"""
Quiz API handler for quiz management operations.
Refactored to inherit from BaseContentAPI to eliminate code duplication.
"""

import os
import logging
from pathlib import Path
from .base_content_api import BaseContentAPI
from ..modules.canvas import list_quizzes, download_quiz_submissions
from ..modules.grading import is_auto_gradable
from ..modules.utils import (
    get_quiz_csv_path, resolve_csv_path,
    list_questions_from_csv, get_grading_status, get_sample_answers
)

logger = logging.getLogger(__name__)


class QuizAPI(BaseContentAPI):
    """Handles quiz-related API operations. Inherits shared methods from BaseContentAPI."""

    def __init__(self, state, window):
        super().__init__(state, window)
        # Cancellation support for grading tasks
        self.grading_cancelled = False

    # ====================
    # Quiz-Specific Methods
    # ====================

    def cancel_grading(self):
        """Cancel ongoing grading task."""
        logger.info("Grading cancellation requested")
        self.grading_cancelled = True
        return self._success_response(message="Grading cancellation requested")

    def get_list(self):
        """Get list of quizzes for current course."""
        logger.info(f"🔍 [API] quiz_get_list() called")

        try:
            if not self.state.course_id:
                logger.warning(f"[API] No course selected in state")
                return self._error_response(
                    "No course selected. Please select a course first.",
                    details="quizzes: []"
                )

            logger.info(f"[API] Fetching quizzes for course {self.state.course_id}")
            logger.debug(f"[API] Calling modules.canvas.list_quizzes()...")
            quizzes = list_quizzes(self.state.course_id)

            logger.info(f"✅ [API] Found {len(quizzes)} quizzes, returning to frontend")
            return self._success_response(quizzes=quizzes)

        except Exception as e:
            logger.error(f"❌ [API] Error fetching quizzes: {e}", exc_info=True)
            return self._error_response(
                "Failed to load quizzes",
                details=str(e)
            )

    def select(self, quiz_id, quiz_name):
        """Select a quiz and load into state."""
        logger.info(f"🔍 [API] quiz_select() called: quiz_id={quiz_id}, quiz_name={quiz_name}")

        try:
            # Clear any previous quiz data to prevent getting stuck on old quizzes
            logger.debug(f"[API] Clearing previous content from state...")
            self.state.clear_content()

            logger.debug(f"[API] Setting content in state: id={quiz_id}, name={quiz_name}, type='quiz'")
            self.state.set_content(quiz_id, quiz_name, 'quiz')

            logger.info(f"✅ [API] Quiz selected successfully: {quiz_name} (ID: {quiz_id})")
            return self._success_response()

        except Exception as e:
            logger.error(f"❌ [API] Error selecting quiz: {e}", exc_info=True)
            return self._error_response("Failed to select quiz", str(e))

    def check_csv(self, quiz_id):
        """Check if CSV exists for quiz."""
        try:
            logger.debug(f"Checking CSV for quiz {quiz_id}, course {self.state.course_id}")

            csv_path = get_quiz_csv_path(self.state.course_id, quiz_id)

            exists = csv_path is not None and os.path.exists(str(csv_path))

            logger.debug(f"CSV {'exists' if exists else 'does not exist'}: {csv_path}")

            return self._success_response(
                exists=exists,
                path=str(csv_path) if exists else None
            )

        except Exception as e:
            logger.error(f"Error checking CSV: {e}")
            return self._error_response("Failed to check CSV", str(e))

    def download_submissions(self, quiz_id, force_download=False):
        """Download quiz submissions from Canvas with real-time progress tracking."""
        logger.info(f"🔍 [API] quiz_download_submissions() called: quiz_id={quiz_id}, force_download={force_download}")

        try:
            # Create progress callback for real-time updates
            def send_progress(data):
                """Send progress updates to frontend via window.evaluate_js()"""
                logger.info(f"[API] send_progress() called with: {data['percent']}% - {data['status']}")
                logger.info(f"[API] self.window exists: {self.window is not None}")

                if self.window:
                    import json
                    js_code = f"if (typeof updateDownloadProgress === 'function') {{ updateDownloadProgress({json.dumps(data)}); }}"
                    logger.info(f"[API] Executing JS code: {js_code[:100]}...")
                    try:
                        self.window.evaluate_js(js_code)
                        logger.info(f"✅ [API] Progress update sent successfully: {data['percent']}% - {data['status']}")
                    except Exception as e:
                        logger.error(f"❌ [API] Failed to send progress update: {e}", exc_info=True)
                else:
                    logger.warning(f"[API] No window available for progress updates")

            # Check if file already exists
            logger.debug(f"[API] Getting CSV path for course {self.state.course_id}, quiz {quiz_id}...")
            csv_path = get_quiz_csv_path(self.state.course_id, quiz_id)
            logger.debug(f"[API] CSV path: {csv_path}")

            if os.path.exists(csv_path) and not force_download:
                logger.info(f"[API] CSV already exists, skipping download: {csv_path}")
                file_path = csv_path

                # Send completion progress for existing file
                if self.window:
                    send_progress({
                        'phase': 'complete',
                        'done': 1,
                        'total': 1,
                        'percent': 100,
                        'current_item': 'Existing CSV',
                        'status': 'Using existing quiz data',
                        'details': str(csv_path)
                    })
            else:
                # Download from Canvas with progress callback
                logger.info(f"[API] CSV not found or force_download=True, calling download module with progress tracking...")
                logger.debug(f"[API] Calling modules.canvas.download_quiz_submissions() with callback...")
                file_path = download_quiz_submissions(
                    self.state.course_id,
                    quiz_id,
                    progress_callback=send_progress  # Pass the callback!
                )

                if not file_path:
                    logger.error(f"❌ [API] Download failed - module returned None")
                    return self._error_response(
                        "Failed to download quiz submissions",
                        details="Canvas download returned no file"
                    )

                logger.info(f"[API] Download successful, CSV saved to: {file_path}")

            # Load CSV into state
            logger.debug(f"[API] Loading CSV into state...")
            self.state.csv_path = file_path

            # Count questions
            logger.debug(f"[API] Counting questions from CSV...")
            questions = list_questions_from_csv(file_path)
            self.state.total_questions = len(questions)
            logger.info(f"[API] Found {self.state.total_questions} questions in CSV")

            # Analyze grading status
            logger.debug(f"[API] Analyzing grading status...")
            grading_status = get_grading_status(file_path)
            self.state.graded_questions = set(grading_status.get('graded_questions', []))
            logger.info(f"[API] Grading status: {len(self.state.graded_questions)} questions already graded")

            logger.info(f"✅ [API] Quiz download complete, returning to frontend")

            return self._success_response(
                path=file_path,
                total_questions=self.state.total_questions
            )

        except Exception as e:
            logger.error(f"❌ [API] Error downloading quiz: {e}", exc_info=True)
            return self._error_response("Failed to download quiz", str(e))

    def load_existing_csv(self, quiz_id):
        """Load existing CSV file into state without downloading."""
        try:
            logger.debug(f"Loading existing CSV for quiz {quiz_id}")

            # Check if course_id is set
            if not self.state.course_id:
                return self._error_response(
                    "No course selected. Please go back and select a course."
                )

            # Get the expected CSV path
            csv_path = get_quiz_csv_path(self.state.course_id, quiz_id)

            # Validate the path exists
            resolved_path = resolve_csv_path(str(csv_path))

            # Check if file actually exists
            if not os.path.exists(resolved_path):
                return self._error_response("CSV file not found", f"Path: {resolved_path}")

            # Load it into state
            self.state.csv_path = resolved_path

            # Count questions
            questions = list_questions_from_csv(self.state.csv_path)
            self.state.total_questions = len(questions)

            # Analyze grading status and update state
            grading_status = get_grading_status(self.state.csv_path)
            self.state.graded_questions = set(grading_status.get('graded_questions', []))

            logger.info(f"Loaded CSV with {self.state.total_questions} questions, "
                       f"{len(self.state.graded_questions)} graded")

            return self._success_response(
                path=str(csv_path),
                total_questions=self.state.total_questions
            )

        except Exception as e:
            logger.error(f"Error loading CSV: {e}")
            return self._error_response("Failed to load CSV", str(e))

    # ====================
    # Shared Methods (Using Parent Implementation)
    # ====================

    def get_questions(self):
        """Get questions from current quiz CSV."""
        return self._get_questions_from_csv()

    def get_sample_answers(self, question_id, count=5):
        """Get sample student answers for a question."""
        return self._get_sample_answers_from_csv(question_id, count)

    def save_grading_results(self, question_id, grading_results):
        """Save grading results after user review."""
        return self._save_grading_results_to_csv(question_id, grading_results)

    # ====================
    # Grading Methods (TODO - Need Implementation)
    # ====================

    def grade_question(self, question_id):
        """
        Grade a specific question.

        TODO: This method needs proper implementation.
        Previously called undefined 'grade_question_in_csv' function.
        """
        logger.warning("grade_question called but not yet implemented")
        return self._error_response(
            "Method not yet implemented",
            details="Quiz grading functionality requires implementation"
        )

    def grade_question_with_criteria(self, question_id, criteria, grade_only_ungraded=True):
        """
        Grade a specific question with provided criteria using LLM or auto-grading.

        Supports real-time progress updates via window.evaluate_js().

        Args:
            question_id: ID of the question to grade (e.g., "q1", "q2")
            criteria: Grading criteria dict with:
                - correct_answer: Model answer or expected response
                - grading_rubric: Rubric or grading guidelines
                - max_points: Maximum points for question
                - feedback_format: Template for feedback
                - good_examples: (optional) Examples of good answers
                - bad_examples: (optional) Examples of poor answers
                - extra_instructions: (optional) Additional instructions
            grade_only_ungraded: If True, skip already-graded submissions

        Returns:
            dict with:
                - success: bool
                - completed: number of submissions graded
                - total: total submissions processed
                - results: list of grading results per student
        """
        import json
        from modules.utils import read_csv, write_csv
        from modules.grading import grade_with_llm, auto_grade_question, is_auto_gradable
        from modules.grading.llm_grade import save_grading_results_to_csv

        try:
            if not self.state.csv_path:
                return self._error_response("No CSV file loaded", details="Please download quiz submissions first")

            logger.info(f"Starting grading for question {question_id} in quiz CSV")

            # Read CSV
            rows = read_csv(self.state.csv_path)

            if not rows:
                return self._error_response("CSV file is empty or could not be read")

            # Quiz CSVs are row-based (one row per student per question)
            # Filter rows for this specific question by question_id column
            question_rows = [r for r in rows if r.get('question_id') == str(question_id)]

            if not question_rows:
                return self._error_response(f"No submissions found for question {question_id}")

            # Debug: Log all students for this question
            logger.info(f"📋 Found {len(question_rows)} submissions for question {question_id}:")
            for i, row in enumerate(question_rows):
                logger.info(f"   Row {i+1}: {row.get('student_name', 'Unknown')} (ID: {row.get('student_id', 'N/A')})")

            # Get question metadata from first row
            first_row = question_rows[0]
            question_text = first_row.get('question_text', criteria.get('question_text', f'Question {question_id}'))
            question_type = first_row.get('question_type', '')
            points_possible = float(first_row.get('points_possible', criteria.get('max_points', 1)) or 1)

            # Filter ungraded if requested
            if grade_only_ungraded:
                to_grade = []
                for row in question_rows:
                    has_feedback = row.get('feedback') and row.get('feedback').strip()
                    has_points = row.get('points_earned') and row.get('points_earned').strip()
                    if not (has_feedback and has_points):
                        to_grade.append(row)
                logger.info(f"Grading {len(to_grade)} ungraded submissions (skipping {len(question_rows) - len(to_grade)} already graded)")
            else:
                to_grade = question_rows
                logger.info(f"Grading all {len(to_grade)} submissions")

            if not to_grade:
                return self._success_response(
                    completed=0,
                    total=len(question_rows),
                    results=[],
                    message="All submissions already graded"
                )

            # Use question metadata (from CSV or criteria)
            max_points = criteria.get('max_points', points_possible)

            # Determine if auto-gradable
            use_auto_grading = is_auto_gradable(question_type)

            # Grade each submission
            grading_results = []
            failed_students = []
            completed = 0
            total = len(to_grade)

            # Reset cancellation flag at start
            self.grading_cancelled = False

            logger.info(f"Grading {total} submissions using {'auto-grading' if use_auto_grading else 'LLM'}...")

            for idx, row in enumerate(to_grade, start=1):
                # Check for cancellation
                if self.grading_cancelled:
                    logger.info(f"⏹️ Grading cancelled by user at {idx-1}/{total} (completed {completed} successfully)")
                    break

                student_id = row.get('student_id', '')
                student_name = row.get('student_name', 'Unknown')
                student_answer = row.get('student_answer', '')

                try:
                    if use_auto_grading:
                        # Auto-grade for objective questions
                        correct_answer = row.get('correct_answer', criteria.get('correct_answer', ''))
                        answer_choices = row.get('answer_choices', '')

                        result = auto_grade_question(
                            question_type=question_type,
                            student_answer=student_answer,
                            correct_answer=correct_answer,
                            points_possible=max_points,
                            answer_choices=answer_choices
                        )
                    else:
                        # LLM grade for subjective questions
                        result = grade_with_llm(
                            question_text=question_text,
                            student_answer=student_answer,
                            criteria=criteria
                        )

                    if result['success']:
                        points = result.get('points', 0)
                        feedback = result.get('feedback', '')

                        grading_results.append({
                            'student_id': student_id,
                            'question_id': question_id,
                            'points': points,
                            'feedback': feedback,
                            'success': True
                        })

                        completed += 1

                        # Real-time progress update via window.evaluate_js()
                        if self.window:
                            progress_percent = (completed / total) * 100
                            update_data = {
                                "done": completed,
                                "total": total,
                                "percent": round(progress_percent, 1),
                                "sub": f"{student_name} (ID: {student_id})",
                                "score": points,
                                "feedback": feedback[:100],  # Truncate for display
                                "questionId": question_id,   # Add questionId to prevent contamination
                                "failed": len(failed_students)  # Track failed count
                            }
                            logger.info(f"📡 Sending progress update: {student_name} (ID: {student_id}) - {points} points")
                            js_code = f"if (typeof updateProgress === 'function') {{ updateProgress({json.dumps(update_data)}); }}"
                            try:
                                self.window.evaluate_js(js_code)
                            except Exception as e:
                                logger.warning(f"Failed to send progress update: {e}")

                        # Incremental save every 5 students for safety
                        if completed % 5 == 0:
                            save_grading_results_to_csv(self.state.csv_path, grading_results)
                            logger.debug(f"Incremental save: {completed}/{total} graded")

                    else:
                        # Skip student on failure - leave ungraded for retry
                        error_msg = result.get('error', 'Unknown error')
                        logger.error(f"❌ Failed to grade {student_name} ({student_id}): {error_msg}")
                        failed_students.append({
                            'student_id': student_id,
                            'student_name': student_name,
                            'error': error_msg
                        })
                        # Don't add to grading_results - student stays ungraded in CSV

                except Exception as e:
                    # Skip student on exception - leave ungraded for retry
                    logger.error(f"❌ Exception grading {student_name} ({student_id}): {e}")
                    failed_students.append({
                        'student_id': student_id,
                        'student_name': student_name,
                        'error': str(e)
                    })
                    # Don't add to grading_results - student stays ungraded in CSV

            # Final save
            success, message = save_grading_results_to_csv(self.state.csv_path, grading_results)

            if not success:
                logger.error(f"Failed to save final results: {message}")

            # Send completion signal
            if self.window:
                try:
                    self.window.evaluate_js("if (typeof finishProgress === 'function') { finishProgress(); }")
                except Exception as e:
                    logger.warning(f"Failed to send completion signal: {e}")

            failed_count = len(failed_students)
            logger.info(f"Grading complete: {completed}/{total} submissions graded successfully, {failed_count} failed" +
                       (f" (cancelled)" if self.grading_cancelled else ""))

            # Build completion message
            message_parts = [f"Graded {completed} out of {total} submissions"]
            if failed_count > 0:
                message_parts.append(f"{failed_count} failed (will retry on next run)")
            if self.grading_cancelled:
                message_parts.append("(stopped by user)")

            return self._success_response(
                completed=completed,
                total=total,
                failed=failed_count,
                failed_students=failed_students,
                results=grading_results,
                cancelled=self.grading_cancelled,
                message=". ".join(message_parts)
            )

        except Exception as e:
            logger.error(f"Error in grade_question_with_criteria: {e}", exc_info=True)
            return self._error_response("Failed to grade question", str(e))

    # ====================
    # Upload/Export Methods (Using Parent Implementation)
    # ====================

    def upload_grades(self, target_assignment_id=None):
        """Upload quiz grades to Canvas."""
        try:
            logger.info(f"Uploading quiz grades to Canvas (target: {target_assignment_id})")

            # Use parent's upload method
            return self._upload_grades_base('quiz', target_assignment_id)

        except Exception as e:
            logger.error(f"Error uploading quiz grades: {e}")
            return self._error_response("Failed to upload grades", str(e))

    def export_grades(self):
        """Export quiz grades to a CSV file."""
        logger.info("Exporting quiz grades")

        # Use parent's export method
        return self._export_grades_base()

    def get_all_grades(self):
        """
        Get all grades from quiz CSV, grouped by question.
        Used by grade_review.html to display grading results.
        Handles row-based CSV format (same as assignments).

        Returns:
            dict with:
                - success: bool
                - questions: list of question dicts, each with:
                    - id: question ID
                    - text: question text
                    - points_possible: max points
                    - students: list of student grade dicts with:
                        - student_id, student_name, student_answer, grade, feedback
        """
        from modules.utils import read_csv, list_questions_from_csv

        try:
            if not self.state.csv_path:
                return {"success": False, "error": "No CSV loaded. Please download quiz submissions first."}

            logger.info("Loading all quiz grades from CSV")

            # Read CSV (row-based format: one row per student per question)
            rows = read_csv(self.state.csv_path)
            if not rows:
                return {"success": False, "error": "CSV file is empty"}

            # Get question metadata (works with row-based format)
            questions_meta = list_questions_from_csv(self.state.csv_path)

            # Group grades by question
            result_questions = []

            for question in questions_meta:
                q_id = question['id']
                q_text = question['text']
                q_points = question.get('points_possible', question.get('points', 0))

                # Get all student submissions for this question (match by question_id column value)
                students = []
                for row in rows:
                    if row.get('question_id') == str(q_id):
                        # Extract grade and feedback from row
                        grade = row.get('points_earned', '')
                        feedback = row.get('feedback', '')

                        # Convert grade to float
                        try:
                            grade_float = float(grade) if grade and grade.strip() else 0
                        except (ValueError, TypeError):
                            grade_float = 0

                        students.append({
                            'student_id': row.get('student_id', ''),
                            'student_name': row.get('student_name', 'Unknown'),
                            'student_answer': row.get('student_answer', ''),
                            'grade': grade_float,
                            'feedback': feedback
                        })

                result_questions.append({
                    'id': q_id,
                    'text': q_text,
                    'points_possible': q_points,
                    'students': students
                })

            logger.info(f"Loaded {len(result_questions)} questions with grades")

            return {"success": True, "questions": result_questions}

        except Exception as e:
            logger.error(f"Error getting quiz grades: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    def start_consistency_test(
        self,
        student_ids,
        num_runs,
        question_filter=None,
        criteria=None
    ):
        """
        Start consistency test for quiz questions.

        Args:
            student_ids: List of student IDs to test
            num_runs: Number of times to grade each student (e.g., 3-5)
            question_filter: Optional question ID to test (null for all)
            criteria: Grading criteria dict (use current if None)

        Returns:
            dict: {success, task_id, message} or {success, error}
        """
        try:
            if not self.state.csv_path or not os.path.exists(self.state.csv_path):
                return {"success": False, "error": "No quiz CSV file found"}

            # Load CSV and get quiz submissions
            from modules.utils import read_csv
            rows = read_csv(self.state.csv_path)
            if not rows:
                return {"success": False, "error": "No quiz submissions found"}

            # Filter for specific question if requested
            if question_filter:
                question_rows = [r for r in rows if r.get('question_id') == str(question_filter)]
                logger.info(f"Testing single question {question_filter} with {len(question_rows)} submissions")
            else:
                question_rows = rows
                logger.info(f"Testing all questions with {len(question_rows)} total submissions")

            # Convert student_ids to student objects expected by consistency engine
            students = []
            logger.info(f"👥 Building student list from {len(question_rows)} rows. Looking for student_ids: {student_ids} (types: {[type(sid).__name__ for sid in student_ids]})")
            for row in question_rows:
                student_id = row.get('student_id')
                logger.info(f"🔍 Checking CSV row: student_id={student_id} (type: {type(student_id).__name__}) - in list? {student_id in student_ids}")
                if student_id in student_ids:
                    students.append({
                        'id': student_id,
                        'name': row.get('student_name', f'Student {student_id}'),
                        'student_answer': row.get('student_answer', ''),  # Include the actual answer
                        'folder': f"user_{student_id}"  # Consistency engine expects folder path
                    })
                    logger.info(f"✅ Added student {student_id} to consistency test")

            logger.info(f"📋 Built students list with {len(students)} students: {[s['id'] for s in students]}")
            if not students:
                return {"success": False, "error": "No matching students found"}

            # Get questions from CSV or use current question
            if criteria:
                # Use current question with provided criteria
                # For quiz consistency, use the question_filter (specific question) or content_id
                q_id = question_filter or self.state.content_id
                logger.info(f"🎯 Using manual criteria with question ID: {q_id} (type: {type(q_id).__name__})")
                questions = [{
                    'id': q_id,
                    'text': criteria.get('question_text', 'Quiz Question'),
                    'grading_criteria': criteria,
                    'correct_answer': criteria.get('correct_answer', ''),
                    'points_possible': criteria.get('max_points', 10)
                }]
            else:
                # Get questions from CSV (limit to question filter if specified)
                from modules.utils import list_questions_from_csv
                csv_questions = list_questions_from_csv(self.state.csv_path)

                questions = []
                if question_filter:
                    # Use specific question
                    for q in csv_questions:
                        if q['id'] == question_filter:
                            questions.append(q)
                            break
                else:
                    # All questions with grading criteria
                    questions = csv_questions

            if not questions:
                return {"success": False, "error": "No questions found for consistency testing"}

            # Get LLM config
            from modules.profile.profile_setter import get_llm_config
            llm_config = get_llm_config()

            logger.info(f"Starting quiz consistency test: {len(students)} students, {len(questions)} questions, {num_runs} runs")

            # Create and run consistency test
            from modules.consistency.consistency_engine import ConsistencyTester
            tester = ConsistencyTester()

            # Progress tracking
            progress_updates = []
            def progress_callback(update):
                progress_updates.append(update)

            # Get quiz info for consistency engine
            quiz_info = {
                'course_id': self.state.course_id,
                'quiz_id': self.state.content_id
            }

            # Run the test (synchronous for now, could be async if needed)
            result = tester.run_test(
                assignment_folder="",  # Quizzes don't have folders
                course_id=self.state.course_id,
                assignment_id=self.state.content_id,
                students=students,
                questions=questions,
                num_runs=int(num_runs),  # Ensure num_runs is an integer
                llm_config=llm_config,
                question_filter=question_filter,
                progress_callback=progress_callback
            )

            logger.info(f"Quiz consistency test completed: {result.get('success', False)}")

            # LOG THE EXACT STRUCTURE BEING RETURNED
            import json
            logger.info("=" * 60)
            logger.info("CONSISTENCY TEST RESULT STRUCTURE:")
            logger.info(f"Keys in result: {list(result.keys())}")
            if 'questions_analyzed' in result:
                logger.info(f"questions_analyzed length: {len(result['questions_analyzed'])}")
                for i, q in enumerate(result['questions_analyzed']):
                    logger.info(f"  Question {i}: {q.get('question_id')} - by_student has {len(q.get('by_student', {}))} students")
            logger.info(f"Full result (first 500 chars): {json.dumps(result, default=str)[:500]}")
            logger.info("=" * 60)

            if result.get('success'):
                # Return detailed results
                return {
                    "success": True,
                    "message": f"Completed consistency test: {len(result.get('results', []))} total grades, {len(students)} students tested",
                    "result": result
                }
            else:
                return {
                    "success": False,
                    "error": result.get('error', 'Unknown error occurred')
                }

        except Exception as e:
            logger.error(f"Error starting consistency test: {e}", exc_info=True)
            return {"success": False, "error": f"Failed to start consistency test: {str(e)}"}

    def get_consistency_test_status(self, task_id):
        """
        Get status of running consistency test (placeholder for async implementation).

        Args:
            task_id: Task ID to check status for

        Returns:
            dict: {success, status, message} or {success, error}
        """
        # For now, return that consistency tests run synchronously
        return {
            "success": False,
            "error": "Quiz consistency tests run synchronously, use start_consistency_test() directly"
        }
