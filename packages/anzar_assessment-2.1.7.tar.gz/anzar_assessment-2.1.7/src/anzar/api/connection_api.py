"""
Connection API handler for Canvas and LLM connections.
"""

import logging
import requests
from ..modules.profile.profile_setter import get_profile_manager
from ..modules.utils.canvas_test import test_canvas_connection

logger = logging.getLogger(__name__)


class ConnectionAPI:
    """Handles connection testing and management."""

    def __init__(self, state, window):
        self.state = state
        self.window = window
        self._manager = get_profile_manager()

    def test_canvas(self, timeout=10):
        """Test Canvas connection with configurable timeout."""
        try:
            success = test_canvas_connection()
            if success:
                self.state.canvas_tested = True
                return {
                    "success": True,
                    "message": "Canvas connection successful"
                }
            else:
                return {
                    "success": False,
                    "error": "Canvas connection failed. Please check your API URL and token."
                }
        except Exception as e:
            logger.error(f"Canvas connection test failed: {e}")
            return {
                "success": False,
                "error": f"Connection error: {str(e)}"
            }

    def test_llm(self, profile_id=None):
        """Test LLM connection for a specific profile or active profile."""
        try:
            # Get the profile to test
            test_profile = self._get_test_profile(profile_id)
            if not test_profile:
                return {
                    "success": False,
                    "error": "No active LLM profile found. Please configure an LLM profile first."
                }

            # Test the connection
            success = self._test_llm_profile(test_profile)

            if success:
                self.state.llm_tested = True
                message = f"LLM connection successful: {test_profile.get('name', 'Unknown')}"
            else:
                message = f"LLM connection failed for: {test_profile.get('name', 'Unknown')}"

            # Return all connections for display
            connections = self._list_llm_connections()
            return {
                "success": success,
                "message": message,
                "connections": connections
            }
        except Exception as e:
            logger.error(f"Error testing LLM: {e}")
            return {
                "success": False,
                "error": f"LLM test error: {str(e)}"
            }

    def _get_test_profile(self, profile_id=None):
        """Get the profile to test (by ID or active profile)."""
        if profile_id:
            profiles = self._manager.get_llm_profiles()
            for p in profiles:
                if p.get('id') == profile_id:
                    return p
            return None
        else:
            return self._manager.get_active_llm_profile()

    def _test_llm_profile(self, profile):
        """Test a single LLM profile by making a test API call."""
        try:
            api_link = profile.get('api_link')
            token = profile.get('token', '')
            model_name = profile.get('model_name')

            if not api_link or not model_name:
                return False

            # Prepare test request
            headers = {
                'Content-Type': 'application/json'
            }

            if token:
                headers['Authorization'] = f'Bearer {token}'

            # Simple test message
            payload = {
                'model': model_name,
                'messages': [
                    {'role': 'user', 'content': 'Hello'}
                ],
                'max_tokens': 5
            }

            # Make test request with short timeout
            response = requests.post(
                api_link,
                json=payload,
                headers=headers,
                timeout=10
            )

            # Consider 200-299 as success
            return 200 <= response.status_code < 300

        except requests.exceptions.Timeout:
            logger.warning(f"LLM connection timeout for {profile.get('name')}")
            return False
        except Exception as e:
            logger.warning(f"LLM connection test failed for {profile.get('name')}: {e}")
            return False

    def _list_llm_connections(self):
        """List all LLM profiles with id field."""
        try:
            profiles = self._manager.get_llm_profiles()
            # Add id field if not present (it should be there already)
            for profile in profiles:
                if 'id' not in profile:
                    profile['id'] = profile.get('name', 'unknown')
            return profiles
        except Exception as e:
            logger.error(f"Error listing LLM connections: {e}")
            return []
