"""
Utility API handler for general utility operations.
Contains navigation, stubs for progress/dashboard, and deprecated grading methods.
"""

import logging
from ..modules.grading import send_grades_to_canvas
from ..modules.utils.data_scanner import scan_data_folder

logger = logging.getLogger(__name__)


class UtilsAPI:
    """Handles utility and general API operations."""

    def __init__(self, state, window):
        self.state = state
        self.window = window

    # ====================
    # Core Utility Methods
    # ====================

    def navigate_to(self, template_name):
        """
        Navigate to a different template.

        CRITICAL METHOD - Called 48 times across 19 JS files.
        """
        logger.debug(f"Navigation requested: {template_name}")
        return {"success": True, "template": template_name}

    # ====================
    # Grading Methods (DEPRECATED - will move to quiz/assignment APIs)
    # ====================
    # NOTE: These methods have issues and belong in quiz/assignment APIs
    # They are kept here temporarily for backward compatibility
    # TODO: Move to appropriate APIs in Steps 8-9

    def analyze_grading_status(self):
        """
        DEPRECATED: Analyze the grading status of the current CSV file.
        TODO: Move to quiz/assignment APIs
        WARNING: Calls undefined function 'analyze_csv_grading_status'
        """
        logger.warning("analyze_grading_status called (deprecated method)")
        if not self.state.csv_path:
            return {"success": False, "error": "No CSV loaded"}

        # This function doesn't exist - method is broken
        # Kept for backward compatibility but will fail
        try:
            return analyze_csv_grading_status(self.state.csv_path)
        except NameError:
            return {
                "success": False,
                "error": "Method not implemented. Use quiz/assignment-specific grading status."
            }

    def get_grades_preview(self):
        """
        DEPRECATED: Get preview of grades to be sent.
        TODO: Move to quiz/assignment APIs
        WARNING: Calls undefined function 'get_grades_preview'
        """
        logger.warning("get_grades_preview called (deprecated method)")
        try:
            if not self.state.csv_path:
                return {"success": False, "error": "No CSV loaded"}

            # This function doesn't exist - method is broken
            success, graded_students, total_students, message = get_grades_preview(self.state.csv_path)

            if success:
                preview_data = []
                for student_id, data in graded_students.items():
                    preview_data.append({
                        "student_id": student_id,
                        "student_name": data["student_name"],
                        "student_email": data.get("student_email", ""),
                        "total_score": data["total_score"],
                        "total_possible": data["total_possible"],
                        "questions": len(data["questions"])
                    })

                return {
                    "success": True,
                    "preview": preview_data,
                    "total_students": total_students,
                    "graded_students": len(graded_students),
                    "message": message
                }
            else:
                return {"success": False, "error": message}
        except (NameError, Exception) as e:
            return {
                "success": False,
                "error": "Method not implemented. Use quiz/assignment-specific grade preview."
            }

    def send_grades_to_canvas(self, target_assignment_id=None):
        """
        DEPRECATED: Send grades to Canvas.
        TODO: Move to quiz/assignment APIs (already have upload methods)
        NOTE: This method actually works but belongs elsewhere
        """
        logger.warning("send_grades_to_canvas called via utils API (deprecated)")
        try:
            is_quiz = self.state.content_type == 'quiz'

            success, message = send_grades_to_canvas(
                self.state.csv_path,
                self.state.course_id,
                self.state.content_id,
                is_quiz,
                target_assignment_id,
                skip_confirmation=True
            )

            if success:
                self.state.clear_content()
                logger.info(f"Grades sent successfully via utils API")

            return {"success": success, "message": message}
        except Exception as e:
            logger.error(f"Error sending grades via utils API: {e}")
            return {"success": False, "error": str(e)}

    # ====================
    # Progress Tracking Stubs
    # ====================
    # These are placeholder methods for future progress tracking feature
    # They return success but don't actually track anything
    # JavaScript calls them, so they must exist

    def progress_start_session(self):
        """Start progress session (stub for future implementation)."""
        logger.debug("progress_start_session called (stub)")
        return {"success": True, "session": {}}

    def progress_update_step(self, step, completed=True):
        """Update progress step (stub for future implementation)."""
        logger.debug(f"progress_update_step called: step={step}, completed={completed} (stub)")
        return {"success": True}

    def progress_get_summary(self):
        """Get progress summary (stub for future implementation)."""
        logger.debug("progress_get_summary called (stub)")
        return {"success": True, "summary": {}}

    def progress_get_recent(self, limit=10):
        """Get recent sessions (stub for future implementation)."""
        logger.debug(f"progress_get_recent called: limit={limit} (stub)")
        return {"success": True, "sessions": []}

    def progress_complete_session(self):
        """Complete session (stub for future implementation)."""
        logger.debug("progress_complete_session called (stub)")
        return {"success": True}

    # ====================
    # Navigation/Breadcrumb Stubs
    # ====================
    # Placeholder methods for future breadcrumb navigation feature

    def get_breadcrumbs(self, current_page):
        """Get breadcrumbs (stub for future implementation)."""
        logger.debug(f"get_breadcrumbs called: page={current_page} (stub)")
        return {"success": True, "breadcrumbs": []}

    def check_navigation(self, target_page):
        """Check if navigation to target page is allowed (stub - always allows)."""
        logger.debug(f"check_navigation called: target={target_page} (stub)")
        return {"success": True, "allowed": True}

    # ====================
    # Dashboard Methods
    # ====================

    def dashboard_get_stats(self):
        """
        Get dashboard statistics by scanning data/ folder.
        Returns counts for courses, quizzes, assignments, and recently graded questions.
        """
        logger.debug("dashboard_get_stats called")

        try:
            # Use shared data scanner utility
            stats = scan_data_folder(recent_days=7)

            logger.info(f"Dashboard stats: {stats['courses']} courses, {stats['quizzes']} quizzes, "
                       f"{stats['assignments']} assignments, {stats['graded_questions']} recently graded questions")

            return {
                "success": True,
                "totalCourses": stats['courses'],
                "totalQuizzes": stats['quizzes'],
                "totalAssignments": stats['assignments'],
                "gradedQuestions": stats['graded_questions']
            }

        except Exception as e:
            logger.error(f"Error getting dashboard stats: {e}")
            return {
                "success": False,
                "error": str(e),
                "totalCourses": 0,
                "totalQuizzes": 0,
                "totalAssignments": 0,
                "gradedQuestions": 0
            }

