// display_utils.js - Common utilities for displaying questions and answers

// HTML cleaning and display utilities
class DisplayUtils {
    /**
     * Safely display HTML content in templates
     * Converts HTML entities and handles special characters
     */
    static safeHtml(htmlContent) {
        if (!htmlContent) return '';

        // HTML entity decoding
        const textArea = document.createElement('textarea');
        textArea.innerHTML = htmlContent;
        return textArea.value;
    }

    /**
     * Convert HTML to plain text for safe x-text display
     */
    static htmlToText(htmlContent) {
        if (!htmlContent) return '';

        // Create temporary div to parse HTML
        const div = document.createElement('div');
        div.innerHTML = htmlContent;
        return div.textContent || div.innerText || '';
    }

    /**
     * Truncate text with proper HTML handling
     */
    static truncate(text, length, preserveHtml = true) {
        if (!text) return '';

        if (preserveHtml && text.includes('<')) {
            // For HTML content, truncate as plain text then preserve HTML
            const plainText = this.htmlToText(text);
            if (plainText.length <= length) return text;

            return plainText.substring(0, length) + '...';
        } else {
            // For plain text, simple truncation
            return text.length > length ? text.substring(0, length) + '...' : text;
        }
    }

    /**
     * Clean and escape text for safe HTML display
     */
    static escapeHtml(text) {
        if (!text) return '';

        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Prepare student answer for display (clean HTML entities)
     */
    static prepareAnswer(answer) {
        if (!answer) return '';

        // First decode any HTML entities
        const decoded = this.safeHtml(answer);

        // Then escape any remaining HTML for safe display
        return this.escapeHtml(decoded);
    }

    /**
     * Prepare question text for display (preserve safe HTML)
     */
    static prepareQuestion(questionText) {
        if (!questionText) return '';

        // Decode HTML entities but preserve safe HTML
        return this.safeHtml(questionText);
    }
}

// Global functions for backward compatibility
window.safeHtml = DisplayUtils.safeHtml.bind(DisplayUtils);
window.htmlToText = DisplayUtils.htmlToText.bind(DisplayUtils);
window.truncate = DisplayUtils.truncate.bind(DisplayUtils);
window.escapeHtml = DisplayUtils.escapeHtml.bind(DisplayUtils);
window.prepareAnswer = DisplayUtils.prepareAnswer.bind(DisplayUtils);
window.prepareQuestion = DisplayUtils.prepareQuestion.bind(DisplayUtils);

console.log('✅ Display utilities loaded');