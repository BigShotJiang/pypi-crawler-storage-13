// content_list.js - Unified content selection for quizzes and assignments (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('contentListPage', () => ({
        // State
        contentType: 'quiz',  // 'quiz' or 'assignment'
        items: [],
        filteredItems: [],
        searchTerm: '',
        selectedItem: null,
        loading: true,
        error: null,
        courseName: '',
        isSelecting: false,

        // Init
        async init() {
            // Wait for API to be ready
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            console.log('🔍 Initializing content list page...');

            // Get content type from sessionStorage or URL
            const urlParams = new URLSearchParams(window.location.search);
            const typeFromUrl = urlParams.get('type');

            console.log('URL params:', window.location.search);
            console.log('Type from URL:', typeFromUrl);

            if (typeFromUrl === 'assignment' || typeFromUrl === 'quiz') {
                this.contentType = typeFromUrl;
                console.log('✅ Set content type from URL:', this.contentType);
            } else {
                // Check session storage
                const savedType = sessionStorage.getItem('contentType');
                if (savedType) {
                    this.contentType = savedType;
                    console.log('✅ Set content type from session:', this.contentType);
                } else {
                    // Default to quiz if nothing set
                    this.contentType = 'quiz';
                    console.log('⚠️ No content type found, defaulting to quiz');
                }
            }

            await this.loadContext();
            await this.loadItems();
        },

        // Load context
        async loadContext() {
            try {
                const state = await window.api.get_state();
                if (state.course_name) {
                    this.courseName = state.course_name;
                }
            } catch (error) {
                console.error('Error loading state:', error);
            }
        },

        // Switch content type
        async switchContentType(type) {
            if (this.contentType === type || this.loading) return;

            this.contentType = type;
            sessionStorage.setItem('contentType', type);

            // Reload items for new type
            await this.loadItems();
        },

        // Load items (quizzes or assignments)
        async loadItems() {
            console.log(`📋 Loading ${this.contentType}s...`);

            this.loading = true;
            this.error = null;
            this.items = [];
            this.filteredItems = [];

            try {
                console.log(`Calling ${this.contentType === 'quiz' ? 'quiz_get_list' : 'assignment_get_list'}()`);

                const result = this.contentType === 'quiz'
                    ? await window.api.quiz_get_list()
                    : await window.api.assignment_get_list();

                console.log('API result:', result);

                const itemsKey = this.contentType === 'quiz' ? 'quizzes' : 'assignments';

                if (result.success && result[itemsKey]) {
                    // Sort by name/title
                    const nameKey = this.contentType === 'quiz' ? 'title' : 'name';
                    this.items = result[itemsKey].sort((a, b) =>
                        (a[nameKey] || '').localeCompare(b[nameKey] || '')
                    );
                    this.filteredItems = [...this.items];
                    console.log(`✅ Loaded ${this.items.length} ${this.contentType}s`);
                    this.loading = false;
                } else {
                    this.error = result.error || `Failed to load ${this.contentType === 'quiz' ? 'quizzes' : 'assignments'}`;
                    console.error('❌ Load failed:', this.error);
                    this.loading = false;
                }
            } catch (error) {
                console.error(`❌ Error loading ${this.contentType}s:`, error);
                this.error = 'Failed to connect to Canvas: ' + error.message;
                this.loading = false;
            }
        },

        // Filter items
        filterItems() {
            const term = this.searchTerm.toLowerCase();
            if (!term) {
                this.filteredItems = [...this.items];
            } else {
                const nameKey = this.contentType === 'quiz' ? 'title' : 'name';
                this.filteredItems = this.items.filter(item =>
                    (item[nameKey] || '').toLowerCase().includes(term)
                );
            }
        },

        // Select item (quiz or assignment)
        async selectItem(item) {
            if (this.isSelecting) return;

            this.selectedItem = item;
            this.isSelecting = true;

            try {
                if (this.contentType === 'quiz') {
                    // Select quiz
                    const selectResult = await window.api.quiz_select(item.id, item.title);

                    if (!selectResult.success) {
                        throw new Error(selectResult.error || 'Failed to select quiz');
                    }

                    // Start progress tracking
                    await window.api.progress_start_session();
                    await window.api.progress_update_step('content_selected', true);

                    // Navigate to quiz CSV page
                    setTimeout(async () => {
                        await window.api.navigate_to('quiz_csv.html');
                    }, 500);

                } else {
                    // Select assignment
                    await window.api.assignment_select(item.id, item.name);

                    // Navigate to assignment download page
                    setTimeout(async () => {
                        await window.api.navigate_to('assignment_download.html');
                    }, 500);
                }
            } catch (error) {
                console.error('Error selecting item:', error);
                Alpine.store('toast').error(`Failed to select ${this.contentType}: ` + error.message);
                this.selectedItem = null;
                this.isSelecting = false;
            }
        },

        // Get card gradient class
        getCardClass(index) {
            return `card-gradient-${(index % 5) + 1}`;
        },

        // Check if item is selected
        isSelected(itemId) {
            return this.selectedItem && this.selectedItem.id === itemId;
        },

        // Format due date
        formatDueDate(dueAt) {
            if (!dueAt) return 'No due date';
            const date = new Date(dueAt);
            return date.toLocaleDateString() + ' at ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        },

        // Format submission types
        formatSubmissionTypes(types) {
            if (!types || !Array.isArray(types)) return 'N/A';
            return types.join(', ');
        }
    }));

    console.log('✅ Unified content list component registered');
});
