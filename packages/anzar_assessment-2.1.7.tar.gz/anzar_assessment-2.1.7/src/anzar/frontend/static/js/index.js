// index.js - Main entry point for the GUI converted to Alpine.js

document.addEventListener('alpine:init', () => {
    Alpine.data('indexPage', () => ({
        profileStatus: '',

        async init() {
            console.log('Initializing index page...');

            // Wait for API to be ready
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.checkProfiles();
                });
            } else if (window.api) {
                await this.checkProfiles();
            } else {
                console.warn('API not yet available');
            }
        },

        async handleStart() {
            console.log('Start button clicked');
            try {
                if (!window.api) {
                    Alpine.store('toast').error('API not available. Please refresh the page.');
                    return;
                }

                // Check if we need profile selection first
                const profileCheck = await this.checkNeedProfileSelection();

                if (profileCheck.needSelection) {
                    console.log('Navigating to profile selection...');
                    await window.api.navigate_to('profile_select.html');
                } else {
                    console.log('Navigating to connection test...');
                    await window.api.navigate_to('connection.html');
                }

                console.log('Navigation completed');
            } catch (error) {
                console.error('Navigation error:', error);
                Alpine.store('toast').error('Navigation error: ' + error.message);
            }
        },

        async checkProfiles() {
            try {
                const activeProfiles = await window.api.profile_get_active();

                if (activeProfiles.success) {
                    let statusText = [];

                    if (activeProfiles.profiles.canvas) {
                        statusText.push(`Canvas: ${activeProfiles.profiles.canvas.name}`);
                    }

                    if (activeProfiles.profiles.llm) {
                        statusText.push(`LLM: ${activeProfiles.profiles.llm.name}`);
                    }

                    this.profileStatus = statusText.join(' | ');
                }
            } catch (error) {
                console.error('Error checking profiles:', error);
            }
        },

        async checkNeedProfileSelection() {
            try {
                // Check if we have both Canvas and LLM profiles configured
                const canvasResult = await window.api.profile_get_all_canvas();
                const llmResult = await window.api.profile_get_all_llm();

                if (canvasResult.success && llmResult.success) {
                    // Need profile selection if:
                    // 1. No profiles exist
                    // 2. Multiple profiles exist but none are active
                    // 3. User has never selected profiles

                    const noCanvasProfiles = canvasResult.profiles.length === 0;
                    const noLLMProfiles = llmResult.profiles.length === 0;
                    const multipleCanvasProfiles = canvasResult.profiles.length > 1;
                    const multipleLLMProfiles = llmResult.profiles.length > 1;

                    if (noCanvasProfiles || noLLMProfiles) {
                        return { needSelection: true, reason: 'no_profiles' };
                    }

                    if ((multipleCanvasProfiles && !canvasResult.active_id) ||
                        (multipleLLMProfiles && !llmResult.active_id)) {
                        return { needSelection: true, reason: 'multiple_profiles' };
                    }
                }

                return { needSelection: false };

            } catch (error) {
                console.error('Error checking profile selection need:', error);
                return { needSelection: true, reason: 'error' };
            }
        }
    }));
});