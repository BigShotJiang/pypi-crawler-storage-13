// grade_edit.js - Unified Grade Editing (Quiz + Assignment)

document.addEventListener('alpine:init', () => {
    Alpine.data('gradeEdit', () => ({
        // State
        gradeData: null,
        grade: 0,
        feedback: '',
        refinementInstruction: '',

        // Init
        async init() {
            console.log('Grade Edit Page: Initializing');

            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            this.loadGradeData();
        },

        // Load grade data from sessionStorage
        loadGradeData() {
            console.log('loadGradeData called');

            // Get grade data from session storage
            const storedData = sessionStorage.getItem('gradeEditData');
            console.log('Stored data:', storedData);

            if (!storedData) {
                console.error('No grade data found in sessionStorage');
                Alpine.store('toast').error('No grade data found. Returning to results page.');
                setTimeout(() => navigateTo('grade_review_v2.html'), 2000);
                return;
            }

            try {
                this.gradeData = JSON.parse(storedData);
                console.log('Parsed grade data:', this.gradeData);

                // Initialize form values
                this.grade = this.gradeData.grade || 0;
                this.feedback = this.gradeData.feedback || '';

                console.log('Form populated with:', { grade: this.grade, feedback: this.feedback });

                // Focus on grade input after Alpine renders
                this.$nextTick(() => {
                    const gradeInput = this.$refs.gradeInput;
                    if (gradeInput) {
                        gradeInput.focus();
                        gradeInput.select();
                        console.log('Grade input focused');
                    }
                });
            } catch (error) {
                console.error('Error parsing grade data:', error);
                Alpine.store('toast').error('Invalid grade data. Returning to results page.');
                setTimeout(() => navigateTo('grade_review_v2.html'), 2000);
            }
        },

        // Computed properties
        get hasChanges() {
            if (!this.gradeData) return false;
            return this.grade !== this.gradeData.grade || this.feedback !== this.gradeData.feedback;
        },

        // Save grade
        async saveGrade() {
            if (!this.gradeData) return;

            // Check if values changed
            if (!this.hasChanges) {
                Alpine.store('toast').info('No changes to save');
                return;
            }

            try {
                Alpine.store('loading').show('Saving grade...');

                // Use UNIFIED API (works for both quiz and assignment)
                const saveResult = await window.api.grades_update(
                    this.gradeData.student_id,
                    this.gradeData.question_id,
                    this.grade,
                    this.feedback
                );

                if (!saveResult.success) {
                    throw new Error(saveResult.error || saveResult.message || 'Save failed');
                }

                Alpine.store('toast').success('Grade saved successfully!');

                // Mark that we're returning from edit so results page can track the edit
                sessionStorage.setItem('returnedFromEdit', JSON.stringify({
                    student_id: this.gradeData.student_id,
                    question_id: this.gradeData.question_id
                }));

                // Clear edit data
                sessionStorage.removeItem('gradeEditData');

                // Return to results page after short delay
                setTimeout(() => {
                    navigateTo('grade_review_v2.html');
                }, 1000);

            } catch (error) {
                console.error('Save error:', error);
                Alpine.store('toast').error('Failed to save: ' + error.message);
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Cancel edit
        cancelEdit() {
            if (this.hasChanges) {
                if (!confirm('Discard changes and return to results?')) {
                    return;
                }
            }

            sessionStorage.removeItem('gradeEditData');
            navigateTo('grade_review_v2.html');
        },

        // Refine feedback with AI
        async refineFeedbackWithAI() {
            if (!this.gradeData) {
                Alpine.store('toast').error('No grade data available');
                return;
            }

            if (!this.refinementInstruction.trim()) {
                Alpine.store('toast').error('Please enter a refinement instruction');
                return;
            }

            try {
                Alpine.store('loading').show('Refining feedback with AI...');

                const result = await window.api.assignment_refine_feedback_with_ai(
                    this.gradeData.student_id,
                    this.gradeData.question_id,
                    this.gradeData.student_answer,
                    this.gradeData.question_text,
                    this.feedback,
                    this.grade,
                    this.gradeData.max_points,
                    this.refinementInstruction
                );

                if (!result.success) {
                    throw new Error(result.error || 'Refinement failed');
                }

                // Update feedback with new feedback
                this.feedback = result.new_feedback;

                // Clear refinement instruction
                this.refinementInstruction = '';

                Alpine.store('toast').success('Feedback refined successfully! Review and save if satisfied.');

                // Focus on feedback to review
                this.$nextTick(() => {
                    const feedbackInput = this.$refs.feedbackInput;
                    if (feedbackInput) {
                        feedbackInput.focus();
                    }
                });

            } catch (error) {
                console.error('Refinement error:', error);
                Alpine.store('toast').error('Failed to refine feedback: ' + error.message);
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Keyboard shortcuts
        handleKeydown(e) {
            // Ctrl/Cmd + S to save
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                this.saveGrade();
            }
            // Escape to cancel
            if (e.key === 'Escape') {
                this.cancelEdit();
            }
        }
    }));

    console.log('✅ Assignment Agent Grade Edit component registered');
});
