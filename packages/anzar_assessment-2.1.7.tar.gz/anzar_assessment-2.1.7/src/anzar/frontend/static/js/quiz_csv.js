// quiz_csv.js - Quiz CSV download with real-time progress (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('quizCSVPage', () => ({
        // State
        quizName: '',
        quizId: null,
        loading: true,
        csvExists: false,
        csvPath: '',

        // Download state
        isDownloading: false,
        downloadProgress: 0,
        downloadStatus: '',
        downloadDetails: '',
        downloadComplete: false,
        completionMessage: '',

        // Init
        async init() {
            console.log('🔍 [JS] Quiz CSV Page: Initializing');

            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadQuizInfo();
            await this.checkCSV();
        },

        // Load quiz info from state
        async loadQuizInfo() {
            try {
                const state = await window.api.get_state();
                this.quizName = state.content_name || 'Quiz';
                this.quizId = state.content_id;

                console.log(`[JS] Quiz info loaded: ${this.quizName} (ID: ${this.quizId})`);

                if (!this.quizId) {
                    console.error('❌ [JS] No quiz selected');
                    Alpine.store('toast').error('No quiz selected');
                    setTimeout(() => navigateTo('quiz_list.html'), 2000);
                }
            } catch (error) {
                console.error('Error loading quiz info:', error);
            }
        },

        // Check if CSV exists
        async checkCSV() {
            console.log('🔍 [JS] Checking for existing CSV...');
            this.loading = true;

            try {
                const result = await window.api.quiz_check_csv(this.quizId);

                if (result.success) {
                    this.csvExists = result.exists || false;
                    this.csvPath = result.path || '';

                    console.log(`[JS] CSV exists: ${this.csvExists}`);
                    console.log(`[JS] CSV path: ${this.csvPath}`);
                }

                this.loading = false;

            } catch (error) {
                console.error('❌ [JS] Error checking CSV:', error);
                this.loading = false;
            }
        },

        // Use existing CSV
        async useExistingCSV() {
            console.log('🔍 [JS] useExistingCSV() called');

            try {
                const result = await window.api.quiz_load_existing_csv(this.quizId);

                if (!result.success) {
                    throw new Error(result.error || 'Failed to load existing CSV');
                }

                console.log(`✅ [JS] Loaded existing CSV - ${result.total_questions} questions`);

                this.downloadComplete = true;
                this.completionMessage = `${result.total_questions} questions loaded from existing data`;

                Alpine.store('toast').success('Quiz data loaded!');

            } catch (error) {
                console.error('❌ [JS] Error loading CSV:', error);
                Alpine.store('toast').error('Failed to load CSV: ' + error.message);
            }
        },

        // Download fresh
        async downloadFresh() {
            console.log('🔍 [JS] downloadFresh() called - forcing re-download');
            await this.downloadSubmissions(true);
        },

        // Start download (first time)
        async startDownload() {
            console.log('🔍 [JS] startDownload() called');
            await this.downloadSubmissions(false);
        },

        // Download submissions with real-time progress
        async downloadSubmissions(forceDownload = false) {
            console.log(`🔍 [JS] downloadSubmissions() called: quizId=${this.quizId}, force=${forceDownload}`);

            this.isDownloading = true;
            this.downloadComplete = false;
            this.downloadProgress = 0;
            this.downloadStatus = 'Starting download...';
            this.downloadDetails = '';

            try {
                console.log(`[JS] Calling window.api.quiz_download_submissions(${this.quizId}, ${forceDownload})...`);

                const result = await window.api.quiz_download_submissions(this.quizId, forceDownload);

                console.log('[JS] Download result:', result);

                if (!result.success) {
                    console.error('❌ [JS] Download failed:', result.error);
                    throw new Error(result.error || 'Failed to download submissions');
                }

                console.log(`✅ [JS] Download successful - ${result.total_questions} questions`);

                this.csvExists = true;
                this.csvPath = result.path;
                this.downloadComplete = true;
                this.downloadStatus = 'Download complete!';
                this.completionMessage = `${result.total_questions} questions ready to grade`;

                Alpine.store('toast').success('Quiz data downloaded!');

            } catch (error) {
                console.error('❌ [JS] Error downloading:', error);
                Alpine.store('toast').error('Download failed: ' + error.message);
                this.downloadComplete = false;
            } finally {
                this.isDownloading = false;
            }
        },

        // Proceed to grading
        async proceedToGrading() {
            console.log('🔍 [JS] proceedToGrading() called');

            if (!this.downloadComplete && !this.csvExists) {
                Alpine.store('toast').warning('Please download quiz data first');
                return;
            }

            console.log('[JS] Navigating to grading_hub.html...');
            await window.api.navigate_to('grading_hub.html');
        }
    }));

    // Global progress update function for quiz downloads
    window.updateDownloadProgress = function(data) {
        console.log('📊 [JS] Quiz download progress update:', data);

        try {
            // Find the quiz CSV page component
            const page = document.querySelector('[x-data*="quizCSVPage"]');

            if (page && page._x_dataStack && page._x_dataStack[0]) {
                const component = page._x_dataStack[0];

                // Update progress state
                component.downloadProgress = data.percent || 0;
                component.downloadStatus = data.status || 'Downloading...';
                component.downloadDetails = data.details || '';

                console.log(`✅ [JS] Progress UI updated: ${data.percent}% - ${data.status}`);
            } else if (page && page.__x && page.__x.$data) {
                const component = page.__x.$data;

                component.downloadProgress = data.percent || 0;
                component.downloadStatus = data.status || 'Downloading...';
                component.downloadDetails = data.details || '';

                console.log(`✅ [JS] Progress UI updated: ${data.percent}% - ${data.status}`);
            } else {
                console.warn('[JS] Quiz CSV component not found for progress update');
            }
        } catch (error) {
            console.error('❌ [JS] Failed to update progress:', error);
        }
    };

    console.log('✅ Quiz CSV component registered');
});
