// grade_review.js - Unified Grade Review (Quiz + Assignment)

document.addEventListener('alpine:init', () => {
    Alpine.data('gradeReview', () => ({
        // State
        questions: [], // Primary data structure - no more allResults duplication
        allStudents: [], // Now includes cached totals
        currentQuestion: null,
        currentStudent: null,
        currentStudentName: '',
        currentStudentResults: [],
        editedStudents: new Set(),
        loading: true,
        viewMode: 'by-student', // 'by-question' or 'by-student' - DEFAULT CHANGED TO 'by-student'
        currentView: 'questions', // 'questions', 'students', or 'student-detail'
        contentType: '', // 'quiz' or 'assignment' - detected from state
        statistics: null, // Grade statistics for dashboard
        searchQuery: '', // Search filter
        scoreFilter: 'all', // Score filter: all, high, medium, low
        editMode: false, // Whether we're in inline edit mode
        currentEditStudent: null, // Student ID being edited
        currentEditQuestion: null, // Question ID being edited
        editData: null, // Current edit data

        // Assignment type detection
        isFileBased: false, // File-based assignments have long answers
        showFullAnswer: false, // Toggle for showing/hiding full answer in file-based view

        // Answer expansion tracking
        expandedAnswers: new Set(), // Track which answers are expanded

        // Refine feedback state
        showRefineInput: false,
        showRefineOptions: false, // Show AI preset options
        refinementPrompt: '',
        refining: false,
        refinementPresets: [
            { label: 'Make More Encouraging', prompt: 'Rewrite this feedback to be more encouraging and positive while maintaining accuracy' },
            { label: 'Make More Specific', prompt: 'Add more specific examples and details to this feedback' },
            { label: 'Convert to Bullet Points', prompt: 'Reformat this feedback as clear, concise bullet points' },
            { label: 'Shorten', prompt: 'Condense this feedback to be more concise while keeping key points' },
            { label: 'Custom...', prompt: '' }
        ],

        // Init
        async init() {
            console.log('Assignment Agent Results: Initializing');

            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            // Detect content type from state
            const state = await window.api.get_state();
            if (state.success) {
                this.contentType = state.state.content_type || 'assignment';
                console.log(`📊 Detected content type: ${this.contentType}`);
            }

            await this.loadResults();
            await this.loadStatistics();
        },

        // Load results
        async loadResults() {
            try {
                this.loading = true;

                // Check if returning from edit page - if so, reload to refresh data
                const cameFromEdit = sessionStorage.getItem('returnedFromEdit');
                if (cameFromEdit) {
                    sessionStorage.removeItem('returnedFromEdit');
                    // Mark that we edited something
                    const editInfo = JSON.parse(cameFromEdit);
                    this.editedStudents.add(`${editInfo.student_id}-${editInfo.question_id}`);
                }

                // Use UNIFIED API (works for both quiz and assignment)
                const result = await window.api.grades_get_all();

                if (!result.success) {
                    Alpine.store('toast').error('Failed to load results: ' + result.error);
                    this.loading = false;
                    return;
                }

                // Data comes pre-structured by question
                // Keep only the questions structure - no more allResults duplication
                this.questions = result.questions;

                // Mark previously edited items
                this.questions.forEach(question => {
                    const students = question.students || [];
                    students.forEach(student => {
                        const editKey = `${student.student_id}-${question.id}`;
                        student.edited = this.editedStudents.has(editKey);
                    });
                });

                console.log('Loaded results:', this.questions.length, 'questions with students');

                // Build student list for by-student view
                this.buildStudentList();

                // Detect assignment type (file-based vs parsable)
                this.detectAssignmentType();

                this.loading = false;

            } catch (error) {
                console.error('Error loading results:', error);
                Alpine.store('toast').error('Failed to load grading results: ' + error.message);
                this.loading = false;
            }
        },

        // Detect if this is file-based or parsable assignment
        detectAssignmentType() {
            // Need at least 2 questions to compare
            if (this.questions.length < 2) {
                console.log('📊 Only 1 question - assuming parsable');
                this.isFileBased = false;
                return;
            }

            // Check if any student has identical answers across all questions
            // File-based: Same file content for all questions
            // Parsable: Different answers per question

            // Get first student with multiple answers
            for (const question of this.questions) {
                const students = question.students || [];
                for (const student of students) {
                    // Find all this student's answers across questions
                    const studentAnswers = [];
                    for (const q of this.questions) {
                        const studentInQ = (q.students || []).find(s => s.student_id === student.student_id);
                        if (studentInQ && studentInQ.student_answer) {
                            studentAnswers.push(studentInQ.student_answer);
                        }
                    }

                    if (studentAnswers.length >= 2) {
                        const firstAnswer = studentAnswers[0];
                        const allSame = studentAnswers.every(a => a === firstAnswer);

                        this.isFileBased = allSame;
                        console.log(`📊 Assignment type: ${this.isFileBased ? 'File-based' : 'Parsable'} (checked student ${student.student_id} with ${studentAnswers.length} questions)`);
                        return;
                    }
                }
            }

            // Fallback: assume parsable if we can't determine
            console.log('📊 Could not determine type - assuming parsable');
            this.isFileBased = false;
        },

        // Get results for a specific question - optimized to use questions structure
        getQuestionResults(questionId) {
            const question = this.questions.find(q => q.id === questionId);
            return question ? (question.students || []) : [];
        },

        // Get question status
        getQuestionStatus(questionId) {
            const questionResults = this.getQuestionResults(questionId);
            const gradedCount = questionResults.filter(r => r.grade > 0).length;
            const totalCount = questionResults.length;

            let status = 'ungraded';
            let statusText = 'Ungraded';

            if (gradedCount === totalCount && totalCount > 0) {
                status = 'graded';
                statusText = 'All Graded';
            } else if (gradedCount > 0) {
                status = 'partial';
                statusText = `${gradedCount}/${totalCount} Graded`;
            }

            return { status, statusText, gradedCount, totalCount };
        },

        // Show students for a question
        showStudents(questionId) {
            console.log('📋 showStudents called with questionId:', questionId);

            // Validate input parameter
            if (!questionId) {
                console.error('❌ showStudents: No questionId provided');
                return;
            }

            // Find the question
            const question = this.questions.find(q => q.id === questionId);
            if (!question) {
                console.error(`❌ showStudents: Question with ID ${questionId} not found`);
                return;
            }

            // Set current question and switch view
            this.currentQuestion = question;
            this.currentView = 'students';

            console.log(`✅ Switched to students view for question: ${question.text?.substring(0, 50)}...`);
        },

        // Back to questions view
        backToQuestions() {
            console.log('🔙 backToQuestions called');

            // Reset state completely
            this.currentView = 'questions';
            this.currentQuestion = null;
            this.currentEditStudent = null;
            this.currentEditQuestion = null;
            this.editData = null;

            console.log('✅ Reset to questions view, currentQuestion cleared');
        },

        // Get current question title
        get currentQuestionTitle() {
            if (!this.currentQuestion) return '';
            return this.currentQuestion.text;
        },

        // Get current question results
        get currentQuestionResults() {
            if (!this.currentQuestion || !this.currentQuestion.id) {
                console.warn('⚠️ currentQuestion or currentQuestion.id is null, returning empty array');
                return [];
            }

            const results = this.getQuestionResults(this.currentQuestion.id);
            if (!results || !Array.isArray(results)) {
                console.warn('⚠️ getQuestionResults returned invalid results:', results);
                return [];
            }

            return results;
        },

        // Edit student grade - NOW INLINE
        editStudent(result) {
            console.log('editStudent called with:', result);

            if (!result) {
                Alpine.store('toast').error('Could not find student data to edit.');
                return;
            }

            // Store current edit state
            this.currentEditStudent = result.student_id;
            this.currentEditQuestion = result.question_id;
            this.editMode = true;

            // Create edit data for the inline form
            this.editData = {
                student_id: result.student_id,
                student_name: result.student_name,
                question_id: result.question_id,
                question_text: result.question_text,
                student_answer: result.student_answer,
                grade: result.grade,
                max_points: result.max_points,
                feedback: result.feedback || ''
            };

            // Set up auto-resizing textareas after DOM updates
            this.$nextTick(() => {
                this.setupAutoResizeTextarea();
            });
        },

        // Cancel inline edit
        cancelEdit() {
            this.editMode = false;
            this.currentEditStudent = null;
            this.currentEditQuestion = null;
            this.editData = null;
        },

        // Save inline edit
        async saveInlineEdit() {
            if (!this.editData) return;

            try {
                Alpine.store('loading').show('Saving grade...');

                // Use the correct API method based on content type
                let saveResult;
                if (this.contentType === 'quiz') {
                    // For quiz, we need to save using quiz API
                    // Quiz saves work differently - they expect a list of grading results
                    const gradingResults = [{
                        student_id: this.editData.student_id,
                        student_name: this.editData.student_name,
                        question_id: this.editData.question_id,
                        grade: this.editData.grade,
                        feedback: this.editData.feedback,
                        points_earned: this.editData.grade,
                        points_possible: this.editData.max_points
                    }];
                    saveResult = await window.api.quiz_save_grading_results(this.editData.question_id, gradingResults);
                } else {
                    // For assignment, use the single grade update
                    saveResult = await window.api.assignment_update_single_grade(
                        this.editData.student_id,
                        this.editData.question_id,
                        this.editData.grade,
                        this.editData.feedback
                    );
                }

                if (saveResult.success) {
                    Alpine.store('toast').success('Grade saved successfully');

                    // Mark as edited
                    const editKey = `${this.editData.student_id}-${this.editData.question_id}`;
                    this.editedStudents.add(editKey);

                    // Update the local data
                    await this.loadResults();

                    // Close edit mode
                    this.cancelEdit();
                } else {
                    Alpine.store('toast').error('Failed to save grade: ' + (saveResult.error || saveResult.message || 'Unknown error'));
                }
            } catch (error) {
                console.error('Save error:', error);
                Alpine.store('toast').error('Failed to save grade: ' + error.message);
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Toggle refine feedback input
        toggleRefineInput() {
            this.showRefineInput = !this.showRefineInput;
            if (!this.showRefineInput) {
                this.refinementPrompt = '';
            }
        },

        // Execute refine feedback
        async refineFeedback() {
            if (!this.refinementPrompt || !this.refinementPrompt.trim()) {
                Alpine.store('toast').error('Please enter refinement instructions');
                return;
            }

            if (!this.editData || !this.editData.feedback) {
                Alpine.store('toast').error('No feedback to refine');
                return;
            }

            try {
                this.refining = true;
                Alpine.store('loading').show('Refining feedback with AI...');

                // Call backend API with all required parameters
                const result = await window.api.assignment_refine_feedback_with_ai(
                    this.editData.student_id,
                    this.editData.question_id,
                    this.editData.student_answer,
                    this.editData.question_text || '',
                    this.editData.feedback,
                    this.editData.grade,
                    this.editData.max_points,
                    this.refinementPrompt
                );

                if (result.success && result.new_feedback) {
                    // Directly apply refined feedback to the edit form
                    this.editData.feedback = result.new_feedback;
                    Alpine.store('toast').success('Feedback refined successfully!');
                    this.showRefineInput = false;
                    this.refinementPrompt = '';
                } else {
                    Alpine.store('toast').error('Failed to refine feedback: ' + (result.error || 'Unknown error'));
                }
            } catch (error) {
                console.error('Refine error:', error);
                Alpine.store('toast').error('Failed to refine feedback: ' + error.message);
            } finally {
                this.refining = false;
                Alpine.store('loading').hide();
            }
        },

        // Check if currently editing this item
        isEditing(studentId, questionId) {
            return this.editMode &&
                   this.currentEditStudent === studentId &&
                   this.currentEditQuestion === questionId;
        },

        // Get grade class for color
        getGradeClass(grade, maxPoints) {
            if (grade === maxPoints) return 'grade-high';
            if (grade >= maxPoints * 0.5) return 'grade-medium';
            return 'grade-low';
        },

        // Load statistics
        async loadStatistics() {
            try {
                const result = await window.api.grades_get_statistics();
                if (result.success) {
                    this.statistics = result;
                    console.log('📊 Loaded statistics:', this.statistics);
                }
            } catch (error) {
                console.error('Failed to load statistics:', error);
            }
        },

        // Navigate to submission page for upload
        async navigateToSubmission() {
            await window.api.navigate_to('rubric.html');
        },

        // Export CSV
        async exportCSV() {
            try {
                Alpine.store('loading').show('Exporting CSV...');

                // Use content-type aware export
                let result;
                if (this.contentType === 'quiz') {
                    result = await window.api.quiz_export_grades();
                } else {
                    result = await window.api.assignment_export_grades();
                }

                if (result.success) {
                    Alpine.store('toast').success('CSV exported successfully');
                } else {
                    Alpine.store('toast').error('Failed to export: ' + result.error);
                }
            } catch (error) {
                Alpine.store('toast').error('Export failed: ' + error.message);
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Navigate back to grading hub
        async backToGradingHub() {
            try {
                await window.api.navigate_to('grading_hub.html');
            } catch (error) {
                console.error('Error navigating to grading hub:', error);
                Alpine.store('toast').error('Failed to navigate to grading hub');
            }
        },

        // Show full question in modal
        showFullQuestion(questionText) {
            if (!questionText) {
                console.warn('No question text provided to showFullQuestion');
                return;
            }

            // Use the global prepareQuestion function for consistent formatting
            const preparedContent = window.prepareQuestion ? window.prepareQuestion(questionText) : questionText;

            console.log('Opening modal with question text:', questionText.substring(0, 100) + '...');

            // Try multiple methods to open the modal
            if (window.showModal) {
                // Use global helper if available
                window.showModal({
                    title: 'Full Question Text',
                    content: `<div class="prose">${preparedContent}</div>`,
                    size: 'lg'
                });
            } else if (typeof Alpine !== 'undefined' && Alpine.store && Alpine.store('modal')) {
                // Direct Alpine store access
                Alpine.store('modal').open({
                    title: 'Full Question Text',
                    content: `<div class="prose">${preparedContent}</div>`,
                    size: 'lg'
                });
            } else {
                console.error('Modal system not available');
                // Fallback: show alert
                alert('Full Question:\n\n' + questionText);
            }
        },

        // Utility: Truncate text
        truncate(text, length) {
            if (!text) return '';
            return text.length > length ? text.substring(0, length) + '...' : text;
        },

        // Wrapper for global prepareQuestion function
        prepareQuestion(text) {
            return window.prepareQuestion ? window.prepareQuestion(text) : text;
        },

        // Wrapper for global prepareAnswer function
        prepareAnswer(text) {
            return window.prepareAnswer ? window.prepareAnswer(text) : text;
        },

        // Auto-resize textarea functionality
        setupAutoResizeTextarea() {
            // Use this.$el to scope the query to the component's root element
            const textareas = this.$el.querySelectorAll('.auto-resize-textarea');
            textareas.forEach(textarea => {
                this.addAutoResizeToTextarea(textarea);
            });
        },

        addAutoResizeToTextarea(textarea) {
            const resizeTextarea = () => {
                // Reset height to 'auto' to ensure scrollHeight is calculated correctly
                textarea.style.height = 'auto';
                // Set the height to the scrollHeight, with a minimum floor of 120px
                const newHeight = Math.max(textarea.scrollHeight, 120);
                textarea.style.height = newHeight + 'px';
            };

            // A minimal timeout ensures the browser has calculated the layout before we resize.
            // This is more reliable than a fixed 100ms delay.
            setTimeout(resizeTextarea, 0);

            // Add event listeners for typing and focus
            textarea.addEventListener('input', resizeTextarea);
            textarea.addEventListener('focus', resizeTextarea);

            // Also resize when the window resizes, as this can affect layout
            window.addEventListener('resize', resizeTextarea);
        },

        // Enhanced content truncation with expandable sections
        truncateSmart(text, maxLength = 150) {
            if (!text) return '';

            // Remove HTML tags for length calculation
            const plainText = text.replace(/<[^>]*>/g, '');

            if (plainText.length <= maxLength) {
                return { text, truncated: false };
            }

            // Find a good breaking point near the max length
            const truncated = plainText.substring(0, maxLength);
            const lastSpace = truncated.lastIndexOf(' ');
            const lastSentence = Math.max(
                truncated.lastIndexOf('.'),
                truncated.lastIndexOf('!'),
                truncated.lastIndexOf('?')
            );

            let cutPoint = lastSpace;
            if (lastSentence > maxLength * 0.6) {
                cutPoint = lastSentence + 1;
            }

            const finalText = cutPoint > 0 ? plainText.substring(0, cutPoint) : truncated;

            return {
                text: finalText + '...',
                truncated: true,
                originalText: text
            };
        },

        // Toggle content expansion
        toggleContentExpansion(elementId) {
            const element = document.getElementById(elementId);
            const toggle = document.getElementById(elementId + '-toggle');

            if (!element || !toggle) return;

            const isExpanded = element.classList.contains('expanded');

            if (isExpanded) {
                element.classList.remove('expanded');
                element.classList.add('content-truncated');
                toggle.classList.remove('expanded');
                toggle.innerHTML = '<i class="ph-caret-down"></i> Show More';
            } else {
                element.classList.remove('content-truncated');
                element.classList.add('expanded');
                toggle.classList.add('expanded');
                toggle.innerHTML = '<i class="ph-caret-up"></i> Show Less';
            }
        },

        // Generate unique IDs for expandable content
        generateContentId(type, id, suffix = '') {
            return `${type}-${id}${suffix ? '-' + suffix : ''}`;
        },

        // Create expandable content HTML
        createExpandableContent(text, contentId, maxLength = 150) {
            const result = this.truncateSmart(text, maxLength);

            if (!result.truncated) {
                return `<div id="${contentId}" class="content-section-content">${this.prepareQuestion ? this.prepareQuestion(text) : text}</div>`;
            }

            return `
                <div id="${contentId}" class="content-section-content content-truncated">${this.prepareQuestion ? this.prepareQuestion(result.text) : result.text}</div>
                <button id="${contentId}-toggle" class="expand-toggle" @click="toggleContentExpansion('${contentId}')">
                    <i class="ph-caret-down"></i> Show More
                </button>
            `;
        },

        // =========================================================================
        // BY-STUDENT VIEW METHODS
        // =========================================================================

        // Build list of all unique students with cached grade totals
        buildStudentList() {
            const studentMap = {};

            this.questions.forEach(question => {
                // Defensive check: ensure students array exists
                const students = question.students || [];
                students.forEach(student => {
                    if (!studentMap[student.student_id]) {
                        studentMap[student.student_id] = {
                            student_id: student.student_id,
                            student_name: student.student_name,
                            totalEarned: 0,
                            totalPossible: 0,
                            questionCount: 0,
                            percentage: 0
                        };
                    }

                    // Accumulate totals
                    const earned = parseFloat(student.grade) || 0;
                    const possible = parseFloat(question.points_possible) || 0;

                    studentMap[student.student_id].totalEarned += earned;
                    studentMap[student.student_id].totalPossible += possible;
                    studentMap[student.student_id].questionCount++;
                });
            });

            // Calculate percentages
            Object.values(studentMap).forEach(student => {
                student.percentage = student.totalPossible > 0
                    ? (student.totalEarned / student.totalPossible) * 100
                    : 0;
            });

            this.allStudents = Object.values(studentMap);
            console.log(`✅ Built student list with ${this.allStudents.length} students and cached totals`);
        },

        // Computed: Filtered students list - optimized with cached totals
        get filteredStudents() {
            let filtered = [...this.allStudents];

            // Apply search filter
            if (this.searchQuery.trim()) {
                const query = this.searchQuery.toLowerCase();
                filtered = filtered.filter(student =>
                    student.student_name.toLowerCase().includes(query)
                );
            }

            // Apply score filter using cached percentage
            if (this.scoreFilter !== 'all') {
                filtered = filtered.filter(student => {
                    const percentage = student.percentage || 0;

                    if (this.scoreFilter === 'high') return percentage >= 90;
                    if (this.scoreFilter === 'medium') return percentage >= 70 && percentage < 90;
                    if (this.scoreFilter === 'low') return percentage < 70;
                    return true;
                });
            }

            return filtered;
        },

        // Show all grades for one student
        showStudentGrades(studentId) {
            const studentResults = [];
            const studentInfo = this.allStudents.find(s => s.student_id === studentId);

            this.questions.forEach(question => {
                // Defensive check: ensure students array exists
                const students = question.students || [];
                const studentGrade = students.find(s => s.student_id === studentId);
                if (studentGrade) {
                    studentResults.push({
                        question_id: question.id,
                        question_text: question.text,
                        student_id: studentId,
                        student_name: studentGrade.student_name,
                        student_answer: studentGrade.student_answer,
                        grade: studentGrade.grade,
                        max_points: question.points_possible,
                        feedback: studentGrade.feedback
                    });
                }
            });

            this.currentStudent = studentId;
            this.currentStudentName = studentInfo ? studentInfo.student_name : 'Student';
            this.currentStudentResults = studentResults;
            this.currentView = 'student-detail';
        },

        // Back to student list
        backToStudentList() {
            this.currentView = 'questions';
            this.currentStudent = null;
            this.currentStudentResults = [];
        },

        // Get summary of student's grades - optimized with cached totals
        getStudentGradesSummary(studentId) {
            const student = this.allStudents.find(s => s.student_id === studentId);
            if (!student) return 'No data';

            const percentage = Math.round(student.percentage || 0);
            return `${student.totalEarned.toFixed(1)}/${student.totalPossible} (${percentage}%) - ${student.questionCount} questions`;
        },

        // =========================================================================
        // ANSWER EXPAND/COLLAPSE FUNCTIONALITY
        // =========================================================================

        // Toggle individual answer expansion
        toggleAnswer(studentId, questionId) {
            const key = `${studentId}-${questionId}`;
            if (this.expandedAnswers.has(key)) {
                this.expandedAnswers.delete(key);
            } else {
                this.expandedAnswers.add(key);
            }
            // Force reactivity update
            this.expandedAnswers = new Set(this.expandedAnswers);
        },

        // Check if answer is expanded
        isAnswerExpanded(studentId, questionId) {
            return this.expandedAnswers.has(`${studentId}-${questionId}`);
        },

        // =========================================================================
        // ENHANCED AI REFINEMENT WITH PRESETS
        // =========================================================================

        // Apply AI refinement preset
        async applyRefinementPreset(preset) {
            if (!preset.prompt) {
                // Custom option - show input
                this.showRefineInput = true;
                this.showRefineOptions = false;
                this.refinementPrompt = '';
            } else {
                // Direct preset - apply immediately
                this.refinementPrompt = preset.prompt;
                this.showRefineOptions = false;
                await this.refineFeedback();
            }
        },

        // Toggle AI refinement options
        toggleRefineOptions() {
            this.showRefineOptions = !this.showRefineOptions;
            if (this.showRefineOptions) {
                this.showRefineInput = false;
            }
        }
    }));

    console.log('✅ Grade Review component registered');
});
