// grade_review_v2.js - Clean Slate Unified Grade Review
// Completely rewritten for better performance, cleaner code, and modern UX

document.addEventListener('alpine:init', () => {
    Alpine.data('gradeReviewV2', () => ({
        // =========================================================================
        // STATE MANAGEMENT
        // =========================================================================

        // Core Data
        questions: [],              // Primary data structure: questions with nested students
        allStudents: [],            // Cached student list with pre-calculated totals
        statistics: null,           // Grade statistics
        contentType: '',            // 'quiz' or 'assignment'
        isFileBased: false,         // File-based vs parsable assignment
        parsingStrategy: '',        // 'agent', 'metadata', etc.

        // View State
        loading: true,
        viewMode: 'by-student',     // 'by-student' or 'by-question'
        currentView: 'list',        // 'list', 'detail'

        // Current Selection
        currentQuestion: null,
        currentStudent: null,
        currentStudentName: '',

        // Filters
        searchQuery: '',
        scoreFilter: 'all',         // 'all', 'high', 'medium', 'low'

        // Edit State
        editingKey: null,           // 'studentId-questionId' being edited
        editData: null,             // Current edit data object

        // UI State
        expandedAnswers: new Set(), // Track expanded answers
        showFullAnswer: false,      // For file-based assignments
        editedStudents: new Set(),  // Track edited items

        // Modal State
        modalOpen: false,
        modalTitle: '',
        modalContent: '',

        // AI Refinement State
        showAiOptions: false,
        showCustomInput: false,
        refinementPrompt: '',
        refining: false,
        aiPresets: [
            { label: 'More Encouraging', prompt: 'Rewrite this feedback to be more encouraging and positive while maintaining accuracy' },
            { label: 'More Specific', prompt: 'Add more specific examples and details to this feedback' },
            { label: 'Bullet Points', prompt: 'Reformat this feedback as clear, concise bullet points' },
            { label: 'Shorten', prompt: 'Condense this feedback to be more concise while keeping key points' },
            { label: 'Custom...', prompt: null }
        ],

        // =========================================================================
        // INITIALIZATION
        // =========================================================================

        async init() {
            console.log('🎨 Grade Review V2 initializing...');

            if (window.initializeAPI) {
                window.initializeAPI(async () => await this.loadData());
            } else if (window.api) {
                await this.loadData();
            } else {
                console.error('⚠️ API not available');
            }
        },

        async loadData() {
            try {
                this.loading = true;

                // Detect content type and parsing strategy
                const state = await window.api.get_state();
                if (state.success) {
                    this.contentType = state.state.content_type || 'assignment';
                    this.parsingStrategy = state.state.parsing_strategy || '';
                    console.log('📋 Content type:', this.contentType, 'Parsing strategy:', this.parsingStrategy);
                }

                // Load grades
                const result = await window.api.grades_get_all();
                if (!result.success) {
                    Alpine.store('toast').error('Failed to load results: ' + result.error);
                    return;
                }

                this.questions = result.questions || [];

                // Mark edited items
                this.questions.forEach(q => {
                    (q.students || []).forEach(s => {
                        const key = `${s.student_id}-${q.id}`;
                        s.edited = this.editedStudents.has(key);
                    });
                });

                // Build student list with cached totals
                this.buildStudentCache();

                // Detect assignment type
                this.detectAssignmentType();

                // Load statistics
                await this.loadStatistics();

                console.log(`✅ Loaded ${this.questions.length} questions, ${this.allStudents.length} students`);

            } catch (error) {
                console.error('❌ Load error:', error);
                Alpine.store('toast').error('Failed to load: ' + error.message);
            } finally {
                this.loading = false;
            }
        },

        async loadStatistics() {
            try {
                const result = await window.api.grades_get_statistics();
                if (result.success) {
                    this.statistics = result;
                }
            } catch (error) {
                console.error('Statistics error:', error);
            }
        },

        // =========================================================================
        // DATA PROCESSING
        // =========================================================================

        buildStudentCache() {
            const map = {};

            this.questions.forEach(q => {
                (q.students || []).forEach(s => {
                    if (!map[s.student_id]) {
                        map[s.student_id] = {
                            student_id: s.student_id,
                            student_name: s.student_name,
                            totalEarned: 0,
                            totalPossible: 0,
                            questionCount: 0,
                            percentage: 0
                        };
                    }

                    const earned = parseFloat(s.grade) || 0;
                    const possible = parseFloat(q.points_possible) || 0;

                    map[s.student_id].totalEarned += earned;
                    map[s.student_id].totalPossible += possible;
                    map[s.student_id].questionCount++;
                });
            });

            // Calculate percentages
            Object.values(map).forEach(student => {
                student.percentage = student.totalPossible > 0
                    ? (student.totalEarned / student.totalPossible) * 100
                    : 0;
            });

            this.allStudents = Object.values(map);
        },

        detectAssignmentType() {
            if (this.questions.length < 2) {
                this.isFileBased = false;
                return;
            }

            for (const q of this.questions) {
                for (const s of q.students || []) {
                    const answers = [];
                    for (const question of this.questions) {
                        const studentInQ = (question.students || []).find(st => st.student_id === s.student_id);
                        if (studentInQ?.student_answer) {
                            answers.push(studentInQ.student_answer);
                        }
                    }

                    if (answers.length >= 2) {
                        this.isFileBased = answers.every(a => a === answers[0]);
                        console.log(`📊 Assignment type: ${this.isFileBased ? 'File-based (AGENT)' : 'Parsable'} (student ${s.student_id})`);
                        console.log(`📊 ✅ isFileBased = ${this.isFileBased}`);
                        return;
                    }
                }
            }

            this.isFileBased = false;
        },

        // =========================================================================
        // COMPUTED PROPERTIES
        // =========================================================================

        get filteredStudents() {
            let filtered = [...this.allStudents];

            // Search filter
            if (this.searchQuery.trim()) {
                const query = this.searchQuery.toLowerCase();
                filtered = filtered.filter(s =>
                    s.student_name.toLowerCase().includes(query)
                );
            }

            // Score filter
            if (this.scoreFilter !== 'all') {
                filtered = filtered.filter(s => {
                    const pct = s.percentage;
                    if (this.scoreFilter === 'high') return pct >= 90;
                    if (this.scoreFilter === 'medium') return pct >= 70 && pct < 90;
                    if (this.scoreFilter === 'low') return pct < 70;
                    return true;
                });
            }

            return filtered;
        },

        get currentStudentResults() {
            if (!this.currentStudent) return [];

            const results = [];
            this.questions.forEach(q => {
                const student = (q.students || []).find(s => s.student_id === this.currentStudent);
                if (student) {
                    results.push({
                        question_id: q.id,
                        question_text: q.text,
                        student_id: student.student_id,
                        student_name: student.student_name,
                        student_answer: student.student_answer,
                        grade: student.grade,
                        max_points: q.points_possible,
                        feedback: student.feedback,
                        edited: student.edited
                    });
                }
            });

            return results;
        },

        get currentQuestionResults() {
            if (!this.currentQuestion?.id) return [];

            const question = this.questions.find(q => q.id === this.currentQuestion.id);
            return question ? (question.students || []) : [];
        },

        // =========================================================================
        // NAVIGATION
        // =========================================================================

        showStudentDetail(studentId) {
            const student = this.allStudents.find(s => s.student_id === studentId);
            if (!student) return;

            this.currentStudent = studentId;
            this.currentStudentName = student.student_name;
            this.currentView = 'detail';
        },

        showQuestionDetail(questionId) {
            const question = this.questions.find(q => q.id === questionId);
            if (!question) return;

            this.currentQuestion = question;
            this.currentView = 'detail';
        },

        backToList() {
            this.currentView = 'list';
            this.currentStudent = null;
            this.currentQuestion = null;
            this.cancelEdit();
        },

        async backToGradingHub() {
            // Simple navigation based on isFileBased detection
            // File-based assignments (same answer for all questions) → agent setup
            // Everything else (parsable assignments, quizzes) → grading hub

            const targetPage = this.isFileBased ? 'assignment_agent_setup.html' : 'grading_hub.html';

            console.log(`🔙 Navigation: isFileBased=${this.isFileBased} → ${targetPage}`);

            await window.api.navigate_to(targetPage);
        },

        async navigateToUpload() {
            await window.api.navigate_to('rubric.html');
        },

        // =========================================================================
        // EDITING
        // =========================================================================

        startEdit(studentId, questionId) {
            // Find the result
            let result = null;

            for (const q of this.questions) {
                if (q.id === questionId) {
                    result = (q.students || []).find(s => s.student_id === studentId);
                    if (result) {
                        result.question_id = q.id;
                        result.question_text = q.text;
                        result.max_points = q.points_possible;
                        break;
                    }
                }
            }

            if (!result) return;

            this.editingKey = `${studentId}-${questionId}`;
            this.editData = {
                student_id: studentId,
                student_name: result.student_name,
                question_id: questionId,
                question_text: result.question_text,
                student_answer: result.student_answer,
                grade: result.grade,
                max_points: result.max_points,
                feedback: result.feedback || ''
            };

            this.$nextTick(() => this.setupAutoResize());
        },

        cancelEdit() {
            this.editingKey = null;
            this.editData = null;
            this.showAiOptions = false;
            this.showCustomInput = false;
        },

        async saveEdit() {
            if (!this.editData) return;

            try {
                Alpine.store('loading').show('Saving grade...');

                let result;
                if (this.contentType === 'quiz') {
                    result = await window.api.quiz_save_grading_results(
                        this.editData.question_id,
                        [{
                            student_id: this.editData.student_id,
                            student_name: this.editData.student_name,
                            question_id: this.editData.question_id,
                            grade: this.editData.grade,
                            feedback: this.editData.feedback,
                            points_earned: this.editData.grade,
                            points_possible: this.editData.max_points
                        }]
                    );
                } else {
                    result = await window.api.assignment_update_single_grade(
                        this.editData.student_id,
                        this.editData.question_id,
                        this.editData.grade,
                        this.editData.feedback
                    );
                }

                if (result.success) {
                    Alpine.store('toast').success('Grade saved successfully');

                    const key = `${this.editData.student_id}-${this.editData.question_id}`;
                    this.editedStudents.add(key);

                    await this.loadData();
                    this.cancelEdit();
                } else {
                    Alpine.store('toast').error('Failed to save: ' + (result.error || 'Unknown error'));
                }
            } catch (error) {
                console.error('Save error:', error);
                Alpine.store('toast').error('Save failed: ' + error.message);
            } finally {
                Alpine.store('loading').hide();
            }
        },

        isEditing(studentId, questionId) {
            return this.editingKey === `${studentId}-${questionId}`;
        },

        // =========================================================================
        // AI REFINEMENT
        // =========================================================================

        toggleAiOptions() {
            this.showAiOptions = !this.showAiOptions;
            if (this.showAiOptions) {
                this.showCustomInput = false;
            }
        },

        async applyPreset(preset) {
            if (!preset.prompt) {
                // Custom option
                this.showCustomInput = true;
                this.showAiOptions = false;
                this.refinementPrompt = '';
            } else {
                // Direct preset
                this.refinementPrompt = preset.prompt;
                this.showAiOptions = false;
                await this.refineWithAi();
            }
        },

        async refineWithAi() {
            if (!this.refinementPrompt?.trim() || !this.editData?.feedback?.trim()) {
                Alpine.store('toast').error('Need both feedback and refinement instructions');
                return;
            }

            try {
                this.refining = true;
                Alpine.store('loading').show('Refining feedback with AI...');

                const result = await window.api.assignment_refine_feedback_with_ai(
                    this.editData.student_id,
                    this.editData.question_id,
                    this.editData.student_answer,
                    this.editData.question_text,
                    this.editData.feedback,
                    this.editData.grade,
                    this.editData.max_points,
                    this.refinementPrompt
                );

                if (result.success && result.new_feedback) {
                    this.editData.feedback = result.new_feedback;
                    Alpine.store('toast').success('Feedback refined!');
                    this.showCustomInput = false;
                    this.refinementPrompt = '';
                } else {
                    Alpine.store('toast').error('Refinement failed: ' + (result.error || 'Unknown error'));
                }
            } catch (error) {
                console.error('Refine error:', error);
                Alpine.store('toast').error('Refinement failed: ' + error.message);
            } finally {
                this.refining = false;
                Alpine.store('loading').hide();
            }
        },

        // =========================================================================
        // ANSWER EXPANSION
        // =========================================================================

        toggleAnswer(studentId, questionId) {
            const key = `${studentId}-${questionId}`;
            if (this.expandedAnswers.has(key)) {
                this.expandedAnswers.delete(key);
            } else {
                this.expandedAnswers.add(key);
            }
            this.expandedAnswers = new Set(this.expandedAnswers);
        },

        isAnswerExpanded(studentId, questionId) {
            return this.expandedAnswers.has(`${studentId}-${questionId}`);
        },

        // =========================================================================
        // MODAL
        // =========================================================================

        openModal(title, content) {
            this.modalTitle = title;
            this.modalContent = content;
            this.modalOpen = true;
        },

        closeModal() {
            this.modalOpen = false;
            setTimeout(() => {
                this.modalTitle = '';
                this.modalContent = '';
            }, 300);
        },

        showFullQuestion(questionText) {
            console.log('🔍 showFullQuestion called with text:', questionText?.substring(0, 50));

            if (!questionText) {
                console.error('❌ No question text provided');
                return;
            }

            const prepared = this.prepareQuestion(questionText);
            console.log('✅ Opening modal...');
            this.openModal('Full Question Text', `<div class="prose">${prepared}</div>`);

            // Verify modal opened
            console.log('📊 Modal state:', { modalOpen: this.modalOpen, hasContent: !!this.modalContent });
        },

        // =========================================================================
        // UTILITIES
        // =========================================================================

        truncate(text, length) {
            if (!text) return '';
            return text.length > length ? text.substring(0, length) + '...' : text;
        },

        prepareQuestion(text) {
            return window.prepareQuestion ? window.prepareQuestion(text) : text;
        },

        prepareAnswer(text) {
            return window.prepareAnswer ? window.prepareAnswer(text) : text;
        },

        getGradeClass(grade, maxPoints) {
            const pct = maxPoints > 0 ? (grade / maxPoints) * 100 : 0;
            if (pct >= 90) return 'grade-high';
            if (pct >= 70) return 'grade-medium';
            return 'grade-low';
        },

        getQuestionStatus(questionId) {
            const question = this.questions.find(q => q.id === questionId);
            if (!question) return { status: 'ungraded', statusText: 'Unknown', totalCount: 0 };

            const students = question.students || [];
            const totalCount = students.length;
            const gradedCount = students.filter(s => parseFloat(s.grade) > 0).length;

            let status = 'ungraded';
            let statusText = 'Ungraded';

            if (gradedCount === totalCount && totalCount > 0) {
                status = 'graded';
                statusText = 'All Graded';
            } else if (gradedCount > 0) {
                status = 'partial';
                statusText = `${gradedCount}/${totalCount} Graded`;
            }

            return { status, statusText, totalCount, gradedCount };
        },

        getStudentSummary(studentId) {
            const student = this.allStudents.find(s => s.student_id === studentId);
            if (!student) return 'No data';

            const pct = Math.round(student.percentage);
            return `${student.totalEarned.toFixed(1)}/${student.totalPossible} (${pct}%) - ${student.questionCount} questions`;
        },

        async exportCSV() {
            try {
                Alpine.store('loading').show('Exporting CSV...');

                let result;
                if (this.contentType === 'quiz') {
                    result = await window.api.quiz_export_grades();
                } else {
                    result = await window.api.assignment_export_grades();
                }

                if (result.success) {
                    Alpine.store('toast').success('CSV exported successfully');
                } else {
                    Alpine.store('toast').error('Export failed: ' + result.error);
                }
            } catch (error) {
                Alpine.store('toast').error('Export failed: ' + error.message);
            } finally {
                Alpine.store('loading').hide();
            }
        },

        setupAutoResize() {
            const textareas = this.$el.querySelectorAll('.auto-resize-textarea');
            textareas.forEach(textarea => {
                const resize = () => {
                    textarea.style.height = 'auto';
                    textarea.style.height = Math.max(textarea.scrollHeight, 120) + 'px';
                };

                setTimeout(resize, 0);
                textarea.addEventListener('input', resize);
                textarea.addEventListener('focus', resize);
            });
        }
    }));

    console.log('✅ Grade Review V2 component registered');
});
