// system_health.js - System Health Page (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('systemHealthPage', () => ({
        // State
        systemInfo: {
            appVersion: 'Loading...',
            pythonVersion: 'Loading...',
            platform: 'Loading...'
        },
        healthResults: null,
        healthChecking: false,
        healthAllOk: false,
        testConnections: false,
        interruptedTasks: [],
        findingTasks: false,
        tasksSearched: false,

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadSystemInfo();
        },

        // Load system information
        async loadSystemInfo() {
            try {
                const result = await window.api.get_system_info();

                if (result.success) {
                    this.systemInfo.appVersion = result.app_version || 'Unknown';
                    this.systemInfo.pythonVersion = result.python_version || 'Unknown';
                    this.systemInfo.platform = result.platform || 'Unknown';
                }
            } catch (error) {
                console.error('Error loading system info:', error);
            }
        },

        // Run health check
        async runHealthCheck() {
            this.healthChecking = true;
            this.healthResults = null;

            try {
                const result = await window.api.health_check(this.testConnections);

                if (result.success) {
                    this.healthResults = result.checks || [];
                    this.healthAllOk = result.all_ok || false;
                } else {
                    this.healthResults = [{
                        component: 'Error',
                        status: 'error',
                        message: result.error
                    }];
                    this.healthAllOk = false;
                }
            } catch (error) {
                this.healthResults = [{
                    component: 'Error',
                    status: 'error',
                    message: error.message
                }];
                this.healthAllOk = false;
            }

            this.healthChecking = false;
        },


        // Get status icon
        getStatusIcon(status) {
            const icons = {
                ok: 'ph-check-circle',
                warning: 'ph-warning',
                error: 'ph-x-circle'
            };
            return icons[status] || 'ph-info';
        },

        // Get status color
        getStatusColor(status) {
            const colors = {
                ok: 'var(--color-success)',
                warning: 'var(--color-warning)',
                error: 'var(--color-danger)'
            };
            return colors[status] || 'var(--text-secondary)';
        },

        // Find interrupted tasks
        async findInterruptedTasks() {
            this.findingTasks = true;
            this.interruptedTasks = [];

            try {
                const result = await window.api.get_interrupted_tasks();

                if (result.success) {
                    this.interruptedTasks = result.tasks || [];
                    this.tasksSearched = true;

                    console.log(`Found ${result.count} interrupted tasks`);
                } else {
                    alert('Error finding interrupted tasks: ' + (result.error || 'Unknown error'));
                }
            } catch (error) {
                console.error('Error finding interrupted tasks:', error);
                alert('Error finding interrupted tasks: ' + error.message);
            }

            this.findingTasks = false;
        },

        // Format timestamp
        formatDate(timestamp) {
            if (!timestamp) return 'Unknown';
            const date = new Date(timestamp * 1000); // Convert from Unix timestamp
            return date.toLocaleString();
        },

        // Get type badge color
        getTypeColor(type) {
            return type === 'quiz' ? 'var(--color-primary)' : 'var(--color-success)';
        }
    }));
});
