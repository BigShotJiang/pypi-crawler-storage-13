// profiles.js - Profile Management (Alpine.js - Properly Refactored)

document.addEventListener('alpine:init', () => {
    Alpine.data('profilesPage', () => ({
        // State
        canvasProfiles: [],
        llmProfiles: [],
        activeCanvasId: null,
        activeLLMId: null,
        loading: true,

        // Modal state
        showCanvasModal: false,
        showLLMModal: false,
        editingCanvasId: null,
        editingLLMId: null,

        // Form data - bound with x-model
        canvasForm: {
            name: '',
            canvas_address: '',
            token: '',
            email: ''
        },
        llmForm: {
            name: '',
            api_link: '',
            model_name: '',
            token: '',
            llm_type: 'remote'
        },

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadProfiles();
        },

        // Load all profiles
        async loadProfiles() {
            this.loading = true;

            try {
                // Load Canvas profiles
                const canvasResult = await window.api.profile_get_all_canvas();
                if (canvasResult.success) {
                    this.canvasProfiles = canvasResult.profiles || [];
                    this.activeCanvasId = canvasResult.active_id;
                }

                // Load LLM profiles
                const llmResult = await window.api.profile_get_all_llm();
                if (llmResult.success) {
                    this.llmProfiles = llmResult.profiles || [];
                    this.activeLLMId = llmResult.active_id;
                }
            } catch (error) {
                console.error('Error loading profiles:', error);
                Alpine.store('toast').error('Failed to load profiles');
            }

            this.loading = false;
        },

        // ===== CANVAS PROFILE ACTIONS =====

        openAddCanvasModal() {
            this.editingCanvasId = null;
            this.canvasForm = {
                name: '',
                canvas_address: '',
                token: '',
                email: ''
            };
            this.showCanvasModal = true;
        },

        openEditCanvasModal(profileId) {
            const profile = this.canvasProfiles.find(p => p.id === profileId);
            if (!profile) return;

            this.editingCanvasId = profileId;
            this.canvasForm = {
                name: profile.name,
                canvas_address: profile.canvas_address,
                token: profile.token || '',
                email: profile.email || ''
            };
            this.showCanvasModal = true;
        },

        closeCanvasModal() {
            this.showCanvasModal = false;
            this.editingCanvasId = null;
        },

        async saveCanvasProfile() {
            try {
                Alpine.store('loading').show('Saving profile...');

                let result;
                if (this.editingCanvasId) {
                    result = await window.api.profile_update_canvas(
                        this.editingCanvasId,
                        this.canvasForm.name,
                        this.canvasForm.canvas_address,
                        this.canvasForm.token,
                        this.canvasForm.email
                    );
                } else {
                    result = await window.api.profile_create_canvas(
                        this.canvasForm.name,
                        this.canvasForm.canvas_address,
                        this.canvasForm.token,
                        this.canvasForm.email
                    );
                }

                if (result.success) {
                    Alpine.store('toast').success(this.editingCanvasId ? 'Profile updated' : 'Profile created');
                    this.closeCanvasModal();
                    await this.loadProfiles();
                } else {
                    Alpine.store('toast').error(result.error || 'Failed to save profile');
                }
            } catch (error) {
                console.error('Error saving profile:', error);
                Alpine.store('toast').error('Error saving profile');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        async activateCanvasProfile(profileId) {
            try {
                Alpine.store('loading').show('Switching profile...');
                const result = await window.api.profile_switch_canvas(profileId);

                if (result.success) {
                    Alpine.store('toast').success('Canvas profile activated');
                    this.activeCanvasId = profileId;
                    Alpine.store('activeProfiles').update();
                } else {
                    Alpine.store('toast').error(result.error || 'Failed to activate profile');
                }
            } catch (error) {
                Alpine.store('toast').error('Error activating profile');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        async testCanvasProfile(profileId) {
            try {
                Alpine.store('loading').show('Testing connection...');

                const currentActiveId = this.activeCanvasId;
                await window.api.profile_switch_canvas(profileId);

                const result = await window.api.connection_test_canvas();

                if (profileId !== currentActiveId && currentActiveId) {
                    await window.api.profile_switch_canvas(currentActiveId);
                }

                if (result.success) {
                    Alpine.store('toast').success('Canvas connection successful!');
                } else {
                    Alpine.store('toast').error('Canvas connection failed');
                }
            } catch (error) {
                Alpine.store('toast').error('Error testing connection');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        async deleteCanvasProfile(profileId) {
            if (!confirm('Are you sure you want to delete this profile?')) return;

            try {
                Alpine.store('loading').show('Deleting profile...');

                const result = await window.api.profile_delete_canvas(profileId);

                if (result.success) {
                    Alpine.store('toast').success('Profile deleted');
                    await this.loadProfiles();
                } else {
                    Alpine.store('toast').error(result.error || 'Failed to delete profile');
                }
            } catch (error) {
                Alpine.store('toast').error('Error deleting profile');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // ===== LLM PROFILE ACTIONS =====

        openAddLLMModal() {
            this.editingLLMId = null;
            this.llmForm = {
                name: '',
                api_link: '',
                model_name: '',
                token: '',
                llm_type: 'remote'
            };
            this.showLLMModal = true;
        },

        openEditLLMModal(profileId) {
            const profile = this.llmProfiles.find(p => p.id === profileId);
            if (!profile) return;

            this.editingLLMId = profileId;
            this.llmForm = {
                name: profile.name,
                api_link: profile.api_link,
                model_name: profile.model_name,
                token: profile.token || '',
                llm_type: profile.type || 'remote'
            };
            this.showLLMModal = true;
        },

        closeLLMModal() {
            this.showLLMModal = false;
            this.editingLLMId = null;
        },

        async saveLLMProfile() {
            try {
                Alpine.store('loading').show('Saving profile...');

                let result;
                if (this.editingLLMId) {
                    result = await window.api.profile_update_llm(
                        this.editingLLMId,
                        this.llmForm.name,
                        this.llmForm.api_link,
                        this.llmForm.model_name,
                        this.llmForm.token,
                        this.llmForm.llm_type
                    );
                } else {
                    result = await window.api.profile_create_llm(
                        this.llmForm.name,
                        this.llmForm.api_link,
                        this.llmForm.model_name,
                        this.llmForm.token,
                        this.llmForm.llm_type
                    );
                }

                if (result.success) {
                    Alpine.store('toast').success(this.editingLLMId ? 'Profile updated' : 'Profile created');
                    this.closeLLMModal();
                    await this.loadProfiles();
                } else {
                    Alpine.store('toast').error(result.error || 'Failed to save profile');
                }
            } catch (error) {
                console.error('Error saving profile:', error);
                Alpine.store('toast').error('Error saving profile');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        async activateLLMProfile(profileId) {
            try {
                Alpine.store('loading').show('Switching profile...');
                const result = await window.api.profile_switch_llm(profileId);

                if (result.success) {
                    Alpine.store('toast').success('LLM profile activated');
                    this.activeLLMId = profileId;
                    Alpine.store('activeProfiles').update();
                } else {
                    Alpine.store('toast').error(result.error || 'Failed to activate profile');
                }
            } catch (error) {
                Alpine.store('toast').error('Error activating profile');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        async testLLMProfile(profileId) {
            try {
                Alpine.store('loading').show('Testing connection...');

                const currentActiveId = this.activeLLMId;
                await window.api.profile_switch_llm(profileId);

                const result = await window.api.connection_test_llm();

                if (profileId !== currentActiveId && currentActiveId) {
                    await window.api.profile_switch_llm(currentActiveId);
                }

                if (result.success) {
                    Alpine.store('toast').success('LLM connection successful!');
                } else {
                    Alpine.store('toast').error('LLM connection failed');
                }
            } catch (error) {
                Alpine.store('toast').error('Error testing connection');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        async deleteLLMProfile(profileId) {
            if (!confirm('Are you sure you want to delete this profile?')) return;

            try {
                Alpine.store('loading').show('Deleting profile...');

                const result = await window.api.profile_delete_llm(profileId);

                if (result.success) {
                    Alpine.store('toast').success('Profile deleted');
                    await this.loadProfiles();
                } else {
                    Alpine.store('toast').error(result.error || 'Failed to delete profile');
                }
            } catch (error) {
                Alpine.store('toast').error('Error deleting profile');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Helper methods
        isCanvasActive(profileId) {
            return this.activeCanvasId === profileId;
        },

        isLLMActive(profileId) {
            return this.activeLLMId === profileId;
        },

        getCanvasDetails(profile) {
            return profile.email || profile.canvas_address;
        },

        getLLMDetails(profile) {
            return profile.model_name;
        },

        formatDate(timestamp) {
            return new Date(timestamp || Date.now()).toLocaleDateString();
        },

        formatRelativeTime(timestamp) {
            if (!timestamp) return 'Never';
            const date = new Date(timestamp);
            const now = new Date();
            const diff = now - date;
            const seconds = Math.floor(diff / 1000);
            const minutes = Math.floor(seconds / 60);
            const hours = Math.floor(minutes / 60);
            const days = Math.floor(hours / 24);

            if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
            if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
            if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
            return 'Just now';
        }
    }));

    console.log('✅ Profiles component registered');
});
