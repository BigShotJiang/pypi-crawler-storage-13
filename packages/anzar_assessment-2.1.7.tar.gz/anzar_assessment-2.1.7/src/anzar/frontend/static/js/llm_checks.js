/**
 * LLM Pre-flight Connectivity Checks
 *
 * Provides shared helper functions to verify LLM connectivity
 * before starting grading or consistency check operations.
 */

/**
 * Check LLM connection before proceeding with grading operations.
 *
 * Shows a loading indicator while checking, displays error toast if connection fails,
 * and returns success/failure status for the caller to decide whether to proceed.
 *
 * @returns {Promise<boolean>} true if LLM is reachable, false otherwise
 */
async function checkLLMConnectionBeforeGrading() {
    try {
        // Show loading indicator
        Alpine.store('loading').show('Verifying LLM connectivity...');

        // Test LLM connection using existing API
        const result = await window.api.connection_test_llm();

        // Hide loading indicator
        Alpine.store('loading').hide();

        // Check if connection was successful
        if (!result.success) {
            // Display user-friendly error message
            const errorMsg = result.error || result.message || 'LLM connection failed';
            Alpine.store('toast').error(
                `Cannot start grading: LLM is not reachable. ${errorMsg}. ` +
                'Please check your LLM profile settings and try again.'
            );
            console.error('LLM pre-flight check failed:', result);
            return false;
        }

        // Connection successful
        console.log('LLM pre-flight check passed:', result);
        return true;

    } catch (error) {
        // Hide loading indicator on exception
        Alpine.store('loading').hide();

        // Display error to user
        Alpine.store('toast').error(
            'Failed to verify LLM connection: ' + error.message + '. ' +
            'Please check your network and LLM settings.'
        );
        console.error('LLM pre-flight check exception:', error);
        return false;
    }
}

/**
 * Check LLM connection before consistency testing.
 * Alias for checkLLMConnectionBeforeGrading() for clarity in consistency check contexts.
 *
 * @returns {Promise<boolean>} true if LLM is reachable, false otherwise
 */
async function checkLLMConnectionBeforeConsistency() {
    return await checkLLMConnectionBeforeGrading();
}
