// quiz_grading_progress.js - Dedicated grading progress page (Alpine.js)

// Global singleton state to prevent multiple instances
let gradingProgressInstance = null;
let isGradingInProgress = false;

document.addEventListener('alpine:init', () => {
    Alpine.data('quizGradingProgress', () => ({
        // State
        questionId: null,
        questionText: '',
        isGrading: true,
        gradingComplete: false,
        canStop: true,
        completionMessage: 'Grading Complete!',
        isRegrade: false,
        regradeMode: 'ungraded',
        gradeOnlyUngraded: true,

        // Progress tracking
        gradingProgress: {
            done: 0,
            total: 0,
            percent: 0,
            currentStudent: '',
            failed: 0
        },

        // Results
        liveResults: [],
        autoScroll: true,

        // Init
        async init() {
            // Singleton protection - prevent multiple instances
            if (gradingProgressInstance) {
                console.warn('⚠️ Quiz Grading Progress instance already exists, skipping initialization');
                return;
            }

            gradingProgressInstance = this;
            console.log('🔍 [JS] Quiz Grading Progress: Initializing (singleton)');

            // Ensure liveResults is initialized as array
            if (!Array.isArray(this.liveResults)) {
                this.liveResults = [];
            }

            // Load grading context from Alpine store
            this.loadGradingContext();

            // Register global progress update functions for backend to call
            this.registerProgressHandlers();

            // Wait for API to be ready, then auto-start grading
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.startGrading();
                });
            } else if (window.api) {
                await this.startGrading();
            } else {
                console.error('⚠️ API utilities not loaded');
                this.showError('API not available');
            }
        },

        // Load grading context from store
        loadGradingContext() {
            try {
                console.log('📥 [progress] Loading grading context from Alpine store...');
                const gradingState = Alpine.store('gradingState');

                const criteria = gradingState.get('gradingCriteria');
                const questionId = gradingState.get('gradingQuestionId');
                const questionData = gradingState.get('questionData');
                const gradeOnlyUngraded = gradingState.get('gradeOnlyUngraded');

                console.log('📥 [progress] Retrieved data:', {
                    hasCriteria: !!criteria,
                    criteriaKeys: criteria ? Object.keys(criteria) : null,
                    hasQuestionId: !!questionId,
                    hasQuestionData: !!questionData,
                    hasGradeOnlyUngraded: gradeOnlyUngraded !== undefined,
                    questionDataKeys: questionData ? Object.keys(questionData) : null
                });

                // Validate required data
                if (!criteria) {
                    console.error('❌ [progress] Missing grading criteria');
                    Alpine.store('toast').error('Missing grading criteria. Please set grading criteria first.');
                    setTimeout(() => {
                        window.api.navigate_to('grading_hub.html');
                    }, 3000);
                    return;
                }

                if (!questionId) {
                    console.error('❌ [progress] Missing question ID');
                    Alpine.store('toast').error('Missing question ID. Please select a question first.');
                    setTimeout(() => {
                        window.api.navigate_to('grading_hub.html');
                    }, 3000);
                    return;
                }

                // Validate question ID consistency between different data sources
                if (questionData && questionData.questionId && questionData.questionId !== questionId) {
                    console.error('❌ [progress] Question ID mismatch detected:', {
                        gradingQuestionId: questionId,
                        questionDataId: questionData.questionId
                    });
                    Alpine.store('toast').error('Question data inconsistency detected. Please restart the grading process.');
                    setTimeout(() => {
                        window.api.navigate_to('grading_hub.html');
                    }, 3000);
                    return;
                }

                // Clear any existing live results that might be from previous questions
                if (this.liveResults && this.liveResults.length > 0) {
                    const hasResultsFromOtherQuestions = this.liveResults.some(result =>
                        result.questionId && result.questionId !== questionId
                    );
                    if (hasResultsFromOtherQuestions) {
                        console.log('🧹 [progress] Clearing results from previous questions');
                        this.liveResults = [];
                    }
                }

                // Set component data
                this.questionId = questionId;
                this.questionText = questionData?.questionText || `Question ${questionId}`;
                this.criteria = criteria;
                this.isRegrade = questionData?.isRegrade || false;
                this.regradeMode = questionData?.regradeMode || 'ungraded';
                this.gradeOnlyUngraded = gradeOnlyUngraded !== undefined ? gradeOnlyUngraded : (!this.isRegrade || this.regradeMode === 'ungraded');

                // Validate criteria has required fields
                const requiredFields = ['correct_answer', 'grading_rubric'];
                const missingFields = requiredFields.filter(field => !criteria[field] || criteria[field].trim() === '');

                if (missingFields.length > 0) {
                    console.warn('⚠️ [progress] Missing required criteria fields:', missingFields);
                    Alpine.store('toast').warning(`Missing required criteria fields: ${missingFields.join(', ')}. Grading may not work properly.`);
                }

                console.log('✅ [progress] Successfully loaded grading context:', {
                    questionId: this.questionId,
                    questionTextLength: this.questionText.length,
                    criteriaFields: Object.keys(criteria),
                    isRegrade: this.isRegrade,
                    regradeMode: this.regradeMode,
                    gradeOnlyUngraded: this.gradeOnlyUngraded,
                    pointsPossible: questionData?.pointsPossible
                });
            } catch (error) {
                console.error('❌ [progress] Error loading grading context:', error);
                Alpine.store('toast').error('Failed to load grading context. Please try again.');
                setTimeout(() => {
                    window.api.navigate_to('grading_hub.html');
                }, 3000);
            }
        },

        // Register global progress handlers for backend
        registerProgressHandlers() {
            const self = this;

            // Force cleanup of any existing handlers to prevent contamination
            if (window.updateProgress) {
                console.warn('⚠️ Cleaning up old updateProgress handler to prevent contamination');
                delete window.updateProgress;
                delete window.finishProgress;
            }

            // Global function called by backend via window.evaluate_js()
            window.updateProgress = function(update) {
                console.log('📊 Progress update received:', update);

                // Validate that this progress update is for the current question
                // This prevents processing updates from previous questions that might still be running
                if (self.questionId && update.questionId && update.questionId !== self.questionId) {
                    console.warn('⚠️ [progress] Ignoring progress update for different question:', {
                        currentQuestionId: self.questionId,
                        updateQuestionId: update.questionId
                    });
                    return;
                }

                // Update progress stats
                self.gradingProgress = {
                    done: update.done || 0,
                    total: update.total || 0,
                    percent: update.percent || 0,
                    currentStudent: update.sub || '',
                    failed: update.failed || 0
                };

                // Add to live results with additional validation
                if (update.sub && update.score !== undefined) {
                    // Ensure liveResults is an array before pushing
                    if (!Array.isArray(self.liveResults)) {
                        self.liveResults = [];
                    }

                    // Create truly unique ID using timestamp and random number
                    const uniqueId = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

                    const newResult = {
                        studentId: uniqueId,
                        studentName: update.sub,
                        score: update.score,
                        feedback: update.feedback || '',
                        timestamp: new Date().toLocaleTimeString(),
                        success: true,
                        questionId: self.questionId // Track which question this result belongs to
                    };

                    console.log(`📝 Adding result for student: ${update.sub}, score: ${update.score}, total graded: ${update.done}/${update.total}, question: ${self.questionId}`);

                    // Check for potential duplicate results from previous questions
                    const isDuplicateFromDifferentQuestion = self.liveResults.some(existing =>
                        existing.studentName === update.sub &&
                        existing.questionId !== self.questionId
                    );

                    if (isDuplicateFromDifferentQuestion) {
                        console.warn('⚠️ [progress] Detected potential duplicate from different question, filtering results');
                        // Filter out results from different questions to prevent confusion
                        self.liveResults = self.liveResults.filter(result =>
                            !result.questionId || result.questionId === self.questionId
                        );
                    }

                    self.liveResults = [...self.liveResults, newResult];

                    // Log current results count for debugging
                    console.log(`📊 Current liveResults count: ${self.liveResults.length}`);

                    // Auto-scroll to bottom if enabled
                    if (self.autoScroll) {
                        self.$nextTick(() => {
                            const feed = document.getElementById('results-feed');
                            if (feed) {
                                const body = feed.querySelector('.results-feed-body');
                                if (body) {
                                    body.scrollTop = body.scrollHeight;
                                }
                            }
                        });
                    }
                }
            };

            // Global function called when grading finishes
            window.finishProgress = function() {
                console.log('✅ Grading finished');
                self.isGrading = false;
                self.gradingComplete = true;
                self.canStop = false;
                self.completionMessage = 'Grading Complete!';
            };

            console.log('✅ Progress handlers registered');
        },

        // Start grading task
        async startGrading() {
            console.log('🚀 Starting grading task...');

            // Check if grading is already in progress
            if (isGradingInProgress) {
                console.warn('⚠️ Grading already in progress, skipping start');
                return;
            }

            try {
                // Set grading lock
                isGradingInProgress = true;

                // Get content type to determine grading mode
                const state = await window.api.get_state();

                // Use the gradeOnlyUngraded flag passed from grade_input (with fallback)
                let gradeOnlyUngraded = this.gradeOnlyUngraded;
                if (gradeOnlyUngraded === undefined) {
                    // Fallback logic if not explicitly set
                    gradeOnlyUngraded = true;
                    if (this.isRegrade && this.regradeMode === 'all') {
                        gradeOnlyUngraded = false; // Regrade everyone
                    }
                }

                console.log(`🎯 [progress] Grading mode: ${this.isRegrade ? 'REGRADE' : 'GRADE'}, Only ungraded: ${gradeOnlyUngraded}, Mode: ${this.regradeMode}`);
                console.log('📊 [progress] Starting grading with data:', {
                    questionId: this.questionId,
                    criteriaFields: Object.keys(this.criteria || {}),
                    hasCriteria: !!this.criteria,
                    gradeOnlyUngraded: gradeOnlyUngraded
                });

                // Start grading (synchronous call with real-time updates)
                const response = await window.api.grading_start_task(
                    this.questionId,
                    this.criteria,
                    gradeOnlyUngraded
                );

                console.log('Grading task completed:', response);

                // Release grading lock
                isGradingInProgress = false;

                // Mark as complete
                this.isGrading = false;
                this.gradingComplete = true;
                this.canStop = false;

                if (response.success) {
                    this.completionMessage = `Successfully graded ${response.completed} out of ${response.total} submissions!`;
                    if (response.cancelled) {
                        this.completionMessage = `Grading stopped. ${response.completed} out of ${response.total} submissions graded.`;
                    }
                } else {
                    this.completionMessage = 'Grading completed with errors';
                    Alpine.store('toast').error(response.error || 'Grading failed');
                }

            } catch (error) {
                console.error('❌ Error during grading:', error);
                // Release grading lock on error
                isGradingInProgress = false;
                this.isGrading = false;
                this.gradingComplete = true;
                this.canStop = false;
                this.completionMessage = 'Grading failed';
                Alpine.store('toast').error('Grading failed: ' + error.message);
            }
        },

        // Stop grading
        async stopGrading() {
            if (!confirm('Are you sure you want to stop grading? Progress will be saved.')) {
                return;
            }

            console.log('⏹️ Stopping grading...');

            try {
                this.canStop = false;
                const response = await window.api.grading_cancel_task();

                if (response.success) {
                    Alpine.store('toast').info('Grading stopped. Progress has been saved.');
                    this.completionMessage = 'Grading Stopped';
                    this.isGrading = false;
                    this.gradingComplete = true;
                } else {
                    console.error('Failed to cancel:', response);
                    Alpine.store('toast').error('Failed to stop grading');
                    this.canStop = true; // Re-enable button
                }
            } catch (error) {
                console.error('Error stopping grading:', error);
                Alpine.store('toast').error('Error stopping grading');
                this.canStop = true; // Re-enable button
            }
        },

        // Navigate to review grades
        async reviewGrades() {
            await window.api.navigate_to('grade_review_v2.html');
        },

        // Back to grading hub
        async backToHub() {
            await window.api.navigate_to('grading_hub.html');
        },

        // Show error
        showError(message) {
            // Release grading lock on error
            isGradingInProgress = false;
            this.isGrading = false;
            this.gradingComplete = true;
            this.completionMessage = message;
            Alpine.store('toast').error(message);
        },

        // Cleanup when component is destroyed
        destroy() {
            console.log('🧹 Cleaning up Quiz Grading Progress component');
            // Release grading lock
            isGradingInProgress = false;
            // Clear global functions
            if (window.updateProgress === this.updateProgressHandler) {
                delete window.updateProgress;
            }
            if (window.finishProgress === this.finishProgressHandler) {
                delete window.finishProgress;
            }
            // Clear singleton reference
            gradingProgressInstance = null;
        }
    }));
});

console.log('✅ Quiz Grading Progress component loaded');
