// gui_helpers.js - Common GUI helper functions (Alpine.js)

document.addEventListener('alpine:init', () => {
    // Progress Tracker Store
    Alpine.store('progressTracker', {
        currentProgress: null,

        async update() {
            try {
                const result = await window.api.progress_get_summary();

                if (result.success && result.summary.exists) {
                    this.currentProgress = result.summary;
                }
            } catch (error) {
                console.error('Error updating progress:', error);
            }
        },

        async startSession() {
            try {
                const result = await window.api.progress_start_session();
                if (result.success) {
                    console.log('Progress session started');
                    await this.update();
                }
            } catch (error) {
                console.error('Error starting progress session:', error);
            }
        },

        async updateStep(step, completed = true) {
            try {
                const result = await window.api.progress_update_step(step, completed);
                if (result.success) {
                    await this.update();
                }
            } catch (error) {
                console.error('Error updating progress step:', error);
            }
        },

        async completeSession() {
            try {
                const result = await window.api.progress_complete_session();
                if (result.success) {
                    console.log('Progress session completed');
                }
            } catch (error) {
                console.error('Error completing progress session:', error);
            }
        }
    });

    // Breadcrumb component
    Alpine.data('breadcrumbNav', () => ({
        breadcrumbs: [],

        async update(currentPage) {
            try {
                const result = await window.api.get_breadcrumbs(currentPage);

                if (result.success) {
                    this.breadcrumbs = result.breadcrumbs || [];
                }
            } catch (error) {
                console.error('Error updating breadcrumbs:', error);
            }
        },

        async navigate(page) {
            try {
                const check = await window.api.check_navigation(page);

                if (check.success && check.allowed) {
                    await window.api.navigate_to(page);
                } else {
                    alert(`Cannot navigate: ${check.reason}`);
                }
            } catch (error) {
                console.error('Navigation error:', error);
            }
        }
    }));

    // Recent Sessions component
    Alpine.data('recentSessions', () => ({
        sessions: [],

        async load(limit = 5) {
            try {
                const result = await window.api.progress_get_recent(limit);

                if (result.success) {
                    this.sessions = result.sessions || [];
                }
            } catch (error) {
                console.error('Error loading recent sessions:', error);
            }
        },

        async resumeSession(courseId, contentId, contentType) {
            console.log('Resume session:', { courseId, contentId, contentType });
            // Navigate to the appropriate page based on the session progress
        },

        formatDate(timestamp) {
            return new Date(timestamp).toLocaleDateString();
        },

        getStatusClass(status) {
            return status === 'completed' ? 'success' : 'warning';
        },

        getStatusText(status) {
            return status === 'completed' ? 'Completed' : 'In Progress';
        }
    }));
});

// Backward compatibility - Keep legacy class structure for unconverted pages
class SearchFilter {
    constructor(inputId, itemsContainerId, searchFunction, renderFunction) {
        this.searchInput = document.getElementById(inputId);
        this.itemsContainer = document.getElementById(itemsContainerId);
        this.searchFunction = searchFunction;
        this.renderFunction = renderFunction;
        this.debounceTimer = null;

        if (this.searchInput) {
            this.setupSearch();
        }
    }

    setupSearch() {
        this.searchInput.addEventListener('input', (e) => {
            clearTimeout(this.debounceTimer);
            const query = e.target.value;

            this.showLoading();

            this.debounceTimer = setTimeout(async () => {
                await this.performSearch(query);
            }, 300);
        });

        const clearBtn = this.searchInput.parentElement.querySelector('.search-clear');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                this.searchInput.value = '';
                this.searchInput.dispatchEvent(new Event('input'));
            });
        }
    }

    showLoading() {
        if (this.itemsContainer) {
            this.itemsContainer.style.opacity = '0.6';
        }
    }

    hideLoading() {
        if (this.itemsContainer) {
            this.itemsContainer.style.opacity = '1';
        }
    }

    async performSearch(query) {
        try {
            const result = await this.searchFunction(query);

            if (result.success) {
                this.renderFunction(result);
                this.updateResultsCount(result.total);
            } else {
                console.error('Search failed:', result.error);
            }
        } catch (error) {
            console.error('Search error:', error);
        } finally {
            this.hideLoading();
        }
    }

    updateResultsCount(count) {
        const countEl = document.querySelector('.search-results-count');
        if (countEl) {
            countEl.textContent = `${count} result${count !== 1 ? 's' : ''} found`;
        }
    }
}

class ProgressTracker {
    constructor() {
        this.progressBar = null;
        this.progressText = null;
        this.breadcrumbs = null;
    }

    async updateProgress() {
        return Alpine.store('progressTracker').update();
    }

    async startSession() {
        return Alpine.store('progressTracker').startSession();
    }

    async updateStep(step, completed = true) {
        return Alpine.store('progressTracker').updateStep(step, completed);
    }

    async completeSession() {
        return Alpine.store('progressTracker').completeSession();
    }
}

class BreadcrumbNav {
    constructor() {
        this.container = document.getElementById('breadcrumb-nav');
    }

    async update(currentPage) {
        // Legacy compatibility - does nothing, breadcrumbs handled in templates
        console.log('BreadcrumbNav.update called (legacy)');
    }
}

class RecentSessions {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
    }

    async load(limit = 5) {
        // Legacy compatibility - render using vanilla DOM if needed
        try {
            const result = await window.api.progress_get_recent(limit);

            if (result.success) {
                this.render(result.sessions || []);
            }
        } catch (error) {
            console.error('Error loading recent sessions:', error);
        }
    }

    render(sessions) {
        if (!this.container || sessions.length === 0) {
            if (this.container) {
                this.container.innerHTML = '<p class="text-muted">No recent grading sessions</p>';
            }
            return;
        }

        const html = sessions.map(session => {
            const date = new Date(session.last_updated).toLocaleDateString();
            const statusClass = session.status === 'completed' ? 'success' : 'warning';
            const statusText = session.status === 'completed' ? 'Completed' : 'In Progress';

            return `
                <div class="recent-session-item">
                    <div class="session-header">
                        <h5>${session.content_name}</h5>
                        <span class="badge badge-${statusClass}">${statusText}</span>
                    </div>
                    <p class="text-muted">${session.course_name}</p>
                    <p class="text-muted">Last updated: ${date}</p>
                    ${session.grading_details ? `
                        <p class="session-progress">
                            Graded: ${session.grading_details.graded_questions}/${session.grading_details.total_questions} questions
                        </p>
                    ` : ''}
                    <button class="btn btn-sm btn-secondary resume-session"
                            data-course-id="${session.course_id}"
                            data-content-id="${session.content_id}"
                            data-content-type="${session.content_type}">
                        Resume
                    </button>
                </div>
            `;
        }).join('');

        this.container.innerHTML = html;

        this.container.querySelectorAll('.resume-session').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const courseId = parseInt(e.target.dataset.courseId);
                const contentId = parseInt(e.target.dataset.contentId);
                const contentType = e.target.dataset.contentType;

                console.log('Resume session:', { courseId, contentId, contentType });
            });
        });
    }
}

// Export for backward compatibility
window.GuiHelpers = {
    SearchFilter,
    ProgressTracker,
    BreadcrumbNav,
    RecentSessions
};

console.log('✅ GUI helpers loaded (Alpine + backward compatibility)');
