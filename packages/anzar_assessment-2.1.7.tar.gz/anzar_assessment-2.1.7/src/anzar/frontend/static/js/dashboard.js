// dashboard.js - Dashboard Page (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('dashboardPage', () => ({
        // State
        stats: {
            courses: 0,
            quizzes: 0,
            assignments: 0,
            gradedQuestions: 0
        },
        gradingSessions: [],
        profiles: {
            canvas: null,
            llm: null
        },
        loading: true,

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadDashboardData();
            await this.loadActiveProfiles();
            this.loading = false;
        },

        // Load all dashboard data
        async loadDashboardData() {
            try {
                // Get filesystem statistics
                const stats = await window.api.dashboard_get_stats();
                if (stats.success) {
                    // Animate stats update
                    this.animateStats(stats);
                }

                // Get recent grading sessions
                const sessions = await window.api.progress_get_recent(5);
                if (sessions.success) {
                    this.gradingSessions = sessions.sessions || [];
                }
            } catch (error) {
                console.error('Error loading dashboard data:', error);
            }
        },

        // Animate stats counting up
        animateStats(newStats) {
            const duration = 1000;
            const startTime = Date.now();

            const startValues = { ...this.stats };
            const endValues = {
                courses: newStats.totalCourses || 0,
                quizzes: newStats.totalQuizzes || 0,
                assignments: newStats.totalAssignments || 0,
                gradedQuestions: newStats.gradedQuestions || 0
            };

            const animate = () => {
                const elapsed = Date.now() - startTime;
                const progress = Math.min(elapsed / duration, 1);

                // Easing function (ease-out)
                const eased = 1 - Math.pow(1 - progress, 3);

                this.stats.courses = Math.round(startValues.courses + (endValues.courses - startValues.courses) * eased);
                this.stats.quizzes = Math.round(startValues.quizzes + (endValues.quizzes - startValues.quizzes) * eased);
                this.stats.assignments = Math.round(startValues.assignments + (endValues.assignments - startValues.assignments) * eased);
                this.stats.gradedQuestions = Math.round(startValues.gradedQuestions + (endValues.gradedQuestions - startValues.gradedQuestions) * eased);

                if (progress < 1) {
                    requestAnimationFrame(animate);
                }
            };

            requestAnimationFrame(animate);
        },

        // Load active profiles
        async loadActiveProfiles() {
            try {
                const result = await window.api.profile_get_active();
                if (result.success) {
                    this.profiles.canvas = result.profiles.canvas || null;
                    this.profiles.llm = result.profiles.llm || null;
                }
            } catch (error) {
                console.error('Error loading profiles:', error);
            }
        },

        // Check if profile selection is needed
        async checkNeedProfileSelection() {
            try {
                const canvasResult = await window.api.profile_get_all_canvas();
                const llmResult = await window.api.profile_get_all_llm();

                if (canvasResult.success && llmResult.success) {
                    const noCanvasProfiles = canvasResult.profiles.length === 0;
                    const noLLMProfiles = llmResult.profiles.length === 0;
                    const multipleCanvasProfiles = canvasResult.profiles.length > 1;
                    const multipleLLMProfiles = llmResult.profiles.length > 1;

                    if (noCanvasProfiles || noLLMProfiles) {
                        return { needSelection: true, reason: 'no_profiles' };
                    }

                    if ((multipleCanvasProfiles && !canvasResult.active_id) ||
                        (multipleLLMProfiles && !llmResult.active_id)) {
                        return { needSelection: true, reason: 'multiple_profiles' };
                    }
                }

                return { needSelection: false };
            } catch (error) {
                console.error('Error checking profile selection need:', error);
                return { needSelection: true, reason: 'error' };
            }
        },

        // Actions
        async startGrading() {
            try {
                const profileCheck = await this.checkNeedProfileSelection();

                if (profileCheck.needSelection) {
                    await window.api.navigate_to('profile_select.html');
                } else {
                    await window.api.navigate_to('connection.html');
                }
            } catch (error) {
                console.error('Navigation error:', error);
                alert('Navigation error: ' + error.message);
            }
        },

        async navigateTo(page) {
            await window.api.navigate_to(page);
        },

        async switchCanvasProfile() {
            await window.api.navigate_to('profiles.html');
        },

        async switchLLMProfile() {
            await window.api.navigate_to('profiles.html');
        },

        async resumeGrading(courseId, contentId, contentType) {
            console.log('Resume grading:', courseId, contentId, contentType);
            // Implementation depends on your navigation system
        },

        async refresh() {
            const refreshBtn = document.getElementById('refresh-btn');
            if (refreshBtn) {
                refreshBtn.classList.add('rotating');
            }

            await this.loadDashboardData();
            await this.loadActiveProfiles();

            setTimeout(() => {
                if (refreshBtn) {
                    refreshBtn.classList.remove('rotating');
                }
            }, 1000);
        },

        // Helper methods
        formatRelativeTime(timestamp) {
            if (!timestamp) return '';

            const now = new Date();
            const date = new Date(timestamp);
            const diffMs = now - date;
            const diffMins = Math.floor(diffMs / 60000);

            if (diffMins < 1) return 'just now';
            if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;

            const diffHours = Math.floor(diffMins / 60);
            if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;

            const diffDays = Math.floor(diffHours / 24);
            if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;

            return date.toLocaleDateString();
        },

        getSessionIcon(contentType) {
            return contentType === 'quiz' ? 'ph-file-text' : 'ph-folder';
        },

        getSessionColor(contentType) {
            return contentType === 'quiz' ? 'var(--color-primary)' : 'var(--color-secondary)';
        },

        getCompletionRate(session) {
            if (!session.total_questions || session.total_questions === 0) return 0;
            return Math.round((session.graded_questions / session.total_questions) * 100);
        }
    }));
});

// Add rotation animation for refresh button
if (!document.getElementById('dashboard-rotation-style')) {
    const rotationStyle = document.createElement('style');
    rotationStyle.id = 'dashboard-rotation-style';
    rotationStyle.textContent = `
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        .rotating i {
            animation: rotate 1s linear infinite;
        }
    `;
    document.head.appendChild(rotationStyle);
}
