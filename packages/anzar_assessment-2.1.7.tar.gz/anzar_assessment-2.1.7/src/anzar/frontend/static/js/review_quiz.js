// review_quiz.js - Final review and grade submission
// Modern version using window.api instead of window.pywebview.api

let targetAssignmentId = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded');
    
    // Use API utilities to initialize
    if (window.initializeAPI) {
        window.initializeAPI(initializePage);
    } else {
        // Fallback if utilities not loaded
        console.log('API utilities not loaded, using fallback');
        
        // Wait for pywebview to be ready
        window.addEventListener('pywebviewready', function() {
            console.log('PyWebView is ready');
            if (window.pywebview && window.pywebview.api) {
                window.api = window.pywebview.api;
                initializePage();
            }
        });
        
        // Check if already available
        if (window.pywebview && window.pywebview.api) {
            window.api = window.pywebview.api;
            initializePage();
        }
    }
});

async function initializePage() {
    if (!window.api) {
        console.error('API not available');
        setTimeout(() => {
            if (window.api) {
                initializePage();
            }
        }, 500);
        return;
    }
    
    const sendGradesBtn = document.getElementById('send-grades-btn');
    const cancelBtn = document.getElementById('cancel-btn');
    const newSessionBtn = document.getElementById('new-session-btn');
    const exitBtn = document.getElementById('exit-btn');
    const sendingGrades = document.getElementById('sending-grades');
    const successMessage = document.getElementById('success-message');
    const successText = document.getElementById('success-text');
    const errorContainer = document.getElementById('error-container');
    const errorMessage = document.getElementById('error-message');
    
    // Summary elements
    const summaryCourse = document.getElementById('summary-course');
    const summaryQuiz = document.getElementById('summary-quiz');
    const summaryAssignment = document.getElementById('summary-assignment');
    const summaryQuestions = document.getElementById('summary-questions');
    const summaryCsv = document.getElementById('summary-csv');
    
    async function loadSummary() {
        try {
            // Get target assignment ID from localStorage
            const storedId = localStorage.getItem('targetAssignmentId');
            targetAssignmentId = parseInt(storedId);
            
            // Get current state
            const state = await window.api.get_state();
            
            // Update active profiles in the header if available
            if (window.updateActiveProfiles) {
                window.updateActiveProfiles();
            }
            
            // Update connection status
            // Removed automatic connection testing - only test on initial load
            
            // Fill summary
            summaryCourse.textContent = state.course_name || 'Unknown';
            summaryQuiz.textContent = state.content_name || 'Unknown';
            summaryQuestions.textContent = state.total_questions || 0;
            summaryCsv.textContent = state.csv_path || 'Unknown';
            
            // Get assignment name
            const assignments = await window.api.assignment_get_list();
            if (assignments.success && assignments.assignments) {
                const targetAssignment = assignments.assignments.find(a => a.id === targetAssignmentId);
                summaryAssignment.textContent = targetAssignment ? targetAssignment.name : 'Unknown';
            }
        } catch (error) {
            console.error('Error loading summary:', error);
            showError('Failed to load summary');
        }
    }
    
    async function sendGrades() {
        sendingGrades.classList.remove('hidden');
        sendGradesBtn.disabled = true;
        cancelBtn.disabled = true;
        
        try {
            const result = await window.api.grades_send_to_canvas(targetAssignmentId);
            
            sendingGrades.classList.add('hidden');
            
            if (result.success) {
                successText.textContent = result.message || 'Grades sent successfully!';
                successMessage.classList.remove('hidden');
                sendGradesBtn.classList.add('hidden');
                cancelBtn.classList.add('hidden');
            } else {
                showError(result.error || result.message || 'Failed to send grades');
                sendGradesBtn.disabled = false;
                cancelBtn.disabled = false;
            }
        } catch (error) {
            console.error('Error sending grades:', error);
            sendingGrades.classList.add('hidden');
            showError('Failed to send grades to Canvas: ' + error.message);
            sendGradesBtn.disabled = false;
            cancelBtn.disabled = false;
        }
    }
    
    function showError(message) {
        errorMessage.textContent = message;
        errorContainer.classList.remove('hidden');
    }
    
    function showToast(type, message) {
        // Use the modern toast notification if available
        if (window.showToast) {
            window.showToast(message, type);
        } else {
            // Fallback to alert
            alert(message);
        }
    }
    
    // Event handlers
    sendGradesBtn.addEventListener('click', async () => {
        // Get grades preview for confirmation message
        let confirmMessage = 'Are you sure you want to send grades to Canvas?\n\n';
        
        try {
            const previewResult = await window.api.grades_get_preview();
            if (previewResult.success && previewResult.preview) {
                confirmMessage += `This will send grades for ${previewResult.graded_students} out of ${previewResult.total_students} students.\n`;
                confirmMessage += `\nTarget Assignment: ${summaryAssignment.textContent}`;
                confirmMessage += `\nQuiz: ${summaryQuiz.textContent}`;
                confirmMessage += '\n\n⚠️ This action cannot be undone.';
            }
        } catch (error) {
            console.error('Error getting grades preview:', error);
        }
        
        // Use native confirm dialog which works in PyWebView
        if (confirm(confirmMessage)) {
            await sendGrades();
        }
    });
    
    cancelBtn.addEventListener('click', async () => {
        await window.api.navigate_to('grading_hub.html');
    });
    
    newSessionBtn.addEventListener('click', async () => {
        localStorage.clear();
        await window.api.navigate_to('dashboard.html');
    });
    
    exitBtn.addEventListener('click', () => {
        window.close();
    });
    
    // Initialize
    await loadSummary();
}