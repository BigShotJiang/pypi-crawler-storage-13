// assignment_parse.js - Assignment parsing management (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('assignmentParsePage', () => ({
        // State
        loading: true,
        selectedMethod: null,
        questions: [],

        // View states
        showParseReady: true,
        showParsing: false,
        showParseComplete: false,
        showError: false,
        errorMessage: '',

        // Parsing progress
        progressPercent: 0,
        progressText: 'Processing...',

        // Parse results
        csvPath: '',
        summaryItems: [],

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            // Check if CSV already exists to avoid re-parsing
            try {
                const state = await window.api.get_state();
                if (state.content_id) {
                    const csvCheck = await window.api.assignment_check_parsed(state.content_id);
                    if (csvCheck.success && csvCheck.exists) {
                        console.log('✅ CSV already exists, going directly to grading hub');
                        Alpine.store('toast').info('Assignment already parsed');
                        navigateTo('grading_hub.html');
                        return;
                    }
                }
            } catch (error) {
                console.log('Could not check CSV status, proceeding with parsing');
            }

            // Check if auto-start parsing
            const urlParams = new URLSearchParams(window.location.search);
            const method = urlParams.get('method');

            if (method === 'template') {
                await this.startTemplateParsing();
            } else {
                this.loading = false;
            }
        },

        // Auto-start template parsing
        async startTemplateParsing() {
            console.log('Auto-starting template parsing');

            try {
                const result = await window.api.assignment_parse_to_csv_pdf();

                if (result.success) {
                    console.log('Parsing complete, redirecting to grading hub');
                    navigateTo('grading_hub.html');
                } else {
                    Alpine.store('toast').error('Parsing failed: ' + (result.error || result.message));
                    navigateTo('assignment_download.html');
                }
            } catch (error) {
                console.error('Error parsing:', error);
                Alpine.store('toast').error('Failed to parse submissions: ' + error.message);
                navigateTo('assignment_download.html');
            }
        },

        // Select parsing method
        selectMethod(method) {
            this.selectedMethod = method;
        },

        // Add question
        addQuestion() {
            const nextNum = this.questions.length + 1;
            this.questions.push({
                id: `q${nextNum}`,
                number: nextNum,
                text: ''
            });
        },

        // Parse with metadata method
        async parseMetadata() {
            await this.startTemplateParsing();
        },

        // Parse with unified method (redirect to agent setup)
        parseUnified() {
            navigateTo('assignment_agent_setup.html');
        },

        // Show error state
        showErrorState(message) {
            this.showParseReady = false;
            this.showParsing = false;
            this.showParseComplete = false;
            this.errorMessage = message;
            this.showError = true;
        },

        // Reload page
        reloadPage() {
            location.reload();
        },

        // Go back to template
        goBackToTemplate() {
            navigateTo('assignment_template.html');
        },

        // Proceed to grading status
        proceedToStatus() {
            navigateTo('assignment_status.html');
        }
    }));

    console.log('✅ Assignment parse component registered');
});
