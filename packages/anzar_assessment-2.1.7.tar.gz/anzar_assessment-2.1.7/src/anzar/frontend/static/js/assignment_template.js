// assignment_template.js - Assignment template management (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('assignmentTemplatePage', () => ({
        // State
        loading: true,
        currentState: null,
        analysisData: null,

        // View states
        checking: true,
        showTemplateExists: false,
        showNoTemplate: false,
        showCreatingTemplate: false,
        showTemplateCreated: false,
        showPDFParsingOption: false,
        showError: false,
        errorMessage: '',

        // Template data
        templatePath: '',
        createdTemplatePath: '',
        templatePathInput: '',

        // PDF parsing data
        recommendedStrategy: '',

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            try {
                const state = await window.api.get_state();

                // Check if assignment is already parsed
                const parseStatus = await window.api.assignment_check_parsed();

                if (parseStatus.success && parseStatus.parsed && parseStatus.has_data) {
                    console.log(`Assignment already parsed: ${parseStatus.rows} rows found`);

                    const loadResult = await window.api.assignment_load_parsed_csv(parseStatus.csv_path);

                    if (loadResult.success) {
                        const statusResult = await window.api.assignment_get_csv_status();

                        if (statusResult.success) {
                            console.log('CSV Status:', statusResult);

                            const progress = statusResult.grading_progress;
                            const graded = statusResult.graded_responses;
                            const total = statusResult.total_responses;
                            const ungraded = total - graded;

                            if (progress === 100) {
                                Alpine.store('toast').success(
                                    `Assignment ready to submit! All ${total} responses graded. Proceeding to submission page.`);
                            } else if (progress > 0) {
                                Alpine.store('toast').info(
                                    `Assignment partially graded: ${graded}/${total} responses completed (${progress}%). ` +
                                    `${ungraded} responses remaining. Proceeding to grading status.`);
                            } else {
                                Alpine.store('toast').info(
                                    `Assignment parsed but not graded: ${statusResult.total_students} students, ` +
                                    `${statusResult.total_questions} questions, ${total} responses. Proceeding to grading status.`);
                            }
                        }

                        navigateTo('grading_hub.html');
                        return;
                    } else {
                        console.warn('Failed to load parsed CSV, proceeding to parse page');
                        Alpine.store('toast').warning('Could not load existing CSV. Will re-parse assignment.');
                    }
                }

                // Not parsed yet, proceed to parse page
                navigateTo('assignment_parse.html');
            } catch (error) {
                console.error('Error checking parse status:', error);
                navigateTo('assignment_parse.html');
            }
        },

        // Update context
        async updateContext() {
            try {
                const state = await window.api.get_state();
                this.currentState = state;

                if (window.updateActiveProfiles) {
                    window.updateActiveProfiles();
                }
            } catch (error) {
                console.error('Error loading state:', error);
            }
        },

        // Check parsing method
        async checkParsingMethod() {
            try {
                // First check submission analysis
                const analysisResult = await window.api.assignment_get_submission_analysis();

                if (analysisResult.success && analysisResult.analysis) {
                    this.analysisData = analysisResult.analysis;

                    // If we have parseable PDFs, show that option first
                    if (this.analysisData.parseable_pdfs > 0) {
                        this.checking = false;
                        this.showPDFParsingOption = true;
                        return;
                    }
                }

                // Otherwise, check for template
                await this.checkForTemplate();
            } catch (error) {
                console.error('Error checking template:', error);
                this.showErrorState('Failed to check template status');
            }
        },

        // Check for template
        async checkForTemplate() {
            try {
                const result = await window.api.assignment_check_template();

                if (result.success) {
                    this.checking = false;

                    if (result.exists && result.path) {
                        this.templatePath = result.path;
                        this.showTemplateExists = true;
                    } else {
                        this.showNoTemplate = true;
                    }
                } else {
                    this.showErrorState(result.error || 'Failed to check for template');
                }
            } catch (error) {
                console.error('Error checking template:', error);
                this.showErrorState('Failed to check template status');
            }
        },

        // Computed: Parseable percentage
        get parseablePercentage() {
            return this.analysisData ? this.analysisData.parseable_percentage.toFixed(1) : 0;
        },

        // Computed: Show low parseable warning
        get showLowParseableWarning() {
            return this.analysisData && this.analysisData.parseable_percentage < 80;
        },

        // Computed: Non-parseable count
        get nonParseableCount() {
            return this.analysisData
                ? this.analysisData.total_submissions - this.analysisData.parseable_pdfs
                : 0;
        },

        // Parse PDFs directly
        async parsePDFsDirectly() {
            this.showPDFParsingOption = false;
            this.showCreatingTemplate = true;

            try {
                const result = await window.api.assignment_parse_to_csv_pdf(
                    this.analysisData.parseable_percentage < 50
                );

                if (result.success) {
                    navigateTo('assignment_parse_results.html');
                } else {
                    this.showErrorState(result.message || 'Failed to parse PDFs');
                }
            } catch (error) {
                console.error('Error parsing PDFs:', error);
                this.showErrorState('Failed to parse PDF submissions');
            }
        },

        // Use template method
        useTemplateMethod() {
            this.showPDFParsingOption = false;
            this.checkForTemplate();
        },

        // Create template
        async createTemplate() {
            this.showNoTemplate = false;
            this.showCreatingTemplate = true;

            try {
                const result = await window.api.assignment_create_template();

                if (result.success) {
                    this.showCreatingTemplate = false;
                    this.createdTemplatePath = result.path;
                    this.showTemplateCreated = true;
                } else {
                    this.showCreatingTemplate = false;
                    this.showNoTemplate = true;
                    this.showErrorState(result.error || 'Failed to create template');
                }
            } catch (error) {
                console.error('Error creating template:', error);
                this.showCreatingTemplate = false;
                this.showNoTemplate = true;
                this.showErrorState('Failed to create template');
            }
        },

        // Copy template
        async copyTemplate() {
            const templatePath = this.templatePathInput.trim();
            if (!templatePath) {
                Alpine.store('toast').error('Please enter a template file path');
                return;
            }

            this.showNoTemplate = false;
            this.showCreatingTemplate = true;

            try {
                const result = await window.api.assignment_copy_template(templatePath);

                if (result.success) {
                    this.showCreatingTemplate = false;
                    this.createdTemplatePath = result.path;
                    this.showTemplateCreated = true;
                } else {
                    this.showCreatingTemplate = false;
                    this.showNoTemplate = true;
                    this.showErrorState(result.error || 'Failed to copy template');
                }
            } catch (error) {
                console.error('Error copying template:', error);
                this.showCreatingTemplate = false;
                this.showNoTemplate = true;
                this.showErrorState('Failed to copy template');
            }
        },

        // Proceed to parse
        proceedToParse() {
            navigateTo('assignment_parse.html');
        },

        // Show error state
        showErrorState(message) {
            this.checking = false;
            this.showTemplateExists = false;
            this.showNoTemplate = false;
            this.showCreatingTemplate = false;
            this.showTemplateCreated = false;
            this.showPDFParsingOption = false;
            this.errorMessage = message;
            this.showError = true;
        },

        // Reload page
        reloadPage() {
            location.reload();
        },

        // Go back
        goBack() {
            navigateTo('assignment_download.html');
        }
    }));

    console.log('✅ Assignment template component registered');
});
