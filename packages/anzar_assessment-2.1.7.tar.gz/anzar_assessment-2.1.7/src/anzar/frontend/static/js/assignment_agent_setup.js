// assignment_agent_setup.js - Alpine.js conversion

document.addEventListener('alpine:init', () => {
    Alpine.data('assignmentAgentSetup', () => ({
        // State
        allQuestions: [],
        filterIncomplete: false,
        loading: true,
        loadingMessage: 'Checking Canvas assignment for questions...',
        infoMessage: null,
        infoType: null, // 'success', 'warning', 'danger', 'info'

        // CSV parsing state
        csvExists: false,
        parsing: false,
        csvPath: '',

        // Grading options
        forceRegrade: false,

        // Grading statistics
        gradingStats: {
            totalStudents: '...',
            totalQuestions: 0,
            totalItems: '...',
            gradedItems: 0,
            percentageGraded: 0
        },

        // Question change tracking
        initialQuestionCount: 0,

        // Init
        async init() {
            console.log('Assignment Agent Setup: Initializing');

            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadQuestionsFromCanvas();
            await this.checkIfCSVExists();
            await this.loadGradingStats();
            await this.updateSummary();
        },

        // Computed properties
        get hasQuestions() {
            return this.allQuestions.length > 0;
        },

        get filteredQuestions() {
            if (!this.filterIncomplete) {
                return this.allQuestions;
            }
            return this.allQuestions.filter(q => !this.isQuestionComplete(q));
        },

        get studentCount() {
            return this.summaryData.studentCount || '...';
        },

        get questionCount() {
            return this.summaryData.questionCount || 0;
        },

        get totalItems() {
            return this.summaryData.totalItems || '...';
        },

        get estimatedTime() {
            return this.summaryData.estimatedTime || '...';
        },

        get questionsChanged() {
            // Only check if CSV exists and we have an initial count
            if (!this.csvExists || this.initialQuestionCount === 0) {
                return false;
            }
            return this.allQuestions.length !== this.initialQuestionCount;
        },

        get questionsChangedMessage() {
            const diff = this.allQuestions.length - this.initialQuestionCount;
            if (diff > 0) {
                return `You've added ${diff} question(s). Re-parse required before grading.`;
            } else if (diff < 0) {
                return `You've deleted ${Math.abs(diff)} question(s). Re-parse required before grading.`;
            }
            return 'Questions modified. Re-parse required before grading.';
        },

        // Summary data
        summaryData: {
            studentCount: '...',
            questionCount: 0,
            totalItems: '...',
            estimatedTime: '...'
        },

        // Load questions from Canvas
        async loadQuestionsFromCanvas() {
            this.loading = true;
            this.infoMessage = null;
            console.log('Loading questions from Canvas...');

            try {
                const result = await window.api.assignment_extract_questions_from_canvas();

                this.loading = false;

                if (result && result.success && result.questions && result.questions.length > 0) {
                    console.log('Questions loaded successfully:', result.questions.length);

                    this.allQuestions = result.questions.map((q, i) => ({
                        ...q,
                        tempId: `q${Date.now() + i}`,
                        isExpanded: false,
                        // Map rubric data to form fields
                        correct_answer: q.long_description || q.correct_answer || '',
                        grading_rubric: q.partial_credit_rubric || q.grading_rubric || ''
                    }));

                    this.infoType = 'success';
                    if (result.source === 'canvas_rubric') {
                        this.infoMessage = `Canvas Rubric Found! Using rubric "${result.rubric_title || 'Unknown'}" criteria as questions.`;
                    } else {
                        this.infoMessage = 'Questions Found! Extracted from the assignment description.';
                    }
                } else {
                    console.log('No questions found in Canvas');
                    this.infoType = 'warning';
                    this.infoMessage = 'No rubric or questions found. Please define the grading criteria manually.';
                }
            } catch (error) {
                console.error('Error extracting questions:', error);
                this.loading = false;

                if (error.message.includes('development mode') || error.message.includes('API not available')) {
                    this.infoType = 'info';
                    this.infoMessage = 'Development Mode: API not available. You can manually add questions below.';
                } else {
                    this.infoType = 'danger';
                    this.infoMessage = `Error: Could not load questions from Canvas. ${error.message}`;
                }
            }
        },

        // Add new question
        addNewQuestion() {
            console.log('Adding new question...');

            const newQuestion = {
                tempId: `q${Date.now()}`,
                text: '',
                points: 10,
                correct_answer: '',
                grading_rubric: '',
                good_examples: '',
                bad_examples: '',
                graded_examples: '',
                feedback_format: 'Provide constructive feedback in 2-3 sentences. Be specific about what was done correctly and what needs improvement.',
                extra_instructions: '',
                isExpanded: true
            };

            this.allQuestions.push(newQuestion);
            console.log('Questions now:', this.allQuestions.length);

            this.updateSummary();

            // Focus first input after Alpine renders
            this.$nextTick(() => {
                const newIndex = this.allQuestions.length - 1;
                const firstInput = document.querySelector(`[data-question-index="${newIndex}"] [data-field="text"]`);
                if (firstInput) firstInput.focus();
            });
        },

        // Delete question
        deleteQuestion(index) {
            if (confirm('Are you sure you want to delete this question?')) {
                this.allQuestions.splice(index, 1);
                this.updateSummary();
            }
        },

        // Toggle question expansion
        toggleQuestion(index) {
            this.allQuestions[index].isExpanded = !this.allQuestions[index].isExpanded;
        },

        // Save question changes
        saveQuestion(index) {
            // Data is already bound via x-model, just collapse
            this.allQuestions[index].isExpanded = false;
            this.updateSummary();
        },

        // Cancel editing (collapse without saving)
        cancelEdit(index) {
            this.allQuestions[index].isExpanded = false;
        },

        // Update a specific field
        updateField(index, field, value) {
            if (field === 'points') {
                this.allQuestions[index][field] = parseFloat(value) || 0;
            } else {
                this.allQuestions[index][field] = value;
            }
        },

        // Check if question is complete
        isQuestionComplete(q) {
            const hasText = !!(q.text && String(q.text).trim());
            const hasPoints = q.points !== undefined && q.points !== null;
            const hasAnswer = !!(q.correct_answer && String(q.correct_answer).trim());
            const hasRubric = !!(q.grading_rubric && String(q.grading_rubric).trim());
            return hasText && hasPoints && hasAnswer && hasRubric;
        },

        // Build status chips for a question
        getQuestionChips(q) {
            const fields = [
                { key: 'text', label: 'Text', icon: 'ph-text-t', required: true },
                { key: 'points', label: 'Points', icon: 'ph-coins', required: true },
                { key: 'correct_answer', label: 'Answer', icon: 'ph-check-circle', required: true },
                { key: 'grading_rubric', label: 'Rubric', icon: 'ph-clipboard-text', required: true },
                { key: 'good_examples', label: 'Good', icon: 'ph-thumbs-up', required: false },
                { key: 'bad_examples', label: 'Bad', icon: 'ph-thumbs-down', required: false },
                { key: 'graded_examples', label: 'Graded', icon: 'ph-list-numbers', required: false },
                { key: 'feedback_format', label: 'Format', icon: 'ph-text-align-left', required: false },
                { key: 'extra_instructions', label: 'Notes', icon: 'ph-robot', required: false },
            ];

            let total = 0, filled = 0;
            const chips = fields.map(f => {
                total++;
                const has = f.key === 'points'
                    ? (q.points !== undefined && q.points !== null)
                    : !!(q[f.key] && String(q[f.key]).trim());
                if (has) filled++;

                let chipClass = 'status-pill';
                if (has) {
                    chipClass += ' complete';
                } else if (f.required) {
                    chipClass += ' missing';
                }

                return { class: chipClass, icon: f.icon, label: f.label };
            });

            const completion = Math.round((filled / total) * 100);
            const summaryText = `${filled}/${total} fields`;

            return { chips, completion, summaryText };
        },

        // Update summary statistics
        async updateSummary() {
            try {
                const questions = this.collectQuestionsData();
                let studentCount = 0;

                if (window.api) {
                    try {
                        const state = await window.api.get_state();

                        // Try multiple sources for student count
                        if (state.analysis && state.analysis.total_submissions) {
                            studentCount = state.analysis.total_submissions;
                        } else if (state.folder_path) {
                            // Try to get submission analysis
                            const analysisResult = await window.api.assignment_get_submission_analysis();
                            if (analysisResult.success) {
                                studentCount = analysisResult.total_submissions || 0;
                            }
                        }
                    } catch (apiError) {
                        console.warn('Could not get student count:', apiError);
                        studentCount = 0;
                    }
                }

                // If we still don't have count, estimate from folder
                if (studentCount === 0 && window.api) {
                    try {
                        const state = await window.api.get_state();
                        // Default estimate if we can't determine
                        studentCount = 1; // At least show something
                    } catch {}
                }

                const totalItems = questions.length * studentCount;
                const estimatedMinutes = Math.max(Math.ceil(totalItems / 60), 1);

                this.summaryData = {
                    studentCount: studentCount > 0 ? studentCount : '...',
                    questionCount: questions.length,
                    totalItems: studentCount > 0 ? totalItems : '...',
                    estimatedTime: (studentCount > 0 && questions.length > 0)
                        ? `${estimatedMinutes} - ${estimatedMinutes * 2} min`
                        : '...'
                };

                console.log('Summary updated:', this.summaryData);
            } catch (error) {
                console.error('Error updating summary:', error);
                this.summaryData = {
                    studentCount: '...',
                    questionCount: this.collectQuestionsData().length,
                    totalItems: '...',
                    estimatedTime: '...'
                };
            }
        },

        // Collect questions data for submission
        collectQuestionsData() {
            const collected = [];
            this.allQuestions.forEach((question, index) => {
                if (question.text && question.text.trim()) {
                    collected.push({
                        id: question.id || `q${index + 1}`,
                        text: question.text.trim(),
                        points: question.points || 10,
                        correct_answer: question.correct_answer || '',
                        grading_rubric: question.grading_rubric || '',
                        good_examples: question.good_examples || '',
                        bad_examples: question.bad_examples || '',
                        graded_examples: question.graded_examples || '',
                        feedback_format: question.feedback_format || '',
                        extra_instructions: question.extra_instructions || '',
                        criterion_id: question.criterion_id || ''
                    });
                }
            });

            console.log('🔍 collectQuestionsData() collected:', collected.length, 'questions');
            collected.forEach((q, i) => {
                console.log(`  Question ${i + 1}:`);
                console.log(`    - correct_answer: "${q.correct_answer.substring(0, 50)}"`);
                console.log(`    - feedback_format: "${q.feedback_format.substring(0, 50)}"`);
            });

            return collected;
        },

        // Normalize question data to match the format expected by grading API (snake_case)
        normalizeQuestionForGrading(question) {
            return {
                question_id: question.id,
                question_text: question.text || '',
                points_possible: question.points || 10,
                criterion_id: question.criterion_id || '',
                criteria: {
                    correct_answer: question.correct_answer || '',
                    grading_rubric: question.grading_rubric || '',
                    good_examples: question.good_examples || '',
                    bad_examples: question.bad_examples || '',
                    graded_examples: question.graded_examples || '',
                    feedback_format: question.feedback_format || '',
                    extra_instructions: question.extra_instructions || '',
                    max_points: question.points || 10
                }
            };
        },

        // Check if CSV already exists
        async checkIfCSVExists() {
            try {
                const state = await window.api.get_state();

                if (!state.content_id) {
                    this.csvExists = false;
                    return;
                }

                const csvCheck = await window.api.assignment_check_parsed(state.content_id);

                if (csvCheck.success && csvCheck.exists) {
                    this.csvExists = true;
                    this.csvPath = csvCheck.csv_path || '';
                    console.log('✅ CSV already exists:', this.csvPath);
                } else {
                    this.csvExists = false;
                    console.log('📝 CSV does not exist yet');
                }
            } catch (error) {
                console.error('Error checking CSV:', error);
                this.csvExists = false;
            }
        },

        // Load grading statistics
        async loadGradingStats() {
            try {
                if (!this.csvExists) {
                    console.log('📊 CSV does not exist, cannot load grading stats');
                    return;
                }

                console.log('📊 Loading grading statistics...');

                const gradesData = await window.api.grades_get_all();

                if (gradesData.success && gradesData.questions) {
                    let totalStudents = 0;
                    let totalQuestions = gradesData.questions.length;
                    let gradedItems = 0;
                    let totalItems = 0;

                    // Count students and graded items from the data
                    for (const question of gradesData.questions) {
                        if (question.students && question.students.length > 0) {
                            // Update total students (use max across all questions)
                            totalStudents = Math.max(totalStudents, question.students.length);

                            // Count graded items
                            for (const student of question.students) {
                                totalItems++;
                                // A student is graded if they have BOTH grade and feedback filled
                                // (grade, feedback, llm are all set during AI grading)
                                const hasGrade = student.grade !== null && student.grade !== undefined && student.grade !== '';
                                const hasFeedback = student.feedback && student.feedback.trim() !== '';

                                if (hasGrade && hasFeedback) {
                                    gradedItems++;
                                }
                            }
                        }
                    }

                    const percentageGraded = totalItems > 0
                        ? Math.round((gradedItems / totalItems) * 100)
                        : 0;

                    this.gradingStats = {
                        totalStudents,
                        totalQuestions,
                        totalItems,
                        gradedItems,
                        percentageGraded
                    };

                    // Store initial question count for change detection
                    if (this.initialQuestionCount === 0) {
                        this.initialQuestionCount = totalQuestions;
                        console.log('📊 Initial question count set to:', this.initialQuestionCount);
                    }

                    console.log('✅ Grading stats loaded:', this.gradingStats);
                } else {
                    console.log('⚠️ Could not load grading data');
                }
            } catch (error) {
                console.error('❌ Error loading grading stats:', error);
            }
        },

        // Parse submissions to CSV
        async parseSubmissions() {
            const questions = this.collectQuestionsData();

            if (questions.length === 0) {
                Alpine.store('toast').error('Please define at least one question before parsing.');
                return;
            }

            // Validate questions have minimum required field (just text for parsing)
            const incompleteQuestions = questions.filter(q =>
                !q.text || !q.text.trim()
            );

            if (incompleteQuestions.length > 0) {
                Alpine.store('toast').error(`${incompleteQuestions.length} question(s) are missing question text. Please fill in question text for all questions.`);
                return;
            }

            // Warning if re-parsing with existing grades
            if (this.csvExists && this.gradingStats.gradedItems > 0) {
                const confirmed = confirm(
                    `⚠️ WARNING: Re-parsing will delete all ${this.gradingStats.gradedItems} existing grades.\n\n` +
                    `This is necessary because you've modified the question structure.\n\n` +
                    `Do you want to continue?`
                );
                if (!confirmed) {
                    console.log('User cancelled re-parse');
                    return;
                }
            }

            try {
                this.parsing = true;
                Alpine.store('toast').info('Parsing submissions... This may take a few minutes.');

                console.log('Starting parsing with', questions.length, 'questions');

                // Call parse API
                const result = await window.api.assignment_parse_auto(questions);

                this.parsing = false;

                if (result.success) {
                    this.csvExists = true;
                    this.csvPath = result.csv_path || '';

                    Alpine.store('toast').success(`Parsing complete! Created CSV with ${result.message || 'submissions'}`);

                    console.log('✅ Parsing successful:', result.csv_path);

                    // Update initial question count to current count
                    this.initialQuestionCount = questions.length;

                    // Reload state to update CSV path and stats
                    await this.checkIfCSVExists();
                    await this.loadGradingStats();
                } else {
                    Alpine.store('toast').error('Parsing failed: ' + (result.error || 'Unknown error'));
                    console.error('Parsing failed:', result);
                }
            } catch (error) {
                this.parsing = false;
                console.error('Error parsing submissions:', error);
                Alpine.store('toast').error('Failed to parse submissions: ' + error.message);
            }
        },

        // Run agent
        async runAgent() {
            // Validate CSV exists
            if (!this.csvExists) {
                Alpine.store('toast').error('Please parse submissions first before grading.');
                return;
            }

            // Check if questions have changed
            if (this.questionsChanged) {
                Alpine.store('toast').error('Questions have been modified. Please re-parse submissions before grading.');
                return;
            }

            const questions = this.collectQuestionsData();

            // Validate we have questions
            if (questions.length === 0) {
                Alpine.store('toast').error('Please define at least one question.');
                return;
            }

            // Validate questions have required fields
            const incompleteQuestions = questions.filter(q =>
                !q.text || !q.text.trim() ||
                !q.correct_answer || !q.correct_answer.trim() ||
                !q.grading_rubric || !q.grading_rubric.trim()
            );

            if (incompleteQuestions.length > 0) {
                Alpine.store('toast').error(`${incompleteQuestions.length} question(s) are missing required fields (text, correct answer, grading rubric). Please complete all questions before grading.`);
                return;
            }

            try {
                Alpine.store('loading').show('Starting grading...');

                // Normalize questions to the format expected by grading progress page
                const normalizedQuestions = questions.map(q => this.normalizeQuestionForGrading(q));

                // Store in Alpine store with consistent naming like quiz flow
                const gradingState = Alpine.store('gradingState');

                console.log('🔍 [setup] Storing normalized questions:', normalizedQuestions.length);
                console.log('🔍 [setup] First normalized question:', normalizedQuestions[0]);
                console.log('🔍 [setup] Force regrade:', this.forceRegrade);

                // Store normalized questions array
                gradingState.set('assignmentQuestions', normalizedQuestions);
                gradingState.set('forceRegrade', this.forceRegrade);
                gradingState.set('isAssignmentGrading', true);

                // Backup to sessionStorage
                sessionStorage.setItem('assignmentQuestions', JSON.stringify(normalizedQuestions));
                sessionStorage.setItem('forceRegrade', JSON.stringify(this.forceRegrade));

                // Verify storage
                const verification = gradingState.get('assignmentQuestions');
                console.log('✅ [setup] Verified storage:', verification ? verification.length : 'null', 'questions');

                console.log(`Starting grading for ${questions.length} question(s)`);

                // Navigate using API method (like quiz flow)
                await window.api.navigate_to('assignment_grading_progress.html');
            } catch (error) {
                console.error('Error starting grading:', error);
                Alpine.store('toast').error('Failed to start grading: ' + error.message);
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Grade a single question
        async gradeQuestion(index) {
            // Validate CSV exists
            if (!this.csvExists) {
                Alpine.store('toast').error('Please parse submissions first before grading.');
                return;
            }

            // PRE-FLIGHT CHECK: Verify LLM connectivity before proceeding
            const llmReady = await checkLLMConnectionBeforeGrading();
            if (!llmReady) {
                return; // Abort if LLM is not reachable
            }

            const question = this.allQuestions[index];

            // Validate question exists and has required fields
            if (!question || !question.text || !question.text.trim()) {
                Alpine.store('toast').error('Please complete the question text first.');
                return;
            }

            if (!question.correct_answer || !question.correct_answer.trim()) {
                Alpine.store('toast').error('Please provide a correct answer before grading.');
                return;
            }

            if (!question.grading_rubric || !question.grading_rubric.trim()) {
                Alpine.store('toast').error('Please provide a grading rubric before grading.');
                return;
            }

            try {
                Alpine.store('loading').show('Starting grading for this question...');

                // Collect just this question's data
                const questionData = {
                    id: question.id || `q${index + 1}`,
                    text: question.text.trim(),
                    points: question.points || 10,
                    correct_answer: question.correct_answer || '',
                    grading_rubric: question.grading_rubric || '',
                    good_examples: question.good_examples || '',
                    bad_examples: question.bad_examples || '',
                    graded_examples: question.graded_examples || '',
                    feedback_format: question.feedback_format || '',
                    extra_instructions: question.extra_instructions || '',
                    criterion_id: question.criterion_id || ''
                };

                // Normalize to match expected format
                const normalizedQuestion = this.normalizeQuestionForGrading(questionData);

                // Store in Alpine store (as array with single question)
                const gradingState = Alpine.store('gradingState');
                gradingState.set('assignmentQuestions', [normalizedQuestion]);
                gradingState.set('forceRegrade', this.forceRegrade);
                gradingState.set('isAssignmentGrading', true);

                // Backup to sessionStorage
                sessionStorage.setItem('assignmentQuestions', JSON.stringify([normalizedQuestion]));
                sessionStorage.setItem('forceRegrade', JSON.stringify(this.forceRegrade));

                console.log('✅ Grading single question:', normalizedQuestion.questionId);
                console.log('✅ Force regrade:', this.forceRegrade);

                // Navigate using API method
                await window.api.navigate_to('assignment_grading_progress.html');
            } catch (error) {
                console.error('Error starting single question grading:', error);
                Alpine.store('toast').error('Failed to start grading: ' + error.message);
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Check consistency for a single question
        async checkConsistency(index) {
            // Validate CSV exists
            if (!this.csvExists) {
                Alpine.store('toast').error('Please parse submissions first before checking consistency.');
                return;
            }

            // PRE-FLIGHT CHECK: Verify LLM connectivity before proceeding
            const llmReady = await checkLLMConnectionBeforeConsistency();
            if (!llmReady) {
                return; // Abort if LLM is not reachable
            }

            const question = this.allQuestions[index];

            // Validate question exists and has required fields
            if (!question || !question.text || !question.text.trim()) {
                Alpine.store('toast').error('Please complete the question text first.');
                return;
            }

            if (!question.correct_answer || !question.correct_answer.trim()) {
                Alpine.store('toast').error('Please provide a correct answer before checking consistency.');
                return;
            }

            if (!question.grading_rubric || !question.grading_rubric.trim()) {
                Alpine.store('toast').error('Please provide a grading rubric before checking consistency.');
                return;
            }

            try {
                Alpine.store('loading').show('Preparing consistency check...');

                // Get sample answers for this question
                const questionId = question.id || `q${index + 1}`;
                const samplesResult = await window.api.assignment_get_sample_answers(questionId, 50);

                if (!samplesResult.success || !samplesResult.samples || samplesResult.samples.length === 0) {
                    Alpine.store('toast').error('No student answers found for this question.');
                    Alpine.store('loading').hide();
                    return;
                }

                // Store data in Alpine store (same format as quiz flow)
                const gradingState = Alpine.store('gradingState');

                // Store return destination for smart back navigation
                gradingState.set('returnTo', 'assignment_agent_setup.html');

                gradingState.set('gradingCriteria', {
                    correct_answer: question.correct_answer || '',
                    grading_rubric: question.grading_rubric || '',
                    good_examples: question.good_examples || '',
                    bad_examples: question.bad_examples || '',
                    graded_examples: question.graded_examples || '',
                    feedback_format: question.feedback_format || '',
                    extra_instructions: question.extra_instructions || '',
                    max_points: question.points || 10
                });

                gradingState.set('gradingQuestionId', questionId);
                gradingState.set('gradingQuestionText', question.text);
                gradingState.set('sampleAnswers', samplesResult.samples);

                // Store the complete question data for consistency checker (matches quiz workflow)
                gradingState.set('questionData', {
                    questionId: questionId,
                    questionText: question.text,
                    pointsPossible: question.points || 10,
                    isQuiz: false, // This is assignment workflow
                    answerCount: samplesResult.samples.length,
                    // Include all the grading criteria fields
                    correct_answer: question.correct_answer || '',
                    grading_rubric: question.grading_rubric || '',
                    good_examples: question.good_examples || '',
                    bad_examples: question.bad_examples || '',
                    graded_examples: question.graded_examples || '',
                    extra_instructions: question.extra_instructions || '',
                    feedback_format: question.feedback_format || ''
                });

                console.log('✅ Navigating to consistency checker for question:', questionId);

                // Navigate to quiz_consistency.html (reuse existing page)
                await window.api.navigate_to('quiz_consistency.html');
            } catch (error) {
                console.error('❌ Error starting consistency check:', error);
                Alpine.store('toast').error('Failed to start consistency check: ' + error.message);
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Run consistency check
        runConsistencyCheck() {
            if (!this.csvExists) {
                Alpine.store('toast').error('Please parse submissions first before running consistency check.');
                return;
            }

            const questions = this.collectQuestionsData();

            if (questions.length === 0) {
                Alpine.store('toast').error('Please define at least one question with grading criteria.');
                return;
            }

            // Check that at least one question has complete criteria
            const hasCompleteCriteria = questions.some(q =>
                q.text && q.text.trim() &&
                q.correct_answer && q.correct_answer.trim() &&
                q.grading_rubric && q.grading_rubric.trim()
            );

            if (!hasCompleteCriteria) {
                Alpine.store('toast').error('At least one question must have complete grading criteria (text, answer, rubric).');
                return;
            }

            // Store questions in sessionStorage for consistency checker
            sessionStorage.setItem('consistencyQuestions', JSON.stringify(questions));

            console.log('Running consistency check with', questions.length, 'questions');

            // Navigate to consistency check page
            navigateTo('assignment_consistency.html');
        },

        // Get icon for info type
        getInfoIcon() {
            switch (this.infoType) {
                case 'success': return 'ph-check-circle';
                case 'warning': return 'ph-warning';
                case 'danger': return 'ph-x-circle';
                case 'info': return 'ph-info';
                default: return 'ph-info';
            }
        },

        // Get title for question card
        getQuestionTitle(q, index) {
            return q.text || `Question ${index + 1}`;
        },

        // Escape HTML
        escapeHtml(text) {
            if (text === null || text === undefined) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    }));

    console.log('✅ Assignment Agent Setup component registered');
});
