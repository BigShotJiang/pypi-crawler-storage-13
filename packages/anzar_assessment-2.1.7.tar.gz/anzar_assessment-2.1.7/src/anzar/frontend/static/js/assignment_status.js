// assignment_status.js - Assignment grading status management (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('assignmentStatusPage', () => ({
        // State
        loading: true,
        currentState: null,
        questions: [],
        rubricExists: false,

        // View states
        showError: false,
        errorMessage: '',

        // Computed stats
        get totalQuestions() {
            return this.questions.length;
        },

        get gradedCount() {
            return this.questions.filter(q => q.graded).length;
        },

        get notGradedCount() {
            return this.totalQuestions - this.gradedCount;
        },

        get progressPercentage() {
            return this.totalQuestions > 0
                ? Math.round((this.gradedCount / this.totalQuestions) * 100)
                : 0;
        },

        get allQuestionsGraded() {
            return this.notGradedCount === 0 && this.totalQuestions > 0;
        },

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.updateContext();
            await this.loadQuestions();
        },

        // Update context
        async updateContext() {
            try {
                const state = await window.api.get_state();
                this.currentState = state;

                if (window.updateActiveProfiles) {
                    window.updateActiveProfiles();
                }
            } catch (error) {
                console.error('Error loading state:', error);
            }
        },

        // Load questions
        async loadQuestions() {
            this.loading = true;

            try {
                const result = await window.api.assignment_get_questions();

                if (result.success) {
                    this.questions = result.questions || [];

                    if (this.questions.length === 0) {
                        if (this.currentState?.csv_path) {
                            this.showErrorState('CSV file was created automatically, but no questions were found. The assignment submissions may not contain valid parsable data.');
                        } else {
                            this.showErrorState('No CSV file loaded. The assignment data may not have been parsed properly. Click "Force Re-parse Assignment" to parse the assignment submissions again.');
                        }
                        return;
                    }

                    await this.checkRubric();
                    this.loading = false;
                } else {
                    this.showErrorState(result.error || 'Failed to load questions. The assignment may not have been parsed yet.');
                }
            } catch (error) {
                console.error('Error loading questions:', error);
                this.showErrorState('Failed to load questions');
            }
        },

        // Check rubric
        async checkRubric() {
            try {
                const result = await window.api.rubric_check_exists(this.currentState.content_id);

                if (result.success) {
                    this.rubricExists = result.exists;
                }
            } catch (error) {
                console.error('Error checking rubric:', error);
            }
        },

        // Get rubric status
        get rubricStatus() {
            if (this.rubricExists) {
                return {
                    class: 'alert-success',
                    message: 'Rubric found and ready for grading'
                };
            } else {
                return {
                    class: 'alert-warning',
                    message: 'No rubric found. Create one for better grading accuracy.'
                };
            }
        },

        // Get question status
        getQuestionStatus(question) {
            if (question.graded) {
                return {
                    class: 'graded',
                    icon: '✓',
                    text: 'Graded'
                };
            } else {
                return {
                    class: 'not-graded',
                    icon: '○',
                    text: 'Not Graded'
                };
            }
        },

        // Create rubric
        async createRubric() {
            try {
                Alpine.store('loading').show('Creating rubric...');

                const result = await window.api.rubric_create(this.currentState.content_id);

                if (result.success) {
                    await this.checkRubric();
                    Alpine.store('toast').success('Rubric created successfully');
                } else {
                    Alpine.store('toast').error(result.error || 'Failed to create rubric');
                }
            } catch (error) {
                console.error('Error creating rubric:', error);
                Alpine.store('toast').error('Failed to create rubric');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Validate rubric
        async validateRubric() {
            try {
                Alpine.store('loading').show('Validating rubric...');

                const result = await window.api.rubric_validate_match(this.currentState.content_id);

                if (result.success) {
                    if (result.matches) {
                        Alpine.store('toast').success('Rubric validation successful! All questions match.');
                    } else {
                        const mismatches = result.mismatches || [];
                        Alpine.store('toast').error(`Rubric validation failed. Issues found:\n${mismatches.join('\n')}`);
                    }
                } else {
                    Alpine.store('toast').error(result.error || 'Failed to validate rubric');
                }
            } catch (error) {
                console.error('Error validating rubric:', error);
                Alpine.store('toast').error('Failed to validate rubric');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Grade all questions
        async gradeAllQuestions() {
            // TODO: Implement proper assignment grading workflow
            Alpine.store('toast').info('Assignment grading workflow needs to be implemented');
        },

        // Review and send grades
        async reviewGrades() {
            navigateTo('review_assignment.html');
        },

        // Force reparse
        async forceReparse() {
            if (this.currentState && this.currentState.content_id) {
                navigateTo('assignment_parse.html');
            } else {
                Alpine.store('toast').error('No assignment selected');
            }
        },

        // Show error state
        showErrorState(message) {
            this.loading = false;
            this.errorMessage = message;
            this.showError = true;
        },

        // Reload page
        reloadPage() {
            location.reload();
        },

        // Go back to assignments
        goBackToAssignments() {
            navigateTo('assignment_list.html');
        }
    }));

    console.log('✅ Assignment status component registered');
});
