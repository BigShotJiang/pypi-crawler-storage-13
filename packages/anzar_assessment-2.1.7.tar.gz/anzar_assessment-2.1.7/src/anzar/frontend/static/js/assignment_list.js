// assignment_list.js - Assignment selection (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('assignmentListPage', () => ({
        // State
        assignments: [],
        filteredAssignments: [],
        searchTerm: '',
        selectedAssignment: null,
        loading: true,
        error: null,
        courseName: '',
        isSelecting: false,

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadContext();
            await this.loadAssignments();
        },

        // Load context
        async loadContext() {
            try {
                const state = await window.api.get_state();
                if (state.course_name) {
                    this.courseName = state.course_name;
                }
            } catch (error) {
                console.error('Error loading state:', error);
            }
        },

        // Load assignments
        async loadAssignments() {
            this.loading = true;
            this.error = null;

            try {
                const result = await window.api.assignment_get_list();

                if (result.success && result.assignments) {
                    this.assignments = result.assignments.sort((a, b) => a.name.localeCompare(b.name));
                    this.filteredAssignments = [...this.assignments];
                    this.loading = false;
                } else {
                    this.error = result.error || 'Failed to load assignments';
                    this.loading = false;
                }
            } catch (error) {
                console.error('Error loading assignments:', error);
                this.error = 'Failed to connect to Canvas';
                this.loading = false;
            }
        },

        // Filter assignments
        filterAssignments() {
            const term = this.searchTerm.toLowerCase();
            if (!term) {
                this.filteredAssignments = [...this.assignments];
            } else {
                this.filteredAssignments = this.assignments.filter(assignment =>
                    assignment.name.toLowerCase().includes(term)
                );
            }
        },

        // Select assignment
        async selectAssignment(assignment) {
            if (this.isSelecting) return;

            this.selectedAssignment = assignment;
            this.isSelecting = true;

            try {
                // Save assignment selection
                await window.api.assignment_select(assignment.id, assignment.name);

                // Navigate with smooth transition
                setTimeout(async () => {
                    await window.api.navigate_to('assignment_download.html');
                }, 500);
            } catch (error) {
                console.error('Error selecting assignment:', error);
                Alpine.store('toast').error('Failed to select assignment: ' + error.message);
                this.selectedAssignment = null;
                this.isSelecting = false;
            }
        },

        // Get card gradient class
        getCardClass(index) {
            return `card-gradient-${(index % 5) + 1}`;
        },

        // Check if assignment is selected
        isSelected(assignmentId) {
            return this.selectedAssignment && this.selectedAssignment.id === assignmentId;
        },

        // Format due date
        formatDueDate(dueAt) {
            if (!dueAt) return 'No due date';
            const date = new Date(dueAt);
            return date.toLocaleDateString() + ' at ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        },

        // Format submission types
        formatSubmissionTypes(types) {
            return types.join(', ');
        }
    }));

    console.log('✅ Assignment list component registered');
});
