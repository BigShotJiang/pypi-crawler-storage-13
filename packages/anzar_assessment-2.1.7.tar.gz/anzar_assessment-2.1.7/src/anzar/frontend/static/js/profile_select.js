// profile_select.js - Profile selection and management (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('profileSelect', () => ({
        // State
        canvasProfiles: [],
        llmProfiles: [],
        selectedCanvasProfile: null,
        selectedLLMProfile: null,
        activeCanvasId: null,
        activeLLMId: null,
        loading: true,
        showMigrateBtn: false,

        // Modal state
        showCanvasModal: false,
        showLLMModal: false,
        canvasModalTitle: 'Add Canvas Profile',
        llmModalTitle: 'Add LLM Profile',

        // Form data
        canvasForm: {
            id: '',
            name: '',
            address: '',
            token: '',
            email: ''
        },
        llmForm: {
            id: '',
            name: '',
            apiLink: '',
            modelName: '',
            token: ''
        },

        // Computed
        get canContinue() {
            return this.selectedCanvasProfile && this.selectedLLMProfile;
        },

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadProfiles();
            await this.checkMigrationNeeded();
        },

        // Load all profiles
        async loadProfiles() {
            this.loading = true;

            try {
                // Load Canvas profiles
                await this.loadCanvasProfiles();

                // Load LLM profiles
                await this.loadLLMProfiles();
            } catch (error) {
                console.error('Error loading profiles:', error);
                Alpine.store('toast').error('Failed to load profiles');
            }

            this.loading = false;
        },

        // Load Canvas profiles
        async loadCanvasProfiles() {
            try {
                const result = await window.api.profile_get_all_canvas();

                if (result.success) {
                    this.canvasProfiles = result.profiles || [];
                    this.activeCanvasId = result.active_id;

                    // Auto-select active profile
                    if (this.activeCanvasId) {
                        const activeProfile = this.canvasProfiles.find(p => p.id === this.activeCanvasId);
                        if (activeProfile) {
                            this.selectedCanvasProfile = activeProfile;
                        }
                    }
                }
            } catch (error) {
                console.error('Error loading Canvas profiles:', error);
            }
        },

        // Load LLM profiles
        async loadLLMProfiles() {
            try {
                const result = await window.api.profile_get_all_llm();

                if (result.success) {
                    this.llmProfiles = result.profiles || [];
                    this.activeLLMId = result.active_id;

                    // Auto-select active profile
                    if (this.activeLLMId) {
                        const activeProfile = this.llmProfiles.find(p => p.id === this.activeLLMId);
                        if (activeProfile) {
                            this.selectedLLMProfile = activeProfile;
                        }
                    }
                }
            } catch (error) {
                console.error('Error loading LLM profiles:', error);
            }
        },

        // Check if migration is needed
        async checkMigrationNeeded() {
            try {
                if (this.canvasProfiles.length === 0 || this.llmProfiles.length === 0) {
                    this.showMigrateBtn = true;
                }
            } catch (error) {
                console.error('Error checking migration:', error);
            }
        },

        // Select Canvas profile
        async selectCanvasProfile(profileId) {
            try {
                const result = await window.api.profile_switch_canvas(profileId);

                if (result.success) {
                    this.selectedCanvasProfile = this.canvasProfiles.find(p => p.id === profileId);
                    this.activeCanvasId = profileId;
                    await this.loadCanvasProfiles();

                    // Auto-progress if both selected
                    this.checkAutoProgress();
                } else {
                    Alpine.store('toast').error('Failed to select profile: ' + result.error);
                }
            } catch (error) {
                console.error('Error selecting Canvas profile:', error);
                Alpine.store('toast').error('Error selecting profile');
            }
        },

        // Select LLM profile
        async selectLLMProfile(profileId) {
            try {
                const result = await window.api.profile_switch_llm(profileId);

                if (result.success) {
                    this.selectedLLMProfile = this.llmProfiles.find(p => p.id === profileId);
                    this.activeLLMId = profileId;
                    await this.loadLLMProfiles();

                    // Auto-progress if both selected
                    this.checkAutoProgress();
                } else {
                    Alpine.store('toast').error('Failed to select profile: ' + result.error);
                }
            } catch (error) {
                console.error('Error selecting LLM profile:', error);
                Alpine.store('toast').error('Error selecting profile');
            }
        },

        // Check auto-progress
        checkAutoProgress() {
            if (this.canContinue) {
                setTimeout(async () => {
                    try {
                        await window.api.navigate_to('connection.html');
                    } catch (error) {
                        console.error('Auto-navigation error:', error);
                    }
                }, 500);
            }
        },

        // Continue with selected profiles
        async continueWithProfiles() {
            if (!this.canContinue) {
                Alpine.store('toast').warning('Please select both Canvas and LLM profiles');
                return;
            }

            try {
                await window.api.navigate_to('connection.html');
            } catch (error) {
                console.error('Navigation error:', error);
                Alpine.store('toast').error('Navigation failed');
            }
        },

        // ===== CANVAS PROFILE MODALS =====

        openAddCanvasModal() {
            this.canvasModalTitle = 'Add Canvas Profile';
            this.canvasForm = {
                id: '',
                name: '',
                address: '',
                token: '',
                email: ''
            };
            this.showCanvasModal = true;
        },

        openEditCanvasModal(profileId) {
            const profile = this.canvasProfiles.find(p => p.id === profileId);
            if (!profile) return;

            this.canvasModalTitle = 'Edit Canvas Profile';
            this.canvasForm = {
                id: profile.id,
                name: profile.name,
                address: profile.canvas_address,
                token: profile.token || '',
                email: profile.email || ''
            };
            this.showCanvasModal = true;
        },

        closeCanvasModal() {
            this.showCanvasModal = false;
        },

        async saveCanvasProfile() {
            const { id, name, address, token, email } = this.canvasForm;

            if (!name || !address || !token) {
                Alpine.store('toast').warning('Please fill in all required fields');
                return;
            }

            try {
                Alpine.store('loading').show('Saving profile...');

                let result;
                if (id) {
                    result = await window.api.profile_update_canvas(id, name, address, token, email);
                } else {
                    result = await window.api.profile_create_canvas(name, address, token, email);
                }

                if (result.success) {
                    Alpine.store('toast').success(id ? 'Profile updated' : 'Profile created');
                    this.closeCanvasModal();
                    await this.loadCanvasProfiles();
                } else {
                    Alpine.store('toast').error('Failed to save profile: ' + result.error);
                }
            } catch (error) {
                console.error('Error saving Canvas profile:', error);
                Alpine.store('toast').error('Error saving profile');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        async deleteCanvasProfile(profileId) {
            if (!confirm('Are you sure you want to delete this Canvas profile?')) {
                return;
            }

            try {
                Alpine.store('loading').show('Deleting profile...');

                const result = await window.api.profile_delete_canvas(profileId);

                if (result.success) {
                    Alpine.store('toast').success('Profile deleted');
                    await this.loadCanvasProfiles();
                } else {
                    Alpine.store('toast').error('Failed to delete profile: ' + result.error);
                }
            } catch (error) {
                console.error('Error deleting Canvas profile:', error);
                Alpine.store('toast').error('Error deleting profile');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // ===== LLM PROFILE MODALS =====

        openAddLLMModal() {
            this.llmModalTitle = 'Add LLM Profile';
            this.llmForm = {
                id: '',
                name: '',
                apiLink: '',
                modelName: '',
                token: ''
            };
            this.showLLMModal = true;
        },

        openEditLLMModal(profileId) {
            const profile = this.llmProfiles.find(p => p.id === profileId);
            if (!profile) return;

            this.llmModalTitle = 'Edit LLM Profile';
            this.llmForm = {
                id: profile.id,
                name: profile.name,
                apiLink: profile.api_link,
                modelName: profile.model_name,
                token: profile.token || ''
            };
            this.showLLMModal = true;
        },

        closeLLMModal() {
            this.showLLMModal = false;
        },

        async saveLLMProfile() {
            const { id, name, apiLink, modelName, token } = this.llmForm;

            if (!name || !apiLink || !modelName || !token) {
                Alpine.store('toast').warning('Please fill in all required fields');
                return;
            }

            try {
                Alpine.store('loading').show('Saving profile...');

                let result;
                if (id) {
                    result = await window.api.profile_update_llm(id, name, apiLink, modelName, token);
                } else {
                    result = await window.api.profile_create_llm(name, apiLink, modelName, token, 'remote');
                }

                if (result.success) {
                    Alpine.store('toast').success(id ? 'Profile updated' : 'Profile created');
                    this.closeLLMModal();
                    await this.loadLLMProfiles();
                } else {
                    Alpine.store('toast').error('Failed to save profile: ' + result.error);
                }
            } catch (error) {
                console.error('Error saving LLM profile:', error);
                Alpine.store('toast').error('Error saving profile');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        async deleteLLMProfile(profileId) {
            if (!confirm('Are you sure you want to delete this LLM profile?')) {
                return;
            }

            try {
                Alpine.store('loading').show('Deleting profile...');

                const result = await window.api.profile_delete_llm(profileId);

                if (result.success) {
                    Alpine.store('toast').success('Profile deleted');
                    await this.loadLLMProfiles();
                } else {
                    Alpine.store('toast').error('Failed to delete profile: ' + result.error);
                }
            } catch (error) {
                console.error('Error deleting LLM profile:', error);
                Alpine.store('toast').error('Error deleting profile');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Helper methods
        isCanvasSelected(profileId) {
            return this.selectedCanvasProfile?.id === profileId;
        },

        isLLMSelected(profileId) {
            return this.selectedLLMProfile?.id === profileId;
        },

        isCanvasActive(profileId) {
            return this.activeCanvasId === profileId;
        },

        isLLMActive(profileId) {
            return this.activeLLMId === profileId;
        }
    }));

    console.log('✅ Profile Select component registered');
});
