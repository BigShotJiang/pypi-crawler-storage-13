// quiz_upload.js - Final Upload Confirmation

document.addEventListener('alpine:init', () => {
    Alpine.data('quizUpload', () => ({
        // State
        statistics: null,
        loading: true,
        targetAssignmentId: null,
        targetAssignmentName: null,
        contentType: '', // 'quiz' or 'assignment'

        // Lifecycle
        async init() {
            console.log('Submission Page: Initializing');

            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            // Detect content type from state
            const state = await window.api.get_state();
            if (state.success && state.state) {
                this.contentType = state.state.content_type || 'assignment';
            }

            // Load target assignment from localStorage (set by rubric.html)
            const targetId = localStorage.getItem('targetAssignmentId');
            this.targetAssignmentId = targetId ? parseInt(targetId) : null;

            // Load assignment name if we have a target
            if (this.targetAssignmentId) {
                try {
                    const result = await window.api.assignment_get_list();
                    if (result.success) {
                        const assignment = result.assignments.find(a => a.id === this.targetAssignmentId);
                        this.targetAssignmentName = assignment?.name || null;
                    }
                } catch (error) {
                    console.error('Failed to load assignment name:', error);
                }
            }

            this.loading = false;
        },

        // Upload grades to Canvas
        async uploadGrades() {
            // Verify target assignment is selected
            if (!this.targetAssignmentId) {
                Alpine.store('toast').error('No target assignment selected. Please select an assignment first.');
                setTimeout(() => navigateTo('rubric.html'), 1500);
                return;
            }

            if (!confirm('Upload all grades to Canvas?\n\nThis will overwrite existing grades and cannot be undone.')) {
                return;
            }

            try {
                Alpine.store('loading').show('Uploading grades to Canvas...');

                // Call appropriate upload API based on content type
                let result;
                if (this.contentType === 'quiz') {
                    result = await window.api.quiz_upload_grades(this.targetAssignmentId);
                } else {
                    result = await window.api.assignment_upload_grades(this.targetAssignmentId);
                }

                if (result.success) {
                    Alpine.store('toast').success('Grades uploaded successfully!');
                    // Clear target assignment after successful upload
                    localStorage.removeItem('targetAssignmentId');
                    setTimeout(() => {
                        navigateTo('dashboard.html');
                    }, 2000);
                } else {
                    Alpine.store('toast').error('Upload failed: ' + (result.error || 'Unknown error'));
                }

            } catch (error) {
                console.error('Upload error:', error);
                Alpine.store('toast').error('Upload failed: ' + error.message);
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Download CSV
        async downloadCSV() {
            try {
                let result;
                if (this.contentType === 'quiz') {
                    result = await window.api.quiz_export_grades();
                } else {
                    result = await window.api.assignment_export_grades();
                }

                if (result.success) {
                    Alpine.store('toast').success('CSV exported successfully');
                } else {
                    Alpine.store('toast').error('Export failed: ' + result.error);
                }

            } catch (error) {
                console.error('Export error:', error);
                Alpine.store('toast').error('Export failed: ' + error.message);
            }
        }
    }));

    console.log('✅ Quiz Upload component registered');
});
