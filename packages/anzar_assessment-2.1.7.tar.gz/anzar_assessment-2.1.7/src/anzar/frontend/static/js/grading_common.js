/**
 * Shared utilities for all grading pages (Alpine.js)
 * Consolidates duplicate code from grade_input.js, grade_review.js, quiz_grading.js
 */

document.addEventListener('alpine:init', () => {
    // Grading State Store (replaces GradingState class)
    Alpine.store('gradingState', {
        /**
         * Set grading state value
         * @param {string} key - State key
         * @param {any} value - Value to store (will be JSON stringified)
         */
        set(key, value) {
            try {
                const fullKey = `grading_${key}`;
                const serialized = JSON.stringify(value);
                localStorage.setItem(fullKey, serialized);
                console.log(`📝 GradingState.set('${key}'):`, value);
            } catch (error) {
                console.error('Error setting grading state:', error);
            }
        },

        /**
         * Get grading state value
         * @param {string} key - State key
         * @returns {any} Parsed value or null
         */
        get(key) {
            try {
                const fullKey = `grading_${key}`;
                const item = localStorage.getItem(fullKey);
                const parsed = item ? JSON.parse(item) : null;
                console.log(`📖 GradingState.get('${key}'):`, parsed);
                return parsed;
            } catch (error) {
                console.error('Error getting grading state:', error);
                return null;
            }
        },

        /**
         * Remove specific state key
         * @param {string} key - State key to remove
         */
        remove(key) {
            localStorage.removeItem(`grading_${key}`);
            console.log(`🗑️ GradingState.remove('${key}')`);
        },

        /**
         * Clear all grading state
         */
        clear() {
            const keys = Object.keys(localStorage).filter(k => k.startsWith('grading_'));
            keys.forEach(k => localStorage.removeItem(k));
            console.log(`🗑️ GradingState.clear(): Removed ${keys.length} keys`);
        },

        /**
         * Check if state key exists
         * @param {string} key - State key
         * @returns {boolean}
         */
        has(key) {
            return localStorage.getItem(`grading_${key}`) !== null;
        }
    });

    // Grading Context Store
    Alpine.store('gradingContext', {
        course: null,
        content: null,
        contentType: null,
        gradedCount: 0,
        totalCount: 0,

        async update() {
            try {
                const state = await window.api.get_state();

                if (state) {
                    this.course = state.course_name || null;
                    this.content = state.content_name || null;
                    this.contentType = state.content_type || null;
                    this.gradedCount = state.graded_questions ? state.graded_questions.length : 0;
                    this.totalCount = state.total_questions || 0;

                    // Update active profiles
                    Alpine.store('activeProfiles').update();
                }

                return state;
            } catch (error) {
                console.error('Error updating context:', error);
                return null;
            }
        },

        get progressPercentage() {
            if (this.totalCount === 0) return 0;
            return Math.round((this.gradedCount / this.totalCount) * 100);
        },

        get contextText() {
            if (!this.course || !this.content) return '';
            const label = this.contentType === 'quiz' ? 'Quiz' : 'Assignment';
            return `Course: ${this.course} > ${label}: ${this.content}`;
        },

        get progressText() {
            return `${this.gradedCount} / ${this.totalCount} questions graded`;
        }
    });
});

// ========================================
// Utility Functions (Pure functions, no DOM manipulation)
// ========================================

/**
 * Format question type for display
 * @param {string} type - Canvas question type
 * @returns {string} Formatted display string
 */
function getQuestionTypeDisplay(type) {
    const typeMap = {
        'multiple_choice_question': '📝 Multiple Choice',
        'true_false_question': '✓ True/False',
        'essay_question': '📄 Essay',
        'short_answer_question': '💬 Short Answer',
        'numerical_question': '🔢 Numerical',
        'calculated_question': '🧮 Calculated',
        'matching_question': '🔗 Matching',
        'multiple_answers_question': '☑️ Multiple Answers',
        'file_upload_question': '📎 File Upload',
        'unknown': '❓ Unknown'
    };
    return typeMap[type] || typeMap['unknown'];
}

/**
 * Check if question is auto-gradable
 * @param {string} questionType - Canvas question type
 * @returns {boolean}
 */
function isAutoGradable(questionType) {
    const autoGradableTypes = [
        'multiple_choice_question',
        'true_false_question',
        'multiple_answers_question',
        'matching_question',
        'numerical_question',
        'calculated_question',
        'formula_question'
    ];
    return autoGradableTypes.includes(questionType);
}

/**
 * Calculate grade percentage
 * @param {number} points - Points earned
 * @param {number} maxPoints - Maximum points
 * @returns {number} Percentage (0-100)
 */
function calculateGradePercentage(points, maxPoints) {
    if (!maxPoints || maxPoints === 0) return 0;
    return Math.round((points / maxPoints) * 100);
}

/**
 * Get grade class for styling
 * @param {number} points - Points earned
 * @param {number} maxPoints - Maximum points
 * @returns {string} CSS class name
 */
function getGradeClass(points, maxPoints) {
    const percentage = calculateGradePercentage(points, maxPoints);
    if (percentage >= 90) return 'grade-excellent';
    if (percentage >= 70) return 'grade-good';
    if (percentage >= 50) return 'grade-fair';
    return 'grade-poor';
}

/**
 * Truncate text to specified length
 * @param {string} text - Text to truncate
 * @param {number} length - Maximum length
 * @returns {string} Truncated text with ellipsis if needed
 */
function truncateText(text, length) {
    if (!text) return '';
    return text.length > length ? text.substring(0, length) + '...' : text;
}

// ========================================
// Backward Compatibility
// ========================================

// Legacy GradingState class (delegates to Alpine store)
class GradingState {
    static set(key, value) {
        Alpine.store('gradingState').set(key, value);
    }

    static get(key) {
        return Alpine.store('gradingState').get(key);
    }

    static remove(key) {
        Alpine.store('gradingState').remove(key);
    }

    static clear() {
        Alpine.store('gradingState').clear();
    }

    static has(key) {
        return Alpine.store('gradingState').has(key);
    }
}

// Legacy functions (delegate to Alpine stores)
async function updateGradingContext() {
    return await Alpine.store('gradingContext').update();
}

function showGradingError(message, title = 'Error') {
    Alpine.store('toast').error(`${title}: ${message}`);
}

function showGradingSuccess(message) {
    Alpine.store('toast').success(message);
}

function showLoadingState(container, message = 'Loading...') {
    if (!container) return;
    container.innerHTML = `
        <div style="text-align: center; padding: 3rem;">
            <div class="spinner-modern" style="margin: 0 auto 1rem;"></div>
            <p style="color: var(--text-secondary);">${message}</p>
        </div>
    `;
}

function showErrorState(container, message) {
    if (!container) return;
    container.innerHTML = `
        <div style="text-align: center; padding: 3rem;">
            <div style="font-size: 3rem; margin-bottom: 1rem;">⚠️</div>
            <p style="color: var(--color-error); font-weight: 600;">Error</p>
            <p style="color: var(--text-secondary); margin-top: 0.5rem;">${message}</p>
            <button onclick="location.reload()" class="btn btn-primary" style="margin-top: 1.5rem;">
                Retry
            </button>
        </div>
    `;
}

function initializeGradingPage(initCallback) {
    console.log('Initializing grading page with common utilities');

    if (window._gradingPageInitialized) {
        console.log('Already initialized, skipping');
        return;
    }
    window._gradingPageInitialized = true;

    if (window.initializeAPI) {
        window.initializeAPI(initCallback);
    } else {
        console.log('API utilities not loaded, using fallback');

        let initialized = false;

        window.addEventListener('pywebviewready', function() {
            if (!initialized) {
                console.log('PyWebView is ready');
                if (window.pywebview && window.pywebview.api) {
                    window.api = window.pywebview.api;
                    initialized = true;
                    initCallback();
                }
            }
        });

        if (window.pywebview && window.pywebview.api && !initialized) {
            window.api = window.pywebview.api;
            initialized = true;
            initCallback();
        }
    }
}

// ========================================
// Export for backward compatibility
// ========================================

window.GradingCommon = {
    initializeGradingPage,
    updateGradingContext,
    GradingState,
    showGradingError,
    showGradingSuccess,
    showLoadingState,
    showErrorState,
    getQuestionTypeDisplay,
    isAutoGradable,
    calculateGradePercentage,
    getGradeClass,
    truncateText
};

console.log('✅ Grading common utilities loaded');
