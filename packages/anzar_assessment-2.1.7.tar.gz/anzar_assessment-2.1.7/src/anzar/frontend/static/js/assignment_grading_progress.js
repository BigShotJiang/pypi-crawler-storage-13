// assignment_grading_progress.js - Multi-question grading progress (Alpine.js)

// Global singleton state to prevent multiple instances
let gradingProgressInstance = null;
let isGradingInProgress = false;

document.addEventListener('alpine:init', () => {
    Alpine.data('assignmentGradingProgress', () => ({
        // State
        questions: [],
        currentQuestionIndex: 0,
        currentQuestionNumber: 1,
        currentQuestionText: '',
        totalQuestions: 0,
        forceRegrade: false,

        isGrading: true,
        gradingComplete: false,
        canStop: true,
        completionMessage: 'Grading Complete!',

        // Progress tracking
        gradingProgress: {
            done: 0,
            total: 0,
            percent: 0,
            currentStudent: '',
            failed: 0
        },

        // Results
        liveResults: [],
        autoScroll: true,

        // Init
        async init() {
            // Singleton protection
            if (gradingProgressInstance) {
                console.warn('⚠️ Assignment Grading Progress instance already exists, skipping initialization');
                return;
            }

            gradingProgressInstance = this;
            console.log('🔍 [JS] Assignment Grading Progress: Initializing');

            // Ensure liveResults is initialized as array
            if (!Array.isArray(this.liveResults)) {
                this.liveResults = [];
            }

            // Load questions from Alpine store
            this.loadQuestions();

            // Register global progress update functions for backend to call
            this.registerProgressHandlers();

            // Wait for API to be ready, then auto-start grading
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.startGradingAllQuestions();
                });
            } else if (window.api) {
                await this.startGradingAllQuestions();
            } else {
                console.error('⚠️ API utilities not loaded');
                this.showError('API not available');
            }
        },

        // Load questions from store
        loadQuestions() {
            try {
                console.log('📥 [progress] Loading questions from Alpine store...');

                const gradingState = Alpine.store('gradingState');

                // Try to get normalized assignment questions first
                let questions = gradingState.get('assignmentQuestions');
                console.log('📥 [progress] Retrieved assignmentQuestions from Alpine store:', questions);

                // Fallback to sessionStorage if Alpine store is empty
                if (!questions || !Array.isArray(questions) || questions.length === 0) {
                    console.warn('⚠️ [progress] Alpine store empty, trying sessionStorage fallback...');
                    const sessionData = sessionStorage.getItem('assignmentQuestions');
                    if (sessionData) {
                        try {
                            questions = JSON.parse(sessionData);
                            console.log('📥 [progress] Loaded from sessionStorage:', questions.length, 'questions');
                        } catch (parseError) {
                            console.error('❌ [progress] Failed to parse sessionStorage data:', parseError);
                        }
                    }
                }

                // Validate we have questions
                if (!questions || !Array.isArray(questions) || questions.length === 0) {
                    console.error('❌ [progress] No questions found in any storage');
                    Alpine.store('toast').error('No questions to grade. Redirecting to setup page...');
                    setTimeout(() => {
                        window.api.navigate_to('assignment_agent_setup.html');
                    }, 2000);
                    return;
                }

                // Validate each question has required data
                const invalidQuestions = questions.filter(q =>
                    !q.question_id ||
                    !q.criteria ||
                    !q.criteria.correct_answer ||
                    !q.criteria.grading_rubric
                );

                if (invalidQuestions.length > 0) {
                    console.error('❌ [progress] Some questions are missing required criteria:', invalidQuestions);
                    Alpine.store('toast').error('Questions are missing grading criteria. Redirecting to setup...');
                    setTimeout(() => {
                        window.api.navigate_to('assignment_agent_setup.html');
                    }, 2000);
                    return;
                }

                // Set questions
                this.questions = questions;
                this.totalQuestions = questions.length;
                this.currentQuestionIndex = 0;
                this.currentQuestionNumber = 1;
                this.currentQuestionText = questions[0].question_text || '';

                // Load forceRegrade flag
                const forceRegradeFromStore = gradingState.get('forceRegrade');
                const forceRegradeFromSession = sessionStorage.getItem('forceRegrade');
                this.forceRegrade = forceRegradeFromStore ||
                    (forceRegradeFromSession ? JSON.parse(forceRegradeFromSession) : false);

                console.log('✅ [progress] Loaded questions:', {
                    totalQuestions: this.totalQuestions,
                    firstQuestionId: questions[0].question_id,
                    firstQuestionHasCriteria: !!questions[0].criteria,
                    forceRegrade: this.forceRegrade
                });

                // Log first question structure for debugging
                console.log('📋 [progress] First question structure:', {
                    questionId: questions[0].question_id,
                    questionText: questions[0].question_text?.substring(0, 50) + '...',
                    criteriaKeys: Object.keys(questions[0].criteria || {}),
                    hasCorrectAnswer: !!questions[0].criteria?.correct_answer,
                    hasGradingRubric: !!questions[0].criteria?.grading_rubric
                });

            } catch (error) {
                console.error('❌ [progress] Error loading questions:', error);
                Alpine.store('toast').error('Failed to load questions. Redirecting to setup...');
                setTimeout(() => {
                    window.api.navigate_to('assignment_agent_setup.html');
                }, 2000);
            }
        },

        // Register global progress handlers for backend
        registerProgressHandlers() {
            const self = this;

            // Force cleanup of any existing handlers to prevent contamination
            if (window.updateProgress) {
                console.warn('⚠️ Cleaning up old updateProgress handler to prevent contamination');
                delete window.updateProgress;
                delete window.finishProgress;
            }

            // Global function called by backend via window.evaluate_js()
            window.updateProgress = function(update) {
                console.log('📊 Progress update received:', update);

                // Update progress stats
                self.gradingProgress = {
                    done: update.done || 0,
                    total: update.total || 0,
                    percent: update.percent || 0,
                    currentStudent: update.sub || '',
                    failed: update.failed || 0
                };

                // Add to live results
                if (update.sub && update.score !== undefined) {
                    // Ensure liveResults is an array before pushing
                    if (!Array.isArray(self.liveResults)) {
                        self.liveResults = [];
                    }

                    // Create unique ID
                    const uniqueId = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

                    const newResult = {
                        studentId: uniqueId,
                        studentName: update.sub,
                        score: update.score,
                        feedback: update.feedback || '',
                        timestamp: new Date().toLocaleTimeString(),
                        success: true
                    };

                    console.log(`📝 Adding result for student: ${update.sub}, score: ${update.score}`);

                    self.liveResults = [...self.liveResults, newResult];

                    // Auto-scroll to bottom if enabled
                    if (self.autoScroll) {
                        self.$nextTick(() => {
                            const feed = document.getElementById('results-feed');
                            if (feed) {
                                const body = feed.querySelector('.results-feed-body');
                                if (body) {
                                    body.scrollTop = body.scrollHeight;
                                }
                            }
                        });
                    }
                }
            };

            // Global function called when grading finishes
            window.finishProgress = function() {
                console.log('✅ Grading finished for current question');
                // Note: We don't set isGrading = false here because we might have more questions
            };

            console.log('✅ Progress handlers registered');
        },

        // Start grading all questions sequentially
        async startGradingAllQuestions() {
            console.log(`🚀 Starting to grade ${this.totalQuestions} question(s)`);

            if (isGradingInProgress) {
                console.warn('⚠️ Grading already in progress, skipping start');
                return;
            }

            try {
                isGradingInProgress = true;

                // Grade each question sequentially
                for (let i = 0; i < this.questions.length; i++) {
                    this.currentQuestionIndex = i;
                    this.currentQuestionNumber = i + 1;
                    this.currentQuestionText = this.questions[i].question_text || '';

                    console.log(`📚 Grading question ${this.currentQuestionNumber}/${this.totalQuestions}: ${this.questions[i].question_id}`);

                    // Clear live results for new question
                    this.liveResults = [];

                    // Grade this question
                    await this.gradeQuestion(this.questions[i]);

                    // Small delay between questions
                    if (i < this.questions.length - 1) {
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    }
                }

                // All questions graded
                isGradingInProgress = false;
                this.isGrading = false;
                this.gradingComplete = true;
                this.canStop = false;
                this.completionMessage = `All ${this.totalQuestions} question(s) graded successfully!`;

                console.log('✅ All questions graded!');

            } catch (error) {
                console.error('❌ Error during multi-question grading:', error);
                isGradingInProgress = false;
                this.isGrading = false;
                this.gradingComplete = true;
                this.canStop = false;
                this.completionMessage = 'Grading failed';
                Alpine.store('toast').error('Grading failed: ' + error.message);
            }
        },

        // Grade a single question
        async gradeQuestion(question) {
            console.log(`🎯 Grading question: ${question.question_id}`);

            try {
                // Question already has normalized structure with criteria object
                const criteria = question.criteria;

                // Validate criteria exists and has required fields
                if (!criteria || !criteria.correct_answer || !criteria.grading_rubric) {
                    throw new Error(`Question ${question.question_id} is missing required criteria (correct_answer or grading_rubric)`);
                }

                console.log(`📊 Starting grading task for question ${question.question_id}`);
                console.log(`📊 Criteria keys:`, Object.keys(criteria));
                console.log(`📊 Force regrade: ${this.forceRegrade}`);

                // Start grading (synchronous call with real-time updates)
                // If forceRegrade=true, grade all students (false = don't skip graded)
                // If forceRegrade=false, grade only ungraded (true = skip graded)
                const gradeOnlyUngraded = !this.forceRegrade;

                const response = await window.api.grading_start_task(
                    question.question_id,
                    criteria,
                    gradeOnlyUngraded
                );

                console.log(`✅ Grading task completed for question ${question.question_id}:`, response);

                if (!response.success) {
                    throw new Error(response.error || 'Grading failed');
                }

                return response;

            } catch (error) {
                console.error(`❌ Error grading question ${question.question_id}:`, error);
                throw error;
            }
        },

        // Stop grading
        async stopGrading() {
            if (!confirm('Are you sure you want to stop grading? Progress will be saved.')) {
                return;
            }

            console.log('⏹️ Stopping grading...');

            try {
                this.canStop = false;
                const response = await window.api.grading_cancel_task();

                if (response.success) {
                    Alpine.store('toast').info('Grading stopped. Progress has been saved.');
                    this.completionMessage = 'Grading Stopped';
                    this.isGrading = false;
                    this.gradingComplete = true;
                    isGradingInProgress = false;
                } else {
                    console.error('Failed to cancel:', response);
                    Alpine.store('toast').error('Failed to stop grading');
                    this.canStop = true;
                }
            } catch (error) {
                console.error('Error stopping grading:', error);
                Alpine.store('toast').error('Error stopping grading');
                this.canStop = true;
            }
        },

        // Navigate to review grades
        async reviewGrades() {
            await window.api.navigate_to('grade_review_v2.html');
        },

        // Back to setup
        async backToSetup() {
            await window.api.navigate_to('assignment_agent_setup.html');
        },

        // Show error
        showError(message) {
            isGradingInProgress = false;
            this.isGrading = false;
            this.gradingComplete = true;
            this.completionMessage = message;
            Alpine.store('toast').error(message);
        },

        // Prepare question text (remove HTML tags safely)
        prepareQuestion(text) {
            if (!text) return '';
            // Basic HTML tag removal for security
            const cleanText = text.replace(/<script.*?>.*?<\/script>/gi, '');
            return cleanText;
        },

        // Cleanup when component is destroyed
        destroy() {
            console.log('🧹 Cleaning up Assignment Grading Progress component');
            isGradingInProgress = false;
            if (window.updateProgress) {
                delete window.updateProgress;
            }
            if (window.finishProgress) {
                delete window.finishProgress;
            }
            gradingProgressInstance = null;
        }
    }));
});

console.log('✅ Assignment Grading Progress component loaded');
