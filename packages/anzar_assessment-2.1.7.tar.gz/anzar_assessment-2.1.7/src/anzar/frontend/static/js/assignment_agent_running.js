// assignment_agent_running.js - Alpine.js conversion

document.addEventListener('alpine:init', () => {
    Alpine.data('assignmentAgentRunning', () => ({
        // State
        agentRunning: false,
        questions: [],
        pollInterval: null,
        logEntries: [],
        logExpanded: true,
        showError: false,
        errorMessage: '',

        // Step states
        steps: {
            extract: { status: 'running', message: 'Initializing...', progress: 0, total: 0 },
            rubric: { status: 'pending', message: 'Waiting...' },
            grading: { status: 'pending', message: 'Waiting...', progress: 0, total: 0 },
            write: { status: 'pending', message: 'Waiting...' },
            complete: { status: 'pending', message: 'Waiting...' }
        },

        // Init
        async init() {
            console.log('Assignment Agent Running: Initializing');

            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.startAgent();
        },

        // Start agent
        async startAgent() {
            try {
                // Get questions from sessionStorage
                const questionsJson = sessionStorage.getItem('agentQuestions');
                if (!questionsJson) {
                    this.showErrorMessage('No questions found. Please go back and set up questions.');
                    return;
                }

                this.questions = JSON.parse(questionsJson);
                this.addLog(`Loaded ${this.questions.length} questions for grading`);

                // DEBUG: Log what fields are actually present in the questions
                console.log('🔍 DEBUG: Questions being sent to agent:');
                this.questions.forEach((q, i) => {
                    console.log(`Question ${i + 1} (ID: ${q.id}):`);
                    console.log(`  - text: ${q.text ? q.text.substring(0, 50) + '...' : 'EMPTY'}`);
                    console.log(`  - points: ${q.points || 'NOT SET'}`);
                    console.log(`  - correct_answer: ${q.correct_answer ? 'SET' : 'EMPTY'} (${(q.correct_answer || '').length} chars)`);
                    console.log(`  - grading_rubric: ${q.grading_rubric ? 'SET' : 'EMPTY'} (${(q.grading_rubric || '').length} chars)`);
                    console.log(`  - feedback_format: ${q.feedback_format ? 'SET' : 'EMPTY'} (${(q.feedback_format || '').length} chars)`);

                    // Show actual feedback_format content if present
                    if (q.feedback_format) {
                        console.log(`  ✅ feedback_format content: "${q.feedback_format}"`);
                    } else {
                        console.log(`  ⚠️ feedback_format is EMPTY!`);
                    }
                });

                // Start agent
                this.addLog('Starting AI grading agent...');
                this.updateStepStatus('extract', 'running', 'Initializing...');

                // Call the agent API
                const result = await window.api.assignment_parse_auto(this.questions);

                if (result.success) {
                    this.addLog('Agent started successfully');
                    this.addLog(`Strategy: ${result.strategy_used}`);

                    // If agent strategy, it runs in background
                    // We need to poll for progress
                    if (result.strategy_used === 'agent') {
                        this.agentRunning = true;
                        this.startPolling();
                    } else {
                        // Metadata strategy completes immediately
                        this.handleMetadataCompletion(result);
                    }
                } else {
                    this.showErrorMessage('Failed to start agent: ' + (result.error || result.message));
                }

            } catch (error) {
                console.error('Error starting agent:', error);
                this.showErrorMessage('Failed to start agent: ' + error.message);
            }
        },

        // Start polling for progress
        startPolling() {
            this.addLog('Monitoring agent progress...');

            // Poll every 2 seconds
            this.pollInterval = setInterval(async () => {
                try {
                    await this.checkAgentProgress();
                } catch (error) {
                    console.error('Error polling agent:', error);
                }
            }, 2000);
        },

        // Check agent progress
        async checkAgentProgress() {
            if (!this.agentRunning) return;

            try {
                // Get real-time progress from CSV analysis
                const progressResult = await window.api.content_analyze_grading_status();

                if (progressResult.success) {
                    const total = progressResult.total_answers || 0;
                    const graded = progressResult.graded_answers || 0;
                    const percent = total > 0 ? Math.round((graded / total) * 100) : 0;

                    // Update grading step progress
                    this.updateStepProgress('grading', graded, total);
                    this.updateStepStatus('grading', graded === total ? 'complete' : 'active',
                        `Grading ${graded}/${total} submissions (${percent}%)`);

                    // If complete, finish up
                    if (graded === total && total > 0) {
                        clearInterval(this.pollInterval);
                        this.updateStepStatus('write', 'complete', 'Results saved to CSV');
                        this.updateStepStatus('complete', 'complete', 'All submissions graded!');
                        this.handleCompletion();
                    }
                }
            } catch (error) {
                console.error('Error checking progress:', error);
            }
        },

        // Update step status
        updateStepStatus(stepId, status, message) {
            this.steps[stepId].status = status;
            this.steps[stepId].message = message;
        },

        // Update progress for a step
        updateStepProgress(stepId, current, total) {
            this.steps[stepId].progress = current;
            this.steps[stepId].total = total;
        },

        // Handle metadata completion
        handleMetadataCompletion(result) {
            this.addLog('Metadata parsing complete');
            this.updateStepStatus('extract', 'completed', 'Complete');
            this.updateStepStatus('complete', 'completed', 'Parsing successful');

            // Metadata workflow goes to question overview, not results page
            setTimeout(() => {
                navigateTo('grading_hub.html');
            }, 2000);
        },

        // Handle completion
        handleCompletion(csvPath) {
            this.agentRunning = false;
            this.addLog('Agent completed successfully!', 'success');

            // Update all steps to completed
            this.updateStepStatus('extract', 'completed', 'Complete');
            this.updateStepStatus('rubric', 'completed', 'Complete');
            this.updateStepStatus('grading', 'completed', 'Complete');
            this.updateStepStatus('write', 'completed', 'Complete');
            this.updateStepStatus('complete', 'completed', 'All done!');

            this.addLog(`CSV created: ${csvPath}`);
            this.addLog('Redirecting to results page...');

            // Redirect to results page
            setTimeout(() => {
                navigateTo('grade_review_v2.html');
            }, 2000);
        },

        // Show error message
        showErrorMessage(message) {
            this.agentRunning = false;
            if (this.pollInterval) {
                clearInterval(this.pollInterval);
            }

            this.errorMessage = message;
            this.showError = true;

            this.addLog('ERROR: ' + message, 'error');
        },

        // Retry agent
        retryAgent() {
            location.reload();
        },

        // Add log entry
        addLog(message, type = 'info') {
            const timestamp = new Date().toLocaleTimeString();
            this.logEntries.push({
                timestamp,
                message,
                type
            });

            // Auto-scroll to bottom after Alpine renders
            this.$nextTick(() => {
                const logContent = this.$refs.logContent;
                if (logContent) {
                    logContent.scrollTop = logContent.scrollHeight;
                }
            });
        },

        // Toggle log visibility
        toggleLog() {
            this.logExpanded = !this.logExpanded;
        },

        // Get step icon class
        getStepIcon(stepId) {
            const step = this.steps[stepId];
            if (step.status === 'completed') return 'ph-check-circle';
            if (step.status === 'running') return 'ph-spinner';
            return 'ph-circle';
        },

        // Get progress percentage
        getProgressPercentage(stepId) {
            const step = this.steps[stepId];
            if (!step.total || step.total === 0) return 0;
            return Math.round((step.progress / step.total) * 100);
        },

        // Cleanup on destroy
        destroy() {
            if (this.pollInterval) {
                clearInterval(this.pollInterval);
            }
        }
    }));

    console.log('✅ Assignment Agent Running component registered');
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    // Alpine will handle cleanup via destroy()
});
