// Modern UI utilities converted to Alpine.js
// This script loads BEFORE Alpine.js to register stores synchronously

console.log('📦 modern-ui.js loading...');

// Wait for Alpine to be available in the global scope
// Then immediately register stores BEFORE Alpine starts processing DOM
document.addEventListener('alpine:init', () => {
    console.log('🎨 alpine:init event fired - registering stores...');

    // Toast Store - Global toast notifications
    Alpine.store('toast', {
        toasts: [],

        show(message, type = 'info', duration = 3000) {
            const id = Date.now();
            const toast = { id, message, type, visible: true };
            this.toasts.push(toast);

            if (duration > 0) {
                setTimeout(() => {
                    this.remove(id);
                }, duration);
            }

            return toast;
        },

        remove(id) {
            const index = this.toasts.findIndex(t => t.id === id);
            if (index > -1) {
                this.toasts.splice(index, 1);
            }
        },

        success(message) { return this.show(message, 'success'); },
        error(message) { return this.show(message, 'error'); },
        warning(message) { return this.show(message, 'warning'); },
        info(message) { return this.show(message, 'info'); }
    });

    // Modal Store - Global modal state
    Alpine.store('modal', {
        isOpen: false,
        title: '',
        content: '',
        footer: '',
        size: 'medium',
        closeButton: true,

        open(options = {}) {
            this.title = options.title || 'Modal';
            this.content = options.content || '';
            this.footer = options.footer || '';
            this.size = options.size || 'medium';
            this.closeButton = options.closeButton !== false;
            this.isOpen = true;

            // Trap focus after DOM updates (use queueMicrotask instead of $nextTick in stores)
            queueMicrotask(() => {
                const modalEl = document.querySelector('.modal-backdrop .modal');
                if (modalEl) {
                    const focusable = modalEl.querySelectorAll(
                        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
                    );
                    if (focusable.length > 0) {
                        focusable[0].focus();
                    }
                }
            });
        },

        close() {
            this.isOpen = false;
        },

        setContent(content) {
            this.content = content;
        }
    });

    // Loading Store - Global loading overlay
    Alpine.store('loading', {
        isVisible: false,
        message: 'Loading...',

        show(message = 'Loading...') {
            this.message = message;
            this.isVisible = true;
        },

        hide() {
            this.isVisible = false;
        }
    });

    // Connection Status Store
    Alpine.store('connectionStatus', {
        status: 'checking',
        text: 'Checking...',

        async update() {
            if (!window.api) return;

            try {
                const canvasStatus = await window.api.connection_test_canvas();
                const llmStatus = await window.api.connection_test_llm();

                if (canvasStatus.success && llmStatus.success) {
                    this.status = 'connected';
                    this.text = 'Connected';
                } else {
                    this.status = 'error';
                    this.text = 'Connection Issue';
                }
            } catch (error) {
                this.status = 'error';
                this.text = 'Offline';
            }
        }
    });

    // Active Profiles Store
    Alpine.store('activeProfiles', {
        canvas: { name: 'No Canvas Profile' },
        llm: { name: 'No LLM Profile' },

        async update() {
            if (!window.api) {
                console.warn('PyWebView API not yet available');
                return;
            }

            try {
                const profiles = await window.api.profile_get_active();
                if (profiles.success) {
                    this.canvas = profiles.profiles.canvas || { name: 'No Canvas Profile' };
                    this.llm = profiles.profiles.llm || { name: 'No LLM Profile' };
                }
            } catch (error) {
                console.error('Error updating profiles:', error);
            }
        }
    });

    // Toast Container Component
    Alpine.data('toastContainer', () => ({
        get toasts() {
            return Alpine.store('toast').toasts;
        },

        getIcon(type) {
            const icons = {
                success: 'ph-check-circle',
                error: 'ph-x-circle',
                warning: 'ph-warning',
                info: 'ph-info'
            };
            return icons[type] || icons.info;
        },

        remove(id) {
            Alpine.store('toast').remove(id);
        }
    }));

    // Modal Component
    Alpine.data('modalComponent', () => ({
        get isOpen() {
            return Alpine.store('modal').isOpen;
        },

        get title() {
            return Alpine.store('modal').title;
        },

        get content() {
            return Alpine.store('modal').content;
        },

        get footer() {
            return Alpine.store('modal').footer;
        },

        get size() {
            return Alpine.store('modal').size;
        },

        get closeButton() {
            return Alpine.store('modal').closeButton;
        },

        close() {
            Alpine.store('modal').close();
        },

        stopPropagation(e) {
            e.stopPropagation();
        }
    }));

    // Loading Overlay Component
    Alpine.data('loadingOverlay', () => ({
        get isVisible() {
            return Alpine.store('loading').isVisible;
        },

        get message() {
            return Alpine.store('loading').message;
        }
    }));

    // Base Layout Component - Sidebar, theme, navigation
    Alpine.data('baseLayout', () => ({
        sidebarCollapsed: false,
        sidebarOpen: false,
        isDark: false,

        init() {
            // Restore sidebar state from localStorage
            this.sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';

            // Restore theme from localStorage
            this.isDark = localStorage.getItem('theme') === 'dark';

            // Update active nav item
            this.updateActiveNav();

            // Initialize profiles and connection status when API becomes available
            if (window.initializeAPI) {
                window.initializeAPI(() => {
                    if (window.updateActiveProfiles) {
                        window.updateActiveProfiles();
                    }
                    if (window.updateConnectionStatus) {
                        window.updateConnectionStatus();
                    }
                });
            }
        },

        toggleSidebar() {
            this.sidebarCollapsed = !this.sidebarCollapsed;
            localStorage.setItem('sidebarCollapsed', this.sidebarCollapsed);
        },

        closeMobileSidebar() {
            this.sidebarOpen = false;
        },

        toggleTheme() {
            this.isDark = !this.isDark;
            localStorage.setItem('theme', this.isDark ? 'dark' : 'light');
        },

        async navigate(page) {
            if (window.api) {
                await window.api.navigate_to(page);
            } else {
                window.location.href = '/frontend/templates/' + page;
            }
        },

        updateActiveNav() {
            const currentPage = window.location.pathname.split('/').pop().replace('.html', '');
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
                if (item.dataset.page === currentPage) {
                    item.classList.add('active');
                }
            });
        }
    }));

    // Initialize backward compatibility layer immediately after stores
    initializeBackwardCompatibility();

    // Initialize UI styles on Alpine init
    initializeUIStyles();

    // Initialize profiles when API is ready
    if (window.initializeAPI) {
        window.initializeAPI(() => {
            Alpine.store('activeProfiles').update();
        });
    }

    console.log('✅ Alpine stores, components, and backward compatibility initialized');
});

function initializeUIStyles() {
    // Add animations CSS
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }

        .toast {
            position: relative;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.875rem 1.25rem;
            background: var(--bg-primary);
            border: 1px solid var(--border-color);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-lg);
            animation: slideIn 0.3s ease;
            min-width: 300px;
            max-width: 500px;
        }

        .toast-close {
            background: transparent;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            padding: 0.25rem;
            margin-left: auto;
        }

        .toast-close:hover {
            color: var(--text-primary);
        }

        .toast-success {
            border-left: 3px solid var(--color-success);
        }

        .toast-error {
            border-left: 3px solid var(--color-danger);
        }

        .toast-warning {
            border-left: 3px solid var(--color-warning);
        }

        .toast-info {
            border-left: 3px solid var(--color-info);
        }

        .modal-small { max-width: 400px; }
        .modal-medium { max-width: 600px; }
        .modal-large { max-width: 800px; }
        .modal-full { max-width: 90%; }
    `;
    document.head.appendChild(style);
}

/**
 * Initialize backward compatibility layer
 * Called after Alpine stores are registered
 */
function initializeBackwardCompatibility() {
    console.log('🔧 Initializing backward compatibility layer...');

    window.toast = {
        show: (msg, type, duration) => Alpine.store('toast').show(msg, type, duration),
        success: (msg) => Alpine.store('toast').success(msg),
        error: (msg) => Alpine.store('toast').error(msg),
        warning: (msg) => Alpine.store('toast').warning(msg),
        info: (msg) => Alpine.store('toast').info(msg)
    };

    window.Modal = class {
        constructor(options) {
            this.options = options;
        }
        open() {
            Alpine.store('modal').open(this.options);
        }
        close() {
            Alpine.store('modal').close();
        }
        setContent(content) {
            Alpine.store('modal').setContent(content);
        }
    };

    window.showModal = function(options) {
        Alpine.store('modal').open(options);
        return {
            close: () => Alpine.store('modal').close(),
            setContent: (content) => Alpine.store('modal').setContent(content)
        };
    };

    window.loading = {
        show: (msg) => Alpine.store('loading').show(msg),
        hide: () => Alpine.store('loading').hide()
    };

    window.updateActiveProfiles = () => Alpine.store('activeProfiles').update();
    window.updateConnectionStatus = () => Alpine.store('connectionStatus').update();

    console.log('✅ Backward compatibility layer initialized');
}
