// grade_input.js - Redesigned for reusable criteria and better UX

// Markdown fallback function
function parseMarkdown(text) {
    if (window.marked) {
        return window.marked.parse(text);
    }
    // Simple fallback for basic markdown
    return text
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/`(.*?)`/g, '<code>$1</code>')
        .replace(/\n/g, '<br>');
}

document.addEventListener('alpine:init', () => {
    Alpine.data('gradeInputPage', () => ({
        // Core State
        questionId: null,
        questionText: '',
        answerCount: 0,
        pointsPossible: 10,
        isQuiz: false,
        isRegrade: false,
        regradeMode: 'ungraded',
        hasData: false,
        initExecuted: false,
        
        // UI State
        samplesCollapsed: true,
        showPromptPreview: false,
        promptContent: '',
        showSaveModal: false,
        newCriteriaName: '',
        expandedSamples: new Set(),

        // Loading states
        isLoadingSampleAnswers: false,
        isLoadingSavedCriteria: false,
        isSavingCriteria: false,
        isStartingGrading: false,

        // Data
        sampleAnswers: [],

        // Reusable Criteria State
        savedCriteria: [],
        selectedCriteria: '',

        // Form State
        form: {
            correct_answer: '',
            grading_rubric: '',
            good_examples: '',
            bad_examples: '',
            graded_examples: '',
            extra_instructions: '',
            feedback_format: 'Provide brief, constructive feedback explaining the grade.',
            default_points: 10,
            partial_credit: 'yes',
        },

        // Computed Properties
        get canStartGrading() {
            return this.form.correct_answer.trim() !== '' && this.form.grading_rubric.trim() !== '';
        },

        get questionTextHtml() {
            return this.questionText ? (window.parseMarkdown ? window.parseMarkdown(this.questionText) : this.questionText) : '';
        },

        get promptContentHtml() {
            if (!this.promptContent) return '';
            if (window.parseMarkdown) {
                return window.parseMarkdown(this.promptContent);
            }
            // Fallback: basic formatting
            return this.promptContent
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\n/g, '<br>');
        },

        // Initialization
        async init() {
            if (this.initExecuted) return;
            this.initExecuted = true;
            console.log("🚀 [grade_input] Initializing grade input page...");

            this.loadQuestionData();

            // Add a small delay to ensure Alpine store is fully populated
            setTimeout(() => {
                if (!this.hasData) {
                    console.log("🔄 [grade_input] Retrying question data load...");
                    this.loadQuestionData();
                }
            }, 100);

            if (window.initializeAPI) {
                window.initializeAPI(() => {
                    console.log("🔧 [grade_input] API initialized, loading backend data...");
                    this.loadBackendData();
                });
            } else if (window.api) {
                console.log("🔧 [grade_input] API available, loading backend data...");
                this.loadBackendData();
            } else {
                console.warn("⚠️ [grade_input] API not available yet, will retry later");
                // Retry after a short delay
                setTimeout(() => {
                    if (window.api) {
                        console.log("🔧 [grade_input] API now available, loading backend data...");
                        this.loadBackendData();
                    } else {
                        console.error("❌ [grade_input] API still not available after retry");
                    }
                }, 500);
            }
        },

        loadQuestionData() {
            console.log("📋 [grade_input] Loading question data...");
            const data = Alpine.store('gradingState')?.get('questionData');
            console.log("📋 [grade_input] Question data from store:", data);

            if (data) {
                // Validate data integrity before loading
                if (!data.questionId) {
                    console.error("❌ [grade_input] Invalid question data: missing questionId");
                    this.cleanupContaminatedState();
                    this.hasData = false;
                    return;
                }

                // Check for potential data contamination (mixed question data)
                const gradingState = Alpine.store('gradingState');
                const storedQuestionId = gradingState.get('gradingQuestionId');
                if (storedQuestionId && storedQuestionId !== data.questionId) {
                    console.warn("⚠️ [grade_input] Question ID mismatch detected, cleaning contaminated state:", {
                        currentQuestionId: data.questionId,
                        storedQuestionId: storedQuestionId
                    });
                    this.cleanupContaminatedState();
                    // Reload data after cleanup
                    return this.loadQuestionData();
                }

                this.questionId = data.questionId;
                this.questionText = data.questionText || '';
                this.answerCount = parseInt(data.answerCount) || 0;
                this.pointsPossible = parseFloat(data.pointsPossible) || 10;
                this.form.defaultPoints = this.pointsPossible;
                this.isQuiz = data.isQuiz || false;
                this.isRegrade = data.isRegrade || false;
                this.regradeMode = data.regradeMode || 'ungraded';
                this.hasData = true;

                // Clean up sample answers that might belong to previous questions
                this.sampleAnswers = [];
                console.log("🧹 [grade_input] Clearing local sample answers from previous questions");

                console.log("✅ [grade_input] Question data loaded successfully:", {
                    questionId: this.questionId,
                    hasQuestionText: !!this.questionText,
                    answerCount: this.answerCount,
                    pointsPossible: this.pointsPossible,
                    isQuiz: this.isQuiz,
                    isRegrade: this.isRegrade
                });
            } else {
                console.error("❌ [grade_input] No question data found in Alpine store.");
                console.log("📋 [grade_input] Available Alpine stores:", Object.keys(Alpine.store('gradingState')?._data || {}));
                this.hasData = false;
            }
        },

        // Clean up contaminated state from previous questions
        cleanupContaminatedState() {
            const gradingState = Alpine.store('gradingState');
            console.log("🧹 [grade_input] Cleaning contaminated grading state...");

            const keysToRemove = [
                'questionData',
                'gradingCriteria',
                'gradingQuestionId',
                'gradeOnlyUngraded'
            ];

            keysToRemove.forEach(key => {
                if (gradingState.get(key)) {
                    console.log(`🧹 [grade_input] Removing contaminated ${key} from state`);
                    gradingState.remove(key);
                }
            });
        },

        async loadBackendData() {
            console.log("🔧 [grade_input] Loading backend data...");
            if (!this.hasData) {
                console.log("❌ [grade_input] No question data available, skipping backend data load");
                return;
            }

            try {
                // Load sample answers and saved criteria in parallel
                await Promise.all([
                    this.loadSampleAnswers(),
                    this.loadSavedCriteria()
                ]);
                console.log("✅ [grade_input] Backend data loaded successfully");
            } catch (error) {
                console.error("❌ [grade_input] Error loading backend data:", error);
                Alpine.store('toast').error('Some data failed to load. You can still proceed with grading.');
            }
        },

        // Sample Answers Logic
        async loadSampleAnswers() {
            console.log("📚 [grade_input] Loading sample answers...");
            this.isLoadingSampleAnswers = true;
            const methodName = this.isQuiz ? 'quiz_get_sample_answers' : 'assignment_get_sample_answers';
            console.log("📚 [grade_input] Using method:", methodName, "for questionId:", this.questionId);

            try {
                const response = await window.api[methodName](this.questionId, 5);
                console.log("📚 [grade_input] Sample answers response:", response);

                if (response.success) {
                    const samples = response.samples || [];
                    console.log("📚 [grade_input] Loaded", samples.length, "sample answers");
                    this.sampleAnswers = samples;

                    if (samples.length > 0) {
                        console.log("📚 [grade_input] First sample preview:", {
                            student_name: samples[0].student_name,
                            has_answer: !!samples[0].student_answer,
                            answer_length: samples[0].student_answer ? samples[0].student_answer.length : 0
                        });
                    }
                } else {
                    console.error("❌ [grade_input] API error loading sample answers:", response.error);
                    Alpine.store('toast').error(response.error || 'Failed to load sample answers');
                }
            } catch (error) {
                console.error("❌ [grade_input] Exception loading sample answers:", error);
                Alpine.store('toast').error('Failed to load sample answers. Please try again.');
            } finally {
                this.isLoadingSampleAnswers = false;
            }
        },

        // Sample answer expansion
        toggleSampleExpansion(index) {
            if (this.expandedSamples.has(index)) {
                this.expandedSamples.delete(index);
            } else {
                this.expandedSamples.add(index);
            }
            // Force Alpine to detect the change
            this.expandedSamples = new Set(this.expandedSamples);
        },

        isSampleExpanded(index) {
            return this.expandedSamples.has(index);
        },

        shouldTruncate(answer) {
            return answer && answer.length > 200;
        },

        // Reusable Criteria Logic
        async loadSavedCriteria() {
            this.isLoadingSavedCriteria = true;
            try {
                const state = await window.api.get_state();
                const response = await window.api.criteria_get(state.course_id, state.content_id, state.content_type);
                if (response.success) {
                    this.savedCriteria = response.criteria || [];
                } else {
                    Alpine.store('toast').error(response.error || 'Failed to load saved criteria');
                }
            } catch (error) {
                console.error('Error loading saved criteria:', error);
                Alpine.store('toast').error('Failed to load saved criteria. Please try again.');
            } finally {
                this.isLoadingSavedCriteria = false;
            }
        },

        applySelectedCriteria() {
            if (!this.selectedCriteria) return;
            const selected = this.savedCriteria.find(c => c.name === this.selectedCriteria);
            if (selected && selected.criteria) {
                // Update form state with loaded criteria
                Object.keys(this.form).forEach(key => {
                    if (selected.criteria[key] !== undefined) {
                        this.form[key] = selected.criteria[key];
                    }
                });
                Alpine.store('toast').success(`Criteria '${this.selectedCriteria}' loaded.`);
            }
        },

        async handleSaveCriteria() {
            if (!this.newCriteriaName.trim()) {
                Alpine.store('toast').error('Please enter a name for the criteria.');
                return;
            }
            this.isSavingCriteria = true;
            try {
                const state = await window.api.get_state();
                const response = await window.api.criteria_save(
                    this.newCriteriaName,
                    this.form,
                    state.course_id,
                    state.content_id,
                    state.content_type
                );

                if (response.success) {
                    Alpine.store('toast').success(response.message || 'Criteria saved successfully');
                    this.showSaveModal = false;
                    this.newCriteriaName = '';
                    await this.loadSavedCriteria(); // Refresh the list
                } else {
                    Alpine.store('toast').error(response.error || 'Failed to save criteria');
                }
            } catch (error) {
                console.error('Error saving criteria:', error);
                Alpine.store('toast').error('Failed to save criteria. Please try again.');
            } finally {
                this.isSavingCriteria = false;
            }
        },

        // Main Grading Action
        async startGrading() {
            if (!this.canStartGrading) return;
            this.isStartingGrading = true;

            try {
                // PRE-FLIGHT CHECK: Verify LLM connectivity before proceeding
                const llmReady = await checkLLMConnectionBeforeGrading();
                if (!llmReady) {
                    this.isStartingGrading = false;
                    return; // Abort grading if LLM is not reachable
                }

                const gradingState = Alpine.store('gradingState');

                // Final validation to ensure data consistency before starting grading
                const storedQuestionData = gradingState.get('questionData');
                if (storedQuestionData && storedQuestionData.questionId !== this.questionId) {
                    console.error('❌ [grade_input] Critical inconsistency detected:', {
                        currentQuestionId: this.questionId,
                        storedQuestionId: storedQuestionData.questionId
                    });
                    Alpine.store('toast').error('Data inconsistency detected. Please refresh the page and try again.');
                    return;
                }

                // Form already uses snake_case, just add max_points
                const criteria = {
                    ...this.form,
                    max_points: this.pointsPossible || this.form.default_points || 10
                };

                // Store comprehensive grading data for progress page
                gradingState.set('gradingCriteria', criteria);
                gradingState.set('gradingQuestionId', this.questionId);
                gradingState.set('gradeOnlyUngraded', !this.isRegrade || this.regradeMode === 'ungraded');

                // Ensure questionData is available and updated with current state
                const existingQuestionData = gradingState.get('questionData') || {};
                gradingState.set('questionData', {
                    ...existingQuestionData,
                    questionId: this.questionId,
                    questionText: this.questionText,
                    isQuiz: this.isQuiz,
                    isRegrade: this.isRegrade,
                    regradeMode: this.regradeMode,
                    pointsPossible: this.pointsPossible,
                    answerCount: this.answerCount
                });

                console.log('📤 [grade_input] Storing grading data:', {
                    criteriaKeys: Object.keys(criteria),
                    questionId: this.questionId,
                    isRegrade: this.isRegrade,
                    regradeMode: this.regradeMode,
                    pointsPossible: this.pointsPossible,
                    gradeOnlyUngraded: !this.isRegrade || this.regradeMode === 'ungraded'
                });

                await window.api.navigate_to('quiz_grading_progress.html');
            } catch (error) {
                console.error('Error starting grading:', error);
                Alpine.store('toast').error('Failed to start grading. Please try again.');
            } finally {
                this.isStartingGrading = false;
            }
        },

        // UI Actions
        async showPromptPreviewModal() {
            const criteria = { ...this.form };
            // This formatting should ideally be done on the backend to be 100% accurate,
            // but a frontend preview is good for UX.
            this.promptContent = `You are a teacher grading a student's answer.

**Question:**
${this.questionText || 'No question text available'}

**Student's Answer:**
[Sample Student Answer would appear here]

**Grading Criteria:**

**Correct Answer / Key Points:**
${criteria.correct_answer || 'Not specified'}

**Maximum Points:**
${this.pointsPossible || criteria.default_points || 10}

**Grading Rubric:**
${criteria.grading_rubric || 'Not specified'}

**Examples of Good Answers:**
${criteria.good_examples || 'Not provided'}

**Examples of Poor Answers:**
${criteria.bad_examples || 'Not provided'}

**Feedback Format Instructions:**
${criteria.feedback_format || 'Provide brief, constructive feedback explaining the grade.'}

**Additional Instructions:**
- Consider partial credit where appropriate
- Use the examples to guide your assessment
- Follow the feedback format when providing explanations
- Be constructive and educational in your feedback

**Response Format:**
Please respond in JSON format:
{
    "points": <number between 0 and ${this.pointsPossible || 10}>,
    "feedback": "<detailed explanation of the grade following the feedback format>"
}`;
            this.showPromptPreview = true;
        },

        skipQuestion() {
            window.api.navigate_to('grading_hub.html');
        },

        cancelGrading() {
            window.api.navigate_to('dashboard.html');
        },

        async navigateToConsistency() {
            // Validate required fields before navigating
            if (!this.form.correct_answer.trim() || !this.form.grading_rubric.trim()) {
                Alpine.store('toast').error('Please provide both correct answer and grading rubric before checking consistency.');
                return;
            }

            // PRE-FLIGHT CHECK: Verify LLM connectivity before proceeding
            const llmReady = await checkLLMConnectionBeforeConsistency();
            if (!llmReady) {
                return; // Abort consistency check if LLM is not reachable
            }

            try {
                const gradingState = Alpine.store('gradingState');

                // Store return destination for smart back navigation
                gradingState.set('returnTo', 'grade_input.html');

                // Store the complete form data as gradingCriteria (matches assignment workflow format)
                gradingState.set('gradingCriteria', this.form);
                gradingState.set('gradingQuestionId', this.questionId);
                gradingState.set('gradingQuestionText', this.questionText);

                // Store the complete question data for consistency checker
                gradingState.set('questionData', {
                    questionId: this.questionId,
                    questionText: this.questionText,
                    pointsPossible: this.pointsPossible,
                    isQuiz: this.isQuiz,
                    answerCount: this.answerCount,
                    // Include the form data as the question object structure
                    ...this.form
                });

                // Load sample answers for consistency check (like assignment workflow)
                console.log("📚 [grade_input] Loading sample answers for consistency check...");
                const methodName = this.isQuiz ? 'quiz_get_sample_answers' : 'assignment_get_sample_answers';

                const response = await window.api[methodName](this.questionId, 50);
                if (response.success && response.samples && response.samples.length > 0) {
                    console.log(`📚 [grade_input] Loaded ${response.samples.length} sample answers for consistency`);
                    gradingState.set('sampleAnswers', response.samples);
                } else {
                    Alpine.store('toast').error('No sample answers found for this question. Cannot run consistency check.');
                    return;
                }

                console.log('✅ [grade_input] Navigating to consistency checker with complete data');
                // Use the same quiz_consistency.html for both quiz and assignment workflows
                window.api.navigate_to('quiz_consistency.html');

            } catch (error) {
                console.error('❌ [grade_input] Error preparing consistency check:', error);
                Alpine.store('toast').error('Failed to prepare consistency check: ' + error.message);
            }
        },
    }));
});


// ============================================================================
// REAL-TIME PROGRESS TRACKING
// Global functions for Python to call via window.evaluate_js()
// ============================================================================

window.updateProgress = function(data) {
    console.log('📊 Grading progress update:', data);

    try {
        // Find the grade input page component
        const page = document.querySelector('[x-data*="gradeInputPage"]');
        if (page && page.__x) {
            const component = page.__x.$data;

            // Update progress state if component has progress tracking
            if (component.showLiveGrading) {
                // Update any progress indicators in the component
                // The actual grading is synchronous/blocking for now,
                // but this allows for console logging and future enhancements
                console.log(`Progress: ${data.done}/${data.total} (${data.percent}%)`);
                console.log(`Current: ${data.sub} - ${data.score} pts`);
            }
        }

        // Could also update DOM directly if needed for progress bar
        const progressContainer = document.getElementById('grading-in-progress-container');
        if (progressContainer && progressContainer.style.display !== 'none') {
            // Future enhancement: Add live progress bar here
            console.log(`Student "${data.sub}" graded: ${data.score} pts`);
        }

    } catch (error) {
        console.error('Error in updateProgress:', error);
    }
};

window.finishProgress = function() {
    console.log('✅ Grading completed successfully!');
    // Completion is handled by the API response
};