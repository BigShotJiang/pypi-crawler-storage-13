// review_assignment.js - Assignment review and grade submission
// Modern version using window.api instead of window.pywebview.api

let currentState = null;
let gradeData = [];
let assignments = [];

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded');
    
    // Use API utilities to initialize
    if (window.initializeAPI) {
        window.initializeAPI(initializePage);
    } else {
        // Fallback if utilities not loaded
        console.log('API utilities not loaded, using fallback');
        
        // Wait for pywebview to be ready
        window.addEventListener('pywebviewready', function() {
            console.log('PyWebView is ready');
            if (window.pywebview && window.pywebview.api) {
                window.api = window.pywebview.api;
                initializePage();
            }
        });
        
        // Check if already available
        if (window.pywebview && window.pywebview.api) {
            window.api = window.pywebview.api;
            initializePage();
        }
    }
});

async function initializePage() {
    if (!window.api) {
        console.error('API not available');
        setTimeout(() => {
            if (window.api) {
                initializePage();
            }
        }, 500);
        return;
    }
    
    const loadingDiv = document.getElementById('loading-review');
    const reviewContent = document.getElementById('review-content');
    const errorContainer = document.getElementById('error-container');
    const errorMessage = document.getElementById('error-message');
    const gradesTableBody = document.getElementById('grades-tbody');
    const targetAssignmentSelect = document.getElementById('target-assignment');
    const sendingGrades = document.getElementById('sending-grades');
    const sendComplete = document.getElementById('send-complete');
    const sendMessage = document.getElementById('send-message');
    
    // Summary elements
    const totalStudentsElement = document.getElementById('total-students');
    const averageScoreElement = document.getElementById('average-score');
    const highestScoreElement = document.getElementById('highest-score');
    const lowestScoreElement = document.getElementById('lowest-score');
    const distributionChart = document.getElementById('distribution-chart');
    
    // Buttons
    const sendGradesBtn = document.getElementById('send-grades-btn');
    const downloadCsvBtn = document.getElementById('download-csv-btn');
    const backBtn = document.getElementById('back-btn');
    const finishBtn = document.getElementById('finish-btn');
    
    async function updateContext() {
        try {
            const state = await window.api.get_state();
            currentState = state;
            
            // Update active profiles in the header if available
            if (window.updateActiveProfiles) {
                window.updateActiveProfiles();
            }
            
            // Update connection status
            // Removed automatic connection testing - only test on initial load
        } catch (error) {
            console.error('Error loading state:', error);
        }
    }
    
    async function loadGradeData() {
        try {
            // In a real implementation, this would load grade data from the CSV
            // For now, we'll simulate some data
            const result = await window.api.get_state();
            
            if (result.csv_path) {
                // Load assignments for target selection
                await loadAssignments();
                
                // Simulate grade data (in reality, this would parse the CSV)
                gradeData = generateSampleGradeData();
                
                displayGradeSummary();
                displayGradeDistribution();
                displayStudentGrades();
                
                loadingDiv.classList.add('hidden');
                reviewContent.classList.remove('hidden');
            } else {
                showError('No grade data found. Please complete grading first.');
            }
        } catch (error) {
            console.error('Error loading grade data:', error);
            showError('Failed to load grade data');
        }
    }
    
    async function loadAssignments() {
        try {
            const result = await window.api.assignment_get_list();
            
            if (result.success && result.assignments) {
                assignments = result.assignments;
                
                // Populate target assignment dropdown
                targetAssignmentSelect.innerHTML = '<option value="">Use original assignment</option>';
                
                assignments.forEach(assignment => {
                    if (assignment.id !== currentState.content_id) {
                        const option = document.createElement('option');
                        option.value = assignment.id;
                        option.textContent = assignment.name;
                        targetAssignmentSelect.appendChild(option);
                    }
                });
            }
        } catch (error) {
            console.error('Error loading assignments:', error);
        }
    }
    
    function generateSampleGradeData() {
        // This is sample data - in reality, this would come from the CSV
        const sampleData = [];
        const studentCount = 25;
        
        for (let i = 0; i < studentCount; i++) {
            const score = Math.floor(Math.random() * 30) + 70; // 70-100 range
            sampleData.push({
                student_name: `Student ${i + 1}`,
                student_id: `100${i + 1}`,
                score: score,
                max_score: 100,
                percentage: score
            });
        }
        
        return sampleData;
    }
    
    function displayGradeSummary() {
        const totalStudents = gradeData.length;
        const scores = gradeData.map(g => g.percentage);
        const averageScore = scores.reduce((a, b) => a + b, 0) / totalStudents;
        const highestScore = Math.max(...scores);
        const lowestScore = Math.min(...scores);
        
        totalStudentsElement.textContent = totalStudents;
        averageScoreElement.textContent = `${averageScore.toFixed(1)}%`;
        highestScoreElement.textContent = `${highestScore}%`;
        lowestScoreElement.textContent = `${lowestScore}%`;
    }
    
    function displayGradeDistribution() {
        const distribution = {
            'A (90-100)': 0,
            'B (80-89)': 0,
            'C (70-79)': 0,
            'D (60-69)': 0,
            'F (0-59)': 0
        };
        
        gradeData.forEach(grade => {
            const score = grade.percentage;
            if (score >= 90) distribution['A (90-100)']++;
            else if (score >= 80) distribution['B (80-89)']++;
            else if (score >= 70) distribution['C (70-79)']++;
            else if (score >= 60) distribution['D (60-69)']++;
            else distribution['F (0-59)']++;
        });
        
        distributionChart.innerHTML = '';
        const maxCount = Math.max(...Object.values(distribution));
        
        Object.entries(distribution).forEach(([grade, count]) => {
            const percentage = (count / gradeData.length) * 100;
            const barWidth = maxCount > 0 ? (count / maxCount) * 100 : 0;
            
            const bar = document.createElement('div');
            bar.className = 'distribution-bar';
            bar.innerHTML = `
                <div class="bar-label">${grade}</div>
                <div class="bar-container">
                    <div class="bar-fill" style="width: ${barWidth}%"></div>
                </div>
                <div class="bar-count">${count} (${percentage.toFixed(1)}%)</div>
            `;
            distributionChart.appendChild(bar);
        });
    }
    
    function displayStudentGrades() {
        gradesTableBody.innerHTML = '';
        
        // Sort by student name
        const sortedGrades = [...gradeData].sort((a, b) => 
            a.student_name.localeCompare(b.student_name)
        );
        
        // Display first 10 students
        const displayCount = Math.min(10, sortedGrades.length);
        
        for (let i = 0; i < displayCount; i++) {
            const grade = sortedGrades[i];
            const row = document.createElement('tr');
            
            row.innerHTML = `
                <td>${escapeHtml(grade.student_name)}</td>
                <td>${escapeHtml(grade.student_id)}</td>
                <td>${grade.score} / ${grade.max_score}</td>
                <td class="${getGradeClass(grade.percentage)}">${grade.percentage}%</td>
            `;
            
            gradesTableBody.appendChild(row);
        }
        
        if (sortedGrades.length > 10) {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td colspan="4" class="text-center text-secondary">
                    ... and ${sortedGrades.length - 10} more students
                </td>
            `;
            gradesTableBody.appendChild(row);
        }
    }
    
    function getGradeClass(percentage) {
        if (percentage >= 90) return 'grade-a';
        if (percentage >= 80) return 'grade-b';
        if (percentage >= 70) return 'grade-c';
        if (percentage >= 60) return 'grade-d';
        return 'grade-f';
    }
    
    async function sendGrades() {
        reviewContent.classList.add('hidden');
        sendingGrades.classList.remove('hidden');
        
        try {
            const targetAssignmentId = targetAssignmentSelect.value || null;
            const result = await window.api.grades_send_to_canvas(targetAssignmentId);
            
            if (result.success) {
                sendingGrades.classList.add('hidden');
                sendMessage.textContent = result.message || 'All grades have been successfully sent to Canvas.';
                sendComplete.classList.remove('hidden');
            } else {
                sendingGrades.classList.add('hidden');
                reviewContent.classList.remove('hidden');
                showToast('error', 'Failed to send grades: ' + (result.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error sending grades:', error);
            sendingGrades.classList.add('hidden');
            reviewContent.classList.remove('hidden');
            showToast('error', 'Failed to send grades: ' + error.message);
        }
    }
    
    function downloadCSV() {
        // In a real implementation, this would download the CSV file
        if (currentState && currentState.csv_path) {
            showToast('info', `CSV file location: ${currentState.csv_path}`);
        } else {
            showToast('warning', 'No CSV file available');
        }
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    function showError(message) {
        loadingDiv.classList.add('hidden');
        reviewContent.classList.add('hidden');
        errorMessage.textContent = message;
        errorContainer.classList.remove('hidden');
    }
    
    function showToast(type, message) {
        // Use the modern toast notification if available
        if (window.showToast) {
            window.showToast(message, type);
        } else {
            // Fallback to alert
            alert(message);
        }
    }
    
    // Event handlers
    sendGradesBtn.addEventListener('click', async () => {
        // First get the grades preview
        let gradesPreview = null;
        try {
            const previewResult = await window.api.grades_get_preview();
            if (previewResult.success) {
                gradesPreview = previewResult;
            }
        } catch (error) {
            console.error('Error getting grades preview:', error);
        }
        
        // Create a modern confirmation dialog
        const confirmDialog = document.createElement('div');
        confirmDialog.className = 'modal-backdrop';
        confirmDialog.innerHTML = `
            <div class="modal">
                <div class="modal-header">
                    <h3 class="modal-title">Confirm Grade Submission</h3>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning mb-3">
                        <i class="ph-warning"></i>
                        <p><strong>Important:</strong> This action will send grades to Canvas and cannot be undone.</p>
                    </div>
                    <p>Are you sure you want to send these grades?</p>
                    <div class="summary-list">
                        <div class="summary-item">
                            <span class="summary-label">Course:</span>
                            <span class="summary-value">${currentState?.course_name || 'Unknown'}</span>
                        </div>
                        <div class="summary-item">
                            <span class="summary-label">Assignment:</span>
                            <span class="summary-value">${currentState?.content_name || 'Unknown'}</span>
                        </div>
                        <div class="summary-item">
                            <span class="summary-label">Target:</span>
                            <span class="summary-value">${targetAssignmentSelect.options[targetAssignmentSelect.selectedIndex]?.text || 'Same Assignment'}</span>
                        </div>
                        <div class="summary-item">
                            <span class="summary-label">Questions:</span>
                            <span class="summary-value">${currentState?.total_questions || 0}</span>
                        </div>
                    </div>
                    ${gradesPreview && gradesPreview.preview ? `
                        <h4 class="section-title mt-4">Grades Preview (${gradesPreview.graded_students} of ${gradesPreview.total_students} students):</h4>
                        <div class="preview-table-wrapper">
                            <table class="preview-table">
                                <thead>
                                    <tr>
                                        <th>Student</th>
                                        <th>Score</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${gradesPreview.preview.slice(0, 10).map(student => `
                                        <tr>
                                            <td>${student.student_name}</td>
                                            <td>${student.total_score}/${student.total_possible}</td>
                                        </tr>
                                    `).join('')}
                                    ${gradesPreview.preview.length > 10 ? `
                                        <tr>
                                            <td colspan="2" class="text-center text-secondary">
                                                ... and ${gradesPreview.preview.length - 10} more students
                                            </td>
                                        </tr>
                                    ` : ''}
                                </tbody>
                            </table>
                        </div>
                    ` : ''}
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" id="confirm-send">
                        <i class="ph-check"></i>
                        Yes, Send Grades
                    </button>
                    <button class="btn btn-secondary" id="cancel-send">
                        <i class="ph-x"></i>
                        Cancel
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(confirmDialog);
        
        // Add modal styles if not already present
        if (!document.getElementById('modal-styles')) {
            const modalStyles = document.createElement('style');
            modalStyles.id = 'modal-styles';
            modalStyles.textContent = `
                .modal-backdrop {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.5);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 1000;
                    animation: fadeIn 0.2s ease;
                }
                
                .modal {
                    background: var(--bg-primary);
                    border-radius: var(--radius-lg);
                    max-width: 600px;
                    width: 90%;
                    max-height: 80vh;
                    overflow: hidden;
                    box-shadow: var(--shadow-xl);
                    animation: slideIn 0.3s ease;
                }
                
                .modal-header {
                    padding: 1.5rem;
                    border-bottom: 1px solid var(--border-color);
                }
                
                .modal-title {
                    font-size: 1.25rem;
                    font-weight: 600;
                    color: var(--text-primary);
                    margin: 0;
                }
                
                .modal-body {
                    padding: 1.5rem;
                    max-height: calc(80vh - 140px);
                    overflow-y: auto;
                }
                
                .modal-footer {
                    padding: 1rem 1.5rem;
                    border-top: 1px solid var(--border-color);
                    display: flex;
                    justify-content: flex-end;
                    gap: 0.75rem;
                }
                
                .summary-list {
                    background: var(--bg-secondary);
                    border-radius: var(--radius-md);
                    padding: 1rem;
                    margin: 1rem 0;
                }
                
                .summary-item {
                    display: flex;
                    justify-content: space-between;
                    padding: 0.5rem 0;
                    border-bottom: 1px solid var(--border-color);
                }
                
                .summary-item:last-child {
                    border-bottom: none;
                }
                
                .preview-table-wrapper {
                    max-height: 200px;
                    overflow-y: auto;
                    border: 1px solid var(--border-color);
                    border-radius: var(--radius-md);
                }
                
                .preview-table {
                    width: 100%;
                    font-size: 0.875rem;
                }
                
                .preview-table th,
                .preview-table td {
                    padding: 0.5rem;
                    text-align: left;
                    border-bottom: 1px solid var(--border-color);
                }
                
                .preview-table th {
                    background: var(--bg-secondary);
                    font-weight: 600;
                    position: sticky;
                    top: 0;
                }
                
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                
                @keyframes slideIn {
                    from {
                        transform: translateY(-20px);
                        opacity: 0;
                    }
                    to {
                        transform: translateY(0);
                        opacity: 1;
                    }
                }
            `;
            document.head.appendChild(modalStyles);
        }
        
        document.getElementById('confirm-send').addEventListener('click', async () => {
            document.body.removeChild(confirmDialog);
            await sendGrades();
        });
        
        document.getElementById('cancel-send').addEventListener('click', () => {
            document.body.removeChild(confirmDialog);
        });
        
        // Close on backdrop click
        confirmDialog.addEventListener('click', (e) => {
            if (e.target === confirmDialog) {
                document.body.removeChild(confirmDialog);
            }
        });
    });
    
    downloadCsvBtn.addEventListener('click', downloadCSV);
    
    backBtn.addEventListener('click', async () => {
        await window.api.navigate_to('grading_hub.html');
    });
    
    finishBtn.addEventListener('click', async () => {
        await window.api.navigate_to('dashboard.html');
    });
    
    // Initialize
    await updateContext();
    await loadGradeData();
}