// content_select.js - Content type selection (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('contentSelectPage', () => ({
        // State
        selectedType: null,
        courseName: '',

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadContext();
        },

        // Load current context
        async loadContext() {
            try {
                const state = await window.api.get_state();
                if (state.course_name) {
                    this.courseName = state.course_name;
                }
            } catch (error) {
                console.error('Error loading state:', error);
            }
        },

        // Select content type
        async selectType(type) {
            this.selectedType = type;

            // Store selection for content_list page
            sessionStorage.setItem('contentType', type);

            // Visual feedback delay
            setTimeout(async () => {
                try {
                    // Navigate to unified content list with type parameter
                    await window.api.navigate_to(`content_list.html?type=${type}`);
                } catch (error) {
                    console.error('Navigation error:', error);
                    Alpine.store('toast').error('Navigation failed');
                }
            }, 300);
        }
    }));

    console.log('✅ Content select component registered');
});
