// rubric.js - Rubric management (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('rubricPage', () => ({
        // State: loading | selecting | checking-rubric | rubric-exists | no-rubric | creating | created | error
        state: 'loading',

        // Data
        assignments: [],
        selectedAssignmentId: null,
        rubric: null,
        rubricMatches: false,
        errorMessage: '',
        contentName: '',
        courseName: '',
        contentType: '', // 'quiz' or 'assignment'

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadContext();
            await this.loadAssignments();
        },

        // Load context
        async loadContext() {
            try {
                const state = await window.api.get_state();
                if (state.success && state.state) {
                    this.courseName = state.state.course_name || '';
                    this.contentName = state.state.content_name || '';
                    this.contentType = state.state.content_type || 'assignment';
                    console.log(`📊 Rubric page context: ${this.contentType} - ${this.contentName}`);
                }
            } catch (error) {
                console.error('Error loading state:', error);
            }
        },

        // Load assignments
        async loadAssignments() {
            this.state = 'loading';

            try {
                const result = await window.api.assignment_get_list();

                if (result.success && result.assignments) {
                    this.assignments = result.assignments.sort((a, b) => a.name.localeCompare(b.name));
                    this.state = 'selecting';
                } else {
                    this.errorMessage = result.error || 'Failed to load assignments';
                    this.state = 'error';
                }
            } catch (error) {
                console.error('Error loading assignments:', error);
                this.errorMessage = 'Failed to load assignments';
                this.state = 'error';
            }
        },

        // Check rubric for selected assignment
        async checkRubric() {
            if (!this.selectedAssignmentId) return;

            this.state = 'checking-rubric';

            try {
                const result = await window.api.rubric_check_exists(this.selectedAssignmentId);

                if (result.success) {
                    if (result.exists && result.rubric) {
                        this.rubric = result.rubric;

                        // Check if rubric matches quiz
                        const matchResult = await window.api.rubric_validate_match(this.selectedAssignmentId);
                        this.rubricMatches = matchResult.success && matchResult.matches;

                        this.state = 'rubric-exists';
                    } else {
                        this.state = 'no-rubric';
                    }
                } else {
                    this.errorMessage = result.error || 'Failed to check rubric';
                    this.state = 'error';
                }
            } catch (error) {
                console.error('Error checking rubric:', error);
                this.errorMessage = 'Failed to check rubric';
                this.state = 'error';
            }
        },

        // Create rubric
        async createRubric() {
            this.state = 'creating';

            try {
                const result = await window.api.rubric_create(this.selectedAssignmentId);

                if (result.success && result.rubric) {
                    this.rubric = result.rubric;
                    this.state = 'created';
                } else {
                    this.errorMessage = result.error || 'Failed to create rubric';
                    this.state = 'error';
                }
            } catch (error) {
                console.error('Error creating rubric:', error);
                this.errorMessage = 'Failed to create rubric';
                this.state = 'error';
            }
        },

        // Use rubric and continue to submission page
        async useRubric() {
            localStorage.setItem('targetAssignmentId', this.selectedAssignmentId);
            // Navigate to submission page (works for both quiz and assignment)
            await window.api.navigate_to('quiz_upload.html');
        },

        // Cancel rubric creation
        cancelRubric() {
            this.state = 'no-rubric';
        },

        // Retry
        retry() {
            this.loadAssignments();
        },

        // Get context text
        getContextText() {
            if (this.courseName && this.contentName) {
                const contentLabel = this.contentType === 'quiz' ? 'Quiz' : 'Assignment';
                return `Course: ${this.courseName} > ${contentLabel}: ${this.contentName}`;
            }
            return 'Loading...';
        },

        // Get page subtitle based on content type
        getPageSubtitle() {
            if (this.contentType === 'quiz') {
                return 'Select the target assignment for quiz grades';
            }
            return 'Select the target assignment for upload';
        }
    }));

    console.log('✅ Rubric component registered');
});
