// HTML utilities for rendering Canvas content with security and MathJax support

class HTMLRenderer {
    constructor() {
        this.allowedTags = [
            'p', 'br', 'div', 'span', 'strong', 'b', 'em', 'i', 'u',
            'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
            'ul', 'ol', 'li', 'dl', 'dt', 'dd',
            'table', 'thead', 'tbody', 'tr', 'th', 'td',
            'a', 'img', 'blockquote', 'code', 'pre',
            'sup', 'sub', 'del', 'ins', 'mark',
            'figure', 'figcaption', 'iframe'
        ];
        
        this.allowedAttributes = {
            'a': ['href', 'title', 'target', 'rel'],
            'img': ['src', 'alt', 'title', 'width', 'height', 'style'],
            'iframe': ['src', 'width', 'height', 'frameborder', 'allowfullscreen'],
            'table': ['class', 'style'],
            'td': ['colspan', 'rowspan', 'style'],
            'th': ['colspan', 'rowspan', 'style'],
            '*': ['class', 'id', 'style']
        };
        
        this.allowedProtocols = ['http:', 'https:', 'mailto:'];
    }
    
    /**
     * Preprocess Canvas-specific HTML patterns
     */
    async preprocessCanvasHTML(html) {
        if (!html) return '';

        // Handle Canvas equation images
        html = html.replace(
            /<img[^>]+class="equation_image"[^>]*>/g,
            (match) => {
                const altMatch = match.match(/alt="([^"]*)"/);
                const titleMatch = match.match(/title="([^"]*)"/);
                const latex = altMatch ? altMatch[1] : (titleMatch ? titleMatch[1] : '');

                if (latex) {
                    // Convert to MathJax format
                    return `<span class="math-inline">\\(${latex}\\)</span>`;
                }
                return match;
            }
        );

        // Handle Canvas file references in both questions and answers
        const canvasUrl = await this.getCanvasUrl();

        // Pattern 1: Answer format - [filename.ext] (/courses/X/files/Y/preview)
        html = html.replace(
            /\[([^\]]+\.(png|jpg|jpeg|gif|bmp|svg|webp))\]\s*\(\s*\/?courses?\/\d+\/files\/\d+\/preview\s*\)/gi,
            (match, filename, extension) => {
                // Extract the file path from the Canvas URL
                const pathMatch = match.match(/\/courses\/\d+\/files\/\d+\/preview/);
                if (pathMatch) {
                    const canvasPath = pathMatch[0];
                    // Use /download/ instead of /preview/ for authenticated access
                    const downloadPath = canvasPath.replace('/preview', '/download?download_frd=1');
                    const fullUrl = canvasUrl ? `${canvasUrl}${downloadPath}` : canvasPath;
                    return `<img src="${fullUrl}" alt="${filename}" class="canvas-answer-image" style="max-width: 100%; height: auto; margin: 10px 0; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">`;
                }
                return match;
            }
        );

        // Pattern 2: Handle img tags with relative Canvas URLs that need the domain
        html = html.replace(
            /<img[^>]+src="\/courses\/\d+\/files\/\d+\/preview[^"]*"[^>]*>/gi,
            (match) => {
                // Extract the src attribute
                const srcMatch = match.match(/src="([^"]+)"/);
                if (srcMatch) {
                    const srcPath = srcMatch[1];
                    // Use /download/ instead of /preview/ for authenticated access
                    const downloadPath = srcPath.replace('/preview', '/download?download_frd=1');
                    const fullUrl = canvasUrl ? `${canvasUrl}${downloadPath}` : srcPath;
                    // Replace the src attribute with the full URL
                    return match.replace(/src="[^"]+"/, `src="${fullUrl}"`);
                }
                return match;
            }
        );

        // Handle LaTeX delimiters that might be escaped
        html = html.replace(/\\\\\(/g, '\\(');
        html = html.replace(/\\\\\)/g, '\\)');
        html = html.replace(/\\\\\[/g, '\\[');
        html = html.replace(/\\\\\]/g, '\\]');

        return html;
    }

    
    /**
     * Sanitize HTML to prevent XSS attacks
     */
    sanitizeHTML(html) {
        if (!html) return '';

        // Fix Canvas image URLs before processing
        html = this.fixCanvasImageUrls(html);

        // Create a temporary container
        const temp = document.createElement('div');
        temp.innerHTML = html;

        // Remove all script tags and event handlers
        this.removeScripts(temp);

        // Clean all elements
        this.cleanElement(temp);

        return temp.innerHTML;
    }

    fixCanvasImageUrls(html) {
        // Get Canvas base URL from active profile (no hardcoded fallback!)
        let canvasBaseUrl = null;

        // Get from Alpine store
        if (window.Alpine && window.Alpine.store) {
            const activeProfiles = window.Alpine.store('activeProfiles');
            if (activeProfiles && activeProfiles.canvas && activeProfiles.canvas.canvas_address) {
                canvasBaseUrl = activeProfiles.canvas.canvas_address;
            }
        }

        // If no Canvas profile is active, can't fix URLs - return as-is
        if (!canvasBaseUrl) {
            console.warn('Cannot fix Canvas image URLs: No active Canvas profile');
            return html;
        }

        // Fix relative Canvas image URLs
        // Convert /courses/... to https://canvas.../courses/...
        html = html.replace(
            /(<img[^>]+src=["'])\/courses\//gi,
            `$1${canvasBaseUrl}/courses/`
        );

        // Also fix other relative Canvas paths
        html = html.replace(
            /(<img[^>]+src=["'])\/files\//gi,
            `$1${canvasBaseUrl}/files/`
        );

        return html;
    }
    
    removeScripts(element) {
        // Remove script tags
        const scripts = element.querySelectorAll('script');
        scripts.forEach(script => script.remove());
        
        // Remove event handlers
        const allElements = element.querySelectorAll('*');
        allElements.forEach(el => {
            // Remove all event attributes
            for (let attr of [...el.attributes]) {
                if (attr.name.startsWith('on')) {
                    el.removeAttribute(attr.name);
                }
            }
        });
    }
    
    cleanElement(element) {
        const children = [...element.children];
        
        children.forEach(child => {
            const tagName = child.tagName.toLowerCase();
            
            // Remove disallowed tags but keep their content
            if (!this.allowedTags.includes(tagName)) {
                while (child.firstChild) {
                    element.insertBefore(child.firstChild, child);
                }
                child.remove();
                return;
            }
            
            // Clean attributes
            const attributes = [...child.attributes];
            attributes.forEach(attr => {
                const attrName = attr.name.toLowerCase();
                const allowedForTag = this.allowedAttributes[tagName] || [];
                const allowedGlobal = this.allowedAttributes['*'] || [];
                
                if (!allowedForTag.includes(attrName) && !allowedGlobal.includes(attrName)) {
                    child.removeAttribute(attr.name);
                } else if (attrName === 'href' || attrName === 'src') {
                    // Validate URLs
                    try {
                        const url = new URL(attr.value, window.location.href);
                        if (!this.allowedProtocols.includes(url.protocol)) {
                            child.removeAttribute(attr.name);
                        }
                    } catch (e) {
                        // Invalid URL, remove attribute
                        child.removeAttribute(attr.name);
                    }
                }
            });
            
            // Recursively clean children
            this.cleanElement(child);
        });
    }
    
    /**
     * Process images with fallback handling
     */
    processImages(container) {
        const images = container.querySelectorAll('img');
        images.forEach(img => {
            // Add loading and error handling
            img.addEventListener('error', function() {
                this.style.display = 'none';
                const altText = document.createElement('span');
                altText.className = 'image-alt-text';
                altText.textContent = `[Image: ${this.alt || 'No description'}]`;
                this.parentNode.insertBefore(altText, this);
            });
            
            // Add loading class
            img.classList.add('loading');
            img.addEventListener('load', function() {
                this.classList.remove('loading');
            });
        });
    }

    /**
     * Get Canvas URL from API
     */
    async getCanvasUrl() {
        // Cache the URL to avoid repeated API calls
        if (this._canvasUrl) {
            return this._canvasUrl;
        }

        try {
            if (window.api && window.api.get_canvas_url) {
                const result = await window.api.get_canvas_url();
                if (result.success) {
                    this._canvasUrl = result.canvas_url;
                    return this._canvasUrl;
                }
            }
        } catch (error) {
            console.warn('Failed to get Canvas URL:', error);
        }

        return null;
    }

    /**
     * Main rendering function with MathJax support
     */
    renderWithMath(element, htmlString, options = {}) {
        if (!element || !htmlString) return;

        // Preprocess Canvas-specific patterns (async but we'll handle it synchronously for simplicity)
        this.preprocessCanvasHTML(htmlString).then(processed => {
            // Sanitize HTML
            let sanitized = this.sanitizeHTML(processed);

            // Set the content
            element.innerHTML = sanitized;

            // Process images
            this.processImages(element);

            // Trigger MathJax rendering if available
            if (window.MathJax && window.MathJax.typesetPromise) {
                window.MathJax.typesetPromise([element]).catch((e) => {
                    console.error('MathJax rendering error:', e);
                });
            }

            // Add Canvas content styling
            element.classList.add('canvas-content');
        }).catch(error => {
            console.error('Error preprocessing Canvas HTML:', error);
            // Fallback to basic rendering without Canvas processing
            let sanitized = this.sanitizeHTML(htmlString);
            element.innerHTML = sanitized;
            element.classList.add('canvas-content');
        });
    }
    
    /**
     * Render plain text (escape HTML)
     */
    renderText(element, text) {
        if (!element) return;
        element.textContent = text || '';
    }
    
    /**
     * Extract text content from HTML
     */
    extractText(htmlString) {
        const temp = document.createElement('div');
        temp.innerHTML = this.sanitizeHTML(htmlString);
        return temp.textContent || temp.innerText || '';
    }
}

// Create global instance
window.htmlRenderer = new HTMLRenderer();

// Add CSS for Canvas content
const style = document.createElement('style');
style.textContent = `
    .canvas-content {
        font-size: 0.875rem;
        line-height: 1.6;
        color: var(--text-primary);
    }
    
    .canvas-content img {
        max-width: 100%;
        height: auto;
        border-radius: var(--radius-md);
    }
    
    .canvas-content img.loading {
        background: var(--bg-tertiary);
        min-height: 100px;
    }
    
    .image-alt-text {
        display: inline-block;
        padding: 0.5rem 1rem;
        background: var(--bg-tertiary);
        border-radius: var(--radius-md);
        font-style: italic;
        color: var(--text-secondary);
    }
    
    .canvas-content table {
        width: 100%;
        border-collapse: collapse;
        margin: 1rem 0;
    }
    
    .canvas-content table th,
    .canvas-content table td {
        padding: 0.5rem;
        border: 1px solid var(--border-color);
    }
    
    .canvas-content table th {
        background: var(--bg-secondary);
        font-weight: 600;
    }
    
    .canvas-content pre {
        background: var(--bg-secondary);
        padding: 1rem;
        border-radius: var(--radius-md);
        overflow-x: auto;
    }
    
    .canvas-content code {
        background: var(--bg-secondary);
        padding: 0.125rem 0.375rem;
        border-radius: var(--radius-sm);
        font-family: 'Monaco', 'Consolas', monospace;
        font-size: 0.875em;
    }
    
    .canvas-content blockquote {
        margin: 1rem 0;
        padding-left: 1rem;
        border-left: 3px solid var(--color-primary);
        color: var(--text-secondary);
    }
    
    .math-inline,
    .math-display {
        overflow-x: auto;
        max-width: 100%;
    }
    
    .question-text {
        background: var(--bg-secondary);
        padding: 1rem;
        border-radius: var(--radius-md);
        margin-bottom: 1rem;
    }
    
    .student-answer {
        background: var(--bg-tertiary);
        padding: 1rem;
        border-radius: var(--radius-md);
    }
`;
document.head.appendChild(style);