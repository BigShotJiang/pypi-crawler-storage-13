// breadcrumb.js - Dynamic Breadcrumb Navigation Component

document.addEventListener('alpine:init', () => {
    // Initialize Alpine.js store for application state if not already initialized
    if (!Alpine.store('state')) {
        Alpine.store('state', {
            course_id: null,
            course_name: null,
            content_id: null,
            content_name: null,
            content_type: null,
            parsing_strategy: null,
            csv_path: null
        });
    }

    // Breadcrumb component
    Alpine.data('breadcrumbNav', () => ({
        items: [],

        async init() {
            // Load state from API
            await this.loadState();

            // Update breadcrumb
            this.updateBreadcrumb();

            // Watch for state changes and update breadcrumb
            this.$watch('$store.state', () => {
                this.updateBreadcrumb();
            }, { deep: true });

            // Refresh breadcrumb periodically to catch manual state changes
            setInterval(() => this.loadState(), 2000);
        },

        async loadState() {
            try {
                if (window.api && window.api.get_state) {
                    const state = await window.api.get_state();
                    if (state) {
                        Alpine.store('state', state);
                    }
                }
            } catch (error) {
                console.debug('Could not load state for breadcrumb:', error);
            }
        },

        updateBreadcrumb() {
            const state = Alpine.store('state');
            const currentPage = this.getCurrentPageName();

            this.items = this.buildBreadcrumbTrail(state, currentPage);
        },

        getCurrentPageName() {
            const path = window.location.pathname;
            const match = path.match(/([^/]+\.html)$/);
            return match ? match[1] : 'index.html';
        },

        buildBreadcrumbTrail(state, currentPage) {
            const trail = [];

            // Always start with Dashboard (except on dashboard itself)
            if (currentPage !== 'dashboard.html' && currentPage !== 'index.html') {
                trail.push({ label: 'Dashboard', page: 'dashboard.html', active: false });
            }

            // Static pages (no further trail needed)
            const staticPages = {
                'about.html': 'About',
                'privacy.html': 'Privacy & Data',
                'documentation.html': 'Documentation',
                'system_health.html': 'System Health',
                'profiles.html': 'Profiles',
                'profile_select.html': 'Select Profile',
                'connection.html': 'Connection Test'
            };

            if (staticPages[currentPage]) {
                trail.push({ label: staticPages[currentPage], page: currentPage, active: true });
                return trail;
            }

            // Workflow pages
            if (currentPage === 'courses.html') {
                trail.push({ label: 'Courses', page: 'courses.html', active: true });
                return trail;
            }

            // Add Courses if we're past course selection
            if (state.course_id || this.isInWorkflow(currentPage)) {
                trail.push({ label: 'Courses', page: 'courses.html', active: false });
            }

            // Content selection pages
            if (currentPage === 'content_select.html') {
                trail.push({ label: 'Content Type', page: 'content_select.html', active: true });
                return trail;
            }

            if (currentPage === 'content_list.html') {
                const urlParams = new URLSearchParams(window.location.search);
                const type = urlParams.get('type') || state.content_type || 'quiz';
                trail.push({ label: type === 'quiz' ? 'Quizzes' : 'Assignments', page: 'content_list.html', active: true });
                return trail;
            }

            // Quiz workflow
            if (this.isQuizPage(currentPage)) {
                trail.push({ label: 'Quizzes', page: 'quiz_list.html', active: false });

                const quizPages = {
                    'quiz_list.html': 'Select Quiz',
                    'quiz_csv.html': 'Download Data',
                    'quiz_grading_progress.html': 'Grading Progress',
                    'quiz_upload.html': 'Upload Grades',
                    'quiz_consistency.html': 'Consistency Check',
                    'review_quiz.html': 'Review & Upload'
                };

                if (quizPages[currentPage]) {
                    trail.push({ label: quizPages[currentPage], page: currentPage, active: true });
                }
            }

            // Assignment workflow
            else if (this.isAssignmentPage(currentPage)) {
                trail.push({ label: 'Assignments', page: 'assignment_list.html', active: false });

                const assignmentPages = {
                    'assignment_list.html': 'Select Assignment',
                    'assignment_download.html': 'Download Submissions',
                    'assignment_parse.html': 'Parse Submissions',
                    'assignment_template.html': 'Template Setup',
                    'assignment_status.html': 'Status',
                    'assignment_agent_setup.html': 'AI Agent Setup',
                    'assignment_points_setup.html': 'Points Setup',
                    'assignment_agent_running.html': 'AI Processing',
                    'assignment_agent_results.html': 'Review Results',
                    'assignment_agent_grade_edit.html': 'Edit Grade',
                    'assignment_grading_progress.html': 'Grading Progress',
                    'rubric.html': 'Rubric'
                };

                if (assignmentPages[currentPage]) {
                    trail.push({ label: assignmentPages[currentPage], page: currentPage, active: true });
                }
            }

            // Shared pages (can be quiz OR assignment)
            else if (this.isSharedPage(currentPage)) {
                // Determine context from state
                if (state.content_type === 'quiz') {
                    trail.push({ label: 'Quizzes', page: 'quiz_list.html', active: false });
                } else if (state.content_type === 'assignment') {
                    trail.push({ label: 'Assignments', page: 'assignment_list.html', active: false });
                } else {
                    trail.push({ label: 'Content', page: 'content_select.html', active: false });
                }

                const sharedPages = {
                    'grading_hub.html': 'Grading Hub',
                    'grade_input.html': 'Grade Question',
                    'grade_review.html': 'Review Results',
                    'grade_review_v2.html': 'Review Results',
                    'grade_edit.html': 'Edit Grade'
                };

                if (sharedPages[currentPage]) {
                    trail.push({ label: sharedPages[currentPage], page: currentPage, active: true });
                }
            }

            return trail;
        },

        isInWorkflow(page) {
            return this.isQuizPage(page) || this.isAssignmentPage(page) || this.isSharedPage(page);
        },

        isQuizPage(page) {
            return page.startsWith('quiz_') || page === 'review_quiz.html';
        },

        isAssignmentPage(page) {
            return page.startsWith('assignment_') || page === 'rubric.html';
        },

        isSharedPage(page) {
            return ['grading_hub.html', 'grade_input.html', 'grade_review.html', 'grade_review_v2.html', 'grade_edit.html'].includes(page);
        },

        async navigateTo(page) {
            if (window.api && window.api.navigate_to) {
                await window.api.navigate_to(page);
            }
        }
    }));
});
