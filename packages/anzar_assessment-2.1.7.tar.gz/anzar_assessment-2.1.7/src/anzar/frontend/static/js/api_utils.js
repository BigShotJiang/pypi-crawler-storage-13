// Utility functions for handling PyWebView API access

// Global flag to prevent multiple initializations
let _apiInitializing = false;
let _apiInitialized = false;
let _pendingCallbacks = [];

/**
 * Initialize PyWebView API with proper handling for both promise and direct access
 * @param {Function} callback - Function to call when API is ready
 */
function initializeAPI(callback) {
    // If already initialized, call callback immediately
    if (_apiInitialized && window.api) {
        if (callback) callback();
        return;
    }
    
    // Add callback to pending list
    if (callback) {
        _pendingCallbacks.push(callback);
    }
    
    // If already initializing, don't start another initialization
    if (_apiInitializing) {
        return;
    }
    
    _apiInitializing = true;
    
    function tryInitialize() {
        if (window.pywebview && window.pywebview.api) {
            if (typeof window.pywebview.api.then === 'function') {
                // Promise-based API
                window.pywebview.api.then((api) => {
                    window.api = api;
                    _apiInitialized = true;
                    _apiInitializing = false;
                    console.log('PyWebView API initialized (promise)');
                    
                    // Call all pending callbacks
                    const callbacks = [..._pendingCallbacks];
                    _pendingCallbacks = [];
                    callbacks.forEach(cb => cb());
                });
            } else {
                // Direct API access
                window.api = window.pywebview.api;
                _apiInitialized = true;
                _apiInitializing = false;
                console.log('PyWebView API initialized (direct)');
                
                // Call all pending callbacks
                const callbacks = [..._pendingCallbacks];
                _pendingCallbacks = [];
                callbacks.forEach(cb => cb());
            }
        } else {
            console.log('PyWebView not yet available, retrying...');
            setTimeout(tryInitialize, 100);
        }
    }
    
    tryInitialize();
}

/**
 * Wait for API to be ready before executing a function
 * @param {Function} fn - Function to execute when API is ready
 */
function whenAPIReady(fn) {
    if (window.api) {
        fn();
    } else {
        initializeAPI(fn);
    }
}

// Note: Background grading task API (gradingTaskAPI) has been removed.
// We now use synchronous grading with real-time progress via window.evaluate_js().
// The grading_start_task() method is still available via window.api for direct use.

// Export for use in other files
window.initializeAPI = initializeAPI;
window.whenAPIReady = whenAPIReady;