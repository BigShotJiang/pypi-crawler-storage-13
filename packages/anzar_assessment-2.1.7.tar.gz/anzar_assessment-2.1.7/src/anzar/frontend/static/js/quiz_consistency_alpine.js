// Quiz Consistency Checker - Alpine.js Component
// Simplified for testing current question only

// Constants
const RANDOM_STUDENT_COUNT = 5;
const API_WAIT_MAX_ATTEMPTS = 50; // 5 seconds timeout
const API_WAIT_INTERVAL_MS = 100;

// Consistency thresholds
const CONSISTENCY_THRESHOLDS = {
    EXCELLENT: 0.5,
    GOOD: 1.0,
    MODERATE: 2.0
};

document.addEventListener('alpine:init', () => {
    Alpine.data('quizConsistencyChecker', () => ({
        // State
        loading: true,
        error: false,
        running: false,
        loadingStudents: false,

        // Data from grade input
        gradingCriteria: {},
        currentQuestion: null,
        students: [],

        // UI State
        studentFilter: '',
        numRuns: 3,
        promptContent: '',
        generatingPreview: false,
        hasReviewedPrompt: false,

        // Results State
        testResults: null,
        showResults: false,

        // Progress tracking
        estimatedDuration: 0,
        estimatedSeconds: 0,

        // Computed
        get filteredStudents() {
            if (!this.studentFilter) {
                return this.students;
            }

            const filter = this.studentFilter.toLowerCase();
            return this.students.filter(student =>
                student.name.toLowerCase().includes(filter) ||
                String(student.id).toLowerCase().includes(filter)  // Convert to string for safety
            );
        },

        get selectedStudents() {
            return this.students.filter(student => student.selected);
        },

        get promptContentHtml() {
            if (!this.promptContent) return '';
            return window.marked ? window.marked.parse(this.promptContent) : this.promptContent.replace(/\n/g, '<br>');
        },

        get totalTestCount() {
            return this.selectedStudents.length * this.numRuns;
        },

        get estimatedTimeText() {
            if (this.estimatedSeconds === 0) return '';

            const minutes = Math.floor(this.estimatedSeconds / 60);
            const seconds = this.estimatedSeconds % 60;

            if (minutes > 0) {
                return `~${minutes}m ${seconds}s`;
            }
            return `~${seconds}s`;
        },

        get canRunTest() {
            return this.selectedStudents.length > 0 && this.hasReviewedPrompt;
        },

        // Methods
        async init() {
            // Guard against double initialization - set flag FIRST to prevent race condition
            if (this.initialized) {
                console.log('⏭️ Quiz Consistency Checker already initialized, skipping');
                return;
            }
            this.initialized = true;

            try {
                console.log('🚀 Initializing Quiz Consistency Checker');

                // Wait for API to be available
                await this.waitForApi();

                // Get state from API
                const state = await window.api.get_state();
                console.log('📊 Current state:', {
                    content_id: state.content_id,
                    content_name: state.content_name,
                    content_type: state.content_type,
                    csv_path: state.csv_path,
                    course_id: state.course_id
                });

                // Load grading criteria from Alpine store (same as grade input page)
                const gradingState = Alpine.store('gradingState');
                if (gradingState) {
                    this.gradingCriteria = gradingState.get('gradingCriteria') || {};
                } else {
                    this.gradingCriteria = {};
                }
                console.log('📋 Grading criteria:', this.gradingCriteria);

                // Check if we have grading criteria
                if (!this.gradingCriteria.correct_answer || !this.gradingCriteria.grading_rubric) {
                    console.warn('⚠️ No grading criteria found');
                    this.error = true;
                    this.loading = false;
                    return;
                }

                // Set current question info
                // Use the question ID from grade input if available (stored by navigateToConsistency)
                const gradingQuestionId = gradingState ? gradingState.get('gradingQuestionId') : null;
                const gradingQuestionText = gradingState ? gradingState.get('gradingQuestionText') : null;
                const questionData = gradingState ? gradingState.get('questionData') : null;

                this.currentQuestion = {
                    id: gradingQuestionId || state.content_id,  // Prefer gradingQuestionId from grade_input
                    text: gradingQuestionText || state.question_text || 'Current Question',
                    pointsPossible: questionData?.pointsPossible || this.gradingCriteria.max_points || 10,
                    total_questions: 1
                };
                console.log("📝 Using question ID:", this.currentQuestion.id, "(from", gradingQuestionId ? "grade_input" : "state", ")");
                console.log("📊 Question points:", this.currentQuestion.pointsPossible);

                // Load students
                await this.loadStudents(state);

                // Done loading

                this.loading = false;
                console.log('✅ Consistency checker initialized successfully');

            } catch (error) {
                console.error('❌ Error initializing consistency checker:', error);
                this.error = true;
                this.loading = false;
            }
        },

        async waitForApi() {
            return new Promise((resolve, reject) => {
                let attempts = 0;

                const checkApi = () => {
                    attempts++;
                    if (window.api && window.api.get_state) {
                        resolve();
                    } else if (attempts >= API_WAIT_MAX_ATTEMPTS) {
                        reject(new Error('API not available after 5 seconds'));
                    } else {
                        setTimeout(checkApi, API_WAIT_INTERVAL_MS);
                    }
                };
                checkApi();
            });
        },

        // Smart back navigation - returns to source page
        goBack() {
            const gradingState = Alpine.store('gradingState');
            const returnTo = gradingState ? gradingState.get('returnTo') : null;

            // Default to grade_input.html if no returnTo is stored
            const destination = returnTo || 'grade_input.html';

            console.log('🔙 Consistency check going back to:', destination);
            window.api.navigate_to(destination);
        },

        async loadStudents(state) {
            this.loadingStudents = true;

            try {
                console.log('🎓 Loading students...');

                // Try loading strategies in order
                const students = await this.loadFromStore()
                    || await this.loadFromAPI()
                    || [];

                this.students = students;

                if (students.length === 0) {
                    this.showNoStudentsMessage();
                } else {
                    console.log(`✅ Successfully loaded ${students.length} students`);
                }

            } catch (error) {
                console.error('❌ Error loading students:', error);
                this.students = [];
                Alpine.store('toast')?.error('Error loading students: ' + error.message);
            } finally {
                this.loadingStudents = false;
            }
        },

        async loadFromStore() {
            console.log('🔍 Strategy 1: Checking Alpine store...');

            const gradingState = Alpine.store('gradingState');
            if (!gradingState || !gradingState.has('sampleAnswers')) {
                console.log('  ⏭️ No sample answers in Alpine store');
                return null;
            }

            const sampleAnswers = gradingState.get('sampleAnswers');
            console.log(`  📋 Found ${sampleAnswers.length} sample answers`);

            const studentsMap = this.extractStudentsFromSamples(sampleAnswers);
            const students = Object.values(studentsMap);

            console.log(`  ✅ Loaded ${students.length} students from Alpine store`);
            return students;
        },

        async loadFromAPI() {
            console.log('🔍 Strategy 2: Trying direct API call...');

            if (!window.api?.quiz_get_sample_answers || !window.api?.quiz_get_questions) {
                console.log('  ⏭️ API methods not available');
                return null;
            }

            const questionsResponse = await window.api.quiz_get_questions();
            if (!questionsResponse.success || !questionsResponse.questions?.length) {
                console.log('  ⏭️ Could not get quiz questions');
                return null;
            }

            console.log(`  📝 Found ${questionsResponse.questions.length} questions`);

            const allStudentsMap = {};

            for (const question of questionsResponse.questions) {
                const response = await window.api.quiz_get_sample_answers(question.id, 50);
                if (response.success && response.samples?.length) {
                    const studentsFromQuestion = this.extractStudentsFromSamples(response.samples);
                    Object.assign(allStudentsMap, studentsFromQuestion);
                }
            }

            const students = Object.values(allStudentsMap);
            if (students.length > 0) {
                console.log(`  ✅ Loaded ${students.length} students via API`);
                return students;
            }

            console.log('  ⏭️ No students found via API');
            return null;
        },

        extractStudentsFromSamples(samples) {
            const studentsMap = {};

            samples.forEach(sample => {
                if (sample.student_id && sample.student_name) {
                    const student_id = String(sample.student_id);

                    if (!studentsMap[student_id]) {
                        studentsMap[student_id] = {
                            id: student_id,
                            name: sample.student_name,
                            answer: sample.student_answer || '',
                            selected: false
                        };
                    }
                }
            });

            return studentsMap;
        },

        showNoStudentsMessage() {
            console.warn('📝 No students available');
            console.warn('ℹ️ To see students in consistency check:');
            console.warn('  1. Download quiz CSV first');
            console.warn('  2. Navigate to Grade Input page and load sample answers');
            console.warn('  3. Then open consistency check');

            Alpine.store('toast')?.warning(
                'No students found. Please load sample answers in the Grade Input page first, then return to the consistency check.'
            );
        },

        selectAllStudents() {
            this.students.forEach(student => student.selected = true);
        },

        selectRandomStudents() {
            // Clear all selections first
            this.students.forEach(student => student.selected = false);

            // Randomly select students
            const shuffled = [...this.students].sort(() => Math.random() - 0.5);
            const selected = shuffled.slice(0, RANDOM_STUDENT_COUNT);
            selected.forEach(student => student.selected = true);
        },

        clearSelection() {
            this.students.forEach(student => student.selected = false);
        },

        updateEstimatedTime() {
            // Estimate ~2 seconds per grading operation
            const SECONDS_PER_GRADE = 2;
            this.estimatedSeconds = this.totalTestCount * SECONDS_PER_GRADE;
        },

        async showPromptPreviewContent() {
            if (this.students.length === 0) {
                Alpine.store('toast')?.error('No sample student answers available to generate a preview.');
                return;
            }

            this.generatingPreview = true;

            // Use setTimeout to allow UI to update before generating preview
            setTimeout(async () => {
                try {
                    // Get the first selected student, or just the first student
                    let sampleStudent = this.selectedStudents.length > 0
                        ? this.selectedStudents[0]
                        : this.students[0];

                    let sampleAnswer = sampleStudent.answer || '[No answer provided]';

                    // If the answer seems truncated or empty, try to get the full answer from the API
                    if (!sampleAnswer || sampleAnswer === '[No answer provided]' || sampleAnswer.length < 50) {
                        console.log('⚠️ Answer seems short or empty, fetching from API...');
                        try {
                            const response = await window.api.quiz_get_sample_answers(this.currentQuestion.id, 1);
                            if (response.success && response.samples && response.samples.length > 0) {
                                sampleAnswer = response.samples[0].student_answer || sampleAnswer;
                                console.log('✅ Fetched full answer from API:', sampleAnswer.length, 'characters');
                            }
                        } catch (err) {
                            console.warn('Could not fetch full answer from API:', err);
                        }
                    }

                    const pointsPossible = this.currentQuestion?.pointsPossible ||
                                          this.gradingCriteria?.max_points || 10;

                    this.promptContent = `You are a teacher grading a student's answer.

**Question:**
${this.currentQuestion?.text || 'No question text available'}

**Student's Answer:**
${sampleAnswer}

**Grading Criteria:**

**Correct Answer / Key Points:**
${this.gradingCriteria.correct_answer || 'Not specified'}

**Maximum Points:**
${pointsPossible}

**Grading Rubric:**
${this.gradingCriteria.grading_rubric || 'Not specified'}

**Examples of Good Answers:**
${this.gradingCriteria.good_examples || 'Not provided'}

**Examples of Poor Answers:**
${this.gradingCriteria.bad_examples || 'Not provided'}

**Feedback Format Instructions:**
${this.gradingCriteria.feedback_format || 'Provide brief, constructive feedback explaining the grade.'}

**Response Format:**
Please respond in JSON format:
{
    "points": <number between 0 and ${pointsPossible}>,
    "feedback": "<detailed explanation of the grade following the feedback format>"
}`;

                    this.hasReviewedPrompt = true;
                    console.log('✅ Prompt preview generated successfully');
                    console.log('📏 Prompt length:', this.promptContent.length, 'characters');
                    console.log('📝 Student answer length:', sampleAnswer.length, 'characters');
                } catch (error) {
                    console.error('❌ Error generating prompt preview:', error);
                    Alpine.store('toast')?.error('Failed to generate prompt preview');
                } finally {
                    this.generatingPreview = false;
                }
            }, 100);
        },

        processResults() {
            if (!this.testResults || !this.testResults.data) {
                console.error('No test results to process');
                return;
            }

            const data = this.testResults.data;
            console.log('Processing results:', data);

            // Calculate summary statistics
            if (data.questions_analyzed && data.questions_analyzed.length > 0) {
                const question = data.questions_analyzed[0];
                const byStudent = question.by_student || {};

                // Process each student's results
                this.testResults.processedResults = [];

                for (const [studentId, stats] of Object.entries(byStudent)) {
                    console.log(`Processing student ${studentId} with feedbacks:`, stats.feedbacks);
                    this.testResults.processedResults.push({
                        studentId: studentId,
                        studentName: stats.student_name,
                        grades: stats.grades || [],
                        mean: stats.mean || 0,
                        std: stats.std || 0,
                        min: stats.min || 0,
                        max: stats.max || 0,
                        consistency: stats.consistency || 'Unknown',
                        feedbacks: stats.feedbacks || []  // Make sure feedbacks are included
                    });
                }

                // Calculate overall statistics
                const allStdDevs = Object.values(byStudent).map(s => s.std || 0);
                const avgStdDev = allStdDevs.length > 0 ?
                    allStdDevs.reduce((a, b) => a + b, 0) / allStdDevs.length : 0;

                this.testResults.overallConsistency =
                    avgStdDev < CONSISTENCY_THRESHOLDS.EXCELLENT ? 'Excellent' :
                    avgStdDev < CONSISTENCY_THRESHOLDS.GOOD ? 'Good' :
                    avgStdDev < CONSISTENCY_THRESHOLDS.MODERATE ? 'Moderate' : 'Poor';

                this.testResults.avgStdDev = avgStdDev;
            }
        },

        clearResults() {
            this.testResults = null;
            this.showResults = false;
            // Don't reset the prompt preview - let the user keep it
        },

        async runConsistencyTest() {
            if (this.selectedStudents.length === 0) {
                Alpine.store('toast')?.warning('Please select at least one student for consistency testing');
                return;
            }

            if (!this.hasReviewedPrompt) {
                Alpine.store('toast')?.warning('Please generate and review the AI prompt preview before running the test');
                return;
            }

            this.updateEstimatedTime();
            this.running = true;

            try {
                console.log('🧪 Starting consistency test...');
                console.log('👥 Selected students:', this.selectedStudents.map(s => s.id));
                console.log('📊 Total tests:', this.totalTestCount, '(estimated time:', this.estimatedTimeText, ')');
                console.log('📋 Using grading criteria:', this.gradingCriteria);

                // Prepare student IDs
                const selectedStudentIds = this.selectedStudents.map(student => student.id);

                // Check if API method is available
                if (!window.api.quiz_start_consistency_test) {
                    throw new Error('Consistency test API not available');
                }

                // Call consistency test API
                // When coming from grade_input, we ALWAYS test the specific question that was being graded
                const gradingState = Alpine.store('gradingState');
                const gradingQuestionId = gradingState ? gradingState.get('gradingQuestionId') : null;

                // For quiz consistency, we always test the current question
                const questionToTest = this.currentQuestion.id;

                console.log('🎯 Testing question:', questionToTest, 'with', selectedStudentIds.length, 'students');

                const result = await window.api.quiz_start_consistency_test(
                    selectedStudentIds,
                    this.numRuns,
                    questionToTest,
                    this.gradingCriteria
                );

                console.log('📊 Consistency test result:', result);

                if (result.success && result.result) {
                    // Store results directly in component
                    this.testResults = {
                        students: this.selectedStudents,
                        question: this.currentQuestion,
                        criteria: this.gradingCriteria,
                        numRuns: this.numRuns,
                        data: result.result,
                        timestamp: new Date().toISOString()
                    };

                    // Process and display results
                    this.showResults = true;
                    this.processResults();

                    if (Alpine.store('toast')) {
                        Alpine.store('toast').success('Consistency test completed successfully');
                    }
                } else {
                    throw new Error(result.error || 'Unknown error');
                }

            } catch (error) {
                console.error('❌ Error running consistency test:', error);
                Alpine.store('toast')?.error('Failed to run consistency test: ' + error.message);
            } finally {
                this.running = false;
            }
        }
    }));
});

console.log('✅ Quiz Consistency Alpine component loaded');