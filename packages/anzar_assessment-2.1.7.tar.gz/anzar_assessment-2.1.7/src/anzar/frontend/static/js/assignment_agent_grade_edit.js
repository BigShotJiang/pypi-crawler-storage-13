// Assignment Agent Grade Edit Page
let gradeData = null;

document.addEventListener('DOMContentLoaded', async function() {
    console.log('Grade Edit Page: DOM loaded');

    if (window.initializeAPI) {
        window.initializeAPI(initializePage);
    } else {
        await initializeAPIFallback();
    }
});

async function initializeAPIFallback() {
    let initialized = false;

    window.addEventListener('pywebviewready', function() {
        if (!initialized && window.pywebview && window.pywebview.api) {
            window.api = window.pywebview.api;
            initialized = true;
            initializePage();
        }
    });

    if (window.pywebview && window.pywebview.api && !initialized) {
        window.api = window.pywebview.api;
        initialized = true;
        initializePage();
    }

    setTimeout(() => {
        if (!initialized) {
            showError('Unable to connect to the application. Please refresh the page.');
        }
    }, 5000);
}

function initializePage() {
    console.log('initializePage called');
    
    // Get grade data from session storage
    const storedData = sessionStorage.getItem('gradeEditData');
    console.log('Stored data:', storedData);
    
    if (!storedData) {
        console.error('No grade data found in sessionStorage');
        showError('No grade data found. Returning to results page.');
        setTimeout(() => navigateTo('assignment_agent_results.html'), 2000);
        return;
    }

    try {
        gradeData = JSON.parse(storedData);
        console.log('Parsed grade data:', gradeData);
        populateForm();
    } catch (error) {
        console.error('Error parsing grade data:', error);
        showError('Invalid grade data. Returning to results page.');
        setTimeout(() => navigateTo('assignment_agent_results.html'), 2000);
    }
}

function populateForm() {
    console.log('populateForm called with data:', gradeData);
    
    if (!gradeData) {
        console.error('No grade data available');
        return;
    }

    // Student info
    const studentNameEl = document.getElementById('student-name');
    const studentIdEl = document.getElementById('student-id');
    console.log('Student elements:', { studentNameEl, studentIdEl });
    
    if (studentNameEl) studentNameEl.textContent = gradeData.student_name || 'Unknown Student';
    if (studentIdEl) studentIdEl.textContent = gradeData.student_id || 'N/A';

    // Question
    const questionTextEl = document.getElementById('question-text');
    console.log('Question element:', questionTextEl);
    if (questionTextEl) questionTextEl.textContent = gradeData.question_text || 'Question text not available';

    // Student answer
    const answerEl = document.getElementById('student-answer');
    console.log('Answer element:', answerEl);
    if (answerEl) answerEl.textContent = gradeData.student_answer || 'No answer provided';

    // Grade
    const gradeInputEl = document.getElementById('grade-input');
    const maxPointsEl = document.getElementById('max-points');
    console.log('Grade elements:', { gradeInputEl, maxPointsEl });
    if (gradeInputEl) gradeInputEl.value = gradeData.grade || 0;
    if (maxPointsEl) maxPointsEl.textContent = gradeData.max_points || 10;

    // Feedback
    const feedbackEl = document.getElementById('feedback-input');
    console.log('Feedback element:', feedbackEl);
    if (feedbackEl) feedbackEl.value = gradeData.feedback || '';

    // Attach event listeners to buttons
    const saveBtn = document.getElementById('save-btn');
    const cancelBtn = document.querySelector('button[onclick*="cancelEdit"]');
    
    console.log('Button elements:', { saveBtn, cancelBtn });
    
    if (saveBtn) {
        // Remove onclick attribute and use event listener
        saveBtn.removeAttribute('onclick');
        saveBtn.addEventListener('click', saveGrade);
        console.log('Save button listener attached');
    }
    
    if (cancelBtn) {
        // Remove onclick attribute and use event listener
        cancelBtn.removeAttribute('onclick');
        cancelBtn.addEventListener('click', cancelEdit);
        console.log('Cancel button listener attached');
    }

    // Focus on grade input
    if (gradeInputEl) {
        gradeInputEl.focus();
        gradeInputEl.select();
        console.log('Grade input focused');
    }
    
    console.log('Form population complete');
}

async function saveGrade() {
    if (!gradeData) return;

    const newGrade = parseFloat(document.getElementById('grade-input').value) || 0;
    const newFeedback = document.getElementById('feedback-input').value.trim();

    // Check if values changed
    if (gradeData.grade === newGrade && gradeData.feedback === newFeedback) {
        showInfo('No changes to save');
        return;
    }

    const saveBtn = document.getElementById('save-btn');
    const originalText = saveBtn.innerHTML;
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<i class="ph-spinner"></i> Saving...';

    try {
        const saveResult = await window.api.assignment_update_single_grade(
            gradeData.student_id,
            gradeData.question_id,
            newGrade,
            newFeedback
        );

        if (!saveResult.success) {
            throw new Error(saveResult.error || saveResult.message || 'Save failed');
        }

        showSuccess('Grade saved successfully!');
        
        // Mark that we're returning from edit so results page can track the edit
        sessionStorage.setItem('returnedFromEdit', JSON.stringify({
            student_id: gradeData.student_id,
            question_id: gradeData.question_id
        }));
        
        // Clear edit data
        sessionStorage.removeItem('gradeEditData');
        
        // Return to results page after short delay
        setTimeout(() => {
            navigateTo('assignment_agent_results.html');
        }, 1000);

    } catch (error) {
        console.error('Save error:', error);
        showError('Failed to save: ' + error.message);
        saveBtn.disabled = false;
        saveBtn.innerHTML = originalText;
    }
}

function cancelEdit() {
    if (confirm('Discard changes and return to results?')) {
        sessionStorage.removeItem('gradeEditData');
        navigateTo('assignment_agent_results.html');
    }
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + S to save
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        saveGrade();
    }
    // Escape to cancel
    if (e.key === 'Escape') {
        cancelEdit();
    }
});

// Make functions globally accessible for onclick handlers (as backup)
window.saveGrade = saveGrade;
window.cancelEdit = cancelEdit;

async function refineFeedbackWithAI() {
    if (!gradeData) {
        showError('No grade data available');
        return;
    }

    const refinementInstruction = document.getElementById('refinement-instruction').value.trim();

    if (!refinementInstruction) {
        showError('Please enter a refinement instruction');
        return;
    }

    const refineBtn = document.getElementById('refine-btn');
    const originalBtnText = refineBtn.innerHTML;

    // Show loading state
    refineBtn.disabled = true;
    refineBtn.innerHTML = '<i class="ph-spinner ph-spin"></i> Refining...';

    try {
        const result = await window.api.assignment_refine_feedback_with_ai(
            gradeData.student_id,
            gradeData.question_id,
            gradeData.student_answer,
            gradeData.question_text,
            document.getElementById('feedback-input').value.trim(),
            parseFloat(document.getElementById('grade-input').value) || 0,
            gradeData.max_points,
            refinementInstruction
        );

        if (!result.success) {
            throw new Error(result.error || 'Refinement failed');
        }

        // Update feedback textarea with new feedback
        const feedbackInput = document.getElementById('feedback-input');
        feedbackInput.value = result.new_feedback;

        // Clear refinement instruction
        document.getElementById('refinement-instruction').value = '';

        showSuccess('Feedback refined successfully! Review and save if satisfied.');

        // Focus on feedback to review
        feedbackInput.focus();

    } catch (error) {
        console.error('Refinement error:', error);
        showError('Failed to refine feedback: ' + error.message);
    } finally {
        refineBtn.disabled = false;
        refineBtn.innerHTML = originalBtnText;
    }
}

// Make function globally accessible
window.refineFeedbackWithAI = refineFeedbackWithAI;

function showSuccess(message) {
    if (window.showToast) {
        window.showToast('success', message);
    } else {
        alert('✅ ' + message);
    }
}

function showError(message) {
    if (window.showToast) {
        window.showToast('error', message);
    } else {
        alert('❌ Error: ' + message);
    }
}

function showInfo(message) {
    if (window.showToast) {
        window.showToast('info', message);
    } else {
        alert('ℹ️ ' + message);
    }
}

