// connection.js - Test Canvas and LLM connections (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('connectionPage', () => ({
        // State
        canvasResult: null,
        llmResult: null,
        canvasSuccess: false,
        llmSuccess: false,
        testingCanvas: false,
        testingLLM: false,
        testsComplete: false,

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    console.log('✅ API ready, starting connection tests');
                    await this.testConnections();
                });
            } else if (window.api) {
                // API already available
                console.log('✅ API already available, starting connection tests');
                await this.testConnections();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        // Test both connections
        async testConnections() {
            // Reset state
            this.canvasResult = null;
            this.llmResult = null;
            this.canvasSuccess = false;
            this.llmSuccess = false;
            this.testsComplete = false;

            // Test Canvas
            this.testingCanvas = true;
            try {
                this.canvasResult = await window.api.connection_test_canvas();
                this.canvasSuccess = this.canvasResult.success;
            } catch (error) {
                console.error('Canvas test error:', error);
                this.canvasResult = { success: false, error: 'Connection error' };
                this.canvasSuccess = false;
            }
            this.testingCanvas = false;

            // Test LLM
            this.testingLLM = true;
            try {
                this.llmResult = await window.api.connection_test_llm();
                this.llmSuccess = this.llmResult.success;
            } catch (error) {
                console.error('LLM test error:', error);
                this.llmResult = { success: false, error: 'Connection error' };
                this.llmSuccess = false;
            }
            this.testingLLM = false;

            this.testsComplete = true;
        },

        // Computed: can continue?
        get canContinue() {
            return this.canvasSuccess && this.llmSuccess;
        },

        // Computed: overall status message
        get statusMessage() {
            if (!this.testsComplete) return '';

            if (this.canvasSuccess && this.llmSuccess) {
                return '✓ All connections successful';
            } else if (!this.canvasSuccess && !this.llmSuccess) {
                return '⚠️ Both Canvas and LLM connections failed';
            } else if (!this.canvasSuccess) {
                return '⚠️ Canvas connection failed';
            } else {
                return '⚠️ LLM connection failed';
            }
        },

        // Actions
        async retry() {
            await this.testConnections();
        },

        async continueToCourses() {
            if (this.canContinue) {
                await window.api.navigate_to('courses.html');
            }
        },

        async manageProfiles() {
            await window.api.navigate_to('profiles.html');
        },

        // Helpers
        escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    }));
});
