// Assignment Agent Results - Clean agent-based implementation
let allResults = [];
let questions = [];
let currentQuestion = null;
let editedStudents = new Set();

// Per-student review state
let currentView = 'student'; // 'question' or 'student' - DEFAULT TO STUDENT
let allStudents = [];
let currentStudentIndex = -1;
let currentStudentFilter = 'all';

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', async function() {
    console.log('Assignment Agent Results: DOM loaded');

    // Use the improved API initialization
    if (window.initializeAPI) {
        window.initializeAPI(loadResults);
    } else {
        // Fallback for older versions
        console.warn('initializeAPI not available, using fallback');
        await initializeAPIFallback();
    }
});

async function initializeAPIFallback() {
    let initialized = false;

    window.addEventListener('pywebviewready', function() {
        if (!initialized && window.pywebview && window.pywebview.api) {
            window.api = window.pywebview.api;
            initialized = true;
            loadResults();
        }
    });

    if (window.pywebview && window.pywebview.api && !initialized) {
        window.api = window.pywebview.api;
        initialized = true;
        loadResults();
    }

    setTimeout(() => {
        if (!initialized) {
            showError('Unable to connect to the application. Please refresh the page.');
        }
    }, 5000);
}

async function loadResults() {
    try {
        showLoading();

        // Check if returning from edit page - if so, reload to refresh data
        const cameFromEdit = sessionStorage.getItem('returnedFromEdit');
        if (cameFromEdit) {
            sessionStorage.removeItem('returnedFromEdit');
            // Mark that we edited something
            const editInfo = JSON.parse(cameFromEdit);
            editedStudents.add(`${editInfo.student_id}-${editInfo.question_id}`);
        }

        // Use NEW agent-specific API
        const result = await window.api.assignment_get_all_agent_grades();
        
        if (!result.success) {
            showError('Failed to load results: ' + result.error);
            hideLoading();
            return;
        }

        // Data comes pre-structured by question
        questions = result.questions.map(q => ({
            id: q.id,
            text: q.text,
            points_possible: q.points_possible
        }));

        // Flatten for display and mark previously edited items
        allResults = [];
        result.questions.forEach(question => {
            question.students.forEach(student => {
                const editKey = `${student.student_id}-${question.id}`;
                allResults.push({
                    ...student,
                    question_id: question.id,
                    question_text: question.text,
                    max_points: question.points_possible,
                    edited: editedStudents.has(editKey)
                });
            });
        });

        console.log('Loaded results:', allResults.length, 'total grades');

        // Update overview stats
        updateOverviewStats();

        // Start with student view (default)
        await loadStudents();
        setupEventListeners();
        hideLoading();

    } catch (error) {
        console.error('Error loading results:', error);
        showError('Failed to load grading results: ' + error.message);
        hideLoading();
    }
}

function displayQuestions() {
    const container = document.getElementById('questions-list');
    container.innerHTML = '';

    questions.forEach((question, index) => {
        const questionResults = allResults.filter(r => r.question_id === question.id);
        const gradedCount = questionResults.filter(r => r.grade > 0).length;
        const totalCount = questionResults.length;

        let status = 'ungraded';
        let statusText = 'Ungraded';

        if (gradedCount === totalCount && totalCount > 0) {
            status = 'graded';
            statusText = 'All Graded';
        } else if (gradedCount > 0) {
            status = 'partial';
            statusText = `${gradedCount}/${totalCount} Graded`;
        }

        const questionItem = document.createElement('div');
        questionItem.className = 'question-item';
        questionItem.onclick = () => showStudents(question.id);

        questionItem.innerHTML = `
            <div class="question-info">
                <div class="question-title">Question ${index + 1}: ${truncate(question.text, 100)}</div>
                <div class="question-stats">${totalCount} students</div>
            </div>
            <div class="question-status">
                <span class="status-badge status-${status}">${statusText}</span>
                <i class="ph-caret-right" style="color: var(--text-tertiary);"></i>
            </div>
        `;

        container.appendChild(questionItem);
    });
}

function showStudents(questionId) {
    currentQuestion = questions.find(q => q.id === questionId);
    if (!currentQuestion) return;

    const questionResults = allResults.filter(r => r.question_id === questionId);

    // Update header
    document.getElementById('current-question-title').textContent =
        `Question ${questions.findIndex(q => q.id === questionId) + 1}: ${truncate(currentQuestion.text, 80)}`;

    // Display students for this question
    const container = document.getElementById('students-list');
    container.innerHTML = '';

    questionResults.forEach(result => {
        const studentItem = document.createElement('div');
        studentItem.className = 'student-item';

        // Determine grade color
        let gradeClass = 'grade-low';
        if (result.grade === result.max_points) {
            gradeClass = 'grade-high';
        } else if (result.grade >= result.max_points * 0.5) {
            gradeClass = 'grade-medium';
        }

        // Determine index for editing
        const resultIndex = allResults.indexOf(result);

        studentItem.innerHTML = `
            <div class="student-info">
                <div class="student-name">
                    ${result.student_name}
                    ${result.edited ? '<span class="edited-indicator"><i class="ph-check-circle"></i> Saved</span>' : ''}
                </div>
                <div class="student-grade">
                    Grade: <span class="${gradeClass}">${result.grade.toFixed(1)}/${result.max_points}</span>
                </div>
                ${result.feedback ? `<div class="student-feedback">"${truncate(result.feedback, 80)}"</div>` : ''}
            </div>
            <div class="student-actions">
                <button class="btn btn-sm btn-primary edit-btn" data-result-index="${resultIndex}">
                    <i class="ph-pencil"></i>
                    Edit
                </button>
            </div>
        `;

        container.appendChild(studentItem);
    });

    // Add event listeners to edit buttons
    const editButtons = container.querySelectorAll('.edit-btn');
    editButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.stopPropagation();
            const resultIndex = parseInt(button.dataset.resultIndex, 10);
            const result = allResults[resultIndex];
            if (result) {
                editStudent(resultIndex);
            }
        });
    });

    // Switch views
    document.getElementById('question-list-view').classList.add('hidden');
    document.getElementById('students-for-question-view').classList.remove('hidden');
}

function backToQuestions() {
    document.getElementById('students-for-question-view').classList.add('hidden');
    document.getElementById('question-list-view').classList.remove('hidden');
}

function editStudent(resultIndex) {
    console.log('editStudent called with index:', resultIndex);
    const result = allResults[resultIndex];
    console.log('Result data:', result);

    if (!result) {
        showError('Could not find student data to edit.');
        return;
    }

    // Store grade data in session storage for edit page
    const editData = {
        student_id: result.student_id,
        student_name: result.student_name,
        question_id: result.question_id,
        question_text: result.question_text,
        student_answer: result.student_answer,
        grade: result.grade,
        max_points: result.max_points,
        feedback: result.feedback
    };

    console.log('Storing edit data:', editData);
    sessionStorage.setItem('gradeEditData', JSON.stringify(editData));

    // Verify it was stored
    const stored = sessionStorage.getItem('gradeEditData');
    console.log('Verified stored data:', stored);

    // Navigate to edit page
    console.log('Navigating to edit page');
    navigateTo('assignment_agent_grade_edit.html');
}

function editGrade(studentId, questionId) {
    // Find the result in allResults by student_id and question_id
    const resultIndex = allResults.findIndex(r =>
        r.student_id === studentId && r.question_id === questionId
    );

    if (resultIndex === -1) {
        showError('Could not find grade data to edit.');
        return;
    }

    // Use the existing editStudent function
    editStudent(resultIndex);
}

function setupEventListeners() {
    // Action buttons
    document.getElementById('upload-btn').addEventListener('click', uploadToCanvas);
    document.getElementById('export-btn').addEventListener('click', exportCSV);
}

async function uploadToCanvas() {
    const editedCount = editedStudents.size;
    
    const message = editedCount > 0
        ? `Upload grades to Canvas? (${editedCount} edited)\n\nThis cannot be undone.`
        : 'Upload all grades to Canvas?\n\nThis cannot be undone.';
    
    if (!confirm(message)) return;

    const btn = document.getElementById('upload-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="ph-spinner"></i> Uploading...';

    try {
        // CSV is always up-to-date from auto-saves
        const uploadResult = await window.api.assignment_upload_grades();

        if (uploadResult.success) {
            showSuccess('Grades uploaded successfully!');
            editedStudents.clear();
            setTimeout(() => {
                navigateTo('assignment_list.html');
            }, 2000);
        } else {
            throw new Error(uploadResult.error || uploadResult.message || 'Upload failed');
        }
    } catch (error) {
        console.error('Upload error:', error);
        showError('Upload failed: ' + error.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="ph-upload"></i> Upload to Canvas';
    }
}

async function exportCSV() {
    const btn = document.getElementById('export-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="ph-spinner ph-spin"></i> Exporting...';

    try {
        const result = await window.api.assignment_export_grades();

        if (result.success) {
            // Show path to user
            const path = result.path || '';
            const shortPath = path.length > 60 ? '...' + path.substring(path.length - 57) : path;

            showSuccessToast(`CSV file location:\n${path}`);

            // Also show in an alert with the full path so they can copy it
            alert(`CSV exported successfully!\n\nFile location:\n${path}\n\nYou can find your graded results in this file.`);
        } else {
            showErrorToast('Failed to export: ' + (result.error || 'Unknown error'));
        }
    } catch (error) {
        showErrorToast('Export failed: ' + error.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="ph-download"></i> Export CSV';
    }
}

// Utility Functions
function truncate(text, length) {
    if (!text) return '';
    return text.length > length ? text.substring(0, length) + '...' : text;
}

function showLoading() {
    const loadingHtml = '<div style="text-align: center; padding: 2rem;"><div class="loading-spinner"></div><p style="margin-top: 1rem; color: var(--text-secondary);">Loading results...</p></div>';
    document.getElementById('questions-list').innerHTML = loadingHtml;
}

function hideLoading() {
    // Loading will be replaced by actual content
}

function showSuccess(message) {
    if (window.showToast) {
        window.showToast('success', message);
    } else {
        alert('✅ ' + message);
    }
}

function showError(message) {
    if (window.showToast) {
        window.showToast('error', message);
    } else {
        alert('❌ Error: ' + message);
    }
}

function showInfo(message) {
    if (window.showToast) {
        window.showToast('info', message);
    } else {
        alert('ℹ️ ' + message);
    }
}

// Add loading spinner CSS if not exists
if (!document.querySelector('#loading-spinner-styles')) {
    const styleSheet = document.createElement('style');
    styleSheet.id = 'loading-spinner-styles';
    styleSheet.textContent = `
        .loading-spinner {
            width: 2rem;
            height: 2rem;
            border: 3px solid var(--border-color);
            border-top: 3px solid var(--color-primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(styleSheet);
}


// ============================================================================
// PER-STUDENT REVIEW FUNCTIONS
// ============================================================================

function updateOverviewStats() {
    // Calculate overall statistics
    const uniqueStudents = new Set(allResults.map(r => r.student_id));
    const uniqueQuestions = new Set(allResults.map(r => r.question_id));
    const gradedItems = allResults.filter(r => r.grade !== null && r.grade !== '' && r.grade !== undefined).length;
    const totalItems = allResults.length;
    const completionPercent = totalItems > 0 ? Math.round((gradedItems / totalItems) * 100) : 0;

    // Update DOM
    const studentsEl = document.getElementById('overview-students');
    if (studentsEl) studentsEl.textContent = uniqueStudents.size;

    const questionsEl = document.getElementById('overview-questions');
    if (questionsEl) questionsEl.textContent = uniqueQuestions.size;

    const gradedEl = document.getElementById('overview-graded');
    if (gradedEl) gradedEl.textContent = `${gradedItems}/${totalItems}`;

    const percentEl = document.getElementById('overview-percent');
    if (percentEl) percentEl.textContent = `${completionPercent}%`;

    const progressBar = document.getElementById('overall-progress-bar');
    if (progressBar) progressBar.style.width = `${completionPercent}%`;
}

async function switchView(view) {
    currentView = view;

    // Update button states (new tab design)
    const questionBtn = document.getElementById('view-by-question-btn');
    const studentBtn = document.getElementById('view-by-student-btn');

    if (view === 'question') {
        questionBtn.classList.add('active');
        studentBtn.classList.remove('active');

        // Show question view
        displayQuestions();
        document.getElementById('question-list-view').classList.remove('hidden');
        document.getElementById('student-list-view').classList.add('hidden');
        document.getElementById('student-detail-view').classList.add('hidden');
        document.getElementById('students-for-question-view').classList.add('hidden');

    } else {
        questionBtn.classList.remove('active');
        studentBtn.classList.add('active');

        // Show student view
        await loadStudents();
    }
}

async function loadStudents() {
    try {
        showLoading();

        const result = await window.api.assignment_get_agent_grades_by_student(currentStudentFilter);

        if (!result.success) {
            showError('Failed to load student data: ' + result.error);
            return;
        }

        allStudents = result.students;
        const stats = result.stats;

        // Update filter count text
        const countText = document.getElementById('student-count-text');
        if (countText) {
            const showing = allStudents.length;
            const total = stats.total_students;
            countText.textContent = showing === total ?
                `${total} students` :
                `Showing ${showing} of ${total} students`;
        }

        displayStudentList();
        hideLoading();

    } catch (error) {
        console.error('Error loading students:', error);
        showError('Failed to load student data: ' + error.message);
        hideLoading();
    }
}

function displayStudentList() {
    const questionListView = document.getElementById('question-list-view');
    const studentListView = document.getElementById('student-list-view');
    const studentDetailView = document.getElementById('student-detail-view');
    const studentsForQuestionView = document.getElementById('students-for-question-view');

    // Hide other views
    questionListView.classList.add('hidden');
    studentDetailView.classList.add('hidden');
    studentsForQuestionView.classList.add('hidden');
    studentListView.classList.remove('hidden');

    const container = document.getElementById('student-cards-list');
    container.innerHTML = '';

    if (allStudents.length === 0) {
        container.innerHTML = '<div class="text-secondary text-center" style="padding: 2rem;">No students found</div>';
        return;
    }

    allStudents.forEach((student, index) => {
        const gradePercent = student.max_possible_score > 0 ?
            (student.total_score / student.max_possible_score * 100).toFixed(1) : 0;

        const statusColor = student.ungraded_count === 0 ? 'var(--color-success)' :
                           student.graded_count === 0 ? 'var(--color-error)' :
                           'var(--color-warning)';

        const statusText = student.ungraded_count === 0 ? 'Fully Graded' :
                          student.graded_count === 0 ? 'Not Graded' :
                          `${student.graded_count}/${student.total_questions} Graded`;

        const card = document.createElement('div');
        card.className = 'student-card';
        card.innerHTML = `
            <div style="flex: 1;">
                <div style="font-weight: 500; font-size: 1.05rem; margin-bottom: 0.25rem;">
                    ${student.student_name}
                </div>
                <div style="font-size: 0.875rem; color: var(--text-secondary); font-family: var(--font-mono);">
                    ID: ${student.student_id}
                </div>
            </div>
            <div style="text-align: center; padding: 0 1.5rem;">
                <div style="font-size: 1.5rem; font-weight: 600; color: ${statusColor};">
                    ${student.total_score.toFixed(1)}/${student.max_possible_score}
                </div>
                <div style="font-size: 0.75rem; color: var(--text-secondary); margin-top: 0.25rem;">
                    ${gradePercent}%
                </div>
            </div>
            <div style="text-align: right;">
                <div style="font-size: 0.875rem; color: ${statusColor}; font-weight: 500; margin-bottom: 0.5rem;">
                    ${statusText}
                </div>
                <button class="btn btn-sm btn-primary" onclick="showStudentDetail(${index})">
                    <i class="ph-eye"></i>
                    Review
                </button>
            </div>
        `;
        container.appendChild(card);
    });
}

async function filterStudents() {
    const select = document.getElementById('student-filter-select');
    currentStudentFilter = select.value;
    await loadStudents();
}

function showStudentDetail(studentIndex) {
    currentStudentIndex = studentIndex;
    const student = allStudents[studentIndex];

    if (!student) {
        showError('Student not found');
        return;
    }

    // Update header
    document.getElementById('current-student-name').textContent = student.student_name;
    document.getElementById('current-student-score').textContent =
        `Score: ${student.total_score.toFixed(1)}/${student.max_possible_score} (${student.graded_count}/${student.total_questions} graded)`;

    // Update navigation buttons
    document.getElementById('prev-student-btn').disabled = studentIndex === 0;
    document.getElementById('next-student-btn').disabled = studentIndex === allStudents.length - 1;

    // Update submission text in left sticky panel
    const submissionTextEl = document.getElementById('submission-text');
    const submissionText = student.questions.length > 0 ? student.questions[0].student_answer : '';
    if (submissionTextEl) {
        submissionTextEl.textContent = submissionText || 'No submission text available';
    }

    // Display questions in right panel
    const container = document.getElementById('student-questions-list');
    container.innerHTML = '';

    // Display questions with inline edit capability
    student.questions.forEach((question, qIndex) => {
        const hasGrade = question.has_grade;
        const gradeColor = hasGrade ? 'var(--color-success)' : 'var(--text-tertiary)';
        const gradeQuality = hasGrade && question.max_points > 0 ?
            (question.grade / question.max_points) : 0;
        const feedbackColor = gradeQuality >= 0.8 ? 'var(--color-success)' :
                             gradeQuality >= 0.5 ? 'var(--color-warning)' :
                             'var(--color-danger)';

        const questionCard = document.createElement('div');
        questionCard.className = 'question-grade-card-inline';
        questionCard.dataset.studentId = student.student_id;
        questionCard.dataset.questionId = question.question_id;
        questionCard.dataset.questionIndex = qIndex;

        questionCard.innerHTML = `
            <!-- Display Mode (default) -->
            <div class="card-display-mode">
                <div class="card-header-inline">
                    <div style="flex: 1;">
                        <h4 style="margin: 0 0 0.5rem 0; font-size: 1.05rem; font-weight: 600; color: var(--text-primary);">
                            ${question.question_id.toUpperCase()}: ${question.question_text}
                        </h4>
                        <div style="font-size: 0.875rem; color: var(--text-secondary);">
                            Max Points: ${question.max_points}
                        </div>
                    </div>
                    <div style="display: flex; align-items: center; gap: 1.5rem;">
                        <div class="grade-display-large" style="color: ${gradeColor};">
                            ${hasGrade ? question.grade.toFixed(1) : '—'}
                        </div>
                        <button class="btn-edit-inline btn btn-sm btn-primary" onclick="enterEditMode(this)">
                            <i class="ph-pencil"></i>
                            ${hasGrade ? 'Edit' : 'Grade'}
                        </button>
                    </div>
                </div>
                ${hasGrade ? `
                <div class="feedback-display-box" style="border-left-color: ${feedbackColor};">
                    <div style="font-weight: 500; margin-bottom: 0.5rem; color: ${feedbackColor}; display: flex; align-items: center; gap: 0.5rem;">
                        <i class="ph-chat-circle-text"></i>
                        Feedback
                    </div>
                    <div class="feedback-text">${question.feedback || '<em class="text-secondary">No feedback provided</em>'}</div>
                </div>
                ` : `
                <div class="feedback-display-box ungraded">
                    <em class="text-secondary">Not graded yet</em>
                </div>
                `}
            </div>

            <!-- Edit Mode (hidden by default) -->
            <div class="card-edit-mode hidden">
                <div class="card-header-inline">
                    <h4 style="margin: 0; font-size: 1.05rem; font-weight: 600; color: var(--text-primary);">
                        ${question.question_id.toUpperCase()}: ${question.question_text}
                    </h4>
                </div>

                <div class="edit-form-inline">
                    <div class="form-group-inline">
                        <label class="form-label-inline">Grade</label>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <input type="number" class="grade-input-inline" min="0" max="${question.max_points}" step="0.5" value="${hasGrade ? question.grade : ''}" placeholder="0">
                            <span style="color: var(--text-secondary); font-weight: 500;">/ ${question.max_points}</span>
                        </div>
                    </div>

                    <div class="form-group-inline">
                        <label class="form-label-inline">Feedback</label>
                        <textarea class="feedback-input-inline" rows="4" placeholder="Enter feedback for the student...">${question.feedback || ''}</textarea>
                    </div>

                    <div class="form-group-inline ai-refine-group">
                        <label class="form-label-inline">
                            <i class="ph-sparkle"></i>
                            AI Refinement (optional)
                        </label>
                        <div class="refine-wrapper-inline">
                            <input type="text" class="refine-input-inline" placeholder="e.g., 'make more concise', 'add more detail'">
                            <button class="btn btn-outline btn-sm" onclick="refineWithAIInline(this)">
                                <i class="ph-magic-wand"></i>
                                Refine
                            </button>
                        </div>
                    </div>

                    <div class="edit-actions-inline">
                        <button class="btn btn-primary" onclick="saveEditInline(this)">
                            <i class="ph-check"></i>
                            Save
                        </button>
                        <button class="btn btn-outline" onclick="cancelEditInline(this)">
                            <i class="ph-x"></i>
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
        `;
        container.appendChild(questionCard);
    });

    // Show student detail view
    document.getElementById('student-list-view').classList.add('hidden');
    document.getElementById('student-detail-view').classList.remove('hidden');
}

function backToStudentList() {
    document.getElementById('student-detail-view').classList.add('hidden');
    document.getElementById('student-list-view').classList.remove('hidden');
}

function navigateStudent(direction) {
    const newIndex = currentStudentIndex + direction;

    if (newIndex >= 0 && newIndex < allStudents.length) {
        showStudentDetail(newIndex);
    }
}

function toggleSubmission() {
    const panel = document.getElementById('submission-panel');
    const icon = document.getElementById('toggle-submission-icon');
    const grid = document.querySelector('.student-detail-grid');

    if (panel.classList.contains('collapsed')) {
        // Expand submission panel
        panel.classList.remove('collapsed');
        icon.className = 'ph-eye-slash';
        grid.style.gridTemplateColumns = '420px 1fr';
    } else {
        // Collapse submission panel
        panel.classList.add('collapsed');
        icon.className = 'ph-eye';
        grid.style.gridTemplateColumns = '60px 1fr';
    }
}

// ============================================================================
// INLINE EDITING FUNCTIONS
// ============================================================================

function enterEditMode(button) {
    const card = button.closest('.question-grade-card-inline');

    // Disable all other edit buttons while one is being edited
    document.querySelectorAll('.btn-edit-inline').forEach(btn => {
        btn.disabled = true;
    });

    // Hide display mode, show edit mode
    card.querySelector('.card-display-mode').classList.add('hidden');
    card.querySelector('.card-edit-mode').classList.remove('hidden');

    // Add editing class to card for visual feedback
    card.classList.add('editing');

    // Focus on grade input
    const gradeInput = card.querySelector('.grade-input-inline');
    if (gradeInput) {
        gradeInput.focus();
        gradeInput.select();
    }
}

function cancelEditInline(button) {
    const card = button.closest('.question-grade-card-inline');

    // Show display mode, hide edit mode
    card.querySelector('.card-edit-mode').classList.add('hidden');
    card.querySelector('.card-display-mode').classList.remove('hidden');

    // Remove editing class
    card.classList.remove('editing');

    // Re-enable all edit buttons
    document.querySelectorAll('.btn-edit-inline').forEach(btn => {
        btn.disabled = false;
    });
}

async function saveEditInline(button) {
    const card = button.closest('.question-grade-card-inline');
    const studentId = card.dataset.studentId;
    const questionId = card.dataset.questionId;

    const gradeInput = card.querySelector('.grade-input-inline');
    const feedbackInput = card.querySelector('.feedback-input-inline');

    const newGrade = gradeInput.value;
    const newFeedback = feedbackInput.value;

    // Show loading state
    button.disabled = true;
    button.innerHTML = '<div class="spinner-tiny"></div> Saving...';

    try {
        // Save via API
        const result = await window.api.assignment_update_single_grade(
            studentId,
            questionId,
            newGrade,
            newFeedback
        );

        if (result.success) {
            // Update display mode with new values
            const gradeDisplay = card.querySelector('.grade-display-large');
            const feedbackText = card.querySelector('.feedback-text');
            const feedbackBox = card.querySelector('.feedback-display-box');

            if (gradeDisplay) {
                gradeDisplay.textContent = parseFloat(newGrade).toFixed(1);
                gradeDisplay.style.color = 'var(--color-success)';
            }

            if (feedbackText) {
                feedbackText.textContent = newFeedback || 'No feedback provided';
            }

            // Update feedback box color based on grade quality
            const maxPoints = parseFloat(card.querySelector('.card-header-inline h4').textContent.match(/Max Points: (\d+)/)?.[1] || 10);
            const gradeQuality = parseFloat(newGrade) / maxPoints;
            const feedbackColor = gradeQuality >= 0.8 ? 'var(--color-success)' :
                                 gradeQuality >= 0.5 ? 'var(--color-warning)' :
                                 'var(--color-danger)';
            if (feedbackBox) {
                feedbackBox.style.borderLeftColor = feedbackColor;
                feedbackBox.classList.remove('ungraded');
            }

            // Update student data in allStudents array
            const qIndex = parseInt(card.dataset.questionIndex);
            if (allStudents[currentStudentIndex] && allStudents[currentStudentIndex].questions[qIndex]) {
                allStudents[currentStudentIndex].questions[qIndex].grade = parseFloat(newGrade);
                allStudents[currentStudentIndex].questions[qIndex].feedback = newFeedback;
                allStudents[currentStudentIndex].questions[qIndex].has_grade = true;

                // Update student totals
                allStudents[currentStudentIndex].graded_count = allStudents[currentStudentIndex].questions.filter(q => q.has_grade).length;
                allStudents[currentStudentIndex].total_score = allStudents[currentStudentIndex].questions.reduce((sum, q) => sum + (q.grade || 0), 0);

                // Update header score
                const scoreEl = document.getElementById('current-student-score');
                if (scoreEl) {
                    const student = allStudents[currentStudentIndex];
                    scoreEl.textContent = `Score: ${student.total_score.toFixed(1)}/${student.max_possible_score} (${student.graded_count}/${student.total_questions} graded)`;
                }
            }

            // Update overview stats
            updateOverviewStats();

            // Exit edit mode
            cancelEditInline(button);

            // Show success toast
            showSuccessToast('Grade saved successfully!');

        } else {
            throw new Error(result.error || 'Save failed');
        }

    } catch (error) {
        console.error('Error saving grade:', error);
        showErrorToast('Failed to save grade: ' + error.message);

        // Restore button
        button.disabled = false;
        button.innerHTML = '<i class="ph-check"></i> Save';
    }
}

async function refineWithAIInline(button) {
    const card = button.closest('.question-grade-card-inline');
    const studentId = card.dataset.studentId;
    const questionId = card.dataset.questionId;

    const refineInput = card.querySelector('.refine-input-inline');
    const feedbackInput = card.querySelector('.feedback-input-inline');
    const gradeInput = card.querySelector('.grade-input-inline');

    const instruction = refineInput.value.trim();
    if (!instruction) {
        showErrorToast('Please enter a refinement instruction');
        return;
    }

    // Get question text and max points
    const questionText = card.querySelector('.card-header-inline h4').textContent.split(':')[1].trim();
    const maxPoints = parseFloat(card.querySelector('.card-header-inline h4').textContent.match(/Max Points: (\d+)/)?.[1] || 10);

    // Get student answer from submission panel
    const studentAnswer = document.getElementById('submission-text').textContent;

    // Show loading
    button.disabled = true;
    const originalHTML = button.innerHTML;
    button.innerHTML = '<div class="spinner-tiny"></div> Refining...';

    try {
        const result = await window.api.assignment_refine_feedback_with_ai(
            studentId,
            questionId,
            studentAnswer,
            questionText,
            feedbackInput.value,
            gradeInput.value,
            maxPoints,
            instruction
        );

        if (result.success) {
            feedbackInput.value = result.new_feedback;
            refineInput.value = '';
            showSuccessToast('Feedback refined successfully!');
            feedbackInput.focus();
        } else {
            throw new Error(result.error || 'Refinement failed');
        }

    } catch (error) {
        console.error('Error refining feedback:', error);
        showErrorToast('Failed to refine feedback: ' + error.message);
    } finally {
        button.disabled = false;
        button.innerHTML = originalHTML;
    }
}

// ============================================================================
// TOAST NOTIFICATIONS
// ============================================================================

function showSuccessToast(message) {
    showToast(message, 'success');
}

function showErrorToast(message) {
    showToast(message, 'error');
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    const icon = type === 'success' ? 'ph-check-circle' :
                 type === 'error' ? 'ph-warning-circle' :
                 'ph-info';

    toast.innerHTML = `
        <i class="${icon}"></i>
        <span>${message}</span>
    `;

    document.body.appendChild(toast);

    // Animate in
    setTimeout(() => toast.classList.add('show'), 10);

    // Remove after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
