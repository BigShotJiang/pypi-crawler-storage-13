// assignment_points_setup.js - Configure question points (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('assignmentPointsSetup', () => ({
        // State
        questions: [],
        questionCount: 0,
        loading: true,
        error: null,

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadQuestions();
        },

        // Load questions from CSV
        async loadQuestions() {
            this.loading = true;
            this.error = null;

            try {
                const state = await window.api.get_state();

                if (!state.csv_path) {
                    this.error = 'No CSV loaded. Please go back and parse submissions.';
                    this.loading = false;
                    return;
                }

                const result = await window.api.assignment_get_questions();

                if (result.success && result.questions) {
                    this.questions = result.questions.map(q => ({
                        ...q,
                        points_possible: q.points_possible || 10
                    }));
                    this.questionCount = this.questions.length;
                } else {
                    this.error = result.error || 'Failed to load questions';
                }
            } catch (error) {
                console.error('Error loading questions:', error);
                this.error = 'Failed to load questions';
            }

            this.loading = false;
        },

        // Save points and continue
        async savePointsAndContinue() {
            try {
                Alpine.store('loading').show('Saving points...');

                // Collect points from all questions
                const pointsMap = {};
                this.questions.forEach(q => {
                    pointsMap[q.id] = parseFloat(q.points_possible);
                });

                // Save to CSV
                const result = await window.api.assignment_save_points(pointsMap);

                if (result.success) {
                    Alpine.store('toast').success('Points saved!');
                    await window.api.navigate_to('grading_hub.html');
                } else {
                    Alpine.store('toast').error('Error saving points: ' + result.error);
                }
            } catch (error) {
                console.error('Error saving points:', error);
                Alpine.store('toast').error('Failed to save points');
            } finally {
                Alpine.store('loading').hide();
            }
        },

        // Go back
        goBack() {
            window.history.back();
        }
    }));

    console.log('✅ Assignment Points Setup component registered');
});
