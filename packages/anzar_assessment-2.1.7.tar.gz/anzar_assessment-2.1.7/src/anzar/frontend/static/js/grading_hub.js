// grading_hub.js - Unified grading hub interface for quiz and assignment workflows

document.addEventListener('alpine:init', () => {
    Alpine.data('gradingHub', () => ({
        // State
        contentName: '',
        contentType: '', // 'quiz' or 'assignment'
        questions: [],
        loading: true,
        errorMessage: '', // To hold the error message
        filterMode: 'all', // all, ungraded, partial, graded

        // Computed properties
        get filteredQuestions() {
            switch (this.filterMode) {
                case 'ungraded':
                    return this.questions.filter(q => q.graded_count === 0);
                case 'partial':
                    return this.questions.filter(q => q.graded_count > 0 && q.graded_count < q.student_count);
                case 'graded':
                    return this.questions.filter(q => q.graded_count === q.student_count && q.student_count > 0);
                case 'all':
                default:
                    return this.questions;
            }
        },

        get gradedCount() {
            return this.questions.reduce((sum, q) => sum + q.graded_count, 0);
        },

        get totalStudentAnswers() {
            return this.questions.reduce((sum, q) => sum + q.student_count, 0);
        },

        get fullyGradedCount() {
            return this.questions.filter(q =>
                q.graded_count === q.student_count && q.student_count > 0
            ).length;
        },

        get partiallyGradedCount() {
            return this.questions.filter(q =>
                q.graded_count > 0 && q.graded_count < q.student_count
            ).length;
        },

        get notGradedCount() {
            return this.questions.filter(q => q.graded_count === 0).length;
        },

        get allGraded() {
            return this.questions.length > 0 &&
                   this.questions.every(q => q.graded_count === q.student_count && q.student_count > 0);
        },

        // Init
        async init() {
            console.log('🔍 [JS] Grading Hub: Initializing');

            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadContentInfo();
            await this.ensureCSVLoaded();
            await this.loadQuestions();
        },

        // Load content info (works for both quiz and assignment)
        async loadContentInfo() {
            try {
                const state = await window.api.get_state();
                // Fix: state properties are directly on state object, not state.state
                this.contentName = state.content_name || 'Content';
                this.contentType = state.content_type || 'quiz';
                console.log(`[JS] Content: ${this.contentName} (${this.contentType})`);
            } catch (error) {
                console.error('Error loading content info:', error);
            }
        },

        // Ensure CSV is loaded in state
        async ensureCSVLoaded() {
            try {
                const state = await window.api.get_state();

                if (!state.content_id) {
                    this.loading = false;
                    this.errorMessage = 'No content selected in the application state. Please go back and select an assignment.';
                    console.error(this.errorMessage);
                    Alpine.store('toast').error('No content selected');
                    return;
                }

                let csvCheck;
                if (this.contentType === 'quiz') {
                    csvCheck = await window.api.quiz_check_csv(state.content_id);
                    if (!csvCheck.success || !csvCheck.exists) {
                        this.loading = false;
                        this.errorMessage = 'Quiz CSV file not found. Please go back and download the quiz submissions.';
                        console.error(this.errorMessage);
                        Alpine.store('toast').warning('Please download quiz data first');
                        return;
                    }
                    if (!state.csv_path) {
                        await window.api.quiz_load_existing_csv(state.content_id);
                    }
                } else { // Assignment workflow
                    try {
                        csvCheck = await window.api.assignment_check_parsed(state.content_id);
                        if (!csvCheck.success || !csvCheck.exists) {
                            this.loading = false;
                            const path = csvCheck.csv_path ? `at path: <strong>${csvCheck.csv_path}</strong>` : '';
                            const reason = csvCheck.error ? `Reason: ${csvCheck.error}` : 'The file may not exist or is empty.';
                            this.errorMessage = `Parsed submissions CSV could not be read ${path}. ${reason}`;
                            console.error(this.errorMessage);
                            Alpine.store('toast').error('Parsed CSV not found.');
                            return;
                        }
                    } catch (error) {
                        this.loading = false;
                        this.errorMessage = `An error occurred while checking for the parsed CSV file: ${error.message}`;
                        console.error(this.errorMessage, error);
                        Alpine.store('toast').error('Failed to check assignment status');
                        return;
                    }

                    if (!state.csv_path) {
                        const csvPath = `data/course_${state.course_id}/assignment_${state.content_id}/parsed_submissions.csv`;
                        await window.api.assignment_load_parsed_csv(csvPath);
                    }
                }

                console.log('✅ CSV loaded and ready');
            } catch (error) {
                this.loading = false;
                this.errorMessage = `A critical error occurred while loading grading data: ${error.message}`;
                console.error(this.errorMessage, error);
                Alpine.store('toast').error('Failed to load grading data');
            }
        },

        // Load questions
        async loadQuestions() {
            console.log('🔍 [JS] loadQuestions() called');

            try {
                let result;

                // Use appropriate API based on content type
                if (this.contentType === 'quiz') {
                    result = await window.api.quiz_get_questions();
                } else {
                    result = await window.api.assignment_get_questions();
                }

                if (!result.success) {
                    console.error('❌ Failed to load questions:', result.error);
                    Alpine.store('toast').error('Failed to load questions');
                    this.loading = false;
                    return;
                }

                this.questions = result.questions.map(q => ({
                    id: q.id,
                    text: q.text || q.question_text || '',
                    type: q.type || q.question_type || 'essay_question',
                    points_possible: q.points_possible || 0,
                    student_count: q.answer_count || q.student_count || 0,
                    graded_count: q.graded_count || 0
                }));

                console.log(`✅ [JS] Loaded ${this.questions.length} questions`);
                this.loading = false;

            } catch (error) {
                console.error('❌ Exception loading questions:', error);
                Alpine.store('toast').error('Failed to load questions');
                this.loading = false;
            }
        },

        // Get question number (for display)
        getQuestionNumber(questionId) {
            const index = this.questions.findIndex(q => q.id === questionId);
            return index >= 0 ? index + 1 : '?';
        },

        // Format question type for display
        formatQuestionType(type) {
            const typeMap = {
                'essay_question': 'Essay',
                'multiple_choice_question': 'Multiple Choice',
                'true_false_question': 'True/False',
                'short_answer_question': 'Short Answer',
                'numerical_question': 'Numerical',
                'fill_in_multiple_blanks_question': 'Fill in Blanks',
                'matching_question': 'Matching'
            };
            return typeMap[type] || 'Question';
        },

        // Get status badge class for Bootstrap styling
        getStatusBadgeClass(question) {
            if (question.graded_count === 0) {
                return 'bg-danger'; // Red for not graded
            } else if (question.graded_count < question.student_count) {
                return 'bg-warning'; // Orange/yellow for partial
            } else {
                return 'bg-success'; // Green for complete
            }
        },

        // Get status label
        getStatusLabel(question) {
            if (question.graded_count === 0) {
                return 'Not Graded';
            } else if (question.graded_count < question.student_count) {
                return 'Partial';
            } else {
                return 'Complete';
            }
        },

        // Clean up grading state to prevent cross-question contamination
        cleanupGradingState() {
            const gradingState = Alpine.store('gradingState');
            console.log('🧹 [grading_hub] Cleaning up previous grading state...');

            // Clear question-specific data that could cause contamination
            const keysToRemove = [
                'questionData',
                'sampleAnswers',
                'gradingCriteria',
                'gradingQuestionId',
                'gradeOnlyUngraded'
            ];

            keysToRemove.forEach(key => {
                if (gradingState.get(key)) {
                    console.log(`🧹 [grading_hub] Removing ${key} from state`);
                    gradingState.remove(key);
                }
            });
        },

        // Grade question - navigate to grade_input
        async gradeQuestion(question, isRegrade = false) {
            console.log(`🔍 [JS] gradeQuestion() called for: ${question.id}, regrade: ${isRegrade}`);

            // PRE-FLIGHT CHECK: Verify LLM connectivity before proceeding
            const llmReady = await checkLLMConnectionBeforeGrading();
            if (!llmReady) {
                return; // Abort if LLM is not reachable
            }

            // Clean up previous grading state to prevent answer transfer between questions
            this.cleanupGradingState();

            // Store question data for grade_input page
            Alpine.store('gradingState').set('questionData', {
                questionId: question.id,
                questionText: question.text || '',
                answerCount: question.student_count || 0,
                pointsPossible: question.points_possible || 0,
                isQuiz: this.contentType === 'quiz',
                isRegrade: isRegrade,
                regradeMode: isRegrade ? 'all' : 'ungraded' // Default to 'all' for regrade
            });

            console.log('[JS] Stored questionData with questionId:', question.id, 'isRegrade:', isRegrade);

            // Navigate to grade input
            await window.api.navigate_to('grade_input.html');
        },

        // View graded answers for a question
        async viewGradedAnswers(question) {
            console.log(`🔍 [JS] viewGradedAnswers() called for: ${question.id}`);

            // Store question filter in session for grade_review page
            sessionStorage.setItem('gradeReviewFilter', JSON.stringify({
                mode: 'by-question',
                questionId: question.id
            }));

            // Navigate to grade review
            await window.api.navigate_to('grade_review_v2.html');
        },

        // Grade all filtered questions
        async gradeFiltered() {
            console.log(`🔍 [JS] gradeFiltered() called for ${this.filteredQuestions.length} questions`);

            if (this.filteredQuestions.length === 0) {
                Alpine.store('toast').warning('No questions to grade');
                return;
            }

            // Store list of questions to grade
            const questionsToGrade = this.filteredQuestions.map(q => ({
                id: q.id,
                text: q.text,
                points_possible: q.points_possible
            }));

            Alpine.store('gradingState').set('questionsToGrade', questionsToGrade);
            Alpine.store('gradingState').set('currentGradeIndex', 0);
            Alpine.store('gradingState').set('isQuiz', this.contentType === 'quiz');

            // Don't auto-navigate - let users choose what to grade
            console.log('✅ Grading hub loaded with', this.filteredQuestions.length, 'questions available');
        },

        // Navigate to upload/review
        // Utility: Truncate text
        truncate(text, length) {
            if (!text) return '';
            // Remove HTML tags for truncation
            const cleanText = text.replace(/<[^>]*>/g, '');
            return cleanText.length > length ? cleanText.substring(0, length) + '...' : cleanText;
        }
    }));
});