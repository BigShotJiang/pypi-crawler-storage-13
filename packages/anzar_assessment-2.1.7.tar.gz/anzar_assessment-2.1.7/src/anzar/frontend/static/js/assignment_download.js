// assignment_download.js - Assignment download management (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('assignmentDownloadPage', () => ({
        // State
        loading: true,
        folderExists: false,
        folderPath: '',
        currentState: null,

        // View states
        checking: true,
        showFolderExists: false,
        showNoFolder: false,
        downloading: false,
        showAnalysisResults: false,
        showError: false,
        errorMessage: '',

        // Download progress
        downloadStatus: '',
        downloadDetails: '',
        downloadProgress: 0,

        // Analysis results
        analysisData: null,
        recommendedStrategy: '',

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.updateContext();
            await this.checkFolder();
        },

        // Update context
        async updateContext() {
            try {
                const state = await window.api.get_state();
                this.currentState = state;

                if (window.updateActiveProfiles) {
                    window.updateActiveProfiles();
                }
            } catch (error) {
                console.error('Error loading state:', error);
            }
        },

        // Check for existing folder
        async checkFolder() {
            if (!this.currentState || !this.currentState.content_id) {
                this.showErrorState('No assignment selected');
                return;
            }

            try {
                const result = await window.api.assignment_check_folder(this.currentState.content_id);

                if (result.success) {
                    this.checking = false;

                    if (result.exists && result.path) {
                        this.folderExists = true;
                        this.folderPath = result.path;
                        this.showFolderExists = true;
                    } else {
                        this.folderExists = false;
                        this.showNoFolder = true;
                    }
                } else {
                    this.showErrorState(result.error || 'Failed to check for folder');
                }
            } catch (error) {
                console.error('Error checking folder:', error);
                this.showErrorState('Failed to check for existing submissions');
            }
        },

        // Use existing folder
        async useExistingFolder() {
            try {
                this.showFolderExists = false;
                this.downloading = true;
                this.downloadStatus = 'Loading existing folder...';
                this.downloadDetails = 'Checking submission types...';
                this.downloadProgress = 30;

                const loadResult = await window.api.assignment_load_existing_folder(this.currentState.content_id);

                if (loadResult.success) {
                    this.downloadProgress = 60;
                    this.downloadDetails = 'Checking for parsed CSV...';

                    // Check if CSV already exists from previous parsing
                    try {
                        const csvCheck = await window.api.assignment_check_parsed(this.currentState.content_id);

                        if (csvCheck.success && csvCheck.exists) {
                            this.downloadProgress = 80;
                            this.downloadStatus = 'Found existing parsed data!';
                            this.downloadDetails = 'Detecting assignment type...';

                            // Load grade data to detect assignment type
                            try {
                                const gradesData = await window.api.grades_get_all();

                                if (gradesData.success && gradesData.questions) {
                                    const isFileBased = this.detectAssignmentTypeFromData(gradesData.questions);

                                    this.downloadProgress = 100;

                                    if (isFileBased) {
                                        console.log('✅ File-based assignment detected → assignment_agent_setup.html');
                                        navigateTo('assignment_agent_setup.html');
                                    } else {
                                        console.log('✅ Parsable assignment detected → grading_hub.html');
                                        navigateTo('grading_hub.html');
                                    }
                                    return;
                                }
                            } catch (error) {
                                console.log('Could not load grades for type detection, defaulting to grading_hub');
                            }

                            // Fallback: go to grading hub if detection fails
                            console.log('✅ CSV exists, defaulting to grading_hub.html');
                            navigateTo('grading_hub.html');
                            return;
                        }
                    } catch (error) {
                        console.log('Could not check CSV status, continuing with analysis...');
                    }

                    this.downloadDetails = 'Analyzing submission formats...';
                    const recommendation = await window.api.assignment_get_parsing_recommendation();

                    this.downloadProgress = 100;

                    if (recommendation.success) {
                        await this.displayAnalysisResults(recommendation);
                    } else {
                        navigateTo('assignment_parse.html');
                    }
                } else {
                    this.showErrorState(loadResult.error || 'Failed to load existing folder');
                }
            } catch (error) {
                console.error('Error loading existing folder:', error);
                this.showErrorState('Failed to load existing assignment folder');
            }
        },

        // Download new submissions
        async downloadNewSubmissions() {
            await this.downloadSubmissions(true);
        },

        // Download submissions
        async downloadSubmissions(forceDownload = false) {
            this.showFolderExists = false;
            this.showNoFolder = false;
            this.downloading = true;

            this.downloadStatus = 'Starting download...';
            this.downloadDetails = 'Connecting to Canvas...';
            this.downloadProgress = 0;

            try {
                const result = await window.api.assignment_download_submissions(
                    this.currentState.content_id,
                    forceDownload
                );

                if (result.success) {
                    this.downloadProgress = 100;

                    // Check if CSV was automatically created (parsable PDFs >= 80%)
                    if (result.csv_created) {
                        console.log(`✅ [JS] Auto-created CSV: ${result.total_questions} questions`);
                        this.downloadStatus = 'CSV created automatically!';
                        this.downloadDetails = `${result.total_questions} questions ready for grading`;

                        // Brief pause to show completion, then navigate to grading
                        setTimeout(() => {
                            navigateTo('grading_hub.html');
                        }, 2000);
                    } else {
                        // Show traditional parsing recommendations for mixed assignments
                        this.downloadStatus = 'Download complete!';
                        this.downloadDetails = 'Analyzing submission types...';
                        this.downloadProgress = 95;

                        const recommendation = await window.api.assignment_get_parsing_recommendation();

                        this.downloadProgress = 100;

                        if (recommendation.success) {
                            await this.displayAnalysisResults(recommendation);
                        } else {
                            navigateTo('assignment_parse.html');
                        }
                    }
                } else {
                    this.showErrorState(result.error || 'Failed to download submissions');
                }
            } catch (error) {
                console.error('Error downloading submissions:', error);
                this.showErrorState('Failed to download submissions');
            }
        },

        // Display analysis results
        async displayAnalysisResults(recommendation) {
            this.downloading = false;
            this.showAnalysisResults = true;
            this.analysisData = recommendation.analysis;
            this.recommendedStrategy = recommendation.recommended_strategy;
        },

        // Computed: Is template-based strategy
        get isTemplateStrategy() {
            return this.recommendedStrategy === 'metadata';
        },

        // Computed: Is agent strategy
        get isAgentStrategy() {
            return this.recommendedStrategy === 'agent';
        },

        // Computed: Parseable percentage
        get parseablePercentage() {
            return this.analysisData ? Math.round(this.analysisData.parseable_percentage) : 0;
        },

        // Computed: Non-parseable count
        get nonParseableCount() {
            return this.analysisData
                ? (this.analysisData.non_pdf_files || 0) + (this.analysisData.legacy_pdfs || 0)
                : 0;
        },

        // Proceed to template parsing
        async proceedToParsing() {
            this.showAnalysisResults = false;
            this.downloading = true;
            this.downloadStatus = 'Checking if CSV already exists...';
            this.downloadDetails = 'Verifying parsing status...';
            this.downloadProgress = 30;

            try {
                // Check if CSV already exists from previous parsing
                const csvCheck = await window.api.assignment_check_parsed(this.currentState.content_id);

                if (csvCheck.success && csvCheck.exists) {
                    this.downloadProgress = 100;
                    this.downloadStatus = 'Already parsed!';
                    this.downloadDetails = 'Using existing parsed data';
                    console.log('✅ CSV already exists, going directly to grading hub');
                    navigateTo('grading_hub.html');
                    return;
                }

                // CSV doesn't exist, proceed with parsing
                this.downloadStatus = 'Parsing Submissions';
                this.downloadDetails = 'Automatically extracting questions from PDFs...';
                this.downloadProgress = 60;

                const result = await window.api.assignment_parse_to_csv_pdf();

                if (result.success) {
                    this.downloadProgress = 100;
                    this.downloadStatus = 'Parsing complete!';
                    navigateTo('grading_hub.html');
                } else {
                    this.showErrorState(result.error || result.message);
                }
            } catch (error) {
                this.showErrorState('Failed to parse submissions: ' + error.message);
            }
        },

        // Proceed to agent
        proceedToAgent() {
            navigateTo('assignment_agent_setup.html');
        },

        // Show error state
        // Detect assignment type from grade data
        detectAssignmentTypeFromData(questions) {
            // Need at least 2 questions to compare
            if (!questions || questions.length < 2) {
                console.log('📊 Only 1 question or no data - assuming parsable');
                return false; // Not file-based
            }

            // Group answers by student ID across all questions
            const studentAnswers = {};

            for (const question of questions) {
                if (!question.students) continue;

                for (const student of question.students) {
                    if (!student.student_id || !student.student_answer) continue;

                    if (!studentAnswers[student.student_id]) {
                        studentAnswers[student.student_id] = [];
                    }
                    studentAnswers[student.student_id].push(student.student_answer);
                }
            }

            // Check if any student has identical answers across all questions
            for (const [studentId, answers] of Object.entries(studentAnswers)) {
                if (answers.length >= 2) {
                    const firstAnswer = answers[0];
                    const allSame = answers.every(a => a === firstAnswer);

                    console.log(`📊 Assignment type: ${allSame ? 'File-based' : 'Parsable'} (checked student ${studentId} with ${answers.length} questions)`);
                    return allSame; // true = file-based, false = parsable
                }
            }

            // Fallback: assume parsable
            console.log('📊 Could not determine type - assuming parsable');
            return false;
        },

        showErrorState(message) {
            this.checking = false;
            this.showFolderExists = false;
            this.showNoFolder = false;
            this.downloading = false;
            this.showAnalysisResults = false;
            this.errorMessage = message;
            this.showError = true;
        },

        // Reload page
        reloadPage() {
            location.reload();
        },

        // Go back to assignments
        goBackToAssignments() {
            navigateTo('assignment_list.html');
        }
    }));

    // Global progress handler for assignment downloads
    window.updateDownloadProgress = function(data) {
        console.log('📊 [JS] Assignment download progress update:', data);

        try {
            // Find the assignment download page component
            const page = document.querySelector('[x-data*="assignmentDownloadPage"]');

            if (page && page._x_dataStack && page._x_dataStack[0]) {
                const component = page._x_dataStack[0];

                // Update progress state
                component.downloadProgress = data.percent || 0;
                component.downloadStatus = data.status || 'Downloading...';
                component.downloadDetails = data.details || '';

                console.log(`✅ [JS] Progress UI updated: ${data.percent}% - ${data.status}`);
            } else if (page && page.__x && page.__x.$data) {
                const component = page.__x.$data;

                component.downloadProgress = data.percent || 0;
                component.downloadStatus = data.status || 'Downloading...';
                component.downloadDetails = data.details || '';

                console.log(`✅ [JS] Progress UI updated: ${data.percent}% - ${data.status}`);
            } else {
                console.warn('[JS] Assignment download component not found for progress update');
            }
        } catch (error) {
            console.error('❌ [JS] Failed to update progress:', error);
        }
    };

    console.log('✅ Assignment download component registered');
});
