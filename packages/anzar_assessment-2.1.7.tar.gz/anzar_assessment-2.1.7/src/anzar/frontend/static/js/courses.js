// courses.js - Courses Page (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('coursesPage', () => ({
        // State
        allCourses: [],
        filteredCourses: [],
        searchTerm: '',
        loading: true,
        error: null,
        selectedCourseId: null,
        selectionFeedback: null,

        // Init
        async init() {
            // Wait for API to be ready using the proper initialization pattern
            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                // API already available
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadCourses();
        },

        // Load courses from API
        async loadCourses() {
            this.loading = true;
            this.error = null;

            // Initialize breadcrumb if available
            if (window.GuiHelpers && window.GuiHelpers.BreadcrumbNav) {
                const breadcrumbs = new window.GuiHelpers.BreadcrumbNav();
                await breadcrumbs.update('courses.html');
            }

            try {
                console.log('Calling api.course_get_list()...');
                const result = await window.api.course_get_list();
                console.log('API result:', result);

                if (result && result.success) {
                    this.allCourses = result.courses || [];
                    this.filteredCourses = [...this.allCourses];
                    console.log(`Found ${this.allCourses.length} courses`);
                } else {
                    throw new Error(result?.error || 'Failed to load courses - invalid response');
                }
            } catch (error) {
                console.error('Error loading courses:', error);
                this.error = error.message || 'Failed to load courses';
            }

            this.loading = false;
        },

        // Filter courses based on search
        filterCourses() {
            const search = this.searchTerm.toLowerCase();

            if (!search) {
                this.filteredCourses = [...this.allCourses];
            } else {
                this.filteredCourses = this.allCourses.filter(course => {
                    const name = course.name.toLowerCase();
                    const code = (course.course_code || '').toLowerCase();
                    return name.includes(search) || code.includes(search);
                });
            }
        },

        // Select a course
        async selectCourse(courseId, courseName) {
            try {
                this.selectedCourseId = courseId;
                this.selectionFeedback = `Selected: ${courseName}`;

                // Wait for visual feedback
                await new Promise(resolve => setTimeout(resolve, 500));

                // Save course selection
                const result = await window.api.course_select(courseId, courseName);

                if (result.success) {
                    // Smooth transition
                    const mainEl = document.querySelector('main');
                    if (mainEl) {
                        mainEl.style.opacity = '0';
                        mainEl.style.transition = 'opacity 0.3s ease';
                    }

                    setTimeout(async () => {
                        await window.api.navigate_to('content_select.html');
                    }, 300);
                } else {
                    Alpine.store('toast').error('Failed to select course');
                    this.selectedCourseId = null;
                    this.selectionFeedback = null;
                }
            } catch (error) {
                console.error('Error selecting course:', error);
                Alpine.store('toast').error('Error selecting course');
                this.selectedCourseId = null;
                this.selectionFeedback = null;
            }
        },

        // Refresh courses
        async refresh() {
            await this.loadCourses();
            Alpine.store('toast').success('Courses refreshed');
        },

        // Computed
        get hasCourses() {
            return this.filteredCourses.length > 0;
        },

        get showEmpty() {
            return !this.loading && !this.error && this.allCourses.length === 0;
        },

        get showError() {
            return !this.loading && this.error !== null;
        },

        // Get animation delay for stagger effect
        getAnimationDelay(index) {
            return `${index * 50}ms`;
        },

        // Check if course is selected
        isSelected(courseId) {
            return this.selectedCourseId === courseId;
        }
    }));
});

// Add animations CSS
if (!document.getElementById('courses-animation-style')) {
    const coursesAnimationStyle = document.createElement('style');
    coursesAnimationStyle.id = 'courses-animation-style';
    coursesAnimationStyle.textContent = `
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateX(-50%) translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateX(-50%) translateY(0);
            }
        }

        .course-card {
            animation: slideUp 0.3s ease forwards;
        }

        .course-card.selected {
            border-color: var(--color-primary);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .course-card.selecting {
            transform: scale(0.98);
            transition: all 0.3s ease;
        }

        .selection-feedback {
            position: absolute;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            background: var(--color-primary);
            color: white;
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 0.875rem;
            animation: fadeIn 0.3s ease;
            z-index: 10;
        }
    `;
    document.head.appendChild(coursesAnimationStyle);
}
