// quiz_list.js - Quiz selection (Alpine.js)

document.addEventListener('alpine:init', () => {
    Alpine.data('quizListPage', () => ({
        // State
        quizzes: [],
        filteredQuizzes: [],
        searchTerm: '',
        loading: true,
        error: null,
        courseName: '',

        // Init
        async init() {
            console.log('🔍 [JS] Quiz List: Initializing');

            if (window.initializeAPI) {
                window.initializeAPI(async () => {
                    await this.initializeComponent();
                });
            } else if (window.api) {
                await this.initializeComponent();
            } else {
                console.error('⚠️ API utilities not loaded');
            }
        },

        async initializeComponent() {
            await this.loadContext();
            await this.loadQuizzes();
        },

        // Load context
        async loadContext() {
            try {
                const state = await window.api.get_state();
                if (state.course_name) {
                    this.courseName = state.course_name;
                }
            } catch (error) {
                console.error('Error loading state:', error);
            }
        },

        // Load quizzes
        async loadQuizzes() {
            console.log('🔍 [JS] loadQuizzes() called');
            this.loading = true;
            this.error = null;

            try {
                const result = await window.api.quiz_get_list();

                if (result.success && result.quizzes) {
                    console.log(`✅ [JS] Successfully loaded ${result.quizzes.length} quizzes`);
                    this.quizzes = result.quizzes.sort((a, b) => a.title.localeCompare(b.title));
                    this.filteredQuizzes = [...this.quizzes];
                    this.loading = false;
                } else {
                    console.error('❌ [JS] Failed to load quizzes:', result.error);
                    this.error = result.error || 'Failed to load quizzes';
                    this.loading = false;
                }
            } catch (error) {
                console.error('❌ [JS] Exception loading quizzes:', error);
                this.error = 'Failed to connect to Canvas';
                this.loading = false;
            }
        },

        // Filter quizzes
        filterQuizzes() {
            const term = this.searchTerm.toLowerCase();
            if (!term) {
                this.filteredQuizzes = [...this.quizzes];
            } else {
                this.filteredQuizzes = this.quizzes.filter(quiz =>
                    quiz.title.toLowerCase().includes(term)
                );
            }
        },

        // Select quiz - navigates to quiz_csv.html for download options
        async selectQuiz(quiz) {
            console.log(`🔍 [JS] selectQuiz() called: ${quiz.title} (ID: ${quiz.id})`);

            try {
                // Save quiz selection in backend
                console.log('[JS] Selecting quiz in backend...');
                const selectResult = await window.api.quiz_select(quiz.id, quiz.title);

                if (!selectResult.success) {
                    console.error('❌ [JS] Quiz selection failed');
                    throw new Error(selectResult.error || 'Failed to select quiz');
                }

                console.log('✅ [JS] Quiz selected successfully');

                // Navigate to quiz_csv.html for download options
                console.log('[JS] Navigating to quiz_csv.html...');
                await window.api.navigate_to('quiz_csv.html');

            } catch (error) {
                console.error('❌ [JS] Error selecting quiz:', error);
                Alpine.store('toast').error('Failed to select quiz: ' + error.message);
            }
        },

        // Get card gradient class
        getCardClass(index) {
            return `card-gradient-${(index % 5) + 1}`;
        }
    }));

    console.log('✅ Quiz list component registered');
});
