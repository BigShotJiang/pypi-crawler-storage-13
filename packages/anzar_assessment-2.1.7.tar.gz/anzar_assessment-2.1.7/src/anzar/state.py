"""
Shared session state management for both CLI and GUI applications.
"""

import os
import logging

# Setup logging
logger = logging.getLogger(__name__)


class SessionState:
    """Maintains state throughout the grading session."""
    def __init__(self):
        self.course_id = None
        self.course_name = None
        self.content_id = None
        self.content_name = None
        self.content_type = None  # 'quiz' or 'assignment'
        self.csv_path = None
        self.folder_path = None
        self.graded_questions = set()
        self.total_questions = 0
        self.canvas_tested = False
        self.llm_tested = False
        self.active_grading_task_id = None  # Track active background grading task
    
    def set_course(self, course_id, course_name):
        """Set current course and clear content."""
        logger.info(f"State: Setting course to {course_id} - {course_name}")
        self.course_id = course_id
        self.course_name = course_name
        self.clear_content()
    
    def set_content(self, content_id, content_name, content_type):
        """Set current quiz/assignment."""
        logger.info(f"State: Setting {content_type} to {content_id} - {content_name}")
        self.content_id = content_id
        self.content_name = content_name
        self.content_type = content_type
        self.graded_questions.clear()
        self.total_questions = 0
    
    def clear_content(self):
        """Clear content-specific state."""
        logger.debug("State: Clearing content (upload complete or navigation)")
        self.content_id = None
        self.content_name = None
        self.content_type = None
        self.csv_path = None
        self.folder_path = None
        self.graded_questions.clear()
        self.total_questions = 0
    
    def add_graded_question(self, question_id):
        """Mark a question as graded."""
        # Ensure graded_questions is a set (defensive programming)
        if not isinstance(self.graded_questions, set):
            self.graded_questions = set(self.graded_questions)
        self.graded_questions.add(question_id)
        logger.info(f"State: Marked question {question_id} as graded ({len(self.graded_questions)}/{self.total_questions})")
    
    def get_progress(self):
        """Get grading progress as a string."""
        if self.total_questions > 0:
            return f"{len(self.graded_questions)}/{self.total_questions} questions graded"
        return "No active grading session"
    
    def has_active_session(self):
        """Check if there's an active grading session."""
        return self.csv_path is not None and os.path.exists(str(self.csv_path))
    
    def all_questions_graded(self):
        """Check if all questions have been graded."""
        return self.total_questions > 0 and len(self.graded_questions) == self.total_questions
    
    def set_active_grading_task(self, task_id):
        """Set the active grading task ID."""
        logger.info(f"State: Setting active grading task to {task_id}")
        self.active_grading_task_id = task_id

    def clear_active_grading_task(self):
        """Clear the active grading task."""
        logger.debug(f"State: Clearing active grading task (was: {self.active_grading_task_id})")
        self.active_grading_task_id = None

    def has_active_grading_task(self):
        """Check if there's an active grading task."""
        return self.active_grading_task_id is not None

    def to_dict(self):
        """Convert state to dictionary for JSON serialization."""
        return {
            'course_id': self.course_id,
            'course_name': self.course_name,
            'content_id': self.content_id,
            'content_name': self.content_name,
            'content_type': self.content_type,
            'csv_path': self.csv_path,
            'folder_path': self.folder_path,
            'graded_questions': list(self.graded_questions),
            'total_questions': self.total_questions,
            'canvas_tested': self.canvas_tested,
            'llm_tested': self.llm_tested,
            'active_grading_task_id': self.active_grading_task_id,
            'progress': self.get_progress(),
            'has_active_session': self.has_active_session(),
            'all_questions_graded': self.all_questions_graded()
        }