"""
Entry point for running AnZar as a module.

Usage:
    python -m anzar
"""

from anzar.app import main

if __name__ == '__main__':
    main()
