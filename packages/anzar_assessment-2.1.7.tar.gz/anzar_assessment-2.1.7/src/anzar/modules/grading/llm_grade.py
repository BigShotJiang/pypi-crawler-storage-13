"""
LLM-based grading for subjective questions - simplified.
Calls LLM APIs (OpenAI, Anthropic, local) to grade with custom criteria.
"""

import json
import logging
import re
import requests
import base64
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
from ..utils import html_to_text
from ..profile.profile_setter import get_profile_manager

logger = logging.getLogger(__name__)


def create_grading_prompt(
    question_text: str,
    student_answer: str,
    criteria: dict,
    image_paths: Optional[List[str]] = None
) -> Union[str, List[Dict]]:
    """
    Create grading prompt for LLM (with optional image support).

    Args:
        question_text: The question being graded
        student_answer: The student's answer
        criteria: Grading criteria dict with snake_case keys:
            - correct_answer: Model answer or key points
            - max_points: Maximum points
            - grading_rubric: (optional) Rubric description
            - good_examples: (optional) Examples of good answers
            - bad_examples: (optional) Examples of poor answers
            - graded_examples: (optional) Previous graded answers
            - extra_instructions: (optional) Additional instructions
            - feedback_format: (optional) Feedback format instructions
        image_paths: (optional) List of image paths for multimodal

    Returns:
        Either string prompt or list of content blocks (multimodal)
    """
    # Convert HTML to clean text
    processed_question = html_to_text(question_text)
    processed_answer = html_to_text(student_answer)

    base_prompt = f"""You are a teacher grading a student's answer to a question.

Question: {processed_question}

Student's Answer: {processed_answer}

Grading Criteria:
- Correct Answer/Key Points: {criteria.get('correct_answer', '')}
- Maximum Points: {criteria.get('max_points', 1)}"""

    # Add rubric if provided
    rubric = criteria.get('grading_rubric') or criteria.get('rubric', '')
    if rubric:
        base_prompt += f"\n- Grading Rubric: {rubric}"

    # Add optional criteria
    good_examples = criteria.get('good_examples') or criteria.get('example_correct', '')
    if good_examples:
        base_prompt += f"\n- Examples of Good Answers: {good_examples}"

    bad_examples = criteria.get('bad_examples') or criteria.get('example_wrong', '')
    if bad_examples:
        base_prompt += f"\n- Examples of Poor Answers: {bad_examples}"

    graded_examples = criteria.get('graded_examples', '')
    if graded_examples:
        if isinstance(graded_examples, list):
            graded_examples = '\n'.join(graded_examples)
        base_prompt += f"\n- Graded Examples for Reference:\n{graded_examples}"

    extra_instructions = criteria.get('extra_instructions') or criteria.get('grading_notes', '')
    if extra_instructions:
        base_prompt += f"\n- Additional Instructions: {extra_instructions}"

    base_prompt += """

Please provide:
1. Points earned (out of maximum)
2. Feedback explaining your grading decision"""

    # Add custom feedback format
    feedback_format = criteria.get('feedback_format', '')
    if feedback_format:
        base_prompt += f"\n\nFeedback Format: {feedback_format}"
    else:
        base_prompt += "\n\nFeedback Format: Brief feedback explaining your grading decision"

    base_prompt += """

IMPORTANT RESPONSE INSTRUCTIONS:
- Respond ONLY with a valid JSON object
- Do not include any explanatory text before or after the JSON
- Do not use markdown formatting (no ```json or ```)
- The JSON must contain exactly these two fields: "points" and "feedback"
- Ensure proper JSON escaping for quotes and special characters

Required JSON format:
{
    "points": <number>,
    "feedback": "<explanation of grade>"
}"""

    # If no images, return string prompt
    if not image_paths:
        return base_prompt

    # For multimodal, create content blocks
    content_blocks = [{"type": "text", "text": base_prompt}]

    # Add images
    for img_path in image_paths:
        if Path(img_path).exists():
            image_block = _create_image_content_block(img_path)
            if image_block:
                content_blocks.append(image_block)

    logger.info(f"Created multimodal prompt with {len(content_blocks)} content blocks")
    return content_blocks


def _create_image_content_block(image_path: str) -> Optional[Dict]:
    """Create image content block for multimodal LLM input."""
    try:
        with open(image_path, 'rb') as img_file:
            image_data = img_file.read()

        # Determine MIME type
        suffix = Path(image_path).suffix.lower()
        mime_types = {
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.gif': 'image/gif',
            '.webp': 'image/webp'
        }
        mime_type = mime_types.get(suffix, 'image/jpeg')

        return {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": mime_type,
                "data": base64.b64encode(image_data).decode('utf-8')
            }
        }
    except Exception as e:
        logger.error(f"Failed to load image {image_path}: {e}")
        return None


def call_llm_api(
    prompt: Union[str, List[Dict]],
    llm_config: dict,
    timeout: int = 30
) -> Tuple[bool, Union[Dict, str]]:
    """
    Call LLM API (OpenAI, Anthropic, local) with support for multimodal.

    Args:
        prompt: String prompt or list of content blocks for multimodal
        llm_config: LLM configuration with url, api_key, model
        timeout: Request timeout in seconds

    Returns:
        Tuple of (success, response_data or error_message)
    """
    try:
        headers = {'Content-Type': 'application/json'}

        # Add appropriate auth header based on provider
        url = llm_config.get('url') or llm_config.get('api_link', '')
        model = llm_config.get('model') or llm_config.get('model_name', '')

        if not url or not model:
            return False, "Missing URL or model in LLM config"

        if llm_config.get('type') == 'local':
            # Local LLMs don't need API key
            pass
        elif 'claude' in model.lower() or 'anthropic' in url:
            headers['x-api-key'] = llm_config.get('api_key', '')
            headers['anthropic-version'] = '2023-06-01'
        else:
            api_key = llm_config.get('api_key') or llm_config.get('token', '')
            if api_key:
                headers['Authorization'] = f"Bearer {api_key}"

        # Construct request body
        if isinstance(prompt, str):
            messages = [{"role": "user", "content": prompt}]
        else:
            messages = [{"role": "user", "content": prompt}]

        if 'anthropic' in url:
            # Anthropic format
            data = {
                "model": model,
                "messages": messages,
                "max_tokens": llm_config.get('max_tokens', 5000),
                "temperature": llm_config.get('temperature', 0.2)
            }
        else:
            # OpenAI format (works for most LLMs)
            data = {
                "model": model,
                "messages": messages,
                "temperature": llm_config.get('temperature', 0.2),
                "max_tokens": llm_config.get('max_tokens', 5000)
            }

        response = requests.post(url, headers=headers, json=data, timeout=timeout)

        if response.status_code != 200:
            return False, f"API error: {response.status_code} - {response.text}"

        return True, response.json()

    except requests.exceptions.Timeout:
        return False, "Request timed out"
    except Exception as e:
        return False, f"Error calling LLM: {str(e)}"


def _extract_json_candidates(text: str) -> List[Dict]:
    """
    Extract JSON candidates from text using multiple robust strategies.
    Works with thinking models and non-thinking models.
    """
    candidates = []

    # Strategy 1: Code blocks with json language tag
    for match in re.finditer(r'```(?:json)?\s*(\{(?:[^{}]|(\{[^{}]*\}))*\})\s*```', text, re.DOTALL | re.IGNORECASE):
        candidates.append({
            'type': 'code_block',
            'content': match.group(1).strip(),
            'confidence': 0.9
        })

    # Strategy 2: Intelligent brace matching for nested JSON
    brace_stack = []
    start_idx = None
    for i, char in enumerate(text):
        if char == '{':
            if not brace_stack:
                start_idx = i
            brace_stack.append(i)
        elif char == '}':
            if brace_stack:
                brace_stack.pop()
                if not brace_stack and start_idx is not None:
                    candidate_json = text[start_idx:i+1]
                    # Quick validation: should contain both 'points' and 'feedback'
                    if 'points' in candidate_json and 'feedback' in candidate_json:
                        candidates.append({
                            'type': 'brace_matched',
                            'content': candidate_json,
                            'confidence': 0.8
                        })

    # Strategy 3: Find JSON-like patterns (last resort)
    # Look for patterns that start with { and end with } with minimal whitespace
    for match in re.finditer(r'\{[^{}]*"points"[^{}]*"feedback"[^{}]*\}', text, re.DOTALL | re.IGNORECASE):
        candidates.append({
            'type': 'pattern_matched',
            'content': match.group(),
            'confidence': 0.6
        })

    # Sort candidates by confidence
    candidates.sort(key=lambda x: x['confidence'], reverse=True)
    return candidates


def _clean_json_string(json_str: str) -> str:
    """
    Clean JSON string while preserving proper escaping.
    This replaces the fragile string-based approach.
    """
    # Remove common LLM artifacts
    json_str = json_str.strip()

    # Remove markdown artifacts
    if json_str.startswith('```json'):
        json_str = json_str[7:]
    if json_str.startswith('```'):
        json_str = json_str[3:]
    if json_str.endswith('```'):
        json_str = json_str[:-3]

    json_str = json_str.strip()

    # Remove common LLM prefixes/suffixes
    prefixes_to_remove = [
        "Here's the JSON response:",
        "JSON response:",
        "Response:",
        "Result:",
        "Output:"
    ]

    for prefix in prefixes_to_remove:
        if json_str.startswith(prefix):
            json_str = json_str[len(prefix):].strip()

    # Remove trailing punctuation or text after JSON
    # Find the last } and truncate there
    last_brace = json_str.rfind('}')
    if last_brace != -1:
        json_str = json_str[:last_brace + 1]

    return json_str.strip()


def _parse_json_candidate(candidate: str) -> Optional[Dict]:
    """
    Parse a single JSON candidate with proper error handling.
    Uses json.loads directly instead of string manipulation.
    """
    try:
        # Clean the candidate string
        cleaned = _clean_json_string(candidate)

        if not cleaned:
            return None

        # Use json.loads which handles proper JSON escaping
        parsed = json.loads(cleaned)

        # Validate it's a dictionary
        if not isinstance(parsed, dict):
            logger.debug(f"Parsed JSON is not a dict: {type(parsed)}")
            return None

        return parsed

    except json.JSONDecodeError as e:
        logger.debug(f"JSON decode error: {e} in candidate: {candidate[:100]}...")
        return None
    except Exception as e:
        logger.debug(f"Unexpected error parsing JSON: {e}")
        return None


def _validate_and_normalize_result(parsed_data: Dict) -> Optional[Dict]:
    """
    Validate and normalize the parsed JSON data.
    Ensures proper types and required fields.
    """
    if not isinstance(parsed_data, dict):
        return None

    # Extract and validate points
    points = parsed_data.get('points')
    if points is None:
        logger.debug("Missing 'points' field in parsed data")
        return None

    # Handle different point formats
    try:
        if isinstance(points, str):
            # Remove common non-numeric characters
            points_clean = re.sub(r'[^\d.-]', '', points)
            points = float(points_clean)
        elif isinstance(points, (int, float)):
            points = float(points)
        else:
            logger.debug(f"Invalid points type: {type(points)}")
            return None

        # Validate points range (allow negative for partial credit logic)
        if not isinstance(points, (int, float)):
            logger.debug(f"Points conversion failed: {points}")
            return None

    except (ValueError, TypeError):
        logger.debug(f"Could not convert points to float: {points}")
        return None

    # Extract and validate feedback
    feedback = parsed_data.get('feedback')
    if feedback is None:
        feedback = "No feedback provided"
    elif not isinstance(feedback, str):
        # Convert non-string feedback to string
        try:
            feedback = str(feedback)
        except:
            feedback = "Error converting feedback to string"

    # Clean up feedback
    feedback = feedback.strip()
    if not feedback:
        feedback = "No feedback provided"

    # Remove any trailing JSON artifacts from feedback
    if feedback.endswith('"}') or feedback.endswith('"}'):
        feedback = re.sub(r'"\s*}\s*$', '', feedback).strip()

    result = {
        'points': points,
        'feedback': feedback
    }

    # Store any additional fields for debugging
    extra_fields = {k: v for k, v in parsed_data.items()
                   if k not in ['points', 'feedback']}
    if extra_fields:
        logger.debug(f"Extra fields in JSON: {extra_fields}")

    return result


def _fallback_extraction(text: str) -> Optional[Dict]:
    """
    Fallback extraction using enhanced regex patterns.
    More robust than the original approach.
    """
    logger.debug("Attempting fallback extraction from text")

    # Extract points with multiple patterns
    points_patterns = [
        r'"points"\s*:\s*(\d+\.?\d*)',
        r'points\s*[:=]\s*(\d+\.?\d*)',
        r'score\s*[:=]\s*(\d+\.?\d*)',
        r'grade\s*[:=]\s*(\d+\.?\d*)',
        r'(\d+\.?\d*)\s*(?:points?|score|grade)'
    ]

    points = None
    for pattern in points_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            try:
                points = float(match.group(1))
                break
            except (ValueError, IndexError):
                continue

    if points is None:
        logger.debug("No points found in fallback extraction")
        return None

    # Extract feedback with multiple patterns
    feedback_patterns = [
        r'"feedback"\s*:\s*"([^"]*(?:\\.[^"]*)*)"',
        r'feedback\s*[:=]\s*"([^"]*)"',
        r'feedback\s*[:=]\s*([^\n\r,}]+)',
        r'"?feedback"?\s*:\s*"([^"]*(?:\\.[^"]*)*)"'
    ]

    feedback = None
    for pattern in feedback_patterns:
        match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
        if match:
            feedback = match.group(1).strip()
            # Unescape common JSON escape sequences
            feedback = feedback.replace('\\"', '"').replace('\\n', '\n')
            break

    if feedback is None:
        feedback = "No feedback provided"

    result = {
        'points': points,
        'feedback': feedback
    }

    logger.debug(f"Fallback extraction successful: {points} points, feedback length: {len(feedback)}")
    return result


def parse_llm_response(response_data: dict, provider_type: str = "auto") -> Tuple[bool, Union[Dict, str]]:
    """
    Parse grading response from LLM with robust JSON handling.
    Works with both thinking models and non-thinking models.

    Args:
        response_data: Raw response from LLM API
        provider_type: "anthropic", "openai", or "auto" to detect

    Returns:
        Tuple of (success, parsed_result or error_message)
        parsed_result has {points: float, feedback: str}
    """
    try:
        # Auto-detect provider
        if provider_type == "auto":
            if 'content' in response_data and isinstance(response_data.get('content'), list):
                provider_type = "anthropic"
            else:
                provider_type = "openai"

        # Extract text content
        if provider_type == "anthropic":
            content = response_data.get('content', [])
            if isinstance(content, list) and content:
                text = content[0].get('text', '')
            else:
                text = str(content)
        else:
            choices = response_data.get('choices', [])
            if not choices:
                return False, "No choices in response"
            text = choices[0].get('message', {}).get('content', '')

        if not text:
            return False, "No text content in response"

        logger.debug(f"Parsing LLM response from {provider_type}, text length: {len(text)}")

        # Step 1: Extract JSON candidates
        candidates = _extract_json_candidates(text)
        logger.debug(f"Found {len(candidates)} JSON candidates")

        # Step 2: Try to parse each candidate
        for i, candidate in enumerate(candidates):
            logger.debug(f"Trying candidate {i+1}/{len(candidates)} (type: {candidate['type']}, confidence: {candidate['confidence']})")

            parsed = _parse_json_candidate(candidate['content'])
            if parsed:
                result = _validate_and_normalize_result(parsed)
                if result:
                    logger.info(f"✅ Successfully parsed JSON (candidate {i+1}): points={result['points']}, feedback_len={len(result['feedback'])}")
                    return True, result

        # Step 3: Fallback extraction if JSON parsing fails
        logger.warning("All JSON candidates failed, attempting fallback extraction")
        result = _fallback_extraction(text)
        if result:
            logger.info(f"✅ Fallback extraction successful: points={result['points']}")
            return True, result

        # Step 4: Complete failure
        error_msg = f"Failed to extract valid grading data from response. Text preview: {text[:300]}..."
        logger.error(error_msg)
        return False, error_msg

    except Exception as e:
        error_msg = f"Unexpected error in parse_llm_response: {e}"
        logger.error(error_msg, exc_info=True)
        return False, error_msg


def grade_with_llm(
    question_text: str,
    student_answer: str,
    criteria: dict,
    llm_config: Optional[dict] = None,
    image_paths: Optional[List[str]] = None,
    timeout: int = 30
) -> Dict[str, any]:
    """
    Grade a question using LLM.

    Args:
        question_text: The question text
        student_answer: Student's answer
        criteria: Grading criteria (see create_grading_prompt)
        llm_config: LLM configuration (if None, uses active profile)
        image_paths: Optional image paths for multimodal
        timeout: Request timeout in seconds

    Returns:
        dict with:
        - success (bool): If grading succeeded
        - points (float): Points earned (if success)
        - feedback (str): Feedback message (if success)
        - error (str): Error message (if not success)
    """
    logger.info(f"🔍 [MODULE] grade_with_llm() called")
    logger.debug(f"[MODULE] Question: {question_text[:100]}...")
    logger.debug(f"[MODULE] Answer length: {len(student_answer)} chars")
    logger.debug(f"[MODULE] Criteria: {criteria.keys() if criteria else 'None'}")
    logger.debug(f"[MODULE] Images: {len(image_paths) if image_paths else 0}")

    # Get LLM config if not provided
    if not llm_config:
        logger.debug(f"[MODULE] Getting active LLM profile...")
        profile_manager = get_profile_manager()
        llm_profile = profile_manager.get_active_llm_profile()
        if not llm_profile:
            return {'success': False, 'error': 'No LLM profile configured'}
        llm_config = llm_profile

    # Create prompt
    logger.debug(f"[MODULE] Creating grading prompt...")
    prompt = create_grading_prompt(question_text, student_answer, criteria, image_paths)
    logger.debug(f"[MODULE] Prompt created, length: {len(str(prompt))} chars")

    # Call LLM API
    logger.info(f"[MODULE] Calling LLM API (timeout={timeout}s)...")
    success, response = call_llm_api(prompt, llm_config, timeout)

    if not success:
        logger.error(f"❌ [MODULE] LLM API call failed: {response}")
        return {'success': False, 'error': response}

    logger.info(f"✅ [MODULE] LLM API call succeeded, parsing response...")

    # Parse response
    success, result = parse_llm_response(response)

    if not success:
        logger.error(f"❌ [MODULE] Failed to parse LLM response: {result}")
        return {'success': False, 'error': result}

    logger.info(f"✅ [MODULE] Successfully graded - Points: {result['points']}, Feedback length: {len(result['feedback'])} chars")

    # Return grading result
    return {
        'success': True,
        'points': result['points'],
        'feedback': result['feedback']
    }


def save_grading_results_to_csv(csv_path: str, grading_results: List[Dict]) -> Tuple[bool, str]:
    """
    Update CSV with grading results (incremental or bulk).

    Handles both Quiz CSV (questions as columns) and Assignment CSV (question_id column) formats.

    Args:
        csv_path: Path to CSV file
        grading_results: List of dicts with:
            - student_id: Student ID
            - question_id: Question ID
            - points: Points earned
            - feedback: Feedback text
            - (optional) success: Whether grading succeeded

    Returns:
        Tuple of (success: bool, message: str)

    Example:
        results = [
            {'student_id': '12345', 'question_id': 'q1', 'points': 8.5, 'feedback': 'Good work'},
            {'student_id': '23456', 'question_id': 'q1', 'points': 7.0, 'feedback': 'Needs improvement'}
        ]
        success, message = save_grading_results_to_csv('path/to/file.csv', results)
    """
    from modules.utils import read_csv, write_csv

    try:
        logger.info(f"Saving {len(grading_results)} grading results to {csv_path}")

        # Read existing CSV
        rows = read_csv(csv_path)

        if not rows:
            return False, "CSV file is empty or could not be read"

        # Check if this is a quiz CSV (has columns like 'q1', 'q2') or assignment CSV
        first_row = rows[0] if rows else {}
        quiz_columns = [col for col in first_row.keys() if col.startswith('q') and col[1:].isdigit()]
        is_quiz_csv = len(quiz_columns) > 0

        updated_count = 0
        failed_count = 0

        if is_quiz_csv:
            # Quiz CSV format - questions are columns, one row per student
            logger.debug("Detected quiz CSV format")

            # Create lookup map for quiz format: student_id -> question_id -> result
            student_results = {}
            for r in grading_results:
                student_id = str(r.get('student_id', ''))
                question_id = str(r.get('question_id', ''))
                if student_id not in student_results:
                    student_results[student_id] = {}
                student_results[student_id][question_id] = r

            # Update matching rows
            for row in rows:
                row_student_id = str(row.get('student_id', row.get('id', '')))

                if row_student_id in student_results:
                    # Check each question result for this student
                    for question_id, result in student_results[row_student_id].items():
                        # Update feedback column (e.g., q1_feedback)
                        feedback_col = f"{question_id}_feedback"
                        if 'feedback' in result:
                            row[feedback_col] = result['feedback']

                        # Update points column (e.g., q1_points)
                        points_col = f"{question_id}_points"
                        if 'points' in result:
                            row[points_col] = result['points']

                        updated_count += 1

                        # Track failures
                        if not result.get('success', True):
                            failed_count += 1

        else:
            # Assignment CSV format - question_id column, multiple rows per student
            logger.debug("Detected assignment CSV format")

            # Get the model name to be written to the 'llm' column
            active_llm = get_profile_manager().get_active_llm_profile()
            model_name = active_llm.get('model_name', 'graded') if active_llm else 'graded'

            # Create lookup map for fast matching: (student_id, question_id) -> result
            results_map = {
                (str(r.get('student_id', '')), str(r.get('question_id', ''))): r
                for r in grading_results
            }

            # Update matching rows
            for row in rows:
                row_student_id = str(row.get('student_id', ''))
                row_question_id = str(row.get('question_id', ''))
                key = (row_student_id, row_question_id)

                if key in results_map:
                    result = results_map[key]

                    # Update grade columns (handle both points_earned and grade column names)
                    if 'points' in result:
                        # Try both column naming conventions
                        if 'points_earned' in row:
                            row['points_earned'] = result['points']
                        if 'grade' in row:
                            row['grade'] = result['points']

                    # Update feedback
                    if 'feedback' in result:
                        row['feedback'] = result['feedback']

                    # Mark with the LLM model name
                    if 'llm' in row:
                        row['llm'] = model_name

                    updated_count += 1

                    # Track failures
                    if not result.get('success', True):
                        failed_count += 1

        # Write back to CSV
        write_csv(csv_path, rows)

        if failed_count > 0:
            message = f"Updated {updated_count} rows ({failed_count} had errors)"
            logger.warning(message)
        else:
            message = f"Successfully updated {updated_count} rows"
            logger.info(message)

        return True, message

    except Exception as e:
        error_msg = f"Error saving grading results: {e}"
        logger.error(error_msg)
        return False, error_msg
