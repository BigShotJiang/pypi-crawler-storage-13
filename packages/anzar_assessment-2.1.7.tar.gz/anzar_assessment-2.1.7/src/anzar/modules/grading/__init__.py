"""
Simplified grading module.
Reduced from 5,127 lines (10 files) to ~920 lines (3 files).

Provides:
- Auto-grading for objective questions (MCQ, T/F, numerical)
- LLM grading for subjective questions
- Upload grades to Canvas
"""

from .auto_grade import (
    is_auto_gradable,
    normalize_answer,
    parse_answer_choices,
    auto_grade_question,
)

from .llm_grade import (
    create_grading_prompt,
    call_llm_api,
    parse_llm_response,
    grade_with_llm,
)

from .upload import (
    read_graded_csv,
    send_grades_to_canvas,
    send_quiz_grades,
    send_assignment_grades,
)

__all__ = [
    # Auto-grading
    'is_auto_gradable',
    'normalize_answer',
    'parse_answer_choices',
    'auto_grade_question',
    # LLM grading
    'create_grading_prompt',
    'call_llm_api',
    'parse_llm_response',
    'grade_with_llm',
    # Upload
    'read_graded_csv',
    'send_grades_to_canvas',
    'send_quiz_grades',
    'send_assignment_grades',
]
