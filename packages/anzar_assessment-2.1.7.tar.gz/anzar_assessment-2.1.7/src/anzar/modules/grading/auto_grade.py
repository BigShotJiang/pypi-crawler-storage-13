"""
Auto-grading for objective questions - simplified.
Handles MCQ, T/F, numerical questions with exact matching.
"""

import logging
from typing import Dict

logger = logging.getLogger(__name__)


def is_auto_gradable(question_type: str) -> bool:
    """
    Check if a question type can be automatically graded.

    Args:
        question_type: Canvas question type

    Returns:
        bool: True if can be auto-graded
    """
    auto_gradable_types = {
        'multiple_choice_question',
        'true_false_question',
        'multiple_answers_question',
        'matching_question',
        'numerical_question',
        'calculated_question',
        'formula_question'
    }
    return question_type in auto_gradable_types


def parse_answer_choices(answer_choices_str: str) -> list:
    """
    Parse pipe-separated answer choices into a list.

    Args:
        answer_choices_str: Pipe-separated answer choices

    Returns:
        List of answer choices
    """
    if not answer_choices_str:
        return []
    return [choice.strip() for choice in answer_choices_str.split('|')]


def normalize_answer(answer: str) -> str:
    """
    Normalize an answer for comparison.

    Args:
        answer: Answer to normalize

    Returns:
        Normalized answer
    """
    # Remove extra whitespace and convert to lowercase
    normalized = answer.strip().lower()

    # Remove common punctuation at the end
    if normalized and normalized[-1] in '.!?':
        normalized = normalized[:-1]

    # Handle true/false variations
    true_variations = {'true', 't', 'yes', 'y', 'correct', '1'}
    false_variations = {'false', 'f', 'no', 'n', 'incorrect', '0'}

    if normalized in true_variations:
        return 'true'
    if normalized in false_variations:
        return 'false'

    return normalized


def auto_grade_question(
    question_type: str,
    student_answer: str,
    correct_answer: str,
    points_possible: float,
    answer_choices: str = ''
) -> Dict[str, any]:
    """
    Automatically grade an objective question.

    Args:
        question_type: Type of question
        student_answer: Student's answer
        correct_answer: Correct answer
        points_possible: Maximum points
        answer_choices: Available answer choices (pipe-separated)

    Returns:
        dict with:
        - success (bool): If grading succeeded
        - points (float): Points earned
        - feedback (str): Feedback message
    """
    if not is_auto_gradable(question_type):
        return {
            'success': False,
            'points': 0,
            'feedback': 'This question type requires manual grading.'
        }

    # Normalize answers for comparison
    student_norm = normalize_answer(student_answer)
    correct_norm = normalize_answer(correct_answer)

    # Handle numerical questions with tolerance
    if question_type in ['numerical_question', 'calculated_question', 'formula_question']:
        try:
            student_num = float(student_answer)
            correct_num = float(correct_answer)
            tolerance = 0.01  # 1% tolerance

            if abs(student_num - correct_num) <= abs(correct_num * tolerance):
                return {
                    'success': True,
                    'points': points_possible,
                    'feedback': f'Correct! Your answer: {student_answer}'
                }
            else:
                return {
                    'success': True,
                    'points': 0,
                    'feedback': f'Incorrect. Your answer: {student_answer}, Correct answer: {correct_answer}'
                }
        except ValueError:
            return {
                'success': True,
                'points': 0,
                'feedback': f'Invalid numerical answer. Expected a number, got: {student_answer}'
            }

    # Handle exact match questions
    if student_norm == correct_norm:
        return {
            'success': True,
            'points': points_possible,
            'feedback': 'Correct!'
        }

    # Check if student answer matches any correct variation for MCQ
    if question_type == 'multiple_choice_question' and answer_choices:
        choices = parse_answer_choices(answer_choices)

        # Check if student gave letter answer (A, B, C, etc.)
        if len(student_norm) == 1 and student_norm.isalpha():
            letter_index = ord(student_norm.upper()) - ord('A')
            if 0 <= letter_index < len(choices):
                # Check if the choice at this index is the correct answer
                if normalize_answer(choices[letter_index]) == correct_norm:
                    return {
                        'success': True,
                        'points': points_possible,
                        'feedback': f'Correct! ({student_answer.upper()}: {choices[letter_index]})'
                    }

    # Incorrect answer
    feedback = f'Incorrect. Your answer: {student_answer}'
    if correct_answer:
        feedback += f', Correct answer: {correct_answer}'

    return {
        'success': True,
        'points': 0,
        'feedback': feedback
    }
