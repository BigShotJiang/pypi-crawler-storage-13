"""
Consistency Testing Engine

Runs grading multiple times and analyzes consistency.
"""

import logging
from pathlib import Path
from typing import List, Dict, Optional
import json

logger = logging.getLogger(__name__)


class ConsistencyTester:
    """Runs consistency tests and analyzes results."""

    def __init__(self):
        pass

    def run_test(
        self,
        assignment_folder: str = "",  # Optional, for quizzes this is empty
        course_id: int = None,
        assignment_id: int = None,
        students: List[Dict] = None,
        questions: List[Dict] = None,
        num_runs: int = 3,
        llm_config: Dict = None,
        question_filter: Optional[str] = None,
        progress_callback=None
    ) -> Dict:
        """
        Run consistency test by grading same students N times.

        Args:
            assignment_folder: Path to assignment folder
            course_id: Canvas course ID
            assignment_id: Canvas assignment ID
            students: List of student dicts with id, name, folder
            questions: List of question dicts with grading criteria
            num_runs: Number of times to grade (e.g., 5)
            llm_config: LLM configuration
            question_filter: Optional question ID to test only one question
            progress_callback: Callback for progress updates

        Returns:
            Results dict with statistics and all grading data
        """
        from modules.grading.llm_grade import grade_with_llm

        student_ids = [s['id'] for s in students]
        logger.info(f"🔄 Running consistency test: {len(students)} students × {num_runs} runs")

        all_results = []

        for run_num in range(num_runs):
            logger.info(f"🔄 Consistency test - Run {run_num + 1}/{num_runs}")

            # Report progress
            if progress_callback:
                try:
                    progress_callback({
                        'current_run': run_num + 1,
                        'total_runs': num_runs,
                        'message': f'Grading run {run_num + 1} of {num_runs}'
                    })
                except Exception as e:
                    logger.warning(f"Progress callback error: {e}")

            run_results = {
                'run_number': run_num + 1,
                'grades': [],
                'success': True
            }

            # For quiz consistency testing, we always use the first (and only) question
            target_question = questions[0] if questions else None

            if not target_question:
                logger.error("No valid question found for consistency testing")
                run_results['success'] = False
                run_results['error'] = "No valid question found"
                all_results.append(run_results)
                continue  # Skip to next run

            # Grade each student for the consistency test
            for student in students:
                # For quiz consistency, student data format:
                # - id, name: student identifiers
                # - student_answer or answer: student's response
                # - question_id: which question this answer belongs to

                logger.info(f"📝 Processing student: {student}")
                student_answer = student.get('student_answer', '') or student.get('answer', '')
                logger.info(f"📝 Student {student['id']} answer: '{student_answer[:50] if student_answer else ''}...' (length: {len(student_answer) if student_answer else 0})")

                if not student_answer or not student_answer.strip():
                    logger.warning(f"❌ Skipping student {student['id']} - no answer provided or empty answer")
                    # STILL ADD TO RESULTS WITH 0 GRADE SO WE SEE SOMETHING
                    run_results['grades'].append({
                        'student_id': student['id'],
                        'student_name': student['name'],
                        'question_id': target_question.get('id', 'Q1'),
                        'grade': 0,
                        'feedback': 'No answer provided',
                        'run_number': run_num + 1
                    })
                    continue

                logger.info(f"🎯 Testing question: {target_question.get('id')} - {target_question.get('text', 'No text')[:50]}...")

                try:
                    # For quiz consistency testing, we need to get criteria from the question
                    # or use provided criteria
                    criteria = target_question.get('grading_criteria') or {
                        'correct_answer': target_question.get('correct_answer', ''),
                        'max_points': target_question.get('points_possible', target_question.get('points', 10)),
                        'rubric': target_question.get('grading_rubric', ''),
                        'grading_rubric': target_question.get('grading_rubric', '')
                    }

                    # Grade the student's answer using LLM
                    grading_result = grade_with_llm(
                        question_text=target_question.get('text', ''),
                        student_answer=student_answer,
                        criteria=criteria,
                        llm_config=llm_config,
                        timeout=30
                    )

                    if grading_result.get('success'):
                        run_results['grades'].append({
                            'student_id': student['id'],
                            'student_name': student['name'],
                            'question_id': target_question.get('id', 'Q1'),
                            'grade': grading_result.get('points', 0),
                            'feedback': grading_result.get('feedback', ''),
                            'run_number': run_num + 1
                        })
                    else:
                        logger.error(f"Failed to grade student {student['id']}: {grading_result.get('error')}")
                        run_results['grades'].append({
                            'student_id': student['id'],
                            'student_name': student['name'],
                            'question_id': target_question.get('id', 'Q1'),
                            'grade': 0,
                            'feedback': f"Grading failed: {grading_result.get('error', 'Unknown error')}",
                            'run_number': run_num + 1
                        })

                except Exception as e:
                    logger.error(f"Error grading student {student['id']}: {e}")
                    run_results['grades'].append({
                        'student_id': student['id'],
                        'student_name': student['name'],
                        'question_id': target_question.get('id', 'Q1') if target_question else 'Q1',
                        'grade': 0,
                        'feedback': f"Error: {str(e)}",
                        'run_number': run_num + 1
                    })

            all_results.append(run_results)

        # Debug logging
        logger.info(f"🔍 Analyzing {len(all_results)} results:")
        for i, r in enumerate(all_results):
            logger.info(f"  Run {i+1}: success={r.get('success')}, grades={len(r.get('grades', []))}, error={r.get('error')}")
            # Log first grade to see structure
            if r.get('grades') and len(r['grades']) > 0:
                logger.info(f"    Sample grade: {r['grades'][0]}")

        # Analyze results
        if any(r['success'] for r in all_results):
            logger.info("✅ At least one run succeeded, proceeding with analysis")
            analysis = self.analyze_consistency(all_results, students, questions)
            analysis['runs_completed'] = len([r for r in all_results if r['success']])
            analysis['runs_failed'] = len([r for r in all_results if not r['success']])
            analysis['success'] = True
            return analysis
        else:
            logger.info("❌ All grading runs failed")
            return {
                'success': False,
                'error': 'All grading runs failed',
                'runs_completed': 0,
                'runs_failed': len(all_results),
                'students_tested': len(students)
            }

    def analyze_consistency(
        self,
        results: List[Dict],
        students: List[Dict],
        questions: List[Dict]
    ) -> Dict:
        """
        Analyze consistency across multiple grading runs.

        Args:
            results: List of run results with grades
            students: List of students tested
            questions: List of questions graded

        Returns:
            Analysis dict with statistics
        """
        analysis = {
            'students_tested': len(students),
            'questions_analyzed': [],
            'raw_results': results
        }

        # Collect successful runs only
        successful_runs = [r for r in results if r.get('success')]

        if not successful_runs:
            return analysis

        # Group by question
        logger.info(f"📊 Analyzing {len(questions)} questions for {len(students)} students")
        for question in questions:
            q_id = question.get('id')
            logger.info(f"📝 Analyzing question: {q_id} (type: {type(q_id).__name__})")
            q_stats = {
                'question_id': q_id,
                'question_text': question.get('text', ''),
                'by_student': {}
            }

            # For each student
            for student in students:
                student_id = student['id']
                logger.info(f"👤 Looking for grades for student: {student_id} (type: {type(student_id).__name__})")
                grades_for_student = []
                feedbacks_for_student = []

                # Collect grades from all successful runs
                for result in successful_runs:
                    if not result.get('grades'):
                        logger.warning(f"No grades in result for run {result.get('run_number', '?')}")
                        continue

                    for row in result['grades']:
                        # DEBUG: Log what we're comparing
                        logger.info(f"🔍 Checking row: student_id={row.get('student_id')} (type: {type(row.get('student_id')).__name__}) vs {student_id} (type: {type(student_id).__name__}), question_id={row.get('question_id')} (type: {type(row.get('question_id')).__name__}) vs {q_id} (type: {type(q_id).__name__})")

                        # Convert both to strings for comparison (handle int/string mismatch)
                        if str(row.get('student_id')) == str(student_id) and str(row.get('question_id')) == str(q_id):
                            try:
                                grade_str = row.get('grade', '') or row.get('points_earned', '')
                                logger.info(f"✅ MATCH FOUND! Grade for student {student_id}: {grade_str}")
                                if grade_str:
                                    grade = float(grade_str)
                                    grades_for_student.append(grade)
                                    feedbacks_for_student.append(row.get('feedback', ''))
                            except (ValueError, TypeError) as e:
                                logger.error(f"Failed to parse grade '{grade_str}': {e}")
                                pass

                logger.info(f"📈 Student {student_id}: Found {len(grades_for_student)} grades")
                if grades_for_student:
                    # Calculate statistics
                    try:
                        import numpy as np
                        mean_grade = float(np.mean(grades_for_student))
                        std_grade = float(np.std(grades_for_student))
                        min_grade = float(np.min(grades_for_student))
                        max_grade = float(np.max(grades_for_student))
                        range_grade = max_grade - min_grade
                    except ImportError:
                        # Fallback if numpy not available
                        mean_grade = sum(grades_for_student) / len(grades_for_student)
                        std_grade = self._calculate_std_dev(grades_for_student, mean_grade)
                        min_grade = min(grades_for_student)
                        max_grade = max(grades_for_student)
                        range_grade = max_grade - min_grade

                    # Determine consistency rating
                    if std_grade < 0.5:
                        consistency = 'Excellent'
                    elif std_grade < 1.0:
                        consistency = 'Good'
                    elif std_grade < 2.0:
                        consistency = 'Moderate'
                    else:
                        consistency = 'Poor'

                    q_stats['by_student'][student_id] = {
                        'student_name': student['name'],
                        'grades': grades_for_student,
                        'feedbacks': feedbacks_for_student,
                        'mean': round(mean_grade, 2),
                        'std': round(std_grade, 2),
                        'min': round(min_grade, 1),
                        'max': round(max_grade, 1),
                        'range': round(range_grade, 1),
                        'consistency': consistency,
                        'num_runs': len(grades_for_student)
                    }

            analysis['questions_analyzed'].append(q_stats)

        return analysis

    def _calculate_std_dev(self, values: List[float], mean: float) -> float:
        """Calculate standard deviation without numpy."""
        if len(values) < 2:
            return 0.0

        variance = sum((x - mean) ** 2 for x in values) / len(values)
        return variance ** 0.5

    def save_results(self, assignment_folder: str, task_id: str, results: Dict):
        """Save consistency test results to JSON file."""
        try:
            folder = Path(assignment_folder)
            results_file = folder / f"consistency_results_{task_id}.json"

            with open(results_file, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)

            logger.info(f"✅ Saved consistency results to: {results_file}")
            return str(results_file)

        except Exception as e:
            logger.error(f"Failed to save consistency results: {e}")
            return None

    def cleanup_test_csvs(self, assignment_folder: str):
        """Remove temporary consistency test CSV files."""
        try:
            folder = Path(assignment_folder)
            test_csvs = folder.glob("*_consistency_run*.csv")

            count = 0
            for csv_file in test_csvs:
                try:
                    csv_file.unlink()
                    count += 1
                except Exception as e:
                    logger.warning(f"Could not delete {csv_file.name}: {e}")

            if count > 0:
                logger.info(f"🗑️  Cleaned up {count} consistency test CSV files")

        except Exception as e:
            logger.warning(f"Cleanup failed: {e}")
