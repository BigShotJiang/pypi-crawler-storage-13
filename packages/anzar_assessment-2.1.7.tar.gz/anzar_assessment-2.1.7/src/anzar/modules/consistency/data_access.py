"""
Data Access Layer for Consistency Testing

Provides robust data loading with multiple fallback strategies.
"""

import json
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Optional

logger = logging.getLogger(__name__)


def get_students_from_quiz_csv(csv_path: str) -> Tuple[List[Dict], List[str]]:
    """
    Get student list from quiz CSV.

    Args:
        csv_path: Path to quiz CSV file

    Returns:
        (students: List[Dict], warnings: List[str])
        students: [{'id': str, 'name': str, 'email': str}]
    """
    warnings = []
    students = []

    try:
        from modules.utils import safe_read_csv

        csv_file = Path(csv_path)
        if not csv_file.exists():
            return [], [f"ERROR: Quiz CSV not found: {csv_path}"]

        success, rows = safe_read_csv(csv_path)
        if not success or not rows:
            return [], ["ERROR: Could not read quiz CSV or CSV is empty"]

        # Extract unique students with answers
        students_dict = {}
        for row in rows:
            sid = row.get('student_id', '')
            if sid and sid not in students_dict:
                # Only include students who have answers
                if row.get('student_answer', '').strip():
                    students_dict[sid] = {
                        'id': sid,
                        'name': row.get('student_name', f'Student {sid}'),
                        'email': row.get('student_email', '')
                    }

        students = list(students_dict.values())

        if students:
            logger.info(f"✅ Loaded {len(students)} students from quiz CSV")
        else:
            warnings.append("No students with answers found in quiz CSV")

        return students, warnings

    except Exception as e:
        logger.error(f"Failed to load students from quiz CSV: {e}")
        return [], [f"ERROR: Failed to parse quiz CSV: {e}"]


def get_students_robust(assignment_folder: str) -> Tuple[List[Dict], List[str]]:
    """
    Get student list with multiple fallback strategies.

    Strategies (in order):
    1. Canvas mapping file (canvas_student_mapping.json)
    2. Scan user_* folders directly
    3. Parse from existing CSV

    Args:
        assignment_folder: Path to assignment folder

    Returns:
        (students: List[Dict], warnings: List[str])
        students: [{'id': str, 'name': str, 'folder': str}]
    """
    warnings = []
    students = []
    folder_path = Path(assignment_folder)

    # Strategy 1: Canvas mapping file
    mapping_file = folder_path / "canvas_student_mapping.json"
    if mapping_file.exists():
        try:
            with open(mapping_file, 'r', encoding='utf-8') as f:
                mapping = json.load(f)

            # Handle different mapping formats
            if isinstance(mapping, dict):
                for student_id, info in mapping.items():
                    if isinstance(info, dict):
                        # Format: {"id": {"name": "...", ...}}
                        name = info.get('name', f'Student {student_id}')
                    else:
                        # Format: {"id": "name"}
                        name = str(info)

                    # Find matching folder for this student
                    student_folders = list(folder_path.glob(f'user_{student_id}*'))
                    if student_folders:
                        # Verify folder has files
                        folder = student_folders[0]
                        has_files = any(folder.iterdir())
                        if has_files:
                            students.append({
                                'id': student_id,
                                'name': name,
                                'folder': folder.name
                            })

            if students:
                logger.info(f"✅ Loaded {len(students)} students from Canvas mapping file (with submissions)")
                return students, warnings

        except Exception as e:
            warnings.append(f"Could not parse Canvas mapping file: {e}")
            logger.warning(f"Canvas mapping file parse failed: {e}")

    # Strategy 2: Scan user_* folders directly
    user_folders = sorted([d for d in folder_path.iterdir()
                          if d.is_dir() and d.name.startswith('user_')])

    if user_folders:
        students = []
        for folder in user_folders:
            # Only include folders that have files (actual submissions)
            has_files = any(folder.iterdir())
            if not has_files:
                continue

            # Extract student ID from folder name
            # Format: user_12345 or user_12345_67890
            folder_name = folder.name
            parts = folder_name.replace('user_', '').split('_')
            student_id = parts[0] if parts else folder_name

            students.append({
                'id': student_id,
                'name': f'Student {student_id}',
                'folder': folder_name
            })

        if students:
            warnings.append(f"Using student IDs from folder scan (no Canvas mapping)")
            logger.info(f"✅ Loaded {len(students)} students from folder scan")
            return students, warnings

    # Strategy 3: Parse from existing CSV
    csv_files = list(folder_path.glob("*.csv"))
    for csv_file in csv_files:
        if 'graded' in csv_file.name.lower() or 'parsed' in csv_file.name.lower():
            try:
                from modules.utils import safe_read_csv
                success, rows = safe_read_csv(str(csv_file))

                if success and rows:
                    seen = set()
                    for row in rows:
                        sid = row.get('student_id', '')
                        if sid and sid not in seen:
                            seen.add(sid)
                            students.append({
                                'id': sid,
                                'name': row.get('student_name', f'Student {sid}'),
                                'folder': row.get('submission_folder', f'user_{sid}')
                            })

                    if students:
                        warnings.append(f"Using student list from existing CSV: {csv_file.name}")
                        logger.info(f"✅ Loaded {len(students)} students from CSV")
                        return students, warnings

            except Exception as e:
                logger.warning(f"Could not parse CSV {csv_file.name}: {e}")

    # All strategies failed
    error_msg = "ERROR: No students found in assignment folder"
    logger.error(error_msg)
    return [], [error_msg]


def get_questions_robust(
    state,
    content_type: str,
    questions_from_frontend: Optional[List[Dict]] = None
) -> Tuple[List[Dict], List[str]]:
    """
    Get questions based on content type with fallback strategies.

    Args:
        state: Session state object
        content_type: 'quiz' or 'assignment'
        questions_from_frontend: Optional questions passed from frontend

    Returns:
        (questions: List[Dict], warnings: List[str])
    """
    warnings = []

    # If questions provided from frontend, use them first
    if questions_from_frontend and len(questions_from_frontend) > 0:
        logger.info(f"✅ Using {len(questions_from_frontend)} questions from frontend")
        return questions_from_frontend, warnings

    if content_type == 'quiz':
        # Quizzes: questions from CSV
        if not state.csv_path:
            return [], ["ERROR: No CSV loaded for quiz"]

        try:
            from modules.grading.grade_llm import list_questions_in_csv
            questions = list_questions_in_csv(state.csv_path)
            if questions:
                logger.info(f"✅ Loaded {len(questions)} questions from quiz CSV")
                return questions, warnings
        except Exception as e:
            return [], [f"ERROR: Could not load quiz questions: {e}"]

    elif content_type == 'assignment':
        # Assignments: try multiple sources

        # Source 1: Existing CSV
        if state.csv_path and Path(state.csv_path).exists():
            try:
                from modules.utils import safe_read_csv
                success, rows = safe_read_csv(state.csv_path)

                if success and rows:
                    questions_dict = {}
                    for row in rows:
                        qid = row.get('question_id', '')
                        if qid and qid not in questions_dict:
                            questions_dict[qid] = {
                                'id': qid,
                                'text': row.get('question_text', ''),
                                'points': float(row.get('points_possible', 10))
                            }

                    questions = list(questions_dict.values())
                    if questions:
                        warnings.append("Using questions from existing CSV")
                        logger.info(f"✅ Loaded {len(questions)} questions from assignment CSV")
                        return questions, warnings

            except Exception as e:
                warnings.append(f"Could not extract questions from CSV: {e}")
                logger.warning(f"CSV question extraction failed: {e}")

        # Source 2: Canvas assignment description
        if state.course_id and state.content_id:
            try:
                from modules.assignment.unified_parser import get_questions_from_assignment
                questions = get_questions_from_assignment(state.course_id, state.content_id)
                if questions:
                    warnings.append("Using questions from Canvas assignment")
                    logger.info(f"✅ Loaded {len(questions)} questions from Canvas")
                    return questions, warnings
            except Exception as e:
                warnings.append(f"Could not fetch from Canvas: {e}")
                logger.warning(f"Canvas question fetch failed: {e}")

        return [], ["ERROR: No questions found for assignment"]

    return [], ["ERROR: Unknown content type"]


def validate_consistency_data(
    students: List[Dict],
    questions: List[Dict],
    assignment_folder: str
) -> Tuple[bool, List[str]]:
    """
    Validate data before running consistency test.

    Args:
        students: List of student dicts
        questions: List of question dicts
        assignment_folder: Path to assignment folder

    Returns:
        (is_valid: bool, errors: List[str])
    """
    errors = []

    # Validate students
    if not students or len(students) == 0:
        errors.append("No students provided")
    else:
        # Verify student folders exist
        folder_path = Path(assignment_folder)
        for student in students:
            student_folder = folder_path / student.get('folder', f"user_{student['id']}")
            if not student_folder.exists():
                errors.append(f"Student folder not found: {student_folder.name}")

    # Validate questions
    if not questions or len(questions) == 0:
        errors.append("No questions provided")
    else:
        for question in questions:
            if not question.get('id'):
                errors.append(f"Question missing ID: {question.get('text', 'Unknown')[:50]}")
            if not question.get('text'):
                errors.append(f"Question {question.get('id')} missing text")

    is_valid = len(errors) == 0
    return is_valid, errors
