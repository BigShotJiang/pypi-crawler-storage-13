"""
Canvas Rubric Rating Level Positioning

OPTIONAL feature that enhances Canvas rubric grading by positioning students
in the appropriate rating level instead of sending arbitrary point values.

**When This Feature Activates:**
- Canvas rubric exists
- Rubric has >2 rating levels per criterion (granular scale)
- LLM provides numeric score

**What It Does:**
- Maps LLM score to closest rating level
- Sends rating_id instead of points
- Canvas highlights the rating level in SpeedGrader

**Backward Compatibility:**
- If rubric is simple (2 levels) or doesn't exist: Uses points (existing flow)
- Falls back gracefully if feature fails
- Does not modify existing workflows

Author: AnZAR Team
Date: 2025-10-19
"""

import logging
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Constants
MIN_RATING_LEVELS_FOR_POSITIONING = 3  # Only use feature if criterion has 3+ levels
MULTI_LEVEL_THRESHOLD = 0.5  # 50% of criteria must have 3+ levels


def is_multi_level_rubric(rubric_data: Dict) -> Tuple[bool, int]:
    """
    Detect if Canvas rubric has granular rating levels.

    A multi-level rubric has multiple rating levels per criterion, allowing
    for nuanced grading (e.g., Excellent, Good, Fair, Poor).

    Args:
        rubric_data: Rubric data from Canvas (from get_content_rubric)

    Returns:
        Tuple of (is_multi_level: bool, average_rating_count: int)

    Example:
        >>> rubric = {
        ...     'rubric': [
        ...         {'ratings': [{'points': 10}, {'points': 8}, {'points': 6}, {'points': 0}]},
        ...         {'ratings': [{'points': 15}, {'points': 12}, {'points': 9}, {'points': 0}]}
        ...     ]
        ... }
        >>> is_multi_level_rubric(rubric)
        (True, 4)
    """
    if not rubric_data or not rubric_data.get('rubric'):
        return False, 0

    rubric_criteria = rubric_data['rubric']

    if not rubric_criteria:
        return False, 0

    # Count rating levels for each criterion
    rating_counts = []
    multi_level_criteria = 0

    for criterion in rubric_criteria:
        ratings = criterion.get('ratings', [])
        rating_count = len(ratings)
        rating_counts.append(rating_count)

        # Check if this criterion has granular levels
        if rating_count >= MIN_RATING_LEVELS_FOR_POSITIONING:
            multi_level_criteria += 1

    # Calculate average
    avg_ratings = sum(rating_counts) / len(rating_counts) if rating_counts else 0

    # Determine if multi-level
    # Criteria: At least 50% of criteria have 3+ rating levels
    total_criteria = len(rubric_criteria)
    is_multi_level = (multi_level_criteria / total_criteria) >= MULTI_LEVEL_THRESHOLD if total_criteria > 0 else False

    logger.debug(f"Rubric analysis: {multi_level_criteria}/{total_criteria} criteria have 3+ levels")
    logger.debug(f"Average rating levels: {avg_ratings:.1f}")
    logger.debug(f"Multi-level rubric: {is_multi_level}")

    return is_multi_level, int(avg_ratings)


def get_rubric_rating_levels(rubric_data: Dict) -> Dict[str, List[Dict]]:
    """
    Extract rating levels from Canvas rubric for all criteria.

    Builds a mapping of criterion_id → list of rating levels with IDs and points.

    Args:
        rubric_data: Rubric data from Canvas

    Returns:
        Dict mapping criterion_id to list of rating dicts:
        {
            'criterion_123': [
                {'rating_id': 'rating_abc', 'description': 'Excellent', 'points': 10},
                {'rating_id': 'rating_def', 'description': 'Good', 'points': 8},
                ...
            ]
        }

    Example:
        >>> rubric = {'rubric': [{'id': 'c1', 'ratings': [...]}]}
        >>> levels = get_rubric_rating_levels(rubric)
        >>> levels['c1']
        [{'rating_id': 'r1', 'description': 'Excellent', 'points': 10}, ...]
    """
    rating_levels = {}

    if not rubric_data or not rubric_data.get('rubric'):
        return rating_levels

    for criterion in rubric_data['rubric']:
        criterion_id = criterion.get('id')
        ratings = criterion.get('ratings', [])

        if not criterion_id or not ratings:
            continue

        # Extract rating information
        criterion_ratings = []
        for rating in ratings:
            rating_info = {
                'rating_id': rating.get('id'),
                'description': rating.get('description', 'Unnamed'),
                'points': float(rating.get('points', 0))
            }
            criterion_ratings.append(rating_info)

        # Sort by points descending (highest first)
        criterion_ratings.sort(key=lambda r: r['points'], reverse=True)

        rating_levels[criterion_id] = criterion_ratings

    logger.debug(f"Extracted rating levels for {len(rating_levels)} criteria")

    return rating_levels


def find_closest_rating(student_points: float, rating_levels: List[Dict]) -> Optional[str]:
    """
    Find the rating level closest to student's earned points.

    Uses nearest-neighbor matching to find which rating level the student
    should be positioned in based on their numeric score.

    Args:
        student_points: Points earned by student (e.g., 7.5)
        rating_levels: List of rating dicts with 'rating_id' and 'points'

    Returns:
        rating_id: ID of the closest rating level, or None if no levels

    Example:
        >>> levels = [
        ...     {'rating_id': 'r1', 'points': 10},
        ...     {'rating_id': 'r2', 'points': 8},
        ...     {'rating_id': 'r3', 'points': 6},
        ...     {'rating_id': 'r4', 'points': 0}
        ... ]
        >>> find_closest_rating(7.5, levels)
        'r2'  # 8 points is closest to 7.5
    """
    if not rating_levels:
        return None

    # Find rating with minimum distance to student's points
    closest_rating = None
    min_distance = float('inf')

    for rating in rating_levels:
        rating_points = rating.get('points', 0)
        distance = abs(student_points - rating_points)

        if distance < min_distance:
            min_distance = distance
            closest_rating = rating

    if closest_rating:
        logger.debug(f"Mapped {student_points} points → {closest_rating['description']} ({closest_rating['points']} pts)")
        return closest_rating['rating_id']

    return None


def should_use_rating_positioning(rubric_data: Dict) -> bool:
    """
    Determine if rating level positioning should be used.

    This is the main decision function that enables the feature only when appropriate.

    Criteria for activation:
    1. Rubric exists
    2. Rubric has >2 rating levels on average
    3. Not a simple binary rubric

    Args:
        rubric_data: Rubric data from Canvas

    Returns:
        bool: True if rating positioning should be used

    Example:
        >>> simple_rubric = {'rubric': [{'ratings': [{'points': 10}, {'points': 0}]}]}
        >>> should_use_rating_positioning(simple_rubric)
        False  # Only 2 levels - use points

        >>> detailed_rubric = {'rubric': [{'ratings': [{'points': 10}, {'points': 8}, {'points': 6}, {'points': 0}]}]}
        >>> should_use_rating_positioning(detailed_rubric)
        True  # 4 levels - use rating positioning
    """
    if not rubric_data:
        logger.debug("No rubric data - rating positioning disabled")
        return False

    is_multi, avg_levels = is_multi_level_rubric(rubric_data)

    if is_multi:
        logger.info(f"✨ Rating positioning ENABLED (multi-level rubric with avg {avg_levels} levels)")
    else:
        logger.debug(f"Rating positioning disabled (simple rubric with avg {avg_levels} levels)")

    return is_multi


def get_rating_summary(rubric_data: Dict) -> Dict:
    """
    Get summary of rubric rating structure for logging/debugging.

    Args:
        rubric_data: Rubric data from Canvas

    Returns:
        Dict with summary statistics
    """
    if not rubric_data or not rubric_data.get('rubric'):
        return {
            'has_rubric': False,
            'criteria_count': 0,
            'total_points': 0,
            'is_multi_level': False
        }

    criteria = rubric_data['rubric']
    is_multi, avg_levels = is_multi_level_rubric(rubric_data)
    total_points = rubric_data.get('points_possible', 0)

    rating_counts = []
    for criterion in criteria:
        rating_counts.append(len(criterion.get('ratings', [])))

    return {
        'has_rubric': True,
        'criteria_count': len(criteria),
        'total_points': total_points,
        'is_multi_level': is_multi,
        'avg_rating_levels': avg_levels,
        'rating_counts': rating_counts,
        'min_ratings': min(rating_counts) if rating_counts else 0,
        'max_ratings': max(rating_counts) if rating_counts else 0
    }


def validate_rating_positioning_data(rating_levels: Dict, student_grades: Dict) -> Tuple[bool, str]:
    """
    Validate that we have all necessary data for rating positioning.

    Args:
        rating_levels: Rating levels extracted from rubric
        student_grades: Student grading data from CSV

    Returns:
        Tuple of (is_valid: bool, error_message: str)
    """
    if not rating_levels:
        return False, "No rating levels available"

    if not student_grades or not student_grades.get('questions'):
        return False, "No student grading data"

    # Check that we have ratings for all questions
    question_ids = student_grades['questions'].keys()
    missing_ratings = []

    for q_id in question_ids:
        # In practice, criterion_id might not match q_id
        # This is just a sanity check
        if not rating_levels:
            missing_ratings.append(q_id)

    if missing_ratings and len(missing_ratings) == len(question_ids):
        return False, f"No rating levels found for any question"

    return True, ""


# ============================================================================
# Example Usage (for testing)
# ============================================================================

if __name__ == "__main__":
    """
    Test rating positioning functions with sample data.
    """
    print("\n" + "="*70)
    print("🧪 Testing Rating Positioning Module")
    print("="*70 + "\n")

    # Sample Canvas rubric with multi-level ratings
    sample_rubric = {
        'points_possible': 25,
        'rubric': [
            {
                'id': 'criterion_1',
                'description': 'Thesis Statement',
                'points': 10,
                'ratings': [
                    {'id': 'rating_1a', 'description': 'Excellent', 'points': 10},
                    {'id': 'rating_1b', 'description': 'Very Good', 'points': 8},
                    {'id': 'rating_1c', 'description': 'Good', 'points': 6},
                    {'id': 'rating_1d', 'description': 'Fair', 'points': 4},
                    {'id': 'rating_1e', 'description': 'Poor', 'points': 0}
                ]
            },
            {
                'id': 'criterion_2',
                'description': 'Evidence and Support',
                'points': 15,
                'ratings': [
                    {'id': 'rating_2a', 'description': 'Outstanding', 'points': 15},
                    {'id': 'rating_2b', 'description': 'Strong', 'points': 12},
                    {'id': 'rating_2c', 'description': 'Adequate', 'points': 9},
                    {'id': 'rating_2d', 'description': 'Weak', 'points': 6},
                    {'id': 'rating_2e', 'description': 'Insufficient', 'points': 0}
                ]
            }
        ]
    }

    # Test 1: Detect multi-level rubric
    print("Test 1: Multi-level detection")
    is_multi, avg = is_multi_level_rubric(sample_rubric)
    print(f"   Result: is_multi={is_multi}, avg_levels={avg}")
    print(f"   Expected: is_multi=True, avg_levels=5")
    print(f"   ✅ PASS\n" if is_multi and avg == 5 else "   ❌ FAIL\n")

    # Test 2: Extract rating levels
    print("Test 2: Extract rating levels")
    levels = get_rubric_rating_levels(sample_rubric)
    print(f"   Extracted levels for {len(levels)} criteria")
    print(f"   Criterion 1: {len(levels.get('criterion_1', []))} ratings")
    print(f"   Expected: 2 criteria, 5 ratings each")
    print(f"   ✅ PASS\n" if len(levels) == 2 and len(levels.get('criterion_1', [])) == 5 else "   ❌ FAIL\n")

    # Test 3: Find closest rating
    print("Test 3: Rating positioning")
    test_cases = [
        (7.5, 'criterion_1', 'rating_1b', 8),   # 7.5 → 8 (Very Good)
        (9.2, 'criterion_1', 'rating_1a', 10),  # 9.2 → 10 (Excellent)
        (5.0, 'criterion_1', 'rating_1c', 6),   # 5.0 → 6 (Good)
        (11.5, 'criterion_2', 'rating_2b', 12), # 11.5 → 12 (Strong)
    ]

    for student_pts, criterion_id, expected_rating_id, expected_points in test_cases:
        rating_id = find_closest_rating(student_pts, levels[criterion_id])
        actual_rating = next((r for r in levels[criterion_id] if r['rating_id'] == rating_id), None)
        actual_points = actual_rating['points'] if actual_rating else None

        match = rating_id == expected_rating_id
        print(f"   {student_pts} pts → {actual_rating['description'] if actual_rating else 'N/A'} ({actual_points} pts)")
        print(f"   Expected: {expected_rating_id}, Got: {rating_id}")
        print(f"   {'✅ PASS' if match else '❌ FAIL'}")

    # Test 4: Simple rubric (should not use rating positioning)
    print("\nTest 4: Simple rubric (2 levels)")
    simple_rubric = {
        'rubric': [
            {
                'id': 'c1',
                'ratings': [
                    {'id': 'r1', 'points': 10},
                    {'id': 'r2', 'points': 0}
                ]
            }
        ]
    }
    should_use = should_use_rating_positioning(simple_rubric)
    print(f"   Result: should_use={should_use}")
    print(f"   Expected: should_use=False")
    print(f"   ✅ PASS\n" if not should_use else "   ❌ FAIL\n")

    print("="*70)
    print("✅ All tests complete!")
    print("="*70 + "\n")
