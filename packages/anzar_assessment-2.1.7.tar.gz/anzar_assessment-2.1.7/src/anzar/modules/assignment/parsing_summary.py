"""
Parsing summary display module.
Shows comprehensive results after parsing assignment submissions.
"""

from typing import Dict, List
import logging

logger = logging.getLogger(__name__)
import json
from pathlib import Path


def create_parsing_summary_html(summary: Dict) -> str:
    """
    Create HTML summary of parsing results.
    
    Args:
        summary: Parsing summary from generate_parsing_summary
        
    Returns:
        HTML string for display
    """
    html = f"""
    <div class="parsing-summary">
        <div class="summary-header">
            <h2>📊 Parsing Results Summary</h2>
        </div>
        
        <div class="summary-stats">
            <div class="stat-group">
                <h3>Submission Processing</h3>
                <div class="stat-grid">
                    <div class="stat-item">
                        <span class="stat-label">Total Submissions:</span>
                        <span class="stat-value">{summary['validation']['total_submissions']}</span>
                    </div>
                    <div class="stat-item success">
                        <span class="stat-label">Successfully Parsed:</span>
                        <span class="stat-value">{summary['validation']['parsed']}</span>
                    </div>
                    <div class="stat-item warning">
                        <span class="stat-label">Excluded:</span>
                        <span class="stat-value">{summary['validation']['excluded']}</span>
                    </div>
                </div>
            </div>
    """
    
    # Add exclusion reasons if any
    if summary['validation']['excluded'] > 0:
        html += """
            <div class="stat-group">
                <h4>Exclusion Reasons</h4>
                <ul class="exclusion-list">
        """
        
        reasons = summary['validation']['excluded_reasons']
        if reasons['multiple_pdfs'] > 0:
            html += f'<li>⚠️ Multiple PDFs: {reasons["multiple_pdfs"]} students</li>'
        if reasons['no_metadata'] > 0:
            html += f'<li>❌ No metadata: {reasons["no_metadata"]} students</li>'
        if reasons['invalid_metadata'] > 0:
            html += f'<li>❌ Invalid metadata: {reasons["invalid_metadata"]} students</li>'
        if reasons['no_pdf'] > 0:
            html += f'<li>❌ No PDF submitted: {reasons["no_pdf"]} students</li>'
        
        html += """
                </ul>
            </div>
        """
    
    # Question consistency status
    consistency_icon = "✅" if summary['parsing']['questions_consistent'] else "⚠️"
    consistency_class = "success" if summary['parsing']['questions_consistent'] else "warning"
    
    html += f"""
            <div class="stat-group">
                <h3>Question Analysis</h3>
                <div class="stat-grid">
                    <div class="stat-item">
                        <span class="stat-label">Questions Found:</span>
                        <span class="stat-value">{summary['parsing']['questions_found']}</span>
                    </div>
                    <div class="stat-item {consistency_class}">
                        <span class="stat-label">Consistency:</span>
                        <span class="stat-value">{consistency_icon} {'Consistent' if summary['parsing']['questions_consistent'] else 'Inconsistent'}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Total Answers:</span>
                        <span class="stat-value">{summary['parsing']['total_rows']}</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="questions-list">
            <h3>Questions Found</h3>
            <table class="questions-table">
                <thead>
                    <tr>
                        <th>Question</th>
                        <th>Answers</th>
                        <th>Coverage</th>
                    </tr>
                </thead>
                <tbody>
    """
    
    # Add question rows
    for q in summary['questions']:
        coverage_pct = (q['answer_count'] / q['expected_count'] * 100) if q['expected_count'] > 0 else 0
        coverage_class = "success" if coverage_pct == 100 else "warning"
        
        html += f"""
                    <tr>
                        <td>
                            <strong>{q['id']}:</strong> {q['text'][:80]}{'...' if len(q['text']) > 80 else ''}
                        </td>
                        <td class="text-center">{q['answer_count']} / {q['expected_count']}</td>
                        <td class="text-center">
                            <span class="coverage-badge {coverage_class}">{coverage_pct:.0f}%</span>
                        </td>
                    </tr>
        """
    
    html += """
                </tbody>
            </table>
        </div>
    """
    
    # Add outliers if any
    if summary['outliers']:
        html += f"""
        <div class="outliers-section">
            <h3>⚠️ Students with Different Questions ({len(summary['outliers'])})</h3>
            <div class="outlier-list">
        """
        
        for outlier in summary['outliers'][:5]:
            html += f"""
                <div class="outlier-item">
                    <strong>Student {outlier['student_id']}:</strong>
            """
            if outlier['missing_questions']:
                html += f" Missing questions: {', '.join(outlier['missing_questions'])}"
            if outlier['extra_questions']:
                html += f" Extra questions: {', '.join(outlier['extra_questions'])}"
            html += "</div>"
        
        if len(summary['outliers']) > 5:
            html += f"<div class='outlier-item'>... and {len(summary['outliers']) - 5} more</div>"
        
        html += """
            </div>
        </div>
        """
    
    html += """
        <div class="action-buttons">
            <button id="proceed-to-grading" class="btn btn-primary">
                <i class="ph-pencil"></i>
                Proceed to Grading
            </button>
            <button id="download-summary" class="btn btn-secondary">
                <i class="ph-download"></i>
                Download Summary
            </button>
        </div>
    </div>
    """
    
    return html


def save_parsing_summary(assignment_folder: str, summary: Dict) -> str:
    """
    Save parsing summary to JSON file.
    
    Args:
        assignment_folder: Path to assignment folder
        summary: Parsing summary data
        
    Returns:
        Path to saved summary file
    """
    summary_path = Path(assignment_folder) / "parsing_summary.json"
    
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2)
    
    return str(summary_path)


def load_parsing_summary(assignment_folder: str) -> Dict:
    """
    Load parsing summary from JSON file.
    
    Args:
        assignment_folder: Path to assignment folder
        
    Returns:
        Parsing summary dict or None if not found
    """
    summary_path = Path(assignment_folder) / "parsing_summary.json"
    
    if summary_path.exists():
        with open(summary_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    return None


def display_parsing_summary_cli(summary: Dict) -> None:
    """
    Display parsing summary in CLI format.
    
    Args:
        summary: Parsing summary data
    """
    print("\n" + "="*70)
    logger.info("📊 ASSIGNMENT PARSING COMPLETE")
    print("="*70)
    
    # Submission stats
    val = summary['validation']
    print(f"\nSubmission Processing:")
    print(f"  Total submissions: {val['total_submissions']}")
    print(f"  ✅ Successfully parsed: {val['parsed']}")
    print(f"  ❌ Excluded: {val['excluded']}")
    
    if val['excluded'] > 0:
        print(f"\nExclusion reasons:")
        reasons = val['excluded_reasons']
        if reasons['multiple_pdfs'] > 0:
            print(f"  - Multiple PDFs: {reasons['multiple_pdfs']} students")
        if reasons['no_metadata'] > 0:
            print(f"  - No metadata: {reasons['no_metadata']} students")
        if reasons['invalid_metadata'] > 0:
            print(f"  - Invalid metadata: {reasons['invalid_metadata']} students")
        if reasons['no_pdf'] > 0:
            print(f"  - No PDF submitted: {reasons['no_pdf']} students")
    
    # Question analysis
    parsing = summary['parsing']
    consistency = "✅ Consistent" if parsing['questions_consistent'] else "⚠️  Inconsistent"
    
    print(f"\nQuestion Analysis:")
    print(f"  Questions found: {parsing['questions_found']}")
    print(f"  Question consistency: {consistency}")
    print(f"  Total answers parsed: {parsing['total_rows']}")
    
    # Question list
    print(f"\nQuestions:")
    for i, q in enumerate(summary['questions'], 1):
        coverage = f"{q['answer_count']}/{q['expected_count']}"
        print(f"  {i}. {q['id']}: {q['text'][:60]}...")
        print(f"     Answers: {coverage} ({q['answer_count'] / q['expected_count'] * 100:.0f}% coverage)")
    
    # Outliers
    if summary['outliers']:
        print(f"\n⚠️  {len(summary['outliers'])} students have different questions")
        for outlier in summary['outliers'][:3]:
            print(f"  - Student {outlier['student_id']}")
    
    print("\n" + "="*70)
    logger.info("✅ CSV file created: parsed_submissions.csv")
    logger.info("📋 Ready for grading!")
    print("="*70)