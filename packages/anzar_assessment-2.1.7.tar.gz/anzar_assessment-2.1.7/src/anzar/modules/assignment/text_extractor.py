"""
Text extraction from any submission format.
Unified interface for getting text from PDF, DOCX, ZIP, TXT, etc.
"""

from pathlib import Path
from typing import Tuple, Optional
import zipfile
import logging

logger = logging.getLogger(__name__)


def extract_student_text(student_folder: Path, verbose: bool = False) -> Tuple[bool, Optional[str], str]:
    """
    Extract full text from student submission (any format).

    This is THE KEY function that unifies all formats.

    Args:
        student_folder: Path to student's submission folder
        verbose: Print debug info

    Returns:
        (success: bool, text_content: Optional[str], error: str)
    """

    files = list(student_folder.iterdir())
    files = [f for f in files if f.is_file()]  # Only files, not dirs

    if not files:
        return False, None, "Empty folder - no files found"

    if verbose:
        print(f"    Found {len(files)} file(s): {[f.name for f in files]}")

    # Priority 1: PDF files (most common)
    pdf_files = [f for f in files if f.suffix.lower() == '.pdf']
    if pdf_files:
        success, text, error = extract_text_from_pdf(pdf_files[0], verbose)
        if success:
            return True, text, ""
        # If fails, try next format

    # Priority 2: DOCX files
    docx_files = [f for f in files if f.suffix.lower() == '.docx']
    if docx_files:
        success, text, error = extract_text_from_docx(docx_files[0], verbose)
        if success:
            return True, text, ""

    # Priority 3: ZIP files
    zip_files = [f for f in files if f.suffix.lower() == '.zip']
    if zip_files:
        success, text, error = extract_text_from_zip(zip_files[0], student_folder, verbose)
        if success:
            return True, text, ""

    # Priority 4: Text files
    text_files = [f for f in files if f.suffix.lower() in ['.txt', '.md', '.rtf']]
    if text_files:
        success, text, error = extract_text_from_text_file(text_files[0], verbose)
        if success:
            return True, text, ""

    # Priority 5: Code files (for code assignments)
    code_extensions = {'.py', '.java', '.cpp', '.c', '.js', '.sql', '.r', '.m'}
    code_files = [f for f in files if f.suffix.lower() in code_extensions]
    if code_files:
        # Concatenate all code files
        all_code = ""
        for code_file in code_files:
            all_code += f"\n\n{'='*60}\n"
            all_code += f"File: {code_file.name}\n"
            all_code += f"{'='*60}\n\n"
            try:
                all_code += code_file.read_text(encoding='utf-8', errors='ignore')
            except Exception as e:
                if verbose:
                    print(f"    ⚠️ Could not read {code_file.name}: {e}")
                continue

        if all_code.strip():
            return True, all_code, ""

    return False, None, f"No supported file format found. Files: {[f.name for f in files]}"


def extract_text_from_pdf(pdf_path: Path, verbose: bool = False) -> Tuple[bool, Optional[str], str]:
    """
    Extract all text from PDF using PyMuPDF.

    Args:
        pdf_path: Path to PDF file
        verbose: Print debug info

    Returns:
        (success: bool, text: Optional[str], error: str)
    """
    try:
        import fitz  # PyMuPDF

        if verbose:
            print(f"    Extracting text from PDF: {pdf_path.name}")

        pdf = fitz.open(str(pdf_path))

        all_text = ""
        for page_num, page in enumerate(pdf):
            text = page.get_text()
            if text.strip():  # Only add non-empty pages
                all_text += f"\n--- Page {page_num + 1} ---\n"
                all_text += text

        pdf.close()

        if not all_text.strip():
            return False, None, "PDF contains no extractable text"

        if verbose:
            print(f"    ✅ Extracted {len(all_text)} characters")

        return True, all_text, ""

    except Exception as e:
        return False, None, f"Error extracting PDF text: {str(e)}"


def extract_text_from_docx(docx_path: Path, verbose: bool = False) -> Tuple[bool, Optional[str], str]:
    """
    Extract text from Word document.

    Requires: pip install python-docx

    Args:
        docx_path: Path to DOCX file
        verbose: Print debug info

    Returns:
        (success: bool, text: Optional[str], error: str)
    """
    try:
        from docx import Document

        if verbose:
            print(f"    Extracting text from DOCX: {docx_path.name}")

        doc = Document(str(docx_path))

        # Extract paragraphs
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]

        # Extract tables (students sometimes put answers in tables)
        table_text = []
        for table in doc.tables:
            for row in table.rows:
                row_text = []
                for cell in row.cells:
                    if cell.text.strip():
                        row_text.append(cell.text)
                if row_text:
                    table_text.append(' | '.join(row_text))

        all_text = '\n'.join(paragraphs)
        if table_text:
            all_text += '\n\nTables:\n' + '\n'.join(table_text)

        if not all_text.strip():
            return False, None, "DOCX contains no text"

        if verbose:
            print(f"    ✅ Extracted {len(all_text)} characters")

        return True, all_text, ""

    except ImportError:
        return False, None, "python-docx not installed. Run: pip install python-docx"
    except Exception as e:
        return False, None, f"Error extracting DOCX text: {str(e)}"


def extract_text_from_zip(zip_path: Path, student_folder: Path, verbose: bool = False) -> Tuple[bool, Optional[str], str]:
    """
    Extract text from ZIP file.

    Strategy:
    1. Unzip to temp location
    2. Find documents inside (PDF, DOCX, TXT)
    3. Extract text from documents found
    4. If no documents, concatenate all text/code files

    Args:
        zip_path: Path to ZIP file
        student_folder: Parent folder (for extraction)
        verbose: Print debug info

    Returns:
        (success: bool, text: Optional[str], error: str)
    """
    try:
        if verbose:
            print(f"    Extracting ZIP: {zip_path.name}")

        # Extract to temp dir
        extract_dir = student_folder / 'extracted_from_zip'
        extract_dir.mkdir(exist_ok=True)

        with zipfile.ZipFile(str(zip_path), 'r') as zf:
            zf.extractall(str(extract_dir))

        # Find all files in extracted content
        all_files = list(extract_dir.rglob('*'))
        all_files = [f for f in all_files if f.is_file()]

        if not all_files:
            return False, None, "ZIP is empty"

        if verbose:
            print(f"    Found {len(all_files)} file(s) in ZIP")

        # Priority 1: Find PDF
        pdfs = [f for f in all_files if f.suffix.lower() == '.pdf']
        if pdfs:
            if verbose:
                print(f"    Found PDF in ZIP: {pdfs[0].name}")
            return extract_text_from_pdf(pdfs[0], verbose)

        # Priority 2: Find DOCX
        docx_files = [f for f in all_files if f.suffix.lower() == '.docx']
        if docx_files:
            if verbose:
                print(f"    Found DOCX in ZIP: {docx_files[0].name}")
            return extract_text_from_docx(docx_files[0], verbose)

        # Priority 3: Find text files
        text_files = [f for f in all_files if f.suffix.lower() in ['.txt', '.md']]
        if text_files:
            if verbose:
                print(f"    Found text file in ZIP: {text_files[0].name}")
            return extract_text_from_text_file(text_files[0], verbose)

        # Priority 4: Code files (concatenate all)
        code_extensions = {'.py', '.java', '.cpp', '.c', '.js', '.html', '.css', '.sql', '.r', '.m'}
        code_files = [f for f in all_files if f.suffix.lower() in code_extensions]

        if code_files:
            if verbose:
                print(f"    Found {len(code_files)} code file(s) in ZIP")

            combined = ""
            for code_file in code_files[:50]:  # Limit to 50 files
                combined += f"\n\n{'='*60}\n"
                combined += f"File: {code_file.relative_to(extract_dir)}\n"
                combined += f"{'='*60}\n\n"
                try:
                    combined += code_file.read_text(encoding='utf-8', errors='ignore')
                except Exception as e:
                    if verbose:
                        print(f"    ⚠️ Could not read {code_file.name}: {e}")
                    continue

            if combined.strip():
                return True, combined, ""

        return False, None, f"ZIP contains no supported files. Found: {[f.suffix for f in all_files[:5]]}"

    except zipfile.BadZipFile:
        return False, None, "Invalid ZIP file (corrupted)"
    except Exception as e:
        return False, None, f"Error extracting ZIP: {str(e)}"


def extract_text_from_text_file(text_path: Path, verbose: bool = False) -> Tuple[bool, Optional[str], str]:
    """
    Extract text from plain text file (.txt, .md, .rtf).

    Args:
        text_path: Path to text file
        verbose: Print debug info

    Returns:
        (success: bool, text: Optional[str], error: str)
    """
    try:
        if verbose:
            print(f"    Reading text file: {text_path.name}")

        # Try UTF-8 first
        try:
            text = text_path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            # Try common encodings
            for encoding in ['latin-1', 'cp1252', 'iso-8859-1']:
                try:
                    text = text_path.read_text(encoding=encoding)
                    if verbose:
                        print(f"    ⚠️ File not UTF-8, read as {encoding}")
                    break
                except:
                    continue
            else:
                return False, None, "Could not decode text file with any encoding"

        if not text.strip():
            return False, None, "Text file is empty"

        if verbose:
            print(f"    ✅ Read {len(text)} characters")

        return True, text, ""

    except Exception as e:
        return False, None, f"Error reading text file: {str(e)}"


def get_student_name_from_folder(user_folder: Path) -> str:
    """
    Get student name from Canvas mapping or submission_info.txt.

    Args:
        user_folder: Path to user_* folder

    Returns:
        str: Student name or "Student {id}" as fallback
    """

    # Try Canvas mapping (most reliable)
    mapping_file = user_folder.parent / 'canvas_student_mapping.json'
    if mapping_file.exists():
        try:
            import json
            with open(mapping_file, 'r', encoding='utf-8') as f:
                mapping = json.load(f)

            # Extract student ID from folder name: user_12345_67890
            parts = user_folder.name.split('_')
            student_id = parts[1] if len(parts) > 1 else None

            if student_id and str(student_id) in mapping:
                return mapping[str(student_id)].get('name', f'Student {student_id}')
        except Exception as e:
            logger.warning(f"Could not read Canvas mapping: {e}")

    # Try submission_info.txt
    info_file = user_folder / 'submission_info.txt'
    if info_file.exists():
        try:
            content = info_file.read_text(encoding='utf-8')
            for line in content.split('\n'):
                if 'Name:' in line:
                    return line.split('Name:', 1)[1].strip()
        except:
            pass

    # Fallback
    parts = user_folder.name.split('_')
    student_id = parts[1] if len(parts) > 1 else 'Unknown'
    return f'Student {student_id}'


def get_student_id_from_folder(user_folder: Path) -> str:
    """
    Extract student ID from folder name.

    Folder format: user_{student_id}_{timestamp}

    Args:
        user_folder: Path to user_* folder

    Returns:
        str: Student ID or 'unknown'
    """
    parts = user_folder.name.split('_')
    return parts[1] if len(parts) > 1 else 'unknown'
