"""
Assignment Parser Factory

Single entry point for parsing assignments.
Automatically detects best strategy and executes it.
"""

from pathlib import Path
from typing import Tuple, Optional, Dict
import logging

from .pdf_metadata_parser import analyze_submission_folder
from .strategies.metadata_strategy import MetadataParsingStrategy
from .strategies.agent_strategy import AgentParsingStrategy

logger = logging.getLogger(__name__)


class ParsingStrategy:
    """Base class for parsing strategies."""

    def can_handle(self, analysis: Dict) -> bool:
        """Check if this strategy can handle the submissions."""
        raise NotImplementedError

    def parse(self, assignment_folder: str, **kwargs) -> Tuple[bool, Optional[str], str]:
        """
        Parse the assignment.

        Returns:
            (success: bool, csv_path: Optional[str], message: str)
        """
        raise NotImplementedError

    def get_description(self) -> str:
        """Get human-readable description of what this strategy does."""
        raise NotImplementedError


class AssignmentParserFactory:
    """
    Factory for creating and executing assignment parsers.

    Automatically selects the best parsing strategy based on submission analysis.
    """

    def __init__(self):
        self.strategies = [
            MetadataParsingStrategy(),
            AgentParsingStrategy()  # Fallback strategy
        ]

    def detect_strategy(self, assignment_folder: str) -> Tuple[ParsingStrategy, Dict]:
        """
        Analyze submissions and determine best parsing strategy.

        Args:
            assignment_folder: Path to assignment folder

        Returns:
            (strategy: ParsingStrategy, analysis: Dict)
        """
        # Analyze submission folder
        analysis = analyze_submission_folder(assignment_folder)

        # Find first strategy that can handle this
        for strategy in self.strategies:
            if strategy.can_handle(analysis):
                logger.info(f"Selected strategy: {strategy.__class__.__name__}")
                return strategy, analysis

        # Should never happen (AgentStrategy is catch-all)
        raise Exception("No suitable parsing strategy found")

    def parse_assignment(
        self,
        assignment_folder: str,
        force_strategy: Optional[str] = None,
        **kwargs
    ) -> Tuple[bool, Optional[str], str, Dict]:
        """
        Parse assignment using best available strategy.

        Args:
            assignment_folder: Path to assignment folder
            force_strategy: Force specific strategy ('metadata' or 'agent')
            **kwargs: Additional parameters passed to strategy

        Returns:
            (success: bool, csv_path: Optional[str], message: str, analysis: Dict)
        """
        logger.info(f"Parsing assignment: {assignment_folder}")

        # Detect strategy
        strategy, analysis = self.detect_strategy(assignment_folder)

        # Override if forced
        if force_strategy:
            strategy = self._get_strategy_by_name(force_strategy)
            logger.info(f"Forced strategy: {force_strategy}")

        # Log what we're doing
        logger.info(f"Using strategy: {strategy.get_description()}")

        # Execute parse
        success, csv_path, message = strategy.parse(assignment_folder, **kwargs)

        return success, csv_path, message, analysis

    def get_strategy_recommendation(self, assignment_folder: str) -> Dict:
        """
        Get recommendation for which strategy to use.

        Returns:
            {
                'recommended_strategy': 'metadata' | 'agent',
                'reason': str,
                'analysis': dict,
                'description': str
            }
        """
        strategy, analysis = self.detect_strategy(assignment_folder)

        return {
            'recommended_strategy': 'metadata' if isinstance(strategy, MetadataParsingStrategy) else 'agent',
            'reason': self._get_recommendation_reason(analysis),
            'analysis': analysis,
            'description': strategy.get_description()
        }

    def _get_strategy_by_name(self, name: str) -> ParsingStrategy:
        """Get strategy instance by name."""
        for strategy in self.strategies:
            if name in strategy.__class__.__name__.lower():
                return strategy
        raise ValueError(f"Unknown strategy: {name}")

    def _get_recommendation_reason(self, analysis: Dict) -> str:
        """Generate human-readable reason for strategy choice."""
        parseable_pct = analysis.get('parseable_percentage', 0)

        if parseable_pct >= 80:
            return f"{parseable_pct:.0f}% of submissions use the template format"
        else:
            return f"Only {parseable_pct:.0f}% use template format - mixed formats detected"


# Global factory instance
parser_factory = AssignmentParserFactory()


# Convenience functions
def parse_assignment(assignment_folder: str, **kwargs):
    """Parse assignment using auto-detected strategy."""
    return parser_factory.parse_assignment(assignment_folder, **kwargs)


def get_parsing_recommendation(assignment_folder: str):
    """Get recommendation for parsing strategy."""
    return parser_factory.get_strategy_recommendation(assignment_folder)
