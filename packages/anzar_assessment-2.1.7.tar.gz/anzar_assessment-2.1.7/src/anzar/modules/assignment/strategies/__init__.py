"""
Assignment parsing strategies.
"""

from .metadata_strategy import MetadataParsingStrategy
from .agent_strategy import AgentParsingStrategy

__all__ = ['MetadataParsingStrategy', 'AgentParsingStrategy']
