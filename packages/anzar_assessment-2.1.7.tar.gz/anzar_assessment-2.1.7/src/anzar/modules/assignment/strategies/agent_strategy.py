"""
Agent-based parsing strategy for non-template submissions.
"""

from pathlib import Path
from typing import Tuple, Optional, Dict, List
import logging

logger = logging.getLogger(__name__)


class AgentParsingStrategy:
    """
    Parse assignments using LangGraph grading agent.

    Handles:
    - Non-template PDFs
    - Mixed formats (PDF, DOCX, ZIP, TXT, Code)
    - Automatic grading included
    """

    def can_handle(self, analysis: Dict) -> bool:
        """
        This is the fallback strategy - handles everything.
        """
        return True  # Always can handle

    def parse(self, assignment_folder: str, **kwargs) -> Tuple[bool, Optional[str], str]:
        """
        Parse using unified parser (extracts text from all formats to CSV).

        Requires:
        - questions_list: List of questions to grade
        - course_id, assignment_id: For metadata
        """
        from modules.assignment.unified_parser import parse_assignment_unified

        # Extract kwargs
        questions_list = kwargs.get('questions_list')
        course_id = kwargs.get('course_id')
        assignment_id = kwargs.get('assignment_id')
        force_parse = kwargs.get('force_parse', False)
        verbose = kwargs.get('verbose', True)

        if not questions_list:
            # Try to extract from Canvas
            if course_id and assignment_id:
                from modules.assignment.unified_parser import get_questions_from_assignment
                questions_list = get_questions_from_assignment(course_id, assignment_id)

            if not questions_list:
                return False, None, "No questions provided and could not extract from Canvas"

        logger.info(f"Agent strategy: Parsing {assignment_folder} with {len(questions_list)} questions")

        # Run unified parser
        success, csv_path, message = parse_assignment_unified(
            assignment_folder=assignment_folder,
            course_id=course_id,
            assignment_id=assignment_id,
            questions_list=questions_list,
            force_parse=force_parse,
            verbose=verbose
        )

        if success:
            return True, csv_path, message
        else:
            return False, None, message

    def get_description(self) -> str:
        """Human-readable description."""
        return "AI Agent: Extract text, fetch rubric, grade automatically, output results for review"
