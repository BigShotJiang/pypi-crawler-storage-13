"""
Metadata-based parsing strategy for template PDFs.
"""

from pathlib import Path
from typing import Tuple, Optional, Dict
import logging

logger = logging.getLogger(__name__)


class MetadataParsingStrategy:
    """
    Parse assignments with embedded PDF metadata (template-based).

    Requirements:
    - 80%+ of submissions must have parseable metadata
    - PDFs created from the official template
    """

    REQUIRED_PARSEABLE_PERCENTAGE = 80.0

    def can_handle(self, analysis: Dict) -> bool:
        """Check if 80%+ submissions have metadata."""
        parseable_pct = analysis.get('parseable_percentage', 0)
        return parseable_pct >= self.REQUIRED_PARSEABLE_PERCENTAGE

    def parse(self, assignment_folder: str, **kwargs) -> Tuple[bool, Optional[str], str]:
        """
        Parse using PDF metadata extraction.

        Delegates to existing parser.
        """
        from modules.assignment.assignment_parser_pdf_v2 import parse_assignment_folder_with_pdf_metadata_v2

        force_parse = kwargs.get('force_parse', False)
        verbose = kwargs.get('verbose', True)

        return parse_assignment_folder_with_pdf_metadata_v2(
            assignment_folder=assignment_folder,
            force_parse=force_parse,
            verbose=verbose
        )

    def get_description(self) -> str:
        """Human-readable description."""
        return "Template-based parsing: Extract questions and answers from PDF metadata"
