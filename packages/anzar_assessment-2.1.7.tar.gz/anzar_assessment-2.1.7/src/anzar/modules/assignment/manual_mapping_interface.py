"""
Manual Mapping Interface - For handling unstructured submissions
"""
from typing import Dict, List, Optional
import json
from pathlib import Path

class ManualMappingInterface:
    """
    When automatic parsing fails, provide an interface for manual mapping
    """
    
    def __init__(self, submission_path: Path, questions: List[str]):
        self.submission_path = submission_path
        self.questions = questions
        self.mappings = {}
        
    def generate_web_interface(self) -> str:
        """Generate HTML interface for manual mapping"""
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Manual Answer Mapping - {self.submission_path.name}</title>
            <style>
                .container {{ 
                    display: flex; 
                    gap: 20px; 
                    height: 100vh; 
                    padding: 20px;
                }}
                .submission-panel {{
                    flex: 1;
                    overflow-y: auto;
                    border: 1px solid #ccc;
                    padding: 20px;
                }}
                .mapping-panel {{
                    flex: 1;
                    padding: 20px;
                }}
                .question-map {{
                    margin-bottom: 30px;
                    padding: 15px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                }}
                .selected-text {{
                    background-color: yellow;
                    cursor: pointer;
                }}
                .answer-preview {{
                    background: #f0f0f0;
                    padding: 10px;
                    margin-top: 10px;
                    border-radius: 3px;
                    max-height: 100px;
                    overflow-y: auto;
                }}
                .btn {{
                    padding: 10px 20px;
                    margin: 5px;
                    border: none;
                    border-radius: 3px;
                    cursor: pointer;
                }}
                .btn-primary {{ background: #007bff; color: white; }}
                .btn-success {{ background: #28a745; color: white; }}
            </style>
        </head>
        <body>
            <div class="container">
                <!-- Left panel: Submission content -->
                <div class="submission-panel">
                    <h2>Submission Content</h2>
                    <div id="submission-content">
                        <!-- Populated by JavaScript -->
                    </div>
                </div>
                
                <!-- Right panel: Question mapping -->
                <div class="mapping-panel">
                    <h2>Map Answers to Questions</h2>
                    <p>Select text from the left panel and click "Map to Question" for each question.</p>
                    
                    {self._generate_question_mapping_html()}
                    
                    <div style="margin-top: 30px;">
                        <button class="btn btn-success" onclick="saveMapping()">
                            Save Mapping
                        </button>
                        <button class="btn btn-primary" onclick="autoDetect()">
                            Try Auto-Detect
                        </button>
                    </div>
                </div>
            </div>
            
            <script>
                let currentSelection = null;
                let mappings = {{}};
                
                // Handle text selection
                document.addEventListener('mouseup', function() {{
                    const selection = window.getSelection();
                    if (selection.toString().trim().length > 0) {{
                        currentSelection = {{
                            text: selection.toString(),
                            range: selection.getRangeAt(0)
                        }};
                        highlightSelection();
                    }}
                }});
                
                function highlightSelection() {{
                    if (currentSelection && currentSelection.range) {{
                        const span = document.createElement('span');
                        span.className = 'selected-text';
                        span.textContent = currentSelection.text;
                        currentSelection.range.deleteContents();
                        currentSelection.range.insertNode(span);
                    }}
                }}
                
                function mapToQuestion(questionId) {{
                    if (!currentSelection) {{
                        alert('Please select text from the submission first');
                        return;
                    }}
                    
                    mappings[questionId] = currentSelection.text;
                    document.getElementById(`preview_${{questionId}}`).textContent = 
                        currentSelection.text.substring(0, 200) + '...';
                    document.getElementById(`status_${{questionId}}`).textContent = '✓ Mapped';
                    document.getElementById(`status_${{questionId}}`).style.color = 'green';
                }}
                
                function saveMapping() {{
                    // Send mappings to backend
                    fetch('/api/save_manual_mapping', {{
                        method: 'POST',
                        headers: {{'Content-Type': 'application/json'}},
                        body: JSON.stringify({{
                            submission: '{self.submission_path}',
                            mappings: mappings
                        }})
                    }}).then(response => {{
                        if (response.ok) {{
                            alert('Mapping saved successfully!');
                            window.close();
                        }}
                    }});
                }}
                
                function autoDetect() {{
                    // Try to auto-detect answers based on patterns
                    const content = document.getElementById('submission-content').textContent;
                    const questions = {json.dumps(self.questions)};
                    
                    questions.forEach((q, idx) => {{
                        // Simple heuristic: find text after question number
                        const patterns = [
                            new RegExp(`Question\\\\s*${{idx+1}}[\\\\s\\\\S]*?(?=Question\\\\s*${{idx+2}}|$)`, 'i'),
                            new RegExp(`Q${{idx+1}}[:.\\\\s]+([\\\\s\\\\S]*?)(?=Q${{idx+2}}|$)`, 'i'),
                            new RegExp(`${{idx+1}}\\\\)[\\\\s]+([\\\\s\\\\S]*?)(?=${{idx+2}}\\\\)|$)`, 'i')
                        ];
                        
                        for (let pattern of patterns) {{
                            const match = content.match(pattern);
                            if (match) {{
                                mappings[`Q${{idx+1}}`] = match[0];
                                document.getElementById(`preview_Q${{idx+1}}`).textContent = 
                                    match[0].substring(0, 200) + '...';
                                document.getElementById(`status_Q${{idx+1}}`).textContent = '✓ Auto-detected';
                                document.getElementById(`status_Q${{idx+1}}`).style.color = 'blue';
                                break;
                            }}
                        }}
                    }});
                }}
                
                // Load submission content
                window.onload = function() {{
                    fetch('/api/get_submission_content?path={self.submission_path}')
                        .then(response => response.text())
                        .then(content => {{
                            document.getElementById('submission-content').innerHTML = 
                                '<pre>' + content + '</pre>';
                        }});
                }};
            </script>
        </body>
        </html>
        """
        return html
    
    def _generate_question_mapping_html(self) -> str:
        """Generate HTML for question mapping interface"""
        html_parts = []
        
        for i, question in enumerate(self.questions, 1):
            html_parts.append(f"""
                <div class="question-map">
                    <h4>Question {i}</h4>
                    <p>{question[:100]}...</p>
                    <button class="btn btn-primary" onclick="mapToQuestion('Q{i}')">
                        Map Selected Text to This Question
                    </button>
                    <span id="status_Q{i}" style="margin-left: 10px; font-weight: bold;"></span>
                    <div class="answer-preview" id="preview_Q{i}">
                        <em>No answer mapped yet</em>
                    </div>
                </div>
            """)
        
        return '\n'.join(html_parts)