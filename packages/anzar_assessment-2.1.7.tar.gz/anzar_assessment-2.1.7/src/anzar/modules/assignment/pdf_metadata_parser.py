#!/usr/bin/env python3
"""
PDF metadata parser - extracts JSON metadata and embedded images from PDFs
"""

import json
import PyPDF2
import fitz  # PyMuPDF for image extraction
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import base64
import io
from PIL import Image
import logging

logger = logging.getLogger(__name__)

def extract_pdf_metadata(pdf_path: str, verbose: bool = False) -> Optional[Dict]:
    """
    Extract JSON metadata from PDF keywords field.
    
    Args:
        pdf_path: Path to PDF file
        verbose: Whether to print debug messages
        
    Returns:
        Dict containing parsed metadata or None if not found/invalid
    """
    try:
        if verbose:
            logger.debug(f" Opening PDF with PyPDF2: {pdf_path}")
            
        with open(pdf_path, 'rb') as file:
            pdf = PyPDF2.PdfReader(file)
            
            if verbose:
                logger.debug(f" PDF has metadata: {pdf.metadata is not None}")
                if pdf.metadata:
                    logger.debug(f" Metadata keys: {list(pdf.metadata.keys())}")
            
            if pdf.metadata and '/Keywords' in pdf.metadata:
                keywords = pdf.metadata['/Keywords']
                
                if verbose:
                    logger.debug(f" Keywords field found")
                    logger.debug(f" Keywords type: {type(keywords)}")
                    logger.debug(f" Keywords length: {len(str(keywords))}")
                    logger.debug(f" Keywords preview: {str(keywords)[:200]}...")
                
                try:
                    metadata = json.loads(keywords)
                    if verbose:
                        logger.debug(f" Successfully parsed JSON from keywords")
                        logger.debug(f" Metadata keys: {list(metadata.keys())}")
                        if 'questions' in metadata:
                            logger.debug(f" Number of questions: {len(metadata.get('questions', []))}")

                    # Validate metadata structure
                    is_valid, error_msg = validate_pdf_metadata(metadata, verbose)
                    if not is_valid:
                        if verbose:
                            logger.debug(f" Metadata validation failed: {error_msg}")
                        else:
                            logger.warning(f"Invalid PDF metadata in {pdf_path}: {error_msg}")
                        return None

                    return metadata
                except json.JSONDecodeError as e:
                    if verbose:
                        logger.debug(f" JSON decode error: {str(e)}")
                        logger.debug(f" Failed to parse: {keywords[:200]}...")
                    else:
                        print(f"Invalid JSON in PDF keywords: {keywords[:100]}...")
                    return None
            else:
                if verbose:
                    logger.debug(f" No /Keywords field in PDF metadata")
                    if pdf.metadata:
                        logger.debug(f" Available fields: {list(pdf.metadata.keys())}")
                return None
                
    except Exception as e:
        if verbose:
            logger.debug(f" Exception in extract_pdf_metadata: {type(e).__name__}: {str(e)}")
            import traceback
            traceback.print_exc()
        else:
            print(f"Error reading PDF metadata from {pdf_path}: {e}")
        return None


def validate_pdf_metadata(metadata: Dict, verbose: bool = False) -> Tuple[bool, str]:
    """
    Validate PDF metadata structure and required fields.

    Args:
        metadata: The metadata dict extracted from PDF
        verbose: Whether to print detailed validation messages

    Returns:
        Tuple of (is_valid: bool, error_message: str)
    """
    if not isinstance(metadata, dict):
        return False, "Metadata must be a dictionary"

    # Check for student field
    if 'student' not in metadata:
        return False, "Missing 'student' field in metadata"

    student = metadata['student']
    if not isinstance(student, dict):
        return False, "'student' must be a dictionary"

    # Validate student fields (at least id or name required)
    if 'id' not in student and 'name' not in student:
        return False, "Student must have at least 'id' or 'name'"

    # Check for questions field
    if 'questions' not in metadata:
        return False, "Missing 'questions' field in metadata"

    questions = metadata['questions']
    if not isinstance(questions, list):
        return False, "'questions' must be an array"

    if len(questions) == 0:
        return False, "'questions' array is empty"

    # Validate each question
    for i, question in enumerate(questions):
        if not isinstance(question, dict):
            return False, f"Question {i+1} must be a dictionary"

        # Required fields for each question
        if 'questionNumber' not in question:
            return False, f"Question {i+1} missing 'questionNumber'"

        if 'questionText' not in question:
            return False, f"Question {i+1} missing 'questionText'"

        # answerText is optional but should be checked if validation needs to be strict
        # For now, we'll allow questions without answers (e.g., template PDFs)

    if verbose:
        logger.info(f"Metadata validation passed: {len(questions)} questions found")

    return True, "Valid metadata structure"


def extract_images_from_pdf(pdf_path: str, output_dir: str) -> Dict[int, List[str]]:
    """
    Extract all images from a PDF and save them to disk.
    
    Args:
        pdf_path: Path to PDF file
        output_dir: Directory to save extracted images
        
    Returns:
        Dict mapping page numbers to list of extracted image paths
    """
    image_paths = {}
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    try:
        pdf_document = fitz.open(pdf_path)
        
        for page_num in range(pdf_document.page_count):
            page = pdf_document[page_num]
            image_list = page.get_images()
            
            if not image_list:
                continue
                
            page_images = []
            
            for img_index, img_info in enumerate(image_list):
                try:
                    # Get image xref
                    xref = img_info[0]
                    
                    # Extract image data
                    base_image = pdf_document.extract_image(xref)
                    image_data = base_image["image"]
                    
                    # Determine image extension
                    ext = base_image["ext"]
                    
                    # Save image
                    img_filename = f"page{page_num + 1}_img{img_index + 1}.{ext}"
                    img_path = output_path / img_filename
                    
                    with open(img_path, "wb") as img_file:
                        img_file.write(image_data)
                    
                    page_images.append(str(img_path))
                    
                except Exception as e:
                    print(f"Failed to extract image {img_index} from page {page_num + 1}: {e}")
                    continue
            
            if page_images:
                image_paths[page_num + 1] = page_images
        
        pdf_document.close()
        
    except Exception as e:
        print(f"Error extracting images from {pdf_path}: {e}")
    
    return image_paths

def map_images_to_questions(metadata: Dict, extracted_images: Dict[int, List[str]], 
                          base_output_dir: str) -> Dict[str, List[str]]:
    """
    Map extracted images to their corresponding questions based on metadata.
    
    Args:
        metadata: Parsed PDF metadata containing question info
        extracted_images: Dict mapping page numbers to image paths
        base_output_dir: Base directory for organizing images
        
    Returns:
        Dict mapping question IDs to their associated image paths
    """
    question_images = {}
    
    # Create organized directory structure
    organized_dir = Path(base_output_dir) / "extracted_images"
    organized_dir.mkdir(parents=True, exist_ok=True)
    
    questions = metadata.get('questions', [])
    
    for question in questions:
        q_num = question.get('questionNumber', '')
        attachments = question.get('attachments', [])
        
        if not attachments:
            continue
            
        question_img_paths = []
        
        for att_index, attachment in enumerate(attachments):
            if attachment.get('type') == 'image':
                # Try to find corresponding extracted image
                # This is a simplified approach - in practice, you might need
                # more sophisticated matching based on page position or metadata
                filename = attachment.get('filename', f'attachment_{att_index}')
                
                # Copy/rename image to organized structure
                new_path = organized_dir / f"q{q_num}_{filename}"
                
                # For now, we'll need to implement logic to match
                # extracted images with attachment metadata
                # This is a placeholder for the actual matching logic
                
                question_img_paths.append(str(new_path))
        
        if question_img_paths:
            question_images[f"q{q_num}"] = question_img_paths
    
    return question_images

def parse_pdf_submission(pdf_path: str, output_dir: str, verbose: bool = False) -> Optional[Dict]:
    """
    Parse a PDF submission extracting both metadata and images.
    
    Args:
        pdf_path: Path to PDF file
        output_dir: Directory to save extracted images
        verbose: Whether to print debug messages
        
    Returns:
        Dict containing parsed data with image references or None if parsing fails
    """
    if verbose:
        logger.debug(f" Starting parse_pdf_submission for: {pdf_path}")
        
    # Extract metadata
    metadata = extract_pdf_metadata(pdf_path, verbose=verbose)
    if verbose:
        logger.debug(f" Metadata extracted: {metadata is not None}")
        if metadata:
            logger.debug(f" Metadata keys: {list(metadata.keys())}")
            if 'questions' in metadata:
                logger.debug(f" Number of questions: {len(metadata['questions'])}")
        else:
            logger.debug(f" No metadata found in PDF")
    
    if not metadata:
        return None
    
    if verbose:
        logger.debug(f" Extracting images to: {output_dir}")
        
    # Extract images
    extracted_images = extract_images_from_pdf(pdf_path, output_dir)
    if verbose:
        logger.debug(f" Images extracted: {len(extracted_images)}")
    
    # Map images to questions
    question_images = map_images_to_questions(metadata, extracted_images, output_dir)
    if verbose:
        logger.debug(f" Question-image mapping complete")
        for q_id, imgs in question_images.items():
            print(f"         - {q_id}: {len(imgs)} images")
    
    # Enhance metadata with image paths
    result = {
        'metadata': metadata,
        'extracted_images': extracted_images,
        'question_images': question_images
    }
    
    if verbose:
        logger.debug(f" parse_pdf_submission completed successfully")
    
    return result

def extract_student_id_from_folder(folder_name: str) -> str:
    """
    Extract student ID from folder name.

    Args:
        folder_name: Folder name like 'user_12345_timestamp'

    Returns:
        Student ID as string (e.g., '12345')
    """
    try:
        # Format: user_{student_id}_{timestamp} or user_{student_id}
        parts = folder_name.split('_')
        if len(parts) >= 2:
            return parts[1]  # student_id is second part
        return folder_name  # Fallback to full name
    except Exception:
        return folder_name


def analyze_submission_folder(folder_path: str) -> Dict:
    """
    Analyze a folder of submissions to determine parsing compatibility.

    Args:
        folder_path: Path to assignment folder containing user submissions

    Returns:
        Dict with analysis results
    """
    analysis = {
        'total_submissions': 0,
        'submissions_with_files': 0,  # NEW: Count only students who actually submitted files
        'parseable_pdfs': 0,
        'legacy_pdfs': 0,
        'non_pdf_files': 0,
        'empty_submissions': 0,
        'submission_details': []
    }

    folder = Path(folder_path)

    # Find all user folders
    user_folders = [d for d in folder.iterdir() if d.is_dir() and d.name.startswith('user_')]
    analysis['total_submissions'] = len(user_folders)

    for user_folder in user_folders:
        # Extract student ID from folder name
        student_id = extract_student_id_from_folder(user_folder.name)

        user_info = {
            'user_folder': user_folder.name,
            'student_id': student_id,  # NEW: Add student ID
            'parseable_pdf': None,  # NEW: Will be set if parseable PDF found
            'files': [],
            'has_parseable_pdf': False,
            'pdf_count': 0,
            'other_files': []
        }
        
        # Check all files in user folder
        files = list(user_folder.iterdir())
        
        if not files:
            analysis['empty_submissions'] += 1
            user_info['files'] = []
        else:
            analysis['submissions_with_files'] += 1  # NEW: Count only actual submissions
            for file_path in files:
                if file_path.suffix.lower() == '.pdf':
                    user_info['pdf_count'] += 1

                    # Check if PDF has metadata
                    metadata = extract_pdf_metadata(str(file_path))
                    if metadata and metadata.get('questions'):
                        analysis['parseable_pdfs'] += 1
                        user_info['has_parseable_pdf'] = True
                        user_info['parseable_pdf'] = file_path.name  # NEW: Store the parseable PDF filename
                        user_info['files'].append({
                            'name': file_path.name,
                            'type': 'parseable_pdf',
                            'questions': len(metadata.get('questions', []))
                        })
                    else:
                        analysis['legacy_pdfs'] += 1
                        user_info['files'].append({
                            'name': file_path.name,
                            'type': 'legacy_pdf'
                        })
                else:
                    analysis['non_pdf_files'] += 1
                    user_info['other_files'].append(file_path.name)
                    user_info['files'].append({
                        'name': file_path.name,
                        'type': file_path.suffix
                    })
        
        analysis['submission_details'].append(user_info)
    
    # Calculate percentages based on actual submissions (not empty folders)
    submissions_with_files = analysis['submissions_with_files']
    if submissions_with_files > 0:
        analysis['parseable_percentage'] = (analysis['parseable_pdfs'] / submissions_with_files) * 100
        analysis['submission_rate'] = (submissions_with_files / analysis['total_submissions']) * 100 if analysis['total_submissions'] > 0 else 0
    else:
        analysis['parseable_percentage'] = 0
        analysis['submission_rate'] = 0
    
    return analysis

def display_analysis_summary(analysis: Dict) -> None:
    """
    Display a formatted summary of the submission analysis.
    
    Args:
        analysis: Analysis results from analyze_submission_folder
    """
    print("\n" + "="*60)
    logger.info("SUBMISSION ANALYSIS SUMMARY")
    print("="*60)
    print(f"Total submissions: {analysis['total_submissions']}")
    print(f"Students with files: {analysis['submissions_with_files']} ({analysis.get('submission_rate', 0):.1f}% submission rate)")
    print(f"Parseable PDFs (with metadata): {analysis['parseable_pdfs']} ({analysis['parseable_percentage']:.1f}% of actual submissions)")
    print(f"Legacy PDFs (no metadata): {analysis['legacy_pdfs']}")
    print(f"Non-PDF files: {analysis['non_pdf_files']}")
    print(f"Empty submissions: {analysis['empty_submissions']}")
    print("="*60)
    
    if analysis['parseable_percentage'] < 80:
        logger.info("\nWARNING: Less than 80% of submissions have parseable metadata.")
        logger.info("   Consider using template-based parsing or handling exceptions manually.")
    
    # Show details for problematic submissions
    if analysis['legacy_pdfs'] > 0 or analysis['non_pdf_files'] > 0:
        logger.info("\nSubmissions requiring attention:")
        for submission in analysis['submission_details']:
            if not submission['has_parseable_pdf']:
                print(f"\n  {submission['user_folder']}:")
                for file_info in submission['files']:
                    print(f"    - {file_info['name']} ({file_info['type']})")