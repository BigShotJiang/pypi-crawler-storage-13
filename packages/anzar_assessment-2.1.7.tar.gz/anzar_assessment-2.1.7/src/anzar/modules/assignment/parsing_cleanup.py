"""
Cleanup utilities for assignment parsing.
Removes artifacts from previous parsing attempts.
"""

import shutil
from pathlib import Path
from typing import List, Tuple, Dict
import logging

logger = logging.getLogger(__name__)


def cleanup_parsing_artifacts(assignment_folder: str) -> Tuple[bool, List[str]]:
    """
    Clean up artifacts from previous parsing attempts.
    
    Args:
        assignment_folder: Path to assignment folder
        
    Returns:
        Tuple of (success, list of cleaned items)
    """
    cleaned_items = []
    folder_path = Path(assignment_folder)
    
    try:
        # 1. Remove all extracted_images folders
        user_folders = [d for d in folder_path.iterdir() if d.is_dir() and d.name.startswith('user_')]
        
        for user_folder in user_folders:
            extracted_images = user_folder / "extracted_images"
            if extracted_images.exists() and extracted_images.is_dir():
                shutil.rmtree(extracted_images)
                cleaned_items.append(f"Removed {extracted_images}")
        
        # 2. Remove previous CSV if exists
        csv_path = folder_path / "parsed_submissions.csv"
        if csv_path.exists():
            csv_path.unlink()
            cleaned_items.append(f"Removed {csv_path.name}")

        # 3. Remove CSV backup files
        for backup in folder_path.glob("parsed_submissions.csv.bak*"):
            backup.unlink()
            cleaned_items.append(f"Removed {backup.name}")

        # 4. Remove checkpoint files (can have stale/wrong format data)
        checkpoint_path = folder_path / ".parse_checkpoint.json"
        if checkpoint_path.exists():
            checkpoint_path.unlink()
            cleaned_items.append(f"Removed {checkpoint_path.name}")
        
        # 4. Remove any temporary files
        temp_patterns = ["*.tmp", "~*", ".~*"]
        for pattern in temp_patterns:
            for temp_file in folder_path.glob(pattern):
                temp_file.unlink()
                cleaned_items.append(f"Removed {temp_file.name}")
        
        return True, cleaned_items
        
    except Exception as e:
        return False, [f"Error during cleanup: {str(e)}"]


def cleanup_user_folder(user_folder_path: str) -> List[str]:
    """
    Clean up a single user folder.
    
    Args:
        user_folder_path: Path to user folder
        
    Returns:
        List of cleaned items
    """
    cleaned_items = []
    user_path = Path(user_folder_path)
    
    # Remove extracted images
    extracted_images = user_path / "extracted_images"
    if extracted_images.exists() and extracted_images.is_dir():
        shutil.rmtree(extracted_images)
        cleaned_items.append(f"extracted_images/")
    
    # Remove any generated files (but keep original submissions)
    generated_patterns = ["*_parsed.json", "*_metadata.json", "*.tmp"]
    for pattern in generated_patterns:
        for gen_file in user_path.glob(pattern):
            gen_file.unlink()
            cleaned_items.append(gen_file.name)
    
    return cleaned_items


def prepare_for_parsing(assignment_folder: str, verbose: bool = True) -> bool:
    """
    Prepare assignment folder for a fresh parsing attempt.
    
    Args:
        assignment_folder: Path to assignment folder
        verbose: Whether to print cleanup details
        
    Returns:
        bool: True if successful
    """
    if verbose:
        logger.info("🧹 Cleaning up previous parsing artifacts...")
    
    success, cleaned_items = cleanup_parsing_artifacts(assignment_folder)
    
    if success and verbose:
        if cleaned_items:
            logger.info(f" Cleaned {len(cleaned_items)} items:")
            for item in cleaned_items[:5]:  # Show first 5
                print(f"   - {item}")
            if len(cleaned_items) > 5:
                print(f"   ... and {len(cleaned_items) - 5} more")
        else:
            logger.info("✅ No artifacts to clean")
    elif not success and verbose:
        logger.info("❌ Cleanup failed:")
        for error in cleaned_items:
            print(f"   - {error}")
    
    return success


def get_artifact_summary(assignment_folder: str) -> Dict:
    """
    Get summary of parsing artifacts in folder.
    
    Args:
        assignment_folder: Path to assignment folder
        
    Returns:
        Dict with artifact counts
    """
    folder_path = Path(assignment_folder)
    
    artifact_count = {
        'extracted_image_folders': 0,
        'csv_files': 0,
        'backup_files': 0,
        'temp_files': 0,
        'total': 0
    }
    
    # Count extracted_images folders
    user_folders = [d for d in folder_path.iterdir() if d.is_dir() and d.name.startswith('user_')]
    for user_folder in user_folders:
        if (user_folder / "extracted_images").exists():
            artifact_count['extracted_image_folders'] += 1
    
    # Count CSV files
    if (folder_path / "parsed_submissions.csv").exists():
        artifact_count['csv_files'] = 1
    
    # Count backup files
    artifact_count['backup_files'] = len(list(folder_path.glob("*.bak*")))
    
    # Count temp files
    temp_patterns = ["*.tmp", "~*", ".~*"]
    for pattern in temp_patterns:
        artifact_count['temp_files'] += len(list(folder_path.glob(pattern)))
    
    artifact_count['total'] = sum(artifact_count.values())
    
    return artifact_count