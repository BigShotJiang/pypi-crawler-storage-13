"""
Enhanced PDF parser with better error handling and debugging.
"""

import os
import logging
from pathlib import Path
import json
import traceback
from typing import Dict, List, Tuple, Optional
from ..utils import safe_write_csv
from .pdf_metadata_parser import parse_pdf_submission
from .parsing_cleanup import prepare_for_parsing

# Fallback functions for missing modules
def validate_all_submissions(*args, **kwargs):
    """Fallback for missing submission_validator module"""
    return {
        'valid_for_parsing': 1,  # Assume valid since we have parsable PDFs
        'valid_percentage': 100.0,
        'parseable_submissions': [],
        'total_submissions': 0,
        'message': 'Fallback validation - assuming valid submissions'
    }

def get_parseable_submissions(*args, **kwargs):
    """Fallback for missing submission_validator module"""
    return []

def display_validation_summary(*args, **kwargs):
    """Fallback for missing submission_validator module"""
    pass

def analyze_question_consistency(*args, **kwargs):
    """Fallback for missing question_consistency module"""
    return {}

def generate_parsing_summary(*args, **kwargs):
    """Fallback for missing question_consistency module"""
    return {}

from .parsing_summary import display_parsing_summary_cli, save_parsing_summary

# Setup logging
logger = logging.getLogger(__name__)

# Constants
CHECKPOINT_INTERVAL = 10  # Save checkpoint every N submissions


def parse_assignment_folder_with_pdf_metadata_v2(
    assignment_folder: str = None,
    course_id: int = None,
    assignment_id: int = None,
    force_parse: bool = False,
    verbose: bool = True
) -> Tuple[bool, Optional[str], str]:
    """
    Enhanced PDF parsing with validation and cleanup.
    """
    try:
        # Construct folder path if needed
        if course_id and assignment_id and not assignment_folder:
            from modules.utils import get_assignment_dir
            assignment_folder = str(get_assignment_dir(course_id, assignment_id))
        
        if not assignment_folder:
            return False, None, "No assignment folder specified"
        
        if not os.path.exists(assignment_folder):
            return False, None, f"Assignment folder not found: {assignment_folder}"
        
        if verbose:
            print(f"\n📂 Processing submissions in: {assignment_folder}")
        
        # Step 1: Clean up previous artifacts
        try:
            if not prepare_for_parsing(assignment_folder, verbose):
                return False, None, "Failed to clean up previous parsing artifacts"
        except Exception as e:
            return False, None, f"Error in cleanup: {str(e)}"
        
        # Step 2: Skip validation (we already detected parsable PDFs in download phase)
        # This step is redundant since we already checked for parsable PDFs
        # when determining auto-CSV creation eligibility
        if verbose:
            logger.info("\n🔍 Skipping validation step (parsable PDFs already detected)")

        # Continue directly to parsing since we know we have parsable PDFs
        
        # Step 3: Parse submissions with checkpoint support
        if verbose:
            print(f"\n📄 Starting to parse submissions...")

        # Load checkpoint if exists
        checkpoint_file = Path(assignment_folder) / ".parse_checkpoint.json"
        start_index = 0
        parsed_data = []
        failed_count = 0
        failed_submissions = []

        if checkpoint_file.exists() and not force_parse:
            try:
                with open(checkpoint_file, 'r', encoding='utf-8') as f:
                    checkpoint = json.load(f)
                    start_index = checkpoint.get('last_processed_index', 0) + 1
                    parsed_data = checkpoint.get('parsed_data', [])
                    failed_count = checkpoint.get('failed_count', 0)
                    failed_submissions = checkpoint.get('failed_submissions', [])
                    if verbose and start_index > 0:
                        print(f"📌 Resuming from checkpoint: skipping first {start_index} submissions")
            except Exception as e:
                if verbose:
                    logger.warning(f" Could not load checkpoint: {e}")

        # Since we skipped validation, get parseable submissions directly from analysis
        # We'll use the analysis data that was already calculated in the download phase
        try:
            from .pdf_metadata_parser import analyze_submission_folder
            analysis = analyze_submission_folder(assignment_folder)
            # Create a simple list of parseable submissions for processing
            parseable_submissions = []
            for detail in analysis.get('submission_details', []):
                if detail.get('has_parseable_pdf'):
                    parseable_submissions.append(detail)
        except Exception as e:
            if verbose:
                logger.warning(f"Could not analyze submission folder: {e}")
            parseable_submissions = []

        for sub_idx, submission in enumerate(parseable_submissions):
            # Skip if already processed (from checkpoint)
            if sub_idx < start_index:
                continue
            user_folder = submission['user_folder']
            user_path = Path(assignment_folder) / user_folder
            student_id = submission['student_id']
            pdf_file = submission['parseable_pdf']
            
            # Get student info from Canvas mapping (authoritative source)
            student_name = f"Student {student_id}"
            student_email = ""
            
            # Load Canvas student mapping if available
            canvas_mapping_file = Path(assignment_folder) / "canvas_student_mapping.json"
            if canvas_mapping_file.exists():
                try:
                    with open(canvas_mapping_file, 'r', encoding='utf-8') as f:
                        canvas_mapping = json.load(f)
                    
                    student_data = canvas_mapping.get(str(student_id), {})
                    if student_data:
                        student_name = student_data.get('name', student_name)
                        student_email = student_data.get('email', '')
                        if verbose:
                            print(f"  📋 Using Canvas data: {student_name} ({student_email})")
                except Exception as e:
                    if verbose:
                        print(f"  ⚠️  Could not read Canvas mapping: {e}")
            
            # Fallback to submission_info.txt if Canvas mapping not available
            if not student_email:
                info_file = user_path / "submission_info.txt"
                if info_file.exists():
                    try:
                        with open(info_file, 'r', encoding='utf-8') as f:
                            content = f.read()
                            for line in content.split('\n'):
                                if 'Name:' in line and student_name.startswith('Student'):
                                    student_name = line.split('Name:', 1)[1].strip()
                                elif 'Email:' in line:
                                    student_email = line.split('Email:', 1)[1].strip()
                    except Exception as e:
                        if verbose:
                            print(f"  ⚠️  Could not read student info: {e}")
            
            # Parse PDF
            pdf_path = user_path / pdf_file
            image_output_dir = user_path / "extracted_images"
            
            try:
                if verbose:
                    print(f"\n  📄 Starting to parse {student_name} - {pdf_file}")
                    print(f"     PDF path: {pdf_path}")
                    print(f"     Image output: {image_output_dir}")
                    
                parsed_submission = parse_pdf_submission(str(pdf_path), str(image_output_dir), verbose=verbose)
                
                if verbose:
                    print(f"     Parsing returned: {parsed_submission is not None}")
                    if parsed_submission:
                        print(f"     Has metadata: {'metadata' in parsed_submission}")
                        if 'metadata' in parsed_submission:
                            meta = parsed_submission['metadata']
                            print(f"     Questions found: {len(meta.get('questions', []))}")
                
                if parsed_submission and parsed_submission.get('metadata'):
                    # Convert to CSV rows
                    rows = convert_parsed_data_to_csv_rows(
                        parsed_submission,
                        student_id,
                        student_name,
                        assignment_id,
                        str(user_path),
                        student_email,
                        verbose=verbose
                    )
                    parsed_data.extend(rows)
                    
                    if verbose:
                        print(f"  ✅ Successfully parsed {student_name}: {len(rows)} questions")
                else:
                    failed_count += 1
                    if verbose:
                        print(f"  ❌ Failed to parse {student_name} - No valid metadata extracted")
                        if parsed_submission:
                            print(f"     Parsed data keys: {list(parsed_submission.keys())}")
            except Exception as e:
                failed_count += 1
                error_info = {
                    'student_id': student_id,
                    'student_name': student_name,
                    'pdf_file': pdf_file,
                    'error': str(e),
                    'error_type': type(e).__name__
                }
                failed_submissions.append(error_info)

                if verbose:
                    print(f"  ❌ Exception parsing {student_name}: {str(e)}")
                    print(f"     Exception type: {type(e).__name__}")
                    print(f"     ⚠️ Marked for manual review - continuing with next student...")

            # Save checkpoint every 5 submissions
            if sub_idx > 0 and sub_idx % 5 == 0:
                try:
                    with open(checkpoint_file, 'w', encoding='utf-8') as f:
                        json.dump({
                            'last_processed_index': sub_idx,
                            'parsed_data': parsed_data,
                            'failed_count': failed_count,
                            'failed_submissions': failed_submissions,
                            'timestamp': datetime.now().isoformat()
                        }, f, indent=2)
                    if verbose:
                        print(f"  💾 Checkpoint saved ({sub_idx + 1}/{len(parseable_submissions)} processed)")
                except Exception as e:
                    if verbose:
                        print(f"  ⚠️ Checkpoint save failed (non-critical): {e}")
        
        if not parsed_data:
            return False, None, f"No data could be parsed from submissions. {failed_count} submissions failed."
        
        # Step 4: Check question consistency
        if verbose:
            logger.info("\n🔍 Analyzing question consistency...")
        
        # Step 5: Write CSV
        csv_path = Path(assignment_folder) / "parsed_submissions.csv"
        headers = [
            'student_id', 'student_name', 'student_email', 'assignment_id',
            'part', 'question_id', 'question_text', 'question_description',
            'student_answer', 'has_attachments', 'attachment_paths',
            'points_earned', 'points_possible', 'grade', 'feedback', 'llm'
        ]

        # DEBUG: Check what's in parsed_data
        if verbose:
            print(f"\n[DEBUG] About to write CSV:")
            print(f"  Total rows: {len(parsed_data)}")
            print(f"  Type of parsed_data: {type(parsed_data)}")
            if parsed_data:
                print(f"  Type of first item: {type(parsed_data[0])}")
                print(f"  First item preview: {str(parsed_data[0])[:200]}")

        try:
            success, message = safe_write_csv(str(csv_path), parsed_data, headers)
            
            if not success:
                return False, None, f"Failed to write CSV: {message}"
        except Exception as e:
            return False, None, f"Error writing CSV: {str(e)}"
        
        # Step 6: Generate and display summary
        try:
            if verbose:
                logger.info("\n📊 Generating parsing summary...")
                
            # Create simple summary using fallback function
            summary = generate_parsing_summary(parsed_data, {})  # Use empty dict as fallback
            
            if verbose:
                display_parsing_summary_cli(summary)
            
            # Save summary for later reference
            save_parsing_summary(assignment_folder, summary)

            # Save failed submissions report
            if failed_submissions:
                failed_report_file = Path(assignment_folder) / "failed_submissions.json"
                with open(failed_report_file, 'w', encoding='utf-8') as f:
                    json.dump({
                        'failed_count': failed_count,
                        'failed_submissions': failed_submissions,
                        'timestamp': datetime.now().isoformat()
                    }, f, indent=2)
                if verbose:
                    print(f"\n⚠️ {failed_count} submissions failed - details saved to failed_submissions.json")

            # Delete checkpoint on successful completion
            if checkpoint_file.exists():
                try:
                    checkpoint_file.unlink()
                    if verbose:
                        logger.info("✅ Parsing checkpoint cleared")
                except:
                    pass
            
            # Step 7: Collect points for questions
            if summary.get('questions'):
                from .parsing_points_collector import load_points_map, save_points_map, apply_points_to_csv, collect_points_for_questions
                
                # Check if points already assigned
                existing_points = load_points_map(assignment_folder)
                
                if existing_points and not force_parse:
                    points_map = existing_points
                    if verbose:
                        logger.info("\n📊 Using existing points assignment")
                else:
                    # Points should already be collected via GUI
                    # If not, use defaults
                    points_map = {q['id']: 10 for q in summary['questions']}
                    save_points_map(assignment_folder, points_map)
                    if verbose:
                        logger.info("\n📊 Using default points (10 per question) - should be set via GUI")
                
                # Apply points to CSV data and rewrite
                parsed_data = apply_points_to_csv(parsed_data, points_map)
                success, message = safe_write_csv(str(csv_path), parsed_data, headers)
                if not success and verbose:
                    logger.warning(f"  Warning: Could not update CSV with points: {message}")
                    
        except Exception as e:
            # Don't fail the whole process if summary fails
            if verbose:
                logger.warning(f"  Warning: Could not generate summary: {str(e)}")
        
        success_msg = f"Successfully parsed {len(parsed_data)} submissions"
        if failed_count > 0:
            success_msg += f" ({failed_count} failed)"
            
        return True, str(csv_path), success_msg
        
    except Exception as e:
        return False, None, f"Error parsing assignment folder: {str(e)}\n{traceback.format_exc()}"


def convert_parsed_data_to_csv_rows(
    parsed_submission: Dict,
    student_id: str,
    student_name: str,
    assignment_id: int,
    user_folder_path: str,
    student_email: str = "",
    verbose: bool = False
) -> List[Dict]:
    """
    Convert parsed PDF data to CSV rows.
    """
    rows = []
    
    if verbose:
        print(f"       [DEBUG] Converting parsed data to CSV rows")
        print(f"       [DEBUG] Student: {student_name} ({student_id})")
    
    try:
        metadata = parsed_submission.get('metadata', {})
        question_images = parsed_submission.get('question_images', {})
        
        # Keep Canvas student info as authoritative (don't override with PDF data)
        # PDF metadata might have different name format or be incorrect
        if verbose:
            pdf_student_info = metadata.get('student', {})
            if pdf_student_info.get('name'):
                print(f"       [DEBUG] PDF contains student name: {pdf_student_info['name']} (using Canvas: {student_name})")
        
        # Only use PDF email if Canvas email is empty
        if not student_email:
            student_info = metadata.get('student', {})
            student_email = student_info.get('email', '')
        
        # Process each question
        questions = metadata.get('questions', [])
        if verbose:
            print(f"       [DEBUG] Processing {len(questions)} questions")
            
        for i, question in enumerate(questions):
            q_num = str(question.get('questionNumber', ''))
            q_id = f"q{q_num}"
            
            if verbose:
                print(f"       [DEBUG] Question {i+1}: {q_id}")
                print(f"         - Keys: {list(question.keys())}")
            
            # Get image paths for this question
            image_paths = question_images.get(q_id, [])
            
            # Check if question has attachments in metadata
            has_attachments = len(question.get('attachments', [])) > 0
            
            # Make paths relative to assignment folder for portability
            attachment_paths_json = json.dumps([])
            if image_paths:
                base_path = Path(user_folder_path).parent
                relative_paths = []
                for img_path in image_paths:
                    try:
                        rel_path = Path(img_path).relative_to(base_path)
                        relative_paths.append(str(rel_path))
                    except:
                        relative_paths.append(img_path)
                attachment_paths_json = json.dumps(relative_paths)
            
            row = {
                'student_id': student_id,
                'student_name': student_name,
                'student_email': student_email,
                'assignment_id': str(assignment_id) if assignment_id else '',
                'part': question.get('part', ''),
                'question_id': q_id,
                'question_text': question.get('questionText', ''),
                'question_description': question.get('questionDescription', ''),
                'student_answer': question.get('answerText', question.get('answerPreview', '')),
                'has_attachments': 'Yes' if has_attachments else 'No',
                'attachment_paths': attachment_paths_json,
                'points_earned': 0,  # Initialize with 0 for numeric calculations
                'points_possible': 1,  # Default to 1 point, teacher can adjust
                'grade': '',
                'feedback': '',
                'llm': ''
            }
            
            rows.append(row)
    
    except Exception as e:
        print(f"Error converting parsed data: {str(e)}")
        raise
    
    return rows