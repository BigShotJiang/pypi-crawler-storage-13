"""
Points collector for parsed questions.
Collects maximum points for each question during parsing.
"""

from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)
import json
from pathlib import Path


def collect_points_for_questions(questions: List[Dict], default_points: int = 10) -> Dict[str, int]:
    """
    Collect points for each unique question interactively.
    
    Args:
        questions: List of unique questions from parsing
        default_points: Default points per question
        
    Returns:
        Dict mapping question_id to max points
    """
    points_map = {}
    
    print("\n" + "="*60)
    logger.info("📊 ASSIGN POINTS TO QUESTIONS")
    print("="*60)
    print(f"Please assign maximum points for each question.")
    print(f"Press Enter to use default ({default_points} points)\n")
    
    for i, question in enumerate(questions, 1):
        q_id = question['id']
        q_text = question['text'][:100] + "..." if len(question['text']) > 100 else question['text']
        
        print(f"\nQuestion {i}/{len(questions)}")
        print(f"ID: {q_id}")
        print(f"Text: {q_text}")
        
        while True:
            try:
                points_input = input(f"Max points (default {default_points}): ").strip()
                if not points_input:
                    points = default_points
                else:
                    points = int(points_input)
                    if points <= 0:
                        logger.info("❌ Points must be greater than 0")
                        continue
                    if points > 100:
                        confirm = input(f"⚠️  {points} points seems high. Confirm? (y/n): ").lower()
                        if confirm != 'y':
                            continue
                
                points_map[q_id] = points
                logger.info(f" Set to {points} points")
                break
                
            except ValueError:
                logger.info("❌ Please enter a valid number")
            except KeyboardInterrupt:
                logger.info("\n\nCancelled. Using default points for remaining questions.")
                # Fill remaining with default
                for j in range(i-1, len(questions)):
                    if questions[j]['id'] not in points_map:
                        points_map[questions[j]['id']] = default_points
                return points_map
    
    # Summary
    total_points = sum(points_map.values())
    print("\n" + "="*60)
    logger.info(f" POINTS ASSIGNED")
    print(f"Total points: {total_points}")
    print("="*60)
    
    return points_map


def save_points_map(assignment_folder: str, points_map: Dict[str, int]) -> str:
    """
    Save points mapping to JSON file.
    
    Args:
        assignment_folder: Path to assignment folder
        points_map: Dict mapping question_id to max points
        
    Returns:
        Path to saved file
    """
    points_file = Path(assignment_folder) / "question_points.json"
    
    with open(points_file, 'w', encoding='utf-8') as f:
        json.dump({
            "points_map": points_map,
            "total_points": sum(points_map.values())
        }, f, indent=2)
    
    return str(points_file)


def load_points_map(assignment_folder: str) -> Optional[Dict[str, int]]:
    """
    Load points mapping from JSON file.
    
    Args:
        assignment_folder: Path to assignment folder
        
    Returns:
        Points map or None if not found
    """
    points_file = Path(assignment_folder) / "question_points.json"
    
    if points_file.exists():
        with open(points_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get("points_map", {})
    
    return None


def apply_points_to_csv(csv_rows: List[Dict], points_map: Dict[str, int]) -> List[Dict]:
    """
    Apply points to CSV rows.
    
    Args:
        csv_rows: List of CSV row dictionaries
        points_map: Dict mapping question_id to max points
        
    Returns:
        Updated CSV rows with points_possible filled
    """
    for row in csv_rows:
        q_id = row.get('question_id', '')
        if q_id in points_map:
            row['points_possible'] = str(points_map[q_id])
        else:
            # Default if not found
            row['points_possible'] = '10'
    
    return csv_rows


def collect_points_gui_format(questions: List[Dict]) -> List[Dict]:
    """
    Format questions for GUI points collection.
    
    Args:
        questions: List of unique questions
        
    Returns:
        List of question dicts formatted for GUI
    """
    formatted = []
    
    for q in questions:
        formatted.append({
            "id": q['id'],
            "text": q['text'],
            "answer_count": q.get('answer_count', 0),
            "suggested_points": 10  # Default suggestion
        })
    
    return formatted