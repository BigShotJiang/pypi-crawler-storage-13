import os
import logging
from ..profile.profile_setter import read_canvas_config
from pathlib import Path
import requests
import shutil
import datetime
import json
from canvasapi import Canvas
from canvasapi.exceptions import CanvasException
from ..utils import get_canvas_instance
from ..utils import get_assignment_dir
from .pdf_metadata_parser import analyze_submission_folder, display_analysis_summary

# Setup logging
logger = logging.getLogger(__name__)

# Configuration constants
PROGRESS_LOG_INTERVAL = 5           # Log progress every N submissions
REQUEST_TIMEOUT_SECONDS = 60        # Timeout for file downloads
MAX_RETRY_ATTEMPTS = 3              # Max retries for failed downloads


def list_assignments(course_id):
    """
    List all assignments for a given course ID.
    
    Args:
        course_id (int): Canvas course ID
    
    Returns:
        list: List of assignment dictionaries with basic info, or empty list if failed
    """
    try:
        canvas = get_canvas_instance()

        logger.info(f"Retrieving assignments for course {course_id}")
        course = canvas.get_course(course_id)
        assignments = list(course.get_assignments())

        # Extract basic assignment information
        assignment_list = []
        for assignment in assignments:
            assignment_info = {
                'id': assignment.id,
                'name': assignment.name,
                'due_at': getattr(assignment, 'due_at', 'No due date'),
                'published': getattr(assignment, 'published', False),
                'submission_types': getattr(assignment, 'submission_types', [])
            }
            assignment_list.append(assignment_info)

        logger.info(f"Successfully retrieved {len(assignment_list)} assignments")
        return assignment_list

    except CanvasException as e:
        logger.error(f"Canvas API error retrieving assignments: {e}")
        return []

    except Exception as e:
        logger.error(f"Unexpected error retrieving assignments: {e}", exc_info=True)
        return []


def _show_detailed_submission_list(analysis):
    """
    Show detailed list of submissions and their parsability status.

    DEPRECATED: Uses print() for CLI display. GUI uses analysis data directly.
    """
    logger.debug("Displaying detailed submission list")
    print("\n📋 Detailed Submission Status:")
    print("-" * 80)
    
    for submission in analysis['submission_details']:
        user_folder = submission['user_folder']
        
        # Extract student ID
        student_id = user_folder.replace('user_', '')
        
        # Determine status icon and message
        if submission['has_parseable_pdf']:
            status = "✅ Parseable PDF"
            pdf_count = sum(1 for f in submission['files'] if f['type'] == 'parseable_pdf')
            status += f" ({pdf_count} PDF{'s' if pdf_count > 1 else ''})"
        elif submission.get('pdf_count', 0) > 0:
            status = "⚠️  Legacy PDF (no metadata)"
        elif submission['files']:
            status = "❌ Non-PDF files only"
        else:
            status = "❌ No submission"
        
        print(f"\n{user_folder}:")
        print(f"  Status: {status}")
        
        if submission['files']:
            print("  Files:")
            for file_info in submission['files']:
                file_status = ""
                if file_info['type'] == 'parseable_pdf':
                    file_status = f" [Parseable - {file_info.get('questions', 0)} questions]"
                elif file_info['type'] == 'legacy_pdf':
                    file_status = " [Legacy PDF]"
                print(f"    - {file_info['name']}{file_status}")
        
        if submission.get('other_files'):
            print("  Other files:", ", ".join(submission['other_files']))
    
    print("-" * 80)