"""
Course operations for Canvas LMS.
Copied from modules/course/courses.py - already simple and well-designed.
"""

import logging
from canvasapi import Canvas
from canvasapi.exceptions import CanvasException, InvalidAccessToken
import requests.exceptions
from ..profile.profile_setter import read_canvas_config

logger = logging.getLogger(__name__)


def get_courses():
    """
    Retrieve all active courses for the current Canvas user.

    Returns:
        list: List of course dictionaries with id, name, course_code, workflow_state
              Empty list on error
    """
    try:
        # Read Canvas credentials
        canvas_address, token = read_canvas_config()

        if not canvas_address or not token:
            logger.error("Cannot get courses: No Canvas credentials configured")
            return []

        # Ensure HTTPS
        if not canvas_address.startswith('https://'):
            canvas_address = canvas_address.replace('http://', 'https://')
            if not canvas_address.startswith('https://'):
                canvas_address = f'https://{canvas_address}'

        logger.info(f"Connecting to Canvas: {canvas_address}")

        # Initialize Canvas API
        canvas = Canvas(canvas_address, token)

        # Get current user
        user = canvas.get_current_user()
        logger.info(f"Connected as: {user.name}")

        # Get all courses (with pagination)
        courses_list = []
        courses = user.get_courses()

        for i, course in enumerate(courses):
            # Log progress for large course lists
            if (i + 1) % 50 == 0:
                logger.info(f"Retrieved {i + 1} courses...")

            course_dict = {
                'id': course.id,
                'name': course.name,
                'course_code': getattr(course, 'course_code', ''),
                'workflow_state': getattr(course, 'workflow_state', 'available')
            }
            courses_list.append(course_dict)

        logger.info(f"Retrieved {len(courses_list)} total courses")
        return courses_list

    except InvalidAccessToken:
        logger.error("Invalid Canvas access token. Please check your credentials.")
        return []
    except requests.exceptions.ConnectionError:
        logger.error("Cannot connect to Canvas. Check your internet connection and Canvas URL.")
        return []
    except CanvasException as e:
        logger.error(f"Canvas API error: {e}")
        return []
    except Exception as e:
        logger.error(f"Unexpected error getting courses: {e}")
        return []
