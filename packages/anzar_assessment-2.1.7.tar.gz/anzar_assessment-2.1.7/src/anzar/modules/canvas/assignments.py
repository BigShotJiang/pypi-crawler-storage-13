"""
Assignment operations for Canvas LMS - simplified.
Reduced from 376 lines to ~120 lines by removing complex progress tracking.
"""

import logging
import os
import requests
from pathlib import Path
from canvasapi.exceptions import CanvasException
from ..utils import get_canvas_instance, get_assignment_dir, ensure_directory_exists, safe_write_json

logger = logging.getLogger(__name__)


def list_assignments(course_id):
    """
    List all assignments for a given course.

    Args:
        course_id: Canvas course ID

    Returns:
        List of assignment dicts with id, name, due_at, points_possible, etc.
    """
    try:
        canvas = get_canvas_instance()
        course = canvas.get_course(course_id)

        logger.info(f"Retrieving assignments for course {course_id}")

        assignment_list = []
        for assignment in course.get_assignments():
            assignment_list.append({
                'id': assignment.id,
                'name': assignment.name,
                'due_at': getattr(assignment, 'due_at', None),
                'points_possible': getattr(assignment, 'points_possible', 0),
                'submission_types': getattr(assignment, 'submission_types', []),
                'published': getattr(assignment, 'published', False)
            })

        logger.info(f"Retrieved {len(assignment_list)} assignments")
        return assignment_list

    except CanvasException as e:
        logger.error(f"Canvas API error: {e}")
        return []
    except Exception as e:
        logger.error(f"Error retrieving assignments: {e}")
        return []


def download_assignment_submissions(course_id, assignment_id, force_download=False):
    """
    Download assignment submissions to folder structure.
    Simplified - removed progress callbacks, analysis, detailed tracking.

    Args:
        course_id: Canvas course ID
        assignment_id: Canvas assignment ID
        force_download: If True, re-download even if folder exists

    Returns:
        dict: {
            'success': bool,
            'folder_path': str,
            'student_count': int,
            'students': List[dict]
        }
    """
    try:
        canvas = get_canvas_instance()
        course = canvas.get_course(course_id)
        assignment = course.get_assignment(assignment_id)

        logger.info(f"Downloading submissions for: {assignment.name}")

        # Create folder: data/course_{id}/assignment_{id}/
        folder_path = get_assignment_dir(course_id, assignment_id)
        folder = Path(folder_path)

        # Check if already exists
        if folder.exists() and not force_download:
            logger.info(f"Folder already exists: {folder_path}")
            # Load existing student mapping
            mapping_file = folder / 'canvas_student_mapping.json'
            if mapping_file.exists():
                import json
                with open(mapping_file, 'r') as f:
                    mapping = json.load(f)
                    students = list(mapping.values())
                    return {
                        'success': True,
                        'folder_path': folder_path,
                        'student_count': len(students),
                        'students': students
                    }

        # Create/recreate folder
        ensure_directory_exists(folder_path)

        # Get submissions with user info
        submissions = list(assignment.get_submissions(include=['user', 'attachments']))

        logger.info(f"Found {len(submissions)} submissions")

        # Download each submission
        students = []
        student_mapping = {}

        for i, submission in enumerate(submissions, 1):
            # Get student info
            try:
                if hasattr(submission, 'user') and submission.user:
                    user = submission.user
                    student_id = str(submission.user_id)
                    student_name = getattr(user, 'name', f"User {student_id}")
                    student_email = getattr(user, 'email', '') or getattr(user, 'login_id', '')
                else:
                    student_id = str(submission.user_id)
                    student_name = f"User {student_id}"
                    student_email = ""
            except:
                student_id = str(submission.user_id)
                student_name = f"User {student_id}"
                student_email = ""

            # Create student folder: user_{student_id}_{canvas_id}/
            student_folder = folder / f"user_{student_id}_{submission.user_id}"
            student_folder.mkdir(exist_ok=True)

            # Save student info
            student_info = {
                'id': student_id,
                'name': student_name,
                'email': student_email,
                'folder': str(student_folder)
            }
            students.append(student_info)
            student_mapping[student_id] = student_info

            # Download attachments if any
            if hasattr(submission, 'attachments') and submission.attachments:
                for attachment in submission.attachments:
                    file_name = "unknown"
                    try:
                        # Attachment is a Canvas File object, not dict
                        file_url = getattr(attachment, 'url', None)
                        file_name = getattr(attachment, 'filename', f'file_{getattr(attachment, "id", "unknown")}')

                        if not file_url:
                            continue

                        # Download file
                        response = requests.get(file_url, timeout=30)
                        if response.status_code == 200:
                            file_path = student_folder / file_name
                            with open(file_path, 'wb') as f:
                                f.write(response.content)
                            logger.debug(f"Downloaded: {file_name}")
                    except Exception as e:
                        logger.warning(f"Failed to download {file_name}: {e}")

            # Log progress
            if i % 10 == 0 or i == len(submissions):
                logger.info(f"Downloaded {i}/{len(submissions)} submissions")

        # Save student mapping JSON
        mapping_file = folder / 'canvas_student_mapping.json'
        safe_write_json(str(mapping_file), student_mapping)

        logger.info(f"Downloaded {len(students)} submissions to {folder_path}")

        return {
            'success': True,
            'folder_path': folder_path,
            'student_count': len(students),
            'students': students
        }

    except Exception as e:
        logger.error(f"Error downloading submissions: {e}", exc_info=True)
        return {
            'success': False,
            'folder_path': None,
            'student_count': 0,
            'students': [],
            'error': str(e)
        }


def download_assignment_submissions_with_progress(course_id, assignment_id, force_download=False, progress_callback=None):
    """
    Download assignment submissions with real-time progress tracking.
    Enhanced version with progress callbacks and analysis support.

    Args:
        course_id: Canvas course ID
        assignment_id: Canvas assignment ID
        force_download: If True, re-download even if folder exists
        progress_callback: Optional callback for progress updates

    Returns:
        dict: {
            'success': bool,
            'folder_path': str,
            'student_count': int,
            'students': List[dict],
            'analysis': dict,  # Submission analysis results
            'error': str if failed
        }
    """
    try:
        # Progress: Starting
        if progress_callback:
            progress_callback({
                'phase': 'fetch_data',
                'done': 0,
                'total': 5,
                'percent': 5,
                'current_item': 'Canvas connection',
                'status': 'Connecting to Canvas...',
                'details': f'Course {course_id}, Assignment {assignment_id}'
            })

        canvas = get_canvas_instance()
        course = canvas.get_course(course_id)
        assignment = course.get_assignment(assignment_id)

        logger.info(f"Downloading submissions for: {assignment.name}")

        # Progress: Connected
        if progress_callback:
            progress_callback({
                'phase': 'fetch_data',
                'done': 1,
                'total': 5,
                'percent': 15,
                'current_item': 'Fetching submissions',
                'status': 'Getting submission list from Canvas...',
                'details': 'Retrieving student submissions...'
            })

        # Create folder: data/course_{id}/assignment_{id}/
        folder_path = get_assignment_dir(course_id, assignment_id)
        folder = Path(folder_path)

        # Check if already exists
        if folder.exists() and not force_download:
            logger.info(f"Folder already exists: {folder_path}")

            # Progress: Loading existing
            if progress_callback:
                progress_callback({
                    'phase': 'fetch_data',
                    'done': 2,
                    'total': 5,
                    'percent': 30,
                    'current_item': 'Loading existing data',
                    'status': 'Loading previously downloaded submissions...',
                    'details': 'Scanning existing folder...'
                })

            # Load existing student mapping
            mapping_file = folder / 'canvas_student_mapping.json'
            if mapping_file.exists():
                import json
                with open(mapping_file, 'r') as f:
                    mapping = json.load(f)
                    students = list(mapping.values())

                    # Progress: Analysis
                    if progress_callback:
                        progress_callback({
                            'phase': 'fetch_data',
                            'done': 4,
                            'total': 5,
                            'percent': 80,
                            'current_item': 'Analyzing submissions',
                            'status': 'Analyzing downloaded files...',
                            'details': 'Checking for parseable PDFs and other content...'
                        })

                    # Get analysis
                    analysis = None
                    try:
                        from modules.assignment.pdf_metadata_parser import analyze_submission_folder
                        analysis = analyze_submission_folder(str(folder_path))
                    except Exception as e:
                        logger.warning(f"Analysis failed: {e}")
                        analysis = {'error': str(e)}

                    # Progress: Complete
                    if progress_callback:
                        progress_callback({
                            'phase': 'fetch_data',
                            'done': 5,
                            'total': 5,
                            'percent': 100,
                            'current_item': 'Complete',
                            'status': 'Download complete!',
                            'details': f'{len(students)} submissions ready'
                        })

                    return {
                        'success': True,
                        'folder_path': folder_path,
                        'student_count': len(students),
                        'students': students,
                        'analysis': analysis
                    }

        # Create/recreate folder
        ensure_directory_exists(folder_path)

        # Progress: Fetching submissions
        if progress_callback:
            progress_callback({
                'phase': 'fetch_data',
                'done': 2,
                'total': 5,
                'percent': 30,
                'current_item': 'Fetching submissions',
                'status': 'Retrieving submission details...',
                'details': 'Getting student information and attachments...'
            })

        # Get submissions with user info
        submissions = list(assignment.get_submissions(include=['user', 'attachments']))
        total_submissions = len(submissions)
        logger.info(f"Found {total_submissions} submissions")

        # Download each submission
        students = []
        student_mapping = {}

        for i, submission in enumerate(submissions, 1):
            # Progress: Downloading files
            progress_percent = 30 + (50 * i / total_submissions)  # 30% to 80%
            if progress_callback:
                progress_callback({
                    'phase': 'fetch_data',
                    'done': i,
                    'total': total_submissions + 1,  # +1 for analysis step
                    'percent': int(progress_percent),
                    'current_item': f'Downloading ({i}/{total_submissions})',
                    'status': f'Downloading submission {i} of {total_submissions}...',
                    'details': f'Processing: {getattr(submission.user, "name", "Unknown") if hasattr(submission, "user") and submission.user else f"User {submission.user_id}"}'
                })

            # Get student info
            try:
                if hasattr(submission, 'user') and submission.user:
                    user = submission.user
                    student_id = str(submission.user_id)
                    student_name = getattr(user, 'name', f"User {student_id}")
                    student_email = getattr(user, 'email', '') or getattr(user, 'login_id', '')
                else:
                    student_id = str(submission.user_id)
                    student_name = f"User {student_id}"
                    student_email = ""
            except:
                student_id = str(submission.user_id)
                student_name = f"User {student_id}"
                student_email = ""

            # Create student folder: user_{student_id}_{canvas_id}/
            student_folder = folder / f"user_{student_id}_{submission.user_id}"
            student_folder.mkdir(exist_ok=True)

            # Save student info
            student_info = {
                'id': student_id,
                'name': student_name,
                'email': student_email,
                'folder': str(student_folder)
            }
            students.append(student_info)
            student_mapping[student_id] = student_info

            # Download attachments if any
            if hasattr(submission, 'attachments') and submission.attachments:
                for attachment in submission.attachments:
                    file_name = "unknown"
                    try:
                        # Attachment is a Canvas File object, not dict
                        file_url = getattr(attachment, 'url', None)
                        file_name = getattr(attachment, 'filename', f'file_{getattr(attachment, "id", "unknown")}')

                        if not file_url:
                            continue

                        # Download file
                        response = requests.get(file_url, timeout=30)
                        if response.status_code == 200:
                            file_path = student_folder / file_name
                            with open(file_path, 'wb') as f:
                                f.write(response.content)
                            logger.debug(f"Downloaded: {file_name}")
                    except Exception as e:
                        logger.warning(f"Failed to download {file_name}: {e}")

        # Save student mapping JSON
        mapping_file = folder / 'canvas_student_mapping.json'
        safe_write_json(str(mapping_file), student_mapping)

        # Progress: Analysis
        if progress_callback:
            progress_callback({
                'phase': 'fetch_data',
                'done': total_submissions,
                'total': total_submissions + 1,
                'percent': 90,
                'current_item': 'Analyzing submissions',
                'status': 'Analyzing downloaded files...',
                'details': 'Checking for parseable PDFs and other content...'
            })

        # Get analysis
        analysis = None
        try:
            from modules.assignment.pdf_metadata_parser import analyze_submission_folder
            analysis = analyze_submission_folder(str(folder_path))
        except Exception as e:
            logger.warning(f"Analysis failed: {e}")
            analysis = {'error': str(e)}

        # Progress: Complete
        if progress_callback:
            progress_callback({
                'phase': 'fetch_data',
                'done': total_submissions + 1,
                'total': total_submissions + 1,
                'percent': 100,
                'current_item': 'Complete',
                'status': 'Download complete!',
                'details': f'{len(students)} submissions ready'
            })

        logger.info(f"Downloaded {len(students)} submissions to {folder_path}")

        return {
            'success': True,
            'folder_path': folder_path,
            'student_count': len(students),
            'students': students,
            'analysis': analysis
        }

    except Exception as e:
        logger.error(f"Error downloading submissions: {e}", exc_info=True)
        return {
            'success': False,
            'folder_path': None,
            'student_count': 0,
            'students': [],
            'analysis': None,
            'error': str(e)
        }
