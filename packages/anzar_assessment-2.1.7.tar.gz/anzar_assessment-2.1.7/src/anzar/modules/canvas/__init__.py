"""
Canvas module - unified Canvas LMS operations.
Consolidates course, quiz, and assignment operations.
"""

from .courses import get_courses
from .quizzes import list_quizzes, download_quiz_submissions
from .assignments import list_assignments, download_assignment_submissions, download_assignment_submissions_with_progress

__all__ = [
    'get_courses',
    'list_quizzes',
    'download_quiz_submissions',
    'list_assignments',
    'download_assignment_submissions',
    'download_assignment_submissions_with_progress',
]
