"""
Quiz operations for Canvas LMS.
Uses Canvas Quiz Reports API to reliably get student answers.
"""

import logging
import time
import requests
import csv
import io
from canvasapi.exceptions import CanvasException
from ..utils import get_canvas_instance, write_csv, get_quiz_csv_path
from ..profile.profile_setter import get_active_canvas_credentials

logger = logging.getLogger(__name__)

# Constants for quiz report polling
REPORT_POLL_MAX_ATTEMPTS = 60  # 2 minutes max wait
REPORT_POLL_INTERVAL_SECONDS = 2
MAX_REASONABLE_QUIZ_POINTS = 1000


def list_quizzes(course_id):
    """
    List all quizzes for a given course.

    Args:
        course_id: Canvas course ID

    Returns:
        List of quiz dicts with id, title, quiz_type, published
    """
    logger.info(f"🔍 [MODULE] list_quizzes() called with course_id={course_id}")

    try:
        logger.debug(f"[MODULE] Getting Canvas instance...")
        canvas = get_canvas_instance()

        logger.debug(f"[MODULE] Getting course object for course {course_id}...")
        course = canvas.get_course(course_id)

        logger.info(f"[MODULE] Retrieving quizzes from Canvas API...")

        quiz_list = []
        for quiz in course.get_quizzes():
            quiz_list.append({
                'id': quiz.id,
                'title': quiz.title,
                'quiz_type': getattr(quiz, 'quiz_type', 'quiz'),
                'published': getattr(quiz, 'published', False)
            })
            logger.debug(f"[MODULE] Found quiz: {quiz.title} (ID: {quiz.id})")

        logger.info(f"✅ [MODULE] Successfully retrieved {len(quiz_list)} quizzes")
        return quiz_list

    except CanvasException as e:
        logger.error(f"❌ [MODULE] Canvas API error: {e}")
        return []
    except Exception as e:
        logger.error(f"❌ [MODULE] Error retrieving quizzes: {e}", exc_info=True)
        return []


def fetch_quiz_questions(course_id, quiz_id, canvas_address, token):
    """
    Fetch detailed question information from Canvas API.

    Returns:
        dict: Dictionary mapping question_id to question details
    """
    # Ensure canvas_address has proper HTTPS scheme
    if canvas_address and not canvas_address.startswith(('http://', 'https://')):
        canvas_address = f'https://{canvas_address}'
    elif canvas_address and canvas_address.startswith('http://'):
        canvas_address = canvas_address.replace('http://', 'https://')

    headers = {"Authorization": f"Bearer {token}"}
    api_url = f"{canvas_address}/api/v1/courses/{course_id}/quizzes/{quiz_id}/questions"

    logger.info(f"[MODULE] Fetching question details for quiz {quiz_id}")

    all_questions = {}
    page = 1

    while True:
        params = {'page': page, 'per_page': 100}
        response = requests.get(api_url, headers=headers, params=params, timeout=30)

        if not response.ok:
            logger.warning(f"Failed to fetch questions (status {response.status_code})")
            break

        questions = response.json()
        if not questions:
            break

        for q in questions:
            q_id = str(q.get('id', ''))

            # Extract correct answer based on question type
            correct_answer = ""
            answer_choices = []

            if q.get('question_type') == 'multiple_choice_question' and q.get('answers'):
                for answer in q.get('answers', []):
                    answer_choices.append(answer.get('text', ''))
                    if answer.get('weight', 0) == 100:  # Correct answer has weight 100
                        correct_answer = answer.get('text', '')

            elif q.get('question_type') == 'true_false_question' and q.get('answers'):
                for answer in q.get('answers', []):
                    if answer.get('weight', 0) == 100:
                        correct_answer = answer.get('text', '')

            all_questions[q_id] = {
                'question_name': q.get('question_name', ''),
                'question_type': q.get('question_type', 'unknown'),
                'question_text': q.get('question_text', ''),
                'points_possible': q.get('points_possible', 0),
                'correct_answer': correct_answer,
                'answer_choices': '|'.join(answer_choices) if answer_choices else ''
            }

        # Check if there are more pages
        if 'next' not in response.links:
            break
        page += 1

    logger.info(f"[MODULE] Successfully fetched {len(all_questions)} question details")
    return all_questions


def download_quiz_submissions(course_id, quiz_id, progress_callback=None):
    """
    Download quiz submissions using Canvas Quiz Reports API.
    This approach guarantees student answers are included.

    Args:
        course_id: Canvas course ID
        quiz_id: Canvas quiz ID
        progress_callback: Optional callback for progress updates

    Returns:
        str: Path to CSV file, or None on error
    """
    logger.info(f"🔍 [MODULE] download_quiz_submissions() called: course_id={course_id}, quiz_id={quiz_id}")
    logger.info(f"[MODULE] Using Canvas Quiz Reports API for reliable answer download")
    logger.info(f"[MODULE] Progress callback provided: {progress_callback is not None}")

    # Use only the Quiz Reports API approach (most reliable)
    return download_quiz_submissions_via_reports(course_id, quiz_id, progress_callback)


def download_quiz_submissions_via_reports(course_id, quiz_id, progress_callback=None, preserve_canvas_grades=False):
    """
    Downloads quiz submissions using Canvas Quiz Reports API (student analysis report).
    This is the most reliable method for getting student answers.

    Args:
        course_id: Canvas course ID
        quiz_id: Canvas quiz ID
        progress_callback: Optional callback for progress updates
        preserve_canvas_grades: If True, keep Canvas grades. If False (default), clear them for fresh grading.

    Returns:
        str: Path to CSV file, or None on error
    """
    logger.info(f"[MODULE] Using Quiz Reports API approach for quiz {quiz_id}")

    try:
        # Get Canvas credentials
        success, canvas_address, token, _ = get_active_canvas_credentials()
        if not success:
            logger.error("[MODULE] Failed to get Canvas credentials")
            return None

        # Ensure canvas_address has proper HTTPS scheme
        if canvas_address and not canvas_address.startswith(('http://', 'https://')):
            canvas_address = f'https://{canvas_address}'
        elif canvas_address and canvas_address.startswith('http://'):
            canvas_address = canvas_address.replace('http://', 'https://')

        logger.debug(f"[MODULE] Using Canvas URL: {canvas_address}")

        headers = {"Authorization": f"Bearer {token}"}
        api_url = f"{canvas_address}/api/v1/courses/{course_id}/quizzes/{quiz_id}/reports"

        # Progress: Starting
        if progress_callback:
            progress_callback({
                'phase': 'fetch_data',
                'done': 0,
                'total': 5,
                'percent': 5,
                'current_item': 'Canvas connection',
                'status': 'Requesting quiz report...',
                'details': f'Course {course_id}, Quiz {quiz_id}'
            })

        # Request student analysis report
        payload = {
            "quiz_report[report_type]": "student_analysis",
            "quiz_report[includes_all_versions]": "true"
        }

        logger.info(f"[MODULE] Requesting student analysis report generation...")
        response = requests.post(api_url, headers=headers, data=payload, timeout=30)

        if response.status_code == 409:
            logger.info("[MODULE] Report already in progress - proceeding to poll existing report")
        elif not response.ok:
            logger.error(f"[MODULE] Report request failed (status {response.status_code}): {response.text[:150]}")
            return None
        else:
            logger.info("[MODULE] Report request accepted by Canvas")

        report_info = response.json()
        progress_url = report_info.get("progress_url")

        if not progress_url:
            logger.error("[MODULE] No progress URL returned - possibly a permission issue")
            return None

        # Progress: Report requested
        if progress_callback:
            progress_callback({
                'phase': 'fetch_data',
                'done': 1,
                'total': 5,
                'percent': 15,
                'current_item': 'Report generation',
                'status': 'Waiting for Canvas to generate report...',
                'details': 'This may take a moment'
            })

        # Poll for completion
        logger.info("[MODULE] Polling for report completion...")
        for attempt in range(REPORT_POLL_MAX_ATTEMPTS):
            poll_response = requests.get(progress_url, headers=headers, timeout=30)
            if not poll_response.ok:
                logger.error(f"[MODULE] Progress check failed: {poll_response.text[:150]}")
                return None

            progress_data = poll_response.json()
            state = progress_data.get("workflow_state", "unknown")
            completion = progress_data.get("completion", 0)

            logger.info(f"[MODULE] Report progress: {completion}% - {state}")

            if state == "completed":
                break
            if state == "failed":
                logger.error("[MODULE] Report generation failed on Canvas side")
                return None

            time.sleep(REPORT_POLL_INTERVAL_SECONDS)
        else:
            logger.error(f"[MODULE] Timed out waiting for report after {REPORT_POLL_MAX_ATTEMPTS} attempts")
            return None

        # Progress: Report ready
        if progress_callback:
            progress_callback({
                'phase': 'fetch_data',
                'done': 2,
                'total': 5,
                'percent': 30,
                'current_item': 'Report ready',
                'status': 'Fetching report details...',
                'details': 'Report generated successfully'
            })

        # Fetch report metadata
        logger.info("[MODULE] Fetching completed report details...")
        report_id = report_info.get("id")
        if not report_id:
            logger.error("[MODULE] No report ID found in response")
            return None

        report_response = requests.get(f"{api_url}/{report_id}", headers=headers, timeout=30)
        if not report_response.ok:
            logger.error(f"[MODULE] Failed to fetch report details: {report_response.text[:150]}")
            return None

        final_report = report_response.json()
        file_url = final_report.get("file", {}).get("url")

        if not file_url:
            logger.error("[MODULE] No file URL available in report")
            return None

        # Progress: Downloading CSV
        if progress_callback:
            progress_callback({
                'phase': 'fetch_data',
                'done': 3,
                'total': 5,
                'percent': 50,
                'current_item': 'CSV download',
                'status': 'Downloading CSV data...',
                'details': 'Retrieving student answers'
            })

        # Download CSV
        logger.info("[MODULE] Downloading CSV data from Canvas...")
        csv_response = requests.get(file_url, timeout=60)
        if not csv_response.ok:
            logger.error(f"[MODULE] Failed to download CSV: {csv_response.status_code}")
            return None

        # Parse and transform CSV with proper UTF-8 encoding
        csv_response.encoding = 'utf-8'  # Force UTF-8 encoding to handle special characters
        original_csv = csv_response.text
        reader = csv.DictReader(io.StringIO(original_csv))
        rows_from_canvas = list(reader)

        if not rows_from_canvas:
            logger.warning("[MODULE] CSV is empty - no student data in quiz")
            return None

        logger.info(f"[MODULE] Downloaded {len(rows_from_canvas)} rows from Canvas")

        # Fetch question details from Canvas API
        question_details = fetch_quiz_questions(course_id, quiz_id, canvas_address, token)

        # Progress: Processing data
        if progress_callback:
            progress_callback({
                'phase': 'process_rows',
                'done': 0,
                'total': len(rows_from_canvas),
                'percent': 60,
                'current_item': 'Processing',
                'status': f'Processing {len(rows_from_canvas)} submissions...',
                'details': 'Transforming data format'
            })

        # Transform CSV to our format with robust column filtering
        transformed_rows = []

        for row_idx, row in enumerate(rows_from_canvas):
            student_name = row.get('name', 'Unknown')
            student_id = row.get('id', 'Unknown')
            student_email = row.get('sis_id', '')

            # Define metadata columns to skip
            meta_cols = {
                'name', 'id', 'sis_id', 'section', 'section_id', 'section_sis_id',
                'submitted', 'score', 'attempt', 'n correct', 'n incorrect'
            }

            # IMPROVED: Two-pass approach - first identify valid question columns
            all_cols = list(row.keys())
            question_cols = []

            for col in all_cols:
                # Skip metadata columns
                if col in meta_cols:
                    continue

                # Skip points columns - Canvas adds ' pts' suffix
                if col.endswith(' pts'):
                    continue

                # Skip empty columns
                if not row[col].strip():
                    continue

                # Skip numeric-only column names (these are usually points or IDs)
                # This prevents creating duplicate rows from numeric columns
                try:
                    float(col)
                    # This is a numeric column, likely points - skip it
                    logger.debug(f"Skipping numeric column: {col}")
                    continue
                except ValueError:
                    # Not a number, treat as potential question
                    question_cols.append(col)

            logger.debug(f"Found {len(question_cols)} valid question columns for student {student_name}")

            # Process only validated question columns
            for col_name in question_cols:
                # Parse question ID and text from column name
                question_id = col_name
                question_text = col_name

                if ':' in col_name:
                    parts = col_name.split(':', 1)
                    if len(parts) == 2:
                        question_id = parts[0].strip()
                        question_text = parts[1].strip()

                # Get question details
                q_details = question_details.get(question_id, {})

                # Look for points in adjacent columns (improved logic from quiz.py)
                points_earned = 0
                points_col_name = f"{col_name} pts"

                # First try the standard " pts" suffix column
                if points_col_name in row:
                    try:
                        points_earned = float(row[points_col_name] or 0)
                    except (ValueError, TypeError):
                        points_earned = 0
                else:
                    # If no " pts" column, look for numeric value in next columns
                    col_index = all_cols.index(col_name) if col_name in all_cols else -1
                    if col_index >= 0:
                        # Check next few columns for numeric points values
                        for offset in range(1, min(4, len(all_cols) - col_index)):
                            next_col = all_cols[col_index + offset]
                            next_value = row.get(next_col, '').strip()

                            # Check if this could be a points value
                            try:
                                if next_value and next_value.replace('.', '').replace('-', '').isdigit():
                                    potential_points = float(next_value)
                                    # Sanity check: points should be reasonable
                                    if 0 <= potential_points <= 1000:
                                        points_earned = potential_points
                                        logger.debug(f"Found points {points_earned} in column {next_col}")
                                        break
                            except (ValueError, TypeError):
                                continue

                points_possible = q_details.get('points_possible', 1)

                # Create row for this question
                if preserve_canvas_grades:
                    # Keep Canvas grades (for review/re-upload scenarios)
                    transformed_rows.append({
                        'student_id': student_id,
                        'student_name': student_name,
                        'student_email': student_email,
                        'quiz_id': str(quiz_id),
                        'quiz_title': f"Quiz {quiz_id}",
                        'question_id': question_id,
                        'question_text': q_details.get('question_text', question_text),
                        'question_type': q_details.get('question_type', 'unknown'),
                        'correct_answer': q_details.get('correct_answer', ''),
                        'answer_choices': q_details.get('answer_choices', ''),
                        'student_answer': row[col_name],
                        'points_earned': str(points_earned),
                        'points_possible': str(points_possible),
                        'is_correct': str(points_earned == points_possible and points_possible > 0),
                        'grade': f"{points_earned}/{points_possible}",
                        'feedback': '',
                        'llm': ''
                    })
                else:
                    # Clear Canvas grades - start fresh for our grading (DEFAULT)
                    transformed_rows.append({
                        'student_id': student_id,
                        'student_name': student_name,
                        'student_email': student_email,
                        'quiz_id': str(quiz_id),
                        'quiz_title': f"Quiz {quiz_id}",
                        'question_id': question_id,
                        'question_text': q_details.get('question_text', question_text),
                        'question_type': q_details.get('question_type', 'unknown'),
                        'correct_answer': q_details.get('correct_answer', ''),
                        'answer_choices': q_details.get('answer_choices', ''),
                        'student_answer': row[col_name],
                        'points_earned': '',  # Clear - start fresh
                        'points_possible': str(points_possible),
                        'is_correct': '',  # Clear - will be set during grading
                        'grade': '',  # Clear - will be set during grading
                        'feedback': '',  # Empty - for our feedback
                        'llm': ''  # Empty - for LLM processing
                    })

            # Progress update for each student processed
            if progress_callback and (row_idx + 1) % 5 == 0:
                percent = 60 + (30 * (row_idx + 1) / len(rows_from_canvas))
                progress_callback({
                    'phase': 'process_rows',
                    'done': row_idx + 1,
                    'total': len(rows_from_canvas),
                    'percent': round(percent, 1),
                    'current_item': student_name,
                    'status': f'Processed {row_idx + 1}/{len(rows_from_canvas)} students',
                    'details': 'Transforming answers'
                })

        if not transformed_rows:
            logger.warning("[MODULE] No data to save after transformation")
            return None

        # Save to CSV
        csv_path = get_quiz_csv_path(course_id, quiz_id)

        # Progress: Writing CSV
        if progress_callback:
            progress_callback({
                'phase': 'write_csv',
                'done': 0,
                'total': 1,
                'percent': 95,
                'current_item': 'CSV file',
                'status': 'Saving to CSV...',
                'details': f'{len(transformed_rows)} rows'
            })

        logger.info(f"[MODULE] Writing {len(transformed_rows)} rows to {csv_path}")
        write_csv(csv_path, transformed_rows)

        logger.info(f"✅ [MODULE] Successfully saved quiz data using Reports API")

        # Progress: Complete
        if progress_callback:
            progress_callback({
                'phase': 'write_csv',
                'done': 1,
                'total': 1,
                'percent': 100,
                'current_item': str(csv_path),
                'status': 'Download complete!',
                'details': f'Saved {len(transformed_rows)} rows'
            })

        return csv_path

    except Exception as e:
        logger.error(f"❌ [MODULE] Error in Quiz Reports API approach: {e}", exc_info=True)
        return None


# Removed the fallback submission API method - using only CSV Reports API approach
