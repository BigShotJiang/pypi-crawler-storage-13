"""Configuration management module for AnZar."""

from .app_config import (
    get_data_dir,
    get_profiles_path,
    get_log_path,
    get_app_config_dir,
    load_config,
    save_config,
    set_data_folder,
    is_first_run,
    mark_first_run_complete,
    get_data_folder_info,
    is_portable_mode,
    migrate_old_profiles
)

__all__ = [
    'get_data_dir',
    'get_profiles_path',
    'get_log_path',
    'get_app_config_dir',
    'load_config',
    'save_config',
    'set_data_folder',
    'is_first_run',
    'mark_first_run_complete',
    'get_data_folder_info',
    'is_portable_mode',
    'migrate_old_profiles'
]
