"""
Simplified profile manager for Canvas and LLM configurations.
Reduced from 597 lines to ~210 lines.
"""

import json
import os
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import uuid
from pathlib import Path

# Import config functions to get AppData paths
try:
    from modules.config.app_config import get_profiles_path, migrate_old_profiles
except ImportError:
    # Fallback for development/testing
    def get_profiles_path():
        return Path('profiles.json')
    def migrate_old_profiles():
        return True

logger = logging.getLogger(__name__)


class ProfileManager:
    """Manages Canvas and LLM profiles with minimal complexity."""

    def __init__(self):
        # Use AppData location for profiles.json
        self.profiles_file = str(get_profiles_path())
        # Attempt migration from old location
        migrate_old_profiles()
        self._ensure_file()

    def _ensure_file(self):
        """Ensure profiles.json exists."""
        if not os.path.exists(self.profiles_file):
            with open(self.profiles_file, 'w', encoding='utf-8') as f:
                json.dump({
                    "canvas_profiles": [],
                    "llm_profiles": [],
                    "active_canvas_profile": None,
                    "active_llm_profile": None
                }, f, indent=4)

    def _load(self) -> dict:
        """Load profiles from JSON."""
        try:
            with open(self.profiles_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            self._ensure_file()
            return {
                "canvas_profiles": [],
                "llm_profiles": [],
                "active_canvas_profile": None,
                "active_llm_profile": None
            }

    def _save(self, data: dict):
        """Save profiles to JSON."""
        with open(self.profiles_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4)

    # ==================== CANVAS METHODS ====================

    def get_canvas_profiles(self) -> List[Dict]:
        """Get all Canvas profiles."""
        return self._load().get('canvas_profiles', [])

    def get_active_canvas_profile(self) -> Optional[Dict]:
        """Get active Canvas profile."""
        data = self._load()
        active_id = data.get('active_canvas_profile')
        if active_id:
            for profile in data.get('canvas_profiles', []):
                if profile['id'] == active_id:
                    return profile
        return None

    def create_canvas_profile(self, name: str, canvas_address: str, token: str, email: str = "") -> Tuple[bool, str]:
        """Create Canvas profile."""
        if not name or not canvas_address or not token:
            return False, "Name, address, and token are required"

        data = self._load()
        profiles = data.get('canvas_profiles', [])

        # Check name uniqueness
        if any(p['name'] == name for p in profiles):
            return False, "Profile name already exists"

        # Ensure HTTPS
        if not canvas_address.startswith('https://'):
            canvas_address = canvas_address.replace('http://', 'https://')
            if not canvas_address.startswith('https://'):
                canvas_address = f'https://{canvas_address}'

        new_profile = {
            'id': str(uuid.uuid4()),
            'name': name.strip(),
            'canvas_address': canvas_address.strip(),
            'token': token.strip(),
            'email': email.strip(),
            'created_at': datetime.now().isoformat(),
            'last_used': None
        }

        profiles.append(new_profile)
        data['canvas_profiles'] = profiles

        # Set as active if first profile
        if len(profiles) == 1:
            data['active_canvas_profile'] = new_profile['id']

        self._save(data)
        logger.info(f"Created Canvas profile: {name}")
        return True, new_profile['id']

    def update_canvas_profile(self, profile_id: str, name: str = None, canvas_address: str = None,
                              token: str = None, email: str = None) -> Tuple[bool, str]:
        """Update Canvas profile."""
        data = self._load()
        profiles = data.get('canvas_profiles', [])

        for i, profile in enumerate(profiles):
            if profile['id'] == profile_id:
                if name:
                    profile['name'] = name.strip()
                if canvas_address:
                    if not canvas_address.startswith('https://'):
                        canvas_address = canvas_address.replace('http://', 'https://')
                        if not canvas_address.startswith('https://'):
                            canvas_address = f'https://{canvas_address}'
                    profile['canvas_address'] = canvas_address.strip()
                if token:
                    profile['token'] = token.strip()
                if email is not None:
                    profile['email'] = email.strip()

                profile['updated_at'] = datetime.now().isoformat()
                profiles[i] = profile
                data['canvas_profiles'] = profiles
                self._save(data)
                logger.info(f"Updated Canvas profile: {profile['name']}")
                return True, "Profile updated"

        return False, "Profile not found"

    def delete_canvas_profile(self, profile_id: str) -> Tuple[bool, str]:
        """Delete Canvas profile."""
        data = self._load()
        profiles = data.get('canvas_profiles', [])

        profiles = [p for p in profiles if p['id'] != profile_id]
        data['canvas_profiles'] = profiles

        if data.get('active_canvas_profile') == profile_id:
            data['active_canvas_profile'] = None

        self._save(data)
        logger.info(f"Deleted Canvas profile: {profile_id}")
        return True, "Profile deleted"

    def set_active_canvas_profile(self, profile_id: str) -> Tuple[bool, str]:
        """Set active Canvas profile."""
        data = self._load()
        profiles = data.get('canvas_profiles', [])

        for i, profile in enumerate(profiles):
            if profile['id'] == profile_id:
                data['active_canvas_profile'] = profile_id
                profile['last_used'] = datetime.now().isoformat()
                profiles[i] = profile
                data['canvas_profiles'] = profiles
                self._save(data)
                logger.info(f"Set active Canvas profile: {profile['name']}")
                return True, "Active profile updated"

        return False, "Profile not found"

    # ==================== LLM METHODS ====================

    def get_llm_profiles(self) -> List[Dict]:
        """Get all LLM profiles."""
        return self._load().get('llm_profiles', [])

    def get_active_llm_profile(self) -> Optional[Dict]:
        """Get active LLM profile."""
        data = self._load()
        active_id = data.get('active_llm_profile')
        if active_id:
            for profile in data.get('llm_profiles', []):
                if profile['id'] == active_id:
                    return profile
        return None

    def create_llm_profile(self, name: str, api_link: str, model_name: str, token: str, llm_type: str = "remote") -> Tuple[bool, str]:
        """Create LLM profile."""
        if not name or not api_link or not model_name:
            return False, "Name, API link, and model name are required"

        data = self._load()
        profiles = data.get('llm_profiles', [])

        # Check name uniqueness
        if any(p['name'] == name for p in profiles):
            return False, "Profile name already exists"

        # Normalize URL
        api_link = api_link.strip()
        if not api_link.startswith(('http://', 'https://')):
            if ':' in api_link or api_link.startswith('localhost'):
                api_link = f'http://{api_link}'
            else:
                api_link = f'https://{api_link}'

        new_profile = {
            'id': str(uuid.uuid4()),
            'name': name.strip(),
            'api_link': api_link,
            'model_name': model_name.strip(),
            'token': token.strip(),
            'type': llm_type if llm_type in ['remote', 'local'] else 'remote',
            'created_at': datetime.now().isoformat(),
            'last_used': None
        }

        profiles.append(new_profile)
        data['llm_profiles'] = profiles

        # Set as active if first profile
        if len(profiles) == 1:
            data['active_llm_profile'] = new_profile['id']

        self._save(data)
        logger.info(f"Created LLM profile: {name}")
        return True, new_profile['id']

    def update_llm_profile(self, profile_id: str, name: str = None, api_link: str = None,
                           model_name: str = None, token: str = None, llm_type: str = None) -> Tuple[bool, str]:
        """Update LLM profile."""
        data = self._load()
        profiles = data.get('llm_profiles', [])

        for i, profile in enumerate(profiles):
            if profile['id'] == profile_id:
                if name:
                    profile['name'] = name.strip()
                if api_link:
                    api_link = api_link.strip()
                    if not api_link.startswith(('http://', 'https://')):
                        if ':' in api_link or api_link.startswith('localhost'):
                            api_link = f'http://{api_link}'
                        else:
                            api_link = f'https://{api_link}'
                    profile['api_link'] = api_link
                if model_name:
                    profile['model_name'] = model_name.strip()
                if token is not None:
                    profile['token'] = token.strip()
                if llm_type:
                    profile['type'] = llm_type if llm_type in ['remote', 'local'] else 'remote'

                profile['updated_at'] = datetime.now().isoformat()
                profiles[i] = profile
                data['llm_profiles'] = profiles
                self._save(data)
                logger.info(f"Updated LLM profile: {profile['name']}")
                return True, "Profile updated"

        return False, "Profile not found"

    def delete_llm_profile(self, profile_id: str) -> Tuple[bool, str]:
        """Delete LLM profile."""
        data = self._load()
        profiles = data.get('llm_profiles', [])

        profiles = [p for p in profiles if p['id'] != profile_id]
        data['llm_profiles'] = profiles

        if data.get('active_llm_profile') == profile_id:
            data['active_llm_profile'] = None

        self._save(data)
        logger.info(f"Deleted LLM profile: {profile_id}")
        return True, "Profile deleted"

    def set_active_llm_profile(self, profile_id: str) -> Tuple[bool, str]:
        """Set active LLM profile."""
        data = self._load()
        profiles = data.get('llm_profiles', [])

        for i, profile in enumerate(profiles):
            if profile['id'] == profile_id:
                data['active_llm_profile'] = profile_id
                profile['last_used'] = datetime.now().isoformat()
                profiles[i] = profile
                data['llm_profiles'] = profiles
                self._save(data)
                logger.info(f"Set active LLM profile: {profile['name']}")
                return True, "Active profile updated"

        return False, "Profile not found"


# ==================== SINGLETON ====================

_manager = None

def get_profile_manager() -> ProfileManager:
    """Get singleton ProfileManager."""
    global _manager
    if _manager is None:
        _manager = ProfileManager()
    return _manager


# ==================== COMPATIBILITY FUNCTIONS ====================

def get_canvas_config() -> Tuple[Optional[str], Optional[str]]:
    """Get Canvas credentials (canvas_address, token)."""
    profile = get_profile_manager().get_active_canvas_profile()
    if profile:
        return profile.get('canvas_address'), profile.get('token')
    return None, None


def get_llm_config() -> Optional[Dict]:
    """Get active LLM config."""
    return get_profile_manager().get_active_llm_profile()


# Aliases for backward compatibility
read_canvas_config = get_canvas_config
read_llm_config = get_llm_config


def get_active_canvas_credentials():
    """Get credentials from active Canvas profile (backward compatibility).

    Returns:
        tuple: (success: bool, canvas_address: str, token: str, email: str)
    """
    profile = get_profile_manager().get_active_canvas_profile()
    if profile and profile.get('canvas_address') and profile.get('token'):
        return (
            True,  # success
            profile['canvas_address'],
            profile['token'],
            profile.get('email', '')  # email (optional)
        )
    return (
        False,  # success
        None,   # canvas_address
        None,   # token
        ""      # email
    )
