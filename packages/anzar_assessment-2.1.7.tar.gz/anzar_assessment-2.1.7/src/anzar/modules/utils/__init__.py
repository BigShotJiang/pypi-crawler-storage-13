"""
Simplified utils module - consolidated and streamlined.
"""

# CSV utilities (centralized)
from .csv_utils import (
    read_csv,
    write_csv,
    get_quiz_csv_path,
    get_assignment_csv_path,
    list_questions_from_csv,
    get_sample_answers,
    get_ungraded_rows,
    get_grading_status,
    safe_grade_to_float,  # New utility function
    # Backward compatibility aliases
    safe_read_csv,
    safe_write_csv,
    safe_write_csv_with_backup,
    analyze_csv_grading_status,
    list_questions_in_csv,
    get_sample_answers_from_csv,
)

# File utilities (simplified)
from .files import (
    ensure_directory_exists,
    safe_read_json,
    safe_write_json,
    file_exists,
    safe_update_json_file,  # Backward compat
    CSVBackupManager,  # Deprecated no-op
    ProfileBackupManager,  # Deprecated no-op
    normalize_canvas_url,
    get_data_dir,
    get_course_dir,
    get_assignment_dir,
    resolve_csv_path,
    resolve_folder_path,
    check_file_readable,
    check_file_writable,
    is_auto_gradable_question,
)

# HTML utilities (simplified)
from .html import html_to_text, prepare_for_llm

# Canvas utilities (backward compat)
from .canvas import get_canvas_instance

__all__ = [
    # CSV
    'read_csv',
    'write_csv',
    'get_quiz_csv_path',
    'get_assignment_csv_path',
    'list_questions_from_csv',
    'get_sample_answers',
    'get_ungraded_rows',
    'get_grading_status',
    'safe_grade_to_float',
    'safe_read_csv',
    'safe_write_csv',
    'safe_write_csv_with_backup',
    'analyze_csv_grading_status',
    'list_questions_in_csv',
    'get_sample_answers_from_csv',
    # Files
    'ensure_directory_exists',
    'safe_read_json',
    'safe_write_json',
    'file_exists',
    'safe_update_json_file',
    'CSVBackupManager',
    'ProfileBackupManager',
    'normalize_canvas_url',
    'get_data_dir',
    'get_course_dir',
    'get_assignment_dir',
    'resolve_csv_path',
    'resolve_folder_path',
    'check_file_readable',
    'check_file_writable',
    'is_auto_gradable_question',
    # HTML
    'html_to_text',
    'prepare_for_llm',
    # Canvas
    'get_canvas_instance',
]
