"""
Data folder scanner utilities.
Scans data/ folder for courses, quizzes, assignments, and grading progress.
"""

import csv
import time
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def scan_data_folder(recent_days=7):
    """
    Scan data/ folder and return statistics.

    Args:
        recent_days: Only count graded questions from CSVs modified in last N days

    Returns:
        dict: {
            'courses': int,
            'quizzes': int,
            'assignments': int,
            'graded_questions': int,
            'quiz_csvs': list[Path],
            'assignment_csvs': list[Path]
        }
    """
    try:
        data_dir = Path("data")

        if not data_dir.exists():
            data_dir.mkdir(parents=True, exist_ok=True)
            return {
                'courses': 0,
                'quizzes': 0,
                'assignments': 0,
                'graded_questions': 0,
                'quiz_csvs': [],
                'assignment_csvs': []
            }

        # Count courses
        courses = [d for d in data_dir.glob("course_*") if d.is_dir()]
        course_count = len(courses)

        # Count quizzes (quiz_*.csv files, excluding backups)
        quiz_csvs = []
        for csv_file in data_dir.glob("course_*/quiz_*.csv"):
            if csv_file.name.endswith('.csv') and not csv_file.name.endswith('.csv.encoding_backup'):
                quiz_csvs.append(csv_file)
        quiz_count = len(quiz_csvs)

        # Count assignments
        assignment_folders = [d for d in data_dir.glob("course_*/assignment_*") if d.is_dir()]
        assignment_count = len(assignment_folders)

        # Find assignment CSVs
        assignment_csvs = []
        for folder in assignment_folders:
            csv_path = folder / "parsed_submissions.csv"
            if csv_path.exists():
                assignment_csvs.append(csv_path)

        # Count graded questions from recent CSVs only
        recent_cutoff = time.time() - (recent_days * 24 * 3600) if recent_days else 0
        graded_count = 0

        for csv_path in quiz_csvs:
            try:
                if csv_path.stat().st_mtime > recent_cutoff:
                    graded_count += _count_graded_questions(csv_path)
            except Exception as e:
                logger.warning(f"Error counting graded questions in {csv_path}: {e}")

        for csv_path in assignment_csvs:
            try:
                if csv_path.stat().st_mtime > recent_cutoff:
                    graded_count += _count_graded_questions(csv_path)
            except Exception as e:
                logger.warning(f"Error counting graded questions in {csv_path}: {e}")

        return {
            'courses': course_count,
            'quizzes': quiz_count,
            'assignments': assignment_count,
            'graded_questions': graded_count,
            'quiz_csvs': quiz_csvs,
            'assignment_csvs': assignment_csvs
        }

    except Exception as e:
        logger.error(f"Error scanning data folder: {e}")
        return {
            'courses': 0,
            'quizzes': 0,
            'assignments': 0,
            'graded_questions': 0,
            'quiz_csvs': [],
            'assignment_csvs': []
        }


def find_interrupted_tasks():
    """
    Find CSVs with partial grading (interrupted tasks).

    Returns:
        list[dict]: List of interrupted tasks with:
            - type: 'quiz' or 'assignment'
            - course_id: str
            - content_id: str
            - content_name: str
            - csv_path: str
            - total_questions: int
            - graded_questions: int
            - completion_percentage: float
            - last_modified: float (timestamp)
    """
    try:
        data_dir = Path("data")

        if not data_dir.exists():
            return []

        interrupted_tasks = []

        # Scan quiz CSVs
        for csv_path in data_dir.glob("course_*/quiz_*.csv"):
            # Skip backup files
            if not csv_path.name.endswith('.csv') or csv_path.name.endswith('.csv.encoding_backup'):
                continue

            try:
                task_info = _analyze_csv_progress(csv_path, content_type='quiz')

                # Only include if partially graded (0% < completion < 100%)
                if task_info and 0 < task_info['completion_percentage'] < 100:
                    interrupted_tasks.append(task_info)

            except Exception as e:
                logger.warning(f"Error analyzing {csv_path}: {e}")

        # Scan assignment CSVs
        for csv_path in data_dir.glob("course_*/assignment_*/parsed_submissions.csv"):
            try:
                task_info = _analyze_csv_progress(csv_path, content_type='assignment')

                # Only include if partially graded (0% < completion < 100%)
                if task_info and 0 < task_info['completion_percentage'] < 100:
                    interrupted_tasks.append(task_info)

            except Exception as e:
                logger.warning(f"Error analyzing {csv_path}: {e}")

        # Sort by last modified (most recent first)
        interrupted_tasks.sort(key=lambda x: x['last_modified'], reverse=True)

        return interrupted_tasks

    except Exception as e:
        logger.error(f"Error finding interrupted tasks: {e}")
        return []


def _count_graded_questions(csv_path):
    """
    Count total number of graded student-question pairs in a CSV.

    Args:
        csv_path: Path to CSV file

    Returns:
        int: Total grading operations performed (students × questions)
    """
    try:
        with open(csv_path, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            fieldnames = reader.fieldnames

            if not fieldnames or 'grade' not in fieldnames:
                return 0

            # Count total graded rows (each row is one student-question pair)
            graded_count = 0

            for row in reader:
                grade_value = row.get('grade', '').strip()

                # If grade is not empty, this is a graded student-question pair
                if grade_value and grade_value != '':
                    graded_count += 1

            return graded_count

    except Exception as e:
        logger.warning(f"Error reading CSV {csv_path}: {e}")
        return 0


def _analyze_csv_progress(csv_path, content_type):
    """
    Analyze CSV grading progress and return task info.

    Args:
        csv_path: Path to CSV file
        content_type: 'quiz' or 'assignment'

    Returns:
        dict or None: Task information or None if can't analyze
    """
    try:
        # Extract IDs from path
        parts = csv_path.parts
        course_id = None
        content_id = None

        for part in parts:
            if part.startswith('course_'):
                course_id = part.replace('course_', '')
            elif content_type == 'quiz' and part.startswith('quiz_'):
                content_id = part.replace('quiz_', '').replace('.csv', '')
            elif content_type == 'assignment' and part.startswith('assignment_'):
                content_id = part.replace('assignment_', '')

        if not course_id or not content_id:
            return None

        # Analyze CSV
        with open(csv_path, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            fieldnames = reader.fieldnames

            if not fieldnames or 'grade' not in fieldnames:
                return None

            # Find question ID column
            question_id_col = None
            for col in ['question_id', 'part', 'id']:
                if col in fieldnames:
                    question_id_col = col
                    break

            if not question_id_col:
                return None

            # Count total and graded questions
            all_questions = set()
            graded_questions = set()

            for row in reader:
                question_id = row.get(question_id_col, '').strip()
                if question_id:
                    all_questions.add(question_id)

                    grade_value = row.get('grade', '').strip()
                    if grade_value and grade_value != '':
                        graded_questions.add(question_id)

            total_questions = len(all_questions)
            graded_count = len(graded_questions)

            if total_questions == 0:
                return None

            completion_percentage = (graded_count / total_questions) * 100

            # Get content name from CSV if available
            content_name = f"{content_type.title()} {content_id}"
            if content_type == 'quiz' and 'quiz_title' in fieldnames:
                f.seek(0)
                reader = csv.DictReader(f)
                first_row = next(reader, None)
                if first_row and first_row.get('quiz_title'):
                    content_name = first_row['quiz_title']

            return {
                'type': content_type,
                'course_id': course_id,
                'content_id': content_id,
                'content_name': content_name,
                'csv_path': str(csv_path),
                'total_questions': total_questions,
                'graded_questions': graded_count,
                'completion_percentage': round(completion_percentage, 1),
                'last_modified': csv_path.stat().st_mtime
            }

    except Exception as e:
        logger.warning(f"Error analyzing CSV progress {csv_path}: {e}")
        return None
