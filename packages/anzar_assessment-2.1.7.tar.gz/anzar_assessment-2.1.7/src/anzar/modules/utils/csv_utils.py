"""
Centralized CSV utilities - all CSV operations in one place.
Consolidates functions from files.py, grade_llm.py, csv_analysis.py
"""

import csv
import os
import logging
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from .html import clean_csv_text

logger = logging.getLogger(__name__)


# ==================== CSV READ/WRITE ====================

def read_csv(csv_path: str) -> List[Dict]:
    """
    Read CSV file and return list of dicts with encoding validation and cleaning.

    Args:
        csv_path: Path to CSV file

    Returns:
        List of row dicts with cleaned text, empty list on error
    """
    try:
        rows = []
        with open(csv_path, 'r', encoding='utf-8', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Clean each field to fix encoding issues
                cleaned_row = {}
                for key, value in row.items():
                    cleaned_row[key] = clean_csv_text(value)
                rows.append(cleaned_row)
        return rows
    except UnicodeDecodeError as ude:
        logger.error(f"Encoding error reading CSV {csv_path}: {ude}")
        # Try with error handling
        try:
            rows = []
            with open(csv_path, 'r', encoding='utf-8', errors='replace', newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    cleaned_row = {}
                    for key, value in row.items():
                        cleaned_row[key] = clean_csv_text(value)
                    rows.append(cleaned_row)
            logger.warning(f"Read CSV {csv_path} with encoding errors replaced")
            return rows
        except Exception as e2:
            logger.error(f"Failed to read CSV {csv_path} even with error handling: {e2}")
            return []
    except Exception as e:
        logger.error(f"Error reading CSV {csv_path}: {e}")
        return []


def write_csv(csv_path: str, rows: List[Dict], fieldnames: Optional[List[str]] = None):
    """
    Write list of dicts to CSV file with text cleaning and validation.

    Args:
        csv_path: Path to CSV file
        rows: List of row dicts
        fieldnames: Optional column names (auto-detected if None)
    """
    import json

    try:
        if not rows:
            logger.warning(f"No rows to write to {csv_path}")
            return

        # VALIDATION: Ensure rows is a list of dicts
        if not isinstance(rows, list):
            raise ValueError(f"rows must be a list, got {type(rows).__name__}")

        for row_idx, row in enumerate(rows):
            if not isinstance(row, dict):
                raise ValueError(f"Row {row_idx} must be a dict, got {type(row).__name__}: {row}")

        # Auto-detect fieldnames from first row if not provided
        if fieldnames is None:
            fieldnames = list(rows[0].keys())

        # Clean and validate data before writing
        for row_idx, row in enumerate(rows):
            for key, value in row.items():
                if isinstance(value, (dict, list)):
                    logger.warning(f"Row {row_idx}, field '{key}' has {type(value).__name__}, converting to JSON")
                    rows[row_idx][key] = json.dumps(value)
                elif isinstance(value, str):
                    # Clean text to fix encoding issues
                    rows[row_idx][key] = clean_csv_text(value)
                # Ensure grade-related fields are properly formatted
                elif key in ['grade', 'points_earned', 'points_possible']:
                    # Convert numeric grade values to float for consistency
                    if value not in [None, '']:
                        try:
                            rows[row_idx][key] = float(value)
                        except (ValueError, TypeError):
                            logger.warning(f"Row {row_idx}, field '{key}' has invalid grade value: '{value}', using 0.0")
                            rows[row_idx][key] = 0.0

        # Ensure directory exists
        Path(csv_path).parent.mkdir(parents=True, exist_ok=True)

        # Write CSV
        with open(csv_path, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

        logger.info(f"Wrote {len(rows)} rows to {csv_path}")
    except Exception as e:
        logger.error(f"Error writing CSV {csv_path}: {e}")
        import traceback
        logger.error(traceback.format_exc())
        raise


def safe_write_csv(csv_path: str, rows: List[Dict], fieldnames: List[str]) -> Tuple[bool, str]:
    """
    Safely write CSV with automatic backup.

    Args:
        csv_path: Path to CSV file
        rows: List of row dicts
        fieldnames: Column names

    Returns:
        Tuple of (success: bool, message: str)
    """
    import shutil

    try:
        # Validate rows - ensure all values are serializable
        for row_idx, row in enumerate(rows):
            for key, value in row.items():
                if isinstance(value, (dict, list)):
                    error_msg = f"Row {row_idx}, field '{key}' contains {type(value).__name__} instead of string. Value: {value}"
                    logger.error(error_msg)
                    # Convert to JSON string if it's a dict or list
                    import json
                    rows[row_idx][key] = json.dumps(value)
                    logger.warning(f"Auto-converted field '{key}' to JSON string")

        # Create backup if file exists
        if os.path.exists(csv_path):
            backup_path = f"{csv_path}.bak"
            shutil.copy2(csv_path, backup_path)
            logger.info(f"Created backup: {backup_path}")

        # Write CSV - write_csv signature is (csv_path, rows, fieldnames)
        write_csv(csv_path, rows, fieldnames)

        return True, f"Successfully wrote {len(rows)} rows to {csv_path}"
    except Exception as e:
        error_msg = f"Error writing CSV: {str(e)}"
        logger.error(error_msg)
        import traceback
        logger.error(traceback.format_exc())
        return False, error_msg


# ==================== CSV PATH HELPERS ====================

def get_quiz_csv_path(course_id: int, quiz_id: int) -> str:
    """Get standard path for quiz CSV."""
    return f"data/course_{course_id}/quiz_{quiz_id}.csv"


def get_assignment_csv_path(course_id: int, assignment_id: int) -> str:
    """Get standard path for assignment CSV."""
    return f"data/course_{course_id}/assignment_{assignment_id}/parsed_submissions.csv"


# ==================== QUESTION OPERATIONS ====================

def list_questions_from_csv(csv_path: str) -> List[Dict]:
    """
    List all unique questions from CSV with metadata.
    Handles both quiz CSV (questions as columns) and assignment CSV (question_id column).

    Returns:
        List of question dicts with: id, text, type, points_possible, answer_count, graded_count
    """
    try:
        rows = read_csv(csv_path)
        if not rows:
            return []

        # Check if this is a quiz CSV (has columns like 'q1', 'q2') or assignment CSV (has 'question_id' column)
        first_row = rows[0] if rows else {}

        # Look for quiz-style columns (q1, q2, etc.)
        quiz_columns = [col for col in first_row.keys() if col.startswith('q') and col[1:].isdigit()]

        # Debug logging
        logger.debug(f"CSV columns found: {list(first_row.keys())[:20]}")  # Log first 20 columns
        logger.debug(f"Quiz columns detected: {quiz_columns}")

        if quiz_columns:
            # This is a quiz CSV - questions are columns
            questions_map = {}

            for qid in sorted(quiz_columns, key=lambda x: int(x[1:])):
                # Get question metadata from the first row (all rows have same question text)
                question_text_col = f"{qid}_text"
                question_type_col = f"{qid}_type"
                question_points_col = f"{qid}_points_possible"
                feedback_col = f"{qid}_feedback"
                points_col = f"{qid}_points"

                # Count unique students (deduplicate by student_id)
                unique_students = set()
                graded_students = set()

                for row in rows:
                    # Only count if this question has an answer
                    if qid in row and row[qid]:  # Has answer for this question
                        student_id = row.get('student_id', row.get('id', ''))
                        if student_id:
                            unique_students.add(student_id)

                            # Check if graded - check question-specific points column for quiz CSVs
                            # Quiz CSVs use columns like q1_points, q2_points etc.
                            points_col = f"{qid}_points"
                            points_value = row.get(points_col, '')

                            # Also check generic grade column as fallback
                            grade_value = row.get('grade', '')

                            # Consider graded if either points column or grade column has a value
                            if (points_value and str(points_value).strip()) or (grade_value and str(grade_value).strip()):
                                graded_students.add(student_id)

                questions_map[qid] = {
                    'id': qid,
                    'text': first_row.get(question_text_col, '') if question_text_col in first_row else f'Question {qid[1:]}',
                    'type': first_row.get(question_type_col, '') if question_type_col in first_row else '',
                    'points_possible': float(first_row.get(question_points_col, 1) or 1) if question_points_col in first_row else 1,
                    'answer_count': len(unique_students),  # Count unique students, not rows
                    'graded_count': len(graded_students),   # Count unique graded students
                }

            return list(questions_map.values())

        else:
            # This is an assignment CSV - has question_id column
            questions_map = {}

            for row in rows:
                qid = row.get('question_id', '')
                if not qid:
                    continue

                if qid not in questions_map:
                    questions_map[qid] = {
                        'id': qid,
                        'text': row.get('question_text', ''),
                        'type': row.get('question_type', ''),
                        'points_possible': float(row.get('points_possible', 0) or 0),
                        'answer_count': 0,
                        'graded_count': 0,
                        'unique_students': set(),  # Track unique students
                        'graded_students': set(),   # Track unique graded students
                    }

                # Count unique students (deduplicate by student_id)
                student_id = row.get('student_id', '')
                if student_id:
                    questions_map[qid]['unique_students'].add(student_id)

                    # Check if graded by looking for a non-empty 'llm' column
                    llm_model_name = row.get('llm', '')
                    if llm_model_name and llm_model_name.strip():
                        questions_map[qid]['graded_students'].add(student_id)

            # Convert sets to counts
            for qid in questions_map:
                questions_map[qid]['answer_count'] = len(questions_map[qid]['unique_students'])
                questions_map[qid]['graded_count'] = len(questions_map[qid]['graded_students'])
                # Remove the sets before returning
                del questions_map[qid]['unique_students']
                del questions_map[qid]['graded_students']

            return list(questions_map.values())

    except Exception as e:
        logger.error(f"Error listing questions from {csv_path}: {e}")
        return []


def get_sample_answers(csv_path: str, question_id: str, limit: int = 10) -> List[Dict]:
    """
    Get sample student answers for a question.
    Handles row-based CSV format (both quiz and assignment use question_id column).

    Returns:
        List of row dicts (student answers)
    """
    try:
        rows = read_csv(csv_path)
        if not rows:
            return []

        # Both quiz and assignment CSVs use row-based format with question_id column
        samples = [r for r in rows if r.get('question_id') == str(question_id)]
        return samples[:limit]

    except Exception as e:
        logger.error(f"Error getting sample answers: {e}")
        return []


def get_ungraded_rows(csv_path: str, question_id: str) -> List[Dict]:
    """
    Get all ungraded rows for a specific question.
    Handles row-based CSV format (both quiz and assignment use question_id column).

    Returns:
        List of ungraded row dicts
    """
    try:
        rows = read_csv(csv_path)
        if not rows:
            return []

        ungraded = []

        # Both quiz and assignment CSVs use row-based format with question_id column
        for row in rows:
            if row.get('question_id') != str(question_id):
                continue

            # Consider ungraded if no feedback AND no points_earned
            has_feedback = row.get('feedback') and row.get('feedback').strip()
            has_points = row.get('points_earned') and row.get('points_earned').strip()

            if not (has_feedback and has_points):
                ungraded.append(row)

        return ungraded

    except Exception as e:
        logger.error(f"Error getting ungraded rows: {e}")
        return []


# ==================== GRADING STATUS ====================

def get_grading_status(csv_path: str) -> Dict:
    """
    Analyze grading completion status of CSV.

    Returns:
        Dict with overall stats and per-question breakdown
    """
    try:
        rows = read_csv(csv_path)
        if not rows:
            return {
                'total_questions': 0,
                'total_answers': 0,
                'graded_answers': 0,
                'ungraded_answers': 0,
                'progress_percent': 0.0,
                'questions': []
            }

        # Count overall - consider graded if any grading-related column is non-empty
        total_answers = len(rows)

        # Check multiple possible grade columns
        def is_row_graded(row):
            # Check generic grade column
            if row.get('grade') and str(row.get('grade')).strip():
                return True
            # Check points_earned column
            if row.get('points_earned') and str(row.get('points_earned')).strip():
                return True
            # Check for quiz-style points columns (q1_points, q2_points, etc.)
            for key in row.keys():
                if '_points' in key and key.startswith('q'):
                    if row.get(key) and str(row.get(key)).strip():
                        return True
            return False

        graded_answers = sum(1 for r in rows if is_row_graded(r))

        # Per-question breakdown
        questions = list_questions_from_csv(csv_path)

        # Calculate progress
        progress_percent = (graded_answers / total_answers * 100) if total_answers > 0 else 0

        # Add progress_percent to each question
        for q in questions:
            if q['answer_count'] > 0:
                q['progress_percent'] = (q['graded_count'] / q['answer_count'] * 100)
            else:
                q['progress_percent'] = 0.0

        return {
            'total_questions': len(questions),
            'total_answers': total_answers,
            'graded_answers': graded_answers,
            'ungraded_answers': total_answers - graded_answers,
            'progress_percent': progress_percent,
            'questions': questions
        }

    except Exception as e:
        logger.error(f"Error analyzing grading status: {e}")
        return {
            'total_questions': 0,
            'total_answers': 0,
            'graded_answers': 0,
            'ungraded_answers': 0,
            'progress_percent': 0.0,
            'questions': []
        }


# ==================== UTILITY FUNCTIONS ====================

def safe_grade_to_float(grade_value, default=0.0):
    """
    Safely convert grade value to float with validation.

    Args:
        grade_value: The grade value to convert (can be string, float, int, None, or empty)
        default: Default value to return if conversion fails

    Returns:
        float: The converted grade value or default if conversion fails

    Examples:
        safe_grade_to_float("8.5") -> 8.5
        safe_grade_to_float("") -> 0.0
        safe_grade_to_float(None) -> 0.0
        safe_grade_to_float("invalid") -> 0.0 (with warning)
    """
    if grade_value in [None, '', ' ']:
        return default

    try:
        # Convert to string first to handle other types, then strip whitespace
        grade_str = str(grade_value).strip()
        if not grade_str:
            return default
        return float(grade_str)
    except (ValueError, TypeError) as e:
        logger.warning(f"Invalid grade value: '{grade_value}' (type: {type(grade_value).__name__}), using default: {default}")
        return default


# ==================== BACKWARD COMPATIBILITY ====================

# Aliases for existing code
safe_read_csv = read_csv
safe_write_csv_with_backup = safe_write_csv  # Use our safe_write_csv function
analyze_csv_grading_status = get_grading_status
list_questions_in_csv = list_questions_from_csv
get_sample_answers_from_csv = get_sample_answers
