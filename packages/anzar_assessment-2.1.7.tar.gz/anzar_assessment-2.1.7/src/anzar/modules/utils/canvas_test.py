from canvasapi import Canvas
from ..profile.profile_setter import read_canvas_config
from canvasapi.exceptions import CanvasException, InvalidAccessToken
import requests.exceptions

def test_canvas_connection(canvas_address=None, token=None):
    """
    Test connection to Canvas API using the canvasapi library.
    
    Args:
        canvas_address (str, optional): Canvas base URL. If None, reads from config.
        token (str, optional): Canvas API token. If None, reads from config.
    
    Returns:
        bool: True if connection successful, False otherwise
    """
    try:
        # If credentials not provided, read from config
        if canvas_address is None or token is None:
            print("Reading credentials from profiles.json...")
            canvas_address, token = read_canvas_config()
            
            if not canvas_address or not token:
                print("❌ Failed to read credentials from config file")
                return False
        
        # Ensure canvas_address has proper format
        if not canvas_address.startswith('http'):
            canvas_address = f"https://{canvas_address}"
        
        print(f"🔍 Testing connection to: {canvas_address}")
        print("📡 Initializing Canvas API client...")
        
        # Create Canvas instance
        canvas = Canvas(canvas_address, token)
        
        # Test connection by getting current user
        print("🔐 Authenticating user...")
        current_user = canvas.get_current_user()
        
        # If we get here, connection is successful
        print("✅ Connection successful!")
        print(f"📝 Connected as: {current_user.name}")
        
        return True
        
    except InvalidAccessToken:
        print("❌ Authentication failed - Invalid or expired token")
        return False
        
    except requests.exceptions.ConnectionError:
        print("❌ Connection error - Cannot reach Canvas server")
        return False
        
    except CanvasException as e:
        print(f"❌ Canvas API error: {e}")
        return False
        
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False

if __name__ == "__main__":
    print("🎨 Canvas Connection Tester")
    print("=" * 40)
    
    success = test_canvas_connection()
    
    print("\n" + "=" * 40)
    print("✨ Test complete!")