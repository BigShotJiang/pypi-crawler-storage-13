"""
Simplified file utilities - basic file operations only.
Removed: backups, file locking, encoding detection, permission checking
"""

import json
import os
import logging
from pathlib import Path
from typing import Tuple, Optional

# Import config-based data directory
try:
    from modules.config.app_config import get_data_dir as _get_config_data_dir
    _USE_CONFIG = True
except ImportError:
    # Fallback for development/testing
    _USE_CONFIG = False
    def _get_config_data_dir():
        return "data"

logger = logging.getLogger(__name__)


# ==================== DIRECTORY OPERATIONS ====================

def ensure_directory_exists(path: str) -> bool:
    """
    Ensure directory exists, create if needed.

    Args:
        path: Directory path

    Returns:
        True if directory exists or was created
    """
    try:
        Path(path).mkdir(parents=True, exist_ok=True)
        return True
    except Exception as e:
        logger.error(f"Failed to create directory {path}: {e}")
        return False


# ==================== JSON OPERATIONS ====================

def safe_read_json(json_path: str) -> Tuple[bool, any]:
    """
    Read JSON file.

    Returns:
        (success, data) or (False, error_message)
    """
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return True, data
    except FileNotFoundError:
        return False, f"File not found: {json_path}"
    except json.JSONDecodeError as e:
        return False, f"Invalid JSON: {e}"
    except Exception as e:
        return False, f"Error reading JSON: {e}"


def safe_write_json(json_path: str, data: any):
    """
    Write data to JSON file.

    Args:
        json_path: Path to JSON file
        data: Data to write
    """
    try:
        # Ensure directory exists
        Path(json_path).parent.mkdir(parents=True, exist_ok=True)

        # Write JSON
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

        logger.debug(f"Wrote JSON to {json_path}")
    except Exception as e:
        logger.error(f"Error writing JSON to {json_path}: {e}")
        raise


# ==================== FILE EXISTENCE ====================

def file_exists(path: str) -> bool:
    """Check if file exists."""
    return Path(path).exists()


# ==================== URL UTILITIES ====================

def normalize_canvas_url(url: str) -> str:
    """
    Normalize Canvas URL to always use HTTPS.

    Args:
        url: Canvas URL

    Returns:
        Normalized URL with HTTPS
    """
    if not url:
        return url

    url = url.strip()
    if url.startswith('http://'):
        url = url.replace('http://', 'https://', 1)
    elif not url.startswith('https://'):
        url = f'https://{url}'
    return url


# ==================== PATH HELPERS ====================

def get_data_dir() -> str:
    r"""
    Get data directory path from config.

    Returns user-configured data directory path (e.g., Documents\AnZar)
    or default 'data' folder for backward compatibility.
    """
    if _USE_CONFIG:
        return _get_config_data_dir()
    return "data"


def get_course_dir(course_id: int) -> str:
    """
    Get course directory path.

    Args:
        course_id: Canvas course ID

    Returns:
        Path to course data directory
    """
    data_dir = get_data_dir()
    return os.path.join(data_dir, f"course_{course_id}")


def get_assignment_dir(course_id: int, assignment_id: int) -> str:
    """
    Get assignment directory path.

    Args:
        course_id: Canvas course ID
        assignment_id: Canvas assignment ID

    Returns:
        Path to assignment data directory
    """
    data_dir = get_data_dir()
    return os.path.join(data_dir, f"course_{course_id}", f"assignment_{assignment_id}")


def resolve_csv_path(csv_path: str) -> str:
    """Resolve CSV path (for backward compat)."""
    return csv_path


def resolve_folder_path(folder_path: str) -> str:
    """Resolve folder path (for backward compat)."""
    return folder_path


def check_file_readable(file_path: str) -> tuple:
    """Check if file is readable (simplified)."""
    try:
        if not Path(file_path).exists():
            return False, f"File not found: {file_path}"
        with open(file_path, 'r') as f:
            f.read(1)
        return True, None
    except Exception as e:
        return False, str(e)


def check_file_writable(file_path: str) -> tuple:
    """Check if file can be written (simplified)."""
    try:
        # Ensure parent directory exists
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        return True, None
    except Exception as e:
        return False, str(e)


# ==================== QUESTION TYPE HELPERS ====================

def is_auto_gradable_question(question_type: str) -> bool:
    """
    Check if question type can be auto-graded.

    Args:
        question_type: Canvas question type

    Returns:
        True if auto-gradable
    """
    auto_gradable_types = {
        'multiple_choice_question',
        'true_false_question',
        'multiple_answers_question',
        'matching_question',
        'numerical_question',
        'calculated_question',
        'formula_question',
    }
    return question_type in auto_gradable_types


# ==================== BACKWARD COMPATIBILITY ====================

def safe_update_json_file(json_path: str, update_func, max_retries: int = 3) -> Tuple[bool, Optional[str]]:
    """
    Update JSON file with function (backward compatibility).
    Simplified - no file locking, just read-modify-write.

    Args:
        json_path: Path to JSON file
        update_func: Function that takes current data and returns updated data
        max_retries: Ignored (kept for compatibility)

    Returns:
        (success, error_message)
    """
    try:
        # Read current data
        success, data = safe_read_json(json_path)
        if not success:
            # File doesn't exist, start with empty dict
            data = {}

        # Apply update function
        updated_data = update_func(data)

        # Write back
        safe_write_json(json_path, updated_data)

        return True, None
    except Exception as e:
        error_msg = f"Error updating JSON file: {e}"
        logger.error(error_msg)
        return False, error_msg


# Deprecated backup managers - kept as no-ops for compatibility
class CSVBackupManager:
    """Deprecated - no-op for compatibility."""
    @staticmethod
    def create_backup(csv_path, reason="manual"):
        logger.debug(f"CSVBackupManager.create_backup called (no-op): {csv_path}")
        return None


class ProfileBackupManager:
    """Deprecated - no-op for compatibility."""
    @staticmethod
    def create_backup(profile_path, reason="auto"):
        logger.debug(f"ProfileBackupManager.create_backup called (no-op): {profile_path}")
        return None
