"""
Simplified HTML utilities - basic HTML to text conversion only.
Removed: LaTeX extraction, Canvas preprocessing, MathML handling
"""

import re
from html.parser import HTMLParser
from html import unescape
import logging

logger = logging.getLogger(__name__)


class SimpleHTMLParser(HTMLParser):
    """
    Simple HTML to text converter.
    Preserves basic structure (paragraphs, lists, line breaks).
    """

    def __init__(self):
        super().__init__()
        self.text_parts = []
        self.current_text = []
        self.in_pre = False
        self.list_depth = 0

    def handle_starttag(self, tag, attrs):
        """Handle opening tags."""
        if tag in ['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
            self._flush_text()
        elif tag == 'br':
            self.current_text.append('\n')
        elif tag == 'pre':
            self._flush_text()
            self.in_pre = True
        elif tag in ['ul', 'ol']:
            self._flush_text()
            self.list_depth += 1
        elif tag == 'li':
            self._flush_text()
            self.current_text.append('  ' * (self.list_depth - 1) + '• ')
        elif tag == 'img':
            # Extract alt text from images
            attrs_dict = dict(attrs)
            alt = attrs_dict.get('alt', '')
            if alt:
                self.current_text.append(f'[Image: {alt}]')
            else:
                self.current_text.append('[Image]')

    def handle_endtag(self, tag):
        """Handle closing tags."""
        if tag in ['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
            self._flush_text()
        elif tag == 'pre':
            self._flush_text()
            self.in_pre = False
        elif tag in ['ul', 'ol']:
            self._flush_text()
            self.list_depth = max(0, self.list_depth - 1)
        elif tag == 'li':
            self.current_text.append('\n')

    def handle_data(self, data):
        """Handle text content."""
        if data.strip() or self.in_pre:
            self.current_text.append(data)

    def _flush_text(self):
        """Flush accumulated text to output."""
        if self.current_text:
            text = ''.join(self.current_text)
            if self.in_pre:
                self.text_parts.append(text)
            else:
                # Normalize whitespace (except in <pre>)
                text = ' '.join(text.split())
            if text:
                self.text_parts.append(text)
            self.current_text = []

    def get_text(self):
        """Get final text output."""
        self._flush_text()
        return '\n\n'.join(self.text_parts)


def html_to_text(html_content: str) -> str:
    """
    Convert HTML to plain text.

    Args:
        html_content: HTML string

    Returns:
        Plain text string
    """
    if not html_content:
        return ""

    try:
        # Unescape HTML entities first
        html_content = unescape(html_content)

        # Parse HTML
        parser = SimpleHTMLParser()
        parser.feed(html_content)
        text = parser.get_text()

        # Clean up excessive blank lines
        text = re.sub(r'\n{3,}', '\n\n', text)

        return text.strip()

    except Exception as e:
        logger.error(f"Error converting HTML to text: {e}")
        # Fallback: strip all HTML tags
        text = re.sub(r'<[^>]+>', '', html_content)
        text = unescape(text)
        return text.strip()


def clean_text_encoding(text: str) -> str:
    """
    Fix common encoding issues in text, particularly from Canvas CSV exports.

    Args:
        text: Input text that may have encoding issues

    Returns:
        Cleaned text with proper character encoding
    """
    if not text or not isinstance(text, str):
        return text

    # Fix the most common issue: UTF-8 non-breaking spaces misinterpreted as ISO-8859-1
    # This causes Â\xa0 (Â followed by non-breaking space) to appear
    text = text.replace('Â\xa0', '\u00A0')  # Replace with proper Unicode non-breaking space
    text = text.replace('\u00A0', ' ')     # Convert non-breaking spaces to regular spaces

    # Fix other common encoding issues
    # Smart quotes that get mangled
    text = text.replace('â€œ', '"')   # Left double quote
    text = text.replace('â€', '"')   # Right double quote
    text = text.replace('â€˜', "'")   # Left single quote
    text = text.replace('â€™', "'")   # Right single quote
    text = text.replace('â€¦', '...') # Ellipsis

    # Em dashes and en dashes
    text = text.replace('â€”', '—')   # Em dash
    text = text.replace('â€“', '–')   # En dash

    # Other common Windows-1252 to UTF-8 issues
    text = text.replace('â‚¬', '€')   # Euro sign

    # Normalize whitespace
    text = ' '.join(text.split())  # Normalize multiple spaces to single space

    return text.strip()


def clean_csv_text(text: str) -> str:
    """
    Clean text specifically for CSV fields.
    Handles encoding issues and CSV-specific formatting.

    Args:
        text: Text from CSV field

    Returns:
        Cleaned text safe for CSV processing
    """
    if not text or not isinstance(text, str):
        return text

    # First fix encoding issues
    text = clean_text_encoding(text)

    # Handle CSV-specific issues
    # Remove or normalize problematic characters for CSV
    # Keep newlines within quotes but normalize line endings
    text = text.replace('\r\n', '\n')  # Windows to Unix line endings
    text = text.replace('\r', '\n')    # Old Mac line endings

    # Remove control characters except newlines and tabs
    import re
    text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', text)

    return text


# Alias for backward compatibility
prepare_for_llm = html_to_text
