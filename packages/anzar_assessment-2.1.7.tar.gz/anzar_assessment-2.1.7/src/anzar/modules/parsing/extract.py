"""
Simplified text extraction from submissions - supports all formats including PDF metadata.
Consolidates text_extractor.py and pdf_metadata_parser.py functionality.
"""

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ==================== PDF EXTRACTION ====================

def extract_pdf_metadata(pdf_path: str) -> Optional[Dict]:
    """
    Extract JSON metadata from PDF Keywords field.

    Returns:
        Dict with student info and questions, or None if no metadata
    """
    try:
        import PyPDF2

        with open(pdf_path, 'rb') as file:
            pdf = PyPDF2.PdfReader(file)

            if pdf.metadata and '/Keywords' in pdf.metadata:
                keywords = pdf.metadata['/Keywords']
                try:
                    metadata = json.loads(keywords)
                    return metadata
                except json.JSONDecodeError:
                    return None
            return None

    except Exception as e:
        logger.debug(f"Error reading PDF metadata from {pdf_path}: {e}")
        return None


def extract_text_from_pdf(pdf_path: str) -> str:
    """Extract text from PDF file."""
    try:
        import pdfplumber

        text = ""
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n\n"

        return text.strip()

    except ImportError:
        # Fallback to PyPDF2
        try:
            import PyPDF2
            text = ""
            with open(pdf_path, 'rb') as file:
                pdf = PyPDF2.PdfReader(file)
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n\n"
            return text.strip()
        except Exception as e:
            logger.error(f"Error extracting PDF text: {e}")
            return ""

    except Exception as e:
        logger.error(f"Error extracting PDF text: {e}")
        return ""


# ==================== DOCX EXTRACTION ====================

def extract_text_from_docx(docx_path: str) -> str:
    """Extract text from DOCX file."""
    try:
        from docx import Document

        doc = Document(docx_path)
        text = "\n\n".join([para.text for para in doc.paragraphs if para.text.strip()])
        return text

    except Exception as e:
        logger.error(f"Error extracting DOCX text: {e}")
        return ""


# ==================== TEXT FILE EXTRACTION ====================

def extract_text_from_txt(txt_path: str) -> str:
    """Extract text from plain text file."""
    try:
        with open(txt_path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    except Exception as e:
        logger.error(f"Error reading text file: {e}")
        return ""


# ==================== ZIP EXTRACTION ====================

def extract_text_from_zip(zip_path: str) -> str:
    """Extract and concatenate text from all files in ZIP."""
    import zipfile

    try:
        text = ""
        with zipfile.ZipFile(zip_path, 'r') as zip_file:
            for file_name in zip_file.namelist():
                # Skip directories and hidden files
                if file_name.endswith('/') or file_name.startswith('__MACOSX'):
                    continue

                try:
                    content = zip_file.read(file_name)
                    # Try to decode as text
                    text += f"\n\n{'='*60}\nFile: {file_name}\n{'='*60}\n\n"
                    text += content.decode('utf-8', errors='ignore')
                except:
                    continue

        return text

    except Exception as e:
        logger.error(f"Error extracting ZIP: {e}")
        return ""


# ==================== AUTO-DETECT FORMAT ====================

def extract_text_from_file(file_path: str) -> str:
    """
    Auto-detect format and extract text.

    Args:
        file_path: Path to file

    Returns:
        Extracted text
    """
    path = Path(file_path)
    suffix = path.suffix.lower()

    if suffix == '.pdf':
        return extract_text_from_pdf(file_path)
    elif suffix in ['.docx', '.doc']:
        return extract_text_from_docx(file_path)
    elif suffix in ['.txt', '.md', '.rtf']:
        return extract_text_from_txt(file_path)
    elif suffix == '.zip':
        return extract_text_from_zip(file_path)
    elif suffix in ['.py', '.java', '.cpp', '.c', '.js', '.sql', '.r', '.m']:
        return extract_text_from_txt(file_path)  # Code files are text
    else:
        # Try as text
        return extract_text_from_txt(file_path)


def extract_text_from_folder(folder_path: str) -> str:
    """
    Extract text from all files in a folder.

    Args:
        folder_path: Path to folder

    Returns:
        Concatenated text from all files
    """
    folder = Path(folder_path)
    files = [f for f in folder.iterdir() if f.is_file()]

    if not files:
        return ""

    # Priority order: PDF > DOCX > TXT > others
    pdf_files = [f for f in files if f.suffix.lower() == '.pdf']
    if pdf_files:
        return extract_text_from_file(str(pdf_files[0]))

    docx_files = [f for f in files if f.suffix.lower() in ['.docx', '.doc']]
    if docx_files:
        return extract_text_from_file(str(docx_files[0]))

    txt_files = [f for f in files if f.suffix.lower() in ['.txt', '.md', '.rtf']]
    if txt_files:
        return extract_text_from_file(str(txt_files[0]))

    # Try all files and concatenate
    all_text = ""
    for file in files:
        text = extract_text_from_file(str(file))
        if text:
            all_text += f"\n\n{'='*60}\nFile: {file.name}\n{'='*60}\n\n{text}"

    return all_text


# ==================== PDF METADATA PARSING (TEMPLATE-BASED) ====================

def parse_pdf_with_metadata(pdf_path: str, student_info: Dict) -> List[Dict]:
    """
    Parse PDF with embedded metadata (template-based submissions).

    Args:
        pdf_path: Path to PDF file
        student_info: Dict with student id, name, email

    Returns:
        List of row dicts for CSV
    """
    metadata = extract_pdf_metadata(pdf_path)

    if not metadata or 'questions' not in metadata:
        return []

    rows = []
    questions = metadata.get('questions', [])

    for q in questions:
        row = {
            'student_id': student_info.get('id', ''),
            'student_name': student_info.get('name', ''),
            'student_email': student_info.get('email', ''),
            'assignment_id': '',  # Set by caller
            'question_id': str(q.get('questionNumber', '')),
            'question_text': q.get('questionText', ''),
            'student_answer': q.get('answerText', ''),
            'submission_folder': student_info.get('folder', ''),
            'points_possible': '',
            'points_earned': '',
            'grade': '',
            'feedback': '',
            'llm': '',
        }
        rows.append(row)

    return rows


# ==================== ASSIGNMENT PARSING ====================

def parse_assignment_to_csv(assignment_folder: str, questions: Optional[List[Dict]] = None) -> List[Dict]:
    """
    Parse assignment submissions to CSV format.
    Tries PDF metadata first (auto-extracts questions), falls back to text extraction with provided questions.

    Args:
        assignment_folder: Path to assignment folder
        questions: Optional list of question dicts with id, text, points (required for non-metadata PDFs)

    Returns:
        List of row dicts ready for CSV
    """
    folder = Path(assignment_folder)

    # Load student mapping
    mapping_file = folder / 'canvas_student_mapping.json'
    if not mapping_file.exists():
        logger.error("No canvas_student_mapping.json found")
        return []

    with open(mapping_file, 'r') as f:
        student_mapping = json.load(f)

    rows = []
    students_with_metadata = 0
    students_without_metadata = 0

    # Parse each student
    for student_id, student_info in student_mapping.items():
        student_folder = Path(student_info['folder'])

        if not student_folder.exists():
            continue

        # Try PDF metadata parsing first
        pdf_files = list(student_folder.glob('*.pdf'))
        if pdf_files:
            metadata_rows = parse_pdf_with_metadata(str(pdf_files[0]), student_info)
            if metadata_rows:
                # Has metadata - use it (questions auto-extracted)
                students_with_metadata += 1
                for row in metadata_rows:
                    row['assignment_id'] = str(folder.name.split('_')[-1])
                rows.extend(metadata_rows)
                continue

        # No metadata - need questions list
        students_without_metadata += 1

        if not questions:
            logger.warning(f"Student {student_id} has no metadata and no questions list provided - skipping")
            continue

        # Fallback: extract full text and create rows for each question
        text = extract_text_from_folder(str(student_folder))

        if not text:
            logger.warning(f"No text extracted for student {student_id}")
            continue

        # Create row for each question
        for question in questions:
            row = {
                'student_id': student_id,
                'student_name': student_info.get('name', ''),
                'student_email': student_info.get('email', ''),
                'assignment_id': str(folder.name.split('_')[-1]),
                'question_id': question.get('id', ''),
                'question_text': question.get('text', ''),
                'student_answer': text,  # Full text - LLM will extract relevant part
                'submission_folder': str(student_folder),
                'points_possible': str(question.get('points', 0)),
                'points_earned': '',
                'grade': '',
                'feedback': '',
                'llm': '',
            }
            rows.append(row)

    logger.info(f"Parsed: {students_with_metadata} with metadata, {students_without_metadata} without metadata")
    return rows


# ==================== SUBMISSION ANALYSIS ====================

def analyze_submission_folder(assignment_folder: str) -> Dict:
    """
    Analyze submissions to determine file types and parseability.

    Args:
        assignment_folder: Path to assignment folder

    Returns:
        Dict with analysis results
    """
    folder = Path(assignment_folder)

    # Load student mapping
    mapping_file = folder / 'canvas_student_mapping.json'
    if not mapping_file.exists():
        return {
            'total_students': 0,
            'has_pdf': 0,
            'has_pdf_metadata': 0,
            'has_docx': 0,
            'has_txt': 0,
            'has_zip': 0,
            'has_other': 0,
            'percent_metadata': 0,
        }

    with open(mapping_file, 'r') as f:
        student_mapping = json.load(f)

    total = len(student_mapping)
    counts = {
        'has_pdf': 0,
        'has_pdf_metadata': 0,
        'has_docx': 0,
        'has_txt': 0,
        'has_zip': 0,
        'has_other': 0,
    }

    # Analyze each student's files
    for student_info in student_mapping.values():
        student_folder = Path(student_info['folder'])

        if not student_folder.exists():
            continue

        files = list(student_folder.glob('*'))

        # Count file types
        has_pdf = any(f.suffix.lower() == '.pdf' for f in files)
        has_docx = any(f.suffix.lower() in ['.docx', '.doc'] for f in files)
        has_txt = any(f.suffix.lower() in ['.txt', '.md', '.rtf'] for f in files)
        has_zip = any(f.suffix.lower() == '.zip' for f in files)

        if has_pdf:
            counts['has_pdf'] += 1
            # Check if PDF has metadata
            pdf_files = [f for f in files if f.suffix.lower() == '.pdf']
            if pdf_files:
                metadata = extract_pdf_metadata(str(pdf_files[0]))
                if metadata:
                    counts['has_pdf_metadata'] += 1

        if has_docx:
            counts['has_docx'] += 1
        if has_txt:
            counts['has_txt'] += 1
        if has_zip:
            counts['has_zip'] += 1

        # Check for other formats
        known_extensions = {'.pdf', '.docx', '.doc', '.txt', '.md', '.rtf', '.zip'}
        has_other = any(f.suffix.lower() not in known_extensions for f in files if f.is_file())
        if has_other:
            counts['has_other'] += 1

    # Calculate percentage with metadata
    percent_metadata = (counts['has_pdf_metadata'] / total * 100) if total > 0 else 0

    return {
        'total_students': total,
        'total_submissions': total,  # Frontend alias
        'has_pdf': counts['has_pdf'],
        'has_pdf_metadata': counts['has_pdf_metadata'],
        'parseable_pdfs': counts['has_pdf_metadata'],  # Frontend alias
        'legacy_pdfs': counts['has_pdf'] - counts['has_pdf_metadata'],  # Non-metadata PDFs
        'non_pdf_files': counts['has_docx'] + counts['has_txt'] + counts['has_zip'] + counts['has_other'],
        'has_docx': counts['has_docx'],
        'has_txt': counts['has_txt'],
        'has_zip': counts['has_zip'],
        'has_other': counts['has_other'],
        'percent_metadata': percent_metadata,
        'parseable_percentage': percent_metadata,  # Frontend alias
    }


def get_parsing_recommendation(assignment_folder: str) -> Dict:
    """
    Get parsing strategy recommendation based on file analysis.

    Returns:
        Dict with recommended_strategy and reasoning
    """
    analysis = analyze_submission_folder(assignment_folder)

    percent_metadata = analysis.get('percent_metadata', 0)

    if percent_metadata >= 80:
        return {
            'recommended_strategy': 'metadata',
            'confidence': 'high',
            'reasoning': f'{percent_metadata:.0f}% of submissions have PDF metadata - fast template-based parsing recommended',
            'analysis': analysis
        }
    elif percent_metadata >= 50:
        return {
            'recommended_strategy': 'metadata',
            'confidence': 'medium',
            'reasoning': f'{percent_metadata:.0f}% have PDF metadata - template parsing with some manual handling',
            'analysis': analysis
        }
    else:
        return {
            'recommended_strategy': 'agent',  # Frontend expects 'agent' not 'text_extraction'
            'confidence': 'medium',
            'reasoning': f'Only {percent_metadata:.0f}% have PDF metadata - AI agent grading recommended',
            'analysis': analysis
        }

