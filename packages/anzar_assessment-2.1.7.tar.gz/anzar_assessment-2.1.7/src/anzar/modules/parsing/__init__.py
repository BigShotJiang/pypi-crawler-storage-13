"""
Parsing module - simplified text extraction from submissions.
Supports PDF (with metadata), DOCX, TXT, ZIP, and code files.
"""

from .extract import (
    extract_text_from_pdf,
    extract_text_from_docx,
    extract_text_from_txt,
    extract_text_from_file,
    extract_text_from_folder,
    extract_pdf_metadata,
    parse_pdf_with_metadata,
    parse_assignment_to_csv,
    analyze_submission_folder,
    get_parsing_recommendation,
)

__all__ = [
    'extract_text_from_pdf',
    'extract_text_from_docx',
    'extract_text_from_txt',
    'extract_text_from_file',
    'extract_text_from_folder',
    'extract_pdf_metadata',
    'parse_pdf_with_metadata',
    'parse_assignment_to_csv',
    'analyze_submission_folder',
    'get_parsing_recommendation',
]
