"""
AnZar - AI-Powered Canvas LMS Grading Assistant

A desktop application for educators to streamline grading with AI assistance.
"""

__version__ = "2.1.0"
__author__ = "AnZar Development Team"
__license__ = "Proprietary"

# Import main app class for programmatic access
try:
    from anzar.app import CanvasGradingApp, main
    __all__ = ["CanvasGradingApp", "main", "__version__", "__author__"]
except ImportError:
    # During build or if dependencies not yet installed
    __all__ = ["__version__", "__author__"]
