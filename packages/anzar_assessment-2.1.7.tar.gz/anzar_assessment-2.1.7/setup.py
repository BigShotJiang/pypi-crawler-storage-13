"""
Setup script for AnZar with Cython compilation for code protection.

This setup.py configures Cython compilation for core business logic modules
while keeping PyWebView-dependent code as plain Python.
"""

import os
from pathlib import Path
from setuptools import setup, Extension

# Try to import Cython, but make it optional
try:
    from Cython.Build import cythonize
    CYTHON_AVAILABLE = True
except ImportError:
    CYTHON_AVAILABLE = False
    print("Cython not available, installing without compiled extensions")

# Determine if we're building with Cython or just installing editable
BUILD_CYTHON = os.environ.get('ANZAR_BUILD_CYTHON', '1') == '1'

# Modules to compile with Cython (core IP protection)
CYTHON_MODULES = [
    # Grading modules (LLM integration, grading logic)
    'src/anzar/modules/grading/llm_grade.py',
    'src/anzar/modules/grading/rubric.py',

    # Canvas integration
    'src/anzar/modules/canvas/api.py',
    'src/anzar/modules/canvas/courses.py',
    'src/anzar/modules/canvas/quiz.py',
    'src/anzar/modules/canvas/assignment.py',

    # Rubric management
    'src/anzar/modules/rubric/rubric_management.py',

    # Assignment processing
    'src/anzar/modules/assignment/extract.py',
    'src/anzar/modules/assignment/parse.py',

    # Parsing
    'src/anzar/modules/parsing/extract.py',
    'src/anzar/modules/parsing/parse.py',

    # Consistency engine
    'src/anzar/modules/consistency/consistency_engine.py',
]

# Modules to keep as plain Python (required for PyWebView or simple utilities)
KEEP_PYTHON = [
    'src/anzar/app.py',          # PyWebView GUI - must stay as .py
    'src/anzar/state.py',        # Simple state management
    'src/anzar/modules/config/',  # Config management - ok to expose
    'src/anzar/modules/utils/',   # Utilities - ok to expose
    'src/anzar/modules/profile/', # Profile management - ok to expose
]


def build_extensions():
    """Build Cython extensions for code protection."""
    if not BUILD_CYTHON:
        print("Skipping Cython compilation (editable install or ANZAR_BUILD_CYTHON=0)")
        return []

    if not CYTHON_AVAILABLE:
        print("Cython not available, skipping compilation")
        return []

    extensions = []

    for module_path in CYTHON_MODULES:
        if not Path(module_path).exists():
            print(f"Warning: Module not found, skipping: {module_path}")
            continue

        # Convert path to module name
        # src/anzar/modules/grading/llm_grade.py -> anzar.modules.grading.llm_grade
        module_name = module_path.replace('src/', '').replace('.py', '').replace('/', '.')

        extensions.append(
            Extension(
                module_name,
                [module_path],
                # Compiler directives
                extra_compile_args=[],
                extra_link_args=[],
            )
        )

    if not extensions:
        print("No Cython modules found to compile")
        return []

    print(f"Compiling {len(extensions)} modules with Cython for code protection:")
    for ext in extensions:
        print(f"  - {ext.name}")

    # Cythonize with optimization
    return cythonize(
        extensions,
        compiler_directives={
            'language_level': "3",
            'embedsignature': True,
            'boundscheck': False,       # Disable bounds checking for performance
            'wraparound': False,         # Disable negative indexing for performance
            'initializedcheck': False,   # Disable initialization checks for performance
        },
        build_dir="build",
        annotate=False,  # Set True to generate .html annotation files
    )


# Run setup with conditional Cython compilation
setup(
    ext_modules=build_extensions(),
)
