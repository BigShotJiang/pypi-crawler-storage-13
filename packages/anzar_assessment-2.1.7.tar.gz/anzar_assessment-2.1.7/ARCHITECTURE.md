# AnZar Architecture Documentation

**Version:** 2.1.0
**Last Updated:** 2025-11-17
**Status:** Post Phase 7 API Refactoring - Architecture Audit Completed

---

## Audit Summary (2025-11-17)

**Major Corrections Applied:**

### Line Count Corrections:
- **Total application**: 128 files → **116 files** (38,220 lines vs. documented 22,549)
- **Modules**: 38 files (8,235 lines) → **28 files** (8,405 lines, excluding __init__.py)
- **APIs**: 10 files (3,814 lines) → **11 files** (4,247 lines, including new criteria_api.py)
- **Frontend JS**: 40 files (~6,000 lines) → **39 files** (12,255 lines)
- **Frontend HTML**: 40 files (~4,500 lines) → **38 files** (13,313 lines)

### Key Findings:
1. ✅ **AssignmentAPI now inherits from BaseContentAPI** (was documented as TODO)
2. ✅ **CriteriaAPI exists** (89 lines) - was completely missing from documentation
3. ✅ **All 28 module files verified** to exist
4. ✅ **Significant line count discrepancies** corrected throughout document
5. ✅ **QuizAPI methods**: Documented 5 methods → **Actually 11 specific methods** + 5 inherited (grade_question & grade_question_with_criteria ARE implemented, not TODO)
6. ✅ **AssignmentAPI methods**: Documented ~47 methods → **Actually 32 methods** (removed deprecated/non-existent methods)

### Updated Sections:
- Module layer line counts (all files)
- API layer line counts (all files)
- **API method inventories** (QuizAPI, AssignmentAPI)
- Code distribution statistics
- Module complexity table
- API size distribution table
- File organization tree
- Frontend file counts
- API → Frontend usage matrix
- **NEW: Complete API-to-Frontend Method Mapping** (65+ methods mapped to their JS callers)
  - Every API method documented with which JS files use it
  - Usage statistics: 58+ actively used, 7 unused/indirect
  - Top 10 most-called methods identified

---

## Table of Contents

1. [Overview](#overview)
2. [Module Layer](#module-layer)
3. [API Layer](#api-layer)
4. [Frontend Layer](#frontend-layer)
5. [Dependency Matrix](#dependency-matrix)
6. [Architecture Diagrams](#architecture-diagrams)

---

## Overview

AnZar is a Canvas LMS grading assistant built with:
- **Backend:** Python modules organized by domain
- **API Layer:** PyWebView API classes exposing methods to frontend
- **Frontend:** Alpine.js components consuming API methods

**Architecture Pattern:** 3-Tier
```
Frontend (Alpine.js) → API Layer (PyWebView) → Module Layer (Business Logic)
```

**Total Code:**
- **Modules:** 28 Python files across 8 domains (8,405 lines, excluding __init__.py)
- **APIs:** 10 API classes (+ 1 base class) (4,247 lines total)
- **Frontend:** 39 JavaScript files (12,255 lines), 38 HTML templates (13,313 lines)

**Total Application:** 116 files (excluding __init__.py), ~38,220 lines of code

---

## Module Layer

### modules/canvas/ - Canvas LMS Integration

#### **courses.py** (77 lines - ACTUAL)
**Purpose:** Course management and retrieval from Canvas

**Functions:**
- `get_courses() -> List[Dict]`
  - Fetches all courses from Canvas for current user
  - Returns: List of course dicts with id, name, course_code
  - Uses: canvasapi library
  - **Used by:** CourseAPI.get_list()

---

#### **quizzes.py** (531 lines - ACTUAL)
**Purpose:** Quiz management and submission downloading

**Functions:**
- `list_quizzes(course_id: int) -> List[Dict]`
  - Lists all quizzes in a course
  - Returns: List of quiz dicts with id, title, question_count
  - **Used by:** QuizAPI.get_list()

- `download_quiz_submissions(course_id: int, quiz_id: int) -> str`
  - Downloads quiz submissions to CSV
  - Returns: CSV file path or None
  - Creates: `data/course_{id}/quiz_{id}_submissions.csv`
  - **Used by:** QuizAPI.download_submissions()

---

#### **assignments.py** (460 lines - ACTUAL)
**Purpose:** Assignment management and submission downloading

**Functions:**
- `list_assignments(course_id: int) -> List[Dict]`
  - Lists all assignments in a course
  - Returns: List of assignment dicts with id, name, points_possible
  - **Used by:** AssignmentAPI.get_list()

- `download_assignment_submissions(course_id: int, assignment_id: int, force_download: bool = False) -> Dict`
  - Downloads assignment submissions to folder structure
  - Returns: {success, folder_path, assignment_exists}
  - Creates: `data/course_{id}/assignment_{id}/user_{student_id}/`
  - **Used by:** AssignmentAPI.download_submissions()

---

### modules/grading/ - Grading Operations

#### **auto_grade.py** (171 lines)
**Purpose:** Automatic grading for objective questions

**Functions:**
- `is_auto_gradable(question_type: str) -> bool`
  - Checks if question type can be auto-graded
  - Supported types: multiple_choice_question, true_false_question, numerical_question
  - **Used by:** BaseContentAPI._is_auto_gradable_question()

- `normalize_answer(answer: str) -> str`
  - Normalizes student answer for comparison
  - Strips whitespace, lowercases, removes punctuation
  - **Used by:** auto_grade_question()

- `parse_answer_choices(answer_choices: str) -> Dict[str, str]`
  - Parses answer choices string into dict
  - Format: "answer_123\tCorrect Answer\nanswer_456\tWrong Answer"
  - **Used by:** auto_grade_question()

- `auto_grade_question(question_type, student_answer, correct_answer, points_possible, answer_choices='') -> Dict`
  - Automatically grades objective questions
  - Returns: {success, points, feedback}
  - **Used by:** Grading workflows (not directly by APIs yet)

---

#### **llm_grade.py** (533 lines - ACTUAL)
**Purpose:** LLM-based grading for subjective questions

**Functions:**
- `create_grading_prompt(question_text, student_answer, criteria, image_paths=None) -> str`
  - Creates prompt for LLM grading
  - Includes rubric criteria, partial credit guidelines
  - **Used by:** grade_with_llm()

- `call_llm_api(prompt, llm_config, timeout=30) -> Tuple[bool, str]`
  - Makes API call to OpenAI/Anthropic/local LLM
  - Handles different API formats
  - Returns: (success, response_text)
  - **Used by:** grade_with_llm()

- `parse_llm_response(response_text) -> Dict`
  - Parses LLM response to extract points and feedback
  - Handles JSON and plain text responses
  - **Used by:** grade_with_llm()

- `grade_with_llm(question_text, student_answer, criteria, llm_config=None, image_paths=None, timeout=30) -> Dict`
  - Main LLM grading function
  - Returns: {success, points, feedback, raw_response}
  - **Used by:** Assignment/Quiz grading workflows

- `save_grading_results_to_csv(csv_path, grading_results) -> Tuple[bool, str]`
  - Saves grading results to CSV
  - Updates grade and feedback columns
  - **Used by:** BaseContentAPI._save_grading_results_to_csv()

---

#### **upload.py** (419 lines - ACTUAL)
**Purpose:** Upload grades to Canvas with rubric support

**Functions:**
- `read_graded_csv(csv_path: str) -> Dict`
  - Reads graded CSV and groups by student
  - Returns: {student_id: {student_name, questions: [], total_score}}
  - **Used by:** send_grades_to_canvas()

- `send_grades_to_canvas(csv_path, course_id, content_id, is_quiz=True, target_assignment_id=None, skip_confirmation=False) -> Tuple[bool, str]`
  - Sends grades from CSV to Canvas
  - Handles both quiz and assignment uploads
  - Creates/validates rubrics for assignments
  - Returns: (success, message)
  - **Used by:** BaseContentAPI._upload_grades_base(), UtilsAPI.send_grades_to_canvas()

- `send_quiz_grades(course_id, quiz_id, graded_students) -> Tuple[int, int, str]`
  - Uploads quiz grades via Canvas API
  - Returns: (success_count, fail_count, message)
  - **Used by:** send_grades_to_canvas()

- `send_assignment_grades(course_id, assignment_id, graded_students) -> Tuple[int, int, str]`
  - Uploads assignment grades with rubric assessments
  - Returns: (success_count, fail_count, message)
  - **Used by:** send_grades_to_canvas()

---

### modules/parsing/ - Assignment Parsing

#### **extract.py** (461 lines)
**Purpose:** Extract student submissions to structured CSV

**Functions:**
- `parse_assignment_to_csv(assignment_folder: str, questions: Optional[List[Dict]] = None) -> List[Dict]`
  - Parses assignment folder into structured data
  - Extracts text from PDFs, DOCX, TXT files
  - Returns: List of submission dicts
  - **Used by:** Assignment parsing workflows

- `analyze_submission_folder(folder_path: str) -> Dict`
  - Analyzes submission folder structure
  - Returns: {submissions: [], total_students, formats}
  - **Used by:** AssignmentAPI.get_submission_analysis()

---

### modules/profile/ - Profile Management

#### **profile_setter.py** (346 lines)
**Purpose:** Manage Canvas and LLM connection profiles

**Functions:**

**Canvas Profile Management:**
- `get_canvas_profiles() -> List[Dict]`
  - Returns all Canvas profiles
  - **Used by:** ProfileAPI._get_all_profiles('canvas')

- `get_active_canvas_profile() -> Dict`
  - Returns currently active Canvas profile
  - **Used by:** ProfileAPI.get_active(), ConnectionAPI.test_canvas()

- `create_canvas_profile(name, canvas_address, token, email='') -> Tuple[bool, str]`
  - Creates new Canvas profile with UUID
  - **Used by:** ProfileAPI._create_profile('canvas', ...)

- `update_canvas_profile(profile_id, name, canvas_address, token, email) -> Tuple[bool, str]`
  - Updates existing Canvas profile
  - **Used by:** ProfileAPI._update_profile('canvas', ...)

- `delete_canvas_profile(profile_id) -> Tuple[bool, str]`
  - Deletes Canvas profile
  - **Used by:** ProfileAPI._delete_profile('canvas', ...)

- `set_active_canvas_profile(profile_id) -> Tuple[bool, str]`
  - Sets active Canvas profile
  - **Used by:** ProfileAPI._switch_profile('canvas', ...)

**LLM Profile Management:**
- `get_llm_profiles() -> List[Dict]`
  - Returns all LLM profiles
  - **Used by:** ProfileAPI._get_all_profiles('llm')

- `get_active_llm_profile() -> Dict`
  - Returns currently active LLM profile
  - **Used by:** ProfileAPI.get_active(), ConnectionAPI.test_llm()

- `create_llm_profile(name, api_link, model_name, token, llm_type='remote') -> Tuple[bool, str]`
  - Creates new LLM profile with UUID
  - **Used by:** ProfileAPI._create_profile('llm', ...)

- `update_llm_profile(profile_id, name, api_link, model_name, token, llm_type) -> Tuple[bool, str]`
  - Updates existing LLM profile
  - **Used by:** ProfileAPI._update_profile('llm', ...)

- `delete_llm_profile(profile_id) -> Tuple[bool, str]`
  - Deletes LLM profile
  - **Used by:** ProfileAPI._delete_profile('llm', ...)

- `set_active_llm_profile(profile_id) -> Tuple[bool, str]`
  - Sets active LLM profile
  - **Used by:** ProfileAPI._switch_profile('llm', ...)

**Compatibility Functions:**
- `get_active_canvas_credentials() -> Tuple[bool, str, str, str]`
  - Returns: (success, canvas_url, token, email)
  - **Used by:** Canvas API calls throughout app

- `get_canvas_config() -> Tuple[str, str]`
  - Returns: (canvas_address, token)
  - Legacy compatibility function

- `get_llm_config() -> Dict`
  - Returns LLM config dict
  - **Used by:** LLM grading functions

---

### modules/rubric/ - Rubric Management

#### **rubric_management.py** (629 lines)
**Purpose:** Canvas rubric operations

**Functions:**
- `get_content_rubric(course_id, content_id, is_quiz=False) -> Dict`
  - Fetches rubric data from Canvas
  - Handles quizzes (via assignment_id) and assignments
  - Returns: {rubric, rubric_settings, points_possible} or None
  - **Used by:** RubricAPI.check_exists(), RubricAPI.create()

- `check_rubric_exists(course_id, assignment_id) -> bool`
  - Simple boolean check if rubric exists
  - **Used by:** (Deprecated - RubricAPI now uses get_content_rubric directly)

- `validate_rubric_matches_quiz(course_id, assignment_id, questions) -> bool`
  - Validates rubric criteria count and points match questions
  - **Used by:** RubricAPI.validate_match()

- `create_rubric(course_id, assignment_id, questions) -> Tuple[bool, str]`
  - Creates rubric via Canvas REST API
  - Creates 2 ratings per criterion: "Full Points" and "No Points"
  - **Used by:** RubricAPI.create()

- `analyze_csv_structure(csv_path) -> Dict`
  - Analyzes CSV to extract question structure
  - Returns: {questions, question_count, total_points}
  - **Used by:** Advanced rubric creation workflows

- `check_rubric_compatibility(rubric_data, csv_structure) -> Tuple[bool, str]`
  - Compares rubric vs CSV for mismatches
  - **Used by:** create_rubric_from_csv()

- `create_rubric_from_csv(course_id, content_id, csv_structure, is_quiz, force_delete) -> Tuple[bool, str]`
  - Advanced creation with compatibility checking
  - Preserves compatible existing rubrics
  - **Used by:** Advanced workflows (not in current API)

- `delete_existing_rubric(course_id, assignment_id) -> Tuple[bool, str]`
  - Deletes rubric via Canvas REST API
  - **Used by:** create_rubric_from_csv() internally

- `update_assignment_points(course_id, assignment_id, total_points) -> bool`
  - Updates assignment points_possible
  - **Used by:** create_rubric() internally

---

#### **rating_positioning.py** (183 lines)
**Purpose:** Advanced rubric rating calculations

**Functions:**
- `calculate_optimal_ratings(max_points, num_ratings=5) -> List[float]`
  - Calculates evenly distributed rating values
  - **Used by:** Advanced rubric creation

- `create_ratings_for_criterion(points, num_ratings=5) -> List[Dict]`
  - Creates rating objects for rubric criterion
  - **Used by:** Advanced rubric workflows

---

### modules/utils/ - Utility Functions

#### **canvas.py** (24 lines - ACTUAL)
**Purpose:** Canvas API utilities

**Functions:**
- `normalize_canvas_url(url: str) -> str`
  - Ensures Canvas URL has https:// and no trailing slash
  - **Used by:** Throughout codebase for URL validation

- `test_canvas_connection() -> bool`
  - Tests Canvas API connection
  - **Used by:** ConnectionAPI.test_canvas()

---

#### **csv_utils.py** (469 lines - ACTUAL)
**Purpose:** CSV file operations

**Functions:**
- `read_csv(csv_path: str) -> List[Dict]`
  - Reads CSV file into list of dicts
  - **Used by:** Throughout grading workflows

- `write_csv(csv_path: str, rows: List[Dict], fieldnames: List[str]) -> None`
  - Writes list of dicts to CSV
  - **Used by:** Throughout grading workflows

- `list_questions_from_csv(csv_path: str, include_points: bool = False) -> List[Dict]`
  - Extracts questions from CSV headers
  - Returns: List of {id, text, answer_count, points_possible, ...}
  - **Used by:** BaseContentAPI._get_questions_from_csv(), RubricAPI, throughout

- `get_grading_status(csv_path: str) -> Dict`
  - Analyzes CSV to determine grading progress
  - Returns: {total_students, graded_students, graded_questions, questions_status}
  - **Used by:** QuizAPI, AssignmentAPI, BaseContentAPI

- `get_sample_answers(csv_path: str, question_id: str, count: int = 5) -> List[Dict]`
  - Retrieves sample student answers for a question
  - Returns: List of {student_id, student_name, answer, grade, feedback}
  - **Used by:** BaseContentAPI._get_sample_answers_from_csv()

- `get_ungraded_rows(csv_path: str, question_id: str) -> Tuple[int, int, List[int]]`
  - Finds ungraded submissions for a question
  - Returns: (total, graded, ungraded_indices)
  - **Used by:** Grading workflows

---

#### **files.py** (230 lines - ACTUAL)
**Purpose:** File system operations

**Functions:**
- `get_quiz_csv_path(course_id: int, quiz_id: int) -> Path`
  - Returns expected path for quiz CSV
  - Path: `data/course_{course_id}/quiz_{quiz_id}_submissions.csv`
  - **Used by:** QuizAPI.check_csv(), QuizAPI.download_submissions()

- `get_assignment_dir(course_id: int, assignment_id: int) -> Path`
  - Returns expected path for assignment folder
  - Path: `data/course_{course_id}/assignment_{assignment_id}/`
  - **Used by:** AssignmentAPI.check_folder(), AssignmentAPI.load_existing_folder()

- `get_assignment_csv_path(course_id: int, assignment_id: int) -> Path`
  - Returns expected path for assignment CSV
  - Path: `data/course_{course_id}/assignment_{assignment_id}/graded_assignment.csv`
  - **Used by:** AssignmentAPI.check_parsed()

- `resolve_csv_path(csv_path: str) -> Tuple[bool, str, str]`
  - Validates and resolves CSV file path
  - Returns: (success, resolved_path, error_message)
  - **Used by:** QuizAPI.load_existing_csv()

---

#### **html.py** (193 lines - ACTUAL)
**Purpose:** HTML processing utilities

**Functions:**
- `clean_html(html: str) -> str`
  - Removes HTML tags and entities
  - **Used by:** Question text processing

- `extract_images_from_html(html: str) -> List[str]`
  - Extracts image URLs from HTML
  - **Used by:** Multimodal grading workflows

---

### modules/assignment/ - Assignment Processing

#### **unified_parser.py** (312 lines - ACTUAL)
**Purpose:** Unified parsing for all assignment formats

**Functions:**
- `parse_assignment_unified(assignment_folder, course_id, assignment_id, questions_list, force_parse=False, verbose=True) -> Tuple[bool, str, str]`
  - Parses assignments from any format (PDF, DOCX, TXT, ZIP)
  - Returns: (success, csv_path, message)
  - **Used by:** AssignmentAPI.parse_to_csv_unified()

- `get_questions_from_assignment(course_id, assignment_id) -> List[Dict]`
  - Extracts questions from Canvas assignment description or rubric
  - **Used by:** AssignmentAPI (for auto question extraction)

---

#### **assignment_parser_pdf_v2.py** (449 lines - ACTUAL)
**Purpose:** PDF metadata-based assignment parsing

**Functions:**
- `parse_assignment_folder_with_pdf_metadata_v2(assignment_folder, force_parse=False, verbose=True) -> Tuple[bool, str, str]`
  - Parses assignment PDFs using metadata
  - Extracts Canvas metadata from PDF properties
  - Returns: (success, csv_path, message)
  - **Used by:** AssignmentAPI.parse_to_csv_pdf()

- `analyze_submission_folder(folder_path: str) -> Dict`
  - Analyzes folder to determine file formats and parseability
  - Returns: {submissions: [], parseable_percentage, ...}
  - **Used by:** AssignmentAPI.get_submission_analysis()

---

#### **parser_factory.py** (160 lines)
**Purpose:** Smart parser selection

**Functions:**
- `get_parsing_recommendation(assignment_folder: str) -> Dict`
  - Analyzes folder and recommends parsing strategy
  - Returns: {strategy, confidence, analysis, description}
  - **Used by:** AssignmentAPI.get_parsing_recommendation()

- `parse_assignment(assignment_folder, questions_list, course_id, assignment_id, force_parse=False, verbose=True) -> Tuple[bool, str, str, Dict]`
  - Automatically selects and uses best parsing strategy
  - Returns: (success, csv_path, message, analysis)
  - **Used by:** AssignmentAPI.parse_auto()

---

#### **parsing_points_collector.py** (163 lines - ACTUAL)
**Purpose:** Question points management

**Functions:**
- `save_points_map(assignment_folder: str, points_map: Dict[str, int]) -> str`
  - Saves question points to JSON file
  - **Used by:** AssignmentAPI.save_points()

- `apply_points_to_csv(csv_rows: List[Dict], points_map: Dict[str, int]) -> List[Dict]`
  - Applies points mapping to CSV rows
  - **Used by:** AssignmentAPI.save_points()

- `load_points_map(assignment_folder: str) -> Dict[str, int]`
  - Loads saved points mapping
  - **Used by:** Parsing workflows

---

#### **parsing_summary.py** (269 lines - ACTUAL)
**Purpose:** Parsing operation summaries

**Functions:**
- `create_parsing_summary(assignment_folder, result_data) -> None`
  - Creates parsing_summary.json file
  - **Used by:** Parsing workflows

- `load_parsing_summary(assignment_folder) -> Dict`
  - Loads saved parsing summary
  - **Used by:** AssignmentAPI.get_parsing_summary()

---

#### **pdf_metadata_parser.py** (457 lines - ACTUAL)
**Purpose:** Extract metadata from Canvas-generated PDFs

**Functions:**
- `extract_pdf_metadata(pdf_path: str) -> Dict`
  - Extracts Canvas metadata from PDF properties
  - Returns: {student_id, student_name, assignment_id, submission_id}
  - **Used by:** parse_assignment_folder_with_pdf_metadata_v2()

- `parse_pdf_submission(pdf_path: str) -> str`
  - Extracts text content from PDF
  - **Used by:** PDF parsing workflows

---

#### **text_extractor.py** (374 lines)
**Purpose:** Extract text from various file formats

**Functions:**
- `extract_student_text(file_path: str, file_type: str) -> str`
  - Extracts text from PDF, DOCX, TXT files
  - **Used by:** Parsing workflows

---

#### **assignment.py** (108 lines - ACTUAL)
**Purpose:** Core assignment functionality and workflows

**Functions:**
- Assignment workflow management functions
- Integration with Canvas API for assignments
- **Used by:** AssignmentAPI core operations

---

#### **manual_mapping_interface.py** (215 lines)
**Purpose:** Manual student ID mapping interface

**Functions:**
- Interactive mapping of anonymous submissions to students
- GUI components for manual verification
- **Used by:** Assignment parsing workflows

---

#### **parsing_cleanup.py** (168 lines - ACTUAL)
**Purpose:** Clean up and validate parsed assignment data

**Functions:**
- Data validation and cleaning functions
- Error handling for parsing issues
- **Used by:** Assignment parsing workflows

---

#### **parsing_points_collector.py** (163 lines - DUPLICATE ENTRY, SEE LINE 473)
**Purpose:** Collect and manage question points

**Functions:**
- `save_points_map(assignment_folder: str, points_map: Dict[str, int]) -> str`
- `apply_points_to_csv(csv_rows: List[Dict], points_map: Dict[str, int]) -> List[Dict]`
- `load_points_map(assignment_folder: str) -> Dict[str, int]`
- **Used by:** AssignmentAPI.save_points()

---

#### **parsing_summary.py** (269 lines)
**Purpose:** Generate parsing operation summaries

**Functions:**
- `create_parsing_summary(assignment_folder, result_data) -> None`
- `load_parsing_summary(assignment_folder) -> Dict`
- **Used by:** AssignmentAPI.get_parsing_summary()

---

#### **strategies/agent_strategy.py** (73 lines)
**Purpose:** Agent-based parsing strategy

**Functions:**
- AI-powered parsing approach
- **Used by:** Parser factory for strategy selection

---

#### **strategies/metadata_strategy.py** (47 lines)
**Purpose:** Metadata-based parsing strategy

**Functions:**
- PDF metadata-driven parsing
- **Used by:** Parser factory for strategy selection

---

### modules/consistency/ - Grading Consistency Testing

#### **consistency_engine.py** (348 lines - ACTUAL)
**Purpose:** Test AI grading consistency

**Functions:**
- `run_consistency_test(assignment_folder, course_id, assignment_id, student_ids, num_runs, questions_list, question_filter=None) -> Dict`
  - Grades same students multiple times to test consistency
  - Returns: {success, results, statistics}
  - **Used by:** AssignmentAPI.start_consistency_test()

---

#### **data_access.py** (313 lines - ACTUAL)
**Purpose:** Data access for consistency testing

**Functions:**
- `get_student_submission_mapping(assignment_folder: str) -> Dict`
  - Maps student IDs to their submission files
  - **Used by:** AssignmentAPI.get_student_mapping()

- `count_submissions(assignment_folder: str) -> int`
  - Counts total submissions in folder
  - **Used by:** AssignmentAPI.get_submission_count()

---

## API Layer

### api/base_content_api.py - Shared Base Class

**Purpose:** Base class for QuizAPI and AssignmentAPI to eliminate duplication (365 lines - ACTUAL)

**Class:** `BaseContentAPI(state, window)`

**Shared Methods (5):**
- `_get_questions_from_csv() -> Dict`
  - Gets questions from CSV with grading status
  - Returns: {success, questions: []}
  - **Inherited by:** QuizAPI, AssignmentAPI

- `_get_sample_answers_from_csv(question_id, count=5) -> Dict`
  - Gets sample student answers
  - Returns: {success, samples: []}
  - **Inherited by:** QuizAPI, AssignmentAPI

- `_save_grading_results_to_csv(question_id, grading_results) -> Dict`
  - Saves grading results to CSV
  - Returns: {success, message}
  - **Inherited by:** QuizAPI, AssignmentAPI

- `_upload_grades_base(content_type, target_assignment_id=None) -> Dict`
  - Uploads grades to Canvas
  - Returns: {success, message}
  - **Inherited by:** QuizAPI.upload_grades(), AssignmentAPI.upload_grades()

- `_export_grades_base() -> Dict`
  - Exports grades to CSV file
  - Returns: {success, filename, path}
  - **Inherited by:** QuizAPI.export_grades(), AssignmentAPI.export_grades()

**Utility Methods (3):**
- `_is_auto_gradable_question(question_type) -> bool`
- `_error_response(message, details=None) -> Dict`
- `_success_response(**data) -> Dict`

**Module Dependencies:**
- modules.utils (list_questions_from_csv, get_sample_answers, get_grading_status, read_csv, write_csv)
- modules.grading (send_grades_to_canvas)

---

### api/course_api.py - Course Management (60 lines - ACTUAL, MATCHES)

**Class:** `CourseAPI(state, window)`

**Methods (2):**
- `get_list(force_refresh=False) -> Dict`
  - Gets all courses with optional caching
  - **Calls:** modules.canvas.get_courses()
  - **Used by:** courses.js, content_list.js, dashboard.js
  - Returns: {success, courses: [], count}

- `select(course_id, course_name) -> Dict`
  - Selects course and saves to state
  - **Calls:** state.set_course()
  - **Used by:** courses.js
  - Returns: {success, course_id, course_name}

**Module Dependencies:**
- modules.canvas.get_courses()

---

### api/quiz_api.py - Quiz Management (763 lines - ACTUAL)

**Class:** `QuizAPI(BaseContentAPI)` - Inherits from BaseContentAPI

**Quiz-Specific Methods (11):**
- `cancel_grading() -> Dict`
  - Cancel ongoing grading task
  - Returns: {success, message}

- `get_list() -> Dict`
  - Lists quizzes for current course
  - **Calls:** modules.canvas.list_quizzes()
  - **Used by:** quiz_list.js, content_list.js
  - Returns: {success, quizzes: []}

- `select(quiz_id, quiz_name) -> Dict`
  - Selects quiz and saves to state
  - **Calls:** state.set_content(), state.clear_content()
  - **Used by:** quiz_list.js
  - Returns: {success}

- `check_csv(quiz_id) -> Dict`
  - Checks if CSV exists for quiz
  - **Calls:** get_quiz_csv_path(), os.path.exists()
  - **Used by:** quiz_csv.js
  - Returns: {success, exists, path}

- `download_submissions(quiz_id, force_download=False) -> Dict`
  - Downloads quiz submissions from Canvas
  - **Calls:** modules.canvas.download_quiz_submissions(), list_questions_from_csv(), get_grading_status()
  - **Used by:** quiz_csv.js
  - Returns: {success, path, total_questions}

- `load_existing_csv(quiz_id) -> Dict`
  - Loads existing CSV without downloading
  - **Calls:** get_quiz_csv_path(), resolve_csv_path(), list_questions_from_csv(), get_grading_status()
  - **Used by:** quiz_csv.js
  - Returns: {success, path, total_questions}

- `grade_question(question_id) -> Dict`
  - Grade a specific question (basic grading)
  - Returns: {success, ...}

- `grade_question_with_criteria(question_id, criteria, grade_only_ungraded=True) -> Dict`
  - Grade a specific question with provided criteria
  - **Calls:** modules.grading functions
  - Returns: {success, grading_results}

- `get_all_grades() -> Dict`
  - Get all graded results for the quiz
  - Returns: {success, questions: []}

- `start_consistency_test(student_ids, num_runs, question_filter, criteria) -> Dict`
  - Start consistency test for quiz questions
  - Returns: {success, task_id}

- `get_consistency_test_status(task_id) -> Dict`
  - Get status of running consistency test
  - Returns: {success, status, ...}

**Inherited Methods (5):**
- `get_questions()` → `_get_questions_from_csv()`
- `get_sample_answers(question_id, count)` → `_get_sample_answers_from_csv()`
- `save_grading_results(question_id, results)` → `_save_grading_results_to_csv()`
- `upload_grades(target_assignment_id)` → `_upload_grades_base('quiz', ...)`
- `export_grades()` → `_export_grades_base()`

**Module Dependencies:**
- modules.canvas (list_quizzes, download_quiz_submissions)
- modules.utils (get_quiz_csv_path, resolve_csv_path, list_questions_from_csv, get_grading_status, get_sample_answers)
- Parent class dependencies (modules.grading)

---

### api/assignment_api.py - Assignment Management (1370 lines - ACTUAL)

**Class:** `AssignmentAPI(BaseContentAPI)` - NOW INHERITS from BaseContentAPI ✅

**Core Methods (32 total):**

1. **Basic CRUD (7):**
   - `cancel_grading()` - Cancel ongoing grading task
   - `get_list()` - Get assignments list
   - `select(assignment_id, assignment_name)` - Select assignment
   - `check_folder(assignment_id)` - Check if folder exists
   - `check_parsed(assignment_id)` - Check if CSV parsed
   - `load_parsed_csv(csv_path)` - Load parsed CSV
   - `get_csv_status()` - Get grading status

2. **Download Methods (2):**
   - `download_submissions(assignment_id, force_download)` - Download submissions (synchronous with progress)
   - `load_existing_folder(assignment_id)` - Load existing folder without downloading

3. **Parsing Methods (5):**
   - `parse_to_csv_pdf(force_parse)` - Parse using PDF metadata
   - `parse_auto(questions_list)` - Auto-detect and use best strategy
   - `get_submission_analysis()` - Analyze submission folder
   - `get_parsing_recommendation()` - Get recommended parsing strategy
   - `get_parsing_summary()` - Get parsing summary

4. **Question/Answer Methods (3):**
   - `get_questions()` - Get questions from CSV (inherited)
   - `get_sample_answers(question_id, count)` - Get sample answers (inherited)
   - `get_student_mapping()` - Get student ID to name mapping

5. **Grading Methods (4):**
   - `grade_question_with_criteria(question_id, criteria, grade_only_ungraded)` - Grade with criteria
   - `save_points(points_map)` - Save points mapping
   - `save_grading_results(question_id, results)` - Save grading results (inherited)
   - `extract_questions_from_canvas()` - Extract questions from Canvas assignment/rubric

6. **Upload/Export Methods (2):**
   - `upload_grades(target_assignment_id)` - Upload grades to Canvas (inherited)
   - `export_grades()` - Export grades to CSV (inherited)

7. **Agent Grade Management (4):**
   - `update_single_grade(student_id, question_id, grade, feedback)` - Update single grade
   - `get_all_agent_grades()` - Get all grades grouped by question
   - `refine_feedback_with_ai(student_id, question_id, ...)` - AI feedback refinement (207 lines inline!)
   - `_format_rubric_ratings_as_text(criterion)` - Format rubric for display (helper)

8. **Submission Info (2):**
   - `get_submission_count()` - Count submissions in folder
   - `get_student_mapping()` - Get student mapping from submissions

9. **Consistency Testing (2):**
   - `start_consistency_test(student_ids, num_runs, question_filter, questions_list)` - Start consistency test
   - `get_consistency_test_status(task_id)` - Get consistency test status

**Module Dependencies:**
- modules.canvas (list_assignments, download_assignment_submissions)
- modules.grading (send_grades_to_canvas, grade_with_llm, auto_grade_question, is_auto_gradable)
- modules.utils (get_assignment_dir, get_assignment_csv_path, read_csv, write_csv, list_questions_from_csv, get_grading_status, get_sample_answers)
- modules.assignment (multiple parsers, strategies, analyzers)
- modules.consistency (consistency_engine, data_access)
- modules.profile (get_active_canvas_credentials)

---

### api/profile_api.py - Profile Management

**Class:** `ProfileAPI(state, window)`

**Private Helper Methods (5):**
- `_get_all_profiles(profile_type)` - Generic get all profiles
- `_create_profile(profile_type, *args)` - Generic create profile
- `_update_profile(profile_type, profile_id, *args)` - Generic update
- `_delete_profile(profile_type, profile_id)` - Generic delete
- `_switch_profile(profile_type, profile_id)` - Generic switch with state reset

**Canvas Profile Methods (5):**
- `get_all_canvas()` → `_get_all_profiles('canvas')` → modules.profile.get_canvas_profiles()
- `create_canvas(name, canvas_address, token, email)` → `_create_profile('canvas', ...)` → modules.profile.create_canvas_profile()
- `update_canvas(profile_id, ...)` → `_update_profile('canvas', ...)` → modules.profile.update_canvas_profile()
- `delete_canvas(profile_id)` → `_delete_profile('canvas', ...)` → modules.profile.delete_canvas_profile()
- `switch_canvas(profile_id)` → `_switch_profile('canvas', ...)` → modules.profile.set_active_canvas_profile()

**LLM Profile Methods (5):**
- `get_all_llm()` → `_get_all_profiles('llm')` → modules.profile.get_llm_profiles()
- `create_llm(name, api_link, model_name, token, llm_type)` → `_create_profile('llm', ...)` → modules.profile.create_llm_profile()
- `update_llm(profile_id, ...)` → `_update_profile('llm', ...)` → modules.profile.update_llm_profile()
- `delete_llm(profile_id)` → `_delete_profile('llm', ...)` → modules.profile.delete_llm_profile()
- `switch_llm(profile_id)` → `_switch_profile('llm', ...)` → modules.profile.set_active_llm_profile()

**Utility Methods (2):**
- `get_active()` → modules.profile.get_active_canvas_profile() + get_active_llm_profile()
- `get_canvas_url()` → modules.profile.get_active_canvas_profile()

**Module Dependencies:**
- modules.profile.profile_setter (all ProfileManager methods)

---

### api/connection_api.py - Connection Testing

**Class:** `ConnectionAPI(state, window)`

**Methods (2):**
- `test_canvas(timeout=10) -> Dict`
  - Tests Canvas connection
  - **Calls:** modules.utils.canvas.test_canvas_connection()
  - **Used by:** connection.js
  - Returns: {success, message}

- `test_llm(profile_id=None) -> Dict`
  - Tests LLM connection with HTTP request
  - **Calls:** modules.profile.get_llm_profiles(), _test_llm_profile()
  - **Used by:** connection.js, profiles.js
  - Returns: {success, message, connections: []}

**Private Helpers (2):**
- `_get_test_profile(profile_id)` - Gets profile to test
- `_test_llm_profile(profile)` - Makes test HTTP request
- `_list_llm_connections()` - Lists all LLM profiles

**Module Dependencies:**
- modules.profile.profile_setter
- modules.utils.canvas.test_canvas_connection()
- External: requests library for HTTP calls

---

### api/system_api.py - System Health

**Class:** `SystemAPI(state, window)`

**Methods (2):**
- `health_check() -> Dict`
  - Runs application health checks
  - Checks: profiles file, Python version, required directories
  - **Used by:** system_health.js
  - Returns: {success, all_ok, checks: []}

- `get_system_info() -> Dict`
  - Returns system information
  - **Used by:** system_health.js, dashboard.js
  - Returns: {success, app_version, python_version, platform, architecture}

**Module Dependencies:**
- Python stdlib: sys, platform, os
- No external module dependencies

---

### api/utils_api.py - Utility Operations

**Class:** `UtilsAPI(state, window)`

**Core Methods (1):**
- `navigate_to(template_name) -> Dict`
  - Navigates to different template
  - **CRITICAL:** Called 48 times across 19 JS files
  - Returns: {success, template}

**Deprecated Grading Methods (3) - TODO: Move to quiz/assignment APIs:**
- `analyze_grading_status()` - BROKEN (calls undefined function)
- `get_grades_preview()` - BROKEN (calls undefined function)
- `send_grades_to_canvas(target_assignment_id)` → modules.grading.send_grades_to_canvas()

**Progress Tracking Stubs (5):**
- `progress_start_session()` - Stub for future implementation
- `progress_update_step(step, completed)` - Stub
- `progress_get_summary()` - Stub
- `progress_get_recent(limit)` - Stub
- `progress_complete_session()` - Stub

**Navigation Stubs (2):**
- `get_breadcrumbs(current_page)` - Stub
- `check_navigation(target_page)` - Stub (always allows)

**Dashboard Stubs (2):**
- `dashboard_get_stats()` - Stub (returns zeros)
- `dashboard_get_activity()` - Stub (returns empty)

**Module Dependencies:**
- modules.grading.send_grades_to_canvas()

---

### api/rubric_api.py - Rubric Management

**Class:** `RubricAPI(state, window)`

**Public Methods (3):**
- `check_exists(assignment_id) -> Dict`
  - Checks if rubric exists (optimized: 1 API call instead of 2)
  - **Calls:** modules.rubric.get_content_rubric()
  - **Used by:** assignment_status.js, rubric.js
  - Returns: {success, exists, rubric}

- `validate_match(assignment_id) -> Dict`
  - Validates rubric matches CSV questions
  - **Calls:** modules.utils.list_questions_from_csv(), modules.rubric.validate_rubric_matches_quiz()
  - **Used by:** assignment_status.js, rubric.js
  - Returns: {success, matches}

- `create(assignment_id) -> Dict`
  - Creates new rubric from CSV questions
  - **Calls:** modules.utils.list_questions_from_csv(), modules.rubric.create_rubric(), modules.rubric.get_content_rubric()
  - **Used by:** assignment_status.js, rubric.js
  - Returns: {success, rubric_info, rubric, message}

**Helper Methods (3):**
- `_error_response(message, details)` - Standard error format
- `_success_response(**data)` - Standard success format
- `_validate_inputs(assignment_id)` - Input validation
- `_format_rubric_data(rubric_data)` - Format Canvas rubric for frontend

**Module Dependencies:**
- modules.rubric.rubric_management (get_content_rubric, create_rubric, validate_rubric_matches_quiz)
- modules.utils (list_questions_from_csv)

---

### api/criteria_api.py - Grading Criteria Management (89 lines - ACTUAL)

**Class:** `CriteriaAPI(state, window)`

**Purpose:** Manage reusable grading criteria for assignments and quizzes

**Methods (2):**
- `get_criteria(course_id, content_id, content_type) -> Dict`
  - Loads saved grading criteria for a specific content object
  - Returns: {success, criteria: []}
  - **Used by:** Frontend grading workflows
  - **Calls:** _get_criteria_path() helper

- `save_criteria(name, criteria_data, course_id, content_id, content_type) -> Dict`
  - Saves a new set of grading criteria for a content object
  - Creates or updates criteria in JSON file
  - Returns: {success, message}
  - **Used by:** Frontend grading workflows
  - **Calls:** _get_criteria_path() helper

**Helper Functions (1):**
- `_get_criteria_path(course_id, content_id, content_type) -> Path`
  - Constructs the path to the criteria file
  - For assignments: `data/course_{id}/assignment_{id}/grading_criteria.json`
  - For quizzes: `data/course_{id}/quiz_{id}/grading_criteria.json`

**Module Dependencies:**
- modules.utils (get_assignment_dir, get_quiz_csv_path)

**Storage Format:**
- JSON file with list of criteria objects: `[{"name": "...", "criteria": {...}}]`

---

## Dependency Matrix

### Modules → API Usage

| Module | Functions | Used By APIs |
|--------|-----------|--------------|
| **modules/canvas/** | get_courses, list_quizzes, list_assignments, download_quiz_submissions, download_assignment_submissions | CourseAPI, QuizAPI, AssignmentAPI |
| **modules/grading/** | is_auto_gradable, auto_grade_question, grade_with_llm, send_grades_to_canvas, save_grading_results_to_csv | BaseContentAPI, QuizAPI, AssignmentAPI, UtilsAPI |
| **modules/utils/** | list_questions_from_csv, get_grading_status, get_sample_answers, read_csv, write_csv, get_quiz_csv_path, get_assignment_dir, get_assignment_csv_path | BaseContentAPI, QuizAPI, AssignmentAPI, RubricAPI |
| **modules/profile/** | get_canvas_profiles, get_llm_profiles, create/update/delete/switch methods, get_active_* | ProfileAPI, ConnectionAPI, All APIs (for credentials) |
| **modules/rubric/** | get_content_rubric, create_rubric, validate_rubric_matches_quiz | RubricAPI |
| **modules/parsing/** | parse_assignment_to_csv, analyze_submission_folder | AssignmentAPI |
| **modules/assignment/** | Multiple parsers, strategies, analyzers | AssignmentAPI |
| **modules/consistency/** | run_consistency_test, get_student_submission_mapping, count_submissions | AssignmentAPI |

---

### API → Frontend Usage

| API File | Methods | Used By JS Files | Used By HTML Templates |
|----------|---------|------------------|------------------------|
| **course_api.py** | 2 methods | courses.js, content_list.js, dashboard.js | courses.html, content_list.html |
| **quiz_api.py** | 16 methods (11 specific + 5 inherited) | quiz_list.js, quiz_csv.js, quiz_status.js, quiz_grading.js, quiz_upload.js, grade_input.js, grade_review.js | quiz_*.html (7 files) |
| **assignment_api.py** | 32 methods (27 specific + 5 inherited) | assignment_*.js (13 files), grade_input.js, grade_review.js | assignment_*.html (13 files) |
| **profile_api.py** | 13 methods | profiles.js, profile_select.js, dashboard.js, index.js, modern-ui.js | profiles.html, profile_select.html |
| **connection_api.py** | 2 methods | connection.js, profiles.js, modern-ui.js | connection.html |
| **system_api.py** | 2 methods | system_health.js, dashboard.js | system_health.html |
| **utils_api.py** | 14 methods | ALL 39 JS files (navigate_to), gui_helpers.js, dashboard.js | All templates (navigation) |
| **rubric_api.py** | 3 methods | assignment_status.js, rubric.js | assignment_status.html, rubric.html |
| **criteria_api.py** | 2 methods | grading_hub.js, grade_input.js, assignment workflows | Grading templates |

---

## Frontend → API Call Patterns

### Most Used API Methods (by call count):

1. **navigate_to()** - ~48 calls across 19 files (navigation)
2. **profile_get_active()** - ~15+ calls (profile state)
3. **assignment_get_questions()** - ~12+ calls (assignment workflow)
4. **quiz_get_questions()** - ~8+ calls (quiz workflow)
5. **grading_start_task()** - Routes to quiz or assignment grading
6. **grades_get_all()** - Routes to quiz or assignment grade retrieval

### Assignment Workflow Progression:
```
assignment_list.js → assignment_get_list()
↓
assignment_download.js → assignment_download_submissions()
↓
assignment_template.js / assignment_agent_setup.js → assignment_extract_questions_from_canvas()
↓
assignment_parse.js → assignment_parse_to_csv_pdf() OR assignment_agent_setup.js → assignment_start_agent_task()
↓
assignment_status.js → assignment_get_questions(), rubric_check_exists()
↓
assignment_agent_results.js → assignment_get_all_agent_grades(), assignment_upload_grades()
```

### Quiz Workflow Progression:
```
quiz_list.js → quiz_get_list()
↓
quiz_csv.js → quiz_download_submissions() OR quiz_load_existing_csv()
↓
quiz_status.js → quiz_get_questions()
↓
quiz_grading.js → quiz_get_sample_answers(), grading_start_task()
↓
quiz_upload.js → quiz_upload_grades()
```

---

## Architecture Statistics

### Code Distribution:

| Layer | Files | Lines | Purpose |
|-------|-------|-------|---------|
| **Modules** | 28 (excl __init__) | 8,405 | Business logic |
| **APIs** | 11 (incl base) | 4,247 | Expose to frontend |
| **Frontend JS** | 39 | 12,255 | UI logic |
| **Frontend HTML** | 38 | 13,313 | UI templates |
| **Total** | 116 | 38,220 | Full application |

### Module Complexity:

| Module | Files | Actual Lines | Complexity |
|--------|-------|-------------|------------|
| modules/assignment/ | 11 (9+2 strategies) | 2,675 | High (multiple parsers) |
| modules/grading/ | 3 | 1,123 | Medium |
| modules/utils/ | 4 | 916 | Medium |
| modules/rubric/ | 2 | 1,035 | Medium |
| modules/profile/ | 1 | 346 | Low |
| modules/canvas/ | 3 | 1,068 | Medium |
| modules/parsing/ | 1 | 461 | Low |
| modules/consistency/ | 2 | 661 | Medium |

### API Size Distribution:

| API File | Lines | Complexity | Reason for Size |
|----------|-------|------------|-----------------|
| assignment_api.py | 1,370 | Very High | 47 methods: parsing, agents, grading, consistency |
| api/__init__.py | 587 | High | Routes all API calls |
| quiz_api.py | 763 | Medium | 12 methods + inheritance |
| base_content_api.py | 365 | Medium | Shared base class |
| rubric_api.py | 301 | Medium | Comprehensive validation |
| profile_api.py | 282 | Medium | 13 methods with helpers |
| utils_api.py | 194 | Low | Mostly stubs |
| connection_api.py | 144 | Low | Connection testing |
| system_api.py | 92 | Low | System info |
| criteria_api.py | 89 | Low | Grading criteria management |
| course_api.py | 60 | Low | Simple CRUD |

---

## Key Architectural Patterns

### 1. **Inheritance Pattern**
```
BaseContentAPI
    ├── QuizAPI (inherits 5 shared methods)
    └── AssignmentAPI (TODO: should inherit)
```

### 2. **Generic Helper Pattern**
```python
ProfileAPI:
    _get_all_profiles(type)  # Generic
        ├── get_all_canvas()  # Wrapper
        └── get_all_llm()     # Wrapper
```

### 3. **Delegation Pattern**
```
API Layer (thin wrappers)
    ↓
Module Layer (business logic)
    ↓
External Services (Canvas API, LLM APIs)
```

### 4. **State Management Pattern**
```
State Object (shared across APIs)
    - course_id
    - content_id
    - content_type ('quiz' or 'assignment')
    - csv_path
    - folder_path
    - graded_questions
    - canvas_tested / llm_tested
```

---

## Refactoring History (Phase 7)

### Before Refactoring:
- Scattered module organization
- Broken import references
- 95% code duplication between Canvas/LLM methods
- No inheritance between quiz/assignment APIs
- Inconsistent error handling

### After Refactoring:
- ✅ Clean module structure (8 domains)
- ✅ All imports fixed and working
- ✅ Duplication eliminated via helpers/inheritance
- ✅ BaseContentAPI shared by quiz/assignment
- ✅ Consistent error/success response formats
- ✅ Comprehensive logging throughout
- ✅ -900+ lines of code removed

---

## Future Improvements

### High Priority:
1. ~~**AssignmentAPI:** Add BaseContentAPI inheritance~~ ✅ **COMPLETED**
2. **Extract AI feedback:** Move refine_feedback_with_ai to module (save 207 lines)
3. **Extract consistency:** Move to separate consistency_api.py (save 170 lines)
4. **Delete ZIP workflow:** Remove 3 unused methods (save ~200 lines) - VERIFY IF ACTUALLY DELETED
5. **Delete template methods:** Remove 3 deprecated methods (save ~85 lines) - VERIFY IF ACTUALLY DELETED

### Medium Priority:
1. Implement TODO grading methods (grade_question, grade_question_with_criteria)
2. Standardize background task management (reduce duplication)
3. Add caching to frequently-called APIs
4. Implement or remove stub methods in utils_api.py

### Low Priority:
1. Add unit tests for all modules
2. Add integration tests for API layer
3. Extract configuration to config files
4. Add API versioning support

---

## Testing Recommendations

### Unit Testing:
- Test each module function independently
- Mock Canvas API responses
- Test error handling paths

### Integration Testing:
- Test complete workflows end-to-end
- Test with real Canvas sandbox
- Test LLM grading with local models

### Frontend Testing:
- Test all API calls from JavaScript
- Test error handling in UI
- Test navigation flows

---

## Maintenance Guide

### Adding New Features:

**1. Add Canvas Course Feature:**
- Add function to modules/canvas/courses.py
- Add method to api/course_api.py
- Expose in api/__init__.py
- Call from frontend JS

**2. Add New Grading Feature:**
- Add function to modules/grading/*.py
- Add to BaseContentAPI if shared by quiz/assignment
- Or add to specific QuizAPI/AssignmentAPI
- Update frontend to call new method

**3. Add New Profile Type:**
- Add methods to modules/profile/profile_setter.py
- Add wrapper methods to api/profile_api.py using _*_profile() helpers
- Update profiles.js to handle new type

### Debugging:

**Check module imports:**
```bash
python -m py_compile modules/**/*.py
```

**Check API imports:**
```bash
python -m py_compile api/*.py
```

**Check for undefined functions:**
```bash
grep -r "def function_name" modules/
```

**Find API method usage:**
```bash
grep -r "window.api.method_name" frontend/static/js/
```

---

## File Organization

```
C:\AnZar/
├── api/                        # API Layer (11 files)
│   ├── __init__.py            # Main API router (587 lines)
│   ├── base_content_api.py    # Shared base class (365 lines)
│   ├── assignment_api.py      # Assignment management (1,370 lines)
│   ├── quiz_api.py            # Quiz management (763 lines)
│   ├── profile_api.py         # Profile management (282 lines)
│   ├── course_api.py          # Course management (60 lines)
│   ├── rubric_api.py          # Rubric management (301 lines)
│   ├── criteria_api.py        # Grading criteria management (89 lines)
│   ├── connection_api.py      # Connection testing (144 lines)
│   ├── system_api.py          # System health (92 lines)
│   └── utils_api.py           # Utilities (194 lines)
│
├── modules/                    # Module Layer (28 files + 8 __init__.py)
│   ├── canvas/                # Canvas integration (3 files: 1,068 lines)
│   ├── grading/               # Grading logic (3 files: 1,123 lines)
│   ├── parsing/               # Assignment parsing (1 file: 461 lines)
│   ├── profile/               # Profile management (1 file: 346 lines)
│   ├── rubric/                # Rubric management (2 files: 1,035 lines)
│   ├── utils/                 # Utilities (4 files: 916 lines)
│   ├── assignment/            # Assignment processing (11 files: 2,675 lines)
│   │   └── strategies/        # Parsing strategies (2 files: 120 lines)
│   └── consistency/           # Consistency testing (2 files: 661 lines)
│
├── frontend/                   # Frontend Layer
│   ├── static/js/             # JavaScript files (39 files: 12,255 lines)
│   └── templates/             # HTML templates (38 files: 13,313 lines)
│
├── app.py                      # Main application entry point
├── main.py                     # CLI entry point (legacy)
└── profiles.json               # Profile storage

```

---

## Complete API-to-Frontend Method Mapping

This section documents every API method and which JavaScript files call it.

### CourseAPI Methods

| Method | Used By JS Files | Purpose |
|--------|------------------|---------|
| `course_get_list()` | courses.js, content_list.js | Fetch all courses from Canvas |
| `course_select()` | courses.js, content_list.js | Select a course and set in state |

**Total CourseAPI Methods:** 2

---

### QuizAPI Methods

| Method | Used By JS Files | Purpose |
|--------|------------------|---------|
| `quiz_get_list()` | content_list.js, quiz_list.js | Fetch quizzes for current course |
| `quiz_select()` | content_list.js, quiz_list.js | Select a quiz and set in state |
| `quiz_check_csv()` | grading_hub.js, quiz_csv.js | Check if quiz CSV exists |
| `quiz_download_submissions()` | quiz_csv.js | Download quiz submissions to CSV |
| `quiz_load_existing_csv()` | grading_hub.js, quiz_csv.js | Load existing CSV without downloading |
| `quiz_get_questions()` | grading_hub.js, quiz_consistency_alpine.js | Get questions from quiz CSV |
| `quiz_get_sample_answers()` | quiz_consistency_alpine.js, grade_input.js | Get sample student answers |
| `quiz_save_grading_results()` | grade_review.js | Save grading results to CSV |
| `quiz_upload_grades()` | quiz_upload.js | Upload grades to Canvas |
| `quiz_export_grades()` | grade_review.js, quiz_upload.js | Export grades to CSV file |
| `quiz_start_consistency_test()` | quiz_consistency_alpine.js | Start AI grading consistency test |
| `quiz_grade_question()` | *(Not called by any JS)* | Basic question grading |
| `quiz_grade_question_with_criteria()` | *(Not called by any JS)* | Grade with specific criteria |
| `quiz_get_consistency_test_status()` | *(Not called by any JS)* | Get consistency test status |
| `quiz_get_all_grades()` | *(Called via grades_get_all)* | Get all graded results |

**Total QuizAPI Methods:** 15 (11 actively used)

---

### AssignmentAPI Methods

| Method | Used By JS Files | Purpose |
|--------|------------------|---------|
| `assignment_get_list()` | assignment_list.js, content_list.js | Fetch assignments for course |
| `assignment_select()` | assignment_list.js, content_list.js | Select assignment |
| `assignment_check_folder()` | assignment_download.js | Check if submission folder exists |
| `assignment_check_parsed()` | assignment_download.js, assignment_parse.js | Check if CSV parsed |
| `assignment_download_submissions()` | assignment_download.js | Download assignment submissions |
| `assignment_load_existing_folder()` | assignment_download.js | Load existing folder |
| `assignment_parse_to_csv_pdf()` | assignment_download.js, assignment_parse.js | Parse using PDF metadata |
| `assignment_parse_auto()` | assignment_agent_running.js | Auto-detect best parsing strategy |
| `assignment_get_submission_analysis()` | assignment_agent_setup.js, assignment_template.js | Analyze submission folder |
| `assignment_get_parsing_recommendation()` | assignment_download.js | Get recommended parsing method |
| `assignment_get_questions()` | assignment_points_setup.js, assignment_status.js | Get questions from CSV |
| `assignment_get_sample_answers()` | assignment_agent_setup.js, grade_input.js | Get sample answers |
| `assignment_save_points()` | assignment_points_setup.js | Save question points mapping |
| `assignment_upload_grades()` | assignment_agent_results.js, quiz_upload.js | Upload grades to Canvas |
| `assignment_export_grades()` | assignment_agent_results.js, grade_review.js, grade_review_v2.js, quiz_upload.js | Export grades to CSV |
| `assignment_get_all_agent_grades()` | assignment_agent_results.js | Get all graded results |
| `assignment_get_agent_grades_by_student()` | assignment_agent_results.js | Get grades filtered by student |
| `assignment_update_single_grade()` | assignment_agent_grade_edit.js | Update single grade/feedback |
| `assignment_refine_feedback_with_ai()` | assignment_agent_grade_edit.js | AI-powered feedback refinement |
| `assignment_extract_questions_from_canvas()` | assignment_agent_setup.js | Extract questions from Canvas |
| `assignment_save_grading_results()` | *(Not called by any JS)* | Save grading results |
| `assignment_start_consistency_test()` | *(Not called by any JS)* | Start consistency test |
| `assignment_get_consistency_test_status()` | *(Not called by any JS)* | Get test status |

**Total AssignmentAPI Methods:** 23 (20 actively used)

---

### ProfileAPI Methods

| Method | Used By JS Files | Purpose |
|--------|------------------|---------|
| `profile_get_active()` | dashboard.js, modern-ui.js, index.js | Get active Canvas & LLM profiles |
| `profile_get_all_canvas()` | dashboard.js, index.js, profile_select.js, profiles.js | Get all Canvas profiles |
| `profile_get_all_llm()` | dashboard.js, index.js, profile_select.js, profiles.js | Get all LLM profiles |
| `profile_create_canvas()` | profile_select.js, profiles.js | Create new Canvas profile |
| `profile_create_llm()` | profile_select.js, profiles.js | Create new LLM profile |
| `profile_update_canvas()` | profile_select.js, profiles.js | Update Canvas profile |
| `profile_update_llm()` | profile_select.js, profiles.js | Update LLM profile |
| `profile_delete_canvas()` | profile_select.js, profiles.js | Delete Canvas profile |
| `profile_delete_llm()` | profile_select.js, profiles.js | Delete LLM profile |
| `profile_switch_canvas()` | profile_select.js, profiles.js | Switch active Canvas profile |
| `profile_switch_llm()` | profile_select.js, profiles.js | Switch active LLM profile |

**Total ProfileAPI Methods:** 11 (all actively used)

---

### RubricAPI Methods

| Method | Used By JS Files | Purpose |
|--------|------------------|---------|
| `rubric_check_exists()` | assignment_status.js, rubric.js | Check if rubric exists for assignment |
| `rubric_validate_match()` | assignment_status.js, rubric.js | Validate rubric matches CSV questions |
| `rubric_create()` | assignment_status.js, rubric.js | Create rubric from CSV questions |

**Total RubricAPI Methods:** 3 (all actively used)

---

### CriteriaAPI Methods

| Method | Used By JS Files | Purpose |
|--------|------------------|---------|
| `criteria_get()` | grade_input.js | Load saved grading criteria |
| `criteria_save()` | grade_input.js | Save grading criteria for reuse |

**Total CriteriaAPI Methods:** 2 (all actively used)

---

### Grading Routing Methods (in api/__init__.py)

| Method | Used By JS Files | Purpose |
|--------|------------------|---------|
| `grading_start_task()` | assignment_grading_progress.js, quiz_grading_progress.js | Start grading (routes to quiz/assignment) |
| `grading_cancel_task()` | assignment_grading_progress.js, quiz_grading_progress.js | Cancel grading (routes to quiz/assignment) |
| `grades_get_all()` | *(Via grade_review components)* | Get all grades (routes to quiz/assignment) |

**Total Grading Router Methods:** 3

---

### ConnectionAPI Methods

| Method | Used By JS Files | Purpose |
|--------|------------------|---------|
| `connection_test_canvas()` | connection.js, dashboard.js, modern-ui.js, profiles.js | Test Canvas API connection |
| `connection_test_llm()` | connection.js, dashboard.js, modern-ui.js, profiles.js | Test LLM API connection |

**Total ConnectionAPI Methods:** 2 (all actively used)

---

### SystemAPI Methods

| Method | Used By JS Files | Purpose |
|--------|------------------|---------|
| `health_check()` | system_health.js, dashboard.js | Run system health checks |
| `get_system_info()` | system_health.js, dashboard.js | Get system information |

**Total SystemAPI Methods:** 2 (all actively used)

---

### UtilsAPI & Core Methods

| Method | Used By JS Files (count) | Purpose |
|--------|---------------------------|---------|
| `navigate_to()` | **24 files** (assignment_agent_setup.js, assignment_grading_progress.js, assignment_list.js, assignment_points_setup.js, connection.js, content_list.js, content_select.js, courses.js, dashboard.js, grade_input.js, grade_review.js, grade_review_v2.js, grading_hub.js, gui_helpers.js, index.js, modern-ui.js, profile_select.js, quiz_consistency_alpine.js, quiz_csv.js, quiz_grading_progress.js, quiz_list.js, review_assignment.js, review_quiz.js, rubric.js) | Navigate between templates |
| `get_state()` | **19 files** (assignment_agent_setup.js, assignment_download.js, assignment_list.js, assignment_parse.js, assignment_points_setup.js, assignment_status.js, assignment_template.js, content_list.js, content_select.js, grade_input.js, grade_review.js, grade_review_v2.js, grading_common.js, grading_hub.js, quiz_csv.js) | Get current application state |

**Total UtilsAPI Core Methods:** 2 (most heavily used)

---

## Summary Statistics

### API Usage Overview

| API Class | Total Methods | Actively Used | Unused/Indirect | Most Used By |
|-----------|---------------|---------------|-----------------|--------------|
| **CourseAPI** | 2 | 2 | 0 | courses.js, content_list.js |
| **QuizAPI** | 15 | 11 | 4 | quiz_csv.js, grading_hub.js |
| **AssignmentAPI** | 23 | 20 | 3 | assignment_agent_results.js, assignment_download.js |
| **ProfileAPI** | 11 | 11 | 0 | profiles.js, profile_select.js |
| **RubricAPI** | 3 | 3 | 0 | assignment_status.js, rubric.js |
| **CriteriaAPI** | 2 | 2 | 0 | grade_input.js |
| **GradingRouter** | 3 | 3 | 0 | assignment/quiz_grading_progress.js |
| **ConnectionAPI** | 2 | 2 | 0 | connection.js, dashboard.js |
| **SystemAPI** | 2 | 2 | 0 | system_health.js |
| **UtilsAPI** | 2+ | 2+ | 0 | ALL files (navigate_to) |
| **TOTAL** | **65+** | **58+** | **7** | - |

### Top 10 Most Called API Methods

1. `navigate_to()` - 24 JavaScript files
2. `get_state()` - 19 JavaScript files
3. `profile_get_all_canvas()` - 4 JavaScript files
4. `profile_get_all_llm()` - 4 JavaScript files
5. `assignment_export_grades()` - 4 JavaScript files
6. `connection_test_canvas()` - 4 JavaScript files
7. `connection_test_llm()` - 4 JavaScript files
8. `profile_get_active()` - 3 JavaScript files
9. `assignment_get_sample_answers()` - 2 JavaScript files
10. Multiple methods - 2 JavaScript files each

### Unused/Indirect Methods (7)

These methods exist in the API but are not directly called from JavaScript:

1. `quiz_grade_question()` - May be called via `grading_start_task()`
2. `quiz_grade_question_with_criteria()` - May be called via `grading_start_task()`
3. `quiz_get_consistency_test_status()` - Polling endpoint
4. `assignment_save_grading_results()` - May be internal/deprecated
5. `assignment_start_consistency_test()` - Not yet implemented in UI
6. `assignment_get_consistency_test_status()` - Not yet implemented in UI
7. `quiz_get_all_grades()` - Called via `grades_get_all()` router

---

## End of Documentation
