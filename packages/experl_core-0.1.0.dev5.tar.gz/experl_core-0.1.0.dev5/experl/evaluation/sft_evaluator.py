import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig

from experl.utils.logging_utils import ExperlLogger


log = ExperlLogger.get_logger(__name__)

base_path = "/mnt/diskai/ai_experiments/experl_output/default-project-name/google_gemma-3-270m-it__all-stages__dpo__20251115-2156/dpo_model/final-dpo_model-google_gemma-3-270m-it"
model_name = f"{base_path}"

tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name, device_map="cuda", dtype=torch.bfloat16)

log.info("\n--- TOKENIZER INFO ---")
log.info("vocab_size:", tokenizer.vocab_size)
log.info("pad_token:", tokenizer.pad_token, tokenizer.pad_token_id)
log.info("eos_token:", tokenizer.eos_token, tokenizer.eos_token_id)
log.info("bos_token:", tokenizer.bos_token, tokenizer.bos_token_id)

model.generation_config = GenerationConfig(
    max_new_tokens=50,
    temperature=0.9,
    do_sample=True,
    top_p=0.95,
    repetition_penalty=1.5,
    no_repeat_ngram_size=3,
    num_return_sequences=1,
    eos_token_id=tokenizer.eos_token_id,
    pad_token_id=tokenizer.pad_token_id,
)

# Test prompt
prompt = "Beautiful is better than"

inputs = tokenizer(prompt, return_tensors="pt").to("cuda")

log.info("\n--- TOKEN IDS ---")
log.info(inputs["input_ids"])
log.info("decoded:", tokenizer.decode(inputs["input_ids"][0]))
log.info("=============model config================")
log.info(model.config)
log.info("=============model generation_config================")
log.info(model.generation_config)

log.info("\n--- GENERATION START ---")
with torch.no_grad():
    for do_sample in (False, True):
        out = model.generate(**inputs,
                             do_sample=do_sample,
                             max_new_tokens=60,
                             temperature=0.7,
                             top_p=0.9,
                             repetition_penalty=1.3,
                             no_repeat_ngram_size=3,
                             eos_token_id=tokenizer.eos_token_id,
                             pad_token_id=tokenizer.pad_token_id,
                             )
        log.info("\n--- MODEL OUTPUT --------------------------------")
        log.info("do_sample=", do_sample)
        log.info(tokenizer.decode(out[0], skip_special_tokens=True))
        log.info("--------------------------------")

    """outputs = model.generate(
        **inputs,
        do_sample=True,
        max_new_tokens=128,
        temperature=0.7,
        top_p=0.95,
        repetition_penalty=1.5,
        no_repeat_ngram_size=1,
        num_return_sequences=1,
        eos_token_id=tokenizer.eos_token_id,
        pad_token_id=tokenizer.pad_token_id,
    )
    """
