from typing import Any

from mlflow.data.huggingface_dataset import from_huggingface
from omegaconf import OmegaConf
from transformers import AutoConfig, AutoModelForCausalLM, BatchEncoding, PreTrainedTokenizer
from trl import PPOConfig, PPOTrainer, create_reference_model

from experl.config.config_loader import ConfigLoader
from experl.config.schema.config_classes import OrchestratorConfig
from experl.logger.mlflow_logger import MLFlowLogger
from experl.models.reward_model import RewardModel
from experl.trainer.base_trainer import BaseTrainer
from experl.utils.dataset_utils import fetch_dataset, get_dataset_metadata
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import (
    create_file_path,
    get_device,
    get_tokenizer,
    get_tracking_path,
    sanitize_model,
)


log = ExperlLogger.get_logger(__name__)


class PPOModelTrainer(BaseTrainer):

    def __init__(
            self,
            config: OrchestratorConfig,
            mlflow_logger: MLFlowLogger,
    ) -> None:
        self.ref_policy = None
        self.value_model = None
        self.reward_model = None
        self.policy_model = None
        super().__init__(
            trainer_name="ppo_model",
            config=config,
            mlflow_logger=mlflow_logger,
        )
        self.trainer_args = PPOConfig(**OmegaConf.to_container(self.config.pipeline.ppo))
        self.trainer_args.sft_model_path = create_file_path(
            self.config,
            f"sft_model/final-sft_model-{self.model_id}",
        )
        self.trainer_args.reward_model_path = create_file_path(
            self.config,
            f"reward_model/final-reward_model-{self.model_id}",
        )

    def load_dataset(self) -> None:
        """Load json dataset and tokenize 'prompt' (and optional 'response')."""

        def tokenize_prompt(example: dict[str, Any], tokenizer: PreTrainedTokenizer) -> BatchEncoding:
            tokenized = tokenizer(text=example[self.config.dataset.prompt.prompt_key])
            if tokenizer.eos_token_id is not None and tokenized["input_ids"][-1] != tokenizer.eos_token_id:
                tokenized["input_ids"] = tokenized["input_ids"] + [tokenizer.eos_token_id]
                tokenized["attention_mask"] = tokenized["attention_mask"] + [1]
            return tokenized

        ds_config = self.config.dataset
        self.train_dataset = fetch_dataset(ds_config.prompt.path,
                                           name=ds_config.prompt.subset,
                                           split=ds_config.prompt.train_split,
                                           process_fn=tokenize_prompt,
                                           process_fn_kwargs={"tokenizer": self.tokenizer},
                                           remove_columns=[ds_config.prompt.prompt_key]
                                           )

        if self.trainer_args.eval_strategy != "no":
            self.eval_dataset = fetch_dataset(ds_config.prompt.path,
                                              name=ds_config.prompt.subset,
                                              split=ds_config.prompt.test_split,
                                              process_fn=tokenize_prompt,
                                              process_fn_kwargs={"tokenizer": self.tokenizer},
                                              remove_columns=[ds_config.prompt.prompt_key]
                                              )
        self.log_dataset()

    def log_dataset(self) -> None:
        self.mlflow_logger.log_dataset_metadata(get_dataset_metadata(self.train_dataset, self.tokenizer, name="train"))
        self.mlflow_logger.log_dataset(
            from_huggingface(self.train_dataset),
            context="train",
            model_id=self.config.base_model_name,
        )
        if self.eval_dataset:
            self.mlflow_logger.log_dataset_metadata(
                get_dataset_metadata(self.eval_dataset, self.tokenizer, name="test"))
            self.mlflow_logger.log_dataset(
                from_huggingface(self.eval_dataset),
                context="test",
                model_id=self.config.base_model_name,
            )

    def load_model(self) -> None:
        self.load_policy_model()
        self.load_reward_model()
        self.load_value_model()
        self.load_ref_model()

    def load_ref_model(self) -> None:
        self.ref_policy = create_reference_model(self.policy_model)
        self.ref_policy.to(get_device())

    def load_value_model(self) -> None:
        rm_config = AutoConfig.from_pretrained(
            self.trainer_args.reward_model_path,
            **self.model_kwargs
        )
        self.value_model = RewardModel(rm_config)
        # sanitize_model(self.value_model, self.tokenizer)
        self.value_model.to(get_device())

    def load_reward_model(self) -> None:
        log.debug(f"reward_model_name = {self.trainer_args.reward_model_path}")
        rm_config = AutoConfig.from_pretrained(
            self.trainer_args.reward_model_path,
            **self.model_kwargs
        )
        self.reward_model = RewardModel(rm_config)
        # sanitize_model(self.reward_model, self.tokenizer)
        self.reward_model.to(get_device())

    def load_policy_model(self) -> None:
        self.tokenizer = get_tokenizer(
            self.trainer_args.sft_model_path,
            padding_side="left",
        )
        self.policy_model = AutoModelForCausalLM.from_pretrained(
            self.trainer_args.sft_model_path,
            **self.model_kwargs
        )
        sanitize_model(self.policy_model, self.tokenizer)
        self.policy_model.to(get_device())

    def create_trainer(self) -> None:
        self.trainer = PPOTrainer(
            args=self.trainer_args,
            processing_class=self.tokenizer,
            model=self.policy_model,
            ref_model=self.ref_policy,
            reward_model=self.reward_model,
            value_model=self.value_model,
            train_dataset=self.train_dataset,
            eval_dataset=self.eval_dataset
        )

    def train_model(self) -> None:
        self.trainer.train()

    @staticmethod
    def run(main_config: OrchestratorConfig, nested: bool = True) -> None:
        stage = "ppo"
        with MLFlowLogger(
                experiment_name=main_config.project_name,
                tracking_uri=get_tracking_path(main_config),
                run_name=f"{stage}__{main_config.run_name}",
                nested=nested,
                tags={
                    "stage": stage,
                    "run_name": f"{stage}__{main_config.run_name}",
                    "project_name": main_config.project_name,
                },
        ) as mlogger:
            # mlogger.log_args_and_overrides(args, overrides)
            ppo_model_trainer = PPOModelTrainer(main_config, mlogger)
            mlogger.log_dict(OmegaConf.to_container(main_config), "config.json")
            ppo_model_trainer.train()


if __name__ == "__main__":
    orch_config: OrchestratorConfig = ConfigLoader.build_orchestrator_config()
    PPOModelTrainer.run(orch_config)
