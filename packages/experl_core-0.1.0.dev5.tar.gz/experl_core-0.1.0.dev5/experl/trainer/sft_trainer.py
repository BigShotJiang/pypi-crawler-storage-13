from typing import Any

from mlflow.data.huggingface_dataset import from_huggingface
from omegaconf import OmegaConf
from transformers import AutoModelForCausalLM, BatchEncoding, PreTrainedTokenizer
from trl import SFTConfig, SFTTrainer, get_peft_config

from experl.config.config_loader import ConfigLoader
from experl.config.schema.config_classes import OrchestratorConfig
from experl.logger.mlflow_logger import MLFlowLogger
from experl.trainer.base_trainer import BaseTrainer
from experl.utils.dataset_utils import fetch_dataset, get_dataset_metadata
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import (
    get_device,
    get_tokenizer,
    get_tracking_path,
    sanitize_model,
)


log = ExperlLogger.get_logger(__name__)


class SFTModelTrainer(BaseTrainer):

    def __init__(
            self,
            config: OrchestratorConfig,
            mlflow_logger: MLFlowLogger,
    ) -> None:
        super().__init__(
            trainer_name="sft_model",
            config=config,
            mlflow_logger=mlflow_logger,
        )

        self.trainer_args = SFTConfig(**OmegaConf.to_container(self.config.pipeline.sft))

    def load_model(self) -> None:
        self.model = AutoModelForCausalLM.from_pretrained(
            self.config.base_model_name,
            **self.model_kwargs
        )
        self.tokenizer = get_tokenizer(
            self.config.base_model_name, self.config.padding_side
        )
        sanitize_model(self.model, self.tokenizer)
        self.model.to(get_device())

    def load_dataset(self) -> None:
        ds_config = self.config.dataset
        log.debug(f"Loading dataset from path : {ds_config.sft.path}")
        prompt_key = ds_config.sft.prompt_key
        completion_key = ds_config.sft.response_key

        def tokenize_prompt(example: dict[str, Any], tokenizer: PreTrainedTokenizer) -> BatchEncoding:
            tokenized = tokenizer(text=f"{example[prompt_key]} {example[completion_key]}")
            if tokenizer.eos_token_id is not None and tokenized["input_ids"][-1] != tokenizer.eos_token_id:
                tokenized["input_ids"] = tokenized["input_ids"] + [tokenizer.eos_token_id]
                tokenized["attention_mask"] = tokenized["attention_mask"] + [1]
            return tokenized

        self.train_dataset = fetch_dataset(ds_config.sft.path,
                                           name=ds_config.sft.subset,
                                           split=ds_config.sft.train_split,
                                           process_fn=tokenize_prompt,
                                           process_fn_kwargs={"tokenizer": self.tokenizer},
                                           remove_columns=[prompt_key, completion_key]
                                           )

        if self.trainer_args.eval_strategy != "no":
            self.eval_dataset = fetch_dataset(ds_config.sft.path,
                                              name=ds_config.sft.subset,
                                              split=ds_config.sft.test_split,
                                              process_fn=tokenize_prompt,
                                              process_fn_kwargs={"tokenizer": self.tokenizer},
                                              remove_columns=[prompt_key, completion_key]
                                              )

        self.log_dataset()

    def log_dataset(self) -> None:
        self.mlflow_logger.log_dataset_metadata(get_dataset_metadata(self.train_dataset, self.tokenizer, name="train"))
        self.mlflow_logger.log_dataset(
            from_huggingface(self.train_dataset),
            context="train",
            model_id=self.model_id,
        )

        if self.eval_dataset:
            self.mlflow_logger.log_dataset_metadata(
                get_dataset_metadata(self.eval_dataset, self.tokenizer, name="test"))
            self.mlflow_logger.log_dataset(
                from_huggingface(self.eval_dataset),
                context="test",
                model_id=self.model_id,
            )

    def create_trainer(self) -> None:
        peft_config = get_peft_config(self.config.model)
        self.trainer = SFTTrainer(
            model=self.model,
            processing_class=self.tokenizer,
            args=self.trainer_args,
            train_dataset=self.train_dataset,
            eval_dataset=self.eval_dataset,
            peft_config=peft_config
        )

    def train_model(self) -> None:
        self.trainer.train()

    @staticmethod
    def run(main_config: OrchestratorConfig, nested: bool = True) -> None:
        stage = "sft"
        with MLFlowLogger(
                experiment_name=main_config.project_name,
                tracking_uri=get_tracking_path(main_config),
                run_name=f"{stage}__{main_config.run_name}",
                nested=nested,
                tags={
                    "stage": stage,
                    "run_name": f"{stage}__{main_config.run_name}",
                    "project_name": main_config.project_name,
                },
        ) as mlogger:
            # mlogger.log_args_and_overrides(args, overrides)
            app = SFTModelTrainer(main_config, mlogger)
            mlogger.log_dict(OmegaConf.to_container(main_config), "config.json")
            app.train()


if __name__ == "__main__":
    orch_config: OrchestratorConfig = ConfigLoader.build_orchestrator_config()
    SFTModelTrainer.run(orch_config)
