from mlflow.data.huggingface_dataset import from_huggingface
from omegaconf import OmegaConf
from transformers import AutoModelForCausalLM
from trl import DPOConfig, DPOTrainer, create_reference_model

from experl.config.config_loader import ConfigLoader
from experl.config.schema.config_classes import OrchestratorConfig
from experl.logger.mlflow_logger import MLFlowLogger
from experl.trainer.base_trainer import BaseTrainer
from experl.utils.dataset_utils import fetch_dataset, get_dataset_metadata
from experl.utils.logging_utils import ExperlLogger
from experl.utils.trainer_utils import (
    create_file_path,
    get_device,
    get_model_id,
    get_tokenizer,
    get_tracking_path,
    sanitize_model,
)


log = ExperlLogger.get_logger(__name__)

class DPOModelTrainer(BaseTrainer):

    def __init__(
            self,
            config: OrchestratorConfig,
            mlflow_logger: MLFlowLogger,
    ) -> None:
        self.ref_policy = None
        self.value_model = None
        self.reward_model = None
        self.model = None
        super().__init__(
            trainer_name="dpo_model",
            config=config,
            mlflow_logger=mlflow_logger,
        )
        self.trainer_args = DPOConfig(**OmegaConf.to_container(self.config.pipeline.dpo))

    def create_trainer(self) -> None:
        self.trainer = DPOTrainer(
            self.model,
            self.ref_policy,
            args=self.trainer_args,
            train_dataset=self.train_dataset,
            eval_dataset=self.eval_dataset,
            processing_class=self.tokenizer,
        )

    def train_model(self) -> None:
        self.trainer.train()

    def load_model(self) -> None:
        self.load_policy_model()
        self.load_ref_model()

    def load_dataset(self) -> None:
        ds_config = self.config.dataset
        self.train_dataset = fetch_dataset(ds_config.preference.path,
                                           name=ds_config.preference.subset,
                                           split=ds_config.preference.train_split
                                           )
        if self.trainer_args.eval_strategy != "no":
            self.eval_dataset = fetch_dataset(ds_config.preference.path,
                                              name=ds_config.preference.subset,
                                              split=ds_config.preference.test_split
                                              )
        self.log_dataset()

    def log_dataset(self) -> None:
        self.mlflow_logger.log_dataset_metadata(get_dataset_metadata(self.train_dataset, self.tokenizer, name="train"))
        self.mlflow_logger.log_dataset(
            from_huggingface(self.train_dataset),
            context="train",
            model_id=self.config.base_model_name,
        )

        if self.eval_dataset:
            self.mlflow_logger.log_dataset_metadata(
                get_dataset_metadata(self.eval_dataset, self.tokenizer, name="test"))
            self.mlflow_logger.log_dataset(
                from_huggingface(self.eval_dataset),
                context="test",
                model_id=self.config.base_model_name,
            )

    def load_ref_model(self) -> None:
        self.ref_policy = create_reference_model(self.model)
        self.ref_policy.to(get_device())

    def load_policy_model(self) -> None:
        model_id = get_model_id(self.config.base_model_name)
        sft_model_path = create_file_path(
            self.config,
            f"sft_model/final-sft_model-{model_id}",
        )
        self.tokenizer = get_tokenizer(
            sft_model_path,
            padding_side=self.config.padding_side,
        )
        self.model = AutoModelForCausalLM.from_pretrained(
            sft_model_path,
            **self.model_kwargs
        )
        sanitize_model(self.model, self.tokenizer)
        self.model.to(get_device())

    @staticmethod
    def run(main_config: OrchestratorConfig, nested: bool =True) -> None:
        stage = "dpo"
        with MLFlowLogger(
                experiment_name=main_config.project_name,
                tracking_uri=get_tracking_path(main_config),
                run_name=f"{stage}__{main_config.run_name}",
                nested=nested,
                tags={
                    "stage": stage,
                    "run_name": f"{stage}__{main_config.run_name}",
                    "project_name": main_config.project_name,
                },
        ) as mlogger:
            # mlogger.log_args_and_overrides(args, overrides)
            model_trainer = DPOModelTrainer(main_config, mlogger)
            mlogger.log_dict(OmegaConf.to_container(main_config), "config.json")
            model_trainer.train()


if __name__ == "__main__":
    orch_config: OrchestratorConfig = ConfigLoader.build_orchestrator_config()
    DPOModelTrainer.run(orch_config)
