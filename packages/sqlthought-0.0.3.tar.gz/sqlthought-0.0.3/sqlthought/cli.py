import warnings
warnings.filterwarnings("ignore", message=".*shadows an attribute in parent.*")

import os
import click
from sqlthought.nlq.conversion import to_sql
from sqlthought.ingestion.build_db import build_sqlite_db
from sqlthought.utils.logger import logger

BASE_DIR = "sqlthought_data"
CSV_DIR = os.path.join(BASE_DIR, "csv")
DB_DIR = os.path.join(BASE_DIR, "databases")
DEFAULT_DB = os.path.join(DB_DIR, "merged.db")


# -------------------------------------------------------
# Root CLI group
# -------------------------------------------------------
@click.group()
def cli():
    """SQLThought CLI – NLQ → SQL and data ingestion tools."""
    pass


# -------------------------------------------------------
# INIT WORKSPACE
# -------------------------------------------------------
@cli.command()
def init():
    """Initialize SQLThought workspace structure."""
    os.makedirs(CSV_DIR, exist_ok=True)
    os.makedirs(DB_DIR, exist_ok=True)

    click.secho("SQLThought workspace created!", fg="green")
    click.echo(f" → Add CSV files to: {CSV_DIR}")
    click.echo(" → Then run: sqlthought build-db")
    click.echo(" → To query: sqlthought query \"your question\"")
    click.echo()
    click.secho("Your project is ready!", fg="cyan")


# -------------------------------------------------------
# BUILD DATABASE
# -------------------------------------------------------
@cli.command("build-db")
@click.argument("csv_folder", type=str)
@click.argument("output_db", type=str)
def build_db(csv_folder, output_db):
    """
    Build a SQLite database from CSV files inside the given folder.

    Usage:
        sqlthought build-db data/ company.db
    """
    from .ingestion.build_db import build_sqlite_db

    # Validate CSV folder
    if not os.path.exists(csv_folder):
        click.secho("CSV folder not found:", fg="red")
        click.echo(f"   {csv_folder}")
        return

    csv_files = [f for f in os.listdir(csv_folder) if f.endswith(".csv")]

    if not csv_files:
        click.secho("No CSV files found.", fg="red")
        click.echo(f"Place your .csv files inside: {csv_folder}")
        return

    click.secho("Building SQLite database from CSV files...", fg="yellow")

    # Ensure DB parent folder exists
    os.makedirs(os.path.dirname(output_db) or ".", exist_ok=True)

    # Build DB
    result = build_sqlite_db(csv_folder, output_db)

    click.secho("Database created successfully!", fg="green")
    click.echo(f"Location: {output_db}\n")

    click.echo("Now you can query this DB using:")
    click.secho(f'sqlthought query "your question" {output_db}', fg="cyan")



# -------------------------------------------------------
# QUERY COMMAND
# -------------------------------------------------------
@cli.command("query")
@click.argument("question", type=str)
@click.argument("db_path", type=str)
def query(question, db_path):
    """Run NLQ → SQL reasoning and execute query on DB."""
    from sqlthought.nlq.conversion import to_sql

    if not os.path.exists(db_path):
        click.secho("Database not found.", fg="red")
        click.echo("Run: sqlthought build-db")
        return
    
    click.secho("🔍 Executing NLQ → SQL pipeline...", fg="blue")
    result = to_sql(question, db_path)

    click.echo("\n=== SQLThought Result ===")
    click.echo(f"SQL: {result.get('sql')}")
    click.echo(f"Success: {result.get('success')}")
    click.echo(f"Result: {result.get('result')}")


