"""
FastMCP-specific middleware for d402 payment protocol.

This module contains middleware classes for standalone FastMCP package.
These are NOT used with the official MCP SDK - see starlette_middleware.py instead.

DEPRECATED: Use starlette_middleware.py for official MCP SDK.
This file is kept for backwards compatibility with standalone fastmcp package.
"""

import logging
import os
from typing import Optional

from starlette.requests import Request
from starlette.responses import JSONResponse

from .types import PaymentPayload
from .encoding import safe_base64_decode
from .facilitator import IATPSettlementFacilitator

logger = logging.getLogger(__name__)

# Import FastMCP middleware classes (only available with standalone fastmcp)
try:
    from fastmcp.server.middleware import Middleware, MiddlewareContext
    FASTMCP_AVAILABLE = True
except ImportError:
    # FastMCP not available - this module won't work
    logger.warning("Standalone fastmcp not available - fastmcp_middleware.py will not work")
    logger.warning("Use starlette_middleware.py for official MCP SDK instead")
    Middleware = None
    MiddlewareContext = None
    FASTMCP_AVAILABLE = False


class D402PaymentRequiredException(Exception):
    """Exception raised when payment is required (HTTP 402)."""
    def __init__(self, payment_response: dict):
        self.payment_response = payment_response
        super().__init__("Payment required")


if FASTMCP_AVAILABLE and Middleware is not None:
    class D402MCPMiddleware(Middleware):
        """
        HTTP 402 Payment Required middleware for standalone FastMCP servers.
        
        DEPRECATED: Use D402PaymentMiddleware from starlette_middleware.py for official MCP SDK.
        
        This is kept for backwards compatibility with standalone fastmcp package.
        """
        
        def __init__(
            self,
            server_address: str,
            facilitator_url: Optional[str] = None,
            facilitator_api_key: Optional[str] = None,
            verify_signatures: bool = True,
            testing_mode: bool = False,
            requires_auth: bool = False,
            internal_api_key_env_var: Optional[str] = None
        ):
            super().__init__()
            
            self.server_address = server_address
            self.facilitator_url = facilitator_url or os.getenv("D402_FACILITATOR_URL", "https://facilitator.d402.net")
            self.facilitator_api_key = facilitator_api_key or os.getenv("D402_FACILITATOR_API_KEY")
            self.verify_signatures = verify_signatures
            self.testing_mode = testing_mode or os.getenv("D402_TESTING_MODE", "false").lower() == "true"
            self.requires_auth = requires_auth
            self.internal_api_key_env_var = internal_api_key_env_var
            
            # Initialize facilitator
            self.facilitator = None
            if not self.testing_mode:
                try:
                    operator_private_key = os.getenv("MCP_OPERATOR_PRIVATE_KEY") or os.getenv("OPERATOR_PRIVATE_KEY")
                    self.facilitator = IATPSettlementFacilitator(
                        relayer_url=self.facilitator_url,
                        relayer_api_key=self.facilitator_api_key,
                        provider_operator_key=operator_private_key,
                        facilitator_url=self.facilitator_url,
                        facilitator_api_key=self.facilitator_api_key
                    )
                except Exception as e:
                    logger.warning(f"Could not initialize facilitator: {e}")
                    self.testing_mode = True
            
            logger.info(f"D402 MCP Middleware initialized (FastMCP - deprecated)")
        
        async def on_request(self, context: MiddlewareContext, call_next):
            """FastMCP middleware on_request handler."""
            # Full implementation would go here
            # For now, just pass through
            logger.warning("D402MCPMiddleware for standalone fastmcp is deprecated")
            logger.warning("Use D402PaymentMiddleware from starlette_middleware.py instead")
            return await call_next(context)
    
    
    def create_d402_mcp_middleware(
        server_address: Optional[str] = None,
        facilitator_url: Optional[str] = None,
        facilitator_api_key: Optional[str] = None,
        verify_signatures: bool = True,
        testing_mode: bool = False,
        requires_auth: bool = False,
        internal_api_key_env_var: Optional[str] = None
    ) -> D402MCPMiddleware:
        """
        Create d402 middleware for standalone FastMCP.
        
        DEPRECATED: Use D402PaymentMiddleware from starlette_middleware.py for official MCP SDK.
        """
        server_address = (
            server_address or 
            os.getenv("SERVER_ADDRESS") or 
            os.getenv("PAYMENT_ADDRESS") or 
            os.getenv("EVM_ADDRESS")
        )
        if not server_address:
            raise ValueError("server_address is required")
        
        return D402MCPMiddleware(
            server_address=server_address,
            facilitator_url=facilitator_url,
            facilitator_api_key=facilitator_api_key,
            verify_signatures=verify_signatures,
            testing_mode=testing_mode,
            requires_auth=requires_auth,
            internal_api_key_env_var=internal_api_key_env_var
        )

else:
    # FastMCP not available - create stub
    class D402MCPMiddleware:
        """Stub class when FastMCP not available."""
        def __init__(self, *args, **kwargs):
            raise ImportError("Standalone fastmcp not available. Use starlette_middleware.py for official MCP SDK.")
    
    def create_d402_mcp_middleware(*args, **kwargs):
        """Stub function when FastMCP not available."""
        raise ImportError("Standalone fastmcp not available. Use starlette_middleware.py for official MCP SDK.")


__all__ = ["D402MCPMiddleware", "D402PaymentRequiredException", "create_d402_mcp_middleware"]

