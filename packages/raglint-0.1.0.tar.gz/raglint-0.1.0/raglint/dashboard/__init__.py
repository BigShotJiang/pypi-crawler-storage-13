"""
RAGLint Dashboard Module.
"""
