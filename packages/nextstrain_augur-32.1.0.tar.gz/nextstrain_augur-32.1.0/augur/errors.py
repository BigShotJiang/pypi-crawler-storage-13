class AugurError(Exception):
    pass
