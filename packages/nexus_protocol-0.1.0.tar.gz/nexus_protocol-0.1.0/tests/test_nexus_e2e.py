import pytest
import numpy as np
import torch
import logging
from nexus.protocol import TensorPacket
from nexus.adapter import LatentBridge, InverseBridge

# Configure logger for tests
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_thought_transfer_e2e():
    """
    Simulates a full 'Thought Transfer' between two different simulated AI models.
    
    Flow:
    Source (768d) -> LatentBridge -> Universal (512d) -> TOON -> Universal (512d) -> InverseBridge -> Target (1024d)
    """
    
    # ==========================================
    # 1. SETUP
    # ==========================================
    logger.info("--- Phase 1: Setup & Initialization ---")
    
    source_dim = 768
    universal_dim = 512
    target_dim = 1024
    
    # Simulate Source Model generating a "thought"
    # We use a random vector to represent the hidden state of "Hello World"
    source_thought_vector = np.random.randn(1, source_dim).astype(np.float32)
    logger.info(f"Source Generated Thought Vector: {source_thought_vector.shape}")

    # Initialize Bridges with random weights (simulating untrained but functional adaptors)
    # Note: In a real scenario, we would load_state_dict here.
    source_bridge = LatentBridge(input_dim=source_dim, universal_dim=universal_dim)
    target_bridge = InverseBridge(universal_dim=universal_dim, target_dim=target_dim)
    
    # Set to eval mode (good practice even with random weights)
    source_bridge.eval()
    target_bridge.eval()

    # ==========================================
    # 2. THE ACTION (Pipeline Execution)
    # ==========================================
    logger.info("--- Phase 2: Execution (Source -> Wire -> Target) ---")

    # Step A: Source Projection (Source -> Universal)
    # Convert numpy to torch for the network
    source_tensor = torch.from_numpy(source_thought_vector)
    
    with torch.no_grad():
        universal_tensor_out = source_bridge(source_tensor)
    
    universal_array_out = universal_tensor_out.numpy()
    logger.info(f"Projected to Universal Space: {universal_array_out.shape}")
    
    # Step B: Packetization (Universal -> TOON)
    packet = TensorPacket.from_array(
        source="simulated-source-768",
        target="simulated-target-1024",
        intent="greeting_transfer",
        array=universal_array_out
    )
    
    toon_message = packet.to_toon()
    logger.info(f"Serialized to TOON (Length: {len(toon_message)} chars)")
    logger.debug(f"TOON Content:\n{toon_message}")

    # Step C: Network Transmission Simulation
    # (Here we just pass the string variable, representing the wire)
    received_toon_message = toon_message

    # Step D: Deserialization (TOON -> Universal)
    received_packet = TensorPacket.from_toon(received_toon_message)
    universal_array_in = received_packet.to_array()
    logger.info(f"Deserialized from TOON: {universal_array_in.shape}")

    # Step E: Target Projection (Universal -> Target)
    universal_tensor_in = torch.from_numpy(universal_array_in)
    
    with torch.no_grad():
        target_thought_vector = target_bridge(universal_tensor_in)
    
    logger.info(f"Projected to Target Space: {target_thought_vector.shape}")

    # ==========================================
    # 3. VERIFICATION
    # ==========================================
    logger.info("--- Phase 3: Verification ---")

    # 3.1 Metadata Integrity
    assert received_packet.source_model == "simulated-source-768"
    assert received_packet.target_model == "simulated-target-1024"
    assert received_packet.intent == "greeting_transfer"
    assert received_packet.dtype == "float32"
    
    # 3.2 Dimensionality Flow Check
    # Source: [1, 768]
    assert source_thought_vector.shape == (1, source_dim)
    
    # Universal (Out): [1, 512]
    assert universal_array_out.shape == (1, universal_dim)
    
    # Universal (In): [1, 512]
    assert universal_array_in.shape == (1, universal_dim)
    
    # Target: [1, 1024]
    assert target_thought_vector.shape == (1, target_dim)

    # 3.3 Data Integrity Check (Lossless Transport)
    # The transport layer (Array -> Compress -> Base64 -> TOON -> Base64 -> Decompress -> Array)
    # must be numerically exact.
    np.testing.assert_array_almost_equal(
        universal_array_out, 
        universal_array_in, 
        decimal=6, 
        err_msg="Transport layer introduced numerical errors!"
    )
    logger.info("SUCCESS: Transport layer is lossless.")

    # 3.4 TOON Format Validation
    # Basic check to ensure it looks like the spec
    lines = received_toon_message.split('\n')
    assert lines[0].startswith("TensorPacket[1]"), "Invalid TOON Header"
    assert len(lines) >= 2, "TOON message missing body"
    
    # 3.5 Pipeline Completion
    logger.info(f"Final Target Vector Stats: Mean={target_thought_vector.mean().item():.4f}, Std={target_thought_vector.std().item():.4f}")
    logger.info("SUCCESS: Full End-to-End Thought Transfer simulated successfully.")

if __name__ == "__main__":
    # allow running directly with python
    test_thought_transfer_e2e()

