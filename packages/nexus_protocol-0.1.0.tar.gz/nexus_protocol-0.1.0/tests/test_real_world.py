import unittest
import logging
import torch
import json
import sys
from nexus.client import NexusClient
from nexus.protocol import TensorPacket
from nexus.adapter import InverseBridge

# --- Configure Logging ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("NexusQA")

class TestRealWorldTelepathy(unittest.TestCase):
    """
    End-to-End Simulation of Direct Latent Space Communication (Telepathy).
    Simulates a full cycle: Thought -> Encode -> Transport -> Decode -> Inject -> Generate.
    """

    @classmethod
    def setUpClass(cls):
        """
        Initialize models once for all tests to save time.
        Uses lightweight models (gpt2) for CI/CPU compatibility.
        """
        cls.device = "cuda" if torch.cuda.is_available() else "cpu"
        logger.info(f"🚀 Starting Test Suite on Device: {cls.device.upper()}")

        # Use lightweight models for testing
        cls.sender_model_name = "gpt2" 
        cls.receiver_model_name = "distilgpt2"
        
        # NOTE: For Real World testing with Llama-3:
        # cls.sender_model_name = "meta-llama/Meta-Llama-3-8B"
        # cls.receiver_model_name = "mistralai/Mistral-7B-v0.1"

        # --- SENDER SETUP ---
        logger.info(f"🧠 Initializing Sender ({cls.sender_model_name})...")
        try:
            # Disable 4-bit if on CPU to avoid bitsandbytes errors
            use_4bit = (cls.device == "cuda")
            cls.sender = NexusClient(cls.sender_model_name, use_4bit=use_4bit)
        except ImportError as e:
            if "bitsandbytes" in str(e):
                logger.warning("⚠️ bitsandbytes not found. Falling back to standard precision.")
                cls.sender = NexusClient(cls.sender_model_name, use_4bit=False)
            else:
                raise e

        # --- RECEIVER SETUP ---
        # Note: nexus.receiver.NexusReceiver is expected to exist based on previous context, 
        # but if not, we will mock the receiver logic using the raw model and InverseBridge here 
        # to ensure the test is self-contained and tests the CORE logic requested.
        # However, since the prompt asks to test the workflow, we'll implement the receiver logic 
        # directly in the test if a dedicated Receiver class isn't fully hardened yet, 
        # OR assuming we need to instantiate the InverseBridge manually as per instructions.
        
        logger.info(f"👾 Initializing Receiver ({cls.receiver_model_name})...")
        from transformers import AutoModelForCausalLM, AutoTokenizer
        
        cls.receiver_tokenizer = AutoTokenizer.from_pretrained(cls.receiver_model_name)
        cls.receiver_model = AutoModelForCausalLM.from_pretrained(cls.receiver_model_name).to(cls.device)
        
        # Initialize Inverse Bridge (Universal 2048 -> Receiver Hidden Size)
        receiver_hidden_size = cls.receiver_model.config.hidden_size
        cls.inverse_bridge = InverseBridge(universal_dim=2048, target_dim=receiver_hidden_size).to(cls.device)
        cls.inverse_bridge.eval() # We aren't training, just testing the pass-through

    def test_telepathy_cycle(self):
        """
        Simulates transmitting the concept "The sky is blue" from Sender to Receiver.
        """
        logger.info("--- TEST: Full Telepathy Cycle ---")

        # 1. ENCODE THOUGHT (Sender)
        input_text = "The sky is blue"
        logger.info(f"💭 Sender thinking: '{input_text}'")
        
        universal_vector = self.sender.encode_thought(input_text)
        
        # Assertion: Check shape [1, 2048] (Default Nexus Dim)
        self.assertEqual(universal_vector.shape[1], 2048, "Universal Vector dimension mismatch!")
        
        # Assertion: Check Normalization (L2 Norm should be approx 1.0 due to F.normalize)
        norm = torch.norm(universal_vector, p=2).item()
        logger.info(f"📏 Vector Norm: {norm:.4f}")
        self.assertAlmostEqual(norm, 1.0, places=2, msg="Sender output is not normalized!")

        # 2. PACKETIZE (Transport)
        packet = TensorPacket.from_tensor(
            sender_name="Test-Sender-GPT2",
            tensor=universal_vector,
            intent="environmental_fact"
        )
        
        json_payload = packet.model_dump_json()
        payload_size = len(json_payload)
        logger.info(f"📦 Packet Serialized. Size: {payload_size} bytes")
        
        # Assertion: Verify JSON structure
        parsed_json = json.loads(json_payload)
        self.assertEqual(parsed_json["sender"], "Test-Sender-GPT2")
        self.assertEqual(parsed_json["intent"], "environmental_fact")
        self.assertEqual(parsed_json["vector_dim"], 2048)
        self.assertEqual(len(parsed_json["payload"]), 2048, "Payload list length mismatch!")

        # 3. RECEIVE & DECODE (Receiver)
        # Simulate wire transfer by parsing JSON back to object
        received_packet = TensorPacket.model_validate_json(json_payload)
        
        # Convert List -> Tensor -> GPU
        received_tensor_list = received_packet.payload
        received_tensor = torch.tensor(received_tensor_list, dtype=torch.float32).to(self.device)
        received_tensor = received_tensor.unsqueeze(0) # Add batch dimension [1, 2048]
        
        logger.info("Rx: Packet received and tensorized.")

        # 4. INJECT (Inverse Bridge -> Model)
        with torch.no_grad():
            # Project Universal (2048) -> Target Model Space (768 for distilgpt2)
            projected_embedding = self.inverse_bridge(received_tensor)
            
        expected_target_dim = self.receiver_model.config.hidden_size
        logger.info(f"🔄 Projected Shape: {projected_embedding.shape} (Expected Last Dim: {expected_target_dim})")
        
        self.assertEqual(projected_embedding.shape[-1], expected_target_dim, "Inverse Bridge projection failed!")

        # 5. GENERATE (The "Telepathy")
        logger.info("💉 Injecting thought vector into Receiver Model...")
        
        # We use inputs_embeds to feed the vector directly. 
        # Usually, we prepend a BOS token so the model knows where to start.
        if self.receiver_tokenizer.bos_token_id:
            bos_id = self.receiver_tokenizer.bos_token_id
        else:
            bos_id = self.receiver_tokenizer.eos_token_id # Fallback
            
        bos_tensor = torch.tensor([[bos_id]], device=self.device)
        bos_embedding = self.receiver_model.transformer.wte(bos_tensor) # specific to GPT2 architecture
        
        # Concatenate: [BOS] + [INJECTED_VECTOR]
        # Shape: [1, 2, hidden_dim]
        inputs_embeds = torch.cat((bos_embedding, projected_embedding.unsqueeze(1)), dim=1)
        
        # Generate
        output_ids = self.receiver_model.generate(
            inputs_embeds=inputs_embeds,
            max_new_tokens=10,
            pad_token_id=self.receiver_tokenizer.eos_token_id,
            do_sample=True
        )
        
        generated_text = self.receiver_tokenizer.decode(output_ids[0], skip_special_tokens=True)
        
        logger.info(f"🗣️ Receiver Verbalized: '{generated_text}'")
        
        # Assertion: It produced SOMETHING
        self.assertTrue(len(generated_text) > 0, "Receiver failed to generate text from thought vector!")
        logger.info("✅ Test Cycle Complete: SUCCESS")

if __name__ == "__main__":
    unittest.main()

