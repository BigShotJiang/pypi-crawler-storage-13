import torch
import torch.nn as nn
import torch.nn.functional as F

class NexusBridge(nn.Module):
    """
    The Universal Translator Layer.
    Maps specific Model Latent Spaces -> Universal Nexus Space.
    """
    def __init__(self, input_dim: int, output_dim: int = 2048):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        
        # Architecture derived from Colab V6 experiments
        # Linear -> LayerNorm -> GELU -> Linear proved most stable
        self.adapter = nn.Sequential(
            nn.Linear(input_dim, output_dim),
            nn.LayerNorm(output_dim), 
            nn.GELU(),
            nn.Linear(output_dim, output_dim)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # CRITICAL FIX: Llama-3 4-bit outputs Float16. 
        # We must cast to Float32 before entering the bridge layer.
        x = x.float()
        
        # Pass through the bridge
        out = self.adapter(x)
        
        # CRITICAL FIX: Normalize output to ensuring Cosine Similarity 
        # is strictly between -1.0 and 1.0 (0-100% confidence).
        return F.normalize(out, p=2, dim=1)

    def save(self, path: str):
        torch.save(self.state_dict(), path)

    def load(self, path: str):
        self.load_state_dict(torch.load(path))

# Add this to the bottom of nexus/adapter.py

class InverseBridge(nn.Module):
    """
    The Receiver's Translator.
    Maps Universal Nexus Space (2048) -> Specific Model Space (e.g. 4096).
    """
    def __init__(self, universal_dim: int = 2048, target_dim: int = 4096):
        super().__init__()
        # Reverse architecture: Expand from Universal to Model logic
        self.adapter = nn.Sequential(
            nn.Linear(universal_dim, target_dim),
            nn.LayerNorm(target_dim), 
            nn.GELU(),
            nn.Linear(target_dim, target_dim)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Input is Universal Vector (Float32)
        x = x.float() 
        out = self.adapter(x)
        # Note: We do NOT normalize here. 
        # The target model expects specific magnitude vectors (hidden states),
        # not normalized unit vectors.
        return out