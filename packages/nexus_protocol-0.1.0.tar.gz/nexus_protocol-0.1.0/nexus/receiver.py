import torch
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from typing import Optional
import logging

from nexus.protocol import TensorPacket
from nexus.adapter import InverseBridge

# Configure logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("NexusReceiver")

class NexusReceiver:
    def __init__(self, model_name: str, bridge_path: Optional[str] = None):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model_name = model_name
        self.universal_dim = 2048

        logger.info(f"📥 Loading receiving brain: {model_name} on {self.device}...")

        # 1. MEMORY FIX: Load in 4-bit to prevent OOM
        if self.device == "cuda":
            bnb_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_quant_type="nf4",
            )
            self.model = AutoModelForCausalLM.from_pretrained(
                model_name,
                quantization_config=bnb_config,
                device_map="auto",
                trust_remote_code=True
            )
        else:
            self.model = AutoModelForCausalLM.from_pretrained(model_name).to(self.device)

        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.target_dim = self.model.config.hidden_size
        
        # 2. Initialize Inverse Bridge
        self.bridge = InverseBridge(
            universal_dim=self.universal_dim, 
            target_dim=self.target_dim
        ).to(self.device)
        
        if bridge_path:
            logger.info(f"Loading weights from {bridge_path}")
            self.bridge.load_state_dict(torch.load(bridge_path, map_location=self.device))
        
        self.bridge.eval()

    def receive_thought(self, toon_json: str, max_new_tokens: int = 20) -> str:
        """
        Decodes a TOON packet and generates text via Vector Injection.
        """
        # 1. Parse JSON (Using Pydantic built-in)
        try:
            packet = TensorPacket.model_validate_json(toon_json)
        except Exception as e:
            logger.error(f"Packet decoding failed: {e}")
            return "Error: Corrupt transmission."

        logger.info(f"🧠 Receiving intent '{packet.intent}' from {packet.sender}")

        with torch.no_grad():
            # 2. Reconstruct Tensor from List
            universal_array = np.array(packet.payload, dtype=np.float32)
            universal_tensor = torch.from_numpy(universal_array).to(self.device)
            
            # Ensure shape (1, dim)
            if universal_tensor.ndim == 1:
                universal_tensor = universal_tensor.unsqueeze(0)
            
            # 3. Project to Target Space (Universal -> Llama Space)
            projected_embedding = self.bridge(universal_tensor) # Outputs Float32

            # 4. TYPE FIX: Cast to Model's Dtype (Float16)
            # If we don't do this, it crashes mixing Float32 and Float16
            target_dtype = self.model.dtype
            projected_embedding = projected_embedding.to(target_dtype)

            # 5. Prompt Injection (The "Virtual Token" Strategy)
            inputs_embeds = projected_embedding.unsqueeze(1) # (1, 1, dim)

            # Add BOS Token (Start of Sentence)
            if self.tokenizer.bos_token_id is not None:
                bos_tensor = torch.tensor([[self.tokenizer.bos_token_id]], device=self.device)
                bos_embeds = self.model.get_input_embeddings()(bos_tensor)
                
                # Concat: [BOS] + [INJECTED_THOUGHT]
                inputs_embeds = torch.cat([bos_embeds, inputs_embeds], dim=1)

            logger.info("⚡ Injecting neural pattern into generation context...")
            
            # 6. Generate Response
            outputs = self.model.generate(
                inputs_embeds=inputs_embeds,
                max_new_tokens=max_new_tokens,
                do_sample=True,
                temperature=0.7,
                pad_token_id=self.tokenizer.eos_token_id
            )
            
            # Decode
            return self.tokenizer.decode(outputs[0], skip_special_tokens=True)