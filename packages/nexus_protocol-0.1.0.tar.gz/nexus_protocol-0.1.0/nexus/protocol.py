from pydantic import BaseModel
from typing import List
import time
import torch

class TensorPacket(BaseModel):
    """
    The TOON-compliant Data Structure.
    This is what actually gets sent over the wire.
    """
    protocol: str = "nexus_v1"
    sender: str
    target: str = "broadcast"
    intent: str = "semantic_transfer"
    timestamp: float
    vector_dim: int
    payload: List[float] # The raw thought vector

    @classmethod
    def from_tensor(cls, sender_name: str, tensor: torch.Tensor, intent: str = "general"):
        """
        Helper to convert a PyTorch tensor directly into a Packet
        """
        # Ensure we are working with a flat list of floats
        if isinstance(tensor, torch.Tensor):
            # Detach from graph -> Move to CPU -> Cast to Float32 -> Numpy -> Flatten -> List
            clean_list = tensor.detach().cpu().float().numpy().flatten().tolist()
        else:
            clean_list = tensor
            
        return cls(
            sender=sender_name,
            timestamp=time.time(),
            intent=intent,
            vector_dim=len(clean_list),
            payload=clean_list
        )