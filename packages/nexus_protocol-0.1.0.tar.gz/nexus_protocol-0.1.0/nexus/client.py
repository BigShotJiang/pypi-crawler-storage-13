import torch
from transformers import AutoModel, AutoTokenizer, BitsAndBytesConfig
from .adapter import NexusBridge
from typing import Optional

class NexusClient:
    """
    The Agent's interface to the Nexus Network.
    Handles Model loading, Tokenization, and Bridging.
    """
    def __init__(self, model_name: str, use_4bit: bool = True):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model_name = model_name
        
        print(f"🔌 Nexus Client connecting to brain: {model_name}...")
        
        # CRITICAL FIX: 4-bit Quantization Config for Consumer Hardware
        if use_4bit and self.device == "cuda":
            bnb_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_quant_type="nf4",
            )
            # device_map="auto" is required to prevent MetaTensor errors
            self.model = AutoModel.from_pretrained(
                model_name,
                quantization_config=bnb_config,
                device_map="auto", 
                trust_remote_code=True
            )
        else:
            self.model = AutoModel.from_pretrained(model_name).to(self.device)

        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        
        # Fix missing pad token for Llama/Mistral
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
            
        # Initialize an empty bridge (Must be trained or loaded later)
        # Default Universal Dimension is 2048
        hidden_size = self.model.config.hidden_size
        self.bridge = NexusBridge(input_dim=hidden_size, output_dim=2048).to(self.device)

    def encode_thought(self, text: str) -> torch.Tensor:
        """
        Converts Text -> Model Vector -> Nexus Vector
        """
        inputs = self.tokenizer(
            [text], 
            return_tensors="pt", 
            padding=True, 
            truncation=True
        ).to(self.model.device)

        with torch.no_grad():
            outputs = self.model(**inputs, output_hidden_states=True)
            
            # EOS Token Pooling Strategy (Matches Colab V6)
            hidden_states = outputs.last_hidden_state
            
            # Use the vector of the last token (EOS strategy)
            # This represents the "conclusion" of the thought
            vector = hidden_states[:, -1, :] 
            
            # Pass through the Nexus Bridge (Auto-casts to float32 inside)
            nexus_packet = self.bridge(vector)
            
        return nexus_packet

    def load_bridge(self, path: str):
        print(f"🌉 Loading Nexus Bridge weights from {path}...")
        self.bridge.load(path)