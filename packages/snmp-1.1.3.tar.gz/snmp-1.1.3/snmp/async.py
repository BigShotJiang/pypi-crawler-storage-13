import asyncio

from snmp.scheduler import *
from snmp.transport.udp import *
from snmp.v1.manager import *

transport = UdpIPv4Socket()
manager = SNMPv1Manager

class PrintTask(SchedulerTask):
    
            print("Yielding")

scheduler = Scheduler(asyncio.sleep, async_wait = True)
scheduler.schedule(
