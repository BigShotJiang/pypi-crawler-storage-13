import asyncio

class AsyncUdpMultiplexor(TransportMultiplexor):
    def register(self, sock, listener):
        # create a task to listen on this socket and call back to listener

    def close(self):
        pass
