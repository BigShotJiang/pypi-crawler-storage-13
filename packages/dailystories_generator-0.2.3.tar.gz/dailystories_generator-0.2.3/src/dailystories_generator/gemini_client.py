"""Gemini API client for text and image generation."""

import asyncio
import base64
from pathlib import Path
from typing import Optional, Any
import google.generativeai as genai
import google.ai.generativelanguage as glm

from dailystories_generator.models import ReferenceImage


# Gemini finish reason mapping
FINISH_REASON_NAMES = {
    0: "FINISH_REASON_UNSPECIFIED",
    1: "STOP",
    2: "MAX_TOKENS",
    3: "SAFETY",
    4: "RECITATION",
    5: "OTHER",
    6: "LANGUAGE",
    7: "BLOCKLIST",
    8: "PROHIBITED_CONTENT",
    9: "SPII",
    10: "MALFORMED_FUNCTION_CALL",
    11: "IMAGE_SAFETY",
}


def create_white_pixel_image() -> bytes:
    """Create a 1x1 white pixel PNG image as a fallback."""
    # PNG header + IHDR + IDAT + IEND chunks for 1x1 white pixel
    return base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="
    )


class GeminiClient:
    """Client for interacting with Google's Gemini API."""
    
    def __init__(self, api_key: str):
        """
        Initialize the Gemini client.
        
        Args:
            api_key: Google API key for Gemini
        """
        self.api_key = api_key
        genai.configure(api_key=api_key)  # type: ignore[attr-defined]
    
    async def generate_text(
        self,
        prompt: str,
        system_prompt: str,
        model: str = "gemini-2.5-flash",
        max_tokens: int = 1000,
    ) -> tuple[str, int]:
        """
        Generate text using Gemini.
        
        Args:
            prompt: The user prompt
            system_prompt: The system instruction
            model: The Gemini model to use
            max_tokens: Maximum tokens (kept for compatibility, not directly used by Gemini)
        
        Returns:
            Tuple of (generated_text, total_tokens)
        """
        gemini_model = genai.GenerativeModel(model)  # type: ignore[attr-defined]
        full_prompt = f"{system_prompt}\n\n{prompt}"
        
        # Count prompt tokens
        prompt_tokens_response = await gemini_model.count_tokens_async(full_prompt)
        prompt_tokens = prompt_tokens_response.total_tokens
        
        # Generate content
        response = await gemini_model.generate_content_async(full_prompt)
        
        try:
            # Extract text and count output tokens
            response_text = response.text
            response_tokens_response = await gemini_model.count_tokens_async(response_text)
            response_tokens = response_tokens_response.total_tokens
        except Exception as e:
            print(f"Error counting tokens: {e}")
            response_tokens = 0
        
        return response_text, prompt_tokens + response_tokens
    
    async def generate_image(
        self,
        content_parts: list[str | dict[str, Any]],
        system_instruction: str,
        model: str = "gemini-2.5-flash-image",
    ) -> tuple[bytes, int]:
        """
        Generate an image using Gemini with system instruction.
        
        Args:
            content_parts: List of content parts (images, text) to pass to the model
            system_instruction: System instruction text
            model: The Gemini image model to use
        
        Returns:
            Tuple of (image_bytes, tokens_used)
            Returns a 1x1 white pixel image if generation fails after all retries
        """
        # Create model with system instruction
        gemini_model = genai.GenerativeModel(  # type: ignore[attr-defined]
            model,
            system_instruction=system_instruction,
        )
        
        max_retries = 3
        retry_delay = 2  # seconds
        last_response = None
        last_error = None
        
        for attempt in range(max_retries):
            try:
                # Generate image
                response = await gemini_model.generate_content_async(contents=content_parts)
                last_response = response
                
                # Check if response was blocked by safety filters
                if hasattr(response, "prompt_feedback") and response.prompt_feedback:
                    feedback = response.prompt_feedback
                    block_reason = getattr(feedback, "block_reason", None)
                    if block_reason:
                        print(f"ERROR: Gemini blocked the request. Block reason: {block_reason}")
                        if hasattr(feedback, "safety_ratings"):
                            print(f"Safety ratings: {feedback.safety_ratings}")
                        # Don't retry on safety blocks - return white pixel immediately
                        print("⚠️  Returning 1x1 white pixel due to safety block")
                        return create_white_pixel_image(), 0
                
                # Extract image data from response
                raw_image_data = None
                if hasattr(response, "parts"):
                    for part in response.parts:
                        if hasattr(part, "inline_data") and part.inline_data:
                            raw_image_data = part.inline_data.data
                            break
                
                # If we got image data, success!
                if raw_image_data:
                    return raw_image_data, 1
                
                # Check for finish reason 15 (unknown error) or other retry-worthy reasons
                should_retry = False
                finish_reason_code = None
                if hasattr(response, "candidates") and response.candidates:
                    for candidate in response.candidates:
                        if hasattr(candidate, "finish_reason"):
                            finish_reason_code = candidate.finish_reason
                            # Retry on finish reason 15 (unknown/internal error)
                            if finish_reason_code == 15:
                                should_retry = True
                                break
                
                # Retry if we didn't get image data and should retry
                if should_retry and attempt < max_retries - 1:
                    finish_reason_name = FINISH_REASON_NAMES.get(finish_reason_code, f"UNKNOWN({finish_reason_code})")
                    print(f"⚠️  Finish reason {finish_reason_code} ({finish_reason_name}) detected (attempt {attempt + 1}/{max_retries}). Retrying in {retry_delay}s...")
                    await asyncio.sleep(retry_delay)
                    continue
                
                # If we get here and no image data, we'll fall through to detailed logging
                if not raw_image_data:
                    break
                
            except Exception as e:
                last_error = e
                if attempt < max_retries - 1:
                    print(f"⚠️  Exception during image generation (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {retry_delay}s...")
                    await asyncio.sleep(retry_delay)
                    continue
                else:
                    # Last attempt failed with exception
                    print(f"ERROR: All {max_retries} attempts failed with exception: {e}")
                    import traceback
                    traceback.print_exc()
        
        # If we get here, all retries failed - log detailed info and return white pixel
        print(f"ERROR: Image generation failed after {max_retries} attempt(s).")
        
        if last_response:
            # Log prompt feedback
            if hasattr(last_response, "prompt_feedback"):
                feedback = last_response.prompt_feedback
                print(f"  Prompt Feedback: {feedback}")
                if hasattr(feedback, "block_reason"):
                    print(f"  Block Reason: {feedback.block_reason}")
                if hasattr(feedback, "safety_ratings"):
                    print(f"  Safety Ratings: {feedback.safety_ratings}")
            
            # Log candidates with decoded finish reasons
            if hasattr(last_response, "candidates") and last_response.candidates:
                print(f"  Number of candidates: {len(last_response.candidates)}")
                for i, candidate in enumerate(last_response.candidates):
                    print(f"  Candidate {i}:")
                    if hasattr(candidate, "finish_reason"):
                        finish_reason_code = candidate.finish_reason
                        finish_reason_name = FINISH_REASON_NAMES.get(
                            finish_reason_code, 
                            f"UNKNOWN({finish_reason_code})"
                        )
                        print(f"    Finish Reason: {finish_reason_code} ({finish_reason_name})")
                        
                        # Provide context for specific finish reasons
                        if finish_reason_code == 3:  # SAFETY
                            print(f"    ⚠️  Generation blocked due to safety filters")
                        elif finish_reason_code == 11:  # IMAGE_SAFETY
                            print(f"    ⚠️  Image generation blocked due to image safety filters")
                        elif finish_reason_code == 8:  # PROHIBITED_CONTENT
                            print(f"    ⚠️  Content blocked due to policy violations")
                        elif finish_reason_code == 15:  # Unknown/Internal error
                            print(f"    ⚠️  Unknown error - possibly an internal Gemini issue")
                        elif finish_reason_code not in FINISH_REASON_NAMES:
                            print(f"    ⚠️  Unknown finish reason - possibly a rate limit, quota issue, or internal error")
                    
                    if hasattr(candidate, "safety_ratings"):
                        print(f"    Safety Ratings: {candidate.safety_ratings}")
                    if hasattr(candidate, "content"):
                        content = candidate.content
                        if hasattr(content, "parts"):
                            print(f"    Parts count: {len(list(content.parts))}")
                            for j, part in enumerate(content.parts):
                                if hasattr(part, "text"):
                                    print(f"      Part {j} (text): {part.text[:100]}...")
                                elif hasattr(part, "inline_data"):
                                    print(f"      Part {j}: inline_data present")
                                else:
                                    print(f"      Part {j}: {type(part)}")
                        else:
                            print(f"    Content has no parts")
            else:
                print("  No candidates in response")
            
            # Check usage metadata
            if hasattr(last_response, "usage_metadata"):
                print(f"  Usage Metadata: {last_response.usage_metadata}")
        
        if last_error:
            print(f"  Last exception: {last_error}")
        
        # Return white pixel image as fallback
        print("⚠️  Returning 1x1 white pixel as fallback")
        return create_white_pixel_image(), 0


# Import Any for type hints moved to top
