# veriskgo/trace_manager.py
from __future__ import annotations
import threading
import uuid
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional, List


class TraceManager:
    """Central controller for a single active trace in the process."""

    _lock = threading.Lock()
    _active: Dict[str, Any] = {
        "trace_id": None,
        "spans": [],
        "stack": [],
    }

    # ------------------------------
    # Helpers
    # ------------------------------
    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _id() -> str:
        return str(uuid.uuid4())

    # ------------------------------
    # Trace Lifecycle
    # ------------------------------
    @classmethod
    def start_trace(cls, name: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """Start a new trace and reset previous state."""
        with cls._lock:
            trace_id = cls._id()
            root_id = cls._id()

            root_span = {
                "span_id": root_id,
                "parent_span_id": None,
                "name": name,
                "type": "root",
                "timestamp": cls._now(),
                "input": "",
                "output": "",
                "metadata": metadata or {},
                "usage": {},
                "duration_ms": 0,
                "success": True,
            }

            cls._active["trace_id"] = trace_id
            cls._active["spans"] = [root_span]
            cls._active["stack"] = [{"span_id": root_id, "start": time.time()}]

            return trace_id

    # ------------------------------
    # Span Creation
    # ------------------------------
    @classmethod
    def start_span(cls, name: str, input: Optional[str] = None) -> str:
        """Create a new child span and push it to the stack."""
        with cls._lock:
            if not cls._active["stack"]:
                # No root? Ignore silently.
                return cls._id()

            parent = cls._active["stack"][-1]["span_id"]
            sid = cls._id()

            span = {
                "span_id": sid,
                "parent_span_id": parent,
                "name": name,
                "type": "child",
                "timestamp": cls._now(),
                "input": input or "",
                "output": "",
                "metadata": {},
                "usage": {},
                "duration_ms": 0,
                "success": True,
            }

            cls._active["spans"].append(span)
            cls._active["stack"].append({"span_id": sid, "start": time.time()})
            return sid

    # ------------------------------
    # Span Close
    # ------------------------------
    @classmethod
    def end_span(cls, span_id: Optional[str] = None, output: Optional[str] = None):
        with cls._lock:
            if not cls._active["stack"]:
                return

            # If none is passed, pop the most recent one
            if span_id is None:
                entry = cls._active["stack"].pop()
                sid = entry["span_id"]
                dur = int((time.time() - entry["start"]) * 1000)
            else:
                sid = span_id
                dur = 0

                # Find specific span in stack
                for i in reversed(range(len(cls._active["stack"]))):
                    if cls._active["stack"][i]["span_id"] == sid:
                        dur = int((time.time() - cls._active["stack"][i]["start"]) * 1000)
                        cls._active["stack"].pop(i)
                        break

            # Update the span with duration & output
            for sp in cls._active["spans"]:
                if sp["span_id"] == sid:
                    if output:
                        sp["output"] = output
                    sp["duration_ms"] = dur
                    return

    # ------------------------------
    # End Trace and Return Bundle
    # ------------------------------
    @classmethod
    def end_trace(cls, final_output: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Close all spans and return final trace bundle dict."""
        with cls._lock:
            trace_id = cls._active["trace_id"]
            if not trace_id:
                return None

            # Close all open spans
            while cls._active["stack"]:
                cls.end_span()

            # Optionally set final output on root span
            if final_output:
                cls._active["spans"][0]["output"] = final_output

            bundle = {
                "trace_id": trace_id,
                "spans": cls._active["spans"],
            }

            # Reset state
            cls._active["trace_id"] = None
            cls._active["spans"] = []
            cls._active["stack"] = []

            return bundle

    # ------------------------------
    # Expose Internal State (Read-only)
    # ------------------------------
    @classmethod
    def active_spans(cls) -> List[Dict[str, Any]]:
        return cls._active["spans"]
