# veriskgo/tracer.py
from __future__ import annotations
import functools
import time
import traceback
from typing import Any, Dict, Optional
from .trace_manager import TraceManager


def start_trace(name: str, metadata: Optional[Dict[str, Any]] = None) -> str:
    return TraceManager.start_trace(name, metadata)


def start_span(name: str, input: Optional[str] = None) -> str:
    return TraceManager.start_span(name, input)


def end_span(span_id: Optional[str] = None, output: Optional[str] = None):
    return TraceManager.end_span(span_id, output)


def end_trace(final_output: Optional[str] = None) -> Optional[Dict[str, Any]]:
    return TraceManager.end_trace(final_output)


# ------------------------------
# Decorator for automatic instrumentation
# ------------------------------
def track_function(name: str = ""):
    """
    Automatically append a span to the active trace when the
    decorated function runs.

    If no trace is active → runs normally without instrumentation.
    """

    def decorator(func):
        func_name = name or func.__name__

        @functools.wraps(func)
        def wrapper(*args, **kwargs):

            # If no active trace, skip instrumentation
            if TraceManager._active["trace_id"] is None:
                return func(*args, **kwargs)

            span_id = start_span(
                func_name,
                input=str({"args": args, "kwargs": kwargs})
            )

            start_t = time.time()

            try:
                result = func(*args, **kwargs)

                latency = int((time.time() - start_t) * 1000)
                end_span(
                    span_id,
                    output=str({
                        "status": "success",
                        "output": result,
                        "latency_ms": latency
                    })
                )

                return result

            except Exception as e:
                latency = int((time.time() - start_t) * 1000)
                end_span(
                    span_id,
                    output=str({
                        "status": "error",
                        "error": str(e),
                        "stacktrace": traceback.format_exc(),
                        "latency_ms": latency
                    })
                )
                raise

        return wrapper

    return decorator
