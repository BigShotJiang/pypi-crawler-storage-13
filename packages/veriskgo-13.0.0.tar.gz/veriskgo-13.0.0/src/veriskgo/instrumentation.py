# veriskgo/instrumentation.py
from contextlib import contextmanager
from veriskgo.trace_manager import TraceManager
import time
import traceback
import json


@contextmanager
def instrument_block(name: str, input=None):
    """Use as: with instrument_block("db_query"): ..."""

    span_id = TraceManager.start_span(name, input)
    start = time.time()

    try:
        yield

        latency = int((time.time() - start) * 1000)
        TraceManager.end_span(
            span_id,
            output=json.dumps({
                "status": "success",
                "latency_ms": latency
            })
        )

    except Exception as e:
        latency = int((time.time() - start) * 1000)
        TraceManager.end_span(
            span_id,
            output=json.dumps({
                "status": "error",
                "error": str(e),
                "stacktrace": traceback.format_exc(),
                "latency_ms": latency
            })
        )
        raise
