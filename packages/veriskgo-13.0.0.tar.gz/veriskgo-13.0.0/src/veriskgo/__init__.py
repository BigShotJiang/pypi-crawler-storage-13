# veriskgo/__init__.py

"""
VeriskGO SDK
------------

This package provides:
- Trace lifecycle tools (start_trace, end_trace, spans)
- Function instrumentation decorator
- Automatic span management
- SQS sending utilities
- User profile models and utilities
"""

from .trace_manager import TraceManager
from .tracer import (
    start_trace,
    start_span,
    end_span,
    end_trace,
    track_function,
)
from .sqs import send_to_sqs
from .models import UserProfile
from .user import user_profile_span

__all__ = [
    "TraceManager",
    "start_trace",
    "start_span",
    "end_span",
    "end_trace",
    "track_function",
    "send_to_sqs",
    "UserProfile",
    "user_profile_span",
]
