import logging

from apscheduler.schedulers.blocking import BlockingScheduler


from aiq.churn.analytics.file_dataloader import FileDataLoader
from aiq.churn.analytics.subscriberprofile_loader import SubscriberProfileLoader

config = {
    "aiq_analytics": {
        "mysql": {
            "host": "localhost",
            "user": "root",
            "password": "root",
            "database": "dataloader",
            "charset": "utf8",
            "pool_name": "dataloaderpool",
            "pool_size": 5
        },
        "opensearch": {
            "host": "10.150.1.22",
            "port": 19200,
            "user": "admin",
            "password": "ev0lv1ng@dm1n",
            "index": "aiq_subscriberprofile",
            "batch_size": 1000
        },
        "dirs": {
            "file_dir": r"D:\working\evol-aiq\data-in",
            "processed_dir": r"D:\working\evol-aiq\data-out"
        }
    }
}


class AIQAnalyticsJobScheduler:
    logger = logging.getLogger(__name__)
    file_dataloader: FileDataLoader = None
    subscription_profile_loader: SubscriberProfileLoader = None
    scheduler: BlockingScheduler = None
    aiq_analytics_config: dict

    def __init__(self, config: dict):
        print("AIQAnalyticsJobScheduler")
        self.aiq_analytics_config = config
        self.aiq_analytics_config = config['aiq_analytics']
        self.file_data_loader = FileDataLoader(self.aiq_analytics_config)
        self.subscription_profile_loader = SubscriberProfileLoader(self.aiq_analytics_config)
        self.scheduler = BlockingScheduler(timezone="Asia/Kolkata")

        self.schedule_jobs()

    def schedule_jobs(self):
        # Run DataLoader every 5 minutes
        self.scheduler.add_job(self.file_data_loader.run_loader, "cron", minute="*")

        # Run ES → DB sync every hour
        self.scheduler.add_job(self.subscription_profile_loader.sync_es_to_db, "cron", minute="*")

        # Run churn update daily at 2 AM
        self.scheduler.add_job(self.subscription_profile_loader.update_churned, "cron", minute="*")

    def run(self):
        try:
            self.scheduler.start()
        except (KeyboardInterrupt, SystemExit):
            print("Scheduler stopped manually.")


if __name__ == "__main__":
    analytics_job_scheduler = AIQAnalyticsJobScheduler(config)
    analytics_job_scheduler.run()

