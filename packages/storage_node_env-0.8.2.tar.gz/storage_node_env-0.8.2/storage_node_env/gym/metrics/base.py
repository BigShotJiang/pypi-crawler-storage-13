"""
Base classes for metrics calculation system.

This module provides abstract base classes for implementing metric calculators
and storing computed metrics in a structured format.
"""

from abc import ABC, abstractmethod
from typing import Any

import pandas as pd


class MetricCalculator(ABC):
    """
    Abstract base class for metric calculators.

    This class defines the interface for all metric calculator implementations.
    Each calculator is responsible for computing a specific category of metrics
    (e.g., economic, battery, grid).

    Attributes:
        df: Results DataFrame from environment tracking.
        node_type: Type of energy node ('producer' or 'prosumer').
        battery_config: Optional battery configuration dict for enhanced metrics.
    """

    def __init__(
        self,
        df: pd.DataFrame,
        node_type: str,
        battery_config: dict[str, Any] | None = None
    ) -> None:
        """
        Initialize metric calculator.

        Args:
            df: Results DataFrame with timestep-level tracking data.
            node_type: Type of energy node ('producer' or 'prosumer').
            battery_config: Optional battery configuration dict. If provided, enables
                           more accurate calculations for battery metrics. Expected keys:
                           - capacity: Battery capacity (kWh)
                           - dod_max: Maximum depth of discharge (%)
                           - power_charge_max: Maximum charging power (kW)
                           - power_discharge_max: Maximum discharging power (kW)
                           - efficiency_charge: Charging efficiency (0-1)
                           - efficiency_discharge: Discharging efficiency (0-1)

        Raises:
            ValueError: If node_type is invalid.
        """
        if node_type not in ('producer', 'prosumer'):
            raise ValueError(f'Invalid node_type: {node_type}. Must be "producer" or "prosumer".')

        self.df = df
        self.node_type = node_type
        self.battery_config = battery_config

    @abstractmethod
    def calculate(self) -> dict[str, float]:
        """
        Calculate all metrics for this category.

        Returns:
            Dictionary mapping metric names to computed values.

        Example:
            >>> calculator = EconomicMetricsCalculator(df, 'prosumer')
            >>> metrics = calculator.calculate()
            >>> print(metrics['total_cost_eur'])
            42.35
        """


class MetricsReport:
    """
    Container for computed metrics with structured access and formatting.

    This class stores metrics organized by category and provides methods
    for accessing, formatting, and displaying the computed metrics.

    Attributes:
        df: Original results DataFrame.
        node_type: Type of energy node ('producer' or 'prosumer').
        metrics: Dictionary mapping category names to metric dictionaries.
    """

    def __init__(self, df: pd.DataFrame, node_type: str) -> None:
        """
        Initialize metrics report.

        Args:
            df: Results DataFrame from environment tracking.
            node_type: Type of energy node ('producer' or 'prosumer').
        """
        self.df = df
        self.node_type = node_type
        self.metrics: dict[str, dict[str, float]] = {}

    def add_category(self, category: str, metrics: dict[str, float]) -> None:
        """
        Add a category of metrics to the report.

        Args:
            category: Category name (e.g., 'economic', 'battery').
            metrics: Dictionary of metric names to values.

        Example:
            >>> report = MetricsReport(df, 'prosumer')
            >>> report.add_category('economic', {'total_cost_eur': 42.35})
        """
        self.metrics[category] = metrics

    def to_dict(self) -> dict[str, dict[str, float]]:
        """
        Get metrics as nested dictionary organized by category.

        Returns:
            Dictionary mapping category names to metric dictionaries.

        Example:
            >>> metrics_dict = report.to_dict()
            >>> print(metrics_dict['economic']['total_cost_eur'])
            42.35
        """
        return self.metrics

    def to_dataframe(self) -> pd.DataFrame:
        """
        Convert metrics to a summary DataFrame.

        Returns:
            DataFrame with columns: category, metric, value.

        Example:
            >>> df = report.to_dataframe()
            >>> print(df.head())
                 category           metric     value
            0    economic  total_cost_eur     42.35
            1    economic  total_revenue_eur  15.80
        """
        rows = []
        for category, metrics in self.metrics.items():
            for metric_name, value in metrics.items():
                rows.append({
                    'category': category,
                    'metric': metric_name,
                    'value': value
                })

        return pd.DataFrame(rows)

    def get_category(self, category: str) -> dict[str, float]:
        """
        Get all metrics for a specific category.

        Args:
            category: Category name (e.g., 'economic', 'battery').

        Returns:
            Dictionary of metric names to values for the category.

        Raises:
            KeyError: If category not found.

        Example:
            >>> economic_metrics = report.get_category('economic')
            >>> print(economic_metrics['total_cost_eur'])
            42.35
        """
        if category not in self.metrics:
            available = list(self.metrics.keys())
            raise KeyError(
                f'Category "{category}" not found. '
                f'Available categories: {available}'
            )
        return self.metrics[category]

    def get_metric(self, category: str, metric: str) -> float:
        """
        Get a specific metric value.

        Args:
            category: Category name.
            metric: Metric name.

        Returns:
            Metric value.

        Raises:
            KeyError: If category or metric not found.

        Example:
            >>> cost = report.get_metric('economic', 'total_cost_eur')
            >>> print(f'{cost:.2f} €')
            42.35 €
        """
        category_metrics = self.get_category(category)
        if metric not in category_metrics:
            available = list(category_metrics.keys())
            raise KeyError(
                f'Metric "{metric}" not found in category "{category}". '
                f'Available metrics: {available}'
            )
        return category_metrics[metric]

    def summary(self, decimals: int = 4) -> str:
        """
        Generate formatted summary of all metrics.

        Args:
            decimals: Number of decimal places for rounding.

        Returns:
            Multi-line formatted string with all metrics.

        Example:
            >>> print(report.summary())
            Metrics Report (prosumer)
            ========================
            Economic Metrics:
              total_cost_eur: 42.3500
              ...
        """
        lines = [
            f'Metrics Report ({self.node_type})',
            '=' * 50
        ]

        for category, metrics in self.metrics.items():
            lines.append(f'\n{category.replace("_", " ").title()} Metrics:')
            for metric_name, value in metrics.items():
                lines.append(f'  {metric_name}: {value:.{decimals}f}')

        return '\n'.join(lines)

    def __repr__(self) -> str:
        """Return string representation of metrics report."""
        num_categories = len(self.metrics)
        total_metrics = sum(len(m) for m in self.metrics.values())
        return (
            f'MetricsReport('
            f'node_type=\'{self.node_type}\', '
            f'categories={num_categories}, '
            f'total_metrics={total_metrics}'
            f')'
        )
