"""
Metrics configuration and registry.

This module defines the configuration for all available metrics,
organized by category, with metadata about calculation methods,
units, and applicability to node types.
"""

from dataclasses import dataclass


@dataclass
class MetricConfig:
    """
    Configuration for a single metric.

    Attributes:
        name: Metric name (lowercase with underscores).
        category: Metric category (economic, battery, grid, etc.).
        description: Human-readable description.
        unit: Unit of measurement (e.g., 'eur', 'kwh', 'pct', 'count').
        node_types: List of applicable node types ('producer', 'prosumer', or both).
    """

    name: str
    category: str
    description: str
    unit: str
    node_types: list[str]


# metrics registry organized by category
METRICS_REGISTRY: dict[str, MetricConfig] = {
    # economic metrics
    'total_cost_eur': MetricConfig(
        name='total_cost_eur',
        category='economic',
        description='Total electricity import cost',
        unit='eur',
        node_types=['producer', 'prosumer']
    ),
    'total_revenue_eur': MetricConfig(
        name='total_revenue_eur',
        category='economic',
        description='Total electricity export revenue',
        unit='eur',
        node_types=['producer', 'prosumer']
    ),
    'net_profit_loss_eur': MetricConfig(
        name='net_profit_loss_eur',
        category='economic',
        description='Net profit (producer) or net loss (prosumer)',
        unit='eur',
        node_types=['producer', 'prosumer']
    ),
    'mean_import_price_eur_kwh': MetricConfig(
        name='mean_import_price_eur_kwh',
        category='economic',
        description='Average price of grid imports',
        unit='eur_kwh',
        node_types=['producer', 'prosumer']
    ),
    'mean_export_price_eur_kwh': MetricConfig(
        name='mean_export_price_eur_kwh',
        category='economic',
        description='Average price of grid exports',
        unit='eur_kwh',
        node_types=['producer', 'prosumer']
    ),

    # self-consumption metrics (prosumer only)
    'mean_selfcons_ratio_pct': MetricConfig(
        name='mean_selfcons_ratio_pct',
        category='self_consumption',
        description='Average self-consumption ratio',
        unit='pct',
        node_types=['prosumer']
    ),
    'mean_selfsuff_ratio_pct': MetricConfig(
        name='mean_selfsuff_ratio_pct',
        category='self_consumption',
        description='Average self-sufficiency ratio',
        unit='pct',
        node_types=['prosumer']
    ),
    'total_selfcons_energy_kwh': MetricConfig(
        name='total_selfcons_energy_kwh',
        category='self_consumption',
        description='Total self-consumed energy',
        unit='kwh',
        node_types=['prosumer']
    ),

    # battery metrics
    'total_charge_energy_kwh': MetricConfig(
        name='total_charge_energy_kwh',
        category='battery',
        description='Total energy charged into battery',
        unit='kwh',
        node_types=['producer', 'prosumer']
    ),
    'total_discharge_energy_kwh': MetricConfig(
        name='total_discharge_energy_kwh',
        category='battery',
        description='Total energy discharged from battery',
        unit='kwh',
        node_types=['producer', 'prosumer']
    ),
    'charge_cycle_count': MetricConfig(
        name='charge_cycle_count',
        category='battery',
        description='Estimated number of charge cycles',
        unit='count',
        node_types=['producer', 'prosumer']
    ),
    'mean_soc_pct': MetricConfig(
        name='mean_soc_pct',
        category='battery',
        description='Average state of charge',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),
    'min_soc_pct': MetricConfig(
        name='min_soc_pct',
        category='battery',
        description='Minimum SoC reached',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),
    'max_soc_pct': MetricConfig(
        name='max_soc_pct',
        category='battery',
        description='Maximum SoC reached',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),
    'soc_range_pct': MetricConfig(
        name='soc_range_pct',
        category='battery',
        description='SoC range (max - min)',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),
    'battery_efficiency_pct': MetricConfig(
        name='battery_efficiency_pct',
        category='battery',
        description='Estimated round-trip efficiency',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),

    # battery utilization metrics (require battery_config)
    'mean_charge_utilization_pct': MetricConfig(
        name='mean_charge_utilization_pct',
        category='battery',
        description='Average charge power utilization (requires battery_config)',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),
    'mean_discharge_utilization_pct': MetricConfig(
        name='mean_discharge_utilization_pct',
        category='battery',
        description='Average discharge power utilization (requires battery_config)',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),
    'max_charge_utilization_pct': MetricConfig(
        name='max_charge_utilization_pct',
        category='battery',
        description='Maximum charge power utilization (requires battery_config)',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),
    'max_discharge_utilization_pct': MetricConfig(
        name='max_discharge_utilization_pct',
        category='battery',
        description='Maximum discharge power utilization (requires battery_config)',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),
    'capacity_utilization_pct': MetricConfig(
        name='capacity_utilization_pct',
        category='battery',
        description='Percentage of usable SoC range utilized (requires battery_config)',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),
    'min_soc_margin_pct': MetricConfig(
        name='min_soc_margin_pct',
        category='battery',
        description='Margin from minimum SoC bound (requires battery_config)',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),
    'max_soc_margin_pct': MetricConfig(
        name='max_soc_margin_pct',
        category='battery',
        description='Margin from maximum SoC bound (requires battery_config)',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),

    # grid metrics
    'total_import_energy_kwh': MetricConfig(
        name='total_import_energy_kwh',
        category='grid',
        description='Total energy imported from grid',
        unit='kwh',
        node_types=['producer', 'prosumer']
    ),
    'total_export_energy_kwh': MetricConfig(
        name='total_export_energy_kwh',
        category='grid',
        description='Total energy exported to grid',
        unit='kwh',
        node_types=['producer', 'prosumer']
    ),
    'import_export_ratio': MetricConfig(
        name='import_export_ratio',
        category='grid',
        description='Ratio of import to export energy',
        unit='ratio',
        node_types=['producer', 'prosumer']
    ),
    'grid_independence_pct': MetricConfig(
        name='grid_independence_pct',
        category='grid',
        description='Grid independence (1 - import/consumption)',
        unit='pct',
        node_types=['prosumer']
    ),

    # violation metrics
    'total_violations_kw': MetricConfig(
        name='total_violations_kw',
        category='violations',
        description='Sum of power constraint violations',
        unit='kw',
        node_types=['producer', 'prosumer']
    ),
    'max_violation_kw': MetricConfig(
        name='max_violation_kw',
        category='violations',
        description='Maximum single violation magnitude',
        unit='kw',
        node_types=['producer', 'prosumer']
    ),
    'violation_count': MetricConfig(
        name='violation_count',
        category='violations',
        description='Number of timesteps with violations',
        unit='count',
        node_types=['producer', 'prosumer']
    ),
    'violation_percentage_pct': MetricConfig(
        name='violation_percentage_pct',
        category='violations',
        description='Percentage of timesteps with violations',
        unit='pct',
        node_types=['producer', 'prosumer']
    ),
}


def list_available_metrics(node_type: str | None = None) -> dict[str, str]:
    """
    List all available metrics with descriptions.

    Args:
        node_type: Optional filter by node type ('producer' or 'prosumer').
                  If None, returns all metrics.

    Returns:
        Dictionary mapping metric names to descriptions.

    Example:
        >>> metrics = list_available_metrics('prosumer')
        >>> print(metrics['mean_selfcons_ratio_pct'])
        Average self-consumption ratio
    """
    result = {}
    for name, config in METRICS_REGISTRY.items():
        if node_type is None or node_type in config.node_types:
            result[name] = config.description

    return result


def get_metric_config(metric_name: str) -> MetricConfig:
    """
    Get configuration for a specific metric.

    Args:
        metric_name: Name of the metric.

    Returns:
        MetricConfig object.

    Raises:
        KeyError: If metric name not found.

    Example:
        >>> config = get_metric_config('total_cost_eur')
        >>> print(config.unit)
        eur
    """
    if metric_name not in METRICS_REGISTRY:
        available = list(METRICS_REGISTRY.keys())
        raise KeyError(
            f'Metric "{metric_name}" not found. '
            f'Available metrics: {available}'
        )
    return METRICS_REGISTRY[metric_name]


def print_metrics_registry(node_type: str | None = None) -> None:
    """
    Pretty-print metrics registry organized by category.

    Args:
        node_type: Optional filter by node type.

    Example:
        >>> print_metrics_registry('prosumer')
        Economic Metrics:
          - total_cost_eur: Total electricity import cost (eur)
          ...
    """
    # group metrics by category
    categories: dict[str, list[MetricConfig]] = {}
    for config in METRICS_REGISTRY.values():
        if node_type is None or node_type in config.node_types:
            if config.category not in categories:
                categories[config.category] = []
            categories[config.category].append(config)

    # print organized by category
    for category, configs in sorted(categories.items()):
        print(f'\n{category.replace("_", " ").title()} Metrics:')
        for config in sorted(configs, key=lambda c: c.name):
            print(f'  - {config.name}: {config.description} ({config.unit})')
