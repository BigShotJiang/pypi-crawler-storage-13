"""
Aggregation and downsampling utilities for large datasets.

This module provides functions for temporal aggregation and intelligent
downsampling using the LTTB (Largest Triangle Three Buckets) algorithm
to handle large datasets efficiently while preserving visual characteristics.
"""

from typing import Any

import numpy as np
import pandas as pd

from storage_node_env.gym.metrics.calculators import (
    BatteryMetricsCalculator,
    EconomicMetricsCalculator,
    GridMetricsCalculator,
    SelfConsumptionMetricsCalculator,
    ViolationMetricsCalculator,
)


# check if lttb is available
try:
    from lttb import downsample as lttb_downsample
    LTTB_AVAILABLE = True
except ImportError:
    LTTB_AVAILABLE = False


def apply_lttb_aggregation(
    df: pd.DataFrame,
    n_points: int,
    x_column: str = 'datetime',
    y_column: str = 'soc_final_pct'
) -> pd.DataFrame:
    """
    Apply LTTB downsampling to preserve visual characteristics.

    This function uses the Largest Triangle Three Buckets algorithm
    to intelligently downsample time series data while preserving
    peaks, valleys, and overall trends. Unlike simple averaging or
    decimation, LTTB preserves the visual characteristics of the data.

    Args:
        df: Results DataFrame.
        n_points: Target number of points after downsampling.
        x_column: Column for x-axis (typically 'datetime').
        y_column: Column for y-axis (metric to visualize).

    Returns:
        Downsampled DataFrame with approximately n_points rows.
        Contains all original columns, not just x and y.

    Raises:
        ImportError: If lttb library not installed.
        ValueError: If n_points >= len(df) or invalid columns.

    Example:
        >>> # downsample 8760 points to 1000
        >>> df_downsampled = apply_lttb_aggregation(df, n_points=1000)
        >>> print(f'Original: {len(df)}, Downsampled: {len(df_downsampled)}')
        Original: 8760, Downsampled: 1000
    """
    if not LTTB_AVAILABLE:
        raise ImportError(
            'LTTB library not available. '
            'Install with: pip install storage-node-env[visualization] '
            'or: pip install lttb'
        )

    if n_points >= len(df):
        # no downsampling needed
        return df

    if x_column not in df.columns or y_column not in df.columns:
        raise ValueError(f'Columns {x_column} or {y_column} not found in DataFrame')

    # convert datetime to numeric for LTTB
    df_work = df.copy()
    if df_work[x_column].dtype == 'object':  # string datetime
        df_work['_datetime_numeric'] = pd.to_datetime(df_work[x_column]).astype(np.int64)
    else:
        df_work['_datetime_numeric'] = df_work[x_column].astype(np.int64)

    # prepare data array for LTTB (N x 2)
    data = np.column_stack([
        df_work['_datetime_numeric'].values,
        df_work[y_column].values
    ])

    # apply LTTB downsampling
    downsampled_data = lttb_downsample(data, n_out=n_points)

    # find nearest original row indices
    selected_indices = []
    for timestamp in downsampled_data[:, 0]:
        # find closest timestamp in original data
        idx = (df_work['_datetime_numeric'] - timestamp).abs().idxmin()
        selected_indices.append(idx)

    # return complete rows from original DataFrame
    return df.iloc[selected_indices].reset_index(drop=True)


def filter_to_day(df: pd.DataFrame, day: str) -> pd.DataFrame:
    """
    Filter DataFrame to a specific day.

    Args:
        df: Results DataFrame with 'datetime' column (string format).
        day: Day to filter (format: 'YYYY-MM-DD').

    Returns:
        Filtered DataFrame for the specified day.
        Adds 'hour_of_day' column for x-axis (0-23.75 for 15-min data).

    Raises:
        ValueError: If day not found in data or invalid format.

    Example:
        >>> df_day = filter_to_day(df, '2024-01-15')
        >>> print(len(df_day))  # 24 for hourly data, 96 for 15-min data
        >>> print(df_day['hour_of_day'].min(), df_day['hour_of_day'].max())
        0.0 23.0
    """
    # convert datetime strings to pandas datetime
    df_work = df.copy()
    df_work['datetime'] = pd.to_datetime(df_work['datetime'])

    # parse requested day
    try:
        target_date = pd.to_datetime(day).date()
    except Exception as e:
        raise ValueError(f'Invalid day format: {day}. Expected YYYY-MM-DD') from e

    # filter to specific day
    df_work['date'] = df_work['datetime'].dt.date
    df_filtered = df_work[df_work['date'] == target_date].copy()

    if len(df_filtered) == 0:
        available_days = df_work['date'].unique()
        raise ValueError(
            f'Day {day} not found in data. '
            f'Available days: {available_days[0]} to {available_days[-1]}'
        )

    # add hour of day for x-axis
    df_filtered['hour_of_day'] = df_filtered['datetime'].dt.hour

    # for 15-minute data, use fractional hours
    df_filtered['hour_of_day'] += df_filtered['datetime'].dt.minute / 60.0

    return df_filtered.drop(columns=['date']).reset_index(drop=True)


def compute_metrics_by_period(
    df: pd.DataFrame,
    node_type: str,
    frequency: str = 'D',
    battery_config: dict | None = None
) -> pd.DataFrame:
    """
    Compute metrics aggregated by time period.

    Calculates the same metrics as compute_metrics(), but aggregated
    over time periods (daily, weekly, monthly) instead of the entire
    simulation. This is useful for analyzing temporal trends and patterns.

    Args:
        df: Results DataFrame with 'datetime' column.
        node_type: 'producer' or 'prosumer'.
        frequency: Pandas frequency string for aggregation.
            Options: 'D' (daily), 'W' (weekly), 'ME' (month-end),
            'H' (hourly), 'QE' (quarter-end), 'YE' (year-end).
            Note: 'M', 'Q', 'Y' are deprecated, use 'ME', 'QE', 'YE' instead.
        battery_config: Optional battery configuration for accurate calculations.

    Returns:
        DataFrame with periods as rows and metrics as columns.
        Index: period timestamps
        Columns: all metrics from METRICS_REGISTRY applicable to aggregation

    Example:
        >>> # daily metrics
        >>> metrics_daily = compute_metrics_by_period(df, 'prosumer', frequency='D')
        >>> print(metrics_daily.head())

        >>> # monthly metrics
        >>> metrics_monthly = compute_metrics_by_period(df, 'prosumer', frequency='ME')
        >>> print(metrics_monthly[['total_cost_eur', 'mean_soc_pct']])
    """
    # validate node type
    if node_type not in ['producer', 'prosumer']:
        raise ValueError(f'Invalid node_type: {node_type}. Must be "producer" or "prosumer"')

    # convert datetime and set as index
    df_work = df.copy()
    df_work['datetime'] = pd.to_datetime(df_work['datetime'])
    df_work = df_work.set_index('datetime')

    # group by period
    grouped = df_work.groupby(pd.Grouper(freq=frequency))

    # compute metrics for each period
    results = []
    for period, group_df in grouped:
        if len(group_df) == 0:
            # skip empty periods
            continue

        # reset index for metric calculations (expects regular DataFrame)
        group_df_reset = group_df.reset_index()

        # compute metrics for this period
        metrics_dict = {'period': period}

        # economic metrics
        economic_calc = EconomicMetricsCalculator(group_df_reset, node_type)
        metrics_dict.update(economic_calc.calculate())

        # battery metrics
        battery_calc = BatteryMetricsCalculator(group_df_reset, node_type, battery_config)
        metrics_dict.update(battery_calc.calculate())

        # grid metrics
        grid_calc = GridMetricsCalculator(group_df_reset, node_type)
        metrics_dict.update(grid_calc.calculate())

        # self-consumption metrics (prosumer only)
        if node_type == 'prosumer':
            sc_calc = SelfConsumptionMetricsCalculator(group_df_reset, node_type, battery_config)
            metrics_dict.update(sc_calc.calculate())

        # constraint violation metrics
        violation_calc = ViolationMetricsCalculator(group_df_reset, node_type, battery_config)
        metrics_dict.update(violation_calc.calculate())

        results.append(metrics_dict)

    # create DataFrame with periods as rows
    if not results:
        raise ValueError(f'No data available for frequency: {frequency}')

    return pd.DataFrame(results).set_index('period')
