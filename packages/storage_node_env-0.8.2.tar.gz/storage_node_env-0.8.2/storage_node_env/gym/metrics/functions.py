"""
Helper functions for metric calculations.

This module provides reusable calculation functions for all metrics,
handling edge cases and providing clear implementations of metric formulas.
"""

import pandas as pd


# economic metrics

def calculate_total_cost(df: pd.DataFrame) -> float:
    """
    Calculate total electricity import cost.

    Args:
        df: Results DataFrame with 'import_cost_eur' column.

    Returns:
        Total cost in EUR.
    """
    if 'import_cost_eur' not in df.columns:
        return 0.0
    return float(df['import_cost_eur'].sum())


def calculate_total_revenue(df: pd.DataFrame) -> float:
    """
    Calculate total electricity export revenue.

    Args:
        df: Results DataFrame with 'export_revenue_eur' column.

    Returns:
        Total revenue in EUR.
    """
    if 'export_revenue_eur' not in df.columns:
        return 0.0
    return float(df['export_revenue_eur'].sum())


def calculate_net_profit_loss(df: pd.DataFrame, node_type: str) -> float:
    """
    Calculate net profit (producer) or net loss (prosumer).

    Args:
        df: Results DataFrame with economic columns.
        node_type: 'producer' or 'prosumer'.

    Returns:
        Net profit (positive) or net loss (negative) in EUR.
    """
    if node_type == 'producer':
        # producer: profit = revenue - cost
        if 'net_profit_eur' in df.columns:
            return float(df['net_profit_eur'].sum())
        revenue = calculate_total_revenue(df)
        cost = calculate_total_cost(df)
        return revenue - cost
    else:
        # prosumer: loss = -(cost - revenue)
        if 'net_cost_eur' in df.columns:
            return -float(df['net_cost_eur'].sum())
        cost = calculate_total_cost(df)
        revenue = calculate_total_revenue(df)
        return revenue - cost


def calculate_mean_import_price(df: pd.DataFrame) -> float:
    """
    Calculate average price of grid imports.

    Args:
        df: Results DataFrame with 'import_cost_eur' and 'import_energy_kwh'.

    Returns:
        Mean import price in EUR/kWh, or 0.0 if no imports.
    """
    if 'import_cost_eur' not in df.columns or 'import_energy_kwh' not in df.columns:
        return 0.0

    total_cost = df['import_cost_eur'].sum()
    total_energy = df['import_energy_kwh'].sum()

    if total_energy == 0:
        return 0.0

    return float(total_cost / total_energy)


def calculate_mean_export_price(df: pd.DataFrame) -> float:
    """
    Calculate average price of grid exports.

    Args:
        df: Results DataFrame with 'export_revenue_eur' and 'export_energy_kwh'.

    Returns:
        Mean export price in EUR/kWh, or 0.0 if no exports.
    """
    if 'export_revenue_eur' not in df.columns or 'export_energy_kwh' not in df.columns:
        return 0.0

    total_revenue = df['export_revenue_eur'].sum()
    total_energy = df['export_energy_kwh'].sum()

    if total_energy == 0:
        return 0.0

    return float(total_revenue / total_energy)


# self-consumption metrics

def calculate_mean_selfcons_ratio(df: pd.DataFrame) -> float:
    """
    Calculate mean self-consumption ratio.

    Args:
        df: Results DataFrame with 'selfcons_ratio' column.

    Returns:
        Mean self-consumption ratio as percentage (0-100).
    """
    if 'selfcons_ratio' not in df.columns:
        return 0.0
    return float(df['selfcons_ratio'].mean() * 100)


def calculate_mean_selfsuff_ratio(df: pd.DataFrame) -> float:
    """
    Calculate mean self-sufficiency ratio.

    Args:
        df: Results DataFrame with 'selfsuff_ratio' column.

    Returns:
        Mean self-sufficiency ratio as percentage (0-100).
    """
    if 'selfsuff_ratio' not in df.columns:
        return 0.0
    return float(df['selfsuff_ratio'].mean() * 100)


def calculate_total_selfcons_energy(df: pd.DataFrame) -> float:
    """
    Calculate total self-consumed energy.

    Args:
        df: Results DataFrame with 'selfcons_energy_kwh' column.

    Returns:
        Total self-consumed energy in kWh.
    """
    if 'selfcons_energy_kwh' not in df.columns:
        return 0.0
    return float(df['selfcons_energy_kwh'].sum())


# battery metrics

def calculate_total_charge_energy(df: pd.DataFrame) -> float:
    """
    Calculate total energy charged into battery.

    Args:
        df: Results DataFrame with 'battery_charge_kwh' column.

    Returns:
        Total charge energy in kWh.
    """
    if 'battery_charge_kwh' not in df.columns:
        return 0.0
    return float(df['battery_charge_kwh'].sum())


def calculate_total_discharge_energy(df: pd.DataFrame) -> float:
    """
    Calculate total energy discharged from battery.

    Args:
        df: Results DataFrame with 'battery_discharge_kwh' column.

    Returns:
        Total discharge energy in kWh.
    """
    if 'battery_discharge_kwh' not in df.columns:
        return 0.0
    return float(df['battery_discharge_kwh'].sum())


def calculate_charge_cycle_count(
    df: pd.DataFrame,
    battery_config: dict | None = None
) -> float:
    """
    Calculate number of charge cycles.

    One full cycle = charging from 0% to 100% (or equivalent throughput).
    Calculated as: total_throughput / (2 * usable_capacity).

    Args:
        df: Results DataFrame with battery energy columns.
        battery_config: Optional battery configuration dict. If provided,
                       uses actual capacity and DoD for accurate calculation.

    Returns:
        Number of charge cycles.

    Note:
        If battery_config is provided, calculates accurate cycle count using
        actual capacity and DoD. Otherwise, uses rough approximation based
        on throughput assuming typical battery sizes.
    """
    charge_energy = calculate_total_charge_energy(df)
    discharge_energy = calculate_total_discharge_energy(df)
    total_throughput = charge_energy + discharge_energy

    # accurate calculation if battery_config available
    if battery_config is not None:
        capacity = battery_config.get('capacity', 10.0)
        dod_max = battery_config.get('dod_max', 100)
        usable_capacity = capacity * (dod_max / 100.0)
        # one full cycle = 2 * usable_capacity (charge + discharge)
        if usable_capacity > 0:
            return float(total_throughput / (2 * usable_capacity))

    # fallback: estimate using SoC range as proxy
    if 'soc_final_pct' in df.columns:
        soc_range = df['soc_final_pct'].max() - df['soc_final_pct'].min()
        if soc_range > 0:
            # rough estimate: cycles = throughput / (2 * capacity)
            # assuming capacity ~= throughput_per_full_swing
            return float(total_throughput / 100.0)

    # fallback: very rough estimate assuming ~10 kWh typical capacity
    return float(total_throughput / 10.0)


def calculate_mean_soc(df: pd.DataFrame) -> float:
    """
    Calculate average state of charge.

    Args:
        df: Results DataFrame with 'soc_final_pct' column.

    Returns:
        Mean SoC as percentage (0-100).
    """
    if 'soc_final_pct' not in df.columns:
        return 0.0
    return float(df['soc_final_pct'].mean())


def calculate_min_soc(df: pd.DataFrame) -> float:
    """
    Calculate minimum state of charge reached.

    Args:
        df: Results DataFrame with 'soc_final_pct' column.

    Returns:
        Minimum SoC as percentage (0-100).
    """
    if 'soc_final_pct' not in df.columns:
        return 0.0
    return float(df['soc_final_pct'].min())


def calculate_max_soc(df: pd.DataFrame) -> float:
    """
    Calculate maximum state of charge reached.

    Args:
        df: Results DataFrame with 'soc_final_pct' column.

    Returns:
        Maximum SoC as percentage (0-100).
    """
    if 'soc_final_pct' not in df.columns:
        return 0.0
    return float(df['soc_final_pct'].max())


def calculate_soc_range(df: pd.DataFrame) -> float:
    """
    Calculate SoC range (max - min).

    Args:
        df: Results DataFrame with 'soc_final_pct' column.

    Returns:
        SoC range in percentage points.
    """
    if 'soc_final_pct' not in df.columns:
        return 0.0
    return calculate_max_soc(df) - calculate_min_soc(df)


def calculate_battery_efficiency(
    df: pd.DataFrame,
    battery_config: dict | None = None
) -> float:
    """
    Calculate battery round-trip efficiency.

    Calculated as: discharge_energy / charge_energy * 100.

    Args:
        df: Results DataFrame with battery energy columns.
        battery_config: Optional battery configuration dict. If provided,
                       uses actual efficiencies for comparison.

    Returns:
        Observed efficiency as percentage (0-100).

    Note:
        The observed efficiency includes parasitic losses and SoC changes.
        If battery_config is provided with efficiency_charge and efficiency_discharge,
        the expected theoretical efficiency is: eta_cha * eta_dis * 100.
        Observed efficiency may differ from theoretical due to parasitic losses
        and net SoC changes during the simulation.
    """
    charge_energy = calculate_total_charge_energy(df)
    discharge_energy = calculate_total_discharge_energy(df)

    if charge_energy == 0:
        return 0.0

    observed_efficiency = discharge_energy / charge_energy * 100

    # note: if battery_config is available, expected theoretical efficiency is:
    # eta_cha * eta_dis * 100
    # this can be used for comparison but we return observed efficiency here
    # (calculators can compute the deviation separately if needed)

    return float(observed_efficiency)


def calculate_power_utilization(
    df: pd.DataFrame,
    battery_config: dict | None = None
) -> dict[str, float]:
    """
    Calculate battery power utilization metrics.

    Measures how much of the available battery power is actually used
    during charge and discharge operations.

    Args:
        df: Results DataFrame with 'action_kw' column.
        battery_config: Battery configuration dict with power limits.
                       Required keys: 'power_charge_max', 'power_discharge_max'.

    Returns:
        Dictionary with power utilization metrics:
        - mean_charge_utilization_pct: Average charge power utilization (%)
        - mean_discharge_utilization_pct: Average discharge power utilization (%)
        - max_charge_utilization_pct: Maximum charge power utilization (%)
        - max_discharge_utilization_pct: Maximum discharge power utilization (%)

        Returns empty dict if battery_config is None or action_kw column missing.

    Note:
        Utilization is calculated as: (actual_power / max_power) * 100
        Only timesteps with actual charge/discharge actions are included in averages.
    """
    if battery_config is None or 'action_kw' not in df.columns:
        return {}

    P_cha_max = battery_config.get('power_charge_max', 1.0)
    P_dis_max = battery_config.get('power_discharge_max', 1.0)

    # filter charge and discharge actions
    charge_actions = df[df['action_kw'] > 0]
    discharge_actions = df[df['action_kw'] < 0]

    # calculate utilization percentages
    result = {}

    if len(charge_actions) > 0:
        result['mean_charge_utilization_pct'] = float(
            (charge_actions['action_kw'].mean() / P_cha_max) * 100
        )
        result['max_charge_utilization_pct'] = float(
            (charge_actions['action_kw'].max() / P_cha_max) * 100
        )
    else:
        result['mean_charge_utilization_pct'] = 0.0
        result['max_charge_utilization_pct'] = 0.0

    if len(discharge_actions) > 0:
        result['mean_discharge_utilization_pct'] = float(
            (abs(discharge_actions['action_kw'].mean()) / P_dis_max) * 100
        )
        result['max_discharge_utilization_pct'] = float(
            (abs(discharge_actions['action_kw'].min()) / P_dis_max) * 100
        )
    else:
        result['mean_discharge_utilization_pct'] = 0.0
        result['max_discharge_utilization_pct'] = 0.0

    return result


def calculate_capacity_utilization(
    df: pd.DataFrame,
    battery_config: dict | None = None
) -> dict[str, float]:
    """
    Calculate battery capacity utilization metrics.

    Measures how much of the usable SoC range is actually utilized
    relative to the DoD constraints.

    Args:
        df: Results DataFrame with 'soc_final_pct' column.
        battery_config: Battery configuration dict with capacity limits.
                       Required keys: 'dod_max'.

    Returns:
        Dictionary with capacity utilization metrics:
        - capacity_utilization_pct: Percentage of usable range utilized (%)
        - min_soc_margin_pct: Margin from minimum SoC bound (percentage points)
        - max_soc_margin_pct: Margin from maximum SoC bound (percentage points)

        Returns empty dict if battery_config is None or soc_final_pct column missing.

    Note:
        A capacity_utilization of 100% means the battery uses the full DoD range.
        Lower values indicate conservative behavior (may be intentional for longevity).
        Margins indicate how close the controller operates to the SoC limits.
    """
    if battery_config is None or 'soc_final_pct' not in df.columns:
        return {}

    dod_max = battery_config.get('dod_max', 100)
    min_soc_allowed = 100 - dod_max  # e.g., 10% if DoD = 90%
    max_soc_allowed = 100.0

    actual_min = float(df['soc_final_pct'].min())
    actual_max = float(df['soc_final_pct'].max())
    actual_range = actual_max - actual_min
    usable_range = max_soc_allowed - min_soc_allowed

    result = {}

    if usable_range > 0:
        result['capacity_utilization_pct'] = float((actual_range / usable_range) * 100)
    else:
        result['capacity_utilization_pct'] = 0.0

    result['min_soc_margin_pct'] = float(actual_min - min_soc_allowed)
    result['max_soc_margin_pct'] = float(max_soc_allowed - actual_max)

    return result


# grid metrics

def calculate_total_import_energy(df: pd.DataFrame) -> float:
    """
    Calculate total energy imported from grid.

    Args:
        df: Results DataFrame with 'import_energy_kwh' column.

    Returns:
        Total import energy in kWh.
    """
    if 'import_energy_kwh' not in df.columns:
        return 0.0
    return float(df['import_energy_kwh'].sum())


def calculate_total_export_energy(df: pd.DataFrame) -> float:
    """
    Calculate total energy exported to grid.

    Args:
        df: Results DataFrame with 'export_energy_kwh' column.

    Returns:
        Total export energy in kWh.
    """
    if 'export_energy_kwh' not in df.columns:
        return 0.0
    return float(df['export_energy_kwh'].sum())


def calculate_import_export_ratio(df: pd.DataFrame) -> float:
    """
    Calculate ratio of import to export energy.

    Args:
        df: Results DataFrame with grid energy columns.

    Returns:
        Import/export ratio, or 0.0 if no exports.
    """
    total_import = calculate_total_import_energy(df)
    total_export = calculate_total_export_energy(df)

    if total_export == 0:
        return 0.0 if total_import == 0 else float('inf')

    return float(total_import / total_export)


def calculate_grid_independence(df: pd.DataFrame) -> float:
    """
    Calculate grid independence for prosumers.

    Formula: (1 - total_import / total_consumption) * 100

    Args:
        df: Results DataFrame with 'import_energy_kwh' and 'consumption_kw'.

    Returns:
        Grid independence as percentage (0-100).

    Note:
        Only applicable to prosumer nodes.
    """
    if 'consumption_kw' not in df.columns or 'import_energy_kwh' not in df.columns:
        return 0.0

    # calculate total consumption from power readings
    # assuming uniform timesteps, sum of consumption_kw * delta_t
    # for simplicity, we use import_energy vs consumption_energy ratio
    total_import = df['import_energy_kwh'].sum()

    # estimate total consumption energy
    # this requires delta_t, which we can infer from energy columns
    # or we can use the consumption_kw column if available
    # for now, use selfcons + import as total consumption
    if 'selfcons_energy_kwh' in df.columns:
        total_consumption = df['selfcons_energy_kwh'].sum() + total_import
    else:
        # fallback: cannot calculate without consumption data
        return 0.0

    if total_consumption == 0:
        return 100.0

    independence = (1 - total_import / total_consumption) * 100
    return float(max(0.0, min(100.0, independence)))  # clamp to [0, 100]


# violation metrics

def calculate_total_violations(df: pd.DataFrame) -> float:
    """
    Calculate sum of power constraint violations.

    Args:
        df: Results DataFrame with 'violation_kw' column.

    Returns:
        Total violations in kW.
    """
    if 'violation_kw' not in df.columns:
        return 0.0
    return float(df['violation_kw'].sum())


def calculate_max_violation(df: pd.DataFrame) -> float:
    """
    Calculate maximum single violation magnitude.

    Args:
        df: Results DataFrame with 'violation_kw' column.

    Returns:
        Maximum violation in kW.
    """
    if 'violation_kw' not in df.columns:
        return 0.0
    return float(df['violation_kw'].max())


def calculate_violation_count(df: pd.DataFrame) -> int:
    """
    Calculate number of timesteps with violations.

    Args:
        df: Results DataFrame with 'violation_kw' column.

    Returns:
        Count of timesteps with non-zero violations.
    """
    if 'violation_kw' not in df.columns:
        return 0
    return int((df['violation_kw'] > 0).sum())


def calculate_violation_percentage(df: pd.DataFrame) -> float:
    """
    Calculate percentage of timesteps with violations.

    Args:
        df: Results DataFrame with 'violation_kw' column.

    Returns:
        Violation percentage (0-100).
    """
    if 'violation_kw' not in df.columns or len(df) == 0:
        return 0.0

    violation_count = calculate_violation_count(df)
    total_timesteps = len(df)

    return float(violation_count / total_timesteps * 100)
