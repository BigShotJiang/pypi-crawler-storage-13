"""
Metrics calculation and visualization system for energy storage simulations.

This package provides tools for computing performance metrics and generating
visualizations from simulation results collected by the tracking system.

Main Functions:
    - compute_metrics(): Calculate comprehensive metrics from results DataFrame
    - visualize(): Generate visualizations from results data

Example:
    >>> import gymnasium as gym
    >>> from storage_node_env.gym.metrics import compute_metrics, visualize
    >>>
    >>> # run simulation and collect results
    >>> env = gym.make('storage_node_env/EnergyStorage-v0', track_results=True, ...)
    >>> env.set_controller('ppo')
    >>> # ... run episode ...
    >>>
    >>> # compute metrics
    >>> df = env.results['ppo']
    >>> report = compute_metrics(df, node_type='prosumer')
    >>> print(report.summary())
    >>>
    >>> # create visualization
    >>> fig = visualize(df, node_type='prosumer', visualization_type='dashboard')
    >>> fig.savefig('dashboard.png')
"""

from typing import Any

import pandas as pd

from storage_node_env.gym.metrics.aggregation import (
    apply_lttb_aggregation,
    compute_metrics_by_period,
    filter_to_day,
)
from storage_node_env.gym.metrics.base import MetricCalculator, MetricsReport
from storage_node_env.gym.metrics.calculators import (
    BatteryMetricsCalculator,
    EconomicMetricsCalculator,
    GridMetricsCalculator,
    SelfConsumptionMetricsCalculator,
    ViolationMetricsCalculator,
)
from storage_node_env.gym.metrics.config import (
    METRICS_REGISTRY,
    list_available_metrics,
    print_metrics_registry,
)
from storage_node_env.gym.metrics.utils import (
    validate_node_type,
    validate_results_dataframe,
)
from storage_node_env.gym.metrics.visualizations import (
    MATPLOTLIB_AVAILABLE,
    create_comparison_dashboard,
    create_dashboard,
    plot_controller_comparison,
    plot_cost_analysis,
    plot_distribution,
    plot_power_flows,
    plot_soc_timeseries,
)


def compute_metrics(
    df: pd.DataFrame,
    node_type: str,
    categories: list[str] | None = None,
    battery_config: dict | None = None
) -> MetricsReport:
    """
    Compute metrics from simulation results DataFrame.

    This is the main entry point for metrics calculation. It computes
    all applicable metrics organized by category (economic, battery,
    grid, self-consumption, violations).

    Args:
        df: Results DataFrame from environment tracking.
        node_type: Type of energy node ('producer' or 'prosumer').
        categories: Specific categories to compute (None = all).
                   Options: 'economic', 'battery', 'grid',
                           'self_consumption', 'violations'.
        battery_config: Optional battery configuration dict. If provided, enables
                       more accurate calculations for battery metrics. Expected keys:
                       - capacity: Battery capacity (kWh)
                       - dod_max: Maximum depth of discharge (%)
                       - power_charge_max: Maximum charging power (kW)
                       - power_discharge_max: Maximum discharging power (kW)
                       - efficiency_charge: Charging efficiency (0-1)
                       - efficiency_discharge: Discharging efficiency (0-1)

    Returns:
        MetricsReport object containing computed metrics.

    Raises:
        ValueError: If DataFrame is invalid or node_type is invalid.
        TypeError: If df is not a pandas DataFrame.

    Example:
        >>> # compute all metrics
        >>> report = compute_metrics(df, node_type='prosumer')
        >>> print(report.summary())
        >>>
        >>> # compute specific categories
        >>> report = compute_metrics(df, 'prosumer', categories=['economic', 'battery'])
        >>> economic = report.get_category('economic')
        >>> print(economic['total_cost_eur'])
        >>>
        >>> # compute with battery configuration for accurate metrics
        >>> battery_config = {
        ...     'capacity': 5.12,
        ...     'dod_max': 90,
        ...     'power_charge_max': 2.5,
        ...     'power_discharge_max': 2.5,
        ...     'efficiency_charge': 0.95,
        ...     'efficiency_discharge': 0.95
        ... }
        >>> report = compute_metrics(df, 'prosumer', battery_config=battery_config)
        >>> battery = report.get_category('battery')
        >>> print(battery['charge_cycle_count'])  # accurate cycle count
    """
    # validate inputs
    validate_results_dataframe(df)
    validate_node_type(node_type)

    # create report
    report = MetricsReport(df, node_type)

    # define calculators
    all_calculators = {
        'economic': EconomicMetricsCalculator,
        'battery': BatteryMetricsCalculator,
        'grid': GridMetricsCalculator,
        'self_consumption': SelfConsumptionMetricsCalculator,
        'violations': ViolationMetricsCalculator,
    }

    # filter categories if specified
    if categories is not None:
        calculators_to_run = {k: v for k, v in all_calculators.items() if k in categories}
    else:
        calculators_to_run = all_calculators

    # compute metrics for each category
    for category_name, calculator_class in calculators_to_run.items():
        calculator = calculator_class(df, node_type, battery_config=battery_config)
        metrics = calculator.calculate()

        # only add if metrics were computed (e.g., self_consumption returns empty for producer)
        if metrics:
            report.add_category(category_name, metrics)

    return report


def visualize(
    df: pd.DataFrame,
    node_type: str,
    visualization_type: str = 'dashboard',
    save_path: str | None = None,
    figsize: tuple[float, float] | None = None,
    battery_config: dict | None = None,
    aggregate_window: int | None = None,
    **kwargs: Any
) -> Any:
    """
    Generate visualization from results DataFrame.

    Creates various types of plots to visualize simulation results
    and performance metrics.

    Args:
        df: Results DataFrame from environment tracking.
        node_type: Type of energy node ('producer' or 'prosumer').
        visualization_type: Type of visualization to create.
            Options: 'dashboard', 'soc', 'power', 'cost', 'distribution'.
        save_path: Optional file path to save figure.
        figsize: Optional figure size (width, height). Uses defaults if None.
        battery_config: Optional battery configuration dict. If provided,
                       adds reference lines for capacity/power bounds.
        aggregate_window: Optional target number of points for LTTB downsampling.
                         If None, plots all points (default behavior).
                         Applied to time series plots only (not distributions).
                         Recommended: 1000-2000 for large datasets (8760+ points).
        **kwargs: Additional arguments passed to visualization functions.

    Returns:
        matplotlib Figure object.

    Raises:
        ImportError: If matplotlib is not installed.
        ValueError: If DataFrame is invalid or visualization_type is unknown.

    Example:
        >>> # create dashboard
        >>> fig = visualize(df, 'prosumer', 'dashboard')
        >>> fig.savefig('dashboard.png', dpi=150, bbox_inches='tight')
        >>> plt.close(fig)
        >>>
        >>> # create specific plot
        >>> fig = visualize(df, 'prosumer', 'soc', figsize=(14, 4))
        >>> plt.show()
        >>>
        >>> # create dashboard with battery specs
        >>> battery_config = {'capacity': 5.12, 'dod_max': 90, ...}
        >>> fig = visualize(df, 'prosumer', 'dashboard', battery_config=battery_config)
        >>> fig.savefig('dashboard.png')
        >>>
        >>> # create dashboard with downsampling for large dataset
        >>> fig = visualize(df, 'prosumer', 'dashboard', aggregate_window=1500)
        >>> fig.savefig('dashboard_downsampled.png')
    """
    if not MATPLOTLIB_AVAILABLE:
        raise ImportError(
            'matplotlib is required for visualization. '
            'Install it with: pip install storage-node-env[visualization]'
        )

    # validate inputs
    validate_results_dataframe(df)
    validate_node_type(node_type)

    # create visualization based on type
    if visualization_type == 'dashboard':
        fig = create_dashboard(
            df,
            node_type,
            figsize=figsize or (16, 10),
            battery_config=battery_config,
            aggregate_window=aggregate_window
        )
    elif visualization_type == 'soc':
        fig, _ = plot_soc_timeseries(
            df,
            figsize=figsize or (12, 4),
            battery_config=battery_config,
            aggregate_window=aggregate_window
        )
    elif visualization_type == 'power':
        fig, _ = plot_power_flows(
            df,
            figsize=figsize or (14, 5),
            battery_config=battery_config,
            aggregate_window=aggregate_window
        )
    elif visualization_type == 'cost':
        fig, _ = plot_cost_analysis(
            df,
            node_type,
            figsize=figsize or (12, 4),
            aggregate_window=aggregate_window
        )
    elif visualization_type == 'distribution':
        # default to SoC distribution
        column = kwargs.get('column', 'soc_final_pct')
        fig, _ = plot_distribution(
            df,
            column,
            bins=kwargs.get('bins', 30),
            figsize=figsize or (10, 4)
        )
    else:
        raise ValueError(
            f'Unknown visualization_type: {visualization_type}. '
            f'Valid options: dashboard, soc, power, cost, distribution'
        )

    # save if path provided
    if save_path is not None:
        fig.savefig(save_path, dpi=kwargs.get('dpi', 150), bbox_inches='tight')

    return fig


def compare_controllers(
    results: dict[str, pd.DataFrame],
    node_type: str,
    save_path: str | None = None,
    figsize: tuple[float, float] = (16, 10),
    battery_config: dict | None = None,
    day: str | None = None
) -> Any:
    """
    Create comparison dashboard for multiple controllers.

    Generates side-by-side comparisons of metrics and visualizations
    across different controllers.

    Args:
        results: Dictionary mapping controller names to result DataFrames.
        node_type: Type of energy node ('producer' or 'prosumer').
        save_path: Optional file path to save figure.
        figsize: Figure size (width, height).
        battery_config: Optional battery configuration dict. If provided,
                       adds capacity bounds to SoC comparison plot.
        day: Optional specific day to show in SoC comparison (format: 'YYYY-MM-DD').
             If None, shows all data (may be cluttered for large datasets).
             Other plots (costs, violations, self-consumption) remain global.

    Returns:
        matplotlib Figure object with comparison visualizations.

    Raises:
        ImportError: If matplotlib is not installed.

    Example:
        >>> results = {
        ...     'naive': env.results['naive'],
        ...     'ppo': env.results['ppo'],
        ...     'self_consumption': env.results['self_consumption']
        ... }
        >>> fig = compare_controllers(results, 'prosumer')
        >>> fig.savefig('comparison.png', dpi=150, bbox_inches='tight')
        >>> plt.close(fig)
        >>>
        >>> # with battery config
        >>> battery_config = {'capacity': 5.12, 'dod_max': 90, ...}
        >>> fig = compare_controllers(results, 'prosumer', battery_config=battery_config)
        >>> fig.savefig('comparison.png')
        >>>
        >>> # compare controllers for specific day
        >>> fig = compare_controllers(results, 'prosumer', day='2024-01-15')
        >>> fig.savefig('comparison_2024-01-15.png', dpi=150, bbox_inches='tight')
    """
    if not MATPLOTLIB_AVAILABLE:
        raise ImportError(
            'matplotlib is required for visualization. '
            'Install it with: pip install storage-node-env[visualization]'
        )

    # validate inputs
    validate_node_type(node_type)

    for name, df in results.items():
        validate_results_dataframe(df)

    # create comparison dashboard
    fig = create_comparison_dashboard(
        results,
        node_type,
        figsize=figsize,
        battery_config=battery_config,
        day=day
    )

    # save if path provided
    if save_path is not None:
        fig.savefig(save_path, dpi=150, bbox_inches='tight')

    return fig


# public API exports
__all__ = [
    # main functions
    'compute_metrics',
    'compute_metrics_by_period',
    'visualize',
    'compare_controllers',
    # classes
    'MetricsReport',
    'MetricCalculator',
    # configuration
    'METRICS_REGISTRY',
    'list_available_metrics',
    'print_metrics_registry',
    # aggregation and downsampling functions
    'apply_lttb_aggregation',
    'filter_to_day',
    # visualization functions (for advanced use)
    'plot_soc_timeseries',
    'plot_power_flows',
    'plot_cost_analysis',
    'plot_distribution',
    'plot_controller_comparison',
    'create_dashboard',
    'create_comparison_dashboard',
]
