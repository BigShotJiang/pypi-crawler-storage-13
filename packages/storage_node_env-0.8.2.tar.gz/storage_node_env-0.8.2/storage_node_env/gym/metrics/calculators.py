"""
Concrete metric calculator implementations.

This module provides calculator classes for different categories of metrics,
each inheriting from MetricCalculator base class.
"""

import pandas as pd

from storage_node_env.gym.metrics import functions as fn
from storage_node_env.gym.metrics.base import MetricCalculator


class EconomicMetricsCalculator(MetricCalculator):
    """
    Calculate economic metrics: costs, revenues, profits.

    Computes metrics related to electricity costs, revenues,
    and economic performance of the energy system.
    """

    def calculate(self) -> dict[str, float]:
        """
        Calculate all economic metrics.

        Returns:
            Dictionary with economic metrics.
        """
        return {
            'total_cost_eur': fn.calculate_total_cost(self.df),
            'total_revenue_eur': fn.calculate_total_revenue(self.df),
            'net_profit_loss_eur': fn.calculate_net_profit_loss(self.df, self.node_type),
            'mean_import_price_eur_kwh': fn.calculate_mean_import_price(self.df),
            'mean_export_price_eur_kwh': fn.calculate_mean_export_price(self.df),
        }


class SelfConsumptionMetricsCalculator(MetricCalculator):
    """
    Calculate self-consumption metrics.

    Computes metrics related to local energy consumption
    and self-sufficiency (prosumer nodes only).
    """

    def calculate(self) -> dict[str, float]:
        """
        Calculate all self-consumption metrics.

        Returns:
            Dictionary with self-consumption metrics.

        Note:
            Returns empty dict for producer nodes (not applicable).
        """
        if self.node_type != 'prosumer':
            return {}

        return {
            'mean_selfcons_ratio_pct': fn.calculate_mean_selfcons_ratio(self.df),
            'mean_selfsuff_ratio_pct': fn.calculate_mean_selfsuff_ratio(self.df),
            'total_selfcons_energy_kwh': fn.calculate_total_selfcons_energy(self.df),
        }


class BatteryMetricsCalculator(MetricCalculator):
    """
    Calculate battery performance metrics.

    Computes metrics related to battery operation,
    state of charge, and energy throughput.

    If battery_config is provided, computes enhanced metrics with accurate
    calculations and additional utilization metrics.
    """

    def calculate(self) -> dict[str, float]:
        """
        Calculate all battery metrics.

        Returns:
            Dictionary with battery metrics. If battery_config is provided,
            includes additional power and capacity utilization metrics.
        """
        metrics = {
            'total_charge_energy_kwh': fn.calculate_total_charge_energy(self.df),
            'total_discharge_energy_kwh': fn.calculate_total_discharge_energy(self.df),
            'charge_cycle_count': fn.calculate_charge_cycle_count(
                self.df,
                self.battery_config
            ),
            'mean_soc_pct': fn.calculate_mean_soc(self.df),
            'min_soc_pct': fn.calculate_min_soc(self.df),
            'max_soc_pct': fn.calculate_max_soc(self.df),
            'soc_range_pct': fn.calculate_soc_range(self.df),
            'battery_efficiency_pct': fn.calculate_battery_efficiency(
                self.df,
                self.battery_config
            ),
        }

        # add utilization metrics if battery_config available
        if self.battery_config is not None:
            # power utilization metrics
            power_util = fn.calculate_power_utilization(self.df, self.battery_config)
            metrics.update(power_util)

            # capacity utilization metrics
            capacity_util = fn.calculate_capacity_utilization(self.df, self.battery_config)
            metrics.update(capacity_util)

        return metrics


class GridMetricsCalculator(MetricCalculator):
    """
    Calculate grid interaction metrics.

    Computes metrics related to energy import/export
    and grid dependency.
    """

    def calculate(self) -> dict[str, float]:
        """
        Calculate all grid metrics.

        Returns:
            Dictionary with grid metrics.
        """
        metrics = {
            'total_import_energy_kwh': fn.calculate_total_import_energy(self.df),
            'total_export_energy_kwh': fn.calculate_total_export_energy(self.df),
            'import_export_ratio': fn.calculate_import_export_ratio(self.df),
        }

        # grid independence only for prosumers
        if self.node_type == 'prosumer':
            metrics['grid_independence_pct'] = fn.calculate_grid_independence(self.df)

        return metrics


class ViolationMetricsCalculator(MetricCalculator):
    """
    Calculate constraint violation metrics.

    Computes metrics related to power constraint violations
    during battery operation.
    """

    def calculate(self) -> dict[str, float]:
        """
        Calculate all violation metrics.

        Returns:
            Dictionary with violation metrics.
        """
        return {
            'total_violations_kw': fn.calculate_total_violations(self.df),
            'max_violation_kw': fn.calculate_max_violation(self.df),
            'violation_count': float(fn.calculate_violation_count(self.df)),
            'violation_percentage_pct': fn.calculate_violation_percentage(self.df),
        }
