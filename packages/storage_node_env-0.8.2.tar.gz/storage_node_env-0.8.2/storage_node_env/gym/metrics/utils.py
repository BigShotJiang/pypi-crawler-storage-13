"""
Utility functions for metrics package.

This module provides validation, formatting, and helper utilities
for the metrics calculation and visualization system.
"""

import pandas as pd


# required columns for metrics calculation
REQUIRED_COLUMNS = [
    'datetime',
    'controller',
    'episode',
    'timestep',
    'action_index',
    'action_kw',
]

ECONOMIC_COLUMNS = [
    'import_cost_eur',
    'export_revenue_eur',
]

BATTERY_COLUMNS = [
    'soc_final_pct',
    'battery_charge_kwh',
    'battery_discharge_kwh',
    'soc_delta_pct',
]

GRID_COLUMNS = [
    'import_energy_kwh',
    'export_energy_kwh',
    'grid_power_kw',
]

VIOLATION_COLUMNS = [
    'violation_kw',
]


def validate_results_dataframe(df: pd.DataFrame) -> None:
    """
    Validate that DataFrame has required structure for metrics calculation.

    Args:
        df: Results DataFrame to validate.

    Raises:
        ValueError: If DataFrame is empty or missing required columns.
        TypeError: If input is not a pandas DataFrame.

    Example:
        >>> validate_results_dataframe(df)  # raises if invalid
    """
    # check type
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f'Expected pandas DataFrame, got {type(df).__name__}')

    # check not empty
    if df.empty:
        raise ValueError('Results DataFrame is empty')

    # check required columns
    missing_required = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    if missing_required:
        raise ValueError(
            f'Results DataFrame missing required columns: {missing_required}. '
            f'Available columns: {list(df.columns)}'
        )


def validate_node_type(node_type: str) -> None:
    """
    Validate node type parameter.

    Args:
        node_type: Node type string to validate.

    Raises:
        ValueError: If node_type is not 'producer' or 'prosumer'.

    Example:
        >>> validate_node_type('prosumer')  # ok
        >>> validate_node_type('invalid')   # raises ValueError
    """
    valid_types = ['producer', 'prosumer']
    if node_type not in valid_types:
        raise ValueError(
            f'Invalid node_type: {node_type}. '
            f'Must be one of: {valid_types}'
        )


def format_metric_value(value: float, unit: str, decimals: int = 2) -> str:
    """
    Format metric value with unit for display.

    Args:
        value: Metric value to format.
        unit: Unit of measurement.
        decimals: Number of decimal places (default: 2).

    Returns:
        Formatted string with value and unit.

    Example:
        >>> format_metric_value(42.3456, 'eur', 2)
        '42.35 €'
        >>> format_metric_value(85.678, 'pct', 1)
        '85.7%'
    """
    # format number
    formatted_value = f'{value:.{decimals}f}'

    # add unit symbol
    unit_map = {
        'eur': '€',
        'eur_kwh': '€/kWh',
        'kwh': 'kWh',
        'kw': 'kW',
        'pct': '%',
        'count': '',
        'ratio': '',
    }

    unit_symbol = unit_map.get(unit, unit)

    if unit_symbol:
        return f'{formatted_value} {unit_symbol}'
    return formatted_value


def create_comparison_table(
    results: dict[str, pd.DataFrame],
    metrics_dict: dict[str, dict[str, dict[str, float]]]
) -> pd.DataFrame:
    """
    Create comparison table of metrics across controllers.

    Args:
        results: Dictionary mapping controller names to DataFrames.
        metrics_dict: Nested dict: {controller: {category: {metric: value}}}.

    Returns:
        DataFrame with controllers as rows and metrics as columns.

    Example:
        >>> table = create_comparison_table(results, metrics)
        >>> print(table)
                  total_cost_eur  mean_soc_pct  ...
        naive           57.92          45.2
        ppo             42.35          52.8
    """
    # flatten metrics dict
    rows = []
    for controller, categories in metrics_dict.items():
        row = {'controller': controller}
        for category, metrics in categories.items():
            for metric_name, value in metrics.items():
                row[metric_name] = value
        rows.append(row)

    # create DataFrame
    df = pd.DataFrame(rows)
    df = df.set_index('controller')

    return df


def get_available_columns(df: pd.DataFrame, column_list: list[str]) -> list[str]:
    """
    Get subset of columns that exist in DataFrame.

    Args:
        df: DataFrame to check.
        column_list: List of column names to filter.

    Returns:
        List of columns that exist in the DataFrame.

    Example:
        >>> available = get_available_columns(df, ['soc_final_pct', 'missing_col'])
        >>> print(available)
        ['soc_final_pct']
    """
    return [col for col in column_list if col in df.columns]


def detect_node_type(df: pd.DataFrame) -> str:
    """
    Detect node type from DataFrame columns.

    Args:
        df: Results DataFrame.

    Returns:
        'prosumer' if consumption columns present, else 'producer'.

    Example:
        >>> node_type = detect_node_type(df)
        >>> print(node_type)
        'prosumer'
    """
    # prosumer has net_cost, producer has net_profit
    if 'net_cost_eur' in df.columns or 'consumption_kw' in df.columns:
        return 'prosumer'
    return 'producer'


def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """
    Safely divide two numbers, returning default if denominator is zero.

    Args:
        numerator: Numerator value.
        denominator: Denominator value.
        default: Value to return if denominator is zero (default: 0.0).

    Returns:
        Division result or default value.

    Example:
        >>> result = safe_divide(10, 2)
        >>> print(result)
        5.0
        >>> result = safe_divide(10, 0, default=0.0)
        >>> print(result)
        0.0
    """
    if denominator == 0:
        return default
    return numerator / denominator
