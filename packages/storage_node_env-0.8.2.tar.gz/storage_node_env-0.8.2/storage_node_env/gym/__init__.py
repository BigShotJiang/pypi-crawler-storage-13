"""
Gymnasium environment for energy storage optimization.

This package provides a Gymnasium-compliant reinforcement learning environment
for battery energy storage system control in producer and prosumer nodes.

Main components:
    - EnergyStorageEnv: Main Gymnasium environment
    - Preprocessing: Observation encoding and normalization
    - Rewards: Modular reward calculation system

Example (direct import):
    >>> from storage_node_env.gym import EnergyStorageEnv
    >>> battery_config = {
    ...     'capacity': 5.12,
    ...     'dod_max': 90,
    ...     'power_charge_max': 2.5,
    ...     'power_discharge_max': 2.5,
    ...     'efficiency_charge': 0.95,
    ...     'efficiency_discharge': 0.95
    ... }
    >>> env = EnergyStorageEnv(
    ...     node_type='prosumer',
    ...     csv_path='data.csv',
    ...     battery_config=battery_config,
    ...     delta_t=1.0
    ... )
    >>> obs, info = env.reset()

Example (Gymnasium registration):
    >>> import gymnasium as gym
    >>> import storage_node_env
    >>> env = gym.make(
    ...     'storage_node_env/EnergyStorage-v0',
    ...     node_type='prosumer',
    ...     csv_path='data.csv',
    ...     battery_config=battery_config,
    ...     delta_t=1.0
    ... )
    >>> obs, info = env.reset()
"""

from gymnasium.envs.registration import register

from storage_node_env.gym.controllers import print_controllers
from storage_node_env.gym.energy_storage_env import EnergyStorageEnv
from storage_node_env.gym.metrics import (
    compare_controllers,
    compute_metrics,
    compute_metrics_by_period,
    list_available_metrics,
    visualize,
)
from storage_node_env.gym.rewards import (
    list_available_rewards,
    print_reward_registry,
)
from storage_node_env.gym.tracking import ResultsCallback, ResultsTracker
from storage_node_env.gym.tracking.utils import summarize_results


def register_envs() -> None:
    """
    Register all storage_node_env environments with Gymnasium.

    This function is called automatically when the package is imported,
    and also serves as the entry point for Gymnasium's plugin system.
    """
    register(
        id='storage_node_env/EnergyStorage-v0',
        entry_point='storage_node_env.gym:EnergyStorageEnv',
    )


# Auto-register environments on import
register_envs()


__all__ = [
    'EnergyStorageEnv',
    'list_available_rewards',
    'print_reward_registry',
    'print_controllers',
    'ResultsTracker',
    'ResultsCallback',
    'summarize_results',
    'compute_metrics',
    'compute_metrics_by_period',
    'visualize',
    'compare_controllers',
    'list_available_metrics',
]
