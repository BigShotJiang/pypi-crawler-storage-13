"""
Abstract base class for reward calculators.

This module provides the base class for all reward calculators, implementing
common penalty functions and the reward composition logic.
"""

from abc import ABC, abstractmethod
from typing import Any


class RewardCalculator(ABC):
    """
    Abstract base class for reward calculation in energy storage environments.

    This class provides a framework for calculating rewards as a weighted combination
    of a main reward component and two penalty terms (violation and storage usage).
    Subclasses must implement the main reward logic while inheriting common penalties.

    Attributes:
        weight_main: Weight coefficient for main reward component.
        weight_violation: Weight coefficient for violation penalty.
        weight_storage_usage: Weight coefficient for storage usage penalty.
        normalize: Whether to apply normalization to rewards.
        node_type: Type of energy node ('producer' or 'prosumer').

    Example:
        >>> calculator = SelfConsumptionReward(
        ...     weights={'main': 1.0, 'violation_penalty': 0.1, 'storage_usage_penalty': 0.01},
        ...     normalize=False,
        ...     node_type='prosumer'
        ... )
        >>> reward = calculator.calculate(node_results)
    """

    def __init__(
        self,
        weights: dict[str, float],
        normalize: bool = False,
        node_type: str = 'prosumer'
    ) -> None:
        """
        Initialize the reward calculator.

        Args:
            weights: Dictionary with weight coefficients:
                - 'main': Weight for main reward component (default: 1.0)
                - 'violation_penalty': Weight for violation penalty (default: 0.1)
                - 'storage_usage_penalty': Weight for storage usage penalty (default: 0.01)
            normalize: Whether to apply normalization to rewards. Defaults to False.
            node_type: Type of energy node ('producer' or 'prosumer'). Defaults to 'prosumer'.

        Raises:
            ValueError: If node_type is not 'producer' or 'prosumer'.
        """
        if node_type not in ['producer', 'prosumer']:
            raise ValueError(f'node_type must be "producer" or "prosumer", got: {node_type}')

        self.weight_main = weights.get('main', 1.0)
        self.weight_violation = weights.get('violation_penalty', 0.1)
        self.weight_storage_usage = weights.get('storage_usage_penalty', 0.01)
        self.normalize = normalize
        self.node_type = node_type

    @abstractmethod
    def _calculate_main_reward(self, node_results: dict[str, Any]) -> float:
        """
        Calculate the main reward component (must be implemented by subclasses).

        Args:
            node_results: Dictionary containing node step results with all state
                information (production, consumption, prices, SoC, power flows, etc.).

        Returns:
            Main reward value (non-negative, higher is better).

        Note:
            This method should return a non-negative value representing the
            desirable outcome (e.g., profit, self-consumption ratio, etc.).
        """

    def _calculate_violation_penalty(self, node_results: dict[str, Any]) -> float:
        """
        Calculate penalty for power constraint violations.

        This penalty discourages actions that exceed battery power bounds,
        helping the agent learn to stay within physical constraints.

        Args:
            node_results: Dictionary containing node step results.

        Returns:
            Violation penalty value (non-negative, 0 if no violation).

        Note:
            - Violation is measured in kW (absolute value)
            - Penalty is proportional to violation magnitude
            - Returns 0 if no violation occurred
        """
        violation = node_results.get('violation', 0.0)
        return abs(violation)

    def _calculate_storage_usage_penalty(self, node_results: dict[str, Any]) -> float:
        """
        Calculate penalty for battery storage usage to discourage unnecessary cycling.

        This penalty represents battery wear and degradation from charge/discharge
        cycles, encouraging the agent to use storage only when beneficial.

        Args:
            node_results: Dictionary containing node step results.

        Returns:
            Storage usage penalty value (non-negative, proportional to energy throughput).

        Note:
            - Penalty is based on absolute energy change in battery (kWh)
            - Calculated as: |final_soc - initial_soc| / 100 * C_nom
            - Independent of charge/discharge direction
        """
        initial_soc = node_results.get('initial_soc', 0.0)  # in %
        final_soc = node_results.get('final_soc', 0.0)      # in %

        # calculate absolute SoC change (in percentage points)
        soc_change = abs(final_soc - initial_soc)

        # penalty proportional to percentage change
        # note: we don't need C_nom since we work in percentage space
        return soc_change

    def calculate(self, node_results: dict[str, Any]) -> float:
        """
        Calculate the total reward as weighted combination of components.

        The final reward is computed as:
            reward = w_main * R_main - w_violation * P_violation - w_usage * P_usage

        Where:
            - R_main: Main reward component (implementation-specific)
            - P_violation: Penalty for power constraint violations
            - P_usage: Penalty for battery usage (wear/degradation)
            - w_*: Weight coefficients

        Args:
            node_results: Dictionary containing node step results with fields:
                - violation: Power constraint violation (kW)
                - initial_soc: Initial state of charge (%)
                - final_soc: Final state of charge (%)
                - ... (other fields used by main reward)

        Returns:
            Total reward value (can be positive or negative after penalties).

        Example:
            >>> node_results = {
            ...     'violation': 0.0,
            ...     'initial_soc': 50.0,
            ...     'final_soc': 55.0,
            ...     'net_profit': 0.15,
            ...     ...
            ... }
            >>> reward = calculator.calculate(node_results)
        """
        # calculate main reward component
        main_reward = self._calculate_main_reward(node_results)

        # calculate penalty components
        violation_penalty = self._calculate_violation_penalty(node_results)
        storage_usage_penalty = self._calculate_storage_usage_penalty(node_results)

        # weighted combination
        total_reward = (
            self.weight_main * main_reward
            - self.weight_violation * violation_penalty
            - self.weight_storage_usage * storage_usage_penalty
        )

        # optional normalization (to be implemented if needed)
        if self.normalize:
            total_reward = self._normalize_reward(total_reward)

        return total_reward

    def _normalize_reward(self, reward: float) -> float:
        """
        Normalize reward to a specific range (optional, for future use).

        Args:
            reward: Raw reward value.

        Returns:
            Normalized reward value.

        Note:
            Currently returns the raw reward unchanged. Can be extended
            to implement specific normalization strategies (e.g., min-max,
            standardization, clipping).
        """
        # placeholder for future normalization implementation
        return reward

    def __repr__(self) -> str:
        """
        Return string representation of the reward calculator.

        Returns:
            Formatted string with calculator type and configuration.
        """
        return (
            f'{self.__class__.__name__}('
            f'weights=[main={self.weight_main}, '
            f'violation={self.weight_violation}, '
            f'usage={self.weight_storage_usage}], '
            f'normalize={self.normalize}, '
            f'node_type=\'{self.node_type}\')'
        )
