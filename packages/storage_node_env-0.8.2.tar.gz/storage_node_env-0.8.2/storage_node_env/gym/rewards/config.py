"""
Reward configuration and registry.

This module provides configuration dataclasses and a registry of available
reward types for the energy storage environment.
"""

from dataclasses import dataclass
from typing import Any


@dataclass
class RewardConfig:
    """
    Configuration for a reward calculator.

    Attributes:
        name: Identifier name of the reward type.
        description: Human-readable description of the reward objective.
        suitable_for: List of node types this reward is suitable for
            ('producer', 'prosumer', or 'both').
        default_weights: Default weight coefficients for reward components.

    Example:
        >>> config = RewardConfig(
        ...     name='self_consumption',
        ...     description='Maximize self-consumption ratio',
        ...     suitable_for=['prosumer'],
        ...     default_weights={'main': 1.0, 'violation_penalty': 0.1,
        ...                      'storage_usage_penalty': 0.01}
        ... )
    """

    name: str
    description: str
    suitable_for: list[str]
    default_weights: dict[str, float]


# Registry of available reward types
REWARD_REGISTRY: dict[str, RewardConfig] = {
    'self_consumption': RewardConfig(
        name='self_consumption',
        description='Maximize self-consumption and grid independence for prosumer nodes',
        suitable_for=['prosumer'],
        default_weights={
            'main': 1.0,
            'violation_penalty': 0.1,
            'storage_usage_penalty': 0.01
        }
    ),
    'energy_arbitrage': RewardConfig(
        name='energy_arbitrage',
        description='Maximize profit through energy arbitrage (buy low, sell high)',
        suitable_for=['producer', 'prosumer'],
        default_weights={
            'main': 1.0,
            'violation_penalty': 0.1,
            'storage_usage_penalty': 0.01
        }
    )
}


def get_reward_config(reward_type: str) -> RewardConfig:
    """
    Get reward configuration by type name.

    Args:
        reward_type: Name of the reward type (e.g., 'self_consumption').

    Returns:
        RewardConfig object for the specified reward type.

    Raises:
        ValueError: If reward_type is not found in registry.

    Example:
        >>> config = get_reward_config('self_consumption')
        >>> print(config.description)
    """
    if reward_type not in REWARD_REGISTRY:
        available = ', '.join(REWARD_REGISTRY.keys())
        raise ValueError(
            f'Unknown reward type: \'{reward_type}\'. '
            f'Available types: {available}'
        )
    return REWARD_REGISTRY[reward_type]


def list_available_rewards() -> list[str]:
    """
    Get list of all available reward types.

    Returns:
        List of reward type names.

    Example:
        >>> rewards = list_available_rewards()
        >>> print(rewards)
        ['self_consumption', 'energy_arbitrage']
    """
    return list(REWARD_REGISTRY.keys())


def validate_reward_settings(
    reward_settings: dict[str, Any],
    node_type: str
) -> dict[str, Any]:
    """
    Validate and complete reward settings dictionary.

    This function checks that reward_settings contains valid configuration,
    fills in default values where needed, and validates compatibility with
    the specified node type.

    Args:
        reward_settings: Dictionary with reward configuration:
            - type: Reward type name (required)
            - weights: Weight coefficients (optional, uses defaults if missing)
            - normalize: Whether to normalize rewards (optional, defaults to False)
        node_type: Type of energy node ('producer' or 'prosumer').

    Returns:
        Validated and completed reward settings dictionary.

    Raises:
        ValueError: If reward_settings is invalid or incompatible with node_type.

    Example:
        >>> settings = {'type': 'self_consumption'}
        >>> validated = validate_reward_settings(settings, 'prosumer')
        >>> print(validated['weights'])
    """
    # validate reward_settings is a dict
    if not isinstance(reward_settings, dict):
        raise ValueError(
            f'reward_settings must be a dict, got: {type(reward_settings).__name__}'
        )

    # check 'type' is present
    if 'type' not in reward_settings:
        raise ValueError('reward_settings must contain \'type\' key')

    reward_type = reward_settings['type']

    # get reward config from registry
    try:
        config = get_reward_config(reward_type)
    except ValueError as e:
        raise ValueError(f'Invalid reward type in reward_settings: {e}') from e

    # validate node_type compatibility
    if 'both' not in config.suitable_for and node_type not in config.suitable_for:
        raise ValueError(
            f'Reward type \'{reward_type}\' is not suitable for node_type=\'{node_type}\'. '
            f'Suitable for: {config.suitable_for}'
        )

    # create validated settings with defaults
    validated = {
        'type': reward_type,
        'weights': reward_settings.get('weights', config.default_weights.copy()),
        'normalize': reward_settings.get('normalize', False)
    }

    # validate weights is a dict
    if not isinstance(validated['weights'], dict):
        raise ValueError(
            f'weights must be a dict, got: {type(validated["weights"]).__name__}'
        )

    # fill in missing weights with defaults
    for key, default_value in config.default_weights.items():
        if key not in validated['weights']:
            validated['weights'][key] = default_value

    # validate weight values are numeric
    for key, value in validated['weights'].items():
        if not isinstance(value, (int, float)):
            raise ValueError(
                f'Weight \'{key}\' must be numeric, got: {type(value).__name__}'
            )

    # validate normalize is boolean
    if not isinstance(validated['normalize'], bool):
        raise ValueError(
            f'normalize must be bool, got: {type(validated["normalize"]).__name__}'
        )

    return validated


def get_default_reward_settings(node_type: str) -> dict[str, Any]:
    """
    Get default reward settings for a given node type.

    Args:
        node_type: Type of energy node ('producer' or 'prosumer').

    Returns:
        Default reward settings dictionary.

    Example:
        >>> settings = get_default_reward_settings('prosumer')
        >>> print(settings['type'])
        self_consumption
    """
    # default reward type based on node type
    if node_type == 'prosumer':
        default_type = 'self_consumption'
    else:  # producer
        default_type = 'energy_arbitrage'

    config = get_reward_config(default_type)

    return {
        'type': default_type,
        'weights': config.default_weights.copy(),
        'normalize': False
    }


def print_reward_registry() -> None:
    """
    Print formatted information about all available rewards.

    Example:
        >>> print_reward_registry()
        Available Reward Types:
        -----------------------
        1. self_consumption
           Description: Maximize self-consumption and grid independence for prosumer nodes
           Suitable for: ['prosumer']
           Default weights: {'main': 1.0, 'violation_penalty': 0.1, 'storage_usage_penalty': 0.01}
        ...
    """
    print('Available Reward Types:')
    print('-' * 50)

    for idx, (name, config) in enumerate(REWARD_REGISTRY.items(), 1):
        print(f'{idx}. {name}')
        print(f'   Description: {config.description}')
        print(f'   Suitable for: {config.suitable_for}')
        print(f'   Default weights: {config.default_weights}')
        print()
