"""
Utility functions for results management.

This module provides helper functions for formatting, validation,
and manipulation of results data.
"""

import os
from typing import Any

import pandas as pd


def save_dataframe_to_csv(
    df: pd.DataFrame,
    filepath: str,
    create_dirs: bool = True
) -> None:
    """
    Save DataFrame to CSV file with automatic directory creation.

    Args:
        df: DataFrame to save.
        filepath: Destination file path.
        create_dirs: If True, create parent directories if they don't exist.

    Example:
        >>> save_dataframe_to_csv(df, 'results/controller_name.csv')
    """
    if create_dirs:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)

    df.to_csv(filepath, index=False)


def validate_controller_name(name: str) -> None:
    """
    Validate controller name format.

    Args:
        name: Controller name to validate.

    Raises:
        ValueError: If name is empty or contains invalid characters.

    Example:
        >>> validate_controller_name('naive_controller')
        >>> validate_controller_name('')  # raises ValueError
    """
    if not name:
        raise ValueError('Controller name cannot be empty')

    if not isinstance(name, str):
        raise ValueError(f'Controller name must be string, got {type(name).__name__}')

    # check for filesystem-unsafe characters
    invalid_chars = ['/', '\\', ':', '*', '?', '"', '<', '>', '|']
    if any(char in name for char in invalid_chars):
        raise ValueError(
            f'Controller name contains invalid characters. '
            f'Avoid: {", ".join(invalid_chars)}'
        )


def get_column_order(node_type: str) -> list[str]:
    """
    Get the standard column order for results CSV.

    Args:
        node_type: Type of energy node ('producer' or 'prosumer').

    Returns:
        List of column names in standard order.

    Example:
        >>> cols = get_column_order('prosumer')
        >>> print(cols[0:3])
        ['controller', 'episode', 'timestep']
    """
    # common columns
    columns = [
        'controller',
        'episode',
        'timestep',
        'action_index',
        'action_kw',
        'production_kw',
        'consumption_kw',
        'energy_balance_kw',
        'soc_final_pct',
        'grid_power_kw',
        'import_power_kw',
        'export_power_kw',
        'import_energy_kwh',
        'export_energy_kwh',
        'import_cost_eur',
        'export_revenue_eur',
    ]

    # add node-specific economic column
    if node_type == 'producer':
        columns.append('net_profit_eur')
    else:  # prosumer
        columns.append('net_cost_eur')

    # add remaining common columns
    columns.extend([
        'violation_kw',
        'selfcons_energy_kwh',
        'selfcons_ratio',
        'selfsuff_energy_kwh',
        'selfsuff_ratio',
        'battery_charge_kwh',
        'battery_discharge_kwh',
        'soc_delta_pct',
    ])

    return columns


def reorder_dataframe_columns(df: pd.DataFrame, node_type: str) -> pd.DataFrame:
    """
    Reorder DataFrame columns to standard format.

    Args:
        df: DataFrame to reorder.
        node_type: Type of energy node ('producer' or 'prosumer').

    Returns:
        DataFrame with columns in standard order.

    Example:
        >>> df_ordered = reorder_dataframe_columns(df, 'prosumer')
    """
    standard_order = get_column_order(node_type)

    # get columns that exist in both standard order and dataframe
    available_columns = [col for col in standard_order if col in df.columns]

    # add any extra columns not in standard order
    extra_columns = [col for col in df.columns if col not in standard_order]

    return df[available_columns + extra_columns]


def summarize_results(df: pd.DataFrame, node_type: str) -> dict[str, Any]:
    """
    Generate summary statistics from results DataFrame.

    Args:
        df: Results DataFrame.
        node_type: Type of energy node ('producer' or 'prosumer').

    Returns:
        Dictionary with summary statistics.

    Example:
        >>> summary = summarize_results(df, 'prosumer')
        >>> print(summary['total_cost'])
    """
    summary = {
        'num_timesteps': len(df),
        'num_episodes': df['episode'].nunique() if 'episode' in df.columns else 1,
        'total_import_energy_kwh': df['import_energy_kwh'].sum(),
        'total_export_energy_kwh': df['export_energy_kwh'].sum(),
        'total_import_cost_eur': df['import_cost_eur'].sum(),
        'total_export_revenue_eur': df['export_revenue_eur'].sum(),
        'mean_soc_pct': df['soc_final_pct'].mean(),
        'total_violations_kw': df['violation_kw'].sum(),
        'mean_selfcons_ratio': df['selfcons_ratio'].mean(),
        'mean_selfsuff_ratio': df['selfsuff_ratio'].mean(),
    }

    # add node-specific economic summary
    if node_type == 'producer':
        summary['total_profit_eur'] = df['net_profit_eur'].sum()
    else:  # prosumer
        summary['total_cost_eur'] = df['net_cost_eur'].sum()

    return summary
