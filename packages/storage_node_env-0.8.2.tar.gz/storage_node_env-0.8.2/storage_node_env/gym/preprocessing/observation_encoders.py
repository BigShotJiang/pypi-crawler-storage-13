"""
Main observation encoder class for preprocessing.

This module provides the ObservationEncoder class that orchestrates
the complete preprocessing pipeline for raw observations.
"""

from datetime import datetime
from typing import Any

import holidays
import numpy as np
import pandas as pd

from storage_node_env.gym.preprocessing.encoders import encode_binary, encode_cyclical
from storage_node_env.gym.preprocessing.feature_config import (
    FEATURE_REGISTRY,
    EncodingType,
    calculate_total_output_dim,
    get_current_features,
    get_feature_config,
    get_lookback_features,
    get_observation_offsets,
    get_temporal_features,
)
from storage_node_env.gym.preprocessing.normalizers import MinMaxNormalizer


def is_italian_holiday(date: datetime) -> bool:
    """
    Check if a date is an Italian holiday.

    Args:
        date: Date to check.

    Returns:
        True if the date is an Italian holiday, False otherwise.

    Example:
        >>> is_italian_holiday(datetime(2024, 1, 1))  # New Year's Day
        True
        >>> is_italian_holiday(datetime(2024, 1, 2))  # Regular day
        False
    """
    it_holidays = holidays.Italy(years=date.year)
    return date.date() in it_holidays


class ObservationEncoder:
    """
    Main encoder for observation preprocessing.

    This class handles the complete preprocessing pipeline:
    - Cyclical encoding for temporal features
    - Holiday detection
    - Min-max normalization for numerical features
    - Consistent processing of lookback features

    Attributes:
        normalizer: MinMaxNormalizer for numerical features.
        lookback_n: Number of lookback timesteps.
        add_holiday: Whether to include holiday feature.
        feature_order: Ordered list of feature names in raw observation.
        lookback_features: Feature names included in lookback.
    """

    # deprecated: use get_current_features() and get_lookback_features() instead
    # kept for backward compatibility only
    CURRENT_FEATURES = [
        'production', 'consumption', 'buy_price', 'sell_price',
        'energy_balance', 'final_soc', 'upper_bound', 'lower_bound'
    ]

    LOOKBACK_FEATURES = ['production', 'consumption', 'energy_balance', 'final_soc']

    def __init__(
        self,
        normalizer: MinMaxNormalizer,
        lookback_n: int,
        add_holiday: bool = True
    ) -> None:
        """
        Initialize the observation encoder with dynamic feature lists.

        Args:
            normalizer: Fitted MinMaxNormalizer with bounds from dataset.
            lookback_n: Number of lookback timesteps.
            add_holiday: Whether to add holiday feature. Defaults to True.
        """
        self.normalizer = normalizer
        self.lookback_n = lookback_n
        self.add_holiday = add_holiday

        # use dynamic feature lists from registry
        self.temporal_features = get_temporal_features()
        self.current_features = get_current_features()
        self.lookback_features = get_lookback_features()

        # calculate offsets dynamically
        self.offsets = get_observation_offsets(lookback_n)

    def encode(self, raw_observation: np.ndarray, timestamp: datetime) -> np.ndarray:
        """
        Encode a raw observation into preprocessed form.

        Args:
            raw_observation: Raw observation array from build_observation().
            timestamp: Current timestamp for holiday detection.

        Returns:
            Encoded observation as numpy array (float32).

        Raises:
            ValueError: If raw_observation has incorrect dimensions.

        Example:
            >>> encoder = ObservationEncoder(normalizer, lookback_n=2)
            >>> raw_obs = np.array([2024, 1, 15, 14, 2, ...])  # 21 dims
            >>> encoded = encoder.encode(raw_obs, datetime(2024, 1, 15, 14, 30))
            >>> print(encoded.shape)
            (27,)  # 10 temporal + 1 holiday + 8 current + 8 lookback (4*2)
        """
        # calculate expected dimension dynamically
        expected_dim = (len(self.temporal_features) +
                        len(self.current_features) +
                        (len(self.lookback_features) * self.lookback_n))
        if len(raw_observation) != expected_dim:
            raise ValueError(
                f'Expected raw observation of dimension {expected_dim}, '
                f'got {len(raw_observation)}'
            )

        encoded_parts = []

        # extract temporal features using dynamic offsets
        temporal_offset = self.offsets['temporal']
        year = raw_observation[temporal_offset['start']]
        month = raw_observation[temporal_offset['start'] + 1]
        day = raw_observation[temporal_offset['start'] + 2]
        hour = raw_observation[temporal_offset['start'] + 3]
        quarter = raw_observation[temporal_offset['start'] + 4]

        # encode temporal features with cyclical encoding
        year_sin, year_cos = encode_cyclical(year - 2024, 10.0)  # normalize year to 0-10
        month_sin, month_cos = encode_cyclical(month, 12.0)
        day_sin, day_cos = encode_cyclical(day, 31.0)
        hour_sin, hour_cos = encode_cyclical(hour, 24.0)
        quarter_sin, quarter_cos = encode_cyclical(quarter, 4.0)

        encoded_parts.extend([
            year_sin, year_cos,
            month_sin, month_cos,
            day_sin, day_cos,
            hour_sin, hour_cos,
            quarter_sin, quarter_cos
        ])

        # encode holiday feature if enabled
        if self.add_holiday:
            holiday = is_italian_holiday(timestamp)
            encoded_parts.append(encode_binary(holiday))

        # encode current state features using dynamic offsets
        current_offset = self.offsets['current']
        for i, feature_name in enumerate(self.current_features):
            raw_value = raw_observation[current_offset['start'] + i]
            encoded_value = self._encode_feature(raw_value, feature_name)
            encoded_parts.append(encoded_value)

        # encode lookback features using dynamic offsets
        lookback_offset = self.offsets['lookback']
        features_per_timestep = lookback_offset['per_timestep']
        for t in range(self.lookback_n):
            offset = t * features_per_timestep
            for i, feature_name in enumerate(self.lookback_features):
                raw_value = raw_observation[lookback_offset['start'] + offset + i]
                encoded_value = self._encode_feature(raw_value, feature_name)
                encoded_parts.append(encoded_value)

        return np.array(encoded_parts, dtype=np.float32)

    def _encode_feature(self, value: float, feature_name: str) -> float:
        """
        Encode a single feature value.

        Args:
            value: Raw feature value.
            feature_name: Name of the feature.

        Returns:
            Encoded value.
        """
        config = get_feature_config(feature_name)

        if config.encoding_type == EncodingType.MINMAX:
            # handle special case: lower_bound is in [-100, 0], shift to [0, 1]
            if feature_name == 'lower_bound':
                # shift from [-100, 0] to [0, 100] then normalize to [0, 1]
                shifted_value = value + 100.0
                return shifted_value / 100.0

            # handle other percentage features (already in [0, 100])
            if feature_name in ('final_soc', 'upper_bound'):
                return value / 100.0

            # for other features, use normalizer if bounds are available
            # check if feature exists in normalizer (may not exist for Producer's consumption)
            if feature_name not in self.normalizer.bounds:
                # feature not in normalizer (e.g., consumption for Producer)
                # return 0.0 as normalized value since raw value is always 0
                return 0.0

            if self.normalizer.is_skipped(feature_name):
                # constant feature, return as-is (will be 0 for min=max=0)
                return 0.0

            return self.normalizer.transform(value, feature_name, clip=True)

        # fallback: return raw value
        return value

    def get_encoded_dimension(self) -> int:
        """
        Calculate the total dimension of encoded observations dynamically.

        Returns:
            Total number of features in encoded observation.

        Example:
            >>> encoder = ObservationEncoder(normalizer, lookback_n=2, add_holiday=True)
            >>> encoder.get_encoded_dimension()
            27  # Dynamic: 10 temporal (5×2) + 1 holiday + 8 current + 8 lookback (4×2)
        """
        # calculate dimensions dynamically from feature registry
        temporal_dim = calculate_total_output_dim(self.temporal_features)
        holiday_dim = 1 if self.add_holiday else 0
        current_dim = calculate_total_output_dim(self.current_features)
        lookback_dim = calculate_total_output_dim(self.lookback_features) * self.lookback_n

        return temporal_dim + holiday_dim + current_dim + lookback_dim

    def get_observation_space_bounds(self) -> tuple[np.ndarray, np.ndarray]:
        """
        Get low and high bounds for the observation space dynamically.

        Returns:
            Tuple of (low_bounds, high_bounds) arrays for Box space.

        Example:
            >>> encoder = ObservationEncoder(normalizer, lookback_n=2)
            >>> low, high = encoder.get_observation_space_bounds()
            >>> print(low.shape, high.shape)
            (27,) (27,)
        """
        low = []
        high = []

        # temporal features: sin/cos in [-1, 1] - calculated dynamically
        temporal_dim = calculate_total_output_dim(self.temporal_features)
        for _ in range(temporal_dim):
            low.append(-1.0)
            high.append(1.0)

        # holiday feature: binary [0, 1]
        if self.add_holiday:
            low.append(0.0)
            high.append(1.0)

        # current + lookback features: all normalized to [0, 1] - calculated dynamically
        current_dim = calculate_total_output_dim(self.current_features)
        lookback_dim = calculate_total_output_dim(self.lookback_features) * self.lookback_n
        num_normalized = current_dim + lookback_dim

        for _ in range(num_normalized):
            low.append(0.0)
            high.append(1.0)

        return np.array(low, dtype=np.float32), np.array(high, dtype=np.float32)

    def __repr__(self) -> str:
        """Return string representation of encoder."""
        return (
            f'ObservationEncoder(lookback_n={self.lookback_n}, '
            f'add_holiday={self.add_holiday}, '
            f'encoded_dim={self.get_encoded_dimension()})'
        )


def create_encoder_from_data(
    data: pd.DataFrame,
    lookback_n: int,
    add_holiday: bool = True
) -> ObservationEncoder:
    """
    Create and fit an ObservationEncoder from dataset.

    This is a convenience function that creates a normalizer, fits it
    to the data, and returns a ready-to-use encoder.

    Args:
        data: DataFrame containing the dataset columns.
        lookback_n: Number of lookback timesteps.
        add_holiday: Whether to add holiday feature. Defaults to True.

    Returns:
        Fitted ObservationEncoder ready to use.

    Example:
        >>> data = pd.read_csv('dataset.csv')
        >>> encoder = create_encoder_from_data(data, lookback_n=2)
        >>> encoded_obs = encoder.encode(raw_obs, timestamp)
    """
    # create and fit normalizer
    normalizer = MinMaxNormalizer()

    # features to normalize from dataset
    features_to_fit = ['production', 'buy_price', 'sell_price']

    # add consumption if present (Prosumer only)
    if 'consumption' in data.columns:
        features_to_fit.append('consumption')

    # compute energy_balance min/max
    if 'consumption' in data.columns:
        energy_balance = data['production'] - data['consumption']
    else:
        energy_balance = data['production']  # Producer: balance = production

    # create temporary dataframe with energy_balance for fitting
    fit_data = data.copy()
    fit_data['energy_balance'] = energy_balance
    features_to_fit.append('energy_balance')

    normalizer.fit(fit_data, features_to_fit)

    # create encoder
    encoder = ObservationEncoder(
        normalizer=normalizer,
        lookback_n=lookback_n,
        add_holiday=add_holiday
    )

    return encoder
