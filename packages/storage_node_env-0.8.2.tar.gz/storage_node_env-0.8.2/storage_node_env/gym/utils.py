"""
Utility functions for Gymnasium energy storage environments.

This module provides helper functions for observation building,
timestamp processing, and data management.
"""

from typing import Any

import numpy as np
import pandas as pd

from storage_node_env.gym.preprocessing.feature_config import (
    get_current_features,
    get_lookback_features,
    get_temporal_features,
)


def split_timestamp(timestamp: pd.Timestamp) -> tuple[int, int, int, int, int]:
    """
    Split a pandas Timestamp into individual time components.

    Args:
        timestamp: Pandas Timestamp to split.

    Returns:
        Tuple containing:
            - year: Year (e.g., 2024)
            - month: Month (1-12)
            - day: Day of month (1-31)
            - hour: Hour (0-23)
            - quarter: Quarter hour (0-3, representing 0, 15, 30, 45 minutes)

    Example:
        >>> ts = pd.Timestamp('2024-01-15 14:45:00')
        >>> split_timestamp(ts)
        (2024, 1, 15, 14, 3)
    """
    year = timestamp.year
    month = timestamp.month
    day = timestamp.day
    hour = timestamp.hour
    quarter = timestamp.minute // 15  # 0-3 for quarters (0, 15, 30, 45 minutes)

    return year, month, day, hour, quarter


def build_observation(
    node_results: dict[str, Any],
    lookback_buffer: list[dict[str, Any]],
    lookback_n: int,
    node_type: str
) -> np.ndarray:
    """
    Build observation array from current node results and lookback history.

    The observation structure is dynamically determined by OBSERVATION_SCHEMA
    in the feature registry:
        - Temporal features: from get_temporal_features()
        - Current state features: from get_current_features()
        - Lookback features: from get_lookback_features() × lookback_n timesteps

    Example structure for lookback_n=2:
        [temporal features (5),                                # year, month, day, hour, quarter
         current features (8),                                  # production, consumption, etc.
         lookback features t-1 (4),                            # production, consumption, energy_balance, final_soc
         lookback features t-2 (4)]                            # production, consumption, energy_balance, final_soc

    Args:
        node_results: Dictionary from node.step() containing current state.
        lookback_buffer: List of past node results (oldest first).
        lookback_n: Number of lookback timesteps to include.
        node_type: Type of node ('producer' or 'prosumer').

    Returns:
        Numpy array with observation values.

    Note:
        - Missing features in node_results are filled with 0.0 (e.g., Producer's consumption)
        - If lookback_buffer has insufficient history, missing timesteps are zero-padded
        - To add new features, update OBSERVATION_SCHEMA in feature_config.py
    """
    obs_list = []

    # current timestep (t) - temporal features (dynamically from registry)
    for feature_name in get_temporal_features():
        value = node_results.get(feature_name, 0.0)
        obs_list.append(value)

    # current timestep (t) - current state features (dynamically from registry)
    for feature_name in get_current_features():
        value = node_results.get(feature_name, 0.0)
        obs_list.append(value)

    # lookback timesteps (t-1, t-2, ..., t-n)
    # pad with zeros if buffer doesn't have enough history yet
    actual_lookback = min(len(lookback_buffer), lookback_n)
    lookback_feature_names = get_lookback_features()

    for i in range(lookback_n):
        if i < actual_lookback:
            # get data from buffer (most recent first)
            past_result = lookback_buffer[-(i + 1)]
            for feature_name in lookback_feature_names:
                value = past_result.get(feature_name, 0.0)
                obs_list.append(value)
        else:
            # pad with zeros if not enough history
            obs_list.extend([0.0] * len(lookback_feature_names))

    return np.array(obs_list, dtype=np.float32)


def update_lookback_buffer(
    buffer: list[dict[str, Any]],
    new_result: dict[str, Any],
    max_size: int
) -> list[dict[str, Any]]:
    """
    Update lookback buffer with new result, maintaining max size.

    Args:
        buffer: Current lookback buffer (oldest first).
        new_result: New node result to append.
        max_size: Maximum buffer size.

    Returns:
        Updated buffer with new result appended and oldest removed if needed.

    Example:
        >>> buffer = [result1, result2]
        >>> buffer = update_lookback_buffer(buffer, result3, max_size=2)
        >>> len(buffer)
        2
    """
    buffer.append(new_result)
    if len(buffer) > max_size:
        buffer.pop(0)  # remove oldest
    return buffer


def calculate_observation_dim(lookback_n: int) -> int:
    """
    Calculate the dimension of the raw observation space.

    This function now delegates to the feature registry for dynamic calculation.

    Args:
        lookback_n: Number of lookback timesteps.

    Returns:
        Total dimension of raw observation array.

    Note:
        Observation structure is defined in OBSERVATION_SCHEMA:
        - Temporal: from get_temporal_features() (year, month, day, hour, quarter)
        - Current state: from get_current_features() (production, consumption, etc.)
        - Lookback: from get_lookback_features() * lookback_n timesteps
    """
    from storage_node_env.gym.preprocessing.feature_config import calculate_raw_observation_dim

    return calculate_raw_observation_dim(lookback_n)


def calculate_encoded_observation_dim(lookback_n: int, add_holiday: bool = True) -> int:
    """
    Calculate the dimension of the encoded observation space with preprocessing.

    This function now delegates to the feature registry for dynamic calculation.

    Args:
        lookback_n: Number of lookback timesteps.
        add_holiday: Whether holiday feature is included. Defaults to True.

    Returns:
        Total dimension of encoded observation array.

    Note:
        Encoded observation structure is calculated dynamically from OBSERVATION_SCHEMA
        and FEATURE_REGISTRY:
        - Temporal features: cyclical encoding (sin/cos) based on feature definitions
        - Holiday feature: binary (0/1) if add_holiday=True
        - Current state: normalized based on encoding type in registry
        - Lookback: same encoding as current features * lookback_n timesteps

    Example:
        >>> calculate_encoded_observation_dim(lookback_n=2, add_holiday=True)
        27  # Dynamic: 10 temporal (5*2) + 1 holiday + 8 current + 8 lookback (4*2)
        >>> calculate_encoded_observation_dim(lookback_n=2, add_holiday=False)
        26  # Dynamic: 10 temporal (5*2) + 8 current + 8 lookback (4*2)
    """
    from storage_node_env.gym.preprocessing.feature_config import (
        calculate_encoded_observation_dim_from_registry,
    )

    return calculate_encoded_observation_dim_from_registry(lookback_n, add_holiday)


def is_episode_truncated(time_step: int, data_length: int) -> bool:
    """
    Check if episode should be truncated due to exhausted data.

    Args:
        time_step: Current timestep index.
        data_length: Total number of timesteps in the dataset.

    Returns:
        True if episode should be truncated (no more data available), False otherwise.

    Example:
        >>> is_episode_truncated(time_step=168, data_length=168)
        True
        >>> is_episode_truncated(time_step=167, data_length=168)
        False
    """
    return time_step >= data_length


def build_terminal_observation(
    data: pd.DataFrame,
    battery_soc_percent: float,
    lookback_buffer: list[dict[str, Any]],
    lookback_n: int,
    node_type: str
) -> tuple[np.ndarray, dict[str, Any]]:
    """
    Build terminal observation when episode is truncated.

    This function creates a terminal observation using the last valid data point
    and current battery state when the environment runs out of data. The observation
    structure is dynamically determined by OBSERVATION_SCHEMA in the feature registry.

    Args:
        data: DataFrame containing historical data with datetime index.
        battery_soc_percent: Current battery state of charge as percentage.
        lookback_buffer: List of past node results (oldest first).
        lookback_n: Number of lookback timesteps to include.
        node_type: Type of node ('producer' or 'prosumer').

    Returns:
        Tuple containing:
            - observation: Terminal observation array.
            - info: Terminal info dictionary with truncation metadata.

    Note:
        - Terminal observation uses last valid data point from CSV
        - Battery state (final_soc) uses current battery_soc_percent
        - Action-related fields (upper_bound, lower_bound, energy_balance) are set to 0
        - Missing features in data are filled with 0.0
        - To add new features, update OBSERVATION_SCHEMA in feature_config.py

    Example:
        >>> obs, info = build_terminal_observation(
        ...     data=env.data,
        ...     battery_soc_percent=50.0,
        ...     lookback_buffer=buffer,
        ...     lookback_n=2,
        ...     node_type='prosumer'
        ... )
        >>> info['truncated']
        True
    """
    # get last valid data point
    last_valid_idx = len(data) - 1
    last_timestamp = data.index[last_valid_idx]
    last_data_row = data.iloc[last_valid_idx]

    # split timestamp into temporal components (dynamically from registry)
    year, month, day, hour, quarter = split_timestamp(last_timestamp)
    temporal_values = [year, month, day, hour, quarter]

    # create terminal node_results dict dynamically from registry
    terminal_results: dict[str, Any] = {}

    # add temporal features
    for feature_name, value in zip(get_temporal_features(), temporal_values):
        terminal_results[feature_name] = value

    # add current state features from last data row or defaults
    for feature_name in get_current_features():
        if feature_name == 'final_soc':
            # use current battery state
            terminal_results[feature_name] = battery_soc_percent
        elif feature_name == 'upper_bound':
            # terminal observation has no action, so bounds are zero
            terminal_results[feature_name] = 0.0
        elif feature_name == 'lower_bound':
            # terminal observation has no action, so bounds are zero
            terminal_results[feature_name] = 0.0
        elif feature_name == 'energy_balance':
            # no action taken, so balance is neutral
            terminal_results[feature_name] = 0.0
        else:
            # extract from data or use 0.0 as default
            terminal_results[feature_name] = last_data_row.get(feature_name, 0.0)

    # add non-registry fields used by the environment
    terminal_results['initial_soc'] = battery_soc_percent
    terminal_results['action_power'] = 0.0

    # build observation from terminal results
    observation = build_observation(
        node_results=terminal_results,
        lookback_buffer=lookback_buffer,
        lookback_n=lookback_n,
        node_type=node_type,
    )

    # create terminal info dict with all required fields
    info: dict[str, Any] = {
        'timestep': len(data),  # timestep that exceeded data length
        'node_type': node_type,
        'P_grid': 0.0,
        'P_import': 0.0,
        'P_export': 0.0,
        'E_import': 0.0,
        'E_export': 0.0,
        'cost_import': 0.0,
        'revenue_export': 0.0,
        'violation': 0.0,
        'truncated': True,
        'message': 'Episode truncated: no more data available',
    }

    # add node-specific economic metric
    if node_type == 'producer':
        info['net_profit'] = 0.0
    else:  # prosumer
        info['net_cost'] = 0.0

    return observation, info
