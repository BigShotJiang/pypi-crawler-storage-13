"""
Abstract Energy Node Model.

This module provides the abstract base class for energy node models in the
storage-node-environment. Energy nodes represent physical systems that can
produce and/or consume energy, equipped with battery energy storage systems.

"""

from abc import ABC, abstractmethod
from typing import Any, Dict

import numpy as np
import pandas as pd

from storage_node_env.core.storage.base import StorageSystem


class EnergyNode(ABC):
    """
    Abstract base class for energy nodes.

    An energy node represents a physical system with energy production and/or
    consumption capabilities, integrated with a battery energy storage system.
    This class provides common functionality for data management, timestep
    handling, and battery interface, while delegating node-specific behavior
    to concrete implementations.

    Attributes:
        csv_path (str): Path to the CSV file containing historical data.
        delta_t (float): Timestep duration in hours.
        num_actions (int): Number of discrete actions available to the agent.
        data (pd.DataFrame): Historical data loaded from CSV.
        time_step (int): Current timestep index.
        battery (StorageSystem): Reference to the battery storage system.
        observation_space (Dict): Dictionary with min/max bounds for observations.
        P_nom (float): Nominal power reference for action conversion (kW).
    """

    def __init__(
        self,
        csv_path: str,
        delta_t: float,
        num_actions: int = 21,
    ):
        """
        Initialize the energy node.

        Args:
            csv_path (str): Path to the CSV file with historical data.
            delta_t (float): Timestep duration in hours (e.g., 0.25 for 15 minutes).
            num_actions (int, optional): Number of discrete actions. Defaults to 21.
                Actions map to power range [-100%, +100%] of nominal power.

        Raises:
            AssertionError: If parameters are invalid or data validation fails.
        """
        assert delta_t > 0, "delta_t must be positive"
        assert num_actions > 0, "num_actions must be positive"
        assert num_actions % 2 == 1, "num_actions must be odd for symmetric action space"

        self.csv_path = csv_path
        self.delta_t = delta_t
        self.num_actions = num_actions
        self.time_step = 0
        self.battery: StorageSystem | None = None
        self.observation_space: Dict[str, Dict[str, float]] | None = None
        self.P_nom: float | None = None

        # load and validate data
        self._load_data()
        self._validate_data()

    def _load_data(self) -> None:
        """
        Load and filter data from the CSV file into the DataFrame.

        This method reads the CSV file and validates the timestep frequency
        against the specified delta_t parameter.

        Returns:
            None

        Raises:
            AssertionError: If datetime column is missing or timestep validation fails.
        """
        self.data = pd.read_csv(self.csv_path)

        # validate datetime column exists
        assert "datetime" in self.data.columns, (
            f'CSV file must contain a "datetime" column. '
            f"Available columns: {self.data.columns.tolist()}"
        )

        # convert datetime column to datetime type and set as index
        self.data["datetime"] = pd.to_datetime(self.data["datetime"])
        self.data = self.data.set_index("datetime")

        # validate timestep frequency
        if len(self.data) > 1:
            # calculate time differences between consecutive rows
            time_diffs = self.data.index.to_series().diff().dropna()

            # convert to hours
            time_diffs_hours = time_diffs.dt.total_seconds() / 3600

            # check if all timesteps match delta_t (with small tolerance for rounding)
            TOLERANCE = 1e-6
            timestep_match = np.allclose(
                time_diffs_hours, self.delta_t, rtol=TOLERANCE, atol=TOLERANCE
            )

            if not timestep_match:
                actual_delta_t = time_diffs_hours.iloc[0]
                raise AssertionError(
                    f"CSV timestep frequency ({actual_delta_t:.6f} hours) does not match "
                    f"specified delta_t ({self.delta_t:.6f} hours). "
                    f"All timesteps must be consistent."
                )

    @abstractmethod
    def _validate_data(self) -> None:
        """
        Validate that required columns exist in the CSV data.

        This method must be implemented by concrete node types to check
        for their specific required columns (e.g., 'production', 'consumption').

        Returns:
            None

        Raises:
            AssertionError: If required columns are missing.
        """

    def set_observation_space(self, observation_space: Dict[str, Dict[str, float]]) -> None:
        """
        Set the observation space for the node.

        Args:
            observation_space (Dict[str, Dict[str, float]]): Dictionary mapping
                observation keys to {'min': float, 'max': float} dictionaries.
                Example: {'soc': {'min': 0.0, 'max': 100.0}}

        Returns:
            None
        """
        raise NotImplementedError("set_observation_space must be implemented.")

    def get_data(self, column: str | None = None) -> pd.DataFrame | pd.Series:
        """
        Return the node's data.

        Args:
            column (str, optional): Name of the column to return. If None,
                returns the entire DataFrame.

        Returns:
            pd.DataFrame | pd.Series: Node data or specified column.

        Raises:
            KeyError: If the specified column does not exist.
        """
        if column is None:
            return self.data
        return self.data[column]

    def get_data_columns(self) -> list[str]:
        """
        Return the list of available columns in the DataFrame.

        Returns:
            list[str]: Names of the columns.
        """
        return self.data.columns.tolist()

    def get_current_data(
        self, column: str | None = None, time_step: int | None = None
    ) -> np.ndarray | float:
        """
        Return the current data for the current or specified time step.

        Args:
            column (str, optional): Name of the column to return. If None,
                returns the entire row as array.
            time_step (int, optional): Time index to retrieve data from.
                If None, uses the current time step.

        Returns:
            np.ndarray | float: Current data row or specified column value.

        Raises:
            IndexError: If time_step is out of bounds.
            KeyError: If column does not exist.
        """
        ts = self.time_step if time_step is None else time_step

        if column is None:
            return self.data.iloc[ts].values # type: ignore
        return self.data[column].iloc[ts]

    def set_storage(self, battery: StorageSystem) -> None:
        """
        Set the storage system (battery) for the node.

        This method links the battery to the node and sets the nominal power
        reference for action-to-power conversion.

        Args:
            battery (StorageSystem): Instance of a StorageSystem (e.g., Battery).

        Returns:
            None
        """
        self.battery = battery
        # use charging power as nominal reference for action conversion
        self.P_nom = battery.P_cha_max # type: ignore

    def reset(self) -> None:
        """
        Reset the node to its initial state.

        This method resets the timestep counter to 0 and resets the battery
        to its initial state of charge.

        Returns:
            None

        Raises:
            AssertionError: If battery has not been set.
        """
        assert self.battery is not None, "Battery must be set before reset. Use set_storage()."

        self.time_step = 0
        self.battery.reset()

    def advance_time(self) -> None:
        """
        Advance the timestep counter by one.

        Returns:
            None
        """
        self.time_step += 1

    def _action_to_power(self, action: int) -> float:
        """
        Convert discrete action to requested power in kW.

        The action space is symmetric around the middle action, mapping to
        power range [-100%, +100%] of nominal power.

        Args:
            action (int): Discrete action index [0, num_actions-1].

        Returns:
            float: Requested power in kW (positive = charge, negative = discharge).

        Raises:
            AssertionError: If action is out of valid range or battery not set.

        Example:
            With num_actions=21 and P_nom=2.5 kW:
            - action=0  → -100% → -2.5 kW (max discharge)
            - action=10 →    0% →  0.0 kW (inactive)
            - action=20 → +100% → +2.5 kW (max charge)
        """
        assert self.battery is not None, "Battery must be set before action conversion."
        assert (
            0 <= action < self.num_actions
        ), f"Action {action} out of range [0, {self.num_actions-1}]"

        # calculate middle action (zero power reference)
        middle_action = (self.num_actions - 1) / 2

        # convert action to power fraction in [-100, 100] %
        power_fraction = (action - middle_action) * (100 / middle_action)

        # convert to power in kW
        P_req = (power_fraction / 100) * self.P_nom  # type: ignore

        return P_req

    @abstractmethod
    def step(self, action: int) -> Dict[str, Any]:
        """
        Execute one timestep of the node simulation.

        This method must be implemented by concrete node types to define
        their specific energy flow logic and economic calculations.

        Args:
            action (int): Discrete action chosen by the agent [0, num_actions-1].

        Returns:
            Dict[str, Any]: Dictionary with step results.

        Raises:
            AssertionError: If battery has not been set or timestep is out of bounds.
        """
