"""
Core physics models for energy storage systems and energy nodes.

This package provides physics-based implementations of:
    - Storage systems (Battery)
    - Energy nodes (Producer, Prosumer)

These models can be used standalone or integrated with the RL environment.

Example:
    >>> from storage_node_env.core import Battery, Producer, Prosumer
    >>> battery = Battery(capacity=5.12, dod_max=90, ...)
    >>> producer = Producer(csv_path='data.csv', delta_t=1.0)
    >>> producer.set_storage(battery)
"""

from storage_node_env.core.nodes.producer import Producer
from storage_node_env.core.nodes.prosumer import Prosumer
from storage_node_env.core.storage.battery import Battery


__all__ = [
    'Battery',
    'Producer',
    'Prosumer',
]
