"""
Storage Node Environment - Energy Storage System Simulation and RL Environment.

A Python library providing Gymnasium environments for simulating energy nodes
with battery energy storage systems (BESS). The library focuses on physics-based
battery simulation using commercial datasheet parameters.

Main packages:
    - core: Physics-based models for storage systems and energy nodes
    - gym: Gymnasium-compliant reinforcement learning environments

For detailed usage, import from subpackages:
    - from storage_node_env.core import Battery, Producer, Prosumer
    - from storage_node_env.gym import EnergyStorageEnv

License: MIT
Repository: https://github.com/unisi-lab305/storage-node-environment
"""

__version__ = '0.8.2'

from storage_node_env import gym as _gym  # noqa: F401


__all__ = []
