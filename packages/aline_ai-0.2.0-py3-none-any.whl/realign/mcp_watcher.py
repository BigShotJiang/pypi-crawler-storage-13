"""Session file watcher for MCP auto-commit per user request completion.

Supports both Claude Code and Codex session formats with unified interface.
"""

import asyncio
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional, Dict, Literal
from datetime import datetime

from .config import ReAlignConfig
from .hooks import find_all_active_sessions


# Session type detection
SessionType = Literal["claude", "codex", "unknown"]


class DialogueWatcher:
    """Watch session files and auto-commit immediately after each user request completes."""

    def __init__(self):
        """Initialize watcher without fixed repo_path - will extract dynamically from sessions."""
        self.config = ReAlignConfig.load()
        self.project_path = self._detect_project_path()
        self.last_commit_times: Dict[str, float] = {}  # Track last commit time per project
        self.last_session_sizes: Dict[str, int] = {}  # Track file sizes
        self.last_stop_reason_counts: Dict[str, int] = {}  # Track stop_reason counts per session
        self.min_commit_interval = 5.0  # Minimum 5 seconds between commits (cooldown)
        self.debounce_delay = 2.0  # Wait 2 seconds after file change to ensure turn is complete
        self.running = False
        self.pending_commit_task: Optional[asyncio.Task] = None

    async def start(self):
        """Start watching session files."""
        if not self.config.mcp_auto_commit:
            print("[MCP Watcher] Auto-commit disabled in config", file=sys.stderr)
            return

        self.running = True
        print("[MCP Watcher] Started watching for dialogue completion", file=sys.stderr)
        print(f"[MCP Watcher] Mode: Per-request (triggers at end of each AI response)", file=sys.stderr)
        print(f"[MCP Watcher] Supports: Claude Code & Codex (auto-detected)", file=sys.stderr)
        print(f"[MCP Watcher] Debounce: {self.debounce_delay}s, Cooldown: {self.min_commit_interval}s", file=sys.stderr)
        if self.project_path:
            print(f"[MCP Watcher] Monitoring project: {self.project_path}", file=sys.stderr)
        else:
            print("[MCP Watcher] Project path unknown, falling back to multi-project scan", file=sys.stderr)

        # Initialize baseline sizes and stop_reason counts
        self.last_session_sizes = self._get_session_sizes()
        self.last_stop_reason_counts = self._get_stop_reason_counts()

        # Poll for file changes more frequently
        while self.running:
            try:
                await self.check_for_changes()
                await asyncio.sleep(0.5)  # Check every 0.5 seconds for responsiveness
            except Exception as e:
                print(f"[MCP Watcher] Error: {e}", file=sys.stderr)
                await asyncio.sleep(1.0)

    async def stop(self):
        """Stop watching."""
        self.running = False
        if self.pending_commit_task:
            self.pending_commit_task.cancel()
        print("[MCP Watcher] Stopped", file=sys.stderr)

    def _get_session_sizes(self) -> Dict[str, int]:
        """Get current sizes of all active session files."""
        sizes = {}
        try:
            session_files = find_all_active_sessions(
                self.config,
                project_path=self.project_path if self.project_path and self.project_path.exists() else None,
            )
            for session_file in session_files:
                if session_file.exists():
                    sizes[str(session_file)] = session_file.stat().st_size
        except Exception as e:
            print(f"[MCP Watcher] Error getting session sizes: {e}", file=sys.stderr)
        return sizes

    def _get_stop_reason_counts(self) -> Dict[str, int]:
        """Get current count of turn completion markers in all active session files."""
        counts = {}
        try:
            session_files = find_all_active_sessions(
                self.config,
                project_path=self.project_path if self.project_path and self.project_path.exists() else None,
            )
            for session_file in session_files:
                if session_file.exists():
                    counts[str(session_file)] = self._count_complete_turns(session_file)
        except Exception as e:
            print(f"[MCP Watcher] Error getting turn counts: {e}", file=sys.stderr)
        return counts

    def _extract_project_path(self, session_file: Path) -> Optional[Path]:
        """
        Extract project path (cwd) from session file.

        Supports:
        1. Codex: Read cwd from session_meta payload
        2. Claude Code: Read cwd from message objects OR infer from project directory name

        Args:
            session_file: Path to session file

        Returns:
            Path to project directory, or None if cannot determine
        """
        try:
            # Method 1: Try to read cwd from session content
            with open(session_file, 'r', encoding='utf-8') as f:
                # Check first 10 lines for cwd field
                for i, line in enumerate(f):
                    if i >= 10:
                        break

                    line = line.strip()
                    if not line:
                        continue

                    try:
                        data = json.loads(line)

                        # Codex format: session_meta.payload.cwd
                        if data.get('type') == 'session_meta':
                            cwd = data.get('payload', {}).get('cwd')
                            if cwd:
                                project_path = Path(cwd)
                                if project_path.exists():
                                    return project_path

                        # Claude Code format: message object has cwd field
                        if 'cwd' in data:
                            cwd = data['cwd']
                            if cwd:
                                project_path = Path(cwd)
                                if project_path.exists():
                                    return project_path

                    except json.JSONDecodeError:
                        continue

            # Method 2: For Claude Code, infer from project directory name
            # ~/.claude/projects/-Users-huminhao-Projects-ReAlign/xxx.jsonl
            if '.claude/projects/' in str(session_file):
                project_dir_name = session_file.parent.name
                if project_dir_name.startswith('-'):
                    # Decode: -Users-huminhao-Projects-ReAlign -> /Users/huminhao/Projects/ReAlign
                    project_path_str = '/' + project_dir_name[1:].replace('-', '/')
                    project_path = Path(project_path_str)
                    if project_path.exists() and (project_path / '.git').exists():
                        return project_path

            print(f"[MCP Watcher] Could not extract project path from {session_file.name}", file=sys.stderr)
            return None

        except Exception as e:
            print(f"[MCP Watcher] Error extracting project path from {session_file}: {e}", file=sys.stderr)
            return None

    def _detect_session_type(self, session_file: Path) -> SessionType:
        """
        Detect the type of session file by examining its structure.

        Returns:
            "claude" for Claude Code sessions
            "codex" for Codex/GPT sessions
            "unknown" if cannot determine
        """
        try:
            with open(session_file, 'r', encoding='utf-8') as f:
                # Check first 20 lines for format indicators
                for i, line in enumerate(f):
                    if i >= 20:
                        break

                    line = line.strip()
                    if not line:
                        continue

                    try:
                        data = json.loads(line)

                        # Claude Code format: {type: "assistant", message: {...}}
                        if data.get("type") in ("assistant", "user") and "message" in data:
                            return "claude"

                        # Codex format: {type: "session_meta", payload: {originator: "codex_*"}}
                        if data.get("type") == "session_meta":
                            payload = data.get("payload", {})
                            if "codex" in payload.get("originator", "").lower():
                                return "codex"

                        # Codex format: {type: "response_item", payload: {...}}
                        if data.get("type") == "response_item":
                            payload = data.get("payload", {})
                            # Claude has "message" wrapper, Codex doesn't
                            if "message" not in data and "role" in payload:
                                return "codex"

                    except json.JSONDecodeError:
                        continue

            return "unknown"

        except Exception as e:
            print(f"[MCP Watcher] Error detecting session type for {session_file.name}: {e}", file=sys.stderr)
            return "unknown"

    def _count_complete_turns(self, session_file: Path) -> int:
        """
        Unified interface to count complete dialogue turns for any session type.

        Automatically detects session format and uses appropriate counting method.

        Returns:
            Number of complete dialogue turns (user request + assistant response)
        """
        session_type = self._detect_session_type(session_file)

        if session_type == "claude":
            return self._count_claude_turns(session_file)
        elif session_type == "codex":
            return self._count_codex_turns(session_file)
        else:
            print(f"[MCP Watcher] Unknown session type for {session_file.name}, skipping", file=sys.stderr)
            return 0

    def _count_claude_turns(self, session_file: Path) -> int:
        """
        Count complete dialogue turns for Claude Code sessions.

        Uses stop_reason='end_turn' as the marker, with message ID deduplication
        to handle Claude Code's incremental writes (thinking first, then full content).
        """
        unique_message_ids = set()
        try:
            with open(session_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        message = data.get("message", {})
                        # Only count end_turn stop reasons (ignore tool_use, etc.)
                        if message.get("stop_reason") == "end_turn":
                            # Deduplicate by message ID to handle incremental writes
                            msg_id = message.get("id")
                            if msg_id:
                                unique_message_ids.add(msg_id)
                            else:
                                # If no message ID, count it anyway (shouldn't happen normally)
                                unique_message_ids.add(f"no_id_{len(unique_message_ids)}")
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            print(f"[MCP Watcher] Error counting Claude turns in {session_file}: {e}", file=sys.stderr)
        return len(unique_message_ids)

    def _count_codex_turns(self, session_file: Path) -> int:
        """
        Count complete dialogue turns for Codex sessions.

        Uses 'token_count' event_msg as the marker for dialogue turn completion.
        Each token_count event appears after an assistant response finishes.

        Note: Codex doesn't have the duplicate write issue that Claude Code has,
        so no deduplication is needed.
        """
        count = 0
        try:
            with open(session_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        # Look for token_count events which mark turn completion
                        if data.get("type") == "event_msg":
                            payload = data.get("payload", {})
                            if payload.get("type") == "token_count":
                                count += 1
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            print(f"[MCP Watcher] Error counting Codex turns in {session_file}: {e}", file=sys.stderr)
        return count

    async def check_for_changes(self):
        """Check if any session file has been modified."""
        try:
            current_sizes = self._get_session_sizes()

            # Detect changed files
            changed_files = []
            for path, size in current_sizes.items():
                old_size = self.last_session_sizes.get(path, 0)
                if size > old_size:
                    changed_files.append(Path(path))

            if changed_files:
                # File changed - cancel any pending commit and schedule a new one
                if self.pending_commit_task:
                    self.pending_commit_task.cancel()

                # Wait for debounce period to ensure the turn is complete
                self.pending_commit_task = asyncio.create_task(
                    self._debounced_commit(changed_files)
                )

            # Update tracked sizes
            self.last_session_sizes = current_sizes

        except Exception as e:
            print(f"[MCP Watcher] Error checking for changes: {e}", file=sys.stderr)

    async def _debounced_commit(self, changed_files: list):
        """Wait for debounce period, then check if dialogue is complete and commit."""
        try:
            # Wait for debounce period
            await asyncio.sleep(self.debounce_delay)

            # Check if any of the changed files contains a complete dialogue turn
            # And collect the session file that triggered the commit
            session_to_commit = None
            for session_file in changed_files:
                if await self._check_if_turn_complete(session_file):
                    session_to_commit = session_file
                    print(f"[MCP Watcher] Complete turn detected in {session_file.name}", file=sys.stderr)
                    break

            if session_to_commit:
                # Extract project path from the session file
                project_path = self._extract_project_path(session_to_commit)
                if not project_path:
                    print(f"[MCP Watcher] Could not determine project path for {session_to_commit.name}, skipping commit", file=sys.stderr)
                    return

                # Check cooldown period for this specific project
                current_time = time.time()
                project_key = str(project_path)
                last_commit_time = self.last_commit_times.get(project_key)
                if last_commit_time:
                    time_since_last = current_time - last_commit_time
                    if time_since_last < self.min_commit_interval:
                        print(f"[MCP Watcher] Skipping commit for {project_path.name} (cooldown: {time_since_last:.1f}s < {self.min_commit_interval}s)", file=sys.stderr)
                        return

                # Perform commit for this project
                await self._do_commit(project_path, session_to_commit)

        except asyncio.CancelledError:
            # Task was cancelled because a newer change was detected
            pass
        except Exception as e:
            print(f"[MCP Watcher] Error in debounced commit: {e}", file=sys.stderr)

    async def _check_if_turn_complete(self, session_file: Path) -> bool:
        """
        Check if the session file has at least 1 new complete dialogue turn since last check.

        Supports both Claude Code and Codex formats:
        - Claude Code: Uses stop_reason='end_turn' (deduplicated by message ID)
        - Codex: Uses token_count events (no deduplication needed)

        Each complete dialogue round consists of:
        1. User message/request
        2. Assistant response
        3. Turn completion marker (format-specific)
        """
        try:
            session_path = str(session_file)
            session_type = self._detect_session_type(session_file)

            current_count = self._count_complete_turns(session_file)
            last_count = self.last_stop_reason_counts.get(session_path, 0)

            new_turns = current_count - last_count

            # Commit after each complete assistant response (1 new turn)
            if new_turns >= 1:
                print(f"[MCP Watcher] Detected {new_turns} new turn(s) in {session_file.name} ({session_type})", file=sys.stderr)
                # Update baseline immediately to avoid double-counting
                self.last_stop_reason_counts[session_path] = current_count
                return True

            return False

        except Exception as e:
            print(f"[MCP Watcher] Error checking turn completion: {e}", file=sys.stderr)
            return False

    async def _do_commit(self, project_path: Path, session_file: Path):
        """
        Perform the actual commit for a specific project.

        Args:
            project_path: Path to the project directory
            session_file: Session file that triggered the commit
        """
        try:
            # Generate commit message
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            message = f"chore: Auto-commit MCP session ({timestamp})"

            # Use realign commit command
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                self._run_realign_commit,
                project_path,
                message
            )

            if result:
                print(f"[MCP Watcher] ✓ Committed to {project_path.name}: {message}", file=sys.stderr)
                # Update last commit time for this project
                self.last_commit_times[str(project_path)] = time.time()
                # Baseline counts already updated in _check_if_turn_complete()

        except Exception as e:
            print(f"[MCP Watcher] Error during commit for {project_path}: {e}", file=sys.stderr)

    def _run_realign_commit(self, project_path: Path, message: str) -> bool:
        """
        Run realign commit command with file locking to prevent race conditions.

        Args:
            project_path: Path to the project directory
            message: Commit message

        The command will:
        - Acquire a file lock to prevent concurrent commits from multiple watchers
        - Auto-initialize git and ReAlign if needed
        - Check for session changes (modified within last 5 minutes)
        - Create empty commit if only sessions changed
        - Return True if commit was created, False otherwise
        """
        from .file_lock import commit_lock

        try:
            # Acquire commit lock to prevent concurrent commits from multiple MCP servers
            with commit_lock(project_path, timeout=5.0) as locked:
                if not locked:
                    print(f"[MCP Watcher] Another watcher is committing to {project_path.name}, skipping", file=sys.stderr)
                    return False

                return self._do_commit_locked(project_path, message)

        except TimeoutError:
            print("[MCP Watcher] Could not acquire commit lock (timeout)", file=sys.stderr)
            return False
        except Exception as e:
            print(f"[MCP Watcher] Commit error: {e}", file=sys.stderr)
            return False

    def _do_commit_locked(self, project_path: Path, message: str) -> bool:
        """
        Perform the actual commit operation (must be called with lock held).

        Args:
            project_path: Path to the project directory
            message: Commit message

        Returns:
            True if commit was created, False otherwise
        """
        try:
            # Check if ReAlign is initialized
            realign_dir = project_path / ".realign"

            if not realign_dir.exists():
                print(f"[MCP Watcher] ReAlign not initialized in {project_path.name}, initializing...", file=sys.stderr)

                # Auto-initialize ReAlign (which also inits git if needed)
                init_result = subprocess.run(
                    ["python3", "-m", "realign.cli", "init", "--yes"],
                    cwd=project_path,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )

                if init_result.returncode != 0:
                    print(f"[MCP Watcher] Failed to initialize ReAlign in {project_path.name}: {init_result.stderr}", file=sys.stderr)
                    return False

                print(f"[MCP Watcher] ✓ ReAlign initialized successfully in {project_path.name}", file=sys.stderr)

            # Use direct function call instead of subprocess
            # This allows environment variables (like OPENAI_API_KEY) to be inherited
            from realign.commands.commit import commit_internal

            success, commit_hash, status_msg = commit_internal(
                repo_root=project_path,
                message=message,
                all_files=True,
                amend=False,
                no_edit=False,
            )

            if success:
                print(f"[MCP Watcher] ✓ {status_msg}", file=sys.stderr)
                return True
            elif "No changes detected" in status_msg:
                # No changes - this is expected, not an error
                return False
            else:
                # Log the error for debugging
                print(f"[MCP Watcher] Commit failed for {project_path.name}: {status_msg}", file=sys.stderr)
                return False

        except Exception as e:
            print(f"[MCP Watcher] Commit error for {project_path.name}: {e}", file=sys.stderr)
            return False

    def _detect_project_path(self) -> Optional[Path]:
        """
        Attempt to detect the git repository root for the current process.
        Returns None if not inside a git repo.
        """
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                capture_output=True,
                text=True,
                check=True,
            )
            repo_path = Path(result.stdout.strip())
            if repo_path.exists():
                return repo_path
        except subprocess.CalledProcessError:
            current_dir = Path.cwd()
            if (current_dir / ".git").exists():
                return current_dir
        except Exception as e:
            print(f"[MCP Watcher] Could not detect project path: {e}", file=sys.stderr)
        return None


# Global watcher instance
_watcher: Optional[DialogueWatcher] = None


async def start_watcher():
    """
    Start the global session watcher for auto-commit on user request completion.

    No longer requires a repo_path - the watcher will dynamically extract project paths
    from session files and commit to the appropriate repositories.
    """
    global _watcher

    if _watcher and _watcher.running:
        print("[MCP Watcher] Already running", file=sys.stderr)
        return

    _watcher = DialogueWatcher()
    asyncio.create_task(_watcher.start())


async def stop_watcher():
    """Stop the global session watcher."""
    global _watcher

    if _watcher:
        await _watcher.stop()
        _watcher = None
