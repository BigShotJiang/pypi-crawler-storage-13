"""
The Orchestrator: High-level API and safety barriers.
"""

import asyncio
import os
import time
import functools
import traceback
import struct
from typing import Optional, AsyncIterator, Callable, Any, TypeVar, Awaitable
from veil.secrets import SecretBytes
from veil.types import (
    EncryptedContainer, KeyMaterial, MasterKey, DataKey, 
    Salt, Nonce, AAD
)
from veil.interfaces import (
    IKdfProvider, ICipherProvider, IStreamProcessor, 
    IAuditLogger, AuthenticationError, IKeyRotator
)
from veil.pipeline import CryptoPipeline
from veil.registry import ProviderRegistry
from veil.providers import AesKeyWrapProvider

T = TypeVar("T")

class SafeCoreError(Exception):
    """Generic error for SafeCore failures."""
    pass

def panic_proof(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
    """
    Decorator to catch ALL exceptions, log panic, wipe secrets, and raise SafeCoreError.
    """
    @functools.wraps(func)
    async def wrapper(self: "SafeCore", *args: Any, **kwargs: Any) -> T:
        try:
            return await func(self, *args, **kwargs)
        except SafeCoreError:
            raise
        except Exception as e:
            # 1. Sanitize Traceback (remove locals)
            # We can't easily modify the traceback object, but we can format it
            # and ensure we don't log sensitive variables.
            tb_str = "".join(traceback.format_exception(type(e), e, e.__traceback__))
            
            # 2. Log PANIC
            if self.audit_logger:
                self.audit_logger.log_event(
                    "PANIC_ERROR",
                    {"error": str(e), "traceback": tb_str},
                    {"args": args, "kwargs": kwargs} # Audit logger sanitizes this
                )
            
            # 3. Wipe Secrets
            self.wipe_session()
            
            # 4. Raise SafeCoreError
            raise SafeCoreError(f"System Panic: {e}") from e
    return wrapper

class SafeCore:
    """
    The main entry point for Veil operations.
    """
    
    def __init__(
        self, 
        pipeline: CryptoPipeline,
        kdf: IKdfProvider,
        audit_logger: Optional[IAuditLogger] = None
    ):
        self.pipeline = pipeline
        self.kdf = kdf
        self.audit_logger = audit_logger
        self._key_material: Optional[KeyMaterial] = None

    def wipe_session(self) -> None:
        """Wipe current session key material."""
        if self._key_material:
            # Best effort wipe of components
            if self._key_material.master_key:
                self._key_material.master_key.wipe()
            if self._key_material.data_key:
                self._key_material.data_key.wipe()
            self._key_material = None

    @panic_proof
    async def encrypt_file(
        self, 
        input_path: str, 
        output_path: str, 
        password: SecretBytes,
        metadata: Optional[dict] = None
    ) -> None:
        """
        Encrypt a file.
        """
        loop = asyncio.get_running_loop()
        
        # 1. Generate Salt & Derive Master Key (CPU bound)
        salt = Salt(os.urandom(16))
        master_key = await loop.run_in_executor(
            None, 
            self.kdf.derive_key, 
            password, salt
        )
        
        # 2. Generate DEK & Nonce Base
        dek = DataKey(SecretBytes(os.urandom(32)))
        nonce_base = Nonce(os.urandom(12))
        
        # 3. Wrap DEK
        wrapped_dek = await loop.run_in_executor(
            None,
            AesKeyWrapProvider.wrap_key,
            master_key, dek
        )
        
        # 4. Create Container Header
        container = EncryptedContainer(
            version=1,
            algorithm="chacha20-poly1305", # Should match pipeline cipher
            kdf_params={"salt": salt, "type": "argon2id"},
            wrapped_dek=wrapped_dek,
            nonce_base=nonce_base,
            aad=b"",
            middleware_chain=[], # TODO: Populate from pipeline
            payload=b"", # Empty for file mode
            created_at=int(time.time()),
            metadata=metadata or {}
        )
        
        header_bytes = container.to_bytes()
        
        # 5. Stream Processing
        async def file_reader() -> AsyncIterator[bytes]:
            with open(input_path, "rb") as f:
                while True:
                    chunk = await loop.run_in_executor(None, f.read, 64 * 1024)
                    if not chunk:
                        break
                    yield chunk

        encrypted_stream = self.pipeline.encrypt_stream(
            file_reader(),
            dek,
            nonce_base,
            AAD(b"")
        )
        
        # 6. Write Output
        with open(output_path, "wb") as f:
            # Write Header
            await loop.run_in_executor(None, f.write, header_bytes)
            
            # Write Stream
            async for chunk in encrypted_stream:
                await loop.run_in_executor(None, f.write, chunk)

        if self.audit_logger:
            self.audit_logger.log_event(
                "ENCRYPTION_SUCCESS",
                {"file": input_path},
                {"metadata": metadata}
            )

    @panic_proof
    async def decrypt_file(
        self, 
        input_path: str, 
        output_path: str, 
        password: SecretBytes
    ) -> None:
        """
        Decrypt a file.
        """
        loop = asyncio.get_running_loop()
        
        # 1. Read Header
        # We need to read enough bytes to parse CBOR. 
        # Since CBOR is self-describing, we can try reading a chunk and decoding.
        # But `cbor2` usually needs the full object.
        # We assume header fits in first 4KB? Or we read until we decode?
        # A robust way is to read a prefix, try decode, if incomplete, read more.
        # For simplicity, we assume header is reasonably small (< 64KB).
        
        with open(input_path, "rb") as f:
            header_chunk = await loop.run_in_executor(None, f.read, 64 * 1024)
            
        # Decode CBOR
        # cbor2.loads will decode the first object and ignore the rest?
        # Yes, if there are extra bytes.
        import cbor2
        try:
            container_dict = cbor2.loads(header_chunk)
            container = EncryptedContainer.model_validate(container_dict)
            
            # Calculate header size to know where stream starts
            header_bytes = container.to_bytes()
            header_size = len(header_bytes)
            
        except Exception as e:
            raise SafeCoreError(f"Invalid container header: {e}")

        # 2. Derive Master Key
        salt = Salt(container.kdf_params["salt"])
        master_key = await loop.run_in_executor(
            None, 
            self.kdf.derive_key, 
            password, salt
        )
        
        # 3. Unwrap DEK
        dek = await loop.run_in_executor(
            None,
            AesKeyWrapProvider.unwrap_key,
            master_key, container.wrapped_dek
        )
        
        # 4. Stream Processing
        async def file_stream_reader() -> AsyncIterator[bytes]:
            with open(input_path, "rb") as f:
                # Skip header
                await loop.run_in_executor(None, f.seek, header_size)
                
                while True:
                    chunk = await loop.run_in_executor(None, f.read, 64 * 1024)
                    if not chunk:
                        break
                    yield chunk

        decrypted_stream = self.pipeline.decrypt_stream(
            file_stream_reader(),
            DataKey(dek),
            Nonce(container.nonce_base),
            AAD(container.aad)
        )
        
        # 5. Write Output
        with open(output_path, "wb") as f:
            async for chunk in decrypted_stream:
                await loop.run_in_executor(None, f.write, chunk)

        if self.audit_logger:
            self.audit_logger.log_event(
                "DECRYPTION_SUCCESS",
                {"file": input_path},
                {}
            )

    @panic_proof
    async def rotate_password(
        self,
        container: EncryptedContainer,
        old_pass: SecretBytes,
        new_pass: SecretBytes
    ) -> EncryptedContainer:
        """
        Rotate the KEK (password) without re-encrypting the payload.
        """
        loop = asyncio.get_running_loop()
        
        # 1. Derive Old Master Key
        old_salt = Salt(container.kdf_params["salt"])
        old_mk = await loop.run_in_executor(None, self.kdf.derive_key, old_pass, old_salt)
        
        # 2. Unwrap DEK
        dek = await loop.run_in_executor(
            None, AesKeyWrapProvider.unwrap_key, old_mk, container.wrapped_dek
        )
        
        # 3. Derive New Master Key
        new_salt = Salt(os.urandom(16))
        new_mk = await loop.run_in_executor(None, self.kdf.derive_key, new_pass, new_salt)
        
        # 4. Wrap DEK with New Master Key
        new_wrapped_dek = await loop.run_in_executor(
            None, AesKeyWrapProvider.wrap_key, new_mk, dek
        )
        
        # 5. Update Container
        new_container = container.model_copy(update={
            "wrapped_dek": new_wrapped_dek,
            "kdf_params": {"salt": new_salt, "type": "argon2id"}
        })
        
        if self.audit_logger:
            self.audit_logger.log_event("KEY_ROTATION", {}, {})
            
        return new_container
