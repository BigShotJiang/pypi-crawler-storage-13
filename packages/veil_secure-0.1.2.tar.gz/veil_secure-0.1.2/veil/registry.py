"""
The Factory: Registry for providers and middleware.
"""

from typing import Dict, Type, Any, Optional
from veil.interfaces import ICipherProvider, IKdfProvider, IStreamProcessor
from veil.providers import (
    ChaCha20Poly1305Provider, 
    Argon2idProvider, 
    ZstdStreamMiddleware
)

class ProviderRegistry:
    """
    Singleton registry for Veil providers.
    """
    _instance: Optional["ProviderRegistry"] = None
    
    def __new__(cls) -> "ProviderRegistry":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
        return cls._instance

    def _initialize(self) -> None:
        self._ciphers: Dict[str, Type[ICipherProvider]] = {}
        self._kdfs: Dict[str, Type[IKdfProvider]] = {}
        self._middleware: Dict[str, Type[IStreamProcessor]] = {}
        
        # Register defaults
        self.register_cipher("chacha20-poly1305", ChaCha20Poly1305Provider)
        self.register_kdf("argon2id", Argon2idProvider)
        self.register_middleware("zstd", ZstdStreamMiddleware)

    def register_cipher(self, name: str, provider: Type[ICipherProvider]) -> None:
        self._ciphers[name] = provider

    def register_kdf(self, name: str, provider: Type[IKdfProvider]) -> None:
        self._kdfs[name] = provider

    def register_middleware(self, name: str, processor: Type[IStreamProcessor]) -> None:
        self._middleware[name] = processor

    def get_cipher(self, name: str) -> Type[ICipherProvider]:
        if name not in self._ciphers:
            raise ValueError(f"Cipher provider '{name}' not found")
        return self._ciphers[name]

    def get_kdf(self, name: str) -> Type[IKdfProvider]:
        if name not in self._kdfs:
            raise ValueError(f"KDF provider '{name}' not found")
        return self._kdfs[name]

    def get_middleware(self, name: str) -> Type[IStreamProcessor]:
        if name not in self._middleware:
            raise ValueError(f"Middleware '{name}' not found")
        return self._middleware[name]

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton (useful for testing)."""
        cls._instance = None
