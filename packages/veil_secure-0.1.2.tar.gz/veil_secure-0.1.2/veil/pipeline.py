"""
The Flow: Pipeline for stream processing.
"""

import struct
from typing import AsyncIterator, List, Optional
from veil.interfaces import (
    IStreamProcessor, ICipherProvider, 
    ProcessingContext, AuthenticationError
)
from veil.types import DataKey, Nonce, AAD

class CryptoPipeline:
    """
    Orchestrates the stream processing pipeline:
    Input -> Middleware -> Encryption -> Output
    Input <- Middleware <- Decryption <- Output
    """
    
    def __init__(self, chunk_size: int = 64 * 1024):
        self.middleware: List[IStreamProcessor] = []
        self.cipher: Optional[ICipherProvider] = None
        self.chunk_size = chunk_size

    def add_middleware(self, processor: IStreamProcessor) -> None:
        self.middleware.append(processor)

    def set_cipher(self, cipher: ICipherProvider) -> None:
        self.cipher = cipher

    async def encrypt_stream(
        self, 
        input_stream: AsyncIterator[bytes], 
        key: DataKey, 
        nonce: Nonce, 
        aad: AAD
    ) -> AsyncIterator[bytes]:
        """
        Encrypts the stream.
        1. Applies middleware (in order).
        2. Encrypts using cipher provider.
        3. Prepends chunk index to each chunk.
        """
        if not self.cipher:
            raise ValueError("Cipher not set")

        ctx = ProcessingContext()
        
        # 1. Apply Middleware
        stream = input_stream
        for mw in self.middleware:
            stream = mw.process_stream(stream, ctx)

        # 2. Encrypt (Provider handles chunking and encryption)
        # The provider yields [ciphertext || tag]
        encrypted_stream = self.cipher.encrypt_stream(stream, key, nonce, aad)
        
        # 3. Prepend Chunk Index
        chunk_index = 0
        async for chunk in encrypted_stream:
            # Format: [chunk_index: 8b] [ciphertext_with_tag]
            header = struct.pack(">Q", chunk_index)
            yield header + chunk
            chunk_index += 1

    async def decrypt_stream(
        self, 
        input_stream: AsyncIterator[bytes], 
        key: DataKey, 
        nonce: Nonce, 
        aad: AAD
    ) -> AsyncIterator[bytes]:
        """
        Decrypts the stream.
        1. Reads chunk index and ciphertext.
        2. Decrypts using cipher provider.
        3. Reverses middleware (in reverse order).
        """
        if not self.cipher:
            raise ValueError("Cipher not set")

        # 1. Strip Chunk Index and feed to provider
        # We need an iterator that yields just the [ciphertext || tag] 
        # but also verifies the chunk index order?
        # The provider expects [ciphertext || tag].
        
        async def stripped_stream_gen() -> AsyncIterator[bytes]:
            # We need to read chunks of size (8 + encrypted_chunk_size)
            # But encrypted_chunk_size might vary for the last chunk.
            # However, the provider expects chunks of (CHUNK_SIZE + TAG_SIZE).
            # So we should read (8 + CHUNK_SIZE + TAG_SIZE).
            
            # We assume the provider is configured with the same chunk_size.
            # Tag size is 16 (Poly1305).
            tag_size = 16
            full_block_size = 8 + self.chunk_size + tag_size
            
            buffer = bytearray()
            expected_index = 0
            
            async for data in input_stream:
                buffer.extend(data)
                
                while len(buffer) >= full_block_size:
                    block = buffer[:full_block_size]
                    buffer = buffer[full_block_size:]
                    
                    # Parse header
                    index = struct.unpack(">Q", block[:8])[0]
                    if index != expected_index:
                        raise AuthenticationError(f"Chunk index mismatch: expected {expected_index}, got {index}")
                    
                    yield block[8:] # Yield ciphertext + tag
                    expected_index += 1
            
            # Handle last chunk
            if buffer:
                if len(buffer) < 8 + tag_size:
                    raise AuthenticationError("Truncated last chunk")
                
                index = struct.unpack(">Q", buffer[:8])[0]
                if index != expected_index:
                    raise AuthenticationError(f"Chunk index mismatch: expected {expected_index}, got {index}")
                
                yield buffer[8:]

        # 2. Decrypt
        decrypted_stream = self.cipher.decrypt_stream(stripped_stream_gen(), key, nonce, aad)
        
        # 3. Reverse Middleware
        stream = decrypted_stream
        ctx = ProcessingContext()
        for mw in reversed(self.middleware):
            stream = mw.inverse_process(stream, ctx)
            
        async for chunk in stream:
            yield chunk

async def chunk_stream(stream: AsyncIterator[bytes], size: int) -> AsyncIterator[bytes]:
    """Helper to re-chunk a stream."""
    buffer = bytearray()
    async for chunk in stream:
        buffer.extend(chunk)
        while len(buffer) >= size:
            yield bytes(buffer[:size])
            buffer = buffer[size:]
    if buffer:
        yield bytes(buffer)
