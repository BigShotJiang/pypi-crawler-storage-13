import json
import requests

_COOKIE = (
    "_ym_uid=176023168614794914; _ym_d=1760231686; "
    "_csrf-front=d3edd593a6bd99f899b2fc8065deb9e8a242175581763c4e14f8e5e2b55f59afa%3A2%3A%7Bi%3A0%3Bs%3A11%3A%22_csrf-front%22%3Bi%3A1%3Bs%3A32%3A%22Ms1Ggxtjt-ikV6FGlOmOuARJYkp3rj8d%22%3B%7D; "
    "_clck=mqbyz5^2^g18^0^2111; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%22f5c72704-12ab-4ada-96b0-aac90b7206fa%5C%22%2C%5B1762881262%2C567000000%5D%5D%22%5D%5D; "
    "__gads=ID=318f105188a70a8c:T=1760231684:RT=1763824977:S=ALNI_MbksgLf8T4_k9pyWi-1eLP7fBVnnQ; "
    "__gpi=UID=0000129c58febc59:T=1760231684:RT=1763824977:S=ALNI_MbsKp_RgRrZZx6jaN7RBqTbfJF2Rw; "
    "__eoi=ID=f6d95719c3f8baa7:T=1760231684:RT=1763824977:S=AA-Afja8-plGcL0oG7ZDG1e_yHNB; _ym_visorc=b; _ym_isad=2; "
    "FCNEC=%5B%5B%22AKsRol8GQ9CwYyO8iANDVHwFAjwD3RsE4NLiugkMYnx6Lq4299VUldkME4DgQiWOUbA4Wfm0SqxhrLOQnknqwdDyqF06FBA_Qus1QTNXmEf25CaqiWT-UioYEx3_X3CGGaBy96A7Um-3qZZn2QRaMJLQKSDJiLzZaA%3D%3D%22%5D%5D; "
    "_clsk=qo2mf8^1763825900071^3^1^b.clarity.ms%2Fcollect; talkai-front=6n1aptbr8fntnmrgg3rokgslv8"
)

def _montar_content(nome, canal_id, link, provas, motivo):
    provas_join = ", ".join(provas)
    return (
        'OBSERVE ESSA RESPOSTA COMO BASE: { "report_type": "channel_violation", '
        '"subject": "Serious Privacy Violation - Doxxing", '
        '"channel_details": { "name": "DOXXING LUFFY GOV", '
        '"link": "https://t.me/luffygovPuta", "id": "-1002616153958" }, '
        '"violation_description": "Channel is openly sharing people\\\'s private information including phone numbers and personal details without their consent", '
        '"violated_policies": [ "Telegram\\\'s Terms of Service regarding privacy", '
        '"Data protection laws (GDPR/LGPD)", "Basic standards of ethical behavior" ], '
        '"supporting_evidence": { "post_urls": [ '
        '"https://t.me/luffygovPuta/26", "https://t.me/luffygovPuta/23", '
        '"https://t.me/luffygovPuta/22", "https://t.me/luffygovPuta/21", '
        '"https://t.me/luffygovPuta/19" ], '
        '"concerns": [ "Public channel exposing private information to anyone", '
        '"Non-consensual sharing of personal data", "Potential harm to affected individuals" ] }, '
        '"requested_actions": [ "Immediately remove this channel", '
        '"Ban the account(s) responsible", "Preserve evidence for potential legal action" ], '
        '"urgency": "High - Due to public nature of violations" }\n\n'
        f'COM BASE NO MOTIVO, CRIE TODO O JSON. PEGUE ESSA IDEIA E USE AS SEGUINTES INFORMAÇOES PARA GERAR UM NOVO JSON (VOCE SÓ PODE ENVIAR UM JSON) UTILIZE ESSAS INFORMACOES: NOME: {nome} ID: {canal_id} LINK: {link} PROVAS: {provas_join} MOTIVO: {motivo}\n\n'
        'USANDO O MOTIVO, VOCE IRA CRIAR O JSON TODO E TODOS OS TEXTOS PELA BASE INFORMADA.'
    )

class BanAI:
    def __init__(self):
        self._cookie = _COOKIE

    def enviar(self, nome, canal_id, link, provas, motivo, timeout=60):
        payload = {
            "type": "chat",
            "messagesHistory": [
                {
                    "id": "01377ae7-f87b-406b-aeee-2371babf6a6d",
                    "from": "you",
                    "content": _montar_content(nome, canal_id, link, provas, motivo),
                    "model": ""
                }
            ],
            "settings": {
                "model": "gpt-4.1-nano",
                "temperature": 0.7
            }
        }

        headers = {
            "accept": "application/json, text/event-stream",
            "content-type": "application/json",
            "user-agent": "Mozilla/5.0",
            "origin": "https://talkai.info",
            "referer": "https://talkai.info/chat/"
        }

        r = requests.post(
            "https://talkai.info/chat/send/",
            headers=headers,
            cookies={"all": self._cookie},
            data=json.dumps(payload),
            stream=True,
            timeout=timeout
        )

        for linha in r.iter_lines():
            if linha:
                yield linha.decode()
