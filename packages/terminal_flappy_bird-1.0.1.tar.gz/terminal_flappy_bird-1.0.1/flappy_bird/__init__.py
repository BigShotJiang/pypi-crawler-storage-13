import curses
import time
import random
import json
import os
from datetime import datetime

# Statistics Management
STATS_FILE = os.path.expanduser("~/.flappy_stats.json")

class GameStats:
    def __init__(self):
        self.stats = {
            'high_score': 0,
            'total_games': 0,
            'total_time': 0, # in seconds
            'history': [] # List of {date, score, duration}
        }
        self.load()
    
    def load(self):
        if os.path.exists(STATS_FILE):
            try:
                with open(STATS_FILE, 'r') as f:
                    loaded = json.load(f)
                    # Merge loaded stats carefully to preserve structure
                    self.stats.update(loaded)
            except Exception:
                pass # Corrupt file or first run
                
    def save(self):
        try:
            with open(STATS_FILE, 'w') as f:
                json.dump(self.stats, f)
        except Exception:
            pass

    def add_run(self, score, duration):
        self.stats['total_games'] += 1
        self.stats['total_time'] += duration
        if score > self.stats['high_score']:
            self.stats['high_score'] = score
            
        # Keep last 100 games history
        self.stats['history'].append({
            'date': datetime.now().isoformat(),
            'score': score,
            'duration': duration
        })
        if len(self.stats['history']) > 100:
            self.stats['history'].pop(0)
            
        self.save()

    def get_high_score(self):
        return self.stats['high_score']
        
def show_stats_screen(stdscr, stats):
    max_y, max_x = stdscr.getmaxyx()
    while True:
        stdscr.erase()
        
        # Header
        title = "STATISTICS"
        stdscr.addstr(2, max_x // 2 - len(title) // 2, title, curses.A_BOLD)
        
        # Stats Data
        s = stats.stats
        lines = [
            f"High Score: {s['high_score']}",
            f"Total Games: {s['total_games']}",
            f"Total Time: {int(s['total_time'] // 60)}m {int(s['total_time'] % 60)}s",
            "",
            "History (Last 10):"
        ]
        
        # History table
        history = s['history'][-10:]
        history.reverse() # Newest first
        for run in history:
            try:
                dt = datetime.fromisoformat(run['date']).strftime("%Y-%m-%d %H:%M")
                lines.append(f"{dt} | Score: {run['score']:3} | Time: {int(run['duration'])}s")
            except Exception:
                pass

        lines.append("")
        lines.append("Press 'q', SPACE, or 's' to return")

        # Draw Lines
        start_y = 4
        for i, line in enumerate(lines):
             if start_y + i < max_y - 1:
                 x_pos = max_x // 2 - len(line) // 2
                 # Ensure x_pos is not negative
                 if x_pos < 0: x_pos = 0
                 try:
                    stdscr.addstr(start_y + i, x_pos, line)
                 except curses.error: pass

        stdscr.refresh()
        
        try:
            key = stdscr.getch()
            if key in [ord('q'), ord(' '), ord('s')]:
                break
        except Exception: pass
        time.sleep(0.1)

def main_game(stdscr):
    # Setup curses
    curses.curs_set(0)  # Hide cursor
    stdscr.nodelay(True) # Non-blocking input
    stdscr.timeout(0)   # Non-blocking getch
    
    # Initialize Stats
    stats = GameStats()
    
    # Colors will be initialized later if supported
    if curses.has_colors():
        curses.start_color()
        curses.use_default_colors()
        
        # Define color pairs
        # 1: Yellow Bird, Default Background
        curses.init_pair(1, curses.COLOR_YELLOW, -1)
        # 2: Green Pipe, Default Background
        curses.init_pair(2, curses.COLOR_GREEN, -1)
        # 4: Bright Green Pipe (Highlight)
        curses.init_pair(4, curses.COLOR_GREEN, curses.COLOR_GREEN)
        # 5: Dark Green Pipe (Shadow) - simulating with black on green if possible or just different char
        curses.init_pair(5, curses.COLOR_BLACK, curses.COLOR_GREEN)
        
        # 3: White Text, Default Background
        curses.init_pair(3, curses.COLOR_WHITE, -1)
        
        # No background color setting needed for default terminal background

    # Game constants
    # Aim for max FPS, but we still need a target for physics calculations
    # We'll separate physics updates from rendering
    TARGET_FPS = 60 
    FRAME_TIME = 1.0 / TARGET_FPS # Re-added for frame capping
    PHYSICS_DT = 1.0 / TARGET_FPS
    
    GRAVITY = 0.06          
    JUMP_STRENGTH = -0.75   
    TERMINAL_VELOCITY = 1.5 
    PIPE_SPEED = 0.4        
    PIPE_SPAWN_RATE = 90    
    PIPE_GAP_HEIGHT = 8
    PIPE_WIDTH = 6 # Wider for detail
    
    # Actual FPS Calculation
    actual_fps = 0
    frame_times = []

    # Game State
    max_y, max_x = stdscr.getmaxyx()
    
    def reset_game():
        return {
            'bird_y': max_y // 2,
            'bird_vel': 0.0,
            'pipes': [],
            'frame_count': 40, # Start closer to first spawn (was -60)
            'score': 0,
            'started': False,
            'run_start_time': 0, # Track duration
            'needs_save': True
        }
    
    game_state = reset_game()
    bird_x = max_x // 4
    
    running = True
    game_over = False
    
    # Physics accumulator
    accumulator = 0.0
    last_time = time.time()

    while running:
        start_time = time.time()
        current_time = time.time()
        dt = current_time - last_time
        last_time = current_time
        accumulator += dt

        # Input handling (Non-blocking)
        try:
            key = stdscr.getch()
            if key == ord('q'):
                running = False
            elif key == ord(' ') or key == curses.KEY_UP:
                if not game_state['started']:
                    game_state['started'] = True
                    game_state['run_start_time'] = time.time()
                game_state['bird_vel'] = JUMP_STRENGTH
            elif key == ord('s'):
                 if not game_state['started']: # Only allow stats if game hasn't started
                    show_stats_screen(stdscr, stats)
                    stdscr.clear()
                    stdscr.refresh()
                    last_time = time.time()
        except Exception:
            pass
        
        # Physics Update (Fixed Timestep)
        while accumulator >= PHYSICS_DT:
            accumulator -= PHYSICS_DT
            
            if game_state['started'] and not game_over:
                game_state['frame_count'] += 1
                
                # Update logic
                game_state['bird_vel'] += GRAVITY
                # Clamp falling speed
                if game_state['bird_vel'] > TERMINAL_VELOCITY:
                    game_state['bird_vel'] = TERMINAL_VELOCITY
                    
                game_state['bird_y'] += game_state['bird_vel']
                
                # Pipe Management
                # Spawn
                if game_state['frame_count'] > 0 and game_state['frame_count'] % PIPE_SPAWN_RATE == 0:
                    gap_y = random.randint(2, max_y - PIPE_GAP_HEIGHT - 2)
                    game_state['pipes'].append({'x': float(max_x), 'gap_y': gap_y, 'passed': False})
                    
                # Move
                for pipe in game_state['pipes']:
                    pipe['x'] -= PIPE_SPEED
                    
                    # Scoring
                    if not pipe['passed'] and pipe['x'] < bird_x:
                        game_state['score'] += 1
                        pipe['passed'] = True
                    
                # Despawn
                if game_state['pipes'] and game_state['pipes'][0]['x'] < -PIPE_WIDTH:
                    game_state['pipes'].pop(0)
                
                # Collision Detection
                # Floor/Ceiling
                if game_state['bird_y'] < 0 or game_state['bird_y'] >= max_y:
                    game_over = True
                
                # Pipes
                bird_int_y = int(game_state['bird_y'])
                for pipe in game_state['pipes']:
                    px = int(pipe['x'])
                    # Check x collision (bird is 1 char wide)
                    if px <= bird_x < px + PIPE_WIDTH:
                        # Check y collision (hit top pipe OR hit bottom pipe)
                        if bird_int_y < pipe['gap_y'] or bird_int_y >= pipe['gap_y'] + PIPE_GAP_HEIGHT:
                            game_over = True
            
        else:
             # Handle game over input outside the physics loop
             if game_over:
                # Save stats on first game over frame (detect transition)
                if game_state.get('needs_save', True):
                     duration = time.time() - game_state['run_start_time']
                     stats.add_run(game_state['score'], duration)
                     game_state['needs_save'] = False

                try:
                    if key == ord(' '):
                        game_state = reset_game()
                        game_over = False
                        accumulator = 0 # Reset physics timer
                    elif key == ord('s'):
                        show_stats_screen(stdscr, stats)
                        # Redraw game after stats
                        stdscr.clear()
                        stdscr.refresh()
                        last_time = time.time() # Prevent physics jump after closing stats
                except Exception:
                    pass

        # Rendering (Uncapped)
        stdscr.erase()
        
        # Helper to draw detailed pipe
        def draw_pipe_segment(y, px):
            try:
                if curses.has_colors():
                    # Left shadow (Dark Green simulated)
                    stdscr.addstr(y, px, "▒", curses.color_pair(2))
                    # Middle body (Bright Green Highlight)
                    stdscr.addstr(y, px+1, " " * (PIPE_WIDTH - 2), curses.color_pair(4) | curses.A_REVERSE) 
                    # Right shadow (Dark Green simulated)
                    stdscr.addstr(y, px+PIPE_WIDTH-1, "▒", curses.color_pair(2))
                else:
                    stdscr.addstr(y, px, "#" * PIPE_WIDTH)
            except curses.error:
                pass
                
        def draw_pipe_cap(y, px):
             try:
                if curses.has_colors():
                    # Cap is slightly wider visually or same width but different pattern
                    stdscr.addstr(y, px, " " * PIPE_WIDTH, curses.color_pair(4) | curses.A_REVERSE)
                else:
                    stdscr.addstr(y, px, "=" * PIPE_WIDTH)
             except curses.error: pass

        # Draw Pipes
        for pipe in game_state['pipes']:
            px = int(pipe['x'])
            if 0 <= px + PIPE_WIDTH < max_x + PIPE_WIDTH: # Allow partial drawing offscreen
                # Draw top pipe
                for y in range(pipe['gap_y'] - 1):
                    draw_pipe_segment(y, px)
                draw_pipe_cap(pipe['gap_y'] - 1, px) # Cap at bottom of top pipe
                
                # Draw bottom pipe
                draw_pipe_cap(pipe['gap_y'] + PIPE_GAP_HEIGHT, px) # Cap at top of bottom pipe
                for y in range(pipe['gap_y'] + PIPE_GAP_HEIGHT + 1, max_y):
                     draw_pipe_segment(y, px)

        
        # Draw Bird
        if not game_over:
            try:
                if curses.has_colors():
                    # Use a smaller block character or even 'o' if supported
                    stdscr.addstr(int(game_state['bird_y']), int(bird_x), "o", curses.color_pair(1))
                else:
                    stdscr.addstr(int(game_state['bird_y']), int(bird_x), "o")
            except curses.error:
                pass # Ignore drawing errors at edge of screen
            
        # Frame cap re-enabled
        elapsed = time.time() - start_time
        if elapsed < FRAME_TIME:
            time.sleep(FRAME_TIME - elapsed)
            
        # Calculate actual FPS
        frame_end = time.time()
        # Use current_time from start of loop or just use frame_end - last_frame_end
        # But we need a separate variable to track frame duration for FPS since physics loop messes with time
        # Simplest is just to measure rendering loop time
        
        # We need to re-implement FPS counter since we removed start_time
        frame_duration = frame_end - current_time # Approximation using loop start time
        if frame_duration <= 0: frame_duration = 0.001
        
        frame_times.append(frame_duration)
        if len(frame_times) > 60:
             frame_times.pop(0)
        if frame_times:
            actual_fps = 1.0 / (sum(frame_times) / len(frame_times))
            
        stdscr.addstr(0, 0, f"Score: {game_state['score']} | HI: {stats.get_high_score()} | FPS: {actual_fps:.1f}")
        
        if not game_state['started'] and not game_over:
             msg = "Press SPACE to Start, 's' for stats"
             try:
                 stdscr.addstr(max_y // 2 + 2, max(0, max_x // 2 - len(msg) // 2), msg)
             except curses.error:
                 pass
        
        if game_over:
             msg = f"GAME OVER! Score: {game_state['score']} - Press SPACE to restart, 's' for stats, q to quit"
             try:
                 stdscr.addstr(max_y // 2, max(0, max_x // 2 - len(msg) // 2), msg)
             except curses.error:
                 pass
             
        stdscr.refresh()

def main():
    try:
        curses.wrapper(main_game)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
