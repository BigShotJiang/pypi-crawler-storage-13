from setuptools import setup, find_packages

setup(
    name="terminal-flappy-bird",
    version="1.0.1",
    author="bshkrt",
    author_email="bshkrt@example.com",
    description="A terminal-based Flappy Bird clone",
    long_description="A smooth, high-performance Flappy Bird clone that runs in your terminal using Python curses.",
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'flappy=flappy_bird:main',
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)

