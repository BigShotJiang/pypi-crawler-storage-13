# Terminal Flappy Bird

A smooth, high-performance Flappy Bird clone that runs in your terminal using Python curses.

![Terminal Flappy Bird](https://img.shields.io/pypi/v/terminal-flappy-bird)

## Installation

```bash
pip install terminal-flappy-bird
```

## Updating

If you have an older version installed, you can update to the latest version with:

```bash
pip install --upgrade terminal-flappy-bird
```

## How to Play

Run the game from your terminal:

```bash
flappy
```

- **SPACE**: Jump / Start Game / Restart
- **q**: Quit
- **s**: Statistics

## Requirements

- Python 3.6+
- A terminal that supports curses (Linux, macOS, WSL on Windows)

