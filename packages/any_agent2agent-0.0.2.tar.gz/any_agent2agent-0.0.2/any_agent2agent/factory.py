"""Factory utilities for constructing agent adapters."""

from __future__ import annotations

from typing import Dict, Type

from .base import BaseAgent
from .exceptions import ConfigurationError


class AgentFactory:
    """Registry-backed factory for dynamically creating agent adapters."""

    _registry: Dict[str, Type[BaseAgent]] = {}

    @classmethod
    def register(cls, name: str, agent_cls: Type[BaseAgent]) -> None:
        key = name.lower()
        cls._registry[key] = agent_cls

    @classmethod
    def create(cls, provider: str, **config) -> BaseAgent:
        key = provider.lower()
        try:
            agent_cls = cls._registry[key]
        except KeyError as exc:
            raise ConfigurationError(f"Unknown provider '{provider}'") from exc
        return agent_cls(**config)

    @classmethod
    def available_providers(cls) -> Dict[str, Type[BaseAgent]]:
        return dict(cls._registry)

