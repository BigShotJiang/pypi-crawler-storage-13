"""Helpers for wiring any_agent2agent agents into AWS Bedrock tools."""

from __future__ import annotations

import json
import time
import uuid
from typing import Any, Callable, Dict, Mapping, MutableMapping, Optional

from .server import AgentHandler, create_agent_handler

BedrockResponseBuilder = Callable[[str, Mapping[str, Any], Mapping[str, Any]], Mapping[str, Any]]


def create_bedrock_tool_handler(
    agent_logic: AgentHandler,
    *,
    protocol: str = "agent_protocol",
    response_builder: BedrockResponseBuilder | None = None,
    default_metadata: Optional[Dict[str, Any]] = None,
    **handler_kwargs: Any,
) -> Callable[[Mapping[str, Any], Any], Mapping[str, Any]]:
    """
    Wrap agent logic so it can be deployed as a Bedrock Agent tool (Lambda/action group).

    Args:
        agent_logic: Function that receives `List[AgentMessage]`.
        protocol: Either `"agent_protocol"` or `"bridge"` depending on your payload needs.
        response_builder: Optional hook to customize the Bedrock response payload.
        default_metadata: Metadata merged into every agent response.
        handler_kwargs: Forwarded to `create_agent_handler` (schema adapters, cache TTL, etc.).

    Returns:
        A callable with signature `(event: Mapping[str, Any], context) -> Mapping[str, Any]`
        that understands Bedrock tool events.
    """

    base_handler = create_agent_handler(
        agent_logic,
        protocol=protocol,  # type: ignore[arg-type]
        default_metadata=default_metadata,
        **handler_kwargs,
    )

    def handler(event: Mapping[str, Any] | str, context: Any = None) -> Mapping[str, Any]:
        normalized = _normalize_event(event)
        sdk_payload = _build_sdk_payload(normalized, protocol=protocol)
        sdk_response = base_handler(sdk_payload)
        content, metadata = _extract_response_parts(sdk_response, protocol=protocol)

        builder = response_builder or _default_response_builder
        return builder(content, metadata, normalized)

    return handler


def _normalize_event(event: Mapping[str, Any] | str | None) -> Dict[str, Any]:
    if event is None:
        return {}
    if isinstance(event, str):
        try:
            data = json.loads(event)
        except json.JSONDecodeError as exc:  # pragma: no cover - defensive
            raise ValueError("Bedrock event string is not valid JSON") from exc
    else:
        data = dict(event)

    if "body" in data and isinstance(data["body"], str):
        try:
            body = json.loads(data["body"])
            if isinstance(body, MutableMapping):
                data = {**data, **body}
        except json.JSONDecodeError:
            pass
    return data


def _build_sdk_payload(event: Mapping[str, Any], *, protocol: str) -> Dict[str, Any]:
    input_text = event.get("inputText") or event.get("inputTextJson") or event.get("payload")
    if not isinstance(input_text, str) or not input_text.strip():
        raise ValueError("Bedrock tool event missing 'inputText'")

    session_id = event.get("sessionId") or event.get("session", {}).get("id") or _generate_session_id()
    timestamp = int(time.time() * 1000)
    metadata = {
        "session_id": session_id,
        "bedrock": {
            "agentId": event.get("agentId"),
            "agentAliasId": event.get("agentAliasId"),
            "invocationId": event.get("invocationId"),
            "sessionState": event.get("sessionState"),
            "actionGroup": event.get("actionGroup"),
            "timestamp_ms": timestamp,
        },
    }

    if protocol == "agent_protocol":
        return {
            "messages": [
                {
                    "id": event.get("messageId") or str(uuid.uuid4()),
                    "role": "user",
                    "content": [{"type": "text", "text": input_text}],
                    "metadata": metadata,
                }
            ]
        }

    return {
        "messages": [
            {
                "id": event.get("messageId") or str(uuid.uuid4()),
                "role": "user",
                "content": input_text,
                "metadata": metadata,
                "timestamp": timestamp,
            }
        ]
    }


def _extract_response_parts(response: Mapping[str, Any], *, protocol: str) -> tuple[str, Dict[str, Any]]:
    if protocol == "agent_protocol":
        messages = response.get("messages")
        if not isinstance(messages, list) or not messages:
            raise ValueError("Agent Protocol response missing 'messages'")
        assistant = messages[-1]
        metadata = dict(assistant.get("metadata") or {})
        content_blocks = assistant.get("content") or []
        text_chunks = []
        if isinstance(content_blocks, list):
            for block in content_blocks:
                if isinstance(block, Mapping) and block.get("type") == "text":
                    text = block.get("text")
                    if isinstance(text, str):
                        text_chunks.append(text)
        elif isinstance(content_blocks, str):
            text_chunks.append(content_blocks)
        content = "\n".join(chunk for chunk in text_chunks if chunk).strip()
        return content, metadata

    content = response.get("content", "")
    metadata = dict(response.get("metadata") or {})
    return str(content), metadata


def _default_response_builder(
    content: str,
    metadata: Mapping[str, Any],
    event: Mapping[str, Any],
) -> Dict[str, Any]:
    action_group = event.get("actionGroup") or metadata.get("action_group") or "agent_protocol_bridge"
    version = event.get("version") or metadata.get("version") or "1.0"
    session_state = event.get("sessionState") or {}
    body_payload: Dict[str, Any] = {"body": content}
    if metadata:
        body_payload["metadata"] = metadata
    return {
        "sessionId": event.get("sessionId"),
        "sessionState": session_state,
        "response": {
            "actionGroup": action_group,
            "version": version,
            "responseBody": {
                "TEXT": body_payload,
            },
        },
    }


def _generate_session_id() -> str:
    return f"bedrock-session-{uuid.uuid4()}"


__all__ = ["create_bedrock_tool_handler", "BedrockResponseBuilder"]


