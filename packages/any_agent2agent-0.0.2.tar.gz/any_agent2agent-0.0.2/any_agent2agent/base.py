"""Abstract agent definitions."""

from __future__ import annotations

import abc
import logging
from typing import AsyncIterator, Iterator, List, Sequence

from .models import AgentMessage

logger = logging.getLogger(__name__)


class BaseAgent(abc.ABC):
    """Base class for all agent adapters."""

    def __init__(self, *, api_key: str | None, timeout: float = 30.0) -> None:
        self.api_key = api_key
        self.timeout = timeout
        self._history: List[AgentMessage] = []
        self._connected = False

    @abc.abstractmethod
    def connect(self) -> bool:
        """Establishes a session or validates credentials."""

    @abc.abstractmethod
    def send(self, prompt: str) -> AgentMessage:
        """Send a synchronous prompt to the provider."""

    @abc.abstractmethod
    def stream(self, prompt: str) -> Iterator[str]:
        """Yield streaming responses for providers that support it."""

    async def async_connect(self) -> bool:
        """Async variant of connect; defaults to running the sync version."""
        return self.connect()

    @abc.abstractmethod
    async def async_send(self, prompt: str) -> AgentMessage:
        """Asynchronous prompt handling."""

    @abc.abstractmethod
    async def async_stream(self, prompt: str) -> AsyncIterator[str]:
        """Asynchronous streaming handler."""

    def get_history(self) -> Sequence[AgentMessage]:
        """Return the normalized conversation history."""
        return tuple(self._history)

    def _append_user_message(self, prompt: str) -> AgentMessage:
        message = AgentMessage(role="user", content=prompt)
        self._history.append(message)
        return message

    def _append_assistant_message(self, content: str, *, metadata: dict | None = None) -> AgentMessage:
        message = AgentMessage(role="assistant", content=content, metadata=metadata or {})
        self._history.append(message)
        return message

    def _ensure_connected(self) -> None:
        if not self._connected:
            logger.debug("Agent not connected; invoking connect()")
            self._connected = self.connect()

    def close(self) -> None:
        """Optional cleanup hook for agents with persistent connections."""
        # Subclasses may override when needed.
        logger.debug("close() called on %s; no action by default", self.__class__.__name__)

    async def aclose(self) -> None:
        """Async cleanup hook."""
        self.close()

