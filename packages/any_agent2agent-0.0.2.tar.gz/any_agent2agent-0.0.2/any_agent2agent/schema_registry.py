"""
Registry loader for schema adapters.

This module fetches adapter manifests from local paths, GitHub URIs, generic
HTTP(S) endpoints, or S3 objects. Manifests describe how to turn between the
normalized Agent Protocol messages and a custom on-the-wire schema.

Manifest JSON format (all keys optional unless noted):

{
    "name": "log-agent",
    "version": "1.0.0",
    "request_schema": "https://.../request.schema.json",
    "response_schema": "https://.../response.schema.json",
    "converter": "package.module:ClassName",   # required
    "metadata": {...},
    "hash": "sha256:..."
}

Developers can host the manifest anywhere reachable over HTTP(S) or in GitHub
using the custom URI scheme:

    github://org/repo/path/to/manifest.json#branch-or-tag

The loader downloads the manifest (with optional caching), validates required
fields, imports the converter class, and instantiates it via
`load_schema_adapter`.
"""

from __future__ import annotations

import dataclasses
import hashlib
import importlib
import json
import os
import time
from pathlib import Path
from typing import Any, Dict, Mapping, MutableMapping, Optional, Tuple
from urllib.parse import urlparse

import httpx

try:  # pragma: no cover - optional dependency
    import boto3  # type: ignore
except ImportError:  # pragma: no cover - boto3 is optional
    boto3 = None

DEFAULT_CACHE_TTL = 300.0
CACHE_ENV_VAR = "A2A_SCHEMA_CACHE_DIR"
ADAPTER_ENV_VAR = "A2A_SCHEMA_ADAPTER"


class SchemaRegistryError(RuntimeError):
    """Raised when manifests or registry artifacts cannot be processed."""


@dataclasses.dataclass(frozen=True)
class AdapterManifest:
    """Parsed adapter manifest."""

    name: str
    converter: str
    version: Optional[str] = None
    request_schema: Optional[str] = None
    response_schema: Optional[str] = None
    metadata: Mapping[str, Any] = dataclasses.field(default_factory=dict)
    hash: Optional[str] = None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "AdapterManifest":
        try:
            converter = payload["converter"]
        except KeyError as exc:  # pragma: no cover - defensive
            raise SchemaRegistryError("Manifest missing required 'converter' field") from exc

        if not isinstance(converter, str) or ":" not in converter:
            raise SchemaRegistryError(
                "Manifest field 'converter' must be import path like 'module:ClassName'"
            )

        name = str(payload.get("name") or "anonymous-adapter")
        version = payload.get("version")
        request_schema = payload.get("request_schema")
        response_schema = payload.get("response_schema")
        metadata = payload.get("metadata") or {}
        manifest_hash = payload.get("hash")
        return cls(
            name=name,
            version=version,
            request_schema=request_schema,
            response_schema=response_schema,
            converter=converter,
            metadata=dict(metadata),
            hash=manifest_hash,
        )


def load_schema_adapter(
    source: str | os.PathLike[str] | Mapping[str, Any],
    *,
    cache_dir: str | os.PathLike[str] | None = None,
    cache_ttl: float = DEFAULT_CACHE_TTL,
    adapter_kwargs: Optional[MutableMapping[str, Any]] = None,
):
    """
    Load and instantiate a schema adapter declared in a manifest.

    Args:
        source: Local path, registry URI, HTTP(S) URL, or manifest dict.
        cache_dir: Override cache directory for downloaded manifests.
        cache_ttl: Seconds to reuse cached manifest content.
        adapter_kwargs: Optional kwargs passed to adapter constructor.
    """

    manifest = (
        AdapterManifest.from_dict(source) if isinstance(source, Mapping) else load_manifest(
            source, cache_dir=cache_dir, cache_ttl=cache_ttl
        )
    )

    adapter_cls = _import_converter(manifest.converter)
    kwargs = dict(adapter_kwargs or {})
    if "manifest" not in kwargs:
        kwargs["manifest"] = manifest
    return adapter_cls(**kwargs)


def load_manifest(
    source: str | os.PathLike[str],
    *,
    cache_dir: str | os.PathLike[str] | None = None,
    cache_ttl: float = DEFAULT_CACHE_TTL,
) -> AdapterManifest:
    """Fetch, cache, and parse an adapter manifest."""

    raw_manifest = _fetch_source(source, cache_dir=cache_dir, cache_ttl=cache_ttl)
    try:
        payload = json.loads(raw_manifest)
    except json.JSONDecodeError as exc:
        raise SchemaRegistryError(f"Manifest is not valid JSON: {exc}") from exc
    return AdapterManifest.from_dict(payload)


def _fetch_source(
    source: str | os.PathLike[str],
    *,
    cache_dir: str | os.PathLike[str] | None = None,
    cache_ttl: float = DEFAULT_CACHE_TTL,
) -> str:
    if isinstance(source, os.PathLike):
        source = os.fspath(source)

    parsed = urlparse(str(source))
    scheme = parsed.scheme.lower()

    if scheme in {"", "file"}:
        path = Path(parsed.path or str(source))
        return path.read_text(encoding="utf-8")

    if scheme == "github":
        resolved = _resolve_github_raw_url(parsed)
        return _fetch_http(resolved, cache_dir=cache_dir, cache_ttl=cache_ttl)

    if scheme in {"http", "https"}:
        return _fetch_http(str(source), cache_dir=cache_dir, cache_ttl=cache_ttl)

    if scheme == "s3":
        return _fetch_s3(parsed)

    raise SchemaRegistryError(f"Unsupported manifest source scheme '{scheme or 'file'}'")


def _fetch_http(
    url: str,
    *,
    cache_dir: str | os.PathLike[str] | None,
    cache_ttl: float,
) -> str:
    cache_file = _cache_file_for(url, cache_dir)
    if cache_file and cache_file.exists():
        max_age = cache_ttl if cache_ttl > 0 else 0
        if max_age <= 0 or (time.time() - cache_file.stat().st_mtime) <= max_age:
            return cache_file.read_text(encoding="utf-8")

    with httpx.Client(timeout=30.0) as client:
        response = client.get(url)
        response.raise_for_status()
        text = response.text

    if cache_file:
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        cache_file.write_text(text, encoding="utf-8")
    return text


def _fetch_s3(parsed) -> str:
    if boto3 is None:
        raise SchemaRegistryError(
            "boto3 is required to fetch S3 manifests; install boto3 or use HTTP/GitHub sources."
        )
    bucket = parsed.netloc
    key = parsed.path.lstrip("/")
    if not bucket or not key:
        raise SchemaRegistryError("s3:// URI must include bucket and key")
    client = boto3.client("s3")
    response = client.get_object(Bucket=bucket, Key=key)
    body = response["Body"].read()
    return body.decode("utf-8")


def _resolve_github_raw_url(parsed) -> str:
    segments = [segment for segment in parsed.path.split("/") if segment]
    if len(segments) < 3:
        raise SchemaRegistryError(
            "github:// URIs must follow github://owner/repo/path/to/file#ref"
        )
    owner, repo, *rest = segments
    ref = parsed.fragment or "main"
    rel_path = "/".join(rest)
    return f"https://raw.githubusercontent.com/{owner}/{repo}/{ref}/{rel_path}"


def _cache_file_for(
    url: str,
    cache_dir: str | os.PathLike[str] | None,
) -> Optional[Path]:
    target_dir = Path(cache_dir or os.getenv(CACHE_ENV_VAR) or Path.home() / ".cache" / "any_agent2agent")
    digest = hashlib.sha256(url.encode("utf-8")).hexdigest()
    return target_dir / f"registry_{digest}.json"


def _import_converter(path: str):
    module_name, attr = _split_import_path(path)
    module = importlib.import_module(module_name)
    try:
        converter_cls = getattr(module, attr)
    except AttributeError as exc:
        raise SchemaRegistryError(
            f"Module '{module_name}' does not define attribute '{attr}' for converter '{path}'"
        ) from exc
    return converter_cls


def _split_import_path(path: str) -> Tuple[str, str]:
    module_name, sep, attr = path.partition(":")
    if not sep or not attr:
        raise SchemaRegistryError(
            f"Converter path '{path}' is invalid. Use 'package.module:ClassName'."
        )
    return module_name, attr


__all__ = [
    "AdapterManifest",
    "SchemaRegistryError",
    "load_manifest",
    "load_schema_adapter",
    "ADAPTER_ENV_VAR",
    "DEFAULT_CACHE_TTL",
]


