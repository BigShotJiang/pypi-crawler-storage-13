"""any_agent2agent - Minimal toolkit for Agent Protocol (Agent2Agent) flows."""

from __future__ import annotations

from .factory import AgentFactory
from .models import AgentMessage
from .adapters import AgentProtocolAdapter
from .server import (
    create_agent_handler,
    create_lambda_handler,
    create_flask_handler,
    create_fastapi_router,
)
from .server_detection import (
    detect_fastapi_app,
    detect_flask_app,
    FASTAPI_ENV_VAR,
    FLASK_ENV_VAR,
)

from .config import ConfigManager, create_agent_config_manager, get_config
from .bedrock_tool import create_bedrock_tool_handler, BedrockResponseBuilder

__all__ = [
    "AgentFactory",
    "AgentMessage",
    "AgentProtocolAdapter",
    "create_agent_handler",
    "create_lambda_handler",
    "create_flask_handler",
    "create_fastapi_router",
    "detect_fastapi_app",
    "detect_flask_app",
    "FASTAPI_ENV_VAR",
    "FLASK_ENV_VAR",
    "ConfigManager",
    "create_agent_config_manager",
    "get_config",
    "create_bedrock_tool_handler",
    "BedrockResponseBuilder",
]

__version__ = "0.1.0"

AgentFactory.register("agent_protocol", AgentProtocolAdapter)

