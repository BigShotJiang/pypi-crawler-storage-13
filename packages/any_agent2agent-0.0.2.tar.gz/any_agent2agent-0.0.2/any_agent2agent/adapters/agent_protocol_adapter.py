"""Adapter for remote agents that implement the Agent Protocol (Agent2Agent)."""

from __future__ import annotations

import json
import logging
import os
from typing import Any, AsyncIterator, Dict, Iterator, Mapping, Optional, Tuple

import httpx

from ..base import BaseAgent
from ..exceptions import AgentAPIError, ConfigurationError
from ..models import AgentMessage
from ..schema_adapters import (
    AgentProtocolSchemaAdapter,
    SchemaAdapter,
    SchemaAdapterError,
)
from ..schema_registry import (
    ADAPTER_ENV_VAR,
    DEFAULT_CACHE_TTL,
    SchemaRegistryError,
    load_schema_adapter,
)

logger = logging.getLogger(__name__)


class AgentProtocolAdapter(BaseAgent):
    """Adapter that communicates with Agent Protocol compliant services."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
        schema_adapter: SchemaAdapter | None = None,
        schema_adapter_source: str | os.PathLike[str] | Mapping[str, object] | None = None,
        schema_adapter_cache_ttl: float | None = None,
    ) -> None:
        if not base_url:
            raise ConfigurationError("AgentProtocolAdapter requires a base_url")
        if schema_adapter and schema_adapter_source:
            raise ConfigurationError("Provide either 'schema_adapter' or 'schema_adapter_source', not both.")

        super().__init__(api_key=api_key, timeout=timeout)
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(timeout=timeout)
        self._async_client: httpx.AsyncClient | None = None
        self._headers = headers.copy() if headers else {}
        if api_key and "Authorization" not in self._headers:
            self._headers["Authorization"] = f"Bearer {api_key}"
        self._connected = True  # stateless HTTP endpoint
        self._schema_adapter = self._resolve_schema_adapter(
            schema_adapter,
            schema_adapter_source or os.getenv(ADAPTER_ENV_VAR),
            cache_ttl=schema_adapter_cache_ttl,
        )

    def connect(self) -> bool:
        """Agent Protocol endpoints are stateless; mark as connected."""
        self._connected = True
        return True

    def send(self, prompt: str) -> AgentMessage:
        self._ensure_connected()
        self._append_user_message(prompt)

        try:
            payload = self._schema_adapter.to_remote_request(self._history)
        except SchemaAdapterError as exc:
            raise AgentAPIError(f"Schema adapter failed to serialize request: {exc}") from exc
        try:
            response = self._client.post(
                f"{self.base_url}/v1/exchange",
                json=payload,
                headers=self._headers,
            )
            response.raise_for_status()
            data = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise AgentAPIError(f"Agent Protocol request failed: {exc}") from exc

        return self._append_from_payload(data)

    def stream(self, prompt: str) -> Iterator[str]:
        self._ensure_connected()
        self._append_user_message(prompt)

        try:
            payload = self._schema_adapter.to_remote_request(self._history)
        except SchemaAdapterError as exc:
            raise AgentAPIError(f"Schema adapter failed to serialize request: {exc}") from exc

        collected_chunks: list[str] = []
        last_metadata: dict[str, object] = {}

        try:
            with self._client.stream(
                "POST",
                f"{self.base_url}/v1/exchange",
                json=payload,
                headers=self._headers,
            ) as response:
                response.raise_for_status()
                for chunk in response.iter_lines():
                    text, metadata = self._decode_stream_chunk(chunk)
                    if text is None:
                        continue
                    collected_chunks.append(text)
                    if metadata:
                        last_metadata = dict(metadata)
                    yield text
        except httpx.HTTPError as exc:
            raise AgentAPIError(f"Agent Protocol streaming request failed: {exc}") from exc

        final_content = "".join(collected_chunks).strip()
        if final_content:
            self._append_assistant_message(final_content, metadata=last_metadata)

    async def async_send(self, prompt: str) -> AgentMessage:
        self._ensure_connected()
        self._append_user_message(prompt)

        try:
            payload = self._schema_adapter.to_remote_request(self._history)
        except SchemaAdapterError as exc:
            raise AgentAPIError(f"Schema adapter failed to serialize request: {exc}") from exc

        client = self._get_async_client()
        try:
            response = await client.post(
                f"{self.base_url}/v1/exchange",
                json=payload,
                headers=self._headers,
            )
            response.raise_for_status()
            data = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise AgentAPIError(f"Agent Protocol request failed: {exc}") from exc

        return self._append_from_payload(data)

    async def async_stream(self, prompt: str) -> AsyncIterator[str]:
        self._ensure_connected()
        self._append_user_message(prompt)

        try:
            payload = self._schema_adapter.to_remote_request(self._history)
        except SchemaAdapterError as exc:
            raise AgentAPIError(f"Schema adapter failed to serialize request: {exc}") from exc

        collected_chunks: list[str] = []
        last_metadata: dict[str, object] = {}

        client = self._get_async_client()
        try:
            async with client.stream(
                "POST",
                f"{self.base_url}/v1/exchange",
                json=payload,
                headers=self._headers,
            ) as response:
                response.raise_for_status()
                async for chunk in response.aiter_lines():
                    text, metadata = self._decode_stream_chunk(chunk)
                    if text is None:
                        continue
                    collected_chunks.append(text)
                    if metadata:
                        last_metadata = dict(metadata)
                    yield text
        except httpx.HTTPError as exc:
            raise AgentAPIError(f"Agent Protocol streaming request failed: {exc}") from exc

        final_content = "".join(collected_chunks).strip()
        if final_content:
            self._append_assistant_message(final_content, metadata=last_metadata)

    def close(self) -> None:
        self._client.close()

    async def aclose(self) -> None:
        self._client.close()
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None

    def _resolve_schema_adapter(
        self,
        adapter: SchemaAdapter | None,
        source: str | os.PathLike[str] | Mapping[str, object] | None,
        *,
        cache_ttl: float | None,
    ) -> SchemaAdapter:
        if adapter:
            return adapter

        if source:
            try:
                return load_schema_adapter(source, cache_ttl=cache_ttl or DEFAULT_CACHE_TTL)
            except SchemaRegistryError as exc:  # pragma: no cover - configuration issue
                raise ConfigurationError(f"Failed to load schema adapter from '{source}': {exc}") from exc
        return AgentProtocolSchemaAdapter()

    def _append_from_payload(self, payload: Mapping[str, Any]) -> AgentMessage:
        try:
            message = self._schema_adapter.parse_remote_response(payload)
        except SchemaAdapterError as exc:
            raise AgentAPIError(f"Schema adapter failed to parse response: {exc}") from exc
        return self._append_assistant_message(message.content, metadata=message.metadata)

    def _decode_stream_chunk(self, chunk: str | bytes | None) -> Tuple[str | None, Dict[str, Any]]:
        if chunk is None:
            return None, {}

        raw = chunk.decode("utf-8") if isinstance(chunk, bytes) else chunk
        if raw is None:
            return None, {}

        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            if not raw.strip():
                return None, {}
            return raw, {}

        try:
            message = self._schema_adapter.parse_remote_response(data)
            raw_text = self._extract_raw_text(data)
            content = raw_text if raw_text is not None else message.content
            return content, dict(message.metadata or {})
        except SchemaAdapterError:
            delta = data.get("delta") or data.get("content")
            if isinstance(delta, list):
                delta = "".join(part for part in delta if isinstance(part, str))
            if isinstance(delta, dict):
                delta = delta.get("text")
            if isinstance(delta, str):
                return delta, dict(data.get("metadata") or {})
        return None, {}

    def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(timeout=self.timeout)
        return self._async_client

    @staticmethod
    def _extract_raw_text(payload: Mapping[str, Any]) -> str | None:
        messages = payload.get("messages")
        if not isinstance(messages, list) or not messages:
            return None
        assistant = messages[-1]
        content = assistant.get("content")
        if isinstance(content, list):
            parts = []
            for block in content:
                if isinstance(block, Mapping) and block.get("type") == "text":
                    text_value = block.get("text")
                    if isinstance(text_value, str):
                        parts.append(text_value)
            if parts:
                return "".join(parts)
        elif isinstance(content, str):
            return content
        return None

