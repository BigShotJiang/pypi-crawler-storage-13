"""Server-side utilities for exposing SDK-compatible agents."""

from __future__ import annotations

import json
import logging
import os
from typing import Any, Callable, Dict, Iterable, Iterator, List, Literal, Mapping, Optional, Protocol, Set

from .models import AgentMessage
from .schema_adapters import (
    AgentProtocolSchemaAdapter,
    SchemaAdapter,
    SchemaAdapterError,
)
from .schema_registry import (
    ADAPTER_ENV_VAR,
    DEFAULT_CACHE_TTL,
    SchemaRegistryError,
    load_schema_adapter,
)
from .server_detection import detect_fastapi_app, detect_flask_app

_LOGGER = logging.getLogger(__name__)


class AgentHandler(Protocol):
    """Callable that accepts a list of AgentMessage objects and returns content/metadata."""

    def __call__(self, messages: List[AgentMessage]) -> Any: ...


def create_agent_handler(
    agent_logic: AgentHandler,
    *,
    default_metadata: Optional[Dict[str, Any]] = None,
    protocol: Literal["bridge", "agent_protocol"] = "bridge",
    schema_adapter: SchemaAdapter | None = None,
    schema_adapter_source: str | os.PathLike[str] | Mapping[str, Any] | None = None,
    schema_adapter_cache_ttl: float | None = None,
) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    """
    Generate a handler that accepts SDK-formatted requests.

    Args:
        agent_logic: function receiving List[AgentMessage] and returning either:
            - str (content)
            - dict with keys: content, metadata
            - tuple (content, metadata)
        default_metadata: metadata to merge into responses.
    """

    handler, _ = _build_handler_components(
        agent_logic,
        default_metadata=default_metadata,
        protocol=protocol,
        schema_adapter=schema_adapter,
        schema_adapter_source=schema_adapter_source,
        schema_adapter_cache_ttl=schema_adapter_cache_ttl,
        enable_streaming=False,
        streaming_agent_logic=None,
    )
    return handler


def create_lambda_handler(
    agent_logic: AgentHandler,
    *,
    protocol: Literal["bridge", "agent_protocol"] = "bridge",
    streaming: bool = False,
    streaming_agent_logic: AgentHandler | None = None,
    schema_adapter: SchemaAdapter | None = None,
    schema_adapter_source: str | os.PathLike[str] | Mapping[str, Any] | None = None,
    schema_adapter_cache_ttl: float | None = None,
    **handler_kwargs: Any,
):
    """
    Wrap agent logic with AWS Lambda-friendly signature.

    Usage:
        lambda_handler = create_lambda_handler(my_agent_logic)

    When `streaming=True`, callers can set `{"stream": true}` on the payload to
    receive newline-delimited JSON chunks under the `"stream"` key, and the
    returned handler exposes a `.stream(payload)` helper that yields those chunks.
    """

    base_handler, streaming_handler = _build_handler_components(
        agent_logic,
        protocol=protocol,
        schema_adapter=schema_adapter,
        schema_adapter_source=schema_adapter_source,
        schema_adapter_cache_ttl=schema_adapter_cache_ttl,
        enable_streaming=streaming,
        streaming_agent_logic=streaming_agent_logic,
        **handler_kwargs,
    )

    def lambda_handler(event: Dict[str, Any], _context: Any) -> Dict[str, Any]:
        if isinstance(event, str):
            event_data = json.loads(event)
        else:
            event_data = event
        if streaming_handler and _should_stream(event_data):
            return {"stream": list(streaming_handler(event_data))}
        return base_handler(event_data)

    if streaming_handler:
        setattr(lambda_handler, "stream", streaming_handler)

    return lambda_handler


def create_flask_handler(
    agent_logic: AgentHandler,
    *,
    protocol: Literal["bridge", "agent_protocol"] = "bridge",
    route_path: str = "/agent/exchange",
    methods: Optional[Iterable[str]] = None,
    endpoint: str = "agent_protocol_exchange",
    streaming: bool = False,
    streaming_agent_logic: AgentHandler | None = None,
    auto_register: bool = True,
    flask_app: Any = None,
    schema_adapter: SchemaAdapter | None = None,
    schema_adapter_source: str | os.PathLike[str] | Mapping[str, Any] | None = None,
    schema_adapter_cache_ttl: float | None = None,
    **handler_kwargs: Any,
):
    """
    Flask route handler factory.

    Example:
        app = Flask(__name__)
        agent_route = create_flask_handler(my_logic)
        app.post("/chat")(agent_route)
    """

    try:
        from flask import Response, jsonify, request
    except ImportError:  # pragma: no cover
        raise RuntimeError("Flask is not installed. Run `pip install flask`.") from None

    base_handler, streaming_handler = _build_handler_components(
        agent_logic,
        protocol=protocol,
        schema_adapter=schema_adapter,
        schema_adapter_source=schema_adapter_source,
        schema_adapter_cache_ttl=schema_adapter_cache_ttl,
        enable_streaming=streaming,
        streaming_agent_logic=streaming_agent_logic,
        **handler_kwargs,
    )

    def flask_route():
        payload = request.get_json(force=True, silent=False) or {}
        response = base_handler(payload)
        return jsonify(response)

    if streaming_handler:
        stream_suffix = f"{route_path.rstrip('/')}/stream"

        def flask_stream_route():
            payload = request.get_json(force=True, silent=False) or {}
            return Response(
                _json_line_stream(streaming_handler(payload)),
                mimetype="text/event-stream",
            )

        setattr(flask_route, "stream", flask_stream_route)

    if auto_register:
        target_app = flask_app
        source = "explicit"
        if target_app is None:
            detected = detect_flask_app()
            if detected is not None:
                target_app = detected.app
                source = detected.source
        if target_app is not None:
            actual_methods = tuple(methods or ("POST",))
            if endpoint in getattr(target_app, "view_functions", {}):
                _LOGGER.debug(
                    "Flask endpoint '%s' already registered on %s",
                    endpoint,
                    source,
                )
            else:
                registered_ids: Set[int] = getattr(
                    flask_route, "_a2a_registered_app_ids", set()
                )
                app_id = id(target_app)
                if app_id in registered_ids:
                    _LOGGER.debug(
                        "Flask endpoint '%s' already attached to detected app",
                        route_path,
                    )
                else:
                    target_app.add_url_rule(
                        route_path,
                        endpoint=endpoint,
                        view_func=flask_route,
                        methods=list(actual_methods),
                    )
                    registered_ids.add(app_id)
                    setattr(flask_route, "_a2a_registered_app_ids", registered_ids)
                    setattr(flask_route, "_a2a_auto_registered", True)
                    setattr(flask_route, "_a2a_auto_registered_source", source)
                    _LOGGER.debug(
                        "Auto-registered Flask endpoint '%s' via %s",
                        route_path,
                        source,
                    )
                    if streaming_handler:
                        target_app.add_url_rule(
                            stream_suffix,
                            endpoint=f"{endpoint}_stream",
                            view_func=flask_route.stream,
                            methods=list(actual_methods),
                    )

    return flask_route


def create_fastapi_router(
    agent_logic: AgentHandler,
    *,
    protocol: Literal["bridge", "agent_protocol"] = "bridge",
    route_path: str = "/agent",
    streaming: bool = False,
    streaming_agent_logic: AgentHandler | None = None,
    auto_register: bool = True,
    fastapi_app: Any = None,
    schema_adapter: SchemaAdapter | None = None,
    schema_adapter_source: str | os.PathLike[str] | Mapping[str, Any] | None = None,
    schema_adapter_cache_ttl: float | None = None,
    **handler_kwargs: Any,
):
    """
    FastAPI router factory.

    Returns a tuple of (router, endpoint_function) for flexibility.
    """

    try:
        from fastapi import APIRouter, HTTPException
        from fastapi.responses import StreamingResponse
        from pydantic import BaseModel
    except ImportError:  # pragma: no cover
        raise RuntimeError("FastAPI is not installed. Run `pip install fastapi`.") from None

    class MessageModel(BaseModel):
        id: Optional[str] = None
        role: str
        content: str
        metadata: Optional[Dict[str, Any]] = None
        timestamp: Optional[float] = None

    class AgentRequest(BaseModel):
        messages: List[MessageModel]
        metadata: Optional[Dict[str, Any]] = None

    router = APIRouter()
    base_handler, streaming_handler = _build_handler_components(
        agent_logic,
        protocol=protocol,
        schema_adapter=schema_adapter,
        schema_adapter_source=schema_adapter_source,
        schema_adapter_cache_ttl=schema_adapter_cache_ttl,
        enable_streaming=streaming,
        streaming_agent_logic=streaming_agent_logic,
        **handler_kwargs,
    )

    @router.post(route_path)
    async def agent_endpoint(request: AgentRequest):
        try:
            payload = request.model_dump()
            return base_handler(payload)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    if streaming_handler:
        stream_path = f"{route_path.rstrip('/')}/stream"

        @router.post(stream_path)
        async def agent_stream_endpoint(request: AgentRequest):
            try:
                payload = request.model_dump()
            except ValueError as exc:  # pragma: no cover - pydantic guard
                raise HTTPException(status_code=400, detail=str(exc)) from exc
            return StreamingResponse(
                _json_line_stream(streaming_handler(payload)),
                media_type="text/event-stream",
            )

    if auto_register:
        target_app = fastapi_app
        source = "explicit"
        if target_app is None:
            detected = detect_fastapi_app()
            if detected is not None:
                target_app = detected.app
                source = detected.source
        if target_app is not None:
            registered_ids: Set[int] = getattr(router, "_a2a_registered_app_ids", set())
            app_id = id(target_app)
            if app_id in registered_ids:
                _LOGGER.debug(
                    "FastAPI router '%s' already registered on detected app",
                    route_path,
                )
            else:
                target_app.include_router(router)
                registered_ids.add(app_id)
                setattr(router, "_a2a_registered_app_ids", registered_ids)
                setattr(router, "_a2a_auto_registered", True)
                setattr(router, "_a2a_auto_registered_source", source)
                _LOGGER.debug(
                    "Auto-registered FastAPI router '%s' via %s",
                    route_path,
                    source,
                )

    return router


__all__ = [
    "create_agent_handler",
    "create_lambda_handler",
    "create_flask_handler",
    "create_fastapi_router",
]


def _normalize_handler_result(result: Any) -> tuple[str, Dict[str, Any]]:
    if isinstance(result, tuple):
        content, metadata = result
    elif isinstance(result, dict) and "content" in result:
        content = result["content"]
        metadata = result.get("metadata", {})
    else:
        content = str(result)
        metadata = {}
    if not isinstance(metadata, dict):
        metadata = {"metadata": metadata}
    return content, metadata


def _resolve_schema_adapter(
    adapter: SchemaAdapter | None,
    source: str | os.PathLike[str] | Mapping[str, Any] | None,
    *,
    cache_ttl: float | None,
) -> SchemaAdapter:
    if adapter:
        return adapter

    if source:
        try:
            return load_schema_adapter(source, cache_ttl=cache_ttl or DEFAULT_CACHE_TTL)
        except SchemaRegistryError as exc:  # pragma: no cover - configuration issue
            raise ValueError(f"Unable to load schema adapter '{source}': {exc}") from exc
    return AgentProtocolSchemaAdapter()


def _build_handler_components(
    agent_logic: AgentHandler,
    *,
    default_metadata: Optional[Dict[str, Any]] = None,
    protocol: Literal["bridge", "agent_protocol"],
    schema_adapter: SchemaAdapter | None,
    schema_adapter_source: str | os.PathLike[str] | Mapping[str, Any] | None,
    schema_adapter_cache_ttl: float | None,
    enable_streaming: bool,
    streaming_agent_logic: AgentHandler | None,
) -> tuple[Callable[[Dict[str, Any]], Dict[str, Any]], Optional[Callable[[Mapping[str, Any]], Iterator[Mapping[str, Any]]]]]:
    default_metadata = default_metadata or {}
    provider_fallback = "agent_protocol" if protocol == "agent_protocol" else "custom_agent"
    adapter = None
    if protocol == "agent_protocol":
        adapter = _resolve_schema_adapter(
            schema_adapter,
            schema_adapter_source or os.getenv(ADAPTER_ENV_VAR),
            cache_ttl=schema_adapter_cache_ttl,
        )
    base_handler = _make_base_handler(
        agent_logic,
        protocol=protocol,
        adapter=adapter,
        default_metadata=default_metadata,
        provider_fallback=provider_fallback,
    )
    streaming_handler = None
    if enable_streaming:
        streaming_handler = _create_streaming_handler(
            streaming_agent_logic or agent_logic,
            protocol=protocol,
            adapter=adapter,
            default_metadata=default_metadata,
            provider_fallback=provider_fallback,
        )
    return base_handler, streaming_handler


def _make_base_handler(
    agent_logic: AgentHandler,
    *,
    protocol: Literal["bridge", "agent_protocol"],
    adapter: SchemaAdapter | None,
    default_metadata: Dict[str, Any],
    provider_fallback: str,
) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    def handler(payload: Dict[str, Any]) -> Dict[str, Any]:
        messages = _parse_messages_from_payload(payload, protocol=protocol, adapter=adapter)
        result = agent_logic(messages)
        content, metadata = _normalize_handler_result(result)

        final_metadata = {**default_metadata, **metadata}
        final_metadata.setdefault("provider", provider_fallback)

        if protocol == "agent_protocol":
            assert adapter is not None
            return adapter.build_remote_response(content, final_metadata)
        return {"content": content, "metadata": final_metadata}

    return handler


def _parse_messages_from_payload(
    payload: Mapping[str, Any],
    *,
    protocol: Literal["bridge", "agent_protocol"],
    adapter: SchemaAdapter | None,
) -> List[AgentMessage]:
    if protocol == "agent_protocol":
        if adapter is None:  # pragma: no cover - guard for type checkers
            raise RuntimeError("Schema adapter missing for agent_protocol mode")
        try:
            return adapter.parse_remote_request(payload)
        except SchemaAdapterError as exc:
            raise ValueError(str(exc)) from exc

    messages_payload = payload.get("messages")
    if not isinstance(messages_payload, list):
        raise ValueError("Payload must include 'messages' list")
    return [AgentMessage.from_dict(msg) for msg in messages_payload]


def _create_streaming_handler(
    agent_logic: AgentHandler,
    *,
    protocol: Literal["bridge", "agent_protocol"],
    adapter: SchemaAdapter | None,
    default_metadata: Dict[str, Any],
    provider_fallback: str,
) -> Callable[[Mapping[str, Any]], Iterator[Mapping[str, Any]]]:
    def streaming_handler(payload: Mapping[str, Any]) -> Iterator[Mapping[str, Any]]:
        messages = _parse_messages_from_payload(payload, protocol=protocol, adapter=adapter)
        iterator = _ensure_stream_iterator(agent_logic(messages))
        yield from _generate_stream_payloads(
            iterator,
            protocol=protocol,
            adapter=adapter,
            default_metadata=default_metadata,
            provider_fallback=provider_fallback,
        )

    return streaming_handler


def _generate_stream_payloads(
    iterator: Iterator[Any],
    *,
    protocol: Literal["bridge", "agent_protocol"],
    adapter: SchemaAdapter | None,
    default_metadata: Dict[str, Any],
    provider_fallback: str,
) -> Iterator[Mapping[str, Any]]:
    iterator = iter(iterator)
    try:
        current = next(iterator)
    except StopIteration:
        return

    for next_chunk in iterator:
        yield _format_stream_chunk(
            current,
            status="in_progress",
            protocol=protocol,
            adapter=adapter,
            default_metadata=default_metadata,
            provider_fallback=provider_fallback,
        )
        current = next_chunk

    yield _format_stream_chunk(
        current,
        status="completed",
        protocol=protocol,
        adapter=adapter,
        default_metadata=default_metadata,
        provider_fallback=provider_fallback,
    )


def _format_stream_chunk(
    chunk: Any,
    *,
    status: str,
    protocol: Literal["bridge", "agent_protocol"],
    adapter: SchemaAdapter | None,
    default_metadata: Dict[str, Any],
    provider_fallback: str,
) -> Mapping[str, Any]:
    content, metadata = _normalize_stream_chunk(chunk)
    final_metadata = {**default_metadata, **metadata}
    final_metadata.setdefault("provider", provider_fallback)

    if protocol == "agent_protocol":
        if adapter is None:  # pragma: no cover - guard
            raise RuntimeError("Schema adapter missing for agent_protocol streaming")
        return adapter.build_remote_response(content, final_metadata, status=status)
    return {"content": content, "metadata": final_metadata, "status": status}


def _normalize_stream_chunk(result: Any) -> tuple[str, Dict[str, Any]]:
    if isinstance(result, tuple):
        if len(result) != 2:
            raise ValueError("Streaming tuples must be (content, metadata)")
        content, metadata = result
    elif isinstance(result, dict) and "content" in result:
        content = result["content"]
        metadata = result.get("metadata", {})
    else:
        content = result
        metadata = {}

    if not isinstance(metadata, dict):
        metadata = {"metadata": metadata}

    return str(content), dict(metadata)


def _ensure_stream_iterator(result: Any) -> Iterator[Any]:
    if isinstance(result, (str, bytes)):
        raise ValueError("Streaming agent logic must yield chunks, not plain strings")
    if isinstance(result, Mapping):
        raise ValueError("Streaming agent logic must yield text/tuple chunks, not dict iterables")
    try:
        iterator = iter(result)
    except TypeError as exc:  # pragma: no cover - defensive
        raise ValueError("Streaming agent logic must return an iterator or generator") from exc
    return iterator


def _should_stream(payload: Mapping[str, Any]) -> bool:
    stream_flag = payload.get("stream")
    if isinstance(stream_flag, bool):
        return stream_flag
    if isinstance(stream_flag, str):
        return stream_flag.lower() in {"1", "true", "yes", "on"}
    return False


def _json_line_stream(chunks: Iterable[Mapping[str, Any]]) -> Iterator[str]:
    for chunk in chunks:
        yield json.dumps(chunk) + "\n"

