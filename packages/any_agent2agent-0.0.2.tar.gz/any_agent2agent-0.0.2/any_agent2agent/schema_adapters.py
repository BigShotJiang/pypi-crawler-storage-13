"""Common schema adapter interface plus the default Agent Protocol implementation."""

from __future__ import annotations

import abc
from typing import Any, Dict, List, Mapping, Sequence

from .models import AgentMessage
from .schema_registry import AdapterManifest


class SchemaAdapterError(RuntimeError):
    """Raised when schema conversion fails."""


class SchemaAdapter(abc.ABC):
    """Abstract translator between AgentMessage objects and remote payloads."""

    def __init__(self, *, manifest: AdapterManifest | None = None) -> None:
        self.manifest = manifest

    @abc.abstractmethod
    def to_remote_request(self, history: Sequence[AgentMessage]) -> Mapping[str, Any]:
        """Serialize conversation history to the remote provider schema."""

    @abc.abstractmethod
    def parse_remote_request(self, payload: Mapping[str, Any]) -> List[AgentMessage]:
        """Parse an inbound remote payload into AgentMessage objects."""

    @abc.abstractmethod
    def parse_remote_response(self, payload: Mapping[str, Any]) -> AgentMessage:
        """Parse a response payload into a single assistant AgentMessage."""

    @abc.abstractmethod
    def build_remote_response(
        self,
        content: str,
        metadata: Mapping[str, Any],
        *,
        status: str = "completed",
    ) -> Mapping[str, Any]:
        """Produce a remote-compatible response body."""


class AgentProtocolSchemaAdapter(SchemaAdapter):
    """Default adapter that speaks the Agent Protocol JSON schema."""

    def to_remote_request(self, history: Sequence[AgentMessage]) -> Mapping[str, Any]:
        messages = []
        for msg in history:
            messages.append(
                {
                    "role": msg.role,
                    "content": [{"type": "text", "text": msg.content}],
                    "metadata": msg.metadata,
                }
            )
        return {"messages": messages}

    def parse_remote_request(self, payload: Mapping[str, Any]) -> List[AgentMessage]:
        messages_payload = payload.get("messages")
        if not isinstance(messages_payload, list) or not messages_payload:
            raise SchemaAdapterError("Agent Protocol payload missing non-empty 'messages'")

        parsed: List[AgentMessage] = []
        for entry in messages_payload:
            role = entry.get("role")
            if role not in {"user", "assistant", "system", "tool"}:
                raise SchemaAdapterError(f"Unsupported Agent Protocol role '{role}'")
            text = _extract_text(entry)
            if not text:
                raise SchemaAdapterError("Agent Protocol message missing text content")
            metadata = entry.get("metadata") or {}
            parsed.append(AgentMessage(role=role, content=text, metadata=metadata))
        return parsed

    def parse_remote_response(self, payload: Mapping[str, Any]) -> AgentMessage:
        messages_payload = payload.get("messages")
        if not isinstance(messages_payload, list) or not messages_payload:
            raise SchemaAdapterError("Agent Protocol response missing 'messages'")

        assistant = messages_payload[-1]
        if assistant.get("role") != "assistant":
            raise SchemaAdapterError("Agent Protocol response must end with assistant role")

        text = _extract_text(assistant)
        if not text:
            raise SchemaAdapterError("Agent Protocol assistant message missing text blocks")

        metadata = assistant.get("metadata") or {}
        return AgentMessage(role="assistant", content=text, metadata=metadata)

    def build_remote_response(
        self,
        content: str,
        metadata: Mapping[str, Any],
        *,
        status: str = "completed",
    ) -> Mapping[str, Any]:
        return {
            "messages": [
                {
                    "role": "assistant",
                    "content": [{"type": "text", "text": content}],
                    "metadata": dict(metadata),
                }
            ],
            "status": status,
        }


def _extract_text(entry: Mapping[str, Any]) -> str:
    content_blocks = entry.get("content")
    text_values: List[str] = []
    if isinstance(content_blocks, list):
        for block in content_blocks:
            if isinstance(block, Mapping) and block.get("type") == "text":
                text = block.get("text")
                if isinstance(text, str):
                    text_values.append(text)
    elif isinstance(content_blocks, str):
        text_values.append(content_blocks)
    combined = "\n".join(part.strip() for part in text_values if part.strip())
    return combined.strip()


__all__ = [
    "AgentProtocolSchemaAdapter",
    "SchemaAdapter",
    "SchemaAdapterError",
]


