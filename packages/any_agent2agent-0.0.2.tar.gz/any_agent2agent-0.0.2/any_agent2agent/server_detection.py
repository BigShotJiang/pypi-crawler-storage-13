"""Helpers for detecting existing FastAPI/Flask apps."""

from __future__ import annotations

import importlib
import logging
import os
import sys
from dataclasses import dataclass
from typing import Any, Iterable, Optional, Tuple, Type

FASTAPI_ENV_VAR = "A2A_FASTAPI_APP"
FLASK_ENV_VAR = "A2A_FLASK_APP"

_LOGGER = logging.getLogger(__name__)
_APP_ATTRS: Tuple[str, ...] = ("app", "application")
_SKIP_VALUES = {"0", "false", "off", "skip", "disabled", "none"}


@dataclass
class DetectedServerApp:
    """Metadata describing a detected server instance."""

    framework: str
    app: Any
    source: str


def detect_fastapi_app() -> Optional[DetectedServerApp]:
    """Return an existing FastAPI app if one is already imported."""

    fastapi_cls = _import_symbol("fastapi", "FastAPI")
    if fastapi_cls is None:
        return None
    return _detect_app_instance(
        framework="fastapi",
        expected_type=fastapi_cls,
        env_var=FASTAPI_ENV_VAR,
    )


def detect_flask_app() -> Optional[DetectedServerApp]:
    """Return an existing Flask app if one is already imported."""

    flask_cls = _import_symbol("flask", "Flask")
    if flask_cls is None:
        return None
    return _detect_app_instance(
        framework="flask",
        expected_type=flask_cls,
        env_var=FLASK_ENV_VAR,
    )


def _detect_app_instance(
    *,
    framework: str,
    expected_type: Type[Any],
    env_var: str,
) -> Optional[DetectedServerApp]:
    env_value = os.getenv(env_var)
    if env_value is not None:
        env_value = env_value.strip()
        if not env_value or env_value.lower() in _SKIP_VALUES:
            _LOGGER.debug("%s set to skip detection (%s)", env_var, env_value)
            return None
        app = _load_object(env_value)
        if app is None:
            return None
        if isinstance(app, expected_type):
            return DetectedServerApp(
                framework=framework,
                app=app,
                source=f"{env_var}={env_value}",
            )
        _LOGGER.debug(
            "%s resolved to %r but is not a %s app",
            env_var,
            app,
            framework,
        )
        return None

    # Fallback: scan imported modules for common attributes.
    for module_name, module in reversed(list(sys.modules.items())):
        if module is None:
            continue
        for attr_name in _APP_ATTRS:
            candidate = getattr(module, attr_name, None)
            if isinstance(candidate, expected_type):
                return DetectedServerApp(
                    framework=framework,
                    app=candidate,
                    source=f"{module_name}.{attr_name}",
                )
    return None


def _import_symbol(module_path: str, attr_name: str) -> Optional[Type[Any]]:
    try:
        module = importlib.import_module(module_path)
    except ImportError:
        return None
    return getattr(module, attr_name, None)


def _load_object(spec: str) -> Optional[Any]:
    module_path, sep, attr_path = spec.partition(":")
    if not sep or not attr_path:
        _LOGGER.debug("Invalid app spec %r (expected module:attr)", spec)
        return None

    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        _LOGGER.debug("Failed importing %s: %s", module_path, exc)
        return None

    obj: Any = module
    for part in attr_path.split("."):
        try:
            obj = getattr(obj, part)
        except AttributeError:
            _LOGGER.debug("Attribute %s missing in %s", part, spec)
            return None
    return obj


__all__ = [
    "DetectedServerApp",
    "detect_fastapi_app",
    "detect_flask_app",
    "FASTAPI_ENV_VAR",
    "FLASK_ENV_VAR",
]

