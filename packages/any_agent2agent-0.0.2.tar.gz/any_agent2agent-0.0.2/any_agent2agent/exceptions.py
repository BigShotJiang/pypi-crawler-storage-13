"""Custom exceptions for the any_agent2agent package."""

from __future__ import annotations


class AgentProtocolError(Exception):
    """Base exception for package-specific errors."""


class ConfigurationError(AgentProtocolError):
    """Raised when an invalid configuration is supplied."""


class AgentConnectionError(AgentProtocolError):
    """Raised when a provider connection cannot be established."""


class AgentTimeoutError(AgentProtocolError):
    """Raised when a provider operation exceeds the configured timeout."""


class AgentAPIError(AgentProtocolError):
    """Raised when the upstream API responds with an error."""

