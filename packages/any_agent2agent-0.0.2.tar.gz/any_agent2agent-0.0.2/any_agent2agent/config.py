"""Configuration and secrets management with AWS Secrets Manager integration."""

from __future__ import annotations

import json
import logging
import os
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Try to import boto3, but don't fail if it's not available
try:
    import boto3
    from botocore.exceptions import ClientError, NoCredentialsError
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False
    logger.debug("boto3 not available, AWS Secrets Manager will be disabled")


class ConfigManager:
    """
    Manages configuration with AWS Secrets Manager integration.
    
    Priority order:
    1. AWS Secrets Manager (if available and configured)
    2. Local environment variables
    
    Usage:
        config = ConfigManager(secret_name="my-app/agents")
        
        # Get single value
        api_key = config.get("OPENAI_API_KEY")
        
        # Get multiple values
        values = config.get_many(["OPENAI_API_KEY", "ASSISTANT_ID"])
        
        # Get all secrets
        all_config = config.get_all()
    
    AWS Credentials:
        AWS credentials are loaded from environment variables:
        - AWS_ACCESS_KEY_ID
        - AWS_SECRET_ACCESS_KEY
        - AWS_SESSION_TOKEN (optional)
        - AWS_DEFAULT_REGION (optional, defaults to us-east-1)
    """

    def __init__(
        self,
        secret_name: Optional[str] = None,
        region_name: Optional[str] = None,
        cache_secrets: bool = True,
    ) -> None:
        """
        Initialize ConfigManager.
        
        Args:
            secret_name: Name of the AWS Secrets Manager secret
            region_name: AWS region (defaults to AWS_DEFAULT_REGION env var or us-east-1)
            cache_secrets: Whether to cache secrets after first retrieval
        """
        self.secret_name = secret_name
        self.region_name = region_name or os.getenv("AWS_DEFAULT_REGION", "us-east-1")
        self.cache_secrets = cache_secrets
        self._secrets_cache: Optional[Dict[str, Any]] = None
        self._client = None

        # Check if AWS is available and configured
        self._aws_available = self._check_aws_availability()

    def _check_aws_availability(self) -> bool:
        """Check if AWS Secrets Manager is available and configured."""
        if not BOTO3_AVAILABLE:
            logger.info("boto3 not installed, using environment variables only")
            return False

        if not self.secret_name:
            logger.info("No secret_name provided, using environment variables only")
            return False

        # Check if AWS credentials are available
        if not os.getenv("AWS_ACCESS_KEY_ID"):
            logger.info("AWS_ACCESS_KEY_ID not found, using environment variables only")
            return False

        return True

    def _get_secrets_manager_client(self):
        """Lazy initialization of AWS Secrets Manager client."""
        if self._client is None and self._aws_available:
            try:
                self._client = boto3.client(
                    "secretsmanager",
                    region_name=self.region_name,
                    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
                    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
                    aws_session_token=os.getenv("AWS_SESSION_TOKEN"),
                )
                logger.info(
                    "AWS Secrets Manager client initialized for region %s",
                    self.region_name,
                )
            except Exception as exc:
                logger.warning("Failed to initialize AWS client: %s", exc)
                self._aws_available = False

        return self._client

    def _fetch_from_secrets_manager(self) -> Optional[Dict[str, Any]]:
        """Fetch secrets from AWS Secrets Manager."""
        if not self._aws_available:
            return None

        # Return cached secrets if available
        if self.cache_secrets and self._secrets_cache is not None:
            return self._secrets_cache

        client = self._get_secrets_manager_client()
        if not client:
            return None

        try:
            logger.info("Fetching secrets from AWS Secrets Manager: %s", self.secret_name)
            response = client.get_secret_value(SecretId=self.secret_name)

            # Parse the secret string (usually JSON)
            if "SecretString" in response:
                secrets = json.loads(response["SecretString"])
                logger.info("Successfully retrieved %d secrets from AWS", len(secrets))

                # Cache if enabled
                if self.cache_secrets:
                    self._secrets_cache = secrets

                return secrets
            else:
                logger.warning("Secret has no SecretString field")
                return None

        except ClientError as exc:
            error_code = exc.response["Error"]["Code"]
            if error_code == "ResourceNotFoundException":
                logger.warning(
                    "Secret '%s' not found in AWS Secrets Manager, falling back to env vars",
                    self.secret_name,
                )
            elif error_code == "AccessDeniedException":
                logger.warning(
                    "Access denied to secret '%s', falling back to env vars",
                    self.secret_name,
                )
            else:
                logger.warning(
                    "Error fetching secret from AWS: %s, falling back to env vars",
                    exc,
                )
            return None

        except NoCredentialsError:
            logger.warning("AWS credentials not configured, falling back to env vars")
            self._aws_available = False
            return None

        except json.JSONDecodeError as exc:
            logger.error("Failed to parse secret JSON: %s", exc)
            return None

        except Exception as exc:
            logger.error("Unexpected error fetching secrets: %s", exc)
            return None

    def get(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """
        Get a configuration value.
        
        Priority:
        1. AWS Secrets Manager (if configured)
        2. Environment variable
        3. Default value
        
        Args:
            key: Configuration key name
            default: Default value if key not found
            
        Returns:
            Configuration value or default
        """
        # Try AWS Secrets Manager first
        if self._aws_available:
            secrets = self._fetch_from_secrets_manager()
            if secrets and key in secrets:
                logger.debug("Retrieved '%s' from AWS Secrets Manager", key)
                return secrets[key]

        # Fall back to environment variable
        value = os.getenv(key)
        if value is not None:
            logger.debug("Retrieved '%s' from environment variable", key)
            return value

        # Return default
        logger.debug("Key '%s' not found, using default", key)
        return default

    def get_many(self, keys: list[str]) -> Dict[str, Optional[str]]:
        """
        Get multiple configuration values.
        
        Args:
            keys: List of configuration key names
            
        Returns:
            Dictionary mapping keys to values
        """
        return {key: self.get(key) for key in keys}

    def get_all(self) -> Dict[str, Any]:
        """
        Get all configuration values.
        
        Returns all secrets from AWS Secrets Manager if available,
        otherwise returns relevant environment variables.
        
        Returns:
            Dictionary of all configuration values
        """
        # Try AWS first
        if self._aws_available:
            secrets = self._fetch_from_secrets_manager()
            if secrets:
                return secrets

        # Fall back to environment variables
        # Return all environment variables (you might want to filter these)
        return dict(os.environ)

    def clear_cache(self) -> None:
        """Clear the secrets cache, forcing a fresh fetch on next access."""
        self._secrets_cache = None
        logger.info("Secrets cache cleared")

    def is_aws_available(self) -> bool:
        """Check if AWS Secrets Manager is available and configured."""
        return self._aws_available


# Convenience function for simple use cases
def get_config(
    key: str,
    default: Optional[str] = None,
    secret_name: Optional[str] = None,
) -> Optional[str]:
    """
    Get a configuration value with AWS Secrets Manager fallback.
    
    This is a convenience function for one-off config retrieval.
    For multiple config values, create a ConfigManager instance.
    
    Args:
        key: Configuration key name
        default: Default value if not found
        secret_name: AWS Secrets Manager secret name (optional)
        
    Returns:
        Configuration value
        
    Example:
        api_key = get_config("OPENAI_API_KEY", secret_name="my-app/agents")
    """
    manager = ConfigManager(secret_name=secret_name)
    return manager.get(key, default)


# Pre-configured manager for common use case
def create_agent_config_manager() -> ConfigManager:
    """
    Create a ConfigManager with sensible defaults for agent configuration.
    
    Looks for secrets in: ai-agents-bridge/config
    Or uses environment variable: AWS_SECRET_NAME
    
    Returns:
        Configured ConfigManager instance
    """
    secret_name = os.getenv("AWS_SECRET_NAME", "ai-agents-bridge/config")
    return ConfigManager(secret_name=secret_name)

