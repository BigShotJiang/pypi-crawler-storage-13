"""Tests for server-side handler utilities."""

import json
import sys
import types

import pytest

from any_agent2agent import AgentMessage
from any_agent2agent.server import (
    create_agent_handler,
    create_fastapi_router,
    create_flask_handler,
    create_lambda_handler,
)
from any_agent2agent.server_detection import FASTAPI_ENV_VAR, FLASK_ENV_VAR


def test_create_agent_handler_basic():
    def logic(messages):
        return ("Hello " + messages[-1].content, {"agent": "demo"})

    handler = create_agent_handler(logic, default_metadata={"provider": "custom"})
    payload = {"messages": [AgentMessage(role="user", content="world").to_dict()]}
    response = handler(payload)

    assert response["content"] == "Hello world"
    assert response["metadata"]["agent"] == "demo"
    assert response["metadata"]["provider"] == "custom"


def test_create_agent_handler_missing_messages():
    handler = create_agent_handler(lambda msgs: "noop")
    with pytest.raises(ValueError):
        handler({})


def test_create_agent_handler_str_return():
    handler = create_agent_handler(lambda msgs: "ok")
    payload = {"messages": [AgentMessage(role="user", content="hi").to_dict()]}
    response = handler(payload)

    assert response["content"] == "ok"
    assert response["metadata"]["provider"] == "custom_agent"


def test_create_lambda_handler_accepts_json_string():
    handler = create_lambda_handler(lambda msgs: ("done", {"agent": "lambda"}))
    event = json.dumps(
        {"messages": [AgentMessage(role="user", content="hi").to_dict()]}
    )
    response = handler(event, None)

    assert response["content"] == "done"
    assert response["metadata"]["agent"] == "lambda"


def test_create_lambda_handler_streaming():
    def base_logic(messages):
        return "final"

    def stream_logic(messages):
        yield ("part-1", {"sequence": 1})
        yield ("part-2", {"sequence": 2})

    handler = create_lambda_handler(
        base_logic,
        streaming=True,
        streaming_agent_logic=stream_logic,
    )

    event = {
        "stream": True,
        "messages": [AgentMessage(role="user", content="hi").to_dict()],
    }
    response = handler(event, None)

    chunks = response["stream"]
    assert len(chunks) == 2
    assert chunks[0]["content"] == "part-1"
    assert chunks[0]["metadata"]["sequence"] == 1
    assert chunks[0]["status"] == "in_progress"
    assert chunks[1]["status"] == "completed"


def test_agent_protocol_handler_roundtrip():
    def logic(messages):
        assert len(messages) == 1
        assert messages[0].content == "Hello from AP"
        return ("Hi from SDK", {"agent": "ap", "provider": "agent_protocol"})

    handler = create_agent_handler(logic, protocol="agent_protocol")
    payload = {
        "messages": [
            {
                "role": "user",
                "content": [{"type": "text", "text": "Hello from AP"}],
                "metadata": {},
            }
        ]
    }
    response = handler(payload)

    assert response["messages"][0]["role"] == "assistant"
    assert response["messages"][0]["content"][0]["text"] == "Hi from SDK"
    assert response["messages"][0]["metadata"]["agent"] == "ap"
    assert response["messages"][0]["metadata"]["provider"] == "agent_protocol"


def test_agent_protocol_handler_missing_text():
    handler = create_agent_handler(lambda msgs: "hi", protocol="agent_protocol")
    payload = {"messages": [{"role": "user", "content": [], "metadata": {}}]}
    with pytest.raises(ValueError):
        handler(payload)


def test_create_fastapi_router_auto_register(monkeypatch):
    fastapi = pytest.importorskip("fastapi")
    app = fastapi.FastAPI()
    module_name = "auto_fastapi_app"
    module = types.ModuleType(module_name)
    module.app = app
    sys.modules[module_name] = module
    monkeypatch.delenv(FASTAPI_ENV_VAR, raising=False)

    try:
        router = create_fastapi_router(lambda msgs: "ok", protocol="agent_protocol")
        assert getattr(router, "_a2a_auto_registered", False)
        paths = {getattr(route, "path", None) for route in app.routes}
        assert "/agent" in paths
    finally:
        sys.modules.pop(module_name, None)


def test_fastapi_router_streaming_endpoint():
    fastapi = pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient

    def stream_logic(messages):
        yield "Chunk A"
        yield "Chunk B"

    router = create_fastapi_router(
        lambda msgs: "unused",
        streaming=True,
        streaming_agent_logic=stream_logic,
    )
    app = fastapi.FastAPI()
    app.include_router(router)

    client = TestClient(app)
    payload = {"messages": [AgentMessage(role="user", content="hello").to_dict()]}
    response = client.post("/agent/stream", json=payload)

    assert response.status_code == 200
    lines = [json.loads(line) for line in response.text.strip().splitlines()]
    assert len(lines) == 2
    assert lines[0]["status"] == "in_progress"
    assert lines[1]["status"] == "completed"

def test_create_fastapi_router_respects_skip(monkeypatch):
    fastapi = pytest.importorskip("fastapi")
    app = fastapi.FastAPI()
    module_name = "auto_fastapi_skip"
    module = types.ModuleType(module_name)
    module.app = app
    sys.modules[module_name] = module
    monkeypatch.setenv(FASTAPI_ENV_VAR, "skip")

    try:
        router = create_fastapi_router(lambda msgs: "ok", protocol="agent_protocol")
        assert not getattr(router, "_a2a_auto_registered", False)
    finally:
        sys.modules.pop(module_name, None)
        monkeypatch.delenv(FASTAPI_ENV_VAR, raising=False)


def test_create_flask_handler_auto_register(monkeypatch):
    flask = pytest.importorskip("flask")
    app = flask.Flask("auto")
    module_name = "auto_flask_app"
    module = types.ModuleType(module_name)
    module.application = app
    sys.modules[module_name] = module
    monkeypatch.delenv(FLASK_ENV_VAR, raising=False)

    try:
        handler = create_flask_handler(lambda msgs: "ok", protocol="agent_protocol")
        assert getattr(handler, "_a2a_auto_registered", False)
        routes = {rule.rule for rule in app.url_map.iter_rules()}
        assert "/agent/exchange" in routes
    finally:
        sys.modules.pop(module_name, None)


def test_create_flask_handler_respects_skip(monkeypatch):
    flask = pytest.importorskip("flask")
    app = flask.Flask("skip")
    module_name = "auto_flask_skip"
    module = types.ModuleType(module_name)
    module.app = app
    sys.modules[module_name] = module
    monkeypatch.setenv(FLASK_ENV_VAR, "off")

    try:
        handler = create_flask_handler(lambda msgs: "ok", protocol="agent_protocol")
        assert not getattr(handler, "_a2a_auto_registered", False)
    finally:
        sys.modules.pop(module_name, None)
        monkeypatch.delenv(FLASK_ENV_VAR, raising=False)

