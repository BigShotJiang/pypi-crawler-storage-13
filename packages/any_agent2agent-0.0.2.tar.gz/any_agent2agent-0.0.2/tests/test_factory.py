from any_agent2agent.base import BaseAgent
from any_agent2agent.factory import AgentFactory
from any_agent2agent.models import AgentMessage


class DummyAgent(BaseAgent):
    def __init__(self, **kwargs):
        super().__init__(api_key=kwargs.get("api_key"))

    def connect(self) -> bool:
        return True

    def send(self, prompt: str) -> AgentMessage:
        return AgentMessage(role="assistant", content=prompt)

    def stream(self, prompt: str):
        yield prompt

    async def async_send(self, prompt: str) -> AgentMessage:
        return AgentMessage(role="assistant", content=prompt)

    async def async_stream(self, prompt: str):
        yield prompt


def test_factory_registration():
    AgentFactory.register("dummy", DummyAgent)
    agent = AgentFactory.create("dummy", api_key=None)
    assert isinstance(agent, DummyAgent)

