"""Tests for automatic server detection utilities."""

from __future__ import annotations

import sys
import types

import pytest

from any_agent2agent.server_detection import (
    FASTAPI_ENV_VAR,
    FLASK_ENV_VAR,
    detect_fastapi_app,
    detect_flask_app,
)


def _register_module(module_name: str, attr: str, value) -> None:
    module = types.ModuleType(module_name)
    setattr(module, attr, value)
    sys.modules[module_name] = module


def _cleanup_module(module_name: str) -> None:
    sys.modules.pop(module_name, None)


def test_detect_fastapi_app_via_module(monkeypatch):
    fastapi = pytest.importorskip("fastapi")
    app = fastapi.FastAPI()
    module_name = "dummy_fastapi_app"
    _register_module(module_name, "app", app)
    monkeypatch.delenv(FASTAPI_ENV_VAR, raising=False)
    try:
        detected = detect_fastapi_app()
        assert detected is not None
        assert detected.app is app
        assert detected.framework == "fastapi"
        assert detected.source.endswith(".app")
    finally:
        _cleanup_module(module_name)


def test_detect_fastapi_app_disabled_via_env(monkeypatch):
    fastapi = pytest.importorskip("fastapi")
    app = fastapi.FastAPI()
    module_name = "dummy_fastapi_skip"
    _register_module(module_name, "app", app)
    monkeypatch.setenv(FASTAPI_ENV_VAR, "skip")
    try:
        assert detect_fastapi_app() is None
    finally:
        _cleanup_module(module_name)
        monkeypatch.delenv(FASTAPI_ENV_VAR, raising=False)


def test_detect_fastapi_env_override(monkeypatch):
    fastapi = pytest.importorskip("fastapi")
    app = fastapi.FastAPI()
    module_name = "dummy_fastapi_env"
    _register_module(module_name, "application", app)
    monkeypatch.setenv(FASTAPI_ENV_VAR, f"{module_name}:application")
    try:
        detected = detect_fastapi_app()
        assert detected is not None
        assert detected.app is app
        assert detected.source.startswith(FASTAPI_ENV_VAR)
    finally:
        _cleanup_module(module_name)
        monkeypatch.delenv(FASTAPI_ENV_VAR, raising=False)


def test_detect_flask_app_via_module(monkeypatch):
    flask = pytest.importorskip("flask")
    app = flask.Flask("dummy")
    module_name = "dummy_flask_app"
    _register_module(module_name, "application", app)
    monkeypatch.delenv(FLASK_ENV_VAR, raising=False)
    try:
        detected = detect_flask_app()
        assert detected is not None
        assert detected.app is app
        assert detected.framework == "flask"
        assert detected.source.endswith(".application")
    finally:
        _cleanup_module(module_name)


def test_detect_flask_app_disabled(monkeypatch):
    flask = pytest.importorskip("flask")
    app = flask.Flask("dummy")
    module_name = "dummy_flask_skip"
    _register_module(module_name, "app", app)
    monkeypatch.setenv(FLASK_ENV_VAR, "false")
    try:
        assert detect_flask_app() is None
    finally:
        _cleanup_module(module_name)
        monkeypatch.delenv(FLASK_ENV_VAR, raising=False)

