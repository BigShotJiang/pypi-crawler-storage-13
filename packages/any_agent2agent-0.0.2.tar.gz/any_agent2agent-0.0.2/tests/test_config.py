"""Tests for the configuration and secrets management module."""

import json
import os
from unittest.mock import MagicMock, patch

import pytest

from any_agent2agent.config import ConfigManager, get_config


@pytest.fixture
def mock_env():
    """Mock environment variables."""
    env_vars = {
        "TEST_KEY": "test_value",
        "OPENAI_API_KEY": "sk-test-12345",
        "AWS_ACCESS_KEY_ID": "AKIATEST",
        "AWS_SECRET_ACCESS_KEY": "test_secret",
        "AWS_DEFAULT_REGION": "us-east-1",
    }
    with patch.dict(os.environ, env_vars, clear=False):
        yield env_vars


@pytest.fixture
def mock_boto3():
    """Mock boto3 client."""
    with patch("any_agent2agent.config.BOTO3_AVAILABLE", True):
        with patch("any_agent2agent.config.boto3") as mock_boto:
            yield mock_boto


def test_config_manager_env_var_only(mock_env):
    """Test ConfigManager with environment variables only."""
    config = ConfigManager()  # No secret_name, should use env vars only

    value = config.get("TEST_KEY")
    assert value == "test_value"

    assert not config.is_aws_available()


def test_config_manager_get_with_default(mock_env):
    """Test getting configuration with default value."""
    config = ConfigManager()

    # Existing key
    value = config.get("TEST_KEY", default="default_value")
    assert value == "test_value"

    # Non-existing key
    value = config.get("NON_EXISTENT", default="default_value")
    assert value == "default_value"


def test_config_manager_get_many(mock_env):
    """Test getting multiple configuration values."""
    config = ConfigManager()

    values = config.get_many(["TEST_KEY", "OPENAI_API_KEY", "NON_EXISTENT"])

    assert values["TEST_KEY"] == "test_value"
    assert values["OPENAI_API_KEY"] == "sk-test-12345"
    assert values["NON_EXISTENT"] is None


def test_config_manager_aws_not_available_without_boto3():
    """Test that AWS is marked unavailable when boto3 is not installed."""
    with patch("any_agent2agent.config.BOTO3_AVAILABLE", False):
        config = ConfigManager(secret_name="test-secret")
        assert not config.is_aws_available()


def test_config_manager_aws_not_available_without_credentials():
    """Test that AWS is marked unavailable without AWS credentials."""
    with patch.dict(os.environ, {}, clear=True):  # Clear all env vars
        config = ConfigManager(secret_name="test-secret")
        assert not config.is_aws_available()


def test_config_manager_aws_secrets_manager(mock_env, mock_boto3):
    """Test fetching from AWS Secrets Manager."""
    # Mock the secrets manager client
    mock_client = MagicMock()
    mock_client.get_secret_value.return_value = {
        "SecretString": json.dumps({
            "API_KEY": "aws_secret_value",
            "DATABASE_URL": "postgres://...",
        })
    }
    mock_boto3.client.return_value = mock_client

    config = ConfigManager(secret_name="test-secret", cache_secrets=False)

    # Should fetch from AWS
    value = config.get("API_KEY")
    assert value == "aws_secret_value"

    # Verify boto3 was called
    mock_boto3.client.assert_called_once()
    mock_client.get_secret_value.assert_called_once_with(SecretId="test-secret")


def test_config_manager_aws_fallback_to_env(mock_env, mock_boto3):
    """Test fallback to environment variables when AWS fails."""
    # Mock AWS to raise an exception
    mock_client = MagicMock()
    mock_client.get_secret_value.side_effect = Exception("AWS Error")
    mock_boto3.client.return_value = mock_client

    config = ConfigManager(secret_name="test-secret")

    # Should fall back to environment variable
    value = config.get("TEST_KEY")
    assert value == "test_value"


def test_config_manager_cache(mock_env, mock_boto3):
    """Test secrets caching."""
    mock_client = MagicMock()
    mock_client.get_secret_value.return_value = {
        "SecretString": json.dumps({"API_KEY": "cached_value"})
    }
    mock_boto3.client.return_value = mock_client

    config = ConfigManager(secret_name="test-secret", cache_secrets=True)

    # First call - fetches from AWS
    value1 = config.get("API_KEY")
    assert value1 == "cached_value"
    assert mock_client.get_secret_value.call_count == 1

    # Second call - uses cache
    value2 = config.get("API_KEY")
    assert value2 == "cached_value"
    assert mock_client.get_secret_value.call_count == 1  # Not called again

    # Clear cache
    config.clear_cache()

    # Third call - fetches again
    value3 = config.get("API_KEY")
    assert value3 == "cached_value"
    assert mock_client.get_secret_value.call_count == 2  # Called again


def test_config_manager_no_cache(mock_env, mock_boto3):
    """Test without caching."""
    mock_client = MagicMock()
    mock_client.get_secret_value.return_value = {
        "SecretString": json.dumps({"API_KEY": "no_cache_value"})
    }
    mock_boto3.client.return_value = mock_client

    config = ConfigManager(secret_name="test-secret", cache_secrets=False)

    # Each call fetches from AWS
    config.get("API_KEY")
    config.get("API_KEY")

    assert mock_client.get_secret_value.call_count == 2


def test_config_manager_secret_not_found(mock_env, mock_boto3):
    """Test handling ResourceNotFoundException."""
    from botocore.exceptions import ClientError

    mock_client = MagicMock()
    mock_client.get_secret_value.side_effect = ClientError(
        {"Error": {"Code": "ResourceNotFoundException"}},
        "GetSecretValue"
    )
    mock_boto3.client.return_value = mock_client

    config = ConfigManager(secret_name="non-existent")

    # Should fall back to environment variables
    value = config.get("TEST_KEY")
    assert value == "test_value"


def test_config_manager_access_denied(mock_env, mock_boto3):
    """Test handling AccessDeniedException."""
    from botocore.exceptions import ClientError

    mock_client = MagicMock()
    mock_client.get_secret_value.side_effect = ClientError(
        {"Error": {"Code": "AccessDeniedException"}},
        "GetSecretValue"
    )
    mock_boto3.client.return_value = mock_client

    config = ConfigManager(secret_name="restricted-secret")

    # Should fall back to environment variables
    value = config.get("TEST_KEY")
    assert value == "test_value"


def test_config_manager_custom_region(mock_env, mock_boto3):
    """Test using a custom AWS region."""
    mock_client = MagicMock()
    mock_boto3.client.return_value = mock_client

    config = ConfigManager(secret_name="test-secret", region_name="us-west-2")

    # Trigger client creation
    config.get("SOME_KEY")

    # Verify region was passed to boto3
    mock_boto3.client.assert_called_once()
    call_kwargs = mock_boto3.client.call_args[1]
    assert call_kwargs["region_name"] == "us-west-2"


def test_get_config_convenience_function(mock_env):
    """Test the convenience function."""
    value = get_config("TEST_KEY")
    assert value == "test_value"

    value_with_default = get_config("NON_EXISTENT", default="default")
    assert value_with_default == "default"


def test_config_manager_priority(mock_env, mock_boto3):
    """Test configuration priority: AWS > Environment."""
    # Setup AWS with one value
    mock_client = MagicMock()
    mock_client.get_secret_value.return_value = {
        "SecretString": json.dumps({"TEST_KEY": "aws_value"})
    }
    mock_boto3.client.return_value = mock_client

    config = ConfigManager(secret_name="test-secret")

    # TEST_KEY exists in both AWS and env vars
    # AWS should take priority
    value = config.get("TEST_KEY")
    assert value == "aws_value"

    # Key that only exists in env vars
    value = config.get("OPENAI_API_KEY")
    assert value == "sk-test-12345"


def test_config_manager_get_all(mock_env):
    """Test getting all configuration."""
    config = ConfigManager()  # No AWS

    all_config = config.get_all()

    # Should contain environment variables
    assert "TEST_KEY" in all_config
    assert all_config["TEST_KEY"] == "test_value"


def test_config_manager_get_all_from_aws(mock_env, mock_boto3):
    """Test getting all configuration from AWS."""
    mock_client = MagicMock()
    mock_client.get_secret_value.return_value = {
        "SecretString": json.dumps({
            "KEY1": "value1",
            "KEY2": "value2",
        })
    }
    mock_boto3.client.return_value = mock_client

    config = ConfigManager(secret_name="test-secret")

    all_config = config.get_all()

    # Should return AWS secrets
    assert all_config == {"KEY1": "value1", "KEY2": "value2"}

