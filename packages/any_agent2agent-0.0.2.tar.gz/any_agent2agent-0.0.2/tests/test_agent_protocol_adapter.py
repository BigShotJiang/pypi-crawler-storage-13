"""Tests for the AgentProtocolAdapter."""

import json
import pytest

from any_agent2agent.adapters import AgentProtocolAdapter
from any_agent2agent.exceptions import AgentAPIError


def test_agent_protocol_adapter_send(httpx_mock):
    httpx_mock.add_response(
        method="POST",
        url="https://agent.example.com/v1/exchange",
        json={
            "messages": [
                {
                    "role": "assistant",
                    "content": [{"type": "text", "text": "Here is your plan"}],
                    "metadata": {"agent": "demo"},
                }
            ],
            "status": "completed",
        },
    )

    agent = AgentProtocolAdapter(base_url="https://agent.example.com")
    response = agent.send("Draft a Jira integration plan")

    assert response.content == "Here is your plan"
    assert response.metadata["agent"] == "demo"


def test_agent_protocol_adapter_error(httpx_mock):
    httpx_mock.add_response(
        method="POST",
        url="https://agent.example.com/v1/exchange",
        status_code=500,
    )

    agent = AgentProtocolAdapter(base_url="https://agent.example.com")

    with pytest.raises(AgentAPIError):
        agent.send("Hello")


def test_agent_protocol_adapter_stream(monkeypatch):
    chunks = [
        json.dumps(
            {
                "messages": [
                    {
                        "role": "assistant",
                        "content": [{"type": "text", "text": "Hello "}],
                        "metadata": {"partial": True},
                    }
                ],
                "status": "in_progress",
            }
        ),
        json.dumps(
            {
                "messages": [
                    {
                        "role": "assistant",
                        "content": [{"type": "text", "text": "world!"}],
                        "metadata": {"partial": False, "agent": "demo"},
                    }
                ],
                "status": "completed",
            }
        ),
    ]

    class DummyStream:
        def __init__(self, lines):
            self._lines = lines

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def iter_lines(self):
            for line in self._lines:
                yield line

        def raise_for_status(self):
            return None

    class DummyClient:
        def stream(self, *args, **kwargs):
            return DummyStream(chunks)

    agent = AgentProtocolAdapter(base_url="https://agent.example.com")
    agent._client = DummyClient()  # type: ignore[assignment]

    results = list(agent.stream("Streamed request"))

    assert results == ["Hello ", "world!"]
    history = agent.get_history()
    assert history[-1].content == "Hello world!"
    assert history[-1].metadata["agent"] == "demo"


@pytest.mark.asyncio
async def test_agent_protocol_adapter_async_send(httpx_mock):
    httpx_mock.add_response(
        method="POST",
        url="https://agent.example.com/v1/exchange",
        json={
            "messages": [
                {
                    "role": "assistant",
                    "content": [{"type": "text", "text": "Async hi"}],
                    "metadata": {"mode": "async"},
                }
            ],
            "status": "completed",
        },
    )

    agent = AgentProtocolAdapter(base_url="https://agent.example.com")
    response = await agent.async_send("Hello async")

    assert response.content == "Async hi"
    assert response.metadata["mode"] == "async"


@pytest.mark.asyncio
async def test_agent_protocol_adapter_async_stream(monkeypatch):
    chunks = [
        json.dumps(
            {
                "messages": [
                    {
                        "role": "assistant",
                        "content": [{"type": "text", "text": "Chunk "}],
                        "metadata": {"partial": True},
                    }
                ],
                "status": "in_progress",
            }
        ),
        json.dumps(
            {
                "messages": [
                    {
                        "role": "assistant",
                        "content": [{"type": "text", "text": "async"}],
                        "metadata": {"agent": "async"},
                    }
                ],
                "status": "completed",
            }
        ),
    ]

    class DummyAsyncStream:
        def __init__(self, lines):
            self._lines = lines

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aiter_lines(self):
            for line in self._lines:
                yield line

    class DummyAsyncClient:
        def stream(self, *args, **kwargs):
            return DummyAsyncStream(chunks)

    agent = AgentProtocolAdapter(base_url="https://agent.example.com")

    async def fake_get_async_client():
        return DummyAsyncClient()

    monkeypatch.setattr(agent, "_get_async_client", lambda: DummyAsyncClient())

    results = []
    async for part in agent.async_stream("Async stream please"):
        results.append(part)

    assert results == ["Chunk ", "async"]
    assert agent.get_history()[-1].content == "Chunk async"

