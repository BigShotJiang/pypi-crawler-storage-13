# cmpparis-db

Database utilities for cmpparis libraries (MongoDB, SQL Server, ODBC).

## Installation

```bash
pip install cmpparis-db
```

## Features

- MongoDB document management
- SQL Server connectivity
- ODBC support
- Unified SQL factory

## Usage

```python
from cmpparis_db import DocumentDBManager, MSSQL

# MongoDB
db = DocumentDBManager("mongodb://localhost", "mydb")

# SQL Server
sql = MSSQL("server", "database")
```
