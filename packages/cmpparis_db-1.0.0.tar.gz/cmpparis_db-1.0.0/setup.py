from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="cmpparis-db",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "pymongo",
        "pyodbc",
        "pymssql",
        "cmpparis-core>=1.0.0"
    ],
    author="Sofiane Charrad",
    description="Database utilities for cmpparis libraries (MongoDB, SQL Server, ODBC)",
    long_description=long_description,
    long_description_content_type="text/markdown",
)
