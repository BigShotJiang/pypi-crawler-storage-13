"""
API endpoints for first-run setup wizard.
"""

import logging
import sys
from pathlib import Path
from typing import Dict, Any

# Import config functions
try:
    from modules.config.app_config import (
        get_default_data_dir,
        get_portable_data_dir,
        set_data_folder,
        mark_first_run_complete,
        get_app_config_dir
    )
except ImportError as e:
    logging.error(f"Failed to import config module: {e}")
    # Provide fallbacks
    def get_default_data_dir():
        return Path.home() / 'Documents' / 'AnZar'
    def get_portable_data_dir():
        return Path.cwd() / 'data'
    def set_data_folder(path):
        return False
    def mark_first_run_complete():
        return False
    def get_app_config_dir():
        return Path.home() / 'AppData' / 'Local' / 'AnZar'

logger = logging.getLogger(__name__)


class WizardAPI:
    """API for first-run setup wizard."""

    def __init__(self, window=None):
        """
        Initialize wizard API.

        Args:
            window: PyWebView window instance
        """
        self.window = window

    def get_wizard_paths(self) -> Dict[str, str]:
        """
        Get default paths for wizard options.

        Returns:
            Dictionary with path options
        """
        try:
            return {
                'documents_path': str(get_default_data_dir()),
                'portable_path': str(get_portable_data_dir()),
                'username': Path.home().name
            }
        except Exception as e:
            logger.error(f"Error getting wizard paths: {e}")
            return {
                'documents_path': str(Path.home() / 'Documents' / 'AnZar'),
                'portable_path': str(Path.cwd() / 'data'),
                'username': 'User'
            }

    def browse_for_folder(self) -> Dict[str, Any]:
        """
        Open native folder picker dialog.

        Returns:
            Dictionary with selected path or None
        """
        try:
            # Get window from webview windows list if not passed to constructor
            if not self.window:
                import webview
                if webview.windows and len(webview.windows) > 0:
                    window = webview.windows[0]
                else:
                    logger.error("No window instance available for folder dialog")
                    return {'success': False, 'error': 'No window available'}
            else:
                window = self.window

            import webview
            result = window.create_file_dialog(
                webview.FOLDER_DIALOG,
                directory=str(Path.home() / 'Documents')
            )

            if result and len(result) > 0:
                selected_path = result[0]
                logger.info(f"User selected folder: {selected_path}")
                return {
                    'success': True,
                    'path': selected_path
                }

            return {'success': False, 'cancelled': True}

        except Exception as e:
            logger.error(f"Error in folder dialog: {e}")
            return {
                'success': False,
                'error': str(e)
            }

    def complete_first_run_wizard(self, config: Dict[str, str]) -> Dict[str, Any]:
        """
        Complete first-run wizard and save configuration.

        Args:
            config: Dictionary with 'data_folder' and 'option' keys

        Returns:
            Dictionary with success status
        """
        try:
            data_folder = config.get('data_folder')
            option = config.get('option', 'documents')

            if not data_folder:
                return {
                    'success': False,
                    'error': 'No data folder specified'
                }

            logger.info(f"Completing first-run wizard: {option} -> {data_folder}")

            # Validate and create the data folder
            try:
                data_path = Path(data_folder)
                data_path.mkdir(parents=True, exist_ok=True)

                # Test write permissions
                test_file = data_path / '.anzar_test'
                test_file.write_text('test')
                test_file.unlink()

            except Exception as e:
                logger.error(f"Error creating/testing data folder: {e}")
                return {
                    'success': False,
                    'error': f'Cannot create or write to folder: {str(e)}'
                }

            # Save the data folder location
            if not set_data_folder(data_folder):
                return {
                    'success': False,
                    'error': 'Failed to save data folder configuration'
                }

            # Mark first run as complete
            if not mark_first_run_complete():
                logger.warning("Failed to mark first run complete")

            logger.info(f"First-run wizard completed successfully. Data folder: {data_folder}")

            return {
                'success': True,
                'data_folder': data_folder,
                'config_location': str(get_app_config_dir())
            }

        except Exception as e:
            logger.error(f"Error completing first-run wizard: {e}")
            return {
                'success': False,
                'error': str(e)
            }

    def get_current_config(self) -> Dict[str, Any]:
        """
        Get current configuration status.

        Returns:
            Dictionary with current config
        """
        try:
            from modules.config.app_config import load_config, get_data_dir

            config = load_config()
            return {
                'success': True,
                'data_folder': get_data_dir(),
                'first_run_complete': config.get('first_run_complete', False),
                'portable_mode': config.get('portable_mode', False)
            }
        except Exception as e:
            logger.error(f"Error getting current config: {e}")
            return {
                'success': False,
                'error': str(e)
            }
