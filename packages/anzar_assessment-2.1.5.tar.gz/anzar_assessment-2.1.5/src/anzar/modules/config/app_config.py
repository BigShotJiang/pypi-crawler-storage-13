"""
Application configuration management for AnZar.

Handles:
- Data folder location configuration
- Application settings storage
- Profile and log file locations
- First-run setup detection
"""

import os
import json
import sys
from pathlib import Path
from typing import Dict, Any, Optional


def get_app_config_dir() -> Path:
    r"""
    Get AnZar config directory in AppData\Local.

    Returns:
        Path to AppData\Local\AnZar directory (created if needed)
    """
    if sys.platform == 'win32':
        config_dir = Path(os.getenv('LOCALAPPDATA', Path.home() / 'AppData' / 'Local')) / 'AnZar'
    elif sys.platform == 'darwin':
        config_dir = Path.home() / 'Library' / 'Application Support' / 'AnZar'
    else:  # Linux and others
        config_dir = Path.home() / '.config' / 'anzar'

    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def get_default_data_dir() -> Path:
    r"""
    Get default data directory in Documents.

    Returns:
        Path to Documents\AnZar directory
    """
    return Path.home() / 'Documents' / 'AnZar'


def get_portable_data_dir() -> Path:
    """
    Get portable mode data directory (next to executable).

    Returns:
        Path to data directory next to executable
    """
    if getattr(sys, 'frozen', False):
        # Running as PyInstaller bundle
        exe_dir = Path(sys.executable).parent
    else:
        # Running in development mode
        exe_dir = Path.cwd()

    return exe_dir / 'data'


def is_portable_mode() -> bool:
    """
    Detect if running in portable mode.

    Portable mode is activated by:
    1. Presence of 'portable.txt' file next to executable
    2. Running from a removable drive (USB)

    Returns:
        True if portable mode detected, False otherwise
    """
    if getattr(sys, 'frozen', False):
        exe_dir = Path(sys.executable).parent
    else:
        exe_dir = Path.cwd()

    # Check for portable.txt marker file
    if (exe_dir / 'portable.txt').exists():
        return True

    # Check if running from removable drive (Windows only)
    if sys.platform == 'win32':
        try:
            import win32file
            drive = os.path.splitdrive(str(exe_dir))[0]
            if drive and win32file.GetDriveType(drive) == win32file.DRIVE_REMOVABLE:
                return True
        except (ImportError, Exception):
            # win32file not available or error checking drive type
            pass

    return False


def load_config() -> Dict[str, Any]:
    """
    Load application configuration from AppData.

    Creates default config if not exists.

    Returns:
        Dictionary containing application configuration
    """
    config_path = get_app_config_dir() / 'config.json'

    if not config_path.exists():
        # First run - create default config
        default_config = {
            'data_folder': str(get_default_data_dir()),
            'first_run_complete': True,  # Skip wizard for pip-installed users
            'portable_mode': is_portable_mode(),
            'version': '2.1.4',
            'auto_backup': False,
            'log_level': 'INFO'
        }
        save_config(default_config)
        return default_config

    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)

        # Check for portable mode override
        if is_portable_mode():
            config['portable_mode'] = True
            config['data_folder'] = str(get_portable_data_dir())

        return config
    except (json.JSONDecodeError, IOError) as e:
        print(f"Error loading config: {e}. Using defaults.")
        return {
            'data_folder': str(get_default_data_dir()),
            'first_run_complete': True,  # Skip wizard for pip-installed users
            'portable_mode': is_portable_mode(),
            'version': '2.1.4'
        }


def save_config(config: Dict[str, Any]) -> bool:
    """
    Save application configuration to AppData.

    Args:
        config: Dictionary containing configuration to save

    Returns:
        True if successful, False otherwise
    """
    config_path = get_app_config_dir() / 'config.json'

    try:
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4)
        return True
    except (IOError, TypeError) as e:
        print(f"Error saving config: {e}")
        return False


def get_data_dir() -> str:
    """
    Get data directory path based on current configuration.

    Respects portable mode and user-configured data folder location.
    Creates the directory if it doesn't exist.

    Returns:
        Absolute path to data directory as string
    """
    config = load_config()

    # Portable mode overrides config
    if config.get('portable_mode', False):
        data_dir = get_portable_data_dir()
    else:
        data_dir = Path(config.get('data_folder', str(get_default_data_dir())))

    # Ensure directory exists
    data_dir.mkdir(parents=True, exist_ok=True)

    return str(data_dir)


def get_profiles_path() -> Path:
    """
    Get path to profiles.json file in AppData.

    Returns:
        Path to profiles.json
    """
    return get_app_config_dir() / 'profiles.json'


def get_log_path() -> Path:
    """
    Get path to anzar.log file in AppData.

    Returns:
        Path to anzar.log
    """
    return get_app_config_dir() / 'anzar.log'


def set_data_folder(folder_path: str) -> bool:
    """
    Update the data folder location in config.

    Args:
        folder_path: New data folder path

    Returns:
        True if successful, False otherwise
    """
    config = load_config()

    # Validate path
    try:
        path = Path(folder_path)
        path.mkdir(parents=True, exist_ok=True)

        config['data_folder'] = str(path.absolute())
        return save_config(config)
    except (OSError, ValueError) as e:
        print(f"Error setting data folder: {e}")
        return False


def mark_first_run_complete() -> bool:
    """
    Mark first-run wizard as completed.

    Returns:
        True if successful, False otherwise
    """
    config = load_config()
    config['first_run_complete'] = True
    return save_config(config)


def is_first_run() -> bool:
    """
    Check if this is the first run of the application.

    Returns:
        True if first run, False otherwise
    """
    config = load_config()
    return not config.get('first_run_complete', False)


def get_data_folder_info() -> Dict[str, Any]:
    """
    Get information about the current data folder.

    Returns:
        Dictionary with data folder statistics
    """
    data_dir = Path(get_data_dir())

    info = {
        'path': str(data_dir),
        'exists': data_dir.exists(),
        'size_bytes': 0,
        'file_count': 0,
        'course_count': 0
    }

    if not data_dir.exists():
        return info

    try:
        # Count files and calculate size
        for item in data_dir.rglob('*'):
            if item.is_file():
                info['file_count'] += 1
                info['size_bytes'] += item.stat().st_size

        # Count course directories
        course_dirs = [d for d in data_dir.iterdir() if d.is_dir() and d.name.startswith('course_')]
        info['course_count'] = len(course_dirs)

    except Exception as e:
        print(f"Error getting data folder info: {e}")

    return info


def migrate_old_profiles() -> bool:
    """
    Migrate profiles.json from old location (app root) to new location (AppData).

    Returns:
        True if migration occurred or not needed, False on error
    """
    old_profiles_path = Path.cwd() / 'profiles.json'
    new_profiles_path = get_profiles_path()

    # If new location already has profiles, no migration needed
    if new_profiles_path.exists():
        return True

    # If old location has profiles, migrate them
    if old_profiles_path.exists():
        try:
            import shutil
            shutil.copy2(old_profiles_path, new_profiles_path)
            print(f"Migrated profiles from {old_profiles_path} to {new_profiles_path}")
            return True
        except Exception as e:
            print(f"Error migrating profiles: {e}")
            return False

    # No profiles in either location - that's okay
    return True


# Initialize on module import
if __name__ != "__main__":
    # Attempt to migrate old profiles on first import
    migrate_old_profiles()
