__version__ = "0.4.1"

import sounddevice  # noqa

from xiaozhi_sdk.core import XiaoZhiWebsocket  # noqa
