"""Database Manager Module for managing database connections and operations."""

from __future__ import annotations

import atexit
from contextlib import contextmanager
from functools import partial
from typing import TYPE_CHECKING, Any, ClassVar, Literal, overload

from sqlalchemy import Engine, MetaData, create_engine
from sqlalchemy.orm import DeclarativeMeta, Query, declarative_base, scoped_session, sessionmaker
from sqlalchemy.orm.session import Session

from ._extra import DatabaseManagerMeta, DynamicRecords, TableHandler, TableHandlers, get_name
from .config import DatabaseConfig, Schemas, get_default_config

if TYPE_CHECKING:
    from collections.abc import Generator
    from threading import RLock

    from sqlalchemy.orm.mapper import Mapper
    from sqlalchemy.orm.session import Session


class DatabaseManager[T_Table](metaclass=DatabaseManagerMeta, bypass=False):
    """A class to manage database connections and operations."""

    _scheme: ClassVar[Schemas] = "sqlite"
    config_factory: partial[DatabaseConfig]
    engine_factory: partial[Engine]

    @classmethod
    def set_base(cls, base: DeclarativeMeta | None) -> None:
        """Set the base class for this database class."""
        cls._set_base(base)

    @classmethod
    def get_base(cls) -> DeclarativeMeta:
        """Get the base class for this database class."""
        if cls._base is None:
            cls._set_base(declarative_base())
        return cls._get_base()

    @classmethod
    def clear_base(cls) -> None:
        """Clear the base class for this database class."""
        cls._set_base(None)

    @classmethod
    def set_scheme(cls, scheme: Schemas) -> None:
        """Set the default scheme for the database manager."""
        cls._scheme = scheme

    def __init__(self, **kwargs) -> None:
        """Initialize the DatabaseManager with a database URL or connection parameters.

        Args:
            database_config (DatabaseConfig | None): The database configuration object.
            host (str): The database host.
            port (int): The database port.
            user (str): The database username.
            password (str | SecretStr): The database password.
            name (str): The database name.
            path (str | None): The database file path (for SQLite).
            schema (Schemas | None): The database schema/type (e.g., 'sqlite', 'postgresql', 'mysql').
            engine (Engine | None): An optional SQLAlchemy Engine instance.
            auto: (bool): Whether to automatically create the engine and tables.
            enable_wal (bool): Whether to enable Write-Ahead Logging (WAL) for SQLite databases.
            flush_mode (WALFlushMode): The WAL flush mode.
            engine_create (bool): Whether to create a new engine if one is not provided.
            tables_create (bool): Whether to create tables on initialization.
            records (dict[str, type[T_Table]] | None): An optional dictionary of pre-registered dynamic records.
        """
        self._metadata: MetaData = self.get_base().metadata

        self._handlers: TableHandlers = TableHandlers()
        self._current_table: str = ""

        self._config: DatabaseConfig | None = None
        self._engine: Engine | None = None
        self._session_factory: sessionmaker[Session] | None = None

        self._on_init(
            config=kwargs.pop("database_config", None),
            schema=kwargs.pop("schema", None),
            engine=kwargs.pop("engine", None),
            auto=kwargs.pop("auto", False),
            engine_create=kwargs.pop("engine_create", False),
            tables_create=kwargs.pop("tables_create", False),
            records=kwargs.pop("records", {}),
            **kwargs,
        )

    def _on_init(
        self,
        records: dict[str, type[T_Table]] | None = None,
        config: DatabaseConfig | None = None,
        schema: Schemas | None = None,
        engine: Engine | None = None,
        auto: bool = False,
        engine_create: bool = False,
        tables_create: bool = False,
        **kwargs,
    ) -> None:
        """Hook method called after initialization.

        Args:
            records (dict[str, type[T_Table]] | None): An optional dictionary of pre-registered dynamic records.
            engine (Engine | None): An optional SQLAlchemy Engine instance.
        """
        if auto:
            engine_create = True
            tables_create = True

        self.config_factory = partial(
            get_default_config,
            schema=schema or self._scheme,
            user=kwargs.pop("user", None),
            password=kwargs.pop("password", None),
            host=kwargs.pop("host", None),
            port=kwargs.pop("port", None),
            name=kwargs.pop("name", None),
            path=kwargs.pop("path", None),
        )

        if config is not None:
            self._config = config

        self.engine_factory: partial[Engine] = partial(
            create_engine,
            self.config.db_url.get_secret_value(),
            echo=False,
            connect_args={**kwargs},
        )

        if engine_create or engine is None:
            self._engine = engine or self.engine_factory()
        if tables_create:
            self.create_tables()

        if records:
            for _, rec_cls in records.items():
                self.register_records(tbl_obj=rec_cls)

        if len(self._handlers) == 0:
            tables: dict[str, type[T_Table]] = self.get_orm_tables()
            if len(tables) == 1:
                first_table: type[T_Table] = next(iter(tables.values()))
                self.register_records(tbl_obj=first_table)
        atexit.register(self.close)

    def register_records(self, tbl_obj: Any) -> DynamicRecords[T_Table]:
        """Register a table class for dynamic record access.

        Args:
            name (str): The name to register the table class under.
            tbl_obj (type[T]): The table class to register.

        Returns:
            DynamicRecords[T]: An instance of DynamicRecords for the table class.
        """
        name: str = get_name(tbl_obj)
        if self._handlers.has(name):
            raise ValueError(f"Records for {name} are already registered.")

        session: scoped_session[Session] = self.get_session(scoped=True)
        records: DynamicRecords[T_Table] = DynamicRecords(tbl_obj=tbl_obj, session=session)
        tbl_handler = TableHandler(name=name.lower(), table_obj=tbl_obj, session=session, records=records)
        self._handlers.add_handler(name, tbl_handler)
        self.set_table(tbl_obj)
        return records

    def is_registered(self, table: type[T_Table] | str) -> bool:
        """Check if a table class is registered.

        Args:
            table (type | str): The table class to check.

        Returns:
            bool: True if the table class is registered, False otherwise.
        """
        return self._handlers.has_handler(table)

    def get_records(self, table: type[T_Table] | str) -> DynamicRecords[T_Table]:
        """Get the DynamicRecords instance for a registered table class.

        Args:
            table (type[T_Table] | str): The table class to get records for.

        Returns:
            DynamicRecords[T_Table]: The DynamicRecords instance for the table class.
        """
        if isinstance(table, str) and self._handlers.has(table):
            return self._handlers.get_handler(table).get_records()
        if isinstance(table, type) and not self.is_registered(table):
            return self.register_records(table)
        return self._handlers.get_handler(table).get_records()

    def set_table(self, table: type[T_Table]) -> None:
        """Set the current table for operations.

        Args:
            table (type[T_Table]): The table class to set as current.
        """
        self._current_table = get_name(table)

    def current_table(self, table: type | None = None) -> type:
        """Get the current table object.

        Returns:
            Table: The current SQLAlchemy Table object.
        """
        if table is not None:
            self.set_table(table)
        if not self._current_table:
            raise ValueError("No current table is set.")
        handler: TableHandler = self._handlers.get_handler(self._current_table)
        return handler.table_obj

    def get_all(self, table: type[T_Table] | None = None) -> list[T_Table]:  # type: ignore[override]
        """Get all records from a table.

        Note: If you do not pass anything, it will use the current table so
        be mindful about if you do or do not pass a table.

        Args:
            table (type[T_Table]): The table class to get records from.

        Returns:
            list[T_Table]: A list of all records in the table.
        """
        table = self.current_table(table)
        return self.get_records(table).all()

    def get(self, table: type[T_Table] | None = None, ident: Any | None = None) -> T_Table | None:
        """Get a record by its primary key.

        Args:
            table (type[T_Table]): The table class to get the record from.
            ident (Any): The primary key of the record to retrieve.

        Returns:
            T_Table | None: The record with the specified primary key, or None if not found.
        """
        table = self.current_table(table)
        return self.get_records(table).get(ident)

    def count(self, table: type[T_Table] | None = None, **kwargs) -> int:
        """Count the number of records in a table.

        Args:
            table (type[T_Table]): The table class to count records from.
            **kwargs: Optional filters to apply when counting.

        Returns:
            int: The count of records in the table.
        """
        table = self.current_table(table)
        records: DynamicRecords[T_Table] = self.get_records(table)
        return records.count() if not kwargs else records.filter_by(**kwargs).count()

    def query(self, table: type[T_Table] | None = None) -> Query[T_Table]:
        """Get a query object for a registered table.

        Args:
            table (type[T_Table]): The table class to query.

        Returns:
            Query[T_Table]: A SQLAlchemy Query object for the table.
        """
        table = self.current_table(table)
        return self.get_records(table).query()

    def filter_by(self, table: type[T_Table] | None = None, **kwargs) -> Query[T_Table]:
        """Get records from a table by a specific variable.

        Args:
            table (type[T_Table]): The table class to filter records from.
            **kwargs: The variable/column name and value to filter by.

        Returns:
            Query[T_Table]: A SQLAlchemy Query object with the applied filters.
        """
        table = self.current_table(table)
        return self.get_records(table).filter_by(**kwargs)

    @overload
    def get_session(self, scoped: Literal[True]) -> scoped_session: ...

    @overload
    def get_session(self, scoped: Literal[False] = False) -> Session: ...

    def get_session(self, scoped: bool = False) -> scoped_session | Session:
        """Get the scoped session for this database class.

        Args:
            scoped (bool): Whether to return a scoped session or a regular session.

        Returns:
            scoped_session | Session: The scoped session or regular session.
        """
        if self.instance_session is None:
            self.instance_session = scoped_session(self.session_factory)
        return self.instance_session if scoped else self.instance_session()

    @contextmanager
    def open_session(self) -> Generator[Session, Any]:
        """Provide a transactional scope around a series of operations.

        Will commit the session if no exceptions occur, otherwise will rollback.

        Yields:
            Generator[Session, Any]: A SQLAlchemy Session instance.
        """
        handler: TableHandler = self._handlers.get_handler(self._current_table)
        session_obj: Session = handler.session()
        try:
            yield session_obj
            session_obj.commit()
        except Exception:
            session_obj.rollback()
            raise
        finally:
            handler.session.remove()

    def close_session(self) -> None:
        """Close the session."""
        if self.instance_session is not None:
            self.session.remove()
        self.instance_session = None

    def create_tables(self) -> None:
        """Create all tables defined by Base"""
        self._metadata.create_all(self.engine)

    def get_table_objs(self) -> dict[str, Any]:
        """Get the tables defined in the metadata."""
        return self._metadata.tables

    def get_orm_tables(self) -> dict[str, type[T_Table]]:
        """Get the ORM table classes defined in the base."""
        base: DeclarativeMeta = self.get_base()
        mappers: frozenset[Mapper[Any]] = base.registry.mappers
        return {get_name(mapper.class_): mapper.class_ for mapper in mappers}

    def close(self) -> None:
        """Close the session and connection."""
        self.close_session()
        self._handlers.close()
        if self._session_factory is not None:
            self._session_factory = None
        if self.engine is not None:
            self.engine.dispose()
            self._engine = None

    @property
    def config(self) -> DatabaseConfig:
        """Get the database configuration."""
        if self._config is None:
            self._config = self.config_factory()
        return self._config

    @property
    def engine(self) -> Engine:
        """Get the SQLAlchemy Engine."""
        if self._engine is None:
            self._engine = self.engine_factory()
        return self._engine

    @property
    def session_factory(self) -> sessionmaker[Session]:
        """Get the session factory."""
        if self._session_factory is None:
            self._session_factory = sessionmaker(bind=self.engine)
        return self._session_factory

    @property
    def session(self) -> scoped_session[Session]:
        """Get the scoped session for this database class."""
        return self._handlers.get_handler(self._current_table).session

    @property
    def instance_session(self) -> scoped_session | None:
        """Get the scoped session for this database class."""
        return self.__class__._scoped_session

    @instance_session.setter
    def instance_session(self, value: scoped_session | None) -> None:
        self.__class__._scoped_session = value

    @property
    def lock(self) -> RLock:
        """Get the lock for the database manager."""
        return self.__class__._lock

    def __enter__(self) -> DatabaseManager[T_Table]:
        """Enter the runtime context related to this object."""
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        """Exit the runtime context related to this object."""
        self.close()


class SqliteDB[T](DatabaseManager[T]):
    """SQLite Database Manager, inherits from DatabaseManager and sets the scheme to sqlite."""

    _scheme: ClassVar[Schemas] = "sqlite"


class PostgresDB[T](DatabaseManager[T]):
    """Postgres Database Manager, inherits from DatabaseManager and sets the scheme to postgresql."""

    _scheme: ClassVar[Schemas] = "postgresql"


class MySQLDB[T](DatabaseManager[T]):
    """MySQL Database Manager, inherits from DatabaseManager and sets the scheme to mysql."""

    _scheme: ClassVar[Schemas] = "mysql"


class BearShelfDB[T](DatabaseManager[T]):
    """BearShelf Database Manager, inherits from DatabaseManager and sets the scheme to bearshelf.

    BearShelf uses file-based storage with multiple format options (JSONL, JSON, YAML, XML, TOML).
    The format is determined by the file extension in the database path/name.
    """

    _scheme: ClassVar[Schemas] = "bearshelf"


__all__ = ["BearShelfDB", "DatabaseManager", "MySQLDB", "PostgresDB", "SqliteDB"]
