import logging
import csv
import io
from collections import defaultdict
from importlib import import_module
from scrapy import signals
from scrapy.exceptions import NotConfigured

logger = logging.getLogger(__name__)

class DeltaGuard:
    """
    A Scrapy extension to monitor data drift by comparing scraped items to
    database records, with configurable thresholds and alerting.
    """
    def __init__(self, crawler):
        self.stats = crawler.stats
        self.settings = crawler.settings
        self.crawler = crawler

        # Core settings
        self.batch_size = self.settings.getint("DELTA_GUARD_BATCH_SIZE", 50)
        self.default_threshold = self.settings.get("DELTA_GUARD_DEFAULT_THRESHOLD", 5)
        self.stop_on_high_delta = self.settings.getbool("DELTA_GUARD_STOP_SPIDER_ON_HIGH_DELTA", True)

        # Alerting settings
        self.jira_func_path = self.settings.get("DELTA_GUARD_JIRA_FUNC")
        self.slack_webhook = self.settings.get("DELTA_GUARD_SLACK_WEBHOOK")
        self.logs_on_slack = self.settings.getbool("DELTA_GUARD_LOGS_ON_SLACK", False)

        # Configurable None handling
        self.db_none_is_delta = self.settings.getbool('DELTA_GUARD_DB_NONE_IS_DELTA', False)
        self.spider_none_is_delta = self.settings.getbool('DELTA_GUARD_SPIDER_NONE_IS_DELTA', False)

        # Parse the field configurations
        self.raw_fields_config = self.settings.getlist("DELTA_GUARD_FIELDS_CONFIG")
        self.fields_config = [fc for fc in (self._parse_field_config(fc) for fc in self.raw_fields_config) if fc is not None]

        # Internal state
        self.delta_batch = []
        self.delta_logs = []  # NEW: Store detailed delta information for CSV export
        self.item_count = 0
        self.alert_triggered = False
        self._load_alert_functions()

    def _parse_field_config(self, field_conf):
        name = field_conf.get('name')
        if not name:
            logger.warning(f"DeltaGuard: Skipping invalid field config (missing 'name'): {field_conf}")
            return None

        threshold = field_conf.get('threshold', self.default_threshold)
        threshold_val = self.default_threshold

        try:
            if isinstance(threshold, str) and '%' in threshold:
                threshold_val = float(threshold.strip().replace('%', ''))
            else:
                threshold_val = float(threshold)
        except (ValueError, TypeError):
            logger.warning(f"DeltaGuard: Invalid threshold format '{threshold}' for field '{name}'. Using default.")
            threshold_val = self.default_threshold
            if isinstance(threshold_val, str):
                 threshold_val = float(threshold_val.strip().replace('%', ''))

        if threshold_val > 1:
            threshold_val /= 100.0

        return {
            'name': name,
            'db_var': field_conf.get('db_var', name),
            'spider_var': field_conf.get('spider_var', name),
            'threshold': threshold_val,
        }

    @classmethod
    def from_crawler(cls, crawler):
        if not crawler.settings.getbool("DELTA_GUARD_ENABLED"):
            raise NotConfigured("DeltaGuard is not enabled.")
        ext = cls(crawler)
        setattr(crawler.spider, 'delta_guard_high_delta_detected', False)
        crawler.signals.connect(ext.item_scraped, signal=signals.item_scraped)
        crawler.signals.connect(ext.spider_closed, signal=signals.spider_closed)
        logger.info("DeltaGuard extension enabled and configured ✅.")
        return ext

    def item_scraped(self, item, response, spider):
        db_item = item.get('db_item')
        if not db_item: return

        self.item_count += 1
        item_deltas = self._compare_fields(item, db_item)
        if item_deltas:
            self.delta_batch.append(item_deltas)

        if self.item_count >= self.batch_size:
            self._process_batch(spider)

    def _compare_fields(self, item, db_item):
        deltas = []
        db_item_id = self._get_db_item_id(db_item)
        
        for field_conf in self.fields_config:
            db_var, spider_var = field_conf["db_var"], field_conf["spider_var"]
            field_name = field_conf["name"]
            
            old_value = self._get_db_item_value(db_item, db_var)
            new_value = item.get(spider_var)

            if old_value is None and new_value is None: continue
            if old_value is None and new_value is not None and not self.db_none_is_delta: continue
            if new_value is None and old_value is not None and not self.spider_none_is_delta: continue

            if str(old_value) != str(new_value):
                deltas.append({"field": field_name})
                self.stats.inc_value(f'deltaguard/delta_detected/{field_name}')
                
                # NEW: Enhancement 3 - Log at INFO level with old and new values
                logger.info(
                    f"DeltaGuard: Delta detected for item {self.item_count} - "
                    f"Field: '{field_name}', Old: '{old_value}', New: '{new_value}'"
                )
                
                # NEW: Enhancement 2 - Store detailed information for CSV export
                self.delta_logs.append({
                    'item_count': self.item_count,
                    'db_item_id': db_item_id,
                    'field': field_name,
                    'db_column': db_var,
                    'spider_item': spider_var,
                    'old_value': old_value,
                    'new_value': new_value
                })
        
        return deltas

    def _process_batch(self, spider):
        if not self.delta_batch:
            self._reset_batch()
            return

        fields_summary = defaultdict(int)
        for item_deltas in self.delta_batch:
            for delta in item_deltas:
                fields_summary[delta['field']] += 1
        
        details = ', '.join([f"{field} ({count})" for field, count in fields_summary.items()])
        logger.info(f"DeltaGuard: Batch processed. Delta summary: {details}.")

        # NEW: Enhancement 1 - Collect all fields that exceeded threshold
        exceeded_fields = []
        for field_conf in self.fields_config:
            field_name = field_conf['name']
            threshold_percent = field_conf['threshold']
            threshold_count = int(self.batch_size * threshold_percent)
            if threshold_count == 0 and threshold_percent > 0: threshold_count = 1
            
            delta_count = fields_summary.get(field_name, 0)
            
            if delta_count >= threshold_count:
                delta_percentage = delta_count / self.batch_size
                exceeded_fields.append({
                    'field': field_name,
                    'count': delta_count,
                    'percentage': delta_percentage,
                    'threshold': threshold_percent
                })
        
        # If any fields exceeded threshold
        if exceeded_fields and not self.alert_triggered:
            self.alert_triggered = True
            
            # Log warning for all exceeded fields
            for field_info in exceeded_fields:
                logger.warning(
                    f"DeltaGuard: HIGH DELTA on field '{field_info['field']}'. "
                    f"Found {field_info['count']} deltas ({field_info['percentage']:.0%}), "
                    f"meeting/exceeding threshold of {field_info['threshold']:.0%}."
                )
            
            # Trigger alerts with summary of all exceeded fields
            self._trigger_alerts(spider, exceeded_fields)
            
            if self.stop_on_high_delta:
                setattr(spider, 'delta_guard_high_delta_detected', True)
                exceeded_field_names = ', '.join([f['field'] for f in exceeded_fields])
                logger.warning(f"DeltaGuard: Flag 'delta_guard_high_delta_detected' set on spider.")
                logger.warning(f"DeltaGuard: Gracefully stopping spider due to high delta rate on fields: {exceeded_field_names}.")
                self.stats.set_value('finish_reason', f'deltaguard_shutdown_multiple_fields')
                self.crawler.engine.close_spider(spider, reason=f'deltaguard_shutdown_multiple_fields')
        
        self._reset_batch()

    def _reset_batch(self):
        self.item_count = 0
        self.delta_batch.clear()
        self.delta_logs.clear()  # Clear delta logs after batch processing

    def spider_closed(self, spider, reason):
        if self.item_count > 0: self._process_batch(spider)

    def _load_alert_functions(self):
        self.jira_func = None
        if self.jira_func_path:
            try:
                module_path, func_name = self.jira_func_path.rsplit('.', 1)
                module = import_module(module_path)
                self.jira_func = getattr(module, func_name)
            except (ImportError, AttributeError) as e:
                logger.error(f"DeltaGuard: Could not load Jira function from '{self.jira_func_path}': {e}")

    def _trigger_alerts(self, spider, exceeded_fields):
        """
        Triggers alerts with summary of all fields that exceeded threshold.
        exceeded_fields: list of dicts with 'field', 'count', 'percentage', 'threshold'
        """
        # Build alert message with all exceeded fields
        field_summaries = []
        for field_info in exceeded_fields:
            field_summaries.append(
                f"• *{field_info['field']}*: {field_info['count']} deltas "
                f"({field_info['percentage']:.0%}) - threshold: {field_info['threshold']:.0%}"
            )
        
        alert_message = (
            f":alert: *DeltaGuard Alert* for Spider: `{spider.name}`\n\n"
            f"*High delta rate detected on {len(exceeded_fields)} field(s):*\n"
            + "\n".join(field_summaries)
        )

        if self.slack_webhook:
            try:
                import requests
                
                # Send text alert
                requests.post(self.slack_webhook, json={"text": alert_message}, headers={"Content-Type": "application/json"})
                self.stats.inc_value('deltaguard/alerts_sent/slack')
                
                # NEW: Enhancement 2 - Send CSV file if logs are enabled
                if self.logs_on_slack and self.delta_logs:
                    # Filter logs for only the exceeded fields
                    exceeded_field_names = [f['field'] for f in exceeded_fields]
                    filtered_logs = [log for log in self.delta_logs if log['field'] in exceeded_field_names]
                    
                    if filtered_logs:
                        csv_content = self._generate_csv(filtered_logs)
                        self._send_csv_to_slack(spider.name, csv_content)
                        
            except Exception as e:
                logger.error(f"DeltaGuard: Failed to send Slack notification: {e}")

        if self.jira_func:
            try:
                exceeded_field_names = ', '.join([f['field'] for f in exceeded_fields])
                summary = f"High Delta Rate on fields: {exceeded_field_names} in Spider: {spider.name}"
                self.jira_func(spider, summary, alert_message)
                self.stats.inc_value('deltaguard/alerts_sent/jira')
            except Exception as e:
                logger.error(f"DeltaGuard: Failed to execute Jira function: {e}")

    def _generate_csv(self, delta_logs):
        """Generate CSV content from delta logs."""
        output = io.StringIO()
        
        # Sort by field name
        sorted_logs = sorted(delta_logs, key=lambda x: x['field'])
        
        # Updated fieldnames without db_column and spider_item
        fieldnames = ['db_item_id', 'field', 'old_value', 'new_value']
        
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        
        # Write only the selected fields
        for log in sorted_logs:
            writer.writerow({
                # 'item_count': log['item_count'],
                'db_item_id': log['db_item_id'],
                'field': log['field'],
                'old_value': log['old_value'],
                'new_value': log['new_value']
            })
        
        return output.getvalue()


    def _send_csv_to_slack(self, spider_name, csv_content):
        """Upload CSV file to Slack using the new Files API v2."""
        try:
            import requests
            
            slack_bot_token = self.settings.get("DELTA_GUARD_SLACK_BOT_TOKEN")
            slack_channel_id = self.settings.get("DELTA_GUARD_SLACK_CHANNEL_ID")
            
            if not slack_bot_token:
                logger.warning(
                    "DeltaGuard: DELTA_GUARD_SLACK_BOT_TOKEN not configured. "
                    "Sending CSV as text. For file uploads, configure a Slack Bot Token."
                )
                truncated_csv = csv_content[:2000] if len(csv_content) > 2000 else csv_content
                message = (
                    f"📊 *DeltaGuard Delta Logs* for spider: `{spider_name}`\n"
                    f"``````"
                )
                requests.post(
                    self.slack_webhook,
                    json={"text": message},
                    headers={"Content-Type": "application/json"}
                )
                return
            
            if not slack_channel_id:
                logger.error("DeltaGuard: DELTA_GUARD_SLACK_CHANNEL_ID not configured. Cannot upload CSV.")
                return
            
            headers = {
                'Authorization': f'Bearer {slack_bot_token}',
            }
            
            filename = f'deltaguard_{spider_name}_deltas.csv'
            
            # Step 1: Get upload URL
            upload_url_response = requests.post(
                'https://slack.com/api/files.getUploadURLExternal',
                headers={**headers, 'Content-Type': 'application/x-www-form-urlencoded'},
                data={
                    'filename': filename,
                    'length': len(csv_content.encode('utf-8'))
                }
            )
            
            upload_data = upload_url_response.json()
            if not upload_data.get('ok'):
                error = upload_data.get('error', 'Unknown error')
                logger.error(f"DeltaGuard: Failed to get upload URL: {error}")
                return
            
            upload_url = upload_data['upload_url']
            file_id = upload_data['file_id']
            
            # Step 2: Upload the file
            upload_response = requests.post(
                upload_url,
                data=csv_content.encode('utf-8'),
                headers={'Content-Type': 'text/csv'}
            )
            
            if upload_response.status_code != 200:
                logger.error(f"DeltaGuard: Failed to upload file: {upload_response.text}")
                return
            
            # Step 3: Complete the upload and share to channel
            complete_response = requests.post(
                'https://slack.com/api/files.completeUploadExternal',
                headers={
                    'Authorization': f'Bearer {slack_bot_token}',
                    'Content-Type': 'application/json'
                },
                json={
                    'files': [
                        {
                            'id': file_id,
                            'title': filename
                        }
                    ],
                    'channel_id': slack_channel_id,
                    'initial_comment': f'📊 DeltaGuard detailed delta logs for spider: `{spider_name}`'
                }
            )
            
            complete_data = complete_response.json()
            if complete_data.get('ok'):
                logger.info("DeltaGuard: Delta logs CSV file uploaded to Slack successfully.")
            else:
                error = complete_data.get('error', 'Unknown error')
                logger.error(f"DeltaGuard: Failed to complete upload: {error}")
                
        except Exception as e:
            logger.error(f"DeltaGuard: Failed to send CSV to Slack: {e}")





    def _get_db_item_value(self, db_item, key):
        if isinstance(db_item, dict):
            return db_item.get(key, None)
        return getattr(db_item, key, None)

    def _get_db_item_id(self, db_item):
        return self._get_db_item_value(db_item, 'id') or 'N/A'
