from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.screenshot_result_manifest_status import ScreenshotResultManifestStatus

if TYPE_CHECKING:
    from ..models.screenshot_result_manifest_manifest import ScreenshotResultManifestManifest


T = TypeVar("T", bound="ScreenshotResultManifest")


@_attrs_define
class ScreenshotResultManifest:
    """
    Attributes:
        batch_id (str): Batch identifier Example: crawl-2025-01-18.
        job_id (str): Job run identifier (hex string without dashes) Example: 550e8400e29b41d4a716446655440000.
        status (ScreenshotResultManifestStatus): Final status of the run
        manifest (ScreenshotResultManifestManifest): Result manifest following 2025 REST API best practices with full
            URLs and metadata
    """

    batch_id: str
    job_id: str
    status: ScreenshotResultManifestStatus
    manifest: ScreenshotResultManifestManifest
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        batch_id = self.batch_id

        job_id = self.job_id

        status = self.status.value

        manifest = self.manifest.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "batch_id": batch_id,
                "job_id": job_id,
                "status": status,
                "manifest": manifest,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.screenshot_result_manifest_manifest import ScreenshotResultManifestManifest

        d = dict(src_dict)
        batch_id = d.pop("batch_id")

        job_id = d.pop("job_id")

        status = ScreenshotResultManifestStatus(d.pop("status"))

        manifest = ScreenshotResultManifestManifest.from_dict(d.pop("manifest"))

        screenshot_result_manifest = cls(
            batch_id=batch_id,
            job_id=job_id,
            status=status,
            manifest=manifest,
        )

        screenshot_result_manifest.additional_properties = d
        return screenshot_result_manifest

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
