from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.cancel_screenshot_run_response_200_status import CancelScreenshotRunResponse200Status
from ..types import UNSET, Unset

T = TypeVar("T", bound="CancelScreenshotRunResponse200")


@_attrs_define
class CancelScreenshotRunResponse200:
    """
    Attributes:
        batch_id (str | Unset):
        job_id (str | Unset):
        status (CancelScreenshotRunResponse200Status | Unset):
    """

    batch_id: str | Unset = UNSET
    job_id: str | Unset = UNSET
    status: CancelScreenshotRunResponse200Status | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        batch_id = self.batch_id

        job_id = self.job_id

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if batch_id is not UNSET:
            field_dict["batch_id"] = batch_id
        if job_id is not UNSET:
            field_dict["job_id"] = job_id
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        batch_id = d.pop("batch_id", UNSET)

        job_id = d.pop("job_id", UNSET)

        _status = d.pop("status", UNSET)
        status: CancelScreenshotRunResponse200Status | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = CancelScreenshotRunResponse200Status(_status)

        cancel_screenshot_run_response_200 = cls(
            batch_id=batch_id,
            job_id=job_id,
            status=status,
        )

        cancel_screenshot_run_response_200.additional_properties = d
        return cancel_screenshot_run_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
