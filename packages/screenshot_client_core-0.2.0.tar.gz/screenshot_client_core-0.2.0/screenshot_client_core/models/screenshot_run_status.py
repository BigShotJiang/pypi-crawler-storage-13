from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.screenshot_run_status_status import ScreenshotRunStatusStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="ScreenshotRunStatus")


@_attrs_define
class ScreenshotRunStatus:
    """
    Attributes:
        batch_id (str):
        job_id (str):
        status (ScreenshotRunStatusStatus):  Example: running.
        job_total (int | Unset): Total number of jobs in the batch Example: 100.
        job_completed (int | Unset): Number of completed jobs Example: 75.
        job_failed (int | Unset): Number of failed jobs Example: 2.
        concurrency (int | Unset): Concurrency level
        created_at (datetime.datetime | None | Unset): Timestamp when run was created
        updated_at (datetime.datetime | None | Unset): Timestamp of last update
        completed_at (datetime.datetime | None | Unset): Timestamp when run completed
        result_manifest_url (str | Unset): URL to fetch the result manifest
        error_message (str | Unset): Error message if status is 'failed'
    """

    batch_id: str
    job_id: str
    status: ScreenshotRunStatusStatus
    job_total: int | Unset = UNSET
    job_completed: int | Unset = UNSET
    job_failed: int | Unset = UNSET
    concurrency: int | Unset = UNSET
    created_at: datetime.datetime | None | Unset = UNSET
    updated_at: datetime.datetime | None | Unset = UNSET
    completed_at: datetime.datetime | None | Unset = UNSET
    result_manifest_url: str | Unset = UNSET
    error_message: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        batch_id = self.batch_id

        job_id = self.job_id

        status = self.status.value

        job_total = self.job_total

        job_completed = self.job_completed

        job_failed = self.job_failed

        concurrency = self.concurrency

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        elif isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        elif isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        completed_at: None | str | Unset
        if isinstance(self.completed_at, Unset):
            completed_at = UNSET
        elif isinstance(self.completed_at, datetime.datetime):
            completed_at = self.completed_at.isoformat()
        else:
            completed_at = self.completed_at

        result_manifest_url = self.result_manifest_url

        error_message = self.error_message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "batch_id": batch_id,
                "job_id": job_id,
                "status": status,
            }
        )
        if job_total is not UNSET:
            field_dict["job_total"] = job_total
        if job_completed is not UNSET:
            field_dict["job_completed"] = job_completed
        if job_failed is not UNSET:
            field_dict["job_failed"] = job_failed
        if concurrency is not UNSET:
            field_dict["concurrency"] = concurrency
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at
        if completed_at is not UNSET:
            field_dict["completed_at"] = completed_at
        if result_manifest_url is not UNSET:
            field_dict["result_manifest_url"] = result_manifest_url
        if error_message is not UNSET:
            field_dict["error_message"] = error_message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        batch_id = d.pop("batch_id")

        job_id = d.pop("job_id")

        status = ScreenshotRunStatusStatus(d.pop("status"))

        job_total = d.pop("job_total", UNSET)

        job_completed = d.pop("job_completed", UNSET)

        job_failed = d.pop("job_failed", UNSET)

        concurrency = d.pop("concurrency", UNSET)

        def _parse_created_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = isoparse(data)

                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        created_at = _parse_created_at(d.pop("created_at", UNSET))

        def _parse_updated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = isoparse(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        updated_at = _parse_updated_at(d.pop("updated_at", UNSET))

        def _parse_completed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                completed_at_type_0 = isoparse(data)

                return completed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        completed_at = _parse_completed_at(d.pop("completed_at", UNSET))

        result_manifest_url = d.pop("result_manifest_url", UNSET)

        error_message = d.pop("error_message", UNSET)

        screenshot_run_status = cls(
            batch_id=batch_id,
            job_id=job_id,
            status=status,
            job_total=job_total,
            job_completed=job_completed,
            job_failed=job_failed,
            concurrency=concurrency,
            created_at=created_at,
            updated_at=updated_at,
            completed_at=completed_at,
            result_manifest_url=result_manifest_url,
            error_message=error_message,
        )

        screenshot_run_status.additional_properties = d
        return screenshot_run_status

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
