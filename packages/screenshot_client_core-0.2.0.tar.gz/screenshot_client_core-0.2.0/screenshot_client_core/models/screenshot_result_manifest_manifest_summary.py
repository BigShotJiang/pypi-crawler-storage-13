from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.screenshot_result_manifest_manifest_summary_file_types import (
        ScreenshotResultManifestManifestSummaryFileTypes,
    )


T = TypeVar("T", bound="ScreenshotResultManifestManifestSummary")


@_attrs_define
class ScreenshotResultManifestManifestSummary:
    """Summary statistics for the result set

    Attributes:
        total_files (int): Total number of files in the result set Example: 6.
        total_size_bytes (int): Total size of all files in bytes Example: 1048576.
        file_types (ScreenshotResultManifestManifestSummaryFileTypes): Count of files by type Example: {'image': 3,
            'data': 3}.
    """

    total_files: int
    total_size_bytes: int
    file_types: ScreenshotResultManifestManifestSummaryFileTypes
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        total_files = self.total_files

        total_size_bytes = self.total_size_bytes

        file_types = self.file_types.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total_files": total_files,
                "total_size_bytes": total_size_bytes,
                "file_types": file_types,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.screenshot_result_manifest_manifest_summary_file_types import (
            ScreenshotResultManifestManifestSummaryFileTypes,
        )

        d = dict(src_dict)
        total_files = d.pop("total_files")

        total_size_bytes = d.pop("total_size_bytes")

        file_types = ScreenshotResultManifestManifestSummaryFileTypes.from_dict(d.pop("file_types"))

        screenshot_result_manifest_manifest_summary = cls(
            total_files=total_files,
            total_size_bytes=total_size_bytes,
            file_types=file_types,
        )

        screenshot_result_manifest_manifest_summary.additional_properties = d
        return screenshot_result_manifest_manifest_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
