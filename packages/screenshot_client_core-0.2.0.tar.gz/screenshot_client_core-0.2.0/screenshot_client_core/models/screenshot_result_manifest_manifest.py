from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.screenshot_result_manifest_manifest_files_item import ScreenshotResultManifestManifestFilesItem
    from ..models.screenshot_result_manifest_manifest_storage import ScreenshotResultManifestManifestStorage
    from ..models.screenshot_result_manifest_manifest_summary import ScreenshotResultManifestManifestSummary


T = TypeVar("T", bound="ScreenshotResultManifestManifest")


@_attrs_define
class ScreenshotResultManifestManifest:
    """Result manifest following 2025 REST API best practices with full URLs and metadata

    Attributes:
        files (list[ScreenshotResultManifestManifestFilesItem]): List of output files with full URLs and metadata
        storage (ScreenshotResultManifestManifestStorage | Unset): Storage provider metadata for Azure Blob Storage
        summary (ScreenshotResultManifestManifestSummary | Unset): Summary statistics for the result set
    """

    files: list[ScreenshotResultManifestManifestFilesItem]
    storage: ScreenshotResultManifestManifestStorage | Unset = UNSET
    summary: ScreenshotResultManifestManifestSummary | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        files = []
        for files_item_data in self.files:
            files_item = files_item_data.to_dict()
            files.append(files_item)

        storage: dict[str, Any] | Unset = UNSET
        if not isinstance(self.storage, Unset):
            storage = self.storage.to_dict()

        summary: dict[str, Any] | Unset = UNSET
        if not isinstance(self.summary, Unset):
            summary = self.summary.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "files": files,
            }
        )
        if storage is not UNSET:
            field_dict["storage"] = storage
        if summary is not UNSET:
            field_dict["summary"] = summary

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.screenshot_result_manifest_manifest_files_item import ScreenshotResultManifestManifestFilesItem
        from ..models.screenshot_result_manifest_manifest_storage import ScreenshotResultManifestManifestStorage
        from ..models.screenshot_result_manifest_manifest_summary import ScreenshotResultManifestManifestSummary

        d = dict(src_dict)
        files = []
        _files = d.pop("files")
        for files_item_data in _files:
            files_item = ScreenshotResultManifestManifestFilesItem.from_dict(files_item_data)

            files.append(files_item)

        _storage = d.pop("storage", UNSET)
        storage: ScreenshotResultManifestManifestStorage | Unset
        if isinstance(_storage, Unset):
            storage = UNSET
        else:
            storage = ScreenshotResultManifestManifestStorage.from_dict(_storage)

        _summary = d.pop("summary", UNSET)
        summary: ScreenshotResultManifestManifestSummary | Unset
        if isinstance(_summary, Unset):
            summary = UNSET
        else:
            summary = ScreenshotResultManifestManifestSummary.from_dict(_summary)

        screenshot_result_manifest_manifest = cls(
            files=files,
            storage=storage,
            summary=summary,
        )

        screenshot_result_manifest_manifest.additional_properties = d
        return screenshot_result_manifest_manifest

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
