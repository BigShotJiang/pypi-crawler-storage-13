from enum import Enum


class ScreenshotResultManifestManifestFilesItemType(str, Enum):
    DATA = "data"
    DOCUMENT = "document"
    IMAGE = "image"
    OTHER = "other"

    def __str__(self) -> str:
        return str(self.value)
