from enum import Enum


class ScreenshotRunStatusStatus(str, Enum):
    CANCELLED = "cancelled"
    CANCEL_REQUESTED = "cancel_requested"
    COMPLETED = "completed"
    FAILED = "failed"
    QUEUED = "queued"
    RUNNING = "running"

    def __str__(self) -> str:
        return str(self.value)
