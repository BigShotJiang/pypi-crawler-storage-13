from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.screenshot_options_wait_until import ScreenshotOptionsWaitUntil
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.screenshot_options_capture import ScreenshotOptionsCapture


T = TypeVar("T", bound="ScreenshotOptions")


@_attrs_define
class ScreenshotOptions:
    """Screenshot capture options

    Attributes:
        viewport_width (int | Unset): Viewport width in pixels Default: 1920.
        viewport_height (int | Unset): Viewport height in pixels Default: 1080.
        full_page (bool | Unset): Capture full scrollable page Default: True.
        wait_until (ScreenshotOptionsWaitUntil | Unset): Wait condition before screenshot Default:
            ScreenshotOptionsWaitUntil.LOAD.
        timeout (float | Unset): Page load timeout in seconds Default: 30.0.
        capture (ScreenshotOptionsCapture | Unset): Capture-specific options
    """

    viewport_width: int | Unset = 1920
    viewport_height: int | Unset = 1080
    full_page: bool | Unset = True
    wait_until: ScreenshotOptionsWaitUntil | Unset = ScreenshotOptionsWaitUntil.LOAD
    timeout: float | Unset = 30.0
    capture: ScreenshotOptionsCapture | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        viewport_width = self.viewport_width

        viewport_height = self.viewport_height

        full_page = self.full_page

        wait_until: str | Unset = UNSET
        if not isinstance(self.wait_until, Unset):
            wait_until = self.wait_until.value

        timeout = self.timeout

        capture: dict[str, Any] | Unset = UNSET
        if not isinstance(self.capture, Unset):
            capture = self.capture.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if viewport_width is not UNSET:
            field_dict["viewport_width"] = viewport_width
        if viewport_height is not UNSET:
            field_dict["viewport_height"] = viewport_height
        if full_page is not UNSET:
            field_dict["full_page"] = full_page
        if wait_until is not UNSET:
            field_dict["wait_until"] = wait_until
        if timeout is not UNSET:
            field_dict["timeout"] = timeout
        if capture is not UNSET:
            field_dict["capture"] = capture

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.screenshot_options_capture import ScreenshotOptionsCapture

        d = dict(src_dict)
        viewport_width = d.pop("viewport_width", UNSET)

        viewport_height = d.pop("viewport_height", UNSET)

        full_page = d.pop("full_page", UNSET)

        _wait_until = d.pop("wait_until", UNSET)
        wait_until: ScreenshotOptionsWaitUntil | Unset
        if isinstance(_wait_until, Unset):
            wait_until = UNSET
        else:
            wait_until = ScreenshotOptionsWaitUntil(_wait_until)

        timeout = d.pop("timeout", UNSET)

        _capture = d.pop("capture", UNSET)
        capture: ScreenshotOptionsCapture | Unset
        if isinstance(_capture, Unset):
            capture = UNSET
        else:
            capture = ScreenshotOptionsCapture.from_dict(_capture)

        screenshot_options = cls(
            viewport_width=viewport_width,
            viewport_height=viewport_height,
            full_page=full_page,
            wait_until=wait_until,
            timeout=timeout,
            capture=capture,
        )

        screenshot_options.additional_properties = d
        return screenshot_options

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
