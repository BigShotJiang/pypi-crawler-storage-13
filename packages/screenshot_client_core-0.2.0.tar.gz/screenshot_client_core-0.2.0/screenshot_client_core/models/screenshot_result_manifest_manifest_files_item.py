from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.screenshot_result_manifest_manifest_files_item_type import ScreenshotResultManifestManifestFilesItemType
from ..types import UNSET, Unset

T = TypeVar("T", bound="ScreenshotResultManifestManifestFilesItem")


@_attrs_define
class ScreenshotResultManifestManifestFilesItem:
    """
    Attributes:
        path (str): Relative path to file within the storage prefix Example: example-com/screenshot-desktop.png.
        type_ (ScreenshotResultManifestManifestFilesItemType): Generic file category inferred from extension Example:
            image.
        content_type (str): MIME content type Example: image/png.
        size_bytes (int): File size in bytes Example: 245680.
        url (str | Unset): Full HTTPS URL to download the file directly from blob storage Example:
            https://crawlsitedata.blob.core.windows.net/screenshot-
            output/runs/crawl-2025-01-18/550e8400-e29b-41d4-a716-446655440000/screens/example-com/screenshot-desktop.png.
    """

    path: str
    type_: ScreenshotResultManifestManifestFilesItemType
    content_type: str
    size_bytes: int
    url: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        path = self.path

        type_ = self.type_.value

        content_type = self.content_type

        size_bytes = self.size_bytes

        url = self.url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "path": path,
                "type": type_,
                "content_type": content_type,
                "size_bytes": size_bytes,
            }
        )
        if url is not UNSET:
            field_dict["url"] = url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        path = d.pop("path")

        type_ = ScreenshotResultManifestManifestFilesItemType(d.pop("type"))

        content_type = d.pop("content_type")

        size_bytes = d.pop("size_bytes")

        url = d.pop("url", UNSET)

        screenshot_result_manifest_manifest_files_item = cls(
            path=path,
            type_=type_,
            content_type=content_type,
            size_bytes=size_bytes,
            url=url,
        )

        screenshot_result_manifest_manifest_files_item.additional_properties = d
        return screenshot_result_manifest_manifest_files_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
