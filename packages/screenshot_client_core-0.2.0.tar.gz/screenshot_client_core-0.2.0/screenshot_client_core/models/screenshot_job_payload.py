from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.screenshot_job_payload_metadata import ScreenshotJobPayloadMetadata
    from ..models.screenshot_options import ScreenshotOptions


T = TypeVar("T", bound="ScreenshotJobPayload")


@_attrs_define
class ScreenshotJobPayload:
    """
    Attributes:
        job_id (str): Unique identifier for this job Example: example-com-abc123.
        url (str): URL to screenshot Example: https://example.com.
        options (ScreenshotOptions | Unset): Screenshot capture options
        partition_date (datetime.date | Unset): Optional partition date for output organization Example: 2025-01-18.
        html_snapshot_path (str | Unset): Optional path to HTML snapshot file
        metadata (ScreenshotJobPayloadMetadata | Unset): Arbitrary metadata attached to the job
    """

    job_id: str
    url: str
    options: ScreenshotOptions | Unset = UNSET
    partition_date: datetime.date | Unset = UNSET
    html_snapshot_path: str | Unset = UNSET
    metadata: ScreenshotJobPayloadMetadata | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        job_id = self.job_id

        url = self.url

        options: dict[str, Any] | Unset = UNSET
        if not isinstance(self.options, Unset):
            options = self.options.to_dict()

        partition_date: str | Unset = UNSET
        if not isinstance(self.partition_date, Unset):
            partition_date = self.partition_date.isoformat()

        html_snapshot_path = self.html_snapshot_path

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "job_id": job_id,
                "url": url,
            }
        )
        if options is not UNSET:
            field_dict["options"] = options
        if partition_date is not UNSET:
            field_dict["partition_date"] = partition_date
        if html_snapshot_path is not UNSET:
            field_dict["html_snapshot_path"] = html_snapshot_path
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.screenshot_job_payload_metadata import ScreenshotJobPayloadMetadata
        from ..models.screenshot_options import ScreenshotOptions

        d = dict(src_dict)
        job_id = d.pop("job_id")

        url = d.pop("url")

        _options = d.pop("options", UNSET)
        options: ScreenshotOptions | Unset
        if isinstance(_options, Unset):
            options = UNSET
        else:
            options = ScreenshotOptions.from_dict(_options)

        _partition_date = d.pop("partition_date", UNSET)
        partition_date: datetime.date | Unset
        if isinstance(_partition_date, Unset):
            partition_date = UNSET
        else:
            partition_date = isoparse(_partition_date).date()

        html_snapshot_path = d.pop("html_snapshot_path", UNSET)

        _metadata = d.pop("metadata", UNSET)
        metadata: ScreenshotJobPayloadMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = ScreenshotJobPayloadMetadata.from_dict(_metadata)

        screenshot_job_payload = cls(
            job_id=job_id,
            url=url,
            options=options,
            partition_date=partition_date,
            html_snapshot_path=html_snapshot_path,
            metadata=metadata,
        )

        screenshot_job_payload.additional_properties = d
        return screenshot_job_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
