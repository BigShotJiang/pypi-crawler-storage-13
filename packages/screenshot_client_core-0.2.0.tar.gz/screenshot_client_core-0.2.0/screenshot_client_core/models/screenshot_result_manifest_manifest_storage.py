from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.screenshot_result_manifest_manifest_storage_provider import (
    ScreenshotResultManifestManifestStorageProvider,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="ScreenshotResultManifestManifestStorage")


@_attrs_define
class ScreenshotResultManifestManifestStorage:
    """Storage provider metadata for Azure Blob Storage

    Attributes:
        provider (ScreenshotResultManifestManifestStorageProvider): Storage provider type Example: azure_blob.
        prefix (str): Blob path prefix for all files in this run Example:
            runs/crawl-2025-01-18/550e8400-e29b-41d4-a716-446655440000/screens.
        container (str | Unset): Azure Blob Storage container name Example: screenshot-output.
    """

    provider: ScreenshotResultManifestManifestStorageProvider
    prefix: str
    container: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        provider = self.provider.value

        prefix = self.prefix

        container = self.container

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "provider": provider,
                "prefix": prefix,
            }
        )
        if container is not UNSET:
            field_dict["container"] = container

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        provider = ScreenshotResultManifestManifestStorageProvider(d.pop("provider"))

        prefix = d.pop("prefix")

        container = d.pop("container", UNSET)

        screenshot_result_manifest_manifest_storage = cls(
            provider=provider,
            prefix=prefix,
            container=container,
        )

        screenshot_result_manifest_manifest_storage.additional_properties = d
        return screenshot_result_manifest_manifest_storage

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
