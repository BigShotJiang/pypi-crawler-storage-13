from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.screenshot_run_handle_status import ScreenshotRunHandleStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="ScreenshotRunHandle")


@_attrs_define
class ScreenshotRunHandle:
    """
    Attributes:
        batch_id (str): Batch identifier Example: crawl-2025-01-18.
        job_id (str): Unique job run identifier (hex string without dashes) Example: 550e8400e29b41d4a716446655440000.
        status (ScreenshotRunHandleStatus): Initial status of the run Example: queued.
        status_url (str): URL to poll for status updates Example: https://example.com/api/screenshot-
            batches/crawl-2025-01-18/runs/550e8400-e29b-41d4-a716-446655440000.
        cancel_url (str | Unset): URL to cancel the run
        result_url (str | Unset): URL to fetch results when completed
        concurrency (int | Unset): Number of concurrent jobs
        instance_id (str | Unset): Azure Durable Functions instance ID
    """

    batch_id: str
    job_id: str
    status: ScreenshotRunHandleStatus
    status_url: str
    cancel_url: str | Unset = UNSET
    result_url: str | Unset = UNSET
    concurrency: int | Unset = UNSET
    instance_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        batch_id = self.batch_id

        job_id = self.job_id

        status = self.status.value

        status_url = self.status_url

        cancel_url = self.cancel_url

        result_url = self.result_url

        concurrency = self.concurrency

        instance_id = self.instance_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "batch_id": batch_id,
                "job_id": job_id,
                "status": status,
                "status_url": status_url,
            }
        )
        if cancel_url is not UNSET:
            field_dict["cancel_url"] = cancel_url
        if result_url is not UNSET:
            field_dict["result_url"] = result_url
        if concurrency is not UNSET:
            field_dict["concurrency"] = concurrency
        if instance_id is not UNSET:
            field_dict["instance_id"] = instance_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        batch_id = d.pop("batch_id")

        job_id = d.pop("job_id")

        status = ScreenshotRunHandleStatus(d.pop("status"))

        status_url = d.pop("status_url")

        cancel_url = d.pop("cancel_url", UNSET)

        result_url = d.pop("result_url", UNSET)

        concurrency = d.pop("concurrency", UNSET)

        instance_id = d.pop("instance_id", UNSET)

        screenshot_run_handle = cls(
            batch_id=batch_id,
            job_id=job_id,
            status=status,
            status_url=status_url,
            cancel_url=cancel_url,
            result_url=result_url,
            concurrency=concurrency,
            instance_id=instance_id,
        )

        screenshot_run_handle.additional_properties = d
        return screenshot_run_handle

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
