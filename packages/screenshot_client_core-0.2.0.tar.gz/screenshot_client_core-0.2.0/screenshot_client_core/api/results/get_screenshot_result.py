from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_response import ErrorResponse
from ...models.screenshot_result_manifest import ScreenshotResultManifest
from ...types import Response


def _get_kwargs(
    batch_id: str,
    job_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": f"/api/screenshot-batches/{batch_id}/runs/{job_id}/result",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorResponse | ScreenshotResultManifest | None:
    if response.status_code == 200:
        response_200 = ScreenshotResultManifest.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())

        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorResponse | ScreenshotResultManifest]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[ErrorResponse | ScreenshotResultManifest]:
    """Get result manifest for a completed run

     Retrieve the result manifest containing references to output artifacts
    in blob storage. Only available for completed runs.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ScreenshotResultManifest]
    """

    kwargs = _get_kwargs(
        batch_id=batch_id,
        job_id=job_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> ErrorResponse | ScreenshotResultManifest | None:
    """Get result manifest for a completed run

     Retrieve the result manifest containing references to output artifacts
    in blob storage. Only available for completed runs.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ScreenshotResultManifest
    """

    return sync_detailed(
        batch_id=batch_id,
        job_id=job_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[ErrorResponse | ScreenshotResultManifest]:
    """Get result manifest for a completed run

     Retrieve the result manifest containing references to output artifacts
    in blob storage. Only available for completed runs.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ScreenshotResultManifest]
    """

    kwargs = _get_kwargs(
        batch_id=batch_id,
        job_id=job_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> ErrorResponse | ScreenshotResultManifest | None:
    """Get result manifest for a completed run

     Retrieve the result manifest containing references to output artifacts
    in blob storage. Only available for completed runs.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ScreenshotResultManifest
    """

    return (
        await asyncio_detailed(
            batch_id=batch_id,
            job_id=job_id,
            client=client,
        )
    ).parsed
