from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cancel_screenshot_run_response_200 import CancelScreenshotRunResponse200
from ...models.error_response import ErrorResponse
from ...types import Response


def _get_kwargs(
    batch_id: str,
    job_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": f"/api/screenshot-batches/{batch_id}/runs/{job_id}",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CancelScreenshotRunResponse200 | ErrorResponse | None:
    if response.status_code == 200:
        response_200 = CancelScreenshotRunResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())

        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CancelScreenshotRunResponse200 | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[CancelScreenshotRunResponse200 | ErrorResponse]:
    """Cancel a screenshot batch run

     Request cancellation of an in-flight run.
    The run will stop processing new jobs but may not stop immediately.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CancelScreenshotRunResponse200 | ErrorResponse]
    """

    kwargs = _get_kwargs(
        batch_id=batch_id,
        job_id=job_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> CancelScreenshotRunResponse200 | ErrorResponse | None:
    """Cancel a screenshot batch run

     Request cancellation of an in-flight run.
    The run will stop processing new jobs but may not stop immediately.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CancelScreenshotRunResponse200 | ErrorResponse
    """

    return sync_detailed(
        batch_id=batch_id,
        job_id=job_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[CancelScreenshotRunResponse200 | ErrorResponse]:
    """Cancel a screenshot batch run

     Request cancellation of an in-flight run.
    The run will stop processing new jobs but may not stop immediately.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CancelScreenshotRunResponse200 | ErrorResponse]
    """

    kwargs = _get_kwargs(
        batch_id=batch_id,
        job_id=job_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> CancelScreenshotRunResponse200 | ErrorResponse | None:
    """Cancel a screenshot batch run

     Request cancellation of an in-flight run.
    The run will stop processing new jobs but may not stop immediately.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CancelScreenshotRunResponse200 | ErrorResponse
    """

    return (
        await asyncio_detailed(
            batch_id=batch_id,
            job_id=job_id,
            client=client,
        )
    ).parsed
