from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_response import ErrorResponse
from ...models.screenshot_run_status import ScreenshotRunStatus
from ...types import Response


def _get_kwargs(
    batch_id: str,
    job_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": f"/api/screenshot-batches/{batch_id}/runs/{job_id}",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorResponse | ScreenshotRunStatus | None:
    if response.status_code == 200:
        response_200 = ScreenshotRunStatus.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())

        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorResponse | ScreenshotRunStatus]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[ErrorResponse | ScreenshotRunStatus]:
    """Get status of a screenshot batch run

     Fetch the current status and metadata for a specific run.
    Poll this endpoint to track progress.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ScreenshotRunStatus]
    """

    kwargs = _get_kwargs(
        batch_id=batch_id,
        job_id=job_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> ErrorResponse | ScreenshotRunStatus | None:
    """Get status of a screenshot batch run

     Fetch the current status and metadata for a specific run.
    Poll this endpoint to track progress.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ScreenshotRunStatus
    """

    return sync_detailed(
        batch_id=batch_id,
        job_id=job_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[ErrorResponse | ScreenshotRunStatus]:
    """Get status of a screenshot batch run

     Fetch the current status and metadata for a specific run.
    Poll this endpoint to track progress.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ScreenshotRunStatus]
    """

    kwargs = _get_kwargs(
        batch_id=batch_id,
        job_id=job_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    batch_id: str,
    job_id: str,
    *,
    client: AuthenticatedClient,
) -> ErrorResponse | ScreenshotRunStatus | None:
    """Get status of a screenshot batch run

     Fetch the current status and metadata for a specific run.
    Poll this endpoint to track progress.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        job_id (str):  Example: 550e8400e29b41d4a716446655440000.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ScreenshotRunStatus
    """

    return (
        await asyncio_detailed(
            batch_id=batch_id,
            job_id=job_id,
            client=client,
        )
    ).parsed
