from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_response import ErrorResponse
from ...models.screenshot_batch_request import ScreenshotBatchRequest
from ...models.screenshot_run_handle import ScreenshotRunHandle
from ...types import Response


def _get_kwargs(
    batch_id: str,
    *,
    body: ScreenshotBatchRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": f"/api/screenshot-batches/{batch_id}/runs",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorResponse | ScreenshotRunHandle | None:
    if response.status_code == 202:
        response_202 = ScreenshotRunHandle.from_dict(response.json())

        return response_202

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorResponse | ScreenshotRunHandle]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    batch_id: str,
    *,
    client: AuthenticatedClient,
    body: ScreenshotBatchRequest,
) -> Response[ErrorResponse | ScreenshotRunHandle]:
    """Start a new screenshot batch run

     Submit a batch of screenshot jobs for asynchronous processing.
    Returns immediately with a job handle for polling status.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        body (ScreenshotBatchRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ScreenshotRunHandle]
    """

    kwargs = _get_kwargs(
        batch_id=batch_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    batch_id: str,
    *,
    client: AuthenticatedClient,
    body: ScreenshotBatchRequest,
) -> ErrorResponse | ScreenshotRunHandle | None:
    """Start a new screenshot batch run

     Submit a batch of screenshot jobs for asynchronous processing.
    Returns immediately with a job handle for polling status.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        body (ScreenshotBatchRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ScreenshotRunHandle
    """

    return sync_detailed(
        batch_id=batch_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    batch_id: str,
    *,
    client: AuthenticatedClient,
    body: ScreenshotBatchRequest,
) -> Response[ErrorResponse | ScreenshotRunHandle]:
    """Start a new screenshot batch run

     Submit a batch of screenshot jobs for asynchronous processing.
    Returns immediately with a job handle for polling status.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        body (ScreenshotBatchRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | ScreenshotRunHandle]
    """

    kwargs = _get_kwargs(
        batch_id=batch_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    batch_id: str,
    *,
    client: AuthenticatedClient,
    body: ScreenshotBatchRequest,
) -> ErrorResponse | ScreenshotRunHandle | None:
    """Start a new screenshot batch run

     Submit a batch of screenshot jobs for asynchronous processing.
    Returns immediately with a job handle for polling status.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        body (ScreenshotBatchRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | ScreenshotRunHandle
    """

    return (
        await asyncio_detailed(
            batch_id=batch_id,
            client=client,
            body=body,
        )
    ).parsed
