from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_response import ErrorResponse
from ...models.run_list_response import RunListResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    batch_id: str,
    *,
    limit: int | Unset = 50,
    continuation: str | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["limit"] = limit

    params["continuation"] = continuation

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": f"/api/screenshot-batches/{batch_id}/runs",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorResponse | RunListResponse | None:
    if response.status_code == 200:
        response_200 = RunListResponse.from_dict(response.json())

        return response_200

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorResponse | RunListResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    batch_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
    continuation: str | Unset = UNSET,
) -> Response[ErrorResponse | RunListResponse]:
    """List all runs for a batch

     Retrieve a paginated list of all runs associated with a batch.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        limit (int | Unset):  Default: 50.
        continuation (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | RunListResponse]
    """

    kwargs = _get_kwargs(
        batch_id=batch_id,
        limit=limit,
        continuation=continuation,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    batch_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
    continuation: str | Unset = UNSET,
) -> ErrorResponse | RunListResponse | None:
    """List all runs for a batch

     Retrieve a paginated list of all runs associated with a batch.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        limit (int | Unset):  Default: 50.
        continuation (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | RunListResponse
    """

    return sync_detailed(
        batch_id=batch_id,
        client=client,
        limit=limit,
        continuation=continuation,
    ).parsed


async def asyncio_detailed(
    batch_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
    continuation: str | Unset = UNSET,
) -> Response[ErrorResponse | RunListResponse]:
    """List all runs for a batch

     Retrieve a paginated list of all runs associated with a batch.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        limit (int | Unset):  Default: 50.
        continuation (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | RunListResponse]
    """

    kwargs = _get_kwargs(
        batch_id=batch_id,
        limit=limit,
        continuation=continuation,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    batch_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
    continuation: str | Unset = UNSET,
) -> ErrorResponse | RunListResponse | None:
    """List all runs for a batch

     Retrieve a paginated list of all runs associated with a batch.

    Args:
        batch_id (str):  Example: crawl-2025-01-18.
        limit (int | Unset):  Default: 50.
        continuation (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | RunListResponse
    """

    return (
        await asyncio_detailed(
            batch_id=batch_id,
            client=client,
            limit=limit,
            continuation=continuation,
        )
    ).parsed
