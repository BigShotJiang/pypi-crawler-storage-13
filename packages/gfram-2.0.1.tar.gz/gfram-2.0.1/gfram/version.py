"""
GFRAM - Geometric Face Recognition and Matching
Version information
"""

__version__ = "2.0.0"
__author__ = "Ortiqova F.S"
__description__ = "Professional geometric face recognition library with AI-powered matching"
__license__ = "MIT"