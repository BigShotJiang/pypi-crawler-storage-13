"""
High-level API for face recognition.
"""

from .recognizer import Recognizer

__all__ = [
    'Recognizer',
]