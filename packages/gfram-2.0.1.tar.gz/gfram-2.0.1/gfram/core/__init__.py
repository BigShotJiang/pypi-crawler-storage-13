"""
Core module for GFRAM.
"""

# Core components will be imported here if needed
# For now, this module is a placeholder for future core functionality

__all__ = []