# Pyarmor 9.2.0 (basic), 009672, 2025-11-20T16:35:49.401631
from .pyarmor_runtime import __pyarmor__
