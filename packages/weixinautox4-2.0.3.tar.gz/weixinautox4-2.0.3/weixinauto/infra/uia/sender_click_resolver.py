# sender_click_resolver.py
# -*- coding: utf-8 -*-

import time
from typing import Optional, Tuple
import uiautomation as uia
from .nickname_reader import read_nickname_from_popup_hwnd, popup_hwnd_quick_by_pid
from .utils_win import send_escape_to_hwnd
from weixinauto.infra.uia.avatar_clicker import AvatarClicker

# ============= 全局参数（按你的要求） =============
FAST_CHECK_STEPS = [0.00, 0.03, 0.05, 0.06, 0.08, 0.10]


class SenderClickResolver:
    """稳定点击头像 → 获取资料卡昵称"""

    def __init__(self):
        self.clicker = AvatarClicker()

    def resolve_by_click(
            self,
            win: uia.Control,
            item: uia.Control,
            *,
            close_after: bool = True
    ) -> Tuple[Optional[bool], Optional[str]]:
        """
        通过点击头像 → 读取昵称 → 决定是否是自己发的消息：
          - 读到昵称 => 别人(False), sender=昵称
          - 读不到昵称 => 自己(True), sender=None
        """

        nick: Optional[str] = None
        try:
            # 第一次点击头像（不看返回值，不等待）
            try:
                self.clicker.simulate_click_avatar(win,item)
            except Exception:
                pass

            pid = self._get_pid(win) or self._get_pid(item)
            popup_hwnd = 0
            # 快速检查资料卡弹窗
            for dt in FAST_CHECK_STEPS:
                if dt > 0:
                    time.sleep(dt)
                popup_hwnd = popup_hwnd_quick_by_pid(pid) if pid else 0
                if popup_hwnd:
                    break

            # 3A) 没有弹窗 => 直接判定“自己”，不再点击第二下
            if not popup_hwnd:
                return True, None
            # 尝试从资料卡弹层读取昵称
            nick = read_nickname_from_popup_hwnd(popup_hwnd)

            # 如果获取到昵称，执行ESC关闭资料卡
            if nick and close_after:
                self.close_popup_with_escape(popup_hwnd)

            # 返回结果
            return (False, nick) if nick else (True, None)

        except Exception as e:
            return None, None

    def close_popup_with_escape(self, popup_hwnd: int) -> None:
        """ 使用 ESC 关闭资料卡弹窗 """
        try:
            send_escape_to_hwnd(popup_hwnd)  # 发送 ESC 键
        except Exception as e:
            print(f"关闭弹窗时出现错误: {e}")

    def _get_pid(self, ctrl: uia.Control) -> int:
        """ 获取控件的进程ID """
        try:
            return int(getattr(ctrl, "ProcessId", 0) or 0)
        except Exception:
            return 0
