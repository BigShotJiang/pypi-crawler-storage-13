# message_actions.py
from __future__ import annotations

import os
import time
import shutil
from typing import Optional, List

import uiautomation as uia
from PIL import Image, ImageGrab

from .utils_win import bring_to_front, get_hwnd_from_ctrl
from .message import ChatMessage, MessageAction
from .message_extract import MessageType
from .wechat_driver import WeChatDriver
from .wx_subwindow_ops import ChatSubWindowOps  # ✅ 统一使用这里封装好的右键+复制逻辑


# ====== 与 chat_listener 同一套路的工具函数 ======

def _runtime_id_hex(node) -> Optional[str]:
    """把 RuntimeId 转成可对比的十六进制字符串。"""
    try:
        rid = node.GetRuntimeId()
        if rid:
            return ".".join(f"{int(v):X}" for v in rid)
    except Exception:
        pass
    try:
        rid = getattr(node, "RuntimeId", None)
        if isinstance(rid, (list, tuple)) and rid:
            return ".".join(f"{int(v):X}" for v in rid)
    except Exception:
        pass
    return None


def _scroll_into_view(node) -> None:
    """保证消息项滚动到可见区域。"""
    try:
        sp = node.GetScrollItemPattern()
        if sp:
            sp.ScrollIntoView()
            return
    except Exception:
        pass
    try:
        node.SetFocus()
    except Exception:
        pass


def _bfs_children(root: uia.Control, max_nodes: int = 8000):
    """简单 BFS，用于在子窗口里按 RuntimeId 兜底查找。"""
    q: List[uia.Control] = [root]
    seen = 0
    while q and seen < max_nodes:
        n = q.pop(0)
        seen += 1
        yield n
        try:
            ch = n.GetChildren()
            if ch:
                q.extend(ch)
        except Exception:
            pass
def _has_wechat_xmenu_open(max_nodes: int = 3000) -> bool:
    """
    粗略判断当前 UI 树里是否存在微信的弹出菜单：
      - ControlTypeName == 'MenuControl'
      - ClassName 包含 'XMenu'
    """
    try:
        root = uia.GetRootControl()
    except Exception:
        return False

    for n in _bfs_children(root, max_nodes=max_nodes):
        try:
            ctn = (getattr(n, "ControlTypeName", "") or "").strip()
            cls = (getattr(n, "ClassName", "") or "").strip()
        except Exception:
            continue

        if ctn == "MenuControl" and "XMenu" in cls:
            return True
    return False


def _find_same_node_in_window_by_runtime_id(
    win: uia.Control,
    target_node: uia.Control,
    max_nodes: int = 4000,
) -> Optional[uia.Control]:
    """
    在当前聊天子窗口 win 内，按 RuntimeId 找到一个与 target_node 相同的控件。
    - 只在 target_node 已经失效时当作兜底使用
    """
    target_rid = _runtime_id_hex(target_node)
    if not target_rid:
        return None

    for n in _bfs_children(win, max_nodes=max_nodes):
        rid = _runtime_id_hex(n)
        if rid and rid == target_rid:
            return n
    return None


def _ensure_weixin_file_dir(base_dir: Optional[str] = None) -> str:
    """
    确保 weixin_file 目录存在：
      - 不传 base_dir：默认当前工作目录
      - 返回绝对路径
    """
    if not base_dir:
        base_dir = os.getcwd()
    dest = os.path.join(base_dir, "weixin_file")
    os.makedirs(dest, exist_ok=True)
    return dest


def save_from_clipboard_to_weixin_file(
    *,
    base_dir: Optional[str] = None,
    prefix: str = "",
    max_retry: int = 10,
    retry_delay: float = 0.1,
) -> List[str]:
    """
    从剪贴板中读取图片/文件，并保存到 weixin_file 目录。
    - 支持微信复制后的「延迟写入」：会重试多次读取剪贴板。
    - 返回保存后的真实路径列表（0/1/N 个）。
    """
    dest_root = _ensure_weixin_file_dir(base_dir)
    ts = int(time.time() * 1000)
    saved: List[str] = []

    obj = None

    # ---- 重点：循环等待微信把数据放到剪贴板里 ----
    for _ in range(max_retry):
        try:
            obj = ImageGrab.grabclipboard()
        except Exception:
            obj = None

        # 只要看到图片或文件列表就退出循环
        if isinstance(obj, Image.Image) or isinstance(obj, list):
            break

        time.sleep(retry_delay)

    if obj is None:
        return saved

    # ---- 1) 图片：直接保存为 PNG ----
    if isinstance(obj, Image.Image):
        fname = f"{prefix or 'img'}_{ts}.png"
        fpath = os.path.join(dest_root, fname)
        try:
            obj.save(fpath)
            saved.append(fpath)
        except Exception:
            return saved
        return saved

    # ---- 2) 文件列表（CF_HDROP）：复制文件 ----
    if isinstance(obj, list):
        for src in obj:
            if not isinstance(src, str):
                continue
            if not os.path.isfile(src):
                continue

            base = os.path.basename(src)
            dst = os.path.join(dest_root, base)

            # 避免覆盖：同名就加一个时间后缀
            if os.path.exists(dst):
                name, ext = os.path.splitext(base)
                dst = os.path.join(dest_root, f"{name}_{ts}{ext}")

            try:
                shutil.copy2(src, dst)
                saved.append(dst)
            except Exception:
                return saved

    return saved


# ============ 默认实现：挂在 ChatMessage.actions 上 ============

class DefaultMessageActions(MessageAction):
    """
    默认消息操作（重构版）：
      - save_image / save_file 直接接收 UI 控件 item: uia.Control
      - 统一使用 wx_subwindow_ops.ChatSubWindowOps.copy_item_via_menu 做：
          右键 + 菜单里点『复制』
      - 本文件只负责：
          * 通过 RuntimeId 兜底找到节点
          * 置前 + 滚动到可见
          * 用 save_from_clipboard_to_weixin_file 从剪贴板保存到 weixin_file
    """

    def __init__(self, driver: WeChatDriver, title: str, base_dir: Optional[str] = None):
        self._driver = driver
        self._title = title
        self._base_dir = base_dir

    # ------ 内部：解析成可用节点 ------

    def _resolve_node(self, item: uia.Control) -> Optional[uia.Control]:
        """
        尝试把传入的 item 解析成当前可用的消息节点：
          1. 若 item 还存活（Exists=True），直接用；
          2. 否则在当前聊天子窗内按 RuntimeId 重新定位；
        """
        if not item:
            print("[MessageActions] _resolve_node: item 为空")
            return None

        try:
            if item.Exists(0, 0):
                return item
        except Exception:
            pass

        # item 已失效：尝试在当前聊天子窗内按 RuntimeId 重新定位
        try:
            win = self._driver.find_chat_subwindow(self._title, timeout_sec=1.0)
        except Exception as e:
            print(f"[MessageActions] _resolve_node: 查找聊天子窗失败: {e}")
            return None

        if not win:
            print("[MessageActions] _resolve_node: 未找到聊天子窗")
            return None

        node = _find_same_node_in_window_by_runtime_id(win, item)
        if not node:
            print("[MessageActions] _resolve_node: 按 RuntimeId 也未找到对应节点")
        return node

    def _prepare_for_context_menu(self, node: uia.Control) -> None:
        """
        主窗置前 + 滚动到可见（不右键，不点菜单）
        右键 + 点击『复制』由 ChatSubWindowOps.copy_item_via_menu 负责。
        """
        try:
            win = self._driver.find_chat_subwindow(self._title, timeout_sec=1.0)
        except Exception:
            win = None

        if win:
            hwnd = get_hwnd_from_ctrl(win)
            if hwnd:
                bring_to_front(hwnd, gentle=True)
                time.sleep(0.08)

        _scroll_into_view(node)
        time.sleep(0.05)

    def _resolve_node_from_item_or_msg(
        self,
        item: Optional[uia.Control],
        msg: Optional[ChatMessage] = None,
    ) -> Optional[uia.Control]:
        """
        优先使用 item，其次使用 msg._node；
        若控件已失效，则在当前聊天子窗内按 RuntimeId 做一次局部查找。
        """
        node = item
        if node is None and msg is not None:
            node = getattr(msg, "_node", None)

        if not node:
            print("[MessageActions] _resolve_node: item 和 msg._node 都为空")
            return None

        # 如果还活着，直接用
        try:
            if node.Exists(0, 0):
                return node
        except Exception:
            pass

        # 尝试按 RuntimeId 在当前子窗里重找
        try:
            win = self._driver.find_chat_subwindow(self._title, timeout_sec=1.0)
        except Exception as e:
            print(f"[MessageActions] _resolve_node: 查找聊天子窗失败: {e}")
            return None

        if not win:
            print("[MessageActions] _resolve_node: 未找到聊天子窗")
            return None

        new_node = _find_same_node_in_window_by_runtime_id(win, node)
        if not new_node:
            print("[MessageActions] _resolve_node: 按 RuntimeId 也未找到对应节点")
        return new_node

    # ------ 对外能力：保存图片 / 文件（以 item 为核心） ------

    def save_image(
        self,
        msg: ChatMessage,
        item: Optional[uia.Control] = None,
        base_dir: Optional[str] = None,
        *,
        max_try: int = 3,           # 右键+复制最多尝试次数
        retry_delay: float = 0.15,  # 每次失败后的等待间隔
        x_ratio: float = 0.12,      # 与 chat_listener 保持一致的右键位置比例
        y_ratio: float = 0.18,
    ) -> Optional[str]:
        """
        保存图片消息：
          - msg: ChatMessage，用于类型校验、日志、以及 msg._node 兜底。
          - item: 当前这条图片消息对应的 UI 控件（可选，传了优先用）。
          - base_dir: 自定义保存根目录（不传则用初始化时的 base_dir）。
          - max_try: 若未找到『复制』或剪贴板为空，最多重试几次。
        """
        if msg.mtype != MessageType.IMAGE:
            print("[MessageActions] save_image: ChatMessage.mtype 不是 IMAGE，但仍按图片处理")

        node = self._resolve_node_from_item_or_msg(item, msg)
        if not node:
            print("[MessageActions] save_image: 找不到图片消息节点")
            return None

        last_reason = ""

        for attempt in range(1, max(1, int(max_try)) + 1):
            # 1) 置前 + 滚动可见
            self._prepare_for_context_menu(node)

            # 2) 右键 + 菜单中点『复制』（统一由 ChatSubWindowOps 处理）
            ok = ChatSubWindowOps.copy_item_via_menu(
                node,
                x_ratio=x_ratio,
                y_ratio=y_ratio,
                timeout_sec=0.3,
            )
            if not ok:
                last_reason = "no_copy"
                print(f"[MessageActions] save_image: 第 {attempt} 次未成功触发『复制』菜单")
            else:
                # 3) 复制成功后，从剪贴板保存
                saved = save_from_clipboard_to_weixin_file(
                    base_dir=base_dir or self._base_dir,
                    prefix="img",
                )
                if saved:
                    path = saved[0]
                    print(f"[MessageActions] save_image 完成(第 {attempt} 次): {path}")
                    return path

                last_reason = "empty_clipboard"
                print(f"[MessageActions] save_image: 第 {attempt} 次剪贴板中没有图片或保存失败")

            if attempt < max_try:
                try:
                    if _has_wechat_xmenu_open():
                        # 这里用 uia.SendKeys 给当前前台窗口发一个 Esc 就行
                        uia.SendKeys("{Esc}")
                        time.sleep(0.08)
                except Exception:
                    pass
                time.sleep(retry_delay)

        print(f"[MessageActions] save_image: 连续 {max_try} 次失败，最后原因={last_reason or 'unknown'}")
        return None

    def save_file(
        self,
        msg: ChatMessage,
        item: Optional[uia.Control] = None,
        base_dir: Optional[str] = None,
        *,
        max_try: int = 3,           # 右键+复制最多尝试次数
        retry_delay: float = 0.15,  # 每次失败后的等待间隔
        x_ratio: float = 0.15,
        y_ratio: float = 0.18,
    ) -> Optional[str]:
        """
        保存文件消息：
          - msg: ChatMessage，用于类型校验、日志、以及 msg._node 兜底。
          - item: 当前这条文件消息对应的 UI 控件（可选，传了优先用）。
          - base_dir: 自定义保存根目录（不传则用初始化时的 base_dir）。
          - max_try: 若未找到『复制』或剪贴板为空，最多重试几次。
        """
        if msg.mtype != MessageType.FILE:
            print("[MessageActions] save_file: ChatMessage.mtype 不是 FILE，但仍按文件处理")

        node = self._resolve_node_from_item_or_msg(item, msg)
        if not node:
            print("[MessageActions] save_file: 找不到文件消息节点")
            return None

        last_reason = ""

        for attempt in range(1, max(1, int(max_try)) + 1):
            # 1) 置前 + 滚动可见
            self._prepare_for_context_menu(node)

            # 2) 右键 + 菜单中点『复制』
            ok = ChatSubWindowOps.copy_item_via_menu(
                node,
                x_ratio=x_ratio,
                y_ratio=y_ratio,
                timeout_sec=2.0,
            )
            if not ok:
                last_reason = "no_copy"
                print(f"[MessageActions] save_file: 第 {attempt} 次未成功触发『复制』菜单")
            else:
                # 3) 复制成功后，从剪贴板保存
                saved = save_from_clipboard_to_weixin_file(
                    base_dir=base_dir or self._base_dir,
                    prefix="file",
                )
                if saved:
                    path = saved[0]
                    print(f"[MessageActions] save_file 完成(第 {attempt} 次): {path}")
                    return path

                last_reason = "empty_clipboard"
                print(f"[MessageActions] save_file: 第 {attempt} 次剪贴板中没有文件或保存失败")

            if attempt < max_try:
                try:
                    if _has_wechat_xmenu_open():
                        # 这里用 uia.SendKeys 给当前前台窗口发一个 Esc 就行
                        uia.SendKeys("{Esc}")
                        time.sleep(0.08)
                except Exception:
                    pass
                time.sleep(retry_delay)

        print(f"[MessageActions] save_file: 连续 {max_try} 次失败，最后原因={last_reason or 'unknown'}")
        return None
