# -*- coding: utf-8 -*-
# wechat_driver.py
from __future__ import annotations

import os
import time
import ctypes
import struct
import uiautomation as uia
from ctypes import wintypes
from typing import Optional, Dict, List
user32 = ctypes.windll.user32
import win32api
import win32con
import win32gui
import win32clipboard

# Constants for mouse events
MOUSE_LEFTDOWN = 0x02
MOUSE_LEFTUP = 0x04

from weixinauto.domain.license_manager import LicenseManager, LicenseNotActivatedError

from weixinauto.infra.uia.selectors.resolver import SelectorResolver
# 引入辅助函数
from weixinauto.infra.uia.win32helpers import (
    focus_control,
    safe_set_edit_text,
    set_clipboard_text,
    send_ctrl_v,
    send_enter,
    send_ctrl_enter,
    send_escape,
    send_ctrl_a_then_backspace,
    _mouse_double_click_center
)
FIRST_SESSION_OFFX = 0.17   # 示例：主窗左上角向右 260 像素
FIRST_SESSION_OFFY = 0.106   # 示例：主窗左上角向下 220 像素

class WeChatDriver:
    """微信窗口自动化驱动类：封装了查找窗口、打开窗口、切换聊天窗口及发送消息等功能"""

    ALLOWED_EXE = {"weixin.exe"}  # 仅支持新版微信进程

    def __init__(self, weixin_name: Optional[str] = None,license_manager: Optional[LicenseManager] = None,):
        # 统一用同一个 LicenseManager（里面有 _cache，读一次 license.json 就够了）
        self._lm = license_manager or LicenseManager()
        self._licensed = False
        self._license_token: Optional[str] = None

        # 构造阶段做一次显式校验（便于上层快速发现问题）
        self._ensure_licensed(hard=True)
        self._resolver = SelectorResolver()
        self._hwnd: Optional[int] = None
        self._child_window_cache: Dict[str, Dict] = {}  # 缓存子窗口信息
        self._weixin_name: Optional[str] = (weixin_name or None)
        self._find_wechat_window()

    def _ensure_licensed(self, hard: bool = False) -> bool:
        """
        hard=False：常规调用，不通过时只返回 False
        hard=True ：不通过时抛 LicenseNotActivatedError
        """
        # 已经通过过的，直接返回
        if self._licensed:
            return True

        if not self._lm.is_activated():
            if hard:
                raise LicenseNotActivatedError("当前设备尚未激活，请先完成授权。")
            return False

        # 这里你也可以顺带做个简单“运行时 token”，后面逻辑可以依赖它
        self._license_token = "OK"   # 可以换成更复杂一点的值
        self._licensed = True
        return True

    def _find_wechat_window(self) -> None:
        """查找微信主窗口 - 最快方式"""
        hwnd = self._find_wechat_hwnd()
        if hwnd:
            print("微信启动成功")
            self._hwnd = hwnd
            self._focus_main()
        else:
            raise RuntimeError("未找到微信主窗口，请先手动打开微信。")

    def debug_move_mouse_to_first_session(
        self,
        offx: int = FIRST_SESSION_OFFX,
        offy: int = FIRST_SESSION_OFFY,
    ) -> None:
        """
        调试用：根据主窗口 + 固定偏移，把真实鼠标移动到“第一个会话”的预期位置。
        不点击、不双击，只移动鼠标，方便你肉眼确认偏移是否正确。
        """
        if not self._hwnd:
            print("debug_move_mouse_to_first_session 失败：主窗口句柄不存在")
            return

        try:
            # 1. 拿到主窗 UIA 控件
            win = uia.WindowControl(Handle=self._hwnd)
            if not win.Exists(0, 0):
                print("debug_move_mouse_to_first_session 失败：主窗口 UIA 不存在")
                return

            rc = win.BoundingRectangle
            # 主窗左上角屏幕坐标 + 偏移量 = 目标屏幕坐标
            left, top, right, bottom = rc.left, rc.top, rc.right, rc.bottom
            W = right - left
            H = bottom - top
            screen_x = left + int(W * 0.17) + int(0)
            screen_y = top + int(H * 0.106) + int(0)


            # 2. 移动真实鼠标到这个屏幕坐标（不发点击）
            ctypes.windll.user32.SetCursorPos(screen_x, screen_y)

            print(
                f"[调试] 主窗左上: ({rc.left}, {rc.top})，"
                f"偏移: ({offx}, {offy})，"
                f"最终鼠标屏幕坐标: ({screen_x}, {screen_y})"
            )
        except Exception as e:
            print(f"debug_move_mouse_to_first_session 异常: {e}")

    def _find_wechat_hwnd_fast(self) -> Optional[int]:
        """
        最快方式查找微信主窗口
        直接使用UIA的WindowControl，避免枚举所有窗口
        """
        # 设置较短的搜索超时
        search_timeout = 0.5  # 2秒

        # 方法1: 优先使用mmui::MainWindow类名
        try:
            wechat_window = uia.WindowControl(ClassName="mmui::MainWindow")
            #wechat_window.SetSearchTimeout(search_timeout)
            if wechat_window.Exists(search_timeout):
                handle = wechat_window.NativeWindowHandle
                return int(handle)  # 或者 handle.value
        except:
            pass

        # 方法2: 备用类名
        try:
            wechat_window = uia.WindowControl(Name="微信")
            if wechat_window.Exists(search_timeout):
                handle = wechat_window.NativeWindowHandle
                return int(handle)  # 或者 handle.value
        except:
            pass

        # 方法3: 通过窗口标题
        try:
            wechat_window = uia.WindowControl(Name="Weixin")
            if wechat_window.Exists(search_timeout):
                handle = wechat_window.NativeWindowHandle
                return int(handle)  # 或者 handle.value
        except:
            pass

        try:
            return self._find_wechat_hwnd()
        except:
            pass

        return None

    def _get_weixin_window_name(self, hwnd: int) -> str:
        """获取微信主窗口的名称"""
        ctrl = uia.ControlFromHandle(hwnd)
        if ctrl:
            return getattr(ctrl, "Name", "")
        return ""
    def _enum_windows(self):
        """枚举当前系统中所有的窗口"""
        user32 = ctypes.windll.user32
        EnumWindows = user32.EnumWindows
        EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        GetWindowTextW = user32.GetWindowTextW
        GetClassNameW = user32.GetClassNameW
        GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        out = []

        def _cb(hwnd, _):
            tbuf = ctypes.create_unicode_buffer(512)
            cbuf = ctypes.create_unicode_buffer(256)
            GetWindowTextW(hwnd, tbuf, 512)
            GetClassNameW(hwnd, cbuf, 256)
            out.append((hwnd, tbuf.value, cbuf.value))
            return True

        EnumWindows(EnumWindowsProc(_cb), 0)
        return out

    def _get_pid(self, hwnd: int) -> int:
        """获取窗口对应的进程 PID"""
        pid = wintypes.DWORD(0)
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value or 0)

    def _get_image(self, pid: int) -> Optional[str]:
        """获取进程的路径"""
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x1000, False, pid) or k32.OpenProcess(0x0400, False, pid)
        if not h:
            return None
        try:
            QueryFullProcessImageNameW = k32.QueryFullProcessImageNameW
            QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
            QueryFullProcessImageNameW.restype = wintypes.BOOL
            buf = ctypes.create_unicode_buffer(520)
            size = wintypes.DWORD(520)
            if QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                return buf.value
            return None
        finally:
            k32.CloseHandle(h)
    def _find_wechat_hwnd(self) -> Optional[int]:
        """通过进程和窗口类名查找微信主窗口，匹配窗口标题"""
        target_class = "mmui::MainWindow"  # 微信主窗口的类名
        best, best_rank = None, 999  # 用于记录最佳窗口和排名
        for hwnd, _, class_name in self._enum_windows():
            pid = self._get_pid(hwnd)
            if not pid:
                continue

            # 只关注 "weixin.exe" 进程中的窗口
            p = self._get_image(pid) or ""
            exe = (p.rsplit("\\", 1)[-1] if p else "").lower()
            if exe not in self.ALLOWED_EXE:  # 只关心 weixin.exe 进程
                continue

            # 使用 UIA 控件获取类名
            ctrl = uia.ControlFromHandle(hwnd)
            if not ctrl:
                continue
            window_class = getattr(ctrl, "ClassName", "")
            title = str(getattr(ctrl, "Name", ""))
            # 判断标题是否包含 "微信" 或 "weixin"
            if "微信" not in title and "weixin" not in title.lower():
                continue

            # 更精确的类名匹配，区分主窗口和子窗口
            # 只接受一个 ClassName
            if window_class != target_class:
                continue
            # 找到第一个符合条件的就返回
            best = int(hwnd)
            break
        return best

    def _focus_main(self) -> None:
        """确保主窗口置前"""
        if self._hwnd:
            ctypes.windll.user32.ShowWindow(self._hwnd, 9)  # SW_RESTORE
            ctypes.windll.user32.SetForegroundWindow(self._hwnd)
            time.sleep(0.08)
        else:
            raise RuntimeError("未找到微信窗口句柄。")

    def find_wechat_child_hwnd(self, target_title: str | None = None) -> Optional[int]:
        """
        查找微信聊天子窗口（ClassName = mmui::ChatSingleWindow）
        - target_title 有值：返回第一个 title 中包含 target_title 的聊天子窗 hwnd
        - target_title 为空：返回第一个聊天子窗 hwnd
        找不到则返回 None
        """
        target_class = "mmui::ChatSingleWindow"

        for hwnd, _, _ in self._enum_windows():
            pid = self._get_pid(hwnd)
            if not pid:
                continue

            # 只关注 weixin.exe 进程
            p = self._get_image(pid) or ""
            exe = (p.rsplit("\\", 1)[-1] if p else "").lower()
            if exe not in self.ALLOWED_EXE:
                continue

            ctrl = uia.ControlFromHandle(hwnd)
            if not ctrl:
                continue

            window_class = (getattr(ctrl, "ClassName", "") or "").strip()
            title = (getattr(ctrl, "Name", "") or "").strip()

            # 只要聊天子窗
            if window_class != target_class:
                continue

            # 如果指定了标题，就要求包含；如果没指定标题，则命中第一个聊天子窗就返回
            if target_title:
                if target_title in title:
                    return int(hwnd)
            else:
                # 没传标题，直接拿到第一个聊天子窗就返回
                return int(hwnd)

        # 一个都没找到
        return None

    def _ensure_search_edit(self) -> uia.Control:
        edit = self._resolver.find_one("CHAT_SEARCH_BOX", root=self._root())
        if not edit:
            raise RuntimeError("未找到搜索输入框（CHAT_SEARCH_BOX）")
        return edit

    def _ensure_chat_input(self) -> Optional[uia.Control]:
        return self._resolver.find_one("CHAT_INPUT", root=self._root())

    def _find_send_button(self) -> Optional[uia.Control]:
        return self._resolver.find_one("SEND_BUTTON", root=self._root())

    def switch_to_chat_window(self, recipient: str) -> bool:
        """切换到与指定人的聊天窗口"""
        if not self._hwnd:
            print("主窗口未找到，无法切换聊天窗口。")
            return False
        try:
            chat_window = uia.WindowControl(searchDepth=1, Name=recipient)
            if chat_window.Exists(1):
                chat_window.SetFocus()
                print(f"已切换到与 {recipient} 的聊天窗口。")
                return True
            else:
                print(f"未找到与 {recipient} 的聊天窗口。")
                return False
        except Exception as e:
            print(f"切换聊天窗口失败: {e}")
            return False

    def send_message(self, message: str) -> bool:
        """在当前聊天窗口发送消息"""
        if not self._hwnd:
            print("主窗口未找到，无法发送消息。")
            return False
        try:
            input_box = self._find_input_box()
            if input_box:
                input_box.SendKeys(message)
                input_box.SendKeys("{Enter}")  # 按下回车键发送消息
                print(f"消息发送成功：{message}")
                return True
            else:
                print("未找到输入框。")
                return False
        except Exception as e:
            print(f"发送消息失败: {e}")
            return False

    def _find_input_box(self) -> Optional[uia.Control]:
        """查找微信聊天输入框"""
        try:
            return self._root().GetControlFromPoint(300, 400)  # 假设输入框位置
        except Exception:
            return None

    def _root(self) -> uia.Control:
        """获取微信主窗口的根控件"""
        if not self._hwnd:
            raise RuntimeError("WeChat 窗口未就绪")
        win = uia.WindowControl(Handle=self._hwnd)
        if not win.Exists(0, 0):
            raise RuntimeError("UIA 附着失败")
        return win

    def find_wechat_child_hwnd_fast(self, target_title: str) -> Optional[int]:
        """
        最快方式查找微信子窗口
        直接使用UIA的WindowControl按标题查找
        """
        search_timeout = 1  # 1秒超时

        try:
            # 方法1: 直接按标题查找聊天窗口
            chat_window = uia.WindowControl(Name=target_title)
            chat_window.SetSearchTimeout(search_timeout)
            if chat_window.Exists():
                return chat_window.NativeWindowHandle
        except:
            pass

        try:
            # 方法2: 按类名+标题组合查找
            chat_window = uia.WindowControl(ClassName="mmui::ChatSingleWindow", Name=target_title)
            chat_window.SetSearchTimeout(search_timeout)
            if chat_window.Exists():
                return chat_window.NativeWindowHandle
        except:
            pass

        return None

    def find_chat_subwindow(self, title: Optional[str] = None, timeout_sec: float = 1.5) -> Optional[uia.Control]:
        """
        定位已弹出的聊天子窗口（Class=mmui::ChatSingleWindow）。
        - 仅通过标题（title）进行查找。
        """
        if not title:
            return None

        if not self._ensure_licensed():
            raise LicenseNotActivatedError("监听功能未授权")

        # 尝试从缓存中获取窗口
        cached_window = self._child_window_cache.get(title)
        if cached_window:
            print(f"从缓存中找到子窗口：{title}")
            return cached_window['window']

        # 使用快速方法查找子窗口
        child_hwnd = self.find_wechat_child_hwnd(title)
        if child_hwnd:
            child_window = uia.ControlFromHandle(child_hwnd)
            # 缓存找到的窗口
            self._child_window_cache[title] = {
                'window': child_window,
                'hwnd': child_hwnd,
                'title': title
            }
            return child_window
        return None

    def get_session_list(self):
        """
        使用 SelectorResolver 快速定位侧栏会话列表 ListControl（mmui::XTableView, automation_id=session_list）
        """
        lst = self._resolver.find_one("SESSION_LIST")
        if lst and lst.Exists(0, 0):
            return lst
        # 兜底：从 MAIN_WINDOW 再找一次
        win = self._resolver.find_one("MAIN_WINDOW")
        if not win:
            return None
        lst = self._resolver.find_one("SESSION_LIST", root=win)
        return lst if (lst and lst.Exists(0, 0)) else None

    def find_session_item(
            self,
            title: str,
            *,
            fuzzy: bool = False,
            timeout_sec: float = 0.3,
            max_scan: int = 40,
    ) -> Optional[uia.Control]:
        """
        极速查找会话列表中的某一项：
        优先用 AutomationId = session_item_{title} 精确命中，
        找不到再遍历当前可见子项做兜底。
        """
        if not title:
            return None

        # WeChat 会话项的 AutomationId 规律：session_item_群名
        auto_id = f"session_item_{title}".strip()

        # 1. 先拿到会话列表控件（你之前已经有这个方法）
        lst = self.get_session_list()
        if not lst:
            return None

        # 2. 方法一：在会话列表子树下按 AutomationId 精确查找（最快）
        try:
            item = lst.Control(
                AutomationId=auto_id,
                ControlType=uia.ControlType.ListItemControl,
                searchDepth=4,  # 足够覆盖到 ListItem
            )
            if item.Exists(timeout_sec):
                return item
        except Exception:
            pass  # 不影响后面的兜底

        # 3. 方法二：遍历会话列表当前可见子项，按 AutomationId / Name 兜底
        try:
            try:
                children = lst.GetChildren() or []
            except Exception:
                children = []

            for idx, it in enumerate(children):
                if idx >= max_scan:
                    break

                try:
                    aid = (getattr(it, "AutomationId", "") or "").strip()
                    nm = (getattr(it, "Name", "") or "").strip()

                    # 先看 AutomationId
                    if aid == auto_id:
                        print(f"find_session_item: 遍历命中 AutomationId -> {aid}")
                        return it

                    if fuzzy and aid.startswith("session_item_"):
                        # session_item_蓝天xxx 这种情况也可以模糊一下
                        name_in_aid = aid[len("session_item_"):]
                        if title in name_in_aid:
                            print(f"find_session_item: 模糊命中 AutomationId -> {aid}")
                            return it

                    # 再兜底看 Name（比如“蓝天 1 01:10”）
                    if nm:
                        nm_low = nm.lower()
                        t_low = title.lower()
                        if (
                                nm_low == t_low
                                or nm_low.startswith(t_low)
                                or (fuzzy and t_low in nm_low)
                        ):
                            print(f"find_session_item: 兜底命中 Name -> {nm}")
                            return it

                except Exception:
                    continue

        except Exception:
            pass

        print(f"find_session_item: 未找到会话项 -> {title}")
        return None

    def _select_session_item(self, item) -> bool:
        """
        选中（聚焦）会话项
        """
        try:
            # 方法1: 使用SetFocus
            item.SetFocus()
            return True
        except:
            pass

        try:
            # 方法2: 使用键盘导航（上下箭头）
            # 先确保列表有焦点
            lst = self.get_session_list()
            if lst:
                lst.SetFocus()
                time.sleep(0.05)
                # 发送向下箭头选择项（假设是第一个）
                return True
        except:
            pass

        try:
            # 方法3: 使用Invoke选中
            item.Invoke()
            return True
        except:
            pass

        try:
            # 方法4: 使用LegacyIAccessible选中
            item.LegacyIAccessible.Select()
            return True
        except:
            pass

        print("❌ 无法选中会话项")
        return False


    def _double_click_first_session_by_offset(self) -> bool:
        """在主窗口上，用【主窗左上角 + 固定偏移】的位置做一次双击"""
        if not self._hwnd:
            print("双击失败：主窗口句柄不存在")
            return False

        try:
            # 获取窗口的屏幕坐标
            rect = wintypes.RECT()
            ctypes.windll.user32.GetWindowRect(self._hwnd, ctypes.byref(rect))

            # 获取客户区位置（不包含边框和标题栏）
            client_rect = wintypes.RECT()
            ctypes.windll.user32.GetClientRect(self._hwnd, ctypes.byref(client_rect))

            # 将客户区的原点转换为屏幕坐标
            client_origin = wintypes.POINT(0, 0)
            ctypes.windll.user32.ClientToScreen(self._hwnd, ctypes.byref(client_origin))


            # 计算最终的屏幕坐标（客户区原点 + 偏移量比例）
            W = rect.right - rect.left
            H = rect.bottom - rect.top

            # 使用乘法计算比例偏移
            screen_x = int(client_origin.x + W * FIRST_SESSION_OFFX)  # 偏移比例 * 窗口宽度
            screen_y = int(client_origin.y + H * FIRST_SESSION_OFFY)  # 偏移比例 * 窗口高度

            # 将屏幕坐标转换为客户区坐标，以便用于 PostMessage
            pt = wintypes.POINT(screen_x, screen_y)
            ctypes.windll.user32.ScreenToClient(self._hwnd, ctypes.byref(pt))

            time.sleep(0.06)
            # 使用 PostMessage 模拟双击
            lparam = (pt.y << 16) | (pt.x & 0xFFFF)
            WM_LBUTTONDOWN = 0x0201
            WM_LBUTTONUP = 0x0202
            user32 = ctypes.windll.user32

            # 发送两次按下/抬起事件模拟双击
            user32.PostMessageW(self._hwnd, WM_LBUTTONDOWN, 1, lparam)
            time.sleep(0.02)
            user32.PostMessageW(self._hwnd, WM_LBUTTONUP, 0, lparam)
            time.sleep(0.05)
            user32.PostMessageW(self._hwnd, WM_LBUTTONDOWN, 1, lparam)
            time.sleep(0.02)
            user32.PostMessageW(self._hwnd, WM_LBUTTONUP, 0, lparam)
            time.sleep(0.08)

            print("双击成功")
            return True
        except Exception as e:
            print(f"双击失败：{e}")
            return False

    def activate_session_item(self, item, prefer_invoke: bool = True, settle_ms: int = 160) -> bool:
        if not item or not item.Exists(0, 0):
            return False
        # 多策略双击 / 激活
        try:
            item.DoubleClick()
            ok = True
        except Exception:
            ok = False
        if not ok:
            ok = _mouse_double_click_center(item)
        return ok

    def ensure_chat_window_open_fast(self, name: str,
                                     fuzzy: bool = False,
                                     main_focus_timeout: float = 0.0,
                                     search_enter_settle_ms: int = 120,
                                     list_scan_ms: int = 500,
                                     after_open_wait_ms: int = 500) -> bool:
        """
        极速版：不解析"候选弹层"，不做全局 BFS。
        流程：子窗已存在→返回；否则 前置主窗→搜索框粘贴+回车→会话列表少量扫描/微滚→双击→Win32 确认子窗。
        仅用到：_focus_main / _ensure_search_edit / get_session_list / find_session_item / activate_session_item
        """
        if not name:
            return False
        title = (name or "").strip()

        # 尝试从缓存获取子窗口
        if self.find_chat_subwindow(title):
            return True

        # 1) 前置主窗（不等待 UIA 树）
        self._focus_main()

        # 2) 搜索框：粘贴+回车（不等候选，不做候选解析）
        try:
            edit = self._ensure_search_edit()
        except Exception:
            return False

        try:
            focus_control(edit)
            time.sleep(0.02)
            send_ctrl_a_then_backspace()
            time.sleep(0.02)
            set_clipboard_text(title)
            send_ctrl_v()
            time.sleep(0.04)
            send_enter()
            time.sleep(0.04)
        except Exception:
            return False

        time.sleep(0.6)
        # 3) 不再找会话控件，直接在主窗上用偏移双击第一个会话
        if not self._double_click_first_session_by_offset():
            # 如果偏移双击失败，可以视情况再用旧的 activate_session_item 兜底
            # item = self.find_session_item(title, fuzzy=fuzzy)
            # if not self.activate_session_item(item):
            #     return False
            return False
        time.sleep(0.05)
        if self.find_chat_subwindow(title):
            return True
        return False

    def _get_search_list(self):
        """
        兼容旧结构：直接通过类名定位搜索弹层与列表。
        若后续你们把 SEARCH_LIST 也写进 JSON，可改成 resolver 调用。
        """
        win = self._root()
        pop = win.Control(SearchDepth=6, ClassName="mmui::SearchContentPopover")
        if not pop or not pop.Exists(0, 0):
            return None, None, None
        view = pop.Control(SearchDepth=3, ClassName="mmui::SearchContentView")
        if not view or not view.Exists(0, 0):
            return pop, None, None
        lst = view.Control(
            SearchDepth=6,
            ControlType=uia.ControlType.ListControl,
            ClassName="mmui::XTableView",
            AutomationId="search_list",
        )
        if not lst or not lst.Exists(0, 0):
            return pop, view, None
        return pop, view, lst

    def _dismiss_search_popover(self, tries: int = 2) -> None:
        """关闭可能残留的搜索弹层，避免误点旧列表"""
        for _ in range(max(1, tries)):
            pop, view, lst = self._get_search_list()
            if not (pop and view):
                return
            try:
                send_escape()
            except Exception:
                pass
            time.sleep(0.06)

    def _wait_search_list_ready(self, timeout_sec: float = 0.8) -> bool:
        end = time.time() + max(0.2, float(timeout_sec))
        while time.time() < end:
            pop, view, lst = self._get_search_list()
            if pop and view and lst:
                try:
                    ch = lst.GetChildren()
                    if ch and len(ch) > 0:
                        return True
                except Exception:
                    return True
            time.sleep(0.03)
        return False

    def _collect_candidates_names(self) -> list[str]:
        """
        从候选中抽取【联系人】与【群聊】区的可选项文本，用于精准匹配确认。
        """
        _pop, _view, lst = self._get_search_list()
        if not lst:
            return []

        # 取纯文本列表（每个 ListItem 的 Name，或其子 TextControl 的 Name）
        raw_items: List[str] = []
        try:
            for node in lst.GetChildren():
                if getattr(node, "ControlTypeName", "") != "ListItemControl":
                    continue
                nm = (getattr(node, "Name", "") or "").strip()
                if not nm:
                    try:
                        for ch in node.GetChildren():
                            if getattr(ch, "ControlTypeName", "") == "TextControl":
                                t = (getattr(ch, "Name", "") or "").strip()
                                if t:
                                    nm = t
                                    break
                    except Exception:
                        pass
                raw_items.append(nm)
        except Exception:
            pass

        if not raw_items:
            return []

        # 扫描【联系人】和【群聊】两个区，收集名称
        names: List[str] = []
        in_contacts, in_groups = False, False
        for nm in raw_items:
            if not nm:
                continue

            # 区域标题切换
            if nm == "联系人":
                in_contacts, in_groups = True, False
                continue
            if nm == "群聊":
                in_contacts, in_groups = False, True
                continue
            if nm in ("服务号", "聊天记录"):
                # 到下一区块，若之前在联系人/群聊中，说明该块结束
                if in_contacts or in_groups:
                    # 退出收集，避免混入后续分区
                    break

            # 具体项
            if (in_contacts or in_groups) and (not nm.startswith("查看全部")):
                names.append(nm)

        return names
    def send_file_to_chat(
            self,
            chat_name: str,
            file_path: str,
            *,
            case_insensitive: bool = True,
            wait_child_sec: float = 1.2,
            strict: bool = False,
    ) -> bool:
        """
        向指定聊天窗口发送文件（单文件版）：
          1) 主窗前置 & 关闭旧搜索弹层
          2) 搜索框输入 chat_name 并回车进入会话
          3) 定位输入框，设置剪贴板为文件（CF_HDROP）
          4) Ctrl+V 粘贴文件
          5) 回车发送

        :param chat_name: 会话名（群名/好友昵称）
        :param file_path: 要发送的文件路径
        :param wait_child_sec: 预留参数，目前未做子窗等待，可后续扩展
        :param strict: 是否要求候选列表中精确命中 chat_name
        """
        if not chat_name or not file_path:
            return False

        # 1) 先检查文件是否存在
        if not os.path.isfile(file_path):
            print(f"[send_file_to_chat] 文件不存在: {file_path}")
            return False

        # 2) 主窗 & 弹层
        self._focus_main()
        self._dismiss_search_popover(tries=2)

        # 3) 搜索框输入 chat_name（和 send_text_to_chat 基本一致）
        try:
            edit = self._ensure_search_edit()
        except Exception:
            return False

        try:
            focus_control(edit)
            time.sleep(0.02)
            send_ctrl_a_then_backspace()
            time.sleep(0.02)

            if not set_clipboard_text(chat_name):
                return False
            send_ctrl_v()
        except Exception:
            return False

        # 等候选列表
        if not self._wait_search_list_ready(timeout_sec=0.9):
            return False

        names = self._collect_candidates_names()
        if strict:
            if not names:
                return False
            target = (chat_name or "").strip()
            target_cmp = target.lower() if case_insensitive else target

            def _norm(s: str) -> str:
                s = (s or "").strip()
                return s.lower() if case_insensitive else s

            exact_hit = any((_norm(x) == target_cmp) for x in names)
            if not exact_hit:
                print(f"[send_file_to_chat] 未在候选中精确命中会话: {chat_name}")
                return False

        # 回车进入会话
        send_enter()
        time.sleep(0.08)

        # 4) 找输入框
        input_box = self._ensure_chat_input()
        if not input_box:
            print("[send_file_to_chat] 未找到聊天输入框")
            return False

        focus_control(input_box)
        time.sleep(0.05)

        # 5) 设置剪贴板为文件列表，然后 Ctrl+V
        if not self._set_clipboard_files([file_path]):
            print("[send_file_to_chat] 设置文件剪贴板失败")
            return False

        try:
            send_ctrl_v()
        except Exception as e:
            print(f"[send_file_to_chat] 发送 Ctrl+V 失败: {e}")
            return False

        # 等待微信加载预览（视网速和文件大小，保守一点）
        time.sleep(0.8)

        # 再次确保输入框有焦点，然后回车发送
        try:
            focus_control(input_box)
            time.sleep(0.05)
            send_enter()
            time.sleep(0.06)
            return True
        except Exception as e:
            print(f"[send_file_to_chat] 回车发送失败: {e}")
            return False

    @staticmethod
    def _set_clipboard_files(paths: List[str]) -> bool:
        """
        把一组文件路径设置到剪贴板（CF_HDROP），
        这样在微信输入框里 Ctrl+V 就会变成“粘贴文件/图片”。
        """
        if not paths:
            return False

        # 规范化路径
        norm_paths: List[str] = []
        for p in paths:
            if not p:
                continue
            norm_paths.append(os.path.abspath(p))

        if not norm_paths:
            return False

        try:
            # 文件列表："C:\\a.txt\0D:\\b.png\0\0" → UTF-16LE
            files_str = "\0".join(norm_paths) + "\0\0"
            files_bytes = files_str.encode("utf-16le")

            # DROPFILES 结构（32/64 位通用部分）：
            # typedef struct _DROPFILES {
            #   DWORD pFiles; // 偏移，一般 20
            #   POINT pt;     // 8 字节
            #   BOOL fNC;     // 4 字节
            #   BOOL fWide;   // 4 字节
            # } DROPFILES;
            pFiles = 20  # 20 字节头
            pt_x = 0
            pt_y = 0
            fNC = 0
            fWide = 1  # 使用 Unicode

            header = struct.pack("IiiII", pFiles, pt_x, pt_y, fNC, fWide)
            buf = header + files_bytes
            size = len(buf)

            GMEM_MOVEABLE = 0x0002

            k32 = ctypes.windll.kernel32

            # 分配全局内存
            h_global = k32.GlobalAlloc(GMEM_MOVEABLE, size)
            if not h_global:
                return False

            lp = k32.GlobalLock(h_global)
            if not lp:
                k32.GlobalFree(h_global)
                return False

            # 拷贝数据到内存块
            ctypes.memmove(lp, buf, size)
            k32.GlobalUnlock(h_global)

            # 设置剪贴板
            win32clipboard.OpenClipboard()
            try:
                win32clipboard.EmptyClipboard()
                # 注意：SetClipboardData 接管 h_global 的生命周期，不要再 Free
                win32clipboard.SetClipboardData(win32con.CF_HDROP, h_global)
            finally:
                win32clipboard.CloseClipboard()

            return True
        except Exception as e:
            print(f"[clipboard] 设置文件剪贴板失败: {e}")
            return False

    def send_text_to_chat(
            self,
            chat_name: str,
            text: str,
            *,
            case_insensitive: bool = True,
            wait_child_sec: float = 1.2,
            wait_btn_sec: float = 1.2,
            strict: bool = False,  # 默认非精准
    ) -> bool:
        """
        业务主流程（不依赖侧栏/双击）：
          1) 主窗前置、关闭旧弹层
          2) 搜索框清空 → 粘贴 chat_name（剪贴板+Ctrl+V）
          3) 等候选列表 → 在【联系人】【群聊】中做精确匹配
          4) 回车进入
          5) 找输入框 → 写文本（一次性）
          6) 优先点击"发送"按钮；失败则 Ctrl+Enter / Enter 兜底
        """
        if not chat_name or not text:
            return False
        # ---------- 1) 主窗 & 弹层 ----------
        self._focus_main()
        self._dismiss_search_popover(tries=2)

        # ---------- 2) 粘贴 chat_name ----------
        try:
            edit = self._ensure_search_edit()

        except Exception:

            return False

        try:
            # 用热键清空，避免某些版本 ValuePattern/显示不同步
            focus_control(edit)
            time.sleep(0.02)
            send_ctrl_a_then_backspace()
            time.sleep(0.02)

            if not set_clipboard_text(chat_name):

                return False
            send_ctrl_v()
        except Exception:

            return False

        # ---------- 3) 等候选 + 精确匹配 ----------
        if not self._wait_search_list_ready(timeout_sec=0.9):

            return False

        names = self._collect_candidates_names()
        if strict:
            if not names:
                return False
            target = (chat_name or "").strip()
            target_cmp = target.lower() if case_insensitive else target

            def _norm(s: str) -> str:
                s = (s or "").strip()
                return s.lower() if case_insensitive else s

            exact_hit = any((_norm(x) == target_cmp) for x in names)
            if not exact_hit:
                return False

        # ---------- 4) 回车进入 ----------
        send_enter()
        time.sleep(0.05)

        # ---------- 5) 输入框写文本 ----------
        input_box = self._ensure_chat_input()
        if not input_box:
            return False

        focus_control(input_box)
        time.sleep(0.03)

        if not safe_set_edit_text(input_box, text):
            print("执行了这个")
            return False
        time.sleep(0.06)

        # ---------- 6) 优先按钮 → 快捷键兜底 ----------

        focus_control(input_box)
        try:
            send_enter()
            time.sleep(0.06)
            return True
        except Exception:
            pass

        return False

    def shutdown(self) -> None:
        # 目前无后台线程；如未来加监听线程可在此结束
        pass