# -*- coding: utf-8 -*-
# chat_listener.py
from __future__ import annotations

import ctypes
import hashlib
import inspect
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional
import os
import win32clipboard
import win32con

import uiautomation as uia
from ctypes import wintypes as _w

from weixinauto.domain.license_manager import LicenseManager, LicenseNotActivatedError
from weixinauto.infra.uia.wechat_driver import WeChatDriver

from .wx_chat_finder import get_last_message_item, get_prev_message_item
from .utils_win import (
    bring_to_front,
    get_hwnd_from_ctrl,
    lock_window_width,
    window_rect_big_enough,
)
from .sender_click_resolver import SenderClickResolver
from .message_extract import (
    MessageType,
    classify_by_classname,
    extract_text_deep,
)
from .message import ChatMessage
from .message_actions import DefaultMessageActions, save_from_clipboard_to_weixin_file
from .wx_subwindow_ops import ChatSubWindowOps  # 新增：子窗口操作工具类

# ====== 可调参数 ======
TARGET_WIN_WIDTH = 980
FIXED_OFFX = 60
FIXED_OFFY = 45
PROBE_MARGIN_H = 6
PROBE_MARGIN_V = 6

POLL_SEC = 0.15
OPEN_STABILIZE_TRY = 8  # 8 * 40ms ≈ 320ms
NICK_MAX_WAIT_SEC = 0.80
NICK_POLL_STEPS = (
    0.00,
    0.04,
    0.06,
    0.08,
    0.10,
    0.12,
    0.16,
    0.20,
    0.24,
    0.28,
    0.36,
    0.44,
    0.56,
    0.68,
    0.80,
)

# ====== Win32 基础（ESC/Enter/Click）======
try:
    LRESULT = _w.LRESULT
except AttributeError:
    LRESULT = ctypes.c_ssize_t if hasattr(ctypes, "c_ssize_t") else (
        ctypes.c_longlong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_long
    )

_user32 = ctypes.windll.user32
SendMessageW = _user32.SendMessageW
PostMessageW = _user32.PostMessageW
SetCursorPos = _user32.SetCursorPos
mouse_event = _user32.mouse_event

SendMessageW.argtypes = [_w.HWND, _w.UINT, _w.WPARAM, _w.LPARAM]
SendMessageW.restype = LRESULT
PostMessageW.argtypes = [_w.HWND, _w.UINT, _w.WPARAM, _w.LPARAM]
PostMessageW.restype = _w.BOOL

WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
VK_RETURN = 0x0D
VK_ESCAPE = 0x1B

MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004

VK_CONTROL = 0x11
VK_V = 0x56
KEYEVENTF_KEYUP = 0x0002
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004

# ====== 类型别名 ======
OnMessage = Callable[..., None]
_MEDIA_CLIPBOARD_LOCK = threading.Lock()

AUTO_SAVE_MAX_TRY = 3          # 最多重试 3 次
AUTO_SAVE_RETRY_DELAY = 0.3    # 每次重试间隔 0.3 秒
AUTO_SAVE_COPY_TIMEOUT = 1.2   # 每次等菜单/复制超时时间

# ====== 小工具函数 ======
def _is_alive(ctrl: Optional[uia.Control]) -> bool:
    if not ctrl:
        return False
    try:
        _ = ctrl.BoundingRectangle
        return ctrl.Exists(0, 0)
    except Exception:
        return False


def _runtime_id_hex(node) -> Optional[str]:
    """把 RuntimeId 转成一个稳定的十六进制字符串，用于做消息 key。"""
    try:
        rid = node.GetRuntimeId()
        if rid:
            return ".".join(f"{int(v):X}" for v in rid)
    except Exception:
        pass

    try:
        rid = getattr(node, "RuntimeId", None)
        if isinstance(rid, (list, tuple)) and rid:
            return ".".join(f"{int(v):X}" for v in rid)
    except Exception:
        pass
    return None


def _get_full_uia_text(item: uia.Control) -> str:
    """
    综合 Name + LegacyIAccessible.Name，尽量拿到完整的多行文本。
    """
    name = ""
    legacy_name = ""

    try:
        name = (getattr(item, "Name", "") or "").strip()
    except Exception:
        pass

    try:
        pat = item.GetLegacyIAccessiblePattern()
        if pat:
            legacy_name = (getattr(pat, "Name", "") or "").strip()
    except Exception:
        pass

    return (legacy_name or name or "").strip()


def _extract_file_name(item: uia.Control, raw_text: str | None = None) -> Optional[str]:
    """
    从控件文本中解析文件名。
    典型结构（LegacyIAccessible.Name）：
      "文件\n爱房通年度汇报(1).pptx\n3.1M\n微信电脑版"
    """
    full = _get_full_uia_text(item)
    if not full and raw_text:
        full = (raw_text or "").strip()

    if not full:
        return None

    lines = [ln.strip() for ln in full.splitlines() if ln.strip()]
    if not lines:
        return None

    # 第一行是“文件”，第二行是文件名
    if lines[0].startswith("文件") and len(lines) >= 2:
        return lines[1]

    # 兜底：找带常见扩展名的那一行
    exts = (
        ".ppt", ".pptx", ".doc", ".docx",
        ".xls", ".xlsx", ".pdf",
        ".zip", ".rar", ".7z",
        ".txt", ".csv"
    )
    for ln in lines:
        low = ln.lower()
        if any(ext in low for ext in exts):
            return ln

    return None


def _msg_key(node, text_for_key: str) -> Optional[str]:
    """消息“边界 key”算法：RuntimeIdHex + 文本（rstrip 后）"""
    rid = _runtime_id_hex(node)
    if not rid:
        return None
    s = f"{rid}|{text_for_key or ''}"
    return hashlib.md5(s.encode("utf-8", "ignore")).hexdigest()


def _hash_text_for_echo(s: str) -> str:
    """给文本做一个简单哈希，用于自回声抑制。"""
    return hashlib.md5((s or "").rstrip().encode("utf-8", "ignore")).hexdigest()


def _scroll_into_view(node) -> None:
    """尽量把节点滚动到可见区域。"""
    try:
        sp = node.GetScrollItemPattern()
        if sp:
            sp.ScrollIntoView()
            return
    except Exception:
        pass
    try:
        node.SetFocus()
    except Exception:
        pass


def _set_clipboard_files(paths: List[str]) -> bool:
    """
    把文件列表写入剪贴板为 CF_HDROP，用于 Ctrl+V 粘贴发送文件。
    """
    abs_paths = []
    for p in paths:
        if not isinstance(p, str):
            continue
        ap = os.path.abspath(p)
        if os.path.isfile(ap):
            abs_paths.append(ap)
    if not abs_paths:
        print("[reply] _set_clipboard_files: 没有有效文件")
        return False

    class DROPFILES(ctypes.Structure):
        _fields_ = [
            ("pFiles", _w.DWORD),
            ("pt", _w.POINT),
            ("fNC", _w.BOOL),
            ("fWide", _w.BOOL),
        ]

    files_str = "\0".join(abs_paths) + "\0\0"
    files_bytes = files_str.encode("utf-16le")

    drop = DROPFILES()
    drop.pFiles = ctypes.sizeof(DROPFILES)
    drop.pt = _w.POINT(0, 0)
    drop.fNC = 0
    drop.fWide = 1

    buf = bytes(drop) + files_bytes

    GMEM_MOVEABLE = 0x0002
    k32 = ctypes.windll.kernel32
    h_global = k32.GlobalAlloc(GMEM_MOVEABLE, len(buf))
    if not h_global:
        print("[reply] GlobalAlloc 失败")
        return False

    ptr = k32.GlobalLock(h_global)
    if not ptr:
        k32.GlobalFree(h_global)
        print("[reply] GlobalLock 失败")
        return False

    ctypes.memmove(ptr, buf, len(buf))
    k32.GlobalUnlock(h_global)

    try:
        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardData(win32con.CF_HDROP, h_global)
        win32clipboard.CloseClipboard()
        return True
    except Exception as e:
        print(f"[reply] 设置剪贴板 CF_HDROP 失败: {e}")
        try:
            win32clipboard.CloseClipboard()
        except Exception:
            pass
        k32.GlobalFree(h_global)
        return False


def _reply_enter_only(win: uia.Control, content: str, *, mode: str = "text") -> bool:
    """
    稳定发送：
      - mode="text"：置前 + 找 Edit + 写入文本 + Enter
      - mode="file"：置前 + 设置剪贴板为文件列表 + 找 Edit + Ctrl+V + Enter
    """
    if not (_is_alive(win) and isinstance(content, str)):
        return False

    hwnd = get_hwnd_from_ctrl(win)
    if hwnd:
        _ = bring_to_front(hwnd, gentle=True)
        for _ in range(OPEN_STABILIZE_TRY):
            time.sleep(0.04)
            if window_rect_big_enough(hwnd, min_w=360, min_h=240):
                break

    if mode == "file":
        path = content.strip().strip('"').strip()
        if not os.path.isfile(path):
            print(f"[reply] 文件不存在: {path}")
            return False

        if not _set_clipboard_files([path]):
            print("[reply] 设置文件剪贴板失败")
            return False

        time.sleep(0.05)

    edit = None
    q, seen = [win], 0
    while q and seen < 8000 and not edit:
        n = q.pop(0)
        seen += 1
        if getattr(n, "ControlTypeName", "") == "EditControl":
            edit = n
            break
        try:
            ch = n.GetChildren()
            if ch:
                q.extend(ch)
        except Exception:
            pass

    if not edit:
        print("[reply] 未找到 Edit 输入框")
        return False

    if mode == "text":
        text = content
        wrote = False
        try:
            vp = edit.GetValuePattern()
        except Exception:
            vp = None

        if vp:
            try:
                vp.SetValue("")
                time.sleep(0.02)
            except Exception:
                pass
            try:
                vp.SetValue(text)
                wrote = True
            except Exception:
                pass

        if not wrote:
            try:
                edit.SetFocus()
            except Exception:
                try:
                    win.SetFocus()
                except Exception:
                    pass
            try:
                edit.SendKeys("{Ctrl}a{Back}")
                time.sleep(0.02)
                edit.SendKeys(text)
                wrote = True
            except Exception:
                return False

    elif mode == "file":
        try:
            edit.SetFocus()
        except Exception:
            try:
                win.SetFocus()
                time.sleep(0.03)
                edit.SetFocus()
            except Exception:
                print("[reply] 无法聚焦 Edit 输入框")
                return False

        time.sleep(0.05)
        try:
            edit.SendKeys("{Ctrl}v")
        except Exception as e:
            print(f"[reply] Edit 发送 Ctrl+V 失败: {e}")
            return False

    else:
        print(f"[reply] 未知发送模式: {mode!r}")
        return False

    time.sleep(0.05)
    try:
        edit.SendKeys("{Enter}")
        return True
    except Exception:
        pass

    try:
        h_edit = int(getattr(edit, "NativeWindowHandle", 0) or 0)
        if h_edit:
            ok = bool(
                PostMessageW(h_edit, WM_KEYDOWN, VK_RETURN, 0)
                and PostMessageW(h_edit, WM_KEYUP, VK_RETURN, 0)
            )
            if ok:
                return True
    except Exception:
        pass

    try:
        if hwnd:
            ok = bool(
                PostMessageW(hwnd, WM_KEYDOWN, VK_RETURN, 0)
                and PostMessageW(hwnd, WM_KEYUP, VK_RETURN, 0)
            )
            return ok
    except Exception:
        pass

    return False


# ====== 头像坐标与一次点击（保留原功能，昵称模块可能会用到） ======
def _avatar_xy_of_item(item: uia.Control) -> Optional[tuple[int, int]]:
    try:
        rc = item.BoundingRectangle
        il, it, ir, ib = rc.left, rc.top, rc.right, rc.bottom
        x = int(il + FIXED_OFFX)
        y = int(it + FIXED_OFFY)
        x = max(il + PROBE_MARGIN_H, min(x, ir - PROBE_MARGIN_H))
        y = max(it + PROBE_MARGIN_V, min(y, ib - PROBE_MARGIN_V))
        return x, y
    except Exception:
        return None


def _click_avatar_once(item: uia.Control) -> bool:
    xy = _avatar_xy_of_item(item)
    if not xy:
        return False
    try:
        SetCursorPos(xy[0], xy[1])
        mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
        mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
        return True
    except Exception:
        return False


# ====== ChatWnd：对外暴露的“子窗口对象”，带 reply() ======
@dataclass(eq=False)
class ChatWnd:
    title: str

    _reply_fn: Optional[Callable[[str], bool]] = field(default=None, repr=False)
    _incoming_cache: List[str] = field(default_factory=list, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def _update_reply_fn(self, fn: Callable[[str], bool]) -> None:
        with self._lock:
            self._reply_fn = fn

    def _record_incoming(self, text: str, is_self: Optional[bool]) -> None:
        if not isinstance(text, str):
            return
        if is_self:
            return

        h = _hash_text_for_echo(text)
        with self._lock:
            self._incoming_cache.append(h)
            if len(self._incoming_cache) > 32:
                self._incoming_cache = self._incoming_cache[-32:]

    def reply(self, text: str) -> bool:
        if not isinstance(text, str):
            return False
        t = text.rstrip()
        if t == "":
            return False

        h = _hash_text_for_echo(t)

        with self._lock:
            if h in self._incoming_cache:
                self._incoming_cache = [x for x in self._incoming_cache if x != h]
                print(
                    f"[{self.title}] reply 被抑制：内容与最近收到的消息一致，疑似调试回声，已跳过发送。"
                )
                return False

            fn = self._reply_fn

        if not fn:
            print(
                f"[{self.title}] reply 失败：当前没有可用的回复函数（子窗口可能尚未绑定或已关闭）。"
            )
            return False

        ok = fn(t)

        if ok:
            with self._lock:
                self._incoming_cache.append(h)
                if len(self._incoming_cache) > 32:
                    self._incoming_cache = self._incoming_cache[-32:]

        return ok

    def reply_file(self, file_path: str) -> bool:
        if not isinstance(file_path, str):
            return False
        t = file_path.rstrip()
        if t == "":
            return False

        h = _hash_text_for_echo(t)

        with self._lock:
            if h in self._incoming_cache:
                self._incoming_cache = [x for x in self._incoming_cache if x != h]
                print(
                    f"[{self.title}] reply 被抑制：内容与最近收到的消息一致，疑似调试回声，已跳过发送。"
                )
                return False

            fn = self._reply_fn

        if not fn:
            print(
                f"[{self.title}] reply 失败：当前没有可用的回复函数（子窗口可能尚未绑定或已关闭）。"
            )
            return False

        ok = fn(content=t, mode="file")  # 注意：这里传 mode="file"

        if ok:
            with self._lock:
                self._incoming_cache.append(h)
                if len(self._incoming_cache) > 32:
                    self._incoming_cache = self._incoming_cache[-32:]

        return ok


# ====== 单窗监听线程 ======
class ChatWindowListener(threading.Thread):
    """
    need_nickname=True：
        * 只点击一次头像
        * 必须读到昵称才回调；否则跳过该条
        * 关闭弹层用 ESC，不再第二次点击
        * 开启昵称检测时，不启用“自回声抑制”
    need_nickname=False：
        * 纯后台监听，使用自回声抑制（最近发送文本哈希）

    新增：
        * auto_save_image：是否自动下载图片
        * auto_save_file：是否自动下载文件
        * save_base_dir：weixin_file 所在根目录（不传则用 cwd）
    """

    def __init__(
        self,
        title: str,
        on_message: OnMessage,
        *,
        driver: Optional[WeChatDriver],
        need_nickname: bool = True,
        license_manager: Optional[LicenseManager] = None,
        poll_sec: float = POLL_SEC,
        debug_nick: bool = False,
        auto_save_image: bool = False,   # 新增：自动保存图片
        auto_save_file: bool = False,    # 新增：自动保存文件
        save_base_dir: Optional[str] = None,  # 新增：保存目录根
    ):
        super().__init__(name=f"wx-listener-{title}", daemon=True)

        self.title = (title or "").strip()
        self.on_message = on_message
        self.need_nickname = bool(need_nickname)
        self.poll = poll_sec if poll_sec and poll_sec > 0 else POLL_SEC
        self.debug_nick = bool(debug_nick)

        self._stop = threading.Event()
        self._win: Optional[uia.Control] = None

        self._last_key: Optional[str] = None
        self._last_noid_text: Optional[str] = None

        self._use_echo = not self.need_nickname
        self._recent_sent: List[tuple[int, str]] = [] if self._use_echo else []

        self._lm = license_manager or LicenseManager()

        # 新增：自动保存开关 & 保存路径
        self._auto_save_image = bool(auto_save_image)
        self._auto_save_file = bool(auto_save_file)
        self._save_base_dir = save_base_dir
        self._ops = ChatSubWindowOps(self.title)

        if not self._lm.is_activated():
            raise LicenseNotActivatedError("当前设备尚未激活，无法启动消息监听。")

        if driver is None:
            self._driver = self._lm.create_wechat_driver()
        else:
            self._driver = driver

        self._resolver = SenderClickResolver()
        self._lock = threading.Lock()

        try:
            self._cb_param_count = len(inspect.signature(on_message).parameters)
        except Exception:
            self._cb_param_count = 2

    # —— 生命周期控制 ——
    def stop(self) -> None:
        self._stop.set()

    def push_outgoing_preview(self, text: str) -> None:
        if not (self._use_echo and isinstance(text, str)):
            return
        if not self._win:
            return

        hwnd = get_hwnd_from_ctrl(self._win) or 0
        if not hwnd:
            return

        h = _hash_text_for_echo(text)
        with self._lock:
            self._recent_sent.append((hwnd, h))
            if len(self._recent_sent) > 32:
                self._recent_sent = self._recent_sent[-32:]

    # —— 内部工具 ——
    def _bind_window_or_raise(self) -> None:
        win = self._driver.find_chat_subwindow(self.title, timeout_sec=1.5)
        if not win:
            raise RuntimeError(
                f"未找到已打开的子窗口：{self.title!r}（Class=mmui::ChatSingleWindow）。请先手动弹出该聊天子窗。"
            )
        self._win = win
        try:
            lock_window_width(self._win, TARGET_WIN_WIDTH)
        except Exception:
            pass
        print(
            f"[{self.title}] 监听成功（need_nickname={self.need_nickname}, "
            f"echo_suppression={self._use_echo}, "
            f"auto_save_image={self._auto_save_image}, auto_save_file={self._auto_save_file})"
        )

    def _make_reply_callable(self) -> Callable[[str], bool]:
        """
        返回一个函数 reply(content, mode='text')->bool：
          - mode="text"：走文本发送 + 自回声抑制
          - mode="file"：走文件发送（不做文本回声判断）
        """

        def reply(content: str, mode: str = "text") -> bool:
            if not (self._win and _is_alive(self._win)):
                return False
            if not isinstance(content, str):
                return False
            if not content.strip():
                return False

            if mode == "file":
                return _reply_enter_only(self._win, content, mode="file")

            t = content.rstrip()
            if not t:
                return False

            hwnd = get_hwnd_from_ctrl(self._win) or 0
            h = _hash_text_for_echo(t)

            if self._use_echo:
                with self._lock:
                    if (hwnd, h) in self._recent_sent:
                        print(
                            f"[{self.title}] reply 被抑制：同一窗口最近已发送过相同内容，跳过本次发送。"
                        )
                        return False

                    self._recent_sent.append((hwnd, h))
                    if len(self._recent_sent) > 32:
                        self._recent_sent = self._recent_sent[-32:]

            return _reply_enter_only(self._win, t, mode="text")

        return reply

    def _bring_front_and_stabilize(self) -> None:
        hwnd = get_hwnd_from_ctrl(self._win)
        if hwnd:
            _ = bring_to_front(hwnd, gentle=True)
            for _ in range(OPEN_STABILIZE_TRY):
                time.sleep(0.04)
                if window_rect_big_enough(hwnd, min_w=360, min_h=240):
                    break

    def _get_nickname(self, item: uia.Control) -> Optional[tuple[bool, str]]:
        is_self, sender = None, None

        if self._lock.acquire(timeout=2):
            try:
                self._bring_front_and_stabilize()
                _scroll_into_view(item)

                item2 = get_last_message_item(self._win) or item
                _scroll_into_view(item2)

                is_self, sender = self._resolver.resolve_by_click(
                    self._win, item2, close_after=True
                )
            except Exception as e:
                print(f"[ERROR] 获取昵称失败: {e}")
                is_self, sender = None, None
            finally:
                self._lock.release()
        else:
            print(f"[WARNING] 获取昵称超时，跳过此操作")

        return is_self, sender

    # 新增：自动保存图片 / 文件
    def _auto_save_media_if_needed(
            self,
            item: uia.Control,
            mtype: MessageType,
    ) -> Optional[str]:
        """
        根据配置自动保存图片/文件：
          - mtype=IMAGE 且 auto_save_image=True
          - mtype=FILE  且 auto_save_file=True
        成功时返回保存路径；失败或未启用时返回 None。

        内部自带重试机制：
          - 先置前 + 稳定窗口
          - 多次尝试：右键 → 菜单复制 → 读剪贴板保存
          - 适配“图片刚到还没完全加载、第一次右键没复制按钮”的情况
        """

        # 2) 先把当前子窗口置前并固定宽度，一次即可
        try:
            self._bring_front_and_stabilize()
        except Exception as e:
            print(f"[{self.title}] auto_save: bring_front 失败：{e}")
            return None

        time.sleep(0.2)  # 稍等一会儿，让图片/菜单有时间渲染

        prefix = "img" if mtype == MessageType.IMAGE else "file"

        # 3) 多次尝试右键复制 + 从剪贴板保存
        for attempt in range(1, AUTO_SAVE_MAX_TRY + 1):
            # 3.1 右键 + 菜单复制
            ok = ChatSubWindowOps.copy_item_via_menu(
                item,
                x_ratio=0.12,
                y_ratio=0.18,
                timeout_sec=AUTO_SAVE_COPY_TIMEOUT,
            )
            if not ok:
                # 可能是图片还没加载完、菜单还没弹对
                print(
                    f"[{self.title}] auto_save: 第 {attempt} 次右键菜单未找到『复制』，"
                    f"类型={mtype}"
                )
            else:
                # 3.2 尝试从剪贴板识别并保存
                paths = save_from_clipboard_to_weixin_file(
                    base_dir=self._save_base_dir,
                    prefix=prefix,
                )
                if paths:
                    path = paths[0]
                    return path
                print(
                    f"[{self.title}] auto_save: 第 {attempt} 次剪贴板中没有有效的 {mtype}，"
                    f"可能是微信还未写入"
                )





        return None

    # —— 主循环 ——
    def run(self) -> None:
        with uia.UIAutomationInitializerInThread():
            self._bind_window_or_raise()
            reply_callable = self._make_reply_callable()

            # 初始化边界
            last_item = get_last_message_item(self._win)
            if last_item:
                raw0 = extract_text_deep(last_item) or ""
                text0 = raw0.rstrip()
                key0 = _msg_key(last_item, text0)
                self._last_key = key0
                self._last_noid_text = text0 if (key0 is None and self.need_nickname) else None

            while not self._stop.is_set():
                if not _is_alive(self._win):
                    break

                last_item = get_last_message_item(self._win)
                if not last_item:
                    time.sleep(self.poll)
                    continue

                items_to_process: List[tuple[uia.Control, str, str, Optional[str]]] = []
                cur = last_item

                while cur:
                    raw_text = extract_text_deep(cur) or ""
                    text = raw_text.rstrip()
                    key = _msg_key(cur, text)

                    if key is not None:
                        if self._last_key is not None and key == self._last_key:
                            break
                    else:
                        if (
                            self.need_nickname
                            and self._last_noid_text is not None
                            and text == self._last_noid_text
                        ):
                            break

                    items_to_process.append((cur, raw_text, text, key))
                    cur = get_prev_message_item(cur)

                if not items_to_process:
                    time.sleep(self.poll)
                    continue

                last_raw = extract_text_deep(last_item) or ""
                last_text = last_raw.rstrip()
                key_last = _msg_key(last_item, last_text)
                self._last_key = key_last
                self._last_noid_text = last_text if (key_last is None and self.need_nickname) else None

                for item, raw_text, text, key in reversed(items_to_process):

                    has_trailing_ws = bool(raw_text and raw_text[-1].isspace())
                    if has_trailing_ws:
                        mtype = MessageType.TEXT
                    else:
                        mtype = classify_by_classname(item)

                    enable_echo_for_this = self._use_echo and (mtype == MessageType.TEXT)

                    is_self: Optional[bool] = None
                    sender: Optional[str] = None

                    # 自回声检测（仅文本）
                    is_echo = False
                    if enable_echo_for_this:
                        h = _hash_text_for_echo(text)
                        hwnd = get_hwnd_from_ctrl(self._win) or 0

                        if hwnd:
                            with self._lock:
                                if (hwnd, h) in self._recent_sent:
                                    is_echo = True
                                    self._recent_sent = [
                                        pair for pair in self._recent_sent
                                        if not (pair[0] == hwnd and pair[1] == h)
                                    ]

                    if is_echo:
                        is_self = True
                        sender = None
                    else:
                        if self.need_nickname:
                            is_self, sender = self._get_nickname(item)
                        else:
                            is_self = None

                    file_name: Optional[str] = None
                    if mtype == MessageType.FILE:
                        file_name = _extract_file_name(item, raw_text)

                    msg = ChatMessage(
                        group=self.title,
                        text=text,
                        ts=time.time(),
                        mtype=mtype,
                        raw_text=raw_text,
                        is_self=is_self,
                        sender=sender,
                        internal_tag=("self_echo" if is_self else None),
                        file_name=file_name,
                    )

                    # 新增：把当前 UI 控件挂到消息上，后续 save_xxx 可以直接用
                    msg._node = item

                    msg._key = key
                    msg.bind_actions(
                        DefaultMessageActions(
                            self._driver,
                            self.title,
                            base_dir=self._save_base_dir,   # 顺便把保存目录传进去更方便
                        )
                    )

                    # ===== 自动保存图片/文件（带重试） =====
                    try:
                        file_path: Optional[str] = None

                        # 只有在开启对应开关 & 类型匹配时才进入媒体保存流程
                        need_media_save = (
                                (mtype == MessageType.IMAGE and self._auto_save_image) or
                                (mtype == MessageType.FILE and self._auto_save_file)
                        )

                        if need_media_save:
                            # 注意：整个“置前 + 右键 + 剪贴板 + 保存”用一把全局锁串行
                            with _MEDIA_CLIPBOARD_LOCK:
                                file_path = self._auto_save_media_if_needed(item, mtype)

                            if file_path:
                                msg.file_path = file_path
                            else:
                                # 仅调试提示一下，不影响整体流程
                                print(
                                    f"[{self.title}] auto_save: {mtype} "
                                    f"连续 {AUTO_SAVE_MAX_TRY} 次右键复制失败，放弃本条"
                                )

                    except Exception as e:
                        print(f"[{self.title}] auto_save 异常：{e}")

                    try:
                        if self._cb_param_count >= 3:
                            self.on_message(self.title, msg, reply_callable)
                        else:
                            self.on_message(self.title, msg)
                    except Exception as e:
                        print(f"[{self.title}] on_message 异常：{e}")

                time.sleep(self.poll)


# ====== 多群管理 ======
class MultiChatManager:
    def __init__(
        self,
        titles: Iterable[str],
        on_message: Optional[OnMessage] = None,
        *,
        driver: WeChatDriver,
        need_nickname: bool = True,
        poll_sec: float = 0.15,
        license_manager: Optional[LicenseManager] = None,
        bring_front_on_new: bool | None = None,
        auto_save_image: bool = False,   # 传给所有 listener 的默认值
        auto_save_file: bool = False,
        save_base_dir: Optional[str] = None,
    ):
        self._listeners: Dict[str, ChatWindowListener] = {}
        self._chat_wnd_by_title: Dict[str, ChatWnd] = {}
        self._lock = threading.Lock()
        self._msg_queue: Dict[ChatWnd, List[ChatMessage]] = {}

        self._need_nickname_default = bool(need_nickname)
        self._poll_sec_default = poll_sec if poll_sec and poll_sec > 0 else 0.15
        self._lm = license_manager or LicenseManager()
        self._driver = driver

        self._auto_save_image_default = bool(auto_save_image)
        self._auto_save_file_default = bool(auto_save_file)
        self._save_base_dir_default = save_base_dir

        self._user_cb = on_message
        if on_message:
            try:
                self._user_cb_param_count = len(inspect.signature(on_message).parameters)
            except Exception:
                self._user_cb_param_count = 2
        else:
            self._user_cb_param_count = 0

        self.add_listens(titles, need_nickname=need_nickname, poll_sec=poll_sec)

    def add_listens(
        self,
        titles: Iterable[str],
        *,
        need_nickname: bool | None = None,
        poll_sec: float | None = None,
        auto_save_image: Optional[bool] = None,
        auto_save_file: Optional[bool] = None,
        save_base_dir: Optional[str] = None,
    ) -> None:
        if not titles:
            return

        nn = self._need_nickname_default if need_nickname is None else bool(need_nickname)
        ps = self._poll_sec_default if (poll_sec is None or poll_sec <= 0) else float(poll_sec)

        asi = self._auto_save_image_default if auto_save_image is None else bool(auto_save_image)
        asf = self._auto_save_file_default if auto_save_file is None else bool(auto_save_file)
        sbd = save_base_dir if save_base_dir is not None else self._save_base_dir_default

        for t in titles:
            t2 = (t or "").strip()
            if not t2:
                continue
            if t2 in self._listeners:
                continue

            chat_wnd = ChatWnd(t2)
            self._chat_wnd_by_title[t2] = chat_wnd

            listener = ChatWindowListener(
                t2,
                self._on_message_from_listener,
                driver=self._driver,
                need_nickname=nn,
                poll_sec=ps,
                license_manager=self._lm,
                auto_save_image=asi,
                auto_save_file=asf,
                save_base_dir=sbd,
            )
            self._listeners[t2] = listener

    def _on_message_from_listener(
        self,
        group: str,
        msg: ChatMessage,
        reply_callable: Optional[Callable[[str], bool]] = None,
    ) -> None:
        chat_wnd = self._chat_wnd_by_title.get((group or "").strip())
        if not chat_wnd:
            return

        chat_wnd._record_incoming(msg.text, msg.is_self)
        if reply_callable:
            chat_wnd._update_reply_fn(reply_callable)

        with self._lock:
            self._msg_queue.setdefault(chat_wnd, []).append(msg)

        if self._user_cb:
            try:
                if self._user_cb_param_count >= 3 and reply_callable:
                    self._user_cb(group, msg, reply_callable)
                else:
                    self._user_cb(group, msg)
            except Exception as e:
                print(f"[{group}] 用户 on_message 回调异常：{e}")

    def start_all(self) -> None:
        for ls in self._listeners.values():
            if not ls.is_alive():
                ls.start()

    def stop_all(self, *, join: bool = True, timeout: float = 1.5) -> None:
        for ls in self._listeners.values():
            ls.stop()
        if join:
            for ls in self._listeners.values():
                ls.join(timeout=timeout)

    def alive(self) -> Dict[str, bool]:
        return {t: th.is_alive() for t, th in self._listeners.items()}

    def push_outgoing_preview(self, title: str, text: str) -> None:
        ls = self._listeners.get((title or "").strip())
        if ls:
            ls.push_outgoing_preview(text)

    def get_listen_messages(
        self,
        *,
        clear: bool = True,
    ) -> Dict[ChatWnd, List[ChatMessage]]:
        with self._lock:
            if not self._msg_queue:
                return {}
            result = {cw: msgs[:] for cw, msgs in self._msg_queue.items()}
            if clear:
                self._msg_queue.clear()
            return result

    def get_chat_wnd(self, title: str) -> Optional[ChatWnd]:
        return self._chat_wnd_by_title.get((title or "").strip())
