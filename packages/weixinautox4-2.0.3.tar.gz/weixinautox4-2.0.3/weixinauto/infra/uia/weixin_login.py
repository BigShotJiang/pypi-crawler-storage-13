import ctypes
from ctypes import wintypes
from typing import Optional

import uiautomation as uia
import time

class WeChatLoginChecker:
    """负责检查微信登录状态的类"""

    ALLOWED_EXE = {"weixin.exe"}  # 仅支持新版微信进程

    def __init__(self):
        self._hwnd: Optional[int] = None

    def _find_wechat_hwnd(self) -> Optional[int]:
        """通过进程和窗口类名查找微信主窗口"""
        prefer = ("mmui::MainWindow", "WeChatMainWndForPC")  # 微信主窗口的类名
        best, best_rank = None, 999  # 用于记录最佳窗口和排名
        for hwnd, _, class_name in self._enum_windows():
            pid = self._get_pid(hwnd)
            if not pid:
                continue

            # 只关注 "weixin.exe" 进程中的窗口
            p = self._get_image(pid) or ""
            exe = (p.rsplit("\\", 1)[-1] if p else "").lower()
            if exe not in self.ALLOWED_EXE:  # 只关心 weixin.exe 进程
                continue

            # 使用 UIA 控件获取类名
            ctrl = uia.ControlFromHandle(hwnd)
            if not ctrl:
                continue
            window_class = getattr(ctrl, "ClassName", "")
            title = getattr(ctrl, "Name", "")
            # 判断标题是否包含 "微信" 或 "weixin"
            if "微信" not in title and "weixin" not in title.lower():
                continue

            # 更精确的类名匹配，区分主窗口和子窗口
            if window_class in prefer:
                try:
                    rank = prefer.index(window_class)
                except ValueError:
                    rank = len(prefer)

                # 记录最佳窗口句柄
                if rank < best_rank:
                    best, best_rank = hwnd, rank
            else:
                best, best_rank = hwnd, 0
        return best

    def _enum_windows(self):
        """枚举当前系统中所有的窗口"""
        user32 = ctypes.windll.user32
        EnumWindows = user32.EnumWindows
        EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        GetWindowTextW = user32.GetWindowTextW
        GetClassNameW = user32.GetClassNameW
        GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        out = []

        def _cb(hwnd, _):
            tbuf = ctypes.create_unicode_buffer(512)
            cbuf = ctypes.create_unicode_buffer(256)
            GetWindowTextW(hwnd, tbuf, 512)
            GetClassNameW(hwnd, cbuf, 256)
            out.append((hwnd, tbuf.value, cbuf.value))
            return True

        EnumWindows(EnumWindowsProc(_cb), 0)
        return out

    def _get_pid(self, hwnd: int) -> int:
        """获取窗口对应的进程 PID"""
        pid = wintypes.DWORD(0)
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value or 0)

    def _get_image(self, pid: int) -> Optional[str]:
        """获取进程的路径"""
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x1000, False, pid) or k32.OpenProcess(0x0400, False, pid)
        if not h:
            return None
        try:
            QueryFullProcessImageNameW = k32.QueryFullProcessImageNameW
            QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
            QueryFullProcessImageNameW.restype = wintypes.BOOL
            buf = ctypes.create_unicode_buffer(520)
            size = wintypes.DWORD(520)
            if QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                return buf.value
            return None
        finally:
            k32.CloseHandle(h)

    def is_logged_in(self) -> bool:
        hwnd=self._find_wechat_hwnd()
        if not hwnd:
            return True
        else:
            return False

