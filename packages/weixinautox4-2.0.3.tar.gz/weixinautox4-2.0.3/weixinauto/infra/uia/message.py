# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Protocol

from .message_extract import MessageType


class MessageAction(Protocol):
    """
    动作接口：具体实现由 DefaultMessageActions 完成。
    这里只定义签名，避免循环依赖。
    """

    def save_file(
        self,
        msg: "ChatMessage",
        base_dir: Optional[str] = None,
    ) -> Optional[str]:
        ...

    def save_image(
        self,
        msg: "ChatMessage",
        base_dir: Optional[str] = None,
    ) -> Optional[str]:
        ...


@dataclass
class ChatMessage:
    """
    微信一条消息的抽象：
      - group: 群名 / 会话名
      - text: 解析后的纯文本
      - ts:   时间戳（float）
      - mtype: 消息类型（文本 / 图片 / 文件 / …）
      - raw_text: 原始文本（带换行）
      - is_self: 是否自己发的
      - sender: 昵称（开启 need_nickname=True 时才会有）
      - internal_tag: 内部标签，用来做“自回声”等标记
      - file_name: 文件名称
      - file_path: 文件路径
    """

    group: str
    text: str
    ts: float
    mtype: MessageType
    raw_text: str = ""
    is_self: Optional[bool] = None
    sender: Optional[str] = None
    internal_tag: Optional[str] = None
    file_name: Optional[str] = None  # 如果是文件消息，这里记录文件名（例如 爱房通年度汇报.pptx）
    file_path: Optional[str] = None  # 如果是文件消息，这里记录文件名（例如 爱房通年度汇报.pptx）

    # 运行时字段（监听时填充）
    _key: Optional[str] = field(default=None, repr=False)              # 用于重新定位 DOM 节点
    _node = None
    actions: Optional[MessageAction] = field(default=None, repr=False) # DefaultMessageActions 实例

    # ====== 绑定动作对象 ======
    def bind_actions(self, actions: MessageAction) -> None:
        """
        在监听器里调用，用来把 DefaultMessageActions 绑定到当前消息。
        之后业务侧就可以直接 msg.save_file() / msg.save_image() 了。
        """
        self.actions = actions

    # ====== 对外快捷方法：msg.save_file(...) / msg.save_image(...) ======
    def save_file(self, base_dir: Optional[str] = None) -> Optional[str]:
        """
        保存“文件类型”的消息到本地：
          - 默认保存到 weixin_file 目录（实现里会处理）
          - base_dir 不为空时，优先使用 base_dir 作为根目录
        """
        if not self.actions:
            print("[ChatMessage] 当前消息未绑定 actions，无法 save_file")
            return None
        return self.actions.save_file(self, base_dir=base_dir)

    def save_image(self, base_dir: Optional[str] = None) -> Optional[str]:
        """
        保存“图片类型”的消息到本地：
          - 默认保存到 weixin_file 目录（实现里会处理）
          - base_dir 不为空时，优先使用 base_dir 作为根目录
        """
        if not self.actions:
            print("[ChatMessage] 当前消息未绑定 actions，无法 save_image")
            return None
        return self.actions.save_image(self, base_dir=base_dir)
