# -*- coding: utf-8 -*-
from __future__ import annotations

import ctypes
import time
from ctypes import wintypes
from typing import Optional

import uiautomation as uia


# =====================================================================================
# 兼容类型（wintypes.ULONG_PTR 在部分 Python 版本缺失）
# =====================================================================================

try:
    ULONG_PTR = wintypes.ULONG_PTR  # type: ignore[attr-defined]
except AttributeError:  # Py<=3.11 的某些发行版没有
    ULONG_PTR = ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_ulong


# =====================================================================================
# Win32 常量
# =====================================================================================

# 剪贴板
CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002

# SendInput / 键盘
INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002

VK_CONTROL = 0x11
VK_SHIFT   = 0x10
VK_MENU    = 0x12  # Alt
VK_RETURN  = 0x0D
VK_ESCAPE  = 0x1B
VK_BACK    = 0x08
VK_A       = 0x41
VK_C       = 0x43
VK_V       = 0x56


# =====================================================================================
# Win32 函数与结构（64 位安全声明）
# =====================================================================================

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

# --- 结构体 ---

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk",        wintypes.WORD),
        ("wScan",      wintypes.WORD),
        ("dwFlags",    wintypes.DWORD),
        ("time",       wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx",        wintypes.LONG),
        ("dy",        wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags",   wintypes.DWORD),
        ("time",      wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [
        ("uMsg",   wintypes.DWORD),
        ("wParamL", wintypes.WORD),
        ("wParamH", wintypes.WORD),
    ]


class _INPUT_UNION(ctypes.Union):
    _fields_ = [
        ("ki", KEYBDINPUT),
        ("mi", MOUSEINPUT),
        ("hi", HARDWAREINPUT),
    ]


class INPUT(ctypes.Structure):
    _anonymous_ = ("union",)
    _fields_ = [
        ("type",  wintypes.DWORD),
        ("union", _INPUT_UNION),
    ]


# --- SendInput ---
SendInput = user32.SendInput
SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
SendInput.restype = wintypes.UINT


# --- 剪贴板（必须显式声明 64 位安全签名） ---
OpenClipboard = user32.OpenClipboard
OpenClipboard.argtypes = [wintypes.HWND]
OpenClipboard.restype = wintypes.BOOL

CloseClipboard = user32.CloseClipboard
CloseClipboard.argtypes = []
CloseClipboard.restype = wintypes.BOOL

EmptyClipboard = user32.EmptyClipboard
EmptyClipboard.argtypes = []
EmptyClipboard.restype = wintypes.BOOL

SetClipboardData = user32.SetClipboardData
SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
SetClipboardData.restype = wintypes.HANDLE

GetClipboardData = user32.GetClipboardData
GetClipboardData.argtypes = [wintypes.UINT]
GetClipboardData.restype = wintypes.HANDLE

GlobalAlloc = kernel32.GlobalAlloc
GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
GlobalAlloc.restype = wintypes.HGLOBAL

GlobalLock = kernel32.GlobalLock
GlobalLock.argtypes = [wintypes.HGLOBAL]
GlobalLock.restype = ctypes.c_void_p

GlobalUnlock = kernel32.GlobalUnlock
GlobalUnlock.argtypes = [wintypes.HGLOBAL]
GlobalUnlock.restype = wintypes.BOOL


# =====================================================================================
# SendInput 基础封装
# =====================================================================================

def _key_input(vk: int, down: bool) -> INPUT:
    ki = KEYBDINPUT(
        wVk=vk,
        wScan=0,
        dwFlags=(0 if down else KEYEVENTF_KEYUP),
        time=0,
        dwExtraInfo=ULONG_PTR(0),
    )
    u = _INPUT_UNION()
    u.ki = ki
    return INPUT(type=INPUT_KEYBOARD, union=u)


def _send_inputs(inputs: list[INPUT]) -> None:
    """一次性发送多键事件（必须传 arr[0] 的指针，不能传数组指针）"""
    if not inputs:
        return
    arr = (INPUT * len(inputs))(*inputs)
    # 关键点：传 arr[0] 的地址
    SendInput(len(inputs), ctypes.byref(arr[0]), ctypes.sizeof(INPUT))


def send_vk(vk: int) -> None:
    """按下并抬起一个虚拟键（Enter/Esc 等简单键）"""
    _send_inputs([_key_input(vk, True), _key_input(vk, False)])


def send_enter() -> None:
    _send_inputs([_key_input(VK_RETURN, True), _key_input(VK_RETURN, False)])


def send_escape() -> None:
    _send_inputs([_key_input(VK_ESCAPE, True), _key_input(VK_ESCAPE, False)])


def send_ctrl_enter() -> None:
    _send_inputs([
        _key_input(VK_CONTROL, True),
        _key_input(VK_RETURN, True),
        _key_input(VK_RETURN, False),
        _key_input(VK_CONTROL, False),
    ])


def send_ctrl_a_then_backspace() -> None:
    """Ctrl+A 全选，再退格删除（用 SendInput，稳定不吐 ctypes.ArgumentError）"""
    _send_inputs([
        _key_input(VK_CONTROL, True),
        _key_input(VK_A, True),
        _key_input(VK_A, False),
        _key_input(VK_CONTROL, False),
        _key_input(VK_BACK, True),
        _key_input(VK_BACK, False),
    ])


def send_ctrl_v() -> None:
    _send_inputs([
        _key_input(VK_CONTROL, True),
        _key_input(VK_V, True),
        _key_input(VK_V, False),
        _key_input(VK_CONTROL, False),
    ])


# =====================================================================================
# 焦点辅助
# =====================================================================================

def focus_control(ctrl) -> None:
    """尝试把焦点给控件（失败则 ClickCenter 兜底）"""
    if not ctrl:
        return
    try:
        ctrl.SetFocus()
        return
    except Exception:
        pass
    try:
        ctrl.ClickCenter()
    except Exception:
        pass


# =====================================================================================
# 剪贴板工具（Unicode）
# =====================================================================================

def _open_clipboard_retry(hwnd: int = 0, retries: int = 8, delay_sec: float = 0.01) -> bool:
    for _ in range(max(1, retries)):
        if OpenClipboard(hwnd):
            return True
        time.sleep(max(0.001, delay_sec))
    return False


def set_clipboard_text(text: str) -> bool:
    """
    以 CF_UNICODETEXT 写入剪贴板（UTF-16LE，末尾双零）。
    64 位安全：HGLOBAL / void* / HANDLE 均已正确声明。
    """
    s = text or ""
    data = s.encode("utf-16-le") + b"\x00\x00"
    size = len(data)

    if not _open_clipboard_retry(0):
        return False
    try:
        # 有的系统 EmptyClipboard 会返回 False，但 SetClipboardData 仍可成功；不中断
        try:
            EmptyClipboard()
        except Exception:
            pass

        h_global = GlobalAlloc(GMEM_MOVEABLE, size)
        if not h_global:
            return False

        ptr = GlobalLock(h_global)
        if not ptr:
            GlobalUnlock(h_global)
            return False
        try:
            ctypes.memmove(ptr, data, size)
        finally:
            GlobalUnlock(h_global)

        # 成功后句柄归系统管理，不要再释放
        if not SetClipboardData(CF_UNICODETEXT, h_global):
            return False

        return True
    finally:
        CloseClipboard()


def get_clipboard_text() -> Optional[str]:
    if not _open_clipboard_retry(0):
        return None
    try:
        handle = GetClipboardData(CF_UNICODETEXT)
        if not handle:
            return None
        ptr = GlobalLock(handle)
        if not ptr:
            GlobalUnlock(handle)
            return None
        try:
            return ctypes.wstring_at(ptr)
        finally:
            GlobalUnlock(handle)
    finally:
        CloseClipboard()


def paste_via_ctrl_v() -> None:
    """使用 SendInput 执行 Ctrl+V（避免 '^v' 被当普通字符）"""
    send_ctrl_v()


# =====================================================================================
# 统一的编辑框写入：一次性、最稳策略
# =====================================================================================

def safe_set_edit_text(edit, text: str) -> bool:
    """
    安全向编辑框写入文本（微信专用版）：
      1) 聚焦 edit
      2) send_ctrl_a_then_backspace() 清空原内容
      3) set_clipboard_text(text) + paste_via_ctrl_v() 粘贴
      4) 若剪贴板方案失败，则逐字符 uia.SendKeys 兜底
    """
    t = (text or "").strip()
    if not t:
        return False

    # 先确认控件存在且有效
    try:
        if not edit or not edit.Exists(0, 0):
            return False
    except Exception:
        return False

    try:
        # 1) 聚焦输入框
        try:
            focus_control(edit)
        except Exception:
            return False
        time.sleep(0.02)

        # 2) 清空原有内容（失败也不强制终止）
        try:
            send_ctrl_a_then_backspace()
            time.sleep(0.02)
        except Exception:
            pass

        # 3) 尝试剪贴板方案
        clipboard_ok = False
        try:
            if set_clipboard_text(t):
                try:
                    paste_via_ctrl_v()  # 内部 Ctrl+V
                except Exception:
                    # 尝试直接 "^v" 作为补救
                    try:
                        uia.SendKeys("^v")
                    except Exception:
                        pass
                else:
                    # paste_via_ctrl_v 没抛异常就认为剪贴板路径成功
                    clipboard_ok = True

                if clipboard_ok:
                    time.sleep(0.05)
                    return True
        except Exception:
            # 剪贴板路径整体异常，继续走兜底
            clipboard_ok = False

        # 4) 兜底：逐字符 SendKeys
        try:
            # 此时输入框仍在焦点上，直接逐字符输入
            for ch in t:
                try:
                    uia.SendKeys(ch)
                    # 可选：适当 sleep，避免极端情况下太快丢键
                    time.sleep(0.002)
                except Exception:
                    # 某个字符失败不影响整体
                    pass
            time.sleep(0.02)
            return True
        except Exception:
            return False

    except Exception:
        return False





def _mouse_left_click_at(x: int, y: int):
    user32.SetCursorPos(x, y)
    user32.mouse_event(0x0002, 0, 0, 0, 0)  # MOUSEEVENTF_LEFTDOWN
    user32.mouse_event(0x0004, 0, 0, 0, 0)  # MOUSEEVENTF_LEFTUP

def _mouse_double_click_center(ctrl):
    try:
        rect = ctrl.BoundingRectangle
        cx = int((rect.left + rect.right) // 2)
        cy = int((rect.top + rect.bottom) // 2)
        _mouse_left_click_at(cx, cy)
        time.sleep(0.05)
        _mouse_left_click_at(cx, cy)
        time.sleep(0.12)
        return True
    except Exception:
        return False

