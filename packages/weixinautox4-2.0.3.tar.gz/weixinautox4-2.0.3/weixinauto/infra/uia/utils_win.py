# utils_win.py
# -*- coding: utf-8 -*-
import ctypes, time
from typing import Optional
import uiautomation as uia
import win32gui, win32con, win32api

user32 = ctypes.windll.user32

# ---- SendInput structs ----
class MOUSEINPUT(ctypes.Structure):
    _fields_ = (("dx", ctypes.c_long), ("dy", ctypes.c_long), ("mouseData", ctypes.c_ulong),
                ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)))
class KEYBDINPUT(ctypes.Structure):
    _fields_ = (("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)))
class HARDWAREINPUT(ctypes.Structure):
    _fields_ = (("uMsg", ctypes.c_ulong), ("wParamL", ctypes.c_short), ("wParamH", ctypes.c_ushort))
class INPUT_UNION(ctypes.Union):
    _fields_ = (("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT))
class INPUT(ctypes.Structure):
    _fields_ = (("type", ctypes.c_ulong), ("union", INPUT_UNION))

INPUT_MOUSE = 0
INPUT_KEYBOARD = 1
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_ABSOLUTE = 0x8000
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP   = 0x0004
KEYEVENTF_KEYUP      = 0x0002
VK_ESCAPE            = 0x1B
WM_KEYDOWN, WM_KEYUP = 0x0100, 0x0101

def screen_size():
    return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)


def iter_bfs(root: uia.Control, max_nodes: int = 15000):
    """
    轻量 BFS 遍历 UIAutomation 树，最多 max_nodes 个节点。
    用于在窗口内查找控件；对异常与不可访问子节点做了保护。
    """
    if not root:
        return
    q, seen = [root], 0
    while q and seen < max_nodes:
        n = q.pop(0); seen += 1
        yield n
        try:
            ch = n.GetChildren()
            if ch:
                q.extend(ch)
        except Exception:
            pass
def send_escape_with_sendinput():
    def send(inp): user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))
    send(INPUT(type=INPUT_KEYBOARD, union=INPUT_UNION(ki=KEYBDINPUT(wVk=VK_ESCAPE,wScan=0,dwFlags=0,time=0,dwExtraInfo=None))))
    send(INPUT(type=INPUT_KEYBOARD, union=INPUT_UNION(ki=KEYBDINPUT(wVk=VK_ESCAPE,wScan=0,dwFlags=KEYEVENTF_KEYUP,time=0,dwExtraInfo=None))))

def send_escape_to_hwnd(hwnd:int):
    try:
        user32.PostMessageW(hwnd, WM_KEYDOWN, VK_ESCAPE, 0)
        user32.PostMessageW(hwnd, WM_KEYUP,   VK_ESCAPE, 0)
    except Exception:
        send_escape_with_sendinput()

def get_rect(ctrl):
    rc = ctrl.BoundingRectangle
    return rc.left, rc.top, rc.right, rc.bottom, rc.width(), rc.height()

def get_hwnd_from_ctrl(ctrl: uia.Control)->int:
    try:
        h = int(getattr(ctrl,"NativeWindowHandle",0) or 0)
        if h: return h
    except Exception: pass
    try:
        h = int(getattr(ctrl,"Handle",0) or 0)
        return h or 0
    except Exception: return 0

def lock_window_width(win: uia.Control, target_width:int)->None:
    try:
        hwnd = get_hwnd_from_ctrl(win)
        if not hwnd: return
        l,t,r,b = win32gui.GetWindowRect(hwnd)
        cur_w, cur_h = max(1,r-l), max(1,b-t)
        if abs(cur_w-target_width)<=2: return
        win32gui.SetWindowPos(hwnd, 0, l,t, target_width, cur_h, win32con.SWP_NOZORDER|win32con.SWP_NOACTIVATE)
    except Exception: pass
def is_iconic(hwnd:int) -> bool:
    try:
        return bool(user32.IsIconic(hwnd))
    except Exception:
        return False
def is_alive(ctrl: Optional[uia.Control]) -> bool:
    if not ctrl:
        return False
    try:
        _ = ctrl.BoundingRectangle
        return ctrl.Exists(0, 0)
    except Exception:
        return False
def bring_to_front(hwnd:int, *, gentle:bool=True) -> bool:
    """
    将窗口置前/还原：
      - gentle=True：先 SW_RESTORE，再 SetForegroundWindow
      - 如果失败，发送一次 Alt 抖动（允许前置），再重试
    """
    try:
        if not hwnd or not win32gui.IsWindow(hwnd):
            return False
        # 还原最小化
        if is_iconic(hwnd):
            user32.ShowWindow(hwnd, win32con.SW_RESTORE)
        if gentle:
            try:
                user32.SetForegroundWindow(hwnd)
            except Exception:
                pass

        # 检查是否已在前台
        try:
            fg = user32.GetForegroundWindow()
            if fg == hwnd:
                return True
        except Exception:
            pass

        # Alt 抖动 + 再次尝试前置
        try:
            win32api.keybd_event(win32con.VK_MENU, 0, 0, 0)                # Alt down
            win32api.keybd_event(win32con.VK_MENU, 0, win32con.KEYEVENTF_KEYUP, 0)  # Alt up
            user32.SetForegroundWindow(hwnd)
        except Exception:
            pass

        try:
            fg = user32.GetForegroundWindow()
            return fg == hwnd
        except Exception:
            return False
    except Exception:
        return False


def window_rect_big_enough(hwnd:int, min_w:int=300, min_h:int=200) -> bool:
    """判断窗口是否“足够展开”，用于决定是否需要置前/还原。"""
    try:
        l,t,r,b = win32gui.GetWindowRect(hwnd)
        return (r - l) >= min_w and (b - t) >= min_h
    except Exception:
        return False