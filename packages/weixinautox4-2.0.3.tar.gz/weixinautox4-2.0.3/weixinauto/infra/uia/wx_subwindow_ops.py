# -*- coding: utf-8 -*-
# wx_subwindow_ops.py
"""
微信聊天子窗口操作工具类：

能力：
  - 查找聊天子窗口（mmui::ChatSingleWindow）
  - 查找消息列表 ListControl
  - 获取最后一条消息控件
  - 调整子窗口高度为全屏高度
  - 滚动消息列表（鼠标滚轮或 PageUp/PageDown）
  - 对指定消息按比例位置进行右键
  - 在右键菜单附近点击“复制”

后续 chat_listener / message_actions 可以直接复用这里的能力，
避免各处自己写 BFS 和坐标计算。
"""

from __future__ import annotations

import time
import ctypes
from ctypes import wintypes as _w
from typing import Optional, List

import uiautomation as uia


class ChatSubWindowOps:
    """
    子窗口操作类：
      - 以聊天子窗口标题为“定位锚点”，内部缓存一个 win（uia.Control）
      - 提供一系列对该子窗的操作工具方法
    """

    def __init__(self, title: str, *, timeout_sec: float = 1.5):
        self.title = (title or "").strip()
        self.timeout_sec = timeout_sec
        self._win: Optional[uia.Control] = None

    # ====== 通用 BFS 工具 ======
    @staticmethod
    def _bfs_children(root: uia.Control, max_nodes: int = 20000):
        """简单 BFS 遍历，带上限防止死循环。"""
        q: List[uia.Control] = [root]
        seen = 0
        while q and seen < max_nodes:
            n = q.pop(0)
            seen += 1
            yield n
            try:
                ch = n.GetChildren()
                if ch:
                    q.extend(ch)
            except Exception:
                pass

    # ====== 0. 获取 / 查找子窗口 ======
    def get_window(self) -> Optional[uia.Control]:
        """
        获取（并缓存）聊天子窗口：
          - ClassName == "mmui::ChatSingleWindow"
          - Name 包含标题（或相互包含）
        """
        if self._win:
            try:
                # 简单活性检查
                _ = self._win.BoundingRectangle
                if self._win.Exists(0, 0):
                    return self._win
            except Exception:
                self._win = None

        title = self.title
        if not title:
            print("[wx_subwindow_ops] get_window: title 为空")
            return None

        end = time.time() + max(0.5, float(self.timeout_sec))

        while time.time() < end:
            root = uia.GetRootControl()
            try:
                for n in self._bfs_children(root, max_nodes=10000):
                    try:
                        cls = (getattr(n, "ClassName", "") or "").strip()
                        nm = (getattr(n, "Name", "") or "").strip()
                    except Exception:
                        continue

                    if cls != "mmui::ChatSingleWindow":
                        continue

                    if title in nm or nm in title:
                        print(f"[wx_subwindow_ops] 命中聊天子窗: cls={cls}, name={nm!r}")
                        self._win = n
                        return n
            except Exception:
                pass

            time.sleep(0.2)

        print(f"[wx_subwindow_ops] 超时未找到 mmui::ChatSingleWindow, title={title!r}")
        return None

    # ====== 1. 调整子窗口高度到屏幕高度 ======
    def resize_full_height(self, win: Optional[uia.Control] = None) -> bool:
        """
        把聊天子窗口的高度拉到和屏幕高度一致（只调高度，不改宽度）。
        """
        if not win:
            win = self.get_window()
        if not win:
            return False

        try:
            hwnd = int(getattr(win, "NativeWindowHandle", 0) or 0)
        except Exception:
            hwnd = 0

        if not hwnd:
            print("[wx_subwindow_ops] resize: 子窗口 NativeWindowHandle 为空")
            return False

        user32 = ctypes.windll.user32

        # 获取屏幕高度
        SM_CYSCREEN = 1
        screen_h = user32.GetSystemMetrics(SM_CYSCREEN)

        # 获取当前窗口矩形
        rect = _w.RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            print("[wx_subwindow_ops] resize: GetWindowRect 失败")
            return False

        left, top, right, bottom = rect.left, rect.top, rect.right, rect.bottom
        width = right - left
        if width <= 0:
            print("[wx_subwindow_ops] resize: 当前窗口宽度异常")
            return False

        # 把窗口拉到屏幕等高（top 设为 0，也可以根据需要自己改）
        new_left = left
        new_top = 0
        new_width = width
        new_height = screen_h

        ok = user32.MoveWindow(hwnd, new_left, new_top, new_width, new_height, True)
        print(
            f"[wx_subwindow_ops] resize: hwnd={hwnd}, old=({left},{top},{right},{bottom}), "
            f"new=({new_left},{new_top},{new_left+new_width},{new_top+new_height}), ok={bool(ok)}"
        )
        return bool(ok)

    # ====== 2. 查找消息列表 & 最后一条消息 ======
    def _find_message_list(self, win: uia.Control) -> Optional[uia.Control]:
        """
        在聊天子窗中查找“消息列表”控件（ListControl）。

        优先规则：
          1) ControlTypeName == "ListControl"
          2) Name 中包含 “消息”
          3) 找不到含“消息”的，就退而求其次选第一个 ListControl
        """
        lists: List[uia.Control] = []
        try:
            for n in self._bfs_children(win, max_nodes=8000):
                ctn = (getattr(n, "ControlTypeName", "") or "").strip()
                if ctn != "ListControl":
                    continue
                lists.append(n)
        except Exception:
            pass

        if not lists:
            print("[wx_subwindow_ops] 未找到 ListControl 消息列表")
            return None

        for lst in lists:
            try:
                nm = (getattr(lst, "Name", "") or "").strip()
            except Exception:
                nm = ""
            if "消息" in nm:
                print(f"[wx_subwindow_ops] 使用消息列表: {nm!r}")
                return lst

        print("[wx_subwindow_ops] 使用第一个 ListControl 作为消息列表")
        return lists[0]

    def get_last_message_item(self, win: Optional[uia.Control] = None) -> Optional[uia.Control]:
        """
        在聊天子窗中，获取“最后一条消息”的控件：
          - 找消息列表 ListControl
          - children = lst.GetChildren()
          - 返回 children[-1]
        """
        if not win:
            win = self.get_window()
        if not win:
            return None

        lst = self._find_message_list(win)
        if not lst:
            return None

        try:
            children = lst.GetChildren() or []
        except Exception:
            children = []

        if not children:
            print("[wx_subwindow_ops] 消息列表没有子项")
            return None

        item = children[-1]
        try:
            nm = (getattr(item, "Name", "") or "").strip()
            cls = (getattr(item, "ClassName", "") or "").strip()
            print(f"[wx_subwindow_ops] 最后一条消息: cls={cls}, name={nm!r}")
        except Exception:
            pass

        return item

    # ====== 3. 滚动消息列表 ======
    def scroll_message_list(
        self,
        direction: str = "up",
        steps: int = 3,
        use_wheel: bool = True,
        win: Optional[uia.Control] = None,
    ) -> None:
        """
        滚动消息列表：
          - direction="up"/"down"
          - steps：滚动次数
          - 默认用鼠标滚轮模拟，必要时可改为 PageUp/PageDown
        """
        if not win:
            win = self.get_window()
        if not win:
            return

        lst = self._find_message_list(win)
        if not lst:
            print("[wx_subwindow_ops] scroll: 未找到消息列表")
            return

        try:
            rc = lst.BoundingRectangle
            cx = int((rc.left + rc.right) / 2)
            cy = int((rc.top + rc.bottom) / 2)
        except Exception as e:
            print(f"[wx_subwindow_ops] scroll: 获取消息列表矩形失败: {e}")
            return

        user32 = ctypes.windll.user32
        SetCursorPos = user32.SetCursorPos
        mouse_event = user32.mouse_event

        MOUSEEVENTF_WHEEL = 0x0800
        wheel_delta = 120 if direction == "up" else -120  # Windows 上：正值一般内容往上走

        for i in range(max(1, int(steps))):
            if use_wheel:
                try:
                    SetCursorPos(cx, cy)
                    time.sleep(0.01)
                    mouse_event(MOUSEEVENTF_WHEEL, 0, 0, wheel_delta, 0)
                    print(f"[wx_subwindow_ops] scroll: step={i+1}, dir={direction}, pos=({cx},{cy})")
                except Exception as e:
                    print(f"[wx_subwindow_ops] scroll: 鼠标滚轮失败: {e}")
                    break
            else:
                try:
                    lst.SetFocus()
                    if direction == "up":
                        lst.SendKeys("{PageUp}")
                    else:
                        lst.SendKeys("{PageDown}")
                    print(f"[wx_subwindow_ops] scroll: step={i+1}, dir={direction}, key-mode")
                except Exception as e:
                    print(f"[wx_subwindow_ops] scroll: SendKeys 失败: {e}")
                    break

            time.sleep(0.08)

    # ====== 4. 关闭子窗口 ======
    def close_window(self, win: Optional[uia.Control] = None) -> bool:
        """
        关闭聊天子窗口：
          - 优先尝试 WindowPattern.Close()
          - 失败则发送 WM_CLOSE
        """
        if not win:
            win = self.get_window()
        if not win:
            return False

        try:
            wp = win.GetWindowPattern()
        except Exception:
            wp = None

        if wp:
            try:
                wp.Close()
                print("[wx_subwindow_ops] close: 使用 WindowPattern.Close() 成功")
                return True
            except Exception as e:
                print(f"[wx_subwindow_ops] close: WindowPattern.Close 失败: {e}")

        try:
            hwnd = int(getattr(win, "NativeWindowHandle", 0) or 0)
        except Exception:
            hwnd = 0

        if not hwnd:
            print("[wx_subwindow_ops] close: NativeWindowHandle 为空")
            return False

        user32 = ctypes.windll.user32
        WM_CLOSE = 0x0010
        ok = user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
        print(f"[wx_subwindow_ops] close: PostMessageW WM_CLOSE, hwnd={hwnd}, ok={bool(ok)}")
        return bool(ok)

    # ====== 5. 右键 + 菜单“复制”（通用） ======
    @staticmethod
    def _right_click_at(x: int, y: int) -> bool:
        """
        在指定【屏幕坐标】模拟鼠标右键（不移动真实鼠标）：
        - 通过 WindowFromPoint 拿到窗口句柄
        - ScreenToClient 转成客户区坐标
        - 用 PostMessageW 发送 WM_RBUTTONDOWN / WM_RBUTTONUP
        """
        try:
            import ctypes
            from ctypes import wintypes as _w
            import time

            user32 = ctypes.windll.user32

            # Win32 常量
            WM_RBUTTONDOWN = 0x0204
            WM_RBUTTONUP   = 0x0205
            MK_RBUTTON     = 0x0002

            class POINT(ctypes.Structure):
                _fields_ = [("x", _w.LONG), ("y", _w.LONG)]

            def _make_lparam(cx: int, cy: int) -> int:
                return (cy << 16) | (cx & 0xFFFF)

            # 1) 通过屏幕坐标找到窗口句柄
            pt = POINT(x, y)
            hwnd = user32.WindowFromPoint(pt)
            if not hwnd:
                print(f"[wx_subwindow_ops] 右键失败: WindowFromPoint 返回空句柄, point=({x},{y})")
                return False

            # 2) 屏幕坐标 -> 客户区坐标
            user32.ScreenToClient(hwnd, ctypes.byref(pt))
            cx, cy = pt.x, pt.y
            lp = _make_lparam(cx, cy)

            # 3) 发送右键按下 / 弹起消息（异步，不移动鼠标）
            user32.PostMessageW(hwnd, WM_RBUTTONDOWN, MK_RBUTTON, lp)
            time.sleep(0.02)
            user32.PostMessageW(hwnd, WM_RBUTTONUP, 0, lp)

            # 不动真实鼠标
            return True

        except Exception as e:
            print(f"[wx_subwindow_ops] 右键失败(PostMessageW): {e}")
            return False


    @staticmethod
    def _find_menu_root_and_items(
        item: uia.Control,
    ) -> tuple[Optional[uia.Control], List[uia.Control]]:
        """
        从某个 MenuItemControl 往上找“菜单容器”：
          - 一层层 GetParentControl()
          - 哪一层的子节点基本都是 MenuItemControl，就认为是菜单根
        返回: (menu_root, children_items)
        """
        cur = item
        max_up = 6

        for _ in range(max_up):
            try:
                parent = cur.GetParentControl()
            except Exception:
                parent = None

            if not parent:
                break

            try:
                children = parent.GetChildren() or []
            except Exception:
                children = []

            menu_items = [
                ch for ch in children
                if (getattr(ch, "ControlTypeName", "") or "").strip() == "MenuItemControl"
            ]

            if menu_items:
                return parent, menu_items

            cur = parent

        return None, []

    @staticmethod
    def _click_copy_near_point(
            base_x: int,
            base_y: int,
            candidate_names: Optional[List[str]] = None,
            timeout_sec: float = 1.5,
            *,
            click: bool = True,  # 新增参数：是否真的去点“复制”，否则只探测是否存在
    ) -> bool:
        """
        从 (base_x, base_y) 附近找到任意一个 MenuItemControl，
        然后：
          1) 用该控件往上找菜单根节点
          2) 在菜单的所有 MenuItem 子项里找 Name 包含 “复制”/“Copy” 的项
          3) 如果 click=True：用 PostMessageW 在该菜单项中心点模拟左键点击；
             否则只返回是否存在

        返回：
          - True：菜单中存在“复制”（且在 click=True 时已经点了）
          - False：没有找到“复制”或过程失败
        """
        if candidate_names is None:
            candidate_names = ["复制", "Copy"]

        end = time.time() + max(0.3, float(timeout_sec))

        # 局部扫描一圈，先拿到“任意一个菜单项”的控件作为锚点
        x_offsets = [10, 14, 20]        # 以 10 为主，稍微给一点冗余
        y_offsets = [16, 20, 24]    # 20 为主，稍微上下浮动一点

        menu_item_anchor: Optional[uia.Control] = None

        while time.time() < end and not menu_item_anchor:
            for dy in y_offsets:
                for dx in x_offsets:
                    x = base_x + dx
                    y = base_y + dy
                    try:
                        ctrl = uia.ControlFromPoint(x, y)
                    except Exception:
                        ctrl = None

                    if not ctrl:
                        continue

                    try:
                        ctn = (getattr(ctrl, "ControlTypeName", "") or "").strip()
                    except Exception:
                        continue

                    # 调试需要时可以开：
                    # print(f"[wx_subwindow_ops] probe ({x},{y}) -> {ctn}, {nm!r}, {cls!r}")

                    if ctn != "MenuItemControl":
                        continue

                    menu_item_anchor = ctrl
                    break

                if menu_item_anchor:
                    break

            # 扫一轮就够了
            break

        if not menu_item_anchor:
            return False

        # 2) 从这个菜单项往上找菜单根 + 全部菜单项
        menu_root, menu_items = ChatSubWindowOps._find_menu_root_and_items(menu_item_anchor)
        if not menu_root or not menu_items:
            return False

        # 3) 在所有菜单项里找名字包含“复制”的那一项
        target_item: Optional[uia.Control] = None
        for it in menu_items:
            try:
                nm = (getattr(it, "Name", "") or "").strip()
            except Exception:
                nm = ""
            if not nm:
                continue

            if any(cand and cand in nm for cand in candidate_names):
                target_item = it
                break

        if not target_item:
            return False

        # 只探测模式：找到就行，不点
        if not click:
            return True

        # 4) 对“复制”菜单项的中心点用 PostMessageW 模拟左键点击（不移动鼠标）
        try:
            rc = target_item.BoundingRectangle
            cx = int((rc.left + rc.right) / 2)
            cy = int((rc.top + rc.bottom) / 2)
        except Exception:
            return False

        try:
            import ctypes
            from ctypes import wintypes as _w

            user32 = ctypes.windll.user32

            WM_LBUTTONDOWN = 0x0201
            WM_LBUTTONUP = 0x0202
            MK_LBUTTON = 0x0001

            class POINT(ctypes.Structure):
                _fields_ = [("x", _w.LONG), ("y", _w.LONG)]

            def _make_lparam(xc: int, yc: int) -> int:
                return (yc << 16) | (xc & 0xFFFF)

            # 用菜单项中心点的屏幕坐标去找窗口句柄（一般是菜单窗口）
            pt = POINT(cx, cy)
            hwnd = user32.WindowFromPoint(pt)
            if not hwnd:
                print(f"[wx_subwindow_ops] _click_copy_near_point: WindowFromPoint 失败, point=({cx},{cy})")
                return False

            # 转成该窗口的客户区坐标
            user32.ScreenToClient(hwnd, ctypes.byref(pt))
            x_client, y_client = pt.x, pt.y
            lp = _make_lparam(x_client, y_client)

            # 发送左键按下 / 抬起消息（不移动真实鼠标）
            user32.PostMessageW(hwnd, WM_LBUTTONDOWN, MK_LBUTTON, lp)
            time.sleep(0.01)
            user32.PostMessageW(hwnd, WM_LBUTTONUP, 0, lp)

            return True
        except Exception as e:
            print(f"[wx_subwindow_ops] _click_copy_near_point: PostMessageW 点击失败: {e}")
            return False

    @staticmethod
    def copy_item_via_menu(
        item: uia.Control,
        x_ratio: float = 0.15,
        y_ratio: float = 0.18,
        timeout_sec: float = 2.0,
    ) -> bool:
        """
        对某条消息右键，并在弹出的菜单中点击“复制”：

        返回：
          - True  -> 已成功执行“复制”菜单（剪贴板里应该已有图片/文件）
          - False -> 没有找到“复制”菜单项，或任一步骤失败（可视为这条消息跳过）
        """
        try:
            rc = item.BoundingRectangle
            left, top, right, bottom = rc.left, rc.top, rc.right, rc.bottom
        except Exception as e:
            print(f"[wx_subwindow_ops] copy_item_via_menu: 获取矩形失败: {e}")
            return False

        width = right - left
        height = bottom - top
        if width <= 0 or height <= 0:
            print(
                f"[wx_subwindow_ops] copy_item_via_menu: 矩形异常 w={width}, h={height}"
            )
            return False

        x_ratio = max(0.0, min(1.0, float(x_ratio)))
        y_ratio = max(0.0, min(1.0, float(y_ratio)))

        x = int(left + width * x_ratio)
        y = int(top + height * y_ratio)


        time.sleep(0.06)
        # 1) 右键
        if not ChatSubWindowOps._right_click_at(x, y):
            return False

        time.sleep(0.25)

        # 2) 在菜单中点“复制”
        ok = ChatSubWindowOps._click_copy_near_point(
            x,
            y,
            candidate_names=["复制", "Copy"],
            timeout_sec=timeout_sec,
            click=True,   # 这里是真正点击
        )

        return ok


    # ====== 6. 针对“最后一条消息”的快捷操作 ======
    def copy_last_message_by_ratio(
        self,
        x_ratio: float = 0.12,
        y_ratio: float = 0.18,
        win: Optional[uia.Control] = None,
    ) -> bool:
        """
        对最后一条消息按比例位置进行右键并点击“复制”。
        """
        if not win:
            win = self.get_window()
        if not win:
            return False

        item = self.get_last_message_item(win)
        if not item:
            return False

        try:
            rc = item.BoundingRectangle
            left, top, right, bottom = rc.left, rc.top, rc.right, rc.bottom
        except Exception as e:
            print(f"[wx_subwindow_ops] copy_last: 获取消息项矩形失败: {e}")
            return False

        width = right - left
        height = bottom - top
        if width <= 0 or height <= 0:
            print(f"[wx_subwindow_ops] copy_last: 消息项矩形尺寸异常: w={width}, h={height}")
            return False

        x_ratio = max(0.0, min(1.0, float(x_ratio)))
        y_ratio = max(0.0, min(1.0, float(y_ratio)))

        x = int(left + width * x_ratio)
        y = int(top + height * y_ratio)

        print(
            f"[wx_subwindow_ops] copy_last: rect=({left},{top},{right},{bottom}), "
            f"ratio=({x_ratio:.2f},{y_ratio:.2f}), target=({x},{y})"
        )

        if not self._right_click_at(x, y):
            return False

        time.sleep(0.15)

        ok = self._click_copy_near_point(x, y, candidate_names=["复制", "Copy"], timeout_sec=2.0)
        print("[wx_subwindow_ops] copy_last: click copy result:", ok)
        return ok
