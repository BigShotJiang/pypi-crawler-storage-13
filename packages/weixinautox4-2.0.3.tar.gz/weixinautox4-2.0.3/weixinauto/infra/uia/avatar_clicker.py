# avatar_clicker.py
# -*- coding: utf-8 -*-
import ctypes
import time
from ctypes import wintypes
from typing import Tuple
import uiautomation as uia
from .utils_win import user32, get_hwnd_from_ctrl  # 假设 utils_win 中有 user32 的相关操作

# 固定偏移（老方案，物理点击兜底时还会用到）
FIXED_OFFX = 60
FIXED_OFFY = 45
PROBE_MARGIN_H = 6
PROBE_MARGIN_V = 6
DEBOUNCE_MS = 250

# 按消息行矩形的比例定位头像
AVATAR_X_RATIO = 0.06   # 相对消息项宽度，从左往右
AVATAR_Y_RATIO = 0.25   # 相对消息项高度，从上往下

def _get_rect(ctrl) -> Tuple[int, int, int, int, int, int]:
    """获取控件的矩形坐标和宽高"""
    rc = ctrl.BoundingRectangle
    return rc.left, rc.top, rc.right, rc.bottom, rc.width(), rc.height()

class AvatarClicker:
    """把鼠标放到消息项左侧头像位置并点击一次"""

    def click_left_avatar(self, item: uia.Control) -> bool:
        """
        使用鼠标物理点击头像位置（会移动鼠标）
        :param item: uiautomation 控件（消息项）
        :return: 是否点击成功
        """
        try:
            il, it, ir, ib, iw, ih = _get_rect(item)
            x = int(il + FIXED_OFFX)
            y = int(it + FIXED_OFFY)
            # 行内保护，避免出界
            x = max(il + PROBE_MARGIN_H, min(x, ir - PROBE_MARGIN_H))
            y = max(it + PROBE_MARGIN_V, min(y, ib - PROBE_MARGIN_V))
            user32.SetCursorPos(x, y)  # 移动鼠标到目标位置
            user32.mouse_event(2, 0, 0, 0, 0)  # LEFT DOWN
            user32.mouse_event(4, 0, 0, 0, 0)  # LEFT UP
            return True
        except Exception as e:
            print(f"使用物理鼠标点击失败: {e}")
            return False

    def simulate_click_avatar(self, win: uia.Control, item: uia.Control) -> bool:
        """
        按比例模拟点击头像（不移动鼠标，直接发鼠标消息）：
          - 成功：返回 True
          - 失败：回退到物理点击 click_left_avatar

        :param win: 聊天子窗口（mmui::ChatSingleWindow 的 Control）
        :param item: 当前消息项对应的 Control（整行）
        """
        try:
            if not win or not win.Exists(0, 0):
                return False
            if not item or not item.Exists(0, 0):
                return False

            # 1. 先拿到消息项的矩形（屏幕坐标）
            il, it, ir, ib, iw, ih = _get_rect(item)
            if iw <= 0 or ih <= 0:
                return False

            # 2. 按比例计算头像的屏幕坐标
            x = il + int(iw * AVATAR_X_RATIO)
            y = it + int(ih * AVATAR_Y_RATIO)

            # 安全边界：避免跑到外面
            x = max(il + PROBE_MARGIN_H, min(x, ir - PROBE_MARGIN_H))
            y = max(it + PROBE_MARGIN_V, min(y, ib - PROBE_MARGIN_V))

            # 3. 从主窗口拿 hwnd
            hwnd = get_hwnd_from_ctrl(win)
            if not hwnd:
                # 拿不到 hwnd 就直接用物理点击兜底
                return self.click_left_avatar(item)

            # 4. 屏幕坐标 -> 客户区坐标
            point = wintypes.POINT(int(x), int(y))
            ctypes.windll.user32.ScreenToClient(hwnd, ctypes.byref(point))
            lparam = (point.y << 16) | (point.x & 0xFFFF)

            # 5. 发送鼠标点击消息（不改变真实鼠标位置）
            WM_LBUTTONDOWN = 0x0201
            WM_LBUTTONUP   = 0x0202

            r1 = ctypes.windll.user32.PostMessageW(hwnd, WM_LBUTTONDOWN, 1, lparam)
            time.sleep(0.02)
            r2 = ctypes.windll.user32.PostMessageW(hwnd, WM_LBUTTONUP, 0, lparam)

            if r1 and r2:
                return True

            # PostMessage 不成功，回退物理点击
            return self.click_left_avatar(item)

        except Exception as e:
            print(f"模拟点击头像异常: {e}")
            return self.click_left_avatar(item)
