# nickname_reader.py
# -*- coding: utf-8 -*-
import traceback
from typing import Optional

import uiautomation as uia
import win32gui, win32process

WEIXIN_POP_CLASS_MAIN = "mmui::ProfileUniquePop"
WEIXIN_POP_CLASS_ALT_PREFIX = "Qt"  # e.g. Qt515xxQWindowToolSaveBits
PROFILE_CLASS = "mmui::ContactProfileView"
NICK_CLASS    = "mmui::XTextView"
NICK_AID      = "right_v_view.nickname_button_view.display_name_text"

FAST_SPECS: list[tuple[str,str]] = [
    ("mmui::XView",                 "fixed_height_v_view"),
    ("mmui::ProfileResizeVBoxView", "fixed_height_v_view.content_v_view"),
    ("mmui::ContactProfileTopUi",   ""),
    ("mmui::XView",                 "right_v_view"),
    ("mmui::XView",                 "right_v_view.nickname_button_view"),
    (NICK_CLASS,                    NICK_AID),
]

def _enum_top_windows_by_pid(pid:int)->list[int]:
    res=[]
    def cb(h,_):
        if win32gui.IsWindowVisible(h):
            try:
                _,p=win32process.GetWindowThreadProcessId(h)
                if p==pid: res.append(h)
            except Exception: pass
        return True
    win32gui.EnumWindows(cb, None)
    return res

def _find_profile_popup(self) -> Optional[uia.Control]:
    root = uia.GetRootControl()
    for w in self._children(root):          # 顶层快扫
        if self._looks_profile_popup(w):
            return w
    q, steps = [root], 0                     # 小 BFS 兜底
    while q and steps < 300:
        n = q.pop(0); steps += 1
        if self._looks_profile_popup(n):
            return n
        q.extend(self._children(n))
    return None

def _looks_profile_popup_hwnd(hwnd:int)->bool:
    try: cls = win32gui.GetClassName(hwnd) or ""
    except Exception: cls=""
    if not (cls==WEIXIN_POP_CLASS_MAIN or cls.startswith(WEIXIN_POP_CLASS_ALT_PREFIX)):
        return False
    try:
        root = uia.ControlFromHandle(hwnd)
        q=[root]; depth=0
        while q and depth<=2:
            nxt=[]
            for n in q:
                try:
                    cname=(getattr(n,"ClassName","") or "")
                    aid=(getattr(n,"AutomationId","") or "")
                    if cname==PROFILE_CLASS: return True
                    if aid==NICK_AID: return True
                    for ch in (n.GetChildren() or [])[:12]: nxt.append(ch)
                except Exception: pass
            q=nxt; depth+=1
    except Exception: pass
    return False

def popup_hwnd_quick_by_pid(pid:int)->int:
    for h in _enum_top_windows_by_pid(pid):
        if _looks_profile_popup_hwnd(h): return h
    return 0

def _children(ctrl):
    try: return ctrl.GetChildren() or []
    except Exception: return []

def _find_contact_profile_view(pop_root: uia.Control)->uia.Control|None:
    q,steps=[pop_root],0
    while q and steps<600:
        n=q.pop(0); steps+=1
        if getattr(n,"ClassName","")==PROFILE_CLASS: return n
        q.extend(_children(n))
    return None

def _resolve_nick_fast(profile_root: uia.Control)->str|None:
    node=profile_root
    for want_cls,want_aid in FAST_SPECS:
        hit=None
        for ch in _children(node):
            if getattr(ch,"ClassName","")!=want_cls: continue
            if want_aid and (getattr(ch,"AutomationId","") or "")!=want_aid: continue
            hit=ch; break
        if not hit: return None
        node=hit
    nm=(getattr(node,"Name","") or "").strip()
    return nm or None

def _resolve_nick_by_search(profile_root: uia.Control)->str|None:
    q,steps=[profile_root],0
    while q and steps<2000:
        n=q.pop(0); steps+=1
        if getattr(n,"ClassName","")==NICK_CLASS and (getattr(n,"AutomationId","") or "")==NICK_AID:
            nm=(getattr(n,"Name","") or "").strip()
            return nm or None
        q.extend(_children(n))
    q,steps=[profile_root],0
    while q and steps<2000:
        n=q.pop(0); steps+=1
        if getattr(n,"ClassName","")==NICK_CLASS:
            aid=(getattr(n,"AutomationId","") or "")
            if "nickname_button_view" in aid:
                nm=(getattr(n,"Name","") or "").strip()
                if nm: return nm
        q.extend(_children(n))
    return None

def read_nickname_from_popup_hwnd(popup_hwnd:int)->str|None:
    try:
        pop = uia.ControlFromHandle(popup_hwnd)
        if not pop: return None
        profile = _find_contact_profile_view(pop)
        if not profile: return None
        nick = _resolve_nick_fast(profile)
        return nick or _resolve_nick_by_search(profile)
    except Exception:
        return None
def get_nickname(self) -> Optional[str]:
    try:
        with uia.UIAutomationInitializerInThread():
            return self.get_nickname_noctx()
    except Exception:
        traceback.print_exc()
        return None

    # ========== 外部 API（不包上下文，供已有UIA上下文里调用） ==========
def get_nickname_noctx(self) -> Optional[str]:
    try:
        pop = self._find_profile_popup()
        if not pop:
            return None
        profile = self._find_contact_profile_view(pop)
        if not profile:
            return None
        nick = self._resolve_nick_fast(profile)
        if nick:
            return nick
        return self._resolve_nick_by_search(profile)
    except Exception:
        traceback.print_exc()
        return None