# weixin_newmessage.py
# -*- coding: utf-8 -*-
from __future__ import annotations

import hashlib
import threading
import time
import re
from typing import List, Optional, Callable, Tuple
import ctypes
from ctypes import wintypes as _w

import uiautomation as uia

from .sender_click_resolver import SenderClickResolver
from .wechat_driver import WeChatDriver
from .message import ChatMessage
from .message_extract import MessageType, extract_text_deep, classify_by_classname
from .utils_win import bring_to_front, get_hwnd_from_ctrl




def _bfs_children(root: uia.Control, max_nodes: int = 8000):
    """简单 BFS 工具函数，防止在 UI 树里死循环。"""
    q: List[uia.Control] = [root]
    seen = 0
    while q and seen < max_nodes:
        n = q.pop(0)
        seen += 1
        yield n
        try:
            ch = n.GetChildren()
            if ch:
                q.extend(ch)
        except Exception:
            pass
    # ====== 工具：从会话 Name 中解析「群名 + 未读数量」======
def _hash_text_for_echo(s: str) -> str:
    """给文本做一个简单哈希，用于抑制我们自己发送的消息被当作新消息。"""
    return hashlib.md5((s or "").rstrip().encode("utf-8", "ignore")).hexdigest()

class WeixinNewMessage:
    """
    主窗口新消息扫描器（单次流程版，按「X条未读」真实取多条消息）：
      - 通过 WeChatDriver 获取主窗口；
      - 点击左侧「微信」Tab；
      - 遍历左侧会话列表（支持滚动），找到 Name 包含「X条未读」的会话；
      - 进入会话后，从右侧消息列表自底向上取多条消息：
          * 按「X条未读」做最大计数；
          * 系统消息/时间消息不计数、不返回；
      - 返回所有会话的未读消息（按时间顺序）组成的 List[ChatMessage]。
    """

    def __init__(
        self,
        driver: WeChatDriver,
        *,
        click_delay: float = 0.5,     # 单个会话点击后等待时间
        keep_foreground: bool = True, # 扫描时是否尝试置前主窗口
        need_nickname: bool = False
    ):
        self._driver = driver
        self._click_delay = max(0.1, float(click_delay))
        self._keep_foreground = bool(keep_foreground)

        self._lock = threading.Lock()
        self._ui_lock = threading.Lock()  # 用于确保UI操作的线程安全
        self._last_results: List[ChatMessage] = []


        # 缓存：主窗口、「微信」Tab、会话列表
        self._main_win: Optional[uia.Control] = None
        self._msg_tab_cached: Optional[uia.Control] = None
        self._session_list_cached: Optional[uia.Control] = None

        # 监听线程相关
        self._watch_thread: Optional[threading.Thread] = None
        self._watch_running: bool = False
        self._watch_interval: float = 1.0
        self._watch_max_rounds: int = 10
        self.need_nickname = need_nickname
        self._watch_callback: Optional[Callable[[List[ChatMessage]], None]] = None
        self._sender_click_resolver = SenderClickResolver()

        self._last_msg_hash = {}  # type: dict[str, list[str]]

        try:
            self._ensure_main_window_ready(timeout_sec=3.0)
        except Exception as e:
            print(f"[WeixinNewMessage] 初始化确保主窗口失败: {e!r}")

    # ====== 会话过滤规则 ======
    def _get_nickname_from_avatar(self, win: uia.Control, item: uia.Control) ->Tuple[Optional[bool], Optional[str]]:
        """
        通过点击头像获取昵称
        """
        try:
            # 调用 SenderClickResolver 来获取昵称
            is_self, nickname = self._sender_click_resolver.resolve_by_click(win, item)
            if is_self:
                print(f"消息是自己发的，昵称未获取: {nickname}")
            else:
                print(f"消息是别人发的，昵称是: {nickname}")
            return (False, nickname) if nickname else (True, None)
        except Exception as e:
            print(f"[WeixinNewMessage] 获取昵称失败: {e!r}")
            return None

    def _is_mute_session(self, raw_name: str) -> bool:
        """
        是否『消息免打扰』会话：
        - Name 里只要包含“消息免打扰”就视为免打扰，直接跳过。
        """
        return "消息免打扰" in (raw_name or "")

    def _make_message_hash(
        self,
        group_title: str,
        node: uia.Control,
        text: str,
        mtype: MessageType,
    ) -> str:
        """
        为一条消息生成稳定的签名：
          - 群名
          - 文本内容
          - 消息类型
          - 控件的 ClassName / RuntimeId / 子节点数量
        """
        parts = [
            group_title or "",
            text or "",
            str(getattr(mtype, "name", mtype)),
        ]

        try:
            cls = (getattr(node, "ClassName", "") or "").strip()
            parts.append(f"cls={cls}")
        except Exception:
            pass

        # RuntimeId 在 uiautomation 里一般有，做个加强区分
        try:
            rid = getattr(node, "RuntimeId", None)
            if rid:
                parts.append("rid=" + ",".join(str(x) for x in rid))
        except Exception:
            pass

        try:
            ch = node.GetChildren() or []
            parts.append(f"ch={len(ch)}")
        except Exception:
            pass

        raw = "||".join(parts)
        return hashlib.md5(raw.encode("utf-8", errors="ignore")).hexdigest()



    def reply(self, msg: ChatMessage, text: str) -> bool:
        """
        根据一条 ChatMessage 进行回复：
        - msg.group 作为目标会话名
        - text 为要发送的内容
        - 使用同一把 _ui_lock，保证和 scan_once 不会并发操作 UI
        """
        text = (text or "").strip()
        if not text:
            return False

        if not hasattr(self, "_driver") or self._driver is None:
            print("[WeixinNewMessage] reply 时 driver 不存在")
            return False

        with self._ui_lock:
            try:
                ok = self._driver.send_text_to_chat(
                    chat_name=msg.group,
                    text=text,
                    strict=False,
                    wait_child_sec=1.5,
                    wait_btn_sec=1.0,
                )
                if not ok:
                    print(f"[WeixinNewMessage] 回复失败：group={msg.group!r}, text={text!r}")
                return ok
            except Exception as e:
                print(f"[WeixinNewMessage] 回复消息异常: {e!r}")
                return False


    def _is_official_or_public_session(self, title: str, raw_name: str, auto_id: str) -> bool:
        """
        是否『公众号 / 系统类 / 腾讯信息』：
        - 这类会话只点击清未读，不读取消息。
        """
        text = f"{title} {raw_name} {auto_id}"
        keywords = [
            "腾讯新闻",
            "微信支付",
            "微信团队",
            "QQ邮箱提醒",
            "服务通知",
            "订阅号",
            "公众号",
            "视频号助手",
            "微信读书",
        ]
        for kw in keywords:
            if kw and kw in text:
                return True
        return False

    def _parse_unread_from_name(self, raw_name: str) -> (str, int):
        """
        从会话项 Name 中解析：
          - 返回 (标题, 未读条数)
          - 必须包含“X条未读”才会返回 cnt > 0
        示例：
          '星尘&机器人管理群 已置顶 3条未读 星尘- Dollar: xxx 17:57'
          'k2.xxx 1条未读 群主xxx: 内容 消息免打扰'
        """
        if not raw_name:
            return "", 0
        # 必须含有“条未读”
        if "条未读" not in raw_name:
            return "", 0
        m = re.search(r"(.+?)\s+(\d+)\s*条未读", raw_name)
        if not m:
            return "", 0
        title = m.group(1).strip()
        try:
            cnt = int(m.group(2))
        except Exception:
            cnt = 0
        # 去掉尾部的“已置顶”
        title = re.sub(r"\s*已置顶$", "", title).strip()

        return title, cnt

    # ====== 主窗口相关（完全依赖 driver）======

    def _get_hwnd_from_driver(self) -> int:
        hwnd = 0
        # 1) 优先使用 driver._hwnd 缓存
        try:
            hwnd = int(getattr(self._driver, "_hwnd", 0) or 0)
        except Exception:
            hwnd = 0
        if hwnd:
            return hwnd
        # 2) 其次尝试 _find_wechat_hwnd_fast
        if hasattr(self._driver, "_find_wechat_hwnd_fast"):
            fn = getattr(self._driver, "_find_wechat_hwnd_fast")
            try:
                hwnd = int(fn() or 0)
            except Exception:
                hwnd = 0
        # 4) 成功的话回写到 driver._hwnd，后面就不用再找了
        try:
            if hwnd:
                setattr(self._driver, "_hwnd", hwnd)
        except Exception:
            pass
        return hwnd

    def _get_main_window_once(self) -> Optional[uia.Control]:
        if self._main_win:
            try:
                if self._main_win.Exists(0, 0):
                    return self._main_win
            except Exception:
                self._main_win = None

        # 2) 通过 driver 拿 hwnd
        hwnd = self._get_hwnd_from_driver()
        if not hwnd:
            return None
        # 3) hwnd -> 控件
        try:
            ctrl = uia.ControlFromHandle(hwnd)
        except Exception:
            return None
        try:
            if ctrl and ctrl.Exists(0, 0):
                self._main_win = ctrl
                return ctrl
        except Exception:
            return None
        return None

    def _ensure_main_window_ready(self, timeout_sec: float = 3.0) -> Optional[uia.Control]:
        win = self._get_main_window_once()
        if win:
            return win

        return None

    def _ensure_main_foreground(self, main_win: uia.Control) -> None:
        hwnd = 0
        # 1) 优先用 driver 缓存的 hwnd
        try:
            hwnd = self._get_hwnd_from_driver()
        except Exception:
            hwnd = 0
        # 2) 兜底：由控件反推 hwnd
        if not hwnd:
            try:
                hwnd = get_hwnd_from_ctrl(main_win)
            except Exception:
                hwnd = 0
        if not hwnd:
            return
        try:
            bring_to_front(hwnd, gentle=True)
            time.sleep(0.05)
        except Exception as e:
            print(f"[WeixinNewMessage] bring_to_front 失败: {e!r}")

    # ====== 「微信」Tab 查找与点击 ======

    def _locate_message_tab(self, main_win: uia.Control) -> Optional[uia.Control]:
        # 1) 先用缓存
        if self._msg_tab_cached:
            try:
                if self._msg_tab_cached.Exists(0, 0):
                    return self._msg_tab_cached
            except Exception:
                self._msg_tab_cached = None

        target = None

        # 2) 先在 main_win 子树里找一圈（可以把 max_nodes 稍微放大一点）
        try:
            for n in _bfs_children(main_win, max_nodes=400):
                try:
                    ctn = (getattr(n, "ControlTypeName", "") or "").strip()
                    cls = (getattr(n, "ClassName", "") or "").strip()
                    nm = (getattr(n, "Name", "") or "").strip()
                except Exception:
                    continue

                if ctn not in ("ButtonControl", "TabItemControl"):
                    continue
                if cls != "mmui::XTabBarItem":
                    continue
                if nm != "微信":
                    continue

                target = n
                break

            # 兜底：Name 包含“微信”的 XTabBarItem
            if not target:
                for n in _bfs_children(main_win, max_nodes=2000):
                    try:
                        ctn = (getattr(n, "ControlTypeName", "") or "").strip()
                        cls = (getattr(n, "ClassName", "") or "").strip()
                        nm = (getattr(n, "Name", "") or "").strip()
                    except Exception:
                        continue

                    if ctn not in ("ButtonControl", "TabItemControl"):
                        continue
                    if cls != "mmui::XTabBarItem":
                        continue
                    if "微信" in nm:
                        target = n
                        break
        except Exception:
            target = None

        # 3) 如果在 main_win 子树里还是没找到，尝试从 root + 进程过滤
        if not target:
            try:
                root = uia.GetRootControl()
                try:
                    pid = getattr(main_win, "ProcessId", None)
                except Exception:
                    pid = None

                for n in _bfs_children(root, max_nodes=8000):
                    try:
                        cls = (getattr(n, "ClassName", "") or "").strip()
                        nm = (getattr(n, "Name", "") or "").strip()
                        ctn = (getattr(n, "ControlTypeName", "") or "").strip()
                        npid = getattr(n, "ProcessId", None)
                    except Exception:
                        continue

                    if pid is not None and npid != pid:
                        continue
                    if ctn not in ("ButtonControl", "TabItemControl"):
                        continue
                    if cls != "mmui::XTabBarItem":
                        continue
                    if nm != "微信" and "微信" not in nm:
                        continue

                    target = n
                    break
            except Exception:
                target = None

        if target:
            self._msg_tab_cached = target
            # 调试：你可以临时打开看看
            # print("[WeixinNewMessage] 找到微信 Tab:",
            #       getattr(target, "ControlTypeName", ""),
            #       getattr(target, "ClassName", ""),
            #       getattr(target, "Name", ""),
            #       "pid=", getattr(target, "ProcessId", None))
        else:
            print("[WeixinNewMessage] _locate_message_tab: 未找到 XTabBarItem『微信』")

        return target

    def _click_control(self, ctrl: uia.Control, *, double: bool = False) -> bool:
        """
        在控件中心做一次“逻辑点击”：
          - double=False：单击
          - double=True：双击（先单击，再发送 DBLCLK）

        只用 PostMessage，不调用 ctrl.Click() / InvokePattern，也不移动真实鼠标。
        """
        if not ctrl:
            return False

        try:
            rc = ctrl.BoundingRectangle
            cx = int((rc.left + rc.right) / 2)
            cy = int((rc.top + rc.bottom) / 2)
        except Exception:
            return False

        try:
            user32 = ctypes.windll.user32

            WM_LBUTTONDOWN = 0x0201
            WM_LBUTTONUP = 0x0202
            WM_LBUTTONDBLCLK = 0x0203
            MK_LBUTTON = 0x0001

            class POINT(ctypes.Structure):
                _fields_ = [("x", _w.LONG), ("y", _w.LONG)]

            def _make_lparam(xc: int, yc: int) -> int:
                return (yc << 16) | (xc & 0xFFFF)

            # 基于控件中心点找到窗口句柄
            pt = POINT(cx, cy)
            hwnd = user32.WindowFromPoint(pt)
            if not hwnd:
                return False

            # 转成客户区坐标
            user32.ScreenToClient(hwnd, ctypes.byref(pt))
            x_client, y_client = pt.x, pt.y
            lp = _make_lparam(x_client, y_client)

            # 第一次：DOWN + UP（单击）
            user32.PostMessageW(hwnd, WM_LBUTTONDOWN, MK_LBUTTON, lp)
            user32.PostMessageW(hwnd, WM_LBUTTONUP, 0, lp)

            if double:
                # 稍微等一下再发双击，防止太快被系统忽略
                import time as _time
                _time.sleep(0.02)

                # 第二次：DBLCLK + UP（双击）
                user32.PostMessageW(hwnd, WM_LBUTTONDBLCLK, MK_LBUTTON, lp)
                user32.PostMessageW(hwnd, WM_LBUTTONUP, 0, lp)

            return True
        except Exception:
            return False


    def _click_message_tab(self, main_win: uia.Control) -> None:
        btn = self._locate_message_tab(main_win)
        if not btn:
            # 兜底：找名字带“消息/Chats”的
            try:
                for n in _bfs_children(main_win, max_nodes=400):
                    ctn = (getattr(n, "ControlTypeName", "") or "").strip()
                    if ctn not in ("ButtonControl", "TabItemControl"):
                        continue
                    nm = (getattr(n, "Name", "") or "").strip()
                    if not nm:
                        continue
                    if "消息" in nm or "Chats" in nm:
                        self._click_control(n, double=True)
                        time.sleep(0.2)
                        return
            except Exception:
                pass
            return

        # 不再依赖 FullDescription，统一直接双击刷新一下
        ok = self._click_control(btn, double=True)
        if not ok:
            print("[WeixinNewMessage] _click_message_tab: _click_control 失败")
        time.sleep(0.2)



    # ====== 会话列表 & 消息列表 ======

    def _get_session_list(self, main_win: uia.Control) -> Optional[uia.Control]:
        if self._session_list_cached:
            try:
                if self._session_list_cached.Exists(0, 0):
                    return self._session_list_cached
            except Exception:
                self._session_list_cached = None

        lists: List[uia.Control] = []
        try:
            for n in _bfs_children(main_win, max_nodes=1200):
                ctn = (getattr(n, "ControlTypeName", "") or "").strip()
                if ctn != "ListControl":
                    continue
                lists.append(n)
        except Exception:
            pass

        if not lists:
            return None

        for lst in lists:
            try:
                auto_id = (getattr(lst, "AutomationId", "") or "").strip()
            except Exception:
                auto_id = ""
            if "session_list" in auto_id:
                self._session_list_cached = lst
                return lst

        for lst in lists:
            try:
                nm = (getattr(lst, "Name", "") or "").strip()
            except Exception:
                nm = ""
            if any(k in nm for k in ("会话", "聊天", "消息")):
                self._session_list_cached = lst
                return lst

        self._session_list_cached = lists[0]
        return lists[0]

    def _get_message_list(self, main_win: uia.Control) -> Optional[uia.Control]:
        lists: List[uia.Control] = []
        try:
            for n in _bfs_children(main_win, max_nodes=500):
                cls = (getattr(n, "ClassName", "") or "").strip()
                # 只查找类名为 "mmui::RecyclerListView" 的控件
                if cls == "mmui::RecyclerListView":
                    lists.append(n)
        except Exception:
            pass

        if not lists:
            return None

        for lst in lists:
            try:
                auto_id = (getattr(lst, "AutomationId", "") or "").strip()
            except Exception:
                auto_id = ""
            if "chat_message_list" in auto_id:
                return lst

        for lst in lists:
            try:
                cls = (getattr(lst, "ClassName", "") or "").strip()
                nm = (getattr(lst, "Name", "") or "").strip()
            except Exception:
                cls = nm = ""
            if "Chat" in cls or "消息" in nm:
                return lst

        best = None
        best_count = -1
        for lst in lists:
            try:
                ch = lst.GetChildren() or []
                cnt = len(ch)
            except Exception:
                cnt = -1
            if cnt > best_count:
                best = lst
                best_count = cnt
        return best
    # ====== 工具：遍历会话列表（带滚动）======

    def _iter_session_items_with_scroll(
        self,
        sess_list: uia.Control,
        *,
        max_rounds: int = 20,
    ):
        """
        迭代会话列表里的条目，尽量覆盖全部：
          - 每一轮读取当前可见的子项；
          - 用 Name/AutomationId 做去重；
          - 如果有 ScrollPattern，就向下滚动一点再下一轮；
          - 最多滚动 max_rounds 轮，防止死循环。
        """
        visited_keys = set()

        # 尝试拿滚动模式（有些情况下可能拿不到）
        try:
            sp = sess_list.GetScrollPattern()
        except Exception:
            sp = None

        for _ in range(max_rounds):
            try:
                items = sess_list.GetChildren() or []
            except Exception:
                items = []

            if not items:
                break

            any_new = False
            for it in items:
                try:
                    auto_id = (getattr(it, "AutomationId", "") or "").strip()
                    nm = (getattr(it, "Name", "") or "").strip()
                except Exception:
                    auto_id = ""
                    nm = ""

                key = auto_id or nm
                if not key:
                    continue
                if key in visited_keys:
                    continue

                visited_keys.add(key)
                any_new = True
                yield it

            # 如果这一轮没有新增条目，说明已经到顶或到底了
            if not any_new:
                break

            # 没有滚动能力就直接退出
            if not sp:
                break

            # 尝试向下滚动一格
            try:
                # uiautomation 里 Scroll(vertAmount, horizAmount)
                # 通常用 ScrollAmount_LargeIncrement 作为一屏
                sp.Scroll(uia.ScrollAmount_LargeIncrement, uia.ScrollAmount_NoAmount)
            except Exception:
                break

            time.sleep(0.15)

    # ====== 核心：对单个会话，根据“X条未读”收集多条消息 ======
    def _extract_last_k_messages(
            self,
            main_win: uia.Control,
            group_title: str,
            unread_count: int,
    ) -> List[ChatMessage]:
        """
        简化版提取逻辑：

        - 不依赖历史 hash；
        - 不做自回声过滤；
        - 先根据未读条数 unread_count 从底部往上取 N 条“有效消息”；
        - 再从“最新一条未读消息”开始，沿 NextSibling 向下补充，直到没有或达上限；
        - 使用 RuntimeId 做本轮去重，避免重复。
        """
        lst = self._get_message_list(main_win)
        if not lst:
            return []

        try:
            children = lst.GetChildren() or []
        except Exception:
            children = []

        if not children:
            return []

        # 至少取 1 条，防御一下
        base = unread_count if unread_count > 0 else 1

        # 本轮去重用的 key 集合
        def _node_key(n: uia.Control) -> str:
            try:
                rid = getattr(n, "RuntimeId", None)
                if rid:
                    return "rid:" + ",".join(str(int(x)) for x in rid)
            except Exception:
                pass
            # 兜底用 id()
            return f"id:{id(n)}"

        visited: set[str] = set()
        res_nodes: list[tuple[uia.Control, str, MessageType]] = []

        i = len(children) - 1
        effective = 0
        first_node: Optional[uia.Control] = None  # 最新的一条未读消息（最底部那条）

        # ===== 1) 从底部往上取 base 条“有效消息” =====
        while i >= 0 and effective < base:
            node = children[i]
            i -= 1

            # 1. 判定消息类型
            try:
                mtype = classify_by_classname(node)
            except Exception:
                mtype = MessageType.TEXT

            # 2. 过滤系统/时间类消息
            try:
                if mtype in (MessageType.SYSTEM, MessageType.TIME):
                    continue
            except Exception:
                pass

            # 3. 提取文本
            try:
                text = (extract_text_deep(node) or "").strip()
            except Exception:
                text = ""

            if not text:
                continue

            # 4. 文本里的系统提示过滤
            if any(k in text for k in ("以上为新消息", "以下为新消息", "以下是新消息")):
                continue

            key = _node_key(node)
            if key in visited:
                # 同一控件别重复记
                continue
            visited.add(key)

            res_nodes.append((node, text, mtype))
            effective += 1

            # 记录“最新的一条未读消息”（第一条命中的就是最底部那条）
            if first_node is None:
                first_node = node

        # 如果一个都没取到，直接返回空
        if not res_nodes:
            return []

        # ===== 2) 从“最新一条未读”开始，沿 NextSibling 向下补充 =====
        tail_nodes: list[tuple[uia.Control, str, MessageType]] = []
        if first_node is not None:
            try:
                nxt = first_node.GetNextSiblingControl()
            except Exception:
                nxt = None

            tail_scanned = 0
            MAX_TAIL = 20  # 防御，最多补 20 条

            while nxt and tail_scanned < MAX_TAIL:
                tail_scanned += 1

                try:
                    mtype2 = classify_by_classname(nxt)
                except Exception:
                    mtype2 = MessageType.TEXT

                try:
                    if mtype2 in (MessageType.SYSTEM, MessageType.TIME):
                        nxt = nxt.GetNextSiblingControl()
                        continue
                except Exception:
                    pass

                try:
                    text2 = (extract_text_deep(nxt) or "").strip()
                except Exception:
                    text2 = ""

                if not text2:
                    nxt = nxt.GetNextSiblingControl()
                    continue

                if any(k in text2 for k in ("以上为新消息", "以下为新消息", "以下是新消息")):
                    nxt = nxt.GetNextSiblingControl()
                    continue

                key2 = _node_key(nxt)
                if key2 in visited:
                    # 本轮已经收集过（包含在底部那 N 条里）就跳过
                    try:
                        nxt = nxt.GetNextSiblingControl()
                    except Exception:
                        nxt = None
                    continue

                visited.add(key2)
                tail_nodes.append((nxt, text2, mtype2))

                try:
                    nxt = nxt.GetNextSiblingControl()
                except Exception:
                    nxt = None

        # ===== 3) 合并结果并按时间顺序封装 ChatMessage =====
        # res_nodes 当前是从“新 -> 旧”，翻转成“旧 -> 新”
        res_nodes.reverse()
        all_nodes = res_nodes + tail_nodes

        msgs: List[ChatMessage] = []
        now_ts = time.time()
        for node, text, mtype in all_nodes:
            msgs.append(
                ChatMessage(
                    group=group_title,
                    text=text,
                    ts=now_ts,
                    mtype=mtype,
                    raw_text=text,
                    is_self=None,
                    sender=None,
                    internal_tag="main_window_unread",
                )
            )

        return msgs

    def is_right_side_obstructed(self,main_win: uia.Control) -> bool:
        """
        判断右侧是否被遮挡：
        - 通过 ClassName 寻找根节点（"mmui::XSplitterView"）
        - 如果找到根节点后，在根节点下扫描，判断是否有 mmui::XImage 控件。
        :param main_win: 主窗口控件
        :return: 如果右侧被遮挡，则返回 True；否则返回 False
        """
        try:
            # 1. 找到根节点 "mmui::XSplitterView"

            for ctrl in _bfs_children(main_win, max_nodes=500):
                class_name = getattr(ctrl, "ClassName", "").strip() if isinstance(getattr(ctrl, "ClassName", ""),
                                                                                  str) else ""
                # 找到匹配的根节点，停止进一步扫描其他控件
                if class_name == "mmui::RecyclerListView":
                    return True
        except Exception as e:
            print(f"[debug] 判断右侧是否被遮挡失败: {e}")
        # 如果没有找到匹配的控件，则认为右侧没有遮挡
        return False

    # ====== 核心：单次扫描“有未读”的会话，并按数量取多条消息 ======

    def scan_once(self) -> List[ChatMessage]:
        """
        同步扫描一次当前主窗口的“有未读消息”的会话（只处理顶部那个）：

        流程：
          1. 通过 driver 确保微信主窗口已打开；
          2. 可选：把主窗口置前；
          3. 看「微信」Tab 的 FullDescription：
               - 若显示 “x条新消息”：
                   a) 点击一次『微信』Tab（刷新）；
                   b) 再点击一次（让微信把会话列表中有未读的顶到前面）；
               - 若没有 “x条新消息”，只点击一次当刷新，然后直接返回 []；
          4. 找到会话列表 session_list，读取子项；
          5. 找到第一个 Name 中含 “N条未读” 的会话项：
               - 解析出群名 group_title 与未读数量 unread_count；
               - 点击该会话项；
          6. 从右侧消息列表中按 unread_count 往回取同等数量的消息（过滤掉时间/系统消息）；
          7. 返回本次采集到的 ChatMessage 列表（可能为 0~N 条）。
        """
        with self._ui_lock:
            main_win = self._ensure_main_window_ready(timeout_sec=2.0)
            if not main_win:
                print("[WeixinNewMessage] 未找到微信主窗口")
                return []

            if self._keep_foreground:
                self._ensure_main_foreground(main_win)

            # 1) 通过 _click_message_tab 统一处理点击，并拿到“新消息总数”
            self._click_message_tab(main_win)


            # 2) 会话列表：session_list
            sess_list = self._get_session_list(main_win)
            if not sess_list:
                print("[WeixinNewMessage] 未找到会话列表控件")
                return []

            try:
                items = sess_list.GetChildren() or []
            except Exception:
                items = []

            if not items:
                return []

            target_item: Optional[uia.Control] = None
            group_title: str = ""
            unread_count: int = 0

            if self.is_right_side_obstructed(main_win):
                first_item=items[0]
                self._click_control(first_item)
                time.sleep(0.3)

            # 3) 找“第一个有 N 条未读”的会话项（只处理一个，处理完就返回）
            for it in items:
                try:
                    raw_name = (getattr(it, "Name", "") or "").strip()
                except Exception:
                    raw_name = ""

                if not raw_name:
                    continue
                # 解析出标题和未读数量（内部必须包含“条未读”，否则 cnt=0）
                title, cnt = self._parse_unread_from_name(raw_name)

                # 如果没有“x条未读”，直接跳过
                if cnt <= 0:
                    continue
                print("[WeixinNewMessage] 会话项 Name:", repr(raw_name))
                # 拿 AutomationId，方便后面区分公众号 / 系统号
                try:
                    auto_id = (getattr(it, "AutomationId", "") or "").strip()
                except Exception:
                    auto_id = ""

                # 2) 消息免打扰：完全跳过（不点、不读）
                if self._is_mute_session(raw_name):
                    self._click_control(it, double=False)
                    print("[WeixinNewMessage] 跳过免打扰会话:", repr(raw_name))
                    continue

                # 3) 公众号 / 系统 / 腾讯新闻：只点击清未读，不读取
                if self._is_official_or_public_session(title, raw_name, auto_id):
                    print("[WeixinNewMessage] 官方/公众号会话：只点击不读取 ->", repr(title))
                    ok_click = self._click_control(it, double=False)
                    if not ok_click:
                        print("[WeixinNewMessage] 点击官方会话失败:", repr(raw_name))
                    # 不作为本轮 target，继续找下一个有未读的会话
                    time.sleep(self._click_delay)
                    continue

                group_title = title or raw_name
                unread_count = cnt
                target_item = it
                break  # ✅ 找到第一个有未读的就停下

            if not target_item or unread_count <= 0:
                # 虽然「微信」Tab 有“x条新消息”，但这一屏没解析到“x条未读”
                with self._lock:
                    self._last_results = []
                return []

            # 4) 点击这个会话项，让右侧加载详情
            ok =self._click_control(target_item, double=False)
            if not ok:
                print(f"[WeixinNewMessage] 点击会话项失败: _click_control 返回 False, name={group_title!r}")
                with self._lock:
                    self._last_results = []
                return []

            time.sleep(self._click_delay)

            # 5) 从右侧消息列表里按 unread_count 抓消息
            msgs = self._extract_last_k_messages(main_win, group_title, unread_count)

            with self._lock:
                self._last_results = list(msgs)

            # ✅ 处理完这个会话的一批未读后，点击隐藏会话
            # 这样下一轮再次双击「微信」，整个会话列表会被微信重新刷新，
            # 有些不会再显示「X条未读」的场景也能重新计算。
            self._click_control(target_item, double=False)
        return msgs

    # ====== 单次异步扫描（线程跑一次就结束）======

    def scan_once_async(self, callback: Optional[Callable[[List[ChatMessage]], None]] = None) -> None:
        """
        在一个后台线程中执行 scan_once（跑一次就结束）。
        """

        def _worker():
            res = self.scan_once()
            if callback:
                try:
                    callback(res)
                except Exception as e:
                    print(f"[WeixinNewMessage] callback 执行异常: {e!r}")

        t = threading.Thread(target=_worker, daemon=True)
        t.start()

    # ====== 内部监听线程（for 循环测试版）======

    def _watch_loop(self):
        """
        内部监听线程：
          - 使用 for 循环跑固定轮数（self._watch_max_rounds）；
          - 每轮调用 scan_once()（带锁），拿到 msgs 后再回调 callback；
          - 中间按 self._watch_interval 休眠。
        """
        rounds = 0
        max_rounds = max(1, int(self._watch_max_rounds))
        interval = max(0.2, float(self._watch_interval))
        print(max_rounds)
        while self._watch_running and rounds < max_rounds:
            rounds += 1
            try:
                print(f"第{rounds}轮")
                msgs = self.scan_once()
                if msgs and self._watch_callback:
                    try:
                        # 注意：callback 在 scan_once 之外执行，避免长时间占用锁
                        self._watch_callback(msgs)
                    except Exception as e:
                        print(f"[WeixinNewMessage] watch callback 出错: {e!r}")
            except Exception as e:
                print(f"[WeixinNewMessage] watch_loop 内部异常: {e!r}")
            finally:
                time.sleep(interval)

        self._watch_running = False
        print(f"[WeixinNewMessage] 监听结束，共执行 {rounds} 轮")

    def start_watch(
            self,
            callback: Callable[[List[ChatMessage]], None],
            *,
            interval_sec: float = 1.0,
            max_rounds: int = 10,  # ✅ 先用 for 循环测试版
    ) -> None:
        """
        启动持续监听（固定轮数版）：
          - interval_sec：轮询间隔（秒）；
          - max_rounds：本次最多扫描多少轮。
        """
        self.stop_watch()

        self._watch_callback = callback
        self._watch_interval = interval_sec
        self._watch_max_rounds = max_rounds
        self._watch_running = True

        t = threading.Thread(target=self._watch_loop, daemon=True)
        self._watch_thread = t
        t.start()
        print(f"[WeixinNewMessage] 开始监听新消息，间隔 {interval_sec}s，最多 {max_rounds} 轮")

    def stop_watch(self) -> None:
        """
        停止监听线程。
        """
        self._watch_running = False
        t = self._watch_thread
        self._watch_thread = None
        if t and t.is_alive():
            try:
                t.join(timeout=0.2)
            except Exception:
                pass
        # print("[WeixinNewMessage] 已停止监听")

    def get_last_results(self) -> List[ChatMessage]:
        """拿最近一次 scan_once/监听 的结果副本。"""
        with self._lock:
            return list(self._last_results)

