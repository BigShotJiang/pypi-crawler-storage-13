# wx_chat_finder.py
# -*- coding: utf-8 -*-
import time
import uiautomation as uia
from typing import Optional, Iterable, Dict


TARGET_CLASS_CHAT = "mmui::ChatSingleWindow"
_timeline_cache: Dict[int, uia.Control] = {}

# ------------ internal utils ------------

def _iter_bfs(root: uia.Control, max_nodes: int = 20000):
    q, seen = [root], 0
    while q and seen < max_nodes:
        n = q.pop(0); seen += 1
        yield n
        try:
            ch = n.GetChildren()
            if ch:
                q.extend(ch)
        except Exception:
            pass

def _children(ctrl: uia.Control) -> list:
    try:
        return ctrl.GetChildren() or []
    except Exception:
        return []

def _runtime_id_str(node) -> Optional[str]:
    """将 RuntimeId 转成 '2A.20CAC.4.80000114' 这种十六进制点分字符串。"""
    try:
        rid = node.GetRuntimeId()
        if rid:
            return ".".join(f"{int(v):X}" for v in rid)
    except Exception:
        pass
    try:
        rid = getattr(node, "RuntimeId", None)
        if isinstance(rid, (list, tuple)) and rid:
            return ".".join(f"{int(v):X}" for v in rid)
    except Exception:
        pass
    return None

def _match_chat_window(n: uia.Control, *, title: Optional[str], autoid: Optional[str]) -> bool:
    """窗口匹配策略：
      1) 若给了 automation_id，则优先用它精确匹配
      2) 否则用标题（Name）匹配
      3) 再否则仅按 Class 命中（不建议，但可作兜底）"""
    try:
        if getattr(n, "ControlTypeName", "") != "WindowControl":
            return False
        if getattr(n, "ClassName", "") != TARGET_CLASS_CHAT:
            return False

        if autoid:
            return (getattr(n, "AutomationId", "") or "") == autoid

        if title:
            return (getattr(n, "Name", "") or "").strip() == title.strip()

        return True
    except Exception:
        return False
# ------------ public: timeline & last item ------------

def _is_visual_message_node(n: uia.Control) -> bool:
    ctn = getattr(n, "ControlTypeName", "")
    if ctn not in ("ListItemControl", "PaneControl"):
        return False
    try:
        rc = n.BoundingRectangle
        return rc.width() >= 10 and rc.height() >= 10
    except Exception:
        return False



def _get_timeline_list(win: uia.Control) -> Optional[uia.Control]:
    """
    获取聊天窗口里的时间线 ListControl。
    使用一个简单的 per-window 缓存，避免每次都 BFS。
    """
    if not win or not win.Exists(0, 0):
        return None

    # 用窗口句柄做 key（也可以用 RuntimeId）
    try:
        hwnd = int(getattr(win, "NativeWindowHandle", 0) or 0)
    except Exception:
        hwnd = 0

    # 先看缓存
    if hwnd and hwnd in _timeline_cache:
        lst = _timeline_cache[hwnd]
        # 确认还存在且没失效
        try:
            if lst and lst.Exists(0, 0):
                return lst
        except Exception:
            # 失效就删掉
            _timeline_cache.pop(hwnd, None)

    # 缓存未命中 → 跑一遍原来的查找逻辑
    try:
        # 1) 先看第一层子控件
        for ch in _children(win):
            if getattr(ch, "ControlTypeName", "") == "ListControl":
                if hwnd:
                    _timeline_cache[hwnd] = ch
                return ch
    except Exception:
        pass

    try:
        # 2) BFS 兜底
        for n in _iter_bfs(win, 8000):
            if getattr(n, "ControlTypeName", "") == "ListControl":
                if hwnd:
                    _timeline_cache[hwnd] = n
                return n
    except Exception:
        pass

    return None

def get_last_message_item(win: uia.Control) -> Optional[uia.Control]:
    """
    获取时间线最后一条消息对应节点（ListItemControl/PaneControl）。
    """
    lst = _get_timeline_list(win)
    if lst:
        try:
            ch = lst.GetChildren() or []
            items = [n for n in ch if _is_visual_message_node(n)]
            if items:
                return items[-1]
        except Exception:
            pass

    last = None
    try:
        for n in _iter_bfs(win, 15000):
            if _is_visual_message_node(n):
                last = n
        return last
    except Exception:
        return None
def get_prev_message_item(item: uia.Control) -> Optional[uia.Control]:
    """
    给定当前消息项控件，返回上一条消息的 ListItem（如果有）
    """
    try:
        # 方式一：直接用 uiautomation 的 PreviousSibling
        prev = item.GetPreviousSiblingControl()
        if prev and prev.Exists(0, 0):
            return prev
    except Exception:
        pass

    # 如果没有 PreviousSiblingControl，可以退化为：
    # 1. 找到父容器（消息列表)
    # 2. 遍历 children，找到当前这个，然后选前一个
    try:
        parent = item.GetParentControl()
        if not parent:
            return None
        children = parent.GetChildren() or []
        last = None
        for ch in children:
            if ch == item:
                return last
            last = ch
    except Exception:
        pass

    return None
