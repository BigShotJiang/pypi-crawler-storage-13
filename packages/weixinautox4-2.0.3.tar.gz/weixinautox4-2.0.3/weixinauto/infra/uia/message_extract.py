# -*- coding: utf-8 -*-
from typing import Optional, List, Tuple
import uiautomation as uia
from .utils_win import iter_bfs, get_rect

TARGET_WIN_WIDTH = 980  # 可用于外部调用时锁宽

class MessageType:
    TEXT   = "text"
    IMAGE  = "image"
    VOICE  = "voice"
    VIDEO  = "video"
    FILE   = "file"
    SYSTEM = "system"
    TRANSFER="transfer"
    RED_ENVELOPE="hongbao"


import uiautomation as uia

def classify_by_classname(item: uia.Control) -> str:
    """
    根据 ClassName + Name + LegacyIAccessible.Name 归类消息类型。
    优先用 ClassName，其次用文本特征做兜底。
    """
    cls = ""
    auto_id = ""
    name = ""
    legacy_name = ""

    # ---- 基本属性 ----
    try:
        cls = (getattr(item, "ClassName", "") or "").strip()
    except Exception:
        pass

    try:
        auto_id = (getattr(item, "AutomationId", "") or "").strip()
    except Exception:
        pass

    try:
        name = (getattr(item, "Name", "") or "").strip()
    except Exception:
        pass

    # ---- LegacyIAccessible.Name ----
    try:
        # uiautomation 里一般是 GetLegacyIAccessiblePattern()
        # 某些版本不存在就直接 except
        pat = item.GetLegacyIAccessiblePattern()
        if pat:
            legacy_name = (getattr(pat, "Name", "") or "").strip()
    except Exception:
        pass

    # 综合文本：优先 Legacy；没有就用 Name
    full_text = legacy_name or name
    # 方便兜底规则使用多行内容
    full_text = full_text or ""

    # 拆成行（兼容这种格式：文件\n爱房通年度汇报(1).pptx\n3.1M\n微信电脑版）
    lines = [ln.strip() for ln in full_text.splitlines() if ln.strip()]
    first_line = lines[0] if lines else ""

    # ========== 1. 先看 ClassName ==========
    if cls == "mmui::ChatTextItemView":
        return MessageType.TEXT

    if cls == "mmui::ChatVoiceItemView":
        return MessageType.VOICE

    if cls == "mmui::ChatBubbleReferItemView":
        n = full_text
        if n.startswith("图片"):
            return MessageType.IMAGE
        if n.startswith("视频"):
            return MessageType.VIDEO
        if "微信红包" in n:
            return MessageType.RED_ENVELOPE
        if "转账" in n:
            return MessageType.TRANSFER
        # 默认当作图片
        return MessageType.IMAGE

    if cls == "mmui::ChatBubbleItemView":
        # 这个类既可能是文件，也可能是图片/视频的一些变体
        # 典型文件 Name/LegacyName:
        #   "文件\n爱房通年度汇报(1).pptx\n3.1M\n微信电脑版"
        if first_line.startswith("文件"):
            return MessageType.FILE

        if first_line.startswith("图片") or "图片" in first_line:
            return MessageType.IMAGE

        if first_line.startswith("视频") or "视频" in first_line:
            return MessageType.VIDEO

        # 根据常见扩展名再判断一层（保险一点）
        low = full_text.lower()
        common_file_exts = (
            ".ppt", ".pptx", ".doc", ".docx", ".xls", ".xlsx",
            ".pdf", ".zip", ".rar", ".7z", ".txt"
        )
        if any(ext in low for ext in common_file_exts):
            return MessageType.FILE

        # 默认把 ChatBubbleItemView 归为文件，宁可多算成 FILE
        return MessageType.FILE

    if cls == "mmui::ChatItemView" and not auto_id:
        # 没有 AutomationId 的 ChatItemView，基本都是系统消息（时间线/入群提示等）
        return MessageType.SYSTEM

    # ========== 2. 兜底：按文本特征判断 ==========
    n = full_text or name  # 再兜底一次

    if n.startswith("图片"):
        return MessageType.IMAGE
    if n.startswith("语音"):
        return MessageType.VOICE
    if n.startswith("视频"):
        return MessageType.VIDEO
    if n.startswith("文件"):
        return MessageType.FILE

    # 最后兜底：当作文本
    return MessageType.TEXT


def _node_text_candidates(n) -> List[str]:
    vals = []
    try:
        nm = (getattr(n, "Name", "") or "")
        if nm: vals.append(nm)
    except Exception: pass
    try:
        vp = n.GetValuePattern()
        if vp and (vp.Value or ""): vals.append(vp.Value)
    except Exception: pass
    try:
        legacy = n.GetLegacyIAccessiblePattern()
        if legacy:
            if legacy.Value: vals.append(legacy.Value)
            if legacy.Name:  vals.append(legacy.Name)
    except Exception: pass
    try:
        ht = (getattr(n, "HelpText", "") or "")
        if ht: vals.append(ht)
    except Exception: pass
    return vals

def extract_text_deep(node) -> str:
    def _self_text(n) -> str:
        name = (getattr(n, "Name", "") or "")
        if name: return name.rstrip("\r\n")
        try:
            legacy = n.GetLegacyIAccessiblePattern()
            if legacy:
                nm = (legacy.Name or "")
                if nm: return nm.rstrip("\r\n")
        except Exception:
            pass
        return ""
    primary = _self_text(node)
    if primary: return primary

    out: List[str] = []
    def walk(n):
        for v in _node_text_candidates(n):
            out.append(v)
        try:
            children = n.GetChildren() or []
        except Exception:
            children = []
        td = [c for c in children if getattr(c, "ControlTypeName", "") in ("TextControl", "DocumentControl")]
        for ch in td: walk(ch)
        rest = [c for c in children if c not in td]
        for ch in rest[:12]: walk(ch)
    walk(node)

    TRASH = {"更多", "更多操作", "复制", "撤回", "消息免打扰"}
    seen = set()
    cand: List[Tuple[str,int,bool]] = []
    for s in out:
        s_raw = s if isinstance(s, str) else str(s)
        s_keep = s_raw.rstrip("\r\n")
        s_norm = s_keep.strip()
        if not s_norm or s_norm in TRASH: continue
        if s_norm in seen: continue
        seen.add(s_norm)
        tail_ws = (len(s_keep) > 0 and s_keep[-1].isspace())
        cand.append((s_keep, len(s_norm), tail_ws))
    if not cand: return ""
    cand.sort(key=lambda x: (x[2], x[1]), reverse=True)
    return cand[0][0]
