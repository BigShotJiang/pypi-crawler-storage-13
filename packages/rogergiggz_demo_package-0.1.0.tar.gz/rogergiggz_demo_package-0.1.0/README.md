# Roger Demo Package
A simple example package created by Roger to learn how Python packaging works.