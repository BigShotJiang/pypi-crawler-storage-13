from setuptools import setup
from pathlib import Path

# Read README.md for the long description
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="avadcaded_math",
    version="0.0.8",
    description="A custom math module with more operations than the built-in math module",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Nguy Nhat",
    license="MIT",  # set your license
    py_modules=["avadcaded_math"],
    install_requires=[
        "numpy",
        "sympy",
    ],
    python_requires=">=3.10",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
