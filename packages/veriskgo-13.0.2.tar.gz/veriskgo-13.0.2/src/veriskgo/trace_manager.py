# veriskgo/trace_manager.py
from __future__ import annotations
import uuid
import threading
import time
import traceback
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List, Callable
import functools


class TraceManager:
    """
    Centralized trace + span manager.
    Replaces tracer.py completely.
    """

    _lock = threading.Lock()

    _active: Dict[str, Any] = {
        "trace_id": None,
        "spans": [],
        "stack": [],
    }

    # ----------------------------------------------------------------------
    # Utility functions
    # ----------------------------------------------------------------------
    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _id():
        return uuid.uuid4().hex

    # ----------------------------------------------------------------------
    # Trace API
    # ----------------------------------------------------------------------
    @classmethod
    def has_active_trace(cls) -> bool:
        return cls._active["trace_id"] is not None

    @classmethod
    def start_trace(cls, name: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """Start a new trace with a root span."""
        with cls._lock:
            trace_id = cls._id()
            root_id = cls._id()

            root_span = {
                "span_id": root_id,
                "parent_span_id": None,
                "name": name,
                "type": "root",
                "timestamp": cls._now(),
                "input": "",
                "output": "",
                "metadata": metadata or {},
                "duration_ms": 0,
                "success": True,
            }

            cls._active["trace_id"] = trace_id
            cls._active["spans"] = [root_span]
            cls._active["stack"] = [{"span_id": root_id, "start": time.time()}]

            return trace_id

    @classmethod
    def end_trace(cls, final_output: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Close all spans and return a complete trace bundle."""
        with cls._lock:
            if not cls._active["trace_id"]:
                return None

            # Close any open spans
            while cls._active["stack"]:
                cls._end_current_span()

            # Set root output
            if final_output:
                cls._active["spans"][0]["output"] = final_output

            # Build bundle
            bundle = {
                "trace_id": cls._active["trace_id"],
                "spans": cls._active["spans"].copy(),
            }

            # Reset internal state
            cls._active["trace_id"] = None
            cls._active["spans"] = []
            cls._active["stack"] = []

            return bundle

    # ----------------------------------------------------------------------
    # Span API
    # ----------------------------------------------------------------------
    @classmethod
    def start_span(cls, name: str, input_data: Optional[Any] = None) -> Optional[str]:
        """Start a span inside the active trace."""
        with cls._lock:
            if not cls._active["trace_id"]:
                return None  # no active trace → skip

            parent = cls._active["stack"][-1]["span_id"]
            sid = cls._id()

            span = {
                "span_id": sid,
                "parent_span_id": parent,
                "name": name,
                "type": "child",
                "timestamp": cls._now(),
                "input": input_data,
                "output": "",
                "metadata": {},
                "duration_ms": 0,
                "success": True,
            }

            cls._active["spans"].append(span)
            cls._active["stack"].append({"span_id": sid, "start": time.time()})

            return sid

    @classmethod
    def end_span(cls, span_id: Optional[str], output_data: Optional[Any] = None):
        """Close the span and compute duration."""
        with cls._lock:
            if not cls._active["stack"]:
                return

            if span_id is None:
                cls._end_current_span(output_data)
                return

            # Search for this span
            for i in reversed(range(len(cls._active["stack"]))):
                entry = cls._active["stack"][i]
                if entry["span_id"] == span_id:
                    duration = int((time.time() - entry["start"]) * 1000)
                    cls._active["stack"].pop(i)

                    # Update matching span object
                    for sp in cls._active["spans"]:
                        if sp["span_id"] == span_id:
                            sp["duration_ms"] = duration
                            if output_data:
                                sp["output"] = output_data
                            return

    @classmethod
    def _end_current_span(cls, output_data=None):
        """Close last opened span."""
        entry = cls._active["stack"].pop()
        sid = entry["span_id"]
        duration = int((time.time() - entry["start"]) * 1000)

        for sp in cls._active["spans"]:
            if sp["span_id"] == sid:
                sp["duration_ms"] = duration
                if output_data:
                    sp["output"] = output_data
                return

    # ----------------------------------------------------------------------
    # Extra helpers
    # ----------------------------------------------------------------------
    @classmethod
    def add_span(cls, span_dict: Dict[str, Any]):
        """Add pre-built span objects (e.g., user-profile)."""
        with cls._lock:
            cls._active["spans"].append(span_dict)

    # ----------------------------------------------------------------------
    # Decorator - Automatic Function Instrumentation
    # ----------------------------------------------------------------------
    @classmethod
    def track_function(cls, name: str = "") -> Callable:
        """Decorator: automatically creates span for the wrapped function."""

        def decorator(func):
            func_name = name or func.__name__

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                if not cls.has_active_trace():
                    return func(*args, **kwargs)

                span_id = cls.start_span(func_name, {"args": args, "kwargs": kwargs})
                start = time.time()

                try:
                    result = func(*args, **kwargs)
                    latency = int((time.time() - start) * 1000)
                    cls.end_span(span_id, {
                        "status": "success",
                        "output": result,
                        "latency_ms": latency,
                    })
                    return result

                except Exception as e:
                    latency = int((time.time() - start) * 1000)
                    cls.end_span(span_id, {
                        "status": "error",
                        "error": str(e),
                        "stacktrace": traceback.format_exc(),
                        "latency_ms": latency,
                    })
                    raise

            return wrapper

        return decorator
