# veriskgo/__init__.py

"""
VeriskGO SDK – Public API
This exposes only the clean, stable functions you want users to import.
"""

# Trace Manager (replaces old tracer.py)
from .trace_manager import TraceManager

# Export decorator for easy use
track_function = TraceManager.track_function

# Export SQS sender
from .sqs import send_to_sqs

# User profile span helper
from .user import user_profile_span

# Export models
from .models import UserProfile

__all__ = [
    "TraceManager",
    "track_function",
    "send_to_sqs",
    "user_profile_span",
    "UserProfile",
]
