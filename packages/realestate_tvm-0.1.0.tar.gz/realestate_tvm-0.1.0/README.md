# realestate-tvm

Extra time value of money helper functions that complement `numpy_financial`,
designed for real estate and finance courses.

Provides:
- compound(pv, i, n)        # multi-period compounding
- eay(fv, pv, n)            # effective annual yield from PV and FV
- annuity_value(pmt, i, n)  # FV of an ordinary annuity
