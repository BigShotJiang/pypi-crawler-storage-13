import anthropic
import os
from dotenv import load_dotenv

load_dotenv()


class AnthropicFile:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.client = anthropic.Anthropic(
            api_key=os.environ["ANTHROPIC_API_KEY"],
            default_headers={"anthropic-beta": "messages-2024-09-24"},
        )

    def upload(self):
        """Returns anthropic file object after uploading
        
        Clear side effect: even if the file was already uploaded, it uploads again.
        We should check whether the file was already uploaded to avoid duplicates.
        """
        with open(self.file_path, "rb") as f:
            uploaded_file = self.client.beta.files.upload(file=f)

        return uploaded_file

