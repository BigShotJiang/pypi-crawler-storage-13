from typing import List
from pathlib import Path
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

from loops.core.system_prompt import SystemPrompt

# Get system_prompts folder path
_current_file = Path(__file__)
_system_prompts_folder = _current_file.parent.parent / "system_prompts"


class PromptNanobanana:
    MODEL = "gpt-4.1"
    SYSTEM_PROMPT_PATH = str(_system_prompts_folder / "nanobanana_prompt.txt")

    def __init__(self):
        self.model = ChatOpenAI(model=self.MODEL, temperature=0)
        self.system_prompt = SystemPrompt(self.SYSTEM_PROMPT_PATH).read()

    def generate_from(self, concept: str) -> str:
        """Generate image prompt for Nanobanana based on ad concept."""
        content = self._construct_full_prompt(concept)
        message = HumanMessage(content=content)
        output = self.model.invoke([message]).content
        return output
    
    def _construct_full_prompt(self, concept: str) -> List:
        content = [
            self.system_prompt,
            {
                "type": "text", 
                "text": concept
            }
        ]
        return content

