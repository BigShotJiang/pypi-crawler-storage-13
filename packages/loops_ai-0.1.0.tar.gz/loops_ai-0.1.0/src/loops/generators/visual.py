from typing import List

from langchain_core.messages import HumanMessage
from langchain_google_genai import ChatGoogleGenerativeAI

from loops.core.prompted_image import PromptedImage


class NewAdVisual:
    """Generate the new ad visual"""
    MODEL = "gemini-2.5-flash-image"

    def __init__(self, product_image_path: str):
        self.product_image_path = product_image_path
        self.model = ChatGoogleGenerativeAI(
            model=self.MODEL,
            temperature=0
        )

    def generate_following(self, prompt: str):
        content = self._construct_full_prompt(prompt)
        message = HumanMessage(content=content)
        output = self.model.invoke([message]).content
        return output

    def _construct_full_prompt(self, prompt: str) -> List:
        product_image = PromptedImage(self.product_image_path).read()
        content = [
            product_image,
            {
                "type": "text", 
                "text": prompt
            }
        ]
        return content

