import os
from typing import List
from pathlib import Path

from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI

from loops.core.brand_brief import BrandBrief
from loops.core.prompted_image import PromptedImage
from loops.core.system_prompt import SystemPrompt

# Get system_prompts folder path
_current_file = Path(__file__)
_system_prompts_folder = _current_file.parent.parent / "system_prompts"


class NewAdConcept:
    """Generate new ad concept (visual ad) using GPT-O3 model."""
    MODEL = "o3"
    SYSTEM_PROMPT_PATH = str(_system_prompts_folder / "new_ad_concept.txt")

    def __init__(self, brand_brief: str):
        """
        Initialize with brand brief as string.
        
        Args:
            brand_brief: String with the brief content
        """
        self.brand_brief = brand_brief
        self.model = ChatOpenAI(model=self.MODEL)
        self.system_prompt = SystemPrompt(self.SYSTEM_PROMPT_PATH).read()

    def generate_from(self, inspiration_path: str):
        """Generate a new ad concept based on brief and inspiration.

        Args:
            inspiration_path: Path to the JPEG inspiration file

        Returns:
            Generated ad concept as string
        """
        content = self._construct_full_prompt(inspiration_path)
        message = HumanMessage(content=content)
        output = self.model.invoke([message]).content
        return output

    def _construct_full_prompt(self, inspiration_path: str) -> List:
        brief = BrandBrief(self.brand_brief).read()
        inspiration_ad = PromptedImage(inspiration_path).read()
        content = [self.system_prompt, brief, inspiration_ad]
        return content

