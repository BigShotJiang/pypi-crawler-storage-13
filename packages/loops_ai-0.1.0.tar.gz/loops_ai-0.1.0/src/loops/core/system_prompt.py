from pathlib import Path


class SystemPrompt:
    """System prompt loaded from a text file"""
    def __init__(self, path: str):
        self.path = path

    def read(self) -> dict:
        """Read text file and return content formatted for LangChain model invocation.
        
        Returns:
            dict: Content dictionary with 'type' and 'text' keys for LangChain models
        """
        p = Path(self.path)
        content = p.read_text(encoding="utf-8") if p.exists() else ""
        return {"type": "text", "text": content}

