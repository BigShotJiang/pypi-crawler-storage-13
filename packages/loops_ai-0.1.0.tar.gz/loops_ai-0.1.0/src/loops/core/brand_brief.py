class BrandBrief:
    """Brief (description of the brand and product, regardless of the visual).
    
    Accepts a string with the brief content.
    """
    def __init__(self, content: str):
        """
        Initialize with brief content as string.
        
        Args:
            content: String with the brief content
        """
        self.content = content
    
    def read(self) -> dict:
        """Returns the brief content as text usable by LangChain models.
        
        Returns:
            dict: Content dictionary with 'type' and 'text' keys
        """
        return {"type": "text", "text": self.content.strip()}

