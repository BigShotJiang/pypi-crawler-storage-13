"""Processors for images and OCR correction."""

from loops.processors.image import EncodedImage
from loops.processors.ocr import RawAdVisual

__all__ = ["EncodedImage", "RawAdVisual"]

