"""Loops - AI-powered ad generation pipeline."""

from loops.pipeline import AdGenerationPipeline
from loops.core.brand_brief import BrandBrief
from loops.generators.concept import NewAdConcept
from loops.generators.prompt import PromptNanobanana
from loops.generators.visual import NewAdVisual
from loops.processors.image import EncodedImage
from loops.processors.ocr import RawAdVisual

__version__ = "0.1.0"

__all__ = [
    "AdGenerationPipeline",
    "BrandBrief",
    "NewAdConcept",
    "PromptNanobanana",
    "NewAdVisual",
    "EncodedImage",
    "RawAdVisual",
]
