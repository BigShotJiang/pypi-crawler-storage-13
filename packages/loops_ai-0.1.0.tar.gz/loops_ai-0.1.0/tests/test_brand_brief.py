import pytest
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
import tempfile
import os
from loops.brand_brief import BrandBrief


@pytest.fixture
def fake_pdf_with_hello_world():
    """Generate a temporary PDF file containing 'hello world' text."""
    with tempfile.NamedTemporaryFile(mode='wb', suffix='.pdf', delete=False) as tmp_file:
        pdf_path = tmp_file.name
        
        # Create a PDF with reportlab
        c = canvas.Canvas(pdf_path, pagesize=letter)
        c.drawString(100, 750, "hello world")
        c.save()
        
    yield pdf_path
    
    # Cleanup
    if os.path.exists(pdf_path):
        os.unlink(pdf_path)


def test_read_with_hello_world_pdf(fake_pdf_with_hello_world):
    """Test that read() correctly extracts 'hello world' from a PDF."""
    brief = BrandBrief(fake_pdf_with_hello_world)
    result = brief.read()
    
    assert isinstance(result, dict)
    assert result["type"] == "text"
    assert "hello world" in result["text"]
    assert isinstance(result["text"], str)


def test_read_nonexistent_file():
    """Test that read() raises FileNotFoundError for non-existent files."""
    brief = BrandBrief("/nonexistent/path/to/file.pdf")
    
    with pytest.raises(FileNotFoundError):
        brief.read()
