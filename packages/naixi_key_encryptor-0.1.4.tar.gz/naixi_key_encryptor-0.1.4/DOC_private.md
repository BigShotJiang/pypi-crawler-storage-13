# naixi-key-encryptor

`naixi-key-encryptor` 是 Naixi 专用的跨语言加/解密核心。该 crate 暴露三个公开函数：

- `encrypt_naixi(secret: &str, password: &str) -> Result<String, CryptoError>`
- `decrypt_naixi(ciphertext_hex: &str, password: &str) -> Result<String, CryptoError>`
- `version() -> &'static str`

函数返回十六进制编码的密文，内部布局为 `nonce || salt || ciphertext+tag`，与本仓库提供的 Python/Node.js 绑定保持完全一致。

## 特性

- 基于 `aes-gcm` 的 AES-256-GCM，加上自定义的盐混合与 SHA-256 派生，兼顾性能和易读性。
- 统一的 `CryptoError` 错误类型，涵盖认证失败、无效 hex、密文过短、UTF-8 错误等情况。
- 内置多组确定性测试向量（包括 ASCII 与 Unicode 字符串），保证 Rust/Python/Node.js 三端行为一致。
- 作为所有上层绑定的“单一事实来源”：仅需在 Rust 核心修改算法，再重新构建 Python/Node 包即可同步更新。

## 安装

在你的 `Cargo.toml` 中加入依赖：

```toml
[dependencies]
naixi-key-encryptor = "0.1"
```

## 使用示例

```rust
use naixi_key_encryptor::{decrypt_naixi, encrypt_naixi};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let password = "naixi666.";
    let secret = "correct horse battery staple";

    let ciphertext = encrypt_naixi(secret, password)?;
    let plaintext = decrypt_naixi(&ciphertext, password)?;

    assert_eq!(secret, plaintext);
    Ok(())
}
```

## 测试

```bash
cargo test
```

当前共有 8 个单元测试，覆盖：

- ASCII 与 Unicode 往返；
- 固定密文回归向量；
- 错误口令触发的认证失败；
- 非法 hex、密文过短等输入校验。

更多跨语言示例可参考 `bindings/python` 与 `bindings/js` 目录，它们分别包含 PyO3 与 napi-rs 的封装及测试。

## 发布检查单

1. `cargo fmt && cargo test`
2. Python 绑定：`cd bindings/python && maturin develop && pytest tests`
3. Node 绑定：`cd bindings/js && npm run build && npm test`
4. 根据需要发布 crate、Wheel、npm 包
