# naixi-key-encryptor (Python bindings)

Rust 核心库 `naixi-key-encryptor` 的 Python 扩展，使用 [PyO3](https://pyo3.rs/) + [maturin](https://www.maturin.rs/) 构建。该扩展暴露 `encrypt_naixi`、`decrypt_naixi` 与 `version` 三个函数，保持与 Python 原实现完全兼容。

## 环境准备

1. 安装 Rust toolchain（推荐 `rustup`）。
2. 准备 Python 3.8+ 环境（可使用 `uv`/`pyenv`/`conda`/系统 Python）。
3. 安装 maturin：`pip install maturin`（使用 `uv` 时可 `uv pip install maturin`）。

## 开发者安装（本地可编辑）

```bash
cd bindings/python
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -U pip maturin pytest
maturin develop --manifest-path Cargo.toml
```

`maturin develop` 会在当前虚拟环境里构建并安装扩展模块，后续对 Rust 代码做修改重新运行该命令即可热更新。
> 如果终端里出现 `Both VIRTUAL_ENV and CONDA_PREFIX are set`，说明 Conda 的 base 环境还在生效。执行 `conda deactivate`（或 `unset CONDA_PREFIX CONDA_DEFAULT_ENV CONDA_SHLVL`）后再运行上面的命令即可。

### 使用 uv 的示例

```bash
uv python install 3.12          # 或者选择其它受 PyO3 支持的版本
uv venv .venv
source .venv/bin/activate
uv pip install maturin pytest
maturin develop --manifest-path Cargo.toml
```

## 运行测试

```bash
cd bindings/python
pytest tests
```

测试会验证：

- `encrypt_naixi`/`decrypt_naixi` 的往返逻辑；
- 使用已知密文解密得到固定明文（确保与 Rust/Python 原实现兼容）；
- 错误密码能够正确抛出异常。

## 使用示例

```python
from naixi_key_encryptor import encrypt_naixi, decrypt_naixi, version

password = "naixi666."
secret = "correct horse battery staple"

encrypted = encrypt_naixi(secret, password)
print("密文:", encrypted)

decrypted = decrypt_naixi(encrypted, password)
print("解密:", decrypted)

print("Rust 核心版本:", version())
```

## 构建发布用 wheel

```bash
cd bindings/python
maturin build --release --manifest-path Cargo.toml
```

产物位于 `bindings/python/target/wheels/`，可上传至内部私有源或通过 `pip install dist.whl` 安装。

## 目录说明

```
bindings/python
├── Cargo.toml        # PyO3 crate 描述
├── pyproject.toml    # Python 构建配置
├── README.md         # 本说明文件
├── src/lib.rs        # PyO3 封装
├── naixi_key_encryptor/__init__.py  # Python 暴露接口
└── tests/            # Pytest 用例
```
