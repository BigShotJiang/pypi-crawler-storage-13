import pytest

from naixi_key_encryptor import decrypt_naixi, encrypt_naixi, version

KNOWN_CIPHERTEXT = (
    "a22427226377cc867d51ad3f130af08ad13451de0430eb113f6b6e4031dc0f5143f1aa29d39f4cd455d1462f29f851"
)
KNOWN_PASSWORD = "p@ssw0rd!"
KNOWN_SECRET = "test-secret"
UNICODE_PASSWORD = "测试123"
UNICODE_SECRET = "测试一些中文字符和特殊符号!@#￥%……&*（）"
UNICODE_CIPHERTEXT = (
    "0a56298244b986a1d2612dd08e5fc01a88128d6d7922df76b9c2b080df17400daff04be75f763abbaa8eafc62e70ef41"
)
UNICODE_CIPHERTEXT_PLAIN = "123测试hhh"


def test_roundtrip():
    password = "naixi666."
    plaintext = "correct horse battery staple"
    ciphertext = encrypt_naixi(plaintext, password)
    assert decrypt_naixi(ciphertext, password) == plaintext


def test_known_vector_matches_rust():
    assert decrypt_naixi(KNOWN_CIPHERTEXT, KNOWN_PASSWORD) == KNOWN_SECRET


def test_wrong_password():
    password = "another-password"
    plaintext = "hello world"
    ciphertext = encrypt_naixi(plaintext, password)
    with pytest.raises(ValueError):
        decrypt_naixi(ciphertext, "bad-password")


def test_version_string():
    # version() 用于和 Rust crate 校验兼容性，检查能返回字符串即可
    assert isinstance(version(), str)

def test_unicode_roundtrip():
    ciphertext = encrypt_naixi(UNICODE_SECRET, UNICODE_PASSWORD)
    assert decrypt_naixi(ciphertext, UNICODE_PASSWORD) == UNICODE_SECRET


def test_decrypt_unicode_ciphertext():
    decrypted_text = decrypt_naixi(UNICODE_CIPHERTEXT, UNICODE_PASSWORD)
    assert decrypted_text == UNICODE_CIPHERTEXT_PLAIN


def test_invalid_hex_rejected():
    with pytest.raises(ValueError):
        decrypt_naixi("zzzz", "pass")


def test_too_short_ciphertext_rejected():
    with pytest.raises(ValueError):
        decrypt_naixi("0011", "pass")
