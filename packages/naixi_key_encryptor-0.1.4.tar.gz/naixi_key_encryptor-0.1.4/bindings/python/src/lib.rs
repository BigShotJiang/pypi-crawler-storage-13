use naixi_key_encryptor::{
    decrypt_naixi as decrypt_impl, encrypt_naixi as encrypt_impl, version as rust_version,
    CryptoError,
};
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyModule;

fn map_err(err: CryptoError) -> PyErr {
    PyValueError::new_err(err.to_string())
}

/// 使用 Rust 核心实现的 Naixi 加密算法加密私钥。
#[pyfunction]
pub fn encrypt_naixi(private_key: &str, password: &str) -> PyResult<String> {
    encrypt_impl(private_key, password).map_err(map_err)
}

/// 使用 Rust 核心实现的 Naixi 加密算法解密密文。
#[pyfunction]
pub fn decrypt_naixi(ciphertext_hex: &str, password: &str) -> PyResult<String> {
    decrypt_impl(ciphertext_hex, password).map_err(map_err)
}

/// 返回底层 Rust crate 的版本号，便于调用侧校验兼容性。
#[pyfunction]
pub fn version() -> PyResult<&'static str> {
    Ok(rust_version())
}

#[pymodule]
fn naixi_key_encryptor_native(_py: Python, m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(encrypt_naixi, m)?)?;
    m.add_function(wrap_pyfunction!(decrypt_naixi, m)?)?;
    m.add_function(wrap_pyfunction!(version, m)?)?;
    Ok(())
}
