# 发布手册（From 0 to 发布）

本手册说明如何从零开始准备账号、配置凭据、构建测试并向 crates.io / PyPI / npm 发布 `naixi-key-encryptor` 系列包，同时包含 GitHub Actions 自动发布的用法及 README 隐私策略。

---

## 0. 全局准备

### 0.1 仓库结构

- 核心 Rust：`src/`
- Python 绑定：`bindings/python`
- Node.js 绑定：`bindings/js`
  - napi 对应的 Rust 代码：`bindings/js/src/lib.rs`
  - TypeScript 入口：`bindings/js/ts/`

### 0.2 README 隐私策略

- Rust：`Cargo.toml` 未声明 `readme`，crates.io 不展示 README。
- Python：`pyproject.toml` 同样不包含 `readme` 字段。
- npm：发布前保持根目录 `README.md` 为公开版（可为空），私有说明使用其他文件名（如 `DOC_private.md`），并确保 `package.json` 的 `files` 仅包含需要发布的文件。GitHub Actions 已在 Rust/npm 任务中自动完成此改名动作，本地手动发布时也可执行 `mv README.md DOC_private.md && touch README.md`。

### 0.3 版本号

- Rust：`Cargo.toml` → `version`
- Python：`bindings/python/pyproject.toml` → `version`
- npm：`bindings/js/package.json`，使用 `npm version patch/minor/major` 自动更新

### 0.4 版本号更新

- Rust：手动编辑 `Cargo.toml` 的 `version`，然后 `git add Cargo.toml`
- Python：编辑 `bindings/python/pyproject.toml` 的 `version`
- Node（npm）：在 `bindings/js` 内执行 `npm version patch`（或 `minor/major`），它会自动更新 `package.json` 与 `package-lock.json`

发布前务必提交这些改动，否则 CI 构建的仍是旧版本。

### 0.5 GitHub Actions Secrets

用于 `.github/workflows/manual-release.yml`：

1. 打开仓库 **Settings → Secrets and variables → Actions → New repository secret**
2. 新建 `CRATES_IO_TOKEN`（crates.io API token）
3. 新建 `PYPI_TOKEN`（PyPI API token，格式 `pypi-xxxx`）
4. 新建 `NPM_TOKEN`（npm Access Token）

CI 会在运行 maturin / npm publish 时读取这些凭据。

Rust crate 现已纳入 workflow：触发时若勾选 “publish_rust”，会使用 `CRATES_IO_TOKEN` 自动执行 `cargo publish --allow-dirty`。

---

## 1. Rust crate（crates.io）


### 1.1 账号与 token

1. 登录 <https://crates.io/>（GitHub 账号）
2. <https://crates.io/settings/profile> 验证邮箱
3. <https://crates.io/settings/tokens> 生成 token
4. 本地执行 `cargo login <token>`（写入 `~/.cargo/credentials`）

### 1.2 发布前检查

```bash
cargo fmt
cargo test
# 确认 git 状态可接受（或发布时使用 --allow-dirty）
```

### 1.3 构建与发布

```bash
cargo publish --dry-run
# 如果存在未提交修改，可使用 --allow-dirty
cargo publish --allow-dirty
```

---

## 2. Python wheel（PyPI）

### 2.1 账号与 token

1. 登录 <https://pypi.org/>
2. <https://pypi.org/manage/account/token/> 创建 token
3. 写入 `~/.pypirc`（推荐）：
   ```
   [distutils]
   index-servers =
       pypi

   [pypi]
   username = __token__
   password = pypi-XXXXXXXXXXXXXXXXXXXX
   ```

### 2.2 发布前检查

```bash
cd bindings/python
conda deactivate   # 若终端自动激活 base
source .venv/bin/activate
maturin develop --manifest-path Cargo.toml
pytest tests
```

### 2.3 构建与发布

```bash
rm -rf target/wheels/*                        # 清理旧 wheel
maturin build --release --manifest-path Cargo.toml
maturin upload target/wheels/*.whl            # 或 twine upload ...
```

> Windows / Linux / macOS 的 wheel 需要在对应平台构建，可通过 GitHub Actions（见第 4 节）自动完成。

---

## 3. Node.js 包（npm）

### 3.1 账号与 token

1. 注册 <https://www.npmjs.com/signup>
2. 终端 `npm login`
3. 在 npm 账号设置中创建 Access Token（用于 CI）

### 3.2 发布前检查

```bash
cd bindings/js
npm install
npm run build              # 生成当前平台的 index.node + dist/index.js
npm test
```

> README 隐私：仓库中将私有说明放在 `DOC_private.md` 等文件，`README.md` 留空或仅含公开说明。GitHub Actions 会自动在发布前把公开 README 置空，无需手动介入。

### 3.3 发布

```bash
npm version patch          # 或 minor/major
npm publish --access public
```

若改由 GitHub Actions 发布，只需在 bump 版本后触发 workflow 并勾选 `publish_npm`：

1. `npm-publish` job 在 macOS (arm64)、Linux (x86_64)、Windows (x86_64) 各自运行 `napi build --release --target ... --platform`，并上传 `prebuilds/`。
2. `npm-publish-aggregate` job 汇总所有 `prebuilds`，执行 `npm publish --access public`（使用 `NPM_TOKEN`）。

---

## 4. GitHub Actions：手动触发自动发布

文件：`.github/workflows/manual-release.yml`

### 4.1 配置 Secrets

- `PYPI_TOKEN`：PyPI API token（格式 `pypi-xxxx`）
- `NPM_TOKEN`：npm Access Token

### 4.2 触发流程

1. 打开 GitHub → Actions → Manual Release
2. 点击 “Run workflow”，根据需求勾选 Python / npm
3. 工作流会：
   - `rust-publish`：在 Ubuntu 上运行 `cargo publish --allow-dirty`（使用 `CRATES_IO_TOKEN`）
   - `python-wheels`：在 macOS / Linux / Windows 三个平台运行 `maturin publish --skip-existing`
   - `npm-publish`：在三大平台生成 prebuilds，`npm-publish-aggregate` 汇总后 `npm publish --access public`

---

## 5. 发布后

1. `git tag vX.Y.Z && git push --tags`
2. 检查 PyPI / npm 页面以及（若可行）crates.io 页面是否显示正确
3. 记录变更日志、更新仓库 README 或 Release 页面
