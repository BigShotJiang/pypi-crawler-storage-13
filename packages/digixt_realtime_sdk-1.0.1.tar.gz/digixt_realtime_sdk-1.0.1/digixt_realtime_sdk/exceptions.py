"""
Custom exceptions for DigiXT SDK
"""


class DigiXTError(Exception):
    """Base exception for all DigiXT SDK errors"""
    pass


class ConnectionError(DigiXTError):
    """Raised when connection to Centrifugo fails"""
    pass


class AuthenticationError(DigiXTError):
    """Raised when authentication fails"""
    pass


class SubscriptionError(DigiXTError):
    """Raised when subscription operations fail"""
    pass


class TokenError(DigiXTError):
    """Raised when token operations fail"""
    pass

