#!/usr/bin/env python3
"""
Command-line interface for DigiXT Real-Time SDK

Usage:
    python -m digixt_realtime_sdk.cli --help
    python -m digixt_realtime_sdk.cli --url ws://localhost:8000/connection/websocket --auth-url http://localhost:3000 --username myuser --api-key my-key --channel updates
"""

import asyncio
import argparse
import json
import sys
from typing import Optional

from .client import DigiXTSDK
from .exceptions import ConnectionError, AuthenticationError


async def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description='DigiXT Real-Time SDK CLI',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage
  python -m digixt_realtime_sdk.cli \\
    --url ws://localhost:8000/connection/websocket \\
    --auth-url http://localhost:3000 \\
    --username myuser \\
    --api-key my-api-key \\
    --channel updates

  # With custom user ID
  python -m digixt_realtime_sdk.cli \\
    --url ws://localhost:8000/connection/websocket \\
    --auth-url http://localhost:3000 \\
    --username myuser \\
    --api-key my-api-key \\
    --user custom-user-id \\
    --channel updates \\
    --debug

  # Publish a message
  python -m digixt_realtime_sdk.cli \\
    --url ws://localhost:8000/connection/websocket \\
    --auth-url http://localhost:3000 \\
    --username myuser \\
    --api-key my-api-key \\
    --channel updates \\
    --publish '{"message": "Hello from CLI"}'
        """
    )
    
    # Connection parameters
    parser.add_argument(
        '--url',
        type=str,
        default='ws://localhost:8000/connection/websocket',
        help='WebSocket URL for Centrifugo (default: ws://localhost:8000/connection/websocket)'
    )
    parser.add_argument(
        '--api-url',
        type=str,
        default='http://localhost:8000/api',
        help='HTTP API URL for Centrifugo (default: http://localhost:8000/api)'
    )
    parser.add_argument(
        '--auth-url',
        type=str,
        default='http://localhost:3000',
        help='Auth service URL (default: http://localhost:3000)'
    )
    
    # Authentication parameters
    parser.add_argument(
        '--username',
        type=str,
        required=True,
        help='Username for authentication'
    )
    parser.add_argument(
        '--api-key',
        type=str,
        required=True,
        help='API key for authentication'
    )
    parser.add_argument(
        '--user',
        type=str,
        default=None,
        help='User ID for token generation (defaults to username)'
    )
    parser.add_argument(
        '--token',
        type=str,
        default=None,
        help='Pre-generated JWT token (optional, will request from auth service if not provided)'
    )
    
    # Channel parameters
    parser.add_argument(
        '--channel',
        type=str,
        default='updates',
        help='Channel to subscribe to (default: updates)'
    )
    parser.add_argument(
        '--channels',
        type=str,
        nargs='+',
        help='Multiple channels to subscribe to (overrides --channel)'
    )
    
    # Operation parameters
    parser.add_argument(
        '--publish',
        type=str,
        default=None,
        help='JSON string to publish to channel (if provided, publishes and exits)'
    )
    parser.add_argument(
        '--timeout',
        type=int,
        default=0,
        help='Timeout in seconds (0 = run indefinitely, default: 0)'
    )
    
    # Configuration parameters
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug logging'
    )
    parser.add_argument(
        '--reconnect-timeout',
        type=int,
        default=5,
        help='Seconds to wait before reconnecting (default: 5)'
    )
    parser.add_argument(
        '--max-reconnect-attempts',
        type=int,
        default=10,
        help='Maximum reconnection attempts (default: 10)'
    )
    parser.add_argument(
        '--api-key-validation-interval',
        type=int,
        default=30,
        help='Seconds between API key validations (default: 30)'
    )
    
    # Output format
    parser.add_argument(
        '--json-output',
        action='store_true',
        help='Output messages in JSON format'
    )
    
    args = parser.parse_args()
    
    # Determine channels
    channels = args.channels or [args.channel]
    
    # Initialize SDK
    sdk = DigiXTSDK(
        url=args.url,
        api_url=args.api_url,
        auth_url=args.auth_url,
        username=args.username,
        api_key=args.api_key,
        user=args.user,
        token=args.token,
        debug=args.debug,
        reconnect_timeout=args.reconnect_timeout,
        max_reconnect_attempts=args.max_reconnect_attempts,
        api_key_validation_interval=args.api_key_validation_interval
    )
    
    # Message counter
    message_count = 0
    
    # Event handlers
    def on_connected(ctx):
        if args.json_output:
            print(json.dumps({'event': 'connected', 'data': ctx}, indent=2))
        else:
            print(f"✅ Connected! Client ID: {ctx.get('client')}")
    
    def on_disconnected(ctx):
        if args.json_output:
            print(json.dumps({'event': 'disconnected', 'data': ctx}, indent=2))
        else:
            print(f"❌ Disconnected: {ctx.get('reason')}")
    
    def on_error(err):
        if args.json_output:
            print(json.dumps({'event': 'error', 'data': err}, indent=2))
        else:
            print(f"❌ Error: {err.get('error')}", file=sys.stderr)
    
    def on_subscribed(ctx):
        if args.json_output:
            print(json.dumps({'event': 'subscribed', 'data': ctx}, indent=2))
        else:
            print(f"📡 Subscribed to channel: {ctx.get('channel')}")
    
    async def on_message(ctx):
        nonlocal message_count
        message_count += 1
        
        if args.json_output:
            print(json.dumps({
                'event': 'message',
                'message_number': message_count,
                'channel': ctx['channel'],
                'data': ctx['data']
            }, indent=2))
        else:
            print(f"📨 [{message_count}] Message on {ctx['channel']}: {json.dumps(ctx['data'], indent=2)}")
    
    # Register event handlers
    sdk.on('connected', on_connected)
    sdk.on('disconnected', on_disconnected)
    sdk.on('error', on_error)
    sdk.on('subscribed', on_subscribed)
    
    try:
        # Connect
        if not args.json_output:
            print(f"Connecting to {args.url}...")
        
        try:
            await sdk.connect()
        except ConnectionError as e:
            print(f"❌ Connection failed: {e}", file=sys.stderr)
            sys.exit(1)
        except AuthenticationError as e:
            print(f"❌ Authentication failed: {e}", file=sys.stderr)
            sys.exit(1)
        
        # Publish mode
        if args.publish:
            try:
                # Parse publish data
                try:
                    publish_data = json.loads(args.publish)
                except json.JSONDecodeError:
                    print(f"❌ Invalid JSON in --publish: {args.publish}", file=sys.stderr)
                    sys.exit(1)
                
                # Publish to first channel
                result = await sdk.publish(channels[0], publish_data)
                if args.json_output:
                    print(json.dumps({'event': 'published', 'result': result}, indent=2))
                else:
                    print(f"✅ Published to {channels[0]}: {json.dumps(result, indent=2)}")
            except Exception as e:
                print(f"❌ Publish failed: {e}", file=sys.stderr)
                sys.exit(1)
            finally:
                await sdk.disconnect()
            return
        
        # Subscribe mode
        if not args.json_output:
            print(f"Subscribing to channels: {', '.join(channels)}...")
        
        for channel in channels:
            try:
                await sdk.subscribe(channel, on_publication=on_message)
            except Exception as e:
                print(f"❌ Failed to subscribe to {channel}: {e}", file=sys.stderr)
                await sdk.disconnect()
                sys.exit(1)
        
        if not args.json_output:
            print(f"\n👂 Listening for messages... Press Ctrl+C to stop\n")
        
        # Wait for timeout or indefinitely
        if args.timeout > 0:
            try:
                await asyncio.sleep(args.timeout)
            except KeyboardInterrupt:
                pass
        else:
            try:
                await asyncio.sleep(float('inf'))
            except KeyboardInterrupt:
                pass
        
    except KeyboardInterrupt:
        if not args.json_output:
            print("\n\nStopping...")
    except Exception as e:
        print(f"❌ Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        await sdk.disconnect()
        if not args.json_output:
            print(f"\n✅ Disconnected. Total messages received: {message_count}")


def cli_entry_point():
    """Entry point for console_scripts"""
    asyncio.run(main())


if __name__ == '__main__':
    cli_entry_point()

