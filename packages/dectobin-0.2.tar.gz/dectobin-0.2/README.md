# Decimal to Binary Library

A simple Python library to convert decimal numbers (integers and floats) to binary strings.

## Installation

pip install dectobin