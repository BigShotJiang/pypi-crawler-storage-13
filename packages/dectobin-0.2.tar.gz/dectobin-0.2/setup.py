from setuptools import setup, find_packages

setup(
    name="dectobin",
    version="0.2",
    packages=find_packages(),
    install_requires=[],
    description="A simple Python library to convert decimal to binary",
    author="MD Mominul Haque Ifti",
    email="mdmominulhaqueifti21@gmail.com",
    license="MIT",
    python_requires='>=3.6',
)
