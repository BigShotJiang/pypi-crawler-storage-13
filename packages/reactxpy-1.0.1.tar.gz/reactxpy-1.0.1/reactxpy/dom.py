from .hooks import get_component_state, reset_component_state, StateValue

class Component:
    def __init__(self, tag, *children, **props):
        self.tag = tag
        self.props = props
        self.children = list(children)
        
        # Check if the first child is a props dictionary (from transpiler)
        if self.children and isinstance(self.children[0], dict) and "_pysx_props" in self.children[0]:
            props_dict = self.children.pop(0)
            # Remove the flag
            del props_dict["_pysx_props"]
            # Merge into props
            self.props.update(props_dict)
        
        # Auto-inject state if this is a root component with state
        if self.tag == "div" and not self.props.get("x-data"):
            state_container = get_component_state()
            if state_container and state_container.states:
                self.props["x-data"] = state_container.to_alpine_data()

    def __str__(self):
        # Convert props: className -> class, hx_get -> hx-get, on_click -> @click
        props_list = []
        for k, v in self.props.items():
            # Handle event handlers
            if k.startswith("on_"):
                event = k[3:]  # Remove "on_" prefix
                key = f"@{event}"
            # Handle Alpine directives
            elif k.startswith("x_"):
                key = k.replace("_", "-")
            # Handle HTMX
            elif k.startswith("hx_"):
                key = k.replace("_", "-")
            # Handle className
            elif k == "className":
                key = "class"
            else:
                key = k.replace("_", "-")
            
            props_list.append(f'{key}="{v}"')
        
        # Check if any children are StateValue objects - if so, use x-text
        has_state_value = any(isinstance(c, StateValue) for c in self.children)
        if has_state_value and not any(k.startswith("x-text") or k.startswith("x_text") for k in self.props.keys()):
            # Find the StateValue and use it for x-text
            for child in self.children:
                if isinstance(child, StateValue):
                    props_list.append(f'x-text="{child.name}"')
                    # Remove the StateValue from children as it's now an attribute
                    self.children = [c for c in self.children if not isinstance(c, StateValue)]
                    break
        
        props_str = " ".join(props_list)
        if props_str:
            props_str = " " + props_str
        
        # Process children: unwrap tuples from .pysx trailing commas
        processed_children = []
        for child in self.children:
            if isinstance(child, tuple) and child:
                # Take the first element of the tuple
                processed_children.append(str(child[0]))
            elif not isinstance(child, StateValue):  # Skip StateValue objects
                processed_children.append(str(child))
        
        children_str = "".join(processed_children)
        
        return f"<{self.tag}{props_str}>{children_str}</{self.tag}>"

def make_tag(tag):
    def tag_func(*children, **props):
        return Component(tag, *children, **props)
    return tag_func

# Common HTML tags
div = make_tag("div")
span = make_tag("span")
h1 = make_tag("h1")
h2 = make_tag("h2")
h3 = make_tag("h3")
p = make_tag("p")
button = make_tag("button")
a = make_tag("a")
ul = make_tag("ul")
li = make_tag("li")
script = make_tag("script")
link = make_tag("link")
head = make_tag("head")
body = make_tag("body")
html = make_tag("html")
meta = make_tag("meta")
title = make_tag("title")
input = make_tag("input")
form = make_tag("form")
