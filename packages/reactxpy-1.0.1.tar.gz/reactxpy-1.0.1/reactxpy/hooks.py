import contextvars
from typing import Any, Tuple, Callable

# Context variable to track state within a component
_component_state = contextvars.ContextVar('component_state', default=None)

class StateValue:
    """Represents a stateful value that binds to Alpine.js"""
    
    def __init__(self, name: str, initial: Any):
        self.name = name
        self.initial = initial
    
    def __str__(self):
        # Returns Alpine.js template binding
        return f"{{{{{self.name}}}}}"
    
    def __repr__(self):
        return f"StateValue({self.name}={self.initial})"
    
    # Support arithmetic operations
    def __add__(self, other):
        if isinstance(other, StateValue):
            return f"{self.name} + {other.name}"
        return f"{self.name} + {other}"
    
    def __sub__(self, other):
        if isinstance(other, StateValue):
            return f"{self.name} - {other.name}"
        return f"{self.name} - {other}"
    
    def __mul__(self, other):
        if isinstance(other, StateValue):
            return f"{self.name} * {other.name}"
        return f"{self.name} * {other}"

class StateContainer:
    """Container for all state in a component"""
    
    def __init__(self):
        self.states = {}
        self._counter = 0
    
    def add_state(self, initial_value):
        """Add a new state variable and return its name"""
        self._counter += 1
        var_name = f"s{self._counter}"
        self.states[var_name] = initial_value
        return var_name
    
    def to_alpine_data(self):
        """Convert to Alpine.js x-data attribute"""
        # Format: { s1: 0, s2: 'hello', s3: true }
        items = [f"{k}: {self._format_value(v)}" for k, v in self.states.items()]
        return "{ " + ", ".join(items) + " }"
    
    def _format_value(self, value):
        """Format Python value for JavaScript"""
        if isinstance(value, str):
            return f"'{value}'"
        elif isinstance(value, bool):
            return "true" if value else "false"
        elif value is None:
            return "null"
        else:
            return str(value)

def use_state(initial_value: Any) -> Tuple[StateValue, Callable]:
    """
    React-like useState hook for ReactXPy.
    
    Returns a tuple of (state, setState) where:
    - state: A StateValue that can be used in templates
    - setState: A function that returns Alpine.js expression for updating state
    
    Example:
        count, set_count = use_state(0)
        
        div(
            p(f"Count: {count}"),
            button("+", on_click=set_count(count + 1))
        )
    """
    # Get or create state container for this component
    container = _component_state.get()
    if container is None:
        container = StateContainer()
        _component_state.set(container)
    
    # Register this state variable
    var_name = container.add_state(initial_value)
    state = StateValue(var_name, initial_value)
    
    # Create setter function
    def set_state(new_value):
        """Returns Alpine.js expression for setting state"""
        if isinstance(new_value, str):
            # If it's already an expression like "count + 1", use as-is
            if any(op in new_value for op in ['+', '-', '*', '/', '=']):
                return f"{var_name} = {new_value}"
            # Otherwise quote it as a string
            return f"{var_name} = '{new_value}'"
        elif isinstance(new_value, StateValue):
            return f"{var_name} = {new_value.name}"
        else:
            return f"{var_name} = {new_value}"
    
    return (state, set_state)

def get_component_state() -> StateContainer:
    """Get the current component's state container"""
    return _component_state.get()

def reset_component_state():
    """Reset component state (call before rendering a new component)"""
    _component_state.set(StateContainer())
