import sys
import os
import importlib.abc
import importlib.machinery
from .compiler import transpile_pysx

class PysxLoader(importlib.abc.Loader):
    def __init__(self, filename):
        self.filename = filename

    def create_module(self, spec):
        return None  # Default module creation

    def exec_module(self, module):
        with open(self.filename, 'r') as f:
            source = f.read()
        
        # Transpile
        code = transpile_pysx(source)
        
        # Compile and execute
        module.__file__ = self.filename
        exec(code, module.__dict__)

class PysxFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        if path is None:
            path = sys.path
            
        # Look for .pysx file matching the module name
        parts = fullname.split('.')
        name = parts[-1]
        
        for entry in path:
            # Check for file.pysx
            filename = os.path.join(entry, name + '.pysx')
            if os.path.exists(filename):
                return importlib.machinery.ModuleSpec(
                    fullname,
                    PysxLoader(filename),
                    origin=filename
                )
        return None
