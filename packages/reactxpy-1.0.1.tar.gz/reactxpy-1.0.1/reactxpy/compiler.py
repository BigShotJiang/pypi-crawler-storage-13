import re

def parse_attrs_to_dict_str(attrs_str):
    """
    Parses attribute string to a Python dict string:
    class="foo" -> "class": "foo"
    value={1+1} -> "value": 1+1
    @click="..." -> "@click": "..."
    x-text="..." -> "x-text": "..."
    """
    if not attrs_str:
        return ""
    
    props = []
    # Match attributes including special ones like @click, x-text, and modifiers like @submit.prevent
    # Added '.' to the character class to support modifiers
    pattern = r'([@\w.-]+)=(?:"([^"]*)"|\{([^}]*)\})'
    
    matches = re.finditer(pattern, attrs_str)
    for match in matches:
        key = match.group(1)
        val_str = match.group(2)
        val_expr = match.group(3)
        
        if val_str is not None:
            props.append(f'"{key}": "{val_str}"')
        else:
            props.append(f'"{key}": {val_expr}')
            
    return ", ".join(props)

def transpile_pysx(source):
    """
    Transpiles .pysx source code to valid Python.
    """
    
    # 1. Handle Text Content: > text < -> > f"text", <
    def quote_text(match):
        content = match.group(1)
        if not content.strip():
            return f'>{content}<' 
        return f'>f"{content}",<'

    source = re.sub(r'>([^<]+)<', quote_text, source)
    
    # 2. Self-closing tags: <Tag ... /> -> Tag({...}),
    def replace_self_closing(match):
        tag = match.group(1)
        attrs = match.group(2)
        props_str = parse_attrs_to_dict_str(attrs)
        if props_str:
            props_arg = f'{{"_pysx_props": True, {props_str}}}'
            return f"{tag}({props_arg}),"
        else:
            return f"{tag}(),"

    source = re.sub(r'<(\w+)([^>]*?)\s*/>', replace_self_closing, source)

    # 3. Opening tags: <Tag ...> -> Tag({...},
    def replace_open_tag(match):
        tag = match.group(1)
        attrs = match.group(2)
        props_str = parse_attrs_to_dict_str(attrs)
        if props_str:
            props_arg = f'{{"_pysx_props": True, {props_str}}}'
            return f"{tag}({props_arg}, "
        else:
            return f"{tag}("

    source = re.sub(r'<(\w+)([^>]*)>', replace_open_tag, source)
    
    # 4. Closing tags: </Tag> -> ),
    source = re.sub(r'</\w+>', '),', source)
    
    return source
