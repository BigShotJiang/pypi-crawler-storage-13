from flask import Flask, render_template_string
from functools import wraps

class ReactXPy:
    def __init__(self, import_name, **kwargs):
        self.app = Flask(import_name, **kwargs)

    def route(self, rule, **options):
        def decorator(f):
            @self.app.route(rule, **options)
            @wraps(f)
            def wrapper(*args, **kwargs):
                # Call the component function
                component = f(*args, **kwargs)
                
                # Handle tuple return (from trailing commas in .pysx)
                if isinstance(component, tuple):
                    # It might be (Component, ) or (Component, "", ...)
                    # We take the first element
                    if component:
                        component = component[0]
                
                # Render it to a string
                return str(component)
            return wrapper
        return decorator

    def run(self, **kwargs):
        self.app.run(**kwargs)
