import os
import sys

def create_file(path, content):
    with open(path, 'w') as f:
        f.write(content.strip() + '\n')
    print(f"Created {path}")

def main():
    print("Scaffolding new ReactXPy app (with .pysx and Alpine.js support)...")

    # Create directories
    dirs = ['src', 'src/components', 'src/pages', 'public']
    for d in dirs:
        os.makedirs(d, exist_ok=True)
        print(f"Created directory {d}")

    # run.py
    create_file('run.py', '''
from src.App import app

if __name__ == '__main__':
    app.run(debug=True)
''')

    # src/App.py
    create_file('src/App.py', '''
from reactxpy import ReactXPy, div, h1, p, script, link, head, body, html, title, meta
# Import the .pysx file directly!
from .pages.Home import Home

app = ReactXPy(__name__, static_folder='../public')

@app.route('/')
def index():
    return html(
        head(
            meta(charset="UTF-8"),
            meta(name="viewport", content="width=device-width, initial-scale=1.0"),
            title("My ReactXPy App"),
            script(src="https://unpkg.com/htmx.org@1.9.10"),
            script(src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js", defer="true"),
            link(rel="stylesheet", href="/public/style.css")
        ),
        body(
            div(
                Home(),
                id="root"
            )
        ),
        lang="en"
    )
''')

    # src/pages/Home.pysx
    create_file('src/pages/Home.pysx', '''
from reactxpy import div, h1, h2, p
from ..components.Counter import Counter
from ..components.AlpineCounter import AlpineCounter

def Home():
    return <div className="home-container">
        <h1>Welcome to ReactXPy!</h1>
        <p>Choose your state management approach:</p>
        
        <h2>HTMX Counter (Server-side)</h2>
        <Counter />
        
        <h2>Alpine.js Counter (Client-side)</h2>
        <AlpineCounter />
    </div>
''')

    # src/components/Counter.py (HTMX version)
    create_file('src/components/Counter.py', '''
from reactxpy import div, p, button

def Counter(count=0):
    return div(
        p(f"Count: {count}"),
        button("Increment", 
               hx_get=f"/count/{count+1}", 
               hx_target="closest .counter", 
               hx_swap="outerHTML"),
        className="counter htmx-counter"
    )
''')

    # src/components/AlpineCounter.py (Alpine.js version)
    create_file('src/components/AlpineCounter.py', '''
from reactxpy import div, p, button

def AlpineCounter():
    return div(
        p("", **{"x-text": "count"}),
        button("Increment", **{"@click": "count++"}),
        **{"x-data": "{ count: 0 }"},
        className="counter alpine-counter"
    )
''')

    # Add route for HTMX counter in App.py
    with open('src/App.py', 'a') as f:
        f.write('''
from .components.Counter import Counter

@app.route('/count/<int:count>')
def count_route(count):
    return Counter(count)
''')

    # public/style.css
    create_file('public/style.css', '''
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    margin: 0;
    padding: 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
}

#root {
    background: white;
    padding: 2rem;
    border-radius: 12px;
    max-width: 700px;
    margin: 0 auto;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
}

h1 {
    color: #667eea;
    margin-bottom: 0.5rem;
}

h2 {
    color: #555;
    font-size: 1.2rem;
    margin-top: 2rem;
    margin-bottom: 1rem;
}

.counter {
    background: #f8f9fa;
    padding: 1.5rem;
    border-radius: 8px;
    margin: 1rem 0;
    border: 2px solid #e9ecef;
}

.htmx-counter {
    border-color: #61dafb;
}

.alpine-counter {
    border-color: #8bc34a;
}

.counter p {
    font-size: 1.5rem;
    font-weight: bold;
    margin: 0 0 1rem 0;
    color: #333;
}

button {
    padding: 10px 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 1rem;
    font-weight: 600;
    transition: transform 0.2s, box-shadow 0.2s;
}

button:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

button:active {
    transform: translateY(0);
}
''')

    print("Done! Run 'python3 run.py' to start your app.")
    print("\nYour app includes:")
    print("  - HTMX for server-side interactivity")
    print("  - Alpine.js for client-side state management")

if __name__ == '__main__':
    main()
