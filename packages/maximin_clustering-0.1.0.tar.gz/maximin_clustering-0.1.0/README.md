# Maximin Clustering for Python

A pure Python implementation of the **Maximin clustering algorithm**, fully
compatible with scikit-learn's API.

## Installation

pip install maximin-clustering

## Usage

```python
from maximin_clustering import Maximin

mm = Maximin(fraction=0.5)
labels = mm.fit_predict(X)

print(mm.cluster_centers_)
```
