import numpy as np
from sklearn.base import BaseEstimator, ClusterMixin
from sklearn.metrics import pairwise_distances


class Maximin(BaseEstimator, ClusterMixin):
    """
    Maximin clustering algorithm.

    Parameters
    ----------
    fraction : float
        Appreciable fraction criterion (0–1) for adding new centers.
    """

    def __init__(self, fraction=0.5):
        self.fraction = fraction

    def fit(self, X, y=None):
        X = np.asarray(X)
        centers = [X[0]]  # Z1

        # Z2: farthest from Z1
        d = pairwise_distances(X, [centers[0]]).flatten()
        centers.append(X[d.argmax()])

        # MIN_i distances
        min_d = pairwise_distances(X, centers).min(axis=1)

        # Add centers
        while True:
            idx = min_d.argmax()
            max_min = min_d[idx]

            C = np.vstack(centers)

            if len(C) > 1:
                dc = pairwise_distances(C)
                typical = dc[np.triu_indices(len(C), 1)].mean()
            else:
                typical = max_min

            if max_min > self.fraction * typical:
                centers.append(X[idx])
                new_d = pairwise_distances(X, [X[idx]]).flatten()
                min_d = np.minimum(min_d, new_d)
            else:
                break

        # Assign points
        self.cluster_centers_ = np.vstack(centers)
        self.labels_ = pairwise_distances(X, self.cluster_centers_).argmin(axis=1)
        return self

    def fit_predict(self, X, y=None):
        self.fit(X)
        return self.labels_
