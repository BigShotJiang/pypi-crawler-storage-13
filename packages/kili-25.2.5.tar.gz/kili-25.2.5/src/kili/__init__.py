"""Kili Python SDK."""

__version__ = "25.2.5"
