
from dv_flow.mgr import ExtRgy as DfmExtRgy

class ExtRgy(DfmExtRgy):

    def __init__(self):
        # Initialize base ExtRgy to ensure internal maps (_pkg_m, etc) exist
        super().__init__()
        base = DfmExtRgy.inst()
        # Copy discovered packages and shells so this registry can serve them
        self._pkg_m = base._pkg_m.copy()
        self._shell_m = base._shell_m.copy()
        self.ext_rgy = base
        self.pkg_m = {}

    def addPackage(self, name, pkgfile):
        self.pkg_m[name] = pkgfile

    def hasPackage(self, name, search_path=True):
        if name in self.pkg_m.keys():
            return True
        else:
            return self.ext_rgy.hasPackage(name, search_path)
        
    def findPackagePath(self, name):
        if name in self.pkg_m.keys():
            return self.pkg_m[name]
        else:
            ret = self.ext_rgy.findPackagePath(name)
            return ret

