from . import build
from . import pypipush
import sys
import argparse
import logging
from typing import Optional, List

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    """
    Parse command line arguments for the main pynary entry point.
    
    Args:
        argv: Optional list of command line arguments (defaults to sys.argv)
        
    Returns:
        Parsed arguments namespace
    """
    parser = argparse.ArgumentParser(
        description='pynary - Convert Python code to binary format and upload to PyPI',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Build a package (current platform only)
  python -m pynary -n mypackage
  
  # Build with clean build
  python -m pynary -n mypackage -f
  
  # Cross-platform build using Docker
  python -m pynary -n mypackage --platforms linux
  python -m pynary -n mypackage --platforms linux windows
  python -m pynary -n mypackage --platforms all
  
  # Upload to PyPI
  python -m pynary -c pypipush -n mypackage -d production --token pypi-xxxxx
  
  # Upload to TestPyPI
  python -m pynary -c p -n mypackage -d test

For more information, see the README.md or visit the project repository.
        """
    )
    parser.add_argument(
        '-c', '--command',
        type=str,
        default='build',
        choices=['build', 'b', 'pypipush', 'p'],
        help='Command to execute: build/b or pypipush/p (default: build)'
    )
    parser.add_argument(
        '-n', '--name',
        type=str,
        default='pynary',
        help='Project name (default: pynary)'
    )
    parser.add_argument(
        '-o', '--output',
        type=str,
        default='package',
        help='Output folder name (default: package)'
    )
    parser.add_argument(
        '-m', '--mbuild',
        action='store_true',
        help='Use new build system (python -m build)'
    )
    parser.add_argument(
        '-f', '--fresh',
        action='store_true',
        help='Perform fresh/clean build'
    )
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Enable verbose output'
    )
    parser.add_argument(
        '--platforms',
        type=str,
        nargs='+',
        choices=['linux', 'windows', 'macos', 'all'],
        help='Build for specific platforms using Docker (requires Docker). '
             'Options: linux, windows, macos, or "all" for all platforms. '
             'Note: macOS builds require macOS host. Windows builds require Windows host with Windows containers.'
    )
    
    if argv is None:
        argv = sys.argv[1:]
    return parser.parse_args(argv)


def main() -> None:
    """
    Main entry point for pynary module.
    """
    try:
        args = parse_args()
        
        if args.verbose:
            logger.setLevel(logging.DEBUG)
        
        project_name = args.name
        package_folder_name = args.output
        command_name = args.command
        use_new_mbuild = args.mbuild
        fresh_build = args.fresh
        
        # Validate project name
        if not project_name or not project_name.replace('_', '').replace('-', '').isalnum():
            raise ValueError(f"Invalid project name: {project_name}")
        
        logger.info(f"Command: {command_name}")
        logger.info(f"Project name: {project_name}")
        
        if command_name in ("build", "b"):
            # If platforms are specified, pass them directly to build.main()
            if hasattr(args, 'platforms') and args.platforms:
                # Build the argument list for build.main()
                build_args = ["-n", project_name, "-o", package_folder_name]
                if use_new_mbuild:
                    build_args.append("-m")
                if fresh_build:
                    build_args.append("-c")
                if args.verbose:
                    build_args.append("-v")
                build_args.extend(["--platforms"] + args.platforms)
                build.main(build_args)
            else:
                build.run(use_new_mbuild, project_name, package_folder_name, fresh_build)
        elif command_name in ("pypipush", "p"):
            # Pass all arguments to pypipush for it to parse
            pypipush.main(sys.argv)
        else:
            raise ValueError(f"Unknown command: {command_name}")
            
    except Exception as e:
        logger.error(f"Command failed: {e}", exc_info=True)
        sys.exit(1)


if __name__ == '__main__':
    main()
