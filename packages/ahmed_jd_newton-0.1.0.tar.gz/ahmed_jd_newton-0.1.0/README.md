# Ahmed_Jd_Newton

Module Python simplifiant l'interpolation de Newton pour les étudiants.

## Installation

