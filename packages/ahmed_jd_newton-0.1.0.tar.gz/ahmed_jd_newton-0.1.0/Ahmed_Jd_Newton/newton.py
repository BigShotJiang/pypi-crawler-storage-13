import numpy as np
import sympy as sp

def dd_newton(x, y):
    """
    Calcule la table des différences divisées de Newton.
    x : tableau des abscisses
    y : tableau des ordonnées
    Retourne : les coefficients du polynôme de Newton
    """
    n = len(x)
    A = np.zeros((n, n))
    A[:, 0] = y

    for j in range(1, n):
        for i in range(n - j):
            A[i][j] = (A[i + 1][j - 1] - A[i][j - 1]) / (x[i + j] - x[i])

    return A[0, :]


def newton_polynomial(x_points, coef, x):
    """
    Évalue le polynôme de Newton en un point x.

    x_points : tableau des points d'interpolation
    coef     : coefficients obtenus par dd_newton
    x        : point où évaluer le polynôme
    """
    n = len(coef)
    p = coef[0]
    prod = 1

    for k in range(1, n):
        prod *= (x - x_points[k-1])
        p += coef[k] * prod

    return p


def Polynome_de_Newton(x_points, coef):
    """
    Retourne l'expression symbolique du polynôme de Newton.

    x_points : points d'interpolation
    coef     : coefficients obtenus via dd_newton
    Retour   : expression sympy du polynôme
    """
    x = sp.Symbol('x')
    n = len(coef)
    P = coef[0]
    term = 1

    for k in range(1, n):
        term *= (x - x_points[k - 1])
        P += coef[k] * term

    return sp.expand(P)
