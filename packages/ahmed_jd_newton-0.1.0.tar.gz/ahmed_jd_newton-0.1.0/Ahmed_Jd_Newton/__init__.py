from .newton import (
    dd_newton,
    newton_polynomial,
    Polynome_de_Newton
)
