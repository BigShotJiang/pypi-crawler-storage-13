from setuptools import setup, find_packages

setup(
    name="Ahmed_Jd_Newton",
    version="0.1.0",
    author="Ahmed Jidou El Bechir",
    description="Module d'interpolation de Newton pour les étudiants.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "sympy"
    ],
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
