# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

<!-- insertion marker -->
## [v0.2.3](https://github.com/sicksubroutine/bear-shelf/releases/tag/v0.2.3) - 2025-11-20

<small>[Compare with v0.2.2](https://github.com/sicksubroutine/bear-shelf/compare/v0.2.2...v0.2.3)</small>

### Code Refactoring

- simplify BearBase class definition and clean up imports in TablesHolder ([b700936](https://github.com/sicksubroutine/bear-shelf/commit/b700936fd8b05ad40c28dee3facbe2d5ca1854ab) by chaz).

## [v0.2.2](https://github.com/sicksubroutine/bear-shelf/releases/tag/v0.2.2) - 2025-11-20

<small>[Compare with v0.2.1](https://github.com/sicksubroutine/bear-shelf/compare/v0.2.1...v0.2.2)</small>

## [v0.2.1](https://github.com/sicksubroutine/bear-shelf/releases/tag/v0.2.1) - 2025-11-19

<small>[Compare with v0.2.0](https://github.com/sicksubroutine/bear-shelf/compare/v0.2.0...v0.2.1)</small>

## [v0.2.0](https://github.com/sicksubroutine/bear-shelf/releases/tag/v0.2.0) - 2025-11-19

<small>[Compare with first commit](https://github.com/sicksubroutine/bear-shelf/compare/3b6c820a15c770b9f46e8ea7d1057882b99b3d22...v0.2.0)</small>

### Features

- Implement JSONL database support with SQLAlchemy dialect ([eaf0982](https://github.com/sicksubroutine/bear-shelf/commit/eaf0982e857402ca78805998ef0a39bc172cd470) by chaz).

### Code Refactoring

- Organize imports and enhance JSONL structure handling ([7370ec6](https://github.com/sicksubroutine/bear-shelf/commit/7370ec68e4952f8942e7df1d8ff04bb7ce7b01ec) by chaz).
