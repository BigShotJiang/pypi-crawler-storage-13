from __future__ import annotations

from dataclasses import dataclass, field
from threading import RLock
from typing import TYPE_CHECKING, Any, NamedTuple

from sqlalchemy import func, select

from funcy_bear.tools.names import Names

if TYPE_CHECKING:
    from collections.abc import Sequence

    from sqlalchemy.orm import DeclarativeMeta, Query, QueryableAttribute, Session, scoped_session


def attr_name(cls: str, attr: str = "data") -> str:
    """Generate a standardized attribute name for storing per-class data.

    Args:
        cls (str): The class name.
        attr (str): The attribute name.

    Returns:
        str: The standardized attribute name.
    """
    return f"_{cls}_{attr}"


@dataclass(slots=True)
class PerClassData:
    """Data class to hold per-class database information."""

    base: DeclarativeMeta | None = None
    scoped_sess: scoped_session | None = None
    lock: RLock = field(default_factory=RLock)


class DatabaseManagerMeta(type):
    def __new__(mcs, name: str, bases: tuple, namespace: dict, bypass: bool = True) -> Any:
        if not bases and bypass:
            return super().__new__(mcs, name, bases, namespace)
        container_name: str = attr_name(name)
        namespace[container_name] = PerClassData()
        return super().__new__(mcs, name, bases, namespace)

    @property
    def _name(cls) -> str:
        """Get the name of the class."""
        return cls.__name__

    @property
    def _meta_name(cls) -> str:
        return attr_name(cls.__name__)

    @property
    def _internal(cls) -> PerClassData:
        """Get the internal data attribute name for the class."""
        if not hasattr(cls, cls._meta_name):
            raise AttributeError(f"Class {cls._name} is missing internal data attribute {cls._meta_name}")
        return getattr(cls, cls._meta_name)

    @property
    def _lock(cls) -> RLock:
        """Get the lock for the database manager."""
        return cls._internal.lock

    @property
    def _base(cls) -> DeclarativeMeta | None:
        """Get the base class for the database manager."""
        return cls._internal.base

    def _set_base(cls, value: DeclarativeMeta | None) -> None:
        """Set the base class for the database manager."""
        with cls._internal.lock:
            cls._internal.base = value

    def _get_base(cls) -> DeclarativeMeta:
        """Get the base class for the database manager, creating it if necessary."""
        with cls._internal.lock:
            return cls._base  # type: ignore[return-value]

    @property
    def _scoped_session(cls) -> scoped_session | None:
        """Get the scoped session for the database manager."""
        with cls._internal.lock:
            return cls._internal.scoped_sess

    @_scoped_session.setter
    def _scoped_session(cls, value: scoped_session | None) -> None:
        """Set the scoped session for the database manager."""
        with cls._internal.lock:
            cls._internal.scoped_sess = value


def get_name(obj: str | object | type) -> str:
    """Get the name of a class or return the string if already a string.

    Args:
        obj: The type, object instance, or string to get the name of.

    Returns:
        str: The name of the class or the string itself.
    """
    if isinstance(obj, str):
        return obj.lower()
    if isinstance(obj, type):
        return obj.__name__.lower()
    return obj.__class__.__name__.lower()


class DynamicRecords[T]:
    """A simple class to hold records of a specific type."""

    def __init__(self, tbl_obj: type[T], session: scoped_session[Session]) -> None:
        """Initialize the RecordsHolder with a table object and session."""
        self.tbl_obj: type[T] = tbl_obj
        self._session: scoped_session[Session] = session

    @property
    def session(self) -> Session:
        """Get the current session."""
        return self._session()

    def count(self) -> int:
        """Get the number of records of the specified type."""
        return len(self)

    def query(self) -> Query[T]:
        """Query all records of the specified type."""
        return self.session.query(self.tbl_obj)

    def all(self) -> list[T]:
        """Get all records of the specified type."""
        return self.query().all()

    def search(self, search: str, *columns: QueryableAttribute) -> Query[T]:
        """Search records by specified columns."""
        if not columns:
            raise ValueError("At least one column must be specified for search.")
        query: Query[T] = self.query()
        search_pattern: str = f"%{search}%"
        filters: list = [column.ilike(search_pattern) for column in columns]
        return query.filter(*filters)

    def filter_by(self, **kwargs: Any) -> Query[T]:
        """Filter records by specified keyword arguments."""
        return self.query().filter_by(**kwargs)

    def first(self) -> T | None:
        """Get the first record of the specified type."""
        return self.query().first()

    def get(self, ident: Any) -> T | None:
        """Get a record by its primary key."""
        return self.session.get(entity=self.tbl_obj, ident=ident)

    def add(self, instance: T) -> None:
        """Add a new record to the session."""
        self.session.add(instance)

    def add_all(self, instances: Sequence[T]) -> None:
        """Add multiple new records to the session."""
        self.session.add_all(instances)

    def update(self, instance: T, **kwargs: Any) -> None:
        """Update a record with specified keyword arguments."""
        for key, value in kwargs.items():
            setattr(instance, key, value)
        self.session.add(instance)

    def paginate(self, page: int, per_page: int) -> list[T]:
        """Paginate records of the specified type."""
        if page < 1 or per_page < 1:
            raise ValueError("Page and per_page must be positive integers.")
        query: Query[T] = self.query()
        return query.offset((page - 1) * per_page).limit(per_page).all()

    def pages(self, per_page: int) -> int:
        """Get the total number of pages based on per_page."""
        if per_page < 1:
            raise ValueError("per_page must be a positive integer.")
        total_records: int = len(self)
        return (total_records + per_page - 1) // per_page  # Ceiling division

    def delete(self, instance: T) -> None:
        """Delete a record from the session."""
        self.session.delete(instance)

    def commit(self) -> None:
        """Commit the current transaction."""
        self.session.commit()

    def rollback(self) -> None:
        """Rollback the current transaction."""
        self.session.rollback()

    def refresh(self, instance: T) -> None:
        """Refresh the instance with the latest data from the database."""
        self.session.refresh(instance)

    def remove(self) -> None:
        """Close the session."""
        self._session.remove()

    def __len__(self) -> int:
        """Get the number of records of the specified type."""
        return self.session.scalar(select(func.count()).select_from(self.tbl_obj)) or 0

    def __enter__(self) -> DynamicRecords[T]:
        """Enter the runtime context related to this object."""
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        """Exit the runtime context related to this object."""
        self.remove()


class TableHandler(NamedTuple):
    """A simple named tuple to hold table handler information."""

    name: str
    table_obj: type
    session: scoped_session[Session]
    records: DynamicRecords

    def remove(self) -> None:
        """Close the session associated with this table handler."""
        self.records.remove()

    def get_session(self) -> scoped_session[Session]:
        """Get the session associated with this table handler."""
        return self.session

    def get_records(self) -> DynamicRecords:
        """Get the records associated with this table handler."""
        return self.records

    def __getattr__(self, item: str) -> Any:
        """Delegate attribute access to the records object."""
        return getattr(self.records, item)


class TableHandlers(Names[TableHandler]):
    """A Namespace-like class to hold multiple TableHandler instances."""

    def add_handler(self, k: str, v: TableHandler) -> None:
        """Add a new TableHandler to the collection."""
        self.add(k.lower(), v)

    def get_handler(self, name: str | type) -> TableHandler:
        """Get a table handler by name."""
        if isinstance(name, (type | object)):
            name = get_name(name)
        return self.get(name.lower(), strict=True)

    def has_handler(self, name: type | str) -> bool:
        """Check if a table handler exists by name."""
        return self.has(get_name(name).lower())

    @property
    def sessions(self) -> list[scoped_session[Session]]:
        """Get all sessions from the table handlers."""
        return [handler.session for handler in self.values()]

    def count(self) -> int:
        """Get the number of table handlers."""
        return len(self._root)

    def clear(self) -> None:
        """Clear all table handlers and close their sessions."""
        self.close()
        self._root.clear()

    def close(self) -> None:
        """Close all table handlers."""
        for handler in self.values():
            handler.remove()
