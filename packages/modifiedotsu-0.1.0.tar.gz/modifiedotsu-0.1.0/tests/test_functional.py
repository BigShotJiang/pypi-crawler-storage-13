"""
Optional functional correctness test for getMask.
Checks internal consistency without assuming exact threshold values.
"""

import numpy as np
from modifiedOtsu.core import getMask  # Adjust based on your package name


def test_getMask_consistency():
    """Test that binary mask corresponds correctly to threshold map."""
    # Small synthetic 3D image
    img = np.random.randint(0, 256, size=(5, 5, 5), dtype=np.uint8)

    # Run getMask
    threshold_map, binary_mask = getMask(img, window_size=(3, 3, 3), delta=0.05)

    # Check shapes
    assert threshold_map.shape == img.shape, "Threshold map shape mismatch"
    assert binary_mask.shape == img.shape, "Binary mask shape mismatch"

    # Check types
    assert threshold_map.dtype == np.int32, "Threshold map should be int32"
    assert binary_mask.dtype == bool, "Binary mask should be boolean"

    # Check that mask values match threshold_map
    assert np.all(
        binary_mask == (img >= threshold_map)
    ), "Binary mask values inconsistent with threshold map"

    print("✓ getMask consistency functional test passed")


if __name__ == "__main__":
    test_getMask_consistency()
