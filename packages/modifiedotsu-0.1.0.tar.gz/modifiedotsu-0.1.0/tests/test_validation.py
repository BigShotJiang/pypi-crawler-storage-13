"""
Input validation tests for getMask
"""

import numpy as np
from modifiedOtsu.core import getMask

# Color codes for terminal output
GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
RESET = "\033[0m"


def print_test_result(test_name: str, passed: bool, error_msg: str = ""):
    """Print formatted test result"""
    if passed:
        print(f"{GREEN}✓ PASS{RESET}: {test_name}")
    else:
        print(f"{RED}✗ FAIL{RESET}: {test_name}")
        if error_msg:
            print(f"  {YELLOW}Expected error not raised or wrong error message{RESET}")
            print(f"  Got: {error_msg}")


def test_validation():
    """Run all validation tests"""
    print("=" * 70)
    print("TESTING INPUT VALIDATION FOR getMask")
    print("=" * 70)

    total_tests = 0
    passed_tests = 0

    # Test 1: Valid input (should NOT raise error)
    print("\n--- Test 1: Valid Input ---")
    total_tests += 1
    try:
        img = np.random.randint(0, 256, size=(4, 4, 4), dtype=np.uint8)
        result = getMask(img, (3, 3, 3), 0.2)
        print_test_result("Valid input should work", True)
        passed_tests += 1
    except Exception as e:
        print_test_result("Valid input should work", False, str(e))

    # Test 2: Wrong number of dimensions (2D)
    print("\n--- Test 2: 2D Image (should fail) ---")
    total_tests += 1
    try:
        img_2d = np.random.randint(0, 256, size=(4, 4), dtype=np.uint8)
        result = getMask(img_2d, (3, 3, 3), 0.2)
        print_test_result("Should reject 2D image", False, "No error raised")
    except ValueError as e:
        if "3D" in str(e) and "2D" in str(e):
            print_test_result("Should reject 2D image", True)
            passed_tests += 1
        else:
            print_test_result("Should reject 2D image", False, str(e))
    except Exception as e:
        print_test_result("Should reject 2D image", False, f"Wrong exception: {e}")

    # Test 3: Wrong number of dimensions (4D)
    print("\n--- Test 3: 4D Image (should fail) ---")
    total_tests += 1
    try:
        img_4d = np.random.randint(0, 256, size=(5, 4, 4, 4), dtype=np.uint8)
        result = getMask(img_4d, (3, 3, 3), 0.2)
        print_test_result("Should reject 4D image", False, "No error raised")
    except ValueError as e:
        if "3D" in str(e) and "4D" in str(e):
            print_test_result("Should reject 4D image", True)
            passed_tests += 1
        else:
            print_test_result("Should reject 4D image", False, str(e))
    except Exception as e:
        print_test_result("Should reject 4D image", False, f"Wrong exception: {e}")

    # Test 4: Float dtype (should fail)
    print("\n--- Test 4: Float Image (should fail) ---")
    total_tests += 1
    try:
        img_float = np.random.rand(4, 4, 4).astype(np.float32)
        result = getMask(img_float, (3, 3, 3), 0.2)
        print_test_result("Should reject float dtype", False, "No error raised")
    except ValueError as e:
        if "integer" in str(e).lower() and "float" in str(e).lower():
            print_test_result("Should reject float dtype", True)
            passed_tests += 1
        else:
            print_test_result("Should reject float dtype", False, str(e))
    except Exception as e:
        print_test_result("Should reject float dtype", False, f"Wrong exception: {e}")

    # Test 5: Float64 dtype (should fail)
    print("\n--- Test 5: Float64 Image (should fail) ---")
    total_tests += 1
    try:
        img_float64 = np.random.rand(4, 4, 4)
        result = getMask(img_float64, (3, 3, 3), 0.2)
        print_test_result("Should reject float64 dtype", False, "No error raised")
    except ValueError as e:
        if "integer" in str(e).lower():
            print_test_result("Should reject float64 dtype", True)
            passed_tests += 1
        else:
            print_test_result("Should reject float64 dtype", False, str(e))
    except Exception as e:
        print_test_result("Should reject float64 dtype", False, f"Wrong exception: {e}")

    # Test 6: Negative value in window_size
    total_tests += 1
    try:
        img = np.random.randint(0, 256, size=(4, 4, 4), dtype=np.uint8)
        getMask(img, window_size=(3, -3, 3), delta=0.2)
        print_test_result(
            "Negative window_size value should fail", False, "No error raised"
        )
    except ValueError as e:
        if "positive" in str(e).lower():
            print_test_result("Negative window_size value should fail", True)
            passed_tests += 1
        else:
            print_test_result("Negative window_size value should fail", False, str(e))
    except Exception as e:
        print_test_result(
            "Negative window_size value should fail", False, f"Wrong exception: {e}"
        )

    # Test 7: Negative delta
    total_tests += 1
    try:
        img = np.random.randint(0, 256, size=(4, 4, 4), dtype=np.uint8)
        getMask(img, window_size=(3, 3, 3), delta=-0.1)
        print_test_result("Negative delta should fail", False, "No error raised")
    except ValueError as e:
        if "non-negative" in str(e).lower() or "positive" in str(e).lower():
            print_test_result("Negative delta should fail", True)
            passed_tests += 1
        else:
            print_test_result("Negative delta should fail", False, str(e))
    except Exception as e:
        print_test_result("Negative delta should fail", False, f"Wrong exception: {e}")

    # Summary
    print("\n" + "=" * 70)
    print(f"SUMMARY: {passed_tests}/{total_tests} tests passed")
    print("=" * 70)

    if passed_tests == total_tests:
        print(f"{GREEN}All tests passed! ✓{RESET}")
    else:
        print(f"{RED}{total_tests - passed_tests} test(s) failed! ✗{RESET}")

    return passed_tests, total_tests


# ===== MAIN ENTRY POINT =====
if __name__ == "__main__":
    test_validation()
