"""
Core implementation of modified Otsu thresholding.
"""

import numpy as np
from numba import njit, prange
from typing import Tuple


# ============================================================================
# Helper Functions (Internal)
# ============================================================================


@njit
def _padReflect(img: np.ndarray, pad_width: Tuple[int, int, int]) -> np.ndarray:
    """
    Manual reflect padding for 3D arrays (Numba-compatible).

    Parameters
    ----------
    img : np.ndarray
        3D input array
    pad_width : tuple of int
        Padding size for each dimension (z_pad, y_pad, x_pad)

    Returns
    -------
    np.ndarray
        Padded array with reflect mode
    """
    z_pad, y_pad, x_pad = pad_width
    z_max, y_max, x_max = img.shape

    padded = np.zeros(
        (z_max + 2 * z_pad, y_max + 2 * y_pad, x_max + 2 * x_pad), dtype=img.dtype
    )

    # Copy center
    padded[z_pad : z_pad + z_max, y_pad : y_pad + y_max, x_pad : x_pad + x_max] = img

    # Reflect padding for Z
    for i in range(z_pad):
        padded[z_pad - 1 - i, y_pad : y_pad + y_max, x_pad : x_pad + x_max] = img[
            i, :, :
        ]
        padded[z_pad + z_max + i, y_pad : y_pad + y_max, x_pad : x_pad + x_max] = img[
            z_max - 1 - i, :, :
        ]

    # Reflect padding for Y
    for j in range(y_pad):
        padded[:, y_pad - 1 - j, x_pad : x_pad + x_max] = padded[
            :, y_pad + j, x_pad : x_pad + x_max
        ]
        padded[:, y_pad + y_max + j, x_pad : x_pad + x_max] = padded[
            :, y_pad + y_max - 1 - j, x_pad : x_pad + x_max
        ]

    # Reflect padding for X
    for k in range(x_pad):
        padded[:, :, x_pad - 1 - k] = padded[:, :, x_pad + k]
        padded[:, :, x_pad + x_max + k] = padded[:, :, x_pad + x_max - 1 - k]

    return padded


@njit(parallel=True)
def _getMask(
    img: np.ndarray, window_size: Tuple[int, int, int], delta: float
) -> np.ndarray:
    """
    Internal Numba-compiled implementation.
    No validation - assumes inputs are correct.
    """
    z_win, y_win, x_win = window_size
    z_pad, y_pad, x_pad = z_win // 2, y_win // 2, x_win // 2

    padded = _padReflect(img, (z_pad, y_pad, x_pad))
    mask = np.zeros_like(img, dtype=np.int32)
    z_max, y_max, x_max = img.shape

    for z in prange(z_max):
        for y in range(y_max):
            for x in range(x_max):
                window = padded[z : z + z_win, y : y + y_win, x : x + x_win].ravel()
                mask[z, y, x] = getThreshold(window, delta)
    
    return mask, (img > mask)

# ============================================================================
# Public API
# ============================================================================


@njit
def getThreshold(values: np.ndarray, delta: float = 0.2) -> int:
    """
    Compute Otsu threshold for a 1D array of intensity values.

    This implementation assumes integer input values. The algorithm bins values
    by their integer representation and computes the optimal threshold that
    maximizes between-class variance.

    Parameters
    ----------
    values : np.ndarray
        1D array of integer intensity values
    delta : float, default=0.2
        Contrast threshold. If the relative difference between foreground
        and background means is below this threshold, the maximum value + 1
        is returned (indicating insufficient contrast).

    Returns
    -------
    int
        The optimal threshold value, or max(values) + 1 if contrast is too low

    Notes
    -----
    The algorithm:
    1. Creates a histogram of input values
    2. Iterates through possible thresholds
    3. Computes between-class variance for each threshold
    4. Returns the threshold with maximum variance
    5. If contrast is too low (|mB - mF| / mB <= delta), returns max + 1

    Examples
    --------
    >>> values = np.array([10, 10, 10, 20, 20, 30, 30, 30], dtype=np.int32)
    >>> threshold = getThreshold(values, delta=0.2)
    """
    mn = values.min()
    mx = values.max()

    if mx == mn:
        return int(mx)

    binned_values = (values - mn).astype(np.int32)
    hist = np.bincount(binned_values, minlength=mx - mn + 1)
    bin_edges = np.arange(len(hist)) + mn

    total = values.size
    sum_total = np.sum(bin_edges * hist)
    sumB = 0.0
    wB = 0
    maximum = 0.0
    threshold = 0
    best_mB, best_mF = 0.0, 0.0

    for i in range(len(hist)):
        wB += hist[i]
        if wB == 0:
            continue
        wF = total - wB
        if wF == 0:
            break

        sumB += bin_edges[i] * hist[i]
        mB = sumB / wB
        mF = (sum_total - sumB) / wF
        between = wB * wF * (mB - mF) ** 2

        if between > maximum:
            maximum = between
            threshold = bin_edges[i]
            best_mB = mB
            best_mF = mF

    # Force threshold to max if contrast is too low
    if best_mB == 0 or abs(best_mB - best_mF) / best_mB <= delta:
        threshold = mx + 1

    return int(threshold)


def getMask(
    img: np.ndarray,
    window_size: Tuple[int, int, int] = (3, 3, 3),
    delta: float = 0.2
) -> np.ndarray:
    """
    Apply local Otsu thresholding to a 3D grayscale image.

    For each pixel, computes an optimal threshold based on the intensity
    distribution in a local neighborhood window, then either returns the
    threshold values or a binary mask.

    Parameters
    ----------
    img : np.ndarray
        3D input image with integer dtype (e.g., uint8, uint16, int32).
        Shape should be (z, y, x).
    window_size : tuple of int
        Local neighborhood size as (z_size, y_size, x_size).
        Should be positive odd integers for centered windows.
    delta : float, default=0.2
        Contrast parameter for Otsu thresholding. Lower values are more
        permissive, higher values require stronger contrast.

    Returns
    -------
    np.ndarray
        If binarize=True: Binary mask with same shape as input (dtype=uint8)
        If binarize=False: Threshold map with same shape as input (dtype=int32)

    Raises
    ------
    ValueError
        If input validation fails (wrong dimensions, dtype, window_size, etc.)

    Examples
    --------
    >>> import numpy as np
    >>> from modifiedOtsu import getMask
    >>>
    >>> # Create sample 3D grayscale image
    >>> img = np.random.randint(0, 256, size=(50, 50, 50), dtype=np.uint8)
    >>>
    >>> # Get binary mask
    >>> mask = getMask(img, window_size=(5, 5, 5), delta=0.2, binarize=True)
    >>> print(mask.shape, mask.dtype)
    (50, 50, 50) uint8
    >>>
    >>> # Get threshold values
    >>> thresholds = getMask(img, window_size=(5, 5, 5), delta=0.2, binarize=False)
    >>> print(thresholds.shape, thresholds.dtype)
    (50, 50, 50) int32

    Notes
    -----
    - Uses reflect padding at image boundaries
    - Parallelized using Numba for high performance
    - Input must be integer dtype (float images should be converted first)
    """
    # Validation
    if img.ndim != 3:
        raise ValueError(
            f"Expected 3D image, got {img.ndim}D array with shape {img.shape}"
        )

    if not np.issubdtype(img.dtype, np.integer):
        raise ValueError(
            f"Expected integer dtype (e.g., uint8, uint16, int32), got {img.dtype}. "
            f"Convert using img.astype(np.uint8) or similar."
        )

    if not isinstance(window_size, (tuple, list)):
        raise ValueError(
            f"window_size must be a tuple or list, got {type(window_size)}"
        )

    if len(window_size) != 3:
        raise ValueError(
            f"window_size must have 3 elements (z, y, x), got {len(window_size)}"
        )

    if not all(isinstance(w, (int, np.integer)) for w in window_size):
        raise ValueError(f"window_size elements must be integers, got {window_size}")

    if any(w <= 0 for w in window_size):
        raise ValueError(f"window_size elements must be positive, got {window_size}")

    if any(w % 2 == 0 for w in window_size):
        z_win, y_win, x_win = window_size
        raise ValueError(
            f"window_size elements should be odd numbers for centered windows, "
            f"got {window_size}. Consider using "
            f"({z_win+1 if z_win%2==0 else z_win}, "
            f"{y_win+1 if y_win%2==0 else y_win}, "
            f"{x_win+1 if x_win%2==0 else x_win}) instead."
        )

    z_max, y_max, x_max = img.shape
    z_win, y_win, x_win = window_size
    if z_win > z_max or y_win > y_max or x_win > x_max:
        raise ValueError(
            f"window_size {window_size} is larger than image dimensions {img.shape}"
        )

    if not isinstance(delta, (int, float)):
        raise ValueError(f"delta must be a number, got {type(delta)}")

    if delta < 0:
        raise ValueError(f"delta must be non-negative, got {delta}")

    if img.size == 0:
        raise ValueError("Input image is empty")

    # Call Numba implementation
    return _getMask(img, window_size, delta)
