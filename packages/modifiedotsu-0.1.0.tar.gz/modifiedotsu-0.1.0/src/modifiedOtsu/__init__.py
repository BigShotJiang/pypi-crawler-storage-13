"""
Local 2D Otsu Thresholding for 3D Images
==========================================

A high-performance implementation of local 2D Otsu thresholding for 3D grayscale images
using Numba acceleration.

Main Functions
--------------
getBinary : Apply local Otsu thresholding to get binary mask or thresholds
getThreshold : Compute Otsu threshold for 1D intensity values

Example
-------
>>> import numpy as np
>>> from modifiedOtsu import getMask
>>> 
>>> # Create sample 3D image
>>> img = np.random.randint(0, 256, size=(50, 50, 50), dtype=np.uint8)
>>> 
>>> # Get threshold mask and binary image
>>> threshold, binary = getMask(img, window_size=(3, 3, 3), delta=0.2)
"""

from .core import getMask, getThreshold

# Package metadata
__version__ = "0.1.0"
__author__ = "John Rick Manzanares"
__email__ = "jdolormanzanares@impan.pl"

# Define what gets imported with "from modifiedOtsu import *"
__all__ = [
    "getBinary",
    "getThreshold",
]

# Optional: Add convenience functions or constants
DEFAULT_WINDOW_SIZE = (3, 3, 3)
