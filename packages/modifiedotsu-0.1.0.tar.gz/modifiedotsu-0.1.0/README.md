# 🧠 Local Modified Otsu Thresholding

**Local Modified Otsu Thresholding** is a **Numba-accelerated** implementation of a *local, contrast-adaptive* Otsu thresholding method for 3D images.

This algorithm adapts the Otsu threshold within a sliding 3D window, enabling robust segmentation in datasets with spatially varying intensity distributions.

The method is inspired by the segmentation approach described in **Subsection 2.2.2** of the article:

> *Segmentation-based tracking of macrophages in 2D + time microscopy movies inside a living animal*
> 
> *Computers in Biology and Medicine, 153 (2023), 106499*
> 
> [https://doi.org/10.1016/j.compbiomed.2022.106499](https://doi.org/10.1016/j.compbiomed.2022.106499)

If you use this implementation in your research, please cite the original work that inspired this algorithm.

---

## ⚙️ Installation

Install the latest stable version from PyPI:

```bash
pip install modifiedOtsu
```

## 🚀 Example Usage

```python
import numpy as np
from modifiedOtsu import getMask

# Create sample 3D image
img = np.random.randint(0, 256, size=(10, 10, 10), dtype=np.uint8)

# Get threshold map and binary image
threshold, binary = getMask(img, window_size=(3, 3, 3), delta=0.2)
```

## 🖥️ Command Line Usage

You can execute the script with custom parameters:

```bash
python runner.py --shape 10 10 10 --window 3 3 3 --delta 0.2
```

## 📦 Dependencies

- NumPy
- Numba
- Matplotlib

Install dependencies with:

```bash
pip install numpy numba matplotlib
```

## 📜 License

This project is licensed under the MIT License. See the LICENSE file for details.

## 🤝 Contributing

Contributions are welcome! If you'd like to fix a bug, add a feature, or improve performance, please open a pull request or contact the maintainers.

## 💬 Contact

For questions, issues, or feedback, open an issue on GitHub.
