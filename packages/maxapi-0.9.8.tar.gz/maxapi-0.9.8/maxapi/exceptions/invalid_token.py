

class InvalidToken(Exception):
    ...