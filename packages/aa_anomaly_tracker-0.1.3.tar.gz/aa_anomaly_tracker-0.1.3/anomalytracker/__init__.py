"""Initialize the app"""

__version__ = "0.1.3"
__title__ = "anomalytracker"
