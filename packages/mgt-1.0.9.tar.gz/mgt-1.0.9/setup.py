from setuptools import setup, find_packages

setup(
    name='mgt',
    version='1.0.9',
    author='OPENSAPI',
    packages=find_packages(),
    install_requires=[
        'sapiens-file-interpreter',
        'utilities-nlp',
        'scn',
        'semantic-comparison-network',
        'perpetual-context',
        'sapiens-transformers',
        'INFINITE-CONTEXT-WINDOW'
    ],
    url='https://github.com/sapiens-technology/mgt',
    license='Proprietary Software'
)
