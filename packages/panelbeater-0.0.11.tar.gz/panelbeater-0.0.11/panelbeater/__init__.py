"""panelbeater initialisation."""

__VERSION__ = "0.0.11"
