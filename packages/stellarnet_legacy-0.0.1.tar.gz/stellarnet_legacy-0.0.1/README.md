# StellarNet Legacy
Python bindings for legacy StellarNet spectrometers.

## Installation

```console
pip install stellarnet-legacy
```

## Resources
`stellarnet_api.dll` and `stellarnet_api_server.exe` must be in the `src/stellarnet_legacy\data` folder.