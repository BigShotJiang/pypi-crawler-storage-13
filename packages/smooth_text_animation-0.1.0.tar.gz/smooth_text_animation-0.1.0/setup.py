"""
Setup file for smooth-text-animation package
"""

from setuptools import setup, find_packages

# Read long description from README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="smooth-text-animation",
    version="0.1.0",
    author="traitimtrongvag",
    author_email="tbinh831@gmail.com",
    description="Beautiful and smooth text animations for terminal output",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/traitimtrongvag/smooth-text-animation",
    project_urls={
        "Bug Tracker": "https://github.com/traitimtrongvag/smooth-text-animation/issues",
        "Documentation": "https://github.com/traitimtrongvag/smooth-text-animation",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Terminals",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    keywords="animation, terminal, text, cli, console, effect",
    install_requires=[
        # Không có dependencies bổ sung
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=3.0",
            "black>=22.0",
            "flake8>=4.0",
        ],
    },
)