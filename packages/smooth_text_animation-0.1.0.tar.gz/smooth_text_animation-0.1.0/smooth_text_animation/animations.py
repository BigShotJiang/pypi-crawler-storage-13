
# smooth-text-animation/smooth_text_animation/animations.py
"""
Main animation functions for text effects
"""

import sys
import time
import random


def animated_line(text, delay=0.05):
    """
    Animation hiệu ứng gõ chữ từ trái sang phải
    
    Args:
        text (str): Văn bản cần hiển thị
        delay (float): Độ trễ giữa mỗi ký tự (giây)
    """
    for i in range(len(text) + 1):
        sys.stdout.write("\r" + text[:i])
        sys.stdout.flush()
        time.sleep(delay)
    print()


def animated_line_dual(text, delay=0.1):
    """
    Animation xuất hiện từ cả 2 phía vào giữa
    
    Args:
        text (str): Văn bản cần hiển thị
        delay (float): Độ trễ giữa mỗi bước (giây)
    """
    length = len(text)
    for i in range(length // 2 + 1):
        left_part = text[:i]
        right_part = text[length - i:]
        sys.stdout.write("\r" + left_part + " " * (length - len(left_part) - len(right_part)) + right_part)
        sys.stdout.flush()
        time.sleep(delay)
    print()


def fade_in_text(text, delay=0.2):
    """
    Hiệu ứng chữ đậm dần từ mờ đến rõ
    
    Args:
        text (str): Văn bản cần hiển thị
        delay (float): Độ trễ giữa các mức sáng (giây)
    """
    brightness_levels = [90, 37, 97]
    
    for level in brightness_levels:
        sys.stdout.write(f"\033[{level}m{text}\033[0m\r")
        sys.stdout.flush()
        time.sleep(delay)
    print(text)


def marquee_text(text, width=30, delay=0.1):
    """
    Hiệu ứng chữ chạy từ phải sang trái
    
    Args:
        text (str): Văn bản cần hiển thị
        width (int): Độ rộng màn hình hiển thị
        delay (float): Độ trễ giữa mỗi bước (giây)
    """
    padded_text = " " * width + text + " " * width
    for i in range(len(padded_text) - width + 1):
        sys.stdout.write("\r" + padded_text[i:i+width])
        sys.stdout.flush()
        time.sleep(delay)
    print()


def wave_text(text, delay=0.1, repeat=3):
    """
    Hiệu ứng Loading với dấu chấm
    
    Args:
        text (str): Văn bản cần hiển thị
        delay (float): Độ trễ giữa mỗi bước (giây)
        repeat (int): Số lần lặp lại hiệu ứng
    """
    wave = ["", ".", "..", "..."]
    for _ in range(repeat):
        for w in wave:
            sys.stdout.write("\r" + text + w + " " * (3 - len(w)))
            sys.stdout.flush()
            time.sleep(delay)
    print()


def blinking_text(text, repeat=5, delay=0.3):
    """
    Hiệu ứng nhấp nháy cảnh báo
    
    Args:
        text (str): Văn bản cần hiển thị
        repeat (int): Số lần nhấp nháy
        delay (float): Độ trễ giữa mỗi lần nhấp nháy (giây)
    """
    for _ in range(repeat):
        sys.stdout.write("\r" + text)
        sys.stdout.flush()
        time.sleep(delay)
        sys.stdout.write("\r" + " " * len(text))
        sys.stdout.flush()
        time.sleep(delay)
    print(text)


def random_fill(text, delay=0.1):
    """
    Chữ xuất hiện ngẫu nhiên từng ký tự
    
    Args:
        text (str): Văn bản cần hiển thị
        delay (float): Độ trễ giữa mỗi ký tự (giây)
    """
    result = [" "] * len(text)
    indices = list(range(len(text)))
    while indices:
        idx = random.choice(indices)
        result[idx] = text[idx]
        sys.stdout.write("\r" + "".join(result))
        sys.stdout.flush()
        indices.remove(idx)
        time.sleep(delay)
    print()


def reverse_text(text, delay=0.2):
    """
    Chữ xuất hiện từ phải sang trái
    
    Args:
        text (str): Văn bản cần hiển thị
        delay (float): Độ trễ giữa mỗi ký tự (giây)
    """
    reversed_text = text[::-1]
    for i in range(len(text) + 1):
        sys.stdout.write("\r" + reversed_text[:i][::-1])
        sys.stdout.flush()
        time.sleep(delay)
    print()


def rotate_text(text, delay=0.2, cycles=10):
    """
    Hiệu ứng loading với ký tự xoay | / - \\
    
    Args:
        text (str): Văn bản cần hiển thị
        delay (float): Độ trễ giữa mỗi ký tự (giây)
        cycles (int): Số lần lặp lại hiệu ứng
    """
    rotations = ["|", "/", "-", "\\"]
    for _ in range(cycles):
        for rot in rotations:
            sys.stdout.write(f"\r{rot} {text}")
            sys.stdout.flush()
            time.sleep(delay)
    print()


def _animated_fade_dual(text, delay=0.1):
    """
    Hiệu ứng xuất hiện từ hai đầu vào giữa với fade-in
    """
    length = len(text)
    brightness_levels = [90, 37, 97]
    num_brightness_levels = len(brightness_levels)

    for i in range(length // 2 + 1):
        brightness = brightness_levels[min(i, num_brightness_levels - 1)]
        left_part = text[:i]
        right_part = text[length - i:]
        
        sys.stdout.write("\r\033[K")
        sys.stdout.write(
            f"\033[{brightness}m" + left_part + " " * (length - len(left_part) - len(right_part)) + right_part + "\033[0m"
        )
        sys.stdout.flush()
        time.sleep(delay)


def _fade_out_dual(text, delay=0.1):
    """
    Hiệu ứng biến mất từ giữa ra hai đầu
    """
    length = len(text)
    for i in range(length // 2 + 1):
        left_part = text[:length // 2 - i]
        right_part = text[length // 2 + i:]
        
        sys.stdout.write("\r\033[K")
        sys.stdout.write(
            left_part + " " * (length - len(left_part) - len(right_part)) + right_part
        )
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write("\r\033[K")
    sys.stdout.flush()


def combined_animation_simultaneous(text, delay=0.1, pause=0.5):
    """
    Kết hợp xuất hiện và biến mất (2 phía)
    
    Args:
        text (str): Văn bản cần hiển thị
        delay (float): Độ trễ giữa mỗi bước (giây)
        pause (float): Thời gian dừng giữa fade-in và fade-out (giây)
    """
    _animated_fade_dual(text, delay=delay)
    time.sleep(pause)
    _fade_out_dual(text, delay=delay)