"""Core API key gateway logic for validation and caching"""

import argparse
import urllib.request
import urllib.error
import json
import os
import time
from functools import wraps
from argon2 import PasswordHasher
from argon2.exceptions import HashingError


class APIKeyGateway:
    """Core API key gateway logic for validation and caching"""

    def __init__(self):
        self.PH = PasswordHasher(
            memory_cost=65536,
            time_cost=3,
            parallelism=4,
            hash_len=32,
            salt_len=16
        )

        # Cache to store valid API key-service pairs
        # Format: {(secret_key, service): expiration_time}
        self.API_KEY_CACHE = {}

        # Cache to store failed API key-service pairs (forever cache)
        # Format: {(secret_key, service): error_message}
        self.API_KEY_FAILURE_CACHE = {}

        # Cache to store JSONBin response (valid public keys) indefinitely
        # until cleared by a timer started on successful login
        self.JSONBIN_CACHE = None
        self.JSONBIN_CACHE_EXPIRY = None  # None means never expires

        # Cache TTL: 1 day (86400 seconds)
        self.CACHE_TTL_SECONDS = 86400

        # Default URL using JSONBin.io
        self.DEFAULT_URL = "https://api.jsonbin.io/v3/b/691ec6a543b1c97be9b8ea6d"

    @staticmethod
    def retry_on_exception(exceptions, max_retries=3, delay=0.5, backoff=1):
        """
        Decorator that retries a function on specific exceptions.
        """
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                verbose = kwargs.get('verbose', True)
                func_kwargs = {k: v for k, v in kwargs.items() if k != 'verbose'}
                retries = 0
                while retries <= max_retries:
                    try:
                        return func(*args, **func_kwargs)
                    except exceptions as e:
                        retries += 1
                        if retries > max_retries:
                            if verbose:
                                print(f"   All {max_retries} retry attempts failed. Exception: {e}")
                            raise
                        wait_time = delay * (backoff ** (retries - 1))
                        if verbose:
                            print(f"   Retry {retries}/{max_retries} in {wait_time:.2f} seconds due to: {type(e).__name__}: {e}")
                        time.sleep(wait_time)
                return None  # This line should never be reached
            return wrapper
        return decorator

    @retry_on_exception(
        urllib.error.URLError,
        max_retries=3,
        delay=0.5,
        backoff=1  # constant delay, not exponential
    )
    def fetch_valid_public_keys(self, url, verbose=True, jsonbin_api_key=None):
        """Fetch the list of valid public keys from the specified URL."""
        # Check if JSONBin cache is valid
        current_time = time.time()
        if self.JSONBIN_CACHE is not None and (self.JSONBIN_CACHE_EXPIRY is None or current_time < self.JSONBIN_CACHE_EXPIRY):
            if verbose:
                print("   Using cached public keys from JSONBin response")
            return self.JSONBIN_CACHE

        try:
            # Set proper headers for JSONBin.io API
            headers = {
                'accept': 'application/json',
            }

            # Add JSONBin API key if available (parameter takes precedence over env var)
            jsonbin_api_key = jsonbin_api_key or os.environ.get('JSONBIN_API_KEY')
            if jsonbin_api_key:
                headers['X-Access-Key'] = jsonbin_api_key

            # Create a request object with the headers
            req = urllib.request.Request(url, headers=headers)

            # Set timeout to avoid hanging (10 seconds)
            with urllib.request.urlopen(req, timeout=10) as response:
                data = json.loads(response.read().decode('utf-8'))

            # JSONBin API wraps the data in a 'record' field
            if isinstance(data, dict) and 'record' in data:
                data = data['record']
                all_keys = []

                # Expected structure: {service: {key_id: public_key, ...}}
                for service_name, service_data in data.items():
                    if isinstance(service_data, dict):
                        # Service has multiple API keys
                        for key_id, public_key in service_data.items():
                            all_keys.append({
                                "service": service_name,
                                "public_key": public_key
                            })
                    else:
                        # Service has a single API key
                        all_keys.append({
                            "service": service_name,
                            "public_key": service_data
                        })

                # Cache the JSONBin response indefinitely
                self.JSONBIN_CACHE = all_keys
                self.JSONBIN_CACHE_EXPIRY = None  # None means never expires

                return all_keys
            raise RuntimeError(f"Unexpected response structure from JSONBin API: {data}")
        except urllib.error.HTTPError as e:
            if e.code == 401:
                # 401 Unauthorized typically means missing or invalid API key
                jsonbin_api_key = os.environ.get('JSONBIN_API_KEY')
                if not jsonbin_api_key:
                    raise RuntimeError("Failed to fetch valid public keys from jsonbin.io: JSONBIN_API_KEY environment variable is missing")
                else:
                    raise RuntimeError(f"Failed to fetch valid public keys from jsonbin.io: Invalid API key provided (HTTP 401). Check your JSONBIN_API_KEY environment variable.")
            raise RuntimeError(f"Failed to fetch valid public keys from jsonbin.io: HTTP {e.code} error - {e.reason}")
        except urllib.error.URLError:
            # Re-raise URLError so the retry decorator can handle it
            raise
        except Exception as e:
            # Wrap all other exceptions in RuntimeError
            raise RuntimeError(f"Failed to fetch valid public keys: {e}")

    def compute_public_key(self, secret_key):
        """Compute the public key from the secret key using argon2id."""
        try:
            return self.PH.hash(secret_key)
        except HashingError as e:
            raise RuntimeError(f"Failed to compute public key: {e}")

    def validate_api_key(self, secret_key, service, public_keys_url=None, verbose=True, jsonbin_api_key=None):
        """Validate an API key for a specific service"""
        # Cache key for this secret-key service pair
        cache_key = (secret_key, service)

        # Check failure cache first (forever cache)
        if cache_key in self.API_KEY_FAILURE_CACHE:
            raise PermissionError(self.API_KEY_FAILURE_CACHE[cache_key])

        # Check success cache next (TTL based)
        current_time = time.time()
        if cache_key in self.API_KEY_CACHE:
            expiration_time = self.API_KEY_CACHE[cache_key]
            if current_time < expiration_time:
                # Cache hit: key-service pair is still valid
                if verbose:
                    print(f"✓ API key validation passed (cached until {time.ctime(expiration_time)})")
                return True

        # Cache miss or expired: proceed with validation
        # Fast fail validations first
        if not secret_key:
            error_msg = "API key validation failed: API key cannot be empty"
            self.API_KEY_FAILURE_CACHE[cache_key] = error_msg
            raise PermissionError(error_msg)

        # Check if secret key has correct length
        expected_length = 43  # Based on test secret key: LVYYllZk6xLIRoGVfGK9A78Dl1ehJbZOpRo6JoF2LAM
        if len(secret_key) != expected_length:
            error_msg = f"API key validation failed: API key must be {expected_length} characters long"
            self.API_KEY_FAILURE_CACHE[cache_key] = error_msg
            raise PermissionError(error_msg)

        # Cache miss or expired: proceed with full validation
        if verbose:
            print(f"⟳ Checking API key validity for service '{service}'...")

        # Fetch valid public keys
        url = public_keys_url or self.DEFAULT_URL
        if verbose:
            print("   Checking public keys from remote server...")

        all_valid_keys = self.fetch_valid_public_keys(url, verbose=verbose, jsonbin_api_key=jsonbin_api_key)

        # Filter keys by the specified service
        valid_public_keys = [key['public_key'] for key in all_valid_keys if key['service'] == service]

        # Check if service exists
        if not valid_public_keys:
            # Check if the service name exists in the fetched keys
            available_services = set(key['service'] for key in all_valid_keys)
            if service not in available_services:
                # Find similar service names to suggest
                def levenshtein_distance(s1, s2):
                    """Compute the Levenshtein distance between two strings"""
                    if len(s1) < len(s2):
                        return levenshtein_distance(s2, s1)
                    if len(s2) == 0:
                        return len(s1)

                    previous_row = range(len(s2) + 1)
                    for i, c1 in enumerate(s1):
                        current_row = [i + 1]
                        for j, c2 in enumerate(s2):
                            insertions = previous_row[j + 1] + 1
                            deletions = current_row[j] + 1
                            substitutions = previous_row[j] + (0 if c1 == c2 else 1)
                            current_row.append(min(insertions, deletions, substitutions))
                        previous_row = current_row
                    return previous_row[-1]

                # Suggest services with Levenshtein distance <= 2
                similar_services = sorted(
                    [s for s in available_services if levenshtein_distance(service.lower(), s.lower()) <= 2],
                    key=lambda s: levenshtein_distance(service.lower(), s.lower())
                )

                if similar_services:
                    error_msg = f"API key validation failed: Service '{service}' does not exist. Did you mean: {', '.join(similar_services)}?"
                    self.API_KEY_FAILURE_CACHE[cache_key] = error_msg
                    raise PermissionError(error_msg)
                else:
                    error_msg = f"API key validation failed: Service '{service}' does not exist."
                    self.API_KEY_FAILURE_CACHE[cache_key] = error_msg
                    raise PermissionError(error_msg)

        # Compute public key from secret key
        try:
            computed_public_key = self.compute_public_key(secret_key)
        except RuntimeError as e:
            raise RuntimeError(f"API key validation failed: {e}")

        # Check if any of the valid public keys match the secret key
        valid = False
        for public_key in valid_public_keys:
            try:
                if self.PH.verify(public_key, secret_key):
                    valid = True
                    break
            except Exception:
                # If verification fails for any reason, try next one
                continue

        if not valid:
            error_msg = "API key validation failed: API key is not correct for the specified service. Please apply for a valid API key from yanru@cyanru.com"
            self.API_KEY_FAILURE_CACHE[cache_key] = error_msg
            raise PermissionError(error_msg)

        # Update cache with valid key-service pair
        self.API_KEY_CACHE[cache_key] = current_time + self.CACHE_TTL_SECONDS
        expiration_time = self.API_KEY_CACHE[cache_key]

        # Start timer for JSONBin cache - will expire after CACHE_TTL_SECONDS
        if verbose:
            print(f"   Starting timer for JSONBin cache renewal")
        self.JSONBIN_CACHE_EXPIRY = current_time + self.CACHE_TTL_SECONDS

        if verbose:
            print(f"✓ API key validation passed for service '{service}'")
            print(f"   Caching result until {time.ctime(expiration_time)}")

        return True


# Create singleton instance
gateway = APIKeyGateway()
