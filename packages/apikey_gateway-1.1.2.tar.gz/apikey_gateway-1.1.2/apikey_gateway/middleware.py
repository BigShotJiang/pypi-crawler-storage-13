"""FastAPI middleware for API key gateway validation"""

# Try to import FastAPI types for middleware (optional dependency)
try:
    from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
    from starlette.requests import Request
    from starlette.responses import Response, JSONResponse
    from fastapi import FastAPI
    FASTAPI_AVAILABLE = True
except ImportError:
    # If FastAPI is not installed, middleware-related functionality will be disabled
    FASTAPI_AVAILABLE = False
    # Create mock classes for type hinting
    class Request:
        pass

    class Response:
        pass

    class JSONResponse:
        pass

    class BaseHTTPMiddleware:
        pass

    class RequestResponseEndpoint:
        pass

    class FastAPI:
        pass


class APIKeyGatewayMiddleware(BaseHTTPMiddleware):
    """
    FastAPI middleware for API key gateway validation.

    Best practice:
    - Validates API keys for all incoming requests to protected routes
    - Extracts API key from configurable headers (default: X-API-Key, Authorization Bearer)
    - Supports service-specific validation
    - Handles proper error responses with appropriate status codes
    """

    def __init__(
        self,
        app: FastAPI,
        service: str,
        public_keys_url: str | None = None,
        api_key_headers: list[str] | None = None,
        jsonbin_api_key_header: str | None = None,
        verbose: bool = True
    ):
        """
        Initialize the API key gateway middleware.

        :param app: FastAPI app instance
        :param service: Service name to validate against (required)
        :param public_keys_url: Custom URL for public keys (defaults to gateway's DEFAULT_URL)
        :param api_key_headers: List of headers to check for API key (default: X-AKGATEWAY-API-KEY, Authorization Bearer)
        :param jsonbin_api_key_header: Header name to check for JSONBin API key (default: X-JSONBIN-API-KEY)
        :param verbose: Verbose logging
        """
        super().__init__(app)
        from .gateway import gateway
        self.service = service
        self.public_keys_url = public_keys_url
        self.api_key_headers = api_key_headers or [
            "x-akgateway-api-key",
            "authorization"  # for Bearer token format
        ]
        self.jsonbin_api_key_header = jsonbin_api_key_header or "x-jsonbin-api-key"
        self.verbose = verbose
        self.gateway_instance = gateway


    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        """
        Middleware dispatch method that handles API key validation.
        """
        # Extract API key from configured headers
        headers = request.headers

        # Extract secret API key
        secret_key = None
        for header_name in self.api_key_headers:
            header_value = headers.get(header_name)
            if header_value:
                if header_name.lower() == "authorization":
                    # Handle Bearer token format
                    if header_value.lower().startswith("bearer "):
                        secret_key = header_value[7:].strip()
                        break
                else:
                    # Handle direct header value
                    secret_key = header_value.strip()
                    break

        # Extract JSONBin API key from header if present
        jsonbin_api_key = headers.get(self.jsonbin_api_key_header)

        try:
            # Validate the API key using the gateway instance
            if secret_key:
                self.gateway_instance.validate_api_key(
                    secret_key=secret_key,
                    service=self.service,
                    public_keys_url=self.public_keys_url,
                    verbose=self.verbose,
                    jsonbin_api_key=jsonbin_api_key
                )
            else:
                # No API key found in headers
                raise PermissionError("API key validation failed: No API key found in request headers")

            # If validation passes, call the next endpoint
            response = await call_next(request)
            return response

        except (PermissionError, RuntimeError) as e:
            # Return appropriate error response
            return JSONResponse(
                status_code=401 if isinstance(e, PermissionError) else 500,
                content={"error": str(e)}
            )
