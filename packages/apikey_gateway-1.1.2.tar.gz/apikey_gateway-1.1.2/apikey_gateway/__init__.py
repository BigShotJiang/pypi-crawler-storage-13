"""API Key Gateway - Professional API key validation library"""

# Public API exports
from .gateway import APIKeyGateway, gateway
from .decorators import apikey_login
from .helpers import (
    add_apikey_gateway_middleware,
    retry_on_exception,
    fetch_valid_public_keys,
    compute_public_key,
    validate_api_key,
    CACHE_TTL_SECONDS,
    API_KEY_CACHE,
    PH
)

# Middleware-related exports
try:
    from .middleware import APIKeyGatewayMiddleware, FASTAPI_AVAILABLE
    __all__ = [
        'APIKeyGateway',
        'gateway',
        'apikey_login',
        'add_apikey_gateway_middleware',
        'APIKeyGatewayMiddleware',
        'FASTAPI_AVAILABLE',
        'retry_on_exception',
        'fetch_valid_public_keys',
        'compute_public_key',
        'validate_api_key',
        'CACHE_TTL_SECONDS',
        'API_KEY_CACHE',
        'PH'
    ]
except ImportError:
    __all__ = [
        'APIKeyGateway',
        'gateway',
        'apikey_login',
        'add_apikey_gateway_middleware',
        'retry_on_exception',
        'fetch_valid_public_keys',
        'compute_public_key',
        'validate_api_key',
        'CACHE_TTL_SECONDS',
        'API_KEY_CACHE',
        'PH'
    ]
