"""Helper functions for the API key gateway"""

from .gateway import gateway


# Expose some constants and helper functions for backward compatibility
CACHE_TTL_SECONDS = gateway.CACHE_TTL_SECONDS
API_KEY_CACHE = gateway.API_KEY_CACHE
PH = gateway.PH


def retry_on_exception(exceptions, max_retries=3, delay=0.5, backoff=1):
    """
    Decorator that retries a function on specific exceptions.

    :param exceptions: Tuple of exceptions to retry on
    :param max_retries: Maximum number of retries (default: 3)
    :param delay: Initial delay between retries in seconds (default: 0.5)
    :param backoff: Factor by which delay increases each retry (default: 1 for constant delay)
    """
    from .gateway import APIKeyGateway
    return APIKeyGateway.retry_on_exception(exceptions, max_retries, delay, backoff)


def fetch_valid_public_keys(url, verbose=True):
    """Fetch the list of valid public keys from the specified URL."""
    return gateway.fetch_valid_public_keys(url, verbose=verbose)


def compute_public_key(secret_key):
    """Compute the public key from the secret key using argon2id."""
    return gateway.compute_public_key(secret_key)


def validate_api_key(secret_key, service, public_keys_url=None, verbose=True, jsonbin_api_key=None):
    """Validate an API key for a specific service"""
    return gateway.validate_api_key(secret_key, service, public_keys_url=public_keys_url, verbose=verbose, jsonbin_api_key=jsonbin_api_key)


def add_apikey_gateway_middleware(
    app,
    service: str,
    public_keys_url: str | None = None,
    api_key_headers: list[str] | None = None,
    jsonbin_api_key_header: str | None = None,
    verbose: bool = True
):
    """
    Convenience function to add APIKeyGatewayMiddleware to a FastAPI app.

    :param app: FastAPI app instance
    :param service: Service name to validate against
    :param public_keys_url: Custom URL for public keys
    :param api_key_headers: List of headers to check for API key
    :param jsonbin_api_key_header: Header name to check for JSONBin API key (default: X-JSONBIN-API-KEY)
    :param verbose: Verbose logging
    """
    from .middleware import APIKeyGatewayMiddleware, FASTAPI_AVAILABLE

    if not FASTAPI_AVAILABLE:
        raise RuntimeError("FastAPI is not installed. Please install it with 'pip install fastapi'.")

    # Add middleware directly to the app
    app.add_middleware(
        APIKeyGatewayMiddleware,
        service=service,
        public_keys_url=public_keys_url,
        api_key_headers=api_key_headers,
        jsonbin_api_key_header=jsonbin_api_key_header,
        verbose=verbose
    )
