"""Decorators for API key validation"""

import argparse
import sys
import os


def apikey_login(func=None, *, public_keys_url=None, service=None, verbose=True):
    """
    Decorator that adds API key validation to a function.

    :param func: The function to decorate (required if using as decorator without params)
    :param public_keys_url: Optional URL to fetch valid public keys from (defaults to the official URL)
    :param service: The service name to validate the API key against (required)
    :param verbose: Whether to print verbose messages (default: True)
    """
    # Check if service parameter is provided
    if func is None:
        # If we're in the parameterized decorator mode, we'll check service later
        pass
    elif service is None:
        raise ValueError("service parameter is required for apikey_login decorator")

    # Handle both decorator with and without parameters
    if func is None:
        # Return a new decorator with the provided parameters
        return lambda f: apikey_login(f, public_keys_url=public_keys_url, service=service, verbose=verbose)

    def wrapper(*args, **kwargs):
        # Create argument parser
        parser = argparse.ArgumentParser(add_help=False)  # Don't add help to avoid conflict
        parser.add_argument(
            '-a', '--apikey',
            required=False,
            help='Your API secret key (fallbacks to AKGATEWAY_API_KEY env var)'
        )

        # Save original argv to restore later
        original_argv = sys.argv.copy()

        # Parse only API key arguments
        args_parsed, remaining_args = parser.parse_known_args()

        # Get API key from command line or environment variable
        secret_key = args_parsed.apikey or os.environ.get('AKGATEWAY_API_KEY')

        # If no API key provided, raise an error
        if not secret_key:
            parser.error('API key is required. Use -a/--apikey or set AKGATEWAY_API_KEY environment variable')

        # Replace sys.argv with remaining args (excluding API key) for the wrapped function
        sys.argv = [sys.argv[0]] + remaining_args

        try:
            # Use the gateway singleton to validate the API key
            from .gateway import gateway
            gateway.validate_api_key(secret_key, service, public_keys_url=public_keys_url, verbose=verbose)

            # If validation passes, call the decorated function
            return func(*args, **kwargs)
        finally:
            # Always restore original argv
            sys.argv = original_argv

    return wrapper
