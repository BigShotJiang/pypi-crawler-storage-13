"""Minimal setup.py for compatibility"""
from setuptools import setup, find_packages

setup(
    packages=find_packages(),
)

