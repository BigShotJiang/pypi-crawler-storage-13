import os
import sys
import json
import time
from unittest.mock import patch, MagicMock, mock_open

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import pytest
from apikey_gateway.gateway import APIKeyGateway


@patch('urllib.request.urlopen')
def test_fetch_valid_public_keys_jsonbin(mock_urlopen):
    """Test fetching public keys from JSONBin"""
    test_public_key = """argon2id$v=19$m=65536,t=3,p=4$test_salt$test_hash"""

    # Create mock response
    mock_response = MagicMock()
    mock_response.read.return_value = json.dumps({
        'record': {'test_service': {'test_key_id': test_public_key}}
    }).encode('utf-8')
    mock_urlopen.return_value.__enter__.return_value = mock_response

    gateway = APIKeyGateway()

    # Call fetch_valid_public_keys with a custom URL
    test_url = 'https://api.jsonbin.io/v3/b/12345'

    with patch.dict(os.environ, {'JSONBIN_API_KEY': 'test_api_key'}):
        # Call fetch_valid_public_keys and verify the result
        public_keys = gateway.fetch_valid_public_keys(test_url, verbose=False)
        assert 'test_service' in {key['service'] for key in public_keys}

        # Verify the key is properly parsed
        assert any(
            key['service'] == 'test_service' and key['public_key'] == test_public_key
            for key in public_keys
        )


@patch('urllib.request.urlopen')
def test_cache_usage(mock_urlopen):
    """Test that cache is used effectively"""
    test_secret_key = "LVYYllZk6xLIRoGVfGK9A78Dl1ehJbZOpRo6JoF2LAM"

    # Create gateway instance first to compute real public key
    gateway = APIKeyGateway()

    # Compute real public key
    test_public_key = gateway.compute_public_key(test_secret_key)

    # Create mock response
    mock_response = MagicMock()
    mock_response.read.return_value = json.dumps({
        'record': {'test_service': {'test_key_id': test_public_key}}
    }).encode('utf-8')
    mock_urlopen.return_value.__enter__.return_value = mock_response

    # Update cache TTL for this test (short time)
    gateway.CACHE_TTL_SECONDS = 100

    # Test URL
    test_url = 'https://api.jsonbin.io/v3/b/12345'

    # First call to validate_api_key should fetch from API
    result1 = gateway.validate_api_key(test_secret_key, 'test_service', public_keys_url=test_url, verbose=False)

    # Second call with the same key and service should use cache (mock won't be called again)
    result2 = gateway.validate_api_key(test_secret_key, 'test_service', public_keys_url=test_url, verbose=False)

    # Verify both calls returned True
    assert result1 == True
    assert result2 == True

    # Verify mock was called only once (cache hit on second call)
    assert mock_urlopen.call_count == 1


@patch('urllib.request.urlopen')
def test_cache_expiry(mock_urlopen):
    """Test that cache expires after TTL"""
    test_secret_key = "LVYYllZk6xLIRoGVfGK9A78Dl1ehJbZOpRo6JoF2LAM"

    # Create gateway instance first to compute real public key
    gateway = APIKeyGateway()

    # Compute real public key
    test_public_key = gateway.compute_public_key(test_secret_key)

    # Create mock response
    mock_response = MagicMock()
    mock_response.read.return_value = json.dumps({
        'record': {'test_service': {'test_key_id': test_public_key}}
    }).encode('utf-8')
    mock_urlopen.return_value.__enter__.return_value = mock_response

    # Set very short cache TTL for this test
    gateway.CACHE_TTL_SECONDS = 1  # 1 second

    # Test URL
    test_url = 'https://api.jsonbin.io/v3/b/12345'

    # First call to validate_api_key should fetch from API
    result1 = gateway.validate_api_key(test_secret_key, 'test_service', public_keys_url=test_url, verbose=False)
    assert result1 == True
    call_count_after_first = mock_urlopen.call_count

    # Wait for cache to expire
    time.sleep(1.1)

    # Second call should fetch from API again since cache has expired
    result2 = gateway.validate_api_key(test_secret_key, 'test_service', public_keys_url=test_url, verbose=False)
    assert result2 == True
    call_count_after_second = mock_urlopen.call_count

    # Verify mock was called twice (cache expired, new fetch)
    assert call_count_after_second == call_count_after_first + 1


def test_verbosity_output(capsys):
    """Test that verbose mode produces expected output"""
    test_secret_key = "LVYYllZk6xLIRoGVfGK9A78Dl1ehJbZOpRo6JoF2LAM"

    # Create gateway instance
    gateway = APIKeyGateway()

    # Clear cache TTL and URL to skip real API calls for this test
    # We'll mock the fetch_valid_public_keys directly
    gateway.CACHE_TTL_SECONDS = 100

    # Mock fetch_valid_public_keys to return an empty list
    with patch.object(gateway, 'fetch_valid_public_keys') as mock_fetch:
        mock_fetch.return_value = []

        try:
            gateway.validate_api_key(test_secret_key, 'test_service', verbose=True)
        except PermissionError:
            pass  # Expected since fetch returns empty list

        # Capture the output
        captured = capsys.readouterr()

        # Verify verbose output contains expected messages
        assert "Checking API key validity" in captured.out
        assert "Checking public keys from remote server" in captured.out


def test_non_verbose_output(capsys):
    """Test that non-verbose mode produces no output"""
    test_secret_key = "LVYYllZk6xLIRoGVfGK9A78Dl1ehJbZOpRo6JoF2LAM"

    # Create gateway instance
    gateway = APIKeyGateway()

    # Clear cache TTL and URL to skip real API calls for this test
    # We'll mock the fetch_valid_public_keys directly
    gateway.CACHE_TTL_SECONDS = 100

    # Mock fetch_valid_public_keys to return an empty list
    with patch.object(gateway, 'fetch_valid_public_keys') as mock_fetch:
        mock_fetch.return_value = []

        try:
            gateway.validate_api_key(test_secret_key, 'test_service', verbose=False)
        except PermissionError:
            pass  # Expected since fetch returns empty list

        # Capture the output
        captured = capsys.readouterr()

        # Verify no output in non-verbose mode
        assert captured.out.strip() == ""


def test_middleware_api_key_extraction_logic():
    """Test the API key extraction logic used by the middleware"""
    # Replicate the exact API key extraction logic from the middleware
    def extract_api_key(headers, api_key_headers):
        secret_key = None
        for header_name in api_key_headers:
            header_value = headers.get(header_name)
            if header_value:
                if header_name.lower() == "authorization":
                    # Handle Bearer token format
                    if header_value.lower().startswith("bearer "):
                        secret_key = header_value[7:].strip()
                        break
                else:
                    # Handle direct header value
                    secret_key = header_value.strip()
                    break
        return secret_key

    # Default api_key_headers as defined in the middleware
    default_headers = [
        "x-akgateway-api-key",
        "authorization"
    ]

    # Test cases: header configurations and expected extracted keys
    test_cases = [
        # (headers_dict, expected_secret_key)
        ({"x-akgateway-api-key": "test_key_123"}, "test_key_123"),
        ({"X-AKGATEWAY-API-KEY": "test_key_456"}, "test_key_456"),  # case insensitive
        ({"authorization": "Bearer test_token_789"}, "test_token_789"),
        ({"Authorization": "bearer test_token_abc"}, "test_token_abc"),  # case insensitive
        ({"x-akgateway-api-key": "key1", "authorization": "Bearer key2"}, "key1"),  # first header takes precedence
        ({}, None),  # no api key headers
    ]

    for headers, expected_key in test_cases:
        # Convert headers to a case-insensitive dictionary for accurate testing
        from collections import defaultdict
        case_insensitive_headers = defaultdict(str)
        for k, v in headers.items():
            case_insensitive_headers[k.lower()] = v

        # Test the extraction logic
        extracted_key = extract_api_key(case_insensitive_headers, [h.lower() for h in default_headers])
        assert extracted_key == expected_key, f"Failed for headers {headers}: expected {expected_key}, got {extracted_key}"


# Note: _extract_issuer is a private function, not tested here

def test_validate_api_key_invalid_format():
    """Test validating API keys with invalid formats"""
    gateway = APIKeyGateway()

    # Test with empty token
    with pytest.raises(PermissionError, match="API key cannot be empty"):
        gateway.validate_api_key("", "test_service", verbose=False)

    # Test with wrong length
    with pytest.raises(PermissionError, match="API key must be 43 characters long"):
        gateway.validate_api_key("too_short_key", "test_service", verbose=False)