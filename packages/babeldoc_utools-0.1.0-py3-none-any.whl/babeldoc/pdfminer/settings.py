STRICT = False
