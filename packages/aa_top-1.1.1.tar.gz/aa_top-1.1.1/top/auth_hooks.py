from django.utils.translation import gettext_lazy as _

from allianceauth import hooks
from allianceauth.services.hooks import MenuItemHook, UrlHook

from . import urls


class TopMenuItem(MenuItemHook):
    """ This class ensures only authorized users will see the menu entry """

    def __init__(self) -> None:
        # setup menu entry for sidebar
        MenuItemHook.__init__(
            self,
            _("top"),
            "fas fa-terminal fa-fw",
            "top:index",
            navactive=["top:"],
        )

    def render(self, request):
        if request.user.has_perm("top.basic_access"):
            return MenuItemHook.render(self, request)
        return ""


@hooks.register("menu_item_hook")
def register_menu() -> TopMenuItem:
    return TopMenuItem()


@hooks.register("url_hook")
def register_urls() -> UrlHook:
    return UrlHook(urls, "top", r"^top/")
