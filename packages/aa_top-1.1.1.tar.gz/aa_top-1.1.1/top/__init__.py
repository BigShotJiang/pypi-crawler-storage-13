"""
Alliance Auth Resource Monitor
"""
__version__ = "1.1.1"
__title__ = "AATop"
__url__ = "https://gitlab.com/tactical-supremacy/aa-top"
