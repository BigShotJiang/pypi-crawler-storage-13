from setuptools import setup

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="aureon-smoother",
    version="0.1.0",
    author="AUREON LABS",
    author_email="contact@aureonlabs.com",
    description="Gradient Scale Synchronization for PyTorch - 5.46x smoothness improvement",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/aureonlabs/smoother",
    py_modules=["smoother"],
    install_requires=["torch>=1.9.0"],
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
