"""Operation research with polars."""
