"""Base class for Uniden scanner implementations."""

from abc import abstractmethod
from typing import Dict, Any, Optional
from ..base import Radio


class UnidenScanner(Radio):
    """
    Base class for Uniden scanner remote control.

    Implements common functionality shared across Uniden scanner models:
    - Volume control (VOL command, 0-29 range)
    - Squelch control (SQL command)
    - Firmware version retrieval (VER command)
    - Common command encoding/decoding patterns

    Subclasses must implement model-specific connection logic and
    reception information parsing.
    """

    # Common constants across Uniden scanners
    VOLUME_MIN = 0
    VOLUME_MAX = 29
    SQUELCH_MIN = 0

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize Uniden scanner.

        Common config options:
            - ser_port: Serial port (e.g., '/dev/ttyACM0')
            - baudrate: Serial baudrate (default: 115200)
            - timeout: Communication timeout (default: 0.5 seconds)
        """
        super().__init__(config)

        # Common serial configuration
        self.ser_port = config.get('ser_port')
        self.baudrate = config.get('baudrate', 115200)
        self.timeout = config.get('timeout', 0.5)

        # Cached values to reduce command overhead
        self._volume: Optional[int] = None
        self._squelch: Optional[int] = None

    @abstractmethod
    def connect(self) -> bool:
        """Connect to the scanner. Implementation is model-specific."""
        pass

    @abstractmethod
    def disconnect(self) -> bool:
        """Disconnect from the scanner. Implementation is model-specific."""
        pass

    @abstractmethod
    def send_command(self, command: str) -> str:
        """
        Send a command and return the response.

        Implementation varies by model:
        - SDS200: Supports both serial (persistent) and network (UDP)
        - BCD996P2: Serial only (per-command connection)
        """
        pass

    @abstractmethod
    def get_reception_info(self) -> Dict[str, str]:
        """
        Get current reception information.

        Returns dict with:
            - freq: Current frequency or TGID
            - site: Site/System name
            - group: Department/Group name
            - name: Channel name or "No Signal"

        Implementation varies by model:
        - SDS200: GSI command returns XML
        - BCD996P2: GLG command returns CSV
        """
        pass

    @abstractmethod
    def hold(self) -> bool:
        """
        Hold on current reception.

        Implementation varies by model due to different key codes:
        - SDS200: Uses KEY,C,P for channel hold
        - BCD996P2: Uses KEY,H,P for hold

        Returns:
            True if command succeeded, False otherwise.
        """
        pass

    @abstractmethod
    def resume(self) -> bool:
        """
        Resume scanning.

        Implementation varies by model due to different key codes:
        - SDS200: Toggle hold key or use JPM command
        - BCD996P2: Uses KEY,S,P for scan

        Returns:
            True if command succeeded, False otherwise.
        """
        pass

    # Common utility methods

    def _encode_command(self, command: str) -> bytes:
        """Encode command for sending (latin-1 encoding, carriage return)."""
        return (command + '\r').encode('latin-1')

    def _parse_comma_response(self, response: str, field_index: int) -> str:
        """
        Parse comma-separated response.

        Args:
            response: Command response (e.g., "VOL,15")
            field_index: Index of field to extract (0-based)

        Returns:
            Extracted field value, or empty string if not found
        """
        try:
            fields = response.split(',')
            return fields[field_index] if len(fields) > field_index else ''
        except Exception:
            return ''

    def _strip_leading_zeros(self, value: str) -> str:
        """
        Strip leading zeros from frequency/TGID strings.

        Keeps at least one '0' if the value is all zeros.
        """
        stripped = value.lstrip('0')
        return stripped if stripped else '0'

    # Common properties and methods

    def get_firmware_version(self) -> str:
        """Get firmware version using VER command."""
        response = self.send_command("VER")
        # Response format: "VER,version"
        try:
            return response.split(',')[1]
        except IndexError:
            return response

    @property
    def volume(self) -> int:
        """
        Get current volume (0-29).

        Uses cached value if available, otherwise queries the scanner.
        """
        if self._volume is None:
            response = self.send_command("VOL")
            # Response format: "VOL,XX" where XX is volume
            try:
                self._volume = int(response.split(',')[1])
            except (IndexError, ValueError):
                self._volume = 0
        return self._volume

    @volume.setter
    def volume(self, level: int) -> None:
        """
        Set volume (0-29 or 0-100 as percentage).

        Accepts both raw values (0-29) and percentages (0-100).
        Percentages are automatically converted to 0-29 range.

        Args:
            level: Volume level (0-29 raw, or 0-100 as percentage)

        Raises:
            ValueError: If level is out of valid range
        """
        # Convert percentage to raw value if needed
        if level > self.VOLUME_MAX:
            level = int(level * self.VOLUME_MAX / 100)

        if not self.VOLUME_MIN <= level <= self.VOLUME_MAX:
            raise ValueError(
                f"Volume must be {self.VOLUME_MIN}-{self.VOLUME_MAX}, got {level}"
            )

        self.send_command(f"VOL,{level}")
        self._volume = level

    @property
    def squelch(self) -> int:
        """
        Get current squelch level.

        Uses cached value if available, otherwise queries the scanner.
        """
        if self._squelch is None:
            response = self.send_command("SQL")
            # Response format: "SQL,XX" where XX is squelch level
            try:
                self._squelch = int(response.split(',')[1])
            except (IndexError, ValueError):
                self._squelch = 0
        return self._squelch

    @squelch.setter
    def squelch(self, level: int) -> None:
        """
        Set squelch level.

        Args:
            level: Squelch level (must be non-negative)

        Raises:
            ValueError: If level is negative
        """
        if level < self.SQUELCH_MIN:
            raise ValueError(
                f"Squelch must be >= {self.SQUELCH_MIN}, got {level}"
            )

        self.send_command(f"SQL,{level}")
        self._squelch = level

    def set_frequency(self, frequency: float) -> bool:
        """
        Set frequency (not implemented for scanners).

        Uniden scanners use programmed systems/channels, not direct frequency
        entry via remote control protocol.

        Raises:
            NotImplementedError: Scanners use systems/channels, not direct frequency
        """
        raise NotImplementedError(
            f"{self.model} is a scanner, use systems/channels for frequency selection"
        )

    def keypress(self, key: str, mode: str) -> bool:
        """
        Simulate a keypress on the scanner.

        Sends KEY command to scanner using the format: KEY,<key>,<mode>

        Args:
            key: Key code (single character, model-specific)
                Common keys: M (Menu), F (Function), L (L/O), 0-9, . (Dot), E (Enter)
                BCD996P2: H (Hold), S (Scan), P (PRI), W (WX), G (GPS)
                SDS200: A (System hold), B (Dept hold), C (Chan hold)
            mode: Key mode - 'P' (press), 'L' (long press), 'H' (hold), 'R' (release)

        Returns:
            True if command succeeded, False otherwise.

        Raises:
            ValueError: If mode is invalid

        Example:
            scanner.keypress('M', 'P')  # Press Menu button
            scanner.keypress('H', 'P')  # Press Hold button (BCD996P2)
            scanner.keypress('C', 'P')  # Press Channel hold (SDS200)
        """
        # Validate mode
        valid_modes = ['P', 'L', 'H', 'R']
        mode_upper = mode.upper()
        if mode_upper not in valid_modes:
            raise ValueError(
                f"Invalid mode '{mode}'. Must be one of: {', '.join(valid_modes)}"
            )

        # Send KEY command
        response = self.send_command(f"KEY,{key.upper()},{mode_upper}")
        return response == "KEY,OK"
