"""Version information for radio-manager."""

__version__ = "0.3.0"
