import uuid

class BookingId:
    @staticmethod
    def generate_id():
        booking_id=str(uuid.uuid4())
        return f"MLDG-{booking_id}"
class PriceCalculate:
    def __init__(self,base_rate, nights):
        self.base_rate=base_rate
        self.nights=nights

    def calculate_total(self, discount=0):
        total=self.base_rate*self.nights
        if discount:
            total-=total*(discount/100)
        return round(total,2)
class EmailTemplate:
    @staticmethod
    def booking_confirmation(username,booking_id,lodge_name, total):
        return {
            "subject": f"Booking Confirmed ID: {booking_id}",
            "body": (
                f"Hi {username},\n"
                f"Your booking for {lodge_name} is confirmed.\n"
                f"Total Amount: ${total}\n"
                "Thank you for choosing MyLodge!"
            )
        }

    @staticmethod
    def booking_cancellation(username,booking_id,total):
        return {
            "subject": f"Booking Cancelled ID: {booking_id}",
            "body": (
                f"Hi {username},\n"
                f"Your booking ({booking_id}) has been cancelled. {total} will be refunded. \n"
                "We hope to see you again!"
            )
        }
