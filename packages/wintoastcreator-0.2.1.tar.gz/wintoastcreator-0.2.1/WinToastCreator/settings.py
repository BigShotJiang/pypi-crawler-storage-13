import keyboard
import time
from WinToastCreator.creator import notify

def toggle_focus():
    keyboard.press_and_release('win+n')
    time.sleep(1.5)
    keyboard.press_and_release('enter')
    keyboard.press_and_release('win+n')
    time.sleep(0.5)
    notify('Переключатель режима «Не беспокоить»', 'Режим «Не беспокоить» успешно переключён!')