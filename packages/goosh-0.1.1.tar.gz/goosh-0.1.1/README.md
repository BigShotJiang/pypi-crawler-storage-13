# Goosh

A terminal emulator with integrated AI assistance. Press Shift twice quickly to get AI help with your current command or task.

## Features

- Full terminal emulation with ANSI color support
- AI assistance via Shift+Shift
- Context-aware command suggestions
- Works with bash, zsh, fish, and other shells

## Installation

```bash


uv pip install -e .

# Or use uvx
uvx goosh
```

## Configuration

Set at least one API key:

```bash
export OPENROUTER_API_KEY=sk-...
# or
export ANTHROPIC_API_KEY=sk-...
# or
export OPENAI_API_KEY=sk-...
# or
export GOOGLE_API_KEY=
# or
export GROQ_API_KEY=
```

## Usage

1. Launch the terminal:
   ```bash
   goosh
   ```

2. Use it like a normal terminal

3. When you need help:
   - Press Shift twice quickly
   - Type what you want (e.g., "fix this command" or "list python files")
   - AI will type the command for you
   - Review and press Enter

## Examples

**Fix a typo:**
```
$ gti status
bash: gti: command not found
[Shift+Shift] → "fix it" → git status
```

**Complete a command:**
```
$ git commit -m "
[Shift+Shift] → "add auth system" → git commit -m "Add user authentication system"
```

**Generate a new command:**
```
$ 
[Shift+Shift] → "find python files" → find . -name "*.py"
```

## How It Works

- **terminal.py**: PTY management and terminal emulation
- **gui.py**: Tkinter UI with color rendering
- **ai.py**: LLM integration for command suggestions

The AI sees your current screen and command buffer, understands what you're trying to do, and types the appropriate command.

## Requirements

- Python 3.11+
- macOS or Linux (PTY-based)
- LLM API key (OpenRouter, Anthropic, or OpenAI)

## License

MIT
