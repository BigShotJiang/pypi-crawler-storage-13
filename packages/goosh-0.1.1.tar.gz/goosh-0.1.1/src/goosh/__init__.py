"""Terminal with AI assistance"""

__version__ = "0.1.0"
