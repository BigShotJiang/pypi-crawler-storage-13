#!/usr/bin/env python3
import time
from .terminal import TerminalSession
from .gui import TerminalGUI
from .ai import AIAssist


def main():
    from dotenv import load_dotenv

    load_dotenv()

    ai_assist = AIAssist()
    gui = TerminalGUI(ai_assist)
    gui.render_terminal()

    try:
        while gui.is_running():
            if not gui.terminal.read_output():
                break

            if gui.terminal.screen_changed():
                gui.render_terminal()
            gui.update()

            time.sleep(0.01)

    except KeyboardInterrupt:
        print("\nExiting...")

    finally:
        gui.root.destroy()


if __name__ == "__main__":
    main()
