"""
Setup configuration for slide_generator package
"""

from setuptools import setup, find_packages

with open("README_SLIDE_GENERATOR.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="slide-generator",
    version="1.0.0",
    author="AI Presentation System",
    author_email="contact@example.com",
    description="Convert presentation outlines to PowerPoint files without requiring LLM",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/slide-generator",
    project_urls={
        "Bug Tracker": "https://github.com/yourusername/slide-generator/issues",
        "Documentation": "https://github.com/yourusername/slide-generator#readme",
        "Source Code": "https://github.com/yourusername/slide-generator",
    },
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Office/Business",
        "Topic :: Multimedia :: Graphics :: Presentation",
    ],
    python_requires=">=3.8",
    install_requires=[
        "playwright>=1.40.0",
        "python-pptx>=0.6.21",
        "pillow>=10.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "black>=23.0",
            "flake8>=6.0",
        ],
    },
    keywords="powerpoint presentation slides html conversion",
)
