"""
HTML Slide Template Generators
Generates HTML for each of the 8 slide layouts
No LLM or external dependencies required.
"""

from typing import Dict, Any
import html as html_lib


class SlideHTMLGenerator:
    """Generates HTML for different slide layouts"""

    # Company logo URL
    COMPANY_LOGO = "https://www.fdjunited.com/wp-content/uploads/2025/02/LOGOFDJUNITED2LBleuFonceBleuClairRVB.jpg"

    @staticmethod
    def get_base_styles() -> str:
        """Return the base CSS styles for all slides"""
        return """
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f0f0;
        }

        .slide {
            width: 1280px;
            height: 720px;
            background: white;
            margin: 20px auto;
            padding: 80px 100px;
            position: relative;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        :root {
            --primary: #2563eb;
            --secondary: #64748b;
            --accent: #f59e0b;
            --text: #1e293b;
            --text-light: #64748b;
            --background: #ffffff;
        }

        .company-logo {
            position: absolute;
            top: 30px;
            right: 40px;
            width: 120px;
            height: auto;
        }

        .title-slide .company-logo {
            top: 40px;
            right: 60px;
            width: 140px;
        }

        .slide-number {
            position: absolute;
            bottom: 30px;
            right: 40px;
            font-size: 18px;
            color: var(--text-light);
        }
        """

    @staticmethod
    def escape_html(text: str) -> str:
        """Escape HTML special characters"""
        if text is None:
            return ""
        return html_lib.escape(str(text))

    @staticmethod
    def generate_title_slide(slide: Dict[str, Any], slide_number: int) -> str:
        """Layout 1: Title Slide"""
        content = slide.get("content", {})
        title = SlideHTMLGenerator.escape_html(content.get("title", "Your Presentation Title"))
        subtitle = SlideHTMLGenerator.escape_html(content.get("subtitle", ""))
        author = SlideHTMLGenerator.escape_html(content.get("author", ""))

        return f"""
        <style>
            .title-slide {{
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                text-align: center;
                background: linear-gradient(135deg, var(--primary) 0%, #1e40af 100%);
                color: white;
            }}

            .title-slide h1 {{
                font-size: 72px;
                font-weight: 700;
                margin-bottom: 30px;
                line-height: 1.2;
            }}

            .title-slide .subtitle {{
                font-size: 32px;
                font-weight: 300;
                color: rgba(255,255,255,0.9);
            }}

            .title-slide .author {{
                position: absolute;
                bottom: 60px;
                font-size: 24px;
                color: rgba(255,255,255,0.8);
            }}
        </style>

        <div class="slide title-slide">
            <img src="{SlideHTMLGenerator.COMPANY_LOGO}" alt="Company Logo" class="company-logo">
            <h1>{title}</h1>
            <div class="subtitle">{subtitle}</div>
            <div class="author">{author}</div>
        </div>
        """

    @staticmethod
    def generate_content_slide(slide: Dict[str, Any], slide_number: int) -> str:
        """Layout 2: Title + Content"""
        title = SlideHTMLGenerator.escape_html(slide.get("title", "Main Heading"))
        subtitle = SlideHTMLGenerator.escape_html(slide.get("subtitle", ""))
        content = slide.get("content", {})
        body = content.get("body", "")

        # Convert newlines to <p> tags
        paragraphs = body.split("\n\n")
        body_html = "".join(f"<p>{SlideHTMLGenerator.escape_html(p)}</p>" for p in paragraphs if p.strip())

        subtitle_html = f'<div class="slide-subtitle">{subtitle}</div>' if subtitle else ""

        return f"""
        <style>
            .content-slide h2 {{
                font-size: 48px;
                color: var(--primary);
                margin-bottom: 12px;
            }}

            .content-slide .slide-subtitle {{
                font-size: 24px;
                color: var(--secondary);
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 4px solid var(--accent);
            }}

            .content-slide .content {{
                font-size: 28px;
                line-height: 1.6;
                color: var(--text);
            }}

            .content-slide .content p {{
                margin-bottom: 20px;
            }}
        </style>

        <div class="slide content-slide">
            <img src="{SlideHTMLGenerator.COMPANY_LOGO}" alt="Company Logo" class="company-logo">
            <h2>{title}</h2>
            {subtitle_html}
            <div class="content">
                {body_html}
            </div>
            <div class="slide-number">{slide_number}</div>
        </div>
        """

    @staticmethod
    def generate_two_column_slide(slide: Dict[str, Any], slide_number: int) -> str:
        """Layout 3: Two Column"""
        title = SlideHTMLGenerator.escape_html(slide.get("title", "Comparison"))
        subtitle = SlideHTMLGenerator.escape_html(slide.get("subtitle", ""))
        content = slide.get("content", {})

        left_col = content.get("left_column", {})
        right_col = content.get("right_column", {})

        left_heading = SlideHTMLGenerator.escape_html(left_col.get("heading", "Left Column"))
        left_content = SlideHTMLGenerator.escape_html(left_col.get("content", ""))

        right_heading = SlideHTMLGenerator.escape_html(right_col.get("heading", "Right Column"))
        right_content = SlideHTMLGenerator.escape_html(right_col.get("content", ""))

        subtitle_html = f'<div class="slide-subtitle">{subtitle}</div>' if subtitle else ""

        return f"""
        <style>
            .two-column h2 {{
                font-size: 48px;
                color: var(--primary);
                margin-bottom: 12px;
            }}

            .two-column .slide-subtitle {{
                font-size: 24px;
                color: var(--secondary);
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 4px solid var(--accent);
            }}

            .two-column .columns {{
                display: flex;
                gap: 60px;
                height: calc(100% - 140px);
            }}

            .two-column .column {{
                flex: 1;
                font-size: 24px;
                line-height: 1.6;
                color: var(--text);
            }}

            .two-column .column h3 {{
                font-size: 32px;
                color: var(--secondary);
                margin-bottom: 20px;
            }}
        </style>

        <div class="slide two-column">
            <img src="{SlideHTMLGenerator.COMPANY_LOGO}" alt="Company Logo" class="company-logo">
            <h2>{title}</h2>
            {subtitle_html}
            <div class="columns">
                <div class="column">
                    <h3>{left_heading}</h3>
                    <p>{left_content}</p>
                </div>
                <div class="column">
                    <h3>{right_heading}</h3>
                    <p>{right_content}</p>
                </div>
            </div>
            <div class="slide-number">{slide_number}</div>
        </div>
        """

    @staticmethod
    def generate_image_slide(slide: Dict[str, Any], slide_number: int) -> str:
        """Layout 4: Title + Image"""
        title = SlideHTMLGenerator.escape_html(slide.get("title", "Visual Content"))
        subtitle = SlideHTMLGenerator.escape_html(slide.get("subtitle", ""))
        content = slide.get("content", {})

        # Priority: SVG > Image URL > description
        image_svg = content.get("image_svg", "")
        image_url = content.get("image_url", "")
        image_desc = SlideHTMLGenerator.escape_html(content.get("image_description", "[Image Placeholder]"))

        if image_svg:
            image_content = image_svg
        elif image_url:
            image_content = f'<img src="{SlideHTMLGenerator.escape_html(image_url)}" alt="Slide Image" style="max-width:100%; max-height:100%; object-fit:contain;"/>'
        else:
            image_content = f"<div style='display:flex; align-items:center; justify-content:center; height:100%; color:var(--text-light);'>{image_desc}</div>"

        subtitle_html = f'<div class="slide-subtitle">{subtitle}</div>' if subtitle else ""

        return f"""
        <style>
            .image-slide h2 {{
                font-size: 48px;
                color: var(--primary);
                margin-bottom: 12px;
            }}

            .image-slide .slide-subtitle {{
                font-size: 24px;
                color: var(--secondary);
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 4px solid var(--accent);
            }}

            .image-slide .image-container {{
                width: 100%;
                height: calc(100% - 140px);
                background: #f8fafc;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 24px;
                color: var(--text-light);
                padding: 30px;
                overflow: hidden;
            }}

            .image-slide .image-container svg {{
                max-width: 100%;
                max-height: 100%;
            }}
        </style>

        <div class="slide image-slide">
            <img src="{SlideHTMLGenerator.COMPANY_LOGO}" alt="Company Logo" class="company-logo">
            <h2>{title}</h2>
            {subtitle_html}
            <div class="image-container">
                {image_content}
            </div>
            <div class="slide-number">{slide_number}</div>
        </div>
        """

    @staticmethod
    def generate_image_text_slide(slide: Dict[str, Any], slide_number: int) -> str:
        """Layout 5: Image + Text (Two Column)"""
        title = SlideHTMLGenerator.escape_html(slide.get("title", "Visual Explanation"))
        subtitle = SlideHTMLGenerator.escape_html(slide.get("subtitle", ""))
        content = slide.get("content", {})

        # Priority: SVG > Image URL > description
        image_svg = content.get("image_svg", "")
        image_url = content.get("image_url", "")
        image_desc = SlideHTMLGenerator.escape_html(content.get("image_description", "[Image Placeholder]"))

        if image_svg:
            image_content = image_svg
        elif image_url:
            image_content = f'<img src="{SlideHTMLGenerator.escape_html(image_url)}" alt="Slide Image" style="max-width:100%; max-height:100%; object-fit:contain;"/>'
        else:
            image_content = f"<div style='display:flex; align-items:center; justify-content:center; height:100%; font-size:18px;'>{image_desc}</div>"

        text_heading = SlideHTMLGenerator.escape_html(content.get("text_heading", "Key Information"))
        text_body = SlideHTMLGenerator.escape_html(content.get("text_body", ""))

        subtitle_html = f'<div class="slide-subtitle">{subtitle}</div>' if subtitle else ""

        return f"""
        <style>
            .image-text-slide h2 {{
                font-size: 48px;
                color: var(--primary);
                margin-bottom: 12px;
            }}

            .image-text-slide .slide-subtitle {{
                font-size: 24px;
                color: var(--secondary);
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 4px solid var(--accent);
            }}

            .image-text-slide .columns {{
                display: flex;
                gap: 60px;
                height: calc(100% - 140px);
            }}

            .image-text-slide .image-column {{
                flex: 1;
                background: #f8fafc;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 24px;
                color: var(--text-light);
                padding: 30px;
                overflow: hidden;
            }}

            .image-text-slide .image-column svg {{
                max-width: 100%;
                max-height: 100%;
            }}

            .image-text-slide .text-column {{
                flex: 1;
                display: flex;
                flex-direction: column;
                justify-content: center;
                font-size: 26px;
                line-height: 1.7;
                color: var(--text);
            }}

            .image-text-slide .text-column h3 {{
                font-size: 36px;
                color: var(--secondary);
                margin-bottom: 24px;
            }}

            .image-text-slide .text-column p {{
                margin-bottom: 20px;
            }}
        </style>

        <div class="slide image-text-slide">
            <img src="{SlideHTMLGenerator.COMPANY_LOGO}" alt="Company Logo" class="company-logo">
            <h2>{title}</h2>
            {subtitle_html}
            <div class="columns">
                <div class="image-column">
                    {image_content}
                </div>
                <div class="text-column">
                    <h3>{text_heading}</h3>
                    <p>{text_body}</p>
                </div>
            </div>
            <div class="slide-number">{slide_number}</div>
        </div>
        """

    @staticmethod
    def generate_bullet_slide(slide: Dict[str, Any], slide_number: int) -> str:
        """Layout 6: Bullet Points"""
        title = SlideHTMLGenerator.escape_html(slide.get("title", "Key Points"))
        subtitle = SlideHTMLGenerator.escape_html(slide.get("subtitle", ""))
        content = slide.get("content", {})
        points = content.get("points", [])

        # Build bullet HTML
        bullet_html = ""
        for point in points:
            if isinstance(point, str):
                escaped_point = SlideHTMLGenerator.escape_html(point)
                bullet_html += f"<li>{escaped_point}</li>"
            elif isinstance(point, dict):
                main = SlideHTMLGenerator.escape_html(point.get("main", ""))
                bullet_html += f"<li>{main}"
                subs = point.get("sub", [])
                if subs:
                    bullet_html += "<ul>"
                    for sub in subs:
                        escaped_sub = SlideHTMLGenerator.escape_html(sub)
                        bullet_html += f"<li>{escaped_sub}</li>"
                    bullet_html += "</ul>"
                bullet_html += "</li>"

        subtitle_html = f'<div class="slide-subtitle">{subtitle}</div>' if subtitle else ""

        return f"""
        <style>
            .bullet-slide h2 {{
                font-size: 48px;
                color: var(--primary);
                margin-bottom: 12px;
            }}

            .bullet-slide .slide-subtitle {{
                font-size: 24px;
                color: var(--secondary);
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 4px solid var(--accent);
            }}

            .bullet-slide ul {{
                list-style: none;
                font-size: 28px;
                line-height: 1.8;
                color: var(--text);
            }}

            .bullet-slide ul li {{
                margin-bottom: 24px;
                padding-left: 50px;
                position: relative;
            }}

            .bullet-slide ul li::before {{
                content: "●";
                color: var(--accent);
                font-size: 32px;
                position: absolute;
                left: 0;
                top: -2px;
            }}

            .bullet-slide ul ul {{
                margin-top: 16px;
                font-size: 24px;
                margin-left: 20px;
            }}

            .bullet-slide ul ul li {{
                margin-bottom: 12px;
            }}

            .bullet-slide ul ul li::before {{
                content: "○";
                font-size: 24px;
            }}
        </style>

        <div class="slide bullet-slide">
            <img src="{SlideHTMLGenerator.COMPANY_LOGO}" alt="Company Logo" class="company-logo">
            <h2>{title}</h2>
            {subtitle_html}
            <ul>
                {bullet_html}
            </ul>
            <div class="slide-number">{slide_number}</div>
        </div>
        """

    @staticmethod
    def generate_quote_slide(slide: Dict[str, Any], slide_number: int) -> str:
        """Layout 7: Quote"""
        content = slide.get("content", {})
        quote_text = SlideHTMLGenerator.escape_html(content.get("quote_text", ""))
        author = SlideHTMLGenerator.escape_html(content.get("author", ""))

        return f"""
        <style>
            .quote-slide {{
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                text-align: center;
                background: #f8fafc;
            }}

            .quote-slide .quote-mark {{
                font-size: 120px;
                color: var(--accent);
                line-height: 0.8;
                margin-bottom: 20px;
                font-family: Georgia, serif;
            }}

            .quote-slide .quote-text {{
                font-size: 40px;
                font-style: italic;
                color: var(--text);
                line-height: 1.5;
                max-width: 900px;
                margin-bottom: 40px;
            }}

            .quote-slide .quote-author {{
                font-size: 28px;
                color: var(--secondary);
                font-weight: 600;
            }}
        </style>

        <div class="slide quote-slide">
            <img src="{SlideHTMLGenerator.COMPANY_LOGO}" alt="Company Logo" class="company-logo">
            <div class="quote-mark">"</div>
            <div class="quote-text">
                {quote_text}
            </div>
            <div class="quote-author">— {author}</div>
            <div class="slide-number">{slide_number}</div>
        </div>
        """

    @staticmethod
    def generate_chart_slide(slide: Dict[str, Any], slide_number: int) -> str:
        """Layout 8: Chart/Graph + Text (Two Column)"""
        import json
        title = SlideHTMLGenerator.escape_html(slide.get("title", "Performance Metrics"))
        subtitle = SlideHTMLGenerator.escape_html(slide.get("subtitle", ""))
        content = slide.get("content", {})

        # Use chart_json first (Chart.js), then chart_svg, then chart_data, then fall back to description
        chart_json_str = content.get("chart_json", "")
        chart_svg = content.get("chart_svg", "")
        chart_data = content.get("chart_data", "")
        chart_desc = SlideHTMLGenerator.escape_html(content.get("chart_description", "[Chart/Graph Placeholder]"))

        # Priority: Chart.js JSON > SVG > HTML table > description
        chart_html = ""
        if chart_json_str:
            try:
                # Parse and validate the JSON
                chart_config = json.loads(chart_json_str)
                chart_html = f'''
                <div style="position: relative; height: 100%; width: 100%;">
                    <canvas id="chart-{slide_number}" style="max-height: 100%; max-width: 100%;"></canvas>
                </div>
                <script>
                    if (typeof Chart !== 'undefined') {{
                        const ctx = document.getElementById('chart-{slide_number}').getContext('2d');
                        new Chart(ctx, {chart_json_str});
                    }}
                </script>
                '''
                chart_content = chart_html
            except json.JSONDecodeError:
                # If JSON is invalid, try SVG, then data, then description
                if chart_svg:
                    chart_content = chart_svg
                elif chart_data:
                    chart_content = chart_data
                else:
                    chart_content = f"<p>{chart_desc}</p>"
        elif chart_svg:
            chart_content = chart_svg
        elif chart_data:
            chart_content = chart_data
        else:
            chart_content = f"<p>{chart_desc}</p>"

        text_heading = SlideHTMLGenerator.escape_html(content.get("text_heading", "Key Insights"))
        text_body = SlideHTMLGenerator.escape_html(content.get("text_body", ""))
        insights = content.get("insights", [])

        insight_html = ""
        for insight in insights:
            escaped_insight = SlideHTMLGenerator.escape_html(insight)
            insight_html += f"<li>{escaped_insight}</li>"

        subtitle_html = f'<div class="slide-subtitle">{subtitle}</div>' if subtitle else ""

        return f"""
        <style>
            .chart-slide h2 {{
                font-size: 48px;
                color: var(--primary);
                margin-bottom: 12px;
            }}

            .chart-slide .slide-subtitle {{
                font-size: 24px;
                color: var(--secondary);
                margin-bottom: 30px;
                padding-bottom: 20px;
                border-bottom: 4px solid var(--accent);
            }}

            .chart-slide .columns {{
                display: flex;
                gap: 60px;
                height: calc(100% - 140px);
            }}

            .chart-slide .chart-column {{
                flex: 1;
                display: flex;
                flex-direction: column;
            }}

            .chart-slide .chart-area {{
                flex: 1;
                background: #f8fafc;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                border: 2px solid #e2e8f0;
                font-size: 20px;
                color: var(--text-light);
                padding: 30px;
                overflow-y: auto;
            }}

            .chart-slide .chart-area table {{
                width: 100%;
            }}

            .chart-slide .chart-area p {{
                text-align: center;
                font-style: italic;
                color: var(--text-light);
            }}

            .chart-slide .text-column {{
                flex: 1;
                display: flex;
                flex-direction: column;
                justify-content: center;
                font-size: 26px;
                line-height: 1.7;
                color: var(--text);
            }}

            .chart-slide .text-column h3 {{
                font-size: 36px;
                color: var(--secondary);
                margin-bottom: 24px;
            }}

            .chart-slide .text-column p {{
                margin-bottom: 16px;
            }}

            .chart-slide .text-column ul {{
                list-style: none;
                margin-top: 20px;
            }}

            .chart-slide .text-column ul li {{
                margin-bottom: 16px;
                padding-left: 30px;
                position: relative;
                font-size: 24px;
            }}

            .chart-slide .text-column ul li::before {{
                content: "▸";
                color: var(--accent);
                position: absolute;
                left: 0;
                font-size: 20px;
            }}
        </style>

        <div class="slide chart-slide">
            <img src="{SlideHTMLGenerator.COMPANY_LOGO}" alt="Company Logo" class="company-logo">
            <h2>{title}</h2>
            {subtitle_html}
            <div class="columns">
                <div class="chart-column">
                    <div class="chart-area">
                        {chart_content}
                    </div>
                </div>
                <div class="text-column">
                    <h3>{text_heading}</h3>
                    <p>{text_body}</p>
                    <ul>
                        {insight_html}
                    </ul>
                </div>
            </div>
            <div class="slide-number">{slide_number}</div>
        </div>
        """

    @staticmethod
    def generate_slide_html(slide: Dict[str, Any]) -> str:
        """Generate HTML for a slide based on its layout"""
        layout = slide.get("layout")
        slide_number = slide.get("slide_number", 1)

        generators = {
            "title": SlideHTMLGenerator.generate_title_slide,
            "content": SlideHTMLGenerator.generate_content_slide,
            "two_column": SlideHTMLGenerator.generate_two_column_slide,
            "image": SlideHTMLGenerator.generate_image_slide,
            "image_text": SlideHTMLGenerator.generate_image_text_slide,
            "bullets": SlideHTMLGenerator.generate_bullet_slide,
            "quote": SlideHTMLGenerator.generate_quote_slide,
            "chart": SlideHTMLGenerator.generate_chart_slide,
        }

        if layout not in generators:
            raise ValueError(f"Unknown layout: {layout}")

        return generators[layout](slide, slide_number)


def wrap_slide_html(slide_content: str) -> str:
    """Wrap a slide with HTML document structure"""
    base_styles = SlideHTMLGenerator.get_base_styles()

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slide</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        html, body {{
            margin: 0;
            padding: 0;
            width: 1280px;
            height: 720px;
            overflow: hidden;
            background: transparent;
        }}
        {base_styles}
    </style>
</head>
<body>
    {slide_content}
</body>
</html>
"""
