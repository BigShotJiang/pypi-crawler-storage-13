"""
Slide Generator Package
Converts presentation outlines to PowerPoint files without requiring LLM.
This package is isolated and can be used independently.
"""

from .html_generator import SlideHTMLGenerator, wrap_slide_html
from .powerpoint_generator import PowerPointGenerator

__version__ = "1.0.0"
__all__ = ["SlideHTMLGenerator", "wrap_slide_html", "PowerPointGenerator"]
