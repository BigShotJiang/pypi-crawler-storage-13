"""
PowerPoint generation from HTML slides - entirely in memory
Converts HTML slides to images and embeds them in a PowerPoint presentation
No LLM or external dependencies required (except Playwright and python-pptx).
"""

from playwright.async_api import async_playwright
from pptx import Presentation
from pptx.util import Inches
from PIL import Image
from io import BytesIO
from typing import List, Dict, Optional
import os
import asyncio


class PowerPointGenerator:
    """Generate PowerPoint entirely in memory - no intermediate files"""

    def __init__(self, pixel_width: int = 1280, pixel_height: int = 720, scale: float = 2.0):
        """
        Initialize the PowerPoint generator

        Args:
            pixel_width: Slide width in pixels (default 1280 for 16:9)
            pixel_height: Slide height in pixels (default 720 for 16:9)
            scale: Device scale factor for higher quality (default 2.0)
        """
        self.pixel_width = pixel_width
        self.pixel_height = pixel_height
        self.scale = scale

        # Calculate slide dimensions (10" x 5.625" for 16:9)
        self.slide_width = Inches(10)
        self.slide_height = Inches(5.625)

    async def html_to_image_bytes(self, html_content: str) -> bytes:
        """
        Convert HTML to PNG image bytes (in memory)

        Args:
            html_content: Complete HTML as string

        Returns:
            PNG image as bytes
        """
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(
                viewport={"width": self.pixel_width, "height": self.pixel_height},
                device_scale_factor=self.scale,
            )

            page = await context.new_page()
            await page.set_content(html_content, wait_until="networkidle")
            await page.wait_for_timeout(2000)  # Wait for fonts/rendering/charts

            # Get screenshot as bytes
            screenshot_bytes = await page.screenshot(type="png", full_page=False)

            await page.close()
            await context.close()
            await browser.close()

        return screenshot_bytes

    def _compress_image_bytes(
        self, image_bytes: bytes, quality: int = 85, max_dimension: int = 2560
    ) -> bytes:
        """
        Compress image bytes to reduce file size

        Args:
            image_bytes: Original PNG bytes
            quality: JPEG quality (1-100)
            max_dimension: Maximum width or height

        Returns:
            Compressed image bytes
        """
        # Load image from bytes
        img = Image.open(BytesIO(image_bytes))

        # Resize if too large
        if max(img.size) > max_dimension:
            ratio = max_dimension / max(img.size)
            new_size = tuple(int(dim * ratio) for dim in img.size)
            img = img.resize(new_size, Image.Resampling.LANCZOS)

        # Compress to JPEG
        output = BytesIO()
        img.convert("RGB").save(output, "JPEG", quality=quality, optimize=True)

        return output.getvalue()

    async def create_powerpoint(
        self,
        html_slides: List[str],
        output_path: str,
        compress_images: bool = True,
        metadata: Optional[Dict] = None,
    ) -> str:
        """
        Create PowerPoint directly from HTML slides (all in memory)

        Args:
            html_slides: List of complete HTML strings
            output_path: Where to save final .pptx file
            compress_images: Whether to compress images (reduces file size)
            metadata: Optional metadata (title, author, subject, comments)

        Returns:
            Path to saved PowerPoint file
        """
        print(f"\nConverting {len(html_slides)} HTML slides to PowerPoint...")

        # Create presentation
        prs = Presentation()
        prs.slide_width = self.slide_width
        prs.slide_height = self.slide_height

        # Process each slide
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(
                viewport={"width": self.pixel_width, "height": self.pixel_height},
                device_scale_factor=self.scale,
            )

            for i, html in enumerate(html_slides, 1):
                try:
                    print(f"  Slide {i}/{len(html_slides)}: Converting to image...", end=" ")

                    # Convert HTML to image bytes
                    page = await context.new_page()
                    await page.set_content(html, wait_until="networkidle")
                    await page.wait_for_timeout(2000)  # Wait for charts to render

                    screenshot_bytes = await page.screenshot(type="png", full_page=False)
                    await page.close()

                    # Optionally compress
                    if compress_images:
                        print("compressing...", end=" ")
                        screenshot_bytes = self._compress_image_bytes(
                            screenshot_bytes, quality=85
                        )

                    # Create in-memory file object
                    image_stream = BytesIO(screenshot_bytes)

                    # Add blank slide
                    blank_layout = prs.slide_layouts[6]  # Blank layout
                    slide = prs.slides.add_slide(blank_layout)

                    # Add image to slide (full size)
                    slide.shapes.add_picture(
                        image_stream,
                        Inches(0),
                        Inches(0),
                        width=self.slide_width,
                        height=self.slide_height,
                    )

                    print("✓")

                except Exception as e:
                    print(f"✗")
                    raise RuntimeError(f"Error processing slide {i}: {str(e)}")

            await context.close()
            await browser.close()

        # Add metadata if provided
        if metadata:
            core_props = prs.core_properties
            if "title" in metadata:
                core_props.title = metadata["title"]
            if "author" in metadata:
                core_props.author = metadata["author"]
            if "subject" in metadata:
                core_props.subject = metadata["subject"]
            if "comments" in metadata:
                core_props.comments = metadata["comments"]

        # Save final PowerPoint
        prs.save(output_path)

        # Get file size
        file_size_mb = os.path.getsize(output_path) / (1024 * 1024)
        print(f"\n✓ PowerPoint created successfully!")
        print(f"  Location: {output_path}")
        print(f"  Size: {file_size_mb:.2f} MB")

        return output_path
