# AI-Powered Presentation Generator - Modular Architecture

A professional, modular presentation generation system with two independent components:

1. **slide_generator** - Standalone package (Outline → PowerPoint)
2. **presentation_generator** - LLM pipeline (User Input → PowerPoint)

## Quick Navigation

| What do you want to do? | Read this | Then run this |
|------------------------|-----------|----------------|
| Get started immediately | [QUICK_START.md](QUICK_START.md) | `example_slide_generator_standalone.py` |
| Use slide_generator | [README_SLIDE_GENERATOR.md](README_SLIDE_GENERATOR.md) | `example_slide_generator_standalone.py` |
| Use full LLM pipeline | [QUICK_START.md](QUICK_START.md) | `example_complete_pipeline_with_llm.py` |
| Understand the design | [ARCHITECTURE.md](ARCHITECTURE.md) | - |
| See what changed | [REFACTORING_SUMMARY.md](REFACTORING_SUMMARY.md) | - |
| Complete overview | [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md) | - |

## Two Components

### 1. slide_generator Package

**What it does**: Converts presentation outlines to PowerPoint files.

**Features**:
- No LLM dependencies
- 8 professional slide layouts
- In-memory processing (no temp files)
- Ready to publish to PyPI
- ~15-18 seconds for 6 slides

**Use when**:
- You have outlines from other sources
- Using a different LLM (Claude, Gemini, etc.)
- Want zero external API dependencies
- Building an integrated system

**Installation**:
```bash
pip install playwright python-pptx pillow
playwright install chromium
```

**Usage**:
```python
from slide_generator import PowerPointGenerator, SlideHTMLGenerator, wrap_slide_html

outline = {...}  # Your outline data
html_slides = [wrap_slide_html(SlideHTMLGenerator.generate_slide_html(s))
               for s in outline['presentation']['slides']]
await PowerPointGenerator().create_powerpoint(html_slides, "output.pptx")
```

---

### 2. presentation_generator Pipeline

**What it does**: Generates presentations from user input using OpenAI.

**Features**:
- Automatic outline generation with LLM
- Uses OpenAI GPT-4
- Integrates slide_generator internally
- Backwards compatible

**Use when**:
- Want automatic content generation
- Have OpenAI API access
- Building a web app with user input
- Want the "batteries included" solution

**Installation**:
```bash
pip install openai requests playwright python-pptx pillow
playwright install chromium
export OPENAI_API_KEY="sk-..."
```

**Usage**:
```python
from presentation_generator import PresentationGenerator

gen = PresentationGenerator(api_key="sk-...")
html, outline = await gen.generate_presentation(
    user_input="Create a presentation about AI",
    num_slides=6
)
await gen.create_powerpoint(html, "output.pptx")
```

---

## 8 Professional Slide Layouts

All slides are generated with professional styling, company logo, and slide numbers:

1. **Title** - Gradient background
2. **Content** - Formatted text
3. **Two Column** - Side-by-side comparison
4. **Image** - Full-slide image/SVG
5. **Image + Text** - Image left, text right
6. **Bullets** - Key points with nesting
7. **Quote** - Inspirational quotes
8. **Chart** - Chart.js data visualization

---

## Examples

### Standalone (No LLM)

```bash
python example_slide_generator_standalone.py
```

Creates `cloud_computing_presentation.pptx` without needing an API key.

### Full Pipeline (With LLM)

```bash
export OPENAI_API_KEY="sk-..."
python example_complete_pipeline_with_llm.py
```

Creates `ai_healthcare_presentation.pptx` with LLM-generated content.

---

## Documentation

| Document | Purpose |
|----------|---------|
| [QUICK_START.md](QUICK_START.md) | Get started quickly (installation, examples, troubleshooting) |
| [README_SLIDE_GENERATOR.md](README_SLIDE_GENERATOR.md) | Complete slide_generator documentation (API, layouts, customization) |
| [ARCHITECTURE.md](ARCHITECTURE.md) | Design guide (component interaction, when to use each, data flow) |
| [REFACTORING_SUMMARY.md](REFACTORING_SUMMARY.md) | What changed (before/after, migration guide) |
| [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md) | Complete project overview |

---

## File Structure

```
project/
├── slide_generator/                    # NEW: Standalone package
│   ├── __init__.py                    # Public API
│   ├── html_generator.py              # HTML generation
│   └── powerpoint_generator.py        # PowerPoint creation
│
├── presentation_generator.py          # UPDATED: Uses slide_generator
├── outline_generator.py               # LLM prompt & parsing
│
├── setup.py                           # NEW: PyPI config
│
├── example_slide_generator_standalone.py   # NEW: No LLM demo
├── example_complete_pipeline_with_llm.py   # NEW: Full pipeline demo
│
├── README.md                          # This file
├── QUICK_START.md                     # Quick start guide
├── README_SLIDE_GENERATOR.md          # Package documentation
├── ARCHITECTURE.md                    # Architecture guide
├── REFACTORING_SUMMARY.md             # What changed
└── PROJECT_SUMMARY.md                 # Complete overview
```

---

## Key Benefits

✓ **Modular** - Two independent components with clean separation

✓ **Reusable** - slide_generator works with any outline source

✓ **Shareable** - Can be published to PyPI independently

✓ **Flexible** - Use standalone or with LLM

✓ **Documented** - 5 comprehensive guides + examples

✓ **Backwards Compatible** - Existing code still works

---

## Performance

| Metric | Standalone | With LLM |
|--------|-----------|----------|
| 6 slides | ~15-18s | ~20-25s |
| Memory | ~15 MB | ~20 MB |
| Output size | ~0.7 MB | ~0.7 MB |

---

## Getting Started

1. **Choose your path**:
   - Just need PowerPoint? → Use `slide_generator` standalone
   - Want LLM? → Use `presentation_generator`

2. **Read the docs**:
   - Start with [QUICK_START.md](QUICK_START.md)
   - Then specific guide for your use case

3. **Run an example**:
   ```bash
   # Standalone (no API key)
   python example_slide_generator_standalone.py

   # Full pipeline (requires OPENAI_API_KEY)
   export OPENAI_API_KEY="sk-..."
   python example_complete_pipeline_with_llm.py
   ```

4. **Open the PowerPoint**:
   - Check the generated `.pptx` file
   - Verify layouts and styling

5. **Integrate or publish**:
   - Use in your application
   - Publish slide_generator to PyPI
   - Share with others

---

## Publishing to PyPI

To share `slide_generator` as a Python package:

```bash
# Build
python -m build

# Upload
python -m twine upload dist/*

# Others install with:
pip install slide-generator
```

---

## Support

For questions about:
- **Getting started** → [QUICK_START.md](QUICK_START.md)
- **slide_generator API** → [README_SLIDE_GENERATOR.md](README_SLIDE_GENERATOR.md)
- **Architecture & design** → [ARCHITECTURE.md](ARCHITECTURE.md)
- **What changed** → [REFACTORING_SUMMARY.md](REFACTORING_SUMMARY.md)
- **Complete overview** → [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md)

---

## Use Cases

- **Batch PowerPoint generation** from outline lists
- **Web applications** with user input
- **CMS integration** for automatic presentations
- **Custom LLM integration** (Claude, Gemini, local models)
- **Template-based presentations** with customization
- **API endpoints** for PowerPoint creation
- **Standalone package** distribution via PyPI

---

## Summary

This is a professional, production-ready presentation generation system that:

✓ Separates outline generation from PowerPoint creation
✓ Can be used with any outline source (no vendor lock-in)
✓ Includes comprehensive documentation
✓ Has working examples for both use cases
✓ Is backwards compatible with existing code
✓ Is ready to publish as a standalone package

**Choose your component and start generating presentations!**

---

**Version**: 1.0.0
**Status**: Production Ready
**Last Updated**: November 24, 2024
