# Architecture Overview

This project is divided into two main components that can be used independently or together:

## 1. Presentation Generator (LLM-based)

**Purpose**: User input → OpenAI → Outline → PowerPoint

**Files**:
- `presentation_generator.py` - Main orchestrator for the full pipeline
- `outline_generator.py` - Prompt engineering and outline parsing
- `example_complete_pipeline_with_llm.py` - Complete example with LLM

**Dependencies**:
- OpenAI API (requires API key)
- requests library
- slide_generator package

**Use this when**:
- You want automatic outline generation from user input
- You're building a web app that takes user descriptions
- You need natural language interface to presentations
- You want content generation assistance

**Example**:
```python
from presentation_generator import PresentationGenerator

generator = PresentationGenerator(api_key="your-key")
html_slides, outline = await generator.generate_presentation(
    user_input="Create a presentation about AI",
    num_slides=6
)
pptx_path = await generator.create_powerpoint(html_slides, "output.pptx")
```

---

## 2. Slide Generator (Isolated Package)

**Purpose**: Outline → HTML → PowerPoint (NO LLM)

**Files**:
- `slide_generator/__init__.py` - Package initialization
- `slide_generator/html_generator.py` - HTML template generation
- `slide_generator/powerpoint_generator.py` - HTML to PowerPoint conversion
- `setup.py` - Package setup for distribution
- `README_SLIDE_GENERATOR.md` - Complete package documentation
- `example_slide_generator_standalone.py` - Standalone example

**Dependencies**:
- playwright (for HTML rendering)
- python-pptx (for PowerPoint creation)
- pillow (for image compression)
- NO OpenAI or LLM dependencies

**Use this when**:
- You already have presentation outlines
- You're using a different LLM provider (Claude, Gemini, etc.)
- You're loading outlines from files, databases, or APIs
- You want a standalone, shareable package
- You're integrating presentations into another system
- You want zero external API dependencies

**Example**:
```python
from slide_generator import PowerPointGenerator, SlideHTMLGenerator, wrap_slide_html

# Define your outline (from anywhere)
outline = {...}

# Generate HTML
html_slides = [wrap_slide_html(SlideHTMLGenerator.generate_slide_html(slide))
               for slide in outline['presentation']['slides']]

# Create PowerPoint
generator = PowerPointGenerator()
await generator.create_powerpoint(html_slides, "output.pptx")
```

---

## Component Interaction

```
┌─────────────────────────────────────────────────────────────┐
│          User Input / Outline / API Response                │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
         ┌──────────────────────────────┐
         │  presentation_generator.py   │ (Optional - with LLM)
         │  ├─ Outline Generation       │
         │  └─ Uses slide_generator     │
         │     internally               │
         └────────┬─────────────────────┘
                  │
                  ▼
    ┌─────────────────────────────────┐
    │  slide_generator (Package)      │
    │  ├─ HTML Generation             │
    │  │  └─ 8 Professional Layouts   │
    │  └─ PowerPoint Generation       │
    │     ├─ Playwright HTML→Image    │
    │     ├─ PIL Image Compression    │
    │     └─ python-pptx Embedding    │
    └────────────┬────────────────────┘
                 │
                 ▼
        ┌────────────────┐
        │  output.pptx   │
        └────────────────┘
```

---

## Two Usage Patterns

### Pattern 1: Complete Pipeline (with LLM)

```python
# User enters description → LLM generates outline → PowerPoint created
from presentation_generator import PresentationGenerator

generator = PresentationGenerator(api_key="openai-key")
html, outline = await generator.generate_presentation(
    user_input="Create a presentation about...",
    num_slides=6
)
await generator.create_powerpoint(html, "output.pptx")
```

**Pros**:
- Simple, all-in-one solution
- Natural language input
- Automatic content generation

**Cons**:
- Requires OpenAI API key
- Slower (network + generation)
- Higher cost per presentation

---

### Pattern 2: Standalone Generator (no LLM)

```python
# Outline from any source → PowerPoint created
from slide_generator import PowerPointGenerator, SlideHTMLGenerator, wrap_slide_html

# Get outline from: file, database, API, manual input, etc.
outline = {...}

# Generate HTML
html_slides = [wrap_slide_html(SlideHTMLGenerator.generate_slide_html(s))
               for s in outline['presentation']['slides']]

# Create PowerPoint
gen = PowerPointGenerator()
await gen.create_powerpoint(html_slides, "output.pptx")
```

**Pros**:
- No external API dependencies
- Fast (local processing only)
- Shareable as standalone package
- Works with any outline source

**Cons**:
- Requires outline structure
- Need to generate content elsewhere

---

## File Organization

```
presentation/
├── slide_generator/          # Standalone package (can be published to PyPI)
│   ├── __init__.py
│   ├── html_generator.py     # HTML slide generation
│   ├── powerpoint_generator.py # HTML→PowerPoint conversion
│   └── py.typed             # PEP 561 type hints marker
│
├── setup.py                  # Package distribution config
├── README_SLIDE_GENERATOR.md # Package documentation
│
├── presentation_generator.py # LLM pipeline orchestrator
├── outline_generator.py      # Outline generation & parsing
│
├── example_slide_generator_standalone.py    # Standalone demo
├── example_complete_pipeline_with_llm.py    # Full pipeline demo
├── example_full_pipeline.py                  # Original demo
│
└── ARCHITECTURE.md           # This file
```

---

## When to Use Each Component

| Use Case | Component | Pattern |
|----------|-----------|---------|
| Web app with user input | presentation_generator.py | Pattern 1 |
| Desktop app with text input | presentation_generator.py | Pattern 1 |
| Batch generate from outline list | slide_generator | Pattern 2 |
| Integrate with custom LLM | slide_generator | Pattern 2 |
| Share as Python package | slide_generator | Pattern 2 |
| API endpoint for PowerPoint | slide_generator | Pattern 2 |
| Automatic content generation | presentation_generator.py | Pattern 1 |
| Template-based presentations | slide_generator | Pattern 2 |
| CMS integration | slide_generator | Pattern 2 |
| No API key available | slide_generator | Pattern 2 |

---

## Packaging & Distribution

### For Users of slide_generator

```bash
# Install from PyPI (when published)
pip install slide-generator

# Or install locally for development
cd presentation
pip install -e .
```

Then use independently:

```python
from slide_generator import PowerPointGenerator, SlideHTMLGenerator

# No LLM dependencies needed!
```

### For Users of presentation_generator.py

This includes slide_generator, so it's a complete solution.

```bash
# Install dependencies
pip install openai playwright python-pptx pillow

# Or use the project as-is
python example_complete_pipeline_with_llm.py
```

---

## API Boundaries

### slide_generator Package API

**Public Exports**:
```python
from slide_generator import (
    SlideHTMLGenerator,      # Class for HTML generation
    wrap_slide_html,         # Function to wrap HTML in document
    PowerPointGenerator      # Class for PowerPoint creation
)
```

**Core Methods**:
```python
# Generate HTML for a slide
html = SlideHTMLGenerator.generate_slide_html(slide_dict)

# Create PowerPoint from HTML slides
pptx_path = await PowerPointGenerator().create_powerpoint(html_slides, "out.pptx")
```

### presentation_generator.py API

**Main Class**:
```python
from presentation_generator import PresentationGenerator

generator = PresentationGenerator(api_key="key", model="gpt-4-turbo")

# Generate outline and HTML slides from user input
html_slides, outline = await generator.generate_presentation(
    user_input="...",
    num_slides=6
)

# Create PowerPoint (delegates to slide_generator)
pptx_path = await generator.create_powerpoint(html_slides, "out.pptx")
```

---

## Data Flow

### Input Outline Structure

All outlines follow this JSON structure:

```json
{
  "presentation": {
    "title": "string",
    "subtitle": "string",
    "author": "string",
    "slides": [
      {
        "slide_number": 1,
        "layout": "title|content|...",
        "title": "string",
        "subtitle": "string (optional)",
        "content": { /* layout-specific */ }
      }
    ]
  }
}
```

### HTML Generation Flow

1. **Outline** → SlideHTMLGenerator.generate_slide_html() → **Slide HTML**
2. **Slide HTML** → wrap_slide_html() → **Complete HTML Document**
3. **HTML Document** → Playwright → **PNG Screenshot (in memory)**
4. **PNG** → PIL compression → **JPEG (in memory)**
5. **JPEG** → python-pptx → **PowerPoint Slide**

### All operations are in-memory - no files written except final .pptx!

---

## Migration Guide

If you're currently using the old single-module approach:

**Before**:
```python
from slide_templates import SlideHTMLGenerator
from pptx_generator import InMemoryPresentationGenerator
```

**After**:
```python
from slide_generator import SlideHTMLGenerator, PowerPointGenerator
```

The API is compatible, but now you can use slide_generator independently!

---

## Performance Characteristics

| Operation | Time | Memory |
|-----------|------|--------|
| Generate single slide HTML | < 100ms | ~ 1 MB |
| Render HTML to image | 2-3s | 2-3 MB |
| Compress image | 100-200ms | 1-2 MB |
| Generate outline (with LLM) | 3-5s | ~ 5 MB |
| Create PowerPoint file | < 1s | < 1 MB |
| **Total for 6 slides (with LLM)** | **~20-25s** | **~20 MB peak** |
| **Total for 6 slides (no LLM)** | **~15-18s** | **~15 MB peak** |

---

## Future Enhancement Ideas

1. **Multiple LLM Support**
   - Anthropic Claude
   - Google Gemini
   - Open source models

2. **Advanced Features**
   - Custom themes/branding
   - Animation support
   - Speaker notes generation
   - PDF export
   - Batch processing

3. **Integration Points**
   - CMS plugins
   - No-code platforms
   - API service
   - CLI tool

4. **Optimization**
   - Streaming rendering
   - Progressive compression
   - Parallel slide generation
   - Template caching

---

## Support & Questions

For questions about:
- **slide_generator package**: See `README_SLIDE_GENERATOR.md`
- **LLM pipeline**: See docstrings in `presentation_generator.py`
- **Overall architecture**: See this file

---

**Last Updated**: November 2024
**Version**: 1.0.0
