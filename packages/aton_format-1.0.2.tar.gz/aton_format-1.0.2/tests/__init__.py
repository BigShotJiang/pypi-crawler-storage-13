"""Tests for ATON package."""
