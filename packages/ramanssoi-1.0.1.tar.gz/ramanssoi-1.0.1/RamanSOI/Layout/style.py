"""
module for the button styles
"""


def checkbox_style_num_slot():
    return """
        QCheckBox {
            font-size: 16px;
            spacing: 0px;
        }
        QCheckBox::indicator {
            width: 20px;
            height: 20px;
        }
        QCheckBox::indicator:checked {
            background-color: #E6E6FA; 
            border: 2px solid black;
        }
        QCheckBox::indicator:unchecked {
            background-color: white;
            border: 2px solid #ccc;
        }
    """

def checkbox_style():
    return """
        QCheckBox {
            font-size: 16px;
            spacing: 0px;
        }
        QCheckBox::indicator {
            width: 20px;
            height: 20px;
        }
        QCheckBox::indicator:checked {
            background-color: #f0ca41; 
            border: 2px solid black;
        }
        QCheckBox::indicator:unchecked {
            background-color: white;
            border: 2px solid #ccc;
        }
    """


def common_radiobutton_style():
    return """
        QRadioButton {
            spacing: 0px;
            font-size: 14px;
        }
        QRadioButton::indicator {
            width: 20px;
            height: 20px;
        }
        QRadioButton::indicator:checked {
            background-color: #f0ca41;
            border: 2px solid black;
        }
        QRadioButton::indicator:unchecked {
            background-color: white;
            border: 2px solid #ccc;
        }
    """


def settings_button_style():
    return """
        QPushButton {
            font-size: 16px;
            background-color: #b3e5fc; 
            border: 2px solid #8c8c8c;
            border-radius: 10px; 
            padding: 10px;
        }
        QPushButton:hover {
            background-color: #64b5f6; 
        }
    """


def open_fitspy_button_style():
    return """
        QPushButton {
            font-size: 16px;
            background-color: #ffcccc;
            border: 2px solid #8c8c8c;
            border-radius: 10px;
            padding: 10px;
        }
        QPushButton:hover {
            background-color: #ff9999;
        }
    """


def run_button_style():
    return """
        QPushButton {
            font-size: 16px;
            background-color: #ffcc80;
            border: 2px solid #8c8c8c;
            border-radius: 10px;
            padding: 5px;
        }
        QPushButton:hover {
            background-color: #ffb74d;
        }
    """


def group_box_style():
    return """
        QGroupBox {
            border: 1px solid black;
            border-radius: 5px;
            margin-top: 10px;
            font-size: 20px;
            font-weight: bold;
        }
        QGroupBox::title {
            font-size: 14px; 
            font-weight: bold;
            subcontrol-origin: margin;
            subcontrol-position: top center;
        }
    """
