"""
Tests for SpeechBridge Components
==================================

Tests for Speech, Translation, TTS, and Video components
"""

import pytest
import sys
from pathlib import Path

# Add speechbridge to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from speechbridge.components.speech import BaseSpeechRecognizer, WhisperRecognizer
from speechbridge.core.exceptions import ComponentException


class TestBaseSpeechRecognizer:
    """Tests for BaseSpeechRecognizer"""

    class DummyRecognizer(BaseSpeechRecognizer):
        """Test implementation of speech recognizer"""

        def initialize(self):
            self._initialized = True

        def transcribe(self, audio_path: str):
            return {
                'text': 'dummy transcription',
                'language': 'en',
                'confidence': 0.95
            }

    def test_recognizer_creation(self):
        """Test recognizer creation"""
        recognizer = self.DummyRecognizer()
        assert recognizer is not None
        assert isinstance(recognizer, BaseSpeechRecognizer)

    def test_recognizer_config(self):
        """Test recognizer configuration"""
        config = {
            'language': 'ru',
            'confidence_threshold': 0.8,
            'use_gpu': True
        }
        recognizer = self.DummyRecognizer(config)

        assert recognizer.language == 'ru'
        assert recognizer.confidence_threshold == 0.8

    def test_recognizer_validate_config(self):
        """Test configuration validation"""
        recognizer = self.DummyRecognizer()
        assert recognizer.validate_config() is True

        # Invalid threshold
        recognizer2 = self.DummyRecognizer({'confidence_threshold': 1.5})
        assert recognizer2.validate_config() is False

    def test_recognizer_info(self):
        """Test getting recognizer info"""
        recognizer = self.DummyRecognizer()
        info = recognizer.get_info()

        assert 'name' in info
        assert 'language' in info
        assert 'confidence_threshold' in info
        assert 'gpu_enabled' in info


class TestWhisperRecognizer:
    """Tests for WhisperRecognizer"""

    def test_whisper_creation(self):
        """Test Whisper recognizer creation"""
        recognizer = WhisperRecognizer()
        assert recognizer is not None
        assert isinstance(recognizer, WhisperRecognizer)
        assert isinstance(recognizer, BaseSpeechRecognizer)

    def test_whisper_model_config(self):
        """Test Whisper model configuration"""
        config = {'model': 'small', 'language': 'en'}
        recognizer = WhisperRecognizer(config)

        assert recognizer.model_name == 'small'
        assert recognizer.language == 'en'

    def test_whisper_invalid_model(self):
        """Test invalid model handling"""
        config = {'model': 'invalid_model'}
        recognizer = WhisperRecognizer(config)

        # Should fallback to 'base'
        assert recognizer.model_name == 'base'

    def test_whisper_supported_languages(self):
        """Test supported languages"""
        recognizer = WhisperRecognizer()
        languages = recognizer.get_supported_languages()

        assert isinstance(languages, list)
        assert len(languages) > 90  # Whisper supports 99+ languages
        assert 'en' in languages
        assert 'ru' in languages
        assert 'auto' in languages

    def test_whisper_validate_config(self):
        """Test Whisper configuration validation"""
        recognizer = WhisperRecognizer({'model': 'base'})
        assert recognizer.validate_config() is True

        # Invalid task
        recognizer2 = WhisperRecognizer({'task': 'invalid_task'})
        assert recognizer2.validate_config() is False

    def test_whisper_info(self):
        """Test Whisper info"""
        recognizer = WhisperRecognizer({'model': 'small'})
        info = recognizer.get_info()

        assert info['name'] == 'WhisperRecognizer'
        assert info['model'] == 'small'
        assert 'num_supported_languages' in info


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
