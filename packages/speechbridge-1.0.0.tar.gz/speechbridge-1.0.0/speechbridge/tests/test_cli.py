"""
Tests for SpeechBridge CLI
===========================

Tests for command-line interface.
"""

import pytest
import sys
from pathlib import Path
from click.testing import CliRunner

# Add speechbridge to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from speechbridge.cli.main import cli


class TestCLI:
    """Tests for CLI commands"""

    def setup_method(self):
        """Setup test environment"""
        self.runner = CliRunner()

    def test_cli_help(self):
        """Test CLI help command"""
        result = self.runner.invoke(cli, ['--help'])
        assert result.exit_code == 0
        assert 'SpeechBridge' in result.output
        assert 'translate' in result.output
        assert 'batch' in result.output
        assert 'info' in result.output

    def test_cli_version(self):
        """Test CLI version command"""
        result = self.runner.invoke(cli, ['--version'])
        assert result.exit_code == 0
        assert 'SpeechBridge' in result.output
        assert '1.0.0' in result.output

    def test_cli_info(self):
        """Test info command"""
        result = self.runner.invoke(cli, ['info'])
        assert result.exit_code == 0
        assert 'GPU Information' in result.output
        assert 'Optimal device' in result.output

    def test_translate_help(self):
        """Test translate command help"""
        result = self.runner.invoke(cli, ['translate', '--help'])
        assert result.exit_code == 0
        assert 'Translate a video' in result.output
        assert '--model' in result.output
        assert '--target-lang' in result.output

    def test_batch_help(self):
        """Test batch command help"""
        result = self.runner.invoke(cli, ['batch', '--help'])
        assert result.exit_code == 0
        assert 'multiple videos' in result.output
        assert '--pattern' in result.output

    def test_analyze_help(self):
        """Test analyze command help"""
        result = self.runner.invoke(cli, ['analyze', '--help'])
        assert result.exit_code == 0
        assert 'Analyze a video' in result.output


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
