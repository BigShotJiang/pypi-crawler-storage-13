"""
Original Video Translator Wrapper - Обертка для оригинального video_translator.py
"""

import sys
from pathlib import Path
from typing import Dict, Any, Optional
from ..core import FrameworkComponent, ProcessingContext

# Импорт оригинального модуля
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

try:
    # Импорт из src/video_translator.py
    sys.path.insert(0, str(project_root / "src"))
    from video_translator import translate_video
    ORIGINAL_TRANSLATOR_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Original video_translator not available: {e}")
    ORIGINAL_TRANSLATOR_AVAILABLE = False

class OriginalVideoTranslatorComponent(FrameworkComponent):
    """Компонент-обертка для оригинального video_translator.py"""

    def __init__(self, name: str = "original_video_translator", config: Dict[str, Any] = None):
        super().__init__(name, config)

    def initialize(self) -> bool:
        """Инициализация компонента"""
        if not super().initialize():
            return False

        if not ORIGINAL_TRANSLATOR_AVAILABLE:
            self.logger.error("Original video_translator module not available")
            return False

        self.logger.info("Original video_translator wrapper initialized")
        return True

    def validate_config(self) -> bool:
        """Валидация конфигурации"""
        if not super().validate_config():
            return False

        return True

    def process(self, context: ProcessingContext) -> ProcessingContext:
        """Обработка: полный перевод видео через оригинальную систему"""
        if not ORIGINAL_TRANSLATOR_AVAILABLE:
            raise RuntimeError("Original video_translator module not available")

        input_file = context.input_file
        if not input_file.exists():
            raise FileNotFoundError(f"Input video file not found: {input_file}")

        self.logger.info(f"🎬 Starting original video translation: {input_file}")

        try:
            # Колбэк для обновления прогресса
            def progress_callback(stage, progress):
                if context.progress_callback:
                    context.progress_callback(f"Original System: {stage}", progress)

            # Подготавливаем параметры
            input_video = str(context.input_file)
            output_video = str(context.output_file)
            source_lang = context.source_language if context.source_language != 'auto' else 'en'
            target_lang = context.target_language

            self.logger.info(f"📊 Translation parameters:")
            self.logger.info(f"  Input: {input_video}")
            self.logger.info(f"  Output: {output_video}")
            self.logger.info(f"  Languages: {source_lang} -> {target_lang}")

            if context.progress_callback:
                context.progress_callback("Original System: Starting translation", 10)

            # Вызываем оригинальную функцию перевода
            result = translate_video(
                input_video=input_video,
                output_video=output_video,
                source_language=source_lang,
                target_language=target_lang,
                custom_output_dir=str(context.output_file.parent),
                use_gpu=self.config.get('use_gpu', True),
                preserve_original_audio=self.config.get('preserve_original_audio', False),
                generate_subtitles=self.config.get('generate_subtitles', True),
                whisper_model=self.config.get('whisper_model', 'base'),
                tts_engine=self.config.get('tts_engine', 'auto')
            )

            if context.progress_callback:
                context.progress_callback("Original System: Completed", 100)

            if result:
                self.logger.info("✅ Original video translation completed successfully")

                # Обновляем метаданные контекста
                context.metadata['original_system_result'] = result
                context.metadata['processing_method'] = 'original_video_translator'

                # Проверяем что выходной файл создан
                if context.output_file.exists():
                    file_size = context.output_file.stat().st_size / (1024*1024)  # MB
                    self.logger.info(f"📁 Output file created: {context.output_file} ({file_size:.1f} MB)")
                else:
                    self.logger.warning("Output file was not created by original system")

            else:
                raise RuntimeError("Original video_translator returned False")

        except Exception as e:
            self.logger.error(f"Original video translation failed: {e}")
            raise

        return context