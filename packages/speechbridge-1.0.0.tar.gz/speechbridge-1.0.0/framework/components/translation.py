"""
Translation Component - Компонент перевода текста
"""

import sys
from pathlib import Path
from typing import Dict, Any, Optional
from ..core import FrameworkComponent, ProcessingContext

# Импорт существующих модулей
project_root = Path(__file__).parent.parent.parent
src_path = project_root / "src"
sys.path.insert(0, str(src_path))

try:
    from translator_compat import translate_text, get_translator_status, get_language_info
    TRANSLATOR_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Translator not available: {e}")
    TRANSLATOR_AVAILABLE = False

class TranslationComponent(FrameworkComponent):
    """Компонент перевода текста"""

    def __init__(self, name: str = "translation", config: Dict[str, Any] = None):
        super().__init__(name, config)
        self.service = self.config.get('service', 'deepl')
        self.api_key = self.config.get('api_key')

    def initialize(self) -> bool:
        """Инициализация компонента"""
        if not super().initialize():
            return False

        if not TRANSLATOR_AVAILABLE:
            self.logger.error("Translator module not available")
            return False

        try:
            # Проверяем доступность сервиса
            status = get_translator_status()
            if not status.get('working', False):
                self.logger.warning(f"Translation service {self.service} may not be available")

            self.logger.info(f"Initialized translation service: {self.service}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to initialize translation service: {e}")
            return False

    def validate_config(self) -> bool:
        """Валидация конфигурации"""
        if not super().validate_config():
            return False

        service = self.config.get('service', 'deepl')
        valid_services = ['deepl', 'google', 'libre']

        if service not in valid_services:
            self.logger.error(f"Invalid translation service: {service}. Valid options: {valid_services}")
            return False

        # Проверяем API ключ для DeepL
        if service == 'deepl' and not self.config.get('api_key'):
            self.logger.warning("DeepL API key not provided - translation may fail")

        return True

    def process(self, context: ProcessingContext) -> ProcessingContext:
        """Обработка: перевод текста"""
        if not TRANSLATOR_AVAILABLE:
            raise RuntimeError("Translator module not available")

        # Получаем текст для перевода
        text_to_translate = context.transcription
        if not text_to_translate:
            raise ValueError("No text found for translation in context")

        source_lang = context.source_language
        target_lang = context.target_language

        self.logger.info(f"Translating text: {len(text_to_translate)} characters")
        self.logger.info(f"Translation: {source_lang} -> {target_lang}")

        try:
            # Колбэк для обновления прогресса
            def progress_callback(stage, progress):
                if context.progress_callback:
                    context.progress_callback(f"Translation: {stage}", progress)

            # Настройки перевода
            translation_settings = {
                'service': self.service,
                'chunk_size': self.config.get('chunk_size', 1000),
                'preserve_formatting': self.config.get('preserve_formatting', True)
            }

            if self.api_key:
                translation_settings['api_key'] = self.api_key

            # Выполняем перевод
            if context.progress_callback:
                context.progress_callback("Translation: Starting translation", 10)

            translated_text = translate_text(
                text=text_to_translate,
                src_lang=source_lang if source_lang != 'auto' else 'en',
                dest_lang=target_lang
            )

            if context.progress_callback:
                context.progress_callback("Translation: Completed", 100)

            if not translated_text:
                raise RuntimeError("Translation failed - no text returned")

            # Сохраняем результат перевода
            context.translation = translated_text

            # Сохраняем метаданные перевода
            context.metadata['translation'] = {
                'service_used': self.service,
                'source_language': source_lang,
                'target_language': target_lang,
                'original_length': len(text_to_translate),
                'translated_length': len(translated_text),
                'settings': translation_settings
            }

            # Если есть временные метки, переводим их тоже
            if context.timestamps:
                self._translate_timestamps(context, translated_text)

            self.logger.info(f"Translation completed. Result length: {len(translated_text)} characters")

        except Exception as e:
            self.logger.error(f"Translation failed: {e}")
            raise

        return context

    def _translate_timestamps(self, context: ProcessingContext, full_translation: str):
        """Перевод текста с временными метками"""
        try:
            timestamps = context.timestamps
            if not timestamps:
                return

            # Простое разделение перевода по количеству сегментов
            # В более сложной реализации можно использовать выравнивание
            segments = full_translation.split('. ')

            for i, timestamp in enumerate(timestamps):
                if i < len(segments):
                    timestamp['translated_text'] = segments[i].strip()
                    if not timestamp['translated_text'].endswith('.'):
                        timestamp['translated_text'] += '.'
                else:
                    # Если сегментов меньше, используем полный перевод
                    timestamp['translated_text'] = full_translation

            context.metadata['timestamps_translated'] = True
            self.logger.info(f"Translated {len(timestamps)} timestamp segments")

        except Exception as e:
            self.logger.warning(f"Failed to translate timestamps: {e}")
            # Устанавливаем полный перевод для всех сегментов
            for timestamp in context.timestamps:
                timestamp['translated_text'] = full_translation

    def get_supported_languages(self, service: str = None) -> Dict[str, list]:
        """Получение поддерживаемых языков"""
        service = service or self.service

        # Базовые языки, поддерживаемые большинством сервисов
        common_languages = {
            'source': ['en', 'ru', 'es', 'fr', 'de', 'it', 'pt', 'zh', 'ja', 'ko', 'auto'],
            'target': ['en', 'ru', 'es', 'fr', 'de', 'it', 'pt', 'zh', 'ja', 'ko']
        }

        if service == 'deepl':
            return {
                'source': [
                    'BG', 'CS', 'DA', 'DE', 'EL', 'EN', 'ES', 'ET', 'FI', 'FR',
                    'HU', 'ID', 'IT', 'JA', 'KO', 'LT', 'LV', 'NB', 'NL', 'PL',
                    'PT', 'RO', 'RU', 'SK', 'SL', 'SV', 'TR', 'UK', 'ZH'
                ],
                'target': [
                    'BG', 'CS', 'DA', 'DE', 'EL', 'EN-GB', 'EN-US', 'ES', 'ET',
                    'FI', 'FR', 'HU', 'ID', 'IT', 'JA', 'KO', 'LT', 'LV', 'NB',
                    'NL', 'PL', 'PT-BR', 'PT-PT', 'RO', 'RU', 'SK', 'SL', 'SV',
                    'TR', 'UK', 'ZH'
                ]
            }
        elif service == 'google':
            # Google Translate поддерживает больше языков
            return {
                'source': common_languages['source'] + [
                    'ar', 'hi', 'th', 'vi', 'nl', 'pl', 'tr', 'uk', 'cs', 'da',
                    'fi', 'no', 'sv', 'he', 'fa', 'ur', 'bn', 'ta', 'te', 'ml'
                ],
                'target': common_languages['target'] + [
                    'ar', 'hi', 'th', 'vi', 'nl', 'pl', 'tr', 'uk', 'cs', 'da',
                    'fi', 'no', 'sv', 'he', 'fa', 'ur', 'bn', 'ta', 'te', 'ml'
                ]
            }
        else:
            return common_languages

    def get_service_info(self) -> Dict[str, Any]:
        """Получение информации о сервисе перевода"""
        try:
            status = get_translator_status()
            language_info = get_language_info(self.config.get('target_language', 'ru'))

            return {
                'service': self.service,
                'status': status,
                'supported_languages': language_info,
                'config': self.config
            }
        except Exception as e:
            return {
                'service': self.service,
                'error': str(e),
                'config': self.config
            }