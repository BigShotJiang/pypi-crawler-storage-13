"""
Framework Components - Компоненты фреймворка

Этот модуль содержит все основные компоненты для обработки видео:
- VideoComponent: Обработка видео файлов
- SpeechComponent: Распознавание речи
- TranslationComponent: Перевод текста
- TTSComponent: Синтез речи
"""

from .video import VideoExtractionComponent, VideoAssemblyComponent
from .speech import SpeechRecognitionComponent
from .translation import TranslationComponent
from .tts import SpeechSynthesisComponent

__all__ = [
    'VideoExtractionComponent',
    'VideoAssemblyComponent',
    'SpeechRecognitionComponent',
    'TranslationComponent',
    'SpeechSynthesisComponent'
]