"""
Video-Translator Framework
==========================

Модульный фреймворк для создания приложений перевода видео

Основные компоненты:
- Core: Базовые модули обработки
- Engines: Различные движки для распознавания речи и синтеза
- Plugins: Расширяемые плагины
- Services: Сервисы высокого уровня
- API: RESTful и WebSocket интерфейсы
- UI: Пользовательские интерфейсы
"""

__version__ = "1.0.0"
__author__ = "Video-Translator Team"

# Основные импорты фреймворка
from .core import FrameworkCore
from .builder import VideoTranslatorBuilder
from .pipeline import ProcessingPipeline
from .config import FrameworkConfig

# Быстрый старт
def create_translator(**kwargs):
    """
    Быстрое создание переводчика с настройками по умолчанию

    Args:
        **kwargs: Параметры конфигурации

    Returns:
        VideoTranslatorBuilder: Настроенный экземпляр переводчика
    """
    return VideoTranslatorBuilder().with_default_config(**kwargs)

def create_pipeline(*steps):
    """
    Создание кастомного пайплайна обработки

    Args:
        *steps: Этапы обработки

    Returns:
        ProcessingPipeline: Настроенный пайплайн
    """
    return ProcessingPipeline(steps)

# Экспорт основных классов
__all__ = [
    'FrameworkCore',
    'VideoTranslatorBuilder',
    'ProcessingPipeline',
    'FrameworkConfig',
    'create_translator',
    'create_pipeline'
]