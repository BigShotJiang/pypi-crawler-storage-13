"""
Model Evaluator
===============

This module provides comprehensive model evaluation functionality.
"""

import logging
import json
from pathlib import Path
from typing import Dict, Any, Optional, List
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline

from .metrics import MetricsCalculator

logger = logging.getLogger(__name__)


class ModelEvaluator:
    """
    Evaluates machine learning models on various datasets.
    """
    
    LABEL_MAP = {0: "negative", 2: "neutral", 4: "positive"}
    
    def __init__(self, model: Pipeline, label_names: Optional[List[str]] = None):
        """
        Initialize the model evaluator.
        
        Args:
            model: Trained model pipeline
            label_names: Optional list of label names
        """
        self.model = model
        self.label_names = label_names
        self.metrics_calculator = MetricsCalculator(label_names=label_names)
        self.evaluation_results: Dict[str, Any] = {}
    
    def evaluate(
        self,
        X: list,
        y_true: np.ndarray,
        dataset_name: str = "test"
    ) -> Dict[str, Any]:
        """
        Evaluate the model on a dataset.
        
        Args:
            X: List of texts
            y_true: True labels
            dataset_name: Name of the dataset (e.g., 'test', 'validation')
            
        Returns:
            Dictionary containing evaluation metrics
        """
        logger.info(f"Evaluating model on {dataset_name} dataset ({len(X)} samples)...")
        
        # Make predictions
        y_pred = self.model.predict(X)
        
        # Calculate metrics
        metrics = self.metrics_calculator.calculate_metrics(y_true, y_pred)
        
        # Get classification report
        report = self.metrics_calculator.get_classification_report(y_true, y_pred)
        
        # Store results
        self.evaluation_results[dataset_name] = {
            "metrics": metrics,
            "classification_report": report,
            "predictions": y_pred.tolist()
        }
        
        logger.info(f"Evaluation completed for {dataset_name} dataset")
        
        return metrics
    
    def evaluate_multiple_datasets(
        self,
        datasets: Dict[str, tuple]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Evaluate the model on multiple datasets.
        
        Args:
            datasets: Dictionary mapping dataset names to (X, y) tuples
            
        Returns:
            Dictionary containing evaluation results for each dataset
        """
        all_results = {}
        
        for dataset_name, (X, y) in datasets.items():
            metrics = self.evaluate(X, y, dataset_name)
            all_results[dataset_name] = metrics
        
        return all_results
    
    def find_errors(
        self,
        X: list,
        y_true: np.ndarray,
        n_samples: int = 10
    ) -> pd.DataFrame:
        """
        Find and return misclassified examples.
        
        Args:
            X: List of texts
            y_true: True labels
            n_samples: Number of error samples to return
            
        Returns:
            DataFrame with error samples
        """
        logger.info(f"Finding misclassified examples...")
        
        y_pred = self.model.predict(X)
        
        # Find misclassified indices
        error_indices = np.where(y_true != y_pred)[0]
        
        logger.info(f"Found {len(error_indices)} misclassifications")
        
        if len(error_indices) == 0:
            return pd.DataFrame()
        
        # Sample errors
        sample_size = min(n_samples, len(error_indices))
        sampled_indices = np.random.choice(error_indices, size=sample_size, replace=False)
        
        # Create DataFrame with error information
        errors_df = pd.DataFrame({
            "text": [X[i] for i in sampled_indices],
            "true_label": [self.LABEL_MAP.get(y_true[i], str(y_true[i])) for i in sampled_indices],
            "predicted_label": [self.LABEL_MAP.get(y_pred[i], str(y_pred[i])) for i in sampled_indices],
            "true_label_code": y_true[sampled_indices],
            "predicted_label_code": y_pred[sampled_indices]
        })
        
        return errors_df
    
    def save_evaluation_results(
        self,
        output_dir: Path,
        include_predictions: bool = False
    ):
        """
        Save evaluation results to files.
        
        Args:
            output_dir: Directory to save results
            include_predictions: Whether to include predictions in saved file
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        
        for dataset_name, results in self.evaluation_results.items():
            # Save metrics
            metrics_path = output_dir / f"metrics_{dataset_name}.json"
            metrics_to_save = results["metrics"].copy()
            
            if not include_predictions:
                results_copy = results.copy()
                results_copy.pop("predictions", None)
                metrics_to_save = results_copy["metrics"]
            
            with open(metrics_path, "w", encoding="utf-8") as f:
                json.dump(metrics_to_save, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Metrics saved to {metrics_path}")
            
            # Save classification report
            report_path = output_dir / f"classification_report_{dataset_name}.txt"
            with open(report_path, "w", encoding="utf-8") as f:
                f.write(results["classification_report"])
            
            logger.info(f"Classification report saved to {report_path}")
    
    def generate_evaluation_report(self) -> str:
        """
        Generate a comprehensive evaluation report.
        
        Returns:
            Formatted evaluation report
        """
        report = "# Model Evaluation Report\n\n"
        
        for dataset_name, results in self.evaluation_results.items():
            metrics = results["metrics"]
            
            report += f"## {dataset_name.upper()} Dataset\n\n"
            report += self.metrics_calculator.format_metrics_report(metrics)
            report += "\n### Classification Report\n```\n"
            report += results["classification_report"]
            report += "\n```\n\n"
        
        return report
    
    def validate_business_requirements(
        self,
        min_accuracy: float = 0.75,
        min_f1: float = 0.75
    ) -> Dict[str, bool]:
        """
        Validate if model meets business requirements.
        
        Args:
            min_accuracy: Minimum required accuracy
            min_f1: Minimum required F1 score
            
        Returns:
            Dictionary with validation results for each dataset
        """
        validation_results = {}
        
        for dataset_name, results in self.evaluation_results.items():
            metrics = results["metrics"]
            
            meets_accuracy = metrics["accuracy"] >= min_accuracy
            meets_f1 = metrics["f1_macro"] >= min_f1
            
            validation_results[dataset_name] = {
                "meets_requirements": meets_accuracy and meets_f1,
                "accuracy": metrics["accuracy"],
                "f1_macro": metrics["f1_macro"],
                "meets_accuracy": meets_accuracy,
                "meets_f1": meets_f1
            }
            
            logger.info(
                f"{dataset_name} - "
                f"Accuracy: {metrics['accuracy']:.4f} ({'✓' if meets_accuracy else '✗'} >= {min_accuracy}), "
                f"F1: {metrics['f1_macro']:.4f} ({'✓' if meets_f1 else '✗'} >= {min_f1})"
            )
        
        return validation_results


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print("ModelEvaluator module loaded successfully")
    print("Use this module to evaluate trained models")
