"""
Evaluation Phase (CRISP-DM)
============================

This module contains the evaluation phase of the CRISP-DM methodology.
It includes model evaluation, metrics calculation, and performance analysis.
"""

from .model_evaluator import ModelEvaluator
from .metrics import MetricsCalculator

__all__ = ["ModelEvaluator", "MetricsCalculator"]
