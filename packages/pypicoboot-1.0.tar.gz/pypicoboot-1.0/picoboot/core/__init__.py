from .enums import NamedIntEnum
