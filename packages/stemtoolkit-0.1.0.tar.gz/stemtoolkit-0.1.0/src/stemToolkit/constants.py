from .qtt import QTT

c = QTT(299792456, "m s^-1")
G = QTT(6.67408E-11, "m^3 kg^-1 s^-2")
F = QTT(96485.33289, "A s mol^-1")
e0 = QTT(8.854E-12, "A^2 s^2 s^2 kg^-1 m^-1 m^-2")
e = QTT(1.6021766208E-19, "A s")
Ry = QTT(10973731.568157, "m^-1")
eM = QTT(9.1093837E-31, "kg")
