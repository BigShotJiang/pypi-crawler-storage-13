import httpx
from anthropic._types import SequenceNotStr
from anthropic.types import MetadataParam, TextBlockParam, ThinkingConfigParam, ToolChoiceParam, ToolUnionParam, \
    ModelParam
from google.genai import types
from openai import NotGiven, NOT_GIVEN
from openai._types import Headers, Query, Body, FileTypes
from openai.types import ChatModel, Metadata, ReasoningEffort, ResponsesModel, Reasoning, ImageModel
from openai.types.chat import ChatCompletionMessageParam, ChatCompletionAudioParam, completion_create_params, \
    ChatCompletionPredictionContentParam, ChatCompletionStreamOptionsParam, ChatCompletionToolChoiceOptionParam, \
    ChatCompletionToolParam
from openai.types.responses import ResponseInputParam, ResponseIncludable, ResponseTextConfigParam, \
    response_create_params, ToolParam
from openai.types.responses.response_prompt_param import ResponsePromptParam
from pydantic import BaseModel, model_validator, field_validator
from typing import Any, List, Optional, Union, Iterable, Dict, Literal, Sequence

from tamar_model_client.schemas.inputs.base import UserContext, TamarFileIdInput, BaseRequest
from tamar_model_client.utils import convert_file_field, validate_fields_by_provider_and_invoke_type


class ModelRequestInput(BaseRequest):
    # 合并 model 字段
    model: Optional[Union[str, ResponsesModel, ChatModel, ImageModel, ImageModel, ModelParam]] = None

    # OpenAI Responses Input（合并）
    input: Optional[Union[str, ResponseInputParam]] = None
    include: Optional[Union[List[ResponseIncludable], NotGiven]] = NOT_GIVEN
    instructions: Optional[Union[str, NotGiven]] = NOT_GIVEN
    max_output_tokens: Optional[Union[int, NotGiven]] = NOT_GIVEN
    max_tool_calls: Optional[Union[int, NotGiven]] = NOT_GIVEN
    metadata: Optional[Union[Metadata, "MetadataParam", NotGiven]] = NOT_GIVEN
    parallel_tool_calls: Optional[Union[bool, NotGiven]] = NOT_GIVEN
    previous_response_id: Optional[Union[str, NotGiven]] = NOT_GIVEN
    prompt: Optional[Union[str, ResponsePromptParam, NotGiven]] = NOT_GIVEN
    prompt_cache_key: Optional[Union[str, NotGiven]] = NOT_GIVEN
    reasoning: Optional[Union[Reasoning, NotGiven]] = NOT_GIVEN
    safety_identifier: Optional[Union[str, NotGiven]] = NOT_GIVEN
    service_tier: Optional[
        Union[Literal["auto", "default", "flex", "scale", "priority", "standard_only"], NotGiven]  # +anthropic
    ] = NOT_GIVEN
    store: Optional[Union[bool, NotGiven]] = NOT_GIVEN
    stream: Optional[Union[Literal[False], Literal[True], NotGiven]] = NOT_GIVEN
    stream_options: Optional[
        Union[response_create_params.StreamOptions, ChatCompletionStreamOptionsParam, NotGiven]] = NOT_GIVEN
    temperature: Optional[Union[float, NotGiven]] = NOT_GIVEN
    text: Optional[Union[ResponseTextConfigParam, NotGiven]] = NOT_GIVEN
    tool_choice: Optional[
        Union[response_create_params.ToolChoice, ChatCompletionToolChoiceOptionParam, "ToolChoiceParam", NotGiven]
    ] = NOT_GIVEN
    tools: Optional[
        Union[Iterable[ToolParam], Iterable[ChatCompletionToolParam], Iterable["ToolUnionParam"], NotGiven]] = NOT_GIVEN
    top_logprobs: Optional[Union[int, NotGiven]] = NOT_GIVEN
    top_p: Optional[Union[float, NotGiven]] = NOT_GIVEN
    truncation: Optional[Union[Literal["auto", "disabled"], NotGiven]] = NOT_GIVEN
    user: Optional[Union[str, NotGiven]] = NOT_GIVEN
    verbosity: Optional[Union[Literal["low", "medium", "high"], NotGiven]] = NOT_GIVEN

    extra_headers: Optional[Union[Headers, None]] = None
    extra_query: Optional[Union[Query, None]] = None
    extra_body: Optional[Union[Body, None]] = None
    timeout: Optional[Union[float, httpx.Timeout, None, NotGiven]] = NOT_GIVEN

    # OpenAI Chat Completions Input（合并）
    messages: Optional[Iterable[ChatCompletionMessageParam]] = None
    audio: Optional[Union[ChatCompletionAudioParam, NotGiven]] = NOT_GIVEN
    frequency_penalty: Optional[Union[float, NotGiven]] = NOT_GIVEN
    function_call: Optional[Union[completion_create_params.FunctionCall, NotGiven]] = NOT_GIVEN
    functions: Optional[Union[Iterable[completion_create_params.Function], NotGiven]] = NOT_GIVEN
    logit_bias: Optional[Union[Dict[str, int], NotGiven]] = NOT_GIVEN
    logprobs: Optional[Union[bool, NotGiven]] = NOT_GIVEN
    max_completion_tokens: Optional[Union[int, NotGiven]] = NOT_GIVEN
    max_tokens: Optional[Union[int, NotGiven]] = NOT_GIVEN
    modalities: Optional[Union[List[Literal["text", "audio"]], NotGiven]] = NOT_GIVEN
    n: Optional[Union[int, NotGiven]] = NOT_GIVEN
    prediction: Optional[Union[ChatCompletionPredictionContentParam, NotGiven]] = NOT_GIVEN
    presence_penalty: Optional[Union[float, NotGiven]] = NOT_GIVEN
    reasoning_effort: Optional[Union[ReasoningEffort, NotGiven]] = NOT_GIVEN
    thinking: Optional[Union["ThinkingConfigParam", NotGiven]] = NOT_GIVEN
    response_format: Optional[
        Union[completion_create_params.ResponseFormat, Literal["url", "b64_json"], NotGiven]
    ] = NOT_GIVEN
    seed: Optional[Union[int, NotGiven]] = NOT_GIVEN
    web_search_options: Optional[Union[completion_create_params.WebSearchOptions, NotGiven]] = NOT_GIVEN

    # Anthropic Messages Input
    system: Optional[Union[str, Iterable["TextBlockParam"], NotGiven]] = NOT_GIVEN
    stop_sequences: Optional[Union["SequenceNotStr[str]", Sequence[str], NotGiven]] = NOT_GIVEN
    top_k: Optional[Union[int, NotGiven]] = NOT_GIVEN

    # Google GenAI Input
    contents: Optional[Union[types.ContentListUnion, types.ContentListUnionDict]] = None
    config: Optional[Union[
        types.GenerateContentConfigOrDict, types.GenerateImagesConfigOrDict, types.GenerateVideosConfigOrDict]] = None

    # Google GenAI Videos Input
    video: Optional[types.VideoOrDict] = None
    source: Optional[Any] = None  # GenerateVideosSourceOrDict (if available)
    callback_url: Optional[str] = None  # 异步任务回调地址

    # Images（OpenAI Images / Images Edit / Google Vertex Images / Freepik 合并）
    image: Optional[Union[str, FileTypes, List[FileTypes], TamarFileIdInput, List[TamarFileIdInput]]] = None
    background: Optional[Union[bool, Literal["transparent", "opaque", "auto"], NotGiven]] = NOT_GIVEN
    moderation: Optional[Union[Literal["low", "auto"], NotGiven]] = NOT_GIVEN
    input_fidelity: Optional[Union[Literal["high", "low"], NotGiven]] = NOT_GIVEN
    output_compression: Optional[Union[int, NotGiven]] = NOT_GIVEN
    output_format: Optional[Union[Literal["png", "jpeg", "webp"], NotGiven]] = NOT_GIVEN
    partial_images: Optional[Union[int, NotGiven]] = NOT_GIVEN
    mask: Union[FileTypes, TamarFileIdInput, NotGiven] = NOT_GIVEN
    negative_prompt: Optional[str] = None
    aspect_ratio: Optional[Literal["1:1", "9:16", "16:9", "4:3", "3:4"]] = None
    guidance_scale: Optional[float] = None
    language: Optional[str] = None
    output_gcs_uri: Optional[str] = None
    add_watermark: Optional[bool] = None
    safety_filter_level: Optional[Literal["block_most", "block_some", "block_few", "block_fewest"]] = None
    person_generation: Optional[Literal["dont_allow", "allow_adult", "allow_all"]] = None
    quality: Optional[Union[Literal["standard", "hd", "low", "medium", "high", "auto"], NotGiven]] = NOT_GIVEN
    size: Optional[
        Union[
            Literal["auto", "1024x1024", "1536x1024", "1024x1536", "256x256", "512x512", "1792x1024", "1024x1792"],
            NotGiven,
        ]
    ] = NOT_GIVEN
    style: Optional[Union[Literal["vivid", "natural"], NotGiven]] = NOT_GIVEN
    number_of_images: Optional[int] = None  # Google 用法

    # Freepik Image Upscaler Input
    scale_factor: Optional[int] = None  # 图像缩放倍数 (2-16)
    sharpen: Optional[int] = None  # 锐化程度 (0-10)
    smart_grain: Optional[int] = None  # 智能颗粒度 (0-10)
    ultra_detail: Optional[int] = None  # 超细节程度 (0-100)
    flavor: Optional[Literal["sublime", "photo", "photo_denoiser"]] = None  # 处理风格

    # BytePlus OmniHuman Video Input
    image_url: Optional[Union[str, TamarFileIdInput, dict]] = None  # 图像URL (支持 URL、TamarFileIdInput、dict)
    audio_url: Optional[str] = None  # 音频URL
    mask_url: Optional[str] = None  # 掩码URL
    pe_fast_mode: Optional[bool] = None  # 快速模式

    # Fal AI Qwen Image Edit Input
    image_urls: Optional[Union[List[str], List[TamarFileIdInput]]] = None  # 图像URL列表
    image_size: Optional[Union[
        Literal["square_hd", "square", "portrait_4_3", "portrait_16_9", "landscape_4_3", "landscape_16_9"],
        Dict[str, Any]
    ]] = None  # 图像尺寸
    num_inference_steps: Optional[int] = None  # 推理步骤数
    acceleration: Optional[Literal["none", "regular"]] = None  # 加速模式
    sync_mode: Optional[bool] = None  # 同步模式
    enable_safety_checker: Optional[bool] = None  # 启用安全检查器
    num_images: Optional[int] = None  # 生成图像数量
    rotate_right_left: Optional[float] = None  # 左右旋转角度
    move_forward: Optional[float] = None  # 向前移动距离
    vertical_angle: Optional[float] = None  # 垂直角度
    wide_angle_lens: Optional[bool] = None  # 广角镜头
    lora_scale: Optional[float] = None  # LoRA 缩放系数

    # Fal AI Wan Video Replace Input
    video_url: Optional[Union[str, TamarFileIdInput, dict]] = None  # 视频URL (支持 URL、TamarFileIdInput、dict)
    resolution: Optional[Literal["480p", "580p", "720p"]] = None  # 视频分辨率
    enable_output_safety_checker: Optional[bool] = None  # 启用输出安全检查器
    shift: Optional[float] = None  # 偏移量
    video_write_mode: Optional[Literal["fast", "balanced", "small"]] = None  # 视频写入模式
    return_frames_zip: Optional[bool] = None  # 返回帧 zip 文件
    use_turbo: Optional[bool] = None  # 使用 turbo 模式
    video_quality: Optional[str] = None  # 视频质量

    # 是否开启异步任务模式(默认True)
    enable_async_task: Optional[bool] = None

    model_config = {
        "arbitrary_types_allowed": True
    }

    @field_validator("image", mode="before")
    @classmethod
    def validate_image(cls, v):
        return convert_file_field(v)

    @field_validator("mask", mode="before")
    @classmethod
    def validate_mask(cls, v):
        return convert_file_field(v)


class ModelRequest(ModelRequestInput):
    user_context: UserContext  # 用户信息

    @model_validator(mode="after")
    def validate_by_provider_and_invoke_type(self) -> "ModelRequest":
        return validate_fields_by_provider_and_invoke_type(
            instance=self,
            extra_allowed_fields={"provider", "channel", "invoke_type", "user_context"},
        )


class BatchModelRequestItem(ModelRequestInput):
    custom_id: Optional[str] = None
    priority: Optional[int] = None  # （可选、预留字段）批量调用时执行的优先级

    @model_validator(mode="after")
    def validate_by_provider_and_invoke_type(self) -> "BatchModelRequestItem":
        return validate_fields_by_provider_and_invoke_type(
            instance=self,
            extra_allowed_fields={"provider", "channel", "invoke_type", "user_context", "custom_id"},
        )


class BatchModelRequest(BaseModel):
    user_context: UserContext  # 用户信息
    items: List[BatchModelRequestItem]  # 批量请求项列表
