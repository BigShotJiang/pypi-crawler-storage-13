"""
Core package for cyne assistant
Made by Cynerza
"""
