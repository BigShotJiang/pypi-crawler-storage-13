#!/usr/bin/env python3
"""
Main entry point for running cyne as a module with python -m cyne
"""

from .cli import main

if __name__ == "__main__":
    main()
