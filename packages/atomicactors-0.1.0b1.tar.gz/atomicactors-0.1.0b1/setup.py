"""Setup script for Atomic Actor framework."""

from setuptools import setup, find_packages

setup(
    name="atomicactors",
    version="0.1.0b1",
    description="Ruthlessly simple framework for building agentic systems",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="Jamoxidase",
    url="https://github.com/Jamoxidase/Atomic-Actors",
    packages=find_packages(exclude=["examples", "tests", "test_*"]),
    python_requires=">=3.10",
    install_requires=[
        "openai>=1.0.0",
        "litellm>=1.0.0",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
