"""
Test format fields filtering functionality.
"""

from atomic_actor.helpers import filter_dict_fields, format_structured_data


def test_filter_dict_fields():
    """Test filtering with dot notation."""

    # Test data mimicking MCP response
    data = {
        "content": [
            {"type": "text", "text": '{"url":"http://example.com", "title":"Example", "description":"A site"}'},
            {"type": "text", "text": '{"url":"http://test.com", "title":"Test", "description":"Test site"}'}
        ],
        "isError": False,
        "metadata": {
            "source": "brave",
            "timestamp": "2025-01-01"
        }
    }

    # Test include
    filtered = filter_dict_fields(data, include=["content", "metadata.source"])
    print("Include test:")
    print(filtered)
    assert "content" in filtered
    assert "metadata" in filtered
    assert "source" in filtered["metadata"]
    assert "timestamp" not in filtered["metadata"]
    assert "isError" not in filtered

    # Test exclude
    filtered2 = filter_dict_fields(data, exclude=["isError", "metadata.timestamp"])
    print("\nExclude test:")
    print(filtered2)
    assert "content" in filtered2
    assert "metadata" in filtered2
    assert "source" in filtered2["metadata"]
    assert "timestamp" not in filtered2["metadata"]
    assert "isError" not in filtered2

    print("\n✓ Filter tests passed!")


def test_format_structured_data():
    """Test formatting of action results."""

    # Single action
    single_action = {"action": "brave_web_search", "result": {"title": "Example", "url": "http://example.com"}}
    formatted = format_structured_data(single_action)
    print("\nSingle action:")
    print(formatted)
    assert "brave_web_search" in formatted

    # Cycle (list of actions)
    cycle = [
        {"action": "search", "result": {"query": "test"}},
        {"action": "calculate", "result": "2+2=4"}
    ]
    formatted = format_structured_data(cycle)
    print("\nCycle:")
    print(formatted)
    assert "search" in formatted
    assert "calculate" in formatted

    # Multiple cycles
    cycles = [
        [{"action": "search", "result": {"query": "first"}}],
        [{"action": "search", "result": {"query": "second"}}]
    ]
    formatted = format_structured_data(cycles)
    print("\nMultiple cycles:")
    print(formatted)
    assert "Cycle 0" in formatted
    assert "Cycle 1" in formatted

    print("\n✓ Format tests passed!")


if __name__ == "__main__":
    test_filter_dict_fields()
    test_format_structured_data()
    print("\n✅ All tests passed!")
