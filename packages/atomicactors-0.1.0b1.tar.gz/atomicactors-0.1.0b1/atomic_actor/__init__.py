"""
Atomic Actor Framework

A ruthlessly simple framework for building agentic systems through
composition of atomic actors.

Core Components:
- AtomicActor: The fundamental building block
- EventBus: Pub/sub communication layer for actors
- ToolRegistry: Interface for registering and invoking tools
- Configuration: Behavior-driving configuration classes

Design Principles:
- Ruthlessly simple
- Plug, config, and play
- Strong OOP with separation of concerns
- Self-orchestrated recursion for complex behavior
- NO tool/model-specific code in library
"""

from .actor import AtomicActor
from .event_bus import EventBus, Event, LogLevel, ColoredLoggingHandler, StateMirrorHandler
from .tool_registry import ToolRegistry, ToolNotFoundError
from .openai_client import OpenAIClient
from .litellm_client import LiteLLMClient
from .config import (
    ActorConfig,
    PerceptionConfig,
    ToolFormatConfig,
    HistoryRule
)
from .types import (
    Action,
    Observation,
    ObservationType,
    ToolSchema,
    ActorStatus,
    ActorState
)

__version__ = "0.1.0"

__all__ = [
    # Core classes
    "AtomicActor",
    "EventBus",
    "ToolRegistry",
    "OpenAIClient",
    "LiteLLMClient",

    # Configuration
    "ActorConfig",
    "PerceptionConfig",
    "ToolFormatConfig",
    "HistoryRule",

    # Types
    "Action",
    "Observation",
    "ObservationType",
    "ToolSchema",
    "ActorStatus",
    "ActorState",
    "Event",

    # Enums
    "LogLevel",

    # EventBus Handlers
    "ColoredLoggingHandler",
    "StateMirrorHandler",

    # Exceptions
    "ToolNotFoundError",
]
