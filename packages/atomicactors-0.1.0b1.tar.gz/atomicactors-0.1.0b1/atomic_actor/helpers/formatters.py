"""
Generic formatters and filters for structured data.

Converts structured data (dicts, lists, nested structures) into
human-readable strings suitable for LLM context.
"""

from typing import Any, List, Optional, Union
import json


def filter_dict_fields(
    data: dict,
    include: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None
) -> dict:
    """
    Filter dictionary fields using dot notation for nested access.

    Supports dot notation paths like:
    - "field" - top-level field
    - "metadata.source" - nested field
    - "content.0.type" - array index access

    Args:
        data: Dictionary to filter
        include: List of dot-notation paths to include (whitelist)
        exclude: List of dot-notation paths to exclude (blacklist)

    Returns:
        Filtered dictionary

    Examples:
        >>> data = {"a": 1, "b": {"c": 2, "d": 3}, "e": 4}
        >>> filter_dict_fields(data, include=["a", "b.c"])
        {"a": 1, "b": {"c": 2}}
        >>> filter_dict_fields(data, exclude=["b.d"])
        {"a": 1, "b": {"c": 2}, "e": 4}
    """
    if not include and not exclude:
        return data

    if include:
        return _include_fields(data, include)
    else:
        return _exclude_fields(data, exclude)


def _include_fields(data: dict, paths: List[str]) -> dict:
    """Build new dict with only included paths, preserving hierarchy."""
    if not paths:
        return data

    # Group paths by their array ancestor (if any)
    # This preserves structure when multiple fields come from same array items
    result = {}

    # Find common prefix and apply all paths together to preserve structure
    # For paths like ["content.text.url", "content.text.title"]
    # We need to extract from each array item: {url: ..., title: ...}
    # Not separate arrays of [urls...] and [titles...]

    # First, identify which paths share array ancestors
    path_groups = _group_paths_by_array_ancestor(data, paths)

    for group_prefix, group_paths in path_groups.items():
        if group_prefix:
            # Check if any path is exactly the array path (e.g., "content")
            # If so, return the whole array for that path
            for path in group_paths:
                if path == group_prefix:
                    # Path points to the array itself, not a field within items
                    parts = path.split('.')
                    _set_nested_value(result, parts, _get_nested_value(data, parts))
                    group_paths.remove(path)

            # Process remaining paths that go into array items
            if group_paths:
                _include_fields_from_array(data, result, group_prefix, group_paths)
        else:
            # No array ancestor - process individually
            for path in group_paths:
                parts = path.split('.')
                _set_nested_value(result, parts, _get_nested_value(data, parts))

    return result


def _group_paths_by_array_ancestor(data: dict, paths: List[str]) -> dict:
    """Group paths by their common array ancestor to preserve structure.

    Returns:
        Dict mapping array prefix to list of paths
        Empty string key means no array ancestor
    """
    groups = {}

    for path in paths:
        parts = path.split('.')
        array_prefix = _find_array_ancestor(data, parts)

        if array_prefix not in groups:
            groups[array_prefix] = []
        groups[array_prefix].append(path)

    return groups


def _find_array_ancestor(data: dict, parts: List[str]) -> str:
    """Find the path prefix where we encounter an array.

    Returns empty string if no array in path.
    """
    current = data
    prefix_parts = []

    for part in parts:
        if isinstance(current, dict):
            current = current.get(part)
            prefix_parts.append(part)

            # Parse JSON strings
            if isinstance(current, str):
                try:
                    import json
                    current = json.loads(current)
                except (json.JSONDecodeError, TypeError):
                    pass

            # Found an array - return the prefix up to this point
            if isinstance(current, list):
                return '.'.join(prefix_parts)
        elif isinstance(current, list):
            return '.'.join(prefix_parts[:-1]) if prefix_parts else ''
        else:
            break

    return ''


def _include_fields_from_array(data: dict, result: dict, array_path: str, field_paths: List[str]) -> None:
    """Extract multiple fields from array items while preserving structure.

    Args:
        data: Source data
        result: Target dict to populate
        array_path: Path to the array (e.g., "content")
        field_paths: Full paths to fields (e.g., ["content.text.url", "content.text.title"])
    """
    # Get the array
    array_parts = array_path.split('.')
    array = _get_nested_value(data, array_parts)

    if not isinstance(array, list):
        return

    # For each field path, extract the suffix after the array path
    field_suffixes = []
    for path in field_paths:
        # Remove array prefix to get the per-item path
        suffix = path[len(array_path)+1:] if path.startswith(array_path + '.') else path
        field_suffixes.append(suffix.split('.'))

    # Process each array item, extracting all requested fields
    filtered_array = []
    for item in array:
        filtered_item = {}
        for suffix_parts in field_suffixes:
            value = _get_nested_value(item, suffix_parts)
            if value is not None:
                _set_nested_value(filtered_item, suffix_parts, value)

        if filtered_item:  # Only include items that have at least one requested field
            filtered_array.append(filtered_item)

    # Set the filtered array in result
    _set_nested_value(result, array_parts, filtered_array)


def _exclude_fields(data: dict, paths: List[str]) -> dict:
    """Remove excluded paths from dict."""
    result = json.loads(json.dumps(data))  # Deep copy

    for path in paths:
        parts = path.split('.')
        _delete_nested_value(result, parts)

    return result


def _get_nested_value(data: Any, parts: List[str]) -> Any:
    """Get value from nested dict using path parts. Arrays are handled by applying path to all items."""
    if not parts:
        return data

    current = data

    for i, part in enumerate(parts):
        if isinstance(current, dict):
            # Try to get the key
            current = current.get(part)

            # If value is a JSON string, parse it
            if isinstance(current, str):
                try:
                    import json
                    current = json.loads(current)
                except (json.JSONDecodeError, TypeError):
                    pass

        elif isinstance(current, list):
            # Apply remaining path to all items in list
            remaining_parts = parts[i+1:]
            if not remaining_parts:
                # No more path - return the array itself
                return current
            results = []
            for item in current:
                result = _get_nested_value(item, remaining_parts)
                if result is not None:
                    results.append(result)
            return results if results else None
        else:
            return None

        if current is None:
            return None

    return current


def _set_nested_value(data: dict, parts: List[str], value: Any) -> None:
    """Set value in nested dict using path parts. Builds structure as needed."""
    if value is None:
        return

    current = data

    for i, part in enumerate(parts[:-1]):
        if part not in current:
            # Create dict for this level
            current[part] = {}

        current = current[part]

    # Set final value
    final_key = parts[-1]
    if isinstance(current, dict):
        current[final_key] = value


def _delete_nested_value(data: dict, parts: List[str]) -> None:
    """Delete value from nested dict using path parts."""
    if not parts:
        return

    current = data

    # Navigate to parent
    for part in parts[:-1]:
        if isinstance(current, dict):
            current = current.get(part)
        else:
            return

        if current is None:
            return

    # Delete final key
    final_key = parts[-1]
    if isinstance(current, dict) and final_key in current:
        del current[final_key]


def format_structured_data(data: Any, indent: int = 0) -> str:
    """
    Format any structured data into human-readable string.

    Recursively handles dicts, lists, and primitives.
    All keys and values formatted consistently.

    Args:
        data: Any data structure to format
        indent: Current indentation level

    Returns:
        Human-readable string representation
    """
    indent_str = "  " * indent

    # Handle None
    if data is None:
        return "None"

    # Handle dict - format each key-value pair
    if isinstance(data, dict):
        if not data:
            return "(empty)"

        lines = []
        for key, value in data.items():
            # Capitalize key for readability
            formatted_key = key.capitalize()

            # Format value based on type
            if isinstance(value, dict):
                # Nested dict - put on new lines with indent
                formatted_value = format_structured_data(value, indent + 1)
                lines.append(f"{indent_str}{formatted_key}:\n{formatted_value}")
            elif isinstance(value, list):
                # List - put on new lines with indent
                formatted_value = format_structured_data(value, indent + 1)
                lines.append(f"{indent_str}{formatted_key}:\n{formatted_value}")
            else:
                # Simple value - inline
                lines.append(f"{indent_str}{formatted_key}: {value}")

        return "\n".join(lines)

    # Handle list
    if isinstance(data, list):
        if not data:
            return "(empty)"

        parts = []
        for item in data:
            formatted_item = format_structured_data(item, indent)
            # Add ## header only at top level (indent == 0)
            if indent == 0:
                formatted_item = f"## {formatted_item}"
            parts.append(formatted_item)

        # Separate list items with blank line
        return "\n\n".join(parts)

    # Primitive value
    return f"{indent_str}{data}"


def _format_action_result(action_result: dict, show_header: bool) -> str:
    """Format a single action result dict into human-readable text."""
    action_name = action_result.get("action", "unknown")
    parameters = action_result.get("parameters")

    # Handle error case
    if "error" in action_result:
        error_msg = action_result["error"]
        if show_header:
            header = f"## {action_name}"
            if parameters:
                header += f"\nparameters: {parameters}"
            return f"{header}\nError: {error_msg}"
        return f"Error: {error_msg}"

    # Handle normal result
    result = action_result.get("result")

    if result is None:
        formatted_result = "None"
    elif isinstance(result, str):
        formatted_result = result
    elif isinstance(result, dict):
        formatted_result = _format_dict_readable(result)
    elif isinstance(result, list):
        formatted_result = _format_list_readable(result)
    else:
        formatted_result = str(result)

    if show_header:
        header = f"## {action_name}"
        if parameters:
            header += f"\nparameters: {parameters}"
        return f"{header}\n{formatted_result}"

    return formatted_result


def _format_dict_readable(data: dict, indent: int = 0) -> str:
    """Format a dict into human-readable text (not JSON).

    Detects common patterns like arrays of items and formats them nicely.
    """
    lines = []
    indent_str = "  " * indent

    for key, value in data.items():
        if isinstance(value, list) and value and isinstance(value[0], dict):
            # Array of objects - format as numbered list
            lines.append(f"{indent_str}{key}:")
            for i, item in enumerate(value, 1):
                lines.append(f"{indent_str}  {i}.")
                item_text = _format_dict_readable(item, indent + 2)
                # Add indentation to each line of the item
                for line in item_text.split('\n'):
                    if line.strip():
                        lines.append(f"  {line}")
        elif isinstance(value, list):
            # Simple array - format inline or as bullet list
            if all(isinstance(v, (str, int, float, bool)) for v in value):
                # Simple values - show inline if short, otherwise bullets
                if sum(len(str(v)) for v in value) < 100:
                    lines.append(f"{indent_str}{key}: {', '.join(str(v) for v in value)}")
                else:
                    lines.append(f"{indent_str}{key}:")
                    for item in value:
                        lines.append(f"{indent_str}  - {item}")
            else:
                # Complex values - use bullets
                lines.append(f"{indent_str}{key}:")
                for item in value:
                    lines.append(f"{indent_str}  - {_format_value_readable(item, indent + 2)}")
        elif isinstance(value, dict):
            # Nested dict
            lines.append(f"{indent_str}{key}:")
            nested = _format_dict_readable(value, indent + 1)
            lines.append(nested)
        else:
            # Simple value
            lines.append(f"{indent_str}{key}: {value}")

    return '\n'.join(lines)


def _format_list_readable(items: list, indent: int = 0) -> str:
    """Format a list into human-readable text."""
    if not items:
        return "(empty)"

    # If all items are dicts with similar structure, format as numbered list
    if all(isinstance(item, dict) for item in items):
        lines = []
        for i, item in enumerate(items, 1):
            lines.append(f"{i}.")
            item_text = _format_dict_readable(item, indent + 1)
            # Add indentation to each line
            for line in item_text.split('\n'):
                if line.strip():
                    lines.append(f"  {line}")
        return '\n'.join(lines)

    # Otherwise, simple bullet list
    return '\n'.join(f"- {_format_value_readable(item)}" for item in items)


def _format_value_readable(value: Any, indent: int = 0) -> str:
    """Format any value into readable text."""
    if isinstance(value, dict):
        return _format_dict_readable(value, indent)
    elif isinstance(value, list):
        return _format_list_readable(value, indent)
    else:
        return str(value)
