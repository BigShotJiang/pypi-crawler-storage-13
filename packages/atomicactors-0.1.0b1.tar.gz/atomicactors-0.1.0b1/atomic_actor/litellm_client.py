"""
LiteLLM Client - Multi-provider LLM interface using LiteLLM.

Supports 100+ LLM providers through unified interface:
- OpenAI, Anthropic, Cohere, Replicate, HuggingFuse, etc.
- Local models via Ollama, LM Studio, etc.
"""

from typing import Any, Dict, List
import json
import os
from .types import Action, ToolSchema
from .config import ActorConfig


class LiteLLMClient:
    """
    LiteLLM client for multi-provider LLM access.

    Supports any provider that LiteLLM supports. Provider is determined
    by model name prefix (e.g., "gpt-4", "claude-3", "ollama/llama2").
    """

    def __init__(
        self,
        model: str,
        api_key: str = None,
        api_base: str = None,
        **kwargs
    ):
        """
        Initialize LiteLLM client.

        Args:
            model: Model identifier (e.g., "gpt-4", "claude-3-opus-20240229", "ollama/llama2")
            api_key: API key (optional, uses env vars if not provided)
            api_base: Custom API base URL (optional)
            **kwargs: Additional arguments passed to litellm.completion()
        """
        try:
            import litellm
            self.litellm = litellm
        except ImportError:
            raise ImportError(
                "litellm not installed. Install with: pip install litellm"
            )

        self.model = model
        self.api_key = api_key
        self.api_base = api_base
        self.extra_kwargs = kwargs

        # Configure LiteLLM settings
        if api_key:
            # Set provider-specific API keys based on model prefix
            if model.startswith("gpt-") or model.startswith("openai/"):
                os.environ["OPENAI_API_KEY"] = api_key
            elif model.startswith("claude-") or model.startswith("anthropic/"):
                os.environ["ANTHROPIC_API_KEY"] = api_key

    async def complete(
        self,
        context: str,
        system_prompt: str,
        tools: Dict[str, ToolSchema],
        config: ActorConfig
    ) -> Any:
        """
        Call LLM with tool schemas.

        Args:
            context: Context string from perceive()
            system_prompt: System prompt from config
            tools: Dictionary of tool schemas
            config: ActorConfig with LLM settings

        Returns:
            LiteLLM response message object
        """
        # Build messages
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": context}
        ]

        # Convert tool schemas to OpenAI format (LiteLLM uses this standard)
        tool_schemas = []
        for schema in tools.values():
            tool_schemas.append({
                "type": "function",
                "function": {
                    "name": schema.name,
                    "description": schema.description,
                    "parameters": schema.parameters
                }
            })

        # Build kwargs for litellm.completion()
        completion_kwargs = {
            "model": self.model,
            "messages": messages,
            "temperature": config.llm_temperature,
            "max_tokens": config.llm_max_tokens,
            **self.extra_kwargs
        }

        # Add tools if available
        if tool_schemas:
            completion_kwargs["tools"] = tool_schemas
            completion_kwargs["tool_choice"] = "auto"

        # Add custom API base if provided
        if self.api_base:
            completion_kwargs["api_base"] = self.api_base

        # Call LiteLLM (async)
        response = await self.litellm.acompletion(**completion_kwargs)

        # Return the message object
        return response.choices[0].message

    def parse_actions(self, message: Any) -> List[Action]:
        """
        Extract tool call actions and text content from LLM response.

        Args:
            message: LiteLLM message object

        Returns:
            List of Action objects parsed from tool calls and/or response
        """
        actions = []

        # Check if message has tool_calls attribute
        if hasattr(message, 'tool_calls') and message.tool_calls:
            for tool_call in message.tool_calls:
                # Parse arguments (might be string or dict)
                if isinstance(tool_call.function.arguments, str):
                    parameters = json.loads(tool_call.function.arguments)
                else:
                    parameters = tool_call.function.arguments

                action = Action(
                    type=tool_call.function.name,
                    parameters=parameters
                )
                actions.append(action)

        # Parse text content as 'response' action
        if hasattr(message, 'content') and message.content:
            actions.append(Action(
                type="response",
                parameters={"content": message.content}
            ))

        return actions
