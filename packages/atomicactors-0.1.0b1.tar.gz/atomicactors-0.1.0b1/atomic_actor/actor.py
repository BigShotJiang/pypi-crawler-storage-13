"""
AtomicActor - Ruthlessly distilled 'agentic' object.

The atomic building block for agentic systems. Multiple actors compose
to form complex agent behavior through self-orchestrated recursion.
"""

from typing import Any, List, Optional, AsyncGenerator
from .types import Action, Observation, ActorStatus, ActorState, ObservationType
from .event_bus import EventBus, LogLevel, Event
from .tool_registry import ToolRegistry
from .config import ActorConfig
from .helpers import format_structured_data, filter_dict_fields


class AtomicActor:
    """
    Atomic Actor - simple building block for agentic systems.

    Execution cycle: observe() → perceive() → act() → execute

    Multiple actors compose to form complex agent behavior.
    """

    def __init__(
        self,
        name: str,
        tools: ToolRegistry,
        event_bus: EventBus,
        config: ActorConfig,
        max_cycles: int = 100
    ):
        """
        Initialize AtomicActor.

        Args:
            name: Actor identifier
            tools: ToolRegistry with available tools
            event_bus: EventBus for communication and event publishing
            config: ActorConfig defining behavior
            max_cycles: Maximum execution cycles
        """
        # Identity
        self.name = name
        self.status = ActorStatus.PENDING
        self.cycle_num = 0
        self.max_cycles = max_cycles

        # State - indexed by cycle
        self.actions: List[List[Action]] = []
        self.observations: List[List[Observation]] = []
        self.data: List[Any] = []

        # Components
        self.tools = tools
        self.event_bus = event_bus
        self._config = config

        # LLM client (to be injected)
        self._llm_client: Optional[Any] = None

        # Internal event queue (populated by EventBus subscriptions)
        self._incoming_events: List[dict] = []

        # Subscribe to own channel for incoming task events
        def _handle_incoming_event(event: Event) -> None:
            """Handle events published to this actor's channel."""
            self._incoming_events.append({
                "event_type": event.event_type,
                "data": event.data,
                "channel": event.channel
            })

        # Subscribe only to task.* events (not internal lifecycle events)
        self.event_bus.subscribe(self.name, "task.*", _handle_incoming_event)

        # Subscribe to additional channels based on config
        for subscription in config.event_subscriptions:
            channel = subscription.get("channel", "*")
            event_type = subscription.get("event_type", "*")
            action_type = subscription.get("action_type")  # Optional list of action types
            self.event_bus.subscribe(channel, event_type, _handle_incoming_event, action_types=action_type)

    async def initialize(self) -> None:
        """
        Initialize actor and publish initialization events.

        Call this after construction to publish tool registration events.
        """
        # Publish tool registration information
        tool_names = self.tools.list_tools()
        await self.event_bus.publish(
            channel=self.name,
            event_type="actor.initialized",
            data={
                "tool_count": len(tool_names),
                "tools": tool_names,
                "max_cycles": self.max_cycles
            }
        )

        # Publish detailed tool information
        for tool_name in tool_names:
            schema = self.tools.get_schema(tool_name)

            # Publish tool registration with full schema
            await self.event_bus.publish(
                channel=self.name,
                event_type="tool.registered",
                data={
                    "tool_name": tool_name,
                    "description": schema.description,
                    "parameters": schema.parameters
                }
            )

            # Publish human-readable tool description
            await self.event_bus.publish(
                channel=self.name,
                event_type="tool.info",
                data={
                    "tool_name": tool_name,
                    "description": schema.description
                }
            )

            # Publish parameter details if available
            if hasattr(schema, 'parameters') and schema.parameters:
                if 'properties' in schema.parameters:
                    param_details = {
                        name: info.get('type', 'unknown')
                        for name, info in schema.parameters['properties'].items()
                    }
                    if param_details:
                        await self.event_bus.publish(
                            channel=self.name,
                            event_type="tool.parameters",
                            data={
                                "tool_name": tool_name,
                                "parameters": param_details
                            }
                        )

    def set_llm_client(self, llm_client: Any) -> None:
        """
        Set LLM client for the actor.

        Args:
            llm_client: LLM client instance (OpenAIClient or LiteLLMClient)
        """
        self._llm_client = llm_client

    async def run(self) -> Any:
        """
        Entry point for actor execution.

        Consumes the clock generator and returns final result.

        Returns:
            Final data from last cycle, or None
        """
        # Initialize and publish setup events
        await self.initialize()

        # Publish LLM client configuration
        if self._llm_client:
            await self.event_bus.publish(
                channel=self.name,
                event_type="llm.configured",
                data={
                    "client_class": self._llm_client.__class__.__name__,
                    "model": self._config.llm_model
                }
            )

        async for _ in self.clock():
            pass  # Could add external hooks here if needed

        return self.data[-1] if self.data else None

    async def clock(self) -> AsyncGenerator[ActorState, None]:
        """
        Main execution loop - generator yielding state each cycle.

        Cycle: observe → perceive → act → execute

        Yields:
            ActorState after each cycle
        """
        # Publish lifecycle start
        self.status = ActorStatus.RUNNING
        await self.event_bus.publish(
            channel=self.name,
            event_type="lifecycle.started",
            data={"status": self.status, "max_cycles": self.max_cycles}
        )

        while self.cycle_num < self.max_cycles:
            # Publish cycle start
            await self.event_bus.publish(
                channel=self.name,
                event_type="cycle.started",
                data={"cycle": self.cycle_num}
            )

            # OBSERVE: Pull from environment
            cycle_observations = await self.observe()
            self.observations.append(cycle_observations)

            # Publish observations (metadata)
            await self.event_bus.publish(
                channel=self.name,
                event_type="observation.received",
                data={
                    "cycle": self.cycle_num,
                    "count": len(cycle_observations),
                    "sources": [obs.source for obs in cycle_observations]
                }
            )

            # Publish actual observation data
            if cycle_observations:
                await self.event_bus.publish(
                    channel=self.name,
                    event_type="observation.data",
                    data={
                        "cycle": self.cycle_num,
                        "observations": [
                            {
                                "source": obs.source,
                                "data": obs.data,
                                "type": obs.type.value
                            } for obs in cycle_observations
                        ]
                    }
                )

            # PERCEIVE: Build context from observations + history
            context = await self.perceive()

            # Publish perception complete (metadata)
            await self.event_bus.publish(
                channel=self.name,
                event_type="perception.built",
                data={
                    "cycle": self.cycle_num,
                    "context_length": len(context)
                }
            )

            # Publish actual context (for debugging/introspection)
            await self.event_bus.publish(
                channel=self.name,
                event_type="perception.context",
                data={
                    "cycle": self.cycle_num,
                    "context": context
                }
            )

            # ACT: LLM call → parse actions
            cycle_actions = await self.act(context)
            self.actions.append(cycle_actions)

            # Publish actions planned
            await self.event_bus.publish(
                channel=self.name,
                event_type="action.planned",
                data={
                    "cycle": self.cycle_num,
                    "action_count": len(cycle_actions),
                    "action_types": [a.type for a in cycle_actions]
                }
            )

            # EXECUTE: Run actions
            cycle_data = await self._execute_actions(cycle_actions)
            self.data.append(cycle_data)

            # Publish cycle completion (metadata)
            await self.event_bus.publish(
                channel=self.name,
                event_type="cycle.completed",
                data={
                    "cycle": self.cycle_num,
                    "actions_executed": len(cycle_data)
                }
            )

            # Publish actual cycle data
            await self.event_bus.publish(
                channel=self.name,
                event_type="cycle.data",
                data={
                    "cycle": self.cycle_num,
                    "data": cycle_data
                }
            )

            # Yield current state
            yield self.get_state()

            # Check completion
            if self._is_complete():
                break

            self.cycle_num += 1

        # Set final status if not already set
        if self.status == ActorStatus.RUNNING:
            self.status = ActorStatus.TIMEOUT
            await self.event_bus.publish(
                channel=self.name,
                event_type="lifecycle.timeout",
                data={"status": self.status, "cycles_completed": self.cycle_num}
            )

    def get_state(self) -> ActorState:
        """
        Get complete current state of the actor.

        Returns:
            ActorState snapshot
        """
        return ActorState(
            name=self.name,
            status=self.status,
            cycle_num=self.cycle_num,
            actions=self.actions.copy(),
            observations=self.observations.copy(),
            data=self.data.copy()
        )

    async def observe(self) -> List[Observation]:
        """
        Observe incoming events from EventBus queue.

        Drains the internal event queue populated by EventBus subscriptions.

        Returns:
            List of observations for this cycle
        """
        observations = []

        # Drain internal event queue
        while self._incoming_events:
            event = self._incoming_events.pop(0)
            # Create source with channel attribution (e.g., "PlanningActor.cycle.data")
            source = f"{event['channel']}.{event['event_type']}"
            obs = Observation(
                type=ObservationType.EXTERNAL_EVENT,
                data=event["data"],
                source=source,
                cycle=self.cycle_num
            )
            observations.append(obs)

        return observations

    async def perceive(self) -> str:
        """
        Build context from latest observations + historical state.

        Supplements current observations with relevant history based on
        config.perception settings.

        Returns:
            Context string for LLM
        """
        parts = []

        # Include latest observations
        if self.observations:
            obs_window = self._config.perception.observation_window

            # Flatten all observations across all cycles
            all_obs = []
            for cycle_obs in self.observations:
                all_obs.extend(cycle_obs)

            # Take the last N observations across all cycles
            obs_to_include = all_obs[-obs_window:] if obs_window else all_obs

            if obs_to_include:
                parts.append("Recent observations:")
                for obs in obs_to_include:
                    obs_data = obs.data

                    # If observation has cycle.data structure, unwrap and filter
                    if isinstance(obs_data, dict) and "data" in obs_data:
                        cycle_num = obs_data.get("cycle", "?")
                        action_results = obs_data.get("data", [])
                        if isinstance(action_results, list):
                            # Apply tool_configs filtering to actions
                            filtered_results = self._apply_format_filters(action_results)
                            # Format the filtered action list with cycle header
                            formatted_data = f"Cycle {cycle_num}:\n{format_structured_data(filtered_results)}"
                        else:
                            # Not a list, format as-is
                            formatted_data = format_structured_data(obs_data)
                    else:
                        # Not cycle.data structure, format as-is
                        formatted_data = format_structured_data(obs_data)

                    parts.append(f"[{obs.source}]:\n{formatted_data}")

        # Supplement with history if configured
        if self._config.perception.include_history and self.actions:
            for rule in self._config.perception.history_rules:
                tool_type = rule.tool_type
                n_previous = rule.include_previous

                # Find last N cycles with this tool type
                matching_actions = []
                for cycle_actions in reversed(self.actions):
                    for action in cycle_actions:
                        if action.type == tool_type:
                            matching_actions.append(action)
                            if len(matching_actions) >= n_previous:
                                break
                    if len(matching_actions) >= n_previous:
                        break

                if matching_actions:
                    parts.append(f"\nPrevious {tool_type} calls:")
                    for action in reversed(matching_actions):
                        parts.append(f"  {action.type}({action.parameters})")

        # Include latest data if exists
        if self.data:
            latest_data = self.data[-1]
            if latest_data is not None:
                # Apply format_fields filtering before formatting
                filtered_data = self._apply_format_filters(latest_data)
                formatted_data = format_structured_data(filtered_data)
                parts.append("\nCycle number: " + str(self.cycle_num))
                parts.append(f"\nCurrent data (COMPLETED ACTIONS (do not repeat these):\n{formatted_data}")

        return "\n".join(parts) if parts else "No context available."

    async def act(self, context: str) -> List[Action]:
        """
        LLM call with tool schemas, parse response into actions.

        Args:
            context: Context string from perceive()

        Returns:
            List of actions parsed from LLM response
        """
        if self._llm_client is None:
            raise RuntimeError("LLM client not set. Call set_llm_client() first.")

        # Get tool schemas from registry
        tool_schemas = self.tools.get_schemas()

        # Publish LLM request event
        await self.event_bus.publish(
            channel=self.name,
            event_type="llm.request",
            data={
                "cycle": self.cycle_num,
                "context_length": len(context),
                "tool_count": len(tool_schemas)
            }
        )

        # Call LLM - question, why would we pass config,sys prompt seperately if we also pass whole config??
        # Build kwargs for complete call
        complete_kwargs = {
            "context": context,
            "system_prompt": self._config.system_prompt,
            "tools": tool_schemas,
            "config": self._config
        }

        # Add tracing IDs if available
        if self._config.trace_id:
            complete_kwargs["trace_id"] = self._config.trace_id
        if self._config.session_id:
            complete_kwargs["session_id"] = self._config.session_id

        message = await self._llm_client.complete(**complete_kwargs)

        # Publish LLM response event (metadata)
        await self.event_bus.publish(
            channel=self.name,
            event_type="llm.response",
            data={
                "cycle": self.cycle_num,
                "has_content": bool(message.content),
                "has_tool_calls": bool(message.tool_calls),
                "tool_call_count": len(message.tool_calls) if message.tool_calls else 0
            }
        )

        # Publish actual LLM response content if present
        if message.content:
            await self.event_bus.publish(
                channel=self.name,
                event_type="llm.content",
                data={
                    "cycle": self.cycle_num,
                    "content": message.content
                }
            )

        # Publish actual tool calls if present
        if message.tool_calls:
            await self.event_bus.publish(
                channel=self.name,
                event_type="llm.tool_calls",
                data={
                    "cycle": self.cycle_num,
                    "tool_calls": [
                        {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments
                        } for tc in message.tool_calls
                    ]
                }
            )

        # Parse message into actions
        actions = self._llm_client.parse_actions(message)

        # Publish parsed actions (with full details)
        await self.event_bus.publish(
            channel=self.name,
            event_type="llm.parsed",
            data={
                "cycle": self.cycle_num,
                "actions": [
                    {
                        "type": a.type,
                        "parameters": a.parameters
                    } for a in actions
                ]
            }
        )

        return actions

    async def _execute_actions(self, actions: List[Action]) -> Any:
        """
        Execute all actions for this cycle.

        Args:
            actions: List of actions to execute

        Returns:
            List of all results from this cycle
        """
        cycle_data = []
        completion_found = False
        completion_status = None

        # Execute all actions
        for action in actions:
            # Check for completion
            if action.type == self._config.completion_tool_name:
                status_str = action.parameters.get("status", "completed")
                completion_found = True
                completion_status = status_str

                # Add structured result for completion action
                cycle_data.append({
                    "action": action.type,
                    "result": action.parameters
                })

            # Handle text response action
            elif action.type == "response":
                content = action.parameters.get("content", "")

                # Publish text response event
                await self.event_bus.publish(
                    channel=self.name,
                    event_type="action.response",
                    data={
                        "cycle": self.cycle_num,
                        "content": content
                    }
                )

                # Append to cycle data with consistent structure
                cycle_data.append({"action": "response", "result": content})

            # Invoke tool
            else:
                try:
                    # Publish action start
                    await self.event_bus.publish(
                        channel=self.name,
                        event_type="action.started",
                        data={
                            "cycle": self.cycle_num,
                            "action": action.type,
                            "parameters": action.parameters
                        }
                    )

                    result = await self.tools.invoke(action.type, **action.parameters)

                    # Publish action executed event (metadata)
                    await self.event_bus.publish(
                        channel=self.name,
                        event_type="action.executed",
                        data={
                            "cycle": self.cycle_num,
                            "action": action.type,
                            "success": True
                        }
                    )

                    # Publish action result (actual data)
                    await self.event_bus.publish(
                        channel=self.name,
                        event_type="action.result",
                        data={
                            "cycle": self.cycle_num,
                            "action": action.type,
                            "parameters": action.parameters,
                            "result": result
                        }
                    )

                    # Append to cycle data with consistent structure
                    cycle_data.append({
                        "action": action.type,
                        "parameters": action.parameters,
                        "result": result
                    })

                except Exception as e:
                    # Publish error event (with full details)
                    await self.event_bus.publish(
                        channel=self.name,
                        event_type="action.failed",
                        data={
                            "cycle": self.cycle_num,
                            "action": action.type,
                            "parameters": action.parameters,
                            "error": str(e),
                            "error_type": type(e).__name__
                        }
                    )

                    cycle_data.append({"action": action.type, "error": str(e)})

        # After processing all actions, handle completion if it was found
        if completion_found:
            self.status = ActorStatus.COMPLETED if completion_status == "completed" else ActorStatus.FAILED

            # Publish lifecycle completion event
            await self.event_bus.publish(
                channel=self.name,
                event_type=f"lifecycle.{completion_status}",
                data={
                    "status": self.status,
                    "cycle": self.cycle_num,
                    "parameters": {"status": completion_status}
                }
            )

        return cycle_data

    def _is_complete(self) -> bool:
        """
        Check if actor has completed.

        Returns:
            True if status indicates completion
        """
        return self.status in [
            ActorStatus.COMPLETED,
            ActorStatus.FAILED
        ]

    def _format_observations(self, observations: List[Observation]) -> str:
        """Format observations for context."""
        if not observations:
            return "None"
        return "\n".join([f"[{obs.source}] {obs.data}" for obs in observations])

    def _format_actions(self, actions: List[Action]) -> str:
        """Format actions for context."""
        if not actions:
            return "None"
        return "\n".join([f"{a.type}({a.parameters})" for a in actions])

    def _apply_format_filters(self, data: Any) -> Any:
        """
        Apply format_fields filtering to action results.

        Filters result dicts based on tool_configs before formatting.

        Args:
            data: Action results (single cycle or multiple cycles)

        Returns:
            Filtered data (same structure)
        """
        # Handle List[List[Dict]] - multiple cycles
        if isinstance(data, list) and len(data) > 0 and isinstance(data[0], list):
            return [self._filter_cycle(cycle) for cycle in data]

        # Handle List[Dict] - single cycle
        if isinstance(data, list):
            return self._filter_cycle(data)

        # Handle single dict
        if isinstance(data, dict) and "action" in data:
            return self._filter_action_result(data)

        return data

    def _filter_cycle(self, cycle: List[dict]) -> List[dict]:
        """Filter all action results in a cycle."""
        return [self._filter_action_result(action_result) for action_result in cycle]

    def _filter_action_result(self, action_result: dict) -> dict:
        """Filter a single action result based on tool config."""
        action_name = action_result.get("action")
        parameters = action_result.get("parameters")
        result = action_result.get("result")

        # Skip if no result or error
        if result is None or "error" in action_result:
            return action_result

        # Check if tool has format config
        tool_config = self._config.tool_configs.get(action_name, {})
        include = tool_config.get("format_fields_include")
        exclude = tool_config.get("format_fields_exclude")

        # Apply filtering if configured
        if (include or exclude) and isinstance(result, dict):
            result = filter_dict_fields(result, include=include, exclude=exclude)

        # Return filtered action result with parameters preserved
        filtered = {"action": action_name, "result": result}
        if parameters is not None:
            filtered["parameters"] = parameters
        return filtered
