"""
OpenAI client with format-specific handling and optional Langfuse tracing.

Supports OpenAI-compatible API endpoints.
"""

from typing import Dict, List, Any, Optional
import json
import os
from openai import AsyncOpenAI

from .types import Action, ToolSchema
from .config import ActorConfig

# Optional Langfuse imports - only used if tracing is enabled
try:
    from langfuse.openai import AsyncOpenAI as LangfuseAsyncOpenAI
    from langfuse import Langfuse
    LANGFUSE_AVAILABLE = True
except ImportError:
    LANGFUSE_AVAILABLE = False


class OpenAIClient:
    """
    OpenAI client with configurable backend and format support.

    Handles:
    - OpenAI-compatible API endpoints
    - Tool calling format conversion
    - Response parsing
    - Optional Langfuse tracing
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8080/v1",  # Default for local model
        api_key: str = "not-needed",  # Default for local model
        model: str = "default_model",
        # Optional Langfuse parameters
        enable_tracing: bool = False,
        langfuse_public_key: Optional[str] = None,
        langfuse_secret_key: Optional[str] = None,
        langfuse_host: str = "https://cloud.langfuse.com"
    ):
        """
        Initialize OpenAI client with optional Langfuse tracing.

        Args:
            base_url: API endpoint URL
            api_key: API key
            model: Model name
            enable_tracing: Enable Langfuse tracing
            langfuse_public_key: Langfuse public key (uses env var if not provided)
            langfuse_secret_key: Langfuse secret key (uses env var if not provided)
            langfuse_host: Langfuse host URL
        """
        self.base_url = base_url
        self.api_key = api_key
        self.model = model
        self.enable_tracing = enable_tracing and LANGFUSE_AVAILABLE

        # Initialize client with or without Langfuse wrapper
        if self.enable_tracing:
            # Set up Langfuse environment variables if provided
            if langfuse_public_key:
                os.environ["LANGFUSE_PUBLIC_KEY"] = langfuse_public_key
            if langfuse_secret_key:
                os.environ["LANGFUSE_SECRET_KEY"] = langfuse_secret_key
            os.environ["LANGFUSE_HOST"] = langfuse_host

            # Use Langfuse-wrapped client for automatic tracing
            client_kwargs = {"api_key": api_key}
            if base_url:
                client_kwargs["base_url"] = base_url
            self.client = LangfuseAsyncOpenAI(**client_kwargs)

            # Initialize Langfuse client for additional features (scores, etc.)
            self.langfuse = Langfuse(
                public_key=langfuse_public_key or os.getenv("LANGFUSE_PUBLIC_KEY"),
                secret_key=langfuse_secret_key or os.getenv("LANGFUSE_SECRET_KEY"),
                host=langfuse_host
            )

            print("✅ Langfuse tracing enabled")
        else:
            # Use regular OpenAI client
            client_kwargs = {"api_key": api_key}
            if base_url:
                client_kwargs["base_url"] = base_url
            self.client = AsyncOpenAI(**client_kwargs)
            self.langfuse = None
            if enable_tracing and not LANGFUSE_AVAILABLE:
                print("⚠️ Langfuse requested but not installed. Run: pip install langfuse")

    async def complete(
        self,
        context: str,
        system_prompt: str,
        tools: Dict[str, ToolSchema],
        config: ActorConfig,
        # Optional tracing parameters
        trace_name: Optional[str] = None,
        session_id: Optional[str] = None,
        trace_id: Optional[str] = None,
        user_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        step_name: Optional[str] = None
    ) -> Any:
        """
        Complete with LLM, including tool schemas and optional tracing.

        Args:
            context: User context/prompt
            system_prompt: System prompt
            tools: Available tool schemas
            config: Actor configuration
            trace_name: Optional name for this trace/generation
            session_id: Optional session ID for grouping related calls
            user_id: Optional user ID for tracking
            metadata: Optional metadata dict to attach to trace
            tags: Optional list of tags for categorization
            step_name: Optional step name for multi-step workflows

        Returns:
            Full response message object with content and tool_calls
        """
        # Convert tool schemas to OpenAI format
        tool_schemas = [
            {
                "type": "function",
                "function": {
                    "name": schema.name,
                    "description": schema.description,
                    "parameters": schema.parameters
                }
            }
            for schema in tools.values()
        ]

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": context}
        ]

        # Build kwargs for the API call
        api_kwargs = {
            "model": self.model,
            "messages": messages,
            "tools": tool_schemas,
            "max_tokens": config.llm_max_tokens,
            "temperature": config.llm_temperature
        }

        # Add Langfuse-specific parameters if tracing is enabled
        if self.enable_tracing:
            # Add trace_id as direct argument for Langfuse
            if trace_id:
                api_kwargs["trace_id"] = trace_id

            # The name parameter is used by Langfuse for the generation name
            if trace_name or step_name:
                api_kwargs["name"] = step_name or trace_name

            # Build metadata for Langfuse
            langfuse_metadata = {}
            if metadata:
                langfuse_metadata.update(metadata)
            if session_id:
                langfuse_metadata["langfuse_session_id"] = session_id
            if user_id:
                langfuse_metadata["langfuse_user_id"] = user_id
            if tags:
                langfuse_metadata["langfuse_tags"] = tags

            if langfuse_metadata:
                api_kwargs["metadata"] = langfuse_metadata

        # Make the API call
        response = await self.client.chat.completions.create(**api_kwargs)

        return response.choices[0].message

    def parse_actions(self, message: Any) -> List[Action]:
        """
        Parse message into actions.

        Extracts tool calls as actions and text content as 'response' action.

        Args:
            message: Response message object from SDK

        Returns:
            List of actions (tool calls and/or response)
        """
        actions = []

        # Parse tool calls into actions
        if message.tool_calls:
            for tool_call in message.tool_calls:
                # Parse arguments from JSON string
                try:
                    arguments = json.loads(tool_call.function.arguments)
                except:
                    arguments = {}

                actions.append(Action(
                    type=tool_call.function.name,
                    parameters=arguments
                ))

        # Parse text content as 'response' action
        if message.content:
            actions.append(Action(
                type="response",
                parameters={"content": message.content}
            ))

        return actions

    def add_score(
        self,
        trace_id: str,
        name: str,
        value: float,
        comment: Optional[str] = None
    ):
        """
        Add a score to a trace (only works if tracing is enabled).

        Args:
            trace_id: The trace ID to add score to
            name: Score name (e.g., "accuracy", "relevance")
            value: Score value
            comment: Optional comment
        """
        if self.langfuse:
            self.langfuse.score(
                trace_id=trace_id,
                name=name,
                value=value,
                comment=comment
            )

    def flush(self):
        """
        Flush pending events to Langfuse (important for short-lived scripts).
        """
        if self.langfuse:
            self.langfuse.flush()

