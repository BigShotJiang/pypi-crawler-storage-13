"""
EventBus - True publish/subscribe event bus for actor orchestration.

Provides hierarchical event routing with channel (actor) + event_type patterns.
Supports wildcard subscriptions for flexible monitoring and orchestration.
"""

from typing import Any, Optional, Callable, Dict, List, Tuple
from enum import Enum
from dataclasses import dataclass
import sys
import asyncio
import inspect


class LogLevel(Enum):
    """Logging levels for EventBus."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"
    NONE = "NONE"


@dataclass
class Event:
    """
    Event published on the bus.

    Attributes:
        channel: Source channel (typically actor name)
        event_type: Type of event (e.g., "lifecycle.started", "action.completed")
        data: Event payload
    """
    channel: str
    event_type: str
    data: Any


class EventBus:
    """
    True publish/subscribe event bus with hierarchical topic routing.

    Architecture:
    - Publishers emit events to channels (typically actor names)
    - Each event has a type (e.g., "lifecycle.started", "action.completed")
    - Subscribers register interest in channel + event_type patterns
    - Patterns support wildcards: "*" matches anything

    Example:
        bus = EventBus()

        # Subscribe to specific actor's status changes
        bus.subscribe("Actor1", "lifecycle.status_changed", handler1)

        # Subscribe to all errors from all actors
        bus.subscribe("*", "*.error", handler2)

        # Subscribe to everything from specific actor
        bus.subscribe("Actor1", "*", debug_handler)

        # Publish event
        await bus.publish("Actor1", "lifecycle.started", {"cycle": 0})
    """

    def __init__(self):
        """Initialize EventBus with empty subscription list."""
        # List of (channel_pattern, event_pattern, action_types, handler, is_async)
        self._subscriptions: List[Tuple[str, str, Optional[List[str]], Callable, bool]] = []

    def subscribe(
        self,
        channel_pattern: str,
        event_pattern: str,
        handler: Callable[[Event], Any],
        action_types: Optional[List[str]] = None
    ) -> None:
        """
        Subscribe to events matching channel and event patterns.

        Patterns:
        - Exact match: "Actor1", "lifecycle.started"
        - Wildcard: "*" matches any single segment
        - Pattern examples:
          - ("Actor1", "lifecycle.started") - specific actor, specific event
          - ("*", "lifecycle.started") - all actors, specific event
          - ("Actor1", "*") - specific actor, all events
          - ("*", "*") - all events (monitoring)

        Args:
            channel_pattern: Channel pattern to match (actor name or "*")
            event_pattern: Event type pattern to match (or "*")
            handler: Callable to invoke when event matches
                    Signature: (event: Event) -> None or async (event: Event) -> None
            action_types: Optional list of action types to filter (e.g., ["response", "complete"])
                         Only applies to events with data structure: {"data": [{"action": "..."}]}
        """
        is_async = inspect.iscoroutinefunction(handler)
        self._subscriptions.append((channel_pattern, event_pattern, action_types, handler, is_async))

    def unsubscribe(
        self,
        channel_pattern: str,
        event_pattern: str,
        handler: Callable[[Event], Any]
    ) -> bool:
        """
        Unsubscribe a specific handler.

        Args:
            channel_pattern: Channel pattern that was subscribed
            event_pattern: Event pattern that was subscribed
            handler: Handler to remove

        Returns:
            True if handler was found and removed, False otherwise
        """
        for i, (ch_pat, ev_pat, _, h, _) in enumerate(self._subscriptions):
            if ch_pat == channel_pattern and ev_pat == event_pattern and h == handler:
                self._subscriptions.pop(i)
                return True
        return False

    async def publish(
        self,
        channel: str,
        event_type: str,
        data: Any = None
    ) -> None:
        """
        Publish event to all matching subscribers.

        Routes event to all handlers whose patterns match the channel and event_type.
        Handles both sync and async handlers appropriately.

        Args:
            channel: Event channel (typically actor name)
            event_type: Event type (e.g., "lifecycle.started", "action.completed")
            data: Event payload
        """
        event = Event(channel=channel, event_type=event_type, data=data)

        # Find all matching subscriptions
        for ch_pattern, ev_pattern, action_types, handler, is_async in self._subscriptions:
            if self._matches_pattern(channel, ch_pattern) and \
               self._matches_pattern(event_type, ev_pattern):
                # Filter event data by action_types if specified
                filtered_event = self._filter_event_by_action_types(event, action_types)

                # Only call handler if event passes filter
                if filtered_event is not None:
                    try:
                        if is_async:
                            await handler(filtered_event)
                        else:
                            handler(filtered_event)
                    except Exception as e:
                        # Log handler errors but don't propagate them
                        # This prevents one bad handler from breaking the bus
                        print(f"[EventBus] Handler error: {e}", file=sys.stderr)

    def _matches_pattern(self, value: str, pattern: str) -> bool:
        """
        Check if value matches pattern.

        Currently supports:
        - Exact match: pattern == value
        - Wildcard: pattern == "*"

        Future: Could extend with glob patterns, regex, etc.

        Args:
            value: Actual value to match
            pattern: Pattern to match against

        Returns:
            True if value matches pattern
        """
        if pattern == "*":
            return True

        # Check for wildcard segments (e.g., "lifecycle.*" matches "lifecycle.started")
        if "*" in pattern:
            pattern_parts = pattern.split(".")
            value_parts = value.split(".")

            if len(pattern_parts) != len(value_parts):
                return False

            for p_part, v_part in zip(pattern_parts, value_parts):
                if p_part != "*" and p_part != v_part:
                    return False

            return True

        return pattern == value

    def _filter_event_by_action_types(
        self,
        event: Event,
        action_types: Optional[List[str]]
    ) -> Optional[Event]:
        """
        Filter event data by action types.

        Args:
            event: Event to filter
            action_types: List of action types to include, or None for no filtering

        Returns:
            Filtered event, or None if no actions match filter
        """
        # No filter - pass through original event
        if action_types is None:
            return event

        # Check if event data has expected structure: {"data": [{"action": "..."}]}
        if not isinstance(event.data, dict) or "data" not in event.data:
            return event  # Data doesn't match expected structure, pass through

        action_list = event.data["data"]
        if not isinstance(action_list, list):
            return event  # Not a list, pass through

        # Filter actions to only those matching action_types
        filtered_actions = [
            action for action in action_list
            if isinstance(action, dict) and action.get("action") in action_types
        ]

        # If no actions match filter, don't call handler
        if not filtered_actions:
            return None

        # Return new event with filtered data
        return Event(
            channel=event.channel,
            event_type=event.event_type,
            data={**event.data, "data": filtered_actions}
        )

    def get_subscription_count(self) -> int:
        """Get total number of subscriptions."""
        return len(self._subscriptions)

    def get_subscriptions_for(self, channel: str, event_type: str) -> int:
        """
        Get count of subscriptions that would match given channel/event.

        Useful for debugging and monitoring.

        Args:
            channel: Channel to check
            event_type: Event type to check

        Returns:
            Number of handlers that would receive this event
        """
        count = 0
        for ch_pattern, ev_pattern, _, _ in self._subscriptions:
            if self._matches_pattern(channel, ch_pattern) and \
               self._matches_pattern(event_type, ev_pattern):
                count += 1
        return count


class ColoredLoggingHandler:
    """
    Event subscriber that provides colored logging output.

    This is a reference implementation showing how logging can be
    implemented as a subscriber rather than core EventBus functionality.

    Features:
    - Color coding per channel (actor)
    - Configurable output stream
    - Consistent event formatting
    - Optional event type filtering
    """

    # ANSI color codes
    COLORS = [
        "\033[94m",  # Blue
        "\033[92m",  # Green
        "\033[93m",  # Yellow
        "\033[95m",  # Magenta
        "\033[96m",  # Cyan
        "\033[91m",  # Red
    ]
    RESET = "\033[0m"

    def __init__(
        self,
        stream_to: str = "stdout",
        color_enabled: bool = True,
        event_filter: Optional[List[str]] = None
    ):
        """
        Initialize logging handler.

        Args:
            stream_to: Output stream ("stdout" or "stderr")
            color_enabled: Whether to use color coding
            event_filter: Optional list of event type prefixes to log (e.g., ["lifecycle", "action.failed"])
                         If None, logs all events
        """
        self._stream = sys.stdout if stream_to == "stdout" else sys.stderr
        self._color_enabled = color_enabled
        self._event_filter = event_filter

        # Color assignments per channel
        self._channel_colors: Dict[str, str] = {}
        self._next_color_idx = 0

    def handle(self, event: Event) -> None:
        """
        Handle event and log it.

        Args:
            event: Event to log
        """
        # Apply event filter if configured
        if self._event_filter is not None:
            if not any(event.event_type.startswith(prefix) for prefix in self._event_filter):
                return

        # Format and print
        color = self._get_channel_color(event.channel)
        reset = self.RESET if self._color_enabled else ""

        # Format: [CHANNEL] event_type: data
        message = f"{color}[{event.channel}] {event.event_type}: {self._format_data(event.data)}{reset}"
        print(message, file=self._stream, flush=True)

    def _get_channel_color(self, channel: str) -> str:
        """Get consistent color for a channel."""
        if not self._color_enabled:
            return ""

        if channel not in self._channel_colors:
            color_idx = self._next_color_idx % len(self.COLORS)
            self._channel_colors[channel] = self.COLORS[color_idx]
            self._next_color_idx += 1

        return self._channel_colors[channel]

    def _format_data(self, data: Any) -> str:
        """Format event data for display."""
        if data is None:
            return ""

        # Simple string representation
        return str(data)


class StateMirrorHandler:
    """
    Event subscriber that maintains a state mirror.

    Useful for external monitoring and introspection of actor states.
    """

    def __init__(self):
        """Initialize empty state mirror."""
        # {channel: {field: value}}
        self._state_mirror: Dict[str, Dict[str, Any]] = {}

    def handle(self, event: Event) -> None:
        """
        Handle event and update state mirror.

        Args:
            event: Event to process
        """
        # Only mirror state-related events
        if not event.event_type.startswith("state."):
            return

        channel = event.channel

        if channel not in self._state_mirror:
            self._state_mirror[channel] = {}

        # Extract field name from event type (e.g., "state.status" -> "status")
        field = event.event_type.split(".", 1)[1] if "." in event.event_type else event.event_type

        self._state_mirror[channel][field] = event.data

    def get_state(self, channel: Optional[str] = None) -> Dict[str, Any]:
        """
        Get mirrored state.

        Args:
            channel: If specified, return state for this channel only.
                    If None, return all channel states.

        Returns:
            Dictionary of state data
        """
        if channel is not None:
            return self._state_mirror.get(channel, {})

        return self._state_mirror.copy()
