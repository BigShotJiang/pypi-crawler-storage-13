"""
Configuration classes for Atomic Actor framework.

All actor behavior is driven by configuration passed at instantiation.
"""

from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field


@dataclass
class HistoryRule:
    """
    Rule for including historical data in perception.

    Defines how previous tool usage should supplement current context.
    """
    tool_type: str
    include_previous: int = 1
    include_results: bool = True


@dataclass
class PerceptionConfig:
    """
    Configuration for actor perception behavior.

    Controls how actor supplements observations with historical state.
    """
    include_history: bool = True
    observation_window: int = 3  # Latest N observations to include
    history_rules: List[HistoryRule] = field(default_factory=list)

    # Observation sources that contain action results to filter
    filter_observation_sources: List[str] = field(default_factory=list)
    # Example: ["cycle.data"] - will apply tool_configs filtering to these observations


@dataclass
class ToolFormatConfig:
    """
    Configuration for tool calling format.

    Defines how tools are presented to LLM and how responses are parsed.
    """
    format_type: str = "lfm2_python"  # "native", "lfm2_python", "json"
    templates_file: Optional[str] = None  # Path to external templates if needed


@dataclass
class ActorConfig:
    """
    Complete configuration for an Atomic Actor.

    All behavioral configuration is specified here and passed at instantiation.
    """
    # System prompt for the actor
    system_prompt: str = "You are a helpful assistant."

    # Sub-configurations
    perception: PerceptionConfig = field(default_factory=PerceptionConfig)
    tool_format: ToolFormatConfig = field(default_factory=ToolFormatConfig)

    # Tool-specific configurations
    tool_configs: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    # Example: {"brave_web_search": {"format_fields_include": ["title", "description"]}}

    # EventBus subscriptions for cross-actor communication
    event_subscriptions: List[Dict[str, Any]] = field(default_factory=list)
    # Example: [{"channel": "PlanningActor", "event_type": "cycle.data", "action_type": ["response"]}]
    # action_type is optional - filters which actions from cycle.data to receive

    # LLM settings (kept generic - SDK handles specifics)
    llm_model: str = "default"
    llm_temperature: float = 0.2
    llm_max_tokens: int = 1000

    # Completion detection
    completion_tool_name: str = "complete"  # Name of completion tool

    # Tracing identifiers (for observability)
    trace_id: Optional[str] = None  # Trace ID for grouping related actors/calls in single execution
    session_id: Optional[str] = None  # Session ID for grouping multiple executions

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "ActorConfig":
        """
        Create ActorConfig from dictionary.

        Useful for loading from YAML/JSON files.

        Args:
            config_dict: Configuration as dictionary

        Returns:
            ActorConfig instance
        """
        # Parse history rules if present
        history_rules = []
        perception_dict = config_dict.get("perception", {})
        if "history_rules" in perception_dict:
            for rule in perception_dict["history_rules"]:
                history_rules.append(HistoryRule(**rule))
            perception_dict["history_rules"] = history_rules

        perc_config = PerceptionConfig(**perception_dict)

        tool_format_config = ToolFormatConfig(**config_dict.get("tool_format", {}))

        # Create main config
        return cls(
            system_prompt=config_dict.get("system_prompt", "You are a helpful assistant."),
            perception=perc_config,
            tool_format=tool_format_config,
            tool_configs=config_dict.get("tool_configs", {}),
            event_subscriptions=config_dict.get("event_subscriptions", []),
            llm_model=config_dict.get("llm_model", "default"),
            llm_temperature=config_dict.get("llm_temperature", 0.7),
            llm_max_tokens=config_dict.get("llm_max_tokens", 1000),
            completion_tool_name=config_dict.get("completion_tool_name", "complete"),
            trace_id=config_dict.get("trace_id"),
            session_id=config_dict.get("session_id")
        )
