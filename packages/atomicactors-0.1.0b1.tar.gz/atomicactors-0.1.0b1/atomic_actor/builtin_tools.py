"""
Built-in tools for the Atomic Actor framework.

These tools are framework primitives, not user-defined tools.
"""

from .types import ToolSchema


def _completion_func(**kwargs):
    """Completion tool function - returns kwargs as-is."""
    return kwargs


# Completion tool - ready to register
COMPLETION_TOOL = {
    "name": "complete",
    "func": _completion_func,
    "schema": ToolSchema(
        name="complete",
        description="Mark task as complete",
        parameters={
            "type": "object",
            "properties": {
                "status": {"type": "string", "enum": ["completed", "failed"]}
            },
            "required": ["status"]
        }
    )
}
