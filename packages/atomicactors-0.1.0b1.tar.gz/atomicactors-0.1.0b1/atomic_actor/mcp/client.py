"""
MCP Client for JSON-RPC communication with MCP servers via stdio.
"""

import asyncio
import json
import os
from typing import Dict, Any, Optional
from .config import MCPServerConfig
from .logger import mcp_logger


class MCPClient:
    """
    Client for managing MCP server processes and JSON-RPC communication.

    Handles:
    - Starting MCP servers via subprocess
    - JSON-RPC message sending/receiving
    - Tool discovery and invocation
    """

    def __init__(self):
        self.servers: Dict[str, MCPServerConfig] = {}
        self.processes: Dict[str, asyncio.subprocess.Process] = {}
        self.tool_registry: Dict[str, str] = {}  # tool_name -> server_name
        self._request_id = 100

    async def add_server(self, config: MCPServerConfig) -> None:
        """
        Add and start an MCP server.

        Args:
            config: MCPServerConfig with server details
        """
        if config.name in self.servers:
            raise ValueError(f"Server {config.name} already registered")

        self.servers[config.name] = config

        # Start the server process
        await self._start_server(config)

        # Initialize the server
        await self._initialize_server(config)

        # Discover available tools
        await self._discover_tools(config)

    async def _start_server(self, config: MCPServerConfig) -> None:
        """Start an MCP server subprocess."""
        cmd = config.command + config.args

        # Merge environment variables
        env = os.environ.copy()
        env.update(config.env)

        # Substitute environment variables in env dict
        for key, value in env.items():
            if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                env_var = value[2:-1]
                env[key] = os.getenv(env_var, "")

        # Create subprocess with pipes
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env
        )

        self.processes[config.name] = process

        # Log server start
        mcp_logger.log(config.name, "INFO", f"Started stdio server with command: {' '.join(cmd)}")

        # Stream stderr to log (stdout is for JSON-RPC)
        asyncio.create_task(
            mcp_logger.stream_process_output(
                config.name,
                None,  # Don't stream stdout - it's for JSON-RPC
                process.stderr
            )
        )

        # Wait a moment for server to start
        await asyncio.sleep(1)

        # Check if process is still running
        if process.returncode is not None:
            raise RuntimeError(f"Server {config.name} died immediately with code {process.returncode}")

    async def _initialize_server(self, config: MCPServerConfig) -> None:
        """Send initialize request to MCP server."""
        response = await self._send_request(config.name, {
            "jsonrpc": "2.0",
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {
                    "name": "atomic-actor",
                    "version": "0.1.0"
                }
            },
            "id": self._get_next_id()
        })

        if "error" in response:
            raise RuntimeError(f"Failed to initialize {config.name}: {response['error']}")

    async def _discover_tools(self, config: MCPServerConfig) -> None:
        """Discover available tools from MCP server."""
        response = await self._send_request(config.name, {
            "jsonrpc": "2.0",
            "method": "tools/list",
            "params": {},
            "id": self._get_next_id()
        })

        if "result" in response and "tools" in response["result"]:
            tools = response["result"]["tools"]
            for tool in tools:
                tool_name = tool["name"]

                # Filter based on config
                if config.tools_expose is not None:
                    if tool_name not in config.tools_expose:
                        continue

                # Register tool with server mapping
                self.tool_registry[tool_name] = config.name

    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """
        Call an MCP tool with retry logic for rate limits.

        Args:
            tool_name: Name of the tool to call
            arguments: Tool arguments

        Returns:
            MCP tool result (native format)
        """
        if tool_name not in self.tool_registry:
            raise ValueError(f"Tool '{tool_name}' not found in any MCP server")

        server_name = self.tool_registry[tool_name]

        # Retry logic for rate limiting
        max_retries = 5
        base_delay = 1.0  # seconds

        for attempt in range(max_retries):
            response = await self._send_request(server_name, {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {
                    "name": tool_name,
                    "arguments": arguments
                },
                "id": self._get_next_id()
            })

            if "result" in response:
                result = response["result"]

                # Check if result contains rate limit error (429)
                if self._is_rate_limited(result):
                    if attempt < max_retries - 1:
                        # Exponential backoff
                        delay = base_delay * (2 ** attempt)
                        print(f"[MCP] Rate limited, retrying in {delay}s (attempt {attempt + 1}/{max_retries})")
                        await asyncio.sleep(delay)
                        continue
                    else:
                        # Final attempt failed, return simplified error
                        return {
                            "content": [{
                                "type": "text",
                                "text": "Error: Rate limit exceeded. Please try again later."
                            }]
                        }

                return result
            elif "error" in response:
                raise Exception(f"MCP tool error: {response['error']}")
            else:
                raise Exception("Invalid MCP response")

    def _is_rate_limited(self, result: Any) -> bool:
        """Check if result contains a rate limit error."""
        if isinstance(result, dict) and "content" in result:
            for item in result.get("content", []):
                if isinstance(item, dict) and item.get("type") == "text":
                    text = item.get("text", "")
                    if "429" in text or "RATE_LIMITED" in text:
                        return True
        return False

    async def get_tool_schema(self, tool_name: str) -> Dict[str, Any]:
        """
        Get schema for a specific tool.

        Args:
            tool_name: Tool name

        Returns:
            Tool schema from MCP server
        """
        if tool_name not in self.tool_registry:
            raise ValueError(f"Tool '{tool_name}' not found")

        server_name = self.tool_registry[tool_name]

        response = await self._send_request(server_name, {
            "jsonrpc": "2.0",
            "method": "tools/list",
            "params": {},
            "id": self._get_next_id()
        })

        if "result" in response and "tools" in response["result"]:
            for tool in response["result"]["tools"]:
                if tool["name"] == tool_name:
                    return tool

        raise ValueError(f"Tool schema not found for {tool_name}")

    async def _send_request(self, server_name: str, request: Dict) -> Dict:
        """Send JSON-RPC request to MCP server via stdio."""
        if server_name not in self.processes:
            raise RuntimeError(f"Server {server_name} not running")

        process = self.processes[server_name]

        if not process.stdin or not process.stdout:
            raise RuntimeError(f"Server {server_name} pipes not available")

        # Log and send request
        mcp_logger.log(server_name, "SEND", json.dumps(request))
        request_str = json.dumps(request) + "\n"
        process.stdin.write(request_str.encode())
        await process.stdin.drain()

        # Read response
        response_line = await process.stdout.readline()
        if response_line:
            response = json.loads(response_line.decode())
            mcp_logger.log(server_name, "RECV", json.dumps(response))
            return response

        return {}

    async def shutdown(self) -> None:
        """Shutdown all MCP servers."""
        for server_name, process in list(self.processes.items()):
            process.terminate()
            await process.wait()

        self.processes.clear()
        self.servers.clear()
        self.tool_registry.clear()

    def _get_next_id(self) -> int:
        """Get next request ID."""
        self._request_id += 1
        return self._request_id

    def list_tools(self) -> Dict[str, str]:
        """
        List all available tools.

        Returns:
            Dict mapping tool_name to server_name
        """
        return self.tool_registry.copy()
