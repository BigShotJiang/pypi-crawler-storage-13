"""MCP logging to shared file."""

from datetime import datetime
from pathlib import Path
from collections import deque
import threading


class MCPLogger:
    """Shared logger for all MCP JSON-RPC communication."""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self, log_file: str = "mcp.log", max_lines: int = 200):
        if self._initialized:
            return

        self.log_file = Path(log_file)
        self.max_lines = max_lines
        self.buffer = deque(maxlen=max_lines)
        self._initialized = True

    def log(self, server_name: str, level: str, message: str):
        """Add a log entry."""
        timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        entry = f"[{timestamp}] [{server_name}] {level}: {message}"

        with self._lock:
            self.buffer.append(entry)
            self._write_to_file()

    def _write_to_file(self):
        """Write buffer to file."""
        with open(self.log_file, 'w') as f:
            for line in self.buffer:
                f.write(line + '\n')

    async def stream_process_output(
        self,
        server_name: str,
        stdout,
        stderr
    ):
        """Stream process stderr output to log."""
        import asyncio

        async def read_stream(stream, prefix):
            while True:
                try:
                    line = await stream.readline()
                    if not line:
                        break
                    text = line.decode().rstrip()
                    if text:
                        self.log(server_name, prefix, text)
                except Exception as e:
                    self.log(server_name, "ERROR", f"Stream read error: {e}")
                    break

        # Create tasks for streams
        tasks = []
        if stdout:
            tasks.append(asyncio.create_task(read_stream(stdout, "OUT")))
        if stderr:
            tasks.append(asyncio.create_task(read_stream(stderr, "ERR")))

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)


# Global logger instance
mcp_logger = MCPLogger()
