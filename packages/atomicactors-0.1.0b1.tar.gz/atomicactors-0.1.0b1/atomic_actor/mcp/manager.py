"""
MCP Manager for high-level MCP integration with Atomic Actor.
"""

from typing import Dict, Any, List, Optional
from ..types import ToolSchema
from ..tool_registry import ToolRegistry
from .client import MCPClient
from .config import MCPServerConfig, MCPToolConfig


class MCPManager:
    """
    High-level manager for MCP integration.

    Handles:
    - Server lifecycle
    - Tool discovery
    - Automatic registration with ToolRegistry
    - Response field filtering
    """

    def __init__(self, servers_config: List[Dict[str, Any]]):
        """
        Initialize MCP manager.

        Args:
            servers_config: List of server configuration dicts
        """
        self.client = MCPClient()
        self.configs: List[MCPServerConfig] = []
        self.tool_configs: Dict[str, MCPToolConfig] = {}  # tool_name -> config

        # Parse server configs
        for config_dict in servers_config:
            # Parse tool_configs if present
            tool_configs = {}
            if "tool_configs" in config_dict:
                for tool_name, tool_config_dict in config_dict["tool_configs"].items():
                    tool_configs[tool_name] = MCPToolConfig(**tool_config_dict)
                config_dict["tool_configs"] = tool_configs

            config = MCPServerConfig(**config_dict)
            self.configs.append(config)

    async def start(self) -> None:
        """Start all configured MCP servers."""
        for config in self.configs:
            await self.client.add_server(config)

    async def register_tools(self, tool_registry: ToolRegistry) -> None:
        """
        Discover MCP tools and register them with ToolRegistry.

        Args:
            tool_registry: ToolRegistry to register tools with
        """
        for tool_name, server_name in self.client.list_tools().items():
            # Get tool schema from MCP
            mcp_schema = await self.client.get_tool_schema(tool_name)

            # Get server config
            server_config = next(c for c in self.configs if c.name == server_name)

            # Get tool-specific config if exists
            tool_config = server_config.tool_configs.get(tool_name)

            # Store tool config for later formatting
            if tool_config:
                self.tool_configs[tool_name] = tool_config

            # Create async callable that wraps MCP tool
            # Use default args to capture by value (avoid closure bug)
            async def tool_func(_tool_name=tool_name, _tool_config=tool_config, **kwargs):
                return await self._call_mcp_tool(_tool_name, kwargs, _tool_config)

            # Convert MCP schema to ToolSchema, filtering params if configured
            tool_schema = self._convert_schema(mcp_schema, tool_config)

            # Register with ToolRegistry
            tool_registry.register(
                name=tool_name,
                func=tool_func,
                schema=tool_schema
            )

    async def _call_mcp_tool(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        tool_config: Optional[MCPToolConfig]
    ) -> Any:
        """
        Call MCP tool and return result.

        Args:
            tool_name: Tool name
            arguments: Tool arguments
            tool_config: Optional tool-specific config (single MCPToolConfig for this tool)

        Returns:
            MCP tool result (native format)
        """
        # Filter parameters if params_expose is configured
        if tool_config and tool_config.params_expose is not None:
            arguments = {
                k: v for k, v in arguments.items()
                if k in tool_config.params_expose
            }

        # Call MCP tool
        result = await self.client.call_tool(tool_name, arguments)

        # Apply response field filtering if configured
        if tool_config:
            result = self._filter_response(result, tool_config)

        # Return raw result
        return result

    def _filter_response(
        self,
        response: Any,
        config: MCPToolConfig
    ) -> Any:
        """
        Filter response fields based on config.

        Parses JSON strings in 'text' fields and filters them.

        Args:
            response: MCP response
            config: Tool config with field filters

        Returns:
            Filtered response
        """
        import json

        # Apply top-level filtering first
        if isinstance(response, dict):
            response = self._filter_dict(response, config)

        return response

    def _filter_dict(self, data: Dict[str, Any], config: MCPToolConfig, use_format_fields: bool = False) -> Dict[str, Any]:
        """
        Filter dictionary fields using dot notation paths.

        Args:
            data: Dictionary to filter
            config: Tool config with field filters
            use_format_fields: If True, use format_fields_* instead of response_fields_*
        """
        from ..helpers.formatters import filter_dict_fields

        if use_format_fields:
            include = config.format_fields_include
            exclude = config.format_fields_exclude
        else:
            include = config.response_fields_include
            exclude = config.response_fields_exclude

        return filter_dict_fields(data, include=include, exclude=exclude)

    def format_response(self, response: Any, tool_config: Optional[MCPToolConfig] = None) -> str:
        """
        Format MCP response for LLM consumption.

        Applies format field filtering if tool_config provided.

        Args:
            response: MCP response (native format)
            tool_config: Optional tool config for format field filtering

        Returns:
            String representation suitable for LLM context
        """
        import json

        # Apply format field filtering if configured
        if tool_config and (tool_config.format_fields_include or tool_config.format_fields_exclude):
            # Clone response to avoid mutating original
            response = json.loads(json.dumps(response))

            # Handle MCP content array format
            if isinstance(response, dict) and "content" in response:
                content = response["content"]

                if isinstance(content, list):
                    for item in content:
                        if isinstance(item, dict):
                            # If this is a text item with JSON string, parse and filter for display
                            if item.get("type") == "text" and isinstance(item.get("text"), str):
                                try:
                                    # Try to parse as JSON
                                    parsed = json.loads(item["text"])
                                    if isinstance(parsed, dict):
                                        # Filter using format_fields_*
                                        filtered = self._filter_dict(parsed, tool_config, use_format_fields=True)
                                        # Re-serialize
                                        item["text"] = json.dumps(filtered)
                                except json.JSONDecodeError:
                                    # Not JSON, leave as-is
                                    pass

        # Now format to string
        # Handle MCP content array format
        if isinstance(response, dict) and "content" in response:
            content = response["content"]

            if isinstance(content, list):
                # Extract text from content items
                text_parts = []
                for item in content:
                    if isinstance(item, dict):
                        if item.get("type") == "text":
                            text_parts.append(item.get("text", ""))
                        else:
                            # Other content types (image, etc.) - stringify
                            text_parts.append(json.dumps(item, indent=2))
                    else:
                        text_parts.append(str(item))

                return "\n\n".join(text_parts)

        # Handle dict responses
        if isinstance(response, dict):
            return json.dumps(response, indent=2)

        # Handle list responses
        if isinstance(response, list):
            return "\n".join(str(item) for item in response)

        # Default: stringify
        return str(response)

    def _convert_schema(self, mcp_schema: Dict[str, Any], tool_config: Optional[MCPToolConfig] = None) -> ToolSchema:
        """
        Convert MCP tool schema to ToolSchema.

        Args:
            mcp_schema: MCP tool schema
            tool_config: Optional tool config with params_expose

        Returns:
            ToolSchema instance
        """
        parameters = mcp_schema.get("inputSchema", {})

        # Filter parameters if params_expose is configured
        if tool_config and tool_config.params_expose is not None:
            if "properties" in parameters:
                filtered_properties = {
                    k: v for k, v in parameters["properties"].items()
                    if k in tool_config.params_expose
                }
                parameters = {**parameters, "properties": filtered_properties}

                # Also filter required list if present
                if "required" in parameters:
                    parameters["required"] = [
                        r for r in parameters["required"]
                        if r in tool_config.params_expose
                    ]

        return ToolSchema(
            name=mcp_schema["name"],
            description=mcp_schema.get("description", ""),
            parameters=parameters
        )

    def get_combined_system_prompt(self) -> str:
        """
        Get combined system prompt additions from all registered tools.

        Returns:
            Combined system prompt additions, or empty string if none
        """
        prompt_parts = []
        for tool_name, tool_config in self.tool_configs.items():
            if tool_config.system_prompt_addition:
                prompt_parts.append(tool_config.system_prompt_addition)

        return "\n".join(prompt_parts) if prompt_parts else ""

    async def shutdown(self) -> None:
        """Shutdown all MCP servers."""
        await self.client.shutdown()
