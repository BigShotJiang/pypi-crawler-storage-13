"""
MCP Configuration dataclasses.
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field


@dataclass
class MCPToolConfig:
    """Configuration for a single MCP tool."""
    # Tool-specific system prompt addition
    system_prompt_addition: Optional[str] = None  # Add this to system prompt when tool is available

    # Filter which parameters are exposed to LLM
    params_expose: Optional[List[str]] = None  # Only allow these parameters (None = all)

    # Filter raw data stored in actor state
    response_fields_include: Optional[List[str]] = None  # Whitelist fields in raw response
    response_fields_exclude: Optional[List[str]] = None  # Blacklist fields in raw response

    # Filter formatted data shown to LLM
    format_fields_include: Optional[List[str]] = None  # Whitelist fields in formatted output
    format_fields_exclude: Optional[List[str]] = None  # Blacklist fields in formatted output


@dataclass
class MCPServerConfig:
    """Configuration for an MCP server."""
    name: str
    command: List[str]
    args: List[str] = field(default_factory=list)
    env: Dict[str, str] = field(default_factory=dict)
    transport: str = "stdio"

    # Tool filtering
    tools_expose: Optional[List[str]] = None  # Only expose these tools (None = all)

    # Per-tool response field configuration
    tool_configs: Dict[str, MCPToolConfig] = field(default_factory=dict)
