"""
MCP (Model Context Protocol) integration for Atomic Actor.

Provides:
- MCPClient: Low-level JSON-RPC communication
- MCPManager: High-level integration with ToolRegistry
- Configuration dataclasses
"""

from .client import MCPClient
from .manager import MCPManager
from .config import MCPServerConfig, MCPToolConfig

__all__ = [
    "MCPClient",
    "MCPManager",
    "MCPServerConfig",
    "MCPToolConfig",
]
