"""
Environment - Free-form key-value store for actor state and observations.

The environment is where actors push results and pull observations.
It can be shared by multiple actors.
"""

from typing import Any, List, Optional
from collections import deque


class Environment:
    """
    Free-form KV store with built-in methods.

    Actors push data to the environment (e.g., tool results) and pull
    observations from it. The environment can also be written to externally.
    """

    def __init__(self, max_per_key: int = 1000):
        """
        Initialize environment.

        Args:
            max_per_key: Maximum items to store per key (prevents unbounded growth)
        """
        self._store: dict[str, deque] = {}
        self._max_per_key = max_per_key

    async def push(self, key: str, value: Any) -> None:
        """
        Push a value to the environment.

        Actors call this to add observations (e.g., tool results).

        Args:
            key: Storage key (e.g., "tool_results.search", "user_messages")
            value: Data to store
        """
        if key not in self._store:
            self._store[key] = deque(maxlen=self._max_per_key)

        self._store[key].append(value)

    async def pull(
        self,
        key: str,
        window: Optional[int] = None
    ) -> List[Any]:
        """
        Pull values from the environment.

        Actors call this during observe() to get observations.

        Args:
            key: Storage key to retrieve
            window: If specified, return only last N items

        Returns:
            List of values for the key (empty list if key doesn't exist)
        """
        if key not in self._store:
            return []

        items = list(self._store[key])

        if window is not None:
            return items[-window:]

        return items

    async def peek(self, key: str) -> Optional[Any]:
        """
        Get the most recent value without removing it.

        Args:
            key: Storage key

        Returns:
            Most recent value, or None if key doesn't exist
        """
        if key not in self._store or not self._store[key]:
            return None

        return self._store[key][-1]

    def keys(self) -> List[str]:
        """Get all keys currently in the environment."""
        return list(self._store.keys())

    def clear(self, key: Optional[str] = None) -> None:
        """
        Clear environment data.

        Args:
            key: If specified, clear only this key. Otherwise clear all.
        """
        if key is not None:
            if key in self._store:
                self._store[key].clear()
        else:
            self._store.clear()

    def __len__(self) -> int:
        """Total number of keys in environment."""
        return len(self._store)

    def __contains__(self, key: str) -> bool:
        """Check if key exists in environment."""
        return key in self._store
