"""
ToolRegistry - Interface for registering and invoking tools.

NO tool-specific code here. Pure registration and invocation.
"""

from typing import Callable, Dict, Any, Optional, List
from .types import ToolSchema


class ToolNotFoundError(Exception):
    """Raised when attempting to invoke a tool that doesn't exist."""
    pass


class ToolRegistry:
    """
    Registry for tools available to actors.

    Provides:
    - Tool registration (name, callable, schema)
    - Tool invocation by name
    - Schema retrieval for LLM prompts

    NO tool-specific logic - purely generic registration/invocation.
    """

    def __init__(self):
        """Initialize empty registry."""
        self._tools: Dict[str, Callable] = {}
        self._schemas: Dict[str, ToolSchema] = {}

    def register(
        self,
        name: str,
        func: Callable,
        schema: ToolSchema
    ) -> None:
        """
        Register a tool.

        Args:
            name: Tool name (used for invocation)
            func: Callable that implements the tool (async or sync)
            schema: ToolSchema describing the tool's interface

        Raises:
            ValueError: If tool name already registered
        """
        if name in self._tools:
            raise ValueError(f"Tool '{name}' already registered")

        self._tools[name] = func
        self._schemas[name] = schema

    def unregister(self, name: str) -> None:
        """
        Unregister a tool.

        Args:
            name: Tool name to remove

        Raises:
            ToolNotFoundError: If tool doesn't exist
        """
        if name not in self._tools:
            raise ToolNotFoundError(f"Tool '{name}' not found")

        del self._tools[name]
        del self._schemas[name]

    async def invoke(self, name: str, **kwargs) -> Any:
        """
        Invoke a tool by name.

        Args:
            name: Tool name
            **kwargs: Parameters to pass to the tool

        Returns:
            Tool result

        Raises:
            ToolNotFoundError: If tool doesn't exist
        """
        if name not in self._tools:
            raise ToolNotFoundError(f"Tool '{name}' not found")

        tool = self._tools[name]

        # Handle both async and sync tools
        if hasattr(tool, '__call__'):
            result = tool(**kwargs)
            # If it's a coroutine, await it
            if hasattr(result, '__await__'):
                return await result
            return result

        return None

    def get_schema(self, name: str) -> ToolSchema:
        """
        Get schema for a specific tool.

        Args:
            name: Tool name

        Returns:
            ToolSchema for the tool

        Raises:
            ToolNotFoundError: If tool doesn't exist
        """
        if name not in self._schemas:
            raise ToolNotFoundError(f"Tool '{name}' not found")

        return self._schemas[name]

    def get_schemas(self) -> Dict[str, ToolSchema]:
        """
        Get registered tool schemas.

        Returns:
            Dictionary mapping tool names to their schemas
        """
        return self._schemas.copy()

    def list_tools(self) -> list[str]:
        """
        Get list of all registered tool names.

        Returns:
            List of tool names
        """
        return list(self._tools.keys())

    def has_tool(self, name: str) -> bool:
        """
        Check if a tool is registered.

        Args:
            name: Tool name

        Returns:
            True if tool exists, False otherwise
        """
        return name in self._tools

    def __len__(self) -> int:
        """Number of registered tools."""
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        """Check if tool is registered (supports 'in' operator)."""
        return name in self._tools
