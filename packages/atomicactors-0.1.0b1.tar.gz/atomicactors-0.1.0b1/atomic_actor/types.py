"""
Core types for Atomic Actor framework.

Defines fundamental data structures used throughout the system.
"""

from typing import Any, Dict, List, Optional
from dataclasses import dataclass
from enum import Enum


class ObservationType(Enum):
    """Types of observations an actor can receive."""
    TOOL_RESULT = "tool_result"
    USER_MESSAGE = "user_message"
    EXTERNAL_EVENT = "external_event"


@dataclass
class Observation:
    """
    Observation from the environment.

    Observations represent input to the actor from the environment,
    such as tool results, user messages, or external events.
    """
    type: ObservationType
    data: Any
    source: str
    cycle: Optional[int] = None


@dataclass
class Action:
    """
    Action to be executed by the actor.

    Actions are parsed from LLM responses and represent tool calls
    or other operations the actor wants to perform.
    """
    type: str
    parameters: Dict[str, Any]

    def __post_init__(self):
        """Ensure parameters is always a dict."""
        if self.parameters is None:
            self.parameters = {}


@dataclass
class ToolSchema:
    """
    Schema defining a tool's interface.

    Contains metadata about a tool for LLM prompt generation.
    """
    name: str
    description: str
    parameters: Dict[str, Any]  # JSON schema format

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for LLM prompt."""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters
        }


class ActorStatus(Enum):
    """Status of an actor's execution."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"


@dataclass
class ActorState:
    """
    Complete state snapshot of an actor at a given cycle.

    Returned by get_state() and yielded by clock() generator.
    """
    name: str
    status: ActorStatus
    cycle_num: int
    actions: List[List[Action]]
    observations: List[List[Observation]]
    data: List[Any]

    def to_tuple(self) -> tuple:
        """Convert to tuple for backwards compatibility."""
        return (
            self.name,
            self.status,
            self.cycle_num,
            self.actions,
            self.observations,
            self.data
        )
