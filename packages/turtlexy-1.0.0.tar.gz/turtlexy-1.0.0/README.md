# turtlexy

Расширенная версия библиотеки turtle с автоматической координатной сеткой.

## Описание

`turtlexy` - это модифицированная версия стандартной библиотеки Python `turtle`, которая автоматически отображает координатную сетку с осями при создании графического окна. Это делает библиотеку особенно полезной для обучения программированию и визуализации координат.

## Особенности

- ✅ **Автоматическая координатная сетка** - сетка рисуется автоматически при создании окна
- ✅ **Зеленые оси координат** - четко видимые оси X и Y
- ✅ **Голубая сетка** - сетка с шагом 50 пикселей для удобной ориентации
- ✅ **Подписи координат** - числовые подписи на осях
- ✅ **Управление сеткой** - команды `hide_grid()` и `show_grid()` для управления отображением
- ✅ **100% совместимость** - все стандартные функции turtle работают как обычно
- ✅ **Удобный импорт** - после `import turtlexy` можно использовать `turtle.setup()`

## Установка

```bash
pip install turtlexy
```

## Быстрый старт

```python
import turtlexy

# Сетка рисуется автоматически!
turtle.setup(500, 500)
turtle.forward(100)
turtle.right(90)
turtle.forward(100)
turtle.done()
```

## Использование

### Базовое использование

```python
import turtlexy

# После импорта turtlexy переменная turtle доступна автоматически
turtle.setup(500, 500)
turtle.forward(100)
turtle.right(90)
turtle.forward(100)
turtle.done()
```

### Управление сеткой

```python
import turtlexy

turtle.setup(500, 500)

# Скрыть сетку
turtle.hide_grid()

# Показать сетку обратно
turtle.show_grid()

turtle.forward(100)
turtle.done()
```

### Использование через объект Screen

```python
import turtlexy

screen = turtle.Screen()
screen.setup(500, 500)

# Скрыть сетку
screen.hide_grid()

# Показать сетку
screen.show_grid()

turtle.done()
```

## Новые функции

### `hide_grid()`

Скрывает координатную сетку с осями.

```python
turtle.hide_grid()
```

### `show_grid()`

Показывает координатную сетку с осями.

```python
turtle.show_grid()
```

## Примеры

### Простой квадрат

```python
import turtlexy

turtle.setup(400, 400)
turtle.speed(2)

for _ in range(4):
    turtle.forward(100)
    turtle.right(90)

turtle.done()
```

### Круг с координатной сеткой

```python
import turtlexy

turtle.setup(600, 600)
turtle.speed(5)

# Сетка видна автоматически
turtle.circle(100)

# Можно скрыть сетку для чистого вида
turtle.hide_grid()
turtle.circle(150)

turtle.done()
```

## Совместимость

`turtlexy` полностью совместим со стандартной библиотекой `turtle`. Все стандартные функции, классы и методы работают точно так же.

## Лицензия

Этот проект основан на `turtle.py` от Gregor Lingl (2006-2010), который распространяется свободно с ограничениями, указанными в исходном коде.

## Автор


Автор модификации Grossbeak
Основано на `turtle.py` от Gregor Lingl. Модифицировано для добавления автоматической координатной сетки.

## Ссылки

- [Оригинальный turtle.py](http://www.python.org)
- [Документация Python turtle](https://docs.python.org/3/library/turtle.html)

