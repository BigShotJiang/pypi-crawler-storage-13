from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="turtlexy",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="Turtle graphics library with automatic coordinate grid",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-username/turtlexy",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Education",
        "Intended Audience :: Developers",
        "Topic :: Education",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: Python Software Foundation License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    keywords="turtle graphics education grid coordinates axes",
    project_urls={
        "Bug Reports": "https://github.com/your-username/turtlexy/issues",
        "Source": "https://github.com/your-username/turtlexy",
    },
)

