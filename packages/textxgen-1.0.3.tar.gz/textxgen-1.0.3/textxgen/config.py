# textxgen/config.py
import random
from typing import List


class Config:
    """
    Configuration class for TextxGen package.
    Stores API key, endpoints, and other configurations.
    """

    # Base URL for OpenRouter API
    BASE_URL = "https://openrouter.ai/api/v1"

    # OpenRouter API URL
    OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"

    # Proxy URL for the Vercel deployment
    PROXY_URL = "https://vercel-proxy-alpha-coral.vercel.app"

    # Package version
    VERSION = "1.0.3"

    # Supported models (actual model IDs)
    SUPPORTED_MODELS = {
        "grok4.1_fast": "x-ai/grok-4.1-fast",
        "kat_coder_pro": "kwaipilot/kat-coder-pro:free",
        "nemotron_nano_12b_v2_vl": "nvidia/nemotron-nano-12b-v2-vl:free",
        "longcat_flash_chat": "meituan/longcat-flash-chat:free",
        "qwen3_coder": "qwen/qwen3-coder:free",
        "kimi_k2": "moonshotai/kimi-k2:free",
        "deepseek_r1_8b": "deepseek/deepseek-r1-0528-qwen3-8b:free",
        "mistralsmall_3_24b": "mistralai/mistral-small-3.2-24b-instruct:free",
        "qwen3_4b": "qwen/qwen3-4b:free",
        "qwen3_14b": "qwen/qwen3-14b:free",
        "deepseek_r1t_chimera": "tngtech/deepseek-r1t-chimera:free",
        "llama_4_maverick": "meta-llama/llama-4-maverick",
        "gemini_2_5_flash_lite": "google/gemini-2.5-flash-lite",
        "gpt4_1_nano": "openai/gpt-4.1-nano",
        "gpt4o_mini": "openai/gpt-4o-mini",
    }

    # Default model
    DEFAULT_MODEL = SUPPORTED_MODELS["grok4.1_fast"]

    @staticmethod
    def get_model_display_names() -> dict:
        """
        Returns a dictionary of model display names (without the `:free` suffix).

        Returns:
            dict: Model display names mapped to their keys.
        """
        return {
            "grok4.1_fast": "Grok 4.1 Fast",
            "kat_coder_pro": "Kat Coder Pro",
            "nemotron_nano_12b_v2_vl": "Nemotron Nano 12B V2 VL",
            "longcat_flash_chat": "Longcat Flash Chat",
            "qwen3_coder": "Qwen 3 Coder",
            "kimi_k2": "Kimi K2",
            "deepseek_r1_8b": "Deepseek R1 8B",
            "mistralsmall_3_24b": "Mistral Small 3 24B",
            "qwen3_4b": "Qwen 3 4B",
            "qwen3_14b": "Qwen 3 14B",
            "deepseek_r1t_chimera": "Deepseek R1T Chimera",
            "llama_4_maverick": "Llama 4 Maverick",
            "gemini_2_5_flash_lite": "Gemini 2.5 Flash Lite",
            "gpt4_1_nano": "GPT 4.1 Nano",
            "gpt4o_mini": "GPT 4o Mini",
        }
