import asyncio
from os import getenv
import sys
import os

# from siga_mcp.tools import inserir_os_infraestrutura
# from siga_mcp.dynamic_constants import obter_usuarios_responsavel
from siga_mcp.tools.genericas import (
    buscar_pendencias_multiplas_matriculas,
    buscar_pendencias_lancamentos_atendimentos,
)
from siga_mcp.tools.os import (
    buscar_informacoes_os,
    buscar_todas_os_usuario,
    inserir_os_sistemas,
)
from siga_mcp.dynamic_constants import buscar_constante_siga


from dotenv import load_dotenv

# 🔑 CARREGAR .ENV AUTOMATICAMENTE
load_dotenv()

print("\n" + "=" * 70)
print("FUNÇÃO: Buscar Projetos")
print("\n" + "=" * 70)


def main():
    resultado = buscar_constante_siga(
        endpoint="https://ava3.uniube.br/ava/api/segProjetos/buscarProjetosOsSigaIA/",
        campo_chave="DESCRICAO_PROJETO",
        campo_valor="CODIGO_PROJETO",
        nome_constante="Projeto OS Sistemas",
    )
    return resultado


if __name__ == "__main__":
    resultado = main()
    print(resultado)

print("\n" + "=" * 70)
print("FUNÇÃO: Buscar Linguagens")
print("\n" + "=" * 70)


def main():
    resultado = buscar_constante_siga(
        endpoint="https://ava3.uniube.br/ava/api/seglinguagens/buscarLinguagensOsSigaIA/",
        campo_chave="DESCRICAO_LINGUAGEM",
        campo_valor="CODIGO_LINGUAGEM",
        nome_constante="Linguagens OS Sistemas",
    )
    return resultado


if __name__ == "__main__":
    resultado = main()
    print(resultado)

print("\n" + "=" * 70)
print("FUNÇÃO: Buscar Sistemas")
print("\n" + "=" * 70)


def main():
    resultado = buscar_constante_siga(
        endpoint="https://ava3.uniube.br/ava/api/segSistemas/buscarSistemasOsSigaIA/",
        campo_chave="DESCRICAO_SISTEMA",
        campo_valor="CODIGO_SISTEMA",
        nome_constante="Sistemas OS Sistemas",
    )
    return resultado


if __name__ == "__main__":
    resultado = main()
    print(resultado)

print("\n" + "=" * 70)
print("FUNÇÃO: Buscar Categorias")
print("\n" + "=" * 70)


def main():
    resultado = buscar_constante_siga(
        endpoint="https://ava3.uniube.br/ava/api/segoscategorias/buscarCategoriasOsSigaIA/",
        campo_chave="DESCRICAO_CATEGORIA",
        campo_valor="CODIGO_CATEGORIA",
        nome_constante="Categorias OS Infraestrutura",
    )
    return resultado


if __name__ == "__main__":
    resultado = main()
    print(resultado)

print("\n" + "=" * 70)
print("FUNÇÃO: Buscar Todos Tipos")
print("\n" + "=" * 70)


def main():
    resultado = buscar_constante_siga(
        endpoint="https://ava3.uniube.br/ava/api/segTiposOs/buscarTiposOsSigaIA/",
        campo_chave="DESCRICAO_TIPO",
        campo_valor="CODIGO_TIPO",
        nome_constante="Type to Number",
        params={"ativo": 1},
    )
    return resultado


if __name__ == "__main__":
    resultado = main()
    print(resultado)

print("\n" + "=" * 70)
print("FUNÇÃO: Buscar Tipo Atendimento Avulso Sistemas")
print("\n" + "=" * 70)


def main():
    resultado = buscar_constante_siga(
        endpoint="https://ava3.uniube.br/ava/api/segTiposOs/buscarTiposOsSigaIA/",
        campo_chave="DESCRICAO_TIPO",
        campo_valor="CODIGO_TIPO",
        nome_constante="Tipo Atendimento Avulso Sistemas",
        params={"tiposIncluir": [1, 10, 19]},
    )
    return resultado


if __name__ == "__main__":
    resultado = main()
    print(resultado)

print("\n" + "=" * 70)
print("FUNÇÃO: Buscar Tipo Atendimento Avulso Infraestrutura")
print("\n" + "=" * 70)


def main():
    resultado = buscar_constante_siga(
        endpoint="https://ava3.uniube.br/ava/api/segTiposOs/buscarTiposOsSigaIA/",
        campo_chave="DESCRICAO_TIPO",
        campo_valor="CODIGO_TIPO",
        nome_constante="Tipo Atendimento Avulso Infraestrutura",
        params={"classe": 2},
    )
    return resultado


if __name__ == "__main__":
    resultado = main()
    print(resultado)

print("\n" + "=" * 70)
print("FUNÇÃO: Buscar Tipo OS Sistemas")
print("\n" + "=" * 70)


def main():
    resultado = buscar_constante_siga(
        endpoint="https://ava3.uniube.br/ava/api/segTiposOs/buscarTiposOsSigaIA/",
        campo_chave="DESCRICAO_TIPO",
        campo_valor="CODIGO_TIPO",
        nome_constante="Tipo OS Sistemas",
        params={"classe": 1, "ativo": 1, "tiposExcluir": [4, 12]},
    )
    return resultado


if __name__ == "__main__":
    resultado = main()
    print(resultado)

print("\n" + "=" * 70)
print("FUNÇÃO: Buscar Origens Atendimentos Avulsos")
print("\n" + "=" * 70)


def main():
    resultado = buscar_constante_siga(
        endpoint="https://ava3.uniube.br/ava/api/segorigens/buscarOrigensSigaIA/",
        campo_chave="DESCRICAO_ORIGEM",
        campo_valor="CODIGO_ORIGEM",
        nome_constante="Origens Atendimentos Avulso",
        params={"origensExcluir": [6, 8]},
    )
    return resultado


if __name__ == "__main__":
    resultado = main()
    print(resultado)

print("\n" + "=" * 70)
print("FUNÇÃO: Buscar Origens OS")
print("\n" + "=" * 70)


def main():
    resultado = buscar_constante_siga(
        endpoint="https://ava3.uniube.br/ava/api/segorigens/buscarOrigensSigaIA/",
        campo_chave="DESCRICAO_ORIGEM",
        campo_valor="CODIGO_ORIGEM",
        nome_constante="Origens OS",
    )
    return resultado


if __name__ == "__main__":
    resultado = main()
    print(resultado)

""" async def main() -> str:
    return await buscar_todas_os_usuario(
        **{"filtrar_por": "Todas OS em Aberto", "matricula": "24290"}
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """

"""def main() -> str:
return listar_usuarios_responsaveis_os_siga(
    **{
        "area": "1",
    }
)"""


# def main() -> str:
# Testar Sistemas (área 1)
#    docstring_sistemas, ids_sistemas, erro_sistemas = obter_usuarios_responsavel(1)

# Testar Infraestrutura (área 2)
#    docstring_infra, ids_infra, erro_infra = obter_usuarios_responsavel(2)

#    return f"""
#        === SISTEMAS ===
#        {docstring_sistemas}
#        IDs: {ids_sistemas}
#        Erro: {erro_sistemas}
#        === INFRAESTRUTURA ===
#        {docstring_infra}
#        IDs: {ids_infra}
#        Erro: {erro_infra}
#        """


# if __name__ == "__main__":
#    resultado = main()
# print(resultado)


""" async def main() -> str:
    return await inserir_os_infraestrutura(
        **{
            "data_solicitacao": "03/10/2025 08:31:17",
            "assunto": "Teste de gravação Infra",
            "descricao": "Este é apenas um teste de gravação Infra",
            "matSolicitante": "24142",
            "criada_por": "24142",
            "responsavel": "24142",
            "responsavel_atual": "24142",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


""" async def main() -> str:
    return await inserir_os_sistemas(
        **{
            "assunto": "teste 1111",
            "data_solicitacao": "11/11/2025 00:00:00",
            "descricao": "testando criação de OS SIGA IA",
            "matSolicitante": "24142",
            "responsavel": "24142",
            "responsavel_atual": "24142",
            "criada_por": "24142",
            "equipe": "Equipe AVA",
            "projeto": "Operação AVA",
            "status": "Em Atendimento",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


""" async def main() -> str:
    # Teste com todos os campos necessários
    return await inserir_os_sistemas(
        data_solicitacao="11/11/2025 10:30:00",  # Com horário específico
        assunto="teste 1111",
        descricao="testando criação de OS SIGA IA",
        responsavel="24142",
        responsavel_atual="24142",
        matSolicitante="24142",
        criada_por="24142",
        # Campos com valores padrão (você pode omitir se quiser usar os defaults)
        sistema="Sistemas AVA",
        tipo="Implementação",
        equipe="Equipe AVA",
        linguagem="PHP",
        projeto="Operação AVA",
        status="Em Atendimento",
        os_interna="Sim",
        origem="Teams",
        prioridade_usuario="Nenhuma",
        criticidade="Nenhuma",
    )


if __name__ == "__main__":
    print("=== INICIANDO TESTE ===")
    print(f"API Key configurada: {'Sim' if getenv('AVA_API_KEY') else 'Não'}")

    try:
        resultado = asyncio.run(main())
        print("=== RESULTADO ===")
        print(resultado)
    except Exception as e:
        print(f"=== ERRO NO TESTE ===")
        print(f"Erro: {e}")
        import traceback

        traceback.print_exc() """


""" async def main() -> str:
    return await listar_usuarios_responsaveis_os_siga(
        **{
            "area": "2",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


""" async def main() -> str:
    return await listar_usuarios_equipe_por_gerente(
        **{
            "matricula_gerente": "8372",
            "descricao_equipe": "Equipe AVA",
            "situacao_usuario": "Ativo",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


""" async def main() -> str:
    return await listar_usuarios_equipe_por_gerente(
        **{
            "matricula_gerente": "8372",
            "descricao_equipe": "Equipe AVA",
            "situacao_usuario": "Ativo",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


""" async def main() -> str:
    return await listar_horas_trabalhadas(
        **{
            "matricula": ["24142", "14897"],
            "data_inicio": "13/10/2025",
            "data_fim": "17/10/2025",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


""" async def main() -> str:
    return await atualizar_tempo_gasto_atendimento(
        **{
            "codigo_analista": "24142",
            "data_inicio": "22/10/2025",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


""" async def main() -> str:
    return await inserir_atendimentos_os(
        **{
            "codigo_analista": 24142,
            "codigo_os": 182487,
            "data_inicio": "23/10/2025 08:02",
            "data_fim": "23/10/2025 08:12",
            "descricao_atendimento": "teste",
            "tipo": "Suporte Sistema",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


""" async def main() -> str:
    return await buscar_informacoes_os(
        **{
            "codigo_os": "182487",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


""" async def main() -> str:
    return await editar_os_sistemas(
        **{
            "codigo_os": 194987,
            "assunto": "teste",
            "criada_por": "24142",
            "data_solicitacao": "30/10/2025 15:01",
            "descricao": "testando SIGA IA",
            "matSolicitante": "24142",
            "responsavel": "24142",
            "responsavel_atual": "24142",
            "tipo": "Implementação",
            "origem": "Teams",
            "sistema": "Sistemas AVA",
            "equipe": "Equipe AVA",
            "projeto": "Operação AVA",
            "status": "Em Atendimento",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


""" # RODAR TESTES TANTO GERAL, QUANTO PARA CANCELAMENTO E CONCLUSAO.
async def main() -> str:
    return await concluir_os_siga_ia(
        **{
            "codigo_os": "195011",
            "tipo_conclusao": "Concluída",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


# TESTE: Buscar pendências de múltiplas matrículas concorrentemente
# EFETUA OS TESTES NA SEGUNDA PARA VER SE ESTÁ FUNCIONANDO. ELA IRÁ CONSUMIR A FUNÇÃO ORIGINAL
""" async def main() -> str:
    return await buscar_pendencias_multiplas_matriculas(
        **{
            "matriculas": [
                16500,
                24290,
                25962,
                27342,
                20634,
                23767,
                24056,
                28560,
                23724,
                29306,
                14897,
                24142,
                26302,
                29229,
                25818,
            ],  # Lista de matrículas para testar
            "dataIni": "03/11/2025",
            "dataFim": "07/11/2025",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


# TESTE: Buscar pendências de múltiplas matrículas concorrentemente
# EFETUA OS TESTES NA SEGUNDA PARA VER SE ESTÁ FUNCIONANDO. ELA IRÁ CONSUMIR A FUNÇÃO ORIGINAL
""" async def main() -> str:
    return await buscar_pendencias_lancamentos_atendimentos(
        **{
            "matricula": 16500,
            "dataIni": "03/11/2025",
            "dataFim": "07/11/2025",
        }
    )


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(resultado) """


# testando o que está chegando no prompt, para substituir as variáveis que estão entre {}, como por exemplo as constantes.
""" def test_debug_prompt_compilation():
    #Testa a compilação do prompt com constantes

    # Adicionar o caminho correto para import
    projeto_root = os.path.dirname(os.path.dirname(__file__))  # Volta para SIGA_MCP
    siga_mcp_path = os.path.join(projeto_root, "siga_mcp")
    sys.path.append(siga_mcp_path)

    try:
        # Agora deve funcionar
        from siga_mcp.dynamic_constants import constantes_md, SYSTEM_INSTRUCTIONS

        print("Import funcionou!")

        # Salvar constantes
        with open("debug_constantes.txt", "w", encoding="utf-8") as f:
            f.write("=== CONSTANTES MARKDOWN ===\n")
            f.write(constantes_md)
            f.write("\n========================")

        # Salvar prompt compilado
        with open("debug_prompt_compilado.txt", "w", encoding="utf-8") as f:
            f.write("=== PROMPT COMPILADO ===\n")
            f.write(str(SYSTEM_INSTRUCTIONS))
            f.write("\n========================")

        print("Arquivos de debug salvos na pasta tests:")
        print("  - debug_constantes.txt")
        print("  - debug_prompt_compilado.txt")

    except ImportError as e:
        print(f"Erro de import: {e}")
        print(f"Tentando importar de: {siga_mcp_path}")

    except Exception as e:
        print(f"Outro erro: {e}")


if __name__ == "__main__":
    test_debug_prompt_compilation() """
