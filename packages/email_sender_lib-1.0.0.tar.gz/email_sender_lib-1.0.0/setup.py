from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="email-sender-lib",
    version="1.0.0",
    author="Ahmed Osama",
    author_email="ahmed.osama@intcore.com",
    description="A flexible HTML email notification library for SMTP servers",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/email-sender-lib",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Communications :: Email",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    keywords="email smtp notification html gmail",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/email-sender-lib/issues",
        "Source": "https://github.com/yourusername/email-sender-lib",
    },
)
