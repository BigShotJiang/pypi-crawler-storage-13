

shutdown -h   