# wedata-automl

AutoML SDK for Tencent Cloud WeData, powered by FLAML and integrated with MLflow for experiment tracking and model registry.

## Features
- FLAML-based AutoML with graceful fallback to RandomForest
- MLflow integration: experiment tracking, model logging, and Model Registry registration
- Quiet, production-friendly logging helpers
- Simple pipeline API and CLI demo

## Installation

```bash
pip install wedata-automl
# Optional extras
pip install "wedata-automl[xgboost]"
pip install "wedata-automl[lightgbm]"
```

## Quickstart (Python API)

```python
from wedata_automl import run_pipeline

# Uses a demo dataset by default, and creates/uses the specified MLflow experiment
result = run_pipeline(experiment_name="blueszzhang-test-automl")
print(result)
```

## Quickstart (CLI)

```bash
wedata-automl-demo
```

## Documentation

- [故障排除指南](docs/TROUBLESHOOTING.md) - 常见问题和解决方案
- [MLflow 版本兼容性](docs/MLFLOW_VERSION_COMPATIBILITY.md) - MLflow 版本要求和兼容性
- [项目 ID 配置](docs/PROJECT_ID_CONFIGURATION.md) - 项目 ID 配置说明

## Notes
- Ensure MLflow Tracking/Registry is configured in your environment (MLFLOW_TRACKING_URI, credentials, etc.)
- XGBoost/LightGBM are optional; install via extras if you want those estimators considered
- Python >= 3.8
- **Project ID is required** - Set via `project_id` parameter or `WEDATA_PROJECT_ID` environment variable

## Troubleshooting

遇到问题？查看 [故障排除指南](docs/TROUBLESHOOTING.md)。

常见问题：
- [MLflow 实验创建失败](docs/TROUBLESHOOTING.md#mlflow-实验创建失败)
- [MLflow 版本兼容性问题](docs/TROUBLESHOOTING.md#mlflow-版本兼容性问题)
- [项目 ID 相关问题](docs/TROUBLESHOOTING.md#项目-id-相关问题)

## License
MIT
