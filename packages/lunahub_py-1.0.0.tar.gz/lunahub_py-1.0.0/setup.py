from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="lunahub-py",
    version="1.0.0",
    author="Nott Achawin",
    author_email="miamicity046@gmail.com",
    description="🌙 Luna-Py - Ultimate All-in-One Python Library for Discord Bots",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ThomasDevMIAMICITY/luna-py",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "discord.py>=2.3.0",
        "requests>=2.31.0",
        "aiohttp>=3.9.0",
    ],
    keywords=[
        "discord",
        "discord-bot",
        "discord.py",
        "webhook",
        "http-client",
        "truewallet",
        "utilities",
        "python-library"
    ],
    project_urls={
        "Bug Reports": "https://github.com/ThomasDevMIAMICITY/luna-py/issues",
        "Source": "https://github.com/ThomasDevMIAMICITY/luna-py",
        "Documentation": "https://github.com/ThomasDevMIAMICITY/luna-py#readme",
    },
)
