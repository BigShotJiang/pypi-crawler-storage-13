# 🌙 Luna-Py - Ultimate All-in-One Python Library

![PyPI version](https://img.shields.io/badge/pypi-v1.0.0-blue)
![Python version](https://img.shields.io/badge/python-3.8+-brightgreen)
![License](https://img.shields.io/badge/license-MIT-green)
![Discord.py](https://img.shields.io/badge/discord.py-2.3+-7289DA)

**Luna-Py** is the ultimate all-in-one Python library for Discord bots! Easy Discord bot creation, webhooks, HTTP client, TrueWallet API, and utilities - all in one package! 🐍🚀

## ✨ Features

- 🤖 **Discord Bot** - Easy bot creation with discord.py
- 📨 **Discord Webhooks** - Simple webhook management
- 🎨 **Embeds & Buttons** - Beautiful message components
- 🌐 **HTTP Client** - Powerful HTTP requests with auto-retry
- 💰 **TrueWallet API** - Voucher redemption
- 🛠️ **Utilities** - Useful helper functions
- 🔐 **Crypto** - Encoding and token generation

## 📦 Installation

```bash
pip install luna-py
```

**Requirements:**
- Python 3.8+
- discord.py 2.3+

## 🚀 Quick Start

### Basic Discord Bot

```python
import luna

# Create bot
bot = luna.LunaBot.create_bot(command_prefix="!")

@bot.command()
async def ping(ctx):
    await ctx.reply("🏓 Pong!")

@bot.command()
async def hello(ctx):
    await bot.luna_reply_embed(
        ctx,
        title="👋 Hello!",
        description=f"Hi {ctx.author.mention}!",
        color=luna.LunaEmbed.BLUE
    )

bot.run("YOUR_BOT_TOKEN")
```

### Bot with Embed

```python
import luna

bot = luna.LunaBot.create_bot()

@bot.command()
async def info(ctx):
    embed = luna.LunaEmbed.create(
        title="📊 Server Info",
        description="Information about this server",
        color=luna.LunaEmbed.DISCORD,
        fields=[
            {"name": "👥 Members", "value": str(ctx.guild.member_count), "inline": True},
            {"name": "📅 Created", "value": ctx.guild.created_at.strftime("%Y-%m-%d"), "inline": True}
        ],
        thumbnail=str(ctx.guild.icon.url) if ctx.guild.icon else None,
        footer="Powered by Luna-Py",
        timestamp=True
    )
    await ctx.reply(embed=embed)

bot.run("YOUR_BOT_TOKEN")
```

### Bot with Buttons

```python
import luna
import discord

bot = luna.LunaBot.create_bot()

@bot.command()
async def menu(ctx):
    embed = luna.LunaEmbed.create(
        title="🎮 Game Menu",
        description="Choose an option:",
        color=luna.LunaEmbed.BLUE
    )
    
    # Create buttons
    button1 = luna.LunaButton.create(
        label="Play Game",
        custom_id="play",
        style=discord.ButtonStyle.success,
        emoji="🎮"
    )
    
    button2 = luna.LunaButton.create(
        label="Rules",
        custom_id="rules",
        style=discord.ButtonStyle.primary,
        emoji="📜"
    )
    
    # Create view with buttons
    view = luna.LunaView(button1, button2)
    
    await ctx.reply(embed=embed, view=view)

# Handle button clicks
@bot.event
async def on_interaction(interaction):
    if interaction.type == discord.InteractionType.component:
        if interaction.data['custom_id'] == 'play':
            await interaction.response.send_message("🎮 Starting game...")
        elif interaction.data['custom_id'] == 'rules':
            await interaction.response.send_message("📜 Here are the rules...")

bot.run("YOUR_BOT_TOKEN")
```

---

## 📖 Complete Examples

### Welcome Bot

```python
import luna

bot = luna.LunaBot.create_bot()

@bot.event
async def on_member_join(member):
    channel = discord.utils.get(member.guild.channels, name="welcome")
    if not channel:
        return
    
    embed = luna.LunaEmbed.create(
        title="👋 Welcome!",
        description=f"Welcome to the server, {member.mention}!",
        color=luna.LunaEmbed.GREEN,
        thumbnail=str(member.avatar.url) if member.avatar else None,
        fields=[
            {"name": "📊 Member Count", "value": str(member.guild.member_count), "inline": True},
            {"name": "📅 Account Created", "value": member.created_at.strftime("%Y-%m-%d"), "inline": True}
        ],
        footer="Enjoy your stay!",
        timestamp=True
    )
    
    await channel.send(embed=embed)

@bot.event
async def on_ready():
    print(f"✅ {bot.user} is ready!")

bot.run("YOUR_BOT_TOKEN")
```

### TrueWallet Bot

```python
import luna

bot = luna.LunaBot.create_bot()

@bot.command()
async def redeem(ctx, voucher_link: str, phone: str):
    """Redeem TrueWallet voucher"""
    await ctx.reply("⏳ Redeeming voucher...")
    
    result = luna.LunaTrueWallet.redeem_voucher(voucher_link, phone)
    
    if result.get("status", {}).get("code") == "SUCCESS":
        embed = luna.LunaEmbed.create(
            title="✅ Voucher Redeemed!",
            description=result["status"]["message"],
            color=luna.LunaEmbed.SUCCESS,
            fields=[
                {"name": "💰 Amount", "value": f"{result['data']['amount']} THB", "inline": True},
                {"name": "📱 Phone", "value": phone, "inline": True}
            ],
            timestamp=True
        )
    else:
        embed = luna.LunaEmbed.create(
            title="❌ Redeem Failed",
            description=result.get("status", {}).get("message", "Unknown error"),
            color=luna.LunaEmbed.ERROR,
            timestamp=True
        )
    
    await ctx.reply(embed=embed)

bot.run("YOUR_BOT_TOKEN")
```

### Shop Bot

```python
import luna
import discord

bot = luna.LunaBot.create_bot()

# Product catalog
products = [
    {"id": "prod1", "name": "🎮 Robux 100", "price": 50},
    {"id": "prod2", "name": "💎 Diamonds 500", "price": 100},
    {"id": "prod3", "name": "⭐ Premium", "price": 150},
]

@bot.command()
async def shop(ctx):
    """Display shop"""
    fields = [
        {"name": p["name"], "value": f"Price: {p['price']} THB", "inline": True}
        for p in products
    ]
    
    embed = luna.LunaEmbed.create(
        title="🛍️ Shop",
        description="Choose a product to buy:",
        color=luna.LunaEmbed.BLUE,
        fields=fields
    )
    
    # Create buy buttons
    buttons = [
        luna.LunaButton.create(
            label=p["name"],
            custom_id=f"buy_{p['id']}",
            style=discord.ButtonStyle.success
        )
        for p in products
    ]
    
    view = luna.LunaView(*buttons)
    await ctx.reply(embed=embed, view=view)

@bot.event
async def on_interaction(interaction):
    if interaction.type == discord.InteractionType.component:
        custom_id = interaction.data['custom_id']
        
        if custom_id.startswith('buy_'):
            product_id = custom_id.replace('buy_', '')
            product = next((p for p in products if p['id'] == product_id), None)
            
            if product:
                embed = luna.LunaEmbed.create(
                    title="✅ Purchase Successful!",
                    description=f"You bought: {product['name']}",
                    color=luna.LunaEmbed.SUCCESS,
                    fields=[
                        {"name": "💰 Price", "value": f"{product['price']} THB"}
                    ]
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)

bot.run("YOUR_BOT_TOKEN")
```

---

## 🎨 Discord Embeds

### Create Embeds

```python
import luna

embed = luna.LunaEmbed.create(
    title="🎉 Announcement",
    description="This is an important announcement!",
    color=luna.LunaEmbed.DISCORD,
    url="https://example.com",
    author={"name": "Admin Team", "icon_url": "https://example.com/icon.png"},
    fields=[
        {"name": "Category", "value": "Updates", "inline": True},
        {"name": "Priority", "value": "High", "inline": True}
    ],
    thumbnail="https://example.com/thumb.png",
    image="https://example.com/image.png",
    footer="Announcement System",
    timestamp=True
)

# Send embed
await channel.send(embed=embed)
```

### Available Colors

```python
luna.LunaEmbed.RED        # 0xFF0000
luna.LunaEmbed.GREEN      # 0x00FF00
luna.LunaEmbed.BLUE       # 0x0000FF
luna.LunaEmbed.YELLOW     # 0xFFFF00
luna.LunaEmbed.PURPLE     # 0x800080
luna.LunaEmbed.ORANGE     # 0xFFA500
luna.LunaEmbed.DISCORD    # 0x5865F2
luna.LunaEmbed.SUCCESS    # 0x00FF00
luna.LunaEmbed.ERROR      # 0xFF0000
luna.LunaEmbed.WARNING    # 0xFFFF00
luna.LunaEmbed.INFO       # 0x0099FF
```

---

## 📨 Discord Webhooks

```python
import luna

# Send simple message
luna.LunaWebhook.send(
    webhook_url="YOUR_WEBHOOK_URL",
    content="Hello from Luna-Py! 🐍",
    username="My Bot",
    avatar_url="https://example.com/avatar.png"
)

# Send embed
embed = luna.LunaEmbed.create(
    title="Webhook Message",
    description="Sent via webhook!",
    color=luna.LunaEmbed.BLUE
)

luna.LunaWebhook.send_embed(
    webhook_url="YOUR_WEBHOOK_URL",
    embed=embed
)
```

---

## 🌐 HTTP Client

```python
import luna

# Create HTTP client
http = luna.LunaHTTP(timeout=30, max_retries=3)

# GET request
response = http.get("https://api.example.com/data")
print(response.json())

# POST request
response = http.post(
    "https://api.example.com/users",
    json={"name": "John", "email": "john@example.com"}
)
```

---

## 💰 TrueWallet API

```python
import luna

result = luna.LunaTrueWallet.redeem_voucher(
    voucher_link="https://gift.truemoney.com/campaign/?v=xxxxx",
    phone_number="0812345678"
)

if result.get("status", {}).get("code") == "SUCCESS":
    print(f"✅ Received {result['data']['amount']} THB")
else:
    print(f"❌ Error: {result.get('status', {}).get('message')}")
```

---

## 🛠️ Utilities

```python
import luna

# Sleep
luna.LunaUtils.sleep(1)  # Sleep 1 second

# Async sleep
await luna.LunaUtils.async_sleep(1)

# Random
num = luna.LunaUtils.random(1, 100)  # Random number 1-100
text = luna.LunaUtils.random_string(16)  # Random string

# Format
formatted = luna.LunaUtils.format_number(1234567)  # "1,234,567"
date = luna.LunaUtils.format_date()  # "2024-11-23 14:30:00"

# List operations
chunks = luna.LunaUtils.chunk_list([1,2,3,4,5,6], 2)  # [[1,2], [3,4], [5,6]]

# Timestamp
ts = luna.LunaUtils.timestamp()  # Unix timestamp
```

---

## 🔐 Crypto

```python
import luna

# Base64 encoding
encoded = luna.LunaCrypto.base64_encode("Hello World")
decoded = luna.LunaCrypto.base64_decode(encoded)

# Generate token
token = luna.LunaCrypto.generate_token(32)  # 64-char hex token
```

---

## 📋 API Reference

### Discord Bot
- `LunaBot.create_bot(command_prefix, intents)` - Create bot
- `LunaBot.create_client(intents)` - Create client
- `LunaEmbed.create(**kwargs)` - Create embed
- `LunaButton.create(**kwargs)` - Create button
- `LunaView(*buttons, timeout)` - Create view

### Webhooks
- `LunaWebhook.send(webhook_url, **kwargs)` - Send message
- `LunaWebhook.send_embed(webhook_url, embed, **kwargs)` - Send embed

### HTTP
- `LunaHTTP(timeout, max_retries)` - Create client
- `http.get(url, **kwargs)` - GET request
- `http.post(url, **kwargs)` - POST request
- `http.put(url, **kwargs)` - PUT request
- `http.delete(url, **kwargs)` - DELETE request

### TrueWallet
- `LunaTrueWallet.redeem_voucher(link, phone)` - Redeem voucher

### Utils
- `LunaUtils.sleep(seconds)` - Sleep
- `LunaUtils.async_sleep(seconds)` - Async sleep
- `LunaUtils.random(min, max)` - Random number
- `LunaUtils.random_string(length)` - Random string
- `LunaUtils.format_number(num)` - Format number
- `LunaUtils.chunk_list(lst, size)` - Chunk list
- `LunaUtils.timestamp()` - Unix timestamp
- `LunaUtils.format_date(dt, format)` - Format date

### Crypto
- `LunaCrypto.base64_encode(text)` - Encode base64
- `LunaCrypto.base64_decode(encoded)` - Decode base64
- `LunaCrypto.generate_token(length)` - Generate token

---

## 💡 Getting Your Bot Token

1. Go to https://discord.com/developers/applications
2. Create "New Application"
3. Go to "Bot" section
4. Click "Reset Token" and copy it
5. Enable necessary intents
6. Invite bot to your server

---

## 📦 Dependencies

- discord.py >= 2.3.0
- requests >= 2.31.0
- aiohttp >= 3.9.0

---

## 🤝 Contributing

Contributions welcome! Open issues or PRs on GitHub.

---

## 📄 License

MIT © Luna-Py Team

---

## 🔗 Links

- **PyPI**: https://pypi.org/project/luna-py/
- **JavaScript Version**: https://www.npmjs.com/package/lunahub

---

**Made with 🌙 by Luna Team**
