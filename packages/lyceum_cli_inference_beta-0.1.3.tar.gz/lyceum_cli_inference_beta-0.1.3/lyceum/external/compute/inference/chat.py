"""Inference commands for AI models"""

import json
from typing import Optional, Callable

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ....shared.config import config
from ...utils import (
    get_model_info, check_model_supports_input,
    build_sync_input, handle_inference_response
)
from ...utils.input_parsing import parse_image_inputs, parse_jsonl_file
from ...utils.models import URLInput, Base64Input, SyncRequest

console = Console()
infer_app = typer.Typer(name="infer", help="Inference commands")

# Lookup tables
HTTP_STATUS_HANDLERS = {
    200: lambda result, model: _handle_success(result),
    503: lambda result, model: _handle_model_unavailable(model),
}

MODEL_TYPE_LABELS = {
    'text': 'Text',
    'image': 'Image',
    'audio': 'Audio',
    'multimodal': 'Multi',
    'embedding': 'Embed'
}

SSE_EVENT_HANDLERS = {
    "queued": lambda payload: console.print(f"[dim]Status: queued[/dim]"),
    "in_progress": lambda payload: console.print(f"[dim]Status: in_progress[/dim]"),
    "finished": lambda payload: _handle_finished_event(payload),
    "failed": lambda payload: _handle_failed_event(payload),
}

IMAGE_INPUT_HANDLERS = {
    URLInput: lambda inp, input_data: _add_url_input(inp, input_data),
    Base64Input: lambda inp, input_data: _add_base64_input(inp, input_data),
}

BATCH_INPUT_HANDLERS = {
    URLInput: lambda inp: {"type": "url", "url": inp.url},
    Base64Input: lambda inp: {"type": "base64", "data": inp.data},
}


def _handle_success(result: dict) -> None:
    """Handle successful HTTP 200 response"""
    inference_id = result.get("id", "unknown")
    console.print(f"[green][SUCCESS] Job queued[/green]")
    console.print(f"[cyan]Inference ID: {inference_id}[/cyan]")
    console.print(f"[dim]Poll status: {config.base_url}/api/v2/external/sync/{inference_id}[/dim]")
    console.print(f"[dim]Results will be uploaded to your S3 bucket![/dim]")


def _handle_model_unavailable(model: str) -> None:
    """Handle HTTP 503 - model unavailable"""
    console.print(f"[red][ERROR] Model {model} is not running. Please contact support to start the model.[/red]")
    raise typer.Exit(1)


def _handle_http_error(status_code: int, response_text: str) -> None:
    """Handle HTTP error responses"""
    console.print(f"[red][ERROR] Error: HTTP {status_code}[/red]")
    console.print(f"[red]{response_text}[/red]")
    raise typer.Exit(1)


def _handle_finished_event(payload: dict) -> bool:
    """Handle SSE finished event - returns True to break loop"""
    output = payload.get("output", {})
    console.print(f"[green]✓ Completed[/green]")
    if isinstance(output, dict) and "text" in output:
        console.print(f"[cyan]{output['text']}[/cyan]")
    elif isinstance(output, str):
        console.print(f"[cyan]{output}[/cyan]")
    return True


def _handle_failed_event(payload: dict) -> bool:
    """Handle SSE failed event - returns True to break loop"""
    error = payload.get("error", "Unknown error")
    console.print(f"[red]✗ Failed: {error}[/red]")
    return True


def _add_url_input(inp: URLInput, input_data: dict) -> None:
    """Add URL input to input_data dict"""
    input_data["image_url"] = inp.url
    input_data["url"] = inp.url


def _add_base64_input(inp: Base64Input, input_data: dict) -> None:
    """Add base64 input to input_data dict"""
    input_data["image_data"] = inp.data


def _process_http_response(response: httpx.Response, model: str, custom_200_handler: Optional[Callable] = None) -> None:
    """Process HTTP response using lookup table"""
    if response.status_code == 200:
        if custom_200_handler:
            result = response.json()
            custom_200_handler(result)
        else:
            handler = HTTP_STATUS_HANDLERS.get(200)
            if handler:
                result = response.json()
                handler(result, model)
    else:
        handler = HTTP_STATUS_HANDLERS.get(response.status_code)
        if handler:
            handler({}, model)
        else:
            _handle_http_error(response.status_code, response.text)


def _process_sse_event(event_type: str, payload: dict) -> bool:
    """Process SSE event using lookup table - returns True to break loop"""
    handler = SSE_EVENT_HANDLERS.get(event_type)
    if handler:
        return handler(payload)
    return False


def _add_image_input_to_data(image_inputs: list, input_data: dict) -> None:
    """Add image input to input_data using lookup table"""
    if not image_inputs:
        return
    img_inp = image_inputs[0]
    handler = IMAGE_INPUT_HANDLERS.get(type(img_inp))
    if handler:
        handler(img_inp, input_data)


def _convert_to_batch_inputs(inputs: list) -> list[dict]:
    """Convert inputs to batch format using lookup table"""
    batch_inputs = []
    for inp in inputs:
        handler = BATCH_INPUT_HANDLERS.get(type(inp))
        if handler:
            batch_inputs.append(handler(inp))
    return batch_inputs


@infer_app.command("stream")
def stream_inference(
    message: Optional[str] = typer.Argument(None, help="Text message (optional if using --file)"),
    model: str = typer.Option("gpt-4", "--model", "-m", help="Model to use for inference"),
    file: Optional[str] = typer.Option(None, "--file", "--jsonl", help="JSONL file with multiple requests"),
    image_url: Optional[str] = typer.Option(None, "--image-url", help="Image URL for multimodal models"),
    image_dir: Optional[str] = typer.Option(None, "--image-dir", help="Directory of images"),
    image_base64: Optional[str] = typer.Option(None, "--image-base64", help="Base64-encoded image"),
    image: Optional[str] = typer.Option(None, "--image", help="Image file path"),
):
    """Stream inference with real-time updates via SSE"""
    try:
        config.get_client()

        if file:
            try:
                requests = parse_jsonl_file(file)
                console.print(f"[dim][PROCESSING] Streaming {len(requests)} requests from JSONL file...[/dim]")

                url = f"{config.base_url}/api/v2/external/inference/streaming/start"
                headers = {"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"}

                with httpx.Client(timeout=None) as http_client:
                    for idx, req in enumerate(requests, 1):
                        console.print(f"\n[cyan][Request {idx}/{len(requests)}][/cyan]")

                        start_response = http_client.post(url, json={
                            "model_id": req.get("model_id", model),
                            "input": req.get("input", {})
                        }, headers=headers)

                        if start_response.status_code != 200:
                            console.print(f"[red]✗ Failed to start: HTTP {start_response.status_code}[/red]")
                            continue

                        result = start_response.json()
                        inference_id = result.get("inference_id")
                        stream_url = result.get("streaming_url")

                        if not stream_url:
                            console.print(f"[red]✗ No streaming URL returned[/red]")
                            continue

                        console.print(f"[dim]Streaming inference {inference_id}...[/dim]")

                        with http_client.stream("GET", stream_url, headers={**headers, "Accept": "text/event-stream"}) as stream:
                            event_type = None
                            for line in stream.iter_lines():
                                if line.startswith("event:"):
                                    event_type = line[6:].strip()
                                elif line.startswith("data:") and event_type:
                                    data = json.loads(line[5:].strip())
                                    payload = data.get("payload", {})
                                    if _process_sse_event(event_type, payload):
                                        break
                return
            except ValueError as e:
                console.print(f"[red][ERROR] {e}[/red]")
                raise typer.Exit(1)

        if not message:
            console.print("[red][ERROR] Either provide a message or use --file for JSONL input[/red]")
            raise typer.Exit(1)

        input_data = {"text": message}

        if image_url or image_dir or image_base64 or image:
            image_inputs = parse_image_inputs(
                urls=image_url,
                dir=image_dir,
                base64_data=image_base64,
                file_path=image
            )
            _add_image_input_to_data(image_inputs, input_data)

        url = f"{config.base_url}/api/v2/external/inference/streaming/start"
        headers = {"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"}

        with httpx.Client() as http_client:
            start_response = http_client.post(url, json={
                "model_id": model,
                "input": input_data
            }, headers=headers, timeout=30.0)

            if start_response.status_code != 200:
                _handle_http_error(start_response.status_code, start_response.text)

            result = start_response.json()
            inference_id = result.get("inference_id")
            stream_url = result.get("streaming_url")

            if not stream_url:
                console.print(f"[red][ERROR] No streaming URL returned[/red]")
                raise typer.Exit(1)

            console.print(f"[dim]Streaming inference {inference_id}...[/dim]")

            with http_client.stream("GET", stream_url, headers={**headers, "Accept": "text/event-stream"}, timeout=None) as stream:
                event_type = None
                for line in stream.iter_lines():
                    if line.startswith("event:"):
                        event_type = line[6:].strip()
                    elif line.startswith("data:") and event_type:
                        data = json.loads(line[5:].strip())
                        payload = data.get("payload", {})
                        if _process_sse_event(event_type, payload):
                            break

    except Exception as e:
        console.print(f"[red][ERROR] Error: {e}[/red]")
        raise typer.Exit(1)


@infer_app.command("chat")
def chat_inference(
    text: str = typer.Argument(..., help="Text prompt/message"),
    model: str = typer.Option("gpt-4", "--model", "-m", help="Model to use for inference"),
    image_url: Optional[str] = typer.Option(None, "--image-url", help="Image URL for multimodal models"),
    image_dir: Optional[str] = typer.Option(None, "--image-dir", help="Directory of images"),
    image_base64: Optional[str] = typer.Option(None, "--image-base64", help="Base64-encoded image"),
    image: Optional[str] = typer.Option(None, "--image", help="Image file path"),
    max_tokens: int = typer.Option(1000, "--max-tokens", help="Maximum tokens in response"),
    temperature: float = typer.Option(0.7, "--temperature", "-t", help="Temperature (0.0-2.0)"),
):
    """Send text prompt (optionally with images for multimodal models)"""
    try:
        config.get_client()

        # Validate max_tokens against model capabilities
        model_info = get_model_info(model)
        if model_info:
            max_output_tokens = model_info.get("max_output_tokens")
            max_input_tokens = model_info.get("max_input_tokens", 4096)
            if max_output_tokens and max_tokens > max_output_tokens:
                console.print(f"[yellow][WARNING] Requested max_tokens ({max_tokens}) exceeds model's max_output_tokens ({max_output_tokens}). Capping to {max_output_tokens}.[/yellow]")
                max_tokens = max_output_tokens
            # Also check against total context (input + output)
            # Estimate input tokens (rough: ~4 chars per token for English)
            estimated_input_tokens = len(text) // 4
            if image_url or image_dir or image_base64 or image:
                # Images add significant tokens, use conservative estimate
                estimated_input_tokens += 500
            total_context = max_input_tokens if max_input_tokens else 4096
            available_output = total_context - estimated_input_tokens - 100  # 100 token safety margin
            if max_tokens > available_output:
                console.print(f"[yellow][WARNING] Requested max_tokens ({max_tokens}) may exceed available context. Capping to {available_output}.[/yellow]")
                max_tokens = min(max_tokens, available_output)

        input_data = {"text": text}

        if image_url or image_dir or image_base64 or image:
            image_inputs = parse_image_inputs(
                urls=image_url,
                dir=image_dir,
                base64_data=image_base64,
                file_path=image
            )
            _add_image_input_to_data(image_inputs, input_data)

        sync_request = SyncRequest(
            model_id=model,
            input=input_data,
            max_tokens=max_tokens,
            temperature=temperature,
            stream=True,
            raw_output=False
        )

        url = f"{config.base_url}/api/v2/external/sync/"
        headers = {"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"}

        with httpx.Client(timeout=None) as http_client:
            response = http_client.post(url, json=sync_request.to_dict(), headers=headers)
            _process_http_response(response, model, custom_200_handler=lambda r: handle_inference_response(r, raw_output=False))

    except Exception as e:
        console.print(f"[red][ERROR] Error: {e}[/red]")
        raise typer.Exit(1)


@infer_app.command("image")
def image_inference(
    file_path: Optional[str] = typer.Argument(None, help="Image/PDF file path or URL"),
    model: str = typer.Option("paddle-ocr-vl", "--model", "-m", help="Model to use"),
    prompt: Optional[str] = typer.Option(None, "--prompt", "-p", help="Text prompt for multimodal models"),
    url: Optional[str] = typer.Option(None, "--url", "-u", help="Comma-separated image/PDF URLs"),
    dir: Optional[str] = typer.Option(None, "--dir", "-d", help="Directory containing images/PDFs"),
    base64: Optional[str] = typer.Option(None, "--base64", help="Base64-encoded image or file path containing base64"),
    file: Optional[str] = typer.Option(None, "--file", "--jsonl", help="JSONL file with multiple requests"),
    raw_output: bool = typer.Option(False, "--raw", help="Return full model response"),
):
    """Analyze image(s) or PDF(s) with AI models - non-blocking send-and-forget"""
    try:
        config.get_client()

        # Handle JSONL file
        if file:
            try:
                requests = parse_jsonl_file(file)
                console.print(f"[dim][PROCESSING] Sending {len(requests)} image requests from JSONL file...[/dim]")

                url = f"{config.base_url}/api/v2/external/sync/"
                headers = {"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"}
                inference_ids = []

                with httpx.Client() as http_client:
                    for req in requests:
                        sync_request = {
                            "model_id": req.get("model_id", model),
                            "input": req.get("input", {}),
                            "stream": False
                        }

                        response = http_client.post(url, json=sync_request, headers=headers, timeout=60.0)

                        if response.status_code == 200:
                            result = response.json()
                            inference_ids.append(result.get("id", "unknown"))
                            console.print(f"[green]✓[/green] Request queued: {result.get('id', 'unknown')}")
                        else:
                            console.print(f"[red]✗[/red] Request failed: HTTP {response.status_code}")

                console.print(f"\n[green][SUCCESS] {len(inference_ids)}/{len(requests)} requests queued[/green]")
                console.print(f"[dim]Results will be uploaded to your S3 bucket![/dim]")
                for inf_id in inference_ids:
                    console.print(f"[dim]  Poll status: {config.base_url}/api/v2/external/sync/{inf_id}[/dim]")
                return
            except ValueError as e:
                console.print(f"[red][ERROR] {e}[/red]")
                raise typer.Exit(1)

        model_info = get_model_info(model)
        supports_image = check_model_supports_input(model_info, "image")
        supports_text = check_model_supports_input(model_info, "text")

        inputs = parse_image_inputs(
            urls=url,
            dir=dir,
            base64_data=base64,
            file_path=file_path
        )

        if not inputs:
            console.print("[red][ERROR] No input specified. Provide --url, --dir, --base64, --file, or file path[/red]")
            raise typer.Exit(1)

        if len(inputs) == 1:
            # Single request - use /sync endpoint with stream: False
            inp = inputs[0]
            input_data = build_sync_input(inp, supports_image)
            if prompt and supports_text:
                input_data["text"] = prompt

            # For image-only requests, don't set max_tokens (let model use default)
            # Only set max_tokens if there's a text prompt
            sync_request = SyncRequest(
                model_id=model,
                input=input_data,
                max_tokens=None if not prompt else 1000,  # Image-only: None, with prompt: default 1000
                stream=False,
                raw_output=raw_output
            )

            url = f"{config.base_url}/api/v2/external/sync/"
            headers = {"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"}

            with httpx.Client() as http_client:
                response = http_client.post(url, json=sync_request.to_dict(), headers=headers, timeout=60.0)

                if response.status_code == 200:
                    result = response.json()
                    inference_id = result.get("id", "unknown")

                    console.print(f"[green][SUCCESS] Job queued[/green]")
                    console.print(f"[cyan]Inference ID: {inference_id}[/cyan]")
                    console.print(f"[dim]Poll status: {config.base_url}/api/v2/external/sync/{inference_id}[/dim]")
                    console.print(f"[dim]Results will be uploaded to your S3 bucket![/dim]")
                else:
                    _process_http_response(response, model)
        else:
            # Multiple inputs - send each individually as send-and-forget
            console.print(f"[dim][PROCESSING] Sending {len(inputs)} requests...[/dim]")

            url = f"{config.base_url}/api/v2/external/sync/"
            headers = {"Authorization": f"Bearer {config.api_key}", "Content-Type": "application/json"}
            inference_ids = []

            with httpx.Client() as http_client:
                for inp in inputs:
                    input_data = build_sync_input(inp, supports_image)
                    if prompt and supports_text:
                        input_data["text"] = prompt

                    # For image-only requests, don't set max_tokens (let model use default)
                    # Only set max_tokens if there's a text prompt
                    sync_request = SyncRequest(
                        model_id=model,
                        input=input_data,
                        max_tokens=None if not prompt else 1000,  # Image-only: None, with prompt: default 1000
                        stream=False,
                        raw_output=raw_output
                    )

                    response = http_client.post(url, json=sync_request.to_dict(), headers=headers, timeout=60.0)

                    if response.status_code == 200:
                        result = response.json()
                        inference_id = result.get("id", "unknown")
                        inference_ids.append(inference_id)
                        console.print(f"[green]✓[/green] Request queued: {inference_id}")
                    else:
                        console.print(f"[red]✗[/red] Request failed: HTTP {response.status_code}")

            console.print(f"\n[green][SUCCESS] {len(inference_ids)}/{len(inputs)} requests queued[/green]")
            console.print(f"[dim]Results will be uploaded to your S3 bucket![/dim]")
            for inf_id in inference_ids:
                console.print(f"[dim]  Poll status: {config.base_url}/api/v2/external/sync/{inf_id}[/dim]")

    except Exception as e:
        console.print(f"[red][ERROR] Error: {e}[/red]")
        raise typer.Exit(1)


@infer_app.command("models")
def list_models(
    model_type: str | None = typer.Option(
        None, "--type", "-t", help="Filter by model type (text, image, multimodal, etc.)"
    ),
    available_only: bool = typer.Option(
        False, "--available", "-a", help="Show only available models"
    ),
    sync_only: bool = typer.Option(
        False, "--sync", help="Show only models that support synchronous inference"
    ),
    async_only: bool = typer.Option(
        False, "--async", help="Show only models that support async/batch inference"
    ),
):
    """List all available AI models"""
    try:
        config.get_client()

        # Determine the endpoint based on filters
        if sync_only:
            endpoint = "/api/v2/external/models/sync"
        elif async_only:
            endpoint = "/api/v2/external/models/async"
        elif model_type:
            endpoint = f"/api/v2/external/models/type/{model_type}"
        else:
            endpoint = "/api/v2/external/models/"

        url = f"{config.base_url}{endpoint}"
        headers = {"Authorization": f"Bearer {config.api_key}"}

        console.print("[dim]🔍 Fetching available models...[/dim]")

        with httpx.Client() as http_client:
            response = http_client.get(url, headers=headers, timeout=10.0)

            if response.status_code != 200:
                _handle_http_error(response.status_code, response.text)

            models = response.json()

            # Filter by availability if requested
            if available_only:
                models = [m for m in models if m.get('available', False)]

            if not models:
                console.print("[yellow][WARNING]  No models found matching your criteria[/yellow]")
                return

            # Create a detailed table
            table = Table(title="Available AI Models", show_header=True, header_style="bold cyan")
            table.add_column("Model ID", style="cyan", no_wrap=True)
            table.add_column("Name", style="white")
            table.add_column("Type", style="magenta")
            table.add_column("Provider", style="blue")
            table.add_column("Status", justify="center")
            table.add_column("Price/1K", justify="right", style="green")
            table.add_column("Sync", justify="center", style="yellow")
            table.add_column("Async", justify="center", style="yellow")

            # Sort models: available first, then by type, then by name
            sorted_models = sorted(models, key=lambda m: (
                not m.get('available', False),
                m.get('type', 'text'),
                m.get('model_id', '')
            ))

            for model in sorted_models:
                # Status with emoji
                status = "🟢 Yes" if model.get('available') else "🔴 No"

                # Sync/Async support
                sync_support = "✓" if model.get('supports_sync', True) else "✗"
                async_support = "✓" if model.get('supports_async', True) else "✗"

                # Price
                price = model.get('price_per_1k_tokens', 0)
                price_str = f"${price:.4f}" if price > 0 else "Free"

                table.add_row(
                    model.get('model_id', 'Unknown'),
                    model.get('name', 'Unknown'),
                    model.get('type', 'text').title(),
                    model.get('provider', 'unknown').title(),
                    status,
                    price_str,
                    sync_support,
                    async_support
                )

            console.print(table)

            # Show summary
            available_count = sum(1 for m in models if m.get('available'))
            total_count = len(models)
            console.print(f"\n[dim][STATS] {available_count}/{total_count} models available[/dim]")

    except Exception as e:
        console.print(f"[red][ERROR] Error: {e}[/red]")
        raise typer.Exit(1)
