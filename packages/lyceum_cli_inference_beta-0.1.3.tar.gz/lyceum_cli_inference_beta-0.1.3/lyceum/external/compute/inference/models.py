"""Model discovery and information commands for AI inference"""


import httpx
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ....shared.config import config

console = Console()

models_app = typer.Typer(name="models", help="Model discovery and information")




@models_app.command("info")
def get_model_info(
    model_id: str = typer.Argument(..., help="Model ID to get information about"),
):
    """Get detailed information about a specific model"""
    try:
        url = f"{config.base_url}/api/v2/external/models/{model_id}"
        headers = {"Authorization": f"Bearer {config.api_key}"}

        console.print(f"[dim]🔍 Fetching info for model: {model_id}...[/dim]")

        with httpx.Client() as http_client:
            response = http_client.get(url, headers=headers, timeout=10.0)

            if response.status_code == 404:
                console.print(f"[red][ERROR] Model '{model_id}' not found[/red]")
                raise typer.Exit(1)
            elif response.status_code != 200:
                console.print(f"[red][ERROR] Error: HTTP {response.status_code}[/red]")
                console.print(f"[red]{response.text}[/red]")
                raise typer.Exit(1)

            model = response.json()

            # Check availability
            if not model.get('available', False):
                console.print(f"[red][ERROR] Model '{model_id}' is not available[/red]")
                raise typer.Exit(1)

            # Build detailed info display
            status_color = "green" if model.get('available') else "red"
            status_text = "Available ✓" if model.get('available') else "Unavailable ✗"

            info_lines = [
                f"[bold cyan]Model ID:[/bold cyan] {model.get('model_id', 'Unknown')}",
                f"[bold]Name:[/bold] {model.get('name', 'Unknown')}",
                f"[bold]Description:[/bold] {model.get('description', 'No description available')}",
                "",
                f"[bold]Type:[/bold] {model.get('type', 'text').title()}",
                f"[bold]Provider:[/bold] {model.get('provider', 'unknown').title()}",
                f"[bold]Version:[/bold] {model.get('version', 'N/A')}",
                f"[bold]Status:[/bold] [{status_color}]{status_text}[/{status_color}]",
                "",
                "[bold yellow]Capabilities:[/bold yellow]",
                f"  • Synchronous inference: {'Yes ✓' if model.get('supports_sync', True) else 'No ✗'}",
                f"  • Asynchronous/Batch: {'Yes ✓' if model.get('supports_async', True) else 'No ✗'}",
                f"  • GPU Required: {'Yes' if model.get('gpu_required', False) else 'No'}",
                "",
                "[bold green]Input/Output:[/bold green]",
                f"  • Input types: {', '.join(model.get('input_types', []))}",
                f"  • Output types: {', '.join(model.get('output_types', []))}",
                "",
                "[bold green]Pricing:[/bold green]",
                f"  • Base price: ${model.get('price_per_1k_tokens', 0):.4f} per 1K tokens",
            ]

            panel = Panel(
                "\n".join(info_lines),
                title=f"[bold white]Model Information: {model.get('name', model_id)}[/bold white]",
                border_style="cyan",
                padding=(1, 2)
            )

            console.print(panel)

    except Exception as e:
        console.print(f"[red][ERROR] Error: {e}[/red]")
        raise typer.Exit(1)
