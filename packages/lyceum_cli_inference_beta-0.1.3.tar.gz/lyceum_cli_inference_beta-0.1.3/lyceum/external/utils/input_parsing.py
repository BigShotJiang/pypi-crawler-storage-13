"""Input parsing utilities for inference operations"""
import json
from pathlib import Path
from typing import Optional

import httpx
from rich.console import Console

from ...shared.config import config
from .models import URLInput, Base64Input
from .request_utils import is_image_file, read_file_as_base64, get_s3_url

console = Console()


def parse_image_inputs(
    urls: str | None = None,
    dir: str | None = None,
    base64_data: str | None = None,
    file_path: str | None = None
) -> list[URLInput | Base64Input]:
    """Parse and normalize image inputs from various sources"""
    inputs = []

    # Handle --url (comma-separated, CLI handles single value smartly)
    if urls:
        url_list = [u.strip() for u in urls.split(",") if u.strip()]
        for url in url_list:
            inputs.append(URLInput(url=url))

    # Handle --dir
    if dir:
        dir_path = Path(dir)
        if not dir_path.exists():
            raise ValueError(f"Directory '{dir}' does not exist")
        if not dir_path.is_dir():
            raise ValueError(f"'{dir}' is not a directory")

        # Safely collect files, skipping any with problematic filenames
        pdf_files = []
        image_files = []
        try:
            for f in dir_path.iterdir():
                try:
                    # Check if we can even get the filename without errors
                    file_name = f.name
                    file_path_str = str(f)

                    # Validate filename length before proceeding
                    if len(file_name) > 255 or len(file_path_str) > 4096:
                        console.print(f"[yellow][WARNING] Skipping file: filename too long ({len(file_name)} chars)[/yellow]")
                        continue

                    # Check if filename looks like base64 data
                    if (file_name.startswith(('/9j/', 'iVBORw0KGgo', 'R0lGODlh')) and len(file_name) > 100) or \
                       (len(file_name) > 200 and all(c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=' for c in file_name[:100])):
                        console.print(f"[yellow][WARNING] Skipping file: filename appears to be base64 data[/yellow]")
                        continue

                    if f.is_file():
                        if f.suffix.lower() == ".pdf":
                            pdf_files.append(f)
                        elif is_image_file(f):
                            image_files.append(f)
                except (OSError, IOError) as e:
                    err_msg = str(e)
                    if "File name too long" in err_msg or "filename too long" in err_msg.lower() or "Errno 36" in err_msg:
                        console.print(f"[yellow][WARNING] Skipping file with invalid filename[/yellow]")
                        continue
                    raise
                except Exception as e:
                    err_msg = str(e)
                    if "File name too long" in err_msg or "filename too long" in err_msg.lower() or "Errno 36" in err_msg:
                        console.print(f"[yellow][WARNING] Skipping file with invalid filename[/yellow]")
                        continue
                    raise
        except Exception as e:
            err_msg = str(e)
            if "File name too long" in err_msg or "filename too long" in err_msg.lower() or "Errno 36" in err_msg:
                console.print(f"[red][ERROR] Directory contains files with invalid filenames. Please check your files.[/red]")
                raise ValueError(f"Cannot process directory: {err_msg}")
            raise

        # Handle PDFs: upload to S3
        for pdf_file in pdf_files:
            try:
                # Validate filename is reasonable
                if len(pdf_file.name) > 255:
                    console.print(f"[yellow][WARNING] Skipping {pdf_file.name}: filename too long (likely invalid file)[/yellow]")
                    continue
                s3_url = upload_file_to_s3(pdf_file)
                inputs.append(URLInput(url=s3_url))
                console.print(f"[dim][UPLOADED] {pdf_file.name} → {s3_url}[/dim]")
            except Exception as e:
                console.print(f"[yellow][WARNING] Failed to upload {pdf_file.name}: {e}[/yellow]")

        # Handle images: base64 encode (images sent directly, no S3 upload needed)
        for img_file in image_files:
            try:
                # Validate filename is reasonable (not base64 data)
                filename = str(img_file)
                if len(filename) > 255:
                    console.print(f"[yellow][WARNING] Skipping file with path length {len(filename)}: filename too long[/yellow]")
                    continue
                if len(img_file.name) > 255:
                    console.print(f"[yellow][WARNING] Skipping {img_file.name[:50]}...: filename too long (likely invalid file)[/yellow]")
                    continue
                # Check if filename looks like base64 data (starts with common base64 chars)
                if img_file.name.startswith(('/9j/', 'iVBORw0KGgo', 'R0lGODlh')) and len(img_file.name) > 100:
                    console.print(f"[yellow][WARNING] Skipping {img_file.name[:50]}...: filename appears to be base64 data, not a valid filename[/yellow]")
                    continue
                # Try to open the file to validate it's accessible
                try:
                    with open(img_file, 'rb') as test_f:
                        test_f.read(1)  # Just read 1 byte to test
                except (OSError, IOError) as open_err:
                    if "File name too long" in str(open_err) or "filename too long" in str(open_err).lower() or "Errno 36" in str(open_err):
                        console.print(f"[yellow][WARNING] Skipping file: {open_err}[/yellow]")
                        continue
                    raise
                file_base64_data = read_file_as_base64(img_file)
                inputs.append(Base64Input(data=file_base64_data, filename=img_file.name))
            except (OSError, IOError) as e:
                if "File name too long" in str(e) or "filename too long" in str(e).lower() or "Errno 36" in str(e):
                    console.print(f"[yellow][WARNING] Skipping file: {e}[/yellow]")
                else:
                    console.print(f"[yellow][WARNING] Could not read {img_file.name if len(str(img_file.name)) < 100 else 'file'}: {e}[/yellow]")
            except Exception as e:
                file_display = img_file.name if len(str(img_file.name)) < 100 else 'file'
                console.print(f"[yellow][WARNING] Could not read {file_display}: {e}[/yellow]")

    # Handle --base64 (smart detection: base64 string or file path)
    if base64_data:
        # Check if it looks like a file path (short, reasonable length) vs base64 data (long)
        if len(base64_data) > 500 or (len(base64_data) > 100 and all(c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=' for c in base64_data[:100])):
            # Likely base64 data, not a file path
            inputs.append(Base64Input(data=base64_data))
        else:
            # Could be a file path, try it
            try:
                base64_path = Path(base64_data)
                if base64_path.exists() and base64_path.is_file():
                    # Read file and use as base64
                    with open(base64_path, 'r') as f:
                        base64_str = f.read().strip()
                    inputs.append(Base64Input(data=base64_str))
                else:
                    # Assume it's a base64 string
                    inputs.append(Base64Input(data=base64_data))
            except (OSError, ValueError) as e:
                # If Path creation fails (e.g., filename too long), treat as base64 string
                inputs.append(Base64Input(data=base64_data))

    # Handle positional file argument
    if file_path:
        path = Path(file_path)
        if path.exists():
            if path.suffix.lower() == ".pdf":
                # Upload PDF to S3
                s3_url = upload_file_to_s3(path)
                inputs.append(URLInput(url=s3_url))
            elif is_image_file(path):
                base64_data = read_file_as_base64(path)
                inputs.append(Base64Input(data=base64_data, filename=path.name))
            else:
                raise ValueError(f"File '{file_path}' is not a supported image format")
        else:
            # Assume it's a URL
            inputs.append(URLInput(url=file_path))

    return inputs


def upload_file_to_s3(file_path: Path, key: str | None = None) -> str:
    """Upload file to S3 using /api/v2/external/storage/upload and return URL"""
    url = f"{config.base_url}/api/v2/external/storage/upload"
    headers = {"Authorization": f"Bearer {config.api_key}"}

    # Use provided key or filename, ensure it's a valid filename (not base64 data)
    file_key = key or file_path.name
    if len(file_key) > 255:
        # Filename too long, use a hash or truncate
        import hashlib
        file_key = hashlib.md5(file_key.encode()).hexdigest() + file_path.suffix

    with open(file_path, 'rb') as f:
        files = {'file': (file_path.name, f, 'application/pdf' if file_path.suffix.lower() == '.pdf' else 'application/octet-stream')}
        data = {'key': file_key} if key else {}

        with httpx.Client() as client:
            response = client.post(url, headers=headers, files=files, data=data, timeout=60.0)

            if response.status_code != 200:
                raise ValueError(f"Failed to upload file to S3: HTTP {response.status_code} - {response.text}")

            result = response.json()
            s3_key = result.get('key', file_key)
            return get_s3_url(s3_key)


def parse_jsonl_file(jsonl_path: str) -> list[dict]:
    """Parse JSONL file and return list of request dictionaries.

    Each line must be valid JSON with 'model_id' and 'input' fields.
    Returns list of individual requests (not batched together).
    """
    path = Path(jsonl_path)
    if not path.exists():
        raise ValueError(f"JSONL file '{jsonl_path}' does not exist")

    requests = []
    with open(path, 'r') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue

            try:
                req = json.loads(line)
                # Validate required fields
                if 'model_id' not in req:
                    raise ValueError(f"Line {line_num}: missing 'model_id' field")
                if 'input' not in req:
                    raise ValueError(f"Line {line_num}: missing 'input' field")
                requests.append(req)
            except json.JSONDecodeError as e:
                raise ValueError(f"Line {line_num}: invalid JSON - {e}")

    if not requests:
        raise ValueError(f"JSONL file '{jsonl_path}' contains no valid requests")

    return requests
