"""Request and validation utilities for inference operations"""
import base64
import json
import os
from pathlib import Path
from typing import Optional, Union

import httpx
from rich.console import Console

from ...shared.config import config
from .models import URLInput, Base64Input, InputData, SyncRequest, BatchRequest, InferenceResponse

console = Console()

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".tif", ".pdf"}


def is_image_file(file_path: Path) -> bool:
    """Check if file is an image based on extension"""
    return file_path.suffix.lower() in IMAGE_EXTENSIONS


def get_images_from_dir(directory: str) -> list[Path]:
    """Get all image files from a directory"""
    dir_path = Path(directory)
    if not dir_path.exists():
        raise ValueError(f"Directory '{directory}' does not exist")
    if not dir_path.is_dir():
        raise ValueError(f"'{directory}' is not a directory")

    images = [f for f in dir_path.iterdir() if f.is_file() and is_image_file(f)]
    if not images:
        raise ValueError(f"No image files found in '{directory}'")

    return sorted(images)


def read_file_as_base64(file_path: Path) -> str:
    """Read a file and encode as base64"""
    with open(file_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def get_s3_files(prefix: str = "") -> list[dict]:
    """List files from S3 storage"""
    url = f"{config.base_url}/api/v2/external/storage/list-files"
    headers = {"Authorization": f"Bearer {config.api_key}"}
    params = {"prefix": prefix, "max_files": 1000}

    with httpx.Client() as client:
        response = client.get(url, headers=headers, params=params, timeout=30.0)
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 401:
            console.print("[red][ERROR] Authentication failed. Please run 'lyceum auth login'[/red]")
            raise SystemExit(1)
        else:
            console.print(f"[red][ERROR] Error listing S3 files: HTTP {response.status_code}[/red]")
            raise SystemExit(1)


def get_s3_url(file_key: str) -> str:
    """Generate S3 URL for a file key"""
    s3_url = os.environ.get("LYCEUM_S3_URL", "https://s3.lyceum.technology")
    clean_key = file_key.lstrip("/")
    return f"{s3_url.rstrip('/')}/{clean_key}"


def get_model_info(model_id: str) -> Optional[dict]:
    """Fetch model information to check capabilities"""
    url = f"{config.base_url}/api/v2/external/models/{model_id}"
    headers = {"Authorization": f"Bearer {config.api_key}"}

    with httpx.Client() as client:
        response = client.get(url, headers=headers, timeout=10.0)
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 404:
            console.print(f"[yellow][WARNING] Model '{model_id}' not found in database. Proceeding with default assumptions.[/yellow]")
            return None
        else:
            console.print(f"[yellow][WARNING] Could not fetch model info: HTTP {response.status_code}[/yellow]")
            return None


def check_model_supports_input(model_info: Optional[dict], input_type: str) -> bool:
    """Check if model supports a specific input type"""
    if not model_info:
        return True

    input_types = model_info.get("input_types", [])
    model_type = model_info.get("type", "").lower()

    if input_types:
        return input_type in input_types

    if input_type == "text":
        return model_type in ("text", "multimodal")
    elif input_type in ("image", "pdf"):
        return model_type in ("image", "multimodal")

    return True


def _is_pdf_url(url: str) -> bool:
    """Detect if URL is a PDF by extension or path pattern"""
    url_lower = url.lower()
    # Check extension
    if url_lower.endswith(".pdf"):
        return True
    # Check common PDF URL patterns (e.g., arxiv.org/pdf/, /pdf/ in path)
    if "/pdf/" in url_lower or url_lower.endswith("/pdf"):
        return True
    return False


def build_sync_input(inp: InputData, supports_image: bool) -> dict:
    """Build input dict for sync request from various input types"""
    input_data = {}

    if isinstance(inp, URLInput):
        url = inp.url
        if supports_image:
            input_data["image_url"] = url
        if _is_pdf_url(url):
            input_data["pdf_url"] = url
        input_data["url"] = url
    elif isinstance(inp, Base64Input) and supports_image:
        input_data["image_data"] = inp.data
    elif isinstance(inp, dict):
        # Legacy dict format
        if inp.get("type") == "url":
            url = inp["url"]
            if supports_image:
                input_data["image_url"] = url
            if url.endswith(".pdf"):
                input_data["pdf_url"] = url
            input_data["url"] = url
        elif inp.get("type") == "base64" and supports_image:
            input_data["image_data"] = inp["data"]
    elif isinstance(inp, str):
        # Legacy string format
        url = inp
        if supports_image:
            input_data["image_url"] = url
        if _is_pdf_url(url):
            input_data["pdf_url"] = url
        input_data["url"] = url

    return input_data


def extract_error_message(result: dict) -> Optional[str]:
    """Extract error message from inference result"""
    output = result.get("output")
    if isinstance(output, dict):
        return output.get("error") or output.get("message")
    if result.get("raw_response"):
        return result.get("raw_response").get("error")
    return None


def display_output(output: any, raw_output: bool = False):
    """Display inference output in appropriate format"""
    if raw_output:
        console.print("[green][SUCCESS] Raw Response:[/green]")
        console.print(json.dumps(output if isinstance(output, dict) else {"output": output}, indent=2))
        return

    console.print("[green][SUCCESS] Image Analysis:[/green]")
    if isinstance(output, dict):
        if "markdown" in output:
            console.print(f"[cyan]{output['markdown']}[/cyan]")
        elif "pages" in output and isinstance(output["pages"], list) and output["pages"]:
            page_texts = [page.get("text", "") for page in output["pages"] if page.get("text")]
            console.print(f"[cyan]{'\\n\\n'.join(page_texts)}[/cyan]" if page_texts else json.dumps(output, indent=2))
        elif "text" in output:
            console.print(f"[cyan]{output['text']}[/cyan]")
        elif "content" in output:
            console.print(f"[cyan]{output['content']}[/cyan]")
        else:
            console.print(json.dumps(output, indent=2))
    else:
        console.print(f"[cyan]{output}[/cyan]")


def handle_inference_response(result: Union[dict, InferenceResponse], raw_output: bool = False):
    """Handle and display inference response"""
    if isinstance(result, dict):
        resp = InferenceResponse.from_dict(result)
    else:
        resp = result

    if resp.status == "failed":
        console.print("[red][ERROR] Inference failed[/red]")
        error_msg = extract_error_message({"output": resp.output, "raw_response": resp.raw_response})
        if error_msg:
            console.print(f"[red]Error: {error_msg}[/red]")
        else:
            console.print(f"[red]No error message provided. Full response:[/red]")
            console.print(json.dumps({"output": resp.output, "raw_response": resp.raw_response}, indent=2))
        raise SystemExit(1)

    if not resp.output or (isinstance(resp.output, dict) and len(resp.output) == 0):
        msg = ("completed but returned empty result" if resp.status == "finished" else
               f"still processing (status: {resp.status})" if resp.status in ("queued", "in_progress") else
               f"status: {resp.status}")
        console.print(f"[yellow][WARNING] Inference {msg}[/yellow]")
        if resp.status in ("queued", "in_progress"):
            console.print(f"[dim]This shouldn't happen with stream=true. Full response: {json.dumps({'output': resp.output, 'raw_response': resp.raw_response}, indent=2)}[/dim]")
        else:
            console.print(f"[dim]Status: {resp.status}, ID: {resp.id}[/dim]")
            console.print(f"[dim]Full response: {json.dumps({'output': resp.output, 'raw_response': resp.raw_response}, indent=2)}[/dim]")
        return

    display_output(resp.output, raw_output)

    if resp.usage:
        console.print(f"[dim][STATS] Tokens: {resp.usage.get('total_tokens', 0)} | "
                     f"Latency: {resp.latency_ms or 0}ms | "
                     f"Cost: ${resp.cost or 0:.4f}[/dim]")
