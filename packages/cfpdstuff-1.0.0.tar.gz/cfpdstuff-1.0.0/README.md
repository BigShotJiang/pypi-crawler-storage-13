# CFPDStuff

A simple Python library for communicating with Google's Gemini LLM. No API keys, no environment variables, no hassle - just install and use!

## Installation

```bash
pip install cfpdstuff
```

## Quick Start

### Option 1: Simple Function Call

```python
import cfpdstuff

response = cfpdstuff.chat("Explain how AI works in a few words")
print(response)
```

### Option 2: Using the Bot Class

```python
from cfpdstuff import CFPDBot

bot = CFPDBot()
response = bot.chat("What is Python?")
print(response)

# Or use the generate method
response = bot.generate("Write a haiku about coding")
print(response)
```

### Option 3: Get Bot Instance

```python
from cfpdstuff import get_bot

bot = get_bot()
response = bot.chat("Hello, how are you?")
print(response)
```

## Features

- ✅ No API key setup required
- ✅ No environment variables needed
- ✅ Simple and intuitive API
- ✅ Ready to use after pip install

## Requirements

- Python 3.7+
- google-genai package (installed automatically)

## License

MIT

