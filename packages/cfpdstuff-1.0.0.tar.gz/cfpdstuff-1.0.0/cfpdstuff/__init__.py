"""
CFPDStuff - A simple library for communicating with Google's Gemini LLM.

Usage:
    # Option 1: Use the convenience functions
    import cfpdstuff
    response = cfpdstuff.chat("Explain how AI works in a few words")
    print(response)
    
    # Option 2: Use the bot class
    from cfpdstuff import CFPDBot
    bot = CFPDBot()
    response = bot.chat("What is Python?")
    print(response)
"""

from .bot import CFPDBot, chat, generate, get_bot

__all__ = ['CFPDBot', 'chat', 'generate', 'get_bot']
__version__ = '1.0.0'

