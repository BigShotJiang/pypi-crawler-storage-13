from google import genai


class CFPDBot:
    """A simple bot interface for communicating with Google's Gemini LLM."""
    
    def __init__(self):
        """Initialize the bot with the hardcoded API key."""
        self.api_key = "AIzaSyClLpy1Qy0BN_VZ36SFHHovV2XhBR1oAro"
        self.client = genai.Client(api_key=self.api_key)
        self.model = "gemini-2.5-flash"
    
    def chat(self, message):
        """
        Send a message to the LLM and get a response.
        
        Args:
            message (str): The message/prompt to send to the LLM
            
        Returns:
            str: The response text from the LLM
        """
        response = self.client.models.generate_content(
            model=self.model,
            contents=message
        )
        return response.text
    
    def generate(self, prompt):
        """
        Alias for chat() method - generates content based on the prompt.
        
        Args:
            prompt (str): The prompt to send to the LLM
            
        Returns:
            str: The response text from the LLM
        """
        return self.chat(prompt)


# Create a default bot instance for convenience
_default_bot = None

def get_bot():
    """Get or create the default bot instance."""
    global _default_bot
    if _default_bot is None:
        _default_bot = CFPDBot()
    return _default_bot

def chat(message):
    """
    Quick function to chat with the LLM using the default bot.
    
    Args:
        message (str): The message/prompt to send to the LLM
        
    Returns:
        str: The response text from the LLM
    """
    return get_bot().chat(message)

def generate(prompt):
    """
    Quick function to generate content using the default bot.
    
    Args:
        prompt (str): The prompt to send to the LLM
        
    Returns:
        str: The response text from the LLM
    """
    return get_bot().generate(prompt)

