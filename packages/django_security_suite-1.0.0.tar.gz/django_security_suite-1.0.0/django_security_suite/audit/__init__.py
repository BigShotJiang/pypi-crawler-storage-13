"""Django Security Suite component"""
