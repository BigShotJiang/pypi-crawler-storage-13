"""Django Security Suite main application configuration"""

from django.apps import AppConfig


class DjangoSecuritySuiteConfig(AppConfig):
    """Main configuration for Django Security Suite"""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_security_suite'
    verbose_name = 'Django Security Suite'

    def ready(self):
        """Initialize the security suite when Django starts"""
        # Import and register all checks
        from django_security_suite.core import checks  # noqa

        # Import signal handlers
        from django_security_suite.authentication import signals  # noqa
        from django_security_suite.audit import signals as audit_signals  # noqa

        # Log initialization
        import logging
        logger = logging.getLogger(__name__)
        logger.info('Django Security Suite initialized successfully')
