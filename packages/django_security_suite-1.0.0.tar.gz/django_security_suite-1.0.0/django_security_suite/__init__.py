"""
Django Security Suite - Enterprise-grade security for Django applications

A comprehensive security suite providing protection against OWASP Top 10
vulnerabilities with ISO 27001 compliance features.
"""

from django_security_suite.__version__ import __version__

__all__ = ['__version__']

default_app_config = 'django_security_suite.apps.DjangoSecuritySuiteConfig'
