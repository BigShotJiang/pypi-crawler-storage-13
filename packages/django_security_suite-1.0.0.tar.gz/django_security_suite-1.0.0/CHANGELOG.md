# Changelog

All notable changes to Django Security Suite will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial planning and structure

## [1.0.0] - 2024-01-XX

### Added
- Core security middleware (headers, rate limiting, request size, suspicious patterns)
- Authentication module with brute force protection
- Session security with timeout and IP binding
- Password validators (complexity, HIBP, reuse prevention)
- Searchable encrypted fields with N-gram indexing
- Standard encrypted fields via django-crypto-fields
- Input validation and sanitization framework
- DRF secure serializer fields
- Tamper-evident audit logging with hash chaining
- API request logging
- PII masking policies
- Security decorators (@rate_limit, @csp_update, @audit_log)
- Django system checks for security validation
- Risk profile presets (strict, moderate, relaxed)
- Management commands for security reports
- Comprehensive test suite
- Full documentation

### Security
- Protection against OWASP Top 10 vulnerabilities
- ISO 27001 compliance features
- SQL injection prevention
- XSS attack prevention
- Path traversal prevention
- Command injection prevention
- CSRF protection enhancements
- Session fixation prevention

### Performance
- Redis-backed rate limiting with sliding window
- Async audit logging option
- Optimized N-gram search on encrypted fields
- Efficient middleware ordering

### Documentation
- Installation guide
- Quick start tutorial
- Configuration reference
- API documentation
- Security best practices
- Migration guide from standalone apps

### Dependencies
- Django 4.2+ support
- Django 5.0+ support
- Django 5.2+ support
- Python 3.10+ support
- Python 3.11+ support
- Python 3.12+ support

[Unreleased]: https://github.com/django-security-suite/django-security-suite/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/django-security-suite/django-security-suite/releases/tag/v1.0.0