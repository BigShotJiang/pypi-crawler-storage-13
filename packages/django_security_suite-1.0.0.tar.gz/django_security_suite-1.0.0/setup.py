#!/usr/bin/env python
"""
Setup script for Django Security Suite

This file is provided for compatibility with older tools.
The package is primarily configured through pyproject.toml.
"""

from setuptools import setup

# Read the contents of README file
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

setup(
    name='django-security-suite',
    long_description=long_description,
    long_description_content_type='text/markdown',
)