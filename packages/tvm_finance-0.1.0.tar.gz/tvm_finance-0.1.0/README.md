# tvm-finance

Extra time value of money helper functions that complement `numpy_financial`,
based on lecture examples (compound, effective annual yield, annuity FV, etc.).

This package is intended for educational use in real estate and finance courses.
