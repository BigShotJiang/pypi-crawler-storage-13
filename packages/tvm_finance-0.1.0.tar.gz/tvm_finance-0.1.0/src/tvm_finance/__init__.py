"""
tvm_finance
===========

Extra time value of money helper functions that complement ``numpy_financial``.

Typical usage
-------------
>>> from tvm_finance import compound, eay, annuity_value
"""
from .core import compound, eay, annuity_value

__all__ = ["compound", "eay", "annuity_value"]
