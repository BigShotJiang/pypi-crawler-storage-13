import enum
import typing


class Service(enum.Enum):
    ACCESS_GOVERNANCE_CP = 'access-governance-cp'
    ADM = 'adm'
    ADVISOR = 'advisor'
    AI_DATA_PLATFORM = 'ai-data-platform'
    ANALYTICS = 'analytics'
    ANNOUNCEMENTS = 'announcements'
    API_GATEWAY = 'api-gateway'
    APM_CONFIG = 'apm-config'
    APM_CONTROL_PLANE = 'apm-control-plane'
    APM_SYNTHETIC_MONITORING = 'apm-synthetic-monitoring'
    APM_TRACE_EXPLORER = 'apm-trace-explorer'
    AUDIT = 'audit'
    AUTOSCALING = 'autoscaling'
    BASTION = 'bastion'
    BIGDATA = 'bigdata'
    BLOCKCHAIN = 'blockchain'
    BUDGETS = 'budgets'
    CERTIFICATES = 'certificates'
    CERTIFICATESMGMT = 'certificatesmgmt'
    CLOUD_GUARD = 'cloud-guard'
    CLUSTERPLACEMENTGROUPS = 'clusterplacementgroups'
    COMPUTE_CLOUD_AT_CUSTOMER = 'compute-cloud-at-customer'
    CONTAINER_INSTANCES = 'container-instances'
    CONTAINERENGINE = 'containerengine'
    DASHBOARD = 'dashboard'
    DATA_CATALOG = 'data-catalog'
    DATA_FLOW = 'data-flow'
    DATA_INTEGRATION = 'data-integration'
    DATA_SAFE = 'data-safe'
    DATA_SCIENCE = 'data-science'
    DATABASE = 'database'
    DATABASE_MANAGEMENT = 'database-management'
    DATABASE_MIGRATION = 'database-migration'
    DATABASE_MULTICLOUD_INTEGRATIONS = 'database-multicloud-integrations'
    DATABASE_TOOLS = 'database-tools'
    DATALABELING = 'datalabeling'
    DATALABELING_DP = 'datalabeling-dp'
    DELEGATE_ACCESS_CONTROL = 'delegate-access-control'
    DEVOPS = 'devops'
    DIGITAL_ASSISTANT = 'digital-assistant'
    DISASTER_RECOVERY = 'disaster-recovery'
    DMS = 'dms'
    DNS = 'dns'
    DOCUMENT_UNDERSTANDING = 'document-understanding'
    EDSFU = 'edsfu'
    EMAILDELIVERY = 'emaildelivery'
    EVENTS = 'events'
    FILESTORAGE = 'filestorage'
    FLEET_MANAGEMENT = 'fleet-management'
    FUNCTIONS = 'functions'
    FUSION_APPLICATIONS = 'fusion-applications'
    GENERATIVE_AI = 'generative-ai'
    GENERATIVE_AI_AGENTS = 'generative-ai-agents'
    GENERATIVE_AI_AGENTS_CLIENT = 'generative-ai-agents-client'
    GENERATIVE_AI_INFERENCE = 'generative-ai-inference'
    GENERIC = 'generic'
    GLOBALLY_DISTRIBUTED_DATABASE = 'globally-distributed-database'
    GOLDENGATE = 'goldengate'
    HEALTHCHECKS = 'healthchecks'
    IAAS = 'iaas'
    IDENTITY = 'identity'
    IDENTITY_DP = 'identity-dp'
    INCIDENTMANAGEMENT = 'incidentmanagement'
    INSTANCEAGENT = 'instanceagent'
    INTEGRATION = 'integration'
    IOT = 'iot'
    JMS = 'jms'
    JMS_JAVA_DOWNLOAD = 'jms-java-download'
    JMS_UTILS = 'jms-utils'
    KAFKA = 'kafka'
    KEY = 'key'
    LANGUAGE = 'language'
    LICENSEMANAGER = 'licensemanager'
    LIMITS = 'limits'
    LOADBALANCER = 'loadbalancer'
    LOGAN_API_SPEC = 'logan-api-spec'
    LOGGING_DATAPLANE = 'logging-dataplane'
    LOGGING_MANAGEMENT = 'logging-management'
    LOGGING_SEARCH = 'logging-search'
    LUSTRE = 'lustre'
    MANAGED_ACCESS = 'managed-access'
    MANAGEMENT_AGENT = 'management-agent'
    MANAGEMENTDASHBOARD = 'managementdashboard'
    MARKETPLACE = 'marketplace'
    MNGDMAC = 'mngdmac'
    MONITORING = 'monitoring'
    MULTICLOUD_OMHUB_CP = 'multicloud-omhub-cp'
    MYSQL = 'mysql'
    NETMONITOR = 'netmonitor'
    NETWORK_FIREWALL = 'network-firewall'
    NETWORKLOADBALANCER = 'networkloadbalancer'
    NOSQL_DATABASE = 'nosql-database'
    NOTIFICATION = 'notification'
    OBJECTSTORAGE = 'objectstorage'
    OCB = 'ocb'
    OCCCM = 'occcm'
    OCCDS = 'occds'
    OCE = 'oce'
    OCICACHE = 'ocicache'
    OCM = 'ocm'
    OPA = 'opa'
    OPENSEARCH = 'opensearch'
    OPERATIONS_INSIGHTS = 'operations-insights'
    OPERATORACCESSCONTROL = 'operatoraccesscontrol'
    ORACLE_API_ACCESS_CONTROL = 'oracle-api-access-control'
    ORGANIZATIONS = 'organizations'
    OSMH = 'osmh'
    POSTGRESQL = 'postgresql'
    PUBLISHER = 'publisher'
    QUEUE = 'queue'
    RECOVERY_SERVICE = 'recovery-service'
    REGISTRY = 'registry'
    RESOURCE_ANALYTICS = 'resource-analytics'
    RESOURCE_DISCOVERY_MONITORING_CONTROL_API = 'resource-discovery-monitoring-control-api'
    RESOURCE_SCHEDULER = 'resource-scheduler'
    RESOURCEMANAGER = 'resourcemanager'
    ROVER = 'rover'
    S3OBJECTSTORAGE = 's3objectstorage'
    SCANNING = 'scanning'
    SEARCH = 'search'
    SECRETMGMT = 'secretmgmt'
    SECRETRETRIEVAL = 'secretretrieval'
    SECURE_DESKTOPS = 'secure-desktops'
    SECURITY_ATTRIBUTE = 'security-attribute'
    SERVICE_CATALOG = 'service-catalog'
    SERVICECONNECTORS = 'serviceconnectors'
    SMP = 'smp'
    SPEECH = 'speech'
    SQLWATCH = 'sqlwatch'
    STACK_MONITORING = 'stack-monitoring'
    STREAMING = 'streaming'
    THREAT_INTEL = 'threat-intel'
    USAGE = 'usage'
    USAGE_PROXY = 'usage-proxy'
    VISION = 'vision'
    VISUAL_BUILDER = 'visual-builder'
    VISUAL_BUILDER_STUDIO = 'visual-builder-studio'
    VMWARE = 'vmware'
    WAA = 'waa'
    WAAS = 'waas'
    WAF = 'waf'
    WLMS = 'wlms'
    WORKREQUESTS = 'workrequests'
    ZERO_TRUST_PACKET_ROUTING = 'zero-trust-packet-routing'


class Region(enum.Enum):
    AF_JOHANNESBURG_1 = 'af-johannesburg-1'
    AP_BATAM_1 = 'ap-batam-1'
    AP_CHUNCHEON_1 = 'ap-chuncheon-1'
    AP_HYDERABAD_1 = 'ap-hyderabad-1'
    AP_MELBOURNE_1 = 'ap-melbourne-1'
    AP_MUMBAI_1 = 'ap-mumbai-1'
    AP_OSAKA_1 = 'ap-osaka-1'
    AP_SEOUL_1 = 'ap-seoul-1'
    AP_SINGAPORE_1 = 'ap-singapore-1'
    AP_SINGAPORE_2 = 'ap-singapore-2'
    AP_SYDNEY_1 = 'ap-sydney-1'
    AP_TOKYO_1 = 'ap-tokyo-1'
    CA_MONTREAL_1 = 'ca-montreal-1'
    CA_TORONTO_1 = 'ca-toronto-1'
    CLOUDGUARD_CP_API = 'cloudguard-cp-api'
    EU_AMSTERDAM_1 = 'eu-amsterdam-1'
    EU_FRANKFURT_1 = 'eu-frankfurt-1'
    EU_JOVANOVAC_1 = 'eu-jovanovac-1'
    EU_MADRID_1 = 'eu-madrid-1'
    EU_MADRID_3 = 'eu-madrid-3'
    EU_MARSEILLE_1 = 'eu-marseille-1'
    EU_MILAN_1 = 'eu-milan-1'
    EU_MILAN_3 = 'eu-milan-3'
    EU_PARIS_1 = 'eu-paris-1'
    EU_STOCKHOLM_1 = 'eu-stockholm-1'
    EU_TURIN_1 = 'eu-turin-1'
    EU_ZURICH_1 = 'eu-zurich-1'
    IL_JERUSALEM_1 = 'il-jerusalem-1'
    ME_ABUDHABI_1 = 'me-abudhabi-1'
    ME_DUBAI_1 = 'me-dubai-1'
    ME_JEDDAH_1 = 'me-jeddah-1'
    ME_RIYADH_1 = 'me-riyadh-1'
    MX_MONTERREY_1 = 'mx-monterrey-1'
    MX_QUERETARO_1 = 'mx-queretaro-1'
    SA_BOGOTA_1 = 'sa-bogota-1'
    SA_MONTERREY_1 = 'sa-monterrey-1'
    SA_QUERETARO_1 = 'sa-queretaro-1'
    SA_SANTIAGO_1 = 'sa-santiago-1'
    SA_SAOPAULO_1 = 'sa-saopaulo-1'
    SA_VALPARAISO_1 = 'sa-valparaiso-1'
    SA_VINDEHO_1 = 'sa-vindeho-1'
    SA_VINHEDO_1 = 'sa-vinhedo-1'
    SP_SAOPAULO_1 = 'sp-saopaulo-1'
    UK_CARDIFF_1 = 'uk-cardiff-1'
    UK_LONDON_1 = 'uk-london-1'
    US_ABILENE_1 = 'us-abilene-1'
    US_ASHBURN_1 = 'us-ashburn-1'
    US_BOARDMAN_1 = 'us-boardman-1'
    US_CHICAGO_1 = 'us-chicago-1'
    US_DALLAS_1 = 'us-dallas-1'
    US_LANGLEY_1 = 'us-langley-1'
    US_LUKE_1 = 'us-luke-1'
    US_PHOENIX_1 = 'us-phoenix-1'
    US_PHOENIX_1OCI = 'us-phoenix-1oci'
    US_SALTLAKE_2 = 'us-saltlake-2'
    US_SANJOSE_1 = 'us-sanjose-1'


ENDPOINT_MAP: typing.Mapping[tuple[Service, Region], str] = {
    (Service.NETMONITOR, Region.AP_BATAM_1): 'https://vnca-api.ap-batam-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.AP_CHUNCHEON_1,
    ): 'https://vnca-api.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.AP_HYDERABAD_1,
    ): 'https://vnca-api.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.AP_MELBOURNE_1,
    ): 'https://vnca-api.ap-melbourne-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.AP_MUMBAI_1): 'https://vnca-api.ap-mumbai-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.AP_OSAKA_1): 'https://vnca-api.ap-osaka-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.AP_SEOUL_1): 'https://vnca-api.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.AP_SINGAPORE_1,
    ): 'https://vnca-api.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.AP_SINGAPORE_2,
    ): 'https://vnca-api.ap-singapore-2.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.AP_SYDNEY_1): 'https://vnca-api.ap-sydney-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.AP_TOKYO_1): 'https://vnca-api.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.CA_MONTREAL_1,
    ): 'https://vnca-api.ca-montreal-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.CA_TORONTO_1): 'https://vnca-api.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.EU_AMSTERDAM_1,
    ): 'https://vnca-api.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.EU_FRANKFURT_1,
    ): 'https://vnca-api.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.EU_JOVANOVAC_1,
    ): 'https://vnca-api.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.NETMONITOR, Region.EU_MADRID_1): 'https://vnca-api.eu-madrid-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.EU_MADRID_3): 'https://vnca-api.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.EU_MARSEILLE_1,
    ): 'https://vnca-api.eu-marseille-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.EU_MILAN_1): 'https://vnca-api.eu-milan-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.EU_PARIS_1): 'https://vnca-api.eu-paris-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.EU_STOCKHOLM_1,
    ): 'https://vnca-api.eu-stockholm-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.EU_TURIN_1): 'https://vnca-api.eu-turin-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.EU_ZURICH_1): 'https://vnca-api.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.IL_JERUSALEM_1,
    ): 'https://vnca-api.il-jerusalem-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.ME_DUBAI_1): 'https://vnca-api.me-dubai-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.ME_JEDDAH_1): 'https://vnca-api.me-jeddah-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.ME_RIYADH_1): 'https://vnca-api.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.MX_MONTERREY_1,
    ): 'https://vnca-api.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.MX_QUERETARO_1,
    ): 'https://vnca-api.mx-queretaro-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.SA_BOGOTA_1): 'https://vnca-api.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.SA_SANTIAGO_1,
    ): 'https://vnca-api.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.SA_SAOPAULO_1,
    ): 'https://vnca-api.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.NETMONITOR,
        Region.SA_VALPARAISO_1,
    ): 'https://vnca-api.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.SA_VINHEDO_1): 'https://vnca-api.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.UK_LONDON_1): 'https://vnca-api.uk-london-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.US_ASHBURN_1): 'https://vnca-api.us-ashburn-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.US_CHICAGO_1): 'https://vnca-api.us-chicago-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.US_PHOENIX_1): 'https://vnca-api.us-phoenix-1.oci.oraclecloud.com',
    (Service.NETMONITOR, Region.US_SANJOSE_1): 'https://vnca-api.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.OCB,
        Region.AF_JOHANNESBURG_1,
    ): 'https://cloudbridge.af-johannesburg-1.oci.oraclecloud.com',
    (Service.OCB, Region.AP_BATAM_1): 'https://cloudbridge.ap-batam-1.oci.oraclecloud.com',
    (Service.OCB, Region.AP_CHUNCHEON_1): 'https://cloudbridge.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.OCB, Region.AP_HYDERABAD_1): 'https://cloudbridge.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.OCB, Region.AP_MELBOURNE_1): 'https://cloudbridge.ap-melbourne-1.oci.oraclecloud.com',
    (Service.OCB, Region.AP_MUMBAI_1): 'https://cloudbridge.ap-mumbai-1.oci.oraclecloud.com',
    (Service.OCB, Region.AP_OSAKA_1): 'https://cloudbridge.ap-osaka-1.oci.oraclecloud.com',
    (Service.OCB, Region.AP_SEOUL_1): 'https://cloudbridge.ap-seoul-1.oci.oraclecloud.com',
    (Service.OCB, Region.AP_SINGAPORE_1): 'https://cloudbridge.ap-singapore-1.oci.oraclecloud.com',
    (Service.OCB, Region.AP_SINGAPORE_2): 'https://cloudbridge.ap-singapore-2.oci.oraclecloud.com',
    (Service.OCB, Region.AP_SYDNEY_1): 'https://cloudbridge.ap-sydney-1.oci.oraclecloud.com',
    (Service.OCB, Region.AP_TOKYO_1): 'https://cloudbridge.ap-tokyo-1.oci.oraclecloud.com',
    (Service.OCB, Region.CA_MONTREAL_1): 'https://cloudbridge.ca-montreal-1.oci.oraclecloud.com',
    (Service.OCB, Region.CA_TORONTO_1): 'https://cloudbridge.ca-toronto-1.oci.oraclecloud.com',
    (Service.OCB, Region.EU_AMSTERDAM_1): 'https://cloudbridge.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.OCB, Region.EU_FRANKFURT_1): 'https://cloudbridge.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.OCB, Region.EU_MADRID_1): 'https://cloudbridge.eu-madrid-1.oci.oraclecloud.com',
    (Service.OCB, Region.EU_MADRID_3): 'https://cloudbridge.eu-madrid-3.oci.oraclecloud.com',
    (Service.OCB, Region.EU_MARSEILLE_1): 'https://cloudbridge.eu-marseille-1.oci.oraclecloud.com',
    (Service.OCB, Region.EU_MILAN_1): 'https://cloudbridge.eu-milan-1.oci.oraclecloud.com',
    (Service.OCB, Region.EU_PARIS_1): 'https://cloudbridge.eu-paris-1.oci.oraclecloud.com',
    (Service.OCB, Region.EU_STOCKHOLM_1): 'https://cloudbridge.eu-stockholm-1.oci.oraclecloud.com',
    (Service.OCB, Region.EU_TURIN_1): 'https://cloudbridge.eu-turin-1.oci.oraclecloud.com',
    (Service.OCB, Region.EU_ZURICH_1): 'https://cloudbridge.eu-zurich-1.oci.oraclecloud.com',
    (Service.OCB, Region.IL_JERUSALEM_1): 'https://cloudbridge.il-jerusalem-1.oci.oraclecloud.com',
    (Service.OCB, Region.ME_ABUDHABI_1): 'https://cloudbridge.me-abudhabi-1.oci.oraclecloud.com',
    (Service.OCB, Region.ME_DUBAI_1): 'https://cloudbridge.me-dubai-1.oci.oraclecloud.com',
    (Service.OCB, Region.ME_JEDDAH_1): 'https://cloudbridge.me-jeddah-1.oci.oraclecloud.com',
    (Service.OCB, Region.ME_RIYADH_1): 'https://cloudbridge.me-riyadh-1.oci.oraclecloud.com',
    (Service.OCB, Region.MX_MONTERREY_1): 'https://cloudbridge.mx-monterrey-1.oci.oraclecloud.com',
    (Service.OCB, Region.MX_QUERETARO_1): 'https://cloudbridge.mx-queretaro-1.oci.oraclecloud.com',
    (Service.OCB, Region.SA_BOGOTA_1): 'https://cloudbridge.sa-bogota-1.oci.oraclecloud.com',
    (Service.OCB, Region.SA_SANTIAGO_1): 'https://cloudbridge.sa-santiago-1.oci.oraclecloud.com',
    (Service.OCB, Region.SA_SAOPAULO_1): 'https://cloudbridge.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.OCB,
        Region.SA_VALPARAISO_1,
    ): 'https://cloudbridge.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.OCB, Region.SA_VINHEDO_1): 'https://cloudbridge.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.OCB, Region.UK_CARDIFF_1): 'https://cloudbridge.uk-cardiff-1.oci.oraclecloud.com',
    (Service.OCB, Region.UK_LONDON_1): 'https://cloudbridge.uk-london-1.oci.oraclecloud.com',
    (Service.OCB, Region.US_ASHBURN_1): 'https://cloudbridge.us-ashburn-1.oci.oraclecloud.com',
    (Service.OCB, Region.US_CHICAGO_1): 'https://cloudbridge.us-chicago-1.oci.oraclecloud.com',
    (Service.OCB, Region.US_PHOENIX_1): 'https://cloudbridge.us-phoenix-1.oci.oraclecloud.com',
    (Service.OCB, Region.US_SANJOSE_1): 'https://cloudbridge.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AF_JOHANNESBURG_1,
    ): 'https://access-governance.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AP_BATAM_1,
    ): 'https://access-governance.ap-batam-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AP_CHUNCHEON_1,
    ): 'https://access-governance.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AP_HYDERABAD_1,
    ): 'https://access-governance.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AP_MELBOURNE_1,
    ): 'https://access-governance.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AP_MUMBAI_1,
    ): 'https://access-governance.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AP_OSAKA_1,
    ): 'https://access-governance.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AP_SEOUL_1,
    ): 'https://access-governance.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AP_SINGAPORE_1,
    ): 'https://access-governance.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AP_SINGAPORE_2,
    ): 'https://access-governance.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AP_SYDNEY_1,
    ): 'https://access-governance.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.AP_TOKYO_1,
    ): 'https://access-governance.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.CA_MONTREAL_1,
    ): 'https://access-governance.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.CA_TORONTO_1,
    ): 'https://access-governance.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.EU_AMSTERDAM_1,
    ): 'https://access-governance.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.EU_FRANKFURT_1,
    ): 'https://access-governance.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.EU_JOVANOVAC_1,
    ): 'https://access-governance.eu-jovanovac-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.EU_MADRID_1,
    ): 'https://access-governance.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.EU_MADRID_3,
    ): 'https://access-governance.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.EU_MARSEILLE_1,
    ): 'https://access-governance.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.EU_MILAN_1,
    ): 'https://access-governance.eu-milan-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.EU_PARIS_1,
    ): 'https://access-governance.eu-paris-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.EU_STOCKHOLM_1,
    ): 'https://access-governance.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.EU_TURIN_1,
    ): 'https://access-governance.eu-turin-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.EU_ZURICH_1,
    ): 'https://access-governance.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.IL_JERUSALEM_1,
    ): 'https://access-governance.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.ME_ABUDHABI_1,
    ): 'https://access-governance.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.ME_DUBAI_1,
    ): 'https://access-governance.me-dubai-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.ME_JEDDAH_1,
    ): 'https://access-governance.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.MX_MONTERREY_1,
    ): 'https://access-governance.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.MX_QUERETARO_1,
    ): 'https://access-governance.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.SA_BOGOTA_1,
    ): 'https://access-governance.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.SA_SANTIAGO_1,
    ): 'https://access-governance.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.SA_SAOPAULO_1,
    ): 'https://access-governance.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.SA_VALPARAISO_1,
    ): 'https://access-governance.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.SA_VINHEDO_1,
    ): 'https://access-governance.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.UK_CARDIFF_1,
    ): 'https://access-governance.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.UK_LONDON_1,
    ): 'https://access-governance.uk-london-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.US_ASHBURN_1,
    ): 'https://access-governance.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.US_CHICAGO_1,
    ): 'https://access-governance.us-chicago-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.US_PHOENIX_1,
    ): 'https://access-governance.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.ACCESS_GOVERNANCE_CP,
        Region.US_SANJOSE_1,
    ): 'https://access-governance.us-sanjose-1.oci.oraclecloud.com',
    (Service.ADM, Region.AF_JOHANNESBURG_1): 'https://adm.af-johannesburg-1.oci.oraclecloud.com',
    (Service.ADM, Region.AP_BATAM_1): 'https://adm.ap-batam-1.oci.oraclecloud.com',
    (Service.ADM, Region.AP_CHUNCHEON_1): 'https://adm.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.ADM, Region.AP_HYDERABAD_1): 'https://adm.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.ADM, Region.AP_MELBOURNE_1): 'https://adm.ap-melbourne-1.oci.oraclecloud.com',
    (Service.ADM, Region.AP_MUMBAI_1): 'https://adm.ap-mumbai-1.oci.oraclecloud.com',
    (Service.ADM, Region.AP_OSAKA_1): 'https://adm.ap-osaka-1.oci.oraclecloud.com',
    (Service.ADM, Region.AP_SEOUL_1): 'https://adm.ap-seoul-1.oci.oraclecloud.com',
    (Service.ADM, Region.AP_SINGAPORE_1): 'https://adm.ap-singapore-1.oci.oraclecloud.com',
    (Service.ADM, Region.AP_SINGAPORE_2): 'https://adm.ap-singapore-2.oci.oraclecloud.com',
    (Service.ADM, Region.AP_SYDNEY_1): 'https://adm.ap-sydney-1.oci.oraclecloud.com',
    (Service.ADM, Region.AP_TOKYO_1): 'https://adm.ap-tokyo-1.oci.oraclecloud.com',
    (Service.ADM, Region.CA_MONTREAL_1): 'https://adm.ca-montreal-1.oci.oraclecloud.com',
    (Service.ADM, Region.CA_TORONTO_1): 'https://adm.ca-toronto-1.oci.oraclecloud.com',
    (Service.ADM, Region.EU_AMSTERDAM_1): 'https://adm.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.ADM, Region.EU_FRANKFURT_1): 'https://adm.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.ADM, Region.EU_JOVANOVAC_1): 'https://adm.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.ADM, Region.EU_MADRID_1): 'https://adm.eu-madrid-1.oci.oraclecloud.com',
    (Service.ADM, Region.EU_MADRID_3): 'https://adm.eu-madrid-3.oci.oraclecloud.com',
    (Service.ADM, Region.EU_MARSEILLE_1): 'https://adm.eu-marseille-1.oci.oraclecloud.com',
    (Service.ADM, Region.EU_MILAN_1): 'https://adm.eu-milan-1.oci.oraclecloud.com',
    (Service.ADM, Region.EU_PARIS_1): 'https://adm.eu-paris-1.oci.oraclecloud.com',
    (Service.ADM, Region.EU_STOCKHOLM_1): 'https://adm.eu-stockholm-1.oci.oraclecloud.com',
    (Service.ADM, Region.EU_TURIN_1): 'https://adm.eu-turin-1.oci.oraclecloud.com',
    (Service.ADM, Region.EU_ZURICH_1): 'https://adm.eu-zurich-1.oci.oraclecloud.com',
    (Service.ADM, Region.IL_JERUSALEM_1): 'https://adm.il-jerusalem-1.oci.oraclecloud.com',
    (Service.ADM, Region.ME_ABUDHABI_1): 'https://adm.me-abudhabi-1.oci.oraclecloud.com',
    (Service.ADM, Region.ME_DUBAI_1): 'https://adm.me-dubai-1.oci.oraclecloud.com',
    (Service.ADM, Region.ME_JEDDAH_1): 'https://adm.me-jeddah-1.oci.oraclecloud.com',
    (Service.ADM, Region.ME_RIYADH_1): 'https://adm.me-riyadh-1.oci.oraclecloud.com',
    (Service.ADM, Region.MX_MONTERREY_1): 'https://adm.mx-monterrey-1.oci.oraclecloud.com',
    (Service.ADM, Region.MX_QUERETARO_1): 'https://adm.mx-queretaro-1.oci.oraclecloud.com',
    (Service.ADM, Region.SA_BOGOTA_1): 'https://adm.sa-bogota-1.oci.oraclecloud.com',
    (Service.ADM, Region.SA_SANTIAGO_1): 'https://adm.sa-santiago-1.oci.oraclecloud.com',
    (Service.ADM, Region.SA_SAOPAULO_1): 'https://adm.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.ADM, Region.SA_VALPARAISO_1): 'https://adm.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.ADM, Region.SA_VINHEDO_1): 'https://adm.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.ADM, Region.UK_CARDIFF_1): 'https://adm.uk-cardiff-1.oci.oraclecloud.com',
    (Service.ADM, Region.UK_LONDON_1): 'https://adm.uk-london-1.oci.oraclecloud.com',
    (Service.ADM, Region.US_ASHBURN_1): 'https://adm.us-ashburn-1.oci.oraclecloud.com',
    (Service.ADM, Region.US_CHICAGO_1): 'https://adm.us-chicago-1.oci.oraclecloud.com',
    (Service.ADM, Region.US_PHOENIX_1): 'https://adm.us-phoenix-1.oci.oraclecloud.com',
    (Service.ADM, Region.US_SANJOSE_1): 'https://adm.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.AF_JOHANNESBURG_1,
    ): 'https://optimizer.af-johannesburg-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.AP_BATAM_1): 'https://optimizer.ap-batam-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.AP_CHUNCHEON_1,
    ): 'https://optimizer.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.AP_HYDERABAD_1,
    ): 'https://optimizer.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.AP_MELBOURNE_1,
    ): 'https://optimizer.ap-melbourne-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.AP_MUMBAI_1): 'https://optimizer.ap-mumbai-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.AP_OSAKA_1): 'https://optimizer.ap-osaka-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.AP_SEOUL_1): 'https://optimizer.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.AP_SINGAPORE_1,
    ): 'https://optimizer.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.AP_SINGAPORE_2,
    ): 'https://optimizer.ap-singapore-2.oci.oraclecloud.com',
    (Service.ADVISOR, Region.AP_SYDNEY_1): 'https://optimizer.ap-sydney-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.AP_TOKYO_1): 'https://optimizer.ap-tokyo-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.CA_MONTREAL_1): 'https://optimizer.ca-montreal-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.CA_TORONTO_1): 'https://optimizer.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.EU_AMSTERDAM_1,
    ): 'https://optimizer.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.EU_FRANKFURT_1,
    ): 'https://optimizer.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.EU_JOVANOVAC_1,
    ): 'https://optimizer.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.ADVISOR, Region.EU_MADRID_1): 'https://optimizer.eu-madrid-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.EU_MADRID_3): 'https://optimizer.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.EU_MARSEILLE_1,
    ): 'https://optimizer.eu-marseille-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.EU_MILAN_1): 'https://optimizer.eu-milan-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.EU_PARIS_1): 'https://optimizer.eu-paris-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.EU_STOCKHOLM_1,
    ): 'https://optimizer.eu-stockholm-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.EU_TURIN_1): 'https://optimizer.eu-turin-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.EU_ZURICH_1): 'https://optimizer.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.IL_JERUSALEM_1,
    ): 'https://optimizer.il-jerusalem-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.ME_ABUDHABI_1): 'https://optimizer.me-abudhabi-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.ME_DUBAI_1): 'https://optimizer.me-dubai-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.ME_JEDDAH_1): 'https://optimizer.me-jeddah-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.ME_RIYADH_1): 'https://optimizer.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.MX_MONTERREY_1,
    ): 'https://optimizer.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.MX_QUERETARO_1,
    ): 'https://optimizer.mx-queretaro-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.SA_BOGOTA_1): 'https://optimizer.sa-bogota-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.SA_SANTIAGO_1): 'https://optimizer.sa-santiago-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.SA_SAOPAULO_1): 'https://optimizer.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.ADVISOR,
        Region.SA_VALPARAISO_1,
    ): 'https://optimizer.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.SA_VINHEDO_1): 'https://optimizer.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.UK_CARDIFF_1): 'https://optimizer.uk-cardiff-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.UK_LONDON_1): 'https://optimizer.uk-london-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.US_ASHBURN_1): 'https://optimizer.us-ashburn-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.US_PHOENIX_1): 'https://optimizer.us-phoenix-1.oci.oraclecloud.com',
    (Service.ADVISOR, Region.US_SANJOSE_1): 'https://optimizer.us-sanjose-1.oci.oraclecloud.com',
    (Service.AI_DATA_PLATFORM, Region.AP_MUMBAI_1): 'https://aidp.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.AI_DATA_PLATFORM,
        Region.EU_FRANKFURT_1,
    ): 'https://aidp.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.AI_DATA_PLATFORM,
        Region.SA_SAOPAULO_1,
    ): 'https://aidp.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.AI_DATA_PLATFORM, Region.UK_LONDON_1): 'https://aidp.uk-london-1.oci.oraclecloud.com',
    (
        Service.AI_DATA_PLATFORM,
        Region.US_ASHBURN_1,
    ): 'https://aidp.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.AI_DATA_PLATFORM,
        Region.US_PHOENIX_1,
    ): 'https://aidp.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://analytics.af-johannesburg-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.AP_BATAM_1): 'https://analytics.ap-batam-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.AP_CHUNCHEON_1,
    ): 'https://analytics.ap-chuncheon-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.AP_HYDERABAD_1,
    ): 'https://analytics.ap-hyderabad-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.AP_MELBOURNE_1,
    ): 'https://analytics.ap-melbourne-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.AP_MUMBAI_1): 'https://analytics.ap-mumbai-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.AP_OSAKA_1): 'https://analytics.ap-osaka-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.AP_SEOUL_1): 'https://analytics.ap-seoul-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.AP_SINGAPORE_1,
    ): 'https://analytics.ap-singapore-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.AP_SINGAPORE_2,
    ): 'https://analytics.ap-singapore-2.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.AP_SYDNEY_1): 'https://analytics.ap-sydney-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.AP_TOKYO_1): 'https://analytics.ap-tokyo-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.CA_MONTREAL_1,
    ): 'https://analytics.ca-montreal-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.CA_TORONTO_1): 'https://analytics.ca-toronto-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.EU_AMSTERDAM_1,
    ): 'https://analytics.eu-amsterdam-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.EU_FRANKFURT_1,
    ): 'https://analytics.eu-frankfurt-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.EU_JOVANOVAC_1,
    ): 'https://analytics.eu-jovanovac-1.ocp.oraclecloud20.com',
    (Service.ANALYTICS, Region.EU_MADRID_1): 'https://analytics.eu-madrid-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.EU_MADRID_3): 'https://analytics.eu-madrid-3.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.EU_MARSEILLE_1,
    ): 'https://analytics.eu-marseille-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.EU_MILAN_1): 'https://analytics.eu-milan-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.EU_PARIS_1): 'https://analytics.eu-paris-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.EU_STOCKHOLM_1,
    ): 'https://analytics.eu-stockholm-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.EU_TURIN_1): 'https://analytics.eu-turin-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.EU_ZURICH_1): 'https://analytics.eu-zurich-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.IL_JERUSALEM_1,
    ): 'https://analytics.il-jerusalem-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.ME_ABUDHABI_1,
    ): 'https://analytics.me-abudhabi-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.ME_DUBAI_1): 'https://analytics.me-dubai-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.ME_JEDDAH_1): 'https://analytics.me-jeddah-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.ME_RIYADH_1): 'https://analytics.me-riyadh-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.MX_MONTERREY_1,
    ): 'https://analytics.mx-monterrey-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.MX_QUERETARO_1,
    ): 'https://analytics.mx-queretaro-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.SA_BOGOTA_1): 'https://analytics.sa-bogota-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.SA_SANTIAGO_1,
    ): 'https://analytics.sa-santiago-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.SA_SAOPAULO_1,
    ): 'https://analytics.sa-saopaulo-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.SA_VALPARAISO_1,
    ): 'https://analytics.sa-valparaiso-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.SA_VINHEDO_1): 'https://analytics.sa-vinhedo-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.UK_CARDIFF_1): 'https://analytics.uk-cardiff-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.UK_LONDON_1): 'https://analytics.uk-london-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.US_ASHBURN_1): 'https://analytics.us-ashburn-1.ocp.oraclecloud.com',
    (
        Service.ANALYTICS,
        Region.US_BOARDMAN_1,
    ): 'https://analytics.us-boardman-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.US_CHICAGO_1): 'https://analytics.us-chicago-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.US_PHOENIX_1): 'https://analytics.us-phoenix-1.ocp.oraclecloud.com',
    (Service.ANALYTICS, Region.US_SANJOSE_1): 'https://analytics.us-sanjose-1.ocp.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://announcements.af-johannesburg-1.oraclecloud.com',
    (Service.ANNOUNCEMENTS, Region.AP_BATAM_1): 'https://announcements.ap-batam-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.AP_CHUNCHEON_1,
    ): 'https://announcements.ap-chuncheon-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.AP_HYDERABAD_1,
    ): 'https://announcements.ap-hyderabad-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.AP_MELBOURNE_1,
    ): 'https://announcements.ap-melbourne-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.AP_MUMBAI_1,
    ): 'https://announcements.ap-mumbai-1.oraclecloud.com',
    (Service.ANNOUNCEMENTS, Region.AP_OSAKA_1): 'https://announcements.ap-osaka-1.oraclecloud.com',
    (Service.ANNOUNCEMENTS, Region.AP_SEOUL_1): 'https://announcements.ap-seoul-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.AP_SINGAPORE_1,
    ): 'https://announcements.ap-singapore-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.AP_SINGAPORE_2,
    ): 'https://announcements.ap-singapore-2.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.AP_SYDNEY_1,
    ): 'https://announcements.ap-sydney-1.oraclecloud.com',
    (Service.ANNOUNCEMENTS, Region.AP_TOKYO_1): 'https://announcements.ap-tokyo-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.CA_MONTREAL_1,
    ): 'https://announcements.ca-montreal-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.CA_TORONTO_1,
    ): 'https://announcements.ca-toronto-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.EU_AMSTERDAM_1,
    ): 'https://announcements.eu-amsterdam-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.EU_FRANKFURT_1,
    ): 'https://announcements.eu-frankfurt-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.EU_JOVANOVAC_1,
    ): 'https://announcements.eu-jovanovac-1.oraclecloud20.com',
    (
        Service.ANNOUNCEMENTS,
        Region.EU_MADRID_1,
    ): 'https://announcements.eu-madrid-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.EU_MADRID_3,
    ): 'https://announcements.eu-madrid-3.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.EU_MARSEILLE_1,
    ): 'https://announcements.eu-marseille-1.oraclecloud.com',
    (Service.ANNOUNCEMENTS, Region.EU_MILAN_1): 'https://announcements.eu-milan-1.oraclecloud.com',
    (Service.ANNOUNCEMENTS, Region.EU_PARIS_1): 'https://announcements.eu-paris-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.EU_STOCKHOLM_1,
    ): 'https://announcements.eu-stockholm-1.oraclecloud.com',
    (Service.ANNOUNCEMENTS, Region.EU_TURIN_1): 'https://announcements.eu-turin-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.EU_ZURICH_1,
    ): 'https://announcements.eu-zurich-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.IL_JERUSALEM_1,
    ): 'https://announcements.il-jerusalem-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.ME_ABUDHABI_1,
    ): 'https://announcements.me-abudhabi-1.oraclecloud.com',
    (Service.ANNOUNCEMENTS, Region.ME_DUBAI_1): 'https://announcements.me-dubai-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.ME_JEDDAH_1,
    ): 'https://announcements.me-jeddah-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.ME_RIYADH_1,
    ): 'https://announcements.me-riyadh-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.MX_MONTERREY_1,
    ): 'https://announcements.mx-monterrey-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.MX_QUERETARO_1,
    ): 'https://announcements.mx-queretaro-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.SA_BOGOTA_1,
    ): 'https://announcements.sa-bogota-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.SA_SANTIAGO_1,
    ): 'https://announcements.sa-santiago-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.SA_SAOPAULO_1,
    ): 'https://announcements.sa-saopaulo-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.SA_VALPARAISO_1,
    ): 'https://announcements.sa-valparaiso-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.SA_VINHEDO_1,
    ): 'https://announcements.sa-vinhedo-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.UK_CARDIFF_1,
    ): 'https://announcements.uk-cardiff-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.UK_LONDON_1,
    ): 'https://announcements.uk-london-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.US_ASHBURN_1,
    ): 'https://announcements.us-ashburn-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.US_CHICAGO_1,
    ): 'https://announcements.us-chicago-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.US_PHOENIX_1,
    ): 'https://announcements.us-phoenix-1.oraclecloud.com',
    (
        Service.ANNOUNCEMENTS,
        Region.US_SANJOSE_1,
    ): 'https://announcements.us-sanjose-1.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.AF_JOHANNESBURG_1,
    ): 'https://apigateway.af-johannesburg-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.AP_BATAM_1): 'https://apigateway.ap-batam-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.AP_CHUNCHEON_1,
    ): 'https://apigateway.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.AP_HYDERABAD_1,
    ): 'https://apigateway.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.AP_MELBOURNE_1,
    ): 'https://apigateway.ap-melbourne-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.AP_MUMBAI_1): 'https://apigateway.ap-mumbai-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.AP_OSAKA_1): 'https://apigateway.ap-osaka-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.AP_SEOUL_1): 'https://apigateway.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.AP_SINGAPORE_1,
    ): 'https://apigateway.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.AP_SINGAPORE_2,
    ): 'https://apigateway.ap-singapore-2.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.AP_SYDNEY_1): 'https://apigateway.ap-sydney-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.AP_TOKYO_1): 'https://apigateway.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.CA_MONTREAL_1,
    ): 'https://apigateway.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.CA_TORONTO_1,
    ): 'https://apigateway.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.EU_AMSTERDAM_1,
    ): 'https://apigateway.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.EU_FRANKFURT_1,
    ): 'https://apigateway.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.EU_JOVANOVAC_1,
    ): 'https://apigateway.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.API_GATEWAY, Region.EU_MADRID_1): 'https://apigateway.eu-madrid-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.EU_MADRID_3): 'https://apigateway.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.EU_MARSEILLE_1,
    ): 'https://apigateway.eu-marseille-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.EU_MILAN_1): 'https://apigateway.eu-milan-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.EU_PARIS_1): 'https://apigateway.eu-paris-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.EU_STOCKHOLM_1,
    ): 'https://apigateway.eu-stockholm-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.EU_TURIN_1): 'https://apigateway.eu-turin-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.EU_ZURICH_1): 'https://apigateway.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.IL_JERUSALEM_1,
    ): 'https://apigateway.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.ME_ABUDHABI_1,
    ): 'https://apigateway.me-abudhabi-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.ME_DUBAI_1): 'https://apigateway.me-dubai-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.ME_JEDDAH_1): 'https://apigateway.me-jeddah-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.ME_RIYADH_1): 'https://apigateway.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.MX_MONTERREY_1,
    ): 'https://apigateway.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.MX_QUERETARO_1,
    ): 'https://apigateway.mx-queretaro-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.SA_BOGOTA_1): 'https://apigateway.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.SA_SANTIAGO_1,
    ): 'https://apigateway.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.SA_SAOPAULO_1,
    ): 'https://apigateway.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.SA_VALPARAISO_1,
    ): 'https://apigateway.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.SA_VINHEDO_1,
    ): 'https://apigateway.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.UK_CARDIFF_1,
    ): 'https://apigateway.uk-cardiff-1.oci.oraclecloud.com',
    (Service.API_GATEWAY, Region.UK_LONDON_1): 'https://apigateway.uk-london-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.US_ASHBURN_1,
    ): 'https://apigateway.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.US_CHICAGO_1,
    ): 'https://apigateway.us-chicago-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.US_PHOENIX_1,
    ): 'https://apigateway.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.API_GATEWAY,
        Region.US_SANJOSE_1,
    ): 'https://apigateway.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.AF_JOHANNESBURG_1,
    ): 'https://apm-config.af-johannesburg-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.AP_BATAM_1): 'https://apm-config.ap-batam-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.AP_CHUNCHEON_1,
    ): 'https://apm-config.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.AP_HYDERABAD_1,
    ): 'https://apm-config.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.AP_MELBOURNE_1,
    ): 'https://apm-config.ap-melbourne-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.AP_MUMBAI_1): 'https://apm-config.ap-mumbai-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.AP_OSAKA_1): 'https://apm-config.ap-osaka-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.AP_SEOUL_1): 'https://apm-config.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.AP_SINGAPORE_1,
    ): 'https://apm-config.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.AP_SINGAPORE_2,
    ): 'https://apm-config.ap-singapore-2.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.AP_SYDNEY_1): 'https://apm-config.ap-sydney-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.AP_TOKYO_1): 'https://apm-config.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.CA_MONTREAL_1,
    ): 'https://apm-config.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.CA_TORONTO_1,
    ): 'https://apm-config.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.EU_AMSTERDAM_1,
    ): 'https://apm-config.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.EU_FRANKFURT_1,
    ): 'https://apm-config.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.EU_JOVANOVAC_1,
    ): 'https://apm-config.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.APM_CONFIG, Region.EU_MADRID_1): 'https://apm-config.eu-madrid-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.EU_MADRID_3): 'https://apm-config.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.EU_MARSEILLE_1,
    ): 'https://apm-config.eu-marseille-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.EU_MILAN_1): 'https://apm-config.eu-milan-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.EU_PARIS_1): 'https://apm-config.eu-paris-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.EU_STOCKHOLM_1,
    ): 'https://apm-config.eu-stockholm-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.EU_TURIN_1): 'https://apm-config.eu-turin-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.EU_ZURICH_1): 'https://apm-config.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.IL_JERUSALEM_1,
    ): 'https://apm-config.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.ME_ABUDHABI_1,
    ): 'https://apm-config.me-abudhabi-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.ME_DUBAI_1): 'https://apm-config.me-dubai-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.ME_JEDDAH_1): 'https://apm-config.me-jeddah-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.ME_RIYADH_1): 'https://apm-config.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.MX_MONTERREY_1,
    ): 'https://apm-config.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.MX_QUERETARO_1,
    ): 'https://apm-config.mx-queretaro-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.SA_BOGOTA_1): 'https://apm-config.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.SA_SANTIAGO_1,
    ): 'https://apm-config.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.SA_SAOPAULO_1,
    ): 'https://apm-config.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.SA_VALPARAISO_1,
    ): 'https://apm-config.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.SA_VINHEDO_1,
    ): 'https://apm-config.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.UK_CARDIFF_1,
    ): 'https://apm-config.uk-cardiff-1.oci.oraclecloud.com',
    (Service.APM_CONFIG, Region.UK_LONDON_1): 'https://apm-config.uk-london-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.US_ASHBURN_1,
    ): 'https://apm-config.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.US_CHICAGO_1,
    ): 'https://apm-config.us-chicago-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.US_PHOENIX_1,
    ): 'https://apm-config.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.APM_CONFIG,
        Region.US_SANJOSE_1,
    ): 'https://apm-config.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://apm-cp.af-johannesburg-1.oci.oraclecloud.com',
    (Service.APM_CONTROL_PLANE, Region.AP_BATAM_1): 'https://apm-cp.ap-batam-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.AP_CHUNCHEON_1,
    ): 'https://apm-cp.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.AP_HYDERABAD_1,
    ): 'https://apm-cp.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.AP_MELBOURNE_1,
    ): 'https://apm-cp.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.AP_MUMBAI_1,
    ): 'https://apm-cp.ap-mumbai-1.oci.oraclecloud.com',
    (Service.APM_CONTROL_PLANE, Region.AP_OSAKA_1): 'https://apm-cp.ap-osaka-1.oci.oraclecloud.com',
    (Service.APM_CONTROL_PLANE, Region.AP_SEOUL_1): 'https://apm-cp.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.AP_SINGAPORE_1,
    ): 'https://apm-cp.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.AP_SINGAPORE_2,
    ): 'https://apm-cp.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.AP_SYDNEY_1,
    ): 'https://apm-cp.ap-sydney-1.oci.oraclecloud.com',
    (Service.APM_CONTROL_PLANE, Region.AP_TOKYO_1): 'https://apm-cp.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.CA_MONTREAL_1,
    ): 'https://apm-cp.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.CA_TORONTO_1,
    ): 'https://apm-cp.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.EU_AMSTERDAM_1,
    ): 'https://apm-cp.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.EU_FRANKFURT_1,
    ): 'https://apm-cp.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.EU_JOVANOVAC_1,
    ): 'https://apm-cp.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.EU_MADRID_1,
    ): 'https://apm-cp.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.EU_MADRID_3,
    ): 'https://apm-cp.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.EU_MARSEILLE_1,
    ): 'https://apm-cp.eu-marseille-1.oci.oraclecloud.com',
    (Service.APM_CONTROL_PLANE, Region.EU_MILAN_1): 'https://apm-cp.eu-milan-1.oci.oraclecloud.com',
    (Service.APM_CONTROL_PLANE, Region.EU_PARIS_1): 'https://apm-cp.eu-paris-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.EU_STOCKHOLM_1,
    ): 'https://apm-cp.eu-stockholm-1.oci.oraclecloud.com',
    (Service.APM_CONTROL_PLANE, Region.EU_TURIN_1): 'https://apm-cp.eu-turin-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.EU_ZURICH_1,
    ): 'https://apm-cp.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.IL_JERUSALEM_1,
    ): 'https://apm-cp.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.ME_ABUDHABI_1,
    ): 'https://apm-cp.me-abudhabi-1.oci.oraclecloud.com',
    (Service.APM_CONTROL_PLANE, Region.ME_DUBAI_1): 'https://apm-cp.me-dubai-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.ME_JEDDAH_1,
    ): 'https://apm-cp.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.ME_RIYADH_1,
    ): 'https://apm-cp.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.MX_MONTERREY_1,
    ): 'https://apm-cp.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.MX_QUERETARO_1,
    ): 'https://apm-cp.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.SA_BOGOTA_1,
    ): 'https://apm-cp.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.SA_SANTIAGO_1,
    ): 'https://apm-cp.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.SA_SAOPAULO_1,
    ): 'https://apm-cp.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.SA_VALPARAISO_1,
    ): 'https://apm-cp.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.SA_VINHEDO_1,
    ): 'https://apm-cp.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.UK_CARDIFF_1,
    ): 'https://apm-cp.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.UK_LONDON_1,
    ): 'https://apm-cp.uk-london-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.US_ASHBURN_1,
    ): 'https://apm-cp.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.US_CHICAGO_1,
    ): 'https://apm-cp.us-chicago-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.US_PHOENIX_1,
    ): 'https://apm-cp.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.APM_CONTROL_PLANE,
        Region.US_SANJOSE_1,
    ): 'https://apm-cp.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AF_JOHANNESBURG_1,
    ): 'https://apm-synthetic.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AP_BATAM_1,
    ): 'https://apm-synthetic.ap-batam-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AP_CHUNCHEON_1,
    ): 'https://apm-synthetic.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AP_HYDERABAD_1,
    ): 'https://apm-synthetic.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AP_MELBOURNE_1,
    ): 'https://apm-synthetic.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AP_MUMBAI_1,
    ): 'https://apm-synthetic.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AP_OSAKA_1,
    ): 'https://apm-synthetic.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AP_SEOUL_1,
    ): 'https://apm-synthetic.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AP_SINGAPORE_1,
    ): 'https://apm-synthetic.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AP_SINGAPORE_2,
    ): 'https://apm-synthetic.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AP_SYDNEY_1,
    ): 'https://apm-synthetic.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.AP_TOKYO_1,
    ): 'https://apm-synthetic.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.CA_MONTREAL_1,
    ): 'https://apm-synthetic.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.CA_TORONTO_1,
    ): 'https://apm-synthetic.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.EU_AMSTERDAM_1,
    ): 'https://apm-synthetic.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.EU_FRANKFURT_1,
    ): 'https://apm-synthetic.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.EU_JOVANOVAC_1,
    ): 'https://apm-synthetic.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.EU_MADRID_1,
    ): 'https://apm-synthetic.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.EU_MADRID_3,
    ): 'https://apm-synthetic.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.EU_MARSEILLE_1,
    ): 'https://apm-synthetic.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.EU_MILAN_1,
    ): 'https://apm-synthetic.eu-milan-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.EU_PARIS_1,
    ): 'https://apm-synthetic.eu-paris-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.EU_STOCKHOLM_1,
    ): 'https://apm-synthetic.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.EU_TURIN_1,
    ): 'https://apm-synthetic.eu-turin-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.EU_ZURICH_1,
    ): 'https://apm-synthetic.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.IL_JERUSALEM_1,
    ): 'https://apm-synthetic.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.ME_ABUDHABI_1,
    ): 'https://apm-synthetic.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.ME_DUBAI_1,
    ): 'https://apm-synthetic.me-dubai-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.ME_JEDDAH_1,
    ): 'https://apm-synthetic.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.ME_RIYADH_1,
    ): 'https://apm-synthetic.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.MX_MONTERREY_1,
    ): 'https://apm-synthetic.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.MX_QUERETARO_1,
    ): 'https://apm-synthetic.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.SA_BOGOTA_1,
    ): 'https://apm-synthetic.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.SA_SANTIAGO_1,
    ): 'https://apm-synthetic.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.SA_SAOPAULO_1,
    ): 'https://apm-synthetic.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.SA_VALPARAISO_1,
    ): 'https://apm-synthetic.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.SA_VINHEDO_1,
    ): 'https://apm-synthetic.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.UK_CARDIFF_1,
    ): 'https://apm-synthetic.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.UK_LONDON_1,
    ): 'https://apm-synthetic.uk-london-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.US_ASHBURN_1,
    ): 'https://apm-synthetic.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.US_CHICAGO_1,
    ): 'https://apm-synthetic.us-chicago-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.US_PHOENIX_1,
    ): 'https://apm-synthetic.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.APM_SYNTHETIC_MONITORING,
        Region.US_SANJOSE_1,
    ): 'https://apm-synthetic.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AF_JOHANNESBURG_1,
    ): 'https://apm-trace.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AP_BATAM_1,
    ): 'https://apm-trace.ap-batam-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AP_CHUNCHEON_1,
    ): 'https://apm-trace.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AP_HYDERABAD_1,
    ): 'https://apm-trace.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AP_MELBOURNE_1,
    ): 'https://apm-trace.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AP_MUMBAI_1,
    ): 'https://apm-trace.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AP_OSAKA_1,
    ): 'https://apm-trace.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AP_SEOUL_1,
    ): 'https://apm-trace.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AP_SINGAPORE_1,
    ): 'https://apm-trace.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AP_SINGAPORE_2,
    ): 'https://apm-trace.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AP_SYDNEY_1,
    ): 'https://apm-trace.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.AP_TOKYO_1,
    ): 'https://apm-trace.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.CA_MONTREAL_1,
    ): 'https://apm-trace.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.CA_TORONTO_1,
    ): 'https://apm-trace.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.EU_AMSTERDAM_1,
    ): 'https://apm-trace.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.EU_FRANKFURT_1,
    ): 'https://apm-trace.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.EU_JOVANOVAC_1,
    ): 'https://apm-trace.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.EU_MADRID_1,
    ): 'https://apm-trace.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.EU_MADRID_3,
    ): 'https://apm-trace.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.EU_MARSEILLE_1,
    ): 'https://apm-trace.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.EU_MILAN_1,
    ): 'https://apm-trace.eu-milan-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.EU_PARIS_1,
    ): 'https://apm-trace.eu-paris-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.EU_STOCKHOLM_1,
    ): 'https://apm-trace.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.EU_TURIN_1,
    ): 'https://apm-trace.eu-turin-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.EU_ZURICH_1,
    ): 'https://apm-trace.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.IL_JERUSALEM_1,
    ): 'https://apm-trace.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.ME_ABUDHABI_1,
    ): 'https://apm-trace.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.ME_DUBAI_1,
    ): 'https://apm-trace.me-dubai-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.ME_JEDDAH_1,
    ): 'https://apm-trace.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.ME_RIYADH_1,
    ): 'https://apm-trace.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.MX_MONTERREY_1,
    ): 'https://apm-trace.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.MX_QUERETARO_1,
    ): 'https://apm-trace.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.SA_BOGOTA_1,
    ): 'https://apm-trace.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.SA_SANTIAGO_1,
    ): 'https://apm-trace.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.SA_SAOPAULO_1,
    ): 'https://apm-trace.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.SA_VALPARAISO_1,
    ): 'https://apm-trace.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.SA_VINHEDO_1,
    ): 'https://apm-trace.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.UK_CARDIFF_1,
    ): 'https://apm-trace.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.UK_LONDON_1,
    ): 'https://apm-trace.uk-london-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.US_ASHBURN_1,
    ): 'https://apm-trace.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.US_CHICAGO_1,
    ): 'https://apm-trace.us-chicago-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.US_PHOENIX_1,
    ): 'https://apm-trace.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.APM_TRACE_EXPLORER,
        Region.US_SANJOSE_1,
    ): 'https://apm-trace.us-sanjose-1.oci.oraclecloud.com',
    (Service.AUDIT, Region.AF_JOHANNESBURG_1): 'https://audit.af-johannesburg-1.oraclecloud.com',
    (Service.AUDIT, Region.AP_BATAM_1): 'https://audit.ap-batam-1.oraclecloud.com',
    (Service.AUDIT, Region.AP_CHUNCHEON_1): 'https://audit.ap-chuncheon-1.oraclecloud.com',
    (Service.AUDIT, Region.AP_HYDERABAD_1): 'https://audit.ap-hyderabad-1.oraclecloud.com',
    (Service.AUDIT, Region.AP_MELBOURNE_1): 'https://audit.ap-melbourne-1.oraclecloud.com',
    (Service.AUDIT, Region.AP_MUMBAI_1): 'https://audit.ap-mumbai-1.oraclecloud.com',
    (Service.AUDIT, Region.AP_OSAKA_1): 'https://audit.ap-osaka-1.oraclecloud.com',
    (Service.AUDIT, Region.AP_SEOUL_1): 'https://audit.ap-seoul-1.oraclecloud.com',
    (Service.AUDIT, Region.AP_SINGAPORE_1): 'https://audit.ap-singapore-1.oraclecloud.com',
    (Service.AUDIT, Region.AP_SINGAPORE_2): 'https://audit.ap-singapore-2.oraclecloud.com',
    (Service.AUDIT, Region.AP_SYDNEY_1): 'https://audit.ap-sydney-1.oraclecloud.com',
    (Service.AUDIT, Region.AP_TOKYO_1): 'https://audit.ap-tokyo-1.oraclecloud.com',
    (Service.AUDIT, Region.CA_MONTREAL_1): 'https://audit.ca-montreal-1.oraclecloud.com',
    (Service.AUDIT, Region.CA_TORONTO_1): 'https://audit.ca-toronto-1.oraclecloud.com',
    (Service.AUDIT, Region.EU_AMSTERDAM_1): 'https://audit.eu-amsterdam-1.oraclecloud.com',
    (Service.AUDIT, Region.EU_FRANKFURT_1): 'https://audit.eu-frankfurt-1.oraclecloud.com',
    (Service.AUDIT, Region.EU_JOVANOVAC_1): 'https://audit.eu-jovanovac-1.oraclecloud20.com',
    (Service.AUDIT, Region.EU_MADRID_1): 'https://audit.eu-madrid-1.oraclecloud.com',
    (Service.AUDIT, Region.EU_MADRID_3): 'https://audit.eu-madrid-3.oraclecloud.com',
    (Service.AUDIT, Region.EU_MARSEILLE_1): 'https://audit.eu-marseille-1.oraclecloud.com',
    (Service.AUDIT, Region.EU_MILAN_1): 'https://audit.eu-milan-1.oraclecloud.com',
    (Service.AUDIT, Region.EU_PARIS_1): 'https://audit.eu-paris-1.oraclecloud.com',
    (Service.AUDIT, Region.EU_STOCKHOLM_1): 'https://audit.eu-stockholm-1.oraclecloud.com',
    (Service.AUDIT, Region.EU_TURIN_1): 'https://audit.eu-turin-1.oraclecloud.com',
    (Service.AUDIT, Region.EU_ZURICH_1): 'https://audit.eu-zurich-1.oraclecloud.com',
    (Service.AUDIT, Region.IL_JERUSALEM_1): 'https://audit.il-jerusalem-1.oraclecloud.com',
    (Service.AUDIT, Region.ME_ABUDHABI_1): 'https://audit.me-abudhabi-1.oraclecloud.com',
    (Service.AUDIT, Region.ME_DUBAI_1): 'https://audit.me-dubai-1.oraclecloud.com',
    (Service.AUDIT, Region.ME_JEDDAH_1): 'https://audit.me-jeddah-1.oraclecloud.com',
    (Service.AUDIT, Region.ME_RIYADH_1): 'https://audit.me-riyadh-1.oraclecloud.com',
    (Service.AUDIT, Region.MX_MONTERREY_1): 'https://audit.mx-monterrey-1.oraclecloud.com',
    (Service.AUDIT, Region.MX_QUERETARO_1): 'https://audit.mx-queretaro-1.oraclecloud.com',
    (Service.AUDIT, Region.SA_BOGOTA_1): 'https://audit.sa-bogota-1.oraclecloud.com',
    (Service.AUDIT, Region.SA_SANTIAGO_1): 'https://audit.sa-santiago-1.oraclecloud.com',
    (Service.AUDIT, Region.SA_SAOPAULO_1): 'https://audit.sa-saopaulo-1.oraclecloud.com',
    (Service.AUDIT, Region.SA_VALPARAISO_1): 'https://audit.sa-valparaiso-1.oraclecloud.com',
    (Service.AUDIT, Region.SA_VINHEDO_1): 'https://audit.sa-vinhedo-1.oraclecloud.com',
    (Service.AUDIT, Region.UK_CARDIFF_1): 'https://audit.uk-cardiff-1.oraclecloud.com',
    (Service.AUDIT, Region.UK_LONDON_1): 'https://audit.uk-london-1.oraclecloud.com',
    (Service.AUDIT, Region.US_ASHBURN_1): 'https://audit.us-ashburn-1.oraclecloud.com',
    (Service.AUDIT, Region.US_CHICAGO_1): 'https://audit.us-chicago-1.oraclecloud.com',
    (Service.AUDIT, Region.US_PHOENIX_1): 'https://audit.us-phoenix-1.oraclecloud.com',
    (Service.AUDIT, Region.US_SANJOSE_1): 'https://audit.us-sanjose-1.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.AF_JOHANNESBURG_1,
    ): 'https://autoscaling.af-johannesburg-1.oci.oraclecloud.com',
    (Service.AUTOSCALING, Region.AP_BATAM_1): 'https://autoscaling.ap-batam-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.AP_CHUNCHEON_1,
    ): 'https://autoscaling.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.AP_HYDERABAD_1,
    ): 'https://autoscaling.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.AP_MELBOURNE_1,
    ): 'https://autoscaling.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.AP_MUMBAI_1,
    ): 'https://autoscaling.ap-mumbai-1.oci.oraclecloud.com',
    (Service.AUTOSCALING, Region.AP_OSAKA_1): 'https://autoscaling.ap-osaka-1.oci.oraclecloud.com',
    (Service.AUTOSCALING, Region.AP_SEOUL_1): 'https://autoscaling.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.AP_SINGAPORE_1,
    ): 'https://autoscaling.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.AP_SINGAPORE_2,
    ): 'https://autoscaling.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.AP_SYDNEY_1,
    ): 'https://autoscaling.ap-sydney-1.oci.oraclecloud.com',
    (Service.AUTOSCALING, Region.AP_TOKYO_1): 'https://autoscaling.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.CA_MONTREAL_1,
    ): 'https://autoscaling.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.CA_TORONTO_1,
    ): 'https://autoscaling.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.EU_AMSTERDAM_1,
    ): 'https://autoscaling.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.EU_FRANKFURT_1,
    ): 'https://autoscaling.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.EU_JOVANOVAC_1,
    ): 'https://autoscaling.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.AUTOSCALING,
        Region.EU_MADRID_1,
    ): 'https://autoscaling.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.EU_MADRID_3,
    ): 'https://autoscaling.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.EU_MARSEILLE_1,
    ): 'https://autoscaling.eu-marseille-1.oci.oraclecloud.com',
    (Service.AUTOSCALING, Region.EU_MILAN_1): 'https://autoscaling.eu-milan-1.oci.oraclecloud.com',
    (Service.AUTOSCALING, Region.EU_PARIS_1): 'https://autoscaling.eu-paris-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.EU_STOCKHOLM_1,
    ): 'https://autoscaling.eu-stockholm-1.oci.oraclecloud.com',
    (Service.AUTOSCALING, Region.EU_TURIN_1): 'https://autoscaling.eu-turin-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.EU_ZURICH_1,
    ): 'https://autoscaling.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.IL_JERUSALEM_1,
    ): 'https://autoscaling.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.ME_ABUDHABI_1,
    ): 'https://autoscaling.me-abudhabi-1.oci.oraclecloud.com',
    (Service.AUTOSCALING, Region.ME_DUBAI_1): 'https://autoscaling.me-dubai-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.ME_JEDDAH_1,
    ): 'https://autoscaling.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.ME_RIYADH_1,
    ): 'https://autoscaling.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.MX_MONTERREY_1,
    ): 'https://autoscaling.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.MX_QUERETARO_1,
    ): 'https://autoscaling.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.SA_BOGOTA_1,
    ): 'https://autoscaling.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.SA_SANTIAGO_1,
    ): 'https://autoscaling.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.SA_SAOPAULO_1,
    ): 'https://autoscaling.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.SA_VALPARAISO_1,
    ): 'https://autoscaling.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.SA_VINHEDO_1,
    ): 'https://autoscaling.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.UK_CARDIFF_1,
    ): 'https://autoscaling.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.UK_LONDON_1,
    ): 'https://autoscaling.uk-london-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.US_ASHBURN_1,
    ): 'https://autoscaling.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.US_CHICAGO_1,
    ): 'https://autoscaling.us-chicago-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.US_PHOENIX_1,
    ): 'https://autoscaling.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.AUTOSCALING,
        Region.US_SANJOSE_1,
    ): 'https://autoscaling.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.BASTION,
        Region.AF_JOHANNESBURG_1,
    ): 'https://bastion.af-johannesburg-1.oci.oraclecloud.com',
    (Service.BASTION, Region.AP_BATAM_1): 'https://bastion.ap-batam-1.oci.oraclecloud.com',
    (Service.BASTION, Region.AP_CHUNCHEON_1): 'https://bastion.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.BASTION, Region.AP_HYDERABAD_1): 'https://bastion.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.BASTION, Region.AP_MELBOURNE_1): 'https://bastion.ap-melbourne-1.oci.oraclecloud.com',
    (Service.BASTION, Region.AP_MUMBAI_1): 'https://bastion.ap-mumbai-1.oci.oraclecloud.com',
    (Service.BASTION, Region.AP_OSAKA_1): 'https://bastion.ap-osaka-1.oci.oraclecloud.com',
    (Service.BASTION, Region.AP_SEOUL_1): 'https://bastion.ap-seoul-1.oci.oraclecloud.com',
    (Service.BASTION, Region.AP_SINGAPORE_1): 'https://bastion.ap-singapore-1.oci.oraclecloud.com',
    (Service.BASTION, Region.AP_SINGAPORE_2): 'https://bastion.ap-singapore-2.oci.oraclecloud.com',
    (Service.BASTION, Region.AP_SYDNEY_1): 'https://bastion.ap-sydney-1.oci.oraclecloud.com',
    (Service.BASTION, Region.AP_TOKYO_1): 'https://bastion.ap-tokyo-1.oci.oraclecloud.com',
    (Service.BASTION, Region.CA_MONTREAL_1): 'https://bastion.ca-montreal-1.oci.oraclecloud.com',
    (Service.BASTION, Region.CA_TORONTO_1): 'https://bastion.ca-toronto-1.oci.oraclecloud.com',
    (Service.BASTION, Region.EU_AMSTERDAM_1): 'https://bastion.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.BASTION, Region.EU_FRANKFURT_1): 'https://bastion.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.BASTION,
        Region.EU_JOVANOVAC_1,
    ): 'https://bastion.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.BASTION, Region.EU_MADRID_1): 'https://bastion.eu-madrid-1.oci.oraclecloud.com',
    (Service.BASTION, Region.EU_MADRID_3): 'https://bastion.eu-madrid-3.oci.oraclecloud.com',
    (Service.BASTION, Region.EU_MARSEILLE_1): 'https://bastion.eu-marseille-1.oci.oraclecloud.com',
    (Service.BASTION, Region.EU_MILAN_1): 'https://bastion.eu-milan-1.oci.oraclecloud.com',
    (Service.BASTION, Region.EU_PARIS_1): 'https://bastion.eu-paris-1.oci.oraclecloud.com',
    (Service.BASTION, Region.EU_STOCKHOLM_1): 'https://bastion.eu-stockholm-1.oci.oraclecloud.com',
    (Service.BASTION, Region.EU_TURIN_1): 'https://bastion.eu-turin-1.oci.oraclecloud.com',
    (Service.BASTION, Region.EU_ZURICH_1): 'https://bastion.eu-zurich-1.oci.oraclecloud.com',
    (Service.BASTION, Region.IL_JERUSALEM_1): 'https://bastion.il-jerusalem-1.oraclecloud.com',
    (Service.BASTION, Region.ME_ABUDHABI_1): 'https://bastion.me-abudhabi-1.oraclecloud.com',
    (Service.BASTION, Region.ME_DUBAI_1): 'https://bastion.me-dubai-1.oraclecloud.com',
    (Service.BASTION, Region.ME_JEDDAH_1): 'https://bastion.me-jeddah-1.oci.oraclecloud.com',
    (Service.BASTION, Region.ME_RIYADH_1): 'https://bastion.me-riyadh-1.oci.oraclecloud.com',
    (Service.BASTION, Region.MX_MONTERREY_1): 'https://bastion.mx-monterrey-1.oci.oraclecloud.com',
    (Service.BASTION, Region.MX_QUERETARO_1): 'https://bastion.mx-queretaro-1.oci.oraclecloud.com',
    (Service.BASTION, Region.SA_BOGOTA_1): 'https://bastion.sa-bogota-1.oraclecloud.com',
    (Service.BASTION, Region.SA_SANTIAGO_1): 'https://bastion.sa-santiago-1.oraclecloud.com',
    (Service.BASTION, Region.SA_SAOPAULO_1): 'https://bastion.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.BASTION,
        Region.SA_VALPARAISO_1,
    ): 'https://bastion.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.BASTION, Region.SA_VINHEDO_1): 'https://bastion.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.BASTION, Region.UK_CARDIFF_1): 'https://bastion.uk-cardiff-1.oraclecloud.com',
    (Service.BASTION, Region.UK_LONDON_1): 'https://bastion.uk-london-1.oci.oraclecloud.com',
    (Service.BASTION, Region.US_ASHBURN_1): 'https://bastion.us-ashburn-1.oci.oraclecloud.com',
    (Service.BASTION, Region.US_CHICAGO_1): 'https://bastion.us-chicago-1.oci.oraclecloud.com',
    (Service.BASTION, Region.US_PHOENIX_1): 'https://bastion.us-phoenix-1.oci.oraclecloud.com',
    (Service.BASTION, Region.US_SANJOSE_1): 'https://bastion.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.BIGDATA,
        Region.AF_JOHANNESBURG_1,
    ): 'https://bigdataservice.af-johannesburg-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.AP_BATAM_1,
    ): 'https://bigdataservice.ap-batam-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.AP_CHUNCHEON_1,
    ): 'https://bigdataservice.ap-chuncheon-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.AP_HYDERABAD_1,
    ): 'https://bigdataservice.ap-hyderabad-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.AP_MELBOURNE_1,
    ): 'https://bigdataservice.ap-melbourne-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.AP_MUMBAI_1,
    ): 'https://bigdataservice.ap-mumbai-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.AP_OSAKA_1,
    ): 'https://bigdataservice.ap-osaka-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.AP_SEOUL_1,
    ): 'https://bigdataservice.ap-seoul-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.AP_SINGAPORE_1,
    ): 'https://bigdataservice.ap-singapore-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.AP_SINGAPORE_2,
    ): 'https://bigdataservice.ap-singapore-2.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.AP_SYDNEY_1,
    ): 'https://bigdataservice.ap-sydney-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.AP_TOKYO_1,
    ): 'https://bigdataservice.ap-tokyo-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.CA_MONTREAL_1,
    ): 'https://bigdataservice.ca-montreal-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.CA_TORONTO_1,
    ): 'https://bigdataservice.ca-toronto-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.EU_AMSTERDAM_1,
    ): 'https://bigdataservice.eu-amsterdam-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.EU_FRANKFURT_1,
    ): 'https://bigdataservice.eu-frankfurt-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.EU_JOVANOVAC_1,
    ): 'https://bigdataservice.eu-jovanovac-1.oci.oraclecloud20.com/20190531',
    (
        Service.BIGDATA,
        Region.EU_MADRID_1,
    ): 'https://bigdataservice.eu-madrid-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.EU_MADRID_3,
    ): 'https://bigdataservice.eu-madrid-3.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.EU_MARSEILLE_1,
    ): 'https://bigdataservice.eu-marseille-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.EU_MILAN_1,
    ): 'https://bigdataservice.eu-milan-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.EU_STOCKHOLM_1,
    ): 'https://bigdataservice.eu-stockholm-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.EU_TURIN_1,
    ): 'https://bigdataservice.eu-turin-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.EU_ZURICH_1,
    ): 'https://bigdataservice.eu-zurich-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.ME_DUBAI_1,
    ): 'https://bigdataservice.me-dubai-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.ME_JEDDAH_1,
    ): 'https://bigdataservice.me-jeddah-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.ME_RIYADH_1,
    ): 'https://bigdataservice.me-riyadh-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.MX_MONTERREY_1,
    ): 'https://bigdataservice.mx-monterrey-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.MX_QUERETARO_1,
    ): 'https://bigdataservice.mx-queretaro-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.SA_BOGOTA_1,
    ): 'https://bigdataservice.sa-bogota-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.SA_SANTIAGO_1,
    ): 'https://bigdataservice.sa-santiago-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.SA_SAOPAULO_1,
    ): 'https://bigdataservice.sa-saopaulo-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.SA_VALPARAISO_1,
    ): 'https://bigdataservice.sa-valparaiso-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.SA_VINHEDO_1,
    ): 'https://bigdataservice.sa-vinhedo-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.UK_CARDIFF_1,
    ): 'https://bigdataservice.uk-cardiff-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.UK_LONDON_1,
    ): 'https://bigdataservice.uk-london-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.US_ASHBURN_1,
    ): 'https://bigdataservice.us-ashburn-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.US_PHOENIX_1,
    ): 'https://bigdataservice.us-phoenix-1.oci.oraclecloud.com/20190531',
    (
        Service.BIGDATA,
        Region.US_SANJOSE_1,
    ): 'https://bigdataservice.us-sanjose-1.oci.oraclecloud.com/20190531',
    (
        Service.BLOCKCHAIN,
        Region.AP_HYDERABAD_1,
    ): 'https://blockchain.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.BLOCKCHAIN, Region.AP_MUMBAI_1): 'https://blockchain.ap-mumbai-1.oci.oraclecloud.com',
    (Service.BLOCKCHAIN, Region.AP_OSAKA_1): 'https://blockchain.ap-osaka-1.oci.oraclecloud.com',
    (Service.BLOCKCHAIN, Region.AP_SEOUL_1): 'https://blockchain.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.AP_SINGAPORE_1,
    ): 'https://blockchain.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.AP_SINGAPORE_2,
    ): 'https://blockchain.ap-singapore-2.oci.oraclecloud.com',
    (Service.BLOCKCHAIN, Region.AP_SYDNEY_1): 'https://blockchain.ap-sydney-1.oci.oraclecloud.com',
    (Service.BLOCKCHAIN, Region.AP_TOKYO_1): 'https://blockchain.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.CA_MONTREAL_1,
    ): 'https://blockchain.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.CA_TORONTO_1,
    ): 'https://blockchain.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.EU_FRANKFURT_1,
    ): 'https://blockchain.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.EU_MARSEILLE_1,
    ): 'https://blockchain.eu-marseille-1.oci.oraclecloud.com',
    (Service.BLOCKCHAIN, Region.EU_MILAN_1): 'https://blockchain.eu-milan-1.oci.oraclecloud.com',
    (Service.BLOCKCHAIN, Region.EU_PARIS_1): 'https://blockchain.eu-paris-1.oci.oraclecloud.com',
    (Service.BLOCKCHAIN, Region.EU_ZURICH_1): 'https://blockchain.eu-zurich-1.oci.oraclecloud.com',
    (Service.BLOCKCHAIN, Region.ME_DUBAI_1): 'https://blockchain.me-dubai-1.oci.oraclecloud.com',
    (Service.BLOCKCHAIN, Region.ME_JEDDAH_1): 'https://blockchain.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.MX_QUERETARO_1,
    ): 'https://blockchain.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.SA_SANTIAGO_1,
    ): 'https://blockchain.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.SA_SAOPAULO_1,
    ): 'https://blockchain.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.BLOCKCHAIN, Region.UK_LONDON_1): 'https://blockchain.uk-london-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.US_ASHBURN_1,
    ): 'https://blockchain.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.US_CHICAGO_1,
    ): 'https://blockchain.us-chicago-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.US_PHOENIX_1,
    ): 'https://blockchain.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.BLOCKCHAIN,
        Region.US_SANJOSE_1,
    ): 'https://blockchain.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.BUDGETS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://usage.af-johannesburg-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.AP_BATAM_1): 'https://usage.ap-batam-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.AP_CHUNCHEON_1): 'https://usage.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.AP_HYDERABAD_1): 'https://usage.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.AP_MELBOURNE_1): 'https://usage.ap-melbourne-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.AP_MUMBAI_1): 'https://usage.ap-mumbai-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.AP_OSAKA_1): 'https://usage.ap-osaka-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.AP_SEOUL_1): 'https://usage.ap-seoul-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.AP_SINGAPORE_1): 'https://usage.ap-singapore-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.AP_SYDNEY_1): 'https://usage.ap-sydney-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.AP_TOKYO_1): 'https://usage.ap-tokyo-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.CA_MONTREAL_1): 'https://usage.ca-montreal-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.CA_TORONTO_1): 'https://usage.ca-toronto-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.EU_AMSTERDAM_1): 'https://usage.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.EU_FRANKFURT_1): 'https://usage.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.EU_JOVANOVAC_1): 'https://usage.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.BUDGETS, Region.EU_MADRID_1): 'https://usage.eu-madrid-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.EU_MADRID_3): 'https://usage.eu-madrid-3.oci.oraclecloud.com',
    (Service.BUDGETS, Region.EU_MARSEILLE_1): 'https://usage.eu-marseille-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.EU_MILAN_1): 'https://usage.eu-milan-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.EU_PARIS_1): 'https://usage.eu-paris-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.EU_STOCKHOLM_1): 'https://usage.eu-stockholm-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.EU_TURIN_1): 'https://usage.eu-turin-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.EU_ZURICH_1): 'https://usage.eu-zurich-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.IL_JERUSALEM_1): 'https://usage.il-jerusalem-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.ME_ABUDHABI_1): 'https://usage.me-abudhabi-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.ME_DUBAI_1): 'https://usage.me-dubai-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.ME_JEDDAH_1): 'https://usage.me-jeddah-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.ME_RIYADH_1): 'https://usage.me-riyadh-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.MX_MONTERREY_1): 'https://usage.mx-monterrey-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.MX_QUERETARO_1): 'https://usage.mx-queretaro-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.SA_BOGOTA_1): 'https://usage.sa-bogota-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.SA_SANTIAGO_1): 'https://usage.sa-santiago-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.SA_SAOPAULO_1): 'https://usage.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.SA_VALPARAISO_1): 'https://usage.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.SA_VINHEDO_1): 'https://usage.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.UK_CARDIFF_1): 'https://usage.uk-cardiff-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.UK_LONDON_1): 'https://usage.uk-london-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.US_ASHBURN_1): 'https://usage.us-ashburn-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.US_PHOENIX_1): 'https://usage.us-phoenix-1.oci.oraclecloud.com',
    (Service.BUDGETS, Region.US_SANJOSE_1): 'https://usage.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AF_JOHANNESBURG_1,
    ): 'https://certificates.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AP_BATAM_1,
    ): 'https://certificates.ap-batam-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AP_CHUNCHEON_1,
    ): 'https://certificates.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AP_HYDERABAD_1,
    ): 'https://certificates.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AP_MELBOURNE_1,
    ): 'https://certificates.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AP_MUMBAI_1,
    ): 'https://certificates.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AP_OSAKA_1,
    ): 'https://certificates.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AP_SEOUL_1,
    ): 'https://certificates.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AP_SINGAPORE_1,
    ): 'https://certificates.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AP_SINGAPORE_2,
    ): 'https://certificates.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AP_SYDNEY_1,
    ): 'https://certificates.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.AP_TOKYO_1,
    ): 'https://certificates.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.CA_MONTREAL_1,
    ): 'https://certificates.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.CA_TORONTO_1,
    ): 'https://certificates.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.EU_AMSTERDAM_1,
    ): 'https://certificates.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.EU_FRANKFURT_1,
    ): 'https://certificates.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.EU_JOVANOVAC_1,
    ): 'https://certificates.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.CERTIFICATES,
        Region.EU_MADRID_1,
    ): 'https://certificates.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.EU_MADRID_3,
    ): 'https://certificates.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.EU_MARSEILLE_1,
    ): 'https://certificates.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.EU_MILAN_1,
    ): 'https://certificates.eu-milan-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.EU_PARIS_1,
    ): 'https://certificates.eu-paris-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.EU_STOCKHOLM_1,
    ): 'https://certificates.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.EU_TURIN_1,
    ): 'https://certificates.eu-turin-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.EU_ZURICH_1,
    ): 'https://certificates.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.IL_JERUSALEM_1,
    ): 'https://certificates.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.ME_ABUDHABI_1,
    ): 'https://certificates.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.ME_DUBAI_1,
    ): 'https://certificates.me-dubai-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.ME_JEDDAH_1,
    ): 'https://certificates.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.ME_RIYADH_1,
    ): 'https://certificates.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.MX_MONTERREY_1,
    ): 'https://certificates.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.MX_QUERETARO_1,
    ): 'https://certificates.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.SA_BOGOTA_1,
    ): 'https://certificates.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.SA_SANTIAGO_1,
    ): 'https://certificates.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.SA_SAOPAULO_1,
    ): 'https://certificates.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.SA_VALPARAISO_1,
    ): 'https://certificates.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.SA_VINHEDO_1,
    ): 'https://certificates.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.UK_CARDIFF_1,
    ): 'https://certificates.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.UK_LONDON_1,
    ): 'https://certificates.uk-london-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.US_ASHBURN_1,
    ): 'https://certificates.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.US_CHICAGO_1,
    ): 'https://certificates.us-chicago-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.US_PHOENIX_1,
    ): 'https://certificates.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATES,
        Region.US_SANJOSE_1,
    ): 'https://certificates.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AF_JOHANNESBURG_1,
    ): 'https://certificatesmanagement.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AP_BATAM_1,
    ): 'https://certificatesmanagement.ap-batam-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AP_CHUNCHEON_1,
    ): 'https://certificatesmanagement.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AP_HYDERABAD_1,
    ): 'https://certificatesmanagement.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AP_MELBOURNE_1,
    ): 'https://certificatesmanagement.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AP_MUMBAI_1,
    ): 'https://certificatesmanagement.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AP_OSAKA_1,
    ): 'https://certificatesmanagement.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AP_SEOUL_1,
    ): 'https://certificatesmanagement.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AP_SINGAPORE_1,
    ): 'https://certificatesmanagement.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AP_SINGAPORE_2,
    ): 'https://certificatesmanagement.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AP_SYDNEY_1,
    ): 'https://certificatesmanagement.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.AP_TOKYO_1,
    ): 'https://certificatesmanagement.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.CA_MONTREAL_1,
    ): 'https://certificatesmanagement.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.CA_TORONTO_1,
    ): 'https://certificatesmanagement.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.EU_AMSTERDAM_1,
    ): 'https://certificatesmanagement.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.EU_FRANKFURT_1,
    ): 'https://certificatesmanagement.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.EU_JOVANOVAC_1,
    ): 'https://certificatesmanagement.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.CERTIFICATESMGMT,
        Region.EU_MADRID_1,
    ): 'https://certificatesmanagement.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.EU_MADRID_3,
    ): 'https://certificatesmanagement.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.EU_MARSEILLE_1,
    ): 'https://certificatesmanagement.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.EU_MILAN_1,
    ): 'https://certificatesmanagement.eu-milan-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.EU_PARIS_1,
    ): 'https://certificatesmanagement.eu-paris-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.EU_STOCKHOLM_1,
    ): 'https://certificatesmanagement.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.EU_TURIN_1,
    ): 'https://certificatesmanagement.eu-turin-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.EU_ZURICH_1,
    ): 'https://certificatesmanagement.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.IL_JERUSALEM_1,
    ): 'https://certificatesmanagement.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.ME_ABUDHABI_1,
    ): 'https://certificatesmanagement.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.ME_DUBAI_1,
    ): 'https://certificatesmanagement.me-dubai-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.ME_JEDDAH_1,
    ): 'https://certificatesmanagement.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.ME_RIYADH_1,
    ): 'https://certificatesmanagement.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.MX_MONTERREY_1,
    ): 'https://certificatesmanagement.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.MX_QUERETARO_1,
    ): 'https://certificatesmanagement.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.SA_BOGOTA_1,
    ): 'https://certificatesmanagement.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.SA_SANTIAGO_1,
    ): 'https://certificatesmanagement.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.SA_SAOPAULO_1,
    ): 'https://certificatesmanagement.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.SA_VALPARAISO_1,
    ): 'https://certificatesmanagement.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.SA_VINHEDO_1,
    ): 'https://certificatesmanagement.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.UK_CARDIFF_1,
    ): 'https://certificatesmanagement.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.UK_LONDON_1,
    ): 'https://certificatesmanagement.uk-london-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.US_ASHBURN_1,
    ): 'https://certificatesmanagement.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.US_CHICAGO_1,
    ): 'https://certificatesmanagement.us-chicago-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.US_PHOENIX_1,
    ): 'https://certificatesmanagement.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.CERTIFICATESMGMT,
        Region.US_SANJOSE_1,
    ): 'https://certificatesmanagement.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.AF_JOHANNESBURG_1,
    ): 'https://cloudguard-cp-api.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.AP_BATAM_1,
    ): 'https://cloudguard-cp-api.ap-batam-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.AP_CHUNCHEON_1,
    ): 'https://cloudguard-cp-api.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.CLOUDGUARD_CP_API,
    ): 'https://cloudguard-cp-api.ap-dcc-canberra-1.oci.oraclecloud10.com',
    (
        Service.CLOUD_GUARD,
        Region.AP_HYDERABAD_1,
    ): 'https://cloudguard-cp-api.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.AP_MELBOURNE_1,
    ): 'https://cloudguard-cp-api.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.AP_MUMBAI_1,
    ): 'https://cloudguard-cp-api.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.AP_OSAKA_1,
    ): 'https://cloudguard-cp-api.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.AP_SEOUL_1,
    ): 'https://cloudguard-cp-api.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.AP_SINGAPORE_1,
    ): 'https://cloudguard-cp-api.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.AP_SINGAPORE_2,
    ): 'https://cloudguard-cp-api.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.AP_SYDNEY_1,
    ): 'https://cloudguard-cp-api.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.AP_TOKYO_1,
    ): 'https://cloudguard-cp-api.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.CA_MONTREAL_1,
    ): 'https://cloudguard-cp-api.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.CA_TORONTO_1,
    ): 'https://cloudguard-cp-api.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.EU_AMSTERDAM_1,
    ): 'https://cloudguard-cp-api.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.EU_FRANKFURT_1,
    ): 'https://cloudguard-cp-api.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.EU_JOVANOVAC_1,
    ): 'https://cloudguard-cp-api.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.CLOUD_GUARD,
        Region.EU_MADRID_1,
    ): 'https://cloudguard-cp-api.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.EU_MADRID_3,
    ): 'https://cloudguard-cp-api.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.EU_MARSEILLE_1,
    ): 'https://cloudguard-cp-api.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.EU_MILAN_1,
    ): 'https://cloudguard-cp-api.eu-milan-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.EU_PARIS_1,
    ): 'https://cloudguard-cp-api.eu-paris-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.EU_STOCKHOLM_1,
    ): 'https://cloudguard-cp-api.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.EU_TURIN_1,
    ): 'https://cloudguard-cp-api.eu-turin-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.EU_ZURICH_1,
    ): 'https://cloudguard-cp-api.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.IL_JERUSALEM_1,
    ): 'https://cloudguard-cp-api.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.ME_ABUDHABI_1,
    ): 'https://cloudguard-cp-api.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.ME_DUBAI_1,
    ): 'https://cloudguard-cp-api.me-dubai-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.ME_JEDDAH_1,
    ): 'https://cloudguard-cp-api.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.ME_RIYADH_1,
    ): 'https://cloudguard-cp-api.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.MX_MONTERREY_1,
    ): 'https://cloudguard-cp-api.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.MX_QUERETARO_1,
    ): 'https://cloudguard-cp-api.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.SA_BOGOTA_1,
    ): 'https://cloudguard-cp-api.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.SA_SANTIAGO_1,
    ): 'https://cloudguard-cp-api.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.SA_SAOPAULO_1,
    ): 'https://cloudguard-cp-api.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.SA_VALPARAISO_1,
    ): 'https://cloudguard-cp-api.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.SA_VINHEDO_1,
    ): 'https://cloudguard-cp-api.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.UK_CARDIFF_1,
    ): 'https://cloudguard-cp-api.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.UK_LONDON_1,
    ): 'https://cloudguard-cp-api.uk-london-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.US_ASHBURN_1,
    ): 'https://cloudguard-cp-api.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.US_CHICAGO_1,
    ): 'https://cloudguard-cp-api.us-chicago-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.US_PHOENIX_1,
    ): 'https://cloudguard-cp-api.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.CLOUD_GUARD,
        Region.US_SANJOSE_1,
    ): 'https://cloudguard-cp-api.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://clusterplacementgroups.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AP_BATAM_1,
    ): 'https://clusterplacementgroups.ap-batam-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AP_CHUNCHEON_1,
    ): 'https://clusterplacementgroups.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AP_HYDERABAD_1,
    ): 'https://clusterplacementgroups.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AP_MELBOURNE_1,
    ): 'https://clusterplacementgroups.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AP_MUMBAI_1,
    ): 'https://clusterplacementgroups.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AP_OSAKA_1,
    ): 'https://clusterplacementgroups.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AP_SEOUL_1,
    ): 'https://clusterplacementgroups.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AP_SINGAPORE_1,
    ): 'https://clusterplacementgroups.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AP_SINGAPORE_2,
    ): 'https://clusterplacementgroups.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AP_SYDNEY_1,
    ): 'https://clusterplacementgroups.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.AP_TOKYO_1,
    ): 'https://clusterplacementgroups.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.CA_MONTREAL_1,
    ): 'https://clusterplacementgroups.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.CA_TORONTO_1,
    ): 'https://clusterplacementgroups.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.EU_AMSTERDAM_1,
    ): 'https://clusterplacementgroups.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.EU_FRANKFURT_1,
    ): 'https://clusterplacementgroups.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.EU_JOVANOVAC_1,
    ): 'https://clusterplacementgroups.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.EU_MADRID_1,
    ): 'https://clusterplacementgroups.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.EU_MADRID_3,
    ): 'https://clusterplacementgroups.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.EU_MARSEILLE_1,
    ): 'https://clusterplacementgroups.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.EU_MILAN_1,
    ): 'https://clusterplacementgroups.eu-milan-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.EU_PARIS_1,
    ): 'https://clusterplacementgroups.eu-paris-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.EU_STOCKHOLM_1,
    ): 'https://clusterplacementgroups.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.EU_TURIN_1,
    ): 'https://clusterplacementgroups.eu-turin-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.EU_ZURICH_1,
    ): 'https://clusterplacementgroups.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.IL_JERUSALEM_1,
    ): 'https://clusterplacementgroups.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.ME_ABUDHABI_1,
    ): 'https://clusterplacementgroups.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.ME_DUBAI_1,
    ): 'https://clusterplacementgroups.me-dubai-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.ME_JEDDAH_1,
    ): 'https://clusterplacementgroups.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.ME_RIYADH_1,
    ): 'https://clusterplacementgroups.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.MX_MONTERREY_1,
    ): 'https://clusterplacementgroups.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.MX_QUERETARO_1,
    ): 'https://clusterplacementgroups.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.SA_BOGOTA_1,
    ): 'https://clusterplacementgroups.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.SA_SANTIAGO_1,
    ): 'https://clusterplacementgroups.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.SA_SAOPAULO_1,
    ): 'https://clusterplacementgroups.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.SA_VALPARAISO_1,
    ): 'https://clusterplacementgroups.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.SA_VINHEDO_1,
    ): 'https://clusterplacementgroups.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.UK_CARDIFF_1,
    ): 'https://clusterplacementgroups.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.UK_LONDON_1,
    ): 'https://clusterplacementgroups.uk-london-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.US_ASHBURN_1,
    ): 'https://clusterplacementgroups.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.US_CHICAGO_1,
    ): 'https://clusterplacementgroups.us-chicago-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.US_PHOENIX_1,
    ): 'https://clusterplacementgroups.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.CLUSTERPLACEMENTGROUPS,
        Region.US_SANJOSE_1,
    ): 'https://clusterplacementgroups.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AF_JOHANNESBURG_1,
    ): 'https://ccc.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AP_BATAM_1,
    ): 'https://ccc.ap-batam-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AP_CHUNCHEON_1,
    ): 'https://ccc.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AP_HYDERABAD_1,
    ): 'https://ccc.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AP_MELBOURNE_1,
    ): 'https://ccc.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AP_MUMBAI_1,
    ): 'https://ccc.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AP_OSAKA_1,
    ): 'https://ccc.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AP_SEOUL_1,
    ): 'https://ccc.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AP_SINGAPORE_1,
    ): 'https://ccc.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AP_SINGAPORE_2,
    ): 'https://ccc.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AP_SYDNEY_1,
    ): 'https://ccc.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.AP_TOKYO_1,
    ): 'https://ccc.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.CA_MONTREAL_1,
    ): 'https://ccc.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.CA_TORONTO_1,
    ): 'https://ccc.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.EU_AMSTERDAM_1,
    ): 'https://ccc.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.EU_FRANKFURT_1,
    ): 'https://ccc.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.EU_MADRID_1,
    ): 'https://ccc.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.EU_MADRID_3,
    ): 'https://ccc.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.EU_MARSEILLE_1,
    ): 'https://ccc.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.EU_MILAN_1,
    ): 'https://ccc.eu-milan-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.EU_PARIS_1,
    ): 'https://ccc.eu-paris-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.EU_STOCKHOLM_1,
    ): 'https://ccc.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.EU_TURIN_1,
    ): 'https://ccc.eu-turin-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.EU_ZURICH_1,
    ): 'https://ccc.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.IL_JERUSALEM_1,
    ): 'https://ccc.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.ME_ABUDHABI_1,
    ): 'https://ccc.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.ME_DUBAI_1,
    ): 'https://ccc.me-dubai-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.ME_JEDDAH_1,
    ): 'https://ccc.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.ME_RIYADH_1,
    ): 'https://ccc.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.MX_MONTERREY_1,
    ): 'https://ccc.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.MX_QUERETARO_1,
    ): 'https://ccc.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.SA_BOGOTA_1,
    ): 'https://ccc.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.SA_SANTIAGO_1,
    ): 'https://ccc.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.SA_SAOPAULO_1,
    ): 'https://ccc.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.SA_VALPARAISO_1,
    ): 'https://ccc.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.SA_VINHEDO_1,
    ): 'https://ccc.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.UK_CARDIFF_1,
    ): 'https://ccc.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.UK_LONDON_1,
    ): 'https://ccc.uk-london-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.US_ASHBURN_1,
    ): 'https://ccc.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.US_CHICAGO_1,
    ): 'https://ccc.us-chicago-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.US_PHOENIX_1,
    ): 'https://ccc.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.COMPUTE_CLOUD_AT_CUSTOMER,
        Region.US_SANJOSE_1,
    ): 'https://ccc.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AF_JOHANNESBURG_1,
    ): 'https://compute-containers.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AP_BATAM_1,
    ): 'https://compute-containers.ap-batam-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AP_CHUNCHEON_1,
    ): 'https://compute-containers.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AP_HYDERABAD_1,
    ): 'https://compute-containers.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AP_MELBOURNE_1,
    ): 'https://compute-containers.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AP_MUMBAI_1,
    ): 'https://compute-containers.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AP_OSAKA_1,
    ): 'https://compute-containers.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AP_SEOUL_1,
    ): 'https://compute-containers.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AP_SINGAPORE_1,
    ): 'https://compute-containers.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AP_SINGAPORE_2,
    ): 'https://compute-containers.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AP_SYDNEY_1,
    ): 'https://compute-containers.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.AP_TOKYO_1,
    ): 'https://compute-containers.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.CA_MONTREAL_1,
    ): 'https://compute-containers.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.CA_TORONTO_1,
    ): 'https://compute-containers.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.EU_AMSTERDAM_1,
    ): 'https://compute-containers.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.EU_FRANKFURT_1,
    ): 'https://compute-containers.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.EU_JOVANOVAC_1,
    ): 'https://compute-containers.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.EU_MADRID_1,
    ): 'https://compute-containers.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.EU_MADRID_3,
    ): 'https://compute-containers.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.EU_MARSEILLE_1,
    ): 'https://compute-containers.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.EU_MILAN_1,
    ): 'https://compute-containers.eu-milan-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.EU_PARIS_1,
    ): 'https://compute-containers.eu-paris-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.EU_STOCKHOLM_1,
    ): 'https://compute-containers.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.EU_TURIN_1,
    ): 'https://compute-containers.eu-turin-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.EU_ZURICH_1,
    ): 'https://compute-containers.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.IL_JERUSALEM_1,
    ): 'https://compute-containers.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.ME_ABUDHABI_1,
    ): 'https://compute-containers.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.ME_DUBAI_1,
    ): 'https://compute-containers.me-dubai-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.ME_JEDDAH_1,
    ): 'https://compute-containers.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.ME_RIYADH_1,
    ): 'https://compute-containers.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.MX_MONTERREY_1,
    ): 'https://compute-containers.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.MX_QUERETARO_1,
    ): 'https://compute-containers.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.SA_BOGOTA_1,
    ): 'https://compute-containers.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.SA_SANTIAGO_1,
    ): 'https://compute-containers.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.SA_SAOPAULO_1,
    ): 'https://compute-containers.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.SA_VALPARAISO_1,
    ): 'https://compute-containers.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.SA_VINHEDO_1,
    ): 'https://compute-containers.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.UK_CARDIFF_1,
    ): 'https://compute-containers.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.UK_LONDON_1,
    ): 'https://compute-containers.uk-london-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.US_ASHBURN_1,
    ): 'https://compute-containers.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.US_PHOENIX_1,
    ): 'https://compute-containers.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.CONTAINER_INSTANCES,
        Region.US_SANJOSE_1,
    ): 'https://compute-containers.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://containerengine.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AP_BATAM_1,
    ): 'https://containerengine.ap-batam-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AP_CHUNCHEON_1,
    ): 'https://containerengine.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AP_HYDERABAD_1,
    ): 'https://containerengine.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AP_MELBOURNE_1,
    ): 'https://containerengine.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AP_MUMBAI_1,
    ): 'https://containerengine.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AP_OSAKA_1,
    ): 'https://containerengine.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AP_SEOUL_1,
    ): 'https://containerengine.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AP_SINGAPORE_1,
    ): 'https://containerengine.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AP_SINGAPORE_2,
    ): 'https://containerengine.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AP_SYDNEY_1,
    ): 'https://containerengine.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.AP_TOKYO_1,
    ): 'https://containerengine.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.CA_MONTREAL_1,
    ): 'https://containerengine.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.CA_TORONTO_1,
    ): 'https://containerengine.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.EU_AMSTERDAM_1,
    ): 'https://containerengine.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.EU_FRANKFURT_1,
    ): 'https://containerengine.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.EU_JOVANOVAC_1,
    ): 'https://containerengine.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.CONTAINERENGINE,
        Region.EU_MADRID_1,
    ): 'https://containerengine.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.EU_MADRID_3,
    ): 'https://containerengine.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.EU_MARSEILLE_1,
    ): 'https://containerengine.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.EU_MILAN_1,
    ): 'https://containerengine.eu-milan-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.EU_PARIS_1,
    ): 'https://containerengine.eu-paris-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.EU_STOCKHOLM_1,
    ): 'https://containerengine.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.EU_TURIN_1,
    ): 'https://containerengine.eu-turin-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.EU_ZURICH_1,
    ): 'https://containerengine.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.IL_JERUSALEM_1,
    ): 'https://containerengine.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.ME_ABUDHABI_1,
    ): 'https://containerengine.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.ME_DUBAI_1,
    ): 'https://containerengine.me-dubai-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.ME_JEDDAH_1,
    ): 'https://containerengine.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.ME_RIYADH_1,
    ): 'https://containerengine.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.MX_MONTERREY_1,
    ): 'https://containerengine.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.MX_QUERETARO_1,
    ): 'https://containerengine.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.SA_BOGOTA_1,
    ): 'https://containerengine.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.SA_SANTIAGO_1,
    ): 'https://containerengine.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.SA_SAOPAULO_1,
    ): 'https://containerengine.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.SA_VALPARAISO_1,
    ): 'https://containerengine.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.SA_VINHEDO_1,
    ): 'https://containerengine.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.UK_CARDIFF_1,
    ): 'https://containerengine.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.UK_LONDON_1,
    ): 'https://containerengine.uk-london-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.US_ASHBURN_1,
    ): 'https://containerengine.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.US_CHICAGO_1,
    ): 'https://containerengine.us-chicago-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.US_PHOENIX_1,
    ): 'https://containerengine.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.CONTAINERENGINE,
        Region.US_SANJOSE_1,
    ): 'https://containerengine.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.AF_JOHANNESBURG_1,
    ): 'https://dashboard.af-johannesburg-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.AP_BATAM_1): 'https://dashboard.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.AP_CHUNCHEON_1,
    ): 'https://dashboard.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.AP_HYDERABAD_1,
    ): 'https://dashboard.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.AP_MELBOURNE_1,
    ): 'https://dashboard.ap-melbourne-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.AP_MUMBAI_1): 'https://dashboard.ap-mumbai-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.AP_OSAKA_1): 'https://dashboard.ap-osaka-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.AP_SEOUL_1): 'https://dashboard.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.AP_SINGAPORE_1,
    ): 'https://dashboard.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.AP_SINGAPORE_2,
    ): 'https://dashboard.ap-singapore-2.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.AP_SYDNEY_1): 'https://dashboard.ap-sydney-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.AP_TOKYO_1): 'https://dashboard.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.CA_MONTREAL_1,
    ): 'https://dashboard.ca-montreal-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.CA_TORONTO_1): 'https://dashboard.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.EU_AMSTERDAM_1,
    ): 'https://dashboard.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.EU_FRANKFURT_1,
    ): 'https://dashboard.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.EU_JOVANOVAC_1,
    ): 'https://dashboard.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.DASHBOARD, Region.EU_MADRID_1): 'https://dashboard.eu-madrid-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.EU_MADRID_3): 'https://dashboard.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.EU_MARSEILLE_1,
    ): 'https://dashboard.eu-marseille-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.EU_MILAN_1): 'https://dashboard.eu-milan-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.EU_STOCKHOLM_1,
    ): 'https://dashboard.eu-stockholm-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.EU_TURIN_1): 'https://dashboard.eu-turin-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.EU_ZURICH_1): 'https://dashboard.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.IL_JERUSALEM_1,
    ): 'https://dashboard.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.ME_ABUDHABI_1,
    ): 'https://dashboard.me-abudhabi-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.ME_DUBAI_1): 'https://dashboard.me-dubai-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.ME_JEDDAH_1): 'https://dashboard.me-jeddah-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.ME_RIYADH_1): 'https://dashboard.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.MX_MONTERREY_1,
    ): 'https://dashboard.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.MX_QUERETARO_1,
    ): 'https://dashboard.mx-queretaro-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.SA_BOGOTA_1): 'https://dashboard.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.SA_SANTIAGO_1,
    ): 'https://dashboard.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.SA_SAOPAULO_1,
    ): 'https://dashboard.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DASHBOARD,
        Region.SA_VALPARAISO_1,
    ): 'https://dashboard.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.SA_VINHEDO_1): 'https://dashboard.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.UK_CARDIFF_1): 'https://dashboard.uk-cardiff-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.UK_LONDON_1): 'https://dashboard.uk-london-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.US_ASHBURN_1): 'https://dashboard.us-ashburn-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.US_CHICAGO_1): 'https://dashboard.us-chicago-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.US_PHOENIX_1): 'https://dashboard.us-phoenix-1.oci.oraclecloud.com',
    (Service.DASHBOARD, Region.US_SANJOSE_1): 'https://dashboard.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.AF_JOHANNESBURG_1,
    ): 'https://datacatalog.af-johannesburg-1.oci.oraclecloud.com',
    (Service.DATA_CATALOG, Region.AP_BATAM_1): 'https://datacatalog.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.AP_CHUNCHEON_1,
    ): 'https://datacatalog.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.AP_HYDERABAD_1,
    ): 'https://datacatalog.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.AP_MELBOURNE_1,
    ): 'https://datacatalog.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.AP_MUMBAI_1,
    ): 'https://datacatalog.ap-mumbai-1.oci.oraclecloud.com',
    (Service.DATA_CATALOG, Region.AP_OSAKA_1): 'https://datacatalog.ap-osaka-1.oci.oraclecloud.com',
    (Service.DATA_CATALOG, Region.AP_SEOUL_1): 'https://datacatalog.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.AP_SINGAPORE_1,
    ): 'https://datacatalog.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.AP_SINGAPORE_2,
    ): 'https://datacatalog.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.AP_SYDNEY_1,
    ): 'https://datacatalog.ap-sydney-1.oci.oraclecloud.com',
    (Service.DATA_CATALOG, Region.AP_TOKYO_1): 'https://datacatalog.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.CA_MONTREAL_1,
    ): 'https://datacatalog.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.CA_TORONTO_1,
    ): 'https://datacatalog.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.EU_AMSTERDAM_1,
    ): 'https://datacatalog.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.EU_FRANKFURT_1,
    ): 'https://datacatalog.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.EU_JOVANOVAC_1,
    ): 'https://datacatalog.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.DATA_CATALOG,
        Region.EU_MADRID_1,
    ): 'https://datacatalog.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.EU_MADRID_3,
    ): 'https://datacatalog.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.EU_MARSEILLE_1,
    ): 'https://datacatalog.eu-marseille-1.oci.oraclecloud.com',
    (Service.DATA_CATALOG, Region.EU_MILAN_1): 'https://datacatalog.eu-milan-1.oci.oraclecloud.com',
    (Service.DATA_CATALOG, Region.EU_PARIS_1): 'https://datacatalog.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.EU_STOCKHOLM_1,
    ): 'https://datacatalog.eu-stockholm-1.oci.oraclecloud.com',
    (Service.DATA_CATALOG, Region.EU_TURIN_1): 'https://datacatalog.eu-turin-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.EU_ZURICH_1,
    ): 'https://datacatalog.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.IL_JERUSALEM_1,
    ): 'https://datacatalog.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.ME_ABUDHABI_1,
    ): 'https://datacatalog.me-abudhabi-1.oci.oraclecloud.com',
    (Service.DATA_CATALOG, Region.ME_DUBAI_1): 'https://datacatalog.me-dubai-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.ME_JEDDAH_1,
    ): 'https://datacatalog.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.ME_RIYADH_1,
    ): 'https://datacatalog.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.MX_MONTERREY_1,
    ): 'https://datacatalog.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.MX_QUERETARO_1,
    ): 'https://datacatalog.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.SA_BOGOTA_1,
    ): 'https://datacatalog.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.SA_SANTIAGO_1,
    ): 'https://datacatalog.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.SA_SAOPAULO_1,
    ): 'https://datacatalog.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.SA_VALPARAISO_1,
    ): 'https://datacatalog.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.SA_VINHEDO_1,
    ): 'https://datacatalog.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.UK_CARDIFF_1,
    ): 'https://datacatalog.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.UK_LONDON_1,
    ): 'https://datacatalog.uk-london-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.US_ASHBURN_1,
    ): 'https://datacatalog.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.US_PHOENIX_1,
    ): 'https://datacatalog.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DATA_CATALOG,
        Region.US_SANJOSE_1,
    ): 'https://datacatalog.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.AF_JOHANNESBURG_1,
    ): 'https://dataflow.af-johannesburg-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.AP_BATAM_1): 'https://dataflow.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.AP_CHUNCHEON_1,
    ): 'https://dataflow.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.AP_HYDERABAD_1): 'https://dataflow.ap-hyderabad-1.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.AP_MELBOURNE_1,
    ): 'https://dataflow.ap-melbourne-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.AP_MUMBAI_1): 'https://dataflow.ap-mumbai-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.AP_OSAKA_1): 'https://dataflow.ap-osaka-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.AP_SEOUL_1): 'https://dataflow.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.AP_SINGAPORE_1,
    ): 'https://dataflow.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.AP_SINGAPORE_2,
    ): 'https://dataflow.ap-singapore-2.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.AP_SYDNEY_1): 'https://dataflow.ap-sydney-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.AP_TOKYO_1): 'https://dataflow.ap-tokyo-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.CA_MONTREAL_1): 'https://dataflow.ca-montreal-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.CA_TORONTO_1): 'https://dataflow.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.EU_AMSTERDAM_1,
    ): 'https://dataflow.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.EU_FRANKFURT_1,
    ): 'https://dataflow.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.EU_JOVANOVAC_1,
    ): 'https://dataflow.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.DATA_FLOW, Region.EU_MADRID_1): 'https://dataflow.eu-madrid-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.EU_MADRID_3): 'https://dataflow.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.EU_MARSEILLE_1,
    ): 'https://dataflow.eu-marseille-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.EU_MILAN_1): 'https://dataflow.eu-milan-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.EU_PARIS_1): 'https://dataflow.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.EU_STOCKHOLM_1,
    ): 'https://dataflow.eu-stockholm-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.EU_TURIN_1): 'https://dataflow.eu-turin-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.EU_ZURICH_1): 'https://dataflow.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.IL_JERUSALEM_1,
    ): 'https://dataflow.il-jerusalem-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.ME_ABUDHABI_1): 'https://dataflow.me-abudhabi-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.ME_DUBAI_1): 'https://dataflow.me-dubai-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.ME_JEDDAH_1): 'https://dataflow.me-jeddah-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.ME_RIYADH_1): 'https://dataflow.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.MX_MONTERREY_1,
    ): 'https://dataflow.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.MX_QUERETARO_1,
    ): 'https://dataflow.mx-queretaro-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.SA_BOGOTA_1): 'https://dataflow.sa-bogota-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.SA_SANTIAGO_1): 'https://dataflow.sa-santiago-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.SA_SAOPAULO_1): 'https://dataflow.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DATA_FLOW,
        Region.SA_VALPARAISO_1,
    ): 'https://dataflow.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.SA_VINHEDO_1): 'https://dataflow.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.UK_CARDIFF_1): 'https://dataflow.uk-cardiff-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.UK_LONDON_1): 'https://dataflow.uk-london-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.US_ASHBURN_1): 'https://dataflow.us-ashburn-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.US_CHICAGO_1): 'https://dataflow.us-chicago-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.US_PHOENIX_1): 'https://dataflow.us-phoenix-1.oci.oraclecloud.com',
    (Service.DATA_FLOW, Region.US_SANJOSE_1): 'https://dataflow.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AF_JOHANNESBURG_1,
    ): 'https://dataintegration.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AP_BATAM_1,
    ): 'https://dataintegration.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AP_CHUNCHEON_1,
    ): 'https://dataintegration.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AP_HYDERABAD_1,
    ): 'https://dataintegration.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AP_MELBOURNE_1,
    ): 'https://dataintegration.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AP_MUMBAI_1,
    ): 'https://dataintegration.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AP_OSAKA_1,
    ): 'https://dataintegration.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AP_SEOUL_1,
    ): 'https://dataintegration.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AP_SINGAPORE_1,
    ): 'https://dataintegration.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AP_SINGAPORE_2,
    ): 'https://dataintegration.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AP_SYDNEY_1,
    ): 'https://dataintegration.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.AP_TOKYO_1,
    ): 'https://dataintegration.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.CA_MONTREAL_1,
    ): 'https://dataintegration.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.CA_TORONTO_1,
    ): 'https://dataintegration.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.EU_AMSTERDAM_1,
    ): 'https://dataintegration.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.EU_FRANKFURT_1,
    ): 'https://dataintegration.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.EU_JOVANOVAC_1,
    ): 'https://dataintegration.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.DATA_INTEGRATION,
        Region.EU_MADRID_1,
    ): 'https://dataintegration.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.EU_MADRID_3,
    ): 'https://dataintegration.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.EU_MARSEILLE_1,
    ): 'https://dataintegration.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.EU_MILAN_1,
    ): 'https://dataintegration.eu-milan-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.EU_PARIS_1,
    ): 'https://dataintegration.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.EU_STOCKHOLM_1,
    ): 'https://dataintegration.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.EU_TURIN_1,
    ): 'https://dataintegration.eu-turin-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.EU_ZURICH_1,
    ): 'https://dataintegration.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.IL_JERUSALEM_1,
    ): 'https://dataintegration.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.ME_ABUDHABI_1,
    ): 'https://dataintegration.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.ME_DUBAI_1,
    ): 'https://dataintegration.me-dubai-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.ME_JEDDAH_1,
    ): 'https://dataintegration.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.ME_RIYADH_1,
    ): 'https://dataintegration.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.MX_MONTERREY_1,
    ): 'https://dataintegration.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.MX_QUERETARO_1,
    ): 'https://dataintegration.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.SA_BOGOTA_1,
    ): 'https://dataintegration.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.SA_SANTIAGO_1,
    ): 'https://dataintegration.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.SA_SAOPAULO_1,
    ): 'https://dataintegration.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.SA_VALPARAISO_1,
    ): 'https://dataintegration.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.SA_VINHEDO_1,
    ): 'https://dataintegration.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.UK_CARDIFF_1,
    ): 'https://dataintegration.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.UK_LONDON_1,
    ): 'https://dataintegration.uk-london-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.US_ASHBURN_1,
    ): 'https://dataintegration.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.US_PHOENIX_1,
    ): 'https://dataintegration.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DATA_INTEGRATION,
        Region.US_SANJOSE_1,
    ): 'https://dataintegration.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://datasafe.af-johannesburg-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.AP_BATAM_1): 'https://datasafe.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.AP_CHUNCHEON_1,
    ): 'https://datasafe.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.AP_HYDERABAD_1,
    ): 'https://datasafe.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.AP_MELBOURNE_1,
    ): 'https://datasafe.ap-melbourne-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.AP_MUMBAI_1): 'https://datasafe.ap-mumbai-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.AP_OSAKA_1): 'https://datasafe.ap-osaka-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.AP_SEOUL_1): 'https://datasafe.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.AP_SINGAPORE_1,
    ): 'https://datasafe.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.AP_SINGAPORE_2,
    ): 'https://datasafe.ap-singapore-2.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.AP_SYDNEY_1): 'https://datasafe.ap-sydney-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.AP_TOKYO_1): 'https://datasafe.ap-tokyo-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.CA_MONTREAL_1): 'https://datasafe.ca-montreal-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.CA_TORONTO_1): 'https://datasafe.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.EU_AMSTERDAM_1,
    ): 'https://datasafe.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.EU_FRANKFURT_1,
    ): 'https://datasafe.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.EU_JOVANOVAC_1,
    ): 'https://datasafe.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.DATA_SAFE, Region.EU_MADRID_1): 'https://datasafe.eu-madrid-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.EU_MADRID_3): 'https://datasafe.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.EU_MARSEILLE_1,
    ): 'https://datasafe.eu-marseille-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.EU_MILAN_1): 'https://datasafe.eu-milan-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.EU_PARIS_1): 'https://datasafe.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.EU_STOCKHOLM_1,
    ): 'https://datasafe.eu-stockholm-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.EU_TURIN_1): 'https://datasafe.eu-turin-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.EU_ZURICH_1): 'https://datasafe.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.IL_JERUSALEM_1,
    ): 'https://datasafe.il-jerusalem-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.ME_ABUDHABI_1): 'https://datasafe.me-abudhabi-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.ME_DUBAI_1): 'https://datasafe.me-dubai-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.ME_JEDDAH_1): 'https://datasafe.me-jeddah-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.ME_RIYADH_1): 'https://datasafe.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.MX_MONTERREY_1,
    ): 'https://datasafe.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.MX_QUERETARO_1,
    ): 'https://datasafe.mx-queretaro-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.SA_BOGOTA_1): 'https://datasafe.sa-bogota-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.SA_SANTIAGO_1): 'https://datasafe.sa-santiago-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.SA_SAOPAULO_1): 'https://datasafe.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DATA_SAFE,
        Region.SA_VALPARAISO_1,
    ): 'https://datasafe.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.SA_VINHEDO_1): 'https://datasafe.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.UK_CARDIFF_1): 'https://datasafe.uk-cardiff-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.UK_LONDON_1): 'https://datasafe.uk-london-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.US_ASHBURN_1): 'https://datasafe.us-ashburn-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.US_PHOENIX_1): 'https://datasafe.us-phoenix-1.oci.oraclecloud.com',
    (Service.DATA_SAFE, Region.US_SANJOSE_1): 'https://datasafe.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://datascience.af-johannesburg-1.oci.oraclecloud.com',
    (Service.DATA_SCIENCE, Region.AP_BATAM_1): 'https://datascience.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.AP_CHUNCHEON_1,
    ): 'https://datascience.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.AP_HYDERABAD_1,
    ): 'https://datascience.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.AP_MELBOURNE_1,
    ): 'https://datascience.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.AP_MUMBAI_1,
    ): 'https://datascience.ap-mumbai-1.oci.oraclecloud.com',
    (Service.DATA_SCIENCE, Region.AP_OSAKA_1): 'https://datascience.ap-osaka-1.oci.oraclecloud.com',
    (Service.DATA_SCIENCE, Region.AP_SEOUL_1): 'https://datascience.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.AP_SINGAPORE_1,
    ): 'https://datascience.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.AP_SINGAPORE_2,
    ): 'https://datascience.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.AP_SYDNEY_1,
    ): 'https://datascience.ap-sydney-1.oci.oraclecloud.com',
    (Service.DATA_SCIENCE, Region.AP_TOKYO_1): 'https://datascience.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.CA_MONTREAL_1,
    ): 'https://datascience.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.CA_TORONTO_1,
    ): 'https://datascience.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.EU_AMSTERDAM_1,
    ): 'https://datascience.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.EU_FRANKFURT_1,
    ): 'https://datascience.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.EU_JOVANOVAC_1,
    ): 'https://datascience.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.DATA_SCIENCE,
        Region.EU_MADRID_1,
    ): 'https://datascience.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.EU_MADRID_3,
    ): 'https://datascience.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.EU_MARSEILLE_1,
    ): 'https://datascience.eu-marseille-1.oci.oraclecloud.com',
    (Service.DATA_SCIENCE, Region.EU_MILAN_1): 'https://datascience.eu-milan-1.oci.oraclecloud.com',
    (Service.DATA_SCIENCE, Region.EU_MILAN_3): 'https://datascience.eu-milan-3.oci.oraclecloud.com',
    (Service.DATA_SCIENCE, Region.EU_PARIS_1): 'https://datascience.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.EU_STOCKHOLM_1,
    ): 'https://datascience.eu-stockholm-1.oci.oraclecloud.com',
    (Service.DATA_SCIENCE, Region.EU_TURIN_1): 'https://datascience.eu-turin-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.EU_ZURICH_1,
    ): 'https://datascience.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.ME_ABUDHABI_1,
    ): 'https://datascience.me-abudhabi-1.oci.oraclecloud.com',
    (Service.DATA_SCIENCE, Region.ME_DUBAI_1): 'https://datascience.me-dubai-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.ME_JEDDAH_1,
    ): 'https://datascience.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.MX_MONTERREY_1,
    ): 'https://datascience.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.MX_QUERETARO_1,
    ): 'https://datascience.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.SA_BOGOTA_1,
    ): 'https://datascience.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.SA_SANTIAGO_1,
    ): 'https://datascience.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.SA_SAOPAULO_1,
    ): 'https://datascience.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.SA_VALPARAISO_1,
    ): 'https://datascience.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.SA_VINDEHO_1,
    ): 'https://datascience.sa-vindeho-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.UK_LONDON_1,
    ): 'https://datascience.uk-london-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.US_ASHBURN_1,
    ): 'https://datascience.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.US_CHICAGO_1,
    ): 'https://datascience.us-chicago-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.US_PHOENIX_1,
    ): 'https://datascience.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DATA_SCIENCE,
        Region.US_SANJOSE_1,
    ): 'https://datascience.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATABASE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://database.af-johannesburg-1.oraclecloud.com',
    (Service.DATABASE, Region.AP_BATAM_1): 'https://database.ap-batam-1.oraclecloud.com',
    (Service.DATABASE, Region.AP_CHUNCHEON_1): 'https://database.ap-chuncheon-1.oraclecloud.com',
    (Service.DATABASE, Region.AP_HYDERABAD_1): 'https://database.ap-hyderabad-1.oraclecloud.com',
    (Service.DATABASE, Region.AP_MELBOURNE_1): 'https://database.ap-melbourne-1.oraclecloud.com',
    (Service.DATABASE, Region.AP_MUMBAI_1): 'https://database.ap-mumbai-1.oraclecloud.com',
    (Service.DATABASE, Region.AP_OSAKA_1): 'https://database.ap-osaka-1.oraclecloud.com',
    (Service.DATABASE, Region.AP_SEOUL_1): 'https://database.ap-seoul-1.oraclecloud.com',
    (Service.DATABASE, Region.AP_SINGAPORE_1): 'https://database.ap-singapore-1.oraclecloud.com',
    (Service.DATABASE, Region.AP_SINGAPORE_2): 'https://database.ap-singapore-2.oraclecloud.com',
    (Service.DATABASE, Region.AP_SYDNEY_1): 'https://database.ap-sydney-1.oraclecloud.com',
    (Service.DATABASE, Region.AP_TOKYO_1): 'https://database.ap-tokyo-1.oraclecloud.com',
    (Service.DATABASE, Region.CA_MONTREAL_1): 'https://database.ca-montreal-1.oraclecloud.com',
    (Service.DATABASE, Region.CA_TORONTO_1): 'https://database.ca-toronto-1.oraclecloud.com',
    (Service.DATABASE, Region.EU_AMSTERDAM_1): 'https://database.eu-amsterdam-1.oraclecloud.com',
    (Service.DATABASE, Region.EU_FRANKFURT_1): 'https://database.eu-frankfurt-1.oraclecloud.com',
    (Service.DATABASE, Region.EU_JOVANOVAC_1): 'https://database.eu-jovanovac-1.oraclecloud20.com',
    (Service.DATABASE, Region.EU_MADRID_1): 'https://database.eu-madrid-1.oraclecloud.com',
    (Service.DATABASE, Region.EU_MADRID_3): 'https://database.eu-madrid-3.oraclecloud.com',
    (Service.DATABASE, Region.EU_MARSEILLE_1): 'https://database.eu-marseille-1.oraclecloud.com',
    (Service.DATABASE, Region.EU_MILAN_1): 'https://database.eu-milan-1.oraclecloud.com',
    (Service.DATABASE, Region.EU_PARIS_1): 'https://database.eu-paris-1.oraclecloud.com',
    (Service.DATABASE, Region.EU_STOCKHOLM_1): 'https://database.eu-stockholm-1.oraclecloud.com',
    (Service.DATABASE, Region.EU_TURIN_1): 'https://database.eu-turin-1.oraclecloud.com',
    (Service.DATABASE, Region.EU_ZURICH_1): 'https://database.eu-zurich-1.oraclecloud.com',
    (Service.DATABASE, Region.IL_JERUSALEM_1): 'https://database.il-jerusalem-1.oraclecloud.com',
    (Service.DATABASE, Region.ME_ABUDHABI_1): 'https://database.me-abudhabi-1.oraclecloud.com',
    (Service.DATABASE, Region.ME_DUBAI_1): 'https://database.me-dubai-1.oraclecloud.com',
    (Service.DATABASE, Region.ME_JEDDAH_1): 'https://database.me-jeddah-1.oraclecloud.com',
    (Service.DATABASE, Region.ME_RIYADH_1): 'https://database.me-riyadh-1.oraclecloud.com',
    (Service.DATABASE, Region.MX_MONTERREY_1): 'https://database.mx-monterrey-1.oraclecloud.com',
    (Service.DATABASE, Region.MX_QUERETARO_1): 'https://database.mx-queretaro-1.oraclecloud.com',
    (Service.DATABASE, Region.SA_SANTIAGO_1): 'https://database.sa-santiago-1.oraclecloud.com',
    (Service.DATABASE, Region.SA_SAOPAULO_1): 'https://database.sa-saopaulo-1.oraclecloud.com',
    (Service.DATABASE, Region.SA_VALPARAISO_1): 'https://database.sa-valparaiso-1.oraclecloud.com',
    (Service.DATABASE, Region.SA_VINHEDO_1): 'https://database.sa-vinhedo-1.oraclecloud.com',
    (Service.DATABASE, Region.UK_CARDIFF_1): 'https://database.uk-cardiff-1.oraclecloud.com',
    (Service.DATABASE, Region.UK_LONDON_1): 'https://database.uk-london-1.oraclecloud.com',
    (Service.DATABASE, Region.US_ASHBURN_1): 'https://database.us-ashburn-1.oraclecloud.com',
    (Service.DATABASE, Region.US_CHICAGO_1): 'https://database.us-chicago-1.oraclecloud.com',
    (Service.DATABASE, Region.US_PHOENIX_1): 'https://database.us-phoenix-1.oraclecloud.com',
    (Service.DATABASE, Region.US_SANJOSE_1): 'https://database.us-sanjose-1.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AF_JOHANNESBURG_1,
    ): 'https://dbmgmt.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AP_BATAM_1,
    ): 'https://dbmgmt.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AP_CHUNCHEON_1,
    ): 'https://dbmgmt.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AP_HYDERABAD_1,
    ): 'https://dbmgmt.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AP_MELBOURNE_1,
    ): 'https://dbmgmt.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AP_MUMBAI_1,
    ): 'https://dbmgmt.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AP_OSAKA_1,
    ): 'https://dbmgmt.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AP_SEOUL_1,
    ): 'https://dbmgmt.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AP_SINGAPORE_1,
    ): 'https://dbmgmt.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AP_SINGAPORE_2,
    ): 'https://dbmgmt.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AP_SYDNEY_1,
    ): 'https://dbmgmt.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.AP_TOKYO_1,
    ): 'https://dbmgmt.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.CA_MONTREAL_1,
    ): 'https://dbmgmt.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.CA_TORONTO_1,
    ): 'https://dbmgmt.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.EU_AMSTERDAM_1,
    ): 'https://dbmgmt.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.EU_FRANKFURT_1,
    ): 'https://dbmgmt.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.EU_MADRID_1,
    ): 'https://dbmgmt.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.EU_MADRID_3,
    ): 'https://dbmgmt.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.EU_MARSEILLE_1,
    ): 'https://dbmgmt.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.EU_MILAN_1,
    ): 'https://dbmgmt.eu-milan-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.EU_PARIS_1,
    ): 'https://dbmgmt.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.EU_STOCKHOLM_1,
    ): 'https://dbmgmt.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.EU_TURIN_1,
    ): 'https://dbmgmt.eu-turin-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.EU_ZURICH_1,
    ): 'https://dbmgmt.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.IL_JERUSALEM_1,
    ): 'https://dbmgmt.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.ME_ABUDHABI_1,
    ): 'https://dbmgmt.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.ME_DUBAI_1,
    ): 'https://dbmgmt.me-dubai-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.ME_JEDDAH_1,
    ): 'https://dbmgmt.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.ME_RIYADH_1,
    ): 'https://dbmgmt.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.MX_MONTERREY_1,
    ): 'https://dbmgmt.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.MX_QUERETARO_1,
    ): 'https://dbmgmt.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.SA_BOGOTA_1,
    ): 'https://dbmgmt.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.SA_SANTIAGO_1,
    ): 'https://dbmgmt.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.SA_SAOPAULO_1,
    ): 'https://dbmgmt.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.SA_VALPARAISO_1,
    ): 'https://dbmgmt.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.SA_VINHEDO_1,
    ): 'https://dbmgmt.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.UK_CARDIFF_1,
    ): 'https://dbmgmt.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.UK_LONDON_1,
    ): 'https://dbmgmt.uk-london-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.US_ASHBURN_1,
    ): 'https://dbmgmt.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.US_CHICAGO_1,
    ): 'https://dbmgmt.us-chicago-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.US_PHOENIX_1,
    ): 'https://dbmgmt.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MANAGEMENT,
        Region.US_SANJOSE_1,
    ): 'https://dbmgmt.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.AF_JOHANNESBURG_1,
    ): 'https://odms.af-johannesburg-1.oci.oraclecloud.com',
    (Service.DATABASE_MIGRATION, Region.AP_BATAM_1): 'https://odms.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.AP_CHUNCHEON_1,
    ): 'https://odms.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.AP_HYDERABAD_1,
    ): 'https://odms.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.AP_MELBOURNE_1,
    ): 'https://odms.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.AP_MUMBAI_1,
    ): 'https://odms.ap-mumbai-1.oci.oraclecloud.com',
    (Service.DATABASE_MIGRATION, Region.AP_OSAKA_1): 'https://odms.ap-osaka-1.oci.oraclecloud.com',
    (Service.DATABASE_MIGRATION, Region.AP_SEOUL_1): 'https://odms.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.AP_SINGAPORE_1,
    ): 'https://odms.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.AP_SYDNEY_1,
    ): 'https://odms.ap-sydney-1.oci.oraclecloud.com',
    (Service.DATABASE_MIGRATION, Region.AP_TOKYO_1): 'https://odms.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.CA_MONTREAL_1,
    ): 'https://odms.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.CA_TORONTO_1,
    ): 'https://odms.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.EU_AMSTERDAM_1,
    ): 'https://odms.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.EU_FRANKFURT_1,
    ): 'https://odms.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.EU_JOVANOVAC_1,
    ): 'https://odms.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.DATABASE_MIGRATION,
        Region.EU_MARSEILLE_1,
    ): 'https://odms.eu-marseille-1.oci.oraclecloud.com',
    (Service.DATABASE_MIGRATION, Region.EU_MILAN_1): 'https://odms.eu-milan-1.oci.oraclecloud.com',
    (Service.DATABASE_MIGRATION, Region.EU_PARIS_1): 'https://odms.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.EU_STOCKHOLM_1,
    ): 'https://odms.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.EU_ZURICH_1,
    ): 'https://odms.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.IL_JERUSALEM_1,
    ): 'https://odms.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.ME_ABUDHABI_1,
    ): 'https://odms.me-abudhabi-1.oci.oraclecloud.com',
    (Service.DATABASE_MIGRATION, Region.ME_DUBAI_1): 'https://odms.me-dubai-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.ME_JEDDAH_1,
    ): 'https://odms.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.ME_RIYADH_1,
    ): 'https://odms.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.MX_MONTERREY_1,
    ): 'https://odms.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.MX_QUERETARO_1,
    ): 'https://odms.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.SA_SANTIAGO_1,
    ): 'https://odms.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.SA_SAOPAULO_1,
    ): 'https://odms.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.SA_VINHEDO_1,
    ): 'https://odms.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.UK_CARDIFF_1,
    ): 'https://odms.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.UK_LONDON_1,
    ): 'https://odms.uk-london-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.US_ASHBURN_1,
    ): 'https://odms.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.US_CHICAGO_1,
    ): 'https://odms.us-chicago-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.US_PHOENIX_1,
    ): 'https://odms.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MIGRATION,
        Region.US_SANJOSE_1,
    ): 'https://odms.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.AP_MELBOURNE_1,
    ): 'https://dbmulticloud.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.AP_SINGAPORE_1,
    ): 'https://dbmulticloud.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.AP_SYDNEY_1,
    ): 'https://dbmulticloud.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.AP_TOKYO_1,
    ): 'https://dbmulticloud.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.CA_TORONTO_1,
    ): 'https://dbmulticloud.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.EU_FRANKFURT_1,
    ): 'https://dbmulticloud.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.EU_MILAN_1,
    ): 'https://dbmulticloud.eu-milan-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.EU_PARIS_1,
    ): 'https://dbmulticloud.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.SA_VINHEDO_1,
    ): 'https://dbmulticloud.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.UK_CARDIFF_1,
    ): 'https://dbmulticloud.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.UK_LONDON_1,
    ): 'https://dbmulticloud.uk-london-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.US_ASHBURN_1,
    ): 'https://dbmulticloud.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.US_BOARDMAN_1,
    ): 'https://dbmulticloud.us-boardman-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.US_PHOENIX_1,
    ): 'https://dbmulticloud.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.US_SALTLAKE_2,
    ): 'https://dbmulticloud.us-saltlake-2.oci.oraclecloud.com',
    (
        Service.DATABASE_MULTICLOUD_INTEGRATIONS,
        Region.US_SANJOSE_1,
    ): 'https://dbmulticloud.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://dbtools.af-johannesburg-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.AP_BATAM_1): 'https://dbtools.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.AP_CHUNCHEON_1,
    ): 'https://dbtools.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.AP_HYDERABAD_1,
    ): 'https://dbtools.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.AP_MELBOURNE_1,
    ): 'https://dbtools.ap-melbourne-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.AP_MUMBAI_1): 'https://dbtools.ap-mumbai-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.AP_OSAKA_1): 'https://dbtools.ap-osaka-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.AP_SEOUL_1): 'https://dbtools.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.AP_SINGAPORE_1,
    ): 'https://dbtools.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.AP_SINGAPORE_2,
    ): 'https://dbtools.ap-singapore-2.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.AP_SYDNEY_1): 'https://dbtools.ap-sydney-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.AP_TOKYO_1): 'https://dbtools.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.CA_MONTREAL_1,
    ): 'https://dbtools.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.CA_TORONTO_1,
    ): 'https://dbtools.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.EU_AMSTERDAM_1,
    ): 'https://dbtools.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.EU_FRANKFURT_1,
    ): 'https://dbtools.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.EU_JOVANOVAC_1,
    ): 'https://dbtools.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.DATABASE_TOOLS, Region.EU_MADRID_1): 'https://dbtools.eu-madrid-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.EU_MADRID_3): 'https://dbtools.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.EU_MARSEILLE_1,
    ): 'https://dbtools.eu-marseille-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.EU_MILAN_1): 'https://dbtools.eu-milan-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.EU_PARIS_1): 'https://dbtools.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.EU_STOCKHOLM_1,
    ): 'https://dbtools.eu-stockholm-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.EU_TURIN_1): 'https://dbtools.eu-turin-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.EU_ZURICH_1): 'https://dbtools.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.IL_JERUSALEM_1,
    ): 'https://dbtools.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.ME_ABUDHABI_1,
    ): 'https://dbtools.me-abudhabi-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.ME_DUBAI_1): 'https://dbtools.me-dubai-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.ME_JEDDAH_1): 'https://dbtools.me-jeddah-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.ME_RIYADH_1): 'https://dbtools.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.MX_MONTERREY_1,
    ): 'https://dbtools.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.MX_QUERETARO_1,
    ): 'https://dbtools.mx-queretaro-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.SA_BOGOTA_1): 'https://dbtools.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.SA_SANTIAGO_1,
    ): 'https://dbtools.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.SA_SAOPAULO_1,
    ): 'https://dbtools.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.SA_VALPARAISO_1,
    ): 'https://dbtools.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.SA_VINHEDO_1,
    ): 'https://dbtools.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.UK_CARDIFF_1,
    ): 'https://dbtools.uk-cardiff-1.oci.oraclecloud.com',
    (Service.DATABASE_TOOLS, Region.UK_LONDON_1): 'https://dbtools.uk-london-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.US_ASHBURN_1,
    ): 'https://dbtools.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.US_CHICAGO_1,
    ): 'https://dbtools.us-chicago-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.US_PHOENIX_1,
    ): 'https://dbtools.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DATABASE_TOOLS,
        Region.US_SANJOSE_1,
    ): 'https://dbtools.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.AF_JOHANNESBURG_1,
    ): 'https://datalabeling-cp.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.AP_BATAM_1,
    ): 'https://datalabeling-cp.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.AP_CHUNCHEON_1,
    ): 'https://datalabeling-cp.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.AP_HYDERABAD_1,
    ): 'https://datalabeling-cp.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.AP_MELBOURNE_1,
    ): 'https://datalabeling-cp.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.AP_MUMBAI_1,
    ): 'https://datalabeling-cp.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.AP_OSAKA_1,
    ): 'https://datalabeling-cp.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.AP_SEOUL_1,
    ): 'https://datalabeling-cp.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.AP_SINGAPORE_2,
    ): 'https://datalabeling-cp.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.AP_SYDNEY_1,
    ): 'https://datalabeling-cp.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.AP_TOKYO_1,
    ): 'https://datalabeling-cp.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.CA_MONTREAL_1,
    ): 'https://datalabeling-cp.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.CA_TORONTO_1,
    ): 'https://datalabeling-cp.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.EU_AMSTERDAM_1,
    ): 'https://datalabeling-cp.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.EU_FRANKFURT_1,
    ): 'https://datalabeling-cp.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.EU_JOVANOVAC_1,
    ): 'https://datalabeling-cp.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.DATALABELING,
        Region.EU_MADRID_1,
    ): 'https://datalabeling-cp.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.EU_MADRID_3,
    ): 'https://datalabeling-cp.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.EU_MARSEILLE_1,
    ): 'https://datalabeling-cp.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.EU_MILAN_1,
    ): 'https://datalabeling-cp.eu-milan-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.EU_PARIS_1,
    ): 'https://datalabeling-cp.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.EU_STOCKHOLM_1,
    ): 'https://datalabeling-cp.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.EU_TURIN_1,
    ): 'https://datalabeling-cp.eu-turin-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.EU_ZURICH_1,
    ): 'https://datalabeling-cp.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.IL_JERUSALEM_1,
    ): 'https://datalabeling-cp.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.ME_ABUDHABI_1,
    ): 'https://datalabeling-cp.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.ME_DUBAI_1,
    ): 'https://datalabeling-cp.me-dubai-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.ME_JEDDAH_1,
    ): 'https://datalabeling-cp.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.ME_RIYADH_1,
    ): 'https://datalabeling-cp.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.SA_BOGOTA_1,
    ): 'https://datalabeling-cp.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.SA_SANTIAGO_1,
    ): 'https://datalabeling-cp.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.SA_SAOPAULO_1,
    ): 'https://datalabeling-cp.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.SA_VALPARAISO_1,
    ): 'https://datalabeling-cp.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.SA_VINHEDO_1,
    ): 'https://datalabeling-cp.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.UK_CARDIFF_1,
    ): 'https://datalabeling-cp.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.UK_LONDON_1,
    ): 'https://datalabeling-cp.uk-london-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.US_ASHBURN_1,
    ): 'https://datalabeling-cp.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.US_PHOENIX_1,
    ): 'https://datalabeling-cp.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.US_SANJOSE_1,
    ): 'https://datalabeling-cp.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.MX_MONTERREY_1,
    ): 'https://datalabeling.cp.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DATALABELING,
        Region.MX_QUERETARO_1,
    ): 'https://datalabeling.cp.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AF_JOHANNESBURG_1,
    ): 'https://datalabeling-dp.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AP_BATAM_1,
    ): 'https://datalabeling-dp.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AP_CHUNCHEON_1,
    ): 'https://datalabeling-dp.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AP_HYDERABAD_1,
    ): 'https://datalabeling-dp.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AP_MELBOURNE_1,
    ): 'https://datalabeling-dp.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AP_MUMBAI_1,
    ): 'https://datalabeling-dp.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AP_OSAKA_1,
    ): 'https://datalabeling-dp.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AP_SEOUL_1,
    ): 'https://datalabeling-dp.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AP_SINGAPORE_1,
    ): 'https://datalabeling-dp.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AP_SINGAPORE_2,
    ): 'https://datalabeling-dp.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AP_SYDNEY_1,
    ): 'https://datalabeling-dp.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.AP_TOKYO_1,
    ): 'https://datalabeling-dp.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.CA_MONTREAL_1,
    ): 'https://datalabeling-dp.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.CA_TORONTO_1,
    ): 'https://datalabeling-dp.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.EU_AMSTERDAM_1,
    ): 'https://datalabeling-dp.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.EU_FRANKFURT_1,
    ): 'https://datalabeling-dp.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.EU_JOVANOVAC_1,
    ): 'https://datalabeling-dp.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.DATALABELING_DP,
        Region.EU_MADRID_1,
    ): 'https://datalabeling-dp.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.EU_MADRID_3,
    ): 'https://datalabeling-dp.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.EU_MARSEILLE_1,
    ): 'https://datalabeling-dp.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.EU_MILAN_1,
    ): 'https://datalabeling-dp.eu-milan-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.EU_PARIS_1,
    ): 'https://datalabeling-dp.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.EU_STOCKHOLM_1,
    ): 'https://datalabeling-dp.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.EU_TURIN_1,
    ): 'https://datalabeling-dp.eu-turin-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.EU_ZURICH_1,
    ): 'https://datalabeling-dp.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.IL_JERUSALEM_1,
    ): 'https://datalabeling-dp.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.ME_ABUDHABI_1,
    ): 'https://datalabeling-dp.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.ME_DUBAI_1,
    ): 'https://datalabeling-dp.me-dubai-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.ME_JEDDAH_1,
    ): 'https://datalabeling-dp.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.ME_RIYADH_1,
    ): 'https://datalabeling-dp.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.SA_BOGOTA_1,
    ): 'https://datalabeling-dp.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.SA_SANTIAGO_1,
    ): 'https://datalabeling-dp.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.SA_SAOPAULO_1,
    ): 'https://datalabeling-dp.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.SA_VALPARAISO_1,
    ): 'https://datalabeling-dp.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.SA_VINHEDO_1,
    ): 'https://datalabeling-dp.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.UK_CARDIFF_1,
    ): 'https://datalabeling-dp.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.UK_LONDON_1,
    ): 'https://datalabeling-dp.uk-london-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.US_ASHBURN_1,
    ): 'https://datalabeling-dp.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.US_PHOENIX_1,
    ): 'https://datalabeling-dp.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.US_SANJOSE_1,
    ): 'https://datalabeling-dp.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.MX_MONTERREY_1,
    ): 'https://datalabeling.dp.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DATALABELING_DP,
        Region.MX_QUERETARO_1,
    ): 'https://datalabeling.dp.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.AF_JOHANNESBURG_1,
    ): 'https://delegate-access-control.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.AP_BATAM_1,
    ): 'https://delegate-access-control.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.AP_CHUNCHEON_1,
    ): 'https://delegate-access-control.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.AP_HYDERABAD_1,
    ): 'https://delegate-access-control.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.AP_MELBOURNE_1,
    ): 'https://delegate-access-control.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.AP_MUMBAI_1,
    ): 'https://delegate-access-control.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.AP_OSAKA_1,
    ): 'https://delegate-access-control.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.AP_SEOUL_1,
    ): 'https://delegate-access-control.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.AP_SINGAPORE_1,
    ): 'https://delegate-access-control.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.AP_SYDNEY_1,
    ): 'https://delegate-access-control.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.AP_TOKYO_1,
    ): 'https://delegate-access-control.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.CA_MONTREAL_1,
    ): 'https://delegate-access-control.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.CA_TORONTO_1,
    ): 'https://delegate-access-control.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.EU_AMSTERDAM_1,
    ): 'https://delegate-access-control.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.EU_FRANKFURT_1,
    ): 'https://delegate-access-control.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.EU_JOVANOVAC_1,
    ): 'https://delegate-access-control.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.EU_MADRID_1,
    ): 'https://delegate-access-control.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.EU_MADRID_3,
    ): 'https://delegate-access-control.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.EU_MARSEILLE_1,
    ): 'https://delegate-access-control.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.EU_MILAN_1,
    ): 'https://delegate-access-control.eu-milan-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.EU_PARIS_1,
    ): 'https://delegate-access-control.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.EU_STOCKHOLM_1,
    ): 'https://delegate-access-control.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.EU_TURIN_1,
    ): 'https://delegate-access-control.eu-turin-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.EU_ZURICH_1,
    ): 'https://delegate-access-control.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.IL_JERUSALEM_1,
    ): 'https://delegate-access-control.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.ME_ABUDHABI_1,
    ): 'https://delegate-access-control.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.ME_DUBAI_1,
    ): 'https://delegate-access-control.me-dubai-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.ME_JEDDAH_1,
    ): 'https://delegate-access-control.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.MX_MONTERREY_1,
    ): 'https://delegate-access-control.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.MX_QUERETARO_1,
    ): 'https://delegate-access-control.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.SA_BOGOTA_1,
    ): 'https://delegate-access-control.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.SA_SANTIAGO_1,
    ): 'https://delegate-access-control.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.SA_SAOPAULO_1,
    ): 'https://delegate-access-control.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.SA_VALPARAISO_1,
    ): 'https://delegate-access-control.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.SA_VINHEDO_1,
    ): 'https://delegate-access-control.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.UK_CARDIFF_1,
    ): 'https://delegate-access-control.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.UK_LONDON_1,
    ): 'https://delegate-access-control.uk-london-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.US_ASHBURN_1,
    ): 'https://delegate-access-control.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.US_PHOENIX_1,
    ): 'https://delegate-access-control.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DELEGATE_ACCESS_CONTROL,
        Region.US_SANJOSE_1,
    ): 'https://delegate-access-control.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DEVOPS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://devops.af-johannesburg-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.AP_BATAM_1): 'https://devops.ap-batam-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.AP_CHUNCHEON_1): 'https://devops.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.AP_HYDERABAD_1): 'https://devops.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.AP_MELBOURNE_1): 'https://devops.ap-melbourne-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.AP_MUMBAI_1): 'https://devops.ap-mumbai-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.AP_OSAKA_1): 'https://devops.ap-osaka-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.AP_SEOUL_1): 'https://devops.ap-seoul-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.AP_SINGAPORE_1): 'https://devops.ap-singapore-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.AP_SINGAPORE_2): 'https://devops.ap-singapore-2.oci.oraclecloud.com',
    (Service.DEVOPS, Region.AP_SYDNEY_1): 'https://devops.ap-sydney-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.AP_TOKYO_1): 'https://devops.ap-tokyo-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.CA_MONTREAL_1): 'https://devops.ca-montreal-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.CA_TORONTO_1): 'https://devops.ca-toronto-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.EU_AMSTERDAM_1): 'https://devops.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.EU_FRANKFURT_1): 'https://devops.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.EU_JOVANOVAC_1): 'https://devops.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.DEVOPS, Region.EU_MADRID_1): 'https://devops.eu-madrid-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.EU_MADRID_3): 'https://devops.eu-madrid-3.oci.oraclecloud.com',
    (Service.DEVOPS, Region.EU_MARSEILLE_1): 'https://devops.eu-marseille-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.EU_MILAN_1): 'https://devops.eu-milan-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.EU_PARIS_1): 'https://devops.eu-paris-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.EU_STOCKHOLM_1): 'https://devops.eu-stockholm-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.EU_TURIN_1): 'https://devops.eu-turin-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.EU_ZURICH_1): 'https://devops.eu-zurich-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.IL_JERUSALEM_1): 'https://devops.il-jerusalem-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.ME_ABUDHABI_1): 'https://devops.me-abudhabi-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.ME_DUBAI_1): 'https://devops.me-dubai-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.ME_JEDDAH_1): 'https://devops.me-jeddah-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.ME_RIYADH_1): 'https://devops.me-riyadh-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.MX_MONTERREY_1): 'https://devops.mx-monterrey-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.MX_QUERETARO_1): 'https://devops.mx-queretaro-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.SA_BOGOTA_1): 'https://devops.sa-bogota-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.SA_SANTIAGO_1): 'https://devops.sa-santiago-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.SA_SAOPAULO_1): 'https://devops.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.SA_VINHEDO_1): 'https://devops.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.UK_CARDIFF_1): 'https://devops.uk-cardiff-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.UK_LONDON_1): 'https://devops.uk-london-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.US_ASHBURN_1): 'https://devops.us-ashburn-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.US_CHICAGO_1): 'https://devops.us-chicago-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.US_PHOENIX_1): 'https://devops.us-phoenix-1.oci.oraclecloud.com',
    (Service.DEVOPS, Region.US_SANJOSE_1): 'https://devops.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AF_JOHANNESBURG_1,
    ): 'https://digitalassistant-api.af-johannesburg-1.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AP_BATAM_1,
    ): 'https://digitalassistant-api.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AP_CHUNCHEON_1,
    ): 'https://digitalassistant-api.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AP_HYDERABAD_1,
    ): 'https://digitalassistant-api.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AP_MELBOURNE_1,
    ): 'https://digitalassistant-api.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AP_MUMBAI_1,
    ): 'https://digitalassistant-api.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AP_OSAKA_1,
    ): 'https://digitalassistant-api.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AP_SEOUL_1,
    ): 'https://digitalassistant-api.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AP_SINGAPORE_1,
    ): 'https://digitalassistant-api.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AP_SINGAPORE_2,
    ): 'https://digitalassistant-api.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AP_SYDNEY_1,
    ): 'https://digitalassistant-api.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.AP_TOKYO_1,
    ): 'https://digitalassistant-api.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.CA_MONTREAL_1,
    ): 'https://digitalassistant-api.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.CA_TORONTO_1,
    ): 'https://digitalassistant-api.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.EU_AMSTERDAM_1,
    ): 'https://digitalassistant-api.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.EU_FRANKFURT_1,
    ): 'https://digitalassistant-api.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.EU_JOVANOVAC_1,
    ): 'https://digitalassistant-api.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.EU_MADRID_1,
    ): 'https://digitalassistant-api.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.EU_MADRID_3,
    ): 'https://digitalassistant-api.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.EU_MARSEILLE_1,
    ): 'https://digitalassistant-api.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.EU_MILAN_1,
    ): 'https://digitalassistant-api.eu-milan-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.EU_PARIS_1,
    ): 'https://digitalassistant-api.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.EU_STOCKHOLM_1,
    ): 'https://digitalassistant-api.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.EU_TURIN_1,
    ): 'https://digitalassistant-api.eu-turin-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.EU_ZURICH_1,
    ): 'https://digitalassistant-api.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.IL_JERUSALEM_1,
    ): 'https://digitalassistant-api.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.ME_ABUDHABI_1,
    ): 'https://digitalassistant-api.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.ME_DUBAI_1,
    ): 'https://digitalassistant-api.me-dubai-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.ME_JEDDAH_1,
    ): 'https://digitalassistant-api.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.ME_RIYADH_1,
    ): 'https://digitalassistant-api.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.MX_MONTERREY_1,
    ): 'https://digitalassistant-api.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.MX_QUERETARO_1,
    ): 'https://digitalassistant-api.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.SA_BOGOTA_1,
    ): 'https://digitalassistant-api.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.SA_SANTIAGO_1,
    ): 'https://digitalassistant-api.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.SA_SAOPAULO_1,
    ): 'https://digitalassistant-api.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.SA_VALPARAISO_1,
    ): 'https://digitalassistant-api.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.SA_VINHEDO_1,
    ): 'https://digitalassistant-api.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.UK_CARDIFF_1,
    ): 'https://digitalassistant-api.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.UK_LONDON_1,
    ): 'https://digitalassistant-api.uk-london-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.US_ASHBURN_1,
    ): 'https://digitalassistant-api.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.US_PHOENIX_1,
    ): 'https://digitalassistant-api.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DIGITAL_ASSISTANT,
        Region.US_SANJOSE_1,
    ): 'https://digitalassistant-api.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AF_JOHANNESBURG_1,
    ): 'https://disaster-recovery.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AP_BATAM_1,
    ): 'https://disaster-recovery.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AP_CHUNCHEON_1,
    ): 'https://disaster-recovery.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AP_HYDERABAD_1,
    ): 'https://disaster-recovery.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AP_MELBOURNE_1,
    ): 'https://disaster-recovery.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AP_MUMBAI_1,
    ): 'https://disaster-recovery.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AP_OSAKA_1,
    ): 'https://disaster-recovery.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AP_SEOUL_1,
    ): 'https://disaster-recovery.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AP_SINGAPORE_1,
    ): 'https://disaster-recovery.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AP_SINGAPORE_2,
    ): 'https://disaster-recovery.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AP_SYDNEY_1,
    ): 'https://disaster-recovery.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.AP_TOKYO_1,
    ): 'https://disaster-recovery.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.CA_MONTREAL_1,
    ): 'https://disaster-recovery.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.CA_TORONTO_1,
    ): 'https://disaster-recovery.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.EU_AMSTERDAM_1,
    ): 'https://disaster-recovery.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.EU_FRANKFURT_1,
    ): 'https://disaster-recovery.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.EU_MADRID_1,
    ): 'https://disaster-recovery.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.EU_MADRID_3,
    ): 'https://disaster-recovery.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.EU_MARSEILLE_1,
    ): 'https://disaster-recovery.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.EU_MILAN_1,
    ): 'https://disaster-recovery.eu-milan-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.EU_PARIS_1,
    ): 'https://disaster-recovery.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.EU_STOCKHOLM_1,
    ): 'https://disaster-recovery.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.EU_TURIN_1,
    ): 'https://disaster-recovery.eu-turin-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.EU_ZURICH_1,
    ): 'https://disaster-recovery.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.IL_JERUSALEM_1,
    ): 'https://disaster-recovery.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.ME_ABUDHABI_1,
    ): 'https://disaster-recovery.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.ME_DUBAI_1,
    ): 'https://disaster-recovery.me-dubai-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.ME_JEDDAH_1,
    ): 'https://disaster-recovery.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.ME_RIYADH_1,
    ): 'https://disaster-recovery.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.MX_MONTERREY_1,
    ): 'https://disaster-recovery.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.MX_QUERETARO_1,
    ): 'https://disaster-recovery.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.SA_BOGOTA_1,
    ): 'https://disaster-recovery.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.SA_SANTIAGO_1,
    ): 'https://disaster-recovery.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.SA_SAOPAULO_1,
    ): 'https://disaster-recovery.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.SA_VALPARAISO_1,
    ): 'https://disaster-recovery.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.SA_VINHEDO_1,
    ): 'https://disaster-recovery.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.UK_CARDIFF_1,
    ): 'https://disaster-recovery.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.UK_LONDON_1,
    ): 'https://disaster-recovery.uk-london-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.US_ASHBURN_1,
    ): 'https://disaster-recovery.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.US_CHICAGO_1,
    ): 'https://disaster-recovery.us-chicago-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.US_PHOENIX_1,
    ): 'https://disaster-recovery.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DISASTER_RECOVERY,
        Region.US_SANJOSE_1,
    ): 'https://disaster-recovery.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://mediaservices.af-johannesburg-1.oci.oraclecloud.com',
    (Service.DMS, Region.AP_BATAM_1): 'https://mediaservices.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.AP_CHUNCHEON_1,
    ): 'https://mediaservices.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.AP_HYDERABAD_1,
    ): 'https://mediaservices.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.AP_MELBOURNE_1,
    ): 'https://mediaservices.ap-melbourne-1.oci.oraclecloud.com',
    (Service.DMS, Region.AP_MUMBAI_1): 'https://mediaservices.ap-mumbai-1.oci.oraclecloud.com',
    (Service.DMS, Region.AP_OSAKA_1): 'https://mediaservices.ap-osaka-1.oci.oraclecloud.com',
    (Service.DMS, Region.AP_SEOUL_1): 'https://mediaservices.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.AP_SINGAPORE_1,
    ): 'https://mediaservices.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.AP_SINGAPORE_2,
    ): 'https://mediaservices.ap-singapore-2.oci.oraclecloud.com',
    (Service.DMS, Region.AP_SYDNEY_1): 'https://mediaservices.ap-sydney-1.oci.oraclecloud.com',
    (Service.DMS, Region.AP_TOKYO_1): 'https://mediaservices.ap-tokyo-1.oci.oraclecloud.com',
    (Service.DMS, Region.CA_MONTREAL_1): 'https://mediaservices.ca-montreal-1.oci.oraclecloud.com',
    (Service.DMS, Region.CA_TORONTO_1): 'https://mediaservices.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.EU_AMSTERDAM_1,
    ): 'https://mediaservices.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.EU_FRANKFURT_1,
    ): 'https://mediaservices.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.EU_JOVANOVAC_1,
    ): 'https://mediaservices.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.DMS, Region.EU_MADRID_1): 'https://mediaservices.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.EU_MARSEILLE_1,
    ): 'https://mediaservices.eu-marseille-1.oci.oraclecloud.com',
    (Service.DMS, Region.EU_MILAN_1): 'https://mediaservices.eu-milan-1.oci.oraclecloud.com',
    (Service.DMS, Region.EU_PARIS_1): 'https://mediaservices.eu-paris-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.EU_STOCKHOLM_1,
    ): 'https://mediaservices.eu-stockholm-1.oci.oraclecloud.com',
    (Service.DMS, Region.EU_ZURICH_1): 'https://mediaservices.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.IL_JERUSALEM_1,
    ): 'https://mediaservices.il-jerusalem-1.oci.oraclecloud.com',
    (Service.DMS, Region.ME_ABUDHABI_1): 'https://mediaservices.me-abudhabi-1.oci.oraclecloud.com',
    (Service.DMS, Region.ME_DUBAI_1): 'https://mediaservices.me-dubai-1.oci.oraclecloud.com',
    (Service.DMS, Region.ME_JEDDAH_1): 'https://mediaservices.me-jeddah-1.oci.oraclecloud.com',
    (Service.DMS, Region.ME_RIYADH_1): 'https://mediaservices.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.MX_MONTERREY_1,
    ): 'https://mediaservices.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.MX_QUERETARO_1,
    ): 'https://mediaservices.mx-queretaro-1.oci.oraclecloud.com',
    (Service.DMS, Region.SA_BOGOTA_1): 'https://mediaservices.sa-bogota-1.oci.oraclecloud.com',
    (Service.DMS, Region.SA_SANTIAGO_1): 'https://mediaservices.sa-santiago-1.oci.oraclecloud.com',
    (Service.DMS, Region.SA_SAOPAULO_1): 'https://mediaservices.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DMS,
        Region.SA_VALPARAISO_1,
    ): 'https://mediaservices.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.DMS, Region.SA_VINHEDO_1): 'https://mediaservices.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.DMS, Region.UK_CARDIFF_1): 'https://mediaservices.uk-cardiff-1.oci.oraclecloud.com',
    (Service.DMS, Region.UK_LONDON_1): 'https://mediaservices.uk-london-1.oci.oraclecloud.com',
    (Service.DMS, Region.US_ASHBURN_1): 'https://mediaservices.us-ashburn-1.oci.oraclecloud.com',
    (Service.DMS, Region.US_PHOENIX_1): 'https://mediaservices.us-phoenix-1.oci.oraclecloud.com',
    (Service.DMS, Region.US_SANJOSE_1): 'https://mediaservices.us-sanjose-1.oci.oraclecloud.com',
    (Service.DNS, Region.AF_JOHANNESBURG_1): 'https://dns.af-johannesburg-1.oci.oraclecloud.com',
    (Service.DNS, Region.AP_BATAM_1): 'https://dns.ap-batam-1.oci.oraclecloud.com',
    (Service.DNS, Region.AP_CHUNCHEON_1): 'https://dns.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.DNS, Region.AP_HYDERABAD_1): 'https://dns.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.DNS, Region.AP_MELBOURNE_1): 'https://dns.ap-melbourne-1.oci.oraclecloud.com',
    (Service.DNS, Region.AP_MUMBAI_1): 'https://dns.ap-mumbai-1.oci.oraclecloud.com',
    (Service.DNS, Region.AP_OSAKA_1): 'https://dns.ap-osaka-1.oci.oraclecloud.com',
    (Service.DNS, Region.AP_SEOUL_1): 'https://dns.ap-seoul-1.oci.oraclecloud.com',
    (Service.DNS, Region.AP_SINGAPORE_1): 'https://dns.ap-singapore-1.oci.oraclecloud.com',
    (Service.DNS, Region.AP_SINGAPORE_2): 'https://dns.ap-singapore-2.oci.oraclecloud.com',
    (Service.DNS, Region.AP_SYDNEY_1): 'https://dns.ap-sydney-1.oci.oraclecloud.com',
    (Service.DNS, Region.AP_TOKYO_1): 'https://dns.ap-tokyo-1.oci.oraclecloud.com',
    (Service.DNS, Region.CA_MONTREAL_1): 'https://dns.ca-montreal-1.oci.oraclecloud.com',
    (Service.DNS, Region.CA_TORONTO_1): 'https://dns.ca-toronto-1.oci.oraclecloud.com',
    (Service.DNS, Region.EU_AMSTERDAM_1): 'https://dns.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.DNS, Region.EU_FRANKFURT_1): 'https://dns.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.DNS, Region.EU_JOVANOVAC_1): 'https://dns.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.DNS, Region.EU_MADRID_1): 'https://dns.eu-madrid-1.oci.oraclecloud.com',
    (Service.DNS, Region.EU_MADRID_3): 'https://dns.eu-madrid-3.oci.oraclecloud.com',
    (Service.DNS, Region.EU_MARSEILLE_1): 'https://dns.eu-marseille-1.oci.oraclecloud.com',
    (Service.DNS, Region.EU_MILAN_1): 'https://dns.eu-milan-1.oci.oraclecloud.com',
    (Service.DNS, Region.EU_PARIS_1): 'https://dns.eu-paris-1.oci.oraclecloud.com',
    (Service.DNS, Region.EU_STOCKHOLM_1): 'https://dns.eu-stockholm-1.oci.oraclecloud.com',
    (Service.DNS, Region.EU_TURIN_1): 'https://dns.eu-turin-1.oci.oraclecloud.com',
    (Service.DNS, Region.EU_ZURICH_1): 'https://dns.eu-zurich-1.oci.oraclecloud.com',
    (Service.DNS, Region.IL_JERUSALEM_1): 'https://dns.il-jerusalem-1.oci.oraclecloud.com',
    (Service.DNS, Region.ME_ABUDHABI_1): 'https://dns.me-abudhabi-1.oci.oraclecloud.com',
    (Service.DNS, Region.ME_DUBAI_1): 'https://dns.me-dubai-1.oci.oraclecloud.com',
    (Service.DNS, Region.ME_JEDDAH_1): 'https://dns.me-jeddah-1.oci.oraclecloud.com',
    (Service.DNS, Region.ME_RIYADH_1): 'https://dns.me-riyadh-1.oci.oraclecloud.com',
    (Service.DNS, Region.MX_MONTERREY_1): 'https://dns.mx-monterrey-1.oci.oraclecloud.com',
    (Service.DNS, Region.MX_QUERETARO_1): 'https://dns.mx-queretaro-1.oci.oraclecloud.com',
    (Service.DNS, Region.SA_BOGOTA_1): 'https://dns.sa-bogota-1.oci.oraclecloud.com',
    (Service.DNS, Region.SA_SANTIAGO_1): 'https://dns.sa-santiago-1.oci.oraclecloud.com',
    (Service.DNS, Region.SA_SAOPAULO_1): 'https://dns.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.DNS, Region.SA_VALPARAISO_1): 'https://dns.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.DNS, Region.SA_VINHEDO_1): 'https://dns.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.DNS, Region.UK_CARDIFF_1): 'https://dns.uk-cardiff-1.oci.oraclecloud.com',
    (Service.DNS, Region.UK_LONDON_1): 'https://dns.uk-london-1.oci.oraclecloud.com',
    (Service.DNS, Region.US_ASHBURN_1): 'https://dns.us-ashburn-1.oci.oraclecloud.com',
    (Service.DNS, Region.US_CHICAGO_1): 'https://dns.us-chicago-1.oci.oraclecloud.com',
    (Service.DNS, Region.US_PHOENIX_1): 'https://dns.us-phoenix-1.oci.oraclecloud.com',
    (Service.DNS, Region.US_SANJOSE_1): 'https://dns.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AF_JOHANNESBURG_1,
    ): 'https://document.aiservice.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AP_BATAM_1,
    ): 'https://document.aiservice.ap-batam-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AP_CHUNCHEON_1,
    ): 'https://document.aiservice.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AP_HYDERABAD_1,
    ): 'https://document.aiservice.ap-hyderabad-1.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AP_MELBOURNE_1,
    ): 'https://document.aiservice.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AP_MUMBAI_1,
    ): 'https://document.aiservice.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AP_OSAKA_1,
    ): 'https://document.aiservice.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AP_SEOUL_1,
    ): 'https://document.aiservice.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AP_SINGAPORE_1,
    ): 'https://document.aiservice.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AP_SINGAPORE_2,
    ): 'https://document.aiservice.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AP_SYDNEY_1,
    ): 'https://document.aiservice.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.AP_TOKYO_1,
    ): 'https://document.aiservice.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.CA_MONTREAL_1,
    ): 'https://document.aiservice.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.CA_TORONTO_1,
    ): 'https://document.aiservice.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.EU_AMSTERDAM_1,
    ): 'https://document.aiservice.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.EU_FRANKFURT_1,
    ): 'https://document.aiservice.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.EU_MARSEILLE_1,
    ): 'https://document.aiservice.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.EU_MILAN_1,
    ): 'https://document.aiservice.eu-milan-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.EU_STOCKHOLM_1,
    ): 'https://document.aiservice.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.EU_ZURICH_1,
    ): 'https://document.aiservice.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.IL_JERUSALEM_1,
    ): 'https://document.aiservice.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.ME_ABUDHABI_1,
    ): 'https://document.aiservice.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.ME_DUBAI_1,
    ): 'https://document.aiservice.me-dubai-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.ME_JEDDAH_1,
    ): 'https://document.aiservice.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.ME_RIYADH_1,
    ): 'https://document.aiservice.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.MX_MONTERREY_1,
    ): 'https://document.aiservice.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.MX_QUERETARO_1,
    ): 'https://document.aiservice.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.SA_BOGOTA_1,
    ): 'https://document.aiservice.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.SA_SANTIAGO_1,
    ): 'https://document.aiservice.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.SA_SAOPAULO_1,
    ): 'https://document.aiservice.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.SA_VALPARAISO_1,
    ): 'https://document.aiservice.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.SA_VINHEDO_1,
    ): 'https://document.aiservice.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.UK_CARDIFF_1,
    ): 'https://document.aiservice.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.UK_LONDON_1,
    ): 'https://document.aiservice.uk-london-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.US_ASHBURN_1,
    ): 'https://document.aiservice.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.US_CHICAGO_1,
    ): 'https://document.aiservice.us-chicago-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.US_PHOENIX_1,
    ): 'https://document.aiservice.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.DOCUMENT_UNDERSTANDING,
        Region.US_SANJOSE_1,
    ): 'https://document.aiservice.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.EDSFU,
        Region.AF_JOHANNESBURG_1,
    ): 'https://fleet-software-update.af-johannesburg-1.oraclecloud.com',
    (Service.EDSFU, Region.AP_BATAM_1): 'https://fleet-software-update.ap-batam-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.AP_CHUNCHEON_1,
    ): 'https://fleet-software-update.ap-chuncheon-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.AP_HYDERABAD_1,
    ): 'https://fleet-software-update.ap-hyderabad-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.AP_MELBOURNE_1,
    ): 'https://fleet-software-update.ap-melbourne-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.AP_MUMBAI_1,
    ): 'https://fleet-software-update.ap-mumbai-1.oraclecloud.com',
    (Service.EDSFU, Region.AP_OSAKA_1): 'https://fleet-software-update.ap-osaka-1.oraclecloud.com',
    (Service.EDSFU, Region.AP_SEOUL_1): 'https://fleet-software-update.ap-seoul-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.AP_SINGAPORE_1,
    ): 'https://fleet-software-update.ap-singapore-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.AP_SYDNEY_1,
    ): 'https://fleet-software-update.ap-sydney-1.oraclecloud.com',
    (Service.EDSFU, Region.AP_TOKYO_1): 'https://fleet-software-update.ap-tokyo-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.CA_MONTREAL_1,
    ): 'https://fleet-software-update.ca-montreal-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.CA_TORONTO_1,
    ): 'https://fleet-software-update.ca-toronto-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.EU_AMSTERDAM_1,
    ): 'https://fleet-software-update.eu-amsterdam-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.EU_FRANKFURT_1,
    ): 'https://fleet-software-update.eu-frankfurt-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.EU_MADRID_1,
    ): 'https://fleet-software-update.eu-madrid-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.EU_MADRID_3,
    ): 'https://fleet-software-update.eu-madrid-3.oraclecloud.com',
    (
        Service.EDSFU,
        Region.EU_MARSEILLE_1,
    ): 'https://fleet-software-update.eu-marseille-1.oraclecloud.com',
    (Service.EDSFU, Region.EU_MILAN_1): 'https://fleet-software-update.eu-milan-1.oraclecloud.com',
    (Service.EDSFU, Region.EU_PARIS_1): 'https://fleet-software-update.eu-paris-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.EU_STOCKHOLM_1,
    ): 'https://fleet-software-update.eu-stockholm-1.oraclecloud.com',
    (Service.EDSFU, Region.EU_TURIN_1): 'https://fleet-software-update.eu-turin-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.EU_ZURICH_1,
    ): 'https://fleet-software-update.eu-zurich-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.IL_JERUSALEM_1,
    ): 'https://fleet-software-update.il-jerusalem-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.ME_ABUDHABI_1,
    ): 'https://fleet-software-update.me-abudhabi-1.oraclecloud.com',
    (Service.EDSFU, Region.ME_DUBAI_1): 'https://fleet-software-update.me-dubai-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.ME_JEDDAH_1,
    ): 'https://fleet-software-update.me-jeddah-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.MX_QUERETARO_1,
    ): 'https://fleet-software-update.mx-queretaro-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.SA_SAOPAULO_1,
    ): 'https://fleet-software-update.sa-saopaulo-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.SA_VINHEDO_1,
    ): 'https://fleet-software-update.sa-vinhedo-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.UK_CARDIFF_1,
    ): 'https://fleet-software-update.uk-cardiff-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.UK_LONDON_1,
    ): 'https://fleet-software-update.uk-london-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.US_ASHBURN_1,
    ): 'https://fleet-software-update.us-ashburn-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.US_PHOENIX_1,
    ): 'https://fleet-software-update.us-phoenix-1.oraclecloud.com',
    (
        Service.EDSFU,
        Region.US_SANJOSE_1,
    ): 'https://fleet-software-update.us-sanjose-1.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.AF_JOHANNESBURG_1,
    ): 'https://ctrl.email.af-johannesburg-1.oci.oraclecloud.com',
    (Service.EMAILDELIVERY, Region.AP_BATAM_1): 'https://ctrl.email.ap-batam-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.AP_CHUNCHEON_1,
    ): 'https://ctrl.email.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.AP_HYDERABAD_1,
    ): 'https://ctrl.email.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.AP_MELBOURNE_1,
    ): 'https://ctrl.email.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.AP_MUMBAI_1,
    ): 'https://ctrl.email.ap-mumbai-1.oci.oraclecloud.com',
    (Service.EMAILDELIVERY, Region.AP_OSAKA_1): 'https://ctrl.email.ap-osaka-1.oci.oraclecloud.com',
    (Service.EMAILDELIVERY, Region.AP_SEOUL_1): 'https://ctrl.email.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.AP_SINGAPORE_1,
    ): 'https://ctrl.email.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.AP_SINGAPORE_2,
    ): 'https://ctrl.email.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.AP_SYDNEY_1,
    ): 'https://ctrl.email.ap-sydney-1.oci.oraclecloud.com',
    (Service.EMAILDELIVERY, Region.AP_TOKYO_1): 'https://ctrl.email.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.CA_MONTREAL_1,
    ): 'https://ctrl.email.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.CA_TORONTO_1,
    ): 'https://ctrl.email.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.EU_FRANKFURT_1,
    ): 'https://ctrl.email.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.EU_JOVANOVAC_1,
    ): 'https://ctrl.email.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.EMAILDELIVERY,
        Region.EU_MADRID_1,
    ): 'https://ctrl.email.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.EU_MADRID_3,
    ): 'https://ctrl.email.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.EU_MARSEILLE_1,
    ): 'https://ctrl.email.eu-marseille-1.oci.oraclecloud.com',
    (Service.EMAILDELIVERY, Region.EU_MILAN_1): 'https://ctrl.email.eu-milan-1.oci.oraclecloud.com',
    (Service.EMAILDELIVERY, Region.EU_PARIS_1): 'https://ctrl.email.eu-paris-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.EU_STOCKHOLM_1,
    ): 'https://ctrl.email.eu-stockholm-1.oci.oraclecloud.com',
    (Service.EMAILDELIVERY, Region.EU_TURIN_1): 'https://ctrl.email.eu-turin-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.EU_ZURICH_1,
    ): 'https://ctrl.email.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.IL_JERUSALEM_1,
    ): 'https://ctrl.email.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.ME_ABUDHABI_1,
    ): 'https://ctrl.email.me-abudhabi-1.oci.oraclecloud.com',
    (Service.EMAILDELIVERY, Region.ME_DUBAI_1): 'https://ctrl.email.me-dubai-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.ME_JEDDAH_1,
    ): 'https://ctrl.email.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.ME_RIYADH_1,
    ): 'https://ctrl.email.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.MX_MONTERREY_1,
    ): 'https://ctrl.email.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.MX_QUERETARO_1,
    ): 'https://ctrl.email.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.SA_BOGOTA_1,
    ): 'https://ctrl.email.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.SA_SANTIAGO_1,
    ): 'https://ctrl.email.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.SA_SAOPAULO_1,
    ): 'https://ctrl.email.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.SA_VALPARAISO_1,
    ): 'https://ctrl.email.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.SA_VINHEDO_1,
    ): 'https://ctrl.email.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.UK_CARDIFF_1,
    ): 'https://ctrl.email.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.UK_LONDON_1,
    ): 'https://ctrl.email.uk-london-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.US_ASHBURN_1,
    ): 'https://ctrl.email.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.US_CHICAGO_1,
    ): 'https://ctrl.email.us-chicago-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.US_PHOENIX_1,
    ): 'https://ctrl.email.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.EMAILDELIVERY,
        Region.US_SANJOSE_1,
    ): 'https://ctrl.email.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.EVENTS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://events.af-johannesburg-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.AP_BATAM_1): 'https://events.ap-batam-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.AP_CHUNCHEON_1): 'https://events.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.AP_HYDERABAD_1): 'https://events.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.AP_MELBOURNE_1): 'https://events.ap-melbourne-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.AP_MUMBAI_1): 'https://events.ap-mumbai-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.AP_OSAKA_1): 'https://events.ap-osaka-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.AP_SEOUL_1): 'https://events.ap-seoul-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.AP_SINGAPORE_1): 'https://events.ap-singapore-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.AP_SINGAPORE_2): 'https://events.ap-singapore-2.oci.oraclecloud.com',
    (Service.EVENTS, Region.AP_SYDNEY_1): 'https://events.ap-sydney-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.AP_TOKYO_1): 'https://events.ap-tokyo-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.CA_MONTREAL_1): 'https://events.ca-montreal-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.CA_TORONTO_1): 'https://events.ca-toronto-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.EU_AMSTERDAM_1): 'https://events.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.EU_FRANKFURT_1): 'https://events.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.EU_JOVANOVAC_1): 'https://events.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.EVENTS, Region.EU_MADRID_1): 'https://events.eu-madrid-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.EU_MADRID_3): 'https://events.eu-madrid-3.oci.oraclecloud.com',
    (Service.EVENTS, Region.EU_MARSEILLE_1): 'https://events.eu-marseille-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.EU_MILAN_1): 'https://events.eu-milan-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.EU_PARIS_1): 'https://events.eu-paris-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.EU_STOCKHOLM_1): 'https://events.eu-stockholm-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.EU_TURIN_1): 'https://events.eu-turin-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.EU_ZURICH_1): 'https://events.eu-zurich-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.IL_JERUSALEM_1): 'https://events.il-jerusalem-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.ME_ABUDHABI_1): 'https://events.me-abudhabi-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.ME_DUBAI_1): 'https://events.me-dubai-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.ME_JEDDAH_1): 'https://events.me-jeddah-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.ME_RIYADH_1): 'https://events.me-riyadh-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.MX_MONTERREY_1): 'https://events.mx-monterrey-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.MX_QUERETARO_1): 'https://events.mx-queretaro-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.SA_BOGOTA_1): 'https://events.sa-bogota-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.SA_SANTIAGO_1): 'https://events.sa-santiago-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.SA_SAOPAULO_1): 'https://events.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.SA_VALPARAISO_1): 'https://events.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.SA_VINHEDO_1): 'https://events.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.UK_CARDIFF_1): 'https://events.uk-cardiff-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.UK_LONDON_1): 'https://events.uk-london-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.US_ASHBURN_1): 'https://events.us-ashburn-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.US_CHICAGO_1): 'https://events.us-chicago-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.US_PHOENIX_1): 'https://events.us-phoenix-1.oci.oraclecloud.com',
    (Service.EVENTS, Region.US_SANJOSE_1): 'https://events.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://filestorage.af-johannesburg-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.AP_BATAM_1): 'https://filestorage.ap-batam-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.AP_CHUNCHEON_1,
    ): 'https://filestorage.ap-chuncheon-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.AP_HYDERABAD_1,
    ): 'https://filestorage.ap-hyderabad-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.AP_MELBOURNE_1,
    ): 'https://filestorage.ap-melbourne-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.AP_MUMBAI_1): 'https://filestorage.ap-mumbai-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.AP_OSAKA_1): 'https://filestorage.ap-osaka-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.AP_SEOUL_1): 'https://filestorage.ap-seoul-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.AP_SINGAPORE_1,
    ): 'https://filestorage.ap-singapore-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.AP_SINGAPORE_2,
    ): 'https://filestorage.ap-singapore-2.oraclecloud.com',
    (Service.FILESTORAGE, Region.AP_SYDNEY_1): 'https://filestorage.ap-sydney-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.AP_TOKYO_1): 'https://filestorage.ap-tokyo-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.CA_MONTREAL_1,
    ): 'https://filestorage.ca-montreal-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.CA_TORONTO_1): 'https://filestorage.ca-toronto-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.EU_AMSTERDAM_1,
    ): 'https://filestorage.eu-amsterdam-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.EU_FRANKFURT_1,
    ): 'https://filestorage.eu-frankfurt-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.EU_JOVANOVAC_1,
    ): 'https://filestorage.eu-jovanovac-1.oraclecloud20.com',
    (Service.FILESTORAGE, Region.EU_MADRID_1): 'https://filestorage.eu-madrid-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.EU_MADRID_3): 'https://filestorage.eu-madrid-3.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.EU_MARSEILLE_1,
    ): 'https://filestorage.eu-marseille-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.EU_MILAN_1): 'https://filestorage.eu-milan-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.EU_PARIS_1): 'https://filestorage.eu-paris-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.EU_STOCKHOLM_1,
    ): 'https://filestorage.eu-stockholm-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.EU_TURIN_1): 'https://filestorage.eu-turin-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.EU_ZURICH_1): 'https://filestorage.eu-zurich-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.IL_JERUSALEM_1,
    ): 'https://filestorage.il-jerusalem-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.ME_ABUDHABI_1,
    ): 'https://filestorage.me-abudhabi-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.ME_DUBAI_1): 'https://filestorage.me-dubai-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.ME_JEDDAH_1): 'https://filestorage.me-jeddah-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.ME_RIYADH_1): 'https://filestorage.me-riyadh-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.MX_MONTERREY_1,
    ): 'https://filestorage.mx-monterrey-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.MX_QUERETARO_1,
    ): 'https://filestorage.mx-queretaro-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.SA_BOGOTA_1): 'https://filestorage.sa-bogota-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.SA_SANTIAGO_1,
    ): 'https://filestorage.sa-santiago-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.SA_SAOPAULO_1,
    ): 'https://filestorage.sa-saopaulo-1.oraclecloud.com',
    (
        Service.FILESTORAGE,
        Region.SA_VALPARAISO_1,
    ): 'https://filestorage.sa-valparaiso-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.SA_VINHEDO_1): 'https://filestorage.sa-vinhedo-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.UK_CARDIFF_1): 'https://filestorage.uk-cardiff-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.UK_LONDON_1): 'https://filestorage.uk-london-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.US_ASHBURN_1): 'https://filestorage.us-ashburn-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.US_CHICAGO_1): 'https://filestorage.us-chicago-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.US_PHOENIX_1): 'https://filestorage.us-phoenix-1.oraclecloud.com',
    (Service.FILESTORAGE, Region.US_SANJOSE_1): 'https://filestorage.us-sanjose-1.oraclecloud.com',
    (
        Service.FLEET_MANAGEMENT,
        Region.AP_HYDERABAD_1,
    ): 'https://fams.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.FLEET_MANAGEMENT, Region.AP_MUMBAI_1): 'https://fams.ap-mumbai-1.oci.oraclecloud.com',
    (Service.FLEET_MANAGEMENT, Region.AP_SYDNEY_1): 'https://fams.ap-sydney-1.oci.oraclecloud.com',
    (Service.FLEET_MANAGEMENT, Region.AP_TOKYO_1): 'https://fams.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.FLEET_MANAGEMENT,
        Region.CA_MONTREAL_1,
    ): 'https://fams.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.FLEET_MANAGEMENT,
        Region.CA_TORONTO_1,
    ): 'https://fams.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.FLEET_MANAGEMENT,
        Region.EU_AMSTERDAM_1,
    ): 'https://fams.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.FLEET_MANAGEMENT,
        Region.EU_FRANKFURT_1,
    ): 'https://fams.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.FLEET_MANAGEMENT, Region.EU_MILAN_1): 'https://fams.eu-milan-1.oci.oraclecloud.com',
    (Service.FLEET_MANAGEMENT, Region.ME_DUBAI_1): 'https://fams.me-dubai-1.oci.oraclecloud.com',
    (Service.FLEET_MANAGEMENT, Region.ME_JEDDAH_1): 'https://fams.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.FLEET_MANAGEMENT,
        Region.SA_SAOPAULO_1,
    ): 'https://fams.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.FLEET_MANAGEMENT,
        Region.SA_VINHEDO_1,
    ): 'https://fams.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.FLEET_MANAGEMENT,
        Region.UK_CARDIFF_1,
    ): 'https://fams.uk-cardiff-1.oci.oraclecloud.com',
    (Service.FLEET_MANAGEMENT, Region.UK_LONDON_1): 'https://fams.uk-london-1.oci.oraclecloud.com',
    (
        Service.FLEET_MANAGEMENT,
        Region.US_ASHBURN_1,
    ): 'https://fams.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.FLEET_MANAGEMENT,
        Region.US_PHOENIX_1,
    ): 'https://fams.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://functions.af-johannesburg-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.AP_BATAM_1): 'https://functions.ap-batam-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.AP_CHUNCHEON_1,
    ): 'https://functions.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.AP_HYDERABAD_1,
    ): 'https://functions.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.AP_MELBOURNE_1,
    ): 'https://functions.ap-melbourne-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.AP_MUMBAI_1): 'https://functions.ap-mumbai-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.AP_OSAKA_1): 'https://functions.ap-osaka-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.AP_SEOUL_1): 'https://functions.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.AP_SINGAPORE_1,
    ): 'https://functions.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.AP_SINGAPORE_2,
    ): 'https://functions.ap-singapore-2.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.AP_SYDNEY_1): 'https://functions.ap-sydney-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.AP_TOKYO_1): 'https://functions.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.CA_MONTREAL_1,
    ): 'https://functions.ca-montreal-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.CA_TORONTO_1): 'https://functions.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.EU_AMSTERDAM_1,
    ): 'https://functions.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.EU_FRANKFURT_1,
    ): 'https://functions.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.EU_JOVANOVAC_1,
    ): 'https://functions.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.FUNCTIONS, Region.EU_MADRID_1): 'https://functions.eu-madrid-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.EU_MADRID_3): 'https://functions.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.EU_MARSEILLE_1,
    ): 'https://functions.eu-marseille-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.EU_MILAN_1): 'https://functions.eu-milan-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.EU_PARIS_1): 'https://functions.eu-paris-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.EU_STOCKHOLM_1,
    ): 'https://functions.eu-stockholm-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.EU_TURIN_1): 'https://functions.eu-turin-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.EU_ZURICH_1): 'https://functions.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.IL_JERUSALEM_1,
    ): 'https://functions.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.ME_ABUDHABI_1,
    ): 'https://functions.me-abudhabi-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.ME_DUBAI_1): 'https://functions.me-dubai-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.ME_JEDDAH_1): 'https://functions.me-jeddah-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.ME_RIYADH_1): 'https://functions.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.MX_MONTERREY_1,
    ): 'https://functions.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.MX_QUERETARO_1,
    ): 'https://functions.mx-queretaro-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.SA_BOGOTA_1): 'https://functions.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.SA_SANTIAGO_1,
    ): 'https://functions.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.SA_SAOPAULO_1,
    ): 'https://functions.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.FUNCTIONS,
        Region.SA_VALPARAISO_1,
    ): 'https://functions.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.SA_VINHEDO_1): 'https://functions.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.UK_CARDIFF_1): 'https://functions.uk-cardiff-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.UK_LONDON_1): 'https://functions.uk-london-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.US_ASHBURN_1): 'https://functions.us-ashburn-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.US_CHICAGO_1): 'https://functions.us-chicago-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.US_PHOENIX_1): 'https://functions.us-phoenix-1.oci.oraclecloud.com',
    (Service.FUNCTIONS, Region.US_SANJOSE_1): 'https://functions.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.AP_BATAM_1,
    ): 'https://fusionapps.ap-batam-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.AP_HYDERABAD_1,
    ): 'https://fusionapps.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.AP_MELBOURNE_1,
    ): 'https://fusionapps.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.AP_MUMBAI_1,
    ): 'https://fusionapps.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.AP_OSAKA_1,
    ): 'https://fusionapps.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.AP_SEOUL_1,
    ): 'https://fusionapps.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.AP_SINGAPORE_1,
    ): 'https://fusionapps.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.AP_SINGAPORE_2,
    ): 'https://fusionapps.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.AP_SYDNEY_1,
    ): 'https://fusionapps.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.AP_TOKYO_1,
    ): 'https://fusionapps.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.CA_MONTREAL_1,
    ): 'https://fusionapps.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.CA_TORONTO_1,
    ): 'https://fusionapps.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.EU_AMSTERDAM_1,
    ): 'https://fusionapps.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.EU_FRANKFURT_1,
    ): 'https://fusionapps.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.EU_MILAN_1,
    ): 'https://fusionapps.eu-milan-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.EU_STOCKHOLM_1,
    ): 'https://fusionapps.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.EU_ZURICH_1,
    ): 'https://fusionapps.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.ME_ABUDHABI_1,
    ): 'https://fusionapps.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.ME_DUBAI_1,
    ): 'https://fusionapps.me-dubai-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.ME_JEDDAH_1,
    ): 'https://fusionapps.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.ME_RIYADH_1,
    ): 'https://fusionapps.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.MX_MONTERREY_1,
    ): 'https://fusionapps.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.MX_QUERETARO_1,
    ): 'https://fusionapps.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.SA_BOGOTA_1,
    ): 'https://fusionapps.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.SA_SANTIAGO_1,
    ): 'https://fusionapps.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.SA_SAOPAULO_1,
    ): 'https://fusionapps.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.SA_VALPARAISO_1,
    ): 'https://fusionapps.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.SA_VINHEDO_1,
    ): 'https://fusionapps.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.UK_CARDIFF_1,
    ): 'https://fusionapps.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.UK_LONDON_1,
    ): 'https://fusionapps.uk-london-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.US_ASHBURN_1,
    ): 'https://fusionapps.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.FUSION_APPLICATIONS,
        Region.US_PHOENIX_1,
    ): 'https://fusionapps.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI,
        Region.AP_HYDERABAD_1,
    ): 'https://generativeai.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI,
        Region.AP_OSAKA_1,
    ): 'https://generativeai.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI,
        Region.EU_FRANKFURT_1,
    ): 'https://generativeai.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI,
        Region.ME_DUBAI_1,
    ): 'https://generativeai.me-dubai-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI,
        Region.ME_RIYADH_1,
    ): 'https://generativeai.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI,
        Region.SA_SAOPAULO_1,
    ): 'https://generativeai.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI,
        Region.UK_LONDON_1,
    ): 'https://generativeai.uk-london-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI,
        Region.US_ASHBURN_1,
    ): 'https://generativeai.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI,
        Region.US_CHICAGO_1,
    ): 'https://generativeai.us-chicago-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI,
        Region.US_PHOENIX_1,
    ): 'https://generativeai.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS,
        Region.AP_OSAKA_1,
    ): 'https://agent.generativeai.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS,
        Region.EU_FRANKFURT_1,
    ): 'https://agent.generativeai.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS,
        Region.SA_SAOPAULO_1,
    ): 'https://agent.generativeai.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS,
        Region.UK_LONDON_1,
    ): 'https://agent.generativeai.uk-london-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS,
        Region.US_ASHBURN_1,
    ): 'https://agent.generativeai.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS,
        Region.US_CHICAGO_1,
    ): 'https://agent.generativeai.us-chicago-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS,
        Region.US_PHOENIX_1,
    ): 'https://agent.generativeai.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS_CLIENT,
        Region.AP_OSAKA_1,
    ): 'https://agent-runtime.generativeai.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS_CLIENT,
        Region.EU_FRANKFURT_1,
    ): 'https://agent-runtime.generativeai.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS_CLIENT,
        Region.SA_SAOPAULO_1,
    ): 'https://agent-runtime.generativeai.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS_CLIENT,
        Region.UK_LONDON_1,
    ): 'https://agent-runtime.generativeai.uk-london-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS_CLIENT,
        Region.US_ASHBURN_1,
    ): 'https://agent-runtime.generativeai.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS_CLIENT,
        Region.US_CHICAGO_1,
    ): 'https://agent-runtime.generativeai.us-chicago-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_AGENTS_CLIENT,
        Region.US_PHOENIX_1,
    ): 'https://agent-runtime.generativeai.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_INFERENCE,
        Region.AP_HYDERABAD_1,
    ): 'https://inference.generativeai.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_INFERENCE,
        Region.AP_OSAKA_1,
    ): 'https://inference.generativeai.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_INFERENCE,
        Region.EU_FRANKFURT_1,
    ): 'https://inference.generativeai.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_INFERENCE,
        Region.ME_DUBAI_1,
    ): 'https://inference.generativeai.me-dubai-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_INFERENCE,
        Region.ME_RIYADH_1,
    ): 'https://inference.generativeai.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_INFERENCE,
        Region.SA_SAOPAULO_1,
    ): 'https://inference.generativeai.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_INFERENCE,
        Region.UK_LONDON_1,
    ): 'https://inference.generativeai.uk-london-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_INFERENCE,
        Region.US_ASHBURN_1,
    ): 'https://inference.generativeai.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_INFERENCE,
        Region.US_CHICAGO_1,
    ): 'https://inference.generativeai.us-chicago-1.oci.oraclecloud.com',
    (
        Service.GENERATIVE_AI_INFERENCE,
        Region.US_PHOENIX_1,
    ): 'https://inference.generativeai.us-phoenix-1.oci.oraclecloud.com',
    (Service.GENERIC, Region.AF_JOHANNESBURG_1): 'https://generic.af-johannesburg-1.ocir.io',
    (Service.GENERIC, Region.AP_BATAM_1): 'https://generic.ap-batam-1.ocir.io',
    (Service.GENERIC, Region.AP_CHUNCHEON_1): 'https://generic.ap-chuncheon-1.ocir.io',
    (Service.GENERIC, Region.AP_HYDERABAD_1): 'https://generic.ap-hyderabad-1.ocir.io',
    (Service.GENERIC, Region.AP_MELBOURNE_1): 'https://generic.ap-melbourne-1.ocir.io',
    (Service.GENERIC, Region.AP_MUMBAI_1): 'https://generic.ap-mumbai-1.ocir.io',
    (Service.GENERIC, Region.AP_OSAKA_1): 'https://generic.ap-osaka-1.ocir.io',
    (Service.GENERIC, Region.AP_SEOUL_1): 'https://generic.ap-seoul-1.ocir.io',
    (Service.GENERIC, Region.AP_SINGAPORE_1): 'https://generic.ap-singapore-1.ocir.io',
    (Service.GENERIC, Region.AP_SINGAPORE_2): 'https://generic.ap-singapore-2.ocir.io',
    (Service.GENERIC, Region.AP_SYDNEY_1): 'https://generic.ap-sydney-1.ocir.io',
    (Service.GENERIC, Region.AP_TOKYO_1): 'https://generic.ap-tokyo-1.ocir.io',
    (Service.GENERIC, Region.CA_MONTREAL_1): 'https://generic.ca-montreal-1.ocir.io',
    (Service.GENERIC, Region.CA_TORONTO_1): 'https://generic.ca-toronto-1.ocir.io',
    (Service.GENERIC, Region.EU_AMSTERDAM_1): 'https://generic.eu-amsterdam-1.ocir.io',
    (Service.GENERIC, Region.EU_FRANKFURT_1): 'https://generic.eu-frankfurt-1.ocir.io',
    (
        Service.GENERIC,
        Region.EU_JOVANOVAC_1,
    ): 'https://generic.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.GENERIC, Region.EU_MADRID_1): 'https://generic.eu-madrid-1.ocir.io',
    (Service.GENERIC, Region.EU_MADRID_3): 'https://generic.eu-madrid-3.ocir.io',
    (Service.GENERIC, Region.EU_MARSEILLE_1): 'https://generic.eu-marseille-1.ocir.io',
    (Service.GENERIC, Region.EU_MILAN_1): 'https://generic.eu-milan-1.ocir.io',
    (Service.GENERIC, Region.EU_PARIS_1): 'https://generic.eu-paris-1.ocir.io',
    (Service.GENERIC, Region.EU_STOCKHOLM_1): 'https://generic.eu-stockholm-1.ocir.io',
    (Service.GENERIC, Region.EU_TURIN_1): 'https://generic.eu-turin-1.ocir.io',
    (Service.GENERIC, Region.EU_ZURICH_1): 'https://generic.eu-zurich-1.ocir.io',
    (Service.GENERIC, Region.ME_ABUDHABI_1): 'https://generic.me-abudhabi-1.ocir.io',
    (Service.GENERIC, Region.ME_DUBAI_1): 'https://generic.me-dubai-1.ocir.io',
    (Service.GENERIC, Region.ME_JEDDAH_1): 'https://generic.me-jeddah-1.ocir.io',
    (Service.GENERIC, Region.ME_RIYADH_1): 'https://generic.me-riyadh-1.ocir.io',
    (Service.GENERIC, Region.MX_MONTERREY_1): 'https://generic.mx-monterrey-1.ocir.io',
    (Service.GENERIC, Region.MX_QUERETARO_1): 'https://generic.mx-queretaro-1.ocir.io',
    (Service.GENERIC, Region.SA_BOGOTA_1): 'https://generic.sa-bogota-1.ocir.io',
    (Service.GENERIC, Region.SA_SANTIAGO_1): 'https://generic.sa-santiago-1.ocir.io',
    (Service.GENERIC, Region.SA_SAOPAULO_1): 'https://generic.sa-saopaulo-1.ocir.io',
    (Service.GENERIC, Region.SA_VALPARAISO_1): 'https://generic.sa-valparaiso-1.ocir.io',
    (Service.GENERIC, Region.SA_VINHEDO_1): 'https://generic.sa-vinhedo-1.ocir.io',
    (Service.GENERIC, Region.UK_CARDIFF_1): 'https://generic.uk-cardiff-1.ocir.io',
    (Service.GENERIC, Region.UK_LONDON_1): 'https://generic.uk-london-1.ocir.io',
    (Service.GENERIC, Region.US_ASHBURN_1): 'https://generic.us-ashburn-1.ocir.io',
    (Service.GENERIC, Region.US_CHICAGO_1): 'https://generic.us-chicago-1.ocir.io',
    (Service.GENERIC, Region.US_PHOENIX_1): 'https://generic.us-phoenix-1.ocir.io',
    (Service.GENERIC, Region.US_SANJOSE_1): 'https://generic.us-sanjose-1.ocir.io',
    (
        Service.GLOBALLY_DISTRIBUTED_DATABASE,
        Region.US_ASHBURN_1,
    ): 'https://globaldb.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://goldengate.af-johannesburg-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.AP_BATAM_1): 'https://goldengate.ap-batam-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.AP_CHUNCHEON_1,
    ): 'https://goldengate.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.AP_HYDERABAD_1,
    ): 'https://goldengate.ap-hyderabad-1.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.AP_MELBOURNE_1,
    ): 'https://goldengate.ap-melbourne-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.AP_MUMBAI_1): 'https://goldengate.ap-mumbai-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.AP_OSAKA_1): 'https://goldengate.ap-osaka-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.AP_SEOUL_1): 'https://goldengate.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.AP_SINGAPORE_1,
    ): 'https://goldengate.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.AP_SINGAPORE_2,
    ): 'https://goldengate.ap-singapore-2.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.AP_SYDNEY_1): 'https://goldengate.ap-sydney-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.AP_TOKYO_1): 'https://goldengate.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.CA_MONTREAL_1,
    ): 'https://goldengate.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.CA_TORONTO_1,
    ): 'https://goldengate.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.EU_AMSTERDAM_1,
    ): 'https://goldengate.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.EU_FRANKFURT_1,
    ): 'https://goldengate.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.EU_JOVANOVAC_1,
    ): 'https://goldengate.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.GOLDENGATE, Region.EU_MADRID_1): 'https://goldengate.eu-madrid-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.EU_MADRID_3): 'https://goldengate.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.EU_MARSEILLE_1,
    ): 'https://goldengate.eu-marseille-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.EU_MILAN_1): 'https://goldengate.eu-milan-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.EU_PARIS_1): 'https://goldengate.eu-paris-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.EU_STOCKHOLM_1,
    ): 'https://goldengate.eu-stockholm-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.EU_TURIN_1): 'https://goldengate.eu-turin-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.EU_ZURICH_1): 'https://goldengate.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.IL_JERUSALEM_1,
    ): 'https://goldengate.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.ME_ABUDHABI_1,
    ): 'https://goldengate.me-abudhabi-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.ME_DUBAI_1): 'https://goldengate.me-dubai-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.ME_JEDDAH_1): 'https://goldengate.me-jeddah-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.ME_RIYADH_1): 'https://goldengate.me-riyadh-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.SA_BOGOTA_1): 'https://goldengate.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.SA_MONTERREY_1,
    ): 'https://goldengate.sa-monterrey-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.SA_QUERETARO_1,
    ): 'https://goldengate.sa-queretaro-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.SA_SANTIAGO_1,
    ): 'https://goldengate.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.SA_SAOPAULO_1,
    ): 'https://goldengate.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.SA_VALPARAISO_1,
    ): 'https://goldengate.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.SA_VINHEDO_1,
    ): 'https://goldengate.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.UK_CARDIFF_1,
    ): 'https://goldengate.uk-cardiff-1.oci.oraclecloud.com',
    (Service.GOLDENGATE, Region.UK_LONDON_1): 'https://goldengate.uk-london-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.US_ASHBURN_1,
    ): 'https://goldengate.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.US_CHICAGO_1,
    ): 'https://goldengate.us-chicago-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.US_PHOENIX_1,
    ): 'https://goldengate.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.GOLDENGATE,
        Region.US_SANJOSE_1,
    ): 'https://goldengate.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://healthchecks.af-johannesburg-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.AP_BATAM_1): 'https://healthchecks.ap-batam-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.AP_CHUNCHEON_1,
    ): 'https://healthchecks.ap-chuncheon-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.AP_HYDERABAD_1,
    ): 'https://healthchecks.ap-hyderabad-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.AP_MELBOURNE_1,
    ): 'https://healthchecks.ap-melbourne-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.AP_MUMBAI_1): 'https://healthchecks.ap-mumbai-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.AP_OSAKA_1): 'https://healthchecks.ap-osaka-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.AP_SEOUL_1): 'https://healthchecks.ap-seoul-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.AP_SINGAPORE_1,
    ): 'https://healthchecks.ap-singapore-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.AP_SINGAPORE_2,
    ): 'https://healthchecks.ap-singapore-2.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.AP_SYDNEY_1): 'https://healthchecks.ap-sydney-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.AP_TOKYO_1): 'https://healthchecks.ap-tokyo-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.CA_MONTREAL_1,
    ): 'https://healthchecks.ca-montreal-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.CA_TORONTO_1,
    ): 'https://healthchecks.ca-toronto-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.EU_AMSTERDAM_1,
    ): 'https://healthchecks.eu-amsterdam-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.EU_FRANKFURT_1,
    ): 'https://healthchecks.eu-frankfurt-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.EU_MADRID_1): 'https://healthchecks.eu-madrid-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.EU_MADRID_3): 'https://healthchecks.eu-madrid-3.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.EU_MARSEILLE_1,
    ): 'https://healthchecks.eu-marseille-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.EU_MILAN_1): 'https://healthchecks.eu-milan-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.EU_PARIS_1): 'https://healthchecks.eu-paris-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.EU_STOCKHOLM_1,
    ): 'https://healthchecks.eu-stockholm-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.EU_TURIN_1): 'https://healthchecks.eu-turin-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.EU_ZURICH_1): 'https://healthchecks.eu-zurich-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.IL_JERUSALEM_1,
    ): 'https://healthchecks.il-jerusalem-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.ME_ABUDHABI_1,
    ): 'https://healthchecks.me-abudhabi-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.ME_DUBAI_1): 'https://healthchecks.me-dubai-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.ME_JEDDAH_1): 'https://healthchecks.me-jeddah-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.ME_RIYADH_1): 'https://healthchecks.me-riyadh-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.MX_MONTERREY_1,
    ): 'https://healthchecks.mx-monterrey-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.MX_QUERETARO_1,
    ): 'https://healthchecks.mx-queretaro-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.SA_BOGOTA_1): 'https://healthchecks.sa-bogota-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.SA_SANTIAGO_1,
    ): 'https://healthchecks.sa-santiago-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.SA_SAOPAULO_1,
    ): 'https://healthchecks.sa-saopaulo-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.SA_VALPARAISO_1,
    ): 'https://healthchecks.sa-valparaiso-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.SA_VINHEDO_1,
    ): 'https://healthchecks.sa-vinhedo-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.UK_CARDIFF_1,
    ): 'https://healthchecks.uk-cardiff-1.oraclecloud.com',
    (Service.HEALTHCHECKS, Region.UK_LONDON_1): 'https://healthchecks.uk-london-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.US_ASHBURN_1,
    ): 'https://healthchecks.us-ashburn-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.US_CHICAGO_1,
    ): 'https://healthchecks.us-chicago-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.US_PHOENIX_1,
    ): 'https://healthchecks.us-phoenix-1.oraclecloud.com',
    (
        Service.HEALTHCHECKS,
        Region.US_SANJOSE_1,
    ): 'https://healthchecks.us-sanjose-1.oraclecloud.com',
    (Service.IAAS, Region.AF_JOHANNESBURG_1): 'https://iaas.af-johannesburg-1.oraclecloud.com',
    (Service.IAAS, Region.AP_BATAM_1): 'https://iaas.ap-batam-1.oraclecloud.com',
    (Service.IAAS, Region.AP_CHUNCHEON_1): 'https://iaas.ap-chuncheon-1.oraclecloud.com',
    (Service.IAAS, Region.AP_HYDERABAD_1): 'https://iaas.ap-hyderabad-1.oraclecloud.com',
    (Service.IAAS, Region.AP_MELBOURNE_1): 'https://iaas.ap-melbourne-1.oraclecloud.com',
    (Service.IAAS, Region.AP_MUMBAI_1): 'https://iaas.ap-mumbai-1.oraclecloud.com',
    (Service.IAAS, Region.AP_OSAKA_1): 'https://iaas.ap-osaka-1.oraclecloud.com',
    (Service.IAAS, Region.AP_SEOUL_1): 'https://iaas.ap-seoul-1.oraclecloud.com',
    (Service.IAAS, Region.AP_SINGAPORE_1): 'https://iaas.ap-singapore-1.oraclecloud.com',
    (Service.IAAS, Region.AP_SINGAPORE_2): 'https://iaas.ap-singapore-2.oraclecloud.com',
    (Service.IAAS, Region.AP_SYDNEY_1): 'https://iaas.ap-sydney-1.oraclecloud.com',
    (Service.IAAS, Region.AP_TOKYO_1): 'https://iaas.ap-tokyo-1.oraclecloud.com',
    (Service.IAAS, Region.CA_MONTREAL_1): 'https://iaas.ca-montreal-1.oraclecloud.com',
    (Service.IAAS, Region.CA_TORONTO_1): 'https://iaas.ca-toronto-1.oraclecloud.com',
    (Service.IAAS, Region.EU_AMSTERDAM_1): 'https://iaas.eu-amsterdam-1.oraclecloud.com',
    (Service.IAAS, Region.EU_FRANKFURT_1): 'https://iaas.eu-frankfurt-1.oraclecloud.com',
    (Service.IAAS, Region.EU_JOVANOVAC_1): 'https://iaas.eu-jovanovac-1.oraclecloud20.com',
    (Service.IAAS, Region.EU_MADRID_1): 'https://iaas.eu-madrid-1.oraclecloud.com',
    (Service.IAAS, Region.EU_MADRID_3): 'https://iaas.eu-madrid-3.oraclecloud.com',
    (Service.IAAS, Region.EU_MARSEILLE_1): 'https://iaas.eu-marseille-1.oraclecloud.com',
    (Service.IAAS, Region.EU_MILAN_1): 'https://iaas.eu-milan-1.oraclecloud.com',
    (Service.IAAS, Region.EU_PARIS_1): 'https://iaas.eu-paris-1.oraclecloud.com',
    (Service.IAAS, Region.EU_STOCKHOLM_1): 'https://iaas.eu-stockholm-1.oraclecloud.com',
    (Service.IAAS, Region.EU_TURIN_1): 'https://iaas.eu-turin-1.oraclecloud.com',
    (Service.IAAS, Region.EU_ZURICH_1): 'https://iaas.eu-zurich-1.oraclecloud.com',
    (Service.IAAS, Region.IL_JERUSALEM_1): 'https://iaas.il-jerusalem-1.oraclecloud.com',
    (Service.IAAS, Region.ME_ABUDHABI_1): 'https://iaas.me-abudhabi-1.oraclecloud.com',
    (Service.IAAS, Region.ME_DUBAI_1): 'https://iaas.me-dubai-1.oraclecloud.com',
    (Service.IAAS, Region.ME_JEDDAH_1): 'https://iaas.me-jeddah-1.oraclecloud.com',
    (Service.IAAS, Region.ME_RIYADH_1): 'https://iaas.me-riyadh-1.oraclecloud.com',
    (Service.IAAS, Region.MX_MONTERREY_1): 'https://iaas.mx-monterrey-1.oraclecloud.com',
    (Service.IAAS, Region.MX_QUERETARO_1): 'https://iaas.mx-queretaro-1.oraclecloud.com',
    (Service.IAAS, Region.SA_BOGOTA_1): 'https://iaas.sa-bogota-1.oraclecloud.com',
    (Service.IAAS, Region.SA_SANTIAGO_1): 'https://iaas.sa-santiago-1.oraclecloud.com',
    (Service.IAAS, Region.SA_SAOPAULO_1): 'https://iaas.sa-saopaulo-1.oraclecloud.com',
    (Service.IAAS, Region.SA_VALPARAISO_1): 'https://iaas.sa-valparaiso-1.oraclecloud.com',
    (Service.IAAS, Region.SA_VINHEDO_1): 'https://iaas.sa-vinhedo-1.oraclecloud.com',
    (Service.IAAS, Region.UK_CARDIFF_1): 'https://iaas.uk-cardiff-1.oraclecloud.com',
    (Service.IAAS, Region.UK_LONDON_1): 'https://iaas.uk-london-1.oraclecloud.com',
    (Service.IAAS, Region.US_ASHBURN_1): 'https://iaas.us-ashburn-1.oraclecloud.com',
    (Service.IAAS, Region.US_CHICAGO_1): 'https://iaas.us-chicago-1.oraclecloud.com',
    (Service.IAAS, Region.US_PHOENIX_1): 'https://iaas.us-phoenix-1.oraclecloud.com',
    (Service.IAAS, Region.US_SANJOSE_1): 'https://iaas.us-sanjose-1.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.AF_JOHANNESBURG_1,
    ): 'https://identity.af-johannesburg-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.AP_BATAM_1): 'https://identity.ap-batam-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.AP_CHUNCHEON_1,
    ): 'https://identity.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.AP_HYDERABAD_1,
    ): 'https://identity.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.AP_MELBOURNE_1,
    ): 'https://identity.ap-melbourne-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.AP_MUMBAI_1): 'https://identity.ap-mumbai-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.AP_OSAKA_1): 'https://identity.ap-osaka-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.AP_SEOUL_1): 'https://identity.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.AP_SINGAPORE_1,
    ): 'https://identity.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.AP_SINGAPORE_2,
    ): 'https://identity.ap-singapore-2.oci.oraclecloud.com',
    (Service.IDENTITY, Region.AP_SYDNEY_1): 'https://identity.ap-sydney-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.AP_TOKYO_1): 'https://identity.ap-tokyo-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.CA_MONTREAL_1): 'https://identity.ca-montreal-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.CA_TORONTO_1): 'https://identity.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.EU_AMSTERDAM_1,
    ): 'https://identity.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.EU_FRANKFURT_1,
    ): 'https://identity.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.EU_JOVANOVAC_1,
    ): 'https://identity.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.IDENTITY, Region.EU_MADRID_1): 'https://identity.eu-madrid-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.EU_MADRID_3): 'https://identity.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.EU_MARSEILLE_1,
    ): 'https://identity.eu-marseille-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.EU_MILAN_1): 'https://identity.eu-milan-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.EU_STOCKHOLM_1,
    ): 'https://identity.eu-stockholm-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.EU_TURIN_1): 'https://identity.eu-turin-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.EU_ZURICH_1): 'https://identity.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.IL_JERUSALEM_1,
    ): 'https://identity.il-jerusalem-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.ME_ABUDHABI_1): 'https://identity.me-abudhabi-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.ME_DUBAI_1): 'https://identity.me-dubai-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.ME_JEDDAH_1): 'https://identity.me-jeddah-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.ME_RIYADH_1): 'https://identity.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.MX_MONTERREY_1,
    ): 'https://identity.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.MX_QUERETARO_1,
    ): 'https://identity.mx-queretaro-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.SA_BOGOTA_1): 'https://identity.sa-bogota-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.SA_SANTIAGO_1): 'https://identity.sa-santiago-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.SA_SAOPAULO_1): 'https://identity.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.IDENTITY,
        Region.SA_VALPARAISO_1,
    ): 'https://identity.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.SA_VINHEDO_1): 'https://identity.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.UK_CARDIFF_1): 'https://identity.uk-cardiff-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.UK_LONDON_1): 'https://identity.uk-london-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.US_ASHBURN_1): 'https://identity.us-ashburn-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.US_CHICAGO_1): 'https://identity.us-chicago-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.US_PHOENIX_1): 'https://identity.us-phoenix-1.oci.oraclecloud.com',
    (Service.IDENTITY, Region.US_SANJOSE_1): 'https://identity.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.IDENTITY_DP,
        Region.AF_JOHANNESBURG_1,
    ): 'https://auth.af-johannesburg-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.AP_BATAM_1): 'https://auth.ap-batam-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.AP_CHUNCHEON_1): 'https://auth.ap-chuncheon-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.AP_HYDERABAD_1): 'https://auth.ap-hyderabad-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.AP_MELBOURNE_1): 'https://auth.ap-melbourne-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.AP_MUMBAI_1): 'https://auth.ap-mumbai-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.AP_OSAKA_1): 'https://auth.ap-osaka-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.AP_SEOUL_1): 'https://auth.ap-seoul-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.AP_SINGAPORE_1): 'https://auth.ap-singapore-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.AP_SINGAPORE_2): 'https://auth.ap-singapore-2.oraclecloud.com',
    (Service.IDENTITY_DP, Region.AP_SYDNEY_1): 'https://auth.ap-sydney-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.AP_TOKYO_1): 'https://auth.ap-tokyo-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.CA_MONTREAL_1): 'https://auth.ca-montreal-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.CA_TORONTO_1): 'https://auth.ca-toronto-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.EU_AMSTERDAM_1): 'https://auth.eu-amsterdam-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.EU_FRANKFURT_1): 'https://auth.eu-frankfurt-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.EU_MADRID_1): 'https://auth.eu-madrid-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.EU_MADRID_3): 'https://auth.eu-madrid-3.oraclecloud.com',
    (Service.IDENTITY_DP, Region.EU_MARSEILLE_1): 'https://auth.eu-marseille-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.EU_MILAN_1): 'https://auth.eu-milan-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.EU_STOCKHOLM_1): 'https://auth.eu-stockholm-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.EU_TURIN_1): 'https://auth.eu-turin-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.EU_ZURICH_1): 'https://auth.eu-zurich-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.IL_JERUSALEM_1): 'https://auth.il-jerusalem-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.ME_ABUDHABI_1): 'https://auth.me-abudhabi-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.ME_DUBAI_1): 'https://auth.me-dubai-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.ME_JEDDAH_1): 'https://auth.me-jeddah-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.ME_RIYADH_1): 'https://auth.me-riyadh-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.MX_MONTERREY_1): 'https://auth.mx-monterrey-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.MX_QUERETARO_1): 'https://auth.mx-queretaro-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.SA_BOGOTA_1): 'https://auth.sa-bogota-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.SA_SANTIAGO_1): 'https://auth.sa-santiago-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.SA_SAOPAULO_1): 'https://auth.sa-saopaulo-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.SA_VALPARAISO_1): 'https://auth.sa-valparaiso-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.SA_VINHEDO_1): 'https://auth.sa-vinhedo-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.UK_CARDIFF_1): 'https://auth.uk-cardiff-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.UK_LONDON_1): 'https://auth.uk-london-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.US_ASHBURN_1): 'https://auth.us-ashburn-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.US_CHICAGO_1): 'https://auth.us-chicago-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.US_PHOENIX_1): 'https://auth.us-phoenix-1.oraclecloud.com',
    (Service.IDENTITY_DP, Region.US_SANJOSE_1): 'https://auth.us-sanjose-1.oraclecloud.com',
    (
        Service.INCIDENTMANAGEMENT,
        Region.US_PHOENIX_1,
    ): 'https://incidentmanagement.us-phoenix-1.oraclecloud.com',
    (
        Service.INSTANCEAGENT,
        Region.AF_JOHANNESBURG_1,
    ): 'https://iaas.af-johannesburg-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.AP_BATAM_1): 'https://iaas.ap-batam-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.AP_CHUNCHEON_1): 'https://iaas.ap-chuncheon-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.AP_HYDERABAD_1): 'https://iaas.ap-hyderabad-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.AP_MELBOURNE_1): 'https://iaas.ap-melbourne-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.AP_MUMBAI_1): 'https://iaas.ap-mumbai-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.AP_OSAKA_1): 'https://iaas.ap-osaka-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.AP_SEOUL_1): 'https://iaas.ap-seoul-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.AP_SINGAPORE_1): 'https://iaas.ap-singapore-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.AP_SINGAPORE_2): 'https://iaas.ap-singapore-2.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.AP_SYDNEY_1): 'https://iaas.ap-sydney-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.AP_TOKYO_1): 'https://iaas.ap-tokyo-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.CA_MONTREAL_1): 'https://iaas.ca-montreal-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.CA_TORONTO_1): 'https://iaas.ca-toronto-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.EU_AMSTERDAM_1): 'https://iaas.eu-amsterdam-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.EU_FRANKFURT_1): 'https://iaas.eu-frankfurt-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.EU_JOVANOVAC_1): 'https://iaas.eu-jovanovac-1.oraclecloud20.com',
    (Service.INSTANCEAGENT, Region.EU_MADRID_1): 'https://iaas.eu-madrid-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.EU_MADRID_3): 'https://iaas.eu-madrid-3.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.EU_MARSEILLE_1): 'https://iaas.eu-marseille-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.EU_MILAN_1): 'https://iaas.eu-milan-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.EU_PARIS_1): 'https://iaas.eu-paris-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.EU_STOCKHOLM_1): 'https://iaas.eu-stockholm-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.EU_TURIN_1): 'https://iaas.eu-turin-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.EU_ZURICH_1): 'https://iaas.eu-zurich-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.IL_JERUSALEM_1): 'https://iaas.il-jerusalem-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.ME_ABUDHABI_1): 'https://iaas.me-abudhabi-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.ME_DUBAI_1): 'https://iaas.me-dubai-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.ME_JEDDAH_1): 'https://iaas.me-jeddah-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.ME_RIYADH_1): 'https://iaas.me-riyadh-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.MX_MONTERREY_1): 'https://iaas.mx-monterrey-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.MX_QUERETARO_1): 'https://iaas.mx-queretaro-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.SA_BOGOTA_1): 'https://iaas.sa-bogota-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.SA_SANTIAGO_1): 'https://iaas.sa-santiago-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.SA_SAOPAULO_1): 'https://iaas.sa-saopaulo-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.SA_VALPARAISO_1): 'https://iaas.sa-valparaiso-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.SA_VINHEDO_1): 'https://iaas.sa-vinhedo-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.UK_CARDIFF_1): 'https://iaas.uk-cardiff-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.UK_LONDON_1): 'https://iaas.uk-london-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.US_ASHBURN_1): 'https://iaas.us-ashburn-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.US_CHICAGO_1): 'https://iaas.us-chicago-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.US_PHOENIX_1): 'https://iaas.us-phoenix-1.oraclecloud.com',
    (Service.INSTANCEAGENT, Region.US_SANJOSE_1): 'https://iaas.us-sanjose-1.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.AF_JOHANNESBURG_1,
    ): 'https://integration.af-johannesburg-1.ocp.oraclecloud.com',
    (Service.INTEGRATION, Region.AP_BATAM_1): 'https://integration.ap-batam-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.AP_CHUNCHEON_1,
    ): 'https://integration.ap-chuncheon-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.AP_HYDERABAD_1,
    ): 'https://integration.ap-hyderabad-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.AP_MELBOURNE_1,
    ): 'https://integration.ap-melbourne-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.AP_MUMBAI_1,
    ): 'https://integration.ap-mumbai-1.ocp.oraclecloud.com',
    (Service.INTEGRATION, Region.AP_OSAKA_1): 'https://integration.ap-osaka-1.ocp.oraclecloud.com',
    (Service.INTEGRATION, Region.AP_SEOUL_1): 'https://integration.ap-seoul-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.AP_SINGAPORE_1,
    ): 'https://integration.ap-singapore-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.AP_SINGAPORE_2,
    ): 'https://integration.ap-singapore-2.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.AP_SYDNEY_1,
    ): 'https://integration.ap-sydney-1.ocp.oraclecloud.com',
    (Service.INTEGRATION, Region.AP_TOKYO_1): 'https://integration.ap-tokyo-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.CA_MONTREAL_1,
    ): 'https://integration.ca-montreal-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.CA_TORONTO_1,
    ): 'https://integration.ca-toronto-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.EU_AMSTERDAM_1,
    ): 'https://integration.eu-amsterdam-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.EU_FRANKFURT_1,
    ): 'https://integration.eu-frankfurt-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.EU_JOVANOVAC_1,
    ): 'https://integration.eu-jovanovac-1.ocp.oraclecloud20.com',
    (
        Service.INTEGRATION,
        Region.EU_MADRID_1,
    ): 'https://integration.eu-madrid-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.EU_MADRID_3,
    ): 'https://integration.eu-madrid-3.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.EU_MARSEILLE_1,
    ): 'https://integration.eu-marseille-1.ocp.oraclecloud.com',
    (Service.INTEGRATION, Region.EU_MILAN_1): 'https://integration.eu-milan-1.ocp.oraclecloud.com',
    (Service.INTEGRATION, Region.EU_PARIS_1): 'https://integration.eu-paris-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.EU_STOCKHOLM_1,
    ): 'https://integration.eu-stockholm-1.ocp.oraclecloud.com',
    (Service.INTEGRATION, Region.EU_TURIN_1): 'https://integration.eu-turin-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.EU_ZURICH_1,
    ): 'https://integration.eu-zurich-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.IL_JERUSALEM_1,
    ): 'https://integration.il-jerusalem-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.ME_ABUDHABI_1,
    ): 'https://integration.me-abudhabi-1.ocp.oraclecloud.com',
    (Service.INTEGRATION, Region.ME_DUBAI_1): 'https://integration.me-dubai-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.ME_JEDDAH_1,
    ): 'https://integration.me-jeddah-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.ME_RIYADH_1,
    ): 'https://integration.me-riyadh-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.MX_MONTERREY_1,
    ): 'https://integration.mx-monterrey-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.MX_QUERETARO_1,
    ): 'https://integration.mx-queretaro-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.SA_BOGOTA_1,
    ): 'https://integration.sa-bogota-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.SA_SANTIAGO_1,
    ): 'https://integration.sa-santiago-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.SA_SAOPAULO_1,
    ): 'https://integration.sa-saopaulo-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.SA_VALPARAISO_1,
    ): 'https://integration.sa-valparaiso-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.SA_VINHEDO_1,
    ): 'https://integration.sa-vinhedo-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.UK_CARDIFF_1,
    ): 'https://integration.uk-cardiff-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.UK_LONDON_1,
    ): 'https://integration.uk-london-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.US_ABILENE_1,
    ): 'https://integration.us-abilene-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.US_ASHBURN_1,
    ): 'https://integration.us-ashburn-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.US_CHICAGO_1,
    ): 'https://integration.us-chicago-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.US_DALLAS_1,
    ): 'https://integration.us-dallas-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.US_PHOENIX_1,
    ): 'https://integration.us-phoenix-1.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.US_SALTLAKE_2,
    ): 'https://integration.us-saltlake-2.ocp.oraclecloud.com',
    (
        Service.INTEGRATION,
        Region.US_SANJOSE_1,
    ): 'https://integration.us-sanjose-1.ocp.oraclecloud.com',
    (Service.IOT, Region.AP_TOKYO_1): 'https://iot.ap-tokyo-1.oci.oraclecloud.com',
    (Service.IOT, Region.CA_TORONTO_1): 'https://iot.ca-toronto-1.oci.oraclecloud.com',
    (Service.IOT, Region.EU_FRANKFURT_1): 'https://iot.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.IOT, Region.EU_MARSEILLE_1): 'https://iot.eu-marseille-1.oci.oraclecloud.com',
    (Service.IOT, Region.MX_QUERETARO_1): 'https://iot.mx-queretaro-1.oci.oraclecloud.com',
    (Service.IOT, Region.SP_SAOPAULO_1): 'https://iot.sp-saopaulo-1.oci.oraclecloud.com',
    (Service.IOT, Region.UK_LONDON_1): 'https://iot.uk-london-1.oci.oraclecloud.com',
    (Service.IOT, Region.US_ASHBURN_1): 'https://iot.us-ashburn-1.oci.oraclecloud.com',
    (Service.IOT, Region.US_PHOENIX_1): 'https://iot.us-phoenix-1.oci.oraclecloud.com',
    (Service.IOT, Region.US_SANJOSE_1): 'https://iot.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://javamanagement.af-johannesburg-1.oci.oraclecloud.com',
    (Service.JMS, Region.AP_BATAM_1): 'https://javamanagement.ap-batam-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.AP_CHUNCHEON_1,
    ): 'https://javamanagement.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.AP_HYDERABAD_1,
    ): 'https://javamanagement.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.AP_MELBOURNE_1,
    ): 'https://javamanagement.ap-melbourne-1.oci.oraclecloud.com',
    (Service.JMS, Region.AP_MUMBAI_1): 'https://javamanagement.ap-mumbai-1.oci.oraclecloud.com',
    (Service.JMS, Region.AP_OSAKA_1): 'https://javamanagement.ap-osaka-1.oci.oraclecloud.com',
    (Service.JMS, Region.AP_SEOUL_1): 'https://javamanagement.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.AP_SINGAPORE_1,
    ): 'https://javamanagement.ap-singapore-1.oci.oraclecloud.com',
    (Service.JMS, Region.AP_SYDNEY_1): 'https://javamanagement.ap-sydney-1.oci.oraclecloud.com',
    (Service.JMS, Region.AP_TOKYO_1): 'https://javamanagement.ap-tokyo-1.oci.oraclecloud.com',
    (Service.JMS, Region.CA_MONTREAL_1): 'https://javamanagement.ca-montreal-1.oci.oraclecloud.com',
    (Service.JMS, Region.CA_TORONTO_1): 'https://javamanagement.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.EU_AMSTERDAM_1,
    ): 'https://javamanagement.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.EU_FRANKFURT_1,
    ): 'https://javamanagement.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.EU_JOVANOVAC_1,
    ): 'https://javamanagement.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.JMS, Region.EU_MADRID_1): 'https://javamanagement.eu-madrid-1.oci.oraclecloud.com',
    (Service.JMS, Region.EU_MADRID_3): 'https://javamanagement.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.EU_MARSEILLE_1,
    ): 'https://javamanagement.eu-marseille-1.oci.oraclecloud.com',
    (Service.JMS, Region.EU_MILAN_1): 'https://javamanagement.eu-milan-1.oci.oraclecloud.com',
    (Service.JMS, Region.EU_PARIS_1): 'https://javamanagement.eu-paris-1.oraclecloud.com',
    (
        Service.JMS,
        Region.EU_STOCKHOLM_1,
    ): 'https://javamanagement.eu-stockholm-1.oci.oraclecloud.com',
    (Service.JMS, Region.EU_TURIN_1): 'https://javamanagement.eu-turin-1.oci.oraclecloud.com',
    (Service.JMS, Region.EU_ZURICH_1): 'https://javamanagement.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.IL_JERUSALEM_1,
    ): 'https://javamanagement.il-jerusalem-1.oci.oraclecloud.com',
    (Service.JMS, Region.ME_ABUDHABI_1): 'https://javamanagement.me-abudhabi-1.oci.oraclecloud.com',
    (Service.JMS, Region.ME_DUBAI_1): 'https://javamanagement.me-dubai-1.oci.oraclecloud.com',
    (Service.JMS, Region.ME_JEDDAH_1): 'https://javamanagement.me-jeddah-1.oci.oraclecloud.com',
    (Service.JMS, Region.ME_RIYADH_1): 'https://javamanagement.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.MX_MONTERREY_1,
    ): 'https://javamanagement.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.MX_QUERETARO_1,
    ): 'https://javamanagement.mx-queretaro-1.oci.oraclecloud.com',
    (Service.JMS, Region.SA_BOGOTA_1): 'https://javamanagement.sa-bogota-1.oraclecloud.com',
    (Service.JMS, Region.SA_SANTIAGO_1): 'https://javamanagement.sa-santiago-1.oci.oraclecloud.com',
    (Service.JMS, Region.SA_SAOPAULO_1): 'https://javamanagement.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.JMS,
        Region.SA_VALPARAISO_1,
    ): 'https://javamanagement.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.JMS, Region.SA_VINHEDO_1): 'https://javamanagement.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.JMS, Region.UK_CARDIFF_1): 'https://javamanagement.uk-cardiff-1.oci.oraclecloud.com',
    (Service.JMS, Region.UK_LONDON_1): 'https://javamanagement.uk-london-1.oci.oraclecloud.com',
    (Service.JMS, Region.US_ASHBURN_1): 'https://javamanagement.us-ashburn-1.oci.oraclecloud.com',
    (Service.JMS, Region.US_CHICAGO_1): 'https://javamanagement.us-chicago-1.oci.oraclecloud.com',
    (Service.JMS, Region.US_PHOENIX_1): 'https://javamanagement.us-phoenix-1.oci.oraclecloud.com',
    (Service.JMS, Region.US_SANJOSE_1): 'https://javamanagement.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.AF_JOHANNESBURG_1,
    ): 'https://javamanagementservice-download.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.AP_BATAM_1,
    ): 'https://javamanagementservice-download.ap-batam-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.AP_CHUNCHEON_1,
    ): 'https://javamanagementservice-download.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.AP_HYDERABAD_1,
    ): 'https://javamanagementservice-download.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.AP_MELBOURNE_1,
    ): 'https://javamanagementservice-download.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.AP_MUMBAI_1,
    ): 'https://javamanagementservice-download.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.AP_OSAKA_1,
    ): 'https://javamanagementservice-download.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.AP_SEOUL_1,
    ): 'https://javamanagementservice-download.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.AP_SINGAPORE_1,
    ): 'https://javamanagementservice-download.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.AP_SYDNEY_1,
    ): 'https://javamanagementservice-download.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.AP_TOKYO_1,
    ): 'https://javamanagementservice-download.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.CA_MONTREAL_1,
    ): 'https://javamanagementservice-download.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.CA_TORONTO_1,
    ): 'https://javamanagementservice-download.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.EU_AMSTERDAM_1,
    ): 'https://javamanagementservice-download.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.EU_FRANKFURT_1,
    ): 'https://javamanagementservice-download.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.EU_JOVANOVAC_1,
    ): 'https://javamanagementservice-download.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.EU_MADRID_1,
    ): 'https://javamanagementservice-download.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.EU_MADRID_3,
    ): 'https://javamanagementservice-download.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.EU_MARSEILLE_1,
    ): 'https://javamanagementservice-download.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.EU_MILAN_1,
    ): 'https://javamanagementservice-download.eu-milan-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.EU_PARIS_1,
    ): 'https://javamanagementservice-download.eu-paris-1.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.EU_STOCKHOLM_1,
    ): 'https://javamanagementservice-download.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.EU_TURIN_1,
    ): 'https://javamanagementservice-download.eu-turin-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.EU_ZURICH_1,
    ): 'https://javamanagementservice-download.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.IL_JERUSALEM_1,
    ): 'https://javamanagementservice-download.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.ME_ABUDHABI_1,
    ): 'https://javamanagementservice-download.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.ME_DUBAI_1,
    ): 'https://javamanagementservice-download.me-dubai-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.ME_JEDDAH_1,
    ): 'https://javamanagementservice-download.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.ME_RIYADH_1,
    ): 'https://javamanagementservice-download.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.MX_MONTERREY_1,
    ): 'https://javamanagementservice-download.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.MX_QUERETARO_1,
    ): 'https://javamanagementservice-download.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.SA_BOGOTA_1,
    ): 'https://javamanagementservice-download.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.SA_SANTIAGO_1,
    ): 'https://javamanagementservice-download.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.SA_SAOPAULO_1,
    ): 'https://javamanagementservice-download.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.SA_VINHEDO_1,
    ): 'https://javamanagementservice-download.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.UK_CARDIFF_1,
    ): 'https://javamanagementservice-download.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.UK_LONDON_1,
    ): 'https://javamanagementservice-download.uk-london-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.US_ASHBURN_1,
    ): 'https://javamanagementservice-download.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.US_CHICAGO_1,
    ): 'https://javamanagementservice-download.us-chicago-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.US_PHOENIX_1,
    ): 'https://javamanagementservice-download.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.JMS_JAVA_DOWNLOAD,
        Region.US_SANJOSE_1,
    ): 'https://javamanagementservice-download.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://javamanagement-utils.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.AP_BATAM_1,
    ): 'https://javamanagement-utils.ap-batam-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.AP_CHUNCHEON_1,
    ): 'https://javamanagement-utils.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.AP_HYDERABAD_1,
    ): 'https://javamanagement-utils.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.AP_MELBOURNE_1,
    ): 'https://javamanagement-utils.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.AP_MUMBAI_1,
    ): 'https://javamanagement-utils.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.AP_OSAKA_1,
    ): 'https://javamanagement-utils.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.AP_SEOUL_1,
    ): 'https://javamanagement-utils.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.AP_SINGAPORE_1,
    ): 'https://javamanagement-utils.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.AP_SYDNEY_1,
    ): 'https://javamanagement-utils.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.AP_TOKYO_1,
    ): 'https://javamanagement-utils.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.CA_MONTREAL_1,
    ): 'https://javamanagement-utils.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.CA_TORONTO_1,
    ): 'https://javamanagement-utils.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.EU_AMSTERDAM_1,
    ): 'https://javamanagement-utils.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.EU_FRANKFURT_1,
    ): 'https://javamanagement-utils.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.EU_JOVANOVAC_1,
    ): 'https://javamanagement-utils.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.JMS_UTILS,
        Region.EU_MADRID_1,
    ): 'https://javamanagement-utils.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.EU_MADRID_3,
    ): 'https://javamanagement-utils.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.EU_MARSEILLE_1,
    ): 'https://javamanagement-utils.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.EU_MILAN_1,
    ): 'https://javamanagement-utils.eu-milan-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.EU_PARIS_1,
    ): 'https://javamanagement-utils.eu-paris-1.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.EU_STOCKHOLM_1,
    ): 'https://javamanagement-utils.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.EU_TURIN_1,
    ): 'https://javamanagement-utils.eu-turin-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.EU_ZURICH_1,
    ): 'https://javamanagement-utils.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.IL_JERUSALEM_1,
    ): 'https://javamanagement-utils.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.ME_ABUDHABI_1,
    ): 'https://javamanagement-utils.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.ME_DUBAI_1,
    ): 'https://javamanagement-utils.me-dubai-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.ME_JEDDAH_1,
    ): 'https://javamanagement-utils.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.ME_RIYADH_1,
    ): 'https://javamanagement-utils.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.MX_MONTERREY_1,
    ): 'https://javamanagement-utils.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.MX_QUERETARO_1,
    ): 'https://javamanagement-utils.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.SA_BOGOTA_1,
    ): 'https://javamanagement-utils.sa-bogota-1.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.SA_SANTIAGO_1,
    ): 'https://javamanagement-utils.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.SA_SAOPAULO_1,
    ): 'https://javamanagement-utils.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.SA_VALPARAISO_1,
    ): 'https://javamanagement-utils.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.SA_VINHEDO_1,
    ): 'https://javamanagement-utils.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.UK_CARDIFF_1,
    ): 'https://javamanagement-utils.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.UK_LONDON_1,
    ): 'https://javamanagement-utils.uk-london-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.US_ASHBURN_1,
    ): 'https://javamanagement-utils.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.US_CHICAGO_1,
    ): 'https://javamanagement-utils.us-chicago-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.US_PHOENIX_1,
    ): 'https://javamanagement-utils.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.JMS_UTILS,
        Region.US_SANJOSE_1,
    ): 'https://javamanagement-utils.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.KAFKA,
        Region.AF_JOHANNESBURG_1,
    ): 'https://kafka.af-johannesburg-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.AP_BATAM_1): 'https://kafka.ap-batam-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.AP_CHUNCHEON_1): 'https://kafka.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.AP_HYDERABAD_1): 'https://kafka.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.AP_MELBOURNE_1): 'https://kafka.ap-melbourne-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.AP_MUMBAI_1): 'https://kafka.ap-mumbai-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.AP_OSAKA_1): 'https://kafka.ap-osaka-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.AP_SEOUL_1): 'https://kafka.ap-seoul-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.AP_SINGAPORE_1): 'https://kafka.ap-singapore-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.AP_SINGAPORE_2): 'https://kafka.ap-singapore-2.oci.oraclecloud.com',
    (Service.KAFKA, Region.AP_SYDNEY_1): 'https://kafka.ap-sydney-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.AP_TOKYO_1): 'https://kafka.ap-tokyo-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.CA_MONTREAL_1): 'https://kafka.ca-montreal-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.CA_TORONTO_1): 'https://kafka.ca-toronto-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.EU_AMSTERDAM_1): 'https://kafka.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.EU_FRANKFURT_1): 'https://kafka.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.EU_JOVANOVAC_1): 'https://kafka.eu-jovanovac-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.EU_MADRID_1): 'https://kafka.eu-madrid-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.EU_MADRID_3): 'https://kafka.eu-madrid-3.oci.oraclecloud.com',
    (Service.KAFKA, Region.EU_MARSEILLE_1): 'https://kafka.eu-marseille-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.EU_MILAN_1): 'https://kafka.eu-milan-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.EU_PARIS_1): 'https://kafka.eu-paris-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.EU_STOCKHOLM_1): 'https://kafka.eu-stockholm-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.EU_TURIN_1): 'https://kafka.eu-turin-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.EU_ZURICH_1): 'https://kafka.eu-zurich-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.IL_JERUSALEM_1): 'https://kafka.il-jerusalem-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.ME_ABUDHABI_1): 'https://kafka.me-abudhabi-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.ME_JEDDAH_1): 'https://kafka.me-jeddah-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.ME_RIYADH_1): 'https://kafka.me-riyadh-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.MX_MONTERREY_1): 'https://kafka.mx-monterrey-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.MX_QUERETARO_1): 'https://kafka.mx-queretaro-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.SA_BOGOTA_1): 'https://kafka.sa-bogota-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.SA_SANTIAGO_1): 'https://kafka.sa-santiago-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.SA_SAOPAULO_1): 'https://kafka.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.SA_VALPARAISO_1): 'https://kafka.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.SA_VINHEDO_1): 'https://kafka.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.UK_CARDIFF_1): 'https://kafka.uk-cardiff-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.UK_LONDON_1): 'https://kafka.uk-london-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.US_ASHBURN_1): 'https://kafka.us-ashburn-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.US_CHICAGO_1): 'https://kafka.us-chicago-1.oci.oraclecloud.com',
    (Service.KAFKA, Region.US_PHOENIX_1OCI): 'https://kafka.us-phoenix-1oci.oraclecloud.com',
    (Service.KAFKA, Region.US_SANJOSE_1): 'https://kafka.us-sanjose-1.oci.oraclecloud.com',
    (Service.KEY, Region.AF_JOHANNESBURG_1): 'https://kms.af-johannesburg-1.oraclecloud.com',
    (Service.KEY, Region.AP_BATAM_1): 'https://kms.ap-batam-1.oraclecloud.com',
    (Service.KEY, Region.AP_CHUNCHEON_1): 'https://kms.ap-chuncheon-1.oraclecloud.com',
    (Service.KEY, Region.AP_HYDERABAD_1): 'https://kms.ap-hyderabad-1.oraclecloud.com',
    (Service.KEY, Region.AP_MELBOURNE_1): 'https://kms.ap-melbourne-1.oraclecloud.com',
    (Service.KEY, Region.AP_MUMBAI_1): 'https://kms.ap-mumbai-1.oraclecloud.com',
    (Service.KEY, Region.AP_OSAKA_1): 'https://kms.ap-osaka-1.oraclecloud.com',
    (Service.KEY, Region.AP_SEOUL_1): 'https://kms.ap-seoul-1.oraclecloud.com',
    (Service.KEY, Region.AP_SINGAPORE_1): 'https://kms.ap-singapore-1.oraclecloud.com',
    (Service.KEY, Region.AP_SYDNEY_1): 'https://kms.ap-sydney-1.oraclecloud.com',
    (Service.KEY, Region.AP_TOKYO_1): 'https://kms.ap-tokyo-1.oraclecloud.com',
    (Service.KEY, Region.CA_MONTREAL_1): 'https://kms.ca-montreal-1.oraclecloud.com',
    (Service.KEY, Region.CA_TORONTO_1): 'https://kms.ca-toronto-1.oraclecloud.com',
    (Service.KEY, Region.EU_AMSTERDAM_1): 'https://kms.eu-amsterdam-1.oraclecloud.com',
    (Service.KEY, Region.EU_FRANKFURT_1): 'https://kms.eu-frankfurt-1.oraclecloud.com',
    (Service.KEY, Region.EU_JOVANOVAC_1): 'https://kms.eu-jovanovac-1.oraclecloud20.com',
    (Service.KEY, Region.EU_MADRID_1): 'https://kms.eu-madrid-1.oraclecloud.com',
    (Service.KEY, Region.EU_MADRID_3): 'https://kms.eu-madrid-3.oraclecloud.com',
    (Service.KEY, Region.EU_MARSEILLE_1): 'https://kms.eu-marseille-1.oraclecloud.com',
    (Service.KEY, Region.EU_MILAN_1): 'https://kms.eu-milan-1.oraclecloud.com',
    (Service.KEY, Region.EU_PARIS_1): 'https://kms.eu-paris-1.oraclecloud.com',
    (Service.KEY, Region.EU_STOCKHOLM_1): 'https://kms.eu-stockholm-1.oraclecloud.com',
    (Service.KEY, Region.EU_TURIN_1): 'https://kms.eu-turin-1.oraclecloud.com',
    (Service.KEY, Region.EU_ZURICH_1): 'https://kms.eu-zurich-1.oraclecloud.com',
    (Service.KEY, Region.IL_JERUSALEM_1): 'https://kms.il-jerusalem-1.oraclecloud.com',
    (Service.KEY, Region.ME_ABUDHABI_1): 'https://kms.me-abudhabi-1.oraclecloud.com',
    (Service.KEY, Region.ME_DUBAI_1): 'https://kms.me-dubai-1.oraclecloud.com',
    (Service.KEY, Region.ME_JEDDAH_1): 'https://kms.me-jeddah-1.oraclecloud.com',
    (Service.KEY, Region.MX_MONTERREY_1): 'https://kms.mx-monterrey-1.oraclecloud.com',
    (Service.KEY, Region.MX_QUERETARO_1): 'https://kms.mx-queretaro-1.oraclecloud.com',
    (Service.KEY, Region.SA_BOGOTA_1): 'https://kms.sa-bogota-1.oraclecloud.com',
    (Service.KEY, Region.SA_SANTIAGO_1): 'https://kms.sa-santiago-1.oraclecloud.com',
    (Service.KEY, Region.SA_SAOPAULO_1): 'https://kms.sa-saopaulo-1.oraclecloud.com',
    (Service.KEY, Region.SA_VALPARAISO_1): 'https://kms.sa-valparaiso-1.oraclecloud.com',
    (Service.KEY, Region.SA_VINHEDO_1): 'https://kms.sa-vinhedo-1.oraclecloud.com',
    (Service.KEY, Region.UK_CARDIFF_1): 'https://kms.uk-cardiff-1.oraclecloud.com',
    (Service.KEY, Region.UK_LONDON_1): 'https://kms.uk-london-1.oraclecloud.com',
    (Service.KEY, Region.US_ASHBURN_1): 'https://kms.us-ashburn-1.oraclecloud.com',
    (Service.KEY, Region.US_CHICAGO_1): 'https://kms.us-chicago-1.oraclecloud.com',
    (Service.KEY, Region.US_PHOENIX_1): 'https://kms.us-phoenix-1.oraclecloud.com',
    (Service.KEY, Region.US_SANJOSE_1): 'https://kms.us-sanjose-1.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://language.aiservice.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AP_BATAM_1,
    ): 'https://language.aiservice.ap-batam-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AP_CHUNCHEON_1,
    ): 'https://language.aiservice.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AP_HYDERABAD_1,
    ): 'https://language.aiservice.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AP_MELBOURNE_1,
    ): 'https://language.aiservice.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AP_MUMBAI_1,
    ): 'https://language.aiservice.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AP_OSAKA_1,
    ): 'https://language.aiservice.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AP_SEOUL_1,
    ): 'https://language.aiservice.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AP_SINGAPORE_1,
    ): 'https://language.aiservice.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AP_SINGAPORE_2,
    ): 'https://language.aiservice.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AP_SYDNEY_1,
    ): 'https://language.aiservice.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.AP_TOKYO_1,
    ): 'https://language.aiservice.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.CA_MONTREAL_1,
    ): 'https://language.aiservice.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.CA_TORONTO_1,
    ): 'https://language.aiservice.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.EU_AMSTERDAM_1,
    ): 'https://language.aiservice.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.EU_FRANKFURT_1,
    ): 'https://language.aiservice.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.EU_JOVANOVAC_1,
    ): 'https://language.aiservice.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.LANGUAGE,
        Region.EU_MADRID_1,
    ): 'https://language.aiservice.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.EU_MADRID_3,
    ): 'https://language.aiservice.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.EU_MARSEILLE_1,
    ): 'https://language.aiservice.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.EU_MILAN_1,
    ): 'https://language.aiservice.eu-milan-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.EU_PARIS_1,
    ): 'https://language.aiservice.eu-paris-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.EU_STOCKHOLM_1,
    ): 'https://language.aiservice.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.EU_TURIN_1,
    ): 'https://language.aiservice.eu-turin-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.EU_ZURICH_1,
    ): 'https://language.aiservice.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.IL_JERUSALEM_1,
    ): 'https://language.aiservice.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.ME_ABUDHABI_1,
    ): 'https://language.aiservice.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.ME_DUBAI_1,
    ): 'https://language.aiservice.me-dubai-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.ME_JEDDAH_1,
    ): 'https://language.aiservice.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.ME_RIYADH_1,
    ): 'https://language.aiservice.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.MX_MONTERREY_1,
    ): 'https://language.aiservice.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.MX_QUERETARO_1,
    ): 'https://language.aiservice.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.SA_BOGOTA_1,
    ): 'https://language.aiservice.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.SA_SANTIAGO_1,
    ): 'https://language.aiservice.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.SA_SAOPAULO_1,
    ): 'https://language.aiservice.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.SA_VALPARAISO_1,
    ): 'https://language.aiservice.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.SA_VINHEDO_1,
    ): 'https://language.aiservice.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.UK_CARDIFF_1,
    ): 'https://language.aiservice.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.UK_LONDON_1,
    ): 'https://language.aiservice.uk-london-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.US_ASHBURN_1,
    ): 'https://language.aiservice.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.US_LANGLEY_1,
    ): 'https://language.aiservice.us-langley-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.US_LUKE_1,
    ): 'https://language.aiservice.us-luke-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.US_PHOENIX_1,
    ): 'https://language.aiservice.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.LANGUAGE,
        Region.US_SANJOSE_1,
    ): 'https://language.aiservice.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AF_JOHANNESBURG_1,
    ): 'https://licensemanager.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AP_BATAM_1,
    ): 'https://licensemanager.ap-batam-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AP_CHUNCHEON_1,
    ): 'https://licensemanager.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AP_HYDERABAD_1,
    ): 'https://licensemanager.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AP_MELBOURNE_1,
    ): 'https://licensemanager.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AP_MUMBAI_1,
    ): 'https://licensemanager.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AP_OSAKA_1,
    ): 'https://licensemanager.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AP_SEOUL_1,
    ): 'https://licensemanager.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AP_SINGAPORE_1,
    ): 'https://licensemanager.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AP_SINGAPORE_2,
    ): 'https://licensemanager.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AP_SYDNEY_1,
    ): 'https://licensemanager.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.AP_TOKYO_1,
    ): 'https://licensemanager.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.CA_MONTREAL_1,
    ): 'https://licensemanager.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.CA_TORONTO_1,
    ): 'https://licensemanager.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.EU_AMSTERDAM_1,
    ): 'https://licensemanager.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.EU_FRANKFURT_1,
    ): 'https://licensemanager.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.EU_MARSEILLE_1,
    ): 'https://licensemanager.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.EU_MILAN_1,
    ): 'https://licensemanager.eu-milan-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.EU_STOCKHOLM_1,
    ): 'https://licensemanager.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.EU_ZURICH_1,
    ): 'https://licensemanager.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.IL_JERUSALEM_1,
    ): 'https://licensemanager.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.ME_ABUDHABI_1,
    ): 'https://licensemanager.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.ME_DUBAI_1,
    ): 'https://licensemanager.me-dubai-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.ME_JEDDAH_1,
    ): 'https://licensemanager.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.ME_RIYADH_1,
    ): 'https://licensemanager.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.MX_MONTERREY_1,
    ): 'https://licensemanager.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.MX_QUERETARO_1,
    ): 'https://licensemanager.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.SA_BOGOTA_1,
    ): 'https://licensemanager.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.SA_SANTIAGO_1,
    ): 'https://licensemanager.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.SA_SAOPAULO_1,
    ): 'https://licensemanager.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.SA_VALPARAISO_1,
    ): 'https://licensemanager.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.SA_VINHEDO_1,
    ): 'https://licensemanager.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.UK_CARDIFF_1,
    ): 'https://licensemanager.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.UK_LONDON_1,
    ): 'https://licensemanager.uk-london-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.US_ASHBURN_1,
    ): 'https://licensemanager.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.US_PHOENIX_1,
    ): 'https://licensemanager.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.LICENSEMANAGER,
        Region.US_SANJOSE_1,
    ): 'https://licensemanager.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.LIMITS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://limits.af-johannesburg-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.AP_BATAM_1): 'https://limits.ap-batam-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.AP_CHUNCHEON_1): 'https://limits.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.AP_HYDERABAD_1): 'https://limits.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.AP_MELBOURNE_1): 'https://limits.ap-melbourne-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.AP_MUMBAI_1): 'https://limits.ap-mumbai-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.AP_OSAKA_1): 'https://limits.ap-osaka-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.AP_SEOUL_1): 'https://limits.ap-seoul-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.AP_SINGAPORE_1): 'https://limits.ap-singapore-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.AP_SINGAPORE_2): 'https://limits.ap-singapore-2.oci.oraclecloud.com',
    (Service.LIMITS, Region.AP_TOKYO_1): 'https://limits.ap-tokyo-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.CA_MONTREAL_1): 'https://limits.ca-montreal-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.CA_TORONTO_1): 'https://limits.ca-toronto-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.EU_AMSTERDAM_1): 'https://limits.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.EU_FRANKFURT_1): 'https://limits.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.EU_JOVANOVAC_1): 'https://limits.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.LIMITS, Region.EU_MADRID_1): 'https://limits.eu-madrid-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.EU_MADRID_3): 'https://limits.eu-madrid-3.oci.oraclecloud.com',
    (Service.LIMITS, Region.EU_MARSEILLE_1): 'https://limits.eu-marseille-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.EU_MILAN_1): 'https://limits.eu-milan-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.EU_PARIS_1): 'https://limits.eu-paris-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.EU_STOCKHOLM_1): 'https://limits.eu-stockholm-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.EU_TURIN_1): 'https://limits.eu-turin-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.EU_ZURICH_1): 'https://limits.eu-zurich-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.IL_JERUSALEM_1): 'https://limits.il-jerusalem-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.ME_ABUDHABI_1): 'https://limits.me-abudhabi-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.ME_DUBAI_1): 'https://limits.me-dubai-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.ME_JEDDAH_1): 'https://limits.me-jeddah-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.ME_RIYADH_1): 'https://limits.me-riyadh-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.MX_MONTERREY_1): 'https://limits.mx-monterrey-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.MX_QUERETARO_1): 'https://limits.mx-queretaro-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.SA_BOGOTA_1): 'https://limits.sa-bogota-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.SA_SANTIAGO_1): 'https://limits.sa-santiago-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.SA_SAOPAULO_1): 'https://limits.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.SA_VALPARAISO_1): 'https://limits.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.SA_VINHEDO_1): 'https://limits.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.UK_CARDIFF_1): 'https://limits.uk-cardiff-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.UK_LONDON_1): 'https://limits.uk-london-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.US_ASHBURN_1): 'https://limits.us-ashburn-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.US_CHICAGO_1): 'https://limits.us-chicago-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.US_PHOENIX_1): 'https://limits.us-phoenix-1.oci.oraclecloud.com',
    (Service.LIMITS, Region.US_SANJOSE_1): 'https://limits.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.LOADBALANCER,
        Region.AF_JOHANNESBURG_1,
    ): 'https://iaas.af-johannesburg-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.AP_BATAM_1): 'https://iaas.ap-batam-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.AP_CHUNCHEON_1): 'https://iaas.ap-chuncheon-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.AP_HYDERABAD_1): 'https://iaas.ap-hyderabad-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.AP_MELBOURNE_1): 'https://iaas.ap-melbourne-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.AP_MUMBAI_1): 'https://iaas.ap-mumbai-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.AP_OSAKA_1): 'https://iaas.ap-osaka-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.AP_SEOUL_1): 'https://iaas.ap-seoul-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.AP_SINGAPORE_1): 'https://iaas.ap-singapore-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.AP_SINGAPORE_2): 'https://iaas.ap-singapore-2.oraclecloud.com',
    (Service.LOADBALANCER, Region.AP_SYDNEY_1): 'https://iaas.ap-sydney-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.AP_TOKYO_1): 'https://iaas.ap-tokyo-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.CA_MONTREAL_1): 'https://iaas.ca-montreal-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.CA_TORONTO_1): 'https://iaas.ca-toronto-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.EU_AMSTERDAM_1): 'https://iaas.eu-amsterdam-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.EU_FRANKFURT_1): 'https://iaas.eu-frankfurt-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.EU_JOVANOVAC_1): 'https://iaas.eu-jovanovac-1.oraclecloud20.com',
    (Service.LOADBALANCER, Region.EU_MADRID_1): 'https://iaas.eu-madrid-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.EU_MADRID_3): 'https://iaas.eu-madrid-3.oraclecloud.com',
    (Service.LOADBALANCER, Region.EU_MARSEILLE_1): 'https://iaas.eu-marseille-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.EU_MILAN_1): 'https://iaas.eu-milan-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.EU_PARIS_1): 'https://iaas.eu-paris-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.EU_STOCKHOLM_1): 'https://iaas.eu-stockholm-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.EU_TURIN_1): 'https://iaas.eu-turin-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.EU_ZURICH_1): 'https://iaas.eu-zurich-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.ME_ABUDHABI_1): 'https://iaas.me-abudhabi-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.ME_DUBAI_1): 'https://iaas.me-dubai-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.ME_JEDDAH_1): 'https://iaas.me-jeddah-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.ME_RIYADH_1): 'https://iaas.me-riyadh-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.MX_MONTERREY_1): 'https://iaas.mx-monterrey-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.MX_QUERETARO_1): 'https://iaas.mx-queretaro-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.SA_BOGOTA_1): 'https://iaas.sa-bogota-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.SA_SANTIAGO_1): 'https://iaas.sa-santiago-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.SA_SAOPAULO_1): 'https://iaas.sa-saopaulo-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.SA_VALPARAISO_1): 'https://iaas.sa-valparaiso-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.SA_VINHEDO_1): 'https://iaas.sa-vinhedo-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.UK_CARDIFF_1): 'https://iaas.uk-cardiff-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.UK_LONDON_1): 'https://iaas.uk-london-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.US_ASHBURN_1): 'https://iaas.us-ashburn-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.US_CHICAGO_1): 'https://iaas.us-chicago-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.US_PHOENIX_1): 'https://iaas.us-phoenix-1.oraclecloud.com',
    (Service.LOADBALANCER, Region.US_SANJOSE_1): 'https://iaas.us-sanjose-1.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AF_JOHANNESBURG_1,
    ): 'https://loganalytics.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AP_BATAM_1,
    ): 'https://loganalytics.ap-batam-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AP_CHUNCHEON_1,
    ): 'https://loganalytics.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AP_HYDERABAD_1,
    ): 'https://loganalytics.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AP_MELBOURNE_1,
    ): 'https://loganalytics.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AP_MUMBAI_1,
    ): 'https://loganalytics.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AP_OSAKA_1,
    ): 'https://loganalytics.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AP_SEOUL_1,
    ): 'https://loganalytics.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AP_SINGAPORE_1,
    ): 'https://loganalytics.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AP_SINGAPORE_2,
    ): 'https://loganalytics.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AP_SYDNEY_1,
    ): 'https://loganalytics.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.AP_TOKYO_1,
    ): 'https://loganalytics.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.CA_MONTREAL_1,
    ): 'https://loganalytics.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.CA_TORONTO_1,
    ): 'https://loganalytics.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.EU_AMSTERDAM_1,
    ): 'https://loganalytics.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.EU_FRANKFURT_1,
    ): 'https://loganalytics.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.EU_JOVANOVAC_1,
    ): 'https://loganalytics.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.LOGAN_API_SPEC,
        Region.EU_MADRID_1,
    ): 'https://loganalytics.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.EU_MADRID_3,
    ): 'https://loganalytics.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.EU_MARSEILLE_1,
    ): 'https://loganalytics.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.EU_MILAN_1,
    ): 'https://loganalytics.eu-milan-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.EU_PARIS_1,
    ): 'https://loganalytics.eu-paris-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.EU_STOCKHOLM_1,
    ): 'https://loganalytics.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.EU_TURIN_1,
    ): 'https://loganalytics.eu-turin-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.EU_ZURICH_1,
    ): 'https://loganalytics.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.IL_JERUSALEM_1,
    ): 'https://loganalytics.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.ME_ABUDHABI_1,
    ): 'https://loganalytics.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.ME_DUBAI_1,
    ): 'https://loganalytics.me-dubai-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.ME_JEDDAH_1,
    ): 'https://loganalytics.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.ME_RIYADH_1,
    ): 'https://loganalytics.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.MX_MONTERREY_1,
    ): 'https://loganalytics.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.MX_QUERETARO_1,
    ): 'https://loganalytics.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.SA_BOGOTA_1,
    ): 'https://loganalytics.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.SA_SANTIAGO_1,
    ): 'https://loganalytics.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.SA_SAOPAULO_1,
    ): 'https://loganalytics.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.SA_VALPARAISO_1,
    ): 'https://loganalytics.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.SA_VINHEDO_1,
    ): 'https://loganalytics.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.UK_CARDIFF_1,
    ): 'https://loganalytics.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.UK_LONDON_1,
    ): 'https://loganalytics.uk-london-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.US_ASHBURN_1,
    ): 'https://loganalytics.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.US_CHICAGO_1,
    ): 'https://loganalytics.us-chicago-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.US_PHOENIX_1,
    ): 'https://loganalytics.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.LOGAN_API_SPEC,
        Region.US_SANJOSE_1,
    ): 'https://loganalytics.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://ingestion.logging.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AP_BATAM_1,
    ): 'https://ingestion.logging.ap-batam-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AP_CHUNCHEON_1,
    ): 'https://ingestion.logging.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AP_HYDERABAD_1,
    ): 'https://ingestion.logging.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AP_MELBOURNE_1,
    ): 'https://ingestion.logging.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AP_MUMBAI_1,
    ): 'https://ingestion.logging.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AP_OSAKA_1,
    ): 'https://ingestion.logging.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AP_SEOUL_1,
    ): 'https://ingestion.logging.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AP_SINGAPORE_1,
    ): 'https://ingestion.logging.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AP_SINGAPORE_2,
    ): 'https://ingestion.logging.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AP_SYDNEY_1,
    ): 'https://ingestion.logging.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.AP_TOKYO_1,
    ): 'https://ingestion.logging.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.CA_MONTREAL_1,
    ): 'https://ingestion.logging.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.CA_TORONTO_1,
    ): 'https://ingestion.logging.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.EU_AMSTERDAM_1,
    ): 'https://ingestion.logging.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.EU_FRANKFURT_1,
    ): 'https://ingestion.logging.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.EU_JOVANOVAC_1,
    ): 'https://ingestion.logging.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.EU_MADRID_1,
    ): 'https://ingestion.logging.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.EU_MADRID_3,
    ): 'https://ingestion.logging.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.EU_MARSEILLE_1,
    ): 'https://ingestion.logging.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.EU_MILAN_1,
    ): 'https://ingestion.logging.eu-milan-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.EU_PARIS_1,
    ): 'https://ingestion.logging.eu-paris-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.EU_STOCKHOLM_1,
    ): 'https://ingestion.logging.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.EU_TURIN_1,
    ): 'https://ingestion.logging.eu-turin-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.EU_ZURICH_1,
    ): 'https://ingestion.logging.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.IL_JERUSALEM_1,
    ): 'https://ingestion.logging.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.ME_ABUDHABI_1,
    ): 'https://ingestion.logging.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.ME_DUBAI_1,
    ): 'https://ingestion.logging.me-dubai-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.ME_JEDDAH_1,
    ): 'https://ingestion.logging.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.ME_RIYADH_1,
    ): 'https://ingestion.logging.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.MX_MONTERREY_1,
    ): 'https://ingestion.logging.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.MX_QUERETARO_1,
    ): 'https://ingestion.logging.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.SA_BOGOTA_1,
    ): 'https://ingestion.logging.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.SA_SAOPAULO_1,
    ): 'https://ingestion.logging.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.SA_VALPARAISO_1,
    ): 'https://ingestion.logging.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.SA_VINHEDO_1,
    ): 'https://ingestion.logging.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.UK_CARDIFF_1,
    ): 'https://ingestion.logging.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.UK_LONDON_1,
    ): 'https://ingestion.logging.uk-london-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.US_ASHBURN_1,
    ): 'https://ingestion.logging.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.US_PHOENIX_1,
    ): 'https://ingestion.logging.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.LOGGING_DATAPLANE,
        Region.US_SANJOSE_1,
    ): 'https://ingestion.logging.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AF_JOHANNESBURG_1,
    ): 'https://logging.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AP_BATAM_1,
    ): 'https://logging.ap-batam-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AP_CHUNCHEON_1,
    ): 'https://logging.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AP_HYDERABAD_1,
    ): 'https://logging.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AP_MELBOURNE_1,
    ): 'https://logging.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AP_MUMBAI_1,
    ): 'https://logging.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AP_OSAKA_1,
    ): 'https://logging.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AP_SEOUL_1,
    ): 'https://logging.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AP_SINGAPORE_1,
    ): 'https://logging.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AP_SINGAPORE_2,
    ): 'https://logging.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AP_SYDNEY_1,
    ): 'https://logging.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.AP_TOKYO_1,
    ): 'https://logging.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.CA_MONTREAL_1,
    ): 'https://logging.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.CA_TORONTO_1,
    ): 'https://logging.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.EU_AMSTERDAM_1,
    ): 'https://logging.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.EU_FRANKFURT_1,
    ): 'https://logging.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.EU_JOVANOVAC_1,
    ): 'https://logging.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.EU_MADRID_1,
    ): 'https://logging.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.EU_MARSEILLE_1,
    ): 'https://logging.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.EU_MILAN_1,
    ): 'https://logging.eu-milan-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.EU_PARIS_1,
    ): 'https://logging.eu-paris-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.EU_STOCKHOLM_1,
    ): 'https://logging.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.EU_ZURICH_1,
    ): 'https://logging.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.IL_JERUSALEM_1,
    ): 'https://logging.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.ME_ABUDHABI_1,
    ): 'https://logging.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.ME_DUBAI_1,
    ): 'https://logging.me-dubai-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.ME_JEDDAH_1,
    ): 'https://logging.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.ME_RIYADH_1,
    ): 'https://logging.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.MX_MONTERREY_1,
    ): 'https://logging.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.MX_QUERETARO_1,
    ): 'https://logging.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.SA_BOGOTA_1,
    ): 'https://logging.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.SA_SANTIAGO_1,
    ): 'https://logging.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.SA_SAOPAULO_1,
    ): 'https://logging.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.SA_VALPARAISO_1,
    ): 'https://logging.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.SA_VINHEDO_1,
    ): 'https://logging.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.UK_CARDIFF_1,
    ): 'https://logging.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.UK_LONDON_1,
    ): 'https://logging.uk-london-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.US_ASHBURN_1,
    ): 'https://logging.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.US_PHOENIX_1,
    ): 'https://logging.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.LOGGING_MANAGEMENT,
        Region.US_SANJOSE_1,
    ): 'https://logging.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.AF_JOHANNESBURG_1,
    ): 'https://logging.af-johannesburg-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.AP_BATAM_1): 'https://logging.ap-batam-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.AP_CHUNCHEON_1,
    ): 'https://logging.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.AP_HYDERABAD_1,
    ): 'https://logging.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.AP_MELBOURNE_1,
    ): 'https://logging.ap-melbourne-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.AP_MUMBAI_1): 'https://logging.ap-mumbai-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.AP_OSAKA_1): 'https://logging.ap-osaka-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.AP_SEOUL_1): 'https://logging.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.AP_SINGAPORE_1,
    ): 'https://logging.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.AP_SINGAPORE_2,
    ): 'https://logging.ap-singapore-2.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.AP_SYDNEY_1): 'https://logging.ap-sydney-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.AP_TOKYO_1): 'https://logging.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.CA_MONTREAL_1,
    ): 'https://logging.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.CA_TORONTO_1,
    ): 'https://logging.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.EU_AMSTERDAM_1,
    ): 'https://logging.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.EU_FRANKFURT_1,
    ): 'https://logging.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.EU_JOVANOVAC_1,
    ): 'https://logging.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.LOGGING_SEARCH, Region.EU_MADRID_1): 'https://logging.eu-madrid-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.EU_MADRID_3): 'https://logging.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.EU_MARSEILLE_1,
    ): 'https://logging.eu-marseille-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.EU_MILAN_1): 'https://logging.eu-milan-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.EU_PARIS_1): 'https://logging.eu-paris-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.EU_STOCKHOLM_1,
    ): 'https://logging.eu-stockholm-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.EU_TURIN_1): 'https://logging.eu-turin-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.EU_ZURICH_1): 'https://logging.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.IL_JERUSALEM_1,
    ): 'https://logging.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.ME_ABUDHABI_1,
    ): 'https://logging.me-abudhabi-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.ME_DUBAI_1): 'https://logging.me-dubai-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.ME_JEDDAH_1): 'https://logging.me-jeddah-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.ME_RIYADH_1): 'https://logging.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.MX_MONTERREY_1,
    ): 'https://logging.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.MX_QUERETARO_1,
    ): 'https://logging.mx-queretaro-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.SA_BOGOTA_1): 'https://logging.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.SA_SANTIAGO_1,
    ): 'https://logging.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.SA_SAOPAULO_1,
    ): 'https://logging.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.SA_VALPARAISO_1,
    ): 'https://logging.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.SA_VINHEDO_1,
    ): 'https://logging.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.UK_CARDIFF_1,
    ): 'https://logging.uk-cardiff-1.oci.oraclecloud.com',
    (Service.LOGGING_SEARCH, Region.UK_LONDON_1): 'https://logging.uk-london-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.US_ASHBURN_1,
    ): 'https://logging.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.US_PHOENIX_1,
    ): 'https://logging.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.LOGGING_SEARCH,
        Region.US_SANJOSE_1,
    ): 'https://logging.us-sanjose-1.oci.oraclecloud.com',
    (Service.LUSTRE, Region.AP_BATAM_1): 'https://lustre-file-storage.ap-batam-1.oraclecloud.com',
    (
        Service.LUSTRE,
        Region.AP_MELBOURNE_1,
    ): 'https://lustre-file-storage.ap-melbourne-1.oraclecloud.com',
    (Service.LUSTRE, Region.AP_OSAKA_1): 'https://lustre-file-storage.ap-osaka-1.oraclecloud.com',
    (
        Service.LUSTRE,
        Region.AP_SINGAPORE_1,
    ): 'https://lustre-file-storage.ap-singapore-1.oraclecloud.com',
    (Service.LUSTRE, Region.AP_SYDNEY_1): 'https://lustre-file-storage.ap-sydney-1.oraclecloud.com',
    (Service.LUSTRE, Region.AP_TOKYO_1): 'https://lustre-file-storage.ap-tokyo-1.oraclecloud.com',
    (
        Service.LUSTRE,
        Region.CA_MONTREAL_1,
    ): 'https://lustre-file-storage.ca-montreal-1.oraclecloud.com',
    (
        Service.LUSTRE,
        Region.EU_AMSTERDAM_1,
    ): 'https://lustre-file-storage.eu-amsterdam-1.oraclecloud.com',
    (
        Service.LUSTRE,
        Region.EU_FRANKFURT_1,
    ): 'https://lustre-file-storage.eu-frankfurt-1.oraclecloud.com',
    (Service.LUSTRE, Region.EU_MADRID_1): 'https://lustre-file-storage.eu-madrid-1.oraclecloud.com',
    (Service.LUSTRE, Region.EU_MADRID_3): 'https://lustre-file-storage.eu-madrid-3.oraclecloud.com',
    (
        Service.LUSTRE,
        Region.ME_ABUDHABI_1,
    ): 'https://lustre-file-storage.me-abudhabi-1.oraclecloud.com',
    (
        Service.LUSTRE,
        Region.SA_SAOPAULO_1,
    ): 'https://lustre-file-storage.sa-saopaulo-1.oraclecloud.com',
    (
        Service.LUSTRE,
        Region.UK_CARDIFF_1,
    ): 'https://lustre-file-storage.uk-cardiff-1.oraclecloud.com',
    (Service.LUSTRE, Region.UK_LONDON_1): 'https://lustre-file-storage.uk-london-1.oraclecloud.com',
    (
        Service.LUSTRE,
        Region.US_ASHBURN_1,
    ): 'https://lustre-file-storage.us-ashburn-1.oraclecloud.com',
    (
        Service.LUSTRE,
        Region.US_CHICAGO_1,
    ): 'https://lustre-file-storage.us-chicago-1.oraclecloud.com/',
    (
        Service.LUSTRE,
        Region.US_PHOENIX_1,
    ): 'https://lustre-file-storage.us-phoenix-1.oraclecloud.com',
    (
        Service.LUSTRE,
        Region.US_SANJOSE_1,
    ): 'https://lustre-file-storage.us-sanjose-1.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://managed-access.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AP_BATAM_1,
    ): 'https://managed-access.ap-batam-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AP_CHUNCHEON_1,
    ): 'https://managed-access.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AP_HYDERABAD_1,
    ): 'https://managed-access.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AP_MELBOURNE_1,
    ): 'https://managed-access.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AP_MUMBAI_1,
    ): 'https://managed-access.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AP_OSAKA_1,
    ): 'https://managed-access.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AP_SEOUL_1,
    ): 'https://managed-access.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AP_SINGAPORE_1,
    ): 'https://managed-access.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AP_SINGAPORE_2,
    ): 'https://managed-access.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AP_SYDNEY_1,
    ): 'https://managed-access.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.AP_TOKYO_1,
    ): 'https://managed-access.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.CA_MONTREAL_1,
    ): 'https://managed-access.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.CA_TORONTO_1,
    ): 'https://managed-access.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.EU_AMSTERDAM_1,
    ): 'https://managed-access.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.EU_FRANKFURT_1,
    ): 'https://managed-access.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.EU_MARSEILLE_1,
    ): 'https://managed-access.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.EU_MILAN_1,
    ): 'https://managed-access.eu-milan-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.EU_STOCKHOLM_1,
    ): 'https://managed-access.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.EU_ZURICH_1,
    ): 'https://managed-access.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.IL_JERUSALEM_1,
    ): 'https://managed-access.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.ME_ABUDHABI_1,
    ): 'https://managed-access.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.ME_DUBAI_1,
    ): 'https://managed-access.me-dubai-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.ME_JEDDAH_1,
    ): 'https://managed-access.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.ME_RIYADH_1,
    ): 'https://managed-access.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.MX_MONTERREY_1,
    ): 'https://managed-access.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.MX_QUERETARO_1,
    ): 'https://managed-access.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.SA_BOGOTA_1,
    ): 'https://managed-access.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.SA_SANTIAGO_1,
    ): 'https://managed-access.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.SA_SAOPAULO_1,
    ): 'https://managed-access.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.SA_VALPARAISO_1,
    ): 'https://managed-access.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.SA_VINHEDO_1,
    ): 'https://managed-access.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.UK_CARDIFF_1,
    ): 'https://managed-access.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.UK_LONDON_1,
    ): 'https://managed-access.uk-london-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.US_ASHBURN_1,
    ): 'https://managed-access.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.US_PHOENIX_1,
    ): 'https://managed-access.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.MANAGED_ACCESS,
        Region.US_SANJOSE_1,
    ): 'https://managed-access.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AF_JOHANNESBURG_1,
    ): 'https://management-agent.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AP_BATAM_1,
    ): 'https://management-agent.ap-batam-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AP_CHUNCHEON_1,
    ): 'https://management-agent.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AP_HYDERABAD_1,
    ): 'https://management-agent.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AP_MELBOURNE_1,
    ): 'https://management-agent.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AP_MUMBAI_1,
    ): 'https://management-agent.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AP_OSAKA_1,
    ): 'https://management-agent.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AP_SEOUL_1,
    ): 'https://management-agent.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AP_SINGAPORE_1,
    ): 'https://management-agent.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AP_SINGAPORE_2,
    ): 'https://management-agent.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AP_SYDNEY_1,
    ): 'https://management-agent.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.AP_TOKYO_1,
    ): 'https://management-agent.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.CA_MONTREAL_1,
    ): 'https://management-agent.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.CA_TORONTO_1,
    ): 'https://management-agent.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.EU_AMSTERDAM_1,
    ): 'https://management-agent.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.EU_FRANKFURT_1,
    ): 'https://management-agent.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.EU_JOVANOVAC_1,
    ): 'https://management-agent.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.EU_MADRID_1,
    ): 'https://management-agent.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.EU_MADRID_3,
    ): 'https://management-agent.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.EU_MARSEILLE_1,
    ): 'https://management-agent.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.EU_MILAN_1,
    ): 'https://management-agent.eu-milan-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.EU_PARIS_1,
    ): 'https://management-agent.eu-paris-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.EU_STOCKHOLM_1,
    ): 'https://management-agent.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.EU_TURIN_1,
    ): 'https://management-agent.eu-turin-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.EU_ZURICH_1,
    ): 'https://management-agent.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.IL_JERUSALEM_1,
    ): 'https://management-agent.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.ME_ABUDHABI_1,
    ): 'https://management-agent.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.ME_DUBAI_1,
    ): 'https://management-agent.me-dubai-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.ME_JEDDAH_1,
    ): 'https://management-agent.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.ME_RIYADH_1,
    ): 'https://management-agent.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.MX_MONTERREY_1,
    ): 'https://management-agent.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.MX_QUERETARO_1,
    ): 'https://management-agent.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.SA_BOGOTA_1,
    ): 'https://management-agent.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.SA_SANTIAGO_1,
    ): 'https://management-agent.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.SA_SAOPAULO_1,
    ): 'https://management-agent.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.SA_VALPARAISO_1,
    ): 'https://management-agent.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.SA_VINHEDO_1,
    ): 'https://management-agent.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.UK_CARDIFF_1,
    ): 'https://management-agent.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.UK_LONDON_1,
    ): 'https://management-agent.uk-london-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.US_ASHBURN_1,
    ): 'https://management-agent.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.US_CHICAGO_1,
    ): 'https://management-agent.us-chicago-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.US_PHOENIX_1,
    ): 'https://management-agent.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENT_AGENT,
        Region.US_SANJOSE_1,
    ): 'https://management-agent.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AF_JOHANNESBURG_1,
    ): 'https://managementdashboard.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AP_BATAM_1,
    ): 'https://managementdashboard.ap-batam-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AP_CHUNCHEON_1,
    ): 'https://managementdashboard.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AP_HYDERABAD_1,
    ): 'https://managementdashboard.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AP_MELBOURNE_1,
    ): 'https://managementdashboard.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AP_MUMBAI_1,
    ): 'https://managementdashboard.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AP_OSAKA_1,
    ): 'https://managementdashboard.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AP_SEOUL_1,
    ): 'https://managementdashboard.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AP_SINGAPORE_1,
    ): 'https://managementdashboard.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AP_SINGAPORE_2,
    ): 'https://managementdashboard.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AP_SYDNEY_1,
    ): 'https://managementdashboard.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.AP_TOKYO_1,
    ): 'https://managementdashboard.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.CA_MONTREAL_1,
    ): 'https://managementdashboard.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.CA_TORONTO_1,
    ): 'https://managementdashboard.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.EU_AMSTERDAM_1,
    ): 'https://managementdashboard.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.EU_FRANKFURT_1,
    ): 'https://managementdashboard.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.EU_MARSEILLE_1,
    ): 'https://managementdashboard.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.EU_MILAN_1,
    ): 'https://managementdashboard.eu-milan-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.EU_STOCKHOLM_1,
    ): 'https://managementdashboard.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.EU_ZURICH_1,
    ): 'https://managementdashboard.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.IL_JERUSALEM_1,
    ): 'https://managementdashboard.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.ME_ABUDHABI_1,
    ): 'https://managementdashboard.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.ME_DUBAI_1,
    ): 'https://managementdashboard.me-dubai-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.ME_JEDDAH_1,
    ): 'https://managementdashboard.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.ME_RIYADH_1,
    ): 'https://managementdashboard.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.MX_MONTERREY_1,
    ): 'https://managementdashboard.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.MX_QUERETARO_1,
    ): 'https://managementdashboard.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.SA_BOGOTA_1,
    ): 'https://managementdashboard.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.SA_SANTIAGO_1,
    ): 'https://managementdashboard.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.SA_SAOPAULO_1,
    ): 'https://managementdashboard.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.SA_VALPARAISO_1,
    ): 'https://managementdashboard.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.SA_VINHEDO_1,
    ): 'https://managementdashboard.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.UK_CARDIFF_1,
    ): 'https://managementdashboard.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.UK_LONDON_1,
    ): 'https://managementdashboard.uk-london-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.US_ASHBURN_1,
    ): 'https://managementdashboard.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.US_PHOENIX_1,
    ): 'https://managementdashboard.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.MANAGEMENTDASHBOARD,
        Region.US_SANJOSE_1,
    ): 'https://managementdashboard.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://marketplace.af-johannesburg-1.oci.oraclecloud.com',
    (Service.MARKETPLACE, Region.AP_BATAM_1): 'https://marketplace.ap-batam-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.AP_CHUNCHEON_1,
    ): 'https://marketplace.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.AP_HYDERABAD_1,
    ): 'https://marketplace.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.AP_MELBOURNE_1,
    ): 'https://marketplace.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.AP_MUMBAI_1,
    ): 'https://marketplace.ap-mumbai-1.oci.oraclecloud.com',
    (Service.MARKETPLACE, Region.AP_OSAKA_1): 'https://marketplace.ap-osaka-1.oci.oraclecloud.com',
    (Service.MARKETPLACE, Region.AP_SEOUL_1): 'https://marketplace.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.AP_SINGAPORE_1,
    ): 'https://marketplace.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.AP_SINGAPORE_2,
    ): 'https://marketplace.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.AP_SYDNEY_1,
    ): 'https://marketplace.ap-sydney-1.oci.oraclecloud.com',
    (Service.MARKETPLACE, Region.AP_TOKYO_1): 'https://marketplace.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.CA_MONTREAL_1,
    ): 'https://marketplace.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.CA_TORONTO_1,
    ): 'https://marketplace.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.EU_AMSTERDAM_1,
    ): 'https://marketplace.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.EU_FRANKFURT_1,
    ): 'https://marketplace.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.EU_JOVANOVAC_1,
    ): 'https://marketplace.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.MARKETPLACE,
        Region.EU_MADRID_1,
    ): 'https://marketplace.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.EU_MADRID_3,
    ): 'https://marketplace.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.EU_MARSEILLE_1,
    ): 'https://marketplace.eu-marseille-1.oci.oraclecloud.com',
    (Service.MARKETPLACE, Region.EU_MILAN_1): 'https://marketplace.eu-milan-1.oci.oraclecloud.com',
    (Service.MARKETPLACE, Region.EU_PARIS_1): 'https://marketplace.eu-paris-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.EU_STOCKHOLM_1,
    ): 'https://marketplace.eu-stockholm-1.oci.oraclecloud.com',
    (Service.MARKETPLACE, Region.EU_TURIN_1): 'https://marketplace.eu-turin-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.EU_ZURICH_1,
    ): 'https://marketplace.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.IL_JERUSALEM_1,
    ): 'https://marketplace.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.ME_ABUDHABI_1,
    ): 'https://marketplace.me-abudhabi-1.oci.oraclecloud.com',
    (Service.MARKETPLACE, Region.ME_DUBAI_1): 'https://marketplace.me-dubai-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.ME_JEDDAH_1,
    ): 'https://marketplace.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.ME_RIYADH_1,
    ): 'https://marketplace.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.MX_MONTERREY_1,
    ): 'https://marketplace.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.MX_QUERETARO_1,
    ): 'https://marketplace.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.SA_BOGOTA_1,
    ): 'https://marketplace.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.SA_SANTIAGO_1,
    ): 'https://marketplace.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.SA_SAOPAULO_1,
    ): 'https://marketplace.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.SA_VALPARAISO_1,
    ): 'https://marketplace.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.SA_VINHEDO_1,
    ): 'https://marketplace.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.UK_CARDIFF_1,
    ): 'https://marketplace.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.UK_LONDON_1,
    ): 'https://marketplace.uk-london-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.US_ASHBURN_1,
    ): 'https://marketplace.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.US_CHICAGO_1,
    ): 'https://marketplace.us-chicago-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.US_PHOENIX_1,
    ): 'https://marketplace.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.MARKETPLACE,
        Region.US_SANJOSE_1,
    ): 'https://marketplace.us-sanjose-1.oci.oraclecloud.com',
    (Service.MNGDMAC, Region.US_ASHBURN_1): 'https://mngdmac.us-ashburn-1.oci.oraclecloud.com/',
    (
        Service.MONITORING,
        Region.AF_JOHANNESBURG_1,
    ): 'https://telemetry.af-johannesburg-1.oraclecloud.com',
    (
        Service.MONITORING,
        Region.AP_BATAM_1,
    ): 'https://telemetry-ingestion.ap-batam-1.oraclecloud.com',
    (Service.MONITORING, Region.AP_CHUNCHEON_1): 'https://telemetry.ap-chuncheon-1.oraclecloud.com',
    (Service.MONITORING, Region.AP_HYDERABAD_1): 'https://telemetry.ap-hyderabad-1.oraclecloud.com',
    (Service.MONITORING, Region.AP_MELBOURNE_1): 'https://telemetry.ap-melbourne-1.oraclecloud.com',
    (Service.MONITORING, Region.AP_MUMBAI_1): 'https://telemetry.ap-mumbai-1.oraclecloud.com',
    (Service.MONITORING, Region.AP_OSAKA_1): 'https://telemetry.ap-osaka-1.oraclecloud.com',
    (Service.MONITORING, Region.AP_SEOUL_1): 'https://telemetry.ap-seoul-1.oraclecloud.com',
    (Service.MONITORING, Region.AP_SINGAPORE_1): 'https://telemetry.ap-singapore-1.oraclecloud.com',
    (Service.MONITORING, Region.AP_SINGAPORE_2): 'https://telemetry.ap-singapore-2.oraclecloud.com',
    (Service.MONITORING, Region.AP_SYDNEY_1): 'https://telemetry.ap-sydney-1.oraclecloud.com',
    (Service.MONITORING, Region.AP_TOKYO_1): 'https://telemetry.ap-tokyo-1.oraclecloud.com',
    (Service.MONITORING, Region.CA_MONTREAL_1): 'https://telemetry.ca-montreal-1.oraclecloud.com',
    (Service.MONITORING, Region.CA_TORONTO_1): 'https://telemetry.ca-toronto-1.oraclecloud.com',
    (Service.MONITORING, Region.EU_AMSTERDAM_1): 'https://telemetry.eu-amsterdam-1.oraclecloud.com',
    (Service.MONITORING, Region.EU_FRANKFURT_1): 'https://telemetry.eu-frankfurt-1.oraclecloud.com',
    (
        Service.MONITORING,
        Region.EU_JOVANOVAC_1,
    ): 'https://telemetry.eu-jovanovac-1.oraclecloud20.com',
    (Service.MONITORING, Region.EU_MADRID_1): 'https://telemetry.eu-madrid-1.oraclecloud.com',
    (
        Service.MONITORING,
        Region.EU_MADRID_3,
    ): 'https://telemetry-ingestion.eu-madrid-3.oraclecloud.com',
    (Service.MONITORING, Region.EU_MARSEILLE_1): 'https://telemetry.eu-marseille-1.oraclecloud.com',
    (Service.MONITORING, Region.EU_MILAN_1): 'https://telemetry.eu-milan-1.oraclecloud.com',
    (Service.MONITORING, Region.EU_PARIS_1): 'https://telemetry.eu-paris-1.oraclecloud.com',
    (Service.MONITORING, Region.EU_STOCKHOLM_1): 'https://telemetry.eu-stockholm-1.oraclecloud.com',
    (
        Service.MONITORING,
        Region.EU_TURIN_1,
    ): 'https://telemetry-ingestion.eu-turin-1.oraclecloud.com',
    (Service.MONITORING, Region.EU_ZURICH_1): 'https://telemetry.eu-zurich-1.oraclecloud.com',
    (Service.MONITORING, Region.IL_JERUSALEM_1): 'https://telemetry.il-jerusalem-1.oraclecloud.com',
    (Service.MONITORING, Region.ME_ABUDHABI_1): 'https://telemetry.me-abudhabi-1.oraclecloud.com',
    (Service.MONITORING, Region.ME_DUBAI_1): 'https://telemetry.me-dubai-1.oraclecloud.com',
    (Service.MONITORING, Region.ME_JEDDAH_1): 'https://telemetry.me-jeddah-1.oraclecloud.com',
    (Service.MONITORING, Region.ME_RIYADH_1): 'https://telemetry.me-riyadh-1.oraclecloud.com',
    (Service.MONITORING, Region.MX_MONTERREY_1): 'https://telemetry.mx-monterrey-1.oraclecloud.com',
    (Service.MONITORING, Region.MX_QUERETARO_1): 'https://telemetry.mx-queretaro-1.oraclecloud.com',
    (Service.MONITORING, Region.SA_BOGOTA_1): 'https://telemetry.sa-bogota-1.oraclecloud.com',
    (Service.MONITORING, Region.SA_SANTIAGO_1): 'https://telemetry.sa-santiago-1.oraclecloud.com',
    (Service.MONITORING, Region.SA_SAOPAULO_1): 'https://telemetry.sa-saopaulo-1.oraclecloud.com',
    (Service.MONITORING, Region.SA_VINHEDO_1): 'https://telemetry.sa-vinhedo-1.oraclecloud.com',
    (Service.MONITORING, Region.UK_CARDIFF_1): 'https://telemetry.uk-cardiff-1.oraclecloud.com',
    (Service.MONITORING, Region.UK_LONDON_1): 'https://telemetry.uk-london-1.oraclecloud.com',
    (Service.MONITORING, Region.US_ASHBURN_1): 'https://telemetry.us-ashburn-1.oraclecloud.com',
    (Service.MONITORING, Region.US_CHICAGO_1): 'https://telemetry.us-chicago-1.oraclecloud.com',
    (Service.MONITORING, Region.US_PHOENIX_1): 'https://telemetry.us-phoenix-1.oraclecloud.com',
    (Service.MONITORING, Region.US_SANJOSE_1): 'https://telemetry.us-sanjose-1.oraclecloud.com',
    (
        Service.MULTICLOUD_OMHUB_CP,
        Region.US_ASHBURN_1,
    ): 'https://omhub-cp.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.MYSQL,
        Region.AF_JOHANNESBURG_1,
    ): 'https://mysql.af-johannesburg-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.AP_BATAM_1): 'https://mysql.ap-batam-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.AP_CHUNCHEON_1): 'https://mysql.ap-chuncheon-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.AP_HYDERABAD_1): 'https://mysql.ap-hyderabad-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.AP_MELBOURNE_1): 'https://mysql.ap-melbourne-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.AP_MUMBAI_1): 'https://mysql.ap-mumbai-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.AP_OSAKA_1): 'https://mysql.ap-osaka-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.AP_SEOUL_1): 'https://mysql.ap-seoul-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.AP_SINGAPORE_1): 'https://mysql.ap-singapore-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.AP_SINGAPORE_2): 'https://mysql.ap-singapore-2.ocp.oraclecloud.com',
    (Service.MYSQL, Region.AP_SYDNEY_1): 'https://mysql.ap-sydney-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.AP_TOKYO_1): 'https://mysql.ap-tokyo-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.CA_MONTREAL_1): 'https://mysql.ca-montreal-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.CA_TORONTO_1): 'https://mysql.ca-toronto-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.EU_AMSTERDAM_1): 'https://mysql.eu-amsterdam-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.EU_FRANKFURT_1): 'https://mysql.eu-frankfurt-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.EU_JOVANOVAC_1): 'https://mysql.eu-jovanovac-1.ocp.oraclecloud20.com',
    (Service.MYSQL, Region.EU_MADRID_1): 'https://mysql.eu-madrid-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.EU_MADRID_3): 'https://mysql.eu-madrid-3.ocp.oraclecloud.com',
    (Service.MYSQL, Region.EU_MARSEILLE_1): 'https://mysql.eu-marseille-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.EU_MILAN_1): 'https://mysql.eu-milan-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.EU_PARIS_1): 'https://mysql.eu-paris-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.EU_STOCKHOLM_1): 'https://mysql.eu-stockholm-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.EU_TURIN_1): 'https://mysql.eu-turin-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.EU_ZURICH_1): 'https://mysql.eu-zurich-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.IL_JERUSALEM_1): 'https://mysql.il-jerusalem-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.ME_ABUDHABI_1): 'https://mysql.me-abudhabi-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.ME_DUBAI_1): 'https://mysql.me-dubai-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.ME_JEDDAH_1): 'https://mysql.me-jeddah-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.ME_RIYADH_1): 'https://mysql.me-riyadh-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.MX_MONTERREY_1): 'https://mysql.mx-monterrey-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.MX_QUERETARO_1): 'https://mysql.mx-queretaro-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.SA_BOGOTA_1): 'https://mysql.sa-bogota-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.SA_SANTIAGO_1): 'https://mysql.sa-santiago-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.SA_SAOPAULO_1): 'https://mysql.sa-saopaulo-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.SA_VALPARAISO_1): 'https://mysql.sa-valparaiso-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.SA_VINHEDO_1): 'https://mysql.sa-vinhedo-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.UK_CARDIFF_1): 'https://mysql.uk-cardiff-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.UK_LONDON_1): 'https://mysql.uk-london-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.US_ASHBURN_1): 'https://mysql.us-ashburn-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.US_PHOENIX_1): 'https://mysql.us-phoenix-1.ocp.oraclecloud.com',
    (Service.MYSQL, Region.US_SANJOSE_1): 'https://mysql.us-sanjose-1.ocp.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AF_JOHANNESBURG_1,
    ): 'https://network-firewall.af-johannesburg-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AP_BATAM_1,
    ): 'https://network-firewall.ap-batam-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AP_CHUNCHEON_1,
    ): 'https://network-firewall.ap-chuncheon-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AP_HYDERABAD_1,
    ): 'https://network-firewall.ap-hyderabad-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AP_MELBOURNE_1,
    ): 'https://network-firewall.ap-melbourne-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AP_MUMBAI_1,
    ): 'https://network-firewall.ap-mumbai-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AP_OSAKA_1,
    ): 'https://network-firewall.ap-osaka-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AP_SEOUL_1,
    ): 'https://network-firewall.ap-seoul-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AP_SINGAPORE_1,
    ): 'https://network-firewall.ap-singapore-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AP_SINGAPORE_2,
    ): 'https://network-firewall.ap-singapore-2.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AP_SYDNEY_1,
    ): 'https://network-firewall.ap-sydney-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.AP_TOKYO_1,
    ): 'https://network-firewall.ap-tokyo-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.CA_MONTREAL_1,
    ): 'https://network-firewall.ca-montreal-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.CA_TORONTO_1,
    ): 'https://network-firewall.ca-toronto-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.EU_AMSTERDAM_1,
    ): 'https://network-firewall.eu-amsterdam-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.EU_FRANKFURT_1,
    ): 'https://network-firewall.eu-frankfurt-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.EU_JOVANOVAC_1,
    ): 'https://network-firewall.eu-jovanovac-1.ocs.oraclecloud20.com',
    (
        Service.NETWORK_FIREWALL,
        Region.EU_MADRID_1,
    ): 'https://network-firewall.eu-madrid-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.EU_MADRID_3,
    ): 'https://network-firewall.eu-madrid-3.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.EU_MARSEILLE_1,
    ): 'https://network-firewall.eu-marseille-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.EU_MILAN_1,
    ): 'https://network-firewall.eu-milan-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.EU_STOCKHOLM_1,
    ): 'https://network-firewall.eu-stockholm-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.EU_TURIN_1,
    ): 'https://network-firewall.eu-turin-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.EU_ZURICH_1,
    ): 'https://network-firewall.eu-zurich-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.IL_JERUSALEM_1,
    ): 'https://network-firewall.il-jerusalem-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.ME_ABUDHABI_1,
    ): 'https://network-firewall.me-abudhabi-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.ME_DUBAI_1,
    ): 'https://network-firewall.me-dubai-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.ME_JEDDAH_1,
    ): 'https://network-firewall.me-jeddah-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.ME_RIYADH_1,
    ): 'https://network-firewall.me-riyadh-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.MX_MONTERREY_1,
    ): 'https://network-firewall.mx-monterrey-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.MX_QUERETARO_1,
    ): 'https://network-firewall.mx-queretaro-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.SA_BOGOTA_1,
    ): 'https://network-firewall.sa-bogota-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.SA_SANTIAGO_1,
    ): 'https://network-firewall.sa-santiago-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.SA_SAOPAULO_1,
    ): 'https://network-firewall.sa-saopaulo-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.SA_VALPARAISO_1,
    ): 'https://network-firewall.sa-valparaiso-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.SA_VINHEDO_1,
    ): 'https://network-firewall.sa-vinhedo-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.UK_CARDIFF_1,
    ): 'https://network-firewall.uk-cardiff-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.UK_LONDON_1,
    ): 'https://network-firewall.uk-london-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.US_ASHBURN_1,
    ): 'https://network-firewall.us-ashburn-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.US_PHOENIX_1,
    ): 'https://network-firewall.us-phoenix-1.ocs.oraclecloud.com',
    (
        Service.NETWORK_FIREWALL,
        Region.US_SANJOSE_1,
    ): 'https://network-firewall.us-sanjose-1.ocs.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AF_JOHANNESBURG_1,
    ): 'https://network-load-balancer-api.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AP_BATAM_1,
    ): 'https://network-load-balancer-api.ap-batam-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AP_CHUNCHEON_1,
    ): 'https://network-load-balancer-api.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AP_HYDERABAD_1,
    ): 'https://network-load-balancer-api.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AP_MELBOURNE_1,
    ): 'https://network-load-balancer-api.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AP_MUMBAI_1,
    ): 'https://network-load-balancer-api.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AP_OSAKA_1,
    ): 'https://network-load-balancer-api.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AP_SEOUL_1,
    ): 'https://network-load-balancer-api.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AP_SINGAPORE_1,
    ): 'https://network-load-balancer-api.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AP_SINGAPORE_2,
    ): 'https://network-load-balancer-api.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AP_SYDNEY_1,
    ): 'https://network-load-balancer-api.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.AP_TOKYO_1,
    ): 'https://network-load-balancer-api.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.CA_MONTREAL_1,
    ): 'https://network-load-balancer-api.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.CA_TORONTO_1,
    ): 'https://network-load-balancer-api.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.EU_AMSTERDAM_1,
    ): 'https://network-load-balancer-api.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.EU_FRANKFURT_1,
    ): 'https://network-load-balancer-api.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.EU_JOVANOVAC_1,
    ): 'https://network-load-balancer-api.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.EU_MADRID_1,
    ): 'https://network-load-balancer-api.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.EU_MADRID_3,
    ): 'https://network-load-balancer-api.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.EU_MARSEILLE_1,
    ): 'https://network-load-balancer-api.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.EU_MILAN_1,
    ): 'https://network-load-balancer-api.eu-milan-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.EU_PARIS_1,
    ): 'https://network-load-balancer-api.eu-paris-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.EU_STOCKHOLM_1,
    ): 'https://network-load-balancer-api.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.EU_TURIN_1,
    ): 'https://network-load-balancer-api.eu-turin-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.EU_ZURICH_1,
    ): 'https://network-load-balancer-api.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.IL_JERUSALEM_1,
    ): 'https://network-load-balancer-api.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.ME_ABUDHABI_1,
    ): 'https://network-load-balancer-api.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.ME_DUBAI_1,
    ): 'https://network-load-balancer-api.me-dubai-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.ME_JEDDAH_1,
    ): 'https://network-load-balancer-api.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.ME_RIYADH_1,
    ): 'https://network-load-balancer-api.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.MX_MONTERREY_1,
    ): 'https://network-load-balancer-api.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.MX_QUERETARO_1,
    ): 'https://network-load-balancer-api.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.SA_BOGOTA_1,
    ): 'https://network-load-balancer-api.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.SA_SANTIAGO_1,
    ): 'https://network-load-balancer-api.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.SA_SAOPAULO_1,
    ): 'https://network-load-balancer-api.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.SA_VALPARAISO_1,
    ): 'https://network-load-balancer-api.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.SA_VINHEDO_1,
    ): 'https://network-load-balancer-api.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.UK_CARDIFF_1,
    ): 'https://network-load-balancer-api.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.UK_LONDON_1,
    ): 'https://network-load-balancer-api.uk-london-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.US_ASHBURN_1,
    ): 'https://network-load-balancer-api.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.US_CHICAGO_1,
    ): 'https://network-load-balancer-api.us-chicago-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.US_PHOENIX_1,
    ): 'https://network-load-balancer-api.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.NETWORKLOADBALANCER,
        Region.US_SANJOSE_1,
    ): 'https://network-load-balancer-api.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://nosql.af-johannesburg-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.AP_BATAM_1): 'https://nosql.ap-batam-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.AP_CHUNCHEON_1,
    ): 'https://nosql.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.AP_HYDERABAD_1,
    ): 'https://nosql.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.AP_MELBOURNE_1,
    ): 'https://nosql.ap-melbourne-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.AP_MUMBAI_1): 'https://nosql.ap-mumbai-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.AP_OSAKA_1): 'https://nosql.ap-osaka-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.AP_SEOUL_1): 'https://nosql.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.AP_SINGAPORE_1,
    ): 'https://nosql.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.AP_SINGAPORE_2,
    ): 'https://nosql.ap-singapore-2.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.AP_SYDNEY_1): 'https://nosql.ap-sydney-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.AP_TOKYO_1): 'https://nosql.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.CA_MONTREAL_1,
    ): 'https://nosql.ca-montreal-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.CA_TORONTO_1): 'https://nosql.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.EU_AMSTERDAM_1,
    ): 'https://nosql.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.EU_FRANKFURT_1,
    ): 'https://nosql.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.EU_JOVANOVAC_1,
    ): 'https://nosql.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.NOSQL_DATABASE, Region.EU_MADRID_1): 'https://nosql.eu-madrid-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.EU_MADRID_3): 'https://nosql.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.EU_MARSEILLE_1,
    ): 'https://nosql.eu-marseille-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.EU_MILAN_1): 'https://nosql.eu-milan-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.EU_PARIS_1): 'https://nosql.eu-paris-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.EU_STOCKHOLM_1,
    ): 'https://nosql.eu-stockholm-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.EU_TURIN_1): 'https://nosql.eu-turin-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.EU_ZURICH_1): 'https://nosql.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.IL_JERUSALEM_1,
    ): 'https://nosql.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.ME_ABUDHABI_1,
    ): 'https://nosql.me-abudhabi-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.ME_DUBAI_1): 'https://nosql.me-dubai-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.ME_JEDDAH_1): 'https://nosql.me-jeddah-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.ME_RIYADH_1): 'https://nosql.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.MX_MONTERREY_1,
    ): 'https://nosql.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.MX_QUERETARO_1,
    ): 'https://nosql.mx-queretaro-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.SA_BOGOTA_1): 'https://nosql.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.SA_SANTIAGO_1,
    ): 'https://nosql.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.SA_SAOPAULO_1,
    ): 'https://nosql.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.NOSQL_DATABASE,
        Region.SA_VALPARAISO_1,
    ): 'https://nosql.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.SA_VINHEDO_1): 'https://nosql.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.UK_CARDIFF_1): 'https://nosql.uk-cardiff-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.UK_LONDON_1): 'https://nosql.uk-london-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.US_ASHBURN_1): 'https://nosql.us-ashburn-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.US_CHICAGO_1): 'https://nosql.us-chicago-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.US_PHOENIX_1): 'https://nosql.us-phoenix-1.oci.oraclecloud.com',
    (Service.NOSQL_DATABASE, Region.US_SANJOSE_1): 'https://nosql.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AF_JOHANNESBURG_1,
    ): 'https://notification.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AP_BATAM_1,
    ): 'https://notification.ap-batam-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AP_CHUNCHEON_1,
    ): 'https://notification.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AP_HYDERABAD_1,
    ): 'https://notification.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AP_MELBOURNE_1,
    ): 'https://notification.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AP_MUMBAI_1,
    ): 'https://notification.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AP_OSAKA_1,
    ): 'https://notification.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AP_SEOUL_1,
    ): 'https://notification.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AP_SINGAPORE_1,
    ): 'https://notification.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AP_SINGAPORE_2,
    ): 'https://notification.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AP_SYDNEY_1,
    ): 'https://notification.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.AP_TOKYO_1,
    ): 'https://notification.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.CA_MONTREAL_1,
    ): 'https://notification.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.CA_TORONTO_1,
    ): 'https://notification.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.EU_AMSTERDAM_1,
    ): 'https://notification.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.EU_FRANKFURT_1,
    ): 'https://notification.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.EU_JOVANOVAC_1,
    ): 'https://notification.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.NOTIFICATION,
        Region.EU_MADRID_1,
    ): 'https://notification.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.EU_MADRID_3,
    ): 'https://notification.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.EU_MARSEILLE_1,
    ): 'https://notification.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.EU_MILAN_1,
    ): 'https://notification.eu-milan-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.EU_PARIS_1,
    ): 'https://notification.eu-paris-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.EU_STOCKHOLM_1,
    ): 'https://notification.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.EU_TURIN_1,
    ): 'https://notification.eu-turin-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.EU_ZURICH_1,
    ): 'https://notification.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.IL_JERUSALEM_1,
    ): 'https://notification.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.ME_ABUDHABI_1,
    ): 'https://notification.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.ME_DUBAI_1,
    ): 'https://notification.me-dubai-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.ME_JEDDAH_1,
    ): 'https://notification.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.ME_RIYADH_1,
    ): 'https://notification.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.MX_MONTERREY_1,
    ): 'https://notification.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.MX_QUERETARO_1,
    ): 'https://notification.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.SA_BOGOTA_1,
    ): 'https://notification.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.SA_SANTIAGO_1,
    ): 'https://notification.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.SA_SAOPAULO_1,
    ): 'https://notification.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.SA_VALPARAISO_1,
    ): 'https://notification.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.SA_VINHEDO_1,
    ): 'https://notification.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.UK_CARDIFF_1,
    ): 'https://notification.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.UK_LONDON_1,
    ): 'https://notification.uk-london-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.US_ASHBURN_1,
    ): 'https://notification.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.US_CHICAGO_1,
    ): 'https://notification.us-chicago-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.US_PHOENIX_1,
    ): 'https://notification.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.NOTIFICATION,
        Region.US_SANJOSE_1,
    ): 'https://notification.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://objectstorage.af-johannesburg-1.oraclecloud.com',
    (Service.OBJECTSTORAGE, Region.AP_BATAM_1): 'https://objectstorage.ap-batam-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.AP_CHUNCHEON_1,
    ): 'https://objectstorage.ap-chuncheon-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.AP_HYDERABAD_1,
    ): 'https://objectstorage.ap-hyderabad-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.AP_MELBOURNE_1,
    ): 'https://objectstorage.ap-melbourne-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.AP_MUMBAI_1,
    ): 'https://objectstorage.ap-mumbai-1.oraclecloud.com',
    (Service.OBJECTSTORAGE, Region.AP_OSAKA_1): 'https://objectstorage.ap-osaka-1.oraclecloud.com',
    (Service.OBJECTSTORAGE, Region.AP_SEOUL_1): 'https://objectstorage.ap-seoul-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.AP_SINGAPORE_1,
    ): 'https://objectstorage.ap-singapore-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.AP_SINGAPORE_2,
    ): 'https://objectstorage.ap-singapore-2.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.AP_SYDNEY_1,
    ): 'https://objectstorage.ap-sydney-1.oraclecloud.com',
    (Service.OBJECTSTORAGE, Region.AP_TOKYO_1): 'https://objectstorage.ap-tokyo-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.CA_MONTREAL_1,
    ): 'https://objectstorage.ca-montreal-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.CA_TORONTO_1,
    ): 'https://objectstorage.ca-toronto-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.EU_AMSTERDAM_1,
    ): 'https://objectstorage.eu-amsterdam-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.EU_FRANKFURT_1,
    ): 'https://objectstorage.eu-frankfurt-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.EU_JOVANOVAC_1,
    ): 'https://objectstorage.eu-jovanovac-1.oraclecloud20.com',
    (
        Service.OBJECTSTORAGE,
        Region.EU_MADRID_1,
    ): 'https://objectstorage.eu-madrid-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.EU_MADRID_3,
    ): 'https://objectstorage.eu-madrid-3.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.EU_MARSEILLE_1,
    ): 'https://objectstorage.eu-marseille-1.oraclecloud.com',
    (Service.OBJECTSTORAGE, Region.EU_MILAN_1): 'https://objectstorage.eu-milan-1.oraclecloud.com',
    (Service.OBJECTSTORAGE, Region.EU_PARIS_1): 'https://objectstorage.eu-paris-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.EU_STOCKHOLM_1,
    ): 'https://objectstorage.eu-stockholm-1.oraclecloud.com',
    (Service.OBJECTSTORAGE, Region.EU_TURIN_1): 'https://objectstorage.eu-turin-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.EU_ZURICH_1,
    ): 'https://objectstorage.eu-zurich-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.IL_JERUSALEM_1,
    ): 'https://objectstorage.il-jerusalem-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.ME_ABUDHABI_1,
    ): 'https://objectstorage.me-abudhabi-1.oraclecloud.com',
    (Service.OBJECTSTORAGE, Region.ME_DUBAI_1): 'https://objectstorage.me-dubai-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.ME_JEDDAH_1,
    ): 'https://objectstorage.me-jeddah-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.ME_RIYADH_1,
    ): 'https://objectstorage.me-riyadh-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.MX_MONTERREY_1,
    ): 'https://objectstorage.mx-monterrey-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.MX_QUERETARO_1,
    ): 'https://objectstorage.mx-queretaro-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.SA_BOGOTA_1,
    ): 'https://objectstorage.sa-bogota-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.SA_SANTIAGO_1,
    ): 'https://objectstorage.sa-santiago-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.SA_SAOPAULO_1,
    ): 'https://objectstorage.sa-saopaulo-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.SA_VALPARAISO_1,
    ): 'https://objectstorage.sa-valparaiso-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.SA_VINHEDO_1,
    ): 'https://objectstorage.sa-vinhedo-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.UK_CARDIFF_1,
    ): 'https://objectstorage.uk-cardiff-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.UK_LONDON_1,
    ): 'https://objectstorage.uk-london-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.US_ASHBURN_1,
    ): 'https://objectstorage.us-ashburn-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.US_CHICAGO_1,
    ): 'https://objectstorage.us-chicago-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.US_PHOENIX_1,
    ): 'https://objectstorage.us-phoenix-1.oraclecloud.com',
    (
        Service.OBJECTSTORAGE,
        Region.US_SANJOSE_1,
    ): 'https://objectstorage.us-sanjose-1.oraclecloud.com',
    (
        Service.OCCCM,
        Region.US_ASHBURN_1,
    ): 'https://control-center-cp.us-ashburn-1.oci.oraclecloud.com/',
    (
        Service.OCCDS,
        Region.US_ASHBURN_1,
    ): 'https://control-center-cp.us-ashburn-1.oci.oraclecloud.com/',
    (Service.OCE, Region.AF_JOHANNESBURG_1): 'https://cp.oce.af-johannesburg-1.ocp.oraclecloud.com',
    (Service.OCE, Region.AP_BATAM_1): 'https://cp.oce.ap-batam-1.ocp.oraclecloud.com',
    (Service.OCE, Region.AP_CHUNCHEON_1): 'https://cp.oce.ap-chuncheon-1.ocp.oraclecloud.com',
    (Service.OCE, Region.AP_HYDERABAD_1): 'https://cp.oce.ap-hyderabad-1.ocp.oraclecloud.com',
    (Service.OCE, Region.AP_MELBOURNE_1): 'https://cp.oce.ap-melbourne-1.ocp.oraclecloud.com',
    (Service.OCE, Region.AP_MUMBAI_1): 'https://cp.oce.ap-mumbai-1.ocp.oraclecloud.com',
    (Service.OCE, Region.AP_OSAKA_1): 'https://cp.oce.ap-osaka-1.ocp.oraclecloud.com',
    (Service.OCE, Region.AP_SEOUL_1): 'https://cp.oce.ap-seoul-1.ocp.oraclecloud.com',
    (Service.OCE, Region.AP_SINGAPORE_1): 'https://cp.oce.ap-singapore-1.ocp.oraclecloud.com',
    (Service.OCE, Region.AP_SYDNEY_1): 'https://cp.oce.ap-sydney-1.ocp.oraclecloud.com',
    (Service.OCE, Region.AP_TOKYO_1): 'https://cp.oce.ap-tokyo-1.ocp.oraclecloud.com',
    (Service.OCE, Region.CA_MONTREAL_1): 'https://cp.oce.ca-montreal-1.ocp.oraclecloud.com',
    (Service.OCE, Region.CA_TORONTO_1): 'https://cp.oce.ca-toronto-1.ocp.oraclecloud.com',
    (Service.OCE, Region.EU_AMSTERDAM_1): 'https://cp.oce.eu-amsterdam-1.ocp.oraclecloud.com',
    (Service.OCE, Region.EU_FRANKFURT_1): 'https://cp.oce.eu-frankfurt-1.ocp.oraclecloud.com',
    (Service.OCE, Region.EU_JOVANOVAC_1): 'https://cp.oce.eu-jovanovac-1.ocp.oraclecloud20.com',
    (Service.OCE, Region.EU_MADRID_1): 'https://cp.oce.eu-madrid-1.ocp.oraclecloud.com',
    (Service.OCE, Region.EU_MADRID_3): 'https://cp.oce.eu-madrid-3.ocp.oraclecloud.com',
    (Service.OCE, Region.EU_MARSEILLE_1): 'https://cp.oce.eu-marseille-1.ocp.oraclecloud.com',
    (Service.OCE, Region.EU_MILAN_1): 'https://cp.oce.eu-milan-1.ocp.oraclecloud.com',
    (Service.OCE, Region.EU_STOCKHOLM_1): 'https://cp.oce.eu-stockholm-1.ocp.oraclecloud.com',
    (Service.OCE, Region.EU_TURIN_1): 'https://cp.oce.eu-turin-1.ocp.oraclecloud.com',
    (Service.OCE, Region.EU_ZURICH_1): 'https://cp.oce.eu-zurich-1.ocp.oraclecloud.com',
    (Service.OCE, Region.IL_JERUSALEM_1): 'https://cp.oce.il-jerusalem-1.ocp.oraclecloud.com',
    (Service.OCE, Region.ME_ABUDHABI_1): 'https://cp.oce.me-abudhabi-1.ocp.oraclecloud.com',
    (Service.OCE, Region.ME_DUBAI_1): 'https://cp.oce.me-dubai-1.ocp.oraclecloud.com',
    (Service.OCE, Region.ME_JEDDAH_1): 'https://cp.oce.me-jeddah-1.ocp.oraclecloud.com',
    (Service.OCE, Region.ME_RIYADH_1): 'https://cp.oce.me-riyadh-1.ocp.oraclecloud.com',
    (Service.OCE, Region.MX_MONTERREY_1): 'https://cp.oce.mx-monterrey-1.ocp.oraclecloud.com',
    (Service.OCE, Region.MX_QUERETARO_1): 'https://cp.oce.mx-queretaro-1.ocp.oraclecloud.com',
    (Service.OCE, Region.SA_BOGOTA_1): 'https://cp.oce.sa-bogota-1.ocp.oraclecloud.com',
    (Service.OCE, Region.SA_SANTIAGO_1): 'https://cp.oce.sa-santiago-1.ocp.oraclecloud.com',
    (Service.OCE, Region.SA_SAOPAULO_1): 'https://cp.oce.sa-saopaulo-1.ocp.oraclecloud.com',
    (Service.OCE, Region.SA_VINHEDO_1): 'https://cp.oce.sa-vinhedo-1.ocp.oraclecloud.com',
    (Service.OCE, Region.UK_CARDIFF_1): 'https://cp.oce.uk-cardiff-1.ocp.oraclecloud.com',
    (Service.OCE, Region.UK_LONDON_1): 'https://cp.oce.uk-london-1.ocp.oraclecloud.com',
    (Service.OCE, Region.US_ASHBURN_1): 'https://cp.oce.us-ashburn-1.ocp.oraclecloud.com',
    (Service.OCE, Region.US_PHOENIX_1): 'https://cp.oce.us-phoenix-1.ocp.oraclecloud.com',
    (Service.OCE, Region.US_SANJOSE_1): 'https://cp.oce.us-sanjose-1.ocp.oraclecloud.com',
    (
        Service.OCICACHE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://redis.af-johannesburg-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.AP_BATAM_1): 'https://redis.ap-batam-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.AP_CHUNCHEON_1): 'https://redis.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.AP_HYDERABAD_1): 'https://redis.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.AP_MELBOURNE_1): 'https://redis.ap-melbourne-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.AP_MUMBAI_1): 'https://redis.ap-mumbai-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.AP_OSAKA_1): 'https://redis.ap-osaka-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.AP_SEOUL_1): 'https://redis.ap-seoul-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.AP_SINGAPORE_1): 'https://redis.ap-singapore-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.AP_SINGAPORE_2): 'https://redis.ap-singapore-2.oci.oraclecloud.com',
    (Service.OCICACHE, Region.AP_SYDNEY_1): 'https://redis.ap-sydney-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.AP_TOKYO_1): 'https://redis.ap-tokyo-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.CA_MONTREAL_1): 'https://redis.ca-montreal-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.CA_TORONTO_1): 'https://redis.ca-toronto-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.EU_AMSTERDAM_1): 'https://redis.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.EU_FRANKFURT_1): 'https://redis.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.EU_JOVANOVAC_1): 'https://redis.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.OCICACHE, Region.EU_MADRID_1): 'https://redis.eu-madrid-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.EU_MADRID_3): 'https://redis.eu-madrid-3.oci.oraclecloud.com',
    (Service.OCICACHE, Region.EU_MARSEILLE_1): 'https://redis.eu-marseille-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.EU_MILAN_1): 'https://redis.eu-milan-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.EU_PARIS_1): 'https://redis.eu-paris-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.EU_STOCKHOLM_1): 'https://redis.eu-stockholm-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.EU_TURIN_1): 'https://redis.eu-turin-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.EU_ZURICH_1): 'https://redis.eu-zurich-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.IL_JERUSALEM_1): 'https://redis.il-jerusalem-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.ME_ABUDHABI_1): 'https://redis.me-abudhabi-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.ME_DUBAI_1): 'https://redis.me-dubai-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.ME_JEDDAH_1): 'https://redis.me-jeddah-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.ME_RIYADH_1): 'https://redis.me-riyadh-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.MX_MONTERREY_1): 'https://redis.mx-monterrey-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.MX_QUERETARO_1): 'https://redis.mx-queretaro-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.SA_SANTIAGO_1): 'https://redis.sa-santiago-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.SA_SAOPAULO_1): 'https://redis.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.SA_VALPARAISO_1): 'https://redis.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.SA_VINHEDO_1): 'https://redis.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.UK_CARDIFF_1): 'https://redis.uk-cardiff-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.UK_LONDON_1): 'https://redis.uk-london-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.US_ASHBURN_1): 'https://redis.us-ashburn-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.US_CHICAGO_1): 'https://redis.us-chicago-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.US_PHOENIX_1): 'https://redis.us-phoenix-1.oci.oraclecloud.com',
    (Service.OCICACHE, Region.US_SANJOSE_1): 'https://redis.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.AF_JOHANNESBURG_1,
    ): 'https://cloudmigration.af-johannesburg-1.oci.oraclecloud.com',
    (Service.OCM, Region.AP_BATAM_1): 'https://cloudmigration.ap-batam-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.AP_CHUNCHEON_1,
    ): 'https://cloudmigration.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.AP_HYDERABAD_1,
    ): 'https://cloudmigration.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.AP_MELBOURNE_1,
    ): 'https://cloudmigration.ap-melbourne-1.oci.oraclecloud.com',
    (Service.OCM, Region.AP_MUMBAI_1): 'https://cloudmigration.ap-mumbai-1.oci.oraclecloud.com',
    (Service.OCM, Region.AP_OSAKA_1): 'https://cloudmigration.ap-osaka-1.oci.oraclecloud.com',
    (Service.OCM, Region.AP_SEOUL_1): 'https://cloudmigration.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.AP_SINGAPORE_1,
    ): 'https://cloudmigration.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.AP_SINGAPORE_2,
    ): 'https://cloudmigration.ap-singapore-2.oci.oraclecloud.com',
    (Service.OCM, Region.AP_SYDNEY_1): 'https://cloudmigration.ap-sydney-1.oci.oraclecloud.com',
    (Service.OCM, Region.AP_TOKYO_1): 'https://cloudmigration.ap-tokyo-1.oci.oraclecloud.com',
    (Service.OCM, Region.CA_MONTREAL_1): 'https://cloudmigration.ca-montreal-1.oci.oraclecloud.com',
    (Service.OCM, Region.CA_TORONTO_1): 'https://cloudmigration.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.EU_AMSTERDAM_1,
    ): 'https://cloudmigration.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.EU_FRANKFURT_1,
    ): 'https://cloudmigration.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.OCM, Region.EU_MADRID_1): 'https://cloudmigration.eu-madrid-1.oci.oraclecloud.com',
    (Service.OCM, Region.EU_MADRID_3): 'https://cloudmigration.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.EU_MARSEILLE_1,
    ): 'https://cloudmigration.eu-marseille-1.oci.oraclecloud.com',
    (Service.OCM, Region.EU_MILAN_1): 'https://cloudmigration.eu-milan-1.oci.oraclecloud.com',
    (Service.OCM, Region.EU_PARIS_1): 'https://cloudmigration.eu-paris-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.EU_STOCKHOLM_1,
    ): 'https://cloudmigration.eu-stockholm-1.oci.oraclecloud.com',
    (Service.OCM, Region.EU_TURIN_1): 'https://cloudmigration.eu-turin-1.oci.oraclecloud.com',
    (Service.OCM, Region.EU_ZURICH_1): 'https://cloudmigration.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.IL_JERUSALEM_1,
    ): 'https://cloudmigration.il-jerusalem-1.oci.oraclecloud.com',
    (Service.OCM, Region.ME_ABUDHABI_1): 'https://cloudmigration.me-abudhabi-1.oci.oraclecloud.com',
    (Service.OCM, Region.ME_DUBAI_1): 'https://cloudmigration.me-dubai-1.oci.oraclecloud.com',
    (Service.OCM, Region.ME_JEDDAH_1): 'https://cloudmigration.me-jeddah-1.oci.oraclecloud.com',
    (Service.OCM, Region.ME_RIYADH_1): 'https://cloudmigration.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.MX_MONTERREY_1,
    ): 'https://cloudmigration.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.MX_QUERETARO_1,
    ): 'https://cloudmigration.mx-queretaro-1.oci.oraclecloud.com',
    (Service.OCM, Region.SA_BOGOTA_1): 'https://cloudmigration.sa-bogota-1.oci.oraclecloud.com',
    (Service.OCM, Region.SA_SANTIAGO_1): 'https://cloudmigration.sa-santiago-1.oci.oraclecloud.com',
    (Service.OCM, Region.SA_SAOPAULO_1): 'https://cloudmigration.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.OCM,
        Region.SA_VALPARAISO_1,
    ): 'https://cloudmigration.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.OCM, Region.SA_VINHEDO_1): 'https://cloudmigration.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.OCM, Region.UK_CARDIFF_1): 'https://cloudmigration.uk-cardiff-1.oci.oraclecloud.com',
    (Service.OCM, Region.UK_LONDON_1): 'https://cloudmigration.uk-london-1.oci.oraclecloud.com',
    (Service.OCM, Region.US_ASHBURN_1): 'https://cloudmigration.us-ashburn-1.oci.oraclecloud.com',
    (Service.OCM, Region.US_CHICAGO_1): 'https://cloudmigration.us-chicago-1.oci.oraclecloud.com',
    (Service.OCM, Region.US_PHOENIX_1): 'https://cloudmigration.us-phoenix-1.oci.oraclecloud.com',
    (Service.OCM, Region.US_SANJOSE_1): 'https://cloudmigration.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.OPA,
        Region.US_ASHBURN_1,
    ): 'https://downstream-cp.opaprod.process.us-ashburn-1.oci.oracleiaas.com',
    (
        Service.OPENSEARCH,
        Region.AF_JOHANNESBURG_1,
    ): 'https://opensearch.af-johannesburg-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.AP_BATAM_1): 'https://opensearch.ap-batam-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.AP_CHUNCHEON_1,
    ): 'https://opensearch.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.AP_HYDERABAD_1,
    ): 'https://opensearch.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.AP_MELBOURNE_1,
    ): 'https://opensearch.ap-melbourne-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.AP_MUMBAI_1): 'https://opensearch.ap-mumbai-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.AP_OSAKA_1): 'https://opensearch.ap-osaka-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.AP_SEOUL_1): 'https://opensearch.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.AP_SINGAPORE_1,
    ): 'https://opensearch.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.AP_SINGAPORE_2,
    ): 'https://opensearch.ap-singapore-2.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.AP_SYDNEY_1): 'https://opensearch.ap-sydney-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.AP_TOKYO_1): 'https://opensearch.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.CA_MONTREAL_1,
    ): 'https://opensearch.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.CA_TORONTO_1,
    ): 'https://opensearch.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.EU_AMSTERDAM_1,
    ): 'https://opensearch.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.EU_FRANKFURT_1,
    ): 'https://opensearch.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.EU_MADRID_1): 'https://opensearch.eu-madrid-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.EU_MADRID_3): 'https://opensearch.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.EU_MARSEILLE_1,
    ): 'https://opensearch.eu-marseille-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.EU_MILAN_1): 'https://opensearch.eu-milan-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.EU_PARIS_1): 'https://opensearch.eu-paris-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.EU_STOCKHOLM_1,
    ): 'https://opensearch.eu-stockholm-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.EU_TURIN_1): 'https://opensearch.eu-turin-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.EU_ZURICH_1): 'https://opensearch.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.IL_JERUSALEM_1,
    ): 'https://opensearch.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.ME_ABUDHABI_1,
    ): 'https://opensearch.me-abudhabi-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.ME_DUBAI_1): 'https://opensearch.me-dubai-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.ME_JEDDAH_1): 'https://opensearch.me-jeddah-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.ME_RIYADH_1): 'https://opensearch.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.MX_MONTERREY_1,
    ): 'https://opensearch.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.MX_QUERETARO_1,
    ): 'https://opensearch.mx-queretaro-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.SA_BOGOTA_1): 'https://opensearch.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.SA_SANTIAGO_1,
    ): 'https://opensearch.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.SA_SAOPAULO_1,
    ): 'https://opensearch.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.SA_VALPARAISO_1,
    ): 'https://opensearch.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.SA_VINHEDO_1,
    ): 'https://opensearch.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.UK_CARDIFF_1,
    ): 'https://opensearch.uk-cardiff-1.oci.oraclecloud.com',
    (Service.OPENSEARCH, Region.UK_LONDON_1): 'https://opensearch.uk-london-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.US_ASHBURN_1,
    ): 'https://opensearch.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.US_CHICAGO_1,
    ): 'https://opensearch.us-chicago-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.US_PHOENIX_1,
    ): 'https://opensearch.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.OPENSEARCH,
        Region.US_SANJOSE_1,
    ): 'https://opensearch.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://operationsinsights.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.AP_BATAM_1,
    ): 'https://operationsinsights.ap-batam-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.AP_CHUNCHEON_1,
    ): 'https://operationsinsights.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.AP_HYDERABAD_1,
    ): 'https://operationsinsights.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.AP_MELBOURNE_1,
    ): 'https://operationsinsights.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.AP_MUMBAI_1,
    ): 'https://operationsinsights.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.AP_OSAKA_1,
    ): 'https://operationsinsights.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.AP_SEOUL_1,
    ): 'https://operationsinsights.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.AP_SINGAPORE_1,
    ): 'https://operationsinsights.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.AP_SYDNEY_1,
    ): 'https://operationsinsights.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.AP_TOKYO_1,
    ): 'https://operationsinsights.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.CA_MONTREAL_1,
    ): 'https://operationsinsights.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.CA_TORONTO_1,
    ): 'https://operationsinsights.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.EU_AMSTERDAM_1,
    ): 'https://operationsinsights.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.EU_FRANKFURT_1,
    ): 'https://operationsinsights.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.EU_MADRID_1,
    ): 'https://operationsinsights.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.EU_MADRID_3,
    ): 'https://operationsinsights.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.EU_MARSEILLE_1,
    ): 'https://operationsinsights.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.EU_MILAN_1,
    ): 'https://operationsinsights.eu-milan-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.EU_PARIS_1,
    ): 'https://operationsinsights.eu-paris-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.EU_STOCKHOLM_1,
    ): 'https://operationsinsights.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.EU_TURIN_1,
    ): 'https://operationsinsights.eu-turin-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.EU_ZURICH_1,
    ): 'https://operationsinsights.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.IL_JERUSALEM_1,
    ): 'https://operationsinsights.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.ME_ABUDHABI_1,
    ): 'https://operationsinsights.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.ME_DUBAI_1,
    ): 'https://operationsinsights.me-dubai-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.ME_JEDDAH_1,
    ): 'https://operationsinsights.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.ME_RIYADH_1,
    ): 'https://operationsinsights.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.MX_MONTERREY_1,
    ): 'https://operationsinsights.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.MX_QUERETARO_1,
    ): 'https://operationsinsights.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.SA_BOGOTA_1,
    ): 'https://operationsinsights.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.SA_SANTIAGO_1,
    ): 'https://operationsinsights.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.SA_SAOPAULO_1,
    ): 'https://operationsinsights.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.SA_VALPARAISO_1,
    ): 'https://operationsinsights.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.SA_VINHEDO_1,
    ): 'https://operationsinsights.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.UK_CARDIFF_1,
    ): 'https://operationsinsights.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.UK_LONDON_1,
    ): 'https://operationsinsights.uk-london-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.US_ASHBURN_1,
    ): 'https://operationsinsights.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.US_CHICAGO_1,
    ): 'https://operationsinsights.us-chicago-1.oci.oraclecould.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.US_PHOENIX_1,
    ): 'https://operationsinsights.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.OPERATIONS_INSIGHTS,
        Region.US_SANJOSE_1,
    ): 'https://operationsinsights.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AF_JOHANNESBURG_1,
    ): 'https://operator-access-control.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AP_BATAM_1,
    ): 'https://operator-access-control.ap-batam-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AP_CHUNCHEON_1,
    ): 'https://operator-access-control.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AP_HYDERABAD_1,
    ): 'https://operator-access-control.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AP_MELBOURNE_1,
    ): 'https://operator-access-control.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AP_MUMBAI_1,
    ): 'https://operator-access-control.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AP_OSAKA_1,
    ): 'https://operator-access-control.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AP_SEOUL_1,
    ): 'https://operator-access-control.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AP_SINGAPORE_1,
    ): 'https://operator-access-control.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AP_SINGAPORE_2,
    ): 'https://operator-access-control.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AP_SYDNEY_1,
    ): 'https://operator-access-control.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.AP_TOKYO_1,
    ): 'https://operator-access-control.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.CA_MONTREAL_1,
    ): 'https://operator-access-control.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.CA_TORONTO_1,
    ): 'https://operator-access-control.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.EU_AMSTERDAM_1,
    ): 'https://operator-access-control.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.EU_FRANKFURT_1,
    ): 'https://operator-access-control.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.EU_JOVANOVAC_1,
    ): 'https://operator-access-control.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.EU_MADRID_1,
    ): 'https://operator-access-control.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.EU_MADRID_3,
    ): 'https://operator-access-control.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.EU_MARSEILLE_1,
    ): 'https://operator-access-control.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.EU_MILAN_1,
    ): 'https://operator-access-control.eu-milan-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.EU_PARIS_1,
    ): 'https://operator-access-control.eu-paris-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.EU_STOCKHOLM_1,
    ): 'https://operator-access-control.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.EU_TURIN_1,
    ): 'https://operator-access-control.eu-turin-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.EU_ZURICH_1,
    ): 'https://operator-access-control.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.IL_JERUSALEM_1,
    ): 'https://operator-access-control.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.ME_ABUDHABI_1,
    ): 'https://operator-access-control.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.ME_DUBAI_1,
    ): 'https://operator-access-control.me-dubai-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.ME_JEDDAH_1,
    ): 'https://operator-access-control.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.ME_RIYADH_1,
    ): 'https://operator-access-control.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.MX_MONTERREY_1,
    ): 'https://operator-access-control.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.MX_QUERETARO_1,
    ): 'https://operator-access-control.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.SA_BOGOTA_1,
    ): 'https://operator-access-control.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.SA_SANTIAGO_1,
    ): 'https://operator-access-control.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.SA_SAOPAULO_1,
    ): 'https://operator-access-control.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.SA_VALPARAISO_1,
    ): 'https://operator-access-control.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.SA_VINHEDO_1,
    ): 'https://operator-access-control.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.UK_CARDIFF_1,
    ): 'https://operator-access-control.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.UK_LONDON_1,
    ): 'https://operator-access-control.uk-london-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.US_ASHBURN_1,
    ): 'https://operator-access-control.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.US_PHOENIX_1,
    ): 'https://operator-access-control.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.OPERATORACCESSCONTROL,
        Region.US_SANJOSE_1,
    ): 'https://operator-access-control.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.AF_JOHANNESBURG_1,
    ): 'https://pactl.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.AP_BATAM_1,
    ): 'https://pactl.ap-batam-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.AP_CHUNCHEON_1,
    ): 'https://pactl.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.AP_HYDERABAD_1,
    ): 'https://pactl.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.AP_MELBOURNE_1,
    ): 'https://pactl.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.AP_MUMBAI_1,
    ): 'https://pactl.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.AP_OSAKA_1,
    ): 'https://pactl.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.AP_SEOUL_1,
    ): 'https://pactl.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.AP_SINGAPORE_1,
    ): 'https://pactl.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.AP_SYDNEY_1,
    ): 'https://pactl.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.AP_TOKYO_1,
    ): 'https://pactl.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.CA_MONTREAL_1,
    ): 'https://pactl.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.CA_TORONTO_1,
    ): 'https://pactl.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.EU_AMSTERDAM_1,
    ): 'https://pactl.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.EU_FRANKFURT_1,
    ): 'https://pactl.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.EU_JOVANOVAC_1,
    ): 'https://pactl.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.EU_MADRID_1,
    ): 'https://pactl.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.EU_MADRID_3,
    ): 'https://pactl.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.EU_MARSEILLE_1,
    ): 'https://pactl.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.EU_MILAN_1,
    ): 'https://pactl.eu-milan-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.EU_PARIS_1,
    ): 'https://pactl.eu-paris-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.EU_STOCKHOLM_1,
    ): 'https://pactl.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.EU_TURIN_1,
    ): 'https://pactl.eu-turin-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.EU_ZURICH_1,
    ): 'https://pactl.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.IL_JERUSALEM_1,
    ): 'https://pactl.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.ME_ABUDHABI_1,
    ): 'https://pactl.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.ME_DUBAI_1,
    ): 'https://pactl.me-dubai-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.ME_JEDDAH_1,
    ): 'https://pactl.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.MX_MONTERREY_1,
    ): 'https://pactl.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.MX_QUERETARO_1,
    ): 'https://pactl.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.SA_BOGOTA_1,
    ): 'https://pactl.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.SA_SANTIAGO_1,
    ): 'https://pactl.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.SA_SAOPAULO_1,
    ): 'https://pactl.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.SA_VALPARAISO_1,
    ): 'https://pactl.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.SA_VINHEDO_1,
    ): 'https://pactl.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.UK_CARDIFF_1,
    ): 'https://pactl.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.UK_LONDON_1,
    ): 'https://pactl.uk-london-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.US_ASHBURN_1,
    ): 'https://pactl.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.US_PHOENIX_1,
    ): 'https://pactl.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.ORACLE_API_ACCESS_CONTROL,
        Region.US_SANJOSE_1,
    ): 'https://pactl.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://organizations.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AP_BATAM_1,
    ): 'https://organizations.ap-batam-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AP_CHUNCHEON_1,
    ): 'https://organizations.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AP_HYDERABAD_1,
    ): 'https://organizations.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AP_MELBOURNE_1,
    ): 'https://organizations.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AP_MUMBAI_1,
    ): 'https://organizations.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AP_OSAKA_1,
    ): 'https://organizations.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AP_SEOUL_1,
    ): 'https://organizations.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AP_SINGAPORE_1,
    ): 'https://organizations.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AP_SINGAPORE_2,
    ): 'https://organizations.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AP_SYDNEY_1,
    ): 'https://organizations.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.AP_TOKYO_1,
    ): 'https://organizations.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.CA_MONTREAL_1,
    ): 'https://organizations.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.CA_TORONTO_1,
    ): 'https://organizations.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.EU_AMSTERDAM_1,
    ): 'https://organizations.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.EU_FRANKFURT_1,
    ): 'https://organizations.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.EU_JOVANOVAC_1,
    ): 'https://organizations.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.ORGANIZATIONS,
        Region.EU_MADRID_1,
    ): 'https://organizations.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.EU_MADRID_3,
    ): 'https://organizations.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.EU_MARSEILLE_1,
    ): 'https://organizations.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.EU_MILAN_1,
    ): 'https://organizations.eu-milan-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.EU_PARIS_1,
    ): 'https://organizations.eu-paris-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.EU_STOCKHOLM_1,
    ): 'https://organizations.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.EU_TURIN_1,
    ): 'https://organizations.eu-turin-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.EU_ZURICH_1,
    ): 'https://organizations.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.IL_JERUSALEM_1,
    ): 'https://organizations.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.ME_ABUDHABI_1,
    ): 'https://organizations.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.ME_DUBAI_1,
    ): 'https://organizations.me-dubai-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.ME_JEDDAH_1,
    ): 'https://organizations.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.ME_RIYADH_1,
    ): 'https://organizations.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.MX_MONTERREY_1,
    ): 'https://organizations.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.MX_QUERETARO_1,
    ): 'https://organizations.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.SA_BOGOTA_1,
    ): 'https://organizations.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.SA_SANTIAGO_1,
    ): 'https://organizations.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.SA_SAOPAULO_1,
    ): 'https://organizations.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.SA_VALPARAISO_1,
    ): 'https://organizations.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.SA_VINHEDO_1,
    ): 'https://organizations.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.UK_LONDON_1,
    ): 'https://organizations.uk-london-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.US_ASHBURN_1,
    ): 'https://organizations.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.US_CHICAGO_1,
    ): 'https://organizations.us-chicago-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.US_PHOENIX_1,
    ): 'https://organizations.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.ORGANIZATIONS,
        Region.US_SANJOSE_1,
    ): 'https://organizations.us-sanjose-1.oci.oraclecloud.com',
    (Service.OSMH, Region.AF_JOHANNESBURG_1): 'https://osmh.af-johannesburg-1.oci.oraclecloud.com',
    (Service.OSMH, Region.AP_BATAM_1): 'https://osmh.ap-batam-1.oci.oraclecloud.com',
    (Service.OSMH, Region.AP_CHUNCHEON_1): 'https://osmh.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.OSMH, Region.AP_HYDERABAD_1): 'https://osmh.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.OSMH, Region.AP_MELBOURNE_1): 'https://osmh.ap-melbourne-1.oci.oraclecloud.com',
    (Service.OSMH, Region.AP_MUMBAI_1): 'https://osmh.ap-mumbai-1.oci.oraclecloud.com',
    (Service.OSMH, Region.AP_OSAKA_1): 'https://osmh.ap-osaka-1.oci.oraclecloud.com',
    (Service.OSMH, Region.AP_SEOUL_1): 'https://osmh.ap-seoul-1.oci.oraclecloud.com',
    (Service.OSMH, Region.AP_SINGAPORE_1): 'https://osmh.ap-singapore-1.oci.oraclecloud.com',
    (Service.OSMH, Region.AP_SINGAPORE_2): 'https://osmh.ap-singapore-2.oci.oraclecloud.com',
    (Service.OSMH, Region.AP_SYDNEY_1): 'https://osmh.ap-sydney-1.oci.oraclecloud.com',
    (Service.OSMH, Region.AP_TOKYO_1): 'https://osmh.ap-tokyo-1.oci.oraclecloud.com',
    (Service.OSMH, Region.CA_MONTREAL_1): 'https://osmh.ca-montreal-1.oci.oraclecloud.com',
    (Service.OSMH, Region.CA_TORONTO_1): 'https://osmh.ca-toronto-1.oci.oraclecloud.com',
    (Service.OSMH, Region.EU_AMSTERDAM_1): 'https://osmh.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.OSMH, Region.EU_FRANKFURT_1): 'https://osmh.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.OSMH, Region.EU_JOVANOVAC_1): 'https://osmh.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.OSMH, Region.EU_MADRID_1): 'https://osmh.eu-madrid-1.oci.oraclecloud.com',
    (Service.OSMH, Region.EU_MADRID_3): 'https://osmh.eu-madrid-3.oci.oraclecloud.com',
    (Service.OSMH, Region.EU_MARSEILLE_1): 'https://osmh.eu-marseille-1.oci.oraclecloud.com',
    (Service.OSMH, Region.EU_MILAN_1): 'https://osmh.eu-milan-1.oci.oraclecloud.com',
    (Service.OSMH, Region.EU_PARIS_1): 'https://osmh.eu-paris-1.oci.oraclecloud.com',
    (Service.OSMH, Region.EU_STOCKHOLM_1): 'https://osmh.eu-stockholm-1.oci.oraclecloud.com',
    (Service.OSMH, Region.EU_TURIN_1): 'https://osmh.eu-turin-1.oci.oraclecloud.com',
    (Service.OSMH, Region.EU_ZURICH_1): 'https://osmh.eu-zurich-1.oci.oraclecloud.com',
    (Service.OSMH, Region.IL_JERUSALEM_1): 'https://osmh.il-jerusalem-1.oci.oraclecloud.com',
    (Service.OSMH, Region.ME_ABUDHABI_1): 'https://osmh.me-abudhabi-1.oci.oraclecloud.com',
    (Service.OSMH, Region.ME_DUBAI_1): 'https://osmh.me-dubai-1.oci.oraclecloud.com',
    (Service.OSMH, Region.ME_JEDDAH_1): 'https://osmh.me-jeddah-1.oci.oraclecloud.com',
    (Service.OSMH, Region.ME_RIYADH_1): 'https://osmh.me-riyadh-1.oci.oraclecloud.com',
    (Service.OSMH, Region.MX_MONTERREY_1): 'https://osmh.mx-monterrey-1.oci.oraclecloud.com',
    (Service.OSMH, Region.MX_QUERETARO_1): 'https://osmh.mx-queretaro-1.oci.oraclecloud.com',
    (Service.OSMH, Region.SA_BOGOTA_1): 'https://osmh.sa-bogota-1.oci.oraclecloud.com',
    (Service.OSMH, Region.SA_SANTIAGO_1): 'https://osmh.sa-santiago-1.oci.oraclecloud.com',
    (Service.OSMH, Region.SA_SAOPAULO_1): 'https://osmh.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.OSMH, Region.SA_VALPARAISO_1): 'https://osmh.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.OSMH, Region.SA_VINHEDO_1): 'https://osmh.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.OSMH, Region.UK_CARDIFF_1): 'https://osmh.uk-cardiff-1.oci.oraclecloud.com',
    (Service.OSMH, Region.UK_LONDON_1): 'https://osmh.uk-london-1.oci.oraclecloud.com',
    (Service.OSMH, Region.US_ASHBURN_1): 'https://osmh.us-ashburn-1.oci.oraclecloud.com',
    (Service.OSMH, Region.US_CHICAGO_1): 'https://osmh.us-chicago-1.oci.oraclecloud.com',
    (Service.OSMH, Region.US_PHOENIX_1): 'https://osmh.us-phoenix-1.oci.oraclecloud.com',
    (Service.OSMH, Region.US_SANJOSE_1): 'https://osmh.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.AF_JOHANNESBURG_1,
    ): 'https://postgresql.af-johannesburg-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.AP_BATAM_1): 'https://postgresql.ap-batam-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.AP_CHUNCHEON_1,
    ): 'https://postgresql.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.AP_HYDERABAD_1,
    ): 'https://postgresql.ap-hyderabad-1.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.AP_MELBOURNE_1,
    ): 'https://postgresql.ap-melbourne-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.AP_MUMBAI_1): 'https://postgresql.ap-mumbai-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.AP_OSAKA_1): 'https://postgresql.ap-osaka-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.AP_SEOUL_1): 'https://postgresql.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.AP_SINGAPORE_1,
    ): 'https://postgresql.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.AP_SINGAPORE_2,
    ): 'https://postgresql.ap-singapore-2.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.AP_SYDNEY_1): 'https://postgresql.ap-sydney-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.AP_TOKYO_1): 'https://postgresql.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.CA_MONTREAL_1,
    ): 'https://postgresql.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.CA_TORONTO_1,
    ): 'https://postgresql.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.EU_AMSTERDAM_1,
    ): 'https://postgresql.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.EU_FRANKFURT_1,
    ): 'https://postgresql.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.EU_JOVANOVAC_1,
    ): 'https://postgresql.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.POSTGRESQL, Region.EU_MADRID_1): 'https://postgresql.eu-madrid-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.EU_MADRID_3): 'https://postgresql.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.EU_MARSEILLE_1,
    ): 'https://postgresql.eu-marseille-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.EU_MILAN_1): 'https://postgresql.eu-milan-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.EU_PARIS_1): 'https://postgresql.eu-paris-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.EU_STOCKHOLM_1,
    ): 'https://postgresql.eu-stockholm-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.EU_TURIN_1): 'https://postgresql.eu-turin-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.EU_ZURICH_1): 'https://postgresql.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.IL_JERUSALEM_1,
    ): 'https://postgresql.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.ME_ABUDHABI_1,
    ): 'https://postgresql.me-abudhabi-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.ME_DUBAI_1): 'https://postgresql.me-dubai-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.ME_JEDDAH_1): 'https://postgresql.me-jeddah-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.ME_RIYADH_1): 'https://postgresql.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.MX_MONTERREY_1,
    ): 'https://postgresql.mx-monterrey-1.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.MX_QUERETARO_1,
    ): 'https://postgresql.mx-queretaro-1.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.SA_SANTIAGO_1,
    ): 'https://postgresql.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.SA_SAOPAULO_1,
    ): 'https://postgresql.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.SA_VINHEDO_1,
    ): 'https://postgresql.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.UK_CARDIFF_1,
    ): 'https://postgresql.uk-cardiff-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.UK_LONDON_1): 'https://postgresql.uk-london-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.US_ASHBURN_1,
    ): 'https://postgresql.us-ashburn-1.oci.oraclecloud.com',
    (Service.POSTGRESQL, Region.US_CHICAGO_1): 'https://postgresql.us-chicago-1.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.US_PHOENIX_1,
    ): 'https://postgresql.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.POSTGRESQL,
        Region.US_SANJOSE_1,
    ): 'https://postgresql.us-sanjose-1.oci.oraclecloud.com',
    (Service.PUBLISHER, Region.US_ASHBURN_1): 'https://publisher.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.QUEUE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://messaging.af-johannesburg-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.AP_BATAM_1): 'https://messaging.ap-batam-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.AP_CHUNCHEON_1): 'https://messaging.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.AP_HYDERABAD_1): 'https://messaging.ap-hyderabad-1.oraclecloud.com',
    (Service.QUEUE, Region.AP_MELBOURNE_1): 'https://messaging.ap-melbourne-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.AP_MUMBAI_1): 'https://messaging.ap-mumbai-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.AP_OSAKA_1): 'https://messaging.ap-osaka-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.AP_SEOUL_1): 'https://messaging.ap-seoul-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.AP_SINGAPORE_1): 'https://messaging.ap-singapore-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.AP_SINGAPORE_2): 'https://messaging.ap-singapore-2.oci.oraclecloud.com',
    (Service.QUEUE, Region.AP_SYDNEY_1): 'https://messaging.ap-sydney-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.AP_TOKYO_1): 'https://messaging.ap-tokyo-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.CA_MONTREAL_1): 'https://messaging.ca-montreal-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.CA_TORONTO_1): 'https://messaging.ca-toronto-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.EU_AMSTERDAM_1): 'https://messaging.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.EU_FRANKFURT_1): 'https://messaging.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.QUEUE,
        Region.EU_JOVANOVAC_1,
    ): 'https://messaging.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.QUEUE, Region.EU_MADRID_1): 'https://messaging.eu-madrid-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.EU_MADRID_3): 'https://messaging.eu-madrid-3.oci.oraclecloud.com',
    (Service.QUEUE, Region.EU_MARSEILLE_1): 'https://messaging.eu-marseille-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.EU_MILAN_1): 'https://messaging.eu-milan-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.EU_PARIS_1): 'https://messaging.eu-paris-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.EU_STOCKHOLM_1): 'https://messaging.eu-stockholm-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.EU_TURIN_1): 'https://messaging.eu-turin-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.EU_ZURICH_1): 'https://messaging.eu-zurich-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.IL_JERUSALEM_1): 'https://messaging.il-jerusalem-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.ME_ABUDHABI_1): 'https://messaging.me-abudhabi-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.ME_DUBAI_1): 'https://messaging.me-dubai-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.ME_JEDDAH_1): 'https://messaging.me-jeddah-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.ME_RIYADH_1): 'https://messaging.me-riyadh-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.MX_MONTERREY_1): 'https://messaging.mx-monterrey-1.oraclecloud.com',
    (Service.QUEUE, Region.MX_QUERETARO_1): 'https://messaging.mx-queretaro-1.oraclecloud.com',
    (Service.QUEUE, Region.SA_BOGOTA_1): 'https://messaging.sa-bogota-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.SA_SANTIAGO_1): 'https://messaging.sa-santiago-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.SA_SAOPAULO_1): 'https://messaging.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.QUEUE,
        Region.SA_VALPARAISO_1,
    ): 'https://messaging.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.SA_VINHEDO_1): 'https://messaging.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.UK_CARDIFF_1): 'https://messaging.uk-cardiff-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.UK_LONDON_1): 'https://messaging.uk-london-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.US_ASHBURN_1): 'https://messaging.us-ashburn-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.US_CHICAGO_1): 'https://messaging.us-chicago-1.oraclecloud.com',
    (Service.QUEUE, Region.US_PHOENIX_1): 'https://messaging.us-phoenix-1.oci.oraclecloud.com',
    (Service.QUEUE, Region.US_SANJOSE_1): 'https://messaging.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://recovery.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AP_BATAM_1,
    ): 'https://recovery.ap-batam-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AP_CHUNCHEON_1,
    ): 'https://recovery.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AP_HYDERABAD_1,
    ): 'https://recovery.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AP_MELBOURNE_1,
    ): 'https://recovery.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AP_MUMBAI_1,
    ): 'https://recovery.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AP_OSAKA_1,
    ): 'https://recovery.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AP_SEOUL_1,
    ): 'https://recovery.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AP_SINGAPORE_1,
    ): 'https://recovery.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AP_SINGAPORE_2,
    ): 'https://recovery.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AP_SYDNEY_1,
    ): 'https://recovery.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.AP_TOKYO_1,
    ): 'https://recovery.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.CA_MONTREAL_1,
    ): 'https://recovery.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.CA_TORONTO_1,
    ): 'https://recovery.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.EU_AMSTERDAM_1,
    ): 'https://recovery.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.EU_FRANKFURT_1,
    ): 'https://recovery.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.EU_JOVANOVAC_1,
    ): 'https://recovery.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.RECOVERY_SERVICE,
        Region.EU_MADRID_1,
    ): 'https://recovery.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.EU_MADRID_3,
    ): 'https://recovery.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.EU_MARSEILLE_1,
    ): 'https://recovery.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.EU_MILAN_1,
    ): 'https://recovery.eu-milan-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.EU_PARIS_1,
    ): 'https://recovery.eu-paris-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.EU_STOCKHOLM_1,
    ): 'https://recovery.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.EU_TURIN_1,
    ): 'https://recovery.eu-turin-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.EU_ZURICH_1,
    ): 'https://recovery.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.IL_JERUSALEM_1,
    ): 'https://recovery.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.ME_ABUDHABI_1,
    ): 'https://recovery.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.ME_DUBAI_1,
    ): 'https://recovery.me-dubai-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.ME_JEDDAH_1,
    ): 'https://recovery.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.ME_RIYADH_1,
    ): 'https://recovery.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.MX_MONTERREY_1,
    ): 'https://recovery.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.MX_QUERETARO_1,
    ): 'https://recovery.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.SA_BOGOTA_1,
    ): 'https://recovery.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.SA_SANTIAGO_1,
    ): 'https://recovery.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.SA_SAOPAULO_1,
    ): 'https://recovery.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.SA_VALPARAISO_1,
    ): 'https://recovery.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.SA_VINHEDO_1,
    ): 'https://recovery.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.UK_CARDIFF_1,
    ): 'https://recovery.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.UK_LONDON_1,
    ): 'https://recovery.uk-london-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.US_ASHBURN_1,
    ): 'https://recovery.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.US_PHOENIX_1,
    ): 'https://recovery.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.RECOVERY_SERVICE,
        Region.US_SANJOSE_1,
    ): 'https://recovery.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.AF_JOHANNESBURG_1,
    ): 'https://artifacts.af-johannesburg-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.AP_BATAM_1): 'https://artifacts.ap-batam-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.AP_CHUNCHEON_1,
    ): 'https://artifacts.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.AP_HYDERABAD_1,
    ): 'https://artifacts.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.AP_MELBOURNE_1,
    ): 'https://artifacts.ap-melbourne-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.AP_MUMBAI_1): 'https://artifacts.ap-mumbai-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.AP_OSAKA_1): 'https://artifacts.ap-osaka-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.AP_SEOUL_1): 'https://artifacts.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.AP_SINGAPORE_1,
    ): 'https://artifacts.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.AP_SINGAPORE_2,
    ): 'https://artifacts.ap-singapore-2.oci.oraclecloud.com',
    (Service.REGISTRY, Region.AP_SYDNEY_1): 'https://artifacts.ap-sydney-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.AP_TOKYO_1): 'https://artifacts.ap-tokyo-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.CA_MONTREAL_1): 'https://artifacts.ca-montreal-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.CA_TORONTO_1): 'https://artifacts.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.EU_AMSTERDAM_1,
    ): 'https://artifacts.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.EU_FRANKFURT_1,
    ): 'https://artifacts.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.EU_JOVANOVAC_1,
    ): 'https://artifacts.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.REGISTRY, Region.EU_MADRID_1): 'https://artifacts.eu-madrid-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.EU_MADRID_3): 'https://artifacts.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.EU_MARSEILLE_1,
    ): 'https://artifacts.eu-marseille-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.EU_MILAN_1): 'https://artifacts.eu-milan-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.EU_PARIS_1): 'https://artifacts.eu-paris-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.EU_STOCKHOLM_1,
    ): 'https://artifacts.eu-stockholm-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.EU_TURIN_1): 'https://artifacts.eu-turin-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.EU_ZURICH_1): 'https://artifacts.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.IL_JERUSALEM_1,
    ): 'https://artifacts.il-jerusalem-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.ME_ABUDHABI_1): 'https://artifacts.me-abudhabi-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.ME_DUBAI_1): 'https://artifacts.me-dubai-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.ME_JEDDAH_1): 'https://artifacts.me-jeddah-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.ME_RIYADH_1): 'https://artifacts.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.MX_MONTERREY_1,
    ): 'https://artifacts.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.MX_QUERETARO_1,
    ): 'https://artifacts.mx-queretaro-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.SA_BOGOTA_1): 'https://artifacts.sa-bogota-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.SA_SANTIAGO_1): 'https://artifacts.sa-santiago-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.SA_SAOPAULO_1): 'https://artifacts.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.REGISTRY,
        Region.SA_VALPARAISO_1,
    ): 'https://artifacts.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.SA_VINHEDO_1): 'https://artifacts.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.UK_CARDIFF_1): 'https://artifacts.uk-cardiff-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.UK_LONDON_1): 'https://artifacts.uk-london-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.US_ASHBURN_1): 'https://artifacts.us-ashburn-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.US_CHICAGO_1): 'https://artifacts.us-chicago-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.US_PHOENIX_1): 'https://artifacts.us-phoenix-1.oci.oraclecloud.com',
    (Service.REGISTRY, Region.US_SANJOSE_1): 'https://artifacts.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://resource-analytics.af-johannesburg-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AP_BATAM_1,
    ): 'https://resource-analytics.ap-batam-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AP_CHUNCHEON_1,
    ): 'https://resource-analytics.ap-chuncheon-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AP_HYDERABAD_1,
    ): 'https://resource-analytics.ap-hyderabad-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AP_MELBOURNE_1,
    ): 'https://resource-analytics.ap-melbourne-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AP_MUMBAI_1,
    ): 'https://resource-analytics.ap-mumbai-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AP_OSAKA_1,
    ): 'https://resource-analytics.ap-osaka-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AP_SEOUL_1,
    ): 'https://resource-analytics.ap-seoul-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AP_SINGAPORE_1,
    ): 'https://resource-analytics.ap-singapore-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AP_SINGAPORE_2,
    ): 'https://resource-analytics.ap-singapore-2.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AP_SYDNEY_1,
    ): 'https://resource-analytics.ap-sydney-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.AP_TOKYO_1,
    ): 'https://resource-analytics.ap-tokyo-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.CA_MONTREAL_1,
    ): 'https://resource-analytics.ca-montreal-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.CA_TORONTO_1,
    ): 'https://resource-analytics.ca-toronto-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.EU_AMSTERDAM_1,
    ): 'https://resource-analytics.eu-amsterdam-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.EU_FRANKFURT_1,
    ): 'https://resource-analytics.eu-frankfurt-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.EU_JOVANOVAC_1,
    ): 'https://resource-analytics.eu-jovanovac-1.ocp.oraclecloud20.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.EU_MADRID_1,
    ): 'https://resource-analytics.eu-madrid-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.EU_MADRID_3,
    ): 'https://resource-analytics.eu-madrid-3.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.EU_MARSEILLE_1,
    ): 'https://resource-analytics.eu-marseille-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.EU_MILAN_1,
    ): 'https://resource-analytics.eu-milan-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.EU_PARIS_1,
    ): 'https://resource-analytics.eu-paris-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.EU_STOCKHOLM_1,
    ): 'https://resource-analytics.eu-stockholm-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.EU_TURIN_1,
    ): 'https://resource-analytics.eu-turin-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.EU_ZURICH_1,
    ): 'https://resource-analytics.eu-zurich-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.ME_ABUDHABI_1,
    ): 'https://resource-analytics.me-abudhabi-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.ME_DUBAI_1,
    ): 'https://resource-analytics.me-dubai-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.ME_JEDDAH_1,
    ): 'https://resource-analytics.me-jeddah-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.MX_MONTERREY_1,
    ): 'https://resource-analytics.mx-monterrey-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.MX_QUERETARO_1,
    ): 'https://resource-analytics.mx-queretaro-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.SA_BOGOTA_1,
    ): 'https://resource-analytics.sa-bogota-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.SA_SANTIAGO_1,
    ): 'https://resource-analytics.sa-santiago-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.SA_SAOPAULO_1,
    ): 'https://resource-analytics.sa-saopaulo-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.SA_VALPARAISO_1,
    ): 'https://resource-analytics.sa-valparaiso-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.SA_VINDEHO_1,
    ): 'https://resource-analytics.sa-vindeho-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.UK_LONDON_1,
    ): 'https://resource-analytics.uk-london-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.US_ASHBURN_1,
    ): 'https://resource-analytics.us-ashburn-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.US_CHICAGO_1,
    ): 'https://resource-analytics.us-chicago-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.US_PHOENIX_1,
    ): 'https://resource-analytics.us-phoenix-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_ANALYTICS,
        Region.US_SANJOSE_1,
    ): 'https://resource-analytics.us-sanjose-1.ocp.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AF_JOHANNESBURG_1,
    ): 'https://cp.appmgmt.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AP_BATAM_1,
    ): 'https://cp.appmgmt.ap-batam-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AP_CHUNCHEON_1,
    ): 'https://cp.appmgmt.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AP_HYDERABAD_1,
    ): 'https://cp.appmgmt.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AP_MELBOURNE_1,
    ): 'https://cp.appmgmt.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AP_MUMBAI_1,
    ): 'https://cp.appmgmt.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AP_OSAKA_1,
    ): 'https://cp.appmgmt.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AP_SEOUL_1,
    ): 'https://cp.appmgmt.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AP_SINGAPORE_1,
    ): 'https://cp.appmgmt.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AP_SINGAPORE_2,
    ): 'https://cp.appmgmt.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AP_SYDNEY_1,
    ): 'https://cp.appmgmt.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.AP_TOKYO_1,
    ): 'https://cp.appmgmt.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.CA_MONTREAL_1,
    ): 'https://cp.appmgmt.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.CA_TORONTO_1,
    ): 'https://cp.appmgmt.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.EU_AMSTERDAM_1,
    ): 'https://cp.appmgmt.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.EU_FRANKFURT_1,
    ): 'https://cp.appmgmt.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.EU_JOVANOVAC_1,
    ): 'https://cp.appmgmt.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.EU_MADRID_1,
    ): 'https://cp.appmgmt.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.EU_MADRID_3,
    ): 'https://cp.appmgmt.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.EU_MARSEILLE_1,
    ): 'https://cp.appmgmt.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.EU_MILAN_1,
    ): 'https://cp.appmgmt.eu-milan-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.EU_PARIS_1,
    ): 'https://cp.appmgmt.eu-paris-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.EU_STOCKHOLM_1,
    ): 'https://cp.appmgmt.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.EU_TURIN_1,
    ): 'https://cp.appmgmt.eu-turin-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.EU_ZURICH_1,
    ): 'https://cp.appmgmt.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.IL_JERUSALEM_1,
    ): 'https://cp.appmgmt.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.ME_ABUDHABI_1,
    ): 'https://cp.appmgmt.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.ME_DUBAI_1,
    ): 'https://cp.appmgmt.me-dubai-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.ME_JEDDAH_1,
    ): 'https://cp.appmgmt.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.MX_MONTERREY_1,
    ): 'https://cp.appmgmt.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.MX_QUERETARO_1,
    ): 'https://cp.appmgmt.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.SA_BOGOTA_1,
    ): 'https://cp.appmgmt.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.SA_SANTIAGO_1,
    ): 'https://cp.appmgmt.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.SA_SAOPAULO_1,
    ): 'https://cp.appmgmt.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.SA_VALPARAISO_1,
    ): 'https://cp.appmgmt.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.SA_VINHEDO_1,
    ): 'https://cp.appmgmt.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.UK_CARDIFF_1,
    ): 'https://cp.appmgmt.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.UK_LONDON_1,
    ): 'https://cp.appmgmt.uk-london-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.US_ASHBURN_1,
    ): 'https://cp.appmgmt.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.US_PHOENIX_1,
    ): 'https://cp.appmgmt.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_DISCOVERY_MONITORING_CONTROL_API,
        Region.US_SANJOSE_1,
    ): 'https://cp.appmgmt.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AF_JOHANNESBURG_1,
    ): 'https://resource-scheduler.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AP_BATAM_1,
    ): 'https://resource-scheduler.ap-batam-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AP_CHUNCHEON_1,
    ): 'https://resource-scheduler.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AP_HYDERABAD_1,
    ): 'https://resource-scheduler.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AP_MELBOURNE_1,
    ): 'https://resource-scheduler.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AP_MUMBAI_1,
    ): 'https://resource-scheduler.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AP_OSAKA_1,
    ): 'https://resource-scheduler.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AP_SEOUL_1,
    ): 'https://resource-scheduler.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AP_SINGAPORE_1,
    ): 'https://resource-scheduler.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AP_SINGAPORE_2,
    ): 'https://resource-scheduler.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AP_SYDNEY_1,
    ): 'https://resource-scheduler.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.AP_TOKYO_1,
    ): 'https://resource-scheduler.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.CA_MONTREAL_1,
    ): 'https://resource-scheduler.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.CA_TORONTO_1,
    ): 'https://resource-scheduler.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.EU_AMSTERDAM_1,
    ): 'https://resource-scheduler.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.EU_FRANKFURT_1,
    ): 'https://resource-scheduler.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.EU_JOVANOVAC_1,
    ): 'https://resource-scheduler.eu-jovanovac-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.EU_MADRID_1,
    ): 'https://resource-scheduler.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.EU_MADRID_3,
    ): 'https://resource-scheduler.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.EU_MARSEILLE_1,
    ): 'https://resource-scheduler.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.EU_MILAN_1,
    ): 'https://resource-scheduler.eu-milan-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.EU_PARIS_1,
    ): 'https://resource-scheduler.eu-paris-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.EU_STOCKHOLM_1,
    ): 'https://resource-scheduler.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.EU_TURIN_1,
    ): 'https://resource-scheduler.eu-turin-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.EU_ZURICH_1,
    ): 'https://resource-scheduler.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.IL_JERUSALEM_1,
    ): 'https://resource-scheduler.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.ME_ABUDHABI_1,
    ): 'https://resource-scheduler.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.ME_DUBAI_1,
    ): 'https://resource-scheduler.me-dubai-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.ME_JEDDAH_1,
    ): 'https://resource-scheduler.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.ME_RIYADH_1,
    ): 'https://resource-scheduler.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.MX_MONTERREY_1,
    ): 'https://resource-scheduler.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.MX_QUERETARO_1,
    ): 'https://resource-scheduler.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.SA_BOGOTA_1,
    ): 'https://resource-scheduler.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.SA_SANTIAGO_1,
    ): 'https://resource-scheduler.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.SA_SAOPAULO_1,
    ): 'https://resource-scheduler.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.SA_VALPARAISO_1,
    ): 'https://resource-scheduler.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.SA_VINHEDO_1,
    ): 'https://resource-scheduler.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.UK_CARDIFF_1,
    ): 'https://resource-scheduler.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.UK_LONDON_1,
    ): 'https://resource-scheduler.uk-london-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.US_ASHBURN_1,
    ): 'https://resource-scheduler.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.US_CHICAGO_1,
    ): 'https://resource-scheduler.us-chicago-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.US_PHOENIX_1,
    ): 'https://resource-scheduler.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.RESOURCE_SCHEDULER,
        Region.US_SANJOSE_1,
    ): 'https://resource-scheduler.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AF_JOHANNESBURG_1,
    ): 'https://resourcemanager.af-johannesburg-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AP_BATAM_1,
    ): 'https://resourcemanager.ap-batam-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AP_CHUNCHEON_1,
    ): 'https://resourcemanager.ap-chuncheon-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AP_HYDERABAD_1,
    ): 'https://resourcemanager.ap-hyderabad-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AP_MELBOURNE_1,
    ): 'https://resourcemanager.ap-melbourne-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AP_MUMBAI_1,
    ): 'https://resourcemanager.ap-mumbai-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AP_OSAKA_1,
    ): 'https://resourcemanager.ap-osaka-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AP_SEOUL_1,
    ): 'https://resourcemanager.ap-seoul-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AP_SINGAPORE_1,
    ): 'https://resourcemanager.ap-singapore-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AP_SINGAPORE_2,
    ): 'https://resourcemanager.ap-singapore-2.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AP_SYDNEY_1,
    ): 'https://resourcemanager.ap-sydney-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.AP_TOKYO_1,
    ): 'https://resourcemanager.ap-tokyo-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.CA_MONTREAL_1,
    ): 'https://resourcemanager.ca-montreal-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.CA_TORONTO_1,
    ): 'https://resourcemanager.ca-toronto-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.EU_AMSTERDAM_1,
    ): 'https://resourcemanager.eu-amsterdam-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.EU_FRANKFURT_1,
    ): 'https://resourcemanager.eu-frankfurt-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.EU_JOVANOVAC_1,
    ): 'https://resourcemanager.eu-jovanovac-1.oraclecloud20.com',
    (
        Service.RESOURCEMANAGER,
        Region.EU_MADRID_1,
    ): 'https://resourcemanager.eu-madrid-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.EU_MADRID_3,
    ): 'https://resourcemanager.eu-madrid-3.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.EU_MARSEILLE_1,
    ): 'https://resourcemanager.eu-marseille-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.EU_MILAN_1,
    ): 'https://resourcemanager.eu-milan-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.EU_PARIS_1,
    ): 'https://resourcemanager.eu-paris-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.EU_STOCKHOLM_1,
    ): 'https://resourcemanager.eu-stockholm-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.EU_TURIN_1,
    ): 'https://resourcemanager.eu-turin-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.EU_ZURICH_1,
    ): 'https://resourcemanager.eu-zurich-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.IL_JERUSALEM_1,
    ): 'https://resourcemanager.il-jerusalem-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.ME_ABUDHABI_1,
    ): 'https://resourcemanager.me-abudhabi-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.ME_DUBAI_1,
    ): 'https://resourcemanager.me-dubai-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.ME_JEDDAH_1,
    ): 'https://resourcemanager.me-jeddah-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.ME_RIYADH_1,
    ): 'https://resourcemanager.me-riyadh-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.MX_MONTERREY_1,
    ): 'https://resourcemanager.mx-monterrey-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.MX_QUERETARO_1,
    ): 'https://resourcemanager.mx-queretaro-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.SA_BOGOTA_1,
    ): 'https://resourcemanager.sa-bogota-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.SA_SANTIAGO_1,
    ): 'https://resourcemanager.sa-santiago-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.SA_SAOPAULO_1,
    ): 'https://resourcemanager.sa-saopaulo-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.SA_VALPARAISO_1,
    ): 'https://resourcemanager.sa-valparaiso-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.SA_VINHEDO_1,
    ): 'https://resourcemanager.sa-vinhedo-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.UK_CARDIFF_1,
    ): 'https://resourcemanager.uk-cardiff-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.UK_LONDON_1,
    ): 'https://resourcemanager.uk-london-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.US_ASHBURN_1,
    ): 'https://resourcemanager.us-ashburn-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.US_CHICAGO_1,
    ): 'https://resourcemanager.us-chicago-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.US_PHOENIX_1,
    ): 'https://resourcemanager.us-phoenix-1.oraclecloud.com',
    (
        Service.RESOURCEMANAGER,
        Region.US_SANJOSE_1,
    ): 'https://resourcemanager.us-sanjose-1.oraclecloud.com',
    (Service.ROVER, Region.AP_SINGAPORE_1): 'https://rover.ap-singapore-1.oci.oraclecloud.com',
    (Service.ROVER, Region.EU_FRANKFURT_1): 'https://rover.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.ROVER, Region.UK_LONDON_1): 'https://rover.uk-london-1.oci.oraclecloud.com',
    (Service.ROVER, Region.US_ASHBURN_1): 'https://rover.us-ashburn-1.oci.oraclecloud.com',
    (Service.ROVER, Region.US_LUKE_1): 'https://rover.us-luke-1.oci.oraclegovcloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.af-johannesburg-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AP_BATAM_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ap-batam-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AP_CHUNCHEON_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ap-chuncheon-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AP_HYDERABAD_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ap-hyderabad-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AP_MELBOURNE_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ap-melbourne-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AP_MUMBAI_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ap-mumbai-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AP_OSAKA_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ap-osaka-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AP_SEOUL_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ap-seoul-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AP_SINGAPORE_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ap-singapore-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AP_SINGAPORE_2,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ap-singapore-2.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AP_SYDNEY_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ap-sydney-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.AP_TOKYO_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ap-tokyo-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.CA_MONTREAL_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ca-montreal-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.CA_TORONTO_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.ca-toronto-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.EU_AMSTERDAM_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.eu-amsterdam-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.EU_FRANKFURT_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.eu-frankfurt-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.EU_JOVANOVAC_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.eu-jovanovac-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.EU_MADRID_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.eu-madrid-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.EU_MADRID_3,
    ): 'https://<object_storage_namespace>.compat.objectstorage.eu-madrid-3.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.EU_MARSEILLE_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.eu-marseille-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.EU_MILAN_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.eu-milan-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.EU_PARIS_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.eu-paris-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.EU_STOCKHOLM_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.eu-stockholm-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.EU_TURIN_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.eu-turin-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.EU_ZURICH_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.eu-zurich-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.IL_JERUSALEM_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.il-jerusalem-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.ME_ABUDHABI_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.me-abudhabi-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.ME_DUBAI_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.me-dubai-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.ME_JEDDAH_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.me-jeddah-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.ME_RIYADH_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.me-riyadh-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.MX_MONTERREY_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.mx-monterrey-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.MX_QUERETARO_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.mx-queretaro-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.SA_BOGOTA_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.sa-bogota-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.SA_SANTIAGO_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.sa-santiago-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.SA_SAOPAULO_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.sa-saopaulo-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.SA_VALPARAISO_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.sa-valparaiso-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.SA_VINHEDO_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.sa-vinhedo-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.UK_CARDIFF_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.uk-cardiff-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.UK_LONDON_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.uk-london-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.US_ASHBURN_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.us-ashburn-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.US_CHICAGO_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.us-chicago-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.US_PHOENIX_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.us-phoenix-1.oraclecloud.com',
    (
        Service.S3OBJECTSTORAGE,
        Region.US_SANJOSE_1,
    ): 'https://<object_storage_namespace>.compat.objectstorage.us-sanjose-1.oraclecloud.com',
    (
        Service.SCANNING,
        Region.AF_JOHANNESBURG_1,
    ): 'https://vss-cp-api.af-johannesburg-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.AP_BATAM_1): 'https://vss-cp-api.ap-batam-1.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.AP_CHUNCHEON_1,
    ): 'https://vss-cp-api.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.AP_HYDERABAD_1,
    ): 'https://vss-cp-api.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.AP_MELBOURNE_1,
    ): 'https://vss-cp-api.ap-melbourne-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.AP_MUMBAI_1): 'https://vss-cp-api.ap-mumbai-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.AP_OSAKA_1): 'https://vss-cp-api.ap-osaka-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.AP_SEOUL_1): 'https://vss-cp-api.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.AP_SINGAPORE_1,
    ): 'https://vss-cp-api.ap-singapore-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.AP_SYDNEY_1): 'https://vss-cp-api.ap-sydney-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.AP_TOKYO_1): 'https://vss-cp-api.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.CA_MONTREAL_1,
    ): 'https://vss-cp-api.ca-montreal-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.CA_TORONTO_1): 'https://vss-cp-api.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.EU_AMSTERDAM_1,
    ): 'https://vss-cp-api.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.EU_FRANKFURT_1,
    ): 'https://vss-cp-api.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.EU_JOVANOVAC_1,
    ): 'https://vss-cp-api.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.SCANNING, Region.EU_MADRID_1): 'https://vss-cp-api.eu-madrid-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.EU_MADRID_3): 'https://vss-cp-api.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.EU_MARSEILLE_1,
    ): 'https://vss-cp-api.eu-marseille-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.EU_MILAN_1): 'https://vss-cp-api.eu-milan-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.EU_PARIS_1): 'https://vss-cp-api.eu-paris-1.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.EU_STOCKHOLM_1,
    ): 'https://vss-cp-api.eu-stockholm-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.EU_TURIN_1): 'https://vss-cp-api.eu-turin-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.EU_ZURICH_1): 'https://vss-cp-api.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.IL_JERUSALEM_1,
    ): 'https://vss-cp-api.il-jerusalem-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.ME_ABUDHABI_1): 'https://vss-cp-api.me-abudhabi-1.oraclecloud.com',
    (Service.SCANNING, Region.ME_DUBAI_1): 'https://vss-cp-api.me-dubai-1.oraclecloud.com',
    (Service.SCANNING, Region.ME_JEDDAH_1): 'https://vss-cp-api.me-jeddah-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.ME_RIYADH_1): 'https://vss-cp-api.me-riyadh-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.MX_MONTERREY_1): 'https://vss-cp-api.mx-monterrey-1.oraclecloud.com',
    (Service.SCANNING, Region.MX_QUERETARO_1): 'https://vss-cp-api.mx-queretaro-1.oraclecloud.com',
    (Service.SCANNING, Region.SA_SANTIAGO_1): 'https://vss-cp-api.sa-santiago-1.oraclecloud.com',
    (
        Service.SCANNING,
        Region.SA_SAOPAULO_1,
    ): 'https://vss-cp-api.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.SCANNING,
        Region.SA_VALPARAISO_1,
    ): 'https://vss-cp-api.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.SA_VINHEDO_1): 'https://vss-cp-api.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.UK_CARDIFF_1): 'https://vss-cp-api.uk-cardiff-1.oraclecloud.com',
    (Service.SCANNING, Region.UK_LONDON_1): 'https://vss-cp-api.uk-london-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.US_ASHBURN_1): 'https://vss-cp-api.us-ashburn-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.US_PHOENIX_1): 'https://vss-cp-api.us-phoenix-1.oci.oraclecloud.com',
    (Service.SCANNING, Region.US_SANJOSE_1): 'https://vss-cp-api.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.SEARCH,
        Region.AF_JOHANNESBURG_1,
    ): 'https://query.af-johannesburg-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.AP_BATAM_1): 'https://query.ap-batam-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.AP_CHUNCHEON_1): 'https://query.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.AP_HYDERABAD_1): 'https://query.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.AP_MELBOURNE_1): 'https://query.ap-melbourne-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.AP_MUMBAI_1): 'https://query.ap-mumbai-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.AP_OSAKA_1): 'https://query.ap-osaka-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.AP_SEOUL_1): 'https://query.ap-seoul-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.AP_SINGAPORE_1): 'https://query.ap-singapore-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.AP_SINGAPORE_2): 'https://query.ap-singapore-2.oci.oraclecloud.com',
    (Service.SEARCH, Region.AP_SYDNEY_1): 'https://query.ap-sydney-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.AP_TOKYO_1): 'https://query.ap-tokyo-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.CA_MONTREAL_1): 'https://query.ca-montreal-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.CA_TORONTO_1): 'https://query.ca-toronto-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.EU_AMSTERDAM_1): 'https://query.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.EU_FRANKFURT_1): 'https://query.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.EU_JOVANOVAC_1): 'https://query.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.SEARCH, Region.EU_MADRID_1): 'https://query.eu-madrid-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.EU_MADRID_3): 'https://query.eu-madrid-3.oci.oraclecloud.com',
    (Service.SEARCH, Region.EU_MARSEILLE_1): 'https://query.eu-marseille-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.EU_MILAN_1): 'https://query.eu-milan-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.EU_PARIS_1): 'https://query.eu-paris-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.EU_STOCKHOLM_1): 'https://query.eu-stockholm-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.EU_TURIN_1): 'https://query.eu-turin-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.EU_ZURICH_1): 'https://query.eu-zurich-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.IL_JERUSALEM_1): 'https://query.il-jerusalem-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.ME_ABUDHABI_1): 'https://query.me-abudhabi-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.ME_DUBAI_1): 'https://query.me-dubai-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.ME_JEDDAH_1): 'https://query.me-jeddah-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.MX_MONTERREY_1): 'https://query.mx-monterrey-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.MX_QUERETARO_1): 'https://query.mx-queretaro-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.SA_BOGOTA_1): 'https://query.sa-bogota-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.SA_SANTIAGO_1): 'https://query.sa-santiago-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.SA_SAOPAULO_1): 'https://query.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.SA_VALPARAISO_1): 'https://query.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.SA_VINHEDO_1): 'https://query.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.UK_CARDIFF_1): 'https://query.uk-cardiff-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.UK_LONDON_1): 'https://query.uk-london-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.US_ASHBURN_1): 'https://query.us-ashburn-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.US_CHICAGO_1): 'https://query.us-chicago-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.US_PHOENIX_1): 'https://query.us-phoenix-1.oci.oraclecloud.com',
    (Service.SEARCH, Region.US_SANJOSE_1): 'https://query.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.AF_JOHANNESBURG_1,
    ): 'https://vaults.af-johannesburg-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.AP_BATAM_1): 'https://vaults.ap-batam-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.AP_CHUNCHEON_1,
    ): 'https://vaults.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.AP_HYDERABAD_1,
    ): 'https://vaults.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.AP_MELBOURNE_1,
    ): 'https://vaults.ap-melbourne-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.AP_MUMBAI_1): 'https://vaults.ap-mumbai-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.AP_OSAKA_1): 'https://vaults.ap-osaka-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.AP_SEOUL_1): 'https://vaults.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.AP_SINGAPORE_1,
    ): 'https://vaults.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.AP_SINGAPORE_2,
    ): 'https://vaults.ap-singapore-2.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.AP_SYDNEY_1): 'https://vaults.ap-sydney-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.AP_TOKYO_1): 'https://vaults.ap-tokyo-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.CA_MONTREAL_1): 'https://vaults.ca-montreal-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.CA_TORONTO_1): 'https://vaults.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.EU_AMSTERDAM_1,
    ): 'https://vaults.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.EU_FRANKFURT_1,
    ): 'https://vaults.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.EU_JOVANOVAC_1,
    ): 'https://vaults.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.SECRETMGMT, Region.EU_MADRID_1): 'https://vaults.eu-madrid-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.EU_MADRID_3): 'https://vaults.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.EU_MARSEILLE_1,
    ): 'https://vaults.eu-marseille-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.EU_MILAN_1): 'https://vaults.eu-milan-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.EU_PARIS_1): 'https://vaults.eu-paris-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.EU_STOCKHOLM_1,
    ): 'https://vaults.eu-stockholm-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.EU_TURIN_1): 'https://vaults.eu-turin-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.EU_ZURICH_1): 'https://vaults.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.IL_JERUSALEM_1,
    ): 'https://vaults.il-jerusalem-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.ME_ABUDHABI_1): 'https://vaults.me-abudhabi-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.ME_DUBAI_1): 'https://vaults.me-dubai-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.ME_JEDDAH_1): 'https://vaults.me-jeddah-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.ME_RIYADH_1): 'https://vaults.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.MX_MONTERREY_1,
    ): 'https://vaults.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.MX_QUERETARO_1,
    ): 'https://vaults.mx-queretaro-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.SA_BOGOTA_1): 'https://vaults.sa-bogota-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.SA_SANTIAGO_1): 'https://vaults.sa-santiago-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.SA_SAOPAULO_1): 'https://vaults.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.SECRETMGMT,
        Region.SA_VALPARAISO_1,
    ): 'https://vaults.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.SA_VINHEDO_1): 'https://vaults.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.UK_CARDIFF_1): 'https://vaults.uk-cardiff-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.UK_LONDON_1): 'https://vaults.uk-london-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.US_ASHBURN_1): 'https://vaults.us-ashburn-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.US_CHICAGO_1): 'https://vaults.us-chicago-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.US_PHOENIX_1): 'https://vaults.us-phoenix-1.oci.oraclecloud.com',
    (Service.SECRETMGMT, Region.US_SANJOSE_1): 'https://vaults.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AF_JOHANNESBURG_1,
    ): 'https://secrets.vaults.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AP_BATAM_1,
    ): 'https://secrets.vaults.ap-batam-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AP_CHUNCHEON_1,
    ): 'https://secrets.vaults.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AP_HYDERABAD_1,
    ): 'https://secrets.vaults.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AP_MELBOURNE_1,
    ): 'https://secrets.vaults.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AP_MUMBAI_1,
    ): 'https://secrets.vaults.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AP_OSAKA_1,
    ): 'https://secrets.vaults.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AP_SEOUL_1,
    ): 'https://secrets.vaults.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AP_SINGAPORE_1,
    ): 'https://secrets.vaults.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AP_SINGAPORE_2,
    ): 'https://secrets.vaults.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AP_SYDNEY_1,
    ): 'https://secrets.vaults.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.AP_TOKYO_1,
    ): 'https://secrets.vaults.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.CA_MONTREAL_1,
    ): 'https://secrets.vaults.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.CA_TORONTO_1,
    ): 'https://secrets.vaults.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.EU_AMSTERDAM_1,
    ): 'https://secrets.vaults.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.EU_FRANKFURT_1,
    ): 'https://secrets.vaults.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.EU_JOVANOVAC_1,
    ): 'https://secrets.vaults.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.SECRETRETRIEVAL,
        Region.EU_MADRID_1,
    ): 'https://secrets.vaults.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.EU_MADRID_3,
    ): 'https://secrets.vaults.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.EU_MARSEILLE_1,
    ): 'https://secrets.vaults.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.EU_MILAN_1,
    ): 'https://secrets.vaults.eu-milan-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.EU_PARIS_1,
    ): 'https://secrets.vaults.eu-paris-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.EU_STOCKHOLM_1,
    ): 'https://secrets.vaults.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.EU_TURIN_1,
    ): 'https://secrets.vaults.eu-turin-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.EU_ZURICH_1,
    ): 'https://secrets.vaults.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.IL_JERUSALEM_1,
    ): 'https://secrets.vaults.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.ME_ABUDHABI_1,
    ): 'https://secrets.vaults.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.ME_DUBAI_1,
    ): 'https://secrets.vaults.me-dubai-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.ME_JEDDAH_1,
    ): 'https://secrets.vaults.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.ME_RIYADH_1,
    ): 'https://secrets.vaults.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.MX_MONTERREY_1,
    ): 'https://secrets.vaults.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.MX_QUERETARO_1,
    ): 'https://secrets.vaults.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.SA_BOGOTA_1,
    ): 'https://secrets.vaults.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.SA_SANTIAGO_1,
    ): 'https://secrets.vaults.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.SA_SAOPAULO_1,
    ): 'https://secrets.vaults.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.SA_VALPARAISO_1,
    ): 'https://secrets.vaults.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.SA_VINHEDO_1,
    ): 'https://secrets.vaults.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.UK_CARDIFF_1,
    ): 'https://secrets.vaults.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.UK_LONDON_1,
    ): 'https://secrets.vaults.uk-london-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.US_ASHBURN_1,
    ): 'https://secrets.vaults.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.US_CHICAGO_1,
    ): 'https://secrets.vaults.us-chicago-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.US_PHOENIX_1,
    ): 'https://secrets.vaults.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.SECRETRETRIEVAL,
        Region.US_SANJOSE_1,
    ): 'https://secrets.vaults.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://api.desktops.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.AP_BATAM_1,
    ): 'https://api.desktops.ap-batam-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.AP_CHUNCHEON_1,
    ): 'https://api.desktops.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.AP_HYDERABAD_1,
    ): 'https://api.desktops.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.AP_MELBOURNE_1,
    ): 'https://api.desktops.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.AP_MUMBAI_1,
    ): 'https://api.desktops.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.AP_OSAKA_1,
    ): 'https://api.desktops.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.AP_SEOUL_1,
    ): 'https://api.desktops.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.AP_SINGAPORE_1,
    ): 'https://api.desktops.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.AP_SYDNEY_1,
    ): 'https://api.desktops.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.AP_TOKYO_1,
    ): 'https://api.desktops.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.CA_MONTREAL_1,
    ): 'https://api.desktops.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.CA_TORONTO_1,
    ): 'https://api.desktops.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.EU_AMSTERDAM_1,
    ): 'https://api.desktops.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.EU_FRANKFURT_1,
    ): 'https://api.desktops.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.EU_MADRID_1,
    ): 'https://api.desktops.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.EU_MADRID_3,
    ): 'https://api.desktops.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.EU_MARSEILLE_1,
    ): 'https://api.desktops.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.EU_MILAN_1,
    ): 'https://api.desktops.eu-milan-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.EU_PARIS_1,
    ): 'https://api.desktops.eu-paris-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.EU_STOCKHOLM_1,
    ): 'https://api.desktops.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.EU_TURIN_1,
    ): 'https://api.desktops.eu-turin-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.EU_ZURICH_1,
    ): 'https://api.desktops.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.IL_JERUSALEM_1,
    ): 'https://api.desktops.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.ME_ABUDHABI_1,
    ): 'https://api.desktops.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.ME_DUBAI_1,
    ): 'https://api.desktops.me-dubai-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.ME_JEDDAH_1,
    ): 'https://api.desktops.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.MX_MONTERREY_1,
    ): 'https://api.desktops.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.MX_QUERETARO_1,
    ): 'https://api.desktops.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.SA_BOGOTA_1,
    ): 'https://api.desktops.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.SA_SANTIAGO_1,
    ): 'https://api.desktops.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.SA_SAOPAULO_1,
    ): 'https://api.desktops.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.SA_VALPARAISO_1,
    ): 'https://api.desktops.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.SA_VINHEDO_1,
    ): 'https://api.desktops.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.UK_CARDIFF_1,
    ): 'https://api.desktops.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.UK_LONDON_1,
    ): 'https://api.desktops.uk-london-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.US_ASHBURN_1,
    ): 'https://api.desktops.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.US_CHICAGO_1,
    ): 'https://api.desktops.us-chicago-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.US_PHOENIX_1,
    ): 'https://api.desktops.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.SECURE_DESKTOPS,
        Region.US_SANJOSE_1,
    ): 'https://api.desktops.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://security-attribute.af-johannesburg-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AP_BATAM_1,
    ): 'https://security-attribute.ap-batam-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AP_CHUNCHEON_1,
    ): 'https://security-attribute.ap-chuncheon-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AP_HYDERABAD_1,
    ): 'https://security-attribute.ap-hyderabad-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AP_MELBOURNE_1,
    ): 'https://security-attribute.ap-melbourne-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AP_MUMBAI_1,
    ): 'https://security-attribute.ap-mumbai-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AP_OSAKA_1,
    ): 'https://security-attribute.ap-osaka-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AP_SEOUL_1,
    ): 'https://security-attribute.ap-seoul-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AP_SINGAPORE_1,
    ): 'https://security-attribute.ap-singapore-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AP_SINGAPORE_2,
    ): 'https://security-attribute.ap-singapore-2.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AP_SYDNEY_1,
    ): 'https://security-attribute.ap-sydney-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.AP_TOKYO_1,
    ): 'https://security-attribute.ap-tokyo-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.CA_MONTREAL_1,
    ): 'https://security-attribute.ca-montreal-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.CA_TORONTO_1,
    ): 'https://security-attribute.ca-toronto-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.EU_AMSTERDAM_1,
    ): 'https://security-attribute.eu-amsterdam-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.EU_FRANKFURT_1,
    ): 'https://security-attribute.eu-frankfurt-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.EU_JOVANOVAC_1,
    ): 'https://security-attribute.eu-jovanovac-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.EU_MADRID_1,
    ): 'https://security-attribute.eu-madrid-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.EU_MADRID_3,
    ): 'https://security-attribute.eu-madrid-3.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.EU_MARSEILLE_1,
    ): 'https://security-attribute.eu-marseille-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.EU_MILAN_1,
    ): 'https://security-attribute.eu-milan-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.EU_PARIS_1,
    ): 'https://security-attribute.eu-paris-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.EU_STOCKHOLM_1,
    ): 'https://security-attribute.eu-stockholm-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.EU_TURIN_1,
    ): 'https://security-attribute.eu-turin-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.EU_ZURICH_1,
    ): 'https://security-attribute.eu-zurich-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.IL_JERUSALEM_1,
    ): 'https://security-attribute.il-jerusalem-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.ME_ABUDHABI_1,
    ): 'https://security-attribute.me-abudhabi-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.ME_DUBAI_1,
    ): 'https://security-attribute.me-dubai-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.ME_JEDDAH_1,
    ): 'https://security-attribute.me-jeddah-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.MX_MONTERREY_1,
    ): 'https://security-attribute.mx-monterrey-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.MX_QUERETARO_1,
    ): 'https://security-attribute.mx-queretaro-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.SA_BOGOTA_1,
    ): 'https://security-attribute.sa-bogota-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.SA_SANTIAGO_1,
    ): 'https://security-attribute.sa-santiago-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.SA_SAOPAULO_1,
    ): 'https://security-attribute.sa-saopaulo-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.SA_VALPARAISO_1,
    ): 'https://security-attribute.sa-valparaiso-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.SA_VINHEDO_1,
    ): 'https://security-attribute.sa-vinhedo-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.UK_CARDIFF_1,
    ): 'https://security-attribute.uk-cardiff-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.UK_LONDON_1,
    ): 'https://security-attribute.uk-london-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.US_ASHBURN_1,
    ): 'https://security-attribute.us-ashburn-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.US_CHICAGO_1,
    ): 'https://security-attribute.us-chicago-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.US_PHOENIX_1,
    ): 'https://security-attribute.us-phoenix-1.oci.oraclecloud.com/',
    (
        Service.SECURITY_ATTRIBUTE,
        Region.US_SANJOSE_1,
    ): 'https://security-attribute.us-sanjose-1.oci.oraclecloud.com/',
    (
        Service.SERVICE_CATALOG,
        Region.AF_JOHANNESBURG_1,
    ): 'https://service-catalog.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.AP_BATAM_1,
    ): 'https://service-catalog.ap-batam-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.AP_CHUNCHEON_1,
    ): 'https://service-catalog.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.AP_HYDERABAD_1,
    ): 'https://service-catalog.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.AP_MELBOURNE_1,
    ): 'https://service-catalog.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.AP_MUMBAI_1,
    ): 'https://service-catalog.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.AP_OSAKA_1,
    ): 'https://service-catalog.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.AP_SEOUL_1,
    ): 'https://service-catalog.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.AP_SINGAPORE_1,
    ): 'https://service-catalog.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.AP_SINGAPORE_2,
    ): 'https://service-catalog.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.AP_SYDNEY_1,
    ): 'https://service-catalog.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.AP_TOKYO_1,
    ): 'https://service-catalog.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.CA_MONTREAL_1,
    ): 'https://service-catalog.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.CA_TORONTO_1,
    ): 'https://service-catalog.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.EU_AMSTERDAM_1,
    ): 'https://service-catalog.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.EU_FRANKFURT_1,
    ): 'https://service-catalog.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.EU_MARSEILLE_1,
    ): 'https://service-catalog.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.EU_MILAN_1,
    ): 'https://service-catalog.eu-milan-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.EU_PARIS_1,
    ): 'https://service-catalog.eu-paris-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.EU_STOCKHOLM_1,
    ): 'https://service-catalog.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.EU_ZURICH_1,
    ): 'https://service-catalog.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.ME_ABUDHABI_1,
    ): 'https://service-catalog.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.ME_DUBAI_1,
    ): 'https://service-catalog.me-dubai-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.ME_JEDDAH_1,
    ): 'https://service-catalog.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.ME_RIYADH_1,
    ): 'https://service-catalog.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.MX_MONTERREY_1,
    ): 'https://service-catalog.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.MX_QUERETARO_1,
    ): 'https://service-catalog.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.SA_BOGOTA_1,
    ): 'https://service-catalog.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.SA_SANTIAGO_1,
    ): 'https://service-catalog.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.SA_SAOPAULO_1,
    ): 'https://service-catalog.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.SA_VALPARAISO_1,
    ): 'https://service-catalog.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.SA_VINHEDO_1,
    ): 'https://service-catalog.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.UK_CARDIFF_1,
    ): 'https://service-catalog.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.UK_LONDON_1,
    ): 'https://service-catalog.uk-london-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.US_ASHBURN_1,
    ): 'https://service-catalog.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.US_PHOENIX_1,
    ): 'https://service-catalog.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.SERVICE_CATALOG,
        Region.US_SANJOSE_1,
    ): 'https://service-catalog.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://service-connector-hub.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AP_BATAM_1,
    ): 'https://service-connector-hub.ap-batam-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AP_CHUNCHEON_1,
    ): 'https://service-connector-hub.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AP_HYDERABAD_1,
    ): 'https://service-connector-hub.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AP_MELBOURNE_1,
    ): 'https://service-connector-hub.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AP_MUMBAI_1,
    ): 'https://service-connector-hub.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AP_OSAKA_1,
    ): 'https://service-connector-hub.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AP_SEOUL_1,
    ): 'https://service-connector-hub.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AP_SINGAPORE_1,
    ): 'https://service-connector-hub.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AP_SINGAPORE_2,
    ): 'https://service-connector-hub.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AP_SYDNEY_1,
    ): 'https://service-connector-hub.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.AP_TOKYO_1,
    ): 'https://service-connector-hub.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.CA_MONTREAL_1,
    ): 'https://service-connector-hub.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.CA_TORONTO_1,
    ): 'https://service-connector-hub.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.EU_AMSTERDAM_1,
    ): 'https://service-connector-hub.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.EU_FRANKFURT_1,
    ): 'https://service-connector-hub.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.EU_JOVANOVAC_1,
    ): 'https://service-connector-hub.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.SERVICECONNECTORS,
        Region.EU_MADRID_1,
    ): 'https://service-connector-hub.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.EU_MADRID_3,
    ): 'https://service-connector-hub.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.EU_MARSEILLE_1,
    ): 'https://service-connector-hub.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.EU_MILAN_1,
    ): 'https://service-connector-hub.eu-milan-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.EU_PARIS_1,
    ): 'https://service-connector-hub.eu-paris-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.EU_STOCKHOLM_1,
    ): 'https://service-connector-hub.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.EU_TURIN_1,
    ): 'https://service-connector-hub.eu-turin-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.EU_ZURICH_1,
    ): 'https://service-connector-hub.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.IL_JERUSALEM_1,
    ): 'https://service-connector-hub.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.ME_ABUDHABI_1,
    ): 'https://service-connector-hub.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.ME_DUBAI_1,
    ): 'https://service-connector-hub.me-dubai-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.ME_JEDDAH_1,
    ): 'https://service-connector-hub.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.ME_RIYADH_1,
    ): 'https://service-connector-hub.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.MX_MONTERREY_1,
    ): 'https://service-connector-hub.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.MX_QUERETARO_1,
    ): 'https://service-connector-hub.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.SA_BOGOTA_1,
    ): 'https://service-connector-hub.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.SA_SANTIAGO_1,
    ): 'https://service-connector-hub.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.SA_SAOPAULO_1,
    ): 'https://service-connector-hub.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.SA_VALPARAISO_1,
    ): 'https://service-connector-hub.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.SA_VINHEDO_1,
    ): 'https://service-connector-hub.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.UK_CARDIFF_1,
    ): 'https://service-connector-hub.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.UK_LONDON_1,
    ): 'https://service-connector-hub.uk-london-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.US_ASHBURN_1,
    ): 'https://service-connector-hub.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.US_CHICAGO_1,
    ): 'https://service-connector-hub.us-chicago-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.US_PHOENIX_1,
    ): 'https://service-connector-hub.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.SERVICECONNECTORS,
        Region.US_SANJOSE_1,
    ): 'https://service-connector-hub.us-sanjose-1.oci.oraclecloud.com',
    (Service.SMP, Region.AP_CHUNCHEON_1): 'https://smproxy.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.SMP, Region.AP_HYDERABAD_1): 'https://smproxy.ap-hyderabad-1.oraclecloud.com',
    (Service.SMP, Region.AP_MELBOURNE_1): 'https://smproxy.ap-melbourne-1.oci.oraclecloud.com',
    (Service.SMP, Region.AP_MUMBAI_1): 'https://smproxy.ap-mumbai-1.oci.oraclecloud.com',
    (Service.SMP, Region.AP_OSAKA_1): 'https://smproxy.ap-osaka-1.oci.oraclecloud.com',
    (Service.SMP, Region.AP_SEOUL_1): 'https://smproxy.ap-seoul-1.oci.oraclecloud.com',
    (Service.SMP, Region.AP_SYDNEY_1): 'https://smproxy.ap-sydney-1.oci.oraclecloud.com',
    (Service.SMP, Region.AP_TOKYO_1): 'https://smproxy.ap-tokyo-1.oci.oraclecloud.com',
    (Service.SMP, Region.CA_MONTREAL_1): 'https://smproxy.ca-montreal-1.oci.oraclecloud.com',
    (Service.SMP, Region.CA_TORONTO_1): 'https://smproxy.ca-toronto-1.oci.oraclecloud.com',
    (Service.SMP, Region.EU_AMSTERDAM_1): 'https://smproxy.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.SMP, Region.EU_FRANKFURT_1): 'https://smproxy.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.SMP, Region.EU_ZURICH_1): 'https://smproxy.eu-zurich-1.oci.oraclecloud.com',
    (Service.SMP, Region.IL_JERUSALEM_1): 'https://smproxy.il-jerusalem-1.oci.oraclecloud.com',
    (Service.SMP, Region.ME_DUBAI_1): 'https://smproxy.me-dubai-1.oci.oraclecloud.com',
    (Service.SMP, Region.ME_JEDDAH_1): 'https://smproxy.me-jeddah-1.oci.oraclecloud.com',
    (Service.SMP, Region.SA_SANTIAGO_1): 'https://smproxy.sa-santiago-1.oci.oraclecloud.com',
    (Service.SMP, Region.SA_SAOPAULO_1): 'https://smproxy.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.SMP, Region.SA_VINHEDO_1): 'https://smproxy.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.SMP, Region.UK_CARDIFF_1): 'https://smproxy.uk-cardiff-1.oci.oraclecloud.com',
    (Service.SMP, Region.UK_LONDON_1): 'https://smproxy.uk-london-1.oci.oraclecloud.com',
    (Service.SMP, Region.US_ASHBURN_1): 'https://smproxy.us-ashburn-1.oci.oraclecloud.com',
    (Service.SMP, Region.US_PHOENIX_1): 'https://smproxy.us-phoenix-1.ocs.oraclecloud.com',
    (Service.SMP, Region.US_SANJOSE_1): 'https://smproxy.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.AF_JOHANNESBURG_1,
    ): 'https://speech.aiservice.af-johannesburg-1.oci.oraclecloud.com',
    (Service.SPEECH, Region.AP_BATAM_1): 'https://speech.aiservice.ap-batam-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.AP_CHUNCHEON_1,
    ): 'https://speech.aiservice.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.AP_HYDERABAD_1,
    ): 'https://speech.aiservice.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.AP_MELBOURNE_1,
    ): 'https://speech.aiservice.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.AP_MUMBAI_1,
    ): 'https://speech.aiservice.ap-mumbai-1.oci.oraclecloud.com',
    (Service.SPEECH, Region.AP_OSAKA_1): 'https://speech.aiservice.ap-osaka-1.oci.oraclecloud.com',
    (Service.SPEECH, Region.AP_SEOUL_1): 'https://speech.aiservice.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.AP_SINGAPORE_1,
    ): 'https://speech.aiservice.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.AP_SINGAPORE_2,
    ): 'https://speech.aiservice.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.AP_SYDNEY_1,
    ): 'https://speech.aiservice.ap-sydney-1.oci.oraclecloud.com',
    (Service.SPEECH, Region.AP_TOKYO_1): 'https://speech.aiservice.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.CA_MONTREAL_1,
    ): 'https://speech.aiservice.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.CA_TORONTO_1,
    ): 'https://speech.aiservice.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.EU_AMSTERDAM_1,
    ): 'https://speech.aiservice.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.EU_FRANKFURT_1,
    ): 'https://speech.aiservice.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.EU_MARSEILLE_1,
    ): 'https://speech.aiservice.eu-marseille-1.oci.oraclecloud.com',
    (Service.SPEECH, Region.EU_MILAN_1): 'https://speech.aiservice.eu-milan-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.EU_STOCKHOLM_1,
    ): 'https://speech.aiservice.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.EU_ZURICH_1,
    ): 'https://speech.aiservice.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.IL_JERUSALEM_1,
    ): 'https://speech.aiservice.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.ME_ABUDHABI_1,
    ): 'https://speech.aiservice.me-abudhabi-1.oci.oraclecloud.com',
    (Service.SPEECH, Region.ME_DUBAI_1): 'https://speech.aiservice.me-dubai-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.ME_JEDDAH_1,
    ): 'https://speech.aiservice.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.ME_RIYADH_1,
    ): 'https://speech.aiservice.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.MX_MONTERREY_1,
    ): 'https://speech.aiservice.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.MX_QUERETARO_1,
    ): 'https://speech.aiservice.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.SA_BOGOTA_1,
    ): 'https://speech.aiservice.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.SA_SANTIAGO_1,
    ): 'https://speech.aiservice.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.SA_SAOPAULO_1,
    ): 'https://speech.aiservice.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.SA_VALPARAISO_1,
    ): 'https://speech.aiservice.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.SA_VINHEDO_1,
    ): 'https://speech.aiservice.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.UK_CARDIFF_1,
    ): 'https://speech.aiservice.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.UK_LONDON_1,
    ): 'https://speech.aiservice.uk-london-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.US_ASHBURN_1,
    ): 'https://speech.aiservice.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.US_PHOENIX_1,
    ): 'https://speech.aiservice.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.SPEECH,
        Region.US_SANJOSE_1,
    ): 'https://speech.aiservice.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.AF_JOHANNESBURG_1,
    ): 'https://sqlwatch.af-johannesburg-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.AP_BATAM_1): 'https://sqlwatch.ap-batam-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.AP_CHUNCHEON_1,
    ): 'https://sqlwatch.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.AP_HYDERABAD_1,
    ): 'https://sqlwatch.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.AP_MELBOURNE_1,
    ): 'https://sqlwatch.ap-melbourne-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.AP_MUMBAI_1): 'https://sqlwatch.ap-mumbai-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.AP_OSAKA_1): 'https://sqlwatch.ap-osaka-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.AP_SEOUL_1): 'https://sqlwatch.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.AP_SINGAPORE_1,
    ): 'https://sqlwatch.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.AP_SINGAPORE_2,
    ): 'https://sqlwatch.ap-singapore-2.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.AP_SYDNEY_1): 'https://sqlwatch.ap-sydney-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.AP_TOKYO_1): 'https://sqlwatch.ap-tokyo-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.CA_MONTREAL_1): 'https://sqlwatch.ca-montreal-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.CA_TORONTO_1): 'https://sqlwatch.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.EU_AMSTERDAM_1,
    ): 'https://sqlwatch.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.EU_FRANKFURT_1,
    ): 'https://sqlwatch.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.EU_MADRID_1): 'https://sqlwatch.eu-madrid-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.EU_MADRID_3): 'https://sqlwatch.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.EU_MARSEILLE_1,
    ): 'https://sqlwatch.eu-marseille-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.EU_MILAN_1): 'https://sqlwatch.eu-milan-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.EU_PARIS_1): 'https://sqlwatch.eu-paris-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.EU_STOCKHOLM_1,
    ): 'https://sqlwatch.eu-stockholm-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.EU_TURIN_1): 'https://sqlwatch.eu-turin-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.EU_ZURICH_1): 'https://sqlwatch.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.IL_JERUSALEM_1,
    ): 'https://sqlwatch.il-jerusalem-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.ME_ABUDHABI_1): 'https://sqlwatch.me-abudhabi-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.ME_DUBAI_1): 'https://sqlwatch.me-dubai-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.ME_JEDDAH_1): 'https://sqlwatch.me-jeddah-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.ME_RIYADH_1): 'https://sqlwatch.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.MX_MONTERREY_1,
    ): 'https://sqlwatch.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.MX_QUERETARO_1,
    ): 'https://sqlwatch.mx-queretaro-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.SA_BOGOTA_1): 'https://sqlwatch.sa-bogota-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.SA_SANTIAGO_1): 'https://sqlwatch.sa-santiago-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.SA_SAOPAULO_1): 'https://sqlwatch.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.SQLWATCH,
        Region.SA_VALPARAISO_1,
    ): 'https://sqlwatch.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.SA_VINHEDO_1): 'https://sqlwatch.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.UK_CARDIFF_1): 'https://sqlwatch.uk-cardiff-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.UK_LONDON_1): 'https://sqlwatch.uk-london-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.US_ASHBURN_1): 'https://sqlwatch.us-ashburn-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.US_CHICAGO_1): 'https://sqlwatch.us-chicago-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.US_PHOENIX_1): 'https://sqlwatch.us-phoenix-1.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.US_SALTLAKE_2): 'https://sqlwatch.us-saltlake-2.oci.oraclecloud.com',
    (Service.SQLWATCH, Region.US_SANJOSE_1): 'https://sqlwatch.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AF_JOHANNESBURG_1,
    ): 'https://stack-monitoring.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AP_BATAM_1,
    ): 'https://stack-monitoring.ap-batam-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AP_CHUNCHEON_1,
    ): 'https://stack-monitoring.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AP_HYDERABAD_1,
    ): 'https://stack-monitoring.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AP_MELBOURNE_1,
    ): 'https://stack-monitoring.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AP_MUMBAI_1,
    ): 'https://stack-monitoring.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AP_OSAKA_1,
    ): 'https://stack-monitoring.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AP_SEOUL_1,
    ): 'https://stack-monitoring.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AP_SINGAPORE_1,
    ): 'https://stack-monitoring.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AP_SINGAPORE_2,
    ): 'https://stack-monitoring.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AP_SYDNEY_1,
    ): 'https://stack-monitoring.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.AP_TOKYO_1,
    ): 'https://stack-monitoring.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.CA_MONTREAL_1,
    ): 'https://stack-monitoring.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.CA_TORONTO_1,
    ): 'https://stack-monitoring.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.EU_AMSTERDAM_1,
    ): 'https://stack-monitoring.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.EU_FRANKFURT_1,
    ): 'https://stack-monitoring.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.EU_MADRID_1,
    ): 'https://stack-monitoring.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.EU_MADRID_3,
    ): 'https://stack-monitoring.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.EU_MARSEILLE_1,
    ): 'https://stack-monitoring.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.EU_MILAN_1,
    ): 'https://stack-monitoring.eu-milan-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.EU_PARIS_1,
    ): 'https://stack-monitoring.eu-paris-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.EU_STOCKHOLM_1,
    ): 'https://stack-monitoring.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.EU_TURIN_1,
    ): 'https://stack-monitoring.eu-turin-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.EU_ZURICH_1,
    ): 'https://stack-monitoring.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.IL_JERUSALEM_1,
    ): 'https://stack-monitoring.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.ME_ABUDHABI_1,
    ): 'https://stack-monitoring.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.ME_DUBAI_1,
    ): 'https://stack-monitoring.me-dubai-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.ME_JEDDAH_1,
    ): 'https://stack-monitoring.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.ME_RIYADH_1,
    ): 'https://stack-monitoring.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.MX_MONTERREY_1,
    ): 'https://stack-monitoring.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.MX_QUERETARO_1,
    ): 'https://stack-monitoring.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.SA_BOGOTA_1,
    ): 'https://stack-monitoring.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.SA_SANTIAGO_1,
    ): 'https://stack-monitoring.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.SA_SAOPAULO_1,
    ): 'https://stack-monitoring.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.SA_VINHEDO_1,
    ): 'https://stack-monitoring.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.UK_CARDIFF_1,
    ): 'https://stack-monitoring.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.UK_LONDON_1,
    ): 'https://stack-monitoring.uk-london-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.US_ASHBURN_1,
    ): 'https://stack-monitoring.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.US_PHOENIX_1,
    ): 'https://stack-monitoring.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.STACK_MONITORING,
        Region.US_SANJOSE_1,
    ): 'https://stack-monitoring.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.AF_JOHANNESBURG_1,
    ): 'https://streaming.af-johannesburg-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.AP_BATAM_1): 'https://streaming.ap-batam-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.AP_CHUNCHEON_1,
    ): 'https://streaming.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.AP_HYDERABAD_1,
    ): 'https://streaming.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.AP_MELBOURNE_1,
    ): 'https://streaming.ap-melbourne-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.AP_MUMBAI_1): 'https://streaming.ap-mumbai-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.AP_OSAKA_1): 'https://streaming.ap-osaka-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.AP_SEOUL_1): 'https://streaming.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.AP_SINGAPORE_1,
    ): 'https://streaming.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.AP_SINGAPORE_2,
    ): 'https://streaming.ap-singapore-2.oci.oraclecloud.com',
    (Service.STREAMING, Region.AP_SYDNEY_1): 'https://streaming.ap-sydney-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.AP_TOKYO_1): 'https://streaming.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.CA_MONTREAL_1,
    ): 'https://streaming.ca-montreal-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.CA_TORONTO_1): 'https://streaming.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.EU_AMSTERDAM_1,
    ): 'https://streaming.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.EU_FRANKFURT_1,
    ): 'https://streaming.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.EU_JOVANOVAC_1,
    ): 'https://streaming.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.STREAMING, Region.EU_MADRID_1): 'https://streaming.eu-madrid-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.EU_MADRID_3): 'https://streaming.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.EU_MARSEILLE_1,
    ): 'https://streaming.eu-marseille-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.EU_MILAN_1): 'https://streaming.eu-milan-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.EU_PARIS_1): 'https://streaming.eu-paris-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.EU_STOCKHOLM_1,
    ): 'https://streaming.eu-stockholm-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.EU_TURIN_1): 'https://streaming.eu-turin-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.EU_ZURICH_1): 'https://streaming.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.IL_JERUSALEM_1,
    ): 'https://streaming.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.ME_ABUDHABI_1,
    ): 'https://streaming.me-abudhabi-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.ME_DUBAI_1): 'https://streaming.me-dubai-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.ME_JEDDAH_1): 'https://streaming.me-jeddah-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.ME_RIYADH_1): 'https://streaming.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.MX_MONTERREY_1,
    ): 'https://streaming.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.MX_QUERETARO_1,
    ): 'https://streaming.mx-queretaro-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.SA_BOGOTA_1): 'https://streaming.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.SA_SANTIAGO_1,
    ): 'https://streaming.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.SA_SAOPAULO_1,
    ): 'https://streaming.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.STREAMING,
        Region.SA_VALPARAISO_1,
    ): 'https://streaming.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.SA_VINHEDO_1): 'https://streaming.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.UK_CARDIFF_1): 'https://streaming.uk-cardiff-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.UK_LONDON_1): 'https://streaming.uk-london-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.US_ASHBURN_1): 'https://streaming.us-ashburn-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.US_CHICAGO_1): 'https://streaming.us-chicago-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.US_PHOENIX_1): 'https://streaming.us-phoenix-1.oci.oraclecloud.com',
    (Service.STREAMING, Region.US_SANJOSE_1): 'https://streaming.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AF_JOHANNESBURG_1,
    ): 'https://api-threatintel.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AP_BATAM_1,
    ): 'https://api-threatintel.ap-batam-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AP_CHUNCHEON_1,
    ): 'https://api-threatintel.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AP_HYDERABAD_1,
    ): 'https://api-threatintel.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AP_MELBOURNE_1,
    ): 'https://api-threatintel.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AP_MUMBAI_1,
    ): 'https://api-threatintel.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AP_OSAKA_1,
    ): 'https://api-threatintel.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AP_SEOUL_1,
    ): 'https://api-threatintel.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AP_SINGAPORE_1,
    ): 'https://api-threatintel.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AP_SINGAPORE_2,
    ): 'https://api-threatintel.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AP_SYDNEY_1,
    ): 'https://api-threatintel.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.AP_TOKYO_1,
    ): 'https://api-threatintel.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.CA_MONTREAL_1,
    ): 'https://api-threatintel.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.CA_TORONTO_1,
    ): 'https://api-threatintel.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.EU_AMSTERDAM_1,
    ): 'https://api-threatintel.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.EU_FRANKFURT_1,
    ): 'https://api-threatintel.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.EU_MARSEILLE_1,
    ): 'https://api-threatintel.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.EU_MILAN_1,
    ): 'https://api-threatintel.eu-milan-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.EU_PARIS_1,
    ): 'https://api-threatintel.eu-paris-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.EU_STOCKHOLM_1,
    ): 'https://api-threatintel.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.EU_ZURICH_1,
    ): 'https://api-threatintel.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.IL_JERUSALEM_1,
    ): 'https://api-threatintel.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.ME_ABUDHABI_1,
    ): 'https://api-threatintel.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.ME_DUBAI_1,
    ): 'https://api-threatintel.me-dubai-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.ME_JEDDAH_1,
    ): 'https://api-threatintel.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.ME_RIYADH_1,
    ): 'https://api-threatintel.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.MX_MONTERREY_1,
    ): 'https://api-threatintel.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.MX_QUERETARO_1,
    ): 'https://api-threatintel.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.SA_BOGOTA_1,
    ): 'https://api-threatintel.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.SA_SANTIAGO_1,
    ): 'https://api-threatintel.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.SA_SAOPAULO_1,
    ): 'https://api-threatintel.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.SA_VALPARAISO_1,
    ): 'https://api-threatintel.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.SA_VINHEDO_1,
    ): 'https://api-threatintel.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.UK_CARDIFF_1,
    ): 'https://api-threatintel.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.UK_LONDON_1,
    ): 'https://api-threatintel.uk-london-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.US_ASHBURN_1,
    ): 'https://api-threatintel.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.US_PHOENIX_1,
    ): 'https://api-threatintel.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.THREAT_INTEL,
        Region.US_SANJOSE_1,
    ): 'https://api-threatintel.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.USAGE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://usageapi.af-johannesburg-1.oci.oraclecloud.com',
    (Service.USAGE, Region.AP_BATAM_1): 'https://usageapi.ap-batam-1.oci.oraclecloud.com',
    (Service.USAGE, Region.AP_CHUNCHEON_1): 'https://usageapi.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.USAGE, Region.AP_HYDERABAD_1): 'https://usageapi.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.USAGE, Region.AP_MELBOURNE_1): 'https://usageapi.ap-melbourne-1.oci.oraclecloud.com',
    (Service.USAGE, Region.AP_MUMBAI_1): 'https://usageapi.ap-mumbai-1.oci.oraclecloud.com',
    (Service.USAGE, Region.AP_OSAKA_1): 'https://usageapi.ap-osaka-1.oci.oraclecloud.com',
    (Service.USAGE, Region.AP_SEOUL_1): 'https://usageapi.ap-seoul-1.oci.oraclecloud.com',
    (Service.USAGE, Region.AP_SINGAPORE_1): 'https://usageapi.ap-singapore-1.oci.oraclecloud.com',
    (Service.USAGE, Region.AP_SINGAPORE_2): 'https://usageapi.ap-singapore-2.oci.oraclecloud.com',
    (Service.USAGE, Region.AP_SYDNEY_1): 'https://usageapi.ap-sydney-1.oci.oraclecloud.com',
    (Service.USAGE, Region.AP_TOKYO_1): 'https://usageapi.ap-tokyo-1.oci.oraclecloud.com',
    (Service.USAGE, Region.CA_MONTREAL_1): 'https://usageapi.ca-montreal-1.oci.oraclecloud.com',
    (Service.USAGE, Region.CA_TORONTO_1): 'https://usageapi.ca-toronto-1.oci.oraclecloud.com',
    (Service.USAGE, Region.EU_AMSTERDAM_1): 'https://usageapi.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.USAGE, Region.EU_FRANKFURT_1): 'https://usageapi.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.USAGE, Region.EU_JOVANOVAC_1): 'https://usageapi.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.USAGE, Region.EU_MADRID_1): 'https://usageapi.eu-madrid-1.oci.oraclecloud.com',
    (Service.USAGE, Region.EU_MADRID_3): 'https://usageapi.eu-madrid-3.oci.oraclecloud.com',
    (Service.USAGE, Region.EU_MARSEILLE_1): 'https://usageapi.eu-marseille-1.oci.oraclecloud.com',
    (Service.USAGE, Region.EU_MILAN_1): 'https://usageapi.eu-milan-1.oci.oraclecloud.com',
    (Service.USAGE, Region.EU_PARIS_1): 'https://usageapi.eu-paris-1.oci.oraclecloud.com',
    (Service.USAGE, Region.EU_STOCKHOLM_1): 'https://usageapi.eu-stockholm-1.oci.oraclecloud.com',
    (Service.USAGE, Region.EU_TURIN_1): 'https://usageapi.eu-turin-1.oci.oraclecloud.com',
    (Service.USAGE, Region.EU_ZURICH_1): 'https://usageapi.eu-zurich-1.oci.oraclecloud.com',
    (Service.USAGE, Region.IL_JERUSALEM_1): 'https://usageapi.il-jerusalem-1.oci.oraclecloud.com',
    (Service.USAGE, Region.ME_ABUDHABI_1): 'https://usageapi.me-abudhabi-1.oci.oraclecloud.com',
    (Service.USAGE, Region.ME_DUBAI_1): 'https://usageapi.me-dubai-1.oci.oraclecloud.com',
    (Service.USAGE, Region.ME_JEDDAH_1): 'https://usageapi.me-jeddah-1.oci.oraclecloud.com',
    (Service.USAGE, Region.ME_RIYADH_1): 'https://usageapi.me-riyadh-1.oci.oraclecloud.com',
    (Service.USAGE, Region.MX_MONTERREY_1): 'https://usageapi.mx-monterrey-1.oci.oraclecloud.com',
    (Service.USAGE, Region.MX_QUERETARO_1): 'https://usageapi.mx-queretaro-1.oci.oraclecloud.com',
    (Service.USAGE, Region.SA_BOGOTA_1): 'https://usageapi.sa-bogota-1.oci.oraclecloud.com',
    (Service.USAGE, Region.SA_SANTIAGO_1): 'https://usageapi.sa-santiago-1.oci.oraclecloud.com',
    (Service.USAGE, Region.SA_SAOPAULO_1): 'https://usageapi.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.USAGE, Region.SA_VALPARAISO_1): 'https://usageapi.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.USAGE, Region.SA_VINHEDO_1): 'https://usageapi.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.USAGE, Region.UK_CARDIFF_1): 'https://usageapi.uk-cardiff-1.oci.oraclecloud.com',
    (Service.USAGE, Region.UK_LONDON_1): 'https://usageapi.uk-london-1.oci.oraclecloud.com',
    (Service.USAGE, Region.US_ASHBURN_1): 'https://usageapi.us-ashburn-1.oci.oraclecloud.com',
    (Service.USAGE, Region.US_CHICAGO_1): 'https://usageapi.us-chicago-1.oci.oraclecloud.com',
    (Service.USAGE, Region.US_PHOENIX_1): 'https://usageapi.us-phoenix-1.oci.oraclecloud.com',
    (Service.USAGE, Region.US_SANJOSE_1): 'https://usageapi.us-sanjose-1.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.AF_JOHANNESBURG_1,
    ): 'https://identity.af-johannesburg-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.AP_BATAM_1): 'https://identity.ap-batam-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.AP_CHUNCHEON_1,
    ): 'https://identity.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.AP_HYDERABAD_1,
    ): 'https://identity.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.AP_MELBOURNE_1,
    ): 'https://identity.ap-melbourne-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.AP_MUMBAI_1): 'https://identity.ap-mumbai-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.AP_OSAKA_1): 'https://identity.ap-osaka-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.AP_SEOUL_1): 'https://identity.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.AP_SINGAPORE_1,
    ): 'https://identity.ap-singapore-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.AP_SYDNEY_1): 'https://identity.ap-sydney-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.AP_TOKYO_1): 'https://identity.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.CA_MONTREAL_1,
    ): 'https://identity.ca-montreal-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.CA_TORONTO_1): 'https://identity.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.EU_AMSTERDAM_1,
    ): 'https://identity.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.EU_FRANKFURT_1,
    ): 'https://identity.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.EU_JOVANOVAC_1,
    ): 'https://identity.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.USAGE_PROXY, Region.EU_MADRID_1): 'https://identity.eu-madrid-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.EU_MADRID_3): 'https://identity.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.EU_MARSEILLE_1,
    ): 'https://identity.eu-marseille-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.EU_MILAN_1): 'https://identity.eu-milan-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.EU_PARIS_1): 'https://identity.eu-paris-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.EU_STOCKHOLM_1,
    ): 'https://identity.eu-stockholm-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.EU_TURIN_1): 'https://identity.eu-turin-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.EU_ZURICH_1): 'https://identity.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.IL_JERUSALEM_1,
    ): 'https://identity.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.ME_ABUDHABI_1,
    ): 'https://identity.me-abudhabi-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.ME_DUBAI_1): 'https://identity.me-dubai-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.ME_JEDDAH_1): 'https://identity.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.MX_QUERETARO_1,
    ): 'https://identity.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.SA_SANTIAGO_1,
    ): 'https://identity.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.USAGE_PROXY,
        Region.SA_SAOPAULO_1,
    ): 'https://identity.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.SA_VINHEDO_1): 'https://identity.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.UK_CARDIFF_1): 'https://identity.uk-cardiff-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.UK_LONDON_1): 'https://identity.uk-london-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.US_ASHBURN_1): 'https://identity.us-ashburn-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.US_CHICAGO_1): 'https://identity.us-chicago-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.US_PHOENIX_1): 'https://identity.us-phoenix-1.oci.oraclecloud.com',
    (Service.USAGE_PROXY, Region.US_SANJOSE_1): 'https://identity.us-sanjose-1.oraclecloud.com',
    (
        Service.VISION,
        Region.AF_JOHANNESBURG_1,
    ): 'https://vision.aiservice.af-johannesburg-1.oci.oraclecloud.com',
    (Service.VISION, Region.AP_BATAM_1): 'https://vision.aiservice.ap-batam-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.AP_CHUNCHEON_1,
    ): 'https://vision.aiservice.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.AP_HYDERABAD_1,
    ): 'https://vision.aiservice.ap-hyderabad-1.oraclecloud.com',
    (
        Service.VISION,
        Region.AP_MELBOURNE_1,
    ): 'https://vision.aiservice.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.AP_MUMBAI_1,
    ): 'https://vision.aiservice.ap-mumbai-1.oci.oraclecloud.com',
    (Service.VISION, Region.AP_OSAKA_1): 'https://vision.aiservice.ap-osaka-1.oci.oraclecloud.com',
    (Service.VISION, Region.AP_SEOUL_1): 'https://vision.aiservice.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.AP_SINGAPORE_1,
    ): 'https://vision.aiservice.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.AP_SINGAPORE_2,
    ): 'https://vision.aiservice.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.AP_SYDNEY_1,
    ): 'https://vision.aiservice.ap-sydney-1.oci.oraclecloud.com',
    (Service.VISION, Region.AP_TOKYO_1): 'https://vision.aiservice.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.CA_MONTREAL_1,
    ): 'https://vision.aiservice.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.CA_TORONTO_1,
    ): 'https://vision.aiservice.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.EU_AMSTERDAM_1,
    ): 'https://vision.aiservice.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.EU_FRANKFURT_1,
    ): 'https://vision.aiservice.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.EU_JOVANOVAC_1,
    ): 'https://vision.aiservice.eu-jovanovac-1.oci.oraclecloud20.com',
    (
        Service.VISION,
        Region.EU_MADRID_1,
    ): 'https://vision.aiservice.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.EU_MADRID_3,
    ): 'https://vision.aiservice.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.EU_MARSEILLE_1,
    ): 'https://vision.aiservice.eu-marseille-1.oci.oraclecloud.com',
    (Service.VISION, Region.EU_MILAN_1): 'https://vision.aiservice.eu-milan-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.EU_STOCKHOLM_1,
    ): 'https://vision.aiservice.eu-stockholm-1.oci.oraclecloud.com',
    (Service.VISION, Region.EU_TURIN_1): 'https://vision.aiservice.eu-turin-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.EU_ZURICH_1,
    ): 'https://vision.aiservice.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.IL_JERUSALEM_1,
    ): 'https://vision.aiservice.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.ME_ABUDHABI_1,
    ): 'https://vision.aiservice.me-abudhabi-1.oci.oraclecloud.com',
    (Service.VISION, Region.ME_DUBAI_1): 'https://vision.aiservice.me-dubai-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.ME_JEDDAH_1,
    ): 'https://vision.aiservice.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.ME_RIYADH_1,
    ): 'https://vision.aiservice.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.MX_MONTERREY_1,
    ): 'https://vision.aiservice.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.MX_QUERETARO_1,
    ): 'https://vision.aiservice.mx-queretaro-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.SA_BOGOTA_1,
    ): 'https://vision.aiservice.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.SA_SANTIAGO_1,
    ): 'https://vision.aiservice.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.SA_SAOPAULO_1,
    ): 'https://vision.aiservice.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.SA_VALPARAISO_1,
    ): 'https://vision.aiservice.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.SA_VINHEDO_1,
    ): 'https://vision.aiservice.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.UK_CARDIFF_1,
    ): 'https://vision.aiservice.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.UK_LONDON_1,
    ): 'https://vision.aiservice.uk-london-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.US_ASHBURN_1,
    ): 'https://vision.aiservice.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.US_PHOENIX_1,
    ): 'https://vision.aiservice.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.VISION,
        Region.US_SANJOSE_1,
    ): 'https://vision.aiservice.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AF_JOHANNESBURG_1,
    ): 'https://visualbuilder.af-johannesburg-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AP_BATAM_1,
    ): 'https://visualbuilder.ap-batam-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AP_CHUNCHEON_1,
    ): 'https://visualbuilder.ap-chuncheon-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AP_HYDERABAD_1,
    ): 'https://visualbuilder.ap-hyderabad-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AP_MELBOURNE_1,
    ): 'https://visualbuilder.ap-melbourne-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AP_MUMBAI_1,
    ): 'https://visualbuilder.ap-mumbai-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AP_OSAKA_1,
    ): 'https://visualbuilder.ap-osaka-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AP_SEOUL_1,
    ): 'https://visualbuilder.ap-seoul-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AP_SINGAPORE_1,
    ): 'https://visualbuilder.ap-singapore-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AP_SINGAPORE_2,
    ): 'https://visualbuilder.ap-singapore-2.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AP_SYDNEY_1,
    ): 'https://visualbuilder.ap-sydney-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.AP_TOKYO_1,
    ): 'https://visualbuilder.ap-tokyo-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.CA_MONTREAL_1,
    ): 'https://visualbuilder.ca-montreal-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.CA_TORONTO_1,
    ): 'https://visualbuilder.ca-toronto-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.EU_AMSTERDAM_1,
    ): 'https://visualbuilder.eu-amsterdam-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.EU_FRANKFURT_1,
    ): 'https://visualbuilder.eu-frankfurt-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.EU_JOVANOVAC_1,
    ): 'https://visualbuilder.eu-jovanovac-1.ocp.oraclecloud20.com',
    (
        Service.VISUAL_BUILDER,
        Region.EU_MADRID_1,
    ): 'https://visualbuilder.eu-madrid-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.EU_MADRID_3,
    ): 'https://visualbuilder.eu-madrid-3.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.EU_MARSEILLE_1,
    ): 'https://visualbuilder.eu-marseille-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.EU_MILAN_1,
    ): 'https://visualbuilder.eu-milan-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.EU_PARIS_1,
    ): 'https://visualbuilder.eu-paris-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.EU_STOCKHOLM_1,
    ): 'https://visualbuilder.eu-stockholm-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.EU_TURIN_1,
    ): 'https://visualbuilder.eu-turin-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.EU_ZURICH_1,
    ): 'https://visualbuilder.eu-zurich-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.IL_JERUSALEM_1,
    ): 'https://visualbuilder.il-jerusalem-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.ME_ABUDHABI_1,
    ): 'https://visualbuilder.me-abudhabi-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.ME_DUBAI_1,
    ): 'https://visualbuilder.me-dubai-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.ME_JEDDAH_1,
    ): 'https://visualbuilder.me-jeddah-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.ME_RIYADH_1,
    ): 'https://visualbuilder.me-riyadh-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.MX_MONTERREY_1,
    ): 'https://visualbuilder.mx-monterrey-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.MX_QUERETARO_1,
    ): 'https://visualbuilder.mx-queretaro-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.SA_BOGOTA_1,
    ): 'https://visualbuilder.sa-bogota-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.SA_SANTIAGO_1,
    ): 'https://visualbuilder.sa-santiago-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.SA_SAOPAULO_1,
    ): 'https://visualbuilder.sa-saopaulo-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.SA_VALPARAISO_1,
    ): 'https://visualbuilder.sa-valparaiso-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.SA_VINHEDO_1,
    ): 'https://visualbuilder.sa-vinhedo-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.UK_CARDIFF_1,
    ): 'https://visualbuilder.uk-cardiff-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.UK_LONDON_1,
    ): 'https://visualbuilder.uk-london-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.US_ASHBURN_1,
    ): 'https://visualbuilder.us-ashburn-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.US_CHICAGO_1,
    ): 'https://visualbuilder.us-chicago-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.US_PHOENIX_1,
    ): 'https://visualbuilder.us-phoenix-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER,
        Region.US_SANJOSE_1,
    ): 'https://visualbuilder.us-sanjose-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.AF_JOHANNESBURG_1,
    ): 'https://vbstudio.af-johannesburg-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.AP_BATAM_1,
    ): 'https://vbstudio.ap-batam-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.AP_CHUNCHEON_1,
    ): 'https://vbstudio.ap-chuncheon-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.AP_HYDERABAD_1,
    ): 'https://vbstudio.ap-hyderabad-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.AP_MELBOURNE_1,
    ): 'https://vbstudio.ap-melbourne-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.AP_MUMBAI_1,
    ): 'https://vbstudio.ap-mumbai-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.AP_OSAKA_1,
    ): 'https://vbstudio.ap-osaka-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.AP_SEOUL_1,
    ): 'https://vbstudio.ap-seoul-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.AP_SINGAPORE_1,
    ): 'https://vbstudio.ap-singapore-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.AP_SYDNEY_1,
    ): 'https://vbstudio.ap-sydney-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.AP_TOKYO_1,
    ): 'https://vbstudio.ap-tokyo-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.CA_MONTREAL_1,
    ): 'https://vbstudio.ca-montreal-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.CA_TORONTO_1,
    ): 'https://vbstudio.ca-toronto-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.EU_AMSTERDAM_1,
    ): 'https://vbstudio.eu-amsterdam-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.EU_FRANKFURT_1,
    ): 'https://vbstudio.eu-frankfurt-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.EU_JOVANOVAC_1,
    ): 'https://vbstudio.eu-jovanovac-1.ocp.oraclecloud20.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.EU_MADRID_1,
    ): 'https://vbstudio.eu-madrid-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.EU_MADRID_3,
    ): 'https://vbstudio.eu-madrid-3.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.EU_MARSEILLE_1,
    ): 'https://vbstudio.eu-marseille-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.EU_MILAN_1,
    ): 'https://vbstudio.eu-milan-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.EU_PARIS_1,
    ): 'https://vbstudio.eu-paris-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.EU_STOCKHOLM_1,
    ): 'https://vbstudio.eu-stockholm-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.EU_TURIN_1,
    ): 'https://vbstudio.eu-turin-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.EU_ZURICH_1,
    ): 'https://vbstudio.eu-zurich-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.IL_JERUSALEM_1,
    ): 'https://vbstudio.il-jerusalem-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.ME_ABUDHABI_1,
    ): 'https://vbstudio.me-abudhabi-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.ME_DUBAI_1,
    ): 'https://vbstudio.me-dubai-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.ME_JEDDAH_1,
    ): 'https://vbstudio.me-jeddah-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.ME_RIYADH_1,
    ): 'https://vbstudio.me-riyadh-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.MX_MONTERREY_1,
    ): 'https://vbstudio.mx-monterrey-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.MX_QUERETARO_1,
    ): 'https://vbstudio.mx-queretaro-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.SA_BOGOTA_1,
    ): 'https://vbstudio.sa-bogota-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.SA_SANTIAGO_1,
    ): 'https://vbstudio.sa-santiago-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.SA_SAOPAULO_1,
    ): 'https://vbstudio.sa-saopaulo-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.SA_VALPARAISO_1,
    ): 'https://vbstudio.sa-valparaiso-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.SA_VINHEDO_1,
    ): 'https://vbstudio.sa-vinhedo-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.UK_CARDIFF_1,
    ): 'https://vbstudio.uk-cardiff-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.UK_LONDON_1,
    ): 'https://vbstudio.uk-london-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.US_ASHBURN_1,
    ): 'https://vbstudio.us-ashburn-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.US_CHICAGO_1,
    ): 'https://vbstudio.us-chicago-1.ocp.oraclecorp.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.US_PHOENIX_1,
    ): 'https://vbstudio.us-phoenix-1.ocp.oraclecloud.com',
    (
        Service.VISUAL_BUILDER_STUDIO,
        Region.US_SANJOSE_1,
    ): 'https://vbstudio.us-sanjose-1.ocp.oraclecloud.com',
    (
        Service.VMWARE,
        Region.AF_JOHANNESBURG_1,
    ): 'https://ocvps.af-johannesburg-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.AP_BATAM_1): 'https://ocvps.ap-batam-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.AP_CHUNCHEON_1): 'https://ocvps.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.AP_HYDERABAD_1): 'https://ocvps.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.AP_MELBOURNE_1): 'https://ocvps.ap-melbourne-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.AP_MUMBAI_1): 'https://ocvps.ap-mumbai-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.AP_OSAKA_1): 'https://ocvps.ap-osaka-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.AP_SEOUL_1): 'https://ocvps.ap-seoul-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.AP_SINGAPORE_1): 'https://ocvps.ap-singapore-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.AP_SINGAPORE_2): 'https://ocvps.ap-singapore-2.oci.oraclecloud.com',
    (Service.VMWARE, Region.AP_SYDNEY_1): 'https://ocvps.ap-sydney-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.AP_TOKYO_1): 'https://ocvps.ap-tokyo-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.CA_MONTREAL_1): 'https://ocvps.ca-montreal-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.CA_TORONTO_1): 'https://ocvps.ca-toronto-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.EU_AMSTERDAM_1): 'https://ocvps.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.EU_FRANKFURT_1): 'https://ocvps.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.EU_JOVANOVAC_1): 'https://ocvps.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.VMWARE, Region.EU_MADRID_1): 'https://ocvps.eu-madrid-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.EU_MADRID_3): 'https://ocvps.eu-madrid-3.oci.oraclecloud.com',
    (Service.VMWARE, Region.EU_MARSEILLE_1): 'https://ocvps.eu-marseille-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.EU_MILAN_1): 'https://ocvps.eu-milan-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.EU_PARIS_1): 'https://ocvps.eu-paris-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.EU_STOCKHOLM_1): 'https://ocvps.eu-stockholm-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.EU_TURIN_1): 'https://ocvps.eu-turin-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.EU_ZURICH_1): 'https://ocvps.eu-zurich-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.IL_JERUSALEM_1): 'https://ocvps.il-jerusalem-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.ME_ABUDHABI_1): 'https://ocvps.me-abudhabi-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.ME_DUBAI_1): 'https://ocvps.me-dubai-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.ME_JEDDAH_1): 'https://ocvps.me-jeddah-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.ME_RIYADH_1): 'https://ocvps.me-riyadh-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.MX_MONTERREY_1): 'https://ocvps.mx-monterrey-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.MX_QUERETARO_1): 'https://ocvps.mx-queretaro-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.SA_BOGOTA_1): 'https://ocvps.sa-bogota-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.SA_SANTIAGO_1): 'https://ocvps.sa-santiago-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.SA_SAOPAULO_1): 'https://ocvps.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.SA_VALPARAISO_1): 'https://ocvps.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.SA_VINHEDO_1): 'https://ocvps.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.UK_CARDIFF_1): 'https://ocvps.uk-cardiff-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.UK_LONDON_1): 'https://ocvps.uk-london-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.US_ASHBURN_1): 'https://ocvps.us-ashburn-1.oci.oraclecloud.com',
    (Service.VMWARE, Region.US_PHOENIX_1): 'https://ocvps.us-phoenix-1.oci.oraclecloud.com',
    (Service.WAA, Region.AF_JOHANNESBURG_1): 'https://waa.af-johannesburg-1.oci.oraclecloud.com',
    (Service.WAA, Region.AP_BATAM_1): 'https://waa.ap-batam-1.oci.oraclecloud.com',
    (Service.WAA, Region.AP_CHUNCHEON_1): 'https://waa.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.WAA, Region.AP_HYDERABAD_1): 'https://waa.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.WAA, Region.AP_MELBOURNE_1): 'https://waa.ap-melbourne-1.oci.oraclecloud.com',
    (Service.WAA, Region.AP_MUMBAI_1): 'https://waa.ap-mumbai-1.oci.oraclecloud.com',
    (Service.WAA, Region.AP_OSAKA_1): 'https://waa.ap-osaka-1.oci.oraclecloud.com',
    (Service.WAA, Region.AP_SEOUL_1): 'https://waa.ap-seoul-1.oci.oraclecloud.com',
    (Service.WAA, Region.AP_SINGAPORE_1): 'https://waa.ap-singapore-1.oci.oraclecloud.com',
    (Service.WAA, Region.AP_SINGAPORE_2): 'https://waa.ap-singapore-2.oci.oraclecloud.com',
    (Service.WAA, Region.AP_SYDNEY_1): 'https://waa.ap-sydney-1.oci.oraclecloud.com',
    (Service.WAA, Region.AP_TOKYO_1): 'https://waa.ap-tokyo-1.oci.oraclecloud.com',
    (Service.WAA, Region.CA_MONTREAL_1): 'https://waa.ca-montreal-1.oci.oraclecloud.com',
    (Service.WAA, Region.CA_TORONTO_1): 'https://waa.ca-toronto-1.oci.oraclecloud.com',
    (Service.WAA, Region.EU_AMSTERDAM_1): 'https://waa.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.WAA, Region.EU_FRANKFURT_1): 'https://waa.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.WAA, Region.EU_JOVANOVAC_1): 'https://waa.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.WAA, Region.EU_MADRID_1): 'https://waa.eu-madrid-1.oci.oraclecloud.com',
    (Service.WAA, Region.EU_MADRID_3): 'https://waa.eu-madrid-3.oci.oraclecloud.com',
    (Service.WAA, Region.EU_MARSEILLE_1): 'https://waa.eu-marseille-1.oci.oraclecloud.com',
    (Service.WAA, Region.EU_MILAN_1): 'https://waa.eu-milan-1.oci.oraclecloud.com',
    (Service.WAA, Region.EU_PARIS_1): 'https://waa.eu-paris-1.oci.oraclecloud.com',
    (Service.WAA, Region.EU_STOCKHOLM_1): 'https://waa.eu-stockholm-1.oci.oraclecloud.com',
    (Service.WAA, Region.EU_TURIN_1): 'https://waa.eu-turin-1.oci.oraclecloud.com',
    (Service.WAA, Region.EU_ZURICH_1): 'https://waa.eu-zurich-1.oci.oraclecloud.com',
    (Service.WAA, Region.IL_JERUSALEM_1): 'https://waa.il-jerusalem-1.oci.oraclecloud.com',
    (Service.WAA, Region.ME_ABUDHABI_1): 'https://waa.me-abudhabi-1.oci.oraclecloud.com',
    (Service.WAA, Region.ME_DUBAI_1): 'https://waa.me-dubai-1.oci.oraclecloud.com',
    (Service.WAA, Region.ME_JEDDAH_1): 'https://waa.me-jeddah-1.oci.oraclecloud.com',
    (Service.WAA, Region.ME_RIYADH_1): 'https://waa.me-riyadh-1.oci.oraclecloud.com',
    (Service.WAA, Region.MX_MONTERREY_1): 'https://waa.mx-monterrey-1.oci.oraclecloud.com',
    (Service.WAA, Region.MX_QUERETARO_1): 'https://waa.mx-queretaro-1.oci.oraclecloud.com',
    (Service.WAA, Region.SA_BOGOTA_1): 'https://waa.sa-bogota-1.oci.oraclecloud.com',
    (Service.WAA, Region.SA_SANTIAGO_1): 'https://waa.sa-santiago-1.oci.oraclecloud.com',
    (Service.WAA, Region.SA_SAOPAULO_1): 'https://waa.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.WAA, Region.SA_VALPARAISO_1): 'https://waa.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.WAA, Region.SA_VINHEDO_1): 'https://waa.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.WAA, Region.UK_CARDIFF_1): 'https://waa.uk-cardiff-1.oci.oraclecloud.com',
    (Service.WAA, Region.UK_LONDON_1): 'https://waa.uk-london-1.oci.oraclecloud.com',
    (Service.WAA, Region.US_ASHBURN_1): 'https://waa.us-ashburn-1.oci.oraclecloud.com',
    (Service.WAA, Region.US_CHICAGO_1): 'https://waa.us-chicago-1.oci.oraclecloud.com',
    (Service.WAA, Region.US_PHOENIX_1): 'https://waa.us-phoenix-1.oci.oraclecloud.com',
    (Service.WAA, Region.US_SANJOSE_1): 'https://waa.us-sanjose-1.oci.oraclecloud.com',
    (Service.WAAS, Region.AF_JOHANNESBURG_1): 'https://waas.af-johannesburg-1.oci.oraclecloud.com',
    (Service.WAAS, Region.AP_BATAM_1): 'https://waas.ap-batam-1.oci.oraclecloud.com',
    (Service.WAAS, Region.AP_CHUNCHEON_1): 'https://waas.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.WAAS, Region.AP_HYDERABAD_1): 'https://waas.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.WAAS, Region.AP_MELBOURNE_1): 'https://waas.ap-melbourne-1.oci.oraclecloud.com',
    (Service.WAAS, Region.AP_MUMBAI_1): 'https://waas.ap-mumbai-1.oci.oraclecloud.com',
    (Service.WAAS, Region.AP_OSAKA_1): 'https://waas.ap-osaka-1.oci.oraclecloud.com',
    (Service.WAAS, Region.AP_SEOUL_1): 'https://waas.ap-seoul-1.oci.oraclecloud.com',
    (Service.WAAS, Region.AP_SINGAPORE_1): 'https://waas.ap-singapore-1.oci.oraclecloud.com',
    (Service.WAAS, Region.AP_SINGAPORE_2): 'https://waas.ap-singapore-2.oci.oraclecloud.com',
    (Service.WAAS, Region.AP_SYDNEY_1): 'https://waas.ap-sydney-1.oci.oraclecloud.com',
    (Service.WAAS, Region.AP_TOKYO_1): 'https://waas.ap-tokyo-1.oci.oraclecloud.com',
    (Service.WAAS, Region.CA_MONTREAL_1): 'https://waas.ca-montreal-1.oci.oraclecloud.com',
    (Service.WAAS, Region.CA_TORONTO_1): 'https://waas.ca-toronto-1.oci.oraclecloud.com',
    (Service.WAAS, Region.EU_AMSTERDAM_1): 'https://waas.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.WAAS, Region.EU_FRANKFURT_1): 'https://waas.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.WAAS, Region.EU_JOVANOVAC_1): 'https://waas.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.WAAS, Region.EU_MADRID_1): 'https://waas.eu-madrid-1.oci.oraclecloud.com',
    (Service.WAAS, Region.EU_MADRID_3): 'https://waas.eu-madrid-3.oci.oraclecloud.com',
    (Service.WAAS, Region.EU_MARSEILLE_1): 'https://waas.eu-marseille-1.oci.oraclecloud.com',
    (Service.WAAS, Region.EU_MILAN_1): 'https://waas.eu-milan-1.oci.oraclecloud.com',
    (Service.WAAS, Region.EU_PARIS_1): 'https://waas.eu-paris-1.oci.oraclecloud.com',
    (Service.WAAS, Region.EU_STOCKHOLM_1): 'https://waas.eu-stockholm-1.oci.oraclecloud.com',
    (Service.WAAS, Region.EU_TURIN_1): 'https://waas.eu-turin-1.oci.oraclecloud.com',
    (Service.WAAS, Region.EU_ZURICH_1): 'https://waas.eu-zurich-1.oci.oraclecloud.com',
    (Service.WAAS, Region.IL_JERUSALEM_1): 'https://waas.il-jerusalem-1.oci.oraclecloud.com',
    (Service.WAAS, Region.ME_ABUDHABI_1): 'https://waas.me-abudhabi-1.oci.oraclecloud.com',
    (Service.WAAS, Region.ME_DUBAI_1): 'https://waas.me-dubai-1.oci.oraclecloud.com',
    (Service.WAAS, Region.ME_JEDDAH_1): 'https://waas.me-jeddah-1.oci.oraclecloud.com',
    (Service.WAAS, Region.ME_RIYADH_1): 'https://waas.me-riyadh-1.oci.oraclecloud.com',
    (Service.WAAS, Region.MX_MONTERREY_1): 'https://waas.mx-monterrey-1.oci.oraclecloud.com',
    (Service.WAAS, Region.MX_QUERETARO_1): 'https://waas.mx-queretaro-1.oci.oraclecloud.com',
    (Service.WAAS, Region.SA_BOGOTA_1): 'https://waas.sa-bogota-1.oci.oraclecloud.com',
    (Service.WAAS, Region.SA_SANTIAGO_1): 'https://waas.sa-santiago-1.oci.oraclecloud.com',
    (Service.WAAS, Region.SA_SAOPAULO_1): 'https://waas.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.WAAS, Region.SA_VALPARAISO_1): 'https://waas.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.WAAS, Region.SA_VINHEDO_1): 'https://waas.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.WAAS, Region.UK_CARDIFF_1): 'https://waas.uk-cardiff-1.oci.oraclecloud.com',
    (Service.WAAS, Region.UK_LONDON_1): 'https://waas.uk-london-1.oci.oraclecloud.com',
    (Service.WAAS, Region.US_ASHBURN_1): 'https://waas.us-ashburn-1.oci.oraclecloud.com',
    (Service.WAAS, Region.US_CHICAGO_1): 'https://waas.us-chicago-1.oci.oraclecloud.com',
    (Service.WAAS, Region.US_PHOENIX_1): 'https://waas.us-phoenix-1.oci.oraclecloud.com',
    (Service.WAAS, Region.US_SANJOSE_1): 'https://waas.us-sanjose-1.oci.oraclecloud.com',
    (Service.WAF, Region.AF_JOHANNESBURG_1): 'https://waf.af-johannesburg-1.oci.oraclecloud.com',
    (Service.WAF, Region.AP_BATAM_1): 'https://waf.ap-batam-1.oci.oraclecloud.com',
    (Service.WAF, Region.AP_CHUNCHEON_1): 'https://waf.ap-chuncheon-1.oci.oraclecloud.com',
    (Service.WAF, Region.AP_HYDERABAD_1): 'https://waf.ap-hyderabad-1.oci.oraclecloud.com',
    (Service.WAF, Region.AP_MELBOURNE_1): 'https://waf.ap-melbourne-1.oci.oraclecloud.com',
    (Service.WAF, Region.AP_MUMBAI_1): 'https://waf.ap-mumbai-1.oci.oraclecloud.com',
    (Service.WAF, Region.AP_OSAKA_1): 'https://waf.ap-osaka-1.oci.oraclecloud.com',
    (Service.WAF, Region.AP_SEOUL_1): 'https://waf.ap-seoul-1.oci.oraclecloud.com',
    (Service.WAF, Region.AP_SINGAPORE_1): 'https://waf.ap-singapore-1.oci.oraclecloud.com',
    (Service.WAF, Region.AP_SINGAPORE_2): 'https://waf.ap-singapore-2.oci.oraclecloud.com',
    (Service.WAF, Region.AP_SYDNEY_1): 'https://waf.ap-sydney-1.oci.oraclecloud.com',
    (Service.WAF, Region.AP_TOKYO_1): 'https://waf.ap-tokyo-1.oci.oraclecloud.com',
    (Service.WAF, Region.CA_MONTREAL_1): 'https://waf.ca-montreal-1.oci.oraclecloud.com',
    (Service.WAF, Region.CA_TORONTO_1): 'https://waf.ca-toronto-1.oci.oraclecloud.com',
    (Service.WAF, Region.EU_AMSTERDAM_1): 'https://waf.eu-amsterdam-1.oci.oraclecloud.com',
    (Service.WAF, Region.EU_FRANKFURT_1): 'https://waf.eu-frankfurt-1.oci.oraclecloud.com',
    (Service.WAF, Region.EU_JOVANOVAC_1): 'https://waf.eu-jovanovac-1.oci.oraclecloud20.com',
    (Service.WAF, Region.EU_MADRID_1): 'https://waf.eu-madrid-1.oci.oraclecloud.com',
    (Service.WAF, Region.EU_MADRID_3): 'https://waf.eu-madrid-3.oci.oraclecloud.com',
    (Service.WAF, Region.EU_MARSEILLE_1): 'https://waf.eu-marseille-1.oci.oraclecloud.com',
    (Service.WAF, Region.EU_MILAN_1): 'https://waf.eu-milan-1.oci.oraclecloud.com',
    (Service.WAF, Region.EU_PARIS_1): 'https://waf.eu-paris-1.oci.oraclecloud.com',
    (Service.WAF, Region.EU_STOCKHOLM_1): 'https://waf.eu-stockholm-1.oci.oraclecloud.com',
    (Service.WAF, Region.EU_TURIN_1): 'https://waf.eu-turin-1.oci.oraclecloud.com',
    (Service.WAF, Region.EU_ZURICH_1): 'https://waf.eu-zurich-1.oci.oraclecloud.com',
    (Service.WAF, Region.IL_JERUSALEM_1): 'https://waf.il-jerusalem-1.oci.oraclecloud.com',
    (Service.WAF, Region.ME_ABUDHABI_1): 'https://waf.me-abudhabi-1.oci.oraclecloud.com',
    (Service.WAF, Region.ME_DUBAI_1): 'https://waf.me-dubai-1.oci.oraclecloud.com',
    (Service.WAF, Region.ME_JEDDAH_1): 'https://waf.me-jeddah-1.oci.oraclecloud.com',
    (Service.WAF, Region.ME_RIYADH_1): 'https://waf.me-riyadh-1.oci.oraclecloud.com',
    (Service.WAF, Region.MX_MONTERREY_1): 'https://waf.mx-monterrey-1.oci.oraclecloud.com',
    (Service.WAF, Region.MX_QUERETARO_1): 'https://waf.mx-queretaro-1.oci.oraclecloud.com',
    (Service.WAF, Region.SA_BOGOTA_1): 'https://waf.sa-bogota-1.oci.oraclecloud.com',
    (Service.WAF, Region.SA_SANTIAGO_1): 'https://waf.sa-santiago-1.oci.oraclecloud.com',
    (Service.WAF, Region.SA_SAOPAULO_1): 'https://waf.sa-saopaulo-1.oci.oraclecloud.com',
    (Service.WAF, Region.SA_VALPARAISO_1): 'https://waf.sa-valparaiso-1.oci.oraclecloud.com',
    (Service.WAF, Region.SA_VINHEDO_1): 'https://waf.sa-vinhedo-1.oci.oraclecloud.com',
    (Service.WAF, Region.UK_CARDIFF_1): 'https://waf.uk-cardiff-1.oci.oraclecloud.com',
    (Service.WAF, Region.UK_LONDON_1): 'https://waf.uk-london-1.oci.oraclecloud.com',
    (Service.WAF, Region.US_ASHBURN_1): 'https://waf.us-ashburn-1.oci.oraclecloud.com',
    (Service.WAF, Region.US_CHICAGO_1): 'https://waf.us-chicago-1.oci.oraclecloud.com',
    (Service.WAF, Region.US_PHOENIX_1): 'https://waf.us-phoenix-1.oci.oraclecloud.com',
    (Service.WAF, Region.US_SANJOSE_1): 'https://waf.us-sanjose-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://api.weblogicmanagement.af-johannesburg-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AP_BATAM_1,
    ): 'https://api.weblogicmanagement.ap-batam-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AP_CHUNCHEON_1,
    ): 'https://api.weblogicmanagement.ap-chuncheon-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AP_HYDERABAD_1,
    ): 'https://api.weblogicmanagement.ap-hyderabad-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AP_MELBOURNE_1,
    ): 'https://api.weblogicmanagement.ap-melbourne-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AP_MUMBAI_1,
    ): 'https://api.weblogicmanagement.ap-mumbai-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AP_OSAKA_1,
    ): 'https://api.weblogicmanagement.ap-osaka-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AP_SEOUL_1,
    ): 'https://api.weblogicmanagement.ap-seoul-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AP_SINGAPORE_1,
    ): 'https://api.weblogicmanagement.ap-singapore-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AP_SINGAPORE_2,
    ): 'https://api.weblogicmanagement.ap-singapore-2.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AP_SYDNEY_1,
    ): 'https://api.weblogicmanagement.ap-sydney-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.AP_TOKYO_1,
    ): 'https://api.weblogicmanagement.ap-tokyo-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.CA_MONTREAL_1,
    ): 'https://api.weblogicmanagement.ca-montreal-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.CA_TORONTO_1,
    ): 'https://api.weblogicmanagement.ca-toronto-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.EU_AMSTERDAM_1,
    ): 'https://api.weblogicmanagement.eu-amsterdam-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.EU_FRANKFURT_1,
    ): 'https://api.weblogicmanagement.eu-frankfurt-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.EU_MADRID_1,
    ): 'https://api.weblogicmanagement.eu-madrid-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.EU_MADRID_3,
    ): 'https://api.weblogicmanagement.eu-madrid-3.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.EU_MARSEILLE_1,
    ): 'https://api.weblogicmanagement.eu-marseille-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.EU_MILAN_1,
    ): 'https://api.weblogicmanagement.eu-milan-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.EU_PARIS_1,
    ): 'https://api.weblogicmanagement.eu-paris-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.EU_STOCKHOLM_1,
    ): 'https://api.weblogicmanagement.eu-stockholm-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.EU_TURIN_1,
    ): 'https://api.weblogicmanagement.eu-turin-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.EU_ZURICH_1,
    ): 'https://api.weblogicmanagement.eu-zurich-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.IL_JERUSALEM_1,
    ): 'https://api.weblogicmanagement.il-jerusalem-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.ME_ABUDHABI_1,
    ): 'https://api.weblogicmanagement.me-abudhabi-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.ME_DUBAI_1,
    ): 'https://api.weblogicmanagement.me-dubai-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.ME_JEDDAH_1,
    ): 'https://api.weblogicmanagement.me-jeddah-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.ME_RIYADH_1,
    ): 'https://api.weblogicmanagement.me-riyadh-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.MX_MONTERREY_1,
    ): 'https://api.weblogicmanagement.mx-monterrey-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.SA_BOGOTA_1,
    ): 'https://api.weblogicmanagement.sa-bogota-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.SA_SANTIAGO_1,
    ): 'https://api.weblogicmanagement.sa-santiago-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.SA_SAOPAULO_1,
    ): 'https://api.weblogicmanagement.sa-saopaulo-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.SA_VALPARAISO_1,
    ): 'https://api.weblogicmanagement.sa-valparaiso-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.SA_VINHEDO_1,
    ): 'https://api.weblogicmanagement.sa-vinhedo-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.UK_CARDIFF_1,
    ): 'https://api.weblogicmanagement.uk-cardiff-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.UK_LONDON_1,
    ): 'https://api.weblogicmanagement.uk-london-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.US_ASHBURN_1,
    ): 'https://api.weblogicmanagement.us-ashburn-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.US_CHICAGO_1,
    ): 'https://api.weblogicmanagement.us-chicago-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.US_PHOENIX_1,
    ): 'https://api.weblogicmanagement.us-phoenix-1.oci.oraclecloud.com',
    (
        Service.WLMS,
        Region.US_SANJOSE_1,
    ): 'https://api.weblogicmanagement.us-sanjose-1.oci.oraclecloud.com/',
    (
        Service.WORKREQUESTS,
        Region.AF_JOHANNESBURG_1,
    ): 'https://iaas.af-johannesburg-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.AP_BATAM_1): 'https://iaas.ap-batam-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.AP_CHUNCHEON_1): 'https://iaas.ap-chuncheon-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.AP_HYDERABAD_1): 'https://iaas.ap-hyderabad-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.AP_MELBOURNE_1): 'https://iaas.ap-melbourne-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.AP_MUMBAI_1): 'https://iaas.ap-mumbai-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.AP_OSAKA_1): 'https://iaas.ap-osaka-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.AP_SEOUL_1): 'https://iaas.ap-seoul-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.AP_SINGAPORE_1): 'https://iaas.ap-singapore-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.AP_SINGAPORE_2): 'https://iaas.ap-singapore-2.oraclecloud.com',
    (Service.WORKREQUESTS, Region.AP_SYDNEY_1): 'https://iaas.ap-sydney-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.AP_TOKYO_1): 'https://iaas.ap-tokyo-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.CA_MONTREAL_1): 'https://iaas.ca-montreal-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.CA_TORONTO_1): 'https://iaas.ca-toronto-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.EU_AMSTERDAM_1): 'https://iaas.eu-amsterdam-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.EU_FRANKFURT_1): 'https://iaas.eu-frankfurt-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.EU_JOVANOVAC_1): 'https://iaas.eu-jovanovac-1.oraclecloud20.com',
    (Service.WORKREQUESTS, Region.EU_MADRID_1): 'https://iaas.eu-madrid-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.EU_MADRID_3): 'https://iaas.eu-madrid-3.oraclecloud.com',
    (Service.WORKREQUESTS, Region.EU_MARSEILLE_1): 'https://iaas.eu-marseille-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.EU_MILAN_1): 'https://iaas.eu-milan-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.EU_PARIS_1): 'https://iaas.eu-paris-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.EU_STOCKHOLM_1): 'https://iaas.eu-stockholm-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.EU_TURIN_1): 'https://iaas.eu-turin-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.EU_ZURICH_1): 'https://iaas.eu-zurich-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.IL_JERUSALEM_1): 'https://iaas.il-jerusalem-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.ME_ABUDHABI_1): 'https://iaas.me-abudhabi-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.ME_DUBAI_1): 'https://iaas.me-dubai-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.ME_JEDDAH_1): 'https://iaas.me-jeddah-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.ME_RIYADH_1): 'https://iaas.me-riyadh-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.MX_MONTERREY_1): 'https://iaas.mx-monterrey-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.MX_QUERETARO_1): 'https://iaas.mx-queretaro-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.SA_BOGOTA_1): 'https://iaas.sa-bogota-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.SA_SANTIAGO_1): 'https://iaas.sa-santiago-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.SA_SAOPAULO_1): 'https://iaas.sa-saopaulo-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.SA_VALPARAISO_1): 'https://iaas.sa-valparaiso-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.SA_VINHEDO_1): 'https://iaas.sa-vinhedo-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.UK_CARDIFF_1): 'https://iaas.uk-cardiff-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.UK_LONDON_1): 'https://iaas.uk-london-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.US_ASHBURN_1): 'https://iaas.us-ashburn-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.US_CHICAGO_1): 'https://iaas.us-chicago-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.US_PHOENIX_1): 'https://iaas.us-phoenix-1.oraclecloud.com',
    (Service.WORKREQUESTS, Region.US_SANJOSE_1): 'https://iaas.us-sanjose-1.oraclecloud.com',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.AF_JOHANNESBURG_1,
    ): 'https://zpr.af-johannesburg-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.AP_CHUNCHEON_1,
    ): 'https://zpr.ap-chuncheon-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.AP_HYDERABAD_1,
    ): 'https://zpr.ap-hyderabad-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.AP_MELBOURNE_1,
    ): 'https://zpr.ap-melbourne-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.AP_MUMBAI_1,
    ): 'https://zpr.ap-mumbai-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.AP_OSAKA_1,
    ): 'https://zpr.ap-osaka-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.AP_SEOUL_1,
    ): 'https://zpr.ap-seoul-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.AP_SINGAPORE_1,
    ): 'https://zpr.ap-singapore-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.AP_SINGAPORE_2,
    ): 'https://zpr.ap-singapore-2.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.AP_SYDNEY_1,
    ): 'https://zpr.ap-sydney-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.AP_TOKYO_1,
    ): 'https://zpr.ap-tokyo-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.CA_MONTREAL_1,
    ): 'https://zpr.ca-montreal-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.CA_TORONTO_1,
    ): 'https://zpr.ca-toronto-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.EU_AMSTERDAM_1,
    ): 'https://zpr.eu-amsterdam-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.EU_FRANKFURT_1,
    ): 'https://zpr.eu-frankfurt-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.EU_JOVANOVAC_1,
    ): 'https://zpr.eu-jovanovac-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.EU_MADRID_1,
    ): 'https://zpr.eu-madrid-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.EU_MADRID_3,
    ): 'https://zpr.eu-madrid-3.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.EU_MARSEILLE_1,
    ): 'https://zpr.eu-marseille-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.EU_MILAN_1,
    ): 'https://zpr.eu-milan-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.EU_PARIS_1,
    ): 'https://zpr.eu-paris-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.EU_STOCKHOLM_1,
    ): 'https://zpr.eu-stockholm-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.EU_TURIN_1,
    ): 'https://zpr.eu-turin-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.EU_ZURICH_1,
    ): 'https://zpr.eu-zurich-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.IL_JERUSALEM_1,
    ): 'https://zpr.il-jerusalem-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.ME_ABUDHABI_1,
    ): 'https://zpr.me-abudhabi-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.ME_DUBAI_1,
    ): 'https://zpr.me-dubai-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.ME_JEDDAH_1,
    ): 'https://zpr.me-jeddah-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.MX_MONTERREY_1,
    ): 'https://zpr.mx-monterrey-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.MX_QUERETARO_1,
    ): 'https://zpr.mx-queretaro-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.SA_BOGOTA_1,
    ): 'https://zpr.sa-bogota-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.SA_SANTIAGO_1,
    ): 'https://zpr.sa-santiago-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.SA_SAOPAULO_1,
    ): 'https://zpr.sa-saopaulo-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.SA_VALPARAISO_1,
    ): 'https://zpr.sa-valparaiso-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.SA_VINHEDO_1,
    ): 'https://zpr.sa-vinhedo-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.UK_CARDIFF_1,
    ): 'https://zpr.uk-cardiff-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.UK_LONDON_1,
    ): 'https://zpr.uk-london-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.US_ASHBURN_1,
    ): 'https://zpr.us-ashburn-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.US_CHICAGO_1,
    ): 'https://zpr.us-chicago-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.US_PHOENIX_1,
    ): 'https://zpr.us-phoenix-1.oci.oraclecloud.com/',
    (
        Service.ZERO_TRUST_PACKET_ROUTING,
        Region.US_SANJOSE_1,
    ): 'https://zpr.us-sanjose-1.oci.oraclecloud.com/',
}
