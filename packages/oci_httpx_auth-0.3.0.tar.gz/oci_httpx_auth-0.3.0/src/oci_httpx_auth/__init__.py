import typing

from ._auth import Auth
from ._auth import AuthConfig as Config
from ._endpoints import ENDPOINT_MAP as _ENDPOINT_MAP
from ._endpoints import Region, Service

if typing.TYPE_CHECKING:
    import httpx


def get_auth(config: Config) -> Auth:
    return Auth.create(
        Config(
            retry_start_delay=config.retry_start_delay,
            retry_max_delay=config.retry_max_delay,
            retry_timeout=config.retry_timeout,
            tenant_id=config.tenant_id,
            user_id=config.user_id,
            api_key_fingerprint=config.api_key_fingerprint,
            api_private_key_pem=config.api_private_key_pem,
        )
    )


def get_endpoint(service: Service, region: Region) -> str:
    endpoint = _ENDPOINT_MAP.get((service, region))
    if endpoint is None:
        msg = 'Region not found for given service'
        raise KeyError(msg, service, region)

    return endpoint


type Client = httpx.AsyncClient | httpx.Client


def setup_client(client: Client, service: Service, region: Region, config: Config) -> None:
    client.base_url = get_endpoint(service, region)
    client.auth = get_auth(config)


__all__ = [
    'Auth',
    'Client',
    'Config',
    'Region',
    'Service',
    'get_auth',
    'get_endpoint',
    'setup_client',
]
