"""Vector store tests package."""
