"""
Шаблон для генерации SQL создания таблицы и функции match.
Используйте f-строку для заполнения параметров.
"""


def generate_table_and_function_sql(
    table_name: str,
    embedding_dim: int = 1536,
) -> str:
    """
    Генерирует SQL код для создания таблицы и функции match.
    
    Args:
        table_name: Название таблицы
        embedding_dim: Размерность вектора embedding (по умолчанию 1536 для text-embedding-3-small)
    
    Returns:
        SQL код для создания таблицы и функции
    """
    function_name = f"match_{table_name}"
    
    sql = f"""-- Создание таблицы {table_name}
CREATE TABLE IF NOT EXISTS {table_name} (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    content text,
    metadata jsonb,
    embedding vector({embedding_dim})
);

-- Создание функции {function_name}
CREATE OR REPLACE FUNCTION {function_name}(
    query_embedding vector, 
    filter jsonb DEFAULT '{{}}'::jsonb
)
RETURNS TABLE(
    id uuid, 
    content text, 
    metadata jsonb, 
    similarity double precision
)
LANGUAGE plpgsql
AS $function$
DECLARE
    filter_conditions text := '';
    filter_key text;
    filter_value jsonb;
    array_elements text;
BEGIN
    -- Проверяем, есть ли фильтры
    IF filter IS NOT NULL AND filter != '{{}}'::jsonb THEN
        FOR filter_key, filter_value IN SELECT * FROM jsonb_each(filter)
        LOOP
            -- Строковые значения
            IF jsonb_typeof(filter_value) = 'string' THEN
                filter_conditions := filter_conditions || 
                    format(' AND metadata->>%L = %L', filter_key, filter_value #>> '{{}}');
            
            -- Массивы
            ELSIF jsonb_typeof(filter_value) = 'array' THEN
                SELECT string_agg(quote_literal(elem::text), ',')
                INTO array_elements
                FROM jsonb_array_elements_text(filter_value) AS elem;
                
                IF array_elements IS NOT NULL THEN
                    filter_conditions := filter_conditions || 
                        format(' AND metadata->>%L = ANY(ARRAY[%s])', filter_key, array_elements);
                END IF;

            -- Числа и boolean
            ELSIF jsonb_typeof(filter_value) IN ('number', 'boolean') THEN
                filter_conditions := filter_conditions || 
                    format(' AND metadata->>%L = %L', filter_key, filter_value #>> '{{}}');
            END IF;
        END LOOP;
    END IF;

    -- Выполняем запрос
    RETURN QUERY EXECUTE format(
        'SELECT 
            s.id,
            s.content,
            s.metadata,
            1 - (s.embedding <=> $1) AS similarity
         FROM {table_name} s
         WHERE TRUE %s
         ORDER BY s.embedding <=> $1',
        filter_conditions
    ) USING query_embedding;
END;
$function$;
"""
    return sql

