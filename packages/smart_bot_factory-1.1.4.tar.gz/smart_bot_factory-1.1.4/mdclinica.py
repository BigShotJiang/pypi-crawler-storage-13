"""
Mdclinica Bot - Умный Telegram бот на Smart Bot Factory
"""

import asyncio
from smart_bot_factory.router import EventRouter
from smart_bot_factory.creation import BotBuilder

from rag_tools import rag_router

# Инициализация
event_router = EventRouter("mdclinica")
bot_builder = BotBuilder("mdclinica")

# =============================================================================
# ЗАПУСК
# =============================================================================

async def main():
    # ========== РЕГИСТРАЦИЯ РОУТЕРОВ ==========
    bot_builder.register_routers(event_router)
    
    # Можно добавить Telegram роутеры:
    # from aiogram import Router
    # telegram_router = Router(name="commands")
    # bot_builder.register_telegram_router(telegram_router)
    
    # ========== КАСТОМИЗАЦИЯ (до build) ==========
    # Установить кастомный PromptLoader:
    # from smart_bot_factory.utils import UserPromptLoader
    # custom_loader = UserPromptLoader("mdclinica")
    # bot_builder.set_prompt_loader(custom_loader)
    
    # ========== СБОРКА И ЗАПУСК ==========
    bot_builder.register_rag(rag_router)
    
    await bot_builder.build()
    await bot_builder.start()

if __name__ == "__main__":
    asyncio.run(main())
    
