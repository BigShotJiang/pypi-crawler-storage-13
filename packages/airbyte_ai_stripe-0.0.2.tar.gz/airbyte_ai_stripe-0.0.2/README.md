# Stripe Connector for Airbyte SDK

Type-safe Stripe API connector with full IDE autocomplete support.

**Version:** 0.0.2

## Installation

```bash
uv pip install airbyte-connector-stripe
```

## Usage

```python
from airbyte_connector_stripe import StripeConnector

# Create connector
connector = StripeConnector.create(secrets={"api_key": "your_api_key"})

# Use typed methods with full IDE autocomplete
# (See Available Operations below for all methods)
```

## Available Operations

### Customers Operations
- `customers__list()` - List all customers
- `customers__retrieve()` - Retrieve a customer

## Type Definitions

All response types are fully typed using TypedDict for IDE autocomplete support.
Import types from `airbyte_connector_stripe.types`.

## Documentation

Generated from OpenAPI 3.0 specification.

For API documentation, see the service's official API docs.
