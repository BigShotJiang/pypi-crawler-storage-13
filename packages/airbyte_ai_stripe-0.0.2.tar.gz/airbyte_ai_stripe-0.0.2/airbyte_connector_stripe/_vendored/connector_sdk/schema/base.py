"""
Base OpenAPI 3.0 models: Info, Server, Contact, License.

References:
- https://spec.openapis.org/oas/v3.0.3#info-object
- https://spec.openapis.org/oas/v3.0.3#server-object
"""

from typing import Optional, Dict
from pydantic import BaseModel, Field, field_validator, ConfigDict


class Contact(BaseModel):
    """
    Contact information for the API.

    OpenAPI Reference: https://spec.openapis.org/oas/v3.0.3#contact-object
    """

    model_config = ConfigDict(populate_by_name=True, extra="forbid")

    name: Optional[str] = None
    url: Optional[str] = None
    email: Optional[str] = None


class License(BaseModel):
    """
    License information for the API.

    OpenAPI Reference: https://spec.openapis.org/oas/v3.0.3#license-object
    """

    model_config = ConfigDict(populate_by_name=True, extra="forbid")

    name: str
    url: Optional[str] = None


class Info(BaseModel):
    """
    API metadata information.

    OpenAPI Reference: https://spec.openapis.org/oas/v3.0.3#info-object

    Extensions:
    - x-airbyte-connector-name: Name of the connector (Airbyte extension)
    """

    model_config = ConfigDict(populate_by_name=True, extra="forbid")

    title: str
    version: str
    description: Optional[str] = None
    terms_of_service: Optional[str] = Field(None, alias="termsOfService")
    contact: Optional[Contact] = None
    license: Optional[License] = None

    # Airbyte extension
    x_airbyte_connector_name: Optional[str] = Field(
        None, alias="x-airbyte-connector-name"
    )


class ServerVariable(BaseModel):
    """
    Variable for server URL templating.

    OpenAPI Reference: https://spec.openapis.org/oas/v3.0.3#server-variable-object
    """

    model_config = ConfigDict(populate_by_name=True, extra="forbid")

    enum: Optional[list[str]] = None
    default: str
    description: Optional[str] = None


class Server(BaseModel):
    """
    Server URL and variable definitions.

    OpenAPI Reference: https://spec.openapis.org/oas/v3.0.3#server-object
    """

    model_config = ConfigDict(populate_by_name=True, extra="forbid")

    url: str
    description: Optional[str] = None
    variables: Dict[str, ServerVariable] = Field(default_factory=dict)

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        """Validate that server URL is properly formatted."""
        if not v:
            raise ValueError("Server URL cannot be empty")
        # Allow both absolute URLs and relative paths
        return v
