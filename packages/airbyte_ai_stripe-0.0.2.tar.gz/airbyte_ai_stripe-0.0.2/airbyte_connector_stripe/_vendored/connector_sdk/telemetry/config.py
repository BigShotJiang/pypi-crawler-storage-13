"""Telemetry configuration from environment variables."""

import os
from enum import Enum
from typing import Optional


class TelemetryMode(Enum):
    """Telemetry tracking modes."""

    BASIC = "basic"
    DETAILED = "detailed"
    DISABLED = "disabled"


class TelemetryConfig:
    """Telemetry configuration from environment variables."""

    @staticmethod
    def get_mode() -> TelemetryMode:
        """Get telemetry mode from environment variable."""
        mode_str = os.getenv("AIRBYTE_TELEMETRY_MODE", "basic").lower()
        try:
            return TelemetryMode(mode_str)
        except ValueError:
            return TelemetryMode.BASIC

    @staticmethod
    def get_write_key() -> Optional[str]:
        """
        Get Segment write key from environment variable.

        Returns:
            Write key string if set, None otherwise
        """
        return os.getenv("SEGMENT_WRITE_KEY")

    @staticmethod
    def is_enabled() -> bool:
        """Telemetry is enabled if mode is not disabled AND write key is set."""
        return (
            TelemetryConfig.get_mode() != TelemetryMode.DISABLED
            and TelemetryConfig.get_write_key() is not None
        )
