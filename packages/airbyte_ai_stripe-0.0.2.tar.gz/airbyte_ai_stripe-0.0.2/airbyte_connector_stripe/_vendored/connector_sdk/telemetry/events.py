"""Telemetry event models."""

from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Any, Dict, Optional


@dataclass
class BaseEvent:
    """Base class for all telemetry events."""

    timestamp: datetime
    anonymous_id: str
    execution_context: str

    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary with ISO formatted timestamp."""
        data = asdict(self)
        data["timestamp"] = self.timestamp.isoformat()
        return data


@dataclass
class ConnectorInitEvent(BaseEvent):
    """Connector initialization event."""

    connector_name: str
    connector_version: Optional[str]
    python_version: str
    os_name: str
    os_version: str


@dataclass
class OperationEvent(BaseEvent):
    """API operation event."""

    connector_name: str
    resource: str
    verb: str
    status_code: Optional[int]
    timing_ms: float
    error_type: Optional[str] = None
    error_message: Optional[str] = None
    params: Optional[Dict[str, Any]] = None


@dataclass
class SessionEndEvent(BaseEvent):
    """Session end event."""

    connector_name: str
    duration_seconds: float
    operation_count: int
    success_count: int
    failure_count: int
