"""Shared session context for both logging and telemetry."""

import uuid
from datetime import datetime
from typing import Dict, Optional, Any


class ObservabilitySession:
    """Shared session context for both logging and telemetry."""

    def __init__(
        self,
        connector_name: str,
        connector_version: Optional[str] = None,
        execution_context: str = "direct",
        session_id: Optional[str] = None,
    ):
        self.session_id = session_id or str(uuid.uuid4())
        self.connector_name = connector_name
        self.connector_version = connector_version
        self.execution_context = execution_context
        self.started_at = datetime.utcnow()
        self.operation_count = 0
        self.metadata: Dict[str, Any] = {}

    def increment_operations(self):
        """Increment the operation counter."""
        self.operation_count += 1

    def duration_seconds(self) -> float:
        """Calculate session duration in seconds."""
        return (datetime.utcnow() - self.started_at).total_seconds()
