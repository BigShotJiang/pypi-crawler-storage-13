"""Type definitions for request/response logging."""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class RequestLog(BaseModel):
    """Captures a single HTTP request/response interaction."""

    timestamp: datetime = Field(default_factory=datetime.utcnow)
    method: str
    url: str
    path: str
    headers: Dict[str, str] = Field(default_factory=dict)
    params: Optional[Dict[str, Any]] = None
    body: Optional[Any] = None
    response_status: Optional[int] = None
    response_body: Optional[Any] = None
    timing_ms: Optional[float] = None
    error: Optional[str] = None

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}


class LogSession(BaseModel):
    """Collection of request logs with session metadata.

    When max_logs is set, the session will maintain a bounded buffer of recent logs.
    Older logs should be flushed to disk before being discarded (handled by RequestLogger).
    """

    session_id: str
    started_at: datetime = Field(default_factory=datetime.utcnow)
    connector_name: Optional[str] = None
    logs: List[RequestLog] = Field(default_factory=list)
    max_logs: Optional[int] = Field(
        default=10000,
        description="Maximum number of logs to keep in memory. "
        "When limit is reached, oldest logs should be flushed before removal. "
        "Set to None for unlimited (not recommended for production).",
    )

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}
