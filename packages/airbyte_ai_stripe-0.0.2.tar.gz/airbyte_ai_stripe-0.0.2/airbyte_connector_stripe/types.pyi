"""
Auto-generated type definitions for stripe connector.

Generated from OpenAPI specification schemas.
"""

from typing import TypedDict, NotRequired, Any

# ===== RESPONSE TYPE DEFINITIONS =====

class Customer(TypedDict, total=False):
    """Customer type definition"""
    id: Any
    object: Any
    email: NotRequired[Any]
    name: NotRequired[Any]
    description: NotRequired[Any]
    phone: NotRequired[Any]
    address: NotRequired[Any]
    metadata: NotRequired[Any]
    created: NotRequired[Any]
    balance: NotRequired[Any]
    delinquent: NotRequired[Any]

class CustomerList(TypedDict, total=False):
    """CustomerList type definition"""
    object: NotRequired[Any]
    data: NotRequired[Any]
    has_more: NotRequired[Any]
    url: NotRequired[Any]

# ===== OPERATION PARAMS TYPE DEFINITIONS =====

class CustomersListParams(TypedDict, total=False):
    """Parameters for customers.list operation"""
    pass

class CustomersRetrieveParams(TypedDict, total=False):
    """Parameters for customers.retrieve operation"""
    id: str
