
{
    "version": "2025.11.21",
    "target": "default",
    "variant": "cpu"
}
