# MIDI Device Control

Generically control MIDI devices with other MIDI devices!

## DESCRIPTION

This package sports a single method: `control()` which allows MIDI control of a device with a controller, as defined in a `YAML` configuration file.

### Configuration YAML

The configuration file has four parts: The required MIDI `controller` and MIDI `device` to be controlled, an optional `description`, and a required list of `messages`. Each message can have differring keys depending on what is being controlled. These keys are as follows:

`type` (required) can either be `note_on`, `note_off`, `control_change`, `program_change`, or `pitchwheel`.

`cmd` (required) can be any of the above `type`s.

`note` is the MIDI note number (e.g. middle c = 60) that is sensed by the controller.

`control` is the MIDI CC# control change number that is sensed by the controller.

`target` (optional) is the MIDI CC# control change number that is changed on the controlled MIDI device.

`data` (optional) is the value to be changed given the above `target`.

One of `note` or `control` must be given for `note_on` or `control_change` types.

```yaml
controller: 'Arturia Keyboard'
device: 'Yamaha DX7'
description: 'MIDI control test!'
messages:
    - type: note_on # what type of message is sensed
        note: 60 # middle c does the controlling here
        cmd: control_change # the message type that is sent
        target: 14 # what parameter is to be controlled
    - type: control_change
        control: 1 # the modwheel does the controlling here
        cmd: control_change
        target: 15
        data: 64 # the value to set for CC# 15
    - type: pitchwheel
        cmd: control_change
        target: 16 # this CC changes with the pitchwheel
```

The `controller` and `device` must be on as MIDI ports. And these **must** be named exactly as they appear to the system.

Please see `mido.get_output_names()` and `mido.get_input_names()` for these known MIDI port names.

## Example:
```python
from midi_device_control import Controller
device_file = 'some-controller-some-device.yaml'
c = Controller(device_file=device_file)
c.control()
```