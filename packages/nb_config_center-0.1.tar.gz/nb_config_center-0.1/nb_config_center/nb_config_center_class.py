import threading
import weakref
import logging
import time
import json

logger = logging.getLogger(__name__)

class _RedisSubscriber:
    """
    Singleton/Multiton manager class for listening to Redis changes (reuses connections and threads)
    """
    _instances = {}
    _lock = threading.Lock()

    @classmethod
    def get_subscriber(cls, redis_client, channel_name):
        # Reuse listener thread based on client connection ID and channel name
        pool_id = id(redis_client.connection_pool) if hasattr(redis_client, 'connection_pool') else id(redis_client)
        key = (pool_id, channel_name)
        
        with cls._lock:
            if key not in cls._instances:
                cls._instances[key] = cls(redis_client, channel_name)
            return cls._instances[key]

    def __init__(self, redis_client, channel_name):
        self.redis_client = redis_client
        self.channel_name = channel_name
        self.pubsub = None
        self.observers = weakref.WeakSet()
        self.running = True
        self.thread = threading.Thread(target=self._listen_loop, daemon=True, name=f"RedisConfigSub-{channel_name}")
        self.thread.start()

    def _connect(self):
        try:
            if self.pubsub:
                self.pubsub.close()
            self.pubsub = self.redis_client.pubsub()
            self.pubsub.subscribe(self.channel_name)
            logger.info(f"NbConfigCenter: Subscribed to {self.channel_name}")
            return True
        except Exception as e:
            logger.error(f"NbConfigCenter: Subscribe failed: {e}")
            return False

    def _listen_loop(self):
        while self.running:
            if self.pubsub is None:
                if not self._connect():
                    time.sleep(2)
                    continue
            
            try:
                message = self.pubsub.get_message(ignore_subscribe_messages=True, timeout=1.0)
                if message and message['type'] == 'message':
                    data = message['data']
                    if isinstance(data, bytes):
                        data = data.decode('utf-8')
                    self._notify_observers(data)
            except Exception as e:
                # Ignore timeout errors, log other errors and retry
                if "Timeout" not in str(e):
                    logger.error(f"Redis subscriber error: {e}")
                    self.pubsub = None
                    time.sleep(1)

    def _notify_observers(self, namespace):
        for observer in list(self.observers):
            # Only trigger refresh when namespace matches
            if observer.namespace == namespace:
                observer._refresh_config_from_redis()

    def add_observer(self, observer):
        self.observers.add(observer)

def get_namespace_key(namespace):
    return f"nb_config_center:{namespace}"

class NbConfigCenter:
    def __init__(self, redis_client, namespace: str, channel_name="nb_config_update_bus"):
        """
        :param redis_client: Redis client object
        :param namespace: Configuration namespace (Redis Hash key)
        :param channel_name: Notification channel name, recommended to modify when multiple projects share Redis
        """
        self.redis = redis_client
        self.namespace = namespace
        self.namespace_key = get_namespace_key(namespace)
        self.old_config = {}
        self.config = {}
        self.callbacks = []
        
        # Start or reuse listener thread
        self.subscriber = _RedisSubscriber.get_subscriber(redis_client, channel_name)
        self.subscriber.add_observer(self)
        
        # Initial load
        self._is_first_load = True
        self._refresh_config_from_redis()

    def add_update_callback(self, func):
        """
        Register a callback function to be executed after configuration changes.
        The callback function will receive the current self.config dictionary as a parameter.
        """
        self.callbacks.append(func)
        return func
    
    def get(self, key: str):
        return self.config[key]

    def update_config(self, config: dict):
        """
        Update configuration to Redis.
        All values are processed through json.dumps to preserve type information (int, bool, dict, list, str).
        """
        if not config:
            return
        
        # 1. Serialize all values to ensure type safety
        data_to_store = {}
        for k, v in config.items():
            # ensure_ascii=False ensures Chinese characters are readable, separators compress whitespace
            data_to_store[k] = json.dumps(v, ensure_ascii=False)
        
        # 2. Atomic operation: write to Hash and publish notification
        pipe = self.redis.pipeline()
        pipe.hset(self.namespace_key, mapping=data_to_store)
        pipe.publish(self.subscriber.channel_name, self.namespace)
        pipe.execute()
        
        # 3. Immediately refresh local configuration
        self._refresh_config_from_redis()

    def _refresh_config_from_redis(self):
        """
        Pull the latest configuration from Redis.
        """
        try:
            # Get all data (returns bytes type keys and values)
            raw_data = self.redis.hgetall(self.namespace_key)
            decoded_config = {}
            
            for k_bytes, v_bytes in raw_data.items():
                # 1. Decode Key
                key_str = k_bytes.decode('utf-8') if isinstance(k_bytes, bytes) else str(k_bytes)
                
                # 2. Decode Value string
                val_str = v_bytes.decode('utf-8') if isinstance(v_bytes, bytes) else str(v_bytes)
                
                # 3. Attempt JSON deserialization to restore type
                try:
                    val = json.loads(val_str)
                except (json.JSONDecodeError, TypeError):
                    # Only when the value in Redis is not valid JSON (e.g., manually entered plain string),
                    # we keep the original string.
                    # Note: If the original stored value is the string "hello", after json.dumps it becomes '"hello"',
                    # and json.loads can correctly extract "hello".
                    logger.warning(f"Failed to json.loads value for key {key_str}: {val_str}")
                    val = val_str
                
                decoded_config[key_str] = val

            if decoded_config == self.config:
                return

            if self._is_first_load:
                self._is_first_load = False
                self.old_config = decoded_config
                self.config = decoded_config
                logger.info(f"NbConfigCenter initialized. Namespace: {self.namespace}")
                return  # Suggestion: Return directly on first load without triggering callbacks
            else:
                self.old_config = self.config
                self.config = decoded_config
            logger.info(f"Config reloaded for {self.namespace}. Keys: {list(self.config.keys())}")
            

            # 4. Execute callbacks
            for func in self.callbacks:
                try:
                    func(old_config=self.old_config,new_config=decoded_config)
                except Exception as e:
                    logger.error(f"Callback error in {func}: {e}")

            
                    
        except Exception as e:
            logger.error(f"Failed to refresh config from redis: {e}")