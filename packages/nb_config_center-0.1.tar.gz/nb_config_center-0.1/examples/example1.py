
import redis
from nb_config_center import NbConfigCenter
import time

r = redis.StrictRedis(host='localhost', port=6379, db=0, socket_timeout=1,decode_responses=True)
namespace = "test_config_ns5"
# Clean up previous run
# r.delete(namespace)

# 1. Instantiate first center
center1 = NbConfigCenter(r, namespace)
print(f"Center1 initial config: {center1.config}")


# 2. Update config via center1
center1.update_config({"key_str": "value1", "key_int": 222})


center2 = NbConfigCenter(r, namespace)

@center2.add_update_callback
def callback(old_config,new_config):
    print(f"Callback received new config: {new_config},old config is: {old_config}")

while True:
    time.sleep(10)
    print(f"Center2 initial config: {center2.config}")
    print(center2.get("key_int"))


