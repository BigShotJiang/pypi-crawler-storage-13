import redis
import time
from nb_config_center import NbConfigCenter
import json
import nb_log

nb_log.get_logger("nb_config_center.nb_config_center_class")


r = redis.StrictRedis(
    host="localhost", port=6379, db=0, socket_timeout=1, decode_responses=True
)
namespace = "test_config_ns5"


center3 = NbConfigCenter(r, namespace)

center3.update_config(
    {
        "key_str": "valuef2b",
        "key_int": 1123,
        "key_dict": {"c": 1, "d": 22},
        "key_float": 123.456,
        "key_bool": True,
    }
)

# time.sleep(1)
print(center3.config)
