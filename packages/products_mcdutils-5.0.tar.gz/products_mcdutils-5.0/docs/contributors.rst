.. include:: ../CONTRIBUTORS.txt
