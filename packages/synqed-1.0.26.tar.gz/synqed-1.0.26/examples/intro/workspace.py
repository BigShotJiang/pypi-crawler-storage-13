"""
Workspace Example - Two agents collaborating in real-time

This shows how to:
1. Create two AI agents with different specialties
2. Add them to a shared workspace
3. Watch them communicate and collaborate in real-time

The agents work together on a task, and you can see their messages
as they discuss and solve the problem.

Setup:
1. Install: pip install synqed anthropic python-dotenv
2. Create .env file with: ANTHROPIC_API_KEY='your-key-here'
3. Run: python workspace.py
"""
import synqed
import asyncio
import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
load_dotenv(dotenv_path=Path(__file__).parent / '.env')

# Create agent logic functions
async def writer_logic(context):
    """A creative writer agent."""
    from anthropic import AsyncAnthropic
    
    client = AsyncAnthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))
    user_message = context.get_user_input()
    
    response = await client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=500,
        system="You are a creative writer. Focus on storytelling, character development, and engaging narratives.",
        messages=[{"role": "user", "content": user_message}]
    )
    
    return response.content[0].text


async def editor_logic(context):
    """An editor agent that reviews and improves content."""
    from anthropic import AsyncAnthropic
    
    client = AsyncAnthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))
    user_message = context.get_user_input()
    
    response = await client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=500,
        system="You are a professional editor. Focus on improving clarity, grammar, and overall quality of writing.",
        messages=[{"role": "user", "content": user_message}]
    )
    
    return response.content[0].text


async def main():
    print("\n" + "="*80)
    print("  WORKSPACE COLLABORATION DEMO")
    print("  Two agents working together in real-time")
    print("="*80 + "\n")
    
    # Step 1: Create the agents
    print("📝 Creating agents...\n")
    
    writer = synqed.Agent(
        name="Creative Writer",
        description="A creative writer specializing in storytelling and narrative",
        skills=["creative_writing", "storytelling", "character_development"],
        executor=writer_logic
    )
    
    editor = synqed.Agent(
        name="Professional Editor",
        description="An editor who reviews and improves written content",
        skills=["editing", "proofreading", "content_improvement"],
        executor=editor_logic
    )
    
    print(f"✓ Created agent: {writer.name}")
    print(f"✓ Created agent: {editor.name}\n")
    
    # Step 2: Create a workspace with real-time message display
    print("🏗️  Creating workspace...\n")
    
    workspace = synqed.Workspace(
        name="Story Development",
        description="A collaborative space for writing and editing stories",
        display_messages=True  # Enable real-time colored message display!
    )
    
    print(f"✓ Workspace created: {workspace.name}")
    print(f"✓ Real-time message display enabled\n")
    
    # Step 3: Add agents to the workspace
    print("👥 Adding agents to workspace...\n")
    
    # Start agent servers
    writer_server = synqed.AgentServer(writer, port=8001)
    editor_server = synqed.AgentServer(editor, port=8002)
    
    # Start servers in background
    await asyncio.gather(
        writer_server.start_async(),
        editor_server.start_async()
    )
    
    # Give servers a moment to start
    await asyncio.sleep(1)
    
    # Add agents to workspace
    workspace.add_agent(writer)
    workspace.add_agent(editor)
    
    print(f"✓ Added {len(workspace.list_participants())} agents to workspace\n")
    
    # Step 4: Start the workspace
    print("🚀 Starting workspace...\n")
    await workspace.start()
    
    print("="*80)
    print("  AGENTS ARE NOW COLLABORATING")
    print("="*80 + "\n")
    
    # Step 5: Give the agents a collaborative task
    task = """Create a short story opening (2-3 sentences) about a robot learning to paint.
    
Writer: Create the opening.
Editor: Review it and suggest one improvement."""
    
    print(f"📋 Task:\n{task}\n")
    print("="*80)
    print("  WATCHING AGENTS COMMUNICATE IN REAL-TIME")
    print("="*80 + "\n")
    
    # Execute the collaborative task - messages will appear in real-time!
    results = await workspace.collaborate(task, timeout=60.0)
    
    # Step 6: Display results
    print("\n" + "="*80)
    print("  COLLABORATION COMPLETE")
    print("="*80 + "\n")
    
    for agent_name, result in results.items():
        if agent_name != "error":
            print(f"📝 Final Result - {agent_name}:")
            print(f"   {result}\n")
    
    # Step 7: View artifacts
    artifacts = workspace.get_artifacts()
    print(f"📦 Generated {len(artifacts)} artifact(s)")
    
    # Step 8: View message history
    messages = workspace.get_messages()
    print(f"💬 Total messages exchanged: {len(messages)}\n")
    
    # Clean up
    print("🧹 Cleaning up...")
    await workspace.close()
    
    # Stop servers
    writer_server.stop()
    editor_server.stop()
    
    print("✓ Workspace closed\n")
    
    print("="*80)
    print("  DEMO COMPLETE")
    print("="*80 + "\n")


if __name__ == "__main__":
    asyncio.run(main())

