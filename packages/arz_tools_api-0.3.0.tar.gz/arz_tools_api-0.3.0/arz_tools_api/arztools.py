import requests
import logging
import threading
from typing import Dict, Any, List, Optional, Union
from bs4 import BeautifulSoup
import time
from functools import wraps

class ArzToolsAPI:
    def __init__(
        self,
        phpsessid_leaders: str = None,
        phpsessid_admins: str = None,
        base_url: str = None,
        timeout: int = 30,
        max_retries: int = 3,
        cache_ttl: int = 300,
        proxy: str = None,
        verify_ssl: bool = True,
        log_level: int = logging.WARNING
    ):
        self.admins = self.Admins(self)
        self.leaders = self.Leaders(self)

        self.phpsessid_leaders = phpsessid_leaders
        self.phpsessid_admins = phpsessid_admins

        self.timeout = timeout
        self.max_retries = max_retries
        self.cache_ttl = cache_ttl
        self.proxy = proxy
        self.verify_ssl = verify_ssl
        self.log_level = log_level

        self.api_configs = {}
        self._connected = False

        admin_base_url = base_url if base_url else "https://admin.arztools.tech/api/"
        self.api_configs['admin'] = {
            'base_url': admin_base_url,
            'headers': {
                "referer": "https://admin.arztools.tech/index.php",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 YaBrowser/25.2.0.0 Safari/537.36"
            },
            'cookies': {"PHPSESSID": self.phpsessid_admins} if self.phpsessid_admins else {}
        }

        leader_base_url = "https://lead.arztools.tech/"
        self.api_configs['leader'] = {
            'base_url': leader_base_url,
            'headers': {
                "referer": "https://lead.arztools.tech/index.php",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 YaBrowser/25.2.0.0 Safari/537.36"
            },
            'cookies': {"PHPSESSID": self.phpsessid_leaders} if self.phpsessid_leaders else {}
        }

    def connect(self):
        """
        Устанавливает соединение и запускает фоновый процесс поддержания активности сессии.
        """
        if not self._connected:
            self._connected = True
            thread = threading.Thread(target=self._keep_alive, daemon=True)
            thread.start()

    def _keep_alive(self):
        """
        Периодически отправляет запросы для поддержания активности сессии.
        Выполняется каждый час только если установлено соединение.
        """
        import time
        while self._connected:
            try:
                if self.phpsessid_admins:
                    try:
                        self._make_request("user/adminlist.php", api_type='admin')
                    except Exception as e:
                        if self.log_level <= logging.ERROR:
                            logging.error(f"Keep-alive для admins не удался: {e}")
                if self.phpsessid_leaders:
                    try:
                        self._make_request("load/leaders.php", params={"sphere": "ME", "rank": "ALL"}, api_type='leader')
                    except Exception as e:
                        if self.log_level <= logging.ERROR:
                            logging.error(f"Keep-alive для leaders не удался: {e}")
            except Exception as e:
                if self.log_level <= logging.ERROR:
                    logging.error(f"Ошибка в keep-alive: {e}")
            time.sleep(360)

    def _make_request(
        self,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        api_type: str = 'admin',
        method: str = 'GET',
        data: Optional[Dict[str, Any]] = None,
        json: Optional[Union[Dict[str, Any], List[Any]]] = None,
        files: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> requests.Response:
        """
        Внутренний метод для выполнения HTTP-запроса к API.
        """
        if api_type not in self.api_configs:
            raise ValueError(f"Неизвестный тип API: {api_type}. Доступные типы: {list(self.api_configs.keys())}")

        config = self.api_configs[api_type]
        url = config['base_url'] + endpoint

        base_headers = config.get('headers', {}).copy()
        if headers:
            base_headers.update(headers)

        cookies = config.get('cookies', {}).copy()

        proxies = None
        if self.proxy:
            proxies = {'http': self.proxy, 'https': self.proxy}

        attempt = 0
        method_upper = (method or 'GET').upper()

        allowed_methods = {'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'}
        if method_upper not in allowed_methods:
            raise ValueError(f"Недопустимый HTTP-метод: {method}. Разрешено: {sorted(list(allowed_methods))}")

        while attempt < self.max_retries:
            try:
                # ⭐⭐⭐ ДОБАВЬТЕ ЭТУ ЗАДЕРЖКУ ⭐⭐⭐
                time.sleep(3)  # 5 секунд задержка перед КАЖДЫМ запросом
                
                if self.log_level <= logging.INFO:
                    logging.info(
                        f"HTTP {method_upper} {url} | params={params} data={bool(data)} json={bool(json)} files={bool(files)}"
                    )

                response = requests.request(
                    method=method_upper,
                    url=url,
                    headers=base_headers,
                    cookies=cookies,
                    params=params,
                    data=data,
                    json=json,
                    files=files,
                    timeout=self.timeout,
                    proxies=proxies,
                    verify=self.verify_ssl
                )

                response.raise_for_status()
                return response

            except requests.exceptions.Timeout:
                attempt += 1
                if self.log_level <= logging.WARNING:
                    logging.warning(f"Request timed out (attempt {attempt}/{self.max_retries}). Retrying...")
                if attempt >= self.max_retries:
                    raise Exception(f"Request timed out after {self.max_retries} attempts.")
            except requests.exceptions.RequestException as e:
                attempt += 1
                if self.log_level <= logging.WARNING:
                    logging.warning(f"Request failed (attempt {attempt}/{self.max_retries}): {e}. Retrying...")
                if attempt >= self.max_retries:
                    raise Exception(f"Request failed after {self.max_retries} attempts: {e}")

        raise Exception("An unexpected error occurred during request.")

    class Admins:
        def __init__(self, outer):
            self.outer = outer

        def get_admin_list(self) -> Dict[str, Any]:
            """
            Получает список администраторов через API.
            :return: Словарь с данными о списке администраторов.
            :raises Exception: Если запрос завершился неудачно или API вернул ошибку.
            """
            response = self.outer._make_request("user/adminlist.php", method="GET", api_type='admin')
            data = response.json()
            if data.get("error") == True:
                raise Exception(data.get("message", "Неизвестная ошибка"))
            elif data.get("message") != "Успех!":
                raise Exception(data.get("message", "Неизвестная ошибка"))
            return data.get("admins")

        def get_admin(self, vkid: int) -> Dict[str, Any]:
            """
            Получает информацию об администраторе через API.
            :param vkid: ID ВКонтакте администратора
            :return: Словарь с данными о администраторе (как в message).
            :raises Exception: Если запрос завершился неудачно или API вернул ошибку.
            """
            data = {"vkid": int(vkid)}
            response = self.outer._make_request("user/getInfo.php", method="POST", data=data, api_type='admin')
            try:
                data = response.json()
            except Exception as e:
                raise Exception(f"Некорректный JSON от API: {e}")
            if not isinstance(data, dict):
                raise Exception("Некорректный формат ответа API (ожидался объект)")
            if data.get("error") is True:
                msg = data.get("message")
                if isinstance(msg, str):
                    raise Exception(msg or "Неизвестная ошибка")
                raise Exception("API вернул ошибку")
            message = data.get("message")
            if not isinstance(message, dict):
                raise Exception("Отсутствует или некорректное поле 'message' в ответе API")
            return message

        def get_detailed_online(self, nick: str, week: str) -> Dict[str, Any]:
            """
            Получает детализированную информацию об онлайне для указанного администратора и недели.
            :param nick: Никнейм администратора.
            :param week: Неделя для получения данных (например, 'previous' или 'current').
            :return: Словарь с детализированной информацией об онлайне.
            :raises Exception: Если запрос завершился неудачно или API вернул ошибку.
            """
            params = {"nick": nick, "week": week}
            response = self.outer._make_request("onlines/detailed.php", method="GET", params=params, api_type='admin')
            data = response.json()
            if "error" in data and data["error"]:
                raise Exception(data.get("message", "Неизвестная ошибка"))
            elif "code" in data and data["code"] != 200:
                raise Exception(data.get("data", {}).get("answer", "Неизвестная ошибка"))
            return data

        def get_online(self) -> Dict[str, Any]:
            """
            Получает общую информацию об онлайне всех администраторов.
            :return: Словарь с данными об онлайне.
            :raises Exception: Если запрос завершился неудачно или API вернул ошибку.
            """
            response = self.outer._make_request("onlines/get.php", method="GET", api_type='admin')
            data = response.json()
            if "error" in data and data["error"]:
                raise Exception(data.get("message", "Неизвестная ошибка"))
            elif "code" in data and data["code"] != 200:
                raise Exception(data.get("data", {}).get("answer", "Неизвестная ошибка"))
            return data

    class Leaders:
        def __init__(self, outer):
            self.outer = outer

        def get_leaders(self) -> List[Dict[str, Optional[str]]]:
            """
            Получает список лидеров с сайта lead.arztools.tech.
            """
            params = {"sphere": "ME", "rank": "ALL"}
            response = self.outer._make_request("load/leaders.php", params=params, api_type='leader')
            soup = BeautifulSoup(response.text, 'html.parser')

            leaders: List[Dict[str, Optional[str]]] = []
            
            rows = soup.select('table#filterTable tbody tr.new-table-leader-block')
            
            for row in rows:
                rank_elem = row.select_one('th')
                rank = rank_elem.get_text(strip=True) if rank_elem else ""
                
                tds = row.select('td')
                if len(tds) < 7:
                    continue
                    
                name_link = tds[0].select_one('a.leader-name-in-list')
                name = ""
                position = ""
                leader_record_id = None
                user_id = None
                
                if name_link:
                    name_div = name_link.select_one('div')
                    name = name_div.get_text(strip=True) if name_div else ""
                    
                    pos_span = name_link.select_one('span.fs-7')
                    position = pos_span.get_text(strip=True) if pos_span else ""
                    
                    href = name_link.get('href', '')
                    if 'id=' in href:
                        try:
                            leader_record_id = int(href.split('id=')[1].split('&')[0].strip())
                            # ПОЛУЧАЕМ ID ПОЛЬЗОВАТЕЛЯ ИЗ СТРАНИЦЫ ЛИДЕРА
                            user_id = self._get_user_id_from_leader_page(leader_record_id)
                        except (IndexError, ValueError):
                            leader_record_id = None
                
                appointed_date = tds[1].get_text(strip=True)
                days = tds[2].get_text(strip=True)
                points = tds[3].get_text(strip=True)
                reprimands = tds[4].get_text(strip=True)
                warnings = tds[5].get_text(strip=True)
                online = tds[6].get_text(strip=True)
                
                leaders.append({
                    'id': user_id,  # Теперь это ID пользователя
                    'leader_record_id': leader_record_id,  # ID записи лидера (из checklead.php)
                    'rank': rank,
                    'name': name,
                    'position': position,
                    'appointed_date': appointed_date,
                    'days': days,
                    'points': points,
                    'reprimands': reprimands,
                    'warnings': warnings,
                    'online': online,
                })
            
            return leaders

        def _get_user_id_from_leader_page(self, leader_record_id: int) -> Optional[int]:
            """
            Получает ID пользователя из страницы лидера (checklead.php).
            Ищет ссылку на profile.php в никнейме лидера.
            """
            try:
                # Получаем страницу лидера
                params = {"id": leader_record_id}
                response = self.outer._make_request("load/checklead.php", params=params, api_type='leader')
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Ищем ссылку на профиль в никнейме лидера
                profile_link = soup.select_one('a.new-leader-nick[href*="profile.php"]')
                if profile_link:
                    href = profile_link.get('href', '')
                    # Извлекаем ID из ссылки profile.php?id=XXXX
                    import re
                    id_match = re.search(r'profile\.php\?id=(\d+)', href)
                    if id_match:
                        return int(id_match.group(1))
                
                # Альтернативный поиск - ищем любую ссылку на profile.php
                all_profile_links = soup.find_all('a', href=lambda x: x and 'profile.php?id=' in x)
                for link in all_profile_links:
                    href = link.get('href', '')
                    id_match = re.search(r'profile\.php\?id=(\d+)', href)
                    if id_match:
                        return int(id_match.group(1))
                        
                return None
                
            except Exception as e:
                logging.warning(f"Не удалось получить ID пользователя для лидера {leader_record_id}: {e}")
                return None

        def get_admins(self) -> List[Dict[str, Any]]:
            """
            Получает список администраторов Leaders.
            """
            response = self.outer._make_request("load/admins.php", api_type='leader')
            soup = BeautifulSoup(response.text, 'html.parser')
            
            admins = []
            
            
            rows = soup.select('table#filterTable tbody tr.table-leader-block')
            
            for row in rows:
                
                th = row.select_one('th')
                tds = row.select('td')
                
                if not th or len(tds) < 4:  
                    continue
                
                
                number = th.get_text(strip=True)
                
                
                nick_link = tds[1].select_one('a')
                nick = tds[1].get_text(strip=True)
                leader_id = None
                
                if nick_link:
                    href = nick_link.get('href', '')
                    if 'id=' in href:
                        try:
                            leader_id = int(href.split('id=')[1])
                        except (IndexError, ValueError):
                            leader_id = None
                
                
                position = tds[2].get_text(strip=True)
                
                
                sphere = tds[3].get_text(strip=True)
                
                admins.append({
                    'id': leader_id,
                    'nick': nick,
                    'position': position,
                    'sphere': sphere
                })
            
            return admins

        def get_random_situations(self) -> dict:
            """
            Получает случайные ситуации, топ победителей и администраторов.
            """
            params = {}
            response = self.outer._make_request("load/situactions.php", params=params, api_type='leader')
            soup = BeautifulSoup(response.text, 'html.parser')
            
            result = {
                'top_winners': [],
                'top_admins': [],
                'last_situations': []
            }
            
            
            winners_card = soup.select_one('.row.new-grp-charts .col-md-6:first-child .card-body')
            if winners_card:
                for item in winners_card.select('.mb-3'):
                    org_name = item.select_one('span:first-child').get_text(strip=True)
                    wins = item.select_one('span:last-child').get_text(strip=True)
                    result['top_winners'].append({'organization': org_name, 'wins': wins})
            
            
            admins_card = soup.select_one('.row.new-grp-charts .col-md-6:last-child .card-body')
            if admins_card:
                for item in admins_card.select('.mb-3'):
                    admin_name = item.select_one('span:first-child').get_text(strip=True)
                    points = item.select_one('span:last-child').get_text(strip=True)
                    result['top_admins'].append({'admin': admin_name, 'points': points})
            
            
            situations = soup.select('.new-grp-item')
            for situation in situations:
                date = situation.select_one('h4').get_text(strip=True)
                badges = []
                for badge in situation.select('.new-grp-position-badge'):
                    position = badge.select_one('.new-grp-position-number').get_text(strip=True)
                    org_name = badge.get_text(strip=True).replace(position, '').strip()
                    badges.append({'position': position, 'organization': org_name})
                
                points = situation.select_one('.new-grp-winners-badge').get_text(strip=True)
                result['last_situations'].append({
                    'date': date,
                    'positions': badges,
                    'total_points': points
                })
            
            return result

        def get_leader_archive(self, page: int = 1, nick: str = "", fraction: str = "") -> List[Dict[str, str]]:
            """
            Получает архив лидеров.
            """
            params = {"page": page, "nick": nick, "fraction": fraction}
            response = self.outer._make_request("load/archive.php", params=params, api_type='leader')
            soup = BeautifulSoup(response.text, 'html.parser')
            
            leaders = []
            cards = soup.select('.card.mb-3')
            
            for card in cards:
                card_body = card.select_one('.card-body')
                if not card_body:
                    continue
                
                
                name_block = card_body.select_one('.d-flex.justify-content-between.mb-1.flex-wrap')
                name_element = name_block.select_one('p.mb-1:first-child') if name_block else None
                position_element = name_block.select_one('p.mb-1:last-child') if name_block else None
                
                name = name_element.get_text(strip=True) if name_element else ""
                position = position_element.get_text(strip=True) if position_element else ""
                
                
                stats_element = card_body.select_one('p.mb-1:nth-of-type(2)')
                stats = stats_element.get_text(strip=True) if stats_element else ""
                
                
                dates_block = card_body.select_one('.d-flex.justify-content-between')
                start_element = dates_block.select_one('p.mb-0:first-child') if dates_block else None
                end_element = dates_block.select_one('p.mb-0.text-end') if dates_block else None
                
                start_info = start_element.get_text(strip=True) if start_element else ""
                end_info = end_element.get_text(strip=True) if end_element else ""
                
                leaders.append({
                    'name': name,
                    'position': position,
                    'stats': stats,
                    'start_info': start_info,
                    'end_info': end_info
                })
            
            return leaders

        def get_leader_details(self, leader_id: int) -> dict:
            """
            Получает детальную информацию о лидере по ID, включая все логи.
            """
            params = {"id": int(leader_id)}
            response = self.outer._make_request("load/checklead.php", params=params, api_type='leader')
            soup = BeautifulSoup(response.text, 'html.parser')
            
            result = {}
            
            # Основная информация
            name_el = soup.select_one('a.new-leader-nick')
            if name_el:
                result['name'] = name_el.get_text(strip=True)
                # Ищем ID пользователя в ссылке на профиль
                href = name_el.get('href', '')
                import re
                id_match = re.search(r'profile\.php\?id=(\d+)', href)
                if id_match:
                    result['user_id'] = int(id_match.group(1))
            
            
            text_muted_elements = soup.select('p.text-muted')
            if len(text_muted_elements) >= 2:
                result['position'] = text_muted_elements[0].get_text(strip=True)
                result['organization'] = text_muted_elements[1].get_text(strip=True)
            
            
            stat_badges = soup.select('.new-leader-stat-badge')
            
            
            if len(stat_badges) > 0:
                points_el = stat_badges[0].select_one('.text-accent')
                if points_el:
                    result['points'] = points_el.get_text(strip=True)
            
            
            if len(stat_badges) > 1:
                days_el = stat_badges[1].select_one('.text-accent span')
                if days_el:
                    result['days'] = days_el.get_text(strip=True)
                
                
                tooltip = stat_badges[1].get('data-bs-title')
                if tooltip:
                    result['appointment_date'] = tooltip
            
            
            labels = soup.select('label.text-muted')
            for label in labels:
                label_text = label.get_text(strip=True)
                next_element = label.find_next_sibling()
                
                if 'Онлайн за' in label_text and next_element:
                    result['online_time'] = next_element.get_text(strip=True)
                elif 'КПД' in label_text and next_element:
                    result['kpd'] = next_element.get_text(strip=True)
                elif 'Выговоры' in label_text and next_element:
                    result['reprimands'] = next_element.get_text(strip=True)
                elif 'Предупреждения' in label_text and next_element:
                    result['warnings'] = next_element.get_text(strip=True)
            
            
            result['logs'] = {}
            
            
            result['logs']['leader_changes'] = self._parse_leader_logs(soup, '#changeLeader')
            
            
            result['logs']['organization'] = self._parse_leader_logs(soup, '#orgLogs')
            
            
            result['logs']['money'] = self._parse_leader_logs(soup, '#moneyLogs')
            
            
            result['logs']['administration'] = self._parse_leader_logs(soup, '#admLogs')
            
            
            result['logs']['login'] = self._parse_leader_logs(soup, '#loginLogs')
            
            return result

        def _parse_leader_logs(self, soup, tab_selector: str) -> list:
            """
            Парсит логи из указанной вкладки.
            """
            logs = []
            tab_content = soup.select_one(tab_selector)
            
            if not tab_content:
                return logs
            
            
            empty_message = tab_content.select_one('.profile-empty')
            if empty_message:
                return logs  
            
            
            log_items = tab_content.select('.new-leader-log-item')
            
            for item in log_items:
                log_entry = {}
                
                
                action_span = item.select_one('.d-flex.justify-content-between span')
                if action_span:
                    log_entry['action'] = action_span.get_text(strip=True)
                
                
                date_info = item.select_one('.text-muted.small')
                if date_info:
                    date_text = date_info.get_text(strip=True)
                    
                    parts = date_text.split(' | ')
                    if len(parts) == 2:
                        log_entry['log_id'] = parts[0].strip()
                        log_entry['datetime'] = parts[1].strip()
                    else:
                        log_entry['raw_date'] = date_text
                
                logs.append(log_entry)
            
            return logs

        def get_usr(self, user_id: int) -> dict:
            """
            Получает информацию о пользователе по ID, включая ссылку на VK.
            """
            params = {"id": user_id}
            response = self.outer._make_request("load/profile.php", params=params, api_type='leader')
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Ищем основной контент профиля
            user_content = soup.select_one('.user-content')
            if not user_content:
                raise Exception("Пользователь не найден")
            
            result = {}
            
            # Аватар
            avatar_block = user_content.select_one('.profile-avatar-block img.profile-avatar')
            if avatar_block:
                result['avatar'] = avatar_block.get('src', '')
            
            # Никнейм
            nickname_el = user_content.select_one('.user-content h5.my-1')
            if nickname_el:
                result['nickname'] = nickname_el.get_text(strip=True)
            
            # Должность
            position_el = user_content.find('i', {'data-bs-title': 'Роль'})
            if position_el and position_el.parent:
                position_text = position_el.parent.get_text(strip=True)
                result['current_position'] = position_text
            
            # Руководящие должности
            leader_positions_el = user_content.find('i', {'data-bs-title': 'Руководящие должности'})
            if leader_positions_el and leader_positions_el.parent:
                span_el = leader_positions_el.parent.select_one('span[data-bs-title]')
                if span_el:
                    leader_positions_text = span_el.get_text(strip=True)
                    result['leader_positions'] = leader_positions_text
            
            # Сервер
            server_el = user_content.find('i', {'data-bs-title': 'Сервер'})
            if server_el and server_el.parent:
                server_text = server_el.parent.get_text(strip=True)
                result['server'] = server_text
            
            # ID
            id_el = user_content.find('i', {'data-bs-title': 'ID'})
            if id_el and id_el.parent:
                id_text = id_el.parent.get_text(strip=True)
                try:
                    import re
                    id_match = re.search(r'ID:\s*(\d+)', id_text)
                    if id_match:
                        extracted_id = int(id_match.group(1))
                        result['id'] = extracted_id
                    else:
                        result['id'] = user_id
                except (ValueError, AttributeError):
                    result['id'] = user_id
            else:
                result['id'] = user_id
            
            # Роль
            role_el = user_content.select_one('.user-content .role-base')
            if role_el:
                result['role'] = role_el.get_text(strip=True)
            
            # Дата регистрации
            reg_el = user_content.find('i', {'data-bs-title': 'Регистрация'})
            if reg_el and reg_el.parent:
                reg_text = reg_el.parent.get_text(strip=True)
                result['registration_date'] = reg_text
            
            # ПОИСК VK ССЫЛКИ - ИСПРАВЛЕННАЯ ВЕРСИЯ
            result['vk_link'] = None
            result['vk_id'] = None
            
            # Ищем ВСЕ кнопки в профиле (не только в user-content)
            all_buttons = soup.find_all('a', class_='btn')
            for button in all_buttons:
                href = button.get('href', '')
                text = button.get_text(strip=True)
                
                # Ищем VK по тексту кнопки или по ссылке
                if 'vk.ru' in href or 'vk.com' in href or 'vkontakte.ru' in href or text.upper() == 'VK':
                    result['vk_link'] = href
                    break
            
            # Если не нашли в кнопках, ищем любую ссылку с vk
            if not result['vk_link']:
                all_links = soup.find_all('a', href=True)
                for link in all_links:
                    href = link.get('href', '')
                    if any(vk_domain in href for vk_domain in ['vk.ru', 'vk.com', 'vkontakte.ru']):
                        result['vk_link'] = href
                        break
            
            # Извлекаем VK ID если нашли ссылку
            if result['vk_link']:
                import re
                vk_id_match = re.search(r'(?:vk\.ru|vk\.com|vkontakte\.ru)/?(?:id|club)?(\d+)', result['vk_link'])
                if vk_id_match:
                    result['vk_id'] = int(vk_id_match.group(1))
            
            return result
        
        def debug_get_usr(self, user_id: int) -> dict:
            """
            Дебаг версия для поиска VK ссылок
            """
            params = {"id": user_id}
            response = self.outer._make_request("load/profile.php", params=params, api_type='leader')
            
            # Сохраняем HTML для анализа
            debug_filename = f"debug_profile_{user_id}.html"
            with open(debug_filename, 'w', encoding='utf-8') as f:
                f.write(response.text)
            print(f"✅ HTML сохранен в {debug_filename}")
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Ищем ВСЕ ссылки
            all_links = soup.find_all('a', href=True)
            print(f"🔍 Найдено ссылок: {len(all_links)}")
            
            for i, link in enumerate(all_links):
                href = link.get('href', '')
                text = link.get_text(strip=True)
                print(f"{i+1}. {href} | текст: '{text}'")
            
            # Специально ищем кнопки с VK
            vk_buttons = soup.find_all('a', class_=lambda x: x and 'btn' in x)
            print(f"🔍 Кнопок: {len(vk_buttons)}")
            
            for btn in vk_buttons:
                href = btn.get('href', '')
                text = btn.get_text(strip=True)
                classes = btn.get('class', [])
                print(f"Кнопка: {href} | текст: '{text}' | классы: {classes}")
            
            return {"debug": "done"}