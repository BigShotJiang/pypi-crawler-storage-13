"""
Enhanced error message sanitization
"""

import re
from typing import Any, Dict

# Comprehensive sensitive patterns
SENSITIVE_PATTERNS = [
    # Credentials
    (r'password["\']?\s*[:=]\s*["\']?[^"\'\s]+', 'password=***'),
    (r'secret["\']?\s*[:=]\s*["\']?[^"\'\s]+', 'secret=***'),
    (r'token["\']?\s*[:=]\s*["\']?[^"\'\s]+', 'token=***'),
    (r'key["\']?\s*[:=]\s*["\']?[^"\'\s]+', 'key=***'),
    (r'api[_-]?key["\']?\s*[:=]\s*["\']?[^"\'\s]+', 'api_key=***'),
    
    # Connection strings
    (r'postgresql://[^:\s]+:[^@\s]+@[^/\s]+', 'postgresql://***:***@***'),
    (r'mysql://[^:\s]+:[^@\s]+@[^/\s]+', 'mysql://***:***@***'),
    (r'redis://[^:\s]+:[^@\s]+@[^/\s]+', 'redis://***:***@***'),
    (r'mongodb://[^:\s]+:[^@\s]+@[^/\s]+', 'mongodb://***:***@***'),
    
    # Auth headers
    (r'Bearer\s+[A-Za-z0-9\-_.]+', 'Bearer ***'),
    (r'Authorization:\s*[^\s]+', 'Authorization: ***'),
    (r'X-API-Key:\s*[^\s]+', 'X-API-Key: ***'),
    
    # JWT tokens
    (r'eyJ[A-Za-z0-9\-_.]+', 'jwt_token_***'),
    
    # Email addresses in errors
    (r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', 'user@***.com'),
    
    # Phone numbers
    (r'\+?1?[-.\s]?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}', '+1-***-***-****'),
    
    # Credit card numbers
    (r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b', '****-****-****-****'),
    
    # IP addresses
    (r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', '***.***.***.***'),
]

def sanitize_error_message(message: str) -> str:
    """Enhanced sanitization of error messages"""
    sanitized = message
    for pattern, replacement in SENSITIVE_PATTERNS:
        sanitized = re.sub(pattern, replacement, sanitized, flags=re.IGNORECASE)
    return sanitized

def sanitize_dict(data: Dict[str, Any]) -> Dict[str, Any]:
    """Sanitize dictionary values"""
    if not isinstance(data, dict):
        return data
    
    sanitized = {}
    for key, value in data.items():
        if isinstance(value, str):
            sanitized[key] = sanitize_error_message(value)
        elif isinstance(value, dict):
            sanitized[key] = sanitize_dict(value)
        elif isinstance(value, list):
            sanitized[key] = [sanitize_error_message(v) if isinstance(v, str) else v for v in value]
        else:
            sanitized[key] = value
    return sanitized

def create_safe_error_response(error: Exception, user_message: str = None) -> Dict[str, Any]:
    """Create a safe error response that doesn't leak sensitive info"""
    return {
        "error": user_message or "An error occurred while processing your request",
        "type": "application_error",
        "code": "INTERNAL_ERROR"
    }
