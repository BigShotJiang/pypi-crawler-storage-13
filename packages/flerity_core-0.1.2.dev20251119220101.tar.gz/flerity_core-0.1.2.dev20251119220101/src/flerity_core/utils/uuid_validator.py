"""
Enhanced UUID validation with proper error handling
"""

import uuid
from typing import Optional, Union
from flerity_core.utils.errors import ValidationError

def validate_uuid_format(value: Union[str, uuid.UUID], field_name: str = "id") -> uuid.UUID:
    """
    Validate UUID format and return UUID object
    
    Args:
        value: String or UUID to validate
        field_name: Name of the field for error messages
        
    Returns:
        UUID object
        
    Raises:
        ValidationError: If UUID format is invalid
    """
    if isinstance(value, uuid.UUID):
        return value
    
    if not isinstance(value, str):
        raise ValidationError(
            f"Invalid {field_name} format. Expected UUID string, got {type(value).__name__}",
            field=field_name,
            code=f"INVALID_{field_name.upper()}_TYPE"
        )
    
    # Check basic format first
    if not value or len(value) != 36:
        raise ValidationError(
            f"Invalid {field_name} format. UUID must be 36 characters long",
            field=field_name,
            code=f"INVALID_{field_name.upper()}_LENGTH"
        )
    
    try:
        return uuid.UUID(value)
    except ValueError as e:
        # Provide user-friendly error message
        if "badly formed hexadecimal UUID string" in str(e):
            raise ValidationError(
                f"Invalid {field_name} format. Please provide a valid UUID",
                field=field_name,
                code=f"INVALID_{field_name.upper()}_FORMAT"
            ) from e
        else:
            raise ValidationError(
                f"Invalid {field_name} format",
                field=field_name,
                code=f"INVALID_{field_name.upper()}"
            ) from e

def safe_uuid_parse(value: str, default: Optional[uuid.UUID] = None) -> Optional[uuid.UUID]:
    """
    Safely parse UUID string, returning default on error
    
    Args:
        value: String to parse
        default: Default value to return on error
        
    Returns:
        UUID object or default value
    """
    try:
        return uuid.UUID(value) if value else default
    except (ValueError, TypeError):
        return default

def is_valid_uuid(value: str) -> bool:
    """
    Check if string is a valid UUID format
    
    Args:
        value: String to check
        
    Returns:
        True if valid UUID format, False otherwise
    """
    try:
        uuid.UUID(value)
        return True
    except (ValueError, TypeError):
        return False
