"""
User-friendly validation decorator and utilities
"""

from functools import wraps
from typing import Any, Callable
from pydantic import ValidationError as PydanticValidationError
from flerity_core.utils.error_sanitizer import sanitize_error_message
from flerity_core.utils.errors import ValidationError

# Friendly message mappings
FRIENDLY_FIELD_MESSAGES = {
    'email': 'Please enter a valid email address',
    'password': 'Password must be at least 8 characters with letters and numbers',
    'phone': 'Please enter a valid phone number',
    'birth_year': 'Please enter a valid birth year',
    'uuid': 'Invalid ID provided',
    'url': 'Please enter a valid URL',
    'date': 'Please enter a valid date (YYYY-MM-DD)',
}

FRIENDLY_ERROR_TYPES = {
    'value_error.email': 'Invalid email format',
    'value_error.url': 'Invalid URL format', 
    'value_error.uuid': 'Invalid ID format',
    'type_error.integer': 'Must be a number',
    'type_error.str': 'Must be text',
    'value_error.missing': 'This field is required',
    'value_error.any_str.min_length': 'Too short',
    'value_error.any_str.max_length': 'Too long',
}

def make_friendly_message(field: str, error_type: str, msg: str) -> str:
    """Convert technical error to friendly message"""
    # Check for field-specific message
    if field.lower() in FRIENDLY_FIELD_MESSAGES:
        return FRIENDLY_FIELD_MESSAGES[field.lower()]
    
    # Check for error type mapping
    if error_type in FRIENDLY_ERROR_TYPES:
        return FRIENDLY_ERROR_TYPES[error_type]
    
    # Generic friendly message
    field_name = field.replace('_', ' ').title()
    if 'required' in msg.lower() or 'missing' in msg.lower():
        return f"{field_name} is required"
    elif 'invalid' in msg.lower():
        return f"Please check your {field_name.lower()}"
    else:
        return f"Invalid {field_name.lower()}"

def friendly_validation(func: Callable) -> Callable:
    """Decorator to convert validation errors to friendly messages"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except PydanticValidationError as e:
            friendly_errors = []
            for error in e.errors():
                field = '.'.join(str(loc) for loc in error['loc'])
                error_type = error['type']
                msg = error['msg']
                
                friendly_msg = make_friendly_message(field, error_type, msg)
                friendly_errors.append({
                    'field': field,
                    'message': friendly_msg
                })
            
            raise ValidationError(sanitize_error_message(f"Please check the information provided"), details=friendly_errors)
        except ValidationError:
            raise  # Re-raise as-is
        except Exception as e:
            # Convert any other validation-related exception
            raise ValidationError(sanitize_error_message(f"Please check your input and try again"))
    
    return wrapper

# Quick validation helpers
def validate_email_friendly(email: str) -> str:
    """Validate email with friendly error"""
    if not email or '@' not in email:
        raise ValidationError(sanitize_error_message(f"Please enter a valid email address"))
    return email.lower().strip()

def validate_uuid_friendly(uuid_str: str, field_name: str = "ID") -> str:
    """Validate UUID with friendly error"""
    import uuid
    try:
        uuid.UUID(uuid_str)
        return uuid_str
    except (ValueError, TypeError):
        raise ValidationError(sanitize_error_message(f"Invalid {field_name} format"))
