"""
Minimal observability utilities for production metrics.
"""

import time
import logging
from typing import Dict, Any, Optional
from functools import wraps
from contextlib import contextmanager

logger = logging.getLogger(__name__)

class MetricsCollector:
    """Minimal metrics collector for production observability."""
    
    def __init__(self):
        self._metrics: Dict[str, Any] = {}
    
    def increment(self, metric_name: str, value: int = 1, tags: Optional[Dict[str, str]] = None):
        """Increment a counter metric."""
        key = f"{metric_name}:{tags or {}}"
        self._metrics[key] = self._metrics.get(key, 0) + value
        logger.info(f"METRIC_INCREMENT {metric_name}={value} tags={tags}")
    
    def histogram(self, metric_name: str, value: float, tags: Optional[Dict[str, str]] = None):
        """Record a histogram metric."""
        key = f"{metric_name}:{tags or {}}"
        if key not in self._metrics:
            self._metrics[key] = []
        self._metrics[key].append(value)
        logger.info(f"METRIC_HISTOGRAM {metric_name}={value} tags={tags}")
    
    def gauge(self, metric_name: str, value: float, tags: Optional[Dict[str, str]] = None):
        """Set a gauge metric."""
        key = f"{metric_name}:{tags or {}}"
        self._metrics[key] = value
        logger.info(f"METRIC_GAUGE {metric_name}={value} tags={tags}")

# Global metrics instance
metrics = MetricsCollector()

@contextmanager
def measure_latency(metric_name: str, tags: Optional[Dict[str, str]] = None):
    """Context manager to measure operation latency."""
    start_time = time.time()
    try:
        yield
    finally:
        duration = (time.time() - start_time) * 1000  # Convert to milliseconds
        metrics.histogram(f"{metric_name}_latency_ms", duration, tags)

def track_database_query(func):
    """Decorator to track database query performance."""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        start_time = time.time()
        try:
            result = await func(*args, **kwargs)
            metrics.increment("db_query_success", tags={"operation": func.__name__})
            return result
        except Exception as e:
            metrics.increment("db_query_error", tags={"operation": func.__name__, "error": type(e).__name__})
            raise
        finally:
            duration = (time.time() - start_time) * 1000
            metrics.histogram("db_query_duration_ms", duration, tags={"operation": func.__name__})
    return wrapper

def track_queue_depth(queue_name: str, depth: int):
    """Track queue depth metric."""
    metrics.gauge("queue_depth", depth, tags={"queue": queue_name})
