"""
Enhanced authentication error handling
"""

from flerity_core.utils.errors import AppError

class AuthenticationError(AppError):
    """Base authentication error"""
    def __init__(self, message: str = "Authentication failed", **kwargs):
        super().__init__(message, **kwargs)
        self.status_code = 401

class InvalidCredentialsError(AuthenticationError):
    """Invalid username/password"""
    def __init__(self):
        super().__init__("Invalid email or password")

class TokenExpiredError(AuthenticationError):
    """JWT token expired"""
    def __init__(self):
        super().__init__("Your session has expired. Please log in again")

class TokenInvalidError(AuthenticationError):
    """JWT token invalid"""
    def __init__(self):
        super().__init__("Invalid authentication token")

class AccountLockedError(AuthenticationError):
    """Account locked due to failed attempts"""
    def __init__(self, unlock_time: str = None):
        msg = f"Account locked. Try again after {unlock_time}" if unlock_time else "Account temporarily locked"
        super().__init__(msg)

class EmailNotVerifiedError(AuthenticationError):
    """Email not verified"""
    def __init__(self):
        super().__init__("Please verify your email address before logging in")

class SocialAuthError(AuthenticationError):
    """Social authentication failed"""
    def __init__(self, provider: str):
        super().__init__(f"Authentication with {provider} failed. Please try again")
