def foo(s:str)->int:
    pass