from typing import Dict
from functools import wraps
# from file_keys import filepath_key, extension_key, filepath_registry, extension_registry

# registry: Dict[filepath_key, extension_key] = {}
registry = {}

def register(path, delim="_", ext=""):
    """
    Args:
        path:   A filepath that matches filenames in the current working directory
                using the python unix filename pattern matching library fnmatch.
        delim:  The single character that is used as a delimiter in the filename.
                Defaults to '_'.
        ext:    The trailing characters of the filename. Literal treatment of
                characters with str.endswith function. Not regex.
    """
    def decorator(func):
        # path_key = (filepath_key(path), extension_key(ext))
        path_key = path.strip().strip("/")
        registry[path_key] = {"func": func, "delim": delim, "ext": ext}
        return func
    return decorator
