import os
import argparse
import importlib.util
from pathlib import Path
from collections import deque
import uuid
from rdflib import Graph
from .register import registry
from .exceptions import SemflowException, NoSemflowConfig, PathConflict
from .path_utils import build_path_dict

CWD = Path.cwd()
SEMFLOW_PATH = CWD / ".semflow_config"
FF_PATH = SEMFLOW_PATH / "ff_store"

def parse_command_line():
    description = "SemFlow allows parsing of files according to the semantic" +\
        "file data curation workflow (semflow)."
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("method", type=str, help="method", 
                        choices="init parse path-space".split())
    parser.add_argument("--format", "-f", type=str, default="list", 
                        help="The output format.",
                        choices="list ttl".split())

    args = vars(parser.parse_args())

    method = args["method"]

    return method, args

def check_semflow_config():
    if not SEMFLOW_PATH.exists():
        raise NoSemflowConfig("current directory not configured for semflow")


def import_ff_store():
    for ff in FF_PATH.glob("*.py"):
        ff_name = str(ff.relative_to(FF_PATH))
        spec = importlib.util.spec_from_file_location(ff_name, ff)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)


def extract(path_dict):
    attributes = {} # filepath/filename -> attributes dict
    for ff_name, file_set in path_dict.items():
        ff = registry[ff_name]["func"]
        delim = registry[ff_name]["delim"]
        ext = registry[ff_name]["ext"]

        for filepath in file_set:
            key = str(filepath)
            name = filepath.name[:-len(ext)]
            args = deque( name.split(delim) )
            vargs = []
            kwargs = {"ext": ext}
            while len(args) > 0:
                a = args.popleft()
                if "=" in a:
                    k,v = a.split("=")
                    kwargs[k] = v
                    break
                vargs.append(a)

            while len(args) > 0:
                a = args.popleft()
                k,v = a.split("=")
                kwargs[k] = v

            attributes[key] = ff(*vargs, **kwargs)

    return attributes
            

def build_graph(attributes):
    g = Graph()

    for key, attributes in attributes.items():
        g.add( (uuid.uuid4(), "source_path", key) )

    return g


def parse(**kwargs):
    check_semflow_config()
    import_ff_store()
    print(CWD)
    path_list = [p for p in CWD.glob("**/*") if not p.is_relative_to(SEMFLOW_PATH)]
    file_list = [p.relative_to(CWD) for p in path_list if p.is_file()]
    dir_list = [p.relative_to(CWD) for p in path_list if p.is_dir()]
    path_dict = build_path_dict(dir_list, file_list)
    print(path_dict)
    print(registry)
    attributes = extract(path_dict)
    print(attributes)
    graph = build_graph(attributes)

    # print(graph.serialize(format="ttl"))

def init(**kwargs):
    try:
        check_semflow_config()
        print(".semflow_config already exists!")
    except NoSemflowConfig:
        print("Initializing .semflow_config dir")
        os.mkdirs(".semflow_config")

def path_space(**kwargs):
    check_semflow_config()
    import_ff_store()
    print("\n".join(registry.keys()))

def main():
    method, args = parse_command_line()

    commands = {"parse": parse, "init": init, "path-space": path_space}

    commands[method](**args)