from pathlib import Path
from typing import List
from fnmatch import fnmatch
from functools import partial
from .register import registry
from .exceptions import PathConflict


def check_paths(path_dict):
    path_keys = list(path_dict.keys())
    n = len(path_keys)

    for i in range(n):
        k1 = path_keys[i]
        s1 = path_dict[k1]
        for j in range(i+1,n):
            k2 = path_keys[j]
            s2 = path_dict[k2]

            if not s1.isdisjoint(s2):
                msg = f"Paths {k1} and {k2} conflict!\n"
                msg += f"The following files are matched by both paths:\n"
                s3 = s1.intersection(s2)
                msg += "\n".join(s3[:250]) + "\n"
                if len(s3) > 250:
                    msg += "\n...\n"
                raise PathConflict(msg)


def get_ext_checker(ext):
    if ext is None or ext=="":
        return lambda e: True
    
    def ext_checker(e:str, ext_pattern:str):
        return e.endswith(ext_pattern)
    
    return partial(ext_checker, ext_pattern=ext)

def get_matches(pattern: str, dir_list: List[Path], file_list: List[Path]):
    dir_set = {d for d in dir_list if fnmatch(str(d), pattern)}
    ext_checker = get_ext_checker(registry[pattern]["ext"])
    matches = set(f for f in file_list if f.parent in dir_set and ext_checker(f.name))
    return matches


def build_path_dict(dir_list: List[Path], file_list: List[Path]):
    path_dict = {k: get_matches(k, dir_list, file_list) for k in registry.keys()}
    check_paths(path_dict)
    return path_dict