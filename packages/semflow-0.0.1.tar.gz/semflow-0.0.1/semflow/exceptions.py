class SemflowException(Exception):
    pass

class NoSemflowConfig(SemflowException):
    pass

class PathConflict(SemflowException):
    pass