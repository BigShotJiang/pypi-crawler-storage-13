# Intro

**SemFlow** is designed as a simple library that allows parsing of files according to the semantic file data curation workflow (semflow). It runs as a command line program in a directory with a `.semflow_config` folder. Folder functions of semflow are stored under `.sf_config/ff_store`.

```txt
    .
    ├── .semflow_config
    |   ├── ff_store
    |   |   ├── path.py
    |   |   ├── path_1.py
    |   |   └── path__2.py
    |   └── identifiers.json
    ├── path
    │   └── 1
    |       ├── example_file_1.ext
    |       └── example_file_2.ext
    └── path_2
        └── example_file_3.ext
```

Run from the command line with:

`semflow set-root-id tag:semflow,2025:`

`semflow path-space` # shows which paths are being parsed

`semflow parse --format ttl > kg.ttl` # ttl is default format


> [!WARNING]
> `semflow parse` executes the code in `ff_store/*.py` files!
> Make sure you trust the source of these files.





# Installation

Install from PyPi with:

`pip install semflow`




# Semantic File Data Curation Workflow (SemFlow)

Each folder represents a function that maps each of its files to a data representation, and will be called the folder function (FF). Folders are defined by complete relative paths. Regex is only allowed to refer to all subfolders of a folder. A FF must refer to a unique pairing of a key given by (folder path, extension) where wildcard subfolder matching in the folder path will match with any subfolder path making them pairwise non-unique. Extension overlap is discussed below.

FFs can be named anything as long as register points to the right path, but it is suggested to use underscores in place of backslashes in a path and two underscores as an underscore in a path. (_ = /) & (__ = _)

Filenames contains delimited values followed by key-value pairs. The values are positional arguments and the key-value pairs are keyword arguments, just like a python function. The positional arguments must also be in the correct order and occur before keyword arguments. Positional arguments with defaults may be skipped and keyword arguments may directly follow the last default positional argument. Positional arguments with defaults must follow positional arguments without defaults, just like a python function.

FF is initialized with a delimiter. This allows the function to remain the same even if delimiter changes.

FF automatically has access to a file's extension. The extension is defined as the last characters of a filename. FF may optionally be unique to an extension. By default FF applies to all filenames. The uniqueness criteria for a filepath includes the extension. Extensions are pairwise unique if they do not contain the other extension as a suffix.

The result of FF is a key-value mapping.

FF will access to the parent FF of a parent folder. It may call this function and then do whatever additional processing with the key-value mapping.

Each file is given a unique identifier (UId). After FF returns a key-value mapping, a triple is generated for each key-value, such that we have file UId-key-value triple. `semflow parse` generates a new UId for each parsing. 


## FUTURE UId design

Future updates will allow caching filename-UId pairs with the parameter `-use-uid-cache`. The cache can be removed by deleting the file in `semflow_config` or with `semflow remove-cache`.

> [!NOTE]
> The cache will use up space.
> The cache will not record any filename changes.
> The cache will not delete entries on file deletion. If a new file takes up that spot later, it will receive the same UId.

A more complete approach that tracks changes is planned for a commercial implementation that will live as an os-level service.


# Folder Function Example

`semflow_config/ff_store/path.py`
```python
# the register decorator is needed to declare folder functions
from semflow import register

# register FF to a path
@register("path")
def path(**kwargs):
    return kwargs
```

`semflow_config/ff_store/path_1.py`
```python
# the register decorator is needed to declare folder functions
from semflow import register

# helper functions
def helper_func(id:str)->int:
    return int(id)

## some imported helper. must be in python path that contains semflow command line executable
import types
upperlib_string = "make_upper = lambda s: s.upper()"
upperlib = types.ModuleType("upperlib")
exec(upperlib_string, upperlib)


# folder function (FF)
## register assigns this function to the defined path
## Delimiter (delim) and "." split the filename and pass in arguments to FF.
### "_" is the default delimiter (delim)
## the function is optionally unique to a particular file extension. "" matches all files
## the function must accept all positional arguments
## register passes some default kwargs like parent functions and file extensions. 
## kwargs also includes any key-value entries in the filename. Optional.
@register("path/1", delim="_", ext=".ext")
def path_1(label1, label2, identifier, **kwargs)->dict:
    # modify any inputs
    parent_result = kwargs["parents"]["path"](label1, label2, identifier, **kwargs)
    identifier = helper_func(identifier)
    kwargs["ext"] = upperlib.make_upper(kwargs["ext"])

    # key-value outputs for each file
    result = {**parent_result, "label1":label1, "label2":label2, "identifier":identifier, **kwargs}

    return result
```