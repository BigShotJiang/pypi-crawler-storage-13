from setuptools import setup, find_packages

setup(
    name='supplychainlib',
    version='1.0.0',
    author='Shridhar Malaghan',
    description='Private AWS-integrated library for the Gourmet Coffee Supply Chain project',
    package_dir={'': 'src'},
    packages=find_packages(where='src'),
    install_requires=['boto3'],
)
