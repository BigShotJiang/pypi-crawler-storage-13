# supplychainlib/aws_sns.py

import boto3
from django.conf import settings

class SNSManager:
    def __init__(self):
        self.sns_client = boto3.client('sns', region_name=settings.AWS_REGION)

    def ensure_topic_and_subscription(self, customer_email):
        """
        Ensure the SNS topic exists and the customer email is subscribed.
        Returns the TopicArn.
        """
        # Use a dedicated topic for all customer notifications (or use one per customer if preferred)
        topic_name = getattr(settings, "SNS_TOPIC_NAME", "gourmet-coffee-orders")  # fallback name
        # Create/get SNS topic ARN
        try:
            topic_response = self.sns_client.create_topic(Name=topic_name)
            print("Created topic response:", topic_response)
        except Exception as e:
            print("Error creating SNS topic:", e)
            raise  # to see traceback

        topic_arn = topic_response['TopicArn']

        # List current subscriptions for the topic
        next_token = None
        subscribed = False
        while True:
            if next_token:
                subs = self.sns_client.list_subscriptions_by_topic(
                    TopicArn=topic_arn, NextToken=next_token)
            else:
                subs = self.sns_client.list_subscriptions_by_topic(TopicArn=topic_arn)

            for sub in subs['Subscriptions']:
                if sub['Protocol'] == 'email' and sub['Endpoint'] == customer_email:
                    subscribed = True
                    break
            next_token = subs.get('NextToken')
            if not next_token or subscribed:
                break

        # Subscribe if not already
        if not subscribed:
            self.sns_client.subscribe(
                TopicArn=topic_arn,
                Protocol='email',
                Endpoint=customer_email
            )
        return topic_arn

    def send_order_notification(self, customer_email, order_id, product_name, quantity, total_price):
        """
        Ensure topic & email subscription, then send order status notification
        """
        topic_arn = self.ensure_topic_and_subscription(customer_email)

        subject = f"Order Update - {order_id}"
        message = f"""
Dear Customer,

Your order status has changed!

Order Details:
Order ID: {order_id}
Product: {product_name}
Quantity: {quantity}
Total Price: ${total_price:.2f}
Customer Email: {customer_email}

Please check your account for the latest status.

Thank you for shopping with us,
Gourmet Coffee Supply Chain
"""
        try:
            response = self.sns_client.publish(
                TopicArn=topic_arn,
                Subject=subject,
                Message=message
            )
            print(f"SNS notification sent successfully. MessageId: {response['MessageId']}")
            return True
        except Exception as e:
            print(f"Error sending SNS notification: {e}")
            return False
