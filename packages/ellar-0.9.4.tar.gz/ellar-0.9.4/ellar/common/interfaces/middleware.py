class IEllarMiddleware:
    pass
