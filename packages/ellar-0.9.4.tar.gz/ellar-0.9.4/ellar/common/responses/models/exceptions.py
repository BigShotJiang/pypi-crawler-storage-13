class RouteResponseExecution(Exception):
    pass
