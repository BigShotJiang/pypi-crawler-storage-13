import os
import socket
import threading
from flask import Flask, render_template_string, request, send_file, jsonify
from werkzeug.utils import secure_filename
from .utils import print_info, print_success, print_error

class MobileServer:
    def __init__(self, port=5000):
        self.app = Flask(__name__)
        self.port = port
        self.server_thread = None
        self.stop_event = threading.Event()
        self.upload_folder = os.getcwd()

        # Configure app
        self.app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024 * 1024  # 16GB max upload
        
        # Register routes
        self.app.add_url_rule('/', 'index', self.index)
        self.app.add_url_rule('/upload', 'upload', self.upload, methods=['POST'])
        self.app.add_url_rule('/download/<path:filename>', 'download', self.download)
        self.app.add_url_rule('/list', 'list_files', self.list_files)

    def get_ip(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # doesn't even have to be reachable
            s.connect(('10.255.255.255', 1))
            IP = s.getsockname()[0]
        except Exception:
            IP = '127.0.0.1'
        finally:
            s.close()
        return IP

    def index(self):
        return render_template_string("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PyShare Mobile</title>
    <style>
        :root {
            --primary: #2563eb;
            --bg: #0f172a;
            --card: #1e293b;
            --text: #f8fafc;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background: var(--bg);
            color: var(--text);
            margin: 0;
            padding: 20px;
            line-height: 1.5;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
        }
        h1 { text-align: center; margin-bottom: 30px; }
        .card {
            background: var(--card);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .btn {
            display: inline-block;
            background: var(--primary);
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            border: none;
            cursor: pointer;
            width: 100%;
            text-align: center;
            box-sizing: border-box;
        }
        .file-list {
            list-style: none;
            padding: 0;
        }
        .file-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            border-bottom: 1px solid #334155;
        }
        .file-item:last-child { border-bottom: none; }
        .file-link {
            color: var(--text);
            text-decoration: none;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            margin-right: 10px;
        }
        .upload-area {
            border: 2px dashed #475569;
            border-radius: 8px;
            padding: 40px 20px;
            text-align: center;
            margin-bottom: 20px;
            cursor: pointer;
        }
        input[type="file"] { display: none; }
    </style>
</head>
<body>
    <div class="container">
        <h1>PyShare Mobile</h1>
        
        <div class="card">
            <h2>Send to PC</h2>
            <form id="uploadForm" enctype="multipart/form-data">
                <div class="upload-area" onclick="document.getElementById('fileInput').click()">
                    <p>Click to select files</p>
                    <input type="file" id="fileInput" name="file" multiple onchange="handleFiles(this.files)">
                </div>
                <div id="uploadStatus"></div>
            </form>
        </div>

        <div class="card">
            <h2>Receive from PC</h2>
            <ul class="file-list" id="fileList">
                <li>Loading files...</li>
            </ul>
        </div>
    </div>

    <script>
        function handleFiles(files) {
            const status = document.getElementById('uploadStatus');
            const formData = new FormData();
            
            for (let i = 0; i < files.length; i++) {
                formData.append('file', files[i]);
            }

            status.textContent = 'Uploading...';
            
            fetch('/upload', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                status.textContent = data.message;
                setTimeout(() => status.textContent = '', 3000);
                loadFiles();
            })
            .catch(error => {
                status.textContent = 'Error uploading file';
                console.error(error);
            });
        }

        function loadFiles() {
            fetch('/list')
            .then(response => response.json())
            .then(files => {
                const list = document.getElementById('fileList');
                list.innerHTML = '';
                files.forEach(file => {
                    const li = document.createElement('li');
                    li.className = 'file-item';
                    li.innerHTML = `
                        <a href="/download/${encodeURIComponent(file)}" class="file-link" download>${file}</a>
                        <span>⬇️</span>
                    `;
                    list.appendChild(li);
                });
                if (files.length === 0) {
                    list.innerHTML = '<li style="padding:10px;text-align:center;color:#94a3b8">No files found in current directory</li>';
                }
            });
        }

        loadFiles();
    </script>
</body>
</html>
        """)

    def upload(self):
        if 'file' not in request.files:
            return jsonify({'error': 'No file part'}), 400
        
        files = request.files.getlist('file')
        saved_files = []
        
        for file in files:
            if file.filename == '':
                continue
            
            filename = secure_filename(file.filename)
            file.save(os.path.join(self.upload_folder, filename))
            saved_files.append(filename)
            print_success(f"Received file from mobile: {filename}")
            
        return jsonify({'message': f'Successfully uploaded {len(saved_files)} files'})

    def download(self, filename):
        try:
            return send_file(os.path.join(self.upload_folder, filename), as_attachment=True)
        except Exception as e:
            return str(e), 404

    def list_files(self):
        files = [f for f in os.listdir(self.upload_folder) if os.path.isfile(os.path.join(self.upload_folder, f))]
        return jsonify(files)

    def start(self):
        ip = self.get_ip()
        print_info(f"Starting mobile server at http://{ip}:{self.port}")
        
        # Disable Flask logging
        import logging
        log = logging.getLogger('werkzeug')
        log.setLevel(logging.ERROR)
        
        self.app.run(host='0.0.0.0', port=self.port, debug=False, use_reloader=False)

if __name__ == '__main__':
    server = MobileServer()
    server.start()
