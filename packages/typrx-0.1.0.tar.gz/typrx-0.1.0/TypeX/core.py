import sys
import time
import random
import itertools
import shutil
import math
import os


# -----------------------------------------------------------
# Terminal beep sound (optional)
# -----------------------------------------------------------
def _beep():
    sys.stdout.write("\a")
    sys.stdout.flush()


# -----------------------------------------------------------
# BASIC TYPEWRITER
# -----------------------------------------------------------
def typewriter(text, speed=0.03, sound=False):
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()

        if sound:
            _beep()  # type sound

        time.sleep(speed)
    print()


# -----------------------------------------------------------
# HUMAN TYPING
# -----------------------------------------------------------
def human(text, min_speed=0.01, max_speed=0.08, sound=False):
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()

        if sound:
            _beep()

        time.sleep(random.uniform(min_speed, max_speed))
    print()


# -----------------------------------------------------------
# GLITCH TYPING
# -----------------------------------------------------------
def glitch(text, speed=0.02, strength=2, sound=False):
    GLITCH = "!@#$%^&*()_+=-<>?/\\|][{}"

    for ch in text:
        for _ in range(strength):
            sys.stdout.write(random.choice(GLITCH))
            sys.stdout.flush()
            time.sleep(speed / 3)
            sys.stdout.write("\b")

        sys.stdout.write(ch)
        sys.stdout.flush()

        if sound:
            _beep()

        time.sleep(speed)
    print()


# -----------------------------------------------------------
# WAVE TYPING
# -----------------------------------------------------------
def wave(text, speed=0.05, amp=1, sound=False):
    for i, ch in enumerate(text):
        y = int(math.sin(i * 0.4) * amp)
        sys.stdout.write(" " * max(y, 0) + ch + "\b" * max(y, 0))
        sys.stdout.flush()

        if sound:
            _beep()

        time.sleep(speed)
    print()


# -----------------------------------------------------------
# LOADER DOTS
# -----------------------------------------------------------
def loader(text="Loading", duration=3, speed=0.3):
    end = time.time() + duration
    while time.time() < end:
        for dots in [".", "..", "...", "...."]:
            sys.stdout.write(f"\r{text}{dots}")
            sys.stdout.flush()
            time.sleep(speed)
    print()


# -----------------------------------------------------------
# SPINNER
# -----------------------------------------------------------
def spinner(text="Processing", duration=3):
    spin = itertools.cycle(["|", "/", "-", "\\"])
    end = time.time() + duration
    while time.time() < end:
        sys.stdout.write(f"\r{text} {next(spin)}")
        sys.stdout.flush()
        time.sleep(0.1)
    print()


# -----------------------------------------------------------
# PROGRESS BAR
# -----------------------------------------------------------
def progress(total=100, speed=0.02):
    for i in range(total + 1):
        width = shutil.get_terminal_size().columns - 15
        done = int((i / total) * width)
        left = width - done

        bar = "█" * done + "-" * left
        sys.stdout.write(f"\r[{bar}] {i}%")
        sys.stdout.flush()
        time.sleep(speed)
    print()
