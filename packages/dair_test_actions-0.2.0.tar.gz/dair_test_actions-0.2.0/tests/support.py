# Global Testing Support Functions
