import pytest
import support as support


# Helpers
def helper_xxx() -> None:
    pass


# Fixtures
@pytest.fixture(params=[None, "xxx_1"], ids=["test_none", "test_xxx_1"])
def arg_name_xxx(request: pytest.FixtureRequest) -> None:
    return request.param


# Tests
def test_xxx() -> None:  # simple
    pass


def test_xxx_2(arg_name_xxx) -> None:  # with params
    pass


def test_raises_xxx() -> None:  # test raises error
    with pytest.raises(NotImplementedError):
        raise NotImplementedError


# Run
if __name__ == "__main__":
    pytest.main([__file__])
