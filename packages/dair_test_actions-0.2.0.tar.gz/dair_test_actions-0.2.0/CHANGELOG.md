## v0.2.0 (2025-11-18)

### Feat

- **.gitignore**: added pre-commit
- **first-commit**: first commit

### Fix

- **actions**: test build-and-test
- **actions**: fixed reference to config
