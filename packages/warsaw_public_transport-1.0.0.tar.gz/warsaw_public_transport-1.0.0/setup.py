"""
Backward compatibility setup.py for older pip versions.
The actual build configuration is in pyproject.toml
"""
from setuptools import setup

# Read pyproject.toml and use it
setup()

