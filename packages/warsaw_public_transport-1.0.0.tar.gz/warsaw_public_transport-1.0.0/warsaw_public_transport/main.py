import os
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from warsaw_public_transport.models import (
    BusLocation,
    TramLocation,
    StopSchedule,
    BusStopInfo,
    LineInfo,
    HealthCheck,
    NextArrival,
    NextArrivalsResponse
)
from warsaw_public_transport.warsaw_api import WarsawTransportAPI

load_dotenv()

app = FastAPI(
    title="Warsaw Public Transport API",
    description="API for accessing Warsaw public transport real-time data",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

api_key = os.getenv("WARSAW_DATA_API_KEY")
if not api_key:
    raise ValueError("WARSAW_DATA_API_KEY environment variable is not set")

ztm = WarsawTransportAPI(api_key=api_key)


@app.get("/")
async def health_check():
    """API health check"""
    return {
        "status": "ok",
        "message": "Warsaw Public Transport API is running"
    }


@app.get("/api/stops")
async def get_all_stops():
    """
    Get list of all stops
    
    Returns a sorted list of all stops in Warsaw
    """
    try:
        stops = ztm.get_all_stops()
        return {
            "stops": stops,
            "total": len(stops)
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error fetching stops list: {str(e)}"
        )


@app.get("/api/buses/location")
async def get_buses_location(line=Query(None, description="Bus route number")):
    """
    Get current location of buses
    
    - **line**: optional route number for filtering
    """
    try:
        buses = ztm.get_buses_location()
        
        bus_locations = []
        for bus in buses:
            bus_data = {
                "line": str(bus.lines),
                "lat": float(bus.location.latitude),
                "lon": float(bus.location.longitude),
                "time": str(bus.time),
                "brigade": str(bus.brigade),
                "vehicle_number": str(bus.vehicle_number) if bus.vehicle_number else None
            }
            bus_locations.append(BusLocation(**bus_data))
        
        if line:
            bus_locations = [b for b in bus_locations if b.line == line]
        
        return bus_locations
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching bus data: {str(e)}")


@app.get("/api/trams/location")
async def get_trams_location(line=Query(None, description="Tram route number")):
    """
    Get current location of trams
    
    - **line**: optional route number for filtering
    """
    try:
        if line:
            trams = ztm.get_trams_location(line=line)
        else:
            trams = ztm.get_trams_location()
        
        tram_locations = []
        for tram in trams:
            tram_data = {
                "line": str(tram.lines),
                "lat": float(tram.location.latitude),
                "lon": float(tram.location.longitude),
                "time": str(tram.time),
                "brigade": str(tram.brigade),
                "vehicle_number": str(tram.vehicle_number) if tram.vehicle_number else None
            }
            tram_locations.append(TramLocation(**tram_data))
        
        return tram_locations
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching tram data: {str(e)}")


@app.get("/api/stops/{stop_id}/lines")
async def get_lines_for_stop(
    stop_id,
    bus_stop_nr=Query("01", description="Stop number (usually 01 or 02)")
):
    """
    Get list of routes passing through the stop
    
    - **stop_id**: Stop ID
    - **bus_stop_nr**: stop number (usually 01 or 02 for different sides of the street)
    """
    try:
        lines = ztm.get_lines_for_stop(stop_id, bus_stop_nr)
        
        line_infos = []
        for line in lines:
            line_info = LineInfo(line=str(line))
            line_infos.append(line_info)
        
        return line_infos
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Error fetching routes for stop {stop_id}: {str(e)}"
        )


@app.get("/api/stops/{stop_id}/schedule")
async def get_stop_schedule_by_id(
    stop_id,
    line,
    bus_stop_nr=Query("01", description="Stop number (usually 01 or 02)")
):
    """
    Get arrival schedule for a stop by ID
    
    - **stop_id**: Stop ID
    - **line**: route number
    - **bus_stop_nr**: stop number (usually 01 or 02 for different sides of the street)
    """
    try:
        schedule = ztm.get_stop_schedule(stop_id, bus_stop_nr, line)
        
        return StopSchedule(
            stop_id=stop_id,
            line=line,
            rides=schedule.rides if hasattr(schedule, 'rides') else []
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error fetching schedule for stop {stop_id}: {str(e)}"
        )


@app.get("/api/stops/by-name/{stop_name}/schedule")
async def get_stop_schedule_by_name(
    stop_name,
    line,
    bus_stop_nr=Query("01", description="Stop number (usually 01 or 02)")
):
    """
    Get arrival schedule for a stop by name
    
    - **stop_name**: stop name (e.g., "Marszałkowska")
    - **line**: route number
    - **bus_stop_nr**: stop number (usually 01 or 02 for different sides of the street)
    """
    try:
        schedule = ztm.get_stop_schedule_by_name(stop_name, bus_stop_nr, line)
        
        return StopSchedule(
            stop_name=stop_name,
            line=line,
            rides=schedule.rides if hasattr(schedule, 'rides') else []
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error fetching schedule for stop '{stop_name}': {str(e)}"
        )


@app.get("/api/stops/search/{stop_name}")
async def search_stop_by_name(stop_name):
    """
    Find stop ID by its name
    
    - **stop_name**: stop name to search for
    """
    try:
        stop_id = ztm.get_bus_stop_id_by_name(stop_name)
        
        return BusStopInfo(
            stop_id=stop_id,
            stop_name=stop_name
        )
    except Exception as e:
        raise HTTPException(
            status_code=404,
            detail=f"Stop '{stop_name}' not found: {str(e)}"
        )


@app.get("/api/routes/{route_number}/location")
async def get_route_location(
    route_number,
    vehicle_type=Query("bus", description="Vehicle type: 'bus' or 'tram'")
):
    """
    Get current location of all vehicles on the specified route
    
    - **route_number**: route number (e.g., "182", "17")
    - **vehicle_type**: vehicle type - 'bus' or 'tram'
    """
    try:
        if vehicle_type.lower() == "tram":
            vehicles = ztm.get_trams_location(line=route_number)
            vehicle_type_name = "tram"
        else:
            vehicles = ztm.get_buses_location()
            vehicles = [v for v in vehicles if str(v.lines) == route_number]
            vehicle_type_name = "bus"
        
        locations = []
        for vehicle in vehicles:
            location = {
                "type": vehicle_type_name,
                "line": str(vehicle.lines),
                "lat": float(vehicle.location.latitude),
                "lon": float(vehicle.location.longitude),
                "time": str(vehicle.time),
                "brigade": str(vehicle.brigade),
                "vehicle_number": str(vehicle.vehicle_number) if vehicle.vehicle_number else None
            }
            locations.append(location)
        
        return {
            "route_number": route_number,
            "vehicle_type": vehicle_type_name,
            "vehicles_count": len(locations),
            "locations": locations
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error fetching data for route {route_number}: {str(e)}"
        )


@app.get("/api/routes/{route_number}/stops")
async def get_route_stops(
    route_number,
    vehicle_type=Query("bus", description="Vehicle type: 'bus' or 'tram'")
):
    """
    Get all stops on the route with coordinates
    
    - **route_number**: route number (e.g., "182", "17")
    - **vehicle_type**: vehicle type - 'bus' or 'tram'
    
    WARNING: This request may take 30-60 seconds as it checks all stops in Warsaw
    """
    import asyncio
    from concurrent.futures import ThreadPoolExecutor
    
    try:
        all_stops = ztm.get_all_stops()
        
        def check_stop(stop):
            stop_id = stop['stop_id']
            for bus_stop_nr in ['01', '02', '03']:
                try:
                    lines = ztm.get_lines_for_stop(stop_id, bus_stop_nr)
                    if route_number in [str(line) for line in lines]:
                        return {
                            'stop_id': stop_id,
                            'stop_name': stop['stop_name'],
                            'bus_stop_nr': bus_stop_nr,
                            'latitude': float(stop['latitude']) if stop['latitude'] else None,
                            'longitude': float(stop['longitude']) if stop['longitude'] else None,
                        }
                except:
                    continue
            return None
        
        route_stops = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            results = list(executor.map(check_stop, all_stops))
            route_stops = [r for r in results if r is not None]
        
        return {
            'route_number': route_number,
            'vehicle_type': vehicle_type,
            'stops': route_stops,
            'total_stops': len(route_stops)
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error fetching stops for route {route_number}: {str(e)}"
        )


@app.get("/api/stops/{stop_id}/next-arrivals")
async def get_next_arrivals(
    stop_id,
    bus_stop_nr=Query("01", description="Stop number (usually 01, 02, or 03)"),
    minutes=Query(120, description="Show arrivals within next N minutes")
):
    """
    Get next vehicle arrivals at a stop with time-to-arrival calculation
    
    - **stop_id**: Stop ID
    - **bus_stop_nr**: stop number (usually 01, 02, or 03)
    - **minutes**: time interval in minutes (default 120 minutes)
    """
    from datetime import datetime, timedelta
    
    try:
        lines = ztm.get_lines_for_stop(stop_id, bus_stop_nr)
        
        all_stops = ztm.get_all_stops()
        stop_name = next((s['stop_name'] for s in all_stops if s['stop_id'] == stop_id), f"Stop {stop_id}")
        
        now = datetime.now()
        current_time_str = now.strftime("%H:%M:%S")
        
        all_arrivals = []
        
        for line in lines:
            try:
                schedule = ztm.get_stop_schedule(stop_id, bus_stop_nr, line)
                
                for ride in schedule.rides:
                    try:
                        time_parts = ride.time.split(':')
                        hour, minute, second = int(time_parts[0]), int(time_parts[1]), int(time_parts[2])
                        scheduled_time = now.replace(hour=hour, minute=minute, second=second, microsecond=0)
                        
                        delta = scheduled_time - now
                        minutes_until = int(delta.total_seconds() / 60)
                        
                        if minutes_until < 0:
                            if minutes_until < -720:
                                scheduled_time += timedelta(days=1)
                                delta = scheduled_time - now
                                minutes_until = int(delta.total_seconds() / 60)
                            else:
                                continue
                        
                        if 0 <= minutes_until <= minutes:
                            if minutes_until == 0:
                                urgency = "now"
                            elif minutes_until <= 5:
                                urgency = "urgent"
                            elif minutes_until <= 15:
                                urgency = "soon"
                            else:
                                urgency = "later"
                            
                            all_arrivals.append(NextArrival(
                                line=line,
                                direction=ride.direction,
                                scheduled_time=ride.time,
                                minutes_until=minutes_until,
                                urgency=urgency,
                                brigade=ride.brigade
                            ))
                    except (ValueError, IndexError):
                        continue
            except Exception as e:
                continue
        
        all_arrivals.sort(key=lambda x: x.minutes_until)
        
        return NextArrivalsResponse(
            current_time=current_time_str,
            stop_id=stop_id,
            stop_name=stop_name,
            bus_stop_nr=bus_stop_nr,
            next_arrivals=all_arrivals,
            total_arrivals=len(all_arrivals)
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error fetching arrival data: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
