from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class HealthCheck(BaseModel):
    status: str
    message: str


class BusLocation(BaseModel):
    line: str = Field(..., description="Route number")
    lat: float = Field(..., description="Latitude")
    lon: float = Field(..., description="Longitude")
    time: str = Field(..., description="Last update time")
    brigade: str = Field(..., description="Brigade number")
    vehicle_number: Optional[str] = Field(None, description="Vehicle number")


class TramLocation(BaseModel):
    line: str = Field(..., description="Route number")
    lat: float = Field(..., description="Latitude")
    lon: float = Field(..., description="Longitude")
    time: str = Field(..., description="Last update time")
    brigade: str = Field(..., description="Brigade number")
    vehicle_number: Optional[str] = Field(None, description="Vehicle number")


class StopSchedule(BaseModel):
    stop_id: Optional[str] = Field(None, description="Stop ID")
    stop_name: Optional[str] = Field(None, description="Stop name")
    line: str = Field(..., description="Route number")
    rides: List[Any] = Field(default_factory=list, description="List of rides")


class BusStopInfo(BaseModel):
    stop_id: str = Field(..., description="Stop ID")
    stop_name: str = Field(..., description="Stop name")


class LineInfo(BaseModel):
    line: str = Field(..., description="Route number")


class VehicleLocation(BaseModel):
    type: str = Field(..., description="Vehicle type (bus/tram)")
    line: str = Field(..., description="Route number")
    lat: float = Field(..., description="Latitude")
    lon: float = Field(..., description="Longitude")
    time: str = Field(..., description="Last update time")
    brigade: str = Field(..., description="Brigade number")
    vehicle_number: Optional[str] = Field(None, description="Vehicle number")


class RouteLocationResponse(BaseModel):
    route_number: str = Field(..., description="Route number")
    vehicle_type: str = Field(..., description="Vehicle type")
    vehicles_count: int = Field(..., description="Number of vehicles")
    locations: List[Dict[str, Any]] = Field(..., description="Vehicle locations on route")


class NextArrival(BaseModel):
    line: str = Field(..., description="Route number")
    direction: str = Field(..., description="Direction")
    scheduled_time: str = Field(..., description="Scheduled arrival time (HH:MM:SS)")
    minutes_until: int = Field(..., description="Minutes until arrival")
    urgency: str = Field(..., description="Urgency: now, urgent, soon, later")
    brigade: str = Field(..., description="Brigade number")


class NextArrivalsResponse(BaseModel):
    current_time: str = Field(..., description="Current time")
    stop_id: str = Field(..., description="Stop ID")
    stop_name: str = Field(..., description="Stop name")
    bus_stop_nr: str = Field(..., description="Stop number")
    next_arrivals: List[NextArrival] = Field(default_factory=list, description="Next arrivals")
    total_arrivals: int = Field(..., description="Total number of arrivals")

