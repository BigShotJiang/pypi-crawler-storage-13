import os
import sys


def main():
    try:
        import uvicorn
        from warsaw_public_transport.main import app
    except ImportError as e:
        print(f"Error importing dependencies: {e}", file=sys.stderr)
        print("Please install the package: pip install warsaw-public-transport", file=sys.stderr)
        sys.exit(1)
    
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    
    print(f"Starting Warsaw Public Transport API on {host}:{port}")
    print(f"Documentation: http://{host}:{port}/docs")
    
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    main()

