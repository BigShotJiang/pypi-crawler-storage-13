"""
Warsaw Public Transport API

A FastAPI-based API for accessing Warsaw public transport real-time data.
Provides endpoints for tracking buses, trams, stops, and schedules.
"""

__version__ = "1.0.0"
__author__ = "Dmitry Gerzha"
__license__ = "MIT"

from warsaw_public_transport.main import app
from warsaw_public_transport.warsaw_api import WarsawTransportAPI, Vehicle, Location, Ride, Schedule
from warsaw_public_transport.models import (
    BusLocation,
    TramLocation,
    StopSchedule,
    BusStopInfo,
    LineInfo,
    HealthCheck,
    NextArrival,
    NextArrivalsResponse,
    VehicleLocation,
    RouteLocationResponse,
)

__all__ = [
    # FastAPI app
    "app",
    
    # API Client
    "WarsawTransportAPI",
    "Vehicle",
    "Location",
    "Ride",
    "Schedule",
    
    # Pydantic Models
    "BusLocation",
    "TramLocation",
    "StopSchedule",
    "BusStopInfo",
    "LineInfo",
    "HealthCheck",
    "NextArrival",
    "NextArrivalsResponse",
    "VehicleLocation",
    "RouteLocationResponse",
    
    # Metadata
    "__version__",
    "__author__",
    "__license__",
]
