from datetime import datetime
from typing import List, Optional, Dict, Any
import requests


class Location:
    def __init__(self, latitude: float, longitude: float):
        self.latitude = latitude
        self.longitude = longitude


class Vehicle:
    def __init__(
        self,
        lines: str,
        location: Location,
        time: datetime,
        brigade: str,
        vehicle_number: str,
        vehicle_type: int
    ):
        self.lines = lines
        self.location = location
        self.time = time
        self.brigade = brigade
        self.vehicle_number = vehicle_number
        self.type = vehicle_type


class Ride:
    def __init__(self, brigade: str, direction: str, route: str, time: str):
        self.brigade = brigade
        self.direction = direction
        self.route = route
        self.time = time


class Schedule:
    def __init__(
        self,
        line: str,
        bus_stop_id: str,
        bus_stop_nr: str,
        rides: List[Ride]
    ):
        self.line = line
        self.bus_stop_id = bus_stop_id
        self.bus_stop_nr = bus_stop_nr
        self.rides = rides


class WarsawTransportAPI:
    BASE_URL = "https://api.um.warszawa.pl/api/action"
    LOCATION_ENDPOINT = f"{BASE_URL}/busestrams_get/"
    TIMETABLE_ENDPOINT = f"{BASE_URL}/dbtimetable_get"
    
    RESOURCE_ID_LOCATION = "f2e5503e927d-4ad3-9500-4ab9e55deb59"
    RESOURCE_ID_SCHEDULE = "e923fa0e-d96c-43f9-ae6e-60518c9f3238"
    RESOURCE_ID_FIND_STOP = "b27f4c17-5c50-4a5b-89dd-236b282bc499"
    RESOURCE_ID_STOP_LINES = "88cd555f-6f31-43ca-9de4-66c479ad5942"
    RESOURCE_ID_ALL_STOPS = "ab75c33d-3a26-4342-b36a-6e5fef0a3ac3"
    
    TYPE_BUS = 1
    TYPE_TRAM = 2
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.session = requests.Session()
    
    def _make_request(self, url: str, params: Dict[str, Any]) -> Any:
        params['apikey'] = self.api_key
        
        try:
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            if data.get('error'):
                raise Exception(f"API Error: {data['error']}")
            
            return data.get('result', [])
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request failed: {str(e)}")
    
    def _parse_vehicle(self, record: Dict[str, str], vehicle_type: int) -> Vehicle:
        location = Location(
            latitude=float(record['Lat']),
            longitude=float(record['Lon'])
        )
        
        time = datetime.strptime(record['Time'], '%Y-%m-%d %H:%M:%S')
        
        return Vehicle(
            lines=record['Lines'],
            location=location,
            time=time,
            brigade=record['Brigade'],
            vehicle_number=record['VehicleNumber'],
            vehicle_type=vehicle_type
        )
    
    def _get_vehicles_location(self, vehicle_type: int, line: Optional[str] = None) -> List[Vehicle]:
        params = {
            'resource_id': self.RESOURCE_ID_LOCATION,
            'type': vehicle_type,
        }
        
        if line:
            params['line'] = line
        
        result = self._make_request(self.LOCATION_ENDPOINT, params)
        
        vehicles = []
        for record in result:
            vehicle = self._parse_vehicle(record, vehicle_type)
            vehicles.append(vehicle)
        
        return vehicles
    
    def get_buses_location(self, line: Optional[str] = None) -> List[Vehicle]:
        return self._get_vehicles_location(self.TYPE_BUS, line)
    
    def get_trams_location(self, line: Optional[str] = None) -> List[Vehicle]:
        return self._get_vehicles_location(self.TYPE_TRAM, line)
    
    def get_bus_stop_id_by_name(self, stop_name: str) -> str:
        params = {
            'id': self.RESOURCE_ID_FIND_STOP,
            'name': stop_name,
        }
        
        result = self._make_request(self.TIMETABLE_ENDPOINT, params)
        
        if not result:
            raise Exception(f"Stop '{stop_name}' not found")
        
        stop_data = self._convert_values_to_dict(result[0]['values'])
        return stop_data['zespol']
    
    def get_lines_for_stop(self, stop_id: str, stop_nr: str = "01") -> List[str]:
        params = {
            'id': self.RESOURCE_ID_STOP_LINES,
            'busstopId': stop_id,
            'busstopNr': stop_nr,
        }
        
        result = self._make_request(self.TIMETABLE_ENDPOINT, params)
        
        lines = []
        for item in result:
            for value_dict in item.get('values', []):
                line = value_dict.get('value')
                if line:
                    lines.append(line)
        
        return lines
    
    def get_stop_schedule(self, stop_id: str, stop_nr: str, line: str) -> Schedule:
        params = {
            'id': self.RESOURCE_ID_SCHEDULE,
            'busstopId': stop_id,
            'busstopNr': stop_nr,
            'line': line,
        }
        
        result = self._make_request(self.TIMETABLE_ENDPOINT, params)
        
        rides = []
        if isinstance(result, list):
            for item in result:
                if isinstance(item, list):
                    try:
                        ride_data = self._convert_values_to_dict(item)
                        ride = Ride(
                            brigade=ride_data.get('brygada', ''),
                            direction=ride_data.get('kierunek', ''),
                            route=ride_data.get('trasa', ''),
                            time=ride_data.get('czas', '')
                        )
                        rides.append(ride)
                    except Exception as e:
                        continue
                elif isinstance(item, dict) and 'values' in item:
                    try:
                        ride_data = self._convert_values_to_dict(item['values'])
                        ride = Ride(
                            brigade=ride_data.get('brygada', ''),
                            direction=ride_data.get('kierunek', ''),
                            route=ride_data.get('trasa', ''),
                            time=ride_data.get('czas', '')
                        )
                        rides.append(ride)
                    except Exception as e:
                        continue
        
        return Schedule(
            line=line,
            bus_stop_id=stop_id,
            bus_stop_nr=stop_nr,
            rides=rides
        )
    
    def get_stop_schedule_by_name(self, stop_name: str, stop_nr: str, line: str) -> Schedule:
        stop_id = self.get_bus_stop_id_by_name(stop_name)
        return self.get_stop_schedule(stop_id, stop_nr, line)
    
    def get_all_stops(self) -> List[Dict[str, str]]:
        params = {
            'id': self.RESOURCE_ID_ALL_STOPS,
        }
        
        result = self._make_request(self.TIMETABLE_ENDPOINT, params)
        
        stops = []
        seen_stops = set()
        
        for item in result:
            stop_data = self._convert_values_to_dict(item['values'])
            stop_id = stop_data.get('zespol', '')
            stop_name = stop_data.get('nazwa_zespolu', '')
            
            if stop_id and stop_name:
                stop_key = f"{stop_id}_{stop_name}"
                if stop_key not in seen_stops:
                    seen_stops.add(stop_key)
                    stops.append({
                        'stop_id': stop_id,
                        'stop_name': stop_name,
                        'latitude': stop_data.get('szer_geo', ''),
                        'longitude': stop_data.get('dlug_geo', '')
                    })
        
        stops.sort(key=lambda x: x['stop_name'])
        return stops
    
    @staticmethod
    def _convert_values_to_dict(values: List[Dict[str, str]]) -> Dict[str, str]:
        result = {}
        if not isinstance(values, list):
            return result
            
        for item in values:
            if isinstance(item, dict) and 'key' in item and 'value' in item:
                result[item['key']] = item['value']
        return result

