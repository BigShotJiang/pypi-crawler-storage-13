# 🚀 Quick Start Guide

Get started with Warsaw Public Transport API in 3 simple steps!

## Step 1: Install the Package

```bash
pip install warsaw-public-transport
```

## Step 2: Get Your API Key

1. Go to [Warsaw Open Data Portal](https://api.um.warszawa.pl/)
2. Register for a free account
3. Get your API key from your account dashboard

## Step 3: Run the Server

### Option A: Using Command Line

```bash
# Set your API key
export WARSAW_DATA_API_KEY="your-api-key-here"

# Start the server
warsaw-transport
```

### Option B: Using Python Module

```bash
export WARSAW_DATA_API_KEY="your-api-key-here"
python -m warsaw_public_transport
```

### Option C: Using .env File

Create a `.env` file:

```env
WARSAW_DATA_API_KEY=your-api-key-here
PORT=8000
```

Then run:

```bash
warsaw-transport
```

## 🎉 You're Ready!

The API is now running at: **http://localhost:8000**

### Try These URLs

- 📖 **Interactive docs**: http://localhost:8000/docs
- 🔄 **Alternative docs**: http://localhost:8000/redoc
- ✅ **Health check**: http://localhost:8000/

### Quick Test

```bash
# Check if it's working
curl http://localhost:8000/

# Get buses on route 182
curl "http://localhost:8000/api/routes/182/location?vehicle_type=bus"

# Search for a stop
curl "http://localhost:8000/api/stops/search/Centrum"

# Get next arrivals at a stop
curl "http://localhost:8000/api/stops/7009/next-arrivals?bus_stop_nr=01&minutes=30"
```

## 📚 Common Use Cases

### 1. Track Buses on a Route

```python
import requests

response = requests.get(
    'http://localhost:8000/api/routes/182/location',
    params={'vehicle_type': 'bus'}
)
data = response.json()
print(f"Found {data['vehicles_count']} buses on route 182")
```

### 2. Find Next Arrivals at a Stop

```python
import requests

# First, find the stop
response = requests.get('http://localhost:8000/api/stops/search/Centrum')
stop = response.json()

# Get next arrivals
response = requests.get(
    f"http://localhost:8000/api/stops/{stop['stop_id']}/next-arrivals",
    params={'bus_stop_nr': '01', 'minutes': 30}
)
arrivals = response.json()

for arrival in arrivals['next_arrivals'][:5]:
    print(f"Line {arrival['line']}: {arrival['minutes_until']} min")
```

### 3. Use the API Client Directly (No Server)

```python
from warsaw_public_transport import WarsawTransportAPI

# Initialize the client
api = WarsawTransportAPI(api_key="your-api-key")

# Get buses location
buses = api.get_buses_location(line="182")
for bus in buses:
    print(f"Bus at {bus.location.latitude}, {bus.location.longitude}")

# Get stop schedule
schedule = api.get_stop_schedule(
    stop_id="7009",
    stop_nr="01",
    line="182"
)
print(f"Found {len(schedule.rides)} rides")
```

## 🆘 Troubleshooting

### "WARSAW_DATA_API_KEY not set" Error

Make sure you've set the environment variable:
```bash
export WARSAW_DATA_API_KEY="your-key-here"
```

### "Connection refused" Error

The server isn't running. Start it with:
```bash
warsaw-transport
```

### Port Already in Use

Change the port:
```bash
export PORT=8080
warsaw-transport
```

## 📖 Next Steps

- Explore the full API at http://localhost:8000/docs
- Read the [complete documentation](README.md)
- Check out [examples](examples/)
- Learn about [publishing](PUBLISHING.md) if you want to contribute

---

**Need Help?** Open an issue on GitHub or check the documentation!

