# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-11-20

### Added
- Initial release of Warsaw Public Transport API
- FastAPI-based REST API for Warsaw public transport data
- Real-time vehicle tracking for buses and trams
- Stop schedule information
- Next arrivals with countdown timers
- Stop search functionality
- Route information endpoints
- Pydantic v2 models for data validation
- Custom Warsaw Open Data API client (no external dependencies)
- Interactive Swagger UI documentation
- Command-line interface: `warsaw-transport`
- Python module support: `python -m warsaw_public_transport`
- Comprehensive examples and documentation
- Support for Python 3.8+

### Endpoints
- `GET /` - Health check
- `GET /api/stops` - List all stops
- `GET /api/buses/location` - Get buses location
- `GET /api/trams/location` - Get trams location
- `GET /api/stops/{stop_id}/lines` - Get routes for stop
- `GET /api/stops/{stop_id}/schedule` - Get stop schedule
- `GET /api/stops/by-name/{stop_name}/schedule` - Get schedule by name
- `GET /api/stops/search/{stop_name}` - Search stop by name
- `GET /api/routes/{route_number}/location` - Get route vehicles location
- `GET /api/routes/{route_number}/stops` - Get all stops on route
- `GET /api/stops/{stop_id}/next-arrivals` - Get next arrivals with countdown

### Features
- Environment variable configuration via `.env` file
- CORS support for frontend integration
- Type hints and Pydantic validation
- Error handling and proper HTTP status codes
- Filtering support (by line, vehicle type, etc.)
- Parallel processing for route stops endpoint
- Urgency levels for arrivals (now, urgent, soon, later)

## [Unreleased]

### Planned
- WebSocket support for real-time updates
- Caching layer for improved performance
- Rate limiting
- Authentication/API keys
- Historical data analysis
- Route planning
- Arrival predictions using ML
- Multi-language support
- Docker support
- Kubernetes deployment examples
- Monitoring and metrics (Prometheus)
- GraphQL API

---

For more information about this project, see the [README](README.md).

