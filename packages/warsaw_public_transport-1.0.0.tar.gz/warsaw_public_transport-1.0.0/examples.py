import os


def example_using_api_client():
    print("\n" + "="*80)
    print("Example 1: Using WarsawTransportAPI Client Directly")
    print("="*80)
    
    from warsaw_public_transport import WarsawTransportAPI
    
    api_key = os.getenv("WARSAW_DATA_API_KEY")
    if not api_key:
        print("Error: Please set WARSAW_DATA_API_KEY environment variable")
        return
    
    api = WarsawTransportAPI(api_key=api_key)
    
    print("\n1. Getting buses on route 182...")
    try:
        buses = api.get_buses_location(line="182")
        print(f"Found {len(buses)} buses")
        if buses:
            bus = buses[0]
            print(f"  First bus: Line {bus.lines}")
            print(f"  Location: ({bus.location.latitude}, {bus.location.longitude})")
            print(f"  Time: {bus.time}")
    except Exception as e:
        print(f"Error: {e}")
    
    print("\n2. Searching for stop 'Centrum'...")
    try:
        stop_id = api.get_bus_stop_id_by_name("Centrum")
        print(f"Found stop ID: {stop_id}")
    except Exception as e:
        print(f"Error: {e}")
        stop_id = None
    
    if stop_id:
        print(f"\n3. Getting lines for stop {stop_id}...")
        try:
            lines = api.get_lines_for_stop(stop_id, "01")
            print(f"Found {len(lines)} lines: {', '.join(lines[:10])}")
        except Exception as e:
            print(f"Error: {e}")
    
    print("\n4. Getting schedule for stop 7009, line 182...")
    try:
        schedule = api.get_stop_schedule("7009", "01", "182")
        print(f"Found {len(schedule.rides)} rides")
        if schedule.rides:
            print(f"  Next rides:")
            for ride in schedule.rides[:5]:
                print(f"    {ride.time} -> {ride.direction}")
    except Exception as e:
        print(f"Error: {e}")
    
    print("\n5. Getting all stops in Warsaw...")
    try:
        stops = api.get_all_stops()
        print(f"Found {len(stops)} stops")
        print(f"  First 5 stops:")
        for stop in stops[:5]:
            print(f"    {stop['stop_id']}: {stop['stop_name']}")
    except Exception as e:
        print(f"Error: {e}")


def example_using_http_api():
    print("\n" + "="*80)
    print("Example 2: Using HTTP API (requires server running)")
    print("="*80)
    
    import requests
    
    BASE_URL = "http://localhost:8000"
    
    try:
        response = requests.get(f"{BASE_URL}/", timeout=2)
        print(f"\nServer is running at {BASE_URL}")
    except requests.exceptions.RequestException:
        print(f"\nError: Server is not running at {BASE_URL}")
        print("Start the server with: warsaw-transport")
        return
    
    print("\n1. Getting buses on route 182...")
    try:
        response = requests.get(
            f"{BASE_URL}/api/routes/182/location",
            params={'vehicle_type': 'bus'}
        )
        data = response.json()
        print(f"Found {data['vehicles_count']} buses")
        if data['locations']:
            loc = data['locations'][0]
            print(f"  First bus at: ({loc['lat']}, {loc['lon']})")
    except Exception as e:
        print(f"Error: {e}")
    
    print("\n2. Searching for stop 'Centrum'...")
    try:
        response = requests.get(f"{BASE_URL}/api/stops/search/Centrum")
        data = response.json()
        print(f"Found stop: {data['stop_name']} (ID: {data['stop_id']})")
        stop_id = data['stop_id']
    except Exception as e:
        print(f"Error: {e}")
        stop_id = None
    
    if stop_id:
        print(f"\n3. Getting next arrivals for stop {stop_id}...")
        try:
            response = requests.get(
                f"{BASE_URL}/api/stops/{stop_id}/next-arrivals",
                params={'bus_stop_nr': '01', 'minutes': 30}
            )
            data = response.json()
            print(f"Found {data['total_arrivals']} upcoming arrivals")
            print(f"  Current time: {data['current_time']}")
            if data['next_arrivals']:
                print(f"  Next 5 arrivals:")
                for arrival in data['next_arrivals'][:5]:
                    print(f"    Line {arrival['line']}: {arrival['minutes_until']} min -> {arrival['direction']} ({arrival['urgency']})")
        except Exception as e:
            print(f"Error: {e}")
    
    print("\n4. Getting list of all stops...")
    try:
        response = requests.get(f"{BASE_URL}/api/stops")
        data = response.json()
        print(f"Total stops: {data['total']}")
        print(f"  First 3 stops:")
        for stop in data['stops'][:3]:
            print(f"    {stop['stop_id']}: {stop['stop_name']}")
    except Exception as e:
        print(f"Error: {e}")


def example_fastapi_app():
    print("\n" + "="*80)
    print("Example 3: Using FastAPI App Programmatically")
    print("="*80)
    
    from warsaw_public_transport import app
    from fastapi.testclient import TestClient
    
    client = TestClient(app)
    
    print("\n1. Health check...")
    response = client.get("/")
    print(f"Status: {response.json()['status']}")
    
    print("\n2. Getting buses on route 182...")
    response = client.get("/api/routes/182/location?vehicle_type=bus")
    if response.status_code == 200:
        data = response.json()
        print(f"Found {data['vehicles_count']} buses")
    else:
        print(f"Error: {response.status_code}")
    
    print("\nFastAPI app is working!")


def example_pydantic_models():
    print("\n" + "="*80)
    print("Example 4: Using Pydantic Models")
    print("="*80)
    
    from warsaw_public_transport.models import (
        BusLocation,
        NextArrival,
        BusStopInfo
    )
    
    print("\n1. Creating BusLocation model...")
    bus = BusLocation(
        line="182",
        lat=52.2297,
        lon=21.0122,
        time="2025-11-20 14:30:00",
        brigade="1",
        vehicle_number="1234"
    )
    print(f"Bus created: Line {bus.line} at ({bus.lat}, {bus.lon})")
    print(f"  JSON: {bus.model_dump_json(indent=2)}")
    
    print("\n2. Creating NextArrival model...")
    arrival = NextArrival(
        line="182",
        direction="Piaseczno",
        scheduled_time="14:35:00",
        minutes_until=5,
        urgency="soon",
        brigade="4"
    )
    print(f"Arrival: Line {arrival.line} in {arrival.minutes_until} min")
    print(f"  Direction: {arrival.direction}")
    
    print("\n3. Model validation...")
    try:
        BusLocation(
            line="182",
            lat="invalid",
            lon=21.0122,
            time="2025-11-20 14:30:00",
            brigade="1"
        )
    except Exception as e:
        print(f"Validation caught error: {type(e).__name__}")


def main():
    print("\n" + "="*80)
    print("Warsaw Public Transport API - Usage Examples")
    print("="*80)
    
    if not os.getenv("WARSAW_DATA_API_KEY"):
        print("\nWarning: WARSAW_DATA_API_KEY not set")
        print("Some examples will not work without an API key")
        print("Get your key at: https://api.um.warszawa.pl/")
        print("\nSet it with: export WARSAW_DATA_API_KEY='your-key-here'")
    
    try:
        example_using_api_client()
    except Exception as e:
        print(f"\nExample 1 failed: {e}")
    
    try:
        example_using_http_api()
    except Exception as e:
        print(f"\nExample 2 failed: {e}")
    
    try:
        example_pydantic_models()
    except Exception as e:
        print(f"\nExample 4 failed: {e}")
    
    print("\n" + "="*80)
    print("Examples completed!")
    print("="*80)
    print("\nFor more info, visit: http://localhost:8000/docs")
    print("Or check the README")


if __name__ == "__main__":
    main()

