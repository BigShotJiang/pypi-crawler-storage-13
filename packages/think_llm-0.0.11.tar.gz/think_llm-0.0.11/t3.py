from asyncio import run
from datetime import datetime
from typing import Any
from logging import basicConfig

from think import LLM
from think.agent import BaseAgent, tool, SimpleRagAgent
from think.llm.tool import ToolDefinition
from think.rag.base import RAG, RagDocument

from dotenv import load_dotenv

load_dotenv()
basicConfig(level="DEBUG")


def get_location() -> str:
    """
    Get user's location.

    :return: User's current location (city and country).
    """
    return "Zagreb, Croatia"


class ChatBot(BaseAgent):
    """
    You are a helpful assistant.
    Today's date is {{today}}.

    You have multiple tools at your disposal and can combine them to achieve your goals.
    """

    tools = [get_location]

    @tool
    async def count_letters(self, text: str, letter: str) -> str:
        """
        Count the number of ocurrences of letter in text.

        :param text: Text to examine
        :param letter: Single letter to search for
        :return: Number of ocurrences of the specified letter
        """
        return str(text.count(letter))

    async def interact(self, response: str) -> str:
        print(response)
        return input("> ").strip()


class RagMixin:
    rag_provider: str | type[RAG] | None = None
    rag: RAG | None = None

    def init_rag(self, llm: LLM, rag: str | type[RAG] | RAG | None):
        """
        Initialize the RAG provider.
        """
        # RAG in constructor takes priority
        if isinstance(rag, str):
            self.rag_provider = RAG.for_provider(rag)
            self.rag = self.rag_provider(llm)
        elif isinstance(rag, type):
            self.rag_provider = rag.provider
            self.rag = self.rag_provider(llm)
        elif isinstance(rag, RAG):
            self.rag_provider = rag.provider
            self.rag = rag

        # Otherwise default to the class attribute
        elif isinstance(self.rag_provider, str):
            self.rag_provider = RAG.for_provider(self.rag_provider)
            self.rag = self.rag_provider(llm)
        elif isinstance(self.rag_provider, type):
            self.rag = self.rag_provider(llm)

        # Otherwise, raise an error (probably a bug)
        else:
            raise ValueError("RagMixin: provider not set")


moviebot_data = [
    "**All About Eve (1950).** An ambitious young actress insinuates herself into the lives of an aging Broadway star and her circle of theater friends. Directed by: Joseph L. Mankiewicz Cast: Bette Davis, Anne Baxter, George Sanders",
    "**On the Waterfront (1954).** An ex-prize fighter turned longshoreman struggles to stand up to his corrupt union bosses. Directed by: Elia Kazan Cast: Marlon Brando, Karl Malden, Lee J. Cobb",
    "**Ben-Hur (1959).** A Jewish prince is betrayed and sent into slavery by a Roman friend, then regains his freedom and comes back for revenge. Directed by: William Wyler Cast: Charlton Heston, Jack Hawkins, Stephen Boyd",
    "**Lawrence of Arabia (1962).** The story of T.E. Lawrence, the English officer who successfully united and led the diverse, often warring Arab tribes during World War I. Directed by: David Lean Cast: Peter O'Toole, Alec Guinness, Anthony Quinn",
    "**The Sound of Music (1965).** A woman leaves an Austrian convent to become a governess to the children of a Naval officer widower. Directed by: Robert Wise Cast: Julie Andrews, Christopher Plummer, Eleanor Parker",
    "**Midnight Cowboy (1969).** A naive hustler travels from Texas to New York City to seek personal fortune, finding a new friend in the process. Directed by: John Schlesinger Cast: Dustin Hoffman, Jon Voight, Sylvia Miles",
    "**The Godfather (1972).** The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son. Directed by: Francis Ford Coppola Cast: Marlon Brando, Al Pacino, James Caan",
    "**One Flew Over the Cuckoo's Nest (1975).** A criminal pleads insanity and is admitted to a mental institution, where he rebels against the oppressive nurse and rallies up the scared patients. Directed by: Milos Forman Cast: Jack Nicholson, Louise Fletcher, Michael Berryman",
    "**Kramer vs. Kramer (1979).** Ted Kramer's wife leaves him, allowing him to bond with his son. Then she returns, demanding custody. Directed by: Robert Benton Cast: Dustin Hoffman, Meryl Streep, Jane Alexander",
    "**Gandhi (1982).** The life of Mahatma Gandhi, the leader of India's non-violent, non-cooperative independence movement against the British Empire. Directed by: Richard Attenborough Cast: Ben Kingsley, John Gielgud, Rohini Hattangadi",
    "**Amadeus (1984).** The life, success, and troubles of Wolfgang Amadeus Mozart, as told by Antonio Salieri, the contemporaneous composer who was insanely jealous of Mozart's talent and claimed to have murdered him. Directed by: Milos Forman Cast: F. Murray Abraham, Tom Hulce, Elizabeth Berridge",
    "**Rain Man (1988).** Selfish yuppie Charlie Babbitt's father left a fortune to his savant brother Raymond and a pittance to Charlie; they travel cross-country. Directed by: Barry Levinson Cast: Dustin Hoffman, Tom Cruise, Valeria Golino",
    "**Schindler's List (1993).** In German-occupied Poland during World War II, industrialist Oskar Schindler gradually becomes concerned for his Jewish workforce after witnessing their persecution by the Nazis. Directed by: Steven Spielberg Cast: Liam Neeson, Ralph Fiennes, Ben Kingsley",
    "**Titanic (1997).** A seventeen-year-old aristocrat falls in love with a kind but poor artist aboard the luxurious, ill-fated R.M.S. Titanic. Directed by: James Cameron Cast: Leonardo DiCaprio, Kate Winslet, Billy Zane",
    "**American Beauty (1999).** A sexually frustrated suburban father has a mid-life crisis after becoming infatuated with his daughter's best friend. Directed by: Sam Mendes Cast: Kevin Spacey, Annette Bening, Thora Birch",
    "**Gladiator (2000).** A former Roman General sets out to exact vengeance against the corrupt emperor who murdered his family and sent him into slavery. Directed by: Ridley Scott Cast: Russell Crowe, Joaquin Phoenix, Connie Nielsen",
    "**The Lord of the Rings: The Return of the King (2003).** Gandalf and Aragorn lead the World of Men against Sauron's army to draw his gaze from Frodo and Sam as they approach Mount Doom with the One Ring. Directed by: Peter Jackson Cast: Elijah Wood, Viggo Mortensen, Ian McKellen",
    "**No Country for Old Men (2007).** Violence and mayhem ensue after a hunter stumbles upon a drug deal gone wrong and more than two million dollars in cash near the Rio Grande. Directed by: Joel and Ethan Coen Cast: Tommy Lee Jones, Javier Bardem, Josh Brolin",
    "**The King's Speech (2010).** The story of King George VI, his impromptu ascension to the throne of the British Empire in 1936, and the speech therapist who helped the unsure monarch overcome his stammer. Directed by: Tom Hooper Cast: Colin Firth, Geoffrey Rush, Helena Bonham Carter",
    "**12 Years a Slave (2013).** In the antebellum United States, Solomon Northup, a free black man from upstate New York, is abducted and sold into slavery. Directed by: Steve McQueen Cast: Chiwetel Ejiofor, Michael Fassbender, Lupita Nyong'o",
    "**Parasite (2019).** Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan. Directed by: Bong Joon-ho Cast: Song Kang-ho, Lee Sun-kyun, Cho Yeo-jeong",
    "**Nomadland (2020).** A woman in her sixties, after losing everything in the Great Recession, embarks on a journey through the American West, living as a modern-day nomad. Directed by: Chloé Zhao Cast: Frances McDormand, David Strathairn, Linda May",
    "**Everything Everywhere All at Once (2022).** An aging Chinese immigrant is swept up in an insane adventure, where she alone can save the world by exploring other universes connecting with the lives she could have led. Directed by: Daniel Kwan, Daniel Scheinert Cast: Michelle Yeoh, Stephanie Hsu, Ke Huy Quan",
    "**Oppenheimer (2023).** The story of J. Robert Oppenheimer's role in the development of the atomic bomb during World War II. Directed by: Christopher Nolan Cast: Cillian Murphy, Emily Blunt, Matt Damon",
    "**Anora (2024).** A young woman navigates the complexities of love and identity in contemporary society. Directed by: Sean Baker Cast: Mikey Madison, Simon Rex, Sofia Boutella",
]


class XRAGMixin:
    rag_sources: dict[str, RAG]

    def rag_init(self, rag_sources: dict[str, RAG]):
        self.rag_sources = rag_sources

        for name, rag in rag_sources.items():
            lookup_func = lambda query: rag(
                f"Look up {query} and give me all the info you have about it",
            )
            lookup_func.__name__ = "lookup_" + name
            lookup_func.__doc__ = f"""
                Look up {name} in the database.

                :param query: The query to look up
                :return: Results matching the provided query
                """

            self.__doc__ += "\n\nWhen asked about {name}, use the provided tool `lookup_{name}` to look it up."
            self.add_tool(lookup_func.__name__, lookup_func)


class XSimpleRAGAgent(XRAGMixin, BaseAgent):
    rag_name: str

    def __init__(self, llm: LLM, rag: RAG, **kwargs: Any):
        super().__init__(llm, **kwargs)

        name = getattr(self, "rag_name", None)
        if not name:
            raise ValueError(
                f"{self.__class__.__name__}.rag_name must be set to the name of the source/object to look up"
            )
        self.rag_init({name: rag})


class MovieBot(SimpleRagAgent):
    """You are a movie buff, and love to talk about movies."""

    # rag_lookup = ("movie", "title, cast, directory, plot detail, etc")
    rag_name = "movie"

    async def interact(self, response: str) -> str:
        print(response)
        return input("> ").strip()


async def main():
    agent = ChatBot(
        LLM.from_url("google:///gemini-2.0-flash"),
        today=datetime.today(),
    )
    await agent.run()


async def main2():
    llm = LLM.from_url("google:///gemini-2.0-flash")
    rag = RAG.for_provider("txtai")(llm)
    agent = MovieBot(llm, rag)
    await rag.add_documents(
        [RagDocument(id=idx, text=movie) for idx, movie in enumerate(moviebot_data)]
    )
    await agent.run()


class Brainstormer(BaseAgent):
    """
    You are a creative content writer brainstorming ideas for the next article
    on a given topic.
    """


class OutlineGenerator(BaseAgent):
    """
    You are a creative content writer. Based on an idea, you generate an outline
    of the article with key insights/takeaways/... that should be in it.
    """


class Drafter(BaseAgent):
    """
    You are a creative content writer. Based on an article idea and outline,
    you generate a 300-400 word draft and a title for the article.
    """


class Writer(BaseAgent):
    """
    You are a creative content writer. Based on the article title and draft,
    you generate a polished article in Markdown format.
    """


class Blogger(BaseAgent):
    """
    You are an executive editor of a blog, working with other creatives to brainstorm,
    draft and publish new articles. You communicate with the user (blog owner) and
    get topic suggestions to brainstorm about.

    When the user gives you an idea, you first ask Brainstormer to brainstorm a few
    article ideas. Then you should present these ideas to the user, and when he/she
    selects one, give it to OutlineGenerator to create a draft outline. Again check
    in with the user, and then give the outline to Drafter to draft the blog post.
    Again check with the user, then give it to Writer to write a complete publishable
    article. Finally, show the completed article to the user.
    """

    @tool
    async def ask_brainstomer(self, topic: str) -> str:
        """Ask the Brainstormer agent to generate a few article ideas.

        :param topic: Topic to generate ideas for
        :return: Article ideas
        """
        return await Brainstormer(self.llm).invoke(topic)

    @tool
    async def ask_outline_generator(self, idea: str) -> str:
        """Ask the OutlineGenerator agent to create an outline for the given article idea.

        :param idea: Article idea to explore
        :return: Article outline
        """
        return await OutlineGenerator(self.llm).invoke(
            f"Please create an outline for the following idea: {idea}"
        )

    @tool
    async def ask_drafter(self, idea: str, outline: str) -> str:
        """Ask the article Drafter agent to draft an article based on the provided outline.

        :param idea: Original article idea being explored
        :param outline: Article outline
        :return: Draft text of the article
        """
        return await Drafter(self.llm).invoke(
            f"Please turn this into a publishable article: {idea}\n\nOutline:\n{outline}\n\nMake sure to include both title and article body"
        )

    @tool
    async def ask_writer(self, draft: str) -> str:
        """Ask the article Writer to write a complete article based on a draft.

        :param draft: Draft of the article
        :return: Finished article
        """
        return await Writer(self.llm).invoke(
            f"Here's the draft article, please create a polished publishable version in Markdown:\n{draft}"
        )

    async def interact(self, response: str) -> str:
        print(response)
        return input("> ").strip()


async def main3():
    llm = LLM.from_url("google:///gemini-2.0-flash")
    agent = Blogger(llm)
    topic = input("Topic: ")
    article = await agent.run(topic)
    print("Finished article:\n\n" + article)


run(main2())
