#!/usr/bin/env python3
"""
Update dependencies in pyproject.toml based on `uv pip list --outdated` output.

This script:
1. Reads pyproject.toml to identify direct dependencies
2. Runs `uv pip list --outdated` to get available updates
3. Updates version constraints for direct dependencies only
4. Outputs the updated TOML to stdout (doesn't overwrite the file)
"""

import re
import subprocess
import sys
import tomllib
from pathlib import Path


def parse_dependency(dep_string):
    """Extract package name from a dependency string like 'anthropic>=0.37.1'."""
    # Handle various formats: package>=version, package==version, package>version, etc.
    match = re.match(r'^([a-zA-Z0-9_-]+)', dep_string.strip())
    if match:
        return match.group(1).lower()  # Normalize to lowercase for comparison
    return None


def get_direct_dependencies(toml_data):
    """Extract all direct dependencies from pyproject.toml."""
    direct_deps = set()

    # 1. project.dependencies
    if 'project' in toml_data and 'dependencies' in toml_data['project']:
        for dep in toml_data['project']['dependencies']:
            pkg = parse_dependency(dep)
            if pkg:
                direct_deps.add(pkg)

    # 2. project.optional-dependencies (all groups)
    if 'project' in toml_data and 'optional-dependencies' in toml_data['project']:
        for group, deps in toml_data['project']['optional-dependencies'].items():
            for dep in deps:
                pkg = parse_dependency(dep)
                if pkg:
                    direct_deps.add(pkg)

    # 3. dependency-groups.dev
    if 'dependency-groups' in toml_data and 'dev' in toml_data['dependency-groups']:
        for dep in toml_data['dependency-groups']['dev']:
            pkg = parse_dependency(dep)
            if pkg:
                direct_deps.add(pkg)

    # 4. tool.uv.dev-dependencies
    if 'tool' in toml_data and 'uv' in toml_data['tool'] and 'dev-dependencies' in toml_data['tool']['uv']:
        for dep in toml_data['tool']['uv']['dev-dependencies']:
            pkg = parse_dependency(dep)
            if pkg:
                direct_deps.add(pkg)

    return direct_deps


def get_outdated_packages():
    """Run `uv pip list --outdated` and parse the output."""
    try:
        result = subprocess.run(
            ['uv', 'pip', 'list', '--outdated'],
            capture_output=True,
            text=True,
            check=True
        )
    except subprocess.CalledProcessError as e:
        print(f"Error running 'uv pip list --outdated': {e}", file=sys.stderr)
        sys.exit(1)
    except FileNotFoundError:
        print("Error: 'uv' command not found. Please install uv.", file=sys.stderr)
        sys.exit(1)

    # Parse the output
    # Format: Package  Version  Latest  Type  [Editable project location]
    updates = {}
    lines = result.stdout.strip().split('\n')

    # Skip header lines (first 2 lines typically)
    for line in lines[2:]:
        if not line.strip():
            continue

        # Split by whitespace, handling variable spacing
        parts = line.split()
        if len(parts) >= 3:
            package = parts[0].lower()  # Normalize to lowercase
            current_version = parts[1]
            latest_version = parts[2]
            updates[package] = latest_version

    return updates


def update_toml_content(content, direct_deps, updates):
    """Update version constraints in the TOML content string."""
    updated_content = content

    for package in direct_deps:
        if package in updates:
            latest_version = updates[package]
            # Pattern to match dependency strings with version constraints
            # Matches: "package>=old_version" and captures the version part
            pattern = rf'("{re.escape(package)}>=)([^"]+)(")'
            replacement = rf'\g<1>{latest_version}\g<3>'

            updated_content = re.sub(
                pattern,
                replacement,
                updated_content,
                flags=re.IGNORECASE
            )

    return updated_content


def main():
    pyproject_path = Path('pyproject.toml')

    if not pyproject_path.exists():
        print("Error: pyproject.toml not found in current directory", file=sys.stderr)
        sys.exit(1)

    # Read the original content (to preserve formatting)
    original_content = pyproject_path.read_text()

    # Parse TOML to identify direct dependencies
    with open(pyproject_path, 'rb') as f:
        toml_data = tomllib.load(f)

    # Get direct dependencies
    direct_deps = get_direct_dependencies(toml_data)
    print(f"Found {len(direct_deps)} direct dependencies", file=sys.stderr)

    # Get outdated packages
    updates = get_outdated_packages()
    print(f"Found {len(updates)} packages with updates available", file=sys.stderr)

    # Find which direct deps can be updated
    updatable = direct_deps & set(updates.keys())
    print(f"Will update {len(updatable)} direct dependencies", file=sys.stderr)

    if updatable:
        print("\nUpdating:", file=sys.stderr)
        for pkg in sorted(updatable):
            print(f"  {pkg} -> {updates[pkg]}", file=sys.stderr)
        print(file=sys.stderr)

    # Update the content
    updated_content = update_toml_content(original_content, direct_deps, updates)

    # Output to stdout
    print(updated_content)


if __name__ == '__main__':
    main()
