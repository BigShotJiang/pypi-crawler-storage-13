from asyncio import run
from datetime import datetime, timedelta, date
from PIL import Image
import io
import json
from enum import Enum
from decimal import Decimal
import logging

from dotenv import load_dotenv

from think import LLM, Chat
from think.parser import JSONParser
from pydantic import BaseModel, model_validator

load_dotenv()


logging.basicConfig(level=logging.DEBUG)


class BusinessType(str, Enum):
    retail = "retail"
    hospitality = "hospitality"
    service = "service"
    transport = "transport"
    utility = "utility"
    travel = "travel"
    other = "other"


class Category(str, Enum):
    bakery = "bakery"
    dairy = "dairy"
    meat = "meat"
    fruit = "fruit"
    vegetable = "vegetable"
    beverage = "beverage"
    snack = "snack"
    canned = "canned"
    frozen = "frozen"
    cleaning = "cleaning"
    personal_care = "personal_care"
    home = "home"
    office_equipment = "office_equipment"
    gas = "gas"
    transport = "transport"
    utility = "utility"
    other = "other"


class Item(BaseModel):
    name: str
    category: Category | None = None
    quantity: Decimal = 1
    item_price: Decimal | None = None
    amount: Decimal | None = None

    @model_validator(mode="before")
    def set_item_price(cls, values):
        if values.get("item_price") is None and values.get("quantity") == 1:
            values["item_price"] = values["amount"]
        return values


class Receipt(BaseModel):
    datetime: datetime
    type: BusinessType
    store: str
    total: Decimal
    tax: Decimal | None = None
    items: list[Item]
    zki: str | None = None
    jir: str | None = None


def resize_image(image, max_width, max_height) -> Image.Image:
    """
    Resize the image to fit within the specified max_width and max_height
    while maintaining the aspect ratio.
    """
    original_width, original_height = image.size
    aspect_ratio = original_width / original_height

    if original_width > max_width or original_height > max_height:
        if aspect_ratio > 1:
            # Width is the limiting factor
            new_width = max_width
            new_height = int(max_width / aspect_ratio)
        else:
            # Height is the limiting factor
            new_height = max_height
            new_width = int(max_height * aspect_ratio)
    else:
        # No resizing needed
        new_width, new_height = original_width, original_height

    return image.resize((new_width, new_height))


def convert_to_grayscale(image: Image.Image) -> Image.Image:
    """
    Convert the image to grayscale.
    """
    return image.convert("L")


def image_to_jpg_binary(image, quality):
    """
    Convert a Pillow Image to a binary string in JPG format with the specified quality.

    :param image: Pillow Image object
    :param quality: Quality of the JPG image
    :return: Binary string of the image in JPG format
    """
    # Create a BytesIO object to hold the binary data
    with io.BytesIO() as output:
        # Save the image to the BytesIO object in JPG format with the specified quality
        image.save(output, format="JPEG", quality=quality)
        # Get the binary data from the BytesIO object
        binary_data = output.getvalue()

    return binary_data


async def get_bill_bbox(img_path):
    llm = LLM.from_url("google:///gemini-2.0-flash")

    # src_img = open(img_path, "rb").read()

    src_img = convert_to_grayscale(Image.open(img_path))
    preview_img = resize_image(src_img, 1000, 1000)

    c = Chat("You're an OCR engine for household bills.").user(
        "Return the bounding box for a bill or receipt as JSON array "
        "[y_min, x_min, y_max, x_max]. Make sure the box contains the "
        "entirety of the bill. If there is no receipt or bill "
        "in the image, return [].",
        images=[image_to_jpg_binary(preview_img, 50)],
    )

    result = await llm(c, parser=JSONParser())
    if len(result) == 1 and isinstance(result[0], list):
        result = result[0]

    print("GOT", result, "from", preview_img.size)

    ymin, xmin, ymax, xmax = result
    w, h = src_img.size
    ymin *= h / 1000
    xmin *= w / 1000
    ymax *= h / 1000
    xmax *= w / 1000

    print(xmin, ymin, xmax, ymax)

    cropped_img = src_img.crop((xmin, ymin, xmax, ymax))
    final_img = resize_image(cropped_img, 1000, 1000)
    return image_to_jpg_binary(final_img, 75)


async def ocr(img_data):
    llm = LLM.from_url("google:///gemini-2.0-flash")

    c = Chat("You're an OCR engine for household bills.").user(
        "Read out the items (with quantity, price per item and item total), tax, and total amount."
        + "\nIf possible, also extract the date, time, store name and ZKI and JIR unique IDs.",
        images=[img_data],
    )
    result = await llm(c)
    return result


async def parse_result(result):
    llm = LLM.from_url("google:///gemini-2.0-flash")

    today = date.today().isoformat()
    month_ago = (date.today() - timedelta(days=30)).isoformat()

    c = Chat("You're an expert in categorizing household/retail receipts.").user(
        """
        Convert the following free-format receipt/bill transcript into structured JSON. The JSON structure should follow this format:
        {
            "datetime": "2025-02-21T01:23:45",
            "type": "retail",
            "store": "Konzum",
            "total":  100.42,
            "tax": 23.49,
            "items": [ { "name": "French bread", "category": "bakery", "quantity": 2, "item_price": 10.21, "amount": 20.42 }, ... ]
        }

        Category can be one of: 'bakery', 'dairy', 'meat', 'fruit', 'vegetable', 'beverage', 'snack', 'canned', 'frozen', 'cleaning', 'personal_care', 'home', 'office_equipment', 'gas', 'transport', 'utility' or 'other'

        Note: date formatting might be confusing. Consider the date to be between
        """
        + month_ago
        + " and "
        + today
        + """
        and the time to be local time.

        Here's the transcript:
        """
        + result,
    )

    parsed = await llm(c, parser=JSONParser(spec=Receipt))
    print("PARSED", parsed.model_dump_json(indent=2))
    return parsed


async def main(img_paths):
    for img_path in img_paths:
        img_data = await get_bill_bbox(img_path)
        with open("/tmp/cropped.jpg", "wb") as f:
            f.write(img_data)
        result = await ocr(img_data)
        print("RAW", result)
        parsed = await parse_result(result)


async def ocr_pdf(pdf_data):
    llm = LLM.from_url("google:///gemini-2.0-flash")

    c = Chat("You're an OCR engine.").user(
        "Read and return text from the document.",
        documents=[pdf_data],
    )
    print("CHAT", c.dump())
    result = await llm(c)
    print("RESULT", result)
    return result


run(ocr_pdf(open("tests/data/hello.pdf", "rb").read()))

# run(
#     main(
#         [
#             # "/tmp/konzum.png",
#             # "/tmp/submarine.png",
#             # "/tmp/spar.png",
#             # "/tmp/pekara.png",
#             # "/tmp/friends.png",
#             # "/tmp/source.jpg",
#             "tests/data/hello.pdf",
#         ]
#     )
# )
