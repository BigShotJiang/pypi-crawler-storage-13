import asyncio
import logging

from dotenv import load_dotenv
from pydantic import BaseModel, Field

from think import LLM, Chat, ask
from think.prompt import JinjaStringTemplate
from think.rag.base import RAG, RagDocument

logging.basicConfig(level=logging.DEBUG)

load_dotenv()

data = [
    {
        "id": "id1",
        "text": "US tops 5 million confirmed virus cases",
    },
    {
        "id": "id2",
        "text": "Canada's last fully intact ice shelf has suddenly collapsed, forming a Manhattan-sized iceberg",
    },
    {
        "id": "id3",
        "text": "Beijing mobilises invasion craft along coast as Taiwan tensions escalate",
    },
    {
        "id": "id4",
        "text": "The National Park Service warns against sacrificing slower friends in a bear attack",
    },
    {
        "id": "id5",
        "text": "Maine man wins 25 lottery ticket",
    },
    {
        "id": "id6",
        "text": "Make huge profits without work, earn up to $100,000 a day",
    },
]


async def main():
    from json import loads

    llm = LLM.from_url("groq:///?model=openai/gpt-oss-20b")
    # rag_class = RAG.for_provider("txtai")
    # rag_class = RAG.for_provider("chroma")
    rag_class = RAG.for_provider("pinecone")

    # rag: RAG = rag_class(llm, collection="test", path="/tmp/txtai-test-db-chroma")
    # rag: RAG = rag_class(llm, collection="test")
    rag: RAG = rag_class(llm, index_name="ragtest")
    from time import time

    t0 = time()
    # raw = loads(open("/tmp/tx/data.json", encoding="utf-8").read())
    # data = [dict(id=str(el["id"]), text=el["summary"]) for el in raw]
    # await rag.add_documents(data)
    t1 = time()
    print("added docs", await rag.count(), t1 - t0)
    # x = await rag("snow weather", 10)
    x = await rag(
        "who is marija selak-raspudić? give me as much background info as possible", 10
    )
    print(x)


async def main2():
    llm = LLM.from_url("openai:///gpt-4o")
    img = open("/tmp/test.jpg", "rb").read()
    c = Chat("You're an expert font designer").user(
        "Which font is this? Pay attention to the 'a' and 'g' letters", images=[img]
    )
    answer = await llm(c)
    print(answer)


async def main3():
    llm = LLM.from_url("groq:///?model=openai/gpt-oss-20b")
    rag = RAG.for_provider("txtai")(llm)

    data = [
        RagDocument(id="a", text="Titanic: A sweeping romantic epic"),
        RagDocument(id="b", text="The Godfather: A gripping mafia saga"),
        RagDocument(id="c", text="Forrest Gump: A heartwarming tale of a simple man"),
    ]
    answer = await llm(c)
    print(answer)


asyncio.run(main3())
