import unittest
from feather.plugins.registry import PluginRegistry


class TestPluginSystem(unittest.TestCase):
    def setUp(self):
        self.registry = PluginRegistry()
    
    def test_plugin_registration(self):
        self.registry.register('test-plugin', {
            'name': 'Test Plugin',
            'version': '1.0.0',
            'description': 'A test plugin'
        })
        
        self.assertIn('test-plugin', self.registry.plugins)
    
    def test_plugin_retrieval(self):
        plugin_info = {
            'name': 'Another Plugin',
            'version': '2.0.0'
        }
        self.registry.register('another-plugin', plugin_info)
        
        retrieved = self.registry.get('another-plugin')
        self.assertEqual(retrieved['version'], '2.0.0')


if __name__ == '__main__':
    unittest.main()
