import unittest
from feather.components import buttons, inputs, layout


class TestComponents(unittest.TestCase):
    def test_button_generation(self):
        button = buttons.button('Click Me', type='primary')
        self.assertIsNotNone(button)
        self.assertIn('Click Me', str(button))
    
    def test_input_generation(self):
        inp = inputs.input('Username', placeholder='Enter username')
        self.assertIsNotNone(inp)
    
    def test_layout_components(self):
        cols = layout.columns([1, 2, 1])
        self.assertIsNotNone(cols)


if __name__ == '__main__':
    unittest.main()
