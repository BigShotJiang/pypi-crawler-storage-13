# 📦 &nbsp;TUM ESM Python Utilities

This library is a collection of small functions used in our research projects. Here, we can test and document the functions properly instead of every project dealing with this overhead which allows us to reduce the size of the utility directories of individual projects.

Feel free to use it in any other project ✨

[![PyPI](https://img.shields.io/pypi/v/tum-esm-utils?color=f43f5e&label=latest%20release&labelColor=%230f172a&cacheSeconds=60)](https://pypi.org/project/tum-esm-utils)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/tum-esm-utils?color=f43f5e&label=python%20versions&labelColor=%230f172a&cacheSeconds=60)](https://pypi.org/project/tum-esm-utils/)<br/>
[![GitHub](https://img.shields.io/github/license/tum-esm/utils?color=0ea5e9&labelColor=%230f172a&cacheSeconds=60)](https://github.com/tum-esm/utils/blob/main/LICENSE)
[![](https://img.shields.io/badge/DOI-10.5281/zenodo.14284582-%230ea5e9?labelColor=%230f172a)](https://doi.org/10.5281/zenodo.14284582)<br/>
[![](https://img.shields.io/github/actions/workflow/status/tum-esm/utils/test-unix.yaml?branch=main&label=unix%20tests&labelColor=%230f172a&cacheSeconds=60)](https://github.com/tum-esm/utils/actions/workflows/test-unix.yaml)
[![](https://img.shields.io/github/actions/workflow/status/tum-esm/utils/test-windows.yaml?branch=main&label=windows%20tests&labelColor=%230f172a&cacheSeconds=60)](https://github.com/tum-esm/utils/actions/workflows/test-windows.yaml)

<br/>

## For Users

Install the Python library with:

```bash
pdm add tum_esm_utils
# or
pip install tum_esm_utils
```

Use the API reference at [tum-esm-utils.netlify.app](https://tum-esm-utils.netlify.app).

<br/>

## For Developers

Publish the Package to PyPI:

```bash
pdm build
pdm publish
```

Open documentation page in dev mode

```bash
cd docs
npm install
npm run dev
```
