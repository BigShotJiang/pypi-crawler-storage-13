# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ConfirmIaConfigRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'version': 'str'
    }

    attribute_map = {
        'id': 'id',
        'version': 'version'
    }

    def __init__(self, id=None, version=None):
        r"""ConfirmIaConfigRequestBody

        The model defined in huaweicloud sdk

        :param id: 配置项ID
        :type id: str
        :param version: 版本号
        :type version: str
        """
        
        

        self._id = None
        self._version = None
        self.discriminator = None

        self.id = id
        self.version = version

    @property
    def id(self):
        r"""Gets the id of this ConfirmIaConfigRequestBody.

        配置项ID

        :return: The id of this ConfirmIaConfigRequestBody.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this ConfirmIaConfigRequestBody.

        配置项ID

        :param id: The id of this ConfirmIaConfigRequestBody.
        :type id: str
        """
        self._id = id

    @property
    def version(self):
        r"""Gets the version of this ConfirmIaConfigRequestBody.

        版本号

        :return: The version of this ConfirmIaConfigRequestBody.
        :rtype: str
        """
        return self._version

    @version.setter
    def version(self, version):
        r"""Sets the version of this ConfirmIaConfigRequestBody.

        版本号

        :param version: The version of this ConfirmIaConfigRequestBody.
        :type version: str
        """
        self._version = version

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ConfirmIaConfigRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
