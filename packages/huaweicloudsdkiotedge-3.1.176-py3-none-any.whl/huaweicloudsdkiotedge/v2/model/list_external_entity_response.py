# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListExternalEntityResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'externals': 'list[ExternalEntityRespDTO]'
    }

    attribute_map = {
        'externals': 'externals'
    }

    def __init__(self, externals=None):
        r"""ListExternalEntityResponse

        The model defined in huaweicloud sdk

        :param externals: 外部实体列表
        :type externals: list[:class:`huaweicloudsdkiotedge.v2.ExternalEntityRespDTO`]
        """
        
        super().__init__()

        self._externals = None
        self.discriminator = None

        if externals is not None:
            self.externals = externals

    @property
    def externals(self):
        r"""Gets the externals of this ListExternalEntityResponse.

        外部实体列表

        :return: The externals of this ListExternalEntityResponse.
        :rtype: list[:class:`huaweicloudsdkiotedge.v2.ExternalEntityRespDTO`]
        """
        return self._externals

    @externals.setter
    def externals(self, externals):
        r"""Sets the externals of this ListExternalEntityResponse.

        外部实体列表

        :param externals: The externals of this ListExternalEntityResponse.
        :type externals: list[:class:`huaweicloudsdkiotedge.v2.ExternalEntityRespDTO`]
        """
        self._externals = externals

    def to_dict(self):
        import warnings
        warnings.warn("ListExternalEntityResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListExternalEntityResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
