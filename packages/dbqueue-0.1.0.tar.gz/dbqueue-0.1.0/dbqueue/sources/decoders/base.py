from typing import List, Dict, Any
from psycopg2.extras import ReplicationMessage


class BaseDecoder:
    def decode(self, msg: ReplicationMessage) -> List[Dict[str, Any]]:
        raise NotImplementedError
