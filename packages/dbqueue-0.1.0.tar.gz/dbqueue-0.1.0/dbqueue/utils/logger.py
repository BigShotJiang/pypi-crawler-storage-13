import datetime
import sys


def log(message: str) -> None:
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    sys.stdout.write(f"[{ts}] {message}\n")
    sys.stdout.flush()
