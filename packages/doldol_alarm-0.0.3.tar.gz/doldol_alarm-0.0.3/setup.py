import setuptools

# README.md 파일을 읽어 long_description으로 사용
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    # 패키지의 배포 이름 (pip install doldol_alarm 로 사용될 이름)
    name="doldol_alarm",

    # 버전 정보. 패키지를 업데이트할 때마다 이 버전을 올려야 합니다.
    version="0.0.3",

    # 작성자 정보
    author="orpheus",  # 본인의 이름이나 닉네임으로 수정하세요.
    author_email="yys400037@gmail.com",  # 본인의 이메일 주소로 수정하세요.

    # 패키지에 대한 간단한 설명
    description="돌돌이 파이썬 메신저 알람 기능",

    # 패키지에 대한 상세 설명 (README.md 파일의 내용을 사용)
    long_description=long_description,
    long_description_content_type="text/markdown",

    # 프로젝트 홈페이지 URL
    url="https://github.com/your_username/doldol_alarm",  # GitHub 저장소 등 프로젝트 URL을 입력하세요.

    # 프로젝트와 관련된 추가적인 메타데이터
    classifiers=[
        # 이 패키지는 파이썬 3에서만 동작합니다.
        "Programming Language :: Python :: 3",
        # MIT 라이선스를 따릅니다.
        "License :: OSI Approved :: MIT License",
        # 운영체제에 독립적입니다.
        "Operating System :: OS Independent",
    ],

    # 실제 패키지에 포함될 파이썬 코드 폴더를 지정
    # find_packages()는 __init__.py가 있는 모든 폴더를 자동으로 찾아줍니다.
    packages=setuptools.find_packages(),

    # 이 패키지가 정상적으로 동작하기 위해 필요한 다른 패키지들의 목록
    # 여기에 명시된 패키지들은 `pip install` 시 자동으로 함께 설치됩니다.
    install_requires=[
        "webexteamssdk",
    ],

    # 이 패키지를 사용하기 위해 필요한 최소 파이썬 버전
    python_requires='>=3.6',
)