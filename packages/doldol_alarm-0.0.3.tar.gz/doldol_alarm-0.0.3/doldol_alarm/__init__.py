from .bot import DDA

__all__ = ['DDA']

from setuptools import setup, find_packages

setup(
    name='doldol_alarm',
    version='0.0.3',
    description='A simple Python package to send messages to a Webex room via a bot.',
    author='orpheus',
    author_email='yys400037@gmail.com',
    url='https://github.com/your_username/doldol_alarm',
    packages=find_packages(),
    install_requires=[
        'webexteamssdk',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)