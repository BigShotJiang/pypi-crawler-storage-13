"""ATON Format version information."""
__version__ = "2.0.0"
__version_info__ = (2, 0, 0)
__author__ = "Stefano D'Agostino"
__email__ = "dago.stefano@gmail.com"
__license__ = "MIT"
