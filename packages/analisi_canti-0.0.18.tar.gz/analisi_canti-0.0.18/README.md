# Analisi canti
