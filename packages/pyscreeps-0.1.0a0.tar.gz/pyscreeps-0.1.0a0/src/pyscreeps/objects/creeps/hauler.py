# -*- coding: utf-8 -*-

from typing import override

from pyscreeps.objects.__base__ import BaseCreep


class Hauler(BaseCreep):
    """Hauler creep."""

    def transfer(self, target_id: str, resource: str = "energy") -> None:
        self.set_memory(
            key="action", value={
                "type": "transfer", "target": target_id, "resource": resource
            }
        )

    @override
    def harvest(self, source_id: str) -> None:
        raise NotImplementedError("Hauler can't harvest.")

    @override
    def build(self, site_id: str) -> None:
        raise NotImplementedError("Hauler can't build.")

    @override
    def upgrade(self, controller_id: str) -> None:
        raise NotImplemented("Hauler can't upgrade.")