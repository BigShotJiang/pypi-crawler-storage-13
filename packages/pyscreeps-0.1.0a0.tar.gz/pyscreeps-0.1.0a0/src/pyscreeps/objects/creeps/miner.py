# -*- coding: utf-8 -*-

from pyscreeps.objects.__base__ import BaseCreep


class Miner(BaseCreep):
    """Miner creep."""
    ...