# -*- coding: utf-8 -*-

"""Base game objects."""

from abc import ABC, abstractmethod
from typing import Any


class BaseCreep:
    """Base creep."""

    def __init__(
            self,
            name: str,
            creep_id: str,
            room: str,
            memory: dict[str, Any] | None
    ):
        """Init creep.

        Args:
            name (str): Creep name
            creep_id (str): Creep ID
            room (str): Room name
            memory (dict | None): Memory
        """
        self.__memory = memory if isinstance(memory, dict) else {}
        self.name = name
        self.__id = creep_id
        self.room = room

    def set_memory(self, key: str, value: Any) -> None:
        self.__memory[key] = value

    def get_memory(self, key: str, default: Any = None) -> Any:
        return self.__memory.get(key, default)

    def __repr__(self):
        return f"<{self.__class__.__name__} {self.name} in {self.room}>"

    def move(self, target_id: str) -> None:
        self.set_memory("action", {"type": "move", "target": target_id})

    def harvest(self, source_id: str) -> None:
        self.set_memory("action", {"type": "harvest", "target": source_id})

    def build(self, site_id: str) -> None:
        self.set_memory("action", {"type": "build", "target": site_id})

    def upgrade(self, controller_id: str) -> None:
        self.set_memory("action", {"type": "upgrade", "target": controller_id})


class BaseRoom(ABC):

    @abstractmethod
    def found(self):
        ...

    @abstractmethod
    def structures(self):
        ...


class BaseStructure(ABC):
    ...


class BaseController(ABC):
    ...