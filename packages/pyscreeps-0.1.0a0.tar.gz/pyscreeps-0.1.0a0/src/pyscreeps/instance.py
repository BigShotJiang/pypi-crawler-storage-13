# -*- coding: utf-8 -*-

from pyscreeps.config import yaml_config_parser


class Screeps:
    def __init__(
            self,
            config: str = "config.yaml"
    ) -> None:
        self.config = yaml_config_parser(config)