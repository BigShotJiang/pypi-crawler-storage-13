# -*- coding: utf-8 -*-

from .instance import Screeps

__version__ = "0.1.0a0"
__all__ = ["Screeps"]
