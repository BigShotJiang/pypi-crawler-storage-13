## Typing stubs for reportlab

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`reportlab`](https://github.com/MrBitBucket/reportlab-mirror) package. It can be used by type checkers
to check code that uses `reportlab`. This version of
`types-reportlab` aims to provide accurate annotations for
`reportlab==4.4.5`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/reportlab`](https://github.com/python/typeshed/tree/main/stubs/reportlab)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.18.2
* [pyright](https://github.com/microsoft/pyright) 1.1.407

It was generated from typeshed commit
[`3e1b90bb2d772781c2b6f318e0f44ef791cf5160`](https://github.com/python/typeshed/commit/3e1b90bb2d772781c2b6f318e0f44ef791cf5160).