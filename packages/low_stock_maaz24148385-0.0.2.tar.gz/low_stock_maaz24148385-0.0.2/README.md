# low-stock-maaz24148385

A **unit-aware low stock detection** library for inventory systems.

## Purpose
Detects low stock based on **unit-specific thresholds**:
- 5kg → acceptable
- 5g → **critical**

## Features
- Configurable thresholds per unit
- Pure Python

