# my_inventory_lib/low_stock.py
"""
Low Stock Detection with Unit-Specific Thresholds
Author: Maaz Ahmed
"""

from typing import Dict, Any, List
from decimal import Decimal

class LowStockChecker:
    DEFAULT_THRESHOLDS = {
        'kg': Decimal('10.0'),
        'g': Decimal('500.0'),
        'liters': Decimal('20.0'),
        'ml': Decimal('1000.0'),
        'box': Decimal('3.0'),
        'pieces': Decimal('5.0'),
        'packet': Decimal('2.0'),
    }
    thresholds = DEFAULT_THRESHOLDS.copy()
    
    @classmethod
    def set_thresholds(cls, new_thresholds: Dict[str, Decimal]):
        cls.thresholds = new_thresholds

    @classmethod
    def is_low(cls, item: Dict[str, Any]) -> bool:
        qty = Decimal(str(item.get('Quantity', 0)))
        unit = item.get('Unit', '').strip().lower()
        threshold = cls.thresholds.get(unit, Decimal('5.0'))
        return qty < threshold
   