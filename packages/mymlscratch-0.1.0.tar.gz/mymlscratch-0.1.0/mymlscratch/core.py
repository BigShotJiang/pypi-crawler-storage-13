from .algorithms import linear_regression, logistic_regression, knn, decision_tree, kmeans

def get_linear_regression_code():
    """Returns the complete source code for Linear Regression from scratch."""
    return linear_regression.CODE

def get_logistic_regression_code():
    """Returns the complete source code for Logistic Regression from scratch."""
    return logistic_regression.CODE

def get_knn_code():
    """Returns the complete source code for K-Nearest Neighbors from scratch."""
    return knn.CODE

def get_decision_tree_code():
    """Returns the complete source code for Decision Tree from scratch."""
    return decision_tree.CODE

def get_kmeans_code():
    """Returns the complete source code for K-Means Clustering from scratch."""
    return kmeans.CODE

def list_available_algorithms():
    """Returns a list of all available algorithms."""
    return [
        "linear_regression",
        "logistic_regression",
        "knn",
        "decision_tree",
        "kmeans"
    ]