# MyMLScratch

A Python library that returns the complete source code for various machine learning algorithms implemented from scratch using pure Python and NumPy.

## Installation
```bash
pip install mymlscratch
```

## Usage
```python
import mymlscratch

# Get Linear Regression code
code = mymlscratch.get_linear_regression_code()
print(code)

# Save to a file
with open('linear_regression.py', 'w') as f:
    f.write(code)

# Execute the code
exec(code)

# List all available algorithms
algorithms = mymlscratch.list_available_algorithms()
print(algorithms)
```

## Available Algorithms

- **Linear Regression** - `get_linear_regression_code()`
- **Logistic Regression** - `get_logistic_regression_code()`
- **K-Nearest Neighbors** - `get_knn_code()`
- **Decision Tree** - `get_decision_tree_code()` *(coming soon)*
- **K-Means Clustering** - `get_kmeans_code()` *(coming soon)*

## Features

- ✅ Pure Python/NumPy implementations
- ✅ Complete, runnable source code
- ✅ Educational comments and docstrings
- ✅ Example usage included in each algorithm
- ✅ No dependencies except NumPy

## Use Cases

- **Learning**: Study how ML algorithms work under the hood
- **Teaching**: Use in educational materials and courses
- **Customization**: Get base code to modify for specific needs
- **Prototyping**: Quick algorithm implementations for experiments

## Example
```python
import mymlscratch
import numpy as np

# Get the code
code = mymlscratch.get_linear_regression_code()

# Execute it
exec(code)

# Now you can use the LinearRegression class
X = np.array([[1], [2], [3], [4], [5]])
y = np.array([2, 4, 6, 8, 10])

model = LinearRegression(learning_rate=0.01, n_iterations=1000)
model.fit(X, y)
predictions = model.predict(X)

print("Predictions:", predictions)
```

## License

MIT License - see LICENSE file for details

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.