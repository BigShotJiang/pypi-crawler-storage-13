"""Analyzer subpackage"""
