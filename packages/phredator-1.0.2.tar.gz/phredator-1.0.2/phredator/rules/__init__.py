"""Rules subpackage"""
