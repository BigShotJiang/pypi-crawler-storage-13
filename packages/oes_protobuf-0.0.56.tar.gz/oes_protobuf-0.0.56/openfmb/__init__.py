import os 
import sys

sys.path.insert(1, "openfmb")
sys.path.insert(1, ".")
sys.path.append(os.path.dirname(__file__))