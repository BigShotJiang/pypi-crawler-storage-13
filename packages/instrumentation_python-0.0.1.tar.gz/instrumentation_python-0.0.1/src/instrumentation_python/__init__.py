"""
instrumentation-python: Security placeholder package

This package is a placeholder to prevent dependency confusion attacks.
DO NOT USE THIS PACKAGE.
"""

__version__ = "0.0.1"

def _placeholder():
    """
    This is a placeholder package and should not be used.
    """
    raise NotImplementedError(
        "This is a security placeholder package and should not be used. "
        "If you are seeing this error, you may have accidentally installed "
        "the public PyPI package instead of the intended internal package."
    )
