"""
Network Manager - Integrates P2P discovery and document sharing
Handles peer communication, document distribution, and real-time sync
"""

import threading
import json
import logging
import socket
from typing import Dict, Callable, Optional, List
from pathlib import Path
from .network.discovery import DiscoveryManager, PeerInfo
from .network.client import P2PClient
from .network.server import P2PServer
from .network.protocol import Message, MessageType
from .storage import StorageManager

logger = logging.getLogger(__name__)

# Global lock to ensure only one NetworkManager per user
_network_managers = {}


class NetworkManager:
    """Manages network operations and P2P communication"""
    
    _instances = {}  # Singleton per username
    _lock = threading.Lock()
    
    def __new__(cls, username: str, tcp_port: int = 5000, config_dir: str = None):
        """Ensure only one NetworkManager per username (singleton pattern)"""
        with cls._lock:
            if username not in cls._instances:
                instance = super().__new__(cls)
                cls._instances[username] = instance
            return cls._instances[username]
    
    def __init__(self, username: str, tcp_port: int = 5000, config_dir: str = None):
        """
        Initialize network manager (only once per username)
        
        Args:
            username: Current user's username
            tcp_port: TCP port for server
            config_dir: Configuration directory
        """
        # Only initialize once
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        
        self.username = username
        self.tcp_port = tcp_port
        self.config_dir = config_dir or str(Path.home() / ".p2pdocs")
        self.is_running = False  # Track if network manager is running
        
        # Initialize components
        self.storage = StorageManager(self.config_dir)
        self.discovery_manager = DiscoveryManager(username, tcp_port)
        self.server = P2PServer(host="0.0.0.0", port=tcp_port, username=username)
        self.client = P2PClient(username=username)
        
        # State tracking
        self.connected_peers: Dict[str, PeerInfo] = {}
        self.shared_documents: Dict[str, List[str]] = {}  # doc_name -> [users editing]
        self.callbacks: Dict[str, Callable] = {}
        self.shared_doc_name = "shared_document.txt"  # Single shared document for all peers
        self.sync_lock = threading.Lock()  # Prevent duplicate sync operations
        
        # Register message handlers
        self._register_handlers()
        
        logger.info(f"NetworkManager initialized for {username}")
    
    def _register_handlers(self):
        """Register message handlers for different message types"""
        
        # Update notification handler
        def handle_update_notification(message):
            doc_name = message.document
            content = message.payload.get("content") if message.payload else None
            sender = message.sender
            
            # CRITICAL: Skip self-updates (own broadcasts coming back from network)
            if sender == self.username:
                logger.info(f"Skipping own update notification from {sender}")
                return
            
            if content is not None:  # Allow empty string but not None
                # Create or update document
                existing_docs = self.storage.list_documents()
                if doc_name not in existing_docs:
                    # Document doesn't exist, create it
                    self.storage.create_document(doc_name, sender, content)
                    logger.info(f"Created document '{doc_name}' from {sender}")
                else:
                    # Document exists, update it
                    self.storage.update_document(doc_name, content)
            
            # Notify callback with content included
            if "on_document_updated" in self.callbacks:
                self.callbacks["on_document_updated"](doc_name, sender, content)
            
            logger.info(f"Document '{doc_name}' updated by {sender}")
        
        # Sync request handler (peer requesting shared document)
        def handle_sync_request(message):
            doc_name = message.document
            sender = message.sender
            
            # Send the document back to requester
            self._send_shared_document(sender)
            logger.info(f"Sync request from {sender} for {doc_name}")
        
        # Sync response handler (document sync from peer)
        def handle_sync_response(message):
            doc_name = message.document
            content = message.payload.get("content") if message.payload else None
            sender = message.sender
            
            # CRITICAL: Skip self-responses (own documents coming back from network)
            if sender == self.username:
                logger.info(f"Skipping own sync response from {sender}")
                return
            
            if content:
                # Create or update document locally
                existing_docs = self.storage.list_documents()
                if doc_name not in existing_docs:
                    self.storage.create_document(doc_name, sender, content)
                else:
                    # Update if already exists (shared document sync)
                    self.storage.update_document(doc_name, content)
            
            # Notify callback (treat as update for shared docs)
            if "on_document_updated" in self.callbacks:
                self.callbacks["on_document_updated"](doc_name, sender)
            
            logger.info(f"Document '{doc_name}' synced from {sender}")
        
        # Peer announced handler
        def handle_peer_announce(message):
            peer_username = message.sender
            
            # Skip self-announcements
            if peer_username == self.username:
                return
            
            if "on_peer_joined" in self.callbacks:
                self.callbacks["on_peer_joined"](peer_username)
            
            logger.info(f"Peer {peer_username} announced")
        
        # Register handlers with server
        self.server.register_handler(MessageType.SYNC_REQUEST, handle_sync_request)
        self.server.register_handler(MessageType.UPDATE_NOTIFICATION, handle_update_notification)
        self.server.register_handler(MessageType.SYNC_RESPONSE, handle_sync_response)
        self.server.register_handler(MessageType.PEER_ANNOUNCE, handle_peer_announce)
    
    def start(self):
        """Start network discovery and server"""
        if self.is_running:
            logger.warning("Network manager already running")
            return
        
        logger.info("Starting network manager...")
        self.is_running = True
        
        # Start TCP server
        self.server.start()
        
        # Start UDP discovery
        self.discovery_manager.start()
        
        # Start client
        self.client.start()
        
        # Start connection monitor thread (daemon for graceful shutdown)
        self.monitor_thread = threading.Thread(target=self._monitor_peers, daemon=True)
        self.monitor_thread.start()
        
        logger.info(f"Network manager started on port {self.tcp_port}")
    
    def stop(self):
        """Stop network manager"""
        logger.info("Stopping network manager...")
        self.is_running = False
        self.discovery_manager.stop()
        self.server.stop()
        self.client.stop()
        # Join monitor thread with timeout
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=2)
        logger.info("Network manager stopped")
    
    def _monitor_peers(self):
        """Monitor peers and connect to new ones"""
        while self.is_running:
            try:
                # Get alive peers from discovery
                alive_peers = self.discovery_manager.get_peers()
                
                peer_count_before = len(self.connected_peers)
                
                for peer in alive_peers:
                    # Skip self
                    if peer.username == self.username:
                        continue
                    
                    # Connect to new peers
                    if peer.username not in self.connected_peers:
                        self._connect_to_peer(peer)
                
                # Remove disconnected peers
                for username in list(self.connected_peers.keys()):
                    if not self.discovery_manager.get_peer(username):
                        del self.connected_peers[username]
                        logger.info(f"Peer {username} disconnected")
                
                # Trigger callback if peer list changed
                peer_count_after = len(self.connected_peers)
                if peer_count_after != peer_count_before and "on_peer_updated" in self.callbacks:
                    self.callbacks["on_peer_updated"]()
                
                threading.Event().wait(5)  # Check every 5 seconds
            
            except Exception as e:
                logger.error(f"Error monitoring peers: {str(e)}")
                threading.Event().wait(5)
    
    def _connect_to_peer(self, peer: PeerInfo):
        """Connect to a peer and sync shared document"""
        try:
            success = self.client.connect_to_peer(
                peer_host=peer.host,
                peer_port=peer.port,
                peer_username=peer.username
            )
            
            if success:
                self.connected_peers[peer.username] = peer
                logger.info(f"Connected to peer {peer.username} at {peer.host}:{peer.port}")
                
                # Request shared document from peer
                self._request_shared_document(peer.username)
            else:
                logger.warning(f"Failed to connect to peer {peer.username}")
        
        except Exception as e:
            logger.error(f"Error connecting to peer {peer.username}: {str(e)}")
    
    def _request_shared_document(self, peer_username: str):
        """Request the shared document from a peer (SYNC_REQUEST)"""
        try:
            message = Message(
                msg_type=MessageType.SYNC_REQUEST,
                sender=self.username,
                recipient=peer_username,
                document=self.shared_doc_name,
                payload={}
            )
            self.client.send_message(peer_username, message)
            logger.info(f"Requested shared document from {peer_username}")
        except Exception as e:
            logger.error(f"Error requesting shared document from {peer_username}: {str(e)}")
    
    def _send_shared_document(self, peer_username: str):
        """Send the shared document to a peer (SYNC_RESPONSE)"""
        try:
            success, content = self.storage.read_document(self.shared_doc_name)
            
            # If document doesn't exist on this peer, create it as empty
            if not success:
                logger.info(f"Shared document doesn't exist locally, creating empty one for {peer_username}")
                success, msg = self.storage.create_document(self.shared_doc_name, self.username, "")
                content = "" if success else ""
            
            # Send document to peer
            message = Message(
                msg_type=MessageType.SYNC_RESPONSE,
                sender=self.username,
                recipient=peer_username,
                document=self.shared_doc_name,
                payload={
                    "content": content,
                    "owner": self.username
                }
            )
            self.client.send_message(peer_username, message)
            logger.info(f"Sent shared document to {peer_username} ({len(content)} bytes)")
        except Exception as e:
            logger.error(f"Error sending shared document to {peer_username}: {str(e)}")
    
    def register_callback(self, event_name: str, callback: Callable):
        """Register callback for network events"""
        self.callbacks[event_name] = callback
        logger.info(f"Registered callback for {event_name}")
    
    def broadcast_document_update(self, doc_name: str, content: str):
        """Broadcast document update to all peers (except self)"""
        message = Message(
            msg_type=MessageType.UPDATE_NOTIFICATION,
            sender=self.username,
            recipient="*",
            document=doc_name,
            payload={
                "content": content
            }
        )
        
        logger.info(f"Broadcasting update for '{doc_name}' to {len(self.connected_peers)} peers: {list(self.connected_peers.keys())}")
        
        for peer_username in self.connected_peers.keys():
            # Don't send to self
            if peer_username == self.username:
                logger.info(f"Skipping self ({self.username})")
                continue
            
            try:
                logger.info(f"Sending update to {peer_username}")
                self.client.send_message(peer_username, message)
            except Exception as e:
                logger.error(f"Error sending update to {peer_username}: {str(e)}")
    
    def broadcast_document_created(self, doc_name: str, content: str):
        """Broadcast new document to all peers"""
        message = Message(
            msg_type=MessageType.SYNC_RESPONSE,
            sender=self.username,
            recipient="*",
            document=doc_name,
            payload={
                "content": content,
                "owner": self.username
            }
        )
        
        for peer_username in self.connected_peers.keys():
            try:
                self.client.send_message(peer_username, message)
            except Exception as e:
                logger.error(f"Error broadcasting document to {peer_username}: {str(e)}")
    
    def get_connected_peers(self) -> List[PeerInfo]:
        """Get list of connected peers"""
        return list(self.connected_peers.values())
    
    def get_discovered_peers(self) -> List[PeerInfo]:
        """Get list of discovered peers on LAN"""
        peers = self.discovery_manager.get_peers()
        return [p for p in peers if p.username != self.username]
    
    def get_peer_connection_status(self) -> Dict[str, bool]:
        """Get connection status for all peers"""
        status = {}
        
        for peer in self.get_discovered_peers():
            status[peer.username] = peer.username in self.connected_peers
        
        return status
    
    def get_status(self) -> dict:
        """Get network status"""
        return {
            "username": self.username,
            "tcp_port": self.tcp_port,
            "discovered_peers": len(self.get_discovered_peers()),
            "connected_peers": len(self.connected_peers),
            "peers": [
                {
                    "username": p.username,
                    "host": p.host,
                    "port": p.port,
                    "connected": p.username in self.connected_peers
                }
                for p in self.get_discovered_peers()
            ]
        }
