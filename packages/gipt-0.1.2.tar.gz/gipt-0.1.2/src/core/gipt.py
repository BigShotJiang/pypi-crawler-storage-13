# src/core/gipt.py

from typing import Optional
from src.core.enums import CommitStyle, CoreConfig
from src.core.integrations.ai_model import get_llm
from src.core.prompts.commit_prompts import get_commit_prompt
from src.core.prompts.greet import get_greeting_prompt
from src.core.utils.gipt_helpers import TomlManager, get_gipt_config
from src.core.utils.git_helpers import get_current_wd_path, get_user_name
from src.settings import setting


class Gipt:
    def __init__(self) -> None:
        self._cfg = TomlManager(get_gipt_config())
        self._llm = get_llm()

    def greet(self) -> str:

        username = get_user_name()
        provider = self._cfg.get(CoreConfig.CORE_PROVIDER)
        model = self._cfg.get(f"provider.{provider.value}.model")

        prompt = get_greeting_prompt()
        chain = prompt | self._llm

        response = chain.invoke({"username": username, "model_name": model})

        return response.content

    def commit(self, diff_content: str, commit_style: Optional[CommitStyle] = None) -> str:
        prompt = get_commit_prompt()
        chain = prompt | self._llm

        commit_rules = setting.COMMIT_STYLES[
            commit_style.value if commit_style else self._cfg.get(CoreConfig.CORE_COMMIT_STYLE)
        ]


        response = chain.invoke({"diff_content": diff_content, "_commit_rules": commit_rules})

        return response.content

    def commit_stream(self, diff_content: str, commit_style: Optional[CommitStyle] = None):
        prompt = get_commit_prompt()
        chain = prompt | self._llm
        commit_rules = setting.COMMIT_STYLES[
            commit_style.value if commit_style else self._cfg.get(CoreConfig.CORE_COMMIT_STYLE)
        ]

        for chunk in chain.stream({"diff_content": diff_content, "_commit_rules": commit_rules}):
            yield chunk.content


gipt = Gipt()
