# src/core/integrations/ai_model.py

import os

from langchain_anthropic import ChatAnthropic
from langchain_core.language_models import BaseChatModel
from langchain_groq import ChatGroq
from langchain_ollama import ChatOllama
from langchain_openai import ChatOpenAI

from src.core.enums import CoreConfig
from src.core.utils.gipt_helpers import TomlManager, get_gipt_config
from src.core.utils.git_helpers import get_current_wd_path


def get_api_key(varname: str) -> str:
    key = os.getenv(varname)

    if not key:
        raise ValueError(
            f"Environment variable '{varname}' is not set or is empty. "
            f"Set it with: export {varname}='your-key-here'"
        )

    return key.strip()


def get_llm() -> BaseChatModel:
    cfg = TomlManager(get_gipt_config())

    provider = cfg.get(CoreConfig.CORE_PROVIDER)
    temp = cfg.get(CoreConfig.CORE_TEMPERATURE)
    p = cfg.get(CoreConfig.CORE_TOP_P)

    if provider == "ollama":
        return ChatOllama(
            model=cfg.get(CoreConfig.PROVIDER_OLLAMA_MODEL), temperature=temp, top_p=p
        )
    elif provider == "openai":
        return ChatOpenAI(
            model=cfg.get(CoreConfig.PROVIDER_OPENAI_MODEL),
            streaming=True,
            temperature=temp,
            top_p=p,
            api_key=get_api_key(cfg.get(CoreConfig.PROVIDER_OPENAI_KEY_ENV)),
        )
    elif provider == "groq":
        return ChatGroq(
            model=cfg.get(CoreConfig.PROVIDER_GROQ_MODEL),
            streaming=True,
            temperature=temp,
            model_kwargs={"top_p": p},
            api_key=get_api_key(cfg.get(CoreConfig.PROVIDER_GROQ_KEY_ENV)),
        )
    else:
        return ChatAnthropic(
            model=cfg.get(CoreConfig.PROVIDER_ANTHROPIC_MODEL),
            streaming=True,
            temperature=temp,
            top_p=p,
            api_key=get_api_key(cfg.get(CoreConfig.PROVIDER_ANTHROPIC_KEY_ENV)),
        )
