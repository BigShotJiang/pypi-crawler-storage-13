# src/core/enums.py

from enum import Enum


class Provider(str, Enum):
    OLLAMA = "ollama"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GROQ = "groq"


class CommitStyle(str, Enum):
    CONVENTIONAL = "conventional"
    GITMOJI = "gitmoji"
    SIMPLE = "simple"


class CoreConfig(str, Enum):
    # Core Config
    CORE_PROVIDER = "core.provider"
    CORE_TEMPERATURE = "core.temperature"
    CORE_COMMIT_STYLE = "core.commit_style"
    CORE_COMMIT_INTERACTIVE = "core.commit_interactive"
    CORE_TOP_P = "core.top_p"

    # Provider Config

    PROVIDER_OLLAMA_KEY_ENV    = "provider.ollama.key_env"
    PROVIDER_OLLAMA_MODEL      = "provider.ollama.model"
    PROVIDER_OLLAMA_URL        = "provider.ollama.url"
    PROVIDER_ANTHROPIC_KEY_ENV = "provider.anthropic.key_env"
    PROVIDER_ANTHROPIC_MODEL   = "provider.anthropic.model"
    PROVIDER_OPENAI_KEY_ENV    = "provider.openai.key_env"
    PROVIDER_OPENAI_MODEL      = "provider.openai.model"
    PROVIDER_GROQ_KEY_ENV      = "provider.groq.key_env"
    PROVIDER_GROQ_MODEL        = "provider.groq.model"