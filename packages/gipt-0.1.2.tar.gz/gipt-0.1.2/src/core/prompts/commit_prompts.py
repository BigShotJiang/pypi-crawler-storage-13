# src/core/prompts/commit_prompts.py

from src.core.utils.gipt_helpers import TomlManager, get_gipt_config
from src.core.utils.git_helpers import get_current_wd_path
from src.core.enums import CommitStyle, CoreConfig
from src.settings import setting
from langchain_core.prompts import PromptTemplate

cfg = TomlManager(get_gipt_config())


_commit_style = cfg.get(CoreConfig.CORE_COMMIT_STYLE)
_commit_rules = setting.COMMIT_STYLES.get(
    _commit_style, setting.COMMIT_STYLES[CommitStyle.CONVENTIONAL.value]
)

_commit = """You are an expert at writing clear, concise commit messages.

Analyze the git diff output below and generate a commit message following this format:

{_commit_rules}

GUIDELINES:
- Focus on the PRIMARY change (ignore minor whitespace/formatting unless that's the main change)
- Explain WHAT changed and WHY (user impact), not HOW (implementation details)
- If multiple unrelated changes exist, mention the most significant one
- For large diffs (>500 lines), provide a high-level summary
- Identify breaking changes if present

DIFF OUTPUT:
{diff_content}

Generate the commit message now:"""


def get_commit_prompt() -> PromptTemplate:
    return PromptTemplate(
        template=_commit, input_variables=["_commit_rules", "diff_content"]
    ).partial(_commit_rules=_commit_rules)
