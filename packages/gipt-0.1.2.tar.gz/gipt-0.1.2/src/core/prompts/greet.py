# src/core/prompts/greet.py

from langchain_core.prompts import PromptTemplate

from src.core.utils.git_helpers import get_user_name

_greet_prompt = """Greet {username} in EXACTLY this format:

Line 1: Hey {username}! {model_name} here. [emoji]
Line 2: [One-line dev joke git and coding]

Examples:
Hey {username}! {model_name} here. ☕
git push --force on Friday? Living dangerously.

Yo {username}! {model_name} here. 🚀
'Temporary fix' from 2019 says hi.

Sup {username}! {model_name} here. 💀
If it works, don't touch it. Ever.

Now, given model name {model_name} greet {username} (2 lines only):"""


def get_greeting_prompt() -> PromptTemplate:
    return PromptTemplate(
        template=_greet_prompt, input_variables=["model_name"]
    ).partial(username=get_user_name())
