# src/core/utils/git_helpers.py

import subprocess
from pathlib import Path


def get_current_wd_path() -> Path:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            stderr=subprocess.PIPE,
            stdout=subprocess.PIPE,
            text=True,
            check=True,
            encoding="utf-8",
        )

        wd = Path(result.stdout.strip()).absolute()

        return wd
    except subprocess.CalledProcessError as e:
        git_error = e.stderr.strip() if e.stderr else "git init failed"
        raise Exception(git_error)

def get_diff(cached=True):
    """Get git diff - either staged changes or last commit"""

    get_current_wd_path()
    cmd = ["git", "diff"]

    if cached:
        cmd.append("--cached")
    else:
        cmd.extend(["HEAD~1", "HEAD"])

    cmd.extend(
        [
            "--stat",
            "--summary",
            "--function-context",
            "--find-copies-harder",
            "--ignore-cr-at-eol",
            "-U10",
        ]
    )

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        check=True,
    )

    return result.stdout.strip()


def get_user_name():
    get_current_wd_path()

    try:
        result = subprocess.run(
            ["git", "config", "user.name"],
            text=True,
            encoding="utf-8",
            check=True,
            capture_output=True,
        )

        return result.stdout.strip()

    except subprocess.CalledProcessError as e:
        return


def git_add():
    get_current_wd_path()
    try:
        result = subprocess.run(
            ["git", "add", "."], check=True, capture_output=True, text=True
        )
        return True
    except subprocess.CalledProcessError as e:
        raise


def git_commit(commit_msg: str, amend: bool = False, edit: bool = True):
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(delete=False, suffix=".txt", mode="w") as tmp:
        tmp_path = tmp.name
        tmp.write(commit_msg)

    try:
        cmd = ["git", "commit", "-F", tmp_path]
        
        if edit:
            cmd.append("--edit")
        if amend:
            cmd.append("--amend")
        
        subprocess.run(
            cmd, 
            check=True,
            text=True,
            stderr=subprocess.PIPE
        )
        
    except subprocess.CalledProcessError as e:
        git_error = e.stderr.strip() if e.stderr else "git commit failed"
        raise ValueError(git_error)

    finally:
        os.remove(tmp_path)

def get_git():
    return get_current_wd_path() / '.git'

def get_git_hooks():
    return get_git() / 'hooks'