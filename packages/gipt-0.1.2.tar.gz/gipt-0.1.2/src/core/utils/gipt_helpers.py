# src/core/utils/gipt_helpers.py

from enum import Enum
from pathlib import Path
from typing import Optional

import toml
from pydantic import BaseModel, Field, ValidationError

from src.core.enums import CommitStyle, CoreConfig, Provider
from src.core.utils.git_helpers import get_current_wd_path


class CoreSettings(BaseModel):
    provider: Provider = Field(default=Provider.OPENAI)
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    commit_style: CommitStyle = Field(default=CommitStyle.CONVENTIONAL)
    commit_interactive: bool = Field(default=True)
    top_p: float = Field(default=0.3, ge=0.0, le=1.0)


class ProviderSettings(BaseModel):
    class Ollama(BaseModel):
        key_env: Optional[str] = None
        model: Optional[str] = None
        url: Optional[str] = None

    class OpenAI(BaseModel):
        key_env: Optional[str] = None
        model: Optional[str] = None

    class Anthropic(BaseModel):
        key_env: Optional[str] = None
        model: Optional[str] = None

    class Groq(BaseModel):
        key_env: Optional[str] = None
        model: Optional[str] = None

    ollama: Ollama = Ollama()
    openai: OpenAI = OpenAI()
    anthropic: Anthropic = Anthropic()
    groq: Groq = Groq()


class GiptConfig(BaseModel):
    core: CoreSettings = CoreSettings()
    provider: ProviderSettings = ProviderSettings()


class TomlManager:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            self.doc = GiptConfig.model_validate(toml.load(path))
        else:
            raise FileNotFoundError(
                f"Config file not found at '{path}'. Run `gipt init` to create one."
            )

    def get(self, dotted_key: str):
        keys = dotted_key.split(".")
        value = self.doc
        for key in keys:
            value = getattr(value, key)
        return value

    def set(self, dotted_key: str, new_value):
        keys = dotted_key.split(".")
        target = self.doc
        for key in keys[:-1]:
            target = getattr(target, key)
        field_name = keys[-1]

        field_info = target.model_fields.get(field_name)
        if not field_info:
            raise KeyError(f"Unknown field: {dotted_key}")

        try:
            validated = target.model_validate({**target.model_dump(), field_name: new_value})
            setattr(self.doc, keys[0], getattr(self.doc, keys[0]))

            parent = self.doc
            for key in keys[:-1]:
                parent = getattr(parent, key)
            setattr(parent, field_name, getattr(validated, field_name))
        except ValidationError as e:
            raise ValueError(f"Invalid value for {dotted_key}: {e}")

        self.doc = GiptConfig.model_validate(self.doc.model_dump())

        self.save()

        if 'model' in dotted_key:
            try:
                from src.core.gipt import gipt
                from typer import echo
                echo(gipt.greet())
            except Exception as e:
                raise 

    def save(self):
        """Save the TOML document back to file."""

        def clean(value):
            if isinstance(value, Enum):
                return value.value
            elif isinstance(value, dict):
                return {k: clean(v) for k, v in value.items()}
            elif isinstance(value, list):
                return [clean(v) for v in value]
            elif isinstance(value, BaseModel):
                return clean(value.model_dump())
            return value

        cleaned = clean(self.doc)
        self.path.write_text(toml.dumps(cleaned))

    def get_all(self):
        return self.doc.model_dump()


def flatten_dict(d: dict, parent_key: str = '', sep: str = '.'):
    """Flatten nested dictionaries with dot notation."""
    items = {}
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.update(flatten_dict(v, new_key, sep=sep))
        else:
            items[new_key] = v
    return items


def get_gipt() -> Path:
    return get_current_wd_path() / '.gipt'

def get_gipt_config() -> Path:
    return get_gipt() / 'giptconfig'

def get_gipt_hooks() -> Path:
    return get_gipt() / 'hooks'
