# src/cli.py

from importlib.metadata import version
from typing import Optional

from typer import Context, Exit, Option, Typer, echo

from src.commands.commit import app as commit_app
from src.commands.config import app as config_app
from src.commands.init import app as init_app


def version_callback(value: bool) -> str:
    if value:
        echo(f"gipt version {version('gipt')}")
        raise Exit()


app = Typer(name="Gipt", help="Gipt ― AI Git Assistant")

app.add_typer(init_app)
app.add_typer(config_app)
app.add_typer(commit_app)


@app.callback(invoke_without_command=True)
def main(
    ctx: Context,
    version: Optional[bool] = Option(
        None,
        "--version",
        "-v",
        help="Show version and exit",
        callback=version_callback,
        is_eager=True,
    ),
):
    if ctx.invoked_subcommand is None:
        echo(
            "Welcome to Gipt ― AI Git Assistant! Type --help to see available commands."
        )
