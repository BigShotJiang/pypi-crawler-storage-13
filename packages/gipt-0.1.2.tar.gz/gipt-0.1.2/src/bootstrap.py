# src/bootstrap.py

import json
import os
import subprocess
from pathlib import Path


def is_bootstrapped():
    bootstrap_file = Path("~/.gipt/bootstrap.json").expanduser()
    if not bootstrap_file.exists():
        return False
    try:
        data = json.loads(bootstrap_file.read_text())
        return data.get("bootstrapped") is True
    except (json.JSONDecodeError, OSError):
        return False

def bootstrap():
    bootstrap_script = Path(__file__).parent.parent / 'scripts' / 'bootstrap.sh'
    if not bootstrap_script.exists():
        raise FileNotFoundError(f"Bootstrap script deleted or not found.\nYou can found it at: https://github.com/ahmad-alqaisi215/gipt/blob/main/scripts/bootstrap.sh ")

    if not os.access(bootstrap_script, os.X_OK):
        bootstrap_script.chmod(bootstrap_script.stat().st_mode | 0o111)

    subprocess.run([str(bootstrap_script)], check=True)

def mark_as_bootstrapped():
    gipt_dir = Path("~/.gipt").expanduser()
    gipt_dir.mkdir(parents=True, exist_ok=True)
    
    bootstrap_file = gipt_dir / "bootstrap.json"
    bootstrap_file.write_text('{\n    "bootstrapped": true\n}')
