from click import ClickException
from typer import Argument, Option, Typer, echo
import typer

from src.core.enums import CoreConfig
from src.core.utils.gipt_helpers import TomlManager, flatten_dict, get_gipt_config
from src.core.utils.git_helpers import get_current_wd_path
from src.settings import setting

app = Typer()


@app.command(
    help="View or modify gipt configuration",
    rich_help_panel="Configuration",
)
def config(
    ctx: typer.Context,
    global_: bool = Option(
        False,
        "--global",
        help="Use global configuration file",
    ),
    local: bool = Option(
        False,
        "--local",
        help="Use local repository configuration file (default)",
    ),
    list_all: bool = Option(
        False,
        "--list",
        "-l",
        help="List all configuration values",
    ),
    key: CoreConfig = Argument(None, help="Configuration key"),
    value: str = Argument(None, help="New value (omit to read current value)"),
):
    try:
        giptconfig_path = (
            setting.GLOBAL_CONF_PATH
            if global_
            else get_gipt_config()
        )

        cfg = TomlManager(giptconfig_path)

        if global_ and local:
            raise ClickException("Only one config file at a time")

        if list_all:
            if key or value:
                raise ClickException("--list cannot be combined with arguments.")

            flat = flatten_dict(cfg.get_all())
            for k, v in sorted(flat.items()):
                echo(f"{k}={v}")

            return

        if key is None:
            echo(ctx.get_help())
            return

        if value:
            cfg.set(key.value, new_value=value)
            cfg.save()
            echo(f"{key.value}={value}")
        else:
            echo(cfg.get(key.value))

    except Exception as e:
        raise ClickException(str(e))
