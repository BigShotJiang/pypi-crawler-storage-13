# src/commands/init.py

import shutil

import click
from typer import Option, Typer, confirm, echo

from src.core.enums import CommitStyle, CoreConfig, Provider
from src.core.utils.gipt_helpers import TomlManager, get_gipt, get_gipt_config, get_gipt_hooks
from src.core.utils.git_helpers import get_current_wd_path, get_git_hooks
from src.settings import setting

app = Typer()


@app.command(
    help="Initialize Gipt in the current Git repository with default configuration."
    )
def init(
    provider: Provider = Option(
        setting.DEFAULT_PROVIDER,
        "--provider",
        help="AI provider to use",
        rich_help_panel="LLM Config",
    ),
    model: str = Option(
        setting.DEFAULT_MODEL,
        "-m",
        "--model",
        help="Model name and version to use",
        rich_help_panel="LLM Config",
    ),
    temp: float = Option(
        setting.DEFAULT_TEMP,
        "-t",
        "--temp",
        min=0,
        max=2,
        help="Response randomness: 0 <- deterministic, creative -> 2",
        rich_help_panel="LLM Config",
    ),
    p: float = Option(
        setting.DEFAULT_P,
        "-p",
        "--top-p",
        min=0,
        max=1,
        help="Top-p (nucleus) sampling: 0 <- focused, diverse -> 1.",
        rich_help_panel="LLM Config",
    ),
    commit_style: CommitStyle = Option(
        setting.DEFAULT_COMMIT_STYLE,
        "-s",
        "--style",
        help="Commit message style",
        rich_help_panel="Commit Config",
    ),
):
    "Initialize Gipt in the current Git repository with default configuration."
    try:
        wd = get_current_wd_path()
        giptconfig_path_local = get_gipt_config()

        if giptconfig_path_local.exists():
            ans = confirm(
                f"Gipt config already exists at `{giptconfig_path_local}`. Overwrite?",
                default=False,
            )

            if ans:
                echo(
                    f"Gipt re-initialized at `{wd}`: existing config overwritten with default."
                )
            else:
                echo("Operation cancelled by user.")
                return

        else:
            echo(f"Gipt initialized at `{wd}` with default config.")

        shutil.copytree(setting.GIPT_HOME, get_gipt(), dirs_exist_ok=True)
        shutil.copyfile(setting.GLOBAL_CONF_PATH, giptconfig_path_local)
        shutil.copytree(get_gipt_hooks(), get_git_hooks(), dirs_exist_ok=True)

        cfg = TomlManager(giptconfig_path_local)

        cfg.set(CoreConfig.CORE_TOP_P, new_value=p)
        cfg.set(CoreConfig.CORE_PROVIDER, new_value=provider.value)
        cfg.set(CoreConfig.CORE_TEMPERATURE, new_value=temp)
        cfg.set(CoreConfig.CORE_COMMIT_STYLE, new_value=commit_style.value)
        cfg.set(f"provider.{provider.value}.model", new_value=model)

        cfg.save()

    except Exception as e:
        raise click.ClickException(str(e)) 
