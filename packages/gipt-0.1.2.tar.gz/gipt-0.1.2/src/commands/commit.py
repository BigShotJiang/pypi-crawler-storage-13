# src/commands/commit.py

from click import ClickException
from typer import Option, Typer, echo

from src.core.enums import CommitStyle
from src.core.utils.git_helpers import get_diff, git_add, git_commit


app = Typer()


@app.command(name="commit", help="Generate and create AI-powered commit messages from staged changes")
def commit(
    all: bool = Option(
        False, "-a", "--all", help="Stage all changes then commit (like git commit -a)"
    ),
    amend: bool = Option(False, "--amend", help="Amend previous commit with regenerated message"),
    dry_run: bool = Option(
        False, "-n", "--dry-run", help="Preview generated message without committing"
    ),
    commit_style: CommitStyle = Option(None, "-s", "--style", help="Commit message style (conventional, gitmoji, simple)"),
):
    try:
        from src.core.gipt import gipt

        if amend and all:
            raise ClickException(
                "Cannot use --amend with --all (amend doesn't stage new changes)"
            )

        if all:
            git_add()

        commit_msg = ""

        diff = get_diff(not amend)

        if not diff:
            echo("Nothing to commit, working tree clean")
            return

        for chunk in gipt.commit_stream(diff, commit_style):
            echo(chunk, nl=False)
            commit_msg += chunk

        echo()

        if not dry_run:
            git_commit(commit_msg, amend=amend)

    except Exception as e:
         raise ClickException(str(e))
