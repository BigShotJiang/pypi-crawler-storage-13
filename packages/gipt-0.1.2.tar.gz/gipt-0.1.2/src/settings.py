# src/settings.py

from pathlib import Path

from src.core.enums import CommitStyle, CoreConfig, Provider
from src.core.utils.gipt_helpers import TomlManager
from src.bootstrap import is_bootstrapped, bootstrap, mark_as_bootstrapped


class Settings:
    GIPT_HOME = Path("~/.gipt").expanduser()
    GLOBAL_CONF_PATH = GIPT_HOME / "giptconfig"
    GIPT_HOOKS = GIPT_HOME / "hooks"

    def __init__(self) -> None:
        self.DEFAULT_CFG = self._get_cfg_manager()

        self.DEFAULT_PROVIDER: Provider = self.DEFAULT_CFG.get(CoreConfig.CORE_PROVIDER)
        self.DEFAULT_MODEL: str = self.DEFAULT_CFG.get(
            f"provider.{self.DEFAULT_PROVIDER.value}.model"
        )
        self.DEFAULT_TEMP: float = self.DEFAULT_CFG.get(CoreConfig.CORE_TEMPERATURE)
        self.DEFAULT_P: float = self.DEFAULT_CFG.get(CoreConfig.CORE_TOP_P)
        self.DEFAULT_COMMIT_STYLE: CommitStyle = self.DEFAULT_CFG.get(
            CoreConfig.CORE_COMMIT_STYLE
        )
        self.DEFAULT_COMMIT_INTERACTIVE: bool = self.DEFAULT_CFG.get(
            CoreConfig.CORE_COMMIT_INTERACTIVE
        )

    def _get_cfg_manager(self):

        if not is_bootstrapped():
            bootstrap()
            mark_as_bootstrapped()

        return TomlManager(self.GLOBAL_CONF_PATH)

    COMMIT_STYLES = {
        CommitStyle.CONVENTIONAL.value: """
Format: <type>(<scope>)[!]: <subject>

[optional body]

[optional footer(s)]

Note, [!] is optional and it used for BREAKING CHANGES

Types: 
feat     : A new feature                                                                                
fix      : A bug fix                                                                                    
docs     : Documentation only changes                                                                   
style    : Code style / formatting / whitespace only (no logic change)                                  
refactor : Code change that neither fixes a bug nor adds a feature (e.g., restructuring)                
perf     : A code change that improves performance                                                      
test     : Adding or updating tests                                                                     
build    : Changes that affect the build system or external dependencies                                
ci       : Changes to CI configuration files and scripts                                                
chore    : Routine tasks, maintenance, dependency updates (no production code change)


- Subject: max 50 chars, imperative mood ("add" not "added"), no period
- Scope: affected component/module

Examples: 
feat(auth): add OAuth2 social login support

Implemented OAuth2 authentication for Google, GitHub, and Microsoft.
Users can now sign in using their social media accounts.


feat(api)!: migrate user endpoints to v2 REST specification

Restructured all user API endpoints to follow v2 REST conventions.
Response payloads now use snake_case instead of camelCase.

BREAKING CHANGE: All /api/users/* endpoints now return snake_case JSON.
The 'userID' field is now 'user_id', 'createdAt' is now 'created_at'.
Legacy v1 endpoints deprecated in 6 months.
""",
        CommitStyle.SIMPLE.value: """
Format: <subject>

- Single line, max 72 chars
- Start with verb in imperative mood
- Describe the change clearly

Example: Add user authentication middleware
""",
        CommitStyle.GITMOJI.value: """
Format: <emoji>: <subject>

Types: 
🎨 : Improving structure / format of the code.
⚡️ : Improving performance.
🔥 : Removing code or files.
🐛 : Fixing a bug.
🚑 : Critical hotfix.
✨ : Introducing new features.
📝 : Writing docs.
🚀 : Deploying stuff.
💄 : Updating the UI and style files.
🎉 : Initial commit.
✅ : Adding tests.
🔒 : Fixing security issues.
🍎 : Fixing something on macOS.
🐧 : Fixing something on Linux.
🏁 : Fixing something on Windows.
🤖 : Fixing something on Android.
🍏 : Fixing something on iOS.
🔖 : Releasing / Version tags.
🚨 : Removing linter warnings.

- Subject(scope): concise description of change
- Single line, max 80 chars

Example: ✨ (langchain): Add Pinecone vector store integration for LangChain LLM agent
""",
    }


setting = Settings()
