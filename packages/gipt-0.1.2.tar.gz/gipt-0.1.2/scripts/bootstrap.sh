#!/usr/bin/env bash
set -e

# ==========================
# GIPT setup installer script
# ==========================

SYS_DIR="$HOME/.gipt"
SYS_CONFIG_PATH="$SYS_DIR/giptconfig"
SYS_HOOKS_DIR="$SYS_DIR/hooks"
SYS_HOOK_PATH="$SYS_HOOKS_DIR/prepare-commit-msg"

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DEFAULT_CONFIG="$SCRIPT_DIR/.giptconfig"

GIPT_PREPARE_COMMIT_MSG="$SCRIPT_DIR/hooks/prepare-commit-msg"

mkdir -p "$SYS_DIR" "$SYS_HOOKS_DIR"

if [ -f "$DEFAULT_CONFIG" ]; then
    cp "$DEFAULT_CONFIG" "$SYS_CONFIG_PATH"

fi

if [ -f "$GIPT_PREPARE_COMMIT_MSG" ]; then
    cp "$GIPT_PREPARE_COMMIT_MSG" "$SYS_HOOK_PATH"
    chmod +x "$SYS_HOOK_PATH"
fi
