# Gipt 🤖

**AI-native Git assistant integrating intelligent automation into your version control workflow**

[![PyPI](https://img.shields.io/pypi/v/gipt)](https://pypi.org/project/gipt/)
[![Python](https://img.shields.io/pypi/pyversions/gipt)](https://pypi.org/project/gipt/)
[![License](https://img.shields.io/pypi/l/gipt)](https://github.com/ahmad-alqaisi215/gipt/blob/main/LICENSE)
![LangChain](https://img.shields.io/badge/LangChain-🦜-blue)
![Typer](https://img.shields.io/badge/Typer-CLI-red)


Gipt brings artificial intelligence directly into your Git workflow, automating repetitive tasks and enhancing your development experience. Instead of treating AI as an external tool, Gipt integrates seamlessly into your version control lifecycle—from initialization to commits to configuration management.

## ✨ Features

- 🤖 **Multi-Provider AI Support** - Works with Ollama, OpenAI, Anthropic, and Groq
- 📝 **Intelligent Commit Messages** - Generate context-aware commits that follow best practices
- 🎨 **Multiple Commit Styles** - Conventional Commits, Gitmoji, or Simple formats
- 🔧 **Smart Configuration** - Global and repository-level settings with simple CLI management
- 🪝 **Git Hook Integration** - Automatic commit message generation via prepare-commit-msg hook
- 🌊 **Streaming Output** - Real-time message generation with live feedback
- ⚡ **Zero-Configuration Start** - Works out of the box with sensible defaults
- 🎯 **Git-Style Commands** - Familiar command patterns like `gipt commit -a`, `gipt config --list`

## Quick Start

### Installation

```bash
pip install gipt
```

Or with uv:
```bash
uv pip install gipt
```

### Initialize in Your Repository

```bash
cd your-git-repo
gipt init
```

This creates a local `.gipt/config` file with default settings and optionally installs a Git hook for automatic commit message generation.

### Generate Your First Commit

```bash
# Make some changes
echo "new feature" > feature.txt
git add feature.txt

# Generate and commit with AI
gipt commit
```

That's it! Gipt analyzes your changes and creates an intelligent commit message.

## Usage

### Basic Commands

```bash
# Initialize in repository
gipt init

# Generate commit (preview only)
gipt commit --dry-run

# Stage all and commit
gipt commit --all

# Amend last commit
gipt commit --amend

# Use specific style
gipt commit --style gitmoji
```

### Configuration

```bash
# List all settings
gipt config --list

# View specific setting
gipt config core.provider

# Update setting (local)
gipt config core.provider anthropic

# Update global setting
gipt config --global core.temperature 0.9
```

### Quick Setup Examples

```bash
# Initialize with OpenAI
gipt init --provider openai --model gpt-4-turbo-preview

# Initialize with Anthropic and gitmoji style
gipt init --provider anthropic --style gitmoji

# Initialize with custom temperature
gipt init --temp 1.2
```

**For detailed documentation, see [docs/usage.md](docs/usage.md)**

## Git Hook Integration

Gipt can automatically generate commit messages when you run `git commit`:

```bash
# Install hook during init
gipt init

# Or manually copy hook
cp ~/.gipt/hooks/prepare-commit-msg .git/hooks/
chmod +x .git/hooks/prepare-commit-msg

# Now git commit opens editor with AI-generated message
git add .
git commit  # Message auto-generated!

# Override with manual message
git commit -m "manual message"

```

## 🧠 AI Providers

Gipt works with multiple AI providers out of the box:

| Provider | Setup | Example |
|----------|-------|---------|
| **Ollama** (default) | No API key needed | `gipt config provider.ollama.model gemma3:latest` |
| **OpenAI** | `export OPENAI_API_KEY="sk-..."` | `gipt config core.provider openai` |
| **Anthropic** | `export ANTHROPIC_API_KEY="sk-ant-..."` | `gipt config core.provider anthropic` |
| **Groq** | `export GROQ_API_KEY="gsk_..."` | `gipt config core.provider groq` |

Configure your preferred provider:
```bash
gipt config core.provider anthropic
gipt config provider.anthropic.model claude-sonnet-4-20250514
```

## Commit Styles

Gipt supports three formats:

**Conventional Commits** (default) - Structured, semantic commits
```
feat(api): add user authentication endpoint

Implemented JWT-based authentication with refresh tokens.
```

**Gitmoji** - Visual commit messages with emojis
```
✨ Add user authentication endpoint

```

**Simple** - Clean, straightforward messages
```
Add user authentication endpoint

```

Change style: `gipt config core.commit_style gitmoji`

## Configuration

**Locations:**
- Global: `~/.gipt/config` - User-wide defaults
- Local: `.gipt/config` - Repository-specific settings

See [docs/usage.md](docs/usage.md) for all available settings.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

### Development Setup

```bash
# Clone repository
git clone https://github.com/ahmad-alqaisi215/gipt.git
cd gipt

# Install in development mode with dev dependencies
pip install -e ".[dev]"

# Run gipt
gipt --version
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Built with [LangChain](https://github.com/langchain-ai/langchain) for AI integration
- CLI powered by [Typer](https://github.com/tiangolo/typer)
- Inspired by the [Conventional Commits](https://www.conventionalcommits.org/) specification

## Links

- **GitHub:** https://github.com/ahmad-alqaisi215/gipt
- **PyPI:** https://pypi.org/project/gipt/

## Why Gipt?

Let's be honest—most developers don't enjoy the administrative side of version control. We love writing code, but documenting changes, crafting meaningful commit messages, and maintaining repository hygiene? Not so much. It's common to work for hours on a feature, accumulate dozens of changes, and then face that familiar moment:

```bash
$ git add .
$ git commit -m "fix stuff"
```

Sound familiar?

Version control systems are filled with repetitive, tedious tasks that distract from actual development. Gipt was created with a simple question: **What if an AI agent could work alongside Git?**

Not just generating commit messages (though that's a great start), but truly understanding your changes, monitoring repository evolution, providing context-aware suggestions, and helping maintain a clean, organized codebase. Think of Gipt as your intelligent version control companion—automating the boring parts so you can focus on what matters: building great software.

---

Made with ❤️ by [Ahmad Alqaisi](https://github.com/ahmad-alqaisi215)