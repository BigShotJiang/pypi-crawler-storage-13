# Usage Guide

Complete guide to using Gipt - AI-native Git assistant.

## Table of Contents

- [Installation](#installation)
- [Commands](#commands)
  - [gipt init](#gipt-init)
  - [gipt commit](#gipt-commit)
  - [gipt config](#gipt-config)
- [Configuration](#configuration)
- [Environment Variables](#environment-variables)
- [Git Hook Integration](#git-hook-integration)
- [Commit Styles](#commit-styles)
- [Troubleshooting](#troubleshooting)

---

## Installation

### From PyPI

```bash
pip install gipt
```

Or with uv:
```bash
uv pip install gipt
```

### From Source

```bash
git clone https://github.com/ahmad-alqaisi215/gipt.git
cd gipt
pip install -e ".[dev]"
```

### Verify Installation

```bash
gipt --version
```

---

## Commands

### gipt init

Initialize Gipt in your Git repository with default or custom configuration.

#### Syntax

```bash
gipt init [OPTIONS]
```

#### Options

**LLM Configuration:**
- `--provider [ollama|openai|anthropic|groq]` - AI provider to use (default: `ollama`)
- `--model`, `-m TEXT` - Model name and version (default: `gemma3:latest`)
- `--temp`, `-t FLOAT` - Response randomness, 0-2 (default: `0.7`)
- `--top-p`, `-p FLOAT` - Top-p (nucleus) sampling, 0-1 (default: `0.3`)

**Commit Configuration:**
- `--style`, `-s [conventional|gitmoji|simple]` - Commit message style (default: `conventional`)

#### Examples

```bash
# Basic initialization with defaults
gipt init

# Initialize with OpenAI
gipt init --provider openai --model gpt-4-turbo-preview

# Initialize with Anthropic and gitmoji style
gipt init --provider anthropic --model claude-sonnet-4-20250514 --style gitmoji

# More creative commits
gipt init --temp 1.2

# Combine multiple options
gipt init --provider groq --model llama-3.1-70b-versatile --style conventional --temp 0.8
```

#### What It Does

1. Creates `.gipt/config` file in your repository
2. Copies configuration from global settings (`~/.gipt/config`)
3. Installs `prepare-commit-msg` Git hook (optional)
4. Sets up provider-specific settings

---

### gipt commit

Generate AI-powered commit messages from staged changes.

#### Syntax

```bash
gipt commit [OPTIONS]
```

#### Options

- `-a`, `--all` - Stage all changes then commit (like `git commit -a`)
- `--amend` - Amend previous commit with regenerated message
- `-n`, `--dry-run` - Preview generated message without committing
- `-s`, `--style [conventional|gitmoji|simple]` - Commit message style for this commit only

#### Examples

```bash
# Preview commit message (no actual commit)
gipt commit --dry-run

# Stage all changes and commit
gipt commit --all

# Commit staged changes
git add file.txt
gipt commit

# Amend last commit with new message
gipt commit --amend

# Use gitmoji style for this commit
gipt commit --style gitmoji

# Preview with different style
gipt commit --dry-run --style simple

# Stage all, preview, then decide
gipt commit -a --dry-run
```

#### Workflow

1. **Analyze Changes**: Gipt reads your staged changes (or last commit if `--amend`)
2. **Generate Message**: AI creates a commit message based on the diff
3. **Stream Output**: Message is displayed in real-time as it's generated
4. **Commit**: Changes are committed with the generated message (unless `--dry-run`)

#### Flag Combinations

| Flags | Result |
|-------|--------|
| `gipt commit` | Commit staged changes |
| `gipt commit -a` | Stage all + commit |
| `gipt commit -n` | Preview only (no commit) |
| `gipt commit --amend` | Regenerate last commit message |
| `gipt commit -a -n` | Stage all + preview |
| `gipt commit --amend -n` | Preview amended message |

---

### gipt config

View or modify Gipt configuration at global or local level.

#### Syntax

```bash
gipt config [KEY] [VALUE] [OPTIONS]
```

#### Options

- `--global` - Use global configuration file (`~/.gipt/config`)
- `--local` - Use local repository configuration file (`.gipt/config`) - **default**
- `-l`, `--list` - List all configuration values

#### Configuration Keys

**Core Settings:**
- `core.provider` - AI provider (`ollama`, `openai`, `anthropic`, `groq`)
- `core.temperature` - Response randomness (0.0-2.0)
- `core.top_p` - Top-p sampling (0.0-1.0)
- `core.commit_style` - Default commit style (`conventional`, `gitmoji`, `simple`)

**Provider Settings:**

*Ollama:*
- `provider.ollama.model` - Model name (e.g., `gemma3:latest`)
- `provider.ollama.url` - Server URL (default: `http://localhost:11434`)

*OpenAI:*
- `provider.openai.model` - Model name (e.g., `gpt-4-turbo-preview`)
- `provider.openai.key_env` - Environment variable name (default: `OPENAI_API_KEY`)

*Anthropic:*
- `provider.anthropic.model` - Model name (e.g., `claude-sonnet-4-20250514`)
- `provider.anthropic.key_env` - Environment variable name (default: `ANTHROPIC_API_KEY`)

*Groq:*
- `provider.groq.model` - Model name (e.g., `llama-3.1-70b-versatile`)
- `provider.groq.key_env` - Environment variable name (default: `GROQ_API_KEY`)

#### Examples

**Viewing Configuration:**

```bash
# List all local settings
gipt config --list

# List all global settings
gipt config --global --list

# View specific setting (local)
gipt config core.provider

# View specific setting (global)
gipt config --global core.temperature
```

**Updating Configuration:**

```bash
# Set AI provider (local)
gipt config core.provider anthropic

# Set AI provider (global)
gipt config --global core.provider openai

# Change model
gipt config provider.anthropic.model claude-sonnet-4-20250514

# Adjust creativity
gipt config core.temperature 0.9

# Set commit style
gipt config core.commit_style gitmoji

# Configure Ollama URL
gipt config provider.ollama.url http://192.168.1.100:11434
```

#### Configuration Hierarchy

**Priority (highest to lowest):**
1. Local config (`.gipt/config`) - Repository-specific
2. Global config (`~/.gipt/config`) - User-wide defaults

Local settings override global settings.

---

## Configuration

### Configuration Files

**Global Configuration:**
- Location: `~/.gipt/config`
- Scope: All repositories for your user
- Created by: Bootstrap script or first `gipt init`

**Local Configuration:**
- Location: `.gipt/config` (in repository root)
- Scope: Current repository only
- Created by: `gipt init`

### Example Configuration File

```toml
[core]
provider = "anthropic"
temperature = 0.7
top_p = 0.3
commit_style = "conventional"

[provider.anthropic]
key_env = "ANTHROPIC_API_KEY"
model = "claude-sonnet-4-20250514"

[provider.openai]
key_env = "OPENAI_API_KEY"
model = "gpt-4-turbo-preview"

[provider.ollama]
model = "gemma3:latest"
url = "http://localhost:11434"

[provider.groq]
key_env = "GROQ_API_KEY"
model = "llama-3.1-70b-versatile"
```

### Configuration Parameters

**Temperature (0.0 - 2.0):**
- `0.0` - Deterministic, focused, consistent
- `0.7` - Balanced (recommended)
- `1.5+` - Creative, varied, experimental

**Top-p (0.0 - 1.0):**
- `0.1` - Very focused, limited vocabulary
- `0.3` - Balanced (recommended)
- `0.9+` - Diverse, exploratory

---

## Environment Variables

Gipt uses environment variables for API authentication.

### Required Variables by Provider

**OpenAI:**
```bash
export OPENAI_API_KEY="sk-..."
```

**Anthropic:**
```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

**Groq:**
```bash
export GROQ_API_KEY="gsk_..."
```

**Ollama:**
```bash
# No API key needed for local Ollama
# Optionally customize URL in config
```

### Setting Environment Variables

**Temporarily (current session):**
```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

**Permanently (add to shell config):**
```bash
# For bash
echo 'export ANTHROPIC_API_KEY="sk-ant-..."' >> ~/.bashrc
source ~/.bashrc

# For zsh
echo 'export ANTHROPIC_API_KEY="sk-ant-..."' >> ~/.zshrc
source ~/.zshrc
```

**Verify:**
```bash
echo $ANTHROPIC_API_KEY
```

---

## Git Hook Integration

Gipt can automatically generate commit messages when you run `git commit`.

### How It Works

The `prepare-commit-msg` hook:
1. Detects when you run `git commit`
2. Analyzes your staged changes
3. Generates an AI-powered commit message
4. Opens your editor with the message pre-filled
5. Lets you review/edit before finalizing

### Installation

**Automatic (recommended):**
```bash
gipt init  # Hook installed automatically
```

**Manual:**
```bash
# Copy from gipt home
cp ~/.gipt/hooks/prepare-commit-msg .git/hooks/
chmod +x .git/hooks/prepare-commit-msg
```

### Usage

**With Hook Installed:**
```bash
# Regular commit - message auto-generated
git add .
git commit
# Opens editor with AI-generated message

# Provide your own message - hook bypassed
git commit -m "manual message"

# Skip hook temporarily
git commit --no-verify
```

### Hook Behavior

| Command | Hook Behavior |
|---------|---------------|
| `git commit` | ✅ Generates message |
| `git commit -m "msg"` | ❌ Uses your message |
| `git commit --amend` | ✅ Regenerates message |
| `git commit --no-verify` | ❌ Skips hook |
| `git merge` | ❌ Uses merge message |
| `git rebase` | ❌ Uses rebase message |

---

## Commit Styles

Gipt supports three commit message formats.

### Conventional Commits (Default)

Follows the [Conventional Commits](https://www.conventionalcommits.org/) specification.

**Format:**
```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types:**
- `feat` - New feature
- `fix` - Bug fix
- `docs` - Documentation changes
- `style` - Code style changes (formatting, etc.)
- `refactor` - Code refactoring
- `perf` - Performance improvements
- `test` - Adding or updating tests
- `chore` - Maintenance tasks
- `ci` - CI/CD changes
- `build` - Build system changes

**Example:**
```
feat(api): add user authentication endpoint

Implemented JWT-based authentication with refresh tokens.
Added middleware for token validation and user session management.

BREAKING CHANGE: Authentication now required for all API endpoints.
```

**Enable:**
```bash
gipt config core.commit_style conventional
```

### Gitmoji

Visual commit messages using [Gitmoji](https://gitmoji.dev/) emojis.

**Common Emojis:**
- ✨ - New feature
- 🐛 - Bug fix
- 📝 - Documentation
- 🎨 - Code style/format
- ♻️ - Refactoring
- ⚡ - Performance
- ✅ - Tests
- 🔧 - Configuration
- 🚀 - Deployment

**Example:**
```
✨ Add user authentication endpoint

Implemented JWT-based authentication with refresh tokens.
🔒 Added middleware for token validation and user session management.
```

**Enable:**
```bash
gipt config core.commit_style gitmoji
```

### Simple

Clean, straightforward commit messages without strict formatting.

**Format:**
```
<Summary>

<Optional detailed description>
```

**Example:**
```
Add user authentication endpoint

Implemented JWT-based authentication with refresh tokens and 
session management middleware. Updated API documentation.
```

**Enable:**
```bash
gipt config core.commit_style simple
```

### Changing Style Per Commit

Override the default style for a single commit:

```bash
# Your default is conventional, but use gitmoji for this commit
gipt commit --style gitmoji

# Preview with simple style
gipt commit --dry-run --style simple
```

---

## Troubleshooting

### "Not a git repository"

**Problem:** Running gipt commands outside a Git repository.

**Solution:**
```bash
# Initialize git first
git init

# Then initialize gipt
gipt init
```

### "No API key found"

**Problem:** Missing API key for selected provider.

**Solution:**
```bash
# Set the appropriate environment variable
export ANTHROPIC_API_KEY="sk-ant-..."

# Or switch to Ollama (no key needed)
gipt config core.provider ollama
```

### "No staged changes" / "Nothing to commit"

**Problem:** No files staged for commit.

**Solution:**
```bash
# Stage specific files
git add file1.txt file2.txt

# Or stage all changes
git add .

# Then commit
gipt commit
```

### Ollama Connection Error

**Problem:** Cannot connect to Ollama server.

**Solutions:**

```bash
# 1. Make sure Ollama is running
ollama serve

# 2. Check if model is downloaded
ollama list

# 3. Pull model if needed
ollama pull gemma3:latest

# 4. Verify connection
curl http://localhost:11434/api/tags

# 5. If using custom URL, update config
gipt config provider.ollama.url http://192.168.1.100:11434
```

### "Command 'gipt' not found"

**Problem:** Gipt not in PATH after installation.

**Solutions:**

```bash
# 1. Verify installation
pip list | grep gipt

# 2. If not installed, install it
pip install gipt

# 3. If installed but not found, check PATH
which gipt

# 4. Try running with python -m
python -m gipt --version

# 5. Reinstall in user directory
pip install --user gipt
```

### Commits Are Too Generic

**Problem:** AI generates vague or uninformative commit messages.

**Solutions:**

```bash
# 1. Increase temperature for more detail
gipt config core.temperature 0.9

# 2. Stage smaller, focused changes
git add specific_file.txt
gipt commit

# 3. Use --dry-run to iterate
gipt commit --dry-run
# Make adjustments, try again

# 4. Try a different provider/model
gipt config core.provider anthropic
gipt config provider.anthropic.model claude-sonnet-4-20250514
```

### Hook Not Working

**Problem:** Git hook doesn't trigger or generate messages.

**Solutions:**

```bash
# 1. Check hook is installed
ls -la .git/hooks/prepare-commit-msg

# 2. Check hook is executable
chmod +x .git/hooks/prepare-commit-msg

# 3. Verify hook content
cat .git/hooks/prepare-commit-msg

# 4. Test gipt command directly
gipt commit --dry-run

# 5. Reinstall hook
cp ~/.gipt/hooks/prepare-commit-msg .git/hooks/
chmod +x .git/hooks/prepare-commit-msg
```

### Rate Limit / API Errors

**Problem:** API provider returns rate limit or quota errors.

**Solutions:**

```bash
# 1. Switch to Ollama (local, no limits)
gipt config core.provider ollama

# 2. Check your API quota/billing
# Visit provider's dashboard

# 3. Wait and retry
# Most rate limits reset quickly

# 4. Use different provider temporarily
gipt config core.provider groq
```

---

## Tips & Best Practices

### 1. Start with Dry Run

Always preview messages before committing:
```bash
gipt commit --dry-run
```

### 2. Commit Small, Focused Changes

Smaller diffs produce better commit messages:
```bash
# Good
git add feature.py
gipt commit

# Less ideal
git add .  # 50 files changed
gipt commit
```

### 3. Use Different Styles for Different Projects

```bash
# Personal projects - simple style
gipt config --global commit_style simple

# Work projects - conventional commits
cd work-repo
gipt config commit_style conventional
```

### 4. Customize Temperature Per Project

```bash
# Creative project - higher temperature
cd creative-app
gipt config core.temperature 1.2

# Critical system - lower temperature
cd production-api
gipt config core.temperature 0.5
```

### 5. Combine with Git Aliases

```bash
# Add to ~/.gitconfig
[alias]
    ac = "!git add -A && gipt commit"
    acd = "!git add -A && gipt commit --dry-run"
```

Then use:
```bash
git ac   # Stage all and commit with gipt
git acd  # Stage all and preview message
```

---

## Getting Help

### Command Help

```bash
# General help
gipt --help

# Command-specific help
gipt init --help
gipt commit --help
gipt config --help
```

### Version Information

```bash
gipt --version
```

### Report Issues

Found a bug or have a feature request?

- GitHub Issues: https://github.com/ahmad-alqaisi215/gipt/issues
- Include: Gipt version, OS, Python version, error messages

---

## More Resources

- **GitHub Repository:** https://github.com/ahmad-alqaisi215/gipt
- **PyPI Package:** https://pypi.org/project/gipt/
- **Changelog:** https://github.com/ahmad-alqaisi215/gipt/blob/main/CHANGELOG.md