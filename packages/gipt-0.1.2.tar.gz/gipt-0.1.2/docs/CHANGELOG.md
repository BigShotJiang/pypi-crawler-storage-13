# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2025-11-10

### Added
- Initial release of Gipt
- AI-powered commit message generation
- Multi-provider support (Ollama, OpenAI, Anthropic, Groq)
- Three commit styles: Conventional, Gitmoji, Simple
- Global and local configuration system
- `gipt init` command for repository setup
- `gipt commit` command with --all, --amend, --dry-run flags
- `gipt config` command for settings management
- Git hook integration via prepare-commit-msg
- Streaming output for real-time message generation

[0.1.0]: https://github.com/ahmad-alqaisi215/gipt/releases/tag/v0.1.0