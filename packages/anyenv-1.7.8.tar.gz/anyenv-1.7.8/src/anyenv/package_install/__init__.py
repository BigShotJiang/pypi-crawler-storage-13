"""Package installation utilities."""
