from .logger import VersaLog

__copyright__ = "Copyright 2025 by Kayu0514"
__version__ = "1.7.2"
__author__ = "Kayu0514"
__url__ = "https://github.com/kayu0514"

__all__ = ["VersaLog"]