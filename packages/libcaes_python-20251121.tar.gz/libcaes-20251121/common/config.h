/* common/config.h.  Generated from config.h.in by configure.  */
/* common/config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if translation of program messages to the user's native
   language is requested. */
#define ENABLE_NLS 1

/* Define to 1 if you have the `AES_cbc_encrypt' function". */
/* #undef HAVE_AES_CBC_ENCRYPT */

/* Define to 1 if you have the `AES_ecb_encrypt' function". */
/* #undef HAVE_AES_ECB_ENCRYPT */

/* Define to 1 if you have the Mac OS X function
   CFLocaleCopyPreferredLanguages in the CoreFoundation framework. */
/* #undef HAVE_CFLOCALECOPYPREFERREDLANGUAGES */

/* Define to 1 if you have the Mac OS X function CFPreferencesCopyAppValue in
   the CoreFoundation framework. */
/* #undef HAVE_CFPREFERENCESCOPYAPPVALUE */

/* Define if the GNU dcgettext() function is already present or preinstalled.
   */
#define HAVE_DCGETTEXT 1

/* Define to 1 if you have the declaration of 'memrchr', and to 0 if you
   don't. */
#define HAVE_DECL_MEMRCHR 0

/* Define to 1 if you have the declaration of 'strerror_r', and to 0 if you
   don't. */
#define HAVE_DECL_STRERROR_R 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 to enable the DllMain function. */
/* #undef HAVE_DLLMAIN */

/* Define to 1 if you have the `EVP_CipherInit_ex2' function". */
#define HAVE_EVP_CIPHERINIT_EX2 1

/* Define to 1 if you have the `EVP_CIPHER_CTX_cleanup' function". */
/* #undef HAVE_EVP_CIPHER_CTX_CLEANUP */

/* Define to 1 if you have the `EVP_CIPHER_CTX_init' function". */
/* #undef HAVE_EVP_CIPHER_CTX_INIT */

/* Define to 1 if you have the `EVP_aes_128_cbc', `EVP_aes_192_cbc' and
   `EVP_aes_256_cbc' functions". */
#define HAVE_EVP_CRYPTO_AES_CBC 1

/* Define to 1 if you have the `EVP_aes_128_ecb', `EVP_aes_192_ecb' and
   `EVP_aes_256_ecb' functions". */
#define HAVE_EVP_CRYPTO_AES_ECB 1

/* Define to 1 if you have the `EVP_aes_128_xts' and `EVP_aes_256_xts'
   functions". */
#define HAVE_EVP_CRYPTO_AES_XTS 1

/* Define to 1 if you have the 'fclose' function. */
#define HAVE_FCLOSE 1

/* Define to 1 if you have the 'feof' function. */
#define HAVE_FEOF 1

/* Define to 1 if you have the 'fgets' function. */
#define HAVE_FGETS 1

/* Define to 1 if you have the 'fgetws' function. */
#define HAVE_FGETWS 1

/* Define to 1 if you have the 'fmemopen' function. */
#define HAVE_FMEMOPEN 1

/* Define to 1 if you have the 'fopen' function. */
#define HAVE_FOPEN 1

/* Define to 1 if you have the 'fread' function. */
#define HAVE_FREAD 1

/* Define to 1 if you have the 'free' function. */
#define HAVE_FREE 1

/* Define to 1 if you have the 'fseeko' function. */
#define HAVE_FSEEKO 1

/* Define to 1 if you have the 'fseeko64' function. */
#define HAVE_FSEEKO64 1

/* Define to 1 if you have the 'fwrite' function. */
#define HAVE_FWRITE 1

/* Define to 1 if you have the 'getopt' function. */
#define HAVE_GETOPT 1

/* Define if the GNU gettext() function is already present or preinstalled. */
#define HAVE_GETTEXT 1

/* Define to 1 if dlsym function is available in GNU dl. */
#define HAVE_GNU_DL_DLSYM 1

/* Define if you have the iconv() function and it works. */
/* #undef HAVE_ICONV */

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the `cerror' library (-lcerror). */
/* #undef HAVE_LIBCERROR */

/* Define to 1 if you have the <libcerror.h> header file. */
/* #undef HAVE_LIBCERROR_H */

/* Define to 1 if you have the 'crypto' library (-lcrypto). */
#define HAVE_LIBCRYPTO 1

/* Define to 1 if you have the 'dl' library (-ldl). */
#define HAVE_LIBDL 1

/* Define to 1 if you have the <libintl.h> header file. */
#define HAVE_LIBINTL_H 1

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if the local version of libcerror is used. */
#define HAVE_LOCAL_LIBCERROR 1

/* Define to 1 if you have the 'malloc' function. */
#define HAVE_MALLOC 1

/* Define to 1 if you have the 'memchr' function. */
#define HAVE_MEMCHR 1

/* Define to 1 if you have the 'memcmp' function. */
#define HAVE_MEMCMP 1

/* Define to 1 if you have the 'memcpy' function. */
#define HAVE_MEMCPY 1

/* Define to 1 if you have the 'memrchr' function. */
#define HAVE_MEMRCHR 1

/* Define to 1 if you have the 'memset' function. */
#define HAVE_MEMSET 1

/* Define to 1 if you have the 'mkstemp' function. */
#define HAVE_MKSTEMP 1

/* Define to 1 if you have the <openssl/aes.h> header file. */
/* #undef HAVE_OPENSSL_AES_H */

/* Define to 1 if you have the <openssl/evp.h> header file. */
#define HAVE_OPENSSL_EVP_H 1

/* Define to 1 if you have the <openssl/opensslv.h> header file. */
/* #undef HAVE_OPENSSL_OPENSSLV_H */

/* Define to 1 whether printf supports the conversion specifier "%jd". */
#define HAVE_PRINTF_JD 1

/* Define to 1 whether printf supports the conversion specifier "%zd". */
#define HAVE_PRINTF_ZD 1

/* Define to 1 if you have the <Python.h> header file. */
/* #undef HAVE_PYTHON_H */

/* Define to 1 if you have the 'realloc' function. */
#define HAVE_REALLOC 1

/* Define to 1 if you have the 'setenv' function. */
#define HAVE_SETENV 1

/* Define to 1 if you have the 'snprintf' function. */
#define HAVE_SNPRINTF 1

/* Define to 1 if you have the 'sscanf' function. */
#define HAVE_SSCANF 1

/* Define to 1 if you have the <stdarg.h> header file. */
#define HAVE_STDARG_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the 'strcasecmp' function. */
#define HAVE_STRCASECMP 1

/* Define to 1 if you have the 'strchr' function. */
#define HAVE_STRCHR 1

/* Define to 1 if you have the 'strerror' function. */
/* #undef HAVE_STRERROR */

/* Define if you have 'strerror_r'. */
#define HAVE_STRERROR_R 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the 'strlen' function. */
#define HAVE_STRLEN 1

/* Define to 1 if you have the 'strncasecmp' function. */
#define HAVE_STRNCASECMP 1

/* Define to 1 if you have the 'strncmp' function. */
#define HAVE_STRNCMP 1

/* Define to 1 if you have the 'strncpy' function. */
#define HAVE_STRNCPY 1

/* Define to 1 if you have the 'strnicmp' function. */
/* #undef HAVE_STRNICMP */

/* Define to 1 if you have the 'strrchr' function. */
#define HAVE_STRRCHR 1

/* Define to 1 if you have the 'strstr' function. */
#define HAVE_STRSTR 1

/* Define to 1 if you have the 'swprintf' function. */
#define HAVE_SWPRINTF 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the 'towlower' function. */
#define HAVE_TOWLOWER 1

/* Define to 1 if you have the 'tzset' function. */
#define HAVE_TZSET 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the 'unlink' function. */
#define HAVE_UNLINK 1

/* Define to 1 if you have the <varargs.h> header file. */
/* #undef HAVE_VARARGS_H */

/* Define to 1 if you have the 'vfprintf' function. */
#define HAVE_VFPRINTF 1

/* Define to 1 if you have the 'vsnprintf' function. */
#define HAVE_VSNPRINTF 1

/* Define to 1 if you have the <wchar.h> header file. */
#define HAVE_WCHAR_H 1

/* Define to 1 if you have the 'wcscasecmp' function. */
#define HAVE_WCSCASECMP 1

/* Define to 1 if you have the 'wcschr' function. */
#define HAVE_WCSCHR 1

/* Define to 1 if you have the 'wcslen' function. */
#define HAVE_WCSLEN 1

/* Define to 1 if you have the 'wcsncasecmp' function. */
#define HAVE_WCSNCASECMP 1

/* Define to 1 if you have the 'wcsncmp' function. */
#define HAVE_WCSNCMP 1

/* Define to 1 if you have the 'wcsncpy' function. */
#define HAVE_WCSNCPY 1

/* Define to 1 if you have the 'wcsnicmp' function. */
/* #undef HAVE_WCSNICMP */

/* Define to 1 if you have the 'wcsrchr' function. */
#define HAVE_WCSRCHR 1

/* Define to 1 if you have the 'wcsstr' function. */
#define HAVE_WCSSTR 1

/* Define to 1 if you have the 'wcstombs' function. */
#define HAVE_WCSTOMBS 1

/* Define to 1 if you have the <wctype.h> header file. */
#define HAVE_WCTYPE_H 1

/* Define to 1 if wide character type should be used. */
/* #undef HAVE_WIDE_CHARACTER_TYPE */

/* Define to 1 if you have the <windows.h> header file. */
/* #undef HAVE_WINDOWS_H */

/* Define to 1 if you have the 'wmemchr' function. */
#define HAVE_WMEMCHR 1

/* Define to 1 if you have the 'wmemcmp' function. */
#define HAVE_WMEMCMP 1

/* Define to 1 if you have the 'wmemcpy' function. */
#define HAVE_WMEMCPY 1

/* Define to 1 if you have the 'wmemrchr' function. */
/* #undef HAVE_WMEMRCHR */

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "libcaes"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "joachim.metz@gmail.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "libcaes"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "libcaes 20251121"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "libcaes"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "20251121"

/* The size of 'int', as computed by sizeof. */
#define SIZEOF_INT 4

/* The size of 'long', as computed by sizeof. */
#define SIZEOF_LONG 8

/* The size of 'off_t', as computed by sizeof. */
#define SIZEOF_OFF_T 8

/* The size of 'size_t', as computed by sizeof. */
#define SIZEOF_SIZE_T 8

/* The size of 'wchar_t', as computed by sizeof. */
#define SIZEOF_WCHAR_T 4

/* Define to 1 if all of the C89 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Define to 1 if strerror_r returns char *. */
/* #undef STRERROR_R_CHAR_P */

/* Version number of package */
#define VERSION "20251121"

/* Number of bits in a file offset, on hosts where this is settable. */
/* #undef _FILE_OFFSET_BITS */

/* Define to 1 on platforms where this makes off_t a 64-bit type. */
/* #undef _LARGE_FILES */

/* Number of bits in time_t, on hosts where this is settable. */
/* #undef _TIME_BITS */

/* Define to 1 on platforms where this makes time_t a 64-bit type. */
/* #undef __MINGW_USE_VC2005_COMPAT */

/* Define to empty if 'const' does not conform to ANSI C. */
/* #undef const */

/* Define to 'int' if <sys/types.h> does not define. */
/* #undef mode_t */

/* Define to 'long int' if <sys/types.h> does not define. */
/* #undef off_t */

/* Define as 'unsigned int' if <stddef.h> doesn't define. */
/* #undef size_t */

/* Define to empty if the keyword 'volatile' does not work. Warning: valid
   code using 'volatile' can become incorrect without. Disable with care. */
/* #undef volatile */
