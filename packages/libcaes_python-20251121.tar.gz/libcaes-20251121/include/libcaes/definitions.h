/*
 * Definitions for libcaes
 *
 * Copyright (C) 2011-2025, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBCAES_DEFINITIONS_H )
#define _LIBCAES_DEFINITIONS_H

#include <libcaes/types.h>

#define LIBCAES_VERSION			20251121

/* The version string
 */
#define LIBCAES_VERSION_STRING		"20251121"

/* The crypt modes
 */
enum LIBCAES_CRYPT_MODES
{
	LIBCAES_CRYPT_MODE_DECRYPT	= 0,
	LIBCAES_CRYPT_MODE_ENCRYPT	= 1
};

#endif /* !defined( _LIBCAES_DEFINITIONS_H ) */

