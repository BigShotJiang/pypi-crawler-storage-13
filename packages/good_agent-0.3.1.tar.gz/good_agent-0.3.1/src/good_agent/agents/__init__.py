"""Built-in reference agents."""
