"""
Modèles de données (dataclasses)
"""
