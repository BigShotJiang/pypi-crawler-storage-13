"""
Aetheris by Adryan - Système d'analyse de code multi-agents
"""

__version__ = "1.1.0"
