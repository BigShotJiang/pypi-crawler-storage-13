"""
Agents d'analyse spécialisés
"""
