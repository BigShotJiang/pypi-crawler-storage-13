from typing import Any, Generic
from collections.abc import Sequence
from core_validator import Validator
from core_validator.types import TError, TValidationData, ValidationError


class ValidatorManager(Generic[TValidationData, TError]):
    def __init__(
        self,
        validators: Sequence[Validator[TValidationData, Any]],
    ) -> None:
        self._validators = validators

    async def setup(self) -> None: ...

    async def dispose(self) -> None: ...

    async def _get_available_validators(
        self,
        validation_data: TValidationData,
    ) -> Sequence[Validator[TValidationData, TError]]:
        return [
            item for item in self._validators if await item.can_apply(validation_data)
        ]

    async def errors(self, validation_data: TValidationData) -> Sequence[TError]:
        await self.setup()

        available_validators = await self._get_available_validators(validation_data)
        all_errors: list[TError] = []
        for validator in available_validators:
            errors = await validator.errors(validation_data)
            all_errors.extend(errors)

        await self.dispose()
        return all_errors

    async def validate(self, validation_data: TValidationData) -> None:
        await self.setup()

        available_validators = await self._get_available_validators(validation_data)
        errors: list[TError] = []
        for validator in available_validators:
            try:
                await validator.validate(validation_data)
            except ValidationError as exc:
                errors.extend(exc.messages)

        await self.dispose()

        if errors:
            raise ValidationError(errors)
