from dataclasses import dataclass
from typing import Literal, TypeAlias
from unittest.mock import patch

import pytest
from core_validator.manager import ValidatorManager
from core_validator.types import ValidationError
from core_validator.validator import Validator, validate

pytestmark = [pytest.mark.anyio]


class CustomError(Exception): ...


Errors: TypeAlias = CustomError | ZeroDivisionError


@dataclass(frozen=True, slots=True, kw_only=True)
class Context:
    number: int
    type: Literal["one", "zero"]


class _OneNumberValidator1(Validator[Context, CustomError]):
    async def can_apply(self, validation_data: Context) -> bool:
        return validation_data.type == "one"

    @validate
    def _validate_number(self) -> None:
        if self.data.number == 1:
            self.context.add_error(CustomError("Got 1 number"))


class _OneNumberValidator2(Validator[Context, CustomError]):
    async def can_apply(self, validation_data: Context) -> bool:
        return validation_data.type == "one"

    @validate
    def _validate_number(self) -> None:
        if self.data.number == 1:
            self.context.add_error(CustomError("Got 1 number"))


class _ZeroNumberValidator(Validator[Context, ZeroDivisionError]):
    async def can_apply(self, validation_data: Context) -> bool:
        return validation_data.type == "zero"

    @validate
    def _validate_number(self) -> None:
        if self.data.number == 0:
            self.context.add_error(ZeroDivisionError("Got 0 number"))


@pytest.fixture
async def manager() -> ValidatorManager[Context, Errors]:
    return ValidatorManager[Context, Errors](
        validators=[
            _OneNumberValidator1(),
            _OneNumberValidator2(),
            _ZeroNumberValidator(),
        ]
    )


async def test_validate_manager_ok(manager: ValidatorManager[Context, Errors]) -> None:
    with patch.object(
        _ZeroNumberValidator,
        "_validate_number",
        return_value=None,
    ) as mock:
        errors = await manager.errors(Context(number=3, type="one"))

    assert not errors
    mock.assert_not_called()


async def test_validate_manager_with_err(
    manager: ValidatorManager[Context, Errors],
) -> None:
    errors = await manager.errors(Context(number=1, type="one"))
    assert errors

    expected_length = 2
    assert len(errors) == expected_length

    exc_1, exc_2 = errors
    assert isinstance(exc_1, CustomError)
    assert isinstance(exc_2, CustomError)


async def test_validate_manager_with_err_raised(
    manager: ValidatorManager[Context, Errors],
) -> None:
    with pytest.raises(ValidationError) as raised:
        await manager.validate(Context(number=1, type="one"))

    assert isinstance(exc := raised.value, ValidationError)

    expected_length = 2
    assert len(exc.messages) == expected_length

    exc_1, exc_2 = exc.messages
    assert isinstance(exc_1, CustomError)
    assert isinstance(exc_2, CustomError)


async def test_validate_manager_errors(
    manager: ValidatorManager[Context, Errors],
) -> None:
    await manager.validate(Context(number=888, type="one"))
