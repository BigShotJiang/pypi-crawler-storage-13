# toon/accessor.py
"""
Pandas DataFrame accessor for TOON format.

Allows calling `df.toon.to_toon(...)` directly on a DataFrame.
"""

from __future__ import annotations
from typing import Any, TextIO
import pandas as pd

from ._toon import to_toon  # standalone writer function


@pd.api.extensions.register_dataframe_accessor("toon")
class ToonAccessor:
    """
    Pandas DataFrame accessor for TOON format.

    Usage:
        df.toon.to_toon(path_or_buf="output.toon", format_type="tabular_array")
    """

    def __init__(self, pandas_obj: pd.DataFrame):
        self._obj = pandas_obj

    def to_toon(
        self,
        file_path: str | TextIO | None = None,
        **kwargs: Any
    ) -> str | None:
        """
        Convert this DataFrame to TOON format string or write to a file.

        Parameters
        ----------
        path_or_buf : str | file-like | None, optional
            If None → returns TOON string.
            If string or file-like → writes TOON output to it.
        **kwargs : dict
            Additional parameters passed to `to_toon()`:
                - table_name, delimiter, indent, length_marker, format_type, return_message

        Returns
        -------
        str | None
            - Returns TOON string if `file_path` is None.
            - Returns None if writing to a file (or success message if `return_message=True`).
        """
        # Call standalone to_toon function with self._obj DataFrame
        return to_toon(self._obj, file_path, **kwargs)
