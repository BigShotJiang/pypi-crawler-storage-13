

from __future__ import annotations
from typing import TYPE_CHECKING
from abc import ABC, abstractmethod
import re
from pandas import DataFrame


# ==============================================================================
# Abstract Base Writer
# ==============================================================================
class ToonBaseWriter(ABC):
    """Abstract base class for TOON format writers."""
    
    def __init__(
        self,
        df: "DataFrame",
        table_name: str | None = None,
        delimiter: str = ",",
        indent: int = 2,
        length_marker: str = ""
    ) -> None:
        self.df = df.reset_index(drop=True) if df is not None else None
        self.table_name = table_name or ""
        self.delimiter = delimiter
        self.indent = indent
        self.length_marker = length_marker
    
    @abstractmethod
    def write(self) -> str:
        """Write the DataFrame to TOON format string."""
        pass


# ==============================================================================
# Basic Tabular Writer
# ==============================================================================
class ToonTabularBasicWriter(ToonBaseWriter):
    """Writer for basic tabular TOON format (flat structure)."""
    
    def write(self) -> str:
        """Write basic tabular format: table[N,]{col1,col2,...}:"""
        #print(f"Delimiter: {self.delimiter} , Length marker: {self.length_marker}, Table name: {self.table_name}, Indent: {self.indent}")
        N = len(self.df)
        cols = [str(c) for c in self.df.columns]
        header_cols = self.delimiter.join(cols)
        
        inside = "" if self.delimiter == "," else self.delimiter
        header = (
            f"{self.table_name}[{self.length_marker}{N}{inside}]{{{header_cols}}}:"
            if self.table_name
            else f"[{self.length_marker}{N}{inside}]{{{header_cols}}}:"
        )
        
        lines = [header]
        row_indent=" " * self.indent  # Indentation for rows
        for _, row in self.df.iterrows():
            vals = [str(v) if v is not None and v == v else "" for v in row]
            line= self.delimiter.join(vals)
            lines.append(row_indent + line)  # <-- INDENT APPLIED
        
        return "\n".join(lines)


# ==============================================================================
# Nested Tabular Writer
# ==============================================================================
class ToonTabularNestedWriter(ToonBaseWriter):
    """Writer for nested tabular TOON format (hierarchical structure)."""
    
    def __init__(
        self,
        df: "DataFrame",
        table_name: str | None = None,
        delimiter: str = ",",
        indent: int = 2,
        length_marker: str = "",
    ) -> None:
        super().__init__(df, table_name, delimiter, indent, length_marker)
    
    def write(self) -> str:
        """Write nested tabular format."""
        lines = []
        N = len(self.df)
        inside = "" if self.delimiter == "," else self.delimiter
        
        header = (
            f"{self.table_name}[{self.length_marker}{N}{inside}]:"
            if self.table_name
            else f"[{self.length_marker}{N}{inside}]:"
        )
        
        lines.append(header)
        
        for _, row in self.df.iterrows():
            nested = self._row_to_nested_dict(row)
            #print(f"Nested dict for row:\n{nested}")
            body = self._format_record_lines(nested, level=1)
            #print(f"Formatted lines for row:\n{body}")
            
            if body:
                # First line starts with dash
                body[0] = "- " + body[0].lstrip()
                for b in body:
                    lines.append("  " + b)
            else:
                lines.append("  -")
        
        return "\n".join(lines).rstrip()
    
    def _row_to_nested_dict(self, row) -> dict:
        """Convert a flat row to nested dictionary structure."""
        result = {}
        
        for col, val in row.items():
            # Skip None or NaN
            if val is None or (isinstance(val, float) and val != val):
                continue
            
            col = str(col)
            
            # Check for primitive list stored as delimited string
            if (isinstance(val, str) and "," in val and 
                "[" not in col and "_" not in col and "." not in col):
                result[col] = val.split(",")
                continue
            
            # Parse array patterns: base[idx].rest or base_idx.rest
            array_match = (
                re.match(r"(.+?)\[(\d+)\](?:\.(.+))?$", col)
                or re.match(r"(.+?)_(\d+)(?:\.(.+))?$", col)
            )
            
            if array_match:
                base_path, idx_str, rest = array_match.groups()
                idx = int(idx_str)
                
                # Split base_path by dots to handle nested paths
                path_parts = base_path.split(".")
                
                # Navigate to parent object
                current = result
                for part in path_parts[:-1]:
                    if part not in current:
                        current[part] = {}
                    current = current[part]
                
                # Create/extend array at final path part
                array_key = path_parts[-1]
                if array_key not in current:
                    current[array_key] = []
                
                while len(current[array_key]) <= idx:
                    current[array_key].append({})
                
                target = current[array_key][idx]
                
                if rest:
                    # Recursively set nested properties
                    self._set_nested(target, rest.split("."), val)
                else:
                    # Primitive value in array
                    current[array_key][idx] = val
                continue
            
            # Dot notation for nested objects
            if "." in col:
                self._set_nested(result, col.split("."), val)
            else:
                # Top-level primitive
                result[col] = val
        
        return result
    
    def _set_nested(self, obj: dict, path: list[str], value):
        """Recursively set value at nested path."""
        for p in path[:-1]:
            # Check if path segment contains array index
            array_match = (
                re.match(r"(.+?)\[(\d+)\]$", p) or 
                re.match(r"(.+?)_(\d+)$", p)
            )
            
            if array_match:
                key, idx_str = array_match.groups()
                idx = int(idx_str)
                
                if key not in obj:
                    obj[key] = []
                while len(obj[key]) <= idx:
                    obj[key].append({})
                
                obj = obj[key][idx]
            else:
                if p not in obj:
                    obj[p] = {}
                obj = obj[p]
        
        # Set final value
        final_key = path[-1]
        array_match = (
            re.match(r"(.+?)\[(\d+)\]$", final_key) or 
            re.match(r"(.+?)_(\d+)$", final_key)
        )
        
        if array_match:
            key, idx_str = array_match.groups()
            idx = int(idx_str)
            if key not in obj:
                obj[key] = []
            while len(obj[key]) <= idx:
                obj[key].append({})
            obj[key][idx] = value
        else:
            obj[final_key] = value
    
    def _format_record_lines(self, data, level=0) -> list[str]:
        """Recursively format nested data structure."""
        lines = []
        base = " " * (self.indent * level)
        
        if isinstance(data, dict):
            for key, value in data.items():
                #print(f"Processing key: {key} at level {level} with value type: {type(value)}")
                # Primitive list (simple values)
                if isinstance(value, list) and all(
                    not isinstance(v, (dict, list)) for v in value
                ):
                    joined = self.delimiter.join(str(v) for v in value)
                    inside = "" if self.delimiter == "," else self.delimiter
                    lines.append(
                        f"{base}{key}[{self.length_marker}{len(value)}{inside}]: {joined}"
                    )
                    #print(f"Added primitive list for key: {key} with values: {joined}")
                    continue
                
                # Object list (list of dictionaries)
                if isinstance(value, list) and any(isinstance(v, dict) for v in value):
                    inside = "" if self.delimiter == "," else self.delimiter
                    #print(f"Processing object list for key: {key} with {len(value)} items")
                    
                    # Check if all items are simple objects (for compact format)
                    all_simple = all(
                        isinstance(v, dict) and 
                        all(not isinstance(val, (dict, list)) for val in v.values())
                        for v in value if isinstance(v, dict)
                    )
                    
                    if all_simple and len(value) > 0:
                        # Compact tabular format
                        fields = sorted(
                            {f for obj in value if isinstance(obj, dict) for f in obj.keys()}
                        )
                        field_str = self.delimiter.join(fields)
                        lines.append(
                            f"{base}{key}[{self.length_marker}{len(value)}{inside}]{{{field_str}}}:"
                        )
                        row_indent = " " * (self.indent * (level + 1))
                        for obj in value:
                            row_vals = [str(obj.get(f, "")) for f in fields]
                            lines.append(f"{row_indent}{self.delimiter.join(row_vals)}")
                            #print(f"Added compact row for key: {key} with values: {row_vals}")
                    else:
                        #print(f"Using nested format for key: {key}")
                        # Nested format for complex objects
                        lines.append(
                            f"{base}{key}[{self.length_marker}{len(value)}{inside}]:"
                        )
                        array_indent = " " * (self.indent * (level + 1))
                        for item in value:
                            nested_lines = self._format_record_lines(item, level + 2)
                            #print(f"Nested lines for item in key: {key}:\n{nested_lines}")
                            if nested_lines:
                                nested_lines[0] = array_indent + "- " + nested_lines[0].lstrip()
                                for i, line in enumerate(nested_lines):
                                    if i == 0:
                                        lines.append(nested_lines[0])
                                    else:
                                        lines.append(line)
                    continue
                
                # Nested dict
                if isinstance(value, dict):
                    #print(f"Processing nested dict for key: {key}")
                    lines.append(f"{base}{key}:")
                    lines.extend(self._format_record_lines(value, level + 1))
                    continue
                
                # Primitive value - check if contains delimiter
                if isinstance(value, str) and self.delimiter in value:
                    #print(f"Processing delimited string for key: {key}")
                    items = [item.strip() for item in value.split(self.delimiter)]
                    inside = "" if self.delimiter == "," else self.delimiter
                    lines.append(
                        f"{base}{key}[{self.length_marker}{len(items)}{inside}]: {value}"
                    )
                else:
                    #print(f"Processing primitive value for key: {key}")
                    lines.append(f"{base}{key}: {value}")
        
        return lines

