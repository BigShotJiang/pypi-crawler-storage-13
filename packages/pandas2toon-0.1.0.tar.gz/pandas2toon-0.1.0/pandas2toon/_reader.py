#toon/_reader.py
from __future__ import annotations
from typing import List
import pandas as pd

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False

from ._tabular_reader import ToonTabularBasicParser, ToonTabularNestedParser


# ----------------------------
# Custom Errors
# ----------------------------
class EmptyTOONError(Exception):
    """Raised when TOON file is empty."""
    pass

class InvalidTOONFormatError(Exception):
    """Raised when TOON format_type is invalid."""
    pass


# ----------------------------
# TOON Reader
# ----------------------------
class ToonReader:
    def __init__(self, file_path, flatten_nested=False, nested_depth=0, format_type="object"):
        self.file_path = file_path  # store it
        self.flatten_nested = flatten_nested
        self.nested_depth = nested_depth
        self.format_type = format_type.lower()
        ...
    def read(self) -> pd.DataFrame:
        """Read the TOON file and return a pandas DataFrame."""

        fpb = self.file_path
        data = None

        # -------------------------------
        # Handle normal path or buffer
        # -------------------------------
        try:
            if isinstance(fpb, str):
                # Basic Python file reader (NO pandas-core)
                with open(fpb, "r") as f:
                    data = f.read()
            else:
                # Assume a file-like buffer
                data = fpb.read()

            # Split into non-empty lines
            lines = [line for line in data.splitlines() if line.strip()]

            if not lines:
                raise EmptyTOONError("Empty TOON file")

            # ---------------------------
            # Validate format_type
            # ---------------------------
            valid_types = ["object", "primitive_array", "tabular_array", "mixed_array"]

            if self.format_type not in valid_types:
                raise ValueError(
                    f"Invalid format_type: {self.format_type}. Expected one of {valid_types}"
                )

            # ---------------------------
            # Dispatch parser
            # ---------------------------
            if self.format_type == "object":
                raise NotImplementedError(
                    f"Format type '{self.format_type}' is not implemented yet."
                )

            elif self.format_type == "primitive_array":
                raise NotImplementedError(
                    "Primitive array format parsing is not implemented yet."
                )

            elif self.format_type == "tabular_array":
                # DO NOT pass self again
                return self.tabular_array_parser(lines)

            elif self.format_type == "mixed_array":
                raise NotImplementedError(
                    "Mixed array format parsing is not implemented yet."
                )

            # Safety fallback
            raise TypeError("Failed to read TOON file.")

        finally:
            # If the user passed a file buffer, we DO NOT close it
            # This matches pandas behavior (caller owns the buffer)
            pass

    # ------------------------
    # Parser helpers
    # ------------------------
    def tabular_array_parser(self, lines: List[str]) -> pd.DataFrame:
        """Parse tabular array TOON format."""
        header_line = lines[0]
        
        if self._is_nested_format(header_line):
            parser = ToonTabularNestedParser(
                lines, self.flatten_nested, self.nested_depth, self.format_type
            )
        else:
            parser = ToonTabularBasicParser(
                lines, self.flatten_nested, self.nested_depth, self.format_type
            )
        
        data = parser.parse()
        return data # pd.DataFrame(data)
    
    @staticmethod
    def _is_nested_format(header_line: str) -> bool:
        """Check if header indicates nested format."""
        return "]:" in header_line and "{" not in header_line
