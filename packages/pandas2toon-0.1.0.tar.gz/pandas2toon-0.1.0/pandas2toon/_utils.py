
# ==============================================================================
# pandas_toon/_utils.py
# ==============================================================================
"""
Utility functions for TOON format.
"""

from __future__ import annotations

import re
from typing import Any


def validate_toon_file(filepath: str) -> bool:
    """Validate if a file is a valid TOON format file."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            first_line = f.readline().strip()
        
        basic_pattern = r"^(?:\w+)?\[\#?\d+[^\]]*\]\{[^\}]+\}:"
        nested_pattern = r"^(?:\w+)?\[\#?\d+[^\]]*\]:"
        
        return bool(
            re.match(basic_pattern, first_line) or 
            re.match(nested_pattern, first_line)
        )
    except Exception:
        return False


def get_toon_info(filepath: str) -> dict[str, Any]:
    """Extract metadata from TOON file without full parsing."""
    with open(filepath, 'r', encoding='utf-8') as f:
        header_line = f.readline().strip()
    
    basic_pattern = r"^(?P<table_name>\w+)?\[(?P<marker>#)?(?P<N>\d+)(?P<delimiter>[^\]]+)?\]\{(?P<columns>[^\}]+)\}:"
    match = re.match(basic_pattern, header_line)
    
    if match:
        delimiter = match.group('delimiter') or ','
        return {
            'format': 'basic',
            'table_name': match.group('table_name'),
            'row_count': int(match.group('N')),
            'delimiter': delimiter,
            'has_length_marker': match.group('marker') == '#',
            'columns': [col.strip() for col in match.group('columns').split(delimiter)]
        }
    
    nested_pattern = r"^(?P<table_name>\w+)?\[(?P<marker>#)?(?P<N>\d+)(?P<delimiter>[^\]]+)?\]:"
    match = re.match(nested_pattern, header_line)
    
    if match:
        return {
            'format': 'nested',
            'table_name': match.group('table_name'),
            'row_count': int(match.group('N')),
            'delimiter': match.group('delimiter') or ',',
            'has_length_marker': match.group('marker') == '#',
            'columns': None
        }
    
    raise ValueError(f"Invalid TOON header format: {header_line}")
