# toon/_toon.py
from __future__ import annotations

import os
import warnings
from typing import TYPE_CHECKING, TextIO

if TYPE_CHECKING:
    from pandas import DataFrame

from ._reader import ToonReader
from ._writer import ToonWriter


# ======================================================
# READ TOON → DataFrame
# ======================================================
def read_toon(
    file_path: str | TextIO,
    *,
    flatten_nested: bool = False,
    nested_depth: int = 0,
    format_type: str = "tabular_array"
) -> "DataFrame":
    """
    Read a TOON file or buffer into a pandas DataFrame.

    Parameters
    ----------
    file_path : str | file-like
        Path to the TOON file or a file-like object.
    flatten_nested : bool, optional
        Whether to flatten nested structures.
    nested_depth : int, optional
        Maximum depth to flatten.
    format_type : str, optional
        Reader format mode ("object", "tabular", etc.)

    Returns
    -------
    DataFrame
    """
    reader = ToonReader(
        file_path=file_path,
        flatten_nested=flatten_nested,
        nested_depth=nested_depth,
        format_type=format_type,
    )
    return reader.read()


# ======================================================
# WRITE TOON ← DataFrame
# ======================================================
def to_toon(
    df: "DataFrame",
    file_path: str | TextIO | None = None,
    *,
    table_name: str | None = None,
    delimiter: str = ",",
    indent: int = 2,
    length_marker: str = "",
    format_type: str = "tabular_array",
    return_message: bool = False,
) -> str | None:
    """
    Convert a DataFrame to TOON format string or write to file.

    Parameters
    ----------
    df : DataFrame
        Input DataFrame.
    file_path : str | file-like, optional
        If provided, writes TOON output to the given path or buffer.
        If None, returns the TOON-formatted string.
    table_name : str, optional
        Optional table name header in TOON format.
    delimiter : str, default ","
        Column separator for TOON table mode.
    indent : int, default 2
        Indentation for nested structures.
    length_marker : str, default ""
        Marker for length-prefixed fields ("", "#").
    format_type : str, default "auto"
        TOON formatting mode ("auto", "tabular_array", etc.)
    return_message : bool, default False
        If True, return a success message when saving to file.

    Returns
    -------
    str | None
        - Returns TOON-formatted string if `path_or_buf=None`
        - Returns None when writing to file
        - Returns success message if `return_message=True`
    """

    # ------------------------------------------------
    # VALIDATION
    # ------------------------------------------------
    if delimiter not in [",", "|", "\t", "\\t"]:
        warnings.warn(f"Using non-standard delimiter '{delimiter}'.", UserWarning)

    if indent < 0:
        raise ValueError(f"indent must be >= 0, got {indent}")

    if length_marker not in ["", "#"]:
        raise ValueError(f"length_marker must be '' or '#', got '{length_marker}'")

    # ------------------------------------------------
    # CREATE WRITER & GENERATE STRING
    # ------------------------------------------------
    writer = ToonWriter(
        df=df,
        file_path=None,   # generate TOON string internally
        table_name=table_name,
        delimiter=delimiter,
        indent=indent,
        length_marker=length_marker,
        format_type=format_type,
    )

    toon_str = writer.write()

    # ------------------------------------------------
    # WRITE TO FILE IF SPECIFIED
    # ------------------------------------------------
    if file_path is not None:

        if isinstance(file_path, str):
            # String filename → write to disk
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(toon_str)

            if return_message:
                abs_path = os.path.abspath(file_path)
                return f"TOON file successfully saved at: {abs_path}"

        else:
            # File-like object
            file_path.write(toon_str)

            if return_message:
                return "TOON data successfully written to buffer."

        return None  # Standard pandas behavior when writing to file

    # ------------------------------------------------
    # RETURN STRING IF NO FILE GIVEN
    # ------------------------------------------------

    if file_path is None and return_message:
        # print(f"return_message=True has no effect when file_path=None.")
        warnings.warn(
            "return_message=True has no effect when file_path=None.",
            UserWarning,
        )

    return toon_str 
