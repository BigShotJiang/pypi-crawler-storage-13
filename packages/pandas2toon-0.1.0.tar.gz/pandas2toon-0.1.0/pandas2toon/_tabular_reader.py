

# ==============================================================================
#toon/_tabular_reader.py
# ==============================================================================
"""
Reader and parser classes for TOON format.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
import re
import warnings

import pandas as pd
DataFrame = pd.DataFrame 

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False



class ToonParser(ABC):
    """Abstract base class for TOON parsers."""
    
    def __init__(
        self,
        lines: list[str],
        flatten_nested: bool = False,
        nested_depth: int = 0,
        format_type: str = "object",
    ) -> None:
        self.lines = lines
        self.header_line = lines[0].strip()
        self.data_lines = lines[1:]

        self.flatten_nested = flatten_nested
        self.nested_depth = nested_depth
        self.format_type = format_type
    
    @abstractmethod
    def parse(self) -> DataFrame:
        """Parse the TOON data and return a DataFrame."""
        pass
    
    @staticmethod
    def normalize_delimiter(delimiter: str | None) -> str:
        """Normalize delimiter string to actual character."""
        if not delimiter:
            return ","
        
        # delimiter = delimiter
        
        if delimiter in ["\\t", "tab", "\t", " "]:
            return '<TAB>'
        elif delimiter in ["|", "pipe"]:
            return "|"
        elif delimiter in [",", "comma"]:
            return ","
        else:
            #print(f"Using custom delimiter: {delimiter}")
            return delimiter


class ToonTabularBasicParser(ToonParser):
    """Parser for tabular basic TOON format."""
    #print("Loaded ToonTabularBasicParser")
    
    HEADER_PATTERN = r"^(?P<table_name>\w+)?\[#?(?P<lengthMarker>\d+)?(?P<N>\d+)(?P<delimiter>[^\]]+)?\]\{(?P<columns>[^\}]+)\}:"
    def __init__(self, lines, flatten_nested=False, nested_depth=0, format_type="object"):
        super().__init__(lines, flatten_nested, nested_depth, format_type)
    
    def parse(self) -> DataFrame:
        """Parse tabular basic format TOON data."""
        #print(f"Header Line inside preview [ToonTabularBasicParser]: {self.header_line}")
        
        match = re.search(self.HEADER_PATTERN, self.header_line)
        #print(f"Regex match object: {match}")
        #print(f"Header Line: ", self.header_line)
        if not match:
            raise ValueError(
                f"Invalid TOON header format: {self.header_line}\n"
                f"Expected format: [table_name][N<delimiter>]{{columns}}:"
            )
        
        table_name = match.group("table_name")
        lengthMarker = int(match.group("lengthMarker")) if match.group("lengthMarker") else None
        N = int(match.group("N"))
        delimiter = self.normalize_delimiter(match.group("delimiter"))
        columns_str = match.group("columns")
        
        columns = [col.strip() for col in columns_str.split(delimiter)]
        
        data = []
        for i, row in enumerate(self.data_lines, 1):
            row = row.strip()
            if row:
                row_data = [field.strip() for field in row.split(delimiter)]
                
                if len(row_data) != len(columns):
                    warnings.warn(
                                f"Row {i} has {len(row_data)} fields but expected {len(columns)}.",
                                UserWarning,
                                stacklevel=2,  # caller দেখানোর জন্য
                            )
                                            
                data.append(row_data)
        
        if len(data) != N:
            warnings.warn(
                f"Expected {N} rows but found {len(data)}.",
                UserWarning,
                stacklevel=2,
            )
        
        df = DataFrame(data, columns=columns)

        
        df.attrs["table_name"] = table_name
        df.attrs["lengthMarker"] = lengthMarker
        df.attrs["N"] = N
        df.attrs["delimiters"] = delimiter
        df.attrs["format_type"] = self.format_type
        df.attrs["flatten_nested"] = self.flatten_nested
        df.attrs["nested_depth"] = self.nested_depth


        return df

# class ToonTabularNestedParser(ToonParser):
#     """Parser for tabular nested TOON format with depth control."""
#     #print("Loaded ToonTabularNestedParser")
    
#     HEADER_PATTERN = r"^(?P<table_name>\w+)?\[#?(?P<lengthMarker>\d+)?(?P<N>\d+)(?P<delimiter>[^\]]+)?\]:"
    
#     def __init__(self, lines: list[str], flatten_nested: bool = False, nested_depth: int = 0, format_type: str = "object") -> None:
#         super().__init__(lines)
#         self.flatten = flatten_nested
#         self.nested_depth = nested_depth  # 0 = unlimited, N = flatten N levels only
#         self.format_type = format_type

    
#     def parse(self) -> DataFrame:
#         """Parse tabular nested format TOON data."""
#         if not HAS_YAML:
#             raise ImportError(
#                 "Nested TOON format requires PyYAML. "
#                 "Install it with: pip install pyyaml"
#             )
#         #print(f"Header Line inside preview [ToonTabularNestedParser]: {self.header_line}")
        
#         match = re.search(self.HEADER_PATTERN, self.header_line)
#         #print(f"Regex match object: {match}")
#         #print(f"Header Line: ", self.header_line)
        
#         if not match:
#             raise ValueError(
#                 f"Invalid nested TOON header format: {self.header_line}\n"
#                 f"Expected format: [table_name][N<delimiter>]:"
#             )
        
#         self.table_name = match.group("table_name")
#         self.lengthMarker = int(match.group("lengthMarker")) if match.group("lengthMarker") else None
#         self.N = int(match.group("N"))
#         self.delimiter = self.normalize_delimiter(match.group("delimiter"))
#         #print(f"Parsed header - table_name: {self.table_name}, lengthMarker: {self.lengthMarker}, N: {self.N}, delimiter: '{type(match.group("delimiter"))}'")
        
#         yaml_content = "\n".join(self.data_lines)
        
#         try:
#             data = yaml.safe_load(yaml_content)
#         except yaml.YAMLError as e:
#             raise ValueError(f"Failed to parse YAML content: {e}")
        
#         if data is None:
#             data = []
#         elif not isinstance(data, list):
#             raise ValueError(f"Expected a list of records, got {type(data).__name__}")
        
#         if len(data) != self.N:
#             warnings.warn(
#                 f"Expected {self.N} rows but found {len(data)}.",
#                 UserWarning,
#                 stacklevel=2,
#             )
        
#         if self.flatten and data:
#             flattened_data = [
#                 self._flatten_dict(
#                     record, 
#                     max_depth=self.nested_depth, 
#                     current_depth=0, 
#                     delimiter=self.delimiter
#                 ) 
#                 for record in data
#             ]
#             df = pd.DataFrame(flattened_data)
#         else:
#             df = pd.DataFrame(data)
        
        
#         df.attrs["table_name"] = self.table_name
#         df.attrs["lengthMarker"] = self.lengthMarker
#         df.attrs["N"] = self.N
#         df.attrs["delimiter"] = self.delimiter
#         df.attrs["format_type"] = self.format_type
#         df.attrs["flatten_nested"] = self.flatten
#         df.attrs["nested_depth"] = self.nested_depth
        
#         return df
    

#     @staticmethod
#     def _flatten_dict(d: dict, parent_key: str = "", sep: str = ".", max_depth: int = 0, 
#                      current_depth: int = 0, delimiter: str = ",") -> dict:
#         """
#         Flatten nested dictionary and lists (arrays) recursively with depth control.
        
#         Handles:
#         - Nested dictionaries at any depth
#         - Nested lists/arrays at any depth
#         - Mixed nested structures (dict in list in dict in list, etc.)
#         - Special field specifications like {id,name} for parsing structured strings
#         - Handle delimiter correctly in nested parsing
#         - Array size markers like [2], [3] which are cleaned from output keys
#         - Depth limiting: when max_depth is reached, stop flattening
#         - If max_depth is 0, flatten completely
#         - If max_depth is N > 0, flatten only N levels deep
        
#         Args:
#             d: Dictionary to flatten
#             parent_key: Key prefix from parent levels
#             sep: Separator for nested keys (default: ".")
#             max_depth: Maximum depth to flatten (0 = unlimited)
#             current_depth: Current nesting level
#             delimiter: Delimiter for parsing structured strings
        
#         Returns:
#             Flattened dictionary with dot-notation keys
#         """
#         items = []
#         # if delimiter.strip() == "<TAB>":
#         #     #print("Using tab delimiter")
        
#         # Check if we've reached max depth (if max_depth > 0)
#         if max_depth > 0 and current_depth >= max_depth:
#             # Stop flattening, return as-is
#             key = parent_key if parent_key else "data"
#             #print(f"Max depth {max_depth} reached at key: {key}. Stopping flattening.")
#             return {key: d}
        
#         for k, v in d.items():
#             # Clean the key: remove array size markers [N] and field specs {field1,field2}
#             # clean_key = re.sub(r'\[\d+\]', '', k)  # Remove [2], [3], etc.
#             # Remove keys like [2|], [3\t], [N|], etc.
#             # clean_key = re.sub(r'\[\d+[|\t]*\]', '', k)
#             clean_key = re.sub(r'\[\d+[|\t]*\]', '', k)
#             # Extract field specification before removing it (e.g., {id,name})
#             field_match = re.search(r'\{([^}]+)\}', k)
#             field_names = None
#             if field_match:
#                 field_names = [f.strip() for f in field_match.group(1).split(delimiter)]
#                 #print("Found field specification:", field_names)
#                 clean_key = re.sub(r'\{[^}]+\}', '', clean_key)  # Remove field spec
            
#             # Build the new key
#             #print(f"Processing key: {k} -> clean key: {clean_key}")
#             new_key = f"{parent_key}{sep}{clean_key}" if parent_key else clean_key

            
#             # Process the value based on its type
#             if isinstance(v, list):
#                 #print(f"Processing value at key: {v}")
#                 items.extend(
#                     ToonTabularNestedParser._process_list(
#                         v, new_key, field_names, sep, max_depth, current_depth + 1, delimiter
#                     )
#                 )
#             elif isinstance(v, dict):
#                 #print(f"Processing value at key: {v}")
#                 items.extend(
#                     ToonTabularNestedParser._process_dict(
#                         v, new_key, sep, max_depth, current_depth + 1, delimiter
#                     )
#                 )
#             elif isinstance(v, str) and field_names and (" " in v or delimiter in v):
#                 #print(f"Processing value at key: {v}")
#                 # Handle case where list was converted to space-separated string
#                 items.extend(
#                     ToonTabularNestedParser._parse_multivalue_string(
#                         v, new_key, field_names, sep, max_depth, current_depth + 1, delimiter
#                     )
#                 )
#             else:
#                 # Primitive value (string, int, float, bool, None, etc.)
#                 #print(f"Processing value at key: {v}")
#                 #print(f"delimiter used: {delimiter}")
#                 if isinstance(v, str):
#                     v= v.replace(delimiter, ",")
#                 items.append((new_key, v))
        
#         return dict(items)


#     @staticmethod
#     def _process_list(lst: list, parent_key: str, field_names: list[str] | None, sep: str, 
#                      max_depth: int = 0, current_depth: int = 0, delimiter: str = ",") -> list[tuple]:
#         """
#         Process a list recursively with depth control.
        
#         Args:
#             lst: List to process
#             parent_key: Key prefix for this list
#             field_names: Optional field names for parsing structured strings
#             sep: Separator for nested keys
#             max_depth: Maximum depth to flatten (0 = unlimited)
#             current_depth: Current nesting level
#             delimiter: Delimiter for parsing structured strings
        
#         Returns:
#             List of (key, value) tuples
#         """
#         items = []
        
#         # Check if we've reached max depth
#         if max_depth > 0 and current_depth >= max_depth:
#             # Stop flattening, return list as-is
#             items.append((parent_key, lst))
#             return items
        
#         for i, item in enumerate(lst):
#             array_key = f"{parent_key}_{i}"
            
#             if isinstance(item, dict):
#                 # Dictionary inside list - recurse
#                 flattened = ToonTabularNestedParser._flatten_dict(
#                     item, array_key, sep, max_depth, current_depth, delimiter
#                 )
#                 items.extend(flattened.items())
                
#             elif isinstance(item, list):
#                 # List inside list - recurse deeper
#                 items.extend(
#                     ToonTabularNestedParser._process_list(
#                         item, array_key, None, sep, max_depth, current_depth + 1, delimiter
#                     )
#                 )
                
#             elif isinstance(item, str) and field_names and delimiter in item:
#                 # Structured string like "5|E" with field specification
#                 items.extend(
#                     ToonTabularNestedParser._parse_structured_string(
#                         item, array_key, field_names, sep, delimiter
#                     )
#                 )
                
#             else:
#                 # Primitive value
#                 items.append((array_key, item))
        
#         return items


#     @staticmethod
#     def _process_dict(d: dict, parent_key: str, sep: str, 
#                      max_depth: int = 0, current_depth: int = 0, delimiter: str = ",") -> list[tuple]:
#         """
#         Process a dictionary recursively with depth control.
        
#         Args:
#             d: Dictionary to process
#             parent_key: Key prefix for this dict
#             sep: Separator for nested keys
#             max_depth: Maximum depth to flatten (0 = unlimited)
#             current_depth: Current nesting level
#             delimiter: Delimiter for parsing structured strings
        
#         Returns:
#             List of (key, value) tuples
#         """
#         flattened = ToonTabularNestedParser._flatten_dict(
#             d, parent_key, sep, max_depth, current_depth, delimiter
#         )
#         return list(flattened.items())


#     @staticmethod
#     def _parse_structured_string(s: str, parent_key: str, field_names: list[str], sep: str, 
#                                  delimiter: str = ",") -> list[tuple]:
#         """
#         Parse structured strings like "5,E" or "5|E" into separate fields.
        
#         Args:
#             s: String to parse (e.g., "5,E" or "5|E")
#             parent_key: Key prefix
#             field_names: Field names to use (e.g., ["id", "name"])
#             sep: Separator for keys
#             delimiter: Delimiter used in the structured string
        
#         Returns:
#             List of (key, value) tuples
#         """
#         items = []
#         parts = [p.strip() for p in s.split(delimiter)]
        
#         if len(parts) == len(field_names):
#             # Create separate columns for each field
#             for field_name, value in zip(field_names, parts):
#                 items.append((f"{parent_key}{sep}{field_name}", value))
#         else:
#             # Fallback: if parts don't match field names, keep as single value
#             items.append((parent_key, s))
        
#         return items


#     @staticmethod
#     def _parse_multivalue_string(s: str, parent_key: str, field_names: list[str], sep: str,
#                                 max_depth: int = 0, current_depth: int = 0, delimiter: str = ",") -> list[tuple]:
#         """
#         Parse multi-value strings like "5,E 6,F" or "5|E 6|F" into separate records.
#         This handles cases where a list was serialized into a single string.
        
#         Args:
#             s: String containing multiple records (e.g., "5,E 6,F" or "5|E 6|F")
#             parent_key: Key prefix
#             field_names: Field names to use (e.g., ["id", "name"])
#             sep: Separator for keys
#             max_depth: Maximum depth to flatten (0 = unlimited)
#             current_depth: Current nesting level
#             delimiter: Delimiter used in the structured strings
        
#         Returns:
#             List of (key, value) tuples
#         """
#         items = []
        
#         # Check if we've reached max depth
#         if max_depth > 0 and current_depth >= max_depth:
#             # Stop flattening, return string as-is
#             items.append((parent_key, s))
#             return items
        
#         # Split by whitespace or newlines to get individual records
#         # Handle various formats: "5,E 6,F" or "5|E 6|F" or "5,E\n6,F"
#         records = re.split(r'[\s\n]+', s.strip())
        
#         for i, record in enumerate(records):
#             record = record.strip()
#             if not record:
#                 continue
                
#             array_key = f"{parent_key}_{i}" if len(records) > 1 else parent_key
#             parts = [p.strip() for p in record.split(delimiter)]
            
#             if len(parts) == len(field_names):
#                 # Create separate columns for each field
#                 for field_name, value in zip(field_names, parts):
#                     items.append((f"{array_key}{sep}{field_name}", value))
#             else:
#                 # Fallback: if parts don't match field names, keep as single value
#                 items.append((array_key, record))
        
#         return items
    


class ToonTabularNestedParser(ToonParser):
    """Parser for tabular nested TOON format with depth control."""
    #print("Loaded ToonTabularNestedParser")
    
    HEADER_PATTERN = r"^(?P<table_name>\w+)?\[#?(?P<lengthMarker>\d+)?(?P<N>\d+)(?P<delimiter>[^\]]+)?\]:"
    
    def __init__(self, lines: list[str], flatten_nested: bool = False, nested_depth: int = 0, format_type: str = "object") -> None:
        super().__init__(lines)
        self.flatten = flatten_nested
        self.nested_depth = nested_depth  # 0 = unlimited, N = flatten N levels only
        self.format_type = format_type

    
    def parse(self) -> DataFrame:
        """Parse tabular nested format TOON data."""
        if not HAS_YAML:
            raise ImportError(
                "Nested TOON format requires PyYAML. "
                "Install it with: pip install pyyaml"
            )
        #print(f"Header Line inside preview [ToonTabularNestedParser]: {self.header_line}")
        
        match = re.search(self.HEADER_PATTERN, self.header_line)
        #print(f"Regex match object: {match}")
        #print(f"Header Line: ", self.header_line)
        
        if not match:
            raise ValueError(
                f"Invalid nested TOON header format: {self.header_line}\n"
                f"Expected format: [table_name][N<delimiter>]:"
            )
        
        self.table_name = match.group("table_name")
        self.lengthMarker = int(match.group("lengthMarker")) if match.group("lengthMarker") else None
        self.N = int(match.group("N"))
        self.delimiter = self.normalize_delimiter(match.group("delimiter"))
        #print(f"Parsed header - table_name: {self.table_name}, lengthMarker: {self.lengthMarker}, N: {self.N}, delimiter: '{type(match.group("delimiter"))}'")
        
        yaml_content = "\n".join(self.data_lines)
        
        try:
            data = yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            raise ValueError(f"Failed to parse YAML content: {e}")
        
        if data is None:
            data = []
        elif not isinstance(data, list):
            raise ValueError(f"Expected a list of records, got {type(data).__name__}")
        
        if len(data) != self.N:
            warnings.warn(
                f"Expected {self.N} rows but found {len(data)}.",
                UserWarning,
                stacklevel=2,
            )
        
        if self.flatten and data:
            flattened_data = [
                self._flatten_dict(
                    record, 
                    max_depth=self.nested_depth, 
                    current_depth=0, 
                    delimiter=self.delimiter
                ) 
                for record in data
            ]
            df = pd.DataFrame(flattened_data)
        else:
            df = pd.DataFrame(data)
        
        df.attrs["table_name"] = self.table_name
        df.attrs["lengthMarker"] = self.lengthMarker
        df.attrs["N"] = self.N
        df.attrs["delimiter"] = self.delimiter
        df.attrs["format_type"] = self.format_type
        df.attrs["flatten_nested"] = self.flatten
        df.attrs["nested_depth"] = self.nested_depth
        
        return df
    

    @staticmethod
    def _flatten_dict(d: dict, parent_key: str = "", sep: str = ".", max_depth: int = 0, 
                     current_depth: int = 0, delimiter: str = ",") -> dict:
        """
        Flatten nested dictionary and lists (arrays) recursively with depth control.
        
        Handles:
        - Nested dictionaries at any depth
        - Nested lists/arrays at any depth
        - Mixed nested structures (dict in list in dict in list, etc.)
        - Special field specifications like {id,name} for parsing structured strings
        - Handle delimiter correctly in nested parsing
        - Array size markers like [2], [3] which are cleaned from output keys
        - Depth limiting: when max_depth is reached, stop flattening
        - If max_depth is 0, flatten completely
        - If max_depth is N > 0, flatten only N levels deep
        
        Args:
            d: Dictionary to flatten
            parent_key: Key prefix from parent levels
            sep: Separator for nested keys (default: ".")
            max_depth: Maximum depth to flatten (0 = unlimited)
            current_depth: Current nesting level
            delimiter: Delimiter for parsing structured strings
        
        Returns:
            Flattened dictionary with dot-notation keys
        """
        items = []
        # if delimiter.strip() == "<TAB>":
        #     #print("Using tab delimiter")
        
        # Check if we've reached max depth (if max_depth > 0)
        if max_depth > 0 and current_depth >= max_depth:
            # Stop flattening, return as-is
            key = parent_key if parent_key else "data"
            #print(f"Max depth {max_depth} reached at key: {key}. Stopping flattening.")
            return {key: d}
        
        for k, v in d.items():
            # Clean the key: remove array size markers [N] and field specs {field1,field2}
            # clean_key = re.sub(r'\[\d+\]', '', k)  # Remove [2], [3], etc.
            # Remove keys like [2|], [3\t], [N|], etc.
            # clean_key = re.sub(r'\[\d+[|\t]*\]', '', k)
            clean_key = re.sub(r'\[\d+[|\t]*\]', '', k)
            # Extract field specification before removing it (e.g., {id,name})
            field_match = re.search(r'\{([^}]+)\}', k)
            field_names = None
            if field_match:
                field_names = [f.strip() for f in field_match.group(1).split(delimiter)]
                #print("Found field specification:", field_names)
                clean_key = re.sub(r'\{[^}]+\}', '', clean_key)  # Remove field spec
            
            # Build the new key
            #print(f"Processing key: {k} -> clean key: {clean_key}")
            new_key = f"{parent_key}{sep}{clean_key}" if parent_key else clean_key

            
            # Process the value based on its type
            if isinstance(v, list):
                #print(f"Processing value at key: {v}")
                items.extend(
                    ToonTabularNestedParser._process_list(
                        v, new_key, field_names, sep, max_depth, current_depth + 1, delimiter
                    )
                )
            elif isinstance(v, dict):
                #print(f"Processing value at key: {v}")
                items.extend(
                    ToonTabularNestedParser._process_dict(
                        v, new_key, sep, max_depth, current_depth + 1, delimiter
                    )
                )
            elif isinstance(v, str) and field_names and (" " in v or delimiter in v):
                #print(f"Processing value at key: {v}")
                # Handle case where list was converted to space-separated string
                items.extend(
                    ToonTabularNestedParser._parse_multivalue_string(
                        v, new_key, field_names, sep, max_depth, current_depth + 1, delimiter
                    )
                )
            else:
                # Primitive value (string, int, float, bool, None, etc.)
                #print(f"Processing value at key: {v}")
                #print(f"delimiter used: {delimiter}")
                if isinstance(v, str):
                    v= v.replace(delimiter, ",")
                items.append((new_key, v))
        
        return dict(items)


    @staticmethod
    def _process_list(lst: list, parent_key: str, field_names: list[str] | None, sep: str, 
                     max_depth: int = 0, current_depth: int = 0, delimiter: str = ",") -> list[tuple]:
        """
        Process a list recursively with depth control.
        
        Args:
            lst: List to process
            parent_key: Key prefix for this list
            field_names: Optional field names for parsing structured strings
            sep: Separator for nested keys
            max_depth: Maximum depth to flatten (0 = unlimited)
            current_depth: Current nesting level
            delimiter: Delimiter for parsing structured strings
        
        Returns:
            List of (key, value) tuples
        """
        items = []
        
        # Check if we've reached max depth
        if max_depth > 0 and current_depth >= max_depth:
            # Stop flattening, return list as-is
            items.append((parent_key, lst))
            return items
        
        for i, item in enumerate(lst):
            array_key = f"{parent_key}_{i}"
            
            if isinstance(item, dict):
                # Dictionary inside list - recurse
                flattened = ToonTabularNestedParser._flatten_dict(
                    item, array_key, sep, max_depth, current_depth, delimiter
                )
                items.extend(flattened.items())
                
            elif isinstance(item, list):
                # List inside list - recurse deeper
                items.extend(
                    ToonTabularNestedParser._process_list(
                        item, array_key, None, sep, max_depth, current_depth + 1, delimiter
                    )
                )
                
            elif isinstance(item, str) and field_names and delimiter in item:
                # Structured string like "5|E" with field specification
                items.extend(
                    ToonTabularNestedParser._parse_structured_string(
                        item, array_key, field_names, sep, delimiter
                    )
                )
                
            else:
                # Primitive value
                items.append((array_key, item))
        
        return items


    @staticmethod
    def _process_dict(d: dict, parent_key: str, sep: str, 
                     max_depth: int = 0, current_depth: int = 0, delimiter: str = ",") -> list[tuple]:
        """
        Process a dictionary recursively with depth control.
        
        Args:
            d: Dictionary to process
            parent_key: Key prefix for this dict
            sep: Separator for nested keys
            max_depth: Maximum depth to flatten (0 = unlimited)
            current_depth: Current nesting level
            delimiter: Delimiter for parsing structured strings
        
        Returns:
            List of (key, value) tuples
        """
        flattened = ToonTabularNestedParser._flatten_dict(
            d, parent_key, sep, max_depth, current_depth, delimiter
        )
        return list(flattened.items())


    @staticmethod
    def _parse_structured_string(s: str, parent_key: str, field_names: list[str], sep: str, 
                                 delimiter: str = ",") -> list[tuple]:
        """
        Parse structured strings like "5,E" or "5|E" into separate fields.
        
        Args:
            s: String to parse (e.g., "5,E" or "5|E")
            parent_key: Key prefix
            field_names: Field names to use (e.g., ["id", "name"])
            sep: Separator for keys
            delimiter: Delimiter used in the structured string
        
        Returns:
            List of (key, value) tuples
        """
        items = []
        parts = [p.strip() for p in s.split(delimiter)]
        
        if len(parts) == len(field_names):
            # Create separate columns for each field
            for field_name, value in zip(field_names, parts):
                items.append((f"{parent_key}{sep}{field_name}", value))
        else:
            # Fallback: if parts don't match field names, keep as single value
            items.append((parent_key, s))
        
        return items


    @staticmethod
    def _parse_multivalue_string(s: str, parent_key: str, field_names: list[str], sep: str,
                                max_depth: int = 0, current_depth: int = 0, delimiter: str = ",") -> list[tuple]:
        """
        Parse multi-value strings like "5,E 6,F" or "5|E 6|F" into separate records.
        This handles cases where a list was serialized into a single string.
        
        Args:
            s: String containing multiple records (e.g., "5,E 6,F" or "5|E 6|F")
            parent_key: Key prefix
            field_names: Field names to use (e.g., ["id", "name"])
            sep: Separator for keys
            max_depth: Maximum depth to flatten (0 = unlimited)
            current_depth: Current nesting level
            delimiter: Delimiter used in the structured strings
        
        Returns:
            List of (key, value) tuples
        """
        items = []
        
        # Check if we've reached max depth
        if max_depth > 0 and current_depth >= max_depth:
            # Stop flattening, return string as-is
            items.append((parent_key, s))
            return items
        
        # Split by whitespace or newlines to get individual records
        # Handle various formats: "5,E 6,F" or "5|E 6|F" or "5,E\n6,F"
        records = re.split(r'[\s\n]+', s.strip())
        
        for i, record in enumerate(records):
            record = record.strip()
            if not record:
                continue
                
            array_key = f"{parent_key}_{i}" if len(records) > 1 else parent_key
            parts = [p.strip() for p in record.split(delimiter)]
            
            if len(parts) == len(field_names):
                # Create separate columns for each field
                for field_name, value in zip(field_names, parts):
                    items.append((f"{array_key}{sep}{field_name}", value))
            else:
                # Fallback: if parts don't match field names, keep as single value
                items.append((array_key, record))
        
        return items