
from pandas import DataFrame
from ._toon import to_toon as _to_toon_core

def _df_to_toon():
    """
    Attach `to_toon` method directly to pandas DataFrame:
        df.to_toon(...) works exactly like the standalone function.
    """
    def _to_toon(self, *args, **kwargs):
        # Only call the core _toon.to_toon
        return _to_toon_core(self, *args, **kwargs)

    DataFrame.to_toon = _to_toon
