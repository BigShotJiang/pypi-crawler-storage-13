
"""
TOON Format Integration for pandas DataFrames.

This module exposes:
    - read_toon(): Read TOON → pandas.DataFrame
    - to_toon(): Write pandas.DataFrame → TOON
    - ToonReader: Low-level reader class
    - ToonWriter: Low-level writer class
    - ToonAccessor: Pandas accessor for df.toon.<method>()
    
You can use either:

    # Standalone function
    toon_str = to_toon(df, indent=2)

    # Direct DataFrame method
    toon_str = df.to_toon(indent=2)

    # Accessor namespace (optional)
    toon_str = df.toon.to_toon(indent=2)
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Literal, overload
import os
import warnings
from pandas import DataFrame
from pandas._typing import FilePath, ReadBuffer


# Core TOON components
# from ._reader import ToonReader
# from ._writer import ToonWriter
# from ._accessor import ToonAccessor
from ._toon import to_toon, read_toon
from ._patch import _df_to_toon
from ._patch import _df_to_toon 

__all__ = [
    "ToonReader",
    "ToonWriter",
    "ToonAccessor",
    "read_toon",
    "to_toon",
]

# ==========================
# Apply patch for df.to_toon()
# ==========================
_df_to_toon()  # monkey patch pandas DataFrame
