# toon/writer.py
"""
Writer for TOON format files.
Standalone version for PyPI package.
"""

from __future__ import annotations
import re
import pandas as pd
from ._tabular_writer import ToonBaseWriter, ToonTabularBasicWriter, ToonTabularNestedWriter


class ToonWriter:
    """
    Writer for TOON format files.

    Automatically detects format type (basic or nested) and writes accordingly.
    """

    def __init__(
        self,
        df: pd.DataFrame,
        file_path=None,
        table_name: str | None = None,
        delimiter: str = ",",
        indent: int = 2,
        length_marker: str = "",
        format_type: str = "tabular_array",
        encoding: str = "utf-8",
    ):
        self.df = df
        self.file_path = file_path
        self.table_name = table_name
        self.delimiter = delimiter
        self.indent = indent
        self.length_marker = length_marker
        self.format_type = format_type.lower()
        self.encoding = encoding

    def write(self) -> str | None:
        """Write DataFrame to TOON format."""

        # Validate format type
        valid_formats = [ "object", "primitive_array",
                         "tabular_array", "mixed_array"]
        if self.format_type == "object":
            raise NotImplementedError(
                f"Format type '{self.format_type}' is not implemented yet."
            )
        elif self.format_type == "primitive_array":
            raise NotImplementedError(
                f"Format type '{self.format_type}' is not implemented yet."
            )
        elif self.format_type == "mixed_array":
            raise NotImplementedError(
                f"Format type '{self.format_type}' is not implemented yet."
            )
        elif self.format_type == "tabular_array":
            # call detection
            self.format_type = self._detect_format()
        elif self.format_type not in valid_formats:
            raise ValueError(
                f"Invalid format_type: {self.format_type}. Expected one of {valid_formats}"
            )
            
        

        # Get appropriate writer
        writer = self._get_writer()

        # Generate output
        output = writer.write()

        # Write to file or return string
        if self.file_path is None:
            return output
        else:
            self._write_to_file(output)
            return None

    def _detect_format(self) -> str:
        """Auto-detect format type based on DataFrame columns."""
        if self.df is None or len(self.df.columns) == 0:
            return "basic"

        # Improved logic to detect nested structure
        has_nested = False
        
        for col in self.df.columns:
            # Check if column name indicates a nested structure
            if ('.' in col) or ('[' in col and ']' in col) or re.search(r"(_\d+|\[\d*\])", col):
                has_nested = True
                break
            
            # Check the data type in the column itself for potential nested structures (like lists or dicts)
            if any(isinstance(val, (list, dict)) for val in self.df[col]):
                has_nested = True
                break

        # Return "nested" if a nested structure is detected
        return "nested" if has_nested else "basic"

    def _get_writer(self) -> ToonBaseWriter:
        """Get appropriate writer based on format type."""
        if self.format_type in ["basic", "tabular_array"]:
            return ToonTabularBasicWriter(
                self.df,
                self.table_name,
                self.delimiter,
                self.indent,
                self.length_marker,
            )
        elif self.format_type == "nested":
            return ToonTabularNestedWriter(
                self.df,
                self.table_name,
                self.delimiter,
                self.indent,
                self.length_marker,
            )
        elif self.format_type == "object":
            raise NotImplementedError(
                f"Format type '{self.format_type}' is not implemented yet."
            )
        elif self.format_type in ["primitive_array", "mixed_array"]:
            raise NotImplementedError(
                f"Format type '{self.format_type}' is not implemented yet."
            )
        else:
            raise ValueError(f"Unknown format type: {self.format_type}")

    def _write_to_file(self, content: str) -> None:
        print(f"_write_to_file: Writing content to {self.file_path}")
        """Write content to file using standard Python open()."""
        if isinstance(self.file_path, str):
            with open(self.file_path, "w", encoding=self.encoding) as f:
                f.write(content)
        else:
            # assume file-like object
            self.file_path.write(content)
