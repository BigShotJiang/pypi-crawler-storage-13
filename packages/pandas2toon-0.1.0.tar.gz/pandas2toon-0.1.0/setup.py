from setuptools import setup, find_packages
import pathlib

# Read README.md for long description
HERE = pathlib.Path(__file__).parent
README = (HERE / "README.md").read_text(encoding="utf-8")

setup(
    name="pandas2toon",                 # PyPI package name
    version="0.1.0",                    # Package version
    author="Md. Rasel Meya",                
    author_email="raselmeya2194@gmail.com", 
    description="A TOON format reader and writer extension for pandas.",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://github.com/raselmeya94/pandas2toon",  # GitHub repository

    # -----------------------------
    # PACKAGE DISCOVERY
    # -----------------------------
    packages=find_packages(include=["pandas2toon", "pandas2toon.*"]),
    include_package_data=True,  # Include MANIFEST.in files

    # -----------------------------
    # DEPENDENCIES
    # -----------------------------
    install_requires=[
        "pandas>=1.5",
        "pyyaml>=6.0"
    ],

    # -----------------------------
    # OPTIONAL FEATURES (EXTRAS)
    # -----------------------------
    # extras_require={
    #     "dev": [
    #         "pytest",
    #         "black",
    #         "isort",
    #         "flake8"
    #     ],
    # },

    # -----------------------------
    # CLASSIFIERS FOR PYPI
    # -----------------------------
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",

        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",

        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",

        "Topic :: Software Development :: Libraries",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: Utilities",
    ],

    python_requires=">=3.8",

    # -----------------------------
    # PROJECT LINKS (SHOW UP ON PYPI)
    # -----------------------------
    project_urls={
        "Bug Tracker": "https://github.com/raselmeya94/pandas2toon/issues",
        "Documentation": "https://github.com/raselmeya94/pandas2toon#readme",
        "Source Code": "https://github.com/raselmeya94/pandas2toon",
    },

    # Keywords help PyPI discovery
    keywords=[
            "pandas",
            "TOON format",
            "serialization",
            "dataframe",
            "custom formatter",
            "parser",
            "writer",
            "reader",
            "read_toon",
            "to_toon",
            ],

)
