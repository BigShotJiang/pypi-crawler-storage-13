import sys
import os
import pandas as pd
from pandas_toon import read_toon, to_toon

# Add the project root path to sys.path for module imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

##############################
# Test Cases: Saving pandas DataFrame to TOON format
##############################

# Define the sample pandas DataFrame to convert to TOON format
df = pd.DataFrame([
    {"id": 1, "name": "Alice", "scores": [85, 90, 95], "details": {"age": 20, "city": "NY"}},
    {"id": 2, "name": "Bob", "scores": [78, 82, 88], "details": {"age": 22, "city": "LA"}}
])

# Option 1: Convert the DataFrame to a TOON string with default settings
toon_str = to_toon(df)
print("TOON String (default options):")
print(toon_str)
# Expected output (default):
# [2]:
#   - id: 1
#     name: Alice
#     scores[3]: 85,90,95
#     details:
#       age: 20
#       city: NY
#   - id: 2
#     name: Bob
#     scores[3]: 78,82,88
#     details:
#       age: 22
#       city: LA

# Option 2: Convert the DataFrame to a TOON string with custom formatting
toon_str_custom = to_toon(df, indent=2, delimiter="|", format_type="tabular_array")
print("\nTOON String (custom options):")
print(toon_str_custom)
# Expected output (with custom delimiter "|"):
# [2|]:
#   - id: 1
#     name: Alice
#     scores[3|]: 85|90|95
#     details:
#       age: 20
#       city: NY
#   - id: 2
#     name: Bob
#     scores[3|]: 78|82|88
#     details:
#       age: 22
#       city: LA

# Option 3: Write the TOON data directly to a file with custom formatting
toon_file_message = to_toon(df, "output.toon", indent=2, delimiter="|", format_type="tabular_array", return_message=True)
print("\nTOON file saved with custom options:")
print(toon_file_message)
# Expected output:
# [2|]:
#   - id: 1
#     name: Alice
#     scores[3|]: 85|90|95
#     details:
#       age: 20
#       city: NY
#   - id: 2
#     name: Bob
#     scores[3|]: 78|82|88
#     details:
#       age: 22
#       city: LA
# Successfully saved TOON file at: /path/to/output.toon
