import sys
import os

# Add the project root path to sys.path to allow importing from the project directory
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Import the `read_toon` function from the `pandas_toon` module
from pandas2toon import read_toon
import pandas as pd

# Set pandas display option to show all columns
pd.set_option('display.max_columns', None)

##########################
# Test cases for read_toon
##########################

# Option 1: Read the .toon file with default settings
# In this case, we are assuming the function will flatten the data automatically if needed
# df = read_toon("data.toon") 

# Expected output (example):
#   id     name   join_date
# 0  1    Alice  2023-01-15
# 1  2      Bob  2022-03-22
# 2  3  Charlie  2021-06-30

##############################
# Option 2: Read the .toon file with explicit parameters
##############################

# Reading the .toon file with the following options:
# - `flatten_nested=True` to flatten any nested structures in the file
# - `nested_depth=0` to control the depth of the nesting (0 means no nesting)
# - `format_type='tabular_array'` specifies the format for tabular data
df = read_toon(
    file_path="data.toon",  # Path to the .toon file
    flatten_nested=True,     # Flatten nested structures in the file
    nested_depth=0,          # Set the depth of the nested structures (0 = no nesting)
    format_type='tabular_array'  # Output in tabular format
)
print(df)

# Expected output for different nested depths:

# If `flatten_nested=True` and `nested_depth=0` (default):
# The result will show the flattened version of the file, where all nested fields are expanded into individual columns
# Example output:
#    id  personal.name  personal.contact_details.email.address  personal.contact_details.address.street  personal.contact_details.address.city  personal.contact_details.address.country  preferences.communication.preferred_method  preferences.communication.receive_newsletter
# 0   1         Alice                      alice@example.com             123 Wonderland Blvd                            Wonderland                             Fantasyland                                        email                                          True

# If `nested_depth=1`:
# The data will be partially flattened, and some fields will still appear as dictionaries (nested structures).
# Example output:
#    id   name                                   contact
# 0   1  Alice            {'email': 'alice@example.com'}
# 1   2    Bob  {'phone': '555-1234', 'fax': '555-5678'}

# If `nested_depth=2`:
# More fields will be flattened to a deeper level. Nested dictionaries are expanded to separate columns.
# Example output:
#    id   name      contact.email contact.phone contact.fax
# 0   1  Alice  alice@example.com           NaN         NaN
# 1   2    Bob                NaN      555-1234    555-5678

