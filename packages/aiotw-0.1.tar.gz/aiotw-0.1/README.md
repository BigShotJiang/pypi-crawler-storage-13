<h1 align="center">aiotw</h1>
<p align="center">
  aiotw is a small, asynchronous library for working with Twitch.
</p>
<br/>


> [!WARNING]
> PROJECT STILL UNDER DEVELOPMENT! We do not recommend using this project in production BEFORE v1.0! Any update can broke previous functionallity!


# Implemented APIs
- [x] IRC
- [ ] Helix
- [ ] EventSub.


# Requirements
- Python >= 3.11


# Quick start
Install

```bash
pip install aiotw
```

## IRC
Simple client example

```python
import asyncio
from aiotw import irc


client = irc.Client(auth_token='oauth:...', auth_nickname='mybot')
# or you can use anonymous client
client = irc.create_anonymous_client()


@client.on(irc.PrivmsgMessage)
async def on_privmsg(msg: irc.PrivmsgMessage):
    print(f'[{msg.channel}] <{msg.user}>: {msg.message}')

    # send privmsg will not work if you use anonymous client!
    if not client.is_anonymous:
      await client.send(irc.PrivmsgMessage(channel=msg.channel, message=msg.message))


async def main():
    async with client:
        await client.send(irc.JoinMessage(channel='some_channel'))
        await client.serve()


asyncio.run(main())
```

_See [irc sources](./src/aiotw/irc.py) for details._

## Helix
_Not implemented yet._

## EventPub
_Not implemented yet._

# License
This project is released under the MIT License — see the [LICENSE file](./LICENSE) for the full text.

