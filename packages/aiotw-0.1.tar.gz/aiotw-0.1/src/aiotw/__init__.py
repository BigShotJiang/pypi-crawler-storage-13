from .irc import Client as IRC

__all__ = [
    "IRC",
]