class BaseError(Exception):
    """Base class for all aiotw errors."""
    pass


class ConnectionError(BaseError):
    """Raised when a connection error occurs."""
    pass


class AuthicationError(BaseError):
    """Raised when an authentication error occurs."""
    pass


class AlreadyConnectedError(BaseError):
    """Raised when attempting to connect while already connected."""
    pass


class NotConnectedError(BaseError):
    """Raised when attempting to operate while not connected."""
    pass


class JoinChannelError(BaseError):
    """Raised when an error occurs while joining a channel."""
    pass