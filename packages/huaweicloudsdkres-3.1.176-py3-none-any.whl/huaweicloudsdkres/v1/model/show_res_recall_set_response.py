# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowResRecallSetResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'result_set': 'list[ResultSet]',
        'is_success': 'bool',
        'message': 'str',
        'error_code': 'str'
    }

    attribute_map = {
        'result_set': 'result_set',
        'is_success': 'is_success',
        'message': 'message',
        'error_code': 'error_code'
    }

    def __init__(self, result_set=None, is_success=None, message=None, error_code=None):
        r"""ShowResRecallSetResponse

        The model defined in huaweicloud sdk

        :param result_set: 候选集列表
        :type result_set: list[:class:`huaweicloudsdkres.v1.ResultSet`]
        :param is_success: 是否成功
        :type is_success: bool
        :param message: 返回消息（请求成功时，不返回此字段）
        :type message: str
        :param error_code: 错误码（请求成功时，不返回此字段）
        :type error_code: str
        """
        
        super().__init__()

        self._result_set = None
        self._is_success = None
        self._message = None
        self._error_code = None
        self.discriminator = None

        if result_set is not None:
            self.result_set = result_set
        if is_success is not None:
            self.is_success = is_success
        if message is not None:
            self.message = message
        if error_code is not None:
            self.error_code = error_code

    @property
    def result_set(self):
        r"""Gets the result_set of this ShowResRecallSetResponse.

        候选集列表

        :return: The result_set of this ShowResRecallSetResponse.
        :rtype: list[:class:`huaweicloudsdkres.v1.ResultSet`]
        """
        return self._result_set

    @result_set.setter
    def result_set(self, result_set):
        r"""Sets the result_set of this ShowResRecallSetResponse.

        候选集列表

        :param result_set: The result_set of this ShowResRecallSetResponse.
        :type result_set: list[:class:`huaweicloudsdkres.v1.ResultSet`]
        """
        self._result_set = result_set

    @property
    def is_success(self):
        r"""Gets the is_success of this ShowResRecallSetResponse.

        是否成功

        :return: The is_success of this ShowResRecallSetResponse.
        :rtype: bool
        """
        return self._is_success

    @is_success.setter
    def is_success(self, is_success):
        r"""Sets the is_success of this ShowResRecallSetResponse.

        是否成功

        :param is_success: The is_success of this ShowResRecallSetResponse.
        :type is_success: bool
        """
        self._is_success = is_success

    @property
    def message(self):
        r"""Gets the message of this ShowResRecallSetResponse.

        返回消息（请求成功时，不返回此字段）

        :return: The message of this ShowResRecallSetResponse.
        :rtype: str
        """
        return self._message

    @message.setter
    def message(self, message):
        r"""Sets the message of this ShowResRecallSetResponse.

        返回消息（请求成功时，不返回此字段）

        :param message: The message of this ShowResRecallSetResponse.
        :type message: str
        """
        self._message = message

    @property
    def error_code(self):
        r"""Gets the error_code of this ShowResRecallSetResponse.

        错误码（请求成功时，不返回此字段）

        :return: The error_code of this ShowResRecallSetResponse.
        :rtype: str
        """
        return self._error_code

    @error_code.setter
    def error_code(self, error_code):
        r"""Sets the error_code of this ShowResRecallSetResponse.

        错误码（请求成功时，不返回此字段）

        :param error_code: The error_code of this ShowResRecallSetResponse.
        :type error_code: str
        """
        self._error_code = error_code

    def to_dict(self):
        import warnings
        warnings.warn("ShowResRecallSetResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowResRecallSetResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
