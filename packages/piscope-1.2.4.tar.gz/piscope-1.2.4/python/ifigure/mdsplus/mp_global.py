data = 0
