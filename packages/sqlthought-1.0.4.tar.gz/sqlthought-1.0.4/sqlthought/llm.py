import json
from groq import Groq
from sqlthought.config import load_config

def build_llm():
    """
    Returns a usable Groq ChatCompletion client that supports .invoke(prompt).
    """

    cfg = load_config()
    if not cfg or "groq_api_key" not in cfg:
        raise RuntimeError("Groq API key not configured. Run: sqlthought configure")

    api_key = cfg["groq_api_key"]
    model = cfg.get("model", "openai/gpt-oss-20b")

    client = Groq(api_key=api_key)

    class GroqLLMWrapper:
        """A simple wrapper to expose .invoke(prompt)"""

        def __init__(self, client, model):
            self.client = client
            self.model = model

        def invoke(self, prompt: str):
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}]
            )
            return type("Obj", (), {"content": response.choices[0].message.content})

    return GroqLLMWrapper(client, model)
