import os
import sqlite3
import pandas as pd
from sqlthought.utils.logger import logger


def build_sqlite_db(csv_folder, output_file):
    logger.info(f"Scanning folder: {csv_folder}")

    csv_files = [f for f in os.listdir(csv_folder) if f.endswith(".csv")]
    if not csv_files:
        raise ValueError("No CSV files found in folder.")

    conn = sqlite3.connect(output_file)

    for file in csv_files:
        table = os.path.splitext(file)[0]
        path = os.path.join(csv_folder, file)

        logger.info(f"Loading {file} → table '{table}'")

        df = pd.read_csv(path)
        df.to_sql(table, conn, if_exists="replace", index=False)

    conn.close()
    logger.info(f"SQLite DB built at: {output_file}")

    return {"status": "ok", "output": output_file}
