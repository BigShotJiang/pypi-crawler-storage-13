import warnings
warnings.filterwarnings("ignore", message=".*PipelineState.*")


import os
import click
from importlib.metadata import version, PackageNotFoundError

from sqlthought.nlq.conversion import to_sql
from sqlthought.ingestion.build_db import build_sqlite_db
from sqlthought.utils.logger import logger
from sqlthought.utils.generate_answer import generate_nl_answer

import json
from sqlthought.config import CONFIG_FILE as CONFIG_PATH


BASE_DIR = "sqlthought_data"
CSV_DIR = os.path.join(BASE_DIR, "csv")
DB_DIR = os.path.join(BASE_DIR, "databases")
DEFAULT_DB = os.path.join(DB_DIR, "merged.db")

# Try to fetch version
try:
    __version__ = version("sqlthought")
except PackageNotFoundError:
    __version__ = "unknown"


# -------------------------------------------------------
# Root CLI group
# -------------------------------------------------------
@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="sqlthought")
@click.pass_context
def cli(ctx):
    """Agentic reasoning engine for building databases from CSV, converting NLQ to SQL, and more."""

    if ctx.invoked_subcommand is None:
        click.secho("\n🎉 Welcome to SQLThought!", fg="green", bold=True)
        click.echo("An agentic reasoning engine for structured data interaction.\n")

        click.secho("Configure your LLM (Groq) API key:", fg="cyan")
        click.secho("   sqlthought configure", fg="yellow")

        click.secho("First-time setup:\n", fg="cyan")

        click.echo("1. Initialize workspace:")
        click.secho("   sqlthought init", fg="yellow")

        click.echo("\n2. Move your CSVs to the workspace folder:")
        click.secho("   move your_file.csv into sqlthought_data/csv/", fg="yellow")

        click.echo("\n3. Build SQLite database from CSVs:")
        click.secho("   sqlthought build-db company.db", fg="yellow")
        click.secho("   sqlthought build-db company.db --csv-folder ./mycsvs", fg="yellow")

        click.echo("\n4. Ask a natural language question:")
        click.secho('   sqlthought query "Show top customers by region" company.db', fg="yellow")

        click.echo("\nNote: The first time you run a query, you’ll be prompted to enter your LLM provider API key.")
        click.echo("This is stored securely in: ~/.sqlthought/config.json")

        click.echo("\nFor help, run:")
        click.secho("   sqlthought --help", fg="cyan")

        click.secho(f"\nVersion: {__version__}", fg="cyan")



# -------------------------------------------------------
# INIT WORKSPACE
# -------------------------------------------------------
@cli.command()
def init():
    """Initialize SQLThought workspace structure."""
    os.makedirs(CSV_DIR, exist_ok=True)
    os.makedirs(DB_DIR, exist_ok=True)

    click.secho("SQLThought workspace created!", fg="green")
    click.echo(f" → Add CSV files to: {CSV_DIR}")
    click.echo(" → Then run: sqlthought build-db")
    click.echo(" → To query: sqlthought query \"your question\" path/to/db")
    click.echo()
    click.secho("Your project is ready!", fg="cyan")




@cli.command("configure")
def configure():
    """Configure your LLM provider (Groq) API key and model."""
    from sqlthought.config import CONFIG_DIR, CONFIG_FILE, save_config, DEFAULT_MODEL

    # Ensure config directory exists
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Prompt for API key
    api_key = click.prompt("Enter your Groq API key", hide_input=True)

    # Prompt for model
    model = click.prompt(
        f"Enter model name (press Enter to use default: {DEFAULT_MODEL})",
        default=DEFAULT_MODEL,
        show_default=False
    )

    # Save configuration
    save_config(api_key=api_key, model=model)

    click.secho("✔ Configuration saved successfully!", fg="green")
    click.echo(f" → File: {CONFIG_FILE}")
    click.echo(f" → Model: {model}")





# -------------------------------------------------------
# BUILD DATABASE
# -------------------------------------------------------
@cli.command("build-db")
@click.argument("output_db", type=str)
@click.option("--csv-folder", type=str, default=CSV_DIR, help="Path to the folder containing CSV files.")
def build_db(output_db, csv_folder):
    """
    Build a SQLite database from CSV files.

    Usage:
        sqlthought build-db company.db          # Uses default folder: sqlthought_data/csv
        sqlthought build-db company.db ./csv    # Custom CSV folder
    """

    # Validate CSV folder
    if not os.path.exists(csv_folder):
        click.secho("CSV folder not found:", fg="red")
        click.echo(f"   {csv_folder}")
        return

    csv_files = [f for f in os.listdir(csv_folder) if f.endswith(".csv")]

    if not csv_files:
        click.secho("No CSV files found.", fg="red")
        click.echo(f"Place your .csv files inside: {csv_folder}")
        return

    click.secho("Building SQLite database from CSV files...", fg="yellow")

    # Ensure DB parent folder exists
    os.makedirs(os.path.dirname(output_db) or ".", exist_ok=True)

    # Build DB
    result = build_sqlite_db(csv_folder, output_db)

    click.secho("Database created successfully!", fg="green")
    click.echo(f"Location: {output_db}\n")

    click.echo("Now you can query this DB using:")
    click.secho(f'sqlthought query "your question" {output_db}', fg="cyan")


# -------------------------------------------------------
# QUERY COMMAND
# -------------------------------------------------------
@cli.command("query")
@click.argument("question", type=str)
@click.argument("db_path", type=str)
def query(question, db_path):
    """Run NLQ → SQL reasoning and execute query on DB."""
    if not os.path.exists(db_path):
        click.secho("Database not found.", fg="red")
        click.echo("Run: sqlthought build-db")
        return

    click.secho("Executing NLQ → SQL pipeline...", fg="blue")
    result = to_sql(question, db_path)

    click.echo("\n=== SQLThought Result ===")
    click.echo(f"SQL: {result.get('sql')}")
    click.echo(f"Success: {result.get('success')}")
    click.echo(f"Result: {result.get('result')}")

    nl_response = generate_nl_answer(
        result.get("result"),
        question,
        result.get("sql")
    )   


    click.secho("\n=== Natural Language Answer ===", fg="green")
    click.echo(nl_response)


