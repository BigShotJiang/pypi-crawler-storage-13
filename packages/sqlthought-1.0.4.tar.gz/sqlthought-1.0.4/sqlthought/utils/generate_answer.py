import os
from sqlthought.llm import build_llm

PROMPT_PATH = os.path.join(os.path.dirname(__file__), "../nlq/prompts/answer_generation.txt")

def generate_nl_answer(result: list, user_question: str, sql_query: str) -> str:
    if not result:
        return "No records found for the given query."

    with open(PROMPT_PATH, "r") as f:
        base_prompt = f.read()

    llm = build_llm()

    final_prompt = base_prompt.format(
        question=user_question,
        sql=sql_query,
        result=result
    )

    response = llm.invoke(final_prompt)
    return response.content.strip()

