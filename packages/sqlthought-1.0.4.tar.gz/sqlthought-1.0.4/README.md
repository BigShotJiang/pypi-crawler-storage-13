# 🔗 SQLThought

Are you interested in quickly building a database from CSV files and asking questions in natural language? 

You’ve arrived at the right place!

## Quick Install
```bash
pip install sqlthought
```

## CLI commands
SQLThought includes a full command-line interface:
- `sqlthought` - Show the steps to follow 
- `sqlthought --version` — Show installed version  
- `sqlthought configure` — Configure Groq API and LLM 
- `sqlthought init` - Create workspace for setting up db
- `sqlthought build-db` — Build a SQLite database from CSV files  
- `sqlthought query` — Query your database using natural language  


# 🤔 What is this?
SQLThought is built to simplify how people interact with structured data.

Many users know exactly what they want to ask —
but writing SQL, understanding joins, tuning filters, or debugging errors takes time.

Traditional NLQ (Natural Language Query) systems jump from text → SQL directly, which often leads to invalid queries and unclear reasoning.

SQLThought takes a more reliable approach:

✅ It thinks step-by-step
It analyzes the schema, decomposes the question, plans the query, generates SQL, executes it, and—if something fails—corrects the SQL automatically.

✅ It builds a database for you
Just place your CSV files in a folder and run one command to generate a queryable SQLite database.

✅ It gives natural language answers
Once SQL is executed, SQLThought converts the results back into a clean, conversational answer powered by Groq.


## 🧩 What are the key features?

### Multi-Agent Reasoning
SQLThought uses LangGraph to orchestrate intelligent pipelines with:
- Stepwise decomposition  
- State-aware execution  
- Deterministic branches  
- Automatic SQL correction loops  
- Fully transparent, debuggable agent workflows  

### Groq-Powered LLM Execution
Fast agentic reasoning using Groq’s API, providing:
- Low-latency inference  
- Predictable outputs  
- Easy model switching  
- Secure local configuration  

### Modular, Extensible Architecture
Every reasoning stage is isolated and replaceable.

### Secure Local Config Storage
```
~/.sqlthought/config.json
```
Stores API keys and model preferences locally (never uploaded or logged).

### NLQ  to SQL conversion
The first reasoning module shipped with SQLThought is a full NLQ → SQL agentic system with:

* Schema understanding
* Subtask decomposition
* Query planning
* SQL generation
* SQL execution
* Automatic correction loops

## 💁 Contributing
Contributions, feature ideas, and pull requests are welcome!
More documentation and developer guides will be added soon.