# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class PersistentStorage:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'name': 'str',
        'storage_metadata': 'StorageMetadata',
        'create_time': 'datetime',
        'user_claim_count': 'int',
        'share_claim_count': 'int'
    }

    attribute_map = {
        'id': 'id',
        'name': 'name',
        'storage_metadata': 'storage_metadata',
        'create_time': 'create_time',
        'user_claim_count': 'user_claim_count',
        'share_claim_count': 'share_claim_count'
    }

    def __init__(self, id=None, name=None, storage_metadata=None, create_time=None, user_claim_count=None, share_claim_count=None):
        r"""PersistentStorage

        The model defined in huaweicloud sdk

        :param id: WKS存储ID。
        :type id: str
        :param name: 名称。
        :type name: str
        :param storage_metadata: 
        :type storage_metadata: :class:`huaweicloudsdkworkspaceapp.v1.StorageMetadata`
        :param create_time: 创建时间。
        :type create_time: datetime
        :param user_claim_count: 个人目录声明数量。
        :type user_claim_count: int
        :param share_claim_count: 共享目录声明数量。
        :type share_claim_count: int
        """
        
        

        self._id = None
        self._name = None
        self._storage_metadata = None
        self._create_time = None
        self._user_claim_count = None
        self._share_claim_count = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if name is not None:
            self.name = name
        if storage_metadata is not None:
            self.storage_metadata = storage_metadata
        if create_time is not None:
            self.create_time = create_time
        if user_claim_count is not None:
            self.user_claim_count = user_claim_count
        if share_claim_count is not None:
            self.share_claim_count = share_claim_count

    @property
    def id(self):
        r"""Gets the id of this PersistentStorage.

        WKS存储ID。

        :return: The id of this PersistentStorage.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this PersistentStorage.

        WKS存储ID。

        :param id: The id of this PersistentStorage.
        :type id: str
        """
        self._id = id

    @property
    def name(self):
        r"""Gets the name of this PersistentStorage.

        名称。

        :return: The name of this PersistentStorage.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this PersistentStorage.

        名称。

        :param name: The name of this PersistentStorage.
        :type name: str
        """
        self._name = name

    @property
    def storage_metadata(self):
        r"""Gets the storage_metadata of this PersistentStorage.

        :return: The storage_metadata of this PersistentStorage.
        :rtype: :class:`huaweicloudsdkworkspaceapp.v1.StorageMetadata`
        """
        return self._storage_metadata

    @storage_metadata.setter
    def storage_metadata(self, storage_metadata):
        r"""Sets the storage_metadata of this PersistentStorage.

        :param storage_metadata: The storage_metadata of this PersistentStorage.
        :type storage_metadata: :class:`huaweicloudsdkworkspaceapp.v1.StorageMetadata`
        """
        self._storage_metadata = storage_metadata

    @property
    def create_time(self):
        r"""Gets the create_time of this PersistentStorage.

        创建时间。

        :return: The create_time of this PersistentStorage.
        :rtype: datetime
        """
        return self._create_time

    @create_time.setter
    def create_time(self, create_time):
        r"""Sets the create_time of this PersistentStorage.

        创建时间。

        :param create_time: The create_time of this PersistentStorage.
        :type create_time: datetime
        """
        self._create_time = create_time

    @property
    def user_claim_count(self):
        r"""Gets the user_claim_count of this PersistentStorage.

        个人目录声明数量。

        :return: The user_claim_count of this PersistentStorage.
        :rtype: int
        """
        return self._user_claim_count

    @user_claim_count.setter
    def user_claim_count(self, user_claim_count):
        r"""Sets the user_claim_count of this PersistentStorage.

        个人目录声明数量。

        :param user_claim_count: The user_claim_count of this PersistentStorage.
        :type user_claim_count: int
        """
        self._user_claim_count = user_claim_count

    @property
    def share_claim_count(self):
        r"""Gets the share_claim_count of this PersistentStorage.

        共享目录声明数量。

        :return: The share_claim_count of this PersistentStorage.
        :rtype: int
        """
        return self._share_claim_count

    @share_claim_count.setter
    def share_claim_count(self, share_claim_count):
        r"""Sets the share_claim_count of this PersistentStorage.

        共享目录声明数量。

        :param share_claim_count: The share_claim_count of this PersistentStorage.
        :type share_claim_count: int
        """
        self._share_claim_count = share_claim_count

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PersistentStorage):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
