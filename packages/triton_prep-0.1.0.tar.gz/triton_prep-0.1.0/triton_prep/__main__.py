from triton_prep.cli.app import cli

if __name__ == "__main__":
    cli()
