"""
Operational context specific to DER resources for zero trust decision-making.

This class was automatically generated from the Grid-STIX ontology.

Namespace: http://www.anl.gov/sss/grid-stix-2.1-operational-contexts.owl

"""

from __future__ import annotations

from typing import Optional, Any, List, Dict
from collections import OrderedDict

from stix2.properties import (  # type: ignore[import-untyped]
    StringProperty,
    IntegerProperty,
    BooleanProperty,
    FloatProperty,
    ListProperty,
    DictionaryProperty,
    TimestampProperty,
    IDProperty,
    TypeProperty,
)
from stix2.utils import NOW  # type: ignore[import-untyped]


# External imports

from ..base import GridSTIXDomainObject


class DerOperationalContext(GridSTIXDomainObject):
    """
    Operational context specific to DER resources for zero trust decision-making.

    """

    # STIX type identifier for this Grid-STIX object
    _type = "x-grid-der-operational-context"

    # STIX properties definition following official STIX patterns
    _properties = OrderedDict(
        [
            ("type", TypeProperty(_type, spec_version="2.1")),
            ("spec_version", StringProperty(fixed="2.1")),
            ("id", IDProperty(_type, spec_version="2.1")),
            (
                "created",
                TimestampProperty(
                    default=lambda: NOW,
                    precision="millisecond",
                    precision_constraint="min",
                ),
            ),
            (
                "modified",
                TimestampProperty(
                    default=lambda: NOW,
                    precision="millisecond",
                    precision_constraint="min",
                ),
            ),
            ("name", StringProperty()),
            ("description", StringProperty()),
            # Grid-STIX base properties
            ("x_grid_context", DictionaryProperty()),
            ("x_operational_status", StringProperty()),
            ("x_compliance_framework", ListProperty(StringProperty)),
            ("x_grid_component_type", StringProperty()),
            ("x_criticality_level", IntegerProperty()),
            ("x_availability_status", ListProperty(StringProperty())),
            ("x_capacity_factor", ListProperty(FloatProperty())),
            ("x_current_power_output", ListProperty(FloatProperty())),
            ("x_der_resource_id", ListProperty(StringProperty())),
            ("x_der_trust_level", ListProperty(FloatProperty())),
            ("x_forecasted_availability", ListProperty(StringProperty())),
            ("x_grid_code_compliance_status", ListProperty(StringProperty())),
            ("x_grid_service_participation", ListProperty(StringProperty())),
            ("x_last_performance_metric", ListProperty(FloatProperty())),
            ("x_market_bidding_behavior", ListProperty(StringProperty())),
            ("x_operational_anomalies", ListProperty(StringProperty())),
            ("x_operational_mode", ListProperty(StringProperty())),
            ("x_reactive_power_capability", ListProperty(FloatProperty())),
            ("x_response_time_to_commands", ListProperty(StringProperty())),
        ]
    )

    def __init__(self, **kwargs: Any) -> None:
        """Initialize DerOperationalContext with Grid-STIX properties."""
        # Set STIX type if not provided
        if "type" not in kwargs:
            kwargs["type"] = self._type

        # Generate deterministic ID if not provided
        if "id" not in kwargs:
            from ..base import DeterministicUUIDGenerator

            # Generate deterministic UUID - will raise ValueError if required properties missing
            kwargs["id"] = DeterministicUUIDGenerator.generate_uuid(self._type, kwargs)

        super().__init__(**kwargs)
