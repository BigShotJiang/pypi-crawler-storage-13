"""Cloudnetpy-QC version."""

MAJOR = 1
MINOR = 30
PATCH = 2
__version__ = f"{MAJOR}.{MINOR}.{PATCH}"
