# fullfrozenclass
___
Decorator that creates a full frozen class. Immutable and prohibits object creation.


```python
from fullfrozenclass import fullfrozenclass


@fullfrozenclass
class Example:
    a: int = 15
    b: int = 25


Example.a = 16
# Error

Example.c = 4
# Error

x = Example()
# Error
```
