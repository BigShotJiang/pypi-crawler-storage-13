from typing import Any


class _FrozenClassMeta(type):
    def __new__(
            mcs,
            name: str,
            bases: tuple[type, ...],
            namespace: dict[str, Any],
    ) -> "_FrozenClassMeta":
        return super().__new__(mcs, name, bases, namespace)

    def __setattr__(cls, name: str, value: Any) -> None:  # noqa: ANN401
        raise TypeError(f"{cls.__name__} is frozen.")

    def __delattr__(cls, name: str) -> None:
        raise TypeError(f"{cls.__name__} is frozen.")

    def __call__(cls, *args: Any, **kwargs: Any) -> None:  # noqa: ANN401
        raise TypeError(f"Class {cls.__name__} is FrozenClass. Not allowed create object with this class.")


def fullfrozenclass[T](cls: T) -> T:
    """Make a class full frozen.

    - Not allowed create object with this class.
    - Not allowed change class attributes.
    """
    print(f"{cls.__dict__}")
    namespace = dict(cls.__dict__)
    namespace["__module__"] = cls.__module__
    namespace["__qualname__"] = cls.__qualname__
    if hasattr(cls, "__annotations__"):
        namespace["__annotations__"] = cls.__annotations__

    return _FrozenClassMeta(
        cls.__name__,
        cls.__bases__,
        namespace,
    )
