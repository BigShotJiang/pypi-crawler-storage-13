from .main import fullfrozenclass

__all__ = [
    "fullfrozenclass",
]

__call__ = fullfrozenclass