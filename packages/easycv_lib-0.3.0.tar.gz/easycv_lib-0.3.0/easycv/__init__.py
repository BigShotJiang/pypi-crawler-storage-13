"""
EasyCV - A convenient wrapper library for OpenCV

EasyCV provides a simple and intuitive interface for common computer vision
tasks using OpenCV, making it easier to work with images and videos.
"""

__version__ = "0.3.0"
__author__ = "EasyCV Contributors"

# Import modules so they can be accessed directly
from . import vision

# Also import all functions directly for convenience
from .vision import (
    # Image operations
    load_image,
    show_image,
    # Camera operations
    open_camera,
    open_live_window,
    open_live_window_from_file,
    # Hand detection
    detect_hand,
    hand_read,
    count_fingers,
    detect_fist,
    # Face detection
    detect_face,
    face_read,
    count_faces,
    face_tracking,
    enroll_face,
    face_verification,
)

__all__ = [
    'vision',
    # Image operations
    'load_image',
    'show_image',
    # Camera operations
    'open_camera',
    'open_live_window',
    'open_live_window_from_file',
    # Hand detection
    'detect_hand',
    'hand_read',
    'count_fingers',
    'detect_fist',
    # Face detection
    'detect_face',
    'face_read',
    'count_faces',
    'face_tracking',
    'enroll_face',
    'face_verification',
    '__version__',
]

