"""Tests for simpllm package."""
