import os
from dataclasses import dataclass


@dataclass(frozen=True)
class AwsConfig:
    region: str
    items_table: str


@dataclass(frozen=True)
class SalesforceConfig:
    client_id: str | None
    client_secret: str | None
    refresh_token: str | None
    login_base_url: str
    api_version: str


aws_config = AwsConfig(
    region=os.getenv("AWS_REGION", "us-east-1"),
    items_table=os.getenv("ITEMS_TABLE", "DailyBasketItems"),
)

salesforce_config = SalesforceConfig(
    client_id=os.getenv("SF_CLIENT_ID"),
    client_secret=os.getenv("SF_CLIENT_SECRET"),
    refresh_token=os.getenv("SF_REFRESH_TOKEN"),
    login_base_url=os.getenv("SF_LOGIN_BASE_URL", "https://login.salesforce.com"),
    api_version=os.getenv("SF_API_VERSION", "v61.0"),
)
