# dailybasket-support-mithilesh

Support code for the DailyBasket project.

This library contains:

- `SalesforceRefreshClient` – helper for OAuth refresh and REST calls
- `SupportBridge` – creates Salesforce Cases and updates the `DailyBasketItems` DynamoDB table.

## Configuration

This library is configured using environment variables. Typical values are:

### AWS / DynamoDB

- `AWS_REGION` – AWS region for DynamoDB (default: `us-east-1`)
- `ITEMS_TABLE` – DynamoDB table name for orders (default: `DailyBasketItems`)

If you do not set these variables, the defaults above are used.

### Salesforce

The Salesforce integration uses OAuth 2.0 refresh token flow. You must provide:

- `SF_CLIENT_ID` – Salesforce connected app client ID
- `SF_CLIENT_SECRET` – Salesforce connected app client secret
- `SF_REFRESH_TOKEN` – long-lived refresh token issued for the integration user

Optional variables:

- `SF_LOGIN_BASE_URL` – Salesforce login base URL  
  Default: `https://login.salesforce.com`
- `SF_API_VERSION` – Salesforce REST API version  
  Default: `v61.0`

#### Example (Linux / macOS)

```bash
export AWS_REGION="us-east-1"
export ITEMS_TABLE="DailyBasketItems"

export SF_CLIENT_ID="your-salesforce-client-id"
export SF_CLIENT_SECRET="your-salesforce-client-secret"
export SF_REFRESH_TOKEN="your-salesforce-refresh-token"
export SF_LOGIN_BASE_URL="https://login.salesforce.com"
export SF_API_VERSION="v61.0"