#!/usr/bin/env python3
"""
getLandCharacteristics 함수 테스트 스크립트
"""

import asyncio
import os
from pycobaltix.public.vworld.endpoints import AsyncVWorldAPI, VWorldAPI


async def test_get_land_characteristics():
    """getLandCharacteristics 함수 직접 테스트"""
    
    # 환경변수에서 API 키와 도메인 가져오기
    api_key = os.getenv("VWORLD_API_KEY", "AD472917-0B2C-3278-AFE5-1BF6F108E5D6")
    domain = os.getenv("VWORLD_DOMAIN", "www.cobaltix.io")
    
    if not api_key or not domain:
        print("❌ 환경변수가 설정되지 않았습니다.")
        print("다음 명령어로 환경변수를 설정한 후 다시 실행해주세요:")
        print("export VWORLD_API_KEY='your_api_key'")
        print("export VWORLD_DOMAIN='your_domain'")
        print()
        print("또는 터미널에서 직접 실행하려면:")
        print("VWORLD_API_KEY='your_key' VWORLD_DOMAIN='your_domain' uv run python test_land_characteristics.py")
        return
    
    # VWorld API 클라이언트 생성
    api = VWorldAPI(api_key=api_key, domain=domain)
    
    # 테스트용 PNU (서울특별시 종로구 청운동)
    test_pnu = "1111010100100010000"
    
    try:
        print(f"🔍 PNU {test_pnu}에 대한 토지특성정보를 조회합니다...")
        
        # getLandCharacteristics 함수 호출
        result = await AsyncVWorldAPI().getLandCharacteristics(
            domain=domain,
            pnu=test_pnu,
            numOfRows=5,
            pageNo=1
        )
        
        print(f"✅ 요청 성공: {result.success}")
        print(f"📊 상태코드: {result.status}")
        print(f"💬 메시지: {result.message}")
        print(f"📦 데이터 개수: {len(result.data) if result.data else 0}")
        
        # 페이지네이션 정보
        if result.pagination:
            print(f"📄 페이지네이션:")
            print(f"   - 현재 페이지: {result.pagination.currentPage}")
            print(f"   - 전체 페이지: {result.pagination.totalPages}")
            print(f"   - 전체 개수: {result.pagination.totalCount}")
            print(f"   - 페이지당 개수: {result.pagination.count}")
        
        # 데이터 세부 정보
        if result.data and len(result.data) > 0:
            print(f"\n📍 첫 번째 토지특성 정보:")
            first_land = result.data[0]
            
            print(f"   - PNU: {first_land.pnu}")
            print(f"   - 법정동: {first_land.ldCodeNm}")
            print(f"   - 지목: {first_land.lndcgrCodeNm}")
            print(f"   - 면적: {first_land.lndpclAr}㎡")
            print(f"   - 용도지역1: {first_land.prposArea1Nm}")
            
            if hasattr(first_land, 'prposArea2Nm') and first_land.prposArea2Nm:
                print(f"   - 용도지역2: {first_land.prposArea2Nm}")
            
            print(f"   - 토지이용상황: {first_land.ladUseSittnNm}")
            print(f"   - 지형높이: {first_land.tpgrphHgCodeNm}")
            print(f"   - 지형형상: {first_land.tpgrphFrmCodeNm}")
            print(f"   - 도로접면: {first_land.roadSideCodeNm}")
            print(f"   - 최종수정일: {first_land.lastUpdtDt}")
            
            # 예시 데이터와 비교
            print(f"\n🔄 예시 데이터와 실제 데이터 비교:")
            from pycobaltix.public.vworld.response.landCharacteristic import LandCharacteristic
            example = LandCharacteristic.create_example()
            print(f"   - 예시 지목: {example.lndcgrCodeNm}")
            print(f"   - 실제 지목: {first_land.lndcgrCodeNm}")
            
        else:
            print("❌ 조회된 데이터가 없습니다.")
            
    except Exception as e:
        print(f"❌ 오류 발생: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    print("🚀 getLandCharacteristics 함수 테스트")
    print("=" * 50)
    
    # 환경변수 사용법 안내
    print("💡 환경변수 설정 방법:")
    print("export VWORLD_API_KEY='your_api_key'")
    print("export VWORLD_DOMAIN='your_domain'")
    print()
    
    # async 함수 실행
    asyncio.run(test_get_land_characteristics())
