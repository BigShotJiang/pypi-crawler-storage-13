from typing import Optional
from typing_extensions import TypedDict

# 检查更新（options: url/timeout/version），返回 {needUpdate,data?,error?}
class HotUpdateResponse(TypedDict):
    download_url: str
    version: int
    download_timeout: int
    dialog: bool
    msg: str
    force: bool
    md5: Optional[str]

class HotUpdateResult(TypedDict):
    needUpdate: bool
    error: Optional[str]
    data: Optional[HotUpdateResponse]

class HotUpdateOptions(TypedDict, total=False):
    url: str
    version: int
    timeout: int

def check_update(options: HotUpdateOptions) -> HotUpdateResult:
    """检查更新

    参数:
      options: 检查参数（url/version/timeout）
    返回:
      HotUpdateResult: needUpdate/data/error
    """
    ...

# 下载并安装（返回 {updated,error?}）
class InstallResult(TypedDict):
    updated: bool
    error: Optional[str]

def download_and_install() -> InstallResult:
    """下载并安装更新（执行成功会自动重启脚本）"""
    ...

# 获取当前应用版本号（整数）
def get_current_version() -> int:
    """获取当前应用版本号（数字）"""
    ...
