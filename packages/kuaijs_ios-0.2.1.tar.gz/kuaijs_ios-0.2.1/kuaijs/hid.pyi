from typing import Any, List, Optional, Literal
from typing_extensions import TypedDict

class AppInfo(TypedDict):
    name: str
    bundleId: str

# 设置动作抖动值（像素，随屏幕 scale 适配）
def set_jitter_value(value: int) -> None: ...

# 重置坐标系方向（如 "portrait" | "landscape"）
def reset_position(orientation: Literal["PORTRAIT", "LANDSCAPE"] = ...) -> None:
    """重置坐标系方向

    参数:
      orientation: 屏幕方向（PORTRAIT/LANDSCAPE）
    """
    ...

# 点击
# 参数：x/y 坐标；duration 持续时间（ms）；jitter 是否启用抖动
def click(x: int, y: int, duration: int = ..., jitter: bool = ...) -> bool:
    """点击指定坐标

    参数:
      x/y: 坐标
      duration: 按下时长（毫秒，默认 10ms）
      jitter: 是否启用抖动（默认 False）
    返回:
      bool: 是否成功
    """
    ...

# 随机点击指定矩形区域
def click_random(x1: int, y1: int, x2: int, y2: int, duration: int = ...) -> bool:
    """随机点击指定矩形区域

    参数:
      x1/y1/x2/y2: 矩形区域坐标
      duration: 按下时长（毫秒，默认 20ms）
    返回:
      bool: 是否成功
    """
    ...

# 双击
# 参数：duration 持续时间；interval 间隔时间（ms）；jitter 是否抖动
def double_click(
    x: int, y: int, duration: int = ..., interval: int = ..., jitter: bool = ...
) -> bool:
    """双击指定坐标

    参数:
      duration: 每次按下时长（毫秒，默认 20ms）
      interval: 两次点击间隔（毫秒，默认 20ms）
      jitter: 是否启用抖动（默认 False）
    """
    ...

# 随机双击指定区域
def double_click_random(
    x1: int, y1: int, x2: int, y2: int, duration: int = ..., interval: int = ...
) -> bool:
    """随机双击矩形区域"""
    ...

# 直线滑动
# 参数：起点 x/y；终点 ex/ey；jitter 抖动；steps 轨迹点数
def swipe(
    x: int, y: int, ex: int, ey: int, jitter: bool = ..., steps: int = ...
) -> bool:
    """直线滑动

    参数:
      jitter: 是否启用抖动（默认 False）
      steps: 轨迹点数量（默认 6）
    """
    ...

# 3 点曲线滑动（先快后慢）
def swipe_curve(
    startX: int, startY: int, midX: int, midY: int, endX: int, endY: int
) -> bool:
    """3 点曲线滑动"""
    ...

# 回主页（Command+H）
def home_screen() -> bool:
    """回主页（Command+H）"""
    ...

# 输入简单键盘数据（仅英文与可输入键；不支持中文）
def input_simple(data: str) -> bool:
    """输入简单文本（英文及可输入键）"""
    ...

# 空格/删除/回车
def space() -> bool:
    """空格键"""
    ...

def backspace() -> bool:
    """删除键"""
    ...

def enter() -> bool:
    """回车键"""
    ...

# 发送组合按键（支持 Int 或字符）
def send_key(keys: List[Any]) -> bool:
    """发送组合按键（支持数字或字符）"""
    ...

# 复制/粘贴/返回/最近应用/锁屏/解锁
def copy_text() -> bool:
    """复制文本（Command+C）"""
    ...

def paste_text() -> bool:
    """粘贴文本（Command+V）"""
    ...

def back() -> bool:
    """返回（Tab+B）"""
    ...

def recent() -> bool:
    """APP 切换器"""
    ...

def lock() -> bool:
    """锁屏"""
    ...

def unlock() -> bool:
    """解锁"""
    ...

# 打开 URL / App；切到前台
def open_url(url: str) -> bool:
    """打开 URL"""
    ...

def open_app(name: str) -> bool:
    """打开 App"""
    ...

def take_me_to_front() -> bool:
    """切到前台"""
    ...

# 当前应用信息（仅 IOS18+）
def current_app_info() -> Optional[AppInfo]:
    """当前应用信息（仅 iOS18+）"""
    ...

# 剪切板读写
def set_clipboard(text: str) -> bool:
    """设置剪贴板"""
    ...

def get_clipboard() -> str:
    """获取剪贴板"""
    ...

# 执行自定义按钮（1-11）
def custom_button(button: int) -> bool:
    """执行自定义按钮（1-11）"""
    ...
