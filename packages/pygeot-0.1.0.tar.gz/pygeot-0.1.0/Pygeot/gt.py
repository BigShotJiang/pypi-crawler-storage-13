
import tkinter as tk

def new():
    root = tk.Tk()
    return root

def gt(pencere, boyut="500x500"):
    pencere.geometry(boyut)

def title(pencere, yazı="Başlık"):
    pencere.title(yazı)

def FIGUR_canva(pencere, boyut="500x500", symbols="square"):
    canvas = tk.Canvas(pencere, width=int(boyut.split('x')[0]), height=int(boyut.split('x')[1]))
    canvas.pack()
    if symbols == "square":
        canvas.create_rectangle(50,50,150,150, fill="blue")
    elif symbols == "line":
        canvas.create_line(0,0,200,200, fill="red", width=3)
    elif symbols == "round":
        canvas.create_oval(50,50,150,150, fill="green")
    return canvas

def moveing(mouse="left_go", yön="right-left"):
    print(f"Mouse {mouse} kaydırınca {yön} hareket edecek")

def wasd_moveing(wasd="w_go", forward="forward", wasd_a="a_go", left="left",
                  wasd_s="s_go", back="back", wasd_d="d_go", right="right"):
    print(f"WASD hareketleri ayarlandı: W:{forward}, A:{left}, S:{back}, D:{right}")
