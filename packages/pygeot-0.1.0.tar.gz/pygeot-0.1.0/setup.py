
from setuptools import setup, find_packages

setup(
    name="Pygeot",
    version="0.1.0",
    packages=find_packages(),
    description="Tkinter tabanlı figür oluşturma ve hareket paketi",
    author="Pygeot Creator",
    python_requires='>=3.10',
)
