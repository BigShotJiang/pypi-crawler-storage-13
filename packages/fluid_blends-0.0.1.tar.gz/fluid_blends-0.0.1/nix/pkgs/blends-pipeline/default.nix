{ lib' }:
let
  rules = {
    default = lib'.pipeline.core.rules.titleRule {
      products = [ "all" "blends" ];
      types = [ ];
    };
    noChore = lib'.pipeline.core.rules.titleRule {
      products = [ "all" "blends" ];
      types = [ "feat" "fix" "refac" ];
    };
  };
in lib'.pipeline.sync {
  name = "blends-pipeline";
  targetPath = ".gitlab-ci.yaml";
  pipeline = {
    blends-lint = lib'.pipeline.jobs.nix {
      cache = {
        key = "$CI_COMMIT_REF_NAME-blends-lint";
        paths = [ "blends/.ruff_cache" "blends/.mypy_cache" ];
      };
      component = "blends";
      rules = lib'.pipeline.rules.dev ++ [ rules.noChore ];
      script = [ "nix run .#blends-lint" ];
      stage = lib'.pipeline.stages.test;
      tags = [ lib'.pipeline.tags.aarch64 ];
    };
    blends-deploy = lib'.pipeline.jobs.nix {
      component = "blends";
      rules = lib'.pipeline.rules.prod ++ [ rules.noChore ];
      script = [ "nix run .#blends-deploy" ];
      stage = lib'.pipeline.stages.deploy;
      tags = [ lib'.pipeline.tags.aarch64 ];
    };
  };
}
