"""
``smolgp`` is designed to be a drop-in extension of the `tinygp <https://github.com/dfm/tinygp>`_ 
library for building Gaussian Process (GP) models in Python. It is also built 
on top of `jax <https://github.com/google/jax>`_. ``smolgp`` uses state space
representations of Gaussian Processes to implement linear-time (or up to logN with
parallelization on GPU) solvers for GP regression and forecasting. It also implements 
"integrated" kernels that can model time-averaged measurements, such as those from 
long-exposure astronomical observations, which can also be solved in linear time and is
compatible with the parallel methods.

The primary way that you will use to interact with ``smolgp`` is by constructing
"kernel" functions using the building blocks provided in the ``kernels``
subpackage (see :ref:`api-kernels`), and then passing that to a
:class:`GaussianProcess` object to do all the computations. Check out the
:ref:`tutorials` for a more complete introduction.
"""

from smolgp import (
    kernels as kernels,
    solvers as solvers,
)
from smolgp.gp import GaussianProcess as GaussianProcess
# from smolgp.smolgp_version import __version__ as __version__
