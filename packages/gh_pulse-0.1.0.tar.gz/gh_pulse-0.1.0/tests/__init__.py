"""Tests for gitpulse."""
