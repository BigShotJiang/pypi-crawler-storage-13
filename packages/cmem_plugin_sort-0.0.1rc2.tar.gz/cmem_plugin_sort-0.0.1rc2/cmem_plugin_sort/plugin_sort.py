"""Deduplicate lines in text files"""

import contextlib
import heapq
import os
import shutil
import subprocess
import tempfile
from collections.abc import Generator, Sequence
from concurrent.futures import ThreadPoolExecutor
from os import cpu_count
from pathlib import Path

from cmem_plugin_base.dataintegration.context import ExecutionContext
from cmem_plugin_base.dataintegration.description import Icon, Plugin, PluginParameter
from cmem_plugin_base.dataintegration.entity import Entities, Entity
from cmem_plugin_base.dataintegration.plugins import WorkflowPlugin
from cmem_plugin_base.dataintegration.ports import FixedNumberOfInputs, FixedSchemaPort
from cmem_plugin_base.dataintegration.typed_entities.file import FileEntitySchema, LocalFile
from cmem_plugin_base.dataintegration.types import (
    BoolParameterType,
    IntParameterType,
)
from cmem_plugin_base.dataintegration.utils import setup_cmempy_user_access

from . import MEMORY

PROCESSES_DEFAULT = max(1, cpu_count() - 1)  # type: ignore[operator]
BUFFER_SIZE_DEFAULT = int(0.1 * MEMORY / (1024**2))  # 10% of RAM in MB
MAX_MEMORY = int(0.5 * MEMORY / (1024**2))  # 50% of RAM in MB

WRITE_BUFFER_SIZE = 10000  # lines to buffer before writing to disk

# Cache for GNU sort availability check
_GNU_SORT_AVAILABLE: bool | None = None


def is_gnu_sort_available() -> bool:
    """Check if GNU sort is available on the system.

    Returns:
        True if GNU sort is available and working, False otherwise.

    """
    global _GNU_SORT_AVAILABLE  # noqa: PLW0603
    if _GNU_SORT_AVAILABLE is not None:
        return _GNU_SORT_AVAILABLE

    try:
        # Check if sort command exists
        if shutil.which("sort") is None:
            _GNU_SORT_AVAILABLE = False
            return False

        # Verify it's GNU sort by checking version
        result = subprocess.run(
            ["sort", "--version"],  # noqa: S607
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )
        # GNU sort will have "GNU" in version output
        _GNU_SORT_AVAILABLE = "GNU" in result.stdout
        return _GNU_SORT_AVAILABLE  # noqa: TRY300
    except (subprocess.TimeoutExpired, OSError):
        _GNU_SORT_AVAILABLE = False
        return False


def sort_with_gnu_sort(
    input_path: str,
    output_path: str,
    dedupe: bool = True,
    processes: int = 1,
    buffer_size: int = BUFFER_SIZE_DEFAULT,
) -> None:
    """Sort file using GNU sort command.

    Args:
        input_path: Path to input file.
        output_path: Path to output file.
        dedupe: Whether to deduplicate lines (uses sort -u).
        processes: Number of parallel threads for GNU sort.
        buffer_size: Buffer size in MB for sorting.

    """
    cmd = ["sort"]

    # Add buffer size (GNU sort accepts --buffer-size in bytes or with K/M/G suffix)
    cmd.extend(["--buffer-size", f"{buffer_size}M"])

    # Add parallel processing if supported (GNU sort 8.6+)
    if processes > 1:
        cmd.extend(["--parallel", str(processes)])

    # Add unique flag if deduplication is requested
    if dedupe:
        cmd.append("-u")

    # Add input and output files
    cmd.extend(["-o", output_path, input_path])

    # Execute GNU sort
    subprocess.run(cmd, check=True, capture_output=True, text=True)  # noqa: S603


def chunk_sort_and_save(lines: list[str]) -> str:
    """Sort lines in memory and save to a temporary file.

    Args:
        lines: List of strings to sort and save.

    Returns:
        Path to the temporary file containing sorted lines.

    """
    lines.sort()
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.writelines(lines)
    return path


def merge_sorted_files(paths: list[str], output_path: str, dedupe: bool = True) -> None:
    """Merge sorted files into a single output file with optional deduplication.

    Args:
        paths: List of paths to sorted temporary files.
        output_path: Path where the merged and deduplicated output will be written.
        dedupe: Whether to deduplicate consecutive duplicate lines.

    """
    with contextlib.ExitStack() as stack:
        files = [
            stack.enter_context(Path(p).open(encoding="utf-8", errors="replace")) for p in paths
        ]
        with Path(output_path).open("w", encoding="utf-8") as outfile:
            prev = None
            buffer = []
            for line in heapq.merge(*files):
                # Only dedupe if requested
                if not dedupe or line != prev:
                    buffer.append(line)
                    # Write in batches for better I/O performance
                    if len(buffer) >= WRITE_BUFFER_SIZE:
                        outfile.writelines(buffer)
                        buffer = []
                    prev = line if dedupe else None
            # Write remaining buffered lines
            if buffer:
                outfile.writelines(buffer)
    # Clean up temporary files
    for p in paths:
        Path(p).unlink(missing_ok=True)


def external_sort_dedupe(
    input_path: str,
    output_path: str,
    dedupe: bool = True,
    processes: int = 1,
    buffer_size: int = BUFFER_SIZE_DEFAULT,
) -> None:
    """Sort and deduplicate a large file using external sorting algorithm.

    Tries to use GNU sort if available for best performance, falls back to Python
    implementation otherwise.

    Args:
        input_path: Path to the input file to be sorted and deduplicated.
        output_path: Path where the sorted and deduplicated output will be written.
        dedupe: Whether to deduplicate consecutive duplicate lines.
        processes: Number of parallel workers.
        buffer_size: Buffer size in MB for sorting.

    """
    # Try GNU sort first for best performance
    if is_gnu_sort_available():
        try:
            sort_with_gnu_sort(input_path, output_path, dedupe, processes, buffer_size)
            return  # noqa: TRY300
        except (subprocess.CalledProcessError, OSError):
            # Fall through to Python implementation if GNU sort fails
            pass

    # Python implementation fallback
    # Calculate chunk size based on buffer_size (assume avg 100 bytes per line)
    chunk_size = max(1000, (buffer_size * 1024 * 1024) // 100)

    # Collect chunks from input file
    chunks = []
    with Path(input_path).open(encoding="utf-8", errors="replace") as infile:
        lines = []
        for line in infile:
            lines.append(line)
            if len(lines) >= chunk_size:
                chunks.append(lines)
                lines = []
        if lines:
            chunks.append(lines)

    # Sort chunks in parallel if multiple workers are requested
    # Note: Using ThreadPoolExecutor for JEP compatibility
    # While sorting is CPU-bound, threads work in JEP environments
    # where ProcessPoolExecutor can cause issues with process forking
    if processes > 1 and len(chunks) > 1:
        with ThreadPoolExecutor(max_workers=processes) as executor:
            paths = list(executor.map(chunk_sort_and_save, chunks))
    else:
        # Sequential sorting for single worker or single chunk
        paths = [chunk_sort_and_save(chunk) for chunk in chunks]

    merge_sorted_files(paths, output_path, dedupe)


@Plugin(
    label="Sort and deduplicate lines in text files",
    description="Efficiently sort and optionally deduplicate lines in "
    "large text files using external merge sort algorithm.",
    documentation="""This plugin performs lexicographic (alphabetical)
     sorting of lines in text files,
with optional deduplication of consecutive duplicate lines.

**Features:**
- Memory-efficient external merge sort for large files
- Automatic use of GNU sort when available for best performance
- Configurable parallel processing and memory usage
- Handles files larger than available RAM

**How it works:**
1. Lines are sorted lexicographically (like UNIX sort command)
2. If deduplication is enabled, consecutive duplicate lines are removed after sorting
3. Uses GNU sort if available on the system, otherwise uses Python implementation

**Performance tuning:**
- Increase `buffer_size` for better performance with large files (uses more RAM)
- Increase `processes` to utilize multiple CPU cores for faster sorting
- Default settings work well for most use cases

**Use cases:**
- Preparing data for merge operations
- Removing duplicate entries from logs or datasets
- Normalizing line order for comparison
""",
    icon=Icon(package=__package__, file_name="sort_icon.svg"),
    parameters=[
        PluginParameter(
            param_type=BoolParameterType(),
            name="dedupe",
            label="Deduplicate lines",
            description="Remove consecutive duplicate lines after sorting. "
            "Note: Only adjacent duplicates are removed,"
            " so all duplicates will be eliminated after sorting.",
        ),
        PluginParameter(
            param_type=IntParameterType(),
            name="processes",
            label="Number of parallel workers",
            description="""Number of parallel workers for sorting (default: CPU cores - 1).
             Increase for better performance on multi-core systems with large files.""",
            advanced=True,
            default_value=PROCESSES_DEFAULT,
        ),
        PluginParameter(
            param_type=IntParameterType(),
            name="buffer_size",
            label="""Buffer size (MB)""",
            description="""Buffer size in MB for sorting (default: 10% of total RAM).
             Larger values improve performance but use more memory.
             Applies to both GNU sort and Python implementation.""",
            advanced=True,
            default_value=BUFFER_SIZE_DEFAULT,
        ),
    ],
)
class PluginSort(WorkflowPlugin):
    """Dedupe lines in text files plugin"""

    context: ExecutionContext

    def __init__(
        self,
        dedupe: bool = False,
        processes: int = PROCESSES_DEFAULT,
        buffer_size: int = BUFFER_SIZE_DEFAULT,
    ) -> None:
        if processes < 1:
            raise ValueError("Number of workers must be greater than 0.")
        if buffer_size < 1 or buffer_size > MAX_MEMORY:
            raise ValueError(f"Buffer size must be between 1 and {MAX_MEMORY}MB.")
        self.dedupe = dedupe
        self.processes = processes
        self.buffer_size = buffer_size
        self._set_ports()

    def _set_ports(self) -> None:
        self.input_ports = FixedNumberOfInputs([FixedSchemaPort(schema=FileEntitySchema())])
        self.output_port = FixedSchemaPort(schema=FileEntitySchema())

    def cancel_workflow(self) -> bool:
        """Cancel workflow"""
        if hasattr(self.context, "workflow") and self.context.workflow.status() != "Running":
            self.log.info("End task (Cancelled Workflow).")
            return True
        return False

    def execute(self, inputs: Sequence, context: ExecutionContext) -> Entities:
        """Run the workflow operator"""
        self.context = context
        setup_cmempy_user_access(context.user)

        schema = FileEntitySchema()

        def generate_entities() -> Generator[Entity, None, None]:
            for entity in inputs[0].entities:
                entity_file = schema.from_entity(entity)
                with entity_file.text_stream(context.task.project_id()) as fs:
                    # Write to temp file
                    input_fd, input_temp_path = tempfile.mkstemp(suffix=".txt")
                    try:
                        with os.fdopen(input_fd, "wb") as input_temp:
                            for line in fs:
                                if isinstance(line, str):
                                    input_temp.write(line.encode("utf-8"))
                                else:
                                    input_temp.write(line)

                        # Create output temp file
                        output_fd, output_temp_path = tempfile.mkstemp(suffix=".txt")
                        os.close(output_fd)

                        # Sort and deduplicate using configured parameters
                        external_sort_dedupe(
                            input_temp_path,
                            output_temp_path,
                            dedupe=self.dedupe,
                            processes=self.processes,
                            buffer_size=self.buffer_size,
                        )

                        output_file = LocalFile(
                            path=output_temp_path,
                            mime=entity_file.mime,
                        )
                        yield schema.to_entity(output_file)
                    finally:
                        # Clean up input temp file
                        Path(input_temp_path).unlink(missing_ok=True)

        return Entities(entities=generate_entities(), schema=schema)
