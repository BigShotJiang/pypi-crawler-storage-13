"""cmem-plugin-sort"""

from psutil import virtual_memory

MEMORY = virtual_memory().total
