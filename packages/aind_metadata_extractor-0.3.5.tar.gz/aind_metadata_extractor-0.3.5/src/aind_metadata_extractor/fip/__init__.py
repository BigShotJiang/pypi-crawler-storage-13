"""FIP metadata extractor module."""
