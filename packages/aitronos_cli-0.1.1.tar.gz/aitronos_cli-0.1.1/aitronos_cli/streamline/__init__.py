"""Streamline automation management commands."""

