"""Utility functions and helpers."""

