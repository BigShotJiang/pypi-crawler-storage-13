# Selector CLI tests
