from setuptools import setup

setup(
    name='udtools',
    version='0.1.0',    
    description='Python tools for Universal Dependencies',
    url='https://universaldependencies.org/',
    author='Daniel Zeman',
    author_email='zeman@ufal.mff.cuni.cz',
    license='GNU GPLv2',
    packages=['udtools'],
    install_requires=['udapi>=0.5.0',
                      'regex>=2020.09.27',
                      ],

    classifiers=[
        'Development Status :: 1 - Planning',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: GNU General Public License v2 (GPLv2)',  
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.11',
    ],
)

