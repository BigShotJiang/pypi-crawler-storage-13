"""
SafeKeyLab SDK - Enterprise PII Detection, Data Protection, and LLM Security
"""

__version__ = "2.2.0"
__author__ = "SafeKey Lab Inc."

from .client import SafeKeyLab
from .client_v2 import (
    SafeKeyLabClient,
    RateLimitException,
    QuotaExceededException,
    FeatureNotAvailableException,
    create_client
)
from .scanner import PIIScanner
from .protector import DataProtector
from .exceptions import SafeKeyLabException, APIError, ValidationError
from .llm_guard import LLMGuardClient, ThreatDetector, ComplianceManager

__all__ = [
    # Core client
    "SafeKeyLab",
    # New v2 client with subscription support
    "SafeKeyLabClient",
    "create_client",
    "RateLimitException",
    "QuotaExceededException",
    "FeatureNotAvailableException",
    # PII detection
    "PIIScanner",
    "DataProtector",
    # Exceptions
    "SafeKeyLabException",
    "APIError",
    "ValidationError",
    # LLM Guard features
    "LLMGuardClient",
    "ThreatDetector",
    "ComplianceManager",
]