"""
I-LIMR: Inspiral-Late-Inspiral-Merger-Ringdown

Here we hybridise LIMR with an inspiral.
"""

import phenom
import numpy as np

import limr.limr_model
import limr.inspiral_model

class ILIMR:
    def __init__(self, limr_model:limr.limr_model.LIMR):
        self.limr_model = limr_model
        self.modes = self.limr_model.modes

    def predict(self, q, M, f_min, deltaT, approximant='IMRPhenomTHM', end_time=100):

        # generate the base HM inspiral
        inspiral_hlm = limr.inspiral_model.get_inspiral_hlm(
            approximant=approximant,
            modes=self.modes,
            q=q,
            M=M,
            f_min=f_min,
            deltaT=deltaT,
            )
        
        
        
        # generate the LIMR waveform
        deltaT_M = phenom.StoM(deltaT, M)
        # the first limr sample is going to be the last sample
        # from the inspiral
        # and when we join the two together we
        # will drop either the last inspiral and the first limr
        # sample to have a contiguous time series
        t_limr_start = inspiral_hlm.times[-1]
        limr_times = np.arange(t_limr_start, end_time, deltaT_M)
        limr_hlm = self.limr_model.predict(limr_times, q)

        # determine amplitude and phase connection
        # of the type (1 + A * (t - T_0))
        # where A is the free parameter
        # and T_0 is the start of the inspiral waveform
        Amp_A0 = {}
        T_0 = inspiral_hlm.times[0]

        n_modes = limr_hlm.shape[0]
        n_samples = limr_hlm.shape[1]
        n_times = len(inspiral_hlm.times)
        inspiral_amp = np.zeros(shape=(n_modes, n_samples, n_times))
        # inspiral_phase = np.zeros(shape=(n_modes, n_samples, n_times))


        # -1 because there is one sample that overlaps
        n_ilimr_times = len(inspiral_hlm.times) + len(limr_times) - 1
        ilimr_times = np.concatenate((inspiral_hlm.times[:-1], limr_times))
        ilimr_amp = np.zeros(shape=(n_modes, n_samples, n_ilimr_times))
        ilimr_phase = np.zeros(shape=(n_modes, n_samples, n_ilimr_times))
        ilimr_hlm = np.zeros(shape=(n_modes, n_samples, n_ilimr_times), dtype=np.complex128)
        
        for mode, mode_index in self.limr_model.mode_to_index.items():
            B_ = np.abs(inspiral_hlm.hlms[mode])[-1]
            C_ = np.abs(limr_hlm[mode_index, 0])[0]
            Amp_A0 = (C_/B_ - 1)/(t_limr_start-T_0)

            amp_correction = (1 + Amp_A0 * (inspiral_hlm.times-T_0))
            inspiral_amp[mode_index,0,:] = np.abs(inspiral_hlm.hlms[mode]) * amp_correction

            # align phase
            phase_ins = np.unwrap(np.angle(inspiral_hlm.hlms[mode]))
            phase_limr = np.unwrap(np.angle(limr_hlm[mode_index, 0]))
            shift = phase_ins[-1] - phase_limr[0]
            # shift limr to match inspiral
            # phase_limr = phase_limr + shift
            # shift inspiral to match limr (this way make it easier to compare with limr)
            phase_ins = phase_ins - shift

            ilimr_amp[mode_index, 0, :] = np.concatenate((inspiral_amp[mode_index, 0, :-1], np.abs(limr_hlm[mode_index,0,:])), axis=0)
            ilimr_phase[mode_index, 0, :] = np.concatenate((phase_ins[:-1], phase_limr), axis=0)
            ilimr_hlm[mode_index,0,:] = ilimr_amp[mode_index, 0, :] * np.exp(1.j * ilimr_phase[mode_index, 0, :])

        # re-interpolate onto final time grid ... if i've done it correctly then i don't need to reinterpolate

        # output

        return ilimr_times, ilimr_hlm

    def sample(self):
        pass