"""Init of django_oemof app, holds version"""

VERSION = "2.2.0"
