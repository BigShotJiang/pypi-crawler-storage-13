import math
import pytest
import sys

sys.path.insert(0, sys.path[0] + "/..")
import unitspy as up

def test_complexquantity_default_construction() -> None:
    cq = up.ComplexQuantity()
    assert cq == 1
    assert isinstance(cq, up.Quantity)

def test_complexquantity_construction_from_float() -> None:
    cq = up.ComplexQuantity(2.5)
    assert cq == 2.5
    assert isinstance(cq, up.Quantity)

def test_complexquantity_construction_from_complex() -> None:
    cq = up.ComplexQuantity(2+3j)
    assert cq == 2+3j
    assert not isinstance(cq, up.Quantity)

def test_complexquantity_construction_from_unit() -> None:
    cq = up.ComplexQuantity(up.m)
    assert cq == 1 * up.m
    assert isinstance(cq, up.Quantity)

def test_complexquantity_construction_from_float_and_unit() -> None:
    cq = up.ComplexQuantity(2.5, up.m)
    assert cq == 2.5 * up.m
    assert isinstance(cq, up.Quantity)

def test_complexquantity_construction_from_complex_and_unit() -> None:
    cq = up.ComplexQuantity(2+3j, up.m)
    assert cq == (2+3j) * up.m
    assert not isinstance(cq, up.Quantity)

def test_complexquantity_construction_invalid_type() -> None:
    with pytest.raises(TypeError):
        up.ComplexQuantity([1, 2, 3]) # type: ignore

def test_quantity_default_construction() -> None:
    q = up.Quantity()
    assert q == 1
    assert isinstance(q, up.Quantity)

def test_quantity_construction_from_float() -> None:
    q = up.Quantity(2.5)
    assert q == 2.5
    assert isinstance(q, up.Quantity)

def test_quantity_construction_from_complex() -> None:
    with pytest.raises(TypeError):
        up.Quantity(2+3j) # type: ignore

def test_quantity_construction_from_unit() -> None:
    q = up.Quantity(up.m)
    assert q == 1 * up.m
    assert isinstance(q, up.Quantity)

def test_quantity_construction_from_float_and_unit() -> None:
    q = up.Quantity(2.5, up.m)
    assert q == 2.5 * up.m
    assert isinstance(q, up.Quantity)

def test_quantity_construction_from_complex_and_unit() -> None:
    with pytest.raises(TypeError):
        up.Quantity(2+3j, up.m) # type: ignore

def test_quantity_construction_invalid_type() -> None:
    with pytest.raises(TypeError):
        up.Quantity([1, 2, 3]) # type: ignore

def test_multiplication() -> None:
    q1 = 2 * up.m
    q2 = 3 * up.m
    q3 = 1j * up.m

    assert isinstance(q1, up.Quantity)
    assert isinstance(q2, up.Quantity)
    assert isinstance(q3, up.ComplexQuantity)
    assert not isinstance(q3, up.Quantity)

    assert q1 * q2 == 6 * up.m**2
    assert isinstance(q1 * q2, up.Quantity)
    assert q1 * q3 == 2j * up.m**2
    assert isinstance(q1 * q3, up.ComplexQuantity)
    assert not isinstance(q1 * q3, up.Quantity)

def test_addition() -> None:
    q1 = 2 * up.m
    q2 = 3 * up.m
    q3 = 1j * up.m
    q4 = 4 * up.kg

    assert q1 + q2 == 5 * up.m
    assert isinstance(q1 + q2, up.Quantity)
    assert q1 + q3 == (2+1j) * up.m
    assert isinstance(q1 + q3, up.ComplexQuantity)
    assert not isinstance(q1 + q3, up.Quantity)
    assert q4 + q4 == 8 * up.kg
    assert isinstance(q4 + q4, up.Quantity)

    with pytest.raises(ValueError):
        q1 + q4
    with pytest.raises(ValueError):
        q2 + q4
    with pytest.raises(ValueError):
        q3 + q4

def test_int_conversion() -> None:
    q1 = up.Quantity(2.5)
    q2 = 2 * up.m

    assert int(q1) == 2
    with pytest.raises(ValueError):
        int(q2)

def test_float_conversion() -> None:
    q1 = up.Quantity(2.5)
    q2 = 2 * up.m

    assert float(q1) == 2.5
    with pytest.raises(ValueError):
        float(q2)

def test_complex_conversion() -> None:
    q1 = up.ComplexQuantity(2.5j)
    q2 = 2j * up.m

    assert complex(q1) == 2.5j
    with pytest.raises(ValueError):
        complex(q2)

def test_to_unit() -> None:
    q = 2000 * up.m
    assert q.toUnit(up.km) == 2 * up.km
    with pytest.raises(ValueError):
        q.toUnit(up.s)

def test_to_si_units() -> None:
    q = 2000 * up.g
    assert q.toSiUnits() == 2 * up.kg

def test_to_planck_units() -> None:
    q1 = 1 * up.m
    q2 = 1 * up.m / up.s

    assert q1.toPlanckUnits() == 6.187142405676738e+34 * up.l_p
    assert q2.toPlanckUnits() == 3.3356409519815204e-09 * up.c

def test_moles_to_dimensionless() -> None:
    q1 = 2 * up.mol
    q2 = 3 * up.s

    assert math.isclose(q1.molesToDimensionless(), 1.204428152e+24)
    assert math.isclose(up.NA.molesToDimensionless(), 1)
    assert q2.molesToDimensionless() == q2

def test_is_dimensionless() -> None:
    q1 = up.Quantity(2)
    q2 = up.ComplexQuantity(3j)
    q3 = 2 * up.mol

    assert q1.isDimensionless()
    assert q2.isDimensionless()
    assert not q3.isDimensionless()
    assert not up.c.isDimensionless()
    assert not up.kB.isDimensionless()

def test_dimensionless_to_float() -> None:
    q1 = up.Quantity(2)
    q2 = up.ComplexQuantity(3j)
    q3 = 2 * up.mol

    q1Float = q1.dimensionlessToFloat()
    q2Float = q2.dimensionlessToFloat()
    q3Float = q3.dimensionlessToFloat()
    cFloat = up.c.dimensionlessToFloat()
    kBFloat = up.kB.dimensionlessToFloat()

    assert q1Float == 2
    assert isinstance(q1Float, float)
    assert q2Float == 3j
    assert isinstance(q2Float, complex)
    assert q3Float == q3
    assert isinstance(q3Float, up.Quantity)
    assert cFloat == up.c
    assert isinstance(cFloat, up.Quantity)
    assert kBFloat == up.kB
    assert isinstance(kBFloat, up.Quantity)

def test_abs() -> None:
    q1 = -2 * up.m
    q2 = 3j * up.s

    assert abs(q1) == 2 * up.m
    assert isinstance(abs(q1), up.Quantity)
    assert abs(q2) == 3 * up.s
    assert isinstance(abs(q2), up.Quantity)

def test_round() -> None:
    q1 = 1.6 * up.km
    q2 = 0.6 * up.mi

    assert round(q1) == 2 * up.km
    assert round(q2) == 1 * up.mi

def test_comparison() -> None:
    q1 = 2 * up.m
    q2 = 3 * up.m
    assert q1 != q2
    assert q1 < q2
    assert q2 > q1
    assert q1 <= q2
    assert q2 >= q1

def test_invalid_comparison() -> None:
    q1 = 2 * up.m
    q2 = 3 * up.s
    assert q1 != q2
    with pytest.raises(ValueError):
        assert q1 < q2
    with pytest.raises(ValueError):
        assert q2 > q1
    with pytest.raises(ValueError):
        assert q1 <= q2
    with pytest.raises(ValueError):
        assert q2 >= q1
