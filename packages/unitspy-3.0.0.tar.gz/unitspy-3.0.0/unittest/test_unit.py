import pytest
import sys

sys.path.insert(0, sys.path[0] + "/..")
import unitspy as up

def test_default_construction() -> None:
    u = up.Unit()
    assert u == up.dimensionless

def test_float_construction() -> None:
    u = up.Unit(5.0)
    assert u == 5 * up.dimensionless

def test_copy_construction() -> None:
    u1 = up.Unit(2.0)
    u2 = up.Unit(u1)
    assert u1 == u2

def test_equality() -> None:
    u1 = up.Unit(3.0)
    u2 = up.Unit(3.0)
    assert u1 == u2
    assert not (u1 != u2)

def test_inequality() -> None:
    u1 = up.Unit(3.0)
    u2 = up.Unit(4.0)
    assert u1 != u2
    assert u1 != up.dimensionless
    assert u1 != up.m

def test_is_multiple() -> None:
    u1 = up.Unit(3.0)
    u2 = up.Unit(4.0)
    assert u1.isMultiple(u2)
    assert u1.isMultiple(up.dimensionless)
    assert not u1.isMultiple(up.m)
    assert not up.m.isMultiple(u1)

def test_is_si_unit() -> None:
    assert up.dimensionless.isSiUnit()
    assert up.m.isSiUnit()
    assert (up.m / up.s).isSiUnit()
    assert not up.km.isSiUnit()
    assert not up.Unit(up.l_p).isSiUnit()

def test_is_planck_unit() -> None:
    assert up.dimensionless.isPlanckUnit()
    assert not up.m.isPlanckUnit()
    assert not up.km.isPlanckUnit()
    assert up.Unit(up.l_p).isPlanckUnit()
    assert up.Unit(up.l_p / up.t_p).isPlanckUnit()

def test_int_conversion() -> None:
    u1 = up.Unit(2.5)
    assert int(u1) == 2
    assert int(up.dimensionless) == 1
    with pytest.raises(ValueError):
        int(up.m)

def test_float_conversion() -> None:
    u1 = up.Unit(2.5)
    assert float(u1) == 2.5
    assert float(up.dimensionless) == 1
    with pytest.raises(ValueError):
        float(up.m)
