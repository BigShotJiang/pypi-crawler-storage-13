
import unittest
from unittest.mock import MagicMock, patch, mock_open
import os
from src.zk_doc_mcp.doc_indexer import DocIndexer

class TestDocIndexer(unittest.TestCase):

    def setUp(self):
        self.test_doc_path = "/tmp/test_docs"
        os.makedirs(self.test_doc_path, exist_ok=True)

        # Create a DocIndexer instance
        self.indexer = DocIndexer(doc_path=self.test_doc_path)

        # Mock the internal dependencies of the DocIndexer instance
        self.indexer.client = MagicMock()
        self.indexer.collection = MagicMock()
        self.indexer.collection.count.return_value = 0 # Mock count to return 0 for initial state

    def tearDown(self):
        # Clean up test directory
        if os.path.exists(self.test_doc_path):
            os.rmdir(self.test_doc_path)

    def test_chunk_content(self):
        content = "This is a test content that needs to be chunked. It is long enough to be split into multiple chunks."
        chunks = self.indexer._chunk_content(content, chunk_size=20, chunk_overlap=5)
        self.assertIsInstance(chunks, list)
        self.assertGreater(len(chunks), 1)
        self.assertEqual(chunks[0], "This is a test conte")
        self.assertEqual(chunks[1], "content that needs t")

    @patch('os.walk')
    @patch('builtins.open', new_callable=mock_open)
    def test_index_docs(self, mock_open_file, mock_os_walk):
        # Simulate a directory with a markdown file
        mock_os_walk.return_value = [
            (self.test_doc_path, [], ["test_doc.md"])
        ]
        mock_open_file.return_value.read.return_value = "# Test Document\nThis is some test content."

        self.indexer.index_docs()

        # Verify that open was called with the correct path
        expected_file_path = os.path.join(self.test_doc_path, "test_doc.md")
        mock_open_file.assert_called_once_with(expected_file_path, 'r', encoding='utf-8')

        # Verify that the collection.add method was called
        self.indexer.collection.add.assert_called_once()

    @patch.object(DocIndexer, '_chunk_content', return_value=["chunk1", "chunk2"])
    def test_embed_and_store(self, mock_chunk_content):
        file_path = "/tmp/test_docs/test_doc.md"
        chunks = ["chunk1", "chunk2"]

        self.indexer._embed_and_store(chunks, file_path)

        # Get the arguments passed to mock_collection.add
        args, kwargs = self.indexer.collection.add.call_args

        # Assert the arguments (ChromaDB handles embeddings internally)
        self.assertEqual(kwargs['documents'], chunks)
        self.assertEqual(len(kwargs['metadatas']), 2)
        self.assertEqual(kwargs['metadatas'][0]['source'], file_path)
        self.assertEqual(kwargs['ids'], [f"{file_path}-0", f"{file_path}-1"])

    def test_from_env_defaults(self):
        """Test from_env() creates instance with default values."""
        from pathlib import Path

        # Clear environment variables to test defaults
        env_vars = ["ZK_DOC_SRC_DIR", "ZK_DOC_VECTOR_DB_DIR", "ZK_DOC_FORCE_REINDEX"]
        original_values = {}
        for var in env_vars:
            original_values[var] = os.getenv(var)
            if var in os.environ:
                del os.environ[var]

        try:
            indexer = DocIndexer.from_env()

            # Verify defaults
            self.assertEqual(indexer.doc_path, Path.home() / ".zk-doc-mcp" / "repo")
            self.assertEqual(indexer.force_reindex, False)
            self.assertEqual(indexer.collection_name, "zk_docs")
        finally:
            # Restore original environment
            for var, value in original_values.items():
                if value is not None:
                    os.environ[var] = value

    def test_from_env_custom_values(self):
        """Test from_env() reads custom values from environment."""
        from pathlib import Path
        import tempfile

        # Use tempfile for writable paths
        with tempfile.TemporaryDirectory() as temp_dir:
            custom_doc_path = os.path.join(temp_dir, "custom_docs")
            custom_vector_path = os.path.join(temp_dir, "custom_vector")

            # Set custom environment variables (without force_reindex to avoid delete issues)
            custom_env = {
                "ZK_DOC_SRC_DIR": custom_doc_path,
                "ZK_DOC_VECTOR_DB_DIR": custom_vector_path,
            }

            original_values = {}
            for var, value in custom_env.items():
                original_values[var] = os.getenv(var)
                os.environ[var] = value

            try:
                indexer = DocIndexer.from_env()

                # Verify custom values
                self.assertEqual(indexer.doc_path, Path(custom_doc_path))
            finally:
                # Restore original environment
                for var, value in original_values.items():
                    if value is not None:
                        os.environ[var] = value
                    elif var in os.environ:
                        del os.environ[var]

    def test_from_env_force_reindex_false(self):
        """Test from_env() with force_reindex explicitly set to false."""
        # Set force_reindex to false
        original_value = os.getenv("ZK_DOC_FORCE_REINDEX")
        os.environ["ZK_DOC_FORCE_REINDEX"] = "false"

        try:
            indexer = DocIndexer.from_env()
            self.assertEqual(indexer.force_reindex, False)
        finally:
            # Restore original environment
            if original_value is not None:
                os.environ["ZK_DOC_FORCE_REINDEX"] = original_value
            elif "ZK_DOC_FORCE_REINDEX" in os.environ:
                del os.environ["ZK_DOC_FORCE_REINDEX"]

    def test_from_env_partial_override(self):
        """Test from_env() with only some environment variables set."""
        from pathlib import Path
        import tempfile

        # Use tempfile for writable paths
        with tempfile.TemporaryDirectory() as temp_dir:
            custom_doc_path = os.path.join(temp_dir, "my_custom_docs")

            # Set only doc path, leave others as defaults
            original_doc_path = os.getenv("ZK_DOC_SRC_DIR")
            os.environ["ZK_DOC_SRC_DIR"] = custom_doc_path

            # Clear other variables
            other_vars = ["ZK_DOC_VECTOR_DB_DIR", "ZK_DOC_FORCE_REINDEX"]
            original_values = {}
            for var in other_vars:
                original_values[var] = os.getenv(var)
                if var in os.environ:
                    del os.environ[var]

            try:
                indexer = DocIndexer.from_env()

                # Verify mixed values
                self.assertEqual(indexer.doc_path, Path(custom_doc_path))  # Custom
                self.assertEqual(indexer.force_reindex, False)  # Default
            finally:
                # Restore original environment
                if original_doc_path is not None:
                    os.environ["ZK_DOC_SRC_DIR"] = original_doc_path
                elif "ZK_DOC_SRC_DIR" in os.environ:
                    del os.environ["ZK_DOC_SRC_DIR"]

                for var, value in original_values.items():
                    if value is not None:
                        os.environ[var] = value

if __name__ == '__main__':
    unittest.main()
