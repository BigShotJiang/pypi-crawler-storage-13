import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from typing import Union, List, Optional, Literal, Tuple
import warnings
import os
from scipy import stats
import seaborn as sns


class UtilsStats:
    """
    Clase utilitaria para operaciones estadísticas comunes y visualización
    
    Esta clase proporciona métodos para validación de datos, análisis estadísticos
    básicos y visualización de resultados.
    
    Examples:
    ---------
    >>> utils = UtilsStats()
    >>> data = np.random.normal(0, 1, 100)
    >>> utils.check_normality(data)
    >>> utils.plot_distribution(data)
    """
    
    def __init__(self):
        """Inicializar la clase utilitaria"""
        self._plot_backend = 'seaborn'
        self._default_figsize = (12, 5)
        self._save_fig = False
        self._fig_format = 'png'
        self._fig_dpi = 300
        self._figures_dir = 'figures'
        
        # Configuración de estilo para matplotlib
        plt.style.use('default')
        self._setup_plotting_style()
    
    def _setup_plotting_style(self):
        """Configurar estilos de plotting por defecto"""
        plt.rcParams['figure.figsize'] = [self._default_figsize[0], self._default_figsize[1]]
        plt.rcParams['figure.dpi'] = self._fig_dpi
        plt.rcParams['savefig.dpi'] = self._fig_dpi
        plt.rcParams['font.size'] = 10
        plt.rcParams['axes.grid'] = True
        plt.rcParams['grid.alpha'] = 0.3
        plt.rcParams['lines.linewidth'] = 2
    
    def set_plot_backend(self, backend: Literal['matplotlib', 'seaborn', 'plotly']):
        """
        Establecer el backend de visualización por defecto
        """
        self._plot_backend = backend
    
    def set_default_figsize(self, figsize: Tuple[int, int]):
        """
        Establecer el tamaño de figura por defecto
        """
        self._default_figsize = figsize
        plt.rcParams['figure.figsize'] = [figsize[0], figsize[1]]
    
    def set_save_fig_options(self, save_fig: Optional[bool] = False, 
                           fig_format: str = 'png', 
                           fig_dpi: int = 300,
                           figures_dir: str = 'figures'):
        """
        Configurar opciones para guardar figuras
        """
        self._save_fig = save_fig
        self._fig_format = fig_format
        self._fig_dpi = fig_dpi
        self._figures_dir = figures_dir
    
    def _save_figure(self, fig, filename: str, **kwargs):
        """
        Guardar figura si save_fig está activado
        """
        if self._save_fig:
            try:
                os.makedirs(self._figures_dir, exist_ok=True)
                filepath = os.path.join(self._figures_dir, f"{filename}.{self._fig_format}")
                
                fig.savefig(
                    filepath, 
                    format=self._fig_format,
                    dpi=self._fig_dpi,
                    bbox_inches='tight',
                    facecolor='white',
                    **kwargs
                )
                print(f"✓ Figura guardada: {filepath}")
                
            except Exception as e:
                print(f"✗ Error guardando figura: {e}")

    # ============= MÉTODOS DE ANÁLISIS ESTADÍSTICO =============

    def validate_dataframe(self, data: Union[pd.DataFrame, np.ndarray, list]) -> pd.DataFrame:
        """Valida y convierte datos a DataFrame"""
        if isinstance(data, pd.DataFrame):
            return data
        elif isinstance(data, np.ndarray):
            if data.ndim == 1:
                return pd.DataFrame({'var': data})
            elif data.ndim == 2:
                return pd.DataFrame(data, columns=[f'var_{i}' for i in range(data.shape[1])])
            else:
                raise ValueError("Solo se soportan arrays 1D y 2D")
        elif isinstance(data, list):
            return pd.DataFrame(data)
        else:
            raise TypeError(f"Tipo de dato no soportado: {type(data)}")

    def format_number(self, num: float, decimals: int = 6, scientific: bool = False) -> str:
        """Formatea un número con decimales especificados"""
        if scientific and abs(num) < 0.001:
            return f"{num:.{decimals}e}"
        return f"{num:.{decimals}f}"

    def check_normality(self, data: Union[pd.Series, np.ndarray], alpha: float = 0.05) -> dict:
        """Verifica si los datos siguen distribución normal usando Shapiro-Wilk"""
        if isinstance(data, pd.Series):
            data = data.dropna().values
        else:
            data = np.array(data)
            data = data[~np.isnan(data)]
        
        shapiro_stat, shapiro_p = stats.shapiro(data)
        
        return {
            'is_normal': shapiro_p > alpha,
            'shapiro_statistic': shapiro_stat,
            'shapiro_pvalue': shapiro_p,
            'alpha': alpha,
            'interpretation': 'Normal' if shapiro_p > alpha else 'No Normal'
        }

    def calculate_confidence_intervals(self, data: Union[pd.Series, np.ndarray], 
                                     confidence_level: float = 0.95,
                                     method: str = 'parametric') -> dict:
        """
        Calcula intervalos de confianza para la media
        """
        if isinstance(data, pd.Series):
            data_clean = data.dropna().values
        else:
            data_clean = data[~np.isnan(data)]
        
        n = len(data_clean)
        mean = np.mean(data_clean)
        std = np.std(data_clean, ddof=1)
        
        if method == 'parametric':
            se = std / np.sqrt(n)
            z_value = stats.t.ppf((1 + confidence_level) / 2, n - 1)
            margin_error = z_value * se
            
            ci_lower = mean - margin_error
            ci_upper = mean + margin_error
            
        elif method == 'bootstrap':
            n_bootstraps = 1000
            bootstrap_means = []
            
            for _ in range(n_bootstraps):
                bootstrap_sample = np.random.choice(data_clean, size=n, replace=True)
                bootstrap_means.append(np.mean(bootstrap_sample))
            
            alpha = 1 - confidence_level
            ci_lower = np.percentile(bootstrap_means, (alpha / 2) * 100)
            ci_upper = np.percentile(bootstrap_means, (1 - alpha / 2) * 100)
            margin_error = (ci_upper - ci_lower) / 2
            
        else:
            raise ValueError("Método debe ser 'parametric' o 'bootstrap'")
        
        return {
            'mean': mean,
            'std': std,
            'n': n,
            'confidence_level': confidence_level,
            'ci_lower': ci_lower,
            'ci_upper': ci_upper,
            'margin_error': margin_error,
            'method': method
        }

    def detect_outliers(self, data: Union[pd.Series, np.ndarray], 
                       method: Literal['iqr', 'zscore', 'isolation_forest'] = 'iqr',
                       **kwargs) -> np.ndarray:
        """
        Detecta outliers usando diferentes métodos
        
        Parameters:
        -----------
        data : array-like
            Datos a analizar
        method : str
            'iqr', 'zscore', o 'isolation_forest'
        
        Returns:
        --------
        np.ndarray
            Array booleano indicando outliers
        """
        if isinstance(data, pd.Series):
            data = data.values
        
        data_clean = data[~np.isnan(data)]
        
        if method == 'iqr':
            q1 = np.percentile(data_clean, 25)
            q3 = np.percentile(data_clean, 75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            outliers = (data_clean < lower_bound) | (data_clean > upper_bound)
            
        elif method == 'zscore':
            threshold = kwargs.get('threshold', 3)
            z_scores = np.abs((data_clean - np.mean(data_clean)) / np.std(data_clean))
            outliers = z_scores > threshold
            
        elif method == 'isolation_forest':
            from sklearn.ensemble import IsolationForest
            contamination = kwargs.get('contamination', 0.1)
            X = data_clean.reshape(-1, 1)
            clf = IsolationForest(contamination=contamination, random_state=42)
            outliers = clf.fit_predict(X) == -1
            
        else:
            raise ValueError("Método debe ser 'iqr', 'zscore', o 'isolation_forest'")
        
        return outliers

    def calculate_effect_size(self, group1: np.ndarray, group2: np.ndarray, 
                             method: Literal['cohen', 'hedges'] = 'cohen') -> dict:
        """
        Calcula el tamaño del efecto entre dos grupos
        """
        mean1, mean2 = np.mean(group1), np.mean(group2)
        std1, std2 = np.std(group1, ddof=1), np.std(group2, ddof=1)
        n1, n2 = len(group1), len(group2)
        
        pooled_std = np.sqrt(((n1 - 1) * std1**2 + (n2 - 1) * std2**2) / (n1 + n2 - 2))
        cohens_d = (mean1 - mean2) / pooled_std
        
        if method == 'hedges':
            correction = 1 - (3 / (4 * (n1 + n2) - 9))
            effect_size = cohens_d * correction
        else:
            effect_size = cohens_d
        
        abs_effect = abs(effect_size)
        if abs_effect < 0.2:
            interpretation = "Muy pequeño"
        elif abs_effect < 0.5:
            interpretation = "Pequeño"
        elif abs_effect < 0.8:
            interpretation = "Mediano"
        else:
            interpretation = "Grande"
        
        return {
            'effect_size': effect_size,
            'method': method,
            'interpretation': interpretation,
            'mean_diff': mean1 - mean2,
            'pooled_std': pooled_std
        }

    # ============= MÉTODOS DE VISUALIZACIÓN COMPLETOS =============

    def _plot_distribution_seaborn(self, data, plot_type, bins, figsize, title, **kwargs):
        """Implementación con seaborn"""
        if plot_type == 'all':
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))
            
            # Histograma
            sns.histplot(data, bins=bins, kde=True, ax=axes[0, 0])
            axes[0, 0].set_title('Histograma con KDE')
            
            # Box plot
            sns.boxplot(y=data, ax=axes[0, 1])
            axes[0, 1].set_title('Box Plot')
            
            # Violin plot
            sns.violinplot(y=data, ax=axes[1, 0])
            axes[1, 0].set_title('Violin Plot')
            
            # Q-Q plot
            stats.probplot(data, dist="norm", plot=axes[1, 1])
            axes[1, 1].set_title('Q-Q Plot')
            
            fig.suptitle(title, fontsize=16, y=1.00)
            plt.tight_layout()
            
        else:
            fig, ax = plt.subplots(figsize=figsize)
            
            if plot_type == 'hist':
                sns.histplot(data, bins=bins, kde=True, ax=ax, **kwargs)
            elif plot_type == 'kde':
                sns.kdeplot(data, ax=ax, **kwargs)
            elif plot_type == 'box':
                sns.boxplot(y=data, ax=ax, **kwargs)
            elif plot_type == 'violin':
                sns.violinplot(y=data, ax=ax, **kwargs)
            
            ax.set_title(title)
            plt.tight_layout()
        
        return fig

    def _plot_distribution_matplotlib(self, data, plot_type, bins, figsize, title, **kwargs):
        """Implementación con matplotlib puro"""
        if plot_type == 'all':
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))
            
            # Histograma
            axes[0, 0].hist(data, bins=bins, alpha=0.7, edgecolor='black', density=True)
            axes[0, 0].set_title('Histograma')
            axes[0, 0].set_ylabel('Densidad')
            
            # Box plot
            axes[0, 1].boxplot(data)
            axes[0, 1].set_title('Box Plot')
            
            # KDE
            from scipy.stats import gaussian_kde
            kde = gaussian_kde(data)
            x_range = np.linspace(data.min(), data.max(), 100)
            axes[1, 0].plot(x_range, kde(x_range))
            axes[1, 0].fill_between(x_range, kde(x_range), alpha=0.3)
            axes[1, 0].set_title('KDE')
            axes[1, 0].set_ylabel('Densidad')
            
            # Q-Q plot
            stats.probplot(data, dist="norm", plot=axes[1, 1])
            axes[1, 1].set_title('Q-Q Plot')
            
            fig.suptitle(title, fontsize=16)
            plt.tight_layout()
            
        else:
            fig, ax = plt.subplots(figsize=figsize)
            
            if plot_type == 'hist':
                ax.hist(data, bins=bins, edgecolor='black', alpha=0.7, **kwargs)
                ax.set_ylabel('Frecuencia')
            elif plot_type == 'box':
                ax.boxplot(data, vert=True)
            elif plot_type == 'kde':
                from scipy.stats import gaussian_kde
                kde = gaussian_kde(data)
                x_range = np.linspace(data.min(), data.max(), 100)
                ax.plot(x_range, kde(x_range), **kwargs)
                ax.fill_between(x_range, kde(x_range), alpha=0.3)
                ax.set_ylabel('Densidad')
        
            ax.set_title(title)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
        
        return fig

    def plot_distribution(self, data: Union[pd.DataFrame, pd.Series, np.ndarray],
                         column: Optional[str] = None,
                         plot_type: Literal['hist', 'kde', 'box', 'violin', 'all'] = 'hist',
                         backend: Optional[Literal['matplotlib', 'seaborn', 'plotly']] = "seaborn",
                         bins: int = 30,
                         figsize: Optional[Tuple[int, int]] = None,
                         save_fig: Optional[bool] = None,
                         filename: Optional[str] = None,
                         **kwargs):
        """
        Graficar distribución de una variable
        
        Parameters:
        -----------
        data : DataFrame, Series o ndarray
            Datos a graficar
        column : str, optional
            Columna a graficar (si data es DataFrame)
        plot_type : str
            Tipo de gráfico
        backend : str, optional
            Backend de visualización
        bins : int
            Número de bins para histograma
        figsize : tuple, optional
            Tamaño de la figura
        save_fig : bool, optional
            Si guardar la figura
        filename : str, optional
            Nombre del archivo
        """
        backend = backend or self._plot_backend
        figsize = figsize or self._default_figsize
        save_fig = save_fig if save_fig is not None else self._save_fig
        
        # Extraer datos
        if isinstance(data, pd.DataFrame):
            if column is None:
                raise ValueError("Debe especificar 'column' cuando data es DataFrame")
            plot_data = data[column].dropna()
            title = f"Distribución de {column}"
            default_filename = f"distribucion_{column}"
        elif isinstance(data, pd.Series):
            plot_data = data.dropna()
            title = f"Distribución de {data.name if data.name else 'Variable'}"
            default_filename = f"distribucion_{data.name if data.name else 'variable'}"
        else:
            plot_data = pd.Series(data).dropna()
            title = "Distribución"
            default_filename = "distribucion"
        
        filename = filename or default_filename
        
        try:
            if backend == 'seaborn':
                fig = self._plot_distribution_seaborn(plot_data, plot_type, bins, figsize, title, **kwargs)
            elif backend == 'matplotlib':
                fig = self._plot_distribution_matplotlib(plot_data, plot_type, bins, figsize, title, **kwargs)
            elif backend == 'plotly':
                fig = self._plot_distribution_plotly(plot_data, plot_type, bins, title, **kwargs)
            else:
                raise ValueError(f"Backend '{backend}' no soportado")
            
            # Guardar figura si está activado
            if save_fig and backend != 'plotly':
                self._save_figure(fig, filename)
            
            return fig
            
        except Exception as e:
            print(f"Error en plot_distribution: {e}")
            raise

    def _plot_distribution_plotly(self, data, plot_type, bins, title, **kwargs):
        """Implementación con plotly"""
        try:
            import plotly.graph_objects as go
            import plotly.express as px
            from plotly.subplots import make_subplots
        except ImportError:
            raise ImportError("Plotly no está instalado. Instale con: pip install plotly")
        
        if plot_type == 'all':
            fig = make_subplots(
                rows=2, cols=2,
                subplot_titles=('Histograma', 'Box Plot', 'Violin Plot', 'Distribución Acumulada')
            )
            
            # Histograma
            fig.add_trace(go.Histogram(x=data, nbinsx=bins, name='Histograma'), row=1, col=1)
            
            # Box plot
            fig.add_trace(go.Box(y=data, name='Box Plot'), row=1, col=2)
            
            # Violin plot
            fig.add_trace(go.Violin(y=data, name='Violin Plot'), row=2, col=1)
            
            # Distribución acumulada
            hist, bin_edges = np.histogram(data, bins=bins, density=True)
            cdf = np.cumsum(hist * np.diff(bin_edges))
            fig.add_trace(go.Scatter(x=bin_edges[1:], y=cdf, name='CDF'), row=2, col=2)
            
        else:
            if plot_type == 'hist':
                fig = px.histogram(data, nbins=bins, title=title)
            elif plot_type == 'box':
                fig = px.box(y=data, title=title)
            elif plot_type == 'violin':
                fig = px.violin(y=data, title=title, box=True)
            else:
                fig = px.histogram(data, nbins=bins, title=title)
        
        return fig

    def plot_correlation_matrix(self, data: pd.DataFrame,
                               method: str = 'pearson',
                               backend: Optional[Literal['seaborn', 'plotly']] = None,
                               figsize: Optional[Tuple[int, int]] = None,
                               save_fig: Optional[bool] = None,
                               filename: Optional[str] = None,
                               **kwargs):
        """
        Visualizar matriz de correlación
        
        Parameters:
        -----------
        data : DataFrame
            Datos para calcular correlación
        method : str
            'pearson', 'spearman' o 'kendall'
        backend : str, optional
            Backend de visualización
        """
        backend = backend or self._plot_backend
        figsize = figsize or self._default_figsize
        save_fig = save_fig if save_fig is not None else self._save_fig
        filename = filename or "matriz_correlacion"
        
        # Calcular matriz de correlación
        corr_matrix = data.corr(method=method)
        
        if backend == 'seaborn':
            fig, ax = plt.subplots(figsize=figsize)
            mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
            
            sns.heatmap(corr_matrix, mask=mask, annot=True, fmt='.2f', 
                       cmap='coolwarm', center=0, ax=ax,
                       square=True, linewidths=0.5, **kwargs)
            ax.set_title(f'Matriz de Correlación ({method})', fontsize=14, pad=20)
            plt.tight_layout()
            
        elif backend == 'plotly':
            import plotly.graph_objects as go
            
            fig = go.Figure(data=go.Heatmap(
                z=corr_matrix.values,
                x=corr_matrix.columns,
                y=corr_matrix.index,
                colorscale='RdBu',
                zmid=0,
                text=corr_matrix.values,
                texttemplate='%{text:.2f}',
                textfont={"size": 10},
                **kwargs
            ))
            
            fig.update_layout(
                title=f'Matriz de Correlación ({method})',
                xaxis_title='Variables',
                yaxis_title='Variables',
                width=figsize[0]*100,
                height=figsize[1]*100
            )
        
        # Guardar figura
        if save_fig:
            if backend == 'seaborn':
                self._save_figure(fig, filename)
            elif backend == 'plotly':
                try:
                    os.makedirs(self._figures_dir, exist_ok=True)
                    filepath = os.path.join(self._figures_dir, f"{filename}.{self._fig_format}")
                    fig.write_image(filepath)
                    print(f"✓ Figura Plotly guardada: {filepath}")
                except Exception as e:
                    print(f"✗ Error guardando figura Plotly: {e}")
        
        return fig

    def plot_scatter_matrix(self, data: pd.DataFrame,
                           columns: Optional[List[str]] = None,
                           backend: Optional[Literal['seaborn', 'plotly', 'pandas']] = None,
                           figsize: Optional[Tuple[int, int]] = None,
                           save_fig: Optional[bool] = None,
                           filename: Optional[str] = None,
                           **kwargs):
        """
        Matriz de gráficos de dispersión (pairplot)
        """
        backend = backend or self._plot_backend
        figsize = figsize or self._default_figsize
        save_fig = save_fig if save_fig is not None else self._save_fig
        filename = filename or "scatter_matrix"
        
        if columns:
            data = data[columns]
        
        if backend == 'seaborn':
            fig = sns.pairplot(data, **kwargs)
            fig.fig.suptitle('Matriz de Dispersión', y=1.02)
            
        elif backend == 'plotly':
            import plotly.express as px
            fig = px.scatter_matrix(data, **kwargs)
            fig.update_layout(title='Matriz de Dispersión')
            
        elif backend == 'pandas':
            from pandas.plotting import scatter_matrix
            fig, ax = plt.subplots(figsize=figsize)
            scatter_matrix(data, ax=ax, **kwargs)
        
        # Guardar figura
        if save_fig:
            if backend in ['seaborn', 'pandas']:
                self._save_figure(fig.figure if hasattr(fig, 'figure') else fig, filename)
            elif backend == 'plotly':
                try:
                    os.makedirs(self._figures_dir, exist_ok=True)
                    filepath = os.path.join(self._figures_dir, f"{filename}.{self._fig_format}")
                    fig.write_image(filepath)
                    print(f"✓ Figura Plotly guardada: {filepath}")
                except Exception as e:
                    print(f"✗ Error guardando figura Plotly: {e}")
        
        return fig

    # ============= GRÁFICOS CON INTERVALOS DE CONFIANZA =============

    def plot_distribution_with_ci(self, 
                                 data: Union[pd.DataFrame, pd.Series, np.ndarray],
                                 column: Optional[str] = None,
                                 confidence_level: float = 0.95,
                                 ci_method: str = 'parametric',
                                 bins: int = 30,
                                 figsize: Optional[Tuple[int, int]] = None,
                                 save_fig: Optional[bool] = None,
                                 filename: Optional[str] = None,
                                 **kwargs) -> plt.Figure:
        """
        Grafica la distribución junto con intervalos de confianza
        """
        # Extraer y limpiar datos
        if isinstance(data, pd.DataFrame):
            if column is None:
                raise ValueError("Debe especificar 'column' cuando data es DataFrame")
            plot_data = data[column].dropna()
            data_name = column
        elif isinstance(data, pd.Series):
            plot_data = data.dropna()
            data_name = data.name if data.name else 'Variable'
        else:
            plot_data = pd.Series(data).dropna()
            data_name = 'Variable'
        
        data_array = plot_data.values
        default_filename = f"distribucion_ci_{data_name.lower().replace(' ', '_')}"
        filename = filename or default_filename
        
        # Calcular estadísticas e intervalos de confianza
        ci_result = self.calculate_confidence_intervals(data_array, confidence_level, ci_method)
        normality_result = self.check_normality(data_array)
        
        # Crear figura con dos subgráficas
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize or (14, 6))
        
        # ===== PRIMERA GRÁFICA: Distribución básica =====
        n, bins, patches = ax1.hist(data_array, bins=bins, alpha=0.7, 
                                   color='skyblue', edgecolor='black', 
                                   density=True, label='Histograma')
        
        # KDE
        kde = stats.gaussian_kde(data_array)
        x_range = np.linspace(data_array.min(), data_array.max(), 200)
        ax1.plot(x_range, kde(x_range), 'r-', linewidth=2, label='KDE')
        
        # Línea vertical en la media
        ax1.axvline(ci_result['mean'], color='red', linestyle='--', 
                   linewidth=2, label=f'Media: {ci_result["mean"]:.2f}')
        
        ax1.set_xlabel('Valores')
        ax1.set_ylabel('Densidad')
        ax1.set_title(f'Distribución de {data_name}\n'
                     f'Media: {ci_result["mean"]:.2f}, '
                     f'Desv. Est.: {ci_result["std"]:.2f}')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # ===== SEGUNDA GRÁFICA: Distribución con intervalos de confianza =====
        n, bins, patches = ax2.hist(data_array, bins=bins, alpha=0.7, 
                                   color='lightgreen', edgecolor='black', 
                                   density=True, label='Histograma')
        
        # KDE
        ax2.plot(x_range, kde(x_range), 'r-', linewidth=2, label='KDE')
        
        # Media y intervalos de confianza
        ax2.axvline(ci_result['mean'], color='red', linestyle='-', 
                   linewidth=3, label=f'Media: {ci_result["mean"]:.2f}')
        
        # Intervalo de confianza
        ax2.axvspan(ci_result['ci_lower'], ci_result['ci_upper'], 
                   alpha=0.3, color='orange', 
                   label=f'IC {confidence_level*100}%: [{ci_result["ci_lower"]:.2f}, {ci_result["ci_upper"]:.2f}]')
        
        # Líneas para los límites del IC
        ax2.axvline(ci_result['ci_lower'], color='orange', linestyle='--', linewidth=2)
        ax2.axvline(ci_result['ci_upper'], color='orange', linestyle='--', linewidth=2)
        
        # Distribución normal teórica (si los datos son normales)
        if normality_result['is_normal']:
            normal_x = np.linspace(data_array.min(), data_array.max(), 200)
            normal_y = stats.norm.pdf(normal_x, ci_result['mean'], ci_result['std'])
            ax2.plot(normal_x, normal_y, 'g--', linewidth=2, alpha=0.7, 
                    label='Distribución Normal Teórica')
        
        ax2.set_xlabel('Valores')
        ax2.set_ylabel('Densidad')
        ax2.set_title(f'Distribución con Intervalos de Confianza\n'
                     f'Método: {ci_method}, n={ci_result["n"]}')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # Información adicional como texto
        info_text = (f'Estadísticas:\n'
                    f'• Media: {ci_result["mean"]:.3f}\n'
                    f'• Desv. Est.: {ci_result["std"]:.3f}\n'
                    f'• n: {ci_result["n"]}\n'
                    f'• IC {confidence_level*100}%: [{ci_result["ci_lower"]:.3f}, {ci_result["ci_upper"]:.3f}]\n'
                    f'• Margen Error: ±{ci_result["margin_error"]:.3f}\n'
                    f'• Normalidad: {normality_result["interpretation"]}\n'
                    f'• p-value: {normality_result["shapiro_pvalue"]:.4f}')
        
        fig.text(0.02, 0.02, info_text, fontsize=9, 
                bbox=dict(boxstyle="round,pad=0.5", facecolor="lightgray", alpha=0.7),
                verticalalignment='bottom')
        
        plt.tight_layout()
        
        # Guardar figura si está activado
        save_fig = save_fig if save_fig is not None else self._save_fig
        if save_fig:
            self._save_figure(fig, filename)
        
        return fig

    def plot_multiple_distributions_with_ci(self, 
                                           data_dict: dict,
                                           confidence_level: float = 0.95,
                                           figsize: Optional[Tuple[int, int]] = None,
                                           save_fig: Optional[bool] = None,
                                           filename: Optional[str] = None,
                                           **kwargs) -> plt.Figure:
        """
        Grafica múltiples distribuciones con sus intervalos de confianza
        """
        n_distributions = len(data_dict)
        fig, axes = plt.subplots(n_distributions, 2, 
                               figsize=figsize or (14, 5 * n_distributions))
        
        if n_distributions == 1:
            axes = axes.reshape(1, -1)
        
        colors = plt.cm.Set3(np.linspace(0, 1, n_distributions))
        
        for idx, (name, data) in enumerate(data_dict.items()):
            ax1, ax2 = axes[idx]
            
            if isinstance(data, pd.Series):
                data_array = data.dropna().values
            else:
                data_array = np.array(data)
                data_array = data_array[~np.isnan(data_array)]
            
            # Calcular estadísticas
            ci_result = self.calculate_confidence_intervals(data_array, confidence_level)
            
            # Gráfica izquierda: Distribución básica
            ax1.hist(data_array, bins=30, alpha=0.7, color=colors[idx], 
                    edgecolor='black', density=True)
            
            kde = stats.gaussian_kde(data_array)
            x_range = np.linspace(data_array.min(), data_array.max(), 200)
            ax1.plot(x_range, kde(x_range), 'k-', linewidth=2)
            ax1.axvline(ci_result['mean'], color='red', linestyle='--', linewidth=2)
            
            ax1.set_title(f'{name}\nMedia: {ci_result["mean"]:.2f}')
            ax1.grid(True, alpha=0.3)
            
            # Gráfica derecha: Con intervalos de confianza
            ax2.hist(data_array, bins=30, alpha=0.7, color=colors[idx], 
                    edgecolor='black', density=True)
            ax2.plot(x_range, kde(x_range), 'k-', linewidth=2)
            
            ax2.axvline(ci_result['mean'], color='red', linestyle='-', linewidth=3)
            ax2.axvspan(ci_result['ci_lower'], ci_result['ci_upper'], 
                       alpha=0.3, color='orange')
            ax2.axvline(ci_result['ci_lower'], color='orange', linestyle='--', linewidth=2)
            ax2.axvline(ci_result['ci_upper'], color='orange', linestyle='--', linewidth=2)
            
            ax2.set_title(f'{name} con IC {confidence_level*100}%')
            ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        # Guardar figura si está activado
        save_fig = save_fig if save_fig is not None else self._save_fig
        if save_fig:
            filename = filename or "multiples_distribuciones_ci"
            self._save_figure(fig, filename)
        
        return fig

    # ============= MÉTODOS UTILITARIOS ADICIONALES =============

    def get_descriptive_stats(self, data: Union[pd.DataFrame, pd.Series, np.ndarray],
                             column: Optional[str] = None) -> dict:
        """
        Obtiene estadísticas descriptivas completas
        """
        if isinstance(data, pd.DataFrame):
            if column is None:
                raise ValueError("Debe especificar 'column' cuando data es DataFrame")
            data_series = data[column]
        elif isinstance(data, pd.Series):
            data_series = data
        else:
            data_series = pd.Series(data)
        
        data_clean = data_series.dropna()
        
        return {
            'count': len(data_clean),
            'mean': np.mean(data_clean),
            'median': np.median(data_clean),
            'mode': stats.mode(data_clean)[0][0] if len(data_clean) > 0 else np.nan,
            'std': np.std(data_clean, ddof=1),
            'variance': np.var(data_clean, ddof=1),
            'min': np.min(data_clean),
            'max': np.max(data_clean),
            'q1': np.percentile(data_clean, 25),
            'q3': np.percentile(data_clean, 75),
            'iqr': np.percentile(data_clean, 75) - np.percentile(data_clean, 25),
            'skewness': stats.skew(data_clean),
            'kurtosis': stats.kurtosis(data_clean),
            'range': np.max(data_clean) - np.min(data_clean)
        }

    def help(self):
        """
        Muestra ayuda completa de la clase UtilsStats
        """
        help_text = """
            📊 CLASE UtilsStats - AYUDA COMPLETA

            Clase utilitaria para análisis estadísticos y visualización de datos.

            🔧 MÉTODOS PRINCIPALES:

            1. 📈 ANÁLISIS ESTADÍSTICO:
            • check_normality()           # Test de normalidad
            • calculate_confidence_intervals()  # Intervalos de confianza
            • detect_outliers()           # Detección de outliers
            • calculate_effect_size()     # Tamaño del efecto
            • get_descriptive_stats()     # Estadísticas descriptivas

            2. 🎨 VISUALIZACIÓN:
            • plot_distribution()         # Gráficos de distribución
            • plot_distribution_with_ci() # Distribución con IC
            • plot_multiple_distributions_with_ci() # Múltiples distribuciones
            • plot_correlation_matrix()   # Matriz de correlación
            • plot_scatter_matrix()       # Matriz de dispersión

            3. ⚙️ CONFIGURACIÓN:
            • set_plot_backend()          # Backend de visualización
            • set_default_figsize()       # Tamaño de figura
            • set_save_fig_options()      # Opciones para guardar

            4. 🛠️ UTILIDADES:
            • validate_dataframe()        # Validación de datos
            • format_number()             # Formateo de números

            💡 EJEMPLOS DE USO:

            # Inicializar
            utils = UtilsStats()

            # Análisis de normalidad
            normalidad = utils.check_normality(mis_datos)

            # Gráfico con intervalos de confianza
            fig = utils.plot_distribution_with_ci(
                data=mis_datos,
                confidence_level=0.95,
                bins=20
            )

            # Matriz de correlación
            fig_corr = utils.plot_correlation_matrix(
                data=mi_dataframe,
                method='pearson'
            )

            # Estadísticas descriptivas
            stats = utils.get_descriptive_stats(mis_datos)

            🎯 CARACTERÍSTICAS:
            • Múltiples backends: matplotlib, seaborn, plotly
            • Guardado automático de figuras
            • Manejo robusto de datos faltantes
            • Visualizaciones profesionales listas para publicación
            • Integración perfecta con Jupyter notebooks
            """
        print(help_text)