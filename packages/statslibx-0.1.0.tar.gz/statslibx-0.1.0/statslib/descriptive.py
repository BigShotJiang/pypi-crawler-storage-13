import numpy as np
import pandas as pd
from typing import Optional, Union, Literal, List
from datetime import datetime

class DescriptiveStats:
    """
    Clase para estadística descriptiva univariada y multivariada
    """
    
    def __init__(self, data: Union[pd.DataFrame, np.ndarray], 
                 backend: Literal['pandas', 'polars'] = 'pandas'):
        """
        Inicializar con DataFrame o array numpy
        
        Parameters:
        -----------
        data : DataFrame o ndarray
            Datos a analizar
        backend : str
            'pandas' o 'polars' para procesamiento
        """
        if isinstance(data, np.ndarray):
            if data.ndim == 1:
                data = pd.DataFrame({'var': data})
            else:
                data = pd.DataFrame(data, columns=[f'var_{i}' for i in range(data.shape[1])])
        
        self.data = data
        self.backend = backend
        self._numeric_cols = data.select_dtypes(include=[np.number]).columns.tolist()
        
    # ============= MÉTODOS UNIVARIADOS =============
    
    def mean(self, column: Optional[str] = None) -> Union[float, pd.Series]:
        """Media aritmética"""
        if column:
            return self.data[column].mean()
        return self.data[self._numeric_cols].mean()
    
    def median(self, column: Optional[str] = None) -> Union[float, pd.Series]:
        """Mediana"""
        if column:
            return self.data[column].median()
        return self.data[self._numeric_cols].median()
    
    def mode(self, column: Optional[str] = None):
        """Moda"""
        if column:
            return self.data[column].mode()[0]
        return self.data[self._numeric_cols].mode().iloc[0]
    
    def variance(self, column: Optional[str] = None) -> Union[float, pd.Series]:
        """Varianza"""
        if column:
            return self.data[column].var()
        return self.data[self._numeric_cols].var()
    
    def std(self, column: Optional[str] = None) -> Union[float, pd.Series]:
        """Desviación estándar"""
        if column:
            return self.data[column].std()
        return self.data[self._numeric_cols].std()
    
    def skewness(self, column: Optional[str] = None) -> Union[float, pd.Series]:
        """Asimetría"""
        if column:
            return self.data[column].skew()
        return self.data[self._numeric_cols].skew()
    
    def kurtosis(self, column: Optional[str] = None) -> Union[float, pd.Series]:
        """Curtosis"""
        if column:
            return self.data[column].kurtosis()
        return self.data[self._numeric_cols].kurtosis()
    
    def quantile(self, q: Union[float, List[float]], column: Optional[str] = None):
        """Cuantiles/Percentiles"""
        if column:
            return self.data[column].quantile(q)
        return self.data[self._numeric_cols].quantile(q)
    
    def outliers(self, column: str, method: Literal['iqr', 'zscore'] = 'iqr', 
                 threshold: float = 1.5) -> pd.Series:
        """
        Detectar outliers en una columna
        
        Parameters:
        -----------
        column : str
            Nombre de la columna
        method : str
            'iqr' o 'zscore'
        threshold : float
            1.5 para IQR, 3 para zscore típicamente
        """
        col_data = self.data[column]
        
        if method == 'iqr':
            q1 = col_data.quantile(0.25)
            q3 = col_data.quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - threshold * iqr
            upper_bound = q3 + threshold * iqr
            outliers = (col_data < lower_bound) | (col_data > upper_bound)
        else:  # zscore
            z_scores = np.abs((col_data - col_data.mean()) / col_data.std())
            outliers = z_scores > threshold
        
        return outliers
    
    # ============= MÉTODOS MULTIVARIADOS =============
    
    def correlation(self, method: Literal['pearson', 'spearman', 'kendall'] = 'pearson',
                   columns: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Matriz de correlación
        
        Parameters:
        -----------
        method : str
            'pearson', 'spearman' o 'kendall'
        columns : list, optional
            Lista de columnas a incluir
        """
        data_subset = self.data[columns] if columns else self.data[self._numeric_cols]
        return data_subset.corr(method=method)
    
    def covariance(self, columns: Optional[List[str]] = None) -> pd.DataFrame:
        """Matriz de covarianza"""
        data_subset = self.data[columns] if columns else self.data[self._numeric_cols]
        return data_subset.cov()
    
    # ============= MÉTODOS DE RESUMEN =============
    
    def summary(self, columns: Optional[List[str]] = None, 
                show_plot: bool = False, 
                plot_backend: str = 'seaborn') -> 'DescriptiveSummary':
        """
        Resumen completo de estadísticas descriptivas
        
        Parameters:
        -----------
        columns : list, optional
            Columnas específicas a resumir
        show_plot : bool
            Si mostrar gráficos
        plot_backend : str
            'seaborn', 'plotly' o 'matplotlib'
        """
        cols = columns if columns else self._numeric_cols
        
        results = {}
        for col in cols:
            col_data = self.data[col]
            results[col] = {
                'count': col_data.count(),
                'mean': col_data.mean(),
                'median': col_data.median(),
                'mode': col_data.mode()[0] if len(col_data.mode()) > 0 else np.nan,
                'std': col_data.std(),
                'variance': col_data.var(),
                'min': col_data.min(),
                'q1': col_data.quantile(0.25),
                'q3': col_data.quantile(0.75),
                'max': col_data.max(),
                'iqr': col_data.quantile(0.75) - col_data.quantile(0.25),
                'skewness': col_data.skew(),
                'kurtosis': col_data.kurtosis(),
            }
        
        return DescriptiveSummary(results, show_plot=show_plot, plot_backend=plot_backend)
    
    # ============= REGRESIÓN LINEAL =============
    
    def linear_regression(self, 
                         y: str,
                         X: Union[str, List[str]],
                         engine: Literal['statsmodels', 'scikit-learn'] = 'statsmodels',
                         fit_intercept: bool = True,
                         show_plot: bool = False,
                         plot_backend: str = 'seaborn',
                         handle_missing: Literal['drop', 'error', 'warn'] = 'drop') -> 'LinearRegressionResult':
        """
        Regresión lineal simple o múltiple
        
        Parameters:
        -----------
        y : str
            Variable dependiente
        X : str o list
            Variable(s) independiente(s)
        engine : str
            'statsmodels' o 'scikit-learn'
        fit_intercept : bool
            Si incluir intercepto
        show_plot : bool
            Mostrar gráficos diagnósticos
        plot_backend : str
            Backend para visualización
        
        Returns:
        --------
        LinearRegressionResult
            Objeto con resultados y método summary()
        """
        if isinstance(X, str):
            X = [X]
        
        # Verificar que las columnas existen
        missing_columns = []
        if y not in self.data.columns:
            missing_columns.append(y)
        for x_col in X:
            if x_col not in self.data.columns:
                missing_columns.append(x_col)
        
        if missing_columns:
            raise ValueError(f"Columnas no encontradas: {missing_columns}")
        
        # Crear DataFrame con solo las columnas necesarias
        regression_data = self.data[[y] + X].copy()
        
        # Manejar valores infinitos
        numeric_cols = regression_data.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            if regression_data[col].dtype in [np.float64, np.float32, np.float16]:
                inf_mask = np.isinf(regression_data[col])
                if inf_mask.any():
                    print(f"Advertencia: Columna '{col}' tiene {inf_mask.sum()} valores infinitos. Serán convertidos a NaN.")
                    regression_data[col] = regression_data[col].replace([np.inf, -np.inf], np.nan)
        
        # Manejar valores faltantes
        missing_before = regression_data.isnull().sum()
        total_missing = missing_before.sum()
        
        if total_missing > 0:
            missing_info = "\n".join([f"  - {col}: {missing_before[col]} missing" 
                                    for col in missing_before[missing_before > 0].index])
            
            if handle_missing == 'error':
                raise ValueError(f"Datos contienen valores faltantes:\n{missing_info}")
            
            elif handle_missing == 'warn':
                print(f"Advertencia: Datos contienen {total_missing} valores faltantes:\n{missing_info}")
                print("Eliminando filas con valores faltantes...")
                regression_data_clean = regression_data.dropna()
            
            elif handle_missing == 'drop':
                regression_data_clean = regression_data.dropna()
                
            else:
                raise ValueError(f"Método de manejo de missing values no reconocido: {handle_missing}")
            
            # Informar sobre la limpieza
            rows_before = len(regression_data)
            rows_after = len(regression_data_clean)
            rows_removed = rows_before - rows_after
            
            if rows_removed > 0:
                print(f"Limpieza de datos: {rows_removed} filas eliminadas ({rows_after} filas restantes)")
                
                if rows_after < len(X) + 1:  # +1 para el intercepto
                    raise ValueError(
                        f"Muy pocas filas después de limpieza: {rows_after}. "
                        f"Se necesitan al menos {len(X) + 1} filas para regresión."
                    )
        else:
            regression_data_clean = regression_data
        
        # Extraer datos limpios
        X_data = regression_data_clean[X].values
        y_data = regression_data_clean[y].values
        
        # Validar que los datos son numéricos
        if not np.issubdtype(X_data.dtype, np.number):
            raise ValueError("Las variables independientes deben ser numéricas")
        if not np.issubdtype(y_data.dtype, np.number):
            raise ValueError("La variable dependiente debe ser numérica")
        
        # Validar que no hay más missing values
        if np.isnan(X_data).any() or np.isnan(y_data).any():
            raise ValueError("Todavía hay valores NaN después de la limpieza")
        
        # Validar que no hay valores infinitos
        if np.isinf(X_data).any() or np.isinf(y_data).any():
            raise ValueError("Todavía hay valores infinitos después de la limpieza")
        
        # Crear y ajustar el modelo
        result = LinearRegressionResult(
            X_data, y_data, X, y, 
            engine=engine, 
            fit_intercept=fit_intercept
        )
        result.fit()
        result.show_plot = show_plot
        result.plot_backend = plot_backend
        
        # Agregar información de limpieza al resultado
        result.data_info = {
            'original_rows': len(self.data),
            'clean_rows': len(regression_data_clean),
            'rows_removed': len(self.data) - len(regression_data_clean),
            'missing_handled': total_missing > 0
        }
        
        return result
    
    def help(self):
        """
        Muestra ayuda completa de la clase DescriptiveStats
        """
        help_text = """
            📈 CLASE DescriptiveStats - AYUDA COMPLETA

            Clase para análisis estadístico descriptivo univariado y multivariado

            🔧 MÉTODOS PRINCIPALES:

            1. 📊 ESTADÍSTICAS UNIVARIADAS:
            • .mean(), .median(), .mode()        # Tendencia central
            • .std(), .variance()                # Dispersión  
            • .skewness(), .kurtosis()           # Forma de distribución
            • .quantile(0.25)                    # Cuantiles
            • .outliers('columna')               # Detección de outliers

            2. 🔗 ESTADÍSTICAS MULTIVARIADAS:
            • .correlation()                     # Matriz de correlación
            • .covariance()                      # Matriz de covarianza

            3. 📋 RESUMEN COMPLETO:
            • .summary()                         # Resumen descriptivo completo
            • .summary(show_plot=True)           # Con visualizaciones

            4. 📈 REGRESIÓN LINEAL:
            • .linear_regression(y, X)           # Regresión simple/múltiple

            💡 EJEMPLOS DE USO:

            # Inicializar
            estadisticas = DescriptiveStats(mi_dataframe)

            # Análisis univariado
            media = estadisticas.mean('edad')
            resumen = estadisticas.summary()

            # Regresión
            modelo = estadisticas.linear_regression(
                y='ventas', 
                X=['publicidad', 'precio'],
                show_plot=True
            )
            print(modelo.summary())
            """
        print(help_text)
    
class DescriptiveSummary:
    """Clase para formatear salida de estadística descriptiva"""
    
    def __init__(self, results: dict, show_plot: bool = False, plot_backend: str = 'seaborn'):
        self.results = results
        self.show_plot = show_plot
        self.plot_backend = plot_backend
        
    def __repr__(self):
        return self._format_output()
    
    def _format_output(self):
        """Formato de tabla organizada para múltiples variables"""
        output = []
        output.append("=" * 100)
        output.append("RESUMEN DE ESTADÍSTICA DESCRIPTIVA".center(100))
        output.append("=" * 100)
        output.append(f"Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        output.append(f"Variables analizadas: {len(self.results)}")
        output.append("-" * 100)
        
        for var_name, stats in self.results.items():
            output.append(f"\n{'VARIABLE: ' + var_name:^100}")
            output.append("-" * 100)
            
            # Tendencia central
            output.append("\nMedidas de Tendencia Central:")
            output.append(f"{'  Conteo':<40} {stats['count']:>20.0f}")
            output.append(f"{'  Media':<40} {stats['mean']:>20.6f}")
            output.append(f"{'  Mediana':<40} {stats['median']:>20.6f}")
            output.append(f"{'  Moda':<40} {stats['mode']:>20.6f}")
            
            # Dispersión
            output.append("\nMedidas de Dispersión:")
            output.append(f"{'  Desviación Estándar':<40} {stats['std']:>20.6f}")
            output.append(f"{'  Varianza':<40} {stats['variance']:>20.6f}")
            output.append(f"{'  Rango Intercuartílico (IQR)':<40} {stats['iqr']:>20.6f}")
            
            # Cuartiles
            output.append("\nCuartiles y Rango:")
            output.append(f"{'  Mínimo':<40} {stats['min']:>20.6f}")
            output.append(f"{'  Primer Cuartil (Q1)':<40} {stats['q1']:>20.6f}")
            output.append(f"{'  Tercer Cuartil (Q3)':<40} {stats['q3']:>20.6f}")
            output.append(f"{'  Máximo':<40} {stats['max']:>20.6f}")
            
            # Forma
            output.append("\nForma de la Distribución:")
            output.append(f"{'  Asimetría (Skewness)':<40} {stats['skewness']:>20.6f}")
            output.append(f"{'  Curtosis (Kurtosis)':<40} {stats['kurtosis']:>20.6f}")
            
            output.append("-" * 100)
        
        output.append("=" * 100)
        return "\n".join(output)
    

import numpy as np
from datetime import datetime


class LinearRegressionResult:
    """Clase para resultados de regresión lineal"""
    
    def __init__(self, X, y, X_names, y_name, engine='statsmodels', fit_intercept=True):
        self.X = X
        self.y = y
        self.X_names = X_names
        self.y_name = y_name
        self.engine = engine
        self.fit_intercept = fit_intercept
        self.model = None
        self.results = None
        self.show_plot = False
        self.plot_backend = 'seaborn'
        
        # Atributos que se llenarán después del fit
        self.coef_ = None
        self.intercept_ = None
        self.r_squared = None
        self.adj_r_squared = None
        self.f_statistic = None
        self.f_pvalue = None
        self.aic = None
        self.bic = None
        self.residuals = None
        self.predictions = None
        self.std_errors = None
        self.t_values = None
        self.p_values = None
        
    def fit(self):
        """Ajustar el modelo"""
        if self.engine == 'statsmodels':
            import statsmodels.api as sm
            X = self.X.copy()
            if self.fit_intercept:
                X = sm.add_constant(X)
            self.model = sm.OLS(self.y, X)
            self.results = self.model.fit()
            
            # Extraer atributos
            if self.fit_intercept:
                self.intercept_ = self.results.params[0]
                self.coef_ = self.results.params[1:]
                self.std_errors = self.results.bse[1:]
                self.t_values = self.results.tvalues[1:]
                self.p_values = self.results.pvalues[1:]
            else:
                self.intercept_ = 0
                self.coef_ = self.results.params
                self.std_errors = self.results.bse
                self.t_values = self.results.tvalues
                self.p_values = self.results.pvalues
            
            self.r_squared = self.results.rsquared
            self.adj_r_squared = self.results.rsquared_adj
            self.f_statistic = self.results.fvalue
            self.f_pvalue = self.results.f_pvalue
            self.aic = self.results.aic
            self.bic = self.results.bic
            self.residuals = self.results.resid
            self.predictions = self.results.fittedvalues
            
        else:  # scikit-learn
            from sklearn.linear_model import LinearRegression
            self.model = LinearRegression(fit_intercept=self.fit_intercept)
            self.model.fit(self.X, self.y)
            
            self.coef_ = self.model.coef_
            self.intercept_ = self.model.intercept_
            self.r_squared = self.model.score(self.X, self.y)
            self.predictions = self.model.predict(self.X)
            self.residuals = self.y - self.predictions
            
            # Calcular métricas adicionales manualmente
            n, k = self.X.shape
            self.adj_r_squared = 1 - (1 - self.r_squared) * (n - 1) / (n - k - 1)
            
        return self
    
    def predict(self, X_new):
        """Hacer predicciones con nuevos datos"""
        if self.engine == 'statsmodels':
            import statsmodels.api as sm
            if self.fit_intercept:
                X_new = sm.add_constant(X_new)
            return self.results.predict(X_new)
        else:
            return self.model.predict(X_new)
    
    def summary(self):
        """Mostrar resumen estilo OLS"""
        return self.__repr__()
    
    def __repr__(self):
        return self._format_output()
    
    def _format_output(self):
        """Formato estilo OLS de statsmodels"""
        output = []
        output.append("=" * 100)
        output.append("RESULTADOS DE REGRESIÓN LINEAL".center(100))
        output.append("=" * 100)
        output.append(f"Variable Dependiente: {self.y_name}")
        output.append(f"Variables Independientes: {', '.join(self.X_names)}")
        output.append(f"Motor: {self.engine}")
        output.append(f"Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        output.append("-" * 100)
        
        # Información del modelo
        output.append("\nINFORMACIÓN DEL MODELO:")
        output.append("-" * 100)
        output.append(f"{'Estadístico':<50} {'Valor':>20}")
        output.append("-" * 100)
        output.append(f"{'R-cuadrado':<50} {self.r_squared:>20.6f}")
        output.append(f"{'R-cuadrado Ajustado':<50} {self.adj_r_squared:>20.6f}")
        
        if self.f_statistic is not None:
            output.append(f"{'Estadístico F':<50} {self.f_statistic:>20.6f}")
            output.append(f"{'Prob (F-estadístico)':<50} {self.f_pvalue:>20.6e}")
        
        if self.aic is not None:
            output.append(f"{'AIC':<50} {self.aic:>20.6f}")
            output.append(f"{'BIC':<50} {self.bic:>20.6f}")
        
        # Coeficientes
        output.append("\nCOEFICIENTES:")
        output.append("-" * 100)
        
        if self.std_errors is not None:
            output.append(f"{'Variable':<20} {'Coef.':>15} {'Std Err':>15} {'t':>15} {'P>|t|':>15}")
            output.append("-" * 100)
            output.append(f"{'const':<20} {self.intercept_:>15.6f} {'-':>15} {'-':>15} {'-':>15}")
            
            for i, name in enumerate(self.X_names):
                output.append(
                    f"{name:<20} {self.coef_[i]:>15.6f} {self.std_errors[i]:>15.6f} "
                    f"{self.t_values[i]:>15.3f} {self.p_values[i]:>15.6f}"
                )
        else:
            output.append(f"{'Variable':<20} {'Coeficiente':>20}")
            output.append("-" * 100)
            output.append(f"{'const':<20} {self.intercept_:>20.6f}")
            
            for i, name in enumerate(self.X_names):
                output.append(f"{name:<20} {self.coef_[i]:>20.6f}")
        
        # Análisis de residuos
        output.append("\nANÁLISIS DE RESIDUOS:")
        output.append("-" * 100)
        output.append(f"{'Estadístico':<50} {'Valor':>20}")
        output.append("-" * 100)
        output.append(f"{'Media de Residuos':<50} {np.mean(self.residuals):>20.6f}")
        output.append(f"{'Desv. Std. de Residuos':<50} {np.std(self.residuals):>20.6f}")
        output.append(f"{'Mínimo Residuo':<50} {np.min(self.residuals):>20.6f}")
        output.append(f"{'Máximo Residuo':<50} {np.max(self.residuals):>20.6f}")
        
        output.append("=" * 100)
        
        if self.show_plot:
            output.append("\n[Gráficos diagnósticos generados]")
        
        return "\n".join(output)