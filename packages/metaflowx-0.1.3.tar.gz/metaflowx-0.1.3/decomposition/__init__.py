"""Matrix decomposition algorithms.

These include PCA, NMF, ICA, and more. Most of the algorithms of this module can be
regarded as dimensionality reduction techniques.
"""

# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause

from decomposition._dict_learning import (
    DictionaryLearning,
    MiniBatchDictionaryLearning,
    SparseCoder,
    dict_learning,
    dict_learning_online,
    sparse_encode,
)
from decomposition._factor_analysis import FactorAnalysis
from decomposition._fastica import FastICA, fastica
from decomposition._incremental_pca import IncrementalPCA
from decomposition._kernel_pca import KernelPCA
from decomposition._lda import LatentDirichletAllocation
from decomposition._nmf import NMF, MiniBatchNMF, non_negative_factorization
from decomposition._pca import PCA
from decomposition._sparse_pca import MiniBatchSparsePCA, SparsePCA
from decomposition._truncated_svd import TruncatedSVD
from utils.extmath import randomized_svd

__all__ = [
    "NMF",
    "PCA",
    "DictionaryLearning",
    "FactorAnalysis",
    "FastICA",
    "IncrementalPCA",
    "KernelPCA",
    "LatentDirichletAllocation",
    "MiniBatchDictionaryLearning",
    "MiniBatchNMF",
    "MiniBatchSparsePCA",
    "SparseCoder",
    "SparsePCA",
    "TruncatedSVD",
    "dict_learning",
    "dict_learning_online",
    "fastica",
    "non_negative_factorization",
    "randomized_svd",
    "sparse_encode",
]
