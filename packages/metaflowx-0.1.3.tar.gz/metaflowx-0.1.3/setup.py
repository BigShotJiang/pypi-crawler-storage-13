from setuptools import setup, find_packages

setup(
    name="metaflowx",
    version="0.1.3",
    packages=find_packages(),
    install_requires=["numpy", "scipy", "pandas","autograd","statsmodels","pmdarima","jinja2","scipy","tqdm"],
    author="ml_lab",
    description="Numerical optimization toolkit — BFGS, CG, Newton, Steepest Descent, and more.",
    python_requires=">=3.7",
)