# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause

from frozen._frozen import FrozenEstimator

__all__ = ["FrozenEstimator"]
