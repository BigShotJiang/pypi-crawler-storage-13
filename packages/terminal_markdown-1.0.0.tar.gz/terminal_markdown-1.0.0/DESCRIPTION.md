# Terminal Markdown (tmd)

## Project Description / 项目描述

### English
**Terminal Markdown** is a command-line tool designed to render Markdown files directly in your terminal. It features Part-of-Speech (POS) tagging analysis, making it useful for both reading documentation and linguistic analysis.

**Features:**
- Render Markdown with rich formatting in the terminal.
- Highlight POS tags for text analysis.
- Lightweight and easy to use.

### 中文
**Terminal Markdown** 是一个命令行工具，旨在直接在终端中渲染 Markdown 文件。它具有词性标注（POS tagging）分析功能，既适用于阅读文档，也适用于语言学分析。

**功能特性：**
- 在终端中以丰富的格式渲染 Markdown。
- 高亮显示词性标注，辅助文本分析。
- 轻量级且易于使用。
