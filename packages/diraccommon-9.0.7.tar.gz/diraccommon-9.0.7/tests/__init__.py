"""DIRACCommon test suite"""
