"""DIRACCommon Core utilities"""
