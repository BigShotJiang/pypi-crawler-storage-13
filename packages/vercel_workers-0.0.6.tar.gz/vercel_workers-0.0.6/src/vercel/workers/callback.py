from __future__ import annotations

import json
from collections.abc import Callable, Iterable
from email.parser import BytesParser
from email.policy import default as _email_default_policy
from typing import Any, TypedDict
from urllib.parse import quote

import httpx

from . import client as _client
from .client import MessageMetadata


class CloudEventData(TypedDict):
    messageId: str
    queueName: str
    consumerGroup: str


class CloudEvent(TypedDict, total=False):
    type: str
    source: str
    id: str
    datacontenttype: str
    data: CloudEventData
    time: str
    specversion: str


def parse_cloudevent(body: bytes) -> tuple[str, str, str]:
    if not body:
        raise ValueError("Empty request body")

    try:
        data: Any = json.loads(body.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise ValueError("Failed to parse CloudEvent from request body") from exc

    if not isinstance(data, dict):
        raise ValueError("Invalid CloudEvent: body must be a JSON object")

    if data.get("type") != "com.vercel.queue.v1beta":
        raise ValueError(
            f"Invalid CloudEvent type: expected 'com.vercel.queue.v1beta', "
            f"got {data.get('type')!r}"
        )

    ce_data = data.get("data")
    if not isinstance(ce_data, dict):
        raise ValueError("Invalid CloudEvent: 'data' must be an object")

    missing: list[str] = []
    if "queueName" not in ce_data:
        missing.append("queueName")
    if "consumerGroup" not in ce_data:
        missing.append("consumerGroup")
    if "messageId" not in ce_data:
        missing.append("messageId")
    if missing:
        raise ValueError(
            f"Missing required CloudEvent data fields: {', '.join(missing)}"
        )

    queue_name = str(ce_data["queueName"])
    consumer_group = str(ce_data["consumerGroup"])
    message_id = str(ce_data["messageId"])
    return queue_name, consumer_group, message_id


def parse_multipart_message(
    response: httpx.Response,
) -> tuple[dict[str, str], bytes]:
    content_type = response.headers.get("Content-Type") or ""
    if "multipart" not in content_type.lower():
        raise RuntimeError(
            f"Expected multipart/mixed response, got Content-Type={content_type!r}"
        )

    raw = (
        f"Content-Type: {content_type}\r\n"
        "MIME-Version: 1.0\r\n"
        "\r\n"
    ).encode("latin1") + response.content

    msg = BytesParser(policy=_email_default_policy).parsebytes(raw)
    if not msg.is_multipart():
        raise RuntimeError("Expected multipart response, got non-multipart payload")

    for part in msg.iter_parts():
        headers = {k: v for (k, v) in part.items()}
        payload_bytes = part.get_payload(decode=True) or b""
        return headers, payload_bytes

    raise RuntimeError("Multipart response contained no parts")


def receive_message_by_id(
    queue_name: str,
    consumer_group: str,
    message_id: str,
    *,
    timeout: float | None = 10.0,
) -> tuple[Any, int, str, str]:
    """
    Minimal receive-by-id:

      GET {base_url}{base_path}/{messageId}
      Accept: multipart/mixed

    Returns (payload, delivery_count, created_at, ticket).
    """
    base_url = _client.get_queue_base_url().rstrip("/")  # type: ignore[attr-defined]
    base_path = _client.get_queue_base_path()  # type: ignore[attr-defined]
    auth_token = _client.get_queue_token(None)  # type: ignore[attr-defined]

    headers: dict[str, str] = {
        "Authorization": f"Bearer {auth_token}",
        "Vqs-Queue-Name": queue_name,
        "Vqs-Consumer-Group": consumer_group,
        "Accept": "multipart/mixed",
    }

    url = f"{base_url}{base_path}/{quote(message_id, safe='')}"
    with httpx.Client(timeout=timeout) as client:
        response = client.get(url, headers=headers)

    if response.status_code == 400:
        raise RuntimeError(response.text or "Invalid parameters (400)")
    if response.status_code == 401:
        raise PermissionError("Missing or invalid authentication token (401)")
    if response.status_code == 403:
        raise PermissionError(
            "Queue environment does not match token environment (403)"
        )
    if response.status_code == 404:
        raise LookupError(f"Message {message_id} not found (404)")
    if response.status_code == 423:
        retry_after = response.headers.get("Retry-After")
        raise RuntimeError(
            f"Message {message_id} is temporarily locked (423), "
            f"Retry-After={retry_after!r}"
        )
    if response.status_code == 409:
        raise RuntimeError(f"Message {message_id} not available for processing (409)")
    if response.status_code >= 500:
        raise RuntimeError(
            f"Server error: {response.status_code} {response.reason_phrase}"
        )

    response.raise_for_status()

    part_headers, payload_bytes = parse_multipart_message(response)

    message_id_header = part_headers.get("Vqs-Message-Id") or message_id
    delivery_count_raw = part_headers.get("Vqs-Delivery-Count") or "0"
    timestamp = part_headers.get("Vqs-Timestamp") or ""
    ticket = part_headers.get("Vqs-Ticket")

    if not ticket:
        raise RuntimeError(
            "Missing required queue header 'Vqs-Ticket' in multipart response"
        )

    try:
        delivery_count = int(delivery_count_raw)
    except ValueError:
        delivery_count = 0

    content_type = part_headers.get("Content-Type", "")
    if "application/json" in content_type.lower():
        try:
            payload: Any = json.loads(payload_bytes.decode("utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError(
                f"Failed to parse message payload as JSON: {exc}"
            ) from exc
    else:
        payload = payload_bytes

    message_id_final = message_id_header or message_id
    return payload, delivery_count, timestamp, ticket  # type: ignore[return-value]


def delete_message(
    queue_name: str,
    consumer_group: str,
    message_id: str,
    ticket: str,
    *,
    timeout: float | None = 10.0,
) -> None:
    base_url = _client.get_queue_base_url().rstrip("/")  # type: ignore[attr-defined]
    base_path = _client.get_queue_base_path()  # type: ignore[attr-defined]
    auth_token = _client.get_queue_token(None)  # type: ignore[attr-defined]

    headers: dict[str, str] = {
        "Authorization": f"Bearer {auth_token}",
        "Vqs-Queue-Name": queue_name,
        "Vqs-Consumer-Group": consumer_group,
        "Vqs-Ticket": ticket,
    }

    url = f"{base_url}{base_path}/{quote(message_id, safe='')}"
    with httpx.Client(timeout=timeout) as client:
        response = client.delete(url, headers=headers)

    if response.status_code == 400:
        raise RuntimeError("Missing or invalid ticket (400)")
    if response.status_code == 401:
        raise PermissionError("Missing or invalid authentication token (401)")
    if response.status_code == 403:
        raise PermissionError(
            "Queue environment does not match token environment (403)"
        )
    if response.status_code == 404:
        raise LookupError(f"Message {message_id} not found (404)")
    if response.status_code == 409:
        raise RuntimeError(
            f"Message {message_id} not available for deletion (409)"
        )
    if response.status_code >= 500:
        raise RuntimeError(
            f"Server error: {response.status_code} {response.reason_phrase}"
        )

    response.raise_for_status()


def change_visibility(
    queue_name: str,
    consumer_group: str,
    message_id: str,
    ticket: str,
    visibility_timeout_seconds: int,
    *,
    timeout: float | None = 10.0,
) -> None:
    base_url = _client.get_queue_base_url().rstrip("/")  # type: ignore[attr-defined]
    base_path = _client.get_queue_base_path()  # type: ignore[attr-defined]
    auth_token = _client.get_queue_token(None)  # type: ignore[attr-defined]

    headers: dict[str, str] = {
        "Authorization": f"Bearer {auth_token}",
        "Vqs-Queue-Name": queue_name,
        "Vqs-Consumer-Group": consumer_group,
        "Vqs-Ticket": ticket,
        "Vqs-Visibility-Timeout": str(visibility_timeout_seconds),
    }

    url = f"{base_url}{base_path}/{quote(message_id, safe='')}"
    with httpx.Client(timeout=timeout) as client:
        response = client.patch(url, headers=headers)

    if response.status_code == 400:
        raise RuntimeError(
            "Missing ticket or invalid visibility timeout (400)"
        )
    if response.status_code == 401:
        raise PermissionError("Missing or invalid authentication token (401)")
    if response.status_code == 403:
        raise PermissionError(
            "Queue environment does not match token environment (403)"
        )
    if response.status_code == 404:
        raise LookupError(f"Message {message_id} not found (404)")
    if response.status_code == 409:
        raise RuntimeError(
            f"Message {message_id} not available for visibility change (409)"
        )
    if response.status_code >= 500:
        raise RuntimeError(
            f"Server error: {response.status_code} {response.reason_phrase}"
        )

    response.raise_for_status()


    # Note: WSGI entrypoint is now implemented in `client.wsgi_app`.
    # This module only contains helpers for parsing CloudEvents and
    # interacting with the Queue Service API.
