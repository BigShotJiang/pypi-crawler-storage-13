class Agent:
    def __init__(self, name):
        self.name = name

    def run(self, task: str):
        return f"Agent `{self.name}` performed task: {task}"
