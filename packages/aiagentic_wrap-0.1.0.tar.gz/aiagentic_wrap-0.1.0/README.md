# agenticpy

A lightweight and extensible agent framework for LLM-powered automation.

## Installation
pip install agenticpy

## Usage
```python
from agenticpy import Agent

agent = Agent("TestAgent")
print(agent.run("Say Hello"))
