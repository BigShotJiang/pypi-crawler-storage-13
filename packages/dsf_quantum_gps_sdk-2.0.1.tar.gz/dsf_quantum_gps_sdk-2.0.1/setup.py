# ============================================
# setup.py — DSF Quantum GPS SDK
# ============================================
from setuptools import setup, find_packages
import os

# Leer README.md
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="dsf-quantum-gps-sdk",
    version="2.0.1",
    author="Jaime Alexander Jimenez",
    author_email="contacto@dsfuptech.cloud",
    description="Quantum GPS Optimization SDK using zero-ancilla amplitude estimation.",
    long_description=long_description,
    long_description_content_type="text/markdown",

    url="https://github.com/jaimeajl/dsf-quantum-gps-sdk",
    project_urls={
        "Documentation": "https://dsfuptech.cloud/docs",
        "Source": "https://github.com/jaimeajl/dsf-quantum-gps-sdk",
        "API Endpoint": "https://dsf-quantum-gps.vercel.app",
    },

    packages=find_packages(include=["dsf_quantum_gps_sdk", "dsf_quantum_gps_sdk.*"]),
    include_package_data=True,

    license="Proprietary License © 2025 Jaime Alexander Jimenez (UpTech)",
    license_files=("LICENSE",),

    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Physics",
        "Topic :: Scientific/Engineering :: Quantum Computing",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: Other/Proprietary License",
    ],

    python_requires=">=3.8",

    install_requires=[
        "requests>=2.25.0",
        "qiskit>=1.0.0",
        "qiskit-aer>=0.13.0",
        "numpy>=1.24.0",
        "scipy>=1.11.0",
    ],

    keywords=[
        "quantum", "gps", "quantum-gps", "dsf",
        "optimization", "qae", "amplitude-estimation",
        "zero-ancilla", "quantum-ai", "quantum-ml",
    ],
)
