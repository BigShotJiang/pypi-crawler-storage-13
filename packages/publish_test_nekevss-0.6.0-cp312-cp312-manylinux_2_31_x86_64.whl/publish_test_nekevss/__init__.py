from publish_test_nekevss._core import hello_from_rust

def hello():
    print(hello_from_rust())
