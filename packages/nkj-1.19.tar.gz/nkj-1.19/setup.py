#
# [name] setup.py
#
# Written by Yoshikazu NAKAJIMA
#

from setuptools import setup, find_packages

setup(
	name='nkj',
	version='1.19',
	description='Python library for geometric computations',
	author='Yoshikazu NAKAJIMA',
	license='bmi.isct',
	packages=find_packages()
)
