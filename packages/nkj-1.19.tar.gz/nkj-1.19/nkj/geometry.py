#
# [name]    nkj.primitiveshape.py
# [comment] Primitive Shapes (ps) Library
# [exec]    python -m nkj.primitiveshape
#
# Written by Yoshikazu NAKAJIMA
#
import math as _m
import numpy as np
from scipy.optimize import curve_fit
import copy
import nkj as _n
import nkj.str as _ns
import nkj.math as _nm
import nkj.list as _nl
import nkj.cs as _ncs
import nkj.vtk as _ntk

_DEFAULT_KEEPING_DISTANCE = _nm.keeping_distance()
_DEFAULT_KEEPING_ANGLE =    _nm.keeping_angle()

_DEFAULT_LINE2 = [_ncs.vec2([0.0, 0.0]), _ncs.vec2([1.0, 0.0])]
_DEFAULT_LINE3 = [_ncs.vec3([0.0, 0.0, 0.0]), _ncs.vec3([1.0, 0.0, 0.0])]

_DEFAULT_PLANE_ORIGIN = _ncs.vec3([0.0, 0.0, 0.0])
_DEFAULT_PLANE_NORMAL = _ncs.vec3([0.0, 0.0, 1.0])
_DEFAULT_PLANE = [_DEFAULT_PLANE_ORIGIN, _DEFAULT_PLANE_NORMAL]

_DEFAULT_SPHARE_ORIGIN = _ncs.point3([0.0, 0.0, 0.0])
_DEFAULT_SPHARE_RADIUS = 1.0
_DEFAULT_SPHARE = [_DEFAULT_SPHARE_ORIGIN, _DEFAULT_SPHARE_RADIUS]

_DEFAULT_CIRCLE2_ORIGIN = _ncs.point2([0.0, 0.0])
_DEFAULT_CIRCLE2_RADIUS = 1.0
_DEFAULT_CIRCLE2 = [_DEFAULT_CIRCLE2_ORIGIN, _DEFAULT_CIRCLE2_RADIUS]

_DEFAULT_CIRCLE3_MATRIX = _ncs.DEFAULT_MAT3X4
_DEFAULT_CIRCLE3_RADIUS = 1.0
_DEFAULT_CIRCLE3 = [_DEFAULT_CIRCLE3_MATRIX, _DEFAULT_CIRCLE3_RADIUS]

_DEFAULT_CYLINDER_AXIS = _DEFAULT_LINE3
_DEFAULT_CYLINDER_RADIUS = 1.0
_DEFAULT_CYLINDER = [_DEFAULT_CYLINDER_AXIS, _DEFAULT_CYLINDER_RADIUS]

_DEFAULT_CONE_BASECENTER = _ncs.point3([0.0, 0.0, 0.0])
_DEFAULT_CONE_TIP =        _ncs.point3([0.0, 0.0, 1.0])
_DEFAULT_CONE_BASERADIUS = 1.0
_DEFAULT_CONE = [_DEFAULT_CONE_BASECENTER, _DEFAULT_CONE_TIP, _DEFAULT_CONE_BASERADIUS]

_LINE_SETTINGFLAG_TWOPOINTS = 0
_LINE_SETTINGFLAG_ORIGINANDVECTOR = 1
_DEFAULT_LINE_SETTINGFLAG = _LINE_SETTINGFLAG_TWOPOINTS

LINE_SETTINGFLAG_TWOPOINTS = _LINE_SETTINGFLAG_TWOPOINTS
LINE_SETTINGFLAG_ORIGINANDVECTOR = _LINE_SETTINGFLAG_ORIGINANDVECTOR

_ICOSAHEDRON_RADIUS1 = 30.0
_ICOSAHEDRON_RADIUS2 = 50.0

nd = _n.LibDebugFlag()

# Classes

#-- Primitive shape classes

class primitiveshape_cls(list):
	_classname = 'nkj.primitiveshape.primitiveshape'

	def __new__(cls):
		self = super().__new__(cls)
		return self

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()


#-- Line classes

class linebase_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshape.linebase'
	_componentclass = None

	def __new__(cls):
		self = super().__new__(cls)
		return self

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	def getComponentClass(cls):
		return cls._componentclass

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	@classmethod
	@property
	def componentclass(cls):
		return cls.getComponentClass()

	def set(self, pts, flag=_DEFAULT_LINE_SETTINGFLAG):
		self.setPoints(pts, flag)

	def setPoints(self, pts, flag=_DEFAULT_LINE_SETTINGFLAG):
		_n.ldprint("--> nkj.primitiveshape.line.setPoints(, flag:{})".format(flag))
		_n.ldprint("pts: {0} ({1})".format(pts, type(pts)))
		
		if (pts is None):
			raise ValueError("__ERROR__: Value is None.")
		
		if (nd.LIB_DEBUG):
			_n.ldprint0("component class: {}".format(type(self.componentclass)))
			_n.ldprint0("pts: {0} ({1})".format(pts, type(pts)))
			_n.ldprint0("len(pts): {}".format(len(pts)))
			for i in range(2):
				print('pt[{0}]: {1} ({2})'.format(i, pts[i], type(pts[i])))
		
		# ここでは、{vec2, vec3, list/tuple/np.ndarray} を要素とする {list, tuple} クラスを取り扱う．
		
		if (isinstance(pts, (list, tuple, np.ndarray))):
			if (len(pts) != 2):
				raise ValueError("__ERROR__: Illegal data. NKJ-PRIMITIVESHAPE-00107.")
			
			if (self.is_componentclass(pts[0]) and self.is_componentclass(pts[1])):
				self.clear()
				if (flag == _LINE_SETTINGFLAG_TWOPOINTS):
					if (nd.LIB_DEBUG):
						print('@-- componentclass, TWOPOINTS_SETTING')
					self.append(pts[0])
					self.append(pts[1])
				elif (flag == _LINE_SETTINGFLAG_ORIGINANDVECTOR):
					if (nd.LIB_DEBUG):
						print('@-- componentclass, ORIGINANDVECTOR_SETTING')
					self.append(pts[0])
					self.append(self.componentclass(pts[0]) + self.componentclass(pts[1]))
					# *1)  ↑
					# リストの要素同士の足し算は、時として、リストの足し算（結合）として計算されるので、
					# コンポーネントクラスの演算を演算子で行う場合には、
					# コンポーネントクラス（vec2, vec3）に型変換（キャスト）してから、計算する
					#
				else:
					raise Exception("__ERROR__: Illegal flag. NKJ-PRIMITIVESHAPE-00131.")
			elif (isinstance(pts[0], (list, tuple, np.ndarray)) and isinstance(pts[1], (list, tuple, np.ndarray))):
				self.clear()
				if (flag == _LINE_SETTINGFLAG_TWOPOINTS):
					if (nd.LIB_DEBUG):
						print('@-- list/tuple/np.ndarray, TWOPOINTS_SETTING')
					for i in range(2):
						pt = self.componentclass(pts[i])
						self.append(pt)
				elif (flag == _LINE_SETTINGFLAG_ORIGINANDVECTOR):
					if (nd.LIB_DEBUG):
						print('@-- list/tuple/np.ndarray, ORIGINANDVECTOR_SETTING')
					for i in range(2):
						pt = self.componentclass(pts[0]) if (i == 0) else (self.componentclass(pts[0]) + self.componentclass(pts[1]))  # 上と同様 *1)
						self.append(pt)
				else:
					raise Exception("__ERROR__: Illegal flag. NKJ-PRIMITIVESHAPE-00142.")
			else:
				raise ValueError("__ERROR__: Illegal data.")
			
			if (nd.LIB_DEBUG):
				self.print("@nkj.primitiveshape.line2.setPoints()")
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-00128.")
		_n.ldprint("<-- nkj.primitiveshape.line.setPoints()")

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError('__ERROR__: Illegal index.')
		return self[index]

	def setComponent(self, index, x):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError('__ERROR__: Illegal index.')
		if (self.is_componentclass(x)):
			self[index] = x
		elif (isinstance(x, (list, tuple))):
			self[index] = self.componentclass(x)
		else:
			raise ValueError("__ERROR__: Illegal data.")

	def Component(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	def componet(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	def getPoint(self, index):
		return self.getComponent(index)

	def setPoint(self, index, pt):
		self.setComponent(index, pt)

	def Point(self, index, pt=None):
		if (pt is None):
			return self.getPoint(index)
		else:
			self.setPoint(index, pt)

	@property
	def point0(self):
		return self.getPoint(0)

	@property
	def point1(self):
		return self.getPoint(1)

	@point0.setter
	def point0(self, pt):
		self.setPoint(0, pt)

	@point1.setter
	def point1(self, pt):
		self.setPoint(1, pt)

	@property
	def pt0(self):
		return self.getPoint(0)

	@property
	def pt1(self):
		return self.getPoint(1)

	@pt0.setter
	def pt0(self, pt):
		self.setPoint(0, pt)

	@pt1.setter
	def pt1(self, pt):
		self.setPoint(1, pt)

	@property
	def p0(self):
		return self.getPoint(0)

	@property
	def p1(self):
		return self.getPoint(1)

	@p0.setter
	def p0(self, pt):
		self.setPoint(0, pt)

	@p1.setter
	def p1(self, pt):
		self.setPoint(1, pt)

	def getOrigin(self):
		return self.getPoint(0)

	def setOrigin(self, x):
		self.setPoint(0, x)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, x):
		self.setOrigin(x)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, x):
		self.setOrigin(x)

	def getDirectionalVector(self):
		return (self.getPoint(1) - self.getPoint(0))

	def setDirectionalVector(self, x):
		orig = self.getOrigin()
		v = self.getDirectionalVector()
		len = self.getLength()
		x = x.normalized
		self.setComponent(1, orig + len * x)

	def DirectionalVector(self):
		return self.getDirectionalVector()

	def getDirection(self):
		return self.getDirectionalVector()

	def Direction(self):
		return self.getDirection()

	def getVector(self):
		return self.getDirectionalVector()

	def Vector(self):
		return self.getVector(self)
	
	@property
	def direction(self):
		return self.getDirection()

	@property
	def vector(self):
		return self.getDirection()

	@property
	def vec(self):
		return self.getDirection()

	def getLength(self):
		return np.linalg.norm(self.getPoint(1) - self.getPoint(0))

	def setLength(self, len):
		self.setPoint(1, self.getPoint(0) + len * self.getDirectionalVector())

	def Length(self, l=None):
		if (l is None):
			return self.getLength()
		else:
			self.setLength(l)

	@property
	def length(self):
		return self.getLength()

	@length.setter
	def length(self, l):
		self.setLength(l)

	@property
	def len(self):
		return self.getLength()

	@len.setter
	def len(self, l):
		self.setLength(l)

	@property
	def l(self):
		return self.getLength()

	@l.setter
	def l(self, l):
		self.setLength(l)

	def getNorm(self):
		return self.getLength()

	def Norm(self):
		return self.getNorm()

	@property
	def norm(self):
		return self.getNorm()

	def getNormalized(self):
		nv = copy.deepcopy(self)
		length = self.getLength()
		nv /= length
		return nv

	@property
	def normalized(self):
		return self.getNormalized()

	# isinstance

	def is_componentclass(self, x):
		raise Exception("__ERROR__: Not implemented.")

	def isinstance(self, x):
		return is_linebase(x)

	# Data

	def getDataString(self):
		s = ''
		for i in range(2):
			if (i != 0):
				s += ', '
			s += '{}'.format(self.getPoint(i).getDataStr())
		return s

	def getDataStr(self):
		return self.getDataString(rowend)

	@property
	def datastr(self):
		return self.getDataString()

	@property
	def dstr(self):
		return self.getDataString()

	# Print

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		for i in range(2):
			if (i != 0):
				s += ', '
			s += '{}'.format(self.getPoint(i).getPrintString())
		return s

	def getPrintStr(self, title=None):
		return self.getPrintString(title)

	@property
	def printstr(self):
		return self.getPrintStr()

	@property
	def pstr(self):
		return self.getPrintStr()

	def print(self, title=None):
		print(self.getPrintString(title), flush=True)

	# Load, Save

	def load(self, filename):
		with open(filename, 'r') as f:
			self.setDataString(f.read())

	def save(self, filename):
		if (filename == '-'):
			print(self.getDataString())
		else:
			try:
				with open(filename, 'w') as f:
					f.write(self.getDataString())
			except Exception as e:
				raise Exception(e)
	
class linebase(linebase_cls):
	pass

def is_linebase(x):
	return isinstance(x, linebase_cls)


class line2_cls(linebase_cls):
	_classname = 'nkj.primitiveshapes.line2'
	_componentclass = _ncs.point2

	def __new__(cls, pts=None, flag=_DEFAULT_LINE_SETTINGFLAG):
		self = super().__new__(cls)
		self.set(_DEFAULT_LINE2 if (pts is None) else pts, flag)
		return self

	def __init__(self, pts=None, flag=_DEFAULT_LINE_SETTINGFLAG):
		self.set(_DEFAULT_LINE2 if (pts is None) else pts, flag)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __xor__(self, second):  # '^' operator
		return self.innerproduct(second)

	def __mul(self, second):    # '*' operator
		return self.outerproduct(second)

	def __matmul__(self, second):
		raise Exception('__ERROR__: Not supported.')

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def __and__(self, second):  # '&' operator
		return self.crosssection(second)

	def getSerialized(self):
		#
		# a * (x - x0) + b * (y - y0) = 0
		#
		vec = self.getVector()
		orig = self.getOrigin()
		return [vec.x, vec.y, orig.x, orig.y]  # a, b, x0, y0

	def serialize(self):
		return self.getSerialized()

	@property
	def serialized(self):
		return self.getSerialized()

	# Operators

	def rmultiply(self, x):
		if (_ncs.is_mat2x2(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass(x @ self.getPoint(i)))
			return line2(newpts)
		elif (_ncs.is_mat2x3(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass((x.h @ self.getPoint(i).h).ih))
			return line2(newpts)
		elif (_ncs.is_mat3x3(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass((x @ self.getPoint(i).h).ih))
			return line3(newpts)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	# Geometrical computation

	def innerproduct(self, v):
		v1 = self.vector
		v2 = v.vector
		return (v1 ^ v2)

	def inner(self, v):
		return self.innerproduct(v)

	def dotproduct(self, v):
		return self.innerproduct(v)

	def dot(self, v):
		return self.innerproduct(v)

	def outerproduct(self, x):
		v1 = self.vector
		v2 = v.vector
		return (v1 * v2)

	def outer(self, v):
		return self.outerproduct(v)

	def crossproduct(self, v):
		return self.outerproduct(v)

	def cross(self, v):
		return self.outerproduct(v)

	def crosssection(self, x):
		_n.ldprint('--> nkj.primitiveshape.line2.crosssection()')
		
		if (not self.isinstance(x)):
			raise TypeError('__ERROR__: Illegal data type.')
		
		l1 = self
		l2 = x
		
		deno = l1.vector * l2.vector  # crosssection, denominator
		
		if (_nm.is_ineps(deno)):
			_n.print_error('Two lines are parallel.')
			return None
		
		s = (l2.p0 - l1.p0) * (l2.p1 - l2.p0) / deno
		t = (l1.p1 - l1.p0) * (l1.p0 - l2.p0) / deno
		
		a = l1.p0
		b = l1.p1
		c = l2.p0
		d = l2.p1
		
		cpt = _ncs.vec2([a.x + s * (b - a).x, a.y + s * (b - a).y])
		
		if (nd.LIB_DEBUG):
			cpt.print('crosssection point')
		
		_n.ldprint('<-- nkj.primitiveshape.line2.crosssection()')
		return cpt

	def crosspoint(self, x):
		return self.crosssection(x)

	def getAngle(self, x):
		v1 = self.getVector()
		v2 = x.getVector()
		return v1.getAngle(v2)

	def angle(self, x):
		return self.getAngle(x)

	def ang(self, x):
		return self.getAngle(x)

	def rad(self, x):
		return self.getAngle(x)

	def deg(self, x):
		return _nm.rad2deg(self.getAngle(x))

	# isinstance

	def is_componentclass(self, x):
		return _ncs.is_point2(x)

	def isinstance(self, x):
		return is_line2(x)

class line2(line2_cls):
	pass

def is_line2(x):
	return isinstance(x, line2_cls)


class line3_cls(linebase_cls):
	_classname = 'nkj.primitiveshapes.line3'
	_componentclass = _ncs.point3

	def __new__(cls, pts=None, flag=_DEFAULT_LINE_SETTINGFLAG):
		self = super().__new__(cls)
		self.set(_DEFAULT_LINE3 if (pts is None) else pts, flag)
		return self

	def __init__(self, pts=None, flag=_DEFAULT_LINE_SETTINGFLAG):
		self.set(_DEFAULT_LINE3 if (pts is None) else pts, flag)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		raise Exception("__ERROR__: Not supported.")

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def __and__(self, second):
		return self.crosssection(second)

	# Operations

	def rmultiply(self, x):
		if (_ncs.is_mat3x3(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass(x @ self.getPoint(i)))
			return line3(newpts)
		elif (_ncs.is_mat3x4(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass((x.h @ self.getPoint(i).h).ih))
			return line3(newpts)
		elif (_ncs.is_mat4x4(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass((x @ self.getPoint(i).h).ih))
			return line3(newpts)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	def serialize(self):
		#
		#  x - x0     y - y0     z - z0
		# -------- = -------- = --------
		#    a          b          c
		#
		vec = self.getVector()
		orig = self.getOrigin()
		return [vec.x, vec.y, vec.z, orig.x, orig.y, orig.z]  # a, b, c, x0, y0, z0

	@property
	def serialized(self):
		return self.serialize()

	def getMat3x4(self):
		m = _ncs.mat3x4()
		xaxis = self.getDirectionalVector().normalized
		m = xaxis.matrix(_ncs.XAXISINDEX)
		m.setTranslation(self.getOrigin())
		return m

	@property
	def mat3x4(self):
		return self.getMat3x4()

	@property
	def m3x4(self):
		return self.getMat3x4()

	@property
	def mat3(self):
		return self.getMat3x4()

	@property
	def m3(self):
		return self.getMat3x4()

	def getMatrix(self):
		return self.getMat3x4()

	@property
	def matrix(self):
		return self.getMat3x4()

	@property
	def mat(self):
		return self.getMat3x4()

	@property
	def m(self):
		return self.getMat3x4()

	# Geometrical computation

	def getDistance(self, pt):
		#
		# d = |b| sin(theta)
		#   = |b| sqrt( 1 - cos(theta)^2)
		#
		#                    (a dot b)^2
		#   = |b| sqrt( 1 - --------------)
		#                     (|a||b|)^2
		#
		# ただし、a は直線の向き、 b は直線上の任意の点（ここでは直線原点 P0) から pt（ここでは点 P1）に向かうベクトル．
		# ここで、a は、P0 から直線への直線上の最近傍点 P2 へ向かうベクトルと一致する．
		#
		a, b, c, x0, y0, z0 = self.serialize()
		av = _ncs.vec3([a, b, c]).normalized
		bv = pt - _ncs.vec3([x0, y0, z0])
		
		if (_nm.is_ineps(bv.norm)):    # 点 P1 が直線原点 P0 と一致．即ち、P1 は直線上に存在．
			d = 0.0
		elif (_nm.is_ineps(av.norm)):  # 点 P1 から直線への最近傍点 P2 が直線原点 P0 と一致．というより直線の向きがゼロベクトルなので，計算不可．
			d = bv.norm
		else:
			nume = _nm.sq(av ^ bv)
			deno = _nm.sq(av.norm * bv.norm)  # av.norm も bv.norm もゼロでないので、分母がゼロになることはない．
			if (_nm.is_ineps(av.normalized ^ bv.normalized, 1.0)):  # av と bv がほぼ並行 = pt が直線上にある
				return 0.0
			if (_nm.is_ineps(deno)):                                # av と bv の外積がゼロの場合も pt が直線上にあると考えられる
				return 0.0
			s = 1.0 - nume / deno
			_METHOD = 2
			if (_METHOD == 1):     # 1.0 - nume / demo が負のとき、0.0 にする．
				s = max([0.0, s])
				sign = 1.0
			elif (_METHOD == 2):   # 1.0 - nume / demo が負のときに、sqrt() が負に対応しないので絶対をとる
				sign = np.sign(s)
				s = abs(s)
			else:
				raise Exception('__ERROR__: Illegal algorithm. Incorrect _METHOD.')
			_n.ldprint2('sin: {:.6f}'.format(s))
			d = bv.norm * sign * _m.sqrt(s)
		return d

	def Distance(self, pt):
		return self.getDistance(pt)

	def distance(self, pt):
		return self.getDistance(pt)

	def dist(self, pt):
		return self.getDistance(pt)

	def crosssection(self, x):
		_n.ldprint('--> nkj.primitiveshape.line3.crosssection()')
		if (is_plane(x)):
			return x.crosssection(self)  # plane.crosssection() をコール
		if (x is None):
			raise ValueError('__ERROR__: Null line. NKJ-PRIMITIVESHAPE-00380.')
		l2 = x if (is_line3(x)) else line3(x)
		l1 = self
		if (_nm.is_ineps(abs(l1.vector ^ l2.vector), 1.0)):
			_n.ldprint0('@ERROR: Two lines are almotst parallel at nkj.primitiveshape.line3.crosssection()')
			return None
		nvec = l1.vector * l2.vector
		pl_1 = plane([l1.origin, l1.vector * nvec])  # 直線 l1 とベクトル nvec を含む平面を定義
		pl_2 = plane([l2.origin, l2.vector * nvec])  # 直線 l2 とベクトル nvec を含む平面を定義
		cpt1 = pl_2 & l1
		cpt2 = pl_1 & l2
		cpt = (cpt1 + cpt2) / 2.0
		_n.ldprint('<-- nkj.primitiveshape.line3.crosssection()')
		return cpt

	def crosspoint(self, x):
		return self.crosssection(x)

	def setByPoints(self, pts, length=1.0):
		_n.ldprint('--> nkj.primitiveshape.line3.setByPoints(, {})'.format(length))
		if (_ncs.is_point3list(pts)):
			pass
		elif (isinstance(pts, (list, tuple))):
			pts = _ncs.point3list(pts)
		else:
			raise TypeError("Illegal data type. NKJ-PRIMITIVESHAPE-00340.")
		l, p = np.linalg.eigh(pts.cvm)
		_n.ldprint2('Eigen value:  {}'.format(l))
		_n.ldprint2('Eigen vector: {}'.format(p))
		maxval, maxid = _nm.max_index(l)
		maxvec = p[:, maxid]  # i番目の固有値とp[:, i]の固有ベクトルが対応している
		_n.ldprint2('Maximum eigen value: index:[{0}], value:{1}'.format(maxid, maxval))
		_n.ldprint2('Maximum eigen vector:              {}'.format(maxvec))
		maxvec = _ncs.vec3(maxvec)
		maxvec.normalize()
		_n.ldprint2('Maximum eigen vector (normalized): {}'.format(maxvec))
		self.setPoint(0, pts.average)
		self.setPoint(1, pts.average + length * maxvec)
		if (nd.LIB_DEBUG):
			self.print("line3 (by points)")
		_n.ldprint('<-- nkj.primitiveshape.line3.setByPoints()')

	def setFromPoints(self, pts, length=1.0):
		self.setByPoints(pts, length)

	@property
	def by_points(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00359.")

	@by_points.setter
	def by_points(self, x):
		if (_ncs.is_point3list(x)):
			self.setByPoints(x)
		elif (isinstance(x, (list, tuple, np.array))):
			if (len(x) == 2):
				if ((_ncs.is_point3list(x[0]) or isinstance(x[0], (list, tuple))) and _nm.is_digit(x[1])):
					self.setByPoints(x[0], x[1])
				else:
					self.setByPoints(x)
			else:
				self.setByPoints(x)

	@property
	def from_points(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00379.")

	@from_points.setter
	def from_points(self, x):
		if (_ncs.is_point3list(x)):
			self.setFromPoints(x)
		elif (isinstance(x, (list, tuple, np.array))):
			if (len(x) == 2):
				if ((_ncs.is_point3list(x[0]) or isinstance(x[0], (list, tuple))) and _nm.is_digit(x[1])):
					self.setFromPoints(x[0], x[1])
				else:
					self.setFromPoints(x)
			else:
				self.setFromPoints(x)

	def getAngle(self, x):
		v1 = self.getVector()
		v2 = x.getVector()
		return v1.getAngle(v2)

	def angle(self, x):
		return self.getAngle(x)

	def ang(self, x):
		return self.getAngle(x)

	def rad(self, x):
		return self.getAngle(x)

	def deg(self, x):
		return _nm.rad2deg(self.getAngle(x))

	def is_componentclass(self, x):
		return _ncs.is_point3(x)

	#
	#  x - x0     y - y0     z - z0
	# -------- = -------- = --------
	#    a          b          c
	#
	def getPointFromX(self, x):
		a, b, c, x0, y0, z0 = self.serialize()
		x = x0 if (_nm.is_ineps(a)) else x
		y = y0 if (_nm.is_ineps(a)) else y0 + b * (x - x0) / a
		z = z0 if (_nm.is_ineps(a)) else z0 + c * (x - x0) / a
		return _nm.vec3([x, y, z])

	def getPointFromY(self, y):
		a, b, c, x0, y0, z0 = self.serialize()
		y = x0 if (_nm.is_ineps(b)) else y
		z = z0 if (_nm.is_ineps(b)) else z0 + c * (y - y0) / b
		x = x0 if (_nm.is_ineps(b)) else x0 + a * (y - y0) / b
		return _nm.vec3([x, y, z])

	def getPointFromZ(self, z):
		a, b, c, x0, y0, z0 = self.serialize()
		z = z0 if (_nm.is_ineps(c)) else z
		x = x0 if (_nm.is_ineps(c)) else x0 + a * (z - z0) / c
		y = y0 if (_nm.is_ineps(c)) else y0 + b * (z - z0) / c
		return _nm.vec3([x, y, z])

	def PointFromX(self, x):
		return self.getPointFromX(x)

	def PointFromY(self, y):
		return self.getPointFromY(y)

	def PointFromZ(self, z):
		return self.getPointFromZ(z)

	def point_from_x(self, x):
		return self.getPointFromX(x)

	def point_from_y(self, y):
		return self.getPointFromY(y)

	def point_from_z(self, z):
		return self.getPointFromZ(z)

	def from_x(self, x):
		return self.getPointFromX(x)

	def from_y(self, y):
		return self.getPointFromY(y)

	def from_z(self, z):
		return self.getPointFromZ(z)

	def getPointFromIndexAndValue(self, index, val):
		if (index == 0):
			pt = self.getPointFromX(val)
		elif (index == 1):
			pt = self.getPointFromY(val)
		elif (index == 2):
			pt = self.getPointFromZ(val)
		else:
			raise ValueError('__ERROR__: Illegal index.')
		return pt

	def PointFromIndexAndValue(self, index, val):
		return self.getPointFromIndexAndValue(index, val)

	def point_from_indexandvalue(self, index, val):
		return self.getPointFromIndexAndValue(index, val)

	def from_indexandvalue(self, index, val):
		return self.getPointFromIndexAndValue(index, val)

	# isinstance

	def isinstance(self, x):
		return is_line3(x)

class line3(line3_cls):
	pass

class line(line3_cls):
	pass

def is_line3(x):
	return isinstance(x, line3_cls)

def is_line(x):
	return is_line3(x)


#-- Plane class

class plane3_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshapes.plane3'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None):
		self.set(_DEFAULT_PLANE if (x is None) else x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		return self.multiply(second)

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def __and__(self, second):     # '&' operator
		return self.crosssection(second)

	def __lshift__(self, second):  # 'self.plane << x' operator
		return self.project(second)

	def __rrshift__(self, first):  # 'x >> self.plane' operator
		return self.project(first)

	# Data operation

	def set(self, x):
		_n.ldprint("--> nkj.primitiveshape.plane.set()")
		if (x is None):
			raise ValueError("__ERROR__: Value is None.")
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError("__ERROR__: Illegal data type.")
		if (len(x) == 0):
			raise TypeError("__ERROR__: Null data.")
		_n.ldprint2("len(x): {}".format(len(x)))
		if (len(x) != 2):
			raise TypeError("__ERROR__: Illegal data type.")
		if (not _ncs.is_point3(x[0])):
			raise TypeError("__ERROR__: Illegal data type.")
		if (not _ncs.is_vec3(x[1])):
			raise TypeError("__ERROR__: Illegal data type.")
		self.clear()
		for i in range(2):
			_n.ldprint("class name: {}".format(_n.classname(x[i])))
			self.append(x[i])
		if (nd.LIB_DEBUG):
			for i in range(len(x)):
				self[i].print("{0}".format(_n.classname(x[i])))
		_n.ldprint("<-- nkj.primitiveshape.plane.set()")

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		return self[index]

	def setComponent(self, index, x):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		if (index == 0):
			if (not _ncs.is_point3(x)):
				raise TypeError("__ERROR__: Illegal data type.")
		if (index == 1):
			if (not _ncs.is_vec3(x)):
				raise TypeError("__ERROR__: Illegal data type.")
		self[index] = x

	def Component(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	def getOrigin(self):
		return self.getComponent(0)

	def setOrigin(self, x):
		self.setComponent(0, x)

	def Origin(self, x=None):
		if (x is None):
			return self.getOrigin()
		else:
			self.setOrigin(x)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, x):
		self.setOrigin(x)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, x):
		self.setOrigin(x)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, x):
		self.setOrigin(x)

	def getNormalVector(self):
		return self.getComponent(1)

	def setNormalVector(self, x):
		self.setComponent(1, x)

	def NormalVector(self, x=None):
		if (x is None):
			return self.getNormalVector()
		else:
			self.setNormalVector(x)

	def getNormal(self):
		return self.getNormalVector()

	def setNormal(self, x):
		self.setNormalVector(x)

	def Normal(self, x=None):
		if (x is None):
			return self.getNormalVector()
		else:
			self.setNormalVector(x)

	def getVector(self):
		return self.getNormalVector()

	def setVector(self, x):
		self.setNormalVector(x)

	def Vector(self, x=None):
		if (x is None):
			return self.getNormalVector()
		else:
			self.setNormalVector(x)

	@property
	def normalvector(self):
		return self.getNormalVector()

	@normalvector.setter
	def normalvector(self, x):
		self.setNormalVector(x)

	@property
	def nv(self):
		return self.getNormalVector()

	@nv.setter
	def nv(self, x):
		self.setNormalVector(x)

	@property
	def normal(self):
		return self.getNormalVector()

	@normal.setter
	def normal(self, x):
		self.setNormalVector(x)

	@property
	def n(self):
		return self.getNormalVector()

	@n.setter
	def n(self, x):
		self.setNormalVector(x)

	@property
	def vector(self):
		return self.getNormalVector()

	@vector.setter
	def vector(self, x):
		self.setNormalVector(x)

	@property
	def vec(self):
		return self.getNormalVector()

	@vec.setter
	def vec(self, x):
		self.setNormalVector(x)

	@property
	def v(self):
		return self.getNormalVector()

	@v.setter
	def v(self, x):
		self.setNormalVector(x)

	def getOriginAndNormal(self):
		return self.getOrigin(), self.getNormal()

	def setOriginAndNormal(self, x):
		orig = x[0]
		nv = x[1]
		self.setOrigin(orig)
		self.setNormal(nv)

	def OriginAndNormal(self, x=None):
		if (x is None):
			return self.getOriginAndNormal(x)
		else:
			self.setOriginAndNormal(x)

	@property
	def originandnormal(self):
		return self.getOriginAndNormal()

	@originandnormal.setter
	def originandnormal(self, orig, nv):
		self.setOriginAndNormal(orig, nv)

	def getSerialized(self):
		#
		# a * (x - x0) + b * (y - y0) + c * (z - z0) = 0
		#
		vec = self.getVector()
		orig = self.getOrigin()
		return [vec.x, vec.y, vec.z, orig.x, orig.y, orig.z]  # a, b, c, x0, y0, z0

	@property
	def serialized(self):
		return self.getSerialized()

	def Serialize(self):
		return self.getSerialized()

	def serialize(self):
		return self.getSerialized()

	# Goemetrical computation

	def getSignedDistance(self, pt):
		#
		#      a * x + b * y + c * z + d
		# d = ---------------------------------
		#        sqrt(a^2 + b^2 + c^2)
		#
		a, b, c, x0, y0, z0 = self.serialize()
		v = _ncs.vec3([a, b, c])
		deno = v.norm  # denominator: sqrt(sq(a) + sq(b) + sq(c))   # denominator
		if (is_ineps(denomin)):
			_n.ldprint0('@ERROR: Zero directional vector: {}'.format(v))
			raise Exception('__ERROR__: Illegal plane parameters.')
		nume = a * (pt.x - x0) + b * (pt.y - y0) + c * (pt.z - z0)  # numerator: a * x + b * y + c * z + d
		d = nume / deno
		return d

	def SignedDistance(self, pt):
		return self.getSignedDistance(self, pt)

	def signeddistance(self, pt):
		return self.getSignedDistance(self, pt)

	def sdist(self, pt):
		return self.getSignedDistance(self, pt)

	def getDistance(self, pt):
		return _m.sqrt(self.getSignedDistance(pt))

	def Distance(self, pt):
		return self.getDistance(pt)

	def distance(self, pt):
		return self.getDistance(pt)

	def dist(self, pt):
		return self.getDistance(pt)

	def setByPoints(self, pts):
		_n.ldprint('--> nkj.primitiveshape.plane.setByPoints()')
		if (_ncs.is_point3list(pts)):
			pass
		elif (isinstance(pts, (list, tuple))):
			pts = _ncs.point3list(pts)
		else:
			raise TypeError("Illegal data type. NKJ-PRIMITIVESHAPE-00546.")
		l, p = np.linalg.eigh(pts.cvm)
		_n.ldprint2('Eigen value:  {}'.format(l))
		_n.ldprint2('Eigen vector: {}'.format(p))
		minval, minid = _nm.min_index(l)
		minvec = p[:, minid]  # i番目の固有値とp[:, i]の固有ベクトルが対応している
		_n.ldprint2('Minimum eigen value: index:[{0}], value:{1}'.format(minid, minval))
		_n.ldprint2('Minimum eigen vector:              {}'.format(minvec))
		minvec = _ncs.vec3(minvec)
		minvec.normalize()
		_n.ldprint2('Minimum eigen vector (normalized): {}'.format(minvec))
		self.setOrigin(pts.average)
		self.setNormal(minvec)
		if (nd.LIB_DEBUG):
			self.print("plane (by points)")
		_n.ldprint('<-- nkj.primitiveshape.plane.setByPoints()')

	def setFromPoints(self, pts):
		self.setByPoints(pts)

	@property
	def by_points(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00554.")

	@by_points.setter
	def by_points(self, pts):
		self.setByPoints(pts)

	@property
	def from_points(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00642.")

	@from_points.setter
	def from_points(self, pts):
		self.setFromPoints(pts)

	def setByMatrix(self, m):
		self.setOrigin(m.getColumn3(3))
		self.setNormal(m.getColumn3(2))

	def setFromMatrix(self, m):
		self.setByMatrix(self, m)
	
	@property
	def by_matrix(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00657.")

	@by_matrix.setter
	def by_matrix(self, m):
		self.setByMatrix(m)

	@property
	def from_matrix(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00665.")

	@from_matrix.setter
	def from_matrix(self, m):
		self.setFromMatrix(m)

	def getMat3x4(self):
		zaxis = self.getNormal().normalized
		m = _ncs.mat3x4()
		m = zaxis.matrix(_ncs.ZAXISINDEX)
		m.setTranslation(self.getOrigin())
		return m

	@property
	def mat3x4(self):
		return self.getMat3x4()

	@property
	def m3x4(self):
		return self.getMat3x4()

	@property
	def mat3(self):
		return self.getMat3x4()

	@property
	def m3(self):
		return self.getMat3x4()

	def getMatrix(self):
		return self.getMat3x4()

	@property
	def matrix(self):
		return self.getMat3x4()

	@property
	def mat(self):
		return self.getMat3x4()

	@property
	def m(self):
		return self.getMat3x4()

	# Operators

	def multiply(self, second):
		if (second is None):
			raise Exception('__ERROR__: Null data.')
		if (_ncs.is_mat3x4(second)):
			pl = plane3()
			pl.setOrigin(_ncs.point3(second @ self.getOrigin()))
			pl.setNormal(_ncs.vec3(second @ self.getNormal()))
			return pl
		else:
			_n.ldprint0('@ERROR: second: {0} ({1})'.format(second, type(second)))
			raise Exception('__ERROR__: Not implemented.')

	def rmultiply(self, first):
		return self.multiply(first)

	# Geometrical computation

	def getAngle(self, x):
		v1 = self.getNormal()
		v2 = x.getNormal()
		return v1.getAngle(v2)

	def angle(self, x):
		return self.getAngle(x)

	def ang(self, x):
		return self.getAngle(x)

	def rad(self, x):
		return self.getAngle(x)

	def deg(self, x):
		return _nm.rad2deg(self.getAngle(x))

	def crosssection(self, x):
		_n.ldprint('--> nkj.primitiveshape.plane3.crosssection()')
		if (x is None):
			raise Exception('__ERROR__: Null input.')
		if (nd.LIB_DEBUG2):
			self.print('self')
			x.print('x')
		if (self.isinstance(x)):  # x is a plane. Return the crosssection line.
			pl1 = self
			pl2 = x
			nvec1 = pl1.normal.normalized
			nvec2 = pl2.normal.normalized
			crossvec = (nvec1 * nvec2).normalized
			line1 = line3([pl1.origin, nvec1 * crossvec], _LINE_SETTINGFLAG_ORIGINANDVECTOR)
			line2 = line3([pl2.origin, nvec2 * crossvec], _LINE_SETTINGFLAG_ORIGINANDVECTOR)
			origin = line1 & line2
			return line3([origin, crossvec], _LINE_SETTINGFLAG_ORIGINANDVECTOR)
		elif (is_line3(x)):  # x is a line. Return the crosssection point.
			line = x
			plane = self
			a_l, b_l, c_l = line.vector.components
			x0_l, y0_l, z0_l = line.origin.components
			a, b, c = plane.vector.components
			x0, y0, z0 = plane.origin.components
			t = (a * (x0 - x0_l) + b * (y0 - y0_l) + c * (z0 - z0_l)) / (a * a_l + b * b_l + c * c_l)
			x = a_l * t + x0_l
			y = b_l * t + y0_l
			z = c_l * t + z0_l
			return _ncs.vec3([x, y, z])
		else:
			raise Exception('__ERROR__: Not supported.')
		_n.ldprint('<-- nkj.primitiveshape.plane3.crosssection()')

	def crosspoint(self, x):
		return self.crosssection(x)

	def project2(self, x):
		return self.getMat3x4().project2(x)

	def project3(self, x):
		return self.getMat3x4().project3(x)

	def project(self, x):
		return self.project3(x)

	#
	# a * (x - x0) + b * (y - y0) + c * (z - z0) = 0
	#
	def getX(self, pt):
		a, b, c, x0, y0, z0 = self.serialize()
		y = pt[0]
		z = pt[1]
		x = x0 if (_nm.is_ineps(a)) else x0 - (b * (y - y0) + c * (z - z0)) / a
		return z

	def getY(self, pt):  # 引数は◯ (x, z) であり、× (z, x) でないので注意すること．
		a, b, c, x0, y0, z0 = self.serialize()
		x = pt[0]
		z = pt[1]
		y = y0 if (_nm.is_ineps(b)) else y0 - (c * (z - z0) + a * (x - x0)) / b
		return z

	def getZ(self, pt):
		a, b, c, x0, y0, z0 = self.serialize()
		x = pt[0]
		y = pt[1]
		z = z0 if (_nm.is_ineps(c)) else z0 - (a * (x - x0) + b * (y - y0)) / c
		return z

	def X(self, pt):
		return self.getX(pt)

	def Y(self, pt):
		return self.getY(pt)

	def Z(self, pt):
		return self.getZ(pt)

	def x(self, pt):
		return self.getX(pt)

	def y(self, pt):
		return self.getY(pt)

	def z(self, pt):
		return self.getZ(pt)

	def getPointFromYZ(self, pt):
		return _nm.vec3([self.getX(pt), pt[0], pt[1]])

	def getPointFromXZ(self, pt):
		return _nm.vec3([pt[0], self.getY(pt), pt[1]])

	def getPointFromXY(self, pt):
		return _nm.vec3([pt[0], pt[1], self.getZ(pt)])

	def PointFromYZ(self, pt):
		return self.getPointFromYZ(pt)

	def PointFromXZ(self, pt):
		return self.getPointFromXZ(pt)

	def PointFromXY(self, pt):
		return self.getPointFromXY(pt)

	def point_from_yz(self, pt):
		return self.getPointFromYZ(pt)

	def point_from_xy(self, pt):
		return self.getPointFromXZ(pt)

	def point_from_xy(self, pt):
		return self.getPointFromXY(pt)

	def from_yz(self, pt):
		return self.getPointFromYZ(pt)

	def from_xy(self, pt):
		return self.getPointFromXZ(pt)

	def from_xy(self, pt):
		return self.getPointFromXY(pt)

	# isinstace

	def isinstance(self, x):
		return is_plane(x)

	# Print

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		for i in range(2):
			if (i != 0):
				s += ', '
			s += '{}'.format(self.getComponent(i).getPrintString())
		return s

	def getPrintStr(self, title=None):
		return self.getPrintString(title)

	@property
	def printstr(self):
		return self.getPrintStr()

	@property
	def pstr(self):
		return self.getPrintStr()

	def print(self, title=None):
		print(self.getPrintString(title), flush=True)

class plane3(plane3_cls):
	pass

class plane(plane3_cls):
	pass

def is_plane3(x):
	return isinstance(x, plane3_cls)

def is_plane(x):
	return is_plane3(x)


#-- Sphare class

class sphare3_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshapes.sphare3'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(_DEFAULT_SPHARE if (x is None) else x)
		return self

	def __init__(self, x=None):
		self.set(_DEFAULT_SPHARE if (x is None) else x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		raise Exception("__ERROR__: Not implemented.")

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def set(self, x):
		_n.ldprint("--> nkj.primitiveshape.sphare.set()")
		if (x is None):
			raise ValueError("__ERROR__: Value is None.")
		if (not (isinstance(x, list) or isinstance(x, tuple))):
			raise TypeError("__ERROR__: Illegal data type.")
		dlen = len(x)
		_n.ldprint2("len(x): {}".format(dlen))
		if (dlen != 2):
			raise TypeError("__ERROR__: Illegal data type.")
		if (not _ncs.is_point3(x[0])):
			raise TypeError("__ERROR__: Illegal data type.")
		if (not _nm.is_digit(x[1])):
			raise TypeError("__ERROR__: Illegal data type.")
		self.clear()
		for i in range(dlen):
			_n.ldprint("class name: {}".format(_n.classname(x[i])))
			self.append(x[i])
		if (nd.LIB_DEBUG):
			self[0].print("{0}".format(_n.classname(x[0])))
			print("{0}: {1}".format(_n.classname(x[1]), x[1]))
		_n.ldprint("<-- nkj.primitiveshape.sphare.set()")

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		return self[index]

	def setComponent(self, index, x):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		if (index == 0):
			if (not _ncs.is_point3(x)):
				raise TypeError("__ERROR__: Illegal data type.")
		if (index == 1):
			if (not _nm.is_digit(x)):
				raise TypeError("__ERROR__: Illegal data type.")
		self[index] = x

	def getOrigin(self):
		return self.getComponent(0)

	def setOrigin(self, x):
		self.setComponent(0, x)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, x):
		self.setOrigin(x)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, x):
		self.setOrigin(x)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, x):
		self.setOrigin(x)

	def getRadius(self):
		return self.getComponent(1)

	def setRadius(self, x):
		self.setComponent(1, x)

	@property
	def radius(self):
		return self.getRadius()

	@radius.setter
	def radius(self, x):
		self.setRadius(x)

	@property
	def r(self):
		return self.getRadius()

	@r.setter
	def r(self, x):
		self.setRadius(x)

	def serialize(self):
		#
		# (x - x0)^2 + (y - y0)^2 + (z - z0)^2 = r^2
		#
		orig = self.getOrigin()
		radius = self.getRadius()
		return [orig.x, orig.y, orig.z, radius]  # x0, y0, z0, r

	@property
	def serialized(self):
		return self.serialize()

	def rmultiply(self, first):
		if (_ncs.is_mat3x3(first)):
			newl = []
			newl.append(_ncs.point3(first @ self.getOrigin()))
			newl.append(self.getRadius())
			return plane(newl)
		elif (_ncs.is_mat3x4(first)):
			newl = []
			newl.append(_ncs.point3(first @ self.getOrigin().h))
			newl.append(self.getRadius())
			return plane(newl)
		elif (_ncs.is_mat4x4(first)):
			newl = []
			newl.append(_ncs.point3((first @ self.getOrigin().h).ih))
			newl.append(self.getRadius())
			return plane(newl)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	def isinstance(self, x):
		return is_sphare(x)

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		s += '{}'.format(self.getOrigin().getPrintString())
		s += ', '
		s += '{:12.6f}'.format(self.getRadius())
		return s

	def getPrintStr(self, title=None):
		return self.getPrintString(title)

	@property
	def printstr(self):
		return self.getPrintStr()

	@property
	def pstr(self):
		return self.getPrintStr()

	def print(self, title=None):
		print(self.getPrintString(title), flush=True)

class sphare3(sphare3_cls):
	pass

class sphare(sphare3_cls):
	pass

def is_sphare3(x):
	return isinstance(x, sphare_cls)

def is_sphare(x):
	return is_sphare3(x)


#-- Circle classes

class circle2_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshapes.circle2'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(_DEFAULT_CIRCLE2 if (x is None) else x)
		return self

	def __init__(self, x=None):
		self.set(_DEFAULT_CIRCLE2 if (x is None) else x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		raise Exception("__ERROR__: Not implemented.")

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def set(self, x):
		_n.ldprint("--> nkj.primitiveshape.circle2.set()")
		if (x is None):
			raise ValueError("__ERROR__: Value is None.")
		
		if (not isinstance(x, (list, tuple))):
			raise TypeError("__ERROR__: Illegal data type.")
		
		dlen = len(x)
		_n.ldprint2("len(x): {}".format(dlen))
		if (dlen != 2):
			raise TypeError("__ERROR__: Illegal data type.")
		
		_n.ldprint("x: {0} ({1})".format(x, type(x)))
		
		if (not _ncs.is_point2(x[0])):
			raise TypeError("__ERROR__: Illegal data type.")
		
		if (not _nm.is_digit(x[1])):
			raise TypeError("__ERROR__: Illegal data type.")
		
		self.clear()
		for i in range(dlen):
			_n.ldprint("class name: {}".format(_n.classname(x[i])))
			self.append(x[i])
		
		if (nd.LIB_DEBUG):
			self[0].print("{0}".format(_n.classname(x[0])))
			print("{0}: {1}".format(_n.classname(x[1]), x[1]))
		
		_n.ldprint("<-- nkj.primitiveshape.circle2.set()")

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		return self[index]

	def setComponent(self, index, x):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		if (index == 0):
			if (not _ncs.is_point2(x)):
				raise TypeError("__ERROR__: Illegal data type.")
		if (index == 1):
			if (not _nm.is_digit(x)):
				raise TypeError("__ERROR__: Illegal data type.")
		self[index] = x

	def getOrigin(self):
		return self.getComponent(0)

	def setOrigin(self, x):
		self.setComponent(0, x)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, x):
		self.setOrigin(x)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, x):
		self.setOrigin(x)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, x):
		self.setOrigin(x)

	def getRadius(self):
		return self.getComponent(1)

	def setRadius(self, x):
		self.setComponent(1, x)

	@property
	def radius(self):
		return self.getRadius()

	@radius.setter
	def radius(self, x):
		self.setRadius(x)

	@property
	def r(self):
		return self.getRadius()

	@r.setter
	def r(self, x):
		self.setRadius(x)

	def serialize(self):
		#
		# (x - x0)^2 + (y - y0)^2 = r^2
		#
		orig = self.getOrigin()
		radius = self.getRadius()
		return [orig.x, orig.y, radius]  # x0, y0, r

	@property
	def serialized(self):
		return self.serialize()

	def rmultiply(self, first):
		if (_ncs.is_mat2x2(first)):
			newl = []
			newl.append(_ncs.point2(first @ self.getOrigin()))
			newl.append(self.getRadius())
			return plane(newl)
		elif (_ncs.is_mat2x3(first)):
			newl = []
			newl.append(_ncs.point2(first @ self.getOrigin().h))
			newl.append(self.getRadius())
			return plane(newl)
		elif (_ncs.is_mat3x3(first)):
			newl = []
			newl.append(_ncs.point2((first @ self.getOrigin().h).ih))
			newl.append(self.getRadius())
			return plane(newl)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	def isinstance(self, x):
		return is_circle2(x)

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		s += '{}'.format(self.getOrigin().getPrintString())
		s += ', '
		s += '{:12.6f}'.format(self.getRadius())
		return s

	def getPrintStr(self, title=None):
		return self.getPrintString(title)

	@property
	def printstr(self):
		return self.getPrintStr()

	@property
	def pstr(self):
		return self.getPrintStr()

	def print(self, title=None):
		print(self.getPrintString(title), flush=True)

class circle2(circle2_cls):
	pass

class circle(circle2_cls):
	pass

class arc2(circle2_cls):
	pass

class arc(circle2_cls):
	pass

def is_circle2(x):
	return isinstance(x, circle2_cls)

def is_circle(x):
	return is_circle2(x)

def is_arc2(x):
	return is_circle2(x)

def is_arc(x):
	return is_circle2(x)


class circle3_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshapes.circle3'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(_DEFAULT_CIRCLE3 if (x is None) else x)
		return self

	def __init__(self, x=None):
		self.set(_DEFAULT_CIRCLE3 if (x is None) else x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		raise Exception("__ERROR__: Not implemented.")

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def set(self, x):
		_n.ldprint("--> nkj.primitiveshape.circle3.set()")
		if (x is None):
			raise ValueError("__ERROR__: Value is None.")
		
		if (not isinstance(x, (list, tuple))):
			raise TypeError("__ERROR__: Illegal data type.")
		
		dlen = len(x)
		_n.ldprint2("len(x): {}".format(dlen))
		if (dlen != 2):
			raise TypeError("__ERROR__: Illegal data type.")
		
		_n.ldprint("x: {0} ({1})".format(x, type(x)))
		
		if (_ncs.is_mat3x4(x[0])):
			pass
		elif (_ncs.is_mat4x4(x[0])):
			x[0] = x[0].mat3x4
		else:
			_n.ldprint0("@ERROR: x[0]: {0}, classname: \'{1}\'".format(x[0], _ns.classname(x[0])))
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01034.")
		
		if (not _nm.is_digit(x[1])):
			_n.ldprint0("@ERROR: x[1]: {0}, classname: \'{1}\'".format(x[1], _ns.classname(x[1])))
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01036.")
		
		self.clear()
		for i in range(dlen):
			_n.ldprint("class name: {}".format(_n.classname(x[i])))
			self.append(x[i])
		
		if (nd.LIB_DEBUG):
			self[0].print("{0}".format(_n.classname(x[0])))
			print("{0}: {1}".format(_n.classname(x[1]), x[1]))
		
		_n.ldprint("<-- nkj.primitiveshape.circle3.set()")

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		return self[index]

	def setComponent(self, index, x):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		
		if (index == 0):
			if (_ncs.is_mat3x4(x)):
				pass
			elif (_ncs.is_mat4x4(x)):
				x = x.mat3x4
			else:
				raise TypeError("__ERROR__: Illegal data type.")
		elif (index == 1):
			if (not _nm.is_digit(x)):
				raise TypeError("__ERROR__: Illegal data type.")
		
		self[index] = x

	def getMatrix(self):
		return self.getcomponent(0)

	def setMatrix(self, x):
		self.setComponent(0, x)

	@property
	def matrix(self):
		return self.getMarix()

	@matrix.setter
	def matrix(self, x):
		self.setMatrix(x)

	@property
	def mat(self):
		return self.getMarix()

	@mat.setter
	def mat(self, x):
		self.setMatrix(x)

	def getOrigin(self):
		return self.getMatrix().getTranslation()

	def setOrigin(self, x):
		m = self.getMatrix()
		m.setTranslation(x)
		self.setComponent(0, m)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, x):
		self.setOrigin(x)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, x):
		self.setOrigin(x)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, x):
		self.setOrigin(x)

	def getNormalVector(self):
		return self.getMatrix().zaxis

	def getNormal(self):
		return self.getNormalVector()

	def getVector(self):
		return self.getNormalVector()

	@property
	def normal(self):
		return self.getNormalVector()

	@property
	def n(self):
		return self.getNormalVector()

	@property
	def vector(self):
		return self.getNormalVector()

	@property
	def vec(self):
		return self.getNormalVector()

	@property
	def v(self):
		return self.getNormalVector()

	def getRadius(self):
		return self.getComponent(1)

	def setRadius(self, x):
		self.setComponent(1, x)

	@property
	def radius(self):
		return self.getRadius()

	@radius.setter
	def radius(self, x):
		self.setRadius(x)

	@property
	def r(self):
		return self.getRadius()

	@r.setter
	def r(self, x):
		self.setRadius(x)

	# Serialization

	def serialize(self):
		#
		# (x - x0)^2 + (y - y0)^2 + (z - z0)^2 = r^2
		#
		orig = self.getOrigin()
		n = self.getNormal()
		radius = self.getRadius()
		return [orig.x, orig.y, orig.z, n.x, n.y, n.z, radius]  # x0, y0, z0, nx, ny, nz, r

	@property
	def serialized(self):
		return self.serialize()

	# Operators

	def rmultiply(self, first):
		if (_ncs.is_mat3x3(first)):
			newl = []
			newl.append(_ncs.point3(first @ self.getOrigin()))
			newl.append(self.getRadius())
			return plane(newl)
		elif (_ncs.is_mat3x4(first)):
			newl = []
			newl.append(_ncs.point3(first @ self.getOrigin().h))
			newl.append(self.getRadius())
			return plane(newl)
		elif (_ncs.is_mat4x4(first)):
			newl = []
			newl.append(_ncs.point3((first @ self.getOrigin().h).ih))
			newl.append(self.getRadius())
			return plane(newl)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	# Functions

	# Print

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		s += '{}'.format(self.getOrigin().getPrintString())
		s += ', '
		s += '{:12.6f}'.format(self.getRadius())
		return s

	def getPrintStr(self, title=None):
		return self.getPrintString(title)

	@property
	def printstr(self):
		return self.getPrintStr()

	@property
	def pstr(self):
		return self.getPrintStr()

	def print(self, title=None):
		print(self.getPrintString(title), flush=True)

	# isinstance

	def isinstance(self, x):
		return is_circle3(x)

class circle3(circle3_cls):
	pass

class arc3(circle3_cls):
	pass

def is_circle3(x):
	return isinstance(x, circle3_cls)

def is_arc3(x):
	return is_circle3(x)


#-- Cylinder class

class cylinder3_cls(primitiveshape_cls):
	pass

class cylinder3(cylinder3_cls):
	pass

class cylinder(cylinder3):
	pass

class pipe3(cylinder3_cls):
	pass

class pipe(pipe3):
	pass

def is_cylinder3(x):
	return isinstance(x, cylinder3_cls)

def is_cylinder(x):
	return is_cylinder3(x)

def is_pipe3(x):
	return is_cylinder3(x)

def is_pipe(x):
	return is_cylinder3(x)


#-- Cone class

class cone3_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshape.cone3'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.set(x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def get(self):
		return self.getComponent()

	def set(self, x=None):
		if (self.isinstance(x)):
			basecenter, tip, baseradius = x.get()
		elif (isinstance(x, (list, tuple))):
			if (len(x) != 3):
				raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01451.")
			basecenter = _ncs.point3(x[0])
			tip = _ncs.point3(x[1])
			baseradius = x[2]
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01458.")
		self.setBaseCenter(basecenter)
		self.setTip(tip)
		self.setBaseRadius(baseradius)

	def getComponent(self, index=None):
		if (index is None):
			return [x.getBaseCenter(), x.getTip(), x.getBaseRadius()]
		elif (_nm.is_digit(index)):
			if (not _nm.is_inrange(index, 0, 2)):
				raise ValueError("__ERROR__: Illegal index. NKJ-PRIMITIVESHAPE-01469.")
			return x.getBaseCenter() if (x == 0) else (x.getTip() if (x == 1) else x.getBaseRadius())
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01472.")

	def component(self, index=None):
		return self.getComponent(index)

	def getBaseCenter(self):
		return self._basecenter

	def setBaseCenter(self, x):
		self._basecenter = x if (_ncs.is_point3(x)) else _ncs.point3(x)

	def getCenter(self):
		return self.getBaseCenter()

	def setCenter(self, x):
		self.setBaseCenter(x)

	def getOrigin(self):
		return self.getBaseCenter()

	def setOrigin(self, x):
		self.setBaseCenter(x)

	@property
	def basecenter(self):
		return self.getBaseCenter()

	@basecenter.setter
	def basecenter(self, x):
		self.setBaseCenter(x)

	@property
	def center(self):
		return self.getBaseCenter()

	@center.setter
	def center(self, x):
		self.setBaseCenter(x)

	@property
	def cen(self):
		return self.getBaseCenter()

	@cen.setter
	def cen(self, x):
		self.setBaseCenter(x)

	@property
	def c(self):
		return self.getBaseCenter()

	@c.setter
	def c(self, x):
		self.setBaseCenter(x)

	@property
	def origin(self):
		return self.getBaseCenter()

	@origin.setter
	def origin(self, x):
		self.setBaseCenter(x)

	@property
	def orig(self):
		return self.getBaseCenter()

	@orig.setter
	def orig(self, x):
		self.setBaseCenter(x)

	@property
	def o(self):
		return self.getBaseCenter()

	@o.setter
	def o(self, x):
		self.setBaseCenter(x)

	def getTip(self):
		return self._tip

	def setTip(self, x):
		self._tip = x if (_ncs.is_point3(x)) else _ncs.point3(x)

	@property
	def tip(self):
		return self.getTip()

	@tip.setter
	def tip(self, x):
		self.setTip(x)

	@property
	def t(self):
		return self.getTip()

	@t.setter
	def t(self, x):
		self.setTip(x)

	def getBaseRadius(self):
		return self._baseradius

	def setBaseRadius(self, x):
		if (not _nm.is_digit(x)):
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01466.")
		self._baseradius = x

	def getRadius(self):
		return self.getBaseRadius()

	def setRaidus(self, x):
		self.setBaseRadius(x)

	@property
	def baseradius(self):
		return self.getBaseRadius()

	@baseradius.setter
	def baseradius(self, x):
		self.setBaseRadius(x)

	@property
	def radius(self):
		return self.getBaseRadius()

	@radius.setter
	def radius(self, x):
		self.setBaseRadius(x)

	@property
	def r(self):
		return self.getBaseRadius()

	@r.setter
	def r(self, x):
		self.setBaseRadius(x)

	def getHeight(self):
		return np.linalg.norm(np.array(self.getTip()) - np.array(self.getOrigin()))

	def setHeight(self, x):
		return True

	@property
	def height(self):
		return self.getHeight()

	@height.setter
	def height(self, x):
		self.setHeight(x)

	@property
	def h(self):
		return self.getHeight()

	@h.setter
	def h(self, x):
		self.setHeight(x)

	def getVector(self):
		return (self.getTip() - self.getOrigin()).normalized()

	def getDirection(self):
		return self.getVector()

	@property
	def vector(self):
		return self.getVector()

	@property
	def vec(self):
		return self.getVector()

	@property
	def v(self):
		return self.getVector()

	@property
	def direction(self):
		return self.getDirection()

	@property
	def direct(self):
		return self.getDirection()

	def getMatrix(self):
		pass

	@property
	def matrix(self):
		return self.getMatrix()

	@property
	def mat(self):
		return self.getMatrix()

	@property
	def m(self):
		return self.getMatrix()

	def isinstance(self, x):
		return is_cone3(x)

class cone3(cone3_cls):
	pass

class cone(cone3_cls):
	pass

def is_cone3(x):
	return isinstance(x, cone3_cls)

def is_cone(x):
	return is_cone3(x)


#-- List classes

class line2list_cls(_nl.uniclasslist_cls):
	_classname = 'nkj.primitiveshape.line2list'
	_componentclass = line2

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(x)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.setComponentClass(self.componentclass)
		self.set(x)
		self.dataheader(_nl.DATAHEADER_INDEX_SINGLELINE)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	@classmethod
	def getComponentClass(cls):
		return cls._componentclass

	@classmethod
	@property
	def componentclass(cls):
		return cls.getComponentClass()

	@classmethod
	def setComponentClass(cls, c):
		cls._componentclass = c

	def set_componentclass(cls, c):
		cls.setComponentClass(c)

	def set(self, x):
		_n.ldprint('--> nkj.primitiveshape.line2list.set()')
		_n.ldprint('x:           {}'.format(x))
		_n.ldprint('x.classname: \'{}\''.format(_n.classname(x)))
		if (x is None):
			pass
		elif (isinstance(x, (list, tuple))):
			if (len(x) == 0):
				raise Exception('__ERROR__: Illegal algorithm. NKJ-PRIMITIVESHAPE-01248.')
			for line in x:
				_n.ldprint2('line:           {}'.format(line))
				_n.ldprint2('line.classname: \'{}\''.format(_n.classname(line)))
				if (is_line2(line)):
					_n.ldprint2('line2 class')
					pass
				elif (isinstance(line, (list, tuple))):
					_n.ldprint2('list, tuple')
					line = line2(line)
				else:
					raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01233.")
				_n.ldprint2('line:           {}'.format(line))
				_n.ldprint2('line.classname: \'{}\''.format(_n.classname(line)))
				self.append(line)
		elif (is_line2list(x)):
			self.append(x)
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01253.")
		_n.ldprint('<-- nkj.primitiveshape.line2list.set()')

	# Functions

	def getVanishingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		_n.ldprint('--> nkj.primitiveshape.line2list.getVanishingPoint(, anglethresh: {}[deg])'.format(_nm.rad2deg(anglethresh)))
		anglethresh = 0.0 if (anglethresh is None) else anglethresh
		vptlist = _ncs.vec2list()
		for i in range(len(self)):
			for j in range(i + 1, len(self)):
				l1, l2 = self[i], self[j]
				angle = abs(Angle(l1, l2))
				_n.ldprint('angle: {:.6f} [deg]'.format(_nm.rad2deg(angle)))
				if (angle > anglethresh and abs(angle - _nm.deg2rad(180.0)) > anglethresh):
					_n.ldprint2('appended')
					vptlist.append(l1.crosssection(l2))
				else:
					_n.ldprint2('passed')
		if (nd.LIB_DEBUG):
			vptlist.print('crosssection points of l1 and l2: ')
		if (len(vptlist) == 0):
			_n.ldprint('No crosssection point')
			vtp = None
		else:
			vpt = vptlist.gravity
			if (nd.LIB_DEBUG):
				vpt.print('vanishing point')
		#
		# vanishing point と、直線からの距離や垂直二等分点からの距離で、データを取捨選択したいならここで実装．
		#
		_FINE_VERNISHING = True
		if (_FINE_VERNISHING and (vpt is not None)):
			_n.ldprint('->> Fine tuning.')
			vptlist.clear()
			for i in range(len(self)):
				for j in range(i + 1, len(self)):
					l1, l2 = self[i], self[j]
					angle = abs(Angle(l1, l2))
					_n.ldprint('angle: {:.6f} [deg]'.format(_nm.rad2deg(angle)))
					if (angle > anglethresh and abs(angle - _nm.deg2rad(180.0)) > anglethresh):
						_n.ldprint2('appended')
						vpt_candidate = l1.crosssection(l2)
						dist = (vpt_candidate - vpt).norm
						_n.ldprint('distance: {:.6f}'.format(dist))
						if (dist < _nm.distance_thresh()):
							vptlist.append(vpt_candidate)
					else:
						_n.ldprint2('passed')
		if (nd.LIB_DEBUG):
			vptlist.print('crosssection points of l1 and l2: ')
		if (len(vptlist) == 0):
			_n.ldprint('No crosssection point')
			vpt = None
		else:
			vpt = vptlist.gravity
			if (nd.LIB_DEBUG):
				vpt.print('vanishing point')
		_n.ldprint('<-- nkj.primitiveshape.line2list.getVanishingPoint()')
		return vpt

	def VanishingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(self, anglethresh)

	def vanishingpoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def vanishing(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def getConversingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def ConversingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		self.getConversingPoint(self, anglethresh)

	def conversingpoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getConversingPoint(anglethresh)

	def conversing(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getConversingPoint(anglethresh)

	# isinstance

	def isinstance(self, x):
		return is_line2list(x)

class line2list(line2list_cls):
	pass

class line2s(line2list_cls):
	pass

def is_line2list(x):
	return isinstance(x, line2list_cls)

def is_line2s(x):
	return is_line2list(x)


class line3list_cls(_nl.uniclasslist_cls):
	_classname = 'nkj.primitiveshape.line3list'
	_componentclass = line3

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(x)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.setComponentClass(self.componentclass)
		self.set(x)
		self.dataheader(_nl.DATAHEADER_INDEX_SINGLELINE)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	@classmethod
	def getComponentClass(cls):
		return cls._componentclass

	@classmethod
	@property
	def componentclass(cls):
		return cls.getComponentClass()

	@classmethod
	def setComponentClass(cls, c):
		cls._componentclass = c

	def set_componentclass(cls, c):
		cls.setComponentClass(c)

	def set(self, x):
		_n.ldprint('--> nkj.primitiveshape.line3list.set()')
		_n.ldprint('x:           {}'.format(x))
		_n.ldprint('x.classname: \'{}\''.format(_n.classname(x)))
		if (x is None):
			pass
		elif (isinstance(x, (list, tuple))):
			if (len(x) == 0):
				raise Exception('__ERROR__: Illegal algorithm. NKJ-PRIMITIVESHAPE-01248.')
			for line in x:
				_n.ldprint2('line:           {}'.format(line))
				_n.ldprint2('line.classname: \'{}\''.format(_n.classname(line)))
				if (is_line3(line)):
					_n.ldprint2('line3 class')
					pass
				elif (isinstance(line, (list, tuple))):
					_n.ldprint2('list, tuple')
					line = line3(line)
				else:
					raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01233.")
				_n.ldprint2('line:           {}'.format(line))
				_n.ldprint2('line.classname: \'{}\''.format(_n.classname(line)))
				self.append(line)
		elif (is_line3list(x)):
			self.append(x)
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01253.")
		_n.ldprint('<-- nkj.primitiveshape.line3list.set()')

	# Functions

	def getVanishingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		vptlist = point3list()
		if (anglethresh is None):
			for i in range(len(self)):
				for j in range(i + 1, len(self)):
					l1, l2 = self[i], self[j]
			return vptlist.gravity
		else:
			if (anglethresh > 0.0):
				for i in range(len(self)):
					for j in range(i + 1, len(self)):
						l1, l2 = self[i], self[j]
						if (Angle(l1, l2) > anglethresh):  # Line elimination by angle
							vptlist.append(l1 & l2)
				return vptlist.gravity
			else:
				for i in range(len(self)):
					for j in range(i + 1, len(self)):
						l1, l2 = self[i], self[j]
				return vptlist.gravity

	def VanishingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(self, anglethresh)

	def vanishingpoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def vanishing(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def getConversingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def conversingpoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getConversingPoint(anglethresh)

	def conversing(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getConversingPoint(anglethresh)

	# isinstance

	def isinstance(self, x):
		return is_line3list(x)

class line3list(line3list_cls):
	pass

class line3s(line3list_cls):
	pass

class linelist(line3list_cls):
	pass

class lines(line3list_cls):
	pass

def is_line3list(x):
	return isinstance(x, line3list_cls)

def is_line3s(x):
	return is_line3list(x)

def is_linelist(x):
	return is_line3list(x)

def is_lines(x):
	return is_line3list(x)


#-- Definitions

DEFAULT_LINE2 = line2(_DEFAULT_LINE2)
DEFAULT_LINE3 = line3(_DEFAULT_LINE3)
DEFAULT_LINE = DEFAULT_LINE3
DEFAULT_PLANE = plane(_DEFAULT_PLANE)
DEFAULT_PLANE3 = DEFAULT_PLANE
DEFAULT_SPHARE = sphare(_DEFAULT_SPHARE)
DEFAULT_SPHARE3 = DEFAULT_SPHARE
DEFAULT_CIRCLE2 = circle2(_DEFAULT_CIRCLE2)
DEFAULT_CIRCLE3 = circle3(_DEFAULT_CIRCLE3)
DEFAULT_CIRCLE = DEFAULT_CIRCLE2


#-- Functions

def Angle(x1, x2):
	if (is_line2(x1)):
		if (is_line2(x2)):
			angle = x1.getAngle(x2)
		else:
			raise TypeError('__ERROR__: Illegal data type.')
	elif (is_line3(x1)):
		if (is_line3(x2)):
			angle = x1.getAngle(x2)
		else:
			raise TypeError('__ERROR__: Illegal data type.')
	elif (is_plane3(x1)):
		if (is_plane3(x2)):
			angle = x1.getAngle(x2)
		else:
			raise TypeError('__ERROR__: Illegal data type.')
	else:
		raise Exception('__ERROR__: Not supported.')
	return angle

def Rad(x1, x2):
	return Angle(x1, x2)

def Deg(x1, x2):
	return _nm.rad2deg(Angle(x1, x2))

def LineCrosssection(l1, l2):
	return l1.crosssection(l2)

def LineCrossPoint(l1, l2):
	return LineCrosssection(l1, l2)

def PlaneLineCrosssection(pl, l):
	return pl.crosssection(l)

def PlaneLineCrossPoint(pl, l):
	return PlaneLineCrosssection(pl, l)

def Crosssection(a, b):
	if (is_line2(a) or is_line3(a)):
		return LineCrosssection(a, b)
	elif (is_plane3(a)):
		return PlaneLineCrosssection(a, b)
	else:
		raise TypeError('__ERROR__: Not implemented. NKJ-PRIMITIVESHAPE-01870.')

def CrossPoint(a, b):
	return CrossSection(a, b)

def crosssection(a, b):
	return Crosssection(a, b)

def crosspoint(a, b):
	return CrossPoint(a, b)

def PerpendicularBisectorLine2(pt1:_ncs.point2, pt2:_ncs.point2):
	_n.ldprint('--> nkj.primitive.shape.PerpendicularBisectorLine2()')
	orig = (pt1 + pt2) / 2.0
	vec = (pt2 - pt1).perpendicular
	line = line2([orig, vec], _LINE_SETTINGFLAG_ORIGINANDVECTOR)
	if (nd.LIB_DEBUG2):
		line.print('perpendicular line')
		line.vector.print('line vector')
	_n.ldprint('<-- nkj.primitive.shape.PerpendicularBisectorLine2()')
	return line

def PerpendicularBisectorLine(pt1:_ncs.point2, pt2:_ncs.point2):
	return PerpendicularBisectorLine2(pt1, pt2)

def PerpendicularBisectorPlane3(pt1:_ncs.point3, pt2:_ncs.point3):
	orig = (pt1 + pt2) / 2.0
	vec = pt2 - pt1
	return plane3([orig, vec])

def PerpendicularBisectorPlane(pt1:_ncs.point3, pt2:_ncs.point3):
	return PerpendicularBisectorPlane3(pt1, pt2)

def PerpendicularBisector(pt1:_ncs.point2, pt2:_ncs.point2):
	return PerpendicularBisectorLine2(pt1, pt2)

def VanishingPoint(lines, anglethresh=_DEFAULT_KEEPING_ANGLE):
	if (not (is_line2list(lines) or is_line3list(lines))):
		raise Exception('__ERROR__: Not supported.')
	return lines.getVanishingPoint(anglethresh)

def ConversingLines(lines, anglethresh=_DEFAULT_KEEPING_ANGLE):
	return VanishingPoint(lines, anglethresh)

def RotationalVector(m1, m2):
	return _ncs.RotationalVector(m1, m2)

def RotationVector(m1, m2):
	return _ncs.RotationVector(m1, m2)

def RotationCenter4Points(pts1, pts2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	_n.ldprint('--> nkj.primitiveshape.RotationCenter4Points(, anglethresh: {}[deg])'.format(_nm.rad2deg(anglethresh)))
	if (pts2 is None):  # For points on a circle.
		_n.ldprint('@-- points. (pts2 is None.)')
		pts = pts1
		if (_ncs.is_vec2list(pts)):
			raise Exception('__ERROR__: Not implemented.')
		elif (_ncs.is_vec3list(pts)):
			raise Exception('__ERROR__: Not implemented.')
		else:
			raise Exception('__ERROR__: Not supported.')
	else:  # For point pairs. Using concentric circles
		_n.ldprint('@-- point pairs')
		if (nd.LIB_DEBUG2):
			pts1.print('pts1')
			pts2.print('pts2')
			print('pts1: {0} ({1})'.format(pts1, type(pts1)))
			print('pts2: {0} ({1})'.format(pts2, type(pts2)))
		
		if (_ncs.is_vec2list(pts1)):
			_n.ldprint('@-- pts1: vec2list')
			pass
		elif (isinstance(pts1, (list, tuple, np.ndarray))):
			_n.ldprint('@-- pts1: list/tuple/np.ndarray')
			ndim = _nm.ndim(pts1)
			_n.ldprint('pts.mdim: {}'.format(ndim))
			if (ndim == 1):
				_n.ldprint('pts1.len: {}'.format(len(pts1)))
				if (len(pts1) == 0):
					raise Exception('__ERROR__: Null data.')
			"""
			rows, columns = _nm.shape(pts1)
			_n.ldprint('pts.shape: ({0}, {1})'.format(rows, columns))
			"""
			pts1 = _ncs.vec2list(pts1)
		else:
			raise Exception('__ERROR__: Unsupported data type.')
		
		if (_ncs.is_vec2list(pts2)):
			_n.ldprint('@-- pts2: vec2list')
			pass
		elif (isinstance(pts2, (list, tuple, np.ndarray))):
			_n.ldprint('@-- pts2: list/tuple/np.ndarray')
			pts2 = _ncs.vec2list(pts2)
		else:
			raise Exception('__ERROR__: Unsupported data type.')
		
		if (nd.LIB_DEBUG2):
			pts1.print('pts1')
			pts2.print('pts2')
		
		if (len(pts1) != len(pts2)):
			_n.print_error('len(pts1): {0}, len(pts2): {1}'.format(len(pts1), len(pts2)))
			raise Exception('__ERROR__: List sizes are different.')
		
		if (_ncs.is_vec2list(pts1)):
			if (_ncs.is_vec2list(pts2)):
				_n.ldprint('@-- pair of vec2list --')
				plinelist = line2list()
				for i in range(len(pts1)):
					pt1 = pts1[i]
					pt2 = pts2[i]
					plinelist.append(PerpendicularBisectorLine2(pt1, pt2))
				if (nd.LIB_DEBUG):
					plinelist.print('perpendicular lines')
				if (len(plinelist) < 2):
					raise Exception('__ERROR__: Illegal algorithm. Perpendicular-line number is too little less than 2.')
				cenpt = VanishingPoint(plinelist, anglethresh)
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		elif (_ncs.is_vec3list(pts1)):
			if (_ncs.is_vec3list(pts2)):
				_n.ldprint('@-- pair of vec3list --')
				if (len(pts1) != len(pts2)):
					raise Exception('__ERROR__: List sizes are different.')
				pplanelist = plane3list()
				for pt1, pt2 in pts1, pts2:
					pplanelist.append(PerpendicularBisectorPlane3(pt1, pt2))
				plinelist = line3list()
				for i in range(len(pplanelist)):
					for j in range(i + 1, len(planelist)):
						pl1 = pplanelist[i]
						pl2 = pplanelist[j]
						if (abs(Angle(pl1.vector, pl2.vector)) < anglethresh):
							plinelist.append(pl1 & pl2)
				cenpt = VanishingPoint(plinelist, anglethresh)
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		else:
			raise Exception('__ERROR__: Not supported.')
	if (nd.LIB_DEBUG):
		cenpt.print('rotation center point')
	_n.ldprint('<-- nkj.primitiveshape.RotationCenter4Points()')
	return cenpt

def RotationCenterPoint4Points(pts1, pts2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	return RotationCenter4Points(pts1, pts2, anglethresh)

def RotationCenter4Matrices(m1, m2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	_n.ldprint('--> nkj.primitiveshape.RotationCenter4Matrices(, anglethresh: {}[deg])'.format(_nm.rad2deg(anglethresh)))
	if (_ncs.is_mat3x4(m1)):
		if (_ncs.is_mat3x4(m2)):
			raxis = _ncs.RotationalVector(m1, m2).normalized
			_METHOD = 2  # 残差計算の観点より，_METHOD #1 より _METHOD #2 をお勧め
			if (_METHOD == 1):
				_n.ldprint('@->> _METHOD: 1')
				orig = _ncs.vec3([0.0, 0.0, 0.0])
			elif (_METHOD == 2):
				_n.ldprint('@->> _METHOD: 2')
				orig = (m1.origin + m2.origin) / 2.0  # 投影平面の原点を計測座標系辺りに移動
			else:
				raise Exception('Illegal algorithm. Incorrect _METHOD.')
			if (nd.LIB_DEBUG2):
				raxis.print('rotation axis')
				orig.print('origin')
			m_plane = plane3([orig, raxis]).matrix  # m_plane: 任意の平面をx-y平面とする座標系
			if (nd.LIB_DEBUG2):
				m_plane.print('m_plane')
			_METHOD = 2
			if (_METHOD == 1):
				_n.ldprint('@->> _METHOD: 1')
				if (nd.LIB_DEBUG2):
					m1.print('m1')
					m2.print('m2')
				m2d_1 = m_plane.project2(m1)
				m2d_2 = m_plane.project2(m2)
				if (nd.LIB_DEBUG2):
					m2d_1.print('m2d_1')
					m2d_2.print('m2d_2')
				pts2d_1 = m2d_1.OriginAndHexagonVerts(10.0)  # 原点と正6角形頂点群．6角形半径は10.0
				pts2d_2 = m2d_2.OriginAndHexagonVerts(10.0)
				if (nd.LIB_DEBUG2):
					pts2d_1.print('pts2d_1 (origin and hexagon verts)')
					pts2d_2.print('pts2d_2 (origin and hexagon verts)')
			elif (_METHOD == 2):
				_n.ldprint('@->> _METHOD: 2')
				pts3d_1 = m1.OriginAndIcosahedronVerts(_ICOSAHEDRON_RADIUS1)  # 原点と正20面体頂点群．20面体半径は30.0
				pts3d_1.extend(m1.IcosahedronVerts(_ICOSAHEDRON_RADIUS2))     # 半径50.0の正20面体頂点群を追加．
				pts3d_2 = m2.OriginAndIcosahedronVerts(_ICOSAHEDRON_RADIUS1)
				pts3d_2.extend(m2.IcosahedronVerts(_ICOSAHEDRON_RADIUS2))
				if (nd.LIB_DEBUG0):
					if (len(pts3d_1) != len(pts3d_2)):
							raise Exception('__ERROR__: Number of points are mismatch.')
				#-- ここから取捨選択
				if (True):
					_DISTANCE_THRESHOLD = _nm.distance_thresh()
					_MIN_POINTS = 3
					plist1 = _ncs.vec3list()
					plist2 = _ncs.vec3list()
					for i in range(len(pts3d_1)):
						pt1 = pts3d_1[i]
						pt2 = pts3d_2[i]
						if ((pt2 - pt1).norm > _DISTANCE_THRESHOLD):
							plist1.append(pt1)
							plist2.append(pt2)
					if (len(plist1) < _MIN_POINTS):
						raise Exception('__ERROR__: Less points')
					pts3d_1 = plist1
					pts3d_2 = plist2
				#-- ここまで取捨選択
				if (nd.LIB_DEBUG2):
					pts3d_1.print('point3list #1')
					pts3d_2.print('point3list #2')
				if (nd.LIB_DEBUG0):
					#
					# Check with vtk polys
					#
					_VTK_POINTSFILE1 = 'testdata/test_icosahedronverts1.vtp'
					_VTK_POINTSFILE2 = 'testdata/test_icosahedronverts2.vtp'
					_VTK_LINEFILE = 'testdata/test_icosahedronvertsline.vtp'
					_VTK_PLANEFILE = 'testdata/test_icosahedronvertsplane.vtu'
					_VTK_CSFILE = 'testdata/test_icosahedronvertscs.vtp'
					poly1 = _ntk.points(pts3d_1)
					poly1.save(_VTK_POINTSFILE1)
					poly2 = _ntk.points(pts3d_2)
					poly2.save(_VTK_POINTSFILE2)
					if (len(pts3d_1) != len(pts3d_2)):
						raise Exception('__ERROR__: Illegal algorithm.')
					linelist = line3list()
					for i in range(len(pts3d_1)):
						linelist.append(line3([pts3d_1[i], pts3d_2[i]]))
					poly3 = _ntk.lines(linelist)
					poly3.save(_VTK_LINEFILE)
					poly4 = _ntk.plane(plane3([orig, raxis]))
					poly4.save(_VTK_PLANEFILE)
					poly5 = _ntk.coordinate(m_plane, 10.0)
					poly5.save(_VTK_CSFILE)
				pts2d_1 = m_plane.project2(pts3d_1)
				pts2d_2 = m_plane.project2(pts3d_2)
				if (nd.LIB_DEBUG2):
					pts2d_1.print('point2list #1')
					pts2d_2.print('point2list #2')
			else:
				raise Exception('__ERROR__: Illegal _METHOD.')
			cpt2 = RotationCenter4Points(pts2d_1, pts2d_2, anglethresh)  # 回転中心点 on the x-y plane of m_plane-CS
			if (nd.LIB_DEBUG):
				cpt2.print('rotation center in 2D-CS')
			if (cpt2 is None):
				cenpt = None
			else:
				cenpt = m_plane @ _ncs.vec3([cpt2.x, cpt2.y, 0.0])
				cenpt.residue = cpt2.residue
		else:
			raise TypeError('__ERROR__: Illegal data type.')
	else:
		raise Exception('__ERROR__: Not supported.')
	_n.ldprint('<-- nkj.primitiveshape.RotationCenter4Matrices(): {}'.format(cenpt))
	return cenpt

def RotationCenterPoint4Matrices(m1, m2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	return RotationCenter4Matrices(m1, m2, anglethresh)

def RotationCenter(x1, x2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	_n.ldprint('--> nkj.primitiveshape.RotationCenter(, anglethresh: {}[deg])'.format(_nm.rad2deg(anglethresh)))
	_n.ldprint('x1: {0} ({1})'.format(x1, type(x1)))
	_n.ldprint('x2: {0} ({1})'.format(x2, type(x2)))
	if (_ncs.is_point2list(x1) or _ncs.is_point3list(x1)):
		cenpt = RotationCenter4Points(x1, x2, anglethresh)
	elif (_ncs.is_mat3x4(x1)):
		cenpt = RotationCenter4Matrices(x1, x2, anglethresh)
	else:
		raise Exception('__ERROR__: Not supported.')
	_n.ldprint('<-- nkj.primitiveshape.RotationCenter()')
	return cenpt

def RotationCenterPoint(x1, x2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	return RotationCenter(x1, x2, anglethresh)

def RotationalAxis(m1, m2, anglethresh=_DEFAULT_KEEPING_ANGLE):
	_n.ldprint('--> nkj.primitiveshape.RotationalAxis(, anglethresh: {}[deg])'.format(_nm.rad2deg(anglethresh)))
	vec = RotationalVector(m1, m2).normalized
	if (nd.LIB_DEBUG):
		vec.print('rotation vector')
	if (_nm.is_ineps(vec.norm, 0.0)):
		_n.ldprint2('@ERROR: No rotation.')
		_n.ldprint('<-- nkj.primitiveshape.RotationalAxis(): {}'.format(None))
		return None
	else:
		cpt = RotationCenter(m1, m2, anglethresh)
		if (cpt is None):
			raxis = None
		else:
			raxis = line3([cpt, vec], _LINE_SETTINGFLAG_ORIGINANDVECTOR)
		_n.ldprint('<-- nkj.primitiveshape.RotationalAxis(): {}'.format(raxis))
		return raxis

def RotationAxis(m1, m2, anglethresh=_DEFAULT_KEEPING_ANGLE):
	return RotationalAxis(m1, m2, anglethresh)

def toLine3(x):
	if (is_line2(x)):
		line2 = x
		return line3([[line2.p0.x, line2.p0.y, 0.0], [line2.p1.x, line2.p1.y, 0.0]])
	elif (is_line2list(x)):
		linelist = line3list()
		for line2 in x:
			linelist.append(line3([[line2.p0.x, line2.p0.y, 0.0], [line2.p1.x, line2.p1.y, 0.0]]))
		return linelist
	else:
		_n.print_error('x: {0} ({1})'.format(x, type(x)))
		raise TypeError('__ERROR__: Illegal data type.')

def to_line3(x):
	return toLine3(x)

def toVec3(x):
	if (is_line2(x) or is_line2list(x)):
		return toLine3(x)
	else:
		return _ncs.toVec3(x)

def to_vec3(v2):
	return toVec3(v2)

def to_point3(v2):
	return toVec3(v2)

def toLine2(x):
	if (is_line3(x)):
		line3 = x
		if (not (is_ineps(line3.p0.z) and is_ineps(line3.p1.z))):
			raise Exception('__ERROR__: Z residue is too large.')
		return line2([[line3.p0.x, line3.p0.y], [line3.p1.x, line3.p1.y]])
	elif (is_line3list(x)):
		linelist = line2list()
		for line3 in x:
			if (not (is_ineps(line3.p0.z) and is_ineps(line3.p1.z))):
				raise Exception('__ERROR__: Z residue is too large.')
			linelist.append(line2([[line3.p0.x, line3.p0.y], [line3.p1.x, line3.p1.y]]))
		return linelist
	else:
		_n.print_error('x: {0} ({1})'.format(x, type(x)))
		raise TypeError('__ERROR__: Illegal data type.')

def to_line3(x):
	return toLine3(x)

def toVec3(x):
	if (is_line2(x) or is_line2list(x)):
		return toLine3(x)
	else:
		return _ncs.toVec3(x)

def to_vec3(v2):
	return toVec3(v2)

def to_point3(v2):
	return toVec3(v2)


#-- lib-test main

if (__name__ == '__main__'):
	from scipy.spatial.transform import Rotation as spr
	import quaternion
	from matplotlib import pyplot as plt

	_DEBUGLEVEL = 1

	_n.debuglevel(_DEBUGLEVEL)

	entireflag = False

	if (entireflag and True):
		print("\n-- line2")
		l = line2()
		l.print("line2")
		l = line2([[1.0, 2.0], [3.0, 4.0]])
		l.print("line2")
		l = line2([(5.0, 5.0), (7.0, 8.0)])
		l.print("line2")
		l = line2(((9.0, 10.0), (11.0, 12.0)))
		l.print("line2")
		for i in range(2):
			l.getPoint(i).print("point[{}]".format(i))

	if (entireflag and True):
		print("\n-- line2")
		for i in range(2):
			l.setPoint(i, _ncs.point2([10 + 2 * i, 10 + 2 * i + 1]))
		l.print("line2")
		for i in range(2):
			l.setPoint(i, (20 + 2 * i, 20 + 2 * i + 1))
		l.print("line2")
		for i in range(2):
			l.setPoint(i, [30 + 2 * i, 30 + 2 * i + 1])
		l.print("line2")

	if (entireflag and True):
		print("\n-- line3")
		l = line3()
		l.print("line3")
		l = line3([_ncs.point3([1.0, 2.0, 3.0]), _ncs.point3([4.0, 5.0, 6.0])])
		l.print("line3")
		l = line3([(1.0, 2.0, 3.0), (4.0, 5.0, 6.0)])
		l.print("line3")
		for i in range(2):
			l.getPoint(i).print("point[{}]".format(i))

	if (entireflag and True):
		print("\n-- line3")
		l = line3()
		for i in range(2):
			l.setPoint(i, (10 + 3 * i, 10 + 3 * i + 1, 10 + 3 * i + 2))
		l.print("line3")
		m = _ncs.mat3x3()
		r = spr.from_rotvec(np.array([0.0, np.pi / 2.0, np.pi / 3.0]))
		m.rotatelocal(r)
		m.print("rotational matrix")
		l2 = m @ l
		l2.print("line3 (rotated)")
		m2 = _ncs.mat3x4(m)
		m2.translate([1.0, 2.0, 3.0])
		m2.print("translational matrix")
		l2 = m2 @ l
		l2.print("line3 (translated)")

	if (entireflag and True):
		print("\n-- line from points")
		pts = _ncs.point3list([0.0, 0.0, 0.0])
		pts.append([1.0, 1.0, 0.0])
		pts.append([2.0, 2.0, 0.0])
		pts.print("points")
		l = line3()
		"""
		l.setByPoints(pts)
		l.setByPoints(pts, 3.0)
		l.setFromPoints(pts)
		l.setFromPoints(pts, 3.0)
		l.by_points = pts
		l.by_points = pts, 3.0
		l.from_points = pts
		"""
		l.from_points = pts, 3.0
		l.print("line (from points)")
		m = l.matrix
		m.print("line matrix")

	if (entireflag and True):
		print("\n-- plane")
		pl = plane()
		pl.print("plane")
		m = _ncs.mat3x4()
		r = spr.from_rotvec(np.array([0.0, np.pi / 2.0, np.pi / 3.0]))
		m.rotatelocal(r)
		m.translate([1.0, 2.0, 3.0])
		m.print("rotational matrix")
		pl2 = m @ pl
		pl2.print("plane (rotated)")

	if (entireflag and True):
		print("\n-- plane from points")
		pts = _ncs.point3list([0.0, 0.0, 0.0])
		pts.append([1.0, 2.0, 0.0])
		pts.append([3.0, 4.0, 0.0])
		pts.print("points")
		pl = plane()
		"""
		pl.setByPoints(pts)
		pl.setFromPoints(pts)
		pl.by_points = pts
		"""
		pl.from_points = pts
		pl.print("plane (from points)")
		m = pl.matrix
		m.print("plane matrix")
		pts_2 = pl << pts
		pts_2.print("points (projected)")

	if (entireflag and True):
		print("\n-- sphare")
		sph = sphare()
		sph.print("sphare")

	if (True):
		print("\n-- rotation axis")
		m1 = _ncs.mat3x4()
		m2 = copy.deepcopy(m1)
		
		"""
		m2.rotatex(_nm.deg2rad(60.0))
		m2.rotatey(_nm.deg2rad(60.0))
		m2.rotatez(_nm.deg2rad(60.0))
		"""
		rotangle = _nm.deg2rad(60.0)
		rotvec = _ncs.vec3([1.0, 3.0, 0.0])
		m2.rotate(spr.from_rotvec((rotangle * rotvec).components))
		
		m1.translate([20.0, 0.0, 0.0])
		m2.translate([20.0, 0.0, 0.0])
		m1.print('m1')
		m2.print('m2')
		raxis = RotationalAxis(m1, m2)
		if (raxis is None):
			print('No crosssection point was found..')
		else:
			raxis.print('rotation axis  ')
			rvec = raxis.vector
			rvec.print('rotational vector')
