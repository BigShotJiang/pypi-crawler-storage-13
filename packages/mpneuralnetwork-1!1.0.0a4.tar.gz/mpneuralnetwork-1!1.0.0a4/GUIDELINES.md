# Feuille de Route de mp-neural-network

Ce document liste les améliorations et fonctionnalités à implémenter, organisées par priorité.

---

## Priorité Critique

- [ ] **Bug `Reshape`**: Corriger la couche `Reshape` qui interprète incorrectement la dimension du `batch` (`(batch_size, ...features)`).

### Priorité Haute

- [x] **Inférence Automatique des Formes (Shape Inference)**: Permettre aux couches de déduire leur `input_shape` de la couche précédente. Le `input_shape` ne serait requis que pour la première couche du modèle.
- [ ] **Couche `Convolutional`**: Implémenter et optimiser la couche `Convolutional` en utilisant une approche vectorisée (ex: `im2col`).
- [ ] **Système de Callbacks**: Intégrer un système de `callbacks` dans `fit()`.
  - [ ] `ModelCheckpoint`: Pour sauvegarder le meilleur modèle.
  - [ ] `EarlyStopping` (Arrêt Précoce): Pour arrêter l'entraînement si une métrique stagne.
- [ ] **Ajout de Couches Essentielles**:
  - [ ] `Flatten`
  - [ ] `MaxPooling2D` / `AveragePooling2D`
  - [ ] `BatchNormalization`

### Priorité Moyenne

- [ ] **Métriques Modulaires**: Créer un module `metrics` configurable dans `compile()`.
- [ ] **Régularisation L1/L2**: Ajouter des arguments de régularisation (ex: `kernel_regularizer`) aux couches.
- [ ] **Sauvegarde/Chargement de Modèles**: Implémenter des méthodes pour la persistance des modèles.
- [ ] **Qualité du code**:
  - [x] **Linting**: Intégrer `ruff` dans le projet et en CI.
  - [ ] **Documentation**: Compléter les `docstrings` de toutes les API publiques.

### Terminé

- [x] **Fiabilisation des Tests**: Ajout de tests de forme et de gradient généralisés pour les couches, activations et fonctions de perte.
- [x] **Initialisation des Poids**: Une première version d'initialisation intelligente a été ajoutée.
