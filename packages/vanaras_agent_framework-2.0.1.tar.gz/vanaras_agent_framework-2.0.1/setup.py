from setuptools import setup, find_packages

setup(
    name="vanaras-agent-framework",
    version="2.0.1",  # patch release for pypi description
    description="A lightweight, local-first agent framework for programmatic code execution and orchestration.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Vanaras AI",
    packages=find_packages(),
    install_requires=[
        "requests>=2.31.0",
        "Flask>=3.0.0",
        "langchain-community>=0.0.10",
        "langchain-core>=0.1.10",
        "wikipedia>=1.4.0"
    ],
    entry_points={
        "console_scripts": [
            "vanaras=vanaras.cli.main:main",
            "vanaras-init=vanaras.cli.interactive:main",
        ],
    },
    include_package_data=True,
    python_requires=">=3.8",
)
