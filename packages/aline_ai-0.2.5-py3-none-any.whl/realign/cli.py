#!/usr/bin/env python3
"""ReAlign CLI - Main command-line interface."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console
from rich.syntax import Syntax

from .commands import init, search, show, config, commit, auto_commit, review, hide, push

app = typer.Typer(
    name="realign",
    help="Track and version AI agent chat sessions with git commits",
    add_completion=False,
)
console = Console()

# Register commands
app.command(name="init")(init.init_command)
app.command(name="search")(search.search_command)
app.command(name="show")(show.show_command)
app.command(name="config")(config.config_command)
app.command(name="commit")(commit.commit_command)
app.command(name="auto-commit")(auto_commit.auto_commit_command)


@app.command(name="review")
def review_cli(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed information"),
    detect_secrets: bool = typer.Option(False, "--detect-secrets", help="Detect sensitive content"),
):
    """Review unpushed commits with session summaries."""
    exit_code = review.review_command(verbose=verbose, detect_secrets=detect_secrets)
    raise typer.Exit(code=exit_code)


@app.command(name="hide")
def hide_cli(
    indices: str = typer.Argument(..., help="Commit indices to hide (e.g., '1,3,5-7' or '--all'), or 'reset' to undo last hide"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt"),
):
    """Hide (redact) specific commits before pushing, or reset to undo last hide."""
    if indices.lower() == "reset":
        exit_code = hide.hide_reset_command(force=force)
    else:
        exit_code = hide.hide_command(indices=indices, force=force)
    raise typer.Exit(code=exit_code)


@app.command(name="push")
def push_cli(
    remote: str = typer.Option("origin", "--remote", "-r", help="Git remote name"),
    branch: Optional[str] = typer.Option(None, "--branch", "-b", help="Branch to push (default: current branch)"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip all confirmation prompts"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be pushed without actually pushing"),
):
    """Interactive push workflow with review and hide options.

    This command provides an interactive workflow:
    1. Review unpushed commits
    2. Optionally hide sensitive commits
    3. Final confirmation before pushing
    """
    exit_code = push.push_command(
        remote=remote,
        branch=branch,
        force=force,
        dry_run=dry_run
    )
    raise typer.Exit(code=exit_code)


@app.command()
def version():
    """Show ReAlign version."""
    from . import __version__
    console.print(f"ReAlign version {__version__}")


if __name__ == "__main__":
    app()
