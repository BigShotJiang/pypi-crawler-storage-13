#!/usr/bin/env python3
"""
Push command - Interactive workflow for reviewing and pushing commits.

This command provides an interactive workflow:
1. Run aline review to show unpushed commits
2. Ask user if they want to hide any commits
3. If yes, allow interactive hiding
4. Ask for final confirmation before pushing
"""

import subprocess
import sys
from pathlib import Path
from typing import Optional

from .review import review_command, get_unpushed_commits
from .hide import hide_command, parse_commit_indices
from ..logging_config import setup_logger

logger = setup_logger('realign.commands.push', 'push.log')


def prompt_yes_no(question: str, default: bool = False) -> bool:
    """
    Prompt user for yes/no confirmation.

    Args:
        question: Question to ask
        default: Default answer if user just presses Enter

    Returns:
        True for yes, False for no
    """
    default_str = "Y/n" if default else "y/N"
    prompt = f"{question} [{default_str}] "

    while True:
        response = input(prompt).strip().lower()

        if not response:
            return default

        if response in ('y', 'yes'):
            return True
        elif response in ('n', 'no'):
            return False
        else:
            print("Please answer 'y' or 'n'")


def push_command(
    repo_root: Optional[Path] = None,
    remote: str = "origin",
    branch: Optional[str] = None,
    force: bool = False,
    dry_run: bool = False
) -> int:
    """
    Interactive push workflow with review and hide options.

    Workflow:
    1. Review unpushed commits
    2. Ask if user wants to hide any commits
    3. Interactive hiding loop (if requested)
    4. Final confirmation
    5. Execute git push

    Args:
        repo_root: Path to repository root (auto-detected if None)
        remote: Git remote name (default: origin)
        branch: Branch to push (default: current branch)
        force: Skip all confirmation prompts
        dry_run: Don't actually push, just show what would happen

    Returns:
        0 on success, 1 on error, 2 if cancelled by user
    """
    logger.info("======== Push command started ========")

    # Auto-detect repo root if not provided
    if repo_root is None:
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                capture_output=True,
                text=True,
                check=True
            )
            repo_root = Path(result.stdout.strip())
            logger.debug(f"Detected repo root: {repo_root}")
        except subprocess.CalledProcessError:
            print("Error: Not in a git repository", file=sys.stderr)
            logger.error("Not in a git repository")
            return 1

    # Detect current branch if not provided
    if branch is None:
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=repo_root,
                capture_output=True,
                text=True,
                check=True
            )
            branch = result.stdout.strip()
            logger.debug(f"Detected current branch: {branch}")
        except subprocess.CalledProcessError:
            print("Error: Failed to detect current branch", file=sys.stderr)
            logger.error("Failed to detect current branch")
            return 1

    # Step 1: Review unpushed commits
    print("\n" + "=" * 60)
    print("STEP 1: Review unpushed commits")
    print("=" * 60 + "\n")

    try:
        commits = get_unpushed_commits(repo_root)
    except Exception as e:
        print(f"Error: Failed to get unpushed commits: {e}", file=sys.stderr)
        logger.error(f"Failed to get unpushed commits: {e}", exc_info=True)
        return 1

    if not commits:
        print("✓ No unpushed commits found. Nothing to push.\n")
        logger.info("No unpushed commits found")
        return 0

    # Run review command to display commits
    exit_code = review_command(repo_root=repo_root, verbose=False, detect_secrets=False)
    if exit_code != 0:
        logger.error("Review command failed")
        return 1

    # Step 2: Ask if user wants to hide any commits
    if not force:
        print("\n" + "=" * 60)
        print("STEP 2: Hide sensitive commits (optional)")
        print("=" * 60 + "\n")

        want_to_hide = prompt_yes_no(
            "Do you want to hide any commits before pushing?",
            default=False
        )

        if want_to_hide:
            # Interactive hiding loop
            while True:
                print("\nEnter commit indices to hide (e.g., '1', '1,3,5', '2-4', or 'done'):")
                print("  Type 'done' when finished hiding commits")
                print("  Type 'review' to see the current list of commits")
                print("  Type 'cancel' to abort the push operation")

                user_input = input("\n> ").strip()

                if not user_input:
                    continue

                if user_input.lower() == 'done':
                    break
                elif user_input.lower() == 'cancel':
                    print("\n❌ Push cancelled by user.\n")
                    logger.info("Push cancelled by user during hide phase")
                    return 2
                elif user_input.lower() == 'review':
                    print("\n" + "-" * 60)
                    review_command(repo_root=repo_root, verbose=False, detect_secrets=False)
                    print("-" * 60)
                    continue

                # Try to parse and hide the commits
                try:
                    # Validate indices first
                    indices_list = parse_commit_indices(user_input)

                    # Refresh commit list
                    commits = get_unpushed_commits(repo_root)
                    if not commits:
                        print("\n✓ No more unpushed commits to hide.\n")
                        break

                    max_index = len(commits)
                    invalid_indices = [i for i in indices_list if i < 1 or i > max_index]
                    if invalid_indices:
                        print(f"❌ Invalid indices (out of range 1-{max_index}): {invalid_indices}")
                        continue

                    # Execute hide command
                    print()
                    exit_code = hide_command(
                        indices=user_input,
                        repo_root=repo_root,
                        force=False  # Always ask for confirmation
                    )

                    if exit_code == 0:
                        print("\n✅ Commits hidden successfully.\n")
                        logger.info(f"Successfully hidden commits: {user_input}")

                        # Refresh and show updated commit list
                        commits = get_unpushed_commits(repo_root)
                        if not commits:
                            print("✓ No more unpushed commits.\n")
                            logger.info("No commits left after hiding")
                            return 0
                        else:
                            print("\n📋 Updated commit list:\n")
                            review_command(repo_root=repo_root, verbose=False, detect_secrets=False)
                    else:
                        print(f"\n❌ Failed to hide commits.\n")
                        logger.error(f"Hide command failed for indices: {user_input}")

                        # Ask if user wants to continue
                        if not prompt_yes_no("Continue with push workflow?", default=True):
                            print("\n❌ Push cancelled.\n")
                            return 2

                except ValueError as e:
                    print(f"❌ Invalid input: {e}")
                    print("   Examples: '1', '1,3,5', '2-4'")
                    continue
                except Exception as e:
                    print(f"❌ Error during hide: {e}", file=sys.stderr)
                    logger.error(f"Error during hide: {e}", exc_info=True)

                    # Ask if user wants to continue
                    if not prompt_yes_no("Continue with push workflow?", default=True):
                        print("\n❌ Push cancelled.\n")
                        return 2

    # Step 3: Final confirmation
    if not force:
        print("\n" + "=" * 60)
        print("STEP 3: Final confirmation")
        print("=" * 60 + "\n")

        # Refresh commit list one more time
        try:
            commits = get_unpushed_commits(repo_root)
        except Exception as e:
            print(f"Error: Failed to refresh commits: {e}", file=sys.stderr)
            return 1

        if not commits:
            print("✓ No unpushed commits. Nothing to push.\n")
            return 0

        print(f"Ready to push {len(commits)} commit(s) to {remote}/{branch}\n")

        if not prompt_yes_no("Proceed with git push?", default=True):
            print("\n❌ Push cancelled by user.\n")
            logger.info("Push cancelled by user at final confirmation")
            return 2

    # Step 4: Execute git push
    print("\n" + "=" * 60)
    print("STEP 4: Pushing to remote")
    print("=" * 60 + "\n")

    if dry_run:
        print(f"🔍 DRY RUN: Would execute: git push {remote} {branch}\n")
        logger.info(f"Dry run: would push to {remote}/{branch}")
        return 0

    try:
        print(f"🚀 Pushing to {remote}/{branch}...")

        result = subprocess.run(
            ["git", "push", remote, branch],
            cwd=repo_root,
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            print("\n✅ Successfully pushed to remote!\n")
            print(result.stdout)
            logger.info(f"Successfully pushed to {remote}/{branch}")
            return 0
        else:
            print(f"\n❌ Push failed:\n{result.stderr}\n", file=sys.stderr)
            logger.error(f"Git push failed: {result.stderr}")
            return 1

    except Exception as e:
        print(f"\n❌ Error during push: {e}\n", file=sys.stderr)
        logger.error(f"Error during push: {e}", exc_info=True)
        return 1
