"""Shared helpers for working with session files recorded in commits."""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import List


def find_session_paths_for_commit(repo_root: Path, commit_hash: str) -> List[str]:
    """Return relative session file paths tracked in a given commit."""
    try:
        result = subprocess.run(
            ["git", "show", "--pretty=format:", "--name-only", commit_hash],
            capture_output=True,
            text=True,
            check=True,
            cwd=repo_root,
        )
    except subprocess.CalledProcessError:
        return []

    paths = []
    for line in result.stdout.splitlines():
        candidate = line.strip()
        if candidate.startswith(".realign/sessions/") and candidate.endswith(".jsonl"):
            paths.append(candidate)
    return paths
