"""
PATX: Pattern eXtraction for time series data using B-splines.

This package provides tools for extracting B-spline patterns from time series data
using hyperparameter optimization with Hyperopt.
"""

from .core import feature_extraction, save_patterns, load_patterns, visualize_patterns
from .models import LightGBMModelWrapper

__version__ = "0.4.4"
__all__ = ["feature_extraction", "LightGBMModelWrapper", "save_patterns", "load_patterns", "visualize_patterns"]
