import numpy as np
from sklearn.model_selection import train_test_split, KFold
import optuna
from scipy.interpolate import BSpline
from sklearn.metrics import accuracy_score, roc_auc_score, mean_squared_error
from .models import LightGBMModelWrapper
from numba import njit
from scipy import fft
import pywt
import warnings
import json
import os
import matplotlib.pyplot as plt

try:
    from optuna._experimental import ExperimentalWarning
    warnings.filterwarnings('ignore', category=ExperimentalWarning)
except ImportError:
    warnings.filterwarnings('ignore', message='.*experimental.*')
warnings.filterwarnings('ignore', message='.*Level value of.*is too high.*')
warnings.filterwarnings('ignore', message='.*does not have valid feature names.*')

def generate_bspline_pattern(control_points, width, data_min, data_max):
    n_cp, degree = len(control_points), min(3, len(control_points) - 1)
    knots = np.concatenate([np.zeros(degree + 1), np.linspace(0, 1, n_cp - degree + 1)[1:-1], np.ones(degree + 1)])
    width_int = int(round(width))
    return data_min + BSpline(knots, np.asarray(control_points), degree)(np.linspace(0, 1, width_int)) * (data_max - data_min)

def apply_transformation(data, transform_type):
    if transform_type == 'derivative': result = np.gradient(data, axis=-1)
    elif transform_type == 'cumsum': result = np.cumsum(data, axis=-1)
    elif transform_type == 'fft_power': result = fft_power_transform(data)
    elif transform_type == 'wavelet': result = wavelet_transform(data)
    else: result = data
    return result

def fft_power_transform(data):
    fft_coeffs = fft.fft(data, axis=-1)
    power_spectrum = np.abs(fft_coeffs) ** 2
    ifft_result = np.real(fft.ifft(power_spectrum, axis=-1))
    return ifft_result

def wavelet_transform(data):
    result = np.zeros_like(data)
    n_samples, n_series, n_time = data.shape
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message='.*Level value of.*is too high.*')
        for s in range(n_samples):
            for ser in range(n_series):
                series = data[s, ser, :]
                coeffs = pywt.wavedec(series, 'db4', level=3, mode='periodization')
                concatenated = np.concatenate(coeffs)
                result[s, ser, :] = np.interp(np.linspace(0, 1, n_time), np.linspace(0, 1, len(concatenated)), concatenated) if len(concatenated) != n_time else concatenated
    return result

@njit(fastmath=True)
def calculate_best_distance(series_data, pattern, pattern_width, pattern_start, use_relative, shift_tolerance, max_shift_evaluations):
    n_samples, n_time = series_data.shape
    pattern_width_int = int(pattern_width)
    
    # Calculate shift parameters
    max_shift = min(int(shift_tolerance * n_time), n_time - pattern_width_int)
    n_evaluations = min(max_shift_evaluations, 2 * max_shift + 1)
    stride = max(1, (2 * max_shift) // (n_evaluations - 1)) if n_evaluations > 1 else 1
    
    distances = np.full(n_samples, np.inf)
    
    for i in range(n_samples):
        best_dist = np.inf
        
        for k in range(n_evaluations):
            shift = -max_shift + k * stride
            current_start = pattern_start + shift
            
            if current_start < 0 or current_start + pattern_width_int > n_time:
                continue
                
            series_seg = series_data[i, current_start:current_start + pattern_width_int]
            
            if use_relative:
                series_min, series_max = series_seg.min(), series_seg.max()
                pattern_min, pattern_max = pattern.min(), pattern.max()
                series_range = series_max - series_min
                pattern_range = pattern_max - pattern_min
                
                sum_sq_diff = 0.0
                for j in range(pattern_width_int):
                    norm_series = (series_seg[j] - series_min) / series_range if series_range > 1e-9 else 0.5
                    norm_pattern = (pattern[j] - pattern_min) / pattern_range if pattern_range > 1e-9 else 0.5
                    diff = norm_series - norm_pattern
                    sum_sq_diff += diff * diff
                dist = np.sqrt(sum_sq_diff / pattern_width)
            else:
                sum_sq_diff = 0.0
                for j in range(pattern_width_int):
                    diff = series_seg[j] - pattern[j]
                    sum_sq_diff += diff * diff
                dist = np.sqrt(sum_sq_diff / pattern_width)
                
            if dist < best_dist:
                best_dist = dist
                
        distances[i] = best_dist
        
    return distances

def evaluate_model_performance(model, metric, cached_data):
    X_train, X_val, y_train_split, y_val = cached_data
    model = model.clone()
    model.fit(X_train, y_train_split, X_val, y_val)
    if metric == 'accuracy': return accuracy_score(y_val, model.predict(X_val))
    if metric == 'rmse': return np.sqrt(mean_squared_error(y_val, model.predict(X_val)))
    y_pred = model.predict_proba(X_val)
    return roc_auc_score(y_val, y_pred) if len(np.unique(y_val)) == 2 else roc_auc_score(y_val, y_pred, multi_class='ovr', average='macro')

def feature_extraction(input_series_train, y_train, input_series_test=None, initial_features=None, model=None, metric='auc', val_size=0.2, n_trials=1000, n_control_points=5, show_progress=True, max_shift_evaluations=50, patience=2, subsample_size=2000, n_startup_trials=500, n_workers=10, inner_k_folds=3, shift_tolerance=None):
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    
    # Handle list inputs
    if isinstance(input_series_train, list):
        input_series_train = np.stack([x.values if hasattr(x, 'values') else x for x in input_series_train], axis=1)
    if isinstance(input_series_test, list):
        input_series_test = np.stack([x.values if hasattr(x, 'values') else x for x in input_series_test], axis=1)
    
    # Convert pandas DataFrames to numpy arrays
    if hasattr(input_series_train, 'values'):
        input_series_train = input_series_train.values
    if input_series_test is not None and hasattr(input_series_test, 'values'):
        input_series_test = input_series_test.values
        
    # Handle 2D inputs (samples, time) -> (samples, 1, time)
    if input_series_train.ndim == 2:
        input_series_train = input_series_train[:, np.newaxis, :]
    if input_series_test is not None and input_series_test.ndim == 2:
        input_series_test = input_series_test[:, np.newaxis, :]
        
    n_input_series, n_time_points = input_series_train.shape[1], input_series_train.shape[2]
    data_min, data_max = input_series_train.min(), input_series_train.max()
    
    # Precompute transformations
    transform_types = ['raw', 'derivative', 'cumsum', 'fft_power', 'wavelet']
    transformed_train = {t: apply_transformation(input_series_train, t) for t in transform_types}
    
    # Prepare targets
    y_train = np.asarray(y_train).flatten()
    if metric != 'rmse':
        unique_targets = np.unique(y_train)
        if len(unique_targets) > 2 and not np.array_equal(unique_targets, np.arange(len(unique_targets))):
            y_train = np.array([{v: i for i, v in enumerate(unique_targets)}[y] for y in y_train])
        elif len(unique_targets) == 2 and not np.array_equal(unique_targets, [0, 1]):
            y_train = (y_train == unique_targets[1]).astype(int)
            
    model_type = 'regression' if metric == 'rmse' else 'classification'
    n_classes = len(np.unique(y_train)) if model_type == 'classification' and len(np.unique(y_train)) > 2 else 2
    model = model or LightGBMModelWrapper(model_type, n_classes=n_classes)
    
    # Setup validation folds
    kf = KFold(n_splits=inner_k_folds, shuffle=True, random_state=42)
    fold_indices = list(kf.split(np.arange(len(y_train))))
    
    model_features_list = [initial_features[0]] if initial_features else []
    extracted_patterns = []
    best_score = float('inf') if metric == 'rmse' else -float('inf')
    no_improve_count = 0
    
    while True:
        # Prepare base features for current round
        base_X_folds = []
        for fold_train_idx, fold_val_idx in fold_indices:
            base_X_train = np.column_stack([f[fold_train_idx] for f in model_features_list]) if model_features_list else np.empty((len(fold_train_idx), 0))
            base_X_val = np.column_stack([f[fold_val_idx] for f in model_features_list]) if model_features_list else np.empty((len(fold_val_idx), 0))
            base_X_folds.append((base_X_train, base_X_val, fold_train_idx, fold_val_idx))
            
        # Subsampling for optimization
        train_indices = np.arange(len(y_train))
        if subsample_size and len(y_train) > subsample_size:
            subsample_idx = np.random.choice(len(y_train), subsample_size, replace=False)
            # Map subsample to folds? Simpler: just use subsample for objective and full for final eval
            # But we need fold structure for robust evaluation. 
            # Let's subsample the *folds* inside objective or just pass subsample indices.
            # Better: Create subsampled fold structures once per round for the objective
            sub_kf = KFold(n_splits=inner_k_folds, shuffle=True, random_state=42)
            sub_fold_indices = list(sub_kf.split(np.arange(len(subsample_idx))))
            
            # We need to map subsample_idx back to original indices to get features
            # But features are already computed.
            # Let's create a subsampled version of everything for the objective
            sub_transformed = {k: v[subsample_idx] for k, v in transformed_train.items()}
            sub_y = y_train[subsample_idx]
            sub_base_X_folds = []
            
            # We need base features for subsample
            if model_features_list:
                sub_base_feats = [f[subsample_idx] for f in model_features_list]
                
            for tr_i, val_i in sub_fold_indices:
                if model_features_list:
                    sub_X_tr = np.column_stack([f[tr_i] for f in sub_base_feats])
                    sub_X_val = np.column_stack([f[val_i] for f in sub_base_feats])
                else:
                    sub_X_tr, sub_X_val = np.empty((len(tr_i), 0)), np.empty((len(val_i), 0))
                sub_base_X_folds.append((sub_X_tr, sub_X_val, tr_i, val_i, sub_y[tr_i], sub_y[val_i]))
        else:
            # Use full data
            sub_transformed = transformed_train
            sub_base_X_folds = []
            for tr_i, val_i, in fold_indices:
                sub_base_X_folds.append((base_X_folds[0][0], base_X_folds[0][1], tr_i, val_i, y_train[tr_i], y_train[val_i]))
                # Wait, the loop above for base_X_folds computes folds correctly.
            # Redo full folds packing
            sub_base_X_folds = []
            for i, (bx_tr, bx_val, tr_i, val_i) in enumerate(base_X_folds):
                sub_base_X_folds.append((bx_tr, bx_val, tr_i, val_i, y_train[tr_i], y_train[val_i]))

        def objective(trial):
            series_idx = trial.suggest_int('series_index', 0, n_input_series - 1)
            transform_type = trial.suggest_categorical('transform_type', transform_types)
            use_relative = trial.suggest_categorical('use_relative', [False, True])
            
            if shift_tolerance is not None:
                # If float <= 1.0, treat as ratio. If > 1.0, treat as steps and convert to ratio.
                if isinstance(shift_tolerance, int) or shift_tolerance > 1.0:
                    shift_tol_val = shift_tolerance / n_time_points
                else:
                    shift_tol_val = shift_tolerance
            else:
                shift_tol_val = trial.suggest_float('shift_tolerance', 0.0, 1.0)
                
            cps = [trial.suggest_float(f'cp{i}', 0, 1) for i in range(n_control_points)]
            pattern_center = trial.suggest_int('pattern_center', 0, n_time_points - 1)
            pattern_width = trial.suggest_float('pattern_width', 2.0, min(50.0, n_time_points))
            
            start = max(0, int(pattern_center - pattern_width // 2))
            pattern = generate_bspline_pattern(tuple(cps), pattern_width, data_min, data_max)
            
            # Calculate features for ALL subsampled data
            full_feat = calculate_best_distance(
                sub_transformed[transform_type][:, series_idx, :], 
                pattern, pattern_width, start, use_relative, shift_tol_val, max_shift_evaluations
            )
            
            scores = []
            for base_X_tr, base_X_val, tr_idx, val_idx, y_tr, y_val in sub_base_X_folds:
                train_feat = full_feat[tr_idx]
                val_feat = full_feat[val_idx]
                X_train_fold = np.column_stack([base_X_tr, train_feat]) if base_X_tr.size > 0 else train_feat.reshape(-1, 1)
                X_val_fold = np.column_stack([base_X_val, val_feat]) if base_X_val.size > 0 else val_feat.reshape(-1, 1)
                scores.append(evaluate_model_performance(model, metric, (X_train_fold, X_val_fold, y_tr, y_val)))
            return np.mean(scores)

        study = optuna.create_study(
            direction='minimize' if metric == 'rmse' else 'maximize', 
            sampler=optuna.samplers.TPESampler(multivariate=True, group=True, n_startup_trials=n_startup_trials, constant_liar=True, n_ei_candidates=12)
        )
        study.optimize(objective, n_trials=n_trials, show_progress_bar=show_progress, n_jobs=n_workers)
        
        score = study.best_trial.value
        improved = (score < best_score) if metric == 'rmse' else (score > best_score)
        
        if improved:
            best_score = score
            no_improve_count = 0
        else:
            no_improve_count += 1
            if no_improve_count >= patience:
                break
        
        params = study.best_trial.params
        cps = [params[f'cp{i}'] for i in range(n_control_points)]
        width = params['pattern_width']
        center = params['pattern_center']
        start = max(0, int(center - width // 2))
        series_idx = params.get('series_index', 0)
        transform_type = params.get('transform_type', 'raw')
        use_relative = params.get('use_relative', False)
        
        if shift_tolerance is not None:
            if isinstance(shift_tolerance, int) or shift_tolerance > 1.0:
                shift_tol = shift_tolerance / n_time_points
            else:
                shift_tol = shift_tolerance
        else:
            shift_tol = params.get('shift_tolerance', 0)
        
        pattern_array = generate_bspline_pattern(tuple(cps), width, data_min, data_max)
        
        # Calculate final features on FULL dataset
        new_features = calculate_best_distance(
            transformed_train[transform_type][:, series_idx, :],
            pattern_array, width, start, use_relative, shift_tol, max_shift_evaluations
        )
        
        extracted_patterns.append({
            'pattern': pattern_array, 'start': start, 'width': width, 'center': center,
            'series_idx': series_idx, 'control_points': cps, 'transform_type': transform_type,
            'use_relative': use_relative, 'shift_tolerance': shift_tol, 'score': score,
            'n_time_points': n_time_points
        })
        model_features_list.append(new_features)
        
        print(f"Pattern {len(extracted_patterns)}: {metric}={score:.4f} (Improved: {improved})")

    # Final Model Training
    model_features = np.column_stack(model_features_list) if model_features_list else np.empty((len(y_train), 0))
    train_idx, val_idx = train_test_split(np.arange(len(y_train)), test_size=val_size, random_state=42)
    model.fit(model_features[train_idx], y_train[train_idx], model_features[val_idx], y_train[val_idx])
    
    test_features = None
    if input_series_test is not None:
        transformed_test = {t: apply_transformation(input_series_test, t) for t in transform_types}
        test_feats = []
        for p in extracted_patterns:
            feat = calculate_best_distance(
                transformed_test[p['transform_type']][:, p['series_idx'], :],
                p['pattern'], p['width'], p['start'], p['use_relative'], p['shift_tolerance'], max_shift_evaluations
            )
            test_feats.append(feat)
        
        all_test_feats = ([initial_features[1]] if initial_features else []) + test_feats
        test_features = np.column_stack(all_test_feats) if all_test_feats else np.empty((len(input_series_test), 0))
        
    return {'patterns': extracted_patterns, 'train_features': model_features, 'test_features': test_features, 'model': model}

def save_patterns(patterns, filename):
    class NumpyEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            return json.JSONEncoder.default(self, obj)
    
    with open(filename, 'w') as f:
        json.dump(patterns, f, cls=NumpyEncoder)

def load_patterns(filename):
    with open(filename, 'r') as f:
        patterns = json.load(f)
    
    # Convert lists back to numpy arrays where needed
    for p in patterns:
        p['pattern'] = np.array(p['pattern'])
        # control_points is usually kept as list, but good to be consistent if needed
    return patterns

def visualize_patterns(patterns, indices=None, save_path=None, show=True):
    if indices is None:
        indices = range(len(patterns))
    elif isinstance(indices, int):
        indices = [indices]
        
    n_patterns = len(indices)
    cols = min(3, n_patterns)
    rows = (n_patterns + cols - 1) // cols
    
    fig, axes = plt.subplots(rows, cols, figsize=(5*cols, 4*rows))
    if n_patterns == 1:
        axes = [axes]
    axes = np.array(axes).flatten()
    
    for i, idx in enumerate(indices):
        if idx >= len(patterns): continue
        p = patterns[idx]
        ax = axes[i]
        
        # Get pattern parameters
        pattern = p['pattern']
        start = p.get('start', 0)
        width = p.get('width', len(pattern))
        center = p.get('center', start + width // 2)
        shift_tol = p.get('shift_tolerance', 0)
        n_time_points = p.get('n_time_points', len(pattern))
        
        # Calculate search space
        # shift_tolerance is a ratio, convert to steps
        if shift_tol > 1.0:
            shift_steps = int(shift_tol)
        else:
            shift_steps = int(shift_tol * n_time_points)
        
        search_start = max(0, start - shift_steps)
        search_end = min(n_time_points, start + int(width) + shift_steps)
        pattern_center_pos = center
        
        # Create full-length array (placeholder for visualization)
        full_data = np.zeros(n_time_points)
        
        # Place pattern centered at pattern_center_pos
        pattern_len = len(pattern)
        pattern_half = pattern_len // 2
        pattern_start_in_full = max(0, pattern_center_pos - pattern_half)
        pattern_end_in_full = min(n_time_points, pattern_start_in_full + pattern_len)
        
        # Calculate which part of pattern to use
        # If pattern center is before start, we skip some initial pattern points
        pattern_offset = max(0, pattern_half - pattern_center_pos)
        # Actual length we can place
        actual_slice_len = pattern_end_in_full - pattern_start_in_full
        # Ensure we don't exceed pattern length
        pattern_slice_end = min(pattern_len, pattern_offset + actual_slice_len)
        # Adjust actual_slice_len to match what we can take from pattern
        actual_slice_len = pattern_slice_end - pattern_offset
        
        # Place pattern in the full array
        pattern_in_full = np.zeros(n_time_points)
        if actual_slice_len > 0 and pattern_offset < pattern_len:
            pattern_in_full[pattern_start_in_full:pattern_start_in_full + actual_slice_len] = pattern[pattern_offset:pattern_slice_end]
        
        # Plot full data length (baseline)
        x_full = np.arange(n_time_points)
        ax.plot(x_full, full_data, 'k-', alpha=0.1, linewidth=1, label='Full data length')
        
        # Highlight search space
        ax.axvspan(search_start, search_end, alpha=0.2, color='yellow', label='Search space')
        
        # Plot pattern centered in search space
        pattern_plot_end = pattern_start_in_full + actual_slice_len
        pattern_x = np.arange(pattern_start_in_full, pattern_plot_end)
        pattern_y = pattern_in_full[pattern_start_in_full:pattern_plot_end]
        ax.plot(pattern_x, pattern_y, 'r-', linewidth=2.5, label='Pattern')
        
        # Mark pattern center
        ax.axvline(pattern_center_pos, color='red', linestyle='--', alpha=0.5, linewidth=1)
        
        ax.set_xlim(0, n_time_points)
        ax.set_xlabel('Time Point')
        ax.set_ylabel('Value')
        ax.set_title(f"Pattern {idx}\nScore: {p.get('score', 'N/A'):.4f}")
        ax.grid(True, alpha=0.3)
        ax.legend(loc='upper right', fontsize=8)
        
        # Add details
        details = (f"Series: {p.get('series_idx', 0)}\n"
                  f"Width: {width:.1f}\n"
                  f"Center: {pattern_center_pos}\n"
                  f"Search: [{search_start}, {search_end}]\n"
                  f"Trans: {p.get('transform_type', 'raw')}")
        ax.text(0.02, 0.98, details, transform=ax.transAxes, 
                verticalalignment='top', fontsize=8,
                bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
    # Hide unused subplots
    for i in range(n_patterns, len(axes)):
        axes[i].axis('off')
        
    plt.tight_layout()
    
    if save_path:
        dir_path = os.path.dirname(save_path)
        if dir_path:
            os.makedirs(dir_path, exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
    if show:
        plt.show()
    else:
        plt.close(fig)
