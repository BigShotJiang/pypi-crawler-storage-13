# PatX - Pattern eXtraction for Time Series and Spatial Data

[![PyPI version](https://badge.fury.io/py/patx.svg)](https://badge.fury.io/py/patx)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

PatX is a Python package for **interpretable feature engineering** on time series and spatial data. It extracts B-spline patterns that characterize classes or regression targets, using Optuna to automatically find the most predictive shapes.

Unlike "black box" deep learning models, PatX discovers specific, visualizable patterns in your data (e.g., "a sharp rise followed by a plateau" or "a specific peak in histone modification") that drive predictions.

**Why PatX?**
- **Interpretability**: See exactly what shapes in your data matter.
- **Shift Invariance**: Finds patterns even if they occur slightly earlier or later (or spatially shifted).
- **Automation**: No need to manually design features like "peak height" or "slope". PatX learns them.
- **Flexibility**: Works with raw data, derivatives, FFT, and Wavelets automatically.

## Use Cases

PatX is designed for "wide" datasets (many samples, fixed length) where the *shape* of the signal determines the outcome.

- **Genomics / Epigenomics**: Identify specific histone modification profiles or spatial chromatin patterns.
- **Medical Diagnostics**: Identify specific heartbeat anomalies (ECG) or EEG patterns.
- **Industrial Monitoring**: Detect "warning signatures" in sensor data.
- **Financial Analysis**: Find predictive price action shapes.

## Installation

```bash
pip install patx
```

## Data Preprocessing & Requirements

PatX expects data in a **matrix format**:

- **Shape**: `(n_samples, n_time_points)` or `(n_samples, n_channels, n_time_points)`
- **Values**: Continuous numerical data (float).
- **Missing Values**: Data should be imputed before passing to PatX.
- **Normalization**: PatX handles internal scaling. **Normalization is not necessary**, but providing clean, consistent data improves results.

## Quick Start

Run the included test suite or follow the examples below which mirror the package tests.

### 1. Classification with Pandas DataFrames

```python
import numpy as np
import pandas as pd
from patx import feature_extraction
from patx.data import load_remc_data
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score

# Load included REMC epigenomics dataset
remc = load_remc_data(series=("H3K4me3", "H3K4me1"))
input_series = remc['X_list']
y = remc['y']

# Split data
idx = np.arange(len(y))
train_idx, test_idx = train_test_split(idx, test_size=0.2, random_state=42, stratify=y)
y_train, y_test = y[train_idx], y[test_idx]

# Prepare input as list of DataFrames (one per channel)
input_series_train = [pd.DataFrame(X[train_idx]) for X in input_series]
input_series_test = [pd.DataFrame(X[test_idx]) for X in input_series]

# Extract patterns
result = feature_extraction(
    input_series_train=input_series_train, 
    y_train=y_train, 
    input_series_test=input_series_test, 
    n_trials=50, 
    show_progress=True
)

# Evaluate
probs = result['model'].predict_proba(result['test_features'])
auc = roc_auc_score(y_test, probs)
print(f"AUC: {auc:.4f}")
print(f"Found {len(result['patterns'])} patterns")
```

### 2. Classification with NumPy Arrays

PatX accepts NumPy arrays directly.

```python
# Prepare input as list of NumPy arrays
input_series_train_numpy = [X[train_idx] for X in input_series]
input_series_test_numpy = [X[test_idx] for X in input_series]

result_numpy = feature_extraction(
    input_series_train=input_series_train_numpy, 
    y_train=y_train, 
    input_series_test=input_series_test_numpy, 
    n_trials=100, 
    show_progress=True
)
```

### 3. Regression Tasks

PatX automatically handles regression if `metric='rmse'` or if the target is continuous.

```python
# Create a synthetic regression target
y_regression = y.astype(float) + np.random.normal(0, 0.3, len(y))
y_train_reg = y_regression[train_idx]

result_reg = feature_extraction(
    input_series_train=input_series_train, 
    y_train=y_train_reg, 
    input_series_test=input_series_test, 
    metric='rmse',
    n_trials=50
)
```

### 4. Using Initial Features

You can combine extracted pattern features with existing static features (e.g., global mean/std).

```python
# Create simple initial features
initial_features_train = np.column_stack([X[train_idx].mean(axis=1) for X in input_series])
initial_features_test = np.column_stack([X[test_idx].mean(axis=1) for X in input_series])

result_init = feature_extraction(
    input_series_train=input_series_train, 
    y_train=y_train, 
    input_series_test=input_series_test,
    initial_features=(initial_features_train, initial_features_test),
    n_trials=100
)
```

### 5. Visualization and Saving Patterns

You can save extracted patterns to JSON and visualize them.

```python
from patx import save_patterns, load_patterns, visualize_patterns

# Save patterns
save_patterns(result['patterns'], 'patterns.json')

# Load and visualize
loaded_patterns = load_patterns('patterns.json')
visualize_patterns(loaded_patterns, show=True)
```

## API Reference

### `feature_extraction`

```python
def feature_extraction(
    input_series_train, 
    y_train, 
    input_series_test=None, 
    initial_features=None, 
    model=None, 
    metric='auc', 
    val_size=0.2, 
    n_trials=1000, 
    n_control_points=5, 
    show_progress=True, 
    max_shift_evaluations=50, 
    patience=2, 
    subsample_size=2000, 
    n_startup_trials=500, 
    n_workers=10, 
    inner_k_folds=3,
    shift_tolerance=None
)
```

**Parameters:**
- `input_series_train`: Training data. DataFrame, array, or list of them.
- `y_train`: Target labels or values.
- `input_series_test`: (Optional) Test data.
- `initial_features`: (Optional) Tuple of `(train_features, test_features)` to include before pattern search.
- `model`: (Optional) Custom estimator. Defaults to LightGBM.
- `metric`: Optimization metric (`'auc'`, `'accuracy'`, `'rmse'`).
- `n_trials`: Max number of patterns to test (default: 1000).
- `shift_tolerance`: (Optional) Allowed pattern shift. If `None` (default), it is optimized per pattern. If set (e.g. `2` or `0.05`), it fixes the tolerance.
- `patience`: Stop if no improvement after this many successful pattern additions.

**Returns:** `dict` containing:
- `patterns`: List of found pattern dictionaries.
- `train_features`: Final feature matrix for training set.
- `test_features`: Final feature matrix for test set.
- `model`: The fitted model.

### Helper Functions

- `save_patterns(patterns, filename)`: Save extracted patterns list to a JSON file.
- `load_patterns(filename)`: Load patterns list from a JSON file.
- `visualize_patterns(patterns, indices=None, save_path=None, show=True)`: Plot patterns using matplotlib.

## Citation

If you use PatX in your research, please cite:

```bibtex
@software{patx,
  title={PatX: Pattern eXtraction for Time Series and Spatial Data},
  author={Wolber, J.},
  year={2025},
  url={https://github.com/Prgrmmrjns/patX}
}
```
