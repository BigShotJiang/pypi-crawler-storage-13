from setuptools import setup, find_packages

setup(
    name="Procaptcha",
    version="1.1.0",
    packages=find_packages(),
    install_requires=["Pillow"],
    description="Custom captcha generator with distortion, multiple fonts, token verification and easy Flask integration",
    author="maksalmaz",
    python_requires=">=3.7",
)