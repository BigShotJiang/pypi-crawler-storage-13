from PIL import Image
import math
import random

def wave_distortion(image, amplitude=5, wavelength=30):
    width, height = image.size
    src = image.load()
    dest = Image.new("RGB", (width, height), (255, 255, 255))
    dst = dest.load()
    for x in range(width):
        for y in range(height):
            offset = int(amplitude * math.sin(2 * math.pi * y / wavelength))
            sx = x + offset
            if 0 <= sx < width:
                dst[x, y] = src[sx, y]
            else:
                dst[x, y] = (255, 255, 255)
    return dest

def shear_distortion(image, magnitude=8):
    width, height = image.size
    src = image.load()
    dest = Image.new("RGB", (width, height), (255, 255, 255))
    dst = dest.load()
    for x in range(width):
        shift = int(magnitude * math.sin(2 * math.pi * x / (width / 2 + 1)))
        for y in range(height):
            sy = y + shift
            if 0 <= sy < height:
                dst[x, y] = src[x, sy]
            else:
                dst[x, y] = (255, 255, 255)
    return dest