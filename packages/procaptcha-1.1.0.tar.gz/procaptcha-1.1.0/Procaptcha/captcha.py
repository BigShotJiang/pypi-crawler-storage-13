import os
import random
import string
import time
import uuid
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from .distort import wave_distortion, shear_distortion
from .config import CAPTCHA_FOLDER

class Captcha:
    def __init__(self, length=5, width=200, height=80, fonts=None, ttl=300):
        self.length = length
        self.width = width
        self.height = height
        self.fonts = fonts or []
        self.ttl = ttl
        self._store = {}

    def _now(self):
        return int(time.time())

    def _cleanup(self):
        now = self._now()
        keys = [k for k, v in self._store.items() if v[1] < now]
        for k in keys:
            try:
                os.remove(self._store[k][2])
            except:
                pass
            del self._store[k]

    def _random_code(self):
        chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return "".join(random.choice(chars) for _ in range(self.length))

    def _load_font(self, size):
        for path in self.fonts:
            try:
                return ImageFont.truetype(path, size)
            except:
                continue
        try:
            return ImageFont.truetype("arial.ttf", size)
        except:
            return ImageFont.load_default()

    def generate(self, save_as=None, return_code=False):
        self._cleanup()
        code = self._random_code()
        img = Image.new("RGB", (self.width, self.height), (255, 255, 255))
        draw = ImageDraw.Draw(img)
        font = self._load_font(int(self.height * 0.55))

        for _ in range(int(self.width * self.height * 0.02)):
            draw.point((random.randint(0, self.width), random.randint(0, self.height)),
                       fill=(random.randint(100, 255),) * 3)

        for _ in range(6):
            draw.line((random.randint(0, self.width), random.randint(0, self.height),
                       random.randint(0, self.width), random.randint(0, self.height)),
                      fill=(random.randint(0, 200), random.randint(0, 200), random.randint(0, 200)),
                      width=random.randint(1, 3))

        x = 10
        for ch in code:
            angle = random.randint(-30, 30)
            char_img = Image.new("RGBA", (self.width, self.height), (255, 255, 255, 0))
            char_draw = ImageDraw.Draw(char_img)
            char_draw.text((0, 0), ch, font=font, fill=(0, 0, 0))
            char_img = char_img.rotate(angle, resample=Image.BICUBIC, expand=1)
            pw, ph = char_img.size
            img.paste(Image.new("RGB", (pw, ph), (255, 255, 255)), (x, int((self.height - ph) / 2)))
            img.paste(char_img.convert("RGB"), (x, int((self.height - ph) / 2)), char_img)
            x += int(self.width / (self.length + 1))

        img = wave_distortion(img, amplitude=random.randint(4, 8), wavelength=random.randint(30, 60))
        img = shear_distortion(img, magnitude=random.randint(3, 8))
        img = img.filter(ImageFilter.GaussianBlur(0.5))

        if save_as:
            filename = save_as
        else:
            filename = f"{uuid.uuid4().hex}.png"
        full_path = os.path.join(CAPTCHA_FOLDER, filename)
        img.save(full_path)

        token = uuid.uuid4().hex
        expiry = self._now() + self.ttl
        self._store[token] = (code, expiry, full_path)
        result = (full_path, token)
        if return_code:
            return full_path, token, code
        return result

    def verify(self, token, user_text):
        self._cleanup()
        entry = self._store.get(token)
        if not entry:
            return False
        code, expiry, path = entry
        ok = str(user_text).strip().upper() == code.upper()
        try:
            os.remove(path)
        except:
            pass
        del self._store[token]
        return ok

    def path_for(self, token):
        entry = self._store.get(token)
        if not entry:
            return None
        return entry[2]