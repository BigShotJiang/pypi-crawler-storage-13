import os
BASE_PATH = os.path.dirname(os.path.abspath(__file__))
CAPTCHA_FOLDER = os.path.join(BASE_PATH, "captchas")
os.makedirs(CAPTCHA_FOLDER, exist_ok=True)