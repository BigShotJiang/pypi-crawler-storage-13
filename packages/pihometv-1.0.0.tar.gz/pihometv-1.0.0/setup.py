from setuptools import setup, find_packages

setup(
    name="pihometv",
    version="1.0.0",
    author="Egorps",
    description="Library for RPi Home TV Shield",
    packages=find_packages(),
    install_requires=[
        "opencv-python",
        "Pillow",
        "RPi.GPIO"
    ],
    python_requires=">=3.6",
    platforms=["Linux"],
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Topic :: Multimedia :: Graphics",
        "Topic :: System :: Hardware"
    ]
)