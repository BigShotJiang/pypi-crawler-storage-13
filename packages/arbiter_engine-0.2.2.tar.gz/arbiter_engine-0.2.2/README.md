# ARBITER

**Every other AI guesses. ARBITER knows.**  
The only semantic reasoning primitive that gives the same answer twice.  
**26 MB. Deterministic. Forever.**

```
pip install arbiter-engine
```

---

## What It Does

ARBITER measures **geometric coherence** between a query and candidates.  
Not similarity. Not probability.  
**Coherence — how well something fits the constraint field.**

```python
from arbiter_engine import rank

r = rank(
    "Optimize lead compound for selective COX-2 inhibition. "
    "Issues: GI toxicity from COX-1 cross-reactivity, short half-life, poor solubility",
    [
        "Replace carboxylic acid with sulfonamide",
        "Convert to prodrug ester",
        "Add polar morpholine ring",
        "Add fluorine substituent",
        "Introduce methoxy group"
    ]
)

print(r.top)
# Ranked(text='Replace carboxylic acid with sulfonamide', score=0.539)
```

That sulfonamide modification became **Celebrex** — a $3B/year drug.  
Zero pharmaceutical training.  
Same score every time.

---

## Installation

```
pip install arbiter-engine
```

---

## Python Usage

```python
from arbiter_engine import rank, iter

# Using rank()
r = rank("jaguar speed", ["animal running", "car performance"])
print(r.top)
print(r.results)

# Using iter()
for text, score in iter("jaguar speed", ["animal running", "car performance"]):
    print(f"{score:.3f}  {text}")
```

---

## The Pun

```python
import arbiter_engine as arb
results = arb.iter("your query", ["option a", "option b"])
```

---

## CLI Usage

```bash
arb "jaguar speed" "animal running" "car performance"
```

```
  0.539  animal running
  0.511  car performance
```

### Disambiguation

```bash
arb "Python memory" "garbage collection" "snake habitat" "malloc"
```

```
  0.484  garbage collection
  0.325  malloc
  0.168  snake habitat
```

### Analogical Reasoning

```bash
arb "consciousness is to brain as computation is to" \
    "computer" "mathematics" "silicon" "algorithm" "information"
```

```
  0.505  mathematics
  0.364  information
  0.348  computer
  0.336  algorithm
  0.291  silicon
```

---

## JSON Output

```bash
arb --json "jaguar speed" "animal running" "car performance"
```

```json
{
  "query": "jaguar speed",
  "candidates": ["animal running", "car performance"],
  "top": {
    "text": "animal running",
    "score": 0.5389612913131714
  },
  "results": [
    {"text": "animal running", "score": 0.5389612913131714},
    {"text": "car performance", "score": 0.5105780959129333}
  ]
}
```

Pipe to jq:

```bash
arb --json "query" "a" "b" "c" | jq '.top.text'
```

---

## CLI Options

```
arb [-h] [--json] [--no-freq] [--version] query candidates...
```

**Options**

- `--json`  
- `--no-freq`  
- `--version`  
- `--help`  

---

## Why This Exists

- **Deterministic** — same input → same output  
- **Tiny** — 26 MB  
- **Fast** — <50 ms  
- **Zero-shot** — works on domains it wasn’t trained on  

---

## API Keys

```bash
export ARBITER_API_KEY=arb_xxxxxxxxxxxxx
```

Get a key at https://getarbiter.dev

---

## What People Have Built

- Drug discovery — Celebrex pathway  
- Defense — 840+ combat decisions  
- Robotics — 9-modality sensor fusion  
- Ancient languages — reads Chinese, Arabic, Sumerian  

---

## The Primitive

```python
from arbiter_engine import rank, iter

def rerank(query, documents):
    return [doc for doc, score in iter(query, documents) if score > 0.5]

def validate(constraint, options):
    r = rank(constraint, options)
    return r.top.score > 0.7

def route(message, destinations):
    r = rank(message, list(destinations.keys()))
    return destinations[r.top.text]
```

---

## Links

- Landing page — https://getarbiter.dev  
- API docs — https://api.arbiter.traut.ai/docs  
- Enterprise — founder@traut.ai  

---

## License

MIT
