# fractal-agents

**fractal-agents** is a toolkit for building hierarchical AI agents. It provides a complete cognitive architecture, from planning to parallel execution, designed for maximum performance and cost-efficiency.

## Status: Pre-Alpha Placeholder

This package has been registered on PyPI to reserve the name. The project is in the initial stages of development. The API is not stable and the package is not yet functional.

Please check back later or visit the [GitHub repository](https://github.com/findjashua/fractal-agents) for updates.

## License

This project is licensed under the MIT License.
