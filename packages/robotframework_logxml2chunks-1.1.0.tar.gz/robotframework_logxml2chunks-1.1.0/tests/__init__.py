"""
Tests initialization file.
"""
