from typing import Callable, Dict, List, Optional
from .server import FeatherServer
from .plugins.loader import PluginLoader


class App:
    def __init__(self, title: str = "FeatherOS App", debug: bool = True):
        self.title = title
        self.debug = debug
        self.pages: Dict[str, Callable] = {}
        self.api_routes: Dict[str, Callable] = {}
        self.plugins: List[str] = []
        self.server = None
        self.plugin_loader = PluginLoader()
        
    def page(self, path: str):
        """Decorator to register a page route"""
        def decorator(func: Callable):
            self.pages[path] = func
            return func
        return decorator
    
    def api(self, path: str):
        """Decorator to register an API endpoint"""
        def decorator(func: Callable):
            self.api_routes[path] = func
            return func
        return decorator
    
    def use_plugin(self, plugin_name: str):
        """Load a plugin into the app"""
        self.plugin_loader.install_plugin(plugin_name)
        plugin = self.plugin_loader.load_plugin(plugin_name)
        if plugin:
            self.plugins.append(plugin_name)
            if hasattr(plugin, 'register'):
                plugin.register(self)
        return self
    
    def run(self, host: str = "0.0.0.0", port: int = 5000):
        """Run the FeatherOS development server"""
        self.server = FeatherServer(self)
        self.server.run(host=host, port=port, debug=self.debug)
