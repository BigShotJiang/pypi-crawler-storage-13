# oes-protobuf

## Description
Pre-compiled Python protocol buffer bindings for OES's OpenDSO™. Includes OpenFMB Version 2.2 Proto Buffs.

## Installation

```bash
pip install oes-protobuf
```

## Included Protocol Buffers

### OpenDSO
- event
- historian
- rpcdss
- equipment
- topology

### OpenFMB
- breakermodule
- capbankmodule
- circuitsegmentservicemodule
- commonmodule
- essmodule
- generationmodule
- interconnectionmodule
- loadmodule
- metermodule
- reclosermodule
- regulatormodule
- reservemodule
- resourcemodule
- solarmodule
- switchmodule

## Note

This package includes the OpenFMB protocol buffers as part of its release. The single-source-of-truth for OpenFMB is hosted at [https://github.com/OpenFMB-Users-Group/psm-protobuf](https://github.com/OpenFMB-Users-Group/psm-protobuf).

## Authors

Open Energy Solutions
