# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class SetThresholdData:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'receiving': 'int',
        'sending': 'int'
    }

    attribute_map = {
        'receiving': 'receiving',
        'sending': 'sending'
    }

    def __init__(self, receiving=None, sending=None):
        r"""SetThresholdData

        The model defined in huaweicloud sdk

        :param receiving: 接收方向阈值设定值，单位为毫秒(ms)。 取值范围：0 - 10000。
        :type receiving: int
        :param sending: 发送方向阈值设定值，单位为毫秒(ms)。 取值范围：0 - 10000。
        :type sending: int
        """
        
        

        self._receiving = None
        self._sending = None
        self.discriminator = None

        if receiving is not None:
            self.receiving = receiving
        if sending is not None:
            self.sending = sending

    @property
    def receiving(self):
        r"""Gets the receiving of this SetThresholdData.

        接收方向阈值设定值，单位为毫秒(ms)。 取值范围：0 - 10000。

        :return: The receiving of this SetThresholdData.
        :rtype: int
        """
        return self._receiving

    @receiving.setter
    def receiving(self, receiving):
        r"""Sets the receiving of this SetThresholdData.

        接收方向阈值设定值，单位为毫秒(ms)。 取值范围：0 - 10000。

        :param receiving: The receiving of this SetThresholdData.
        :type receiving: int
        """
        self._receiving = receiving

    @property
    def sending(self):
        r"""Gets the sending of this SetThresholdData.

        发送方向阈值设定值，单位为毫秒(ms)。 取值范围：0 - 10000。

        :return: The sending of this SetThresholdData.
        :rtype: int
        """
        return self._sending

    @sending.setter
    def sending(self, sending):
        r"""Sets the sending of this SetThresholdData.

        发送方向阈值设定值，单位为毫秒(ms)。 取值范围：0 - 10000。

        :param sending: The sending of this SetThresholdData.
        :type sending: int
        """
        self._sending = sending

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, SetThresholdData):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
