# src/rewe_ebon_parser/parse.py

import re
from datetime import datetime
from typing import List, Optional
import pdfplumber
import io
import math
import pytz
from collections import OrderedDict
from .classes import (
    LoyaltyData,
    MarketAddress,
    Payment,
    PaybackCoupon,
    PaybackDetails,
    REWEBonusCoupon,
    REWEBonusDetails,
    Receipt,
    ReceiptItem,
    TaxDetails,
    TaxDetailsEntry,
)

def _parse_date(line: str) -> Optional[datetime]:
    """
    Parse date from a line of text.

    Args:
        line (str): The line of text.

    Returns:
        Optional[datetime]: The parsed date or None.
    """
    timestamp_hit = re.search(r'(\d{2})\.(\d{2})\.(\d{4}) (\d{2}):(\d{2}) Bon-Nr\.:', line)
    if timestamp_hit:
        date = datetime(
            year=int(timestamp_hit.group(3)),
            month=int(timestamp_hit.group(2)),
            day=int(timestamp_hit.group(1)),
            hour=int(timestamp_hit.group(4)),
            minute=int(timestamp_hit.group(5)),
            second=0
        )
        local_tz = pytz.timezone('Europe/Berlin')
        date = local_tz.localize(date)
        return date
    return None

def extract_raw_text(data_buffer: bytes) -> str:
    """
    Extract raw text from a PDF data buffer.

    Args:
        data_buffer (bytes): The PDF data buffer.

    Returns:
        str: The extracted raw text.
    """
    raw_text = ''
    with pdfplumber.open(io.BytesIO(data_buffer)) as pdf:
        for page in pdf.pages:
            raw_text += page.extract_text() + '\n'
    return raw_text

def parse_ebon(data_buffer: bytes) -> dict:
    """
    Parse receipt data from a PDF data buffer.

    Args:
        data_buffer (bytes): The PDF data buffer.

    Returns:
        dict: The parsed receipt data.
    """
    data_text = extract_raw_text(data_buffer)

    lines = list(filter(None, map(str.strip, data_text.replace('  ', ' ').split('\n'))))

    detected_loyalty_program = None
    # Pre-scan for loyalty program so items can be labeled correctly
    for line in lines:
        if 'Deine REWE PAYBACK Vorteile' in line:
            detected_loyalty_program = "PAYBACK"
            break
        if 'Deine REWE Bonus-Vorteile' in line:
            detected_loyalty_program = "REWE Bonus"
            break

    date = None
    market = '?'
    market_address = None
    cashier = '?'
    checkout = '?'
    uid = '?'
    items = []
    total = float('nan')
    given = []
    change = float('nan')
    payout = float('nan')
    payback_points_before = float('nan')
    payback_points = float('nan')
    payback_revenue = float('nan')
    payback_card_number = '?'
    payback_coupons = []
    rewe_bonus_earned_credit = None
    rewe_bonus_used_credit = None
    rewe_bonus_new_total_credit = None
    rewe_bonus_coupons = []
    used_rewe_credit = float('nan')
    new_rewe_credit = float('nan')
    tax_details_total = TaxDetailsEntry(float('nan'), float('nan'), float('nan'), float('nan'))
    tax_details_A = None
    tax_details_B = None
    tax_details_C = None

    # Improved address extraction logic to handle both formats
    address_match_1 = re.search(r'[\s\*]*([a-zäöüß \d.,-]+?)\s*[\s\*]*(\d{5})\s*([a-zäöüß \d.,-]+)[\s\*]*', data_text, re.IGNORECASE)
    address_match_2 = re.search(r'([\wäöüß \d.,-]+),\s*(\d{5})\s*([\wäöüß \d.,-]+)', data_text, re.IGNORECASE)
    if address_match_1:
        market_address = MarketAddress(
            street=address_match_1.group(1).replace('  ', ' ').replace(',', '').strip(),
            zip=address_match_1.group(2),
            city=address_match_1.group(3).strip()
        )
    elif address_match_2:
        market_address = MarketAddress(
            street=address_match_2.group(1).replace('  ', ' ').replace(',', '').strip(),
            zip=address_match_2.group(2),
            city=address_match_2.group(3).strip()
        )

    # Detect the dedicated item block bounded by the EUR marker and dashed separator.
    uid_index = -1
    for idx, line in enumerate(lines):
        if 'UID Nr.:' in line:
            uid_index = idx
            break

    start_index = -1
    if uid_index != -1:
        for idx in range(uid_index + 1, len(lines)):
            if lines[idx].strip() == 'EUR':
                start_index = idx + 1  # start parsing after the EUR marker
                break

    end_index = -1
    if start_index != -1:
        for idx in range(start_index, len(lines)):
            if lines[idx].strip().startswith('--------------------------------------'):
                end_index = idx
                break

    def _process_item_line(line: str) -> bool:
        # First, check for quantity/weight lines, as they modify the last added item.
        menge_hit = re.match(r'(.*) (.*) x (.*).*', line)
        if menge_hit:
            amount = float(menge_hit.group(1).replace(',', '.'))
            unit = menge_hit.group(2)
            price_per_unit_str = re.search(r'(\d+,\d+)', menge_hit.group(3))
            price_per_unit = float(price_per_unit_str.group(1).replace(',', '.')) if price_per_unit_str else None
            if unit == 'Stk':
                amount = int(amount)
            if items:
                items[-1].amount = amount
                items[-1].unit = unit
                items[-1].price_per_unit = price_per_unit
            return True

        menge_handeingabe_hit = re.match(r"Handeingabe E-Bon\s*(\d+,\d+)\s*([a-zA-Z]*)", line)
        if menge_handeingabe_hit:
            amount = float(menge_handeingabe_hit.group(1).replace(",","."))
            unit = menge_handeingabe_hit.group(2)
            if items:
                items[-1].amount = amount
                items[-1].unit = unit
                items[-1].price_per_unit = items[-1].sub_total/amount
            return True

        # If not a quantity line, check for one or more item definitions.
        # This handles cases where multiple items are merged onto a single line.
        item_pattern = r'(-?\d+,\d\d) ([ABC]) ?(\*?)'
        matches = list(re.finditer(item_pattern, line))

        if not matches:
            return False # Not a line with parsable items.

        last_pos = 0
        processed_item = False
        for match in matches:
            # The item name is the text between the end of the last full match and
            # the beginning of the current price match.
            item_name = line[last_pos:match.start()].strip()
            
            # Skip if there's no item name (e.g., malformed line)
            if not item_name:
                last_pos = match.end()
                continue
            
            price_str = match.group(1)
            category = match.group(2)
            star = match.group(3)

            price = float(price_str.replace(',', '.'))
            loyalty_program_qualified = detected_loyalty_program if (not star and price > 0) else None

            items.append(ReceiptItem(
                tax_category=category,
                name=item_name,
                sub_total=price,
                amount=1, # Default amount, may be overridden by a following line
                loyalty_program_qualified=loyalty_program_qualified
            ))
            
            last_pos = match.end()
            processed_item = True
        
        return processed_item

    def _process_non_item_line(line: str) -> bool:
        nonlocal total, change, payout, date, market, checkout, cashier, uid
        nonlocal payback_card_number, payback_points_before, payback_points, payback_revenue
        nonlocal tax_details_total, tax_details_A, tax_details_B, tax_details_C
        nonlocal used_rewe_credit, new_rewe_credit
        nonlocal rewe_bonus_earned_credit, rewe_bonus_used_credit, rewe_bonus_new_total_credit

        total_hit = re.match(r'SUMME EUR (-?\d*,\d\d)', line)
        if total_hit:
            total = float(total_hit.group(1).replace(',', '.'))
            return True

        gegeben_hit = re.match(r'Geg\.(.*) EUR ([0-9,]*)', line)
        if gegeben_hit:
            given.append(Payment(
                type=gegeben_hit.group(1).strip(),
                value=float(gegeben_hit.group(2).replace(',', '.'))
            ))
            return True

        return_hit = re.match(r'Rückgeld BAR EUR ([0-9,]*)', line)
        if return_hit:
            change = float(return_hit.group(1).replace(',', '.'))
            return True

        payout_match = re.match(r'AUSZAHLUNG EUR ([0-9,]*)', line)
        if payout_match:
            payout = float(payout_match.group(1).replace(',', '.'))
            return True

        parsed_date = _parse_date(line)
        if parsed_date:
            date = parsed_date
            return True

        markt_match = re.match(r'Markt:(.*) Kasse:(.*) Bed\.:(.*)', line)
        if markt_match:
            market = markt_match.group(1).strip()
            checkout = markt_match.group(2).strip()
            cashier = markt_match.group(3).strip()
            return True

        uid_match = re.match(r'UID Nr.: (.*)', line)
        if uid_match:
            uid = uid_match.group(1).strip()
            return True

        payback_info_match = re.match(r'PAYBACK Karten-Nr\.: ([0-9#]*)Punkte vor dem Einkauf: ([0-9.,]*) Punkte', line)
        if payback_info_match:
            payback_card_number = payback_info_match.group(1)
            payback_points_before = int(payback_info_match.group(2).replace('.', '').replace(',', ''))
            return True

        payback_points_match = re.match(r'Sie erhalten (\d*) PAYBACK Punkte? auf|Mit diesem Einkauf gesammelt: (\d*) Punkte?', line)
        if payback_points_match:
            match = next(group for group in payback_points_match.groups() if group is not None)
            payback_points = int(match)
            return True

        payback_revenue_match = re.match(r'einen PAYBACK Umsatz von (.*) EUR!', line)
        if payback_revenue_match:
            payback_revenue = float(payback_revenue_match.group(1).replace(',', '.'))
            return True

        payback_points_before_match = re.match(r'Punktestand vor Einkauf: ([0-9.]*)|Punkte vor dem Einkauf: ([0-9.]*)', line)
        if payback_points_before_match:
            match = next(group for group in payback_points_before_match.groups() if group is not None)
            payback_points_before = int(match.replace('.', ''))
            return True

        payback_card_number_match = re.match(r'PAYBACK Karten-Nr\.: ([0-9#]*)', line)
        if payback_card_number_match:
            payback_card_number = payback_card_number_match.group(1)
            return True

        payback_coupon_match = re.match(r'(.*) ([0-9.]*) Punkte?', line)
        if payback_coupon_match:
            payback_coupons.append(PaybackCoupon(
                name=payback_coupon_match.group(1),
                points=int(payback_coupon_match.group(2).replace('.', ''))
            ))
            return True

        if detected_loyalty_program == "REWE Bonus":
            earned_credit_match = re.match(r'Mit diesem Einkauf hast du ([0-9.,]+) EUR', line)
            if earned_credit_match:
                rewe_bonus_earned_credit = float(earned_credit_match.group(1).replace('.', '').replace(',', '.'))
                return True

            used_bonus_credit_match = re.match(r'Eingesetztes Bonus-Guthaben: ([0-9.,]+) EUR', line)
            if used_bonus_credit_match:
                rewe_bonus_used_credit = float(used_bonus_credit_match.group(1).replace('.', '').replace(',', '.'))
                return True

            new_total_credit_match = re.match(r'Aktuelles Bonus-Guthaben: ([0-9.,]+) EUR', line)
            if new_total_credit_match:
                rewe_bonus_new_total_credit = float(new_total_credit_match.group(1).replace('.', '').replace(',', '.'))
                return True

            rewe_bonus_coupon_match = re.match(r'(.*) ([0-9.,]+) EUR', line)
            if rewe_bonus_coupon_match and 'Bonus-Guthaben' not in line and 'Mit diesem Einkauf' not in line:
                coupon_name = rewe_bonus_coupon_match.group(1).strip()
                if coupon_name:
                    rewe_bonus_coupons.append(REWEBonusCoupon(
                        name=coupon_name,
                        value=float(rewe_bonus_coupon_match.group(2).replace('.', '').replace(',', '.'))
                    ))
                    return True

        tax_details_match = re.match(r'([ABC])= ([0-9,]*)% ([0-9,]*) ([0-9,]*) ([0-9,]*)', line)
        if tax_details_match:
            category = tax_details_match.group(1)
            tax_details_entry = TaxDetailsEntry(
                tax_percent=float(tax_details_match.group(2).replace(',', '.')),
                net=float(tax_details_match.group(3).replace(',', '.')),
                tax=float(tax_details_match.group(4).replace(',', '.')),
                gross=float(tax_details_match.group(5).replace(',', '.'))
            )
            if category == 'A':
                tax_details_A = tax_details_entry
            elif category == 'B':
                tax_details_B = tax_details_entry
            elif category == 'C':
                tax_details_C = tax_details_entry
            return True

        total_tax_match = re.match(r'Gesamtbetrag ([0-9,]*) ([0-9,]*) ([0-9,]*)', line)
        if total_tax_match:
            tax_details_total = TaxDetailsEntry(
                tax_percent=float('nan'),
                net=float(total_tax_match.group(1).replace(',', '.')),
                tax=float(total_tax_match.group(2).replace(',', '.')),
                gross=float(total_tax_match.group(3).replace(',', '.'))
            )
            return True

        used_rewe_credit_match = re.match(r'Eingesetztes REWE Guthaben: ([0-9,]*) EUR', line)
        if used_rewe_credit_match:
            used_rewe_credit = float(used_rewe_credit_match.group(1).replace(',', '.'))

        new_rewe_credit_match = re.match(r'Neues REWE Guthaben: ([0-9,]*) EUR', line)
        if new_rewe_credit_match:
            new_rewe_credit = float(new_rewe_credit_match.group(1).replace(',', '.'))

        return False

    if start_index != -1 and end_index != -1:
        header_lines = lines[:start_index]
        item_lines = lines[start_index:end_index]
        footer_lines = lines[end_index:]

        for line in header_lines + footer_lines:
            if _process_non_item_line(line):
                continue

        for line in item_lines:
            if _process_item_line(line):
                continue
    else:
        for line in lines:
            if _process_item_line(line):
                continue
            if _process_non_item_line(line):
                continue

    if date is None:
        raise ValueError("Date not found in the receipt")

    real_total_in_cents = sum(item.sub_total * 100 for item in items)
    total_in_cents = total * 100

    if round(real_total_in_cents, 2) != round(total_in_cents, 2):
        raise ValueError(f"Something went wrong when parsing the eBon: The eBon states a total sum of {total_in_cents} but the parser only found items worth {real_total_in_cents}.")

    loyalty_data = None
    if detected_loyalty_program == "PAYBACK" and payback_card_number != '?':
        qualified_revenue = payback_revenue if not math.isnan(payback_revenue) else sum(item.sub_total for item in items if item.loyalty_program_qualified or item.sub_total < 0)
        payback_details = PaybackDetails(
            card=payback_card_number,
            points_before=payback_points_before,
            earned_points=payback_points,
            used_coupons=payback_coupons,
            used_rewe_credit=used_rewe_credit if not math.isnan(used_rewe_credit) else None,
            new_rewe_credit=new_rewe_credit if not math.isnan(new_rewe_credit) else None,
            payback_revenue=qualified_revenue
        )
        loyalty_data = LoyaltyData(program="PAYBACK", details=payback_details)
    elif detected_loyalty_program == "REWE Bonus" and rewe_bonus_earned_credit is not None:
        rewe_bonus_details = REWEBonusDetails(
            earned_credit=rewe_bonus_earned_credit,
            used_credit=rewe_bonus_used_credit,
            new_total_credit=rewe_bonus_new_total_credit,
            used_coupons=rewe_bonus_coupons
        )
        loyalty_data = LoyaltyData(program="REWE Bonus", details=rewe_bonus_details)

    receipt = Receipt(
        date=date,
        market=market,
        market_address=market_address,
        cashier=cashier,
        checkout=checkout,
        vatin=uid,
        items=items,
        total=total,
        given=given,
        change=change if not math.isnan(change) else None,
        payout=payout if not math.isnan(payout) else None,
        loyalty=loyalty_data,
        tax_details=TaxDetails(
                total=tax_details_total,
                A=tax_details_A,
                B=tax_details_B,
                C=tax_details_C
            )
    )

    # Create an ordered dictionary to ensure specific order of keys
    receipt_dict = receipt.to_dict()
    ordered_receipt_dict = OrderedDict([
        ('datetime_local', receipt_dict.get('datetime_local')),
        ('datetime_utc', receipt_dict.get('datetime_utc')),
        ('market', receipt_dict.get('market')),
        ('marketAddress', receipt_dict.get('marketAddress')),
        ('cashier', receipt_dict.get('cashier')),
        ('checkout', receipt_dict.get('checkout')),
        ('vatin', receipt_dict.get('vatin')),
        ('items', receipt_dict.get('items')),
        ('total', receipt_dict.get('total')),
        ('given', receipt_dict.get('given')),
        ('change', receipt_dict.get('change')),
        ('payout', receipt_dict.get('payout')),
        ('loyalty', receipt_dict.get('loyalty')),
        ('taxDetails', receipt_dict.get('taxDetails')),
    ])

    # Remove None values to clean up the dictionary
    ordered_receipt_dict = {k: v for k, v in ordered_receipt_dict.items() if v is not None}

    return ordered_receipt_dict

def parse_text_ebon(text: str) -> dict:
    """
    Parse receipt data from extracted text.

    Args:
        text (str): The extracted text from a receipt.

    Returns:
        dict: The parsed receipt data.
    """
    data_text = text

    lines = list(filter(None, map(str.strip, data_text.replace('  ', ' ').split('\n'))))

    detected_loyalty_program = None
    # Pre-scan for loyalty program so items can be labeled correctly
    for line in lines:
        if 'Deine REWE PAYBACK Vorteile' in line:
            detected_loyalty_program = "PAYBACK"
            break
        if 'Deine REWE Bonus-Vorteile' in line:
            detected_loyalty_program = "REWE Bonus"
            break

    date = None
    market = '?'
    market_address = None
    cashier = '?'
    checkout = '?'
    uid = '?'
    items = []
    total = float('nan')
    given = []
    change = float('nan')
    payout = float('nan')
    payback_points_before = float('nan')
    payback_points = float('nan')
    payback_revenue = float('nan')
    payback_card_number = '?'
    payback_coupons = []
    rewe_bonus_earned_credit = None
    rewe_bonus_used_credit = None
    rewe_bonus_new_total_credit = None
    rewe_bonus_coupons = []
    used_rewe_credit = float('nan')
    new_rewe_credit = float('nan')
    tax_details_total = TaxDetailsEntry(float('nan'), float('nan'), float('nan'), float('nan'))
    tax_details_A = None
    tax_details_B = None
    tax_details_C = None

    # Improved address extraction logic to handle both formats
    address_match_1 = re.search(r'[\s\*]*([a-zäöüß \d.,-]+?)\s*[\s\*]*(\d{5})\s*([a-zäöüß \d.,-]+)[\s\*]*', data_text, re.IGNORECASE)
    address_match_2 = re.search(r'([\wäöüß \d.,-]+),\s*(\d{5})\s*([\wäöüß \d.,-]+)', data_text, re.IGNORECASE)
    if address_match_1:
        market_address = MarketAddress(
            street=address_match_1.group(1).replace('  ', ' ').replace(',', '').strip(),
            zip=address_match_1.group(2),
            city=address_match_1.group(3).strip()
        )
    elif address_match_2:
        market_address = MarketAddress(
            street=address_match_2.group(1).replace('  ', ' ').replace(',', '').strip(),
            zip=address_match_2.group(2),
            city=address_match_2.group(3).strip()
        )

    uid_index = -1
    for idx, line in enumerate(lines):
        if 'UID Nr.:' in line:
            uid_index = idx
            break

    start_index = -1
    if uid_index != -1:
        for idx in range(uid_index + 1, len(lines)):
            if lines[idx].strip() == 'EUR':
                start_index = idx + 1
                break

    end_index = -1
    if start_index != -1:
        for idx in range(start_index, len(lines)):
            if lines[idx].strip().startswith('--------------------------------------'):
                end_index = idx
                break

    def _process_item_line(line: str) -> bool:
        # First, check for quantity/weight lines, as they modify the last added item.
        menge_hit = re.match(r'(.*) (.*) x (.*).*', line)
        if menge_hit:
            amount = float(menge_hit.group(1).replace(',', '.'))
            unit = menge_hit.group(2)
            price_per_unit_str = re.search(r'(\d+,\d+)', menge_hit.group(3))
            price_per_unit = float(price_per_unit_str.group(1).replace(',', '.')) if price_per_unit_str else None
            if unit == 'Stk':
                amount = int(amount)
            if items:
                items[-1].amount = amount
                items[-1].unit = unit
                items[-1].price_per_unit = price_per_unit
            return True

        menge_handeingabe_hit = re.match(r"Handeingabe E-Bon\s*(\d+,\d+)\s*([a-zA-Z]*)", line)
        if menge_handeingabe_hit:
            amount = float(menge_handeingabe_hit.group(1).replace(",","."))
            unit = menge_handeingabe_hit.group(2)
            if items:
                items[-1].amount = amount
                items[-1].unit = unit
                items[-1].price_per_unit = items[-1].sub_total/amount
            return True

        # If not a quantity line, check for one or more item definitions.
        # This handles cases where multiple items are merged onto a single line.
        item_pattern = r'(-?\d+,\d\d) ([ABC]) ?(\*?)'
        matches = list(re.finditer(item_pattern, line))

        if not matches:
            return False # Not a line with parsable items.

        last_pos = 0
        processed_item = False
        for match in matches:
            # The item name is the text between the end of the last full match and
            # the beginning of the current price match.
            item_name = line[last_pos:match.start()].strip()
            
            # Skip if there's no item name (e.g., malformed line)
            if not item_name:
                last_pos = match.end()
                continue
            
            price_str = match.group(1)
            category = match.group(2)
            star = match.group(3)

            price = float(price_str.replace(',', '.'))
            loyalty_program_qualified = detected_loyalty_program if (not star and price > 0) else None

            items.append(ReceiptItem(
                tax_category=category,
                name=item_name,
                sub_total=price,
                amount=1, # Default amount, may be overridden by a following line
                loyalty_program_qualified=loyalty_program_qualified
            ))
            
            last_pos = match.end()
            processed_item = True
        
        return processed_item

    def _process_non_item_line(line: str) -> bool:
        nonlocal total, change, payout, date, market, checkout, cashier, uid
        nonlocal payback_card_number, payback_points_before, payback_points, payback_revenue
        nonlocal tax_details_total, tax_details_A, tax_details_B, tax_details_C
        nonlocal used_rewe_credit, new_rewe_credit
        nonlocal rewe_bonus_earned_credit, rewe_bonus_used_credit, rewe_bonus_new_total_credit

        total_hit = re.match(r'SUMME EUR (-?\d*,\d\d)', line)
        if total_hit:
            total = float(total_hit.group(1).replace(',', '.'))
            return True

        gegeben_hit = re.match(r'Geg\.(.*) EUR ([0-9,]*)', line)
        if gegeben_hit:
            given.append(Payment(
                type=gegeben_hit.group(1).strip(),
                value=float(gegeben_hit.group(2).replace(',', '.'))
            ))
            return True

        return_hit = re.match(r'Rückgeld BAR EUR ([0-9,]*)', line)
        if return_hit:
            change = float(return_hit.group(1).replace(',', '.'))
            return True

        payout_match = re.match(r'AUSZAHLUNG EUR ([0-9,]*)', line)
        if payout_match:
            payout = float(payout_match.group(1).replace(',', '.'))
            return True

        parsed_date = _parse_date(line)
        if parsed_date:
            date = parsed_date
            return True

        markt_match = re.match(r'Markt:(.*) Kasse:(.*) Bed\.:(.*)', line)
        if markt_match:
            market = markt_match.group(1).strip()
            checkout = markt_match.group(2).strip()
            cashier = markt_match.group(3).strip()
            return True

        uid_match = re.match(r'UID Nr.: (.*)', line)
        if uid_match:
            uid = uid_match.group(1).strip()
            return True

        payback_info_match = re.match(r'PAYBACK Karten-Nr\.: ([0-9#]*)Punkte vor dem Einkauf: ([0-9.,]*) Punkte', line)
        if payback_info_match:
            payback_card_number = payback_info_match.group(1)
            payback_points_before = int(payback_info_match.group(2).replace('.', '').replace(',', ''))
            return True

        payback_points_match = re.match(r'Sie erhalten (\d*) PAYBACK Punkte? auf|Mit diesem Einkauf gesammelt: (\d*) Punkte?', line)
        if payback_points_match:
            match = next(group for group in payback_points_match.groups() if group is not None)
            payback_points = int(match)
            return True

        payback_revenue_match = re.match(r'einen PAYBACK Umsatz von (.*) EUR!', line)
        if payback_revenue_match:
            payback_revenue = float(payback_revenue_match.group(1).replace(',', '.'))
            return True

        payback_points_before_match = re.match(r'Punktestand vor Einkauf: ([0-9.]*)|Punkte vor dem Einkauf: ([0-9.]*)', line)
        if payback_points_before_match:
            match = next(group for group in payback_points_before_match.groups() if group is not None)
            payback_points_before = int(match.replace('.', ''))
            return True

        payback_card_number_match = re.match(r'PAYBACK Karten-Nr\.: ([0-9#]*)', line)
        if payback_card_number_match:
            payback_card_number = payback_card_number_match.group(1)
            return True

        payback_coupon_match = re.match(r'(.*) ([0-9.]*) Punkte?', line)
        if payback_coupon_match:
            payback_coupons.append(PaybackCoupon(
                name=payback_coupon_match.group(1),
                points=int(payback_coupon_match.group(2).replace('.', ''))
            ))
            return True

        if detected_loyalty_program == "REWE Bonus":
            earned_credit_match = re.match(r'Mit diesem Einkauf hast du ([0-9.,]+) EUR', line)
            if earned_credit_match:
                rewe_bonus_earned_credit = float(earned_credit_match.group(1).replace('.', '').replace(',', '.'))
                return True

            used_bonus_credit_match = re.match(r'Eingesetztes Bonus-Guthaben: ([0-9.,]+) EUR', line)
            if used_bonus_credit_match:
                rewe_bonus_used_credit = float(used_bonus_credit_match.group(1).replace('.', '').replace(',', '.'))
                return True

            new_total_credit_match = re.match(r'Aktuelles Bonus-Guthaben: ([0-9.,]+) EUR', line)
            if new_total_credit_match:
                rewe_bonus_new_total_credit = float(new_total_credit_match.group(1).replace('.', '').replace(',', '.'))
                return True

            rewe_bonus_coupon_match = re.match(r'(.*) ([0-9.,]+) EUR', line)
            if rewe_bonus_coupon_match and 'Bonus-Guhaben' not in line and 'Mit diesem Einkauf' not in line:
                coupon_name = rewe_bonus_coupon_match.group(1).strip()
                if coupon_name:
                    rewe_bonus_coupons.append(REWEBonusCoupon(
                        name=coupon_name,
                        value=float(rewe_bonus_coupon_match.group(2).replace('.', '').replace(',', '.'))
                    ))
                    return True

        tax_details_match = re.match(r'([ABC])= ([0-9,]*)% ([0-9,]*) ([0-9,]*) ([0-9,]*)', line)
        if tax_details_match:
            category = tax_details_match.group(1)
            tax_details_entry = TaxDetailsEntry(
                tax_percent=float(tax_details_match.group(2).replace(',', '.')),
                net=float(tax_details_match.group(3).replace(',', '.')),
                tax=float(tax_details_match.group(4).replace(',', '.')),
                gross=float(tax_details_match.group(5).replace(',', '.'))
            )
            if category == 'A':
                tax_details_A = tax_details_entry
            elif category == 'B':
                tax_details_B = tax_details_entry
            elif category == 'C':
                tax_details_C = tax_details_entry
            return True

        total_tax_match = re.match(r'Gesamtbetrag ([0-9,]*) ([0-9,]*) ([0-9,]*)', line)
        if total_tax_match:
            tax_details_total = TaxDetailsEntry(
                tax_percent=float('nan'),
                net=float(total_tax_match.group(1).replace(',', '.')),
                tax=float(total_tax_match.group(2).replace(',', '.')),
                gross=float(total_tax_match.group(3).replace(',', '.'))
            )
            return True

        used_rewe_credit_match = re.match(r'Eingesetztes REWE Guthaben: ([0-9,]*) EUR', line)
        if used_rewe_credit_match:
            used_rewe_credit = float(used_rewe_credit_match.group(1).replace(',', '.'))

        new_rewe_credit_match = re.match(r'Neues REWE Guthaben: ([0-9,]*) EUR', line)
        if new_rewe_credit_match:
            new_rewe_credit = float(new_rewe_credit_match.group(1).replace(',', '.'))

        return False

    if start_index != -1 and end_index != -1:
        header_lines = lines[:start_index]
        item_lines = lines[start_index:end_index]
        footer_lines = lines[end_index:]

        for line in header_lines + footer_lines:
            if _process_non_item_line(line):
                continue

        for line in item_lines:
            if _process_item_line(line):
                continue
    else:
        for line in lines:
            if _process_item_line(line):
                continue
            if _process_non_item_line(line):
                continue

    # For anonymized text files, date might not be available
    if date is None:
        # Use a default date for anonymized receipts
        date = datetime(1970, 1, 1, 0, 0, 0)
        local_tz = pytz.timezone('Europe/Berlin')
        date = local_tz.localize(date)

    real_total_in_cents = sum(item.sub_total * 100 for item in items)
    total_in_cents = total * 100

    # For anonymized files, skip total validation if it's off (might have redacted items)
    # Validate that the sum of item sub_totals equals the receipt's total sum.
    if not math.isnan(total) and round(real_total_in_cents, 2) != round(total_in_cents, 2):
        raise ValueError(f"Something went wrong when parsing the eBon: The eBon states a total sum of {total:.2f} but the parser only found items worth {real_total_in_cents / 100:.2f}.")

    loyalty_data = None
    if detected_loyalty_program == "PAYBACK" and payback_card_number != '?':
        qualified_revenue = payback_revenue if not math.isnan(payback_revenue) else sum(item.sub_total for item in items if item.loyalty_program_qualified or item.sub_total < 0)
        payback_details = PaybackDetails(
            card=payback_card_number,
            points_before=payback_points_before,
            earned_points=payback_points,
            used_coupons=payback_coupons,
            used_rewe_credit=used_rewe_credit if not math.isnan(used_rewe_credit) else None,
            new_rewe_credit=new_rewe_credit if not math.isnan(new_rewe_credit) else None,
            payback_revenue=qualified_revenue
        )
        loyalty_data = LoyaltyData(program="PAYBACK", details=payback_details)
    elif detected_loyalty_program == "REWE Bonus" and rewe_bonus_earned_credit is not None:
        rewe_bonus_details = REWEBonusDetails(
            earned_credit=rewe_bonus_earned_credit,
            used_credit=rewe_bonus_used_credit,
            new_total_credit=rewe_bonus_new_total_credit,
            used_coupons=rewe_bonus_coupons
        )
        loyalty_data = LoyaltyData(program="REWE Bonus", details=rewe_bonus_details)

    receipt = Receipt(
        date=date,
        market=market,
        market_address=market_address,
        cashier=cashier,
        checkout=checkout,
        vatin=uid,
        items=items,
        total=total,
        given=given,
        change=change if not math.isnan(change) else None,
        payout=payout if not math.isnan(payout) else None,
        loyalty=loyalty_data,
        tax_details=TaxDetails(
                total=tax_details_total,
                A=tax_details_A,
                B=tax_details_B,
                C=tax_details_C
            )
    )

    # Create an ordered dictionary to ensure specific order of keys
    receipt_dict = receipt.to_dict()
    ordered_receipt_dict = OrderedDict([
        ('datetime_local', receipt_dict.get('datetime_local')),
        ('datetime_utc', receipt_dict.get('datetime_utc')),
        ('market', receipt_dict.get('market')),
        ('marketAddress', receipt_dict.get('marketAddress')),
        ('cashier', receipt_dict.get('cashier')),
        ('checkout', receipt_dict.get('checkout')),
        ('vatin', receipt_dict.get('vatin')),
        ('items', receipt_dict.get('items')),
        ('total', receipt_dict.get('total')),
        ('given', receipt_dict.get('given')),
        ('change', receipt_dict.get('change')),
        ('payout', receipt_dict.get('payout')),
        ('loyalty', receipt_dict.get('loyalty')),
        ('taxDetails', receipt_dict.get('taxDetails')),
    ])

    # Remove None values to clean up the dictionary
    ordered_receipt_dict = {k: v for k, v in ordered_receipt_dict.items() if v is not None}

    return ordered_receipt_dict

def parse_pdf_ebon(pdf_path: str) -> dict:
    """
    Parse receipt data from a PDF file.

    Args:
        pdf_path (str): Path to the input PDF file.

    Returns:
        dict: The parsed receipt data.
    """
    with open(pdf_path, 'rb') as f:
        data = f.read()
        result = parse_ebon(data)
        return result
