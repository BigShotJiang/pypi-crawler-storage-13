# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.

# create_color.py

# Importar paletas y reglas desde el mismo archivo
# create_color.py
from pathlib import Path

from .palettes_homologous import palette_homologous, homologous_color_rule
from .palettes_triadic import palette_triadic, triadic_color_rule
from .palettes_tetradic import palette_tetradic, tetradic_color_rule


class CreateColor:
    """
    Aplica automáticamente una familia de colores al archivo style.css.
    No requiere llamar métodos adicionales (.apply).
    """

    PALETTES = {
        "homologous": palette_homologous,
        "triadic": palette_triadic,
        "tetradic": palette_tetradic,
    }

    RULES = {
        "homologous": homologous_color_rule,
        "triadic": triadic_color_rule,
        "tetradic": tetradic_color_rule,
    }

    def __init__(self, family="homologous", color_name=None, css_path="style.css"):
        if family not in self.PALETTES:
            raise ValueError(f"family '{family}' not supported")

        self.family = family
        self.palette = self.PALETTES[family]
        self.rule = self.RULES[family]
        self.css_path = Path(css_path)

        # Aplica estilos automáticamente:
        self._apply_colors()

    # -----------------------------------------
    #   Aplica colores dentro de style.css
    # -----------------------------------------
    def _apply_colors(self):
        if not self.css_path.exists():
            print(f"⚠ style.css not found at: {self.css_path}")
            return

        css_content = self.css_path.read_text()

        # aplicar a todos los selectores /* styles here */
        css_content = self._replace_all(css_content)

        self.css_path.write_text(css_content)
        print(f"🎨 Colors applied using {self.family} palette.")

    # -----------------------------------------
    #   Reemplaza cada selector en style.css
    # -----------------------------------------
    def _replace_all(self, css_text):
        """
        Cada regla en style.css tiene: { /* styles here */ }
        Lo reemplazamos por background + text según la regla.
        """
        bg, tx = self._default_colors()

        replacement = f"background:{bg}; color:{tx};"

        return css_text.replace("/* styles here */", replacement)

    # -----------------------------------------
    #   Obtiene bg y text por defecto (body)
    # -----------------------------------------
    def _default_colors(self):
        main_rule = self.rule.get("body", {})
        return (
            main_rule.get("bg", self.palette["white"]["principal"]),
            main_rule.get("text", self.palette["black"]["principal"])
        )
