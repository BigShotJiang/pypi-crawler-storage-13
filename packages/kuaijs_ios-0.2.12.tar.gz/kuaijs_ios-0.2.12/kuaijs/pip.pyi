from typing import Optional, TypedDict

class LogViewParams(TypedDict):
    width: Optional[int]
    height: Optional[int]
    textSize: Optional[int]
    textColor: Optional[str]
    backgroundColor: Optional[str]

def set_log_view_params(params: Optional[LogViewParams] = ...) -> None:
    """设置悬浮窗日志窗口的显示参数（需在显示前调用）"""
    ...

def is_pip_active() -> bool:
    """是否开启了悬浮窗"""
    ...

def show_log_window() -> bool:
    """显示日志窗口（App 必须在前台）"""
    ...

def close_log_window() -> bool:
    """关闭日志窗口（App 必须在前台）"""
    ...

def set_pip_ctrl_script(ctrl: bool) -> bool:
    """设置是否允许悬浮窗控制脚本启停"""
    ...
