# 安裝指南

## 推薦方式：uvx 一行指令（最簡單）

```bash
uvx adhd-copilot
```

**優點：**
- ✅ 不需要 clone 專案
- ✅ 不需要預先安裝 Python
- ✅ 不需要管理虛擬環境
- ✅ 不會與其他專案衝突
- ✅ 自動下載並安裝所有依賴
- ✅ 一行指令就能啟動

### 安裝 uv（如果還沒有）

```bash
# macOS / Linux（推薦）
curl -LsSf https://astral.sh/uv/install.sh | sh

# 或使用 Homebrew (macOS)
brew install uv

# 或使用 pip（如果已有 Python）
pip install uv
```

安裝完 `uv` 後，重新開啟終端機，然後執行：

```bash
uvx adhd-copilot
```

---

## 開發者方式：從原始碼安裝

如果你想修改程式碼或貢獻開發：

```bash
# 1. Clone 專案
git clone https://github.com/richblack/ADHD-copilot.git
cd ADHD-copilot

# 2. 執行安裝腳本
chmod +x install.sh
./install.sh

# 3. 啟動服務
chmod +x run_service.sh
./run_service.sh
```

---

## 首次使用設定

### 1. 啟動服務

```bash
uvx adhd-copilot
```

服務會自動啟動並開啟瀏覽器到 `http://localhost:3001`

### 2. 選擇能量狀態

你會看到兩個選項：
- **🔋 電力充足** - 適合處理複雜任務、規劃專案
- **🪫 低耗電模式** - 適合做簡單任務、減少決策負擔

選擇你現在的狀態（隨時可以重選）

### 3. 設定 API Key

點擊右上角 ⚙️ 設定圖示：

1. **取得 Gemini API Key**（免費）
   - 前往 [Google AI Studio](https://makersuite.google.com/app/apikey)
   - 登入 Google 帳號
   - 點擊「Create API Key」
   - 複製 API Key（格式：`AIzaSy...`）

2. **設定專案目錄**
   - 輸入你的專案主目錄
   - 例如：`/Users/你的名字/Documents/projects`
   - 這樣 AI 才能掃描你的專案

3. 點擊「儲存」

### 4. 開始使用

直接在輸入框輸入你的想法：
- 按 **Enter** 送出訊息
- 按 **Shift+Enter** 換行
- 點擊 📁 圖示掃描專案
- 點擊 🔄 圖示重選能量狀態

## 取得 Gemini API Key

1. 前往 [Google AI Studio](https://makersuite.google.com/app/apikey)
2. 登入你的 Google 帳號
3. 點擊「Create API Key」
4. 複製 API Key（格式：`AIzaSy...`）
5. 貼到 ADHD Copilot 的設定中

免費額度：每分鐘 15 次請求，每天 1500 次請求（對個人使用綽綽有餘）

---

## 常見問題

### Q: uvx 找不到套件？

確認已安裝 `uv`：
```bash
uv --version
```

如果沒有，請先安裝 uv（見上方）。

### Q: 無法連接到 localhost:3001？

可能是 port 被佔用。檢查：
```bash
lsof -i :3001
```

如果有其他程式佔用，先關閉該程式。

### Q: API Key 無效？

確認：
1. API Key 格式正確（以 `AIzaSy` 開頭）
2. 已在 [Google AI Studio](https://makersuite.google.com/app/apikey) 建立 API Key
3. 沒有超過免費額度（每分鐘 15 次請求）

### Q: 如何停止服務？

在終端機按 `Ctrl+C` 即可。

### Q: 如何更新到最新版本？

```bash
# uvx 會自動使用最新版本
uvx adhd-copilot

# 或強制重新下載
uvx --refresh adhd-copilot
```

### Q: 資料儲存在哪裡？

- API Key 和設定：`~/.adhd_copilot_config.json`
- 同步檔案：`.adhd/context.md`（在你的專案目錄）

### Q: 如何完全移除？

```bash
# 移除 uv cache
rm -rf ~/.cache/uv

# 移除設定檔
rm ~/.adhd_copilot_config.json
```

---

## 效能比較

| 安裝方式 | 首次安裝時間 | 啟動時間 | 需要技術知識 |
|---------|------------|---------|------------|
| uvx | ~30 秒 | ~5 秒 | ❌ 不需要 |
| 原始碼 | ~5 分鐘 | ~10 秒 | ✅ 需要 |

**結論：除非你要開發，否則用 uvx 就對了。**
