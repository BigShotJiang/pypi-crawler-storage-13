import reflex as rx

# Zen Theme Colors
class ZenColor:
    BG = "#F9F9F7"        # Rice paper white
    TEXT = "#4A4A4A"      # Soft charcoal
    PRIMARY = "#8FA998"   # Matcha green
    SECONDARY = "#D4C5B0" # Sand/Wood
    ACCENT = "#A8B5C9"    # Pale Indigo
    MUTED = "#E0E0E0"     # Light gray
    WHITE = "#FFFFFF"

# Global Styles
global_style = {
    "body": {
        "bg": ZenColor.BG,
        "color": ZenColor.TEXT,
        "font_family": "Inter, sans-serif",
    },
    "::selection": {
        "bg": ZenColor.PRIMARY,
        "color": ZenColor.WHITE,
    },
}

# Component Styles
class ZenStyle:
    BUTTON_PRIMARY = {
        "bg": ZenColor.PRIMARY,
        "color": ZenColor.WHITE,
        "border_radius": "12px",
        "padding": "12px 24px",
        "_hover": {"bg": "#7E9686"},
        "box_shadow": "0 2px 4px rgba(0,0,0,0.05)",
        "transition": "all 0.2s ease",
    }
    
    BUTTON_SECONDARY = {
        "bg": "transparent",
        "color": ZenColor.TEXT,
        "border": f"1px solid {ZenColor.SECONDARY}",
        "border_radius": "12px",
        "padding": "12px 24px",
        "_hover": {"bg": ZenColor.BG, "border_color": ZenColor.PRIMARY},
        "transition": "all 0.2s ease",
    }

    CARD = {
        "bg": ZenColor.WHITE,
        "border_radius": "16px",
        "padding": "24px",
        "box_shadow": "0 4px 12px rgba(0,0,0,0.03)",
        "border": f"1px solid {ZenColor.MUTED}",
    }

    INPUT = {
        "bg": ZenColor.WHITE,
        "border": f"1px solid {ZenColor.MUTED}",
        "border_radius": "12px",
        "padding": "16px",
        "min_height": "56px",
        "font_size": "16px",
        "line_height": "24px",
        "word_wrap": "break-word",
        "white_space": "pre-wrap",
        "_focus": {"border_color": ZenColor.PRIMARY, "box_shadow": "none"},
    }
