import os
import json
from datetime import datetime

CONTEXT_FILE_PATH = ".adhd/context.md"

class SyncManager:
    @staticmethod
    def ensure_context_file():
        """Ensure the .adhd directory and context.md file exist."""
        os.makedirs(os.path.dirname(CONTEXT_FILE_PATH), exist_ok=True)
        if not os.path.exists(CONTEXT_FILE_PATH):
            # Directly write initial content to avoid recursion
            initial_content = f"""# ADHD Copilot Context
Last Updated: {datetime.now().isoformat()}

## Status
Idle

## Current Task
Waiting for tasks...

## Details
Initial context created.

## Instructions for Gemini CLI
- Read this file to understand the current objective.
- When you finish a sub-task, update the Status to 'In Progress' or 'Completed'.
"""
            with open(CONTEXT_FILE_PATH, "w", encoding="utf-8") as f:
                f.write(initial_content)

    @staticmethod
    def write_context(status: str, task: str, details: str = ""):
        """Write the current context to the file."""
        # Only ensure directory exists, do not call ensure_context_file() to avoid recursion if file missing
        os.makedirs(os.path.dirname(CONTEXT_FILE_PATH), exist_ok=True)
        
        content = f"""# ADHD Copilot Context
Last Updated: {datetime.now().isoformat()}

## Status
{status}

## Current Task
{task}

## Details
{details}

## Instructions for Gemini CLI
- Read this file to understand the current objective.
- When you finish a sub-task, update the Status to 'In Progress' or 'Completed'.
"""
        with open(CONTEXT_FILE_PATH, "w", encoding="utf-8") as f:
            f.write(content)

    @staticmethod
    def read_context() -> dict:
        """Read the context file and parse it."""
        if not os.path.exists(CONTEXT_FILE_PATH):
            return {"status": "Unknown", "task": "None"}
        
        try:
            with open(CONTEXT_FILE_PATH, "r", encoding="utf-8") as f:
                content = f.read()
            
            # Simple parsing (could be more robust)
            lines = content.split('\n')
            status = "Unknown"
            task = "None"
            
            for i, line in enumerate(lines):
                if line.strip() == "## Status":
                    status = lines[i+1].strip() if i+1 < len(lines) else "Unknown"
                elif line.strip() == "## Current Task":
                    task = lines[i+1].strip() if i+1 < len(lines) else "None"
            
            return {"status": status, "task": task, "raw": content}
        except Exception as e:
            return {"status": "Error", "task": str(e)}
