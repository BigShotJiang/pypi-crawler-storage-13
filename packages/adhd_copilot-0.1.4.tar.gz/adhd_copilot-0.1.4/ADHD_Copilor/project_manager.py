import os
from typing import List, Dict

class ProjectManager:
    @staticmethod
    def list_projects(root_path: str) -> List[str]:
        """List subdirectories in the root path."""
        try:
            if not os.path.exists(root_path):
                return []
            return [d for d in os.listdir(root_path) if os.path.isdir(os.path.join(root_path, d)) and not d.startswith('.')]
        except Exception:
            return []

    @staticmethod
    def scan_directory(path: str = ".", max_depth: int = 2) -> str:
        """Scan the directory and return a summary of the structure."""
        structure = []
        try:
            for root, dirs, files in os.walk(path):
                # Calculate depth
                depth = root[len(path):].count(os.sep)
                if depth > max_depth:
                    continue
                
                # Ignore hidden directories
                dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__']
                
                indent = "  " * depth
                structure.append(f"{indent}{os.path.basename(root)}/")
                
                for file in files:
                    if not file.startswith('.') and not file.endswith('.pyc'):
                        structure.append(f"{indent}  {file}")
                        
            return "\n".join(structure)
        except Exception as e:
            return f"Error scanning directory: {str(e)}"

    @staticmethod
    def read_file(path: str) -> str:
        """Read the content of a specific file."""
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            return f"Error reading file: {str(e)}"

    @staticmethod
    def get_important_files(path: str = ".") -> Dict[str, str]:
        """Try to find and read important files like README.md."""
        important_files = {}
        targets = ["README.md", "requirements.txt", "package.json"]
        
        for target in targets:
            full_path = os.path.join(path, target)
            if os.path.exists(full_path):
                important_files[target] = ProjectManager.read_file(full_path)
                
        return important_files
