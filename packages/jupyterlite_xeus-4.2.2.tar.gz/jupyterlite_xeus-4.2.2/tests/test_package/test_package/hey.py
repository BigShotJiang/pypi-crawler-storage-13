print("Hey")
