pip install hatch

rm -rf dist
hatch build
git tag v0.1.13
git push --tags