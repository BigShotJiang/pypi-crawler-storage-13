from typing import Any, Type
from pydantic import BaseModel

from guardianhub_sdk.models.registry import get_registered_model
from guardianhub_sdk.registry.dynamic_loader import DynamicModelBuilder


class RegistryLoader:

    def load_by_name(self, model_name: str) -> Type[BaseModel]:
        """
        Loads a model that exists inside the shared SDK registry.
        """
        return get_registered_model(model_name)

    def load_from_schema(
        self,
        model_name: str,
        schema_json: dict
    ) -> Type[BaseModel]:
        """
        Loads a Pydantic model reconstructed from a schema JSON.
        """
        return DynamicModelBuilder.load_from_schema(model_name, schema_json)
