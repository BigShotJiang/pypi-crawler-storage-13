"""Schema patterns for SpecQL."""
