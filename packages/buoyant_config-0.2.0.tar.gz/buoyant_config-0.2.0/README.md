A modular and typed yaml configuration system with secret support

## Example Usage ##

```python
from typing import Annotated, Literal
from modular_config import ModularConfig
from modular_config.annotations.gsm import gsm_secret

class ConfigBase(ModularConfig):
    CONFIG_PATH = "settings.test.yaml"
    CONFIG_PATH_FROM_ENV_VAR = "SETTINGS_PATH"


class LoggingConfig(ConfigBase):
    CONFIG_SECTION = "logging"
    level: Literal["info", "warning", "error"]


class BackendConfig(ConfigBase):
    CONFIG_SECTION = "server"
    host: str
    api_key: Annotated[str, gsm_secret(project="buoyant-open-projects")]
```
