from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="codexglitch",
    version="0.1.2",
    author="codeXglitch Team",
    author_email="team@codeXglitch.ai",
    description="Offline static analysis tool for Python - detects bugs, performance issues, and security vulnerabilities",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/codeXglitch/codeXglitch",
    project_urls={
        "Bug Tracker": "https://github.com/codeXglitch/codeXglitch/issues",
        "Documentation": "https://github.com/codeXglitch/codeXglitch#readme",
    },
    keywords="static-analysis python bug-detection security performance offline",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    entry_points={
        "console_scripts": [
            "codeXglitch=codesense.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Quality Assurance",
    ],
    python_requires=">=3.8",
    install_requires=[],
)
