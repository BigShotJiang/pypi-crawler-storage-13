# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowLastPropertyValueRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'asset_id': 'str',
        'body': 'LastAssetPropertyValueRequest'
    }

    attribute_map = {
        'asset_id': 'asset_id',
        'body': 'body'
    }

    def __init__(self, asset_id=None, body=None):
        r"""ShowLastPropertyValueRequest

        The model defined in huaweicloud sdk

        :param asset_id: 资产ID
        :type asset_id: str
        :param body: Body of the ShowLastPropertyValueRequest
        :type body: :class:`huaweicloudsdkiotanalytics.v1.LastAssetPropertyValueRequest`
        """
        
        

        self._asset_id = None
        self._body = None
        self.discriminator = None

        self.asset_id = asset_id
        if body is not None:
            self.body = body

    @property
    def asset_id(self):
        r"""Gets the asset_id of this ShowLastPropertyValueRequest.

        资产ID

        :return: The asset_id of this ShowLastPropertyValueRequest.
        :rtype: str
        """
        return self._asset_id

    @asset_id.setter
    def asset_id(self, asset_id):
        r"""Sets the asset_id of this ShowLastPropertyValueRequest.

        资产ID

        :param asset_id: The asset_id of this ShowLastPropertyValueRequest.
        :type asset_id: str
        """
        self._asset_id = asset_id

    @property
    def body(self):
        r"""Gets the body of this ShowLastPropertyValueRequest.

        :return: The body of this ShowLastPropertyValueRequest.
        :rtype: :class:`huaweicloudsdkiotanalytics.v1.LastAssetPropertyValueRequest`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this ShowLastPropertyValueRequest.

        :param body: The body of this ShowLastPropertyValueRequest.
        :type body: :class:`huaweicloudsdkiotanalytics.v1.LastAssetPropertyValueRequest`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowLastPropertyValueRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
