# ============================================
# dsf_quantum_gps_sdk/__init__.py
# ============================================

"""
DSF Quantum GPS SDK
Optimización cuántica con Zero-Ancilla Amplitude Estimation.
"""

__version__ = "1.0.0"
__author__ = "Jaime Alexander Jimenez"
__email__ = "contacto@dsfuptech.cloud"

# ============================
# Importación del Cliente
# ============================
from ._client import QuantumGPSClient

# ============================
# Importación de Excepciones
# ============================
from .exceptions import (
    AccessSDKError,
    ValidationError,
    LicenseError,
    APIError,
)

# ============================
# Opcional: Exportar funciones cuánticas internas
# (si deseas que el usuario pueda llamarlas directamente)
# ============================
from .quantum_gps import (
    optimize_weights_quantum,
    build_cost_operator,
    run_zero_ancilla_qae,
)

# ============================
# Exponer API pública
# ============================
__all__ = [
    "QuantumGPSClient",
    "AccessSDKError",
    "ValidationError",
    "LicenseError",
    "APIError",
    "optimize_weights_quantum",
    "build_cost_operator",
    "run_zero_ancilla_qae",
]
