from typing import List, Dict, Optional, Tuple
import numpy as np
from scipy.optimize import minimize
from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import StatePreparation
from qiskit_algorithms import AmplitudeEstimation, EstimationProblem
from qiskit_aer import AerSimulator
from qiskit_aer.primitives import Sampler
import requests
import math


class QuantumGPS:
    def __init__(self, api_key: str, license_key: str, tier: str = "enterprise",
                 base_url: str = "https://your-gps-api.vercel.app"):
        self.api_key = api_key
        self.license_key = license_key
        self.tier = tier
        self.base_url = base_url
        self.sampler = Sampler()

    def _call_api(self, similitudes: List[float],
                  initial_weights: Optional[List[float]] = None,
                  initial_criticalities: Optional[List[float]] = None) -> Dict:
        payload = {
            "similitudes": similitudes,
            "license_key": self.license_key,
            "tier": self.tier
        }
        if initial_weights:
            payload["initial_weights"] = initial_weights
        if initial_criticalities:
            payload["initial_criticalities"] = initial_criticalities

        response = requests.post(
            self.base_url,
            json=payload,
            headers={"X-Api-Key": self.api_key},
            timeout=30
        )
        response.raise_for_status()
        return response.json()

    def _build_quantum_operator(self, similitudes: List[float], weights: List[float],
                                criticalities: List[float]) -> Tuple[QuantumCircuit, int]:
        n = len(similitudes)
        k = max(1, int(math.ceil(math.log2(max(1, n)))))

        wc = np.array(weights) * np.array(criticalities)
        probs = wc / (wc.sum() + 1e-12)

        amps = np.zeros(2**k)
        for i in range(n):
            amps[i] = math.sqrt(max(0, probs[i]))

        norm = np.linalg.norm(amps)
        amps = amps / norm if norm > 0 else np.array([1.0] + [0.0]*(2**k-1))

        qc = QuantumCircuit(k + 1)
        qc.append(StatePreparation(amps), range(k))

        for i in range(n):
            theta = 2.0 * math.asin(math.sqrt(max(0.0, min(1.0, similitudes[i]))))
            if abs(theta) < 1e-12:
                continue

            for b in range(k):
                if not ((i >> b) & 1):
                    qc.x(b)
            qc.mcry(theta, list(range(k)), k, None, mode='noancilla')
            for b in range(k):
                if not ((i >> b) & 1):
                    qc.x(b)

        return qc, k

    def _estimate_score(self, similitudes: List[float], weights: List[float],
                       criticalities: List[float], num_eval_qubits: int = 6) -> float:
        A_qc, k = self._build_quantum_operator(similitudes, weights, criticalities)
        problem = EstimationProblem(state_preparation=A_qc, objective_qubits=[k])
        qae = AmplitudeEstimation(num_eval_qubits=num_eval_qubits, sampler=self.sampler)
        return float(qae.estimate(problem).estimation)

    def _benchmark_ancillas(self, n_controls: int) -> Dict:
        backend = AerSimulator()

        n_ancillas = max(0, n_controls - 2)
        qc_trad = QuantumCircuit(n_controls + 1 + n_ancillas)
        qc_trad.mcx(list(range(n_controls)), n_controls,
                    list(range(n_controls + 1, n_controls + 1 + n_ancillas)))
        qc_trad_trans = transpile(qc_trad.decompose(reps=5), backend, optimization_level=0)

        qc_opt = QuantumCircuit(n_controls + 1)
        qc_opt.mcx(list(range(n_controls)), n_controls, mode='noancilla')
        qc_opt_trans = transpile(qc_opt.decompose(reps=5), backend, optimization_level=0)

        trad_qubits = qc_trad_trans.num_qubits
        opt_qubits = qc_opt_trans.num_qubits
        ancillas_saved = trad_qubits - opt_qubits
        trad_depth = qc_trad_trans.depth()
        opt_depth = qc_opt_trans.depth()

        return {
            "traditional_qubits": trad_qubits,
            "optimized_qubits": opt_qubits,
            "ancillas_saved": ancillas_saved,
            "ancilla_saving_ratio": ancillas_saved / trad_qubits if trad_qubits > 0 else 0.0,
            "traditional_depth": trad_depth,
            "optimized_depth": opt_depth,
            "depth_overhead": opt_depth - trad_depth if trad_depth else None
        }

    def optimize(self, similitudes: List[float],
                 initial_weights: Optional[List[float]] = None,
                 initial_criticalities: Optional[List[float]] = None,
                 include_ancilla_benchmark: bool = True) -> Dict:
        
        api_response = self._call_api(similitudes, initial_weights, initial_criticalities)
        prepared = api_response['prepared_vectors']
        config = api_response['optimization_config']

        n = len(similitudes)
        max_evals = config['max_evaluations']

        def objective(params):
            w = np.abs(params[:n])
            w = w / (np.sum(w) + 1e-12)
            c = np.abs(params[n:]) + 0.1
            return -self._estimate_score(similitudes, list(w), list(c),
                                         config['num_eval_qubits'])

        x0 = np.concatenate([
            np.array(prepared['normalized_weights']),
            np.array(prepared['initial_criticalities'])
        ])

        bounds = [(config['bounds']['weights'][0], config['bounds']['weights'][1])] * n + \
                 [(config['bounds']['criticalities'][0], config['bounds']['criticalities'][1])] * n

        result = minimize(objective, x0, method=config['method'], bounds=bounds,
                         options={'maxiter': max_evals})

        w_opt = np.abs(result.x[:n])
        w_opt = w_opt / (np.sum(w_opt) + 1e-12)

        output = {
            'weights': list(w_opt),
            'criticalities': list(np.abs(result.x[n:])),
            'score': -result.fun,
            'evaluations': result.nfev,
            'converged': result.success,
            'tier': api_response['tier']
        }

        if include_ancilla_benchmark:
            output['ancilla_efficiency'] = self._benchmark_ancillas(config['num_selector_qubits'])

        return output

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

