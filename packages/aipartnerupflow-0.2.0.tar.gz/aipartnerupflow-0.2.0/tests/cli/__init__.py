"""
CLI tests for aipartnerupflow
"""

