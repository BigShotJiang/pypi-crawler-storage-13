from dataclasses import field

from cashare.common.dname import url1
import datetime
import pandas as pd
from cashare.common.get_data import _retry_get
from cashare.common.var_date import check_date
from cashare.common.var_token import get_token

def us_min_data(ca_code,freq,start_date,end_date=str(datetime.date.today().strftime('%Y%m%d')),**kwargs):

    ls=check_date(start_date=start_date,end_date=end_date)
    if isinstance(ls, str):
        return ls
    else:
        start_date=ls[0]
        end_date=ls[1]
    params={
        "token": get_token(),
        "start_date":  start_date[:4] + "-" + start_date[4:6] + "-" + start_date[6:],
        "end_date": end_date[:4] + "-" + end_date[4:6] + "-" + end_date[6:],
        **kwargs,
    }
    li = f"{url1}/us/history/min/{ca_code}/{freq}"
    r = _retry_get(li, timeout=100,params=params)
    if type(r)==str:
        return r
    else:
        # print(r)
        if r.empty:
            return r
        else:
            r["date"] = pd.to_datetime(r["date"], unit='ms')
            return r
import time

def us_all_min_data(ca_code,freq,start_date,end_date=str(datetime.date.today().strftime('%Y%m%d')),delay=0.1,**kwargs):
    """
        获取指定时间段内的所有分钟数据

        Args:
            ca_code: 股票代码
            freq: 频率
            start_date: 开始日期
            end_date: 结束日期
            page_size: 每页大小
            delay: 请求间隔(秒)，避免频繁请求
        """


    all_data = []
    offset = 0
    page_size = 6000
    while True:
        try:
            print(f"正在获取{ca_code} 的 {freq} 第 {offset // page_size + 1} 页数据...")

            df = us_min_data(
                ca_code=ca_code,
                freq=freq,
                start_date=start_date,
                end_date=end_date,
                offset=str(offset)
            )
            # print(df)

            # 检查是否获取到数据
            if df is None or len(df) == 0:
                print(f"{ca_code} 的 {freq} 没有更多数据了")
                break

            all_data.append(df)
            # print(f"已获取 {len(df)} 条记录，累计 {sum(len(d) for d in all_data)} 条")

            # 如果获取的数据少于page_size，说明已经是最后一页
            if len(df) < page_size:
                break

            offset += page_size
            time.sleep(delay)  # 避免频繁请求

        except Exception as e:
            print(f"{ca_code} 的 {freq} 获取数据时出错: {e}")
            break

    if all_data:
        result_df = pd.concat(all_data, ignore_index=True)
        print(f"{ca_code} 的 {freq} 总共获取了 {len(result_df)} 条记录")
        return result_df
    else:
        print("未获取到任何数据")
        return pd.DataFrame()


if __name__ == '__main__':
    import cashare as ca
    ca.set_token('your_token')
    df=ca.us_min_data(ca_code="aapl", freq='1min',start_date='2023-06-05',end_date='2023-07-22',)
    print(df)
    df = ca.us_all_min_data(ca_code="aapl", freq='1min',start_date='2023-06-05',end_date='2023-07-22',)
    print(df)







