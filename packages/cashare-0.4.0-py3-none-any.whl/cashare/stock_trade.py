from cashare.common.dname import url1
import datetime
import pandas as pd
from cashare.common.get_data import _retry_get
from cashare.common.var_date import check_date
from cashare.common.var_token import get_token

def trade(ca_code,):


    # li = hg(ca_code=ca_code, token=get_token(),)
    li= url1 + '/us/real_stock_trade/b_a_trade/' + ca_code + '/' + get_token()
    r = _retry_get(li, timeout=100)
    if type(r)==str:
        return r
    else:
        # print(r)
        if r.empty:
            return r
        else:

            r["date"] = pd.to_datetime(r["date"], unit='ms').dt.tz_localize('UTC').dt.tz_convert('Asia/Shanghai').dt.tz_localize(None)
            new_order = ['ca_code', 'date','price', 'volume', ]
            r = r.reindex(columns=new_order)
            return r


if __name__ == '__main__':
    import cashare as ca
    ca.set_token('you_token')
    df = ca.trade(ca_code="aapl", )
    print(df)







