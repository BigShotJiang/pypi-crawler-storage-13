from dataclasses import field

from cashare.common.dname import url1
import datetime
import pandas as pd
from cashare.common.get_data import _retry_get
from cashare.common.var_date import check_date
from cashare.common.var_token import get_token
#
# def us_min_data(ca_code,freq,limit,offset,end_date=str(datetime.date.today().strftime('%Y%m%d')),start_date='19000101',):
#
#     ls=check_date(start_date=start_date,end_date=end_date)
#     if isinstance(ls, str):
#         return ls
#     else:
#         start_date=ls[0]
#         end_date=ls[1]
#
#     li = hg(ca_code=ca_code, token=get_token(), start_date=start_date, end_date=end_date,freq=freq, limit=limit, offset=offset)
#     r = _retry_get(li, timeout=100,)
#     if type(r)==str:
#         return r
#     else:
#         # print(r)
#         if r.empty:
#             return r
#         else:
#             r["date"] = pd.to_datetime(r["date"], unit='ms')
#             return r
#
#
# def hg(ca_code,freq,start_date,end_date,limit,offset,token):
#     start_date = start_date[:4] + "-" + start_date[4:6] + "-" + start_date[6:]
#     end_date = end_date[:4] + "-" + end_date[4:6] + "-" + end_date[6:]
#     g_url=url1+'/us/history/min/'+ca_code+'/'+freq+'/'+start_date+'/'+end_date+'/'+limit+'/'+offset+'/'+token
#     return g_url



def us_min_data(ca_code,freq,start_date,end_date=str(datetime.date.today().strftime('%Y%m%d')),**kwargs):

    ls=check_date(start_date=start_date,end_date=end_date)
    if isinstance(ls, str):
        return ls
    else:
        start_date=ls[0]
        end_date=ls[1]
    params={
        "token": get_token(),
        "start_date":  start_date[:4] + "-" + start_date[4:6] + "-" + start_date[6:],
        "end_date": end_date[:4] + "-" + end_date[4:6] + "-" + end_date[6:],
        **kwargs,
    }
    li = f"{url1}/us/history/min/{ca_code}/{freq}"
    r = _retry_get(li, timeout=100,params=params)
    if type(r)==str:
        return r
    else:
        # print(r)
        if r.empty:
            return r
        else:
            r["date"] = pd.to_datetime(r["date"], unit='ms')
            return r

if __name__ == '__main__':
    import cashare as ca
    ca.set_token('you_token')
    df = us_min_data(ca_code="aapl", freq='1min',start_date='2023-06-05',end_date='2025-09-22',limit='6000',offset='3',)
    print(df)







