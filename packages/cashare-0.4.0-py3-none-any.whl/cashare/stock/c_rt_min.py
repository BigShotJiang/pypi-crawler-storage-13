from cashare.common.dname import url1
import pandas as pd
from cashare.common.get_data import _retry_get
from cashare.common.var_token import get_token

def cs_rtmin_data(freq):
    li = handle_url(freq=freq, token=get_token())
    r =_retry_get(li,timeout=100)
    if str(r) == 'token无效或已超期':
        return r
    else:

        return r

def handle_url(freq,token):
    g_url = f"{url1}/csi/stock/min/rt_min/{freq}/{token}"
    return g_url
if __name__ == '__main__':
    import cashare as ca
    ca.set_token('you_token')
    df = cs_rtmin_data(freq='60000',)
    print(df)




