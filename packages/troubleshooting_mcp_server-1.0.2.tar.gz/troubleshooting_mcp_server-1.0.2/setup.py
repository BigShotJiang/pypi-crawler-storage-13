#!/usr/bin/env python3
"""
Setup script for troubleshooting-mcp-server
"""

from setuptools import setup, find_packages
import os

# Read the README file
def read_readme():
    with open("README.md", "r", encoding="utf-8") as fh:
        return fh.read()

# Read requirements
def read_requirements():
    with open("requirements.txt", "r", encoding="utf-8") as fh:
        return [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="troubleshooting-mcp-server",
    version="1.0.2",
    author="Samuel Amoh Ntim",
    author_email="amohntim123@gmail.com",
    description="A Model Context Protocol server for system troubleshooting and diagnostics",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/Amoh-Ntim/troubleshooting-mcp-server",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=read_requirements(),
    entry_points={
        "console_scripts": [
            "troubleshooting-mcp-server=troubleshooting_mcp_server.server:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)