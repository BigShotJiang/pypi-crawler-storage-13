"""
Troubleshooting MCP Server

A Model Context Protocol server for system troubleshooting and diagnostics.
"""

__version__ = "1.0.2"
__author__ = "Samuel Amoh Ntim"
__email__ = "your.email@example.com"