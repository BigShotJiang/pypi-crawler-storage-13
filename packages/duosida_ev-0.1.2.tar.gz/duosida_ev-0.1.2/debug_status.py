#!/usr/bin/env python3
"""Simple status debug - use the charger's get_status method"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from duosida_ev.charger import DuosidaCharger

def main():
    charger = DuosidaCharger(
        host="192.168.20.95",
        device_id="0310107112122360374",
        debug=True
    )

    if not charger.connect():
        print("Failed to connect")
        return

    print("Connected. Getting status...\n")

    try:
        status = charger.get_status()
        if status:
            print(f"conn_status: {status.conn_status} ({status.state})")
            print(f"voltage: {status.voltage:.2f} V")
            print(f"current: {status.current:.2f} A")
            print(f"power: {status.power:.2f} W")
            print(f"temperature_station: {status.temperature_station:.1f} °C")
            print(f"temperature_internal: {status.temperature_internal:.1f} °C")
            print(f"session_energy: {status.session_energy:.2f} kWh")
            print(f"timestamp: {status.timestamp}")
            print(f"\nCP voltage: {status.cp_voltage:.1f} V")

            # Also print the raw dict
            print("\n--- Raw to_dict() output ---")
            for key, value in status.to_dict().items():
                print(f"  {key}: {value}")
        else:
            print("Failed to get status")
    finally:
        charger.disconnect()
        print("\nDisconnected")

if __name__ == "__main__":
    main()
