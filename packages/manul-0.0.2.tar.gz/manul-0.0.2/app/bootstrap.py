from pathlib import Path

from manul.components.database.core import Database
from manul.components.logging.core import Logging
from manul.components.web_service.core import WebService
from manul.components.event_bus.core import EventBus
from manul.core import Loader

from app.settings import Settings

__all__: list[str] = [
    "App",
]


class App(Loader[Settings]):
    """Application loader."""

    Settings = Settings
    Components = {Logging, EventBus, WebService, Database}

    load_dotenv = True
    secrets_dir = Path(__file__).parent / "secrets/"
    environments = {"development", "production"}
    default_environment = "development"
    install_rich_traceback = True


@App.bootstrap("Set up Default DB models")
def attach_default_base(app: App) -> None:
    """Attach the base model to the default database connection."""
    from app.database.default.models.base import BaseModel

    connection = app.get(Database).get_connection("default")
    connection.base = BaseModel


@App.bootstrap("Set up Another DB models")
def attach_another_db_base(app: App) -> None:
    """Attach the base model to the another database connection."""
    from app.database.another_db.models.base import BaseModel

    connection = app.get(Database).get_connection("another_db")
    connection.base = BaseModel


@App.bootstrap("Set up WebService routers")
def attach_webservice_routers(app: App) -> None:
    """Attach routers to the webservice component."""
    from app.web_service.routers import event_bus, db, hello, robots

    app.get(WebService).add_router(hello.router)
    app.get(WebService).add_router(robots.router)
    app.get(WebService).add_router(db.router)
    app.get(WebService).add_router(event_bus.router)


@App.bootstrap("Set up EventBus routers")
def attach_event_routers(app: App) -> None:
    """Attach routers to the EventBus component."""
    from app.broker.routers import test

    app.get(EventBus).add_router(test.router)
