from typing import Annotated

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.bootstrap import App
from manul.components.database.core import Database

__all__: list[str] = [
    "DefaultDBSessionDependency",
    "AnotherDBSessionDependency",
]

database: Database = App().get(Database)


DefaultDBSessionDependency = Annotated[
    AsyncSession,
    Depends(
        database.get_connection("default").get_session,
    ),
]

AnotherDBSessionDependency = Annotated[
    AsyncSession,
    Depends(
        database.get_connection("another_db").get_session,
    ),
]
