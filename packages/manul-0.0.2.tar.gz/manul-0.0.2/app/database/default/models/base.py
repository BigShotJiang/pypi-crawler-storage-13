from sqlalchemy.orm import DeclarativeBase


class BaseModel(DeclarativeBase):
    """Base for the default database models."""

    __abstract__ = True
