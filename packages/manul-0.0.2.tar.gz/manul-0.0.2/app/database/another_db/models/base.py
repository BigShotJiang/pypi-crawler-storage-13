from sqlalchemy.orm import DeclarativeBase


class BaseModel(DeclarativeBase):
    """Base for the analytics database models."""

    __abstract__ = True
