from sqlalchemy import Column, DateTime, Integer, String

from app.database.another_db.models.base import BaseModel


class Event(BaseModel):
    __tablename__ = "events"

    id = Column(Integer, primary_key=True)
    event_type = Column(String(50))
    timestamp = Column(DateTime)
