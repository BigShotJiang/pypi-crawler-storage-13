from pydantic_settings import SettingsConfigDict

from manul.core import LoaderSettings

__all__: list[str] = [
    "Settings",
]


class Settings(LoaderSettings):
    """Application specific settings."""

    test_setting: str = "example_value"
    y: str = "value"
    z: str = "another_value"
    baris: int = 42

    model_config = SettingsConfigDict(
        extra="allow",
    )
