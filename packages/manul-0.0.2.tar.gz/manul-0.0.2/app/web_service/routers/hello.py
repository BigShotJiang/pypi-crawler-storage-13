"""Module documentation"""

from fastapi import APIRouter

router: APIRouter = APIRouter()


@router.get(
    path="/hello",
    summary="Hello Endpoint",
    description="Endpoint that returns a greeting message.",
)
async def test() -> dict[str, str]:
    return {"message": "Hello, World!"}
