from fastapi import APIRouter
from sqlalchemy import text

from app.database.dependencies import DefaultDBSessionDependency

router: APIRouter = APIRouter()


@router.get(
    path="/db-test",
    summary="Database Test Endpoint",
    description="Endpoint that tests the database connection.",
)
async def test_db_connection(db: DefaultDBSessionDependency) -> dict[str, int]:
    result = await db.execute(text("SELECT 1"))
    return {"result": result.scalar_one()}
