"""Robots.txt API documentation router."""

from fastapi.responses import PlainTextResponse
from fastapi.routing import APIRouter

router: APIRouter = APIRouter()


@router.get(
    path="/robots.txt",
    include_in_schema=False,
    response_class=PlainTextResponse,
)
async def get_robots_txt() -> PlainTextResponse:
    return PlainTextResponse(content="User-agent: *\nDisallow: /")
