from fastapi import APIRouter
from pydantic import BaseModel

from app.bootstrap import App
from manul.components.event_bus.core import EventBus
from app.broker.routers import test as broker_test_router

router = APIRouter(
    prefix="/event-bus",
    tags=["event-bus"],
)

TEST_TOPIC = "test_topic"
TEST_CHANNEL = f"{broker_test_router.router.prefix or ''}{TEST_TOPIC}"


class PublishRequest(BaseModel):
    message: str


@router.post(
    "/publish-test",
    summary="Publish FastStream test message",
    description="Publishes a message to the FastStream Redis topic so the subscriber can consume it.",
)
async def publish_test_message(payload: PublishRequest) -> dict[str, str]:
    application = App.instance
    event_component = application.get(EventBus)

    await event_component.publish(payload.message, channel=TEST_CHANNEL)

    return {
        "status": "published",
        "channel": TEST_CHANNEL,
        "message": payload.message,
    }
