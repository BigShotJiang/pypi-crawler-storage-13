#!/usr/bin/env python3

from app.bootstrap import App

if __name__ == "__main__":
    App().cli()
