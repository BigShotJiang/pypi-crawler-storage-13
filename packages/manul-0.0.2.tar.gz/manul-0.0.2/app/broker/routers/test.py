from faststream.redis.router import RedisRouter

router = RedisRouter()


@router.subscriber("test_topic")
async def test_subscriber(message: str) -> None:
    """Test subscriber that processes incoming messages."""
    print(f"Received message: {message}")


@router.publisher("test_topic")
async def test_publisher(message: str) -> None:
    """Test publisher that sends messages."""
    print(f"Publishing message: {message}")
