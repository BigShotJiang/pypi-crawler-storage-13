from manul.exceptions.base import manulException


class MissingConfigFileError(manulException):
    """Raised when a configuration YAML file is missing."""

    def __init__(self, filepath: str):
        super().__init__(f"Configuration file not found: {filepath}")


class SettingsCompositionError(manulException):
    """Raised when there is an error composing settings from multiple sources."""

    def __init__(self, details: str):
        super().__init__(f"Error composing settings: {details}")


class SettingsConflictError(manulException):
    """Raised when there is a conflict in settings values."""

    def __init__(self, setting_name: str):
        super().__init__(f"Conflict detected for setting: {setting_name}")
