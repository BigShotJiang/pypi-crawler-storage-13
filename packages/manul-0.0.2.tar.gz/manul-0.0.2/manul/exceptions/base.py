class manulException(Exception):
    """Base exception class for all manul framework errors."""

    def __init__(self, message: str = "An unexpected error occurred in the manul framework."):
        super().__init__(message)
        self.message = message

    def __str__(self) -> str:
        return f"[manulException] {self.message}"
