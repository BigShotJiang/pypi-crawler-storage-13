from typing import Iterable

from manul.exceptions.base import manulException


class InvalidEnvironmentError(manulException):
    """Raised when an environment variable or ENVIRONMENT value is invalid."""

    def __init__(self, env: str, valid_environments: Iterable[str]):
        super().__init__(
            f"Invalid environment: '{env}'. Must be one of {', '.join(sorted(valid_environments))}."
        )


class InvalidDefaultEnvironmentError(manulException):
    """Raised when the default environment is invalid."""

    def __init__(self, env: str, valid_environments: Iterable[str]):
        super().__init__(
            f"Invalid default environment: '{env}'. Must be one of {', '.join(sorted(valid_environments))}."
        )
