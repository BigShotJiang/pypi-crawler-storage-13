from manul.exceptions.base import manulException


class ComponentDefinitionError(manulException):
    """Raised when a component is improperly defined (e.g. missing Settings)."""

    def __init__(self, component: str, reason: str):
        super().__init__(f"Invalid component definition '{component}': {reason}")


class ComponentNotFoundError(manulException):
    """Raised when a requested component is not found in the loader."""

    def __init__(self, component_name: str, available: list[str]):
        available_str = ", ".join(available)
        super().__init__(
            f"Component '{component_name}' not found in Loader. Available components: [{available_str}]"
        )


class CircularDependencyError(manulException):
    """Raised when circular dependencies are detected between components."""

    def __init__(self, components: list[str]):
        components_str = " -> ".join(components)
        super().__init__(f"Circular dependency detected: {components_str}")
