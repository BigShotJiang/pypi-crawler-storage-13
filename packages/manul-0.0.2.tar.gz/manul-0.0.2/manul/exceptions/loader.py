from manul.exceptions.base import manulException


class ComponentRegistrationError(manulException):
    """Raised when a component fails to register or initialize inside the loader."""

    def __init__(self, component: str, reason: str):
        super().__init__(f"Failed to register component '{component}': {reason}")


class InvalidTracebackConfigError(manulException):
    """Raised when ``install_rich_traceback`` is configured with an invalid value."""

    def __init__(self, config: object):
        super().__init__(
            "install_rich_traceback must be a bool or mapping of environment flags, "
            f"got {config!r}",
        )
