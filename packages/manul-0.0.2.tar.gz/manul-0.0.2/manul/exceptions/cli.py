from manul.exceptions.base import manulException


class CLIConflictError(manulException):
    """Raised when multiple components register CLI commands with the same name."""

    def __init__(self, command: str, component: str):
        super().__init__(
            f"CLI conflict detected: command '{command}' already exists. Component '{component}' attempted to reuse it."
        )
