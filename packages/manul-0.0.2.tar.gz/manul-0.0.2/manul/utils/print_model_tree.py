"""Utility to print model tree structures."""

from typing import Any

from pydantic import BaseModel
from rich.console import Console
from rich.tree import Tree


def add_branch(node: Tree, data: Any) -> None:
    match data:
        case dict():
            for key, value in data.items():
                add_branch(node.add(str(key)), value)
        case list():
            for i, item in enumerate(data):
                add_branch(node.add(str(i)), item)
        case _:
            node.add(str(data))


def print_tree(*models: BaseModel | dict[str, Any], title: str = "⚙", highlight: bool = False) -> None:
    root = Tree(title, highlight=highlight)
    for model in models:
        if isinstance(model, BaseModel):
            add_branch(root, model.model_dump(mode="json"))
        else:
            add_branch(root, model)
    Console().print(root)
