from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from manul.core import Loader


def print_info(loader: "Loader[Any]") -> None:
    """Print application information."""

    print(f"""
                  Bootstrap File: {loader.import_path}
                     Environment: {loader.environment}
                    Project Root: {str(loader.project_root)}
                     Config File: {str(loader.configuration_file)}
               Config File (Env): {str(loader.environment_configuration_file)}
            Installed Components: {", ".join(loader.components.keys())}
    """)
