"""Utility functions for the manul framework."""


def print_about() -> None:
    """Display an animated 'About' message for the manul framework."""

    print("""
          Code refines the mind; clarity refines the code.
            — Engin Aygen <engin@aygen.org>
    """)
