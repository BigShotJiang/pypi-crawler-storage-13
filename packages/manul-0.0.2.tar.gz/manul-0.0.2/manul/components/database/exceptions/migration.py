from manul.components.database.exceptions.base import DatabaseError


class MigrationError(DatabaseError):
    """Raised when there is an error during database migration operations."""


class MigrationDirectoryError(MigrationError):
    """Raised when the migration directory cannot be created."""


class MigrationNotConfiguredError(MigrationError):
    """Raised when migrations are not configured for a database connection."""
