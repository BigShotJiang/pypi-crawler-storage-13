from manul.exceptions.base import manulException


class DatabaseError(manulException):
    """Raised for general database-related errors."""
