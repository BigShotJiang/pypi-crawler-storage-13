from manul.components.database.exceptions.base import DatabaseError


class ConnectionError(DatabaseError):
    """Raised when there is a connection error to the database."""


class ConnectionNotFoundError(ConnectionError):
    """Raised when a specified database connection is not found."""


class ConnectionNotConfiguredError(ConnectionError):
    """Raised when a database connection is not properly configured."""
