from pathlib import Path
from typing import Annotated

from pydantic import Field
from pydantic.config import ConfigDict
from pydantic.functional_serializers import PlainSerializer
from pydantic.functional_validators import AfterValidator
from pydantic.networks import AnyUrl, UrlConstraints

from manul.core import Settings


class EngineSettings(Settings):
    """Engine settings for database connection."""

    url: Annotated[
        Annotated[AnyUrl, UrlConstraints(host_required=False)],
        PlainSerializer(lambda v: str(v)),
    ]
    model_config = ConfigDict(
        extra="allow",
    )


class MigrationSettings(Settings):
    """Migration settings for database migrations."""

    script_location: Annotated[
        Path | None,
        Field(
            default=None,
        ),
    ]
    version_locations: Path
    truncate_slug_length: Annotated[
        int,
        Field(
            default=40,
        ),
    ]
    file_template: Annotated[
        str,
        Field(
            default="%%(rev)s_%%(slug)s",
        ),
        AfterValidator(
            lambda v: str(v.replace("%", "%%")),
        ),
    ]
    timezone: Annotated[
        str,
        Field(
            default="utc",
        ),
    ]
    output_encoding: Annotated[
        str,
        Field(
            default="utf-8",
        ),
    ]
    post_write_hooks: Annotated[
        dict[str, str] | None,
        Field(
            default={
                "hooks": "black",
                "black.type": "console_scripts",
                "black.entrypoint": "black",
                "black.options": "REVISION_SCRIPT_FILENAME",
            },
        ),
    ]
    model_config = ConfigDict(
        extra="forbid",
    )


class ConnectionSettings(Settings):
    """Database settings for connection."""

    engine: EngineSettings
    migrations: MigrationSettings | None = None
    model_config = ConfigDict(
        extra="allow",
    )


class ComponentSettings(Settings):
    """Component settings for Database component."""

    database: dict[str, ConnectionSettings]
