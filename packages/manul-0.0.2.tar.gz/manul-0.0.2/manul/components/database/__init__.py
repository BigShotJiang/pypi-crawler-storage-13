"""Database component for manul framework."""

from .core import Database

__all__ = ["Database"]
