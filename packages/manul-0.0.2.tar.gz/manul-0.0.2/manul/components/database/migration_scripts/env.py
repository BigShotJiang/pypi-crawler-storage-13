"""
Migration environment for Alembic, supporting asynchronous database engines.
"""

from asyncio import run

from alembic import context
from sqlalchemy.engine.base import Connection
from sqlalchemy.ext.asyncio import AsyncEngine

engine: AsyncEngine | None = context.config.attributes.get("engine")
metadata = context.config.attributes.get("target_metadata")


async def run_migrations_online() -> None:
    if engine:
        async with engine.connect() as connection:
            await connection.run_sync(do_run_migrations)
        return
    raise ValueError("Engine is not configured for online migrations")


def do_run_migrations(connection: Connection) -> None:
    context.configure(connection=connection, target_metadata=metadata, include_schemas=True)
    with context.begin_transaction():
        context.run_migrations()


run(run_migrations_online())
