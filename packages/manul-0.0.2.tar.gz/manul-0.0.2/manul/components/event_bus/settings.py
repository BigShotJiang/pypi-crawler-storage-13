from enum import Enum
from typing import Annotated, List, Literal

from pydantic.fields import Field
from pydantic.networks import AnyUrl
from pydantic.functional_serializers import PlainSerializer

from faststream.asyncapi.schema.info import Contact, ContactDict, License, LicenseDict
from faststream.asyncapi.schema.utils import AnyHttpUrl, ExternalDocs, ExternalDocsDict, Tag, TagDict

from manul.core import Settings


class BrokerType(str, Enum):
    KAFKA = "kafka"
    RABBITMQ = "rabbitmq"
    REDIS = "redis"
    NATS = "nats"


class ServerSettings(Settings):
    """Uvicorn server configuration settings."""

    host: Annotated[
        str,
        Field(
            default="0.0.0.0",
        ),
    ]
    port: Annotated[
        int,
        Field(
            default=80,
            ge=1,
            le=65535,
        ),
    ]
    reload: Annotated[
        bool,
        Field(
            default=False,
        ),
    ]
    workers: Annotated[
        int,
        Field(
            default=1,
            ge=1,
        ),
    ]


class AppSettings(Settings):
    """FastStream app-level configuration schema."""

    title: Annotated[
        str,
        Field(
            default="FastStream Application",
            description="App title",
        ),
    ]
    version: Annotated[
        str,
        Field(
            default="1.0.0",
            description="App version",
        ),
    ]
    description: Annotated[
        str | None,
        Field(
            default=None,
            description="Short description of the app",
        ),
    ]
    asyncapi_path: Annotated[
        str | None,
        Field(
            default=None,
            description="Path to the AsyncAPI document",
        ),
    ]
    terms_of_service: Annotated[
        AnyHttpUrl | None,
        Field(
            default=None,
            description="Terms of service URL",
        ),
    ]
    license: Annotated[
        License | LicenseDict | dict[str, str] | None,
        Field(
            default=None,
            description="License information for AsyncAPI metadata.",
        ),
    ]
    contact: Annotated[
        Contact | ContactDict | dict[str, str] | None,
        Field(
            default=None,
            description="Contact information for AsyncAPI metadata.",
        ),
    ]
    tags: Annotated[
        list[Tag | TagDict | dict[str, str]] | None,
        Field(
            default=None,
            description="AsyncAPI tags describing channels/messages.",
        ),
    ]
    external_docs: Annotated[
        ExternalDocs | ExternalDocsDict | dict[str, str] | None,
        Field(
            default=None,
            description="External documentation references for AsyncAPI.",
        ),
    ]
    identifier: Annotated[
        str | None,
        Field(
            default=None,
            description="Unique identifier for the FastStream application.",
        ),
    ]


class KafkaBrokerSettings(Settings):
    type: Annotated[
        Literal[BrokerType.KAFKA],
        Field(
            exclude=True,
            default=BrokerType.KAFKA,
        ),
    ]
    bootstrap_servers: Annotated[
        str,
        Field(
            description="Kafka broker address",
        ),
    ]


class RabbitBrokerSettings(Settings):
    type: Annotated[
        Literal[BrokerType.RABBITMQ],
        Field(
            exclude=True,
            default=BrokerType.RABBITMQ,
        ),
    ]
    url: Annotated[
        AnyUrl,
        Field(
            description="AMQP URL",
        ),
        PlainSerializer(lambda v: str(v)),
    ]


class RedisBrokerSettings(Settings):
    type: Annotated[
        Literal[BrokerType.REDIS],
        Field(
            exclude=True,
            default=BrokerType.REDIS,
        ),
    ]
    url: Annotated[
        AnyUrl,
        Field(
            description="Redis connection URL",
        ),
        PlainSerializer(lambda v: str(v)),
    ]


class NatsBrokerSettings(Settings):
    type: Annotated[
        Literal[BrokerType.NATS],
        Field(
            exclude=True,
            default=BrokerType.NATS,
        ),
    ]
    servers: Annotated[
        List[AnyUrl],
        Field(
            default_factory=lambda: [
                "nats://localhost:4222",
            ]
        ),
        PlainSerializer(lambda v: [str(url) for url in v]),
    ]
    name: Annotated[
        str,
        Field(
            default="faststream-nats-client",
        ),
    ]


class EventBusSettings(Settings):
    """Settings for the FastStream broker integration."""

    server: ServerSettings
    app: AppSettings
    broker: Annotated[
        KafkaBrokerSettings | RabbitBrokerSettings | RedisBrokerSettings | NatsBrokerSettings,
        Field(
            discriminator="type",
            description="Concrete broker configuration definition.",
        ),
    ]
    standalone: Annotated[
        bool,
        Field(
            default=True,
            description="Whether to run the broker component in standalone mode.",
        ),
    ]


class ComponentSettings(Settings):
    """Component settings for EventBus component."""

    event_bus: EventBusSettings
