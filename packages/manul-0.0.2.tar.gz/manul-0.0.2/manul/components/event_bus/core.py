"""EventBus component implementation built on FastStream brokers."""

from typing import Annotated, Any, Callable
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from logging import getLogger

from faststream.kafka import KafkaBroker
from faststream.rabbit import RabbitBroker
from faststream.redis import RedisBroker
from faststream.nats import NatsBroker
from faststream.broker.core.usecase import BrokerUsecase
from faststream.broker.router import BrokerRouter
from faststream.broker.types import BrokerMiddleware
from faststream.asgi.app import AsgiFastStream


from typer import Typer, Option
from uvicorn import run as uvicorn_run
from uvicorn.config import LOGGING_CONFIG

from manul.components.event_bus.settings import BrokerType, ComponentSettings
from manul.core import Component, LoaderSettings
from manul.components.logging.core import Logging
from manul.components.web_service.core import WebService

__all__: list[str] = [
    "EventBus",
]


class EventBus(Component[ComponentSettings, LoaderSettings]):
    """Message broker component built around FastStream.

    EventBus owns the underlying FastStream broker instance, wires routers and
    middlewares declared across the application, and exposes both standalone
    worker execution and embedded FastAPI lifecycle integration. When
    ``standalone`` mode is enabled it behaves like a dedicated worker process
    with its own Typer command (``eventbus`` / alias ``eb``); otherwise it
    registers a FastAPI lifespan handler so publish/subscribe flows run inside
    the web application without a separate worker.

    Attributes:
        Settings: Component settings model describing FastStream configuration.
        aliases: CLI aliases registered along with the primary ``eventbus`` name.
        _standalone: Flag indicating whether we run as dedicated worker only.
        _broker: Concrete FastStream broker implementation resolved from settings.
        _routers: Collection of ``FastStream`` routers awaiting registration.
        _middlewares: List of broker middlewares awaiting registration.

    Example:
        >>> from app.bootstrap import App
        >>> event_bus = App.instance.get(EventBus)
        >>> await event_bus.publish({"hello": "world"}, channel="/demo")
    """

    Settings = ComponentSettings

    aliases = ("eb",)

    def init(self):
        self._standalone = self.settings.event_bus.standalone
        self._broker = self._create_broker_instance()
        self._routers: list[BrokerRouter] = []
        self._middlewares: list[BrokerMiddleware[Any]] = []

    def post_init(self) -> None:
        super().post_init()
        if self.loader.has(WebService):
            webservice = self.loader.get(WebService)
            webservice.add_lifespan(self._fastapi_lifespan)

    def app_factory(self) -> AsgiFastStream:
        """Register the broker with the FastStream application."""
        self._configure_broker()

        faststream_kwargs = self.settings.event_bus.app.model_dump(mode="dict")
        faststream_kwargs["logger"] = getLogger("event_bus")

        return AsgiFastStream(self._broker, **faststream_kwargs)

    def add_router(self, router: BrokerRouter) -> None:
        """Add a router to the FastStream application."""
        self._routers.append(router)

    def add_middleware(self, middleware: BrokerMiddleware[Any]) -> None:
        """Add a middleware to the FastStream application."""
        self._middlewares.append(middleware)

    @property
    def broker(self) -> BrokerUsecase[Any, Any]:
        """Expose the underlying FastStream broker instance."""
        return self._broker

    async def publish(self, *args: Any, **kwargs: Any) -> Any:
        """Proxy publish calls to the underlying broker."""
        return await self._broker.publish(*args, **kwargs)

    def _create_broker_instance(self) -> BrokerUsecase[Any, Any]:
        """Create a broker instance based on the configuration type."""
        broker_kwargs = self.settings.event_bus.broker.model_dump(mode="dict")
        broker_kwargs["logger"] = getLogger("event_bus.broker")
        broker_type: BrokerType = self.settings.event_bus.broker.type

        match broker_type:
            case BrokerType.KAFKA:
                return KafkaBroker(**broker_kwargs)
            case BrokerType.RABBITMQ:
                return RabbitBroker(**broker_kwargs)
            case BrokerType.REDIS:
                return RedisBroker(**broker_kwargs)
            case BrokerType.NATS:
                return NatsBroker(**broker_kwargs)
            case _:
                raise ValueError(
                    f"Unsupported broker type: {broker_type}",
                )

    def _configure_broker(self) -> None:
        for router in self._routers:
            self._broker.include_router(router)
        for middleware in self._middlewares:
            self._broker.add_middleware(middleware)

    @asynccontextmanager
    async def _fastapi_lifespan(self, _: Any) -> AsyncIterator[None]:
        """FastAPI lifespan handler to manage broker lifecycle."""
        try:
            if not self._standalone:
                self._configure_broker()

            await self._broker.start()
        except Exception as e:
            self.loader.logger.error(
                f"Failed to start message broker: {e}",
            )
            raise

        try:
            yield
        finally:
            try:
                await self._broker.close()
            except Exception as e:
                self.loader.logger.warning(
                    f"Failed to gracefully close message broker: {e}",
                )

    def _create_cli(self) -> Typer | None:
        """Register CLI commands for the EventBus component."""

        if not self._standalone:
            return None

        cli = Typer(name="eventbus", help="Commands for managing the EventBus component.")

        @cli.command(
            name="run",
            help="Run the ASGI application with Uvicorn.",
        )
        def run(
            host: Annotated[
                str,
                Option(
                    help="Host to bind.",
                ),
            ] = self.settings.event_bus.server.host,
            port: Annotated[
                int,
                Option(
                    help="Port to bind.",
                ),
            ] = self.settings.event_bus.server.port,
            reload: Annotated[
                bool,
                Option(
                    help="Enable auto-reload.",
                ),
            ] = self.settings.event_bus.server.reload,
            workers: Annotated[
                int,
                Option(
                    help="Number of worker processes.",
                ),
            ] = self.settings.event_bus.server.workers,
        ) -> None:
            """Run the ASGI application with Uvicorn."""

            log_config: dict[str, Any] = LOGGING_CONFIG
            if self.loader.has(Logging):
                logging: Logging = self.loader.get(Logging)
                log_config = logging.settings.logging.model_dump(mode="json")

            reload_includes: list[str] | None = None
            if reload:
                reload_includes = ["config/*.yaml"]

            app: str | Callable[[], AsgiFastStream] = self.app_factory
            if workers > 1 or reload:
                app = f"{self.loader.import_path}:{self.loader.__class__.__name__}.instance.EventBus.app_factory"

            uvicorn_run(
                app,
                host=host,
                port=port,
                reload=reload,
                workers=workers,
                log_config=log_config,
                reload_includes=reload_includes,
                factory=True,
            )

        return cli
