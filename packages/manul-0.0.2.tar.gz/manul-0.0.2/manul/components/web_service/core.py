"""WebService component wrapping FastAPI/Uvicorn configuration."""

from collections.abc import AsyncIterator, Callable
from contextlib import AbstractAsyncContextManager, AsyncExitStack, asynccontextmanager
from json import dumps
from typing import Annotated, Any

from fastapi import FastAPI
from fastapi.routing import APIRouter
from rich import print_json
from typer import Option, Typer
from uvicorn import run as uvicorn_run
from uvicorn.config import LOGGING_CONFIG

from manul.components.web_service.settings import ComponentSettings
from manul.components.logging.core import Logging
from manul.core import Component, LoaderSettings


class WebService(Component[ComponentSettings, LoaderSettings]):
    """HTTP service component backed by FastAPI/Uvicorn.

    WebService collects routers, middlewares, and lifespan hooks from other
    components, builds the FastAPI application object, and exposes Typer-based
    management commands (``webservice`` / ``ws``) for running the ASGI server or
    dumping the OpenAPI schema. It centralizes all FastAPI/Uvicorn configuration
    to keep web related concerns isolated from the rest of the loader.

    Attributes:
        Settings: Component settings model containing FastAPI/Uvicorn options.
        aliases: CLI aliases (``ws``) registered alongside the ``webservice`` command.

    Example:
        >>> from app.bootstrap import App
        >>> web = App.instance.get(WebService)
        >>> fastapi_app = web.app_factory()
    """

    Settings = ComponentSettings

    aliases = ("ws",)

    def init(self) -> None:
        self._routers: list[APIRouter] = []
        self._middlewares: dict[type[Any], dict[str, Any]] = {}
        self._lifespan_handlers: list[Callable[[FastAPI], AbstractAsyncContextManager[None]]] = []

    def app_factory(self) -> FastAPI:
        """Create and return the FastAPI application."""
        fastapi_kwargs = self.settings.web_service.app.model_dump(mode="dict")

        if self._lifespan_handlers:

            @asynccontextmanager
            async def lifespan(app: FastAPI) -> AsyncIterator[None]:
                async with AsyncExitStack() as stack:
                    for handler in self._lifespan_handlers:
                        await stack.enter_async_context(handler(app))
                    yield

            fastapi_kwargs["lifespan"] = lifespan

        app = FastAPI(**fastapi_kwargs)

        for router in self._routers:
            app.include_router(router)
        for middleware, options in self._middlewares.items():
            app.add_middleware(middleware, **options)

        return app

    def add_lifespan(self, handler: Callable[[FastAPI], AbstractAsyncContextManager[None]]) -> None:
        """Register a custom FastAPI lifespan handler."""
        self._lifespan_handlers.append(handler)

    def add_router(self, router: APIRouter) -> None:
        """Add a router to the FastAPI application."""
        self._routers.append(router)

    def add_middleware(self, middleware: type[Any], **options: Any) -> None:
        """Add a middleware to the FastAPI application."""
        self._middlewares[middleware] = options

    @property
    def routers(self) -> list[APIRouter]:
        """Get the list of registered routers."""
        return self._routers

    @property
    def middlewares(self) -> dict[type[Any], dict[str, Any]]:
        """Get the dictionary of registered middlewares and their options."""
        return self._middlewares

    def _create_cli(self) -> Typer:
        """Register CLI commands for the WebService component."""

        cli = Typer(name="webservice", help="Commands for managing the WebService component.")

        @cli.command(
            name="run",
            help="Run the ASGI application with Uvicorn.",
        )
        def run(
            host: Annotated[
                str,
                Option(
                    help="Host to bind.",
                ),
            ] = self.settings.web_service.server.host,
            port: Annotated[
                int,
                Option(
                    help="Port to bind.",
                ),
            ] = self.settings.web_service.server.port,
            reload: Annotated[
                bool,
                Option(
                    help="Enable auto-reload.",
                ),
            ] = self.settings.web_service.server.reload,
            workers: Annotated[
                int,
                Option(
                    help="Number of worker processes.",
                ),
            ] = self.settings.web_service.server.workers,
        ) -> None:
            """Run the ASGI application with Uvicorn."""

            log_config: dict[str, Any] = LOGGING_CONFIG
            if self.loader.has(Logging):
                logging: Logging = self.loader.get(Logging)
                log_config = logging.settings.logging.model_dump(mode="json")

            reload_includes: list[str] | None = None
            if reload:
                reload_includes = ["config/*.yaml"]

            app: str | Callable[[], FastAPI] = self.app_factory
            if workers > 1 or reload:
                app = f"{self.loader.import_path}:{self.loader.__class__.__name__}.instance.WebService.app_factory"

            uvicorn_run(
                app,
                host=host,
                port=port,
                reload=reload,
                workers=workers,
                log_config=log_config,
                reload_includes=reload_includes,
                factory=True,
            )

        @cli.command(
            name="openapi",
            help="Generate OpenAPI schema.",
        )
        def generate_openapi() -> None:
            print_json(dumps(self.app_factory().openapi(), indent=2))

        return cli
