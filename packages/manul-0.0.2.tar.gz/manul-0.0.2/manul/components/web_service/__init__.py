from .core import WebService

__all__ = ["WebService"]
