from typing import Annotated, Any

from pydantic import Field
from pydantic.functional_validators import AfterValidator

from manul.core import Settings

__all__: list[str] = [
    "ComponentSettings",
    "AppSettings",
    "ServerSettings",
    "WebServiceSettings",
]


class ServerSettings(Settings):
    """Uvicorn server configuration settings."""

    host: Annotated[
        str,
        Field(
            default="0.0.0.0",
        ),
    ]
    port: Annotated[
        int,
        Field(
            default=80,
            ge=1,
            le=65535,
        ),
    ]
    reload: Annotated[
        bool,
        Field(
            default=False,
        ),
    ]
    workers: Annotated[
        int,
        Field(
            default=1,
            ge=1,
        ),
    ]


class AppSettings(Settings):
    """FastAPI application configuration settings."""

    debug: Annotated[
        bool,
        Field(
            default=False,
        ),
    ]
    title: str = "manul API"
    summary: Annotated[
        str | None,
        Field(
            default=None,
        ),
    ]
    description: Annotated[
        str,
        Field(
            default="",
        ),
    ]
    openapi_url: Annotated[
        str | None,
        Field(default=None),
        AfterValidator(lambda v: v.rstrip("/") if v else v),
    ]
    openapi_tags: Annotated[
        list[dict[str, Any]] | None,
        Field(
            default=None,
        ),
    ]
    docs_url: Annotated[
        str | None,
        Field(default=None),
        AfterValidator(lambda v: v.rstrip("/") if v else v),
    ]
    redoc_url: Annotated[
        str | None,
        Field(default=None),
        AfterValidator(lambda v: v.rstrip("/") if v else v),
    ]
    rapidoc_url: Annotated[
        str | None,
        Field(default=None),
        AfterValidator(lambda v: v.rstrip("/") if v else v),
    ]
    scalar_url: Annotated[
        str | None,
        Field(default=None),
        AfterValidator(lambda v: v.rstrip("/") if v else v),
    ]
    swagger_ui_parameters: Annotated[
        dict[str, Any] | None,
        Field(
            default=None,
        ),
    ]
    servers: Annotated[
        list[dict[str, str]] | None,
        Field(
            default=None,
        ),
    ]


class WebServiceSettings(Settings):
    """Composite accessor for FastAPI and Uvicorn settings."""

    server: ServerSettings
    app: AppSettings


class ComponentSettings(Settings):
    """WebService component settings."""

    web_service: WebServiceSettings
