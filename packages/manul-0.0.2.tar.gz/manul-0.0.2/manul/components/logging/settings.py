from typing import Annotated, Any

from pydantic import Field

from manul.core import Settings

__all__: list[str] = [
    "ComponentSettings",
]


class LoggingSettings(Settings):
    """Logging component settings."""

    version: Annotated[
        int,
        Field(
            default=1,
        ),
    ]
    disable_existing_loggers: Annotated[
        bool,
        Field(
            default=False,
        ),
    ]
    formatters: Annotated[
        dict[str, dict[str, Any]],
        Field(
            default={
                "default": {
                    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                },
            },
        ),
    ]
    handlers: Annotated[
        dict[str, dict[str, Any]],
        Field(
            default={
                "console": {
                    "class": "logging.StreamHandler",
                    "formatter": "default",
                }
            },
        ),
    ]
    root: Annotated[
        dict[str, Any],
        Field(
            default={
                "level": "INFO",
                "handlers": ["console"],
            },
        ),
    ]
    loggers: Annotated[
        dict[str, dict[str, Any]],
        Field(
            default={},
        ),
    ]


class ComponentSettings(Settings):
    """Component settings for Logging component."""

    logging: Annotated[
        LoggingSettings,
        Field(
            default_factory=LoggingSettings,
        ),
    ]
