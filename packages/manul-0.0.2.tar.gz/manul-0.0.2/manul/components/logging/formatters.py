"""Log module."""

from logging import Formatter, LogRecord

__all__: list[str] = [
    "ExtendedFormatter",
]


class ExtendedFormatter(Formatter):
    """Extended log formatter to include additional fields."""

    _excluded_fields = {
        "name",
        "msg",
        "args",
        "levelname",
        "levelno",
        "pathname",
        "filename",
        "module",
        "exc_info",
        "exc_text",
        "stack_info",
        "lineno",
        "funcName",
        "created",
        "msecs",
        "relativeCreated",
        "thread",
        "threadName",
        "processName",
        "process",
        "message",
        "asctime",
        "color_message",
    }

    def format(self, record: LogRecord) -> str:
        formatted = super().format(record)

        extra_parts: list[str] = []
        for key, value in record.__dict__.items():
            if key in self._excluded_fields:
                continue
            if value in (None, ""):
                continue
            extra_parts.append(f"{key}={value}")

        if extra_parts:
            return f"{formatted} {' '.join(extra_parts)}"
        return formatted
