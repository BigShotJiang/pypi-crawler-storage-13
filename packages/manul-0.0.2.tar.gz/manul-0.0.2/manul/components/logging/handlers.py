from logging import NOTSET
from typing import Any

from rich.console import Console
from rich.logging import RichHandler
from rich.style import Style
from rich.theme import Theme

__all__: list[str] = [
    "ExtendedRichHandler",
]


class ExtendedRichHandler(RichHandler):
    """Extended Rich log handler with customizable console and theme."""

    def __init__(
        self,
        level: int = NOTSET,
        console: Console | None = None,
        *,
        show_time: bool = True,
        omit_repeated_times: bool = True,
        show_level: bool = True,
        show_path: bool = True,
        enable_link_path: bool = True,
        markup: bool = True,
        rich_tracebacks: bool = True,
        tracebacks_width: int | None = None,
        tracebacks_extra_lines: int = 3,
        tracebacks_theme: str | None = None,
        tracebacks_word_wrap: bool = True,
        tracebacks_show_locals: bool = False,
        locals_max_length: int = 10,
        locals_max_string: int = 80,
        log_time_format: str = "[%x %X]",
        keywords: list[str] | None = None,
        theme: dict[str, dict[str, Any]] | None = None,
    ):
        if console is None:
            if theme:
                console = Console(
                    theme=Theme({key: Style(**value) for key, value in theme.items()}),
                )
            else:
                console = Console()

        super().__init__(
            level=level,
            console=console,
            show_time=show_time,
            omit_repeated_times=omit_repeated_times,
            show_level=show_level,
            show_path=show_path,
            enable_link_path=enable_link_path,
            markup=markup,
            rich_tracebacks=rich_tracebacks,
            tracebacks_width=tracebacks_width,
            tracebacks_extra_lines=tracebacks_extra_lines,
            tracebacks_theme=tracebacks_theme,
            tracebacks_word_wrap=tracebacks_word_wrap,
            tracebacks_show_locals=tracebacks_show_locals,
            locals_max_length=locals_max_length,
            locals_max_string=locals_max_string,
            log_time_format=log_time_format,
            keywords=keywords,
        )
