"""Logging component centralizing dictConfig installation."""

from logging.config import dictConfig

from manul.components.logging.settings import ComponentSettings
from manul.core import Component, LoaderSettings

__all__: list[str] = [
    "Logging",
]


class Logging(Component[ComponentSettings, LoaderSettings]):
    """Central logging configuration component.

    Consumes the declarative logging settings, installs the dictConfig at loader
    startup, and provides a single place for adjusting formatter/handler options
    that the rest of the components rely on. Does not expose CLI commands but is
    responsible for ensuring all loggers share the same structure.

    Attributes:
        Settings: Component settings model for logging configuration.
        aliases: Empty tuple; logging has no CLI entry point.

    Example:
        >>> logging_component = App.instance.get(Logging)
        >>> logging_component.settings.logging.dict()
    """

    Settings = ComponentSettings

    def init(self) -> None:
        dictConfig(
            self.settings.logging.model_dump(
                mode="json",
            ),
        )

    def _create_cli(self) -> None:
        """Logging component does not provide CLI commands."""
        return None
