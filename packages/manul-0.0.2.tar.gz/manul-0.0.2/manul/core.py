"""Core loader and component abstractions for the manul framework.

Defines the typed ``Settings``, ``Component``, and ``Loader`` bases that power
environment-aware bootstrap flows, dependency-driven component orchestration,
Pydantic settings composition, and Typer CLI exposure with Rich traceback and
dotenv integration.
"""

from __future__ import annotations

from abc import ABC, ABCMeta, abstractmethod
from inspect import getfile
from os import environ
from pathlib import Path
from logging import Logger, getLogger
from collections import deque
from enum import Enum, auto
from threading import RLock
from collections.abc import Mapping
from typing import Annotated, Any, ClassVar, Callable, Generic, TypeVar, cast, final, overload, override
from functools import lru_cache

try:
    from typing_extensions import Doc
except ImportError:  # pragma: no cover

    def Doc(description: str) -> str:  # type: ignore[misc]
        return description


from dotenv import load_dotenv
from pydantic import BaseModel
from pydantic_settings import BaseSettings, PydanticBaseSettingsSource, sources
from rich.traceback import install as install_rich_traceback
from typer import Option, Typer
from click.exceptions import UsageError

from manul.exceptions.cli import CLIConflictError
from manul.exceptions.component import ComponentDefinitionError, ComponentNotFoundError, CircularDependencyError
from manul.exceptions.environment import InvalidDefaultEnvironmentError, InvalidEnvironmentError
from manul.exceptions.loader import ComponentRegistrationError, InvalidTracebackConfigError
from manul.exceptions.settings import MissingConfigFileError, SettingsCompositionError, SettingsConflictError
from manul.utils.print_about import print_about
from manul.utils.print_info import print_info
from manul.utils.print_model_tree import print_tree

__all__: list[str] = [
    "Settings",
    "Component",
    "Loader",
    "LoaderSettings",
]

T_Settings = TypeVar("T_Settings", bound="Settings")
T_LoaderSettings = TypeVar("T_LoaderSettings", bound="LoaderSettings")
T_Component = TypeVar("T_Component", bound="Component[Settings, LoaderSettings]")
T_Loader = TypeVar("T_Loader", bound="Loader[LoaderSettings]")


class Settings(BaseModel):
    """Base settings class for application-wide configuration models."""


class Component(Generic[T_Settings, T_LoaderSettings], ABC):
    """Base class for loader-aware application components.

    Components are the building blocks of manul applications. They encapsulate
    related functionality like database connections, web services, message brokers,
    etc. Components can declare dependencies on other components to ensure proper
    initialization order.

    Each component has access to:
    - Shared application settings
    - The loader instance for cross-component communication
    - Optional CLI subcommands
    - Lifecycle hooks (init, post_init)

    Components are automatically instantiated and configured by the loader during
    application startup, with dependency resolution ensuring correct initialization
    order.
    """

    Settings: ClassVar[
        Annotated[
            type[Settings],
            Doc("Settings model used by the component; override with a subclass of Settings."),
        ]
    ] = Settings

    dependencies: ClassVar[
        Annotated[
            set[type["Component[Any, Any]"]],
            Doc("Set of component classes that must be initialized before this component."),
        ]
    ] = set()

    aliases: ClassVar[
        Annotated[
            tuple[str, ...],
            Doc("Optional CLI command aliases registered alongside the primary name."),
        ]
    ] = ()

    @final
    def __init__(self, loader: Loader[T_LoaderSettings]) -> None:
        """Initialize the component with a loader instance.

        Args:
            loader: The loader that owns and configures the component.

        """
        self._loader: Loader[T_LoaderSettings] = loader
        self._settings: T_Settings = cast(T_Settings, loader.settings)
        self._cli: Typer | None = None

        self.init()

    @abstractmethod
    def init(self) -> None:
        """Perform component-specific initialization logic."""

    def post_init(self) -> None:
        """Perform component-specific post-initialization logic."""

    @property
    def loader(self) -> Loader[T_LoaderSettings]:
        """Get the loader instance that owns this component."""
        return self._loader

    @property
    def settings(self) -> T_Settings:
        """Get the component's settings instance."""
        return self._settings

    @property
    def cli(self) -> Typer | None:
        """Lazy Typer command group exposed by the component, or None when unavailable."""
        if self._cli is None:
            self._cli = self._create_cli()
        return self._cli

    @abstractmethod
    def _create_cli(self) -> Typer | None:
        """Build a Typer command group for the component."""


class LoaderState(Enum):
    """Loader singleton instance state tracking."""

    NOT_CREATED = auto()
    INITIALIZING = auto()
    READY = auto()


class LoaderSettings(Settings, BaseSettings):
    """Settings base class that merges Pydantic and manul semantics."""

    custom_sources: ClassVar[
        Annotated[
            tuple[PydanticBaseSettingsSource, ...],
            Doc("Additional Pydantic settings sources injected ahead of defaults."),
        ]
    ] = ()

    @override
    @classmethod
    def settings_customise_sources(cls, *args: Any, **kwargs: Any) -> tuple[PydanticBaseSettingsSource, ...]:
        """Inject custom settings sources for merged Loader settings.

        Returns:
            Tuple of settings sources evaluated by Pydantic during model creation.

        """
        return cls.custom_sources


class LoaderMetaclass(Generic[T_Loader], ABCMeta):
    """Metaclass for Loader ensuring proper initialization and type safety."""

    def __call__(cls: type[T_Loader]) -> T_Loader:  # type: ignore[misc]
        """Enforce singleton behavior for Loader subclasses.

        Thread-safe singleton implementation using RLock for reentrant call support.
        Returns the same instance on subsequent calls. If called during initialization
        (e.g., from a bootstrap hook), returns the partially initialized instance.

        Returns:
            Singleton loader instance.

        Raises:
            TypeError: If attempting to instantiate the base Loader class directly.

        """
        if cls is Loader:
            raise TypeError("Base Loader class cannot be instantiated directly.")

        with cls._lock:
            match cls._state:
                case LoaderState.READY | LoaderState.INITIALIZING if cls._instance is not None:
                    return cast(T_Loader, cls._instance)
                case LoaderState.NOT_CREATED | _:
                    cls._instance = object.__new__(cls)
                    cls._state = LoaderState.INITIALIZING

                    try:
                        cls._instance.__init__()  # type: ignore[misc]
                        cls._state = LoaderState.READY
                    except Exception:
                        cls._instance = None
                        cls._state = LoaderState.NOT_CREATED
                        raise
                    return cast(T_Loader, cls._instance)

    @property
    def instance(cls: type[T_Loader]) -> T_Loader:  # type: ignore[misc]
        """Provide direct access to the singleton loader instance.

        Thread-safe property that returns an existing instance or lazily creates one
        if not yet initialized. Safe to call during initialization (reentrant).

        Returns:
            The singleton loader instance.

        """
        with cls._lock:
            match cls._state:
                case LoaderState.READY | LoaderState.INITIALIZING if cls._instance is not None:
                    return cls._instance  # type: ignore[return-value]
                case _:
                    return cls()

    def reset_instance(cls: type[T_Loader]) -> None:  # type: ignore[misc]
        """Reset the cached singleton instance for the loader subclass.

        Clears the singleton instance and resets state to NOT_CREATED. Primarily
        intended for testing scenarios where a fresh loader instance is required
        between test cases. Thread-safe operation.

        Warning:
            Should not be used in production code. Resetting a loader while
            components are actively using it may lead to undefined behavior.

        """
        with cls._lock:
            cls._instance = None
            cls._state = LoaderState.NOT_CREATED


class Loader(Generic[T_LoaderSettings], ABC, metaclass=LoaderMetaclass):
    """Base loader that composes settings, components, and CLI functionality.

    Attributes:
        Settings: The settings class to use for configuration composition.
        Components: Set of component classes to register with the loader. Order doesn't matter
            as initialization order is determined by dependency resolution.
        root: Optional override for the project root directory. If None, the directory
            containing the Loader subclass declaration file is used. Useful for testing
            or when the project structure differs from the default convention.
        install_rich_traceback: Whether to install rich traceback formatting. Accepts a boolean,
            or a dict mapping environment names to booleans for environment-specific toggling.
        load_dotenv: Whether to load environment variables from .env files.
        environments: Set of valid environment names supported by the application.
        default_environment: Default environment to use when ENVIRONMENT is not set.
        secrets_dir: Optional directory path for Pydantic secrets file source.

    """

    # Public class-level configuration
    Settings: ClassVar[
        Annotated[
            type[LoaderSettings],
            Doc(
                "Settings class used for loader-wide configuration composition.",
            ),
        ]
    ] = LoaderSettings

    Components: Annotated[
        set[type[Component[Any, Any]]],
        Doc(
            "Registered component classes; dependencies determine init order.",
        ),
    ] = set()

    root: Annotated[
        Path | None,
        Doc(
            "Project root override for config and file resolution.",
        ),
    ] = None

    install_rich_traceback: Annotated[
        bool | dict[str, bool], Doc("Enable Rich tracebacks globally or per environment.")
    ] = False

    rich_traceback_settings: ClassVar[
        Annotated[
            dict[str, Any],
            Doc(
                "Default settings for Rich traceback installation.",
            ),
        ]
    ] = {
        "show_locals": True,
        "word_wrap": True,
        "width": 120,
    }

    dotenv: Annotated[
        bool,
        Doc(
            "Load environment variables from a .env file before other sources.",
        ),
    ] = True

    dotenv_override: Annotated[
        bool,
        Doc(
            "Allow .env values to override existing environment variables.",
        ),
    ] = True

    dotenv_file: Annotated[
        str,
        Doc(
            "Filename of the dotenv file relative to the project root.",
        ),
    ] = ".env"

    config_folder: Annotated[
        str,
        Doc(
            "Directory (under the project root) containing config files.",
        ),
    ] = "config"

    config_file: Annotated[
        str,
        Doc(
            "Default YAML configuration merged before environment overrides.",
        ),
    ] = "default.yaml"

    environments: Annotated[
        set[str],
        Doc(
            "Allowed environment identifiers recognized by the loader.",
        ),
    ] = {
        "development",
        "staging",
        "production",
        "testing",
    }

    default_environment: Annotated[
        str,
        Doc(
            "Environment name assumed when ENVIRONMENT is unset.",
        ),
    ] = "production"

    secrets_dir: Annotated[
        Path | None,
        Doc(
            "Optional directory for secrets consumed by Pydantic sources.",
        ),
    ] = None

    _lock: ClassVar[RLock] = RLock()
    _instance: ClassVar[Loader[Any] | None] = None
    _state: ClassVar[LoaderState] = LoaderState.NOT_CREATED
    _declaration_file: ClassVar[Path]
    _bootstrap_hooks: ClassVar[list[tuple[str, Callable[[Loader[Any]], None], int]]] = []

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Validate subclass attributes during Loader subclass creation.

        Raises:
            TypeError: If ``Settings`` does not inherit from ``LoaderSettings``.
            ComponentDefinitionError: If ``Components`` is not a set or contains invalid entries.
            ComponentDefinitionError: If a component's ``Settings`` does not inherit from ``Settings``.

        """
        super().__init_subclass__(**kwargs)

        cls._declaration_file = Path(getfile(cls)).absolute()
        cls._instance = None
        cls._state = LoaderState.NOT_CREATED
        cls._lock = RLock()
        cls._bootstrap_hooks = []

    def __init__(self) -> None:
        """Initialize a loader instance and its registered components.

        Raises:
            InvalidDefaultEnvironmentError: If ``default_environment`` is outside ``environments``.
            InvalidEnvironmentError: If the resolved environment is unsupported.
            MissingConfigFileError: If expected configuration files are absent.
            SettingsCompositionError: If composed settings classes cannot be instantiated.
            ComponentRegistrationError: If component initialization fails.
            ComponentDefinitionError: If registered components are misconfigured.

        """
        for component in self.Components:
            if not isinstance(component, type) or not issubclass(component, Component):
                raise ComponentDefinitionError(component.__name__, "Must inherit from 'Component'.")
            if not isinstance(component.Settings, type) or not issubclass(component.Settings, Settings):
                raise ComponentDefinitionError(component.__name__, "Settings must inherit from 'Settings'.")

        self._settings: T_LoaderSettings
        self._components: dict[str, Component[Any, Any]] = {}
        self._cli: Typer | None = None
        self._logger: Logger | None = None

        self._init_path()
        self._init_environment()
        self._init_rich_traceback()
        self._init_configuration_files()
        self._init_settings()
        self._init_components()

        self._run_bootstrap_hooks()

    def _init_path(self) -> None:
        """Determine project root and import path for the loader."""
        self._project_root: Path = self.__class__.root or self.__class__._declaration_file.parent
        self._import_path: str = self.__class__.__module__

    def _init_environment(self) -> None:
        """Load environment variables and validate the active environment."""
        if self.dotenv:
            load_dotenv(
                dotenv_path=self._project_root / self.dotenv_file,
                override=self.dotenv_override,
                encoding="utf-8",
            )

        if self.default_environment not in self.environments:
            raise InvalidDefaultEnvironmentError(self.default_environment, self.environments)

        self._environment: str = environ.get("ENVIRONMENT", self.default_environment)
        self._base_environment: str = self._environment.split(".")[0]

        if self._base_environment not in self.environments:
            raise InvalidEnvironmentError(self._environment, self.environments)

    def _init_rich_traceback(self) -> None:
        """Enable Rich traceback support when configured for the environment."""
        match self.install_rich_traceback:
            case False | None:
                return
            case Mapping() as config if not config.get(self._base_environment, False):
                return
            case Mapping() | True:
                install_rich_traceback(**self.rich_traceback_settings)
            case other:
                raise InvalidTracebackConfigError(other)

    def _init_configuration_files(self) -> None:
        """Resolve configuration file paths and ensure their existence.

        Raises:
            MissingConfigFileError: If default or environment-specific config files are missing.

        """
        self._configuration_file: Path = self._project_root / self.config_folder / self.config_file
        self._environment_configuration_file: Path = (
            self._project_root / self.config_folder / f"{self._environment}.yaml"
        )

        for configuration_file in (self._configuration_file, self._environment_configuration_file):
            if not configuration_file.exists():
                raise MissingConfigFileError(str(configuration_file))

    def _init_settings(self) -> None:
        """Construct the merged Pydantic settings model for the loader.

        Raises:
            SettingsConflictError: If component settings declare conflicting fields.
            SettingsCompositionError: If Pydantic settings cannot be constructed.

        """
        seen: dict[str, type[Any]] = {}
        settings_sources: list[type[Settings]] = [self.__class__.Settings, *[c.Settings for c in self.Components]]

        for source in settings_sources:
            annotations: dict[str, Any] = getattr(source, "__annotations__", {})
            for name, annotation in annotations.items():
                if name in seen and seen[name] is not annotation:
                    raise SettingsConflictError(name)
                seen[name] = annotation

        try:
            MergedSettings: type[LoaderSettings] = type(
                "MergedSettings", (self.__class__.Settings, *[c.Settings for c in self.Components]), {}
            )

            MergedSettings.__name__ = "MergedSettings"
            MergedSettings.__qualname__ = f"{self.__class__.__qualname__}.MergedSettings"
            MergedSettings.__module__ = "manul.core"

            MergedSettings.custom_sources = (
                sources.EnvSettingsSource(MergedSettings, env_nested_delimiter="__"),
                sources.SecretsSettingsSource(MergedSettings, secrets_dir=self.secrets_dir),
                sources.YamlConfigSettingsSource(MergedSettings, self._environment_configuration_file),
                sources.YamlConfigSettingsSource(MergedSettings, self._configuration_file),
            )

            self._settings = cast(T_LoaderSettings, MergedSettings())
        except Exception as e:
            raise SettingsCompositionError(str(e)) from e

    def _init_components(self) -> None:
        """Instantiate and register the loader components with dependency resolution.

        Raises:
            ComponentRegistrationError: If a component constructor raises an exception.
            CircularDependencyError: If circular dependencies are detected.

        """
        try:
            init_order = self._resolve_component_dependencies()

            for component_cls in init_order:
                try:
                    self._components[component_cls.__name__] = component_cls(self)
                except Exception as e:
                    raise ComponentRegistrationError(component_cls.__name__, str(e)) from e

            for component_instance in self._components.values():
                try:
                    component_instance.post_init()
                except Exception as e:
                    raise ComponentRegistrationError(component_instance.__class__.__name__, str(e)) from e
        except (ComponentRegistrationError, CircularDependencyError):
            raise

    def _resolve_component_dependencies(self) -> list[type[Component[Any, Any]]]:
        """Resolve component initialization order using topological sorting.

        Returns:
            List of component classes in dependency resolution order.

        Raises:
            CircularDependencyError: If circular dependencies are detected.
        """

        graph: dict[type[Component[Any, Any]], set[type[Component[Any, Any]]]] = {
            component_cls: set() for component_cls in self.Components  # Initialize graph
        }

        in_degree: dict[type[Component[Any, Any]], int] = {
            component_cls: 0 for component_cls in self.Components  # Initialize in-degrees
        }

        for component_cls in self.Components:
            for dep_cls in component_cls.dependencies:
                if dep_cls not in self.Components:
                    raise ComponentRegistrationError(
                        component_cls.__name__,
                        f"Dependency {dep_cls.__name__} is not registered as a component. "
                        "Dependencies must only reference other registered components.",
                    )
                graph[dep_cls].add(component_cls)
                in_degree[component_cls] += 1

        queue = deque([cls for cls in self.Components if in_degree[cls] == 0])
        result = []

        while queue:
            current = queue.popleft()
            result.append(current)
            for dependent in graph[current]:
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        if len(result) != len(self.Components):
            remaining = [cls.__name__ for cls in self.Components if cls not in result]
            raise CircularDependencyError(remaining)

        return result

    @classmethod
    def bootstrap(
        cls, name: str, priority: int = 100
    ) -> Callable[[Callable[[Loader[Any]], None]], Callable[[Loader[Any]], None]]:
        """Register a bootstrap hook to execute during loader initialization.

        Bootstrap hooks are executed in priority order (lower numbers first) after all components are
        initialized. Useful for application-wide setup logic like seeding databases,
        registering signal handlers, or configuring third-party libraries.

        Args:
            name: Descriptive name for the bootstrap hook (used in logging).
            priority: Execution priority (lower numbers execute first, default 100).

        Returns:
            Decorator that registers the hook function.

        Example:
            >>> @App.bootstrap("database_seed", priority=10)
            >>> def seed_db(loader: App) -> None:
            >>>     print(f"Seeding database for {loader.environment}")

        """

        def decorator(func: Callable[[Loader[Any]], None]) -> Callable[[Loader[Any]], None]:
            cls._bootstrap_hooks.append(
                (name, func, priority),
            )

            return func

        return decorator

    def _run_bootstrap_hooks(self) -> None:
        """Execute all registered bootstrap hooks in priority order.

        Called automatically at the end of loader initialization. Each hook
        receives the loader instance as its argument. Hooks are sorted by priority
        (lower numbers first). Errors in individual hooks don't stop execution.
        """

        sorted_hooks = sorted(self._bootstrap_hooks, key=lambda x: x[2])

        for name, hook, priority in sorted_hooks:
            try:
                self.logger.info(
                    f"Running bootstrap hook: {name} ({hook.__name__}, priority {priority})",
                )

                hook(self)
            except Exception as e:
                self.logger.error(
                    f"Bootstrap hook '{name}' failed: {e}",
                )

    def get(self, component: type[T_Component]) -> T_Component:
        """Return a component instance by its type.

        Args:
            component: Component class to retrieve.

        Returns:
            Instantiated component matching the requested type.

        Raises:
            ComponentNotFoundError: If the component has not been registered.

        """
        return cast(T_Component, self._get_component_by_name(component.__name__))

    def has(self, component: type[Component[Any, Any]]) -> bool:
        """Check if a component is registered by its type.

        Args:
            component: Component class to check.

        Returns:
            True if the component is registered, False otherwise.

        """
        return component in self.Components

    def cli(self) -> None:
        """Execute the loader's Typer CLI application."""
        if not self._cli:
            self._cli = self._create_cli()

        try:
            self._cli()
        except SystemExit as e:
            if e.code not in (0, None):
                raise

    @lru_cache(maxsize=128)
    def _get_component_by_name(self, name: str) -> Component[Any, Any]:
        """Fetch a component by its registry name.

        Args:
            name: Registered component name.

        Returns:
            The component instance associated with ``name``.

        Raises:
            ComponentNotFoundError: If the requested component does not exist.

        """
        try:
            return self._components[name]

        except KeyError as e:
            raise ComponentNotFoundError(name, available=list(self.components.keys())) from e

    def _create_cli(self) -> Typer:
        """Build the Typer CLI including component subcommands.

        Returns:
            Configured Typer application with loader and component commands.

        Raises:
            CLIConflictError: If multiple components expose the same subcommand name.

        """
        cli: Typer = Typer(
            help="manul application CLI",
        )

        @cli.command(name="info")
        def info() -> None:
            print_info(self)

        @cli.command(name="settings")
        def settings(
            highlight: Annotated[bool, Option(help="Highlight the output.")] = False,
        ) -> None:
            print_tree(
                self.settings,
                highlight=highlight,
                title=f"🛠 Application Settings ({self.settings.__class__})",
            )

        @cli.command(name="about")
        def about() -> None:
            print_about()

        try:
            for comp in self._components.values():
                if comp.cli is not None:
                    primary_name = comp.cli.info.name or comp.__class__.__name__.lower()
                    cli.add_typer(
                        comp.cli,
                        name=primary_name,
                    )
                    for alias in comp.aliases:
                        if alias != primary_name:
                            cli.add_typer(comp.cli, name=alias, hidden=True)
        except UsageError as e:
            raise CLIConflictError(str(e)) from e

        return cli

    @property
    def import_path(self) -> str:
        """Python import string pointing to the loader declaration module."""
        return self._import_path

    @property
    def project_root(self) -> Path:
        """Absolute project root inferred from the loader declaration file or override."""
        return self._project_root

    @property
    def settings(self) -> T_LoaderSettings:
        """Merged settings instance composed from loader and component models."""
        return self._settings

    @property
    def components(self) -> Mapping[str, Component[Any, Any]]:
        """Read-only mapping view of registered component instances keyed by name."""
        return self._components

    @property
    def environment(self) -> str:
        """Full environment name resolved from configuration sources."""
        return self._environment

    @property
    def base_environment(self) -> str:
        """Base environment name without sub-environment qualifiers."""
        return self._base_environment

    @property
    def configuration_file(self) -> Path:
        """Absolute path to ``config/default.yaml``."""
        return self._configuration_file

    @property
    def environment_configuration_file(self) -> Path:
        """Absolute path to the active environment's YAML configuration file."""
        return self._environment_configuration_file

    @property
    def logger(self) -> Logger:
        """Provide a logger instance for the loader.

        Returns:
            Logger instance.

        """
        if self._logger is None:
            self._logger = getLogger(self.__class__.__qualname__)
        return self._logger

    @overload
    def __getitem__(self, component: type[T_Component], /) -> T_Component: ...

    @overload
    def __getitem__(self, component: str, /) -> Component[Any, Any]: ...

    def __getitem__(self, component: type[T_Component] | str, /) -> Component[Any, Any]:
        """Retrieve a component by type or registry name.

        Args:
            component: Component class or registry name.

        Returns:
            The component instance corresponding to ``component``.

        Raises:
            TypeError: If ``component`` is neither a Component type nor a string.
            ComponentNotFoundError: If the component is not registered.

        Examples:
            >>> loader[MyComponent]  # Access by type
            >>> loader["MyComponent"]  # Access by name

        """
        match component:
            case str():
                name = component
            case type() if issubclass(component, Component):
                name = component.__name__
            case _:
                raise TypeError(
                    "Component key must be a component type or string name.",
                )

        return self._get_component_by_name(name)

    def __getattr__(self, name: str) -> Component[Any, Any]:
        """Return components via attribute-style access when available.

        Args:
            name: Component name requested as an attribute.

        Returns:
            Component instance tied to ``name``.

        Raises:
            AttributeError: If ``name`` does not match a registered component.

        Examples:
            >>> loader.MyComponent  # Attribute-style access

        """
        try:
            return self._get_component_by_name(name)
        except ComponentNotFoundError as exc:
            raise AttributeError(name) from exc

    def __dir__(self) -> list[str]:
        """Augment ``dir()`` output with registered component names."""
        return sorted(set(super().__dir__()) | set(self._components.keys()))

    def __repr__(self) -> str:
        """Return a concise debug representation of the loader."""
        return (
            f"<Loader {self.__class__.__name__}, "
            f"components={list(self.components.keys())}, "
            f"env={self.environment!r}, "
            f"path={self.project_root}>"
        )

    __slots__ = (
        "_components",
        "_project_root",
        "_import_path",
        "_environment",
        "_base_environment",
        "_configuration_file",
        "_environment_configuration_file",
        "_settings",
        "_cli",
        "_logger",
    )
