# About

A python library with tools to support less point-and-click for instructors as we lean into GenAI

