def main() -> None:
    print("Hello from coursekit!")
