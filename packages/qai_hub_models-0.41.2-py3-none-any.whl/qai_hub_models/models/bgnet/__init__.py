# ---------------------------------------------------------------------
# Copyright (c) 2025 Qualcomm Technologies, Inc. and/or its subsidiaries.
# SPDX-License-Identifier: BSD-3-Clause
# ---------------------------------------------------------------------

from .app import BGNetApp as App  # noqa: F401
from .model import MODEL_ID  # noqa: F401
from .model import BGNet as Model  # noqa: F401
