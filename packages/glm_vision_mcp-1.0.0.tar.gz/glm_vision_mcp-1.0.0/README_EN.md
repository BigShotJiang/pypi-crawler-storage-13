# GLM Vision MCP Server

English | [简体中文](./README.md)

A Model Context Protocol (MCP) server implementation based on ZhipuAI's GLM-4V multimodal model, providing professional vision analysis capabilities for Claude and other AI assistants.

## Project Overview

GLM Vision MCP Server is a standard MCP protocol server that integrates ZhipuAI's GLM-4V multimodal model to provide developers with 8 professional vision analysis tools. This project uses stdio transport mode, supports multimodal analysis of images and videos, and can be seamlessly integrated into MCP-compatible clients such as Claude Desktop and Claude Code.

## Technical Specifications

### MCP Configuration

- **Protocol Version**: MCP 1.0
- **Transport Mode**: stdio (Standard Input/Output Communication)
- **Server Type**: FastMCP

### Model Configuration

| Parameter | Value | Description |
|-----------|-------|-------------|
| Model | glm-4.5v | ZhipuAI Multimodal Vision Model |
| API Endpoint | https://open.bigmodel.cn/api/paas/v4/chat/completions | ZhipuAI API Address |
| Temperature | 0.8 | Controls output randomness |
| Top P | 0.6 | Nucleus sampling parameter |
| Max Tokens | 16384 | Maximum output tokens |
| Timeout | 120s | API request timeout limit |

### File Support Specifications

| Type | Supported Formats | Max File Size | Encoding Method |
|------|------------------|---------------|-----------------|
| Image | PNG, JPG, JPEG | 5MB | Base64 Data URI |
| Video | MP4, MOV, M4V | 8MB | Base64 Data URI |

## System Requirements

- Python 3.8 or higher
- ZhipuAI API Key
- Supported OS: Windows, macOS, Linux

## Installation and Deployment

### 1. Get the Project

```bash
git clone https://github.com/kie0519/glm_vision_mcp.git
cd glm_vision_mcp
```

### 2. Install Dependencies

```bash
pip install fastmcp httpx
```

### 3. Configure API Key

Get ZhipuAI API Key from: https://open.bigmodel.cn/

Set environment variable:

**Windows (PowerShell)**
```powershell
$env:GLM_API_KEY = "your_api_key_here"
```

**Windows (CMD)**
```cmd
set GLM_API_KEY=your_api_key_here
```

**macOS/Linux**
```bash
export GLM_API_KEY="your_api_key_here"
```

### 4. Configure MCP Client

#### Claude Desktop Configuration

Edit configuration file:
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`
- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`

Add configuration:

```json
{
  "mcpServers": {
    "glm-vision": {
      "command": "python",
      "args": [
        "D:/path/to/glm_vision_mcp/server.py"
      ],
      "env": {
        "GLM_API_KEY": "your_api_key_here"
      }
    }
  }
}
```

#### Claude Code Configuration

**Method 1: Command Line Configuration**

```bash
claude mcp add -s user glm-vision --env GLM_API_KEY=your_api_key -- python D:/path/to/glm_vision_mcp/server.py
```

**Method 2: Configuration File**

Edit `.claude.json`:

```json
{
  "mcpServers": {
    "glm-vision": {
      "type": "stdio",
      "command": "python",
      "args": [
        "D:/path/to/glm_vision_mcp/server.py"
      ],
      "env": {
        "GLM_API_KEY": "your_api_key_here"
      }
    }
  }
}
```

### 5. Verify Installation

After restarting the MCP client, run test:

```bash
python server.py
```

If no errors occur, the installation is successful.

## Tool Catalog

### 1. ui_to_artifact

**Description**: Convert UI screenshots to code/prompts/design specs/descriptions

**Use Cases**:
- Generate frontend code from UI designs
- Create AI prompts to rebuild UI
- Extract design specification documents
- Generate natural language UI descriptions

**Input Parameters**:
- `image_source` (string): UI screenshot path
- `output_type` (string): Output type, options: 'code'/'prompt'/'spec'/'description'
- `prompt` (string): Detailed requirement description

**Output Content**:

Returns different formats based on `output_type`:
- `code`: Complete runnable code + structure explanation + style notes
- `prompt`: AI generation prompts + structure breakdown + usage instructions
- `spec`: Design system specification document
- `description`: Natural language UI description

### 2. extract_text_from_screenshot

**Description**: Extract and recognize text content from screenshots

**Use Cases**:
- Extract code from IDE/editors
- Copy terminal/console output
- Get document or article text
- Extract configuration files, logs, or API responses

**Input Parameters**:
- `image_source` (string): Screenshot path containing text
- `prompt` (string): Extraction requirement description

**Output Content**:
- Extracted complete text (preserving format)
- Content type identification
- Programming language/format detection
- OCR correction notes
- Quality annotations

### 3. diagnose_error_screenshot

**Description**: Diagnose and analyze error messages and exceptions in screenshots

**Use Cases**:
- Error messages or exception screenshots
- Stack traces or error logs
- Compilation or build failures
- Runtime errors or crashes

**Input Parameters**:
- `image_source` (string): Error screenshot path
- `prompt` (string): Error context and help requirements

**Output Content**:
- Error summary (type/location/severity)
- Root cause analysis
- Step-by-step fix solutions + code snippets
- Prevention strategies and best practices
- Additional notes

### 4. understand_technical_diagram

**Description**: Analyze and interpret technical diagrams and architecture designs

**Use Cases**:
- System architecture diagrams
- Flowcharts
- UML diagrams (class/sequence/activity diagrams, etc.)
- Database ER diagrams
- Network topology diagrams

**Input Parameters**:
- `image_source` (string): Technical diagram path
- `prompt` (string): Analysis requirement description

**Output Content**:
- Diagram overview (type/purpose/standard)
- Component inventory and responsibilities
- Relationship and data flow analysis
- Architecture pattern assessment
- Text representation (Mermaid/PlantUML)

### 5. analyze_data_visualization

**Description**: Analyze data visualizations, charts, and dashboards

**Use Cases**:
- Various charts (line/bar/pie/scatter plots, etc.)
- Dashboards or monitoring panels
- Statistical visualizations
- Performance metric displays

**Input Parameters**:
- `image_source` (string): Data visualization screenshot path
- `prompt` (string): Analysis requirement description

**Output Content**:
- Visualization summary (type/metrics/time period)
- Key metric values
- Trend and pattern analysis
- Anomalies and insights
- Actionable recommendations

### 6. ui_diff_check

**Description**: Compare differences between two UI screenshots

**Use Cases**:
- Compare design mockups vs implemented UI
- Visual regression testing
- Check UI consistency between versions
- Identify layout issues or visual bugs
- Verify UI implementation accuracy

**Input Parameters**:
- `expected_image_source` (string): Expected UI screenshot path
- `actual_image_source` (string): Actual UI screenshot path
- `prompt` (string): Comparison requirement description

**Output Content**:
- Overall assessment (similarity/major differences)
- Detailed differences (graded by severity)
- Layout/content/style issue checklist
- Recommended fix solutions (with CSS code)
- Testing annotations

### 7. analyze_image

**Description**: General image analysis

**Use Cases**: Serves as a fallback tool when other specialized tools are not applicable, providing flexible image analysis capabilities

**Input Parameters**:
- `image_source` (string): Any image path
- `prompt` (string): Detailed analysis requirement description

**Output Content**:
- Main response to user request
- Detailed observation results
- Context and analysis
- Additional annotations

### 8. analyze_video

**Description**: General video analysis

**Use Cases**: Analyze video content, understand video scenes, answer video-related questions

**Input Parameters**:
- `video_source` (string): Video file path
- `prompt` (string): Video analysis requirement description

**Output Content**:
- Video content summary
- Scene and action analysis
- Key frame descriptions
- Targeted answers

## Configuration Parameters

Configuration file located at `config.py`, adjustable as needed:

```python
# File size limits
MAX_IMAGE_SIZE = 5 * 1024 * 1024  # 5MB
MAX_VIDEO_SIZE = 8 * 1024 * 1024  # 8MB

# Supported file formats
SUPPORTED_IMAGE_FORMATS = {'.png', '.jpg', '.jpeg'}
SUPPORTED_VIDEO_FORMATS = {'.mp4', '.mov', '.m4v'}

# GLM API configuration
GLM_API_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
MODEL_NAME = "glm-4.5v"

# Model parameters
TEMPERATURE = 0.8  # Controls randomness (0.0-1.0)
TOP_P = 0.6        # Nucleus sampling parameter (0.0-1.0)
MAX_TOKENS = 16384 # Maximum response length

# Server metadata
SERVER_NAME = "GLM Vision Scene Server"
SERVER_VERSION = "1.0.0"
```

## Troubleshooting

### Environment Variable Not Set

**Error**: `RuntimeError: GLM_API_KEY environment variable is not set`

**Solution**:
1. Confirm `GLM_API_KEY` environment variable is correctly set
2. Check `env` configuration in MCP client configuration file
3. Restart MCP client to apply configuration

### Unsupported File Format

**Error**: `ValueError: Unsupported image/video format`

**Solution**:
1. Confirm file format is in the supported list
2. Check file extension is correct
3. Convert file format if necessary

### File Size Exceeded

**Error**: `ValueError: File size exceeds limit`

**Solution**:
1. Compress image/video files
2. Adjust size limits in `config.py`
3. Restart MCP server to apply configuration

### API Call Failed

**Error**: `RuntimeError: GLM API request failed`

**Solution**:
1. Check network connection
2. Verify API Key is valid
3. Confirm ZhipuAI account has sufficient credits
4. Review detailed error logs

### MCP Server Connection Failed

**Solution**:
1. Verify configuration file path is correct
2. Confirm Python interpreter path is correct
3. Check MCP client logs
4. Try running `python server.py` directly from command line for testing

## Project Structure

```
glm_vision_mcp/
├── server.py                 # MCP server entry point
├── config.py                 # Configuration file
├── api_client.py             # GLM API client
├── utils.py                  # Utility functions
├── __init__.py               # Package initialization
├── tools/                    # Tool modules
│   ├── __init__.py           # Tool registration
│   ├── ui_to_artifact.py     # UI to code tool
│   ├── text_extraction.py    # Text extraction tool
│   ├── error_diagnosis.py    # Error diagnosis tool
│   ├── diagram_analysis.py   # Diagram analysis tool
│   ├── data_viz.py           # Data visualization tool
│   ├── ui_diff.py            # UI comparison tool
│   ├── video_analysis.py     # Video analysis tool
│   └── general_image.py      # General image analysis tool
├── prompts/                  # System prompt templates
│   ├── __init__.py           # Prompt module initialization
│   ├── ui_to_artifact.py     # UI to code prompts
│   ├── text_extraction.py    # Text extraction prompts
│   ├── error_diagnosis.py    # Error diagnosis prompts
│   ├── diagram_analysis.py   # Diagram analysis prompts
│   ├── data_viz.py           # Data visualization prompts
│   ├── ui_diff.py            # UI comparison prompts
│   ├── video_analysis.py     # Video analysis prompts
│   └── general_image.py      # General image analysis prompts
└── data/                     # Sample data
```

## Development Guide

### Adding New Tools

1. Create a new tool module in the `tools/` directory
2. Implement tool function and registration function:

```python
from fastmcp import FastMCP
from api_client import call_glm_api
from utils import file_to_data_uri, load_prompt_template

def register_new_tool(mcp: FastMCP):
    @mcp.tool()
    async def new_tool(image_source: str, prompt: str) -> str:
        """Tool description"""
        system_prompt = load_prompt_template("new_tool")
        data_uri = file_to_data_uri(image_source)

        result = await call_glm_api(
            system_prompt=system_prompt,
            user_prompt=prompt,
            media_data_uris=[data_uri]
        )

        return result
```

3. Register the new tool in `tools/__init__.py`
4. Create corresponding prompt file in the `prompts/` directory

### Debugging Tools

Use MCP Inspector for debugging:

```bash
npx @modelcontextprotocol/inspector python server.py
```

## License

MIT License

## Author Information

- Author: kie
- Project Homepage: https://github.com/kie0519/glm_vision_mcp
- Issue Tracker: https://github.com/kie0519/glm_vision_mcp/issues

## Related Links

- [ZhipuAI Open Platform](https://open.bigmodel.cn/)
- [Model Context Protocol](https://modelcontextprotocol.io/)
- [FastMCP Framework](https://github.com/jlowin/fastmcp)
- [Claude Desktop](https://claude.ai/download)
