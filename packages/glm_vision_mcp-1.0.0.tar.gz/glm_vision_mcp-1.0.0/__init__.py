"""
GLM Vision MCP Server
基于智谱AI GLM-4V多模态大模型的MCP服务器，提供专业的视觉分析能力
"""

__version__ = "1.0.0"
__author__ = "kie"
__email__ = "noreply@github.com"

__all__ = ["__version__", "__author__", "__email__"]
