import numpy as np
import librosa
import matplotlib.pyplot as plt
from IPython.display import Audio
from scipy.fftpack import dct

from .utils import pre_emphasis

def generate_phonemes():
    """
    Generate synthetic phoneme sounds
    
    Returns:
    dict: Generated phoneme signals and parameters
    """
    sr = 8000
    t = np.linspace(0, 1, sr)
    
    # AA sound
    y1 = 0.5 * np.sin(2 * np.pi * 120 * t) + 0.2 * np.sin(2 * np.pi * 800 * t) + 0.1 * np.sin(2 * np.pi * 2400 * t)
    y1 = y1 / np.max(np.abs(y1))
    
    # EE sound
    y2 = 0.5 * np.sin(2 * np.pi * 270 * t) + 0.3 * np.sin(2 * np.pi * 2290 * t) + 0.1 * np.sin(2 * np.pi * 3010 * t)
    y2 = y2 / np.max(np.abs(y2))
    
    # OO sound 1
    y3 = 0.5 * np.sin(2 * np.pi * 120 * t) + 0.2 * np.sin(2 * np.pi * 800 * t) + 0.1 * np.sin(2 * np.pi * 2460 * t)
    y3 = y3 / np.max(np.abs(y3))
    
    # OO sound 2
    y4 = 0.5 * np.sin(2 * np.pi * 120 * t) + 0.2 * np.sin(2 * np.pi * 300 * t) + 0.1 * np.sin(2 * np.pi * 870 * t)
    y4 = y4 / np.max(np.abs(y4))
    
    return {
        'aa': (y1, sr),
        'ee': (y2, sr),
        'oo1': (y3, sr),
        'oo2': (y4, sr)
    }

def plot_phoneme_waveforms(phonemes_dict):
    """
    Plot waveforms for all generated phonemes
    
    Parameters:
    phonemes_dict (dict): Dictionary of phoneme signals
    """
    for phoneme, (signal, sr) in phonemes_dict.items():
        plt.figure(figsize=(10, 6))
        plt.title(f"Waveform {phoneme}")
        librosa.display.waveshow(signal, sr=sr)
        plt.xlabel('Time (Seconds)')
        plt.ylabel('Amplitude')
        plt.show()

def compute_spectrograms(phonemes_dict):
    """
    Compute and plot spectrograms for phonemes
    
    Parameters:
    phonemes_dict (dict): Dictionary of phoneme signals
    """
    for phoneme, (signal, sr) in phonemes_dict.items():
        # STFT spectrogram
        D = librosa.stft(signal, n_fft=512, hop_length=128)
        S_db = librosa.amplitude_to_db(np.abs(D), ref=np.max)
        
        plt.figure(figsize=(10, 6))
        librosa.display.specshow(S_db, sr=sr, hop_length=256, x_axis='time', y_axis='linear')
        plt.colorbar(label="Magnitude (dB)")
        plt.title(f"Linear-Frequency Spectrogram (STFT) - {phoneme}")
        plt.ylim(0, 5000)
        plt.tight_layout()
        plt.show()
        
        # Mel spectrogram
        S_mel = librosa.feature.melspectrogram(y=signal, sr=sr, n_mels=64, fmax=8000)
        S_mel_db = librosa.power_to_db(S_mel, ref=np.max)
        
        plt.figure(figsize=(10, 6))
        librosa.display.specshow(S_mel_db, x_axis='time', y_axis='mel', sr=sr, fmax=8000)
        plt.colorbar(label="dB")
        plt.title(f"Log-Mel Spectrogram - {phoneme}")
        plt.tight_layout()
        plt.show()

def hamming_window(M):
    """
    Generate Hamming window
    
    Parameters:
    M (int): Window length
    
    Returns:
    array: Hamming window
    """
    return 0.54 - 0.46 * np.cos(2 * np.pi * np.arange(M) / (M - 1))

def complete_mfcc_pipeline(signal, sr):
    """
    Complete MFCC pipeline from Lab 7
    
    Parameters:
    signal (array): Input signal
    sr (int): Sampling rate
    
    Returns:
    dict: MFCC pipeline results
    """
    # Step 1: Pre-emphasis
    emphasized = pre_emphasis(signal)
    
    print("=== Step 2: Pre-Emphasis ===")
    for i in range(11, 20):
        print(f"Sample {i}: Original = {signal[i]:.8f}, Emphasized = {emphasized[i]:.8f}")
    
    # Plot pre-emphasis effect
    plt.figure(figsize=(10, 4))
    plt.plot(signal[:200], color='blue', label='Original')
    plt.plot(emphasized[:200], color='orange', label='Pre-emphasized')
    plt.title("Pre-emphasis Effect (first 200 samples)")
    plt.xlabel("Sample Index")
    plt.ylabel("Amplitude")
    plt.legend()
    plt.grid(True)
    plt.show()
    
    # Step 2: Framing
    frame_size = int(0.025 * sr)  # 25 ms
    frame_shift = int(0.010 * sr)  # 10 ms
    
    frames = []
    for start in range(0, len(emphasized) - frame_size, frame_shift):
        frames.append(emphasized[start:start + frame_size])
    frames = np.array(frames)
    
    print(f"\n=== Step 3: Total Frames == {len(frames)}")
    print(f"Frame length: {frame_size} samples")
    print(f"Frame Shift: {frame_shift}")
    
    # Framing visualization
    plt.figure(figsize=(18, 4))
    t = np.linspace(0, 0.5, len(signal))
    plt.plot(t, signal, color='blue')
    plt.title("Framing Visualization")
    plt.xlabel("Time (s)")
    plt.ylabel("Amplitude")
    
    # Draw frame windows
    colors = ['red', 'green', 'orange']
    for i, start in enumerate(range(0, len(signal) - frame_size, frame_shift)[:3]):
        start_time = start / sr
        end_time = (start + frame_size) / sr
        plt.axvspan(start_time, end_time, color=colors[i % len(colors)], alpha=0.2, 
                   label=f"Frame {i+1}" if i == 0 else "")
    
    plt.legend()
    plt.grid(True)
    plt.show()
    
    # Step 3: Windowing
    window = hamming_window(frame_size)
    windowed_frames = frames * window
    
    # Plot windowing effect
    frame_index = 11
    original_frame = frames[frame_index]
    windowed_frame = windowed_frames[frame_index]
    
    plt.figure(figsize=(10, 4))
    plt.plot(original_frame[:200], color='blue', label='Original Frame')
    plt.plot(windowed_frame[:200], color='orange', label='Windowed Frame')
    plt.title("Hamming Window Effect on First 200 Samples")
    plt.xlabel("Sample Index")
    plt.ylabel("Amplitude")
    plt.legend()
    plt.grid(True)
    plt.show()
    
    # Plot Hamming window
    plt.figure(figsize=(8, 3))
    plt.plot(window[:200], color='green')
    plt.title("Hamming Window Shape (First 200 Samples)")
    plt.xlabel("Sample Index")
    plt.ylabel("Window Value")
    plt.grid(True)
    plt.show()
    
    # Step 4: FFT & Power Spectrum
    NFFT = 512
    
    def power_spectrum(frame, NFFT):
        mag = np.abs(np.fft.rfft(frame, NFFT))   # positive frequency
        power = (1.0 / NFFT) * (mag ** 2)
        return power
    
    power_frames = np.array([power_spectrum(f, NFFT) for f in windowed_frames])
    
    plt.figure(figsize=(10, 4))
    plt.plot(10 * np.log10(power_frames[0]))
    plt.title("Power Spectrum (First Frame, dB Scale)")
    plt.xlabel("Frequency Bins")
    plt.ylabel("Power (dB)")
    plt.show()
    
    # Step 5: Mel Filterbank
    def hz_to_mel(hz): 
        return 2595 * np.log10(1 + hz / 700)
    
    def mel_to_hz(mel): 
        return 700 * (10**(mel / 2595) - 1)
    
    n_filters = 26
    low_mel = hz_to_mel(0)
    high_mel = hz_to_mel(sr / 2)
    mel_points = np.linspace(low_mel, high_mel, n_filters + 2)
    hz_points = mel_to_hz(mel_points)
    bin_points = np.floor((NFFT + 1) * hz_points / sr).astype(int)
    
    fbank = np.zeros((n_filters, int(NFFT / 2 + 1)))
    for m in range(1, n_filters + 1):
        f_m_minus = bin_points[m - 1]
        f_m = bin_points[m]
        f_m_plus = bin_points[m + 1]
        for k in range(f_m_minus, f_m):
            fbank[m - 1, k] = (k - f_m_minus) / (f_m - f_m_minus)
        for k in range(f_m, f_m_plus):
            fbank[m - 1, k] = (f_m_plus - k) / (f_m_plus - f_m)
    
    plt.figure(figsize=(10, 4))
    for i in range(n_filters):
        plt.plot(fbank[i])
    plt.title("Mel Filterbank (Triangular filters)")
    plt.xlabel("Frequency Bins")
    plt.ylabel("Amplitude")
    plt.show()
    
    # Step 6: Filter Energies
    filter_banks = np.dot(power_frames, fbank.T)
    filter_banks = np.where(filter_banks == 0, np.finfo(float).eps, filter_banks)
    log_energies = np.log(filter_banks)
    
    plt.imshow(log_energies.T, aspect='auto', origin='lower')
    plt.title("Mel Filterbank Energies (Log Scale)")
    plt.xlabel("Frame Index")
    plt.ylabel("Filter Index")
    plt.show()
    
    # Step 7: MFCC
    num_ceps = 13
    mfccs = np.array([dct(f, type=2, norm='ortho')[:num_ceps] for f in log_energies])
    mfccs -= (np.mean(mfccs, axis=0) + 1e-8)
    
    plt.imshow(mfccs.T, aspect='auto', origin='lower')
    plt.title("MFCCs (13 Coefficients per Frame)")
    plt.xlabel("Frame Index")
    plt.ylabel("Coefficient Index")
    plt.colorbar(label="Coefficient Value")
    plt.show()
    
    print("\n=== Step 8: MFCCs (first frame, all coefficients) ===")
    print(mfccs[0])
    
    return {
        'preemph_signal': emphasized,
        'frames': frames,
        'windowed_frames': windowed_frames,
        'power_spectrum': power_frames,
        'filter_banks': filter_banks,
        'mfccs': mfccs
    }