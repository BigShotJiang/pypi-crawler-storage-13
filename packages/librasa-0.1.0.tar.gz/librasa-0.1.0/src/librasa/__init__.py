"""
Librasa - Speech Processing Library

A comprehensive Python library for speech processing tasks including 
spectral analysis, formant estimation, MFCC extraction, and audio visualization.
"""

__version__ = "0.1.0"

from . import lab1
from . import lab2
from . import lab4
from . import lab6
from . import lab7
from . import quiz1
from . import utils

__all__ = ["lab1", "lab2", "lab4", "lab6", "lab7", "quiz1", "utils"]