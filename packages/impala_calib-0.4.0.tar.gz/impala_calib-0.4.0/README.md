# impala
[![CI Status][ci-status-img]](https://github.com/lanl/impala/actions)

Python tools for modular Bayesian model calibration.  Posterior exploration
includes tempering and adaptive MCMC.

## Installation
You can install `impala` via **pip** or **uv**.

**pip**
```sh
pip install impala-calib
```

**uv**
```sh
uv add impala-calib
```

## Examples
* [Example 1](examples/ex_friedman.ipynb)    

## References

************

Copyright 2020. Triad National Security, LLC. All rights reserved.
This program was produced under U.S. Government contract 89233218CNA000001 for
Los Alamos National Laboratory (LANL), which is operated by Triad National
Security, LLC for the U.S.  Department of Energy/National Nuclear Security
Administration. All rights in the program are reserved by Triad National
Security, LLC, and the U.S. Department of Energy/National Nuclear Security
Administration. The Government is granted for itself and others acting on its
behalf a nonexclusive, paid-up, irrevocable worldwide license in this material
to reproduce, prepare derivative works, distribute copies to the public, perform
publicly and display publicly, and to permit others to do so.

LANL software release C19112

Authors: Devin Francom, Peter Trubey, others

[ci-status-img]: https://img.shields.io/github/actions/workflow/status/lanl/impala/CI.yml?style=flat-square&label=CI
