"""Playwright session implementation."""

from typing import TYPE_CHECKING
from playwright.async_api import BrowserContext
from ....browser import Session

if TYPE_CHECKING:
    from .playwright_page import PlaywrightPage


class PlaywrightSession(Session):
    """
    Playwright implementation of Session.

    Wraps Playwright's BrowserContext for session management.
    Users should set cookies directly on the BrowserContext before passing it in.
    """

    def __init__(self, context: BrowserContext):
        """
        Initialize PlaywrightSession.

        Args:
            context: Playwright BrowserContext instance
        """
        super().__init__()
        self._context = context

    async def create_page(self) -> "PlaywrightPage":
        """
        Create a new page/tab in this session.

        Returns:
            PlaywrightPage instance

        Example:
            >>> session = await PlaywrightSession.create_session(browser)
            >>> page1 = await session.create_page()
            >>> page2 = await session.create_page()  # New tab in same session
        """
        from .playwright_page import PlaywrightPage

        playwright_page = await self._context.new_page()
        return PlaywrightPage(playwright_page)

    async def close(self):
        """Close the session/context."""
        if self._context:
            await self._context.close()
