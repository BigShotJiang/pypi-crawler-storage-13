# Cython Build Instructions

This package uses Cython to compile Python source code into C extensions, making it harder for users to read the source code while keeping the original code safe.

## Build Process

### 1. Build Compiled Version

Run the build script to compile Python files:

```bash
python build_cython.py
```

This will:
- Backup original source code to `payme_source/`
- Compile Python files to `.so` files (Linux/Mac) or `.pyd` files (Windows)
- Keep the compiled extensions in the `payme/` directory

### 2. Create Distribution Package

After compilation, create the distribution package:

```bash
python setup.py sdist bdist_wheel
```

### 3. Install the Package

Install the compiled package:

```bash
pip install dist/payme_pkg-3.0.32-*.whl
```

## Directory Structure

- `payme/` - Contains compiled extensions (.so/.pyd files)
- `payme_source/` - Original Python source code (NOT distributed)
- `build_cython.py` - Build script for Cython compilation
- `setup.py` - Package setup configuration

## Notes

- Original source code is preserved in `payme_source/` 
- Only compiled extensions are distributed to end users
- The package functions identically to the non-compiled version
- `.gitignore` is updated to exclude source backup and build artifacts
