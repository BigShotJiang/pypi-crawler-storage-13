import pathlib
from setuptools import find_packages, setup, Extension

here = pathlib.Path(__file__).parent.resolve()
long_description = (here / "README.md").read_text(encoding="utf-8")

# Check if Cython is available for building extensions
ext_modules = []
try:
    from Cython.Build import cythonize
    # Cython extensions will be built separately via build_cython.py
    USE_CYTHON = True
except ImportError:
    USE_CYTHON = False

setup(
    name='payme-pkg',
    version='3.2.6',
    license='MIT',
    author="Muhammadali Akbarov",
    author_email='muhammadali17abc@gmail.com',
    packages=find_packages(exclude=['payme_source', 'payme_source.*', 'build', 'scripts']),
    url='https://github.com/Muhammadali-Akbarov/payme-pkg',
    keywords='paymeuz paycomuz payme-merchant merchant-api subscribe-api payme-pkg payme-api',
    install_requires=[
        'requests==2.*',
        "dataclasses==0.*;python_version<'3.7'",
        'djangorestframework==3.*',
    ],
    long_description=long_description,
    long_description_content_type="text/markdown",
    include_package_data=True,
    package_data={
        '': ['*.so', '*.pyd', '*.dll', '*.dylib'],
        'payme': ['*.so', '*.pyd', '*.dll', '*.dylib'],
    },
    ext_modules=ext_modules,
    zip_safe=False,
)
