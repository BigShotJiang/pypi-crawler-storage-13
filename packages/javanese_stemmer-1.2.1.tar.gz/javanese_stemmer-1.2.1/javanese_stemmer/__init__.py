"""
Javanese Stemmer - Comprehensive Javanese Language Stemmer with Morphophonological Rules
"""

from .stemmer import (
    JavaneseStemmer,
    JavaneseStemmerLibrary,
    JavaneseStemmerPipeline,
    StemmerFactory,
    PrefixType,
    MorphologicalRule,
    create_stemmer,
    get_stemmer,
    stem_word,
    stem_sentence,
    stem_text,
    create_comprehensive_test_suite,
    run_comprehensive_evaluation
)

__version__ = "1.2.1"
__author__ = "Stevia Anlena Putri"
__email__ = "stevia.ap@gmail.com"

__all__ = [
    # Main classes
    'JavaneseStemmer',
    'JavaneseStemmerLibrary',
    'JavaneseStemmerPipeline',
    'StemmerFactory',
    
    # Enums and data classes
    'PrefixType',
    'MorphologicalRule',
    
    # Factory functions
    'create_stemmer',
    'get_stemmer',
    
    # Convenience functions
    'stem_word',
    'stem_sentence',
    'stem_text',
    
    # Testing functions
    'create_comprehensive_test_suite',
    'run_comprehensive_evaluation',
]