# Javanese Stemmer

Javanese language stemmer with dictionary validation.

## Installation

```bash
pip install javanese-stemmer
```

## Usage

```python
from javanese_stemmer import JavaneseStemmer

# Initialize (dictionary auto-loads from package)
stemmer = JavaneseStemmer()

# Stem a word
result = stemmer.stem("mlaku")
print(result)

# Stem a sentence
words = stemmer.stem_sentence("Aku mlaku ing dalan")
print(words)
```

## Features

- Dictionary validation
- Handles prefixes, suffixes, infixes
- Safe fallback to original word
- Built-in Javanese dictionary

## License

MIT License
