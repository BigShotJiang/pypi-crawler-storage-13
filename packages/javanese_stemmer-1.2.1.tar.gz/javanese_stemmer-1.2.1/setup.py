from setuptools import setup, find_packages
import os

# Read the README file
def read_long_description():
    try:
        with open("README.md", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return "Comprehensive Javanese language stemmer with morphophonological rules"

setup(
    name="javanese-stemmer",
    version="1.2.1",
    author="Stevia Anlena Putri",
    author_email="stevia.ap@gmail.com",
    description="Comprehensive Javanese language stemmer with morphophonological rules and dictionary validation",
    long_description=read_long_description(),
    long_description_content_type="text/markdown",
    url="https://github.com/steviaanlena/Javanese-Stemmer",
    packages=find_packages(),
    
    # CRITICAL: Include dictionary file
    package_data={
        'javanese_stemmer': ['kamus.txt', 'data/*.txt'],
    },
    include_package_data=True,
    
    # Dependencies
    install_requires=[
        'pandas>=1.0.0',
    ],
    
    # Optional dependencies for advanced features
    extras_require={
        'dev': [
            'pytest>=6.0',
            'pytest-cov>=2.0',
        ],
    },
    
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Text Processing :: Linguistic",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Natural Language :: Javanese",
    ],
    python_requires=">=3.7",
    keywords="javanese nlp stemmer morphology linguistics text-processing",
    project_urls={
        'Bug Reports': 'https://github.com/steviaanlena/Javanese-Stemmer/issues',
        'Source': 'https://github.com/steviaanlena/Javanese-Stemmer',
    },
)