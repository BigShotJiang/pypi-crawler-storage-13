import numpy as np
from itertools import product

# The Discrete Gradient Linear Operator
# grad: R^{256x256} -> R^{256x255} x R^{255x256}
def grad(X):
    return (X[:, 1:] - X[:, :-1], X[1:, :] - X[:-1, :])

# The Adjoint of the Discrete Gradient Linear Operator
# grad_T: R^{256x255} x R^{255x256} -> R^{256x256}
def grad_T(Y):
    Y1, Y2 = Y
    N = Y1.shape[0]
    G_T = np.zeros((N, N))
    for i, j in product(range(N), range(N-1)): G_T[i, j] -= Y1[i, j]
    for i, j in product(range(N-1), range(N)): G_T[i, j] -= Y2[i, j]
    for i, j in product(range(N), range(1, N)): G_T[i, j] += Y1[i, j-1]
    for i, j in product(range(1, N), range(N)): G_T[i, j] += Y2[i-1, j]
    return G_T
