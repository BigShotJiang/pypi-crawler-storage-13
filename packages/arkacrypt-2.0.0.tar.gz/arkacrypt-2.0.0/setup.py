from setuptools import setup
from Cython.Build import cythonize

setup(
    name="arkacrypt",
    version="2.0.0",
    packages=["arkacrypt"],
    ext_modules=cythonize("arkacrypt/core.pyx", language_level="3"),
)
