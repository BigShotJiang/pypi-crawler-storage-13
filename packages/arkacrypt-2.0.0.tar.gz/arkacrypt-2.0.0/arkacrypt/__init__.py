"""Arkacrypt Cython wrapper."""
from .core import encode, run
__all__ = ["encode", "run"]
