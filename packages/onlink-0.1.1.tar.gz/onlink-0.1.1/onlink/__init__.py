__version__ = '0.1.1'

from bs4 import BeautifulSoup
import requests
import webbrowser
from urllib.parse import urlparse, urlunparse, urljoin
import re
import random
import sys
from ddgs import DDGS
import cv2
import numpy as np
from pprint import pprint # Kept for potential user debugging/inspection

# Initialize DDGS globally
ddgs = DDGS()

# Headers for HTTP requests
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'
}

def Url(argument):
    """
    Constructs a robust, absolute URL from an argument.
    Assumes HTTPS and appends .com if no dot is present in the hostname.
    """
    parsed = urlparse(argument)
    
    # 1. Ensure scheme is present (e.g., 'https://')
    # Use 'http' as a general fallback, it will be promoted to 'https' if not explicitly defined
    if not parsed.scheme and not argument.lower().startswith(('http://', 'https://')):
        # Prepend 'https://' to ensure proper parsing
        argument = 'https://' + argument
        parsed = urlparse(argument)
    
    # Re-evaluate hostname after scheme is fixed
    hostname = parsed.netloc.lower()

    # 2. Append '.com' if no TLD dot is found (e.g., 'google' -> 'google.com')
    if '.' not in hostname:
        new_netloc = hostname + '.com'
        parsed = parsed._replace(netloc=new_netloc)
        
    final_url = urlunparse(parsed)
    
    return final_url

def Open(webpage_url):
    """
    Opens a webpage URL in the default web browser.
    """
    my_url = Url(webpage_url)
    webbrowser.open(my_url)

def Wrap(text, min_chars=100, max_chars=150):
    """
    Wraps text into chunks of random length between min_chars and max_chars.
    """
    if not text:
        return ""

    result_chunks = []
    current_index = 0
    text_length = len(text)

    while current_index < text_length:
        remaining = text_length - current_index
        
        # Ensure target_step is calculated correctly based on limits and remaining text
        step_limit = min(max_chars, remaining)
        # Ensure min_chars doesn't exceed the step_limit, use step_limit if it does
        safe_min_chars = min(min_chars, step_limit)
        
        # If remaining text is less than min_chars, just take the rest
        if remaining <= safe_min_chars:
             target_step = remaining
        else:
             target_step = random.randint(safe_min_chars, step_limit)
        
        cut_off_index = current_index + target_step
        
        # Find the next space *after* the cut_off_index to cut cleanly
        space_index = text.find(' ', cut_off_index)
        
        if space_index != -1:
            final_cut = space_index + 1
        else:
            final_cut = text_length # Cut at the end of the text

        chunk = text[current_index:final_cut]
        result_chunks.append(chunk.rstrip()) 
        result_chunks.append('\n')
        
        current_index = final_cut

    return "".join(result_chunks).rstrip('\n')


def Read(webpage_url, line_break=125):
    """
    Fetches a webpage, extracts readable text from common block tags, 
    and wraps the text for terminal display. Uses global HEADERS.
    """
    page_url = Url(webpage_url)
    
    global HEADERS

    try:
        response = requests.get(page_url, headers=HEADERS)
        response.raise_for_status()

        raw_html = response.text
        soup = BeautifulSoup(raw_html, 'html.parser')
        
        block_tags = ['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'dt', 'dd'] 
        
        text_blocks = []
        for tag in soup.find_all(block_tags):
            block_text = tag.get_text(separator=' ', strip=True) 
            if block_text:
                # Remove extra spaces caused by get_text
                cleaned_block = re.sub(r' {2,}', ' ', block_text) 
                text_blocks.append(cleaned_block)

        cleaned_text = '\n\n'.join(text_blocks)
        
        final_lines = []
        for block in cleaned_text.split('\n\n'):
            if block:
                # Use line_break to dynamically set the wrap range
                randomly_wrapped_block = Wrap(block, min_chars=(line_break-25), max_chars=(line_break+25))
                final_lines.append(randomly_wrapped_block)

        final_formatted_text = '\n\n'.join(final_lines)

        return final_formatted_text

    except requests.exceptions.RequestException as e:
        print(f"An error occurred while fetching the URL or during processing: {e}", file=sys.stderr)
        return ""

def Search(search='latest technology news', where='worldwide', safe_search='on', results=10):
    """
    Performs a text search using DuckDuckGo Search (DDGS) and returns a tuple of URLs.
    """
    global ddgs

    results_list = list(ddgs.text(
        query=search,
        region=where if not where == 'worldwide' else 'wt-wt', # DDGS standard
        # Standardize safe_search input for DDGS
        safesearch='moderate' if safe_search.lower() == 'on' else 'off', 
        max_results=results
    ))

    urls = []
    if results_list:
        for result in results_list:
            found_url = result.get('href')
            if found_url:
                urls.append(found_url)
        
    if not urls:
        print("No text search results found.", file=sys.stderr)
        
    return tuple(urls)


def Image(search='What is Python?', where='worldwide', safe_search='on', results=5):
    """
    Performs an image search using DuckDuckGo Search (DDGS) and returns a tuple of image URLs.
    """
    global ddgs
    
    results_generator = ddgs.images(query=search,
                                     region=where if not where == 'worldwide' else 'wt-wt',
                                     safesearch='moderate' if safe_search.lower() == 'on' else 'off',
                                     max_results=results)

    results_list = list(results_generator)
    urls = []

    if results_list:
        for result in results_list:
            # The key is 'image' in DDGS image results
            urls.append(result.get('image')) 
        return tuple(urls)
    
    else:
        print("No images found.", file=sys.stderr)
        return tuple()


def Resize(img, target_size_str):
    """
    Resizes an OpenCV image to fit within the target_size_str (e.g., '640x480') 
    while maintaining the aspect ratio (scaling down only).
    """
    try:
        width_str, height_str = target_size_str.lower().split('x')
        target_width = int(width_str)
        target_height = int(height_str)
    except ValueError:
        print(f"Warning: Invalid size format '{target_size_str}'. Using original size.", file=sys.stderr)
        return img
    
    h, w = img.shape[:2]
    
    scale_w = target_width / w
    scale_h = target_height / h
    # Use the smaller scale factor to ensure the image fits within the target dimensions
    scale = min(scale_w, scale_h) 
    
    new_w = int(w * scale)
    new_h = int(h * scale)
    
    # FIX: Only resize if the image is larger than the target size (scale < 1)
    if scale >= 1:
        return img
            
    # Use INTER_AREA for scaling down (preferred)
    resized_img = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_AREA) 
    
    return resized_img


def Load(image_url):
    """
    Loads an image from a URL into an OpenCV (numpy) array using global HEADERS.
    """
    global HEADERS
    
    try:
        # FIX: Removed the headers parameter from the function signature and used global HEADERS
        response = requests.get(image_url, headers=HEADERS, timeout=10) 
        response.raise_for_status()

        # Convert raw content into a numpy array and then decode as an image
        image_array = np.asarray(bytearray(response.content), dtype="uint8")
        img_opencv = cv2.imdecode(image_array, cv2.IMREAD_COLOR)

        if img_opencv is None:
            # Handle cases where imdecode fails (e.g., non-image content)
            return None

        return img_opencv

    except requests.exceptions.RequestException as e:
        print(f"    [SKIP] Error fetching image '{image_url}': {e}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"    [SKIP] Unexpected error for '{image_url}': {e}", file=sys.stderr)
        return None


def Fetch(webpage_url, max_images=10, size=None):
    """
    Fetches the webpage, finds image tags, loads the images, and displays them 
    using OpenCV. Returns a list of loaded OpenCV images.
    """
    page_url = Url(webpage_url)
    
    global HEADERS # HEADERS are used inside Load()

    loaded_images = []

    try:
        response = requests.get(page_url, headers=HEADERS)
        response.raise_for_status()

        raw_html = response.text
        soup = BeautifulSoup(raw_html, 'html.parser')
        image_tags = soup.find_all('img')
        
        print(f"Found {len(image_tags)} image tags. Attempting to load up to {max_images} images...", file=sys.stderr)
        
        for i, img_tag in enumerate(image_tags):
            if len(loaded_images) >= max_images:
                break
            src = img_tag.get('src')
            if src:
                # Convert relative URL to absolute URL
                absolute_url = urljoin(page_url, src) 
                # FIX: Load() now uses global HEADERS, so the argument is removed
                opencv_image = Load(absolute_url) 
                if opencv_image is not None:
                    loaded_images.append(opencv_image)

        if loaded_images:
            for i, img in enumerate(loaded_images):
                # Basic check to skip tiny trackers/spacers
                if img is not None and img.shape[0] > 10 and img.shape[1] > 10: 
                    
                    img_to_display = img
                    current_size_str = f"{img.shape[1]}x{img.shape[0]}"

                    if size:
                        img_to_display = Resize(img, size)
                        
                        # Use the actual resized shape for the window size
                        display_width = img_to_display.shape[1]
                        display_height = img_to_display.shape[0]
                    else:
                        display_width = img.shape[1]
                        display_height = img.shape[0]

                    window_name = f"Web Image {i+1} - Original Shape: {current_size_str} - Display Size: {display_width}x{display_height}"
                    
                    cv2.imshow(window_name, img_to_display)
                    
                    # Resize the window for better viewing (using the determined display size)
                    # FIX: Use the calculated display_width/height (as ints)
                    cv2.resizeWindow(window_name, display_width, display_height)
                    
            print("\n*** DISPLAY ACTIVE ***: Close all image windows to continue script execution.", file=sys.stderr)
            cv2.waitKey(0) # Blocks until a key is pressed in the window
            cv2.destroyAllWindows() 
        else:
            print("No suitable images were found or loaded from the page.", file=sys.stderr)
            
        return loaded_images

    except requests.exceptions.RequestException as e:
        print(f"\nFATAL Error: Could not fetch the webpage '{page_url}': {e}", file=sys.stderr)
        return []
    except Exception as e:
        print(f"\nFATAL Error: An unexpected error occurred during page parsing: {e}", file=sys.stderr)
        return []


def Show(image_urls, size=None):
    """
    Loads images from a list of URLs and displays them using OpenCV.
    """
    global HEADERS # HEADERS are used inside Load()
    loaded_images = []
    
    print(f"Attempting to load {len(image_urls)} images...", file=sys.stderr)

    for image_url in image_urls:
        # FIX: Load() now uses global HEADERS, so no argument is needed
        img_opencv = Load(image_url) 
        if img_opencv is not None:
            loaded_images.append(img_opencv)

    if loaded_images:
        
        for i, img in enumerate(loaded_images):
            # Basic check to skip tiny trackers/spacers
            if img is not None and img.shape[0] > 10 and img.shape[1] > 10: 
                
                img_to_display = img
                current_size_str = f"{img.shape[1]}x{img.shape[0]}"

                if size:
                    img_to_display = Resize(img, size)
                    # Use the actual resized shape for the window size
                    display_width = img_to_display.shape[1]
                    display_height = img_to_display.shape[0]
                else:
                    display_width = img.shape[1]
                    display_height = img.shape[0]

                window_name = f"DDGS Image {i+1} - Original Shape: {current_size_str} - Display Size: {display_width}x{display_height}"
                
                cv2.imshow(window_name, img_to_display)
                
                # Resize the window for better viewing
                # FIX: Corrected typo from 'height_height' to 'display_height' (using the calculated variable)
                cv2.resizeWindow(window_name, display_width, display_height)
            else:
                print(f"Skipping tiny image {i+1} with shape: {img.shape}", file=sys.stderr)
        
        print("\nDISPLAY ACTIVE: Close all image windows to continue script execution.", file=sys.stderr)
        cv2.waitKey(0) # Blocks until a key is pressed in the window
        cv2.destroyAllWindows() 
        
    else:
        print("No images were successfully loaded to display.", file=sys.stderr)
        
    return loaded_images

__all__ = [
    'Open',
    'Read',
    'Search',
    'Image',
    'Load',
    'Fetch',
    'Show'
]
