"""
工具函数
"""

# 时间格式化（如 "yyyy-MM-dd HH:mm:ss"）
def time_format(foramt: str) -> str: ...

# 生成随机数（闭区间）
def random(min: int, max: int) -> int: ...

# 将应用切到前台
def take_me_to_front() -> None: ...