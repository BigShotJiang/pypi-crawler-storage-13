from typing import Any, Dict

# 检查更新（options: url/timeout/version），返回 {needUpdate,data?,error?}
def check_update(options: Dict[str, Any]) -> Dict[str, Any]: ...

# 下载并安装（返回 {updated,error?}）
def download_and_install() -> Dict[str, Any]: ...

# 获取当前应用版本号（整数）
def get_current_version() -> int: ...
