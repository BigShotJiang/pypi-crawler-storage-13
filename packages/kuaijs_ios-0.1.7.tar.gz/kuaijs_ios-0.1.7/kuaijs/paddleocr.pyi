from typing import Any, Dict, List

# 加载 PP-OCRv5 模型（maxSideLen 一般为 640）
def load_v5(maxSideLen: int) -> bool: ...

# 识别文本（返回字典列表：text/confidence/坐标信息）
def recognize(
    input: str, x: int, y: int, ex: int, ey: int, confidenceThreshold: float
) -> List[Dict[str, Any]]: ...

# 释放模型资源
def free() -> None: ...
