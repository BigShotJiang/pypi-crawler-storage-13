#!/usr/bin/env python3

import os
import sys
from pathlib import Path

import httpx


def main():
    """Generate Pydantic models from OpenAPI specification."""

    api_url = os.getenv("AUTH_MANAGER_API_URL", "http://localhost:8000")
    schema_url = f"{api_url}/openapi.json"

    print(f"fetching OpenAPI spec from {schema_url}...")

    try:
        response = httpx.get(schema_url, timeout=10.0)
        response.raise_for_status()
    except httpx.ConnectError:
        print(
            f"❌ error: Could not connect to API at {api_url}",
            file=sys.stderr,
        )
        print("   make sure the backend is running:", file=sys.stderr)
        print(
            "   cd auth-manager && uv run uvicorn app.main:app --reload",
            file=sys.stderr,
        )
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        print(
            f"❌ error: API returned {e.response.status_code}",
            file=sys.stderr,
        )
        sys.exit(1)
    except Exception as e:
        print(f"❌ error: {e}", file=sys.stderr)
        sys.exit(1)

    print(f"✓ fetched OpenAPI spec ({len(response.text)} bytes)")

    # Output paths
    sdk_root = Path(__file__).parent.parent / "authmanagersdk"
    output_file = sdk_root / "schemas" / "models.py"

    print(f"generating models to {output_file.relative_to(Path.cwd())}...")

    # Import here to show better error if not installed
    try:
        from datamodel_code_generator import (
            DataModelType,
            InputFileType,
            generate,
        )
    except ImportError:
        print(
            "❌ error: datamodel-code-generator not installed", file=sys.stderr
        )
        print("   run: uv sync", file=sys.stderr)
        sys.exit(1)

    # Generate models
    try:
        from datamodel_code_generator import PythonVersion

        generate(
            input_=response.text,
            input_file_type=InputFileType.OpenAPI,
            output=output_file,
            output_model_type=DataModelType.PydanticV2BaseModel,
            target_python_version=PythonVersion.PY_310,
            use_standard_collections=True,
            use_schema_description=True,
            field_constraints=True,
            snake_case_field=True,
            wrap_string_literal=True,
            use_union_operator=True,
        )
    except Exception as e:
        print(f"❌ error generating models: {e}", file=sys.stderr)
        sys.exit(1)

    print("✅ models generated successfully!")
    print(f"   generated: {output_file.relative_to(Path.cwd())}")
    print(f"   api uri: {api_url}")


if __name__ == "__main__":
    main()
