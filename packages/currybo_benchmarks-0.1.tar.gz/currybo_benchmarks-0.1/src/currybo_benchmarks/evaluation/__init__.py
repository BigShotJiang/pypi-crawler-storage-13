from .generality import find_max_generality, find_generality
