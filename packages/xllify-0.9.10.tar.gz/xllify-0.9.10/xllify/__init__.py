"""
xllify - Python SDK for creating Excel XLL add-ins

This package provides a simple way to expose Python functions to Excel
via xllify using RPC.
"""

from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from xllify.rpc_server import XllifyRPCServer

# Get version from package metadata (set in pyproject.toml)
try:
    from importlib.metadata import version
    __version__ = version("xllify")
except Exception:
    # Fallback for development or if package not installed
    __version__ = "0.0.0.dev"
__all__ = [
    "XllifyRPCServer",
    "Parameter",
    "RTDClient",
    "TopicUpdate",
    "RTDCommand",
    "CellValue",
    "Matrix",
    "ExcelValue",
    "get_server",
    "fn",
    "start_server",
    "configure_batching",
    "configure_spawn_count",
]

# Create default server instance for convenience
_default_server = None


def __getattr__(name):
    """Lazy import to avoid loading zmq-dependent modules unless actually used."""
    if name == "XllifyRPCServer":
        from xllify.rpc_server import XllifyRPCServer
        return XllifyRPCServer
    elif name == "Parameter":
        from xllify.rpc_server import Parameter
        return Parameter
    elif name == "RTDClient":
        from xllify.rtd_client import RTDClient
        return RTDClient
    elif name == "TopicUpdate":
        from xllify.rtd_client import TopicUpdate
        return TopicUpdate
    elif name == "RTDCommand":
        from xllify.rtd_client import RTDCommand
        return RTDCommand
    elif name == "CellValue":
        from xllify.rtd_client import CellValue
        return CellValue
    elif name == "Matrix":
        from xllify.rtd_client import Matrix
        return Matrix
    elif name == "ExcelValue":
        from xllify.rtd_client import ExcelValue
        return ExcelValue
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")

# Global spawn count configuration
_spawn_count: int = 1


def get_server() -> "XllifyRPCServer":
    """Get or create the default XllifyRPCServer instance."""
    global _default_server
    if _default_server is None:
        from xllify.rpc_server import XllifyRPCServer as _XllifyRPCServer
        _default_server = _XllifyRPCServer()
    return _default_server


# Convenience exports
fn = lambda *args, **kwargs: get_server().fn(*args, **kwargs)
fn.__doc__ = """Decorator to register a Python function as an Excel function. Alias for XllifyRPCServer.fn()"""

start_server = lambda: get_server().start()
start_server.__doc__ = (
    """Start the default RPC server. This is an alias to XllifyRPCServer.start()"""
)


def configure_batching(
    enabled: bool = True, batch_size: int = 500, batch_timeout_ms: int = 50
) -> None:
    """
    Configure batching behavior for RTD updates on the default server.

    Call this before starting the server to customize batching settings.
    Batching improves performance by sending multiple updates together.

    Args:
        enabled: Enable batching (default: True)
        batch_size: Maximum number of updates to batch together (default: 500)
        batch_timeout_ms: Maximum time to wait before flushing batch in milliseconds (default: 50)

    Example:
        import xllify

        xllify.configure_batching(batch_size=1000, batch_timeout_ms=100)

        @xllify.fn("xllipy.Hello")
        def hello(name: str) -> str:
            return f"Hello, {name}!"
    """
    get_server().configure_batching(
        enabled=enabled, batch_size=batch_size, batch_timeout_ms=batch_timeout_ms
    )


def configure_spawn_count(count: int) -> None:
    """
    Configure the number of Python processes to spawn for this module.

    This function both sets a runtime global that the RPC server reads and
    serves as a marker for funcinfo to extract the spawn_count value.

    Args:
        count: Number of processes to spawn (must be positive)

    Example:
        import xllify

        xllify.configure_spawn_count(4)

        @xllify.fn("xllipy.Hello")
        def hello(name: str) -> str:
            return f"Hello, {name}!"
    """
    global _spawn_count
    _spawn_count = count
