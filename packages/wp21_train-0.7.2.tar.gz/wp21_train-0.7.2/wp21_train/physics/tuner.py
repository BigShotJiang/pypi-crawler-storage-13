from dataclasses import dataclass
from typing import Dict, List
from ..training.tuner import ScoreBase, TrialRecord, TunerBase

@dataclass 
class PhysicsScore(ScoreBase):
    efficiency: List[Dict[str, List[float]]]
    rate: List[int]
    def __post_init__(self):
        self.score = -self.rate[0]

class PhysicsTuner(TunerBase):
    def _run_once(self):
        self.trainer.compile(self.params)
        history = self.trainer.fit(self.params)

        hist = {"loss": history.history.get("loss"), "val_loss": history.history.get("val_loss")}

        rec = TrialRecord(
            params = self.params,
            score = self.compute_physics_score(self.trainer.model, self.params),
            history = hist,
            model = self.trainer.model,
        )
        self.trials.append(rec)

    def compute_physics_score(self, model):
        raise NotImplementedError("compute_physics_score must be implemented in your project")



