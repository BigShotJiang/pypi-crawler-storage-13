from arcade_tdk.auth import GitHub

from arcade_github.constants import USE_OAUTH_APP_AUTH


def get_github_auth(scopes: list[str] | None = None) -> GitHub:
    """
    Get GitHub authentication configuration.

    When USE_OAUTH_APP_AUTH is False (default), returns GitHub() without scopes
    for GitHub Apps compatibility. When True, returns GitHub(scopes=...) for
    OAuth Apps compatibility.

    Args:
        scopes: List of required scopes for OAuth Apps. Used only when
                USE_OAUTH_APP_AUTH is True.

    Returns:
        GitHub authentication configuration instance.
    """
    if USE_OAUTH_APP_AUTH:
        return GitHub(scopes=scopes or [])
    return GitHub()


def get_required_secrets(needs_classic_token_for_github_apps: bool = False) -> list[str]:
    """
    Get the list of required secrets based on authentication mode.

    When USE_OAUTH_APP_AUTH is False (GitHub Apps), classic PAT is required for
    endpoints that GitHub Apps cannot access (e.g., notifications).

    When USE_OAUTH_APP_AUTH is True (OAuth Apps), classic PAT is NOT needed as
    OAuth tokens can access all endpoints with proper scopes.

    Args:
        needs_classic_token_for_github_apps: Whether this endpoint requires classic PAT
                                             when using GitHub Apps (e.g., notifications).

    Returns:
        List of required secret names.
    """
    secrets = ["GITHUB_SERVER_URL"]
    if not USE_OAUTH_APP_AUTH and needs_classic_token_for_github_apps:
        secrets.append("GITHUB_CLASSIC_PERSONAL_ACCESS_TOKEN")
    return secrets
