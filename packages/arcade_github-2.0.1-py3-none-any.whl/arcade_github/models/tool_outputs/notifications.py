from typing_extensions import TypedDict

from arcade_github.models.tool_outputs.common import PaginationInfo


class NotificationData(TypedDict, total=False):
    """Individual notification details."""

    id: str
    """Notification ID."""

    unread: bool
    """Whether notification is unread."""

    reason: str
    """Reason for notification (review_requested, mention, assign, etc.)."""

    subject_title: str
    """Title of the subject (PR/Issue title)."""

    subject_type: str
    """Type of subject (PullRequest, Issue, Release, etc.)."""

    subject_url: str
    """API URL of the subject."""

    repository_full_name: str
    """Full repository name (owner/repo)."""

    repository_url: str
    """Repository HTML URL."""

    updated_at: str
    """ISO 8601 timestamp of last update."""

    last_read_at: str
    """ISO 8601 timestamp when last read."""


class NotificationSummaryOutput(TypedDict, total=False):
    """Summary of user notifications."""

    total_unread: int
    """Total number of unread notifications."""

    by_reason: dict[str, int]
    """Count of notifications by reason."""

    by_repository: dict[str, int]
    """Count of notifications by repository."""

    by_type: dict[str, int]
    """Count of notifications by subject type."""

    oldest_unread_date: str
    """ISO 8601 date of oldest unread notification."""


class NotificationsListOutput(TypedDict, total=False):
    """Paginated list of notifications."""

    notifications: list[NotificationData]
    """List of notifications."""

    pagination: PaginationInfo
    """Pagination information."""


class ReviewWorkloadPR(TypedDict, total=False):
    """Pull request in review workload."""

    number: int
    """Pull request number."""

    title: str
    """PR title."""

    repository: str
    """Repository full name."""

    author: str
    """PR author login."""

    created_at: str
    """ISO 8601 creation timestamp."""

    updated_at: str
    """ISO 8601 last update timestamp."""

    html_url: str
    """GitHub web URL."""

    draft: bool
    """Whether PR is draft."""

    labels: list[str]
    """PR labels."""


class ReviewWorkloadOutput(TypedDict, total=False):
    """PR review workload information."""

    pending_reviews: list[ReviewWorkloadPR]
    """PRs awaiting your review."""

    pending_count: int
    """Number of PRs awaiting review."""

    reviewed_recently: list[ReviewWorkloadPR]
    """PRs you recently reviewed (still open)."""

    reviewed_count: int
    """Number of recently reviewed PRs."""
