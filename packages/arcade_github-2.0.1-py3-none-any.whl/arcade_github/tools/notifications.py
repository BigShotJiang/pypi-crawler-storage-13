from collections import defaultdict
from typing import Annotated, Any, cast

from arcade_tdk import ToolContext, tool

from arcade_github.models.api_responses.user import NotificationResponse
from arcade_github.models.mappers import map_notification
from arcade_github.models.models import NotificationSubjectType
from arcade_github.models.tool_outputs.common import PaginationInfo
from arcade_github.models.tool_outputs.notifications import (
    NotificationsListOutput,
    NotificationSummaryOutput,
)
from arcade_github.utils.auth_utils import get_github_auth, get_required_secrets
from arcade_github.utils.github_api_client import GitHubAPIClient
from arcade_github.utils.response_utils import remove_none_values_recursive


@tool(
    requires_auth=get_github_auth(scopes=["notifications"]),
    requires_secrets=get_required_secrets(needs_classic_token_for_github_apps=True),
)
async def get_notification_summary(
    context: ToolContext,
) -> Annotated[NotificationSummaryOutput, "Summary of user notifications"]:
    """
    Get a summary of GitHub notifications.

    Returns counts grouped by reason, repository, and type without full notification details.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_user_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    notifications, _ = await client.list_notifications(all_notifications=False, per_page=15)

    by_reason: dict[str, int] = defaultdict(int)
    by_repository: dict[str, int] = defaultdict(int)
    by_type: dict[str, int] = defaultdict(int)
    oldest_date = None

    unread_count = 0
    for notif in notifications:
        if notif.get("unread"):
            unread_count += 1
            updated_at = notif.get("updated_at")
            if updated_at and (oldest_date is None or updated_at < oldest_date):
                oldest_date = updated_at

        reason = notif.get("reason", "unknown")
        by_reason[reason] += 1

        repo = notif.get("repository", {})
        repo_name = repo.get("full_name", "unknown")
        by_repository[repo_name] += 1

        subject = notif.get("subject", {})
        subject_type = subject.get("type", "unknown")
        by_type[subject_type] += 1

    result: NotificationSummaryOutput = {
        "total_unread": unread_count,
        "by_reason": dict(by_reason),
        "by_repository": dict(by_repository),
        "by_type": dict(by_type),
        "oldest_unread_date": oldest_date or "",
    }

    return remove_none_values_recursive(result)


@tool(
    requires_auth=get_github_auth(scopes=["notifications"]),
    requires_secrets=get_required_secrets(needs_classic_token_for_github_apps=True),
)
async def list_notifications(
    context: ToolContext,
    page: Annotated[int, "Page number to fetch. Default is 1."] = 1,
    per_page: Annotated[int, "Number of notifications per page (max 100). Default is 30."] = 30,
    all_notifications: Annotated[bool, "Include read notifications. Default is False."] = False,
    participating: Annotated[
        bool, "Only show notifications user is participating in. Default is False."
    ] = False,
    repository_full_name: Annotated[
        str | None, "Filter notifications to owner/name repository. Default is None."
    ] = None,
    subject_types: Annotated[
        list[NotificationSubjectType] | None,
        "List of notification subject types to include. Default is None (all types).",
    ] = None,
) -> Annotated[NotificationsListOutput, "Paginated list of notifications"]:
    """
    List GitHub notifications with pagination.

    Returns notifications sorted chronologically by most recent first.
    """
    base_url = GitHubAPIClient.get_base_url(context)
    token = GitHubAPIClient.get_user_token(context)
    client = GitHubAPIClient(base_url=base_url, token=token)

    per_page = min(max(1, per_page), 100)
    notifications, has_next_page = await client.list_notifications(
        all_notifications=all_notifications,
        participating=participating,
        per_page=per_page,
        page=page,
    )

    normalized_repo = repository_full_name.strip().lower() if repository_full_name else None
    normalized_subject_types = {st.value.lower() for st in subject_types} if subject_types else None

    if normalized_repo or normalized_subject_types:
        filtered_notifications: list[dict[str, Any]] = []
        for notification in notifications:
            repo_name = ((notification.get("repository") or {}).get("full_name") or "").lower()
            if normalized_repo and repo_name != normalized_repo:
                continue

            subject_type_value = ((notification.get("subject") or {}).get("type") or "").lower()
            if normalized_subject_types and subject_type_value not in normalized_subject_types:
                continue

            filtered_notifications.append(notification)

        notifications = filtered_notifications

    pagination: PaginationInfo = {
        "page": page,
        "per_page": per_page,
        "has_next_page": has_next_page,
    }

    result: NotificationsListOutput = {
        "notifications": [
            map_notification(cast(NotificationResponse, notif)) for notif in notifications
        ],
        "pagination": pagination,
    }

    return remove_none_values_recursive(result)
