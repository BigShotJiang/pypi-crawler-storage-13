"""CLI Orchestrator for unified generation workflows."""

from dataclasses import dataclass
from pathlib import Path

from core.ast_models import Action, Entity
from core.specql_parser import SpecQLParser
from src.generators.output_strategy import create_output_strategy, OutputContext
from src.generators.targets.postgresql.generators.schema.naming_conventions import (
    NamingConventions,
)
from src.generators.targets.postgresql.generators.schema_orchestrator import SchemaOrchestrator
from utils.performance_monitor import get_performance_monitor


def convert_entity_definition_to_entity(entity_def):
    """Convert EntityDefinition (parser output) to Entity (generator input)."""
    # Convert ActionDefinition to Action
    actions = []
    for action_def in entity_def.actions:
        action = Action(name=action_def.name, steps=action_def.steps, impact=action_def.impact)
        actions.append(action)

    # Create Entity
    entity = Entity(
        name=entity_def.name,
        schema=entity_def.schema,
        description=entity_def.description,
        fields=entity_def.fields,
        actions=actions,
        agents=entity_def.agents,
        organization=getattr(entity_def, "organization", None),
    )

    return entity


@dataclass
class MigrationFile:
    """Represents a generated migration file"""

    number: int  # Kept for backward compatibility
    name: str
    content: str
    path: Path | None = None
    table_code: str | None = None  # NEW: Hexadecimal table code


@dataclass
class GenerationResult:
    """Result of generation process"""

    migrations: list[MigrationFile]
    errors: list[str]
    warnings: list[str]


class CLIOrchestrator:
    """Orchestrate all Teams for CLI commands"""

    def __init__(
        self,
        use_registry: bool = False,
        output_strategy: str = "confiture",
        enable_performance_monitoring: bool = False,
        logger=None,
    ):
        self.enable_performance_monitoring = enable_performance_monitoring
        self.perf_monitor = get_performance_monitor() if enable_performance_monitoring else None

        self.parser = SpecQLParser(
            logger=logger, enable_performance_monitoring=enable_performance_monitoring
        )
        self.schema_orchestrator = SchemaOrchestrator(
            enable_performance_monitoring=enable_performance_monitoring,
            registry_optional=not use_registry,  # Make registry optional when not explicitly using it
        )

        # NEW: Registry integration
        self.use_registry = use_registry
        self.output_strategy_name = output_strategy
        self.output_strategy = create_output_strategy(output_strategy)
        if use_registry:
            self.naming = NamingConventions()
        else:
            self.naming = None

    def get_table_code(self, entity) -> str:
        """
        Derive table code from registry

        Returns:
            6-character hexadecimal table code (e.g., "012311")
        """
        if not self.use_registry or not self.naming:
            raise ValueError("Registry not enabled. Use CLIOrchestrator(use_registry=True)")

        return self.naming.derive_table_code(entity)

    def generate_file_path(
        self,
        entity,
        table_code: str,
        file_type: str = "table",
        base_dir: str = "generated/migrations",
    ) -> str:
        """
        Generate file path (registry-aware or legacy flat)

        Args:
            entity: Entity AST model
            table_code: 6-digit hexadecimal table code
            file_type: Type of file ('table', 'function', 'comment')
            base_dir: Base directory for output

        Returns:
            File path (hierarchical if registry enabled, flat otherwise)
        """
        if self.use_registry and self.naming:
            if self.output_strategy_name == "confiture":
                # Use Confiture-compatible flat paths
                return self.generate_file_path_confiture(entity, file_type)
            else:
                # Use registry's hierarchical path
                return self.naming.generate_file_path(
                    entity=entity, table_code=table_code, file_type=file_type, base_dir=base_dir
                )
        else:
            # Legacy flat path
            return str(Path(base_dir) / f"{table_code}_{entity.name.lower()}.sql")

    def generate_file_path_confiture(self, entity, file_type: str) -> str:
        """
        Generate Confiture-compatible flat paths

        Maps registry layers to Confiture directories:
        - 01_write_side → db/schema/10_tables
        - 03_functions → db/schema/30_functions
        - metadata → db/schema/40_metadata
        """
        confiture_map = {"table": "10_tables", "function": "30_functions", "comment": "40_metadata"}

        dir_name = confiture_map.get(file_type, "10_tables")
        filename = f"{entity.name.lower()}.sql"

        return f"db/schema/{dir_name}/{filename}"

    def generate_with_output_strategy(
        self, entity: Entity, output_dir: Path, table_code: str | None = None
    ) -> list[MigrationFile]:
        """
        Generate files for an entity using the configured output strategy.

        Args:
            entity: Entity to generate files for
            output_dir: Base output directory
            table_code: Optional table code for registry-based strategies

        Returns:
            List of generated migration files
        """
        # Create output context
        context = OutputContext(
            base_dir=output_dir,
            entities=[entity],
            use_registry=self.use_registry,
            table_codes={entity.name: table_code} if table_code else None,
        )

        # Prepare output directories
        self.output_strategy.prepare_directories(context)

        # Generate file outputs using the strategy
        file_outputs = self.output_strategy.generate_file_outputs(context, entity, table_code)

        # Write files and collect migration info
        written_files = self.output_strategy.write_files(context, file_outputs)

        # Convert to MigrationFile objects
        migrations = []
        for file_path in written_files:
            # Read the content back to store in migration
            content = file_path.read_text()

            migration = MigrationFile(
                number=int(table_code, 16) if table_code else 0,
                name=entity.name.lower(),
                content=content,
                path=file_path,
                table_code=table_code,
            )
            migrations.append(migration)

        return migrations

    def generate_from_files(
        self,
        entity_files: list[str],
        output_dir: str = "migrations",
        with_impacts: bool = False,
        include_tv: bool = False,
        foundation_only: bool = False,
    ) -> GenerationResult:
        """
        Generate migrations from SpecQL files (registry-aware)

        When use_registry=True:
        - Derives hexadecimal table codes
        - Creates hierarchical directory structure
        - Registers entities in domain_registry.yaml

        When use_registry=False:
        - Uses legacy flat numbering (000, 100, 200)
        - Single directory output
        """

        result = GenerationResult(migrations=[], errors=[], warnings=[])
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # Foundation only mode
        if foundation_only:
            foundation_sql = self.schema_orchestrator.generate_app_foundation_only()
            migration = MigrationFile(
                number=0,
                name="app_foundation",
                content=foundation_sql,
                path=output_path / "000_app_foundation.sql",
            )
            result.migrations.append(migration)
            # Write the file
            if migration.path:
                migration.path.write_text(migration.content)
            return result

        # Generate foundation first
        foundation_sql = self.schema_orchestrator.generate_app_foundation_only()
        if foundation_sql:
            if self.output_strategy_name == "confiture":
                # For Confiture: write to db/schema/00_foundation/
                foundation_dir = Path("db/schema/00_foundation")
                foundation_dir.mkdir(parents=True, exist_ok=True)
                foundation_path = foundation_dir / "000_app_foundation.sql"
                foundation_path.write_text(foundation_sql)
                migration = MigrationFile(
                    number=0,
                    name="app_foundation",
                    content=foundation_sql,
                    path=foundation_path,
                )
            else:
                # Legacy format: write to output_dir
                migration = MigrationFile(
                    number=0,
                    name="app_foundation",
                    content=foundation_sql,
                    path=output_path / "000_app_foundation.sql",
                )
            result.migrations.append(migration)

        # Parse all entities
        entity_defs = []
        for entity_file in entity_files:
            try:
                content = Path(entity_file).read_text()
                entity_def = self.parser.parse(content)
                entity_defs.append(entity_def)
            except Exception as e:
                result.errors.append(f"Failed to parse {entity_file}: {e}")

        # Generate entity migrations
        for entity_def in entity_defs:
            try:
                entity = convert_entity_definition_to_entity(entity_def)

                # Generate schema output
                schema_output = self.schema_orchestrator.generate_split_schema(entity)

                table_code = None
                if self.use_registry:
                    # Registry-based generation
                    table_code = self.get_table_code(entity)

                    # Register entity if using registry
                    if self.naming:
                        self.naming.register_entity_auto(entity, table_code)

                # Use output strategy to generate files
                context = OutputContext(
                    base_dir=output_path,
                    entities=[entity],
                    use_registry=self.use_registry,
                    table_codes={entity.name: table_code} if table_code else None,
                    schema_outputs={entity.name: schema_output},
                )

                # Generate file outputs using the strategy
                file_outputs = self.output_strategy.generate_file_outputs(
                    context, entity, table_code
                )

                # Write files
                written_files = self.output_strategy.write_files(context, file_outputs)

                # Track all files as migrations
                for file_path in written_files:
                    content = file_path.read_text()
                    migration = MigrationFile(
                        number=int(table_code, 16) if table_code else 0,
                        name=entity.name.lower(),
                        content=content,
                        path=file_path,
                        table_code=table_code,
                    )
                    result.migrations.append(migration)

            except Exception as e:
                result.errors.append(f"Failed to generate {entity_def.name}: {e}")

        # Generate tv_ tables if requested
        if include_tv and entity_defs:
            try:
                tv_sql = self.schema_orchestrator.generate_table_views(entity_defs)
                if tv_sql:
                    migration = MigrationFile(
                        number=200,
                        name="table_views",
                        content=tv_sql,
                        path=output_path / "200_table_views.sql",
                    )
                    result.migrations.append(migration)
            except Exception as e:
                result.errors.append(f"Failed to generate tv_ tables: {e}")

        # Write migrations to disk
        for migration in result.migrations:
            if migration.path:
                migration.path.write_text(migration.content)

        return result
