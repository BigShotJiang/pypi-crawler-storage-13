"""
Reverse SQL subcommand - Convert SQL DDL and functions to SpecQL YAML.

Uses the unified ReverseEngineeringPipeline for all processing.
Supports all pattern detection, AI enhancement, and view association.
"""

from pathlib import Path

import click

from cli.utils.error_handler import handle_cli_error
from cli.utils.output import output as cli_output


@click.command()
@click.argument("files", nargs=-1, required=True, type=click.Path(exists=True))
@click.option("-o", "--output", required=True, type=click.Path(), help="Output directory")
@click.option(
    "--functions-dir",
    type=click.Path(exists=True),
    help="Directory containing SQL function files for identifier extraction",
)
@click.option(
    "--views-dir",
    type=click.Path(exists=True),
    multiple=True,
    help="Additional directories containing view definitions",
)
@click.option("--min-confidence", default=0.80, type=float, help="Minimum confidence threshold")
@click.option(
    "--ai/--no-ai",
    default=None,
    help="Enable/disable AI enhancement (default: auto-detect)",
)
@click.option(
    "--ai-provider",
    type=click.Choice(["auto", "opencode", "ollama", "anthropic", "openai", "local"]),
    default="auto",
    help="AI provider to use (auto detects best available)",
)
@click.option("--merge-translations/--no-merge-translations", default=True)
@click.option("--preview", is_flag=True, help="Preview without writing")
@click.option("--with-patterns", is_flag=True, help="Auto-detect and apply patterns")
@click.option("--hierarchical", is_flag=True, help="Output hierarchical by schema (default: flat)")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
@click.option("--quiet", "-q", is_flag=True, help="Suppress non-error output")
def sql(
    files,
    output,
    functions_dir,
    views_dir,
    min_confidence,
    ai,
    ai_provider,
    merge_translations,
    preview,
    with_patterns,
    hierarchical,
    verbose,
    quiet,
    **kwargs,
):
    """Reverse engineer SQL files to SpecQL YAML.

    Handles both table DDL and PL/pgSQL functions. Auto-detects
    Trinity pattern, foreign keys, audit fields, and more.

    AI Enhancement:
      By default, AI is auto-detected. Free providers (opencode, ollama)
      are preferred. Use --no-ai to disable.

    Examples:

        specql reverse sql db/tables/*.sql -o entities/

        specql reverse sql functions.sql -o entities/ --no-ai

        specql reverse sql db/ -o entities/ --with-patterns

        specql reverse sql tables/*.sql -o entities/ --views-dir views/

        specql reverse sql schema/*.sql -o entities/ --ai-provider=ollama
    """
    with handle_cli_error():
        from cli.utils.output import set_output_config

        set_output_config(verbose=verbose, quiet=quiet)

        cli_output.info(f"Reversing {len(files)} SQL file(s)")

        # Use the unified pipeline
        from reverse_engineering.pipeline import PipelineConfig, ReverseEngineeringPipeline

        # Build configuration
        # Note: reverse sql uses flat output by default for backward compatibility
        # Use --hierarchical to organize by schema
        config = PipelineConfig(
            output_dir=Path(output),
            hierarchical_output=hierarchical,  # Flat by default for reverse sql
            min_confidence=min_confidence,
            use_ai=ai,
            ai_provider=ai_provider,
            merge_translations=merge_translations,
            with_patterns=with_patterns,
            views_dirs=[Path(v) for v in views_dir],
            functions_dir=Path(functions_dir) if functions_dir else None,
            preview=preview,
            verbose=verbose,
            quiet=quiet,
            validate=False,  # Don't validate by default for sql command
            generate_report=False,  # Don't generate report by default
            on_progress=cli_output.info,
            on_warning=cli_output.warning,
            on_success=cli_output.success,
        )

        # Create pipeline
        pipeline = ReverseEngineeringPipeline(config)

        # Process the files
        file_paths = [Path(f) for f in files]
        result = pipeline.process_files(file_paths)

        if preview:
            cli_output.info("Preview mode - showing what would be generated:")
            return

        # Summary
        cli_output.success(f"Generated {result.entities_generated} file(s)")

        if result.ai_provider_used:
            cli_output.info(f"  AI provider: {result.ai_provider_used}")

        if result.with_identifiers > 0:
            cli_output.info(f"  With identifiers: {result.with_identifiers}")

        if result.with_views > 0:
            cli_output.info(f"  With views: {result.with_views}")

        if result.low_confidence_files:
            cli_output.warning(
                f"  {len(result.low_confidence_files)} file(s) below confidence threshold ({min_confidence:.0%}):"
            )
            for table_name, confidence, patterns in result.low_confidence_files:
                cli_output.warning(f"    {table_name}: {confidence:.0%} (patterns: {patterns})")
