"""
Reverse project subcommand - Auto-detect and process entire projects.

Uses the unified ReverseEngineeringPipeline for ALL frameworks.
Single implementation for SQL, Django, Rust, TypeScript, Prisma.

Features:
- Auto-detect project type (SQL, Django, Rust, TypeScript, Prisma)
- AI enhancement with auto-detected provider (opencode, ollama, anthropic, openai)
- Smart hierarchical output based on project complexity
- Identifier extraction from recalcid_* functions (SQL)
- View detection and classification (v_*, tv_*, mv_*)
- Pattern detection (translation tables, info/instance pairs)
- Automatic project.yaml generation
"""

from pathlib import Path

import click

from cli.utils.error_handler import handle_cli_error
from cli.utils.output import output


def detect_project_type(directory: Path) -> str:
    """Auto-detect project type from files."""
    if (directory / "manage.py").exists():
        return "django"
    if (directory / "Cargo.toml").exists():
        return "rust"
    if (directory / "package.json").exists():
        pkg = Path(directory / "package.json")
        try:
            import json

            with open(pkg) as f:
                data = json.load(f)
            if "prisma" in data.get("dependencies", {}):
                return "prisma"
            return "typescript"
        except Exception:
            return "typescript"
    if (directory / "requirements.txt").exists():
        return "python"

    # Check for SQL-based projects
    sql_dirs = ["db", "schema", "sql", "database", "migrations"]
    for sql_dir in sql_dirs:
        sql_path = directory / sql_dir
        if sql_path.exists() and sql_path.is_dir():
            sql_files = list(sql_path.glob("**/*.sql"))
            if sql_files:
                return "sql"

    root_sql_files = list(directory.glob("*.sql"))
    if root_sql_files:
        return "sql"

    return "unknown"


@click.command()
@click.argument("directory", type=click.Path(exists=True, file_okay=False))
@click.option("-o", "--output-dir", required=True, type=click.Path(), help="Output directory")
@click.option(
    "--framework",
    type=click.Choice(["django", "python", "rust", "prisma", "typescript", "sql"]),
    help="Override auto-detection",
)
@click.option("--preview", is_flag=True, help="Preview without writing files")
@click.option("--no-validate", is_flag=True, help="Skip YAML validation")
@click.option("--no-report", is_flag=True, help="Skip report generation")
@click.option(
    "--views-dir",
    type=click.Path(exists=True),
    multiple=True,
    help="Additional directories containing view definitions",
)
@click.option(
    "--functions-dir",
    type=click.Path(exists=True),
    help="Directory containing SQL function files for identifier extraction",
)
@click.option(
    "--ai/--no-ai",
    default=None,
    help="Enable/disable AI enhancement (default: auto-detect)",
)
@click.option(
    "--ai-provider",
    type=click.Choice(["opencode", "ollama", "anthropic", "openai", "local"]),
    help="AI provider to use (default: auto-detect best available)",
)
@click.option("--min-confidence", default=0.80, type=float, help="Minimum confidence threshold")
@click.option("--flat", is_flag=True, help="Force flat output (default: auto based on complexity)")
@click.option("--hierarchical", is_flag=True, help="Force hierarchical output by schema")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
@click.option("--quiet", "-q", is_flag=True, help="Suppress non-error output")
def project(
    directory,
    output_dir,
    framework,
    preview,
    no_validate,
    no_report,
    views_dir,
    functions_dir,
    ai,
    ai_provider,
    min_confidence,
    flat,
    hierarchical,
    verbose,
    quiet,
    **kwargs,
):
    """Reverse engineer an entire project to SpecQL YAML.

    Auto-detects project type and processes all relevant files using
    the unified reverse engineering pipeline.

    AI Enhancement:
      By default, AI is auto-detected. Free providers (opencode, ollama)
      are preferred. Use --no-ai to disable.

    For SQL projects:
      - Extracts identifiers from recalcid_* functions
      - Detects and classifies views (v_*, tv_*, mv_*)
      - Generates project.yaml automatically
      - Creates extraction report with metrics

    Examples:

        specql reverse project ./my-django-app -o entities/

        specql reverse project ./printoptim -o output/ --framework=sql

        specql reverse project . --preview

        specql reverse project ./db -o entities/ --views-dir ./db/02_views/

        specql reverse project ./db -o entities/ --ai-provider=ollama
    """
    with handle_cli_error():
        from cli.utils.output import set_output_config
        from reverse_engineering.pipeline import PipelineConfig, ReverseEngineeringPipeline

        set_output_config(verbose=verbose, quiet=quiet)

        project_path = Path(directory)
        output.info(f"Analyzing project: {project_path.absolute()}")

        # Detect project type
        project_type = framework or detect_project_type(project_path)
        output.info(f"Project type: {project_type}")

        if project_type == "unknown":
            output.warning("Could not detect project type. Use --framework to specify explicitly.")
            output.info("Supported: django, python, rust, prisma, typescript, sql")
            raise click.ClickException("Unknown project type")

        output_path = Path(output_dir)

        if preview:
            output.info("Preview mode: no files will be written")

        # Determine hierarchical output setting
        # None = auto-detect based on complexity
        # True = forced hierarchical, False = forced flat
        hierarchical_setting = None  # Auto by default
        if flat:
            hierarchical_setting = False
        elif hierarchical:
            hierarchical_setting = True

        # Build unified pipeline configuration
        config = PipelineConfig(
            output_dir=output_path,
            source_type=project_type,
            hierarchical_output=hierarchical_setting,
            min_confidence=min_confidence,
            use_ai=ai,
            ai_provider=ai_provider,
            views_dirs=[Path(v) for v in views_dir],
            functions_dir=Path(functions_dir) if functions_dir else None,
            preview=preview,
            verbose=verbose,
            quiet=quiet,
            validate=not no_validate,
            generate_report=not no_report,
            on_progress=output.info,
            on_warning=output.warning,
            on_success=output.success,
        )

        # Create pipeline
        pipeline = ReverseEngineeringPipeline(config)

        # Process using appropriate method based on framework
        if project_type == "sql":
            result = pipeline.process_directory(project_path)
        else:
            result = pipeline.process_framework_project(project_path, project_type)

        # Display results
        if not preview:
            output.success("\nProject extraction complete!")
            output.info(f"   Entities: {result.entities_generated}")

            # SQL-specific info
            if project_type == "sql":
                if result.domains:
                    output.info(f"   Schemas: {', '.join(result.domains)}")
                output.info(f"   With identifiers: {result.with_identifiers}")
                output.info(f"   With views: {result.with_views}")
            else:
                # Framework-specific info
                if result.apps:
                    output.info(f"   Apps/Modules: {', '.join(result.apps)}")

            auto_note = " (auto)" if hierarchical_setting is None else ""
            output.info(f"   Output: {result.output_structure}{auto_note}")

            if result.ai_provider_used:
                output.info(f"   AI provider: {result.ai_provider_used}")

            if result.valid_yaml > 0 and result.entities_generated > 0:
                pct = result.valid_yaml * 100 / result.entities_generated
                output.info(f"   Valid YAML: {result.valid_yaml} ({pct:.1f}%)")

            if result.low_confidence_files:
                output.warning(f"   Low confidence: {len(result.low_confidence_files)} files")

            if result.warnings:
                output.warning(f"   Warnings: {len(result.warnings)}")
        else:
            output.info("Preview complete")
