"""Prisma/TypeScript target for SpecQL code generation."""
