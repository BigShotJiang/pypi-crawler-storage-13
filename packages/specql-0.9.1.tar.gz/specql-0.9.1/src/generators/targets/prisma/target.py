"""Prisma target for SpecQL code generation."""

from typing import TYPE_CHECKING, Any

from src.generators.targets.base.registry import register_target
from src.generators.targets.base.target import BaseTarget, GeneratedFile, GenerationResult
from src.generators.targets.prisma.prisma_generator import PrismaGenerator
from src.generators.targets.prisma.typescript_generator import TypeScriptGenerator

if TYPE_CHECKING:
    pass


@register_target("prisma")
class PrismaTarget(BaseTarget):
    """Prisma/TypeScript code generation target.

    Generates Prisma schema and TypeScript interfaces for database-first
    TypeScript applications using Prisma ORM.
    """

    @property
    def name(self) -> str:
        """The name of this target."""
        return "prisma"

    @property
    def supported_languages(self) -> list[str]:
        """List of programming languages this target generates."""
        return ["typescript", "prisma"]

    def __init__(self):
        """Initialize the Prisma target with its components."""
        self.prisma_generator = PrismaGenerator()
        self.typescript_generator = TypeScriptGenerator()

    def generate(self, entity_ir: Any) -> GenerationResult:
        """Generate Prisma and TypeScript code for the given entity IR.

        Args:
            entity_ir: EntityIR definition to generate Prisma/TypeScript code for

        Returns:
            GenerationResult containing all generated files
        """
        files = []
        errors = []
        warnings = []

        try:
            # Generate Prisma schema
            prisma_files = self.prisma_generator.generate_schema([entity_ir])
            files.extend(prisma_files)

            # Generate TypeScript interfaces
            typescript_files = self.typescript_generator.generate_interfaces([entity_ir])
            files.extend(typescript_files)

        except Exception as e:
            errors.append(f"Generation failed: {str(e)}")
            return GenerationResult(
                success=False, files=files, target_name=self.name, errors=errors, warnings=warnings
            )

        return GenerationResult(
            success=True, files=files, target_name=self.name, errors=errors, warnings=warnings
        )
