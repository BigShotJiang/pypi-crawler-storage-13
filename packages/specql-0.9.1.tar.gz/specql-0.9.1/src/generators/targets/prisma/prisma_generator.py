"""Prisma schema generator."""

from typing import TYPE_CHECKING, Any

from src.generators.targets.base.target import GeneratedFile

if TYPE_CHECKING:
    pass


class PrismaGenerator:
    """Generates Prisma schema files from EntityIR."""

    def generate_schema(self, entities: Any) -> list[GeneratedFile]:
        """Generate Prisma schema files."""
        files = []

        # Generate schema.prisma
        schema_content = self._generate_schema_content(entities)
        files.append(
            GeneratedFile(
                path="prisma/schema.prisma",
                content=schema_content,
                language="prisma",
                metadata={"type": "schema", "category": "prisma"},
            )
        )

        return files

    def _generate_schema_content(self, entities: Any) -> str:
        """Generate complete Prisma schema content."""
        parts = []

        # Add schema header
        parts.append(self._generate_header())
        parts.append("")

        # Generate enums first
        for entity in entities:
            enum_definitions = self._generate_enums(entity)
            if enum_definitions:
                parts.extend(enum_definitions)
                parts.append("")

        # Generate models
        for entity in entities:
            model_definition = self._generate_model(entity)
            parts.append(model_definition)
            parts.append("")

        return "\n".join(parts)

    def _generate_header(self) -> str:
        """Generate Prisma schema header."""
        return """generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}"""

    def _generate_enums(self, entity: Any) -> list[str]:
        """Generate enum declarations for entity."""
        enums = []

        for field in entity.fields:
            if hasattr(field, "type_ir") and field.type_ir.category.name == "ENUM":
                enum_name = f"{field.name.capitalize()}Status"
                enum_values = getattr(field.type_ir, "enum_values", [])
                if enum_values:
                    enum_def = f"enum {enum_name} {{"
                    enum_def += "\n  " + "\n  ".join(enum_values)
                    enum_def += "\n}"
                    enums.append(enum_def)

        return enums

    def _generate_model(self, entity: Any) -> str:
        """Generate a single Prisma model."""
        lines = [f"model {entity.name} {{"]

        # Add fields
        for field in entity.fields:
            field_line = self._generate_field(field, entity)
            if field_line:
                lines.append(f"  {field_line}")

        lines.append("}")

        return "\n".join(lines)

    def _generate_field(self, field: Any, entity: Any) -> str:
        """Generate a single Prisma field declaration."""
        field_name = field.name

        # Handle different field types
        if hasattr(field, "type_ir"):
            if field.type_ir.category.name == "REFERENCE":
                # Generate foreign key field
                fk_field_name = f"{field_name}Id"
                fk_type = "Int"
                optional = "?" if not getattr(field, "required", True) else ""

                # Add foreign key field
                fk_line = f"{fk_field_name:<15} {fk_type}{optional}"

                # Add relation field
                ref_entity = getattr(field.type_ir, "referenced_entity", field_name.capitalize())
                relation_line = f"{field_name:<15} {ref_entity}{optional}  @relation(fields: [{fk_field_name}], references: [id])"

                return f"{fk_line}\n  {relation_line}"

            elif field.type_ir.category.name == "ENUM":
                field_type = f"{field_name.capitalize()}Status"
            elif field.type_ir.category.name == "LIST":
                base_type = self._map_scalar_type(field.type_ir.base_type)
                field_type = f"{base_type}[]"
            else:
                field_type = self._map_scalar_type(field.type_ir.base_type)
        else:
            field_type = "String"

        # Optional marker
        optional = "?" if not getattr(field, "required", True) else ""

        # Attributes
        attributes = []

        # ID field
        if field_name == "id":
            attributes.append("@id @default(autoincrement())")

        # Unique constraint
        if getattr(field, "unique", False):
            attributes.append("@unique")

        # Default values
        default_value = getattr(field, "default", None)
        if default_value is not None:
            if isinstance(default_value, bool):
                attributes.append(f"@default({str(default_value).lower()})")
            elif isinstance(default_value, str):
                attributes.append(f'@default("{default_value}")')

        # Special handling for timestamp fields
        if field_name == "createdAt" and field_type == "DateTime":
            attributes.append("@default(now())")
        elif field_name == "updatedAt" and field_type == "DateTime":
            attributes.append("@updatedAt")

        # Soft delete field
        if field_name == "deletedAt":
            optional = "?"

        # Build field line
        field_line = f"{field_name:<15} {field_type}{optional}"

        if attributes:
            field_line += "  " + " ".join(attributes)

        return field_line

    def _map_scalar_type(self, base_type: str) -> str:
        """Map SpecQL scalar types to Prisma types."""
        type_mapping = {
            "string": "String",
            "text": "String",
            "integer": "Int",
            "int": "Int",
            "float": "Float",
            "decimal": "Decimal",
            "boolean": "Boolean",
            "bool": "Boolean",
            "date": "DateTime",
            "datetime": "DateTime",
            "timestamp": "DateTime",
            "uuid": "String",
            "json": "Json",
            "jsonb": "Json",
        }
        return type_mapping.get(base_type, "String")
