"""React component generator."""

from typing import TYPE_CHECKING, Any

from src.generators.targets.base.target import GeneratedFile

if TYPE_CHECKING:
    pass


class ReactComponentGenerator:
    """Generates React components for entities."""

    def generate_components(self, entities: Any) -> list[GeneratedFile]:
        """Generate React component files."""
        files = []

        for entity in entities:
            # Generate list component
            list_content = self._generate_list_component(entity)
            entity_name = self._to_pascal_case(entity.name)

            files.append(
                GeneratedFile(
                    path=f"src/components/{entity_name}List.tsx",
                    content=list_content,
                    language="tsx",
                    metadata={"type": "component", "variant": "list", "entity": entity.name},
                )
            )

            # Generate form component
            form_content = self._generate_form_component(entity)
            files.append(
                GeneratedFile(
                    path=f"src/components/{entity_name}Form.tsx",
                    content=form_content,
                    language="tsx",
                    metadata={"type": "component", "variant": "form", "entity": entity.name},
                )
            )

            # Generate detail component
            detail_content = self._generate_detail_component(entity)
            files.append(
                GeneratedFile(
                    path=f"src/components/{entity_name}Detail.tsx",
                    content=detail_content,
                    language="tsx",
                    metadata={"type": "component", "variant": "detail", "entity": entity.name},
                )
            )

        # Generate components index
        components_index = self._generate_components_index(entities)
        files.append(
            GeneratedFile(
                path="src/components/index.ts",
                content=components_index,
                language="typescript",
                metadata={"type": "index", "category": "components"},
            )
        )

        return files

    def _generate_list_component(self, entity: Any) -> str:
        """Generate list component for an entity."""
        entity_name = self._to_pascal_case(entity.name)
        entity_name_lower = entity.name.lower()

        lines = [
            "import React, { useEffect, useState } from 'react';",
            "import {",
            f"  {entity_name},",
            f"  {entity_name_lower}Api,",
            "} from '../api';",
            "",
            f"export const {entity_name}List: React.FC = () => {{",
            f"  const [{entity_name_lower}s, set{entity_name}s] = useState<{entity_name}[]>([]);",
            "  const [loading, setLoading] = useState(true);",
            "  const [error, setError] = useState<string | null>(null);",
            "",
            "  useEffect(() => {",
            "    const fetchData = async () => {",
            "      try {",
            f"        const data = await {entity_name_lower}Api.getAll();",
            f"        set{entity_name}s(data);",
            "      } catch (err) {",
            "        setError('Failed to load data');",
            "      } finally {",
            "        setLoading(false);",
            "      }",
            "    };",
            "",
            "    fetchData();",
            "  }, []);",
            "",
            "  if (loading) return <div>Loading...</div>;",
            "  if (error) return <div>Error: {error}</div>;",
            "",
            "  return (",
            "    <div>",
            f"      <h2>{entity_name} List</h2>",
            f"      {{{entity_name_lower}s.map((item) => (",
            "        <div key={item.id}>",
            "          {/* Display item fields here */}",
            "          <span>{item.name || item.title || 'Item'}</span>",
            "        </div>",
            "      ))}}",
            "    </div>",
            "  );",
            "};",
        ]

        return "\n".join(lines)

    def _generate_form_component(self, entity: Any) -> str:
        """Generate form component for an entity."""
        entity_name = self._to_pascal_case(entity.name)
        entity_name_lower = entity.name.lower()

        lines = [
            "import React, { useState } from 'react';",
            "import {",
            f"  {entity_name}FormData,",
            f"  {entity_name_lower}Api,",
            "} from '../api';",
            "",
            f"interface {entity_name}FormProps {{",
            "  onSuccess?: () => void;",
            f"  initialData?: Partial<{entity_name}FormData>;",
            "}",
            "",
            f"export const {entity_name}Form: React.FC<{entity_name}FormProps> = ({{",
            "  onSuccess,",
            "  initialData = {},",
            "}) => {",
            f"  const [formData, setFormData] = useState<{entity_name}FormData>(initialData as {entity_name}FormData);",
            "  const [loading, setLoading] = useState(false);",
            "  const [error, setError] = useState<string | null>(null);",
            "",
            "  const handleSubmit = async (e: React.FormEvent) => {",
            "    e.preventDefault();",
            "    setLoading(true);",
            "    setError(null);",
            "",
            "    try {",
            f"      await {entity_name_lower}Api.create(formData);",
            "      onSuccess?.();",
            "    } catch (err) {",
            "      setError('Failed to save');",
            "    } finally {",
            "      setLoading(false);",
            "    }",
            "  };",
            "",
            "  const handleChange = (field: keyof {entity_name}FormData, value: any) => {",
            "    setFormData(prev => ({ ...prev, [field]: value }));",
            "  };",
            "",
            "  return (",
            "    <form onSubmit={handleSubmit}>",
            "      {/* Form fields go here */}",
            "      {error && <div style={{color: 'red'}}>{error}</div>}",
            '      <button type="submit" disabled={loading}>',
            "        {loading ? 'Saving...' : 'Save'}",
            "      </button>",
            "    </form>",
            "  );",
            "};",
        ]

        return "\n".join(lines)

    def _generate_detail_component(self, entity: Any) -> str:
        """Generate detail component for an entity."""
        entity_name = self._to_pascal_case(entity.name)
        entity_name_lower = entity.name.lower()

        lines = [
            "import React, { useEffect, useState } from 'react';",
            "import {",
            f"  {entity_name},",
            f"  {entity_name_lower}Api,",
            "} from '../api';",
            "",
            f"interface {entity_name}DetailProps {{",
            "  id: string;",
            "}",
            "",
            f"export const {entity_name}Detail: React.FC<{entity_name}DetailProps> = ({{ id }}) => {{",
            f"  const [{entity_name_lower}, set{entity_name}] = useState<{entity_name} | null>(null);",
            "  const [loading, setLoading] = useState(true);",
            "  const [error, setError] = useState<string | null>(null);",
            "",
            "  useEffect(() => {",
            "    const fetchData = async () => {",
            "      try {",
            f"        const data = await {entity_name_lower}Api.getById(id);",
            f"        set{entity_name}(data);",
            "      } catch (err) {",
            "        setError('Failed to load data');",
            "      } finally {",
            "        setLoading(false);",
            "      }",
            "    };",
            "",
            "    fetchData();",
            "  }, [id]);",
            "",
            "  if (loading) return <div>Loading...</div>;",
            "  if (error) return <div>Error: {error}</div>;",
            f"  if (!{entity_name_lower}) return <div>Not found</div>;",
            "",
            "  return (",
            "    <div>",
            f"      <h2>{entity_name} Detail</h2>",
            "      {/* Display item details here */}",
            f"      <pre>{{JSON.stringify({entity_name_lower}, null, 2)}}</pre>",
            "    </div>",
            "  );",
            "};",
        ]

        return "\n".join(lines)

    def _generate_components_index(self, entities: Any) -> str:
        """Generate components index."""
        lines = []

        for entity in entities:
            entity_name = self._to_pascal_case(entity.name)
            lines.extend(
                [
                    f"export {{ {entity_name}List }} from './{entity_name}List';",
                    f"export {{ {entity_name}Form }} from './{entity_name}Form';",
                    f"export {{ {entity_name}Detail }} from './{entity_name}Detail';",
                ]
            )

        return "\n".join(lines)

    def _to_pascal_case(self, name: str) -> str:
        """Convert a name to PascalCase."""
        return "".join(word.capitalize() for word in name.split("_"))

    def _to_camel_case(self, name: str) -> str:
        """Convert a name to camelCase."""
        pascal = self._to_pascal_case(name)
        return pascal[0].lower() + pascal[1:] if pascal else ""
