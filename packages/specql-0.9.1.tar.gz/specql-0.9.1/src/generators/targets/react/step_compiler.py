"""React/TypeScript-specific action step compilation."""

from typing import TYPE_CHECKING

from src.generators.targets.base.interfaces import StepCompilationResult
from src.generators.targets.base.step_compiler import BaseStepCompiler
from src.generators.targets.react.expression_compiler import ReactExpressionCompiler

if TYPE_CHECKING:
    from src.core.ir.action_ir import ActionStepIR


class ReactStepCompiler(BaseStepCompiler):
    """Compiles SpecQL action steps to React/TypeScript code.

    Handles the translation of SpecQL action steps (validate, update, insert, etc.)
    into React/TypeScript code that can be used in components, hooks, or API clients.
    """

    def __init__(self):
        """Initialize the React step compiler with an expression compiler."""
        super().__init__(ReactExpressionCompiler())

    def _compile_validate(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a validate step to React validation logic.

        Validate steps check conditions and set error states or throw errors.
        """
        if not step.expression:
            raise ValueError("Validate step must have an expression")

        condition = self.compile_condition(step.expression, ctx)
        error_message = "Validation failed"  # Default error message

        code = f"""
        if (!{condition}) {{
          setError('{error_message}');
          return;
        }}
        """.strip()

        return StepCompilationResult(code=code)

    def _compile_update(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile an update step to React API call."""
        if not step.fields:
            raise ValueError("Update step must have fields to update")

        entity_name = self._get_entity_name(step, ctx)
        update_data = self._compile_update_data(step.fields, ctx)
        api_endpoint = f"/api/{entity_name.lower()}s"

        code = f"""
        try {{
          const response = await fetch(`{api_endpoint}/$id`, {{
            method: 'PUT',
            headers: {{
              'Content-Type': 'application/json',
            }},
            body: JSON.stringify({update_data}),
          }});

          if (!response.ok) {{
            throw new Error('Update failed');
          }}

          const updatedData = await response.json();
          // Update local state or trigger refetch
        }} catch (error) {{
          console.error('Update error:', error);
          setError('Failed to update {entity_name}');
        }}
        """.strip()

        return StepCompilationResult(code=code)

    def _compile_insert(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile an insert step to React API POST call."""
        if not step.fields:
            raise ValueError("Insert step must have fields to insert")

        entity_name = self._get_entity_name(step, ctx)
        create_data = self._compile_create_data(step.fields, ctx)
        api_endpoint = f"/api/{entity_name.lower()}s"

        code = f"""
        try {{
          const response = await fetch('{api_endpoint}', {{
            method: 'POST',
            headers: {{
              'Content-Type': 'application/json',
            }},
            body: JSON.stringify({create_data}),
          }});

          if (!response.ok) {{
            throw new Error('Create failed');
          }}

          const newData = await response.json();
          // Update local state or navigate to new item
        }} catch (error) {{
          console.error('Create error:', error);
          setError('Failed to create {entity_name}');
        }}
        """.strip()

        return StepCompilationResult(code=code)

    def _compile_if(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile an if step to TypeScript conditional logic."""
        if not step.condition:
            raise ValueError("If step must have a condition")

        condition = self.compile_condition(step.condition, ctx)

        # Compile the then branch using base class helper
        then_result = self._compile_nested_steps(step.then_steps or [], ctx)

        # Compile the else branch
        else_result = None
        if step.else_steps:
            else_result = self._compile_nested_steps(step.else_steps, ctx)

        code = f"if ({condition}) {{\n{then_result.code}\n}}"
        if else_result:
            code += f" else {{\n{else_result.code}\n}}"

        # Merge imports and variables from both branches
        imports = then_result.imports
        variables = then_result.variables.copy()
        if else_result:
            imports = imports | else_result.imports
            variables.update(else_result.variables)

        return StepCompilationResult(code=code, imports=imports, variables=variables)

    def _compile_call(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a call step to TypeScript function call."""
        if not step.function_name:
            raise ValueError("Call step must have a function name")

        function_name = step.function_name
        args = self._compile_function_args(step.function_args, ctx)

        code = f"{function_name}({args});"
        return StepCompilationResult(code=code)

    def _compile_notify(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a notify step to React toast notification."""
        # For React, we'll assume a toast library like react-hot-toast
        # Since ActionStepIR doesn't have message/notification_type, use defaults
        message = "Notification"
        notification_type = "info"

        if notification_type == "success":
            code = f"toast.success('{message}');"
        elif notification_type == "error":
            code = f"toast.error('{message}');"
        elif notification_type == "warning":
            code = f"toast('{message}', {{ type: 'warning' }});"
        else:
            code = f"toast('{message}');"

        return StepCompilationResult(code=code, imports={"toast"})

    def _compile_foreach(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a foreach step to TypeScript array iteration."""
        if not step.collection or not step.item_name:
            raise ValueError("Foreach step must have collection and item_name")

        collection_expr = self.expression_compiler.compile_expression(step.collection, ctx)
        item_var = step.item_name

        # Compile the loop body using base class helper
        loop_ctx = ctx.copy()
        loop_ctx[step.item_name] = item_var
        loop_result = self._compile_nested_steps(step.loop_steps or [], loop_ctx)

        code = f"{collection_expr}.forEach(({item_var}) => {{\n{loop_result.code}\n}});"

        return StepCompilationResult(
            code=code, imports=loop_result.imports, variables=loop_result.variables
        )

    def _get_entity_name(self, step: "ActionStepIR", ctx: dict) -> str:
        """Get the entity name for a step."""
        entity_name = step.target_entity or ctx.get("entity_name")
        if not entity_name:
            raise ValueError(
                "Cannot determine entity name: no target_entity or entity_name in context"
            )

        return self._to_pascal_case(entity_name)

    def _compile_update_data(self, fields: dict, ctx: dict) -> str:
        """Compile the update data object for React API call."""
        assignments = []
        for field_name, field_value in fields.items():
            if isinstance(field_value, str):
                # Assume it's an expression
                compiled_value = self.expression_compiler.compile_expression(field_value, ctx)
            else:
                # Assume it's a literal value
                compiled_value = self._format_literal_value(field_value)

            assignments.append(f"{field_name}: {compiled_value}")

        return f"{{{', '.join(assignments)}}}"

    def _compile_create_data(self, fields: dict, ctx: dict) -> str:
        """Compile the create data object for React API call."""
        assignments = []
        for field_name, field_value in fields.items():
            if isinstance(field_value, str):
                # Assume it's an expression
                compiled_value = self.expression_compiler.compile_expression(field_value, ctx)
            else:
                # Assume it's a literal value
                compiled_value = self._format_literal_value(field_value)

            assignments.append(f"{field_name}: {compiled_value}")

        return f"{{{', '.join(assignments)}}}"

    def _compile_function_args(self, args: list, ctx: dict) -> str:
        """Compile function arguments."""
        compiled_args = []
        for arg in args:
            if isinstance(arg, str):
                compiled_args.append(self.expression_compiler.compile_expression(arg, ctx))
            else:
                compiled_args.append(self._format_literal_value(arg))

        return ", ".join(compiled_args)

    def _format_literal_value(self, value) -> str:
        """Format a literal value for TypeScript."""
        if isinstance(value, str):
            # Escape single quotes in the string
            escaped_value = value.replace("'", "\\'")
            return f"'{escaped_value}'"
        elif isinstance(value, bool):
            return "true" if value else "false"
        elif value is None:
            return "null"
        else:
            return str(value)

    def _to_pascal_case(self, name: str) -> str:
        """Convert a name to PascalCase."""
        return "".join(word.capitalize() for word in name.split("_"))
