"""React form generator."""

from typing import TYPE_CHECKING, Any

from src.generators.targets.base.target import GeneratedFile

if TYPE_CHECKING:
    pass


class ReactFormGenerator:
    """Generates advanced React form components with validation."""

    def generate_forms(self, entities: Any) -> list[GeneratedFile]:
        """Generate advanced form components with validation."""
        files = []

        for entity in entities:
            # Generate advanced form component with validation
            form_content = self._generate_advanced_form_component(entity)
            entity_name = self._to_pascal_case(entity.name)

            files.append(
                GeneratedFile(
                    path=f"src/components/{entity_name}AdvancedForm.tsx",
                    content=form_content,
                    language="tsx",
                    metadata={
                        "type": "component",
                        "variant": "advanced-form",
                        "entity": entity.name,
                    },
                )
            )

        return files

    def _generate_advanced_form_component(self, entity: Any) -> str:
        """Generate advanced form component with validation."""
        entity_name = self._to_pascal_case(entity.name)
        entity_name_lower = entity.name.lower()

        lines = [
            "import React, { useState, useEffect } from 'react';",
            "import {",
            f"  {entity_name}FormData,",
            f"  {entity_name}UpdateData,",
            f"  {entity_name_lower}Api,",
            "} from '../api';",
            "import { validateForm, validateRequired, validateEmail } from '../utils/validation';",
            "",
            f"interface {entity_name}AdvancedFormProps {{",
            "  onSuccess?: () => void;",
            "  onCancel?: () => void;",
            f"  initialData?: Partial<{entity_name}FormData>;",
            "  isEdit?: boolean;",
            "  editId?: string;",
            "}",
            "",
            f"export const {entity_name}AdvancedForm: React.FC<{entity_name}AdvancedFormProps> = ({{",
            "  onSuccess,",
            "  onCancel,",
            "  initialData = {},",
            "  isEdit = false,",
            "  editId,",
            "}) => {",
            f"  const [formData, setFormData] = useState<{entity_name}FormData>(initialData as {entity_name}FormData);",
            "  const [loading, setLoading] = useState(false);",
            "  const [errors, setErrors] = useState<Record<string, string>>({});",
            "  const [touched, setTouched] = useState<Record<string, boolean>>({});",
            "",
            "  useEffect(() => {",
            "    if (isEdit && editId) {",
            "      loadExistingData();",
            "    }",
            "  }, [isEdit, editId]);",
            "",
            "  const loadExistingData = async () => {",
            "    if (!editId) return;",
            "    try {",
            f"      const data = await {entity_name_lower}Api.getById(editId);",
            "      setFormData(data);",
            "    } catch (err) {",
            "      console.error('Failed to load data for editing:', err);",
            "    }",
            "  };",
            "",
            "  const handleSubmit = async (e: React.FormEvent) => {",
            "    e.preventDefault();",
            "    setLoading(true);",
            "",
            "    // Validate all fields",
            "    const validationErrors = validateForm(formData, {",
            "      // Add field validations here based on entity fields",
            "    });",
            "",
            "    if (Object.keys(validationErrors).length > 0) {",
            "      setErrors(validationErrors);",
            "      setLoading(false);",
            "      return;",
            "    }",
            "",
            "    try {",
            "      if (isEdit && editId) {",
            f"        await {entity_name_lower}Api.update(editId, formData);",
            "      } else {",
            f"        await {entity_name_lower}Api.create(formData);",
            "      }",
            "      onSuccess?.();",
            "    } catch (err) {",
            "      setErrors({ submit: 'Failed to save' });",
            "    } finally {",
            "      setLoading(false);",
            "    }",
            "  };",
            "",
            "  const handleChange = (field: keyof {entity_name}FormData, value: any) => {",
            "    setFormData(prev => ({ ...prev, [field]: value }));",
            "    // Clear error when user starts typing",
            "    if (errors[field]) {",
            "      setErrors(prev => ({ ...prev, [field]: '' }));",
            "    }",
            "  };",
            "",
            "  const handleBlur = (field: keyof {entity_name}FormData) => {",
            "    setTouched(prev => ({ ...prev, [field]: true }));",
            "  };",
            "",
            "  const getFieldError = (field: keyof {entity_name}FormData): string => {",
            "    return touched[field] ? errors[field] || '' : '';",
            "  };",
            "",
            "  return (",
            '    <div className="form-container">',
            f"      <h3>{{isEdit ? 'Edit' : 'Create'}} {entity_name}</h3>",
            '      <form onSubmit={handleSubmit} className="entity-form">',
            "        {/* Form fields will be generated here based on entity fields */}",
            "        {errors.submit && (",
            "          <div className=\"error-message\" style={{color: 'red', marginBottom: '1rem'}}>",
            "            {errors.submit}",
            "          </div>",
            "        )}",
            '        <div className="form-actions">',
            '          <button type="submit" disabled={loading} className="btn btn-primary">',
            "            {loading ? 'Saving...' : (isEdit ? 'Update' : 'Create')}",
            "          </button>",
            "          {onCancel && (",
            '            <button type="button" onClick={onCancel} className="btn btn-secondary">',
            "              Cancel",
            "            </button>",
            "          )}",
            "        </div>",
            "      </form>",
            "    </div>",
            "  );",
            "};",
        ]

        return "\n".join(lines)

    def _to_pascal_case(self, name: str) -> str:
        """Convert a name to PascalCase."""
        return "".join(word.capitalize() for word in name.split("_"))

    def _to_camel_case(self, name: str) -> str:
        """Convert a name to camelCase."""
        pascal = self._to_pascal_case(name)
        return pascal[0].lower() + pascal[1:] if pascal else ""
