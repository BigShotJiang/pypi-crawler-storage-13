"""React API client generator."""

from typing import TYPE_CHECKING, Any

from src.generators.targets.base.target import GeneratedFile

if TYPE_CHECKING:
    pass


class ReactApiGenerator:
    """Generates API client functions for React entities."""

    def generate_api_clients(self, entities: Any) -> list[GeneratedFile]:
        """Generate API client files."""
        files = []

        # Generate API client for each entity
        for entity in entities:
            api_content = self._generate_api_content(entity)
            entity_name = self._to_camel_case(entity.name)

            files.append(
                GeneratedFile(
                    path=f"src/api/{entity_name}.ts",
                    content=api_content,
                    language="typescript",
                    metadata={"type": "api", "entity": entity.name},
                )
            )

        # Generate main API client index
        api_index_content = self._generate_api_index(entities)
        files.append(
            GeneratedFile(
                path="src/api/index.ts",
                content=api_index_content,
                language="typescript",
                metadata={"type": "index", "category": "api"},
            )
        )

        return files

    def _generate_api_content(self, entity: Any) -> str:
        """Generate API client content for an entity."""
        entity_name = self._to_pascal_case(entity.name)
        entity_name_lower = entity.name.lower()

        lines = [
            "import {",
            f"  {entity_name},",
            f"  {entity_name}FormData,",
            f"  {entity_name}UpdateData,",
            "} from '../types';",
            "",
            "const API_BASE = '/api';",
            "",
            f"export const {entity_name_lower}Api = {{",
            f"  async getAll(): Promise<{entity_name}[]> {{",
            f"    const response = await fetch(`${{API_BASE}}/{entity_name_lower}s`);",
            "    if (!response.ok) throw new Error('Failed to fetch data');",
            "    return response.json();",
            "  },",
            "",
            f"  async getById(id: string): Promise<{entity_name}> {{",
            f"    const response = await fetch(`${{API_BASE}}/{entity_name_lower}s/${{id}}`);",
            "    if (!response.ok) throw new Error('Failed to fetch item');",
            "    return response.json();",
            "  },",
            "",
            f"  async create(data: {entity_name}FormData): Promise<{entity_name}> {{",
            f"    const response = await fetch(`${{API_BASE}}/{entity_name_lower}s`, {{",
            "      method: 'POST',",
            "      headers: { 'Content-Type': 'application/json' },",
            "      body: JSON.stringify(data),",
            "    }});",
            "    if (!response.ok) throw new Error('Failed to create item');",
            "    return response.json();",
            "  },",
            "",
            f"  async update(id: string, data: {entity_name}UpdateData): Promise<{entity_name}> {{",
            f"    const response = await fetch(`${{API_BASE}}/{entity_name_lower}s/${{id}}`, {{",
            "      method: 'PUT',",
            "      headers: { 'Content-Type': 'application/json' },",
            "      body: JSON.stringify(data),",
            "    }});",
            "    if (!response.ok) throw new Error('Failed to update item');",
            "    return response.json();",
            "  },",
            "",
            "  async delete(id: string): Promise<void> {",
            f"    const response = await fetch(`${{API_BASE}}/{entity_name_lower}s/${{id}}`, {{",
            "      method: 'DELETE',",
            "    }});",
            "    if (!response.ok) throw new Error('Failed to delete item');",
            "  }},",
            "};",
        ]

        return "\n".join(lines)

    def _generate_api_index(self, entities: Any) -> str:
        """Generate API client index."""
        lines = []

        for entity in entities:
            entity_name = self._to_camel_case(entity.name)
            lines.append(f"export * from './{entity_name}';")

        return "\n".join(lines)

    def _to_pascal_case(self, name: str) -> str:
        """Convert a name to PascalCase."""
        return "".join(word.capitalize() for word in name.split("_"))

    def _to_camel_case(self, name: str) -> str:
        """Convert a name to camelCase."""
        pascal = self._to_pascal_case(name)
        return pascal[0].lower() + pascal[1:] if pascal else ""
