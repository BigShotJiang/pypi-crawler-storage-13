"""React target for SpecQL code generation."""

from .target import ReactTarget

__all__ = ["ReactTarget"]
