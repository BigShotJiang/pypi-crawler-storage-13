"""React/TypeScript-specific type mapping for SpecQL types."""


from src.core.ir.type_ir import TypeCategory, TypeIR
from src.generators.targets.base.type_mapper import BaseTypeMapper, TypeInfo


class ReactTypeMapper(BaseTypeMapper):
    """Maps SpecQL types to React/TypeScript types.

    Provides TypeScript-specific type mappings for React frontend development,
    including interfaces, union types, and proper TypeScript declarations.
    """

    def map_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map a SpecQL type to React/TypeScript type information.

        Args:
            type_ir: The SpecQL type to map

        Returns:
            TypeInfo with TypeScript-specific details
        """
        if type_ir.category == TypeCategory.SCALAR:
            return self._map_scalar_type(type_ir)
        elif type_ir.category == TypeCategory.REFERENCE:
            return self._map_reference_type(type_ir)
        elif type_ir.category == TypeCategory.ENUM:
            return self._map_enum_type(type_ir)
        elif type_ir.category == TypeCategory.LIST:
            return self._map_list_type(type_ir)
        elif type_ir.category == TypeCategory.COMPOSITE:
            return self._map_composite_type(type_ir)
        else:
            raise ValueError(f"Unsupported type category: {type_ir.category}")

    def _map_scalar_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map scalar types to TypeScript."""
        return self._get_base_type_mapping(type_ir.base_type)

    def _map_reference_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map reference types to TypeScript interface references."""
        # For references, we use the entity name as the TypeScript interface name
        entity_name = type_ir.referenced_entity or "unknown"
        interface_name = self._to_pascal_case(entity_name)

        return TypeInfo(
            target_type=interface_name,
            ddl_type="string",  # Foreign key is typically a string/uuid
            imports=[interface_name],
            constraints=[],
        )

    def _map_enum_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map enum types to TypeScript union types."""
        if type_ir.enum_values:
            # Create union type from enum values
            union_values = " | ".join(f'"{value}"' for value in type_ir.enum_values)
            return TypeInfo(
                target_type=f"({union_values})",
                ddl_type="string",
                imports=[],
                constraints=[],
            )
        else:
            return TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=[],
                constraints=[],
            )

    def _map_list_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map list types to TypeScript arrays."""
        if type_ir.element_type:
            element_info = self.map_type(type_ir.element_type)
            return TypeInfo(
                target_type=f"{element_info.target_type}[]",
                ddl_type="array",
                imports=element_info.imports,
                constraints=[],
            )
        else:
            # Default to any array
            return TypeInfo(
                target_type="any[]",
                ddl_type="array",
                imports=[],
                constraints=[],
            )

    def _map_composite_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map composite types to TypeScript interfaces."""
        # For composite types, we generate inline interface definitions
        # The actual interface generation happens at the entity level
        return TypeInfo(
            target_type="Record<string, any>",
            ddl_type="object",
            imports=[],
            constraints=[],
        )

    def get_reference_type(self, referenced_entity: str) -> str:
        """Get the TypeScript type for foreign key references.

        Args:
            referenced_entity: Name of the referenced entity

        Returns:
            TypeScript interface name for the referenced entity
        """
        return self._to_pascal_case(referenced_entity)

    def get_enum_type(self, enum_values: list[str]) -> str:
        """Get the TypeScript type for enum fields.

        Args:
            enum_values: List of allowed enum values

        Returns:
            TypeScript union type string
        """
        if enum_values:
            union_values = " | ".join(f'"{value}"' for value in enum_values)
            return f"({union_values})"
        return "string"

    def _get_base_type_mapping(self, base_type: str) -> TypeInfo:
        """Get the base TypeScript type mapping for a SpecQL type.

        Args:
            base_type: The SpecQL base type

        Returns:
            TypeInfo for the base type
        """
        mappings = {
            # Scalar types
            "string": TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=[],
                constraints=[],
            ),
            "text": TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=[],
                constraints=[],
            ),
            "integer": TypeInfo(
                target_type="number",
                ddl_type="number",
                imports=[],
                constraints=[],
            ),
            "bigint": TypeInfo(
                target_type="number",
                ddl_type="number",
                imports=[],
                constraints=[],
            ),
            "smallint": TypeInfo(
                target_type="number",
                ddl_type="number",
                imports=[],
                constraints=[],
            ),
            "decimal": TypeInfo(
                target_type="number",
                ddl_type="number",
                imports=[],
                constraints=[],
            ),
            "float": TypeInfo(
                target_type="number",
                ddl_type="number",
                imports=[],
                constraints=[],
            ),
            "double": TypeInfo(
                target_type="number",
                ddl_type="number",
                imports=[],
                constraints=[],
            ),
            "boolean": TypeInfo(
                target_type="boolean",
                ddl_type="boolean",
                imports=[],
                constraints=[],
            ),
            "date": TypeInfo(
                target_type="Date",
                ddl_type="string",
                imports=[],
                constraints=[],
            ),
            "datetime": TypeInfo(
                target_type="Date",
                ddl_type="string",
                imports=[],
                constraints=[],
            ),
            "timestamp": TypeInfo(
                target_type="Date",
                ddl_type="string",
                imports=[],
                constraints=[],
            ),
            "time": TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=[],
                constraints=[],
            ),
            "uuid": TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=[],
                constraints=[],
            ),
            "json": TypeInfo(
                target_type="any",
                ddl_type="object",
                imports=[],
                constraints=[],
            ),
            "jsonb": TypeInfo(
                target_type="any",
                ddl_type="object",
                imports=[],
                constraints=[],
            ),
            # Email type (string with email validation)
            "email": TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=[],
                constraints=[],
            ),
            # URL type (string with URL validation)
            "url": TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=[],
                constraints=[],
            ),
            # Phone type (string)
            "phone": TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=[],
                constraints=[],
            ),
            # Currency type (number)
            "currency": TypeInfo(
                target_type="number",
                ddl_type="number",
                imports=[],
                constraints=[],
            ),
            # Percentage type (number)
            "percentage": TypeInfo(
                target_type="number",
                ddl_type="number",
                imports=[],
                constraints=[],
            ),
        }

        if base_type not in mappings:
            raise ValueError(f"Unsupported type: {base_type}")

        return mappings[base_type]

    def _to_pascal_case(self, snake_case: str) -> str:
        """Convert snake_case to PascalCase.

        Args:
            snake_case: String in snake_case format

        Returns:
            String in PascalCase format
        """
        return "".join(word.capitalize() for word in snake_case.split("_"))

    def _add_not_null_constraint(self, type_info: TypeInfo) -> TypeInfo:
        """Add non-null constraint to TypeScript type.

        Args:
            type_info: Current type information

        Returns:
            Updated TypeInfo (TypeScript handles nullability with union types)
        """
        # In TypeScript, non-null is the default. We could add | null for nullable
        # but for now, we'll keep it simple
        return type_info

    def _add_default_value(self, type_info: TypeInfo, type_ir: TypeIR) -> TypeInfo:
        """Add default value information to TypeScript type.

        Args:
            type_info: Current type information
            type_ir: The type IR with default value

        Returns:
            Updated TypeInfo with default value information
        """
        # Default values are typically handled in component state, not in types
        # We could store this information for code generation
        return type_info

    def _add_constraints(self, type_info: TypeInfo, type_ir: TypeIR) -> TypeInfo:
        """Add constraints to TypeScript type.

        Args:
            type_info: Current type information
            type_ir: The type IR with constraints

        Returns:
            Updated TypeInfo with constraints
        """
        # TypeScript types don't have runtime constraints like databases
        # Constraints are typically handled in validation logic
        return type_info
