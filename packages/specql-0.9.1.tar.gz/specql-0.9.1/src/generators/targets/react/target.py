"""React target for SpecQL code generation."""

from typing import TYPE_CHECKING, Any

from src.generators.targets.base.registry import register_target
from src.generators.targets.base.target import BaseTarget, GeneratedFile, GenerationResult
from src.generators.targets.react.api_generator import ReactApiGenerator
from src.generators.targets.react.component_generator import ReactComponentGenerator
from src.generators.targets.react.form_generator import ReactFormGenerator
from src.generators.targets.react.step_compiler import ReactStepCompiler
from src.generators.targets.react.type_generator import ReactTypeGenerator
from src.generators.targets.react.type_mapper import ReactTypeMapper

if TYPE_CHECKING:
    pass


@register_target("react")
class ReactTarget(BaseTarget):
    """React/TypeScript code generation target.

    Generates React frontend code including:
    - TypeScript interfaces for entities and API responses
    - React components (forms, lists, detail views)
    - API client functions for CRUD operations
    - Custom hooks for data fetching and state management
    - Form validation and error handling
    """

    @property
    def name(self) -> str:
        """The name of this target."""
        return "react"

    @property
    def supported_languages(self) -> list[str]:
        """List of programming languages this target generates."""
        return ["typescript", "tsx"]

    def __init__(self):
        """Initialize the React target with its components."""
        self.type_mapper = ReactTypeMapper()
        self.step_compiler = ReactStepCompiler()
        self.type_generator = ReactTypeGenerator()
        self.api_generator = ReactApiGenerator()
        self.component_generator = ReactComponentGenerator()
        self.form_generator = ReactFormGenerator()

    def generate(self, entity_ir: Any) -> GenerationResult:
        """Generate React code for the given entity IR.

        Args:
            entity_ir: EntityIR definition to generate React code for

        Returns:
            GenerationResult containing all generated files
        """
        files = []
        errors = []
        warnings = []

        try:
            # Generate TypeScript interfaces
            interface_files = self.type_generator.generate_interfaces([entity_ir])
            files.extend(interface_files)

            # Generate API client
            api_files = self.api_generator.generate_api_clients([entity_ir])
            files.extend(api_files)

            # Generate React components
            component_files = self.component_generator.generate_components([entity_ir])
            files.extend(component_files)

            # Generate advanced forms
            form_files = self.form_generator.generate_forms([entity_ir])
            files.extend(form_files)

            # Generate utility functions
            util_files = self._generate_utils()
            files.extend(util_files)

        except Exception as e:
            errors.append(f"Generation failed: {str(e)}")
            return GenerationResult(
                success=False, files=files, target_name=self.name, errors=errors, warnings=warnings
            )

        return GenerationResult(
            success=True, files=files, target_name=self.name, errors=errors, warnings=warnings
        )

    def _generate_utils(self) -> list[GeneratedFile]:
        """Generate utility files."""
        files = []

        # Generate form validation utilities
        validation_content = self._generate_validation_utils()
        files.append(
            GeneratedFile(
                path="src/utils/validation.ts",
                content=validation_content,
                language="typescript",
                metadata={"type": "utility", "category": "validation"},
            )
        )

        # Generate API utilities
        api_utils_content = self._generate_api_utils()
        files.append(
            GeneratedFile(
                path="src/utils/api.ts",
                content=api_utils_content,
                language="typescript",
                metadata={"type": "utility", "category": "api"},
            )
        )

        return files

    def _generate_validation_utils(self) -> str:
        """Generate validation utility functions."""
        return r"""export const validateRequired = (value: any): string | null => {
  if (!value || (typeof value === 'string' && value.trim() === '')) {
    return 'This field is required';
  }
  return null;
};

export const validateEmail = (email: string): string | null => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return 'Please enter a valid email address';
  }
  return null;
};

export const validateMinLength = (value: string, minLength: number): string | null => {
  if (value.length < minLength) {
    return `Must be at least ${minLength} characters`;
  }
  return null;
};

export const validateForm = <T extends Record<string, any>>(
  data: T,
  rules: Partial<Record<keyof T, ((value: any) => string | null)[]>>
): Record<keyof T, string | null> => {
  const errors: Record<string, string | null> = {};

  for (const field in rules) {
    const fieldRules = rules[field];
    if (fieldRules) {
      for (const rule of fieldRules) {
        const error = rule(data[field]);
        if (error) {
          errors[field] = error;
          break;
        }
      }
    }
  }

  return errors;
};
"""

    def _generate_api_utils(self) -> str:
        """Generate API utility functions."""
        return """export const handleApiError = (error: any): string => {
  if (error instanceof Error) {
    return error.message;
  }
  return 'An unexpected error occurred';
};

export const createApiUrl = (endpoint: string): string => {
  const baseUrl = process.env.REACT_APP_API_URL || '/api';
  return `${baseUrl}${endpoint}`;
};

export const apiRequest = async <T>(
  url: string,
  options?: RequestInit
): Promise<T> => {
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  });

  if (!response.ok) {
    throw new Error(`API request failed: ${response.statusText}`);
  }

  return response.json();
};
"""
