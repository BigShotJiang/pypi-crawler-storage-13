"""React/TypeScript-specific expression compilation."""

from typing import Any

from src.generators.targets.base.step_compiler import BaseExpressionCompiler


class ReactExpressionCompiler(BaseExpressionCompiler):
    """Compiles SpecQL expressions to React/TypeScript expressions.

    Handles the translation of SpecQL expressions into TypeScript/JavaScript-compatible
    expressions that can be used in React components, API calls, validation, etc.
    """

    # React/TypeScript operator mappings
    OPERATORS = {
        "=": "===",
        "!=": "!==",
        "AND": "&&",
        "OR": "||",
        "NOT": "!",
        "<=": "<=",
        ">=": ">=",
        "<": "<",
        ">": ">",
        "+": "+",
        "-": "-",
        "*": "*",
        "/": "/",
        "%": "%",
        ".": "+",  # String concatenation
    }

    NULL_LITERAL = "null"
    TRUE_LITERAL = "true"
    FALSE_LITERAL = "false"
    STRING_QUOTE = "'"

    def _translate_identifier(self, identifier: str) -> str:
        """Translate identifiers to JavaScript variable syntax."""
        return identifier

    def _translate_field_reference(self, field_ref: str) -> str:
        """Translate field references to JavaScript dot notation (entity.field)."""
        return field_ref.replace(".", ".")

    def compile_expression(self, expression: str, context: dict[str, Any]) -> str:
        """Compile a SpecQL expression to React/TypeScript.

        Args:
            expression: The SpecQL expression string
            context: Compilation context (variables, entity info, etc.)

        Returns:
            TypeScript/JavaScript expression string
        """
        # Use the new template method
        result = self.compile(expression, context)

        # Apply additional React/TypeScript-specific transformations
        code = result.code
        code = self._replace_functions(code)
        code = self._replace_variables(code, context)

        return code

    def _replace_operators(self, expression: str) -> str:
        """Replace SpecQL operators with JavaScript operators (for backwards compatibility)."""
        import re

        # Replace compound operators first
        replacements = [
            ("AND", "&&"),
            ("OR", "||"),
            ("NOT", "!"),
            ("!=", "!=="),
            ("<=", "<="),
            (">=", ">="),
            ("<", "<"),
            (">", ">"),
        ]

        for specql_op, js_op in replacements:
            expression = expression.replace(specql_op, js_op)

        # Replace standalone = with === (not part of compound operators)
        # This regex matches = that is not preceded by <, >, or !
        expression = re.sub(r"(?<![<>=!])=(?![<>=!])", "===", expression)

        return expression

    def _replace_functions(self, expression: str) -> str:
        """Replace SpecQL functions with TypeScript/JavaScript functions."""
        replacements = {
            "NOW()": "new Date()",
            "TODAY()": "new Date().toISOString().split('T')[0]",
            "LEN(": "String(",  # Convert to string first, then get length
            "CONTAINS(": "String(",  # Will need custom contains logic
            "UPPER(": "String(",  # Will need toUpperCase()
            "LOWER(": "String(",  # Will need toLowerCase()
        }

        for specql_func, js_func in replacements.items():
            expression = expression.replace(specql_func, js_func)

        # Handle special cases that need more complex replacement
        expression = self._handle_special_functions(expression)

        return expression

    def _handle_special_functions(self, expression: str) -> str:
        """Handle special function replacements that need more complex logic."""
        # Handle LEN function - need to add .length
        if "LEN(" in expression:
            expression = expression.replace("LEN(String(", "String(")
            expression = expression.replace("))", ").length)")

        # Handle CONTAINS function - use includes() method
        if "CONTAINS(" in expression:
            # This is a simplified replacement - real implementation would parse properly
            expression = expression.replace("CONTAINS(String(", "String(")
            # Would need proper parsing to handle: CONTAINS(field, 'value') -> field.includes('value')

        # Handle UPPER/LOWER functions
        if "UPPER(" in expression:
            expression = expression.replace("UPPER(String(", "String(")
            expression = expression.replace("))", ").toUpperCase())")

        if "LOWER(" in expression:
            expression = expression.replace("LOWER(String(", "String(")
            expression = expression.replace("))", ").toLowerCase())")

        return expression

    def _replace_variables(self, expression: str, context: dict[str, Any]) -> str:
        """Replace variables in the expression using context."""
        # Simple variable replacement - in a real implementation,
        # this would be more sophisticated
        for var_name, var_value in context.items():
            if isinstance(var_value, str):
                expression = expression.replace(f"${var_name}", f"'{var_value}'")
            else:
                expression = expression.replace(f"${var_name}", str(var_value))

        return expression

    def supports_operator(self, operator: str) -> bool:
        """Check if TypeScript/JavaScript supports a specific operator."""
        # JavaScript supports all the base operators plus some extras
        js_operators = {
            "&&",
            "||",
            "!",  # Logical
            "===",
            "!==",
            "==",
            "!=",
            "<",
            ">",
            "<=",
            ">=",  # Comparison
            "+",
            "-",
            "*",
            "/",
            "%",
            "**",  # Arithmetic
            "+=",  # String concatenation and assignment
            "instanceof",  # Type checking
            "in",  # Property checking
            "&",
            "|",
            "^",
            "~",
            "<<",
            ">>",
            ">>>",  # Bitwise
            "?",  # Ternary
        }

        return operator in js_operators

    def get_operator_mapping(self, operator: str) -> str:
        """Get TypeScript/JavaScript-specific operator mapping."""
        return self.OPERATORS.get(operator.upper(), operator)
