"""React TypeScript interface generator."""

from typing import TYPE_CHECKING, Any

from src.generators.targets.base.target import GeneratedFile

if TYPE_CHECKING:
    pass


class ReactTypeGenerator:
    """Generates TypeScript interfaces for React entities."""

    def generate_interfaces(self, entities: Any) -> list[GeneratedFile]:
        """Generate TypeScript interface files."""
        files = []

        # Generate individual interface files
        for entity in entities:
            interface_content = self._generate_interface_content(entity)
            interface_name = self._to_pascal_case(entity.name)

            files.append(
                GeneratedFile(
                    path=f"src/types/{interface_name}.ts",
                    content=interface_content,
                    language="typescript",
                    metadata={"type": "interface", "entity": entity.name},
                )
            )

        # Generate index file for all interfaces
        index_content = self._generate_interfaces_index(entities)
        files.append(
            GeneratedFile(
                path="src/types/index.ts",
                content=index_content,
                language="typescript",
                metadata={"type": "index", "category": "types"},
            )
        )

        return files

    def _generate_interface_content(self, entity: Any) -> str:
        """Generate TypeScript interface content for an entity."""
        interface_name = self._to_pascal_case(entity.name)

        lines = [
            f"export interface {interface_name} {{",
        ]

        # Add fields
        if hasattr(entity, "fields"):
            for field in entity.fields:
                # For now, use basic type mapping - will be enhanced with type_mapper later
                field_type = self._map_field_type(
                    field.type_ir if hasattr(field, "type_ir") else field.get("type", "string")
                )
                field_name = field.name
                # Convert field name to camelCase for TypeScript
                ts_field_name = self._to_camel_case(field_name)
                lines.append(f"  {ts_field_name}: {field_type};")

        lines.append("}")
        lines.append("")

        # Add form data interface
        lines.extend(
            [
                f"export interface {interface_name}FormData extends Omit<{interface_name}, 'id'> {{",
                "}",
                "",
                f"export interface {interface_name}UpdateData extends Partial<{interface_name}FormData> {{",
                "}",
            ]
        )

        return "\n".join(lines)

    def _generate_interfaces_index(self, entities: Any) -> str:
        """Generate index file for all interfaces."""
        lines = []

        for entity in entities:
            interface_name = self._to_pascal_case(entity.name)
            lines.append(f"export * from './{interface_name}';")

        return "\n".join(lines)

    def _map_field_type(self, field_type: Any) -> str:
        """Map SpecQL field type to TypeScript type."""
        # Basic type mapping - will be enhanced with proper type_mapper integration
        type_mapping = {
            "string": "string",
            "text": "string",
            "integer": "number",
            "int": "number",
            "float": "number",
            "decimal": "number",
            "boolean": "boolean",
            "bool": "boolean",
            "date": "string",
            "datetime": "string",
            "timestamp": "string",
            "uuid": "string",
            "json": "any",
            "array": "any[]",
        }

        if hasattr(field_type, "name"):
            return type_mapping.get(field_type.name, "any")
        elif isinstance(field_type, str):
            return type_mapping.get(field_type, "any")
        else:
            return "any"

    def _to_pascal_case(self, name: str) -> str:
        """Convert a name to PascalCase."""
        return "".join(word.capitalize() for word in name.split("_"))

    def _to_camel_case(self, name: str) -> str:
        """Convert a name to camelCase."""
        pascal = self._to_pascal_case(name)
        return pascal[0].lower() + pascal[1:] if pascal else ""
