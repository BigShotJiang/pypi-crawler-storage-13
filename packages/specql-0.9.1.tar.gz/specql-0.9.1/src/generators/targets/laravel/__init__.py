"""Laravel target for SpecQL code generation."""

from .target import LaravelTarget

__all__ = ["LaravelTarget"]
