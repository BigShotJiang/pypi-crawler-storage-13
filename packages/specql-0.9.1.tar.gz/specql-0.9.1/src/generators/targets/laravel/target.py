"""Laravel target for SpecQL code generation.

This target generates comprehensive Laravel 12.x code including Models, Migrations,
Controllers, Form Requests, API Resources, DTOs, Events, Factories, Policies, and Actions.
"""

from datetime import datetime
from typing import TYPE_CHECKING

from src.core.ir import TypeCategory
from src.generators.laravel.action_generator import ActionGenerator
from src.generators.laravel.controller_generator import ControllerGenerator
from src.generators.laravel.dto_generator import DTOGenerator
from src.generators.laravel.enum_generator import EnumGenerator
from src.generators.laravel.event_generator import EventGenerator
from src.generators.laravel.factory_generator import FactoryGenerator
from src.generators.laravel.form_request_generator import FormRequestGenerator
from src.generators.laravel.migration_generator import MigrationGenerator
from src.generators.laravel.model_generator import ModelGenerator
from src.generators.laravel.policy_generator import PolicyGenerator
from src.generators.laravel.resource_generator import ResourceGenerator
from src.generators.targets.base.registry import register_target
from src.generators.targets.base.target import BaseTarget, GeneratedFile, GenerationResult

if TYPE_CHECKING:
    from src.core.ir import EntityIR


@register_target("laravel")
class LaravelTarget(BaseTarget):
    """Laravel code generation target.

    Generates comprehensive Laravel PHP backend code:
    - Eloquent Models with proper types, relationships, and casts
    - Database migrations with proper column types and constraints
    - Controllers with CRUD operations and custom actions
    - Form Requests for validation (Store and Update)
    - API Resources for JSON responses
    - DTOs (Data Transfer Objects)
    - Events (created, updated, deleted)
    - Model Factories for testing
    - Policies for authorization
    - Custom Actions with step compilation
    """

    @property
    def name(self) -> str:
        """The name of this target."""
        return "laravel"

    @property
    def supported_languages(self) -> list[str]:
        """List of programming languages this target generates."""
        return ["php"]

    def __init__(self):
        """Initialize the Laravel target with individual generators."""
        self.enum_generator = EnumGenerator()
        self.migration_generator = MigrationGenerator()
        self.model_generator = ModelGenerator()
        self.factory_generator = FactoryGenerator()
        self.controller_generator = ControllerGenerator()
        self.form_request_generator = FormRequestGenerator()
        self.resource_generator = ResourceGenerator()
        self.dto_generator = DTOGenerator()
        self.event_generator = EventGenerator()
        self.policy_generator = PolicyGenerator()
        self.action_generator = ActionGenerator()

    def generate(self, entity_ir: "EntityIR") -> GenerationResult:
        """Generate Laravel code for a single EntityIR.

        Uses individual generators to create comprehensive Laravel backend code.

        Args:
            entity_ir: The intermediate representation of the entity

        Returns:
            GenerationResult containing all generated files
        """
        files: list[GeneratedFile] = []
        errors: list[str] = []
        warnings: list[str] = []

        try:
            # Generate enums for enum fields
            for field in entity_ir.fields:
                if field.type_ir.category == TypeCategory.ENUM:
                    content = self.enum_generator.generate_from_field(entity_ir.name, field)
                    path = f"app/Enums/{entity_ir.name}{field.name.title()}Enum.php"
                    files.append(GeneratedFile(path=path, content=content, language="php"))

            # Generate migration
            migration_content = self.migration_generator.generate_from_ir(entity_ir)
            migration_path = f"database/migrations/{self._migration_timestamp()}_create_{entity_ir.name.lower()}_table.php"
            files.append(
                GeneratedFile(path=migration_path, content=migration_content, language="php")
            )

            # Generate model
            model_content = self.model_generator.generate_from_ir(entity_ir)
            model_path = f"app/Models/{entity_ir.schema.title()}/{entity_ir.name}.php"
            files.append(GeneratedFile(path=model_path, content=model_content, language="php"))

            # Generate factory
            factory_content = self.factory_generator.generate_from_ir(entity_ir)
            factory_path = (
                f"database/factories/{entity_ir.schema.title()}/{entity_ir.name}Factory.php"
            )
            files.append(GeneratedFile(path=factory_path, content=factory_content, language="php"))

            # Generate controller
            controller_content = self.controller_generator.generate_from_ir(entity_ir)
            controller_path = (
                f"app/Http/Controllers/{entity_ir.schema.title()}/{entity_ir.name}Controller.php"
            )
            files.append(
                GeneratedFile(path=controller_path, content=controller_content, language="php")
            )

            # Generate form requests
            store_request_content = self.form_request_generator.generate_store_request_from_ir(
                entity_ir
            )
            store_request_path = (
                f"app/Http/Requests/{entity_ir.schema.title()}/{entity_ir.name}StoreRequest.php"
            )
            files.append(
                GeneratedFile(
                    path=store_request_path, content=store_request_content, language="php"
                )
            )

            update_request_content = self.form_request_generator.generate_update_request_from_ir(
                entity_ir
            )
            update_request_path = (
                f"app/Http/Requests/{entity_ir.schema.title()}/{entity_ir.name}UpdateRequest.php"
            )
            files.append(
                GeneratedFile(
                    path=update_request_path, content=update_request_content, language="php"
                )
            )

            # Generate API resource
            resource_content = self.resource_generator.generate_from_ir(entity_ir)
            resource_path = (
                f"app/Http/Resources/{entity_ir.schema.title()}/{entity_ir.name}Resource.php"
            )
            files.append(
                GeneratedFile(path=resource_path, content=resource_content, language="php")
            )

            # Generate DTO
            dto_content = self.dto_generator.generate_from_ir(entity_ir)
            dto_path = f"app/DTOs/{entity_ir.schema.title()}/{entity_ir.name}DTO.php"
            files.append(GeneratedFile(path=dto_path, content=dto_content, language="php"))

            # Generate events
            created_event_content = self.event_generator.generate_from_ir(entity_ir, "created")
            created_event_path = (
                f"app/Events/{entity_ir.schema.title()}/{entity_ir.name}Created.php"
            )
            files.append(
                GeneratedFile(
                    path=created_event_path, content=created_event_content, language="php"
                )
            )

            updated_event_content = self.event_generator.generate_from_ir(entity_ir, "updated")
            updated_event_path = (
                f"app/Events/{entity_ir.schema.title()}/{entity_ir.name}Updated.php"
            )
            files.append(
                GeneratedFile(
                    path=updated_event_path, content=updated_event_content, language="php"
                )
            )

            deleted_event_content = self.event_generator.generate_from_ir(entity_ir, "deleted")
            deleted_event_path = (
                f"app/Events/{entity_ir.schema.title()}/{entity_ir.name}Deleted.php"
            )
            files.append(
                GeneratedFile(
                    path=deleted_event_path, content=deleted_event_content, language="php"
                )
            )

            # Generate policy
            policy_content = self.policy_generator.generate_from_ir(entity_ir)
            policy_path = f"app/Policies/{entity_ir.schema.title()}/{entity_ir.name}Policy.php"
            files.append(GeneratedFile(path=policy_path, content=policy_content, language="php"))

            # TODO: Generate actions when ActionIR is available
            # For now, we'll skip action generation as it requires ActionIR instances

        except Exception as e:
            errors.append(f"Generation failed: {str(e)}")
            return GenerationResult(
                success=False,
                files=files,
                target_name=self.name,
                errors=errors,
                warnings=warnings,
            )

        return GenerationResult(
            success=True,
            files=files,
            target_name=self.name,
            errors=errors,
            warnings=warnings,
        )

    def _migration_timestamp(self) -> str:
        """Generate timestamp for migration filename."""
        return datetime.now().strftime("%Y_%m_%d_%H%M%S")
