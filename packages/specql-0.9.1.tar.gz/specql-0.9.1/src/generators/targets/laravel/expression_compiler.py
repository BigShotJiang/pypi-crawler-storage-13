"""Laravel-specific expression compilation."""

from typing import Any, Optional

from src.generators.targets.base.interfaces import ExpressionCompilationResult
from src.generators.targets.base.step_compiler import BaseExpressionCompiler


class LaravelExpressionCompiler(BaseExpressionCompiler):
    """Compiles SpecQL expressions to Laravel/PHP expressions.

    Handles the translation of SpecQL expressions into Laravel/PHP-compatible
    expressions that can be used in Eloquent queries, validation rules, etc.
    """

    # Laravel/PHP operator mappings
    OPERATORS = {
        "=": "==",
        "!=": "!=",
        "AND": "&&",
        "OR": "||",
        "NOT": "!",
        "<=": "<=",
        ">=": ">=",
        "<": "<",
        ">": ">",
        "+": "+",
        "-": "-",
        "*": "*",
        "/": "/",
        "%": "%",
        ".": ".",
    }

    NULL_LITERAL = "null"
    TRUE_LITERAL = "true"
    FALSE_LITERAL = "false"
    STRING_QUOTE = "'"

    def compile(
        self, expression: str, context: dict[str, Any] | None = None
    ) -> ExpressionCompilationResult:
        """Compile expression with Laravel-specific transformations."""
        if context is None:
            context = {}

        # Start with base tokenization and operator replacement
        tokens = self._tokenize(expression)
        translated = self._translate_tokens(tokens)
        code = self._join_tokens(translated)

        # Apply Laravel-specific transformations
        code = self._replace_functions(code)
        code = self._replace_variables(code, context)

        return ExpressionCompilationResult(code=code)

    def _translate_identifier(self, identifier: str) -> str:
        """Translate identifiers to PHP variable syntax."""
        return f"${identifier}"

    def _translate_field_reference(self, field_ref: str) -> str:
        """Translate field references - for backwards compatibility, keep as-is."""
        # Original implementation didn't parse field references, just did string replacements
        # To maintain backwards compatibility, return unchanged
        return field_ref

    def compile_expression(self, expression: str, context: dict[str, Any]) -> str:
        """Compile a SpecQL expression to Laravel/PHP.

        This is a convenience wrapper around compile() that returns just the code string.

        Args:
            expression: The SpecQL expression string
            context: Compilation context (variables, entity info, etc.)

        Returns:
            Laravel/PHP expression string
        """
        result = self.compile(expression, context)
        return result.code

    def _replace_functions(self, expression: str) -> str:
        """Replace SpecQL functions with Laravel/PHP functions."""
        replacements = {
            "NOW()": "now()",
            "TODAY()": "today()",
            "LEN(": "strlen(",
            "CONTAINS(": "str_contains(",
            "UPPER(": "strtoupper(",
            "LOWER(": "strtolower(",
        }

        for specql_func, php_func in replacements.items():
            expression = expression.replace(specql_func, php_func)

        return expression

    def _replace_variables(self, expression: str, context: dict[str, Any]) -> str:
        """Replace variables in the expression using context."""
        # Simple variable replacement - in a real implementation,
        # this would be more sophisticated
        for var_name, var_value in context.items():
            if isinstance(var_value, str):
                expression = expression.replace(f"${var_name}", f"'{var_value}'")
            else:
                expression = expression.replace(f"${var_name}", str(var_value))

        return expression

    def supports_operator(self, operator: str) -> bool:
        """Check if Laravel/PHP supports a specific operator."""
        # PHP supports all the base operators plus some extras
        php_operators = {
            "&&",
            "||",
            "!",  # Logical
            "==",
            "!=",
            "===",
            "!==",
            "<",
            ">",
            "<=",
            ">=",
            "<=>",  # Comparison
            "+",
            "-",
            "*",
            "/",
            "%",
            "**",  # Arithmetic
            ".",
            "instanceof",  # Type checking
            "&",
            "|",
            "^",
            "~",
            "<<",
            ">>",  # Bitwise
            "?:",  # Ternary
        }

        return operator in php_operators

    def get_operator_mapping(self, operator: str) -> str:
        """Get Laravel/PHP-specific operator mapping."""
        return self.OPERATORS.get(operator.upper(), operator)
