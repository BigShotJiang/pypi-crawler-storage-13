"""Laravel-specific type mapping for SpecQL types."""

from typing import Any

from src.core.ir.type_ir import TypeCategory, TypeIR
from src.generators.targets.base.type_mapper import BaseTypeMapper, TypeInfo


class LaravelTypeMapper(BaseTypeMapper):
    """Maps SpecQL types to Laravel/PHP types.

    Provides Laravel-specific type mappings with appropriate PHP types,
    Laravel casts, migrations, and validation rules.
    """

    def map_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map a SpecQL type to Laravel/PHP type information.

        Args:
            type_ir: The SpecQL type to map

        Returns:
            TypeInfo with Laravel-specific details
        """
        if type_ir.category == TypeCategory.SCALAR:
            return self._map_scalar_type(type_ir)
        elif type_ir.category == TypeCategory.REFERENCE:
            return self._map_reference_type(type_ir)
        elif type_ir.category == TypeCategory.ENUM:
            return self._map_enum_type(type_ir)
        elif type_ir.category == TypeCategory.LIST:
            return self._map_list_type(type_ir)
        elif type_ir.category == TypeCategory.COMPOSITE:
            return self._map_composite_type(type_ir)
        else:
            raise ValueError(f"Unsupported type category: {type_ir.category}")

    def _map_scalar_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map scalar types to Laravel/PHP."""
        return self._get_base_type_mapping(type_ir.base_type)

    def _map_reference_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map reference types to Laravel foreign keys."""
        return TypeInfo(
            target_type="string",
            ddl_type="foreignId",  # Laravel migration method
            imports=["Illuminate\\Database\\Schema\\Blueprint"],
            constraints=["constrained()", "cascadeOnDelete()"],
        )

    def _map_enum_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map enum types to Laravel enums."""
        return TypeInfo(
            target_type="string",
            ddl_type="enum",  # Laravel migration enum method
            imports=["Illuminate\\Database\\Schema\\Blueprint"],
            constraints=[],
        )

    def _map_list_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map list types to Laravel JSON arrays."""
        if type_ir.element_type:
            return TypeInfo(
                target_type="array",
                ddl_type="json",  # Store as JSON in database
                imports=["Illuminate\\Database\\Eloquent\\Casts\\AsArrayCast"],
                constraints=[],
            )
        else:
            # Default to mixed array
            return TypeInfo(
                target_type="array",
                ddl_type="json",
                imports=["Illuminate\\Database\\Eloquent\\Casts\\AsArrayCast"],
                constraints=[],
            )

    def _map_composite_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map composite types to Laravel JSON objects."""
        return TypeInfo(
            target_type="object",
            ddl_type="json",
            imports=["Illuminate\\Database\\Eloquent\\Casts\\AsCollection"],
            constraints=[],
        )

    def get_reference_type(self, referenced_entity: str) -> str:
        """Get the Laravel type for foreign key references.

        Args:
            referenced_entity: Name of the referenced entity

        Returns:
            Laravel migration type string for foreign key fields
        """
        return "foreignId"

    def get_enum_type(self, enum_values: list[str]) -> str:
        """Get the Laravel type for enum fields.

        Args:
            enum_values: List of allowed enum values

        Returns:
            Laravel enum type (will be converted to proper enum migration)
        """
        return "enum"

    def _get_base_type_mapping(self, base_type: str) -> TypeInfo:
        """Get the base Laravel/PHP type mapping for a SpecQL type.

        Args:
            base_type: The SpecQL base type

        Returns:
            TypeInfo for the base type
        """
        mappings = {
            # Scalar types
            "string": TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=["Illuminate\\Database\\Schema\\Blueprint"],
                constraints=[],
            ),
            "text": TypeInfo(
                target_type="string",
                ddl_type="text",
                imports=["Illuminate\\Database\\Schema\\Blueprint"],
                constraints=[],
            ),
            "integer": TypeInfo(
                target_type="int",
                ddl_type="integer",
                imports=["Illuminate\\Database\\Schema\\Blueprint"],
                constraints=[],
            ),
            "bigint": TypeInfo(
                target_type="int",
                ddl_type="bigInteger",
                imports=["Illuminate\\Database\\Schema\\Blueprint"],
                constraints=[],
            ),
            "smallint": TypeInfo(
                target_type="int",
                ddl_type="smallInteger",
                imports=["Illuminate\\Database\\Schema\\Blueprint"],
                constraints=[],
            ),
            "decimal": TypeInfo(
                target_type="float",
                ddl_type="decimal",
                imports=["Illuminate\\Database\\Schema\\Blueprint"],
                constraints=[],
            ),
            "float": TypeInfo(
                target_type="float",
                ddl_type="float",
                imports=["Illuminate\\Database\\Schema\\Blueprint"],
                constraints=[],
            ),
            "double": TypeInfo(
                target_type="float",
                ddl_type="double",
                imports=["Illuminate\\Database\\Schema\\Blueprint"],
                constraints=[],
            ),
            "boolean": TypeInfo(
                target_type="bool",
                ddl_type="boolean",
                imports=["Illuminate\\Database\\Schema\\Blueprint"],
                constraints=[],
            ),
            "date": TypeInfo(
                target_type="Carbon",
                ddl_type="date",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\Attribute",
                    "Carbon\\Carbon",
                ],
                constraints=[],
            ),
            "datetime": TypeInfo(
                target_type="Carbon",
                ddl_type="datetime",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\Attribute",
                    "Carbon\\Carbon",
                ],
                constraints=[],
            ),
            "timestamp": TypeInfo(
                target_type="Carbon",
                ddl_type="timestamp",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\Attribute",
                    "Carbon\\Carbon",
                ],
                constraints=[],
            ),
            "time": TypeInfo(
                target_type="Carbon",
                ddl_type="time",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\Attribute",
                    "Carbon\\Carbon",
                ],
                constraints=[],
            ),
            "uuid": TypeInfo(
                target_type="string",
                ddl_type="uuid",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\Attribute",
                ],
                constraints=[],
            ),
            "json": TypeInfo(
                target_type="mixed",
                ddl_type="json",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\AsCollection",
                ],
                constraints=[],
            ),
            "jsonb": TypeInfo(
                target_type="mixed",
                ddl_type="json",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\AsCollection",
                ],
                constraints=[],
            ),
            # Email type (using VARCHAR with validation)
            "email": TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\Attribute",
                ],
                constraints=[],  # Validation handled in model rules
            ),
            # URL type (using VARCHAR with validation)
            "url": TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\Attribute",
                ],
                constraints=[],  # Validation handled in model rules
            ),
            # Phone type (using VARCHAR)
            "phone": TypeInfo(
                target_type="string",
                ddl_type="string",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\Attribute",
                ],
                constraints=[],
            ),
            # Currency type (using DECIMAL)
            "currency": TypeInfo(
                target_type="float",
                ddl_type="decimal",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\Attribute",
                ],
                constraints=["total => 10", "places => 2"],
            ),
            # Percentage type (using DECIMAL with constraints)
            "percentage": TypeInfo(
                target_type="float",
                ddl_type="decimal",
                imports=[
                    "Illuminate\\Database\\Schema\\Blueprint",
                    "Illuminate\\Database\\Eloquent\\Casts\\Attribute",
                ],
                constraints=["total => 5", "places => 2"],
            ),
        }

        if base_type not in mappings:
            raise ValueError(f"Unsupported type: {base_type}")

        return mappings[base_type]

    def _add_not_null_constraint(self, type_info: TypeInfo) -> TypeInfo:
        """Add NOT NULL constraint to Laravel migration.

        Args:
            type_info: Current type information

        Returns:
            Updated TypeInfo with NOT NULL constraint
        """
        return TypeInfo(
            target_type=type_info.target_type,
            ddl_type=type_info.ddl_type,
            imports=type_info.imports,
            constraints=type_info.constraints + ["->nullable(false)"],
        )

    def _add_default_value(self, type_info: TypeInfo, type_ir: TypeIR) -> TypeInfo:
        """Add default value to Laravel migration.

        Args:
            type_info: Current type information
            type_ir: The type IR with default value

        Returns:
            Updated TypeInfo with default value
        """
        default_php = self._format_default_value(type_ir.default_value, type_ir.base_type)
        return TypeInfo(
            target_type=type_info.target_type,
            ddl_type=type_info.ddl_type,
            imports=type_info.imports,
            constraints=type_info.constraints + [f"->default({default_php})"],
        )

    def _add_constraints(self, type_info: TypeInfo, type_ir: TypeIR) -> TypeInfo:
        """Add custom constraints to Laravel migration.

        Args:
            type_info: Current type information
            type_ir: The type IR with constraints

        Returns:
            Updated TypeInfo with additional constraints
        """
        additional_constraints = []
        for constraint in type_ir.constraints:
            if isinstance(constraint, dict):
                # Handle structured constraints
                constraint_php = self._format_constraint(constraint)
                if constraint_php:
                    additional_constraints.append(constraint_php)
            else:
                # Handle string constraints
                additional_constraints.append(f"->{str(constraint)}")

        return TypeInfo(
            target_type=type_info.target_type,
            ddl_type=type_info.ddl_type,
            imports=type_info.imports,
            constraints=type_info.constraints + additional_constraints,
        )

    def _format_default_value(self, value: Any, base_type: str) -> str:
        """Format a default value for Laravel/PHP.

        Args:
            value: The default value
            base_type: The base type for context

        Returns:
            PHP-formatted default value
        """
        if isinstance(value, str):
            if base_type == "uuid":
                if value.lower() == "gen_random_uuid()":
                    return "(string) Str::uuid()"
                return f"'{value}'"
            elif base_type in ("date", "datetime", "timestamp"):
                if value.upper() == "NOW":
                    return "now()"
                return f"'{value}'"
            else:
                return f"'{value}'"
        elif isinstance(value, bool):
            return "true" if value else "false"
        elif value is None:
            return "null"
        else:
            return str(value)

    def _format_constraint(self, constraint: dict) -> str:
        """Format a structured constraint for Laravel.

        Args:
            constraint: Constraint dictionary

        Returns:
            PHP constraint string or empty string if unsupported
        """
        constraint_type = constraint.get("type", "").lower()

        if constraint_type == "check":
            expression = constraint.get("expression", "")
            return f"->check('{expression}')"
        elif constraint_type == "min":
            value = constraint.get("value")
            return f"->min({value})"
        elif constraint_type == "max":
            value = constraint.get("value")
            return f"->max({value})"
        elif constraint_type == "range":
            min_val = constraint.get("min")
            max_val = constraint.get("max")
            return f"->min({min_val})->max({max_val})"
        elif constraint_type == "length":
            max_len = constraint.get("max")
            return f"->length({max_len})"

        return ""
