"""Laravel-specific action step compilation."""

from typing import TYPE_CHECKING, Any

from src.generators.targets.base.interfaces import StepCompilationResult
from src.generators.targets.base.step_compiler import BaseStepCompiler
from src.generators.targets.laravel.expression_compiler import LaravelExpressionCompiler

if TYPE_CHECKING:
    from src.core.ir.action_ir import ActionStepIR


class LaravelStepCompiler(BaseStepCompiler):
    """Compiles SpecQL action steps to Laravel/PHP code.

    Handles the translation of SpecQL action steps (validate, update, insert, etc.)
    into Laravel/PHP code that can be used in controllers, jobs, or other application code.
    """

    def __init__(self):
        """Initialize the Laravel step compiler with an expression compiler."""
        super().__init__(LaravelExpressionCompiler())

    def _compile_validate(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a validate step to Laravel validation.

        Validate steps check conditions and throw exceptions if they fail.
        """
        if not step.expression:
            raise ValueError("Validate step must have an expression")

        condition = self.compile_condition(step.expression, ctx)
        error_message = "Validation failed"  # Default error message

        code = f"""
        if (!{condition}) {{
            throw new \\InvalidArgumentException('{error_message}');
        }}
        """.strip()

        return StepCompilationResult(code=code)

    def _compile_update(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile an update step to Laravel Eloquent update."""
        if not step.fields:
            raise ValueError("Update step must have fields to update")

        model_class = self._get_model_class(step, ctx)
        update_data = self._compile_update_data(step.fields, ctx)
        where_clause = self._compile_where_clause(step, ctx)

        code = f"${model_class}::where({where_clause})->update({update_data});"

        return StepCompilationResult(code=code)

    def _compile_insert(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile an insert step to Laravel Eloquent create."""
        if not step.fields:
            raise ValueError("Insert step must have fields to insert")

        model_class = self._get_model_class(step, ctx)
        create_data = self._compile_create_data(step.fields, ctx)

        code = f"${model_class}::create({create_data});"

        return StepCompilationResult(code=code)

    def _compile_if(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile an if step to PHP if statement."""
        if not step.condition:
            raise ValueError("If step must have a condition")

        condition = self.compile_condition(step.condition, ctx)

        # Compile the then branch using base class helper
        then_result = self._compile_nested_steps(step.then_steps or [], ctx)

        # Compile the else branch
        else_result = None
        if step.else_steps:
            else_result = self._compile_nested_steps(step.else_steps, ctx)

        code = f"if ({condition}) {{\n{then_result.code}\n}}"
        if else_result:
            code += f" else {{\n{else_result.code}\n}}"

        # Merge imports and variables from both branches
        imports = then_result.imports
        variables = then_result.variables.copy()
        if else_result:
            imports = imports | else_result.imports
            variables.update(else_result.variables)

        return StepCompilationResult(code=code, imports=imports, variables=variables)

    def _compile_call(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a call step to PHP method call."""
        if not step.function_name:
            raise ValueError("Call step must have a function name")

        function_name = step.function_name
        args = self._compile_function_args(step.function_args, ctx)

        code = f"{function_name}({args});"
        return StepCompilationResult(code=code)

    def _compile_notify(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a notify step to Laravel notification."""
        # ActionStepIR doesn't have channel/payload fields, so this is a placeholder
        # In a real implementation, these would be added to ActionStepIR or passed via context
        raise NotImplementedError("Notify steps not yet implemented in ActionStepIR")

    def _compile_foreach(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a foreach step to PHP foreach loop."""
        if not step.collection or not step.item_name:
            raise ValueError("Foreach step must have collection and item_name")

        collection_expr = self.expression_compiler.compile_expression(step.collection, ctx)
        item_var = f"${step.item_name}"

        # Compile the loop body using base class helper
        loop_ctx = ctx.copy()
        loop_ctx[step.item_name] = item_var
        loop_result = self._compile_nested_steps(step.loop_steps or [], loop_ctx)

        code = f"foreach ({collection_expr} as {item_var}) {{\n{loop_result.code}\n}}"

        return StepCompilationResult(
            code=code, imports=loop_result.imports, variables=loop_result.variables
        )

    def _get_model_class(self, step: "ActionStepIR", context: dict[str, Any]) -> str:
        """Get the model class name for a step."""
        entity_name = step.target_entity or context.get("entity_name")
        if not entity_name:
            raise ValueError(
                "Cannot determine model class: no target_entity or entity_name in context"
            )

        # Convert entity name to model class name (PascalCase)
        return self._to_pascal_case(entity_name)

    def _compile_update_data(self, fields: dict[str, Any], context: dict[str, Any]) -> str:
        """Compile the update data array for Laravel."""
        assignments = []
        entity_fields = context.get("entity", {}).get("fields", {})

        for field_name, field_value in fields.items():
            if isinstance(field_value, str):
                # Assume it's an expression
                compiled_value = self.expression_compiler.compile_expression(field_value, context)
            else:
                # Assume it's a literal value
                compiled_value = self._format_literal_value(field_value)

            # Handle enum values
            field_type = entity_fields.get(field_name, "")
            if field_type.startswith("enum(") and isinstance(field_value, str):
                enum_class = self._get_enum_class_name(field_name, context)
                # Convert enum value to PascalCase for enum case
                from ...laravel.utils import enum_value_to_case_name

                enum_case = enum_value_to_case_name(field_value.strip("'\""))
                compiled_value = f"{enum_class}::{enum_case}"

            assignments.append(f"'{field_name}' => {compiled_value}")

        return f"[{', '.join(assignments)}]"

    def _compile_where_clause(self, step: "ActionStepIR", context: dict[str, Any]) -> str:
        """Compile the WHERE clause for Laravel queries."""
        # ActionStepIR doesn't have where_condition or target_id fields
        # In a real implementation, these would be added or passed via context
        # For now, return empty string (no WHERE clause)
        return "[]"

    def _compile_create_data(self, fields: dict[str, Any], context: dict[str, Any]) -> str:
        """Compile the create data array for Laravel."""
        assignments = []
        for field_name, field_value in fields.items():
            if isinstance(field_value, str):
                # Assume it's an expression
                compiled_value = self.expression_compiler.compile_expression(field_value, context)
            else:
                # Assume it's a literal value
                compiled_value = self._format_literal_value(field_value)

            assignments.append(f"'{field_name}' => {compiled_value}")

        return f"[{', '.join(assignments)}]"

    def _compile_function_args(self, args: list[Any], context: dict[str, Any]) -> str:
        """Compile function arguments."""
        compiled_args = []
        for arg in args:
            if isinstance(arg, str):
                compiled_args.append(self.expression_compiler.compile_expression(arg, context))
            else:
                compiled_args.append(self._format_literal_value(arg))

        return ", ".join(compiled_args)

    def _format_literal_value(self, value: Any) -> str:
        """Format a literal value for PHP."""
        if isinstance(value, str):
            # Escape single quotes in the string
            escaped_value = value.replace("'", "\\'")
            return f"'{escaped_value}'"
        elif isinstance(value, bool):
            return "true" if value else "false"
        elif value is None:
            return "null"
        else:
            return str(value)

    def _get_enum_class_name(self, field_name: str, context: dict[str, Any]) -> str:
        """Get the enum class name for a field."""
        from ...laravel.utils import field_to_enum_class_name, schema_to_namespace

        entity_name = context.get("entity", {}).get("name", "")
        schema = context.get("entity", {}).get("schema", "")

        enum_class = field_to_enum_class_name(entity_name, field_name)
        namespace = schema_to_namespace(schema)
        return f"\\App\\Enums\\{namespace}\\{enum_class}"

    def _to_pascal_case(self, name: str) -> str:
        """Convert a name to PascalCase."""
        return "".join(word.capitalize() for word in name.split("_"))
