"""Django target for SpecQL code generation."""

from typing import TYPE_CHECKING

from src.generators.targets.base.registry import register_target
from src.generators.targets.base.target import BaseTarget, GeneratedFile, GenerationResult
from src.generators.targets.django.type_mapper import DjangoTypeMapper
from src.generators.targets.django.step_compiler import DjangoStepCompiler

if TYPE_CHECKING:
    from src.core.ir import EntityIR, FieldIR


@register_target("django")
class DjangoTarget(BaseTarget):
    """Django/Python code generation target."""

    def __init__(self):
        self.type_mapper = DjangoTypeMapper()
        self.step_compiler = DjangoStepCompiler()

    @property
    def name(self) -> str:
        return "django"

    @property
    def supported_languages(self) -> list[str]:
        return ["python"]

    def generate(self, entity_ir: "EntityIR") -> GenerationResult:
        """Generate Django code for an EntityIR."""
        files: list[GeneratedFile] = []

        # Generate model
        model_content = self._generate_model(entity_ir)
        files.append(
            GeneratedFile(
                path=f"{entity_ir.schema}/models/{entity_ir.name.lower()}.py",
                content=model_content,
                language="python",
            )
        )

        # Generate serializer
        serializer_content = self._generate_serializer(entity_ir)
        files.append(
            GeneratedFile(
                path=f"{entity_ir.schema}/serializers/{entity_ir.name.lower()}_serializer.py",
                content=serializer_content,
                language="python",
            )
        )

        # Generate viewset
        viewset_content = self._generate_viewset(entity_ir)
        files.append(
            GeneratedFile(
                path=f"{entity_ir.schema}/views/{entity_ir.name.lower()}_viewset.py",
                content=viewset_content,
                language="python",
            )
        )

        # Generate admin
        admin_content = self._generate_admin(entity_ir)
        files.append(
            GeneratedFile(
                path=f"{entity_ir.schema}/admin/{entity_ir.name.lower()}_admin.py",
                content=admin_content,
                language="python",
            )
        )

        return GenerationResult(success=True, files=files, target_name=self.name)

    def _generate_model(self, entity_ir: "EntityIR") -> str:
        """Generate Django model."""
        lines = [
            "from django.db import models",
            "import uuid",
            "from django.utils import timezone",
            "",
            "",
            f"class {entity_ir.name}(models.Model):",
            f'    """Auto-generated Django model for {entity_ir.name}."""',
            "",
            "    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)",
        ]

        for field in entity_ir.fields:
            type_info = self.type_mapper.map_type(field.type_ir)
            nullable = ", null=True, blank=True" if field.nullable else ""
            lines.append(f"    {field.name} = {type_info.target_type.rstrip(')')}{nullable})")

        # Add timestamps
        lines.extend(
            [
                "",
                "    created_at = models.DateTimeField(default=timezone.now)",
                "    updated_at = models.DateTimeField(auto_now=True)",
                "",
                "    class Meta:",
                f"        db_table = '{entity_ir.default_table_name}'",
                f"        verbose_name = '{entity_ir.name}'",
                f"        verbose_name_plural = '{entity_ir.name}s'",
                "",
                "    def __str__(self):",
                "        return str(self.id)",
            ]
        )

        return "\n".join(lines)

    def _generate_serializer(self, entity_ir: "EntityIR") -> str:
        """Generate DRF serializer."""
        field_names = ", ".join(f"'{f.name}'" for f in entity_ir.fields)
        return f'''from rest_framework import serializers
from .models import {entity_ir.name}


class {entity_ir.name}Serializer(serializers.ModelSerializer):
    """Auto-generated serializer for {entity_ir.name}."""

    class Meta:
        model = {entity_ir.name}
        fields = ['id', {field_names}, 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']
'''

    def _generate_viewset(self, entity_ir: "EntityIR") -> str:
        """Generate DRF viewset."""
        return f'''from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import {entity_ir.name}
from .serializers import {entity_ir.name}Serializer


class {entity_ir.name}ViewSet(viewsets.ModelViewSet):
    """Auto-generated viewset for {entity_ir.name}."""

    queryset = {entity_ir.name}.objects.all()
    serializer_class = {entity_ir.name}Serializer
    permission_classes = [IsAuthenticated]
'''

    def _generate_admin(self, entity_ir: "EntityIR") -> str:
        """Generate Django admin configuration."""
        field_names = ", ".join(f"'{f.name}'" for f in entity_ir.fields[:5])  # First 5 fields
        return f'''from django.contrib import admin
from .models import {entity_ir.name}


@admin.register({entity_ir.name})
class {entity_ir.name}Admin(admin.ModelAdmin):
    """Auto-generated admin for {entity_ir.name}."""

    list_display = ['id', {field_names}]
    search_fields = [{field_names}]
    readonly_fields = ['id', 'created_at', 'updated_at']
'''
