"""Django expression compiler."""

from src.generators.targets.base.step_compiler import BaseExpressionCompiler


class DjangoExpressionCompiler(BaseExpressionCompiler):
    """Compiles SpecQL expressions to Python/Django."""

    OPERATORS = {
        "=": "==",
        "!=": "!=",
        "AND": "and",
        "OR": "or",
        "NOT": "not",
        "<": "<",
        ">": ">",
        "<=": "<=",
        ">=": ">=",
    }

    NULL_LITERAL = "None"
    TRUE_LITERAL = "True"
    FALSE_LITERAL = "False"
    STRING_QUOTE = "'"

    def _translate_identifier(self, identifier: str) -> str:
        """Python uses bare identifiers."""
        return identifier

    def _translate_field_reference(self, field_ref: str) -> str:
        """Translate entity.field to Python attribute access."""
        parts = field_ref.split(".")
        if len(parts) == 2:
            return f"{parts[0].lower()}.{parts[1]}"
        return field_ref
