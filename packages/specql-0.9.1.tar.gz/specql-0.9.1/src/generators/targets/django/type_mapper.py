"""Django type mapping from TypeIR."""

from src.core.ir import TypeIR, TypeCategory
from src.generators.targets.base.type_mapper import BaseTypeMapper, TypeInfo


class DjangoTypeMapper(BaseTypeMapper):
    """Maps TypeIR to Django model field types."""

    SCALAR_MAPPINGS = {
        "text": ("models.TextField()", "TEXT"),
        "varchar": ("models.CharField(max_length={length})", "VARCHAR({length})"),
        "integer": ("models.IntegerField()", "INTEGER"),
        "bigint": ("models.BigIntegerField()", "BIGINT"),
        "boolean": ("models.BooleanField()", "BOOLEAN"),
        "uuid": ("models.UUIDField()", "UUID"),
        "timestamp": ("models.DateTimeField()", "TIMESTAMP"),
        "date": ("models.DateField()", "DATE"),
        "time": ("models.TimeField()", "TIME"),
        "decimal": (
            "models.DecimalField(max_digits={precision}, decimal_places={scale})",
            "DECIMAL({precision},{scale})",
        ),
        "float": ("models.FloatField()", "FLOAT"),
        "json": ("models.JSONField()", "JSON"),
        "jsonb": ("models.JSONField()", "JSONB"),
    }

    def map_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map TypeIR to Django field type information."""
        if type_ir.category == TypeCategory.SCALAR:
            target_type, ddl_type = self.SCALAR_MAPPINGS.get(
                type_ir.base_type, ("models.TextField()", "TEXT")
            )
            # Handle parameterized types
            if type_ir.params:
                target_type = target_type.format(**type_ir.params)
                ddl_type = ddl_type.format(**type_ir.params)

            imports = ["from django.db import models"]
            if type_ir.base_type == "uuid":
                imports.append("import uuid")

            return TypeInfo(target_type=target_type, ddl_type=ddl_type, imports=imports)

        if type_ir.category == TypeCategory.REFERENCE:
            entity_name = type_ir.referenced_entity or "unknown_entity"
            return TypeInfo(
                target_type=f"models.ForeignKey('{entity_name}', on_delete=models.CASCADE)",
                ddl_type=f"INTEGER REFERENCES {entity_name.lower()}(id)",
                imports=["from django.db import models"],
            )

        if type_ir.category == TypeCategory.ENUM:
            return TypeInfo(
                target_type="models.CharField(max_length=50, choices=STATUS_CHOICES)",
                ddl_type="VARCHAR(50)",
                imports=["from django.db import models"],
            )

        if type_ir.category == TypeCategory.LIST:
            return TypeInfo(
                target_type="models.JSONField(default=list)",
                ddl_type="JSONB",
                imports=["from django.db import models"],
            )

        return TypeInfo(
            target_type="models.TextField()",
            ddl_type="TEXT",
            imports=["from django.db import models"],
        )

    def get_reference_type(self, referenced_entity: str) -> str:
        """Get the target type for foreign key references."""
        return f"models.ForeignKey('{referenced_entity}', on_delete=models.CASCADE)"

    def get_enum_type(self, enum_values: list[str]) -> str:
        """Get the target type for enum fields."""
        return "models.CharField(max_length=50, choices=STATUS_CHOICES)"
