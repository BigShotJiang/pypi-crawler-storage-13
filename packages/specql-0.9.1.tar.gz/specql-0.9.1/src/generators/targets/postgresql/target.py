"""PostgreSQL target for SpecQL code generation."""

from typing import TYPE_CHECKING, Any

from src.generators.targets.base.registry import register_target
from src.generators.targets.base.target import BaseTarget, GeneratedFile, GenerationResult
from src.generators.targets.postgresql.generators.schema_orchestrator import SchemaOrchestrator
from src.generators.targets.postgresql.generators.actions.action_orchestrator import (
    ActionOrchestrator,
)
from src.generators.targets.postgresql.step_compiler import PostgreSQLStepCompiler
from src.generators.targets.postgresql.type_mapper import PostgreSQLTypeMapper

if TYPE_CHECKING:
    from src.core.ir import EntityIR


@register_target("postgresql")
class PostgreSQLTarget(BaseTarget):
    """PostgreSQL code generation target.

    Generates PostgreSQL database schema including:
    - Tables with proper types and constraints
    - Functions for business logic (actions)
    - Views for read models
    - Indexes and triggers as needed
    """

    @property
    def name(self) -> str:
        """The name of this target."""
        return "postgresql"

    @property
    def supported_languages(self) -> list[str]:
        """List of programming languages this target generates."""
        return ["sql"]

    def __init__(self):
        """Initialize the PostgreSQL target with its components."""
        self.type_mapper = PostgreSQLTypeMapper()
        self.step_compiler = PostgreSQLStepCompiler()

        # Initialize migrated generators
        self.schema_orchestrator = SchemaOrchestrator()
        self.action_orchestrator = ActionOrchestrator()

    def generate(self, entity_ir: "EntityIR") -> GenerationResult:
        """Generate PostgreSQL code for the given entity IR.

        Args:
            entity_ir: EntityIR definition to generate PostgreSQL schema for

        Returns:
            GenerationResult containing all generated files
        """
        files = []
        errors = []
        warnings = []

        try:
            # TODO: Convert EntityIR to Entity for compatibility with migrated generators
            # For now, use placeholder implementation until EntityIR->Entity converter is available

            # Generate table DDL using migrated schema orchestrator
            table_files = self._generate_tables([entity_ir])
            files.extend(table_files)

            # Generate action functions using migrated action orchestrator
            if entity_ir.actions:
                action_files = self._generate_actions(entity_ir.actions)
                files.extend(action_files)

        except Exception as e:
            errors.append(f"Generation failed: {str(e)}")
            return GenerationResult(
                success=False, files=files, target_name=self.name, errors=errors, warnings=warnings
            )

        return GenerationResult(
            success=True, files=files, target_name=self.name, errors=errors, warnings=warnings
        )

    def _generate_tables(self, entities: Any) -> list[GeneratedFile]:
        """Generate table DDL files."""
        files = []

        # Placeholder implementation - in a real implementation,
        # this would iterate through entities and generate CREATE TABLE statements
        for entity in entities:
            table_name = self._to_snake_case(entity.name)
            ddl = self._generate_table_ddl(entity)

            files.append(
                GeneratedFile(
                    path=f"schema/{table_name}.sql",
                    content=ddl,
                    language="sql",
                    metadata={"type": "table", "entity": entity.name},
                )
            )

        return files

    def _generate_actions(self, actions: Any) -> list[GeneratedFile]:
        """Generate action function files."""
        files = []

        # Placeholder implementation - in a real implementation,
        # this would iterate through actions and generate PL/pgSQL functions
        for action in actions:
            function_name = f"{action.entity}_{action.name}"
            sql = self._generate_action_function(action)

            files.append(
                GeneratedFile(
                    path=f"functions/{function_name}.sql",
                    content=sql,
                    language="sql",
                    metadata={"type": "function", "action": action.name, "entity": action.entity},
                )
            )

        return files

    def _generate_views(self, views: Any) -> list[GeneratedFile]:
        """Generate view files."""
        files = []

        # Placeholder implementation - in a real implementation,
        # this would iterate through views and generate CREATE VIEW statements
        for view in views:
            view_name = self._to_snake_case(view.name)
            sql = self._generate_view_sql(view)

            files.append(
                GeneratedFile(
                    path=f"views/{view_name}.sql",
                    content=sql,
                    language="sql",
                    metadata={"type": "view", "view": view.name},
                )
            )

        return files

    def _generate_table_ddl(self, entity: Any) -> str:
        """Generate CREATE TABLE DDL for an entity."""
        table_name = self._to_snake_case(entity.name)

        # Start building the DDL
        ddl_lines = [f"CREATE TABLE {table_name} ("]

        # Add columns
        column_lines = []
        for field in entity.fields:
            column_ddl = self._generate_column_ddl(field)
            column_lines.append(f"    {column_ddl}")

        ddl_lines.append(",\n".join(column_lines))

        # Add primary key if specified
        if hasattr(entity, "primary_key") and entity.primary_key:
            pk_columns = ", ".join(entity.primary_key)
            ddl_lines.append(f",\n    PRIMARY KEY ({pk_columns})")

        # Add table constraints
        if hasattr(entity, "constraints"):
            for constraint in entity.constraints:
                ddl_lines.append(f",\n    {constraint}")

        ddl_lines.append("\n);")

        # Add indexes if specified
        if hasattr(entity, "indexes"):
            for index in entity.indexes:
                index_ddl = self._generate_index_ddl(table_name, index)
                ddl_lines.append(f"\n{index_ddl}")

        # Add comments
        if hasattr(entity, "description") and entity.description:
            ddl_lines.append(f"\nCOMMENT ON TABLE {table_name} IS '{entity.description}';")

        return "".join(ddl_lines)

    def _generate_column_ddl(self, field: Any) -> str:
        """Generate column DDL for a field."""
        # Map the field type
        type_info = self.type_mapper.map_type(field.type_ir)

        column_name = self._to_snake_case(field.name)
        ddl_parts = [column_name, type_info.ddl_type]

        # Add constraints
        ddl_parts.extend(type_info.constraints)

        return " ".join(ddl_parts)

    def _generate_index_ddl(self, table_name: str, index: Any) -> str:
        """Generate CREATE INDEX DDL."""
        # Placeholder implementation
        return f"CREATE INDEX idx_{table_name}_{index.name} ON {table_name} ({', '.join(index.columns)});"

    def _generate_action_function(self, action: Any) -> str:
        """Generate PL/pgSQL function for an action."""
        function_name = f"{action.entity}_{action.name}"
        param_list = []

        # Add parameters
        if action.params:
            for param in action.params:
                param_list.append(f"p_{param['name']} {param['type']}")

        params_str = ", ".join(param_list) if param_list else ""

        # Start building the function
        sql_lines = [
            f"CREATE OR REPLACE FUNCTION {function_name}({params_str})",
            "RETURNS void AS $$",
            "BEGIN",
        ]

        # Compile each step
        for step in action.steps:
            step_result = self.step_compiler.compile_step(step, {"entity_name": action.entity})
            # Indent the step SQL
            indented_sql = "\n".join(
                f"    {line}" for line in step_result.code.split("\n") if line.strip()
            )
            sql_lines.append(indented_sql)

        sql_lines.extend(["END;", "$$ LANGUAGE plpgsql;"])

        return "\n".join(sql_lines)

    def _generate_view_sql(self, view: Any) -> str:
        """Generate CREATE VIEW SQL."""
        view_name = self._to_snake_case(view.name)

        # Placeholder implementation - in a real implementation,
        # this would build the SELECT statement based on the view definition
        select_sql = "SELECT * FROM some_table"  # Placeholder

        return f"CREATE VIEW {view_name} AS\n{select_sql};"

    def _to_snake_case(self, name: str) -> str:
        """Convert a name to snake_case."""
        import re

        # Insert underscores before uppercase letters and convert to lowercase
        s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
        return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()
