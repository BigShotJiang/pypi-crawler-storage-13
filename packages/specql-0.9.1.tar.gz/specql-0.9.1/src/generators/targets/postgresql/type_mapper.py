"""PostgreSQL-specific type mapping for SpecQL types."""

from typing import Any

from src.core.ir.type_ir import TypeCategory, TypeIR
from src.generators.targets.base.type_mapper import BaseTypeMapper, TypeInfo


class PostgreSQLTypeMapper(BaseTypeMapper):
    """Maps SpecQL types to PostgreSQL database types.

    Provides PostgreSQL-specific type mappings with appropriate constraints,
    defaults, and import requirements for schema generation.
    """

    def map_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map a SpecQL type to PostgreSQL type information.

        Args:
            type_ir: The SpecQL type to map

        Returns:
            TypeInfo with PostgreSQL-specific details
        """
        if type_ir.category == TypeCategory.SCALAR:
            return self._map_scalar_type(type_ir)
        elif type_ir.category == TypeCategory.REFERENCE:
            return self._map_reference_type(type_ir)
        elif type_ir.category == TypeCategory.ENUM:
            return self._map_enum_type(type_ir)
        elif type_ir.category == TypeCategory.LIST:
            return self._map_list_type(type_ir)
        elif type_ir.category == TypeCategory.COMPOSITE:
            return self._map_composite_type(type_ir)
        else:
            raise ValueError(f"Unsupported type category: {type_ir.category}")

    def _map_scalar_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map scalar types to PostgreSQL."""
        return self._get_base_type_mapping(type_ir.base_type)

    def _map_reference_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map reference types to PostgreSQL foreign keys."""
        return TypeInfo(
            target_type="string",
            ddl_type=self.get_reference_type(type_ir.referenced_entity or type_ir.base_type),
            imports=["uuid-ossp"],
            constraints=[],
        )

    def _map_enum_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map enum types to PostgreSQL."""
        return TypeInfo(
            target_type="string",
            ddl_type=self.get_enum_type(type_ir.enum_values),
            imports=[],
            constraints=[],
        )

    def _map_list_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map list types to PostgreSQL arrays."""
        if type_ir.element_type:
            element_info = self.map_type(type_ir.element_type)
            return TypeInfo(
                target_type=f"{element_info.target_type}[]",
                ddl_type=f"{element_info.ddl_type}[]",
                imports=element_info.imports,
                constraints=element_info.constraints,
            )
        else:
            # Default to text array
            return TypeInfo(target_type="string[]", ddl_type="TEXT[]", imports=[], constraints=[])

    def _map_composite_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map composite types to PostgreSQL JSONB."""
        return TypeInfo(target_type="object", ddl_type="JSONB", imports=[], constraints=[])

    def get_reference_type(self, referenced_entity: str) -> str:
        """Get the PostgreSQL type for foreign key references.

        Args:
            referenced_entity: Name of the referenced entity

        Returns:
            PostgreSQL type string for foreign key fields (always UUID)
        """
        return "UUID"

    def get_enum_type(self, enum_values: list[str]) -> str:
        """Get the PostgreSQL type for enum fields.

        Args:
            enum_values: List of allowed enum values

        Returns:
            PostgreSQL enum type name (using custom enum types)
        """
        # For PostgreSQL, we create custom enum types
        # The actual enum type name would be generated based on the field/entity
        # This is a placeholder - the actual implementation would generate
        # CREATE TYPE statements and return the appropriate type name
        return "VARCHAR"  # Fallback for now

    def _get_base_type_mapping(self, base_type: str) -> TypeInfo:
        """Get the base PostgreSQL type mapping for a SpecQL type.

        Args:
            base_type: The SpecQL base type

        Returns:
            TypeInfo for the base type
        """
        mappings = {
            # Scalar types
            "string": TypeInfo(
                target_type="string", ddl_type="VARCHAR", imports=[], constraints=[]
            ),
            "text": TypeInfo(target_type="string", ddl_type="TEXT", imports=[], constraints=[]),
            "integer": TypeInfo(
                target_type="number", ddl_type="INTEGER", imports=[], constraints=[]
            ),
            "bigint": TypeInfo(target_type="number", ddl_type="BIGINT", imports=[], constraints=[]),
            "smallint": TypeInfo(
                target_type="number", ddl_type="SMALLINT", imports=[], constraints=[]
            ),
            "decimal": TypeInfo(
                target_type="number", ddl_type="DECIMAL", imports=[], constraints=[]
            ),
            "float": TypeInfo(target_type="number", ddl_type="REAL", imports=[], constraints=[]),
            "double": TypeInfo(
                target_type="number", ddl_type="DOUBLE PRECISION", imports=[], constraints=[]
            ),
            "boolean": TypeInfo(
                target_type="boolean", ddl_type="BOOLEAN", imports=[], constraints=[]
            ),
            "date": TypeInfo(target_type="Date", ddl_type="DATE", imports=[], constraints=[]),
            "datetime": TypeInfo(
                target_type="Date", ddl_type="TIMESTAMP", imports=[], constraints=[]
            ),
            "timestamp": TypeInfo(
                target_type="Date", ddl_type="TIMESTAMP", imports=[], constraints=[]
            ),
            "time": TypeInfo(target_type="Date", ddl_type="TIME", imports=[], constraints=[]),
            "uuid": TypeInfo(
                target_type="string",
                ddl_type="UUID",
                imports=["uuid-ossp"],  # PostgreSQL extension
                constraints=[],
            ),
            "json": TypeInfo(target_type="object", ddl_type="JSONB", imports=[], constraints=[]),
            "jsonb": TypeInfo(target_type="object", ddl_type="JSONB", imports=[], constraints=[]),
            # Email type (using VARCHAR with CHECK constraint)
            "email": TypeInfo(
                target_type="string",
                ddl_type="VARCHAR",
                imports=[],
                constraints=["email ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'"],
            ),
            # URL type (using VARCHAR with CHECK constraint)
            "url": TypeInfo(
                target_type="string",
                ddl_type="VARCHAR",
                imports=[],
                constraints=["url ~ '^https?://.+'"],
            ),
            # Phone type (using VARCHAR)
            "phone": TypeInfo(target_type="string", ddl_type="VARCHAR", imports=[], constraints=[]),
            # Currency type (using DECIMAL)
            "currency": TypeInfo(
                target_type="number", ddl_type="DECIMAL(15,2)", imports=[], constraints=[]
            ),
            # Percentage type (using DECIMAL with constraints)
            "percentage": TypeInfo(
                target_type="number",
                ddl_type="DECIMAL(5,2)",
                imports=[],
                constraints=["percentage >= 0", "percentage <= 100"],
            ),
        }

        if base_type not in mappings:
            raise ValueError(f"Unsupported type: {base_type}")

        return mappings[base_type]

    def _map_array_type(self, base_info: TypeInfo, type_ir: TypeIR) -> TypeInfo:
        """Map array types to PostgreSQL array syntax.

        Args:
            base_info: Base type information
            type_ir: The type IR

        Returns:
            Updated TypeInfo for array type
        """
        return TypeInfo(
            target_type=f"{base_info.target_type}[]",
            ddl_type=f"{base_info.ddl_type}[]",
            imports=base_info.imports,
            constraints=base_info.constraints,
        )

    def _add_not_null_constraint(self, type_info: TypeInfo) -> TypeInfo:
        """Add NOT NULL constraint to type info.

        Args:
            type_info: Current type information

        Returns:
            Updated TypeInfo with NOT NULL constraint
        """
        return TypeInfo(
            target_type=type_info.target_type,
            ddl_type=type_info.ddl_type,
            imports=type_info.imports,
            constraints=type_info.constraints + ["NOT NULL"],
        )

    def _add_default_value(self, type_info: TypeInfo, type_ir: TypeIR) -> TypeInfo:
        """Add default value to type info.

        Args:
            type_info: Current type information
            type_ir: The type IR with default value

        Returns:
            Updated TypeInfo with default value
        """
        default_sql = self._format_default_value(type_ir.default_value, type_ir.base_type)
        return TypeInfo(
            target_type=type_info.target_type,
            ddl_type=type_info.ddl_type,
            imports=type_info.imports,
            constraints=type_info.constraints + [f"DEFAULT {default_sql}"],
        )

    def _add_constraints(self, type_info: TypeInfo, type_ir: TypeIR) -> TypeInfo:
        """Add custom constraints to type info.

        Args:
            type_info: Current type information
            type_ir: The type IR with constraints

        Returns:
            Updated TypeInfo with additional constraints
        """
        additional_constraints = []
        for constraint in type_ir.constraints:
            if isinstance(constraint, dict):
                # Handle structured constraints
                constraint_sql = self._format_constraint(constraint)
                if constraint_sql:
                    additional_constraints.append(constraint_sql)
            else:
                # Handle string constraints
                additional_constraints.append(str(constraint))

        return TypeInfo(
            target_type=type_info.target_type,
            ddl_type=type_info.ddl_type,
            imports=type_info.imports,
            constraints=type_info.constraints + additional_constraints,
        )

    def _format_default_value(self, value: Any, base_type: str) -> str:
        """Format a default value for PostgreSQL SQL.

        Args:
            value: The default value
            base_type: The base type for context

        Returns:
            SQL-formatted default value
        """
        if isinstance(value, str):
            if base_type == "uuid":
                if value.lower() == "gen_random_uuid()":
                    return "gen_random_uuid()"
                return f"'{value}'"
            elif base_type in ("date", "datetime", "timestamp"):
                if value.upper() == "NOW":
                    return "NOW()"
                return f"'{value}'"
            else:
                return f"'{value}'"
        elif isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        elif value is None:
            return "NULL"
        else:
            return str(value)

    def _format_constraint(self, constraint: dict) -> str:
        """Format a structured constraint for PostgreSQL.

        Args:
            constraint: Constraint dictionary

        Returns:
            SQL constraint string or empty string if unsupported
        """
        constraint_type = constraint.get("type", "").lower()

        if constraint_type == "check":
            expression = constraint.get("expression", "")
            return f"CHECK ({expression})"
        elif constraint_type == "min":
            value = constraint.get("value")
            return f"CHECK (value >= {value})"
        elif constraint_type == "max":
            value = constraint.get("value")
            return f"CHECK (value <= {value})"
        elif constraint_type == "range":
            min_val = constraint.get("min")
            max_val = constraint.get("max")
            return f"CHECK (value >= {min_val} AND value <= {max_val})"
        elif constraint_type == "length":
            max_len = constraint.get("max")
            return f"CHECK (LENGTH(value) <= {max_len})"

        return ""
