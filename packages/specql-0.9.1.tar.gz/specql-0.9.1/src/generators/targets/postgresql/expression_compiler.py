"""PostgreSQL-specific expression compilation."""

from typing import Any

from src.generators.targets.base.step_compiler import BaseExpressionCompiler


class PostgreSQLExpressionCompiler(BaseExpressionCompiler):
    """Compiles SpecQL expressions to PostgreSQL SQL expressions.

    Handles the translation of SpecQL expressions into PostgreSQL-compatible
    SQL expressions that can be used in WHERE clauses, SELECT statements, etc.
    """

    # PostgreSQL operator mappings
    OPERATORS = {
        "=": "=",
        "!=": "<>",
        "AND": "AND",
        "OR": "OR",
        "NOT": "NOT",
        "<=": "<=",
        ">=": ">=",
        "<": "<",
        ">": ">",
        "+": "+",
        "-": "-",
        "*": "*",
        "/": "/",
        "%": "%",
        "||": "||",
    }

    NULL_LITERAL = "NULL"
    TRUE_LITERAL = "TRUE"
    FALSE_LITERAL = "FALSE"
    STRING_QUOTE = "'"

    def _translate_identifier(self, identifier: str) -> str:
        """Translate identifiers to PostgreSQL column syntax."""
        # For simple identifiers, don't quote to maintain backwards compatibility
        # Only quote if contains special characters or is a reserved word
        if any(char in identifier for char in [" ", "-", ".", "/", "\\"]) or identifier.upper() in {
            "SELECT",
            "FROM",
            "WHERE",
            "INSERT",
            "UPDATE",
            "DELETE",
            "CREATE",
            "DROP",
            "ALTER",
            "TABLE",
            "INDEX",
            "VIEW",
            "DATABASE",
            "SCHEMA",
            "COLUMN",
            "CONSTRAINT",
            "PRIMARY",
            "FOREIGN",
            "REFERENCES",
            "UNIQUE",
            "CHECK",
            "DEFAULT",
            "NULL",
            "NOT",
            "AND",
            "OR",
            "ORDER",
            "BY",
            "GROUP",
            "HAVING",
            "LIMIT",
            "OFFSET",
            "JOIN",
            "INNER",
            "LEFT",
            "RIGHT",
            "FULL",
            "OUTER",
            "ON",
            "USING",
            "AS",
            "DISTINCT",
            "ALL",
            "ANY",
            "SOME",
            "EXISTS",
            "IN",
            "BETWEEN",
            "LIKE",
            "ILIKE",
            "SIMILAR",
            "TO",
            "CASE",
            "WHEN",
            "THEN",
            "ELSE",
            "END",
            "UNION",
            "INTERSECT",
            "EXCEPT",
            "WITH",
            "RECURSIVE",
            "VALUES",
            "RETURNING",
        }:
            return f'"{identifier}"'
        return identifier

    def _translate_field_reference(self, field_ref: str) -> str:
        """Translate field references to PostgreSQL table.column syntax."""
        parts = field_ref.split(".")
        if len(parts) == 2:
            table, column = parts
            return f'"{table}"."{column}"'
        elif len(parts) > 2:
            # Handle schema.table.column
            schema, table, column = parts[:3]
            return f'"{schema}"."{table}"."{column}"'
        else:
            return f'"{field_ref}"'

    def compile_expression(self, expression: str, context: dict[str, Any]) -> str:
        """Compile a SpecQL expression to PostgreSQL SQL.

        Args:
            expression: The SpecQL expression string
            context: Compilation context (variables, entity info, etc.)

        Returns:
            PostgreSQL SQL expression string
        """
        # Use the new template method
        result = self.compile(expression, context)

        # Apply additional PostgreSQL-specific transformations
        code = result.code
        code = self._replace_functions(code)
        code = self._replace_variables(code, context)

        return code

    def _replace_functions(self, expression: str) -> str:
        """Replace SpecQL functions with PostgreSQL functions."""
        replacements = {
            "NOW()": "NOW()",
            "TODAY()": "CURRENT_DATE",
            "LEN(": "LENGTH(",
            "CONTAINS(": "POSITION(",
        }

        for specql_func, sql_func in replacements.items():
            expression = expression.replace(specql_func, sql_func)

        return expression

    def _replace_variables(self, expression: str, context: dict[str, Any]) -> str:
        """Replace variables in the expression using context."""
        # Simple variable replacement - in a real implementation,
        # this would be more sophisticated
        for var_name, var_value in context.items():
            if isinstance(var_value, str):
                expression = expression.replace(f"${var_name}", f"'{var_value}'")
            else:
                expression = expression.replace(f"${var_name}", str(var_value))

        return expression

    def supports_operator(self, operator: str) -> bool:
        """Check if PostgreSQL supports a specific operator."""
        # PostgreSQL supports all the base operators plus some extras
        postgresql_operators = {
            "AND",
            "OR",
            "NOT",
            "=",
            "!=",
            "<",
            ">",
            "<=",
            ">=",
            "+",
            "-",
            "*",
            "/",
            "%",  # Arithmetic
            "||",  # String concatenation
            "LIKE",
            "ILIKE",
            "SIMILAR TO",  # Pattern matching
            "IS",
            "IS NOT",  # Null checking
            "IN",
            "NOT IN",  # Set membership
            "BETWEEN",
            "NOT BETWEEN",  # Range checking
            "@>",
            "<@",
            "&&",
            "<<",
            ">>",
            "&<",
            "&>",
            "<<|",
            "|>>",
            "&<|",
            "|&>",
            "<->",  # Geometric operators
        }

        return operator.upper() in postgresql_operators

    def get_operator_mapping(self, operator: str) -> str:
        """Get PostgreSQL-specific operator mapping."""
        return self.OPERATORS.get(operator.upper(), operator)
