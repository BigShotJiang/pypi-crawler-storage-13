"""PostgreSQL-specific action step compilation."""

from typing import TYPE_CHECKING

from src.generators.laravel.utils import to_snake_case
from src.generators.targets.base.interfaces import StepCompilationResult
from src.generators.targets.base.step_compiler import BaseStepCompiler
from src.generators.targets.postgresql.expression_compiler import PostgreSQLExpressionCompiler

if TYPE_CHECKING:
    from src.core.ir.action_ir import ActionStepIR


class PostgreSQLStepCompiler(BaseStepCompiler):
    """Compiles SpecQL action steps to PostgreSQL SQL statements.

    Handles the translation of SpecQL action steps (validate, update, insert, etc.)
    into PostgreSQL-specific SQL code that can be executed in stored procedures
    or application code.
    """

    def __init__(self):
        """Initialize the PostgreSQL step compiler with an expression compiler."""
        super().__init__(PostgreSQLExpressionCompiler())

        # Add PL/pgSQL native step handlers (for round-trip fidelity)
        self._handlers["declare"] = self._compile_declare  # type: ignore
        self._handlers["assign"] = self._compile_assign  # type: ignore
        self._handlers["query"] = self._compile_query  # type: ignore
        self._handlers["cte"] = self._compile_cte  # type: ignore
        self._handlers["return"] = self._compile_return  # type: ignore
        self._handlers["return_table"] = self._compile_return_table  # type: ignore
        self._handlers["for_query"] = self._compile_for_query  # type: ignore

    def _compile_validate(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a validate step to PostgreSQL validation logic.

        Validate steps check conditions and raise exceptions if they fail.
        """
        if not step.expression:
            raise ValueError("Validate step must have an expression")

        condition = self.compile_condition(step.expression, ctx)
        error_message = "Validation failed"  # Default error message

        code = f"""
        IF NOT {condition} THEN
            RAISE EXCEPTION '{error_message}';
        END IF;
        """.strip()

        return StepCompilationResult(code=code)

    def _compile_update(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile an update step to PostgreSQL UPDATE statement."""
        if not step.fields:
            raise ValueError("Update step must have fields to update")

        table_name = self._get_table_name(step, ctx)
        update_data = self._compile_update_data(step.fields, ctx)
        where_clause = self._compile_where_clause(step, ctx)

        code = f"UPDATE {table_name} SET {update_data}{where_clause};"

        return StepCompilationResult(code=code)

    def _compile_insert(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile an insert step to PostgreSQL INSERT statement."""
        if not step.fields:
            raise ValueError("Insert step must have fields to insert")

        table_name = self._get_table_name(step, ctx)
        insert_data = self._compile_insert_data(step.fields, ctx)

        code = f"INSERT INTO {table_name} {insert_data};"

        return StepCompilationResult(code=code)

    def _compile_if(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile an if step to PostgreSQL IF statement."""
        if not step.condition:
            raise ValueError("If step must have a condition")

        condition = self.compile_condition(step.condition, ctx)

        # Compile the then branch using base class helper
        then_result = self._compile_nested_steps(step.then_steps or [], ctx)

        # Compile the else branch
        else_result = None
        if step.else_steps:
            else_result = self._compile_nested_steps(step.else_steps, ctx)

        code = f"IF {condition} THEN\n{then_result.code}\nEND IF;"
        if else_result:
            code = code.replace("END IF;", f"ELSE\n{else_result.code}\nEND IF;")

        # Merge imports and variables from both branches
        imports = then_result.imports
        variables = then_result.variables.copy()
        if else_result:
            imports = imports | else_result.imports
            variables.update(else_result.variables)

        return StepCompilationResult(code=code, imports=imports, variables=variables)

    def _compile_call(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a call step to PostgreSQL function call."""
        if not step.function_name:
            raise ValueError("Call step must have a function name")

        function_name = step.function_name
        args = self._compile_function_args(step.function_args, ctx)

        code = f"PERFORM {function_name}({args});"
        return StepCompilationResult(code=code)

    def _compile_notify(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a notify step to PostgreSQL NOTIFY statement."""
        # For PostgreSQL, we'll use NOTIFY for notifications
        channel = "specql_notification"  # Default channel
        payload = "'notification'"  # Default payload

        code = f"NOTIFY {channel}, {payload};"
        return StepCompilationResult(code=code)

    def _compile_foreach(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile a foreach step to PostgreSQL loop."""
        if not step.collection or not step.item_name:
            raise ValueError("Foreach step must have collection and item_name")

        collection_expr = self.expression_compiler.compile_expression(step.collection, ctx)
        item_var = step.item_name

        # Compile the loop body using base class helper
        loop_ctx = ctx.copy()
        loop_ctx[step.item_name] = item_var
        loop_result = self._compile_nested_steps(step.loop_steps or [], loop_ctx)

        code = f"""
        FOREACH {item_var} IN ARRAY {collection_expr} LOOP
        {loop_result.code}
        END LOOP;
        """.strip()

        return StepCompilationResult(
            code=code, imports=loop_result.imports, variables=loop_result.variables
        )

    def _get_table_name(self, step: "ActionStepIR", ctx: dict) -> str:
        """Get the table name for a step."""
        entity_name = step.target_entity or ctx.get("entity_name")
        if not entity_name:
            raise ValueError(
                "Cannot determine table name: no target_entity or entity_name in context"
            )

        return to_snake_case(entity_name)

    def _compile_update_data(self, fields: dict, ctx: dict) -> str:
        """Compile the SET clause for PostgreSQL UPDATE."""
        assignments = []
        for field_name, field_value in fields.items():
            if isinstance(field_value, str):
                # Assume it's an expression
                compiled_value = self.expression_compiler.compile_expression(field_value, ctx)
            else:
                # Assume it's a literal value
                compiled_value = self._format_literal_value(field_value)

            assignments.append(f"{field_name} = {compiled_value}")

        return ", ".join(assignments)

    def _compile_where_clause(self, step: "ActionStepIR", ctx: dict) -> str:
        """Compile the WHERE clause for PostgreSQL queries."""
        # ActionStepIR doesn't have where_condition or target_id fields
        # In a real implementation, these would be added or passed via context
        # For now, return empty string (no WHERE clause)
        return ""

    def _compile_insert_data(self, fields: dict, ctx: dict) -> str:
        """Compile the VALUES clause for PostgreSQL INSERT."""
        columns = []
        values = []

        for field_name, field_value in fields.items():
            columns.append(field_name)
            if isinstance(field_value, str):
                # Assume it's an expression
                compiled_value = self.expression_compiler.compile_expression(field_value, ctx)
            else:
                # Assume it's a literal value
                compiled_value = self._format_literal_value(field_value)
            values.append(compiled_value)

        columns_str = ", ".join(columns)
        values_str = ", ".join(values)

        return f"({columns_str}) VALUES ({values_str})"

    def _compile_function_args(self, args: list, ctx: dict) -> str:
        """Compile function arguments."""
        compiled_args = []
        for arg in args:
            if isinstance(arg, str):
                compiled_args.append(self.expression_compiler.compile_expression(arg, ctx))
            else:
                compiled_args.append(self._format_literal_value(arg))

        return ", ".join(compiled_args)

    def _format_literal_value(self, value) -> str:
        """Format a literal value for PostgreSQL."""
        if isinstance(value, str):
            # Escape single quotes in the string
            escaped_value = value.replace("'", "''")
            return f"'{escaped_value}'"
        elif isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        elif value is None:
            return "NULL"
        else:
            return str(value)

    # Legacy PL/pgSQL step compilation methods (for round-trip fidelity)

    def _compile_declare(self, step: "ActionStepIR", ctx: dict) -> "StepCompilationResult":
        """Compile declare step to PL/pgSQL DECLARE statement."""
        var_name = getattr(step, "variable_name", "v_unnamed")
        var_type = getattr(step, "variable_type", "TEXT")
        default = getattr(step, "default_value", None)

        if default is not None:
            declaration = f"{var_name} {var_type} := {default};"
        else:
            declaration = f"{var_name} {var_type};"

        return StepCompilationResult(code=declaration)

    def _compile_assign(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile assign step to PL/pgSQL assignment statement."""
        var_name = getattr(step, "variable_name", "v_unnamed")
        expression = getattr(step, "expression", "NULL")

        return StepCompilationResult(code=f"{var_name} := {expression};")

    def _compile_query(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile query step to PL/pgSQL."""
        sql = getattr(step, "sql", "")
        store_result = getattr(step, "store_result", None)

        if store_result:
            # SELECT INTO pattern
            if "INTO" not in sql.upper():
                # Insert INTO clause after SELECT
                sql_upper = sql.upper()
                if sql_upper.startswith("SELECT"):
                    # Find the FROM or first column to insert INTO before
                    # Simple approach: add INTO right after SELECT
                    sql = sql.replace("SELECT", f"SELECT INTO {store_result}", 1)
                else:
                    # For other queries, execute and store
                    return StepCompilationResult(code=f"EXECUTE '{sql}' INTO {store_result};")

        return StepCompilationResult(code=f"{sql};")

    def _compile_cte(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile CTE step to PL/pgSQL WITH clause."""
        cte_name = getattr(step, "cte_name", "cte")
        cte_query = getattr(step, "cte_query", "SELECT 1")

        cte_sql = f"WITH {cte_name} AS (\n    {cte_query}\n)"

        # For standalone CTE, add a SELECT from it
        cte_sql += f"\nSELECT * FROM {cte_name};"

        return StepCompilationResult(code=cte_sql)

    def _compile_return(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile return step to PL/pgSQL RETURN statement."""
        return_value = getattr(step, "return_value", None)

        if return_value:
            return StepCompilationResult(code=f"RETURN {return_value};")
        else:
            return StepCompilationResult(code="RETURN;")

    def _compile_return_table(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile return_table step to PL/pgSQL RETURN QUERY statement."""
        query = getattr(step, "return_table_query", "SELECT NULL")

        return StepCompilationResult(code=f"RETURN QUERY {query};")

    def _compile_for_query(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile for_query step to PL/pgSQL FOR loop."""
        alias = getattr(step, "for_query_alias", "rec")
        query = getattr(step, "for_query_sql", "SELECT 1")
        body_steps = getattr(step, "for_query_body", [])

        lines = [f"FOR {alias} IN {query}"]
        lines.append("LOOP")

        # Compile body steps
        for body_step in body_steps:
            if hasattr(body_step, "step_type"):
                # If it's an ActionStepIR, compile recursively
                body_result = self.compile_step(body_step, ctx)
                body_sql = f"    {body_result.code}"
            else:
                # Fallback: just note the step type
                body_sql = f"    -- {getattr(body_step, 'type', 'unknown')} step"

            lines.append(body_sql)

        lines.append("END LOOP;")

        return StepCompilationResult(code="\n".join(lines))
