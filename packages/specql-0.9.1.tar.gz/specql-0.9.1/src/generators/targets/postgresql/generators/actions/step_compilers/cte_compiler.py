"""Compiler for CTE steps - Common Table Expressions."""

from typing import Optional
from core.ast_models import ActionStep


class CTEStepCompiler:
    """Compile CTE steps to PL/pgSQL WITH clauses."""

    def compile(self, step: ActionStep, main_query: Optional[str] = None) -> str:
        """
        Compile a CTE step to PL/pgSQL.

        Args:
            step: ActionStep with type="cte"
            main_query: Optional main query to combine with CTE

        Returns:
            PL/pgSQL WITH statement
        """
        cte_name = step.cte_name or "cte"
        cte_query = step.cte_query or "SELECT 1"

        cte_sql = f"WITH {cte_name} AS (\n    {cte_query}\n)"

        if main_query:
            return f"{cte_sql}\n{main_query};"
        else:
            # Standalone CTE needs a SELECT from it
            return f"{cte_sql}\nSELECT * FROM {cte_name};"
