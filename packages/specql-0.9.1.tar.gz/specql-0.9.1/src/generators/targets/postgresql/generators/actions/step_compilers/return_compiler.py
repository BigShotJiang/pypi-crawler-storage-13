"""Compiler for return steps."""

from core.ast_models import ActionStep


class ReturnStepCompiler:
    """Compile return steps to PL/pgSQL RETURN statements."""

    def compile(self, step: ActionStep) -> str:
        """
        Compile a return step to PL/pgSQL.

        Args:
            step: ActionStep with type="return"

        Returns:
            PL/pgSQL RETURN statement
        """
        return_value = step.return_value

        if return_value:
            return f"RETURN {return_value};"
        else:
            return "RETURN;"


class ReturnTableStepCompiler:
    """Compile return_table steps to PL/pgSQL RETURN QUERY statements."""

    def compile(self, step: ActionStep) -> str:
        """
        Compile a return_table step to PL/pgSQL.

        Args:
            step: ActionStep with type="return_table"

        Returns:
            PL/pgSQL RETURN QUERY statement
        """
        query = step.return_table_query or "SELECT NULL"

        return f"RETURN QUERY {query};"
