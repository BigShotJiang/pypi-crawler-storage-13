"""Compiler for declare steps - variable declarations."""

from dataclasses import dataclass

from core.ast_models import ActionStep


@dataclass
class DeclareCompileResult:
    """Result of compiling a declare step."""

    declaration: str  # Goes in DECLARE section
    variable_name: str
    variable_type: str


class DeclareStepCompiler:
    """Compile declare steps to PL/pgSQL DECLARE statements."""

    def compile(self, step: ActionStep) -> DeclareCompileResult:
        """
        Compile a declare step to PL/pgSQL.

        Args:
            step: ActionStep with type="declare"

        Returns:
            DeclareCompileResult with the declaration SQL
        """
        var_name = step.variable_name or "v_unnamed"
        var_type = step.variable_type or "TEXT"
        default = step.default_value

        if default is not None:
            declaration = f"{var_name} {var_type} := {default};"
        else:
            declaration = f"{var_name} {var_type};"

        return DeclareCompileResult(
            declaration=declaration,
            variable_name=var_name,
            variable_type=var_type,
        )
