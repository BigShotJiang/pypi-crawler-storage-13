"""Compiler for assign steps - variable assignments."""

from core.ast_models import ActionStep


class AssignStepCompiler:
    """Compile assign steps to PL/pgSQL assignment statements."""

    def compile(self, step: ActionStep) -> str:
        """
        Compile an assign step to PL/pgSQL.

        Args:
            step: ActionStep with type="assign"

        Returns:
            PL/pgSQL assignment statement
        """
        var_name = step.variable_name or "v_unnamed"
        expression = step.expression or "NULL"

        return f"{var_name} := {expression};"
