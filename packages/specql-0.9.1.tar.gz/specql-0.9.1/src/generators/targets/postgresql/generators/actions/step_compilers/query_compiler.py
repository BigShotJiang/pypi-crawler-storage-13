"""Compiler for query steps - raw SQL queries."""

from core.ast_models import ActionStep


class QueryStepCompiler:
    """Compile query steps to PL/pgSQL."""

    def compile(self, step: ActionStep) -> str:
        """
        Compile a query step to PL/pgSQL.

        Args:
            step: ActionStep with type="query"

        Returns:
            PL/pgSQL query statement
        """
        sql = step.sql or ""
        store_result = step.store_result

        if store_result:
            # SELECT INTO pattern
            if "INTO" not in sql.upper():
                # Insert INTO clause after SELECT
                sql_upper = sql.upper()
                if sql_upper.startswith("SELECT"):
                    # Find the FROM or first column to insert INTO before
                    # Simple approach: add INTO right after SELECT
                    sql = sql.replace("SELECT", f"SELECT INTO {store_result}", 1)
                else:
                    # For other queries, execute and store
                    return f"EXECUTE '{sql}' INTO {store_result};"

        return f"{sql};"
