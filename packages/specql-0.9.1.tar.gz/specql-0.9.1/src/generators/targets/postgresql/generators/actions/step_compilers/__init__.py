"""
Step Compilers for Action Compilation

This package contains compilers for individual action step types.

SpecQL DSL Steps (business-level abstractions):
- validate: Validation logic
- update: UPDATE statements
- insert: INSERT statements
- delete: Soft delete (UPDATE deleted_at)
- if: Conditional logic
- foreach: Loop over collections
- call: Function calls
- notify: PostgreSQL NOTIFY
- refresh_table_view: Table view refresh

PL/pgSQL Native Steps (preserved for round-trip fidelity):
- declare: Variable declarations
- assign: Variable assignments
- query: Raw SQL queries
- cte: Common Table Expressions
- return: Return statements
- return_table: Return query results
- for_query: FOR ... IN query loops
"""

from .call_compiler import CallStepCompiler
from .delete_compiler import DeleteStepCompiler
from .foreach_compiler import ForEachStepCompiler
from .if_compiler import IfStepCompiler
from .insert_compiler import InsertStepCompiler
from .notify_compiler import NotifyStepCompiler
from .refresh_table_view_compiler import RefreshTableViewStepCompiler
from .update_compiler import UpdateStepCompiler
from .validate_compiler import ValidateStepCompiler

# PL/pgSQL native step compilers (preserved for round-trip fidelity)
from .declare_compiler import DeclareStepCompiler
from .assign_compiler import AssignStepCompiler
from .query_compiler import QueryStepCompiler
from .cte_compiler import CTEStepCompiler
from .return_compiler import ReturnStepCompiler, ReturnTableStepCompiler
from .for_query_compiler import ForQueryStepCompiler

__all__ = [
    # SpecQL DSL Steps (business-level abstractions)
    "ValidateStepCompiler",
    "UpdateStepCompiler",
    "InsertStepCompiler",
    "DeleteStepCompiler",
    "IfStepCompiler",
    "ForEachStepCompiler",
    "CallStepCompiler",
    "NotifyStepCompiler",
    "RefreshTableViewStepCompiler",
    # PL/pgSQL Native Steps (preserved for round-trip fidelity)
    "DeclareStepCompiler",
    "AssignStepCompiler",
    "QueryStepCompiler",
    "CTEStepCompiler",
    "ReturnStepCompiler",
    "ReturnTableStepCompiler",
    "ForQueryStepCompiler",
]
