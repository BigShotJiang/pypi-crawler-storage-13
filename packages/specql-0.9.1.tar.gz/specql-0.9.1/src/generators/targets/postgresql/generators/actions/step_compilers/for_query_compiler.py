"""Compiler for for_query steps - FOR ... IN query LOOP."""

from core.ast_models import ActionStep


class ForQueryStepCompiler:
    """Compile for_query steps to PL/pgSQL FOR loops."""

    def __init__(self, step_compiler_registry=None):
        """
        Initialize with optional step compiler registry for nested steps.

        Args:
            step_compiler_registry: Registry to compile nested body steps
        """
        self.step_compiler_registry = step_compiler_registry

    def compile(self, step: ActionStep, indent: int = 0) -> str:
        """
        Compile a for_query step to PL/pgSQL.

        Args:
            step: ActionStep with type="for_query"
            indent: Indentation level for nested code

        Returns:
            PL/pgSQL FOR loop statement
        """
        alias = step.for_query_alias or "rec"
        query = step.for_query_sql or "SELECT 1"
        body_steps = step.for_query_body or []

        indent_str = "    " * indent
        body_indent = "    " * (indent + 1)

        lines = [f"{indent_str}FOR {alias} IN {query}"]
        lines.append(f"{indent_str}LOOP")

        # Compile body steps
        for body_step in body_steps:
            if self.step_compiler_registry:
                body_sql = self.step_compiler_registry.compile_step(body_step, indent + 1)
                lines.append(f"{body_indent}{body_sql}")
            else:
                # Fallback: just note the step type
                lines.append(f"{body_indent}-- {body_step.type} step")

        lines.append(f"{indent_str}END LOOP;")

        return "\n".join(lines)
