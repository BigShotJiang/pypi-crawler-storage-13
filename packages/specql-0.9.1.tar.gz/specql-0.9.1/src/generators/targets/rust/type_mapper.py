"""Rust type mapping from TypeIR."""

from src.core.ir import TypeIR, TypeCategory
from src.generators.targets.base.type_mapper import BaseTypeMapper, TypeInfo


class RustTypeMapper(BaseTypeMapper):
    """Maps TypeIR to Rust/Diesel types."""

    RUST_TYPE_MAPPINGS = {
        "text": ("String", "Text"),
        "varchar": ("String", "Varchar"),
        "integer": ("i32", "Int4"),
        "bigint": ("i64", "Int8"),
        "boolean": ("bool", "Bool"),
        "uuid": ("Uuid", "Uuid"),
        "timestamp": ("NaiveDateTime", "Timestamp"),
        "date": ("NaiveDate", "Date"),
        "decimal": ("BigDecimal", "Numeric"),
        "float": ("f64", "Float8"),
        "json": ("serde_json::Value", "Jsonb"),
        "jsonb": ("serde_json::Value", "Jsonb"),
    }

    def map_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map TypeIR to Rust type information."""
        if type_ir.category == TypeCategory.SCALAR:
            rust_type, diesel_type = self.RUST_TYPE_MAPPINGS.get(
                type_ir.base_type, ("String", "Text")
            )

            imports = []
            if type_ir.base_type == "uuid":
                imports.append("use uuid::Uuid;")
            elif type_ir.base_type in ["timestamp", "date"]:
                imports.append("use chrono::NaiveDateTime;")
                imports.append("use chrono::NaiveDate;")
            elif type_ir.base_type == "decimal":
                imports.append("use bigdecimal::BigDecimal;")

            # Note: nullability would be handled at field level, not type level

            return TypeInfo(target_type=rust_type, ddl_type=diesel_type, imports=imports)

        if type_ir.category == TypeCategory.REFERENCE:
            entity_name = type_ir.referenced_entity or "UnknownEntity"
            return TypeInfo(
                target_type=f"Uuid",  # Foreign keys are typically UUIDs
                ddl_type=f"Uuid REFERENCES {entity_name.lower()}(id)",
                imports=["use uuid::Uuid;"],
            )

        if type_ir.category == TypeCategory.ENUM:
            return TypeInfo(
                target_type="String",  # Enums stored as strings
                ddl_type="Varchar",
                imports=[],
            )

        if type_ir.category == TypeCategory.LIST:
            return TypeInfo(
                target_type="serde_json::Value",
                ddl_type="Jsonb",
                imports=["use serde_json::Value;"],
            )

        return TypeInfo(target_type="String", ddl_type="Text", imports=[])

    def get_reference_type(self, referenced_entity: str) -> str:
        """Get the target type for foreign key references."""
        return "Uuid"

    def get_enum_type(self, enum_values: list[str]) -> str:
        """Get the target type for enum fields."""
        return "String"
