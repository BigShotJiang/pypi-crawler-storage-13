"""Rust expression compiler."""

from src.generators.targets.base.step_compiler import BaseExpressionCompiler


class RustExpressionCompiler(BaseExpressionCompiler):
    """Compiles SpecQL expressions to Rust."""

    OPERATORS = {
        "=": "==",
        "!=": "!=",
        "AND": "&&",
        "OR": "||",
        "NOT": "!",
        "<": "<",
        ">": ">",
        "<=": "<=",
        ">=": ">=",
    }

    NULL_LITERAL = "None"
    TRUE_LITERAL = "true"
    FALSE_LITERAL = "false"
    STRING_QUOTE = '"'

    def _translate_identifier(self, identifier: str) -> str:
        """Rust uses bare identifiers."""
        return identifier

    def _translate_field_reference(self, field_ref: str) -> str:
        """Translate entity.field to Rust field access."""
        parts = field_ref.split(".")
        if len(parts) == 2:
            return f"{parts[0].lower()}.{parts[1]}"
        return field_ref
