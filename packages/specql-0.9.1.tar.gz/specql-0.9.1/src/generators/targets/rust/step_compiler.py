"""Rust step compiler."""

from typing import TYPE_CHECKING

from src.generators.targets.base.interfaces import StepCompilationResult
from src.generators.targets.base.step_compiler import BaseStepCompiler
from src.generators.targets.rust.expression_compiler import RustExpressionCompiler

if TYPE_CHECKING:
    from src.core.ir.action_ir import ActionStepIR


class RustStepCompiler(BaseStepCompiler):
    """Compiles SpecQL action steps to Rust/Diesel code."""

    def __init__(self):
        super().__init__(RustExpressionCompiler())

    def _compile_validate(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        condition = self.compile_condition(step.expression, ctx)
        code = f"""if !({condition}) {{
    return Err(anyhow::anyhow!("Validation failed"));
}}"""
        return StepCompilationResult(code=code, imports={"use anyhow::Result;"})

    def _compile_update(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        model = step.target_entity
        fields = ", ".join(f"{k}: {v}" for k, v in (step.fields or {}).items())
        code = f"""diesel::update({model}::table.filter({model}::id.eq(&id)))
    .set(({fields}))
    .execute(&mut conn)?;"""
        return StepCompilationResult(code=code)

    def _compile_insert(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        model = step.target_entity
        fields = ", ".join(f"{k}: {v}" for k, v in (step.fields or {}).items())
        code = f"""let new_record = New{model} {{
    {fields}
}};
diesel::insert_into({model}::table)
    .values(&new_record)
    .execute(&mut conn)?;"""
        return StepCompilationResult(code=code)

    def _compile_if(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        condition = self.compile_condition(step.condition, ctx)
        then_result = self._compile_nested_steps(step.then_steps or [], ctx)

        code = f"if {condition} {{\n"
        # Indent the then block
        for line in then_result.code.split("\n"):
            code += f"    {line}\n"
        code += "}\n"

        if step.else_steps:
            else_result = self._compile_nested_steps(step.else_steps, ctx)
            code += "else {\n"
            for line in else_result.code.split("\n"):
                code += f"    {line}\n"
            code += "}\n"

        return StepCompilationResult(code=code.rstrip(), imports=then_result.imports)

    def _compile_call(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        args = ", ".join(str(a) for a in (step.function_args or []))
        code = f"{step.function_name}({args})?;"
        return StepCompilationResult(code=code)

    def _compile_notify(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        code = f"// TODO: Implement notification: {step.expression}"
        return StepCompilationResult(code=code)

    def _compile_foreach(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        collection = step.collection
        item = step.item_name
        loop_result = self._compile_nested_steps(step.loop_steps or [], ctx)

        code = f"for {item} in {collection} {{\n"
        for line in loop_result.code.split("\n"):
            code += f"    {line}\n"
        code += "}\n"

        return StepCompilationResult(code=code.rstrip(), imports=loop_result.imports)
