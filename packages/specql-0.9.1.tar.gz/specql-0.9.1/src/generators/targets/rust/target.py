"""Rust/Diesel target for SpecQL code generation."""

from typing import TYPE_CHECKING

from src.generators.targets.base.registry import register_target
from src.generators.targets.base.target import BaseTarget, GeneratedFile, GenerationResult
from src.generators.targets.rust.type_mapper import RustTypeMapper
from src.generators.targets.rust.step_compiler import RustStepCompiler

if TYPE_CHECKING:
    from src.core.ir import EntityIR


@register_target("rust")
class RustTarget(BaseTarget):
    """Rust/Diesel code generation target."""

    def __init__(self):
        self.type_mapper = RustTypeMapper()
        self.step_compiler = RustStepCompiler()

    @property
    def name(self) -> str:
        return "rust"

    @property
    def supported_languages(self) -> list[str]:
        return ["rust"]

    def generate(self, entity_ir: "EntityIR") -> GenerationResult:
        """Generate Rust/Diesel code for an EntityIR."""
        files: list[GeneratedFile] = []

        # Generate model
        model_content = self._generate_model(entity_ir)
        files.append(
            GeneratedFile(
                path=f"src/models/{entity_ir.name.lower()}.rs",
                content=model_content,
                language="rust",
            )
        )

        # Generate schema
        schema_content = self._generate_schema(entity_ir)
        files.append(
            GeneratedFile(
                path=f"src/schema/{entity_ir.name.lower()}.rs",
                content=schema_content,
                language="rust",
            )
        )

        return GenerationResult(success=True, files=files, target_name=self.name)

    def _generate_model(self, entity_ir: "EntityIR") -> str:
        """Generate Diesel model."""
        snake_name = self._to_snake_case(entity_ir.name)

        lines = [
            "use diesel::prelude::*;",
            "use serde::{Deserialize, Serialize};",
            "use uuid::Uuid;",
            "use chrono::NaiveDateTime;",
            "",
            f"use crate::schema::{snake_name};",
            "",
            "#[derive(Queryable, Selectable, Serialize, Debug)]",
            f"#[diesel(table_name = {snake_name})]",
            f"pub struct {entity_ir.name} {{",
            "    pub id: Uuid,",
        ]

        for field in entity_ir.fields:
            rust_type = self._map_type(field)
            lines.append(f"    pub {field.name}: {rust_type},")

        lines.extend(
            [
                "    pub created_at: NaiveDateTime,",
                "    pub updated_at: NaiveDateTime,",
                "}",
                "",
                "#[derive(Insertable, Deserialize, Debug)]",
                f"#[diesel(table_name = {snake_name})]",
                f"pub struct New{entity_ir.name} {{",
            ]
        )

        for field in entity_ir.fields:
            rust_type = self._map_type(field)
            lines.append(f"    pub {field.name}: {rust_type},")

        lines.append("}")

        return "\n".join(lines)

    def _generate_schema(self, entity_ir: "EntityIR") -> str:
        """Generate Diesel schema."""
        snake_name = self._to_snake_case(entity_ir.name)
        table_name = entity_ir.default_table_name

        lines = [
            "diesel::table! {",
            f"    {table_name} ({snake_name}_id) {{",
            f"        {snake_name}_id -> Uuid,",
        ]

        for field in entity_ir.fields:
            diesel_type = self._map_diesel_type(field)
            lines.append(f"        {field.name} -> {diesel_type},")

        lines.extend(
            [
                "        created_at -> Timestamp,",
                "        updated_at -> Timestamp,",
                "    }",
                "}",
            ]
        )

        return "\n".join(lines)

    def _map_type(self, field) -> str:
        """Map field to Rust type."""
        base_type = self.type_mapper.map_type(field.type_ir).target_type
        if field.nullable:
            return f"Option<{base_type}>"
        return base_type

    def _map_diesel_type(self, field) -> str:
        """Map field to Diesel type."""
        return self.type_mapper.map_type(field.type_ir).ddl_type

    def _to_snake_case(self, name: str) -> str:
        """Convert PascalCase to snake_case."""
        import re

        s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
        return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()
