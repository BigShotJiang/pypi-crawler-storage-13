"""Go/GORM target for SpecQL code generation."""

from typing import TYPE_CHECKING

from src.generators.targets.base.registry import register_target
from src.generators.targets.base.target import BaseTarget, GeneratedFile, GenerationResult
from src.generators.targets.go.type_mapper import GoTypeMapper
from src.generators.targets.go.step_compiler import GoStepCompiler

if TYPE_CHECKING:
    from src.core.ir import EntityIR


@register_target("go")
class GoTarget(BaseTarget):
    """Go/GORM code generation target."""

    def __init__(self):
        self.type_mapper = GoTypeMapper()
        self.step_compiler = GoStepCompiler()

    @property
    def name(self) -> str:
        return "go"

    @property
    def supported_languages(self) -> list[str]:
        return ["go"]

    def generate(self, entity_ir: "EntityIR") -> GenerationResult:
        """Generate Go/GORM code for an EntityIR."""
        files: list[GeneratedFile] = []

        # Generate model
        model_content = self._generate_model(entity_ir)
        files.append(
            GeneratedFile(
                path=f"internal/models/{entity_ir.name.lower()}.go",
                content=model_content,
                language="go",
            )
        )

        # Generate repository
        repo_content = self._generate_repository(entity_ir)
        files.append(
            GeneratedFile(
                path=f"internal/repository/{entity_ir.name.lower()}_repository.go",
                content=repo_content,
                language="go",
            )
        )

        return GenerationResult(success=True, files=files, target_name=self.name)

    def _generate_model(self, entity_ir: "EntityIR") -> str:
        """Generate GORM model."""
        lines = [
            "package models",
            "",
            "import (",
            '    "time"',
            '    "github.com/google/uuid"',
            ")",
            "",
            f"// {entity_ir.name} represents the {entity_ir.name.lower()} entity.",
            f"type {entity_ir.name} struct {{",
            f'    ID        uuid.UUID `gorm:"type:uuid;primaryKey" json:"id"`',
        ]

        for field in entity_ir.fields:
            go_type = self._map_type(field)
            json_name = self._to_snake_case(field.name)
            gorm_tag = self._get_gorm_tag(field)
            lines.append(
                f"    {self._to_pascal_case(field.name)} {go_type} "
                f'`gorm:"{gorm_tag}" json:"{json_name}"`'
            )

        lines.extend(
            [
                '    CreatedAt time.Time `gorm:"autoCreateTime" json:"created_at"`',
                '    UpdatedAt time.Time `gorm:"autoUpdateTime" json:"updated_at"`',
                "}",
                "",
                f"// TableName returns the table name for {entity_ir.name}.",
                f"func ({entity_ir.name}) TableName() string {{",
                f'    return "{entity_ir.default_table_name}"',
                "}",
            ]
        )

        return "\n".join(lines)

    def _generate_repository(self, entity_ir: "EntityIR") -> str:
        """Generate repository pattern implementation."""
        name = entity_ir.name
        lower_name = name.lower()

        return f"""package repository

import (
    "context"
    "github.com/google/uuid"
    "gorm.io/gorm"
    "yourapp/internal/models"
)

// {name}Repository handles {lower_name} data operations.
type {name}Repository struct {{
    db *gorm.DB
}}

// New{name}Repository creates a new repository instance.
func New{name}Repository(db *gorm.DB) *{name}Repository {{
    return &{name}Repository{{db: db}}
}}

// Create inserts a new {lower_name}.
func (r *{name}Repository) Create(ctx context.Context, entity *models.{name}) error {{
    return r.db.WithContext(ctx).Create(entity).Error
}}

// GetByID retrieves a {lower_name} by ID.
func (r *{name}Repository) GetByID(ctx context.Context, id uuid.UUID) (*models.{name}, error) {{
    var entity models.{name}
    err := r.db.WithContext(ctx).First(&entity, "id = ?", id).Error
    if err != nil {{
        return nil, err
    }}
    return &entity, nil
}}

// Update updates an existing {lower_name}.
func (r *{name}Repository) Update(ctx context.Context, entity *models.{name}) error {{
    return r.db.WithContext(ctx).Save(entity).Error
}}

// Delete removes a {lower_name}.
func (r *{name}Repository) Delete(ctx context.Context, id uuid.UUID) error {{
    return r.db.WithContext(ctx).Delete(&models.{name}{{}}, "id = ?", id).Error
}}

// List retrieves all {lower_name}s with pagination.
func (r *{name}Repository) List(ctx context.Context, offset, limit int) ([]models.{name}, error) {{
    var entities []models.{name}
    err := r.db.WithContext(ctx).Offset(offset).Limit(limit).Find(&entities).Error
    return entities, err
}}
"""

    def _map_type(self, field) -> str:
        """Map field to Go type."""
        base_type = self.type_mapper.map_type(field.type_ir).target_type
        if field.nullable:
            return f"*{base_type}"
        return base_type

    def _get_gorm_tag(self, field) -> str:
        """Generate GORM tag for field."""
        tags = [f"column:{field.name}"]
        if not field.nullable:
            tags.append("not null")
        if field.unique:
            tags.append("unique")
        return ";".join(tags)

    def _to_pascal_case(self, name: str) -> str:
        """Convert snake_case to PascalCase."""
        return "".join(word.capitalize() for word in name.split("_"))

    def _to_snake_case(self, name: str) -> str:
        """Convert PascalCase to snake_case."""
        import re

        s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
        return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()
