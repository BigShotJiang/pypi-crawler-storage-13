"""Go type mapping from TypeIR."""

from src.core.ir import TypeIR, TypeCategory
from src.generators.targets.base.type_mapper import BaseTypeMapper, TypeInfo


class GoTypeMapper(BaseTypeMapper):
    """Maps TypeIR to Go/GORM types."""

    GO_TYPE_MAPPINGS = {
        "text": ("string", "TEXT"),
        "varchar": ("string", "VARCHAR(255)"),
        "integer": ("int", "INT"),
        "bigint": ("int64", "BIGINT"),
        "boolean": ("bool", "BOOLEAN"),
        "uuid": ("uuid.UUID", "UUID"),
        "timestamp": ("time.Time", "TIMESTAMP"),
        "date": ("time.Time", "DATE"),
        "decimal": ("decimal.Decimal", "DECIMAL(10,2)"),
        "float": ("float64", "FLOAT"),
        "json": ("datatypes.JSON", "JSON"),
        "jsonb": ("datatypes.JSON", "JSON"),
    }

    def map_type(self, type_ir: TypeIR) -> TypeInfo:
        """Map TypeIR to Go type information."""
        if type_ir.category == TypeCategory.SCALAR:
            go_type, gorm_type = self.GO_TYPE_MAPPINGS.get(type_ir.base_type, ("string", "TEXT"))

            imports = []
            if type_ir.base_type in ["uuid", "timestamp", "date"]:
                imports.append('"github.com/google/uuid"')
                if type_ir.base_type in ["timestamp", "date"]:
                    imports.append('"time"')
            elif type_ir.base_type == "decimal":
                imports.append('"github.com/shopspring/decimal"')
            elif type_ir.base_type in ["json", "jsonb"]:
                imports.append('"gorm.io/datatypes"')

            # Handle parameterized types
            if type_ir.params and type_ir.base_type == "varchar":
                length = type_ir.params.get("length", 255)
                gorm_type = f"VARCHAR({length})"

            return TypeInfo(target_type=go_type, ddl_type=gorm_type, imports=imports)

        if type_ir.category == TypeCategory.REFERENCE:
            entity_name = type_ir.referenced_entity or "UnknownEntity"
            return TypeInfo(
                target_type="uuid.UUID",  # Foreign keys are typically UUIDs
                ddl_type=f"UUID REFERENCES {entity_name.lower()}(id)",
                imports=['"github.com/google/uuid"'],
            )

        if type_ir.category == TypeCategory.ENUM:
            return TypeInfo(
                target_type="string",  # Enums stored as strings
                ddl_type="VARCHAR(50)",
                imports=[],
            )

        if type_ir.category == TypeCategory.LIST:
            return TypeInfo(
                target_type="datatypes.JSON", ddl_type="JSON", imports=['"gorm.io/datatypes"']
            )

        return TypeInfo(target_type="string", ddl_type="TEXT", imports=[])

    def get_reference_type(self, referenced_entity: str) -> str:
        """Get the target type for foreign key references."""
        return "uuid.UUID"

    def get_enum_type(self, enum_values: list[str]) -> str:
        """Get the target type for enum fields."""
        return "string"
