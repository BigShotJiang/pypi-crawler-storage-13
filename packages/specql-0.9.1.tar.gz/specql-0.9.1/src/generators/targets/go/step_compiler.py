"""Go step compiler."""

from typing import TYPE_CHECKING

from src.generators.targets.base.interfaces import StepCompilationResult
from src.generators.targets.base.step_compiler import BaseStepCompiler
from src.generators.targets.go.expression_compiler import GoExpressionCompiler

if TYPE_CHECKING:
    from src.core.ir.action_ir import ActionStepIR


class GoStepCompiler(BaseStepCompiler):
    """Compiles SpecQL action steps to Go/GORM code."""

    def __init__(self):
        super().__init__(GoExpressionCompiler())

    def _compile_validate(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        condition = self.compile_condition(step.expression, ctx)
        code = f"""if !({condition}) {{
    return errors.New("validation failed")
}}"""
        return StepCompilationResult(code=code, imports={'"errors"'})

    def _compile_update(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        model = step.target_entity
        fields = ", ".join(f"{k}: {v}" for k, v in (step.fields or {}).items())
        code = (
            f"""updates := map[string]interface{{{{
    {fields}
}}}}
if err := db.Model(&{model}"""
            + """{}).Where("id = ?", id).Updates(updates).Error; err != nil {
    return err
}"""
        )
        return StepCompilationResult(code=code)

    def _compile_insert(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        model = step.target_entity
        fields = ", ".join(f"{k}: {v}" for k, v in (step.fields or {}).items())
        code = f"""newRecord := {model}{{
    {fields}
}}
if err := db.Create(&newRecord).Error; err != nil {{
    return err
}}"""
        return StepCompilationResult(code=code)

    def _compile_if(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        condition = self.compile_condition(step.condition, ctx)
        then_result = self._compile_nested_steps(step.then_steps or [], ctx)

        code = f"if {condition} {{\n"
        # Indent the then block
        for line in then_result.code.split("\n"):
            code += f"    {line}\n"
        code += "}\n"

        if step.else_steps:
            else_result = self._compile_nested_steps(step.else_steps, ctx)
            code += "else {\n"
            for line in else_result.code.split("\n"):
                code += f"    {line}\n"
            code += "}\n"

        return StepCompilationResult(code=code.rstrip(), imports=then_result.imports)

    def _compile_call(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        args = ", ".join(str(a) for a in (step.function_args or []))
        code = f"""if err := {step.function_name}({args}); err != nil {{
    return err
}}"""
        return StepCompilationResult(code=code)

    def _compile_notify(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        code = f"// TODO: Implement notification: {step.expression}"
        return StepCompilationResult(code=code)

    def _compile_foreach(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        collection = step.collection
        item = step.item_name
        loop_result = self._compile_nested_steps(step.loop_steps or [], ctx)

        code = f"for _, {item} := range {collection} {{\n"
        for line in loop_result.code.split("\n"):
            code += f"    {line}\n"
        code += "}\n"

        return StepCompilationResult(code=code.rstrip(), imports=loop_result.imports)
