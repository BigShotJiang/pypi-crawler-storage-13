"""Go expression compiler."""

from src.generators.targets.base.step_compiler import BaseExpressionCompiler


class GoExpressionCompiler(BaseExpressionCompiler):
    """Compiles SpecQL expressions to Go."""

    OPERATORS = {
        "=": "==",
        "!=": "!=",
        "AND": "&&",
        "OR": "||",
        "NOT": "!",
        "<": "<",
        ">": ">",
        "<=": "<=",
        ">=": ">=",
    }

    NULL_LITERAL = "nil"
    TRUE_LITERAL = "true"
    FALSE_LITERAL = "false"
    STRING_QUOTE = '"'

    def _translate_identifier(self, identifier: str) -> str:
        """Go uses bare identifiers."""
        return identifier

    def _translate_field_reference(self, field_ref: str) -> str:
        """Translate entity.field to Go field access."""
        parts = field_ref.split(".")
        if len(parts) == 2:
            return f"{parts[0].lower()}.{self._to_pascal_case(parts[1])}"
        return field_ref

    def _to_pascal_case(self, name: str) -> str:
        """Convert snake_case to PascalCase for Go."""
        return "".join(word.capitalize() for word in name.split("_"))
