"""Base step and expression compilers for target-specific action compilation."""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Callable, ClassVar

if TYPE_CHECKING:
    from src.core.ir.action_ir import ActionStepIR

from .interfaces import ExpressionCompilationResult, StepCompilationResult


class BaseExpressionCompiler(ABC):
    """Base expression compiler with template method pattern.

    Each target implements an expression compiler that knows how to
    translate SpecQL expressions into target-specific syntax.
    """

    # Subclasses override these mappings
    OPERATORS: ClassVar[dict[str, str]] = {}
    NULL_LITERAL: ClassVar[str] = "null"
    TRUE_LITERAL: ClassVar[str] = "true"
    FALSE_LITERAL: ClassVar[str] = "false"
    STRING_QUOTE: ClassVar[str] = "'"

    def compile(
        self, expression: str, context: dict[str, Any] = None
    ) -> ExpressionCompilationResult:
        """Compile expression to target language.

        Args:
            expression: The SpecQL expression string
            context: Compilation context (variables, entity info, etc.)

        Returns:
            ExpressionCompilationResult with compiled code and metadata
        """
        if context is None:
            context = {}

        tokens = self._tokenize(expression)
        translated = self._translate_tokens(tokens)
        code = self._join_tokens(translated)
        return ExpressionCompilationResult(code=code)

    def _tokenize(self, expression: str) -> list[str]:
        """Tokenize expression - shared logic."""
        # For backwards compatibility, use a simpler approach
        # Split on whitespace only, then process each token
        tokens = expression.split()

        # Further split tokens that contain operators
        result = []
        for token in tokens:
            if any(op in token for op in ["=", "!=", "<=", ">=", "<", ">", "AND", "OR", "NOT"]):
                # Split compound tokens like "user.name=value" into ["user.name", "=", "value"]
                import re

                parts = re.split(r"(\=|\!\=|\<\=|\>\=|\<|\>|\s+)", token)
                result.extend([p for p in parts if p and not p.isspace()])
            else:
                result.append(token)

        return result

    def _translate_tokens(self, tokens: list[str]) -> list[str]:
        """Translate tokens using operator mapping."""
        result = []
        for token in tokens:
            if token.upper() in self.OPERATORS:
                result.append(self.OPERATORS[token.upper()])
            elif token.lower() == "null":
                result.append(self.NULL_LITERAL)
            elif token.lower() == "true":
                result.append(self.TRUE_LITERAL)
            elif token.lower() == "false":
                result.append(self.FALSE_LITERAL)
            elif token.startswith('"') and token.endswith('"'):
                # Double-quoted string - keep as-is for now
                result.append(token)
            elif token.startswith("'") and token.endswith("'"):
                # Single-quoted string - keep as-is for now
                result.append(token)
            elif "." in token:
                # Field reference like entity.field
                result.append(self._translate_field_reference(token))
            elif token.replace("_", "").isalnum() and not token.isdigit():
                # Identifier/variable
                result.append(self._translate_identifier(token))
            else:
                # Operators, punctuation, etc.
                result.append(token)
        return result

    def _join_tokens(self, tokens: list[str]) -> str:
        """Join tokens back into expression string."""
        result = " ".join(tokens).strip()
        # Fix spacing around parentheses: "func (" -> "func("
        import re

        result = re.sub(r"(\w+)\s+\(", r"\1(", result)
        result = re.sub(r"\)\s+(\w+)", r")\1", result)
        return result

    @abstractmethod
    def _translate_identifier(self, identifier: str) -> str:
        """Translate field/entity identifiers - target-specific."""
        pass

    @abstractmethod
    def _translate_field_reference(self, field_ref: str) -> str:
        """Translate field references like entity.field - target-specific."""
        pass

    # Legacy method for backwards compatibility
    def compile_expression(self, expression: str, context: dict[str, Any]) -> str:
        """Compile a SpecQL expression to target-specific syntax.

        Args:
            expression: The SpecQL expression string
            context: Compilation context (variables, entity info, etc.)

        Returns:
            Target-specific expression string
        """
        result = self.compile(expression, context)
        return result.code

    def supports_operator(self, operator: str) -> bool:
        """Check if the target supports a specific operator.

        Args:
            operator: Operator name (e.g., 'AND', 'OR', 'NOT', '=')

        Returns:
            True if the operator is supported
        """
        # Default supported operators - subclasses can override
        supported = {"AND", "OR", "NOT", "=", "!=", "<", ">", "<=", ">="}
        return operator.upper() in supported

    def get_operator_mapping(self, operator: str) -> str:
        """Get the target-specific mapping for an operator.

        Args:
            operator: SpecQL operator

        Returns:
            Target-specific operator
        """
        # Default mappings - subclasses can override
        mappings = {
            "AND": "AND",
            "OR": "OR",
            "NOT": "NOT",
            "=": "=",
            "!=": "!=",
            "<": "<",
            ">": ">",
            "<=": "<=",
            ">=": ">=",
        }
        return mappings.get(operator.upper(), operator)


class BaseStepCompiler(ABC):
    """Unified base class for target-specific action step compilers.

    Uses a dispatch pattern to handle different step types with shared logic
    for nested steps and result merging.
    """

    def __init__(self, expression_compiler: BaseExpressionCompiler):
        """Initialize the step compiler with an expression compiler."""
        self.expression_compiler = expression_compiler
        self._handlers: dict[
            str, Callable[["BaseStepCompiler", "ActionStepIR", dict], StepCompilationResult]
        ] = {
            "validate": self._compile_validate,
            "if": self._compile_if,
            "insert": self._compile_insert,
            "update": self._compile_update,
            "call": self._compile_call,
            "notify": self._compile_notify,
            "foreach": self._compile_foreach,
        }

    def compile_step(self, step: "ActionStepIR", context: dict[str, Any]) -> StepCompilationResult:
        """Compile a single step by dispatching to handler.

        Args:
            step: The ActionStepIR to compile
            context: Compilation context

        Returns:
            StepCompilationResult with compiled code and metadata
        """
        handler = self._handlers.get(step.step_type)
        if not handler:
            raise ValueError(f"Unknown step type: {step.step_type}")
        return handler(step, context)

    def compile_steps(
        self, steps: list["ActionStepIR"], context: dict[str, Any]
    ) -> StepCompilationResult:
        """Compile multiple steps, merging results.

        Args:
            steps: List of ActionStepIR to compile
            context: Compilation context

        Returns:
            Merged StepCompilationResult
        """
        result = StepCompilationResult.empty()
        for step in steps:
            step_result = self.compile_step(step, context)
            result = result.merge(step_result)
        return result

    # Template methods - subclasses implement target-specific logic

    @abstractmethod
    def _compile_validate(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile validation step."""
        pass

    @abstractmethod
    def _compile_if(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile conditional step with recursion."""
        pass

    @abstractmethod
    def _compile_insert(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile insert step."""
        pass

    @abstractmethod
    def _compile_update(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile update step."""
        pass

    @abstractmethod
    def _compile_call(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile function call step."""
        pass

    @abstractmethod
    def _compile_notify(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile notification step."""
        pass

    @abstractmethod
    def _compile_foreach(self, step: "ActionStepIR", ctx: dict) -> StepCompilationResult:
        """Compile foreach loop step."""
        pass

    # Shared helper for if/foreach recursion
    def _compile_nested_steps(
        self, steps: list["ActionStepIR"], ctx: dict
    ) -> StepCompilationResult:
        """Compile nested steps (shared logic for if/foreach)."""
        return self.compile_steps(steps, ctx)

    # Legacy methods for backwards compatibility
    def supports_step_type(self, step_type: str) -> bool:
        """Check if the target supports a specific step type."""
        return step_type in self._handlers

    def set_expression_compiler(self, compiler: BaseExpressionCompiler) -> None:
        """Set the expression compiler to use for compiling expressions within steps."""
        self.expression_compiler = compiler

    def compile_condition(self, condition: str | None, context: dict[str, Any]) -> str:
        """Compile a condition expression."""
        if condition and self.expression_compiler:
            return self.expression_compiler.compile_expression(condition, context)
        return condition or ""

    def validate_step(self, step: "ActionStepIR") -> list[str]:
        """Validate that a step is compatible with this compiler."""
        errors = []

        if not self.supports_step_type(step.step_type):
            errors.append(f"Unsupported step type: {step.step_type}")

        # Step-specific validation
        if step.step_type == "validate" and not step.expression:
            errors.append("Validate steps must have an expression")

        if step.step_type in ("update", "insert") and not step.fields:
            errors.append(f"{step.step_type.capitalize()} steps must have fields")

        if step.step_type == "if" and not step.condition:
            errors.append("If steps must have a condition")

        return errors
