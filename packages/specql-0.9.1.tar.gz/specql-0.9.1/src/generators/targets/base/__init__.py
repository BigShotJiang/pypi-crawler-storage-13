"""Base infrastructure for SpecQL code generation targets."""

from .interfaces import (
    ExpressionCompilationResult,
    StepCompilationResult,
    StepCompilerProtocol,
)
from .registry import TargetRegistry, register_target
from .step_compiler import BaseExpressionCompiler, BaseStepCompiler
from .target import BaseTarget, GeneratedFile, GenerationResult
from .type_mapper import BaseTypeMapper, TypeInfo

__all__ = [
    "BaseTypeMapper",
    "TypeInfo",
    "BaseTarget",
    "GeneratedFile",
    "GenerationResult",
    "BaseStepCompiler",
    "BaseExpressionCompiler",
    "TargetRegistry",
    "register_target",
    "StepCompilationResult",
    "ExpressionCompilationResult",
    "StepCompilerProtocol",
]
