"""Unified interfaces and result types for SpecQL code generation targets."""

from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass
class StepCompilationResult:
    """Unified result from compiling any action step."""

    code: str
    imports: set[str] = field(default_factory=set)
    helpers: list[str] = field(default_factory=list)
    variables: dict[str, str] = field(default_factory=dict)

    def merge(self, other: "StepCompilationResult") -> "StepCompilationResult":
        """Merge two compilation results."""
        return StepCompilationResult(
            code=f"{self.code}\n{other.code}" if self.code else other.code,
            imports=self.imports | other.imports,
            helpers=self.helpers + other.helpers,
            variables={**self.variables, **other.variables},
        )

    @classmethod
    def empty(cls) -> "StepCompilationResult":
        """Create an empty compilation result."""
        return cls(code="")


@dataclass
class ExpressionCompilationResult:
    """Result from compiling an expression."""

    code: str
    imports: set[str] = field(default_factory=set)
    bindings: dict[str, Any] = field(default_factory=dict)


class StepCompilerProtocol(Protocol):
    """Protocol that all step compilers must implement."""

    def compile_step(self, step: Any, context: dict) -> StepCompilationResult:
        """Compile a single step to target code."""
        ...

    def compile_steps(self, steps: list, context: dict) -> StepCompilationResult:
        """Compile multiple steps, merging results."""
        ...
