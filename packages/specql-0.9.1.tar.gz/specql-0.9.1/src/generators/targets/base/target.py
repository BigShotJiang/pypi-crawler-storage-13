"""Base target classes for SpecQL code generation."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass


@dataclass
class GeneratedFile:
    """Represents a single generated file.

    Contains the file path, content, language, and optional metadata
    for tracking generation details.
    """

    path: str
    content: str
    language: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class GenerationResult:
    """Result of a code generation operation.

    Contains the success status, generated files, and any errors or warnings
    that occurred during generation.
    """

    success: bool
    files: list[GeneratedFile]
    target_name: str
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def has_errors(self) -> bool:
        """True if generation failed with errors."""
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        """True if generation succeeded but with warnings."""
        return len(self.warnings) > 0


class BaseTarget(ABC):
    """Abstract base class for all code generation targets.

    Each target (PostgreSQL, Laravel, etc.) implements this interface
    to provide target-specific code generation capabilities.
    """

    @abstractmethod
    def generate(self, entity_ir: Any) -> GenerationResult:
        """Generate code for the given entity IR.

        Args:
            entity_ir: The intermediate representation of the entity to generate

        Returns:
            GenerationResult containing success status and generated files
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """The name of this target (e.g., 'postgresql', 'laravel')."""
        pass

    @property
    @abstractmethod
    def supported_languages(self) -> list[str]:
        """List of programming languages this target generates (e.g., ['sql', 'php'])."""
        pass

    def validate_entity_ir(self, entity_ir: Any) -> list[str]:
        """Validate that the entity IR is compatible with this target.

        This is a convenience method that can be overridden by subclasses
        to provide target-specific validation.

        Args:
            entity_ir: The entity IR to validate

        Returns:
            List of validation error messages (empty if valid)
        """
        return []

    def get_target_options(self) -> dict[str, Any]:
        """Get target-specific configuration options.

        Returns:
            Dictionary of configuration options
        """
        return {}

    def supports_feature(self, feature: str) -> bool:
        """Check if this target supports a specific feature.

        Args:
            feature: Feature name (e.g., 'actions', 'views', 'migrations')

        Returns:
            True if the feature is supported
        """
        # Default implementation - subclasses should override
        return False
