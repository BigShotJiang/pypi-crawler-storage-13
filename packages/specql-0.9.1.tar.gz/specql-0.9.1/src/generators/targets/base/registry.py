"""Target registry for managing and discovering code generation targets."""

from typing import Any

from .target import BaseTarget


class TargetRegistry:
    """Registry for managing code generation targets.

    Provides a centralized way to register, discover, and instantiate
    target implementations for different languages/frameworks.
    """

    _targets: dict[str, type[BaseTarget]] = {}

    @classmethod
    def register(cls, name: str, target_class: type[BaseTarget]) -> None:
        """Register a target class with the given name.

        Args:
            name: Unique identifier for the target (e.g., 'postgresql', 'laravel')
            target_class: The target class to register

        Raises:
            ValueError: If a target with the same name is already registered
        """
        if name in cls._targets:
            raise ValueError(f"Target '{name}' is already registered")

        if not issubclass(target_class, BaseTarget):
            raise ValueError("Target class must inherit from BaseTarget")

        cls._targets[name] = target_class

    @classmethod
    def get_target(cls, name: str) -> type[BaseTarget]:
        """Get a registered target class by name.

        Args:
            name: The target name

        Returns:
            The target class

        Raises:
            KeyError: If no target with the given name is registered
        """
        if name not in cls._targets:
            available = list(cls._targets.keys())
            raise KeyError(f"Target '{name}' not found. Available targets: {available}")

        return cls._targets[name]

    @classmethod
    def list_targets(cls) -> dict[str, type[BaseTarget]]:
        """List all registered targets.

        Returns:
            Dictionary mapping target names to target classes
        """
        return cls._targets.copy()

    @classmethod
    def get_target_names(cls) -> list[str]:
        """Get a list of all registered target names.

        Returns:
            List of target names
        """
        return list(cls._targets.keys())

    @classmethod
    def create_target(cls, name: str, **kwargs: Any) -> BaseTarget:
        """Create an instance of a registered target.

        Args:
            name: The target name
            **kwargs: Arguments to pass to the target constructor

        Returns:
            An instance of the target

        Raises:
            KeyError: If no target with the given name is registered
        """
        target_class = cls.get_target(name)
        return target_class(**kwargs)

    @classmethod
    def is_registered(cls, name: str) -> bool:
        """Check if a target is registered.

        Args:
            name: The target name

        Returns:
            True if the target is registered
        """
        return name in cls._targets

    @classmethod
    def clear(cls) -> None:
        """Clear all registered targets. Mainly for testing."""
        cls._targets.clear()


def register_target(name: str):
    """Decorator to register a target class with the registry.

    Args:
        name: Unique identifier for the target

    Returns:
        Decorator function

    Example:
        @register_target('postgresql')
        class PostgreSQLTarget(BaseTarget):
            ...
    """

    def decorator(target_class: type[BaseTarget]) -> type[BaseTarget]:
        TargetRegistry.register(name, target_class)
        return target_class

    return decorator
