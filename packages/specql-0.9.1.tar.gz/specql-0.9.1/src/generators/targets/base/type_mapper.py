"""Base type mapper for target-specific type mapping."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from src.core.ir.type_ir import TypeIR


@dataclass
class TypeInfo:
    """Information about a mapped type for a specific target.

    Contains all the information needed to generate target-specific
    type declarations, including DDL types, target types, imports, and constraints.
    """

    target_type: str  # The type as used in the target language (e.g., 'string', 'String', 'str')
    ddl_type: str  # The DDL type for database schema generation (e.g., 'VARCHAR(100)', 'TEXT')

    # Additional metadata
    imports: list[str] = field(default_factory=list)  # Required imports for this type
    constraints: list[str] = field(
        default_factory=list
    )  # Additional constraints (e.g., ['NOT NULL'])


class BaseTypeMapper(ABC):
    """Abstract base class for target-specific type mappers.

    Each target (PostgreSQL, Laravel, etc.) implements a concrete type mapper
    that knows how to convert SpecQL types to target-specific representations.
    """

    @abstractmethod
    def map_type(self, type_ir: "TypeIR") -> TypeInfo:
        """Map a SpecQL TypeIR to target-specific type information.

        Args:
            type_ir: The intermediate representation of the type

        Returns:
            TypeInfo containing target type, DDL type, imports, and constraints
        """
        pass

    @abstractmethod
    def get_reference_type(self, referenced_entity: str) -> str:
        """Get the target type for foreign key references.

        Args:
            referenced_entity: Name of the referenced entity

        Returns:
            Target type string for foreign key fields
        """
        pass

    @abstractmethod
    def get_enum_type(self, enum_values: list[str]) -> str:
        """Get the target type for enum fields.

        Args:
            enum_values: List of allowed enum values

        Returns:
            Target type string for enum fields
        """
        pass

    def map_scalar_type(self, base_type: str, params: dict[str, Any] | None = None) -> TypeInfo:
        """Map scalar types with optional parameters.

        This is a convenience method that can be overridden by subclasses
        to provide custom scalar type mapping logic.

        Args:
            base_type: The scalar type name (e.g., 'text', 'integer', 'uuid')
            params: Optional type parameters (e.g., {'length': 100} for varchar)

        Returns:
            TypeInfo for the scalar type
        """
        # Default implementation - subclasses should override
        return TypeInfo(target_type=base_type, ddl_type=base_type.upper())

    def map_list_type(self, element_type: "TypeIR") -> TypeInfo:
        """Map list/array types.

        Args:
            element_type: The TypeIR of the list elements

        Returns:
            TypeInfo for the list type
        """
        # Default implementation - subclasses should override
        element_info = self.map_type(element_type)
        return TypeInfo(
            target_type=f"List[{element_info.target_type}]",
            ddl_type=f"{element_info.ddl_type}[]",
            imports=element_info.imports,
        )

    def map_composite_type(self, composite_fields: dict[str, "TypeIR"]) -> TypeInfo:
        """Map composite/custom types.

        Args:
            composite_fields: Dictionary of field names to their TypeIR

        Returns:
            TypeInfo for the composite type
        """
        # Default implementation - subclasses should override
        return TypeInfo(target_type="object", ddl_type="JSONB")
