"""
Base Output Strategy

Abstract base class for different output directory structures and file organization strategies.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict


@dataclass
class FileOutput:
    """Represents a file to be written"""

    relative_path: str
    content: str
    file_type: str  # 'table', 'function', 'view', 'comment', etc.


@dataclass
class OutputContext:
    """Context information for output generation"""

    base_dir: Path
    entities: list
    use_registry: bool = False
    table_codes: dict[str, str] | None = None  # entity_name -> table_code mapping
    schema_outputs: Dict[str, Any] | None = None  # entity_name -> schema_output mapping


class OutputStrategy(ABC):
    """Abstract base class for output strategies"""

    @abstractmethod
    def generate_file_outputs(
        self,
        context: OutputContext,
        entity: Any,
        table_code: str | None = None,
    ) -> list[FileOutput]:
        """
        Generate file outputs for a single entity

        Args:
            context: Output context with base directory and settings
            entity: Entity to generate files for
            table_code: Optional table code for registry-based strategies

        Returns:
            List of FileOutput objects representing files to write
        """
        pass

    @abstractmethod
    def get_directory_structure(self) -> dict[str, Any]:
        """
        Return the directory structure description for documentation

        Returns:
            Dictionary describing the directory structure
        """
        pass

    @abstractmethod
    def get_strategy_name(self) -> str:
        """Return the strategy name"""
        pass

    def prepare_directories(self, context: OutputContext) -> None:
        """
        Prepare output directories. Default implementation creates base directory.

        Args:
            context: Output context
        """
        context.base_dir.mkdir(parents=True, exist_ok=True)

    def write_files(self, context: OutputContext, file_outputs: list[FileOutput]) -> list[Path]:
        """
        Write file outputs to disk

        Args:
            context: Output context
            file_outputs: List of files to write

        Returns:
            List of written file paths
        """
        written_files = []

        for file_output in file_outputs:
            full_path = context.base_dir / file_output.relative_path
            full_path.parent.mkdir(parents=True, exist_ok=True)
            full_path.write_text(file_output.content)
            written_files.append(full_path)

        return written_files
