"""
Confiture Output Strategy

Preserves the current flat directory structure used by Confiture.
"""

from typing import Any

from .base import FileOutput, OutputContext, OutputStrategy


class ConfitureStrategy(OutputStrategy):
    """Output strategy that maintains Confiture's flat directory structure"""

    def get_strategy_name(self) -> str:
        return "confiture"

    def get_directory_structure(self) -> dict[str, Any]:
        return {
            "description": "Flat directory structure (Confiture compatible)",
            "structure": {
                "db/schema/": {
                    "00_foundation/": ["000_app_foundation.sql"],
                    "10_tables/": ["{entity_name}.sql"],
                    "30_functions/": ["{entity_name}.sql"],
                    "40_metadata/": ["{entity_name}.sql"],
                }
            },
        }

    def generate_file_outputs(
        self,
        context: OutputContext,
        entity: Any,
        table_code: str | None = None,
    ) -> list[FileOutput]:
        """
        Generate file outputs using Confiture's flat structure

        Maps registry layers to Confiture directories:
        - table files → db/schema/10_tables/
        - function files → db/schema/30_functions/
        - comment/metadata files → db/schema/40_metadata/
        """
        outputs = []

        # Get schema output from context if available
        schema_output = None
        if context.schema_outputs and entity.name in context.schema_outputs:
            schema_output = context.schema_outputs[entity.name]

        # Generate table file
        table_content = self._generate_table_sql(entity, table_code, schema_output)
        if table_content:
            outputs.append(
                FileOutput(
                    relative_path=f"db/schema/10_tables/{entity.name.lower()}.sql",
                    content=table_content,
                    file_type="table",
                )
            )

        # Generate function files (if entity has actions)
        if entity.actions and schema_output:
            function_outputs = self._generate_function_files(entity, table_code, schema_output)
            outputs.extend(function_outputs)

        # Generate metadata/comment file (if needed)
        metadata_content = self._generate_metadata_sql(entity)
        if metadata_content:
            outputs.append(
                FileOutput(
                    relative_path=f"db/schema/40_metadata/{entity.name.lower()}.sql",
                    content=metadata_content,
                    file_type="comment",
                )
            )

        return outputs

    def _generate_table_sql(
        self, entity: Any, table_code: str | None, schema_output: Any = None
    ) -> str:
        """Generate CREATE TABLE SQL"""
        if schema_output and hasattr(schema_output, "table_sql"):
            return schema_output.table_sql
        # Fallback placeholder
        return f"-- Table: {entity.name}\n-- TODO: Integrate with PostgreSQL table generator\n"

    def _generate_function_files(
        self, entity: Any, table_code: str | None, schema_output: Any
    ) -> list[FileOutput]:
        """Generate function files for entity actions"""
        outputs = []

        if not schema_output or not hasattr(schema_output, "mutations"):
            return outputs

        # Generate one file per mutation
        for mutation in schema_output.mutations:
            mutation_content = f"""-- ============================================================================
-- Mutation: {mutation.action_name}
-- Entity: {entity.name}
-- Pattern: App Wrapper + Core Logic + FraiseQL Metadata
-- ============================================================================

{mutation.app_wrapper_sql}

{mutation.core_logic_sql}

{mutation.fraiseql_comments_sql}
"""
            outputs.append(
                FileOutput(
                    relative_path=f"db/schema/30_functions/{mutation.action_name}.sql",
                    content=mutation_content,
                    file_type="function",
                )
            )

        return outputs

    def _generate_metadata_sql(self, entity: Any) -> str:
        """Generate metadata/comment SQL"""
        # Only generate if entity has description or other metadata
        if not entity.description:
            return ""

        return f"-- Metadata for {entity.name}\n-- Description: {entity.description}\n"
