"""
PrintOptim Output Strategy

Generates PrintOptim-style numbered directory hierarchy.
"""

from typing import Any

from .base import FileOutput, OutputContext, OutputStrategy


class PrintOptimStrategy(OutputStrategy):
    """Output strategy that generates PrintOptim's numbered directory hierarchy"""

    def get_strategy_name(self) -> str:
        return "printoptim"

    def get_directory_structure(self) -> dict[str, Any]:
        return {
            "description": "PrintOptim numbered directory hierarchy",
            "structure": {
                "db/0_schema/": {
                    "01_write_side/": {
                        "010_i18n/": {
                            "0101_locale/": ["01011_language/", "01012_locale/"],
                            "0102_country/": ["01021_continent/", "01022_tl_continent/"],
                        }
                    },
                    "02_query_side/": ["Views and read models"],
                    "03_functions/": ["Business logic functions"],
                }
            },
        }

    def generate_file_outputs(
        self,
        context: OutputContext,
        entity: Any,
        table_code: str | None = None,
    ) -> list[FileOutput]:
        """
        Generate file outputs using PrintOptim's numbered hierarchy

        The structure follows:
        db/0_schema/
        ├── 01_write_side/
        │   ├── {domain_code}_{domain}/
        │   │   ├── {entity_code}_{entity}/
        │   │   │   └── {entity_code}{subentity_code}_{table_name}.sql
        │   │   └── {entity_code}{subentity_code}_{tl_table_name}.sql
        ├── 02_query_side/
        └── 03_functions/
        """
        outputs = []

        # Get schema output from context if available
        schema_output = None
        if context.schema_outputs and entity.name in context.schema_outputs:
            schema_output = context.schema_outputs[entity.name]

        # Determine domain and entity codes
        domain_code, entity_code = self._derive_codes(entity, table_code)

        # Generate table file in write_side
        table_content = self._generate_table_sql(entity, table_code, schema_output)
        if table_content:
            table_path = self._get_table_file_path(entity, domain_code, entity_code)
            outputs.append(
                FileOutput(
                    relative_path=table_path,
                    content=table_content,
                    file_type="table",
                )
            )

        # Generate translation table files (if applicable)
        translation_outputs = self._generate_translation_files(entity, domain_code, entity_code)
        outputs.extend(translation_outputs)

        # Generate function files in functions directory
        if entity.actions and schema_output:
            function_outputs = self._generate_function_files(
                entity, table_code, schema_output, domain_code, entity_code
            )
            outputs.extend(function_outputs)

        return outputs

    def _derive_codes(self, entity: Any, table_code: str | None) -> tuple[str, str]:
        """
        Derive domain and entity codes for PrintOptim structure

        PrintOptim uses codes like:
        - 010_i18n (domain)
        - 0101_locale (subdomain/entity)
        - 01011_language (specific table)
        """
        if table_code and len(table_code) >= 6:
            # Use registry-based codes if available
            domain_code = table_code[:3]  # e.g., "010"
            entity_code = table_code[3:6]  # e.g., "011"
            return domain_code, entity_code

        # Fallback: derive from entity name
        # This is a simplified mapping - in practice would need domain registry
        name_lower = entity.name.lower()

        # Simple domain mapping (would be configurable in real implementation)
        domain_map = {
            "language": ("010", "011"),
            "locale": ("010", "012"),
            "country": ("010", "013"),
            "continent": ("010", "021"),
            "currency": ("020", "001"),
        }

        domain_code, entity_code = domain_map.get(name_lower, ("999", "999"))
        return domain_code, entity_code

    def _get_table_file_path(self, entity: Any, domain_code: str, entity_code: str) -> str:
        """Generate table file path in PrintOptim structure"""
        # Pattern: db/0_schema/01_write_side/{domain_code}_{domain}/{entity_code}_{entity}/
        #          {entity_code}{subentity_code}_{table_name}.sql

        # Determine domain name (simplified)
        domain_name = self._get_domain_name(entity)

        # For main entity table
        subentity_code = "1"  # Main table
        filename = f"{entity_code}{subentity_code}_{entity.name.lower()}.sql"

        return (
            f"db/0_schema/01_write_side/{domain_code}_{domain_name}/"
            f"{entity_code}_{entity.name.lower()}/{filename}"
        )

    def _get_function_file_path(self, entity: Any, domain_code: str, entity_code: str) -> str:
        """Generate function file path in PrintOptim structure"""
        domain_name = self._get_domain_name(entity)
        filename = f"{entity_code}_{entity.name.lower()}.sql"

        return f"db/0_schema/03_functions/{domain_code}_{domain_name}/{filename}"

    def _get_domain_name(self, entity: Any) -> str:
        """Determine domain name from entity (simplified mapping)"""
        name_lower = entity.name.lower()

        domain_map = {
            "language": "i18n",
            "locale": "i18n",
            "country": "i18n",
            "continent": "i18n",
            "currency": "finance",
        }

        return domain_map.get(name_lower, "common")

    def _generate_translation_files(
        self, entity: Any, domain_code: str, entity_code: str
    ) -> list[FileOutput]:
        """Generate translation table files if entity has translations"""
        outputs = []

        # Check if entity has translation fields (indicated by nested translations structure)
        if hasattr(entity, "fields") and entity.fields:
            for field_name, field_info in entity.fields.items():
                if isinstance(field_info, dict) and "translations" in field_info:
                    # This entity has translations - generate tl_* table
                    translation_content = self._generate_translation_sql(entity, field_name)
                    if translation_content:
                        translation_path = self._get_translation_file_path(
                            entity, domain_code, entity_code
                        )
                        outputs.append(
                            FileOutput(
                                relative_path=translation_path,
                                content=translation_content,
                                file_type="translation_table",
                            )
                        )
                    break  # Only generate one translation table per entity

        return outputs

    def _get_translation_file_path(self, entity: Any, domain_code: str, entity_code: str) -> str:
        """Generate translation table file path"""
        domain_name = self._get_domain_name(entity)

        # Translation tables use tl_ prefix
        tl_name = f"tl_{entity.name.lower()}"
        subentity_code = "2"  # Translation table
        filename = f"{entity_code}{subentity_code}_{tl_name}.sql"

        return (
            f"db/0_schema/01_write_side/{domain_code}_{domain_name}/"
            f"{entity_code}_{entity.name.lower()}/{filename}"
        )

    def _generate_table_sql(
        self, entity: Any, table_code: str | None, schema_output: Any = None
    ) -> str:
        """Generate CREATE TABLE SQL for PrintOptim format"""
        if schema_output and hasattr(schema_output, "table_sql"):
            lines = [f"-- {entity.name} table"]
            lines.append("-- Generated for PrintOptim structure")
            if table_code:
                lines.append(f"-- Table code: {table_code}")
            lines.append("")
            lines.append(schema_output.table_sql)
            return "\n".join(lines)

        # Fallback placeholder
        lines = [f"-- {entity.name} table"]
        lines.append("-- Generated for PrintOptim structure")
        if table_code:
            lines.append(f"-- Table code: {table_code}")
        lines.append("")

        # Basic table structure (would integrate with actual PostgreSQL generators)
        lines.append(f"CREATE TABLE IF NOT EXISTS {entity.schema}.{entity.name.lower()} (")
        lines.append("    -- TODO: Integrate with PostgreSQL table generator")
        lines.append("    id SERIAL PRIMARY KEY")
        lines.append(");")
        lines.append("")

        if entity.description:
            lines.append(
                f"COMMENT ON TABLE {entity.schema}.{entity.name.lower()} IS '{entity.description}';"
            )

        return "\n".join(lines)

    def _generate_function_files(
        self,
        entity: Any,
        table_code: str | None,
        schema_output: Any,
        domain_code: str,
        entity_code: str,
    ) -> list[FileOutput]:
        """Generate function files for PrintOptim format"""
        outputs = []

        if not schema_output or not hasattr(schema_output, "mutations"):
            return outputs

        # Generate one file per mutation in PrintOptim structure
        for mutation in schema_output.mutations:
            mutation_content = f"""-- ============================================================================
-- Mutation: {mutation.action_name}
-- Entity: {entity.name}
-- Pattern: App Wrapper + Core Logic + FraiseQL Metadata
-- ============================================================================

{mutation.app_wrapper_sql}

{mutation.core_logic_sql}

{mutation.fraiseql_comments_sql}
"""
            # Use PrintOptim path structure for functions
            domain_name = self._get_domain_name(entity)
            function_path = (
                f"db/0_schema/03_functions/{domain_code}_{domain_name}/{mutation.action_name}.sql"
            )

            outputs.append(
                FileOutput(
                    relative_path=function_path,
                    content=mutation_content,
                    file_type="function",
                )
            )

        return outputs

    def _generate_translation_sql(self, entity: Any, translation_field: str) -> str:
        """Generate translation table SQL"""
        tl_name = f"tl_{entity.name.lower()}"

        lines = [f"-- Translation table for {entity.name}"]
        lines.append("-- Generated for PrintOptim structure")
        lines.append("")

        lines.append(f"CREATE TABLE IF NOT EXISTS {entity.schema}.{tl_name} (")
        lines.append("    -- TODO: Integrate with translation table generator")
        lines.append(f"    fk_{entity.name.lower()} INTEGER NOT NULL,")
        lines.append("    fk_language INTEGER NOT NULL,")
        lines.append(f"    {translation_field} TEXT,")
        lines.append(f"    PRIMARY KEY (fk_{entity.name.lower()}, fk_language)")
        lines.append(");")

        return "\n".join(lines)
