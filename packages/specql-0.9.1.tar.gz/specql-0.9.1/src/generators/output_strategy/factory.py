"""
Output Strategy Factory

Creates output strategy instances based on configuration.
"""

from .base import OutputStrategy
from .confiture import ConfitureStrategy
from .printoptim import PrintOptimStrategy


def create_output_strategy(strategy_name: str) -> OutputStrategy:
    """
    Create an output strategy instance.

    Args:
        strategy_name: Name of the strategy ('confiture' or 'printoptim')

    Returns:
        OutputStrategy instance

    Raises:
        ValueError: If strategy_name is not recognized
    """
    strategies = {
        "confiture": ConfitureStrategy,
        "printoptim": PrintOptimStrategy,
    }

    strategy_class = strategies.get(strategy_name.lower())
    if strategy_class is None:
        available = list(strategies.keys())
        raise ValueError(f"Unknown output strategy '{strategy_name}'. Available: {available}")

    return strategy_class()
