"""
Output Strategy Package

Provides different strategies for organizing generated files in directory structures.
"""

from .base import OutputStrategy, OutputContext, FileOutput
from .confiture import ConfitureStrategy
from .printoptim import PrintOptimStrategy
from .factory import create_output_strategy

__all__ = [
    "OutputStrategy",
    "OutputContext",
    "FileOutput",
    "ConfitureStrategy",
    "PrintOptimStrategy",
    "create_output_strategy",
]
