"""SpecQL Code Generators.

This package contains all code generators for different target platforms
and languages. Generators consume the IR (Intermediate Representation)
to produce target-specific code.
"""

__version__ = "0.9.1"

# Import core submodule for easier access
from . import core
