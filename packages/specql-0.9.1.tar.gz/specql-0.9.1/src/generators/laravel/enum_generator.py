"""Generator for PHP Enum classes."""

from pathlib import Path
from typing import TYPE_CHECKING

from jinja2 import Environment, FileSystemLoader

from .utils import (
    enum_value_to_case_name,
    field_to_enum_class_name,
)

if TYPE_CHECKING:
    from src.core.ir import FieldIR

from src.core.ir import TypeCategory


class EnumGenerator:
    """Generates PHP Enum files from SpecQL enum fields."""

    def __init__(self):
        """Initialize the generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.template = self.env.get_template("enum.php.jinja2")

    def generate_from_field(self, entity_name: str, field: "FieldIR") -> str:
        """Generate enum from FieldIR.

        Args:
            entity_name: Name of the parent entity
            field: FieldIR with type_ir containing enum values

        Returns:
            PHP enum code
        """
        if field.type_ir.category != TypeCategory.ENUM:
            raise ValueError(f"Field {field.name} is not an enum type")

        class_name = field_to_enum_class_name(entity_name, field.name)
        enum_values = field.type_ir.enum_values or []

        values = []
        for value in enum_values:
            values.append(
                {
                    "value": value,
                    "case_name": enum_value_to_case_name(value),
                    "label": self._value_to_label(value),
                }
            )

        return self.template.render(
            class_name=class_name,
            values=values,
        )

    def get_class_name(self, entity_name: str, field_name: str) -> str:
        """Get the enum class name for an entity field."""
        return field_to_enum_class_name(entity_name, field_name)

    def get_file_path(self, entity_name: str, field_name: str) -> str:
        """Get the relative file path for the enum."""
        class_name = self.get_class_name(entity_name, field_name)
        return f"app/Enums/{class_name}.php"

    def _value_to_label(self, value: str) -> str:
        """
        Convert enum value to human-readable label.

        Examples:
            'lead' -> 'Lead'
            'in_progress' -> 'In Progress'
            'in-progress' -> 'In Progress'
        """
        # Replace underscores and hyphens with spaces
        label = value.replace("_", " ").replace("-", " ")
        # Capitalize each word
        return " ".join(word.capitalize() for word in label.split())
