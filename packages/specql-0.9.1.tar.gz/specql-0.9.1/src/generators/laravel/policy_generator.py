"""Generator for PHP Policy classes."""

from pathlib import Path
from typing import TYPE_CHECKING

from jinja2 import Environment, FileSystemLoader

from .utils import (
    schema_to_namespace,
    to_camel_case,
    to_pascal_case,
)

if TYPE_CHECKING:
    from src.core.ir import EntityIR


class PolicyGenerator:
    """Generates PHP Policy files from SpecQL entities."""

    def __init__(self):
        """Initialize the generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.template = self.env.get_template("policy.php.jinja2")

    def generate_from_ir(self, entity: "EntityIR") -> str:
        """Generate policy from EntityIR.

        Args:
            entity: The EntityIR to generate a policy for

        Returns:
            Generated PHP policy code
        """
        from .utils import schema_to_namespace, to_pascal_case

        namespace = schema_to_namespace(entity.schema) if entity.schema else ""
        model_class = to_pascal_case(entity.name)
        class_name = f"{model_class}Policy"
        model_param = to_camel_case(entity.name)

        return self.template.render(
            namespace=namespace,
            model_class=model_class,
            class_name=class_name,
            model_param=model_param,
        )

    def get_class_name(self, entity_name: str) -> str:
        """Get the Policy class name for an entity."""
        model_class = to_pascal_case(entity_name)
        return f"{model_class}Policy"

    def get_file_path(self, entity_name: str, schema: str = "") -> str:
        """Get the relative file path for the Policy."""
        class_name = self.get_class_name(entity_name)
        namespace_path = f"/{schema_to_namespace(schema)}" if schema else ""
        return f"app/Policies{namespace_path}/{class_name}.php"
