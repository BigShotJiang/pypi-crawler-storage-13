"""Generator for PHP API Resource classes."""

from pathlib import Path
from typing import TYPE_CHECKING, Any

from jinja2 import Environment, FileSystemLoader

from .utils import (
    is_enum_type,
    schema_to_namespace,
    to_camel_case,
    to_pascal_case,
)

if TYPE_CHECKING:
    from src.core.ir import EntityIR


class ResourceGenerator:
    """Generates PHP API Resource files from SpecQL entities."""

    def __init__(self):
        """Initialize the generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.template = self.env.get_template("resource.php.jinja2")

    def generate_from_ir(self, entity: "EntityIR") -> str:
        """Generate resource from EntityIR.

        Args:
            entity: The EntityIR to generate a resource for

        Returns:
            Generated PHP resource code
        """
        from .utils import schema_to_namespace, to_pascal_case

        # Convert EntityIR to the format expected by the template
        fields = {}
        relationships = []

        for field in entity.fields:
            # Convert TypeIR back to specql type string for backwards compatibility
            if field.type_ir.category.name == "SCALAR":
                specql_type = field.type_ir.base_type
                fields[field.name] = specql_type
            elif field.type_ir.category.name == "ENUM":
                enum_values = ", ".join(field.type_ir.enum_values or [])
                specql_type = f"enum({enum_values})"
                fields[field.name] = specql_type
            elif field.type_ir.category.name == "REFERENCE":
                referenced_entity = field.type_ir.referenced_entity or "Unknown"
                # For references, don't add to fields (they're handled as relationships)
                # Add relationship info
                relationships.append(
                    {"name": field.name, "type": "belongsTo", "entity": referenced_entity}
                )
            else:
                specql_type = field.type_ir.base_type
                fields[field.name] = specql_type

        namespace = schema_to_namespace(entity.schema) if entity.schema else ""
        class_name = f"{to_pascal_case(entity.name)}Resource"

        processed_fields = []
        for field_name, specql_type in fields.items():
            field_info = self._process_field(field_name, specql_type)
            processed_fields.append(field_info)

        processed_relationships = []
        if relationships:
            for relationship in relationships:
                rel_info = self._process_relationship(relationship, entity.schema)
                processed_relationships.append(rel_info)

        return self.template.render(
            namespace=namespace,
            class_name=class_name,
            fields=processed_fields,
            relationships=processed_relationships,
        )

    def get_class_name(self, entity_name: str) -> str:
        """Get the Resource class name for an entity."""
        return f"{to_pascal_case(entity_name)}Resource"

    def get_file_path(self, entity_name: str, schema: str = "") -> str:
        """Get the relative file path for the Resource."""
        class_name = self.get_class_name(entity_name)
        namespace_path = f"/{schema_to_namespace(schema)}" if schema else ""
        return f"app/Http/Resources{namespace_path}/{class_name}.php"

    def _process_field(self, field_name: str, specql_type: str) -> dict[str, Any]:
        """Process a field for API resource inclusion."""
        # Convert field name to camelCase for API responses
        api_name = to_camel_case(field_name)

        # Determine model attribute (usually the same as field name)
        model_attribute = field_name

        # Handle enum fields - they might need special formatting
        if is_enum_type(specql_type):
            model_attribute = f"{field_name}->value"

        return {
            "api_name": api_name,
            "model_attribute": model_attribute,
        }

    def _process_relationship(self, relationship: dict[str, str], schema: str) -> dict[str, Any]:
        """Process a relationship for API resource inclusion."""
        rel_name = relationship["name"]
        rel_entity = relationship["entity"]

        # API name in camelCase
        api_name = to_camel_case(rel_name)

        # Resource class name
        resource_class = f"{to_pascal_case(rel_entity)}Resource"

        # Add namespace if schema is provided
        if schema:
            namespace = schema_to_namespace(schema)
            resource_class = f"{namespace}\\{resource_class}"

        return {
            "name": rel_name,
            "api_name": api_name,
            "resource_class": resource_class,
        }
