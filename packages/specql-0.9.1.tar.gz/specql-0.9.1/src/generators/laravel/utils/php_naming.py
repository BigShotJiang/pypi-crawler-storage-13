"""PHP naming convention utilities."""


def to_pascal_case(name: str) -> str:
    """
    Convert snake_case or kebab-case to PascalCase.

    Examples:
        'contact' -> 'Contact'
        'qualify_lead' -> 'QualifyLead'
        'user-profile' -> 'UserProfile'
    """
    # Replace hyphens with underscores
    name = name.replace("-", "_")
    # Split by underscore and capitalize each part
    parts = name.split("_")
    return "".join(part.capitalize() for part in parts)


def to_camel_case(name: str) -> str:
    """
    Convert snake_case to camelCase.

    Examples:
        'qualify_lead' -> 'qualifyLead'
        'contact' -> 'contact'
    """
    pascal = to_pascal_case(name)
    if not pascal:
        return pascal
    return pascal[0].lower() + pascal[1:]


def to_snake_case(name: str) -> str:
    """
    Convert PascalCase or camelCase to snake_case.

    Examples:
        'QualifyLead' -> 'qualify_lead'
        'Contact' -> 'contact'
    """
    result = []
    for i, char in enumerate(name):
        if char.isupper() and i > 0:
            result.append("_")
        result.append(char.lower())
    return "".join(result)


def entity_to_table_name(entity_name: str) -> str:
    """
    Convert entity name to table name.

    Examples:
        'Contact' -> 'tb_contact'
        'CompanyAddress' -> 'tb_company_address'
    """
    return f"tb_{to_snake_case(entity_name)}"


def entity_to_primary_key(entity_name: str) -> str:
    """
    Convert entity name to primary key column name.

    Examples:
        'Contact' -> 'pk_contact'
        'CompanyAddress' -> 'pk_company_address'
    """
    return f"pk_{to_snake_case(entity_name)}"


def entity_to_foreign_key(entity_name: str) -> str:
    """
    Convert entity name to foreign key column name.

    Examples:
        'Company' -> 'fk_company'
        'UserProfile' -> 'fk_user_profile'
    """
    return f"fk_{to_snake_case(entity_name)}"


def schema_to_namespace(schema: str) -> str:
    """
    Convert schema name to PHP namespace part.

    Examples:
        'crm' -> 'Crm'
        'user_management' -> 'UserManagement'
    """
    return to_pascal_case(schema)


def action_to_class_name(action_name: str) -> str:
    """
    Convert action name to Action class name.

    Examples:
        'qualify_lead' -> 'QualifyLeadAction'
        'send_invoice' -> 'SendInvoiceAction'
    """
    return f"{to_pascal_case(action_name)}Action"


def field_to_enum_class_name(entity_name: str, field_name: str) -> str:
    """
    Convert entity and field to Enum class name.

    Examples:
        ('Contact', 'status') -> 'ContactStatus'
        ('Order', 'payment_status') -> 'OrderPaymentStatus'
    """
    return f"{to_pascal_case(entity_name)}{to_pascal_case(field_name)}"


def enum_value_to_case_name(value: str) -> str:
    """
    Convert enum value to PHP enum case name.

    Examples:
        'lead' -> 'Lead'
        'in-progress' -> 'InProgress'
        'ACTIVE' -> 'Active'
    """
    return to_pascal_case(value.lower())
