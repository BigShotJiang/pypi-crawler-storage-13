"""Type mapping between SpecQL and Laravel/PHP."""

from dataclasses import dataclass


@dataclass
class TypeMapping:
    """Holds all type information for a field."""

    migration_method: str  # Laravel migration method
    migration_args: list  # Arguments for migration method
    php_type: str  # PHP type hint
    cast: str | None  # Eloquent cast (or None)
    faker_method: str  # Faker method for factories
    validation_rules: list  # Laravel validation rules


# Default mappings for SpecQL types
TYPE_MAPPINGS: dict[str, TypeMapping] = {
    "text": TypeMapping(
        migration_method="string",
        migration_args=[255],
        php_type="string",
        cast=None,
        faker_method="fake()->sentence()",
        validation_rules=["string", "max:255"],
    ),
    "integer": TypeMapping(
        migration_method="integer",
        migration_args=[],
        php_type="int",
        cast="'integer'",
        faker_method="fake()->randomNumber()",
        validation_rules=["integer"],
    ),
    "bigint": TypeMapping(
        migration_method="bigInteger",
        migration_args=[],
        php_type="int",
        cast="'integer'",
        faker_method="fake()->randomNumber()",
        validation_rules=["integer"],
    ),
    "boolean": TypeMapping(
        migration_method="boolean",
        migration_args=[],
        php_type="bool",
        cast="'boolean'",
        faker_method="fake()->boolean()",
        validation_rules=["boolean"],
    ),
    "date": TypeMapping(
        migration_method="date",
        migration_args=[],
        php_type="Carbon",
        cast="'date'",
        faker_method="fake()->date()",
        validation_rules=["date"],
    ),
    "datetime": TypeMapping(
        migration_method="dateTime",
        migration_args=[],
        php_type="Carbon",
        cast="'datetime'",
        faker_method="fake()->dateTime()",
        validation_rules=["date"],
    ),
    "timestamp": TypeMapping(
        migration_method="timestamp",
        migration_args=[],
        php_type="Carbon",
        cast="'datetime'",
        faker_method="fake()->dateTime()",
        validation_rules=["date"],
    ),
    "uuid": TypeMapping(
        migration_method="uuid",
        migration_args=[],
        php_type="string",
        cast=None,
        faker_method="fake()->uuid()",
        validation_rules=["uuid"],
    ),
    "json": TypeMapping(
        migration_method="json",
        migration_args=[],
        php_type="array",
        cast="'array'",
        faker_method="[]",
        validation_rules=["array"],
    ),
    "decimal": TypeMapping(
        migration_method="decimal",
        migration_args=[10, 2],
        php_type="string",
        cast="'decimal:2'",
        faker_method="fake()->randomFloat(2, 0, 10000)",
        validation_rules=["numeric"],
    ),
}


def get_type_mapping(specql_type: str) -> TypeMapping:
    """
    Get type mapping for a SpecQL type.

    Args:
        specql_type: The SpecQL type string (e.g., 'text', 'text(100)', 'decimal(8,2)')

    Returns:
        TypeMapping with all type information
    """
    # Handle types with parameters like text(100) or decimal(8,2)
    if "(" in specql_type:
        base_type = specql_type.split("(")[0]
        params_str = specql_type.split("(")[1].rstrip(")")
        params = [p.strip() for p in params_str.split(",")]

        if base_type in TYPE_MAPPINGS:
            mapping = TYPE_MAPPINGS[base_type]
            # Create new mapping with custom parameters
            return TypeMapping(
                migration_method=mapping.migration_method,
                migration_args=[int(p) if p.isdigit() else p for p in params],
                php_type=mapping.php_type,
                cast=mapping.cast,
                faker_method=mapping.faker_method,
                validation_rules=mapping.validation_rules.copy(),
            )

    # Return default mapping or text as fallback
    return TYPE_MAPPINGS.get(specql_type, TYPE_MAPPINGS["text"])


def is_reference_type(specql_type: str) -> bool:
    """Check if type is a reference (foreign key)."""
    return specql_type.startswith("ref(")


def get_reference_entity(specql_type: str) -> str:
    """
    Extract entity name from ref() type.

    Example:
        'ref(Company)' -> 'Company'
    """
    if is_reference_type(specql_type):
        return specql_type[4:-1]  # Remove 'ref(' and ')'
    return ""


def is_enum_type(specql_type: str) -> bool:
    """Check if type is an enum."""
    return specql_type.startswith("enum(")


def get_enum_values(specql_type: str) -> list[str]:
    """
    Extract enum values from enum() type.

    Example:
        'enum(lead, qualified, customer)' -> ['lead', 'qualified', 'customer']
    """
    if is_enum_type(specql_type):
        values_str = specql_type[5:-1]  # Remove 'enum(' and ')'
        return [v.strip() for v in values_str.split(",")]
    return []
