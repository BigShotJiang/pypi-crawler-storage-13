"""Laravel generator utilities."""

from .faker_mapper import get_faker_method
from .php_naming import (
    action_to_class_name,
    entity_to_foreign_key,
    entity_to_primary_key,
    entity_to_table_name,
    enum_value_to_case_name,
    field_to_enum_class_name,
    schema_to_namespace,
    to_camel_case,
    to_pascal_case,
    to_snake_case,
)
from .type_mapper import (
    TypeMapping,
    get_enum_values,
    get_reference_entity,
    get_type_mapping,
    is_enum_type,
    is_reference_type,
)

__all__ = [
    "to_pascal_case",
    "to_camel_case",
    "to_snake_case",
    "entity_to_table_name",
    "entity_to_primary_key",
    "entity_to_foreign_key",
    "schema_to_namespace",
    "action_to_class_name",
    "field_to_enum_class_name",
    "enum_value_to_case_name",
    "TypeMapping",
    "get_type_mapping",
    "is_reference_type",
    "get_reference_entity",
    "is_enum_type",
    "get_enum_values",
    "get_faker_method",
]
