"""Faker method mapping for factory generation."""

from .type_mapper import get_type_mapping

# Map field names to specific Faker methods
FIELD_NAME_FAKER_MAP: dict[str, str] = {
    "email": "fake()->unique()->safeEmail()",
    "name": "fake()->name()",
    "first_name": "fake()->firstName()",
    "last_name": "fake()->lastName()",
    "phone": "fake()->phoneNumber()",
    "address": "fake()->address()",
    "city": "fake()->city()",
    "country": "fake()->country()",
    "zip": "fake()->postcode()",
    "postal_code": "fake()->postcode()",
    "company": "fake()->company()",
    "company_name": "fake()->company()",
    "website": "fake()->url()",
    "url": "fake()->url()",
    "description": "fake()->paragraph()",
    "notes": "fake()->paragraph()",
    "title": "fake()->sentence(3)",
    "slug": "fake()->unique()->slug(3)",
    "identifier": "fake()->unique()->slug(3)",
    "username": "fake()->unique()->userName()",
    "password": "fake()->password()",
    "amount": "fake()->randomFloat(2, 10, 1000)",
    "price": "fake()->randomFloat(2, 1, 100)",
    "quantity": "fake()->numberBetween(1, 100)",
    "count": "fake()->numberBetween(1, 100)",
}


def get_faker_method(field_name: str, specql_type: str) -> str:
    """
    Get the appropriate Faker method for a field.

    Args:
        field_name: Name of the field
        specql_type: SpecQL type of the field

    Returns:
        Faker method call as string
    """
    # Check if field name has a specific faker method
    field_lower = field_name.lower()
    if field_lower in FIELD_NAME_FAKER_MAP:
        return FIELD_NAME_FAKER_MAP[field_lower]

    # Check for partial matches
    for key, method in FIELD_NAME_FAKER_MAP.items():
        if key in field_lower:
            return method

    # Fall back to type-based faker
    return get_type_mapping(specql_type).faker_method
