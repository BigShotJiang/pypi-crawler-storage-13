"""Generator for PHP DTO classes."""

from pathlib import Path
from typing import TYPE_CHECKING, Any

from jinja2 import Environment, FileSystemLoader

from .utils import (
    enum_value_to_case_name,
    field_to_enum_class_name,
    get_enum_values,
    get_type_mapping,
    is_enum_type,
    schema_to_namespace,
    to_pascal_case,
)

if TYPE_CHECKING:
    from src.core.ir import EntityIR


class DTOGenerator:
    """Generates PHP DTO files from SpecQL entities."""

    def __init__(self):
        """Initialize the generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.template = self.env.get_template("dto.php.jinja2")

    def generate_from_ir(self, entity: "EntityIR") -> str:
        """Generate DTO from EntityIR.

        Args:
            entity: The EntityIR to generate a DTO for

        Returns:
            Generated PHP DTO code
        """
        from .utils import schema_to_namespace, to_pascal_case

        # Convert EntityIR to the format expected by the template
        fields = {}
        for field in entity.fields:
            # Convert TypeIR back to specql type string for backwards compatibility
            if field.type_ir.category.name == "SCALAR":
                specql_type = field.type_ir.base_type
            elif field.type_ir.category.name == "ENUM":
                enum_values = ", ".join(field.type_ir.enum_values or [])
                specql_type = f"enum({enum_values})"
            elif field.type_ir.category.name == "REFERENCE":
                referenced_entity = field.type_ir.referenced_entity or "Unknown"
                specql_type = f"ref({referenced_entity})"
            else:
                specql_type = field.type_ir.base_type

            fields[field.name] = specql_type

        namespace = schema_to_namespace(entity.schema) if entity.schema else ""
        class_name = f"{to_pascal_case(entity.name)}DTO"

        processed_fields = []
        for field_name, specql_type in fields.items():
            field_info = self._process_field(field_name, specql_type, entity.name, entity.schema)
            processed_fields.append(field_info)

        return self.template.render(
            namespace=namespace,
            class_name=class_name,
            fields=processed_fields,
        )

    def get_class_name(self, entity_name: str) -> str:
        """Get the DTO class name for an entity."""
        return f"{to_pascal_case(entity_name)}DTO"

    def get_file_path(self, entity_name: str, schema: str = "") -> str:
        """Get the relative file path for the DTO."""
        class_name = self.get_class_name(entity_name)
        namespace_path = f"/{schema_to_namespace(schema)}" if schema else ""
        return f"app/DTOs{namespace_path}/{class_name}.php"

    def _process_field(
        self, field_name: str, specql_type: str, entity_name: str, schema: str
    ) -> dict[str, Any]:
        """Process a field to extract PHP type and validation info."""
        type_mapping = get_type_mapping(specql_type)

        field_info = {
            "name": field_name,
            "php_type": type_mapping.migration_method,  # This will be refined
            "cast_method": self._get_cast_method(specql_type),
            "default_value": self._get_default_value(specql_type),
            "validation_rules": self._get_validation_rules(specql_type, entity_name, field_name),
        }

        # Set proper PHP type
        if is_enum_type(specql_type):
            enum_class = field_to_enum_class_name(entity_name, field_name)
            field_info["php_type"] = enum_class
            field_info["cast_method"] = ""  # Enums don't need casting in fromRequest
            field_info["default_value"] = (
                f"{enum_class}::{enum_value_to_case_name(get_enum_values(specql_type)[0])}"
            )
        elif specql_type.startswith("ref("):
            # Reference types
            field_info["php_type"] = "int"  # Assuming foreign keys are integers
        else:
            # Map common types
            type_map = {
                "string": "string",
                "text": "string",
                "int": "int",
                "bigint": "int",
                "decimal": "float",
                "float": "float",
                "bool": "bool",
                "datetime": "string",  # DateTime string
                "date": "string",
                "uuid": "string",
            }
            field_info["php_type"] = type_map.get(specql_type, "string")

        return field_info

    def _get_cast_method(self, specql_type: str) -> str:
        """Get the appropriate cast method for a SpecQL type."""
        if specql_type == "bool":
            return "(bool)"
        elif specql_type in ["int", "bigint"]:
            return "(int)"
        elif specql_type == "decimal":
            return "(float)"
        elif is_enum_type(specql_type):
            return ""  # Enums don't need casting in fromArray
        else:
            return "(string)"

    def _get_default_value(self, specql_type: str) -> str:
        """Get the default value for a SpecQL type."""
        if specql_type == "bool":
            return "false"
        elif specql_type in ["int", "bigint", "decimal", "float"]:
            return "0"
        else:
            return "''"

    def _get_validation_rules(self, specql_type: str, entity_name: str, field_name: str) -> str:
        """Get Laravel validation rules for a SpecQL type."""
        rules = []

        if specql_type == "string":
            rules.append("'max:255'")
        elif specql_type == "text":
            rules.append("'max:255'")  # Text fields also get max length validation
        elif specql_type in ["int", "bigint", "integer"]:
            rules.append("'integer'")
        elif specql_type == "decimal":
            rules.append("'numeric'")
        elif specql_type == "float":
            rules.append("'numeric'")
        elif specql_type in ["bool", "boolean"]:
            rules.append("'boolean'")
        elif specql_type == "datetime":
            rules.append("'date'")
        elif specql_type == "date":
            rules.append("'date'")
        elif specql_type == "uuid":
            rules.append("'uuid'")
        elif is_enum_type(specql_type):
            enum_values = get_enum_values(specql_type)
            enum_class = field_to_enum_class_name(entity_name, field_name)
            enum_cases = [
                f"{enum_class}::{enum_value_to_case_name(value)}" for value in enum_values
            ]
            rules.append(f"Rule::in({', '.join(enum_cases)})")

        return ", ".join(rules) if rules else ""
