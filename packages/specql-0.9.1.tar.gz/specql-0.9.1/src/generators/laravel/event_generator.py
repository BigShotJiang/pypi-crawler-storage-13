"""Generator for PHP Event classes."""

from pathlib import Path
from typing import TYPE_CHECKING

from jinja2 import Environment, FileSystemLoader

from .utils import (
    schema_to_namespace,
    to_camel_case,
    to_pascal_case,
)

if TYPE_CHECKING:
    from src.core.ir import EntityIR


class EventGenerator:
    """Generates PHP Event files from SpecQL entities."""

    def __init__(self):
        """Initialize the generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.template = self.env.get_template("event.php.jinja2")

    def generate_from_ir(self, entity: "EntityIR", event_type: str = "created") -> str:
        """Generate event from EntityIR.

        Args:
            entity: The EntityIR to generate an event for
            event_type: Type of event (e.g., 'created', 'updated', 'deleted')

        Returns:
            Generated PHP event code
        """
        from .utils import schema_to_namespace, to_pascal_case

        namespace = schema_to_namespace(entity.schema) if entity.schema else ""
        entity_class = to_pascal_case(entity.name)
        class_name = f"{entity_class}{to_pascal_case(event_type)}"
        entity_param = to_camel_case(entity.name)

        return self.template.render(
            namespace=namespace,
            entity_class=entity_class,
            class_name=class_name,
            entity_param=entity_param,
        )

    def get_class_name(self, entity_name: str, event_type: str = "created") -> str:
        """Get the event class name for an entity."""
        entity_class = to_pascal_case(entity_name)
        return f"{entity_class}{to_pascal_case(event_type)}"

    def get_file_path(self, entity_name: str, schema: str = "", event_type: str = "created") -> str:
        """Get the relative file path for the event."""
        class_name = self.get_class_name(entity_name, event_type)
        namespace_path = f"/{schema_to_namespace(schema)}" if schema else ""
        return f"app/Events{namespace_path}/{class_name}.php"
