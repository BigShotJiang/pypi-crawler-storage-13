"""Generator for Eloquent Model classes."""

from pathlib import Path
from typing import TYPE_CHECKING

from jinja2 import Environment, FileSystemLoader

from src.core.ir import TypeCategory

from .utils import (
    entity_to_foreign_key,
    entity_to_primary_key,
    entity_to_table_name,
    field_to_enum_class_name,
    get_reference_entity,
    get_type_mapping,
    is_enum_type,
    is_reference_type,
    schema_to_namespace,
    to_pascal_case,
    to_snake_case,
)

if TYPE_CHECKING:
    from src.core.ir import EntityIR, TypeCategory


class ModelGenerator:
    """Generates Eloquent Model files from SpecQL entities."""

    def __init__(self):
        """Initialize the generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.template = self.env.get_template("model.php.jinja2")

    def generate_from_ir(self, entity: "EntityIR") -> str:
        """Generate Eloquent model from EntityIR.

        Args:
            entity: The EntityIR to generate a model for

        Returns:
            Generated PHP model code
        """
        # Build context for template
        context = {
            "entity": entity,
            "class_name": entity.name,
            "namespace": schema_to_namespace(entity.schema),
            "table_name": entity_to_table_name(entity.name),
            "primary_key": entity_to_primary_key(entity.name),
            "fillable": [field.name for field in entity.fields],
            "casts": self._build_enum_casts_from_ir(entity),
            "relationships": self._build_relationships_from_ir(entity),
            "imports": self._build_imports_from_ir(entity),
            "traits": self._build_traits_from_ir(entity),
            "is_multi_tenant": entity.is_multi_tenant,
            "has_soft_delete": True,  # Default for now
        }

        return self.template.render(context)

    def _build_relationships_from_ir(self, entity: "EntityIR") -> list[dict]:
        """Build relationship definitions from EntityIR."""
        relationships = []

        for field in entity.fields:
            if field.type_ir.category == TypeCategory.REFERENCE:
                related_entity = field.type_ir.referenced_entity or "Unknown"
                relationships.append(
                    {
                        "name": related_entity.lower(),
                        "method": to_snake_case(field.name).replace("_id", ""),
                        "type": "belongsTo",
                        "return_type": "BelongsTo",
                        "related": related_entity,
                        "foreign_key": entity_to_foreign_key(related_entity),
                        "owner_key": entity_to_primary_key(related_entity),
                    }
                )

        return relationships

    def _build_enum_casts_from_ir(self, entity: "EntityIR") -> dict[str, str]:
        """Build enum cast definitions from EntityIR."""
        enum_casts = {}

        for field in entity.fields:
            if field.type_ir.category == TypeCategory.ENUM:
                enum_class = field_to_enum_class_name(entity.name, field.name)
                enum_casts[field.name] = f"{enum_class}::class"

        return enum_casts

    def _build_imports_from_ir(self, entity: "EntityIR") -> list[str]:
        """Build import statements from EntityIR."""
        imports = []

        # Always import base Laravel classes
        imports.extend(
            [
                "Illuminate\\Database\\Eloquent\\Model",
                "Illuminate\\Database\\Eloquent\\Relations\\BelongsTo",
            ]
        )

        # Add enum imports
        for field in entity.fields:
            if field.type_ir.category == TypeCategory.ENUM:
                enum_class = field_to_enum_class_name(entity.name, field.name)
                imports.append(f"App\\Enums\\{enum_class}")

        # Add relationship imports if needed
        if any(field.type_ir.category == TypeCategory.REFERENCE for field in entity.fields):
            imports.append("Illuminate\\Database\\Eloquent\\Relations\\HasMany")

        # Add trait imports
        if entity.is_multi_tenant:
            imports.append("App\\Models\\Concerns\\BelongsToTenant")
        if True:  # has_soft_delete
            imports.append("Illuminate\\Database\\Eloquent\\SoftDeletes")

        return sorted(set(imports))

    def _build_traits_from_ir(self, entity: "EntityIR") -> list[str]:
        """Build trait usage from EntityIR."""
        traits = []

        if entity.is_multi_tenant:
            traits.append("BelongsToTenant")
        if True:  # has_soft_delete
            traits.append("SoftDeletes")

        return traits

    def get_file_path(self, entity_name: str, schema: str) -> str:
        """Get the relative file path for the model."""
        class_name = to_pascal_case(entity_name)
        namespace = schema_to_namespace(schema)
        return f"app/Models/{namespace}/{class_name}.php"

    def _build_imports(
        self,
        entity_name: str,
        schema: str,
        fields: dict[str, str],
        is_multi_tenant: bool,
    ) -> set[str]:
        """Build the list of use statements."""
        imports = {
            "Illuminate\\Database\\Eloquent\\Model",
            "Illuminate\\Database\\Eloquent\\SoftDeletes",
        }

        if is_multi_tenant:
            imports.add("App\\Models\\Concerns\\BelongsToTenant")

        # Add enum imports
        for field_name, field_type in fields.items():
            if is_enum_type(field_type):
                enum_class = field_to_enum_class_name(entity_name, field_name)
                imports.add(f"App\\Enums\\{enum_class}")

        # Add relationship imports
        for field_name, field_type in fields.items():
            if is_reference_type(field_type):
                imports.add("Illuminate\\Database\\Eloquent\\Relations\\BelongsTo")
                related_entity = get_reference_entity(field_type)
                namespace = schema_to_namespace(schema)
                imports.add(f"App\\Models\\{namespace}\\{related_entity}")

        return imports

    def _build_traits(self, is_multi_tenant: bool) -> list[str]:
        """Build the list of traits to use."""
        traits = ["SoftDeletes"]
        if is_multi_tenant:
            traits.append("BelongsToTenant")
        return traits

    def _build_fillable(
        self,
        fields: dict[str, str],
        is_multi_tenant: bool,
    ) -> list[str]:
        """Build the list of fillable fields."""
        fillable = ["id", "identifier"]

        for field_name, field_type in fields.items():
            if is_reference_type(field_type):
                # Use foreign key column name
                related_entity = get_reference_entity(field_type)
                fillable.append(entity_to_foreign_key(related_entity))
            else:
                fillable.append(to_snake_case(field_name))

        if is_multi_tenant:
            fillable.append("tenant_id")

        return fillable

    def _build_casts(
        self,
        entity_name: str,
        fields: dict[str, str],
    ) -> dict[str, str]:
        """Build the casts array."""
        casts = {
            "created_at": "'datetime'",
            "updated_at": "'datetime'",
            "deleted_at": "'datetime'",
        }

        for field_name, field_type in fields.items():
            snake_name = to_snake_case(field_name)

            if is_enum_type(field_type):
                enum_class = field_to_enum_class_name(entity_name, field_name)
                casts[snake_name] = f"{enum_class}::class"
            elif not is_reference_type(field_type):
                mapping = get_type_mapping(field_type)
                if mapping.cast:
                    casts[snake_name] = mapping.cast

        return casts

    def _build_relationships(
        self,
        fields: dict[str, str],
        schema: str,
    ) -> list[dict]:
        """Build relationship definitions."""
        relationships = []

        for field_name, field_type in fields.items():
            if is_reference_type(field_type):
                related_entity = get_reference_entity(field_type)
                relationships.append(
                    {
                        "name": related_entity.lower(),
                        "method": to_snake_case(field_name).replace("_id", ""),
                        "type": "belongsTo",
                        "return_type": "BelongsTo",
                        "related": related_entity,
                        "foreign_key": entity_to_foreign_key(related_entity),
                        "owner_key": entity_to_primary_key(related_entity),
                    }
                )

        return relationships
