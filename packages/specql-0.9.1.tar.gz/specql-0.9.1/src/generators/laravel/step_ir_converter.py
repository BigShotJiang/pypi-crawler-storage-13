"""Converter for transforming dict-based action steps to ActionStepIR objects."""

from typing import Any

from src.core.ir.action_ir import ActionStepIR


class StepIRConverter:
    """Converts dict-based action steps to ActionStepIR objects."""

    def convert_step(self, step_dict: dict[str, Any]) -> ActionStepIR:
        """
        Convert a dict-based step to ActionStepIR.

        Args:
            step_dict: Dictionary representation of a step

        Returns:
            ActionStepIR object

        Raises:
            ValueError: If the step type is unsupported or malformed
        """
        step_type = step_dict.get("type", "")
        if not step_type:
            raise ValueError("Step must have a 'type' field")

        # Convert based on step type
        if step_type == "validate":
            return self._convert_validate_step(step_dict)
        elif step_type == "update":
            return self._convert_update_step(step_dict)
        elif step_type == "insert":
            return self._convert_insert_step(step_dict)
        elif step_type == "if":
            return self._convert_if_step(step_dict)
        elif step_type == "call":
            return self._convert_call_step(step_dict)
        elif step_type == "notify":
            return self._convert_notify_step(step_dict)
        elif step_type == "foreach":
            return self._convert_foreach_step(step_dict)
        else:
            raise ValueError(f"Unsupported step type: {step_type}")

    def convert_steps(self, step_dicts: list[dict[str, Any]]) -> list[ActionStepIR]:
        """
        Convert a list of dict-based steps to ActionStepIR objects.

        Args:
            step_dicts: List of dictionary representations of steps

        Returns:
            List of ActionStepIR objects
        """
        return [self.convert_step(step_dict) for step_dict in step_dicts]

    def _convert_validate_step(self, step_dict: dict[str, Any]) -> ActionStepIR:
        """Convert validate step dict to ActionStepIR."""
        # Validate steps can have different formats
        # Format 1: {"type": "validate", "field": "status", "condition": "status = 'lead'"}
        # Format 2: {"type": "validate", "expression": "status = 'lead'"}
        # Format 3: {"type": "validate", "fields": ["name", "email"]} - basic presence validation

        expression = step_dict.get("expression")
        if expression:
            pass  # Use as-is
        else:
            # Try to construct from field/condition
            field = step_dict.get("field", "")
            condition = step_dict.get("condition", "")
            fields = step_dict.get("fields", [])

            if field and condition:
                expression = condition  # Assume condition contains the full expression
            elif fields:
                # Basic presence validation for multiple fields
                conditions = [f"{field} IS NOT NULL" for field in fields]
                expression = " AND ".join(conditions)
            else:
                raise ValueError(
                    "Validate step must have 'expression', 'field'/'condition', or 'fields'"
                )

        return ActionStepIR(step_type="validate", expression=expression)

    def _convert_update_step(self, step_dict: dict[str, Any]) -> ActionStepIR:
        """Convert update step dict to ActionStepIR."""
        target = step_dict.get("target", "")
        updates = step_dict.get("updates", {})
        data = step_dict.get("data", {})

        # Handle different formats
        if data and not updates:
            updates = data  # "data" is an alias for "updates"

        if not target:
            # If no target specified, assume it's updating the current entity
            target = "entity"  # This will be resolved by context

        # Handle legacy format where target contains SET clause
        if " SET " in target and not updates:
            # Format: "Entity SET field1 = value1, field2 = value2"
            entity_name, assignments = target.split(" SET ", 1)
            updates = self._parse_assignments(assignments)
            target = entity_name

        if not updates:
            raise ValueError("Update step must have 'updates', 'data', or SET clause in target")

        # Convert updates dict to the format expected by ActionStepIR
        # ActionStepIR expects fields to be a dict[str, str] where values are expressions
        fields = {}
        for field, value in updates.items():
            if isinstance(value, str):
                fields[field] = value
            else:
                # Convert to string representation
                fields[field] = str(value)

        return ActionStepIR(step_type="update", target_entity=target, fields=fields)

    def _convert_insert_step(self, step_dict: dict[str, Any]) -> ActionStepIR:
        """Convert insert step dict to ActionStepIR."""
        target = step_dict.get("target", "")
        fields = step_dict.get("fields", {})

        if not target:
            raise ValueError("Insert step must have 'target'")
        if not fields:
            raise ValueError("Insert step must have 'fields'")

        # Convert fields dict to the format expected by ActionStepIR
        insert_fields = {}
        for field, value in fields.items():
            if isinstance(value, str):
                insert_fields[field] = value
            else:
                insert_fields[field] = str(value)

        return ActionStepIR(step_type="insert", target_entity=target, fields=insert_fields)

    def _convert_if_step(self, step_dict: dict[str, Any]) -> ActionStepIR:
        """Convert if step dict to ActionStepIR."""
        condition = step_dict.get("condition", "")
        then_steps = step_dict.get("then", [])
        else_steps = step_dict.get("else", [])

        if not condition:
            raise ValueError("If step must have 'condition'")

        # Recursively convert nested steps
        then_ir_steps = self.convert_steps(then_steps) if then_steps else []
        else_ir_steps = self.convert_steps(else_steps) if else_steps else []

        return ActionStepIR(
            step_type="if", condition=condition, then_steps=then_ir_steps, else_steps=else_ir_steps
        )

    def _convert_call_step(self, step_dict: dict[str, Any]) -> ActionStepIR:
        """Convert call step dict to ActionStepIR."""
        function = step_dict.get("function", "")
        args = step_dict.get("args", [])

        if not function:
            raise ValueError("Call step must have 'function'")

        # Convert args to strings if they're not already
        str_args = [str(arg) if not isinstance(arg, str) else arg for arg in args]

        return ActionStepIR(step_type="call", function_name=function, function_args=str_args)

    def _convert_notify_step(self, step_dict: dict[str, Any]) -> ActionStepIR:
        """Convert notify step dict to ActionStepIR."""
        # Notify steps in dict format may have different fields
        # For now, create a basic notify step
        return ActionStepIR(step_type="notify")

    def _convert_foreach_step(self, step_dict: dict[str, Any]) -> ActionStepIR:
        """Convert foreach step dict to ActionStepIR."""
        collection = step_dict.get("collection", "")
        item_name = step_dict.get("item", "")
        loop_steps = step_dict.get("do", [])

        if not collection:
            raise ValueError("Foreach step must have 'collection'")
        if not item_name:
            raise ValueError("Foreach step must have 'item'")
        if not loop_steps:
            raise ValueError("Foreach step must have 'do' steps")

        # Recursively convert nested steps
        loop_ir_steps = self.convert_steps(loop_steps)

        return ActionStepIR(
            step_type="foreach",
            collection=collection,
            item_name=item_name,
            loop_steps=loop_ir_steps,
        )

    def _parse_assignments(self, assignments: str) -> dict[str, str]:
        """Parse assignment string into field-value pairs."""
        update_dict = {}

        # Split by comma, but be careful with commas inside function calls
        parts = []
        current = ""
        paren_depth = 0

        for char in assignments:
            if char == "(":
                paren_depth += 1
                current += char
            elif char == ")":
                paren_depth -= 1
                current += char
            elif char == "," and paren_depth == 0:
                parts.append(current.strip())
                current = ""
            else:
                current += char

        if current.strip():
            parts.append(current.strip())

        for part in parts:
            if " = " in part:
                field, value = part.split(" = ", 1)
                field = field.strip()
                value = value.strip()
                update_dict[field] = value

        return update_dict
