"""Generator for PHP Controller classes."""

from pathlib import Path
from typing import TYPE_CHECKING

from jinja2 import Environment, FileSystemLoader

from .utils import (
    schema_to_namespace,
    to_camel_case,
    to_pascal_case,
)

if TYPE_CHECKING:
    from src.core.ir import EntityIR


class ControllerGenerator:
    """Generates PHP Controller files from SpecQL entities."""

    def __init__(self):
        """Initialize the generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.template = self.env.get_template("controller.php.jinja2")

    def generate_from_ir(self, entity: "EntityIR") -> str:
        """Generate controller from EntityIR.

        Args:
            entity: The EntityIR to generate a controller for

        Returns:
            Generated PHP controller code
        """
        from .utils import schema_to_namespace, to_pascal_case

        namespace = schema_to_namespace(entity.schema) if entity.schema else ""

        # Generate class names
        model = to_pascal_case(entity.name)
        class_name = f"{model}Controller"
        store_request = f"{model}StoreRequest"
        update_request = f"{model}UpdateRequest"
        resource = f"{model}Resource"

        # Generate variable names
        instance = to_camel_case(entity.name)
        collection = f"{instance}s"

        return self.template.render(
            namespace=namespace,
            model=model,
            class_name=class_name,
            store_request=store_request,
            update_request=update_request,
            resource=resource,
            instance=instance,
            collection=collection,
        )

    def get_class_name(self, entity_name: str) -> str:
        """Get the Controller class name for an entity."""
        model = to_pascal_case(entity_name)
        return f"{model}Controller"

    def get_file_path(self, entity_name: str, schema: str = "") -> str:
        """Get the relative file path for the Controller."""
        class_name = self.get_class_name(entity_name)
        namespace_path = f"/{schema_to_namespace(schema)}" if schema else ""
        return f"app/Http/Controllers{namespace_path}/{class_name}.php"
