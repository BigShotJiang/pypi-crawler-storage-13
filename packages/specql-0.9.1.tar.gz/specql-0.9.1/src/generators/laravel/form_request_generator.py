"""Generator for PHP Form Request classes."""

from pathlib import Path
from typing import TYPE_CHECKING, Any

from jinja2 import Environment, FileSystemLoader

from .utils import (
    enum_value_to_case_name,
    field_to_enum_class_name,
    get_enum_values,
    is_enum_type,
    schema_to_namespace,
    to_pascal_case,
)

if TYPE_CHECKING:
    from src.core.ir import EntityIR


class FormRequestGenerator:
    """Generates PHP Form Request files from SpecQL entities."""

    def __init__(self):
        """Initialize the generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.template = self.env.get_template("form_request.php.jinja2")

    def generate_store_request_from_ir(self, entity: "EntityIR") -> str:
        """Generate a store request from EntityIR."""
        from .utils import schema_to_namespace, to_pascal_case

        namespace = schema_to_namespace(entity.schema) if entity.schema else ""
        class_name = f"{to_pascal_case(entity.name)}StoreRequest"

        processed_fields = []
        for field in entity.fields:
            # Convert TypeIR to specql type string for validation rules
            if field.type_ir.category.name == "SCALAR":
                specql_type = field.type_ir.base_type
            elif field.type_ir.category.name == "ENUM":
                enum_values = ", ".join(field.type_ir.enum_values or [])
                specql_type = f"enum({enum_values})"
            elif field.type_ir.category.name == "REFERENCE":
                referenced_entity = field.type_ir.referenced_entity or "Unknown"
                specql_type = f"ref({referenced_entity})"
            else:
                specql_type = field.type_ir.base_type

            field_info = self._process_field(field.name, specql_type, entity.name, "store")
            processed_fields.append(field_info)

        return self.template.render(
            namespace=namespace,
            class_name=class_name,
            fields=processed_fields,
        )

    def generate_update_request_from_ir(self, entity: "EntityIR") -> str:
        """Generate an update request from EntityIR."""
        from .utils import schema_to_namespace, to_pascal_case

        namespace = schema_to_namespace(entity.schema) if entity.schema else ""
        class_name = f"{to_pascal_case(entity.name)}UpdateRequest"

        processed_fields = []
        for field in entity.fields:
            # Convert TypeIR to specql type string for validation rules
            if field.type_ir.category.name == "SCALAR":
                specql_type = field.type_ir.base_type
            elif field.type_ir.category.name == "ENUM":
                enum_values = ", ".join(field.type_ir.enum_values or [])
                specql_type = f"enum({enum_values})"
            elif field.type_ir.category.name == "REFERENCE":
                referenced_entity = field.type_ir.referenced_entity or "Unknown"
                specql_type = f"ref({referenced_entity})"
            else:
                specql_type = field.type_ir.base_type

            field_info = self._process_field(field.name, specql_type, entity.name, "update")
            processed_fields.append(field_info)

        return self.template.render(
            namespace=namespace,
            class_name=class_name,
            fields=processed_fields,
        )

    def get_class_name(self, entity_name: str, action: str = "store") -> str:
        """Get the Form Request class name for an entity."""
        return f"{to_pascal_case(entity_name)}{to_pascal_case(action)}Request"

    def get_file_path(self, entity_name: str, schema: str = "", action: str = "store") -> str:
        """Get the relative file path for the Form Request."""
        class_name = self.get_class_name(entity_name, action)
        namespace_path = f"/{schema_to_namespace(schema)}" if schema else ""
        return f"app/Http/Requests{namespace_path}/{class_name}.php"

    def _process_field(
        self, field_name: str, specql_type: str, entity_name: str, action: str
    ) -> dict[str, Any]:
        """Process a field to extract validation and display info."""
        field_info = {
            "name": field_name,
            "label": self._field_to_label(field_name),
            "validation_rules": self._get_validation_rules(
                specql_type, entity_name, field_name, action
            ),
            "custom_messages": self._get_custom_messages(specql_type, field_name),
        }

        return field_info

    def _field_to_label(self, field_name: str) -> str:
        """Convert field name to human-readable label."""
        # Replace underscores with spaces and capitalize
        return " ".join(word.capitalize() for word in field_name.split("_"))

    def _get_validation_rules(
        self, specql_type: str, entity_name: str, field_name: str, action: str
    ) -> str:
        """Get Laravel validation rules for a SpecQL type."""
        rules = []

        # Basic type validation
        if specql_type == "string":
            rules.append("'max:255'")
        elif specql_type == "text":
            rules.append("'max:255'")  # Text fields also get max length validation
        elif specql_type in ["int", "bigint"]:
            rules.append("'integer'")
        elif specql_type == "decimal":
            rules.append("'numeric'")
        elif specql_type == "float":
            rules.append("'numeric'")
        elif specql_type == "bool":
            rules.append("'boolean'")
        elif specql_type == "datetime":
            rules.append("'date'")
        elif specql_type == "date":
            rules.append("'date'")
        elif specql_type == "uuid":
            rules.append("'uuid'")
        elif is_enum_type(specql_type):
            enum_values = get_enum_values(specql_type)
            enum_class = field_to_enum_class_name(entity_name, field_name)
            enum_cases = [
                f"{enum_class}::{enum_value_to_case_name(value)}" for value in enum_values
            ]
            rules.append(f"Rule::in({', '.join(enum_cases)})")

        # Action-specific rules
        if action == "update":
            rules.append("'sometimes'")  # Fields are optional on update

        return ", ".join(rules) if rules else ""

    def _get_custom_messages(self, specql_type: str, field_name: str) -> dict[str, str]:
        """Get custom validation messages for a field."""
        messages = {}

        if specql_type in ["string", "text"]:
            messages["max"] = (
                f"The {self._field_to_label(field_name).lower()} may not be greater than 255 characters."
            )
        elif specql_type == "uuid":
            messages["uuid"] = (
                f"The {self._field_to_label(field_name).lower()} must be a valid UUID."
            )

        return messages
