"""Generator for Laravel Factory files."""

from pathlib import Path
from typing import TYPE_CHECKING

from jinja2 import Environment, FileSystemLoader

from .utils import (
    entity_to_foreign_key,
    entity_to_primary_key,
    enum_value_to_case_name,
    field_to_enum_class_name,
    get_enum_values,
    get_faker_method,
    get_reference_entity,
    is_enum_type,
    is_reference_type,
    schema_to_namespace,
    to_camel_case,
    to_pascal_case,
    to_snake_case,
)

if TYPE_CHECKING:
    from src.core.ir import EntityIR


class FactoryGenerator:
    """Generates Laravel Factory files from SpecQL entities."""

    def __init__(self):
        """Initialize the generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.template = self.env.get_template("factory.php.jinja2")

    def generate_from_ir(self, entity: "EntityIR") -> str:
        """Generate factory from EntityIR.

        Args:
            entity: The EntityIR to generate a factory for

        Returns:
            Generated PHP factory code
        """
        from .utils import schema_to_namespace, to_pascal_case

        # Convert EntityIR to the format expected by the template
        fields = {}
        for field in entity.fields:
            # Convert TypeIR back to specql type string for backwards compatibility
            if field.type_ir.category.name == "SCALAR":
                specql_type = field.type_ir.base_type
            elif field.type_ir.category.name == "ENUM":
                enum_values = ", ".join(field.type_ir.enum_values or [])
                specql_type = f"enum({enum_values})"
            elif field.type_ir.category.name == "REFERENCE":
                referenced_entity = field.type_ir.referenced_entity or "Unknown"
                specql_type = f"ref({referenced_entity})"
            else:
                specql_type = field.type_ir.base_type

            fields[field.name] = specql_type

        class_name = f"{to_pascal_case(entity.name)}Factory"
        model_class = to_pascal_case(entity.name)
        namespace = schema_to_namespace(entity.schema)

        imports = self._build_imports(entity.name, entity.schema, fields)
        definition_fields = self._build_definition_fields(
            entity.name, fields, entity.is_multi_tenant
        )
        states = self._build_states(entity.name, fields)
        relation_methods = self._build_relation_methods(fields, entity.schema)

        return self.template.render(
            class_name=class_name,
            model_class=model_class,
            namespace=namespace,
            imports=sorted(imports),
            definition_fields=definition_fields,
            states=states,
            relation_methods=relation_methods,
        )

    def get_file_path(self, entity_name: str, schema: str) -> str:
        """Get the relative file path for the factory."""
        class_name = f"{to_pascal_case(entity_name)}Factory"
        namespace = schema_to_namespace(schema)
        return f"database/factories/{namespace}/{class_name}.php"

    def _build_imports(
        self,
        entity_name: str,
        schema: str,
        fields: dict[str, str],
    ) -> set[str]:
        """Build import statements."""
        namespace = schema_to_namespace(schema)
        model_class = to_pascal_case(entity_name)

        imports = {
            "Illuminate\\Database\\Eloquent\\Factories\\Factory",
            f"App\\Models\\{namespace}\\{model_class}",
        }

        for field_name, field_type in fields.items():
            if is_enum_type(field_type):
                enum_class = field_to_enum_class_name(entity_name, field_name)
                imports.add(f"App\\Enums\\{enum_class}")
            elif is_reference_type(field_type):
                related = get_reference_entity(field_type)
                imports.add(f"App\\Models\\{namespace}\\{related}")

        return imports

    def _build_definition_fields(
        self,
        entity_name: str,
        fields: dict[str, str],
        is_multi_tenant: bool,
    ) -> list[dict]:
        """Build definition array fields."""
        definition = [
            {"name": "identifier", "faker": "fake()->unique()->slug(3)"},
        ]

        for field_name, field_type in fields.items():
            snake_name = to_snake_case(field_name)

            if is_reference_type(field_type):
                related = get_reference_entity(field_type)
                fk = entity_to_foreign_key(related)
                definition.append(
                    {
                        "name": fk,
                        "faker": f"{related}::factory()",
                    }
                )
            elif is_enum_type(field_type):
                enum_class = field_to_enum_class_name(entity_name, field_name)
                definition.append(
                    {
                        "name": snake_name,
                        "faker": f"fake()->randomElement({enum_class}::cases())",
                    }
                )
            else:
                faker = get_faker_method(field_name, field_type)
                definition.append(
                    {
                        "name": snake_name,
                        "faker": faker,
                    }
                )

        if is_multi_tenant:
            definition.append(
                {
                    "name": "tenant_id",
                    "faker": "fake()->uuid()",
                }
            )

        return definition

    def _build_states(
        self,
        entity_name: str,
        fields: dict[str, str],
    ) -> list[dict]:
        """Build state methods for enum values."""
        states = []

        for field_name, field_type in fields.items():
            if is_enum_type(field_type):
                snake_name = to_snake_case(field_name)
                enum_class = field_to_enum_class_name(entity_name, field_name)
                values = get_enum_values(field_type)

                for value in values:
                    case_name = enum_value_to_case_name(value)
                    states.append(
                        {
                            "method": f"as{case_name}",
                            "description": f"Set {field_name} to {value}.",
                            "field": snake_name,
                            "value": f"{enum_class}::{case_name}",
                        }
                    )

        return states

    def _build_relation_methods(
        self,
        fields: dict[str, str],
        schema: str,
    ) -> list[dict]:
        """Build relation helper methods."""
        methods = []

        for field_name, field_type in fields.items():
            if is_reference_type(field_type):
                related = get_reference_entity(field_type)
                methods.append(
                    {
                        "name": related,
                        "type": related,
                        "param": to_camel_case(related),
                        "foreign_key": entity_to_foreign_key(related),
                        "primary_key": entity_to_primary_key(related),
                    }
                )

        return methods
