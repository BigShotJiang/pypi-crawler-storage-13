"""Generator for Laravel Migration files."""

from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

from jinja2 import Environment, FileSystemLoader

from src.core.ir import TypeCategory

from .utils import (
    entity_to_foreign_key,
    entity_to_primary_key,
    entity_to_table_name,
    get_enum_values,
    get_reference_entity,
    get_type_mapping,
    is_enum_type,
    is_reference_type,
    to_snake_case,
)

if TYPE_CHECKING:
    from src.core.ir import EntityIR, TypeCategory


class MigrationGenerator:
    """Generates Laravel Migration files from SpecQL entities."""

    def __init__(self):
        """Initialize the generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.template = self.env.get_template("migration.php.jinja2")

    def generate_from_ir(self, entity: "EntityIR") -> str:
        """Generate migration from EntityIR.

        Args:
            entity: The EntityIR to generate a migration for

        Returns:
            Generated PHP migration code
        """
        # Build context for template
        context = {
            "entity": entity,
            "schema": entity.schema,
            "table_name": entity_to_table_name(entity.name),
            "primary_key": entity_to_primary_key(entity.name),
            "columns": self._build_columns_from_ir(entity),
            "foreign_keys": self._build_foreign_keys_from_ir(entity),
            "indexes": self._build_indexes_from_ir(entity),
            "is_multi_tenant": entity.is_multi_tenant,
        }

        return self.template.render(context)

    def _build_columns_from_ir(self, entity: "EntityIR") -> list[dict]:
        """Build column definitions from EntityIR."""
        columns = []

        for field in entity.fields:
            snake_name = to_snake_case(field.name)

            if field.type_ir.category == TypeCategory.REFERENCE:
                # Foreign key column
                related_entity = field.type_ir.referenced_entity or "Unknown"
                fk_column = entity_to_foreign_key(related_entity)
                columns.append(
                    {
                        "definition": f"$table->unsignedBigInteger('{fk_column}')",
                    }
                )
            elif field.type_ir.category == TypeCategory.ENUM:
                # Enum stored as string with default
                values = field.type_ir.enum_values or []
                default = values[0] if values else ""
                columns.append(
                    {
                        "definition": f"$table->string('{snake_name}', 50)->default('{default}')",
                    }
                )
            else:
                # Regular column
                mapping = get_type_mapping(field.type_ir.base_type)
                definition = self._build_column_definition(
                    snake_name,
                    mapping.migration_method,
                    mapping.migration_args,
                )
                columns.append({"definition": definition})

        return columns

    def _build_foreign_keys_from_ir(self, entity: "EntityIR") -> list[dict]:
        """Build foreign key definitions from EntityIR."""
        foreign_keys = []
        table_name = entity_to_table_name(entity.name)

        for field in entity.fields:
            if field.type_ir.category == TypeCategory.REFERENCE:
                related_entity = field.type_ir.referenced_entity or "Unknown"
                fk_column = entity_to_foreign_key(related_entity)
                related_table = entity_to_table_name(related_entity)
                related_pk = entity_to_primary_key(related_entity)

                foreign_keys.append(
                    {
                        "column": fk_column,
                        "constraint_name": f"fk_{table_name}_{to_snake_case(field.name)}",
                        "references": related_pk,
                        "on_table": related_table,
                        "on_delete": "restrict",
                    }
                )

        return foreign_keys

    def _build_indexes_from_ir(self, entity: "EntityIR") -> list[dict]:
        """Build index definitions from EntityIR."""
        indexes = []
        table_name = entity_to_table_name(entity.name)

        for field in entity.fields:
            snake_name = to_snake_case(field.name)

            if field.type_ir.category == field.type_ir.category.REFERENCE:
                # Index foreign key columns
                related_entity = field.type_ir.referenced_entity or "Unknown"
                fk_column = entity_to_foreign_key(related_entity)
                indexes.append(
                    {
                        "column": fk_column,
                        "name": f"idx_{table_name}_{fk_column}",
                    }
                )
            elif field.type_ir.category == TypeCategory.ENUM:
                # Index enum columns
                indexes.append(
                    {
                        "column": snake_name,
                        "name": f"idx_{table_name}_{snake_name}",
                    }
                )

        return indexes

    def get_file_path(self, entity_name: str, sequence: int = 1) -> str:
        """Get the relative file path for the migration."""
        table_name = entity_to_table_name(entity_name)
        timestamp = datetime.now().strftime("%Y_%m_%d")
        return f"database/migrations/{timestamp}_{sequence:06d}_create_{table_name}_table.php"

    def _build_columns(self, fields: dict[str, str]) -> list[dict]:
        """Build column definitions."""
        columns = []

        for field_name, field_type in fields.items():
            snake_name = to_snake_case(field_name)

            if is_reference_type(field_type):
                # Foreign key column
                related_entity = get_reference_entity(field_type)
                fk_column = entity_to_foreign_key(related_entity)
                columns.append(
                    {
                        "definition": f"$table->unsignedBigInteger('{fk_column}')",
                    }
                )
            elif is_enum_type(field_type):
                # Enum stored as string with default
                values = get_enum_values(field_type)
                default = values[0] if values else ""
                columns.append(
                    {
                        "definition": f"$table->string('{snake_name}', 50)->default('{default}')",
                    }
                )
            else:
                # Regular column
                mapping = get_type_mapping(field_type)
                definition = self._build_column_definition(
                    snake_name,
                    mapping.migration_method,
                    mapping.migration_args,
                )
                columns.append({"definition": definition})

        return columns

    def _build_column_definition(
        self,
        name: str,
        method: str,
        args: list,
    ) -> str:
        """Build a single column definition."""
        if args:
            args_str = ", ".join(str(a) for a in args)
            return f"$table->{method}('{name}', {args_str})"
        return f"$table->{method}('{name}')"

    def _build_foreign_keys(
        self,
        fields: dict[str, str],
        table_name: str,
    ) -> list[dict]:
        """Build foreign key definitions."""
        foreign_keys = []

        for field_name, field_type in fields.items():
            if is_reference_type(field_type):
                related_entity = get_reference_entity(field_type)
                fk_column = entity_to_foreign_key(related_entity)
                related_table = entity_to_table_name(related_entity)
                related_pk = entity_to_primary_key(related_entity)

                foreign_keys.append(
                    {
                        "column": fk_column,
                        "constraint_name": f"fk_{table_name}_{to_snake_case(field_name)}",
                        "references": related_pk,
                        "on_table": related_table,
                        "on_delete": "restrict",
                    }
                )

        return foreign_keys

    def _build_indexes(
        self,
        fields: dict[str, str],
        table_name: str,
    ) -> list[dict]:
        """Build index definitions."""
        indexes = []

        for field_name, field_type in fields.items():
            snake_name = to_snake_case(field_name)

            if is_reference_type(field_type):
                # Index foreign key columns
                related_entity = get_reference_entity(field_type)
                fk_column = entity_to_foreign_key(related_entity)
                indexes.append(
                    {
                        "column": fk_column,
                        "name": f"idx_{table_name}_{fk_column}",
                    }
                )
            elif is_enum_type(field_type):
                # Index enum columns
                indexes.append(
                    {
                        "column": snake_name,
                        "name": f"idx_{table_name}_{snake_name}",
                    }
                )

        return indexes
