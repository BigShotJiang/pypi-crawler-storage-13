"""Generator for Laravel Action classes."""

from pathlib import Path
from typing import TYPE_CHECKING, Any

from jinja2 import Environment, FileSystemLoader

from .step_ir_converter import StepIRConverter
from .utils import (
    action_to_class_name,
    schema_to_namespace,
    to_camel_case,
    to_pascal_case,
)

if TYPE_CHECKING:
    from src.core.ir import ActionIR, EntityIR


class ActionGenerator:
    """Generates Laravel Action classes from SpecQL actions."""

    def __init__(self):
        """Initialize the generator with Jinja2 environment."""
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.template = self.env.get_template("action.php.jinja2")

        # Initialize IR converter
        self.step_converter = StepIRConverter()

        # Import step compiler locally to avoid circular imports
        from ..targets.laravel.step_compiler import LaravelStepCompiler

        self.step_compiler = LaravelStepCompiler()

    def generate_from_ir(self, entity: "EntityIR", action: "ActionIR") -> str:
        """Generate action from EntityIR and ActionIR.

        Args:
            entity: The EntityIR for context
            action: The ActionIR to generate code for

        Returns:
            Generated PHP action code
        """
        from .utils import action_to_class_name, schema_to_namespace

        # Convert EntityIR to entity_def format for context
        entity_def = {"name": entity.name, "schema": entity.schema, "fields": {}}

        for field in entity.fields:
            # Convert TypeIR back to specql type string for backwards compatibility
            if field.type_ir.category.name == "SCALAR":
                specql_type = field.type_ir.base_type
            elif field.type_ir.category.name == "ENUM":
                enum_values = ", ".join(field.type_ir.enum_values or [])
                specql_type = f"enum({enum_values})"
            elif field.type_ir.category.name == "REFERENCE":
                referenced_entity = field.type_ir.referenced_entity or "Unknown"
                specql_type = f"ref({referenced_entity})"
            else:
                specql_type = field.type_ir.base_type

            entity_def["fields"][field.name] = specql_type

        class_name = action_to_class_name(action.name)
        entity_class = to_pascal_case(entity.name)
        entity_param = to_camel_case(entity.name)
        namespace = schema_to_namespace(entity.schema)

        # Compile action steps using ActionIR.steps directly
        result = self.step_compiler.compile_steps(
            action.steps,  # ActionIR.steps is already a list of ActionStepIR
            {
                "entity": entity_def,
                "schema": entity.schema,
            },
        )
        compiled_steps = result.code.split("\n") if result.code else []

        return self.template.render(
            class_name=class_name,
            entity_class=entity_class,
            entity_param=entity_param,
            namespace=namespace,
            action_name=action.name,
            steps=compiled_steps,
        )

    def get_file_path(self, entity_name: str, action_name: str, schema: str) -> str:
        """Get the relative file path for the action."""
        class_name = action_to_class_name(action_name)
        namespace = schema_to_namespace(schema)
        return f"app/Actions/{namespace}/{class_name}.php"

    def _compile_steps(self, steps: list[dict[str, Any]], context: dict[str, Any]) -> list[str]:
        """Compile action steps into PHP code."""
        # Convert dict-based steps to ActionStepIR objects
        ir_steps = self.step_converter.convert_steps(steps)

        # Compile using the unified step compiler
        result = self.step_compiler.compile_steps(ir_steps, context)

        # Return the compiled code as a list of strings (split by newlines)
        return result.code.split("\n") if result.code else []
