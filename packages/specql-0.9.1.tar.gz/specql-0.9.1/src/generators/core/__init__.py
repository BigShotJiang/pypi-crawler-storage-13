"""Core generator infrastructure.

This package contains the shared infrastructure used by all target generators,
including the Intermediate Representation (IR) and analysis tools.
"""
