"""Core SpecQL functionality.

This package contains the core parsing, AST models, and intermediate representations
used throughout SpecQL.
"""

# Import submodules for easier access
from . import ir
