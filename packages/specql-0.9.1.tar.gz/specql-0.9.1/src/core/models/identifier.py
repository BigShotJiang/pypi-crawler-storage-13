"""
Data models for identifier specifications.

These classes represent the structure of an identifier pattern
that we extract from SQL and write to YAML.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TransformType(Enum):
    """
    How a field value is transformed when building the identifier.

    Examples:
    - NONE: Use the value as-is ("john@email.com" stays "john@email.com")
    - SLUGIFY: Convert to URL-safe ("My Company" becomes "my-company")
    - DATERANGE: Format a date ("2025-01-01" becomes "2025-01-01→2025-12-31")
    """

    NONE = "none"
    SLUGIFY = "slugify"
    DATERANGE = "daterange"
    DECIMAL = "decimal"
    STRIP_PARENT_PREFIX = "strip_parent_prefix"
    LPAD = "lpad"


@dataclass
class IdentifierComponent:
    """
    One piece of an identifier pattern.

    Example: In pattern "{org}|{email}", there are two components:
    - org (the parent's identifier)
    - email (a field from this entity)
    """

    field: str  # Field name, e.g., "email"
    transform: TransformType = TransformType.NONE  # How to transform it
    format: str | None = None  # Date format string
    precision: int | None = None  # Decimal places
    parent_field: str | None = None  # For strip_parent_prefix
    padding: int | None = None  # For lpad (left padding)


@dataclass
class HierarchicalConfig:
    """
    Config for entities that have parent-child relationships.

    Example: Locations can be nested: "warehouse.zone-1.shelf-a"
    """

    enabled: bool = False
    separator: str = "."  # What separates levels
    child_pattern: str | None = None  # Pattern for children


@dataclass
class OrderingConfig:
    """
    Config for ordered hierarchies that need numeric prefixes.

    Example: "001-first-item", "002-second-item"
    """

    enabled: bool = False
    field: str = "int_ordered"  # Field containing order number
    padding: int = 3  # Pad to this many digits
    default: int = 10  # Default increment


@dataclass
class IdentifierSpec:
    """
    Complete specification for how an entity's identifier is built.

    This is what we extract from SQL and write to YAML.
    """

    pattern: str  # The pattern template
    parent: str | None = None  # Parent entity name
    components: list[IdentifierComponent] = field(default_factory=list)
    deduplicate: bool = True  # Add #2, #3 for duplicates?
    hierarchical: HierarchicalConfig | None = None
    ordering: OrderingConfig | None = None
    composition_separator: str = "∘"  # Separator for complex fields

    def to_yaml_dict(self) -> dict[str, Any]:
        """
        Convert this spec to a dictionary for YAML output.

        Returns:
            Dictionary that can be dumped to YAML
        """
        result: dict[str, Any] = {"pattern": self.pattern}

        if self.parent:
            result["parent"] = self.parent

        if self.components:
            result["components"] = []
            for comp in self.components:
                comp_dict: dict[str, Any] = {"field": comp.field}
                if comp.transform != TransformType.NONE:
                    comp_dict["transform"] = comp.transform.value
                if comp.format:
                    comp_dict["format"] = comp.format
                if comp.precision:
                    comp_dict["precision"] = comp.precision
                if comp.parent_field:
                    comp_dict["parent_field"] = comp.parent_field
                result["components"].append(comp_dict)

        if not self.deduplicate:
            result["deduplicate"] = False

        if self.hierarchical and self.hierarchical.enabled:
            result["hierarchical"] = {
                "enabled": True,
                "separator": self.hierarchical.separator,
            }
            if self.hierarchical.child_pattern:
                result["hierarchical"]["child_pattern"] = self.hierarchical.child_pattern

        if self.ordering and self.ordering.enabled:
            result["ordering"] = {
                "enabled": True,
                "field": self.ordering.field,
                "padding": self.ordering.padding,
                "default": self.ordering.default,
            }

        return result
