"""
Data models for view specifications.

These classes represent different types of database views
that we detect during reverse engineering.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ViewType(Enum):
    """
    Types of views we can detect.

    - REGULAR: CREATE VIEW (live query)
    - TABLE_VIEW: Physical table used as a cached view
    - MATERIALIZED: CREATE MATERIALIZED VIEW (snapshot)
    """

    REGULAR = "view"
    TABLE_VIEW = "table_view"
    MATERIALIZED = "materialized_view"


class RefreshStrategy(Enum):
    """How a materialized view is refreshed."""

    MANUAL = "manual"
    ON_COMMIT = "on_commit"
    PERIODIC = "periodic"


@dataclass
class ViewColumn:
    """A column in a view's SELECT clause."""

    name: str  # Column name or expression
    alias: str | None = None  # AS alias


@dataclass
class ViewFilter:
    """A WHERE clause condition."""

    expression: str  # e.g., "deleted_at IS NULL"


@dataclass
class ViewIndex:
    """An index on a view."""

    columns: list[str]  # Columns in the index
    index_type: str = "btree"  # btree, gist, gin, hash
    unique: bool = False


@dataclass
class IncludedEntity:
    """
    An entity included in a table view's denormalization.

    Table views often "flatten" related entities into JSONB.
    """

    entity: str  # Entity name
    fields: list[str]  # Which fields to include
    alias: str | None = None


@dataclass
class ViewSpec:
    """
    Complete specification for a view.

    This captures everything we need to know about a view
    to recreate it from YAML.
    """

    name: str  # View name (e.g., "v_contact")
    view_type: ViewType  # Regular, table view, or materialized

    # For regular views
    columns: list[ViewColumn] = field(default_factory=list)
    filters: list[ViewFilter] = field(default_factory=list)
    joins: list[str] = field(default_factory=list)

    # For table views
    flags: list[str] = field(default_factory=list)  # e.g., is_current, is_past
    data_column: bool = False  # Has JSONB data column?
    cache_invalidation: bool = False  # Has cache trigger?
    includes: list[IncludedEntity] = field(default_factory=list)

    # For materialized views
    refresh: RefreshStrategy = RefreshStrategy.MANUAL
    indexes: list[ViewIndex] = field(default_factory=list)

    def to_yaml_dict(self) -> dict[str, Any]:
        """
        Convert to YAML-serializable dictionary.

        Returns:
            Dictionary for YAML output
        """
        result: dict[str, Any] = {
            "name": self.name,
            "type": self.view_type.value,
        }

        if self.view_type == ViewType.REGULAR:
            if self.filters:
                result["filters"] = [f.expression for f in self.filters]
            if self.columns:
                result["columns"] = [c.alias or c.name for c in self.columns]

        elif self.view_type == ViewType.TABLE_VIEW:
            if self.flags:
                result["flags"] = self.flags
            if self.data_column:
                result["data_column"] = True
            if self.cache_invalidation:
                result["cache_invalidation"] = True
            if self.includes:
                result["includes"] = [
                    {"entity": i.entity, "fields": i.fields} for i in self.includes
                ]

        elif self.view_type == ViewType.MATERIALIZED:
            result["refresh"] = self.refresh.value
            if self.indexes:
                result["indexes"] = [
                    {"columns": idx.columns, "type": idx.index_type} for idx in self.indexes
                ]

        return result

    @classmethod
    def get_parent_entity(cls, view_name: str) -> str | None:
        """
        Extract the parent entity name from a view name.

        Examples:
            "v_contact" -> "contact"
            "tv_machine" -> "machine"
            "mv_organization" -> "organization"

        Args:
            view_name: The view's name

        Returns:
            Parent entity name, or None if can't determine
        """
        prefixes = ["v_", "tv_", "mv_"]
        for prefix in prefixes:
            if view_name.startswith(prefix):
                return view_name[len(prefix) :]
        return None
