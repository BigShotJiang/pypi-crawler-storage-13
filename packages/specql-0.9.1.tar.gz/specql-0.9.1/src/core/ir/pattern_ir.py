"""Pattern Intermediate Representation."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class PatternIR:
    """Detected patterns on an entity.

    Patterns are architectural conventions detected either from:
    - YAML declarations (forward generation)
    - SQL/code analysis (reverse engineering)

    Supported Patterns:
        - trinity: pk_*/id/identifier convention
        - audit_trail: created_at, updated_at, created_by, updated_by
        - soft_delete: deleted_at column
        - hierarchy: ltree or adjacency list
        - scd: Slowly Changing Dimension (Type 2)
        - info_instance: *_info vocabulary tables
        - translation: *_tl translation tables
    """

    patterns: list[str]
    confidence: float  # 0.0 to 1.0

    # Additional pattern metadata
    details: dict[str, Any] = field(default_factory=dict)

    # Hierarchy pattern specifics
    hierarchy_type: str | None = None  # 'ltree', 'adjacency_list', 'nested_set'
    hierarchy_parent_column: str | None = None

    # SCD pattern specifics
    scd_effective_from: str | None = None
    scd_effective_to: str | None = None

    def has_pattern(self, pattern_name: str) -> bool:
        """Check if a specific pattern was detected."""
        return pattern_name in self.patterns

    @property
    def is_high_confidence(self) -> bool:
        """True if confidence is above threshold (0.8)."""
        return self.confidence >= 0.8
