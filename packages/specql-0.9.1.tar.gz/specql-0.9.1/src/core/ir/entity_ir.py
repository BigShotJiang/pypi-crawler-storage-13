"""Entity Intermediate Representation.

The canonical representation of a SpecQL entity that all target generators consume.
This is the bridge between the parser (which produces Entity objects) and the
code generators (which need a clean, target-agnostic representation).
"""

from dataclasses import dataclass, field

from .action_ir import ActionIR
from .field_ir import FieldIR
from .identifier_ir import IdentifierIR
from .pattern_ir import PatternIR
from .type_ir import TypeCategory
from .view_ir import ViewIR


@dataclass
class EntityIR:
    """Intermediate representation of a SpecQL entity.

    This is the canonical representation that all target generators consume.
    It captures everything needed to generate target-specific code while
    remaining completely target-agnostic.

    Example:
        EntityIR(
            name='Contact',
            schema='crm',
            fields=[
                FieldIR(name='email', type_ir=TypeIR(category=TypeCategory.SCALAR, base_type='text')),
                FieldIR(name='company', type_ir=TypeIR(
                    category=TypeCategory.REFERENCE,
                    base_type='Company',
                    referenced_entity='Company'
                )),
            ],
            actions=[
                ActionIR(name='qualify_lead', entity='Contact', schema='crm', steps=[...])
            ]
        )
    """

    name: str
    schema: str = "public"

    # Core components
    fields: list[FieldIR] = field(default_factory=list)
    actions: list[ActionIR] = field(default_factory=list)

    # Patterns and extensions
    patterns: PatternIR | None = None
    views: list[ViewIR] = field(default_factory=list)
    identifier: IdentifierIR | None = None

    # Metadata
    description: str = ""
    table_name: str | None = None  # Override default tb_{name}

    # Trinity pattern (SpecQL convention)
    # When True, generators should include pk_*, id (UUID), identifier columns
    has_trinity: bool = True

    # Multi-tenancy
    is_multi_tenant: bool = False  # When True, include tenant_id column

    # Audit trail
    has_audit_trail: bool = True  # created_at, updated_at, created_by, updated_by
    has_soft_delete: bool = False  # deleted_at column

    # Computed properties for generator convenience

    @property
    def has_references(self) -> bool:
        """True if entity has any foreign key references."""
        return any(f.is_reference for f in self.fields)

    @property
    def reference_fields(self) -> list[FieldIR]:
        """Fields that are foreign key references."""
        return [f for f in self.fields if f.is_reference]

    @property
    def reference_field_names(self) -> list[str]:
        """Names of fields that are foreign key references."""
        return [f.name for f in self.fields if f.is_reference]

    @property
    def enum_fields(self) -> list[FieldIR]:
        """Fields that have enum types."""
        return [f for f in self.fields if f.is_enum]

    @property
    def has_enums(self) -> bool:
        """True if entity has any enum fields."""
        return len(self.enum_fields) > 0

    @property
    def list_fields(self) -> list[FieldIR]:
        """Fields that are list/array types."""
        return [f for f in self.fields if f.type_ir.category == TypeCategory.LIST]

    @property
    def composite_fields(self) -> list[FieldIR]:
        """Fields that are composite/rich types (money, address, etc.)."""
        return [f for f in self.fields if f.type_ir.category == TypeCategory.COMPOSITE]

    @property
    def scalar_fields(self) -> list[FieldIR]:
        """Fields that are simple scalar types (text, integer, etc.)."""
        return [f for f in self.fields if f.type_ir.category == TypeCategory.SCALAR]

    @property
    def has_actions(self) -> bool:
        """True if entity has any actions defined."""
        return len(self.actions) > 0

    @property
    def has_views(self) -> bool:
        """True if entity has any associated views."""
        return len(self.views) > 0

    @property
    def has_identifier(self) -> bool:
        """True if entity has a custom identifier pattern."""
        return self.identifier is not None

    @property
    def has_patterns(self) -> bool:
        """True if entity has detected patterns."""
        return self.patterns is not None and len(self.patterns.patterns) > 0

    @property
    def default_table_name(self) -> str:
        """Get the table name, using convention if not explicitly set."""
        if self.table_name:
            return self.table_name
        # SpecQL convention: tb_{entity_name_snake_case}
        return f"tb_{self._to_snake_case(self.name)}"

    @property
    def required_fields(self) -> list[FieldIR]:
        """Fields that are not nullable (required)."""
        return [f for f in self.fields if not f.nullable]

    @property
    def optional_fields(self) -> list[FieldIR]:
        """Fields that are nullable (optional)."""
        return [f for f in self.fields if f.nullable]

    @property
    def indexed_fields(self) -> list[FieldIR]:
        """Fields that should be indexed."""
        return [f for f in self.fields if f.indexed]

    @property
    def unique_fields(self) -> list[FieldIR]:
        """Fields that have unique constraints."""
        return [f for f in self.fields if f.unique]

    # Helper methods

    def get_field(self, name: str) -> FieldIR | None:
        """Get a field by name.

        Args:
            name: The field name to find

        Returns:
            The FieldIR if found, None otherwise
        """
        for f in self.fields:
            if f.name == name:
                return f
        return None

    def get_action(self, name: str) -> ActionIR | None:
        """Get an action by name.

        Args:
            name: The action name to find

        Returns:
            The ActionIR if found, None otherwise
        """
        for a in self.actions:
            if a.name == name:
                return a
        return None

    def get_referenced_entities(self) -> list[str]:
        """Get list of all entities this entity references.

        Returns:
            List of entity names that are referenced by foreign keys
        """
        return [
            f.type_ir.referenced_entity
            for f in self.fields
            if f.is_reference and f.type_ir.referenced_entity
        ]

    def has_field(self, name: str) -> bool:
        """Check if entity has a field with the given name."""
        return self.get_field(name) is not None

    def has_action(self, name: str) -> bool:
        """Check if entity has an action with the given name."""
        return self.get_action(name) is not None

    @staticmethod
    def _to_snake_case(name: str) -> str:
        """Convert PascalCase/camelCase to snake_case."""
        import re

        # Insert underscore before uppercase letters and convert to lowercase
        s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
        return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()

    def __repr__(self) -> str:
        """Human-readable representation."""
        return (
            f"EntityIR(name={self.name!r}, schema={self.schema!r}, "
            f"fields={len(self.fields)}, actions={len(self.actions)})"
        )
