"""Identifier Intermediate Representation."""

from dataclasses import dataclass, field


@dataclass
class IdentifierComponentIR:
    """A component of a hierarchical identifier.

    Identifiers can be composed of multiple parts like:
    - field: Direct field value
    - literal: Fixed string
    - separator: Joining character
    - function: Computed value
    """

    source: str  # 'field', 'literal', 'separator', 'function'
    value: str  # field name, literal string, separator char, function name

    # For function components
    args: list[str] = field(default_factory=list)


@dataclass
class IdentifierIR:
    """Hierarchical identifier pattern.

    Examples:
        - Simple: {entity}_{id}
        - Complex: ORG-{org_id}-DEPT-{dept_id}-EMP-{emp_id}
        - With functions: {entity}_{hash(id, 8)}
    """

    name: str
    components: list[IdentifierComponentIR]

    # Generation options
    case: str = "upper"  # 'upper', 'lower', 'title'
    separator: str = "_"  # Default separator between components

    # Validation
    pattern: str | None = None  # Regex pattern for validation
    max_length: int | None = None

    def format_identifier(self, **field_values) -> str:
        """Format the identifier using provided field values."""
        parts = []

        for component in self.components:
            if component.source == "field":
                if component.value in field_values:
                    parts.append(str(field_values[component.value]))
                else:
                    parts.append(f"{{{component.value}}}")  # Placeholder
            elif component.source == "literal":
                parts.append(component.value)
            elif component.source == "separator":
                parts.append(component.value)
            elif component.source == "function":
                # For now, just use placeholder
                parts.append(f"{component.value}({','.join(component.args)})")

        result = "".join(parts)

        # Apply case transformation
        if self.case == "upper":
            result = result.upper()
        elif self.case == "lower":
            result = result.lower()
        elif self.case == "title":
            result = result.title()

        return result
