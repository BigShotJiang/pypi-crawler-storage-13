"""Intermediate Representation (IR) for SpecQL.

The IR module provides target-agnostic representations of SpecQL constructs
that can be consumed by any code generator. The key classes are:

- EntityIR: Complete entity representation (fields, actions, patterns, etc.)
- FieldIR: Single field with type information
- TypeIR: Type information with category (scalar, reference, enum, list, composite)
- ActionIR: Business action with steps
- ActionStepIR: Single action step (validate, update, insert, if, etc.)
- PatternIR: Detected patterns (trinity, audit, hierarchy, SCD, etc.)
- ViewIR: Database view definition
- IdentifierIR: Hierarchical identifier pattern

Use IRConverter to convert parser output (Entity) to IR:

    from core.ast_models import Entity
    from src.core.ir import IRConverter, EntityIR

    entity = Entity(name='Contact', schema='crm', fields={...})
    entity_ir = IRConverter.to_entity_ir(entity)
"""

from .action_ir import ActionIR, ActionStepIR
from .converter import IRConverter
from .entity_ir import EntityIR
from .field_ir import FieldIR
from .identifier_ir import IdentifierComponentIR, IdentifierIR
from .pattern_ir import PatternIR
from .type_ir import TypeCategory, TypeIR
from .view_ir import ViewIR

__all__ = [
    # Core entity representation
    "EntityIR",
    # Type system
    "TypeCategory",
    "TypeIR",
    "FieldIR",
    # Actions
    "ActionStepIR",
    "ActionIR",
    # Patterns and extensions
    "PatternIR",
    "IdentifierComponentIR",
    "IdentifierIR",
    "ViewIR",
    # Converter
    "IRConverter",
]
