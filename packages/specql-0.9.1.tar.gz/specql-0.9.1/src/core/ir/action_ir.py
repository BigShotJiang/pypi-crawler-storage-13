"""Action Intermediate Representation."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ActionStepIR:
    """Intermediate representation of a single action step.

    SpecQL actions are composed of steps like validate, update, insert, if, etc.
    This IR captures the step in a target-agnostic way.

    Step Types:
        - validate: Check a condition, fail if false
        - update: Update entity fields
        - insert: Insert new record
        - if: Conditional branching
        - call: Call another function
        - notify: Send notification
        - foreach: Loop over collection
    """

    step_type: str  # 'validate', 'update', 'insert', 'if', 'call', 'notify', 'foreach'
    expression: str | None = None  # For validate steps

    # For update/insert steps
    target_entity: str | None = None
    fields: dict[str, str] = field(default_factory=dict)

    # For if steps
    condition: str | None = None
    then_steps: list["ActionStepIR"] = field(default_factory=list)
    else_steps: list["ActionStepIR"] = field(default_factory=list)

    # For call steps
    function_name: str | None = None
    function_args: list[str] = field(default_factory=list)

    # For foreach steps
    collection: str | None = None
    item_name: str | None = None
    loop_steps: list["ActionStepIR"] = field(default_factory=list)


@dataclass
class ActionIR:
    """Intermediate representation of a SpecQL action.

    An action is a business operation that modifies data. Actions are
    compiled to target-specific code (PL/pgSQL, PHP, Python, etc.).

    Example:
        ActionIR(
            name='publish_article',
            entity='Article',
            schema='content',
            steps=[
                ActionStepIR(step_type='validate', expression="status = 'draft'"),
                ActionStepIR(step_type='update', target_entity='Article',
                            fields={'status': "'published'"})
            ],
            impacts=['Article', 'ActivityLog']
        )
    """

    name: str
    entity: str
    schema: str
    steps: list[ActionStepIR]

    # Action signature
    params: list[dict[str, Any]] = field(default_factory=list)

    # Mutation impacts for cache invalidation
    impacts: list[str] = field(default_factory=list)

    # Documentation
    description: str | None = None
