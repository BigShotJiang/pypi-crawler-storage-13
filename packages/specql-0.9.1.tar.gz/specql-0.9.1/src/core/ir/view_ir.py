"""View Intermediate Representation."""

from dataclasses import dataclass, field
from typing import Any

from .field_ir import FieldIR


@dataclass
class ViewIR:
    """Intermediate representation of a database view.

    Views can be:
    - Simple SELECT projections
    - Aggregations and rollups
    - Complex joins
    - Materialized views
    """

    name: str
    schema: str
    description: str | None = None

    # View definition
    select_fields: list[FieldIR] = field(default_factory=list)
    from_entity: str | None = None
    joins: list[dict[str, Any]] = field(default_factory=list)  # Join specifications
    where_clause: str | None = None
    group_by: list[str] = field(default_factory=list)
    having_clause: str | None = None
    order_by: list[str] = field(default_factory=list)

    # View properties
    is_materialized: bool = False
    refresh_type: str | None = None  # 'immediate', 'deferred', 'manual'

    # Permissions and security
    grants: list[dict[str, Any]] = field(default_factory=list)

    @property
    def is_aggregate_view(self) -> bool:
        """True if this view contains aggregation functions."""
        return len(self.group_by) > 0 or any(
            "COUNT(" in str(field.type_ir.base_type).upper()
            or "SUM(" in str(field.type_ir.base_type).upper()
            or "AVG(" in str(field.type_ir.base_type).upper()
            or "MIN(" in str(field.type_ir.base_type).upper()
            or "MAX(" in str(field.type_ir.base_type).upper()
            for field in self.select_fields
        )
