"""Convert parser AST models to IR (Intermediate Representation).

This module provides the bridge between the parser output (Entity, FieldDefinition, etc.)
and the generator input (EntityIR, FieldIR, etc.). This separation allows:
- Parsers to focus on syntax without worrying about generation
- Generators to work with a clean, normalized representation
- Easy testing of both sides independently
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

from .action_ir import ActionIR, ActionStepIR
from .entity_ir import EntityIR
from .field_ir import FieldIR
from .identifier_ir import IdentifierComponentIR, IdentifierIR
from .pattern_ir import PatternIR
from .type_ir import TypeCategory, TypeIR
from .view_ir import ViewIR

if TYPE_CHECKING:
    from core.ast_models import (
        Action,
        ActionStep,
        Entity,
        FieldDefinition,
        IdentifierConfig,
        Pattern,
    )


class IRConverter:
    """Converts parser output (Entity) to generator input (EntityIR).

    This is a stateless converter - all methods are class methods that can be
    called without instantiation.

    Example:
        from core.ast_models import Entity
        from src.core.ir import IRConverter, EntityIR

        entity = Entity(name='Contact', schema='crm', fields={...})
        entity_ir = IRConverter.to_entity_ir(entity)
    """

    @classmethod
    def to_entity_ir(cls, entity: Entity) -> EntityIR:
        """Convert Entity (parser output) to EntityIR (generator input).

        Args:
            entity: The parsed Entity object from ast_models

        Returns:
            EntityIR ready for code generation
        """
        # Convert fields
        fields = [
            cls._convert_field(name, defn)
            for name, defn in entity.fields.items()
        ]

        # Convert actions
        actions = [
            cls._convert_action(action, entity)
            for action in entity.actions
        ]

        # Convert patterns
        patterns = cls._convert_patterns(entity.patterns) if entity.patterns else None

        # Convert identifier
        identifier = (
            cls._convert_identifier(entity.identifier)
            if entity.identifier
            else None
        )

        # Detect multi-tenancy from schema registry or field presence
        is_multi_tenant = any(f.name == "tenant_id" for f in fields)

        # Detect audit trail from field presence
        audit_fields = {"created_at", "updated_at", "created_by", "updated_by"}
        has_audit_trail = any(f.name in audit_fields for f in fields)

        # Detect soft delete from field presence
        has_soft_delete = any(f.name == "deleted_at" for f in fields)

        return EntityIR(
            name=entity.name,
            schema=entity.schema,
            fields=fields,
            actions=actions,
            patterns=patterns,
            identifier=identifier,
            description=entity.description,
            table_name=entity.table,
            has_trinity=True,  # SpecQL convention - always has trinity
            is_multi_tenant=is_multi_tenant,
            has_audit_trail=has_audit_trail,
            has_soft_delete=has_soft_delete,
        )

    @classmethod
    def _convert_field(cls, name: str, defn: FieldDefinition) -> FieldIR:
        """Convert FieldDefinition to FieldIR.

        Args:
            name: The field name
            defn: The FieldDefinition from the parser

        Returns:
            FieldIR ready for code generation
        """
        type_ir = cls._parse_type(defn.type_name, defn)
        return FieldIR(
            name=name,
            type_ir=type_ir,
            nullable=defn.nullable,
            default=defn.default,
            unique=False,  # Would need to be detected from constraints
            indexed=False,  # Would need to be detected from indexes
            description=defn.description if defn.description else None,
        )

    @classmethod
    def _parse_type(cls, type_str: str, defn: FieldDefinition | None = None) -> TypeIR:
        """Parse type string to TypeIR.

        Handles all SpecQL type formats:
        - Simple scalars: text, integer, boolean, uuid, timestamp, etc.
        - References: ref(Entity), ref(Entity, schema)
        - Enums: enum(a, b, c)
        - Lists: list(text), list(ref(Entity))
        - Composite types: money, dimensions, address, etc.

        Args:
            type_str: The type string from the YAML
            defn: Optional FieldDefinition for additional metadata

        Returns:
            TypeIR representing the type
        """
        # Handle ref(Entity) or ref(Entity, schema)
        if type_str.startswith("ref(") and type_str.endswith(")"):
            inner = type_str[4:-1]
            parts = [p.strip() for p in inner.split(",")]
            entity_name = parts[0]
            schema_name = parts[1] if len(parts) > 1 else None

            return TypeIR(
                category=TypeCategory.REFERENCE,
                base_type=entity_name,
                referenced_entity=entity_name,
                referenced_schema=schema_name,
            )

        # Handle enum(a, b, c)
        if type_str.startswith("enum(") and type_str.endswith(")"):
            inner = type_str[5:-1]
            values = [v.strip() for v in inner.split(",")]
            return TypeIR(
                category=TypeCategory.ENUM,
                base_type="enum",
                enum_values=values,
            )

        # Handle list(type)
        if type_str.startswith("list(") and type_str.endswith(")"):
            inner = type_str[5:-1]
            element_type = cls._parse_type(inner)
            return TypeIR(
                category=TypeCategory.LIST,
                base_type="list",
                element_type=element_type,
            )

        # Handle composite types (detected by defn.tier or known names)
        composite_types = {
            "money", "dimensions", "address", "simple_address", "contact_info",
            "phone", "date_range", "time_range", "coordinates", "measurement",
        }
        if type_str.lower() in composite_types:
            return TypeIR(
                category=TypeCategory.COMPOSITE,
                base_type=type_str,
            )

        # Handle types with parameters like varchar(100), decimal(10,2)
        param_match = re.match(r"(\w+)\(([^)]+)\)", type_str)
        if param_match:
            base = param_match.group(1)
            params_str = param_match.group(2)
            params = {}

            # Parse parameters
            if base.lower() in ("varchar", "char"):
                params["length"] = int(params_str)
            elif base.lower() == "decimal":
                parts = params_str.split(",")
                params["precision"] = int(parts[0].strip())
                if len(parts) > 1:
                    params["scale"] = int(parts[1].strip())

            return TypeIR(
                category=TypeCategory.SCALAR,
                base_type=base,
                params=params,
            )

        # Default: scalar type
        return TypeIR(
            category=TypeCategory.SCALAR,
            base_type=type_str,
        )

    @classmethod
    def _convert_action(cls, action: Action, entity: Entity) -> ActionIR:
        """Convert Action to ActionIR.

        Args:
            action: The Action from the parser
            entity: The parent Entity (for context)

        Returns:
            ActionIR ready for code generation
        """
        steps = [cls._convert_step(step) for step in action.steps]

        # Extract impacts from action.impact if present
        impacts = []
        if action.impact:
            impacts.append(action.impact.primary.entity)
            impacts.extend(se.entity for se in action.impact.side_effects)

        return ActionIR(
            name=action.name,
            entity=entity.name,
            schema=entity.schema,
            steps=steps,
            impacts=impacts,
        )

    @classmethod
    def _convert_step(cls, step: ActionStep) -> ActionStepIR:
        """Convert ActionStep to ActionStepIR.

        Handles all step types:
        - validate: Check condition
        - update: Update entity fields
        - insert: Insert new record
        - if: Conditional branching
        - call: Function call
        - notify: Send notification
        - foreach: Loop over collection

        Args:
            step: The ActionStep from the parser

        Returns:
            ActionStepIR ready for code generation
        """
        step_type = step.type

        if step_type == "validate":
            return ActionStepIR(
                step_type="validate",
                expression=step.condition,
            )

        if step_type == "update":
            return ActionStepIR(
                step_type="update",
                target_entity=step.entity,
                fields=step.fields or {},
                condition=step.where_clause,
            )

        if step_type == "insert":
            return ActionStepIR(
                step_type="insert",
                target_entity=step.entity,
                fields=step.fields or {},
            )

        if step_type == "if":
            then_steps = [cls._convert_step(s) for s in (step.then_steps or [])]
            else_steps = [cls._convert_step(s) for s in (step.else_steps or [])]
            return ActionStepIR(
                step_type="if",
                condition=step.condition,
                then_steps=then_steps,
                else_steps=else_steps,
            )

        if step_type == "call":
            return ActionStepIR(
                step_type="call",
                function_name=step.function_name,
                function_args=list(step.arguments.values()) if step.arguments else [],
            )

        if step_type == "notify":
            return ActionStepIR(
                step_type="notify",
                expression=step.recipient or step.channel,
            )

        if step_type == "foreach":
            loop_steps = [cls._convert_step(s) for s in (step.nested_steps or [])]
            return ActionStepIR(
                step_type="foreach",
                collection=step.collection or step.foreach_expr,
                item_name=step.iterator_var,
                loop_steps=loop_steps,
            )

        # Unknown step type - create a basic IR
        return ActionStepIR(
            step_type=step_type,
            expression=step.condition,
        )

    @classmethod
    def _convert_patterns(cls, patterns: list[Pattern]) -> PatternIR | None:
        """Convert Pattern list to PatternIR.

        Args:
            patterns: List of Pattern objects from the parser

        Returns:
            PatternIR if patterns exist, None otherwise
        """
        if not patterns:
            return None

        pattern_names = [p.type for p in patterns]
        details = {}

        # Extract pattern-specific details
        for p in patterns:
            if p.params:
                details[p.type] = p.params

        # Detect hierarchy pattern details
        hierarchy_type = None
        hierarchy_parent = None
        for p in patterns:
            if "hierarchy" in p.type.lower() or "ltree" in p.type.lower():
                hierarchy_type = p.params.get("type", "adjacency_list") if p.params else "adjacency_list"
                hierarchy_parent = p.params.get("parent_column") if p.params else None

        # Detect SCD pattern details
        scd_from = None
        scd_to = None
        for p in patterns:
            if "scd" in p.type.lower():
                if p.params:
                    scd_from = p.params.get("effective_from")
                    scd_to = p.params.get("effective_to")

        return PatternIR(
            patterns=pattern_names,
            confidence=1.0,  # Explicit patterns have full confidence
            details=details,
            hierarchy_type=hierarchy_type,
            hierarchy_parent_column=hierarchy_parent,
            scd_effective_from=scd_from,
            scd_effective_to=scd_to,
        )

    @classmethod
    def _convert_identifier(cls, identifier: IdentifierConfig) -> IdentifierIR:
        """Convert IdentifierConfig to IdentifierIR.

        Args:
            identifier: The IdentifierConfig from the parser

        Returns:
            IdentifierIR ready for code generation
        """
        components = []

        # Convert prefix components
        for comp in identifier.prefix:
            components.append(
                IdentifierComponentIR(
                    source="field" if not comp.format else "function",
                    value=comp.field,
                    args=[comp.transform] if comp.transform else [],
                )
            )
            if comp.separator:
                components.append(
                    IdentifierComponentIR(source="separator", value=comp.separator)
                )

        # Add main separator between prefix and components if needed
        if identifier.prefix and identifier.components:
            components.append(
                IdentifierComponentIR(source="separator", value=identifier.separator)
            )

        # Convert main components
        for i, comp in enumerate(identifier.components):
            components.append(
                IdentifierComponentIR(
                    source="field" if not comp.format else "function",
                    value=comp.field,
                    args=[comp.transform] if comp.transform else [],
                )
            )
            # Add separator between components (except last)
            if i < len(identifier.components) - 1:
                sep = comp.separator or identifier.composition_separator
                components.append(
                    IdentifierComponentIR(source="separator", value=sep)
                )

        return IdentifierIR(
            name=identifier.strategy,
            components=components,
            separator=identifier.separator,
        )

    # Convenience methods for partial conversions

    @classmethod
    def fields_to_ir(cls, fields: dict[str, FieldDefinition]) -> list[FieldIR]:
        """Convert a dict of FieldDefinitions to list of FieldIR.

        Useful when you only need to convert fields without the full entity.
        """
        return [cls._convert_field(name, defn) for name, defn in fields.items()]

    @classmethod
    def actions_to_ir(cls, actions: list[Action], entity_name: str, schema: str) -> list[ActionIR]:
        """Convert a list of Actions to list of ActionIR.

        Useful when you only need to convert actions without the full entity.
        """
        # Create a minimal entity for context
        from core.ast_models import Entity
        entity = Entity(name=entity_name, schema=schema)
        return [cls._convert_action(action, entity) for action in actions]

    @classmethod
    def type_string_to_ir(cls, type_str: str) -> TypeIR:
        """Convert a type string directly to TypeIR.

        Useful for testing or when you have a type string without a full field.
        """
        return cls._parse_type(type_str)
