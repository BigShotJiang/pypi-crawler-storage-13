"""Field Intermediate Representation."""

from dataclasses import dataclass
from typing import Any

from .type_ir import TypeCategory, TypeIR


@dataclass
class FieldIR:
    """Intermediate representation of an entity field.

    Captures all metadata about a field that targets need for code generation:
    - Type information (via TypeIR)
    - Constraints (nullable, unique, indexed)
    - Default values
    - Documentation

    Examples:
        # Simple text field
        FieldIR(
            name='email',
            type_ir=TypeIR(category=TypeCategory.SCALAR, base_type='text'),
            unique=True
        )

        # Foreign key field
        FieldIR(
            name='company',
            type_ir=TypeIR(
                category=TypeCategory.REFERENCE,
                base_type='Company',
                referenced_entity='Company'
            )
        )
    """

    name: str
    type_ir: TypeIR

    # Constraints
    nullable: bool = True
    default: Any = None
    unique: bool = False
    indexed: bool = False

    # Documentation
    description: str | None = None

    # Computed properties
    @property
    def is_reference(self) -> bool:
        """True if this field is a foreign key reference."""
        return self.type_ir.category == TypeCategory.REFERENCE

    @property
    def is_enum(self) -> bool:
        """True if this field has enumerated values."""
        return self.type_ir.category == TypeCategory.ENUM

    @property
    def referenced_entity(self) -> str | None:
        """The entity this field references, or None."""
        return self.type_ir.referenced_entity
