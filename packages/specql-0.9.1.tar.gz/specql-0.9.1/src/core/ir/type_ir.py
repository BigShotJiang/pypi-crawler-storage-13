"""Type Intermediate Representation."""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any


class TypeCategory(Enum):
    """Categories of field types in SpecQL."""

    SCALAR = auto()  # text, integer, boolean, uuid, etc.
    REFERENCE = auto()  # ref(Entity) - foreign key
    ENUM = auto()  # enum(a, b, c) - constrained values
    LIST = auto()  # list(text), list(ref(Entity))
    COMPOSITE = auto()  # money, dimensions, address (rich types)


@dataclass
class TypeIR:
    """Intermediate representation of a SpecQL type.

    This is the canonical representation of a type that all target
    generators consume. It captures everything needed to generate
    target-specific type definitions.

    Examples:
        # Simple scalar
        TypeIR(category=TypeCategory.SCALAR, base_type='text')

        # Foreign key reference
        TypeIR(
            category=TypeCategory.REFERENCE,
            base_type='Company',
            referenced_entity='Company',
            referenced_schema='crm'
        )

        # Enum with values
        TypeIR(
            category=TypeCategory.ENUM,
            base_type='enum',
            enum_values=['draft', 'published']
        )
    """

    category: TypeCategory
    base_type: str  # 'text', 'integer', 'Company', 'enum', etc.

    # Type parameters (for varchar(100), decimal(10,2), etc.)
    params: dict[str, Any] = field(default_factory=dict)

    # For REFERENCE types
    referenced_entity: str | None = None
    referenced_schema: str | None = None

    # For ENUM types
    enum_values: list[str] = field(default_factory=list)

    # For LIST types
    element_type: "TypeIR | None" = None

    # For COMPOSITE types (future use)
    composite_fields: dict[str, "TypeIR"] = field(default_factory=dict)
