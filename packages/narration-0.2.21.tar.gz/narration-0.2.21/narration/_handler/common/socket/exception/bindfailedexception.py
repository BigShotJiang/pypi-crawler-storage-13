class BindFailedException(BaseException):
    pass
