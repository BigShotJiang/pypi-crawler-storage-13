class ConnectFailedException(BaseException):
    pass
