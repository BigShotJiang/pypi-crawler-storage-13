class OpTimeoutException(BaseException):
    pass
