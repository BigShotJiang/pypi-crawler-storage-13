#-----------------------------------------------------------------------
# Name:        didtools (diffindiff package)
# Purpose:     Additional tools for Difference-in-Differences Analysis
# Author:      Thomas Wieland 
#              ORCID: 0000-0001-5168-9846
#              mail: geowieland@googlemail.com              
# Version:     2.0.8
# Last update: 2025-11-22 10:23
# Copyright (c) 2025 Thomas Wieland
#-----------------------------------------------------------------------


import pandas as pd
import numpy as np
import re
from statsmodels.formula.api import ols
from sklearn.ensemble import BaggingRegressor, RandomForestRegressor, GradientBoostingRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_percentage_error, mean_squared_error, root_mean_squared_error

import diffindiff.config as config


def check_columns(
    df: pd.DataFrame, 
    columns: list,
    verbose: bool = config.VERBOSE
    ):

    if len(columns) > 0:

        if verbose:
            print(f"Checking {len(columns)} column(s) in data frame", end=" ... ")
        
        missing_columns = [col for col in columns if col not in df.columns]
        
        if verbose:
            print("OK")
        
        if missing_columns:
            raise KeyError(f"Data do not contain column(s): {', '.join(missing_columns)}")
        
def is_balanced(
    data: pd.DataFrame,
    unit_col: str,
    time_col: str,
    outcome_col: str,
    other_cols: list = None,
    verbose: bool = config.VERBOSE
    ):

    if verbose:
        print(f"Checking whether panel data is balanced with respect to {3+len(other_cols)} columns", end = " ... ")

    unit_freq = data[unit_col].nunique()
    time_freq = data[time_col].nunique()
    unitxtime = unit_freq*time_freq

    if other_cols is None:
        cols_relevant = [unit_col, time_col, outcome_col]
    else:
        cols_relevant = [unit_col, time_col, outcome_col] + other_cols

    data_relevant = data[cols_relevant]
    
    if unitxtime != len(data_relevant.notna()):
        balanced = False
    else:
        balanced = True
    
    if verbose:
        print("OK")
        if not balanced:
            print("WARNING: Panel data is not balanced.")
        
    return balanced

def is_binary(
    data: pd.DataFrame,
    treatment_col: str,
    verbose: bool = config.VERBOSE
    ):
    
    if verbose:
        print(f"Checking whether treatment column '{treatment_col}' is binary", end = " ... ")
    
    unique_values = set(data[treatment_col].dropna().unique())
    
    if unique_values == {0, 1}:
        binary = True
        treatment_format = "Binary"
    elif unique_values == {0}:
        binary = False
        treatment_format = "Constant (no treatment)"
    elif unique_values == {1}:
        binary = False
        treatment_format = "Constant (no control)"
    elif len(unique_values) > 2:
        binary = False
        treatment_format = "Continuous"
    else:
        binary = False
        treatment_format = "Unknown"
    
    if verbose:
        print("OK")
        if not binary:
            print(f"NOTE: treatment column '{treatment_col}' is not binary. Likely treatment format is: {treatment_format}.")
    
    return [
        binary,
        treatment_format
        ]           

def is_missing(
    data: pd.DataFrame,
    drop_missing: bool = True,
    missing_replace_by_zero: bool = False,
    fill_na = 0,
    verbose: bool = config.VERBOSE
    ):

    if verbose:
        print("Checking whether data frame contains missing values", end = " ... ")

    missing_outcome = data.isnull().any()
    missing_outcome_var = any(missing_outcome == True)

    missing_true_vars = []
    if missing_outcome_var:
        missing_true_vars = [name for name, value in missing_outcome.items() if value]        
        
    if verbose:
        print("OK")
        if len(missing_true_vars) > 0:
            print(f"WARNING: Data frame contains columns with missing values: {', '.join(missing_true_vars)}.")

    if drop_missing and not missing_replace_by_zero:
        
        if verbose:
            print("Dropping rows with missing values", end = " ... ")
        
        data = data.dropna(subset = missing_true_vars)
        
        if verbose:
            print("OK")
        
    if missing_replace_by_zero:
        
        if verbose:
            print(f"Replacing missing values with {fill_na}", end = " ... ")
            
        data[missing_true_vars] = data[missing_true_vars].fillna(0)
        
        if verbose:
            print("OK")

    return [
        missing_outcome_var, 
        missing_true_vars, 
        data,
        drop_missing,
        missing_replace_by_zero
        ]

def is_simultaneous(
    data: pd.DataFrame,
    unit_col: str,
    time_col: str,
    treatment_col: str,
    pre_post: bool = False,
    verbose: bool = config.VERBOSE
    ):   

    if pre_post:
        
        if verbose:
            print(f"Checking whether treatment '{treatment_col}' is simultaneous or staggered", end = " ... ")
        
        simultaneous = True
    
    else:
        
        data_isnotreatment = is_notreatment(
            data, 
            unit_col, 
            treatment_col,
            verbose=False
            )
        
        if verbose:
            print(f"Checking whether treatment '{treatment_col}' is simultaneous or staggered", end = " ... ")
        
        treatment_group = data_isnotreatment[1]
        data_TG = data[data[unit_col].isin(treatment_group)]

        data_TG_pivot = data_TG.pivot_table (index = time_col, columns = unit_col, values = treatment_col)

        simultaneous = (data_TG_pivot.nunique(axis=1) == 1).all()

    if verbose:
        print("OK")
        if not simultaneous:
            print(f"NOTE: treatment '{treatment_col}' is not simultaneous.")

    return simultaneous

def is_notreatment(
    data: pd.DataFrame,
    unit_col: str,
    treatment_col: str,
    verbose: bool = config.VERBOSE
    ):

    if verbose:
        print(f"Checking whether treatment '{treatment_col}' includes a no-treatment control group", end = " ... ")

    data_relevant = data[[unit_col, treatment_col]]

    treatment_timepoints = data_relevant.groupby(unit_col).sum(treatment_col)
    treatment_timepoints = treatment_timepoints.reset_index()

    no_treatment = (treatment_timepoints[treatment_col] == 0).any()
    if (treatment_timepoints[treatment_col] == 0).all():
        no_treatment = False

    treatment_group = treatment_timepoints.loc[treatment_timepoints[treatment_col] > 0, unit_col]
    treatment_group = treatment_group.tolist()
    control_group = treatment_timepoints.loc[treatment_timepoints[treatment_col] == 0, unit_col]
    control_group = control_group.tolist()
    
    if verbose:
        print("OK")
        if not no_treatment:
            print(f"WARNING: treatment '{treatment_col}' does not include a no-treatment control group.")

    return [
        no_treatment, 
        treatment_group, 
        control_group
        ]

def treatment_group_col(
    data: pd.DataFrame,
    unit_col: str,
    treatment_col: str,
    create_TG_col: str = "TG",
    verbose: bool = config.VERBOSE
    ):
    
    isnotreatment = is_notreatment(
        data = data,
        unit_col = unit_col,
        treatment_col = treatment_col
        )
    
    if verbose:
        print(f"Creating treatment group column {create_TG_col} for treatment '{treatment_col}'", end = " ... ")
    
    create_TG_col_exists = False
    if create_TG_col in data.columns:
        create_TG_col_exists = True        
        create_TG_col = f"{config.TG_COL}{config.DELIMITER}{treatment_col}"        

    treatment_group = isnotreatment[1]

    data[create_TG_col] = 0
    data.loc[data[unit_col].astype(str).isin(treatment_group), create_TG_col] = 1

    if verbose:
        print("OK")
        if create_TG_col_exists:
            print(f"NOTE: Column {create_TG_col} already exists. Saved treatment group in column {config.TG_COL}{config.DELIMITER}{treatment_col}.")

    return [
        data, 
        isnotreatment[0], 
        create_TG_col
        ]

def untreated_units(
    data: pd.DataFrame,
    unit_col: str,
    treatment_col: list,
    verbose: bool = config.VERBOSE
    ):

    if verbose:
        print(f"Identifying treated and untreated units for treatment(s) {', '.join(treatment_col)}", end = " ... ")

    unit_sum = data.groupby(unit_col)[treatment_col].sum().sum(axis=1).reset_index(name="sum")

    units_treated = unit_sum.loc[unit_sum["sum"] > 0, unit_col]
    units_nontreated = unit_sum.loc[unit_sum["sum"] == 0, unit_col]
    no_units_treated = len(units_treated)
    no_units_nontreated = len(units_nontreated)

    if verbose:
        print("OK")

    return [
        no_units_treated,
        no_units_nontreated,
        units_treated,
        units_nontreated
        ]

def is_parallel(
    data: pd.DataFrame,
    unit_col: str,
    time_col: str,
    treatment_col: str,
    outcome_col: str,
    pre_post: bool = False,
    alpha = 0.05,
    verbose: bool = config.VERBOSE
    ):
 
    modeldata_isnotreatment = is_notreatment(
        data = data,
        unit_col = unit_col,
        treatment_col = treatment_col,
        verbose = False
        )
    
    if verbose:
        print(f"Testing outcome '{outcome_col}' for parallel time trends", end = " ... ")
    
    if pre_post or not modeldata_isnotreatment:
        parallel = "not_tested"
        test_ols_model = None
    
    treatment_group = modeldata_isnotreatment[1]

    if len(data[(data[unit_col].isin(treatment_group)) & (data[treatment_col] == 1)]) > 0:
        
        first_day_of_treatment = min(data[(data[unit_col].isin(treatment_group)) & (data[treatment_col] == 1)][time_col])
        
        data_test = data[data[time_col] < first_day_of_treatment].copy()
        data_test[config.TG_COL] = 0
        data_test.loc[data_test[unit_col].isin(treatment_group), config.TG_COL] = 1
        
        if config.TIME_COUNTER_COL not in data_test.columns:
            data_test = date_counter(
                df = data_test,
                date_col = time_col, 
                new_col = config.TIME_COUNTER_COL,
                verbose = False
                )
        data_test[f"{config.TG_COL}_x_{config.TIME_COL}"] = data_test[config.TG_COL]*data_test[config.TIME_COUNTER_COL]        

        test_ols_model = ols(f'{outcome_col} ~ {config.TG_COL} + {config.TIME_COUNTER_COL} + {config.TG_COL}_x_{config.TIME_COL}', data = data_test).fit()
        coef_TG_x_t_p = test_ols_model.pvalues[f"{config.TG_COL}_x_{config.TIME_COL}"]

        if coef_TG_x_t_p < alpha:
            parallel = False
        else:
            parallel = True
        
    else:
        parallel = "not_tested"
        test_ols_model = None
    
    if verbose:
        print("OK")
        if parallel == "not_tested":
            print("WARNING: Data could not be tested for parallel time trends.")
      
    return [
        parallel, 
        test_ols_model
        ]

def date_counter(
    df: pd.DataFrame,
    date_col: str, 
    new_col: str = config.TIME_COUNTER_COL,
    verbose: bool = config.VERBOSE
    ):
    
    if new_col not in df.columns:
               
        if verbose:
            print(f"Building time counter for time column '{date_col}' in new column '{new_col}'", end = " ... ")    
            
        dates = df[date_col].unique()

        date_counter = pd.DataFrame({
        'date': dates,
            new_col: range(1, len(dates) + 1)
            })

        df = df.merge(
            date_counter,
            left_on = date_col,
            right_on = "date"
            )
    
        if verbose:
            print("OK")
    
    else:
        
        if verbose:
            print(f"Time counter column '{new_col}' already exists in data frame.")
        
        if not pd.api.types.is_numeric_dtype(df[new_col]):
            print(f"WARNING: Time counter column '{new_col}' is not numeric.")
    
    return df

def unique(data):

    if data is None or (isinstance(data, (list, np.ndarray, pd.Series, pd.DataFrame)) and len(data) == 0):
        return []
    
    if isinstance(data, pd.DataFrame):
        values = data.values.ravel()

    elif isinstance(data, pd.Series):
        values = data.values.ravel()

    elif isinstance(data, np.ndarray):
        values = data.ravel()

    elif isinstance(data, list):
        values = data

    elif isinstance(data, set):
        values = list(data)

    else:
        raise TypeError(f"Unsupported data type: {type(data)}")
    
    unique_values = list(np.unique(values))
    return unique_values

def model_wrapper(
    y,
    X,
    model_type: str,
    test_size = 0.2,
    train_size = None,
    model_n_estimators = 1000,
    model_max_features = 0.9,
    model_min_samples_split = 2,
    rf_max_depth = None,
    gb_iterations = 100,
    gb_max_depth = 3,
    gb_learning_rate = 0.1,
    knn_n_neighbors = 5,
    svr_kernel = "rbf",
    xgb_learning_rate = 0.1,
    lgbm_learning_rate = 0.1,
    random_state = 71
    ):

    if model_type not in ["ols", "olsbg", "dtbg", "rf", "gb", "knn", "svr", "xgb", "lgbm"]:
        raise ValueError("Please enter a valid model type ('ols', 'olsbg', 'dtbg', 'rf', 'gb', 'knn', 'svr', 'xgb', 'lgbm')")
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, 
        y, 
        test_size = test_size,
        train_size = train_size,
        random_state = random_state
    )
    
    model = None
    y_pred = None

    if model_type == "ols":
        model = LinearRegression()    
    elif model_type == "olsbg":
        model = BaggingRegressor(
            estimator = LinearRegression(),
            n_estimators = model_n_estimators,         
            random_state = random_state
        )         
    elif model_type == "dtbg":
        model = BaggingRegressor(
            estimator = DecisionTreeRegressor(),
            n_estimators =model_n_estimators,         
            random_state = random_state
        )    
    elif model_type == "rf":
        model = RandomForestRegressor(
            n_estimators = model_n_estimators, 
            max_features = model_max_features,
            min_samples_split = model_min_samples_split,
            max_depth = rf_max_depth,
            random_state = random_state
        )
    elif model_type == "gb":
        model = GradientBoostingRegressor(
            learning_rate = gb_learning_rate,
            n_estimators = gb_iterations, 
            max_features = model_max_features,
            min_samples_split = model_min_samples_split,
            max_depth = gb_max_depth,
            random_state = random_state
        )
    elif model_type == "knn":
        model = KNeighborsRegressor(n_neighbors=knn_n_neighbors)
    elif model_type == "svr":
        model = SVR(kernel=svr_kernel)
    elif model_type == "xgb":
        model = XGBRegressor(
            learning_rate = xgb_learning_rate,
            n_estimators = gb_iterations,
            random_state = random_state
        )
    elif model_type == "lgbm":
        model = LGBMRegressor(
            learning_rate = lgbm_learning_rate,
            n_estimators = gb_iterations,
            random_state = random_state
        )
        
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    metrics = {
        "r2_score": r2_score(y_test, y_pred),
        "mape": mean_absolute_percentage_error(y_test, y_pred),
        "mse": mean_squared_error(y_test, y_pred),
        "rmse": np.sqrt(mean_squared_error(y_test, y_pred))
        }

    return [
        y_pred,
        model,
        metrics
        ]
 
def treatment_times(
    data: pd.DataFrame,
    unit_col: str,
    time_col: str,
    treatment_col: str,
    verbose: bool = config.VERBOSE
    ):

    check_columns(
        df = data,
        columns = [
            unit_col, 
            time_col, 
            treatment_col
            ]
        )
    
    if verbose:
        print(f"Identifying treatment times for treatment '{treatment_col}'", end = " ... ")
    
    units = unique(data[unit_col])
    
    units_tt = pd.DataFrame(columns = [unit_col, "treatment_min", "treatment_max"])
    
    for unit in units:
        
        data_unit_tt = data[(data[unit_col] == unit) & (data[treatment_col] == 1)]
        
        if data_unit_tt.empty:
            continue
        
        treatment_min = min(data_unit_tt[time_col])
        treatment_max = max(data_unit_tt[time_col])
        
        units_tt = pd.concat(
            [units_tt, pd.DataFrame({unit_col: [unit], "treatment_min": [treatment_min], "treatment_max": [treatment_max]})],
            ignore_index=True
        )
        
    if verbose:
        print("OK")
        
    return units_tt

def clean_column_name(value):

    value = str(value).upper()
    value = re.sub(r'[^A-Z0-9_]', '_', value) 
    value = re.sub(r'_+', '_', value)        
    
    return value.strip('_')

def replace_prefix(s, prefix, replace):
    if s.startswith(prefix):
        return s.replace(prefix, replace, 1)
    return s