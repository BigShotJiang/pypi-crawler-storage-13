#-----------------------------------------------------------------------
# Name:        config (diffindiff package)
# Purpose:     Configuration for the diffindiff package
# Author:      Thomas Wieland 
#              ORCID: 0000-0001-5168-9846
#              mail: geowieland@googlemail.com              
# Version:     1.0.0
# Last update: 2025-11-22 10:18
# Copyright (c) 2025 Thomas Wieland
#-----------------------------------------------------------------------

# Basic config:

VERBOSE = True

ROUND_PERCENT = 2

# Description texts:

DID_DESCRIPTION = "Difference in Differences (DiD) Analysis"
DDD_DESCRIPTION = "Difference in Difference in Differences (DDD) Analysis"

TREATMENT_DESCRIPTION = "Treatment"

TREATMENT_GROUP_DESCRIPTION = f"{TREATMENT_DESCRIPTION} group"
CONTROL_GROUP_DESCRIPTION = "Control group"
GROUPS_DESCRIPTION = f"{TREATMENT_DESCRIPTION} and {CONTROL_GROUP_DESCRIPTION}"

TREATMENT_PERIOD_DESCRIPTION = f"{TREATMENT_DESCRIPTION} period"
STUDY_PERIOD_DESCRIPTION = "Study period"

UNITS_DESCRIPTION = "Units"

DDD_GROUP_DESCRIPTION = "Group segmentation"

SUMMARY_LABELS = [
    TREATMENT_DESCRIPTION,
    UNITS_DESCRIPTION,
    TREATMENT_GROUP_DESCRIPTION,
    CONTROL_GROUP_DESCRIPTION
]
SUMMARY_MAX_WIDTH = max(len(label) for label in SUMMARY_LABELS) + 1

# Data management:

DELIMITER = "_"
DELIMITER_INTERACT = "x"

COL_ABBREV = "col"

DUMMY_PREFIX = "DUMMY"
LOG_PREFIX = "log"
OBSERVED_SUFFIX = "observed"
EXPECTED_SUFFIX = "expected"
PREDICTED_SUFFIX = "pred"
CI_LOWER_SUFFIX = "CI_lower"
CI_UPPER_SUFFIX = "CI_upper"
PI_LOWER_SUFFIX = "PI_lower"
PI_UPPER_SUFFIX = "PI_upper"

TG_COL = "TG"
CG_COL = "CG"
TT_COL = "TT"
ATT_COL = "ATT"
TIME_COL = "t"
UNIT_COL = "unit"
UNIT_TIME_COL = f"{UNIT_COL}{DELIMITER}{TIME_COL}"
TIME_COUNTER_COL = "time_counter"


# Modeling config:

# Coefficients/effects types:

EFFECTS_TYPES = {
    "ATE": {
        "description": "Average treatment effect",
        "model_results_key": "average_treatment_effects"
    },
    "AATE": {
        "description": "Average after-treatment effect",
        "model_results_key": "average_after_treatment_effects"
    },
    "beta_0": {
        "description": "Control group baseline",
        "model_results_key": "control_group_baseline"
    },
    "beta_1": {
        "description": "Treatment group deviation",
        "model_results_key": "treatment_group_deviation"
    },
    "delta_0": {
        "description": "Non-treatment time effect",
        "model_results_key": "non_treatment_time_effect"
    },
    "ATT": {
        "description": "After-treatment time effect",
        "model_results_key": "after_treatment_time_effects"
    },
    "FE": {
        "description": "Fixed effects",
        "model_results_key": "fixed_effects",
        "types": {
            0: {
                "FE": "unit",
                "dummy_prefix": "UNIT",
                "model_config_key": "FE_unit",
                "description": "Fixed effects for observational units"
            },
            1: {
                "FE": "time",
                "dummy_prefix": "TIME",
                "model_config_key": "FE_time",
                "description": "Fixed effects for time points"
            },
            2: {
                "FE": "group",
                "dummy_prefix": "GROUP",
                "model_config_key": "FE_group",
                "description": "Fixed effects for groups"
            },
        }
    },
    "ITT": {
        "description": "Individual time trends",
        "model_results_key": "individual_time_trends",
        "model_config_key": "ITT"
    },
    "ITE": {
        "description": "Individual treatment effects",
        "model_results_key": "individual_treatment_effects",
        "model_config_key": "ITE"
    },
    "GTT": {
        "description": "Group time trends",
        "model_results_key": "group_time_trends",
        "model_config_key": "GTT"
    },
    "GTE": {
        "description": "Group treatment effects",
        "model_results_key": "group_treatment_effects",
        "model_config_key": "GTE"
    },
    "spillover": {
        "description": "Treatment spillover effects",
        "model_results_key": "treatment_spillover_effects",
        "model_config_key": "spillover_effects"
    }
}

FE_TYPES = [value["FE"] for value in EFFECTS_TYPES["FE"]["types"].values()]

# Time trends:
TIME_TRENDS_TYPES = [
    list(EFFECTS_TYPES.keys())[7],
    list(EFFECTS_TYPES.keys())[9]
    ]

# Specific effects:
SPECIFIC_EFFFECTS_TYPES = [
    list(EFFECTS_TYPES.keys())[8],
    list(EFFECTS_TYPES.keys())[10]
    ]

# Predictions:
PREDICTIONS_SUMMARY_FRAME_COLS = {
    "mean": "Predicted mean",
    "mean_se": "Predicted mean SE",
    "mean_ci_lower": "Lower CI of mean",
    "mean_ci_upper": "Upper CI of mean",
    "obs_ci_lower": "Lower prediction interval",
    "obs_ci_upper": "Upper prediction interval",
}
PREDICTIONS_SUMMARY_FRAME_COLS_LIST = list(PREDICTIONS_SUMMARY_FRAME_COLS.keys())
PREDICTIONS_SUMMARY_FRAME_DESCRIPTIONS = list(PREDICTIONS_SUMMARY_FRAME_COLS.values())

# Counterfactual:
COUNTERFAC_SUFFIX_CF = "counterfac"
COUNTERFAC_SUFFIX_PRED_CF = f"{DELIMITER}{PREDICTED_SUFFIX}{DELIMITER}{COUNTERFAC_SUFFIX_CF}"