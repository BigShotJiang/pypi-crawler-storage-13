import { createClerkClient, verifyToken } from "@clerk/backend"
import { sendEmail } from "./lib/email"
import { getPrisma } from "./lib/prisma"
import type { PrismaEnv } from "./lib/prisma"

interface Env extends PrismaEnv {
  ALLOWED_ORIGINS?: string
  CLERK_SECRET_KEY?: string
  BREVO_API_KEY?: string
  BREVO_SENDER_EMAIL?: string
  BREVO_SENDER_NAME?: string
  PNOTP_INTERNAL_NOTIFICATIONS_EMAIL?: string
}

type ApiHandler = (request: Request, env: Env) => Promise<Response>

type AuthContext = {
  userId: string
}

class UnauthorizedError extends Error {
  constructor(message = "Unauthorized") {
    super(message)
    this.name = "UnauthorizedError"
  }
}

const CONSOLE_ORIGIN = "https://app.pnotp.ai"
const API_KEY_BYTE_LENGTH = 32
const DEFAULT_API_KEY_TIER: KnownTier = "MVP"
const SUBSCRIPTION_RENEWAL_DAYS = 30
const KNOWN_TIERS = ["VIABLE", "MVP", "PREMIUM", "EXPERT"] as const
type KnownTier = (typeof KNOWN_TIERS)[number]

const worker: ExportedHandler<Env> = {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return handleOptions(request, env)
    }

    const prisma = getPrisma(env)
    const url = new URL(request.url)
    const pathname = normalizePath(url.pathname)
    const segments = pathname === "/" ? [] : pathname.slice(1).split("/")
    const routeKey = segments[0] ?? ""

    try {
      if (segments.length === 0) {
        return jsonResponse(request, env, { service: "pnotp-api" })
      }

      if (request.method === "GET" && routeKey === "health") {
        return jsonResponse(request, env, { status: "ok" })
      }

      if (routeKey === "v1") {
        return handlePublicApi(request, env, prisma, segments.slice(1))
      }

      if (routeKey === "api-keys") {
        const authContext = await authorize(request, env, `${request.method} ${pathname}`)

        if (segments.length === 1) {
          if (request.method === "GET") {
            const apiKeys = await prisma.apiKey.findMany({
              where: { userId: authContext.userId },
              orderBy: { createdAt: "desc" },
            })

            return jsonResponse(request, env, {
              apiKeys: apiKeys.map(mapApiKeyRecord),
            })
          }

          if (request.method === "POST") {
            return handleApiKeyCreate(request, env, prisma, authContext.userId)
          }

          return methodNotAllowed(request, env)
        }

        if (segments.length === 2 && request.method === "DELETE") {
          const apiKeyId = segments[1]
          return handleApiKeyDelete(request, env, prisma, authContext.userId, apiKeyId)
        }

        return methodNotAllowed(request, env)
      }

      if (routeKey === "dashboard" && segments[1] === "metrics" && request.method === "GET") {
        await authorize(request, env, `${request.method} ${pathname}`)

        const [apiKeyCount, modelCount, subscriptionCount] = await Promise.all([
          prisma.apiKey.count(),
          prisma.pnotPModel.count(),
          prisma.subscription.count({ where: { status: "active" } }),
        ])

        return jsonResponse(request, env, {
          apiKeyCount,
          modelCount,
          subscriptionCount,
        })
      }

      if (routeKey === "models" && request.method === "GET") {
        const { userId } = await authorize(request, env, `${request.method} ${pathname}`)

        const [models, subscription] = await Promise.all([
          prisma.pnotPModel.findMany({
            orderBy: [{ tier: "asc" }, { name: "asc" }],
          }),
          prisma.subscription.findFirst({
            where: { userId, status: "active" },
          }),
        ])

        const subscribedTiers = subscription ? [subscription.tier] : []

        return jsonResponse(request, env, {
          models,
          subscribedTiers,
        })
      }

      if (routeKey === "billing" && request.method === "GET") {
        const { userId } = await authorize(request, env, `${request.method} ${pathname}`)

        const [models, subscription] = await Promise.all([
          prisma.pnotPModel.findMany({
            orderBy: [{ tier: "asc" }, { priceUsd: "asc" }],
          }),
          prisma.subscription.findFirst({
            where: { userId, status: "active" },
          }),
        ])

        return jsonResponse(request, env, {
          subscription: subscription ? mapSubscriptionResponse(subscription) : null,
          plans: buildTierPlans(models),
        })
      }

      if (routeKey === "subscriptions") {
        const authContext = await authorize(request, env, `${request.method} ${pathname}`)

        if (segments.length === 1 && request.method === "POST") {
          return handleSubscriptionCreate(request, env, prisma, authContext.userId)
        }

        if (segments.length === 3 && segments[2] === "cancel" && request.method === "POST") {
          const subscriptionId = segments[1]
          return handleSubscriptionCancel(request, env, prisma, authContext.userId, subscriptionId)
        }

        return methodNotAllowed(request, env)
      }

      if (routeKey === "custom-model-requests" && request.method === "POST") {
        const { userId } = await authorize(request, env, `${request.method} ${pathname}`)

        const body = (await parseJson(request)) as Partial<Record<string, string>>
        const domain = body?.domain?.trim()
        const problemDescription = body?.problemDescription?.trim()
        const dataDescription = body?.dataDescription?.trim()
        const contactEmail = body?.contactEmail?.trim()

        if (!domain || !problemDescription || !dataDescription || !contactEmail) {
          return jsonResponse(request, env, { error: "All fields are required" }, 400)
        }

        const record = await prisma.customModelRequest.create({
          data: {
            domain,
            problemDescription,
            dataDescription,
            contactEmail,
            status: "new",
          },
        })

        console.log(`[custom-model-request] user ${userId} submitted ${record.id}`)

        const userProfile = await getUserProfile(userId, env)

        await Promise.all([
          sendEmail(env, {
            to: contactEmail,
            subject: "We received your custom model request",
            html: buildCustomModelUserEmail({
              domain,
              problemDescription,
              dataDescription,
              contactEmail,
              userProfile,
            }),
          }),
          sendInternalCustomModelEmail(env, {
            recordId: record.id,
            userId,
            userProfile,
            domain,
            problemDescription,
            dataDescription,
            contactEmail,
            createdAt: record.createdAt,
          }),
        ])

        return jsonResponse(request, env, { id: record.id }, 201)
      }

      if (routeKey === "contact" && request.method === "POST") {
        return handleContact(request, env)
      }

      return jsonResponse(request, env, { error: "Not Found" }, 404)
    } catch (error) {
      if (error instanceof UnauthorizedError) {
        return jsonResponse(request, env, { error: error.message }, 401)
      }
      console.error("pnotp-api error", error)
      return jsonResponse(request, env, { error: "Internal Server Error" }, 500)
    }
  },
}

export default worker

async function authorize(request: Request, env: Env, action: string) {
  const authContext = await validateAuth(request, env)
  console.log(`[auth] ${authContext.userId} -> ${action}`)
  return authContext
}

async function validateAuth(request: Request, env: Env): Promise<AuthContext> {
  const headerValue = request.headers.get("Authorization") ?? ""
  const [scheme, ...rest] = headerValue.split(" ")
  const token = rest.join(" ").trim()

  if (scheme?.toLowerCase() !== "bearer" || !token) {
    throw new UnauthorizedError("Missing authorization token.")
  }

  const secretKey = env.CLERK_SECRET_KEY
  if (!secretKey) {
    throw new Error("CLERK_SECRET_KEY is not configured")
  }

  try {
    const verification = await verifyToken(token, { secretKey })
    const userId = verification.sub

    if (!userId) {
      throw new UnauthorizedError("Invalid token payload.")
    }

    return { userId }
  } catch (error) {
    console.error("Failed to verify Clerk token", error)
    throw new UnauthorizedError("Invalid or expired authorization token.")
  }
}

let cachedSecretKey: string | null = null
let cachedClerkClient: ReturnType<typeof createClerkClient> | null = null

function getClerkClient(env: Env) {
  const secretKey = env.CLERK_SECRET_KEY
  if (!secretKey) {
    throw new Error("CLERK_SECRET_KEY is not configured")
  }

  if (cachedClerkClient && cachedSecretKey === secretKey) {
    return cachedClerkClient
  }

  cachedSecretKey = secretKey
  cachedClerkClient = createClerkClient({ secretKey })
  return cachedClerkClient
}

async function handleApiKeyCreate(
  request: Request,
  env: Env,
  prisma: ReturnType<typeof getPrisma>,
  userId: string,
) {
  const body = (await parseJson(request)) as Partial<{ label?: string; tier?: string }>
  const label = body?.label?.trim()
  if (!label) {
    return jsonResponse(request, env, { error: "Label is required" }, 400)
  }

  const tier = normalizeTier(body?.tier) ?? DEFAULT_API_KEY_TIER
  const apiKeyValue = generateApiKeyValue()
  const keyHash = await hashApiKeyValue(apiKeyValue)
  const fingerprint = apiKeyValue.slice(-6)

  const record = await prisma.apiKey.create({
    data: {
      userId,
      keyHash,
      label,
      tier,
      fingerprint,
    },
  })

  console.log(`[api-keys] user ${userId} generated a key labeled ${label}`)

  const userProfile = await getUserProfile(userId, env)
  await sendApiKeyEmail(env, {
    userProfile,
    label,
    tier,
    fingerprint,
  })

  return jsonResponse(
    request,
    env,
    {
      apiKey: apiKeyValue,
      key: mapApiKeyRecord(record),
    },
    201,
  )
}

async function handleApiKeyDelete(
  request: Request,
  env: Env,
  prisma: ReturnType<typeof getPrisma>,
  userId: string,
  apiKeyId: string,
) {
  if (!apiKeyId) {
    return jsonResponse(request, env, { error: "API key ID is required" }, 400)
  }

  const existing = await prisma.apiKey.findUnique({ where: { id: apiKeyId } })
  if (!existing || existing.userId !== userId) {
    return jsonResponse(request, env, { error: "API key not found" }, 404)
  }

  await prisma.apiKey.delete({ where: { id: apiKeyId } })
  console.log(`[api-keys] user ${userId} deleted key ${apiKeyId}`)

  return jsonResponse(request, env, { deleted: true })
}

async function handleSubscriptionCreate(
  request: Request,
  env: Env,
  prisma: ReturnType<typeof getPrisma>,
  userId: string,
) {
  const body = (await parseJson(request)) as Partial<{ tier?: string }>
  const tier = normalizeTier(body?.tier)
  if (!tier) {
    return jsonResponse(request, env, { error: "Tier is required" }, 400)
  }

  const now = new Date()
  const renewalDate = nextRenewalDate(now)
  const userProfile = await getUserProfile(userId, env)

  const existing = await prisma.subscription.findFirst({
    where: { userId, status: "active" },
    orderBy: { startedAt: "desc" },
  })

  if (existing) {
    if (existing.tier === tier) {
      return jsonResponse(request, env, { subscription: mapSubscriptionResponse(existing) })
    }

    const updated = await prisma.subscription.update({
      where: { id: existing.id },
      data: {
        tier,
        startedAt: now,
        canceledAt: null,
        status: "active",
        renewalDate,
      },
    })

    await sendSubscriptionEmail(env, {
      type: "updated",
      userProfile,
      tier,
      subscription: updated,
    })

    return jsonResponse(request, env, { subscription: mapSubscriptionResponse(updated) })
  }

  const created = await prisma.subscription.create({
    data: {
      userId,
      tier,
      status: "active",
      startedAt: now,
      renewalDate,
    },
  })

  await sendSubscriptionEmail(env, {
    type: "created",
    userProfile,
    tier,
    subscription: created,
  })

  return jsonResponse(request, env, { subscription: mapSubscriptionResponse(created) }, 201)
}

async function handleSubscriptionCancel(
  request: Request,
  env: Env,
  prisma: ReturnType<typeof getPrisma>,
  userId: string,
  subscriptionId: string,
) {
  const subscription = await prisma.subscription.findUnique({ where: { id: subscriptionId } })
  if (!subscription) {
    return jsonResponse(request, env, { error: "Subscription not found" }, 404)
  }

  if (subscription.userId !== userId) {
    return jsonResponse(request, env, { error: "Subscription not accessible" }, 403)
  }

  if (subscription.status === "canceled") {
    return jsonResponse(request, env, { error: "Subscription already canceled" }, 400)
  }

  const now = new Date()
  const updated = await prisma.subscription.update({
    where: { id: subscriptionId },
    data: {
      status: "canceled",
      canceledAt: now,
      renewalDate: null,
    },
  })

  const userProfile = await getUserProfile(userId, env)
  await sendSubscriptionEmail(env, {
    type: "canceled",
    userProfile,
    tier: updated.tier as KnownTier,
    subscription: updated,
  })

  return jsonResponse(request, env, { status: "canceled" })
}

type ContactPayload = {
  name?: string
  email?: string
  subject?: string
  message?: string
  context?: string
}

async function handleContact(request: Request, env: Env) {
  const body = (await parseJson(request)) as ContactPayload

  const email = body?.email?.trim()
  const message = body?.message?.trim()
  if (!email || !message) {
    return jsonResponse(request, env, { error: "Email and message are required" }, 400)
  }

  const notificationsEmail = env.PNOTP_INTERNAL_NOTIFICATIONS_EMAIL
  if (!notificationsEmail) {
    console.error("PNOTP_INTERNAL_NOTIFICATIONS_EMAIL is not configured")
    return jsonResponse(request, env, { error: "Contact channel unavailable" }, 500)
  }

  const name = body?.name?.trim()
  const subject = body?.subject?.trim()
  const context = body?.context?.trim() || "unknown"

  const html = `
    <p>You have a new contact message via P¬P (${escapeHtml(context)}).</p>
    <p><strong>Name:</strong> ${escapeHtml(name || "Anonymous")}</p>
    <p><strong>Email:</strong> ${escapeHtml(email)}</p>
    ${subject ? `<p><strong>Subject:</strong> ${escapeHtml(subject)}</p>` : ""}
    <p><strong>Message:</strong></p>
    <p>${escapeHtml(message).replace(/\n/g, "<br />")}</p>
  `.trim()

  await sendEmail(env, {
    to: notificationsEmail,
    subject: `New contact message from P¬P (${context})`,
    html,
    replyTo: email,
  })

  return jsonResponse(request, env, { ok: true })
}

type UserProfileInfo = {
  email: string
  fullName?: string
}

type ApiKeyContext = {
  apiKeyId: string
  userId: string
  tier: KnownTier
  label: string | null
  fingerprint: string
}

async function handlePublicApi(
  request: Request,
  env: Env,
  prisma: ReturnType<typeof getPrisma>,
  segments: string[],
) {
  const resource = segments[0] ?? ""

  if (resource === "models") {
    if (segments.length === 1 && request.method === "GET") {
      return handlePublicModelsList(request, env, prisma)
    }

    const modelId = segments[1]
    if (!modelId) {
      return jsonResponse(request, env, { error: "Model id is required" }, 400)
    }

    if (segments.length === 2 && request.method === "GET") {
      return handlePublicModelDetail(request, env, prisma, modelId)
    }

    if (segments.length === 3 && segments[2] === "predict" && request.method === "POST") {
      return handlePublicModelPredict(request, env, prisma, modelId)
    }
  }

  return jsonResponse(request, env, { error: "Not Found" }, 404)
}

async function handlePublicModelsList(
  request: Request,
  env: Env,
  prisma: ReturnType<typeof getPrisma>,
) {
  const auth = await authenticateApiKey(request, env, prisma)
  if (auth instanceof Response) {
    return auth
  }

  const allowedDbTiers: string[] = getAllowedTiers(auth.tier).map(mapKnownTierToDb)

  const models = await prisma.pnotPModel.findMany({
    where: {
      tier: {
        in: allowedDbTiers,
      },
    },
    orderBy: [{ tier: "asc" }, { name: "asc" }],
  })

  return jsonResponse(request, env, {
    models: models.map(mapPublicModel),
  })
}

async function handlePublicModelDetail(
  request: Request,
  env: Env,
  prisma: ReturnType<typeof getPrisma>,
  modelId: string,
) {
  const auth = await authenticateApiKey(request, env, prisma)
  if (auth instanceof Response) {
    return auth
  }

  const allowedDbTiers: string[] = getAllowedTiers(auth.tier).map(mapKnownTierToDb)

  const model = await prisma.pnotPModel.findUnique({ where: { modelId } })
  if (!model || !allowedDbTiers.includes(model.tier)) {
    return jsonResponse(request, env, { error: "Model not found" }, 404)
  }

  return jsonResponse(request, env, {
    model: mapPublicModel(model),
  })
}

async function handlePublicModelPredict(
  request: Request,
  env: Env,
  prisma: ReturnType<typeof getPrisma>,
  modelId: string,
) {
  const auth = await authenticateApiKey(request, env, prisma)
  if (auth instanceof Response) {
    return auth
  }

  const allowedDbTiers: string[] = getAllowedTiers(auth.tier).map(mapKnownTierToDb)

  const model = await prisma.pnotPModel.findUnique({ where: { modelId } })
  if (!model || !allowedDbTiers.includes(model.tier)) {
    return jsonResponse(request, env, { error: "Model not available" }, 404)
  }

  return jsonResponse(request, env, { error: "Prediction endpoint not implemented yet" }, 501)
}

function mapPublicModel(model: {
  modelId: string
  name: string
  tier: string
  description: string
  inputType: string
  outputType: string
  status: string
  priceUsd: number
  accuracy: number
  f1Score: number
  auc: number
  latencyMs: number
  industry: string
}) {
  return {
    id: model.modelId,
    name: model.name,
    tier: model.tier,
    description: model.description,
    input_type: model.inputType,
    output_type: model.outputType,
    status: model.status,
    price_usd: model.priceUsd,
    accuracy: model.accuracy,
    f1_score: model.f1Score,
    auc: model.auc,
    latency_ms: model.latencyMs,
    industry: model.industry,
  }
}

async function authenticateApiKey(
  request: Request,
  env: Env,
  prisma: ReturnType<typeof getPrisma>,
): Promise<ApiKeyContext | Response> {
  const apiKeyValue = extractApiKey(request)
  if (!apiKeyValue) {
    return jsonResponse(request, env, { error: "Missing API key" }, 401)
  }

  const keyHash = await hashApiKeyValue(apiKeyValue)

  const apiKeyRecord = await prisma.apiKey.findFirst({
    where: { keyHash },
  })

  if (!apiKeyRecord || apiKeyRecord.revokedAt) {
    return jsonResponse(request, env, { error: "Invalid API key" }, 401)
  }

  const tier = normalizeTier(apiKeyRecord.tier)
  if (!tier) {
    return jsonResponse(request, env, { error: "API key tier is not allowed" }, 403)
  }

  return {
    apiKeyId: apiKeyRecord.id,
    userId: apiKeyRecord.userId,
    tier,
    label: apiKeyRecord.label ?? null,
    fingerprint: apiKeyRecord.fingerprint,
  }
}

function extractApiKey(request: Request) {
  const authHeader = request.headers.get("Authorization") ?? ""
  if (authHeader.toLowerCase().startsWith("bearer ")) {
    const token = authHeader.slice(7).trim()
    if (token) {
      return token
    }
  }

  const fallback = request.headers.get("X-PNOTP-API-Key")?.trim()
  return fallback ?? ""
}

async function sendApiKeyEmail(
  env: Env,
  params: { userProfile: UserProfileInfo | null; label: string; tier: string; fingerprint: string },
) {
  const email = params.userProfile?.email
  if (!email) {
    return false
  }

  const tierLabel = formatTierLabel(params.tier)

  const html = `
    <p>Hi ${escapeHtml(getUserGreeting(params.userProfile))},</p>
    <p>Your new P¬P API key (tier: ${escapeHtml(tierLabel)}) was created.</p>
    <p>You can manage or rotate keys at
      <a href="${consoleUrl("/api-keys")}">app.pnotp.ai/api-keys</a>.
    </p>
    <p><strong>Label:</strong> ${escapeHtml(params.label)}</p>
    <p><strong>Fingerprint:</strong> ****${escapeHtml(params.fingerprint)}</p>
    <p>
      For security reasons we never email the full key. If you didn't request this, please sign in and delete the key immediately.
    </p>
  `.trim()

  return sendEmail(env, {
    to: email,
    subject: "Your new P¬P API key",
    html,
  })
}

type SubscriptionEmailType = "created" | "canceled" | "updated"

async function sendSubscriptionEmail(
  env: Env,
  params: {
    type: SubscriptionEmailType
    userProfile: UserProfileInfo | null
    tier: KnownTier
    subscription: {
      startedAt: Date
      renewalDate: Date | null
      canceledAt: Date | null
    }
  },
) {
  const email = params.userProfile?.email
  if (!email) {
    return false
  }

  const tierLabel = formatTierLabel(params.tier)
  let subject = "Your P¬P subscription was updated"
  let intro = `Your subscription is now on the ${tierLabel} tier.`
  let detail = ""

  if (params.type === "created") {
    subject = "Your P¬P subscription has started"
    intro = `Thanks for subscribing to the ${tierLabel} tier.`
    detail = `<p>Your subscription started on ${formatDisplayDate(params.subscription.startedAt)}. ${
      params.subscription.renewalDate
        ? `Your next renewal is ${formatDisplayDate(params.subscription.renewalDate)}.`
        : ""
    }</p>`
  } else if (params.type === "canceled") {
    subject = "Your P¬P subscription was canceled"
    intro = "We've processed your cancellation request."
    detail = `<p>Cancellation date: ${formatDisplayDate(
      params.subscription.canceledAt ?? new Date(),
    )}.</p>`
  }

  const html = `
    <p>Hi ${escapeHtml(getUserGreeting(params.userProfile))},</p>
    <p>${intro}</p>
    ${detail}
    <p>Manage your subscription at <a href="${consoleUrl("/billing")}">app.pnotp.ai/billing</a>.</p>
  `.trim()

  return sendEmail(env, {
    to: email,
    subject,
    html,
  })
}

function mapApiKeyRecord(record: {
  id: string
  label: string | null
  tier: string
  fingerprint: string
  createdAt: Date
}) {
  return {
    id: record.id,
    label: record.label,
    tier: record.tier,
    fingerprint: record.fingerprint,
    createdAt: record.createdAt.toISOString(),
  }
}

function mapSubscriptionResponse(record: {
  id: string
  tier: string
  status: string
  startedAt: Date
  renewalDate: Date | null
  canceledAt: Date | null
}) {
  return {
    id: record.id,
    tier: record.tier,
    status: record.status,
    startedAt: record.startedAt.toISOString(),
    renewalDate: record.renewalDate ? record.renewalDate.toISOString() : null,
    canceledAt: record.canceledAt ? record.canceledAt.toISOString() : null,
  }
}

type TierPlan = {
  tier: string
  label: string
  priceUsd: number
  description: string
  modelName?: string
  modelId?: string
}

function buildTierPlans(models: Array<{ tier: string; priceUsd: number; description: string; name: string; modelId: string }>): TierPlan[] {
  const grouped = new Map<string, TierPlan>()

  for (const model of models) {
    const key = model.tier.toLowerCase()
    if (!grouped.has(key)) {
      grouped.set(key, {
        tier: key,
        label: formatTierLabel(key),
        priceUsd: model.priceUsd,
        description: model.description,
        modelName: model.name,
        modelId: model.modelId,
      })
    }
  }

  return KNOWN_TIERS.map((tier) => {
    const key = tier.toLowerCase()
    const plan = grouped.get(key)
    if (plan) {
      return plan
    }
    return {
      tier: key,
      label: formatTierLabel(key),
      priceUsd: 0,
      description: "Coming soon",
    }
  })
}

function generateApiKeyValue() {
  const bytes = new Uint8Array(API_KEY_BYTE_LENGTH)
  crypto.getRandomValues(bytes)
  return `pnp_${toBase64Url(bytes)}`
}

async function hashApiKeyValue(value: string) {
  const encoder = new TextEncoder()
  const data = encoder.encode(value)
  const digest = await crypto.subtle.digest("SHA-256", data)
  return Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("")
}

function toBase64Url(bytes: Uint8Array) {
  let binary = ""
  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte)
  })
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
}

function normalizeTier(input?: string | null): KnownTier | null {
  if (!input) {
    return null
  }
  const normalized = input.trim().toUpperCase()
  return KNOWN_TIERS.includes(normalized as KnownTier) ? (normalized as KnownTier) : null
}

function getAllowedTiers(tier: KnownTier): KnownTier[] {
  const index = KNOWN_TIERS.indexOf(tier)
  if (index === -1) {
    return []
  }
  return KNOWN_TIERS.slice(0, index + 1)
}

function mapKnownTierToDb(tier: KnownTier) {
  switch (tier) {
    case "EXPERT":
      return "Expert"
    case "PREMIUM":
      return "Premium"
    case "MVP":
      return "MVP"
    case "VIABLE":
      return "Viable"
    default:
      return tier
  }
}

function formatTierLabel(tier: string) {
  const normalized = tier.toLowerCase()
  switch (normalized) {
    case "expert":
      return "Expert"
    case "premium":
      return "Premium"
    case "mvp":
      return "MVP"
    case "viable":
      return "Viable"
    default:
      return normalized
  }
}

function nextRenewalDate(from: Date) {
  return new Date(from.getTime() + SUBSCRIPTION_RENEWAL_DAYS * 24 * 60 * 60 * 1000)
}

function buildCustomModelUserEmail(params: {
  domain: string
  problemDescription: string
  dataDescription: string
  contactEmail: string
  userProfile: UserProfileInfo | null
}) {
  return `
    <p>Hi ${escapeHtml(getUserGreeting(params.userProfile))},</p>
    <p>We received your custom model request. Here's what you sent:</p>
    <ul>
      <li><strong>Domain:</strong> ${escapeHtml(params.domain)}</li>
      <li><strong>Problem:</strong> ${escapeHtml(params.problemDescription)}</li>
      <li><strong>Data:</strong> ${escapeHtml(params.dataDescription)}</li>
      <li><strong>Contact email:</strong> ${escapeHtml(params.contactEmail)}</li>
    </ul>
    <p>Our team will review and get back to you shortly.</p>
    <p>Track requests anytime at <a href="${consoleUrl("/custom-models")}">app.pnotp.ai/custom-models</a>.</p>
  `.trim()
}

async function sendInternalCustomModelEmail(
  env: Env,
  params: {
    recordId: string
    userId: string
    userProfile: UserProfileInfo | null
    domain: string
    problemDescription: string
    dataDescription: string
    contactEmail: string
    createdAt: Date
  },
) {
  const notificationsEmail = env.PNOTP_INTERNAL_NOTIFICATIONS_EMAIL
  if (!notificationsEmail) {
    console.error("PNOTP_INTERNAL_NOTIFICATIONS_EMAIL is not configured")
    return false
  }

  const html = `
    <p>New custom model request submitted.</p>
    <p><strong>Record ID:</strong> ${escapeHtml(params.recordId)}</p>
    <p><strong>User ID:</strong> ${escapeHtml(params.userId)}</p>
    <p><strong>User Email:</strong> ${escapeHtml(params.userProfile?.email ?? "unknown")}</p>
    <p><strong>Contact Email:</strong> ${escapeHtml(params.contactEmail)}</p>
    <p><strong>Domain:</strong> ${escapeHtml(params.domain)}</p>
    <p><strong>Problem:</strong> ${escapeHtml(params.problemDescription)}</p>
    <p><strong>Data:</strong> ${escapeHtml(params.dataDescription)}</p>
    <p><strong>Submitted at:</strong> ${escapeHtml(params.createdAt.toISOString())}</p>
  `.trim()

  return sendEmail(env, {
    to: notificationsEmail,
    subject: "New P¬P custom model request",
    html,
  })
}

async function getUserProfile(userId: string, env: Env): Promise<UserProfileInfo | null> {
  try {
    const clerkClient = getClerkClient(env)
    const user = await clerkClient.users.getUser(userId)
    const primaryEmail =
      user.emailAddresses?.find((address) => address.id === user.primaryEmailAddressId) ??
      user.emailAddresses?.[0]

    const email = primaryEmail?.emailAddress
    if (!email) {
      return null
    }

    const fullName = [user.firstName, user.lastName].filter(Boolean).join(" ").trim()
    return {
      email,
      fullName: fullName || undefined,
    }
  } catch (error) {
    console.error("Failed to load Clerk user profile", { userId, error })
    return null
  }
}

function getUserGreeting(userProfile: UserProfileInfo | null) {
  if (userProfile?.fullName) {
    return userProfile.fullName
  }
  if (userProfile?.email) {
    return userProfile.email
  }
  return "there"
}

function consoleUrl(path: string) {
  if (!path.startsWith("/")) {
    return `${CONSOLE_ORIGIN}/${path}`
  }
  return `${CONSOLE_ORIGIN}${path}`
}

function formatDisplayDate(date?: Date | null) {
  if (!date) {
    return "TBD"
  }

  try {
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  } catch {
    return date.toISOString().split("T")[0] ?? ""
  }
}

async function parseJson(request: Request) {
  try {
    return await request.json()
  } catch (error) {
    console.error("Failed to parse JSON", error)
    return {}
  }
}

function normalizePath(path: string) {
  if (!path || path === "/") {
    return "/"
  }

  const trimmed = path.replace(/\/+$/, "")
  return trimmed || "/"
}

function handleOptions(request: Request, env: Env) {
  return new Response(null, {
    status: 204,
    headers: buildCorsHeaders(request, env, true),
  })
}

function methodNotAllowed(request: Request, env: Env) {
  return jsonResponse(request, env, { error: "Method not allowed" }, 405)
}

function jsonResponse(request: Request, env: Env, body: unknown, status = 200) {
  const headers = buildCorsHeaders(request, env)
  headers["Content-Type"] = "application/json; charset=utf-8"
  return new Response(JSON.stringify(body), {
    status,
    headers,
  })
}

function buildCorsHeaders(request: Request, env: Env, isOptions = false) {
  const requestedHeaders = request.headers.get("Access-Control-Request-Headers")
  const allowedOrigins = (env.ALLOWED_ORIGINS ?? "*")
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean)

  const origin = request.headers.get("Origin")
  let allowOrigin = "*"

  if (allowedOrigins.length && !allowedOrigins.includes("*")) {
    if (origin && allowedOrigins.includes(origin)) {
      allowOrigin = origin
    } else {
      allowOrigin = allowedOrigins[0]
    }
  }

  const headers: Record<string, string> = {
    "Access-Control-Allow-Origin": allowOrigin,
    "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": requestedHeaders ?? "Content-Type,Authorization",
    Vary: "Origin",
  }

  if (isOptions) {
    headers["Access-Control-Max-Age"] = "86400"
  }

  return headers
}

const HTML_ESCAPE: Record<string, string> = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;",
}

function escapeHtml(value?: string | null) {
  if (!value) {
    return ""
  }

  return value.replace(/[&<>"']/g, (char) => HTML_ESCAPE[char] ?? char)
}
