"""Management command to generate djadmin view documentation."""

import json
from pathlib import Path

from django.core.management.base import BaseCommand
from django.template.loader import get_template

from djadmin_classy_doc.app_settings import get_known_plugins
from djadmin_classy_doc.classifier import ClassifierAdapter
from djadmin_classy_doc.view_introspector import ViewIntrospector


class DjAdminJSONEncoder(json.JSONEncoder):
    """Custom JSON encoder for non-serializable objects.

    Converts non-JSON-serializable objects to string representations.
    """

    def default(self, obj):
        """Handle non-serializable objects.

        Args:
            obj: Object to encode

        Returns:
            String representation or delegates to parent
        """
        # Handle model classes
        if hasattr(obj, '_meta'):
            return f'<class {obj._meta.label}>'

        # Handle function/method objects
        if callable(obj):
            return f'<function {getattr(obj, "__name__", str(obj))}>'

        # Handle dict-like objects with __str__
        if hasattr(obj, '__str__'):
            return str(obj)

        # Let the base class handle it
        return super().default(obj)


class Command(BaseCommand):
    """Generate static documentation for djadmin views."""

    help = 'Generate documentation for djadmin views'

    def add_arguments(self, parser):
        """Add command-line arguments.

        Args:
            parser: ArgumentParser instance
        """
        parser.add_argument(
            '--output-dir',
            default='./djadmin_docs',
            help='Output directory for generated documentation (default: ./djadmin_docs)',
        )
        parser.add_argument(
            '--format',
            choices=['json', 'html', 'markdown'],
            default='json',
            help='Output format (default: json)',
        )
        parser.add_argument(
            '--action-types-only',
            action='store_true',
            help='Only generate generic action type documentation (no model-specific views)',
        )
        parser.add_argument(
            '--models-only',
            action='store_true',
            help='Only generate model-specific view documentation (no generic action types)',
        )

    def handle(self, *args, **options):
        """Execute the command.

        Args:
            args: Positional arguments
            options: Parsed command-line options
        """
        output_dir = Path(options['output_dir'])
        output_format = options['format']
        action_types_only = options['action_types_only']
        models_only = options['models_only']

        # Create output directory
        output_dir.mkdir(parents=True, exist_ok=True)

        # Initialize introspector and classifier
        introspector = ViewIntrospector()
        classifier = ClassifierAdapter(introspector)

        # Get views based on flags
        all_views = []
        generic_views = []

        if not action_types_only:
            # Get model-specific and site-level views
            all_views.extend(introspector.get_registered_views())
            all_views.extend(introspector.get_site_actions())

        if not models_only:
            # Get generic action type views
            generic_views = introspector.get_generic_action_views()

        if not all_views and not generic_views:
            self.stdout.write(self.style.WARNING('No views found'))
            return

        # Prepare summary data
        summary = {
            'total_views': len(all_views),
            'model_views': len([v for v in all_views if v['model'] is not None]),
            'site_views': len([v for v in all_views if v['model'] is None]),
            'models': len({v['model'] for v in all_views if v['model'] is not None}),
            'generic_action_types': len(generic_views),
        }

        if output_format == 'json':
            self._generate_json(output_dir, all_views, generic_views, classifier, summary)
        elif output_format == 'html':
            self._generate_html(output_dir, all_views, generic_views, classifier, summary)
        elif output_format == 'markdown':
            self._generate_markdown(output_dir, all_views, generic_views, classifier, summary)
        else:
            self.stdout.write(self.style.ERROR(f'Unknown format: {output_format}'))

    def _generate_json(self, output_dir, all_views, generic_views, classifier, summary):
        """Generate JSON documentation.

        Args:
            output_dir: Output directory path
            all_views: List of view info dicts
            generic_views: List of generic action type view info dicts
            classifier: ClassifierAdapter instance
            summary: Summary stats dict
        """
        output_data = {
            'views': [],
            'action_types': [],
            'summary': summary,
        }

        # Process model-specific and site-level views
        for view_info in all_views:
            try:
                klass_data = classifier.classify_djadmin_view(
                    view_info['view_class'],
                    view_info['action'],
                )

                # Convert to serializable format
                # Handle None model gracefully
                model_value = str(view_info['model']._meta.label) if view_info['model'] is not None else None

                view_entry = {
                    'name': klass_data.get('name', view_info['view_class'].__name__),
                    'model': model_value,
                    'action': str(view_info['action']),
                    'action_type': view_info['action_type'],
                    'view_class': view_info['view_class'].__name__,
                    'module': view_info['view_class'].__module__,
                    'methods': list(klass_data.get('methods', {}).keys()),
                    'attributes': list(klass_data.get('attributes', {}).keys()),
                    'construction_info': self._serialize_construction_info(klass_data.get('construction_info', {})),
                    # Include any extra contextual info (e.g., app_label for app dashboards)
                    **{
                        k: v
                        for k, v in view_info.items()
                        if k not in ('action', 'view_class', 'model', 'model_admin', 'action_type')
                    },
                }
                output_data['views'].append(view_entry)

            except Exception as e:
                self.stdout.write(self.style.WARNING(f"Failed to classify {view_info['view_class'].__name__}: {e}"))

        # Process generic action type views
        for view_info in generic_views:
            try:
                klass_data = classifier.classify_djadmin_view(
                    view_info['view_class'],
                    view_info['action'],
                )

                action_type_entry = {
                    'name': view_info['view_class'].__name__,  # View class name (e.g., GenericListView)
                    'action_class': view_info['action'].__class__.__name__,  # Action class (e.g., ListAction)
                    'module': view_info['view_class'].__module__,
                    'action_type': view_info['action_type'],
                    'methods': list(klass_data.get('methods', {}).keys()),
                    'attributes': list(klass_data.get('attributes', {}).keys()),
                    'construction_info': self._serialize_construction_info(klass_data.get('construction_info', {})),
                }
                output_data['action_types'].append(action_type_entry)

            except Exception as e:
                action_name = view_info['action'].__class__.__name__
                self.stdout.write(self.style.WARNING(f'Failed to classify generic {action_name}: {e}'))

        # Write JSON output
        output_file = output_dir / 'views.json'
        try:
            with open(output_file, 'w') as f:
                json.dump(output_data, f, indent=2, cls=DjAdminJSONEncoder)

            self.stdout.write(
                self.style.SUCCESS(
                    f'Generated documentation: {output_file}\n'
                    f'  Total views: {output_data["summary"]["total_views"]}\n'
                    f'  Model views: {output_data["summary"]["model_views"]}\n'
                    f'  Site views: {output_data["summary"]["site_views"]}\n'
                    f'  Total models: {output_data["summary"]["models"]}\n'
                    f'  Generic action types: {output_data["summary"]["generic_action_types"]}'
                )
            )

        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Failed to write output: {e}'))

    def _generate_html(self, output_dir, all_views, generic_views, classifier, summary):
        """Generate HTML documentation.

        Args:
            output_dir: Output directory path
            all_views: List of view info dicts
            generic_views: List of generic action type view info dicts
            classifier: ClassifierAdapter instance
            summary: Summary stats dict
        """

        # Classify all views and organize by model
        classified_views = []
        model_views_by_model = {}
        site_views = []
        action_types = []

        # Process generic action type views first
        for view_info in generic_views:
            try:
                klass_data = classifier.classify_djadmin_view(
                    view_info['view_class'],
                    view_info['action'],
                )

                action_class_name = view_info['action'].__class__.__name__
                view_class_name = klass_data.get('name')
                klass_data['action'] = view_info.get('action')
                klass_data['model'] = None
                klass_data['model_admin'] = view_info.get('model_admin')

                filename = f'generic_{view_class_name}.html'

                action_types.append(
                    {
                        'name': action_class_name,  # Action class (e.g., ListAction)
                        'view_class': view_class_name,  # View class (e.g., GenericListView)
                        'action_type': view_info['action_type'],
                        'url': filename,
                    }
                )

                classified_views.append(
                    {
                        'klass_data': klass_data,
                        'view_info': view_info,
                        'filename': filename,
                    }
                )

            except Exception as e:
                action_class_name = view_info['action'].__class__.__name__
                self.stdout.write(self.style.WARNING(f'Failed to classify generic view for {action_class_name}: {e}'))

        # Process model-specific and site-level views
        for view_info in all_views:
            try:
                klass_data = classifier.classify_djadmin_view(
                    view_info['view_class'],
                    view_info['action'],
                )

                # Add action and model to klass_data for template context
                klass_data['action'] = view_info.get('action')
                klass_data['model'] = view_info.get('model')
                klass_data['model_admin'] = view_info.get('model_admin')

                # Generate filename using app prefix and class name for uniqueness
                view_name = klass_data.get('name')

                if view_info['model'] is not None:
                    app_label = view_info['model']._meta.app_label
                    model_label_str = view_info['model']._meta.label
                    filename = f'{app_label}_{view_name}.html'

                    if model_label_str not in model_views_by_model:
                        model_views_by_model[model_label_str] = []

                    model_views_by_model[model_label_str].append(
                        {
                            'name': view_name,
                            'view_class': view_name,
                            'action_class': view_info['action'].__class__.__name__,
                            'action_type': view_info['action_type'],
                            'url': filename,
                        }
                    )
                else:
                    # Site-level view - use app_label to make filename unique
                    app_label = view_info.get('app_label', 'site')
                    filename = f'{app_label}_{view_name}.html'

                    # Generate descriptive name for site-level views
                    if app_label == 'site':
                        view_display_name = 'ProjectDashboardView'
                    else:
                        # Capitalize first letter for display name
                        capitalized_app = app_label[0].upper() + app_label[1:] if app_label else ''
                        view_display_name = f'{capitalized_app}DashboardView'

                    site_views.append(
                        {
                            'name': view_display_name,
                            'view_class': view_name,
                            'action_class': view_info['action'].__class__.__name__,
                            'action_type': view_info['action_type'],
                            'app_label': app_label,
                            'url': filename,
                        }
                    )

                classified_views.append(
                    {
                        'klass_data': klass_data,
                        'view_info': view_info,
                        'filename': filename,
                    }
                )

            except Exception as e:
                self.stdout.write(self.style.WARNING(f"Failed to classify {view_info['view_class'].__name__}: {e}"))

        # Render index.html
        try:
            index_template = get_template('djadmin_classy_doc/index.html')
            index_context = {
                'summary': summary,
                'action_types': action_types,
                'site_views': site_views,
                'model_views_by_model': model_views_by_model,
                'known_plugins': get_known_plugins(),
            }

            index_html = index_template.render(index_context)
            index_file = output_dir / 'index.html'
            with open(index_file, 'w') as f:
                f.write(index_html)

            self.stdout.write(self.style.SUCCESS(f'Generated index: {index_file}'))

        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Failed to generate index.html: {e}'))

        # Render view_detail.html for each view
        view_template = get_template('djadmin_classy_doc/view_detail.html')
        html_count = 0

        for view in classified_views:
            try:
                klass_data = view['klass_data']

                # Serialize construction_info for template rendering
                # (to convert class objects to readable strings)
                serialized_construction_info = self._serialize_construction_info(klass_data.get('construction_info'))

                # Format action for display
                action_obj = klass_data.get('action')
                action_display = self._format_action(action_obj) if action_obj else ''

                view_context = {
                    'klass': klass_data,
                    'model': klass_data.get('model'),
                    'action': action_display,
                    'construction_info': serialized_construction_info,
                    'known_plugins': get_known_plugins(),
                }

                html_content = view_template.render(view_context)
                html_file = output_dir / view['filename']

                with open(html_file, 'w') as f:
                    f.write(html_content)

                html_count += 1

            except Exception as e:
                view_class_name = view['view_info']['view_class'].__name__
                self.stdout.write(self.style.WARNING(f'Failed to render {view_class_name} ({view["filename"]}): {e}'))

        self.stdout.write(
            self.style.SUCCESS(
                f'Generated HTML documentation in {output_dir}\n'
                f'  Index: index.html\n'
                f'  View pages: {html_count}\n'
                f'  Total views: {summary["total_views"]}\n'
                f'  Model views: {summary["model_views"]}\n'
                f'  Site views: {summary["site_views"]}\n'
                f'  Generic action types: {summary["generic_action_types"]}'
            )
        )

    def _generate_markdown(self, output_dir, all_views, generic_views, classifier, summary):
        """Generate Markdown documentation for mkdocs.

        Args:
            output_dir: Output directory path
            all_views: List of view info dicts
            generic_views: List of generic action type view info dicts
            classifier: ClassifierAdapter instance
            summary: Summary stats dict
        """
        # Classify generic action views
        action_types = []

        for view_info in generic_views:
            try:
                klass_data = classifier.classify_djadmin_view(
                    view_info['view_class'],
                    view_info['action'],
                )

                action_class_name = view_info['action'].__class__.__name__
                view_class_name = klass_data.get('name')
                klass_data['action'] = view_info.get('action')
                klass_data['model'] = None

                filename = f'{view_class_name}.md'

                action_types.append(
                    {
                        'action_class': action_class_name,
                        'view_class': view_class_name,
                        'action_type': view_info['action_type'],
                        'filename': filename,
                        'klass_data': klass_data,
                    }
                )

            except Exception as e:
                action_class_name = view_info['action'].__class__.__name__
                self.stdout.write(self.style.WARNING(f'Failed to classify generic view for {action_class_name}: {e}'))

        # Generate index.md
        index_content = self._generate_markdown_index(action_types, summary)
        index_file = output_dir / 'index.md'
        with open(index_file, 'w') as f:
            f.write(index_content)
        self.stdout.write(self.style.SUCCESS(f'Generated index: {index_file}'))

        # Generate individual view markdown files
        md_count = 0
        for action_type in action_types:
            try:
                md_content = self._generate_markdown_view(action_type)
                md_file = output_dir / action_type['filename']
                with open(md_file, 'w') as f:
                    f.write(md_content)
                md_count += 1
            except Exception as e:
                self.stdout.write(self.style.WARNING(f'Failed to generate {action_type["filename"]}: {e}'))

        self.stdout.write(
            self.style.SUCCESS(
                f'Generated Markdown documentation in {output_dir}\n'
                f'  Index: index.md\n'
                f'  View pages: {md_count}\n'
                f'  Generic action types: {summary["generic_action_types"]}'
            )
        )

    def _generate_markdown_index(self, action_types, summary):
        """Generate index.md content for generic action views.

        Args:
            action_types: List of action type dicts
            summary: Summary stats dict

        Returns:
            Markdown string
        """
        lines = [
            '# Generated View Classes',
            '',
            "This documentation is auto-generated from djadmin's ViewFactory output.",
            'It shows the structure of dynamically generated view classes including',
            'their methods, attributes, and plugin contributions.',
            '',
            '## Generic Action Views',
            '',
            'These are the base view patterns generated for each action type.',
            'Model-specific views inherit from these patterns with additional',
            'model-specific configuration.',
            '',
            '| Action | View Class | Type |',
            '|--------|------------|------|',
        ]

        for action_type in action_types:
            view_name = action_type['view_class']
            action_name = action_type['action_class']
            action_type_str = action_type['action_type']
            link = f'[{view_name}]({action_type["filename"]})'
            lines.append(f'| {action_name} | {link} | {action_type_str} |')

        lines.extend(
            [
                '',
                '## Summary',
                '',
                f'- **Generic action types**: {summary["generic_action_types"]}',
                '',
            ]
        )

        return '\n'.join(lines)

    def _generate_markdown_view(self, action_type):
        """Generate markdown content for a single view class.

        Args:
            action_type: Dict with view info and klass_data

        Returns:
            Markdown string
        """
        klass_data = action_type['klass_data']
        view_class = action_type['view_class']
        action_class = action_type['action_class']

        lines = [
            f'# {view_class}',
            '',
            f'Generated view class for **{action_class}**.',
            '',
        ]

        # Add class docstring if available
        docstring = klass_data.get('docstring', '')
        if docstring:
            lines.extend(
                [
                    '```',
                    docstring.strip(),
                    '```',
                    '',
                ]
            )

        # Construction Info
        construction_info = self._serialize_construction_info(klass_data.get('construction_info', {}))

        if construction_info:
            lines.extend(
                [
                    '## Construction Info',
                    '',
                    'How ViewFactory builds this view:',
                    '',
                ]
            )

            # Base class
            if construction_info.get('base_class'):
                bc = construction_info['base_class']
                lines.extend(
                    [
                        '### Base Class',
                        '',
                        f'`{bc["class"]}`',
                        '',
                    ]
                )
                if bc.get('plugin'):
                    lines.append(f'- **Plugin**: `{bc["plugin"]}`')
                if bc.get('hook'):
                    lines.append(f'- **Hook**: `{bc["hook"]}`')
                lines.append('')

            # Mixins
            if construction_info.get('mixins'):
                lines.extend(
                    [
                        '### Mixins',
                        '',
                        '| Mixin | Plugin | Hook |',
                        '|-------|--------|------|',
                    ]
                )
                for mixin in construction_info['mixins']:
                    plugin = mixin.get('plugin', '-')
                    hook = mixin.get('hook', '-')
                    lines.append(f'| `{mixin["class"]}` | `{plugin}` | `{hook}` |')
                lines.append('')

            # Bound methods
            if construction_info.get('bound_methods'):
                lines.extend(
                    [
                        '### Bound Methods',
                        '',
                        'Methods bound from the action class:',
                        '',
                        '| Method | Action Class | Plugin |',
                        '|--------|--------------|--------|',
                    ]
                )
                for method_name, method_info in construction_info['bound_methods'].items():
                    action_cls = method_info.get('action_class', '-')
                    plugin = method_info.get('plugin', '-')
                    lines.append(f'| `{method_name}` | `{action_cls}` | `{plugin}` |')
                lines.append('')

        # MRO
        if klass_data.get('annotated_mro'):
            lines.extend(
                [
                    '## Method Resolution Order',
                    '',
                ]
            )
            for i, ancestor in enumerate(klass_data['annotated_mro'], 1):
                cls_name = ancestor.get('class', {})
                if hasattr(cls_name, '__name__'):
                    cls_name = cls_name.__name__
                module = ancestor.get('module', '')
                plugin = ancestor.get('plugin', '')
                source = ancestor.get('source', '')

                line = f'{i}. `{cls_name}`'
                if module:
                    line += f' ({module})'
                if plugin:
                    line += f' - *{plugin}*'
                elif source:
                    line += f' - *{source}*'
                lines.append(line)
            lines.append('')

        # Methods
        if klass_data.get('methods'):
            lines.extend(
                [
                    '## Methods',
                    '',
                ]
            )
            # Get bound methods for checking
            bound_methods = klass_data.get('construction_info', {}).get('bound_methods', {})

            for method_name, declarations in sorted(klass_data['methods'].items()):
                if declarations:
                    decl_list = declarations if isinstance(declarations, list) else [declarations]
                    first_decl = decl_list[0]

                    # Extract defining class from the first declaration
                    defining_class = self._get_defining_class_str(first_decl)
                    # Check if this is a bound method
                    is_bound = method_name in bound_methods
                    bound_marker = ' **(bound)**' if is_bound else ''

                    # Get method signature
                    arguments = first_decl.get('arguments') if isinstance(first_decl, dict) else None
                    if not arguments:
                        arguments = '(self)'

                    lines.append(f'### `{method_name}{arguments}`{bound_marker}')
                    lines.append('')
                    lines.append(f'**Defined in:** {defining_class}')
                    lines.append('')

                    # Add docstring from first declaration if available
                    docstring = first_decl.get('docstring', '') if isinstance(first_decl, dict) else ''
                    if docstring:
                        lines.append(docstring.strip())
                        lines.append('')

                    # Show source code from all declarations in MRO
                    for decl in decl_list:
                        if not isinstance(decl, dict):
                            continue

                        decl_class = self._get_defining_class_str(decl)
                        code = decl.get('code', '')

                        if code:
                            if len(decl_list) > 1:
                                # Show which class this implementation is from
                                lines.append(f'#### {decl_class}')
                                lines.append('')

                            lines.append('```python')
                            lines.append(code.strip())
                            lines.append('```')
                            lines.append('')

        # Attributes
        if klass_data.get('attributes'):
            lines.extend(
                [
                    '## Attributes',
                    '',
                    '| Attribute | Value | Defined in |',
                    '|-----------|-------|------------|',
                ]
            )
            for attr_name, declarations in sorted(klass_data['attributes'].items()):
                if declarations:
                    first_decl = declarations[0] if isinstance(declarations, list) else declarations
                    # Extract defining class from the declaration
                    defining_class = self._get_defining_class_str(first_decl)
                    # Get value from the 'object' key
                    value = first_decl.get('object', '') if isinstance(first_decl, dict) else ''
                    value_str = self._format_attribute_value(value)
                    lines.append(f'| `{attr_name}` | `{value_str}` | {defining_class} |')
            lines.append('')

        return '\n'.join(lines)

    def _get_defining_class_str(self, declaration):
        """Extract defining class string from a declaration dict.

        Args:
            declaration: Dict with 'defining_class' key (tuple or class object)

        Returns:
            String like 'module.ClassName'
        """
        if not isinstance(declaration, dict):
            return ''

        defining_class = declaration.get('defining_class')
        if not defining_class:
            return ''

        if isinstance(defining_class, tuple):
            # Tuple format: (module, class_name)
            return f'{defining_class[0]}.{defining_class[1]}'
        elif hasattr(defining_class, '__module__') and hasattr(defining_class, '__name__'):
            # Class object
            return f'{defining_class.__module__}.{defining_class.__name__}'
        else:
            return str(defining_class)

    def _format_attribute_value(self, value):
        """Format attribute value for markdown display.

        Args:
            value: The attribute value

        Returns:
            Formatted string suitable for markdown table
        """
        import html
        import re

        if value is None:
            return 'None'

        value_str = str(value)

        # Decode HTML entities
        value_str = html.unescape(value_str)

        # Clean up class representations: <class 'foo.Bar'> → foo.Bar
        class_match = re.match(r"^<class '([^']+)'>$", value_str)
        if class_match:
            value_str = class_match.group(1)

        # Clean up function repr: <function name at 0x...> → name()
        value_str = re.sub(r'<function ([^\s>]+)[^>]*>', r'\1()', value_str)

        # Clean up bound method repr
        value_str = re.sub(r'<bound method ([^>]+)>', r'\1()', value_str)

        # Truncate long values
        if len(value_str) > 50:
            value_str = value_str[:47] + '...'

        # Escape pipe characters and remove newlines for table compatibility
        value_str = value_str.replace('|', '\\|').replace('\n', ' ')

        return value_str

    def _serialize_construction_info(self, construction_info):
        """Serialize construction info for JSON output.

        Args:
            construction_info: Construction info dict from introspector

        Returns:
            Serializable dict with plugin attribution
        """
        if not construction_info:
            return {}

        serialized = {
            'base_class': None,
            'mixins': [],
            'attributes': {},
            'bound_methods': {},
        }

        # Serialize base_class
        if construction_info.get('base_class'):
            bc = construction_info['base_class']
            serialized['base_class'] = {
                'class': self._format_class_path(bc.get('class')),
                'source': bc.get('source', ''),
                'plugin': bc.get('plugin', ''),
                'hook': bc.get('hook', ''),
            }

        # Serialize mixins
        for mixin_info in construction_info.get('mixins', []):
            mixin_class = mixin_info.get('class')
            serialized['mixins'].append(
                {
                    'class': self._format_class_path(mixin_class),
                    'source': mixin_info.get('source', ''),
                    'plugin': mixin_info.get('plugin', ''),
                    'hook': mixin_info.get('hook', ''),
                }
            )

        # Serialize attributes
        for attr_name, attr_info in construction_info.get('attributes', {}).items():
            serialized['attributes'][attr_name] = {
                'value': str(attr_info.get('value', '')),
                'plugin': attr_info.get('plugin', ''),
                'hook': attr_info.get('hook', ''),
            }

        # Serialize bound_methods
        for method_name, method_info in construction_info.get('bound_methods', {}).items():
            action_class = method_info.get('action_class')
            action_class_name = method_info.get('action_class_name', '')
            if action_class and not action_class_name:
                # Fallback if name not already captured
                action_class_name = self._format_class_path(action_class)

            serialized['bound_methods'][method_name] = {
                'plugin': method_info.get('plugin', ''),
                'hook': method_info.get('hook', ''),
                'action_class': action_class_name,
            }

        return serialized

    def _format_class_path(self, cls):
        """Format a class as a full module path string.

        Args:
            cls: A class object or string representation

        Returns:
            String like 'djadmin.plugins.core.mixins.DjAdminViewMixin'
        """
        if isinstance(cls, str):
            return cls

        if not hasattr(cls, '__module__') or not hasattr(cls, '__name__'):
            return str(cls)

        # Return full module path: module.ClassName
        return f'{cls.__module__}.{cls.__name__}'

    def _format_action(self, action):
        """Format an action instance as a readable string.

        Args:
            action: An action instance

        Returns:
            String like 'ListAction' or 'DashboardAction'
        """
        if isinstance(action, str):
            return action

        if hasattr(action, '__class__'):
            return action.__class__.__name__

        return str(action)
