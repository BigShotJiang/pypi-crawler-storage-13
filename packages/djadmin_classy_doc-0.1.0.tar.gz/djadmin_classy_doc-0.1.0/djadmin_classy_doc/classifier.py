"""Classifies djadmin views using django-classy-doc patterns with djadmin extensions."""

from typing import Any

from django_classy_doc.utils import DefaultOrderedDict
from django_classy_doc.utils import classify as dc_classify

from .view_introspector import ViewIntrospector


class ClassifierAdapter:
    """Adapts django-classy-doc's classify() function for factory-generated views.

    Wraps django-classy-doc's introspection to work with dynamically generated
    views created by djadmin's ViewFactory, adding djadmin-specific metadata.
    """

    def __init__(self, introspector=None):
        """Initialize with optional ViewIntrospector.

        Args:
            introspector: A ViewIntrospector instance. If None, creates a new one.
        """
        if introspector is None:
            introspector = ViewIntrospector()

        self.introspector = introspector

    def classify_djadmin_view(self, view_class: type, action: Any) -> dict[str, Any]:
        """Enhanced classify() for factory-generated views.

        Uses django-classy-doc's introspection and extends with djadmin-specific
        metadata (action, model, model_admin, construction_info).

        Args:
            view_class: The generated view class
            action: The Action instance that generated the view

        Returns:
            Dict with django-classy-doc structure plus djadmin extensions:
                - Standard django-classy-doc fields: name, module, docstring,
                  ancestors, parents, attributes, methods, fields, properties
                - djadmin extensions: action, model, model_admin, construction_info,
                  annotated_mro
        """
        # 1. Initialize klass dict with django-classy-doc structure
        klass = {
            'attributes': DefaultOrderedDict(list),
            'methods': DefaultOrderedDict(list),
            'fields': DefaultOrderedDict(list),
            'properties': [],
            'ancestors': [],
            'parents': [],
            'everything': DefaultOrderedDict(list),
        }

        # 2. Use django-classy-doc's classify() to extract methods/attributes from real class
        dc_classify(klass, view_class)

        # 3. Add djadmin-specific extensions
        klass['action'] = action
        # Handle both model-specific and site-level actions (model can be None)
        klass['model'] = action.model if hasattr(action, 'model') else None
        klass['model_admin'] = action.model_admin if hasattr(action, 'model_admin') else None

        # 4. Add construction info with plugin attribution
        construction_info = self.introspector.introspect_action(action, view_class)
        klass['construction_info'] = construction_info

        # 5. Add annotated MRO showing plugin sources
        klass['annotated_mro'] = self._annotate_mro(view_class, construction_info)

        # 6. Add bound methods to methods dict and enrich with source code
        if action and hasattr(action, '__class__'):
            self._add_bound_methods_to_dict(klass, action)
            self._add_bound_method_source(klass, action)

        return klass

    def _annotate_mro(self, view_class: type, construction_info: dict[str, Any]) -> list[dict]:
        """Add plugin source attribution to Method Resolution Order.

        Args:
            view_class: The generated view class
            construction_info: Construction info dict from introspector

        Returns:
            List of dicts with MRO entries annotated with source/plugin info
        """
        annotated = []

        for ancestor in view_class.__mro__:
            # Skip builtins.object - everything inherits from it
            if ancestor is object:
                continue

            entry = {
                'class': ancestor,
                'name': ancestor.__name__,
                'module': ancestor.__module__,
                'source': None,  # Will be filled if we find source info
            }

            # Try to find this class in construction info
            # Check if it's a mixin from construction_info['mixins']
            for mixin_info in construction_info.get('mixins', []):
                if mixin_info['class'] == ancestor:
                    plugin_name = mixin_info.get('plugin', '')
                    entry['plugin'] = plugin_name
                    entry['source'] = f'{plugin_name} plugin' if plugin_name else ''
                    entry['hook'] = mixin_info.get('hook')
                    break

            # Check if it's the base class
            base_class_info = construction_info.get('base_class')
            if base_class_info is not None and ancestor == base_class_info.get('class'):
                plugin_name = base_class_info.get('plugin', '')
                action = construction_info.get('action')
                action_name = action.__class__.__name__ if action else ''

                entry['plugin'] = plugin_name
                entry['source'] = f'base class from {action_name}' if action_name else 'base class'
                entry['hook'] = base_class_info.get('hook')
                entry['is_base_class'] = True

            annotated.append(entry)

        return annotated

    def _add_bound_methods_to_dict(self, klass: dict, action: Any) -> None:
        """Add bound methods from action class to methods dict.

        Bound methods from action classes may not appear in the view class's
        methods dict if they're only defined on the action class. This ensures
        they appear in the Methods section of the documentation.

        Args:
            klass: The classified view dict (modified in place)
            action: The Action instance
        """
        import inspect

        construction_info = klass.get('construction_info', {})
        bound_method_names = construction_info.get('bound_methods', {}).keys()

        if not bound_method_names:
            return

        action_class = action.__class__
        methods_dict = klass.get('methods', {})

        for method_name in bound_method_names:
            # Try to get the method from the action class
            try:
                method = getattr(action_class, method_name, None)
                if method is None:
                    continue

                # Create a declaration entry for this bound method
                # Use similar structure to what django-classy-doc creates
                declaration = {
                    'defining_class': (action_class.__module__, action_class.__name__),
                    'type': 'method',
                    'docstring': inspect.getdoc(method) or '',
                    'arguments': self._get_method_arguments(method),
                    'code': '',  # Will be filled by _add_bound_method_source
                    'lines': {'start': 0, 'total': 0},
                    'object': f'<bound method {action_class.__name__}.{method_name}>',
                }

                # Add to methods dict - if method already exists, annotate the last
                # declaration as bound from action (don't create duplicate)
                # Note: Template iterates reversed, so last declaration is shown first
                if method_name in methods_dict:
                    # Mark the last declaration (most derived, shown first) as bound from action
                    last_decl = methods_dict[method_name][-1]
                    last_decl['bound_from'] = (action_class.__module__, action_class.__name__)
                    last_decl['bound_docstring'] = declaration['docstring']
                    # Source code will be added by _add_bound_method_source
                else:
                    # Method only exists on action, create new declaration
                    methods_dict[method_name] = [declaration]

            except (OSError, TypeError):
                # Can't get source for built-in methods
                pass

    def _get_method_arguments(self, method):
        """Extract method signature as a string.

        Args:
            method: A method object

        Returns:
            String like '(self, arg1, arg2)' or None
        """
        import inspect

        try:
            sig = inspect.signature(method)
            return f'({str(sig)[1:-1]})'  # Remove the parens inspect adds, then add them back
        except (ValueError, TypeError):
            return None

    def _add_bound_method_source(self, klass: dict, action: Any) -> None:
        """Add source code for methods bound from action class.

        For methods that are bound from the action class, try to get their
        source code and add it to the method declarations. We add the source
        code to ALL declarations of the method since the action's implementation
        overrides all mixins.

        Args:
            klass: The classified view dict (modified in place)
            action: The Action instance
        """
        import inspect

        # Get bound methods from construction_info
        construction_info = klass.get('construction_info', {})
        bound_method_names = set(construction_info.get('bound_methods', {}).keys())

        if not bound_method_names:
            return

        action_class = action.__class__
        methods_dict = klass.get('methods', {})

        for method_name in bound_method_names:
            if method_name not in methods_dict:
                continue

            # Try to get the method from the action class
            try:
                method = getattr(action_class, method_name, None)
                if method is None:
                    continue

                # Get source code and line info
                source_lines = inspect.getsourcelines(method)
                code = ''.join(source_lines[0])
                start_line = source_lines[1]
                file_path = inspect.getfile(action_class)

                # Get the method declarations list
                declarations = methods_dict[method_name]

                # For bound methods, add the action's source code to the first
                # (most recent) declaration. This is the one that will be shown.
                if declarations:
                    # Add to the first declaration (the one from the action class or its mixins)
                    declaration = declarations[0]
                    declaration['code'] = code
                    declaration['lines'] = {
                        'start': start_line,
                        'total': len(source_lines[0]),
                    }
                    declaration['file'] = file_path

            except (OSError, TypeError):
                # Can't get source for built-in methods or other edge cases
                pass
