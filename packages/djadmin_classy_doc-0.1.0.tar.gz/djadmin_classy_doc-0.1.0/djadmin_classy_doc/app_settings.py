"""Settings for djadmin-classy-doc plugin.

Uses same pattern as django-classy-doc, with defaults that can be overridden
in Django settings using DJADMIN_CLASSY_DOC_* settings.
"""

from django.conf import settings as django_settings

# Default known plugins for filtering in templates
DJADMIN_CLASSY_DOC_KNOWN_PLUGINS = {
    'Core': [
        'djadmin.plugins.core',
    ],
    'Theme': [
        'djadmin.plugins.theme',
    ],
    'Django': [
        'django',
    ],
}

# Override with Django settings if provided
if hasattr(django_settings, 'DJADMIN_CLASSY_DOC_KNOWN_PLUGINS'):
    DJADMIN_CLASSY_DOC_KNOWN_PLUGINS = django_settings.DJADMIN_CLASSY_DOC_KNOWN_PLUGINS


def get_known_plugins():
    """Get known plugins for filtering in templates.

    Returns a dict mapping plugin names to module patterns:
    {
        'Core': ['djadmin.plugins.core'],
        'Theme': ['djadmin.plugins.theme'],
        'Django': ['django'],
    }
    """
    return DJADMIN_CLASSY_DOC_KNOWN_PLUGINS
