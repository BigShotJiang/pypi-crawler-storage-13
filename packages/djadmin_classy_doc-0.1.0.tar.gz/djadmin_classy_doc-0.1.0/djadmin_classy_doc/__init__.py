"""Django admin documentation generator using django-classy-doc patterns."""

__version__ = '0.1.0'
