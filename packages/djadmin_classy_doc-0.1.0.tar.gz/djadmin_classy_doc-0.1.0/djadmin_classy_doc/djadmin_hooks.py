"""djadmin hooks for djadmin-classy-doc plugin.

This plugin provides documentation generation for djadmin views.
It doesn't contribute any mixins or actions, but registers itself
as a plugin for visibility in generated view docstrings.
"""

from djadmin.plugins import hookimpl


@hookimpl
def djadmin_provides_features():
    """Advertise features provided by this plugin."""
    return ['classy-doc']
