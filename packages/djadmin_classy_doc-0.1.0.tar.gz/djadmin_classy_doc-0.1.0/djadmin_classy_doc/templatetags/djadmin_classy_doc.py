"""Template tags for djadmin-classy-doc view documentation."""

from django import template
from django.utils.text import capfirst

register = template.Library()


@register.filter
def display_if(value):
    """Generate Alpine.js variable name for show/hide based on plugin.

    For each item in known_plugins, returns a variable name like:
    'showCore' (for plugin name 'Core')
    'showTheme' (for plugin name 'Theme')

    Falls back to 'true' if defining_class can't be determined.
    """
    module_name = None

    try:
        # value should be a dict with 'defining_class' key
        if isinstance(value, dict):
            defining_class = value.get('defining_class')
            if isinstance(defining_class, tuple):
                module_name = defining_class[0]
            elif hasattr(defining_class, '__module__'):
                module_name = defining_class.__module__
        elif hasattr(value, '__module__'):
            # Fallback: if value is an object with __module__
            module_name = value.__module__
    except (AttributeError, TypeError, KeyError):
        pass

    # If we couldn't determine module, fall back to always showing
    if module_name is None:
        return 'true'

    # Get known plugins from settings
    from djadmin_classy_doc.app_settings import get_known_plugins

    known_plugins = get_known_plugins()

    for plugin_name, module_patterns in known_plugins.items():
        if any(module_name.startswith(f'{mod}.') or module_name == mod for mod in module_patterns):
            # Convert plugin name to variable name (e.g., 'Core' -> 'showCore')
            clean_name = plugin_name.replace(' ', '')
            return f'show{capfirst(clean_name)}'

    return 'true'


@register.simple_tag
def init_show_vars():
    """Initialize Alpine.js variables for plugin checkboxes.

    Returns JavaScript initialization like:
    'showCore: true, showTheme: true, ...'

    All checkboxes are checked by default since developers typically
    want to see all methods when viewing documentation.
    """
    from djadmin_classy_doc.app_settings import get_known_plugins

    known_plugins = get_known_plugins()
    vars_list = []

    for plugin_name in known_plugins.keys():
        clean_name = plugin_name.replace(' ', '')
        vars_list.append(f'show{capfirst(clean_name)}: true')

    return ', '.join(vars_list)


@register.filter
def module(value):
    """Extract module name from defining_class."""
    if isinstance(value, dict):
        defining_class = value.get('defining_class')
    else:
        defining_class = value

    if isinstance(defining_class, tuple):
        return defining_class[0]
    else:
        return defining_class.__module__


@register.filter
def class_name(value):
    """Extract class name from defining_class."""
    if isinstance(value, dict):
        defining_class = value.get('defining_class')
    else:
        defining_class = value

    if isinstance(defining_class, tuple):
        return defining_class[1]
    else:
        return defining_class.__name__


@register.filter
def format_value(value):
    """Format attribute values for better display.

    - Cleans up class repr: <class 'module.Class'> → module.Class
    - Cleans up function repr: <function name at 0x...> → name()
    - Pretty prints lists with multiple items
    """
    import html
    import re

    if not value:
        return value

    # Unescape HTML entities first
    unescaped = html.unescape(str(value))

    # Clean up class representations: <class 'foo.Bar'> → foo.Bar
    class_match = re.match(r"^<class '([^']+)'>$", unescaped)
    if class_match:
        return class_match.group(1)

    # Clean up function repr: <function name at 0x...> → name()
    # This regex handles function repr both inside and outside of lists
    unescaped = re.sub(r'<function ([^\s>]+)[^>]*>', r'\1()', unescaped)

    # Clean up bound method repr
    unescaped = re.sub(r'<bound method ([^>]+)>', r'\1()', unescaped)

    # Pretty print lists with multiple items (look for "), " pattern which indicates list items)
    # Match lists that contain at least 2 items (have at least one ", " between items)
    if unescaped.startswith('[') and unescaped.endswith(']') and '), ' in unescaped:
        # Split on "), " to find list items, then rejoin with newlines
        # This works for lists of objects with repr like "ClassName(...)"
        items = re.split(r'\), ', unescaped[1:-1])
        if len(items) > 1:
            # Re-add the closing paren that was removed by split (except for last item)
            formatted_items = [item + ')' if i < len(items) - 1 else item for i, item in enumerate(items)]
            return '[\n    ' + ',\n    '.join(formatted_items) + '\n]'

    return unescaped


@register.filter
def items(value, key):
    """Get items from a dict key (for use in for loops)."""
    return value[key].items()


@register.filter
def is_bound_method(method_name, construction_info):
    """Check if a method is bound from an action class.

    Returns True if the method is in construction_info.bound_methods.
    """
    if not construction_info:
        return False

    bound_methods = construction_info.get('bound_methods', {})
    return method_name in bound_methods


@register.filter
def action_class_name(method_name, construction_info):
    """Get the action class name for a bound method."""
    if not construction_info:
        return ''

    bound_methods = construction_info.get('bound_methods', {})
    method_info = bound_methods.get(method_name, {})
    return method_info.get('action_class', '')
