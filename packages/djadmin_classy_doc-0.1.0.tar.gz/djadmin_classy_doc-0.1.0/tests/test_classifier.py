"""Tests for ClassifierAdapter."""

from djadmin import ModelAdmin
from djadmin.factories import ViewFactory
from djadmin.plugins.core.actions import AddAction, ListAction
from examples.webshop.models import Product

from djadmin_classy_doc.classifier import ClassifierAdapter
from djadmin_classy_doc.view_introspector import ViewIntrospector


class TestClassifierAdapter:
    """Test view classification functionality."""

    def test_classify_djadmin_view_returns_dict(self, admin_site):
        """Test that classify_djadmin_view returns a dict."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        view_class = ViewFactory().create_view(action)
        klass_data = classifier.classify_djadmin_view(view_class, action)

        assert isinstance(klass_data, dict)

    def test_classify_djadmin_view_includes_django_classy_doc_fields(self, admin_site):
        """Test that classify_djadmin_view includes django-classy-doc fields."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        view_class = ViewFactory().create_view(action)
        klass_data = classifier.classify_djadmin_view(view_class, action)

        # Check for django-classy-doc fields
        assert 'attributes' in klass_data
        assert 'methods' in klass_data
        assert 'fields' in klass_data
        assert 'properties' in klass_data
        assert 'ancestors' in klass_data
        assert 'parents' in klass_data

    def test_classify_djadmin_view_includes_action(self, admin_site):
        """Test that classify_djadmin_view includes action metadata."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        view_class = ViewFactory().create_view(action)
        klass_data = classifier.classify_djadmin_view(view_class, action)

        assert 'action' in klass_data
        assert klass_data['action'] == action

    def test_classify_djadmin_view_includes_model(self, admin_site):
        """Test that classify_djadmin_view includes model metadata."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        view_class = ViewFactory().create_view(action)
        klass_data = classifier.classify_djadmin_view(view_class, action)

        assert 'model' in klass_data
        assert klass_data['model'] == Product

    def test_classify_djadmin_view_includes_model_admin(self, admin_site):
        """Test that classify_djadmin_view includes model_admin metadata."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        view_class = ViewFactory().create_view(action)
        klass_data = classifier.classify_djadmin_view(view_class, action)

        assert 'model_admin' in klass_data
        assert klass_data['model_admin'] == model_admin

    def test_classify_djadmin_view_with_different_actions(self, admin_site):
        """Test classify_djadmin_view with different action types."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        # Test with ListAction
        list_action = ListAction(Product, model_admin, admin_site)
        list_view = ViewFactory().create_view(list_action)
        list_data = classifier.classify_djadmin_view(list_view, list_action)

        assert list_data['action'] == list_action
        assert list_data['model'] == Product

        # Test with AddAction
        add_action = AddAction(Product, model_admin, admin_site)
        add_view = ViewFactory().create_view(add_action)
        add_data = classifier.classify_djadmin_view(add_view, add_action)

        assert add_data['action'] == add_action
        assert add_data['model'] == Product

    def test_classifier_uses_provided_introspector(self, admin_site):
        """Test that classifier uses provided introspector."""
        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        assert classifier.introspector == introspector

    def test_classifier_creates_default_introspector(self):
        """Test that classifier creates default introspector if none provided."""
        classifier = ClassifierAdapter()

        assert classifier.introspector is not None
        assert isinstance(classifier.introspector, ViewIntrospector)

    def test_classify_djadmin_view_methods_are_discovered(self, admin_site):
        """Test that view methods are discovered."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        view_class = ViewFactory().create_view(action)
        klass_data = classifier.classify_djadmin_view(view_class, action)

        # View methods should be discovered
        methods = klass_data['methods']
        # View classes typically have methods like 'get', 'post', 'get_queryset', etc.
        assert isinstance(methods, dict)
        # ListViews typically have get method
        assert 'get' in methods or len(methods) > 0

    def test_classify_djadmin_view_attributes_are_discovered(self, admin_site):
        """Test that view attributes are discovered."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        view_class = ViewFactory().create_view(action)
        klass_data = classifier.classify_djadmin_view(view_class, action)

        # View attributes should be discovered
        attributes = klass_data['attributes']
        assert isinstance(attributes, dict)
        # Factory-generated views should have some attributes
        assert len(attributes) > 0

    def test_classify_djadmin_view_handles_none_model(self, admin_site):
        """ClassifierAdapter should handle model=None as a normal case."""
        from djadmin.actions.dashboard import DashboardAction

        action = DashboardAction(admin_site=admin_site)
        view_class = ViewFactory().create_view(action)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        klass_data = classifier.classify_djadmin_view(view_class, action)

        # Should have None model - this is normal, not special
        assert klass_data['model'] is None
        assert klass_data['model_admin'] is None

        # Should still have all standard classification data
        assert 'methods' in klass_data
        assert 'attributes' in klass_data
        assert 'name' in klass_data

    def test_classify_djadmin_view_includes_construction_info(self, admin_site):
        """Test that classify_djadmin_view includes construction_info."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        view_class = ViewFactory().create_view(action)
        klass_data = classifier.classify_djadmin_view(view_class, action)

        # Should include construction info
        assert 'construction_info' in klass_data
        assert 'mixins' in klass_data['construction_info']
        assert 'attributes' in klass_data['construction_info']

    def test_classify_djadmin_view_construction_info_has_plugin_attribution(self, admin_site):
        """Test that construction_info includes plugin attribution."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        view_class = ViewFactory().create_view(action)
        klass_data = classifier.classify_djadmin_view(view_class, action)

        # Check mixins have plugin attribution
        construction_info = klass_data['construction_info']
        if construction_info['mixins']:
            for mixin_info in construction_info['mixins']:
                assert 'plugin' in mixin_info
                assert 'hook' in mixin_info

    def test_classify_djadmin_view_construction_info_works_for_site_actions(self, admin_site):
        """Test that construction_info works for site-level actions."""
        from djadmin.actions.dashboard import DashboardAction

        action = DashboardAction(admin_site=admin_site)
        view_class = ViewFactory().create_view(action)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        klass_data = classifier.classify_djadmin_view(view_class, action)

        # Should have construction info even for site-level actions
        assert 'construction_info' in klass_data
        assert 'mixins' in klass_data['construction_info']
        assert 'attributes' in klass_data['construction_info']

    def test_classify_djadmin_view_includes_annotated_mro(self, admin_site):
        """Test that classify_djadmin_view includes annotated_mro."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        view_class = ViewFactory().create_view(action)
        klass_data = classifier.classify_djadmin_view(view_class, action)

        # Should include annotated_mro
        assert 'annotated_mro' in klass_data
        assert isinstance(klass_data['annotated_mro'], list)
        assert len(klass_data['annotated_mro']) > 0

    def test_annotated_mro_shows_plugin_attribution(self, admin_site):
        """Test that annotated_mro shows plugin sources for mixins."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        classifier = ClassifierAdapter(introspector)

        view_class = ViewFactory().create_view(action)
        klass_data = classifier.classify_djadmin_view(view_class, action)

        # Check that MRO entries have expected structure
        for mro_entry in klass_data['annotated_mro']:
            assert 'class' in mro_entry
            assert 'name' in mro_entry
            assert 'module' in mro_entry
            # Plugin info may or may not be present, depends on class

    def test_bound_methods_include_action_class_reference(self, admin_site):
        """Test that bound_methods include action class reference."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)

        construction_info = introspector.introspect_action(action)

        # Check that bound methods have action class reference
        if construction_info['bound_methods']:
            for _method_name, method_info in construction_info['bound_methods'].items():
                assert 'action_class' in method_info
                assert 'action_class_name' in method_info
                # action_class should be the action's class
                assert method_info['action_class'] == action.__class__
                assert method_info['action_class_name'] == action.__class__.__name__
