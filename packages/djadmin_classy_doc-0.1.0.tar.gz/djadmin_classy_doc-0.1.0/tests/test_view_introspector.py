"""Tests for ViewIntrospector."""

from djadmin import ModelAdmin
from djadmin.plugins.core.actions import ListAction
from examples.webshop.models import Product

from djadmin_classy_doc.view_introspector import ViewIntrospector


class TestViewIntrospector:
    """Test view introspection functionality."""

    def test_get_registered_views_empty_site(self, admin_site):
        """Test get_registered_views with no registered models."""
        introspector = ViewIntrospector(admin_site)
        views = introspector.get_registered_views()

        assert views == []

    def test_get_registered_views_single_model(self, admin_site):
        """Test basic view discovery for single model."""
        admin_site.register(Product, ModelAdmin)

        introspector = ViewIntrospector(admin_site)
        views = introspector.get_registered_views()

        # Product has default actions (list, add, edit, delete, view)
        # So we expect multiple views
        assert len(views) > 0

        # Check structure of returned data
        for view_info in views:
            assert 'model' in view_info
            assert 'model_admin' in view_info
            assert 'action' in view_info
            assert 'action_type' in view_info
            assert 'view_class' in view_info

    def test_get_registered_views_includes_model(self, admin_site):
        """Test that get_registered_views includes correct model."""
        admin_site.register(Product, ModelAdmin)

        introspector = ViewIntrospector(admin_site)
        views = introspector.get_registered_views()

        # All views should reference Product model
        for view_info in views:
            assert view_info['model'] == Product

    def test_get_registered_views_includes_model_admin(self, admin_site):
        """Test that get_registered_views includes correct ModelAdmin."""
        admin_site.register(Product, ModelAdmin)

        introspector = ViewIntrospector(admin_site)
        views = introspector.get_registered_views()

        # All views should reference a ModelAdmin
        for view_info in views:
            assert isinstance(view_info['model_admin'], ModelAdmin)
            assert view_info['model_admin'].model == Product

    def test_get_registered_views_includes_action(self, admin_site):
        """Test that get_registered_views includes action instances."""
        admin_site.register(Product, ModelAdmin)

        introspector = ViewIntrospector(admin_site)
        views = introspector.get_registered_views()

        # All views should reference an action
        for view_info in views:
            assert view_info['action'] is not None
            assert hasattr(view_info['action'], 'action_type')

    def test_get_registered_views_includes_action_type(self, admin_site):
        """Test that get_registered_views categorizes action types correctly."""
        admin_site.register(Product, ModelAdmin)

        introspector = ViewIntrospector(admin_site)
        views = introspector.get_registered_views()

        # Check that action_type values are valid
        action_types = {v['action_type'] for v in views}
        valid_types = {'general', 'bulk', 'record'}
        assert action_types.issubset(valid_types)

    def test_get_registered_views_includes_view_class(self, admin_site):
        """Test that get_registered_views includes generated view classes."""
        admin_site.register(Product, ModelAdmin)

        introspector = ViewIntrospector(admin_site)
        views = introspector.get_registered_views()

        # All views should have a view_class
        for view_info in views:
            assert view_info['view_class'] is not None
            assert isinstance(view_info['view_class'], type)
            # Views are classes, not instances
            assert not isinstance(view_info['view_class'], view_info['view_class'])

    def test_get_registered_views_view_classes_are_callable(self, admin_site):
        """Test that returned view classes can be called with as_view()."""
        admin_site.register(Product, ModelAdmin)

        introspector = ViewIntrospector(admin_site)
        views = introspector.get_registered_views()

        # View classes should have as_view() method (from CBV)
        for view_info in views:
            assert hasattr(view_info['view_class'], 'as_view')
            # Calling as_view() should work (returns a view function)
            view_func = view_info['view_class'].as_view()
            assert callable(view_func)

    def test_introspector_uses_provided_admin_site(self, admin_site):
        """Test that introspector uses provided admin site."""
        admin_site.register(Product, ModelAdmin)

        introspector = ViewIntrospector(admin_site)

        # Introspector should reference the provided site
        assert introspector.admin_site == admin_site

    def test_introspector_defaults_to_global_site(self):
        """Test that introspector uses global site if none provided."""
        from djadmin import site

        introspector = ViewIntrospector()

        # Should use the global site
        assert introspector.admin_site == site

    def test_get_site_actions_includes_project_dashboard(self, admin_site):
        """Test that site actions include project dashboard."""
        introspector = ViewIntrospector(admin_site)
        views = introspector.get_site_actions()

        # Should have at least project dashboard
        assert len(views) >= 1

        # First should be project dashboard (no app_label)
        project_dash = views[0]
        assert project_dash['model'] is None
        assert project_dash['model_admin'] is None
        assert 'app_label' not in project_dash

    def test_get_site_actions_includes_app_dashboards(self, admin_site):
        """Test that site actions include one dashboard per registered app."""
        admin_site.register(Product, ModelAdmin)

        introspector = ViewIntrospector(admin_site)
        views = introspector.get_site_actions()

        # Should have project dashboard + app dashboards
        app_dashboards = [v for v in views if 'app_label' in v]
        assert len(app_dashboards) == 1  # Only webshop app
        assert app_dashboards[0]['app_label'] == 'webshop'
        assert app_dashboards[0]['model'] is None

    def test_get_site_actions_structure_matches_registered_views(self, admin_site):
        """Site actions should have same dict structure as registered views."""
        admin_site.register(Product, ModelAdmin)
        introspector = ViewIntrospector(admin_site)

        site_views = introspector.get_site_actions()
        assert len(site_views) > 0

        # Check structure matches registered views
        required_keys = {'action', 'action_type', 'view_class', 'model', 'model_admin'}
        for view in site_views:
            assert required_keys.issubset(view.keys())

    def test_get_site_actions_has_valid_action_types(self, admin_site):
        """Site actions should have valid action types."""
        admin_site.register(Product, ModelAdmin)
        introspector = ViewIntrospector(admin_site)

        site_views = introspector.get_site_actions()
        valid_types = {'general', 'bulk', 'record'}

        for view in site_views:
            assert view['action_type'] in valid_types

    def test_get_site_actions_view_classes_are_callable(self, admin_site):
        """Test that site action view classes can be called with as_view()."""
        admin_site.register(Product, ModelAdmin)
        introspector = ViewIntrospector(admin_site)

        site_views = introspector.get_site_actions()

        # Site action view classes should have as_view() method (from CBV)
        for view in site_views:
            assert hasattr(view['view_class'], 'as_view')
            # Calling as_view() should work (returns a view function)
            view_func = view['view_class'].as_view()
            assert callable(view_func)

    def test_introspect_action_returns_construction_info(self, admin_site):
        """Test that introspect_action returns construction info."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        construction_info = introspector.introspect_action(action)

        # Should have expected keys
        assert 'action' in construction_info
        assert 'base_class' in construction_info
        assert 'mixins' in construction_info
        assert 'attributes' in construction_info
        assert 'bound_methods' in construction_info

    def test_introspect_action_captures_plugin_contributions(self, admin_site):
        """Test introspect_action captures plugin mixins."""
        admin_site.register(Product, ModelAdmin)
        model_admin = admin_site._registry[Product][0]
        action = ListAction(Product, model_admin, admin_site)

        introspector = ViewIntrospector(admin_site)
        construction_info = introspector.introspect_action(action)

        # Should have mixins from core plugin
        assert 'mixins' in construction_info
        assert isinstance(construction_info['mixins'], list)

        # Each mixin should have plugin attribution
        for mixin_info in construction_info['mixins']:
            assert 'class' in mixin_info
            assert 'plugin' in mixin_info
            assert 'hook' in mixin_info

    def test_introspect_action_works_for_site_level_actions(self, admin_site):
        """Test that introspect_action works for site-level actions."""
        from djadmin.actions.dashboard import DashboardAction

        action = DashboardAction(admin_site=admin_site)

        introspector = ViewIntrospector(admin_site)
        construction_info = introspector.introspect_action(action)

        # Should work even though model=None
        assert 'mixins' in construction_info
        assert 'attributes' in construction_info
        assert isinstance(construction_info['mixins'], list)
        assert isinstance(construction_info['attributes'], dict)

    def test_get_generic_action_views_returns_default_actions(self, admin_site):
        """Test that get_generic_action_views returns all default action types."""
        introspector = ViewIntrospector(admin_site)
        generic_views = introspector.get_generic_action_views()

        # Should have all default actions
        # (ListAction, AddAction, ViewAction, EditAction, DeleteAction, DeleteBulkAction)
        assert len(generic_views) >= 6

        # Check action names
        action_names = {v['action'].__class__.__name__ for v in generic_views}
        expected_actions = {'ListAction', 'AddAction', 'ViewAction', 'EditAction', 'DeleteAction', 'DeleteBulkAction'}
        assert expected_actions.issubset(action_names)

    def test_get_generic_action_views_structure(self, admin_site):
        """Test that get_generic_action_views returns correct structure."""
        introspector = ViewIntrospector(admin_site)
        generic_views = introspector.get_generic_action_views()

        # Check structure of each view
        required_keys = {'action', 'action_type', 'view_class', 'model', 'model_admin', 'is_generic'}
        for view in generic_views:
            assert required_keys.issubset(view.keys())
            assert view['model'] is None  # Generic views have no model
            assert view['is_generic'] is True

    def test_get_generic_action_views_has_valid_action_types(self, admin_site):
        """Test that generic action views have valid action types."""
        introspector = ViewIntrospector(admin_site)
        generic_views = introspector.get_generic_action_views()

        valid_types = {'general', 'bulk', 'record'}
        for view in generic_views:
            assert view['action_type'] in valid_types

    def test_get_generic_action_views_view_classes_are_callable(self, admin_site):
        """Test that generic action view classes have as_view() method."""
        introspector = ViewIntrospector(admin_site)
        generic_views = introspector.get_generic_action_views()

        for view in generic_views:
            assert hasattr(view['view_class'], 'as_view')
            view_func = view['view_class'].as_view()
            assert callable(view_func)

    def test_get_generic_action_views_uses_temporary_site(self, admin_site):
        """Test that get_generic_action_views doesn't affect main site registry."""
        # Register a model on the main site
        admin_site.register(Product, ModelAdmin)
        initial_registry_size = len(admin_site._registry)

        introspector = ViewIntrospector(admin_site)
        _ = introspector.get_generic_action_views()

        # Main site registry should be unchanged
        assert len(admin_site._registry) == initial_registry_size

    def test_get_generic_action_views_includes_construction_info(self, admin_site):
        """Test that generic views can be introspected for construction info."""
        introspector = ViewIntrospector(admin_site)
        generic_views = introspector.get_generic_action_views()

        # Each view should be introspectable
        for view in generic_views:
            construction_info = introspector.introspect_action(view['action'], view['view_class'])
            assert 'mixins' in construction_info
            assert 'bound_methods' in construction_info
