#!/usr/bin/env python
"""Setup script for djadmin-classy-doc."""

from setuptools import setup

setup()
