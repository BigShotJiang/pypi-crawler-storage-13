"""mkdocstrings handler for djadmin generated views."""

from typing import Any

from .handler import DjadminHandler


def get_handler(
    *,
    theme: str,
    custom_templates: str | None = None,
    mdx: list | None = None,
    mdx_config: dict | None = None,
    handler_config: dict | None = None,
    tool_config: Any = None,
    **kwargs: Any,
) -> DjadminHandler:
    """Create and return a DjadminHandler instance.

    This function is the entry point for mkdocstrings to obtain a handler instance.

    Args:
        theme: The MkDocs theme name.
        custom_templates: Path to custom templates directory.
        mdx: Markdown extensions configuration.
        mdx_config: Markdown extensions configuration options.
        handler_config: Handler-specific configuration.
        tool_config: MkDocs tool configuration.
        **kwargs: Additional keyword arguments.

    Returns:
        A configured DjadminHandler instance.
    """
    return DjadminHandler(
        theme=theme,
        custom_templates=custom_templates,
        mdx=mdx or [],
        mdx_config=mdx_config or {},
    )


__all__ = ['DjadminHandler', 'get_handler']
