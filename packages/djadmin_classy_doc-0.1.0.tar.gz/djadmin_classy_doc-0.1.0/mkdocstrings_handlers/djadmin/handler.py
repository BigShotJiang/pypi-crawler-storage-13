"""DjadminHandler for mkdocstrings - extends ClassyDocHandler for generated views.

This handler supports special `djadmin://` identifiers to document dynamically
generated views created by djadmin's ViewFactory.
"""

from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Any, ClassVar, Mapping

from mkdocstrings import CollectionError
from mkdocstrings_handlers.classydoc.handler import ClassyDocHandler


class DjadminHandler(ClassyDocHandler):
    """Handler for djadmin generated view documentation.

    Extends ClassyDocHandler to support `djadmin://` identifiers for documenting
    dynamically generated views with plugin attribution.

    Identifier formats:
        - djadmin://view:ModelName:action_name - Specific model+action view
        - djadmin://model:ModelName - All views for a model
        - djadmin://action:action_name - Generic action view (model=None)
        - djadmin://site:dashboard - Site-level actions

    Example:
        ```markdown
        ## ProductListView

        ::: djadmin://view:Product:list
            handler: djadmin
        ```
    """

    name: ClassVar[str] = 'djadmin'

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the handler."""
        super().__init__(**kwargs)
        self._introspector = None
        self._classifier = None
        self._ensure_djadmin_autodiscovered()

    def _ensure_djadmin_autodiscovered(self) -> None:
        """Ensure djadmin modules are autodiscovered.

        This imports all djadmin.py modules from installed apps to ensure
        models are registered with the admin site.
        """
        from django.apps import apps
        from django.utils.module_loading import module_has_submodule
        import importlib

        for app_config in apps.get_app_configs():
            # Try to import djadmin module from each app
            if module_has_submodule(app_config.module, 'djadmin'):
                try:
                    importlib.import_module(f'{app_config.name}.djadmin')
                except Exception:
                    pass  # Ignore apps that don't have djadmin or fail to import

    def _get_introspector(self):
        """Get or create ViewIntrospector (lazy loaded)."""
        if self._introspector is None:
            from djadmin_classy_doc.view_introspector import ViewIntrospector

            self._introspector = ViewIntrospector()
        return self._introspector

    def _get_classifier(self):
        """Get or create ClassifierAdapter (lazy loaded)."""
        if self._classifier is None:
            from djadmin_classy_doc.classifier import ClassifierAdapter

            self._classifier = ClassifierAdapter(self._get_introspector())
        return self._classifier

    def get_templates_dir(self, handler: str | None = None) -> Path:
        """Return the path to the handler's templates directory.

        Args:
            handler: The name of the handler (unused).

        Returns:
            The path to the templates directory.
        """
        return Path(__file__).parent / 'templates'

    def collect(self, identifier: str, options: Mapping[str, Any]) -> dict[str, Any]:
        """Collect documentation for a class or djadmin view identifier.

        Args:
            identifier: The identifier - either a fully qualified class name
                or a djadmin:// identifier for generated views.
            options: Configuration options for collection.

        Returns:
            A dictionary containing the class documentation data.

        Raises:
            CollectionError: If the class/view cannot be found or documented.
        """
        if identifier.startswith('djadmin://'):
            return self._collect_djadmin_view(identifier, options)

        # Delegate to parent for regular class identifiers
        return super().collect(identifier, options)

    def _collect_djadmin_view(self, identifier: str, options: Mapping[str, Any]) -> dict[str, Any]:
        """Collect documentation for a djadmin generated view.

        Args:
            identifier: The djadmin:// identifier.
            options: Configuration options.

        Returns:
            A dictionary containing the view documentation data.

        Raises:
            CollectionError: If the view cannot be found.
        """
        parsed = self._parse_djadmin_identifier(identifier)

        if parsed['type'] == 'view':
            return self._collect_model_action_view(parsed['model'], parsed['action'], options)
        elif parsed['type'] == 'model':
            return self._collect_model_views(parsed['model'], options)
        elif parsed['type'] == 'action':
            return self._collect_generic_action_view(parsed['action'], options)
        elif parsed['type'] == 'site':
            return self._collect_site_view(parsed['action'], options)
        else:
            raise CollectionError(f"Unknown djadmin identifier type: {parsed['type']}")

    def _parse_djadmin_identifier(self, identifier: str) -> dict[str, Any]:
        """Parse a djadmin:// identifier.

        Args:
            identifier: The djadmin:// identifier string.

        Returns:
            Dict with 'type' and relevant keys (model, action).

        Raises:
            CollectionError: If the identifier format is invalid.
        """
        # Remove djadmin:// prefix
        path = identifier[10:]

        if not path:
            raise CollectionError(f'Invalid djadmin identifier: {identifier}')

        parts = path.split(':')

        if len(parts) < 2:
            raise CollectionError(f"Invalid djadmin identifier format: {identifier}. Expected 'type:value'")

        id_type = parts[0]

        if id_type == 'view':
            # djadmin://view:ModelName:action_name
            if len(parts) != 3:
                raise CollectionError(
                    f"Invalid view identifier: {identifier}. Expected 'djadmin://view:ModelName:action_name'"
                )
            return {'type': 'view', 'model': parts[1], 'action': parts[2]}

        elif id_type == 'model':
            # djadmin://model:ModelName
            return {'type': 'model', 'model': parts[1]}

        elif id_type == 'action':
            # djadmin://action:action_name
            return {'type': 'action', 'action': parts[1]}

        elif id_type == 'site':
            # djadmin://site:dashboard
            return {'type': 'site', 'action': parts[1]}

        else:
            raise CollectionError(f"Unknown identifier type '{id_type}' in: {identifier}")

    def _collect_model_action_view(self, model_name: str, action_name: str, options: Mapping[str, Any]) -> dict[str, Any]:
        """Collect documentation for a specific model+action view.

        Args:
            model_name: The model name (e.g., 'Product').
            action_name: The action name (e.g., 'list', 'edit').
            options: Configuration options.

        Returns:
            Documentation dictionary.

        Raises:
            CollectionError: If the view cannot be found.
        """
        introspector = self._get_introspector()

        # Find the view in registered views
        for view_info in introspector.get_registered_views():
            model = view_info['model']
            action = view_info['action']

            if model.__name__ == model_name:
                # Match action by name (url_name or class name)
                action_class_name = action.__class__.__name__.lower()
                action_url_name = getattr(action, 'url_name', '').lower()

                if action_name.lower() in (action_class_name, action_url_name, action_class_name.replace('action', '')):
                    return self._classify_and_postprocess(view_info['view_class'], action, options)

        raise CollectionError(f"Could not find view for model '{model_name}' with action '{action_name}'")

    def _collect_model_views(self, model_name: str, options: Mapping[str, Any]) -> dict[str, Any]:
        """Collect documentation for all views of a model.

        Args:
            model_name: The model name.
            options: Configuration options.

        Returns:
            Documentation dictionary with all views for the model.

        Raises:
            CollectionError: If the model cannot be found.
        """
        introspector = self._get_introspector()

        views = []
        for view_info in introspector.get_registered_views():
            if view_info['model'].__name__ == model_name:
                view_data = self._classify_and_postprocess(view_info['view_class'], view_info['action'], options)
                views.append(view_data)

        if not views:
            raise CollectionError(f"Could not find any views for model '{model_name}'")

        # Return first view for now - could be extended to return multiple
        # For multiple views, would need different template handling
        return views[0]

    def _collect_generic_action_view(self, action_name: str, options: Mapping[str, Any]) -> dict[str, Any]:
        """Collect documentation for a generic action view (model=None).

        Args:
            action_name: The action name (e.g., 'list', 'edit').
            options: Configuration options.

        Returns:
            Documentation dictionary.

        Raises:
            CollectionError: If the action cannot be found.
        """
        introspector = self._get_introspector()

        for view_info in introspector.get_generic_action_views():
            action = view_info['action']
            action_class_name = action.__class__.__name__.lower()
            action_url_name = getattr(action, 'url_name', '').lower()

            if action_name.lower() in (action_class_name, action_url_name, action_class_name.replace('action', '')):
                return self._classify_and_postprocess(view_info['view_class'], action, options)

        raise CollectionError(f"Could not find generic action view for '{action_name}'")

    def _collect_site_view(self, action_name: str, options: Mapping[str, Any]) -> dict[str, Any]:
        """Collect documentation for a site-level view.

        Args:
            action_name: The action name (e.g., 'dashboard').
            options: Configuration options.

        Returns:
            Documentation dictionary.

        Raises:
            CollectionError: If the action cannot be found.
        """
        introspector = self._get_introspector()

        for view_info in introspector.get_site_actions():
            action = view_info['action']
            action_class_name = action.__class__.__name__.lower()

            if action_name.lower() in (action_class_name, action_class_name.replace('action', '')):
                return self._classify_and_postprocess(view_info['view_class'], action, options)

        raise CollectionError(f"Could not find site action '{action_name}'")

    def _classify_and_postprocess(
        self, view_class: type, action: Any, options: Mapping[str, Any]
    ) -> dict[str, Any]:
        """Classify a view and post-process for rendering.

        Args:
            view_class: The generated view class.
            action: The action instance.
            options: Configuration options.

        Returns:
            Post-processed documentation dictionary.
        """
        classifier = self._get_classifier()

        # Get classified view data
        klass = classifier.classify_djadmin_view(view_class, action)

        # Add standard fields expected by templates
        klass['name'] = view_class.__name__
        klass['module'] = view_class.__module__
        klass['docstring'] = view_class.__doc__ or ''

        # Post-process attributes like parent handler does
        for name, lst in klass['attributes'].items():
            for i, definition in enumerate(lst):
                a = definition.get('defining_class')
                if a and not isinstance(a, tuple):
                    klass['attributes'][name][i]['defining_class'] = (a.__module__, a.__name__)

                if isinstance(definition.get('object'), list):
                    try:
                        s = '[{0}]'.format(', '.join([c.__name__ for c in definition['object']]))
                    except AttributeError:
                        pass
                    else:
                        klass['attributes'][name][i]['default'] = s

        # Sort attributes and methods
        sorted_attributes = sorted(klass['attributes'].items(), key=lambda t: t[0])
        klass['attributes'] = OrderedDict(sorted_attributes)

        sorted_methods = sorted(klass['methods'].items(), key=lambda t: t[0])
        klass['methods'] = OrderedDict(sorted_methods)

        # Add options to structure
        klass['_options'] = dict(options)

        return klass

    def render(
        self,
        data: dict[str, Any],
        options: Mapping[str, Any],
        *,
        locale: str | None = None,
    ) -> str:
        """Render the collected data using Jinja templates.

        Args:
            data: The collected class documentation data.
            options: Configuration options for rendering.
            locale: Locale for translations (not used).

        Returns:
            Rendered HTML string.
        """
        # Merge default options with provided options
        merged_options = {
            'show_source': True,
            'show_mro': True,
            'show_attributes': True,
            'show_methods': True,
            'show_fields': True,
            'show_plugin_attribution': True,  # djadmin-specific
            'show_construction_info': True,  # djadmin-specific
            'heading_level': 2,
        }
        merged_options.update(options)

        template = self.env.get_template('class.html.jinja')
        return template.render(
            class_data=data,
            config=merged_options,
            heading_level=merged_options['heading_level'],
        )
