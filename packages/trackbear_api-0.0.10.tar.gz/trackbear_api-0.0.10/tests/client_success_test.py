"""
Happy path tests for all client methods.

All tests are run through the TrackBearClient which is the public API for the library.

Tests in this collection focus on the error handling and successful model building.
There is no focus on the underlying APIClient behavior as that is tested in the
trackbearclient_test.py collection.
"""

from __future__ import annotations

import copy
import dataclasses
import json
from typing import Any
from typing import TypeVar

import pytest
import responses
import responses.matchers

from trackbear_api import TrackBearClient
from trackbear_api import enums
from trackbear_api import models

from . import test_parameters

ModelType = TypeVar("ModelType")


def get_client_attribute(client: TrackBearClient, provider_method: str) -> Any:
    """Return the attribute given through dot-notation of the client."""
    method_to_call = getattr(client, provider_method.split(".")[0])
    for attribute in provider_method.split(".")[1:]:
        method_to_call = getattr(method_to_call, attribute)

    return method_to_call


@pytest.mark.parametrize(
    "provider_method,kwargs,url,api_response,query_string,model_type",
    (
        (
            "project.list",
            {},
            "https://trackbear.app/api/v1/project",
            test_parameters.PROJECT_RESPONSE,
            "",
            models.Project,
        ),
        (
            "goal.list",
            {},
            "https://trackbear.app/api/v1/goal",
            test_parameters.GOAL_RESPONSE_THRESHOLD,
            "",
            models.Goal,
        ),
        (
            "tag.list",
            {},
            "https://trackbear.app/api/v1/tag",
            test_parameters.TAG_RESPONSE,
            "",
            models.Tag,
        ),
        (
            "stat.list",
            {"start_date": "2024-01-01", "end_date": "2025-01-01"},
            "https://trackbear.app/api/v1/stats/days",
            test_parameters.STAT_RESPONSE,
            "startDate=2024-01-01&endDate=2025-01-01",
            models.Stat,
        ),
        (
            "tally.list",
            {"works": [123, 456], "tags": [987, 654], "measure": enums.Measure.SCENE},
            "https://trackbear.app/api/v1/tally",
            test_parameters.TALLY_RESPONSE,
            "works[]=123&works[]=456&tags[]=987&tags[]=654&measure=scene",
            models.Tally,
        ),
        (
            "tally.list",
            {"measure": "scene", "start_date": "2025-01-01", "end_date": "2025-12-31"},
            "https://trackbear.app/api/v1/tally",
            test_parameters.TALLY_RESPONSE,
            "measure=scene&startDate=2025-01-01&endDate=2025-12-31",
            models.Tally,
        ),
        (
            "leaderboard.list",
            {},
            "https://trackbear.app/api/v1/leaderboard",
            test_parameters.LEADERBOARD_EXTENDED_RESPONSE,
            "",
            models.LeaderboardExtended,
        ),
        (
            "leaderboard.list_participants",
            {"board_uuid": "uuid1234"},
            "https://trackbear.app/api/v1/leaderboard/uuid1234/participants",
            test_parameters.LEADERBOARD_PARTICIPANT_RESPONSE,
            "",
            models.Participant,
        ),
        (
            "leaderboard.teams.list",
            {"board_uuid": "uuid1234"},
            "https://trackbear.app/api/v1/leaderboard/uuid1234/teams",
            test_parameters.TEAM_RESPONSE,
            "",
            models.Team,
        ),
        (
            "leaderboard.members.list",
            {"board_uuid": "uuid1234"},
            "https://trackbear.app/api/v1/leaderboard/uuid1234/members",
            test_parameters.MEMBER_RESPONSE,
            "",
            models.Member,
        ),
    ),
)
@responses.activate(assert_all_requests_are_fired=True)
def test_client_list_success(
    client: TrackBearClient,
    provider_method: str,
    kwargs: dict[str, Any],
    api_response: dict[str, Any],
    query_string: str,
    url: str,
    model_type: type[ModelType],
) -> None:
    """Assert the list method has success and that the models are correct."""
    mock_data = [copy.deepcopy(api_response)] * 3
    mock_body = {"success": True, "data": mock_data}
    method_to_call = get_client_attribute(client, provider_method)

    query_matcher = responses.matchers.query_string_matcher(query_string)

    responses.add(
        method="GET",
        status=200,
        url=url,
        body=json.dumps(mock_body),
        match=[query_matcher],
    )

    results = method_to_call(**kwargs)

    assert len(results) == len(mock_data)

    for result in results:
        assert isinstance(result, model_type)
        assert dataclasses.is_dataclass(result)
        assert not isinstance(result, type)
        assert dataclasses.asdict(result) == test_parameters.keys_to_snake_case(api_response)


@pytest.mark.parametrize(
    "provider_method,kwargs,url,api_response,model_type",
    (
        (
            "project.get",
            {"project_id": 123},
            "https://trackbear.app/api/v1/project/123",
            test_parameters.PROJECT_RESPONSE,
            models.Project,
        ),
        (
            "goal.get",
            {"goal_id": 123},
            "https://trackbear.app/api/v1/goal/123",
            test_parameters.GOAL_RESPONSE_HABIT_THRESHOLD,
            models.Goal,
        ),
        (
            "tag.get",
            {"tag_id": 123},
            "https://trackbear.app/api/v1/tag/123",
            test_parameters.TAG_RESPONSE,
            models.Tag,
        ),
        (
            "tally.get",
            {"tally_id": 123},
            "https://trackbear.app/api/v1/tally/123",
            test_parameters.TALLY_RESPONSE,
            models.Tally,
        ),
        (
            "leaderboard.get",
            {"board_uuid": "uuid1234"},
            "https://trackbear.app/api/v1/leaderboard/uuid1234",
            test_parameters.LEADERBOARD_RESPONSE,
            models.Leaderboard,
        ),
        (
            "leaderboard.get_by_join_code",
            {"join_code": "code1234"},
            "https://trackbear.app/api/v1/leaderboard/joincode/code1234",
            test_parameters.LEADERBOARD_RESPONSE,
            models.Leaderboard,
        ),
        (
            "leaderboard.teams.get",
            {"board_uuid": "uuid1234", "team_id": 123},
            "https://trackbear.app/api/v1/leaderboard/uuid1234/teams/123",
            test_parameters.TEAM_RESPONSE,
            models.Team,
        ),
    ),
)
@responses.activate(assert_all_requests_are_fired=True)
def test_client_get_success(
    client: TrackBearClient,
    provider_method: str,
    kwargs: dict[str, Any],
    url: str,
    api_response: dict[str, Any],
    model_type: type[ModelType],
) -> None:
    """Assert the Project model is built correctly."""
    mock_data = copy.deepcopy(api_response)
    mock_body = {"success": True, "data": mock_data}
    method_to_call = get_client_attribute(client, provider_method)

    responses.add(
        method="GET",
        status=200,
        url=url,
        body=json.dumps(mock_body),
    )

    result = method_to_call(**kwargs)

    assert isinstance(result, model_type)
    assert dataclasses.is_dataclass(result)
    assert not isinstance(result, type)
    assert dataclasses.asdict(result) == test_parameters.keys_to_snake_case(api_response)


@pytest.mark.parametrize(
    "provider_method,kwargs,expected_payload,url,api_response,model_type",
    (
        (
            "project.save",
            test_parameters.PROJECT_SAVE_KWARGS,
            test_parameters.PROJECT_SAVE_PAYLOAD,
            "POST https://trackbear.app/api/v1/project",
            test_parameters.PROJECTSTUB_RESPONSE,
            models.ProjectStub,
        ),
        (
            "project.save",
            # replace enum with string while adding project_id
            test_parameters.PROJECT_SAVE_KWARGS | {"phase": "drafting", "project_id": 123},
            test_parameters.PROJECT_SAVE_PAYLOAD,
            "PATCH https://trackbear.app/api/v1/project/123",
            test_parameters.PROJECTSTUB_RESPONSE,
            models.ProjectStub,
        ),
        (
            "goal.save_target",
            test_parameters.GOAL_SAVE_TARGET_KWARGS,
            test_parameters.GOAL_SAVE_TARGET_PAYLOAD,
            "POST https://trackbear.app/api/v1/goal",
            test_parameters.GOAL_RESPONSE_THRESHOLD,
            models.Goal,
        ),
        (
            "goal.save_habit",
            test_parameters.GOAL_SAVE_HABIT_KWARGS,
            test_parameters.GOAL_SAVE_HABIT_PAYLOAD,
            "POST https://trackbear.app/api/v1/goal",
            test_parameters.GOAL_RESPONSE_HABIT,
            models.Goal,
        ),
        (
            "goal.save_habit",
            test_parameters.GOAL_SAVE_HABIT_TARGET_KWARGS,
            test_parameters.GOAL_SAVE_HABIT_TARGET_PAYLOAD,
            "POST https://trackbear.app/api/v1/goal",
            test_parameters.GOAL_RESPONSE_HABIT_THRESHOLD,
            models.Goal,
        ),
        (
            # replace enum with string while adding project_id
            "goal.save_target",
            test_parameters.GOAL_SAVE_TARGET_KWARGS | {"measure": "word", "goal_id": 123},
            test_parameters.GOAL_SAVE_TARGET_PAYLOAD,
            "PATCH https://trackbear.app/api/v1/goal/123",
            test_parameters.GOAL_RESPONSE_THRESHOLD,
            models.Goal,
        ),
        (
            # replace enum with string while adding project_id
            "goal.save_habit",
            test_parameters.GOAL_SAVE_HABIT_TARGET_KWARGS
            | {"unit": "day", "measure": "chapter", "goal_id": 123},
            test_parameters.GOAL_SAVE_HABIT_TARGET_PAYLOAD,
            "PATCH https://trackbear.app/api/v1/goal/123",
            test_parameters.GOAL_RESPONSE_HABIT_THRESHOLD,
            models.Goal,
        ),
        (
            "tag.save",
            test_parameters.TAG_SAVE_KWARGS,
            test_parameters.TAG_SAVE_PAYLOAD,
            "POST https://trackbear.app/api/v1/tag",
            test_parameters.TAG_RESPONSE,
            models.Tag,
        ),
        (
            "tag.save",
            # replace enum with string while adding tag_id
            test_parameters.TAG_SAVE_KWARGS | {"color": "blue", "tag_id": 123},
            test_parameters.TAG_SAVE_PAYLOAD,
            "PATCH https://trackbear.app/api/v1/tag/123",
            test_parameters.TAG_RESPONSE,
            models.Tag,
        ),
        (
            "tally.save",
            test_parameters.TALLY_SAVE_KWARGS,
            test_parameters.TALLY_SAVE_PAYLOAD,
            "POST https://trackbear.app/api/v1/tally",
            test_parameters.TALLY_RESPONSE,
            models.Tally,
        ),
        (
            "tally.save",
            # replace enum with string while adding tally_id
            test_parameters.TALLY_SAVE_KWARGS | {"measure": "scene", "tally_id": 123},
            test_parameters.TALLY_SAVE_PAYLOAD,
            "PATCH https://trackbear.app/api/v1/tally/123",
            test_parameters.TALLY_RESPONSE,
            models.Tally,
        ),
        (
            "leaderboard.save",
            test_parameters.LEADERBOARD_SAVE_SIMPLE_KWARGS,
            test_parameters.LEADERBOARD_SAVE_SIMPLE_PAYLOAD,
            "POST https://trackbear.app/api/v1/leaderboard",
            test_parameters.LEADERBOARD_RESPONSE,
            models.Leaderboard,
        ),
        (
            "leaderboard.save",
            test_parameters.LEADERBOARD_SAVE_COMPLEX_KWARGS,
            test_parameters.LEADERBOARD_SAVE_COMPLEX_PAYLOAD,
            "POST https://trackbear.app/api/v1/leaderboard",
            test_parameters.LEADERBOARD_RESPONSE,
            models.Leaderboard,
        ),
        (
            "leaderboard.save",
            test_parameters.LEADERBOARD_SAVE_COMPLEX_KWARGS | {"board_uuid": "uuid123"},
            test_parameters.LEADERBOARD_SAVE_COMPLEX_PAYLOAD,
            "PATCH https://trackbear.app/api/v1/leaderboard/uuid123",
            test_parameters.LEADERBOARD_RESPONSE,
            models.Leaderboard,
        ),
        (
            "leaderboard.save_star",
            {"board_uuid": "uuid123", "starred": True},
            {"starred": True},
            "PATCH https://trackbear.app/api/v1/leaderboard/uuid123/star",
            test_parameters.STARRED_RESPONSE,
            models.Starred,
        ),
        (
            "leaderboard.teams.save",
            test_parameters.TEAM_SAVE_KWARGS,
            test_parameters.TEAM_SAVE_PAYLOAD,
            "POST https://trackbear.app/api/v1/leaderboard/uuid1234/teams",
            test_parameters.TEAM_RESPONSE,
            models.Team,
        ),
        (
            "leaderboard.teams.save",
            test_parameters.TEAM_SAVE_KWARGS | {"team_id": "123"},
            test_parameters.TEAM_SAVE_PAYLOAD,
            "PATCH https://trackbear.app/api/v1/leaderboard/uuid1234/teams/123",
            test_parameters.TEAM_RESPONSE,
            models.Team,
        ),
        (
            "leaderboard.members.save_owner",
            {"board_uuid": "uuid1234", "member_id": 123, "is_owner": True},
            {"isOwner": True},
            "PATCH https://trackbear.app/api/v1/leaderboard/uuid1234/members/123",
            test_parameters.MEMBER_RESPONSE,
            models.Member,
        ),
    ),
)
@responses.activate(assert_all_requests_are_fired=True)
def test_client_save_success(
    client: TrackBearClient,
    provider_method: str,
    kwargs: dict[str, Any],
    expected_payload: dict[str, Any],
    url: str,
    api_response: dict[str, Any],
    model_type: type[ModelType],
) -> None:
    """
    Assert a new create returns the expected model while asserting
    the payload is generated for the request correctly.

    NOTE: The response model is not reflective of the kwarg inputs.

    Accepts a Measure enum in the parameters
    """
    body_match = responses.matchers.body_matcher(json.dumps(expected_payload))
    method_to_call = get_client_attribute(client, provider_method)
    method, url = url.split(" ", 1)

    responses.add(
        method=method,
        url=url,
        status=200,
        match=[body_match],
        body=json.dumps({"success": True, "data": api_response}),
    )

    result = method_to_call(**kwargs)

    assert isinstance(result, model_type)
    assert dataclasses.is_dataclass(result)
    assert not isinstance(result, type)
    assert dataclasses.asdict(result) == test_parameters.keys_to_snake_case(api_response)


@pytest.mark.parametrize(
    "provider_method,kwargs,url,api_response,model_type",
    (
        (
            "project.delete",
            {"project_id": 123},
            "https://trackbear.app/api/v1/project/123",
            test_parameters.PROJECTSTUB_RESPONSE,
            models.ProjectStub,
        ),
        (
            "goal.delete",
            {"goal_id": 123},
            "https://trackbear.app/api/v1/goal/123",
            test_parameters.GOAL_RESPONSE_HABIT,
            models.Goal,
        ),
        (
            "tag.delete",
            {"tag_id": 123},
            "https://trackbear.app/api/v1/tag/123",
            test_parameters.TAG_RESPONSE,
            models.Tag,
        ),
        (
            "tally.delete",
            {"tally_id": 123},
            "https://trackbear.app/api/v1/tally/123",
            test_parameters.TALLY_RESPONSE,
            models.Tally,
        ),
        (
            "leaderboard.delete",
            {"board_uuid": "uuid1234"},
            "https://trackbear.app/api/v1/leaderboard/uuid1234",
            test_parameters.LEADERBOARD_RESPONSE,
            models.Leaderboard,
        ),
        (
            "leaderboard.teams.delete",
            {"board_uuid": "uuid1234", "team_id": 123},
            "https://trackbear.app/api/v1/leaderboard/uuid1234/teams/123",
            test_parameters.TEAM_RESPONSE,
            models.Team,
        ),
        (
            "leaderboard.members.delete",
            {"board_uuid": "uuid1234", "member_id": 123},
            "https://trackbear.app/api/v1/leaderboard/uuid1234/members/123",
            test_parameters.MEMBER_RESPONSE,
            models.Member,
        ),
    ),
)
@responses.activate(assert_all_requests_are_fired=True)
def test_client_delete_success(
    client: TrackBearClient,
    provider_method: str,
    kwargs: dict[str, Any],
    url: str,
    api_response: dict[str, Any],
    model_type: type[ModelType],
) -> None:
    """Assert a delete request returns the expected model."""
    method_to_call = get_client_attribute(client, provider_method)
    body = json.dumps({"success": True, "data": api_response})
    responses.add(method="DELETE", url=url, status=200, body=body)

    result = method_to_call(**kwargs)

    assert isinstance(result, model_type)
    assert dataclasses.is_dataclass(result)
    assert not isinstance(result, type)
    assert dataclasses.asdict(result) == test_parameters.keys_to_snake_case(api_response)
