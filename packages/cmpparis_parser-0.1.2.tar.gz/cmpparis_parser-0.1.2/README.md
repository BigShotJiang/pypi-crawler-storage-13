# CMP Paris Parser (Light)

Une bibliothèque légère et optimisée pour le parsing de documents BOD (Business Object Documents) Infor M3.

Cette version est une extraction de la librairie principale `cmpparis`, conçue pour être utilisée dans des environnements contraints comme **AWS Lambda**.

## Fonctionnalités

*   **Parsing XML vers CSV** : Transforme les flux XML complexes en structures plates.
*   **Configuration Flexible** : Utilise des fichiers YAML/JSON pour définir les mappings XPath.
*   **Transformers** : +40 fonctions de transformation de données (dates, nombres, chaînes).
*   **Zéro Dépendance Lourde** : Ne dépend que de `pyyaml`. Pas de pandas, boto3, ou drivers DB.

## Installation

```bash
pip install cmpparis-parser
```

## Utilisation Rapide

```python
from cmpparis_parser import BODParser, BODConfigLoader

# 1. Charger la configuration
config = BODConfigLoader.from_yaml("config.yaml")

# 2. Parser le contenu XML
parser = BODParser()
csv_output = parser.parse_and_convert(xml_content, config)

# 3. Utiliser le CSV
print(csv_output)
```

## Documentation

Documentation complète disponible sur : [http://cmp-docs-internal.s3-website.eu-west-3.amazonaws.com/parser](http://cmp-docs-internal.s3-website.eu-west-3.amazonaws.com/parser)
