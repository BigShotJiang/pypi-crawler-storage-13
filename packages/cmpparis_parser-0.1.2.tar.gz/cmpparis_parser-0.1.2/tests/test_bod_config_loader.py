import unittest
from unittest.mock import MagicMock
import json
import yaml
from cmpparis_parser.bod_config_loader import BODConfigLoader
from cmpparis_parser.bod_config import BODConfig

class TestBODConfigLoader(unittest.TestCase):

    def test_from_dict(self):
        config_dict = {
            "header_xpath": "header",
            "lines_xpath": "lines",
            "header_mapping": {"h1": "path1"},
            "line_mapping": {"l1": "path2"},
            "header_transformers": {"h1": "uppercase"}
        }
        config = BODConfigLoader.from_dict(config_dict)
        self.assertIsInstance(config, BODConfig)
        self.assertEqual(config.header_xpath, "header")
        self.assertIsNotNone(config.header_transformers)
        # Check if transformer name was resolved to function
        self.assertTrue(callable(config.header_transformers["h1"]))

    def test_from_string_yaml(self):
        yaml_content = """
        header_xpath: header
        lines_xpath: lines
        header_mapping:
            h1: path1
        line_mapping:
            l1: path2
        """
        config = BODConfigLoader.from_string(yaml_content, format='yaml')
        self.assertIsInstance(config, BODConfig)
        self.assertEqual(config.header_xpath, "header")

    def test_from_string_json(self):
        json_content = json.dumps({
            "header_xpath": "header",
            "lines_xpath": "lines",
            "header_mapping": {"h1": "path1"},
            "line_mapping": {"l1": "path2"}
        })
        config = BODConfigLoader.from_string(json_content, format='json')
        self.assertIsInstance(config, BODConfig)
        self.assertEqual(config.header_xpath, "header")

    def test_from_s3(self):
        # Mock S3 client
        mock_s3 = MagicMock()
        mock_response = {
            'Body': MagicMock()
        }
        mock_response['Body'].read.return_value = b"""
        header_xpath: header
        lines_xpath: lines
        header_mapping:
            h1: path1
        line_mapping:
            l1: path2
        """
        mock_s3.get_object.return_value = mock_response
        
        config = BODConfigLoader.from_s3("bucket", "config.yaml", mock_s3)
        
        self.assertIsInstance(config, BODConfig)
        mock_s3.get_object.assert_called_with(Bucket="bucket", Key="config.yaml")

    def test_validate_config(self):
        valid_config = {
            "header_xpath": "header",
            "lines_xpath": "lines",
            "header_mapping": {},
            "line_mapping": {}
        }
        self.assertTrue(BODConfigLoader.validate_config(valid_config))
        
        invalid_config = {"header_xpath": "header"}
        with self.assertRaises(ValueError):
            BODConfigLoader.validate_config(invalid_config)

if __name__ == '__main__':
    unittest.main()
