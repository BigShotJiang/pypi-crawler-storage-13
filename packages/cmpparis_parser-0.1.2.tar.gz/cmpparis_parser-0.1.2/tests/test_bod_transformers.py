import unittest
from cmpparis_parser.bod_transformers import (
    date_format, datetime_format, uppercase, lowercase, strip_whitespace,
    boolean_to_yes_no, boolean_to_01, float_format_2, integer_format,
    remove_currency_symbol, remove_special_chars, truncate, pad_left,
    clean_text, default_if_empty, extract_digits
)

class TestBODTransformers(unittest.TestCase):

    def test_date_format(self):
        self.assertEqual(date_format("2025-09-09T12:00:00Z"), "2025-09-09")
        self.assertEqual(date_format("2025-09-09"), "2025-09-09")
        self.assertEqual(date_format(""), "")
        self.assertEqual(date_format(None), "")

    def test_datetime_format(self):
        self.assertEqual(datetime_format("2025-09-09T09:33:09.770Z"), "2025-09-09 09:33:09")
        self.assertEqual(datetime_format("invalid"), "invalid")
        self.assertEqual(datetime_format(""), "")

    def test_uppercase(self):
        self.assertEqual(uppercase("hello"), "HELLO")
        self.assertEqual(uppercase(""), "")
        self.assertEqual(uppercase(None), "")

    def test_lowercase(self):
        self.assertEqual(lowercase("HELLO"), "hello")
        self.assertEqual(lowercase(""), "")

    def test_strip_whitespace(self):
        self.assertEqual(strip_whitespace("  hello  "), "hello")
        self.assertEqual(strip_whitespace(""), "")

    def test_boolean_to_yes_no(self):
        self.assertEqual(boolean_to_yes_no("true"), "Yes")
        self.assertEqual(boolean_to_yes_no("True"), "Yes")
        self.assertEqual(boolean_to_yes_no("1"), "Yes")
        self.assertEqual(boolean_to_yes_no("false"), "No")
        self.assertEqual(boolean_to_yes_no("0"), "No")
        self.assertEqual(boolean_to_yes_no(""), "")

    def test_boolean_to_01(self):
        self.assertEqual(boolean_to_01("true"), "1")
        self.assertEqual(boolean_to_01("false"), "0")
        self.assertEqual(boolean_to_01(""), "0")

    def test_float_format_2(self):
        self.assertEqual(float_format_2("123.456"), "123.46")
        self.assertEqual(float_format_2("123"), "123.00")
        self.assertEqual(float_format_2("abc"), "abc")

    def test_integer_format(self):
        self.assertEqual(integer_format("123.456"), "123")
        self.assertEqual(integer_format("123"), "123")
        self.assertEqual(integer_format("abc"), "abc")

    def test_remove_currency_symbol(self):
        self.assertEqual(remove_currency_symbol("$123.45"), "123.45")
        self.assertEqual(remove_currency_symbol("123.45 €"), "123.45")

    def test_remove_special_chars(self):
        self.assertEqual(remove_special_chars("Hello@World!"), "HelloWorld")
        self.assertEqual(remove_special_chars("123-456"), "123456")

    def test_truncate(self):
        self.assertEqual(truncate("Hello World", 5), "Hello")
        self.assertEqual(truncate("Hi", 5), "Hi")

    def test_pad_left(self):
        self.assertEqual(pad_left("123", 5, "0"), "00123")
        self.assertEqual(pad_left("123456", 5, "0"), "123456")

    def test_clean_text(self):
        self.assertEqual(clean_text("  Hello   World  "), "Hello World")
        self.assertEqual(clean_text("Line\nBreak"), "Line Break")

    def test_default_if_empty(self):
        self.assertEqual(default_if_empty("", "N/A"), "N/A")
        self.assertEqual(default_if_empty("Value", "N/A"), "Value")

    def test_extract_digits(self):
        self.assertEqual(extract_digits("abc123def456"), "123456")
        self.assertEqual(extract_digits("no digits"), "")

if __name__ == '__main__':
    unittest.main()
