import unittest
import xml.etree.ElementTree as ET
from cmpparis_parser.bod_parser import BODParser
from cmpparis_parser.bod_config import BODConfig

class TestBODParser(unittest.TestCase):

    def setUp(self):
        self.parser = BODParser()
        self.xml_content = """
        <ns:PurchaseOrder xmlns:ns="http://schema.infor.com/InforOAGIS/2">
            <ns:PurchaseOrderHeader>
                <ns:DocumentID>
                    <ns:ID>PO12345</ns:ID>
                </ns:DocumentID>
                <ns:Status>
                    <ns:Code>Open</ns:Code>
                </ns:Status>
                <ns:PurchaseOrderLine>
                    <ns:LineNumber>1</ns:LineNumber>
                    <ns:Item>
                        <ns:ItemID>
                            <ns:ID>ITEM001</ns:ID>
                        </ns:ItemID>
                    </ns:Item>
                    <ns:Quantity unitCode="EA">10</ns:Quantity>
                </ns:PurchaseOrderLine>
                <ns:PurchaseOrderLine>
                    <ns:LineNumber>2</ns:LineNumber>
                    <ns:Item>
                        <ns:ItemID>
                            <ns:ID>ITEM002</ns:ID>
                        </ns:ItemID>
                    </ns:Item>
                    <ns:Quantity unitCode="KG">5</ns:Quantity>
                </ns:PurchaseOrderLine>
            </ns:PurchaseOrderHeader>
        </ns:PurchaseOrder>
        """
        self.root = self.parser.parse_xml_string(self.xml_content)

    def test_extract_field(self):
        # Test extraction with namespace
        header = self.root.find(".//ns:PurchaseOrderHeader", self.parser.ns)
        po_id = self.parser.extract_field(header, ".//ns:DocumentID/ns:ID")
        self.assertEqual(po_id, "PO12345")
        
        # Test missing field default
        missing = self.parser.extract_field(header, ".//ns:MissingField", default="N/A")
        self.assertEqual(missing, "N/A")

    def test_extract_attribute(self):
        line = self.root.find(".//ns:PurchaseOrderLine", self.parser.ns)
        unit = self.parser.extract_attribute(line, ".//ns:Quantity", "unitCode")
        self.assertEqual(unit, "EA")
        
        # Test missing attribute
        missing = self.parser.extract_attribute(line, ".//ns:Quantity", "missingAttr", "N/A")
        self.assertEqual(missing, "N/A")

    def test_flatten_element(self):
        header = self.root.find(".//ns:PurchaseOrderHeader", self.parser.ns)
        mapping = {
            "order_id": ".//ns:DocumentID/ns:ID",
            "status": ".//ns:Status/ns:Code"
        }
        result = self.parser.flatten_element(header, mapping)
        self.assertEqual(result, {"order_id": "PO12345", "status": "Open"})

    def test_parse_header_lines_structure(self):
        config = BODConfig(
            header_xpath=".//ns:PurchaseOrderHeader",
            lines_xpath=".//ns:PurchaseOrderLine",
            header_mapping={"order_id": ".//ns:DocumentID/ns:ID"},
            line_mapping={
                "line_num": ".//ns:LineNumber",
                "item_id": ".//ns:Item/ns:ItemID/ns:ID"
            },
            flatten_mode="duplicate_header"
        )
        
        results = self.parser.parse_header_lines_structure(
            self.root,
            config.header_xpath,
            config.lines_xpath,
            config.header_mapping,
            config.line_mapping,
            flatten_mode=config.flatten_mode
        )
        
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]["order_id"], "PO12345")
        self.assertEqual(results[0]["line_num"], "1")
        self.assertEqual(results[0]["item_id"], "ITEM001")
        
        self.assertEqual(results[1]["order_id"], "PO12345")
        self.assertEqual(results[1]["line_num"], "2")
        self.assertEqual(results[1]["item_id"], "ITEM002")

    def test_to_csv(self):
        data = [
            {"col1": "val1", "col2": "val2"},
            {"col1": "val3", "col2": "val4"}
        ]
        csv_output = self.parser.to_csv(data, fieldnames=["col1", "col2"])
        expected = "col1;col2\r\nval1;val2\r\nval3;val4\r\n"
        self.assertEqual(csv_output.replace("\r\n", "\n"), expected.replace("\r\n", "\n"))

if __name__ == '__main__':
    unittest.main()
