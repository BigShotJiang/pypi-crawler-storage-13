import unittest
import xml.etree.ElementTree as ET
from cmpparis_parser.csv_to_xml import CSVToXMLConverter

class TestCSVToXMLConverter(unittest.TestCase):

    def setUp(self):
        self.converter = CSVToXMLConverter()
        self.config = {
            "root_element": "ns:PurchaseOrder",
            "namespaces": {
                "ns": "http://schema.infor.com/InforOAGIS/2"
            },
            "header_mapping": {
                "ns:PurchaseOrderHeader/ns:DocumentID/ns:ID": "OrderNumber"
            },
            "lines_root": "ns:PurchaseOrderHeader",
            "line_element": "ns:PurchaseOrderLine",
            "line_mapping": {
                "ns:LineNumber": "LineNum",
                "ns:Item/ns:ItemID/ns:ID": "ItemCode"
            },
            "group_by": "OrderNumber"
        }

    def test_convert_single_order(self):
        csv_content = "OrderNumber;LineNum;ItemCode\nPO123;1;ITEM001\nPO123;2;ITEM002"
        xml_output = self.converter.convert(csv_content, self.config)
        
        root = ET.fromstring(xml_output)
        ns = {"ns": "http://schema.infor.com/InforOAGIS/2"}
        
        # Check Header
        doc_id = root.find(".//ns:DocumentID/ns:ID", ns).text
        self.assertEqual(doc_id, "PO123")
        
        # Check Lines
        lines = root.findall(".//ns:PurchaseOrderLine", ns)
        self.assertEqual(len(lines), 2)
        
        self.assertEqual(lines[0].find("ns:LineNumber", ns).text, "1")
        self.assertEqual(lines[0].find(".//ns:ItemID/ns:ID", ns).text, "ITEM001")
        
        self.assertEqual(lines[1].find("ns:LineNumber", ns).text, "2")
        self.assertEqual(lines[1].find(".//ns:ItemID/ns:ID", ns).text, "ITEM002")

    def test_convert_multiple_orders_single_entity_mode(self):
        # By default, it creates one root. If we have multiple orders in CSV, 
        # and group_by is set, the current implementation (Single Entity Mode) 
        # will overwrite header fields with the last group? 
        # Wait, let's check implementation.
        # In Single Entity Mode: _process_entity uses rows[0] for header.
        # So it takes the header from the FIRST row of the ENTIRE CSV.
        # This means if CSV has PO123 and PO456, the header will be PO123, 
        # and ALL lines from PO123 and PO456 will be added to it.
        # This is expected behavior for "Single Entity Mode".
        
        csv_content = "OrderNumber;LineNum\nPO123;1\nPO456;1"
        xml_output = self.converter.convert(csv_content, self.config)
        root = ET.fromstring(xml_output)
        ns = {"ns": "http://schema.infor.com/InforOAGIS/2"}
        
        doc_id = root.find(".//ns:DocumentID/ns:ID", ns).text
        self.assertEqual(doc_id, "PO123")
        
        lines = root.findall(".//ns:PurchaseOrderLine", ns)
        self.assertEqual(len(lines), 2)

    def test_convert_multiple_orders_multi_entity_mode(self):
        # Test with entity_element set
        multi_config = self.config.copy()
        multi_config["root_element"] = "ns:PurchaseOrders" # Wrapper
        multi_config["entity_element"] = "ns:PurchaseOrder" # Per group
        
        csv_content = "OrderNumber;LineNum\nPO123;1\nPO456;1"
        xml_output = self.converter.convert(csv_content, multi_config)
        
        root = ET.fromstring(xml_output)
        ns = {"ns": "http://schema.infor.com/InforOAGIS/2"}
        
        # Should have 2 PurchaseOrder children
        orders = root.findall("ns:PurchaseOrder", ns)
        self.assertEqual(len(orders), 2)
        
        # Check first order
        self.assertEqual(orders[0].find(".//ns:DocumentID/ns:ID", ns).text, "PO123")
        self.assertEqual(len(orders[0].findall(".//ns:PurchaseOrderLine", ns)), 1)
        
        # Check second order
        self.assertEqual(orders[1].find(".//ns:DocumentID/ns:ID", ns).text, "PO456")
        self.assertEqual(len(orders[1].findall(".//ns:PurchaseOrderLine", ns)), 1)

if __name__ == '__main__':
    unittest.main()
