####################################################
# setup.py for the 'cmpparis-parser' library
# Created by: Sofiane Charrad
####################################################

import setuptools

setuptools.setup(
    name="cmpparis-parser",
    version="0.1.2",
    author="Sofiane Charrad",
    author_email="s.charrad@cmp-paris.com",
    description="A lightweight BOD parsing library for CMP",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://codecatalyst.aws/spaces/CMP/projects/Coding-Tools/source-repositories/python-cmpparis-lib/",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
    install_requires=[
        "pyyaml",
    ],
)
