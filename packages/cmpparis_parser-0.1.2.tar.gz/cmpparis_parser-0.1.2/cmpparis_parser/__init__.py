####################################################
# __init__.py for the 'cmpparis-parser' library
# Created by: Sofiane Charrad
####################################################
"""Point d'entrée du package ``cmpparis_parser``.

Expose les classes et fonctions de parsing BOD.
"""

from .bod_parser import BODParser
from .bod_config import BODConfig
from .bod_config_loader import BODConfigLoader
from .csv_to_xml import CSVToXMLConverter
from .bod_transformers import (
    register_transformer,
    get_transformer,
    TRANSFORMER_REGISTRY
)

__all__ = [
    "BODParser",
    "BODConfig",
    "BODConfigLoader",
    "CSVToXMLConverter",
    "register_transformer",
    "get_transformer",
    "TRANSFORMER_REGISTRY",
]
