import csv
import io
import xml.etree.ElementTree as ET
from typing import Dict, List, Any, Optional
import logging
from xml.dom import minidom

logger = logging.getLogger(__name__)

class CSVToXMLConverter:
    """
    Converts CSV data to XML based on a configuration mapping.
    Supports hierarchical structures (Header/Lines) via grouping.
    """

    def __init__(self):
        pass

    def convert_file(self, csv_path: str, config: Dict[str, Any]) -> str:
        """
        Reads a CSV file and converts it to an XML string.

        Args:
            csv_path (str): Path to the CSV file.
            config (Dict[str, Any]): Configuration dictionary.

        Returns:
            str: The generated XML string.
        """
        with open(csv_path, 'r', encoding='utf-8') as f:
            csv_content = f.read()
        return self.convert(csv_content, config)

    def convert(self, csv_content: str, config: Dict[str, Any]) -> str:
        """
        Converts CSV content string to an XML string.

        Args:
            csv_content (str): CSV content as a string.
            config (Dict[str, Any]): Configuration dictionary.

        Returns:
            str: The generated XML string.
        """
        # Parse CSV
        reader = csv.DictReader(io.StringIO(csv_content), delimiter=';') # Default to semi-colon, maybe make configurable
        rows = list(reader)
        
        if not rows:
            logger.warning("CSV content is empty")
            return ""

        # Register Namespaces
        namespaces = config.get('namespaces', {})
        for prefix, uri in namespaces.items():
            ET.register_namespace(prefix, uri)

        # Group rows if needed
        group_by = config.get('group_by')
        grouped_data = self._group_rows(rows, group_by)

        # Create Root Element
        root_tag = self._expand_tag(config['root_element'], namespaces)
        root = ET.Element(root_tag)

        # Process groups (each group creates one main entity, e.g., one PurchaseOrder)
        # Wait, usually a CSV contains multiple POs? Or one PO with multiple lines?
        # If root is "PurchaseOrder", and we have multiple POs in CSV, do we create a list of POs?
        # Usually BODs are one per file or wrapped in a list.
        # Let's assume for now the CSV represents ONE logical document structure (like a list of Orders),
        # OR the root is a wrapper like "PurchaseOrders".
        # BUT, the user requirement implies "Reverse of BODParser". BODParser usually parses ONE BOD.
        # If the CSV contains multiple BODs, we might need to return a list of XMLs or a wrapped XML.
        # Let's assume the config defines the structure. 
        
        # Case 1: The CSV represents ONE document (e.g. one Invoice with multiple lines)
        # Case 2: The CSV represents MULTIPLE documents.
        
        # Let's implement: The Root Element wraps everything.
        # If group_by is set, we iterate over groups.
        # Inside each group, we map header fields (from first row of group) and line fields (iterate rows).
        
        # Actually, if root is "PurchaseOrder", it usually implies ONE PO.
        # If the CSV has multiple POs, we probably want a list of XML strings?
        # Or a root "PurchaseOrders" containing multiple "PurchaseOrder"?
        
        # Let's stick to the plan:
        # "root_element" is the top level.
        # If "group_by" is defined, we create children of root for each group?
        # No, usually "root_element" IS the document (e.g. PurchaseOrder).
        # If we have multiple POs, we can't put them in one root unless the root is a List.
        
        # Let's assume the standard use case: 1 CSV = 1 List of things OR 1 Complex thing.
        # Let's support: Root -> [Entity -> [Header, Lines]]
        
        # If config has "entity_element" (e.g. PurchaseOrder), we create one per group under Root.
        # If NOT, we assume Root IS the Entity (1 CSV = 1 Entity).
        
        entity_element = config.get('entity_element')
        
        if entity_element:
            # Multiple entities mode
            for group_key, group_rows in grouped_data.items():
                entity_tag = self._expand_tag(entity_element, namespaces)
                entity_node = ET.SubElement(root, entity_tag)
                self._process_entity(entity_node, group_rows, config, namespaces)
        else:
            # Single entity mode (Root IS the entity)
            # We treat all rows as belonging to this single entity
            # If group_by is set, it might be weird here, but let's just use all rows.
            self._process_entity(root, rows, config, namespaces)

        return self._prettify(root)

    def _group_rows(self, rows: List[Dict], group_by: Optional[str]) -> Dict[str, List[Dict]]:
        if not group_by:
            return {"all": rows}
        
        groups = {}
        for row in rows:
            key = row.get(group_by)
            if key not in groups:
                groups[key] = []
            groups[key].append(row)
        return groups

    def _process_entity(self, parent_node: ET.Element, rows: List[Dict], config: Dict, namespaces: Dict):
        # Header Mapping (use first row)
        first_row = rows[0]
        header_mapping = config.get('header_mapping', {})
        for xpath, col_name in header_mapping.items():
            value = first_row.get(col_name)
            if value:
                self._create_element_at_xpath(parent_node, xpath, value, namespaces)

        # Lines Mapping
        lines_root_xpath = config.get('lines_root')
        line_element_tag = config.get('line_element')
        line_mapping = config.get('line_mapping', {})

        if line_element_tag and line_mapping:
            # Find or create lines root
            lines_container = parent_node
            if lines_root_xpath:
                lines_container = self._find_or_create_xpath(parent_node, lines_root_xpath, namespaces)
            
            for row in rows:
                line_tag = self._expand_tag(line_element_tag, namespaces)
                line_node = ET.SubElement(lines_container, line_tag)
                
                for xpath, col_name in line_mapping.items():
                    value = row.get(col_name)
                    if value:
                        self._create_element_at_xpath(line_node, xpath, value, namespaces)

    def _expand_tag(self, tag: str, namespaces: Dict) -> str:
        if ':' in tag:
            prefix, local = tag.split(':', 1)
            if prefix in namespaces:
                return f"{{{namespaces[prefix]}}}{local}"
        return tag

    def _find_or_create_xpath(self, parent: ET.Element, xpath: str, namespaces: Dict) -> ET.Element:
        # Simple xpath handling: "ns:Parent/ns:Child"
        # Does NOT support full XPath syntax, only path of tags
        parts = xpath.split('/')
        current = parent
        for part in parts:
            if not part: continue
            tag = self._expand_tag(part, namespaces)
            # Check if exists (only direct child)
            found = current.find(tag) # This uses ET default namespace handling which might be tricky with expanded tags
            # ET.find with {uri}tag works.
            
            if found is None:
                found = ET.SubElement(current, tag)
            current = found
        return current

    def _create_element_at_xpath(self, parent: ET.Element, xpath: str, value: str, namespaces: Dict):
        # Last part is the element to set text to
        parts = xpath.split('/')
        current = parent
        
        # Navigate up to the last parent
        for part in parts[:-1]:
            if not part: continue
            tag = self._expand_tag(part, namespaces)
            found = current.find(tag)
            if found is None:
                found = ET.SubElement(current, tag)
            current = found
            
        # Create the leaf element
        leaf_tag = self._expand_tag(parts[-1], namespaces)
        leaf = ET.SubElement(current, leaf_tag)
        leaf.text = str(value)

    def _prettify(self, elem: ET.Element) -> str:
        rough_string = ET.tostring(elem, 'utf-8')
        reparsed = minidom.parseString(rough_string)
        return reparsed.toprettyxml(indent="  ")
