import spacy
import warnings

from spacy.language import Language
from spacy.tokens import Doc, Token, Span
from morphseg.interface.morpheme_segmenter import MorphemeSegmenter

Token.set_extension("morphemes", default=None)  # do this in the global scope so it happens when imported
Span.set_extension("morphemes",
                   getter=lambda obj: [i._.morphemes for i in obj])  # unsure if this is doing its thing
Doc.set_extension("morphemes", getter=lambda obj: [i._.morphemes for i in obj])


def predict(segmenter, word: str) -> list[str]:
    return segmenter.segment(word)[0]


@Language.factory("morpheme_segmenter", default_config={"model_filepath": None, "load_pretrained": True})
def seg_factory(nlp, name, model_filepath, load_pretrained):  # stateful component to handle different languages
    segmenter = MorphemeSegmenter(nlp.lang, model_filepath=model_filepath, load_pretrained=load_pretrained)
    nlp.segmenter = segmenter  # attach segmenter to nlp object for access later

    def segment_doc(doc):
        for token in doc:
            token._.morphemes = predict(nlp.segmenter, token.text)  # set segmentations for every token in doc
        return doc

    return segment_doc


def load_spacy_integration(lang, model_filepath=None, load_pretrained=True):
    cls = spacy.util.get_lang_class(lang)
    seg = MorphemeSegmenter(lang)
    nlp = cls()
    nlp.add_pipe("morpheme_segmenter", config={"model_filepath": model_filepath, "load_pretrained": load_pretrained})
    return nlp
