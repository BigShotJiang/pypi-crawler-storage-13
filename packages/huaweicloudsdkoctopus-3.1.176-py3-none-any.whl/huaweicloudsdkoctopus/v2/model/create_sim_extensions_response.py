# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateSimExtensionsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'name': 'str',
        'description': 'str',
        'mount_path': 'str',
        'url': 'str',
        'id': 'int',
        'created_at': 'float',
        'updated_at': 'float',
        'file': 'FileCreateSrlz'
    }

    attribute_map = {
        'name': 'name',
        'description': 'description',
        'mount_path': 'mount_path',
        'url': 'url',
        'id': 'id',
        'created_at': 'created_at',
        'updated_at': 'updated_at',
        'file': 'file'
    }

    def __init__(self, name=None, description=None, mount_path=None, url=None, id=None, created_at=None, updated_at=None, file=None):
        r"""CreateSimExtensionsResponse

        The model defined in huaweicloud sdk

        :param name: 名称
        :type name: str
        :param description: 描述
        :type description: str
        :param mount_path: 挂载路径
        :type mount_path: str
        :param url: 扩展文件资源地址。
        :type url: str
        :param id: 扩展文件ID。
        :type id: int
        :param created_at: 创建时间。
        :type created_at: float
        :param updated_at: 更新时间。
        :type updated_at: float
        :param file: 
        :type file: :class:`huaweicloudsdkoctopus.v2.FileCreateSrlz`
        """
        
        super().__init__()

        self._name = None
        self._description = None
        self._mount_path = None
        self._url = None
        self._id = None
        self._created_at = None
        self._updated_at = None
        self._file = None
        self.discriminator = None

        if name is not None:
            self.name = name
        self.description = description
        if mount_path is not None:
            self.mount_path = mount_path
        if url is not None:
            self.url = url
        if id is not None:
            self.id = id
        if created_at is not None:
            self.created_at = created_at
        if updated_at is not None:
            self.updated_at = updated_at
        if file is not None:
            self.file = file

    @property
    def name(self):
        r"""Gets the name of this CreateSimExtensionsResponse.

        名称

        :return: The name of this CreateSimExtensionsResponse.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this CreateSimExtensionsResponse.

        名称

        :param name: The name of this CreateSimExtensionsResponse.
        :type name: str
        """
        self._name = name

    @property
    def description(self):
        r"""Gets the description of this CreateSimExtensionsResponse.

        描述

        :return: The description of this CreateSimExtensionsResponse.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this CreateSimExtensionsResponse.

        描述

        :param description: The description of this CreateSimExtensionsResponse.
        :type description: str
        """
        self._description = description

    @property
    def mount_path(self):
        r"""Gets the mount_path of this CreateSimExtensionsResponse.

        挂载路径

        :return: The mount_path of this CreateSimExtensionsResponse.
        :rtype: str
        """
        return self._mount_path

    @mount_path.setter
    def mount_path(self, mount_path):
        r"""Sets the mount_path of this CreateSimExtensionsResponse.

        挂载路径

        :param mount_path: The mount_path of this CreateSimExtensionsResponse.
        :type mount_path: str
        """
        self._mount_path = mount_path

    @property
    def url(self):
        r"""Gets the url of this CreateSimExtensionsResponse.

        扩展文件资源地址。

        :return: The url of this CreateSimExtensionsResponse.
        :rtype: str
        """
        return self._url

    @url.setter
    def url(self, url):
        r"""Sets the url of this CreateSimExtensionsResponse.

        扩展文件资源地址。

        :param url: The url of this CreateSimExtensionsResponse.
        :type url: str
        """
        self._url = url

    @property
    def id(self):
        r"""Gets the id of this CreateSimExtensionsResponse.

        扩展文件ID。

        :return: The id of this CreateSimExtensionsResponse.
        :rtype: int
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this CreateSimExtensionsResponse.

        扩展文件ID。

        :param id: The id of this CreateSimExtensionsResponse.
        :type id: int
        """
        self._id = id

    @property
    def created_at(self):
        r"""Gets the created_at of this CreateSimExtensionsResponse.

        创建时间。

        :return: The created_at of this CreateSimExtensionsResponse.
        :rtype: float
        """
        return self._created_at

    @created_at.setter
    def created_at(self, created_at):
        r"""Sets the created_at of this CreateSimExtensionsResponse.

        创建时间。

        :param created_at: The created_at of this CreateSimExtensionsResponse.
        :type created_at: float
        """
        self._created_at = created_at

    @property
    def updated_at(self):
        r"""Gets the updated_at of this CreateSimExtensionsResponse.

        更新时间。

        :return: The updated_at of this CreateSimExtensionsResponse.
        :rtype: float
        """
        return self._updated_at

    @updated_at.setter
    def updated_at(self, updated_at):
        r"""Sets the updated_at of this CreateSimExtensionsResponse.

        更新时间。

        :param updated_at: The updated_at of this CreateSimExtensionsResponse.
        :type updated_at: float
        """
        self._updated_at = updated_at

    @property
    def file(self):
        r"""Gets the file of this CreateSimExtensionsResponse.

        :return: The file of this CreateSimExtensionsResponse.
        :rtype: :class:`huaweicloudsdkoctopus.v2.FileCreateSrlz`
        """
        return self._file

    @file.setter
    def file(self, file):
        r"""Sets the file of this CreateSimExtensionsResponse.

        :param file: The file of this CreateSimExtensionsResponse.
        :type file: :class:`huaweicloudsdkoctopus.v2.FileCreateSrlz`
        """
        self._file = file

    def to_dict(self):
        import warnings
        warnings.warn("CreateSimExtensionsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateSimExtensionsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
