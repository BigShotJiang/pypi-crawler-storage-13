"""Main entry point for fazeevision package."""

from .server import main

if __name__ == "__main__":
    main()
