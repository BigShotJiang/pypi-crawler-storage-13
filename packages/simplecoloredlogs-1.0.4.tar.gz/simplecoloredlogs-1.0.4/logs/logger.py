"""
Logs - Der komplette, erweiterte, farbige Terminal Logger
Behebt Fehler mit der Formatierung des Level-Namens (z.B. DEBUG).
"""

from datetime import datetime
from typing import Optional, Callable, Dict, Any
from pathlib import Path
import sys
import threading
import inspect
from enum import IntEnum
import traceback 

from colorama import Fore, Style, init

# Colorama initialisieren und automatisch zurücksetzen
init(autoreset=True)


class LogLevel(IntEnum):
    """Log-Level Definitionen (als IntEnum)"""
    DEBUG = 0
    INFO = 1
    SUCCESS = 2
    WARN = 3
    ERROR = 4
    FATAL = 5


class Logs:
    """
    Erweiterter Terminal Logger mit Farbunterstützung.
    """
    
    # --- Konfiguration (Klassenvariablen) ---
    enabled: bool = True
    show_timestamp: bool = True
    min_level: LogLevel = LogLevel.DEBUG
    log_file: Optional[Path] = None
    colorize: bool = True
    
    # Standardfarbe für die Log-Nachricht
    message_color: str = Fore.WHITE 
    
    # Format-String (Wird nur verwendet, wenn colorize=False)
    log_format: str = "[{timestamp}] {level_name:<7} [{category}] {message}"
    timestamp_format: str = "%Y-%m-%d %H:%M:%S"
    
    _lock = threading.Lock()
    _handlers: list[Callable] = []
    
    # Mapping für Kategorien-spezifische Farben
    _category_colors: Dict[str, str] = {}
    
    # Level-Farben
    _level_colors: Dict[LogLevel, str] = {
        LogLevel.DEBUG: Fore.CYAN,
        LogLevel.INFO: Fore.WHITE,
        LogLevel.SUCCESS: Fore.GREEN,
        LogLevel.WARN: Fore.YELLOW,
        LogLevel.ERROR: Fore.RED,
        LogLevel.FATAL: Fore.MAGENTA,
    }
    
    _level_names: Dict[LogLevel, str] = {
        lvl: lvl.name for lvl in LogLevel
    }
    
    @classmethod
    def _get_metadata(cls, frame_depth: int) -> Dict[str, Any]:
        """Holt Metadaten wie Dateiname und Zeilennummer des Aufrufers."""
        try:
            # frame_depth: 0=_get_metadata, 1=_log, 2=debug/info/etc., 3=Aufrufer
            frame = inspect.stack()[frame_depth] 
            return {
                "file": Path(frame.filename).name,
                "line": frame.lineno,
                "function": frame.function
            }
        except Exception:
            return {"file": "", "line": 0, "function": ""}

    @classmethod
    def _format_log(cls, level: LogLevel, category: str, message: str, metadata: Dict[str, Any]) -> str:
        """Erzeugt den finalen Log-String mit dynamischen Farben und korrekter Ausrichtung."""
        
        # Kontext für die plain_message
        context = {
            "timestamp": datetime.now().strftime(cls.timestamp_format),
            "level_name": cls._level_names[level],
            "category": category,
            "message": message,
            **metadata 
        }
        
        # 1. Plain Message (für File-Logging und wenn colorize=False)
        plain_message = cls.log_format.format(**context)
        
        if not cls.colorize:
            return plain_message
        
        # --- FARB-LOGIK (MANUELLE KONSTRUKTION FÜR KORREKTE AUSRICHTUNG) ---
        
        level_name = cls._level_names[level]
        level_color = cls._level_colors.get(level, Fore.WHITE)
        category_color = cls._category_colors.get(category, None)
        
        # a) Zeitstempel-Teil
        timestamp_part = ""
        # Wir bauen den Zeitstempel manuell basierend auf dem Standardformat.
        if cls.show_timestamp: 
            timestamp_str = context["timestamp"]
            timestamp_part = f"[{Style.DIM}{timestamp_str}{Style.RESET_ALL}] "
        
        # b) Level-Teil (Ausrichtung MUSS manuell VOR der Farbe erfolgen!)
        # Wir verwenden 7 Zeichen Breite, um alle Level-Namen auszurichten.
        padded_level_name = f"{level_name:<7}"
        colored_level_part = f"{level_color}{Style.BRIGHT}{padded_level_name}{Style.RESET_ALL}"
        
        # c) Kategorie-Teil
        category_color_or_style = category_color if category_color else Style.BRIGHT
        colored_category_part = f"{category_color_or_style}{category}{Style.RESET_ALL}"
            
        # d) Message-Teil
        # Wenn ERROR/FATAL, ist die Message Rot, sonst die konfigurierte message_color.
        msg_color = Fore.RED if level >= LogLevel.ERROR else cls.message_color
        colored_message_part = f"{msg_color}{message}{Style.RESET_ALL}"
        
        # 2. Manuelle Zusammenstellung des Strings (Garantiert korrekte Ausrichtung)
        final_output = (
            f"{timestamp_part}"
            f"{colored_level_part} "
            f"[{colored_category_part}] "
            f"{colored_message_part}"
        )
        
        # Entferne unnötige führende Leerzeichen nach dem Zeitstempel
        final_output = final_output.strip()
        
        return f"{final_output}{Style.RESET_ALL}"


    @classmethod
    def _write_to_file(cls, clean_message: str):
        """Schreibt den bereinigten Log-String in die Datei (Thread-sicher)."""
        if cls.log_file:
            try:
                # Entfernt alle ANSI-Farbcodes für die saubere Datei-Ausgabe
                clean_output = clean_message
                for color_code in list(Fore.__dict__.values()) + list(Style.__dict__.values()):
                    if isinstance(color_code, str):
                        clean_output = clean_output.replace(color_code, '')

                with open(cls.log_file, 'a', encoding='utf-8') as f:
                    # Fügt den Zeitstempel manuell hinzu, falls er in der Konsolenausgabe unterdrückt wurde
                    timestamp_prefix = ""
                    if not cls.show_timestamp:
                         timestamp_prefix = f"[{datetime.now().strftime(cls.timestamp_format)}] "
                         
                    f.write(timestamp_prefix + clean_output.strip() + '\n')
            except Exception as e:
                print(f"[Logs] Fehler beim Schreiben in Log-Datei: {e}", file=sys.stderr)


    @classmethod
    def _log(cls, level: LogLevel, category: str, message: str, frame_depth: int = 3):
        """Interne, thread-sichere Log-Methode."""
        if not cls.enabled or level < cls.min_level:
            return

        with cls._lock:
            metadata = cls._get_metadata(frame_depth=frame_depth)
            output = cls._format_log(level, category, message, metadata)
            
            # Ausgabe auf stdout oder stderr
            if level >= LogLevel.ERROR:
                print(output, file=sys.stderr)
            else:
                print(output)
            
            cls._write_to_file(output)
            
            # Custom Handler aufrufen
            for handler in cls._handlers:
                try:
                    handler(level, category, message, metadata)
                except Exception as e:
                    print(f"[Logs] Handler-Fehler: {e}", file=sys.stderr)
    
    # --- Public Logging Methoden (DEBUG, INFO, etc.) ---
    
    @classmethod
    def debug(cls, category: str, message: str):
        cls._log(LogLevel.DEBUG, category, message)
    
    @classmethod
    def info(cls, category: str, message: str):
        cls._log(LogLevel.INFO, category, message)
    
    @classmethod
    def success(cls, category: str, message: str):
        cls._log(LogLevel.SUCCESS, category, message)
    
    @classmethod
    def warn(cls, category: str, message: str):
        cls._log(LogLevel.WARN, category, message)
    
    @classmethod
    def error(cls, category: str, message: str):
        cls._log(LogLevel.ERROR, category, message)
    
    @classmethod
    def fatal(cls, category: str, message: str):
        cls._log(LogLevel.FATAL, category, message)

    @classmethod
    def exception(cls, category: str, message: str, exc: Optional[BaseException] = None):
        """ERROR Level mit Traceback-Unterstützung."""
        
        full_message = f"{message}\n"
        
        if exc is not None:
            full_message += "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        else:
            full_message += traceback.format_exc()
            
        cls._log(LogLevel.ERROR, category, full_message.strip(), frame_depth=3)
    
    # --- Konfigurations- und Handler-Methoden (unverändert) ---

    @classmethod
    def configure_category_colors(cls, color_map: Dict[str, str]):
        """Setzt ein Mapping von Kategorie-Namen zu Colorama-Farbcodes."""
        with cls._lock:
            cls._category_colors = color_map

    @classmethod
    def configure(cls, 
                  enabled: Optional[bool] = None,
                  show_timestamp: Optional[bool] = None,
                  timestamp_format: Optional[str] = None,
                  log_format: Optional[str] = None,
                  min_level: Optional[LogLevel] = None,
                  log_file: Optional[str] = None,
                  colorize: Optional[bool] = None,
                  message_color: Optional[str] = None):
        """Konfiguriert den Logger."""
        with cls._lock:
            if enabled is not None:
                cls.enabled = enabled
            if show_timestamp is not None:
                cls.show_timestamp = show_timestamp
            if timestamp_format is not None:
                cls.timestamp_format = timestamp_format
            if log_format is not None:
                cls.log_format = log_format
            if min_level is not None:
                cls.min_level = min_level
            if log_file is not None:
                cls.log_file = Path(log_file) if log_file else None
            if colorize is not None:
                cls.colorize = colorize
            if message_color is not None:
                cls.message_color = message_color
    
    @classmethod
    def add_handler(cls, handler: Callable[[LogLevel, str, str, Dict[str, Any]], None]):
        """Fügt einen Custom-Handler hinzu"""
        with cls._lock:
            cls._handlers.append(handler)
    
    @classmethod
    def remove_handler(cls, handler: Callable):
        """Entfernt einen Handler"""
        with cls._lock:
            if handler in cls._handlers:
                cls._handlers.remove(handler)
    
    @classmethod
    def clear_handlers(cls):
        """Entfernt alle Handler"""
        with cls._lock:
            cls._handlers.clear()
    
    @classmethod
    def reset(cls):
        """Setzt alle Einstellungen auf Standard zurück"""
        with cls._lock:
            cls.enabled = True
            cls.show_timestamp = True
            cls.timestamp_format = "%Y-%m-%d %H:%M:%S"
            cls.log_format = "[{timestamp}] {level_name:<7} [{category}] {message}"
            cls.min_level = LogLevel.DEBUG
            cls.log_file = None
            cls.colorize = True
            cls.message_color = Fore.WHITE
            cls._category_colors = {}
            cls.clear_handlers()