"""Custom lib exceptions."""

from typing import List, Optional


class IkClientBaseException(Exception):
    """Custom base exception."""

    pass


class TaskNotFoundException(IkClientBaseException):
    """When task is not found on workflow."""

    def __init__(self, workflow, task_name: str):
        """Initialize a new exception.

        Args:
            workflow: A workflow object
            task_name: Task name not found on workflow
        """
        super().__init__(f"Can't task '{task_name}' on workflow '{workflow}'")
        self.workflow = workflow
        self.task_name = task_name


class TaskIdNotFoundException(IkClientBaseException):
    """When task is not found on workflow."""

    def __init__(self, workflow, task_id: int):
        """Initialize a new exception.

        Args:
            workflow: A workflow object
            task_id: Task ID not found on workflow
        """
        super().__init__(f"Can't find task with ID #{task_id} on workflow '{workflow}'")
        self.workflow = workflow
        self.task_id = task_id


class FinalTaskNotFoundException(IkClientBaseException):
    """When no final (leaf) task found on workflow."""

    def __init__(self, workflow):
        """Initialize a new exception.

        Args:
            workflow: A workflow object
        """
        super().__init__(
            f"Can't find a final task on workflow '{workflow}'. You have to specify which task you want to run."
        )


class MultipleTaskFoundException(IkClientBaseException):
    """When more than one task match a given name."""

    def __init__(self, workflow, task_name: str, matching_ids: list[int]):
        """Initialize a new exception.

        Args:
            workflow: A workflow object
            task_name: Task name found multiple time on workflow
            matching_ids: A list of matching task ids
        """
        super().__init__(
            f"Found more than one task with name '{task_name}' on workflow '{workflow}'. "
            "Please provide a task id instead of a task name to select wanted task. "
            f"(matching ids: {', '.join(map(str, matching_ids))})"
        )
        self.workflow = workflow
        self.task_name = task_name
        self.matching_ids = matching_ids


class TaskParameterNotFoundException(IkClientBaseException):
    """When a parameter name not found on task."""

    def __init__(self, task_name: str, parameter_names: List[str], parameter_name: str):
        """Initialize a new exception.

        Args:
            task_name: Task name found multiple time on workflow
            parameter_names: A list of existing parameter names for task
            parameter_name: A mismatching parameter name
        """
        super().__init__(
            f"Parameter '{parameter_name}' not found on '{', '.join(parameter_names)}' for task '{task_name}'"
        )
        self.task_name = task_name
        self.parameter_names = parameter_names
        self.parameter_name = parameter_name


class OutputNotFoundException(IkClientBaseException):
    """When output is missing on Context."""

    def __init__(self):
        """Initialize a new exception."""
        super().__init__("Outputs information are mandatory. Please provide at least one output task name.")


class NoResultsException(IkClientBaseException):
    """When give up getting endpoint call results."""

    def __init__(self):
        """Initialize a new exception."""
        super().__init__("Can't get run call results.")


class CannotInferDataTypeException(IkClientBaseException):
    """When data type cannot be inferred from the metadata."""

    def __init__(self, content_type: str, is_directory: bool, wf_data_type: Optional[str]):
        """Initialize a new exception.

        Args:
            content_type: The content type of the file
            is_directory: Whether the path is a directory
            wf_data_type: The expected workflow data type
        """
        reasons = []
        if content_type:
            reasons.append(f"it has content type '{content_type}'")
        if is_directory:
            reasons.append("it is a directory")

        if wf_data_type:
            reasons.append(f"according to the workflow input types, the workflow expect a '{wf_data_type}' input")

        super().__init__(
            f"Can't automatically infer input data_type of {'directory' if is_directory else 'file'} "
            f"because {' and '.join(reasons)}. "
            "Please specify `data_type` explicitly or pass a compatible TaskIO object."
        )


class InvalidDataTypeForDirectoryException(IkClientBaseException):
    """When a data type incompatible with directory is provided."""

    def __init__(self, data_type: str):
        """Initialize a new exception.

        Args:
            data_type: The provided data type
        """
        super().__init__(f"Can't accept input data_type '{data_type}' for a directory. ")
