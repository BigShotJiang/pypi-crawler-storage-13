"""Ikomia SCALE deployment API client."""

import asyncio
import json
import logging
import mimetypes
import os
import zipfile
from abc import ABC, abstractmethod
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryFile
from typing import BinaryIO, Callable, Optional, Union, cast

import fsspec
from yarl import URL

import ikclient.http.auth
from ikclient.core.context import Context
from ikclient.core.io import BaseTaskIO, ImageIO, StorageObjectIO, TaskIO
from ikclient.core.results import Results
from ikclient.core.workflow import RawWorkflowTaskDataIO, Workflow
from ikclient.exceptions import (
    CannotInferDataTypeException,
    InvalidDataTypeForDirectoryException,
)
from ikclient.http.session import AsyncSession, Session
from ikclient.storage.client import AsyncStorageClient, BaseStorageClient, StorageClient, StorageObject

logger = logging.getLogger(__name__)


class BaseClient(ABC):
    """Base client for Ikomia SCALE deployment API."""

    def __init__(self, url: Union[str, URL], token: Optional[str] = None):
        """Initialize deployment API client.

        Args:
            url: Ikomia SCALE deployment endpoint URL.
            token: API token. Defaults to IKOMIA_TOKEN environment variable.
        """
        self.url = URL(url)
        scale_url = URL(os.getenv("IKOMIA_URL", "https://scale.ikomia.ai"))

        # Initialize auth
        token = token if token is not None else os.getenv("IKOMIA_TOKEN")
        assert isinstance(token, str)

        self._auth = ikclient.http.auth.ScaleJwtAuth(scale_url=str(scale_url), token=token, endpoint_url=str(self.url))

        # Cache workflow
        self._workflow: Optional[Workflow] = None

    @property
    @abstractmethod
    def storage(self) -> BaseStorageClient:
        """Return a well initialized storage client."""
        pass

    def _infer_data_type(  # noqa: PLR0911, PLR0912
        self,
        *,
        is_directory: bool,
        content_type: str = "application/octet-stream",
        data_type: Optional[str] = None,
        workflow_input: Optional[RawWorkflowTaskDataIO] = None,
    ) -> tuple[str, str]:
        """Try to infer the most appropriate input data type for a object metadata.

        If the user call `client.run("path/to/image.jpg")`, the correct data type to send to the deployment might be:
        - an image
        - a file_path
        - something else (if the path is weirdly named: e.g. if "image.jpg" is actually a directory)

        We try to infer the correct data type to use based on:
        - The user provided data_type (that needs to be validated)
        - Whether the path links to a file or a directory
        - The known content type of the file or determined from the file extension
        - The workflow input type hint (if the workflow provides one, old versions of Ikomia API might not provide it)

        Args:
            is_directory: Whether the object is a directory.
            content_type: The content type of the file (if known).
            data_type: User provided data type (if any).
            workflow_input: The workflow input data (if available).

        Returns:
            A tuple of (data_type, content_type).

        Raises:
            InvalidDataTypeForDirectoryException: If is_directory==True and data_type is incompatible.
            CannotInferDataTypeException: If the data type cannot be inferred.
        """
        is_file = not is_directory
        content_type = content_type if is_file else ""

        wf_data_type = None
        if workflow_input is not None:
            wf_data_type = workflow_input["name"].removeprefix("IODataType.").lower()

        # - User provided a data type
        if data_type is not None:
            if is_file:  # Send file in whatever data_type
                return data_type, content_type

            # For directories, only folder_path is allowed
            if is_directory and data_type == "folder_path":
                return "folder_path", "application/zip"

            raise InvalidDataTypeForDirectoryException(data_type=data_type)

        is_image = content_type.startswith("image/")
        is_video = content_type.startswith("video/")

        # - The workflow input is not provided, try to infer data type from content type only
        if wf_data_type is None:
            if is_image:
                return "image", content_type
            if is_video:
                return "video", content_type
            if is_file:
                return "file_path", content_type
            if is_directory:
                return "folder_path", "application/zip"

        # - Try to infer data type with workflow hint
        if wf_data_type == "image":
            if is_image:
                return "image", content_type
            if is_video:
                return "video", content_type

        if wf_data_type == "video":
            if is_video:
                return "video", content_type

        if wf_data_type == "file_path":
            if is_file:
                return "file_path", content_type

        if wf_data_type == "folder_path":
            if content_type == "application/zip" or is_directory:
                return "folder_path", "application/zip"

        raise CannotInferDataTypeException(
            content_type=content_type,
            is_directory=is_directory,
            wf_data_type=wf_data_type,
        )

    @staticmethod
    def _get_workflow_inputs(workflow: Workflow) -> list[Optional[RawWorkflowTaskDataIO]]:
        workflow_inputs: list[Optional[RawWorkflowTaskDataIO]] = []
        for conn in workflow.data["connections"]:
            if conn["source_id"] == -1:  # Root connection
                task = workflow.get_task_by_id(conn["target_id"])
                task_inputs = task["task_data"].get("inputs", [])
                try:
                    workflow_inputs.append(task_inputs[conn["target_index"]])
                except IndexError:
                    workflow_inputs.append(None)

        return workflow_inputs

    def _get_raw_inputs(self, *inputs: Union[BaseTaskIO, Results, dict]) -> list[dict]:
        raw_inputs = []
        for input_data in inputs:
            if isinstance(input_data, BaseTaskIO):
                raw_inputs.append(input_data.raw)
            elif isinstance(input_data, Results):
                raw_inputs.extend(input_data._outputs)
            elif isinstance(input_data, dict):
                raw_inputs.append(input_data)
            else:
                raise TypeError(f"Unsupported input type: {type(input_data)}")
        return raw_inputs

    def _create_storage_input_from_object(
        self,
        obj: StorageObject,
        *,
        data_type: Optional[str] = None,
        workflow_input: Optional[RawWorkflowTaskDataIO] = None,
    ) -> StorageObjectIO:
        data_type, _ = self._infer_data_type(
            is_directory=False,
            content_type=obj.get("content_type", "application/octet-stream"),
            workflow_input=workflow_input,
            data_type=data_type,
        )

        return StorageObjectIO(
            {
                "storage_object": {
                    "url": str(self.storage.scalefs_url / "v1/objects/" % {"uid": obj["uid"]}),
                    "data_type": data_type,
                }
            }
        )

    @contextmanager
    def _zip_directory_to_tempfile(self, fs: fsspec.AbstractFileSystem, path: str) -> Generator[BinaryIO, None, None]:
        with TemporaryFile() as temp_file:
            with zipfile.ZipFile(temp_file, "w", zipfile.ZIP_DEFLATED) as zip:
                for directory_path, _, filenames in fs.walk(path):
                    for filename in filenames:
                        file_path = fs.sep.join([directory_path, filename])
                        with fs.open(file_path, "rb") as f:
                            arcname = os.path.relpath(file_path, start=path)
                            zip.writestr(arcname, f.read())
            temp_file.seek(0)
            yield temp_file


class Client(BaseClient):
    """Client for Ikomia SCALE deployment API."""

    def __init__(self, url: Union[str, URL], token: Optional[str] = None):
        """Initialize deployment API client.

        Args:
            url: Ikomia SCALE deployment endpoint URL.
            token: API token. Defaults to IKOMIA_TOKEN environment variable.
        """
        super().__init__(url, token)
        self._session: Optional[Session] = None
        self._storage: Optional[StorageClient] = None

    @property
    def session(self) -> Session:
        """Return a well initialized session.

        Returns:
            Session: HTTP client session.
        """
        if self._session is None:
            self._session = Session(self.url, self._auth)
        return self._session

    @property
    def storage(self) -> StorageClient:
        """Return a well initialized storage client.

        Returns:
            StorageClient: Storage client.
        """
        if self._storage is None:
            self._storage = StorageClient(self.url, _auth=self._auth)
        return self._storage

    def close(self):
        """Close the HTTP client session."""
        if self._session is not None:
            self._session.close()

    def __enter__(self) -> "Client":
        """Enter context manager.

        Returns:
            Client: Self instance.
        """
        logger.debug("Open session on %s", self.url)
        _ = self.session
        return self

    def __exit__(self, *_):
        """Exit context manager and close client."""
        logger.debug("Close session on %s", self.url)
        self.close()

    def get_workflow(self) -> Workflow:
        """Get deployment workflow.

        Returns:
            Workflow: Deployment workflow.
        """
        if self._workflow is None:
            response = self.session.get("/workflow")
            self._workflow = Workflow(response.json())
        return self._workflow

    def build_context(self) -> Context:
        """Create a new context for this deployment endpoint.

        Returns:
            Context: A properly initialized context.
        """
        workflow = self.get_workflow()
        return Context(workflow)

    def create_input(
        self,
        path: Union[str, Path],
        *,
        data_type: Optional[str] = None,
        workflow_input: Optional[RawWorkflowTaskDataIO] = None,
        save_temporary=False,
        storage_options: Optional[dict] = None,
    ) -> BaseTaskIO:
        """Get deployment input from a path.

        Args:
            path: Path to the input. Support fsspec paths (e.g. "s3://bucket/file").
            data_type: Input type (e.g. "image", "video", "file_path", "folder_path").
                If not provided, we will try to infer it from file extension and workflow_input.
            workflow_input: Optional workflow input type definition to help infer data type.
            save_temporary: If True, upload the data to SCALE storage.
                Note: Video inputs are always uploaded to SCALE storage.
            storage_options: Options for fsspec file system.
                https://filesystem-spec.readthedocs.io/en/latest

        Returns:
            BaseTaskIO: Object as deployment input.
        """
        fs, _, [path] = fsspec.get_fs_token_paths(path, storage_options=storage_options)
        fs = cast(fsspec.AbstractFileSystem, fs)

        path_content_type, _ = mimetypes.guess_type(str(path))

        data_type, content_type = self._infer_data_type(
            is_directory=fs.isdir(path),
            content_type=path_content_type or "application/octet-stream",
            data_type=data_type,
            workflow_input=workflow_input,
        )

        if fs.isdir(path):
            file = self._zip_directory_to_tempfile(fs, str(path))
        else:
            file = fs.open(path, "rb")

        with file as f:
            if save_temporary or data_type in {"file_path", "folder_path", "video"}:
                uploaded_obj = self.storage.put(f.read(), content_type=content_type)
                return self._create_storage_input_from_object(uploaded_obj, data_type=data_type)

            if data_type == "image":
                return ImageIO.create(f.read())

            return TaskIO(json.loads(f.read().decode("utf-8")))

    def create_storage_input(
        self,
        path: str,
        *,
        data_type: Optional[str] = None,
        workflow_input: Optional[RawWorkflowTaskDataIO] = None,
    ) -> StorageObjectIO:
        """Get deployment input from a storage object path.

        Args:
            path: Path to the object in SCALE storage.
            data_type: Input type (e.g. "image", "video", "file_path", "folder_path").
                If not provided, we will try to infer it from content type and workflow_input.
            workflow_input: Optional workflow input type definition to help infer data type.

        Returns:
            StorageObjectIO: Object as deployment input.
        """
        obj = self.storage.get(path)
        return self._create_storage_input_from_object(obj, data_type=data_type, workflow_input=workflow_input)

    def create_storage_input_from_uid(
        self,
        uid: str,
        *,
        data_type: Optional[str] = None,
        workflow_input: Optional[RawWorkflowTaskDataIO] = None,
    ) -> StorageObjectIO:
        """Get deployment input from a storage object UID.

        Args:
            uid: Object unique identifier.
            data_type: Input type (e.g. "image", "video", "file_path", "folder_path").
                If not provided, we will try to infer it from content type and workflow_input.
            workflow_input: Optional workflow input type definition to help infer data type.

        Returns:
            StorageObjectIO: Object as deployment input.
        """
        obj = self.storage.get_by_uid(uid)
        return self._create_storage_input_from_object(obj, data_type=data_type, workflow_input=workflow_input)

    def run(
        self,
        *inputs: Union[str, Path, BaseTaskIO, Results, dict],
        parameters: Optional[dict[str, object]] = None,
        on_progress: Optional[Callable] = None,
    ) -> Results:
        """Run the deployment's final task.

        Args:
            *inputs: Input data. Can be a path, a BaseTaskIO, a Results object, or a serialized JSON input.
            parameters: Task parameters.
            on_progress: Callback for progress reporting.

        Returns:
            Results: Task execution results.
        """
        # Get final task from workflow
        workflow = self.get_workflow()
        task_name = workflow.get_first_final_task_name()

        # Then call run_task
        return self.run_task(task_name, *inputs, parameters=parameters, on_progress=on_progress)

    def run_task(
        self,
        task_name: str,
        *inputs: Union[str, Path, BaseTaskIO, Results, dict],
        parameters: Optional[dict[str, object]] = None,
        on_progress: Optional[Callable] = None,
    ) -> Results:
        """Run a specific task in the deployment.

        Args:
            task_name: Name of the task to run.
            *inputs: Input data. Can be a path, a BaseTaskIO, a Results object, or a serialized JSON input.
            parameters: Task parameters.
            on_progress: Callback for progress reporting.

        Returns:
            Results: Task execution results.
        """
        # Get context
        context = self.build_context()

        # Add parameters if needed
        if parameters:
            context.set_parameters(task_name, parameters)

        # Add default output
        context.add_output(task_name)

        # Run context
        return self.run_on(context, *inputs, on_progress=on_progress)

    def run_on(
        self,
        context: Context,
        *inputs: Union[str, Path, BaseTaskIO, Results, dict],
        on_progress: Optional[Callable] = None,
    ) -> Results:
        """Run with a specific context.

        Args:
            context: Execution context with parameters and outputs configuration.
            *inputs: Input data. Can be a path, a BaseTaskIO, a Results object, or a serialized JSON input.
            on_progress: Callback for progress reporting.

        Returns:
            Results: Task execution results.
        """
        workflow = self.get_workflow()
        workflow_inputs = self._get_workflow_inputs(workflow)

        while len(workflow_inputs) < len(inputs):
            workflow_inputs.append(None)

        # Convert processed inputs to raw inputs
        raw_inputs = self._get_raw_inputs(
            *[
                self.create_input(inp, workflow_input=wf_inp) if isinstance(inp, (str, Path)) else inp
                for inp, wf_inp in zip(inputs, workflow_inputs)
            ]
        )

        return self.session.run_on(context, raw_inputs, on_progress=on_progress)


class AsyncClient(BaseClient):
    """Async client for Ikomia SCALE deployment API."""

    def __init__(self, url: Union[str, URL], token: Optional[str] = None):
        """Initialize async deployment API client.

        Args:
            url: Ikomia SCALE deployment endpoint URL.
            token: API token. Defaults to IKOMIA_TOKEN environment variable.
        """
        super().__init__(url, token)
        self._session: Optional[AsyncSession] = None
        self._storage: Optional[AsyncStorageClient] = None
        self._workflow_mutex = asyncio.Lock()

    @property
    def session(self) -> AsyncSession:
        """Return a well initialized session.

        Returns:
            AsyncSession: Async HTTP client session.
        """
        if self._session is None:
            self._session = AsyncSession(self.url, self._auth)
        return self._session

    @property
    def storage(self) -> AsyncStorageClient:
        """Return a well initialized storage client.

        Returns:
            AsyncStorageClient: Async storage client.
        """
        if self._storage is None:
            self._storage = AsyncStorageClient(self.url, _auth=self._auth)
        return self._storage

    async def aclose(self):
        """Close the HTTP client session."""
        if self._session is not None:
            await self._session.aclose()

    async def __aenter__(self) -> "AsyncClient":
        """Enter async context manager.

        Returns:
            AsyncClient: Self instance.
        """
        logger.debug("Open session on %s", self.url)
        _ = self.session
        return self

    async def __aexit__(self, *_):
        """Exit async context manager and close client."""
        logger.debug("Close session on %s", self.url)
        await self.aclose()

    async def get_workflow(self) -> Workflow:
        """Get deployment workflow.

        Returns:
            Workflow: Deployment workflow.
        """
        # We use a mutex to ensure that we don't try to fetch the same workflow multiple times
        async with self._workflow_mutex:
            if self._workflow is None:
                response = await self.session.get("/workflow")
                self._workflow = Workflow(response.json())
        return self._workflow

    async def build_context(self) -> Context:
        """Create a new context for this deployment endpoint.

        Returns:
            Context: A properly initialized context.
        """
        workflow = await self.get_workflow()
        return Context(workflow)

    async def create_input(
        self,
        path: Union[str, Path],
        *,
        data_type: Optional[str] = None,
        workflow_input: Optional[RawWorkflowTaskDataIO] = None,
        save_temporary=False,
        storage_options: Optional[dict] = None,
    ) -> BaseTaskIO:
        """Get deployment input from a path.

        Args:
            path: Path to the input. Support fsspec paths (e.g. "s3://bucket/file").
            data_type: Input type (e.g. "image", "video", "file_path", "folder_path").
                If not provided, we will try to infer it from file extension and workflow_input.
            workflow_input: Optional workflow input type definition to help infer data type.
            save_temporary: If True, upload the data to SCALE storage.
                Note: Video inputs are always uploaded to SCALE storage.
            storage_options: Options for fsspec file system.
                https://filesystem-spec.readthedocs.io/en/latest

        Returns:
            BaseTaskIO: Object as deployment input.
        """
        fs, _, [path] = fsspec.get_fs_token_paths(path, storage_options=storage_options)
        fs = cast(fsspec.AbstractFileSystem, fs)

        path_content_type, _ = mimetypes.guess_type(str(path))

        data_type, content_type = self._infer_data_type(
            is_directory=fs.isdir(path),
            content_type=path_content_type or "application/octet-stream",
            data_type=data_type,
            workflow_input=workflow_input,
        )

        if fs.isdir(path):
            file = self._zip_directory_to_tempfile(fs, str(path))
        else:
            file = fs.open(path, "rb")

        with file as f:
            if save_temporary or data_type in {"file_path", "folder_path", "video"}:
                uploaded_obj = await self.storage.put(f.read(), content_type=content_type)
                return self._create_storage_input_from_object(uploaded_obj, data_type=data_type)

            if data_type == "image":
                return ImageIO.create(f.read())

            return TaskIO(json.loads(f.read().decode("utf-8")))

    async def create_storage_input(
        self,
        path: str,
        *,
        data_type: Optional[str] = None,
        workflow_input: Optional[RawWorkflowTaskDataIO] = None,
    ) -> StorageObjectIO:
        """Get deployment input from a storage object path.

        Args:
            path: Path to the object in SCALE storage.
            data_type: Input type (e.g. "image", "video", "file_path", "folder_path").
                If not provided, we will try to infer it from content type and workflow_input.
            workflow_input: Optional workflow input type definition to help infer data type.

        Returns:
            StorageObjectIO: Object as deployment input.
        """
        obj = await self.storage.get(path)
        return self._create_storage_input_from_object(obj, data_type=data_type, workflow_input=workflow_input)

    async def create_storage_input_from_uid(
        self,
        uid: str,
        *,
        data_type: Optional[str] = None,
        workflow_input: Optional[RawWorkflowTaskDataIO] = None,
    ) -> StorageObjectIO:
        """Get deployment input from a storage object UID.

        Args:
            uid: Object unique identifier.
            data_type: Input type (e.g. "image", "video", "file_path", "folder_path").
                If not provided, we will try to infer it from content type and workflow_input.
            workflow_input: Optional workflow input type definition to help infer data type.

        Returns:
            StorageObjectIO: Object as deployment input.
        """
        obj = await self.storage.get_by_uid(uid)
        return self._create_storage_input_from_object(obj, data_type=data_type, workflow_input=workflow_input)

    async def run(
        self,
        *inputs: Union[str, Path, BaseTaskIO, Results, dict],
        parameters: Optional[dict[str, object]] = None,
        on_progress: Optional[Callable] = None,
    ) -> Results:
        """Run the deployment's final task.

        Args:
            *inputs: Input data. Can be a path, a BaseTaskIO, a Results object, or a serialized JSON input.
            parameters: Task parameters.
            on_progress: Callback for progress reporting.

        Returns:
            Results: Task execution results.
        """
        # Get final task from workflow
        workflow = await self.get_workflow()
        task_name = workflow.get_first_final_task_name()

        # Then call run_task
        return await self.run_task(task_name, *inputs, parameters=parameters, on_progress=on_progress)

    async def run_task(
        self,
        task_name: str,
        *inputs: Union[str, Path, BaseTaskIO, Results, dict],
        parameters: Optional[dict[str, object]] = None,
        on_progress: Optional[Callable] = None,
    ) -> Results:
        """Run a specific task in the deployment.

        Args:
            task_name: Name of the task to run.
            *inputs: Input data. Can be a path, a BaseTaskIO, a Results object, or a serialized JSON input.
            parameters: Task parameters.
            on_progress: Callback for progress reporting.

        Returns:
            Results: Task execution results.
        """
        # Get context
        context = await self.build_context()

        # Add parameters if needed
        if parameters:
            context.set_parameters(task_name, parameters)

        # Add default output
        context.add_output(task_name)

        # Run context
        return await self.run_on(context, *inputs, on_progress=on_progress)

    async def run_on(
        self,
        context: Context,
        *inputs: Union[str, Path, BaseTaskIO, Results, dict],
        on_progress: Optional[Callable] = None,
    ) -> Results:
        """Run with a specific context.

        Args:
            context: Execution context with parameters and outputs configuration.
            *inputs: Input data. Can be a path, a BaseTaskIO, a Results object, or a serialized JSON input.
            on_progress: Callback for progress reporting.

        Returns:
            Results: Task execution results.
        """

        async def _identity(x: Union[BaseTaskIO, Results, dict]) -> Union[BaseTaskIO, Results, dict]:
            return x

        workflow = await self.get_workflow()
        workflow_inputs = self._get_workflow_inputs(workflow)

        while len(workflow_inputs) < len(inputs):
            workflow_inputs.append(None)

        loaded_inputs = await asyncio.gather(
            *[
                self.create_input(inp, workflow_input=wf_inp) if isinstance(inp, (str, Path)) else _identity(inp)
                for inp, wf_inp in zip(inputs, workflow_inputs)
            ]
        )
        raw_inputs = self._get_raw_inputs(*loaded_inputs)

        return await self.session.run_on(context, raw_inputs, on_progress=on_progress)
