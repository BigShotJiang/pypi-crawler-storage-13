## 0.13.1 (2025-11-18)

### added (3 changes)

- [Add Wuhan ODE model, implementing Read et al. 2021.](https://gitlab.com/gem-epidemics/gemlib/-/commit/9f4411a1a0b1c162f50e5a2130c16c54351e63ed) ([merge request](https://gitlab.com/gem-epidemics/gemlib/-/merge_requests/111))
- [Add `sanitize_key` function](https://gitlab.com/gem-epidemics/gemlib/-/commit/c93ffd59b60aef22585808ff73094fc464e77e8d) ([merge request](https://gitlab.com/gem-epidemics/gemlib/-/merge_requests/111))
- [Add a more flexible cumsum function](https://gitlab.com/gem-epidemics/gemlib/-/commit/96313807ee5f77a7639fbc835557413bcde3eba0) ([merge request](https://gitlab.com/gem-epidemics/gemlib/-/merge_requests/111))

### changed (2 changes)

- [Update Scipy, JAX and TFP versions](https://gitlab.com/gem-epidemics/gemlib/-/commit/444fb4062e3d96f7dccc6602e044df6555b9c7c5) ([merge request](https://gitlab.com/gem-epidemics/gemlib/-/merge_requests/111))
- [Replace DeterministicStateTransitionModel with ode_model](https://gitlab.com/gem-epidemics/gemlib/-/commit/f6ef7f7319310329e78a753a5b17ec971d96eed6) ([merge request](https://gitlab.com/gem-epidemics/gemlib/-/merge_requests/111))

### removed (3 changes)

- [Remove experimental state transition models.](https://gitlab.com/gem-epidemics/gemlib/-/commit/a8c844357a8d757ebc0be82bbd91aef5417a7d70) ([merge request](https://gitlab.com/gem-epidemics/gemlib/-/merge_requests/111))
- [Remove TensorFlow dependency](https://gitlab.com/gem-epidemics/gemlib/-/commit/1b293dfd04834666fbe28ab78fd94dee5b4506c9) ([merge request](https://gitlab.com/gem-epidemics/gemlib/-/merge_requests/111))
- [Remove deprecated `MultiScanKernel`](https://gitlab.com/gem-epidemics/gemlib/-/commit/2af87d68c11acd7df25f661a1b99a1faf9433868) ([merge request](https://gitlab.com/gem-epidemics/gemlib/-/merge_requests/111))

