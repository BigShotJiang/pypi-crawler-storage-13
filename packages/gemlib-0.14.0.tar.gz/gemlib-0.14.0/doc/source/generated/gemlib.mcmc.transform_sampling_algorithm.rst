﻿gemlib.mcmc.transform\_sampling\_algorithm
==========================================

.. currentmodule:: gemlib.mcmc

.. autofunction:: transform_sampling_algorithm