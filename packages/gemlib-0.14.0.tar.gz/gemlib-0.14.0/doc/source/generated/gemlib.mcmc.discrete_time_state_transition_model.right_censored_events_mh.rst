﻿gemlib.mcmc.discrete\_time\_state\_transition\_model.right\_censored\_events\_mh
================================================================================

.. currentmodule:: gemlib.mcmc.discrete_time_state_transition_model

.. autofunction:: right_censored_events_mh