﻿gemlib.mcmc.mcmc
================

.. currentmodule:: gemlib.mcmc

.. autofunction:: mcmc