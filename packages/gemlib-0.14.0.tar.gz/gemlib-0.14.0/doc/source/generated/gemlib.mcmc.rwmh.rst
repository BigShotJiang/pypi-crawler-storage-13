﻿gemlib.mcmc.rwmh
================

.. currentmodule:: gemlib.mcmc

.. autofunction:: rwmh