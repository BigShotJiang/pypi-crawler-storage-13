﻿DiscreteTimeStateTransitionModel
================================

.. currentmodule:: gemlib.distributions

.. autoclass:: DiscreteTimeStateTransitionModel
	       
   
   .. automethod:: __init__

   

   Methods
   -------
   ..
      .. autosummary::
	 :toctree:
	 :nosignatures:

   
   
   
   .. automethod:: batch_shape_tensor
   
   
   
   .. automethod:: compute_state
   
   
   
   
   
   
   .. automethod:: event_shape_tensor
   
   
   
   
   
   
   
   
   
   
   .. automethod:: log_prob
   
   
   
   
   
   
   
   
   .. automethod:: prob
   
   
   
   .. automethod:: sample
   
   
   
   
   .. automethod:: transition_prob_matrix
   
   
   
   
   

   
   

   Attributes
   ----------

   .. autosummary::
   
      ~DiscreteTimeStateTransitionModel.allow_nan_stats
      ~DiscreteTimeStateTransitionModel.batch_shape
      ~DiscreteTimeStateTransitionModel.dtype
      ~DiscreteTimeStateTransitionModel.event_shape
      ~DiscreteTimeStateTransitionModel.experimental_shard_axis_names
      ~DiscreteTimeStateTransitionModel.incidence_matrix
      ~DiscreteTimeStateTransitionModel.initial_state
      ~DiscreteTimeStateTransitionModel.initial_step
      ~DiscreteTimeStateTransitionModel.name
      ~DiscreteTimeStateTransitionModel.num_states
      ~DiscreteTimeStateTransitionModel.num_steps
      ~DiscreteTimeStateTransitionModel.num_units
      ~DiscreteTimeStateTransitionModel.parameters
      ~DiscreteTimeStateTransitionModel.reparameterization_type
      ~DiscreteTimeStateTransitionModel.source_states
      ~DiscreteTimeStateTransitionModel.time_delta
      ~DiscreteTimeStateTransitionModel.trainable_variables
      ~DiscreteTimeStateTransitionModel.transition_rate_fn
      ~DiscreteTimeStateTransitionModel.validate_args
      ~DiscreteTimeStateTransitionModel.variables
   
   