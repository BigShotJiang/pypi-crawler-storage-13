﻿gemlib.mcmc.SamplingAlgorithm
=============================

.. currentmodule:: gemlib.mcmc

.. autoclass:: SamplingAlgorithm

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SamplingAlgorithm.__init__
      ~SamplingAlgorithm.init
      ~SamplingAlgorithm.step
      ~SamplingAlgorithm.then
   
   

   
   
   