﻿ContinuousTimeStateTransitionModel
==================================

.. currentmodule:: gemlib.distributions

.. autoclass:: ContinuousTimeStateTransitionModel
	       
   
   .. automethod:: __init__

   

   Methods
   -------
   ..
      .. autosummary::
	 :toctree:
	 :nosignatures:

   
   
   
   .. automethod:: batch_shape_tensor
   
   
   
   .. automethod:: compute_state
   
   
   
   
   
   
   .. automethod:: event_shape_tensor
   
   
   
   
   
   
   
   
   
   
   .. automethod:: log_prob
   
   
   
   
   
   
   
   
   .. automethod:: prob
   
   
   
   .. automethod:: sample
   
   
   
   
   
   
   

   
   

   Attributes
   ----------

   .. autosummary::
   
      ~ContinuousTimeStateTransitionModel.allow_nan_stats
      ~ContinuousTimeStateTransitionModel.batch_shape
      ~ContinuousTimeStateTransitionModel.dtype
      ~ContinuousTimeStateTransitionModel.event_shape
      ~ContinuousTimeStateTransitionModel.experimental_shard_axis_names
      ~ContinuousTimeStateTransitionModel.incidence_matrix
      ~ContinuousTimeStateTransitionModel.initial_state
      ~ContinuousTimeStateTransitionModel.initial_time
      ~ContinuousTimeStateTransitionModel.name
      ~ContinuousTimeStateTransitionModel.num_steps
      ~ContinuousTimeStateTransitionModel.parameters
      ~ContinuousTimeStateTransitionModel.reparameterization_type
      ~ContinuousTimeStateTransitionModel.trainable_variables
      ~ContinuousTimeStateTransitionModel.transition_rate_fn
      ~ContinuousTimeStateTransitionModel.validate_args
      ~ContinuousTimeStateTransitionModel.variables
   
   