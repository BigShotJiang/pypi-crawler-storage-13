﻿gemlib.spatial.pdist
====================

.. currentmodule:: gemlib.spatial

.. autofunction:: pdist