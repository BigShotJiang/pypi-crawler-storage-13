﻿gemlib.mcmc.multi\_scan
=======================

.. currentmodule:: gemlib.mcmc

.. autofunction:: multi_scan