﻿gemlib.mcmc.hmc
===============

.. currentmodule:: gemlib.mcmc

.. autofunction:: hmc