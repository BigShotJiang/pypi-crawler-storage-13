﻿gemlib.mcmc.discrete\_time\_state\_transition\_model.move\_events
=================================================================

.. currentmodule:: gemlib.mcmc.discrete_time_state_transition_model

.. autofunction:: move_events