﻿gemlib.mcmc.MwgStep
===================

.. currentmodule:: gemlib.mcmc

.. autoclass:: MwgStep

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MwgStep.__init__
   
   

   
   
   