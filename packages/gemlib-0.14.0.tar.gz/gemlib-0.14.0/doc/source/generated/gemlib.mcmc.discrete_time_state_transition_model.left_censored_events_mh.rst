﻿gemlib.mcmc.discrete\_time\_state\_transition\_model.left\_censored\_events\_mh
===============================================================================

.. currentmodule:: gemlib.mcmc.discrete_time_state_transition_model

.. autofunction:: left_censored_events_mh