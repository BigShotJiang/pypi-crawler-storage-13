﻿gemlib.deterministic.ode\_model
===============================

.. currentmodule:: gemlib.deterministic

.. autofunction:: ode_model