﻿gemlib.typing.foo
=================

.. currentmodule:: gemlib.typing

.. autofunction:: foo