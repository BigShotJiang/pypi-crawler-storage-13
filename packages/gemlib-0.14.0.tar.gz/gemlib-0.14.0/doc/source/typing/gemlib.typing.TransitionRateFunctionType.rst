﻿gemlib.typing.TransitionRateFunctionType
========================================

.. currentmodule:: gemlib.typing

.. autodata:: TransitionRateFunctionType