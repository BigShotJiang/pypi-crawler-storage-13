﻿gemlib.typing
==============

.. automodule:: gemlib.typing

.. currentmodule:: gemlib.typing

.. autosummary::
   :toctree: typing/

   TransitionRateFunctionType
   foo
