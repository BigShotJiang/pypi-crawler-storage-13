"""Type aliases and annotations"""

from __future__ import annotations

from collections.abc import Callable, Sequence

import jax

ArrayLike = jax.typing.ArrayLike

TransitionRateFunctionType = (
    Sequence[Callable[[float, ArrayLike], ArrayLike]]
    | Callable[[float, ArrayLike], tuple[ArrayLike, ...]]
)
"""Transition rate function type

A type for a transition function can take two forms...
"""


def foo(tx: TransitionRateFunctionType) -> None:
    """SOme doc here

    Args:
      tx: the transition rate function

    Returns:
      Nowt
    """

    return None
