# Framework for Spatially Joining two Hydrofabric Flowlines
<hr style="border: 1px solid black; margin: 0;"> 

## Update the code
```bash
git clone https://github.com/sdmlua/riverjoin_py
cd riverjoin_py
```

Use the ```uv``` to work and update the code,
```bash
pip install uv

#Create a virtual env and start collabortaing the code
uv venv

#activate the virtual environment
source .venv/bin/activate

#Install all the dependencies and all development packages into it
uv pip install e .
uv pip install -e ".[dev]"

#Then add/edit modules under the src/ and run the code through the tests
#For instance
pytest tests/spatial_join.py
```
Once all changes are made, update the code style with ```black``` code formatter.
```bash
black .
```