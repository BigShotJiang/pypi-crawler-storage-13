import os
import io
import geopandas as gpd
import fiona
import folium
import contextlib
from typing import Optional

from .project_initialization import setup_project
from .situation_checker import check_situation


class VizualizeOutputInteractively:
    """
    Interactive display of flowlines by situation, with custom styling.
    Saves map as HTML and optionally returns the Folium map object.

    Whatever the output in any steps, pass that layer, it will be vizualize the output interactively.
    """

    def __init__(
        self,
        join_fl: str,
        target_fl: str,
        simplify_tolerance: float = 1000,
        output_clip_layer: Optional[str] = None,
        target_reach_unique_id_field: Optional[str] = None,
        identifier: Optional[str] = None,
        unique_id: Optional[str] = None,
        join_fl_layer: Optional[str] = None,
        target_fl_layer: Optional[str] = None,
    ):
        self.join_fl = join_fl
        self.join_fl_layer = join_fl_layer
        self.target_fl = target_fl
        self.target_fl_layer = target_fl_layer

        self.output_clip_layer = output_clip_layer or "ClippedFlowlines"

        # Importing paths from the project setup module
        self.project_paths = setup_project.only_paths()
        self.output_reach_gpkg = self.project_paths.output_reach_gpkg
        self.output_final_reach_gpkg = self.project_paths.output_final_reach_gpkg
        self.output_reach_point_perp_gpkg = (
            self.project_paths.output_reach_point_perp_gpkg
        )
        self.target_reach_unique_id_field = target_reach_unique_id_field
        self.identifier = identifier
        self.unique_id = unique_id
        self.simplify_tolerance = simplify_tolerance

        # Derived layer names
        if identifier:
            self.perp_filtered = (
                f"orig_join_perp_notcross_intersected_filtered_{identifier}"
            )
            self.perp_notcross = f"perp_lines_notcross_{identifier}"
            self.traced_layer = f"join_fl_traced_extracted_reaches_{identifier}"
            self.final_layer = f"join_fl_final_reaches_{identifier}"
        else:
            self.perp_filtered = "orig_join_perp_notcross_intersected_filtered"
            self.perp_notcross = "perp_lines_notcross"
            self.traced_layer = "join_fl_traced_extracted_reaches"
            self.final_layer = "join_fl_final_reaches"

        # Get the situation
        if identifier:
            with contextlib.redirect_stdout(io.StringIO()):
                self.situation = check_situation(identifier=identifier).situation
        else:
            with contextlib.redirect_stdout(io.StringIO()):
                self.situation = check_situation().situation

        self.map = None  # Will store folium map

        # Deciding which visualization to run
        if self.situation:
            self.run_situation()
        else:
            self.visualize_join_and_target()

    def visualize_join_and_target(self):
        """Simplified display when no situation is found."""
        if self.join_fl_layer is None:
            join_gdf = gpd.read_file(self.join_fl)
        else:
            join_gdf = gpd.read_file(self.join_fl, layer=self.join_fl_layer)

        join_simp = join_gdf.copy()
        join_simp.geometry = join_simp.geometry.simplify(
            tolerance=self.simplify_tolerance, preserve_topology=True
        )
        available_layers = fiona.listlayers(self.target_fl)
        if self.target_fl_layer and self.target_fl_layer in available_layers:
            target_gdf = gpd.read_file(self.target_fl, layer=self.target_fl_layer)
        else:
            target_gdf = gpd.read_file(self.target_fl)

        # Base map
        self.map = target_gdf.explore(
            tiles="cartodbpositron",
            name="Target flowlines",
            color="#73B2FF",
            style_kwds={"weight": 6},
            tooltip=self.target_reach_unique_id_field,
        )

        join_simp.explore(
            m=self.map,
            name="Join flowlines",
            color="#732600",
            style_kwds={"weight": 0.5},
            tooltip=self.unique_id,
        )

        folium.LayerControl(collapsed=False).add_to(self.map)
        self.save_map()

    # Read and simplify join flowlines
    def run_situation(self):
        if self.join_fl_layer is None:
            self.join_fl = gpd.read_file(self.join_fl)
        else:
            self.join_fl = gpd.read_file(self.join_fl, layer=self.join_fl_layer)
        join_simp = self.join_fl.copy()
        join_simp.geometry = join_simp.geometry.simplify(
            tolerance=self.simplify_tolerance, preserve_topology=True
        )

        # Base style for target & clipped
        base_kwargs = dict(
            color="#73B2FF",
            style_kwds={"weight": 6},
            tooltip=self.target_reach_unique_id_field,
        )

        # Render based on situation
        if self.situation == "no_intersection":
            available_layers = fiona.listlayers(self.target_fl)
            if self.target_fl_layer in available_layers:
                target_gdf = gpd.read_file(self.target_fl, layer=self.target_fl_layer)
            else:
                target_gdf = gpd.read_file(self.target_fl)

            self.map = target_gdf.explore(
                tiles="cartodbpositron", name="Target flowlines", **base_kwargs
            )
            join_simp.explore(
                m=self.map,
                name="Join (simplified)",
                color="#732600",
                style_kwds={"weight": 0.5},
                tooltip=self.unique_id,
            )

        # elif self.situation == "all_extracted":
        #     self.map = gpd.read_file(
        #         self.output_reach_gpkg, layer=self.output_clip_layer
        #     ).explore(tiles="cartodbpositron", name="Clipped target", **base_kwargs)
        #     join_simp.explore(
        #         m=self.map,
        #         name="Join (simplified)",
        #         color="#732600",
        #         style_kwds={"weight": 0.5},
        #         tooltip=self.unique_id,
        #     )
        #     gpd.read_file(self.output_final_reach_gpkg, layer=self.final_layer).explore(
        #         m=self.map,
        #         name="Final reaches",
        #         color="#E64C00",
        #         style_kwds={"weight": 3},
        #         tooltip=self.unique_id,
        #     )

        elif self.situation == "extract_upstream_others":
            self.map = gpd.read_file(
                self.output_reach_gpkg, layer=self.output_clip_layer
            ).explore(tiles="cartodbpositron", name="Clipped target", **base_kwargs)
            join_simp.explore(
                m=self.map,
                name="Join (simplified)",
                color="#732600",
                style_kwds={"weight": 0.5},
                tooltip=self.unique_id,
            )
            gpd.read_file(
                self.output_reach_point_perp_gpkg, layer=self.perp_notcross
            ).explore(
                m=self.map,
                name="Perp notcross",
                color="#000000",
                style_kwds={"weight": 1},
                tooltip=False,
            )
            gpd.read_file(self.output_final_reach_gpkg, layer=self.final_layer).explore(
                m=self.map,
                name="Final reaches",
                color="#E64C00",
                style_kwds={"weight": 3},
                tooltip=self.unique_id,
            )
            gpd.read_file(
                self.output_reach_point_perp_gpkg, layer=self.perp_filtered
            ).explore(
                m=self.map,
                name="Perp filtered",
                color="yellow",
                style_kwds={"weight": 3},
                tooltip=self.unique_id,
            )
            gpd.read_file(self.output_reach_gpkg, layer=self.traced_layer).explore(
                m=self.map,
                name="Traced reaches",
                color="#005CE6",
                style_kwds={"weight": 3},
                tooltip=self.unique_id,
            )
        else:
            raise ValueError(f"Unknown situation: {self.situation!r}")

        # Add layer control
        folium.LayerControl(collapsed=False).add_to(self.map)

        # Save the map
        self.save_map()

    # Build filename parts dynamically
    def save_map(self):
        filename_parts = ["output_interactive_map"]

        if getattr(self, "situation", None):
            filename_parts.append(self.situation)
        if getattr(self, "identifier", None):
            filename_parts.append(self.identifier)

        out_path = "_".join(filename_parts) + ".html"

        self.map.save(out_path)
        print(f"Interactive map saved to {os.path.abspath(out_path)}")
        return self.map
