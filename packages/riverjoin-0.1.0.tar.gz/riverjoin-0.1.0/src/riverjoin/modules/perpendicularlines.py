import os
import re
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import MultiLineString, Point, LineString
from pyproj import CRS
from typing import Optional, Union, List

from .project_initialization import setup_project


# To calculate the upstreamflowlines along with the extracted flowlines, we need to create nodes at regular intervals for Extraction.
class create_nodes:
    """
    Extracts spaced nodes along flowlines at specified intervals.
    - Read `output_reach_layer` from `output_reach_gpkg`.
    - If geographic, reproject to a suitable UTM zone (meters);
       otherwise stay in the native projected CRS.
    - Interpolate points every `spacing` meters along each segment,
       dropping the overlapping boundary point.
    - Drop exact duplicates.
    - If we reprojected in step 2, reproject back to original CRS,
       then write to `output_reach_point_perp_gpkg`/`output_layer`.
    """

    def __init__(
        self,
        target_reach_unique_id_field: str,
        output_clip_layer: Optional[str] = None,
        node_output_layer: Optional[str] = None,
        identifier: Optional[str] = None,
        spacing: float = 200,  # in meters
    ):

        self.target_reach_unique_id_field = target_reach_unique_id_field
        self.spacing = spacing
        self.identifier = identifier

        # Get the necessary path internally to automate the process
        self.project_paths = setup_project.only_paths()
        self.output_reach_gpkg = self.project_paths.output_reach_gpkg
        self.output_reach_point_perp_gpkg = (
            self.project_paths.output_reach_point_perp_gpkg
        )

        self.output_reach_layer = output_clip_layer or "ClippedFlowlines"

        # Output layer name
        if node_output_layer:
            self.output_layer = node_output_layer
        else:
            spacing_tag = self.float_to_tag(spacing)
            suffix = f"_{self.identifier}" if self.identifier else ""
            self.output_layer = f"nodes_space_{spacing_tag}m{suffix}"

        # run the process
        self.run()

    def run(self):
        self.result = self.extract()

    @staticmethod
    def float_to_tag(x: float) -> str:
        s = f"{x:g}"
        return s.replace(".", "p")

    def _reproject_to_utm(self, gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        orig_crs = gdf.crs
        if orig_crs.is_geographic:
            minx, miny, maxx, maxy = gdf.total_bounds
            midx, midy = (minx + maxx) / 2, (miny + maxy) / 2
            zone = int((midx + 180) // 6) + 1
            epsg_utm = 32600 + zone if midy >= 0 else 32700 + zone
            return gdf.to_crs(epsg=epsg_utm)
        else:
            return gdf

    def extract(self) -> gpd.GeoDataFrame:
        # Load and clean
        lines = (
            gpd.read_file(self.output_reach_gpkg, layer=self.output_reach_layer)
            .dropna(subset=["geometry"])
            .explode(ignore_index=True)
        )
        orig_crs = lines.crs

        # Reproject if needed
        lines_proj = self._reproject_to_utm(lines)

        # Generate spaced points
        point_records = []
        for row in lines_proj.itertuples():
            geom = row.geometry
            parts = geom.geoms if isinstance(geom, MultiLineString) else [geom]
            for part_idx, seg in enumerate(parts):
                L = seg.length
                if L == 0:
                    continue
                n_steps = max(1, int(np.ceil(L / self.spacing)))
                dists = np.linspace(0, L, n_steps + 1)
                if part_idx > 0:
                    dists = dists[1:]
                for d in dists:
                    pt = seg.interpolate(d)
                    point_records.append(
                        {
                            "reach_id": getattr(
                                row, self.target_reach_unique_id_field, None
                            ),
                            "geometry": pt,
                        }
                    )

        pts_proj = gpd.GeoDataFrame(point_records, crs=lines_proj.crs)

        # Drop exact duplicates
        pts_proj = pts_proj.drop_duplicates(subset="geometry").reset_index(drop=True)

        # Save to file
        os.makedirs(os.path.dirname(self.output_reach_point_perp_gpkg), exist_ok=True)
        pts_proj.to_file(
            filename=self.output_reach_point_perp_gpkg,
            layer=self.output_layer,
            driver="GPKG",
        )

        print(
            f"Generated and wrote {len(pts_proj)} nodes (spacing={self.float_to_tag(self.spacing)}m) to {self.output_reach_point_perp_gpkg}/{self.output_layer}"
        )
        return pts_proj


# Create the perpendicular line along the nodes
class generate_perpendicular_lines:
    """
    Generates perpendicular lines at regularly spaced nodes on a flowline.

    - Reads nodes from GeoPackage
    - Builds perpendicular lines at each segment
    - Cleans and filters invalid lines
    - Writes output to specified GeoPackage layer
    """

    def __init__(
        self,
        spacing: float = 200,  # in meters
        perp_line_length: float = 600,  # in meters
        identifier: Optional[str] = None,
        node_output_layer: Optional[str] = None,
    ):
        self.identifier = identifier

        # nodes layer name
        if node_output_layer:
            self.nodes_layer = node_output_layer
        else:
            spacing_tag = self.float_to_tag(spacing)
            suffix = f"_{self.identifier}" if self.identifier else ""
            self.nodes_layer = f"nodes_space_{spacing_tag}m{suffix}"

        self.spacing = spacing
        self.perp_line_length = perp_line_length

        # Project paths
        self.project_paths = setup_project.only_paths()
        self.nodes_gpkg = self.project_paths.output_reach_point_perp_gpkg
        self.output_gpkg = self.project_paths.output_reach_point_perp_gpkg

        # Output layer name
        self.output_layer = f"perp_lines_len{self.float_to_tag(perp_line_length)}_space{self.float_to_tag(spacing)}m{suffix}"

        self.result = None
        self.run()

    @staticmethod
    def float_to_tag(x: float) -> str:
        return f"{x:g}".replace(".", "p")

    def generate_perpendicular_line(
        self, node: Point, previous_node: Point
    ) -> Optional[LineString]:
        x1, y1 = previous_node.x, previous_node.y
        x2, y2 = node.x, node.y
        dx, dy = x2 - x1, y2 - y1
        perp_dx, perp_dy = -dy, dx
        norm = np.hypot(perp_dx, perp_dy)
        if norm == 0:
            return None
        perp_dx /= norm
        perp_dy /= norm
        start = (
            node.x + perp_dx * self.perp_line_length / 2,
            node.y + perp_dy * self.perp_line_length / 2,
        )
        end = (
            node.x - perp_dx * self.perp_line_length / 2,
            node.y - perp_dy * self.perp_line_length / 2,
        )
        return LineString([start, end])

    def run(self):
        self.result = self.extract()

    def extract(self) -> gpd.GeoDataFrame:
        # Read nodes
        nodes = gpd.read_file(self.nodes_gpkg, layer=self.nodes_layer)
        nodes = nodes.dropna(subset=["geometry"])
        nodes = nodes[~nodes.geometry.is_empty]

        # Generate perpendiculars
        perp_lines = []
        for i in range(1, len(nodes)):
            cur = nodes.geometry.iloc[i]
            prev = nodes.geometry.iloc[i - 1]
            line = self.generate_perpendicular_line(cur, prev)
            if line is not None:
                perp_lines.append(line)

        perp_gdf = gpd.GeoDataFrame(geometry=perp_lines, crs=nodes.crs)

        # Filter valid lines
        perp_gdf["geometry"] = perp_gdf["geometry"].apply(self.valid_or_none)
        perp_gdf = perp_gdf.dropna(subset=["geometry"]).reset_index(drop=True)

        # Write output
        os.makedirs(os.path.dirname(self.output_gpkg), exist_ok=True)
        perp_gdf.to_file(
            filename=self.output_gpkg, layer=self.output_layer, driver="GPKG"
        )

        print(
            f"Step 4.0.2: Saved {len(perp_gdf)} perpendicular lines to {self.output_gpkg}/{self.output_layer}"
        )
        return perp_gdf

    @staticmethod
    def valid_or_none(geom):
        if (
            geom is not None
            and geom.is_valid
            and np.isfinite(geom.length)
            and geom.length > 0
        ):
            return geom
        return None


# Remove the perpendicular lines which intersect with alteady traced stream networks
class PerpendicularCleaner:
    """
    Removes perpendicular lines that intersect traced flowlines.

    - Reads traced flowlines and perpendicular lines
    - Performs spatial join to find intersections
    - Removes intersecting lines
    - Writes cleaned result to a new layer
    """

    def __init__(
        self,
        spacing: float = 200,  # in meters
        perp_line_length: float = 600,  # in meters
        identifier: Optional[str] = None,
    ):
        self.identifier = identifier
        self.spacing = spacing
        self.perp_line_length = perp_line_length

        suffix = f"_{self.identifier}" if self.identifier else ""
        self.perp_layer = f"perp_lines_len{self.float_to_tag(perp_line_length)}_space{self.float_to_tag(spacing)}m{suffix}"

        # If user provided an identifier, use it to create unique layer names
        if identifier:
            self.traced_layer = f"join_fl_traced_extracted_reaches_{identifier}"
            self.output_layer = f"perp_lines_notcross_{identifier}"
        else:
            self.traced_layer = "join_fl_traced_extracted_reaches"
            self.output_layer = f"perp_lines_notcross"

        # Get project paths
        self.project_paths = setup_project.only_paths()
        self.output_reach_gpkg = self.project_paths.output_reach_gpkg
        self.output_reach_point_perp_gpkg = (
            self.project_paths.output_reach_point_perp_gpkg
        )

        self.result_layer = None
        self.run()

    def run(self):
        self.result_layer = self.clean()

    @staticmethod
    def float_to_tag(x: float) -> str:
        return f"{x:g}".replace(".", "p")

    def clean(self) -> str:
        # Read traced flowlines and perpendicular lines
        traced_gdf = gpd.read_file(self.output_reach_gpkg, layer=self.traced_layer)
        perp_gdf = gpd.read_file(
            self.output_reach_point_perp_gpkg, layer=self.perp_layer
        )

        # Align CRS if needed
        if traced_gdf.crs != perp_gdf.crs:
            perp_gdf = perp_gdf.to_crs(traced_gdf.crs)

        # Find intersecting perpendiculars
        joined = gpd.sjoin(perp_gdf, traced_gdf, how="inner", predicate="intersects")
        intersecting_idx = joined.index.unique()

        # Drop intersecting lines
        if len(intersecting_idx) > 0:
            perp_notcross_gdf = perp_gdf.drop(index=intersecting_idx)
        else:
            perp_notcross_gdf = perp_gdf.copy()

        # Save cleaned layer
        perp_notcross_gdf.to_file(
            self.output_reach_point_perp_gpkg, layer=self.output_layer, driver="GPKG"
        )

        print(
            f"Wrote non‐crossing perpendicular lines to {self.output_reach_point_perp_gpkg}/{self.output_layer}"
        )
        return self.output_layer


# [Original Code]--> more flexible filtering with user-defined expressions is written below
# Perform the spatial joining between the original flowlines and the remaining perpendicular lines
# class SpatialJoinWithPerpendicularlines:
#     def __init__(
#         self,
#         join_fl: str,
#         unique_id: str,
#         min_join_count: int = 5,
#         min_strm_order: int = 2,
#         join_fl_layer: Optional[str] = None,
#         strm_order_field: Optional[str] = None,
#         identifier: Optional[str] = None,
#     ):
#         self.identifier = identifier
#         self.join_fl = join_fl

#         self.join_fl_layer = join_fl_layer
#         self.unique_id = unique_id
#         self.min_join_count = min_join_count
#         self.strm_order_field = strm_order_field
#         self.min_strm_order = min_strm_order

#         # If user provided an identifier, use it to create unique layer names
#         if identifier:
#             self.perp_notcross_layer = f"perp_lines_notcross_{identifier}"
#         else:
#             self.perp_notcross_layer = f"perp_lines_notcross"

#         # Get project paths
#         self.project_paths = setup_project.only_paths()
#         self.perp_gpkg = self.project_paths.output_reach_point_perp_gpkg
#         self.output_reach_point_prep_gpkg = (
#             self.project_paths.output_reach_point_perp_gpkg
#         )

#         self.joined_1to1 = None
#         self.filtered_gdf = None

#         self.run()

#     def run(self):
#         self.read_inputs()
#         self.align_crs()
#         self.spatial_join()
#         self.filter_and_count()
#         self.collapse_to_first_match()
#         self.write_joined_output()
#         self.apply_final_filter()
#         self.write_filtered_output()
#         self.print_summary()

#     # Read inputs
#     def read_inputs(self):
#         if self.join_fl_layer is None:
#             self.orig_gdf = gpd.read_file(self.join_fl)
#         else:
#             self.orig_gdf = gpd.read_file(self.join_fl, layer=self.join_fl_layer)

#         self.perp_gdf = gpd.read_file(self.perp_gpkg, layer=self.perp_notcross_layer)

#     # Align the CRS
#     def align_crs(self):
#         if self.orig_gdf.crs != self.perp_gdf.crs:
#             self.perp_gdf = self.perp_gdf.to_crs(self.orig_gdf.crs)

#     # One to Many join
#     def spatial_join(self):
#         self.joined_1toN = gpd.sjoin(
#             self.orig_gdf, self.perp_gdf, how="left", predicate="intersects"
#         )

#         if "geometry_left" in self.joined_1toN.columns:
#             self.joined_1toN = self.joined_1toN.set_geometry("geometry_left").drop(
#                 columns=["geometry_right"], errors="ignore"
#             )

#     # Compute join counts per original index
#     def filter_and_count(self):
#         self.joined_filtered = self.joined_1toN[
#             self.joined_1toN["index_right"].notna()
#         ].copy()
#         counts = self.joined_filtered.groupby(self.joined_filtered.index).size()
#         self.joined_filtered["Join_Count"] = (
#             self.joined_filtered.index.to_series().map(counts).astype(int)
#         )

#     def collapse_to_first_match(self):
#         self.joined_1to1 = self.joined_filtered.drop_duplicates(
#             subset=self.unique_id, keep="first"
#         )

#     # Write the joined with counts layer
#     def write_joined_output(self):
#         if self.identifier:
#             layer1 = f"orig_join_perp_notcross_intersected_{self.identifier}"
#         else:
#             layer1 = "orig_join_perp_notcross_intersected"
#         self.joined_1to1.to_file(
#             self.output_reach_point_prep_gpkg, layer=layer1, driver="GPKG"
#         )

#     # Apply filters based on the parameters
#     def apply_final_filter(self):
#         if self.strm_order_field:
#             self.filtered_gdf = self.joined_1to1[
#                 (self.joined_1to1["Join_Count"] >= self.min_join_count)
#                 & (self.joined_1to1[self.strm_order_field] > self.min_strm_order)
#             ]
#         else:
#             self.filtered_gdf = self.joined_1to1[
#                 self.joined_1to1["Join_Count"] >= self.min_join_count
#             ]

#     # Writing the filtered output
#     def write_filtered_output(self):
#         if self.identifier:
#             layer2 = f"orig_join_perp_notcross_intersected_filtered_{self.identifier}"
#         else:
#             layer2 = "orig_join_perp_notcross_intersected_filtered"
#         self.filtered_layer_name = layer2
#         self.filtered_gdf.to_file(
#             self.output_reach_point_prep_gpkg, layer=layer2, driver="GPKG"
#         )

#     # build a human readable filter description
#     def print_summary(self):
#         if self.strm_order_field:
#             cond_txt = f"Join_Count≥{self.min_join_count} & {self.strm_order_field}>{self.min_strm_order}"
#         else:
#             cond_txt = f"Join_Count≥{self.min_join_count}"

#         print(
#             f"Wrote {len(self.filtered_gdf)} further found flowlines "
#             f"({cond_txt}) to {self.output_reach_point_prep_gpkg}/{self.filtered_layer_name}"
#         )

"""
User can have their own expression based on the requirement and the fields available in their flowline dataset.
Note: All the executions are based on precedence rules of python pandas eval/query method.
For example, 

Minimum join count only
"Join_Count >= 5"

Using the alias --> auto-mapped:
"min_join_count >= 5" will becomes "Join_Count >= 5"

Combine conditions
"(Join_Count >= 6) & (stream_order > 2)"/ "(Join_Count >= 6) AND (stream_order > 2)"
"(Join_Count >= 6) | (stream_order > 2)"/ "(Join_Count >= 6) OR (stream_order > 2)"

OR logic
"(Join_Count >= 8) OR (stream_order >= 4)" ⟶ normalized to ... | ...

Arithmetic on columns
"(width_m / area_km2) < 0.5 & Join_Count >= 5"

User can send any numbers of expressions as a list, which will be combined with AND logic 
filter_eqn =
            [
                "Join_Count >= 5 OR stream_order > 2",      #expr1
                "slope < 0.001",                #expr2
                "width_m < 300"                 #expr3
            ]
    This will be executed as mask = expr1 & expr2 & expr3

Or without list, User can also send like this:
Join_Count >= 5 OR stream_order > 2 AND slope < 0.001
"""


class SpatialJoinWithPerpendicularlines:
    def __init__(
        self,
        join_fl: str,
        unique_id: str,
        min_join_count: int = 5,
        min_strm_order: int = 2,
        join_fl_layer: Optional[str] = None,
        strm_order_field: Optional[str] = None,
        identifier: Optional[str] = None,
        filter_eqn: Optional[Union[str, List[str]]] = None,
    ):
        self.identifier = identifier
        self.join_fl = join_fl
        self.join_fl_layer = join_fl_layer
        self.unique_id = unique_id
        self.min_join_count = int(min_join_count)
        self.strm_order_field = strm_order_field
        self.min_strm_order = int(min_strm_order)
        self.user_filter = filter_eqn

        # If user provided an identifier, use it to create unique layer names
        if identifier:
            self.perp_notcross_layer = f"perp_lines_notcross_{identifier}"
        else:
            self.perp_notcross_layer = "perp_lines_notcross"

        # Get project paths
        self.project_paths = setup_project.only_paths()
        self.perp_gpkg = self.project_paths.output_reach_point_perp_gpkg
        self.output_reach_point_prep_gpkg = (
            self.project_paths.output_reach_point_perp_gpkg
        )

        self.joined_1to1 = None
        self.filtered_gdf = None

        self.run()

    def run(self):
        self.read_inputs()
        self.align_crs()
        self.spatial_join()
        self.filter_and_count()
        self.collapse_to_first_match()
        self.write_joined_output()
        self.apply_final_filter()
        self.write_filtered_output()
        self.print_summary()

    # Read inputs
    def read_inputs(self):
        if self.join_fl_layer is None:
            self.orig_gdf = gpd.read_file(self.join_fl)
        else:
            self.orig_gdf = gpd.read_file(self.join_fl, layer=self.join_fl_layer)

        self.perp_gdf = gpd.read_file(self.perp_gpkg, layer=self.perp_notcross_layer)

    # Align the CRS
    def align_crs(self):
        if self.orig_gdf.crs != self.perp_gdf.crs:
            self.perp_gdf = self.perp_gdf.to_crs(self.orig_gdf.crs)

    # One to Many join
    def spatial_join(self):
        self.joined_1toN = gpd.sjoin(
            self.orig_gdf, self.perp_gdf, how="left", predicate="intersects"
        )
        if "geometry_left" in self.joined_1toN.columns:
            self.joined_1toN = self.joined_1toN.set_geometry("geometry_left").drop(
                columns=["geometry_right"], errors="ignore"
            )

    # Compute join counts per original index
    def filter_and_count(self):
        self.joined_filtered = self.joined_1toN[
            self.joined_1toN["index_right"].notna()
        ].copy()
        counts = self.joined_filtered.groupby(self.joined_filtered.index).size()
        self.joined_filtered["Join_Count"] = (
            self.joined_filtered.index.to_series().map(counts).astype(int)
        )

    def collapse_to_first_match(self):
        self.joined_1to1 = self.joined_filtered.drop_duplicates(
            subset=self.unique_id, keep="first"
        )

    # helpers for user-defined filters
    _SAFE_CHARS_RE = re.compile(r"^[\s\w\.\(\)\|\&\!\=\<\>\+\-\*/%,]+$")

    def _normalize_expr(self, expr: str) -> str:
        """
        Normalize a single expression:
        - case-insensitive AND/OR -> & and |
        - treating 'min_join_count' as the computed Join_Count column
        - fix common operator variants:
            => -> >=, =< -> <=
            lone '=' -> '=='
        """
        e = expr.strip()

        # Logical operators
        e = re.sub(r"\bAND\b", "&", e, flags=re.IGNORECASE)
        e = re.sub(r"\bOR\b", "|", e, flags=re.IGNORECASE)

        # Special param name -> real column
        e = re.sub(r"\bmin_join_count\b", "Join_Count", e, flags=re.IGNORECASE)

        # Common typos: => and =<
        e = re.sub(r"=>", ">=", e)
        e = re.sub(r"=<", "<=", e)

        # Convert a SINGLE '=' (not part of >=, <=, !=, ==) into '=='
        e = re.sub(r"(?<![<>=!])=(?![=])", "==", e)
        return e

    def _validate_expr(self, expr: str):
        """Simple guard against arbitrary code in eval/query."""
        if not self._SAFE_CHARS_RE.match(expr):
            raise ValueError(
                "User filter contains unsupported characters. "
                "Allowed: letters, digits, _, spaces, ., () , operators & | ! = < > + - * / % ,"
            )

        # block dunder attempts
        if "__" in expr:
            raise ValueError("Disallowed token '__' in expression.")

        # allow decimals (e.g., 3.14) but block attribute-like dots (e.g., a.b)
        if "." in expr and not re.search(r"\b\d+\.\d+\b", expr):
            raise ValueError(
                "Dot notation not allowed (attribute access is disallowed)."
            )

    def _show_filter_schema(self, df: pd.DataFrame, preview: int = 0) -> None:
        # names and dtypes only
        print("\n[Schema] Column names and dtypes:")
        for col, dt in df.dtypes.items():
            print(f"  - {col}: {dt}")

    def _combine_user_filters(self, df: pd.DataFrame) -> pd.Series:
        """
        Accepts str or list[str]. Returns a boolean mask.
        Multiple strings are combined with '&'.

        Magic tokens:
            - "COLUMNS": print schema and still apply other expressions.
        """
        if self.user_filter is None:
            return pd.Series(True, index=df.index)

        exprs = (
            self.user_filter
            if isinstance(self.user_filter, list)
            else [self.user_filter]
        )

        # magic: print schema, then continue with remaining expressions
        MAGIC = {"COLUMNS"}
        if any(isinstance(x, str) and x.strip().upper() in MAGIC for x in exprs):
            self._show_filter_schema(df)  # prints names + dtypes
            exprs = [
                x
                for x in exprs
                if not (isinstance(x, str) and x.strip().upper() in MAGIC)
            ]
            if not exprs:
                return pd.Series(True, index=df.index)

        mask = pd.Series(True, index=df.index)
        for raw in exprs:
            e = self._normalize_expr(raw)
            self._validate_expr(e)

            # # print the processed expression before eval
            # print(f"[filter] raw: {raw}  ->  normalized: {e}")

            try:
                part = df.eval(e, engine="python")
                if part.dtype != bool:
                    raise ValueError(
                        f"User filter did not evaluate to boolean mask: '{raw}'"
                    )
            except Exception as ex:
                raise ValueError(
                    f"Failed to evaluate user filter '{raw}': {ex}"
                ) from ex
            mask &= part
        return mask

    # Apply filters based on the parameters
    def apply_final_filter(self):
        df = self.joined_1to1

        if self.user_filter:
            # user expressions of filter
            mask_user = self._combine_user_filters(df)
            self.filtered_gdf = df[mask_user].copy()
            return

        # Default behavior- keeping original logic
        if self.strm_order_field:
            self.filtered_gdf = df[
                (df["Join_Count"] >= self.min_join_count)
                & (df[self.strm_order_field] > self.min_strm_order)
            ].copy()
        else:
            self.filtered_gdf = df[df["Join_Count"] >= self.min_join_count].copy()

    # Write the joined with counts layer
    def write_joined_output(self):
        layer1 = (
            f"orig_join_perp_notcross_intersected_{self.identifier}"
            if self.identifier
            else "orig_join_perp_notcross_intersected"
        )
        self.joined_1to1.to_file(
            self.output_reach_point_prep_gpkg, layer=layer1, driver="GPKG"
        )

    # Writing the filtered output
    def write_filtered_output(self):
        layer2 = (
            f"orig_join_perp_notcross_intersected_filtered_{self.identifier}"
            if self.identifier
            else "orig_join_perp_notcross_intersected_filtered"
        )
        self.filtered_layer_name = layer2
        self.filtered_gdf.to_file(
            self.output_reach_point_prep_gpkg, layer=layer2, driver="GPKG"
        )

    # build a human readable filter description
    def print_summary(self):
        if self.user_filter:
            cond_txt = f"user_filter={self.user_filter}"
        elif self.strm_order_field:
            cond_txt = f"Join_Count≥{self.min_join_count} & {self.strm_order_field}>{self.min_strm_order}"
        else:
            cond_txt = f"Join_Count≥{self.min_join_count}"

        print(
            f"Wrote {len(self.filtered_gdf)} further found flowlines "
            f"({cond_txt}) to {self.output_reach_point_prep_gpkg}/{self.filtered_layer_name}"
        )


# Merge the already extracted flowlines with the perpendicular based extracted flowlines
class merge_and_drop_duplicates:
    """
    - Reads join_fl_perp_intersected_filtered and join_fl_traced_extracted into GeoDataFrames.
    - Merges them row-wise.
    - Drops duplicates by ["LINKNO","DSLINKNO","DSContArea"].
    - Drops any columns not in the original feature class (except geometry/ID fields).
    - Writes out the final deduplicated layer to
      output_reach_gpkg/all_extracted_reaches_{huc_id}.

    Returns:
        Path to the final merged & deduplicated feature class.
    """

    def __init__(
        self,
        join_fl: str,
        join_fl_layer: Optional[str] = None,
        identifier: Optional[str] = None,
    ):
        self.join_fl = join_fl
        self.join_fl_layer = join_fl_layer
        self.identifier = identifier

        # Get project paths
        self.project_paths = setup_project.only_paths()
        self.output_reach_gpkg = self.project_paths.output_reach_gpkg
        self.output_reach_point_perp_gpkg = (
            self.project_paths.output_reach_point_perp_gpkg
        )

        if identifier:
            self.output_layer_name = f"join_fl_merged_{identifier}"
            self.join_fl_perp_intersected_filtered = (
                f"orig_join_perp_notcross_intersected_filtered_{identifier}"
            )
            self.join_fl_traced_extracted = (
                f"join_fl_traced_extracted_reaches_{identifier}"
            )
        else:
            self.output_layer_name = "join_fl_merged"
            self.join_fl_perp_intersected_filtered = (
                "orig_join_perp_notcross_intersected_filtered"
            )
            self.join_fl_traced_extracted = "join_fl_traced_extracted_reaches"

        self.result = None  # Final deduplicated GeoDataFrame

        self.run()

    def run(self):
        self.read_inputs()
        self.align_crs()
        self.merge()
        self.drop_duplicates()
        self.clean_fields()
        self.write_output()
        self.print_summary()

    # Read traced and intersected flowlines
    def read_inputs(self):
        self.gdf_traced = gpd.read_file(
            self.output_reach_gpkg, layer=self.join_fl_traced_extracted
        )
        self.gdf_intersected = gpd.read_file(
            self.output_reach_point_perp_gpkg,
            layer=self.join_fl_perp_intersected_filtered,
        )

    # Align CRS if needed
    def align_crs(self):
        if self.gdf_traced.crs != self.gdf_intersected.crs:
            self.gdf_intersected = self.gdf_intersected.to_crs(self.gdf_traced.crs)

    # Merge traced and intersected flowlines row-wise
    def merge(self):
        self.merged_gdf = gpd.GeoDataFrame(
            pd.concat([self.gdf_traced, self.gdf_intersected], ignore_index=True),
            crs=self.gdf_traced.crs,
        )

    # Drop duplicates based on geometry
    def drop_duplicates(self):
        self.deduped_gdf = self.merged_gdf.drop_duplicates(subset=["geometry"])

    # Remove extra fields not in the original schema
    def clean_fields(self):
        if self.join_fl_layer is None:
            self.original_schema = gpd.read_file(self.join_fl)
        else:
            self.original_schema = gpd.read_file(self.join_fl, layer=self.join_fl_layer)

        original_fields = set(self.original_schema.columns)
        fields_to_remove = [
            col for col in self.deduped_gdf.columns if col not in original_fields
        ]
        if fields_to_remove:
            self.deduped_gdf = self.deduped_gdf.drop(
                columns=fields_to_remove, errors="ignore"
            )

    # Write final cleaned layer to GPKG
    def write_output(self):
        self.deduped_gdf.to_file(
            filename=self.output_reach_gpkg, layer=self.output_layer_name, driver="GPKG"
        )
        self.result = self.deduped_gdf

    def print_summary(self):
        print(
            f"Merged and deduplicated flowlines saved to {self.output_reach_gpkg}/{self.output_layer_name}"
        )


# Reconstruct the disconnected segments, which gives the final output of the flowline network
class ReconstructDisconnectedSegments:
    """
    - Reads the initially extracted network (extract_gdf) and the full join flowline network (join_fl).
    - Finds NextDownIDs (unique_id_nextDown) that do not appear as HydroIDs in the extracted set.
    - Traces upstream from each “disconnected end,” adding any missing reaches until hitting a node that is already in the extracted set or a dead-end.
    - Exports those “missing_reaches” to output_reach_gpkg/missing_reaches_{identifier}.
    - Merges them back into the extracted network, writing the final reconstructed network to output_final_reach_gpkg/output_final_reach_gpkg_{identifier}.

    Returns:
        Path to the final reconstructed feature class GeoPackage.
    """

    def __init__(
        self,
        unique_id: str,
        unique_id_nextDown: str,
        join_fl: str,
        join_fl_layer: Optional[str] = None,
        identifier: Optional[str] = None,
    ):
        self.unique_id = unique_id
        self.unique_id_nextDown = unique_id_nextDown
        self.join_fl = join_fl
        self.join_fl_layer = join_fl_layer
        self.identifier = identifier

        # Get project paths
        self.project_paths = setup_project.only_paths()
        self.output_reach_gpkg = self.project_paths.output_reach_gpkg
        self.output_final_reach_gpkg = self.project_paths.output_final_reach_gpkg

        if identifier:
            self.extracted_layer = f"join_fl_merged_{identifier}"
            self.join_fl_perp_intersected_filtered = (
                f"orig_join_perp_notcross_intersected_filtered_{identifier}"
            )
            self.join_fl_traced_extracted = (
                f"join_fl_traced_extracted_reaches_{identifier}"
            )
        else:
            self.extracted_layer = "join_fl_merged"
            self.join_fl_perp_intersected_filtered = (
                "orig_join_perp_notcross_intersected_filtered"
            )
            self.join_fl_traced_extracted = "join_fl_traced_extracted_reaches"

        self.result = None  # Final reconstructed GeoDataFrame
        self.missing_ids = []  # Missing reaches

        self.run()

    def run(self):
        self.read_inputs()
        self.dtype_alignment()
        self.find_disconnected_segments()
        self.trace_missing_segments()
        self.export_missing_reaches()
        self.merge_and_save_final()
        self.print_summary()

    def read_inputs(self):
        self.extract_gdf = gpd.read_file(
            self.output_reach_gpkg, layer=self.extracted_layer
        )

        if self.join_fl_layer is None:
            self.orig_gdf = gpd.read_file(self.join_fl)
        else:
            self.orig_gdf = gpd.read_file(self.join_fl, layer=self.join_fl_layer)

    @staticmethod
    # Compare-only caster (does NOT modify original Series)
    def _cast_for_compare(src: pd.Series, target_dtype) -> pd.Series:
        if pd.api.types.is_integer_dtype(target_dtype):
            # nullable Int64 handles NA cleanly
            return pd.to_numeric(src, errors="coerce").astype("Int64")
        if pd.api.types.is_string_dtype(target_dtype) or target_dtype == object:
            return src.astype("string")
        # fallback: best-effort copy cast
        return src.astype(target_dtype, copy=True)

    def dtype_alignment(self):
        # --- Decide compare space ---
        uid_dtype = self.extract_gdf[self.unique_id].dtype
        next_dtype = self.extract_gdf[self.unique_id_nextDown].dtype
        same_dtype = uid_dtype == next_dtype

        if same_dtype:
            # Use native dtypes directly (no temp views needed)
            self.hydro_ids = self.extract_gdf[self.unique_id]
            self.nextdown_ids = self.extract_gdf[self.unique_id_nextDown]
            self.orig_ids = self.orig_gdf[self.unique_id]
            self.orig_next_ids = self.orig_gdf[self.unique_id_nextDown]
        else:
            # Use the dtype of extract_gdf[unique_id] as the TARGET everywhere (compare-only views)
            self.hydro_ids = self.extract_gdf[
                self.unique_id
            ]  # keep native; it's already the target dtype
            self.nextdown_ids = self._cast_for_compare(
                self.extract_gdf[self.unique_id_nextDown], uid_dtype
            )
            self.orig_ids = self._cast_for_compare(
                self.orig_gdf[self.unique_id], uid_dtype
            )
            self.orig_next_ids = self._cast_for_compare(
                self.orig_gdf[self.unique_id_nextDown], uid_dtype
            )

    def find_disconnected_segments(self):
        # ---- Disconnected ends ----
        valid_mask = self.nextdown_ids.notna()
        nextdown_valid = self.nextdown_ids[valid_mask]
        self.disconnected_ends = (
            nextdown_valid[~nextdown_valid.isin(self.hydro_ids)].dropna().unique()
        )
        # print(f"Found {len(self.disconnected_ends)} disconnected downstream ends in the 2nd round.")

    # Trace downstream from each disconnected end
    def trace_missing_segments(self):
        # Downstream map & trace in the same compare space (orig frames untouched)
        down_map = dict(zip(self.orig_ids, self.orig_next_ids))
        orig_ids_set = set(self.orig_ids.dropna().unique())

        self.disconnected_segments = []
        for end_id in self.disconnected_ends:
            current_id = end_id
            missing_reaches = []

            while pd.notna(current_id):
                if (current_id not in down_map) and (current_id not in orig_ids_set):
                    break

                if not (self.hydro_ids == current_id).any():
                    missing_reaches.append(current_id)

                # Advance downstream
                current_id = down_map.get(current_id, pd.NA)
                if pd.isna(current_id) or (self.hydro_ids == current_id).any():
                    break

            if missing_reaches:
                self.disconnected_segments.append(missing_reaches)

    # Export Missing reaches
    def export_missing_reaches(self):
        all_missing_ids = [fid for seg in self.disconnected_segments for fid in seg]
        if all_missing_ids:
            missing_mask = self.orig_ids.isin(
                pd.Series(all_missing_ids, dtype=self.orig_ids.dtype)
            )
            self.missing_reaches_gdf = self.orig_gdf.loc[missing_mask].copy()
        else:
            self.missing_reaches_gdf = self.orig_gdf.iloc[0:0].copy()

        if self.identifier:
            missing_layer = f"join_fl_merged_traced_reaches_{self.identifier}"
        else:
            missing_layer = "join_fl_merged_traced_reaches"

        self.missing_reaches_gdf.to_file(
            self.output_reach_gpkg, layer=missing_layer, driver="GPKG", mode="w"
        )
        # print(
        #     f"Exported {len(self.missing_reaches_gdf)} missing reaches to {missing_layer} in the 2nd round."
        # )

    # Merge extracted reaches with missing reaches and finalize
    def merge_and_save_final(self):
        merged_gdf = gpd.GeoDataFrame(
            pd.concat([self.extract_gdf, self.missing_reaches_gdf], ignore_index=True),
            crs=self.extract_gdf.crs,
        )

        merged_gdf = merged_gdf.drop_duplicates(subset=["geometry"])

        if self.identifier:
            self.final_layer = f"join_fl_final_reaches_{self.identifier}"
        else:
            self.final_layer = "join_fl_final_reaches"

        self.result = merged_gdf

        merged_gdf.to_file(
            self.output_final_reach_gpkg,
            layer=self.final_layer,
            driver="GPKG",
            mode="w",
        )

    def print_summary(self):
        print(
            f"Saved reconstructed reaches to {self.output_final_reach_gpkg}/{self.final_layer}"
        )

    # # Find downstream segments not in extracted set
    # def find_disconnected_segments(self):
    #     valid_mask = pd.notnull(self.nextdown_ids)
    #     nextdown_valid = self.nextdown_ids[valid_mask]

    #     disconnected_ends = np.unique(
    #         nextdown_valid[~np.isin(nextdown_valid, self.hydro_ids)]
    #     )
    #     disconnected_segments = []

    #     for end_id in disconnected_ends:
    #         current_id = end_id
    #         missing_reaches = []

    #         while pd.notnull(current_id):
    #             match = self.orig_gdf[self.orig_gdf[self.unique_id] == current_id]
    #             if match.empty:
    #                 break

    #             if current_id not in self.hydro_ids:
    #                 missing_reaches.append(current_id)

    #             # Advance downstream
    #             current_id = match.iloc[0][self.unique_id_nextDown]
    #             if pd.isnull(current_id) or (current_id in self.hydro_ids):
    #                 break

    #         if missing_reaches:
    #             disconnected_segments.append(missing_reaches)

    #     self.missing_ids = [fid for seg in disconnected_segments for fid in seg]

    # # Export missing segments to output_reach_gpkg
    # def export_missing_reaches(self):
    #     if self.missing_ids:
    #         mask = self.orig_gdf[self.unique_id].isin(self.missing_ids)
    #         self.missing_reaches_gdf = self.orig_gdf[mask].copy()
    #     else:
    #         self.missing_reaches_gdf = self.orig_gdf.iloc[0:0].copy()

    #     if self.identifier:
    #         self.merged_missing_layer = (
    #             f"join_fl_merged_traced_reaches_{self.identifier}"
    #         )
    #     else:
    #         self.merged_missing_layer = f"join_fl_merged_traced_reaches"

    #     self.missing_reaches_gdf.to_file(
    #         self.output_reach_gpkg,
    #         layer=self.merged_missing_layer,
    #         driver="GPKG",
    #         mode="w",
    #     )

    # # Merge with original extracted and write final layer
    # def merge_and_save_final(self):
    #     merged_gdf = gpd.GeoDataFrame(
    #         pd.concat([self.extract_gdf, self.missing_reaches_gdf], ignore_index=True),
    #         crs=self.extract_gdf.crs,
    #     )
    #     merged_gdf = merged_gdf.drop_duplicates(subset=["geometry"])

    #     if self.identifier:
    #         self.final_layer = f"join_fl_final_reaches_{self.identifier}"
    #     else:
    #         self.final_layer = f"join_fl_final_reaches"

    #     self.result = merged_gdf

    #     merged_gdf.to_file(
    #         self.output_final_reach_gpkg,
    #         layer=self.final_layer,
    #         driver="GPKG",
    #         mode="w",
    #     )

    # def print_summary(self):
    #     print(
    #         f"Saved reconstructed reaches to {self.output_final_reach_gpkg}/{self.final_layer}"
    #     )
