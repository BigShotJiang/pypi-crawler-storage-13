import geopandas as gpd
from typing import Optional
import os

from .project_initialization import setup_project


class compare_linelength:
    """To see the statitstics of the line lengths between the join and target flowlines.
    This class reads two GeoPackage layers, harmonizes their CRS, computes line lengths

    output_fl: str - Path to the flowline files containing the clipped target flowlines (benchmark).
    extracted_fl: str - Path to the flowline files containing the extracted flowlines with riverjoin framework.

    output_layer: Optional[str] - Layer name for the output, if it is GeoPackage layer.
    extracted_layer: Optional[str] - Layer name for the extracted flowlines, if it is GeoPackage layer.
    """

    def __init__(
        self,
        identifier: Optional[str] = None,
        output_fl: Optional[str] = None,
        extracted_fl: Optional[str] = None,
        output_layer: Optional[str] = None,
        extracted_layer: Optional[str] = None,
    ):
        """
        Initialize the comparator with paths to the join and target GeoPackage layers.
        """
        self.identifier = identifier
        if not output_fl or not extracted_fl:
            self.project_paths = setup_project.only_paths()
            self.output_fl = self.project_paths.output_reach_gpkg
            self.extracted_fl = self.project_paths.output_final_reach_gpkg
        else:
            self.output_fl = output_fl
            self.extracted_fl = extracted_fl

        if output_layer or extracted_layer:
            self.output_layer = output_layer
            self.extracted_layer = extracted_layer
        else:
            self.output_layer = "ClippedFlowlines"
            if self.identifier:
                self.extracted_layer = f"join_fl_final_reaches_{self.identifier}"
            else:
                self.extracted_layer = "join_fl_final_reaches"

        self.output_gdf = None
        self.extracted_gdf = None
        self.output_proj = None
        self.extracted_proj = None
        self.output_lengths = None
        self.extracted_lengths = None

        self.run()

    def pick_utm_epsg(self, gdf: gpd.GeoDataFrame) -> int:
        """Pick the appropriate UTM zone EPSG code from a layer’s centroid."""
        minx, miny, maxx, maxy = gdf.total_bounds
        midx, midy = (minx + maxx) / 2, (miny + maxy) / 2
        zone = int((midx + 180) // 6) + 1
        return 32600 + zone if midy >= 0 else 32700 + zone

    def print_basic_stats(self, name: str, series) -> None:
        """
        Print count, mean, std, min, 25%, 50%, 75%, max for the given numeric Series.
        """
        stats = series.describe().round(2)
        print(f"\n{name} (metres):")
        print(stats)

    def harmonize_crs(self):
        """
        Reproject join and target layers to compatible CRS for length comparison.
        """
        crs1 = self.output_gdf.crs
        crs2 = self.extracted_gdf.crs
        geo1 = crs1.is_geographic
        geo2 = crs2.is_geographic

        if not geo1 and geo2:
            self.output_proj = self.output_gdf
            self.extracted_proj = self.extracted_gdf.to_crs(crs1)
        elif geo1 and not geo2:
            self.output_proj = self.output_gdf.to_crs(crs2)
            self.extracted_proj = self.extracted_gdf
        elif geo1 and geo2:
            utm_epsg = self.pick_utm_epsg(self.extracted_gdf)
            self.output_proj = self.output_gdf.to_crs(epsg=utm_epsg)
            self.extracted_proj = self.extracted_gdf.to_crs(epsg=utm_epsg)
        else:
            self.output_proj = self.output_gdf.to_crs(crs2)
            self.extracted_proj = self.extracted_gdf

    def compare(self):
        """
        Perform the line length comparison.
        - Read data
        - Harmonize CRS
        - Compute lengths
        - Print summary stats
        """
        if not os.path.exists(self.output_fl):
            print(
                f"Output file not found, please complete the extraction process: {self.output_fl}"
            )
            return

        if not os.path.exists(self.extracted_fl):
            print(
                f"Extracted file not found, please complete the extraction process: {self.extracted_fl}"
            )
            return

        try:
            if self.output_layer:
                self.output_gdf = gpd.read_file(self.output_fl, layer=self.output_layer)
            else:
                self.output_gdf = gpd.read_file(self.output_fl)
        except Exception as e:
            print(
                f"Could not read output layer: {self.output_layer} from {self.output_fl}. Error: {e}"
            )
            return

        try:
            if self.extracted_layer:
                self.extracted_gdf = gpd.read_file(
                    self.extracted_fl, layer=self.extracted_layer
                )
            else:
                self.extracted_gdf = gpd.read_file(self.extracted_fl)
        except Exception as e:
            print(
                f"Could not read extracted layer: {self.extracted_layer} from {self.extracted_fl}. Error: {e}"
            )
            return

        self.harmonize_crs()

        self.output_lengths = self.output_proj.geometry.length
        self.extracted_lengths = self.extracted_proj.geometry.length

        self.print_basic_stats("Output line lengths", self.output_lengths)
        self.print_basic_stats("Extracted line lengths", self.extracted_lengths)

    def run(self):
        self.compare()
