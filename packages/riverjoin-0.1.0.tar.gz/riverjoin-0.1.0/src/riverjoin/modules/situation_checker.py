import geopandas as gpd
from typing import Optional

from .project_initialization import setup_project


class check_situation:
    """
    Checks extraction situation for given flowline data.

    - Compares extracted and traced flowlines
    - Identifies if:
        • No intersection (zero extracted)
        • All reaches were already extracted (traced == extracted)
        • More flowlines need to be traced upstream
    Optionally writes final GeoPackage in "all_extracted" case.
    """

    def __init__(
        self,
        identifier: Optional[str] = None,
    ):
        self.identifier = identifier
        self.project_paths = setup_project.only_paths()
        self.extract_stream_gpkg = self.project_paths.output_reach_gpkg

        # If user provided an identifier, use it to create unique layer names
        if identifier:
            self.extract_layer = f"join_fl_extracted_reaches_{identifier}"
        else:
            self.extract_layer = "join_fl_extracted_reaches"

        self.situation: Optional[str] = None

        # populated during run
        self.extract_gdf = None

        self.run()

    def run(self) -> str:
        self.read_data()
        self.compare_counts()
        return self.situation

    def read_data(self):
        self.extract_gdf = (
            gpd.read_file(self.extract_stream_gpkg, layer=self.extract_layer)
            .drop_duplicates(subset="geometry")
            .reset_index(drop=True)
        )

        print(f"Read {len(self.extract_gdf)} extracted flowlines.")

    def compare_counts(self):
        count_extract = len(self.extract_gdf)

        if count_extract == 0:
            self.situation = "no_intersection"
            print(
                "There may be no intersection of join and target flowlines in this region."
            )
            return

        self.situation = "extract_upstream_others"
        print(
            "Upstream and other flowlines still need extraction (Proceed to next steps for all extraction)."
        )
