import os
import geopandas as gpd
from shapely.geometry import LineString
from typing import Optional

from .project_initialization import setup_project


class StreamNetworkExtractor:
    """
    Extracts join flowlines whose midpoints lie within a buffer
    around target flowlines (e.g., SWORD). Writes midpoints, buffer,
    and extracted reaches to GeoPackage layers.
    unique_id = This is the unique identifier for the join flowline which have downstream flow lines dataset as well
    buffer_distance = Distance in meters to buffer the target flowlines
    join_fl_layer = Layer name of the join flowlines (if GPKG or GDB)
    target_fl_layer = Layer name of the target flowlines (if GPKG or GDB)
    identifier = Optional identifier to append to output layer names for clarity
    """

    def __init__(
        self,
        join_fl: str,
        unique_id: str,
        buffer_distance: int = 100,
        join_fl_layer: Optional[str] = None,
        output_clip_layer: Optional[str] = None,
        identifier: Optional[str] = None,
    ):
        self.join_fl = join_fl
        self.join_fl_layer = join_fl_layer
        self.unique_id = unique_id
        self.buffer_distance = buffer_distance
        self.identifier = identifier

        self.output_clip_layer = output_clip_layer or "ClippedFlowlines"

        self.project_paths = setup_project.only_paths()
        self.output_reach_gpkg = self.project_paths.output_reach_gpkg
        self.output_reach_buffer_gpkg = self.project_paths.output_reach_buffer_gpkg
        self.output_point_gpkg = self.project_paths.output_point_gpkg

        # Run the process
        self.run()

    def run(self) -> gpd.GeoDataFrame:
        self.read_data()
        self.ensure_crs()
        self.compute_midpoints()
        self.write_midpoints()
        self.buffer_clipped_flowlines()
        self.write_buffer()
        self.extract_within_buffer()
        self.write_extracted()
        return self.extracted

    def read_data(self):
        if self.join_fl_layer is None:
            self.join_fl_gdf = gpd.read_file(self.join_fl)
        else:
            self.join_fl_gdf = gpd.read_file(self.join_fl, layer=self.join_fl_layer)

        self.clipped_fl_gdf = gpd.read_file(
            self.output_reach_gpkg, layer=self.output_clip_layer
        )

    def ensure_crs(self):
        if not self.clipped_fl_gdf.crs or not self.clipped_fl_gdf.crs.is_projected:
            minx, miny, maxx, maxy = self.clipped_fl_gdf.total_bounds
            midx, midy = (minx + maxx) / 2, (miny + maxy) / 2
            zone = int((midx + 180) // 6) + 1
            epsg_utm = 32600 + zone if midy >= 0 else 32700 + zone
            self.clipped_fl_gdf = self.clipped_fl_gdf.to_crs(epsg=epsg_utm)
            self.join_fl_gdf = self.join_fl_gdf.to_crs(epsg=epsg_utm)
            print(f"Reprojected both layers to EPSG:{epsg_utm}")
        else:
            self.join_fl_gdf = self.join_fl_gdf.to_crs(self.clipped_fl_gdf.crs)
            print(
                f"Reprojected join_fl to match clipped_fl CRS: {self.join_fl_gdf.crs}"
            )

    def compute_midpoints(self):
        def midpoint_of_line(geom):
            if geom.geom_type == "MultiLineString":
                line = list(geom.geoms)[0]
            else:
                line = geom
            return line.interpolate(0.5, normalized=True)

        midpoints = self.join_fl_gdf.geometry.apply(midpoint_of_line)
        self.midpoints_gdf = gpd.GeoDataFrame(
            {
                self.unique_id: self.join_fl_gdf[self.unique_id],
                "orig_index": self.join_fl_gdf.index,
            },
            geometry=midpoints,
            crs=self.join_fl_gdf.crs,
        )
        print(f"Computed {len(self.midpoints_gdf)} midpoints.")

    def write_midpoints(self):
        mid_layer = (
            f"join_fl_midpoints_{self.identifier}"
            if self.identifier
            else "join_fl_midpoints"
        )
        self.midpoints_gdf.to_file(
            self.output_point_gpkg, layer=mid_layer, driver="GPKG", mode="w"
        )
        print(f"Midpoints saved to {self.output_point_gpkg}/{mid_layer}")

    def buffer_clipped_flowlines(self):
        self.clipped_fl_gdf = self.clipped_fl_gdf[
            ~self.clipped_fl_gdf.geometry.is_empty
            & self.clipped_fl_gdf.geometry.notnull()
            & self.clipped_fl_gdf.geometry.is_valid
        ].copy()

        self.buffered = self.clipped_fl_gdf.copy()
        self.buffered["geometry"] = self.buffered.geometry.buffer(self.buffer_distance)
        print(f"Buffered {len(self.buffered)} clipped flowlines.")

    def write_buffer(self):
        buf_layer = f"clipped_fl_buffer_{int(self.buffer_distance)}m_{self.identifier}"
        self.buffered.to_file(
            self.output_reach_buffer_gpkg, layer=buf_layer, driver="GPKG", mode="w"
        )
        print(f"Buffer saved to {self.output_reach_buffer_gpkg}/{buf_layer}")

    def extract_within_buffer(self):
        selected = gpd.sjoin(
            self.midpoints_gdf, self.buffered, how="inner", predicate="within"
        )
        indices = selected["orig_index"].unique()
        self.extracted = self.join_fl_gdf.loc[indices].copy()
        print(f"Extracted {len(self.extracted)} flowlines within buffer.")

    def write_extracted(self):
        extracted_layer = (
            f"join_fl_extracted_reaches_{self.identifier}"
            if self.identifier
            else "join_fl_extracted_reaches"
        )
        self.extracted.to_file(
            self.output_reach_gpkg, layer=extracted_layer, driver="GPKG", mode="w"
        )
        print(
            f"Extracted flowlines saved to {self.output_reach_gpkg}/{extracted_layer}"
        )
