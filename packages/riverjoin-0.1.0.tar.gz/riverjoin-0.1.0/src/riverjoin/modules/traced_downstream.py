import geopandas as gpd
import pandas as pd
import numpy as np
import fiona
from typing import Optional

from .project_initialization import setup_project


class traced_downstream:
    """
    1) Reads the initially extracted network and the full join flowline network (join_fl).
    2) Finds NextDownIDs (unique_id_nextDown) that do not appear as HydroIDs in the extracted set.
    3) Traces upstream from each “disconnected end,” adding any missing reaches until hitting a node that is already in the extracted set or a dead-end.
    4) Exports those “missing_reaches” to output_reach_gpkg/missing_reaches_{identifier}.
    5) Merges them back into the extracted network, writing the final reconstructed network to output_reach_gpkg/output_final_reach_gpkg_{identifier}.
    Returns:
        Path to the final reconstructed feature class GeoPackage.
    """

    def __init__(
        self,
        unique_id: str,
        unique_id_nextDown: str,
        join_fl: str,
        join_fl_layer: Optional[str] = None,
        identifier: Optional[str] = None,
    ):
        self.unique_id = unique_id
        self.unique_id_nextDown = unique_id_nextDown
        if identifier:
            self.extracted_layer = f"join_fl_extracted_reaches_{identifier}"
        else:
            self.extracted_layer = "join_fl_extracted_reaches"

        self.join_fl = join_fl
        self.join_fl_layer = join_fl_layer
        self.identifier = identifier

        self.project_paths = setup_project.only_paths()
        self.output_reach_gpkg = self.project_paths.output_reach_gpkg

        # These will be populated during run()
        self.extract_gdf = None
        self.orig_gdf = None
        self.missing_reaches_gdf = None
        self.merged_gdf = None

        # Run the process
        self.run()

    def run(self) -> gpd.GeoDataFrame:
        self.read_data()
        self.dtype_unify()
        self.find_disconnected()
        self.trace_missing_reaches()
        self.export_missing()
        self.merge_and_write()
        return self.merged_gdf

    def read_data(self):
        self.extract_gdf = gpd.read_file(
            self.output_reach_gpkg, layer=self.extracted_layer
        )
        if self.join_fl_layer is None:
            self.orig_gdf = gpd.read_file(self.join_fl)
        else:
            self.orig_gdf = gpd.read_file(self.join_fl, layer=self.join_fl_layer)

    @staticmethod
    # Compare-only caster (does NOT modify original Series)
    def _cast_for_compare(src: pd.Series, target_dtype) -> pd.Series:
        if pd.api.types.is_integer_dtype(target_dtype):
            # nullable Int64 handles NA cleanly
            return pd.to_numeric(src, errors="coerce").astype("Int64")
        if pd.api.types.is_string_dtype(target_dtype) or target_dtype == object:
            return src.astype("string")
        # fallback: best-effort copy cast
        return src.astype(target_dtype, copy=True)

    def dtype_unify(self):
        # --- Decide compare space ---
        uid_dtype = self.extract_gdf[self.unique_id].dtype
        next_dtype = self.extract_gdf[self.unique_id_nextDown].dtype
        same_dtype = uid_dtype == next_dtype

        if same_dtype:
            # Use native dtypes directly (no temp views needed)
            self.hydro_ids = self.extract_gdf[self.unique_id]
            self.nextdown_ids = self.extract_gdf[self.unique_id_nextDown]
            self.orig_ids = self.orig_gdf[self.unique_id]
            self.orig_next_ids = self.orig_gdf[self.unique_id_nextDown]
        else:
            # Use the dtype of extract_gdf[unique_id] as the TARGET everywhere (compare-only views)
            self.hydro_ids = self.extract_gdf[
                self.unique_id
            ]  # keep native; it's already the target dtype
            self.nextdown_ids = self._cast_for_compare(
                self.extract_gdf[self.unique_id_nextDown], uid_dtype
            )
            self.orig_ids = self._cast_for_compare(
                self.orig_gdf[self.unique_id], uid_dtype
            )
            self.orig_next_ids = self._cast_for_compare(
                self.orig_gdf[self.unique_id_nextDown], uid_dtype
            )

    def find_disconnected(self):
        # ---- Disconnected ends ----
        valid_mask = self.nextdown_ids.notna()
        nextdown_valid = self.nextdown_ids[valid_mask]
        self.disconnected_ends = (
            nextdown_valid[~nextdown_valid.isin(self.hydro_ids)].dropna().unique()
        )
        print(f"Found {len(self.disconnected_ends)} disconnected downstream ends.")

    # Trace downstream from each disconnected end
    def trace_missing_reaches(self):
        # Downstream map & trace in the same compare space (orig frames untouched)
        down_map = dict(zip(self.orig_ids, self.orig_next_ids))
        orig_ids_set = set(self.orig_ids.dropna().unique())

        self.disconnected_segments = []
        for end_id in self.disconnected_ends:
            current_id = end_id
            missing_reaches = []

            while pd.notna(current_id):
                if (current_id not in down_map) and (current_id not in orig_ids_set):
                    break

                if not (self.hydro_ids == current_id).any():
                    missing_reaches.append(current_id)

                # Advance downstream
                current_id = down_map.get(current_id, pd.NA)
                if pd.isna(current_id) or (self.hydro_ids == current_id).any():
                    break

            if missing_reaches:
                self.disconnected_segments.append(missing_reaches)

        # hydro_ids = set(self.extract_gdf[self.unique_id])
        # self.disconnected_segments = []

        # for end_id in self.disconnected_ends:
        #     current_id = end_id
        #     missing_reaches = []

        #     while pd.notnull(current_id):
        #         match = self.orig_gdf[self.orig_gdf[self.unique_id] == current_id]
        #         if match.empty:
        #             break

        #         if current_id not in hydro_ids:
        #             missing_reaches.append(current_id)

        #         # Advance downstream
        #         current_id = match.iloc[0][self.unique_id_nextDown]
        #         if pd.isnull(current_id) or (current_id in hydro_ids):
        #             break

        #     if missing_reaches:
        #         self.disconnected_segments.append(missing_reaches)

    # Export Missing reaches
    def export_missing(self):
        all_missing_ids = [fid for seg in self.disconnected_segments for fid in seg]
        if all_missing_ids:
            missing_mask = self.orig_ids.isin(
                pd.Series(all_missing_ids, dtype=self.orig_ids.dtype)
            )
            self.missing_reaches_gdf = self.orig_gdf.loc[missing_mask].copy()
        else:
            self.missing_reaches_gdf = self.orig_gdf.iloc[0:0].copy()

        # all_missing_ids = [fid for seg in self.disconnected_segments for fid in seg]
        # if all_missing_ids:
        #     missing_mask = self.orig_gdf[self.unique_id].isin(all_missing_ids)
        #     self.missing_reaches_gdf = self.orig_gdf[missing_mask].copy()
        # else:
        #     self.missing_reaches_gdf = self.orig_gdf.iloc[0:0].copy()

        if self.identifier:
            missing_layer = f"join_fl_traced_reaches_{self.identifier}"
        else:
            missing_layer = "join_fl_traced_reaches"

        self.missing_reaches_gdf.to_file(
            self.output_reach_gpkg, layer=missing_layer, driver="GPKG", mode="w"
        )
        print(
            f"Exported {len(self.missing_reaches_gdf)} missing reaches to {missing_layer}."
        )

    # Merge extracted reaches with missing reaches and finalize
    def merge_and_write(self):
        self.merged_gdf = gpd.GeoDataFrame(
            pd.concat([self.extract_gdf, self.missing_reaches_gdf], ignore_index=True),
            crs=self.extract_gdf.crs,
        )

        if self.identifier:
            merged_layer = f"join_fl_traced_extracted_reaches_{self.identifier}"
        else:
            merged_layer = "join_fl_traced_extracted_reaches"

        # If that layer already exists, remove it
        existing_layers = fiona.listlayers(self.output_reach_gpkg)
        if merged_layer in existing_layers:
            fiona.remove(self.output_reach_gpkg, layer=merged_layer)
            print(f"Removed existing layer '{merged_layer}' from GeoPackage.")

        self.merged_gdf.to_file(
            self.output_reach_gpkg, layer=merged_layer, driver="GPKG", mode="w"
        )
        print(f"Saved reconstructed reaches to {self.output_reach_gpkg}/{merged_layer}")

    # def find_disconnected(self):
    #     hydro_ids = self.extract_gdf[self.unique_id].to_numpy()
    #     nextdown_ids = self.extract_gdf[self.unique_id_nextDown].to_numpy()
    #     valid_mask = pd.notnull(nextdown_ids)
    #     nextdown_valid = nextdown_ids[valid_mask]
    #     self.disconnected_ends = np.unique(
    #         nextdown_valid[~np.isin(nextdown_valid, hydro_ids)]
    #     )
    #     print(f"Found {len(self.disconnected_ends)} disconnected downstream ends.")

    # # Trace downstream from each disconnected end
    # def trace_missing_reaches(self):
    #     hydro_ids = set(self.extract_gdf[self.unique_id])
    #     self.disconnected_segments = []

    #     for end_id in self.disconnected_ends:
    #         current_id = end_id
    #         missing_reaches = []

    #         while pd.notnull(current_id):
    #             match = self.orig_gdf[self.orig_gdf[self.unique_id] == current_id]
    #             if match.empty:
    #                 break

    #             if current_id not in hydro_ids:
    #                 missing_reaches.append(current_id)

    #             # Advance downstream
    #             current_id = match.iloc[0][self.unique_id_nextDown]
    #             if pd.isnull(current_id) or (current_id in hydro_ids):
    #                 break

    #         if missing_reaches:
    #             self.disconnected_segments.append(missing_reaches)

    # # Export Missing reaches
    # def export_missing(self):
    #     all_missing_ids = [fid for seg in self.disconnected_segments for fid in seg]
    #     if all_missing_ids:
    #         missing_mask = self.orig_gdf[self.unique_id].isin(all_missing_ids)
    #         self.missing_reaches_gdf = self.orig_gdf[missing_mask].copy()
    #     else:
    #         self.missing_reaches_gdf = self.orig_gdf.iloc[0:0].copy()

    #     if self.identifier:
    #         missing_layer = f"join_fl_traced_reaches_{self.identifier}"
    #     else:
    #         missing_layer = "join_fl_traced_reaches"

    #     self.missing_reaches_gdf.to_file(
    #         self.output_reach_gpkg, layer=missing_layer, driver="GPKG", mode="w"
    #     )
    #     print(
    #         f"Exported {len(self.missing_reaches_gdf)} missing reaches to {missing_layer}."
    #     )

    # # Merge extracted reaches with missing reaches and finalize
    # def merge_and_write(self):
    #     self.merged_gdf = gpd.GeoDataFrame(
    #         pd.concat([self.extract_gdf, self.missing_reaches_gdf], ignore_index=True),
    #         crs=self.extract_gdf.crs,
    #     )
    #     if self.identifier:
    #         merged_layer = f"join_fl_traced_extracted_reaches_{self.identifier}"
    #     else:
    #         merged_layer = "join_fl_traced_extracted_reaches"

    #     # If that layer already exists, remove it
    #     existing_layers = fiona.listlayers(self.output_reach_gpkg)
    #     if merged_layer in existing_layers:
    #         fiona.remove(self.output_reach_gpkg, layer=merged_layer)
    #         print(f"Removed existing layer '{merged_layer}' from GeoPackage.")

    #     self.merged_gdf.to_file(
    #         self.output_reach_gpkg, layer=merged_layer, driver="GPKG", mode="w"
    #     )
    #     print(f"Saved reconstructed reaches to {self.output_reach_gpkg}/{merged_layer}")
