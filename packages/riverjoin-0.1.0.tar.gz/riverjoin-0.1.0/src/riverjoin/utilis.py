import geopandas as gpd
from typing import Optional
from pathlib import Path


class FlowlineFieldViewer:
    """
    Utility class to inspect available fields in the join flowline dataset.
    Works with both GeoPackage (.gpkg) and Shapefile (.shp). For geopackages, user needs to specify the layer name.
    """

    def __init__(
        self,
        flowline: str,
        layer_name: Optional[str] = None,
        show_types: bool = True,
        limit: Optional[int] = None,
    ):
        """
        Parameters
        ----------
        boundary_path : str
            Path to the GeoPackage or Shapefile.
        layer_name : Optional[str]
            Layer name for GeoPackage; ignored if file is a Shapefile.
        show_types : bool, default=True
            If True, print column names with data types.
        limit : Optional[int]
            Number of sample rows to preview.
        """
        self.flowline = flowline
        self.layer_name = layer_name
        self.show_types = show_types
        self.limit = limit

        self.gdf = self._read_data()
        self.print_summary()

    def _read_data(self):
        file_ext = Path(self.flowline).suffix.lower()

        try:
            if file_ext == ".gpkg":
                if self.layer_name:
                    gdf = gpd.read_file(self.flowline, layer=self.layer_name)
                else:
                    # Read the first available layer automatically
                    layers = gpd.io.file.fiona.listlayers(self.flowline)
                    first_layer = layers[0]
                    print(
                        f" No layer specified. Using first available layer: '{first_layer}'"
                    )
                    gdf = gpd.read_file(self.flowline, layer=first_layer)
            elif file_ext == ".shp":
                gdf = gpd.read_file(self.flowline)
            else:
                raise ValueError(f"Unsupported file type: {file_ext}")
        except Exception as e:
            raise RuntimeError(
                f"Failed to read {self.layer_name or 'file'} from {self.flowline}: {e}"
            )
        return gdf

    def print_summary(self):
        print("=" * 60)
        print(f"Fields for: {self.layer_name or Path(self.boundary_path).stem}")
        print(f"Source: {self.boundary_path}")
        print("-" * 60)
        if self.show_types:
            for col, dtype in self.gdf.dtypes.items():
                print(f"{col:<30} {str(dtype):>15}")
        else:
            print(", ".join(self.gdf.columns))
        print("=" * 60)
        if self.limit:
            print("\n Sample rows:")
            print(self.gdf.head(self.limit))
