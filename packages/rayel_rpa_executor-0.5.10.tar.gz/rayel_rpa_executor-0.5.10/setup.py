from setuptools import find_packages, setup  # pyright: ignore[reportMissingModuleSource]

setup(
    name="rayel-rpa-executor",
    version="0.5.10",  # 由 publish.sh 自动递增
    packages=find_packages(),
    install_requires=[
        "pydantic>=2.7.4",
        "python-dotenv>=1.0.1",
        "aiohttp>=3.10.9",
        "protobuf>=5.27.2",
        "grpcio>=1.66.2",
        "GitPython>=3.1.0",
        "playwright>=1.55.0"
    ],
    extras_require={
        "dev": [
            "ruff>=0.3.0",
            "grpcio-tools>=1.66.2",
        ],
    },
    python_requires=">=3.12",
    description="Distributed task scheduler and RPA executor",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
)
