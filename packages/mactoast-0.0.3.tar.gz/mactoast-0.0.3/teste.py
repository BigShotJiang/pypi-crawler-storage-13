from mactoast import toast, WindowLevel

"""Mactoast - Simple toast notifications for macOS."""


toast('Hello, World!', window_level=WindowLevel.NORMAL)