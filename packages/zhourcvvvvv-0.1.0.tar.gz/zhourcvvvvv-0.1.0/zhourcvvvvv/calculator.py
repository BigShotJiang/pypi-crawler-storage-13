def add(a, b):
    """返回两个数的和"""
    return a + b

def multiply(a, b):
    """返回两个数的乘积"""
    return a * b

def factorial(n):
    """返回一个数的阶乘"""
    if n == 0:
        return 1
    return n * factorial(n-1)

def is_prime(n):
    """检查一个数是否为质数"""
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True
