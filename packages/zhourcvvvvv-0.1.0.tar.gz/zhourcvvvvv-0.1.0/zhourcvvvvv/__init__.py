"""一个简单的数学计算包"""
from .calculator import add, multiply, factorial

__version__ = "0.1.0"
__all__ = ['add', 'multiply', 'factorial']
