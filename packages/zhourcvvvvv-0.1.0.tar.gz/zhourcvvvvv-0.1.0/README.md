# Simple Math Package

一个简单的数学计算包示例，用于演示PyPI包发布。

## 功能

- 加法运算
- 乘法运算  
- 阶乘计算

## 安装

```bash
pip install zhourcvvvvv
