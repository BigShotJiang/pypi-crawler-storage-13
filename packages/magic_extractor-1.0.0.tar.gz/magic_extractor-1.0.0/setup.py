from setuptools import setup, find_packages

setup(
    name="magic-extractor",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "requests",
        "beautifulsoup4",
        "pyfiglet",
        "tqdm",
        "termcolor"
    ],
    entry_points={
        "console_scripts": [
            "magic-extractor=magic_extractor.main:main"
        ]
    },
    author="Elm4g3k",
    description="Discover Your Target Automatically",
    python_requires=">=3.8"
)
