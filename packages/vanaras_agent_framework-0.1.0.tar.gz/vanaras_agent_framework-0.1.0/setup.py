from setuptools import setup, find_packages

setup(
    name="vanaras-agent-framework",
    version="0.1.0",
    description="A lightweight, local-first agent framework for programmatic code execution and orchestration.",
    author="Vanaras AI",
    packages=find_packages(),
    install_requires=[
        "requests>=2.31.0",
        "Flask>=3.0.0",
        "langchain-community>=0.0.10",
        "langchain-core>=0.1.10",
        "wikipedia>=1.4.0"
    ],
    python_requires=">=3.8",
)
