# Vanaras Agent Framework 🐒

A lightweight, local-first agent framework designed for programmatic code execution, multi-agent orchestration, and seamless tool integration.

## Features

-   **Autonomous Agents**: Create agents with specific Roles, Goals, and Backstories.
-   **Orchestration**: Manage agents with `Crew` in Sequential or Hierarchical processes.
-   **Tooling**: Built-in safe file operations and full support for the **LangChain** ecosystem.
-   **Observability**: Real-time dashboard to watch your agents think and act.
-   **Human-in-the-Loop**: Optional user approval before agents execute sensitive actions.
-   **Local First**: Designed to work with local LLMs (via Ollama) for privacy and speed.

## Installation

```bash
pip install vanaras-agent-framework
```

## Quick Start

```python
from vanaras.core.agent import Agent
from vanaras.core.task import Task
from vanaras.core.crew import Crew

# 1. Create an Agent
researcher = Agent(
    role="Researcher",
    goal="Find interesting facts",
    backstory="You are a curious researcher.",
    verbose=True
)

# 2. Define a Task
task = Task(
    description="What is the capital of France?",
    expected_output="The name of the city.",
    agent=researcher
)

# 3. Run the Crew
crew = Crew(
    agents=[researcher],
    tasks=[task]
)

result = crew.kickoff()
print(result)
```

## Architecture

Vanaras follows a modular architecture:
-   **Agents**: The "brains" that use LLMs and Tools.
-   **Tasks**: Units of work assigned to agents.
-   **Crew**: The engine that manages the workflow.
-   **Tools**: Capabilities (File I/O, Search, etc.).

## License

MIT
