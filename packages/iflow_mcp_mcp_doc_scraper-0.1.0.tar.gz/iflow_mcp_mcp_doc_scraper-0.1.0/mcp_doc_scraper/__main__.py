from mcp_doc_scraper import main
import asyncio

asyncio.run(main())
