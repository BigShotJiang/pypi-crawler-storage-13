"""rclone-commander - A dual-pane TUI file manager for rclone.

Copyright (C) 2025 Miklos Mukka Szel <contact@miklos-szel.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

__version__ = "0.1.2"
__author__ = "Miklos Mukka Szel"
__email__ = "contact@miklos-szel.com"
