from scrapemm import retrieve
import asyncio

if __name__ == "__main__":
    url = "https://www.youtube.com/shorts/cE0zgN6pYOc"
    result = asyncio.run(retrieve(url))
    print(result)
