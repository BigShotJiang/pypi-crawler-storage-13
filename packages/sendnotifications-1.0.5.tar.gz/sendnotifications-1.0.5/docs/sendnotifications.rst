sendnotifications package
=========================

Submodules
----------

sendnotifications.sendonemail module
------------------------------------

.. automodule:: sendnotifications.sendonemail
   :members:
   :undoc-members:
   :show-inheritance:

sendnotifications.sendonteams module
------------------------------------

.. automodule:: sendnotifications.sendonteams
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: sendnotifications
   :members:
   :undoc-members:
   :show-inheritance:
