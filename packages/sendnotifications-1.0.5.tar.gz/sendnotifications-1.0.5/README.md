## sendnotifications

sendnotifications is a simple package that enables users to send notification to MSTeams or Email. The package is built using `urllib3` for distribution.

## Prereqiustes libraries
- urllib3
- http.client
- json
- logging
- traceback

## Features

- Send notification on channel w/ adaptive card using NotifyMsTeams.
- Send notification on email using prefix of team name on attributes using NotifyEmail.


## Installation

This package will be made available as lambda layer in aws account
for email grant sns:publish, sns:createtopic on IAM Role

## Usage
Usage:

##  Core NotifyEmail Class.
    Usage:

        from sendnotifications.sendonemail import NotifyEmail
        message = ""
        NotifyEmail(title="Title - Testing card",message_body=messages,recipeint="vthelu")

        Parameters:
             title: str - Subject
             messages:str - Stack of messages
             recipient: str - Recepient Team Identifier

       Send Messages to subscribed email address"""

##  Core NotifyMSTeam Class.
    Usage:

          from sendnotifications.sendonteams import NotifyMsTeams
     messages = []
     messages.append("Test")
     messages.append("Test1")
     NotifyMsTeams(channel="homes-analytics-alerts",messages=messages,header="Test Title",messagetype=1,color="warn")

     Parameters:
          channel: str - Channel name
          messages:str - Stack of messages
          header_text: str - Title / Subject
          messagetype:str - 0 - Direct Mesage , 1 - Adapative Card (default)
          color:str = "good" - Alert Type , good (default), warn, attn

         e.g "dba-only",messages,"Test Title",1,"warn"
             "dba-only",messages,"Test Title"

    Send Messages to webhook url"""

```python
from sendnotifications import NotifyMsTeams, NotifyEmail

# Initialize the predictor

def testemail:
    messages = []
    messages.append("Test")
    messages.append("Test1")
    notifye = NotifyEmail("Title - Testing card",messages,"vthelu")
    notifyt = NotifyMsTeams("homes-analytics-alerts",messages,"Test Title",1,"warn")
    print ("notifyt response:{}, notifye response{}".format(notifyt, notifye))

```