import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="mongodb_ai_widgets",
    version="0.1.1",
    author="Thibaut Gourdel",
    author_email="thibaut.gourdel@mongodb.com",
    description="AI Widgets for exploring and testing MongoDB AI features",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/tgourdel/mongodb-ai-widgets",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
    install_requires=[
        "anywidget",
        "traitlets",
        "langchain>=1.0",
        "langchain-mongodb",
        "langchain-core>=1.0",
        "langchain-community"
    ],
    include_package_data=True,
    package_data={
        "mongodb_ai_widgets": ["index.js", "index.css"],
    },
)
