# mongodb_ai_playground/__init__.py

from .rag_widget import MongoDBRAGWidget

__all__ = ["MongoDBRAGWidget"]
