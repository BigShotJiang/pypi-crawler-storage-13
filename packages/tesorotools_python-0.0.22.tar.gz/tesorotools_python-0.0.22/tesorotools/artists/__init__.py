import matplotlib.style

from tesorotools.artists.barh_plot import HorizontalBarChart
from tesorotools.utils.config import TemplateLoader

from ..utils.globals import STYLE_SHEET

matplotlib.style.use(STYLE_SHEET)
TemplateLoader.add_constructor("!barh", HorizontalBarChart.from_yaml)
