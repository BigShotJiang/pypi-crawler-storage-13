from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="featheros",
    version="0.1.15",
    author="FeatherOS Team",
    description="A Python framework for building full-stack web applications with minimal code",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/featheros/featheros",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "Flask>=3.0.0",
        "Click>=8.1.0",
        "SQLAlchemy>=2.0.0",
        "Jinja2>=3.1.0",
        "Werkzeug>=3.0.0",
        "Rich>=13.0.0",
        "PyYAML>=6.0.0",
        "Requests>=2.31.0",
        "packaging>=23.0",
        "bleach>=6.0.0",
    ],
    entry_points={
        "console_scripts": [
            "feather=feather.cli:cli",
        ],
    },
    include_package_data=True,
    package_data={
        "feather": ["templates/*.html", "templates/components/*.html"],
    },
)
