# __init__.py for the argus_ai package

__version__ = "0.0.1"