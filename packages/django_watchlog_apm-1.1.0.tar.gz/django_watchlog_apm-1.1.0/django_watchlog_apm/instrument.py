import os
import dns.resolver
import logging
from datetime import datetime

import requests
from google.protobuf.json_format import MessageToDict
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider, sampling
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SpanExporter, SpanExportResult
from opentelemetry.exporter.otlp.proto.common.trace_encoder import encode_spans
from opentelemetry.instrumentation.django import DjangoInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor
from opentelemetry.sdk.resources import Resource

# Optional PostgreSQL instrumentation
try:
    from opentelemetry.instrumentation.psycopg2 import Psycopg2Instrumentor
    PSYCOPG2_AVAILABLE = True
except ImportError:
    PSYCOPG2_AVAILABLE = False
    Psycopg2Instrumentor = None

# ---- Logging setup ----
# Only configure logging if not already configured
if not logging.getLogger().handlers:
    logging.basicConfig(
        level=logging.WARNING,  # Default to WARNING to reduce noise
        format="%(asctime)s %(levelname)s %(name)s: %(message)s"
    )
logger = logging.getLogger("django_watchlog_apm")


def _is_running_in_k8s() -> bool:
    if os.path.exists('/var/run/secrets/kubernetes.io/serviceaccount/token'):
        return True
    try:
        with open('/proc/1/cgroup') as f:
            if 'kubepods' in f.read():
                return True
    except Exception:
        pass
    try:
        dns.resolver.resolve('kubernetes.default.svc.cluster.local', 'A')
        return True
    except Exception:
        return False


def _detect_endpoint(default: str) -> str:
    try:
        if _is_running_in_k8s():
            k8s_url = 'http://watchlog-python-agent.monitoring.svc.cluster.local:3774/apm'
            return k8s_url
    except Exception:
        pass  # Fallback to default on any error
    return default


class OTLPJsonSpanExporter(SpanExporter):
    def __init__(self, endpoint: str, headers: dict, timeout: float = 10.0):
        self._endpoint = endpoint
        self._headers = dict(headers or {})
        self._headers['Content-Type'] = 'application/json'
        self._timeout = timeout

    def export(self, spans) -> SpanExportResult:
        try:
            proto_req = encode_spans(spans)
            body = MessageToDict(proto_req, preserving_proto_field_name=False)

            # normalize status codes
            STATUS_CODE_MAP = {
                "STATUS_CODE_UNSET": 0,
                "STATUS_CODE_OK": 1,
                "STATUS_CODE_ERROR": 2,
            }
            for rs in body.get("resourceSpans", []):
                if "scopeSpans" in rs:
                    rs["instrumentationLibrarySpans"] = rs.pop("scopeSpans")
                for ils in rs.get("instrumentationLibrarySpans", []):
                    for span in ils.get("spans", []):
                        code = span.get("status", {}).get("code")
                        if isinstance(code, str) and code in STATUS_CODE_MAP:
                            span["status"]["code"] = STATUS_CODE_MAP[code]

            resp = requests.post(
                self._endpoint,
                json=body,
                headers=self._headers,
                timeout=self._timeout
            )
            resp.raise_for_status()
            return SpanExportResult.SUCCESS

        except Exception as e:
            # Silently swallow export errors to prevent application crashes
            # Errors are logged at WARNING level only if logging is configured
            return SpanExportResult.SUCCESS

    def shutdown(self):
        pass  # No-op to prevent errors

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True


def instrument_django(
    *,
    service_name: str,
    otlp_endpoint: str = 'http://localhost:3774/apm',
    headers: dict = None,
    batch_max_size: int = 200,
    batch_delay_ms: int = 5000,
    sample_rate: float = 1.0,
    send_error_spans: bool = False,
    error_tps: int = None,
    slow_threshold_ms: int = 0,
    export_timeout: float = 10.0,
):
    """
    Initialize Watchlog APM for Django — must be called before Django starts serving.
    """
    headers = headers or {}
    rate = min(sample_rate, 0.3)
    base = _detect_endpoint(otlp_endpoint)

    # 1) TracerProvider + sampler
    try:
        resource = Resource.create({"service.name": service_name})
        provider = TracerProvider(
            resource=resource,
            sampler=sampling.ParentBased(sampling.TraceIdRatioBased(rate))
        )
        trace.set_tracer_provider(provider)
    except Exception:
        return  # Exit early if provider creation fails (silently)

    # 2) Final exporter URL
    url = f"{base}/{service_name}/v1/traces"

    # 3) JSON exporter
    try:
        exporter = OTLPJsonSpanExporter(url, headers, timeout=export_timeout)
    except Exception:
        return  # Exit early if exporter creation fails (silently)

    # 4) Filtering setup
    last_sec = int(datetime.utcnow().timestamp())
    err_count = 0
    def _filter(span):
        nonlocal last_sec, err_count
        now = int(datetime.utcnow().timestamp())
        if now != last_sec:
            last_sec, err_count = now, 0
        if send_error_spans and span.status.status_code.value != 0:
            if error_tps is None or err_count < error_tps:
                err_count += 1
                return True
            return False
        if slow_threshold_ms > 0 and span.start_time and span.end_time:
            dur_ms = (span.end_time - span.start_time) / 1e6
            if dur_ms > slow_threshold_ms:
                return True
        if rate < 1.0:
            from random import random
            return random() < rate
        return True

    # 5) BatchSpanProcessor (with optional filtering)
    try:
        bsp = BatchSpanProcessor(exporter,
                                 max_export_batch_size=batch_max_size,
                                 schedule_delay_millis=batch_delay_ms)
        if send_error_spans or slow_threshold_ms > 0 or rate < 1.0:
            class _FilteringProcessor(BatchSpanProcessor):
                def __init__(self, exporter, fn, **kw):
                    super().__init__(exporter, **kw)
                    self._fn = fn
                def on_end(self, span):
                    try:
                        if self._fn(span):
                            super().on_end(span)
                    except Exception:
                        # Silently ignore filter errors to prevent crashes
                        pass
            proc = _FilteringProcessor(exporter, _filter,
                                       max_export_batch_size=batch_max_size,
                                       schedule_delay_millis=batch_delay_ms)
        else:
            proc = bsp
        provider.add_span_processor(proc)
    except Exception:
        return  # Exit early if processor setup fails (silently)

    # 6) Auto-instrument Django, Requests, and PostgreSQL (exclude exporter URL)
    try:
        DjangoInstrumentor().instrument(tracer_provider=provider)
    except Exception:
        # Continue even if Django instrumentation fails (silently)
        pass
    
    try:
        RequestsInstrumentor().instrument(
            tracer_provider=provider,
            exclude_urls=[base]
        )
    except Exception:
        # Continue even if Requests instrumentation fails (silently)
        pass
    
    # Instrument PostgreSQL/psycopg2 for database query tracing (optional)
    if PSYCOPG2_AVAILABLE and Psycopg2Instrumentor:
        try:
            Psycopg2Instrumentor().instrument(tracer_provider=provider)
            # Log success at INFO level if logging is configured
            if logger.isEnabledFor(logging.INFO):
                logger.info("[instrument_django] PostgreSQL/psycopg2 instrumentation enabled")
        except Exception as e:
            # Log error but don't crash
            if logger.isEnabledFor(logging.WARNING):
                logger.warning(f"[instrument_django] Failed to instrument PostgreSQL: {e}")
