import json
from importlib.resources import files  # Python 3.7+ 标准库
# 若需兼容 Python <3.7，可安装第三方库：pip install importlib-resources，导入方式相同

# 导入你的包的子模块（确保 schema 是包，含 __init__.py）
from blues_lib.schema import templates  # 对应 templates 目录

class SchemaTemplate:
  @classmethod
  def get(cls, file: str, sub_dir: str = '') -> dict:
    # 处理文件名（确保后缀为 .json）
    json_file = file if file.endswith('.json') else f"{file}.json"
    
    # 1. 定位包内 templates 目录（基于包结构，而非运行目录）
    templates_dir = files(templates)
    
    # 2. 拼接文件路径（支持子目录）
    if sub_dir.strip():
      file_path = templates_dir.joinpath(sub_dir, json_file)
    else:
      file_path = templates_dir.joinpath(json_file)
    
    # 3. 读取文件内容（用 read_text() 兼容所有安装场景）
    try:
      # 直接读取 JSON 字符串并解析
      json_content = file_path.read_text(encoding='utf-8')
      return json.loads(json_content)
    except FileNotFoundError:
      raise FileNotFoundError(f"JSON 文件未找到：{file_path}")
    except json.JSONDecodeError:
      raise ValueError(f"JSON 文件格式错误：{file_path}")