import jsonschema
from blues_lib.schema.SchemaTemplate import SchemaTemplate

class SchemaValidator:
  """
  Class for validating metadata against JSON Schema templates
  """
  @classmethod
  def validate(cls, instance:any, schema:dict)->tuple[bool,str]:
    stat,message = SchemaValidator.validate_schema(schema)
    if not stat:
      return False, message

    try:
      jsonschema.validate(instance, schema)
      return True, 'validated'
    except jsonschema.exceptions.ValidationError as e:
      message:str = cls._get_message(e)
      return False, message
    except Exception as e:
      return False, str(e)

  @classmethod
  def validate_with_template(cls, instance:any, tpl_name:str, sub_dir:str='')->tuple[bool,str]:
    schema = SchemaTemplate.get(tpl_name,sub_dir)
    if not schema:
      return False, f"Schema template {tpl_name} not found"
    return cls.validate(instance, schema)
    
  @classmethod
  def _get_message(cls, validation_error):
    """
    Get validation error message
    Args:
        validation_error: jsonschema ValidationError object
    Returns:
        str: Formatted error message
    """
    # Get error path
    path = '/'.join(map(str, validation_error.path))
    return f"{validation_error.message} - at {path}"
    
  @classmethod
  def validate_schema(cls, schema)->tuple[bool,str]:
    """
    Validate if a schema is a valid JSON Schema
    Args:
      schema: Schema to validate
    Returns:
      bool: True if valid
    """
    try:
      jsonschema.validators.validator_for(schema).check_schema(schema)
      return True,''
    except Exception as e:
      return False, str(e)
    