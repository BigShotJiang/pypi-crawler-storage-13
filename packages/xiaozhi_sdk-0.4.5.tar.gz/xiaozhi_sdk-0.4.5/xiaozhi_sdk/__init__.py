__version__ = "0.4.5"

from xiaozhi_sdk.core import XiaoZhiWebsocket  # noqa
