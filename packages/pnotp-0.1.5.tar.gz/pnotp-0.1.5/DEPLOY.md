# PnotP Cloudflare Deployment

Este repositorio ahora expone tres superficies:

- `PLATFORM/pnotp-landing` → Landing marketing público (`pnotp.ai`).
- `PLATFORM/pnotp-console` → Dashboard Next.js (Edge runtime) que consume una API propia (`app.pnotp.ai`).
- `PLATFORM/pnotp-api` → Worker de Cloudflare con `nodejs_compat` que ejecuta Prisma (Accelerate/Data Proxy) y sirve JSON (`api.pnotp.ai`).

## Arquitectura

1. `pnotp-api` (Cloudflare Workers) concentra toda la lógica de datos: Prisma Accelerate, generación de API Keys vía FastAPI, billing mock, etc.
2. `pnotp-console` sólo hace `fetch` contra `PNOTP_API_URL`, por lo que es compatible con `@cloudflare/next-on-pages` + Edge Runtime.
3. `pnotp-landing` sigue siendo un Next.js marketing site sin cambios.

## Requisitos previos

- `pnpm` instalado (cada proyecto trae su `pnpm-lock.yaml`).
- `wrangler` autenticado (`pnpm wrangler login`).
- Acceso al dashboard de Cloudflare (Pages + Workers + DNS de `pnotp.ai`).
- Una URL HTTP de Prisma Accelerate/Data Proxy que exponga la base de datos real (se inyecta como `DATABASE_URL` en el Worker).

> ⚠️ Ejecuta cada comando exactamente como aparece (sin comentarios inline tipo `# nota`), para evitar que `pnpm` interprete texto adicional como argumentos.

---

## API Worker (`api.pnotp.ai`)

- **Ruta del proyecto:** `PLATFORM/pnotp-api/`
- **Stack:** TypeScript + Wrangler + Prisma Accelerate.
- **Scripts útiles:**
  ```bash
  pnpm install
  pnpm prisma:generate     # genera el cliente edge
  pnpm dev                 # wrangler dev
  pnpm deploy              # wrangler deploy
  ```
- **wrangler.toml:** ya define `compatibility_flags = ["nodejs_compat"]` y variables no sensibles (`PATHOVISION_*`, `ALLOWED_ORIGINS`).

### Variables y secretos requeridos

Setéalos como secrets en el Worker:

```bash
wrangler secret put DATABASE_URL             # URL HTTP de Prisma Accelerate/Data Proxy
wrangler secret put PNOTP_INTERNAL_SECRET    # Se usa para llamar al endpoint FastAPI que emite API Keys
wrangler secret put CLERK_SECRET_KEY         # Clave que valida los tokens Bearer que manda la consola
```

Puedes sobreescribir `PATHOVISION_API_URL`, `PATHOVISION_PLAN_CODE` o `PATHOVISION_USER_EXTERNAL_ID` con `wrangler secret put` si cambia el backend.

> Autenticación Worker: todos los endpoints sensibles (`/api-keys`, `/dashboard/metrics`, `/models`, `/billing`, `/subscriptions`, `/custom-model-requests`) leen `Authorization: Bearer <token>` y usan `@clerk/backend` para validar el token contra Clerk. Sin token válido el Worker responde `401`.

### Deploy + dominio

```bash
cd PLATFORM/pnotp-api
pnpm install
pnpm deploy        # genera el Worker en *.workers.dev
```

Luego en Cloudflare Dashboard → Workers & Pages → Workers → `pnotp-api` → Custom domains → **Add domain** → `api.pnotp.ai`. Cloudflare emitirá el SSL y creará el CNAME automáticamente.

---

## Landing (`pnotp.ai`)

- **Ruta del proyecto:** `PLATFORM/pnotp-landing/`
- **Comando dev:** `pnpm dev`
- **Comando build:** `pnpm build && pnpm pages:build`
- **Directorio de salida:** `.cloudflare`
- **Project name (Pages):** `pnotp-landing`

### Despliegue manual

```bash
cd PLATFORM/pnotp-landing
pnpm install
pnpm build
pnpm pages:build
pnpm pages:deploy   # corre build + pages:build + wrangler pages deploy .cloudflare --project-name=pnotp-landing
```

### Custom domain

Wrangler CLI no soporta `wrangler pages project domains add`, así que usa la UI:

1. Cloudflare Dashboard → Pages → `pnotp-landing`.
2. Pestaña **Custom domains** → **Add domain** → `pnotp.ai` (y opcional `www.pnotp.ai`).
3. Cloudflare creará el CNAME y el certificado automáticamente.

---

## Plataforma (`app.pnotp.ai`)

- **Ruta del proyecto:** `PLATFORM/pnotp-console/`
- **Comando dev:** `pnpm dev`
- **Comando build:** `pnpm build && pnpm pages:build`
- **Directorio de salida:** `.cloudflare`
- **Project name (Pages):** `pnotp-console`

### Variables de entorno en Pages

Configura las variables (Production + Preview) apuntando a Clerk + Worker:

```
PNOTP_API_URL = https://api.pnotp.ai
NEXT_PUBLIC_PNOTP_API_URL = https://api.pnotp.ai
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY = pk_live_xxx
CLERK_SECRET_KEY = sk_live_xxx
```

- Las llaves `NEXT_PUBLIC_*` son visibles para el bundle y se usan por `ClerkProvider` y los componentes client.
- `CLERK_SECRET_KEY` debe configurarse como **Pages Secret** (no plain env) para que las llamadas autenticadas desde el layout/middleware funcionen.

### Despliegue manual

```bash
cd PLATFORM/pnotp-console
pnpm install
pnpm build
pnpm pages:build
pnpm pages:deploy   # build + pages:build + wrangler pages deploy .cloudflare --project-name=pnotp-console
```

### Custom domain

1. Cloudflare Dashboard → Pages → `pnotp-console`.
2. **Custom domains** → **Add domain** → `app.pnotp.ai`.
3. Cloudflare crea el CNAME `app` → `<project>.pages.dev` y emite el certificado automáticamente.

### Autenticación y protección de rutas

- El layout raíz (`app/layout.tsx`) envuelve la app en `<ClerkProvider>` y el grupo `app/(auth)` expone formularios custom para `/sign-in` y `/sign-up` usando `useSignIn`/`useSignUp`. La UI respeta el estilo negro/blanco de P¬P; no se usa el widget default de Clerk.
- `middleware.ts` importa `authMiddleware` y sólo deja `/sign-in` y `/sign-up` como rutas públicas. Las rutas `/dashboard`, `/models`, `/billing`, `/api-keys`, `/custom-models`, `/subscriptions` y `/` (redirect a dashboard) fuerzan login y redirigen a `/sign-in` si no hay sesión.
- `lib/pnotpApi.ts` usa `auth()` (Edge friendly) para adjuntar `Authorization: Bearer <token>` en cada fetch que sale del server. Los componentes client (p.ej. generación de API keys, formularios de billing/custom models) usan el hook `useAuthedPnotpApi()` para lograr lo mismo desde el browser, manteniendo los bundles pesados de Clerk fuera del Worker.
- El Worker valida el token con `@clerk/backend`. Si la verificación falla responde `401`, así que Pages y Worker siempre se mantienen en sync respecto a la sesión.

### Límite de 3 MiB del Worker de Pages

- Después de mover toda la mutación al cliente y quitar los server actions, el build de `@cloudflare/next-on-pages` sigue produciendo funciones de ~1.6‑1.8 MiB cada una. El directorio `.cloudflare/_worker.js` pesa ~17 MiB (`du -sh PLATFORM/pnotp-console/.cloudflare/_worker.js`), muy por encima del límite free (3 MiB).
- La causa principal es la integración de Next 16 + Clerk en el edge Worker: cada ruta arrastra los módulos `@clerk/nextjs` (`keyless-actions`, `server-actions`, etc.) aunque la UI sea minimalista.
- Opciones viables: (a) actualizar el plan de Workers a uno de pago (límite 10 MiB) o (b) mover `pnotp-console` a una plataforma sin límite de 3 MiB (ej. Vercel) y dejar sólo landing + API en Cloudflare.

---

## Dominio raíz → Verificación

Tras desplegar los tres proyectos:

1. Verifica `https://<hash>.pnotp-landing.pages.dev` y `https://<hash>.pnotp-console.pages.dev` para asegurarte de que devuelven contenido.
2. Verifica `https://pnotp.ai`, `https://app.pnotp.ai` y `https://api.pnotp.ai`. Si alguno falla, revisa la pestaña **Custom domains** del proyecto correspondiente.

---

## Notas adicionales

- `pnotp-console` ya no usa Prisma localmente; todo pasa por `pnotp-api`. Si el Worker devuelve un error, las páginas mostrarán el mensaje propagado.
- El Worker implementa CORS (`Access-Control-Allow-Origin` controlado por `ALLOWED_ORIGINS`). Por defecto está en `*`; ajústalo si necesitas restringirlo a `https://app.pnotp.ai` y `https://localhost:3000`.
- Si quieres eliminar los avisos de “Ignored build scripts: esbuild, sharp, workerd”, ejecuta `pnpm approve-builds` una vez en cada proyecto (`pnotp-landing`, `pnotp-console`, `pnotp-api`).
- `@cloudflare/next-on-pages` sigue mostrando un warning con Next 16; documentado en el README del console.

Con estos pasos, cada superficie queda desplegada en su dominio final y los builds quedan listos para correr `pnpm pages:deploy`/`pnpm deploy` cuando quieras publicar cambios.
