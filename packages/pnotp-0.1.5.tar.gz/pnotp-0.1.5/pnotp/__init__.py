from __future__ import annotations

"""Public entrypoint for the pnotp client library."""

import os

from .client import Client as _Client, DEFAULT_BASE_URL

__version__ = "0.1.5"


def client(api_key: str | None = None, base_url: str | None = None) -> _Client:
    """
    Factory for the PnotP client.

    If no api_key is provided, the loader will pull it from the environment
    using (in order): PNOTP_API_KEY, pnotp_API_KEY.
    The base URL defaults to the production endpoint unless explicitly overridden.
    """
    resolved_key = api_key or os.getenv("PNOTP_API_KEY") or os.getenv("pnotp_API_KEY") or os.getenv("PNP_API_KEY") or os.getenv("pnp_API_KEY")
    resolved_base = base_url or DEFAULT_BASE_URL
    return _Client(api_key=resolved_key, base_url=resolved_base)


__all__ = ["client"]
