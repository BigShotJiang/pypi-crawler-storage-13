type LogicDividerProps = {
  symbol?: "¬" | "⊢" | "⟂";
  label?: string;
};

export function LogicDivider({ symbol = "¬", label }: LogicDividerProps) {
  return (
    <div className="logic-divider text-xs" aria-hidden>
      <span className="font-mono text-base">{symbol}</span>
      {label && <span className="tracking-[0.2em]">{label}</span>}
    </div>
  );
}
