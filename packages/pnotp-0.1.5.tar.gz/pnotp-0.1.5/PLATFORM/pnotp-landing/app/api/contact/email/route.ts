import { NextRequest, NextResponse } from "next/server";

export const runtime = "edge";

export async function POST(request: NextRequest) {
  const formData = await request.formData();
  const payload = Object.fromEntries(formData.entries());

  console.info("Message received", payload);

  return NextResponse.json({ status: "queued", payload });
}
