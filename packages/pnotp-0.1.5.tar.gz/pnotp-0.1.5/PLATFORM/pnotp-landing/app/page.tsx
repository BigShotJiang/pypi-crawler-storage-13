import Link from "next/link";
import type { Metadata } from "next";

import { LogicDivider } from "@/components/brand/logic-divider";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const logicSymbols: Array<"¬" | "⊢" | "⟂"> = ["¬", "⊢", "⟂"];

const navItems = [
  { label: "Modelos", href: "#modelos" },
  { label: "Desarrollo 1-a-1", href: "#desarrollo" },
  { label: "PathoVision", href: "#pathovision" },
  { label: "Visión", href: "#vision" },
  { label: "Contacto", href: "#cta-final" },
];

const valueBullets = [
  "Modelos propios, no wrappers",
  "Validación técnica y clínica real",
  "API simple, escalable y lista para producción",
  "Desarrollo personalizado para empresas",
];

const problemPoints = [
  "Costos de cómputo altos",
  "Falta de talento especializado",
  "Datasets difíciles de obtener",
  "MLOps y mantenimiento continuo",
  "Modelos genéricos que no alcanzan nivel de producción",
];

const methodologySteps = [
  {
    title: "Dive",
    detail: "Profundizamos en tu caso de uso y definimos el problema P vs ¬P o el modelo avanzado requerido.",
  },
  {
    title: "Design",
    detail: "Seleccionamos la arquitectura correcta (CNNs, ViTs, multimodal, ensembles).",
  },
  {
    title: "Develop",
    detail: "Entrenamos, calibramos y validamos con rigor cuantitativo y clínico.",
  },
  {
    title: "Deploy",
    detail: "Integramos vía API y aseguramos operatividad continua en tu stack.",
  },
  {
    title: "Scale",
    detail: "Mejoramos progresivamente usando datos reales y feedback operativo.",
  },
];

const tiers = [
  {
    name: "Expert Tier",
    price: "$1999/month",
    description:
      "Modelos con desempeño clínico y exactitud excepcional (>99%). Diseñados para productos críticos y empresas que requieren precisión extrema.",
    models: [
      {
        name: "Brain MRI Tumor Detection",
        industry: "Medicina",
        bullets: [
          "Ensemble de 5 checkpoints",
          "Accuracy: 99.2%",
          "F1: 0.992",
          "AUC: 1.000",
        ],
      },
      {
        name: "Chest X-Ray Tuberculosis Screening",
        industry: "Salud pública",
        bullets: [
          "Ensemble calibrado para programas de salud",
          "Accuracy: 99.9%",
          "F1: 0.998",
          "AUC: 1.000",
        ],
      },
      {
        name: "Retina — Diabetic Retinopathy (Binary)",
        industry: "Oftalmología",
        bullets: [
          "Ensemble con threshold 0.8489",
          "Accuracy: 100%",
          "F1: 1.000",
          "AUC: 1.000",
        ],
      },
    ],
  },
  {
    name: "Premium Tier",
    price: "$999/month",
    description: "Modelos con desempeño robusto para producción masiva.",
    models: [
      {
        name: "Chest X-Ray Aortic Enlargement",
        bullets: ["Accuracy: 96.5%", "AUC: 0.995"],
      },
      {
        name: "Chest X-Ray Cardiomegaly",
        bullets: ["Accuracy: 95.5%", "AUC: 0.995"],
      },
      {
        name: "Chest X-Ray Pleural Effusion",
        bullets: ["Accuracy: 99.0%", "AUC: 0.996"],
      },
      {
        name: "Chest X-Ray Pneumonia Detection",
        bullets: ["Accuracy: 97.1%", "AUC: 0.990"],
      },
    ],
  },
  {
    name: "MVP Tier",
    price: "$499/month",
    description: "Modelos listos para lanzamientos tempranos y pilotos medibles.",
    models: [
      {
        name: "Chest X-Ray Pleural Thickening",
        bullets: ["Accuracy: 94.4%", "AUC: 0.985"],
      },
    ],
  },
  {
    name: "Viable Tier",
    price: "$199/month",
    description: "Modelos accesibles para compañías que necesitan pruebas controladas.",
    models: [
      {
        name: "Retina — Glaucoma (Binary)",
        bullets: ["Accuracy: 91.7%", "AUC: 0.979"],
      },
    ],
  },
];

const minimumStandards = [
  "Accuracy ≥ 90%",
  "AUC ≥ 0.95",
  "Modelos calibrados y validados",
  "Ensembles cuando corresponde",
  "Thresholding con metodología médica (Youden, ROC-based)",
];

const workTracks = [
  {
    title: "Suscripción a modelos existentes",
    description: "Acceso directo a cualquiera de los modelos de la librería P¬P vía API.",
    bullets: [
      "Provisioning instantáneo de endpoints",
      "Monitoreo y reporting incluidos",
      "Upgrades automáticos por tier",
    ],
  },
  {
    title: "Desarrollo 1-a-1",
    description: "Proyectos a la medida para industrias que requieren arquitectura dedicada.",
    bullets: [
      "Arquitectura y entrenamiento dirigidos",
      "Validación interpretada y documentación",
      "Integración con tu infraestructura + soporte continuo",
    ],
  },
];

const futureVerticals = [
  "PathoVision — diagnóstico médico",
  "AgriVision — agricultura y cultivos",
  "InfraVision — mantenimiento predictivo",
  "FinVision — modelos de riesgo y fraude",
  "SportsVision — desempeño deportivo e inteligencia biomecánica",
  "Más por anunciar…",
];

const pathoVisionStack = [
  "pipelines completos de entrenamiento",
  "calibración clínicamente interpretada",
  "ensembles de cinco modelos",
  "thresholds específicos por patología",
  "modelos listos para entornos hospitalarios",
];

const inputClasses =
  "w-full border border-black bg-white px-4 py-3 text-sm uppercase tracking-[0.08em] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-black focus-visible:ring-offset-2 focus-visible:ring-offset-white";

export const metadata: Metadata = {
  title: "P¬P — AI Lab",
  description: "Landing oficial de PnotP con tiers de modelos y PathoVision",
};

const telegraphStyle = {
  fontFamily: "'PP Telegraf','PP Telegraph','Inter',sans-serif",
};

const consoleUrl = process.env.NEXT_PUBLIC_CONSOLE_URL ?? "https://console.pnotp.ai";

export default function LandingPage() {
  return (
    <div className="bg-white text-black">
      <header className="border-b border-black bg-white">
        <nav className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-6 py-6 text-[11px] font-medium uppercase tracking-[0.25em]">
          <Link href="/" className="text-3xl tracking-[0.08em]" style={telegraphStyle}>
            P¬P
          </Link>
          <div className="flex flex-wrap items-center justify-center gap-5 text-[10px] uppercase tracking-[0.3em]">
            {navItems.map((item) => (
              <Link key={item.label} href={item.href} className="transition-colors hover:bg-black hover:text-white">
                <span className="inline-block px-2 py-1">{item.label}</span>
              </Link>
            ))}
          </div>
          <div className="flex flex-wrap gap-3">
            <Button asChild size="sm" variant="outline">
              <a href={consoleUrl} target="_blank" rel="noreferrer">
                Ir a la plataforma
              </a>
            </Button>
            <Button asChild size="sm">
              <Link href="#cta-final">Habla con nosotros</Link>
            </Button>
          </div>
        </nav>
      </header>

      <main className="mx-auto max-w-6xl space-y-16 px-6 py-16">
        <section id="hero" className="space-y-8">
          <p className="text-xs uppercase tracking-[0.35em] text-black/60">LANDING PAGE — PnotP</p>
          <div className="space-y-6">
            <h1 className="tracking-[0.08em]">El AI Lab que desarrolla modelos de alta precisión para empresas</h1>
            <p className="max-w-4xl text-lg text-black/80">
              Somos expertos en clasificación binaria de alto impacto (P vs ¬P) y desarrollamos modelos avanzados de IA para
              empresas y startups. Aunque nuestra especialidad es la clasificación binaria, abordamos cualquier proyecto de
              IA que requiera arquitectura propia, rigor alto y precisión real.
            </p>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {valueBullets.map((text, index) => (
              <div
                key={text}
                className="flex items-center gap-4 border border-black px-4 py-4 text-sm font-medium tracking-[0.08em]"
              >
                <span className="font-mono text-lg">{logicSymbols[index % logicSymbols.length]}</span>
                <span>{text}</span>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap gap-4">
            <Button asChild>
              <Link href="#call-request">Agenda una llamada</Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="#modelos">Explorar modelos</Link>
            </Button>
            <Button asChild variant="ghost">
              <Link href="https://www.linkedin.com/in/vicente-gallardo-aba5b2253/" target="_blank" rel="noreferrer">
                Conectar en LinkedIn
              </Link>
            </Button>
            <Button asChild variant="secondary">
              <a href={consoleUrl} target="_blank" rel="noreferrer">
                Abrir consola
              </a>
            </Button>
          </div>
        </section>

        <section id="que-es-pnotp" className="space-y-6">
          <LogicDivider symbol="¬" label="01 — ¿QUÉ ES PNOTP?" />
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <p>
                PnotP es un AI Lab que diseña, entrena y mantiene modelos de Inteligencia Artificial para empresas que
                necesitan soluciones rigurosas, calibradas y listas para producción.
              </p>
              <p>Somos especialistas en problemas de la forma:</p>
              <div className="border border-black px-4 py-4 text-sm uppercase tracking-[0.2em]">
                <p>¿P o ¬P?</p>
                <p>¿Es cáncer o no es cáncer?</p>
                <p>¿Es fraude o no es fraude?</p>
                <p>¿Es falla crítica o no?</p>
              </div>
            </div>
            <div className="space-y-4">
              <p>
                También desarrollamos modelos avanzados para cualquier otro tipo de problema, desde visión por computadora
                hasta modelado multimodal.
              </p>
              <p>
                Las empresas simplemente se conectan vía API o solicitan un desarrollo 1-a-1, sin tener que construir su propio
                laboratorio de IA.
              </p>
            </div>
          </div>
        </section>

        <section id="problema" className="space-y-6">
          <LogicDivider symbol="⊢" label="02 — EL PROBLEMA" />
          <div className="grid gap-6 md:grid-cols-[1.2fr_0.8fr]">
            <p>
              La mayoría de empresas necesita IA. Casi ninguna puede desarrollarla. Los cuellos de botella técnicos y
              financieros vuelven inviables los prototipos internos.
            </p>
            <p className="text-sm text-black/70">El resultado: prototipos que no escalan y productos que no alcanzan precisión confiable.</p>
          </div>
          <ul className="logic-list">
            {problemPoints.map((point, index) => (
              <li key={point} data-symbol={logicSymbols[index % logicSymbols.length]}>
                {point}
              </li>
            ))}
          </ul>
        </section>

        <section id="modelos" className="space-y-8">
          <LogicDivider symbol="⟂" label="03 — MODELOS POR TIERS + DESARROLLO 1-A-1" />
          <p>
            Creamos modelos propios y los distribuimos en cuatro niveles de capacidad. Cada tier incluye modelos auditados,
            documentación de métricas y soporte de despliegue. Si necesitas algo único, activamos un desarrollo 1-a-1 dentro
            del mismo stack.
          </p>
          <div className="grid gap-6 lg:grid-cols-2">
            {tiers.map((tier) => (
              <Card key={tier.name}>
                <CardHeader>
                  <p className="text-[11px] uppercase tracking-[0.35em] text-black/60">{tier.price}</p>
                  <CardTitle>{tier.name}</CardTitle>
                  <CardDescription>{tier.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-5">
                  {tier.models.map((model) => (
                    <div key={model.name} className="border border-black px-4 py-4">
                      <div className="flex flex-wrap items-baseline justify-between gap-2">
                        <p className="text-sm font-medium uppercase tracking-[0.2em]">{model.name}</p>
                        {"industry" in model && model.industry && (
                          <span className="text-xs uppercase tracking-[0.3em] text-black/60">{model.industry}</span>
                        )}
                      </div>
                      <ul className="mt-3 space-y-1 text-sm text-black/80">
                        {model.bullets.map((bullet) => (
                          <li key={bullet}>{bullet}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>
          <Card className="bg-black text-white">
            <CardHeader>
              <CardTitle className="text-white">Nuestros estándares mínimos</CardTitle>
              <CardDescription className="text-white/80">
                Cada modelo cumple y documenta métricas antes de exponerse en la plataforma.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="logic-list">
                {minimumStandards.map((standard, index) => (
                  <li key={standard} data-symbol={logicSymbols[index % logicSymbols.length]} className="text-white">
                    {standard}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
          <div className="flex flex-wrap gap-4">
            <Button asChild variant="outline">
              <Link href="#desarrollo">Conoce el servicio 1-a-1</Link>
            </Button>
          </div>
        </section>

        <section id="metodo" className="space-y-6">
          <LogicDivider symbol="¬" label="04 — P¬P METHOD" />
          <p>Un pipeline diseñado para equipos que necesitan decisiones binarias confiables.</p>
          <div className="grid gap-4 md:grid-cols-5">
            {methodologySteps.map((step, index) => (
              <div key={step.title} className="border border-black px-4 py-4">
                <p className="text-xs font-medium uppercase tracking-[0.35em] text-black/60">
                  {String(index + 1).padStart(2, "0")}
                </p>
                <p className="mt-2 text-lg font-medium uppercase tracking-[0.2em]">{step.title}</p>
                <p className="mt-2 text-sm text-black/80">{step.detail}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="pathovision" className="space-y-6">
          <LogicDivider symbol="⊢" label="05 — PATHOVISION" />
          <div className="space-y-4">
            <p>
              PathoVision fue nuestro primer proyecto y hoy vive dentro de P¬P. Sus modelos son accesibles inmediatamente
              dentro de los tiers Expert y Premium.
            </p>
            <Button asChild variant="outline" className="w-full md:w-auto">
              <Link href="https://pathovision.ai" target="_blank" rel="noreferrer">
                Visita pathovision.ai
              </Link>
            </Button>
            <p>Gracias a PathoVision construimos:</p>
            <ul className="logic-list">
              {pathoVisionStack.map((item, index) => (
                <li key={item} data-symbol={logicSymbols[index % logicSymbols.length]}>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id="desarrollo" className="space-y-6">
          <LogicDivider symbol="⟂" label="06 — ¿PARA QUIÉN ES PNOTP?" />
          <p>
            Ideal para compañías que requieren modelos propios sin montar un laboratorio interno. Operamos en dos vías de
            trabajo claras:
          </p>
          <div className="grid gap-6 md:grid-cols-2">
            {workTracks.map((track) => (
              <Card key={track.title}>
                <CardHeader>
                  <CardTitle>{track.title}</CardTitle>
                  <CardDescription>{track.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="logic-list">
                    {track.bullets.map((bullet, index) => (
                      <li key={bullet} data-symbol={logicSymbols[index % logicSymbols.length]}>
                        {bullet}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section id="vision" className="space-y-6">
          <LogicDivider symbol="¬" label="07 — VISIÓN" />
          <p>
            Convertirnos en el AI Lab más grande y preciso de LATAM. PnotP es la infraestructura que permite conectar
            productos al núcleo de IA P~P sin construir departamentos internos.
          </p>
          <p>Nuestras verticales seguirán creciendo y alimentándose del mismo motor lógico:</p>
          <ul className="logic-list">
            {futureVerticals.map((vertical, index) => (
              <li key={vertical} data-symbol={logicSymbols[index % logicSymbols.length]}>
                {vertical}
              </li>
            ))}
          </ul>
        </section>

        <section id="equipo" className="space-y-6">
          <LogicDivider symbol="⊢" label="08 — EQUIPO" />
          <div className="border border-black px-6 py-6">
            <p className="text-xs uppercase tracking-[0.35em] text-black/60">Fundador</p>
            <h3 className="mt-2 tracking-[0.08em]">Vicente Gallardo</h3>
            <p className="mt-4 text-sm text-black/80">
              Ingeniero en Ciencia de Datos y Matemáticas con foco en diseño de arquitecturas de IA, visión por computadora,
              modelos de clasificación binaria de alta precisión, calibración y metodologías clínicas, y desarrollo de
              plataformas de IA para empresas.
            </p>
            <p className="mt-4 text-sm text-black/80">
              Ha desarrollado PathoVision, múltiples ensembles médicos, y ahora lidera PnotP como un AI Lab enfocado en rigor,
              precisión y escalabilidad empresarial.
            </p>
          </div>
        </section>

        <section id="cta-final" className="space-y-8">
          <LogicDivider symbol="¬" label="09 — CTA FINAL" />
          <h2 className="tracking-[0.08em]">¿NECESITAS UN MODELO AVANZADO DE ALTA PRECISIÓN?</h2>
          <p className="text-black/80">
            Hablemos. Puedes escribirnos directamente o dejar tu disponibilidad para coordinar una llamada con el equipo de P¬P.
          </p>
          <div className="grid gap-6 lg:grid-cols-2">
            <Card id="call-request">
              <CardHeader>
                <CardTitle>Agenda una llamada</CardTitle>
                <CardDescription>Comparte tus horarios ideales y te respondemos con un enlace de calendario.</CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4" action="/api/contact/call-request" method="post">
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-[0.35em] text-black/60" htmlFor="call-name">
                      Nombre completo
                    </label>
                    <input id="call-name" name="name" className={inputClasses} placeholder="Nombre" required />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-[0.35em] text-black/60" htmlFor="call-company">
                      Empresa / Proyecto
                    </label>
                    <input id="call-company" name="company" className={inputClasses} placeholder="Compañía" required />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-[0.35em] text-black/60" htmlFor="call-email">
                      Correo
                    </label>
                    <input
                      id="call-email"
                      name="email"
                      type="email"
                      className={inputClasses}
                      placeholder="correo@empresa.com"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-[0.35em] text-black/60" htmlFor="call-availability">
                      Disponibilidad
                    </label>
                    <textarea
                      id="call-availability"
                      name="availability"
                      className={`${inputClasses} min-h-[120px]`}
                      placeholder="Comparte tu zona horaria y horarios preferidos"
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full">
                    Enviar solicitud
                  </Button>
                </form>
                <p className="mt-4 text-xs uppercase tracking-[0.35em] text-black/60">
                  Backend API listo para conectar disponibilidad y recordatorios.
                </p>
              </CardContent>
            </Card>

            <Card id="message-request">
              <CardHeader>
                <CardTitle>Escríbenos</CardTitle>
                <CardDescription>
                  Manda un mensaje directo; pronto conectaremos este formulario con el motor de correo transaccional de P¬P.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4" action="/api/contact/email" method="post">
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-[0.35em] text-black/60" htmlFor="message-name">
                      Nombre
                    </label>
                    <input id="message-name" name="name" className={inputClasses} placeholder="Tu nombre" required />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-[0.35em] text-black/60" htmlFor="message-email">
                      Correo
                    </label>
                    <input
                      id="message-email"
                      name="email"
                      type="email"
                      className={inputClasses}
                      placeholder="tu@correo.com"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-[0.35em] text-black/60" htmlFor="message-body">
                      Mensaje
                    </label>
                    <textarea
                      id="message-body"
                      name="message"
                      className={`${inputClasses} min-h-[140px]`}
                      placeholder="Cuéntanos sobre tu caso P vs ¬P o modelos avanzados"
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full">
                    Enviar mensaje
                  </Button>
                </form>
                <p className="mt-4 text-xs text-black/70">
                  ¿Prefieres tu propio cliente de correo? Escribe a
                  <Link
                    href="mailto:brand@pnotp.ai"
                    className="ml-1 inline-flex border border-black px-2 py-1 text-[10px] uppercase tracking-[0.35em] text-black"
                  >
                    brand@pnotp.ai
                  </Link>
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <footer className="border-t border-black bg-white py-6 text-center text-xs uppercase tracking-[0.3em]">
        © 2025 PnotP – P¬P Intelligence Lab
      </footer>
    </div>
  );
}
