"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useAuthedPnotpApi } from "@/lib/useAuthedPnotpApi"
import { isSignInRequiredError } from "@/lib/authErrors"
import { promptSignIn } from "@/lib/signInRedirect"

type SubscribeDialogButtonProps = {
  tier: string
  label: string
  priceUsd: number
  description?: string
  triggerClassName?: string
  disabled?: boolean
  disabledLabel?: string
}

export function SubscribeDialogButton({
  tier,
  label,
  priceUsd,
  description,
  triggerClassName,
  disabled,
  disabledLabel,
}: SubscribeDialogButtonProps) {
  const router = useRouter()
  const pnotpFetch = useAuthedPnotpApi()
  const [open, setOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async () => {
    setSubmitting(true)
    setError(null)

    try {
      await pnotpFetch("/subscriptions", {
        method: "POST",
        body: JSON.stringify({ tier }),
      })
      setOpen(false)
      router.refresh()
    } catch (err) {
      if (isSignInRequiredError(err)) {
        promptSignIn("Sign in to manage billing.")
        return
      }
      const message = err instanceof Error ? err.message : "Unable to update subscription."
      setError(message)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <>
      <Button
        onClick={() => setOpen(true)}
        disabled={disabled || submitting}
        className={triggerClassName}
      >
        {disabled ? disabledLabel ?? "Subscribed" : submitting ? "Processing..." : "Subscribe"}
      </Button>

      <Dialog open={open && !disabled} onOpenChange={setOpen}>
        <DialogContent className="rounded-none border-[#C6C6C6] bg-white text-black shadow-none">
          <DialogHeader>
            <DialogTitle className="text-2xl font-medium">{label}</DialogTitle>
            <DialogDescription className="text-black/60">
              {tier.toUpperCase()} • ${priceUsd}/month
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 text-sm">
            {description && <p className="text-black/70">{description}</p>}
            <p className="text-black/60">
              Subscriptions renew monthly. Payment processing is currently manual; activating this tier
              updates your access records immediately.
            </p>
            {error && <p className="text-sm text-red-600">{error}</p>}
          </div>

          <DialogFooter className="flex flex-col gap-2 sm:flex-row">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              className="rounded-none border-black text-black hover:bg-black hover:text-white"
              disabled={submitting}
            >
              Close
            </Button>
            <Button
              type="button"
              onClick={handleSubmit}
              disabled={submitting}
              className="rounded-none bg-black text-white hover:bg-black/90"
            >
              {submitting ? "Updating..." : "Confirm subscription"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
