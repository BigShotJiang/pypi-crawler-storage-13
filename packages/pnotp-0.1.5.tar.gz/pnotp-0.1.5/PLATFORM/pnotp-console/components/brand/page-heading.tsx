import { LogicDivider } from "@/components/brand/logic-divider"

const logicSymbols: Array<"¬" | "⊢" | "⟂"> = ["¬", "⊢", "⟂"]

type PageHeadingProps = {
  label?: string
  title: string
  description: string
  meta?: string[]
  symbol?: "¬" | "⊢" | "⟂"
}

export function PageHeading({
  label = "P¬P AI LAB",
  title,
  description,
  meta,
  symbol = "¬",
}: PageHeadingProps) {
  return (
    <header className="space-y-4 border-b border-black pb-6">
      <p className="text-[11px] font-medium uppercase tracking-[0.35em] text-black/60">
        {label}
      </p>
      <div className="space-y-3">
        <h1 className="tracking-[0.08em]">{title}</h1>
        <p className="max-w-3xl text-sm text-black/80">{description}</p>
      </div>
      {meta && meta.length > 0 && (
        <ul className="logic-list">
          {meta.map((item, index) => (
            <li key={item} data-symbol={logicSymbols[index % logicSymbols.length]}>
              {item}
            </li>
          ))}
        </ul>
      )}
      <LogicDivider symbol={symbol} />
    </header>
  )
}
