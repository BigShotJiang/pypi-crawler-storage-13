import * as React from "react"

import { cn } from "@/lib/utils"

function Textarea({ className, ...props }: React.ComponentProps<"textarea">) {
  return (
    <textarea
      data-slot="textarea"
      className={cn(
        "w-full border border-black bg-white px-4 py-3 text-sm tracking-[0.08em] text-black placeholder:text-black/40 outline-none focus-visible:ring-2 focus-visible:ring-black focus-visible:ring-offset-2 focus-visible:ring-offset-white disabled:pointer-events-none disabled:opacity-40 rounded-none min-h-32",
        className
      )}
      {...props}
    />
  )
}

export { Textarea }
