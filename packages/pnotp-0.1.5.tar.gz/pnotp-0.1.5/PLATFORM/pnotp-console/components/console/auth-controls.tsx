"use client"

import Link from "next/link"
import { SignedIn, SignedOut, UserButton } from "@clerk/nextjs"

const userButtonAppearance = {
  elements: {
    userButtonAvatarBox: "ring-2 ring-zinc-700 rounded-full",
    userButtonPopoverCard:
      "bg-black border border-zinc-800 rounded-2xl text-white shadow-xl",
    userButtonPopoverActionButton:
      "text-sm text-zinc-300 hover:bg-zinc-900 hover:text-white",
    userButtonPopoverFooter: "text-xs text-zinc-500",
  },
}

export function AuthControls() {
  return (
    <div className="flex items-center gap-3">
      <SignedOut>
        <Link
          href="/sign-in?redirect_url=%2Fdashboard"
          className="text-xs uppercase tracking-[0.25em] border border-zinc-800 px-4 py-2 rounded-full text-white hover:bg-zinc-900"
        >
          Sign In
        </Link>
      </SignedOut>
      <SignedIn>
        <UserButton afterSignOutUrl="/sign-in" appearance={userButtonAppearance} />
      </SignedIn>
    </div>
  )
}
