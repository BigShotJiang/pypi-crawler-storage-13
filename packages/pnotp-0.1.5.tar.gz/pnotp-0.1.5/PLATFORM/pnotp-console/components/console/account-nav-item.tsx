"use client"

import Link from "next/link"
import { SignedIn } from "@clerk/nextjs"

const navClasses =
  "flex items-center justify-between px-6 py-5 text-xs font-medium uppercase tracking-[0.25em] transition-colors hover:bg-black hover:text-white"

export function AccountNavItem() {
  return (
    <SignedIn>
      <Link href="/account" className={navClasses}>
        <span className="flex items-center gap-3">
          <span className="font-mono text-base">⊢</span>
          Account
        </span>
        <span className="text-[10px]">⟂</span>
      </Link>
    </SignedIn>
  )
}
