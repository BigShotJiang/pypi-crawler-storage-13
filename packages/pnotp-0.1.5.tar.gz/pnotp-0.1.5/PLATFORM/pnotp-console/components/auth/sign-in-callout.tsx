import Link from "next/link"
import { Button } from "@/components/ui/button"

type SignInCalloutProps = {
  message: string
  redirectUrl?: string
}

export function SignInCallout({ message, redirectUrl }: SignInCalloutProps) {
  const href = redirectUrl
    ? `/sign-in?redirect_url=${encodeURIComponent(redirectUrl)}`
    : "/sign-in"

  return (
    <div className="border border-black bg-white p-6 text-center">
      <div className="space-y-4">
        <p className="text-sm text-black/70">{message}</p>
        <Button asChild className="rounded-none">
          <Link href={href}>Sign In</Link>
        </Button>
      </div>
    </div>
  )
}
