"use client"

import { useClerk } from "@clerk/nextjs"
import { useState } from "react"

export function AccountActions() {
  const { user, openUserProfile, signOut } = useClerk()
  const [deleting, setDeleting] = useState(false)

  if (!user) {
    return null
  }

  const handleDelete = async () => {
    if (!user) {
      return
    }

    const confirmed = window.confirm(
      "This will permanently remove your P¬P account and API access. Continue?"
    )
    if (!confirmed) {
      return
    }

    setDeleting(true)
    try {
      await user.delete()
      window.location.href = "/sign-in"
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="flex flex-wrap gap-2 text-xs uppercase tracking-[0.2em]">
      <button
        onClick={() => signOut({ redirectUrl: "/sign-in" })}
        className="rounded-full border border-black px-4 py-2 hover:bg-black hover:text-white transition-colors"
      >
        Sign Out
      </button>
      <button
        onClick={() => openUserProfile()}
        className="rounded-full border border-black px-4 py-2 hover:bg-black hover:text-white transition-colors"
      >
        Change Password
      </button>
      <button
        onClick={() => openUserProfile()}
        className="rounded-full border border-black px-4 py-2 hover:bg-black hover:text-white transition-colors"
      >
        Manage Devices
      </button>
      <button
        onClick={handleDelete}
        disabled={deleting}
        className="rounded-full border border-red-500 px-4 py-2 text-red-600 hover:bg-red-600 hover:text-white disabled:opacity-60 transition-colors"
      >
        {deleting ? "Deleting..." : "Delete Account"}
      </button>
    </div>
  )
}
