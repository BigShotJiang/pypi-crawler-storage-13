# P¬P Developer Console

A production-quality Next.js Developer Console for managing PnotP API keys, models, and subscriptions.

## Overview

The P¬P Developer Console is a local, production-quality web application built with Next.js 14+ (App Router) that replaces the previous Base-44 console. It provides a comprehensive interface for:

- Viewing the PnotP model catalog (with tiers + metrics)
- Managing API keys (generated via the existing FastAPI PnotP backend)
- Viewing active subscriptions (locally modeled for now)
- Submitting custom model requests

## Tech Stack

- **Framework**: Next.js 14+ with App Router
- **Language**: TypeScript (strict mode)
- **Styling**: Tailwind CSS
- **UI Components**: shadcn/ui
- **Icons**: lucide-react
- **State Management**: @tanstack/react-query (for client-side interactivity)
- **Data Layer**: Remote Cloudflare Worker (`pnotp-api`) exposed over HTTPS (Prisma Accelerate)
- **Runtime**: Cloudflare Pages (Edge)
- **Package Manager**: pnpm

## Prerequisites

- Node.js 18+ 
- pnpm (install with `npm install -g pnpm`)

## Setup Instructions

1. **Install dependencies**:
   ```bash
   pnpm install
   ```

2. **Configure environment variables**:
   ```
   PNOTP_API_URL=https://api.pnotp.ai
   NEXT_PUBLIC_PNOTP_API_URL=https://api.pnotp.ai
   NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_123
   CLERK_SECRET_KEY=sk_test_123
   ```
   - `PNOTP_API_URL` is used by server components/server actions.
   - `NEXT_PUBLIC_PNOTP_API_URL` is referenced by browser-side code (API key creation).
   - `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` is injected in the browser so Clerk.js can render the headless auth hooks.
   - `CLERK_SECRET_KEY` stays on the server/Edge runtime and powers middleware + authenticated fetches.

3. **Start the development server**:
   ```bash
   pnpm dev
   ```

   The application will be available at `http://localhost:3000`

## Available Scripts

- `pnpm dev` - Start development server
- `pnpm build` - Build for production
- `pnpm start` - Start production server
- `pnpm lint` - Run ESLint

## Project Structure

```
pnotp-console/
├── app/
│   ├── (auth)/             # Custom Clerk sign-in/up routes
│   ├── (console)/          # Console route group
│   │   ├── layout.tsx      # Console shell with sidebar
│   │   ├── dashboard/      # Dashboard page
│   │   ├── models/         # Models catalog page
│   │   ├── api-keys/       # API keys management page
│   │   ├── billing/        # Billing/subscriptions page
│   │   └── custom-models/  # Custom model request page
│   ├── globals.css         # Global styles
│   └── layout.tsx          # Root layout
├── components/
│   └── ui/                 # shadcn/ui components
├── lib/
│   ├── pnotpApi.ts         # Server-side HTTP client for the Worker API
│   ├── pnotpTypes.ts       # Shared DTOs used across server/client components
│   └── utils.ts            # Utility functions
└── public/                 # Static assets
```

## Environment Variables

### Required

- `PNOTP_API_URL` – Internal base URL for the `pnotp-api` Worker (e.g., `https://api.pnotp.ai`)
- `NEXT_PUBLIC_PNOTP_API_URL` – Same base URL exposed to browser-side code (must point to the Worker as well)
- `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` – Publishable key that hydrates the ClerkProvider and client hooks
- `CLERK_SECRET_KEY` – Server-side key used by middleware, server actions, and Worker fetch helpers

## Authentication Flow

- The root `app/layout.tsx` wraps every route in `<ClerkProvider>` so both client and server components have Clerk context at the Edge runtime.
- Custom, P¬P-styled auth pages live in `app/(auth)/sign-in` and `app/(auth)/sign-up`. They use the headless `useSignIn`/`useSignUp` hooks plus manual verification flows—no default Clerk UI is rendered.
- `middleware.ts` relies on `authMiddleware` to force authentication on `/dashboard`, `/models`, `/billing`, `/api-keys`, `/custom-models`, `/subscriptions`, and `/` (root redirect). Unauthenticated visitors are sent to `/sign-in`.
- Server-only loaders call helpers in `lib/pnotpApi.ts`, which uses `auth()` to append `Authorization: Bearer <token>` before hitting the Worker.
- Client components that mutate data use the `useAuthedPnotpApi()` hook (Clerk + fetch) so heavy Clerk bundles stay client-side and the Worker bundle remains slim.
- Client-side mutations (API key creation) use `useAuth().getToken()` before hitting the Worker, guaranteeing the Worker receives the same Bearer token regardless of where the request originated.

## Data Source

All persistence now lives inside the `PLATFORM/pnotp-api` Worker project. It exposes HTTPS endpoints that wrap Prisma Accelerate and the upstream FastAPI API-key issuer. See that package for schema definitions and deployment steps.

## Integration with FastAPI Backend

External API-key minting is handled inside the `pnotp-api` Worker:

- The Worker calls `https://api.pathovision.ai/internal/api-keys`, attaching the `PNOTP_INTERNAL_SECRET` header plus plan/user metadata.
- The console never stores that secret; it simply sends HTTPS requests to `PNOTP_API_URL`, and the Worker proxies/validates everything server-side.
- API responses are returned as JSON DTOs that the console components consume.

## Brand & Design

The console follows a strict black & white minimal design:

- **Colors**: 
  - Black: `#000000`
  - White: `#FFFFFF`
  - Soft Gray (borders only): `#C6C6C6`
- **Typography**: Inter font (400 weight for body, 500 for titles)
- **Style**: Ultra-minimal, square corners, no shadows, no gradients

## Features

### Dashboard
- Overview statistics (API keys, models, subscriptions)
- Quick action cards

### Models Catalog
- Browse models grouped by tier (Expert, Premium, MVP, Viable)
- Filter by industry (Medicine, Finance, Agriculture)
- View model metrics (accuracy, F1 score, AUC)
- Subscribe to models (local mock, no Stripe yet)

### API Keys
- List all generated API keys
- Generate new keys via external FastAPI endpoint
- One-time display of full API key with copy functionality
- Code snippet showing how to use the key with the `pnotp` Python client

### Billing
- View active subscriptions with total monthly cost
- Subscribe to additional models
- Local mock subscriptions (Stripe integration TBD)

### Custom Models
- Submit requests for custom model development
- Form includes domain, problem description, data description, and contact email

## Future Enhancements

- [ ] Authentication system (currently single "owner" user)
- [ ] Stripe integration for real billing
- [ ] User management and multi-user support
- [ ] Model usage analytics
- [ ] API key usage tracking
- [ ] Webhook support for subscription events

## Development Notes

- All components use strict TypeScript types
- Server components by default; React Query only for client interactivity
- Mutating flows live in client components via `useAuthedPnotpApi()` so Clerk stays client-side and the Worker stays lean; avoid reintroducing server actions unless you plan to exceed the 3 MiB Pages Worker limit.
- El Worker (`pnotp-api`) conserva las relaciones Prisma usando `modelId` (no el `id` interno), y la UI asume esos identificadores al consumir la API
- Brand colors strictly enforced throughout
- TODO comments mark where auth/Stripe will be added

## License

Private - PnotP Platform
