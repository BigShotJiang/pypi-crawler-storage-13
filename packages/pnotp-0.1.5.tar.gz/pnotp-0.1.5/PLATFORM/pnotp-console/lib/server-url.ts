import { headers } from "next/headers"

export async function getAbsoluteUrl(path: string) {
  const headerList = await headers()
  const proto = headerList.get("x-forwarded-proto") ?? "https"
  const host =
    headerList.get("x-forwarded-host") ??
    headerList.get("host") ??
    process.env.NEXT_PUBLIC_APP_URL ??
    "localhost:3000"

  return `${proto}://${host}${path.startsWith("/") ? path : `/${path}`}`
}
