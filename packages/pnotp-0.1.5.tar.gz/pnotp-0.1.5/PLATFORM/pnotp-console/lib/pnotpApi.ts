import { auth } from "@clerk/nextjs/server"
import { SIGN_IN_REQUIRED_ERROR } from "@/lib/authErrors"
import type { ApiKeyRecord, BillingOverview, DashboardMetrics, ModelCatalogResponse, SubscriptionRecord } from "@/lib/pnotpTypes"

function sanitizeBaseUrl(url: string) {
  return url.replace(/\/$/, "")
}

let cachedServerBaseUrl: string | null = null

function getServerApiBaseUrl() {
  if (cachedServerBaseUrl) {
    return cachedServerBaseUrl
  }

  const base = process.env.PNOTP_API_URL ?? process.env.NEXT_PUBLIC_PNOTP_API_URL
  if (!base) {
    throw new Error("PNOTP_API_URL (or NEXT_PUBLIC_PNOTP_API_URL) is not configured")
  }

  cachedServerBaseUrl = sanitizeBaseUrl(base)
  return cachedServerBaseUrl
}

async function getClerkToken() {
  const authResult = await auth()
  const getToken = authResult.getToken

  if (!getToken || !authResult.userId) {
    throw new Error(SIGN_IN_REQUIRED_ERROR)
  }

  const token = await getToken()
  if (!token) {
    throw new Error(SIGN_IN_REQUIRED_ERROR)
  }

  return token
}

async function pnotpFetch<T>(path: string, init?: RequestInit) {
  const bearer = await getClerkToken()
  const response = await fetch(`${getServerApiBaseUrl()}${path}`, {
    cache: "no-store",
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${bearer}`,
      ...(init?.headers ?? {}),
    },
  })

  const text = await response.text()
  const data = text ? (JSON.parse(text) as unknown) : null

  if (!response.ok) {
    const message = (data as { error?: string } | null)?.error ?? response.statusText
    throw new Error(message)
  }

  return data as T
}

export async function getApiKeys() {
  const data = await pnotpFetch<{ apiKeys: ApiKeyRecord[] }>("/api-keys")
  return data.apiKeys
}

export async function getDashboardMetrics() {
  return pnotpFetch<DashboardMetrics>("/dashboard/metrics")
}

export async function getModelCatalog() {
  return pnotpFetch<ModelCatalogResponse>("/models")
}

export async function getBillingOverview() {
  return pnotpFetch<BillingOverview>("/billing")
}

export async function createRemoteSubscription(tier: string) {
  const data = await pnotpFetch<{ subscription: SubscriptionRecord }>("/subscriptions", {
    method: "POST",
    body: JSON.stringify({ tier }),
  })
  return data.subscription
}

export async function cancelRemoteSubscription(subscriptionId: string) {
  return pnotpFetch(`/subscriptions/${subscriptionId}/cancel`, {
    method: "POST",
  })
}

export async function submitRemoteCustomModelRequest(payload: {
  domain: string
  problemDescription: string
  dataDescription: string
  contactEmail: string
}) {
  await pnotpFetch("/custom-model-requests", {
    method: "POST",
    body: JSON.stringify(payload),
  })
}
