export type ApiKeyRecord = {
  id: string
  label: string | null
  tier: string
  fingerprint: string
  createdAt: string
}

export type PnotpModel = {
  id: string
  modelId: string
  name: string
  description: string
  tier: string
  priceUsd: number
  accuracy: number
  f1Score: number
  auc: number
  inputType: string
  outputType: string
  latencyMs: number
  status: string
  industry: string
}

export type SubscriptionRecord = {
  id: string
  tier: string
  status: string
  startedAt: string
  renewalDate: string | null
  canceledAt: string | null
}

export type TierPlan = {
  tier: string
  label: string
  priceUsd: number
  description: string
  modelName?: string
  modelId?: string
}

export type BillingOverview = {
  subscription: SubscriptionRecord | null
  plans: TierPlan[]
}

export type ModelCatalogResponse = {
  models: PnotpModel[]
  subscribedTiers: string[]
}

export type DashboardMetrics = {
  apiKeyCount: number
  modelCount: number
  subscriptionCount: number
}
