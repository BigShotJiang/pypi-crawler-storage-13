export const SIGN_IN_REQUIRED_ERROR = "SIGN_IN_REQUIRED"

export function isSignInRequiredError(error: unknown): error is Error {
  return error instanceof Error && error.message === SIGN_IN_REQUIRED_ERROR
}
