"use client"

export function promptSignIn(message: string) {
  if (message) {
    alert(message)
  }
  const redirectTarget = encodeURIComponent(window.location.href)
  window.location.href = `/sign-in?redirect_url=${redirectTarget}`
}
