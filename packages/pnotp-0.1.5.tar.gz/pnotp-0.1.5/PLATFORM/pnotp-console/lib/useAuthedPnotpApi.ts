"use client"

import { useAuth } from "@clerk/nextjs"
import { useCallback, useMemo } from "react"
import { SIGN_IN_REQUIRED_ERROR } from "@/lib/authErrors"

function sanitizeBaseUrl(url: string) {
  return url.replace(/\/$/, "")
}

function getClientApiBaseUrl() {
  if (process.env.NEXT_PUBLIC_PNOTP_API_URL) {
    return sanitizeBaseUrl(process.env.NEXT_PUBLIC_PNOTP_API_URL)
  }
  throw new Error("NEXT_PUBLIC_PNOTP_API_URL is not configured")
}

type AuthedFetch = <T>(path: string, init?: RequestInit) => Promise<T>

export function useAuthedPnotpApi(): AuthedFetch {
  const { getToken, isLoaded, isSignedIn } = useAuth()
  const baseUrl = useMemo(() => getClientApiBaseUrl(), [])

  return useCallback(
    async <T>(path: string, init?: RequestInit) => {
      if (!isLoaded) {
        throw new Error("Authentication context is still loading. Please try again.")
      }

      if (!isSignedIn) {
        throw new Error(SIGN_IN_REQUIRED_ERROR)
      }

      const token = await getToken()
      if (!token) {
        throw new Error(SIGN_IN_REQUIRED_ERROR)
      }

      const response = await fetch(`${baseUrl}${path}`, {
        cache: "no-store",
        ...init,
        headers: {
          "Content-Type": "application/json",
          ...(init?.headers ?? {}),
          Authorization: `Bearer ${token}`,
        },
      })

      const text = await response.text()
      const data = text ? (JSON.parse(text) as unknown) : null

      if (!response.ok) {
        const message = (data as { error?: string } | null)?.error ?? response.statusText
        throw new Error(message)
      }

      return data as T
    },
    [baseUrl, getToken, isLoaded, isSignedIn],
  ) as AuthedFetch
}
