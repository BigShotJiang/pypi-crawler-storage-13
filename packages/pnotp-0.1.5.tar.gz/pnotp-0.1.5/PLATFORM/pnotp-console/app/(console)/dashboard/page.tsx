import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getDashboardMetrics } from "@/lib/pnotpApi"
import { LogicDivider } from "@/components/brand/logic-divider"
import { PageHeading } from "@/components/brand/page-heading"
import { SignInCallout } from "@/components/auth/sign-in-callout"
import { isSignInRequiredError } from "@/lib/authErrors"
import { getAbsoluteUrl } from "@/lib/server-url"

const designPrinciples = [
  { title: "Mathematical Precision", detail: "Integer-based layouts, orthogonal alignments, and no fractional pixels." },
  { title: "Binary Aesthetics", detail: "Pure #000000 and #FFFFFF fills only; #C6C6C6 reserved for dividers." },
  { title: "Geometric Rigor", detail: "Strict 90° intersections, no rounded corners, no ornamental curves." },
  { title: "Formal Logic", detail: "Visual cues borrowed from logical notation (¬, ⊢, ⟂) to signify structure." },
  { title: "Systematic Purpose", detail: "Every component communicates hierarchy, provenance, or action explicitly." },
]

const brandValues = [
  "Precision-first infrastructure",
  "Transparent, auditable AI",
  "Opposition to arbitrary complexity",
  "Foundational rigor over decoration",
]

const actionCards = [
  {
    title: "Generate API Keys",
    description: "Provision secure credentials for accessing the full catalogue of P¬P models.",
    href: "/api-keys",
    cta: "Manage Keys",
  },
  {
    title: "Browse Model Catalog",
    description: "Inspect Expert → Viable tiers, accuracy metrics, and subscription eligibility.",
    href: "/models",
    cta: "Open Catalog",
  },
]

const colorSystem = [
  { name: "Pure Black", hex: "#000000" },
  { name: "Pure White", hex: "#FFFFFF" },
]

const typographySpecs = [
  { label: "Primary Typeface", value: "Inter Medium 500" },
  { label: "Body Typeface", value: "Inter Regular 400" },
  { label: "Letter Spacing", value: "+0.02em for headings" },
  { label: "Code", value: "Geist Mono / SF Mono" },
]

const logicSymbols: Array<"¬" | "⊢" | "⟂"> = ["¬", "⊢", "⟂"]

export default async function DashboardPage() {
  const [metrics, redirectTarget] = await Promise.all([
    getDashboardMetrics().catch((error) => {
      if (isSignInRequiredError(error)) {
        return null
      }
      throw error
    }),
    getAbsoluteUrl("/dashboard"),
  ])

  return (
    <div className="space-y-10">
      <PageHeading
        title="P¬P Developer Console"
        description="Administrative surface for issuing credentials, auditing subscriptions, and aligning deployments with the P¬P logical system."
        meta={[
          "Scope: Developer Infrastructure",
          "Discipline: Formal Logic Interfaces",
          "Release: Version 1.0",
        ]}
      />

      {!metrics && (
        <SignInCallout
          message="Sign in to view live dashboard metrics and private data."
          redirectUrl={redirectTarget}
        />
      )}

      {metrics && (
        <section>
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>API Keys</CardTitle>
              <CardDescription>Total credentials issued</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-medium tracking-[0.08em]">{metrics.apiKeyCount}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Models</CardTitle>
              <CardDescription>Entries in the catalog</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-medium tracking-[0.08em]">{metrics.modelCount}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Active Subscriptions</CardTitle>
              <CardDescription>Contracts in good standing</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-medium tracking-[0.08em]">{metrics.subscriptionCount}</p>
            </CardContent>
          </Card>
        </div>
      </section>
      )}

      <LogicDivider symbol="⊢" />

      <section className="grid gap-6 md:grid-cols-2">
        {actionCards.map((card) => (
          <Card key={card.title}>
            <CardHeader>
              <CardTitle>{card.title}</CardTitle>
              <CardDescription>{card.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild>
                <Link href={card.href}>{card.cta}</Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </section>

      <LogicDivider symbol="⟂" />

      <section className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Design Principles</CardTitle>
            <CardDescription>P¬P visual governance</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="logic-list">
              {designPrinciples.map((principle, index) => (
                <li key={principle.title} data-symbol={logicSymbols[index % logicSymbols.length]}>
                  <div>
                    <p className="font-medium uppercase tracking-[0.1em]">{principle.title}</p>
                    <p className="text-black/70">{principle.detail}</p>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Brand Values</CardTitle>
            <CardDescription>North stars for every release</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <ul className="logic-list">
              {brandValues.map((value, index) => (
                <li key={value} data-symbol={logicSymbols[(index + 1) % logicSymbols.length]}>
                  {value}
                </li>
              ))}
            </ul>
            <div className="grid gap-4">
              <div>
                <p className="text-xs uppercase tracking-[0.25em] text-black/60">Color System</p>
                <div className="mt-3 grid grid-cols-2 gap-3">
                  {colorSystem.map((color) => (
                    <div key={color.name} className="border border-black p-4">
                      <div
                        className="h-16 border border-black"
                        style={{ backgroundColor: color.hex }}
                      />
                      <p className="mt-2 text-sm font-medium">{color.name}</p>
                      <p className="text-xs tracking-[0.1em] text-black/60">{color.hex}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.25em] text-black/60">Typography</p>
                <div className="mt-3 grid gap-2">
                  {typographySpecs.map((item) => (
                    <div key={item.label} className="flex justify-between text-sm">
                      <span className="text-black/60">{item.label}</span>
                      <span className="font-medium">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
