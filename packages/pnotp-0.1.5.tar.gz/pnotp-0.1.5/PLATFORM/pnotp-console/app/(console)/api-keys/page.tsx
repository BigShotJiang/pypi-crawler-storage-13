import { PageHeading } from "@/components/brand/page-heading"
import { ApiKeysClient } from "./api-keys-client"
import { getApiKeys } from "@/lib/pnotpApi"
import { SignInCallout } from "@/components/auth/sign-in-callout"
import { isSignInRequiredError } from "@/lib/authErrors"
import { getAbsoluteUrl } from "@/lib/server-url"

export default async function ApiKeysPage() {
  const [apiKeys, redirectTarget] = await Promise.all([
    getApiKeys().catch((error) => {
      if (isSignInRequiredError(error)) {
        return null
      }
      throw error
    }),
    getAbsoluteUrl("/api-keys"),
  ])

  return (
    <div className="space-y-8">
      <PageHeading
        title="API Keys"
        description="Issue, archive, and audit access tokens. Keys are rendered once and must respect the binary color protocol when shared."
        meta={["Min size: 16px digital", "Clear space: 56%", "Format: Plaintext only"]}
        symbol="⊢"
      />

      {apiKeys ? (
        <ApiKeysClient apiKeys={apiKeys} />
      ) : (
        <SignInCallout
          message="Sign in to generate or review API keys."
          redirectUrl={redirectTarget}
        />
      )}
    </div>
  )
}
