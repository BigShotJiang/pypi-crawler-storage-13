"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Copy, Check } from "lucide-react"
import type { ApiKeyRecord } from "@/lib/pnotpTypes"
import { useAuthedPnotpApi } from "@/lib/useAuthedPnotpApi"
import { isSignInRequiredError } from "@/lib/authErrors"
import { promptSignIn } from "@/lib/signInRedirect"

type ApiKeysClientProps = {
  apiKeys: ApiKeyRecord[]
}

const codeSnippet = `import pnotp as pnp

client = pnp.client(api_key="PASTE_YOUR_KEY_HERE")
client.models()
model = client.models(model="pneumonia_binary_classification")
result = model.predict("path/to/image.jpg")
print(result)`

export function ApiKeysClient({ apiKeys: initialApiKeys }: ApiKeysClientProps) {
  const apiKeys = initialApiKeys
  const router = useRouter()
  const pnotpFetch = useAuthedPnotpApi()
  const [label, setLabel] = useState("")
  const [loading, setLoading] = useState(false)
  const [generatedKey, setGeneratedKey] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const handleGenerate = async () => {
    const trimmed = label.trim()
    if (!trimmed) {
      alert("Please enter a label for your API key")
      return
    }

    setLoading(true)
    try {
      const data = await pnotpFetch<{ apiKey: string }>("/api-keys", {
        method: "POST",
        body: JSON.stringify({ label: trimmed }),
      })
      setGeneratedKey(data.apiKey ?? null)
      setLabel("")
      router.refresh()
    } catch (error) {
      if (isSignInRequiredError(error)) {
        promptSignIn("Sign in to generate API keys.")
        return
      }
      console.error("Error generating API key:", error)
      alert(error instanceof Error ? error.message : "Failed to generate API key")
    } finally {
      setLoading(false)
    }
  }

  const handleCopy = async () => {
    if (generatedKey) {
      await navigator.clipboard.writeText(generatedKey)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleDelete = async (apiKeyId: string) => {
    const confirmed = window.confirm("Delete this API key? This action cannot be undone.")
    if (!confirmed) {
      return
    }

    setDeletingId(apiKeyId)
    try {
      await pnotpFetch(`/api-keys/${apiKeyId}`, {
        method: "DELETE",
      })
      router.refresh()
    } catch (error) {
      if (isSignInRequiredError(error)) {
        promptSignIn("Sign in to manage API keys.")
        return
      }
      console.error("Error deleting API key:", error)
      alert(error instanceof Error ? error.message : "Failed to delete API key")
    } finally {
      setDeletingId(null)
    }
  }

  const handleCopyCode = async () => {
    await navigator.clipboard.writeText(codeSnippet)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Generate New API Key</CardTitle>
          <CardDescription>Keys render once. Archive locally per your governance policy.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col gap-4 md:flex-row">
            <Input
              placeholder="Label (e.g., PRODUCTION)"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleGenerate()
                }
              }}
            />
            <Button onClick={handleGenerate} disabled={loading || !label.trim()}>
              {loading ? "Generating" : "Generate"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {apiKeys.length > 0 && (
        <div className="space-y-3">
          <p className="text-xs uppercase tracking-[0.25em] text-black/60">Existing Keys</p>
          <div className="space-y-3">
            {apiKeys.map((key) => (
              <Card key={key.id}>
                <CardContent className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-medium tracking-[0.1em] uppercase">
                      {key.label || "UNLABELED"}
                    </p>
                    <p className="text-xs text-black/60">
                      Tier: {key.tier.toUpperCase()} • Fingerprint ****{key.fingerprint}
                    </p>
                    <p className="text-xs text-black/50">
                      Created {new Date(key.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => handleDelete(key.id)}
                    disabled={deletingId === key.id}
                    className="rounded-none border-black text-black hover:bg-black hover:text-white disabled:opacity-60"
                  >
                    {deletingId === key.id ? "Deleting..." : "Delete"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Client Example</CardTitle>
          <CardDescription>Python reference implementation (pnotp)</CardDescription>
        </CardHeader>
        <CardContent>
          <pre className="overflow-x-auto border border-black bg-black p-4 text-white">
            <code>{codeSnippet}</code>
          </pre>
          <Button onClick={handleCopyCode} variant="outline" className="mt-4">
            {copied ? (
              <>
                <Check className="size-4" /> Copied
              </>
            ) : (
              <>
                <Copy className="size-4" /> Copy Snippet
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <Dialog open={!!generatedKey} onOpenChange={() => setGeneratedKey(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>API Key Generated</DialogTitle>
            <DialogDescription>Copy and store securely. This value will not be shown again.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="border border-black bg-black p-4">
              <code className="text-white break-all">{generatedKey}</code>
            </div>
            <Button onClick={handleCopy} className="w-full">
              {copied ? (
                <>
                  <Check className="size-4" /> Copied
                </>
              ) : (
                <>
                  <Copy className="size-4" /> Copy Key
                </>
              )}
            </Button>
            <div className="border border-black bg-black p-4">
              <pre className="text-xs text-white">
                <code>{codeSnippet}</code>
              </pre>
            </div>
            <Button onClick={handleCopyCode} variant="outline" className="w-full">
              Copy Code Snippet
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
