import { currentUser } from "@clerk/nextjs/server"
import { getApiKeys } from "@/lib/pnotpApi"
import { SignInCallout } from "@/components/auth/sign-in-callout"
import { getAbsoluteUrl } from "@/lib/server-url"
import type { ApiKeyRecord } from "@/lib/pnotpTypes"
import { AccountActions } from "@/components/account/account-actions"

export default async function AccountPage() {
  const user = await currentUser()

  if (!user) {
    const redirectTarget = await getAbsoluteUrl("/account")
    return (
      <div className="py-10">
        <SignInCallout
          message="Sign in to manage your account and security settings."
          redirectUrl={redirectTarget}
        />
      </div>
    )
  }

  let apiKeys: ApiKeyRecord[] = []
  try {
    apiKeys = await getApiKeys()
  } catch {
    apiKeys = []
  }

  return (
    <div className="space-y-8">
      <section className="rounded-3xl border border-black bg-white p-8 text-black">
        <div className="space-y-4">
          <p className="text-xs uppercase tracking-[0.3em] text-black/50">Account Identity</p>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <p className="text-[11px] uppercase tracking-[0.2em] text-black/50">Email</p>
              <p className="text-lg font-medium">{user.primaryEmailAddress?.emailAddress}</p>
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-[0.2em] text-black/50">User ID</p>
              <p className="font-mono text-sm text-black/80">{user.id}</p>
            </div>
          </div>
          <div className="border-t border-black/20 pt-4">
            <AccountActions />
          </div>
        </div>
      </section>

      <section className="rounded-3xl border border-black bg-white p-8">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-black/60">API Keys</p>
            <p className="text-sm text-black/60">Read-only preview of existing credentials.</p>
          </div>
        </div>
        <div className="mt-6 space-y-3">
          {apiKeys.length === 0 && (
            <p className="text-sm text-black/60">No API keys issued under this user.</p>
          )}
          {apiKeys.map((key) => (
            <div
              key={key.id}
              className="grid gap-4 rounded-2xl border border-black px-4 py-3 text-sm md:grid-cols-4"
            >
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-black/60">Label</p>
                <p className="font-medium">{key.label ?? "Unlabeled key"}</p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-black/60">Tier</p>
                <p className="font-medium">{key.tier.toUpperCase()}</p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-black/60">Fingerprint</p>
                <p className="font-mono text-sm">****{key.fingerprint}</p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-black/60">Created</p>
                <p>{new Date(key.createdAt).toLocaleDateString()}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
