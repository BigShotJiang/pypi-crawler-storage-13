"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SubscribeDialogButton } from "@/components/billing/subscribe-dialog";
import type { PnotpModel } from "@/lib/pnotpTypes";

type ModelsClientProps = {
  models: PnotpModel[];
  subscribedTiers: string[];
};

const tiers = ["Expert", "Premium", "MVP", "Viable"];
const industries = ["All", "Medicine", "Ophthalmology"];

export function ModelsClient({ models, subscribedTiers }: ModelsClientProps) {
  const [selectedIndustry, setSelectedIndustry] = useState("All");
  const normalizedSubscriptions = subscribedTiers.map((tier) => tier.toLowerCase());

  const filteredModels = models.filter(
    (model) => selectedIndustry === "All" || model.industry === selectedIndustry
  );

  const groupedModels = tiers.reduce((acc, tier) => {
    acc[tier] = filteredModels.filter((m) => m.tier === tier);
    return acc;
  }, {} as Record<string, PnotpModel[]>);

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4">
        <label className="inline-flex items-center bg-black px-3 py-1 text-sm text-white">
          Filter by industry:
        </label>
        <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
          <SelectTrigger className="w-48 rounded-none border-[#C6C6C6] bg-white">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="rounded-none border-[#C6C6C6] bg-white">
            {industries.map((industry) => (
              <SelectItem key={industry} value={industry} className="rounded-none">
                {industry}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {tiers.map((tier) => {
        const tierModels = groupedModels[tier] || [];
        if (tierModels.length === 0) return null;

        return (
          <div key={tier} className="space-y-4">
            <h2 className="inline-block bg-black px-3 py-1 text-2xl font-medium text-white">
              {tier} Tier
            </h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {tierModels.map((model) => {
                const isSubscribed = normalizedSubscriptions.includes(model.tier.toLowerCase());

                return (
                  <Card
                    key={model.id}
                    className="rounded-none border-[#C6C6C6] bg-white shadow-none"
                  >
                    <CardHeader>
                      <CardTitle className="text-lg">{model.name}</CardTitle>
                      <CardDescription className="text-xs">
                        {model.modelId}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm text-black/80">{model.description}</p>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-black/60">Price:</span>
                          <span className="font-medium">${model.priceUsd}/month</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-black/60">Accuracy:</span>
                          <span className="font-medium">{(model.accuracy * 100).toFixed(1)}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-black/60">F1 Score:</span>
                          <span className="font-medium">{model.f1Score.toFixed(3)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-black/60">AUC:</span>
                          <span className="font-medium">{model.auc.toFixed(3)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-black/60">Industry:</span>
                          <span className="font-medium">{model.industry}</span>
                        </div>
                      </div>
                      <SubscribeDialogButton
                        tier={model.tier.toLowerCase()}
                        label={model.name}
                        priceUsd={model.priceUsd}
                        description={model.description}
                        disabled={isSubscribed}
                        disabledLabel="Subscribed"
                        triggerClassName="w-full rounded-none bg-black text-white hover:bg-black/90 disabled:opacity-60"
                      />
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}
