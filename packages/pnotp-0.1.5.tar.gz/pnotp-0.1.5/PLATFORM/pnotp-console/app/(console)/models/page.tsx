import { PageHeading } from "@/components/brand/page-heading"
import { ModelsClient } from "./models-client"
import { getModelCatalog } from "@/lib/pnotpApi"
import { SignInCallout } from "@/components/auth/sign-in-callout"
import { isSignInRequiredError } from "@/lib/authErrors"
import { getAbsoluteUrl } from "@/lib/server-url"

export default async function ModelsPage() {
  const [catalog, redirectTarget] = await Promise.all([
    getModelCatalog().catch((error) => {
      if (isSignInRequiredError(error)) {
        return null
      }
      throw error
    }),
    getAbsoluteUrl("/models"),
  ])

  return (
    <div className="space-y-8">
      <PageHeading
        title="Model Catalog"
        description="Filter tiers, enforce industry scope, and subscribe through the binary interface."
        meta={["Tiers: Expert, Premium, MVP, Viable", "Icons: 16–256px", "Format: SVG" ]}
        symbol="⟂"
      />

      {catalog ? (
        <ModelsClient models={catalog.models} subscribedTiers={catalog.subscribedTiers} />
      ) : (
        <SignInCallout
          message="Sign in to inspect the full model catalog."
          redirectUrl={redirectTarget}
        />
      )}
    </div>
  )
}
