import Link from "next/link"
import { PageHeading } from "@/components/brand/page-heading"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const sections = [
  {
    title: "Explore Models",
    description: "Browse the catalog of Expert → Viable models and request subscriptions.",
    href: "/models",
  },
  {
    title: "Generate API Keys",
    description: "Issue new credentials or review existing prefixes.",
    href: "/api-keys",
  },
  {
    title: "Manage Billing",
    description: "Audit subscriptions, recent charges, and invoices.",
    href: "/billing",
  },
  {
    title: "Custom Requests",
    description: "Submit new domain briefs and data availability details.",
    href: "/custom-models",
  },
]

export default function HomePage() {
  return (
    <div className="space-y-10">
      <PageHeading
        label="P¬P Console"
        title="Developer Console Overview"
        description="Navigate the dashboard, inspect model catalogs, and manage subscriptions. Authentication is only required when performing account-sensitive actions."
        meta={["Access: Public browsing", "Actions: Auth required", "Runtime: Edge"]}
        symbol="⊢"
      />

      <div className="grid gap-6 md:grid-cols-2">
        {sections.map((section) => (
          <Card key={section.title} className="rounded-none border-black">
            <CardHeader>
              <CardTitle>{section.title}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-black/70">{section.description}</p>
              <Button asChild className="rounded-none">
                <Link href={section.href}>Open</Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
