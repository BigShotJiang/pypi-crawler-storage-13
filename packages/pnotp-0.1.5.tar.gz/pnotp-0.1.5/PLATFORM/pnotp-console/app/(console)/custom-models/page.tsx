import { PageHeading } from "@/components/brand/page-heading"
import { CustomModelsForm } from "./custom-models-form"

export default function CustomModelsPage() {
  return (
    <div className="space-y-8">
      <PageHeading
        title="Custom Model Request"
        description="Document your domain, objective, data availability, and contact protocol. Requests inherit the same binary identity system."
        meta={["Response SLA: 48h", "Formats: PDF/SVG briefs", "Contact: brand@pnotp.ai"]}
        symbol="¬"
      />

      <CustomModelsForm />
    </div>
  )
}
