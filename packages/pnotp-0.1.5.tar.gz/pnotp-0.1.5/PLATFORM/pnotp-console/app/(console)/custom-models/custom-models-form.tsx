"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { useAuthedPnotpApi } from "@/lib/useAuthedPnotpApi"
import { isSignInRequiredError } from "@/lib/authErrors"
import { promptSignIn } from "@/lib/signInRedirect"

const domains = ["Medicine", "Finance", "Agriculture", "Other"]

export function CustomModelsForm() {
  const pnotpFetch = useAuthedPnotpApi()
  const [domain, setDomain] = useState("")
  const [problemDescription, setProblemDescription] = useState("")
  const [dataDescription, setDataDescription] = useState("")
  const [contactEmail, setContactEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!domain || !problemDescription || !dataDescription || !contactEmail) {
      alert("Please fill in all fields")
      return
    }

    setLoading(true)
    try {
      await pnotpFetch("/custom-model-requests", {
        method: "POST",
        body: JSON.stringify({
          domain,
          problemDescription,
          dataDescription,
          contactEmail,
        }),
      })
      setSuccess(true)
      setDomain("")
      setProblemDescription("")
      setDataDescription("")
      setContactEmail("")
    } catch (error) {
      if (isSignInRequiredError(error)) {
        promptSignIn("Sign in to submit a custom model request.")
        return
      }
      console.error("Error submitting request:", error)
      alert("Failed to submit request. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <Card>
        <CardContent className="py-12 text-center space-y-4">
          <h2 className="text-2xl tracking-[0.08em]">Request Submitted</h2>
          <p className="text-black/70">We received your brief. Expect a response within 48 hours.</p>
          <Button onClick={() => setSuccess(false)}>Submit Another Request</Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Submit Custom Model Request</CardTitle>
        <CardDescription>Document the problem, data, and point of contact.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="domain">Domain</Label>
            <Select value={domain} onValueChange={setDomain}>
              <SelectTrigger id="domain">
                <SelectValue placeholder="Select a domain" />
              </SelectTrigger>
              <SelectContent>
                {domains.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="problem">Problem Description</Label>
            <Textarea
              id="problem"
              placeholder="Describe the decision boundary, KPIs, and rollout requirements."
              value={problemDescription}
              onChange={(e) => setProblemDescription(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="data">Data Description</Label>
            <Textarea
              id="data"
              placeholder="Document formats, sample sizes, annotation quality, and privacy constraints."
              value={dataDescription}
              onChange={(e) => setDataDescription(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Contact Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="your@email.com"
              value={contactEmail}
              onChange={(e) => setContactEmail(e.target.value)}
              required
            />
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Submitting" : "Submit Request"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
