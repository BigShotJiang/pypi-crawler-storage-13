"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { SubscribeDialogButton } from "@/components/billing/subscribe-dialog"
import type { SubscriptionRecord, TierPlan } from "@/lib/pnotpTypes"
import { useAuthedPnotpApi } from "@/lib/useAuthedPnotpApi"
import { isSignInRequiredError } from "@/lib/authErrors"
import { promptSignIn } from "@/lib/signInRedirect"

type BillingClientProps = {
  subscription: SubscriptionRecord | null
  plans: TierPlan[]
}

export function BillingClient({ subscription, plans }: BillingClientProps) {
  const router = useRouter()
  const pnotpFetch = useAuthedPnotpApi()
  const [cancelLoading, setCancelLoading] = useState(false)

  const handleCancel = async () => {
    if (!subscription) {
      return
    }

    setCancelLoading(true)
    try {
      await pnotpFetch(`/subscriptions/${subscription.id}/cancel`, {
        method: "POST",
      })
      router.refresh()
    } catch (error) {
      if (isSignInRequiredError(error)) {
        promptSignIn("Sign in to manage billing.")
        return
      }
      console.error("Failed to cancel subscription:", error)
      alert("Failed to cancel subscription. Please try again.")
    } finally {
      setCancelLoading(false)
    }
  }

  return (
    <div className="space-y-10">
      <section>
        <h2 className="inline-block bg-black px-3 py-1 text-2xl font-medium text-white">
          Current Subscription
        </h2>
        <Card className="mt-4 rounded-none border-[#C6C6C6] bg-white shadow-none">
          <CardHeader>
            <CardTitle className="text-lg">
              {subscription ? subscription.tier.toUpperCase() : "No active tier"}
            </CardTitle>
            <CardDescription className="text-xs">
              {subscription
                ? `Status: ${subscription.status.toUpperCase()}`
                : "Choose a tier below to activate access."}
            </CardDescription>
          </CardHeader>
          {subscription && (
            <CardContent className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-black/60">Started</span>
                <span className="font-medium">{formatDate(subscription.startedAt)}</span>
              </div>
              {subscription.renewalDate && (
                <div className="flex justify-between">
                  <span className="text-black/60">Next renewal</span>
                  <span className="font-medium">{formatDate(subscription.renewalDate)}</span>
                </div>
              )}
              <Button
                variant="outline"
                onClick={handleCancel}
                disabled={cancelLoading}
                className="mt-4 w-full rounded-none border-black text-black hover:bg-black hover:text-white disabled:opacity-50"
              >
                {cancelLoading ? "Canceling..." : "Cancel subscription"}
              </Button>
            </CardContent>
          )}
          {!subscription && (
            <CardContent className="text-sm text-black/70">
              Activating a tier unlocks P¬P API access aligned with that plan&apos;s guarantees.
            </CardContent>
          )}
        </Card>
      </section>

      <section className="space-y-4">
        <h2 className="inline-block bg-black px-3 py-1 text-2xl font-medium text-white">Plans</h2>
        <div className="grid gap-4 md:grid-cols-2">
          {plans.map((plan) => (
            <Card key={plan.tier} className="rounded-none border-[#C6C6C6] bg-white shadow-none">
              <CardHeader>
                <CardTitle className="text-lg">{plan.label}</CardTitle>
                <CardDescription className="text-xs">
                  ${plan.priceUsd}/month • {plan.modelName ?? "P¬P lab access"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <p className="text-black/70">{plan.description}</p>
                <SubscribeDialogButton
                  tier={plan.tier}
                  label={plan.label}
                  priceUsd={plan.priceUsd}
                  description={plan.modelName ?? ""}
                  disabled={plan.tier === subscription?.tier}
                  disabledLabel="Current tier"
                  triggerClassName="w-full rounded-none bg-black text-white hover:bg-black/90 disabled:opacity-60 disabled:hover:bg-black"
                />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}

function formatDate(value: string) {
  const date = new Date(value)
  return date.toLocaleDateString(undefined, {
    month: "long",
    day: "numeric",
    year: "numeric",
  })
}
