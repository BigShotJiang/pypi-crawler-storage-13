import { getBillingOverview } from "@/lib/pnotpApi"
import { BillingClient } from "./billing-client"
import { PageHeading } from "@/components/brand/page-heading"
import { SignInCallout } from "@/components/auth/sign-in-callout"
import { isSignInRequiredError } from "@/lib/authErrors"
import { getAbsoluteUrl } from "@/lib/server-url"

export default async function BillingPage() {
  const [overview, redirectTarget] = await Promise.all([
    getBillingOverview().catch((error) => {
      if (isSignInRequiredError(error)) {
        return null
      }
      throw error
    }),
    getAbsoluteUrl("/billing"),
  ])

  return (
    <div className="space-y-8">
      <PageHeading
        title="Billing"
        description="Manage your active P¬P subscription tier and review available plans."
        meta={["Status: Live", "Billing cadence: Monthly", "Processor: Coming soon"]}
        symbol="⊢"
      />

      {!overview && (
        <SignInCallout
          message="Sign in to view billing details and manage subscriptions."
          redirectUrl={redirectTarget}
        />
      )}

      {overview && (
        <BillingClient subscription={overview.subscription} plans={overview.plans} />
      )}
    </div>
  )
}
