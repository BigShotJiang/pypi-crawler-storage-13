import Link from "next/link"
import { AuthControls } from "@/components/console/auth-controls"
import { AccountNavItem } from "@/components/console/account-nav-item"

export const dynamic = "force-dynamic"
export const runtime = "edge"

const navigation = [
  { name: "Dashboard", href: "/dashboard" },
  { name: "Models", href: "/models" },
  { name: "API Keys", href: "/api-keys" },
  { name: "Billing", href: "/billing" },
  { name: "Custom Models", href: "/custom-models" },
]

const logicSymbols: Array<"¬" | "⊢" | "⟂"> = ["¬", "⊢", "⟂"]

function Sidebar() {
  return (
    <div className="flex h-screen w-72 flex-col border-r border-black bg-white text-black">
      <div className="border-b border-black px-6 py-8">
        <Link href="/" className="text-4xl font-medium tracking-[0.08em]">
          P¬P
        </Link>
        <p className="mt-3 text-xs uppercase tracking-[0.3em] text-black/70">
          AI Infrastructure Lab
        </p>
        <p className="text-[10px] tracking-[0.35em] text-black/50">
          Version 1.0 • November 2024
        </p>
      </div>
      <nav className="flex-1 divide-y divide-black/40">
        {navigation.map((item, index) => (
          <Link
            key={item.name}
            href={item.href}
            className="flex items-center justify-between px-6 py-5 text-xs font-medium uppercase tracking-[0.25em] transition-colors hover:bg-black hover:text-white"
          >
            <span className="flex items-center gap-3">
              <span className="font-mono text-base">
                {logicSymbols[index % logicSymbols.length]}
              </span>
              {item.name}
            </span>
            <span className="text-[10px]">⟂</span>
          </Link>
        ))}
        <AccountNavItem />
      </nav>
      <div className="border-t border-black px-6 py-8 text-xs leading-relaxed text-black/70">
        <p>P¬P AI Lab</p>
        <p>brand@pnotp.ai</p>
        <p>www.pnotp.ai</p>
      </div>
    </div>
  )
}

export default function ConsoleLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen bg-white">
      <Sidebar />
      <main className="flex-1 overflow-y-auto border-l border-black bg-white">
        <div className="flex justify-end border-b border-black/40 bg-white px-10 py-5">
          <AuthControls />
        </div>
        <div className="mx-auto max-w-6xl px-10 py-12 space-y-10">{children}</div>
      </main>
    </div>
  )
}
