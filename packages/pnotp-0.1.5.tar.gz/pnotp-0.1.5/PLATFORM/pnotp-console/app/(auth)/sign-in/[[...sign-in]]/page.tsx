import { SignIn } from "@clerk/nextjs"
import { auth } from "@clerk/nextjs/server"
import { redirect } from "next/navigation"
import type { Metadata } from "next"

type SignInPageProps = {
  searchParams?: {
    redirect_url?: string
  }
}

const appearance = {
  variables: {
    colorBackground: "#ffffff",
    colorText: "#050505",
    borderRadius: "1.5rem",
    fontFamily: "Space Grotesk, system-ui, sans-serif",
  },
  elements: {
    rootBox: "w-full max-w-lg rounded-[32px] border border-black bg-white shadow-[0_20px_60px_rgba(0,0,0,0.08)]",
    card: "bg-white border-0 rounded-[32px] text-black",
    headerTitle: "text-2xl font-semibold tracking-[0.14em] uppercase text-black",
    headerSubtitle: "text-sm text-black/60",
    socialButtonsBlockButton:
      "rounded-2xl border border-black/30 bg-white text-black hover:bg-black hover:text-white",
    formFieldLabel: "text-xs font-medium uppercase tracking-[0.2em] text-black/50",
    formFieldInput:
      "bg-white border border-black px-4 py-2 text-sm text-black rounded-2xl focus:border-black focus:ring-0",
    formButtonPrimary:
      "bg-black text-white rounded-2xl px-4 py-2 text-sm font-semibold tracking-[0.2em] hover:bg-black/80",
    footerAction__signIn: "text-xs text-black/60",
  },
}

function getRedirectTarget(param?: string) {
  if (!param) {
    return "/dashboard"
  }
  try {
    const decoded = decodeURIComponent(param)
    return decoded || "/dashboard"
  } catch {
    return "/dashboard"
  }
}

export const metadata: Metadata = {
  title: "Sign In - P¬P Console",
}

export default async function SignInPage({ searchParams }: SignInPageProps) {
  const { userId } = await auth()
  const redirectTarget = getRedirectTarget(searchParams?.redirect_url)

  if (userId) {
    redirect(redirectTarget || "/dashboard")
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#f8f8f8] px-4 text-black">
      <SignIn
        routing="path"
        path="/sign-in"
        signUpUrl="/sign-up"
        afterSignInUrl={redirectTarget}
        redirectUrl={redirectTarget}
        appearance={appearance}
      />
    </div>
  )
}
