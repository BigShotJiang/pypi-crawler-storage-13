import { clerkMiddleware } from "@clerk/nextjs/server"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

function buildRedirectUrl(request: NextRequest) {
  const signInUrl = new URL("/sign-in", request.url)
  signInUrl.searchParams.set("redirect_url", request.nextUrl.href)
  return signInUrl.toString()
}

export default clerkMiddleware(async (auth, request) => {
  if (request.nextUrl.pathname.startsWith("/account")) {
    const session = await auth()
    if (!session.userId) {
      return NextResponse.redirect(buildRedirectUrl(request))
    }
  }

  return NextResponse.next()
})

export const config = {
  matcher: ["/((?!_next|.*\\..*|favicon.ico).*)"],
}
