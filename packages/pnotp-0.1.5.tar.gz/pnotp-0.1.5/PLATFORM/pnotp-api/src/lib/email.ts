const BREVO_ENDPOINT = "https://api.brevo.com/v3/smtp/email"

type EmailRecipient = string | { email: string; name?: string }

export type EmailEnv = {
  BREVO_API_KEY?: string
  BREVO_SENDER_EMAIL?: string
  BREVO_SENDER_NAME?: string
}

type SendEmailOptions = {
  to: EmailRecipient | EmailRecipient[]
  subject: string
  html: string
  replyTo?: string
}

export async function sendEmail(env: EmailEnv, options: SendEmailOptions): Promise<boolean> {
  const apiKey = env.BREVO_API_KEY

  if (!apiKey) {
    console.error("Brevo email skipped: BREVO_API_KEY is not configured")
    return false
  }

  const recipients = Array.isArray(options.to) ? options.to : [options.to]
  const to = recipients
    .map((recipient) => {
      if (typeof recipient === "string") {
        return { email: recipient }
      }
      return recipient
    })
    .filter((recipient) => !!recipient.email)

  if (!to.length) {
    console.error("Brevo email skipped: no recipients provided")
    return false
  }

  const payload: Record<string, unknown> = {
    sender: {
      email: env.BREVO_SENDER_EMAIL ?? "no-reply@pnotp.ai",
      name: env.BREVO_SENDER_NAME ?? "P¬P",
    },
    to,
    subject: options.subject,
    htmlContent: options.html,
  }

  if (options.replyTo) {
    payload.replyTo = {
      email: options.replyTo,
    }
  }

  try {
    const response = await fetch(BREVO_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-key": apiKey,
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      const body = await response.text().catch(() => "")
      console.error("Brevo email error", { status: response.status, body })
      return false
    }

    return true
  } catch (error) {
    console.error("Brevo email exception", error)
    return false
  }
}
