import { PrismaClient } from "@prisma/client/edge"
import { withAccelerate } from "@prisma/extension-accelerate"

export type PrismaEnv = {
  DATABASE_URL?: string
}

let prisma: ReturnType<typeof createClient> | undefined

function createClient(databaseUrl: string) {
  const client = new PrismaClient({
    datasourceUrl: databaseUrl,
  })

  return client.$extends(withAccelerate())
}

export function getPrisma(env: PrismaEnv) {
  if (!env.DATABASE_URL) {
    throw new Error("DATABASE_URL is not configured for pnotp-api")
  }

  if (!prisma) {
    prisma = createClient(env.DATABASE_URL)
  }

  return prisma
}
