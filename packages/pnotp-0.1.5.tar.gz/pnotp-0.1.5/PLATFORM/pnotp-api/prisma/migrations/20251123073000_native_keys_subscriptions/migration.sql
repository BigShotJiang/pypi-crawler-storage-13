-- Drop legacy billing/subscription tables
DROP TABLE IF EXISTS "billing_charges";
DROP TABLE IF EXISTS "model_subscriptions";

-- Recreate api_keys table with native ownership fields
DROP TABLE IF EXISTS "api_keys";
CREATE TABLE "api_keys" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "keyHash" TEXT NOT NULL,
    "label" TEXT,
    "tier" TEXT NOT NULL,
    "fingerprint" TEXT NOT NULL,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "revokedAt" TIMESTAMPTZ
);
CREATE INDEX "api_keys_userId_idx" ON "api_keys"("userId");

-- Native subscription storage
CREATE TABLE "subscriptions" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "tier" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'active',
    "startedAt" TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "canceledAt" TIMESTAMPTZ,
    "renewalDate" TIMESTAMPTZ
);
CREATE INDEX "subscriptions_userId_idx" ON "subscriptions"("userId");
