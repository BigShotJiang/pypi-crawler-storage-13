-- CreateTable
CREATE TABLE "pnotp_models" (
    "id" TEXT NOT NULL,
    "modelId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "tier" TEXT NOT NULL,
    "priceUsd" INTEGER NOT NULL,
    "accuracy" REAL NOT NULL,
    "f1Score" REAL NOT NULL,
    "auc" REAL NOT NULL,
    "inputType" TEXT NOT NULL,
    "outputType" TEXT NOT NULL,
    "latencyMs" INTEGER NOT NULL,
    "status" TEXT NOT NULL,
    "industry" TEXT NOT NULL,
    CONSTRAINT "pnotp_models_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "api_keys" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "prefix" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable
CREATE TABLE "model_subscriptions" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "modelId" TEXT NOT NULL,
    "tier" TEXT NOT NULL,
    "priceUsd" INTEGER NOT NULL,
    "status" TEXT NOT NULL,
    "startDate" TIMESTAMPTZ NOT NULL,
    "nextBillingDate" TIMESTAMPTZ,
    CONSTRAINT "model_subscriptions_modelId_fkey" FOREIGN KEY ("modelId") REFERENCES "pnotp_models" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "custom_model_requests" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "domain" TEXT NOT NULL,
    "problemDescription" TEXT NOT NULL,
    "dataDescription" TEXT NOT NULL,
    "contactEmail" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'new',
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateIndex
CREATE UNIQUE INDEX "pnotp_models_modelId_key" ON "pnotp_models"("modelId");
