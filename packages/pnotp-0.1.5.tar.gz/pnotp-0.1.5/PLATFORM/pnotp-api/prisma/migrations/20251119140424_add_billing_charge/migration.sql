-- CreateTable
CREATE TABLE "billing_charges" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "subscriptionId" TEXT,
    "modelId" TEXT NOT NULL,
    "amountUsd" INTEGER NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'USD',
    "billingName" TEXT NOT NULL,
    "billingEmail" TEXT NOT NULL,
    "billingAddressLine1" TEXT NOT NULL,
    "billingAddressLine2" TEXT,
    "billingCity" TEXT NOT NULL,
    "billingState" TEXT,
    "billingCountry" TEXT NOT NULL,
    "billingPostalCode" TEXT NOT NULL,
    "cardBrand" TEXT NOT NULL,
    "cardLast4" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'succeeded',
    "createdAt" TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "billing_charges_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES "model_subscriptions" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
