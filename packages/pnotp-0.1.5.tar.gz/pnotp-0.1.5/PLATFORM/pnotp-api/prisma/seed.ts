import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding database...");

  // Clear existing data
  await prisma.subscription.deleteMany();
  await prisma.pnotPModel.deleteMany();
  await prisma.apiKey.deleteMany();
  await prisma.customModelRequest.deleteMany();

  // Seed PnotP Models
  const models = [
    // Expert tier ($1999)
    {
      modelId: "brain_mri_tumor_detection",
      name: "Brain MRI Tumor Detection",
      description:
        "Five-checkpoint ensemble (equal weights) across glioma, meningioma, no tumor, and pituitary classes. Validated at 0.9913 accuracy / 0.9909 F1 / 0.9999 ROC-AUC with test accuracy 0.9924.",
      tier: "Expert",
      priceUsd: 1999,
      accuracy: 0.9924,
      f1Score: 0.9919,
      auc: 0.9998,
      inputType: "Brain MRI Volume",
      outputType: "4-class Classification",
      latencyMs: 450,
      status: "available",
      industry: "Medicine",
    },
    {
      modelId: "chest_xray_tuberculosis",
      name: "Chest X-Ray Tuberculosis Screening",
      description:
        "Five-checkpoint ensemble tuned at threshold 0.7049 for public-health TB screening programs.",
      tier: "Expert",
      priceUsd: 1999,
      accuracy: 0.9987,
      f1Score: 0.9978,
      auc: 1.0,
      inputType: "Chest X-Ray",
      outputType: "Binary Classification",
      latencyMs: 360,
      status: "available",
      industry: "Medicine",
    },
    // Premium tier ($999)
    {
      modelId: "chest_xray_aortic_enlargement",
      name: "Chest X-Ray Aortic Enlargement",
      description:
        "Ensemble operating at threshold 0.558 for aortic enlargement triage with high ROC-AUC.",
      tier: "Premium",
      priceUsd: 999,
      accuracy: 0.9649,
      f1Score: 0.9236,
      auc: 0.9951,
      inputType: "Chest X-Ray",
      outputType: "Binary Classification",
      latencyMs: 340,
      status: "available",
      industry: "Medicine",
    },
    {
      modelId: "chest_xray_cardiomegaly",
      name: "Chest X-Ray Cardiomegaly",
      description:
        "Five-member ensemble optimized at threshold 0.4995 for cardiomegaly monitoring.",
      tier: "Premium",
      priceUsd: 999,
      accuracy: 0.9551,
      f1Score: 0.8863,
      auc: 0.9947,
      inputType: "Chest X-Ray",
      outputType: "Binary Classification",
      latencyMs: 335,
      status: "available",
      industry: "Medicine",
    },
    {
      modelId: "chest_xray_pleural_effusion",
      name: "Chest X-Ray Pleural Effusion",
      description:
        "Five-checkpoint ensemble (threshold 0.6589) for hospital-grade pleural effusion triage.",
      tier: "Premium",
      priceUsd: 999,
      accuracy: 0.9897,
      f1Score: 0.9434,
      auc: 0.9956,
      inputType: "Chest X-Ray",
      outputType: "Binary Classification",
      latencyMs: 330,
      status: "available",
      industry: "Medicine",
    },
    {
      modelId: "chest_xray_pneumonia",
      name: "Chest X-Ray Pneumonia Detection",
      description:
        "Operating point at threshold 0.4659 (precision 0.9864 / sensitivity 0.9634 / specificity 0.9756) with strong generalization on hold-out tests.",
      tier: "Premium",
      priceUsd: 999,
      accuracy: 0.9706,
      f1Score: 0.9771,
      auc: 0.99,
      inputType: "Chest X-Ray",
      outputType: "Binary Classification",
      latencyMs: 320,
      status: "available",
      industry: "Medicine",
    },
    {
      modelId: "retina_diabetic_retinopathy_binary",
      name: "Retina Diabetic Retinopathy (Binary)",
      description:
        "Five equally weighted checkpoints run at Youden threshold 0.8489 for normal vs. DR classification.",
      tier: "Expert",
      priceUsd: 1999,
      accuracy: 1.0,
      f1Score: 1.0,
      auc: 1.0,
      inputType: "Retinal Fundus Image",
      outputType: "Binary Classification",
      latencyMs: 310,
      status: "available",
      industry: "Ophthalmology",
    },
    // MVP tier ($499)
    {
      modelId: "chest_xray_pleural_thickening",
      name: "Chest X-Ray Pleural Thickening",
      description:
        "Clinical MVP ensemble at threshold 0.5049 for pleural thickening surveillance.",
      tier: "MVP",
      priceUsd: 499,
      accuracy: 0.9444,
      f1Score: 0.8458,
      auc: 0.985,
      inputType: "Chest X-Ray",
      outputType: "Binary Classification",
      latencyMs: 310,
      status: "available",
      industry: "Medicine",
    },
    // Viable tier ($199)
    {
      modelId: "retina_glaucoma_binary",
      name: "Retina Glaucoma (Binary)",
      description:
        "Five checkpoint ensemble (Youden threshold 0.4383) for glaucoma risk triage.",
      tier: "Viable",
      priceUsd: 199,
      accuracy: 0.9167,
      f1Score: 0.9091,
      auc: 0.9791,
      inputType: "Retinal Fundus Image",
      outputType: "Binary Classification",
      latencyMs: 290,
      status: "available",
      industry: "Ophthalmology",
    },
  ];

  for (const model of models) {
    await prisma.pnotPModel.create({
      data: model,
    });
  }

  console.log(`Seeded ${models.length} models`);
  console.log("Database seeded successfully!");
}

main()
  .catch((e) => {
    console.error(e);
    throw e;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
