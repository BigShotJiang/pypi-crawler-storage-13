# PnotP

Unified API and Python client for PathoVision vision models.

## Packages
- `pnotp_api`: FastAPI service that wraps PathoVision ensembles under a consistent `/v1` surface with API-key auth.
- `pnotp`: Python client for calling the PnotP API.

## Install (client only)
```bash
pip install pnotp
```

## Install (client + server extra)
```bash
pip install "pnotp[server]"
```

## Usage (client)
```python
import pnotp as pnp

client = pnp.client(api_key="YOUR_KEY")  # default base URL: https://api.pnotp.ai
client.models()
model = client.models("pneumonia_binary_classification")
result = model.predict("image.jpg")
heatmap = model.attention_map("image.jpg")
```

Set your key once per shell:
```bash
export PNOTP_API_KEY="your_api_key_here"
python your_script.py  # pnp.client() will read the env var automatically
```

## Run the API locally
```bash
export PNOTP_INTERNAL_SECRET="dev-secret"
export PATHOVISION_ROOT="/absolute/path/to/PathoVision"  # if not default
uvicorn pnotp_api.main:app --host 0.0.0.0 --port 8000
```

## Issue an API key (internal)
```bash
curl -X POST http://127.0.0.1:8000/internal/api-keys \
  -H "X-Internal-Secret: $PNOTP_INTERNAL_SECRET" \
  -H "Content-Type: application/json" \
  -d '{"user_external_id":"demo-user","plan_code":"pathovision_starter"}'
```
