# брбрбр патапил
# skylinetl
# version: v1.0.0

Что такое skylinetl?
Skylinetl это форк библиотеки telethon. Оптимизированная версия а также обновлённая.
Подойдёт для юзерботов в телеграмме

# установка

```bash
pip install skylinetl
