from __future__ import annotations

from typing import TypeAlias

Json: TypeAlias = str | int | float | bool | dict[str, "Json"] | list["Json"] | None

__all__ = ("Json",)
