"""Tests for taggers module."""
