# Shapley-Banckruptcy

⚠️ **Note:** This package has been moved to [shapley-bankruptcy](https://pypi.org/project/shapley-bankruptcy/)

Please install the new version instead:
```bash
pip install shapley-bankruptcy
```
