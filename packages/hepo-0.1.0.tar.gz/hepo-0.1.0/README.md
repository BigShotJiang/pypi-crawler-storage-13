# Hepo

Flexible retrieval over hierarchical, filesystem-like repositories.
