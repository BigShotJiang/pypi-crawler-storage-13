from ThermodynamicCycles.FluidPort.FluidPort import FluidPort

def Fluid_connect( inlet=FluidPort(),outlet=FluidPort()):
    # Copier les propriétés du fluide
    inlet.fluid=outlet.fluid
    inlet.h=outlet.h
    inlet.F=outlet.F
    inlet.S=outlet.S
    inlet.T=outlet.T
    
    # Gérer les pressions avec propagation des callbacks
    if inlet.P is not None:
        #print("inlet.P....",inlet.P)
        outlet.P=inlet.P
    else:
        inlet.P=outlet.P
    
    # Créer une liaison bidirectionnelle pour la synchronisation des pressions
    # Sauvegarder les callbacks originaux
    original_inlet_callback = getattr(inlet, 'callback', None)
    original_outlet_callback = getattr(outlet, 'callback', None)
    
    # Créer une référence croisée pour la synchronisation
    inlet._connected_port = outlet
    outlet._connected_port = inlet
    
    # Créer des callbacks qui propagent les changements et exécutent les callbacks originaux
    def inlet_pressure_sync():
        # D'abord exécuter le callback original s'il existe
        if original_inlet_callback:
            original_inlet_callback()
        # Propager vers le port connecté si différent
        if hasattr(inlet, '_connected_port') and hasattr(inlet, '_P'):
            connected = inlet._connected_port
            if hasattr(connected, '_P') and connected._P != inlet._P:
                # Éviter les boucles infinies
                if not hasattr(inlet, '_syncing_P'):
                    inlet._syncing_P = True
                    try:
                        print(f"SYNC: Propagation inlet→outlet {inlet._P/100000:.3f}→{connected._P/100000:.3f} bar")
                        connected.P = inlet._P
                    finally:
                        delattr(inlet, '_syncing_P')
        # Propager le débit aussi (inlet peut aspirer un débit différent)
        if hasattr(inlet, '_connected_port') and hasattr(inlet, '_F'):
            connected = inlet._connected_port
            if hasattr(connected, '_F') and connected._F != inlet._F:
                if not hasattr(inlet, '_syncing_F'):
                    inlet._syncing_F = True
                    try:
                        print(f"SYNC: Propagation débit inlet→outlet {inlet._F:.3f}→{connected._F:.3f} kg/s")
                        connected.F = inlet._F
                    finally:
                        delattr(inlet, '_syncing_F')
    
    def outlet_pressure_sync():
        # D'abord exécuter le callback original s'il existe
        if original_outlet_callback:
            original_outlet_callback()
        # Propager vers le port connecté si différent
        if hasattr(outlet, '_connected_port') and hasattr(outlet, '_P'):
            connected = outlet._connected_port
            if hasattr(connected, '_P') and connected._P != outlet._P:
                # Éviter les boucles infinies
                if not hasattr(outlet, '_syncing_P'):
                    outlet._syncing_P = True
                    try:
                        print(f"SYNC: Propagation outlet→inlet {outlet._P/100000:.3f}→{connected._P/100000:.3f} bar")
                        connected.P = outlet._P
                    finally:
                        delattr(outlet, '_syncing_P')
        # Propager le débit aussi
        if hasattr(outlet, '_connected_port') and hasattr(outlet, '_F'):
            connected = outlet._connected_port
            if hasattr(connected, '_F') and connected._F != outlet._F:
                if not hasattr(outlet, '_syncing_F'):
                    outlet._syncing_F = True
                    try:
                        print(f"SYNC: Propagation débit outlet→inlet {outlet._F:.3f}→{connected._F:.3f} kg/s")
                        connected.F = outlet._F
                    finally:
                        delattr(outlet, '_syncing_F')
    
    # Assigner les nouveaux callbacks
    inlet.callback = inlet_pressure_sync
    outlet.callback = outlet_pressure_sync
    
    # Calculer les propriétés
    inlet.calculate_properties()
    outlet.calculate_properties()
    
    return "connectés"