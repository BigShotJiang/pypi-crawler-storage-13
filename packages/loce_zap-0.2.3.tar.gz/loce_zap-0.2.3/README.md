# Loce Zap Python SDK

SDK oficial em Python para integrar com a API Loce Zap.

## Instalação

```bash
pip install loce-zap
```

## Uso rápido

```python
from loce_zap import LoceZap

api = LoceZap("SUA_API_KEY")

connect_resp = api.connect(
    session_name="sessao-123",
    webhook_url="https://seu-webhook.com/evento",
    webhook_messages=True,
)

edit_resp = api.edit_session(
    "sessao-123",
    session_name="sessao-renomeada",
    webhook_url="https://seu-webhook.com/novo",
    webhook_messages=False,
)

list_resp = api.list_sessions()

disconnect_resp = api.disconnect("sessao-123")

api.close()
```

## Assíncrono

```python
import asyncio
from loce_zap import AsyncLoceZap

async def main() -> None:
    api = AsyncLoceZap("SUA_API_KEY")

    await api.connect(
        session_name="sessao-123",
        webhook_url="https://seu-webhook.com/evento",
        webhook_messages=True,
    )

    await api.edit_session(
        "sessao-123",
        session_name="sessao-renomeada",
        webhook_url="https://seu-webhook.com/novo",
        webhook_messages=False,
    )

    await api.list_sessions()
    await api.disconnect("sessao-123")

    await api._http.aclose()

asyncio.run(main())
```

## Envio de mensagens (exemplos)

```python
send_resp = api.send_message_text(
    session_id="sessao-123",
    to="+5511999999999",
    text="Olá!",
)

api.delete_message(
    session_id="sessao-123",
    message_id="msg-123",
)

api.edit_message(
    session_id="sessao-123",
    message_id="msg-123",
    text="Corrigido",
)
```

Outras opções: `send_message_image`, `send_message_audio`, `send_message_document`, `send_message_location`, `send_message_video`, `send_message_sticker`, `send_message_buttons`, `send_message_list`, `delete_message`, `edit_message`.

## Sessões

- `connect(session_name, webhook_url, webhook_messages=True)` → cria/conecta sessão.
- `edit_session(session_id, *, session_name=None, webhook_url=None, webhook_messages=None)` → atualiza sessão. É obrigatório enviar pelo menos um campo.
- `list_sessions()` → lista sessões.
- `disconnect(session_id)` → desconecta sessão.

## Validação de webhooks

```python
from loce_zap import WebhookVerifier

verifier = WebhookVerifier()
is_valid = verifier.verify(signature, payload_bytes, api_key="SUA_API_KEY")
```

## Licença

MIT
