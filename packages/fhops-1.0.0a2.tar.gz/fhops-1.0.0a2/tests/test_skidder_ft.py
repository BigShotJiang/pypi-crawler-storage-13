from __future__ import annotations

import math

import pytest

from fhops.productivity.skidder_ft import (
    ADV6N7DeckingMode,
    DeckingCondition,
    Han2018SkidderMethod,
    TrailSpacingPattern,
    estimate_cable_skidder_productivity_adv1n12_full_tree,
    estimate_cable_skidder_productivity_adv1n12_two_phase,
    estimate_grapple_skidder_productivity_adv6n7,
    estimate_grapple_skidder_productivity_han2018,
    get_skidder_speed_profile,
)


def test_han2018_lop_and_scatter_cycle_time() -> None:
    result = estimate_grapple_skidder_productivity_han2018(
        method=Han2018SkidderMethod.LOP_AND_SCATTER,
        pieces_per_cycle=20.0,
        piece_volume_m3=0.25,
        empty_distance_m=150.0,
        loaded_distance_m=130.0,
    )
    assert result.cycle_time_seconds == pytest.approx(213.279, rel=1e-6)
    assert result.predicted_m3_per_pmh == pytest.approx(84.401, rel=1e-3)


def test_han2018_whole_tree_cycle_time() -> None:
    result = estimate_grapple_skidder_productivity_han2018(
        method=Han2018SkidderMethod.WHOLE_TREE,
        pieces_per_cycle=18.0,
        piece_volume_m3=0.35,
        empty_distance_m=160.0,
        loaded_distance_m=140.0,
    )
    assert result.cycle_time_seconds == pytest.approx(
        25.125 + (1.881 * 18) + (0.632 * 160) + (0.477 * 140), rel=1e-9
    )
    assert result.predicted_m3_per_pmh > 0


def test_han2018_with_trail_and_decking_multipliers() -> None:
    baseline = estimate_grapple_skidder_productivity_han2018(
        method=Han2018SkidderMethod.WHOLE_TREE,
        pieces_per_cycle=18.0,
        piece_volume_m3=0.35,
        empty_distance_m=160.0,
        loaded_distance_m=140.0,
    )
    adjusted = estimate_grapple_skidder_productivity_han2018(
        method=Han2018SkidderMethod.WHOLE_TREE,
        pieces_per_cycle=18.0,
        piece_volume_m3=0.35,
        empty_distance_m=160.0,
        loaded_distance_m=140.0,
        trail_pattern=TrailSpacingPattern.NARROW_13_15M,
        decking_condition=DeckingCondition.CONSTRAINED,
    )
    assert adjusted.predicted_m3_per_pmh < baseline.predicted_m3_per_pmh


def test_han2018_with_speed_profile() -> None:
    profile = get_skidder_speed_profile("SK")
    result = estimate_grapple_skidder_productivity_han2018(
        method=Han2018SkidderMethod.LOP_AND_SCATTER,
        pieces_per_cycle=16.0,
        piece_volume_m3=0.2,
        empty_distance_m=120.0,
        loaded_distance_m=100.0,
        speed_profile=profile,
    )
    legacy = estimate_grapple_skidder_productivity_han2018(
        method=Han2018SkidderMethod.LOP_AND_SCATTER,
        pieces_per_cycle=16.0,
        piece_volume_m3=0.2,
        empty_distance_m=120.0,
        loaded_distance_m=100.0,
    )
    assert result.cycle_time_seconds != legacy.cycle_time_seconds


def test_adv1n12_full_tree_regression() -> None:
    distance = 200.0
    expected = 5.4834 * math.exp(-0.0013 * distance)
    assert estimate_cable_skidder_productivity_adv1n12_full_tree(distance) == pytest.approx(
        expected, rel=1e-6
    )


def test_adv1n12_two_phase_regression() -> None:
    distance = 150.0
    expected = -4.9339 * math.log(distance) + 35.202
    assert estimate_cable_skidder_productivity_adv1n12_two_phase(distance) == pytest.approx(
        expected, rel=1e-6
    )


def test_adv6n7_default_productivity_and_cost() -> None:
    result = estimate_grapple_skidder_productivity_adv6n7(
        skidding_distance_m=85.0,
        decking_mode=ADV6N7DeckingMode.SKIDDER_LOADER,
        support_ratio=0.0,
    )
    assert result.productivity_m3_per_pmh == pytest.approx(92.672, rel=1e-3)
    assert result.skidder_cost_per_m3_cad_2004 == pytest.approx(115.21 / 92.672, rel=1e-3)


def test_adv6n7_loader_support_combined_cost() -> None:
    result = estimate_grapple_skidder_productivity_adv6n7(
        skidding_distance_m=85.0,
        decking_mode=ADV6N7DeckingMode.HOT_PROCESSING,
        support_ratio=0.4,
    )
    assert result.combined_cost_per_m3_cad_2004 == pytest.approx(1.98, rel=0.05)
    assert result.support_ratio == pytest.approx(0.4)
