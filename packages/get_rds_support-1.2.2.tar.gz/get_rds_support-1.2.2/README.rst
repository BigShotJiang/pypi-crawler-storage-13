===================
**get_rds_support**
===================

Overview
--------

A Python module to get RDS instance support details from AWS accounts. Authenticates using AWS SSO (see example below).

Prerequisites
-------------

- Python 3.9 or higher.
- Boto3 (https://pypi.org/project/boto3/)
- aws_crawler (https://pypi.org/project/aws_crawler/)
- aws_authenticator (https://pypi.org/project/aws_authenticator/)
- multithreader (https://pypi.org/project/multithreader/)

Usage
-----

Installation:

.. code-block:: BASH

   pip3 install get_rds_support
   # or
   python3 -m pip install get_rds_support

CLI:

.. code-block:: BASH

   rds_support \
      -a "<sso_account_id>" \
      -u "<sso_url>" \
      -r "<sso_role_name>" \
      [-n "<assumed_role_name>" \]
      [-e "<external_id>" \]
      [-s "<account_statuses>" \]
      [-o "<account_ou>" \]
      [-l "<account_list>" \]
      [-t <thread_num>]

Response:

.. code-block:: JSON

   [
      {
         "account_id": "string",
         "region": "string",
         "rds_id": "string",
         "support": "string",
         "engine": "string",
         "engine_version": "string",
         "support_start_date": "string",
         "support_end_date": "string"
      },
      ...
   ]

Example:

.. code-block:: BASH

   rds_support \
      -a "123456789012" \
      -u "https://a-123example.awsapps.com/start/#/" \
      -r "AWSReadOnlyAccess" \
      -n "AWSCrossAccountAccess" \
      -l "234567890123,345678901234"
   Verification URI: https://a-123example.awsapps.com/start/#/device?user_code=ABCD-1234
   Access Token retrieval successful.
   You specified 2 account(s)...
   Working on 234567890123...
   Working on 345678901234...
   [
      {
         "account_id": "234567890123",
         "region": "us-east-1",
         "rds_id": "database-1",
         "support": null,
         "engine": "mariadb",
         "engine_version": "11.4.8",
         "support_start_date": "2024-10-15 00:00:00+00:00",
         "support_end_date": "2029-05-31 23:59:59.999000+00:00"
      },
      {
         "account_id": "345678901234",
         "region": "us-west-2",
         "rds_id": "database-5",
         "support": null,
         "engine": "mysql",
         "engine_version": "8.4.2",
         "support_start_date": "2025-05-01 00:00:00+00:00",
         "support_end_date": "2030-04-30 23:59:59.999000+00:00"
      }
   ]
