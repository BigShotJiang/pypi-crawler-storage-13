#!/usr/bin/env python3
# -*- coding: latin-1 -*-
"""Get RDS instance support details from AWS accounts."""

import __init__

if __name__ == "__main__":
    __init__.main()
