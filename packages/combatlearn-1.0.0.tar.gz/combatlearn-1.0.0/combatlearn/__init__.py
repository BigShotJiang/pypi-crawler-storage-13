from .combat import ComBat

__all__ = ["ComBat"]
__version__ = "1.0.0"
__author__ = "Ettore Rocchi"