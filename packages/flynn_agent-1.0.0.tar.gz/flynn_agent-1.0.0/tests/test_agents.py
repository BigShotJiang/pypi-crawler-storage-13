"""Tests for Tier 1 agents."""

import pytest

from flynn_agent.models import TaskSpec
from flynn_agent.registry import AgentRegistry


@pytest.mark.asyncio
async def test_code_writer_generates_function():
    spec = TaskSpec(
        task_id="cw", intent="write code", payload={"description": "add two numbers", "function_name": "add"}
    )
    agent_cls = AgentRegistry.global_registry().get("code-writer-agent")
    agent = agent_cls()
    result = await agent.execute(spec)
    assert "def add(" in result.output
    assert "add two numbers" in result.output


@pytest.mark.asyncio
async def test_testing_agent_generates_tests():
    code = "def foo():\n    return 1"
    spec = TaskSpec(task_id="test", intent="test code", payload={"code": code})
    agent_cls = AgentRegistry.global_registry().get("testing-agent")
    agent = agent_cls()
    result = await agent.execute(spec)
    assert "test_foo" in result.output


@pytest.mark.asyncio
async def test_security_agent_detects_eval():
    code = "def bad():\n    return eval('2+2')"
    spec = TaskSpec(task_id="sec", intent="security", payload={"code": code})
    agent_cls = AgentRegistry.global_registry().get("security-agent")
    agent = agent_cls()
    result = await agent.execute(spec)
    assert any("eval" in issue for issue in result.output)