"""Tests for the Orchestrator DAG execution."""

import asyncio

import pytest

from flynn_agent.models import TaskSpec
from flynn_agent.orchestrator import Orchestrator


@pytest.mark.asyncio
async def test_orchestrator_executes_tasks_in_dependency_order():
    # define tasks
    t1 = TaskSpec(
        task_id="t1",
        intent="generate code",
        payload={"description": "return hello", "function_name": "greet"},
        dependencies=[],
    )
    t2 = TaskSpec(
        task_id="t2",
        intent="test code",
        payload={"code": "def greet():\n    return 'hello'"},
        dependencies=["t1"],
    )
    orchestrator = Orchestrator()
    results = await orchestrator.run([t1, t2])
    assert "t1" in results and "t2" in results
    # ensure t1 output is code
    assert "def greet(" in results["t1"].output
    # t2 should produce a test stub
    assert "test_greet" in results["t2"].output