"""Context Store tests for thread-safety and basic operations."""

import asyncio

import pytest

from flynn_agent.context import ContextStore


def test_context_store_set_get():
    """Test basic set and get operations."""
    store = ContextStore()
    store.set("key1", "value1")
    assert store.get("key1") == "value1"


def test_context_store_get_nonexistent():
    """Test getting non-existent key returns None."""
    store = ContextStore()
    assert store.get("nonexistent_key") is None


def test_context_store_overwrite():
    """Test that set overwrites existing values."""
    store = ContextStore()
    store.set("key1", "value1")
    store.set("key1", "value2")
    assert store.get("key1") == "value2"


def test_context_store_multiple_keys():
    """Test storing multiple keys independently."""
    store = ContextStore()
    store.set("key1", "value1")
    store.set("key2", "value2")
    store.set("key3", "value3")

    assert store.get("key1") == "value1"
    assert store.get("key2") == "value2"
    assert store.get("key3") == "value3"


@pytest.mark.asyncio
async def test_context_store_thread_safety():
    """Test that context store is thread-safe under concurrent access."""
    store = ContextStore()

    async def writer(key, start_value, iterations=50):
        """Write to store repeatedly."""
        for i in range(iterations):
            store.set(key, start_value + i)
            await asyncio.sleep(0.001)

    async def reader(key, iterations=50):
        """Read from store repeatedly."""
        for i in range(iterations):
            val = store.get(key)
            # Value should exist or be None (race condition acceptable)
            assert val is None or isinstance(val, int)
            await asyncio.sleep(0.001)

    # Run concurrent writers and readers
    await asyncio.gather(
        writer("key1", 0),
        writer("key2", 1000),
        reader("key1"),
        reader("key2"),
        reader("key3"),  # Read non-existent key
    )

    # After all operations, keys should exist
    assert store.get("key1") is not None
    assert store.get("key2") is not None
