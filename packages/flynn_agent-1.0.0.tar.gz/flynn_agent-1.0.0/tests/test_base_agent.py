"""Unit tests for the BaseAgent execution template."""

import asyncio
from dataclasses import dataclass
from typing import Dict

import pytest

from flynn_agent.base import BaseAgent
from flynn_agent.models import TaskSpec, AgentResult
from flynn_agent.registry import AgentRegistry
from flynn_agent.models import Capabilities


@AgentRegistry.global_registry().register
class DummyAgent(BaseAgent):
    name = "dummy-agent"
    description = "A dummy agent for testing."
    capabilities = {Capabilities.ANALYSIS}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, str]) -> str:
        return ctx.get("value", "default")


@pytest.mark.asyncio
async def test_execute_calls_run_and_finalizes():
    spec = TaskSpec(task_id="t", intent="dummy", payload={}, context={"value": "ok"})
    agent = DummyAgent()
    result = await agent.execute(spec)
    assert isinstance(result, AgentResult)
    assert result.output == "ok"
    assert result.success is True
    assert result.status_code == "OK"