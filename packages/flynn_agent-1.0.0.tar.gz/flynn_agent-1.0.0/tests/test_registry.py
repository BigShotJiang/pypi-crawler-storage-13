"""Tests for the AgentRegistry."""

from flynn_agent.registry import AgentRegistry
from flynn_agent.models import TaskSpec


def test_get_registered_agent():
    registry = AgentRegistry.global_registry()
    assert registry.get("code-writer-agent").__name__ == "CodeWriterAgent"


def test_get_agent_for_spec_matches_keyword():
    registry = AgentRegistry.global_registry()
    spec = TaskSpec(task_id="1", intent="please write code", payload={})
    cls = registry.get_agent_for_spec(spec)
    assert cls.name == "code-writer-agent"