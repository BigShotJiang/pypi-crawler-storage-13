"""Advanced Registry tests for validation, edge cases, and agent selection."""

import pytest

from flynn_agent.base import BaseAgent
from flynn_agent.models import TaskSpec
from flynn_agent.registry import AgentRegistry


def test_register_agent_without_name():
    """Test that registering agent without name raises ValueError."""
    registry = AgentRegistry()

    class BadAgent(BaseAgent):
        # Missing name attribute
        async def execute(self, task):
            return None

    with pytest.raises(ValueError, match="missing name"):
        registry.register(BadAgent)


def test_get_nonexistent_agent():
    """Test that getting non-existent agent raises KeyError."""
    registry = AgentRegistry()
    with pytest.raises(KeyError):
        registry.get("nonexistent-agent-xyz")


def test_agent_selection_priority():
    """Test that more specific keywords take precedence."""
    registry = AgentRegistry.global_registry()

    # "test" should match testing-agent, not code-writer-agent
    spec_test = TaskSpec(task_id="1", intent="test code", payload={}, dependencies=[])
    agent = registry.get_agent_for_spec(spec_test)
    assert agent.name == "testing-agent"

    # "security" should match security-agent
    spec_sec = TaskSpec(task_id="2", intent="security audit", payload={}, dependencies=[])
    agent_sec = registry.get_agent_for_spec(spec_sec)
    assert agent_sec.name == "security-agent"


def test_fallback_agent():
    """Test that unknown intents fall back to default agent."""
    registry = AgentRegistry.global_registry()
    spec = TaskSpec(
        task_id="1",
        intent="xyz unknown task that matches nothing",
        payload={},
        dependencies=[]
    )
    agent = registry.get_agent_for_spec(spec)
    # Should return code-writer or orchestrator as fallback
    assert agent is not None
    assert hasattr(agent, "name")


def test_registry_singleton():
    """Test that global_registry returns same instance."""
    reg1 = AgentRegistry.global_registry()
    reg2 = AgentRegistry.global_registry()
    assert reg1 is reg2


def test_multiple_keyword_matching():
    """Test agent selection when multiple keywords present."""
    registry = AgentRegistry.global_registry()

    # "write code" should match code-writer-agent
    spec_code = TaskSpec(
        task_id="1",
        intent="write code for login",
        payload={},
        dependencies=[]
    )
    agent_code = registry.get_agent_for_spec(spec_code)
    assert agent_code.name == "code-writer-agent"

    # "document api" should match documentation-agent
    spec_docs = TaskSpec(
        task_id="2",
        intent="document api endpoints",
        payload={},
        dependencies=[]
    )
    agent_docs = registry.get_agent_for_spec(spec_docs)
    assert agent_docs.name == "documentation-agent"
