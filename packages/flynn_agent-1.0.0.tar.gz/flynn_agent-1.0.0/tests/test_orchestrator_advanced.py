"""Advanced Orchestrator tests for cycle detection, parallel execution, and complex DAGs."""

import asyncio
import time

import pytest

from flynn_agent.models import TaskSpec
from flynn_agent.orchestrator import Orchestrator


@pytest.mark.asyncio
async def test_cycle_detection():
    """Test that orchestrator handles cycles gracefully (currently no cycle detection)."""
    t1 = TaskSpec(task_id="t1", intent="test", payload={}, dependencies=["t2"])
    t2 = TaskSpec(task_id="t2", intent="test", payload={}, dependencies=["t1"])

    orchestrator = Orchestrator()
    # Current implementation: cycle causes deadlock (no tasks have indegree 0)
    # Result: empty dict (no tasks executed)
    results = await orchestrator.run([t1, t2])
    assert len(results) == 0  # No tasks can start (both have dependencies)


@pytest.mark.asyncio
async def test_self_cycle_detection():
    """Test that orchestrator handles self-referential cycles."""
    t1 = TaskSpec(task_id="t1", intent="test", payload={}, dependencies=["t1"])

    orchestrator = Orchestrator()
    # Self-cycle: task depends on itself (indegree = 1, never becomes 0)
    results = await orchestrator.run([t1])
    assert len(results) == 0  # Task never starts (depends on itself)


@pytest.mark.asyncio
async def test_parallel_execution():
    """Test that independent tasks execute in parallel."""
    t1 = TaskSpec(task_id="t1", intent="test", payload={}, dependencies=[])
    t2 = TaskSpec(task_id="t2", intent="test", payload={}, dependencies=[])
    t3 = TaskSpec(task_id="t3", intent="test", payload={}, dependencies=[])

    orchestrator = Orchestrator()
    start = time.time()
    results = await orchestrator.run([t1, t2, t3])
    duration = time.time() - start

    assert len(results) == 3
    # Tasks should run in parallel, not sequentially
    # Each mock task takes ~0.1s, so parallel should be <0.5s total
    assert duration < 1.0


@pytest.mark.asyncio
async def test_diamond_dependency():
    """Test complex dependency graph: A→B, A→C, B→D, C→D."""
    t_a = TaskSpec(task_id="A", intent="test", payload={}, dependencies=[])
    t_b = TaskSpec(task_id="B", intent="test", payload={}, dependencies=["A"])
    t_c = TaskSpec(task_id="C", intent="test", payload={}, dependencies=["A"])
    t_d = TaskSpec(task_id="D", intent="test", payload={}, dependencies=["B", "C"])

    orchestrator = Orchestrator()
    results = await orchestrator.run([t_a, t_b, t_c, t_d])

    assert len(results) == 4
    # Verify all tasks completed successfully
    assert all(results[tid].success is True for tid in results)


@pytest.mark.asyncio
async def test_empty_task_list():
    """Test orchestrator with no tasks."""
    orchestrator = Orchestrator()
    results = await orchestrator.run([])
    assert results == {}


@pytest.mark.asyncio
async def test_single_task():
    """Test orchestrator with single task."""
    t1 = TaskSpec(task_id="t1", intent="test", payload={}, dependencies=[])
    orchestrator = Orchestrator()
    results = await orchestrator.run([t1])
    assert len(results) == 1
    assert "t1" in results


@pytest.mark.asyncio
async def test_long_chain_dependency():
    """Test long linear dependency chain: A→B→C→D→E."""
    tasks = []
    for i in range(5):
        task_id = chr(65 + i)  # A, B, C, D, E
        deps = [chr(65 + i - 1)] if i > 0 else []
        tasks.append(TaskSpec(task_id=task_id, intent="test", payload={}, dependencies=deps))

    orchestrator = Orchestrator()
    results = await orchestrator.run(tasks)

    assert len(results) == 5
    # Verify E depends on D, D on C, etc.
    assert "A" in results
    assert "E" in results
