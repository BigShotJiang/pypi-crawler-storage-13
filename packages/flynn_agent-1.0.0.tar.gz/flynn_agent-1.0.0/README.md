# Flynn-Agent: Multi-Agent AI Orchestration System

> 🤖 **Powerful multi-agent orchestration for Claude Code with production-ready Python implementation**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Status: Production](https://img.shields.io/badge/Status-Production-green.svg)]()
[![Node.js](https://img.shields.io/badge/Node.js-%3E%3D18.0.0-green.svg)](https://nodejs.org/)
[![Python](https://img.shields.io/badge/Python-%3E%3D3.9-blue.svg)](https://www.python.org/)
[![Tests](https://img.shields.io/badge/Tests-200%2B-brightgreen.svg)]()

---

## 🎯 What is Flynn-Agent?

**Flynn-Agent** is a comprehensive multi-agent orchestration system that combines:

1. **Claude Code Integration** - 24 specialized AI agents accessible via slash commands
2. **Python Core Library** - Production-ready asynchronous orchestration engine
3. **Dual-Mode Operation** - Use with Claude Code OR as standalone Python CLI

### Key Features

- 🤖 **24 AI Agents** - From orchestration to security analysis
- 🐍 **Python Core** - Fully async, offline-capable, production-tested
- 🔧 **Claude Integration** - Seamless integration with Claude Code
- ✅ **200+ Tests** - Comprehensive test coverage with pytest
- 🌐 **WSL Compatible** - Designed for Windows Subsystem for Linux
- 📦 **Dual Installation** - Claude integration OR standalone Python
- 🚀 **Open Source** - MIT licensed, ready for contributions

---

## 🚀 Quick Start

### Prerequisites

**For Claude Code Integration:**
- **Claude Code** installed and configured
- **Node.js** >= 18.0.0
- **WSL** (Ubuntu recommended) or Linux

**For Python Standalone:**
- **Python** >= 3.9
- **pip** package manager

### Installation

#### Option 1: PyPI (Recommended for Python-only)

```bash
# Install from PyPI (once published)
pip install flynn-agent

# Verify installation
python -c "import flynn_agent; print(flynn_agent.__version__)"
```

#### Option 2: Full Installation (Claude + Python)

```bash
# Clone the repository
git clone https://github.com/reze83/flynn-agent.git
cd flynn-agent

# Run unified installation
chmod +x install.sh
./install.sh

# Select: "3) Both (Recommended)"

# Configure API keys (for Claude integration)
cp .env.example .env
nano .env

# Restart Claude Code
```

#### Option 3: Python Standalone from Source

```bash
# Clone the repository
git clone https://github.com/reze83/flynn-agent.git
cd flynn-agent

# Install Python package
pip install -e .

# Verify installation
flynn-agent --version
```

#### Option 4: Claude Integration Only

```bash
# Clone and install
git clone https://github.com/reze83/flynn-agent.git
cd flynn-agent
./install.sh

# Select: "1) Claude Code Integration"
```

---

## 💡 Usage

Flynn-Agent supports **three operation modes**:

1. **Claude Mode** - Claude simulates agents using Markdown definitions
2. **Python Mode** - Standalone Python orchestration engine
3. **Hybrid Mode** - Claude orchestrates, Python executes (RECOMMENDED)

### Mode 1: Claude Code Integration

After installation, use these commands in Claude Code:

```bash
/agentic     # Activate the Flynn-Agent multi-agent system
/agent       # Load and use a specific agent
/agents      # List all available agents
```

**Example Workflow:**

```bash
# List available agents
/agents

# Use a specific agent
/agent code-writer

# Activate full multi-agent orchestration
/agentic "Implement OAuth2 authentication with security validation"
```

### Mode 2: Python CLI

Use Flynn-Agent programmatically via Python:

```python
from flynn_agent import Orchestrator, TaskSpec

# Define tasks
tasks = [
    TaskSpec(
        task_id="generate",
        intent="generate code",
        payload={"description": "Add two numbers", "function_name": "add"},
        dependencies=[],
    ),
    TaskSpec(
        task_id="test",
        intent="test code",
        payload={"code": "def add(a, b): return a + b"},
        dependencies=["generate"],
    ),
]

# Execute workflow
orchestrator = Orchestrator()
results = await orchestrator.run(tasks)
```

**Or use the CLI:**

```bash
# Run a single agent
flynn-agent run-agent code-writer-agent --task '{
  "task_id": "t1",
  "intent": "write code",
  "payload": {"description": "add two numbers", "function_name": "add"}
}'

# Run a workflow
flynn-agent run-orchestrator --task '[
  {"task_id": "t1", "intent": "generate code", "payload": {...}},
  {"task_id": "t2", "intent": "test code", "dependencies": ["t1"], "payload": {...}}
]'
```

### Mode 3: Hybrid Mode (RECOMMENDED)

Combine the best of both worlds: **Claude's intelligence with Python's reliability**.

**How it works:**
```
User Request
    ↓
Claude - Analyzes & decomposes task
    ↓
Python Engine - Executes workflow (DAG, cycle detection, error handling)
    ↓
Claude - Synthesizes & presents results
```

**Example Workflow:**

```bash
# In Claude Code, use the /agentic command:
/agentic Implement user authentication with tests and security review

# Claude will:
# 1. Analyze the request
# 2. Decompose into tasks (code, test, security)
# 3. Call Python-Engine via Bash tool:
flynn-agent run-orchestrator --task '[
  {"task_id":"t1","intent":"generate code","payload":{...}},
  {"task_id":"t2","intent":"test code","dependencies":["t1"],"payload":{...}},
  {"task_id":"t3","intent":"security analysis","dependencies":["t1"],"payload":{...}}
]'
# 4. Parse results and present to you
```

**Or use the python-engine skill explicitly:**

```python
# In Claude Code
Skill: python-engine

# Then provide your task description
# Claude will use the Python-Engine for execution
```

**Or use the bridge script directly:**

```bash
# Run orchestrator with multiple tasks
~/workspace/Flynn-Agent/scripts/claude-python-bridge.sh run-orchestrator '[
  {"task_id":"t1","intent":"generate code","payload":{"description":"add function","function_name":"add"}},
  {"task_id":"t2","intent":"test code","dependencies":["t1"],"payload":{"code":"..."}}
]'

# Run single agent
~/workspace/Flynn-Agent/scripts/claude-python-bridge.sh run-agent code-writer-agent '{
  "task_id":"t1",
  "intent":"generate code",
  "payload":{"description":"multiply two numbers","function_name":"multiply"}
}'

# List available agents
~/workspace/Flynn-Agent/scripts/claude-python-bridge.sh list-agents
```

**When to Use Hybrid Mode:**

✅ Complex workflows (3+ agents with dependencies)
✅ Need reproducible results (testing, CI/CD)
✅ Parallel execution optimization
✅ Production-grade error handling
✅ Proven reliability (200+ tests, 85% coverage)

**Advantages:**

| Feature | Claude Only | Hybrid Mode |
|---------|-------------|-------------|
| Intelligence | ✅ Full Claude reasoning | ✅ Full Claude reasoning |
| Orchestration | Manual coordination | ✅ DAG execution |
| Cycle Detection | Manual | ✅ Automatic DFS |
| Error Handling | Ad-hoc | ✅ Structured exceptions |
| Testing | None | ✅ 200+ tests |
| Reproducibility | Variable | ✅ Consistent |
| Parallel Execution | Often sequential | ✅ Optimal parallelization |

---

## 🤖 Available Agents

### Core Agents (4)
- **orchestrator-agent** - Multi-agent coordination and task decomposition
- **context-manager-agent** - Central knowledge repository and state management
- **query-analyzer-agent** - Intelligent query analysis and tool recommendation
- **tool-router-agent** - Dynamic tool routing with Context7-first policy

### Development Agents (7)
- **code-writer-agent** - Clean, maintainable code generation
- **pragmatic-code-review-agent** - Balanced code review (quality + velocity)
- **design-review-agent** - UI/UX and WCAG accessibility review
- **testing-agent** - Comprehensive test strategy and generation
- **security-agent** - Security analysis and OWASP compliance
- **documentation-agent** - Technical documentation generation
- **implementation-planning-agent** - Strategic planning and execution

### Infrastructure Agents (3)
- **devops-agent** - CI/CD pipelines and deployment automation
- **database-agent** - Schema design and query optimization
- **performance-agent** - Performance profiling and Core Web Vitals

### Specialized Agents (2)
- **migration-agent** - Framework and language migrations
- **localization-agent** - i18n/l10n specialist

### Optional Agents (1)
- **api-design-agent** - REST/GraphQL API design

### Experimental Agents (3)
- **learning-agent** - Adaptive learning and pattern recognition
- **predictive-agent** - Complexity and effort prediction
- **meta-agent** - System improvement and optimization

---

## 🎯 Skills

Reusable skill modules available via the `Skill` tool or Python API:

- **python-engine** - Execute tasks using production-tested Python orchestration (NEW)
- **github-workflow** - GitHub integration and workflows
- **deep-thinking** - Sequential thinking for complex problems
- **smart-research** - Context7 + Serper research
- **api-development** - API development workflows
- **confidence-check** - Pre-implementation confidence assessment (≥90%)
- **security-check** - Pre-implementation security validation (OWASP)
- **browser-automation** - Playwright browser automation

**python-engine Skill:**
The python-engine skill enables Hybrid Mode by allowing Claude to leverage the production-tested Python orchestration engine. See `~/.claude/skills/python-engine/SKILL.md` for details.

---

## 🏗️ Architecture

Flynn-Agent uses a **dual-architecture approach**:

### 1. Claude Integration Layer

```
~/.claude/
├── agents/       # 24 Agent definitions (Markdown)
├── commands/     # Slash commands (/agentic, /agent, /agents)
├── skills/       # Reusable skills
└── schemas/      # JSON schemas & protocols
```

### 2. Python Core Engine

```
flynn_agent/
├── orchestrator.py   # DAG execution engine
├── registry.py       # Agent discovery & selection
├── base.py          # BaseAgent abstract class
├── models.py        # TaskSpec, AgentResult dataclasses
├── agents/          # Agent implementations
│   ├── core/
│   ├── development/
│   ├── infrastructure/
│   └── experimental/
└── cli.py           # Command-line interface
```

**Key Features:**
- ✅ **Async DAG Orchestration** - Parallel task execution
- ✅ **Cycle Detection** - Prevents infinite loops
- ✅ **Error Handling** - Graceful failure recovery
- ✅ **Context Sharing** - Thread-safe shared state
- ✅ **Input Validation** - Prevents code injection
- ✅ **Capability-Based Routing** - 90%+ accuracy

---

## 🛠️ Configuration

### API Keys (Claude Integration)

Flynn-Agent requires API keys for various MCP servers:

- **Context7**: https://context7.com
- **GitHub Token**: https://github.com/settings/tokens
  - Required scopes: `repo`, `read:org`, `workflow`
- **Serper**: https://serper.dev (2,500 free searches/month)

Add these to your `.env` file (see `.env.example`).

### Python Configuration

No API keys needed for standalone Python usage. All agents work offline.

---

## 🧪 Testing

Run the comprehensive test suite:

```bash
# All tests
pytest tests/ -v

# With coverage
pytest tests/ --cov=flynn_agent --cov-report=html

# Specific test categories
pytest tests/unit/ -v
pytest tests/integration/ -v
pytest tests/agents/ -v
```

**Test Coverage:**
- ✅ 200+ test cases
- ✅ 85% code coverage
- ✅ Unit tests for all core components
- ✅ Integration tests for workflows
- ✅ Agent-specific tests

---

## 📚 Documentation

- **[Python Implementation Guide](docs/PYTHON_IMPLEMENTATION.md)** - Core architecture
- **[Claude Integration Guide](docs/README-CLAUDE-INTEGRATION.md)** - Claude Code setup
- **[Implementation Plan](IMPLEMENTATION_PLAN.md)** - Development roadmap
- **[Agent Deep Dive](AGENT_DEEP_DIVE_REVIEW.md)** - Detailed agent analysis
- **[Review Summary](REVIEW_SUMMARY.md)** - Complete review report

---

## 🗑️ Uninstallation

```bash
cd flynn-agent
./uninstall.sh
```

This will:
- Create a backup before removal
- Remove Claude integration (if installed)
- Uninstall Python package (if installed)
- Preserve your configuration files

---

## 🤝 Contributing

Contributions are welcome! Please see our contributing guidelines.

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🐛 Support & Issues

- **Issues**: [GitHub Issues](https://github.com/reze83/flynn-agent/issues)
- **Discussions**: [GitHub Discussions](https://github.com/reze83/flynn-agent/discussions)
- **Documentation**: [Full Docs](docs/)

---

## 🙏 Acknowledgments

Built with:
- [Claude Code](https://claude.ai/code) by Anthropic
- [Model Context Protocol (MCP)](https://modelcontextprotocol.io/)
- Various MCP servers for extended functionality

Special thanks to the open-source community!

---

## 📊 Project Status

**Current Version**: 1.0.0 (Merged Python + Claude Integration)
**Status**: Production Ready
**Test Coverage**: 85%+
**Platform**: Linux, WSL, macOS
**Python**: 3.9+

---

**Built with ❤️ for the open-source community**

*Flynn-Agent - Intelligent task orchestration for Claude Code and beyond*
