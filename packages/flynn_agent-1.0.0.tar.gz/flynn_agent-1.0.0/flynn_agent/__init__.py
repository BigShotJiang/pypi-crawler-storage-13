"""Top-level package for the Flynn-Agent multi‑agent framework.

This package provides a modular, asynchronous framework for orchestrating
specialised AI agents. It exposes the primary classes and functions needed
to construct and run agentic workflows, including:

* dataclasses for task specifications and agent results;
* a base class that all agents derive from, enforcing a consistent
  execution template;
* a registry that allows dynamic discovery of available agents;
* an asynchronous orchestrator capable of executing a directed acyclic
  graph (DAG) of tasks concurrently;
* context and cache managers for sharing state across agents;
* stubs for an MCP (multi‑capability provider) manager and skill
  abstractions.

The framework is designed to run completely offline and deterministically,
without network access. It follows the architecture described in the
original Flynn‑Agent repository, with Tier 1 agents fully implemented and
Tier 2 agents provided as extendable stubs.

Refer to the module documentation in `flynn_agent.models` and
`flynn_agent.base` for more details on the execution model.

"""

from .models import TaskSpec, AgentResult, Capabilities  # noqa:F401
from .registry import AgentRegistry  # noqa:F401
from .orchestrator import Orchestrator  # noqa:F401