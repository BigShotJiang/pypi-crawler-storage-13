"""Context management for Flynn‑Agent.

The context manager stores shared state and documentation snapshots
available to all agents. It exposes simple get/set operations and
supports versioned snapshots and rollback. In this initial
implementation the functionality is minimal; a persistent backend can be
plugged in later.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict


class ContextStore:
    """A simple in‑memory context store.

    Keys are arbitrary strings and values are versioned. The store
    supports snapshotting and rollback by maintaining a history of
    versions for each key.
    """

    def __init__(self) -> None:
        self._store: Dict[str, Any] = {}
        self._history: Dict[str, list] = defaultdict(list)

    def get(self, key: str, default: Any = None) -> Any:
        return self._store.get(key, default)

    def set(self, key: str, value: Any) -> None:
        # record previous value in history
        if key in self._store:
            self._history[key].append(self._store[key])
        self._store[key] = value

    def snapshot(self) -> Dict[str, Any]:
        """Return a copy of the current context."""
        return self._store.copy()

    def rollback(self) -> None:
        """Rollback to the previous version for all keys if available."""
        for key, hist in self._history.items():
            if hist:
                self._store[key] = hist.pop()