"""Module executed when running ``python -m flynn_agent``."""

from .cli import main


if __name__ == "__main__":  # pragma: no cover
    main()