"""Simulated MCP Manager.

The MCPManager acts as a broker for external capabilities defined in
`.claude/skills` and `.claude/mcp`. In this offline implementation it
supports lazy loading of backends and returning static information. This
allows agents such as the ToolRouterAgent to request functionality
without performing network calls.
"""

from __future__ import annotations

from typing import Any, Dict, Set


class MCPManager:
    """Manage simulated MCP servers and skills.

    The manager loads backends on demand. Each backend is a simple
    dictionary mapping from a capability name to a static description.
    """

    def __init__(self) -> None:
        self.loaded: Set[str] = set()
        self.backends: Dict[str, Dict[str, Any]] = {}

    def load(self, name: str) -> None:
        """Load a backend lazily if not already loaded."""
        if name in self.loaded:
            return
        # in v1 we simulate loading by creating a static mapping
        self.backends[name] = {
            "description": f"Simulated backend for {name}",
            "version": "1.0",
        }
        self.loaded.add(name)

    def get_backend(self, name: str) -> Dict[str, Any]:
        """Return a backend; load it if necessary."""
        if name not in self.loaded:
            self.load(name)
        return self.backends[name]