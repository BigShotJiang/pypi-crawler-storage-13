"""MCP (Multi‑Capability Provider) abstractions.

This package contains the MCPManager responsible for lazy loading and
managing external capabilities (simulated offline). It also contains
stubs for individual MCP backends. For v1 these classes are largely
placeholders and simply return static data.
"""

from .manager import MCPManager  # noqa: F401