"""Data models used throughout the Flynn‑Agent framework.

This module defines the core dataclasses that describe the inputs and
outputs of agents as well as enumerations for their capabilities. The
definitions mirror the specification in the system prompt and are used
throughout the orchestrator and agent implementations.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set
from typing_extensions import Literal


@dataclass
class TaskSpec:
    """Specification for a unit of work executed by an agent.

    Attributes
    ----------
    task_id: unique identifier for the task within a workflow.
    intent: high‑level intent of the task. This informs agent selection.
    payload: arbitrary dictionary containing the input data for the task.
    context: shared contextual information available to the agent.
    dependencies: list of task IDs that must complete before this task can
      execute.
    parent_task_id: ID of the parent task if this is a subtask, otherwise
      ``None``.
    depth: depth in the task tree. ``0`` indicates a top‑level task.
    mode: either ``"normal"`` or ``"ultrathink"`` to indicate whether
      deep reasoning is enabled.
    goal: explicit, normalised goal string describing the desired outcome.
    require_fresh_docs: if ``True``, documentation freshness must be
      validated before execution.
    """

    task_id: str
    intent: str
    payload: Dict[str, Any]
    context: Dict[str, Any] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)
    parent_task_id: Optional[str] = None
    depth: int = 0
    mode: str = "normal"
    goal: str = ""
    require_fresh_docs: bool = False


@dataclass
class AgentResult:
    """Represents the outcome of executing a task by an agent.

    Attributes
    ----------
    agent: name of the agent that produced this result.
    success: whether the agent succeeded in completing its task.
    output: arbitrary output payload produced by the agent.
    diagnostics: structured diagnostic information for auditing and
      debugging. Agents should populate this with the reasoning steps
      undertaken and any tool usage or subgoals pursued.
    cache_key: optional cache key used to store/retrieve results.
    status_code: enumerated status of the result (e.g. OK, RETRY).
    """

    agent: str
    success: bool
    output: Any
    diagnostics: Dict[str, Any] = field(default_factory=dict)
    cache_key: Optional[str] = None
    status_code: Literal[
        "OK",
        "RETRY",
        "BLOCKED",
        "INVALID_INPUT",
        "FRESH_DOCS_REQUIRED",
    ] = "OK"


class Capabilities(str, enum.Enum):
    """Enumeration of agent capabilities.

    Each capability corresponds to a specialised area of expertise that
    agents may advertise. The orchestrator and tool router use these
    capabilities to determine which agent should handle a given task.
    """

    CODE_GEN = "code_generation"
    SECURITY = "security_analysis"
    TESTING = "testing"
    DB = "database"
    PERFORMANCE = "performance"
    DOCS = "documentation"
    REVIEW = "review"
    META = "meta_reasoning"
    ROUTING = "routing"
    ANALYSIS = "analysis"