"""Database schema design, query optimization, and migration management agent.

This agent analyzes database designs for:
- Normalization (1NF, 2NF, 3NF, BCNF)
- Query optimization and N+1 detection
- Index recommendations
- Migration generation (Alembic, Django, Prisma)
- Performance analysis and best practices

Supports: PostgreSQL, MySQL, MongoDB
"""

from __future__ import annotations

import re
import json
from typing import Any, Dict, List, Set, Tuple, Optional
from dataclasses import dataclass
from datetime import datetime

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@dataclass
class DatabaseIssue:
    """Represents a detected database design or performance issue."""
    severity: str  # "critical", "high", "medium", "low"
    category: str  # "normalization", "indexing", "query", "migration"
    issue_type: str
    description: str
    line_number: int = 0
    recommendation: str = ""
    affected_tables: List[str] = None

    def __post_init__(self):
        if self.affected_tables is None:
            self.affected_tables = []


@AgentRegistry.global_registry().register
class DatabaseAgent(BaseAgent):
    """Database schema design, query optimization, and migration specialist."""

    name = "database-agent"
    description = "Database schema design, query optimization, migration management"
    capabilities = {Capabilities.DB}

    # Database best practice categories
    NORMALIZATION_LEVELS = ["1NF", "2NF", "3NF", "BCNF"]

    # Common SQL keywords for query analysis
    SQL_KEYWORDS = {
        "SELECT", "FROM", "WHERE", "JOIN", "LEFT JOIN", "RIGHT JOIN",
        "INNER JOIN", "OUTER JOIN", "GROUP BY", "ORDER BY", "HAVING",
        "INSERT", "UPDATE", "DELETE", "CREATE", "ALTER", "DROP"
    }

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> List[str]:
        """Run database analysis based on task type."""
        task_type = spec.payload.get("task_type", "analyze_schema")

        if task_type == "analyze_schema":
            return await self._analyze_schema_design(spec.payload)
        elif task_type == "optimize_query":
            return await self._optimize_query(spec.payload)
        elif task_type == "generate_migration":
            return await self._generate_migration(spec.payload)
        elif task_type == "review_performance":
            return await self._review_performance(spec.payload)
        elif task_type == "detect_n_plus_one":
            return await self._detect_n_plus_one(spec.payload)
        else:
            return [f"Unknown task_type: {task_type}"]

    async def _analyze_schema_design(self, payload: Dict[str, Any]) -> List[str]:
        """Analyze database schema for normalization and design issues."""
        schema_sql = payload.get("schema", "")
        db_type = payload.get("db_type", "postgresql")

        if not schema_sql.strip():
            return ["No schema provided for analysis."]

        issues: List[DatabaseIssue] = []

        # Parse schema
        tables = self._parse_schema(schema_sql)

        # Check normalization
        issues.extend(self._check_normalization(tables))

        # Check primary/foreign keys
        issues.extend(self._check_keys(tables))

        # Check data types
        issues.extend(self._check_data_types(tables, db_type))

        # Check indexing
        issues.extend(self._check_indexes(tables))

        return self._format_schema_results(issues, tables)

    def _parse_schema(self, schema_sql: str) -> Dict[str, Dict[str, Any]]:
        """Parse SQL schema into structured format."""
        tables = {}
        current_table = None

        lines = schema_sql.split('\n')
        for line in lines:
            line = line.strip()

            # CREATE TABLE detection
            create_match = re.match(r'CREATE TABLE\s+(\w+)\s*\(', line, re.IGNORECASE)
            if create_match:
                current_table = create_match.group(1)
                tables[current_table] = {
                    "columns": {},
                    "primary_keys": [],
                    "foreign_keys": [],
                    "indexes": [],
                    "constraints": []
                }
                continue

            if current_table and line and not line.startswith(')'):
                # Parse column definition
                col_match = re.match(r'(\w+)\s+(\w+(?:\(\d+(?:,\d+)?\))?)(.*)', line.rstrip(','))
                if col_match:
                    col_name, col_type, constraints = col_match.groups()
                    tables[current_table]["columns"][col_name] = {
                        "type": col_type,
                        "constraints": constraints.strip()
                    }

                    # Check for PRIMARY KEY
                    if "PRIMARY KEY" in constraints.upper():
                        tables[current_table]["primary_keys"].append(col_name)

                    # Check for FOREIGN KEY
                    fk_match = re.search(r'REFERENCES\s+(\w+)\s*\((\w+)\)', constraints, re.IGNORECASE)
                    if fk_match:
                        ref_table, ref_col = fk_match.groups()
                        tables[current_table]["foreign_keys"].append({
                            "column": col_name,
                            "references": {"table": ref_table, "column": ref_col}
                        })

        return tables

    def _check_normalization(self, tables: Dict[str, Dict[str, Any]]) -> List[DatabaseIssue]:
        """Check for normalization violations (1NF, 2NF, 3NF)."""
        issues = []

        for table_name, table_info in tables.items():
            columns = table_info["columns"]

            # 1NF: Check for repeating groups (columns with numbers: col1, col2, col3)
            column_patterns = {}
            for col_name in columns.keys():
                base = re.sub(r'\d+$', '', col_name)
                if base != col_name:
                    column_patterns.setdefault(base, []).append(col_name)

            for base, cols in column_patterns.items():
                if len(cols) >= 2:
                    issues.append(DatabaseIssue(
                        severity="high",
                        category="normalization",
                        issue_type="1NF_violation",
                        description=f"Repeating group detected: {', '.join(cols)}",
                        affected_tables=[table_name],
                        recommendation=f"Create separate table for {base} with foreign key to {table_name}. "
                                     f"Example: CREATE TABLE {table_name}_{base} (id, {table_name}_id, {base}_value)"
                    ))

            # 2NF: Check for partial dependencies (composite primary keys)
            if len(table_info["primary_keys"]) > 1:
                issues.append(DatabaseIssue(
                    severity="medium",
                    category="normalization",
                    issue_type="2NF_check_required",
                    description=f"Composite primary key detected: {', '.join(table_info['primary_keys'])}",
                    affected_tables=[table_name],
                    recommendation="Verify all non-key columns depend on the ENTIRE primary key, not just part of it. "
                                 "If partial dependency exists, extract to separate table."
                ))

            # 3NF: Check for potential transitive dependencies
            # Look for columns that might depend on other non-key columns
            non_key_cols = [col for col in columns.keys() if col not in table_info["primary_keys"]]
            if len(non_key_cols) > 5:
                issues.append(DatabaseIssue(
                    severity="low",
                    category="normalization",
                    issue_type="3NF_check_required",
                    description=f"Table has {len(non_key_cols)} non-key columns",
                    affected_tables=[table_name],
                    recommendation="Review for transitive dependencies (A→B→C). "
                                 "Extract derived or dependent columns to separate tables."
                ))

        return issues

    def _check_keys(self, tables: Dict[str, Dict[str, Any]]) -> List[DatabaseIssue]:
        """Check for missing primary keys and foreign key issues."""
        issues = []

        for table_name, table_info in tables.items():
            # Missing primary key
            if not table_info["primary_keys"]:
                issues.append(DatabaseIssue(
                    severity="critical",
                    category="schema_design",
                    issue_type="missing_primary_key",
                    description=f"Table '{table_name}' has no primary key",
                    affected_tables=[table_name],
                    recommendation=f"Add primary key: ALTER TABLE {table_name} ADD COLUMN id SERIAL PRIMARY KEY; (PostgreSQL)"
                ))

            # Check foreign key references exist
            for fk in table_info["foreign_keys"]:
                ref_table = fk["references"]["table"]
                if ref_table not in tables:
                    issues.append(DatabaseIssue(
                        severity="critical",
                        category="schema_design",
                        issue_type="broken_foreign_key",
                        description=f"Foreign key references non-existent table '{ref_table}'",
                        affected_tables=[table_name, ref_table],
                        recommendation=f"Create table '{ref_table}' or fix foreign key reference"
                    ))

        return issues

    def _check_data_types(self, tables: Dict[str, Dict[str, Any]], db_type: str) -> List[DatabaseIssue]:
        """Check for data type optimization opportunities."""
        issues = []

        for table_name, table_info in tables.items():
            for col_name, col_info in table_info["columns"].items():
                col_type = col_info["type"].upper()

                # VARCHAR without length limit
                if "VARCHAR" in col_type and "(" not in col_type:
                    issues.append(DatabaseIssue(
                        severity="medium",
                        category="data_types",
                        issue_type="unbounded_varchar",
                        description=f"{table_name}.{col_name}: VARCHAR without length limit",
                        affected_tables=[table_name],
                        recommendation="Specify VARCHAR length or use TEXT for large content"
                    ))

                # TEXT for short strings
                if col_type == "TEXT" and "name" in col_name.lower():
                    issues.append(DatabaseIssue(
                        severity="low",
                        category="data_types",
                        issue_type="inefficient_type",
                        description=f"{table_name}.{col_name}: TEXT type for likely short string",
                        affected_tables=[table_name],
                        recommendation="Consider VARCHAR(255) for better indexing performance"
                    ))

                # INT for boolean-like columns
                if col_type.startswith("INT") and re.match(r'is_|has_|can_|should_', col_name):
                    issues.append(DatabaseIssue(
                        severity="low",
                        category="data_types",
                        issue_type="suboptimal_type",
                        description=f"{table_name}.{col_name}: INT type for boolean column",
                        affected_tables=[table_name],
                        recommendation="Use BOOLEAN type for clarity and space efficiency"
                    ))

        return issues

    def _check_indexes(self, tables: Dict[str, Dict[str, Any]]) -> List[DatabaseIssue]:
        """Check for missing indexes on foreign keys and frequently queried columns."""
        issues = []

        for table_name, table_info in tables.items():
            # Foreign keys without indexes
            for fk in table_info["foreign_keys"]:
                fk_col = fk["column"]
                # Check if index exists for this column
                has_index = any(idx for idx in table_info["indexes"] if fk_col in idx)
                if not has_index:
                    issues.append(DatabaseIssue(
                        severity="high",
                        category="indexing",
                        issue_type="missing_fk_index",
                        description=f"Foreign key '{fk_col}' in '{table_name}' has no index",
                        affected_tables=[table_name],
                        recommendation=f"CREATE INDEX idx_{table_name}_{fk_col} ON {table_name}({fk_col});"
                    ))

            # Suggest composite indexes for multi-column queries
            if len(table_info["foreign_keys"]) >= 2:
                fk_cols = [fk["column"] for fk in table_info["foreign_keys"][:2]]
                issues.append(DatabaseIssue(
                    severity="low",
                    category="indexing",
                    issue_type="composite_index_suggestion",
                    description=f"Consider composite index for frequently joined columns",
                    affected_tables=[table_name],
                    recommendation=f"CREATE INDEX idx_{table_name}_composite ON {table_name}({', '.join(fk_cols)});"
                ))

        return issues

    async def _optimize_query(self, payload: Dict[str, Any]) -> List[str]:
        """Analyze SQL query for optimization opportunities."""
        query = payload.get("query", "")
        db_type = payload.get("db_type", "postgresql")

        if not query.strip():
            return ["No query provided for optimization."]

        issues: List[DatabaseIssue] = []

        # Check for SELECT *
        if re.search(r'SELECT\s+\*', query, re.IGNORECASE):
            issues.append(DatabaseIssue(
                severity="medium",
                category="query",
                issue_type="select_star",
                description="Using SELECT * instead of explicit columns",
                recommendation="Specify only needed columns: SELECT col1, col2 FROM table. "
                             "Benefits: reduced I/O, prevents breaking changes, better performance."
            ))

        # Check for missing WHERE clause on large tables
        if re.search(r'SELECT\s+.*\s+FROM\s+\w+(?!\s+WHERE)', query, re.IGNORECASE):
            issues.append(DatabaseIssue(
                severity="high",
                category="query",
                issue_type="missing_where_clause",
                description="Query without WHERE clause may scan entire table",
                recommendation="Add WHERE clause to limit rows scanned. Use LIMIT for pagination."
            ))

        # Check for functions in WHERE clause
        func_in_where = re.search(r'WHERE\s+.*\b(UPPER|LOWER|SUBSTR|DATE)\s*\(', query, re.IGNORECASE)
        if func_in_where:
            issues.append(DatabaseIssue(
                severity="high",
                category="query",
                issue_type="non_sargable_predicate",
                description="Function call in WHERE clause prevents index usage",
                recommendation="Create functional index or restructure query. "
                             "Example: Instead of WHERE UPPER(name) = 'JOHN', use WHERE name = 'JOHN' with case-insensitive collation."
            ))

        # Check for OR conditions (can prevent index usage)
        if re.search(r'WHERE\s+.*\bOR\b', query, re.IGNORECASE):
            issues.append(DatabaseIssue(
                severity="medium",
                category="query",
                issue_type="or_condition",
                description="OR conditions can prevent index usage in some databases",
                recommendation="Consider UNION instead of OR, or use IN clause if applicable. "
                             "Example: WHERE status IN ('active', 'pending') instead of status = 'active' OR status = 'pending'"
            ))

        # Check for subqueries in SELECT
        if re.search(r'SELECT\s+.*\(SELECT', query, re.IGNORECASE):
            issues.append(DatabaseIssue(
                severity="medium",
                category="query",
                issue_type="scalar_subquery",
                description="Scalar subquery in SELECT executes once per row",
                recommendation="Use JOIN instead of scalar subquery for better performance. "
                             "Move subquery to FROM clause with LEFT JOIN."
            ))

        # Check for OFFSET pagination on large datasets
        offset_match = re.search(r'OFFSET\s+(\d+)', query, re.IGNORECASE)
        if offset_match and int(offset_match.group(1)) > 1000:
            issues.append(DatabaseIssue(
                severity="high",
                category="query",
                issue_type="inefficient_pagination",
                description=f"OFFSET {offset_match.group(1)} scans and discards many rows",
                recommendation="Use keyset pagination (WHERE id > last_id ORDER BY id LIMIT 100) for better performance on large datasets."
            ))

        return self._format_query_results(issues, query)

    async def _detect_n_plus_one(self, payload: Dict[str, Any]) -> List[str]:
        """Detect N+1 query problems in ORM code."""
        code = payload.get("code", "")
        orm_type = payload.get("orm", "sqlalchemy")  # sqlalchemy, django, prisma

        if not code.strip():
            return ["No code provided for N+1 detection."]

        issues: List[DatabaseIssue] = []
        lines = code.split('\n')

        # Pattern: query in loop
        for i, line in enumerate(lines, 1):
            # Detect loop patterns
            if re.search(r'for\s+\w+\s+in\s+', line):
                # Check next 10 lines for queries
                context = '\n'.join(lines[i:min(i+10, len(lines))])

                # SQLAlchemy patterns
                if orm_type == "sqlalchemy":
                    if re.search(r'\.(query|filter|get|all)\(', context):
                        issues.append(DatabaseIssue(
                            severity="critical",
                            category="query",
                            issue_type="n_plus_one",
                            description=f"Potential N+1 query at line {i}: query inside loop",
                            line_number=i,
                            recommendation="Use eager loading: query(User).options(joinedload(User.posts)).all() "
                                         "or selectinload() for collection relationships."
                        ))

                # Django ORM patterns
                elif orm_type == "django":
                    if re.search(r'\.(filter|get|all)\(', context):
                        issues.append(DatabaseIssue(
                            severity="critical",
                            category="query",
                            issue_type="n_plus_one",
                            description=f"Potential N+1 query at line {i}: query inside loop",
                            line_number=i,
                            recommendation="Use select_related() for foreign keys or prefetch_related() for many-to-many. "
                                         "Example: User.objects.select_related('profile').all()"
                        ))

                # Prisma patterns (TypeScript/JS)
                elif orm_type == "prisma":
                    if re.search(r'await\s+prisma\.\w+\.(findMany|findUnique)', context):
                        issues.append(DatabaseIssue(
                            severity="critical",
                            category="query",
                            issue_type="n_plus_one",
                            description=f"Potential N+1 query at line {i}: Prisma query inside loop",
                            line_number=i,
                            recommendation="Use include or select to eager load: findMany({ include: { posts: true } })"
                        ))

        return self._format_query_results(issues, code)

    async def _generate_migration(self, payload: Dict[str, Any]) -> List[str]:
        """Generate database migration scripts."""
        migration_type = payload.get("migration_type", "alembic")  # alembic, django, prisma
        operation = payload.get("operation", "add_column")  # add_column, add_table, add_index
        table_name = payload.get("table_name", "")
        details = payload.get("details", {})

        if not table_name:
            return ["No table name provided for migration."]

        timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")

        if migration_type == "alembic":
            return self._generate_alembic_migration(operation, table_name, details, timestamp)
        elif migration_type == "django":
            return self._generate_django_migration(operation, table_name, details, timestamp)
        elif migration_type == "prisma":
            return self._generate_prisma_migration(operation, table_name, details)
        else:
            return [f"Unknown migration_type: {migration_type}"]

    def _generate_alembic_migration(self, operation: str, table: str, details: Dict, ts: str) -> List[str]:
        """Generate Alembic migration (Python/SQLAlchemy)."""
        revision_id = f"rev_{ts}"

        if operation == "add_column":
            col_name = details.get("column_name", "new_column")
            col_type = details.get("column_type", "String(255)")
            nullable = details.get("nullable", True)

            migration = f'''"""Add {col_name} to {table}

Revision ID: {revision_id}
Create Date: {datetime.utcnow().isoformat()}
"""

from alembic import op
import sqlalchemy as sa

revision = '{revision_id}'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.add_column('{table}',
        sa.Column('{col_name}', sa.{col_type}, nullable={nullable})
    )

def downgrade():
    op.drop_column('{table}', '{col_name}')
'''
            return [migration]

        elif operation == "add_index":
            columns = details.get("columns", ["id"])
            index_name = f"idx_{table}_{'_'.join(columns)}"

            migration = f'''"""Add index on {table}

Revision ID: {revision_id}
"""

from alembic import op

revision = '{revision_id}'

def upgrade():
    op.create_index('{index_name}', '{table}', {columns})

def downgrade():
    op.drop_index('{index_name}', table_name='{table}')
'''
            return [migration]

        return [f"Unsupported operation: {operation}"]

    def _generate_django_migration(self, operation: str, table: str, details: Dict, ts: str) -> List[str]:
        """Generate Django migration."""
        if operation == "add_column":
            col_name = details.get("column_name", "new_field")
            field_type = details.get("field_type", "CharField")
            max_length = details.get("max_length", 255)

            migration = f'''# Generated migration - {ts}

from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('app', 'previous_migration'),
    ]

    operations = [
        migrations.AddField(
            model_name='{table.lower()}',
            name='{col_name}',
            field=models.{field_type}(max_length={max_length}, blank=True),
        ),
    ]
'''
            return [migration]

        return [f"Unsupported operation: {operation}"]

    def _generate_prisma_migration(self, operation: str, table: str, details: Dict) -> List[str]:
        """Generate Prisma schema update (manual migration)."""
        if operation == "add_column":
            col_name = details.get("column_name", "newField")
            col_type = details.get("column_type", "String")

            schema_update = f'''// Add to schema.prisma:

model {table.capitalize()} {{
  // ... existing fields ...
  {col_name}  {col_type}?  // Optional field
}}

// Then run: npx prisma migrate dev --name add_{col_name}_to_{table}
'''
            return [schema_update]

        return [f"Unsupported operation: {operation}"]

    async def _review_performance(self, payload: Dict[str, Any]) -> List[str]:
        """Review database performance and provide recommendations."""
        slow_queries = payload.get("slow_queries", [])
        connection_pool_size = payload.get("connection_pool_size", 10)
        avg_query_time = payload.get("avg_query_time_ms", 0)

        recommendations = []

        # Connection pool sizing
        if connection_pool_size < 5:
            recommendations.append("⚠️  Connection pool too small (< 5). Increase to at least 10 for better concurrency.")
        elif connection_pool_size > 50:
            recommendations.append("⚠️  Connection pool too large (> 50). Reduce to prevent resource exhaustion.")

        # Average query time
        if avg_query_time > 1000:
            recommendations.append(f"🔴 Average query time {avg_query_time}ms is high. Target < 100ms for interactive queries.")
        elif avg_query_time > 500:
            recommendations.append(f"🟡 Average query time {avg_query_time}ms is moderate. Consider optimization.")

        # Slow query analysis
        if slow_queries:
            recommendations.append(f"\n📊 Slow Query Analysis ({len(slow_queries)} queries):\n")
            for i, query in enumerate(slow_queries[:5], 1):
                recommendations.append(f"{i}. {query.get('query', 'N/A')[:100]}...")
                recommendations.append(f"   Time: {query.get('time_ms', 0)}ms")
                recommendations.append(f"   Recommendation: Run EXPLAIN ANALYZE to identify bottlenecks\n")

        # General recommendations
        recommendations.append("\n💡 General Performance Tips:")
        recommendations.append("1. Enable query logging for slow queries (> 1000ms)")
        recommendations.append("2. Use connection pooling (pgBouncer for PostgreSQL)")
        recommendations.append("3. Implement query result caching (Redis)")
        recommendations.append("4. Monitor table bloat and run VACUUM regularly")
        recommendations.append("5. Use EXPLAIN ANALYZE for query plan analysis")

        return recommendations

    def _format_schema_results(self, issues: List[DatabaseIssue], tables: Dict) -> List[str]:
        """Format schema analysis results."""
        if not issues:
            return [f"✅ Schema analysis complete. No issues found. Analyzed {len(tables)} tables."]

        results = ["# Database Schema Analysis Report\n"]
        results.append(f"**Tables Analyzed**: {len(tables)}")
        results.append(f"**Issues Found**: {len(issues)}\n")

        # Group by severity
        by_severity = {"critical": [], "high": [], "medium": [], "low": []}
        for issue in issues:
            by_severity[issue.severity].append(issue)

        for severity in ["critical", "high", "medium", "low"]:
            severity_issues = by_severity[severity]
            if not severity_issues:
                continue

            emoji = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵"}[severity]
            results.append(f"\n## {emoji} {severity.upper()} ({len(severity_issues)} issues)\n")

            for issue in severity_issues:
                results.append(f"### {issue.issue_type}")
                results.append(f"**Category**: {issue.category}")
                if issue.affected_tables:
                    results.append(f"**Tables**: {', '.join(issue.affected_tables)}")
                results.append(f"**Description**: {issue.description}")
                results.append(f"**Recommendation**: {issue.recommendation}\n")

        return results

    def _format_query_results(self, issues: List[DatabaseIssue], query: str) -> List[str]:
        """Format query optimization results."""
        if not issues:
            return ["✅ Query analysis complete. No optimization suggestions."]

        results = ["# Query Optimization Report\n"]
        results.append(f"**Issues Found**: {len(issues)}\n")

        for issue in issues:
            emoji = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵"}[issue.severity]
            results.append(f"\n## {emoji} {issue.issue_type.upper()}")
            results.append(f"**Severity**: {issue.severity}")
            if issue.line_number:
                results.append(f"**Line**: {issue.line_number}")
            results.append(f"**Description**: {issue.description}")
            results.append(f"**Recommendation**: {issue.recommendation}\n")

        return results
