"""Performance profiling, optimization, and Core Web Vitals analysis agent.

This agent analyzes performance for:
- Code profiling (cProfile, line_profiler, memory_profiler)
- Core Web Vitals (LCP, FID, CLS)
- Bundle optimization (JavaScript, code splitting)
- Caching strategies (Redis, CDN, browser)
- Algorithm complexity analysis (Big-O)

Supports: Python, JavaScript/TypeScript, Web Applications
"""

from __future__ import annotations

import re
import ast
import json
from typing import Any, Dict, List, Set, Tuple, Optional
from dataclasses import dataclass

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@dataclass
class PerformanceIssue:
    """Represents a detected performance issue."""
    severity: str  # "critical", "high", "medium", "low"
    category: str  # "profiling", "web_vitals", "bundle", "caching", "complexity"
    issue_type: str
    description: str
    line_number: int = 0
    metric_value: Optional[float] = None
    metric_unit: str = ""
    recommendation: str = ""


@AgentRegistry.global_registry().register
class PerformanceAgent(BaseAgent):
    """Performance profiling, optimization, and Core Web Vitals specialist."""

    name = "performance-agent"
    description = "Performance profiling, Core Web Vitals, bundle optimization"
    capabilities = {Capabilities.PERFORMANCE}

    # Core Web Vitals thresholds (Google standards)
    WEB_VITALS_THRESHOLDS = {
        "LCP": {"good": 2500, "needs_improvement": 4000},  # Largest Contentful Paint (ms)
        "FID": {"good": 100, "needs_improvement": 300},    # First Input Delay (ms)
        "CLS": {"good": 0.1, "needs_improvement": 0.25},   # Cumulative Layout Shift (score)
        "FCP": {"good": 1800, "needs_improvement": 3000},  # First Contentful Paint (ms)
        "TTFB": {"good": 800, "needs_improvement": 1800},  # Time to First Byte (ms)
    }

    # Bundle size thresholds (bytes)
    BUNDLE_SIZE_THRESHOLDS = {
        "critical": 500_000,   # 500KB
        "warning": 250_000,    # 250KB
        "good": 100_000,       # 100KB
    }

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> List[str]:
        """Run performance analysis based on task type."""
        task_type = spec.payload.get("task_type", "profile_code")

        if task_type == "profile_code":
            return await self._profile_code(spec.payload)
        elif task_type == "analyze_web_vitals":
            return await self._analyze_web_vitals(spec.payload)
        elif task_type == "optimize_bundle":
            return await self._optimize_bundle(spec.payload)
        elif task_type == "caching_strategy":
            return await self._generate_caching_strategy(spec.payload)
        elif task_type == "complexity_analysis":
            return await self._analyze_complexity(spec.payload)
        else:
            return [f"Unknown task_type: {task_type}"]

    async def _profile_code(self, payload: Dict[str, Any]) -> List[str]:
        """Generate code profiling recommendations and analysis."""
        code = payload.get("code", "")
        language = payload.get("language", "python")
        profiler_type = payload.get("profiler", "cprofile")  # cprofile, line_profiler, memory

        if not code.strip():
            return ["No code provided for profiling."]

        issues: List[PerformanceIssue] = []

        # Static analysis of performance anti-patterns
        if language == "python":
            issues.extend(self._analyze_python_performance(code))
        elif language in ["javascript", "typescript"]:
            issues.extend(self._analyze_js_performance(code))

        # Generate profiling recommendations
        profiling_guide = self._generate_profiling_guide(language, profiler_type)

        return self._format_profiling_results(issues, profiling_guide)

    def _analyze_python_performance(self, code: str) -> List[PerformanceIssue]:
        """Analyze Python code for performance anti-patterns."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # List comprehension in loop (creates multiple lists)
            if re.search(r'for\s+\w+\s+in\s+.*:', stripped):
                context = '\n'.join(lines[i:min(i+5, len(lines))])
                if re.search(r'\[.*for.*in.*\]', context):
                    issues.append(PerformanceIssue(
                        severity="medium",
                        category="profiling",
                        issue_type="nested_list_comp",
                        description="List comprehension inside loop creates multiple intermediate lists",
                        line_number=i,
                        recommendation="Use generator expression or move comprehension outside loop. "
                                     "Example: gen = (x for x in items) instead of [x for x in items]"
                    ))

            # Global variable access in tight loops
            if re.search(r'for\s+\w+\s+in\s+range\(\d{3,}\)', stripped):
                context = '\n'.join(lines[i:min(i+10, len(lines))])
                if re.search(r'\bglobal\s+\w+', context):
                    issues.append(PerformanceIssue(
                        severity="high",
                        category="profiling",
                        issue_type="global_in_loop",
                        description="Global variable access in tight loop (slow lookup)",
                        line_number=i,
                        recommendation="Cache global in local variable before loop. "
                                     "Example: local_var = global_var; for i in range(1000): use local_var"
                    ))

            # String concatenation in loop
            if '+=' in stripped and re.search(r'str|""|\'\' ', stripped):
                issues.append(PerformanceIssue(
                    severity="high",
                    category="profiling",
                    issue_type="string_concat_loop",
                    description="String concatenation with += creates new string each iteration",
                    line_number=i,
                    recommendation="Use list append + ''.join() or io.StringIO for better performance. "
                                 "Example: parts = []; parts.append(s); result = ''.join(parts)"
                ))

            # .append() in tight loop (should use list comprehension)
            if re.search(r'\.append\(', stripped):
                # Check if in loop context
                context_start = max(0, i-5)
                context = '\n'.join(lines[context_start:i])
                if re.search(r'for\s+\w+\s+in\s+', context):
                    issues.append(PerformanceIssue(
                        severity="low",
                        category="profiling",
                        issue_type="append_in_loop",
                        description="Using .append() in loop (list comprehension is faster)",
                        line_number=i,
                        recommendation="Use list comprehension instead. "
                                     "Example: result = [process(x) for x in items] instead of for-append loop"
                    ))

            # dict.keys() in loop
            if re.search(r'\.keys\(\)', stripped):
                issues.append(PerformanceIssue(
                    severity="low",
                    category="profiling",
                    issue_type="unnecessary_keys",
                    description="Using .keys() is unnecessary for dict iteration",
                    line_number=i,
                    recommendation="Iterate dict directly. Example: for key in my_dict: instead of for key in my_dict.keys():"
                ))

            # len() in loop condition
            if re.search(r'for\s+\w+\s+in\s+range\(len\(', stripped):
                issues.append(PerformanceIssue(
                    severity="medium",
                    category="profiling",
                    issue_type="range_len_antipattern",
                    description="Using range(len(...)) instead of enumerate or direct iteration",
                    line_number=i,
                    recommendation="Use enumerate() for indexed iteration or iterate directly. "
                                 "Example: for i, item in enumerate(items): instead of for i in range(len(items)):"
                ))

        return issues

    def _analyze_js_performance(self, code: str) -> List[PerformanceIssue]:
        """Analyze JavaScript/TypeScript code for performance anti-patterns."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # document.querySelector in loop
            if re.search(r'(for|while)\s*\(', stripped):
                context = '\n'.join(lines[i:min(i+10, len(lines))])
                if re.search(r'document\.(querySelector|getElementById)', context):
                    issues.append(PerformanceIssue(
                        severity="high",
                        category="profiling",
                        issue_type="dom_query_in_loop",
                        description="DOM query inside loop (expensive operation)",
                        line_number=i,
                        recommendation="Cache DOM reference before loop. "
                                     "Example: const el = document.querySelector('.item'); for (...) { use el }"
                    ))

            # innerHTML in loop
            if re.search(r'innerHTML\s*[\+\=]', stripped):
                issues.append(PerformanceIssue(
                    severity="high",
                    category="profiling",
                    issue_type="innerhtml_concat",
                    description="innerHTML concatenation triggers reflow/repaint each time",
                    line_number=i,
                    recommendation="Build HTML string first, assign once. Or use DocumentFragment for DOM manipulation."
                ))

            # Array.push in tight loop
            if re.search(r'\.push\(', stripped):
                context_start = max(0, i-3)
                context = '\n'.join(lines[context_start:i])
                if re.search(r'for\s*\(.*of\s+', context):
                    issues.append(PerformanceIssue(
                        severity="low",
                        category="profiling",
                        issue_type="push_in_loop",
                        description="Array.push in loop (map/filter might be faster)",
                        line_number=i,
                        recommendation="Use .map() or .filter() for transformations. "
                                     "Example: result = items.map(x => transform(x))"
                    ))

            # setTimeout with 0 delay
            if re.search(r'setTimeout\s*\(.*,\s*0\)', stripped):
                issues.append(PerformanceIssue(
                    severity="medium",
                    category="profiling",
                    issue_type="settimeout_zero",
                    description="setTimeout(fn, 0) defers to next event loop tick",
                    line_number=i,
                    recommendation="Consider requestAnimationFrame for visual updates or Promise.resolve().then() for async deferral"
                ))

        return issues

    def _generate_profiling_guide(self, language: str, profiler: str) -> List[str]:
        """Generate profiling setup guide."""
        guides = []

        if language == "python":
            if profiler == "cprofile":
                guides.append("# cProfile Setup (Function-level profiling)\n")
                guides.append("```python")
                guides.append("import cProfile")
                guides.append("import pstats")
                guides.append("")
                guides.append("# Profile code")
                guides.append("profiler = cProfile.Profile()")
                guides.append("profiler.enable()")
                guides.append("# Your code here")
                guides.append("profiler.disable()")
                guides.append("")
                guides.append("# Analyze results")
                guides.append("stats = pstats.Stats(profiler)")
                guides.append("stats.sort_stats('cumulative')")
                guides.append("stats.print_stats(20)  # Top 20 functions")
                guides.append("```")

            elif profiler == "line_profiler":
                guides.append("# line_profiler Setup (Line-by-line profiling)\n")
                guides.append("```bash")
                guides.append("pip install line_profiler")
                guides.append("```")
                guides.append("")
                guides.append("```python")
                guides.append("# Add @profile decorator to functions")
                guides.append("@profile")
                guides.append("def my_slow_function():")
                guides.append("    # code here")
                guides.append("    pass")
                guides.append("```")
                guides.append("")
                guides.append("```bash")
                guides.append("# Run profiler")
                guides.append("kernprof -l -v script.py")
                guides.append("```")

            elif profiler == "memory":
                guides.append("# memory_profiler Setup (Memory usage profiling)\n")
                guides.append("```bash")
                guides.append("pip install memory_profiler")
                guides.append("```")
                guides.append("")
                guides.append("```python")
                guides.append("from memory_profiler import profile")
                guides.append("")
                guides.append("@profile")
                guides.append("def my_function():")
                guides.append("    # code here")
                guides.append("    pass")
                guides.append("```")
                guides.append("")
                guides.append("```bash")
                guides.append("python -m memory_profiler script.py")
                guides.append("```")

        elif language in ["javascript", "typescript"]:
            guides.append("# Browser Performance Profiling\n")
            guides.append("## Chrome DevTools")
            guides.append("1. Open DevTools (F12)")
            guides.append("2. Go to Performance tab")
            guides.append("3. Click Record, perform actions, Stop")
            guides.append("4. Analyze flame chart for bottlenecks\n")
            guides.append("## Node.js Profiling")
            guides.append("```bash")
            guides.append("node --prof script.js")
            guides.append("node --prof-process isolate-*-v8.log > processed.txt")
            guides.append("```")

        return guides

    async def _analyze_web_vitals(self, payload: Dict[str, Any]) -> List[str]:
        """Analyze Core Web Vitals metrics."""
        lcp = payload.get("lcp", 0)  # Largest Contentful Paint (ms)
        fid = payload.get("fid", 0)  # First Input Delay (ms)
        cls = payload.get("cls", 0.0)  # Cumulative Layout Shift (score)
        fcp = payload.get("fcp", 0)  # First Contentful Paint (ms)
        ttfb = payload.get("ttfb", 0)  # Time to First Byte (ms)

        issues: List[PerformanceIssue] = []

        # LCP Analysis
        if lcp > self.WEB_VITALS_THRESHOLDS["LCP"]["needs_improvement"]:
            issues.append(PerformanceIssue(
                severity="critical",
                category="web_vitals",
                issue_type="poor_lcp",
                description=f"LCP {lcp}ms exceeds 4000ms (poor)",
                metric_value=lcp,
                metric_unit="ms",
                recommendation="Optimize largest element: 1) Optimize images (WebP, lazy load), "
                             "2) Reduce server response time, 3) Eliminate render-blocking resources, "
                             "4) Use CDN for static assets"
            ))
        elif lcp > self.WEB_VITALS_THRESHOLDS["LCP"]["good"]:
            issues.append(PerformanceIssue(
                severity="medium",
                category="web_vitals",
                issue_type="needs_improvement_lcp",
                description=f"LCP {lcp}ms needs improvement (target: <2500ms)",
                metric_value=lcp,
                metric_unit="ms",
                recommendation="Optimize largest element: preload critical resources, compress images, use image CDN"
            ))

        # FID Analysis
        if fid > self.WEB_VITALS_THRESHOLDS["FID"]["needs_improvement"]:
            issues.append(PerformanceIssue(
                severity="high",
                category="web_vitals",
                issue_type="poor_fid",
                description=f"FID {fid}ms exceeds 300ms (poor)",
                metric_value=fid,
                metric_unit="ms",
                recommendation="Reduce JavaScript execution: 1) Code splitting, 2) Defer non-critical JS, "
                             "3) Use Web Workers for heavy tasks, 4) Minimize main thread work"
            ))
        elif fid > self.WEB_VITALS_THRESHOLDS["FID"]["good"]:
            issues.append(PerformanceIssue(
                severity="medium",
                category="web_vitals",
                issue_type="needs_improvement_fid",
                description=f"FID {fid}ms needs improvement (target: <100ms)",
                metric_value=fid,
                metric_unit="ms",
                recommendation="Reduce JavaScript execution time, split long tasks, use requestIdleCallback"
            ))

        # CLS Analysis
        if cls > self.WEB_VITALS_THRESHOLDS["CLS"]["needs_improvement"]:
            issues.append(PerformanceIssue(
                severity="high",
                category="web_vitals",
                issue_type="poor_cls",
                description=f"CLS {cls} exceeds 0.25 (poor)",
                metric_value=cls,
                metric_unit="score",
                recommendation="Prevent layout shifts: 1) Set dimensions for images/videos, "
                             "2) Reserve space for ads/embeds, 3) Avoid inserting content above existing, "
                             "4) Use transform animations instead of layout properties"
            ))
        elif cls > self.WEB_VITALS_THRESHOLDS["CLS"]["good"]:
            issues.append(PerformanceIssue(
                severity="medium",
                category="web_vitals",
                issue_type="needs_improvement_cls",
                description=f"CLS {cls} needs improvement (target: <0.1)",
                metric_value=cls,
                metric_unit="score",
                recommendation="Set explicit dimensions for media, avoid dynamic content injection"
            ))

        # FCP Analysis
        if fcp and fcp > self.WEB_VITALS_THRESHOLDS["FCP"]["needs_improvement"]:
            issues.append(PerformanceIssue(
                severity="medium",
                category="web_vitals",
                issue_type="poor_fcp",
                description=f"FCP {fcp}ms exceeds 3000ms",
                metric_value=fcp,
                metric_unit="ms",
                recommendation="Optimize initial render: inline critical CSS, defer non-critical CSS, reduce server response time"
            ))

        # TTFB Analysis
        if ttfb and ttfb > self.WEB_VITALS_THRESHOLDS["TTFB"]["needs_improvement"]:
            issues.append(PerformanceIssue(
                severity="high",
                category="web_vitals",
                issue_type="poor_ttfb",
                description=f"TTFB {ttfb}ms exceeds 1800ms",
                metric_value=ttfb,
                metric_unit="ms",
                recommendation="Optimize server: 1) Use CDN, 2) Enable caching, 3) Optimize database queries, "
                             "4) Use HTTP/2, 5) Enable compression (Brotli/gzip)"
            ))

        return self._format_web_vitals_results(issues, {
            "LCP": lcp, "FID": fid, "CLS": cls, "FCP": fcp, "TTFB": ttfb
        })

    async def _optimize_bundle(self, payload: Dict[str, Any]) -> List[str]:
        """Analyze and optimize JavaScript bundle size."""
        bundle_size = payload.get("bundle_size", 0)  # bytes
        bundle_stats = payload.get("bundle_stats", {})  # {module: size}

        issues: List[PerformanceIssue] = []

        # Bundle size analysis
        if bundle_size > self.BUNDLE_SIZE_THRESHOLDS["critical"]:
            issues.append(PerformanceIssue(
                severity="critical",
                category="bundle",
                issue_type="bundle_too_large",
                description=f"Bundle size {bundle_size // 1024}KB exceeds 500KB",
                metric_value=bundle_size / 1024,
                metric_unit="KB",
                recommendation="Critical optimization needed: 1) Code splitting (route-based), "
                             "2) Tree shaking, 3) Remove unused dependencies, 4) Lazy load non-critical modules"
            ))
        elif bundle_size > self.BUNDLE_SIZE_THRESHOLDS["warning"]:
            issues.append(PerformanceIssue(
                severity="high",
                category="bundle",
                issue_type="bundle_warning",
                description=f"Bundle size {bundle_size // 1024}KB exceeds 250KB",
                metric_value=bundle_size / 1024,
                metric_unit="KB",
                recommendation="Implement code splitting, use dynamic imports for routes, enable tree shaking"
            ))

        # Module-level analysis
        if bundle_stats:
            large_modules = [(mod, size) for mod, size in bundle_stats.items() if size > 50_000]
            for module, size in large_modules:
                issues.append(PerformanceIssue(
                    severity="medium",
                    category="bundle",
                    issue_type="large_module",
                    description=f"Module '{module}' is {size // 1024}KB (large)",
                    metric_value=size / 1024,
                    metric_unit="KB",
                    recommendation=f"Optimize '{module}': check for unused exports, consider splitting, use lighter alternative"
                ))

        # General bundle optimization recommendations
        optimization_guide = [
            "\n# Bundle Optimization Strategies\n",
            "## 1. Code Splitting",
            "```javascript",
            "// Route-based splitting (React)",
            "const Home = lazy(() => import('./pages/Home'));",
            "const About = lazy(() => import('./pages/About'));",
            "```",
            "",
            "## 2. Tree Shaking",
            "```javascript",
            "// Use named imports instead of default",
            "import { specific } from 'library';  // Good",
            "import library from 'library';       // Bad (bundles entire library)",
            "```",
            "",
            "## 3. Dynamic Imports",
            "```javascript",
            "// Load heavy library only when needed",
            "button.onclick = async () => {",
            "  const { Chart } = await import('chart.js');",
            "  new Chart(ctx, config);",
            "};",
            "```",
            "",
            "## 4. Webpack Bundle Analyzer",
            "```bash",
            "npm install --save-dev webpack-bundle-analyzer",
            "npx webpack-bundle-analyzer dist/stats.json",
            "```"
        ]

        return self._format_bundle_results(issues, bundle_size, optimization_guide)

    async def _generate_caching_strategy(self, payload: Dict[str, Any]) -> List[str]:
        """Generate caching strategy recommendations."""
        cache_type = payload.get("cache_type", "all")  # all, redis, cdn, browser
        use_case = payload.get("use_case", "web_app")

        strategies = []

        if cache_type in ["all", "redis"]:
            strategies.append("# Redis Caching Strategy\n")
            strategies.append("```python")
            strategies.append("import redis")
            strategies.append("from functools import wraps")
            strategies.append("")
            strategies.append("redis_client = redis.Redis(host='localhost', port=6379)")
            strategies.append("")
            strategies.append("def cache_result(ttl=3600):")
            strategies.append("    def decorator(func):")
            strategies.append("        @wraps(func)")
            strategies.append("        def wrapper(*args, **kwargs):")
            strategies.append("            cache_key = f'{func.__name__}:{args}:{kwargs}'")
            strategies.append("            cached = redis_client.get(cache_key)")
            strategies.append("            if cached:")
            strategies.append("                return json.loads(cached)")
            strategies.append("            result = func(*args, **kwargs)")
            strategies.append("            redis_client.setex(cache_key, ttl, json.dumps(result))")
            strategies.append("            return result")
            strategies.append("        return wrapper")
            strategies.append("    return decorator")
            strategies.append("```\n")

        if cache_type in ["all", "cdn"]:
            strategies.append("# CDN Caching Strategy\n")
            strategies.append("## CloudFlare Cache Rules")
            strategies.append("- Static assets (images, CSS, JS): Cache for 1 year")
            strategies.append("- HTML: Cache for 1 hour with stale-while-revalidate")
            strategies.append("- API responses: Cache for 5 minutes with Cache-Control headers\n")
            strategies.append("```nginx")
            strategies.append("# Nginx cache config")
            strategies.append("location ~* \\.(jpg|jpeg|png|gif|ico|css|js)$ {")
            strategies.append("    expires 1y;")
            strategies.append("    add_header Cache-Control 'public, immutable';")
            strategies.append("}")
            strategies.append("```\n")

        if cache_type in ["all", "browser"]:
            strategies.append("# Browser Caching Headers\n")
            strategies.append("```python")
            strategies.append("# Flask example")
            strategies.append("@app.after_request")
            strategies.append("def add_cache_headers(response):")
            strategies.append("    if request.path.startswith('/static/'):")
            strategies.append("        response.cache_control.max_age = 31536000  # 1 year")
            strategies.append("        response.cache_control.public = True")
            strategies.append("    elif request.path.startswith('/api/'):")
            strategies.append("        response.cache_control.max_age = 300  # 5 minutes")
            strategies.append("    return response")
            strategies.append("```\n")

        strategies.append("# Cache Invalidation Strategy\n")
        strategies.append("1. **Time-based**: Set TTL based on data change frequency")
        strategies.append("2. **Event-based**: Invalidate on data update (Pub/Sub)")
        strategies.append("3. **Version-based**: Use cache keys with version numbers")
        strategies.append("4. **Stale-while-revalidate**: Serve stale content while updating")

        return strategies

    async def _analyze_complexity(self, payload: Dict[str, Any]) -> List[str]:
        """Analyze algorithm complexity (Big-O)."""
        code = payload.get("code", "")
        language = payload.get("language", "python")

        if not code.strip():
            return ["No code provided for complexity analysis."]

        issues: List[PerformanceIssue] = []
        lines = code.split('\n')

        # Detect nested loops
        loop_depth = 0
        loop_starts = []

        for i, line in enumerate(lines, 1):
            indent = len(line) - len(line.lstrip())

            # Detect loop start
            if re.search(r'(for|while)\s+', line):
                loop_depth += 1
                loop_starts.append((i, indent, loop_depth))
            # Detect loop end (dedent)
            elif loop_starts and indent <= loop_starts[-1][1]:
                if loop_starts:
                    loop_starts.pop()
                    loop_depth = max(0, loop_depth - 1)

            # Report nested loops
            if loop_depth >= 2:
                complexity = "O(n²)" if loop_depth == 2 else f"O(n^{loop_depth})"
                issues.append(PerformanceIssue(
                    severity="high" if loop_depth >= 3 else "medium",
                    category="complexity",
                    issue_type="nested_loops",
                    description=f"{loop_depth}-level nested loop detected: {complexity} complexity",
                    line_number=i,
                    recommendation=f"Consider optimization: 1) Use hash map for lookups (O(1)), "
                                 f"2) Flatten loops if possible, 3) Use library functions (NumPy, pandas)"
                ))

        # Detect inefficient search patterns
        for i, line in enumerate(lines, 1):
            # Linear search in list
            if re.search(r'if\s+.*\s+in\s+\[', line):
                issues.append(PerformanceIssue(
                    severity="medium",
                    category="complexity",
                    issue_type="linear_search",
                    description="Linear search in list (O(n))",
                    line_number=i,
                    recommendation="Use set for membership testing (O(1)). Example: if x in {a, b, c}: instead of if x in [a, b, c]:"
                ))

        return self._format_complexity_results(issues)

    def _format_profiling_results(self, issues: List[PerformanceIssue], guide: List[str]) -> List[str]:
        """Format profiling analysis results."""
        results = ["# Code Performance Analysis\n"]

        if issues:
            results.append(f"**Issues Found**: {len(issues)}\n")
            for issue in issues:
                emoji = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵"}[issue.severity]
                results.append(f"\n## {emoji} {issue.issue_type.upper()}")
                if issue.line_number:
                    results.append(f"**Line**: {issue.line_number}")
                results.append(f"**Description**: {issue.description}")
                results.append(f"**Recommendation**: {issue.recommendation}\n")
        else:
            results.append("✅ No obvious performance anti-patterns detected.\n")

        results.extend(guide)
        return results

    def _format_web_vitals_results(self, issues: List[PerformanceIssue], metrics: Dict) -> List[str]:
        """Format Core Web Vitals analysis results."""
        results = ["# Core Web Vitals Analysis\n"]

        # Summary
        results.append("## Metrics Summary\n")
        for metric, value in metrics.items():
            if value:
                unit = "ms" if metric != "CLS" else "score"
                threshold = self.WEB_VITALS_THRESHOLDS.get(metric, {})
                status = "✅ Good" if value <= threshold.get("good", 0) else (
                    "🟡 Needs Improvement" if value <= threshold.get("needs_improvement", 0) else "🔴 Poor"
                )
                results.append(f"- **{metric}**: {value}{unit} {status}")

        results.append("\n## Issues Detected\n")
        if issues:
            for issue in issues:
                emoji = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵"}[issue.severity]
                results.append(f"\n### {emoji} {issue.issue_type.upper()}")
                results.append(f"**Metric**: {issue.metric_value}{issue.metric_unit}")
                results.append(f"**Description**: {issue.description}")
                results.append(f"**Recommendation**: {issue.recommendation}\n")
        else:
            results.append("✅ All Core Web Vitals are in good range!")

        return results

    def _format_bundle_results(self, issues: List[PerformanceIssue], total_size: int, guide: List[str]) -> List[str]:
        """Format bundle optimization results."""
        results = ["# Bundle Optimization Analysis\n"]
        results.append(f"**Total Bundle Size**: {total_size // 1024}KB\n")

        if issues:
            results.append(f"**Issues Found**: {len(issues)}\n")
            for issue in issues:
                emoji = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵"}[issue.severity]
                results.append(f"\n## {emoji} {issue.issue_type.upper()}")
                results.append(f"**Size**: {issue.metric_value}{issue.metric_unit}")
                results.append(f"**Description**: {issue.description}")
                results.append(f"**Recommendation**: {issue.recommendation}\n")
        else:
            results.append("✅ Bundle size is within acceptable limits.\n")

        results.extend(guide)
        return results

    def _format_complexity_results(self, issues: List[PerformanceIssue]) -> List[str]:
        """Format algorithm complexity analysis results."""
        if not issues:
            return ["✅ No complexity issues detected. Code appears to use efficient algorithms."]

        results = ["# Algorithm Complexity Analysis\n"]
        results.append(f"**Issues Found**: {len(issues)}\n")

        for issue in issues:
            emoji = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵"}[issue.severity]
            results.append(f"\n## {emoji} {issue.issue_type.upper()}")
            results.append(f"**Line**: {issue.line_number}")
            results.append(f"**Description**: {issue.description}")
            results.append(f"**Recommendation**: {issue.recommendation}\n")

        return results
