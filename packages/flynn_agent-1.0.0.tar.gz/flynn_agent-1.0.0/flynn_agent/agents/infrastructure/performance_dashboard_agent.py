"""Performance dashboard agent stub."""

from __future__ import annotations

from typing import Any, Dict

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class PerformanceDashboardAgent(BaseAgent):
    """Stub for real‑time monitoring with anomaly detection."""

    name = "performance-dashboard-agent"
    description = "Performance dashboard (stub)."
    capabilities = {Capabilities.PERFORMANCE}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> str:
        return "Performance dashboard not implemented in v1."