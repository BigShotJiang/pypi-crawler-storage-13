"""Migration agent stub."""

from __future__ import annotations

from typing import Any, Dict

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class MigrationAgent(BaseAgent):
    """Stub for framework and language migrations."""

    name = "migration-agent"
    description = "Migration tasks (stub)."
    capabilities = {Capabilities.ANALYSIS}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> str:
        return "Migration tasks not implemented in v1."