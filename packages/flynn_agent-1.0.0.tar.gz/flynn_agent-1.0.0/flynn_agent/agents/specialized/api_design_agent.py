"""API design agent stub."""

from __future__ import annotations

from typing import Any, Dict

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class APIDesignAgent(BaseAgent):
    """Stub for REST/GraphQL API design."""

    name = "api-design-agent"
    description = "API design tasks (stub)."
    capabilities = {Capabilities.ANALYSIS}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> str:
        return "API design tasks not implemented in v1."