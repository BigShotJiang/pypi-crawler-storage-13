"""Localization agent stub."""

from __future__ import annotations

from typing import Any, Dict

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class LocalizationAgent(BaseAgent):
    """Stub for internationalisation and localisation."""

    name = "localization-agent"
    description = "Localization tasks (stub)."
    capabilities = {Capabilities.ANALYSIS}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> str:
        return "Localization tasks not implemented in v1."