"""Testing agent.

Generates a simple pytest test stub for given source code. The agent
extracts function names and builds a skeleton test file with placeholder
assertions. It also suggests test strategies based on the number of
functions detected.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class TestingAgent(BaseAgent):
    """Generates comprehensive test strategies and test code."""

    name = "testing-agent"
    description = "Create pytest test stubs for provided functions."
    capabilities = {Capabilities.TESTING}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> str:
        code: str = spec.payload.get("code", "")
        function_names = re.findall(r"def\s+([a-zA-Z_][a-zA-Z0-9_]*)", code)
        if not function_names:
            return "# No functions found to test."
        lines: List[str] = ["import pytest", "", ""]
        for fn in function_names:
            lines.append(f"def test_{fn}():")
            lines.append(f"    # TODO: add meaningful assertions for {fn}")
            lines.append("    assert False  # placeholder")
            lines.append("")
        return "\n".join(lines)