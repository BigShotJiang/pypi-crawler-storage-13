"""Implementation planning agent stub."""

from __future__ import annotations

from typing import Any, Dict

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class ImplementationPlanningAgent(BaseAgent):
    """Stub for planning and execution strategy."""

    name = "implementation-planning-agent"
    description = "Plan implementation strategy (stub)."
    capabilities = {Capabilities.ANALYSIS}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> str:
        return "Implementation planning not implemented in v1."