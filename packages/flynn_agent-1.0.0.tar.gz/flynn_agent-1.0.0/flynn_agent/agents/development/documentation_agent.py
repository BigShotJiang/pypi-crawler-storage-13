"""Documentation agent.

Generates technical documentation for given code or high level
description. In v1 it returns a formatted Markdown section summarising
the inputs, outputs and purpose of the code.
"""

from __future__ import annotations

from typing import Any, Dict

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class DocumentationAgent(BaseAgent):
    """Generates technical documentation."""

    name = "documentation-agent"
    description = "Produce Markdown documentation for code."
    capabilities = {Capabilities.DOCS}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> str:
        description = spec.payload.get("description", "")
        code = spec.payload.get("code", "")
        doc = ["### Documentation", ""]
        if description:
            doc.append(f"**Description**: {description}")
        if code:
            doc.append("**Code Summary**:")
            doc.append("```python")
            doc.extend(code.strip().splitlines())
            doc.append("```")
        return "\n".join(doc)