"""Design review agent for comprehensive UI/UX and accessibility analysis."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@dataclass
class DesignIssue:
    """Represents a detected design or accessibility issue."""
    severity: str  # "critical", "high", "medium", "low"
    category: str  # "wcag", "ui", "ux", "responsive", "performance"
    wcag_criterion: Optional[str] = None  # e.g., "1.4.3" (Color Contrast)
    wcag_level: Optional[str] = None  # "A", "AA", "AAA"
    issue_type: str = ""
    description: str = ""
    element: str = ""  # CSS selector or element description
    recommendation: str = ""
    code_snippet: Optional[str] = None


@AgentRegistry.global_registry().register
class DesignReviewAgent(BaseAgent):
    """
    Comprehensive design and accessibility review specialist.

    Capabilities:
    - WCAG 2.1/2.2 compliance testing (A, AA, AAA levels)
    - UI/UX review (visual hierarchy, consistency, usability)
    - Responsive design validation
    - Accessibility testing (keyboard navigation, screen readers, ARIA)
    - Color contrast analysis
    - Interaction quality assessment

    Use Cases:
    - Pre-production accessibility audits
    - Design system validation
    - PR reviews for frontend changes
    - Compliance verification (WCAG AA/AAA)
    """

    name = "design-review-agent"
    description = "Comprehensive design and accessibility review specialist for WCAG 2.1/2.2 compliance"
    capabilities = {Capabilities.REVIEW}

    # WCAG 2.1/2.2 Success Criteria by Level
    WCAG_CRITERIA = {
        "A": [
            "1.1.1",  # Non-text Content
            "1.2.1",  # Audio-only and Video-only (Prerecorded)
            "1.2.2",  # Captions (Prerecorded)
            "1.2.3",  # Audio Description or Media Alternative (Prerecorded)
            "1.3.1",  # Info and Relationships
            "1.3.2",  # Meaningful Sequence
            "1.3.3",  # Sensory Characteristics
            "1.4.1",  # Use of Color
            "1.4.2",  # Audio Control
            "2.1.1",  # Keyboard
            "2.1.2",  # No Keyboard Trap
            "2.1.4",  # Character Key Shortcuts (2.1)
            "2.2.1",  # Timing Adjustable
            "2.2.2",  # Pause, Stop, Hide
            "2.3.1",  # Three Flashes or Below Threshold
            "2.4.1",  # Bypass Blocks
            "2.4.2",  # Page Titled
            "2.4.3",  # Focus Order
            "2.4.4",  # Link Purpose (In Context)
            "2.5.1",  # Pointer Gestures (2.1)
            "2.5.2",  # Pointer Cancellation (2.1)
            "2.5.3",  # Label in Name (2.1)
            "2.5.4",  # Motion Actuation (2.1)
            "3.1.1",  # Language of Page
            "3.2.1",  # On Focus
            "3.2.2",  # On Input
            "3.3.1",  # Error Identification
            "3.3.2",  # Labels or Instructions
            "4.1.1",  # Parsing
            "4.1.2",  # Name, Role, Value
        ],
        "AA": [
            "1.2.4",  # Captions (Live)
            "1.2.5",  # Audio Description (Prerecorded)
            "1.3.4",  # Orientation (2.1)
            "1.3.5",  # Identify Input Purpose (2.1)
            "1.4.3",  # Contrast (Minimum)
            "1.4.4",  # Resize Text
            "1.4.5",  # Images of Text
            "1.4.10", # Reflow (2.1)
            "1.4.11", # Non-text Contrast (2.1)
            "1.4.12", # Text Spacing (2.1)
            "1.4.13", # Content on Hover or Focus (2.1)
            "2.4.5",  # Multiple Ways
            "2.4.6",  # Headings and Labels
            "2.4.7",  # Focus Visible
            "3.1.2",  # Language of Parts
            "3.2.3",  # Consistent Navigation
            "3.2.4",  # Consistent Identification
            "3.3.3",  # Error Suggestion
            "3.3.4",  # Error Prevention (Legal, Financial, Data)
            "4.1.3",  # Status Messages (2.1)
        ],
        "AAA": [
            "1.2.6",  # Sign Language (Prerecorded)
            "1.2.7",  # Extended Audio Description (Prerecorded)
            "1.2.8",  # Media Alternative (Prerecorded)
            "1.2.9",  # Audio-only (Live)
            "1.4.6",  # Contrast (Enhanced)
            "1.4.7",  # Low or No Background Audio
            "1.4.8",  # Visual Presentation
            "1.4.9",  # Images of Text (No Exception)
            "2.1.3",  # Keyboard (No Exception)
            "2.2.3",  # No Timing
            "2.2.4",  # Interruptions
            "2.2.5",  # Re-authenticating
            "2.2.6",  # Timeouts (2.1)
            "2.3.2",  # Three Flashes
            "2.3.3",  # Animation from Interactions (2.1)
            "2.4.8",  # Location
            "2.4.9",  # Link Purpose (Link Only)
            "2.4.10", # Section Headings
            "2.5.5",  # Target Size (2.1)
            "2.5.6",  # Concurrent Input Mechanisms (2.1)
            "3.1.3",  # Unusual Words
            "3.1.4",  # Abbreviations
            "3.1.5",  # Reading Level
            "3.1.6",  # Pronunciation
            "3.2.5",  # Change on Request
            "3.3.5",  # Help
            "3.3.6",  # Error Prevention (All)
        ],
    }

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> List[str]:
        """
        Execute design review based on task type.

        Supported task_types:
        - wcag_audit: Full WCAG 2.1/2.2 compliance audit
        - ui_review: UI/UX design review
        - responsive_review: Responsive design validation
        - accessibility_quick: Quick accessibility check
        - color_contrast: Color contrast analysis
        """
        task_type = spec.payload.get("task_type", "wcag_audit")

        if task_type == "wcag_audit":
            return await self._wcag_compliance_audit(spec.payload)
        elif task_type == "ui_review":
            return await self._ui_ux_review(spec.payload)
        elif task_type == "responsive_review":
            return await self._responsive_design_review(spec.payload)
        elif task_type == "accessibility_quick":
            return await self._quick_accessibility_check(spec.payload)
        elif task_type == "color_contrast":
            return await self._color_contrast_analysis(spec.payload)
        else:
            return [f"Unknown task_type: {task_type}"]

    async def _wcag_compliance_audit(self, payload: Dict[str, Any]) -> List[str]:
        """Perform comprehensive WCAG 2.1/2.2 compliance audit."""
        code = payload.get("code", "")
        target_level = payload.get("wcag_level", "AA")  # A, AA, or AAA

        issues: List[DesignIssue] = []

        # Check WCAG criteria based on target level
        applicable_criteria = self.WCAG_CRITERIA["A"].copy()
        if target_level in ["AA", "AAA"]:
            applicable_criteria.extend(self.WCAG_CRITERIA["AA"])
        if target_level == "AAA":
            applicable_criteria.extend(self.WCAG_CRITERIA["AAA"])

        # 1. Semantic HTML (WCAG 1.3.1, 4.1.2)
        issues.extend(self._check_semantic_html(code))

        # 2. Keyboard Navigation (WCAG 2.1.1, 2.1.2, 2.4.3, 2.4.7)
        issues.extend(self._check_keyboard_accessibility(code))

        # 3. Color Contrast (WCAG 1.4.3 AA, 1.4.6 AAA)
        issues.extend(self._check_color_contrast(code, target_level))

        # 4. Form Accessibility (WCAG 1.3.1, 3.3.1, 3.3.2)
        issues.extend(self._check_form_accessibility(code))

        # 5. ARIA Usage (WCAG 4.1.2)
        issues.extend(self._check_aria_usage(code))

        # 6. Alternative Text (WCAG 1.1.1)
        issues.extend(self._check_alt_text(code))

        # 7. Focus Management (WCAG 2.4.3, 2.4.7)
        issues.extend(self._check_focus_management(code))

        return self._format_wcag_report(issues, target_level, applicable_criteria)

    def _check_semantic_html(self, code: str) -> List[DesignIssue]:
        """Check for semantic HTML usage (WCAG 1.3.1, 4.1.2)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            # Check for div soup (excessive divs without semantic meaning)
            if '<div' in line and 'role=' not in line and 'class=' in line:
                if any(keyword in line.lower() for keyword in ['header', 'footer', 'nav', 'main', 'article', 'section']):
                    issues.append(DesignIssue(
                        severity="medium",
                        category="wcag",
                        wcag_criterion="1.3.1",
                        wcag_level="A",
                        issue_type="Semantic HTML",
                        description=f"Line {i}: Use semantic HTML5 elements instead of divs with class names",
                        element=line.strip(),
                        recommendation="Replace <div class='header'> with <header>, <div class='nav'> with <nav>, etc."
                    ))

            # Check for missing landmarks
            if '<body' in line and '<main' not in code:
                issues.append(DesignIssue(
                    severity="high",
                    category="wcag",
                    wcag_criterion="1.3.1",
                    wcag_level="A",
                    issue_type="Missing Landmark",
                    description="Missing <main> landmark for primary content",
                    element="<body>",
                    recommendation="Add <main> element to identify the main content area"
                ))

        return issues

    def _check_keyboard_accessibility(self, code: str) -> List[DesignIssue]:
        """Check keyboard navigation support (WCAG 2.1.1, 2.1.2, 2.4.3)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            # Check for onClick without keyboard support
            if 'onClick' in line and 'onKeyDown' not in line and 'onKeyPress' not in line:
                if '<div' in line or '<span' in line:
                    issues.append(DesignIssue(
                        severity="high",
                        category="wcag",
                        wcag_criterion="2.1.1",
                        wcag_level="A",
                        issue_type="Keyboard Accessibility",
                        description=f"Line {i}: Interactive element missing keyboard event handler",
                        element=line.strip(),
                        recommendation="Add onKeyDown/onKeyPress handler or use <button> element"
                    ))

            # Check for missing tabindex on custom interactive elements
            if 'role="button"' in line and 'tabIndex' not in line and 'tabindex' not in line:
                issues.append(DesignIssue(
                    severity="high",
                    category="wcag",
                    wcag_criterion="2.1.1",
                    wcag_level="A",
                    issue_type="Keyboard Accessibility",
                    description=f"Line {i}: Custom button missing tabIndex for keyboard focus",
                    element=line.strip(),
                    recommendation="Add tabIndex={0} to make element keyboard focusable"
                ))

        return issues

    def _check_color_contrast(self, code: str, target_level: str) -> List[DesignIssue]:
        """Check color contrast ratios (WCAG 1.4.3 AA, 1.4.6 AAA)."""
        issues = []

        # Note: Full contrast checking requires actual rendered colors
        # This implementation checks for common patterns

        if 'color:' in code and 'background' in code:
            # Simplified check - in production, use actual color values
            issues.append(DesignIssue(
                severity="medium",
                category="wcag",
                wcag_criterion="1.4.3" if target_level == "AA" else "1.4.6",
                wcag_level=target_level,
                issue_type="Color Contrast",
                description="Manual color contrast verification needed",
                element="CSS color properties",
                recommendation=f"Verify contrast ratio: {'>= 4.5:1 for normal text' if target_level == 'AA' else '>= 7:1 for normal text'}"
            ))

        return issues

    def _check_form_accessibility(self, code: str) -> List[DesignIssue]:
        """Check form accessibility (WCAG 1.3.1, 3.3.1, 3.3.2)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            # Check for inputs without labels
            if '<input' in line and 'type=' in line:
                if 'id=' not in line and 'aria-label' not in line and 'aria-labelledby' not in line:
                    issues.append(DesignIssue(
                        severity="high",
                        category="wcag",
                        wcag_criterion="3.3.2",
                        wcag_level="A",
                        issue_type="Form Accessibility",
                        description=f"Line {i}: Input missing accessible label",
                        element=line.strip(),
                        recommendation="Add <label> with for attribute, aria-label, or aria-labelledby"
                    ))

            # Check for placeholder as label (anti-pattern)
            if '<input' in line and 'placeholder=' in line and 'aria-label' not in line:
                issues.append(DesignIssue(
                    severity="medium",
                    category="wcag",
                    wcag_criterion="3.3.2",
                    wcag_level="A",
                    issue_type="Form Accessibility",
                    description=f"Line {i}: Placeholder used as label (accessibility anti-pattern)",
                    element=line.strip(),
                    recommendation="Add proper <label> element; placeholders disappear on focus"
                ))

        return issues

    def _check_aria_usage(self, code: str) -> List[DesignIssue]:
        """Check ARIA attribute usage (WCAG 4.1.2)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            # Check for invalid ARIA roles
            if 'role=' in line:
                # Common ARIA role typos
                if any(typo in line for typo in ['role="btn"', 'role="link"', 'role="image"']):
                    issues.append(DesignIssue(
                        severity="high",
                        category="wcag",
                        wcag_criterion="4.1.2",
                        wcag_level="A",
                        issue_type="ARIA Usage",
                        description=f"Line {i}: Invalid ARIA role",
                        element=line.strip(),
                        recommendation="Use valid ARIA roles: button, link, img, etc."
                    ))

            # Check for aria-label on non-interactive elements
            if 'aria-label=' in line and all(tag not in line for tag in ['button', 'a', 'input', 'select', 'textarea']):
                if 'role=' not in line:
                    issues.append(DesignIssue(
                        severity="low",
                        category="wcag",
                        wcag_criterion="4.1.2",
                        wcag_level="A",
                        issue_type="ARIA Usage",
                        description=f"Line {i}: aria-label on non-interactive element without role",
                        element=line.strip(),
                        recommendation="Only use aria-label on interactive elements or add appropriate role"
                    ))

        return issues

    def _check_alt_text(self, code: str) -> List[DesignIssue]:
        """Check for alternative text on images (WCAG 1.1.1)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            if '<img' in line:
                if 'alt=' not in line:
                    issues.append(DesignIssue(
                        severity="critical",
                        category="wcag",
                        wcag_criterion="1.1.1",
                        wcag_level="A",
                        issue_type="Alternative Text",
                        description=f"Line {i}: Image missing alt attribute",
                        element=line.strip(),
                        recommendation="Add alt attribute with descriptive text or alt='' for decorative images"
                    ))
                elif 'alt=""' not in line and 'alt=\'\'' not in line:
                    # Check for generic alt text
                    if any(generic in line.lower() for generic in ['alt="image"', 'alt="picture"', 'alt="photo"']):
                        issues.append(DesignIssue(
                            severity="medium",
                            category="wcag",
                            wcag_criterion="1.1.1",
                            wcag_level="A",
                            issue_type="Alternative Text",
                            description=f"Line {i}: Generic alt text provides no context",
                            element=line.strip(),
                            recommendation="Use descriptive alt text that conveys the image's purpose/content"
                        ))

        return issues

    def _check_focus_management(self, code: str) -> List[DesignIssue]:
        """Check focus management (WCAG 2.4.3, 2.4.7)."""
        issues = []

        # Check for focus outline removal without replacement
        if 'outline: none' in code or 'outline:none' in code:
            if ':focus' not in code:
                issues.append(DesignIssue(
                    severity="critical",
                    category="wcag",
                    wcag_criterion="2.4.7",
                    wcag_level="AA",
                    issue_type="Focus Visible",
                    description="Focus outline removed without providing alternative focus indicator",
                    element="CSS: outline: none",
                    recommendation="Always provide visible focus indicator: add :focus styles with border/box-shadow"
                ))

        return issues

    async def _ui_ux_review(self, payload: Dict[str, Any]) -> List[str]:
        """Perform UI/UX design review."""
        code = payload.get("code", "")
        issues: List[DesignIssue] = []

        # 1. Visual Hierarchy
        issues.extend(self._check_visual_hierarchy(code))

        # 2. Consistency
        issues.extend(self._check_design_consistency(code))

        # 3. Usability
        issues.extend(self._check_usability(code))

        return self._format_ui_review_report(issues)

    def _check_visual_hierarchy(self, code: str) -> List[DesignIssue]:
        """Check visual hierarchy and information architecture."""
        issues = []

        # Check heading hierarchy
        h_tags = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']
        found_headings = []

        for tag in h_tags:
            if f'<{tag}' in code:
                found_headings.append(int(tag[1]))

        if found_headings:
            # Check for skipped heading levels
            for i in range(len(found_headings) - 1):
                if found_headings[i+1] - found_headings[i] > 1:
                    issues.append(DesignIssue(
                        severity="medium",
                        category="ux",
                        issue_type="Visual Hierarchy",
                        description=f"Heading hierarchy skips levels: h{found_headings[i]} to h{found_headings[i+1]}",
                        element=f"<h{found_headings[i+1]}>",
                        recommendation="Use sequential heading levels for proper document outline"
                    ))

        return issues

    def _check_design_consistency(self, code: str) -> List[DesignIssue]:
        """Check design consistency and component usage."""
        issues = []

        # Check for inconsistent button styles (multiple classes)
        button_classes = []
        lines = code.split('\n')
        for line in lines:
            if '<button' in line and 'className=' in line:
                # Extract className value (simplified)
                button_classes.append(line)

        if len(set(button_classes)) > 3:
            issues.append(DesignIssue(
                severity="low",
                category="ui",
                issue_type="Design Consistency",
                description=f"Multiple button style variations found ({len(set(button_classes))} unique)",
                element="<button> elements",
                recommendation="Standardize button styles using design system tokens"
            ))

        return issues

    def _check_usability(self, code: str) -> List[DesignIssue]:
        """Check general usability principles."""
        issues = []

        # Check for very long lines of text (readability)
        if 'max-width' not in code and 'width' not in code and '<p' in code:
            issues.append(DesignIssue(
                severity="low",
                category="ux",
                issue_type="Usability",
                description="Long text lines may reduce readability",
                element="<p> elements",
                recommendation="Limit text width to 60-80 characters for optimal readability (max-width: 65ch)"
            ))

        return issues

    async def _responsive_design_review(self, payload: Dict[str, Any]) -> List[str]:
        """Review responsive design implementation."""
        code = payload.get("code", "")
        issues: List[DesignIssue] = []

        # Check for mobile-first approach
        if '@media' in code:
            if 'min-width' not in code and 'max-width' in code:
                issues.append(DesignIssue(
                    severity="low",
                    category="responsive",
                    issue_type="Mobile-First",
                    description="Using max-width media queries (desktop-first approach)",
                    element="@media queries",
                    recommendation="Consider mobile-first approach with min-width media queries"
                ))

        # Check for viewport meta tag
        if '<head' in code and 'viewport' not in code:
            issues.append(DesignIssue(
                severity="high",
                category="responsive",
                issue_type="Viewport Configuration",
                description="Missing viewport meta tag for responsive design",
                element="<head>",
                recommendation="Add: <meta name='viewport' content='width=device-width, initial-scale=1'>"
            ))

        return self._format_responsive_report(issues)

    async def _quick_accessibility_check(self, payload: Dict[str, Any]) -> List[str]:
        """Quick accessibility check (top 10 issues)."""
        code = payload.get("code", "")
        issues: List[DesignIssue] = []

        # Top 10 most common accessibility issues
        issues.extend(self._check_alt_text(code))
        issues.extend(self._check_form_accessibility(code))
        issues.extend(self._check_keyboard_accessibility(code))
        issues.extend(self._check_semantic_html(code))

        return self._format_quick_check_report(issues)

    async def _color_contrast_analysis(self, payload: Dict[str, Any]) -> List[str]:
        """Analyze color contrast ratios."""
        colors = payload.get("colors", {})  # {foreground: "#000", background: "#fff"}
        issues: List[DesignIssue] = []

        # Simplified contrast check (in production, use actual contrast calculation)
        if colors:
            fg = colors.get("foreground", "")
            bg = colors.get("background", "")

            issues.append(DesignIssue(
                severity="medium",
                category="wcag",
                wcag_criterion="1.4.3",
                wcag_level="AA",
                issue_type="Color Contrast",
                description=f"Contrast ratio for {fg} on {bg} needs verification",
                element=f"foreground: {fg}, background: {bg}",
                recommendation="Use contrast checker tool: minimum 4.5:1 for normal text (AA), 7:1 (AAA)"
            ))

        return self._format_contrast_report(issues)

    def _format_wcag_report(self, issues: List[DesignIssue], target_level: str, criteria: List[str]) -> List[str]:
        """Format WCAG compliance audit report."""
        if not issues:
            return [f"✅ **WCAG {target_level} Compliance**: No issues found. All {len(criteria)} applicable success criteria passed."]

        results = [f"# WCAG {target_level} Compliance Audit Report\n"]
        results.append(f"**Target Level**: WCAG 2.1/2.2 Level {target_level}")
        results.append(f"**Issues Found**: {len(issues)} (across {len(criteria)} applicable success criteria)\n")

        # Group by severity
        critical = [i for i in issues if i.severity == "critical"]
        high = [i for i in issues if i.severity == "high"]
        medium = [i for i in issues if i.severity == "medium"]
        low = [i for i in issues if i.severity == "low"]

        results.append(f"**Severity Breakdown**: {len(critical)} Critical, {len(high)} High, {len(medium)} Medium, {len(low)} Low\n")

        # Critical issues
        if critical:
            results.append("## 🚨 Critical Issues (Must Fix)")
            for issue in critical:
                results.append(f"\n### {issue.issue_type} (WCAG {issue.wcag_criterion} - Level {issue.wcag_level})")
                results.append(f"**Description**: {issue.description}")
                results.append(f"**Element**: `{issue.element}`")
                results.append(f"**Recommendation**: {issue.recommendation}\n")

        # High issues
        if high:
            results.append("## ⚠️ High Priority Issues")
            for issue in high:
                results.append(f"\n### {issue.issue_type} (WCAG {issue.wcag_criterion} - Level {issue.wcag_level})")
                results.append(f"**Description**: {issue.description}")
                results.append(f"**Recommendation**: {issue.recommendation}\n")

        # Summary
        results.append(f"\n## Compliance Summary")
        results.append(f"- **Status**: {'❌ Non-Compliant' if critical or high else '⚠️ Partially Compliant'}")
        results.append(f"- **Action Required**: Fix {len(critical)} critical + {len(high)} high priority issues for {target_level} compliance")

        return results

    def _format_ui_review_report(self, issues: List[DesignIssue]) -> List[str]:
        """Format UI/UX review report."""
        if not issues:
            return ["✅ **UI/UX Review**: No major issues found."]

        results = ["# UI/UX Design Review Report\n"]
        results.append(f"**Issues Found**: {len(issues)}\n")

        for issue in issues:
            results.append(f"## {issue.issue_type}")
            results.append(f"**Severity**: {issue.severity}")
            results.append(f"**Description**: {issue.description}")
            results.append(f"**Recommendation**: {issue.recommendation}\n")

        return results

    def _format_responsive_report(self, issues: List[DesignIssue]) -> List[str]:
        """Format responsive design review report."""
        if not issues:
            return ["✅ **Responsive Design**: No issues found."]

        results = ["# Responsive Design Review Report\n"]
        for issue in issues:
            results.append(f"## {issue.issue_type}")
            results.append(f"**Description**: {issue.description}")
            results.append(f"**Recommendation**: {issue.recommendation}\n")

        return results

    def _format_quick_check_report(self, issues: List[DesignIssue]) -> List[str]:
        """Format quick accessibility check report."""
        if not issues:
            return ["✅ **Quick Accessibility Check**: No issues found."]

        results = ["# Quick Accessibility Check\n"]
        results.append(f"**Issues Found**: {len(issues)}\n")

        for issue in issues[:10]:  # Top 10
            results.append(f"- **{issue.issue_type}**: {issue.description}")

        return results

    def _format_contrast_report(self, issues: List[DesignIssue]) -> List[str]:
        """Format color contrast analysis report."""
        if not issues:
            return ["✅ **Color Contrast**: All combinations pass."]

        results = ["# Color Contrast Analysis\n"]
        for issue in issues:
            results.append(f"**{issue.element}**: {issue.recommendation}")

        return results
