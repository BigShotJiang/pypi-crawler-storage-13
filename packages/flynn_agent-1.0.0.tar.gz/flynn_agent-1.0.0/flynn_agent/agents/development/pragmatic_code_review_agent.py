"""Pragmatic code review agent with 20+ review patterns.

This agent performs comprehensive code reviews covering:
- Code quality and maintainability
- Performance anti-patterns
- Error handling best practices
- SOLID principles
- Design patterns
- Testing coverage
- Documentation quality

Pattern Count: 24 patterns (exceeds 20+ target)
"""

from __future__ import annotations

import re
import ast
from typing import Any, Dict, List, Set, Tuple
from dataclasses import dataclass

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@dataclass
class ReviewIssue:
    """Represents a code review finding."""
    severity: str  # "blocker", "major", "minor", "suggestion"
    category: str  # Pattern category
    pattern_id: str  # Unique pattern identifier
    description: str
    line_number: int = 0
    recommendation: str = ""
    code_snippet: str = ""


@AgentRegistry.global_registry().register
class PragmaticCodeReviewAgent(BaseAgent):
    """Provides pragmatic code reviews with 20+ review patterns."""

    name = "pragmatic-code-review-agent"
    description = "Comprehensive code review with quality, performance, and design pattern analysis."
    capabilities = {Capabilities.REVIEW}

    # Review pattern categories
    PATTERN_CATEGORIES = {
        "quality": "Code Quality",
        "performance": "Performance",
        "error_handling": "Error Handling",
        "solid": "SOLID Principles",
        "testing": "Testing",
        "documentation": "Documentation",
        "security": "Security",
        "maintainability": "Maintainability"
    }

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> List[str]:
        """Run comprehensive code review."""
        code: str = spec.payload.get("code", "")
        language: str = spec.payload.get("language", "python")
        focus: List[str] = spec.payload.get("focus", [])

        if not code.strip():
            return ["No code provided for review."]

        issues: List[ReviewIssue] = []

        # Run all review patterns
        issues.extend(self._pattern_01_function_length(code))
        issues.extend(self._pattern_02_cognitive_complexity(code))
        issues.extend(self._pattern_03_magic_numbers(code))
        issues.extend(self._pattern_04_naming_conventions(code))
        issues.extend(self._pattern_05_dead_code(code))
        issues.extend(self._pattern_06_duplicate_code(code))
        issues.extend(self._pattern_07_nested_loops(code))
        issues.extend(self._pattern_08_exception_handling(code))
        issues.extend(self._pattern_09_bare_except(code))
        issues.extend(self._pattern_10_resource_leaks(code))
        issues.extend(self._pattern_11_mutable_defaults(code))
        issues.extend(self._pattern_12_global_state(code))
        issues.extend(self._pattern_13_srp_violation(code))
        issues.extend(self._pattern_14_ocp_violation(code))
        issues.extend(self._pattern_15_lsp_violation(code))
        issues.extend(self._pattern_16_god_class(code))
        issues.extend(self._pattern_17_missing_tests(code))
        issues.extend(self._pattern_18_test_quality(code))
        issues.extend(self._pattern_19_missing_docstrings(code))
        issues.extend(self._pattern_20_todo_comments(code))
        issues.extend(self._pattern_21_commented_code(code))
        issues.extend(self._pattern_22_type_hints(code))
        issues.extend(self._pattern_23_dependency_injection(code))
        issues.extend(self._pattern_24_immutability(code))

        # Format results
        return self._format_results(issues, focus)

    def _pattern_01_function_length(self, code: str) -> List[ReviewIssue]:
        """Pattern 01: Function/method length (max 50 lines recommended)."""
        issues = []
        lines = code.split('\n')

        in_function = False
        func_start = 0
        func_name = ""
        func_lines = 0

        for i, line in enumerate(lines, 1):
            if re.match(r'^\s*(def|async def)\s+(\w+)', line):
                # New function starts
                if in_function and func_lines > 50:
                    issues.append(ReviewIssue(
                        severity="major",
                        category="quality",
                        pattern_id="P01",
                        description=f"Function '{func_name}' is too long ({func_lines} lines)",
                        line_number=func_start,
                        recommendation="Break down into smaller functions (< 50 lines). Extract helper methods."
                    ))

                # Start tracking new function
                match = re.match(r'^\s*(def|async def)\s+(\w+)', line)
                func_name = match.group(2)
                func_start = i
                func_lines = 1
                in_function = True
            elif in_function:
                # Check if we're still in the function (indentation)
                if line.strip() and not line.startswith(' ') and not line.startswith('\t'):
                    in_function = False
                else:
                    func_lines += 1

        # Check last function
        if in_function and func_lines > 50:
            issues.append(ReviewIssue(
                severity="major",
                category="quality",
                pattern_id="P01",
                description=f"Function '{func_name}' is too long ({func_lines} lines)",
                line_number=func_start,
                recommendation="Break down into smaller functions (< 50 lines). Extract helper methods."
            ))

        return issues

    def _pattern_02_cognitive_complexity(self, code: str) -> List[ReviewIssue]:
        """Pattern 02: High cognitive complexity (nested conditions)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            # Count nesting level by indentation
            indent = len(line) - len(line.lstrip())
            spaces_per_level = 4

            if indent > 3 * spaces_per_level:  # More than 3 levels deep
                if any(keyword in line for keyword in ['if', 'for', 'while', 'try']):
                    issues.append(ReviewIssue(
                        severity="major",
                        category="quality",
                        pattern_id="P02",
                        description=f"High cognitive complexity at line {i} (nesting level {indent // spaces_per_level})",
                        line_number=i,
                        recommendation="Refactor to reduce nesting. Use early returns, extract methods, or apply guard clauses."
                    ))

        return issues

    def _pattern_03_magic_numbers(self, code: str) -> List[ReviewIssue]:
        """Pattern 03: Magic numbers (hardcoded numeric constants)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            # Find numeric literals (excluding 0, 1, -1)
            matches = re.findall(r'\b(\d{2,}|[2-9])\b', line)
            for match in matches:
                # Skip if it's in a comment or string
                if '#' in line and line.index('#') < line.index(match):
                    continue
                if any(c in line for c in ['"', "'"]):
                    continue

                issues.append(ReviewIssue(
                    severity="minor",
                    category="quality",
                    pattern_id="P03",
                    description=f"Magic number '{match}' at line {i}",
                    line_number=i,
                    recommendation=f"Extract to named constant: MAX_RETRIES = {match}"
                ))
                break  # Only report first per line

        return issues

    def _pattern_04_naming_conventions(self, code: str) -> List[ReviewIssue]:
        """Pattern 04: Naming convention violations (PEP 8)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            # Function names should be snake_case
            if re.search(r'def\s+([A-Z]\w+)', line):
                match = re.search(r'def\s+([A-Z]\w+)', line)
                issues.append(ReviewIssue(
                    severity="minor",
                    category="quality",
                    pattern_id="P04",
                    description=f"Function name '{match.group(1)}' violates PEP 8 (should be snake_case)",
                    line_number=i,
                    recommendation="Rename to snake_case (e.g., my_function)"
                ))

            # Class names should be PascalCase
            if re.search(r'class\s+([a-z_]\w+)', line):
                match = re.search(r'class\s+([a-z_]\w+)', line)
                issues.append(ReviewIssue(
                    severity="minor",
                    category="quality",
                    pattern_id="P04",
                    description=f"Class name '{match.group(1)}' violates PEP 8 (should be PascalCase)",
                    line_number=i,
                    recommendation="Rename to PascalCase (e.g., MyClass)"
                ))

        return issues

    def _pattern_05_dead_code(self, code: str) -> List[ReviewIssue]:
        """Pattern 05: Dead code (unreachable statements)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            # Code after return
            if 'return' in line and i < len(lines):
                next_line = lines[i].strip()
                if next_line and not next_line.startswith(('#', 'def', 'class', '}')):
                    # Check if it's not a nested function
                    if not re.match(r'^\s+(def|class)', lines[i]):
                        issues.append(ReviewIssue(
                            severity="major",
                            category="quality",
                            pattern_id="P05",
                            description=f"Dead code after return at line {i + 1}",
                            line_number=i + 1,
                            recommendation="Remove unreachable code"
                        ))

        return issues

    def _pattern_06_duplicate_code(self, code: str) -> List[ReviewIssue]:
        """Pattern 06: Duplicate code blocks (DRY violation)."""
        issues = []
        lines = code.split('\n')

        # Simple duplicate detection: find identical multi-line blocks (3+ lines)
        seen_blocks = {}
        for i in range(len(lines) - 2):
            block = '\n'.join(lines[i:i+3])
            if block.strip():
                if block in seen_blocks:
                    issues.append(ReviewIssue(
                        severity="major",
                        category="maintainability",
                        pattern_id="P06",
                        description=f"Duplicate code block at lines {i+1}-{i+3} (also at line {seen_blocks[block]+1})",
                        line_number=i+1,
                        recommendation="Extract to a shared function or method (DRY principle)"
                    ))
                else:
                    seen_blocks[block] = i

        return issues

    def _pattern_07_nested_loops(self, code: str) -> List[ReviewIssue]:
        """Pattern 07: Nested loops (performance concern)."""
        issues = []
        lines = code.split('\n')

        loop_stack = []
        for i, line in enumerate(lines, 1):
            indent = len(line) - len(line.lstrip())

            # Pop loops that are no longer nested (less indentation)
            loop_stack = [(lvl, start) for lvl, start in loop_stack if lvl < indent]

            if re.search(r'\b(for|while)\b', line):
                if len(loop_stack) >= 2:  # Already 2 levels deep
                    issues.append(ReviewIssue(
                        severity="major",
                        category="performance",
                        pattern_id="P07",
                        description=f"Triple-nested loop at line {i} (O(n³) complexity)",
                        line_number=i,
                        recommendation="Consider using data structures (dict, set) or algorithms to reduce complexity"
                    ))
                elif len(loop_stack) == 1:
                    issues.append(ReviewIssue(
                        severity="minor",
                        category="performance",
                        pattern_id="P07",
                        description=f"Nested loop at line {i} (O(n²) complexity)",
                        line_number=i,
                        recommendation="Review for optimization opportunities (e.g., hash maps, list comprehensions)"
                    ))

                loop_stack.append((indent, i))

        return issues

    def _pattern_08_exception_handling(self, code: str) -> List[ReviewIssue]:
        """Pattern 08: Poor exception handling (swallowing errors)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            if 'except' in line and 'pass' in lines[i] if i < len(lines) else False:
                issues.append(ReviewIssue(
                    severity="major",
                    category="error_handling",
                    pattern_id="P08",
                    description=f"Exception swallowed at line {i} (empty except block)",
                    line_number=i,
                    recommendation="Log the exception or re-raise if it cannot be handled"
                ))

        return issues

    def _pattern_09_bare_except(self, code: str) -> List[ReviewIssue]:
        """Pattern 09: Bare except clauses (catches everything)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            if re.search(r'except\s*:', line):
                issues.append(ReviewIssue(
                    severity="major",
                    category="error_handling",
                    pattern_id="P09",
                    description=f"Bare except clause at line {i}",
                    line_number=i,
                    recommendation="Catch specific exception types (e.g., except ValueError:)"
                ))

        return issues

    def _pattern_10_resource_leaks(self, code: str) -> List[ReviewIssue]:
        """Pattern 10: Resource leaks (files/connections not closed)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            if re.search(r'\bopen\(', line) and 'with' not in line:
                issues.append(ReviewIssue(
                    severity="major",
                    category="error_handling",
                    pattern_id="P10",
                    description=f"File opened without context manager at line {i}",
                    line_number=i,
                    recommendation="Use 'with open(...) as f:' to ensure file is closed"
                ))

        return issues

    def _pattern_11_mutable_defaults(self, code: str) -> List[ReviewIssue]:
        """Pattern 11: Mutable default arguments (common Python pitfall)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            if re.search(r'def\s+\w+\([^)]*=\s*(\[\]|\{\})', line):
                issues.append(ReviewIssue(
                    severity="major",
                    category="quality",
                    pattern_id="P11",
                    description=f"Mutable default argument at line {i}",
                    line_number=i,
                    recommendation="Use None as default: def func(arg=None): arg = arg or []"
                ))

        return issues

    def _pattern_12_global_state(self, code: str) -> List[ReviewIssue]:
        """Pattern 12: Global state usage (testability issue)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            if re.search(r'\bglobal\s+\w+', line):
                issues.append(ReviewIssue(
                    severity="major",
                    category="maintainability",
                    pattern_id="P12",
                    description=f"Global variable usage at line {i}",
                    line_number=i,
                    recommendation="Pass as parameter or use dependency injection for better testability"
                ))

        return issues

    def _pattern_13_srp_violation(self, code: str) -> List[ReviewIssue]:
        """Pattern 13: Single Responsibility Principle violation."""
        issues = []
        lines = code.split('\n')

        # Detect classes with too many methods (> 10)
        class_methods = {}
        current_class = None

        for i, line in enumerate(lines, 1):
            if re.match(r'class\s+(\w+)', line):
                match = re.match(r'class\s+(\w+)', line)
                current_class = match.group(1)
                class_methods[current_class] = 0
            elif current_class and re.match(r'\s+def\s+(\w+)', line):
                class_methods[current_class] += 1

        for class_name, method_count in class_methods.items():
            if method_count > 10:
                issues.append(ReviewIssue(
                    severity="major",
                    category="solid",
                    pattern_id="P13",
                    description=f"Class '{class_name}' has {method_count} methods (SRP violation)",
                    line_number=1,
                    recommendation="Split into smaller classes, each with a single responsibility"
                ))

        return issues

    def _pattern_14_ocp_violation(self, code: str) -> List[ReviewIssue]:
        """Pattern 14: Open/Closed Principle violation (large if-else chains)."""
        issues = []
        lines = code.split('\n')

        consecutive_elifs = 0
        elif_start = 0

        for i, line in enumerate(lines, 1):
            if 'elif' in line:
                if consecutive_elifs == 0:
                    elif_start = i
                consecutive_elifs += 1
            elif consecutive_elifs > 0:
                if consecutive_elifs >= 3:
                    issues.append(ReviewIssue(
                        severity="major",
                        category="solid",
                        pattern_id="P14",
                        description=f"Large if-elif chain ({consecutive_elifs} branches) at line {elif_start}",
                        line_number=elif_start,
                        recommendation="Refactor to polymorphism or strategy pattern for extensibility"
                    ))
                consecutive_elifs = 0

        return issues

    def _pattern_15_lsp_violation(self, code: str) -> List[ReviewIssue]:
        """Pattern 15: Liskov Substitution Principle violation."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            # Detect NotImplementedError in base class methods
            if re.search(r'raise\s+NotImplementedError', line):
                issues.append(ReviewIssue(
                    severity="minor",
                    category="solid",
                    pattern_id="P15",
                    description=f"NotImplementedError at line {i} (potential LSP violation)",
                    line_number=i,
                    recommendation="Use abstract base classes (ABC) instead of raising NotImplementedError"
                ))

        return issues

    def _pattern_16_god_class(self, code: str) -> List[ReviewIssue]:
        """Pattern 16: God class (class with too many responsibilities)."""
        issues = []
        lines = code.split('\n')

        # Count lines per class
        class_lines = {}
        current_class = None
        class_start = 0
        line_count = 0

        for i, line in enumerate(lines, 1):
            if re.match(r'class\s+(\w+)', line):
                if current_class and line_count > 200:
                    issues.append(ReviewIssue(
                        severity="blocker",
                        category="maintainability",
                        pattern_id="P16",
                        description=f"God class '{current_class}' with {line_count} lines",
                        line_number=class_start,
                        recommendation="Decompose into smaller classes with focused responsibilities"
                    ))

                match = re.match(r'class\s+(\w+)', line)
                current_class = match.group(1)
                class_start = i
                line_count = 1
            elif current_class:
                if not line.startswith(' ') and not line.startswith('\t') and line.strip():
                    current_class = None
                else:
                    line_count += 1

        # Check last class
        if current_class and line_count > 200:
            issues.append(ReviewIssue(
                severity="blocker",
                category="maintainability",
                pattern_id="P16",
                description=f"God class '{current_class}' with {line_count} lines",
                line_number=class_start,
                recommendation="Decompose into smaller classes with focused responsibilities"
            ))

        return issues

    def _pattern_17_missing_tests(self, code: str) -> List[ReviewIssue]:
        """Pattern 17: Missing test files."""
        issues = []

        if 'def test_' not in code and 'class Test' not in code:
            if 'def ' in code and 'import unittest' not in code and 'import pytest' not in code:
                issues.append(ReviewIssue(
                    severity="major",
                    category="testing",
                    pattern_id="P17",
                    description="No tests detected for this code",
                    line_number=1,
                    recommendation="Add unit tests (pytest or unittest) with >80% coverage"
                ))

        return issues

    def _pattern_18_test_quality(self, code: str) -> List[ReviewIssue]:
        """Pattern 18: Test quality issues (no assertions, etc.)."""
        issues = []
        lines = code.split('\n')

        if 'def test_' in code:
            for i, line in enumerate(lines, 1):
                if re.match(r'\s*def test_', line):
                    # Check if test has assertions (next 20 lines)
                    test_block = '\n'.join(lines[i:min(i+20, len(lines))])
                    if not re.search(r'\bassert\b|self\.assert', test_block):
                        match = re.match(r'\s*def (test_\w+)', line)
                        issues.append(ReviewIssue(
                            severity="major",
                            category="testing",
                            pattern_id="P18",
                            description=f"Test '{match.group(1)}' has no assertions at line {i}",
                            line_number=i,
                            recommendation="Add assertions to verify expected behavior"
                        ))

        return issues

    def _pattern_19_missing_docstrings(self, code: str) -> List[ReviewIssue]:
        """Pattern 19: Missing docstrings (functions, classes)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            if re.match(r'(class|def)\s+\w+', line):
                # Check if next line has docstring
                if i < len(lines):
                    next_line = lines[i].strip()
                    if not next_line.startswith('"""') and not next_line.startswith("'''"):
                        match = re.match(r'(class|def)\s+(\w+)', line)
                        issues.append(ReviewIssue(
                            severity="minor",
                            category="documentation",
                            pattern_id="P19",
                            description=f"Missing docstring for {match.group(1)} '{match.group(2)}' at line {i}",
                            line_number=i,
                            recommendation="Add docstring explaining purpose, parameters, and return value"
                        ))

        return issues

    def _pattern_20_todo_comments(self, code: str) -> List[ReviewIssue]:
        """Pattern 20: TODO comments (unfinished work)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            if re.search(r'#\s*(TODO|FIXME|HACK)', line, re.IGNORECASE):
                issues.append(ReviewIssue(
                    severity="minor",
                    category="maintainability",
                    pattern_id="P20",
                    description=f"TODO comment at line {i}",
                    line_number=i,
                    recommendation="Create a task/issue or implement the missing functionality"
                ))

        return issues

    def _pattern_21_commented_code(self, code: str) -> List[ReviewIssue]:
        """Pattern 21: Commented-out code (should be removed)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith('#') and re.search(r'(def|class|import|return|if|for)', stripped):
                issues.append(ReviewIssue(
                    severity="minor",
                    category="maintainability",
                    pattern_id="P21",
                    description=f"Commented-out code at line {i}",
                    line_number=i,
                    recommendation="Remove commented code (use version control for history)"
                ))

        return issues

    def _pattern_22_type_hints(self, code: str) -> List[ReviewIssue]:
        """Pattern 22: Missing type hints (Python 3.5+)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            if re.match(r'\s*def\s+\w+\([^)]*\)', line):
                # Check for type hints in function signature
                if '->' not in line and ':' not in line:
                    match = re.match(r'\s*def\s+(\w+)', line)
                    issues.append(ReviewIssue(
                        severity="suggestion",
                        category="quality",
                        pattern_id="P22",
                        description=f"Missing type hints for function '{match.group(1)}' at line {i}",
                        line_number=i,
                        recommendation="Add type hints: def func(arg: int) -> str:"
                    ))

        return issues

    def _pattern_23_dependency_injection(self, code: str) -> List[ReviewIssue]:
        """Pattern 23: Missing dependency injection (tight coupling)."""
        issues = []
        lines = code.split('\n')

        for i, line in enumerate(lines, 1):
            # Detect instantiation inside methods
            if re.search(r'def\s+\w+.*:\s*\w+\s*=\s*\w+\(', line):
                issues.append(ReviewIssue(
                    severity="minor",
                    category="solid",
                    pattern_id="P23",
                    description=f"Potential tight coupling at line {i} (instantiation in method)",
                    line_number=i,
                    recommendation="Consider dependency injection for better testability"
                ))

        return issues

    def _pattern_24_immutability(self, code: str) -> List[ReviewIssue]:
        """Pattern 24: Mutable class attributes (shared state bug)."""
        issues = []
        lines = code.split('\n')

        in_class = False
        for i, line in enumerate(lines, 1):
            if re.match(r'class\s+\w+', line):
                in_class = True
            elif in_class and re.match(r'\s{4}\w+\s*=\s*(\[\]|\{\})', line):
                issues.append(ReviewIssue(
                    severity="major",
                    category="quality",
                    pattern_id="P24",
                    description=f"Mutable class attribute at line {i} (shared state)",
                    line_number=i,
                    recommendation="Move to __init__ or use immutable defaults (tuple, frozenset)"
                ))

        return issues

    def _format_results(self, issues: List[ReviewIssue], focus: List[str]) -> List[str]:
        """Format review issues into readable report."""
        if not issues:
            return ["✅ Code looks clean and well structured. No issues found."]

        # Filter by focus if specified
        if focus:
            issues = [i for i in issues if any(f.lower() in i.category.lower() for f in focus)]

        # Sort by severity: blocker > major > minor > suggestion
        severity_order = {"blocker": 0, "major": 1, "minor": 2, "suggestion": 3}
        issues.sort(key=lambda x: (severity_order[x.severity], x.line_number))

        # Group by severity
        grouped = {}
        for issue in issues:
            grouped.setdefault(issue.severity, []).append(issue)

        results = []
        results.append(f"📋 Code Review Results ({len(issues)} issues found)")
        results.append("")

        for severity in ["blocker", "major", "minor", "suggestion"]:
            if severity in grouped:
                emoji = {"blocker": "🚫", "major": "⚠️", "minor": "💡", "suggestion": "💭"}[severity]
                results.append(f"{emoji} {severity.upper()} ({len(grouped[severity])} issues):")
                results.append("")

                for issue in grouped[severity]:
                    results.append(f"  [{issue.pattern_id}] {self.PATTERN_CATEGORIES.get(issue.category, issue.category)}")
                    results.append(f"  Line {issue.line_number}: {issue.description}")
                    results.append(f"  💡 Fix: {issue.recommendation}")
                    results.append("")

        # Summary
        blocker_count = len(grouped.get("blocker", []))
        major_count = len(grouped.get("major", []))

        results.append("📊 Summary:")
        results.append(f"  Patterns Checked: 24 (quality, performance, SOLID, testing, documentation)")
        results.append(f"  Blocker Issues: {blocker_count}")
        results.append(f"  Major Issues: {major_count}")

        if blocker_count > 0:
            results.append("")
            results.append("🚫 BLOCKER: Address critical issues before merging!")

        return results
