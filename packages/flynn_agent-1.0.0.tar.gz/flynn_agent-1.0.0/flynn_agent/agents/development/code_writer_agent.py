"""Code writer agent.

The code writer agent generates clean, maintainable code based on a
high‑level description provided in the task's payload. For v1 the
implementation returns a simple Python function skeleton that echoes the
description in the docstring. More sophisticated logic such as unit
test generation and optimisation can be added in future versions.
"""

from __future__ import annotations

from typing import Any, Dict

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class CodeWriterAgent(BaseAgent):
    """Generates clean, maintainable source code."""

    name = "code-writer-agent"
    description = "Generate Python code from high‑level descriptions."
    capabilities = {Capabilities.CODE_GEN}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> str:
        description = spec.payload.get("description", "")
        function_name = spec.payload.get("function_name", "generated_function")
        # Create a simple function skeleton with a docstring
        code = (
            f"def {function_name}(*args, **kwargs):\n"
            f"    \"\"\"{description}\"\"\"\n"
            f"    # TODO: implement the function logic here\n"
            f"    raise NotImplementedError\n"
        )
        return code