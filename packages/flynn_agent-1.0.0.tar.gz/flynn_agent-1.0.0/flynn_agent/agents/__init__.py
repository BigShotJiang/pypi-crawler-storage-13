"""Agent implementations for the Flynn‑Agent framework.

This package contains concrete implementations of all agents defined in
the system architecture. Tier 1 agents provide full logic and are used
by the orchestrator in v1. Tier 2 agents act as thin stubs ready to be
extended in future versions. All agents register themselves with the
global registry when imported.

Agents are grouped by category:

* core – fundamental system services (orchestrator, context manager,
  query analyser, tool router, freshness validator);
* development – agents that assist in software development (code
  writer, code review, testing, security, documentation, design and
  implementation planning);
* infrastructure – DevOps, database, performance and caching agents;
* specialised – migration, localisation, API design;
* experimental – agents for learning, prediction and meta‑reasoning.

"""

# import modules to trigger registration side effects
from .core import (  # noqa:F401
    OrchestratorAgent,
    ContextManagerAgent,
    QueryAnalyzerAgent,
    ToolRouterAgent,
    FreshnessValidatorAgent,
)
from .development import (  # noqa:F401
    CodeWriterAgent,
    PragmaticCodeReviewAgent,
    TestingAgent,
    SecurityAgent,
    DocumentationAgent,
    DesignReviewAgent,
    ImplementationPlanningAgent,
)
from .infrastructure import (  # noqa:F401
    DevOpsAgent,
    DatabaseAgent,
    PerformanceAgent,
    ContextCacheManager,
    OptimizationEngineAgent,
    PerformanceDashboardAgent,
)
from .specialized import (  # noqa:F401
    MigrationAgent,
    LocalizationAgent,
    APIDesignAgent,
)
from .experimental import (  # noqa:F401
    LearningAgent,
    PredictiveAgent,
    MetaAgent,
)