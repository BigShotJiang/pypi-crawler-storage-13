"""Tool router agent.

The tool router determines which skills or MCP backends should be used
for a given task. It consults the MCPManager to load only the
capabilities needed. In this offline implementation, the router
returns a set of backend names based on the task's capabilities.
"""

from __future__ import annotations

from typing import Dict, Set

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...mcp.manager import MCPManager
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class ToolRouterAgent(BaseAgent):
    """Dynamic tool routing with context‑first policy."""

    name = "tool-router-agent"
    description = "Selects minimal set of MCP backends required for a task."
    capabilities = {Capabilities.ROUTING}

    def __init__(self) -> None:
        super().__init__()
        self.mcp = MCPManager()

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> Any:
        # determine required backends based on capabilities of target agent
        registry = AgentRegistry.global_registry()
        target_agent_cls = registry.get_agent_for_spec(spec)
        capabilities = getattr(target_agent_cls, "capabilities", set())
        backends: Set[str] = set()
        for cap in capabilities:
            # simple mapping: capability name -> backend name
            backends.add(cap.value)
        # load backends lazily
        for name in backends:
            self.mcp.load(name)
        return {
            "backends": list(backends),
            "details": {name: self.mcp.get_backend(name) for name in backends},
        }