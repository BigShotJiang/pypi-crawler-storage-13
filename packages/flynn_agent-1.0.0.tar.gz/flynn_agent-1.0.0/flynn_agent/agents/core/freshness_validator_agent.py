"""Freshness validator agent stub.

This agent checks whether documentation or tool descriptions in the
context are fresh. In v1 it always returns that the documentation is
fresh. A future implementation would validate timestamps and refresh
via skills.
"""

from __future__ import annotations

from typing import Dict

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class FreshnessValidatorAgent(BaseAgent):
    """Stub for documentation freshness validation."""

    name = "freshness-validator-agent"
    description = "Validates freshness of docs (stub)."
    capabilities = {Capabilities.DOCS}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Dict]) -> Dict[str, str]:
        # Always return that docs are fresh in v1
        return {"status": "fresh"}