"""Context manager agent implementation.

This agent provides access to a shared context store. It can read,
write and snapshot values based on the payload of the incoming
task. Supported operations:

* ``get``: return the value for a given key;
* ``set``: update the context with a key/value pair;
* ``snapshot``: return a snapshot of the entire context.

The context manager agent is registered with the global registry.
"""

from __future__ import annotations

from typing import Any, Dict

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...context import ContextStore
from ...base import BaseAgent


_GLOBAL_CONTEXT = ContextStore()


@AgentRegistry.global_registry().register
class ContextManagerAgent(BaseAgent):
    """Central knowledge repository and state management."""

    name = "context-manager-agent"
    description = "Manages shared context across tasks and agents."
    capabilities = {Capabilities.DOCS, Capabilities.ANALYSIS}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> Any:
        payload = spec.payload
        # handle get/set/snapshot commands
        if "get" in payload:
            key = payload["get"]
            return _GLOBAL_CONTEXT.get(key)
        elif "set" in payload:
            key, value = next(iter(payload["set"].items()))
            _GLOBAL_CONTEXT.set(key, value)
            return {key: value}
        elif payload.get("snapshot"):
            return _GLOBAL_CONTEXT.snapshot()
        else:
            return None