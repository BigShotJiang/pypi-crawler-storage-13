"""Query analyser agent.

The query analyser agent inspects the task specification and determines
which agent(s) are best suited to handle it. It returns a list of
candidate agent names and their rationales. The analysis is based on
simple keyword matching over the intent and goal fields.
"""

from __future__ import annotations

from typing import Dict, List

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class QueryAnalyzerAgent(BaseAgent):
    """Intelligent query analysis and tool recommendation."""

    name = "query-analyzer-agent"
    description = "Analyses tasks and recommends appropriate agents."
    capabilities = {Capabilities.ANALYSIS, Capabilities.ROUTING}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> Any:
        text = (spec.intent + " " + spec.goal).lower()
        recommendations: List[Dict[str, str]] = []
        registry = AgentRegistry.global_registry()
        # naive keyword mapping
        mappings = {
            "code": "code-writer-agent",
            "review": "pragmatic-code-review-agent",
            "test": "testing-agent",
            "security": "security-agent",
            "document": "documentation-agent",
        }
        for keyword, agent_name in mappings.items():
            if keyword in text and agent_name in registry._agents:
                recommendations.append(
                    {
                        "agent": agent_name,
                        "reason": f"keyword '{keyword}' present in intent/goal",
                    }
                )
        # default orchestrator recommendation
        if not recommendations and "multi" in text:
            recommendations.append(
                {
                    "agent": "orchestrator-agent",
                    "reason": "multi‑step task requires orchestration",
                }
            )
        return recommendations