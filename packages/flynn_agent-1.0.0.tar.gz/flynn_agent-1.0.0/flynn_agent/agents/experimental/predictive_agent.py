"""Predictive agent stub."""

from __future__ import annotations

from typing import Any, Dict

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class PredictiveAgent(BaseAgent):
    """Stub for complexity and effort prediction."""

    name = "predictive-agent"
    description = "Predictive analysis agent (stub)."
    capabilities = {Capabilities.META}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> str:
        return "Predictive agent not implemented in v1."