"""Learning agent stub."""

from __future__ import annotations

from typing import Any, Dict

from ...models import AgentResult, Capabilities, TaskSpec
from ...registry import AgentRegistry
from ...base import BaseAgent


@AgentRegistry.global_registry().register
class LearningAgent(BaseAgent):
    """Stub for adaptive learning and pattern recognition."""

    name = "learning-agent"
    description = "Learning agent (stub)."
    capabilities = {Capabilities.META}

    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> str:
        return "Learning agent not implemented in v1."