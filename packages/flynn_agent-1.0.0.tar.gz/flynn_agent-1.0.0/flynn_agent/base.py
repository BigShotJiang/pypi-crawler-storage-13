"""Base classes and shared logic for all agents.

This module defines the abstract :class:`BaseAgent` class that all other
agents in the system must derive from. It enforces a consistent
asynchronous execution template and provides hooks for preparing context,
entering deep reasoning mode, spawning subtasks and finalising results.

Agents implement their domain‑specific behaviour by overriding the
``_run`` method, and optionally ``_maybe_spawn_subtasks`` and
``_enter_ultrathink_mode`` if they support those features. The public
``execute`` coroutine orchestrates the overall lifecycle.
"""

from __future__ import annotations

import abc
import asyncio
from typing import Any, Dict, Optional, Set

from .models import AgentResult, Capabilities, TaskSpec


class BaseAgent(abc.ABC):
    """Abstract base class for all agents.

    Every agent must define a ``name``, ``description`` and a set of
    ``capabilities``. The main entry point is the :meth:`execute` coroutine
    which prepares the context, optionally enters ultrathink mode,
    executes the agent's core logic via :meth:`_run`, spawns any
    subtasks, and finalises the result.
    """

    #: Human readable name of the agent
    name: str = ""
    #: Textual description of the agent
    description: str = ""
    #: Set of declared capabilities
    capabilities: Set[Capabilities] = set()

    async def execute(self, spec: TaskSpec) -> AgentResult:
        """Entrypoint for executing a task with this agent.

        This method must not be overridden in subclasses. It coordinates
        context preparation, optional ultrathink handling, execution of
        domain logic, spawning of subtasks (if any) and finalisation.
        """
        # prepare context using context manager and cache (stubbed here)
        ctx: Dict[str, Any] = await self._prepare_context(spec)

        # optionally enter deep reasoning mode
        if spec.mode == "ultrathink":
            ctx = await self._enter_ultrathink_mode(spec, ctx)

        # run agent specific logic
        raw_output = await self._run(spec, ctx)

        # optionally spawn subtasks via orchestrator API (stubbed)
        sub_results = await self._maybe_spawn_subtasks(spec, ctx)

        # finalise and return result
        return await self._finalize(raw_output, sub_results, spec)

    async def _prepare_context(self, spec: TaskSpec) -> Dict[str, Any]:
        """Prepare the execution context for this agent.

        In a full implementation this method would consult a shared
        context manager and caching layer. If ``spec.require_fresh_docs``
        is true, a freshness validator would check documentation
        staleness and refresh it if necessary. For now we simply
        propagate the task's existing context.
        """
        # TODO: integrate with ContextManagerAgent and caching layer
        return spec.context.copy()

    async def _enter_ultrathink_mode(
        self, spec: TaskSpec, ctx: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Perform optional deep reasoning steps.

        Subclasses can override this to implement multi‑step planning,
        assumption validation and subagent proposals. The default
        implementation simply returns the context unchanged.
        """
        return ctx

    @abc.abstractmethod
    async def _run(self, spec: TaskSpec, ctx: Dict[str, Any]) -> Any:
        """Execute the core logic of the agent.

        This must be implemented by every concrete agent subclass. The
        method should be deterministic given the same inputs and should not
        perform any network I/O. It may raise exceptions to signal
        unrecoverable errors.
        """
        raise NotImplementedError

    async def _maybe_spawn_subtasks(
        self, spec: TaskSpec, ctx: Dict[str, Any]
    ) -> Dict[str, AgentResult]:
        """Optionally spawn subtasks to delegate parts of the work.

        By default agents do not spawn subtasks. Subclasses may override
        this to call out to the orchestrator's subtask API. The default
        implementation returns an empty mapping.
        """
        return {}

    async def _finalize(
        self,
        raw_output: Any,
        sub_results: Dict[str, AgentResult],
        spec: TaskSpec,
    ) -> AgentResult:
        """Finalise and construct an :class:`AgentResult`.

        This method combines the primary output with any subtask results
        and assembles the diagnostic information. Subclasses may override
        this to customise result construction but should call ``super``.
        """
        diagnostics = {
            "sub_results": {k: v.status_code for k, v in sub_results.items()},
        }
        result = AgentResult(
            agent=self.name,
            success=True,
            output=raw_output,
            diagnostics=diagnostics,
            status_code="OK",
        )
        return result