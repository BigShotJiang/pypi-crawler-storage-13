"""Caching utilities for Flynn‑Agent.

This module provides a simple multilevel LRU cache implementation. It
supports global, per‑agent and per‑task caches. Keys are derived from
(task_id, agent_name, payload) tuples. Values are arbitrary and live
until evicted by least‑recently‑used policy.

For now the cache is a minimal stub and does not enforce a size
limit. Future versions should implement true LRU eviction and optional
disk persistence.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, Tuple


class MultiLevelCache:
    """A hierarchical cache keyed by (task_id, agent_name, payload)."""

    def __init__(self) -> None:
        self._global: Dict[Tuple[str, str, str], Any] = {}
        self._per_agent: Dict[str, Dict[Tuple[str, str, str], Any]] = defaultdict(dict)
        self._per_task: Dict[str, Dict[Tuple[str, str, str], Any]] = defaultdict(dict)

    @staticmethod
    def _make_key(task_id: str, agent_name: str, payload: Dict[str, Any]) -> Tuple[str, str, str]:
        return (task_id, agent_name, str(sorted(payload.items())))

    def get(self, task_id: str, agent_name: str, payload: Dict[str, Any]) -> Any:
        key = self._make_key(task_id, agent_name, payload)
        # try per task
        if key in self._per_task.get(task_id, {}):
            return self._per_task[task_id][key]
        # try per agent
        if key in self._per_agent.get(agent_name, {}):
            return self._per_agent[agent_name][key]
        # try global
        return self._global.get(key)

    def set(self, task_id: str, agent_name: str, payload: Dict[str, Any], value: Any) -> None:
        key = self._make_key(task_id, agent_name, payload)
        self._global[key] = value
        self._per_agent[agent_name][key] = value
        self._per_task[task_id][key] = value