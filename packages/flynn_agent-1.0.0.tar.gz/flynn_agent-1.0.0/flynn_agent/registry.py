"""Dynamic agent registry for the Flynn‑Agent framework.

The registry maintains a mapping between agent names and their
constructors. It supports registration of new agents via a class
decorator and provides simple lookup utilities based on task
specifications. A global registry is available for convenience.
"""

from __future__ import annotations

import inspect
from typing import Dict, Optional, Type

from .models import Capabilities, TaskSpec


class AgentRegistry:
    """Registry of available agents.

    Agents register themselves using the :func:`register` decorator.
    The registry can then provide an agent class given a task
    specification. In this simplified implementation the mapping from
    task intent to agent is rule‑based: it looks for keywords in the
    intent or goal and selects an agent whose capabilities match.
    """

    def __init__(self) -> None:
        self._agents: Dict[str, Type] = {}

    def register(self, cls: Type) -> Type:
        """Register an agent class with the registry.

        This decorator adds the class to the internal mapping using its
        declared ``name`` attribute as the key.
        """
        if not hasattr(cls, "name") or not cls.name:
            raise ValueError(f"Cannot register agent {cls}: missing name")
        self._agents[cls.name] = cls
        return cls

    def get(self, name: str) -> Type:
        """Retrieve an agent class by name.

        Raises ``KeyError`` if the agent is not registered.
        """
        return self._agents[name]

    def get_agent_for_spec(self, spec: TaskSpec) -> Optional[Type]:
        """Select an agent class based on the task specification.

        The selection uses simple keyword matching over the intent and
        goal. If no specific agent is matched a fallback to the
        orchestrator is returned.
        """
        text = (spec.intent + " " + spec.goal).lower()
        # explicit keyword mappings
        # order matters: test before code to avoid matching 'code' in 'test code'
        mapping = [
            ("test", "testing-agent"),
            ("security", "security-agent"),
            ("review", "pragmatic-code-review-agent"),
            ("document", "documentation-agent"),
            ("docs", "documentation-agent"),
            ("generate", "code-writer-agent"),
            ("write", "code-writer-agent"),
            ("code", "code-writer-agent"),
        ]
        for keyword, agent_name in mapping:
            if keyword in text and agent_name in self._agents:
                return self._agents[agent_name]
        # default orchestrator for multi‑step or unknown tasks
        if "multi" in text:
            return self._agents.get("orchestrator-agent")
        # fallback to orchestrator by default
        return self._agents.get("orchestrator-agent")

    @classmethod
    def global_registry(cls) -> "AgentRegistry":
        """Return the global singleton registry.

        This registry is populated when agents are imported. Code should
        use this rather than instantiating new registries.
        """
        if not hasattr(cls, "_global"):
            # instantiate and populate
            cls._global = cls()
            # import agents to trigger registration
            try:
                import flynn_agent.agents  # noqa: F401
            except ImportError:
                pass
        return cls._global