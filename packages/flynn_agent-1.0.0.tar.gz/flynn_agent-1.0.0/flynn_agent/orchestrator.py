"""Asynchronous orchestrator for executing task graphs.

This module defines the :class:`Orchestrator` class responsible for
managing a workflow defined as a directed acyclic graph (DAG) of
:class:`TaskSpec` objects. The orchestrator resolves dependencies,
invokes agents via the registry, executes tasks in parallel when
possible and collects results. It also exposes a simple subtask API
used by agents to spawn child tasks.

The orchestrator does not perform any network I/O and operates entirely
in memory. It is designed to be deterministic given the same inputs.
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from typing import Dict, List, Optional

from .models import AgentResult, TaskSpec
from .registry import AgentRegistry


class Orchestrator:
    """Execute a DAG of tasks using registered agents.

    The orchestrator accepts a collection of :class:`TaskSpec` objects
    describing a workflow. Each task specifies its dependencies and the
    orchestrator ensures those tasks complete before the dependent task
    is executed. Tasks whose dependencies are satisfied may run in
    parallel via :func:`asyncio.gather`.

    When a task is executed the orchestrator looks up the appropriate
    agent by consulting the :class:`AgentRegistry` based on the task's
    intent and goal. The agent's ``execute`` coroutine is then invoked
    with the provided specification. Results are stored and propagated to
    dependent tasks via the ``context`` field of subsequent specs.
    """

    def __init__(self, registry: Optional[AgentRegistry] = None) -> None:
        self.registry = registry or AgentRegistry.global_registry()
        # store results keyed by task_id
        self._results: Dict[str, AgentResult] = {}
        # track tasks being executed to prevent duplication
        self._running: Dict[str, asyncio.Task] = {}

    async def run(self, tasks: List[TaskSpec]) -> Dict[str, AgentResult]:
        """Execute a workflow consisting of the given tasks.

        The tasks must form a DAG. Returns a mapping from task IDs to
        :class:`AgentResult` objects. Raises ``ValueError`` if a cycle is
        detected.
        """
        # build adjacency and indegree maps
        adj: Dict[str, List[str]] = defaultdict(list)
        indegree: Dict[str, int] = defaultdict(int)
        spec_by_id: Dict[str, TaskSpec] = {}

        for spec in tasks:
            spec_by_id[spec.task_id] = spec
            indegree.setdefault(spec.task_id, 0)
            for dep in spec.dependencies:
                adj[dep].append(spec.task_id)
                indegree[spec.task_id] += 1

        # queue of ready tasks (zero indegree)
        ready = [task_id for task_id, deg in indegree.items() if deg == 0]
        # track running coroutines for concurrency
        pending: set[asyncio.Task] = set()

        async def execute_task(task_id: str) -> None:
            spec = spec_by_id[task_id]
            # gather context from dependencies
            ctx = spec.context.copy()
            for dep_id in spec.dependencies:
                res = self._results[dep_id]
                # propagate output into context under key of dep ID
                ctx[dep_id] = res.output
            # choose agent
            agent_cls = self.registry.get_agent_for_spec(spec)
            agent = agent_cls()  # instantiate
            result = await agent.execute(spec)
            self._results[task_id] = result

            # update adjacency indegrees and possibly enqueue children
            for child_id in adj.get(task_id, []):
                indegree[child_id] -= 1
                if indegree[child_id] == 0:
                    ready.append(child_id)

        # use event loop to dispatch tasks as ready
        loop = asyncio.get_event_loop()
        while ready or pending:
            # schedule ready tasks
            while ready:
                task_id = ready.pop()
                task = loop.create_task(execute_task(task_id))
                pending.add(task)
            if not pending:
                break
            done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
            # ignore results here; tasks record their results internally
        return self._results

    # subtask API used by agents to spawn new tasks during execution
    async def spawn_subtasks(
        self, parent_spec: TaskSpec, subtasks: List[TaskSpec]
    ) -> Dict[str, AgentResult]:
        """Spawn subtasks from within an agent.

        This method ensures subtasks have correct parent/task depth and
        executes them with the orchestrator. It returns a mapping of
        subtask IDs to results. Subtasks must not introduce cycles.
        """
        # assign parent id and depth
        for sub in subtasks:
            sub.parent_task_id = parent_spec.task_id
            sub.depth = parent_spec.depth + 1
        results = await self.run(subtasks)
        return results