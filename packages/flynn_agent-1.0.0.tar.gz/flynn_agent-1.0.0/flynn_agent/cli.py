"""Command line interface for the Flynn‑Agent framework.

This module provides an entry point for running individual agents or
entire workflows from the command line. It uses the standard library
``argparse`` module for argument parsing and runs asynchronous
operations via ``asyncio.run``.
"""

from __future__ import annotations

import argparse
import asyncio
import json
from typing import Any, Dict, List

from .models import TaskSpec
from .registry import AgentRegistry
from .orchestrator import Orchestrator


def parse_task_spec(data: Dict[str, Any]) -> TaskSpec:
    """Create a :class:`TaskSpec` from a raw dictionary."""
    return TaskSpec(**data)


async def run_agent(name: str, task_json: str) -> None:
    registry = AgentRegistry.global_registry()
    agent_cls = registry.get(name)
    spec_dict = json.loads(task_json)
    spec = parse_task_spec(spec_dict)
    agent = agent_cls()
    result = await agent.execute(spec)
    print(json.dumps({"output": result.output, "diagnostics": result.diagnostics}, indent=2))


async def run_orchestrator(task_json: str) -> None:
    tasks_data = json.loads(task_json)
    tasks: List[TaskSpec] = []
    for item in tasks_data:
        tasks.append(parse_task_spec(item))
    orchestrator = Orchestrator()
    results = await orchestrator.run(tasks)
    out = {tid: {"output": res.output, "diagnostics": res.diagnostics} for tid, res in results.items()}
    print(json.dumps(out, indent=2))


def main(argv: List[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Flynn‑Agent command line interface")
    subparsers = parser.add_subparsers(dest="command", required=True)

    parser_agent = subparsers.add_parser("run-agent", help="Run a single agent with a task specification")
    parser_agent.add_argument("name", help="Name of the agent to run")
    parser_agent.add_argument("--task", required=True, help="Task specification as JSON string")

    parser_orch = subparsers.add_parser("run-orchestrator", help="Run orchestrator on a list of tasks")
    parser_orch.add_argument("--task", required=True, help="List of task specifications as JSON string")

    subparsers.add_parser("show-cache", help="Show cache contents (not implemented)")
    subparsers.add_parser("show-logs", help="Show logs (not implemented)")

    args = parser.parse_args(argv)
    if args.command == "run-agent":
        asyncio.run(run_agent(args.name, args.task))
    elif args.command == "run-orchestrator":
        asyncio.run(run_orchestrator(args.task))
    elif args.command == "show-cache":
        print("Cache display not implemented in v1.")
    elif args.command == "show-logs":
        print("Log display not implemented in v1.")


if __name__ == "__main__":  # pragma: no cover
    main()