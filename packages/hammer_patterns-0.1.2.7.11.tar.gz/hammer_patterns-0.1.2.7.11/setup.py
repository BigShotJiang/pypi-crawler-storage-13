from setuptools import setup, find_packages

setup(
    name="hammer-patterns",
    version="0.1.2.7.11",     # change to new version
    packages=find_packages(),  # THIS FIXES EVERYTHING
    description="Fun ASCII hammer and custom patterns",
    author="Deepinder Singh",
    python_requires=">=3.7",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
