"""Template doc string."""
