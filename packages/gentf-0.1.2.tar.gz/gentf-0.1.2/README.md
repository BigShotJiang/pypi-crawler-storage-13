# gentf

**Generate file structures from text tree files** - A CLI tool that creates directory structures and scaffolds framework projects from simple text-based tree definitions.

## Features

- 📁 **Simple Structure Generation**: Create file and folder structures from text tree files
- ⚛️ **React Scaffolding**: Scaffold React projects with Vite or Create React App
- 🚀 **Next.js Scaffolding**: Scaffold Next.js projects with multiple variants (TypeScript, Turbopack, Pages Router, App Router)
- 🔄 **Smart Unwrapping**: Automatically unwraps matching top-level directories to avoid nested structures
- 🔀 **Intelligent Merging**: Merges your custom structure with scaffolded framework files

## Installation

```bash
pip install gentf
```

## Quick Start

### Basic Usage

Generate a file structure in the current directory:

```bash
gentf structure.txt
```

Generate in a specific output directory:

```bash
gentf structure.txt -o path/to/output
```

### Framework Scaffolding

**React with Vite:**
```bash
gentf project.txt --type react --variant vite
```

**React with Create React App:**
```bash
gentf project.txt --type react --variant cra
```

**Next.js (App Router):**
```bash
gentf project.txt --type next --variant default
```

**Next.js with TypeScript:**
```bash
gentf project.txt --type next --variant ts
```

**Next.js with Turbopack:**
```bash
gentf project.txt --type next --variant turbopack
```

**Next.js Pages Router:**
```bash
gentf project.txt --type next --variant pages
```

## Tree File Format

Create a text file describing your directory structure using indentation or box-drawing characters:

```
project-root/
├── src/
│   ├── components/
│   │   └── Button.tsx
│   ├── pages/
│   │   └── Home.tsx
│   └── App.tsx
├── public/
│   └── favicon.ico
├── package.json
└── README.md
```

Or use simple indentation:

```
project-root/
    src/
        components/
            Button.tsx
        pages/
            Home.tsx
        App.tsx
    public/
        favicon.ico
    package.json
    README.md
```

## How It Works

1. **Project Name**: Automatically derived from your tree file name (e.g., `myapp.txt` → `myapp`)
2. **Unwrapping**: If your tree file has a top-level directory matching the project name, it's automatically unwrapped to prevent nested structures
3. **Framework Scaffolding**: When using `--type`, the framework project is scaffolded first, then your tree structure is applied
4. **Smart Merging**: Your custom files are merged with scaffolded framework files

## Examples

### Simple Structure

```bash
# Create structure.txt with your tree definition
gentf structure.txt
```

### React Project with Custom Structure

```bash
# Scaffold React + Vite, then apply your tree structure
gentf myapp.txt --type react --variant vite -o ./projects
```

### Next.js TypeScript Project

```bash
# Scaffold Next.js with TypeScript, then apply your tree structure
gentf myapp.txt --type next --variant ts
```

## Help

Get detailed help and see all available options:

```bash
gentf --help
```

## Requirements

- Python 3.8+
- Node.js and npm (for framework scaffolding)

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Development

### Setup

```bash
# Create and activate virtual environment
python3 -m venv venv
source venv/bin/activate  # On macOS/Linux

# Install in editable mode
pip install -e .

# Install development dependencies
pip install build twine pytest
```

### Local Development

```bash
# Run tests
pytest tests/

# Test CLI
gentf --help

# Build package locally (for testing)
python -m build
```

See [DEVELOPMENT.md](DEVELOPMENT.md) for more details.

### Releasing

The project uses GitHub Actions for automatic PyPI publishing. To release a new version:

1. **Update version** in `pyproject.toml`
2. **Run the release script**:
   ```bash
   ./release.sh 0.1.1
   ```

Or manually:
```bash
git tag v0.1.1
git push origin v0.1.1
```

The workflow will automatically build, test, and publish to PyPI.

## Author

shayan (tomohmmdali@gmail.com)
