import re
from pathlib import Path
from typing import List, Optional


class Node:
    def __init__(self, name: str):
        self.name = name
        self.children: List["Node"] = []


def parse_tree(lines: List[str]) -> Optional[Node]:
    """Parse a textual tree (using box drawing chars or simple indentation)

    This function implements the parser you provided. It tolerates common
    tree-drawing characters like ├──, └──, │ and plain 4-space indentation.
    """
    root = Node("__root__")
    stack: List[Optional[Node]] = [root]

    # translation table to normalize box chars to spaces for indentation calc
    translation = str.maketrans({c: " " for c in "│├└─╰╯╭╮┌┐┬┴┤┘|+"})

    for line in lines:
        if not line.strip():
            continue

        # Normalize box-drawing characters into spaces then count groups of 4
        expanded = line.expandtabs(4)
        translated = expanded.translate(translation)
        leading_spaces = len(translated) - len(translated.lstrip(" "))
        depth = leading_spaces // 4

        # Clean up all box-drawing and hierarchy symbols from the name
        # Remove all Unicode box-drawing characters (U+2500-U+257F)
        # Also remove common ASCII alternatives like |, +, -, etc. when used for trees
        clean = line
        # Remove all box-drawing Unicode characters (range U+2500 to U+257F)
        clean = re.sub(r'[\u2500-\u257F]', '', clean)
        # Remove common ASCII tree characters that might be used
        # But preserve dashes/hyphens that are part of actual filenames
        # We'll be more careful: only remove leading tree chars before the actual name
        # Strip whitespace to clean up
        clean = clean.strip()
        
        # Strip comments (everything after #)
        if '#' in clean:
            clean = clean.split('#')[0].strip()
        
        # Skip lines that become empty after cleaning (e.g., lines with only box-drawing chars)
        if not clean:
            continue

        node = Node(clean)

        # ensure stack ready
        if len(stack) <= depth:
            stack.extend([None] * (depth + 1 - len(stack)))

        # parent at depth
        parent = stack[depth]
        if parent is None:
            # malformed input: a child without a parent at that depth
            raise ValueError(f"No parent found for node '{clean}' at depth {depth}")
        parent.children.append(node)

        # update stack
        if len(stack) > depth + 1:
            stack[depth + 1] = node
        else:
            stack.append(node)

    # Return the synthetic root so callers can decide how to materialize
    return root if root.children else None


def materialize_node(node: Node, base: Path) -> None:
    """Recursively create filesystem entries for a parsed node tree."""
    name = node.name
    if not name:
        return

    # Directory indicated by trailing slash
    if name.endswith("/"):
        target = base / name.rstrip("/")
        target.mkdir(parents=True, exist_ok=True)
        for child in node.children:
            materialize_node(child, target)
    else:
        # file
        target = base / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.touch(exist_ok=True)
        for child in node.children:
            # If a file has children treat them as contents under a directory
            materialize_node(child, target.parent)


def parse_and_build(txt_path: str | Path, output_dir: str | Path, unwrap_root_name: Optional[str] = None) -> None:
    """Read a textual tree file, parse it with parse_tree and materialize it.
    
    Args:
        txt_path: Path to the tree structure file
        output_dir: Directory where the structure should be created
        unwrap_root_name: If provided, unwrap a top-level directory matching this name
    """
    structure_file = Path(txt_path)
    if not structure_file.exists():
        raise FileNotFoundError(f"Structure file '{structure_file}' was not found.")

    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)

    lines = structure_file.read_text(encoding="utf-8").splitlines()
    root = parse_tree(lines)
    if root is None:
        return

    # If unwrap_root_name is provided, try to unwrap matching top-level directory
    if unwrap_root_name:
        for child in root.children:
            node_name = child.name.rstrip("/")
            if node_name == unwrap_root_name:
                is_directory = child.name.endswith("/") or len(child.children) > 0
                if is_directory:
                    # Unwrap: apply children directly to output_root
                    for grandchild in child.children:
                        materialize_node(grandchild, output_root)
                    return

    # If single top-level child is a directory, unwrap it
    if len(root.children) == 1:
        only = root.children[0]
        is_directory = only.name.endswith("/") or len(only.children) > 0
        if is_directory:
            # Unwrap: apply children directly to output_root
            for child in only.children:
                materialize_node(child, output_root)
            return

    # Default: materialize all top-level children under the output root
    for child in root.children:
        materialize_node(child, output_root)