import os
import time
from typing import Any, Dict, Optional, Type, TypeVar
from urllib.parse import urlparse

import requests
from openenv_core import HTTPEnvClient
from openenv_core.containers.runtime import ContainerProvider

EnvClientT = TypeVar("EnvClientT", bound="HTTPEnvClient")


class DojoOpenEnvProvisioner:
    @staticmethod
    def run_on_dojo(
        cls: Type[EnvClientT],
        image: str,
        api_key: str,
        env_vars: Optional[Dict[str, str]] = None,
    ) -> EnvClientT:
        provider = _DojoContainerProvider(api_key=api_key)
        url = provider.start_container(image=image, env_vars=env_vars)

        try:
            provider.wait_for_ready(base_url=url, timeout_s=60)
        except:
            provider.stop_container()
            raise

        return cls(
            base_url=url,
            provider=provider,
            default_headers=provider.headers,
        )


class _DojoContainerProvider(ContainerProvider):
    def __init__(self, api_key: str):
        dojo_endpoint = os.environ.get("DOJO_HTTP_ENDPOINT", "https://orchestrator.trydojo.ai")
        parsed_url = urlparse(dojo_endpoint)
        self._base_endpoint = f"{parsed_url.scheme}://{parsed_url.netloc}"
        self._container_path = Optional[str]
        self.headers = {"Authorization": f"Bearer {api_key}"}

    def start_container(
        self,
        image: str,
        port: Optional[int] = None,
        env_vars: Optional[Dict[str, str]] = None,
        **kwargs: Any,
    ) -> str:
        response = requests.post(
            f"{self._base_endpoint}/api/v1/openenv",
            json={
                "image": image,
                "env_vars": env_vars,
            },
            headers=self.headers,
        )
        response.raise_for_status()
        resp = response.json()
        self._container_path = resp["path"]
        return f"{self._base_endpoint}/{self._container_path}"

    def stop_container(self) -> None:
        response = requests.delete(f"{self._base_endpoint}/{self._container_path}", headers=self.headers)
        response.raise_for_status()

    def wait_for_ready(self, base_url: str, timeout_s: float = 60.0) -> None:
        for _ in range(int(timeout_s)):
            response = requests.get(f"{base_url}/health", headers=self.headers)
            if response.status_code == 200:
                return

            time.sleep(1)
        raise TimeoutError(f"Container did not become ready within {timeout_s} seconds")
