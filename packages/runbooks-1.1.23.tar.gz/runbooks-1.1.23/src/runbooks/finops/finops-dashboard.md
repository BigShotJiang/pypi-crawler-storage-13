# FinOps Dashboard

## 

## FinOps Dashboard Architecture

```mermaid
  graph TD
      A[CLI Entry: runbooks finops dashboard] --> B[Dashboard Runner]
      B --> C[Cost Processor]
      B --> D[Activity Enrichers]
      B --> E[Decommission Scorer]

      C --> F[Cost Explorer API]
      D --> G[AWS APIs: EC2/RDS/DX/etc]
      E --> H[Activity Metrics]

      B --> I{Validation Level}
      I -->|basic| J[Rich Output]
      I -->|mcp| K[MCP Validator]
      K --> L[InventoryCollector]
      L --> G
      K --> J

      J --> M[Executive Mode: Cost Dashboard]
      J --> N[Architect Mode: Services + Tree]
      J --> O[SRE Mode: Health + Operations]

      style K fill:#ff6b6b,stroke:#c92a2a
      style L fill:#51cf66,stroke:#2f9e44
      style M fill:#339af0,stroke:#1971c2
```

