import os
import subprocess
import sys
import shutil
from pathlib import Path

# Update this version when changing the Go code
__version__ = "0.1.3"


def main():
    """
    Entry point for the Loki MCP Server wrapper.
    It builds the Go binary if not present and runs it.
    """
    package_dir = Path(__file__).parent
    go_src_dir = package_dir / "go_src"

    # Name of the binary
    bin_name = "loki-mcp-server"
    if sys.platform == "win32":
        bin_name += ".exe"

    bin_path = package_dir / bin_name
    version_file = package_dir / "binary_version.txt"

    # Check if we need to build
    needs_build = False

    if not bin_path.exists():
        needs_build = True
    elif not version_file.exists():
        needs_build = True
    else:
        try:
            with open(version_file, "r") as f:
                built_version = f.read().strip()
            if built_version != __version__:
                print(
                    f"Binary version mismatch (built: {built_version}, required: {__version__}). Rebuilding...",
                    file=sys.stderr,
                )
                needs_build = True
        except Exception:
            needs_build = True

    if needs_build:
        if not bin_path.exists():
            print(f"Binary not found at {bin_path}. Building...", file=sys.stderr)

        # Verify Go is installed
        if not shutil.which("go"):
            print("Error: 'go' is not installed or not in PATH.", file=sys.stderr)
            print("Please install Go 1.24+ to use this package.", file=sys.stderr)
            sys.exit(1)

        # Build the binary
        cmd_path = go_src_dir / "cmd" / "server"
        if not cmd_path.exists():
            # Fallback for development (running from root without pip install)
            repo_root = package_dir.parent.parent
            cmd_path = repo_root / "cmd" / "server"

        if not cmd_path.exists():
            print(
                f"Error: Could not find Go source code at {go_src_dir} or {cmd_path}",
                file=sys.stderr,
            )
            sys.exit(1)

        try:
            # We build into the package directory so it's cached for next time
            subprocess.check_call(
                ["go", "build", "-o", str(bin_path), "."],
                cwd=str(cmd_path),
                env={**os.environ, "CGO_ENABLED": "0"},
                stdout=sys.stderr,  # Redirect stdout to stderr to prevent protocol corruption
                stderr=sys.stderr,
            )

            # Write version file
            with open(version_file, "w") as f:
                f.write(__version__)

            print("Build complete.", file=sys.stderr)
        except subprocess.CalledProcessError as e:
            print(f"Error building Go binary: {e}", file=sys.stderr)
            sys.exit(1)

    # Run the binary
    try:
        # Pass all arguments through to the binary
        result = subprocess.call([str(bin_path)] + sys.argv[1:])
        sys.exit(result)
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as e:
        print(f"Error running binary: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
