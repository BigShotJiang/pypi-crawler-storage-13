# src/veriskgo/sqs.py

import json
import boto3
import queue
import threading
import time
from typing import Optional, Dict, Any
from .config import get_cfg


class _VeriskGoSQS:
    """
    Asynchronous SQS sender that prevents blocking GenAI apps.
    - Internal queue
    - Background worker
    - Batch SQS send (10 at a time)
    - Auto reinit
    """

    def __init__(self):
        self.client: Optional[Any] = None
        self.queue_url: Optional[str] = None
        self.sqs_enabled = False
        self._init_once = False

        # Internal async work queue
        self._q: queue.Queue = queue.Queue(maxsize=5000)

        # Start background worker
        self._worker_thread = threading.Thread(
            target=self._worker_loop,
            daemon=True
        )
        self._worker_thread.start()

        # Initial setup
        self._auto_initialize()

    # ---------------------------------------------------------
    # AUTO INITIALIZATION
    # ---------------------------------------------------------
    def _auto_initialize(self):
        """Initialize SQS client if possible."""
        if self._init_once and self.client:
            return

        cfg = get_cfg()
        self.queue_url = cfg.get("aws_sqs_url")

        if not self.queue_url:
            print("[veriskgo] No SQS URL → SQS disabled.")
            return

        try:
            session = boto3.Session(
                profile_name=cfg.get("aws_profile"),
                region_name=cfg.get("aws_region", "us-east-1")
            )
            self.client = session.client("sqs")

            # Test connectivity
            self.client.get_queue_attributes(
                QueueUrl=self.queue_url,
                AttributeNames=["QueueArn"]
            )

            self.sqs_enabled = True
            print(f"[veriskgo] SQS connected → {self.queue_url}")

        except Exception as e:
            print("[veriskgo] SQS initialization failed:", e)
            self.client = None
            self.sqs_enabled = False

        self._init_once = True

    # ---------------------------------------------------------
    # PUBLIC ASYNC SEND: enqueue only, non-blocking
    # ---------------------------------------------------------
    def send(self, message: Optional[Dict[str, Any]]) -> bool:
        """Public API: Put into internal queue. Worker sends to SQS."""

        if not message:
            print("[veriskgo] Empty message → skip")
            return False

        try:
            self._q.put_nowait(message)
            return True
        except queue.Full:
            print("[veriskgo] WARNING: queue full → dropping trace")
            return False

    # ---------------------------------------------------------
    # BACKGROUND WORKER: Infinite loop
    # ---------------------------------------------------------
    def _worker_loop(self):
        """Runs forever and pushes batches to SQS."""
        batch = []

        while True:
            try:
                msg = self._q.get(timeout=0.2)
                batch.append(msg)
            except queue.Empty:
                pass

            # Flush conditions:
            flush_due_to_size = len(batch) >= 10
            flush_due_to_time = batch and (time.time() % 1 < 0.25)

            if flush_due_to_size or flush_due_to_time:
                self._send_batch(batch)
                batch = []

    # ---------------------------------------------------------
    # BATCH SENDER
    # ---------------------------------------------------------
    def _send_batch(self, batch: list):
        """Send up to 10 messages in one batch call."""

        if not batch:
            return

        # Ensure client exists
        if not self.client or not self.sqs_enabled:
            self._auto_initialize()

        if not self.client or not self.sqs_enabled:
            print("[veriskgo] SQS unavailable → skipping batch")
            return

        entries = []
        for i, msg in enumerate(batch[:10]):
            entries.append({
                "Id": str(i),
                "MessageBody": json.dumps(msg)
            })

        client = self.client  # local var helps Pylance guarantee non-null

        try:
            client.send_message_batch(
                QueueUrl=self.queue_url,
                Entries=entries
            )
            print(f"[veriskgo] Batch sent ({len(entries)} traces).")

        except Exception as e:
            print("[veriskgo] ERROR in batch:", e)
            self._retry_individual(batch)

    # ---------------------------------------------------------
    # FALLBACK: retry one-by-one
    # ---------------------------------------------------------
    def _retry_individual(self, batch: list):
        """Retry each message individually when batch fails."""

        # Ensure client
        if not self.client or not self.sqs_enabled:
            self._auto_initialize()

        if not self.client or not self.sqs_enabled:
            print("[veriskgo] Client unavailable → drop individual retries")
            return

        client = self.client  # now guaranteed non-None

        for msg in batch:
            try:
                client.send_message(
                    QueueUrl=self.queue_url,
                    MessageBody=json.dumps(msg)
                )
                print("[veriskgo] Single retry succeeded.")
            except Exception as e:
                print("[veriskgo] Single retry FAILED:", e)


# ---------------------------------------------------------
# SINGLETON INSTANCE
# ---------------------------------------------------------
_sqs_instance = _VeriskGoSQS()

def init_sqs() -> bool:
    """Backward compatibility."""
    return _sqs_instance.sqs_enabled


def send_to_sqs(trace_bundle: Optional[Dict[str, Any]]) -> bool:
    """Public API → now fully async."""
    return _sqs_instance.send(trace_bundle)
