"""
Locator Picker for rfdb - Selenium Element Selector
Allows users to visually pick elements and generate XPath locators
"""

import logging
from typing import List, Dict, Tuple, Optional, Any


class LocatorPicker:
    """Handles element picking and XPath generation for Selenium failures"""
    
    # Selenium-related error patterns
    SELENIUM_ERROR_PATTERNS = [
        'ElementNotFound',
        'NoSuchElement',
        'TimeoutException',
        'element not found',
        'could not locate',
        'unable to locate element',
        'no such element',
        'element is not visible',
        'element not interactable'
    ]
    
    # Configuration
    PICKER_TIMEOUT_SECONDS = 30
    POLL_INTERVAL_MS = 100
    
    @staticmethod
    def is_selenium_failure(keyword_name: str, error_message: str, libraries: List[str], args: List[Any] = None) -> bool:
        """
        Detect if failure is Selenium element-related (smart detection)
        
        Args:
            keyword_name: Name of failed keyword
            error_message: Error message from failure
            libraries: List of imported library names
            args: Keyword arguments (optional)
            
        Returns:
            True if this is a Selenium element failure
        """
        # Check if SeleniumLibrary is imported
        has_selenium = any('selenium' in lib.lower() for lib in libraries)
        if not has_selenium:
            return False
        
        # Smart detection 1: Check if error message contains element-related errors (most reliable)
        error_match = any(pattern.lower() in error_message.lower() 
                         for pattern in LocatorPicker.SELENIUM_ERROR_PATTERNS)
        if error_match:
            logging.info(f"[Locator Picker] Detected Selenium failure via error pattern match: {keyword_name}")
            return True
        
        # Smart detection 2: Check if first argument looks like a locator
        if args and len(args) > 0:
            first_arg = str(args[0])
            # Common locator patterns
            locator_patterns = [
                'id:', 'css:', 'xpath:', 'name:', 'class:', 'tag:', 'link:',
                '//', 'id=', 'css=', 'xpath=', 'name=', 'class='
            ]
            if any(first_arg.startswith(pattern) for pattern in locator_patterns):
                logging.info(f"[Locator Picker] Detected Selenium failure via locator pattern in args: {keyword_name}")
                return True
            # Check if looks like XPath or CSS selector
            if first_arg.startswith(('//', '/', '(', '#', '.')):
                logging.info(f"[Locator Picker] Detected Selenium failure via XPath/CSS pattern in args: {keyword_name}")
                return True
        
        # Smart detection 3: Keyword name contains element-related terms
        element_terms = ['element', 'click', 'input', 'wait', 'page should contain', 
                        'textfield', 'checkbox', 'button', 'link', 'select']
        keyword_lower = keyword_name.lower()
        if any(term in keyword_lower for term in element_terms):
            logging.info(f"[Locator Picker] Detected Selenium failure via keyword name match: {keyword_name}")
            return True
        
        logging.debug(f"[Locator Picker] No Selenium failure detected for: {keyword_name}")
        return False
    
    @staticmethod
    def get_picker_javascript() -> str:
        """
        Returns JavaScript code to inject into browser for element picking
        
        Features:
        - Highlights elements on hover
        - Captures element on click
        - Extracts element properties (id, name, class, text, tag, path)
        - ESC to cancel
        - Error reporting back to Python
        """
        return """
(function() {
    try {
        // Prevent multiple injections
        if (window.__rfdb_picker_active) {
            return { error: 'Picker already active' };
        }
        window.__rfdb_picker_active = true;
    
    let selectedElement = null;
    let originalOutline = null;
    let lastHighlighted = null;
    let tooltip = null;
    
    // Create tooltip element
    function createTooltip() {
        tooltip = document.createElement('div');
        tooltip.style.position = 'fixed';
        tooltip.style.backgroundColor = '#000';
        tooltip.style.color = '#fff';
        tooltip.style.padding = '8px 12px';
        tooltip.style.borderRadius = '4px';
        tooltip.style.fontSize = '12px';
        tooltip.style.fontFamily = 'monospace';
        tooltip.style.zIndex = '999999';
        tooltip.style.pointerEvents = 'none';
        tooltip.style.whiteSpace = 'pre-line';
        tooltip.style.maxWidth = '300px';
        document.body.appendChild(tooltip);
    }
    
    // Update tooltip content and position
    function updateTooltip(element, x, y) {
        if (!tooltip) createTooltip();
        
        const tag = element.tagName.toLowerCase();
        const text = element.textContent.trim().substring(0, 40);
        const id = element.id ? `#${element.id}` : '';
        const classes = element.className ? `.${element.className.split(' ')[0]}` : '';
        
        tooltip.textContent = `<${tag}${id}${classes}>\\n${text ? 'Text: ' + text : 'No text'}`;
        tooltip.style.left = (x + 15) + 'px';
        tooltip.style.top = (y + 15) + 'px';
        tooltip.style.display = 'block';
    }
    
    // Hover highlight with tooltip
    function highlightElement(e) {
        if (lastHighlighted && lastHighlighted !== e.target) {
            lastHighlighted.style.outline = '';
        }
        e.target.style.outline = '3px solid #00ff00';
        lastHighlighted = e.target;
        updateTooltip(e.target, e.clientX, e.clientY);
        e.stopPropagation();
        e.preventDefault();
    }
    
    // Get Chrome-style XPath (absolute path with positions)
    function getChromeXPath(element) {
        try {
            if (element.id) {
                return `//*[@id="${element.id}"]`;
            }
        
        const parts = [];
        let current = element;
        let foundId = false;
        
        while (current && current.nodeType === Node.ELEMENT_NODE) {
            if (current.id) {
                // Found ancestor with ID - add it without // prefix
                parts.unshift(`*[@id="${current.id}"]`);
                foundId = true;
                break;
            }
            
            let tag = current.tagName.toLowerCase();
            let index = 1;
            let sibling = current.previousElementSibling;
            
            while (sibling) {
                if (sibling.tagName === current.tagName) {
                    index++;
                }
                sibling = sibling.previousElementSibling;
            }
            
            // Check if there are multiple siblings of same tag
            const siblings = Array.from(current.parentNode.children).filter(
                el => el.tagName === current.tagName
            );
            
            if (siblings.length > 1) {
                parts.unshift(`${tag}[${index}]`);
            } else {
                parts.unshift(tag);
            }
            
            current = current.parentElement;
            
            // Stop at body
            if (current && current.tagName.toLowerCase() === 'body') {
                break;
            }
        }
        
            // Join with single /
            return '//' + parts.join('/');
        } catch (error) {
            console.error('[rfdb] XPath generation error:', error);
            return null;
        }
    }
    
    // Get element path (for internal use)
    function getElementPath(element) {
        const path = [];
        let current = element;
        
        while (current && current.nodeType === Node.ELEMENT_NODE) {
            let selector = current.tagName.toLowerCase();
            
            if (current.id) {
                selector += '#' + current.id;
                path.unshift(selector);
                break;  // Stop at ID
            } else {
                // Get index among siblings of same tag
                let sibling = current;
                let nth = 1;
                while (sibling.previousElementSibling) {
                    sibling = sibling.previousElementSibling;
                    if (sibling.tagName === current.tagName) nth++;
                }
                if (nth > 1) selector += ':nth-of-type(' + nth + ')';
                path.unshift(selector);
            }
            
            current = current.parentElement;
        }
        
        return path;
    }
    
    // Extract element data
    function getElementData(element) {
        try {
            const rect = element.getBoundingClientRect();
            const text = element.textContent.trim().substring(0, 50);
        
        return {
            tag: element.tagName.toLowerCase(),
            id: element.id || null,
            name: element.getAttribute('name') || null,
            className: element.className || null,
            text: text || null,
            type: element.getAttribute('type') || null,
            href: element.getAttribute('href') || null,
            placeholder: element.getAttribute('placeholder') || null,
            value: element.value || null,
            path: getElementPath(element),
            chromeXPath: getChromeXPath(element),
            position: {
                x: rect.left,
                y: rect.top,
                width: rect.width,
                height: rect.height
            }
        };
        } catch (error) {
            console.error('[rfdb] Element data extraction error:', error);
            window.__rfdb_selected_element = { error: 'Failed to extract element data: ' + error.message };
            cleanup();
            return null;
        }
    }
    
    // Click to select
    function selectElement(e) {
        e.stopPropagation();
        e.preventDefault();
        
        selectedElement = getElementData(e.target);
        cleanup();
        
        // Store in window for retrieval
        window.__rfdb_selected_element = selectedElement;
    }
    
    // Cancel on ESC
    function handleKeydown(e) {
        if (e.key === 'Escape') {
            cleanup();
            window.__rfdb_selected_element = { cancelled: true };
        }
    }
    
    // Cleanup
    function cleanup() {
        document.removeEventListener('mouseover', highlightElement, true);
        document.removeEventListener('click', selectElement, true);
        document.removeEventListener('keydown', handleKeydown, true);
        if (lastHighlighted) {
            lastHighlighted.style.outline = '';
        }
        if (tooltip) {
            tooltip.remove();
            tooltip = null;
        }
        window.__rfdb_picker_active = false;
    }
    
    // Attach listeners
        document.addEventListener('mouseover', highlightElement, true);
        document.addEventListener('click', selectElement, true);
        document.addEventListener('keydown', handleKeydown, true);
        
        return { status: 'Picker activated. Click any element or press ESC to cancel.' };
    } catch (error) {
        console.error('[rfdb] Picker initialization error:', error);
        window.__rfdb_picker_active = false;
        return { error: 'Picker initialization failed: ' + error.message };
    }
})();
"""
    
    @staticmethod
    def _escape_xpath_value(value: str) -> str:
        """
        Escape special characters in XPath string values
        Handles quotes and apostrophes by using concat() if needed
        
        Args:
            value: String value to escape
            
        Returns:
            Escaped XPath string expression
        """
        if not value:
            return "''"
        
        # If no quotes or apostrophes, use simple quoting
        if "'" not in value and '"' not in value:
            return f"'{value}'"
        
        # If only apostrophes, use double quotes
        if "'" in value and '"' not in value:
            return f'"{value}"'
        
        # If only double quotes, use apostrophes
        if '"' in value and "'" not in value:
            return f"'{value}'"
        
        # Both types of quotes - use concat()
        parts = []
        current = []
        for char in value:
            if char == "'":
                if current:
                    parts.append(f"'{''.join(current)}'")
                    current = []
                parts.append('"\'\"')  # Apostrophe in double quotes
            else:
                current.append(char)
        if current:
            parts.append(f"'{''.join(current)}'")
        
        return f"concat({', '.join(parts)})"
    
    @staticmethod
    def generate_xpath_variants(element_data: Dict[str, Any]) -> List[Tuple[str, str]]:
        """
        Generate 3 XPath variants from element data
        Priority: ID-based, Name-based, Chrome XPath, Text-based
        
        Args:
            element_data: Dictionary with element properties from JavaScript
            
        Returns:
            List of (description, xpath) tuples (exactly 3)
        """
        variants = []
        tag = element_data.get('tag', '*')
        
        # Variant 1: ID-based (most reliable if available)
        if element_data.get('id'):
            escaped_id = LocatorPicker._escape_xpath_value(element_data['id'])
            xpath = f"//{tag}[@id={escaped_id}]"
            variants.append(("ID-based", xpath))
        
        # Variant 2: Name-based (second priority)
        if element_data.get('name'):
            escaped_name = LocatorPicker._escape_xpath_value(element_data['name'])
            xpath = f"//{tag}[@name={escaped_name}]"
            variants.append(("Name-based", xpath))
        
        # Variant 3: Relative XPath (Chrome-style with positions)
        if len(variants) < 3:
            chrome_xpath = element_data.get('chromeXPath')
            if chrome_xpath:
                variants.append(("Relative XPath", chrome_xpath))
        
        # Variant 4: Text-based
        if len(variants) < 3:
            text = element_data.get('text')
            if text and len(text) > 0:
                if len(text) < 30:
                    # Exact match for short text
                    escaped_text = LocatorPicker._escape_xpath_value(text)
                    xpath = f"//{tag}[text()={escaped_text}]"
                else:
                    # Contains for longer text (truncate first)
                    escaped_text = LocatorPicker._escape_xpath_value(text[:20])
                    xpath = f"//{tag}[contains(text(), {escaped_text})]"
                variants.append(("Text-based", xpath))
        
        # Fill remaining slots if needed (fallbacks)
        if len(variants) < 3 and element_data.get('className'):
            class_name = element_data['className'].split()[0]  # First class
            escaped_class = LocatorPicker._escape_xpath_value(class_name)
            xpath = f"//{tag}[contains(@class, {escaped_class})]"
            variants.append(("Class-based", xpath))
        
        if len(variants) < 3 and element_data.get('type'):
            escaped_type = LocatorPicker._escape_xpath_value(element_data['type'])
            xpath = f"//{tag}[@type={escaped_type}]"
            variants.append(("Type-based", xpath))
        
        if len(variants) < 3 and element_data.get('placeholder'):
            escaped_placeholder = LocatorPicker._escape_xpath_value(element_data['placeholder'])
            xpath = f"//{tag}[@placeholder={escaped_placeholder}]"
            variants.append(("Placeholder-based", xpath))
        
        return variants[:3]  # Return max 3
    
    @staticmethod
    def get_selenium_driver():
        """
        Get active Selenium WebDriver from Robot Framework
        
        Returns:
            WebDriver instance or None if not available
        """
        try:
            from robot.libraries.BuiltIn import BuiltIn
            
            # Try to get SeleniumLibrary instance
            try:
                selenium_lib = BuiltIn().get_library_instance('SeleniumLibrary')
                driver = selenium_lib.driver
                return driver
            except:
                # Try Browser library as fallback
                try:
                    browser_lib = BuiltIn().get_library_instance('Browser')
                    # Browser library has different API
                    return None  # Not supported yet
                except:
                    return None
        except Exception as e:
            logging.error(f"Failed to get Selenium driver: {e}")
            return None
    
    @staticmethod
    def pick_element(driver) -> Optional[Dict[str, Any]]:
        """
        Execute picker in browser and wait for user selection
        
        Args:
            driver: Selenium WebDriver instance
            
        Returns:
            Element data dictionary or None if cancelled/failed
        """
        try:
            # Validate browser is still open
            try:
                _ = driver.current_url  # Simple check to see if browser is responsive
            except Exception as e:
                logging.error(f"Browser is not accessible: {e}")
                return {'error': 'Browser window is closed or not responding'}
            
            # Inject picker JavaScript
            js_code = LocatorPicker.get_picker_javascript()
            result = driver.execute_script(js_code)
            
            if isinstance(result, dict) and result.get('error'):
                logging.error(f"Picker injection failed: {result['error']}")
                return None
            
            # Return success - caller will poll for selection
            return {'status': 'waiting'}
            
        except Exception as e:
            logging.error(f"Failed to inject picker: {e}")
            return None
    
    @staticmethod
    def get_selected_element(driver) -> Optional[Dict[str, Any]]:
        """
        Retrieve selected element data from browser
        
        Args:
            driver: Selenium WebDriver instance
            
        Returns:
            Element data or None
        """
        try:
            # Validate browser is still open
            try:
                _ = driver.current_url
            except Exception as e:
                logging.error(f"Browser is not accessible during element retrieval: {e}")
                return {'error': 'Browser closed during selection'}
            
            # Get element data first (before cleanup to avoid race condition)
            result = driver.execute_script("return window.__rfdb_selected_element;")
            
            # Only clean up if we got data (avoid deleting before read completes)
            if result:
                try:
                    driver.execute_script("delete window.__rfdb_selected_element; delete window.__rfdb_picker_active;")
                except:
                    pass  # Ignore cleanup errors
            
            if result and result.get('cancelled'):
                return None
            
            if result and result.get('error'):
                logging.error(f"JavaScript error during picking: {result['error']}")
                return None
            
            return result
        except Exception as e:
            logging.error(f"Failed to get selected element: {e}")
            return None
