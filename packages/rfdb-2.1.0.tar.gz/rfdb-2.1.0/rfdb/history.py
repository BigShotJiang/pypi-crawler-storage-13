"""
Debug History Tracker for rfdb
Tracks all debugging actions (retries, skips, arg changes) to a log file
Minimal memory overhead - loads on-demand when UI refreshes
"""

import json
import os
import logging
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum


class ActionType(Enum):
    """Types of actions that can be tracked"""
    FAILURE = "FAILURE"
    RETRY = "RETRY"
    SKIP_KEYWORD = "SKIP_KEYWORD"
    SKIP_TEST = "SKIP_TEST"
    ARGS_CHANGED = "ARGS_CHANGED"
    CONTINUE = "CONTINUE"
    CUSTOM_EXECUTION = "CUSTOM_EXECUTION"
    ABORT_SUITE = "ABORT_SUITE"


@dataclass
class HistoryEntry:
    """Single history entry representing a debug action"""
    timestamp: str
    action_type: ActionType
    keyword_name: str
    test_name: Optional[str] = None
    suite_name: Optional[str] = None
    args: Optional[List[Any]] = None
    old_args: Optional[List[Any]] = None  # For ARGS_CHANGED
    result: Optional[str] = None  # "PASS" or "FAIL"
    message: Optional[str] = None
    details: Optional[Dict[str, Any]] = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON export"""
        data = asdict(self)
        data['action_type'] = self.action_type.value
        return data

    @classmethod
    def from_dict(cls, data: dict) -> 'HistoryEntry':
        """Create from dictionary (for loading from JSON)"""
        data['action_type'] = ActionType(data['action_type'])
        return cls(**data)


class DebugHistory:
    """
    Tracks all debugging actions to a log file (append-only).
    Loads entries on-demand when UI requests refresh.
    No memory overhead - just file I/O.
    Each execution creates a unique timestamped log file.
    """

    def __init__(self, log_file: Optional[str] = None):
        # Create timestamped log file for each execution
        self.session_start = datetime.now()
        if log_file is None:
            timestamp = self.session_start.strftime("%Y%m%d_%H%M%S")
            self.log_file = f"rfdb_history_{timestamp}.log"
        else:
            self.log_file = log_file
        # Write session header
        self._write_log(f"# SESSION START: {self.session_start.isoformat()}\n")

    def add_failure(self, keyword_name: str, test_name: str, args: List[Any], 
                   message: str, suite_name: Optional[str] = None) -> None:
        """Record a keyword failure"""
        entry = HistoryEntry(
            timestamp=self._timestamp(),
            action_type=ActionType.FAILURE,
            keyword_name=keyword_name,
            test_name=test_name,
            suite_name=suite_name,
            args=args,
            result="FAIL",
            message=message
        )
        self._append_to_log(entry)

    def add_retry(self, keyword_name: str, test_name: str, args: List[Any],
                 result: str, message: Optional[str] = None, suite_name: Optional[str] = None) -> None:
        """Record a retry attempt"""
        entry = HistoryEntry(
            timestamp=self._timestamp(),
            action_type=ActionType.RETRY,
            keyword_name=keyword_name,
            test_name=test_name,
            suite_name=suite_name,
            args=args,
            result=result,
            message=message
        )
        self._append_to_log(entry)

    def add_skip_keyword(self, keyword_name: str, test_name: str) -> None:
        """Record a skipped keyword"""
        entry = HistoryEntry(
            timestamp=self._timestamp(),
            action_type=ActionType.SKIP_KEYWORD,
            keyword_name=keyword_name,
            test_name=test_name
        )
        self._append_to_log(entry)

    def add_skip_test(self, test_name: str) -> None:
        """Record a skipped test"""
        entry = HistoryEntry(
            timestamp=self._timestamp(),
            action_type=ActionType.SKIP_TEST,
            keyword_name="N/A",
            test_name=test_name
        )
        self._append_to_log(entry)

    def add_args_changed(self, keyword_name: str, test_name: str,
                        old_args: List[Any], new_args: List[Any], suite_name: Optional[str] = None) -> None:
        """Record argument modification"""
        entry = HistoryEntry(
            timestamp=self._timestamp(),
            action_type=ActionType.ARGS_CHANGED,
            keyword_name=keyword_name,
            test_name=test_name,
            suite_name=suite_name,
            args=new_args,
            old_args=old_args
        )
        self._append_to_log(entry)

    def add_continue(self, test_name: str, keyword_name: Optional[str] = None) -> None:
        """Record continue/resume action"""
        entry = HistoryEntry(
            timestamp=self._timestamp(),
            action_type=ActionType.CONTINUE,
            keyword_name=keyword_name or "N/A",
            test_name=test_name
        )
        self._append_to_log(entry)

    def add_custom_execution(self, keyword_name: str, result: str,
                           message: Optional[str] = None) -> None:
        """Record custom keyword execution"""
        entry = HistoryEntry(
            timestamp=self._timestamp(),
            action_type=ActionType.CUSTOM_EXECUTION,
            keyword_name=keyword_name,
            result=result,
            message=message
        )
        self._append_to_log(entry)

    def add_abort_suite(self, suite_name: str) -> None:
        """Record suite abortion"""
        entry = HistoryEntry(
            timestamp=self._timestamp(),
            action_type=ActionType.ABORT_SUITE,
            keyword_name="N/A",
            test_name=suite_name
        )
        self._append_to_log(entry)

    def get_all_entries(self) -> List[HistoryEntry]:
        """Load all history entries from log file"""
        return self._load_entries_from_log()

    def filter_by_action_type(self, action_type: ActionType) -> List[HistoryEntry]:
        """Filter entries by action type"""
        all_entries = self._load_entries_from_log()
        return [e for e in all_entries if e.action_type == action_type]

    def clear(self) -> None:
        """Clear all history - delete log file"""
        try:
            if os.path.exists(self.log_file):
                os.remove(self.log_file)
            # Recreate with session header
            self._write_log(f"# SESSION START: {datetime.now().isoformat()}\n")
        except Exception as e:
            logging.error(f"Failed to clear history: {e}")

    def get_statistics(self) -> Dict[str, Any]:
        """Get summary statistics"""
        all_entries = self._load_entries_from_log()
        stats = {
            "total_actions": len(all_entries),
            "failures": len([e for e in all_entries if e.action_type == ActionType.FAILURE]),
            "retries": len([e for e in all_entries if e.action_type == ActionType.RETRY]),
            "successful_retries": len([e for e in all_entries 
                                      if e.action_type == ActionType.RETRY and e.result == "PASS"]),
            "failed_retries": len([e for e in all_entries 
                                  if e.action_type == ActionType.RETRY and e.result == "FAIL"]),
            "skips": len([e for e in all_entries if e.action_type == ActionType.SKIP_KEYWORD]),
            "args_changes": len([e for e in all_entries if e.action_type == ActionType.ARGS_CHANGED]),
            "session_duration": str(datetime.now() - self.session_start)
        }
        return stats

    def _append_to_log(self, entry: HistoryEntry) -> None:
        """Append entry to log file (fast, no memory overhead)"""
        try:
            log_line = json.dumps(entry.to_dict()) + "\n"
            self._write_log(log_line)
        except Exception as e:
            # Silently fail to not block test execution
            pass

    def _write_log(self, content: str) -> None:
        """Write to log file"""
        try:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(content)
        except Exception:
            pass

    def _load_entries_from_log(self) -> List[HistoryEntry]:
        """Load all entries from log file on-demand"""
        entries = []
        try:
            if not os.path.exists(self.log_file):
                return entries
            
            with open(self.log_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    try:
                        data = json.loads(line)
                        entries.append(HistoryEntry.from_dict(data))
                    except Exception:
                        continue
        except Exception:
            pass
        return entries

    def _timestamp(self) -> str:
        """Generate timestamp string"""
        return datetime.now().strftime("%H:%M:%S")
