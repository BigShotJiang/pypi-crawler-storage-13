# argparts

Dummy package to reserve the name `argparts` on PyPI.

This package is intentionally minimal and contains a placeholder function.

argparts coming soon