"""Text normalization helpers shared across datasets."""

from __future__ import annotations

import re


def strip_code_fence(text: str) -> str:
    """Remove SQL/JSON/markdown code fences if present."""
    fenced = text.strip()
    if fenced.startswith("```"):
        fenced = re.sub(r"^```(?:\w+)?", "", fenced, count=1).strip()
        fenced = re.sub(r"```$", "", fenced, count=1).strip()
    return fenced


def deduplicate_sentences(text: str) -> str:
    """Remove duplicate sentences while preserving order."""
    sentences = [
        sentence.strip()
        for sentence in re.split(r"(?<=[.!?])\s+", text.strip())
        if sentence.strip()
    ]
    seen: set[str] = set()
    unique: list[str] = []
    for sentence in sentences:
        key = re.sub(r"\s+", " ", sentence).lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(sentence.rstrip(".") + ".")
    return " ".join(unique).strip()


def normalize_whitespace(text: str) -> str:
    """Collapse whitespace for consistent comparisons."""
    return re.sub(r"\s+", " ", text.strip())


__all__ = ["deduplicate_sentences", "normalize_whitespace", "strip_code_fence"]
