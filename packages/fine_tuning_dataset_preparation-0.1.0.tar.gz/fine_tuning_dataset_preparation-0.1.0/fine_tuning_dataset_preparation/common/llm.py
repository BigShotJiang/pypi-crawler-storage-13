"""LLM-related helpers shared across dataset builders."""

from __future__ import annotations

import os
from enum import Enum
from typing import Any, List, Optional

ChatGoogleGenerativeAI = None
ChatOpenAI = None
ChatAnthropic = None

try:
    from langchain_google_genai import ChatGoogleGenerativeAI  # type: ignore[assignment]
except ImportError:
    pass

try:
    from langchain_openai import ChatOpenAI  # type: ignore[assignment]
except ImportError:
    pass

try:
    from langchain_anthropic import ChatAnthropic  # type: ignore[assignment]
except ImportError:
    pass


class LLMProvider(str, Enum):
    GEMINI = "gemini"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"


def build_llm(
    provider: str | LLMProvider = LLMProvider.GEMINI,
    model_name: str = "gemini-2.5-flash",
    temperature: float = 0.7,
    **kwargs,
):
    """Construct a chat LLM client for the given provider or return None if unavailable."""
    provider_value = (provider.value if isinstance(provider, LLMProvider) else provider).lower()

    if provider_value == LLMProvider.GEMINI.value:
        if ChatGoogleGenerativeAI is None:
            return None
        api_key = kwargs.get("api_key") or os.getenv("GOOGLE_API_KEY")
        if not api_key:
            return None
        return ChatGoogleGenerativeAI(
            model=model_name,
            temperature=temperature,
            convert_system_message_to_human=True,
            **{k: v for k, v in kwargs.items() if k != "api_key"},
        )

    if provider_value == LLMProvider.OPENAI.value:
        if ChatOpenAI is None:
            return None
        api_key = kwargs.get("api_key") or os.getenv("OPENAI_API_KEY")
        if not api_key:
            return None
        return ChatOpenAI(
            model=model_name,
            temperature=temperature,
            api_key=api_key,
            **{k: v for k, v in kwargs.items() if k != "api_key"},
        )

    if provider_value == LLMProvider.ANTHROPIC.value:
        if ChatAnthropic is None:
            return None
        api_key = kwargs.get("api_key") or os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            return None
        return ChatAnthropic(
            model=model_name,
            temperature=temperature,
            api_key=api_key,
            **{k: v for k, v in kwargs.items() if k != "api_key"},
        )

    raise ValueError(f"Unsupported LLM provider '{provider}'.")


def extract_text_from_llm_message(message: Any) -> str:
    """Normalize LangChain ChatResult content to plain text."""
    content = getattr(message, "content", "")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts: List[str] = []
        for item in content:
            if hasattr(item, "text"):
                parts.append(item.text)
            elif isinstance(item, dict) and "text" in item:
                parts.append(str(item["text"]))
        return "\n".join(parts).strip()
    return str(content).strip()


__all__ = ["LLMProvider", "build_llm", "extract_text_from_llm_message"]
