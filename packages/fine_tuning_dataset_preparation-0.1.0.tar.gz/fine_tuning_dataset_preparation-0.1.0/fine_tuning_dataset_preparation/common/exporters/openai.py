"""OpenAI dataset exporters (JSON/JSONL)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

DEFAULT_SYSTEM_PROMPT = "You are a helpful coding assistant. Generate code based on the given instruction."


def _build_entry(record: dict, system_prompt: str) -> dict:
    entry = {
        "messages": [
            {
                "role": "system",
                "content": [{"type": "text", "text": system_prompt}],
            },
            {
                "role": "user",
                "content": [{"type": "text", "text": record["instruction"]}],
            },
            {
                "role": "assistant",
                "content": [{"type": "text", "text": record["output"]}],
            },
        ],
    }
    metadata = record.get("metadata")
    if metadata:
        entry["metadata"] = metadata
    if record.get("alternate_instructions"):
        entry.setdefault("metadata", {})["alternate_instructions"] = record["alternate_instructions"]
    return entry


def export_openai(
    records: List[dict],
    output_path: Path,
    options: Dict,
) -> None:
    system_prompt = options.get("system_prompt", DEFAULT_SYSTEM_PROMPT)
    as_jsonl = options.get("jsonl", True if output_path.suffix == ".jsonl" else False)

    if as_jsonl:
        with output_path.open("w", encoding="utf-8") as f:
            for record in records:
                json.dump(_build_entry(record, system_prompt), f, ensure_ascii=False)
                f.write("\n")
    else:
        data = [_build_entry(record, system_prompt) for record in records]
        with output_path.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
