from __future__ import annotations

from pathlib import Path
from typing import Callable, Dict, List

from .base import load_jsonl
from .gemini import export_gemini
from .openai import export_openai
from .qa import export_qa_gemini, export_qa_jsonl, export_qa_openai

Formatter = Callable[[List[dict], Path, Dict], None]

_FORMATTERS: Dict[str, Formatter] = {
    "gemini": export_gemini,
    "openai": export_openai,
    "qa_gemini": export_qa_gemini,
    "qa_openai": export_qa_openai,
    "qa_jsonl": export_qa_jsonl,
}


def export_dataset(
    dataset_path: str | Path,
    output_path: str | Path,
    *,
    target: str = "gemini",
    **options,
) -> None:
    dataset_path = Path(dataset_path)
    output_path = Path(output_path)
    formatter = _FORMATTERS.get(target.lower())
    if formatter is None:
        raise ValueError(f"Unknown exporter target '{target}'. Available: {', '.join(sorted(_FORMATTERS))}")

    records = load_jsonl(dataset_path)
    formatter(records, output_path, options)


__all__ = [
    "export_dataset",
    "export_gemini",
    "export_openai",
    "export_qa_gemini",
    "export_qa_jsonl",
    "export_qa_openai",
]
