"""Export helpers for question/answer style datasets (documents)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable, List

DEFAULT_QA_SYSTEM_PROMPT = "You are a helpful assistant. Answer the user's question concisely based on prior context."


def _build_openai_entry(pair: dict, system_prompt: str) -> dict:
    entry = {
        "messages": [
            {
                "role": "system",
                "content": [{"type": "text", "text": system_prompt}],
            },
            {
                "role": "user",
                "content": [{"type": "text", "text": pair["question"]}],
            },
            {
                "role": "assistant",
                "content": [{"type": "text", "text": pair["answer"]}],
            },
        ],
    }
    metadata: Dict[str, object] = {}
    if doc := pair.get("document"):
        metadata["document"] = doc
    if seg_ref := pair.get("segment_ref"):
        metadata["segment_ref"] = seg_ref
    if seg_kind := pair.get("segment_kind"):
        metadata["segment_kind"] = seg_kind
    if cat := pair.get("category_path"):
        metadata["category_path"] = cat
    if metadata:
        entry["metadata"] = metadata
    return entry


def _build_gemini_entry(pair: dict, system_prompt: str) -> dict:
    return {
        "systemInstruction": {
            "role": "system",
            "parts": [{"text": system_prompt}],
        },
        "contents": [
            {
                "role": "user",
                "parts": [{"text": pair["question"]}],
            },
            {
                "role": "model",
                "parts": [{"text": pair["answer"]}],
            },
        ],
        "metadata": {
            "document": pair.get("document"),
            "segment_ref": pair.get("segment_ref"),
            "segment_kind": pair.get("segment_kind"),
            "category_path": pair.get("category_path"),
        },
    }


def export_qa_openai(pairs: Iterable[dict], output_path: Path, options: Dict) -> None:
    system_prompt = options.get("system_prompt", DEFAULT_QA_SYSTEM_PROMPT)
    as_jsonl = options.get("jsonl", output_path.suffix == ".jsonl")
    records = [_build_openai_entry(pair, system_prompt) for pair in pairs]
    if as_jsonl:
        with output_path.open("w", encoding="utf-8") as f:
            for record in records:
                json.dump(record, f, ensure_ascii=False)
                f.write("\n")
    else:
        with output_path.open("w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)


def export_qa_gemini(pairs: Iterable[dict], output_path: Path, options: Dict) -> None:
    system_prompt = options.get("system_prompt", DEFAULT_QA_SYSTEM_PROMPT)
    as_jsonl = options.get("jsonl", output_path.suffix == ".jsonl")
    records = [_build_gemini_entry(pair, system_prompt) for pair in pairs]
    if as_jsonl:
        with output_path.open("w", encoding="utf-8") as f:
            for record in records:
                json.dump(record, f, ensure_ascii=False)
                f.write("\n")
    else:
        with output_path.open("w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)


def export_qa_jsonl(pairs: Iterable[dict], output_path: Path, options: Dict) -> None:
    """Plain QA JSONL export for debugging."""
    with output_path.open("w", encoding="utf-8") as f:
        for pair in pairs:
            json.dump(pair, f, ensure_ascii=False)
            f.write("\n")


__all__ = ["export_qa_openai", "export_qa_gemini", "export_qa_jsonl"]
