"""Gemini dataset exporters."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

DEFAULT_SYSTEM_PROMPT = "You are a helpful coding assistant. Generate code based on the given instruction."


def _build_entry(record: dict, system_prompt: str) -> dict:
    return {
        "systemInstruction": {
            "role": "system",
            "parts": [{"text": system_prompt}],
        },
        "contents": [
            {
                "role": "user",
                "parts": [{"text": record["instruction"]}],
            },
            {
                "role": "model",
                "parts": [{"text": record["output"]}],
            },
        ],
        "metadata": record.get("metadata"),
    }


def export_gemini(
    records: List[dict],
    output_path: Path,
    options: Dict,
) -> None:
    system_prompt = options.get("system_prompt", DEFAULT_SYSTEM_PROMPT)
    as_jsonl = options.get("jsonl", output_path.suffix == ".jsonl")

    if as_jsonl:
        with output_path.open("w", encoding="utf-8") as f:
            for record in records:
                json.dump(_build_entry(record, system_prompt), f, ensure_ascii=False)
                f.write("\n")
    else:
        data = [_build_entry(record, system_prompt) for record in records]
        with output_path.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
