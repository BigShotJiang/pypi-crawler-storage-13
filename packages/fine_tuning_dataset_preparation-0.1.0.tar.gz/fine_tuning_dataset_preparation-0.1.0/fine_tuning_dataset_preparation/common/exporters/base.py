"""Shared helpers for exporters."""

from __future__ import annotations

import json
from pathlib import Path
from typing import List


def load_jsonl(path: Path) -> List[dict]:
    """Load JSONL records from disk."""
    records: List[dict] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            records.append(json.loads(line))
    return records


__all__ = ["load_jsonl"]
