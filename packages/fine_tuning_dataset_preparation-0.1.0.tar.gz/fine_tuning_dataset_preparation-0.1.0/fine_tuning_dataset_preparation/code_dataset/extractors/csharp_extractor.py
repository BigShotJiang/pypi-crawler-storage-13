"""Tree-sitter based extractor for C# code."""

from __future__ import annotations

from typing import List

from tree_sitter import Language, Parser
from tree_sitter_c_sharp import language as ts_csharp_language

from .base import LanguageExtractor, Snippet, register_extractor

CS_LANGUAGE = Language(ts_csharp_language())
CS_PARSER = Parser(CS_LANGUAGE)


class CSharpExtractor(LanguageExtractor):
    language = "csharp"
    extensions = (".cs",)

    NODE_ELEMENT_MAP = {
        "class_declaration": "class",
        "struct_declaration": "struct",
        "interface_declaration": "interface",
        "enum_declaration": "enum",
        "record_declaration": "record",
        "record_struct_declaration": "record",
        "method_declaration": "function",
        "constructor_declaration": "function",
        "property_declaration": "property",
    }

    def extract(self, file_path: str, code: str) -> List[Snippet]:
        tree = CS_PARSER.parse(code.encode())
        root = tree.root_node
        snippets: List[Snippet] = []

        def node_text(node):
            return code[node.start_byte : node.end_byte]

        def get_name(node):
            for field in ("name", "identifier"):
                child = node.child_by_field_name(field)
                if child:
                    return node_text(child).strip()
            for child in node.children:
                if child.type in ("identifier", "type_identifier"):
                    return node_text(child).strip()
            return "anonymous"

        def traverse(node):
            element_type = self.NODE_ELEMENT_MAP.get(node.type)
            if element_type:
                snippets.append(
                    Snippet(
                        name=get_name(node),
                        element_type=element_type,
                        code=node_text(node).strip(),
                        path=file_path,
                        language=self.language,
                    )
                )
            for child in node.children:
                traverse(child)

        traverse(root)

        if not snippets:
            snippets.append(
                Snippet(
                    name="module",
                    element_type="module",
                    code=code.strip(),
                    path=file_path,
                    language=self.language,
                )
            )
        return snippets


register_extractor(CSharpExtractor)

__all__ = ["CSharpExtractor"]
