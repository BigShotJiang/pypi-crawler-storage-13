"""Tree-sitter based extractor for Go code."""

from __future__ import annotations

from typing import List

from tree_sitter import Language, Parser
from tree_sitter_go import language as ts_go_language

from .base import LanguageExtractor, Snippet, register_extractor

GO_LANGUAGE = Language(ts_go_language())
GO_PARSER = Parser(GO_LANGUAGE)


class GoExtractor(LanguageExtractor):
    language = "go"
    extensions = (".go",)

    def extract(self, file_path: str, code: str) -> List[Snippet]:
        tree = GO_PARSER.parse(code.encode())
        root = tree.root_node
        snippets: List[Snippet] = []

        def node_text(node):
            return code[node.start_byte : node.end_byte]

        def add_snippet(name: str, element_type: str, node):
            snippets.append(
                Snippet(
                    name=name or "anonymous",
                    element_type=element_type,
                    code=node_text(node).strip(),
                    path=file_path,
                    language=self.language,
                )
            )

        def get_name(node, field="name"):
            child = node.child_by_field_name(field)
            if child:
                return node_text(child).strip()
            return "anonymous"

        def traverse(node):
            if node.type == "function_declaration":
                add_snippet(get_name(node), "function", node)
            elif node.type == "method_declaration":
                add_snippet(get_name(node), "function", node)
            elif node.type == "type_declaration":
                for child in node.children:
                    if child.type == "type_spec":
                        name = get_name(child)
                        add_snippet(name, "type", child)
                    traverse(child)
            else:
                for child in node.children:
                    traverse(child)

        traverse(root)

        if not snippets:
            snippets.append(
                Snippet(
                    name="module",
                    element_type="module",
                    code=code.strip(),
                    path=file_path,
                    language=self.language,
                )
            )
        return snippets


register_extractor(GoExtractor)

__all__ = ["GoExtractor"]
