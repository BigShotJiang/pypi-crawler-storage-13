"""Tree-sitter based extractor for Python code."""

from __future__ import annotations

from typing import List

from tree_sitter import Language, Parser
from tree_sitter_python import language as ts_python_language

from .base import LanguageExtractor, Snippet, register_extractor

PY_LANGUAGE = Language(ts_python_language())
PY_PARSER = Parser(PY_LANGUAGE)


class PythonExtractor(LanguageExtractor):
    language = "python"
    extensions = (".py",)

    def extract(self, file_path: str, code: str) -> List[Snippet]:
        tree = PY_PARSER.parse(code.encode())
        root = tree.root_node
        snippets: List[Snippet] = []

        def traverse(node):
            if node.type in ("function_definition", "class_definition"):
                start, end = node.start_byte, node.end_byte
                snippet_code = code[start:end]
                name_node = next((child for child in node.children if child.type == "identifier"), None)
                name = code[name_node.start_byte:name_node.end_byte] if name_node else "unknown"
                element_type = "function" if node.type == "function_definition" else "class"
                snippets.append(
                    Snippet(
                        name=name,
                        element_type=element_type,
                        code=snippet_code.strip(),
                        path=file_path,
                        language=self.language,
                    )
                )
            for child in node.children:
                traverse(child)

        traverse(root)
        if not snippets:
            snippets.append(
                Snippet(
                    name="module",
                    element_type="module",
                    code=code.strip(),
                    path=file_path,
                    language=self.language,
                )
            )
        return snippets


register_extractor(PythonExtractor)

__all__ = ["PythonExtractor"]
