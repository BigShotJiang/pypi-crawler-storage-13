"""Tree-sitter based extractors for JavaScript and TypeScript."""

from __future__ import annotations

from typing import Iterable, List

from tree_sitter import Language, Parser
from tree_sitter_javascript import language as ts_javascript_language
from tree_sitter_typescript import language_typescript, language_tsx

from .base import LanguageExtractor, Snippet, register_extractor

JS_LANGUAGE = Language(ts_javascript_language())
JS_PARSER = Parser(JS_LANGUAGE)

TS_LANGUAGE = Language(language_typescript())
TSX_LANGUAGE = Language(language_tsx())
TS_PARSER = Parser(TS_LANGUAGE)
TSX_PARSER = Parser(TSX_LANGUAGE)


def _node_text(code: str, node) -> str:
    return code[node.start_byte : node.end_byte]


def _get_name(code: str, node, fallbacks: Iterable[str] = ("name", "identifier")) -> str:
    for field in fallbacks:
        child = node.child_by_field_name(field)
        if child:
            return _node_text(code, child).strip()
    for child in node.children:
        if child.type in ("identifier", "property_identifier", "type_identifier"):
            return _node_text(code, child).strip()
    return "anonymous"


class _BaseJSExtractor(LanguageExtractor):
    NODE_ELEMENT_MAP = {
        "function_declaration": "function",
        "generator_function_declaration": "function",
        "method_definition": "function",
        "class_declaration": "class",
        "interface_declaration": "interface",
        "type_alias_declaration": "type",
    }

    def _parse(self, file_path: str, code: str):
        raise NotImplementedError

    def extract(self, file_path: str, code: str) -> List[Snippet]:
        tree = self._parse(file_path, code)
        root = tree.root_node
        snippets: List[Snippet] = []

        def traverse(node):
            element_type = self.NODE_ELEMENT_MAP.get(node.type)
            if element_type:
                snippets.append(
                    Snippet(
                        name=_get_name(code, node),
                        element_type=element_type,
                        code=_node_text(code, node).strip(),
                        path=file_path,
                        language=self.language,
                    )
                )
            for child in node.children:
                traverse(child)

        traverse(root)

        if not snippets:
            snippets.append(
                Snippet(
                    name="module",
                    element_type="module",
                    code=code.strip(),
                    path=file_path,
                    language=self.language,
                )
            )
        return snippets


class JavaScriptExtractor(_BaseJSExtractor):
    language = "javascript"
    extensions = (".js", ".jsx")

    def _parse(self, file_path: str, code: str):
        return JS_PARSER.parse(code.encode())


class TypeScriptExtractor(_BaseJSExtractor):
    language = "typescript"
    extensions = (".ts", ".tsx")

    def _parse(self, file_path: str, code: str):
        lower = file_path.lower()
        parser = TSX_PARSER if lower.endswith(".tsx") else TS_PARSER
        return parser.parse(code.encode())


register_extractor(JavaScriptExtractor)
register_extractor(TypeScriptExtractor)

__all__ = ["JavaScriptExtractor", "TypeScriptExtractor"]
