"""Abstractions for language-specific snippet extraction."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Type


@dataclass
class Snippet:
    name: str
    element_type: str
    code: str
    path: str
    language: str
    module: Optional[str] = None
    parent: Optional[str] = None
    signature: Optional[str] = None
    docstring: Optional[str] = None
    tags: Dict[str, Any] = field(default_factory=dict)


class LanguageExtractor(ABC):
    language: str = "generic"
    extensions: tuple[str, ...] = ()

    def supports_extension(self, suffix: str) -> bool:
        normalized = suffix.lower()
        return normalized in {ext.lower() for ext in self.extensions}

    @abstractmethod
    def extract(self, file_path: str, code: str) -> List[Snippet]:
        ...


_EXTRACTORS_BY_LANGUAGE: Dict[str, LanguageExtractor] = {}
_EXTRACTORS_BY_EXTENSION: Dict[str, LanguageExtractor] = {}


def register_extractor(extractor_cls: Type[LanguageExtractor]) -> None:
    instance = extractor_cls()
    _EXTRACTORS_BY_LANGUAGE[instance.language.lower()] = instance
    for ext in instance.extensions:
        _EXTRACTORS_BY_EXTENSION[ext.lower()] = instance


def get_extractor(language: str | None, suffix: str | None) -> LanguageExtractor | None:
    if language:
        extractor = _EXTRACTORS_BY_LANGUAGE.get(language.lower())
        if extractor:
            return extractor
    if suffix:
        extractor = _EXTRACTORS_BY_EXTENSION.get(suffix.lower())
        if extractor:
            return extractor
    return None


__all__ = ["Snippet", "LanguageExtractor", "register_extractor", "get_extractor"]
