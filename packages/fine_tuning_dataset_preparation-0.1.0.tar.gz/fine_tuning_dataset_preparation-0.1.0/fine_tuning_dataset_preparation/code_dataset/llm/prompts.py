"""Centralized prompt templates used by the LLM helpers."""

from __future__ import annotations

from typing import Any, Iterable, Optional

ChatPromptTemplate = None

try:
    from langchain.prompts import ChatPromptTemplate as _ChatPromptTemplate  # type: ignore[assignment]

    ChatPromptTemplate = _ChatPromptTemplate
except ImportError:
    try:
        from langchain_core.prompts import ChatPromptTemplate as _ChatPromptTemplate  # type: ignore[assignment]

        ChatPromptTemplate = _ChatPromptTemplate
    except ImportError:
        pass


def _build_prompt(messages: Iterable[Any]) -> Optional["ChatPromptTemplate"]:
    if ChatPromptTemplate is None:
        return None
    return ChatPromptTemplate.from_messages(list(messages))


INSTRUCTION_PROMPT = _build_prompt(
    [
        (
            "system",
            (
                "You help collect training datasets for code. "
                "Formulate concise instructions in English that encourage implementing "
                "the specified code element in the style of the specified repository. "
                "Don't mention that you're a model, and don't add explanations — only the instruction."
            ),
        ),
        (
            "human",
                (
                    "Repository: {repo_name}\n"
                    "Element type: {element_type}\n"
                    "Name: {element_name}\n"
                    "Language: {language}\n"
                    "Style hint: {instruction_hint}\n"
                    "Source code:\n```{language}\n{code}\n```\n"
                    "Formulate an instruction for the model to implement this element."
                ),
        ),
    ]
)


PARAPHRASE_PROMPT = _build_prompt(
    [
        (
            "system",
            (
                "You rewrite coding dataset instructions. Preserve the technical intent, "
                "keep them imperative, and stay in English. Avoid redundant filler and respond with a single sentence."
            ),
        ),
        (
            "human",
                (
                    "Repository: {repo_name}\n"
                    "Original instruction: {instruction}\n"
                    "Language: {language}\n"
                    "Style hint: {paraphrase_hint}\n"
                    "Code snippet:\n```{language}\n{code}\n```\n"
                    "Rewrite or paraphrase the instruction so it looks different but keeps the same goal."
                ),
        ),
    ]
)


__all__ = ["INSTRUCTION_PROMPT", "PARAPHRASE_PROMPT"]
