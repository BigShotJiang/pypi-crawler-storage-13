"""Utility helpers for interacting with Gemini via LangChain."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ...common.llm import LLMProvider, build_llm, extract_text_from_llm_message
from .prompts import INSTRUCTION_PROMPT, PARAPHRASE_PROMPT


@dataclass
class PromptConfig:
    instruction_hint: str = (
        "Keep the instruction concise, imperative, and aligned with the repository's coding style."
    )
    paraphrase_hint: str = (
        "Keep the paraphrased instruction single-sentence, imperative, and true to the original intent."
    )


async def _generate_batch_async(messages_list: List[Any], llm, concurrency: int = 64) -> List[str]:
    if hasattr(llm, "abatch"):
        try:
            responses = await llm.abatch(messages_list, config={"max_concurrency": concurrency})
            return [extract_text_from_llm_message(r) for r in responses]
        except (ConnectionError, TimeoutError, ValueError) as batch_error:  # pragma: no cover
            print(f"Batch processing failed: {batch_error}, falling back to individual processing")

    semaphore = asyncio.Semaphore(concurrency)

    async def process(messages):
        async with semaphore:
            response = await llm.ainvoke(messages)
            return extract_text_from_llm_message(response)

    tasks = [asyncio.create_task(process(messages)) for messages in messages_list]
    return await asyncio.gather(*tasks)


async def generate_instruction_texts_async(
    snippets_meta: List[Dict[str, Any]],
    repo_name: str,
    llm,
    concurrency: int = 64,
    prompt_config: Optional[PromptConfig] = None,
) -> List[str]:
    config = prompt_config or PromptConfig()
    if INSTRUCTION_PROMPT is None or llm is None:
        raise RuntimeError("Instruction prompt or LLM is unavailable.")
    messages_list = [
        INSTRUCTION_PROMPT.format_messages(
            repo_name=repo_name,
            element_type=snippet["element_type"],
            element_name=snippet["name"],
            code=snippet["code"],
            language=snippet.get("language", "plaintext"),
            instruction_hint=config.instruction_hint,
        )
        for snippet in snippets_meta
    ]
    return await _generate_batch_async(messages_list, llm, concurrency)


async def paraphrase_instructions_async(
    requests: List[Dict[str, Any]],
    llm,
    concurrency: int = 32,
    prompt_config: Optional[PromptConfig] = None,
) -> List[str]:
    config = prompt_config or PromptConfig()
    if PARAPHRASE_PROMPT is None or llm is None:
        raise RuntimeError("Paraphrase prompt or LLM is unavailable.")
    messages_list = [
        PARAPHRASE_PROMPT.format_messages(
            repo_name=req.get("repo_name", "unknown"),
            instruction=req["instruction"],
            code=req.get("code", ""),
            language=req.get("language", "plaintext"),
            paraphrase_hint=config.paraphrase_hint,
        )
        for req in requests
    ]
    return await _generate_batch_async(messages_list, llm, concurrency)


__all__ = [
    "PromptConfig",
    "LLMProvider",
    "build_llm",
    "generate_instruction_texts_async",
    "paraphrase_instructions_async",
]
