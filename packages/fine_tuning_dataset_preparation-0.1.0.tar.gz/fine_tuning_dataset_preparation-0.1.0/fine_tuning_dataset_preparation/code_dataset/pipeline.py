"""High-level helper that orchestrates extraction and paraphrasing."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from .dataset.builder import extract_code_samples
from .augmentation.paraphraser import augment_instructions
from ..common.exporters import export_dataset
from .llm.service import PromptConfig


def code_pipeline(
    *,
    project_path: str | Path,
    multi_project: bool = True,
    repo_name: Optional[str] = None,
    dataset_path: str | Path = "dataset.jsonl",
    skip_extraction: bool = False,
    instruction_concurrency: int = 8,
    model_name: str = "gemini-2.5-flash",
    instruction_temperature: float = 0.7,
    llm_provider: str = "gemini",
    llm_options: Optional[dict] = None,
    paraphrase_variations: int = 0,
    paraphrase_temperature: float = 0.9,
    paraphrase_output: str | Path = "dataset_with_paraphrases.jsonl",
    language: str = "auto",
    prompt_config: PromptConfig | None = None,
    exports: Optional[List[Dict[str, Any]]] = None,
) -> None:
    dataset_path = Path(dataset_path)
    paraphrase_output = Path(paraphrase_output)
    final_dataset_path = dataset_path

    if not skip_extraction:
        extract_code_samples(
            project_path=str(project_path),
            repo_name=repo_name,
            output_path=str(dataset_path),
            instruction_concurrency=instruction_concurrency,
            process_subdirectories=multi_project,
            llm_model_name=model_name,
            llm_temperature=instruction_temperature,
            language=language,
            prompt_config=prompt_config,
            llm_provider=llm_provider,
            llm_options=llm_options,
        )
    elif not dataset_path.exists():
        raise FileNotFoundError(
            f"skip_extraction=True, but dataset '{dataset_path}' does not exist."
        )

    if paraphrase_variations > 0:
        augment_instructions(
            input_path=dataset_path,
            output_path=paraphrase_output,
            variations=paraphrase_variations,
            concurrency=max(1, instruction_concurrency // 2),
            model_name=model_name,
            temperature=paraphrase_temperature,
            prompt_config=prompt_config,
            llm_provider=llm_provider,
            llm_options=llm_options,
        )
        final_dataset_path = paraphrase_output
    else:
        print("Paraphrasing skipped (set paraphrase_variations > 0 to enable).")

    if exports:
        for export_config in exports:
            target = export_config.get("target")
            output_path = export_config.get("output_path")
            if not target or not output_path:
                raise ValueError("Each export configuration must include 'target' and 'output_path'.")
            options = export_config.get("options", {})
            export_dataset(final_dataset_path, output_path, target=target, **options)


__all__ = ["code_pipeline"]
