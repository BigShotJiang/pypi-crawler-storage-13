"""Library entry point for adding paraphrased instruction variants."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, Dict, List

from ..llm.prompts import PARAPHRASE_PROMPT
from ..llm.service import LLMProvider, PromptConfig, build_llm, paraphrase_instructions_async


def load_jsonl(path: Path) -> List[Dict]:
    data: List[Dict] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            data.append(json.loads(line))
    return data


def save_jsonl(path: Path, data: List[Dict]) -> None:
    with path.open("w", encoding="utf-8") as f:
        for item in data:
            json.dump(item, f, ensure_ascii=False)
            f.write("\n")


def augment_instructions(
    input_path: Path,
    output_path: Path,
    *,
    variations: int = 1,
    concurrency: int = 16,
    model_name: str = "gemini-2.5-flash",
    temperature: float = 0.9,
    prompt_config: PromptConfig | None = None,
    llm_provider: str | LLMProvider = LLMProvider.GEMINI,
    llm_options: Dict[str, Any] | None = None,
) -> None:
    data = load_jsonl(input_path)
    if not data:
        print("No samples found to paraphrase.")
        return

    if PARAPHRASE_PROMPT is None:
        print("Paraphrase prompt unavailable (missing langchain). Cannot augment dataset.")
        return

    llm = build_llm(
        provider=llm_provider,
        model_name=model_name,
        temperature=temperature,
        **(llm_options or {}),
    )
    if llm is None:
        print("LLM unavailable. Ensure langchain-google-genai is installed and GOOGLE_API_KEY is set.")
        return

    requests: List[Dict] = []
    for idx, item in enumerate(data):
        for _ in range(variations):
            requests.append(
                {
                    "index": idx,
                    "instruction": item["instruction"],
                    "code": item.get("output", ""),
                    "repo_name": item.get("metadata", {}).get("repo_name", "unknown"),
                    "language": item.get("metadata", {}).get("language", "plaintext"),
                }
            )

    if not requests:
        print("No paraphrase requests generated.")
        return

    responses = asyncio.run(
        paraphrase_instructions_async(
            requests,
            llm,
            concurrency=concurrency,
            prompt_config=prompt_config,
        )
    )

    for request, paraphrased in zip(requests, responses):
        entry = data[request["index"]]
        alternate = entry.setdefault("alternate_instructions", [])
        if not isinstance(alternate, list):
            alternate = entry["alternate_instructions"] = []

        paraphrased_clean = paraphrased.strip()
        if not paraphrased_clean:
            continue
        if paraphrased_clean == entry["instruction"]:
            continue
        if paraphrased_clean in alternate:
            continue
        alternate.append(paraphrased_clean)

    save_jsonl(output_path, data)
    print(
        f"Augmented dataset saved to {output_path} "
        f"({len(data)} samples, {variations} paraphrases per sample)."
    )


__all__ = ["augment_instructions", "load_jsonl", "save_jsonl"]
