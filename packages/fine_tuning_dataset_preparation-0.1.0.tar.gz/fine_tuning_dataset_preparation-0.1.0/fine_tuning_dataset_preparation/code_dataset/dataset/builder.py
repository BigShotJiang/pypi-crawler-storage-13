"""Dataset building utilities with pluggable language extractors."""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Tuple, Set

import chardet

from ..extractors import base  # register base
from ..extractors import python_extractor  # noqa: F401
from ..extractors import csharp_extractor  # noqa: F401
from ..extractors import go_extractor  # noqa: F401
from ..extractors import javascript_extractor  # noqa: F401
from ..llm.prompts import INSTRUCTION_PROMPT
from ..llm.service import LLMProvider, PromptConfig, build_llm, generate_instruction_texts_async

SUPPORTED_EXTENSIONS = {
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".java",
    ".go",
    ".cs",
    ".cpp",
    ".cxx",
    ".cc",
    ".hpp",
    ".h",
    ".rs",
    ".rb",
    ".php",
    ".swift",
    ".kt",
    ".kts",
    ".scala",
    ".m",
    ".mm",
    ".ps1",
    ".sh",
    ".lua",
    ".pl",
    ".sql",
    ".r",
}


def read_file_safely(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    enc = chardet.detect(raw)["encoding"] or "utf-8"
    try:
        return raw.decode(enc)
    except (UnicodeDecodeError, LookupError):
        return raw.decode("utf-8", errors="ignore")


def detect_language_from_extension(path: str) -> str:
    _, ext = os.path.splitext(path)
    if ext.lower() == ".py":
        return "python"
    if ext.lower() in {".js", ".jsx"}:
        return "javascript"
    if ext.lower() in {".ts", ".tsx"}:
        return "typescript"
    if ext.lower() in {".java"}:
        return "java"
    if ext.lower() in {".go"}:
        return "go"
    if ext.lower() in {".cs"}:
        return "csharp"
    if ext.lower() in {".cpp", ".cxx", ".cc", ".hpp", ".h"}:
        return "cpp"
    if ext.lower() in {".rs"}:
        return "rust"
    if ext.lower() in {".rb"}:
        return "ruby"
    if ext.lower() in {".php"}:
        return "php"
    if ext.lower() in {".swift"}:
        return "swift"
    if ext.lower() in {".kt", ".kts"}:
        return "kotlin"
    return "generic"


def extract_code_samples(
    project_path: str,
    repo_name: str | None = None,
    output_path: str = "dataset.jsonl",
    instruction_concurrency: int = 8,
    process_subdirectories: bool = False,
    llm_model_name: str = "gemini-2.5-flash",
    llm_temperature: float = 0.7,
    language: str = "auto",
    prompt_config: PromptConfig | None = None,
    llm_provider: str | LLMProvider = LLMProvider.GEMINI,
    llm_options: Dict[str, Any] | None = None,
) -> List[Dict[str, str]]:
    if process_subdirectories:
        return _process_multiple_projects(
            project_path,
            output_path,
            instruction_concurrency,
            llm_model_name,
            llm_temperature,
            language,
            prompt_config,
            llm_provider,
            llm_options,
        )

    if repo_name is None:
        repo_name = os.path.basename(os.path.abspath(project_path))

    data = _process_single_project(
        project_path,
        repo_name,
        instruction_concurrency,
        llm_model_name,
        llm_temperature,
        language,
        prompt_config,
        llm_provider,
        llm_options,
    )
    _write_jsonl(output_path, data)
    print(f"Dataset saved: {output_path} ({len(data)} examples)")
    return data


def _process_multiple_projects(
    base_path: str,
    output_path: str,
    instruction_concurrency: int,
    llm_model_name: str,
    llm_temperature: float,
    language: str,
    prompt_config: PromptConfig | None = None,
    llm_provider: str | LLMProvider = LLMProvider.GEMINI,
    llm_options: Dict[str, Any] | None = None,
) -> List[Dict[str, str]]:
    all_data: List[Dict[str, str]] = []
    base_path_obj = Path(base_path)

    if not base_path_obj.exists():
        print(f"Path does not exist: {base_path}")
        return []

    subdirs = [d for d in base_path_obj.iterdir() if d.is_dir()]

    if not subdirs:
        print(f"No subdirectories found in {base_path}")
        return []

    print(f"Found {len(subdirs)} subdirectories to process:")
    for subdir in subdirs:
        print(f"  - {subdir.name}")

    project_stats: List[Tuple[str, int]] = []
    for subdir in subdirs:
        print(f"\nProcessing: {subdir.name}")
        subdir_data = _process_single_project(
            str(subdir),
            subdir.name,
            instruction_concurrency,
            llm_model_name,
            llm_temperature,
            language,
            prompt_config,
            llm_provider,
            llm_options,
        )
        all_data.extend(subdir_data)
        project_stats.append((subdir.name, len(subdir_data)))
        print(f"  Added {len(subdir_data)} examples from {subdir.name}")

    _write_jsonl(output_path, all_data)

    print(f"\nSaved {len(all_data)} examples to {output_path}")
    print("\nProject breakdown:")
    for project_name, count in sorted(project_stats, key=lambda x: x[1], reverse=True):
        print(f"{project_name}: {count}")

    return all_data


def _write_jsonl(output_path: str, dataset: List[Dict[str, str]]) -> None:
    with open(output_path, "w", encoding="utf-8") as f:
        for item in dataset:
            json.dump(item, f, ensure_ascii=False)
            f.write("\n")


def _process_single_project(
    project_path: str,
    repo_name: str,
    instruction_concurrency: int,
    llm_model_name: str,
    llm_temperature: float,
    language: str,
    prompt_config: PromptConfig | None = None,
    llm_provider: str | LLMProvider = LLMProvider.GEMINI,
    llm_options: Dict[str, Any] | None = None,
) -> List[Dict[str, str]]:
    data: List[Dict[str, str]] = []
    snippets_meta: List[Dict[str, str]] = []
    llm = None

    if INSTRUCTION_PROMPT is not None:
        llm = build_llm(
            provider=llm_provider,
            model_name=llm_model_name,
            temperature=llm_temperature,
            **(llm_options or {}),
        )
    else:
        print("Instruction prompt unavailable (missing langchain). Using standard instructions.")

    if llm is None:
        print(
            "LLM for instructions unavailable (check langchain-google-genai and GOOGLE_API_KEY). "
            "Using standard instructions."
        )

    unsupported_logged: Set[str] = set()

    project_root = os.path.abspath(project_path)

    for root, _, files in os.walk(project_path):
        for file in files:
            full_path = os.path.join(root, file)
            _, ext = os.path.splitext(full_path)
            if language == "auto" and ext and ext.lower() not in SUPPORTED_EXTENSIONS:
                continue
            detected_language = language if language != "auto" else detect_language_from_extension(full_path)
            extractor = base.get_extractor(detected_language, ext)
            if extractor is None:
                key = f"{detected_language}:{ext.lower()}"
                if key not in unsupported_logged:
                    print(
                        f"Skipping '{full_path}': no extractor registered for language '{detected_language}' "
                        f"(extension '{ext}')."
                    )
                    unsupported_logged.add(key)
                continue
            code = read_file_safely(full_path)
            snippets = extractor.extract(full_path, code)

            for snippet in snippets:
                metadata = _build_snippet_metadata(
                    snippet=snippet,
                    repo_name=repo_name,
                    project_root=project_root,
                )
                snippets_meta.append(
                    {
                        "name": snippet.name,
                        "element_type": snippet.element_type,
                        "code": snippet.code,
                        "path": snippet.path,
                        "language": snippet.language if snippet.language != "generic" else detected_language,
                        "metadata": metadata,
                    }
                )

    if snippets_meta:
        if llm:
            instructions = asyncio.run(
                generate_instruction_texts_async(
                    snippets_meta,
                    repo_name,
                    llm,
                    concurrency=instruction_concurrency,
                    prompt_config=prompt_config,
                )
            )
        else:
            instructions = [
                f"Implement {snippet['element_type']} '{snippet['name']}' in the style of repository '{repo_name}'."
                for snippet in snippets_meta
            ]

        for snippet, instruction in zip(snippets_meta, instructions):
            data.append(
                {
                    "instruction": instruction,
                    "output": snippet["code"],
                    "metadata": snippet["metadata"],
                }
            )

    return data


def _build_snippet_metadata(
    *,
    snippet: base.Snippet,
    repo_name: str,
    project_root: str,
) -> Dict[str, object]:
    relative_path = os.path.relpath(snippet.path, project_root)
    line_count = snippet.code.count("\n") + 1 if snippet.code else 0
    char_count = len(snippet.code)
    metadata: Dict[str, object] = {
        "repo_name": repo_name,
        "element_type": snippet.element_type,
        "name": snippet.name,
        "path": snippet.path,
        "relative_path": relative_path,
        "language": snippet.language,
        "line_count": line_count,
        "char_count": char_count,
    }
    if snippet.module:
        metadata["module"] = snippet.module
    if snippet.parent:
        metadata["parent"] = snippet.parent
    if snippet.signature:
        metadata["signature"] = snippet.signature
    if snippet.docstring:
        metadata["docstring"] = snippet.docstring
    if snippet.tags:
        metadata["tags"] = snippet.tags
    return metadata
