"""Pipeline entrypoint for documentation-based Q/A dataset generation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Optional

from ..code_dataset.llm.service import LLMProvider
from ..common.exporters import export_dataset
from .dataset.builder import (
    DocumentPromptConfig,
    generate_dataset_from_documents,
    generate_dataset_from_markdown,
)


def run_document_pipeline(
    *,
    markdown_path: str | Path = "",
    markdown_dir: str | Path | None = None,
    markdown_paths: Optional[list[str | Path]] = None,
    output_path: str | Path = "document_dataset.json",
    doc_name: Optional[str] = None,
    concurrency: int = 32,
    min_total_pairs: int = 1,
    model_name: str = "gemini-2.5-pro",
    temperature: float = 1.0,
    llm_provider: str | LLMProvider = LLMProvider.GEMINI,
    llm_options: Optional[Dict[str, object]] = None,
    prompt_config: Optional[DocumentPromptConfig] = None,
    exports: Optional[list[Dict[str, object]]] = None,
) -> None:
    """
    High-level helper that wraps Markdown ingestion, LLM calls, and persistence.
    """
    if markdown_dir is not None:
        base = Path(markdown_dir)
        files = sorted([p for p in base.glob("**/*.md") if p.is_file()])
        if not files:
            raise FileNotFoundError(f"No markdown files found in directory: {markdown_dir}")
        dataset = generate_dataset_from_documents(
            files,
            concurrency=concurrency,
            min_total_pairs=min_total_pairs,
            model_name=model_name,
            temperature=temperature,
            llm_provider=llm_provider,
            llm_options=llm_options,
            prompt_config=prompt_config,
        )
    elif markdown_paths:
        dataset = generate_dataset_from_documents(
            markdown_paths,
            concurrency=concurrency,
            min_total_pairs=min_total_pairs,
            model_name=model_name,
            temperature=temperature,
            llm_provider=llm_provider,
            llm_options=llm_options,
            prompt_config=prompt_config,
        )
    else:
        if not markdown_path:
            raise ValueError("Provide either markdown_path, markdown_dir, or markdown_paths.")
        dataset = generate_dataset_from_markdown(
            markdown_path=markdown_path,
            doc_name=doc_name,
            concurrency=concurrency,
            min_total_pairs=min_total_pairs,
            model_name=model_name,
            temperature=temperature,
            llm_provider=llm_provider,
            llm_options=llm_options,
            prompt_config=prompt_config,
        )

    output_path = Path(output_path)
    output_path.write_text(json.dumps(dataset, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Saved {dataset['coverage']['total_pairs']} Q/A pairs to {output_path}")
    if exports:
        pairs_jsonl = output_path.with_suffix(".pairs.jsonl")
        with pairs_jsonl.open("w", encoding="utf-8") as f:
            for pair in dataset.get("pairs", []):
                json.dump(pair, f, ensure_ascii=False)
                f.write("\n")
        for export_conf in exports:
            target = export_conf.get("target")
            dest = export_conf.get("output_path")
            options = export_conf.get("options", {})
            if not target or not dest:
                raise ValueError("Each export configuration must include 'target' and 'output_path'.")
            export_dataset(pairs_jsonl, dest, target=target, **options)
        print("Additional exports completed.")


__all__ = ["run_document_pipeline"]
