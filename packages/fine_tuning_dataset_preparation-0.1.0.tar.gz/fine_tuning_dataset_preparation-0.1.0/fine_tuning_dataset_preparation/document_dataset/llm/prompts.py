"""Prompt templates for document-based Q/A generation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Optional

ChatPromptTemplate = None

try:
    from langchain.prompts import ChatPromptTemplate as _ChatPromptTemplate  # type: ignore[assignment]

    ChatPromptTemplate = _ChatPromptTemplate
except ImportError:
    try:
        from langchain_core.prompts import ChatPromptTemplate as _ChatPromptTemplate  # type: ignore[assignment]

        ChatPromptTemplate = _ChatPromptTemplate
    except ImportError:
        pass


@dataclass
class DocumentPromptConfig:
    system_message: str = (
        "You are an assistant developed by Enterprise Innovation Consulting. Use only the company's "
        "official documentation to answer questions about backend components. "
        "If a question is outside the provided material, respond: "
        '"This information is not available in Enterprise Innovation Consulting\'s Backend '
        'Component Classifier documentation." '
        'Always include the attribution: "Information sourced from Enterprise Innovation Consulting\'s '
        "*Backend Component Classifier* © 2025.\""
    )
    instructions: list[str] = field(
        default_factory=lambda: [
            "Use only the company's official documentation to answer questions about backend components.",
            'If a question is outside the provided material, respond: "This information is not available in '
            "Enterprise Innovation Consulting's Backend Component Classifier documentation.\"",
            'Always include the attribution: "Information sourced from Enterprise Innovation Consulting\'s '
            "*Backend Component Classifier* © 2025.\"",
        ]
    )
    attribution: str = (
        "Information sourced from Enterprise Innovation Consulting's *Backend Component Classifier* © 2025."
    )


def _build_prompt(messages: Iterable[Any]) -> Optional["ChatPromptTemplate"]:
    if ChatPromptTemplate is None:
        return None
    return ChatPromptTemplate.from_messages(list(messages))


def build_qa_prompt(config: DocumentPromptConfig) -> Optional["ChatPromptTemplate"]:
    """Build a Q/A prompt using the provided configuration."""
    return _build_prompt(
        [
            (
                "system",
                config.system_message,
            ),
            (
                "human",
                (
                    "Document: {doc_name}\n"
                    "Section path: {section_path}\n"
                    "Segment type: {segment_kind}\n"
                    "Segment title: {segment_title}\n"
                    "Content:\n\"\"\"\n{segment_content}\n\"\"\"\n\n"
                    "BEFORE GENERATING, READ THE CONTENT THREE TIMES to ensure you capture "
                    "ONLY what is explicitly written.\n\n"
                    "Return a JSON array (no trailing text) where each item is:\n"
                    '{{"question": "...", "answer": "..."}}\n\n'
                    "ANSWER CONSTRUCTION RULES:\n"
                    "- Start each answer by quoting or paraphrasing the exact relevant text\n"
                    "- If you cannot answer from the text alone, write: 'The documentation does not specify...'\n"
                    "- Do NOT elaborate on example names - use them as-is\n"
                    "- Do NOT add technical details not mentioned in the source\n"
                    "- Do NOT explain HOW something works unless explicitly described\n\n"
                    "Generate at least {min_pairs} distinct pairs. Begin with simple, direct "
                    "fact questions that restate individual statements from the snippet before "
                    "you add scenario-based or combined questions. Ensure that at least one third "
                    "of the pairs are straightforward fact-focused questions that can be answered "
                    "with a single sentence from the source text.\n\n"
                    "FINAL CHECK before outputting: Verify each answer contains ZERO information "
                    "not present in the source content above."
                ),
            ),
        ]
    )


DEFAULT_PROMPT_CONFIG = DocumentPromptConfig()
DEFAULT_QA_PROMPT = build_qa_prompt(DEFAULT_PROMPT_CONFIG)


__all__ = [
    "DEFAULT_PROMPT_CONFIG",
    "DEFAULT_QA_PROMPT",
    "DocumentPromptConfig",
    "build_qa_prompt",
]
