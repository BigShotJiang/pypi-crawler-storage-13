"""Q/A dataset builder for documentation sources."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Sequence

from ...common import deduplicate_sentences, extract_text_from_llm_message, normalize_whitespace, strip_code_fence
from ...common.llm import LLMProvider, build_llm
from ..ingestion.markdown import Segment, assign_min_pairs, extract_markdown_segments, read_markdown
from ..llm.prompts import (
    DEFAULT_PROMPT_CONFIG,
    DEFAULT_QA_PROMPT,
    DocumentPromptConfig,
    build_qa_prompt,
)

MIN_TOTAL_PAIRS = 1
MAX_RETRIES_PER_SEGMENT = 3


def _parse_pairs_from_response(text: str) -> List[Dict[str, str]]:
    cleaned = strip_code_fence(text)
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        return []

    if isinstance(data, dict) and "qa_pairs" in data:
        data = data["qa_pairs"]
    if not isinstance(data, list):
        return []

    pairs: List[Dict[str, str]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        question = item.get("question") or item.get("q")
        answer = item.get("answer") or item.get("a")
        if not question or not answer:
            continue
        pairs.append(
            {
                "question": question.strip(),
                "answer": answer.strip(),
            }
        )
    return pairs


def _normalize_pairs(pairs: List[Dict[str, str]]) -> List[Dict[str, str]]:
    normalized: List[Dict[str, str]] = []
    seen_questions: set[str] = set()
    for pair in pairs:
        question = normalize_whitespace(pair.get("question", ""))
        answer = normalize_whitespace(pair.get("answer", ""))
        if not question or not answer:
            continue
        key = question.lower()
        if key in seen_questions:
            continue
        seen_questions.add(key)
        normalized.append(
            {
                "question": question,
                "answer": deduplicate_sentences(answer),
            }
        )
    return normalized


def _ensure_attribution(text: str, attribution: str) -> str:
    stripped = text.strip()
    if stripped.endswith(attribution):
        return stripped
    if stripped.endswith("."):
        return f"{stripped} {attribution}"
    return f"{stripped}. {attribution}"


async def _generate_pairs_async(llm, doc_name: str, segment: Segment, qa_prompt) -> List[Dict[str, str]]:
    if qa_prompt is None:
        raise RuntimeError("QA prompt is unavailable (missing langchain).")
    messages = qa_prompt.format_messages(
        doc_name=doc_name,
        section_path=" > ".join(segment.path) if segment.path else "Document Overview",
        segment_kind=segment.kind,
        segment_title=segment.title,
        segment_content=segment.content,
        min_pairs=segment.min_pairs,
    )
    response = await llm.ainvoke(messages)
    text = extract_text_from_llm_message(response)
    return _parse_pairs_from_response(text)


async def generate_pairs_batch(
    segments: Sequence[Segment],
    doc_name: str,
    llm,
    qa_prompt,
    concurrency: int,
) -> List[List[Dict[str, str]]]:
    """Generate question/answer pairs for each segment with batching when possible."""
    segment_list = list(segments)
    if qa_prompt is None:
        raise RuntimeError("QA prompt is unavailable (missing langchain).")

    if hasattr(llm, "abatch"):
        messages_list = [
            qa_prompt.format_messages(
                doc_name=doc_name,
                section_path=" > ".join(seg.path) if seg.path else "Document Overview",
                segment_kind=seg.kind,
                segment_title=seg.title,
                segment_content=seg.content,
                min_pairs=seg.min_pairs,
            )
            for seg in segment_list
        ]
        try:
            responses = await llm.abatch(messages_list, config={"max_concurrency": concurrency})
            pairs = []
            for response in responses:
                text = extract_text_from_llm_message(response)
                pairs.append(_parse_pairs_from_response(text))
            return pairs
        except (ConnectionError, TimeoutError, ValueError):
            print("Batch generation failed. Falling back to individual requests.")

    semaphore = asyncio.Semaphore(concurrency)

    async def process_segment(seg: Segment) -> List[Dict[str, str]]:
        async with semaphore:
            return await _generate_pairs_async(llm, doc_name, seg, qa_prompt)

    tasks = [asyncio.create_task(process_segment(seg)) for seg in segment_list]
    return await asyncio.gather(*tasks)


def build_dataset_document(
    doc_name: str,
    source_path: str,
    model_name: str,
    segments: Sequence[Segment],
    pairs_per_segment: Sequence[List[Dict[str, str]]],
    *,
    instructions: List[str],
    attribution: str,
) -> Dict[str, object]:
    generated_at = (
        datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    )
    pairs_output: List[Dict[str, object]] = []
    segment_summaries: List[Dict[str, object]] = []
    seen_questions: set[str] = set()

    for segment, pairs in zip(segments, pairs_per_segment):
        segment_count = 0
        for idx, pair in enumerate(pairs, start=1):
            question = pair["question"]
            key = question.lower()
            if key in seen_questions:
                continue
            seen_questions.add(key)
            segment_count += 1
            answer = _ensure_attribution(deduplicate_sentences(pair["answer"]), attribution)
            pair_id = f"{segment.identifier.replace(':', '_')}_{segment_count:03}"
            pairs_output.append(
                {
                    "id": pair_id,
                    "segment_ref": segment.identifier,
                    "segment_kind": segment.kind,
                    "category_path": segment.path,
                    "question": question,
                    "answer": answer,
                }
            )

        segment_summaries.append(
            {
                "segment_ref": segment.identifier,
                "title": segment.title,
                "kind": segment.kind,
                "path": segment.path,
                "pair_count": segment_count,
            }
        )

    coverage = {
        "total_pairs": len(pairs_output),
        "unique_questions": len(seen_questions),
        "segments": len(segments),
        "segments_covered": sum(1 for summary in segment_summaries if summary["pair_count"] > 0),
        "pairs_per_segment": segment_summaries,
    }

    return {
        "document": {
            "name": doc_name,
            "source_path": source_path,
            "generated_at": generated_at,
            "model": model_name,
        },
        "instructions": instructions,
        "pairs": pairs_output,
        "coverage": coverage,
    }


def generate_dataset_from_markdown(
    markdown_path: str | Path,
    *,
    doc_name: Optional[str] = None,
    concurrency: int = 32,
    min_total_pairs: int = MIN_TOTAL_PAIRS,
    model_name: str = "gemini-2.5-pro",
    temperature: float = 1.0,
    llm_provider: str | LLMProvider = LLMProvider.GEMINI,
    llm_options: Optional[Dict[str, object]] = None,
    prompt_config: Optional[DocumentPromptConfig] = None,
) -> Dict[str, object]:
    """
    Build a dataset of exhaustive Q/A pairs derived from a Markdown document.

    Returns the dataset as a Python dict (not written to disk).
    """
    markdown_path = Path(markdown_path)
    if not markdown_path.exists():
        raise FileNotFoundError(f"Markdown file not found: {markdown_path}")

    doc_name = doc_name or markdown_path.stem.replace("_", " ").title()
    markdown_text = read_markdown(markdown_path)
    segments = extract_markdown_segments(markdown_text)

    if not segments:
        raise ValueError("No segments discovered in the Markdown document.")

    assign_min_pairs(segments, min_total_pairs)

    config = prompt_config or DEFAULT_PROMPT_CONFIG
    qa_prompt = build_qa_prompt(config) if prompt_config else DEFAULT_QA_PROMPT

    llm = build_llm(
        provider=llm_provider,
        model_name=model_name,
        temperature=temperature,
        **(llm_options or {}),
    )
    if llm is None:
        raise RuntimeError(
            "LLM for dataset generation unavailable. Install langchain provider and set API key."
        )

    async def _generate_all() -> List[List[Dict[str, str]]]:
        raw_pairs = await generate_pairs_batch(segments, doc_name, llm, qa_prompt, concurrency)
        results: List[List[Dict[str, str]]] = []

        for seg, pairs in zip(segments, raw_pairs):
            attempt = 0
            current_pairs = pairs
            while len(current_pairs) < seg.min_pairs and attempt < MAX_RETRIES_PER_SEGMENT:
                attempt += 1
                print(
                    f"Retrying segment '{seg.title}' ({seg.identifier}) "
                    f"— attempt {attempt}/{MAX_RETRIES_PER_SEGMENT}"
                )
                current_pairs = await _generate_pairs_async(llm, doc_name, seg, qa_prompt)
            results.append(current_pairs)
        return results

    raw_pairs_per_segment = asyncio.run(_generate_all())

    pairs_per_segment: List[List[Dict[str, str]]] = []
    for segment, pairs in zip(segments, raw_pairs_per_segment):
        normalized = _normalize_pairs(pairs)
        if len(normalized) < segment.min_pairs:
            raise ValueError(
                f"LLM returned {len(normalized)} pairs for segment '{segment.title}' "
                f"(expected at least {segment.min_pairs})."
            )
        pairs_per_segment.append(normalized)

    dataset_document = build_dataset_document(
        doc_name=doc_name,
        source_path=str(markdown_path),
        model_name=model_name,
        segments=segments,
        pairs_per_segment=pairs_per_segment,
        instructions=config.instructions,
        attribution=config.attribution,
    )

    return dataset_document


def generate_dataset_from_documents(
    markdown_paths: Sequence[str | Path],
    *,
    concurrency: int = 32,
    min_total_pairs: int = MIN_TOTAL_PAIRS,
    model_name: str = "gemini-2.5-pro",
    temperature: float = 1.0,
    llm_provider: str | LLMProvider = LLMProvider.GEMINI,
    llm_options: Optional[Dict[str, object]] = None,
    prompt_config: Optional[DocumentPromptConfig] = None,
) -> Dict[str, object]:
    """Build a combined dataset from multiple Markdown documents."""
    datasets: List[Dict[str, object]] = []
    for path in markdown_paths:
        markdown_path = Path(path)
        if not markdown_path.exists():
            raise FileNotFoundError(f"Markdown file not found: {markdown_path}")
        datasets.append(
            generate_dataset_from_markdown(
                markdown_path=markdown_path,
                doc_name=None,
                concurrency=concurrency,
                min_total_pairs=min_total_pairs,
                model_name=model_name,
                temperature=temperature,
                llm_provider=llm_provider,
                llm_options=llm_options,
                prompt_config=prompt_config,
            )
        )

    if not datasets:
        raise ValueError("No documents processed. Provide at least one Markdown file.")

    instructions = datasets[0]["instructions"]
    pairs_all: List[Dict[str, object]] = []
    documents_meta: List[Dict[str, object]] = []
    seen_questions: set[str] = set()

    for doc_data in datasets:
        doc_meta = doc_data["document"]
        documents_meta.append(doc_meta)
        for pair in doc_data["pairs"]:
            pair_copy = dict(pair)
            pair_copy["document"] = doc_meta.get("name")
            pairs_all.append(pair_copy)
            seen_questions.add(pair["question"].lower())

    coverage = {
        "total_pairs": len(pairs_all),
        "unique_questions": len(seen_questions),
        "documents": len(datasets),
        "document_breakdown": [
            {
                "name": doc["name"],
                "source_path": doc["source_path"],
            }
            for doc in documents_meta
        ],
    }

    return {
        "documents": documents_meta,
        "instructions": instructions,
        "pairs": pairs_all,
        "coverage": coverage,
    }


__all__ = [
    "generate_dataset_from_markdown",
    "generate_dataset_from_documents",
    "build_dataset_document",
    "generate_pairs_batch",
    "DocumentPromptConfig",
]
