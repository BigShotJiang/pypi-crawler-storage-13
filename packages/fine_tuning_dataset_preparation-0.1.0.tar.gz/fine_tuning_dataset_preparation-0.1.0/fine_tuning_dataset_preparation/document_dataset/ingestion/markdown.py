"""Utilities for splitting Markdown documentation into structured segments."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List
import math

SegmentPath = List[str]


@dataclass
class Segment:
    """Structured representation of a Markdown fragment."""

    identifier: str
    kind: str
    title: str
    path: SegmentPath
    content: str
    extra: Dict[str, str] = field(default_factory=dict)
    min_pairs: int = 0


def read_markdown(path: str | Path) -> str:
    """Read Markdown text from disk."""
    return Path(path).read_text(encoding="utf-8")


def _split_table_line(line: str) -> List[str]:
    stripped = line.strip().strip("|")
    if not stripped:
        return []
    cells = re.split(r"\s*\|\s*", stripped)
    return [cell.strip() for cell in cells]


def _is_table_divider(line: str) -> bool:
    body = line.strip().replace("|", "").replace(" ", "")
    return bool(body) and set(body) <= {":", "-"}


def _split_examples(examples: str | None) -> List[str]:
    """Split example strings like '1. Foo 2. Bar' into structured items."""
    if not examples:
        return []
    parts = re.split(r"\d+\.\s*|\s*[;,]\s*", examples)
    items: List[str] = []
    for part in parts:
        item = part.strip()
        if not item:
            continue
        if item.endswith("."):
            item = item[:-1].strip()
        items.append(item)
    return items


def extract_markdown_segments(markdown_text: str) -> List[Segment]:
    """
    Split Markdown into logical segments:
    - heading-aware paragraphs
    - table rows treated as individual concepts
    """
    lines = markdown_text.splitlines()
    segments: List[Segment] = []
    path: SegmentPath = []
    buffer: List[str] = []

    def current_section_title() -> str:
        return path[-1] if path else "Document Overview"

    def flush_buffer():
        text = "\n".join(buffer).strip()
        buffer.clear()
        if not text:
            return
        identifier = f"paragraph::{len(segments)}"
        segments.append(
            Segment(
                identifier=identifier,
                kind="paragraph",
                title=current_section_title(),
                path=path.copy(),
                content=text,
            )
        )

    i = 0
    while i < len(lines):
        line = lines[i]
        heading_match = re.match(r"^(#{1,6})\s+(.*)", line)
        if heading_match:
            flush_buffer()
            level = len(heading_match.group(1))
            if level > 2:
                level = 2
            title = heading_match.group(2).strip()
            while len(path) >= level:
                path.pop()
            path.append(title)
            i += 1
            continue

        stripped = line.strip()
        next_line = lines[i + 1] if i + 1 < len(lines) else ""

        if stripped.startswith("|") and _is_table_divider(next_line):
            flush_buffer()
            table_lines = [line]
            i += 1
            while i < len(lines) and lines[i].strip().startswith("|"):
                table_lines.append(lines[i])
                i += 1

            if len(table_lines) < 3:
                continue

            headers = _split_table_line(table_lines[0])
            rows = [
                _split_table_line(row_line)
                for row_line in table_lines[2:]
                if _split_table_line(row_line)
            ]

            for index, row_cells in enumerate(rows):
                if len(row_cells) != len(headers):
                    continue
                row_dict = dict(zip(headers, row_cells))
                row_dict["Examples_list"] = _split_examples(row_dict.get("Examples"))
                name = row_dict.get(headers[0], f"Row {index + 1}")
                content_lines = [
                    f"{header}: {row_dict.get(header, '').strip()}"
                    for header in headers
                ]
                identifier = f"table::{len(segments)}::{index}"
                segments.append(
                    Segment(
                        identifier=identifier,
                        kind="table_row",
                        title=name,
                        path=path.copy(),
                        content="\n".join(content_lines).strip(),
                        extra=row_dict,
                    )
                )
            continue

        if stripped:
            buffer.append(line)
        else:
            flush_buffer()
        i += 1

    flush_buffer()
    return segments


def _base_segment_weight(segment: Segment) -> int:
    """Estimate a baseline weight for how many pairs a segment should yield."""
    if segment.kind == "table_row":
        examples = segment.extra.get("Examples_list") or []
        description = segment.extra.get("Description") or segment.content
        desc_sentences = [
            sentence
            for sentence in re.split(r"(?<=[.!?])\s+", description)
            if sentence.strip()
        ]
        return max(6, 4 + len(examples) * 3 + len(desc_sentences))
    sentences = [
        sentence
        for sentence in re.split(r"(?<=[.!?])\s+", segment.content)
        if sentence.strip()
    ]
    non_empty_lines = [line for line in segment.content.splitlines() if line.strip()]
    return max(8, len(sentences) * 3 + len(non_empty_lines))


def assign_min_pairs(segments: List[Segment], target_total: int) -> None:
    """Assign a minimum number of pairs for each segment to hit a global target."""
    if not segments:
        return
    base_weights = [_base_segment_weight(segment) for segment in segments]
    total_base = sum(base_weights)
    if total_base == 0:
        fallback_value = max(target_total // len(segments), 6)
        for segment in segments:
            segment.min_pairs = fallback_value
        return

    factor = max(1.0, target_total / total_base)
    for segment, weight in zip(segments, base_weights):
        scaled = int(math.ceil(weight * factor))
        floor_value = 6 if segment.kind == "table_row" else 8
        segment.min_pairs = max(scaled, floor_value, weight)


__all__ = [
    "Segment",
    "assign_min_pairs",
    "extract_markdown_segments",
    "read_markdown",
]
