from pathlib import Path

from setuptools import find_packages, setup


def read_readme() -> str:
    readme_path = Path(__file__).with_name("README.md")
    if readme_path.exists():
        return readme_path.read_text(encoding="utf-8")
    return "Utilities for building code and document fine-tuning datasets."


setup(
    name="fine_tuning_dataset_preparation",
    version="0.1.0",
    url="https://bitbucket.org/entinco/eic-aimodelknowledge-utils/src/master/lib-finetuningdatasetpreparation-python",
    license="Commercial",
    author="Enterprise Innovation Consulting LLC",
    author_email="seroukhov@entinco.com",
    description="Utilities for building code and document fine-tuning datasets.",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    packages=find_packages(include=["fine_tuning_dataset_preparation", "fine_tuning_dataset_preparation.*"]),
    include_package_data=True,
    zip_safe=True,
    install_requires=[
        "langchain>=1.0.5,<2.0",
        "langchain-google-genai>=3.0.1",
        "langchain-openai>=1.0.2",
        "langchain-anthropic>=1.0.2",
        "chardet>=5.2.0",
        "tree_sitter>=0.25.2",
        "tree_sitter_python>=0.25.0",
        "tree_sitter_c_sharp>=0.23.1",
        "tree_sitter_go>=0.25.0",
        "tree_sitter_javascript>=0.25.0",
        "tree_sitter_typescript>=0.23.2",
    ],
    classifiers=[
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
