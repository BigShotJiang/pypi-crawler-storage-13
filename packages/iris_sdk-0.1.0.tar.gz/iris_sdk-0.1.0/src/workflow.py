from sdk_client import SDKClient
from collections import defaultdict
from task import Run
import uuid
import context

class Workflow:

    def __init__(self, workflow_name: str, api_key: str) -> None:
        self.workflow_name: str = workflow_name
        self.client: SDKClient = SDKClient(api_key=api_key)
        self.workflow_id: uuid.UUID = uuid.uuid4()
        self.run_id: uuid.UUID = uuid.uuid4()

    def start_run(self):
        self.run_id = uuid.uuid4()
        run: Run = Run(self.run_id, self.client)
        context.current_run.set(run)
        context.run_stack.set([])
        context.parent_children_mappings.set(defaultdict(set))
        return run
        
