from sdk_client import SDKClient
from enums import TaskTypes
from typing import Any, Dict, Optional, List, Type, Set
from dataclasses import asdict
from types import TracebackType
from shared_dataclasses import ProviderMetrics
import context

class TaskContext:
    def __init__(self, task_step_id: str, client: SDKClient, type: TaskTypes = TaskTypes.GENERIC, metadata: Dict[Any, Any] = {}) -> None:
        self.task_step_id: str = task_step_id
        self.client: SDKClient = client
        self.type: TaskTypes = type
        self.metadata: Dict[Any, Any] = metadata
        self.parent_task_id: Optional[str] = None
        self.metrics: Dict[Any, Any] = {}
    
    def log_llm_usage(self, provider_metrics: ProviderMetrics) -> None:
        self.metrics = asdict(provider_metrics)
        self.metrics["task_step_id"] = self.task_step_id
    
    def __enter__(self):
        run_stack: List[str] = context.run_stack.get()
        if run_stack:
            self.parent_task_id = run_stack[-1]
        parent_children_mappings: Dict[str, Set[str]] = context.parent_children_mappings.get()
        parent_key = str(self.parent_task_id) if self.parent_task_id else "None"
        parent_children_mappings[parent_key].add(self.task_step_id)
        context.parent_children_mappings.set(parent_children_mappings)
        run_stack.append(self.task_step_id)
        context.run_stack.set(run_stack)

        return self

    def __exit__(self, exc_type: Optional[Type[BaseException]], exc_val: Optional[BaseException], exc_tb: Optional[TracebackType]) -> bool:
        run_stack: List[str] = context.run_stack.get()
        run_stack.pop()
        context.run_stack.set(run_stack)
        if not exc_type:
            parent_children_mappings = context.parent_children_mappings.get()
            self.metrics["children_tasks"] = parent_children_mappings[self.task_step_id]
            self.client.emit(self.metrics, self.task_step_id)
        
        