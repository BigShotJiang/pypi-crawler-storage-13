SDK_ENDPOINT_TIMEOUT: int = 5
AUTH_HEADER_NAME: str = "auth_header"
INVALID_AUTH_MESSAGE: str = "Invalid authentication!"

PROVIDER_NOT_SUPPORTED = "Provider not supported/invalid provider!"
METRICS_DUMP_ERROR = "Error sending metrics to backend!"
NO_TASK_CONTEXT = "No task context available!"

TASK_STEP_ID = "task_step_id"

OPENAI = "openai"
ANTHROPIC = "anthropic"
GEMINI = "gemini"
GOOGLE = "google"

GENERIC_NAME = "generic"
LLM_NAME = "llm"
TOOL_NAME = "tool"
AGENT_NAME = "agent"

USER = "user"