import constants
import requests
from typing import Dict, Any
from dotenv import load_dotenv
import os

class SDKClient:

    def __init__(self, api_key: str) -> None:
        load_dotenv()
        self._api_key: str = api_key
        self._endpoint: str = os.environ.get("SDK_ENDPOINT")
        self._endpoint_timeout: int = constants.SDK_ENDPOINT_TIMEOUT
        if not self.__auth():
            raise AuthenticationError(constants.INVALID_AUTH_MESSAGE)
    
    def emit(self, provider_metrics: Dict[Any, Any], task_step_id: str) -> None:
        payload: Dict = provider_metrics
        payload[constants.TASK_STEP_ID] = task_step_id
        response = requests.post(
            os.environ.get("SDK_METRICS_ENDPOINT"),
            json=payload,
            timeout=constants.SDK_ENDPOINT_TIMEOUT
        )
        if response.status_code != 200:
            raise MetricsDumpError(constants.METRICS_DUMP_ERROR)
    
    def __auth(self) -> bool:
        if not self.__endpoint_is_up():
            return False

        auth_header: Dict[str, str] = {constants.AUTH_HEADER_NAME: self._api_key}
        try:
            resp: requests.Response = requests.post(
                os.environ.get("SDK_AUTH_ENDPOINT"),
                headers=auth_header,
                timeout=constants.SDK_ENDPOINT_TIMEOUT
            )
            return resp.status_code == 200
        except:
            return False

    def __endpoint_is_up(self) -> bool:
        try:
            resp: requests.Response = requests.get(self._endpoint, timeout=constants.SDK_ENDPOINT_TIMEOUT)
            return resp.status_code == 200
        except requests.RequestException:
            return False

class AuthenticationError(Exception):
    pass

class MetricsDumpError(Exception):
    pass
