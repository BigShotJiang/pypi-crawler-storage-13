from dataclasses import dataclass, field
from typing import Optional, Any

@dataclass
class ProviderMetrics:
    run_id: str
    provider: str
    model: str
    input_chars: int
    output_chars: int
    latency_sec: float
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    cost_usd: Optional[float] = None
    raw_response: Any = field(default=None)