from context import run_stack, current_run
from typing import List
from task_context import TaskContext
from cost_table import COST_TABLE
from shared_dataclasses import ProviderMetrics
import constants
import time

class LLMPassthrough:
    def __init__(self, provider: str, api_key: str, model: str) -> None:
        self.provider: str = provider.lower()
        self.api_key: str = api_key
        self.model: str = model
    
        if self.provider == constants.OPENAI:
            from openai import OpenAI
            self.client: OpenAI = OpenAI(api_key=self.api_key)
        
        elif self.provider == constants.ANTHROPIC:
            from anthropic import Anthropic
            self.client: Anthropic = Anthropic(api_key=self.api_key)
        
        elif self.provider == constants.GOOGLE:
            import google.generativeai as genai
            genai.configure(api_key = api_key)
            self.client: genai = genai
        
        else:
            raise ProviderNotSupportedError(constants.PROVIDER_NOT_SUPPORTED)
    
    def run(self, prompt: str) -> None:
        start: time.time = time.time()

        if self.provider == constants.OPENAI:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": constants.USER, "content": prompt}],
            )
            text_out = response.choices[0].message.content
            usage = response.usage
            input_tokens = usage.prompt_tokens
            output_tokens = usage.completion_tokens

        elif self.provider == constants.ANTHROPIC:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=1024,
                messages=[{"role": constants.USER, "content": prompt}],
            )
            text_out = response.content[0].text
            input_tokens = response.usage.input_tokens
            output_tokens = response.usage.output_tokens

        elif self.provider == constants.GOOGLE:
            model = self.client.GenerativeModel(self.model)
            response = model.generate_content(prompt)
            text_out = response.text
            meta = getattr(response, "usage_metadata", None)
            input_tokens = getattr(meta, "prompt_token_count", None)
            output_tokens = getattr(meta, "candidates_token_count", None)

        latency = time.time() - start
        input_chars = len(prompt)
        output_chars = len(text_out)

        cost_usd = None
        cost_info = COST_TABLE.get(self.provider, {}).get(self.model)
        if cost_info and input_tokens and output_tokens:
            cost_usd = (
                cost_info["input"] * input_tokens
                + cost_info["output"] * output_tokens
            )
        
        curr_run = current_run.get()

        provider_metrics: ProviderMetrics = ProviderMetrics(
            run_id=curr_run,
            provider=self.provider,
            model=self.model,
            input_chars=input_chars,
            output_chars=output_chars,
            latency_sec=latency,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost_usd,
            raw_response=response,
        )

        curr_run_stack: List[str] = run_stack.get()

        if not curr_run_stack:
            raise NoTaskContextError(constants.NO_TASK_CONTEXT)

        curr_task_context: TaskContext = curr_run_stack[-1]
        curr_task_context.log_llm_usage(provider_metrics)

class ProviderNotSupportedError(Exception):
    pass

class NoTaskContextError(Exception):
    pass