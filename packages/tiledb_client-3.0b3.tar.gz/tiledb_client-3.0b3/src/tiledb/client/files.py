"""TileDB File Assets

The functions of this module allow a TileDB File to be downloaded to a
local filesystem, or uploaded from a local filesystem to TileDB so that
it becomes a catalog asset.

"""

import logging
import pathlib
from os import PathLike
from typing import BinaryIO, Optional, Union
from xml.etree import ElementTree as ET

import urllib3

import tiledb
from tiledb.client import client
from tiledb.client._common.api_v4 import AssetsApi
from tiledb.client._common.api_v4 import FilesApi
from tiledb.client.folders import Teamspace

from .assets import AssetType
from .assets import _normalize_ids
from .rest_api import ApiException

logger = logging.getLogger(__name__)


class FilesError(tiledb.TileDBError):
    """Raised when a file transfer operation fails."""


class FileUploaderError(Exception):
    """When file upload fails."""


class _FileUploader:
    def __init__(self, file, length, content_type=None):
        self.file = file
        self.length = length
        self.content_type = content_type
        self.upload_id = None
        self.upload_path = None
        self.parts = []
        self.chunksize = 8000000
        self.http = urllib3.PoolManager()

    def begin(self, workspace, teamspace, path, name):
        # Is there a folder at path? We have to ask first,
        # because the initiateMultipartUpload API won't
        # complain if the path is occupied.
        try:
            folder = (
                client.build(AssetsApi)
                .get_asset(
                    workspace,
                    teamspace,
                    path,
                )
                .data
            )
        except ApiException as exc1:
            if exc1.status == 404:
                # No folder, continue.
                logger.info("No existing asset at path, continuing.")
        else:
            if folder.type != AssetType.FOLDER:
                raise FileUploaderError("Target must be a folder.")
            else:
                logger.info("Existing folder at path, appending file name.")
                if not name:
                    raise FilesError(
                        "An unnamed sequence of bytes can not be uploaded to a folder."
                    )
                path = pathlib.Path(folder.path).joinpath(name).as_posix()

        if self.length > self.chunksize:
            server_address = client.config.config.host
            uri = f"{server_address}/v4/files/{workspace}/{teamspace}/{path.lstrip('/')}?uploads"
            logger.debug("Request to initiateMultipartUpload API: uri=%r", uri)
            resp = self.http.request("POST", uri, headers=client.config.config.api_key)
            self.upload_id = ET.fromstring(resp.data).find("UploadId").text

        self.upload_path = path

    def chunks(self):
        if isinstance(self.file, memoryview):
            start = 0
            while dataslice := self.file[start : start + self.chunksize]:
                yield dataslice.tobytes()
                start = start + self.chunksize
        else:
            while data := self.file.read(self.chunksize):
                yield data

    def put_parts(self, workspace, teamspace):
        server_address = client.config.config.host
        headers = headers = client.config.config.api_key
        if self.content_type:
            headers.update({"Content-Type": self.content_type})

        if self.length > self.chunksize:
            part_num = 1
            for data in self.chunks():
                headers.update({"Content-Length": len(data)})
                uri = f"{server_address}/v4/files/{workspace}/{teamspace}/{self.upload_path.lstrip('/')}?uploadId={self.upload_id}&partNumber={part_num}"
                logger.debug(
                    "Request to uploadPart API: uri=%r, headers=%r, len=%r",
                    uri,
                    headers,
                    len(data),
                )
                resp = self.http.request("PUT", uri, headers=headers, body=data)
                etag = resp.headers["ETag"]
                self.parts.append(etag.strip('"'))
                part_num = part_num + 1
        else:
            data = next(self.chunks())
            headers.update({"Content-Length": len(data)})
            uri = f"{server_address}/v4/files/{workspace}/{teamspace}/{self.upload_path.lstrip('/')}"
            logger.debug(
                "Putting single part: uri=%r, headers=%r, len=%r",
                uri,
                headers,
                len(data),
            )
            resp = self.http.request("PUT", uri, headers=headers, body=data)

    def finish(self, workspace, teamspace):
        if self.length > self.chunksize:
            server_address = client.config.config.host
            uri = f"{server_address}/v4/files/{workspace}/{teamspace}/{self.upload_path.lstrip('/')}?uploadId={self.upload_id}"
            elem = ET.Element("CompleteMultipartUpload")
            for part_num, etag in enumerate(self.parts, start=1):
                part = ET.SubElement(elem, "Part")
                n = ET.SubElement(part, "PartNumber")
                n.text = str(part_num)
                e = ET.SubElement(part, "ETag")
                e.text = str(etag)

            doc = ET.tostring(elem, encoding="utf-8", xml_declaration=True)

            logger.debug(
                "Request to completeMultipartUpload API: uri=%r, doc=%r", uri, doc
            )
            self.http.request(
                "POST", uri, headers=client.config.config.api_key, body=doc
            )


def download_file(
    path: str,
    file: Union[BinaryIO, str],
    *,
    teamspace: Union[Teamspace, str],
) -> None:
    """Download a file from a teamspace.

    Parameters
    ----------
    path : str
        The path of the file to be downloaded.
    file : BinaryIO or str
        The file to be written.
    teamspace : Teamspace or str
        The teamspace to which the downloaded file belongs.

    Returns
    -------
    None

    Raises
    ------
    FilesError:
        If the file download failed.

    Examples
    --------
    >>> files.download_file(
    ...     "teamspace",
    ...     "README.md",
    ...     open("README.md", "wb"),
    ... )

    Notes
    -----
    The current implementation makes a copy of the file in memory
    before writing to the output file.

    """
    teamspace_id, path_id = _normalize_ids(teamspace, path)
    try:
        api_instance = client.client.build(FilesApi)
        resp = api_instance.file_get(
            client.get_workspace_id(),
            teamspace_id,
            path_id,
            _preload_content=False,
        )
    except ApiException as exc:
        raise FilesError("The file download failed.") from exc
    else:
        file.write(resp.read())


def upload_file(
    file: Union[BinaryIO, PathLike, bytes, bytearray, memoryview],
    path: Union[object, str],
    *,
    teamspace: Optional[Union[Teamspace, str]] = None,
    content_type: str = "application/octet-stream",
) -> None:
    """Upload a file to a teamspace.

    Parameters
    ----------
    file : BinaryIO, PathLike, or Buffer
        The file to be uploaded.
    path : str or object
        The TileDB path at which the file is to be registered. May be
        a path relative to a teamspace, a `Folder` or `Asset` instance,
        or an absolute "tiledb" URI. If the path to a folder is
        provided, the basename of the file will be appended to form
        a full asset path.
    teamspace : Teamspace or str, optional
        The teamspace to which the file will be registered, specified
        by object or id. If not provided, the `path` parameter is
        queried for a teamspace id.
    content_type: str, optional
        The content type of the uploaded file.

    Raises
    ------
    FilesError:
        If the file upload failed.

    Examples
    --------
    >>> folder = folders.create_folder(
    ...     "files",
    ...     teamspace="teamspace",
    ...     exists_ok=True,
    ... )
    >>> upload_file(
    ...     open("README.md", "rb"),
    ...     "files",
    ...     teamspace="teamspace",
    ...     content_type="text/markdown",
    ... )

    This creates a file asset at path "files/README.md" in the teamspace
    named "teamspace". The file's basename has been used to construct
    the full path.

    If you like, you can pass a Folder or Asset object instead of a path
    string and get the same result.

    >>> upload_file(
    ...     open("README.md", "rb"),
    ...     folder,
    ...     teamspace="teamspace",
    ...     content_type="text/markdown",
    ... )

    If you like, you can pass a Folder or Asset object instead of a path
    string and get the same result.

    >>> register_udf(get_tiledb_version, folder)

    A file can also be registered to a specific absolute "tiledb" URI
    that specifies a different name.

    >>> files.upload_file(
    ...     open("README.md", "rb"),
    ...     "tiledb://workspace/teamspace/files/index.md",
    ...     content_type="text/markdown",
    ... )

    Notes
    -----
    The current implementation copies the file in memory
    before submiting it to the server.

    """
    teamspace_id, path_id = _normalize_ids(teamspace, path)

    if hasattr(file, "read"):
        file_obj = file
        if hasattr(file, "name"):
            file_name = pathlib.Path(file.name).name
        else:
            file_name = None
        file_obj.seek(0, 2)
        file_len = file_obj.tell()
        file_obj.seek(0)
    elif isinstance(file, (str, PathLike)):
        file_path = pathlib.Path(file)
        file_name = file_path.name
        file_obj = file_path.open("rb")
        file_len = file_path.stat().st_size
    else:
        file_obj = memoryview(file)
        file_len = len(file_obj)
        file_name = None

    workspace = client.get_workspace_id()

    uploader = _FileUploader(file_obj, file_len, content_type)
    uploader.begin(workspace, teamspace_id, path_id, file_name)
    uploader.put_parts(workspace, teamspace_id)
    uploader.finish(workspace, teamspace_id)
