"""
Bot - Main class for AI Coliseum Arena SDK
"""
import asyncio
import time
from typing import Optional, Dict, Any
import aiohttp
from .types import (
    BotConfig,
    TradeAction,
    TickContextResponse,
    PlaceBetResponse,
    BotTickContext,
    Position,
    Trade,
)
from .bot_context import BotContext


class Bot:
    """Main bot class for AI Coliseum Arena SDK"""

    # API URL is always fixed
    API_URL = "https://api.sanqa.org"

    def __init__(self, config: BotConfig):
        if not config.bot_token:
            raise ValueError("bot_token is required")

        self.config = config
        self._is_running = False
        self._last_tick_timestamp: Optional[str] = None
        self._current_match_id: Optional[str] = None
        self._session: Optional[aiohttp.ClientSession] = None
        self._task: Optional[asyncio.Task] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session"""
        if self._session is None or self._session.closed:
            headers = {
                "X-Bot-Token": self.config.bot_token,
                "Content-Type": "application/json",
            }
            self._session = aiohttp.ClientSession(
                base_url=self.API_URL, headers=headers
            )
        return self._session

    async def _close_session(self):
        """Close aiohttp session"""
        if self._session and not self._session.closed:
            await self._session.close()

    def start(self):
        """Start bot in automatic mode (polling)"""
        if self._is_running:
            print("Warning: Bot is already running")
            return

        if not self.config.on_tick:
            raise ValueError("on_tick callback is required for automatic mode")

        self._is_running = True
        try:
            loop = asyncio.get_running_loop()
            # We're in an async context, create task
            self._task = loop.create_task(self._tick_loop())
        except RuntimeError:
            # No event loop running, start in background thread
            import threading
            def run_in_thread():
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                self._task = loop.create_task(self._tick_loop())
                loop.run_forever()
            thread = threading.Thread(target=run_in_thread, daemon=True)
            thread.start()

    async def stop(self):
        """Stop bot"""
        self._is_running = False
        if self._task:
            self._task.cancel()
        await self._close_session()

    async def _tick_loop(self):
        """Main tick loop for automatic mode"""
        try:
            while self._is_running:
                try:
                    await self._tick()
                except Exception as e:
                    if self.config.on_error:
                        self.config.on_error(e)
                    else:
                        print(f"Bot error: {e}")

                # Wait for next tick
                if self._is_running:
                    await asyncio.sleep(self.config.tick_interval / 1000.0)
        except asyncio.CancelledError:
            pass

    async def _tick(self):
        """Perform a single tick (polling)"""
        tick_data = await self.tick_current_match()

        # Check if we have a new match
        if tick_data.context:
            match_id = None
            if tick_data.context.match_info:
                match_id = tick_data.context.match_info.get("matchId")
            if match_id and match_id != self._current_match_id:
                # New match started
                if self._current_match_id and self.config.on_match_end:
                    self.config.on_match_end(self._current_match_id)
                self._current_match_id = match_id
                if self.config.on_match_start:
                    self.config.on_match_start(match_id)

            # Check if this is a new tick (by timestamp)
            if tick_data.timestamp != self._last_tick_timestamp:
                self._last_tick_timestamp = tick_data.timestamp

                # Create BotContext and call on_tick
                ctx = BotContext(tick_data.context)
                decision = self.config.on_tick(ctx)

                # Handle async callback
                if asyncio.iscoroutine(decision):
                    decision = await decision

                # Place bet if not hold
                if decision.action != "hold":
                    await self.place_bet(decision)

    async def tick_current_match(self) -> TickContextResponse:
        """Get current tick context (manual mode)"""
        session = await self._get_session()
        try:
            async with session.get("/api/matches/tick-current-match") as response:
                if response.status != 200:
                    error_data = await response.json()
                    raise Exception(
                        error_data.get("error", f"API error: {response.status}")
                    )
                data = await response.json()
                return self._parse_tick_response(data)
        except aiohttp.ClientError as e:
            raise Exception(f"Network error: {str(e)}")

    async def place_bet(self, action: TradeAction) -> PlaceBetResponse:
        """Place a bet/order (manual mode)"""
        # For 'sell' action, we don't need side and size
        payload: Dict[str, Any] = {"action": action.action}

        if action.action == "buy":
            if not action.side:
                raise ValueError("side is required for buy action")
            if not action.size or action.size <= 0:
                raise ValueError(
                    "size is required and must be greater than 0 for buy action"
                )
            payload["side"] = action.side
            payload["size"] = action.size

        session = await self._get_session()
        try:
            async with session.post(
                "/api/matches/place-bet/current-match", json=payload
            ) as response:
                if response.status != 200:
                    error_data = await response.json()
                    raise Exception(
                        error_data.get("error", f"API error: {response.status}")
                    )
                data = await response.json()
                return self._parse_place_bet_response(data)
        except aiohttp.ClientError as e:
            raise Exception(f"Network error: {str(e)}")

    def _parse_tick_response(self, data: Dict[str, Any]) -> TickContextResponse:
        """Parse tick response from API"""
        context = None
        if data.get("context"):
            context = self._parse_bot_tick_context(data["context"])

        return TickContextResponse(
            context=context,
            price=data.get("price", 0),
            timestamp=data.get("timestamp", ""),
        )

    def _parse_bot_tick_context(self, data: Dict[str, Any]) -> BotTickContext:
        """Parse BotTickContext from API response"""
        current_position = None
        if data.get("currentPosition"):
            pos_data = data["currentPosition"]
            current_position = Position(
                side=pos_data["side"],
                entry_price=pos_data["entryPrice"],
                size=pos_data["size"],
                entry_time=pos_data["entryTime"],
            )

        trade_history = []
        if data.get("tradeHistory"):
            trade_history = [
                self._parse_trade(t) for t in data["tradeHistory"]
            ]

        return BotTickContext(
            price=data.get("price", 0),
            timestamp=data.get("timestamp", ""),
            equity=data.get("equity", 0),
            initial_equity=data.get("initialEquity", 0),
            current_pnl=data.get("currentPnL", 0),
            current_position=current_position,
            trade_history=trade_history,
            realized_pnl=data.get("realizedPnL", 0),
            unrealized_pnl=data.get("unrealizedPnL", 0),
            tick_interval_ms=data.get("tickIntervalMs", 1000),
            stats=data.get("stats", {}),
            match_info=data.get("matchInfo"),
            price_history=data.get("priceHistory"),
            opponents=data.get("opponents"),
        )

    def _parse_trade(self, data: Dict[str, Any]) -> Trade:
        """Parse Trade from API response"""
        return Trade(
            id=data.get("id", ""),
            bot_name=data.get("botName", ""),
            match_id=data.get("matchId", ""),
            side=data.get("side", ""),
            entry_price=data.get("entryPrice", 0),
            exit_price=data.get("exitPrice"),
            size=data.get("size", 0),
            entry_time=data.get("entryTime", ""),
            exit_time=data.get("exitTime"),
            pnl=data.get("pnl", 0),
            status=data.get("status", "open"),
        )

    def _parse_place_bet_response(self, data: Dict[str, Any]) -> PlaceBetResponse:
        """Parse PlaceBetResponse from API response"""
        trade = None
        if data.get("trade"):
            trade = self._parse_trade(data["trade"])

        return PlaceBetResponse(
            success=data.get("success", False),
            message=data.get("message"),
            trade=trade,
        )

