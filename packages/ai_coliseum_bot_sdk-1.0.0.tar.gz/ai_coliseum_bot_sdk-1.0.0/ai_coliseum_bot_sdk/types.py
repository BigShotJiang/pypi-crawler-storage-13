"""
Types for ai-coliseum-bot-sdk
"""
from typing import Optional, List, Dict, Any, Callable, Awaitable, Union
from dataclasses import dataclass


@dataclass
class Position:
    side: str  # 'long' | 'short'
    entry_price: float
    size: float
    entry_time: str


@dataclass
class TradeAction:
    action: str  # 'buy' | 'sell' | 'hold'
    size: Optional[float] = None
    side: Optional[str] = None  # 'long' | 'short'


@dataclass
class Trade:
    id: str
    bot_name: str
    match_id: str
    side: str
    entry_price: float
    exit_price: Optional[float]
    size: float
    entry_time: str
    exit_time: Optional[str]
    pnl: float
    status: str  # 'open' | 'closed_profit' | 'closed_loss'


@dataclass
class BotTickContext:
    price: float
    timestamp: str
    equity: float
    initial_equity: float
    current_pnl: float
    current_position: Optional[Position]
    trade_history: List[Trade]
    realized_pnl: float
    unrealized_pnl: float
    tick_interval_ms: int
    stats: Dict[str, Any]
    match_info: Optional[Dict[str, Any]] = None
    price_history: Optional[List[float]] = None
    opponents: Optional[List[Dict[str, Any]]] = None


@dataclass
class TickContextResponse:
    context: Optional[BotTickContext]
    price: float
    timestamp: str


@dataclass
class PlaceBetResponse:
    success: bool
    message: Optional[str] = None
    trade: Optional[Trade] = None


@dataclass
class BotConfig:
    bot_token: str
    tick_interval: int = 1000  # Polling interval in milliseconds
    on_tick: Optional[Callable[[Any], Union[TradeAction, Awaitable[TradeAction]]]] = None
    on_error: Optional[Callable[[Exception], None]] = None
    on_match_start: Optional[Callable[[str], None]] = None
    on_match_end: Optional[Callable[[str], None]] = None
    # api_url removed - always uses https://api.sanqa.org

