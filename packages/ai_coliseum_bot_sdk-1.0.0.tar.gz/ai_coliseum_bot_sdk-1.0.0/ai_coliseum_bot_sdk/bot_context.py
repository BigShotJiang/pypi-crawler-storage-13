"""
BotContext - Wrapper around BotTickContext with convenient methods
"""
from typing import List, Optional
from .types import BotTickContext, TradeAction, Position


class BotContext:
    """Context wrapper for bot tick callbacks"""

    def __init__(self, context: BotTickContext):
        self._context = context

    @property
    def price(self) -> float:
        """Current price"""
        return self._context.price

    @property
    def history(self) -> List[float]:
        """Price history"""
        return self._context.price_history or []

    @property
    def current_position(self) -> Optional[Position]:
        """Current open position"""
        return self._context.current_position

    @property
    def equity(self) -> float:
        """Current balance"""
        return self._context.equity

    @property
    def initial_equity(self) -> float:
        """Initial balance"""
        return self._context.initial_equity

    @property
    def current_pnl(self) -> float:
        """Current PnL"""
        return self._context.current_pnl

    @property
    def realized_pnl(self) -> float:
        """Realized PnL"""
        return self._context.realized_pnl

    @property
    def unrealized_pnl(self) -> float:
        """Unrealized PnL"""
        return self._context.unrealized_pnl

    @property
    def stats(self):
        """Trading statistics"""
        return self._context.stats

    @property
    def match_info(self):
        """Match information"""
        return self._context.match_info

    @property
    def opponents(self):
        """Opponents information"""
        return self._context.opponents

    @property
    def trade_history(self):
        """Trade history"""
        return self._context.trade_history

    @property
    def full_context(self) -> BotTickContext:
        """Full context"""
        return self._context

    def buy(self, size: float) -> TradeAction:
        """Open LONG position"""
        return TradeAction(action="buy", side="long", size=size)

    def short(self, size: float) -> TradeAction:
        """Open SHORT position"""
        return TradeAction(action="buy", side="short", size=size)

    def close(self) -> TradeAction:
        """Close current position"""
        return TradeAction(action="sell")

    def hold(self) -> TradeAction:
        """Do nothing"""
        return TradeAction(action="hold")

