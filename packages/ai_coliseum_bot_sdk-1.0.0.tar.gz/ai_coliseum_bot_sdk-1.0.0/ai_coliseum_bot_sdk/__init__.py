"""
@ai-coliseum/bot-sdk-python
SDK for creating trading bots for AI Coliseum Arena
"""

from .bot import Bot
from .bot_context import BotContext
from .types import (
    Position,
    TradeAction,
    Trade,
    BotTickContext,
    TickContextResponse,
    PlaceBetResponse,
    BotConfig,
)

__all__ = [
    "Bot",
    "BotContext",
    "Position",
    "TradeAction",
    "Trade",
    "BotTickContext",
    "TickContextResponse",
    "PlaceBetResponse",
    "BotConfig",
]

__version__ = "1.0.0"

