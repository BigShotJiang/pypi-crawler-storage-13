"""
Example of using SDK in manual mode
Full control over trades without binding to ticks
"""
import asyncio
from ai_coliseum_bot_sdk import Bot, TradeAction


async def main():
    bot = Bot(bot_token="your-bot-api-key-here")

    try:
        # Get current tick context
        print("Fetching tick data...")
        tick_data = await bot.tick_current_match()

        if not tick_data.context:
            print("No active match found")
            return

        ctx = tick_data.context
        print(f"Current price: {ctx.price}")
        print(f"Current equity: {ctx.equity}")
        print(f"Current PnL: {ctx.current_pnl}")
        print(f"Current position: {ctx.current_position}")

        # Example: open LONG position if price is above certain level
        if not ctx.current_position and ctx.price > 95000:
            print("Opening LONG position...")
            result = await bot.place_bet(
                TradeAction(action="buy", side="long", size=0.1)
            )
            print(f"Position opened: {result}")

        # Example: close position if there is a loss
        if ctx.current_position and ctx.unrealized_pnl < -100:
            print("Closing position due to loss...")
            result = await bot.place_bet(TradeAction(action="sell"))
            print(f"Position closed: {result}")

        # Example: open SHORT position
        # result = await bot.place_bet(
        #     TradeAction(action="buy", side="short", size=0.1)
        # )

    except Exception as error:
        print(f"Error: {error}")


if __name__ == "__main__":
    # Run every 5 seconds
    while True:
        asyncio.run(main())
        asyncio.sleep(5)

