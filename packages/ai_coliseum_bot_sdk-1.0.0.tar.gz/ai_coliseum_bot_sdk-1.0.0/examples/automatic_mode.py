"""
Example of using SDK in automatic mode
Bot automatically polls API and calls on_tick callback
"""
import asyncio
from ai_coliseum_bot_sdk import Bot, BotContext, TradeAction


def on_tick_handler(ctx: BotContext) -> TradeAction:
    """Handle tick callback"""
    print(f"[{asyncio.get_event_loop().time()}] Price: {ctx.price}, Equity: {ctx.equity}")

    # Example: buy if price is above average of last 10 ticks
    if ctx.history and len(ctx.history) >= 10:
        avg_price = sum(ctx.history[-10:]) / 10

        if ctx.price > avg_price and not ctx.current_position:
            print("Opening LONG position...")
            return ctx.buy(0.1)

        # Close position if price dropped below average
        if ctx.current_position and ctx.current_position.side == "long" and ctx.price < avg_price:
            print("Closing LONG position...")
            return ctx.close()

    # Stop-loss: close if loss > 3%
    if ctx.current_position:
        if ctx.current_position.side == "long":
            pnl_percent = ((ctx.price - ctx.current_position.entry_price) / ctx.current_position.entry_price) * 100
        else:
            pnl_percent = ((ctx.current_position.entry_price - ctx.price) / ctx.current_position.entry_price) * 100

        if pnl_percent < -3:
            print(f"Stop-loss triggered: {pnl_percent:.2f}%")
            return ctx.close()

    return ctx.hold()


async def main():
    bot = Bot(
        bot_token="your-bot-api-key-here",
        tick_interval=1000,  # optional, polling interval in ms
        on_tick=on_tick_handler,
        on_error=lambda error: print(f"Bot error: {error}"),
        on_match_start=lambda match_id: print(f"Match started: {match_id}"),
        on_match_end=lambda match_id: print(f"Match ended: {match_id}"),
    )

    # Start bot
    bot.start()

    # Keep running
    try:
        await asyncio.sleep(3600)  # Run for 1 hour
    except KeyboardInterrupt:
        print("Stopping bot...")
        await bot.stop()
        # Give it a moment to clean up
        await asyncio.sleep(0.5)


if __name__ == "__main__":
    asyncio.run(main())

