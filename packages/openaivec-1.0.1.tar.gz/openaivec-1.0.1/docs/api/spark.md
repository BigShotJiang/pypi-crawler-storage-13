# Spark Extension

::: openaivec.spark