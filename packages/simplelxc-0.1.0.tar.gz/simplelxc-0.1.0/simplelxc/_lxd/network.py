"""Network and port mapping operations."""

import socket

from simplelxc._lxd._internal import get_instance as _get_instance
from simplelxc._lxd.types import ContainerError, ContainerHandle


def map_port(
    handle: ContainerHandle,
    container_port: int,
    host_port: int | None = None,
) -> int:
    """Map a container port to a host port.

    Args:
        handle: Container handle
        container_port: Port inside the container
        host_port: Port on the host (auto-assigned if None)

    Returns:
        The host port that was assigned

    Raises:
        ContainerError: If port mapping fails
    """
    from simplelxc._lxd.core import container_exists

    if not container_exists(handle):
        raise ContainerError("Container does not exist")

    # Auto-assign a free port if not specified
    assigned_port = host_port
    if assigned_port is None:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("", 0))
            s.listen(1)
            assigned_port = s.getsockname()[1]

    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Failed to get instance")

    try:
        device_name = f"proxy-{assigned_port}"
        devices = {
            device_name: {
                "type": "proxy",
                # Bind to localhost by default for safety
                "listen": f"tcp:127.0.0.1:{assigned_port}",
                "connect": f"tcp:127.0.0.1:{container_port}",
            }
        }

        instance.devices.update(devices)
        instance.save(wait=True)

        return assigned_port
    except Exception as e:
        raise ContainerError(f"Failed to map port: {e}") from e
