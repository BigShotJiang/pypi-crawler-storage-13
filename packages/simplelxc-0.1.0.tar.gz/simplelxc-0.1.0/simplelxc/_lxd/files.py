"""File transfer operations for containers."""

import os
import shlex

from simplelxc._lxd._internal import get_instance as _get_instance
from simplelxc._lxd.types import ContainerError, ContainerHandle
from simplelxc.log import logger

# =============================================================================
# Internal helpers
# =============================================================================


def resolve_container_path(handle: ContainerHandle, path: str) -> str:
    """Resolve a container path to an absolute path.

    This mirrors the previous behavior used in copy_to/copy_from/create_file:
    - ``~`` is expanded via the container's $HOME
    - relative paths are resolved against the handle's cwd using realpath -m
    """
    from simplelxc._lxd.cmd import execute_bash

    # Expand tilde in container path
    if path.startswith("~"):
        # Resolve $HOME inside the container without exposing the
        # user-provided path to the shell.
        result = execute_bash(handle, "printenv HOME")
        if result.failed or not result.stdout.strip():
            error_msg = result.stderr or "empty result"
            raise ContainerError(f"Failed to resolve $HOME: {error_msg}")

        home = result.stdout.strip()

        if path == "~":
            return home
        if path.startswith("~/"):
            return f"{home}/{path[2:]}"

        # Fallback for paths like "~something" to preserve previous behaviour
        return f"{home}{path[1:]}"

    # Resolve relative paths using handle's cwd
    if not path.startswith("/"):
        result = execute_bash(
            handle,
            f"cd {shlex.quote(handle.cwd)} && realpath -m {shlex.quote(path)}",
        )
        if result.failed:
            raise ContainerError(f"Cannot resolve path in container: {path}")
        return result.stdout.strip()

    return path


# =============================================================================
# Public API
# =============================================================================


def copy_to(
    handle: ContainerHandle,
    host_path: str,
    container_path: str,
) -> None:
    """Copy file or directory from host to container.

    Args:
        handle: Container handle
        host_path: Path on the host (file or directory)
        container_path: Path inside the container (absolute or relative to handle.cwd)

    Raises:
        ContainerError: If copy fails
    """
    from simplelxc._lxd.core import container_exists
    from simplelxc._lxd.exec import execute_bash

    if not container_exists(handle):
        raise ContainerError("Container does not exist")

    host_path = os.path.expanduser(host_path)
    if not os.path.exists(host_path):
        raise ContainerError(f"Host path does not exist: {host_path}")

    # Resolve container path to an absolute path
    container_path = resolve_container_path(handle, container_path)

    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Failed to get instance")

    try:
        # Check if container path is an existing directory
        result = execute_bash(handle, f"test -d {shlex.quote(container_path)}")
        is_container_dir = result.success

        if os.path.isdir(host_path):
            # For directories, recursively put
            dir_name = os.path.basename(host_path)
            if is_container_dir:
                final_dest = f"{container_path}/{dir_name}"
            else:
                final_dest = container_path

            # Create the destination directory first
            execute_bash(handle, f"mkdir -p {shlex.quote(final_dest)}")
            instance.files.recursive_put(host_path, final_dest)
        else:
            # For files
            if is_container_dir:
                # If destination is a directory, append filename
                if container_path.endswith("/"):
                    container_path = f"{container_path}{os.path.basename(host_path)}"
                else:
                    container_path = f"{container_path}/{os.path.basename(host_path)}"

            # Create parent directory if needed
            parent_dir = os.path.dirname(container_path)
            if parent_dir:
                result = execute_bash(handle, f"mkdir -p {shlex.quote(parent_dir)}")
                if result.failed:
                    raise ContainerError(
                        f"Failed to create parent directory {parent_dir}: "
                        f"{result.stderr}"
                    )

            with open(host_path, "rb") as f:
                content = f.read()

            logger.debug(f"Copying file to {container_path} ({len(content)} bytes)")
            instance.files.put(container_path, content)

        logger.debug(f"Created {container_path}")
    except Exception as e:
        raise ContainerError(f"Failed to copy to container: {e}") from e


def copy_from(
    handle: ContainerHandle,
    container_path: str,
    host_path: str,
) -> None:
    """Copy file or directory from container to host.

    Args:
        handle: Container handle
        container_path: Path inside the container (absolute or relative to handle.cwd)
        host_path: Path on the host (will be created if needed)

    Raises:
        ContainerError: If copy fails
    """
    from simplelxc._lxd.core import container_exists
    from simplelxc._lxd.exec import execute_bash

    if not container_exists(handle):
        raise ContainerError("Container does not exist")

    host_path = os.path.expanduser(host_path)
    os.makedirs(os.path.dirname(host_path) or ".", exist_ok=True)

    # Resolve container path to an absolute path
    container_path = resolve_container_path(handle, container_path)

    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Failed to get instance")

    try:
        # Check if it's a directory
        result = execute_bash(handle, f"test -d {shlex.quote(container_path)}")
        is_directory = result.success

        if is_directory:
            dir_name = os.path.basename(container_path)
            if os.path.isdir(host_path):
                final_host_path = os.path.join(host_path, dir_name)
            else:
                final_host_path = host_path
            instance.files.recursive_get(container_path, final_host_path)
        else:
            # For files
            if os.path.isdir(host_path):
                host_path = os.path.join(host_path, os.path.basename(container_path))

            # get the content and write it
            content = instance.files.get(container_path)
            if isinstance(content, str):
                content = content.encode("utf-8")
            with open(host_path, "wb") as f:
                f.write(content)

        logger.debug(f"Fetched {container_path}")
    except Exception as e:
        raise ContainerError(f"Failed to copy from container: {e}") from e


def create_file(
    handle: ContainerHandle,
    container_path: str,
    content: str,
) -> None:
    """Create a file with content in the container.

    Args:
        handle: Container handle
        container_path: Path inside the container (absolute or relative to handle.cwd)
        content: Content to write to the file

    Raises:
        ContainerError: If file creation fails
    """
    from simplelxc._lxd.core import container_exists

    if not container_exists(handle):
        raise ContainerError("Container does not exist")

    # Resolve the path
    resolved_path = resolve_container_path(handle, container_path)

    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Failed to get instance")

    try:
        instance.files.put(resolved_path, content.encode("utf-8"))
    except Exception as e:
        raise ContainerError(f"Failed to create file: {e}") from e
