"""Shared types for container operations."""

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class LXDExecuteResult(Protocol):
    """Protocol for pylxd execute result."""

    exit_code: int
    stdout: str
    stderr: str


@runtime_checkable
class LXDSnapshot(Protocol):
    """Protocol for pylxd snapshot object."""

    name: str

    def delete(self, wait: bool = False) -> None: ...
    def restore(self, wait: bool = False) -> None: ...


@runtime_checkable
class LXDSnapshots(Protocol):
    """Protocol for pylxd snapshots manager."""

    def get(self, name: str) -> LXDSnapshot: ...
    def create(self, name: str, stateful: bool = False, wait: bool = False) -> None: ...
    def all(self) -> list[LXDSnapshot]: ...


@runtime_checkable
class LXDFiles(Protocol):
    """Protocol for pylxd files manager."""

    def put(
        self,
        filepath: str,
        data: bytes | str,
        mode: str | None = None,
        uid: int | None = None,
        gid: int | None = None,
    ) -> None: ...
    def get(self, filepath: str) -> bytes | str: ...
    def recursive_put(
        self,
        src: str,
        dst: str,
        mode: str | None = None,
        uid: int | None = None,
        gid: int | None = None,
    ) -> None: ...
    def recursive_get(self, src: str, dst: str) -> None: ...


@runtime_checkable
class LXDInstanceManager(Protocol):
    """Protocol for pylxd instance manager."""

    def get(self, name: str) -> "LXDInstance": ...
    def create(self, config: dict[str, Any], wait: bool = False) -> "LXDInstance": ...
    def exists(self, name: str) -> bool: ...
    def all(self) -> list["LXDInstance"]: ...


@runtime_checkable
class LXDClient(Protocol):
    """Protocol for pylxd client."""

    instances: LXDInstanceManager


@runtime_checkable
class LXDInstance(Protocol):
    """Protocol for pylxd instance object."""

    name: str
    status: str
    status_code: int
    files: LXDFiles
    snapshots: LXDSnapshots

    def start(self, wait: bool = False) -> None: ...
    def stop(self, wait: bool = False, force: bool = False) -> None: ...
    def restart(self, wait: bool = False, force: bool = False) -> None: ...
    def delete(self, wait: bool = False) -> None: ...
    def execute(
        self,
        commands: list[str],
        environment: dict[str, str] | None = None,
        encoding: str | None = None,
        decode: bool = True,
    ) -> LXDExecuteResult: ...
    def state(self) -> Any: ...


class ContainerError(Exception):
    """Raised when container operations fail."""


class CommandResult:
    """Result from executing a command in a container."""

    returncode: int
    stdout: str
    stderr: str

    def __init__(self, returncode: int, stdout: str, stderr: str) -> None:
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr

    @property
    def success(self) -> bool:
        """Check if command succeeded (returncode == 0)."""
        return self.returncode == 0

    @property
    def failed(self) -> bool:
        """Check if command failed (returncode != 0)."""
        return self.returncode != 0

    def __repr__(self) -> str:
        return (
            "CommandResult("
            f"returncode={self.returncode!r}, "
            f"stdout={self.stdout!r}, "
            f"stderr={self.stderr!r})"
        )


class ContainerHandle:
    """A reference to a container - just data, no behavior."""

    name: str
    _client: LXDClient
    _instance: LXDInstance | None
    cwd: str

    def __init__(
        self,
        name: str,
        client: LXDClient,
        *,
        instance: LXDInstance | None = None,
        cwd: str = "/root",
    ) -> None:
        self.name = name
        self._client = client
        self._instance = instance
        self.cwd = cwd

    def __repr__(self) -> str:
        return f"ContainerHandle(name={self.name!r}, cwd={self.cwd!r})"

    def __str__(self) -> str:
        return f"ContainerHandle({self.name})"
