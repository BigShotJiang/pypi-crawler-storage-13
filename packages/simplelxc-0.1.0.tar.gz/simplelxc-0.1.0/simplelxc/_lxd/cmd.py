"""Low-level command execution in containers (avoids circular imports)."""

import shlex

from simplelxc._lxd._internal import get_instance as _get_instance
from simplelxc._lxd.types import CommandResult, ContainerError, ContainerHandle


def execute(
    handle: ContainerHandle,
    command: list[str],
    cwd: str | None = None,
    environment: dict | None = None,
) -> CommandResult:
    """Execute a command (as list of args) in the container.

    Args:
        handle: Container handle
        command: Command as a list of arguments (e.g., ["ls", "-la"])
        cwd: Working directory (optional, uses handle.cwd if not specified)
        environment: Environment variables (optional)

    Returns:
        CommandResult with returncode, stdout, and stderr

    Raises:
        ContainerError: If command execution fails
    """
    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Container does not exist")

    try:
        # Use handle's cwd if not explicitly provided
        if cwd is None:
            cwd = handle.cwd

        # Build environment prefix
        env_prefix = ""
        if environment:
            env_items = [f"{k}={shlex.quote(v)}" for k, v in environment.items()]
            env_prefix = " ".join(env_items) + " "

        # Build the base command string
        base_cmd = " ".join(shlex.quote(arg) for arg in command)

        # Change directory if needed
        if cwd:
            shell_command = f"cd {shlex.quote(cwd)} && {env_prefix}{base_cmd}"
        else:
            shell_command = f"{env_prefix}{base_cmd}"

        # Execute via sh
        result = instance.execute(["sh", "-c", shell_command])

        return CommandResult(
            returncode=result.exit_code,
            stdout=result.stdout or "",
            stderr=result.stderr or "",
        )
    except Exception as e:
        raise ContainerError(f"Command execution failed: {e}") from e


def execute_bash(
    handle: ContainerHandle,
    command: str,
    cwd: str | None = None,
    environment: dict | None = None,
) -> CommandResult:
    """Execute a bash command (as string) in the container.

    This allows shell features like pipes, redirects, wildcards, etc.

    Args:
        handle: Container handle
        command: Bash command string (e.g., "ls -la | grep foo")
        cwd: Working directory (optional, uses handle.cwd if not specified)
        environment: Environment variables (optional)

    Returns:
        CommandResult with returncode, stdout, and stderr

    Raises:
        ContainerError: If command execution fails
    """
    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Container does not exist")

    try:
        # Use handle's cwd if not explicitly provided
        if cwd is None:
            cwd = handle.cwd

        # Build environment command
        env_prefix = ""
        if environment:
            env_items = [f"{k}={shlex.quote(v)}" for k, v in environment.items()]
            env_prefix = " ".join(env_items) + " "

        # Build full command with cd
        if cwd:
            full_command = (
                f"cd {shlex.quote(cwd)} && {env_prefix}sh -c {shlex.quote(command)}"
            )
        else:
            full_command = f"{env_prefix}sh -c {shlex.quote(command)}"

        # Execute via sh
        result = instance.execute(["sh", "-c", full_command])

        return CommandResult(
            returncode=result.exit_code,
            stdout=result.stdout or "",
            stderr=result.stderr or "",
        )
    except Exception as e:
        raise ContainerError(f"Command execution failed: {e}") from e
