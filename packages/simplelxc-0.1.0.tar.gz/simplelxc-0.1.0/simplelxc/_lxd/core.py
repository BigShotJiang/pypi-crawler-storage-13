"""Core container lifecycle operations (create, delete, start, stop)."""

import platform
import time
from typing import cast

from pylxd import Client
from pylxd.exceptions import NotFound

from simplelxc._lxd._internal import get_instance as _get_instance
from simplelxc._lxd.types import ContainerError, ContainerHandle, LXDClient
from simplelxc.log import logger

# Shared client instance (initialized on first use)
_client: LXDClient | None = None


def _ensure_client() -> LXDClient:
    """Ensure pylxd client is initialized and return it."""
    global _client
    if _client is None:
        try:
            _client = cast(LXDClient, Client())
        except Exception as e:
            raise ContainerError(f"Failed to connect to LXD: {e}") from e
    return _client


# =============================================================================
# Public API
# =============================================================================


def create_handle(name: str) -> ContainerHandle:
    """Create a container handle for the given name.

    This creates a handle (reference) to a container. The container doesn't
    need to exist yet - this just creates the handle.

    Args:
        name: Container name

    Returns:
        ContainerHandle for the named container
    """

    client = _ensure_client()
    return ContainerHandle(name, client)


def container_exists(handle: ContainerHandle) -> bool:
    """Check if the container exists.

    Args:
        handle: Container handle

    Returns:
        True if container exists, False otherwise
    """
    if not handle.name:
        return False
    try:
        return handle._client.instances.exists(handle.name)
    except Exception:
        return False


def create_container(
    handle: ContainerHandle,
    image: str,
    wait_for_network: bool = True,
) -> None:
    """Create and start a container from an image.

    Args:
        handle: Container handle
        image: LXC image to use (e.g., "images:archlinux", "local:myimage")
        wait_for_network: Wait for network connectivity before returning

    Raises:
        ContainerError: If container creation fails
    """
    try:
        config = {
            "name": handle.name,
            "source": {"type": "image", "alias": image},
            "type": "container",
        }

        # Handle remote images (e.g., "images:archlinux")
        if ":" in image:
            remote, alias = image.split(":", 1)
            if remote == "local":
                config["source"]["alias"] = alias
            else:
                # Map common remote names to URLs
                remote_urls = {
                    "images": "https://images.lxd.canonical.com",
                    "ubuntu": "https://cloud-images.ubuntu.com/releases/",
                    "ubuntu-daily": "https://cloud-images.ubuntu.com/daily/",
                }
                server_url = remote_urls.get(remote, "https://images.lxd.canonical.com")

                # Add architecture suffix based on host architecture if needed
                if "/" not in alias or alias.count("/") == 1:
                    if not alias.endswith(("/amd64", "/arm64", "/armhf", "/i386")):
                        machine = platform.machine().lower()
                        if machine in ("x86_64", "amd64"):
                            arch = "amd64"
                        elif machine in ("aarch64", "arm64"):
                            arch = "arm64"
                        elif machine in ("armv7l", "armv7", "armhf"):
                            arch = "armhf"
                        elif machine in ("i386", "i686"):
                            arch = "i386"
                        else:
                            raise ContainerError(f"Unsupported architecture: {machine}")
                        alias = f"{alias}/{arch}"

                config["source"] = {
                    "type": "image",
                    "mode": "pull",
                    "server": server_url,
                    "protocol": "simplestreams",
                    "alias": alias,
                }

        handle._instance = handle._client.instances.create(config, wait=True)
        handle._instance.start(wait=True)

        if wait_for_network:
            wait_for_network_ready(handle)

    except Exception as e:
        error_msg = str(e).lower()

        # Check for image-related errors
        if any(
            keyword in error_msg
            for keyword in ["image", "not found", "alias", "404", "fingerprint"]
        ):
            raise ContainerError(f"Image not found: '{image}'") from None

        # Generic error
        raise ContainerError(f"Failed to create container: {e}") from e


def stop_container(handle: ContainerHandle) -> None:
    """Stop the container if it is running.

    Args:
        handle: Container handle

    Raises:
        ContainerError: If stopping fails
    """
    instance = _get_instance(handle)
    if not instance:
        return

    try:
        instance.stop(wait=True)
    except Exception as e:
        raise ContainerError(f"Failed to stop container: {e}") from e


def start_container(handle: ContainerHandle, wait_for_network: bool = True) -> None:
    """Start an existing container.

    Args:
        handle: Container handle
        wait_for_network: Wait for network connectivity

    Raises:
        ContainerError: If starting fails
    """
    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Container does not exist")

    try:
        if instance.status_code == 103:  # Running
            return

        instance.start(wait=True)
        # Refresh the instance after start to get updated state
        handle._instance = handle._client.instances.get(handle.name)
        if wait_for_network:
            wait_for_network_ready(handle)
    except Exception as e:
        raise ContainerError(f"Failed to start container: {e}") from e


def delete_container(handle: ContainerHandle) -> None:
    """Delete the container (forcefully stops if running).

    Args:
        handle: Container handle

    Raises:
        ContainerError: If deletion fails
    """
    try:
        instance = _get_instance(handle)
        if instance:
            # Force stop regardless of status
            try:
                instance.stop(force=True, wait=True)
            except Exception:
                pass  # not a problem

            try:
                instance.delete(wait=True)
            except NotFound:
                logger.debug(f"Container '{handle.name}' already deleted")

            handle._instance = None
    except Exception as e:
        raise ContainerError(f"Failed to delete container: {e}") from e


def restart_container(handle: ContainerHandle, wait_for_network: bool = True) -> None:
    """Restart the container and wait for it to become available.

    Args:
        handle: Container handle
        wait_for_network: Wait for network connectivity

    Raises:
        ContainerError: If restart fails
    """
    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Container does not exist")

    try:
        instance.restart(wait=True)
        # Refresh the instance after restart to get updated state
        handle._instance = handle._client.instances.get(handle.name)
        if wait_for_network:
            wait_for_network_ready(handle)
    except Exception as e:
        raise ContainerError(f"Failed to restart container: {e}") from e


def wait_for_network_ready(handle: ContainerHandle, timeout: int = 10) -> None:
    """Wait for container to have network connectivity (IP address assigned).

    Args:
        handle: Container handle
        timeout: Maximum seconds to wait

    Raises:
        ContainerError: If timeout reached
    """
    logger.debug("Waiting for network to become ready in container")
    start = time.time()

    while time.time() - start < timeout:
        try:
            instance = _get_instance(handle)
            if not instance:
                # Container might be in the process of creation/starting
                time.sleep(0.5)
                continue

            state = instance.state()
            # Check for having an IPv4 address
            for iface_name, iface_data in state.network.items():
                if iface_name.startswith(("lo", "docker", "lxdbr")):
                    continue  # Skip loopback and bridge interfaces
                addresses = iface_data.get("addresses", [])
                for addr in addresses:
                    if addr.get("family") == "inet" and addr.get("scope") == "global":
                        logger.debug(f"Network ready: Found IP {addr.get('address')}")
                        return
        except Exception:
            pass

        time.sleep(0.5)

    raise ContainerError(f"Container not ready after {timeout}s")


def get_container_names() -> list[str]:
    """List all container names on the system.

    Returns:
        List of container names
    """
    try:
        client = _ensure_client()
        instances = client.instances.all()
        return [instance.name for instance in instances]
    except Exception:
        return []


def delete_containers_by_prefix(prefix: str) -> int:
    """Delete containers whose names start with the given prefix.

    Containers are matched using ``f"{prefix}-"`` to match the pattern
    by which `simplelxc` creates all containers. Allowing containers
    to be safely deleted without affecting unrelated containers.

    Args:
        prefix: Prefix to match container names (e.g., "my-app")

    Returns:
        Number of containers deleted

    Raises:
        ValueError: If prefix is empty or only whitespace
    """
    if not prefix or not prefix.strip():
        raise ValueError("Prefix cannot be empty")

    prefix = prefix.strip()
    search_prefix = f"{prefix}-"

    all_containers = get_container_names()
    matching_containers = [
        name for name in all_containers if name.startswith(search_prefix)
    ]

    deleted_count = 0
    client = _ensure_client()

    for container_name in matching_containers:
        try:
            instance = client.instances.get(container_name)
            # Force stop regardless of status
            try:
                instance.stop(force=True, wait=True)
            except Exception as e:
                logger.debug(
                    f"Failed to stop container before deletion (ignoring): {e}"
                )
            instance.delete(wait=True)
            deleted_count += 1
            logger.info(f"Deleted container: {container_name}")
        except Exception as e:
            logger.warning(f"Failed to delete container {container_name}: {e}")

    return deleted_count
