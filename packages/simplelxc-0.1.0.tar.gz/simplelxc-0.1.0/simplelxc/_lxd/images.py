"""Container image management."""

from pylxd.exceptions import NotFound

from simplelxc._lxd._internal import get_instance as _get_instance
from simplelxc._lxd.types import ContainerError, ContainerHandle
from simplelxc.log import logger


def _get_client():
    """Get the shared pylxd client."""
    from simplelxc._lxd.core import _ensure_client

    return _ensure_client()


def create_image(
    handle: ContainerHandle,
    image_name: str,
    version: str | None = None,
) -> None:
    """Create a local image from the container.

    Args:
        handle: Container handle
        image_name: Alias name for the local image
        version: Optional version string to attach as metadata

    Raises:
        ContainerError: If image creation fails
    """
    from simplelxc._lxd.core import container_exists

    if not container_exists(handle):
        raise ContainerError("Container does not exist")

    logger.debug(f"Saving container as image '{image_name}'")

    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Failed to get instance")

    try:
        properties = {"description": "SimpleLXC Container Image"}
        if version:
            properties["version"] = version

        # Stop the container before publishing (LXD requirement)
        was_running = instance.status_code == 103  # 103 = Running
        if was_running:
            logger.debug("Stopping container to create image")
            instance.stop(wait=True)
            logger.debug("Stopped")

        # Publish the stopped instance
        logger.debug("Creating base containing image")
        image = instance.publish(wait=True)
        image.properties = properties
        image.save()

        # Restart if it was running before
        if was_running:
            logger.debug("Restarting container")
            instance.start(wait=True)

        # Add/update alias
        try:
            existing = handle._client.images.get_by_alias(image_name)  # type: ignore
            existing.delete_alias(image_name)
        except NotFound:
            pass

        image.add_alias(image_name, "")
        logger.debug(f"Created local image '{image_name}'")
    except Exception as e:
        raise ContainerError(f"Failed to create image '{image_name}': {e}") from e


def delete_image(image_name: str) -> None:
    """Delete a local image.

    Args:
        image_name: Name of the image to delete

    Raises:
        ContainerError: If image deletion fails
    """
    try:
        client = _get_client()
        image = client.images.get_by_alias(image_name)  # type: ignore
        image.delete(wait=True)
        logger.info(f"Deleted image: {image_name}")
    except NotFound:
        raise ContainerError(f"Image not found: {image_name}") from None
    except Exception as e:
        raise ContainerError(f"Failed to delete image {image_name}: {e}") from e


def image_exists(image_name: str) -> bool:
    """Check if a local image exists.

    Args:
        image_name: Alias name of the image to check

    Returns:
        True if image exists
    """
    try:
        client = _get_client()
        client.images.get_by_alias(image_name)  # type: ignore
        return True
    except NotFound:
        return False
    except Exception:
        return False


def get_image_version(image_name: str) -> str | None:
    """Get version metadata from an image.

    Args:
        image_name: Alias name of the image

    Returns:
        Version string if found, None otherwise
    """
    try:
        client = _get_client()
        image = client.images.get_by_alias(image_name)  # type: ignore
        return image.properties.get("version")
    except (NotFound, Exception):
        return None


def get_image_names() -> list[str]:
    """List all local image names.

    Returns:
        List of image aliases
    """
    try:
        client = _get_client()
        images = client.images.all()  # type: ignore
        aliases = []
        for img in images:
            aliases.extend([alias["name"] for alias in img.aliases])
        return aliases
    except Exception:
        return []


def delete_images_by_prefix(prefix: str) -> int:
    """Delete images whose names start with the given prefix.

    Images are matched using ``f"{prefix}-"`` to match the pattern
    by which `simplelxc` creates all images. Allowing images
    to be safely deleted without affecting unrelated images.

    Args:
        prefix: Prefix to match images names (e.g., "my-app")

    Returns:
        Number of images deleted

    Raises:
        ValueError: If prefix is empty or only whitespace
    """
    if not prefix or not prefix.strip():
        raise ValueError("Prefix cannot be empty")

    prefix = prefix.strip()
    search_prefix = f"{prefix}-"

    all_images = get_image_names()
    matching_images = [
        name for name in all_images if name.startswith(search_prefix)
    ]

    deleted_count = 0
    client = _get_client()

    for image_name in matching_images:
        try:
            image = client.images.get(image_name)  # type: ignore
            image.delete(wait=True)
            deleted_count += 1
            logger.info(f"Deleted image: {image_name}")
        except Exception as e:
            logger.warning(f"Failed to delete image {image_name}: {e}")

    return deleted_count
