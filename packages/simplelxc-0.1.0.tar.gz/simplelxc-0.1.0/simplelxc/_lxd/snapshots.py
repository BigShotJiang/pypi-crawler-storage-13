"""Container snapshot operations."""

from pylxd.exceptions import NotFound

from simplelxc._lxd._internal import get_instance as _get_instance
from simplelxc._lxd.types import ContainerError, ContainerHandle


def create_snapshot(handle: ContainerHandle, name: str) -> None:
    """Create a snapshot of the container."""
    from simplelxc._lxd.core import container_exists

    if not container_exists(handle):
        raise ContainerError("Container does not exist")

    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Failed to get instance")

    try:
        # Delete existing snapshot with same name
        try:
            snapshot = instance.snapshots.get(name)
            snapshot.delete(wait=True)
        except NotFound:
            pass

        instance.snapshots.create(name, wait=True)
    except Exception as e:
        raise ContainerError(f"Failed to create snapshot: {e}") from e


def restore_snapshot(handle: ContainerHandle, name: str) -> None:
    """Restore container to a snapshot."""
    from simplelxc._lxd.core import container_exists

    if not container_exists(handle):
        raise ContainerError("Container does not exist")

    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Failed to get instance")

    try:
        snapshot = instance.snapshots.get(name)
        snapshot.restore(wait=True)
    except NotFound:
        raise ContainerError(f"Snapshot not found: {name}") from None
    except Exception as e:
        raise ContainerError(f"Failed to restore snapshot: {e}") from e


def delete_snapshot(handle: ContainerHandle, name: str) -> None:
    """Delete a snapshot."""
    from simplelxc._lxd.core import container_exists

    if not container_exists(handle):
        raise ContainerError("Container does not exist")

    instance = _get_instance(handle)
    if not instance:
        raise ContainerError("Failed to get instance")

    try:
        snapshot = instance.snapshots.get(name)
        snapshot.delete(wait=True)
    except NotFound:
        raise ContainerError(f"Snapshot not found: {name}") from None
    except Exception as e:
        raise ContainerError(f"Failed to delete snapshot: {e}") from e


def get_snapshot_names(handle: ContainerHandle) -> list[str]:
    """List all snapshots for the container."""
    from simplelxc._lxd.core import container_exists

    if not container_exists(handle):
        return []

    instance = _get_instance(handle)
    if not instance:
        return []

    try:
        snapshots = instance.snapshots.all()
        return [snapshot.name for snapshot in snapshots]
    except Exception:
        return []
