"""Internal utilities for container modules.

This module contains shared helper functions used across container modules.
Not part of the public API - functions here are for internal use only.
"""

from pylxd.exceptions import NotFound

from simplelxc._lxd.types import ContainerHandle, LXDInstance


def get_instance(handle: ContainerHandle) -> LXDInstance | None:
    """Get the pylxd instance object, fetching it if needed.

    This is a shared helper used by all container modules.

    Args:
        handle: Container handle

    Returns:
        The pylxd instance object, or None if not found
    """
    if handle._instance is None and handle.name:
        try:
            handle._instance = handle._client.instances.get(handle.name)
        except NotFound:
            return None
    return handle._instance
