"""Command execution in containers."""

import os
import time

from simplelxc._lxd.cmd import execute, execute_bash
from simplelxc._lxd.types import CommandResult, ContainerError, ContainerHandle
from simplelxc.log import logger

# Export execute/execute_bash for backward compatibility or if used elsewhere
__all__ = ["execute", "execute_bash", "execute_script", "exec_replace"]


def execute_script(
    handle: ContainerHandle,
    local_path: str,
    args: str = "",
) -> CommandResult:
    """Copy a local script to container, execute it, and clean up.

    This is a convenience function that handles the common pattern of:
    1. Copying a local script to the container
    2. Making it executable
    3. Running it with detailed error checking
    4. Cleaning up the script file

    Args:
        handle: Container handle
        local_path: Path to local script file
        args: Arguments to pass to the script (optional)

    Returns:
        CommandResult with returncode, stdout, and stderr

    Raises:
        RuntimeError: If script execution fails
        ContainerError: If file operations fail

    """
    from simplelxc._lxd import files

    # Copy script to container
    remote_path = f"~/{os.path.basename(local_path)}"
    files.copy_to(handle, local_path, remote_path)

    # Make executable
    execute_bash(handle, f"chmod +x {remote_path}")

    # Execute script with timing
    logger.debug(f"Executing script {os.path.basename(local_path)}")
    start_time = time.time()

    # Build command with args if provided
    command = remote_path
    if args:
        command = f"{remote_path} {args}"

    result = execute_bash(handle, command)
    duration = time.time() - start_time

    # Log execution diagnostics
    logger.debug(
        f"Script completed in {duration:.1f}s (exit code: {result.returncode})"
    )

    # Log stdout if present
    if result.stdout.strip():
        logger.debug(f"Script stdout:\n{result.stdout}")

    # Log stderr if present
    if not result.failed and result.stderr.strip():
        logger.debug(f"Script stderr:\n{result.stderr}")

    # Check for failure
    if result.failed:
        logger.warning(f"Script stderr:\n{result.stderr}")
        logger.error(f"Script failed (exit code: {result.returncode})")
        # Clean up before raising
        execute_bash(handle, f"rm -f {remote_path}")
        raise RuntimeError(f"Script execution failed: {result.stderr}")

    # Clean up
    execute_bash(handle, f"rm -f {remote_path}")

    logger.debug("Script execution complete")
    return result


def exec_replace(
    handle: ContainerHandle,
    command: str,
    cwd: str | None = None,
    environment: dict | None = None,
) -> None:
    """Execute command and replace current process (for interactive sessions).

    This uses the 'lxc' CLI to replace the current process with the
    command running in the container. Useful for interactive sessions.

    Args:
        handle: Container handle
        command: Bash command to execute
        cwd: Working directory (optional, uses handle.cwd if not specified)
        environment: Environment variables (optional)

    Note:
        This function does not return - it replaces the current process!
    """
    from simplelxc._lxd.core import container_exists

    if not container_exists(handle):
        raise ContainerError("Container does not exist")

    # Use handle's cwd if not explicitly provided
    if cwd is None:
        cwd = handle.cwd

    args = ["lxc", "exec"]
    if cwd:
        args.extend(["--cwd", cwd])
    args.append(handle.name)
    if environment:
        for key, value in environment.items():
            args.extend(["--env", f"{key}={value}"])
    args.extend(["--", "bash", "-lc", command])

    # This never returns - replaces current process
    os.execvp("lxc", args)
