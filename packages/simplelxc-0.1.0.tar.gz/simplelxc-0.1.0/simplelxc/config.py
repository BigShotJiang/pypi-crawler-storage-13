"""Configuration dataclasses for container orchestration."""

from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from simplelxc.container import Container


class ContainerConfig:
    """Configuration for the container runtime.

    This class defines how the container behaves during its lifecycle.

    Attributes:
        name_prefix:
            A prefix used to generate a unique container name (e.g., "myapp" ->
            "myapp-1").
        auto_delete:
            If True (default), the container is deleted automatically when
            `stop()` is called.
        headless:
            If True, the container runs without expecting interactive terminal
            control.
        version:
            A version string (e.g., "1.0"). If provided, SimpleLXC will cache the
            provisioned container state as an image and reuse it for future runs with
            the same version, skipping provisioning steps.
        image_name:
            Optional base name for the cached image. Defaults to `name_prefix`.
            Use this if multiple different containers should share the same cached
            image.
    """

    name_prefix: str
    auto_delete: bool
    headless: bool
    version: str | None
    image_name: str | None

    def __init__(
        self,
        *,
        name_prefix: str,
        auto_delete: bool = True,
        headless: bool = False,
        version: str | None = None,
        image_name: str | None = None,
    ) -> None:
        self.name_prefix = name_prefix
        self.auto_delete = auto_delete
        self.headless = headless
        self.version = version
        self.image_name = image_name

    def __repr__(self) -> str:
        return (
            "ContainerConfig("
            f"name_prefix={self.name_prefix!r}, "
            f"auto_delete={self.auto_delete!r}, "
            f"headless={self.headless!r}, "
            f"version={self.version!r}, "
            f"image_name={self.image_name!r})"
        )


class ImageConfig:
    """Configuration for the container image and environment.

    This class defines what goes *inside* the container.

    Attributes:
        base_image:
            The LXD image to use as a starting point (e.g., "images:archlinux",
            "ubuntu:22.04").
        force_rebuild:
            If True, forces a rebuild of the environment even if a cached image
            exists.
        install_packages:
            A list of system package names to install (uses `pacman` or `apt-get`).
        setup_scripts:
            A list of paths to local shell scripts. These will be copied to the
            container and executed in order after package installation.
    """

    base_image: str
    force_rebuild: bool
    install_packages: list[str]
    setup_scripts: list[str]

    def __init__(
        self,
        *,
        base_image: str = "images:archlinux",
        force_rebuild: bool = False,
        install_packages: list[str] | None = None,
        setup_scripts: list[str] | None = None,
    ) -> None:
        self.base_image = base_image
        self.force_rebuild = force_rebuild
        self.install_packages = list(install_packages) if install_packages else []
        self.setup_scripts = list(setup_scripts) if setup_scripts else []

    def __repr__(self) -> str:
        return (
            "ImageConfig("
            f"base_image={self.base_image!r}, "
            f"force_rebuild={self.force_rebuild!r}, "
            f"install_packages={self.install_packages!r}, "
            f"setup_scripts={self.setup_scripts!r})"
        )


class StartPlan:
    """Details about the planned container startup.

    Passed to the `before_start` hook to allow inspection of what is about to happen.
    """

    container_name: str
    image_name: str
    version: str | None
    will_use_cached_image: bool
    will_create_cached_image: bool
    auto_delete: bool

    def __init__(
        self,
        *,
        container_name: str,
        image_name: str,
        version: str | None,
        will_use_cached_image: bool,
        will_create_cached_image: bool,
        auto_delete: bool,
    ) -> None:
        self.container_name = container_name
        self.image_name = image_name
        self.version = version
        self.will_use_cached_image = will_use_cached_image
        self.will_create_cached_image = will_create_cached_image
        self.auto_delete = auto_delete

    def __repr__(self) -> str:
        return (
            "StartPlan("
            f"container_name={self.container_name!r}, "
            f"image_name={self.image_name!r}, "
            f"version={self.version!r}, "
            f"will_use_cached_image={self.will_use_cached_image!r}, "
            f"will_create_cached_image={self.will_create_cached_image!r}, "
            f"auto_delete={self.auto_delete!r})"
        )


class LifecycleHooks:
    """Lifecycle callbacks for customizing container orchestration.

    Hooks allow you to inject custom logic at specific points in the container's
    lifecycle (creation, provisioning, shutdown). You can assign callables (functions
    or lambdas) to these attributes on the `Container.hooks` object.

    Unless otherwise noted, hooks receive the `Container` instance as their only
    argument.

    Attributes:
        before_start:
            Called before the container is created or started.
            Receives a `StartPlan` object describing the intended configuration.
            Useful for logging plans or validating preconditions.

        after_start:
            Called immediately after the container is created and started, but before
            any environment provisioning (packages/scripts) begins.
            Useful for quick health checks or waiting for base services.

        before_provision:
            Called before environment provisioning begins. Only runs if a new image
            is being built (i.e., not using a cached image).
            Useful for preparing files or state required by setup scripts.

        after_provision:
            Called after all packages are installed and setup scripts have finished.
            Only runs if a new image was built.
            Useful for running migrations or validating the provisioned environment.

        before_image_creation:
            Called before the provisioned container is saved as a cached image.
            Only runs if versioning is enabled and a new image is being built.
            Useful for cleaning up temporary files before baking the image.

        after_image_creation:
            Called after the cached image has been successfully created.
            Only runs if versioning is enabled and a new image was built.

        container_ready:
            Called when the container is fully ready for use.
            - If using a cached image: runs after `after_start`.
            - If provisioning: runs after `after_provision` (and image creation).
            This is the ideal place for final readiness checks.

        before_stop:
            Called immediately before the container is stopped.
            Useful for capturing logs, artifacts, or saving state.

        after_stop:
            Called after the container has been stopped.

        before_delete:
            Called before the container is deleted.
            Only runs if `auto_delete` is True or `delete()` is called explicitly.

        after_delete:
            Called after the container has been successfully deleted.
    """

    before_start: Callable[[StartPlan], None] | None
    after_start: Callable[[Container], None] | None
    before_provision: Callable[[Container], None] | None
    after_provision: Callable[[Container], None] | None
    before_image_creation: Callable[[Container], None] | None
    after_image_creation: Callable[[Container], None] | None
    container_ready: Callable[[Container], None] | None
    before_stop: Callable[[Container], None] | None
    after_stop: Callable[[Container], None] | None
    before_delete: Callable[[Container], None] | None
    after_delete: Callable[[Container], None] | None

    def __init__(
        self,
        *,
        before_start: Callable[[StartPlan], None] | None = None,
        after_start: Callable[[Container], None] | None = None,
        before_provision: Callable[[Container], None] | None = None,
        after_provision: Callable[[Container], None] | None = None,
        before_image_creation: Callable[[Container], None] | None = None,
        after_image_creation: Callable[[Container], None] | None = None,
        container_ready: Callable[[Container], None] | None = None,
        before_stop: Callable[[Container], None] | None = None,
        after_stop: Callable[[Container], None] | None = None,
        before_delete: Callable[[Container], None] | None = None,
        after_delete: Callable[[Container], None] | None = None,
    ) -> None:
        self.before_start = before_start
        self.after_start = after_start
        self.before_provision = before_provision
        self.after_provision = after_provision
        self.before_image_creation = before_image_creation
        self.after_image_creation = after_image_creation
        self.container_ready = container_ready
        self.before_stop = before_stop
        self.after_stop = after_stop
        self.before_delete = before_delete
        self.after_delete = after_delete

    def __repr__(self) -> str:
        return (
            "LifecycleHooks("
            f"before_start={self.before_start!r}, "
            f"after_start={self.after_start!r}, "
            f"before_provision={self.before_provision!r}, "
            f"after_provision={self.after_provision!r}, "
            f"before_image_creation={self.before_image_creation!r}, "
            f"after_image_creation={self.after_image_creation!r}, "
            f"container_ready={self.container_ready!r}, "
            f"before_stop={self.before_stop!r}, "
            f"after_stop={self.after_stop!r}, "
            f"before_delete={self.before_delete!r}, "
            f"after_delete={self.after_delete!r})"
        )


# =============================================================================
# Configuration Loading
# =============================================================================


def load_config_from_dict(
    config: dict[str, Any],
) -> tuple[ContainerConfig, ImageConfig]:
    """Load container configuration from a dictionary.

    This is useful for programmatically building configs or loading from
    other sources besides JSON files.

    Args:
        config: Configuration dictionary (same format as JSON file)

    Returns:
        Tuple of (ContainerConfig, ImageConfig)

    Raises:
        ValueError: If config is missing required fields

    Example format:

    ```json
        {
            "container": {
                "name_prefix": "myapp",
                "auto_delete": true,
                "version": "1.0"
            },
            "image": {
                "base_image": "images:ubuntu/22.04",
                "install_packages": ["python3", "curl"]
            }
        }
    ```
    """

    container_data = config.get("container", {})
    if not container_data.get("name_prefix"):
        raise ValueError("Config must include 'container.name_prefix'")

    container_config = ContainerConfig(
        name_prefix=container_data["name_prefix"],
        auto_delete=container_data.get("auto_delete", True),
        headless=container_data.get("headless", False),
        version=container_data.get("version"),
        image_name=container_data.get("image_name"),
    )

    image_data = config.get("image", {})
    image_config = ImageConfig(
        base_image=image_data.get("base_image", "images:archlinux"),
        force_rebuild=image_data.get("force_rebuild", False),
        install_packages=image_data.get("install_packages", []),
        setup_scripts=image_data.get("setup_scripts", []),
    )

    return container_config, image_config


def load_config_from_file(
    config_path: str | Path,
) -> tuple[ContainerConfig, ImageConfig]:
    """Load container configuration from a JSON file.

    Args:
        config_path: Path to JSON configuration file

    Returns:
        Tuple of (ContainerConfig, ImageConfig)

    Raises:
        FileNotFoundError: If config file doesn't exist
        json.JSONDecodeError: If config file is invalid JSON
        ValueError: If config is missing required fields

    See load_config_from_dict() for JSON format.
    """

    path = Path(config_path)

    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path) as f:
        data = json.load(f)

    return load_config_from_dict(data)
