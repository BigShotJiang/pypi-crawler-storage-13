"""
.. include:: ../intro.md
   :start-line: 5
"""

from importlib.metadata import PackageNotFoundError, version

from simplelxc import system
from simplelxc._lxd.types import CommandResult, ContainerError
from simplelxc.config import LifecycleHooks
from simplelxc.container import Container, PackageManager

try:
    __version__ = version("simplelxc")
except PackageNotFoundError:
    __version__ = "unknown"

__all__ = [
    "__version__",
    "Container",
    "PackageManager",
    "system",
    "CommandResult",
    "LifecycleHooks",
    "ContainerError",
]
