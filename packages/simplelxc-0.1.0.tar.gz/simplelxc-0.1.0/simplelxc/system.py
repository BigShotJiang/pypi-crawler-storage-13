"""Global system-wide container and image management operations."""

from __future__ import annotations

from simplelxc._lxd import core, images


def get_container_names() -> list[str]:
    """Get a list of names of all LXD containers on the system."""
    return core.get_container_names()


def prune_containers(prefix: str) -> int:
    """
    Delete all containers with names starting with the given `prefix`.

    Returns the number of containers deleted.
    """
    return core.delete_containers_by_prefix(prefix)


def prune_images(prefix: str) -> int:
    """
    Delete all images with names starting with the given `prefix`.

    Returns the number of images deleted.
    """
    return images.delete_images_by_prefix(prefix)


def get_image_names() -> list[str]:
    """Get a list of names (aliases) of all local LXD images."""
    return images.get_image_names()


def delete_image(image_name: str) -> None:
    """Delete a local image by its alias."""
    images.delete_image(image_name)


def image_exists(image_name: str) -> bool:
    """Check if a local image exists with the given alias."""
    return images.image_exists(image_name)


def get_image_version(image_name: str) -> str | None:
    """
    Get the version string of a local image, if it exists.

    Returns None if the image does not exist or has no version metadata.
    """
    return images.get_image_version(image_name)
