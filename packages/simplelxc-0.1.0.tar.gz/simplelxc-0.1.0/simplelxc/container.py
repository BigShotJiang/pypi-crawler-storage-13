"""Container orchestration interface."""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from simplelxc._lxd import core, exec, files, images, network, snapshots
from simplelxc._lxd.types import CommandResult, ContainerHandle
from simplelxc.config import (
    ContainerConfig,
    ImageConfig,
    LifecycleHooks,
    StartPlan,
    load_config_from_dict,
    load_config_from_file,
)
from simplelxc.log import logger


@dataclass
class PackageManager:
    """Configuration for a system package manager."""

    name: str
    install_cmd: str
    update_cmd: str | None = None
    binary: str | None = None  # Defaults to name if None

    def get_binary(self) -> str:
        return self.binary or self.name


_DEFAULT_PACKAGE_MANAGERS: dict[str, PackageManager] = {
    "apt-get": PackageManager(
        name="apt-get",
        update_cmd="apt-get update",
        install_cmd="DEBIAN_FRONTEND=noninteractive apt-get install -y {packages}",
    ),
    "pacman": PackageManager(
        name="pacman",
        update_cmd="pacman -Syu --noconfirm",
        install_cmd="pacman -S --noconfirm {packages}",
    ),
    "apk": PackageManager(
        name="apk",
        update_cmd="apk update",
        install_cmd="apk add {packages}",
    ),
    "dnf": PackageManager(
        name="dnf",
        update_cmd="dnf makecache",
        install_cmd="dnf install -y {packages}",
    ),
    "yum": PackageManager(
        name="yum",
        update_cmd="yum makecache",
        install_cmd="yum install -y {packages}",
    ),
    "zypper": PackageManager(
        name="zypper",
        update_cmd="zypper -n refresh",
        install_cmd="zypper -n install -y {packages}",
    ),
    "microdnf": PackageManager(
        name="microdnf",
        update_cmd="microdnf makecache",
        install_cmd="microdnf install -y {packages}",
    ),
    "xbps": PackageManager(
        name="xbps",
        binary="xbps-install",
        update_cmd="xbps-install -Sy",
        install_cmd="xbps-install -y {packages}",
    ),
    "emerge": PackageManager(
        name="emerge",
        update_cmd="emerge --sync",
        install_cmd="emerge {packages}",
    ),
}


class Container:
    """Automated container management.

    This class is the main entry point for creating and managing a single container
    instance. You can configure a container programmatically or load the
    configuration from a JSON file.

    The lifecycle (start, stop, provision) is managed automatically. You can hook
    into various stages of the lifecycle using the `hooks` attribute.

    Example:

    ```python
    from simplelxc import Container

    # Create and start a container
    c = Container(name_prefix="myapp", base_image="images:archlinux")
    c.start()
    c.execute("echo Hello World")
    c.stop()
    ```
    """

    _package_managers: dict[str, PackageManager] = _DEFAULT_PACKAGE_MANAGERS.copy()

    @classmethod
    def register_package_manager(cls, manager: PackageManager) -> None:
        """Register a new package manager or update an existing one.

        This allows adding support for new Linux distributions or overriding
        default behavior for existing ones.
        """
        cls._package_managers[manager.name] = manager

    def __init__(
        self,
        name_prefix: str,
        base_image: str = "images:archlinux",
        install_packages: list[str] | None = None,
        auto_delete: bool = True,
        version: str | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize a container configuration.

        This prepares the configuration but does not create the container yet.
        Call `start()` to actually create and start the container.

        The `name_prefix` is used to generate a unique container name.
        If `auto_delete` is True (default), the container will be deleted when
        `stop()` is called. `version` is used for caching the container image
        to speed up subsequent starts.
        """

        self._container_config = ContainerConfig(
            name_prefix=name_prefix,
            auto_delete=auto_delete,
            version=version,
            headless=kwargs.get("headless", False),
            image_name=kwargs.get("image_name"),
        )
        self._image_config = ImageConfig(
            base_image=base_image,
            install_packages=install_packages or [],
            force_rebuild=kwargs.get("force_rebuild", False),
            setup_scripts=kwargs.get("setup_scripts", []),
        )
        self._hooks = LifecycleHooks()

        # Runtime state
        self._handle: ContainerHandle | None = None
        self._container_name: str | None = None
        self._image_name: str | None = None
        self._cached_image: bool = False
        self._env: dict[str, str] = {}
        self._pkg_mgr: str | None = None

    @classmethod
    def _from_configs(
        cls,
        container_cfg: ContainerConfig,
        image_cfg: ImageConfig,
    ) -> Container:
        """Internal helper to construct a Container from config objects."""

        instance = cls.__new__(cls)
        instance._container_config = container_cfg
        instance._image_config = image_cfg
        instance._hooks = LifecycleHooks()

        # Runtime state
        instance._handle = None
        instance._container_name = None
        instance._image_name = None
        instance._cached_image = False
        instance._env = {}

        return instance

    @classmethod
    def from_file(cls, config_path: str | Path) -> Container:
        """Create a Container instance by loading configuration from a JSON file."""

        container_cfg, image_cfg = load_config_from_file(config_path)
        return cls._from_configs(container_cfg, image_cfg)

    @classmethod
    def from_dict(cls, config: dict[str, Any]) -> Container:
        """Create a Container instance from a dictionary configuration."""

        container_cfg, image_cfg = load_config_from_dict(config)
        return cls._from_configs(container_cfg, image_cfg)

    @property
    def hooks(self) -> LifecycleHooks:
        """Access lifecycle hooks for this container."""

        return self._hooks

    def start(self, **kwargs: Any) -> Container:
        """Start the container lifecycle.

        This will create the container, start it, provision it (install packages,
        run scripts), and execute any configured lifecycle hooks. If a cached image
        matching the version exists, it will be used to speed up creation.

        Configuration overrides can be passed as keyword arguments (e.g. `base_image`).
        These overrides apply only to this start attempt.

        Returns `self` to allow method chaining.
        """

        self._start_lifecycle(**kwargs)
        return self

    def stop(self) -> None:
        """Stop the container and perform cleanup.

        If `auto_delete` was set to True (default), the container will be deleted
        after stopping. Lifecycle hooks for stopping and deleting will be executed.
        """

        self._stop_lifecycle()
        self._handle = None
        if self._container_config.auto_delete:
            self._container_name = None

    def restart(self, wait_for_network: bool = True) -> None:
        """Restart the container.

        If `wait_for_network` is True, this method blocks until the container
        has network connectivity again.
        """
        if not self._handle:
            raise RuntimeError("Container not started")
        core.restart_container(self._handle, wait_for_network=wait_for_network)

    def delete(self) -> None:
        """Delete the container immediately.

        This forcefully stops the container if it is running and then deletes it.
        """
        if not self._handle:
            return
        core.delete_container(self._handle)
        self._handle = None
        self._container_name = None

    def exists(self) -> bool:
        """Check if the container exists."""
        if not self._handle:
            return False
        return core.container_exists(self._handle)

    @property
    def handle(self) -> ContainerHandle | None:
        """Get the container handle if running."""
        return self._handle

    @property
    def env(self) -> dict[str, str]:
        """Access the environment variable dictionary.

        Modifying this dictionary will affect all subsequent `execute` calls.
        """
        return self._env

    # =========================================================================
    # Execution & File Operations
    # =========================================================================

    def execute(
        self,
        command: str,
        cwd: str | None = None,
        environment: dict | None = None,
    ) -> CommandResult:
        """Execute a shell command inside the container.

        The command is executed via the container's shell. You can provide a
        working directory `cwd` and a dictionary of `environment` variables.

        Returns a `CommandResult` object containing the exit code, stdout, and stderr.
        """
        if not self._handle:
            raise RuntimeError("Container not started. Call .start() first.")

        # Merge with persistent environment
        env = self._env.copy()
        if environment:
            env.update(environment)

        return exec.execute_bash(self._handle, command, cwd=cwd, environment=env)

    def execute_script(self, local_path: str, args: str = "") -> CommandResult:
        """Copy a script from the host and execute it inside the container.

        The script is copied to the container, marked executable, run, and then deleted.
        Use `args` to pass arguments to the script.
        """
        if not self._handle:
            raise RuntimeError("Container not started. Call .start() first.")
        return exec.execute_script(self._handle, local_path, args)

    def exec_replace(
        self,
        command: str,
        cwd: str | None = None,
        environment: dict | None = None,
    ) -> None:
        """Execute command and replace current process (for interactive sessions).

        This uses the 'lxc' CLI to replace the current process with the
        command running in the container. Useful for interactive sessions.
        This function does not return - it replaces the current process!
        """
        if not self._handle:
            raise RuntimeError("Container not started. Call .start() first.")

        # Merge with persistent environment
        env = self._env.copy()
        if environment:
            env.update(environment)

        exec.exec_replace(self._handle, command, cwd=cwd, environment=env)

    def copy_from(self, container_path: str, host_path: str) -> None:
        """Copy a file or directory from the container to the host."""
        if not self._handle:
            raise RuntimeError("Container not started")
        files.copy_from(self._handle, container_path, host_path)

    def copy_to(self, host_path: str, container_path: str) -> None:
        """Copy a file or directory from the host to the container."""
        if not self._handle:
            raise RuntimeError("Container not started")
        files.copy_to(self._handle, host_path, container_path)

    def create_file(self, container_path: str, content: str) -> None:
        """Create a file inside the container with the given string content."""
        if not self._handle:
            raise RuntimeError("Container not started")
        files.create_file(self._handle, container_path, content)

    def realpath(self, pathname: str) -> str:
        """Resolve the given pathname to an absolute pathname.

        This will return the absolute path inside the container, specifically:
        * Expand `~` to the containers home directory.
        * Resolve absolute paths relative to the containers current working directory.
        """
        if not self._handle:
            raise RuntimeError("Container not started")
        return files.resolve_container_path(self._handle, pathname)

    # =========================================================================
    # Snapshots & Images
    # =========================================================================

    def snapshot(self, name: str) -> None:
        """Create a named snapshot of the current container state."""
        if not self._handle:
            raise RuntimeError("Container not started")
        snapshots.create_snapshot(self._handle, name)

    def restore(self, name: str) -> None:
        """Restore the container to a previously saved snapshot state."""
        if not self._handle:
            raise RuntimeError("Container not started")
        snapshots.restore_snapshot(self._handle, name)

    def delete_snapshot(self, name: str) -> None:
        """Delete a snapshot."""
        if not self._handle:
            raise RuntimeError("Container not started")
        snapshots.delete_snapshot(self._handle, name)

    @property
    def snapshots(self) -> list[str]:
        """Get a list of all snapshot names for this container."""
        if not self._handle:
            return []
        return snapshots.get_snapshot_names(self._handle)

    def create_image(self, image_name: str, version: str | None = None) -> None:
        """Save the current container state as a new local image.

        This allows you to use this state as a base for other containers.
        """
        if not self._handle:
            raise RuntimeError("Container not started")
        images.create_image(self._handle, image_name, version=version)

    # =========================================================================
    # Network
    # =========================================================================

    def map_port(self, container_port: int, host_port: int | None = None) -> int:
        """Expose a TCP port from the container to the host.

        If `host_port` is not specified, a random free port on the host will be
        assigned. Returns the port number on the host.
        """
        if not self._handle:
            raise RuntimeError("Container not started")
        return network.map_port(self._handle, container_port, host_port)

    def wait_for_network(self, timeout: int = 10) -> None:
        """Wait for container to have network connectivity."""
        if not self._handle:
            raise RuntimeError("Container not started")
        core.wait_for_network_ready(self._handle, timeout=timeout)

    @property
    def name(self) -> str | None:
        """Get the container name, if started."""
        return self._container_name

    @property
    def version(self) -> str | None:
        """Get the container version."""
        return self._container_config.version

    # =========================================================================
    # Lifecycle Implementation
    # =========================================================================

    def _start_lifecycle(self, **kwargs: Any) -> None:
        """Orchestrate a complete container lifecycle."""
        config = self._container_config
        image = self._image_config
        hooks = self._hooks

        # Apply overrides to a local copy of image config if needed
        if "base_image" in kwargs:
            image = ImageConfig(
                base_image=kwargs["base_image"],
                force_rebuild=image.force_rebuild,
                install_packages=image.install_packages,
                setup_scripts=image.setup_scripts,
            )

        # Determine image to use
        image_name, cached = self._determine_image(config, image)

        # Check for restart of existing container
        restarting = False
        container_name: str | None = None
        if self._container_name:
            existing_names = core.get_container_names()
            if self._container_name in existing_names:
                restarting = True
                container_name = self._container_name
                logger.debug(f"Restarting existing container '{container_name}'")
            else:
                self._container_name = None

        if restarting and container_name:
            will_create_cached_image = False
        else:
            # Decide whether we will create a cached image in this run
            will_create_cached_image = bool(config.version and not cached)

            # Create unique container name
            container_name = self._ensure_unique_name(config.name_prefix)
            logger.debug(f"Creating container '{container_name}' with {image_name}")

        assert container_name is not None

        # Build start plan and invoke before_start
        plan = StartPlan(
            container_name=container_name,
            image_name=image_name,
            version=config.version,
            will_use_cached_image=cached,
            will_create_cached_image=will_create_cached_image,
            auto_delete=config.auto_delete,
        )

        if hooks.before_start:
            hooks.before_start(plan)

        # Create container
        handle = core.create_handle(container_name)

        if restarting:
            core.start_container(handle)
        else:
            core.create_container(handle, image_name)

        # Update runtime instance
        self._handle = handle
        self._container_name = container_name
        self._image_name = image_name
        self._cached_image = cached

        # Hook: after_start
        if hooks.after_start:
            hooks.after_start(self)

        # Provision environment (skip if using cached image or restarting)
        if not cached and not restarting:
            logger.debug(f"{container_name}: Provisioning environment")

            if hooks.before_provision:
                hooks.before_provision(self)

            self._setup_environment(image)

            if hooks.after_provision:
                hooks.after_provision(self)

            # Create cached image if version specified
            if config.version:
                base_name = (
                    config.image_name if config.image_name else config.name_prefix
                )
                cache_image_name = f"{base_name}-{config.version}"
                logger.debug(
                    f"{container_name}: Creating cached image '{cache_image_name}'"
                )

                if hooks.before_image_creation:
                    hooks.before_image_creation(self)

                images.create_image(handle, cache_image_name, version=config.version)

                if hooks.after_image_creation:
                    hooks.after_image_creation(self)

        # Final readiness hook
        if hooks.container_ready:
            hooks.container_ready(self)

        logger.debug(f"{container_name}: Container ready")

    def _stop_lifecycle(self) -> None:
        """Stop and optionally delete a container."""
        if not self._handle:
            return

        hooks = self._hooks

        if hooks.before_stop:
            hooks.before_stop(self)

        logger.debug(f"{self.name}: Stopping container")

        # Explicitly stop the container
        core.stop_container(self._handle)

        if hooks.after_stop:
            hooks.after_stop(self)

        # Use auto_delete from config
        should_delete = self._container_config.auto_delete

        if should_delete:
            if hooks.before_delete:
                hooks.before_delete(self)

            core.delete_container(self._handle)
            logger.debug(f"{self.name}: Container deleted")

            if hooks.after_delete:
                hooks.after_delete(self)
        else:
            logger.debug(f"{self.name}: Container kept (auto_delete=False)")

    @staticmethod
    def _determine_image(
        config: ContainerConfig, image: ImageConfig
    ) -> tuple[str, bool]:
        """Determine which image to use.

        Returns:
            Tuple of (image_name, is_cached)
        """
        # Force rebuild - use base image
        if image.force_rebuild:
            logger.debug("Force rebuild enabled, using base image")
            return image.base_image, False

        # Check for cached image
        if config.version:
            # Use image_name if provided, otherwise fall back to name_prefix
            # This allows multiple containers to share the same cached base image
            base_name = config.image_name if config.image_name else config.name_prefix
            cache_image_name = f"{base_name}-{config.version}"
            logger.debug(f"Checking for cached image: {cache_image_name}")

            if images.image_exists(cache_image_name):
                image_ver = images.get_image_version(cache_image_name)
                logger.debug(
                    f"Found cached image, version: {image_ver} (need: {config.version})"
                )

                if image_ver == config.version:
                    logger.debug(f"Using cached image: {cache_image_name}")
                    return f"local:{cache_image_name}", True
                else:
                    logger.debug(
                        f"Cached image out of date: {image_ver} != {config.version}"
                    )
            else:
                logger.debug(f"Cached image not found: {cache_image_name}")
        else:
            logger.debug("No version specified, skipping cache check")

        logger.debug(f"Using base image: {image.base_image}")
        return image.base_image, False

    @staticmethod
    def _ensure_unique_name(prefix: str) -> str:
        """Ensure container name is unique."""
        existing = core.get_container_names()
        if prefix not in existing:
            return prefix

        counter = 1
        while f"{prefix}-{counter}" in existing:
            counter += 1
        return f"{prefix}-{counter}"

    def install_package(self, package_name: str) -> None:
        """Install a single package.

        See `install_packages` for details on supported package managers and behavior.
        """
        self.install_packages([package_name])

    def install_packages(self, packages: list[str]) -> None:
        """Install a list of packages using the container's package manager.

        This method detects the operating system's package manager and installs
        the requested packages.

        1. Checks for package manager binaries in the container.
        2. Automatically updates the package database before installation.
        3. Installs the packages in non-interactive mode.

        Supported Package Managers (default):
        -   `apt-get` (Debian, Ubuntu, etc.)
        -   `pacman` (Arch Linux, Manjaro)
        -   `apk` (Alpine, Chimera)
        -   `dnf` (Fedora, RHEL 8+, CentOS 8+)
        -   `yum` (RHEL 7, CentOS 7)
        -   `zypper` (OpenSUSE, SLES)
        -   `microdnf` (UBI, minimal Fedora)
        -   `xbps` (Void Linux)
        -   `emerge` (Gentoo)

        You can add support for other package managers using
        `Container.register_package_manager()`.

        For example:

        ```python
        container.install_packages(["git", "python"])
        ```

        """
        if not self._handle:
            raise RuntimeError("Container not started")

        if not packages:
            return

        package_list = " ".join(packages)
        logger.debug(f"{self.name}: Installing packages: {package_list}")

        mgr_name = self._detect_package_manager()
        if not mgr_name:
            logger.error(f"{self.name}: No supported package manager found")
            raise RuntimeError(f"{self.name}: No recognised package manager found.")

        mgr = self._package_managers[mgr_name]

        # Update package database
        if mgr.update_cmd:
            logger.debug(f"{self.name}: Updating package database with {mgr.name}")
            exec.execute_bash(self._handle, mgr.update_cmd, cwd="/")

        # Install packages
        install_cmd = mgr.install_cmd.format(packages=package_list)
        logger.debug(f"{self.name}: Installing with {mgr.name}: {install_cmd}")

        result = exec.execute_bash(self._handle, install_cmd, cwd="/")
        if result.failed:
            raise RuntimeError(
                f"{self.name}: Package installation failed.\n"
                f"Command: {install_cmd}\n"
                f"Error: {result.stderr}"
            )

    def _detect_package_manager(self) -> str | None:
        """Detect and cache the package manager."""
        if self._pkg_mgr:
            return self._pkg_mgr

        if not self._handle:
            return None

        for mgr in self._package_managers.values():
            binary = mgr.get_binary()
            if exec.execute_bash(self._handle, f"command -v {binary}").success:
                self._pkg_mgr = mgr.name
                return mgr.name
        return None

    def _setup_environment(self, image: ImageConfig) -> None:
        """Setup the container environment."""
        if not self._handle:
            raise RuntimeError("Container has no handle")

        # Install packages
        if image.install_packages:
            self.install_packages(image.install_packages)

        # Run setup scripts
        for script_path in image.setup_scripts:
            logger.debug(f"{self.name}: Running setup script: {script_path}")
            self.execute_script(script_path)

        # Restart container after setup
        logger.debug(f"{self.name}: Restarting after setup")
        core.restart_container(self._handle)

    # =========================================================================
    # Wait Operations
    # =========================================================================

    def wait_for(
        self,
        condition: Callable[[], bool],
        timeout: int = 30,
        check_interval: float = 0.5,
    ) -> bool:
        """Wait until the provided `condition` function returns True.

        Returns True if the condition was met before the timeout, False otherwise.
        """
        start = time.time()
        while time.time() - start < timeout:
            try:
                if condition():
                    return True
            except Exception as e:
                logger.debug(f"Condition check failed: {e}")
            time.sleep(check_interval)
        return False

    def wait_for_command(
        self,
        command: str,
        timeout: int = 30,
        check_interval: float = 0.5,
    ) -> bool:
        """Wait until a command returns exit code 0.

        Useful for polling until a service is ready.
        Returns True if the command succeeded before the timeout.
        """

        def check():
            result = self.execute(command)
            return result.success

        return self.wait_for(check, timeout=timeout, check_interval=check_interval)

    def wait_for_port(
        self,
        port: int,
        host: str = "localhost",
        timeout: int = 30,
    ) -> bool:
        """Wait until a TCP port is listening inside the container.

        Returns True if the port is open before the timeout.
        """
        command = f"nc -z {host} {port}"
        return self.wait_for_command(command, timeout=timeout)

    def wait_for_http(
        self,
        url: str,
        expected_status: int = 200,
        timeout: int = 30,
        check_interval: float = 0.5,
    ) -> bool:
        """Wait for a HTTP GET request to return the expected status code.

        Uses `curl` inside the container.
        """

        def check():
            # -o /dev/null : suppress output
            # -s : silent
            # -w "%{http_code}" : write http code to stdout
            cmd = f"curl -s -o /dev/null -w '%{{http_code}}' {url}"
            result = self.execute(cmd)
            if result.failed:
                return False
            try:
                code = int(result.stdout.strip())
                return code == expected_status
            except ValueError:
                return False

        return self.wait_for(check, timeout=timeout, check_interval=check_interval)

    # =========================================================================
    # Working Directory
    # =========================================================================

    @property
    def cwd(self) -> str:
        """Get or set the current working directory for commands executed in this
        container.
        """
        if not self._handle:
            raise RuntimeError("Container not started")
        return self._handle.cwd

    @cwd.setter
    def cwd(self, dirname: str):
        """Set current working directory."""
        if not self._handle:
            raise RuntimeError("Container not started")
        if dirname != self._handle.cwd:
            logger.debug(f"Changed CWD to '{dirname}'")
        self._handle.cwd = dirname

    def __enter__(self) -> Container:
        """Context manager entry. Calls `start()`."""

        return self.start()

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit. Calls `stop()`."""

        self.stop()
