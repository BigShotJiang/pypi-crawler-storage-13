"""Development helpers for the project.

The idea being __main__.py and scripts directory can simply
be excluded from the package build to remove all the
development utils.
"""

from __future__ import annotations

import os
import subprocess
import sys


def _run(cmd: list[str] | str, env: dict[str, str] | None = None) -> None:
    """Run a command, exiting with its status on failure."""
    if isinstance(cmd, str):
        cmd = cmd.split()

    run_env = os.environ.copy() if env else None
    if env and run_env:
        run_env.update(env)

    try:
        subprocess.run(cmd, check=True, env=run_env)
    except subprocess.CalledProcessError as exc:
        sys.exit(exc.returncode)


def build() -> None:
    """Run everything necessary to fully update, test and
    build the distribution package."""
    tests()
    _run(["uv", "build"])


def check() -> None:
    """Runs a lint check, updates the typehints, updates the
    API docs and runs just the __fast__ unit tests, i.e.
    the unit tests that don't perform any container
    operations."""
    tests(fast_only=True)


def _lint() -> None:
    """Run a lint check"""
    _run("uv run ruff check -q --fix")
    print("BUILD: The lint check completed successfully.")


def _docs() -> None:
    """Generate or update the class library API docs"""
    _run("uv run pymarkdoc simplelxc -o README.md")
    print("BUILD: The project documentation in README.md has been updated")


def tests(fast_only=False) -> None:
    """Runs the check command, and then additionally runs
    the FULL unit test suite."""
    _lint()
    _docs()
    if fast_only:
        _run("uv run pytest", env={"SIMPLELXC_FAST_TESTS": "true"})
        print(
            "BUILD: Tests involving LXC containers have "
            "been skipped. Use `tests` instead of `check` "
            "to run ALL tests."
        )
    else:
        _run("uv run pytest")
        print("BUILD: All tests have completed successfully.")
