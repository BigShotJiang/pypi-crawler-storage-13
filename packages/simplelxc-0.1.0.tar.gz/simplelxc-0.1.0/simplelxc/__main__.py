"""Command-line interface for simplelxc development tools."""

from __future__ import annotations

import inspect
import sys

import simplelxc._scripts.build as run


def _get_commands() -> list[str]:
    commands = [
        name
        for name in dir(run)
        if not name.startswith("_") and callable(getattr(run, name))
    ]
    return commands


def _get_command_help(name: str) -> str:
    func = getattr(run, name, None)
    if func is None:
        return ""

    doc = inspect.getdoc(func)
    if not doc:
        return "No description available."

    return doc


def main() -> None:
    commands = _get_commands()
    if len(sys.argv) < 2:
        print("Usage: uv run simplelxc <command>")
        print("Available commands:")
        for name in sorted(commands):
            help_text = _get_command_help(name)
            lines = help_text.splitlines()
            if lines:
                print(f"  {name}:")
                for line in lines:
                    print(f"    {line}")
        sys.exit(0)

    command = sys.argv[1]

    if command in commands:
        getattr(run, command)()

    else:
        print(f"Unknown command: {command}", file=sys.stderr)
        print(f"Available commands: {', '.join(sorted(commands))}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
