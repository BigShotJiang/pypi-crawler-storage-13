"""Logging utilities for simplelxc.

This module exposes a standard library logger named ``"simplelxc"``
without configuring any handlers by default. Applications using
simplelxc are responsible for configuring logging as they see fit.

If the ``SLXC_LOG`` environment variable is set, all logging will be
sent to the console at DEBUG level.
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger("simplelxc")

if os.environ.get("SLXC_LOG"):
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    logger.setLevel(logging.DEBUG)
else:
    logger.addHandler(logging.NullHandler())
