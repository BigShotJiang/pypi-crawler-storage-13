# Changelog

## v0.1.0 (21st November 2025)
* Initial release.
