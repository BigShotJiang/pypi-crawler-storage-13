# SimpleLXC

[![PyPI - Version](https://img.shields.io/pypi/v/simplelxc.svg)](https://pypi.org/project/simplelxc)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/simplelxc.svg)](https://pypi.org/project/simplelxc)
[![License](https://img.shields.io/pypi/l/simplelxc.svg)](https://git.sr.ht/~gk/simplelxc/tree/LICENSE)

Easily setup LXC containers for automated testing and interactive use of headless or terminal applications in isolated environments.

## Installation

```bash
pip install simplelxc
```
```bash
# or with uv
uv add simplelxc
```

## Requirements

- __Linux only__
- Python 3.10+
- LXD installed and initialised on your system

## Quick Start

SimpleLXC provides a simple API for automated container management:

```python
from simplelxc import Container

# Create a container
container = Container(
    name_prefix="myapp",
    base_image="images:archlinux",
    install_packages=["python", "git"],
)

# Start the container
container.start()

# Use it
container.execute("python --version")
container.copy_to("./myproject", "~/project")
container.execute("cd ~/project && python main.py")
container.execute_script("scripts/setup_db.sh", args="--force")

# Stop and delete it
container.stop()
```

Or load container configuration from a file:

```python
from simplelxc import Container

container = Container.from_file("container.json")
container.start()
container.execute("python --version")
...
```

### Context Manager

You can use the container as a context manager to ensure it is stopped and cleaned up automatically, even if errors occur:

```python
with Container(name_prefix="myapp") as c:
    c.execute("echo 'Doing work...'")
# Container stops and deletes automatically here
```


### Lifecycle Hooks

Containers expose a small set of lifecycle hooks that run at
well-defined points while a container is being created, provisioned,
and shut down. Hooks are configured on the ``Container.hooks``
attribute and are simple callables.

Core hooks:

- `before_start(plan)`
  - Called before any container is created or started.
  - ``plan`` is a small object with:
    - ``container_name``
    - ``image_name``
    - ``version``
    - ``will_use_cached_image``
    - ``will_create_cached_image``
    - ``auto_delete``
- `after_start(container)`
  - Called right after the container has been created and started,
    before any provisioning.
- `before_provision(container)` / `after_provision(container)`
  - Called around environment provisioning (package installation and
    setup scripts) when building a new environment (i.e. when no
    suitable cached image exists).
- `before_image_creation(container)` / `after_image_creation(container)`
  - Called when creating a cached LXD image after provisioning, if
    versioning/caching is enabled.
- `container_ready(container)`
  - Called once the container is fully usable:
    - For cached runs: after ``after_start``.
    - For provisioned runs: after ``after_provision`` and any
      image-creation hooks.
- `before_stop(container)` / `after_stop(container)`
  - Called before and after the container is explicitly stopped.
- `before_delete(container)` / `after_delete(container)`
  - Called before and after the container is deleted, when deletion
    occurs (for example, when ``auto_delete=True``).

Example:

```python
from simplelxc import Container

container = Container.from_file("container.json")

def log_plan(plan):
    print(f"Will create {plan.container_name} from {plan.image_name}")

def check_created(container):
    container.execute("echo 'Container created!'")

def check_provisioned(container):
    container.execute("echo 'Provisioning complete!'")

def save_logs(container):
    container.copy_from("~/logs", "./logs")

def on_ready(container):
    container.execute("echo 'Ready!'")

# Register hooks
container.hooks.before_start = log_plan
container.hooks.after_start = check_created
container.hooks.after_provision = check_provisioned
container.hooks.before_stop = save_logs
container.hooks.container_ready = on_ready

container.start()
```

### Configuration Files

Define container configuration in JSON files for easy management and version control:

**container.json:**
```json
{
  "container": {
    "name_prefix": "myapp",
    "auto_delete": true,
    "version": "1.0"
  },
  "image": {
    "base_image": "images:archlinux",
    "install_packages": ["python", "nodejs", "git"]
  }
}
```

**Python code:**
```python
from simplelxc import Container

# Load and start
container = Container.from_file("container.json")
container.start()

# Use it
container.execute("python --version")
```

This keeps static configuration in JSON files while keeping dynamic behavior (hooks) in Python code.

### Image Caching

SimpleLXC automatically caches container images based on version strings, significantly speeding up subsequent container creations:

```python
from simplelxc import Container

# First run: sets up environment and caches image
container = Container(
    name_prefix="myapp",
    base_image="images:archlinux",
    install_packages=["python", "git"],
    version="1.0",
)
container.start()

# Subsequent runs with same version: uses cached image (much faster!)
container2 = Container(
    name_prefix="myapp",
    base_image="images:archlinux",
    install_packages=["python", "git"],
    version="1.0",
)
container2.start()
```

## System Management

SimpleLXC provides top-level utilities for inspecting and cleaning up LXD resources system-wide:

```python
import simplelxc

# List all containers
print(simplelxc.get_container_names())

# List all local images
print(simplelxc.get_image_names())

# Check an image version
version = simplelxc.get_image_version("my-image")
if version:
    print(f"Image version: {version}")

# Delete all containers starting with "test-env"
count = simplelxc.prune_containers("test-env")
print(f"Deleted {count} containers")
```

## License


MIT License - see LICENSE file for details.

## Credits

SimpleLXC is built on top of [pylxd](https://github.com/lxc/pylxd), the Python library for LXD.
