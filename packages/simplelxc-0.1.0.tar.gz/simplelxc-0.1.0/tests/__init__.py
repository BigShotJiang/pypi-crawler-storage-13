"""SimpleLXC tests."""
