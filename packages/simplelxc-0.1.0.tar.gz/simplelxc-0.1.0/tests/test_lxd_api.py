"""Unit tests for simplelxc.lxd module functions.

This test suite covers the low-level container API functions in simplelxc.lxd.
Tests are organized to share a single container across multiple tests to avoid
the overhead of creating/destroying containers repeatedly.

Test structure:
- TestContainerCore: Tests for core lifecycle operations
- TestContainerExec: Tests for command execution
- TestContainerFiles: Tests for file operations
- TestContainerImages: Tests for image management
- TestContainerNetwork: Tests for network/port operations
- TestContainerSnapshots: Tests for snapshot operations
"""

import os

import pytest

pytestmark = pytest.mark.skipif(
    os.getenv("SIMPLELXC_FAST_TESTS") is not None, reason="Skipping LXD tests"
)

# ruff: noqa: E402
import shutil
import sys
import tempfile
from pathlib import Path
from uuid import uuid4

# Add tests directory to path for conftest imports
sys.path.insert(0, str(Path(__file__).parent))
from conftest import LXC_TEST_PREFIX, requires_lxd

from simplelxc._lxd import core, exec, files, images, network, snapshots
from simplelxc._lxd.types import ContainerError
from simplelxc.system import delete_image, get_image_names, image_exists


class TestContainerCore:
    """Test core container lifecycle operations.

    These tests share a single container to minimize creation overhead.
    """

    @pytest.fixture(scope="class")
    def shared_handle(self):
        """Create a shared container handle for all core tests."""
        # Create container
        name = f"{LXC_TEST_PREFIX}-core-{uuid4().hex[:8]}"
        handle = core.create_handle(name)
        core.create_container(handle, "images:archlinux")

        yield handle

        # Cleanup
        try:
            if core.container_exists(handle):
                core.delete_container(handle)
        except Exception:
            pass

    @requires_lxd
    def test_create_handle(self):
        """Test creating a container handle."""
        name = f"{LXC_TEST_PREFIX}-handle-test"
        handle = core.create_handle(name)

        assert handle.name == name
        assert handle._client is not None

    @requires_lxd
    def test_exists(self, shared_handle):
        """Test checking if a container exists."""
        # Container should exist
        assert core.container_exists(shared_handle) is True

        # Non-existent container should return False
        fake_handle = core.create_handle(
            f"{LXC_TEST_PREFIX}-nonexistent-{uuid4().hex[:8]}"
        )
        assert core.container_exists(fake_handle) is False

    @requires_lxd
    def test_get_container_names(self, shared_handle):
        """Test listing all containers."""
        containers = core.get_container_names()

        # Should return a list
        assert isinstance(containers, list)

        # Should include our test container
        assert shared_handle.name in containers

    @requires_lxd
    def test_restart(self, shared_handle):
        """Test restarting a container."""
        # Make sure container exists
        if not core.container_exists(shared_handle):
            return

        # Force refresh instance state
        instance = shared_handle._client.instances.get(shared_handle.name)
        shared_handle._instance = instance  # Update cached instance

        # Restart should work without errors (even if not running)
        core.restart_container(shared_handle, wait_for_network=False)

        # Container should still exist
        assert core.container_exists(shared_handle) is True

    @requires_lxd
    def test_wait_for_network_ready(self, shared_handle):
        """Test waiting for network to be ready."""
        # Force refresh instance state and check if running
        instance = shared_handle._client.instances.get(shared_handle.name)
        shared_handle._instance = instance  # Update cached instance

        if instance.status_code != 103:  # Not running
            # Restart to ensure container is running
            core.restart_container(shared_handle, wait_for_network=False)
            # Refresh again after restart
            instance = shared_handle._client.instances.get(shared_handle.name)
            shared_handle._instance = instance

        # This should complete without error since container is running
        core.wait_for_network_ready(shared_handle, timeout=5)

    @requires_lxd
    def test_delete_all_with_prefix(self):
        """Test deleting all containers with a specific prefix."""
        # Create a couple of test containers with a unique prefix
        unique_prefix = f"deltest-{uuid4().hex[:8]}"
        handle1 = core.create_handle(f"{unique_prefix}-1")
        handle2 = core.create_handle(f"{unique_prefix}-2")

        try:
            core.create_container(handle1, "images:archlinux")
            core.create_container(handle2, "images:archlinux")

            # Verify they exist
            assert core.container_exists(handle1) is True
            assert core.container_exists(handle2) is True

            # Delete all with prefix
            deleted_count = core.delete_containers_by_prefix(unique_prefix)

            # Should have deleted 2 containers
            assert deleted_count == 2

            # Containers should no longer exist
            assert core.container_exists(handle1) is False
            assert core.container_exists(handle2) is False

        finally:
            # Cleanup in case test fails
            for h in [handle1, handle2]:
                try:
                    if core.container_exists(h):
                        core.delete_container(h)
                except Exception:
                    pass


class TestContainerExec:
    """Test command execution in containers.

    Uses a shared container for all exec tests.
    """

    @pytest.fixture(scope="class")
    def shared_handle(self):
        """Create a shared container for exec tests."""
        name = f"{LXC_TEST_PREFIX}-exec-{uuid4().hex[:8]}"
        handle = core.create_handle(name)
        core.create_container(handle, "images:archlinux")

        yield handle

        try:
            if core.container_exists(handle):
                core.delete_container(handle)
        except Exception:
            pass

    @requires_lxd
    def test_execute(self, shared_handle):
        """Test executing a command as a list of arguments."""
        result = exec.execute(shared_handle, ["echo", "hello world"])

        assert result.returncode == 0
        assert result.success is True
        assert result.failed is False
        assert "hello world" in result.stdout

    @requires_lxd
    def test_execute_bash(self, shared_handle):
        """Test executing a bash command as a string."""
        result = exec.execute_bash(shared_handle, "echo 'test' | tr a-z A-Z")

        assert result.returncode == 0
        assert result.success is True
        assert "TEST" in result.stdout

    @requires_lxd
    def test_execute_with_cwd(self, shared_handle):
        """Test executing a command with a working directory."""
        # Create a test directory first
        exec.execute_bash(shared_handle, "mkdir -p /tmp/testdir")

        # Execute pwd in that directory
        result = exec.execute(shared_handle, ["pwd"], cwd="/tmp/testdir")

        assert result.returncode == 0
        assert "/tmp/testdir" in result.stdout

    @requires_lxd
    def test_execute_with_environment(self, shared_handle):
        """Test executing a command with environment variables."""
        result = exec.execute_bash(
            shared_handle,
            "echo $TEST_VAR",
            environment={"TEST_VAR": "test_value"},
        )

        assert result.returncode == 0
        assert "test_value" in result.stdout

    @requires_lxd
    def test_execute_with_environment_list_args(self, shared_handle):
        """Test executing a list command with environment variables."""
        result = exec.execute(
            shared_handle,
            ["sh", "-c", "echo $TEST_VAR"],
            environment={"TEST_VAR": "list_value"},
        )

        assert result.returncode == 0
        assert "list_value" in result.stdout

    @requires_lxd
    def test_execute_bash_with_cwd_and_env(self, shared_handle):
        """Test execute_bash with both cwd and environment."""
        exec.execute_bash(shared_handle, "mkdir -p /tmp/envtest")

        result = exec.execute_bash(
            shared_handle,
            "pwd && echo $MY_VAR",
            cwd="/tmp/envtest",
            environment={"MY_VAR": "myvalue"},
        )

        assert result.returncode == 0
        assert "/tmp/envtest" in result.stdout
        assert "myvalue" in result.stdout

    @requires_lxd
    def test_execute_script_success(self, shared_handle, tmp_path: Path):
        """Test executing a script that succeeds."""
        script = tmp_path / "ok.sh"
        script.write_text("#!/bin/sh\necho script-ok\n", encoding="utf-8")

        result = exec.execute_script(shared_handle, str(script))

        assert result.returncode == 0
        assert result.success is True
        assert "script-ok" in result.stdout

    @requires_lxd
    def test_execute_script_failure_raises(self, shared_handle, tmp_path: Path):
        """Test executing a script that fails raises RuntimeError."""
        script = tmp_path / "fail.sh"
        script.write_text("#!/bin/sh\n>&2 echo fail\nexit 1\n", encoding="utf-8")

        with pytest.raises(RuntimeError):
            exec.execute_script(shared_handle, str(script))


class TestContainerFiles:
    """Test file transfer operations.

    Uses a shared container for all file tests.
    """

    @pytest.fixture(scope="class")
    def shared_handle(self):
        """Create a shared container for file tests."""
        name = f"{LXC_TEST_PREFIX}-files-{uuid4().hex[:8]}"
        handle = core.create_handle(name)
        core.create_container(handle, "images:archlinux")

        yield handle

        try:
            if core.container_exists(handle):
                core.delete_container(handle)
        except Exception:
            pass

    @requires_lxd
    def test_copy_file_to_file(self, shared_handle):
        """Host to container: cp foo.txt bar.txt"""

        # Create a temp file on host
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
            host_path = f.name
            test_content = f"test-content-{uuid4()}"
            f.write(test_content)

        try:
            # Copy to container
            container_path = f"/tmp/test_file_{uuid4().hex[:8]}.txt"
            files.copy_to(shared_handle, host_path, container_path)

            # Verify file exists with correct content
            result = exec.execute_bash(shared_handle, f"cat {container_path}")
            assert result.returncode == 0
            assert test_content in result.stdout

        finally:
            os.unlink(host_path)

    @requires_lxd
    def test_copy_file_to_directory(self, shared_handle):
        """Host to container: cp foo.txt bar/"""
        # Create a temp file on host
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
            host_path = f.name
            test_content = f"test-content-{uuid4()}"
            f.write(test_content)

        try:
            # Copy to container
            expected_path = f"/tmp/{os.path.basename(f.name)}"
            container_path = "/tmp/"
            files.copy_to(shared_handle, host_path, container_path)

            # Verify file exists with correct content
            result = exec.execute_bash(shared_handle, f"cat {expected_path}")
            assert result.returncode == 0
            assert test_content in result.stdout

        finally:
            os.unlink(host_path)

    @requires_lxd
    def test_copy_to_tilde_path(self, shared_handle):
        """Host to container: cp foo.txt ~/bar.txt"""
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
            host_path = f.name
            test_content = f"tilde-content-{uuid4()}"
            f.write(test_content)

        try:
            # Copy to a path using ~ expansion
            files.copy_to(shared_handle, host_path, "~/tilde_test.txt")

            # Verify file exists at $HOME/tilde_test.txt
            result = exec.execute_bash(shared_handle, "cat $HOME/tilde_test.txt")
            assert result.returncode == 0
            assert test_content in result.stdout

        finally:
            os.unlink(host_path)

    @requires_lxd
    def test_copy_file_from_file(self, shared_handle):
        """Container to host: cp foo.txt bar.txt"""
        # Create a file in container
        container_path = f"/tmp/from_container_{uuid4().hex[:8]}.txt"
        test_content = f"container-content-{uuid4()}"
        files.create_file(shared_handle, container_path, test_content)

        # Copy to host
        with tempfile.TemporaryDirectory() as temp_dir:
            host_path = str(Path(temp_dir) / "copied_file.txt")
            files.copy_from(shared_handle, container_path, host_path)

            # Verify file exists with correct content
            assert os.path.exists(host_path)
            with open(host_path) as f:
                content = f.read()
            assert test_content in content

    @requires_lxd
    def test_copy_directory_from_file(self, shared_handle):
        """Container to host: cp foo.txt bar/"""
        # Create a file in container
        container_path = f"/tmp/from_container_{uuid4().hex[:8]}.txt"
        test_content = f"container-content-{uuid4()}"
        files.create_file(shared_handle, container_path, test_content)

        # Copy to host
        with tempfile.TemporaryDirectory() as temp_dir:
            host_path = f"{temp_dir}/"
            expected_path = str(Path(temp_dir) / os.path.basename(container_path))
            files.copy_from(shared_handle, container_path, host_path)

            # Verify file exists with correct content
            assert os.path.exists(expected_path)
            with open(expected_path) as f:
                content = f.read()
            assert test_content in content

    @requires_lxd
    def test_create_file(self, shared_handle):
        """Test creating a file with content in container."""
        container_path = f"/tmp/created_file_{uuid4().hex[:8]}.txt"
        test_content = f"created-content-{uuid4()}"

        files.create_file(shared_handle, container_path, test_content)

        # Verify file exists with correct content
        result = exec.execute_bash(shared_handle, f"cat {container_path}")
        assert result.returncode == 0
        assert test_content in result.stdout

    @requires_lxd
    def test_copy_to_directory(self, shared_handle):
        """Test copying a directory from host to container."""
        # Create a temp directory on host with files
        host_dir = tempfile.mkdtemp(prefix=f"testdir_{uuid4().hex[:8]}_")

        try:
            # Create test files
            with open(os.path.join(host_dir, "file1.txt"), "w") as f:
                f.write("content1")
            with open(os.path.join(host_dir, "file2.txt"), "w") as f:
                f.write("content2")

            # Copy to container
            container_dest = "/tmp"
            files.copy_to(shared_handle, host_dir, container_dest)

            # Verify directory and files exist
            dir_name = os.path.basename(host_dir)
            result = exec.execute_bash(
                shared_handle, f"test -d {container_dest}/{dir_name}"
            )
            assert result.returncode == 0

            result = exec.execute_bash(
                shared_handle, f"cat {container_dest}/{dir_name}/file1.txt"
            )
            assert result.returncode == 0
            assert "content1" in result.stdout

        finally:
            shutil.rmtree(host_dir)

    @requires_lxd
    def test_copy_from_directory(self, shared_handle):
        """Test copying a directory from container to host."""
        # Create a directory in container
        container_dir = f"/tmp/containerdir_{uuid4().hex[:8]}"
        exec.execute_bash(shared_handle, f"mkdir -p {container_dir}")
        files.create_file(shared_handle, f"{container_dir}/file.txt", "dir-content")

        # Copy to host
        with tempfile.TemporaryDirectory() as temp_dir:
            files.copy_from(shared_handle, container_dir, temp_dir)

            # Verify directory structure
            dir_name = os.path.basename(container_dir)
            copied_dir = os.path.join(temp_dir, dir_name)
            assert os.path.isdir(copied_dir)

            file_path = os.path.join(copied_dir, "file.txt")
            assert os.path.exists(file_path)
            with open(file_path) as f:
                assert "dir-content" in f.read()


class TestContainerImages:
    """Test image management operations.

    Note: Image tests use their own containers since they need to
    create/delete images from containers.
    """

    @requires_lxd
    def test_image_lifecycle(self):
        """Test creating, checking existence, and deleting an image."""
        # Create a temporary container to make an image from
        name = f"{LXC_TEST_PREFIX}-img-{uuid4().hex[:8]}"
        handle = core.create_handle(name)
        core.create_container(handle, "images:archlinux")

        # Unique image name to avoid conflicts
        image_name = f"test-image-{uuid4().hex[:8]}"

        try:
            # Create image from container
            images.create_image(handle, image_name, version="1.0.0")

            # Check image exists (low-level API)
            assert images.image_exists(image_name) is True

            # Get version
            version = images.get_image_version(image_name)
            assert version == "1.0.0"

            # List all images (should include our image)
            all_images = images.get_image_names()
            assert image_name in all_images

            # Manager facade should see the same image
            assert image_exists(image_name) is True
            manager_images = get_image_names()
            assert image_name in manager_images

            # Delete image via Manager
            delete_image(image_name)

            # Image should no longer exist
            assert images.image_exists(image_name) is False
            assert image_exists(image_name) is False

        finally:
            # Cleanup container
            try:
                if core.container_exists(handle):
                    core.delete_container(handle)
            except Exception:
                pass

            # Cleanup image if it still exists
            try:
                if images.image_exists(image_name):
                    images.delete_image(image_name)
            except Exception:
                pass

    @requires_lxd
    def test_list_all_images(self):
        """Test listing all images."""
        all_images = images.get_image_names()

        # Should return a list
        assert isinstance(all_images, list)


class TestContainerNetwork:
    """Test network operations.

    Uses a shared container for network tests.
    """

    @pytest.fixture(scope="class")
    def shared_handle(self):
        """Create a shared container for network tests."""
        name = f"{LXC_TEST_PREFIX}-net-{uuid4().hex[:8]}"
        handle = core.create_handle(name)
        core.create_container(handle, "images:archlinux")

        yield handle

        try:
            if core.container_exists(handle):
                core.delete_container(handle)
        except Exception:
            pass

    @requires_lxd
    def test_map_port(self, shared_handle):
        """Test mapping a container port to a host port."""
        # Map port (auto-assign host port)
        container_port = 8080
        host_port = network.map_port(shared_handle, container_port)

        # Should return a valid port number
        assert isinstance(host_port, int)
        assert host_port > 0
        assert host_port < 65536

    @requires_lxd
    def test_map_port_with_specific_host_port(self, shared_handle):
        """Test mapping with a specific host port."""
        # Use a high port number to avoid conflicts
        container_port = 9000
        specific_host_port = 45678

        host_port = network.map_port(shared_handle, container_port, specific_host_port)

        # Should return the requested port
        assert host_port == specific_host_port


class TestContainerSnapshots:
    """Test snapshot operations.

    Uses a shared container for snapshot tests.
    """

    @pytest.fixture(scope="class")
    def shared_handle(self):
        """Create a shared container for snapshot tests."""
        name = f"{LXC_TEST_PREFIX}-snap-{uuid4().hex[:8]}"
        handle = core.create_handle(name)
        core.create_container(handle, "images:archlinux")

        yield handle

        try:
            if core.container_exists(handle):
                core.delete_container(handle)
        except Exception:
            pass

    @requires_lxd
    @pytest.mark.filterwarnings("ignore::UserWarning:pylxd.models._model")
    def test_snapshot_lifecycle(self, shared_handle):
        """Test creating, listing, restoring, and deleting snapshots."""
        snapshot_name = f"snap-{uuid4().hex[:8]}"

        # Create a test file in /root (persistent location) before snapshot
        test_file = f"/root/test_{uuid4().hex[:8]}.txt"
        files.create_file(shared_handle, test_file, "original content")

        # Create snapshot
        snapshots.create_snapshot(shared_handle, snapshot_name)

        # Verify snapshot exists in list
        snap_list = snapshots.get_snapshot_names(shared_handle)
        assert snapshot_name in snap_list

        # Modify the file
        files.create_file(shared_handle, test_file, "modified content")

        # Verify file is modified
        result = exec.execute_bash(shared_handle, f"cat {test_file}")
        assert "modified content" in result.stdout

        # Restore snapshot (this stops the container)
        snapshots.restore_snapshot(shared_handle, snapshot_name)

        # Restart the container after restore
        core.restart_container(shared_handle)

        # Verify file is back to original
        result = exec.execute_bash(shared_handle, f"cat {test_file}")
        assert "original content" in result.stdout

        # Delete snapshot
        snapshots.delete_snapshot(shared_handle, snapshot_name)

        # Verify snapshot is gone
        snap_list = snapshots.get_snapshot_names(shared_handle)
        assert snapshot_name not in snap_list

    @requires_lxd
    def test_list_all_snapshots(self, shared_handle):
        """Test listing all snapshots."""
        snap_list = snapshots.get_snapshot_names(shared_handle)

        # Should return a list
        assert isinstance(snap_list, list)


class TestErrorHandling:
    """Test error handling for various container operations."""

    @requires_lxd
    def test_operate_on_nonexistent_container(self):
        """Test that operations on non-existent containers raise errors."""
        fake_handle = core.create_handle(f"{LXC_TEST_PREFIX}-fake-{uuid4().hex[:8]}")

        # Executing on non-existent container should raise error
        with pytest.raises(ContainerError):
            exec.execute(fake_handle, ["echo", "test"])

        # Copying to non-existent container should raise error
        with pytest.raises(ContainerError):
            with tempfile.NamedTemporaryFile() as f:
                files.copy_to(fake_handle, f.name, "/tmp/test.txt")

    @requires_lxd
    def test_copy_nonexistent_file(self):
        """Test that copying non-existent files raises errors."""
        name = f"{LXC_TEST_PREFIX}-err-{uuid4().hex[:8]}"
        handle = core.create_handle(name)
        core.create_container(handle, "images:archlinux")

        try:
            # Copying non-existent host file should raise error
            with pytest.raises(ContainerError):
                files.copy_to(handle, "/nonexistent/file.txt", "/tmp/dest.txt")

            # Copying non-existent container file should raise error
            with pytest.raises(ContainerError):
                files.copy_from(handle, "/nonexistent/container.txt", "/tmp/dest.txt")

        finally:
            if core.container_exists(handle):
                core.delete_container(handle)

    @requires_lxd
    def test_delete_nonexistent_image(self):
        """Test that deleting non-existent image raises error."""
        fake_image_name = f"nonexistent-{uuid4().hex[:8]}"

        with pytest.raises(ContainerError):
            images.delete_image(fake_image_name)

    @requires_lxd
    def test_exec_replace_nonexistent_container(self):
        """Test that exec_replace on non-existent container raises error."""
        from simplelxc._lxd.exec import exec_replace

        fake_handle = core.create_handle(
            f"{LXC_TEST_PREFIX}-execreplace-{uuid4().hex[:8]}"
        )

        with pytest.raises(ContainerError):
            exec_replace(fake_handle, "echo test")

    @requires_lxd
    def test_snapshot_operations_nonexistent_container(self):
        """Test snapshot helpers with a non-existent container."""
        fake_handle = core.create_handle(
            f"{LXC_TEST_PREFIX}-snapfake-{uuid4().hex[:8]}"
        )

        with pytest.raises(ContainerError):
            snapshots.create_snapshot(fake_handle, "snap")

        with pytest.raises(ContainerError):
            snapshots.restore_snapshot(fake_handle, "snap")

        with pytest.raises(ContainerError):
            snapshots.delete_snapshot(fake_handle, "snap")

        assert snapshots.get_snapshot_names(fake_handle) == []

    @requires_lxd
    def test_delete_all_with_empty_prefix(self):
        """Test that delete_all with empty prefix raises error."""
        with pytest.raises(ValueError):
            core.delete_containers_by_prefix("")

        with pytest.raises(ValueError):
            core.delete_containers_by_prefix("   ")
