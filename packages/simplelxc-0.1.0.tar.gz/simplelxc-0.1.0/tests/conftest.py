"""Pytest configuration and shared fixtures."""

import os
import shutil
from functools import wraps

import pytest

import simplelxc.system


def _is_running_in_container():
    """Check if we're running inside an LXC container."""
    # Check /run/systemd/container
    if os.path.exists("/run/systemd/container"):
        return True

    # Check /proc/1/environ for container=lxc
    try:
        with open("/proc/1/environ", "rb") as f:
            environ = f.read().decode("utf-8", errors="ignore")
            if "container=lxc" in environ:
                return True
    except (FileNotFoundError, PermissionError):
        pass

    return False


def requires_lxd(func):
    """Skip test if LXD is not available or running inside a container."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        if _is_running_in_container():
            pytest.skip("Cannot run LXD tests inside a container")
        if not shutil.which("lxc"):
            pytest.skip("LXD not installed")
        return func(*args, **kwargs)

    return wrapper


LXC_TEST_PREFIX = "slxc-test"


def pytest_sessionfinish(session, exitstatus):
    """
    Called after the whole test run finishes.
    Prune any leftover containers starting with LXC_TEST_PREFIX.
    """
    simplelxc.system.prune_containers(LXC_TEST_PREFIX)


# Make requires_lxd available to all test modules
pytest_plugins = []
