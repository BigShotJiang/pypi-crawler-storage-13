import os
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.skipif(
    os.getenv("SIMPLELXC_FAST_TESTS") is not None, reason="Skipping LXD tests"
)
# ruff: noqa: E402

from simplelxc import Container, system

# Add tests directory to path for conftest imports
sys.path.insert(0, str(Path(__file__).parent))
from conftest import LXC_TEST_PREFIX, requires_lxd


class TestVersionAndPackages:
    """Tests for version caching and package installation."""

    @requires_lxd
    def test_version_caching_flow(self):
        """
        Test the flow:
        1. Start container with version, no cache -> provisions, creates image.
        2. Start container with same version -> uses cached image, no provisioning.
        """
        version = "v1.test"
        name_prefix = f"{LXC_TEST_PREFIX}-ver-cache"
        image_name = f"{name_prefix}-{version}"

        # Clean up any pre-existing image
        if system.image_exists(image_name):
            system.delete_image(image_name)

        # 1. First run: should provision and create image
        c1 = Container(
            name_prefix=name_prefix,
            version=version,
            base_image="images:alpine/edge",  # Use alpine for speed
            auto_delete=True,
        )

        hooks_called = []
        c1.hooks.before_provision = lambda c: hooks_called.append("before_provision")
        c1.hooks.after_image_creation = lambda c: hooks_called.append(
            "after_image_creation"
        )

        c1.start()

        assert "before_provision" in hooks_called
        assert "after_image_creation" in hooks_called
        assert system.image_exists(image_name)
        assert system.get_image_version(image_name) == version

        c1.stop()

        # 2. Second run: should use cached image
        c2 = Container(
            name_prefix=name_prefix,
            version=version,
            base_image="images:alpine/edge",
            auto_delete=True,
        )

        hooks_called_2 = []
        c2.hooks.before_provision = lambda c: hooks_called_2.append("before_provision")

        c2.start()

        # Should NOT have provisioned again
        assert "before_provision" not in hooks_called_2

        c2.stop()

        # Cleanup image
        system.delete_image(image_name)

    @requires_lxd
    def test_install_packages(self):
        """Test Container.install_packages explicitly."""
        c = Container(
            name_prefix=f"{LXC_TEST_PREFIX}-pkg",
            base_image="images:alpine/edge",
            auto_delete=True,
        )
        c.start()

        # Check git not present (usually) or at least we install it and check
        # Alpine edge is minimal.

        c.install_packages(["git"])

        res = c.execute("git --version")
        assert res.success
        assert "git version" in res.stdout

        c.stop()
