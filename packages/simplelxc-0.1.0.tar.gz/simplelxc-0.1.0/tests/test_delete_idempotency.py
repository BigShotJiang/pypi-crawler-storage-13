import sys
from pathlib import Path

import pytest
from pylxd import Client

from simplelxc import Container

# Add tests directory to path for conftest imports
sys.path.insert(0, str(Path(__file__).parent))
from conftest import LXC_TEST_PREFIX, requires_lxd


@requires_lxd
def test_delete_idempotency():
    """Test that calling delete() on an already deleted container is idempotent."""

    # 1. Create a container
    container = Container(
        name_prefix=f"{LXC_TEST_PREFIX}-idempotency",
        base_image="images:archlinux",
        auto_delete=False,  # We will handle deletion manually first
    )
    container.start()

    container_name = container.name
    assert container_name is not None

    # 2. Delete it externally (using raw pylxd client)
    client = Client()
    instance = client.instances.get(container_name)  # type: ignore
    instance.stop(wait=True)  # type: ignore
    instance.delete(wait=True)  # type: ignore

    # Verify it's gone
    assert not client.instances.exists(container_name)  # type: ignore

    # 3. Call container.delete() - Should not raise exception
    try:
        container.delete()
    except Exception as e:
        pytest.fail(f"container.delete() raised exception on missing container: {e}")

    # 4. Verify handle is cleared
    assert container.handle is None
