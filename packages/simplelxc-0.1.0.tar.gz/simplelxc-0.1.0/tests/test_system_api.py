"""Tests for the public system API."""

import os
import sys
from pathlib import Path
from uuid import uuid4

import pytest

pytestmark = pytest.mark.skipif(
    os.getenv("SIMPLELXC_FAST_TESTS") is not None, reason="Skipping LXD tests"
)
# ruff: noqa: E402
# Add tests directory to path for conftest imports
sys.path.insert(0, str(Path(__file__).parent))
from conftest import LXC_TEST_PREFIX, requires_lxd

from simplelxc import Container, system


class TestSystemAPI:
    """Test system-wide operations."""

    @requires_lxd
    def test_list_and_prune_containers(self):
        """Test listing and pruning containers."""
        prefix = f"{LXC_TEST_PREFIX}-{uuid4().hex[:8]}"

        # Create 2 containers
        c1 = Container(name_prefix=f"{prefix}-1", auto_delete=False)
        c1.start()
        c2 = Container(name_prefix=f"{prefix}-2", auto_delete=False)
        c2.start()

        try:
            # Test get_container_names
            containers = system.get_container_names()
            assert c1.name in containers
            assert c2.name in containers

            # Test prune_containers
            deleted = system.prune_containers(prefix)
            assert deleted >= 2

            # Verify deletion
            remaining = system.get_container_names()
            assert c1.name not in remaining
            assert c2.name not in remaining

        finally:
            # Cleanup if prune failed
            try:
                c1.delete()
            except Exception:
                pass
            try:
                c2.delete()
            except Exception:
                pass

    @requires_lxd
    def test_image_operations(self):
        """Test image operations exposed via system module."""
        # Create a container to make an image from
        c = Container(
            name_prefix=f"{LXC_TEST_PREFIX}-{uuid4().hex[:8]}", auto_delete=True
        )
        c.start()

        img_name = f"{LXC_TEST_PREFIX}-image-{uuid4().hex[:8]}"
        version = "1.2.3"

        try:
            # Create image using Container API
            c.create_image(img_name, version=version)

            # Test image_exists
            assert system.image_exists(img_name) is True

            # Test get_image_version
            assert system.get_image_version(img_name) == version

            # Test get_image_names
            assert img_name in system.get_image_names()

            # Test delete_image
            system.delete_image(img_name)
            assert system.image_exists(img_name) is False

        finally:
            c.stop()
            # Cleanup image if test failed
            if system.image_exists(img_name):
                system.delete_image(img_name)
