"""Tests for the container orchestrator internals."""

import os
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.skipif(
    os.getenv("SIMPLELXC_FAST_TESTS") is not None, reason="Skipping LXD tests"
)

# ruff: noqa: E402
# Add tests directory to path for conftest imports
sys.path.insert(0, str(Path(__file__).parent))
from conftest import LXC_TEST_PREFIX, requires_lxd

from simplelxc.config import (
    ContainerConfig,
    ImageConfig,
    LifecycleHooks,
    load_config_from_dict,
    load_config_from_file,
)
from simplelxc.container import Container


class TestContainer:
    """Test the container module building blocks."""

    def test_container_config_defaults(self):
        """Test ContainerConfig default values."""

        config = ContainerConfig(name_prefix=f"{LXC_TEST_PREFIX}-test")
        assert config.name_prefix == f"{LXC_TEST_PREFIX}-test"
        assert config.auto_delete is True
        assert config.headless is False
        assert config.version is None

    def test_image_config_defaults(self):
        """Test ImageConfig default values."""

        config = ImageConfig()
        assert config.base_image == "images:archlinux"
        assert config.force_rebuild is False
        assert config.install_packages == []
        assert config.setup_scripts == []

    def test_lifecycle_hooks_defaults(self):
        """Test LifecycleHooks default values."""

        hooks = LifecycleHooks()
        assert hooks.before_start is None
        assert hooks.after_start is None
        assert hooks.before_provision is None
        assert hooks.after_provision is None
        assert hooks.before_image_creation is None
        assert hooks.after_image_creation is None
        assert hooks.container_ready is None
        assert hooks.before_stop is None
        assert hooks.after_stop is None
        assert hooks.before_delete is None
        assert hooks.after_delete is None

    def test_load_config_from_dict(self):
        data = {
            "container": {
                "name_prefix": f"{LXC_TEST_PREFIX}-cfg-test",
                "auto_delete": False,
                "headless": True,
                "version": "1.2.3",
                "image_name": "cfg-image",
            },
            "image": {
                "base_image": "images:archlinux",
                "force_rebuild": True,
                "install_packages": ["python"],
                "setup_scripts": ["setup.sh"],
            },
        }

        container_cfg, image_cfg = load_config_from_dict(data)

        assert container_cfg.name_prefix == f"{LXC_TEST_PREFIX}-cfg-test"
        assert container_cfg.auto_delete is False
        assert container_cfg.headless is True
        assert container_cfg.version == "1.2.3"
        assert container_cfg.image_name == "cfg-image"

        assert image_cfg.base_image == "images:archlinux"
        assert image_cfg.force_rebuild is True
        assert image_cfg.install_packages == ["python"]
        assert image_cfg.setup_scripts == ["setup.sh"]

    def test_load_config_from_dict_missing_name_prefix(self):
        with pytest.raises(ValueError):
            load_config_from_dict({"container": {}, "image": {}})

    def test_load_config_from_file_roundtrip(self, tmp_path: Path):
        path = tmp_path / "container.json"
        path.write_text(
            """{
  "container": {"name_prefix": "slxc-test-file-test"},
  "image": {"base_image": "images:archlinux"}
}
""",
            encoding="utf-8",
        )

        container_cfg, image_cfg = load_config_from_file(path)

        assert container_cfg.name_prefix == f"{LXC_TEST_PREFIX}-file-test"
        assert image_cfg.base_image == "images:archlinux"

    def test_load_config_from_file_missing_file(self, tmp_path: Path):
        missing = tmp_path / "does-not-exist.json"
        with pytest.raises(FileNotFoundError):
            load_config_from_file(missing)

    @requires_lxd
    def test_basic_orchestration(self):
        """Test basic container orchestration via orchestrate()."""

        container = Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-orchestrator",
            auto_delete=True,
            base_image="images:archlinux",
        )

        # Track hook calls
        calls: list[str] = []

        def after_start(c: Container) -> None:
            calls.append("after_start")
            assert isinstance(c, Container)
            assert c.name is not None
            assert c.name.startswith(f"{LXC_TEST_PREFIX}-test-orchestrator")

        container.hooks.after_start = after_start

        # Orchestrate
        container._start_lifecycle()

        # Verify context
        assert container.name is not None
        assert container.name.startswith(f"{LXC_TEST_PREFIX}-test-orchestrator")
        assert "after_start" in calls

        # Test context methods
        result = container.execute("echo hello")
        assert result.success
        assert "hello" in result.stdout

        # Cleanup
        container._stop_lifecycle()

    @requires_lxd
    def test_hook_ordering_non_cached(self):
        """Test hook ordering for a non-cached provisioning run."""

        container = Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-hooks-order",
            auto_delete=True,
            base_image="images:archlinux",
        )

        events: list[str] = []

        hooks = container.hooks
        hooks.before_start = lambda plan: events.append("before_start")
        hooks.after_start = lambda c: events.append("after_start")
        hooks.before_provision = lambda c: events.append("before_provision")
        hooks.after_provision = lambda c: events.append("after_provision")
        hooks.before_image_creation = lambda c: events.append("before_image_creation")
        hooks.after_image_creation = lambda c: events.append("after_image_creation")
        hooks.container_ready = lambda c: events.append("container_ready")

        container._start_lifecycle()
        container._stop_lifecycle()

        assert events[:3] == ["before_start", "after_start", "before_provision"]
        assert "after_provision" in events
        assert "container_ready" in events

    @requires_lxd
    def test_stop_delete_hooks_order(self):
        container = Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-stop-hooks",
            auto_delete=True,
            base_image="images:archlinux",
        )

        events: list[str] = []

        hooks = container.hooks
        hooks.before_stop = lambda c: events.append("before_stop")
        hooks.after_stop = lambda c: events.append("after_stop")
        hooks.before_delete = lambda c: events.append("before_delete")
        hooks.after_delete = lambda c: events.append("after_delete")

        container._start_lifecycle()
        container._stop_lifecycle()

        assert events == [
            "before_stop",
            "after_stop",
            "before_delete",
            "after_delete",
        ]

    @requires_lxd
    def test_stop_without_delete_does_not_call_delete_hooks(self):
        container = Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-stop-nodelete",
            auto_delete=False,
            base_image="images:archlinux",
        )

        events: list[str] = []

        hooks = container.hooks
        hooks.before_stop = lambda c: events.append("before_stop")
        hooks.after_stop = lambda c: events.append("after_stop")
        hooks.before_delete = lambda c: events.append("before_delete")
        hooks.after_delete = lambda c: events.append("after_delete")

        container._start_lifecycle()
        # Manually ensure auto_delete is false for stop
        container._container_config.auto_delete = False
        container._stop_lifecycle()

        assert events == ["before_stop", "after_stop"]

    def test_determine_image_force_rebuild_uses_base(self):
        config = ContainerConfig(name_prefix=f"{LXC_TEST_PREFIX}-img", auto_delete=True)
        image = ImageConfig(base_image="images:archlinux", force_rebuild=True)

        name, cached = Container._determine_image(config, image)

        assert name == "images:archlinux"
        assert cached is False

    @requires_lxd
    def test_before_start_exception_propagates(self):
        container = Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-before-start-exc",
            auto_delete=True,
            base_image="images:archlinux",
        )

        def before_start(_plan):
            raise RuntimeError("boom-before-start")

        container.hooks.before_start = before_start

        with pytest.raises(RuntimeError):
            container._start_lifecycle()

    @requires_lxd
    def test_before_stop_exception_propagates(self):
        container = Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-before-stop-exc",
            auto_delete=True,
            base_image="images:archlinux",
        )

        container._start_lifecycle()

        def before_stop(_c: Container) -> None:
            raise RuntimeError("boom-before-stop")

        container.hooks.before_stop = before_stop

        try:
            with pytest.raises(RuntimeError):
                container._stop_lifecycle()
        finally:
            # Cleanup without hooks
            container.hooks.before_stop = None
            container._stop_lifecycle()

    def test_version_property(self):
        container = Container(name_prefix=f"{LXC_TEST_PREFIX}-test", version="1.5")
        assert container.version == "1.5"


class TestContainerRuntime:
    """Test Container runtime methods (without running containers)."""

    def test_container_creation(self):
        """Test creating a container object."""

        from simplelxc._lxd.core import create_handle

        handle = create_handle(f"{LXC_TEST_PREFIX}-test")
        container = Container(name_prefix=f"{LXC_TEST_PREFIX}-test")
        container._handle = handle
        container._container_name = f"{LXC_TEST_PREFIX}-test"
        container._image_name = "images:archlinux"
        container._cached_image = False

        assert container.name == f"{LXC_TEST_PREFIX}-test"
        # assert container.image_name == "images:archlinux"
        assert container.cwd == "/root"  # Default from ContainerHandle

    def test_container_cwd_property(self):
        """Test cwd property getter/setter."""

        from simplelxc._lxd.core import create_handle

        handle = create_handle(f"{LXC_TEST_PREFIX}-test")
        container = Container(name_prefix=f"{LXC_TEST_PREFIX}-test")
        container._handle = handle
        container._container_name = f"{LXC_TEST_PREFIX}-test"

        assert container.cwd == "/root"
        container.cwd = "/home/user"
        assert container.cwd == "/home/user"
        assert container._handle.cwd == "/home/user"

    def test_wait_for_condition_true_and_timeout(self):
        from simplelxc._lxd.core import create_handle

        handle = create_handle(f"{LXC_TEST_PREFIX}-test-wait")
        container = Container(name_prefix=f"{LXC_TEST_PREFIX}-test-wait")
        container._handle = handle

        result_true = container.wait_for(lambda: True, timeout=1, check_interval=0.01)
        assert result_true is True

        result_false = container.wait_for(lambda: False, timeout=0, check_interval=0.01)
        assert result_false is False
