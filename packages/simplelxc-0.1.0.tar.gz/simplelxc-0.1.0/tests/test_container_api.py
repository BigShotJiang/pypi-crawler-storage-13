"""Tests for the high-level Container API.

These tests use real LXD containers but keep scenarios minimal
and reuse each container within the test where possible.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.skipif(
    os.getenv("SIMPLELXC_FAST_TESTS") is not None, reason="Skipping LXD tests"
)

# ruff: noqa: E402

# Add tests directory to path for conftest imports
sys.path.insert(0, str(Path(__file__).parent))
from conftest import LXC_TEST_PREFIX, requires_lxd

from simplelxc import Container


class TestContainerAPI:
    """Test basic Container operations end-to-end."""

    @requires_lxd
    def test_start_stop_with_hooks_and_execute(self):
        events: list[str] = []

        container = Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-api",
            base_image="images:archlinux",
            auto_delete=True,
        )

        container.hooks.after_start = lambda c: events.append("after_start")
        container.hooks.before_stop = lambda c: events.append("before_stop")
        container.hooks.after_stop = lambda c: events.append("after_stop")

        container.start()

        # Exercise dynamic delegation via __getattr__
        container.restart(wait_for_network=False)

        # images = container.lxd.images.get_image_names() # lxd is hidden now
        # assert isinstance(images, list)

        assert container.handle is not None
        assert container.name is not None
        assert "after_start" in events

        result = container.execute("echo api-test")
        assert result.success
        assert "api-test" in result.stdout

        container.stop()

        assert events[-2:] == ["before_stop", "after_stop"]
        assert container.handle is None

    @requires_lxd
    def test_context_manager_uses_start_and_stop(self):
        with Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-ctx", base_image="images:archlinux"
        ) as c:
            assert c.handle is not None
            result = c.execute("echo ctx-test")
            assert result.success
            assert "ctx-test" in result.stdout

            # Simple wait_for_command on a trivial command
            assert c.wait_for_command("true", timeout=5)

        # After context manager exit, container should be stopped
        assert c.handle is None

    @requires_lxd
    def test_file_operations(self, tmp_path: Path):
        """Test file operations."""
        with Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-files",
            base_image="images:archlinux",
            auto_delete=True,
        ) as c:
            # Create file
            c.create_file("/tmp/hello.txt", "Hello World")
            res = c.execute("cat /tmp/hello.txt")
            assert res.success
            assert "Hello World" in res.stdout

            # Copy from container
            dest = tmp_path / "hello.txt"
            c.copy_from("/tmp/hello.txt", str(dest))
            assert dest.read_text() == "Hello World"

            # Copy to container
            src = tmp_path / "host.txt"
            src.write_text("From Host")
            c.copy_to(str(src), "/tmp/host.txt")
            res = c.execute("cat /tmp/host.txt")
            assert res.success
            assert "From Host" in res.stdout

    @requires_lxd
    def test_execute_script(self, tmp_path: Path):
        """Test executing a script."""
        with Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-script",
            base_image="images:archlinux",
            auto_delete=True,
        ) as c:
            script = tmp_path / "myscript.sh"
            script.write_text("#!/bin/sh\necho Script Runs $1\n")

            res = c.execute_script(str(script), args="Arg1")
            assert res.success
            assert "Script Runs Arg1" in res.stdout

    @requires_lxd
    def test_snapshot_operations(self):
        """Test snapshot operations."""
        with Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-snap",
            base_image="images:archlinux",
            auto_delete=True,
        ) as c:
            c.create_file("/root/data", "Version 1")
            c.snapshot("snap1")

            assert "snap1" in c.snapshots

            c.create_file("/root/data", "Version 2")
            c.restore("snap1")

            # Container is stopped after restore, need to restart
            c.restart()

            res = c.execute("cat /root/data")
            assert "Version 1" in res.stdout

            c.delete_snapshot("snap1")
            assert "snap1" not in c.snapshots

    @requires_lxd
    def test_network_wait_ops(self):
        """Test network and wait operations."""
        with Container(
            name_prefix=f"{LXC_TEST_PREFIX}-test-net",
            base_image="images:archlinux",
            auto_delete=True,
        ) as c:
            # Just test the wait_for_network call doesn't crash
            c.wait_for_network(timeout=5)

            # Test wait_for_command
            assert c.wait_for_command("true")
            assert not c.wait_for_command("false", timeout=1)
