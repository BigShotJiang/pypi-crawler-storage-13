import warnings

WARNING_MSG = (
    "The 'capiscio-a2a-security' package is deprecated and has been renamed to 'capiscio-sdk'. "
    "Please update your dependencies: pip install capiscio-sdk"
)

warnings.warn(WARNING_MSG, DeprecationWarning, stacklevel=2)
print(f"WARNING: {WARNING_MSG}")
