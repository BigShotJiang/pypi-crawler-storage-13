# ⚠️ DEPRECATED

This package (`capiscio-a2a-security`) has been renamed to **`capiscio-sdk`**.

Please update your `requirements.txt` or `pyproject.toml`:

```bash
pip uninstall capiscio-a2a-security
pip install capiscio-sdk
```

This package is now a hollow shell that installs `capiscio-sdk` as a dependency to ensure continuity, but you should update your references.
