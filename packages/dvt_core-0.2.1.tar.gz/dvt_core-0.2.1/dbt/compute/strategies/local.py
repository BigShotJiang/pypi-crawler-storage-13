"""
Local Spark Connection Strategy

Provides embedded PySpark session for local development and testing.
This is the default strategy extracted from the original SparkEngine implementation.
"""

from typing import Any, Dict, Optional

from dbt.compute.strategies.base import BaseConnectionStrategy
from dbt_common.exceptions import DbtRuntimeError

try:
    from pyspark.sql import SparkSession

    PYSPARK_AVAILABLE = True
except ImportError:
    PYSPARK_AVAILABLE = False
    SparkSession = None


class LocalStrategy(BaseConnectionStrategy):
    """
    Local embedded Spark strategy.

    Creates an in-process PySpark session with local[*] master.
    Best for development, testing, and small-medium workloads.

    Configuration:
    {
        "master": "local[*]",  # optional, defaults to local[*]
        "spark.driver.memory": "4g",  # optional
        "spark.executor.memory": "4g",  # optional
        # ... any other Spark configs
    }
    """

    def validate_config(self) -> None:
        """
        Validate local strategy configuration.

        Local strategy is flexible - no required fields.
        """
        # Local strategy accepts any config - very flexible
        # Just ensure it's a dictionary
        if not isinstance(self.config, dict):
            raise DbtRuntimeError(
                f"Local Spark config must be a dictionary, got {type(self.config)}"
            )

    def get_spark_session(self) -> SparkSession:
        """
        Create local Spark session.

        Creates an embedded PySpark session with local[*] master.

        :returns: Initialized SparkSession
        :raises DbtRuntimeError: If session creation fails
        """
        if not PYSPARK_AVAILABLE:
            raise DbtRuntimeError("PySpark is not available. Install it with: pip install pyspark")

        try:
            builder = SparkSession.builder.appName(self.app_name)

            # Set local master (use config value or default to local[*])
            master = self.config.get("master", "local[*]")
            builder = builder.master(master)

            # Default local configurations
            default_configs = {
                "spark.driver.memory": "4g",
                "spark.sql.execution.arrow.pyspark.enabled": "true",
                "spark.sql.execution.arrow.pyspark.fallback.enabled": "true",
            }

            # Apply default configs (can be overridden by user config)
            for key, value in default_configs.items():
                if key not in self.config:
                    builder = builder.config(key, value)

            # Apply user-provided configs (except 'master' which is already set)
            for key, value in self.config.items():
                if key != "master":
                    builder = builder.config(key, value)

            # Enable Arrow optimization
            builder = builder.config("spark.sql.execution.arrow.enabled", "true")

            # Create session
            spark = builder.getOrCreate()

            # Set log level to WARN to reduce noise
            spark.sparkContext.setLogLevel("WARN")

            return spark

        except Exception as e:
            raise DbtRuntimeError(f"Failed to create local Spark session: {str(e)}") from e

    def close(self, spark: Optional[SparkSession]) -> None:
        """
        Stop local Spark session.

        For local strategy, we stop the session to free resources.

        :param spark: SparkSession to close
        """
        if spark:
            try:
                spark.stop()
            except Exception:
                pass  # Best effort cleanup

    def estimate_cost(self, duration_minutes: float) -> float:
        """
        Estimate cost for local execution.

        Local execution is free (runs on local machine).

        :param duration_minutes: Estimated query duration
        :returns: 0.0 (free)
        """
        return 0.0

    def get_platform_name(self) -> str:
        """Get platform name."""
        return "local"
