"""
Base Connection Strategy for Spark Engines

Defines the abstract interface for different Spark connection strategies.
Uses composition over inheritance for flexible platform support.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

try:
    from pyspark.sql import SparkSession

    PYSPARK_AVAILABLE = True
except ImportError:
    PYSPARK_AVAILABLE = False
    SparkSession = None


class BaseConnectionStrategy(ABC):
    """
    Abstract base class for Spark connection strategies.

    Different strategies implement different ways to connect to Spark:
    - LocalStrategy: Embedded PySpark (in-process)
    - DatabricksStrategy: Databricks Connect (remote cluster)
    - EMRStrategy: AWS EMR cluster (future)
    - DataprocStrategy: GCP Dataproc (future)
    """

    def __init__(self, config: Dict[str, Any], app_name: str = "DVT-Compute"):
        """
        Initialize connection strategy.

        :param config: Strategy-specific configuration
        :param app_name: Spark application name
        """
        self.config = config
        self.app_name = app_name

    @abstractmethod
    def get_spark_session(self) -> SparkSession:
        """
        Create and return a SparkSession.

        :returns: Initialized SparkSession
        :raises DbtRuntimeError: If session creation fails
        """
        pass

    @abstractmethod
    def validate_config(self) -> None:
        """
        Validate strategy-specific configuration.

        :raises DbtRuntimeError: If configuration is invalid
        """
        pass

    def estimate_cost(self, duration_minutes: float) -> float:
        """
        Estimate cost for running on this platform.

        Default implementation returns 0.0 (free). Override for cloud platforms.

        :param duration_minutes: Estimated query duration in minutes
        :returns: Estimated cost in USD
        """
        return 0.0

    @abstractmethod
    def close(self, spark: Optional[SparkSession]) -> None:
        """
        Clean up Spark session.

        :param spark: SparkSession to clean up (may be None)
        """
        pass

    def get_platform_name(self) -> str:
        """
        Get human-readable platform name.

        :returns: Platform name (e.g., "local", "databricks", "emr")
        """
        return self.__class__.__name__.replace("Strategy", "").lower()
