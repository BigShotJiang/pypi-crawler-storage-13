"""aiopioneer decode classes."""
