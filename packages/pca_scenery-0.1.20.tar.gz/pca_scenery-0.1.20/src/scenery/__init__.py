"""A versatile integration testing framework for web apps."""
import configparser
# import datetime
import logging
from typing import Any

# from rich.console import Console
from pprint import pformat


class SceneryLogger:

    style_map = {
        logging.DEBUG: None,
        logging.INFO: "blue",
        logging.WARNING: "yellow",
        logging.ERROR: "red",
    }

    def __init__(self, level: int):
        self.level = level
        # self.console = console
        self.logger = logging.getLogger("scenery")

        import sys
        handler = logging.StreamHandler(stream=sys.stdout)
        formatter = logging.Formatter(
            fmt="%(asctime)s.%(msecs)03d - %(levelname)s - scenery - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)

        self.logger.setLevel(level)
        self.logger.addHandler(handler)
        # pass

    def log(self, level: int, msg: Any ) -> None: # , style: str | None = None

        # print("log", level, msg)

        # if self.level <= level:

            # print("Should be log indeed")

            # now = datetime.datetime.now(datetime.UTC)
            # timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
            # milliseconds = f"{now.microsecond // 1000:03d}"
            # formatted_time = f"{timestamp}.{milliseconds}"


            # level_name = f"{logging.getLevelName(level)}"
            # level_name = f"{level_name:<10}"
            # color = self.style_map[level]
            # if color:
                # pass
                # level_name = f"[{color}]{level_name}[/{color}]"
                # msg = level_name + str(msg)
            # msg = f"{formatted_time} - {level_name} - {msg}"

            # self.console.log(msg, style=style, log_)
        msg = pformat(msg)
        if "\n" in msg:
            msg = "\n" + msg
        self.logger.log(level, msg)

    def info(self, msg: Any, style: str | None =None) -> None:
        # self.log(logging.INFO, msg, style)
        self.log(logging.INFO, msg)

    def debug(self, msg: Any, style: str | None =None) -> None:
        # self.log(logging.DEBUG, msg, style)
        self.log(logging.DEBUG, msg)

    def warning(self, msg: Any, style: str | None =None) -> None:
        # self.log(logging.WARNING, msg, style)
        self.log(logging.WARNING, msg)

    def error(self, msg: Any, style: str | None =None) -> None:
        self.log(logging.ERROR, msg)


class SceneryConfig(configparser.ConfigParser):

    @property
    def framework(self):
        if self.has_section("app"):
            return self.get("app", "framework")
        else:
            return None
    
    @property
    def manifests_folder(self):
        return self.get("manifests", "folder")
    
    @property
    def common_items(self):
        return self.get("manifests", "common", fallback=None)

    @property
    def selenium_instructions(self):
        if self.has_section("instructions"):
            return self.get("instructions", "selenium", fallback=None)
        else:
            return None
    
    @property
    def setup_instructions(self):
        if self.has_section("instructions"):
            return self.get("instructions", "setup", fallback=None)
        else:
            return None
    
    @property
    def django_app_name(self):
        return self.get("app-django", "name")
    
    @property
    def urls(self):
        return self["urls"]

# console = Console()
logger = SceneryLogger(logging.INFO)
config = SceneryConfig()


