"""NetCDF utility functions."""

import xarray as xr


def get_valid_variables(dataset: xr.Dataset) -> list[str]:
    """
    Get list of valid variables for visualization (2D or higher).

    Args:
        dataset: xarray Dataset to extract variables from

    Returns:
        List of variable names that have at least 2 dimensions
    """
    return [v for v in dataset.variables if len(dataset[v].dims) >= 2]
