"""
Worker thread for loading NetCDF volumes into memory.
"""

import traceback
from typing import Any, Optional

import numpy as np
import xarray as xr
from numpy.typing import NDArray
from PyQt6.QtCore import QThread, pyqtSignal

from ..constants import (
    LARGE_VALUE_THRESHOLD,
    PERCENTILE_MAX,
    PERCENTILE_MIN,
    STATS_SAMPLE_SIZE,
)


class VolumeLoader(QThread):
    """
    Loads the ENTIRE volume into RAM, sanitizes it, and calculates global stats.
    Handles flipping data if Latitudes are inverted (North-to-South).
    """

    finished_loading = pyqtSignal(object, object, object, str)  # volume, stats, bounds, msg
    error_occurred = pyqtSignal(str)

    def __init__(self, dataset: xr.Dataset, var_name: str):
        super().__init__()
        self.dataset = dataset
        self.var_name = var_name

    def run(self) -> None:
        """Execute the volume loading process."""
        try:
            ds = self.dataset
            da = ds[self.var_name]

            # 1. Load all data into memory
            raw_data: NDArray[Any] = da.values

            # 2. Sanitize Data (Global)
            raw_data = self._sanitize_data(raw_data)

            # 3. Determine Coordinates & Bounds
            bounds_info = self._determine_bounds(da, raw_data)
            bounds = bounds_info[0]

            # 4. Orientation Fix (Flip if North-to-South)
            raw_data = self._fix_orientation(ds, da, raw_data, bounds_info)

            # 5. Calculate Global Min/Max (ignoring NaNs) for slider ranges
            stats = self._calculate_stats(raw_data)

            self.finished_loading.emit(raw_data, stats, bounds, f"Loaded {self.var_name}")

        except Exception as e:
            self.error_occurred.emit(str(e))
            traceback.print_exc()

    def _sanitize_data(self, data: NDArray[Any]) -> NDArray[Any]:
        """Sanitize data by handling complex numbers, timedeltas, and fill values."""
        # Handle complex numbers
        if np.iscomplexobj(data):
            data = np.abs(data)

        # Handle timedeltas
        if np.issubdtype(data.dtype, np.timedelta64):
            nat_mask = np.isnat(data)
            data = data.astype("timedelta64[s]").astype(np.float32)
            data[nat_mask] = np.nan

        # Replace huge values (fill values) with NaN
        if np.issubdtype(data.dtype, np.floating):
            data[np.abs(data) > LARGE_VALUE_THRESHOLD] = np.nan

        return data

    def _determine_bounds(
        self, da: xr.DataArray, data: NDArray[Any]
    ) -> tuple[dict[str, float], Optional[str], Optional[str]]:
        """Determine coordinate bounds for the data."""
        lat_name = next((d for d in da.dims if "lat" in d.lower()), None)
        lon_name = next((d for d in da.dims if "lon" in d.lower()), None)

        # Default bounds if no coords found
        bounds: dict[str, float] = {
            "x_min": 0.0,
            "x_max": float(data.shape[-1]),
            "y_min": 0.0,
            "y_max": float(data.shape[-2]),
        }

        # Update bounds with actual coordinates if available
        if lon_name and lon_name in self.dataset:
            lons = self.dataset[lon_name].values
            if lons.ndim == 1:
                bounds["x_min"] = float(lons.min())
                bounds["x_max"] = float(lons.max())

        return bounds, lat_name, lon_name

    def _fix_orientation(
        self,
        ds: xr.Dataset,
        da: xr.DataArray,
        data: NDArray[Any],
        bounds_info: tuple[dict[str, float], Optional[str], Optional[str]],
    ) -> NDArray[Any]:
        """Fix data orientation if latitudes are inverted (North-to-South)."""
        bounds, lat_name, _ = bounds_info

        if lat_name and lat_name in ds:
            lats = ds[lat_name].values
            if lats.ndim == 1 and lats.size > 1:
                # Check if descending (e.g. 90, 89, ... -90)
                if lats[0] > lats[-1]:
                    # Flip data along the Y axis (second to last dimension)
                    data = np.flip(data, axis=-2)
                    lats = np.flip(lats)

                bounds["y_min"] = float(lats.min())
                bounds["y_max"] = float(lats.max())

        return data

    def _calculate_stats(self, data: NDArray[Any]) -> dict[str, float]:
        """Calculate global statistics for the volume."""
        flat = data.ravel()
        valid_mask = ~np.isnan(flat)

        if np.any(valid_mask):
            # Grab a subset to calculate stats quickly
            sample_size = min(valid_mask.sum(), STATS_SAMPLE_SIZE)
            valid_indices = np.flatnonzero(valid_mask)
            sample_indices = np.random.choice(valid_indices, sample_size, replace=False)
            sample = flat[sample_indices]

            vmin = float(np.percentile(sample, PERCENTILE_MIN))
            vmax = float(np.percentile(sample, PERCENTILE_MAX))
        else:
            vmin, vmax = 0.0, 1.0

        return {"vmin": vmin, "vmax": vmax}
