"""
Pynoply - A GPU-accelerated NetCDF viewer and editor.
"""

from .constants import APP_NAME, APP_VERSION, APP_DESCRIPTION

__version__ = APP_VERSION
__app_name__ = APP_NAME
__description__ = APP_DESCRIPTION

__all__ = ["__version__", "__app_name__", "__description__"]
