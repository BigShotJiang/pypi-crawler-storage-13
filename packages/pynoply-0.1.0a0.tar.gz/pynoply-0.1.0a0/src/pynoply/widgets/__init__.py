"""Custom widgets for Pynoply."""

# Widgets will be imported directly from the main_window module
# to avoid circular imports. This __init__ file serves as a placeholder.

__all__ = []
