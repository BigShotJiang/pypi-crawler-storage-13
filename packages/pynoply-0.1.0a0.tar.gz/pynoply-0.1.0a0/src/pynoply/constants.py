"""
Constants and configuration for Pynoply.
"""

from typing import Final

# Application metadata
APP_NAME: Final[str] = "Pynoply"
APP_VERSION: Final[str] = "0.1.0-alpha"
APP_DESCRIPTION: Final[str] = "A GPU-accelerated NetCDF viewer and editor"
ORGANIZATION_NAME: Final[str] = "Pynoply"
SETTINGS_APP_NAME: Final[str] = "GPUSettings"

# UI Constants
DEFAULT_WINDOW_WIDTH: Final[int] = 1600
DEFAULT_WINDOW_HEIGHT: Final[int] = 1000
FILE_BROWSER_MAX_WIDTH: Final[int] = 350
CANVAS_BACKGROUND_COLOR: Final[str] = "#050505"

# Colormaps
AVAILABLE_COLORMAPS: Final[list[str]] = [
    "viridis",
    "magma",
    "plasma",
    "inferno",
    "hsl",
    "grays",
    "cool",
    "hot",
]

# File extensions
NETCDF_EXTENSIONS: Final[list[str]] = ["*.nc", "*.nc4", "*.netcdf"]

# NetCDF engines
NETCDF_ENGINES: Final[list[str]] = ["netcdf4", "h5netcdf", "scipy", "pynio"]
DEFAULT_ENGINE: Final[str] = "netcdf4"

# NetCDF formats
NETCDF_FORMATS: Final[list[str]] = [
    "NETCDF4",
    "NETCDF4_CLASSIC",
    "NETCDF3_CLASSIC",
    "NETCDF3_64BIT",
]

# Slider constants
CONTRAST_SLIDER_RANGE: Final[tuple[int, int]] = (0, 1000)
CONTRAST_SLIDER_DEFAULT_MIN: Final[int] = 0
CONTRAST_SLIDER_DEFAULT_MAX: Final[int] = 1000

# Data processing
STATS_SAMPLE_SIZE: Final[int] = 500000
PERCENTILE_MIN: Final[int] = 1
PERCENTILE_MAX: Final[int] = 99
LARGE_VALUE_THRESHOLD: Final[float] = 1e15

# Export settings
HIGH_RES_DPI: Final[int] = 300
HIGH_RES_WIDTH: Final[int] = 3840
HIGH_RES_HEIGHT: Final[int] = 2160

# Info bar update interval (milliseconds)
INFO_BAR_UPDATE_INTERVAL: Final[int] = 1000

# Compression defaults
DEFAULT_COMPRESSION_LEVEL: Final[int] = 4
COMPRESSION_LEVEL_RANGE: Final[tuple[int, int]] = (1, 9)
