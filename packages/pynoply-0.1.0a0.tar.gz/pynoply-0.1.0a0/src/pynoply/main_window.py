"""
Main window for Pynoply - A GPU-accelerated NetCDF viewer and editor.
"""

import os
import platform
import sys
from typing import Any, Optional

import numpy as np
import psutil
import xarray as xr
from numpy.typing import NDArray
from PyQt6.QtCore import QDir, QSettings, Qt, QTimer
from PyQt6.QtGui import QAction, QFileSystemModel, QFont
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSlider,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTreeView,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)
from vispy import scene
from vispy.visuals.transforms import STTransform

from .constants import (
    APP_NAME,
    APP_VERSION,
    AVAILABLE_COLORMAPS,
    CANVAS_BACKGROUND_COLOR,
    COMPRESSION_LEVEL_RANGE,
    CONTRAST_SLIDER_DEFAULT_MAX,
    CONTRAST_SLIDER_DEFAULT_MIN,
    CONTRAST_SLIDER_RANGE,
    DEFAULT_COMPRESSION_LEVEL,
    DEFAULT_ENGINE,
    DEFAULT_WINDOW_HEIGHT,
    DEFAULT_WINDOW_WIDTH,
    FILE_BROWSER_MAX_WIDTH,
    HIGH_RES_DPI,
    HIGH_RES_HEIGHT,
    HIGH_RES_WIDTH,
    INFO_BAR_UPDATE_INTERVAL,
    NETCDF_ENGINES,
    NETCDF_EXTENSIONS,
    NETCDF_FORMATS,
    ORGANIZATION_NAME,
    SETTINGS_APP_NAME,
)
from .gpu import detect_available_gpus, GPUInfo
from .gpu.settings_dialog import GPUSettingsDialog
from .utils import get_valid_variables
from .workers import VolumeLoader


"""Main window for Pynoply."""

class PynoplyMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Pynoply")
        self.resize(1600, 1000)

        # Settings
        self.settings = QSettings('NetCDFWorkbench', 'GPUSettings')

        # State
        self.dataset = None
        self.current_file_path = None
        self.volume = None
        self.global_stats = {}
        self.bounds = {}
        self.loader = None
        self.process = psutil.Process()
        self.available_gpus = detect_available_gpus()

        # === MENU BAR ===
        self.create_menu_bar()

        # === MAIN CONTENT: TABS ===
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # Tab Widget
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("QTabWidget::pane { border: 1px solid #cccccc; }")

        # === TAB 1: VIEWER ===
        viewer_tab = self.create_viewer_tab()
        self.tabs.addTab(viewer_tab, "Viewer")

        # === TAB 2: ATTRIBUTE EDITOR ===
        editor_tab = self.create_editor_tab()
        self.tabs.addTab(editor_tab, "Attribute Editor")

        main_layout.addWidget(self.tabs)

        # === INFO BAR (Bottom) ===
        self.create_info_bar()
        main_layout.addWidget(self.info_bar)

        # === UPDATE TIMER for Info Bar ===
        self.info_timer = QTimer()
        self.info_timer.timeout.connect(self.update_info_bar)
        self.info_timer.start(1000)  # Update every second

    def create_menu_bar(self):
        """Create menu bar with useful actions"""
        menubar = self.menuBar()

        # File Menu
        file_menu = menubar.addMenu("File")

        open_action = QAction("Open NetCDF...", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self.open_file)
        file_menu.addAction(open_action)

        self.recent_menu = file_menu.addMenu("Recent Files")
        file_menu.addSeparator()

        save_action = QAction("Save As...", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.save_file)
        file_menu.addAction(save_action)

        file_menu.addSeparator()

        close_action = QAction("Close File", self)
        close_action.triggered.connect(self.close_file)
        file_menu.addAction(close_action)

        file_menu.addSeparator()

        exit_action = QAction("Exit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # Edit Menu
        edit_menu = menubar.addMenu("Edit")

        add_attr_action = QAction("Add Attribute...", self)
        add_attr_action.triggered.connect(self.add_attribute)
        edit_menu.addAction(add_attr_action)

        edit_attr_action = QAction("Edit Selected Attribute...", self)
        edit_attr_action.triggered.connect(self.edit_attribute)
        edit_menu.addAction(edit_attr_action)

        delete_attr_action = QAction("Delete Selected Attribute", self)
        delete_attr_action.triggered.connect(self.delete_attribute)
        edit_menu.addAction(delete_attr_action)

        # View Menu
        view_menu = menubar.addMenu("View")

        self.view_viewer_action = QAction("Switch to Viewer", self)
        self.view_viewer_action.setShortcut("Ctrl+1")
        self.view_viewer_action.triggered.connect(lambda: self.tabs.setCurrentIndex(0))
        view_menu.addAction(self.view_viewer_action)

        self.view_editor_action = QAction("Switch to Attribute Editor", self)
        self.view_editor_action.setShortcut("Ctrl+2")
        self.view_editor_action.triggered.connect(lambda: self.tabs.setCurrentIndex(1))
        view_menu.addAction(self.view_editor_action)

        view_menu.addSeparator()

        refresh_action = QAction("Refresh Attributes", self)
        refresh_action.setShortcut("F5")
        refresh_action.triggered.connect(self.populate_attributes_tree)
        view_menu.addAction(refresh_action)

        # Tools Menu
        tools_menu = menubar.addMenu("Tools")

        gpu_settings_action = QAction("GPU Settings...", self)
        gpu_settings_action.triggered.connect(self.show_gpu_settings)
        tools_menu.addAction(gpu_settings_action)

        tools_menu.addSeparator()

        compress_action = QAction("Compression Settings...", self)
        compress_action.triggered.connect(self.save_file)
        tools_menu.addAction(compress_action)

        # Help Menu
        help_menu = menubar.addMenu("Help")

        about_action = QAction("About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def create_info_bar(self):
        """Create bottom info bar with system stats"""
        self.info_bar = QFrame()
        self.info_bar.setFrameStyle(QFrame.Shape.StyledPanel | QFrame.Shadow.Sunken)
        info_layout = QHBoxLayout(self.info_bar)
        info_layout.setContentsMargins(5, 2, 5, 2)

        # GPU Info
        self.lbl_gpu = QLabel("GPU: Detecting...")
        info_layout.addWidget(self.lbl_gpu)
        info_layout.addWidget(self.create_separator())

        # RAM Usage
        self.lbl_ram = QLabel("RAM: 0 MB")
        info_layout.addWidget(self.lbl_ram)
        info_layout.addWidget(self.create_separator())

        # CPU Usage
        self.lbl_cpu = QLabel("CPU: 0%")
        info_layout.addWidget(self.lbl_cpu)
        info_layout.addWidget(self.create_separator())

        # File Info
        self.lbl_file_info = QLabel("No file loaded")
        info_layout.addWidget(self.lbl_file_info)

        info_layout.addStretch()

        # Progress bar
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setMaximumWidth(200)
        self.progress.setMaximumHeight(16)
        info_layout.addWidget(self.progress)

        # Detect GPU
        self.detect_gpu()

    def create_separator(self):
        """Create vertical separator for info bar"""
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.VLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)
        return sep

    def detect_gpu(self):
        """Detect GPU using vispy/OpenGL"""
        try:
            from vispy import gloo
            gl_renderer = gloo.gl.glGetParameter(gloo.gl.GL_RENDERER)
            gl_vendor = gloo.gl.glGetParameter(gloo.gl.GL_VENDOR)

            # Show warning if not using NVIDIA GPU on systems with NVIDIA GPU
            has_nvidia = any(gpu['vendor'] == 'NVIDIA' for gpu in self.available_gpus)
            is_using_nvidia = 'NVIDIA' in gl_renderer or 'NVIDIA' in gl_vendor

            if has_nvidia and not is_using_nvidia:
                self.lbl_gpu.setText(f"GPU: {gl_renderer} ⚠️ (Click Tools → GPU Settings)")
                self.lbl_gpu.setStyleSheet("color: orange;")
            else:
                self.lbl_gpu.setText(f"GPU: {gl_renderer}")
                self.lbl_gpu.setStyleSheet("")
        except Exception as e:
            self.lbl_gpu.setText(f"GPU: {platform.processor()} (Software)")

    def update_info_bar(self):
        """Update info bar with current stats"""
        # RAM Usage
        mem_info = self.process.memory_info()
        ram_mb = mem_info.rss / (1024 * 1024)
        self.lbl_ram.setText(f"RAM: {ram_mb:.1f} MB")

        # CPU Usage
        cpu_percent = self.process.cpu_percent()
        self.lbl_cpu.setText(f"CPU: {cpu_percent:.1f}%")

        # File Info
        if self.dataset and self.current_file_path:
            import os
            file_size = os.path.getsize(self.current_file_path) / (1024 * 1024)
            num_vars = len(self.dataset.variables)
            self.lbl_file_info.setText(f"File: {os.path.basename(self.current_file_path)} ({file_size:.1f} MB, {num_vars} vars)")
        else:
            self.lbl_file_info.setText("No file loaded")

    def create_file_browser(self, tab_name="main"):
        """Create file browser widget for a specific tab"""
        browser_group = QGroupBox("File Browser")
        browser_layout = QVBoxLayout(browser_group)

        # Open button
        btn_open = QPushButton("Open NetCDF File Dialog")
        btn_open.setStyleSheet("background: #0078d7; color: white; font-weight: bold; padding: 8px;")
        btn_open.clicked.connect(lambda: self.open_file())
        browser_layout.addWidget(btn_open)

        # Navigation toolbar
        nav_widget = QWidget()
        nav_layout = QHBoxLayout(nav_widget)
        nav_layout.setContentsMargins(0, 0, 0, 0)

        # Drive selector
        drive_combo = QComboBox()
        self.populate_drives_for_combo(drive_combo)
        drive_combo.currentTextChanged.connect(lambda path: self.navigate_to_path(path) if path else None)
        nav_layout.addWidget(QLabel("Drive:"))
        nav_layout.addWidget(drive_combo)

        # Up directory button
        btn_up = QPushButton("Up")
        btn_up.clicked.connect(self.navigate_up)
        nav_layout.addWidget(btn_up)

        browser_layout.addWidget(nav_widget)

        # Current path display
        path_widget = QWidget()
        path_layout = QHBoxLayout(path_widget)
        path_layout.setContentsMargins(0, 0, 0, 0)
        path_layout.addWidget(QLabel("Path:"))
        path_edit = QLineEdit()
        path_edit.setText(QDir.currentPath())
        path_edit.returnPressed.connect(lambda: self.navigate_to_path(path_edit.text()))
        path_layout.addWidget(path_edit)
        btn_go = QPushButton("Go")
        btn_go.clicked.connect(lambda: self.navigate_to_path(path_edit.text()))
        path_layout.addWidget(btn_go)
        browser_layout.addWidget(path_widget)

        # File system tree
        file_tree = QTreeView()
        file_model = QFileSystemModel()
        file_model.setRootPath("")
        file_model.setNameFilters(["*.nc", "*.nc4", "*.netcdf"])
        file_model.setNameFilterDisables(False)

        file_tree.setModel(file_model)
        file_tree.setRootIndex(file_model.index(QDir.currentPath()))
        file_tree.setColumnWidth(0, 200)
        file_tree.setAlternatingRowColors(True)
        file_tree.doubleClicked.connect(lambda idx: self.on_file_double_clicked_handler(idx, file_model))
        file_tree.clicked.connect(lambda idx: path_edit.setText(file_model.filePath(idx)) if QDir(file_model.filePath(idx)).exists() else None)

        browser_layout.addWidget(file_tree)

        # Engine selector (shared across tabs)
        if not hasattr(self, 'engine_combo'):
            engine_widget = QWidget()
            engine_layout = QHBoxLayout(engine_widget)
            engine_layout.setContentsMargins(0, 0, 0, 0)
            engine_layout.addWidget(QLabel("Engine:"))
            self.engine_combo = QComboBox()
            self.engine_combo.addItems(["netcdf4", "h5netcdf", "scipy", "pynio"])
            self.engine_combo.setCurrentText("netcdf4")
            engine_layout.addWidget(self.engine_combo)
            engine_layout.addStretch()
            browser_layout.addWidget(engine_widget)

        # Store references for navigation
        if tab_name == "viewer":
            self.viewer_path_edit = path_edit
            self.viewer_file_tree = file_tree
        else:
            self.editor_path_edit = path_edit
            self.editor_file_tree = file_tree

        browser_group.setMaximumWidth(350)
        return browser_group

    def create_viewer_tab(self):
        """Create the viewer tab with controls on left and visualization on right"""
        viewer_widget = QWidget()
        viewer_layout = QHBoxLayout(viewer_widget)
        viewer_layout.setContentsMargins(0, 0, 0, 0)

        # Splitter: Left Panel (Browser + Controls) | Visualization
        viewer_splitter = QSplitter(Qt.Orientation.Horizontal)

        # === LEFT PANEL: File Browser + Controls ===
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(5, 5, 5, 5)
        left_layout.setSpacing(10)

        # File browser on top
        browser_widget = self.create_file_browser("viewer")
        left_layout.addWidget(browser_widget)

        # Add separator
        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setFrameShadow(QFrame.Shadow.Sunken)
        left_layout.addWidget(separator)

        # === Viewer Controls ===
        controls_label = QLabel("Viewer Controls")
        font = controls_label.font()
        font.setBold(True)
        controls_label.setFont(font)
        left_layout.addWidget(controls_label)

        # Variable selector
        left_layout.addWidget(QLabel("Variable:"))
        self.combo_var = QComboBox()
        self.combo_var.currentTextChanged.connect(self.load_variable)
        left_layout.addWidget(self.combo_var)

        # Colormap
        left_layout.addWidget(QLabel("Colormap:"))
        self.combo_cmap = QComboBox()
        self.combo_cmap.addItems(["viridis", "magma", "plasma", "inferno", "hsl", "grays", "cool", "hot"])
        self.combo_cmap.currentTextChanged.connect(self.update_render)
        left_layout.addWidget(self.combo_cmap)

        # Min
        left_layout.addWidget(QLabel("Min:"))
        contrast_min_layout = QHBoxLayout()
        self.slider_vmin = QSlider(Qt.Orientation.Horizontal)
        self.slider_vmin.setRange(0, 1000)
        self.slider_vmin.setValue(0)
        self.slider_vmin.valueChanged.connect(self.on_contrast_slider_move)
        self.slider_vmin.sliderReleased.connect(self.on_contrast_change)
        self.spin_vmin = QDoubleSpinBox()
        self.spin_vmin.setRange(-1e15, 1e15)
        self.spin_vmin.setDecimals(2)
        self.spin_vmin.setValue(0)
        self.spin_vmin.valueChanged.connect(self.on_manual_vmin_change)
        contrast_min_layout.addWidget(self.slider_vmin, stretch=3)
        contrast_min_layout.addWidget(self.spin_vmin, stretch=1)
        left_layout.addLayout(contrast_min_layout)

        # Max
        left_layout.addWidget(QLabel("Max:"))
        contrast_max_layout = QHBoxLayout()
        self.slider_vmax = QSlider(Qt.Orientation.Horizontal)
        self.slider_vmax.setRange(0, 1000)
        self.slider_vmax.setValue(1000)
        self.slider_vmax.valueChanged.connect(self.on_contrast_slider_move)
        self.slider_vmax.sliderReleased.connect(self.on_contrast_change)
        self.spin_vmax = QDoubleSpinBox()
        self.spin_vmax.setRange(-1e15, 1e15)
        self.spin_vmax.setDecimals(2)
        self.spin_vmax.setValue(100)
        self.spin_vmax.valueChanged.connect(self.on_manual_vmax_change)
        contrast_max_layout.addWidget(self.slider_vmax, stretch=3)
        contrast_max_layout.addWidget(self.spin_vmax, stretch=1)
        left_layout.addLayout(contrast_max_layout)

        # Time/Depth Index
        left_layout.addWidget(QLabel("Time/Depth Index:"))
        time_layout = QHBoxLayout()
        self.slider_time = QSlider(Qt.Orientation.Horizontal)
        self.slider_time.setEnabled(False)
        self.slider_time.valueChanged.connect(self.on_time_slider_change)
        self.spin_time = QSpinBox()
        self.spin_time.setEnabled(False)
        self.spin_time.valueChanged.connect(self.on_manual_time_change)
        time_layout.addWidget(self.slider_time, stretch=3)
        time_layout.addWidget(self.spin_time, stretch=1)
        left_layout.addLayout(time_layout)

        # BBox Input
        left_layout.addWidget(QLabel("Focus BBox (lon_min, lat_min, lon_max, lat_max):"))
        bbox_layout = QHBoxLayout()
        self.bbox_lonmin = QLineEdit()
        self.bbox_lonmin.setPlaceholderText("lon_min")
        self.bbox_latmin = QLineEdit()
        self.bbox_latmin.setPlaceholderText("lat_min")
        self.bbox_lonmax = QLineEdit()
        self.bbox_lonmax.setPlaceholderText("lon_max")
        self.bbox_latmax = QLineEdit()
        self.bbox_latmax.setPlaceholderText("lat_max")
        bbox_layout.addWidget(self.bbox_lonmin)
        bbox_layout.addWidget(self.bbox_latmin)
        bbox_layout.addWidget(self.bbox_lonmax)
        bbox_layout.addWidget(self.bbox_latmax)
        left_layout.addLayout(bbox_layout)

        btn_apply_bbox = QPushButton("Apply BBox")
        btn_apply_bbox.clicked.connect(self.apply_bbox)
        left_layout.addWidget(btn_apply_bbox)

        left_layout.addStretch()
        left_panel.setMaximumWidth(350)
        viewer_splitter.addWidget(left_panel)

        # === RIGHT PANEL: Visualization ===
        viz_panel = QWidget()
        viz_layout = QVBoxLayout(viz_panel)
        viz_layout.setContentsMargins(0, 0, 0, 0)

        # --- VisPy Setup with Grid Layout (Fixed Rulers) ---
        self.canvas = scene.SceneCanvas(keys='interactive', bgcolor='#050505')

        # Create a Grid for fixed axes
        self.grid = self.canvas.central_widget.add_grid(margin=10)
        self.grid.spacing = 0

        # Grid Layout:
        #      Col 0       Col 1
        # Row 0  [Empty]     [Title]
        # Row 1  [Y-Axis]    [ViewBox (Map)]
        # Row 2  [Empty]     [X-Axis]

        # Title (Row 0, Col 1)
        self.title_view = self.grid.add_view(row=0, col=1, border_color=None)
        self.title_view.height_max = 35
        self.title_view.camera = scene.cameras.PanZoomCamera()
        self.title_view.camera.interactive = False
        self.title_view.camera.set_range(x=(-1, 1), y=(-1, 1))
        self.title_text = scene.visuals.Text("", color='white', font_size=16, bold=True,
                                             anchor_x='center', anchor_y='center',
                                             pos=(0, 0, 0),
                                             parent=self.title_view.scene)

        # Y-Axis (Latitude) (Row 1, Col 0)
        self.yaxis = scene.AxisWidget(orientation='left', axis_label='Latitude',
                                      text_color='white', axis_color='white', tick_color='white')
        self.yaxis.width_max = 60
        self.grid.add_widget(self.yaxis, row=1, col=0)

        # ViewBox (The Map) (Row 1, Col 1)
        self.view = self.grid.add_view(row=1, col=1, border_color='white')
        self.view.camera = scene.PanZoomCamera(aspect=1)

        # X-Axis (Longitude) (Row 2, Col 1)
        self.xaxis = scene.AxisWidget(orientation='bottom', axis_label='Longitude',
                                      text_color='white', axis_color='white', tick_color='white')
        self.xaxis.height_max = 40
        self.grid.add_widget(self.xaxis, row=2, col=1)

        # Link Axes to Camera
        self.xaxis.link_view(self.view)
        self.yaxis.link_view(self.view)

        # Image Visual
        self.image = scene.visuals.Image(parent=self.view.scene, method='auto')

        # Add right-click context menu to canvas
        self.canvas.native.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.canvas.native.customContextMenuRequested.connect(self.show_canvas_context_menu)

        # Add canvas to viz panel
        viz_layout.addWidget(self.canvas.native, stretch=1)

        # Add viz panel to splitter
        viewer_splitter.addWidget(viz_panel)
        viewer_splitter.setSizes([350, 1250])

        # Add splitter to main layout
        viewer_layout.addWidget(viewer_splitter)

        return viewer_widget

    def create_editor_tab(self):
        """Create editor tab with file browser and attributes viewer"""
        editor_widget = QWidget()
        editor_layout = QHBoxLayout(editor_widget)
        editor_layout.setContentsMargins(0, 0, 0, 0)

        # Splitter: File Browser | Attributes
        editor_splitter = QSplitter(Qt.Orientation.Horizontal)

        # File browser on left
        browser_widget = self.create_file_browser("editor")
        editor_splitter.addWidget(browser_widget)

        # === Attributes Viewer Section (right) ===
        attr_group = QGroupBox("NetCDF Structure & Attributes")
        attr_layout = QVBoxLayout(attr_group)

        # Toolbar for attributes
        attr_toolbar = QWidget()
        attr_toolbar_layout = QHBoxLayout(attr_toolbar)
        attr_toolbar_layout.setContentsMargins(0, 0, 0, 0)

        self.btn_add_attr = QPushButton("Add Attribute")
        self.btn_add_attr.clicked.connect(self.add_attribute)
        self.btn_edit_attr = QPushButton("Edit Selected")
        self.btn_edit_attr.clicked.connect(self.edit_attribute)
        self.btn_delete_attr = QPushButton("Delete Selected")
        self.btn_delete_attr.clicked.connect(self.delete_attribute)
        self.btn_save_file = QPushButton("Save As...")
        self.btn_save_file.setStyleSheet("background: #107c10; color: white; font-weight: bold;")
        self.btn_save_file.clicked.connect(self.save_file)

        attr_toolbar_layout.addWidget(self.btn_add_attr)
        attr_toolbar_layout.addWidget(self.btn_edit_attr)
        attr_toolbar_layout.addWidget(self.btn_delete_attr)
        attr_toolbar_layout.addWidget(self.btn_save_file)

        # Attributes tree
        self.attr_tree = QTreeWidget()
        self.attr_tree.setHeaderLabels(["Name", "Value", "Type", "Info"])
        self.attr_tree.setAlternatingRowColors(True)
        self.attr_tree.setColumnWidth(0, 150)
        self.attr_tree.setColumnWidth(1, 150)
        self.attr_tree.itemDoubleClicked.connect(self.on_attr_item_double_clicked)

        attr_layout.addWidget(attr_toolbar)
        attr_layout.addWidget(self.attr_tree)

        # === Assemble Editor Tab ===
        editor_splitter.addWidget(attr_group)
        editor_splitter.setSizes([350, 1250])

        editor_layout.addWidget(editor_splitter)
        return editor_widget

    def populate_drives_for_combo(self, combo):
        """Populate drive combo with available drives"""
        if platform.system() == 'Windows':
            import string
            from pathlib import Path
            available_drives = []
            for letter in string.ascii_uppercase:
                drive = f"{letter}:\\"
                if Path(drive).exists():
                    available_drives.append(drive)
            combo.addItems(available_drives)

            # Set current drive
            current = QDir.currentPath()
            if len(current) >= 2 and current[1] == ':':
                current_drive = current[:3]
                index = combo.findText(current_drive)
                if index >= 0:
                    combo.setCurrentIndex(index)
        else:
            # Unix-like systems
            combo.addItems(["/", QDir.homePath()])

    def on_file_double_clicked_handler(self, index, model):
        """Handle double-click on file in browser"""
        file_path = model.filePath(index)
        if QDir(file_path).exists():
            # It's a directory, navigate into it
            self.navigate_to_path(file_path)
        elif file_path.endswith(('.nc', '.nc4', '.netcdf')):
            # It's a NetCDF file, open it
            self.open_file(file_path)

    def navigate_up(self):
        """Navigate to parent directory"""
        # Get current tab and use appropriate path edit
        current_tab = self.tabs.currentIndex()
        path_edit = self.viewer_path_edit if current_tab == 0 else self.editor_path_edit
        current_path = path_edit.text()
        parent_dir = QDir(current_path)
        if parent_dir.cdUp():
            self.navigate_to_path(parent_dir.absolutePath())

    def navigate_to_path(self, path):
        """Navigate file browser to specified path in current tab"""
        if QDir(path).exists():
            # Update both file browsers to stay in sync
            if hasattr(self, 'viewer_path_edit'):
                self.viewer_path_edit.setText(path)
                index = self.viewer_file_tree.model().index(path)
                self.viewer_file_tree.setRootIndex(index)
            if hasattr(self, 'editor_path_edit'):
                self.editor_path_edit.setText(path)
                index = self.editor_file_tree.model().index(path)
                self.editor_file_tree.setRootIndex(index)

    def on_manual_vmin_change(self, value):
        """Handle manual vmin value change from spinbox"""
        if not self.global_stats:
            return
        g_min = self.global_stats['vmin']
        g_max = self.global_stats['vmax']
        span = g_max - g_min
        # Convert value to slider position
        pct = (value - g_min) / span if span > 0 else 0
        slider_val = int(pct * 1000)
        self.slider_vmin.blockSignals(True)
        self.slider_vmin.setValue(max(0, min(1000, slider_val)))
        self.slider_vmin.blockSignals(False)
        self.update_render(use_sliders=True)

    def on_manual_vmax_change(self, value):
        """Handle manual vmax value change from spinbox"""
        if not self.global_stats:
            return
        g_min = self.global_stats['vmin']
        g_max = self.global_stats['vmax']
        span = g_max - g_min
        # Convert value to slider position
        pct = (value - g_min) / span if span > 0 else 0
        slider_val = int(pct * 1000)
        self.slider_vmax.blockSignals(True)
        self.slider_vmax.setValue(max(0, min(1000, slider_val)))
        self.slider_vmax.blockSignals(False)
        self.update_render(use_sliders=True)

    def on_time_slider_change(self, value):
        """Handle time slider change"""
        self.spin_time.blockSignals(True)
        self.spin_time.setValue(value)
        self.spin_time.blockSignals(False)
        self.update_render()

    def on_manual_time_change(self, value):
        """Handle manual time index change from spinbox"""
        self.slider_time.blockSignals(True)
        self.slider_time.setValue(value)
        self.slider_time.blockSignals(False)
        self.update_render()

    def apply_bbox(self):
        """Apply bounding box to focus view"""
        try:
            lon_min = float(self.bbox_lonmin.text())
            lat_min = float(self.bbox_latmin.text())
            lon_max = float(self.bbox_lonmax.text())
            lat_max = float(self.bbox_latmax.text())

            self.view.camera.set_range(x=(lon_min, lon_max), y=(lat_min, lat_max), margin=0)
        except ValueError:
            QMessageBox.warning(self, "Invalid BBox", "Please enter valid numeric values for bounding box.")

    def show_canvas_context_menu(self, position):
        """Show right-click context menu on canvas"""
        menu = QMenu(self)

        reset_action = QAction("Reset View", self)
        reset_action.triggered.connect(self.reset_view)
        menu.addAction(reset_action)

        menu.addSeparator()

        export_png_action = QAction("Export to High-Res PNG...", self)
        export_png_action.triggered.connect(self.export_highres_png)
        menu.addAction(export_png_action)

        export_current_action = QAction("Export Current View as PNG...", self)
        export_current_action.triggered.connect(self.export_current_png)
        menu.addAction(export_current_action)

        menu.addSeparator()

        copy_bounds_action = QAction("Copy Current Bounds to BBox", self)
        copy_bounds_action.triggered.connect(self.copy_bounds_to_bbox)
        menu.addAction(copy_bounds_action)

        menu.exec(self.canvas.native.mapToGlobal(position))

    def reset_view(self):
        """Reset camera view to full extent"""
        if self.bounds:
            x0, x1 = self.bounds['x_min'], self.bounds['x_max']
            y0, y1 = self.bounds['y_min'], self.bounds['y_max']
            self.view.camera.set_range(x=(x0, x1), y=(y0, y1), margin=0)

    def export_highres_png(self):
        """Export visualization to high-resolution PNG"""
        if self.volume is None:
            QMessageBox.warning(self, "No Data", "No data loaded to export.")
            return

        fname, _ = QFileDialog.getSaveFileName(self, "Export High-Res PNG", "", "PNG Image (*.png)")
        if not fname:
            return

        try:
            from PIL import Image
            import matplotlib.pyplot as plt
            import matplotlib.colors as mcolors

            # Get current data slice
            idx = self.slider_time.value()
            if self.volume.ndim > 2:
                flat_idx = np.unravel_index(idx, self.volume.shape[:-2])
                slicer = tuple(flat_idx) + (slice(None), slice(None))
                data_slice = self.volume[slicer]
            else:
                data_slice = self.volume

            # Get current color limits
            clim = self.image.clim
            cmap_name = self.combo_cmap.currentText()

            # Create high-res figure
            dpi = 300
            fig_width = 3840 / dpi
            fig_height = 2160 / dpi
            fig, ax = plt.subplots(figsize=(fig_width, fig_height), dpi=dpi)

            # Plot with current settings
            im = ax.imshow(data_slice, cmap=cmap_name, vmin=clim[0], vmax=clim[1],
                          aspect='auto', interpolation='bilinear')

            # Add colorbar
            plt.colorbar(im, ax=ax, orientation='horizontal', pad=0.05, fraction=0.046)

            # Set title
            if hasattr(self, 'current_var_name'):
                title = self.title_text.text
                ax.set_title(title, fontsize=16)

            # Remove axes for clean export
            ax.axis('off')

            # Save
            plt.savefig(fname, dpi=dpi, bbox_inches='tight', facecolor='black')
            plt.close(fig)

            QMessageBox.information(self, "Success", f"High-res image (3840x2160) exported to:\n{fname}")
        except Exception as e:
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Export Failed", str(e))

    def export_current_png(self):
        """Export current canvas view as PNG"""
        if self.volume is None:
            QMessageBox.warning(self, "No Data", "No data loaded to export.")
            return

        fname, _ = QFileDialog.getSaveFileName(self, "Export PNG", "", "PNG Image (*.png)")
        if not fname:
            return

        try:
            from PIL import Image

            # Get current canvas as image
            region = (0, 0, self.canvas.size[0], self.canvas.size[1])
            img = self.canvas.render(region=region, alpha=False)

            # Convert to PIL Image and save
            pil_img = Image.fromarray(img)
            pil_img.save(fname)

        except Exception as e:
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Export Failed", str(e))

    def copy_bounds_to_bbox(self):
        """Copy current camera bounds to bbox input fields"""
        rect = self.view.camera.rect
        self.bbox_lonmin.setText(f"{rect.left:.2f}")
        self.bbox_latmin.setText(f"{rect.bottom:.2f}")
        self.bbox_lonmax.setText(f"{rect.right:.2f}")
        self.bbox_latmax.setText(f"{rect.top:.2f}")

    def open_file(self, file_path=None):
        """Open NetCDF file, either from parameter or file dialog"""
        if file_path is None:
            fname, _ = QFileDialog.getOpenFileName(self, "Open NetCDF", "", "NetCDF (*.nc *.nc4 *.netcdf)")
            if not fname:
                return
        else:
            fname = file_path

        try:
            if self.dataset:
                self.dataset.close()

            # Get selected engine
            engine = self.engine_combo.currentText()

            # Open with specified engine
            self.dataset = xr.open_dataset(fname, engine=engine, decode_timedelta=False)
            self.current_file_path = fname

            # Populate attributes tree
            self.populate_attributes_tree()

            # Update variable selector
            valid_vars = [v for v in self.dataset.variables if len(self.dataset[v].dims) >= 2]
            self.combo_var.blockSignals(True)
            self.combo_var.clear()
            self.combo_var.addItems(valid_vars)
            self.combo_var.blockSignals(False)

            if valid_vars:
                self.load_variable(valid_vars[0])
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open file with engine '{engine}':\n{str(e)}")

    def populate_attributes_tree(self):
        """Populate tree with complete NetCDF structure: dimensions, variables, attributes"""
        self.attr_tree.clear()
        if not self.dataset:
            return

        ds = self.dataset
        bold_font = QFont()
        bold_font.setBold(True)

        # === GLOBAL ATTRIBUTES ===
        global_item = QTreeWidgetItem(["Global Attributes", "", "", f"{len(ds.attrs)} attributes"])
        global_item.setFont(0, bold_font)
        global_item.setData(0, Qt.ItemDataRole.UserRole, {'type': 'global_attrs'})
        for key, val in ds.attrs.items():
            attr_item = QTreeWidgetItem([key, str(val)[:100], type(val).__name__, "global attr"])
            attr_item.setData(0, Qt.ItemDataRole.UserRole, {'type': 'global_attr', 'name': key, 'value': val})
            global_item.addChild(attr_item)
        self.attr_tree.addTopLevelItem(global_item)
        global_item.setExpanded(True)

        # === DIMENSIONS ===
        dims_item = QTreeWidgetItem(["Dimensions", "", "", f"{len(ds.sizes)} dimensions"])
        dims_item.setFont(0, bold_font)
        dims_item.setData(0, Qt.ItemDataRole.UserRole, {'type': 'dimensions'})
        for dim_name, dim_size in ds.sizes.items():
            unlimited = " (unlimited)" if dim_name in ds.encoding.get('unlimited_dims', []) else ""
            dim_child = QTreeWidgetItem([dim_name, str(dim_size), "dimension", unlimited])
            dim_child.setData(0, Qt.ItemDataRole.UserRole, {'type': 'dimension', 'name': dim_name, 'size': dim_size})
            dims_item.addChild(dim_child)
        self.attr_tree.addTopLevelItem(dims_item)
        dims_item.setExpanded(True)

        # === VARIABLES ===
        vars_item = QTreeWidgetItem(["Variables", "", "", f"{len(ds.variables)} variables"])
        vars_item.setFont(0, bold_font)
        vars_item.setData(0, Qt.ItemDataRole.UserRole, {'type': 'variables'})

        for var_name in ds.variables:
            var = ds[var_name]
            dims_str = f"({', '.join(var.dims)})" if var.dims else "(scalar)"
            shape_str = str(var.shape)
            dtype_str = str(var.dtype)

            var_item = QTreeWidgetItem([var_name, shape_str, dtype_str, dims_str])
            var_item.setFont(0, bold_font)
            var_item.setData(0, Qt.ItemDataRole.UserRole, {
                'type': 'variable',
                'name': var_name,
                'dims': var.dims,
                'shape': var.shape,
                'dtype': var.dtype
            })

            # Variable attributes
            for attr_name, attr_val in var.attrs.items():
                attr_child = QTreeWidgetItem([
                    f"  @{attr_name}",
                    str(attr_val)[:100],
                    type(attr_val).__name__,
                    "var attr"
                ])
                attr_child.setData(0, Qt.ItemDataRole.UserRole, {
                    'type': 'var_attr',
                    'var_name': var_name,
                    'attr_name': attr_name,
                    'value': attr_val
                })
                var_item.addChild(attr_child)

            # Data preview for small 1D/2D variables
            if var.ndim <= 2 and var.size < 10000:
                preview_item = QTreeWidgetItem(["  [Data Preview]", "double-click to view", "", ""])
                preview_item.setData(0, Qt.ItemDataRole.UserRole, {
                    'type': 'data_preview',
                    'var_name': var_name
                })
                var_item.addChild(preview_item)

            vars_item.addChild(var_item)

        self.attr_tree.addTopLevelItem(vars_item)
        vars_item.setExpanded(True)

    def on_attr_item_double_clicked(self, item, column):
        """Handle double-click on attribute tree items"""
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data:
            return

        if data['type'] == 'data_preview':
            self.show_data_preview(data['var_name'])
        elif data['type'] in ['global_attr', 'var_attr']:
            self.edit_attribute_inline(item, data)

    def show_data_preview(self, var_name):
        """Show data preview in a table dialog"""
        var = self.dataset[var_name]
        data = var.values

        dialog = QDialog(self)
        dialog.setWindowTitle(f"Data Preview: {var_name}")
        dialog.resize(600, 400)
        layout = QVBoxLayout(dialog)

        info_label = QLabel(f"Shape: {var.shape} | Dims: {var.dims} | Dtype: {var.dtype}")
        layout.addWidget(info_label)

        table = QTableWidget()

        if var.ndim == 1:
            table.setRowCount(min(len(data), 1000))
            table.setColumnCount(2)
            table.setHorizontalHeaderLabels(["Index", "Value"])
            for i in range(min(len(data), 1000)):
                table.setItem(i, 0, QTableWidgetItem(str(i)))
                table.setItem(i, 1, QTableWidgetItem(str(data[i])))
        elif var.ndim == 2:
            rows, cols = data.shape
            table.setRowCount(min(rows, 100))
            table.setColumnCount(min(cols, 50))
            for i in range(min(rows, 100)):
                for j in range(min(cols, 50)):
                    table.setItem(i, j, QTableWidgetItem(str(data[i, j])))

        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(table)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn)

        dialog.exec()

    def add_attribute(self):
        """Add new attribute dialog"""
        if not self.dataset:
            QMessageBox.warning(self, "No File", "Please open a NetCDF file first.")
            return

        selected = self.attr_tree.selectedItems()
        if not selected:
            QMessageBox.information(self, "Select Target", "Select a variable or Global Attributes to add an attribute.")
            return

        item = selected[0]
        data = item.data(0, Qt.ItemDataRole.UserRole)

        dialog = QDialog(self)
        dialog.setWindowTitle("Add Attribute")
        layout = QVBoxLayout(dialog)

        layout.addWidget(QLabel("Attribute Name:"))
        name_edit = QLineEdit()
        layout.addWidget(name_edit)

        layout.addWidget(QLabel("Attribute Value:"))
        value_edit = QLineEdit()
        layout.addWidget(value_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            attr_name = name_edit.text().strip()
            attr_value = value_edit.text().strip()

            if not attr_name:
                QMessageBox.warning(self, "Invalid", "Attribute name cannot be empty.")
                return

            try:
                # Try to convert value to number if possible
                try:
                    attr_value = float(attr_value)
                    if attr_value.is_integer():
                        attr_value = int(attr_value)
                except ValueError:
                    pass  # Keep as string

                if data and data['type'] == 'variable':
                    var_name = data['name']
                    self.dataset[var_name].attrs[attr_name] = attr_value
                else:
                    self.dataset.attrs[attr_name] = attr_value

                self.populate_attributes_tree()
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def edit_attribute(self):
        """Edit selected attribute"""
        selected = self.attr_tree.selectedItems()
        if not selected:
            QMessageBox.information(self, "Select Attribute", "Select an attribute to edit.")
            return

        item = selected[0]
        data = item.data(0, Qt.ItemDataRole.UserRole)

        if not data or data['type'] not in ['global_attr', 'var_attr']:
            QMessageBox.information(self, "Invalid Selection", "Please select an attribute to edit.")
            return

        self.edit_attribute_inline(item, data)

    def edit_attribute_inline(self, item, data):
        """Show dialog to edit attribute value"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Edit Attribute")
        layout = QVBoxLayout(dialog)

        if data['type'] == 'global_attr':
            layout.addWidget(QLabel(f"Global Attribute: {data['name']}"))
        else:
            layout.addWidget(QLabel(f"Variable: {data['var_name']}"))
            layout.addWidget(QLabel(f"Attribute: {data['attr_name']}"))

        layout.addWidget(QLabel("Current Value:"))
        layout.addWidget(QLabel(str(data['value'])))

        layout.addWidget(QLabel("New Value:"))
        value_edit = QLineEdit(str(data['value']))
        layout.addWidget(value_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            new_value = value_edit.text().strip()

            try:
                # Try to convert to original type
                try:
                    new_value = type(data['value'])(new_value)
                except (ValueError, TypeError):
                    # If conversion fails, try numeric
                    try:
                        new_value = float(new_value)
                        if new_value.is_integer():
                            new_value = int(new_value)
                    except ValueError:
                        pass  # Keep as string

                if data['type'] == 'global_attr':
                    self.dataset.attrs[data['name']] = new_value
                else:
                    self.dataset[data['var_name']].attrs[data['attr_name']] = new_value

                self.populate_attributes_tree()
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def delete_attribute(self):
        """Delete selected attribute"""
        selected = self.attr_tree.selectedItems()
        if not selected:
            QMessageBox.information(self, "Select Attribute", "Select an attribute to delete.")
            return

        item = selected[0]
        data = item.data(0, Qt.ItemDataRole.UserRole)

        if not data or data['type'] not in ['global_attr', 'var_attr']:
            QMessageBox.information(self, "Invalid Selection", "Please select an attribute to delete.")
            return

        if data['type'] == 'global_attr':
            msg = f"Delete global attribute '{data['name']}'?"
        else:
            msg = f"Delete attribute '{data['attr_name']}' from variable '{data['var_name']}'?"

        reply = QMessageBox.question(self, "Confirm Delete", msg,
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)

        if reply == QMessageBox.StandardButton.Yes:
            try:
                if data['type'] == 'global_attr':
                    del self.dataset.attrs[data['name']]
                else:
                    del self.dataset[data['var_name']].attrs[data['attr_name']]

                self.populate_attributes_tree()
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def close_file(self):
        """Close the currently open file"""
        if self.dataset:
            self.dataset.close()
            self.dataset = None
            self.current_file_path = None
            self.volume = None
            self.global_stats = {}
            self.bounds = {}

            # Clear UI
            self.attr_tree.clear()
            self.combo_var.clear()

            # Clear visualization
            self.image.set_data(np.zeros((10, 10)))

    def show_gpu_settings(self):
        """Show GPU settings dialog"""
        dialog = QDialog(self)
        dialog.setWindowTitle("GPU Settings")
        dialog.resize(600, 450)
        layout = QVBoxLayout(dialog)

        # Info label
        info_label = QLabel("<b>GPU Selection</b><br>Select which GPU to use for rendering:")
        layout.addWidget(info_label)

        # Current GPU info
        try:
            from vispy import gloo
            gl_renderer = gloo.gl.glGetParameter(gloo.gl.GL_RENDERER)
            current_gpu_label = QLabel(f"<b>Currently Active:</b> {gl_renderer}")
            current_gpu_label.setStyleSheet("padding: 10px; background-color: #2d2d2d; border-radius: 5px;")
            layout.addWidget(current_gpu_label)
        except:
            pass

        layout.addWidget(QLabel(""))

        # Available GPUs section
        gpus_group = QGroupBox("Available GPUs")
        gpus_layout = QVBoxLayout(gpus_group)

        # Radio buttons for GPU selection
        self.gpu_button_group = QButtonGroup()
        saved_gpu_id = self.settings.value('selected_gpu_id', -1, type=int)

        # Add "Automatic" option
        auto_radio = QRadioButton("Automatic (System Default)")
        auto_radio.setProperty('gpu_id', -1)
        self.gpu_button_group.addButton(auto_radio)
        gpus_layout.addWidget(auto_radio)

        if saved_gpu_id == -1:
            auto_radio.setChecked(True)

        # Add detected GPUs
        for gpu in self.available_gpus:
            gpu_text = f"{gpu['name']}"
            if gpu['type'] == 'dedicated':
                gpu_text += " (Dedicated GPU - Recommended)"
            elif gpu['type'] == 'integrated':
                gpu_text += " (Integrated Graphics)"

            radio = QRadioButton(gpu_text)
            radio.setProperty('gpu_id', gpu['id'])
            self.gpu_button_group.addButton(radio)
            gpus_layout.addWidget(radio)

            if saved_gpu_id == gpu['id']:
                radio.setChecked(True)

        layout.addWidget(gpus_group)

        # Instructions
        layout.addWidget(QLabel(""))
        instructions_label = QLabel(
            "<b>Note:</b> Changing GPU requires restarting the application.<br>"
            "The application will close and you'll need to launch it again."
        )
        instructions_label.setWordWrap(True)
        instructions_label.setStyleSheet("color: #999; padding: 10px;")
        layout.addWidget(instructions_label)

        # Buttons
        button_box = QDialogButtonBox()
        apply_btn = button_box.addButton("Apply && Restart", QDialogButtonBox.ButtonRole.AcceptRole)
        cancel_btn = button_box.addButton("Cancel", QDialogButtonBox.ButtonRole.RejectRole)

        apply_btn.clicked.connect(lambda: self.apply_gpu_settings(dialog))
        cancel_btn.clicked.connect(dialog.reject)

        layout.addWidget(button_box)

        dialog.exec()

    def apply_gpu_settings(self, dialog):
        """Apply GPU settings and restart application"""
        # Get selected GPU
        selected_button = self.gpu_button_group.checkedButton()
        if not selected_button:
            QMessageBox.warning(self, "No Selection", "Please select a GPU option.")
            return

        gpu_id = selected_button.property('gpu_id')

        # Save settings
        self.settings.setValue('selected_gpu_id', gpu_id)

        # Find the selected GPU
        selected_gpu = None
        if gpu_id >= 0:
            for gpu in self.available_gpus:
                if gpu['id'] == gpu_id:
                    selected_gpu = gpu
                    break

        # Prepare restart message
        if selected_gpu:
            msg = f"GPU selection saved: {selected_gpu['name']}\n\n"
            msg += "The application will now close.\n"
            msg += "Please restart it to use the selected GPU."
        else:
            msg = "GPU selection saved: Automatic\n\n"
            msg += "The application will now close.\n"
            msg += "Please restart it to use automatic GPU selection."

        QMessageBox.information(self, "Restart Required", msg)

        dialog.accept()
        self.close()
        sys.exit(0)

    def show_about(self):
        """Show about dialog"""
        about_text = """
        <h2>Pynoply</h2>
        <p><b>Version:</b> 2.0</p>
        <p><b>Description:</b> Professional NetCDF viewer and editor with GPU-accelerated visualization.</p>
        <p><b>Features:</b></p>
        <ul>
        <li>GPU-accelerated visualization with VisPy</li>
        <li>Complete NetCDF attribute editing</li>
        <li>File compression and format conversion</li>
        <li>Multi-dimensional data navigation</li>
        <li>Real-time system monitoring</li>
        </ul>
        <p><b>Libraries:</b> PyQt6, xarray, VisPy, NumPy, psutil</p>
        """
        QMessageBox.about(self, "About Pynoply", about_text)

    def save_file(self):
        """Save NetCDF file with compression options"""
        if not self.dataset:
            QMessageBox.warning(self, "No File", "No file is currently open.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Save NetCDF File")
        dialog.resize(500, 400)
        layout = QVBoxLayout(dialog)

        # File path
        path_layout = QHBoxLayout()
        path_layout.addWidget(QLabel("Save to:"))
        path_edit = QLineEdit(self.current_file_path if self.current_file_path else "output.nc")
        path_layout.addWidget(path_edit)
        browse_btn = QPushButton("Browse")

        def browse_save():
            fname, _ = QFileDialog.getSaveFileName(self, "Save NetCDF", "", "NetCDF (*.nc *.nc4)")
            if fname:
                path_edit.setText(fname)

        browse_btn.clicked.connect(browse_save)
        path_layout.addWidget(browse_btn)
        layout.addLayout(path_layout)

        # Format selection
        format_group = QGroupBox("NetCDF Format")
        format_layout = QVBoxLayout(format_group)
        format_combo = QComboBox()
        format_combo.addItems(["NETCDF4", "NETCDF4_CLASSIC", "NETCDF3_CLASSIC", "NETCDF3_64BIT"])
        format_layout.addWidget(format_combo)
        layout.addWidget(format_group)

        # Compression options
        comp_group = QGroupBox("Compression (NETCDF4 only)")
        comp_layout = QVBoxLayout(comp_group)

        use_comp_check = QCheckBox("Enable Compression")
        use_comp_check.setChecked(True)
        comp_layout.addWidget(use_comp_check)

        comp_layout.addWidget(QLabel("Compression Level (1-9):"))
        comp_level_spin = QSpinBox()
        comp_level_spin.setRange(1, 9)
        comp_level_spin.setValue(4)
        comp_layout.addWidget(comp_level_spin)

        layout.addWidget(comp_group)

        # Buttons
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            output_path = path_edit.text().strip()
            if not output_path:
                QMessageBox.warning(self, "Invalid", "Please specify output file path.")
                return

            try:
                self.progress.setVisible(True)
                self.progress.setRange(0, 0)

                format_str = format_combo.currentText()
                encoding = {}

                if format_str == "NETCDF4" and use_comp_check.isChecked():
                    comp_level = comp_level_spin.value()
                    for var_name in self.dataset.data_vars:
                        encoding[var_name] = {'zlib': True, 'complevel': comp_level}

                self.dataset.to_netcdf(output_path, format=format_str, encoding=encoding)

                self.progress.setVisible(False)
                QMessageBox.information(self, "Success", f"File saved successfully to:\n{output_path}")

            except Exception as e:
                self.progress.setVisible(False)
                QMessageBox.critical(self, "Error", f"Failed to save file:\n{str(e)}")

    def load_variable(self, var_name):
        if not var_name: return

        self.current_var_name = var_name
        self.progress.setVisible(True)
        self.progress.setRange(0,0)
        self.combo_var.setEnabled(False)

        self.loader = VolumeLoader(self.dataset, var_name)
        self.loader.finished_loading.connect(self.on_load_complete)

        self.loader.start()

    def on_load_complete(self, volume, stats, bounds, msg):
        self.volume = volume
        self.global_stats = stats
        self.bounds = bounds
        self.progress.setVisible(False)
        self.combo_var.setEnabled(True)

        # Setup Time Slider
        if self.volume.ndim > 2:
            total_frames = np.prod(self.volume.shape[:-2])
            self.slider_time.setEnabled(True)
            self.slider_time.setRange(0, total_frames - 1)
            self.slider_time.setValue(0)
            self.spin_time.setEnabled(True)
            self.spin_time.setRange(0, total_frames - 1)
            self.spin_time.setValue(0)
        else:
            self.slider_time.setEnabled(False)
            self.slider_time.setRange(0, 0)
            self.spin_time.setEnabled(False)
            self.spin_time.setRange(0, 0)

        # Reset Contrast Sliders and Spinboxes
        self.slider_vmin.setValue(0)
        self.slider_vmax.setValue(1000)
        self.spin_vmin.setValue(float(stats['vmin']))
        self.spin_vmax.setValue(float(stats['vmax']))
        
        # Setup Geometry (Real world coords)
        h, w = self.volume.shape[-2], self.volume.shape[-1]
        x0, x1 = bounds['x_min'], bounds['x_max']
        y0, y1 = bounds['y_min'], bounds['y_max']
        
        # Transform:
        # Image coords are (0..w, 0..h). 
        # We want (x0..x1, y0..y1).
        # Note: Texture Y=0 is Bottom. Texture Y=h is Top.
        # If we flipped data correctly, Y=0 corresponds to y_min (South).
        
        scale_x = (x1 - x0) / w
        scale_y = (y1 - y0) / h
        
        self.image.transform = STTransform(scale=(scale_x, scale_y), translate=(x0, y0))
        
        # Set Camera Range to whole map
        # Add a slight margin so rulers are clean
        self.view.camera.set_range(x=(x0, x1), y=(y0, y1), margin=0)

        # Update title
        self.update_title()

        self.update_render()

    def on_contrast_slider_move(self):
        """Handle slider movement - update image only, not colorbar"""
        if not self.global_stats:
            return

        g_min = self.global_stats['vmin']
        g_max = self.global_stats['vmax']
        span = g_max - g_min

        cur_min_pct = self.slider_vmin.value() / 1000.0
        cur_max_pct = self.slider_vmax.value() / 1000.0

        val_min = g_min + (span * cur_min_pct)
        val_max = g_min + (span * cur_max_pct)

        # Update spinboxes
        self.spin_vmin.blockSignals(True)
        self.spin_vmax.blockSignals(True)
        self.spin_vmin.setValue(float(val_min))
        self.spin_vmax.setValue(float(val_max))
        self.spin_vmin.blockSignals(False)
        self.spin_vmax.blockSignals(False)

        # Update image
        self.update_render(use_sliders=True)

    def on_contrast_change(self):
        """Handle final contrast change"""
        self.update_render(use_sliders=True)

    def update_title(self):
        """Update the title text above the visualization"""
        if hasattr(self, 'current_var_name') and self.dataset:
            var = self.dataset[self.current_var_name]
            # Try to get long_name attribute
            if 'long_name' in var.attrs:
                title = var.attrs['long_name']
            elif 'title' in self.dataset.attrs:
                title = self.dataset.attrs['title']
            else:
                title = self.current_var_name

            self.title_text.text = title
            # Center the text in the view
            self.title_text.pos = (0, 0, 0)

    def update_render(self, use_sliders=False):
        if self.volume is None: return

        idx = self.slider_time.value()

        # Slice Data
        if self.volume.ndim > 2:
            flat_idx = np.unravel_index(idx, self.volume.shape[:-2])
            slicer = tuple(flat_idx) + (slice(None), slice(None))
            data_slice = self.volume[slicer]
        else:
            data_slice = self.volume

        # Convert to float32 to avoid GPU warning
        data_slice = data_slice.astype(np.float32)

        # Clim
        if use_sliders:
            g_min = self.global_stats['vmin']
            g_max = self.global_stats['vmax']
            span = g_max - g_min
            c_min = g_min + (span * (self.slider_vmin.value() / 1000.0))
            c_max = g_min + (span * (self.slider_vmax.value() / 1000.0))
            clim = (c_min, c_max)
        else:
            # Fast Auto
            valid = data_slice[~np.isnan(data_slice)]
            if valid.size > 0:
                if valid.size > 10000: valid = valid[::10]
                c_min, c_max = np.percentile(valid, 2), np.percentile(valid, 98)
                clim = (c_min, c_max)
            else:
                clim = (0, 1)

        cmap_name = self.combo_cmap.currentText()
        self.image.set_data(data_slice)
        self.image.clim = clim
        self.image.cmap = cmap_name

