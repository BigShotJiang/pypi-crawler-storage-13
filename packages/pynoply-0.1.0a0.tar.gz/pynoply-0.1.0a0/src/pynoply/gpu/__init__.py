"""GPU detection and management utilities."""

from .detection import GPUInfo, detect_available_gpus, apply_gpu_environment

__all__ = ["GPUInfo", "detect_available_gpus", "apply_gpu_environment"]
