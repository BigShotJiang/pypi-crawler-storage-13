"""
GPU detection and environment configuration for Pynoply.
"""

import os
import subprocess
from dataclasses import dataclass, field
from typing import TypedDict


class EnvVars(TypedDict):
    """Type definition for environment variables dictionary."""

    pass


@dataclass
class GPUInfo:
    """Information about a detected GPU."""

    id: int
    name: str
    vendor: str
    type: str  # 'dedicated', 'integrated', or 'unknown'
    env_vars: dict[str, str] = field(default_factory=dict)


def detect_available_gpus() -> list[GPUInfo]:
    """
    Detect available GPUs on the system.

    Returns:
        List of GPUInfo objects containing information about detected GPUs.
    """
    gpus: list[GPUInfo] = []

    # Try to detect NVIDIA GPUs using nvidia-smi
    try:
        result = subprocess.run(
            ["nvidia-smi", "-L"], capture_output=True, text=True, timeout=2
        )
        if result.returncode == 0:
            lines = result.stdout.strip().split("\n")
            for i, line in enumerate(lines):
                if "GPU" in line:
                    # Extract GPU name
                    name = line.split(":", 1)[1].strip()
                    # Remove UUID part
                    if "(UUID" in name:
                        name = name.split("(UUID")[0].strip()
                    gpus.append(
                        GPUInfo(
                            id=i,
                            name=name,
                            vendor="NVIDIA",
                            type="dedicated",
                            env_vars={
                                "__NV_PRIME_RENDER_OFFLOAD": "1",
                                "__GLX_VENDOR_LIBRARY_NAME": "nvidia",
                                "DRI_PRIME": "1",
                            },
                        )
                    )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    # Try to detect Intel integrated graphics using lspci
    try:
        result = subprocess.run(["lspci"], capture_output=True, text=True, timeout=2)
        if result.returncode == 0:
            lines = result.stdout.strip().split("\n")
            for line in lines:
                if "VGA" in line and "Intel" in line:
                    # Extract Intel GPU name
                    parts = line.split(": ", 1)
                    if len(parts) > 1:
                        name = parts[1]
                        gpus.append(
                            GPUInfo(
                                id=len(gpus),
                                name=name,
                                vendor="Intel",
                                type="integrated",
                                env_vars={},  # No special env vars needed for integrated
                            )
                        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    # If no GPUs detected, add a default entry
    if not gpus:
        gpus.append(
            GPUInfo(
                id=0,
                name="Default System GPU",
                vendor="Unknown",
                type="unknown",
                env_vars={},
            )
        )

    return gpus


def apply_gpu_environment(gpu_id: int) -> None:
    """
    Apply environment variables for the selected GPU.

    Args:
        gpu_id: ID of the GPU to use. If -1, auto-select NVIDIA GPU if available.
    """
    available_gpus = detect_available_gpus()

    if gpu_id >= 0:
        # Apply specific GPU settings
        for gpu in available_gpus:
            if gpu.id == gpu_id:
                for key, value in gpu.env_vars.items():
                    os.environ[key] = value
                    print(f"Set {key}={value} for GPU: {gpu.name}")
                break
    else:
        # Auto-select: Prefer NVIDIA GPU if available
        for gpu in available_gpus:
            if gpu.vendor == "NVIDIA":
                for key, value in gpu.env_vars.items():
                    os.environ[key] = value
                    print(f"Auto-selected {gpu.name}: Set {key}={value}")
                break
