"""
Entry point for Pynoply application.
"""

import sys

from PyQt6.QtCore import QSettings
from PyQt6.QtWidgets import QApplication

from .constants import ORGANIZATION_NAME, SETTINGS_APP_NAME
from .gpu import apply_gpu_environment
from .main_window import PynoplyMainWindow


def main() -> int:
    """
    Main entry point for the Pynoply application.

    Returns:
        Exit code
    """
    # Apply GPU settings from saved preferences BEFORE creating QApplication
    # This must be done early as environment variables need to be set before OpenGL initialization
    settings = QSettings(ORGANIZATION_NAME, SETTINGS_APP_NAME)
    selected_gpu_id = settings.value("selected_gpu_id", -1, type=int)

    # Apply GPU environment variables
    apply_gpu_environment(selected_gpu_id)

    # Create application
    app = QApplication(sys.argv)

    # Create and show main window
    window = PynoplyMainWindow()
    window.show()

    # Run event loop
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
