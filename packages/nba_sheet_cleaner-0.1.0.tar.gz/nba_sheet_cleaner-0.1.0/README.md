# NBA Sheet Cleaner

Utility for cleaning NBA projection spreadsheets.

## Usage

### Default behavior

```bash
nba-sheet-clean
```

- If `sheets/` exists alongside `main.py`, every Excel file from that folder (recursively) is processed.
- Otherwise, it falls back to the current directory.
- Cleaned files are written to `<source>/sheets_cleaned/` using the `<name>_cleaned.<ext>` naming convention.

### Custom folder

```bash
nba-sheet-clean path/to/folder
```

Processes only the Excel files found inside `path/to/folder` and writes results to `path/to/folder/sheets_cleaned`.

### Single file

```bash
nba-sheet-clean path/to/file.xlsx
```

Processes only that Excel file and writes the cleaned version to `path/to/sheets_cleaned/file_cleaned.xlsx`.

### Notes

- Files ending with `_cleaned` are automatically skipped.
- The script requires the columns `Name`, `Team`, `p`, `3`, `r`, `a`, `s`, `b`. Missing columns cause the file to be skipped with a log message.
