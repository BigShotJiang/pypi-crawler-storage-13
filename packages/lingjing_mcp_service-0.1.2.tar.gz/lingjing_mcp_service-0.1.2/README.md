# 灵境MCP服务

这是一个为塔易（TaYi）平台定制的，用于连接外部搜索模型的MCP（Model-as-a-Service Connector Provider）服务。
