# lingjing_mcp/server.py

import os
import json
import httpx
import asyncio
import uvicorn
from fastapi import FastAPI
from fastapi.responses import StreamingResponse, JSONResponse

# ------------------- 配置区 -------------------
SEARCH_MODEL_API_KEY = os.environ.get("SEARCH_MODEL_API_KEY", "sk-fkjX35oSw8qNX4kTBwxSE2pAGDpp6Wn9eV1eL3G2F62zWQfu")
SEARCH_MODEL_API_URL = "https://api.tiu.me/v1/chat/completions"
# -------------------------------------------------------------

app = FastAPI(
    title="灵境专属MCP服务",
    description="一个能响应工具发现和执行流式搜索的中间件",
    version="5.1.0",
)

@app.post("/sse")
async def unified_post_handler(query_data: dict):
    print(f"收到 /sse POST 请求，请求内容: {query_data}")

    if query_data.get("method") == "initialize":
        print("识别为 initialize 请求，正在返回工具定义...")
        tool_definition = {
            "tools": [
                {
                    "name": "web_search",
                    "description": "从互联网搜索信息以回答问题。",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "需要搜索的关键词或问题"
                            }
                        },
                        "required": ["query"]
                    }
                }
            ]
        }
        async def tool_definition_stream():
            yield f"data: {json.dumps(tool_definition, ensure_ascii=False)}\n\n" # ensure_ascii=False here
        return StreamingResponse(tool_definition_stream(), media_type="text/event-stream")
    
    print("识别为执行搜索(perform_search)请求...")
    search_query = query_data.get("query")

    headers = {
        "Authorization": f"Bearer {SEARCH_MODEL_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "gemini-2.5-pro-search",
        "messages": [{"role": "user", "content": search_query}],
    }

    async def stream_generator():
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                print("正在建立到外部API的流式连接...")
                # 手动编码payload为UTF-8，解决编码问题
                encoded_payload = json.dumps(payload, ensure_ascii=False).encode('utf-8')
                async with client.stream("POST", SEARCH_MODEL_API_URL, headers=headers, content=encoded_payload) as response:
                    response.raise_for_status()
                    print("流式连接已建立，正在转发数据...")
                    async for chunk in response.aiter_bytes():
                        yield chunk
        except Exception as e:
            import traceback
            print("--- TRACEBACK START ---")
            traceback.print_exc()
            print("--- TRACEBACK END ---")
            print(f"处理流式请求时出错: {e}")
            error_message = f"调用外部搜索模型失败: {str(e)}"
            error_data = json.dumps({"error": error_message}, ensure_ascii=False) # ensure_ascii=False here
            yield f"data: {error_data}\n\n"

    return StreamingResponse(stream_generator(), media_type="text/event-stream")

@app.get("/sse")
async def sse_get_handler():
    print("收到 /sse GET 请求，建立并保持长连接...")
    async def keep_alive_stream():
        while True:
            yield ": keep-alive\n\n"
            await asyncio.sleep(15)
    
    return StreamingResponse(keep_alive_stream(), media_type="text/event-stream")

@app.get("/")
def read_root():
    return {"message": "欢迎使用灵境MCP服务！服务运行正常。"}

def main():
    """
    打包后的程序入口点
    """
    uvicorn.run(app, host="0.0.0.0", port=8000)