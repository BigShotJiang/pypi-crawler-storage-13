import playwright.sync_api
import playwright_stealth_plugin

with playwright.sync_api.sync_playwright() as pw:
    playwright_stealth_plugin.sync_apply(pw)
    browser = pw.chromium.launch()
