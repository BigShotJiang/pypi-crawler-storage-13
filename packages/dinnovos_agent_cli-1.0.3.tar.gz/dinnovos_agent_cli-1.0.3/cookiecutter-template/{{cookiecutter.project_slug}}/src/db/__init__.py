"""Database configuration."""
