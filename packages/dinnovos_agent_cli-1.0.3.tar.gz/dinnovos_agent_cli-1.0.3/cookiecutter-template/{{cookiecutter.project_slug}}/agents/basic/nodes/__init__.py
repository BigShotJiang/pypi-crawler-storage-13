"""Agent nodes."""
