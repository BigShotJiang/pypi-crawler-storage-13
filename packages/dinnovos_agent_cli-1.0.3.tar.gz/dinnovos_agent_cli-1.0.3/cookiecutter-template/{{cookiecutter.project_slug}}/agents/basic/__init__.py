"""Basic agent implementation."""
