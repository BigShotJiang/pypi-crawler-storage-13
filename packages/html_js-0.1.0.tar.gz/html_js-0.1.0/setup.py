from setuptools import setup, find_packages

setup(
    name="html_js",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    description="HTML ve JS kodlarını Python'a ekleyen paket",
    author="Hamza Al",
    author_email="hamza@example.com",
    python_requires=">=3.7",
)