from setuptools import setup

# read the contents of your README file
from os import path
this_directory = path.abspath(path.dirname(__file__))
with open(path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(name='cbpi4-KettleSensor',
      version='0.1.1',
      description='CraftBeerPi4 Plugin to add Sensor parameters for your Kettle and Fermenter',
      author='Alexander Vollkopf',
      author_email='avollkopf@web.de',
      url='https://github.com/PiBrewing/cbpi4-KettleSensor',
      include_package_data=True,
      package_data={
        # If any package contains *.txt or *.rst files, include them:
      '': ['*.txt', '*.rst', '*.yaml'],
      'cbpi4-KettleSensor': ['*','*.txt', '*.rst', '*.yaml']},
      packages=['cbpi4-KettleSensor'],
	  long_description=long_description,
	  long_description_content_type='text/markdown'
     )
