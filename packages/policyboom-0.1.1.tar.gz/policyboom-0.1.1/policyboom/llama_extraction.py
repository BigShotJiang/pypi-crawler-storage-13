"""AI-powered document extraction using Together AI with OpenAI SDK."""

import os
import httpx
from typing import Optional
from openai import OpenAI
from .models import Document, Clause
from .user_agents import get_headers
from .config import get_config
from datetime import datetime
import json
import re
from rich.console import Console


class LlamaExtractor:
    """Extract clauses from legal documents using Llama AI."""
    
    def __init__(self, timeout: int = 30):
        """Initialize Llama Stack client with Together AI."""
        self.timeout = timeout
        self.http_client = httpx.Client(timeout=timeout, follow_redirects=True)
        
        # Get API key from config (file or env var)
        config = get_config()
        api_key = config.get_api_key()
        
        if not api_key:
            # Friendly message instead of crash
            console = Console()
            console.print("\n[yellow]⚠️  No Together AI API key configured[/yellow]")
            console.print("\n[cyan]To use AI-powered extraction:[/cyan]")
            console.print("  1. Run: [bold]policyboom setup[/bold]")
            console.print("  2. Enter your Together AI API key when prompted")
            console.print("\n[dim]Get a free API key at: https://api.together.xyz[/dim]\n")
            raise ValueError("Together AI API key not configured. Run 'policyboom setup' to configure.")
        
        # Use Together AI via OpenAI-compatible API
        self.client = OpenAI(
            api_key=api_key,
            base_url="https://api.together.xyz/v1"
        )
        
        # Use Llama 3.3 70B for best extraction quality
        self.model = "meta-llama/Llama-3.3-70B-Instruct-Turbo"
    
    def cleanup(self):
        """Close the HTTP client."""
        if hasattr(self, 'http_client'):
            self.http_client.close()
    
    def extract_document(self, url: str, doc_type: str) -> Optional[Document]:
        """
        Extract clauses from a legal document using AI.
        
        Returns Document with intelligently parsed clauses.
        """
        try:
            print(f"    🔄 Starting extraction for {url}...")
            
            # Fetch the HTML with random user-agent
            response = self.http_client.get(url, headers=get_headers())
            response.raise_for_status()
            print(f"    ✓ Fetched HTML ({len(response.text)} chars)")
            
            # Validate content before processing
            if not self._is_valid_html_content(response):
                print(f"    ❌ HTML validation failed for {url}")
                return None
            
            html = response.text
            
            # Extract metadata
            print(f"    📋 Extracting metadata...")
            title = self._extract_title(html)
            last_updated = self._extract_last_updated(html)
            
            # Use AI to extract clauses
            print(f"    🤖 Starting AI clause extraction...")
            clauses = self._extract_clauses_with_ai(html, url, doc_type, last_updated)
            
            if not clauses:
                print(f"    ⚠️  No clauses extracted from {url}")
            
            # Always return a Document, even if no clauses found
            # This ensures all fetched documents appear in metadata
            document = Document(
                url=url,
                doc_type=doc_type,
                title=title,
                last_updated=last_updated,
                clauses=clauses  # May be empty list
            )
            
            print(f"    ✅ Document extracted successfully")
            return document
        
        except Exception as e:
            print(f"    ❌ AI extraction error for {url}: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _is_valid_html_content(self, response: httpx.Response) -> bool:
        """
        Validate that response contains valid HTML suitable for AI extraction.
        
        Checks Content-Type, length, and basic HTML structure.
        """
        # Check Content-Type header
        content_type = response.headers.get('content-type', '').lower()
        if 'html' not in content_type:
            return False
        
        # Try to decode text content (handles gzip/compression automatically)
        try:
            content = response.text
        except Exception as e:
            print(f"    ⚠️  Failed to decode response text: {e}")
            return False
        
        # Check content length (minimum 500 chars, max 5MB)
        if len(content) < 500 or len(content) > 5_000_000:
            return False
        
        # Check for basic HTML structure - be flexible with case and whitespace
        # Check for common HTML indicators (doctype, html, body, div, or script tags)
        content_sample = content[:2000].lower()  # Only check first 2000 chars for performance
        has_html_indicators = any([
            '<!doctype' in content_sample,
            '<html' in content_sample,
            '<body' in content_sample,
            '<div' in content_sample,
            '<script' in content_sample,
            '<head' in content_sample
        ])
        
        if not has_html_indicators:
            print(f"    ⚠️  No HTML indicators found in content")
            return False
        
        # Check it's not an error page (common error page indicators)
        error_indicators = ['404 not found', 'page not found', 'error occurred', 'access denied']
        if any(indicator in content_sample for indicator in error_indicators):
            return False
        
        return True
    
    def _extract_clauses_with_ai(self, html: str, url: str, doc_type: str, last_updated: Optional[str]) -> list[Clause]:
        """Use Llama AI to intelligently extract and categorize clauses."""
        
        # Use readability to extract main content (removes nav, scripts, ads, boilerplate)
        from readability import Document
        from bs4 import BeautifulSoup
        
        try:
            # Extract main content using readability
            doc = Document(html)
            clean_html = doc.summary()
            
            # Parse with BeautifulSoup
            soup = BeautifulSoup(clean_html, 'lxml')
            text_content = soup.get_text(separator=' ', strip=True)
            
            print(f"    📝 Extracted {len(text_content)} chars of clean policy text")
        except Exception as e:
            print(f"    ⚠️  Readability extraction failed, falling back to basic extraction: {e}")
            # Fallback to basic extraction
            soup = BeautifulSoup(html, 'lxml')
            text_content = soup.get_text(separator=' ', strip=True)
        
        # Validate text content has enough substance
        if len(text_content) < 200:
            print(f"    ⚠️  Extracted text too short ({len(text_content)} chars), skipping AI analysis")
            return []
        
        # Limit to reasonable size (Llama can handle long context but be efficient)
        if len(text_content) > 20000:
            print(f"    ✂️  Truncating text from {len(text_content)} to 20,000 chars")
            text_content = text_content[:20000]
        
        # Craft extraction prompt
        prompt = f"""You are analyzing a legal policy document. Extract important clauses that users should be aware of.

Focus on these categories:
- **Data Sale/Sharing**: Any mention of selling, renting, monetizing, sharing, or licensing user data to third parties
- **Arbitration**: Forced arbitration, class action waivers, litigation restrictions
- **Tracking**: Analytics, cookies, pixels, user behavior tracking
- **Location Data**: GPS, location tracking, geolocation
- **Data Retention**: How long data is kept
- **Children's Data**: COPPA compliance, data from minors

For each concerning clause you find:
1. Extract the EXACT text as it appears (preserve capitalization, punctuation, spacing)
2. Identify the section heading it belongs to
3. Categorize it (dataSale, arbitration, tracking, location, retention, children)
4. Rate severity (high, medium, low)

Return ONLY a JSON array of clauses. Each clause must have:
- "text": exact clause text (verbatim from document)
- "section": section heading
- "category": one of the categories above
- "severity": high, medium, or low
- "reason": brief explanation why it's concerning

Document text:
{text_content}

Return valid JSON only, no markdown formatting:"""

        try:
            content = None  # Initialize for error handling
            console = Console()
            
            # Call Llama via Together AI with progress indicator
            with console.status("[bold cyan]Thinking...", spinner="dots"):
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {
                            "role": "system",
                            "content": "You are a legal document analyzer. Return only valid JSON arrays with no markdown formatting."
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    temperature=0.1,  # Low temperature for consistent extraction
                    max_tokens=4096
                )
            
            # Parse response
            content = response.choices[0].message.content
            if not content:
                return []
            
            content = content.strip()
            
            # Remove markdown code blocks if present
            if content.startswith("```"):
                content = re.sub(r'^```(?:json)?\n?', '', content)
                content = re.sub(r'\n?```$', '', content)
            
            # Parse JSON
            extracted_clauses = json.loads(content)
            
            # Debug logging
            if not extracted_clauses or len(extracted_clauses) == 0:
                print(f"    ℹ️  AI returned 0 findings for this document")
                print(f"    📄 Text snippet sent to AI: {text_content[:200]}...")
                return []
            else:
                print(f"    ✅ AI found {len(extracted_clauses)} concerning clauses")
            
            # Convert to Clause objects
            clauses = []
            for idx, clause_data in enumerate(extracted_clauses):
                # Generate unique ID
                clause_id = f"clause_ai_{idx}_{hash(clause_data.get('text', '')[:50]) % 10000}"
                
                clause = Clause(
                    id=clause_id,
                    text=clause_data.get('text', ''),
                    section_title=clause_data.get('section', 'General'),
                    paragraph_index=idx,
                    document_url=url,
                    document_type=doc_type,
                    last_updated=last_updated,
                    context_before="",
                    context_after="",
                    ai_category=clause_data.get('category'),
                    ai_severity=clause_data.get('severity'),
                    ai_reason=clause_data.get('reason')
                )
                clauses.append(clause)
            
            return clauses
        
        except json.JSONDecodeError as e:
            print(f"    ❌ Failed to parse AI response as JSON: {e}")
            if content is not None:
                print(f"    📄 AI Response was: {content[:500]}")
            return []
        except Exception as e:
            print(f"    ❌ AI extraction failed: {e}")
            return []
    
    def _extract_title(self, html: str) -> str:
        """Extract document title."""
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, 'lxml')
            
            title_tag = soup.find('title')
            if title_tag:
                return title_tag.get_text(strip=True)
            
            h1 = soup.find('h1')
            if h1:
                return h1.get_text(strip=True)
        except:
            pass
        
        return "Legal Document"
    
    def _extract_last_updated(self, html: str) -> Optional[str]:
        """Extract last updated date."""
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, 'lxml')
            text = soup.get_text()
            
            patterns = [
                r'(?:last updated|last modified|updated|effective date|last revised)[\s:]*([A-Za-z]+ \d{1,2},? \d{4})',
                r'(?:last updated|last modified|updated|effective date|last revised)[\s:]*(\d{1,2}/\d{1,2}/\d{4})',
                r'(?:last updated|last modified|updated|effective date|last revised)[\s:]*(\d{4}-\d{2}-\d{2})',
            ]
            
            for pattern in patterns:
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    return match.group(1)
        except:
            pass
        
        return None
    
    def close(self):
        """Close HTTP client."""
        self.http_client.close()
