"""Configuration management for PolicyBoom."""
import json
import os
from pathlib import Path
from typing import Optional


class Config:
    """Manages PolicyBoom configuration including API keys."""
    
    def __init__(self):
        self.config_dir = Path.home() / ".policyboom"
        self.config_file = self.config_dir / "config.json"
    
    def get_api_key(self) -> Optional[str]:
        """
        Get Together AI API key from config file or environment variable.
        
        Priority:
        1. Config file (~/.policyboom/config.json)
        2. Environment variable (TOGETHER_API_KEY)
        3. None (if not found)
        
        Returns:
            API key string or None if not configured
        """
        # Try config file first
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    api_key = config.get('together_api_key')
                    if api_key:
                        return api_key
            except (json.JSONDecodeError, IOError):
                pass  # Fall through to env var
        
        # Fall back to environment variable
        return os.getenv("TOGETHER_API_KEY")
    
    def save_api_key(self, api_key: str) -> None:
        """
        Save Together AI API key to config file.
        
        Args:
            api_key: The API key to save
        """
        # Create config directory if it doesn't exist
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # Load existing config or create new one
        config = {}
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
            except (json.JSONDecodeError, IOError):
                config = {}
        
        # Update API key
        config['together_api_key'] = api_key
        
        # Save config
        with open(self.config_file, 'w') as f:
            json.dump(config, f, indent=2)
        
        # Set secure permissions (user read/write only)
        os.chmod(self.config_file, 0o600)
    
    def has_api_key(self) -> bool:
        """Check if an API key is configured."""
        return self.get_api_key() is not None
    
    def clear_api_key(self) -> None:
        """Remove API key from config file."""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                
                if 'together_api_key' in config:
                    del config['together_api_key']
                    
                    with open(self.config_file, 'w') as f:
                        json.dump(config, f, indent=2)
            except (json.JSONDecodeError, IOError):
                pass


# Global config instance
_config = None

def get_config() -> Config:
    """Get the global config instance."""
    global _config
    if _config is None:
        _config = Config()
    return _config
