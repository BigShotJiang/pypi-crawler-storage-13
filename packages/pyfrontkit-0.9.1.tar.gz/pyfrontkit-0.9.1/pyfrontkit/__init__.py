# ----------------------------------------------------------------------
# Package Configuration
# ----------------------------------------------------------------------
__version__ = "0.9.0"
__author__ = "Eduardo Antonio Ferrera Rodriguez"
__license__ = "GPLv3"


# ----------------------------------------------------------------------
# Expose CSS submodule (new)
# ----------------------------------------------------------------------
# Esto permite:  from pyfrontkit import css
from . import css


# ----------------------------------------------------------------------
# Optionally expose key CSS classes for direct import
# (Esto permite hacer: from pyfrontkit import CreateColor)
# ----------------------------------------------------------------------
try:
    from .css.create_color import CreateColor
    from .css.rules_homologous import HomologousRules
    from .css.palettes_homologous import palette_homologous
except ImportError:
    # El paquete css puede no existir aún en instalaciones viejas
    pass


# ----------------------------------------------------------------------
# Export main classes and functions (original)
# ----------------------------------------------------------------------

# Core modules
from .html_doc import HtmlDoc
from .css import CSSRegistry
from .block import Block

# Tags
from .tags import (
    Div, Section, Article, Header, Footer, Nav, Main, Aside, Button, Form, Ul, Li, A,
    div, section, article, header, footer, nav, main, aside, button, form, ul, li, a
)

# Void elements
from .void_element import (
    VoidElement, Img, Input, Hr, Meta, Link, Source, Embed, Param, Track, Wbr, Area, Base, Col,
    img, input, hr, meta, link, source, embed, param, track, wbr, area, base, col
)

# Special containers
from .special import Video, Audio, Picture, ObjectElement
from .special import video, audio, picture, object


# ----------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------
__all__ = [
    # CSS module
    "css",
    "CreateColor",
    "HomologousRules",
    "palette_homologous",

    # Core
    "HtmlDoc",
    "CSSRegistry",
    "Block",

    # Tags
    "Div", "Section", "Article", "Header", "Footer", "Nav", "Main", "Aside",
    "Button", "Form", "Ul", "Li", "A",
    "div", "section", "article", "header", "footer", "nav", "main", "aside",
    "button", "form", "ul", "li", "a",

    # Void
    "VoidElement", "Img", "Input", "Hr", "Meta", "Link", "Source", "Embed",
    "Param", "Track", "Wbr", "Area", "Base", "Col",
    "img", "input", "hr", "meta", "link", "source", "embed", "param",
    "track", "wbr", "area", "base", "col",

    # Special
    "Video", "Audio", "Picture", "ObjectElement",
    "video", "audio", "picture", "object",
]
