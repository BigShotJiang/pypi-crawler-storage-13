"""Setup script for MetaEnv."""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="metaenv",
    version="0.1.0",
    author="MetaEnv Contributors",
    description="Automated Python environment management tool that scans imports, installs dependencies, and generates requirements.txt",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/AnantAILabs/metaenv",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "typer>=0.9.0",
        "rich>=13.0.0",
    ],
    entry_points={
        "console_scripts": [
            "metaenv=metaenv.cli:main",
        ],
    },
)
