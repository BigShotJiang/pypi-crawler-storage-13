"""Example Python script with various imports for testing MetaEnv.

This script imports a bunch of different packages to demonstrate how
MetaEnv automatically detects and installs dependencies.
"""

# Standard library imports
import os
import sys
import json
from pathlib import Path
from datetime import datetime

# Third-party imports - MetaEnv will detect these
import requests  # requests
import numpy as np  # numpy
from sklearn.linear_model import LinearRegression  # scikit-learn
import cv2  # opencv-python
from bs4 import BeautifulSoup  # beautifulsoup4
import yaml  # PyYAML
from dotenv import load_dotenv  # python-dotenv
import pandas as pd  # pandas


def main():
    """Main function demonstrating various imports."""
    print("=" * 60)
    print("MetaEnv Example Project")
    print("=" * 60)

    # Show some stdlib usage (shouldn't trigger installs)
    current_time = datetime.now()
    print(f"\n[Stdlib] Current time: {current_time}")
    print(f"[Stdlib] Current directory: {Path.cwd()}")

    # Third-party usage
    print(f"\n[Third-party] NumPy version: {np.__version__}")
    print(f"[Third-party] Pandas version: {pd.__version__}")
    print(f"[Third-party] Requests version: {requests.__version__}")
    print(f"[Third-party] OpenCV version: {cv2.__version__}")

    # NumPy demo
    arr = np.array([1, 2, 3, 4, 5])
    print(f"\n[NumPy] Array: {arr}")
    print(f"[NumPy] Mean: {arr.mean()}")

    # Pandas demo
    df = pd.DataFrame({
        'name': ['Alice', 'Bob', 'Charlie'],
        'age': [25, 30, 35],
        'city': ['NYC', 'LA', 'Chicago']
    })
    print(f"\n[Pandas] DataFrame:\n{df}")

    # Simple scikit-learn demo
    model = LinearRegression()
    X = np.array([[1], [2], [3], [4], [5]])
    y = np.array([2, 4, 6, 8, 10])
    model.fit(X, y)
    prediction = model.predict([[6]])
    print(f"\n[Sklearn] Linear regression prediction for x=6: {prediction[0]:.1f}")

    # YAML demo
    config = {
        'app': 'MetaEnv Example',
        'version': '1.0',
        'features': ['scanning', 'installing', 'syncing']
    }
    yaml_str = yaml.dump(config)
    print(f"\n[YAML] Config:\n{yaml_str}")

    print("\n" + "=" * 60)
    print("All imports working correctly!")
    print("MetaEnv successfully managed all dependencies.")
    print("=" * 60)


if __name__ == "__main__":
    main()
