# MetaEnv Examples

This directory contains example projects to demonstrate MetaEnv functionality.

## Example 1: Basic Project

[example_project.py](example_project.py) - A simple script with various third-party imports.

### Try it:

```bash
# Create a new directory for testing
mkdir ~/metaenv-test
cp examples/example_project.py ~/metaenv-test/

cd ~/metaenv-test

# Initialize MetaEnv (this will install all dependencies)
metaenv init .

# Run the example
metaenv run example_project.py
```

This example demonstrates:
- Standard library imports (os, sys, json, pathlib, datetime)
- Common third-party packages (numpy, pandas, requests)
- Packages requiring name resolution (cv2→opencv-python, sklearn→scikit-learn, yaml→PyYAML)

## Example 2: Multi-file Project

Create a project with multiple files:

```bash
mkdir ~/multi-file-test
cd ~/multi-file-test

# Create main.py
cat > main.py << 'EOF'
from utils import process_data
from api import fetch_data

def main():
    data = fetch_data()
    result = process_data(data)
    print(result)

if __name__ == "__main__":
    main()
EOF

# Create utils.py
cat > utils.py << 'EOF'
import pandas as pd
import numpy as np

def process_data(data):
    df = pd.DataFrame(data)
    return df.describe()
EOF

# Create api.py
cat > api.py << 'EOF'
import requests

def fetch_data():
    return [
        {'name': 'Alice', 'score': 95},
        {'name': 'Bob', 'score': 87},
    ]
EOF

# Initialize MetaEnv
metaenv init .

# View per-file dependencies
metaenv deps

# Run the main script
metaenv run main.py
```

MetaEnv will:
- Detect that `utils.py` needs pandas and numpy
- Detect that `api.py` needs requests
- Detect that `main.py` only uses local imports
- Create a dependency map showing which file needs what
- Install all required packages

## Example 3: Sync Workflow

Demonstrate the sync workflow:

```bash
cd ~/multi-file-test

# Add a new import to utils.py
cat >> utils.py << 'EOF'

from sklearn.preprocessing import StandardScaler

def scale_data(data):
    scaler = StandardScaler()
    return scaler.fit_transform(data)
EOF

# Sync dependencies (will install scikit-learn)
metaenv sync

# Check the updated dependency map
metaenv deps --file utils.py
```

## Example 4: Freeze & Rebuild

Lock dependencies and rebuild environment:

```bash
cd ~/multi-file-test

# Generate locked requirements
metaenv freeze --output requirements-lock.txt

# Simulate environment corruption
rm -rf .venv

# Rebuild from locked requirements
metaenv rebuild --requirements requirements-lock.txt

# Verify everything works
metaenv run main.py
```

## Tips for Examples

1. **Clean Testing**: Always test in a fresh directory to see MetaEnv in action
2. **Dry Run First**: Use `--dry-run` to preview changes before applying
3. **Check Deps Map**: Use `metaenv deps` to see per-file dependencies
4. **Watch Sync**: Add imports, run `metaenv sync`, see automatic installation
