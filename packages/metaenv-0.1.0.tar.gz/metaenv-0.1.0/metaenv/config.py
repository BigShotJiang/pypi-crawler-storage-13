"""Configuration management.

Manages the .metaenv/ folder and config files.
"""

import json
import logging
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)


@dataclass
class MetaEnvConfig:
    """MetaEnv configuration."""
    python_path: str = ""
    pip_path: str = ""
    venv_path: str = ".venv"
    exclude_patterns: list = None
    auto_install: bool = True
    index_url: str = ""  # Custom PyPI index if needed

    def __post_init__(self):
        # Set default exclude patterns if not provided
        if self.exclude_patterns is None:
            self.exclude_patterns = ['.venv', 'venv', '__pycache__', '.git', 'node_modules', 'build', 'dist', '*.egg-info']


class ConfigManager:
    """Manages MetaEnv configuration."""

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.config_dir = project_root / '.metaenv'
        self.config_file = self.config_dir / 'config.json'
        self.deps_file = self.config_dir / 'deps.json'

    def ensure_config_dir(self):
        """Ensure .metaenv directory exists."""
        self.config_dir.mkdir(exist_ok=True)

    def load(self) -> MetaEnvConfig:
        """Load configuration from file."""
        if not self.config_file.exists():
            return MetaEnvConfig()

        try:
            with open(self.config_file, 'r') as f:
                data = json.load(f)
            return MetaEnvConfig(**data)
        except (json.JSONDecodeError, TypeError) as e:
            # Fall back to defaults if config is corrupted
            logger.warning(f"Failed to load config, using defaults: {e}")
            return MetaEnvConfig()

    def save(self, config: MetaEnvConfig):
        """Save configuration to file."""
        self.ensure_config_dir()

        with open(self.config_file, 'w') as f:
            json.dump(asdict(config), f, indent=2)

    def load_deps_map(self) -> Dict[str, list]:
        """Load per-file dependency map."""
        if not self.deps_file.exists():
            return {}

        try:
            with open(self.deps_file, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError:
            return {}

    def save_deps_map(self, deps_map: Dict[str, list]):
        """Save per-file dependency map."""
        self.ensure_config_dir()

        with open(self.deps_file, 'w') as f:
            json.dump(deps_map, f, indent=2)

    def get_gitignore_path(self) -> Path:
        """Get path to .gitignore in project root."""
        return self.project_root / '.gitignore'

    def update_gitignore(self):
        """Add .metaenv to .gitignore if not present."""
        gitignore = self.get_gitignore_path()

        # Read existing content or start fresh
        if gitignore.exists():
            content = gitignore.read_text()
            if '.metaenv' in content:
                return  # Already there
        else:
            content = ""

        # Append MetaEnv entries
        with open(gitignore, 'a') as f:
            if content and not content.endswith('\n'):
                f.write('\n')
            f.write('\n# MetaEnv\n.metaenv/\n.venv/\n')

        logger.info("[OK] Updated .gitignore")
