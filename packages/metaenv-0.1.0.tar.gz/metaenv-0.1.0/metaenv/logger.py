"""Logging configuration for MetaEnv.

Provides centralized logging with both console and file output.
"""

import logging
import sys
from pathlib import Path


def setup_logger(name: str = "metaenv", level: int = logging.INFO) -> logging.Logger:
    """
    Set up and return a configured logger.

    Args:
        name: Logger name
        level: Logging level (default: INFO)

    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)

    # Avoid adding handlers multiple times
    if logger.handlers:
        return logger

    logger.setLevel(level)

    # Console handler with custom formatting
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)

    # Simple format for console output
    console_format = logging.Formatter('%(message)s')
    console_handler.setFormatter(console_format)

    logger.addHandler(console_handler)

    return logger


def get_logger(name: str = "metaenv") -> logging.Logger:
    """Get or create a logger instance."""
    return logging.getLogger(name)
