"""AST-based Python import scanner.

Parses Python files to extract import statements and classify them
into stdlib, local, and third-party categories.
"""

import ast
import logging
import sys
from pathlib import Path
from typing import Set, Dict, List
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class ImportInfo:
    """Information about a discovered import."""
    module: str
    top_level: str  # Top-level package name
    file_path: str
    line_number: int


class ImportScanner:
    """Scans Python files for import statements using AST."""

    def __init__(self):
        self.stdlib_modules = self._get_stdlib_modules()

    def _get_stdlib_modules(self) -> Set[str]:
        """Get set of Python stdlib module names."""
        # Hardcoded list of stdlib modules for Python 3.8+
        # Yeah, there's probably a better way to do this but this works reliably
        # TODO: Could use sys.stdlib_module_names in Python 3.10+
        stdlib = {
            'abc', 'aifc', 'argparse', 'array', 'ast', 'asynchat', 'asyncio', 'asyncore',
            'atexit', 'audioop', 'base64', 'bdb', 'binascii', 'binhex', 'bisect', 'builtins',
            'bz2', 'calendar', 'cgi', 'cgitb', 'chunk', 'cmath', 'cmd', 'code', 'codecs',
            'codeop', 'collections', 'colorsys', 'compileall', 'concurrent', 'configparser',
            'contextlib', 'contextvars', 'copy', 'copyreg', 'cProfile', 'crypt', 'csv',
            'ctypes', 'curses', 'dataclasses', 'datetime', 'dbm', 'decimal', 'difflib',
            'dis', 'distutils', 'doctest', 'email', 'encodings', 'enum', 'errno', 'faulthandler',
            'fcntl', 'filecmp', 'fileinput', 'fnmatch', 'formatter', 'fractions', 'ftplib',
            'functools', 'gc', 'getopt', 'getpass', 'gettext', 'glob', 'graphlib', 'grp',
            'gzip', 'hashlib', 'heapq', 'hmac', 'html', 'http', 'idlelib', 'imaplib',
            'imghdr', 'imp', 'importlib', 'inspect', 'io', 'ipaddress', 'itertools', 'json',
            'keyword', 'lib2to3', 'linecache', 'locale', 'logging', 'lzma', 'mailbox',
            'mailcap', 'marshal', 'math', 'mimetypes', 'mmap', 'modulefinder', 'msilib',
            'msvcrt', 'multiprocessing', 'netrc', 'nis', 'nntplib', 'ntpath', 'numbers',
            'operator', 'optparse', 'os', 'ossaudiodev', 'parser', 'pathlib', 'pdb', 'pickle',
            'pickletools', 'pipes', 'pkgutil', 'platform', 'plistlib', 'poplib', 'posix',
            'posixpath', 'pprint', 'profile', 'pstats', 'pty', 'pwd', 'py_compile', 'pyclbr',
            'pydoc', 'queue', 'quopri', 'random', 're', 'readline', 'reprlib', 'resource',
            'rlcompleter', 'runpy', 'sched', 'secrets', 'select', 'selectors', 'shelve',
            'shlex', 'shutil', 'signal', 'site', 'smtpd', 'smtplib', 'sndhdr', 'socket',
            'socketserver', 'spwd', 'sqlite3', 'ssl', 'stat', 'statistics', 'string',
            'stringprep', 'struct', 'subprocess', 'sunau', 'symbol', 'symtable', 'sys',
            'sysconfig', 'syslog', 'tabnanny', 'tarfile', 'telnetlib', 'tempfile', 'termios',
            'test', 'textwrap', 'threading', 'time', 'timeit', 'tkinter', 'token', 'tokenize',
            'trace', 'traceback', 'tracemalloc', 'tty', 'turtle', 'turtledemo', 'types',
            'typing', 'unicodedata', 'unittest', 'urllib', 'uu', 'uuid', 'venv', 'warnings',
            'wave', 'weakref', 'webbrowser', 'winreg', 'winsound', 'wsgiref', 'xdrlib',
            'xml', 'xmlrpc', 'zipapp', 'zipfile', 'zipimport', 'zlib', '_thread'
        }
        return stdlib

    def scan_file(self, file_path: Path) -> List[ImportInfo]:
        """Scan a single Python file for imports."""
        imports = []

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Parse the Python code into an AST
            tree = ast.parse(content, filename=str(file_path))

            for node in ast.walk(tree):
                # Handle "import foo" statements
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        top_level = alias.name.split('.')[0]
                        imports.append(ImportInfo(
                            module=alias.name,
                            top_level=top_level,
                            file_path=str(file_path),
                            line_number=node.lineno
                        ))

                # Handle "from foo import bar" statements
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        top_level = node.module.split('.')[0]
                        imports.append(ImportInfo(
                            module=node.module,
                            top_level=top_level,
                            file_path=str(file_path),
                            line_number=node.lineno
                        ))

        except (SyntaxError, UnicodeDecodeError) as e:
            logger.warning(f"Could not parse {file_path}: {e}")

        return imports

    def scan_directory(self, directory: Path, exclude_patterns: List[str] = None) -> Dict[str, List[ImportInfo]]:
        """Scan all Python files in a directory."""
        if exclude_patterns is None:
            exclude_patterns = ['.venv', 'venv', '__pycache__', '.git', 'node_modules', 'build', 'dist', '*.egg-info']

        file_imports = {}

        # Recursively find all .py files
        for py_file in directory.rglob('*.py'):
            # Skip files in excluded directories
            if any(pattern in str(py_file) for pattern in exclude_patterns):
                continue

            imports = self.scan_file(py_file)
            if imports:
                file_imports[str(py_file.relative_to(directory))] = imports

        return file_imports

    def classify_imports(self, imports: List[ImportInfo], project_root: Path) -> Dict[str, Set[str]]:
        """Classify imports into stdlib, local, and third-party."""
        classified = {
            'stdlib': set(),
            'local': set(),
            'third_party': set()
        }

        for imp in imports:
            top_level = imp.top_level

            # Check if it's stdlib
            if top_level in self.stdlib_modules:
                classified['stdlib'].add(top_level)
            # Check if it's local (exists in project)
            elif self._is_local_module(top_level, project_root):
                classified['local'].add(top_level)
            else:
                classified['third_party'].add(top_level)

        return classified

    def _is_local_module(self, module_name: str, project_root: Path) -> bool:
        """Check if a module is local to the project."""
        # Simple check: does a folder or .py file with this name exist?
        module_path = project_root / module_name
        module_file = project_root / f"{module_name}.py"

        return module_path.is_dir() or module_file.is_file()
