"""MetaEnv - Automated environment and dependency management for Python projects."""

__version__ = "0.1.0"
