"""Virtual environment management.

Handles creating and managing .venv directories for projects.
"""

import logging
import subprocess
import sys
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


class VenvManager:
    """Manages Python virtual environments."""

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.venv_path = project_root / '.venv'  # Always use .venv as the folder name

    def exists(self) -> bool:
        """Check if virtual environment exists."""
        return self.venv_path.exists()

    def create(self, python_path: Optional[str] = None) -> bool:
        """
        Create a virtual environment.

        Args:
            python_path: Path to Python interpreter to use. If None, uses current Python.

        Returns:
            True if successful, False otherwise.
        """
        if self.exists():
            logger.info(f"Virtual environment already exists at {self.venv_path}")
            return True

        python = python_path or sys.executable

        try:
            logger.info(f"Creating virtual environment at {self.venv_path}...")
            result = subprocess.run(
                [python, '-m', 'venv', str(self.venv_path)],
                check=True,
                capture_output=True,
                text=True
            )
            logger.info("[OK] Virtual environment created successfully")
            return True
        except subprocess.CalledProcessError as e:
            logger.error(f"[ERROR] Failed to create virtual environment: {e.stderr}")
            return False

    def get_python_path(self) -> Path:
        """Get path to Python interpreter in venv."""
        # Windows uses Scripts/, Unix uses bin/
        if sys.platform == 'win32':
            return self.venv_path / 'Scripts' / 'python.exe'
        else:
            return self.venv_path / 'bin' / 'python'

    def get_pip_path(self) -> Path:
        """Get path to pip in venv."""
        # Same deal - Windows vs Unix paths
        if sys.platform == 'win32':
            return self.venv_path / 'Scripts' / 'pip.exe'
        else:
            return self.venv_path / 'bin' / 'pip'

    def get_info(self) -> Tuple[str, str]:
        """
        Get Python and pip versions.

        Returns:
            Tuple of (python_version, pip_version)
        """
        python = str(self.get_python_path())

        try:
            # Get Python version
            py_result = subprocess.run([python, '--version'],
                                     capture_output=True, text=True, check=True)
            python_version = py_result.stdout.strip() or py_result.stderr.strip()

            # Get pip version
            pip_result = subprocess.run([python, '-m', 'pip', '--version'],
                                      capture_output=True, text=True, check=True)
            pip_version = pip_result.stdout.strip()

            return python_version, pip_version
        except subprocess.CalledProcessError:
            return "Unknown", "Unknown"

    def upgrade_pip(self) -> bool:
        """Upgrade pip to latest version."""
        python = str(self.get_python_path())

        try:
            logger.info("Upgrading pip...")
            subprocess.run(
                [python, '-m', 'pip', 'install', '--upgrade', 'pip'],
                check=True,
                capture_output=True,
                text=True
            )
            logger.info("[OK] pip upgraded successfully")
            return True
        except subprocess.CalledProcessError as e:
            logger.error(f"[ERROR] Failed to upgrade pip: {e.stderr}")
            return False
