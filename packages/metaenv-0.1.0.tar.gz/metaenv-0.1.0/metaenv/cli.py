"""CLI interface for MetaEnv.

Main command-line interface implementation. Handles all user-facing commands
for environment management and dependency installation.
"""

import logging
import sys
from pathlib import Path
from typing import Optional
import typer
from rich.console import Console
from rich.table import Table
from rich import print as rprint

from metaenv.scanner import ImportScanner
from metaenv.resolver import PackageResolver
from metaenv.venv_mgr import VenvManager
from metaenv.installer import PackageInstaller
from metaenv.config import ConfigManager, MetaEnvConfig
from metaenv.logger import setup_logger

# Initialize CLI app
app = typer.Typer(help="MetaEnv - Automated Python environment management tool")
console = Console()

# Setup logging - will be initialized on first command
_logger_initialized = False

def ensure_logger():
    """Initialize logger if not already done."""
    global _logger_initialized
    if not _logger_initialized:
        setup_logger()
        _logger_initialized = True


@app.command()
def create(
    path: Path = typer.Argument(".", help="Project directory"),
    python: Optional[str] = typer.Option(None, "--python", "-p", help="Python version to use (e.g., 3.11)"),
    freeze: bool = typer.Option(False, help="Use exact versions (pip freeze)"),
):
    """
    Create virtual environment and install all dependencies automatically.

    Detects Python version, creates venv, scans imports, installs all required libraries.
    """
    ensure_logger()
    path = path.resolve()

    if not path.is_dir():
        console.print(f"[red][ERROR] Error: {path} is not a directory[/red]")
        raise typer.Exit(1)

    console.print(f"\n[bold cyan]MetaEnv - Creating Environment[/bold cyan]")
    console.print(f"Project: {path}\n")

    # Load or create config
    config_mgr = ConfigManager(path)
    config = config_mgr.load()

    # Step 1: Create/verify virtual environment
    console.print("[bold]1. Virtual Environment[/bold]")
    venv_mgr = VenvManager(path)

    if not venv_mgr.exists():
        if not venv_mgr.create(python):
            raise typer.Exit(1)
        venv_mgr.upgrade_pip()
    else:
        console.print(f"  [OK] Virtual environment exists at {venv_mgr.venv_path}")

    # Get venv info
    py_version, pip_version = venv_mgr.get_info()
    console.print(f"  Python: {py_version}")
    console.print(f"  Pip: {pip_version}")

    # Update config
    config.python_path = str(venv_mgr.get_python_path())
    config.pip_path = str(venv_mgr.get_pip_path())
    config_mgr.save(config)

    # Step 2: Scan for imports
    console.print("\n[bold]2. Scanning Imports[/bold]")
    scanner = ImportScanner()
    file_imports = scanner.scan_directory(path, config.exclude_patterns)

    # Count total imports across all files
    total_imports = sum(len(imports) for imports in file_imports.values())
    console.print(f"  Scanned {len(file_imports)} file(s)")
    console.print(f"  Found {total_imports} import statement(s)")

    # Step 3: Classify imports
    console.print("\n[bold]3. Classifying Imports[/bold]")
    all_imports = [imp for imports in file_imports.values() for imp in imports]
    classified = scanner.classify_imports(all_imports, path)

    console.print(f"  Standard library: {len(classified['stdlib'])} package(s)")
    console.print(f"  Local modules: {len(classified['local'])} package(s)")
    console.print(f"  Third-party: {len(classified['third_party'])} package(s)")

    # Step 4: Resolve to PyPI names
    console.print("\n[bold]4. Resolving Package Names[/bold]")
    resolver = PackageResolver()
    packages_to_install = set()

    for import_name in sorted(classified['third_party']):
        package_name = resolver.resolve(import_name)
        packages_to_install.add(package_name)
        if import_name != package_name:
            console.print(f"  {import_name} -> {package_name}")

    console.print(f"  Resolved to {len(packages_to_install)} PyPI package(s)")

    # Step 5: Check what's already installed
    console.print("\n[bold]5. Checking Installed Packages[/bold]")
    installer = PackageInstaller(venv_mgr.get_python_path())
    installed = installer.get_installed_packages()

    # Normalize package names (PyPI uses dashes, Python uses underscores sometimes)
    packages_to_install_normalized = {pkg.lower().replace('_', '-') for pkg in packages_to_install}
    installed_normalized = {pkg.lower().replace('_', '-') for pkg in installed}

    missing_packages = []
    for pkg in sorted(packages_to_install):
        pkg_normalized = pkg.lower().replace('_', '-')
        if pkg_normalized in installed_normalized:
            console.print(f"  [OK] {pkg} (already installed)")
        else:
            console.print(f"  [ERROR] {pkg} (missing)")
            missing_packages.append(pkg)

    # Step 6: Install missing packages
    if missing_packages:
        console.print(f"\n[bold]6. Installing {len(missing_packages)} Package(s)[/bold]")
        results = installer.install_packages(missing_packages)

        success_count = sum(1 for v in results.values() if v)
        console.print(f"\n  [OK] Installed {success_count}/{len(missing_packages)} package(s)")
    else:
        console.print("\n[bold]6. Installation[/bold]")
        console.print("  [OK] All packages already installed")

    # Step 7: Generate requirements.txt
    console.print("\n[bold]7. Generating requirements.txt[/bold]")
    req_path = path / 'requirements.txt'
    installer.generate_requirements(req_path, freeze=freeze)

    # Step 8: Save per-file dependency map
    # This helps with debugging and understanding which files need what
    console.print("\n[bold]8. Saving Dependency Map[/bold]")
    deps_map = {}
    for file_path, imports in file_imports.items():
        file_deps = set()
        for imp in imports:
            pkg_name = resolver.resolve(imp.top_level)
            file_deps.add(pkg_name)
        deps_map[file_path] = sorted(file_deps)

    config_mgr.save_deps_map(deps_map)
    console.print(f"  [OK] Saved to .metaenv/deps.json")

    # Make sure .gitignore is updated
    config_mgr.update_gitignore()

    console.print("\n[bold green][OK] Environment created successfully![/bold green]\n")
    console.print("[dim]Next: Run your code directly or use 'metaenv generate' to create requirements.txt[/dim]\n")


@app.command()
def sync(
    path: Path = typer.Argument(".", help="Project directory"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be done without doing it"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompts"),
    uninstall: bool = typer.Option(True, "--uninstall/--no-uninstall", help="Remove unused packages"),
):
    """
    Sync dependencies with current imports.

    Rescan imports, install new packages, optionally remove unused ones.
    """
    path = path.resolve()

    console.print(f"\n[bold cyan]MetaEnv Sync[/bold cyan]")
    console.print(f"Project: {path}\n")

    # Load config
    config_mgr = ConfigManager(path)
    config = config_mgr.load()

    # Verify venv exists
    venv_mgr = VenvManager(path)
    if not venv_mgr.exists():
        console.print("[red][ERROR] Virtual environment not found. Run 'metaenv create' first.[/red]")
        raise typer.Exit(1)

    # Scan imports
    console.print("[bold]1. Scanning Imports[/bold]")
    scanner = ImportScanner()
    file_imports = scanner.scan_directory(path, config.exclude_patterns)

    all_imports = [imp for imports in file_imports.values() for imp in imports]
    classified = scanner.classify_imports(all_imports, path)

    console.print(f"  Found {len(classified['third_party'])} third-party import(s)")

    # Resolve to packages
    resolver = PackageResolver()
    needed_packages = set()
    for import_name in classified['third_party']:
        package_name = resolver.resolve(import_name)
        needed_packages.add(package_name.lower().replace('_', '-'))

    # Get installed packages
    console.print("\n[bold]2. Comparing with Installed Packages[/bold]")
    installer = PackageInstaller(venv_mgr.get_python_path())
    installed = {pkg.lower().replace('_', '-') for pkg in installer.get_installed_packages()}

    # Find differences
    to_install = needed_packages - installed
    to_remove = installed - needed_packages if uninstall else set()

    # Remove pip, setuptools, wheel from to_remove
    to_remove = {pkg for pkg in to_remove if pkg not in {'pip', 'setuptools', 'wheel'}}

    console.print(f"  To install: {len(to_install)}")
    console.print(f"  To remove: {len(to_remove)}")

    if not to_install and not to_remove:
        console.print("\n[bold green][OK] Everything is in sync![/bold green]\n")
        return

    # Show plan
    if to_install:
        console.print("\n[bold]Packages to Install:[/bold]")
        for pkg in sorted(to_install):
            console.print(f"  + {pkg}")

    if to_remove:
        console.print("\n[bold]Packages to Remove:[/bold]")
        for pkg in sorted(to_remove):
            console.print(f"  - {pkg}")

    if dry_run:
        console.print("\n[yellow]Dry run - no changes made[/yellow]\n")
        return

    # Confirm
    if not yes and (to_install or to_remove):
        confirm = typer.confirm("\nProceed with changes?")
        if not confirm:
            console.print("Aborted")
            raise typer.Exit(0)

    # Install
    if to_install:
        console.print("\n[bold]Installing...[/bold]")
        installer.install_packages(sorted(to_install))

    # Uninstall
    if to_remove:
        console.print("\n[bold]Uninstalling...[/bold]")
        installer.uninstall_packages(sorted(to_remove))

    # Update requirements.txt
    console.print("\n[bold]Updating requirements.txt[/bold]")
    req_path = path / 'requirements.txt'
    installer.generate_requirements(req_path, freeze=False)

    console.print("\n[bold green][OK] Sync complete![/bold green]\n")


@app.command()
def scan(
    path: Path = typer.Argument(".", help="Project directory"),
):
    """
    Scan project imports and list third-party dependencies.

    Does not create environment or install packages - audit only.
    """
    path = path.resolve()

    console.print(f"\n[bold cyan]MetaEnv - Scanning Project[/bold cyan]")
    console.print(f"Project: {path}\n")

    # Load config
    config_mgr = ConfigManager(path)
    config = config_mgr.load()

    # Scan imports
    console.print("[bold]Scanning Imports[/bold]")
    scanner = ImportScanner()
    file_imports = scanner.scan_directory(path, config.exclude_patterns)

    total_imports = sum(len(imports) for imports in file_imports.values())
    console.print(f"  Scanned {len(file_imports)} file(s)")
    console.print(f"  Found {total_imports} import statement(s)")

    # Classify imports
    console.print("\n[bold]Classifying Imports[/bold]")
    all_imports = [imp for imports in file_imports.values() for imp in imports]
    classified = scanner.classify_imports(all_imports, path)

    console.print(f"  Standard library: {len(classified['stdlib'])} package(s)")
    console.print(f"  Local modules: {len(classified['local'])} package(s)")
    console.print(f"  Third-party: {len(classified['third_party'])} package(s)")

    # Resolve to packages
    if classified['third_party']:
        console.print("\n[bold]Third-Party Dependencies[/bold]")
        resolver = PackageResolver()
        packages = set()

        for import_name in sorted(classified['third_party']):
            package_name = resolver.resolve(import_name)
            packages.add(package_name)
            if import_name != package_name:
                console.print(f"  {import_name} -> {package_name}")
            else:
                console.print(f"  {package_name}")

        console.print(f"\n[bold green][OK] Found {len(packages)} required package(s)[/bold green]\n")
    else:
        console.print("\n[bold yellow]No third-party dependencies found[/bold yellow]\n")


@app.command()
def install(
    path: Path = typer.Argument(".", help="Project directory"),
):
    """
    Install dependencies into existing environment.

    Assumes environment already exists. Scans and installs detected packages.
    """
    path = path.resolve()

    console.print(f"\n[bold cyan]MetaEnv - Installing Dependencies[/bold cyan]")
    console.print(f"Project: {path}\n")

    # Verify venv exists
    venv_mgr = VenvManager(path)
    if not venv_mgr.exists():
        console.print("[red][ERROR] Virtual environment not found.[/red]")
        console.print("[yellow]Run 'metaenv create' first to create the environment.[/yellow]")
        raise typer.Exit(1)

    # Load config
    config_mgr = ConfigManager(path)
    config = config_mgr.load()

    # Scan imports
    console.print("[bold]1. Scanning Imports[/bold]")
    scanner = ImportScanner()
    file_imports = scanner.scan_directory(path, config.exclude_patterns)

    all_imports = [imp for imports in file_imports.values() for imp in imports]
    classified = scanner.classify_imports(all_imports, path)

    console.print(f"  Found {len(classified['third_party'])} third-party import(s)")

    # Resolve to packages
    console.print("\n[bold]2. Resolving Package Names[/bold]")
    resolver = PackageResolver()
    packages_to_install = set()

    for import_name in sorted(classified['third_party']):
        package_name = resolver.resolve(import_name)
        packages_to_install.add(package_name)
        if import_name != package_name:
            console.print(f"  {import_name} -> {package_name}")

    console.print(f"  Resolved to {len(packages_to_install)} PyPI package(s)")

    # Check what's installed
    console.print("\n[bold]3. Checking Installed Packages[/bold]")
    installer = PackageInstaller(venv_mgr.get_python_path())
    installed = {pkg.lower().replace('_', '-') for pkg in installer.get_installed_packages()}

    packages_to_install_normalized = {pkg.lower().replace('_', '-') for pkg in packages_to_install}
    missing_packages = []

    for pkg in sorted(packages_to_install):
        pkg_normalized = pkg.lower().replace('_', '-')
        if pkg_normalized in installed:
            console.print(f"  [OK] {pkg} (already installed)")
        else:
            console.print(f"  [ERROR] {pkg} (missing)")
            missing_packages.append(pkg)

    # Install missing packages
    if missing_packages:
        console.print(f"\n[bold]4. Installing {len(missing_packages)} Package(s)[/bold]")
        results = installer.install_packages(missing_packages)
        success_count = sum(1 for v in results.values() if v)
        console.print(f"\n  [OK] Installed {success_count}/{len(missing_packages)} package(s)")
    else:
        console.print("\n[bold green][OK] All packages already installed[/bold green]")

    console.print("\n[bold green][OK] Installation complete![/bold green]\n")


@app.command()
def clean(
    path: Path = typer.Argument(".", help="Project directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
):
    """
    Remove the existing virtual environment.

    Useful for resetting the environment before a fresh rebuild.
    """
    import shutil

    path = path.resolve()
    venv_mgr = VenvManager(path)

    if not venv_mgr.exists():
        console.print("\n[yellow]No virtual environment found to clean[/yellow]\n")
        return

    console.print(f"\n[bold yellow]MetaEnv - Clean Environment[/bold yellow]")
    console.print(f"Project: {path}")
    console.print(f"Virtual environment: {venv_mgr.venv_path}\n")

    if not yes:
        confirm = typer.confirm("⚠️  This will delete the entire virtual environment. Continue?")
        if not confirm:
            console.print("\n[dim]Cancelled[/dim]\n")
            raise typer.Exit(0)

    try:
        shutil.rmtree(venv_mgr.venv_path)
        console.print("\n[bold green][OK] Virtual environment removed successfully![/bold green]\n")
    except Exception as e:
        console.print(f"\n[red][ERROR] Error removing environment: {e}[/red]\n")
        raise typer.Exit(1)


@app.command()
def run(
    script: str = typer.Argument(..., help="Python script to run"),
    args: list[str] = typer.Argument(None, help="Arguments to pass to script"),
    path: Path = typer.Option(".", help="Project directory"),
):
    """
    Run a Python script using the project's virtual environment.
    """
    import subprocess

    path = path.resolve()

    # Load config
    config_mgr = ConfigManager(path)
    config = config_mgr.load()

    # Verify venv
    venv_mgr = VenvManager(path)
    if not venv_mgr.exists():
        console.print("[red][ERROR] Virtual environment not found. Run 'metaenv create' first.[/red]")
        raise typer.Exit(1)

    python = str(venv_mgr.get_python_path())

    # Build command
    cmd = [python, script]
    if args:
        cmd.extend(args)

    console.print(f"[dim]Running: {' '.join(cmd)}[/dim]\n")

    # Run script
    try:
        result = subprocess.run(cmd, cwd=path)
        sys.exit(result.returncode)
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted[/yellow]")
        sys.exit(130)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


@app.command()
def deps(
    file: Optional[str] = typer.Option(None, "--file", help="Show dependencies for specific file"),
    path: Path = typer.Option(".", help="Project directory"),
):
    """
    Show dependency information.
    """
    path = path.resolve()

    config_mgr = ConfigManager(path)
    deps_map = config_mgr.load_deps_map()

    if not deps_map:
        console.print("[yellow]No dependency map found. Run 'metaenv create' first.[/yellow]")
        return

    if file:
        # Show deps for specific file
        if file in deps_map:
            console.print(f"\n[bold]Dependencies for {file}:[/bold]")
            for dep in sorted(deps_map[file]):
                console.print(f"  • {dep}")
            console.print()
        else:
            console.print(f"[red]File not found in dependency map: {file}[/red]")
    else:
        # Show all files and their dep counts
        table = Table(title="Dependency Map")
        table.add_column("File", style="cyan")
        table.add_column("Dependencies", justify="right", style="magenta")

        for file_path, file_deps in sorted(deps_map.items()):
            table.add_row(file_path, str(len(file_deps)))

        console.print()
        console.print(table)
        console.print()


@app.command()
def generate(
    path: Path = typer.Argument(".", help="Project directory"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file (default: requirements.txt)"),
):
    """
    Generate requirements.txt with pinned versions from installed packages.
    """
    path = path.resolve()

    venv_mgr = VenvManager(path)
    if not venv_mgr.exists():
        console.print("[red][ERROR] Virtual environment not found. Run 'metaenv create' first.[/red]")
        raise typer.Exit(1)

    installer = PackageInstaller(venv_mgr.get_python_path())

    output_path = output or path / 'requirements.txt'
    installer.generate_requirements(output_path, freeze=True)

    console.print(f"\n[bold green][OK] Requirements generated successfully![/bold green]")
    console.print(f"[dim]Written to: {output_path}[/dim]\n")


@app.command()
def rebuild(
    path: Path = typer.Argument(".", help="Project directory"),
    requirements: Optional[Path] = typer.Option(None, "--requirements", "-r", help="Requirements file to install from"),
):
    """
    Rebuild virtual environment from scratch.
    """
    import shutil

    path = path.resolve()

    console.print(f"\n[bold yellow]MetaEnv Rebuild[/bold yellow]")
    console.print(f"Project: {path}\n")

    venv_mgr = VenvManager(path)

    # Remove existing venv
    if venv_mgr.exists():
        console.print("[bold]Removing existing virtual environment...[/bold]")
        shutil.rmtree(venv_mgr.venv_path)
        console.print("  [OK] Removed")

    # Create fresh venv
    console.print("\n[bold]Creating new virtual environment...[/bold]")
    if not venv_mgr.create():
        raise typer.Exit(1)
    venv_mgr.upgrade_pip()

    # Install from requirements if specified
    if requirements:
        if requirements.exists():
            console.print(f"\n[bold]Installing from {requirements}...[/bold]")
            installer = PackageInstaller(venv_mgr.get_python_path())
            installer.install_from_requirements(requirements)
        else:
            console.print(f"[red][ERROR] Requirements file not found: {requirements}[/red]")
            raise typer.Exit(1)
    else:
        # Check for requirements.txt
        req_path = path / 'requirements.txt'
        if req_path.exists():
            console.print(f"\n[bold]Installing from {req_path}...[/bold]")
            installer = PackageInstaller(venv_mgr.get_python_path())
            installer.install_from_requirements(req_path)

    console.print("\n[bold green][OK] Rebuild complete![/bold green]\n")


def main():
    """Entry point for CLI."""
    app()


if __name__ == '__main__':
    main()
