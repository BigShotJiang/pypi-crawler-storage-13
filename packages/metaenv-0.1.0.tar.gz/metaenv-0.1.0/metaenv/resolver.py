"""Resolve import names to PyPI package names.

This is needed because import names don't always match PyPI package names.
For example, you import 'cv2' but install 'opencv-python'.
"""

from typing import Dict, Optional


class PackageResolver:
    """Resolves Python import names to PyPI package names."""

    def __init__(self):
        # Mapping of import names to actual PyPI package names
        # This list was built over time by finding common mismatches
        # TODO: Maybe load this from a JSON file for easier updates?
        self.mapping = {
            # Image processing
            'cv2': 'opencv-python',
            'PIL': 'Pillow',

            # Data science
            'sklearn': 'scikit-learn',
            'skimage': 'scikit-image',

            # Web scraping
            'bs4': 'beautifulsoup4',

            # YAML
            'yaml': 'PyYAML',

            # Google Cloud
            'google.cloud': 'google-cloud',
            'google.auth': 'google-auth',

            # Database
            'MySQLdb': 'mysqlclient',
            'psycopg2': 'psycopg2-binary',

            # Utilities
            'dateutil': 'python-dateutil',
            'dotenv': 'python-dotenv',

            # Async
            'aiohttp': 'aiohttp',
            'httpx': 'httpx',

            # Type checking
            'typing_extensions': 'typing-extensions',

            # Web frameworks
            'flask': 'Flask',
            'django': 'Django',
            'fastapi': 'fastapi',

            # Testing
            'pytest': 'pytest',

            # Common packages (usually match, but normalize)
            'requests': 'requests',
            'numpy': 'numpy',
            'pandas': 'pandas',
            'scipy': 'scipy',
            'matplotlib': 'matplotlib',
            'seaborn': 'seaborn',
            'plotly': 'plotly',
            'streamlit': 'streamlit',
            'click': 'click',
            'typer': 'typer',
            'pydantic': 'pydantic',
            'sqlalchemy': 'SQLAlchemy',
            'celery': 'celery',
            'redis': 'redis',
            'boto3': 'boto3',
            'cryptography': 'cryptography',
            'pytest': 'pytest',
            'black': 'black',
            'mypy': 'mypy',
            'flake8': 'flake8',
            'isort': 'isort',
            'jinja2': 'Jinja2',
        }

    def resolve(self, import_name: str) -> str:
        """
        Resolve an import name to a PyPI package name.

        Args:
            import_name: The import name (e.g., 'cv2', 'sklearn')

        Returns:
            The PyPI package name (e.g., 'opencv-python', 'scikit-learn')
        """
        # Check if we have an explicit mapping
        if import_name in self.mapping:
            return self.mapping[import_name]

        # Handle submodule imports (e.g., google.cloud.storage → google-cloud)
        for key, value in self.mapping.items():
            if import_name.startswith(f"{key}."):
                return value

        # Default: assume import name matches package name
        # Works for most packages (numpy, pandas, requests, etc.)
        return import_name

    def add_mapping(self, import_name: str, package_name: str):
        """Add a custom import→package mapping."""
        self.mapping[import_name] = package_name

    def get_all_mappings(self) -> Dict[str, str]:
        """Get all current mappings."""
        return self.mapping.copy()
