"""Package installation and management.

Wraps pip commands to install packages and generate requirements.txt
"""

import logging
import subprocess
from pathlib import Path
from typing import List, Set, Dict
import json

logger = logging.getLogger(__name__)


class PackageInstaller:
    """Handles package installation and requirement management."""

    def __init__(self, venv_python: Path):
        self.python = str(venv_python)  # Path to the venv's Python executable

    def get_installed_packages(self) -> Set[str]:
        """Get set of currently installed package names."""
        try:
            # Use pip list with JSON format for easy parsing
            result = subprocess.run(
                [self.python, '-m', 'pip', 'list', '--format=json'],
                capture_output=True,
                text=True,
                check=True
            )

            packages = json.loads(result.stdout)
            # Normalize to lowercase for comparison
            return {pkg['name'].lower() for pkg in packages}

        except subprocess.CalledProcessError as e:
            logger.warning(f"Failed to list installed packages: {e.stderr}")
            return set()

    def install_packages(self, packages: List[str], upgrade: bool = False) -> Dict[str, bool]:
        """
        Install packages one by one.

        Args:
            packages: List of package names to install
            upgrade: Whether to upgrade existing packages

        Returns:
            Dict mapping package names to success status
        """
        results = {}

        if not packages:
            return results

        logger.info(f"\nInstalling {len(packages)} package(s)...")

        # Install packages one at a time for better error reporting
        for package in packages:
            try:
                cmd = [self.python, '-m', 'pip', 'install']
                if upgrade:
                    cmd.append('--upgrade')
                cmd.append(package)

                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    check=True
                )

                logger.info(f"  [OK] {package}")
                results[package] = True

            except subprocess.CalledProcessError as e:
                logger.error(f"  [ERROR] {package}: {e.stderr.strip()}")
                results[package] = False

        return results

    def uninstall_packages(self, packages: List[str]) -> Dict[str, bool]:
        """
        Uninstall packages.

        Args:
            packages: List of package names to uninstall

        Returns:
            Dict mapping package names to success status
        """
        results = {}

        if not packages:
            return results

        logger.info(f"\nUninstalling {len(packages)} package(s)...")

        for package in packages:
            try:
                subprocess.run(
                    [self.python, '-m', 'pip', 'uninstall', '-y', package],
                    capture_output=True,
                    text=True,
                    check=True
                )

                logger.info(f"  [OK] {package}")
                results[package] = True

            except subprocess.CalledProcessError as e:
                logger.error(f"  [ERROR] {package}: {e.stderr.strip()}")
                results[package] = False

        return results

    def generate_requirements(self, output_path: Path, freeze: bool = False):
        """
        Generate requirements.txt file.

        Args:
            output_path: Path to write requirements.txt
            freeze: If True, use pip freeze (exact versions). Otherwise, use pip list without versions.
        """
        try:
            # pip freeze includes exact versions with ==
            if freeze:
                result = subprocess.run(
                    [self.python, '-m', 'pip', 'freeze'],
                    capture_output=True,
                    text=True,
                    check=True
                )
            else:
                result = subprocess.run(
                    [self.python, '-m', 'pip', 'list', '--format=freeze'],
                    capture_output=True,
                    text=True,
                    check=True
                )

            with open(output_path, 'w') as f:
                f.write(result.stdout)

            logger.info(f"[OK] Generated {output_path}")

        except subprocess.CalledProcessError as e:
            logger.error(f"[ERROR] Failed to generate requirements: {e.stderr}")

    def install_from_requirements(self, requirements_path: Path) -> bool:
        """Install packages from requirements.txt."""
        try:
            logger.info(f"Installing from {requirements_path}...")
            result = subprocess.run([self.python, '-m', 'pip', 'install', '-r',
                                   str(requirements_path)],
                                  check=True, capture_output=True, text=True)
            logger.info("[OK] Installed successfully")
            return True

        except subprocess.CalledProcessError as e:
            logger.error(f"[ERROR] Failed to install from requirements: {e.stderr}")
            return False
