"""Quick test script to verify MetaEnv functionality."""

import sys
import tempfile
import shutil
from pathlib import Path

# Fix Windows console encoding
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Add parent directory to path for testing
sys.path.insert(0, str(Path(__file__).parent.parent))

from metaenv.scanner import ImportScanner
from metaenv.resolver import PackageResolver
from metaenv.venv_mgr import VenvManager
from metaenv.config import ConfigManager


def test_scanner():
    """Test the import scanner."""
    print("=" * 60)
    print("TEST 1: Import Scanner")
    print("=" * 60)

    # Create a temp file with some imports to scan
    test_code = """
import os
import sys
import requests
import numpy as np
from sklearn.linear_model import LinearRegression
import cv2
from bs4 import BeautifulSoup
"""

    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write(test_code)
        test_file = Path(f.name)

    try:
        scanner = ImportScanner()
        imports = scanner.scan_file(test_file)

        print(f"\nScanned file: {test_file}")
        print(f"Found {len(imports)} imports:\n")

        for imp in imports:
            print(f"  - {imp.module:20s} (top-level: {imp.top_level})")

        # Classify
        classified = scanner.classify_imports(imports, Path.cwd())
        print(f"\nClassification:")
        print(f"  Stdlib: {classified['stdlib']}")
        print(f"  Third-party: {classified['third_party']}")

        print("\n[PASS] Scanner test passed!")

    finally:
        test_file.unlink()


def test_resolver():
    """Test the package resolver."""
    print("\n" + "=" * 60)
    print("TEST 2: Package Resolver")
    print("=" * 60)

    resolver = PackageResolver()

    test_cases = [
        ('cv2', 'opencv-python'),
        ('sklearn', 'scikit-learn'),
        ('bs4', 'beautifulsoup4'),
        ('yaml', 'PyYAML'),
        ('PIL', 'Pillow'),
        ('requests', 'requests'),  # Should pass through
        ('numpy', 'numpy'),  # Should pass through
    ]

    print("\nTesting import → package resolution:\n")

    all_passed = True
    for import_name, expected in test_cases:
        result = resolver.resolve(import_name)
        status = "[OK]" if result == expected else "[FAIL]"
        print(f"  {status} {import_name:15s} -> {result:20s} (expected: {expected})")
        if result != expected:
            all_passed = False

    if all_passed:
        print("\n[PASS] Resolver test passed!")
    else:
        print("\n[FAIL] Some resolver tests failed!")


def test_venv_manager():
    """Test virtual environment manager."""
    print("\n" + "=" * 60)
    print("TEST 3: Virtual Environment Manager")
    print("=" * 60)

    # Create a temporary directory
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        print(f"\nTest directory: {tmpdir}")

        venv_mgr = VenvManager(tmpdir)

        # Check existence
        exists = venv_mgr.exists()
        print(f"  Venv exists: {exists} (should be False)")
        assert not exists, "Venv should not exist yet"

        # Get paths (even though venv doesn't exist yet)
        python_path = venv_mgr.get_python_path()
        pip_path = venv_mgr.get_pip_path()
        print(f"  Python path: {python_path}")
        print(f"  Pip path: {pip_path}")

        print("\n[PASS] VenvManager test passed!")


def test_config_manager():
    """Test configuration manager."""
    print("\n" + "=" * 60)
    print("TEST 4: Configuration Manager")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        print(f"\nTest directory: {tmpdir}")

        config_mgr = ConfigManager(tmpdir)

        # Load default config
        config = config_mgr.load()
        print(f"  Default config loaded")
        print(f"    venv_path: {config.venv_path}")
        print(f"    auto_install: {config.auto_install}")

        # Save config
        config.python_path = "/usr/bin/python3"
        config_mgr.save(config)
        print(f"  Config saved to {config_mgr.config_file}")

        # Load again
        config2 = config_mgr.load()
        print(f"  Config reloaded")
        print(f"    python_path: {config2.python_path}")

        assert config2.python_path == "/usr/bin/python3", "Config should persist"

        # Test deps map
        deps_map = {
            'main.py': ['requests', 'numpy'],
            'utils.py': ['pandas', 'scikit-learn']
        }
        config_mgr.save_deps_map(deps_map)
        print(f"  Deps map saved to {config_mgr.deps_file}")

        loaded_deps = config_mgr.load_deps_map()
        print(f"  Deps map reloaded: {loaded_deps}")

        assert loaded_deps == deps_map, "Deps map should persist"

        print("\n[PASS] ConfigManager test passed!")


def test_directory_scan():
    """Test scanning a directory with multiple files."""
    print("\n" + "=" * 60)
    print("TEST 5: Directory Scanning")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        # Create a few test files with different imports
        (tmpdir / 'main.py').write_text("""
import requests
from utils import helper
""")

        (tmpdir / 'utils.py').write_text("""
import numpy as np
import pandas as pd
""")

        (tmpdir / 'data.py').write_text("""
from sklearn.linear_model import LinearRegression
import cv2
""")

        print(f"\nTest directory: {tmpdir}")
        print("Created 3 test files")

        scanner = ImportScanner()
        file_imports = scanner.scan_directory(tmpdir)

        print(f"\nScanned {len(file_imports)} file(s):\n")

        for file_path, imports in sorted(file_imports.items()):
            print(f"  {file_path}:")
            for imp in imports:
                print(f"    - {imp.module}")

        # Get all unique imports
        all_imports = [imp for imports in file_imports.values() for imp in imports]
        classified = scanner.classify_imports(all_imports, tmpdir)

        print(f"\nClassified imports:")
        print(f"  Stdlib: {classified['stdlib']}")
        print(f"  Local: {classified['local']}")
        print(f"  Third-party: {classified['third_party']}")

        # Resolve third-party
        resolver = PackageResolver()
        packages = set()
        for import_name in classified['third_party']:
            pkg = resolver.resolve(import_name)
            packages.add(pkg)

        print(f"\nResolved to packages:")
        for pkg in sorted(packages):
            print(f"  - {pkg}")

        print("\n[PASS] Directory scan test passed!")


def main():
    """Run all tests."""
    print("\n" + "=" * 60)
    print("MetaEnv Unit Tests")
    print("=" * 60)

    try:
        test_scanner()
        test_resolver()
        test_venv_manager()
        test_config_manager()
        test_directory_scan()

        print("\n" + "=" * 60)
        print("ALL TESTS PASSED!")
        print("=" * 60)
        print("\nMetaEnv is ready to use!")
        print("\nNext steps:")
        print("  1. Install MetaEnv: pip install -e .")
        print("  2. Try it: metaenv create")
        print("  3. Read the docs: cat README.md")
        print("=" * 60 + "\n")

    except Exception as e:
        print(f"\n[FAIL] Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
