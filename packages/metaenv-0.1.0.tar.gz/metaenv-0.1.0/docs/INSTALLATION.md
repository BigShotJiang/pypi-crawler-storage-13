# MetaEnv Installation & Setup

## Prerequisites

- Python 3.8 or higher
- pip

## Installation

### Option 1: Install from source (current)

```bash
cd metaenv
pip install -e .
```

This installs MetaEnv in "editable" mode, so any changes you make to the source code will be immediately available.

### Option 2: Install from PyPI (future)

Once published to PyPI:

```bash
pip install metaenv
```

## Verify Installation

```bash
metaenv --help
```

You should see:

```
Usage: metaenv [OPTIONS] COMMAND [ARGS]...

MetaEnv - Automated Python environment builder

Commands:
  create    Create virtual environment and install all dependencies automatically.
  scan      Scan project imports and list dependencies.
  install   Install dependencies into existing environment.
  generate  Generate requirements.txt with pinned versions.
  clean     Remove the existing virtual environment.
  run       Run a Python script using the managed environment.
  sync      Sync dependencies with current imports.
  deps      Show dependency information.
  rebuild   Rebuild virtual environment from scratch.
```

## Quick Test

Run the unit tests to verify everything works:

```bash
cd metaenv
python tests/test_metaenv.py
```

You should see:

```
============================================================
ALL TESTS PASSED!
============================================================
```

## First Run

Create a test project:

```bash
# Create test directory
mkdir ~/metaenv-test
cd ~/metaenv-test

# Create a simple Python file
cat > main.py << 'EOF'
import requests
import numpy as np

def main():
    print("Hello from MetaEnv!")
    print(f"NumPy version: {np.__version__}")

if __name__ == "__main__":
    main()
EOF

# Create environment and install dependencies
metaenv create
```

Expected output:
```
MetaEnv - Creating Environment
Project: /home/user/metaenv-test

1. Virtual Environment
  Creating virtual environment at .venv...
  [OK] Virtual environment created successfully
  Upgrading pip...
  [OK] pip upgraded successfully
  Python: Python 3.10.x
  Pip: pip 23.x.x

2. Scanning Imports
  Scanned 1 file(s)
  Found 2 import statement(s)

3. Classifying Imports
  Standard library: 0 package(s)
  Local modules: 0 package(s)
  Third-party: 2 package(s)

4. Resolving Package Names
  Resolved to 2 PyPI package(s)

5. Checking Installed Packages
  [ERROR] requests (missing)
  [ERROR] numpy (missing)

6. Installing 2 Package(s)
  [OK] requests
  [OK] numpy

7. Generating requirements.txt
  [OK] Generated requirements.txt

8. Saving Dependency Map
  [OK] Saved to .metaenv/deps.json

[OK] Updated .gitignore

[OK] Environment created successfully!
```

## Uninstallation

```bash
pip uninstall metaenv
```

## Troubleshooting

### Command not found

If `metaenv` command is not found after installation:

1. Check if Python scripts directory is in PATH
2. Try running directly: `python -m metaenv.cli --help`
3. On Windows, you may need to restart your terminal

### Permission errors

On Linux/Mac, you might need to use `--user`:

```bash
pip install --user -e .
```

### Import errors

If you get import errors, make sure dependencies are installed:

```bash
pip install typer rich
```

## Development Setup

If you want to contribute or modify MetaEnv:

```bash
# Clone or navigate to project
cd metaenv

# Install in editable mode with dev dependencies
pip install -e .

# Run tests
python tests/test_metaenv.py

# Make your changes...

# Test your changes
metaenv create /path/to/test/project
```

## Next Steps

- Read the [README.md](../README.md) for full documentation
- Check out [QUICKSTART.md](QUICKSTART.md) for usage examples
- Explore [examples/](../examples/) for sample projects
