# MetaEnv Quick Start Guide

Get up and running with MetaEnv in 60 seconds.

## Install

```bash
# From source
cd metaenv
pip install -e .
```

## Try It Out

### 1. Create a Test Project

```bash
# Create a new directory
mkdir test-metaenv
cd test-metaenv

# Create a simple Python script with imports
cat > main.py << 'EOF'
import requests
import numpy as np
from sklearn.linear_model import LinearRegression
import cv2

def main():
    print("Hello from MetaEnv!")
    print(f"NumPy version: {np.__version__}")
    print(f"Requests installed: {requests}")

if __name__ == "__main__":
    main()
EOF
```

### 2. Create Environment

```bash
metaenv create
```

This will:
- Detect available Python version
- Scan `main.py` and find: requests, numpy, sklearn, cv2
- Resolve: sklearn → scikit-learn, cv2 → opencv-python
- Create `.venv/`
- Install: requests, numpy, scikit-learn, opencv-python

**That's it! One command setup complete.**

### 3. Generate Requirements (Optional)

```bash
metaenv generate
```

This will:
- Read all installed packages from venv
- Create `requirements.txt` with pinned versions

## Real-World Examples

### Clone and Setup
```bash
# Clone a project
git clone https://github.com/user/some-python-project.git
cd some-python-project

# One command to set up everything
metaenv create
```

### Use Specific Python Version
```bash
# Create environment with Python 3.11
metaenv create --python 3.11

# Or use short form
metaenv create -p 3.11
```

### Prepare for Deployment
```bash
# Generate locked requirements
metaenv generate
git add requirements.txt
git commit -m "Add requirements"
```

## Next Steps

- Read the full [README.md](../README.md) for all features
- Check out [examples/](../examples/) for more use cases
- Star the repo if you find it useful!

## Tips

💡 **Tip 1:** MetaEnv automatically detects all your project imports - no manual configuration needed.

💡 **Tip 2:** Use `--python` or `-p` to specify a Python version:
```bash
metaenv create -p 3.11
```

💡 **Tip 3:** `.metaenv/` and `.venv/` are automatically added to `.gitignore`.

💡 **Tip 4:** Generate requirements.txt anytime with:
```bash
metaenv generate
```

Happy coding! 🚀
