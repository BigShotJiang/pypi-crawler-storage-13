# MetaEnv - Project Summary

## Overview

**MetaEnv** is an automated Python environment builder that creates virtual environments, scans your project for import statements, installs all required third-party libraries, and optionally generates requirements.txt files. It eliminates the need for manual environment setup and dependency hunting.

**Version**: 0.1.0 (MVP Complete ✅)

## Quick Stats

- **Core Code**: ~1,100 lines across 7 modules
- **Commands**: 9 CLI commands (create, scan, install, generate, clean, run, sync, deps, rebuild)
- **Package Mappings**: 40+ import→PyPI package mappings
- **Python Support**: 3.8, 3.9, 3.10, 3.11, 3.12

## Core Modules

1. **[scanner.py](metaenv/scanner.py)** - AST-based Python import scanner
2. **[resolver.py](metaenv/resolver.py)** - Maps import names to PyPI packages
3. **[venv_mgr.py](metaenv/venv_mgr.py)** - Virtual environment management
4. **[installer.py](metaenv/installer.py)** - Package installation via pip
5. **[config.py](metaenv/config.py)** - Configuration and metadata management
6. **[cli.py](metaenv/cli.py)** - Full CLI interface with Typer/Rich
7. **[logger.py](metaenv/logger.py)** - Centralized logging

## CLI Commands

| Command | Description |
|---------|-------------|
| `metaenv create` | Create venv, scan project, install all dependencies automatically |
| `metaenv scan` | Scan imports only (no installation) |
| `metaenv install` | Install dependencies into existing environment |
| `metaenv generate` | Generate requirements.txt with pinned versions |
| `metaenv clean` | Remove virtual environment |
| `metaenv run` | Run script in managed environment |
| `metaenv sync` | Sync dependencies with current imports |
| `metaenv deps` | Show dependency information |
| `metaenv rebuild` | Rebuild environment from scratch |

## Key Features

✅ AST-based import scanning (accurate, not regex)
✅ Smart package resolution (cv2→opencv-python, sklearn→scikit-learn, etc.)
✅ Automatic virtual environment creation
✅ Automatic dependency installation
✅ Python version selection support
✅ Requirements.txt generation with pinned versions
✅ Cross-platform (Windows, Linux, macOS)
✅ Rich CLI with colors and progress indicators
✅ Centralized logging system
✅ .gitignore auto-update
✅ Zero configuration required

## Smart Import Resolution

MetaEnv correctly handles tricky imports:

| Import | PyPI Package |
|--------|--------------|
| `cv2` | opencv-python |
| `sklearn` | scikit-learn |
| `skimage` | scikit-image |
| `bs4` | beautifulsoup4 |
| `PIL` | Pillow |
| `yaml` | PyYAML |
| `dateutil` | python-dateutil |
| `dotenv` | python-dotenv |
| `MySQLdb` | mysqlclient |
| `psycopg2` | psycopg2-binary |

...and 30+ more!

## Project Structure

```
metaenv/
├── metaenv/                 # Core package
│   ├── __init__.py
│   ├── cli.py              # CLI interface
│   ├── scanner.py          # Import detection
│   ├── resolver.py         # Name resolution
│   ├── venv_mgr.py         # Venv management
│   ├── installer.py        # Package installation
│   ├── config.py           # Configuration
│   └── logger.py           # Logging system
├── examples/                # Example projects
│   ├── example_project.py
│   └── README.md
├── tests/test_metaenv.py   # Unit tests
├── docs/                    # Documentation
│   ├── PROJECT_SUMMARY.md
│   ├── QUICKSTART.md
│   └── INSTALLATION.md
├── README.md               # Main documentation
├── pyproject.toml          # Modern packaging
├── setup.py                # Legacy compatibility
└── LICENSE                 # MIT License
```

## Dependencies

Runtime:
- `typer >= 0.9.0` - CLI framework
- `rich >= 13.0.0` - Terminal formatting

Python: 3.8+

## Usage Examples

### Initialize a new project
```bash
metaenv create
```

### Sync after adding imports
```bash
metaenv sync
```

### Run your code
```bash
metaenv run main.py
```

### Lock dependencies
```bash
metaenv freeze
```

### Rebuild environment
```bash
metaenv rebuild
```

## Roadmap

### Phase 2 (Planned)
- [ ] Watch mode (auto-sync on file changes)
- [ ] Enhanced resolver (PyPI metadata cache)
- [ ] Jupyter notebook support (.ipynb)
- [ ] Better error handling and logging

### Phase 3 (Planned)
- [ ] CI/CD integration (GitHub Actions templates)
- [ ] Docker integration (Dockerfile generation)
- [ ] Security audit integration (pip-audit)
- [ ] Multi-environment support (dev/prod)

## Comparison with Alternatives

| Feature | MetaEnv | pip | poetry | pipenv |
|---------|---------|-----|--------|--------|
| Auto-scan imports | ✅ | ❌ | ❌ | ❌ |
| Auto-install | ✅ | ❌ | ❌ | ❌ |
| Zero config | ✅ | ✅ | ❌ | ❌ |
| Venv management | ✅ | ❌ | ✅ | ✅ |
| Per-file deps | ✅ | ❌ | ❌ | ❌ |
| Smart resolution | ✅ | ❌ | ❌ | ❌ |

## Philosophy

**"Your code is the source of truth. Dependencies are derived from actual imports, not manually maintained lists."**

## Getting Started

1. **Install**: `pip install -e .`
2. **Test**: `python tests/test_metaenv.py`
3. **Use**: `metaenv create`

## Documentation

- **[README.md](../README.md)** - Complete documentation
- **[QUICKSTART.md](QUICKSTART.md)** - 5-minute tutorial
- **[INSTALLATION.md](INSTALLATION.md)** - Setup and troubleshooting

## License

MIT License - See [LICENSE](../LICENSE)

---

**Status**: ✅ MVP Complete and Ready for Production Use

**Next Step**: Try it on your project!

```bash
metaenv init /path/to/your/project
```
