#!/usr/bin/env python3
# test_helptext.py - helptext module test suite

import pytest
from helptext import parse

pytestmark = pytest.mark.parametrize(
    'kwargs',
    [
        {'posixly_correct': False},
        {'posixly_correct': True},
    ],
)


def test_empty(kwargs):
    args = []
    doc = ''
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_lower(kwargs):
    args = []
    doc = 'a'
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_upper(kwargs):
    args = []
    doc = 'A'
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_digit(kwargs):
    args = []
    doc = '0'
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_symbol(kwargs):
    args = []
    doc = '?'
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_dash(kwargs):
    args = []
    doc = '-'
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_dashes(kwargs):
    args = []
    doc = '--'
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_short(kwargs):
    args = []
    doc = '-a'
    opts, operands = parse(args, doc, **kwargs)
    assert '-a' in opts


def test_short_unexpected(kwargs):
    args = ['-a']
    doc = ''
    with pytest.raises(SystemExit):
        opts, operands = parse(args, doc, **kwargs)


def test_short_upper(kwargs):
    args = []
    doc = '-A'
    opts, operands = parse(args, doc, **kwargs)
    assert '-A' in opts


def test_short_digit(kwargs):
    args = []
    doc = '-0'
    opts, operands = parse(args, doc, **kwargs)
    assert '-0' in opts


def test_short_symbol(kwargs):
    args = []
    doc = '-?'
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_short_long(kwargs):
    args = []
    doc = '-alpha'
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_repr(kwargs):
    args = []
    doc = '-a'
    opts, operands = parse(args, doc, **kwargs)
    assert repr(opts['-a']).startswith('Option')


def test_long(kwargs):
    args = []
    doc = '--alpha'
    opts, operands = parse(args, doc, **kwargs)
    if kwargs['posixly_correct']:
        assert opts == {}
    else:
        assert '--alpha' in opts


def test_long_unexpected(kwargs):
    args = ['--alpha']
    doc = ''
    with pytest.raises(SystemExit):
        opts, operands = parse(args, doc, **kwargs)


def test_long_long(kwargs):
    args = []
    doc = '--alpha-bravo'
    opts, operands = parse(args, doc, **kwargs)
    if kwargs['posixly_correct']:
        assert opts == {}
    else:
        assert '--alpha-bravo' in opts


def test_long_lower(kwargs):
    args = []
    doc = '--a'
    opts, operands = parse(args, doc, **kwargs)
    if kwargs['posixly_correct']:
        assert opts == {}
    else:
        assert '--a' in opts


def test_long_upper(kwargs):
    args = []
    doc = '--A'
    opts, operands = parse(args, doc, **kwargs)
    if kwargs['posixly_correct']:
        assert opts == {}
    else:
        assert '--A' in opts


def test_long_digit(kwargs):
    args = []
    doc = '--0'
    opts, operands = parse(args, doc, **kwargs)
    if kwargs['posixly_correct']:
        assert opts == {}
    else:
        assert '--0' in opts


def test_long_symbol(kwargs):
    args = []
    doc = '--?'
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_long_dash(kwargs):
    args = []
    doc = '---'
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_long_mixed(kwargs):
    args = []
    doc = '--abc-ABC-123'
    opts, operands = parse(args, doc, **kwargs)
    if kwargs['posixly_correct']:
        assert opts == {}
    else:
        assert '--abc-ABC-123' in opts


def test_flags_space(kwargs):
    args = []
    doc = '-a -b'
    opts, operands = parse(args, doc, **kwargs)
    assert '-a' in opts
    assert '-b' in opts
    assert opts['-a'] is opts['-b']


def test_flags_comma_space(kwargs):
    args = []
    doc = '-a, -b'
    opts, operands = parse(args, doc, **kwargs)
    assert '-a' in opts
    assert '-b' in opts
    assert opts['-a'] is opts['-b']


def test_flags_spaces(kwargs):
    args = []
    doc = '-a  -b'
    opts, operands = parse(args, doc, **kwargs)
    assert '-a' in opts
    assert '-b' not in opts


def test_flags_newline(kwargs):
    args = []
    doc = '-a\n-b'
    opts, operands = parse(args, doc, **kwargs)
    assert '-a' in opts
    assert '-b' in opts
    assert opts['-a'] is not opts['-b']


def test_flags_delimiter(kwargs):
    args = []
    doc = '-a -- -b'
    opts, operands = parse(args, doc, **kwargs)
    assert '-a' in opts
    assert '-b' in opts
    assert opts['-a'] is opts['-b']


def test_argument_reversed(kwargs):
    args = []
    doc = 'b -a'
    opts, operands = parse(args, doc, **kwargs)
    assert opts == {}


def test_argument_space(kwargs):
    args = []
    doc = '-a b'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].argument is True


def test_argument_long_attached(kwargs):
    args = []
    doc = '--alpha=bravo'
    opts, operands = parse(args, doc, **kwargs)
    if kwargs['posixly_correct']:
        assert opts == {}
    else:
        assert opts['--alpha'].argument is True


def test_argument_comma_space_arg(kwargs):
    args = []
    doc = '-a, b'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].argument is True


def test_argument_comma_space_opt_arg(kwargs):
    args = []
    doc = '-a, -b c'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].argument is True
    assert opts['-b'].argument is True


def test_argument_spaces(kwargs):
    args = []
    doc = '-a  b'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].argument is False


def test_argument_newline(kwargs):
    args = []
    doc = '-a\nb'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].argument is False


def test_enabled_none(kwargs):
    args = []
    doc = '-a'
    opts, operands = parse(args, doc, **kwargs)
    assert '-a' in opts
    assert not opts['-a'].enabled
    assert opts['-a'].count == 0


def test_enabled_short(kwargs):
    args = ['-a']
    doc = '-a'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].enabled
    assert opts['-a'].count == 1


def test_enabled_long(kwargs):
    args = ['--alpha']
    doc = '--alpha'
    if kwargs['posixly_correct']:
        with pytest.raises(SystemExit):
            opts, operands = parse(args, doc, **kwargs)
    else:
        opts, operands = parse(args, doc, **kwargs)
        assert opts['--alpha'].enabled
        assert opts['--alpha'].count == 1


def test_enabled_long_abbreviated(kwargs):
    args = ['--a', '--al', '--alp', '--alph', '--alpha']
    doc = '--alpha'
    if kwargs['posixly_correct']:
        with pytest.raises(SystemExit):
            opts, operands = parse(args, doc, **kwargs)
    else:
        opts, operands = parse(args, doc, **kwargs)
        assert opts['--alpha'].enabled
        assert opts['--alpha'].count == 5


def test_enabled_long_abbreviated_overlap(kwargs):
    args = ['--alpha']
    doc = '--alpha\n--alphabet'
    with pytest.raises(SystemExit):
        opts, operands = parse(args, doc, **kwargs)


def test_enabled_long_abbreviated_ambiguous(kwargs):
    args = ['--al']
    doc = '--alpha\n--alternate'
    with pytest.raises(SystemExit):
        opts, operands = parse(args, doc, **kwargs)


def test_count(kwargs):
    args = ['-a', '-a', '-a']
    doc = '-a'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].enabled
    assert opts['-a'].count == 3


def test_count_aliases(kwargs):
    args = ['-a', '-b']
    doc = '-a -b'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].enabled
    assert opts['-a'].count == 2
    assert opts['-b'].enabled
    assert opts['-b'].count == 2


def test_count_combined(kwargs):
    args = ['-aaa']
    doc = '-a'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].enabled
    assert opts['-a'].count == 3


def test_count_combined_mixed(kwargs):
    args = ['-abbba']
    doc = '-a\n-b'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].enabled
    assert opts['-a'].count == 2
    assert opts['-b'].enabled
    assert opts['-b'].count == 3


def test_value_none(kwargs):
    args = ['-a']
    doc = '-a'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].value is None


def test_value_missing(kwargs):
    args = ['-a']
    doc = '-a ARG'
    with pytest.raises(SystemExit):
        opts, operands = parse(args, doc, **kwargs)


def test_value_next(kwargs):
    args = ['-a', 'b']
    doc = '-a ARG'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].value == 'b'


def test_value_empty(kwargs):
    args = ['-a', '', 'b']
    doc = '-a ARG'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].value == ''
    assert operands == ['b']


def test_value_prefixed(kwargs):
    args = ['-a', '-b', 'c']
    doc = '-a ARG'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].value == '-b'
    assert operands == ['c']


def test_value_short_attached(kwargs):
    args = ['-ab', 'c']
    doc = '-a ARG'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].value == 'b'
    assert operands == ['c']


def test_value_short_combined_attached(kwargs):
    args = ['-abcd']
    doc = '-a\n-b\n-c ARG'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].value is None
    assert opts['-b'].value is None
    assert opts['-c'].value == 'd'


def test_value_short_combined_next(kwargs):
    args = ['-abc', 'd']
    doc = '-a\n-b\n-c ARG'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-a'].value is None
    assert opts['-b'].value is None
    assert opts['-c'].value == 'd'


def test_value_short_combined_missing(kwargs):
    args = ['-ab']
    doc = '-a\n-b ARG'
    with pytest.raises(SystemExit):
        opts, operands = parse(args, doc, **kwargs)


def test_value_long_attached(kwargs):
    args = ['--alpha=bravo', 'charlie']
    doc = '--alpha ARG'
    if kwargs['posixly_correct']:
        with pytest.raises(SystemExit):
            opts, operands = parse(args, doc, **kwargs)
    else:
        opts, operands = parse(args, doc, **kwargs)
        assert opts['--alpha'].value == 'bravo'
        assert operands == ['charlie']


def test_value_long_attached_empty(kwargs):
    args = ['--alpha=', 'bravo']
    doc = '--alpha ARG'
    if kwargs['posixly_correct']:
        with pytest.raises(SystemExit):
            opts, operands = parse(args, doc, **kwargs)
    else:
        opts, operands = parse(args, doc, **kwargs)
        assert opts['--alpha'].value == ''
        assert operands == ['bravo']


def test_value_long_attached_unexpected(kwargs):
    args = ['--alpha=bravo']
    doc = '--alpha'
    with pytest.raises(SystemExit):
        opts, operands = parse(args, doc, **kwargs)


def test_operands(kwargs):
    args = ['a']
    doc = ''
    opts, operands = parse(args, doc, **kwargs)
    assert operands == ['a']


def test_operands_dash(kwargs):
    args = ['-']
    doc = ''
    opts, operands = parse(args, doc, **kwargs)
    assert operands == ['-']


def test_operands_delimiter(kwargs):
    args = ['--', '-a']
    doc = ''
    opts, operands = parse(args, doc, **kwargs)
    assert operands == ['-a']


def test_operands_intermixed(kwargs):
    args = ['a', '-b', 'c']
    doc = '-b ARG'
    opts, operands = parse(args, doc, **kwargs)
    assert '-b' in opts
    if kwargs['posixly_correct']:
        assert not opts['-b'].enabled
        assert opts['-b'].count == 0
        assert opts['-b'].value is None
        assert operands == ['a', '-b', 'c']
    else:
        assert opts['-b'].enabled
        assert opts['-b'].count == 1
        assert opts['-b'].value == 'c'
        assert operands == ['a']


def test_helper(capsys, kwargs):
    args = ['--help']
    doc = '--help'
    if kwargs['posixly_correct']:
        with pytest.raises(SystemExit):
            opts, operands = parse(args, doc, **kwargs)
    else:
        with pytest.raises(SystemExit):
            opts, operands = parse(args, doc, **kwargs)
        captured = capsys.readouterr()
        assert captured.out.strip() == doc.strip()


def test_helper_alias(capsys, kwargs):
    args = ['-h']
    doc = '-h, --help'
    if kwargs['posixly_correct']:
        opts, operands = parse(args, doc, **kwargs)
        assert opts['-h'].enabled
        assert opts['-h'].count == 1
    else:
        with pytest.raises(SystemExit):
            opts, operands = parse(args, doc, **kwargs)
        captured = capsys.readouterr()
        assert captured.out.strip() == doc.strip()


def test_version(capsys, kwargs):
    args = ['--version']
    doc = '--version'
    if kwargs['posixly_correct']:
        with pytest.raises(SystemExit):
            opts, operands = parse(args, doc, **kwargs, version='1.2.3')
    else:
        with pytest.raises(SystemExit):
            opts, operands = parse(args, doc, **kwargs, version='1.2.3')
        captured = capsys.readouterr()
        assert captured.out.strip() == '1.2.3'


def test_version_alias(capsys, kwargs):
    args = ['-v']
    doc = '-v, --version'
    if kwargs['posixly_correct']:
        opts, operands = parse(args, doc, **kwargs, version='1.2.3')
        assert opts['-v'].enabled
        assert opts['-v'].count == 1
    else:
        with pytest.raises(SystemExit):
            opts, operands = parse(args, doc, **kwargs, version='1.2.3')
        captured = capsys.readouterr()
        assert captured.out.strip() == '1.2.3'


def test_version_default(kwargs):
    args = ['-v']
    doc = '-v, --version'
    opts, operands = parse(args, doc, **kwargs)
    assert opts['-v'].enabled
    assert opts['-v'].count == 1
