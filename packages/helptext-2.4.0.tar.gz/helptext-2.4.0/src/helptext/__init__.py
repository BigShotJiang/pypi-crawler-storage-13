def parse(args, doc, *, version=None, posixly_correct=False):
    class Option:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __repr__(self):
            attrs = [f"{k}={v!r}" for k, v in self.__dict__.items()]
            return f"Option({', '.join(attrs)})"

    opts = {}
    operands = []
    lines = [i.lstrip().split('  ', 1)[0] for i in doc.split('\n')]
    for line in [i for i in lines if i.startswith('-')]:
        opt = Option(enabled=False, count=0, argument=False, value=None)
        flags = []
        for s in line.replace(',', ' ').split():
            if not s.startswith('-') or s == '-':
                opt.argument = True
            elif len(s) == 2 or s.startswith('--') and not posixly_correct:
                if '=' in s:
                    s = s.split('=', 1)[0]
                    opt.argument = True
                if s.isascii() and s.replace('-', '').isalnum():
                    flags.append(s)
        opts.update({k: opt for k in flags})
    while args:
        s, args = args[0], args[1:]
        if s == '--':
            break
        if not s.startswith('-') or s == '-':
            operands.append(s)
            if posixly_correct:
                break
            continue
        if s.startswith('--'):
            s, attached = s.split('=', 1) + ([] if '=' in s else [None])
            matches = [i for i in opts if i.startswith(s)]
            if not matches:
                raise SystemExit(f"unrecognized option: {s}")
            if 1 < len(matches):
                raise SystemExit(f"option is ambiguous: {s}")
            s = matches[0]
            if not opts[s].argument and attached is not None:
                raise SystemExit(f"option does not allow an argument: {s}")
        else:
            s, attached = s[:2], s[2:] or None
            if s not in opts:
                raise SystemExit(f"invalid option: {s}")
            if not opts[s].argument and attached is not None:
                args = ['-' + attached] + args
        opts[s].enabled = True
        opts[s].count += 1
        if opts[s].argument:
            opts[s].value = attached
            if opts[s].value is None:
                if not args:
                    raise SystemExit(f"option requires an argument: {s}")
                opts[s].value, args = args[0], args[1:]
    if '--help' in opts and opts['--help'].enabled:
        print(doc.strip())
        raise SystemExit()
    if version and '--version' in opts and opts['--version'].enabled:
        print(version)
        raise SystemExit()
    return opts, operands + args
