# helptext - a documentation-generated argument parser

```py
"""
Usage: demo.py [OPTIONS] [OPERANDS...]

OPTIONS
  -a ARG, --alpha       capture an argument
"""

import sys
import helptext

opts, operands = helptext.parse(sys.argv[1:], __doc__)
```

```py
$ python3 -i demo.py -a b c
>>> opts['-a'] is opts['--alpha']
True
>>> opts['--alpha']
Option(enabled=True, count=1, argument=True, value='b')
>>> operands
['c']
```

# Installation

```console
pip install helptext
```

# API

This module provides a single function.

```py
helptext.parse(args, doc, *, version=None, posixly_correct=False)
```

Parses command-line arguments according to a program's help text.

_args_ is a list of positional parameter strings, not including the command
name special parameter `$0`, typically `sys.argv[1:]`. _doc_ is a string
containing a typical option list, ideally `__doc__` as described in
[PEP 257 – Docstring Conventions][1].

Returns an _opts_ dictionary and a list of string _operands_.

Option attributes include a boolean _enabled_ set to `True` when invoked on the
command-line, an integer _count_ of invocations, a boolean _argument_ set to
`True` when an option-argument is required, and a string `value` representing
the option-argument, default `None`.

Command-line errors are printed to `stderr` and raise `SystemExit(1)`.

If `--help` is configured in _doc_ and invoked in _args_, _doc_ is printed to
`stdout` and `SystemExit(0)` is raised. Similarly, if a _version_ string is
provided, it is printed and the program exited when `--version` (or an alias)
is defined and enabled.

If _posixly_correct_, disable GNU-style long options and intermixed operands.
As with the explicit `--` delimiter argument, the first non-option argument
will terminate argument parsing, preserving strict positional order and
option-like operands.

[1]: https://peps.python.org/pep-0257

