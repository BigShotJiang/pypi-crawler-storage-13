## cdf 

### Changed

- Set minimum version of cognite-sdk to `7.87.0` in pyproject.toml

## templates

No changes.

Co-authored-by: Magnus Schjølberg <magnus.schjolberg@cognitedata.com>