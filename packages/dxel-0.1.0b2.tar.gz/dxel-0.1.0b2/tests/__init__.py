"""
Tests for DataGenie package
"""
