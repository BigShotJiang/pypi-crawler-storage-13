"""
OpenRouter LLM Adapter for worker-core-lib.

This adapter connects to OpenRouter's API gateway to access multiple LLM providers
including Gemini Flash, Claude, GPT-4, and others.
"""
import httpx
import logging
import os
from typing import Optional, List

from .llm_port import LLMPort

logger = logging.getLogger(__name__)


class OpenRouterSettings:
    """Configuration settings for OpenRouter adapter."""
    
    def __init__(self):
        self.OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
        self.OPENROUTER_MODEL_NAMES = os.getenv(
            "OPENROUTER_MODEL_NAMES", 
            "google/gemini-flash-1.5,google/gemini-pro-1.5"
        )
        self.OPENROUTER_BASE_URL = os.getenv(
            "OPENROUTER_BASE_URL",
            "https://openrouter.ai/api/v1"
        )
        self.OPENROUTER_TIMEOUT = int(os.getenv("OPENROUTER_TIMEOUT", "180"))
        self.OPENROUTER_MAX_RETRIES = int(os.getenv("OPENROUTER_MAX_RETRIES", "2"))
        self.OPENROUTER_SITE_URL = os.getenv("OPENROUTER_SITE_URL", "")
        self.OPENROUTER_APP_NAME = os.getenv("OPENROUTER_APP_NAME", "MeshSync-Worker")


class OpenRouterAdapter(LLMPort):
    """
    Adapter to interact with OpenRouter LLM gateway service.
    
    OpenRouter provides access to multiple LLM providers through a single API.
    Supports automatic fallback between models if one fails.
    """

    def __init__(self, settings: Optional[OpenRouterSettings] = None):
        """
        Initialize OpenRouter adapter.
        
        Args:
            settings: Optional OpenRouterSettings instance. If not provided,
                     loads from environment variables.
        
        Raises:
            ValueError: If OPENROUTER_API_KEY is not configured
        """
        if settings:
            self.settings = settings
        else:
            logger.info("OpenRouterSettings not provided, loading from environment.")
            self.settings = OpenRouterSettings()

        if not self.settings.OPENROUTER_API_KEY:
            raise ValueError(
                "OPENROUTER_API_KEY must be set in the environment or OpenRouterSettings. "
                "Get your key from https://openrouter.ai/keys"
            )
        
        # Parse model names (comma-separated list)
        self.model_names: List[str] = [
            name.strip() 
            for name in self.settings.OPENROUTER_MODEL_NAMES.split(",")
            if name.strip()
        ]
        
        if not self.model_names:
            raise ValueError(
                "OPENROUTER_MODEL_NAMES must contain at least one model. "
                "Example: google/gemini-flash-1.5,google/gemini-pro-1.5"
            )
        
        logger.info(
            f"OpenRouter adapter initialized with models: {', '.join(self.model_names)}"
        )
        
        self.current_model: Optional[str] = None  # Track which model is being used

    async def generate_text(
        self, 
        prompt: str, 
        max_tokens: int, 
        temperature: float
    ) -> str:
        """
        Generates text using OpenRouter service with multi-model fallback.
        
        Args:
            prompt: The text prompt to send to the LLM
            max_tokens: Maximum number of tokens to generate
            temperature: Sampling temperature (0.0 to 1.0)
        
        Returns:
            str: Generated text response
        
        Raises:
            Exception: If all models fail to generate text
        """
        # Try each model in sequence until one succeeds
        last_error = None
        
        for model_name in self.model_names:
            for attempt in range(self.settings.OPENROUTER_MAX_RETRIES):
                try:
                    self.current_model = model_name
                    logger.info(
                        f"OpenRouter: Generating text with model '{model_name}' "
                        f"(attempt {attempt + 1}/{self.settings.OPENROUTER_MAX_RETRIES})"
                    )
                    
                    response_text = await self._call_openrouter_api(
                        model_name=model_name,
                        prompt=prompt,
                        max_tokens=max_tokens,
                        temperature=temperature
                    )
                    
                    logger.info(
                        f"OpenRouter: Successfully generated {len(response_text)} characters "
                        f"with model '{model_name}'"
                    )
                    return response_text
                    
                except Exception as e:
                    last_error = e
                    logger.warning(
                        f"OpenRouter: Model '{model_name}' attempt {attempt + 1} failed: {str(e)}"
                    )
                    
                    # Don't retry on authentication errors
                    if "401" in str(e) or "authentication" in str(e).lower():
                        logger.error(
                            "Authentication failed. Please check your OPENROUTER_API_KEY. "
                            "Get a key from https://openrouter.ai/keys"
                        )
                        raise
                    
                    # Continue to next attempt/model
                    continue
        
        # All models and retries failed
        error_msg = (
            f"OpenRouter: All models failed after {self.settings.OPENROUTER_MAX_RETRIES} "
            f"retries. Models tried: {', '.join(self.model_names)}. "
            f"Last error: {str(last_error)}"
        )
        logger.error(error_msg)
        raise Exception(error_msg)

    async def _call_openrouter_api(
        self,
        model_name: str,
        prompt: str,
        max_tokens: int,
        temperature: float
    ) -> str:
        """
        Make API call to OpenRouter.
        
        Args:
            model_name: Name of the model to use (e.g., "google/gemini-flash-1.5")
            prompt: The prompt text
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
        
        Returns:
            str: Generated text
        
        Raises:
            httpx.HTTPStatusError: On HTTP errors
            httpx.RequestError: On network errors
        """
        endpoint = f"{self.settings.OPENROUTER_BASE_URL}/chat/completions"
        
        # Build headers
        headers = {
            "Authorization": f"Bearer {self.settings.OPENROUTER_API_KEY}",
            "Content-Type": "application/json",
        }
        
        # Add optional headers for usage tracking
        if self.settings.OPENROUTER_SITE_URL:
            headers["HTTP-Referer"] = self.settings.OPENROUTER_SITE_URL
        if self.settings.OPENROUTER_APP_NAME:
            headers["X-Title"] = self.settings.OPENROUTER_APP_NAME
        
        # Build payload (OpenAI-compatible format)
        payload = {
            "model": model_name,
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    endpoint,
                    json=payload,
                    headers=headers,
                    timeout=self.settings.OPENROUTER_TIMEOUT
                )
                response.raise_for_status()
                
                response_data = response.json()
                
                # Extract text from OpenAI-compatible response format
                if "choices" in response_data and len(response_data["choices"]) > 0:
                    message = response_data["choices"][0].get("message", {})
                    content = message.get("content", "").strip()
                    
                    if not content:
                        raise ValueError(
                            f"Empty response from model '{model_name}'. "
                            f"Response: {response_data}"
                        )
                    
                    return content
                else:
                    raise ValueError(
                        f"Unexpected response format from OpenRouter: {response_data}"
                    )

            except httpx.HTTPStatusError as e:
                logger.error(
                    f"OpenRouter HTTP error: {e.response.status_code} - {e.response.text}"
                )
                raise
                
            except httpx.RequestError as e:
                logger.error(
                    f"OpenRouter request error while calling {e.request.url!r}: {str(e)}"
                )
                raise
