"""Basic tests for sciexplorer package"""

import sciexplorer


def test_version():
    """Test that version is defined"""
    assert hasattr(sciexplorer, "__version__")
    assert isinstance(sciexplorer.__version__, str)


def test_import():
    """Test that the package can be imported"""
    assert sciexplorer is not None
