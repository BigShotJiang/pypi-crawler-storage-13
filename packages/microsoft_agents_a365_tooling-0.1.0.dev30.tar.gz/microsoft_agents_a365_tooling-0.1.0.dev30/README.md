# microsoft-agents-a365-tooling

[![PyPI](https://img.shields.io/pypi/v/microsoft-agents-a365-tooling?label=PyPI&logo=pypi)](https://pypi.org/project/microsoft-agents-a365-tooling)
[![PyPI Downloads](https://img.shields.io/pypi/dm/microsoft-agents-a365-tooling?label=Downloads&logo=pypi)](https://pypi.org/project/microsoft-agents-a365-tooling)

Core tooling functionality for MCP (Model Context Protocol) tool server management in applications built with the Microsoft Agent 365 SDK. This package provides the foundation for discovering, registering, and managing tool servers across different AI frameworks.

## Installation

```bash
pip install microsoft-agents-a365-tooling
```

## Usage

For usage examples and detailed documentation, see the [Tooling documentation](https://learn.microsoft.com/microsoft-agent-365/developer/tooling?tabs=python) on Microsoft Learn.

## Support

For issues, questions, or feedback:

- File issues in the [GitHub Issues](https://github.com/microsoft/Agent365-python/issues) section
- See the [main documentation](../../../README.md) for more information
 
## Trademarks
 
*Microsoft, Windows, Microsoft Azure and/or other Microsoft products and services referenced in the documentation may be either trademarks or registered trademarks of Microsoft in the United States and/or other countries. The licenses for this project do not grant you rights to use any Microsoft names, logos, or trademarks. Microsoft's general trademark guidelines can be found at http://go.microsoft.com/fwlink/?LinkID=254653.*

## License

Copyright (c) Microsoft Corporation. All rights reserved.

Licensed under the MIT License - see the [LICENSE](../../../LICENSE.md) file for details.