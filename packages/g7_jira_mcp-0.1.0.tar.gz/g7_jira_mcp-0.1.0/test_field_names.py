#!/usr/bin/env python3
"""测试 get_issue 的 custom_field_names 功能."""
import json
from src.jira_mcp.server import get_issue

def test_get_issue_with_field_names():
    """测试获取问题时是否返回自定义字段名称映射."""

    # 替换为你的实际 issue key
    issue_key = input("请输入要测试的 JIRA issue key (例如: ERP-123): ").strip()

    if not issue_key:
        # issue_key = "ZNGC2-16032"
        print("未输入 issue key，退出测试")
        return

    print(f"\n正在获取问题 {issue_key}...")
    result = get_issue(issue_key)

    if "error" in result:
        print(f"❌ 错误: {result['error']}")
        return

    print(f"✅ 成功获取问题: {result['key']} - {result['summary']}\n")

    # 检查是否有 custom_field_names 字段
    if "custom_field_names" in result:
        print("✅ custom_field_names 字段存在！\n")
        print("=" * 60)
        print("自定义字段名称映射 (custom_field_names):")
        print("=" * 60)

        custom_field_names = result["custom_field_names"]
        for field_id, field_name in sorted(custom_field_names.items()):
            # 获取该字段的实际值（简化显示）
            value = result.get(field_id)
            if value is not None:
                if isinstance(value, dict):
                    value_str = f"[字典: {len(value)} 个键]"
                elif isinstance(value, list):
                    value_str = f"[列表: {len(value)} 项]"
                elif isinstance(value, str) and len(value) > 50:
                    value_str = value[:50] + "..."
                else:
                    value_str = str(value)
                print(f"  {field_id:25} => {field_name:20} = {value_str}")
            else:
                print(f"  {field_id:25} => {field_name}")

        print(f"\n共 {len(custom_field_names)} 个自定义字段\n")
    else:
        print("❌ custom_field_names 字段不存在！")
        return

    # 保存完整结果到文件
    output_file = f"{issue_key}_result.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f"📄 完整结果已保存到: {output_file}")

if __name__ == "__main__":
    try:
        test_get_issue_with_field_names()
    except Exception as e:
        print(f"❌ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
