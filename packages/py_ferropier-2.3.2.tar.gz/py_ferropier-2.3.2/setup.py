from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="py-ferropier",
    version="2.3.2",
    author="LORD",
    author_email="grizlyabab@gmail.com",
    description="A secure Python file encoder/decoder with password protection",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
    python_requires=">=3.6",
    entry_points={
        'console_scripts': [
            'ferropier=ferropier.cli:main',
        ],
    },
    keywords="encoding decoding security cryptography",
    url="https://github.com/grizlyeditor/ferropier",
    project_urls={
        "Bug Reports": "https://github.com/grizlyeditor/ferropier/issues",
        "Source": "https://github.com/grizlyeditor/ferropier",
    },
)