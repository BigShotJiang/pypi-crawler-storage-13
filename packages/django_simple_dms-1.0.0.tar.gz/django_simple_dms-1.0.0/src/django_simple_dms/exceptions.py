class ForbiddenException(Exception):
    pass
