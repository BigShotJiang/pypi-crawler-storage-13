"""
Optimized Python wrapper for PrepareCache()

This wrapper handles point list preparation in Python (which is faster than
doing it in C++ via pybind11), then calls the C++ PrepareCache().

Usage:
    import rad_ngsolve_cached_wrapper as rn_cache

    # Collect points from mesh
    all_points = [[x1,y1,z1], [x2,y2,z2], ...]

    # Prepare cache (optimized)
    A_cf = rad_ngsolve.RadiaField(bg_field, 'a')
    rn_cache.prepare_cache_optimized(A_cf, all_points)

    # Use cached values
    gf.Set(A_cf)  # Fast!
"""

def prepare_cache_optimized(coefficient_function, points_meters):
    """
    Optimized PrepareCache() with Python-side list preparation

    Args:
        coefficient_function: rad_ngsolve.RadiaField object
        points_meters: List of [x, y, z] in meters

    This function is much faster than calling PrepareCache() directly because:
    - Python list operations are fast in Python
    - Avoids pybind11 overhead for list building
    - Only crosses Python/C++ boundary once
    """
    # Call the C++ PrepareCache with Python-prepared list
    # The C++ side will extract points to C++ arrays efficiently
    coefficient_function.PrepareCache(points_meters)
