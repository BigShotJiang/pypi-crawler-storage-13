"""Mores: LLM-powered decorators for intelligent function behavior.

Mores (from Latin 'mōrēs', meaning customs or behavioral norms) provides
decorators that use language models as a substrate for code behavior.
"""

from .sdk import guard, mock, doubt, Value, Rejected, DoubtError, Maybe

# Main decorator exports
__all__ = [
    # Decorators
    "guard",  # Pre-execution validation against rules
    "mock",  # LLM-powered function mocking
    "doubt",  # Post-execution output validation
    # Return types
    "Value",
    "Rejected",
    "Maybe",
    # Exceptions
    "DoubtError",
]
