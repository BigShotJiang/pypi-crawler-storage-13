from django.apps import AppConfig


class DjConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "varorm.dj"
    verbose_name = "varorm"
