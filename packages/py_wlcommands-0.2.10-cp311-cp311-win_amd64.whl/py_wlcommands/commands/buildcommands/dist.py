"""Build dist command for WL Commands."""

import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from ...exceptions import CommandError
from ...utils.logging import log_error, log_info
from ...utils.uv_workspace import is_uv_workspace
from .. import Command, register_command


@register_command("build dist")
class BuildDistCommand(Command):
    """Command to build distribution packages."""

    @property
    def name(self) -> str:
        """Return the command name."""
        return "dist"

    @property
    def help(self) -> str:
        """Return the command help text."""
        return "Build distribution packages"

    def execute(self, *args: Any, **kwargs: Any) -> None:
        """Execute the build dist command."""
        # Determine the platform and run the appropriate build command
        try:
            log_info("Building distribution packages...")

            # Check if we are in a uv workspace
            is_workspace = self._detect_uv_workspace()
            python_executable = None
            if is_workspace:
                log_info("✓ uv workspace environment detected")
                # In a workspace, check if .venv exists
                if not Path(".venv").exists():
                    log_info("No .venv found, creating virtual environment...")
                    # Create virtual environment
                    self._create_venv()

                # Set python executable path for maturin
                if sys.platform.startswith("win"):
                    python_executable = str(Path(".venv/Scripts/python.exe").resolve())
                else:
                    python_executable = str(Path(".venv/bin/python").resolve())
            else:
                log_info("Not in uv workspace environment")

            # Use maturin to build the distribution packages
            # Directly use maturin from PATH
            command = ["maturin", "build", "--release", "--out", "dist"]
            # If we have a python executable, use it for the build
            if python_executable:
                command.extend(["-i", python_executable])

            log_info(f"Trying to build with: {' '.join(command)}")
            subprocess.run(
                command,
                check=True,
                capture_output=False,
                text=True,
            )

            # If in workspace, remove the .venv directory
            if is_workspace and Path(".venv").exists():
                log_info("In uv workspace, removing .venv directory...")
                shutil.rmtree(".venv")
                log_info("✓ .venv directory removed")

            log_info("✓ Distribution packages built successfully")
        except subprocess.CalledProcessError as e:
            log_error(f"Failed to build distribution packages: {e}")
            raise CommandError(f"Build dist failed with return code {e.returncode}")
        except FileNotFoundError:
            log_error(
                "Maturin command not found. Please ensure maturin is installed and in PATH."
            )
            raise CommandError("Maturin command not found")
        except Exception as e:
            log_error(f"Unexpected error during build dist: {e}")
            raise CommandError(f"Build dist failed: {e}")

    def _detect_uv_workspace(self) -> bool:
        """
        Detect if we are in a uv workspace.
        This is kept for backward compatibility with tests.

        Returns:
            bool: True if in a uv workspace, False otherwise.
        """
        return is_uv_workspace()

    def _create_venv(self) -> None:
        """Create virtual environment using uv."""
        try:
            # Use uv to create virtual environment
            cmd = ["uv", "venv"]
            subprocess.run(
                cmd,
                check=True,
                capture_output=False,
                text=True,
            )
            log_info("✓ Virtual environment created successfully")
        except subprocess.CalledProcessError as e:
            log_error(f"Failed to create virtual environment: {e}")
            raise CommandError(f"Failed to create virtual environment: {e}")
        except Exception as e:
            log_error(f"Unexpected error creating virtual environment: {e}")
            raise CommandError(f"Failed to create virtual environment: {e}")
