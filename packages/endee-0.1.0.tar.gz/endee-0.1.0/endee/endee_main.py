import requests
import secrets
import json
from endee.exceptions import raise_exception
from endee.index import Index
from endee.user import User
from endee.crypto import get_checksum
from endee.utils import is_valid_index_name
from functools import lru_cache

SUPPORTED_REGIONS = ["us-west", "india-west", "local"]
class Endee:
    def __init__(self, token:str|None=None):
        self.token = token
        self.region = "local"
        self.base_url = "http://127.0.0.1:8080/api/v1"
        # Token will be of the format user:token:region
        if token:
            token_parts = self.token.split(":")
            if len(token_parts) > 2:
                self.base_url = f"https://{token_parts[2]}.endee.io/api/v1"
                self.token = f"{token_parts[0]}:{token_parts[1]}"
        self.version = 1

    def __str__(self):
        return self.token

    def set_token(self, token:str):
        self.token = token
        self.region = self.token.split (":")[1]
    
    def set_base_url(self, base_url:str):
        self.base_url = base_url
    
    def generate_key(self) -> str:
        """Generate a secure random encryption key.
        
        Returns:
            32-character hexadecimal encryption key
            
        Note:
            Alias for generate_encryption_key() for backward compatibility
        """
        return self.generate_encryption_key()
    
    def generate_encryption_key(self) -> str:
        """Generate a secure random encryption key.
        
        Returns:
            32-character hexadecimal encryption key
        """
        encryption_key = secrets.token_hex(16)  # 16 bytes * 2 hex chars/byte = 32 chars
        warning_message = (
            "⚠️  IMPORTANT: Store this encryption key in a secure location.\n"
            "Loss of the key will result in irreversible loss of associated vector data.\n"
            f"Encryption Key: {encryption_key}"
        )
        print(warning_message)
        return encryption_key

    def create_index(self, name: str, dimension: int, space_type: str, M: int = 16, 
                     key: str | None = None, ef_con: int = 128, 
                     use_fp16: bool = True, version: int = None, 
                     hnsw_m: int = None, encryption_key: str | None = None, ef_construction: int = None):
        """Create a new vector index.
        
        Args:
            name: Index name (alphanumeric + underscores, max 48 chars)
            dimension: Vector dimension (max 10000)
            space_type: Distance metric ("cosine", "l2", or "ip")
            M: HNSW graph connectivity parameter (default 16)
            key: Optional encryption key for secure storage
            ef_con: HNSW construction parameter (default 128)
            use_fp16: Use 16-bit floating point for storage (default True)
            version: API version override
            hnsw_m: Alias for M (backward compatibility)
            encryption_key: Alias for key (backward compatibility)
            ef_construction: Alias for ef_con (backward compatibility)
            
        Returns:
            Success message string
        """
        # Handle backward compatibility aliases
        final_m = hnsw_m if hnsw_m is not None else M
        final_key = encryption_key if encryption_key is not None else key
        final_ef_con = ef_construction if ef_construction is not None else ef_con
        
        if not is_valid_index_name(name):
            raise ValueError(
                "Invalid index name. Index name must be alphanumeric, "
                "can contain underscores, and be less than 48 characters"
            )
        if dimension > 10000:
            raise ValueError("Dimension cannot be greater than 10000")
        
        normalized_space_type = space_type.lower()
        if normalized_space_type not in ["cosine", "l2", "ip"]:
            raise ValueError(f"Invalid space type: {space_type}. Must be 'cosine', 'l2', or 'ip'")
        
        request_headers = {
            'Authorization': f'{self.token}',
            'Content-Type': 'application/json'
        }
        request_payload = {
            'index_name': name,
            'dim': dimension,
            'space_type': normalized_space_type,
            'M': final_m,
            'ef_con': final_ef_con,
            'checksum': get_checksum(final_key),
            'use_fp16': use_fp16,
            'version': version
        }
        response = requests.post(
            f'{self.base_url}/index/create', 
            headers=request_headers, 
            json=request_payload
        )
        if response.status_code != 200:
            print(response.text)
            raise_exception(response.status_code, response.text)
        return "Index created successfully"

    def list_indexes(self):
        """List all indexes for the authenticated user.
        
        Returns:
            List of index information dictionaries
        """
        request_headers = {
            'Authorization': f'{self.token}',
        }
        response = requests.get(f'{self.base_url}/index/list', headers=request_headers)
        if response.status_code != 200:
            raise_exception(response.status_code, response.text)
        indexes_list = response.json()
        return indexes_list
    
    def delete_index(self, name: str):
        """Delete an index by name.
        
        Args:
            name: Name of the index to delete
            
        Returns:
            Success message string
            
        Note:
            TODO - Delete the index cache if the index is deleted
        """
        request_headers = {
            'Authorization': f'{self.token}',
        }
        response = requests.delete(
            f'{self.base_url}/index/{name}/delete', 
            headers=request_headers
        )
        if response.status_code != 200:
            print(response.text)
            raise_exception(response.status_code, response.text)
        return f'Index {name} deleted successfully'


    @lru_cache(maxsize=10)
    def get_index(self, name: str, key: str | None = None):
        """Retrieve an index instance by name.
        
        Args:
            name: Name of the index to retrieve
            key: Encryption key if index is encrypted
            
        Returns:
            Index instance configured with server parameters
            
        Note:
            Results are cached (LRU cache, maxsize=10)
        """
        request_headers = {
            'Authorization': f'{self.token}',
            'Content-Type': 'application/json'
        }
        # Get index details from the server
        response = requests.get(
            f'{self.base_url}/index/{name}/info', 
            headers=request_headers
        )
        if response.status_code != 200:
            raise_exception(response.status_code, response.text)
        
        index_params = response.json()
        
        # Verify encryption key matches
        calculated_checksum = get_checksum(key)
        if calculated_checksum != index_params['checksum']:
            raise_exception(403, "Checksum does not match. Please check the encryption key.")
        
        index_instance = Index(
            name=name, 
            key=key, 
            token=self.token, 
            url=self.base_url, 
            version=self.version, 
            params=index_params
        )
        return index_instance
    
    def get_user(self):
        """Get User management instance for the authenticated user.
        
        Returns:
            User instance configured with current credentials
        """
        return User(self.base_url, self.token)



