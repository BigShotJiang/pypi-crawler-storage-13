import re

def is_valid_index_name(index_name: str) -> bool:
    """Validate index name against allowed pattern and length.
    
    Args:
        index_name: Name to validate
        
    Returns:
        True if valid (alphanumeric + underscores, max 48 chars), False otherwise
    """
    alphanumeric_pattern = re.compile(r'^[a-zA-Z0-9_]+$')
    is_pattern_match = alphanumeric_pattern.match(index_name) is not None
    is_valid_length = len(index_name) <= 48
    return is_pattern_match and is_valid_length