
import json
import zlib

def get_checksum(encryption_key: str | None) -> int:
    """Calculate checksum from the last two characters of encryption key.
    
    Args:
        encryption_key: Hexadecimal encryption key string
        
    Returns:
        Integer checksum value, or -1 if key is None
    """
    if encryption_key is None:
        return -1
    return int(encryption_key[-2:], 16)

def json_zip(data_dict):
    """Compress a dictionary into bytes using zlib compression."""
    if not data_dict:
        return b''
    json_string = json.dumps(data_dict).encode('utf-8')
    compressed_data = zlib.compress(json_string)
    return compressed_data

def json_unzip(compressed_data):
    """Decompress zlib-compressed bytes back into a dictionary."""
    if not compressed_data:
        return {}
    decompressed_data = zlib.decompress(compressed_data)
    return json.loads(decompressed_data.decode('utf-8'))