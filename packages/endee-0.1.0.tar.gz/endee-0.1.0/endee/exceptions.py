import json
class EndeeException(Exception):
    """Base class for all Endee related exceptions.
    
    All custom exceptions in the Endee library inherit from this class,
    allowing for easy exception handling with a single except clause.
    """
    def __init__(self, error_message="An error occurred in Endee"):
        self.message = error_message
        super().__init__(error_message)

    def __str__(self):
        return self.message

class APIException(EndeeException):
    """Generic API exception for 4xx client errors.
    
    Raised when an API call returns a client error (typically 400 Bad Request).
    """
    def __init__(self, error_message):
        self.message = error_message
        super().__init__(f"API Error: {error_message}")

class ServerException(EndeeException):
    """Server exception for 5xx server errors.
    
    Raised when the server encounters an error or is temporarily unavailable.
    """
    def __init__(self, error_message):
        self.message = error_message
        super().__init__(f"Server Busy: {error_message}")

class ForbiddenException(EndeeException):
    """Permission denied exception (403 Forbidden).
    
    Raised when the user lacks permission to perform the requested operation.
    """
    def __init__(self, error_message):
        self.message = error_message
        super().__init__(f"Forbidden: {error_message}")

class ConflictException(EndeeException):
    """Resource conflict exception (409 Conflict).
    
    Raised when attempting to create a resource that already exists,
    such as creating an index with a name that's already taken.
    """
    def __init__(self, error_message):
        self.message = error_message
        super().__init__(f"Conflict: {error_message}")

class NotFoundException(EndeeException):
    """Resource not found exception (404 Not Found).
    
    Raised when the requested resource (index, user, vector, etc.) doesn't exist.
    """
    def __init__(self, error_message):
        self.message = error_message
        super().__init__(f"Resource Not Found: {error_message}")

class AuthenticationException(EndeeException):
    """Authentication failure exception (401 Unauthorized).
    
    Raised when authentication fails due to invalid or missing credentials/token.
    """
    def __init__(self, error_message):
        self.message = error_message
        super().__init__(f"Authentication Error: {error_message}")

class SubscriptionException(EndeeException):
    """Subscription/payment required exception (402 Payment Required).
    
    Raised when the operation requires a paid subscription or quota has been exceeded.
    """
    def __init__(self, error_message):
        self.message = error_message
        super().__init__(f"Subscription Error: {error_message}")

def raise_exception(status_code: int, response_text: str = None):
    """Raise an appropriate exception based on HTTP status code.
    
    Args:
        status_code: HTTP status code from the API response
        response_text: Response body text (may contain JSON error message)
        
    Raises:
        EndeeException: Appropriate exception subclass based on status code
    """
    error_message = None
    
    # Try to extract error message from JSON response
    try:
        parsed_response = json.loads(response_text)
        error_message = parsed_response.get("error", "Unknown error")
    except (json.JSONDecodeError, TypeError, AttributeError):
        error_message = response_text or "Unknown error"

    # Map HTTP status codes to exception types
    if status_code == 400:
        raise APIException(error_message)
    elif status_code == 401:
        raise AuthenticationException(error_message)
    elif status_code == 402:
        raise SubscriptionException(error_message)
    elif status_code == 403:
        raise ForbiddenException(error_message)
    elif status_code == 404:
        raise NotFoundException(error_message)
    elif status_code == 409:
        raise ConflictException(error_message)
    elif status_code >= 500:
        server_error_message = "Server is busy. Please try again in sometime"
        raise ServerException(server_error_message)
    else:
        unknown_error_message = "Unknown Error. Please try again in sometime"
        raise APIException(unknown_error_message)