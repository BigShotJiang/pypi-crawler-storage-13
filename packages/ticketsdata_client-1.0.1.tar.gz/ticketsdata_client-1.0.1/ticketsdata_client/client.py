import asyncio
import time
from datetime import datetime, timezone
import aiohttp
from aiohttp import ClientSession, ClientTimeout


class TicketsDataClient:
    """
    Async client for TicketsData API.
    Supports all platforms and attaches metadata (platform, event_url, timings) to each result.
    """

    def __init__(
        self,
        username: str,
        password: str,
        base_url: str = "https://ticketsdata.com/fetch",
        concurrency: int = 5,
        timeout: int = 25,
        max_retries: int = 2,
        include_metadata: bool = True,   # <- NEW
    ):
        self.username = username
        self.password = password
        self.base_url = base_url
        self.semaphore = asyncio.Semaphore(concurrency)
        self.timeout = ClientTimeout(total=timeout)
        self.max_retries = max_retries
        self.include_metadata = include_metadata
        self.session: ClientSession | None = None

    async def _ensure_session(self):
        if self.session is None:
            self.session = aiohttp.ClientSession(timeout=self.timeout)

    async def close(self):
        if self.session:
            await self.session.close()

    async def fetch_one(self, platform: str, event_url: str, **extra_params) -> dict:
        """
        Fetch a single event with retry logic and metadata tagging.
        Example extra_params: mode="all", qty=4
        """
        await self._ensure_session()

        params = {
            "username": self.username,
            "password": self.password,
            "platform": platform,
            "event_url": event_url,
        }
        params.update(extra_params)

        started_at = datetime.now(timezone.utc).isoformat()
        t0 = time.perf_counter()

        async with self.semaphore:
            last_exc = None
            for attempt in range(1, self.max_retries + 1):
                try:
                    async with self.session.get(self.base_url, params=params) as resp:
                        status = resp.status
                        resp_text = await resp.text()

                        try:
                            data = await resp.json()  # fast path
                        except Exception:
                            # Non-JSON (should be rare). Return text safely.
                            data = {"_raw_text": resp_text[:2000]}

                        elapsed_ms = int((time.perf_counter() - t0) * 1000)

                        if self.include_metadata:
                            # Wrap into a stable envelope and mark platform origin
                            tagged = {
                                "platform": platform,
                                "event_url": event_url,
                                # include commonly used call options for traceability
                                **({ "mode": extra_params.get("mode") } if "mode" in extra_params else {}),
                                **({ "qty":  extra_params.get("qty")  } if "qty"  in extra_params else {}),
                                "http_status": status,
                                "started_at": started_at,
                                "response_ms": elapsed_ms,
                                "result": data,  # original API payload, untouched
                            }
                            return tagged

                        # Back-compat: return API payload as-is (no tagging)
                        return data

                except asyncio.TimeoutError as e:
                    last_exc = e
                    if attempt == self.max_retries:
                        elapsed_ms = int((time.perf_counter() - t0) * 1000)
                        return self._error_envelope(
                            platform, event_url, started_at, elapsed_ms,
                            "timeout", f"request timed out after {self.timeout.total}s", extra_params
                        )
                    await asyncio.sleep(1)

                except Exception as e:
                    last_exc = e
                    if attempt == self.max_retries:
                        elapsed_ms = int((time.perf_counter() - t0) * 1000)
                        return self._error_envelope(
                            platform, event_url, started_at, elapsed_ms,
                            "network_error", str(e), extra_params
                        )
                    await asyncio.sleep(1)

            # Should not reach here, but just in case:
            elapsed_ms = int((time.perf_counter() - t0) * 1000)
            return self._error_envelope(
                platform, event_url, started_at, elapsed_ms,
                "unknown_error", str(last_exc) if last_exc else "unknown", extra_params
            )

    async def fetch_many(self, jobs: list[dict]) -> list[dict]:
        """
        Fetch many events concurrently.

        jobs = [
            {"platform": "ticketmaster", "event_url": "..."},
            {"platform": "gametime", "event_url": "...", "mode": "all"},
            ...
        ]
        """
        tasks = [self.fetch_one(**job) for job in jobs]
        return await asyncio.gather(*tasks, return_exceptions=False)

    def _error_envelope(
        self,
        platform: str,
        event_url: str,
        started_at: str,
        response_ms: int,
        code: str,
        message: str,
        extra_params: dict,
    ) -> dict:
        """Create a tagged error envelope (never raise to caller)."""
        if self.include_metadata:
            env = {
                "platform": platform,
                "event_url": event_url,
                **({ "mode": extra_params.get("mode") } if "mode" in extra_params else {}),
                **({ "qty":  extra_params.get("qty")  } if "qty"  in extra_params else {}),
                "http_status": 0,
                "started_at": started_at,
                "response_ms": response_ms,
                "error": {"code": code, "message": message},
            }
            return env
        # Back-compat: basic error
        return {"error": {"code": code, "message": message}}
