from .client import TicketsDataClient

__all__ = ["TicketsDataClient"]
__version__ = "1.0.1"
