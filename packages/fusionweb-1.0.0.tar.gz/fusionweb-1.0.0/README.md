# FusionWeb
Framework web HTTP avec routing et gestion d'erreurs.