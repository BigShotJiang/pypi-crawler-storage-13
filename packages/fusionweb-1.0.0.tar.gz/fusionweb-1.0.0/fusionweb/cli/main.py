
import argparse
from fusionweb.core.server.server import server

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    server.run(host=args.host, http_port=args.port, debug=args.debug)
