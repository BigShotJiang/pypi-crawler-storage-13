
import datetime
def log_info(msg): print("[INFO]", datetime.datetime.now().isoformat(), "-", msg)
def log_warn(msg): print("[WARN]", datetime.datetime.now().isoformat(), "-", msg)
def log_error(msg): print("[ERROR]", datetime.datetime.now().isoformat(), "-", msg)
