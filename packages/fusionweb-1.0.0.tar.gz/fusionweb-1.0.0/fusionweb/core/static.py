
from pathlib import Path
import os
from http import HTTPStatus

STATIC_DIR = Path(os.getcwd()) / "static"

def serve_static(h):
    fp = STATIC_DIR / h.path.lstrip("/")
    if not fp.exists():
        h.send_response(HTTPStatus.NOT_FOUND)
        h.end_headers()
        h.wfile.write(b"Not found")
        return
    ext = fp.suffix
    ct = "text/plain"
    if ext == ".css": ct = "text/css"
    if ext == ".js": ct = "application/javascript"
    if ext in [".png",".jpg",".jpeg",".gif"]:
        h.send_response(200)
        h.send_header("Content-Type", "image/"+ext[1:])
        h.end_headers()
        h.wfile.write(fp.read_bytes())
    else:
        h.send_response(200)
        h.send_header("Content-Type", ct)
        h.end_headers()
        h.wfile.write(fp.read_text().encode())
