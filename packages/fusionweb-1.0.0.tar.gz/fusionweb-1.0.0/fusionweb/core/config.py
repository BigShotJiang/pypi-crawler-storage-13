
class Config:
    host = "127.0.0.1"
    debug = False
