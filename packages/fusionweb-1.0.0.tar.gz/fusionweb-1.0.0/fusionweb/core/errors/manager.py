
from pathlib import Path

class ErrorManager:
    def __init__(self):
        self.template = (Path(__file__).parent / "templates/base.html").read_text()

    def render(self, code, message, trace_id):
        return self.template.replace("{{ code }}", str(code)).replace("{{ message }}", message).replace("{{ trace_id }}", trace_id)
