
class Router:
    def __init__(self):
        self.routes = {}

    def route(self, path):
        def deco(f):
            self.routes[path] = f
            return f
        return deco

    def get(self, path):
        return self.routes.get(path)
