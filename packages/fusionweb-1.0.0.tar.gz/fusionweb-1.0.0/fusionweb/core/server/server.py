
from http.server import HTTPServer
import threading, sys
from fusionweb.core.http.handler import MiniServHandler
from fusionweb.core.config import Config
from fusionweb.core.utils.logging import log_info, log_warn, log_error

class MiniServ:
    def __init__(self):
        self.config = Config()
        self.handler_class = MiniServHandler

    def run(self, host="0.0.0.0", http_port=8080, debug=False):
        self.config.host = host
        self.config.debug = debug

        httpd = HTTPServer((host, http_port), self.handler_class)
        log_info(f"🌐 MiniServ HTTP running at http://{host}:{http_port}")

        def start_http(): httpd.serve_forever()

        try:
            threading.Thread(target=start_http, daemon=True).start()
            if debug: log_info("🔧 Debug mode enabled (CTRL+C to stop)")
            while True: pass
        except KeyboardInterrupt:
            log_warn("🛑 Serveur arrêté")
            httpd.server_close()
            sys.exit(0)
        except Exception as e:
            log_error(f"Erreur fatale: {e}")
            httpd.server_close()
            sys.exit(1)

server = MiniServ()
