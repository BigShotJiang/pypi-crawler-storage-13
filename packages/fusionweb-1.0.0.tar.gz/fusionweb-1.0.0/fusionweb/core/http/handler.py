
from http.server import BaseHTTPRequestHandler
from fusionweb.core.router.router import Router
from fusionweb.core.errors.manager import ErrorManager
from fusionweb.core.static import serve_static
import traceback, uuid

class MiniServHandler(BaseHTTPRequestHandler):
    router = Router()
    errors = ErrorManager()

    def do_GET(self):
        try:
            if self.path.startswith("/static/"):
                serve_static(self)
                return

            f = self.router.get(self.path)
            if not f:
                self.send_error_page(404, "Ressource non trouvée")
                return

            r = f()
            if not isinstance(r, str):
                self.send_error_page(500, "Réponse invalide")
                return

            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(r.encode())
        except Exception:
            self.send_error_page(500, "Erreur interne")

    def send_error_page(self, code, msg):
        tid = str(uuid.uuid4())
        html = self.errors.render(code, msg, tid)
        self.send_response(code)
        self.send_header("Content-Type","text/html")
        self.end_headers()
        self.wfile.write(html.encode())
