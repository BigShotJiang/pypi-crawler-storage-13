"""Mia21 Python SDK - Official client for Mia21 Chat API."""

from .client import Mia21Client, ResponseMode, VoiceConfig
from .models import ChatMessage, Space, Tool, ToolCall, StreamEvent
from .exceptions import Mia21Error, ChatNotInitializedError, APIError

__version__ = "1.3.3"  # Focused on api.mia21.com integration endpoints
__all__ = [
    "Mia21Client",
    "ResponseMode",
    "VoiceConfig",
    "ChatMessage",
    "Space",
    "Tool",
    "ToolCall",
    "StreamEvent",
    "Mia21Error",
    "ChatNotInitializedError",
    "APIError"
]


