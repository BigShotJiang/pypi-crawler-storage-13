"""SSB Libtest8."""
