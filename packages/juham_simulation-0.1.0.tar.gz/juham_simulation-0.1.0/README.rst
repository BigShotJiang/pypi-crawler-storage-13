Simulation plugin for Juham™
============================

Description
-----------

Plugin with simulated sensors.


Install
---------------

1. Install 

   .. code-block:: bash

      pip install juham-simulation

      
2. Configure

To configure edit the `*.json` configuration files to match your network and
desired reading frequency in seconds.

   .. code-block:: python

      {
	"update_interval": 60
      }

