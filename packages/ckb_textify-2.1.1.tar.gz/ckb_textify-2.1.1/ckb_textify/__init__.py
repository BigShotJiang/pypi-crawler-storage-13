# ckb_textify/__init__.py

# --- 1. Import dependencies ---
from .number_to_text import number_to_kurdish_text
from .decimal_handler import decimal_to_kurdish_text
from .normalizer import normalize_characters, normalize_digits
from .date_time import date_to_kurdish_text, time_to_kurdish_text
from .currency import currency_to_kurdish_text
from .percentage import percentage_to_kurdish_text
from .math_operations import normalize_math_expressions
from .symbols import normalize_common_symbols
from .units import (
    normalize_units,
    normalize_per_rule,
    normalize_standalone_units
)
from .abbreviations import normalize_abbreviations
from .phone_numbers import normalize_phone_numbers
from .arabic_names import normalize_arabic_names
from .technical import normalize_technical
from .web import normalize_web
from .latin import normalize_latin
from .config import DEFAULT_CONFIG

# --- 2. Import main ---
from .sentence_normalizer import normalize_sentence_kurdish, convert_all

# --- 3. Public ---
__all__ = [
    "date_to_kurdish_text",
    "time_to_kurdish_text",
    "normalize_sentence_kurdish",
    "number_to_kurdish_text",
    "currency_to_kurdish_text",
    "percentage_to_kurdish_text",
    "normalize_math_expressions",
    "normalize_common_symbols",
    "normalize_units",
    "normalize_per_rule",
    "normalize_standalone_units",
    "normalize_abbreviations",
    "normalize_phone_numbers",
    "normalize_arabic_names",
    "normalize_technical",
    "normalize_web",
    "normalize_latin",
    "DEFAULT_CONFIG",
    "convert_all",
]