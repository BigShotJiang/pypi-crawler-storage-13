from typing import List

from llama_index.core.response_synthesizers import TreeSummarize
from llama_index.llms.openai import OpenAI
from llama_index.llms.openai_like import OpenAILike
from pydantic import BaseModel, Field

class DocumentSummary(BaseModel):
    """Step-by-step, identify the main content of the following document, including the main plot, characters, and themes. Then summarize the entire text into 1 to 3 paragraphs.
    The summary will be used to categorization. It's therefore important to include details that might separate this document from others."""

    summary: str = Field(description=("Step-by-step, identify the main content of the following document, including the main plot, characters, and themes. Then summarize the entire text into 1 to 3 paragraphs.\n"
              "The summary will be used to categorization. It's therefore important to include details that might separate this document from others."))
    keywords: List[str] = Field(description="Keywords extracted from the document")

def main():
    filename = "/mnt/storage/data/knowledge/textfiles_sample/sex/C/2cindy.txt"
    with open(filename, "r") as f:
        text = f.read()

    llm = OpenAI(api_base="http://localhost:8000", api_key="sk-123", model="gpt-4-turbo")

    summarizer = TreeSummarize(verbose=True, llm=llm)

    prompt = ("Step-by-step, identify the main content of the following document, including the main plot, characters, and themes. Then summarize the entire text into 1 to 3 paragraphs.\n"
              "The summary will be used to categorization. It's therefore important to include details that might separate this document from others.")

    response = summarizer.get_response(prompt, [text])

    print(response)


if __name__ == '__main__':
    main()
