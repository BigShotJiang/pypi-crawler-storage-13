# crsgame

An object-oriented wrapper for the Python curses library.

## Installation

```
pip install crsgame
```

## Example

```
import curses
from crsgame import Renderer, Color, Vector, Box

def main(stdscr):
    r = Renderer(stdscr, fps=15)

    r.RegisterColor("white", Color("white"))

    obj = Box(Vector(5, 5), Vector(2, 2), True, "#", "white")

    def loop(deltaTime):
        r.Render([box])
    r.RenderStep.Connect(loop)

    r.Run()

curses.wrapper(main)
```

## Features

- Object-oriented curses API
- Automatic delta rendering
- Shapes, colors, input handling
- Asynchronous game loop support

## Links

PyPI: https://pypi.org/project/crsgame
