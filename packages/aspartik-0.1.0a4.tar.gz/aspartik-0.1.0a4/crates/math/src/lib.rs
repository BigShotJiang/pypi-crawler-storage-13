#![forbid(unsafe_code)]

pub mod consts;
pub mod float;
pub mod function;
pub mod tolerance;

#[cfg(feature = "python")]
use pyo3::prelude::*;

#[cfg(feature = "python")]
pub fn pymodule(py: Python) -> PyResult<Bound<PyModule>> {
	use util::py_make_submodule;
	let m = py_make_submodule!(py, "_math_rust_impl");

	use function::erf::*;
	m.add_function(wrap_pyfunction!(erf, &m)?)?;
	m.add_function(wrap_pyfunction!(erf_inv, &m)?)?;
	m.add_function(wrap_pyfunction!(erfc, &m)?)?;
	m.add_function(wrap_pyfunction!(erfc_inv, &m)?)?;

	use function::exponential::*;
	m.add_function(wrap_pyfunction!(ei, &m)?)?;

	use function::factorial::*;
	m.add_function(wrap_pyfunction!(factorial, &m)?)?;
	m.add_function(wrap_pyfunction!(ln_factorial, &m)?)?;
	m.add_function(wrap_pyfunction!(binomial, &m)?)?;
	m.add_function(wrap_pyfunction!(ln_binomial, &m)?)?;

	use function::gamma::*;
	m.add_function(wrap_pyfunction!(gamma, &m)?)?;
	m.add_function(wrap_pyfunction!(ln_gamma, &m)?)?;
	m.add_function(wrap_pyfunction!(gamma_ui, &m)?)?;
	m.add_function(wrap_pyfunction!(gamma_li, &m)?)?;
	m.add_function(wrap_pyfunction!(gamma_ur, &m)?)?;
	m.add_function(wrap_pyfunction!(gamma_lr, &m)?)?;
	m.add_function(wrap_pyfunction!(digamma, &m)?)?;
	m.add_function(wrap_pyfunction!(digamma_inv, &m)?)?;

	use function::harmonic::*;
	m.add_function(wrap_pyfunction!(harmonic, &m)?)?;
	m.add_function(wrap_pyfunction!(generalized_harmonic, &m)?)?;

	use function::logistic::*;
	m.add_function(wrap_pyfunction!(logistic, &m)?)?;
	m.add_function(wrap_pyfunction!(logit, &m)?)?;

	m.add_function(wrap_pyfunction!(tolerance::is_close, &m)?)?;

	use float::*;
	m.add_function(wrap_pyfunction!(sign, &m)?)?;
	m.add_function(wrap_pyfunction!(exponent, &m)?)?;
	m.add_function(wrap_pyfunction!(exponent_bits, &m)?)?;
	m.add_function(wrap_pyfunction!(mantissa, &m)?)?;
	m.add_function(wrap_pyfunction!(mantissa_bits, &m)?)?;

	Ok(m)
}
