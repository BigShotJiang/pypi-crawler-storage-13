mod function;
