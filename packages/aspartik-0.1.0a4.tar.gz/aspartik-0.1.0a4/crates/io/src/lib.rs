#[cfg(feature = "python")]
mod fasta;
pub mod rw;
pub mod sam;

#[cfg(feature = "python")]
use pyo3::prelude::*;

#[cfg(feature = "python")]
pub fn pymodule(py: Python) -> PyResult<Bound<PyModule>> {
	use util::py_make_submodule;
	let m = py_make_submodule!(py, "_io_rust_impl");

	m.add_class::<fasta::PyFastaDnaReader>()?;

	Ok(m)
}
