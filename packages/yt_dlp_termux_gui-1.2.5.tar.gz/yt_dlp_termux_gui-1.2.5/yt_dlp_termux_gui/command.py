import json
import logging
import os
import subprocess
import threading
from typing import Any, Literal

import termuxgui as tg

from . import settings, utils, utils_gui


def get_metadata(
    url: str,
) -> dict[Literal["thumbnail_url", "title", "uploader", "duration"], str]:
    result = subprocess.run(
        ["yt-dlp", "--skip-download", "--dump-json", url],
        capture_output=True,
        text=True,
    )

    return json.loads(result.stdout)


def prepare(output_dir: str, cookies_file: str, additional_args: list):
    output_dir = os.path.expanduser(output_dir or settings.defaults["Output Directory"])
    cookies_file = os.path.expanduser(
        cookies_file or settings.defaults["Cookies File (optional)"]
    )

    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(os.path.dirname(cookies_file), exist_ok=True)

    cmd = []

    if additional_args != []:
        cmd.extend(additional_args)

    cmd.extend(["--cookies", cookies_file])

    return {"args": cmd, "output_dir": output_dir}


def run_yt_dlp(
    config_inputs: dict[str, Any],
    config_checkboxes: dict[str, bool],
    logs_activity: tg.Activity,
    status_container: tg.LinearLayout,
    logger: logging.Logger,
):
    video_url = config_inputs["Media URL"]
    output_dir = config_inputs["Output Directory"]
    filename_template = config_inputs["Filename Template"].split(" ")
    start_time = config_inputs["Start Time (optional)"]
    end_time = config_inputs["End Time (optional)"]
    cookies_file = config_inputs["Cookies File (optional)"]
    additional_args: list[str] = config_inputs["Additional Arguments"].split(" ")

    enable_logs = config_checkboxes["Verbose Logging"]
    force_keyframes = config_checkboxes["Force Keyframes at Cuts"]

    if not video_url:
        utils_gui.append_text(
            logger,
            logs_activity,
            status_container,
            "error",
            "Error: No video URL provided",
        )
        return

    cmd: list = ["yt-dlp"]
    cmd_prepare = prepare(output_dir, cookies_file, additional_args)

    output_dir: str = cmd_prepare["output_dir"]
    is_default_timestamps = (
        start_time == settings.defaults["Start Time (optional)"]
        and end_time == settings.defaults["End Time (optional)"]
    )

    if enable_logs:
        cmd.append("--verbose")
    if force_keyframes and not is_default_timestamps:
        cmd.append("--force-keyframes-at-cuts")
    if start_time and end_time and not is_default_timestamps:
        cmd.extend(["--download-sections", f"{start_time}-{end_time}"])

    cmd.extend(cmd_prepare["args"])
    cmd.extend(["-o", f"{output_dir}/${filename_template}"])
    cmd.append(video_url)

    utils_gui.append_text(
        logger, logs_activity, status_container, f"Running command:\n{' '.join(cmd)}"
    )

    def _run():
        try:
            utils_gui.append_text(
                logger, logs_activity, status_container, "\nRunning...\n"
            )

            def on_stdout(line: str):
                utils_gui.append_text(
                    logger, logs_activity, status_container, line.strip()
                )

            errors = utils.run_cli_command(cmd, on_stdout)
            if errors:
                utils_gui.append_text(
                    logger,
                    logs_activity,
                    status_container,
                    f"\nCompleted with error(s):\n{errors}",
                )
            else:
                utils_gui.append_text(
                    logger, logs_activity, status_container, "\nCompleted."
                )
        except Exception as e:
            utils_gui.append_text(
                logger,
                logs_activity,
                status_container,
                f"Failed to run yt-dlp: {str(e)}",
            )

    threading.Thread(target=_run).start()
