import logging
import sys
import threading

import termuxgui as tg

from . import utils


def display_toast(
    connection: tg.Connection,
    message: str = None,
    long: bool = False,
):
    connection.toast(message or "", long)


def print_error_toast(
    logger: logging.Logger, connection: tg.Connection, message: str = None
):
    verbose = not logger.disabled
    display_toast(
        connection,
        f"An error occurred{verbose and ' (check Termux logs)' or ''}"
        if message is None
        else message,
    )


def print_event_error(
    error: Exception,
    logger: logging.Logger,
    connection: tg.Connection,
    event_name: str,
    message: str = None,
):
    msg = (
        f"GUI Event '{event_name}' error: {str(error)}" if message is None else message
    )
    utils.print_msg(logger, msg, "error")
    print_error_toast(logger, connection)


def get_logger(disable: bool = False):
    level = utils.get_logger_level()
    gui_logger = utils.create_logger(level)
    if disable:
        gui_logger.disabled = True
    return gui_logger


def append_text(
    logger: logging.Logger,
    activity: tg.Activity,
    status_container: tg.LinearLayout,
    message: str,
):
    def create_log():
        threadlock = threading.Lock()
        with threadlock:
            timestamp = utils.get_timestamp()
            try:
                formatted_message = f"[{timestamp}] {message}"
                logger.info(formatted_message)
                text_view = tg.TextView(
                    activity,
                    formatted_message,
                    status_container,
                    selectabletext=True,
                    clickablelinks=True,
                )
                text_view.settextsize(15)
                text_view.setmargin(10, "bottom")
                text_view.setclickable(True)
            except Exception as e:
                logger.error(f"[{timestamp}] Failed to append log: {str(e)}")

    threading.Thread(target=create_log, daemon=True).start()


def get_thumbnail_view(
    activity: tg.Activity, parent: tg.View | None, url: str
) -> tg.ImageView:
    from .assets import get_image_bytes

    img = get_image_bytes(url, "thumbnail")
    thumbnail_view = tg.ImageView(activity, parent)
    thumbnail_view.setimage(img)
    thumbnail_view.setbackgroundcolor(0)
    return thumbnail_view


def handle_lifecycle_events(
    logger: logging.Logger, connection: tg.Connection, event: tg.Event
):
    if event.type == tg.Event.create:
        try:
            utils.print_msg(logger, "Starting GUI...")
        except Exception as e:
            print_event_error(e, logger, connection, "create")

    if event.type == tg.Event.start:
        try:
            utils.print_msg(logger, "GUI gained focus")
        except Exception as e:
            print_event_error(e, logger, connection, "start")

    if event.type == tg.Event.resume:
        try:
            utils.print_msg(logger, "GUI is active")
        except Exception as e:
            print_event_error(e, logger, connection, "resume")

    if event.type == tg.Event.pause:
        try:
            utils.print_msg(logger, "GUI is inactive")
        except Exception as e:
            print_event_error(e, logger, connection, "pause")

    if event.type == tg.Event.stop:
        try:
            utils.print_msg(logger, "GUI lost focus")
        except Exception as e:
            print_event_error(e, logger, connection, "stop")

    if event.type == tg.Event.destroy:
        try:
            utils.print_msg(logger, "GUI was destroyed")
            if event.value["finishing"]:
                logging.shutdown()
                sys.exit()
        except Exception as e:
            print_event_error(e, logger, connection, "destroy")

    if event.type == tg.Event.userleavehint:
        try:
            utils.print_msg(logger, "User hints to go back")
        except Exception as e:
            print_event_error(e, logger, connection, "userleavehint")

    if event.type == tg.Event.pipchanged:
        try:
            utils.print_msg(logger, "Picture-in-picture mode changed")
        except Exception as e:
            print_event_error(e, logger, connection, "pipchanged")

    if event.type == tg.Event.config:
        try:
            utils.print_msg(logger, "State changed")
        except Exception as e:
            print_event_error(e, logger, connection, "config")

    if event.type == tg.Event.back:
        try:
            utils.print_msg(logger, "User pressed back")
        except Exception as e:
            print_event_error(e, logger, connection, "back")
