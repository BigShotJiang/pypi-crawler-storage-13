import logging
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from typing import Callable, Literal

import requests

from . import assets, constants, settings


def parse_version(v):
    m = constants.VERSION_REGEX.match(v)
    if not m:
        raise ValueError(f"Cannot parse version {v!r}")

    g = m.groupdict(default="0")

    # Normalized tuple for comparison
    return (
        int(g["major"]),
        int(g["minor"]),
        int(g["patch"]),
        # Pre-releases sort before releases: a < b < rc < final
        {"0": 3, "a": 0, "b": 1, "rc": 2}[g["pre_type"]],
        int(g["pre_num"]),
        int(g["dev"]),
        int(g["post"]),
    )


def check_for_updates(
    existing_settings: dict, update_settings: bool = True, force: bool = False
):
    last_update_check_unix = existing_settings.get("last_update_check_unix", 0)
    current_unix_time = int(datetime.now(timezone.utc).timestamp())
    unix_diff = current_unix_time - last_update_check_unix
    can_check = unix_diff >= constants.UPDATE_CHECK_INTERVAL

    def auto_save_settings():
        if update_settings or force:
            existing_settings["last_update_check_unix"] = current_unix_time
            settings.save_settings(existing_settings)

    if not can_check:
        return False

    current_ver: str = None
    latest_ver: str = None
    current_ver_parsed: tuple[int, int, int, int, int, int, int] = None
    latest_ver_parsed: tuple[int, int, int, int, int, int, int] = None

    try:
        pkg = "yt-dlp-termux-gui"
        current_ver = constants.METADATA.get("version")
        latest_ver = requests.get(f"https://pypi.org/pypi/{pkg}/json").json()["info"][
            "version"
        ]
        current_ver_parsed = parse_version(current_ver)
        latest_ver_parsed = parse_version(latest_ver)
    except Exception:
        auto_save_settings()
        return False

    auto_save_settings()

    if latest_ver_parsed > current_ver_parsed:
        return latest_ver

    return False


def get_timestamp():
    return datetime.now().strftime("%H:%M:%S")


def print_msg(
    logger: logging.Logger,
    message: str,
    level: Literal["debug", "info", "warning", "error", "critical"] = "debug",
):
    logger = getattr(logger, level, "debug")
    logger(f"[{get_timestamp()}] {message}")


def run_cli_command(
    cmd: list[str],
    on_stdout: Callable[[str], None] = lambda x: None,
    on_stderr: Callable[[str], None] = lambda x: None,
):
    errors = ""
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
    )
    if proc.stdout and on_stdout:
        for line in proc.stdout:
            on_stdout(line.strip())
    if proc.stderr and on_stderr:
        for line in proc.stderr:
            on_stderr(line.strip())
            errors += f"{line.strip()}\n"
    proc.wait()

    return errors


def run_cli_command_simple(cmd: list[str], cwd: str = None, silent: bool = False):
    stdout_value = subprocess.DEVNULL if silent else None
    subprocess.run(cmd, check=True, cwd=cwd, stdout=stdout_value)


def get_cli_option_value(
    options: list[str],
    option: str,
    default: list[str] = None,
    allowed_values: list[str] = None,
) -> str:
    value = default
    try:
        index = options.index(option)
        value = options[index + 1]
    except ValueError:
        pass
    if allowed_values and value not in allowed_values:
        raise ValueError(
            f"Invalid value for '{option}' option: '{value}'. Allowed values: {', '.join(allowed_values)}."
        )
    return value


def init_logger():
    logging.basicConfig(level=logging.DEBUG, format="%(message)s")


def get_logger_level():
    level = "debug"
    args = sys.argv[1:]
    options = [s for s in args if s.startswith("-")]
    silent = options.count("--silent") != 0

    if silent:
        level = "silent"
    elif options.count("--verbose"):
        level = get_cli_option_value(
            options,
            "--verbose",
            "debug",
            ["silent", "debug", "info", "warning", "error", "critical"],
        )

    return level


def create_logger(
    level: Literal["silent", "debug", "info", "warning", "error", "critical"] = "debug",
) -> logging.Logger:
    logger = logging.getLogger("yt-dlp-termux-gui")

    logger_level = level.upper()
    logger.setLevel(
        getattr(logging, logger_level if logger_level != "SILENT" else "DEBUG")
    )

    if logger_level == "SILENT":
        logger.disabled = True

    logger.addHandler(logging.NullHandler(logger.level))

    return logger


def get_dir_tree(path: str) -> list[str]:
    if not os.path.exists(path):
        return []
    if not os.path.isdir(path):
        return [path]
    tree = []
    for root, dirs, files in os.walk(path):
        for dir in dirs:
            tree.append(os.path.join(root, dir))
        for file in files:
            tree.append(os.path.join(root, file))
    return tree


def assign_permissions_to_path(path: str, mode: Literal["600", "700"] = "600"):
    perm_mode: int = 0o600 if mode == "600" else 0o700
    file_tree = get_dir_tree(path)
    for file in file_tree:
        os.chmod(file, perm_mode)


def is_valid_url(url: str) -> bool:
    url_pattern = re.compile(
        r"^(https?://)?"  # optional http or https
        r"(([A-Za-z0-9-]+\.)+[A-Za-z]{2,})"  # domain (example.com)
        r"(:\d+)?"  # optional port
        r"(/[\w\-.~:/?#[\]@!$&\'()*+,;%=]*)?$"  # optional path/query
    )
    return bool(url_pattern.match(url))


def ensure_termux_env_variables() -> bool | dict[str, str]:
    home_path = os.environ.get("HOME")
    prefix_path = os.environ.get("PREFIX")
    if not home_path.startswith(constants.TERMUX_HOME) or not prefix_path.startswith(
        constants.TERMUX_PREFIX
    ):
        return False
    return {"HOME": home_path, "PREFIX": prefix_path}


def detect_termux() -> bool:
    print("\nEnsuring platform...")
    termux_env_variables = ensure_termux_env_variables()
    if not termux_env_variables:
        return False
    return termux_env_variables["PREFIX"].startswith(constants.TERMUX_PREFIX)


def ensure_ytdlp():
    print("\nEnsuring yt-dlp...")
    run_cli_command_simple(["pip", "install", "yt-dlp"])


def ensure_ffmpeg():
    try:
        print("\nEnsuring ffmpeg...")
        run_cli_command_simple(["ffmpeg", "-version"], silent=True)
        print("ffmpeg is already installed. Skipping...")
    except subprocess.CalledProcessError:
        print("ffmpeg not installed. Installing...")
        run_cli_command_simple(["pkg", "install", "ffmpeg"])


def ensure_git():
    try:
        print("\nEnsuring git...")
        run_cli_command_simple(["git", "--version"], silent=True)
        print("Git is already installed. Skipping...")
    except subprocess.CalledProcessError:
        print("Git not installed. Installing...")
        run_cli_command_simple(["pkg", "update", "-y"])
        run_cli_command_simple(["pkg", "install", "git", "-y"])


def ensure_curl():
    try:
        print("\nEnsuring curl...")
        run_cli_command_simple(["curl", "--version"], silent=True)
        print("curl is already installed. Skipping...")
    except subprocess.CalledProcessError:
        print("Curl not installed. Installing...")
        run_cli_command_simple(["pkg", "update", "-y"])
        run_cli_command_simple(["pkg", "install", "curl", "-y"])


def ensure_curl_impersonate(force: bool = False):
    print("\nEnsuring curl-impersonate...")

    result = subprocess.run(
        ["ls", f"{constants.TERMUX_PREFIX}/lib"], capture_output=True, text=True
    )

    files = [
        "libcurl-impersonate-chrome.so",
        "libcurl-impersonate-chrome.so.4",
        "libcurl-impersonate-chrome.so.4.8.0",
        "libcurl-impersonate.so",
        "libcurl-impersonate.so.4",
        "libcurl-impersonate.so.4.8.0",
    ]

    exists = result.stdout.find("\n".join(files)) != -1
    if exists and not force:
        print("curl-impersonate is already installed. Skipping...")
        return
    elif exists and force:
        print("curl-impersonate is already installed. Overwriting...")
    else:
        print("curl-impersonate not installed. Installing...")

    install_dir = f"{constants.TERMUX_PREFIX}/curl-impersonate-android"
    curl_dir = f"{constants.TERMUX_PREFIX}/include/curl"
    lib_dir = f"{constants.TERMUX_PREFIX}/lib"

    if os.path.exists(install_dir):
        try:
            shutil.rmtree(install_dir)
        except Exception as e:
            print(f"Error removing {install_dir}: {str(e)}")

    if exists and force:
        try:
            if os.path.exists(curl_dir):
                print("Removing old include/curl...")
                shutil.rmtree(curl_dir)
                if os.path.exists(curl_dir):
                    os.rmdir(curl_dir)
            for file in files:
                lib_file = f"{lib_dir}/{file}"
                if os.path.exists(lib_file):
                    print(f"Removing old lib/{file}...")
                    os.remove(lib_file)
        except Exception as e:
            print(f"Error removing old binaries: {str(e)}")

    run_cli_command_simple(
        [
            "git",
            "clone",
            "https://github.com/T0chi/curl-impersonate-android.git",
            install_dir,
        ]
    )

    try:
        install_dir_shortened = install_dir.replace(constants.TERMUX_PREFIX, "")
        curl_dir_shortened = curl_dir.replace(constants.TERMUX_PREFIX, "")
        lib_dir_shortened = install_dir.replace(constants.TERMUX_PREFIX, "")
        os.makedirs(curl_dir, exist_ok=True)
        os.makedirs(lib_dir, exist_ok=True)
        print(
            f"Copying {install_dir_shortened}/include/curl to {curl_dir_shortened}..."
        )
        shutil.copytree(f"{install_dir}/include/curl", curl_dir, dirs_exist_ok=True)
        print(f"Copying {install_dir_shortened}/lib files to {lib_dir_shortened}...")
        for file in files:
            lib_file_src = f"{install_dir}/lib/{file}"
            lib_file_dest = f"{lib_dir}/{file}"
            lib_file_src_shortened = f"{install_dir_shortened}/lib/{file}"
            if os.path.exists(lib_file_src) and not os.path.exists(lib_file_dest):
                print(f"Copying {lib_file_src_shortened}...")
                shutil.copyfile(lib_file_src, lib_file_dest)
            elif not os.path.exists(lib_file_src):
                print(f"File {lib_file_src_shortened} not found. Skipping...")
        print("curl-impersonate installed successfully!")
    except Exception as e:
        print(f"Error copying curl-impersonate files: {str(e)}")

    try:
        shutil.rmtree(install_dir)
        if os.path.exists(install_dir):
            os.rmdir(install_dir)
    except Exception as e:
        print(f"Error removing curl-impersonate-android folder: {str(e)}")


def ensure_curl_cffi():
    print("\nEnsuring curl_cffi...")
    run_cli_command_simple(["pip", "install", "curl_cffi"])


def ensure_termux_api():
    print("\nEnsuring termux-api...")
    run_cli_command_simple(["pip", "install", "termux-api"])


def ensure_termuxgui():
    print("\nEnsuring termuxgui...")
    run_cli_command_simple(["pip", "install", "termuxgui"])


def ensure_termux_widget(force: bool = False, task: bool = False):
    shortcut_path = os.path.join(
        constants.TERMUX_WIDGETS_DIR, constants.WIDGET_SCRIPT_NAME
    )
    shortcut_task_path = os.path.join(
        constants.TERMUX_WIDGETS_TASKS_DIR, constants.WIDGET_SCRIPT_NAME
    )
    shortcut_icon_path = f"{os.path.join(constants.TERMUX_WIDGETS_ICONS_DIR, constants.WIDGET_SCRIPT_NAME)}.png"

    shortcut_file_exists = os.path.exists(shortcut_path)
    shortcut_task_file_exists = os.path.exists(shortcut_task_path)
    shortcut_icon_file_exists = os.path.exists(shortcut_icon_path)

    if task and shortcut_task_file_exists and shortcut_icon_file_exists and not force:
        return False

    if not task and shortcut_file_exists and shortcut_icon_file_exists and not force:
        return False

    if task:
        shortcut_path = shortcut_task_path
        shortcut_file_exists = shortcut_task_file_exists

    for p in [
        constants.TERMUX_WIDGETS_DIR,
        constants.TERMUX_WIDGETS_ICONS_DIR,
        constants.TERMUX_WIDGETS_TASKS_DIR,
    ]:
        try:
            os.makedirs(p, exist_ok=True)
        except Exception as e:
            print(f"Error setting permissions for {p}: {str(e)}")

    assign_permissions_to_path(constants.TERMUX_WIDGETS_DIR, "700")

    if not shortcut_file_exists or force:
        shortcut_content = """#!"""
        shortcut_content += f"{constants.TERMUX_PREFIX}/bin/sh"
        shortcut_content += "\n\nyt-dlp-termux-gui launch\n"

        try:
            with open(shortcut_path, "w") as f:
                f.write(shortcut_content)
        except Exception as e:
            print(f"Error writing {shortcut_path}: {str(e)}")

    if not shortcut_icon_file_exists or force:
        try:
            assets.copy_resource(
                f"icons/{constants.WIDGET_SCRIPT_NAME}.png", shortcut_icon_path
            )
        except Exception as e:
            print(f"Error copying resource {shortcut_icon_path}: {str(e)}")
    return True


def ensure_packages(force: bool = False):
    ensure_git()
    ensure_curl()
    ensure_curl_impersonate(force)
    ensure_ffmpeg()
    ensure_ytdlp()
    ensure_curl_cffi()
    ensure_termux_api()
    ensure_termuxgui()
