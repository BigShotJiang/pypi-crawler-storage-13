import importlib.metadata as lib_metadata
import os
import re

PACKAGE_NAME = "yt-dlp-termux-gui"

METADATA = lib_metadata.metadata(PACKAGE_NAME)

PYPI_PROJECT_URL = f"https://pypi.org/project/{PACKAGE_NAME}"
GITHUB_REPO_URL = f"https://github.com/tochiResources/{PACKAGE_NAME}"

TERMUX_PACKAGE_DIR = "/data/data/com.termux"
TERMUX_HOME = f"{TERMUX_PACKAGE_DIR}/files/home"
TERMUX_PREFIX = f"{TERMUX_PACKAGE_DIR}/files/usr"

PACKAGE_CONFIG_DIR = os.path.expanduser("~/.config/yt_dlp_termux_gui").replace(
    "\\", "/"
)

SETTINGS_PATH = f"{PACKAGE_CONFIG_DIR}/settings.json"
SETTINGS_DIR = os.path.dirname(SETTINGS_PATH).replace("\\", "/")

TERMUX_CURL_IMPERSONATE_DIR = os.path.expanduser("~/curl-impersonate-android").replace(
    "\\", "/"
)

TERMUX_WIDGETS_DIR = os.path.expanduser("~/.shortcuts").replace("\\", "/")
TERMUX_WIDGETS_ICONS_DIR = os.path.join(TERMUX_WIDGETS_DIR, "icons").replace("\\", "/")
TERMUX_WIDGETS_TASKS_DIR = os.path.join(TERMUX_WIDGETS_DIR, "tasks").replace("\\", "/")

WIDGET_TITLE = "YT-DLP TERMUX GUI"
WIDGET_SCRIPT_NAME = "yt-dlp-gui.sh"

FILENAME_TEMPLATE = [
    "%(uploader).30B",
    "-",
    "%(title)s",
    "(%(extractor)s)",
    "[%(upload_date>%Y-%m-%d)s].%(ext)s",
]

ADDITIONAL_ARGS_TEMPLATE = [
    "-N",
    "3",
    "--retries",
    "3",
    "--fragment-retries",
    "3",
    "--restrict-filenames",
    "--embed-metadata",
    "--embed-thumbnail",
    "--impersonate",
    "Chrome-99",
    "--no-overwrites",
    "--no-post-overwrites",
]

# in seconds
UPDATE_CHECK_INTERVAL = int(86400 / 2)

VERSION_REGEX = re.compile(
    r"""
    ^\s*
    (?P<major>\d+)
    (?:\.(?P<minor>\d+))?
    (?:\.(?P<patch>\d+))?
    (?:
        (?P<pre_type>a|b|rc)
        (?P<pre_num>\d+)
    )?
    (?:\.?dev(?P<dev>\d+))?
    (?:\.?post(?P<post>\d+))?
    \s*$
    """,
    re.VERBOSE,
)
