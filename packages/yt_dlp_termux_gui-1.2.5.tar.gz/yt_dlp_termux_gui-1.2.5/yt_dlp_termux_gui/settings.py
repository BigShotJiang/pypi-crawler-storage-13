import json
import os

from . import constants, utils

defaults = {
    "Media URL": "https://example.com/video",
    "Output Directory": "~/storage/downloads",
    "Filename Template": constants.FILENAME_TEMPLATE,
    "Start Time (optional)": "*00:00",
    "End Time (optional)": "inf",
    "Cookies File (optional)": os.path.join(constants.SETTINGS_DIR, "cookies.txt"),
    "Additional Arguments": constants.ADDITIONAL_ARGS_TEMPLATE,
    "Force Keyframes at Cuts": True,
    "Verbose Logging": False,
    "Check for Updates at Startup": True,
    "last_update_check_unix": 0,
}


def load_settings(with_defaults: bool = True, key: str = None) -> dict:
    utils.assign_permissions_to_path(constants.PACKAGE_CONFIG_DIR)
    if os.path.exists(constants.SETTINGS_PATH):
        with open(constants.SETTINGS_PATH, "r") as f:
            existing_settings: dict = json.load(f)
            if not with_defaults:
                if key:
                    return existing_settings.get(key, None)
                return existing_settings
            settings_with_defaults: dict = {}
            for k, v in existing_settings.items():
                settings_with_defaults[k] = v
            settings_with_defaults_list = list(settings_with_defaults)
            for k, v in defaults.items():
                if k not in settings_with_defaults_list:
                    settings_with_defaults[k] = v
            if key:
                return settings_with_defaults.get(key, None)
            return settings_with_defaults
    if not with_defaults:
        return {}
    if key:
        return defaults.get(key, None)
    return defaults


def save_settings(existing_settings: dict):
    utils.assign_permissions_to_path(constants.PACKAGE_CONFIG_DIR)
    settings_dir = os.path.dirname(constants.SETTINGS_PATH)
    os.makedirs(settings_dir, exist_ok=True)
    updated_settings = {label: value for label, value in existing_settings.items()}
    updated_settings.pop("Media URL", None)
    with open(constants.SETTINGS_PATH, "w") as f:
        json.dump(updated_settings, f, indent=2)


def reset_settings():
    save_settings(defaults)
