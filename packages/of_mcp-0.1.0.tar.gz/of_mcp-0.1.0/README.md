# MCP Gateway CLI# MCP Gateway CLI



> Enterprise-grade Model Context Protocol management for Claude DesktopCommand-line tool for managing MCP Gateway workspaces, backends, and agents.



[![PyPI version](https://badge.fury.io/py/mcpgw.svg)](https://pypi.org/project/mcpgw/)## Installation

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

### pip (Python)

The `mcpgw` CLI helps you manage MCP servers, workspaces, and configurations for Claude Desktop with enterprise security features.```bash

pip install mcpgw

## 🚀 Quick Start```



### One-liner Installation### Homebrew (macOS/Linux)

```bash

```bash# Add tap

curl -fsSL https://get.mcpgw.io | shbrew tap orangefennec/tap

```

# Install

### Alternative Installation Methodsbrew install mcpgw

```

<details>

<summary><b>📦 pip (Python Package Manager)</b></summary>### From source

```bash

```bashcd cli

pip install mcpgwpip install -e .

``````



Requirements: Python 3.9+## Quick Start



</details>### 1. Login

```bash

<details>mcpgw auth login

<summary><b>🍺 Homebrew (macOS/Linux)</b></summary># Enter your email and password

```

```bash

# Add the tap (first time only)### 2. List Workspaces

brew tap orangefennec/mcpgw```bash

mcpgw workspace list

# Install```

brew install mcpgw

### 3. Create Workspace

# Update```bash

brew upgrade mcpgwmcpgw workspace create --name "Production"

``````



</details>### 4. Add Backend

```bash

<details>mcpgw backend add WORKSPACE_ID --name "Gmail" --url "http://gmail-mcp:9000"

<summary><b>💻 From Source</b></summary>```



```bash### 5. Create Agent

git clone https://github.com/orangefennec/mcp-gateway.git```bash

cd mcp-gateway/climcpgw agent create WORKSPACE_ID --name "My Agent"

pip install -e .# Save the API key shown!

``````



</details>## Commands



## 📚 Usage### Authentication

```bash

### Authenticationmcpgw auth login              # Login

mcpgw auth logout             # Logout

```bashmcpgw auth whoami             # Show current user

# Login (opens browser)```

mcpgw auth login

### Workspaces

# Login with token```bash

mcpgw auth login --token YOUR_TOKENmcpgw workspace list                    # List all workspaces

mcpgw workspace get WORKSPACE_ID        # Get workspace details

# Login with email/passwordmcpgw workspace create                  # Create new workspace

mcpgw auth login --email you@example.com --password yourpassmcpgw workspace delete WORKSPACE_ID     # Delete workspace

```

# Check auth status

mcpgw auth status### Backends

```bash

# Logoutmcpgw backend list WORKSPACE_ID                           # List backends

mcpgw auth logoutmcpgw backend add WORKSPACE_ID --name X --url Y           # Add backend

```mcpgw backend remove WORKSPACE_ID BACKEND_ID              # Remove backend

```

### Workspace Management

### Backend Catalog

```bash```bash

# List workspacesmcpgw catalog list                                  # Browse catalog

mcpgw workspace listmcpgw catalog list --category email                 # Filter by category

mcpgw catalog enable WORKSPACE_ID BACKEND_ID        # Enable from catalog

# Create workspace```

mcpgw workspace create "My Workspace"

### Agents

# Switch workspace```bash

mcpgw workspace use my-workspacemcpgw agent list WORKSPACE_ID                 # List agents

mcpgw agent create WORKSPACE_ID --name X      # Create agent

# Show current workspace```

mcpgw workspace current

```## Configuration



### MCP Server ManagementConfig stored in `~/.mcpgw/config.json`



```bash### Environment Variables

# Add servers from marketplace- `MCPGW_API_URL` - API base URL (default: http://localhost:8000/api/v1)

mcpgw add github

mcpgw add slack## Examples

mcpgw add postgres

### Setup a new workspace

# Add custom server```bash

mcpgw add custom https://my-server.com/mcp# Login

mcpgw auth login

# List enabled servers

mcpgw list# Create workspace

mcpgw workspace create --name "Production"

# Remove server

mcpgw remove github# Enable Gmail backend

```WORKSPACE_ID="ws_abc123"

mcpgw catalog enable $WORKSPACE_ID backend_gmail

### Claude Desktop Integration

# Create an agent

```bashmcpgw agent create $WORKSPACE_ID --name "Email Agent"

# Generate claude_desktop_config.json```

mcpgw generate

### Get workspace info as JSON

# Generate and save directly```bash

mcpgw generate > ~/Library/Application\ Support/Claude/claude_desktop_config.jsonmcpgw workspace list --json-output | jq '.[0]'

```

# Test configuration

mcpgw test## Development

```

```bash

### Interactive Wizard# Install in development mode

cd cli

```bashpip install -e .

# Quick start wizard

mcpgw quickstart# Run tests

```pytest



Walks you through:# Build distribution

1. Authenticationpython setup.py sdist bdist_wheel

2. Workspace selection/creation

3. Adding MCP servers# Upload to PyPI

4. Generating Claude configtwine upload dist/*

```

## 🎯 Common Workflows

## License

### New User Setup

MIT

```bash
# Complete setup in one flow
curl -fsSL https://get.mcpgw.io | sh
mcpgw quickstart
```

### Add GitHub Integration

```bash
mcpgw auth login
mcpgw add github --repo your-org/your-repo
mcpgw generate > ~/Library/Application\ Support/Claude/claude_desktop_config.json
```

### Team Workspace

```bash
mcpgw auth login
mcpgw workspace use team-workspace
mcpgw add github slack postgres
mcpgw generate
```

## ⌨️ Shell Aliases

Add to your `~/.zshrc` or `~/.bashrc`:

```bash
alias mg='mcpgw'
```

Then use:
```bash
mg add github    # Short and sweet!
mg generate
```

## 🔧 Configuration

Config stored in `~/.mcpgw/config.json`:

```json
{
  "token": "your-auth-token",
  "workspace_id": "selected-workspace-id",
  "api_url": "https://api.mcpgw.io"
}
```

### Environment Variables

- `MCPGW_API_URL` - Override API endpoint (default: **production** - https://api.mcpgw.io/api/v1)
- `MCPGW_PROFILE` - Override active profile  
- `MCPGW_TOKEN` - Authentication token (for CI/CD)
- `MCPGW_WORKSPACE` - Default workspace ID

Example:
```bash
# CLI uses production by default - just login and go!
mcpgw auth login

# Use staging for one command
MCPGW_PROFILE=staging mcpgw workspace list

# Or with direct API URL for local development
MCPGW_API_URL=http://localhost:8000/api/v1 mcpgw workspace list
```

📖 **See [ENVIRONMENT_GUIDE.md](ENVIRONMENT_GUIDE.md) for complete environment management guide**

## 📖 Commands Reference

### `mcpgw profile`
- `list` - Show all configuration profiles
- `create <name> --api-url <url>` - Create new profile
- `use <name>` - Switch to profile
- `current` - Show active profile
- `delete <name>` - Delete profile

### `mcpgw auth`
- `login` - Authenticate with MCP Gateway
- `logout` - Clear local credentials
- `status` - Check authentication status
- `whoami` - Show current user

### `mcpgw workspace`
- `list` - Show all workspaces
- `create <name>` - Create new workspace
- `use <workspace>` - Switch active workspace
- `current` - Show current workspace
- `delete <workspace>` - Delete workspace

### `mcpgw add <backend>`
- Add MCP servers from marketplace or custom URL
- Examples: `github`, `slack`, `postgres`, `custom`

### `mcpgw remove <backend>`
- Remove MCP server from workspace

### `mcpgw list`
- Show all enabled MCP servers

### `mcpgw generate`
- Generate `claude_desktop_config.json`

### `mcpgw test`
- Test current configuration

### `mcpgw quickstart`
- Interactive setup wizard

### `mcpgw version`
- Show CLI version

## 🏢 Enterprise Features

### Security & Compliance
- PII detection and redaction
- Audit trails for all operations
- Role-based access control
- Security policy enforcement

### Team Management
- Organization workspaces
- Member invitations
- Usage quotas
- Centralized billing

### Advanced Configuration
- Custom MCP servers
- API key management
- OAuth integration
- SSO/OIDC support

## 🔗 Links

- **Documentation**: https://docs.mcpgw.io
- **Website**: https://mcpgw.io
- **GitHub**: https://github.com/orangefennec/mcp-gateway
- **Support**: support@mcpgw.io

## 📝 License

MIT License - see [LICENSE](../LICENSE) for details

## 🤝 Contributing

Contributions welcome! See [CONTRIBUTING.md](../CONTRIBUTING.md)

---

**Made with ❤️ by [Orange Fennec](https://orangefennec.com)**
