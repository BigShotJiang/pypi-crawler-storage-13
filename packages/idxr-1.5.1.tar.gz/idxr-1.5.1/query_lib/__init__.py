"""Query library for executing ChromaSQL queries against multi-collection ChromaDB."""

from .executor import QueryExecutor, QueryResult

__all__ = ["QueryExecutor", "QueryResult"]
