from typing import List, Mapping

from idxr.models import ModelSpec


def format_model_registry_prompt(
    registry: Mapping[str, ModelSpec], discriminator_field: str = "model_name"
) -> str:
    """
    Produce a concise system prompt snippet describing the available models.
    """
    field_parts = [part for part in discriminator_field.split(".") if part]
    metadata_accessor = (
        ".".join(["metadata", *field_parts]) if field_parts else "metadata"
    )

    lines: List[str] = [
        "## Search on indexed data of SAP ERP system\n",
        "The index includes records modeled from SAP's internal tables."
        "The name of the model describes what it contains."
        "Eg. model name `MenuPath` has all the menu paths that's available "
        "in the attached SAP ERP system."
        "Each model has different metadata fields (listed later) and these can be used in"
        "queries as `WHERE metadata.field_name = ...` to filter records."
        "Each record has a document. The index contains embeddings of the document as well."
        "Use `WHERE_DOCUMENT` clause for keyword/text/regex-like search on the document."
        "Us `USING EMBEDDING` clause for vector search on the embeddings."
        "The index contain 19 million records, hence, it would be wise to "
        "not blow up your context and "
        "slowly expand the surface are of your search."
        f"Use `WHERE metadata.{metadata_accessor} = '...'` to keep your search "
        "limited to required models."
        "### Model Schema",
    ]

    for model_name in sorted(registry.keys()):
        spec = registry[model_name]
        keyword_fields = ", ".join(spec.keyword_fields) or "—"
        lines.append(f"- {model_name}: " f"metadata_fields=[{keyword_fields}]")

    return "\n".join(lines)
