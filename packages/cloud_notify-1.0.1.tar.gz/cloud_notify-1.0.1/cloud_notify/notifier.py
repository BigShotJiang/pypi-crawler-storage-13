import logging
import os
from typing import Iterable, Optional

logger = logging.getLogger("cloud_notify")
logger.addHandler(logging.NullHandler())


def _send_with_django(subject: str, text_body: str, html_body: str,
                      from_email: str, to: Iterable[str],
                      cc: Optional[Iterable[str]] = None,
                      bcc: Optional[Iterable[str]] = None,
                      fail_silently: bool = False) -> None:
    # Lazy import so library can be imported in non-Django environments
    try:
        from django.core.mail import EmailMultiAlternatives
        from django.conf import settings
    except Exception as exc:
        raise RuntimeError("Django not available for Django email backend.") from exc

    # Ensure from_email falls back to Django DEFAULT_FROM_EMAIL if possible
    if not from_email:
        from_email = getattr(settings, "DEFAULT_FROM_EMAIL", from_email)

    email = EmailMultiAlternatives(
        subject=subject,
        body=text_body or "",
        from_email=from_email,
        to=list(to),
        cc=list(cc) if cc else None,
        bcc=list(bcc) if bcc else None,
    )

    if html_body:
        email.attach_alternative(html_body, "text/html")

    email.send(fail_silently=fail_silently)
    logger.info("Email sent via Django backend to: %s", ", ".join(to))


def _send_with_smtplib(subject: str, text_body: str, html_body: str,
                       from_email: str, to: Iterable[str],
                       cc: Optional[Iterable[str]] = None,
                       bcc: Optional[Iterable[str]] = None,
                       fail_silently: bool = False) -> None:
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText

    smtp_host = os.environ.get("SMTP_HOST", "localhost")
    smtp_port = int(os.environ.get("SMTP_PORT", 25))
    smtp_user = os.environ.get("SMTP_USER")
    smtp_password = os.environ.get("SMTP_PASSWORD")
    smtp_use_tls = os.environ.get("SMTP_USE_TLS", "False").lower() in ("1", "true", "yes")

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = from_email or smtp_user or "noreply@example.com"
    recipients = list(to) + (list(cc) if cc else []) + (list(bcc) if bcc else [])
    msg["To"] = ", ".join(list(to))

    # Attach plain then HTML
    if text_body:
        msg.attach(MIMEText(text_body, "plain"))
    if html_body:
        msg.attach(MIMEText(html_body, "html"))

    try:
        if smtp_use_tls:
            server = smtplib.SMTP(smtp_host, smtp_port, timeout=10)
            server.starttls()
        else:
            server = smtplib.SMTP(smtp_host, smtp_port, timeout=10)

        if smtp_user and smtp_password:
            server.login(smtp_user, smtp_password)
        server.sendmail(msg["From"], recipients, msg.as_string())
        server.quit()
        logger.info("Email sent via smtplib to: %s", ", ".join(recipients))
    except Exception as exc:
        logger.exception("Failed to send email via smtplib: %s", exc)
        if not fail_silently:
            raise


def send_status_email(
    to_email: str,
    subject: str,
    html_body: str,
    text_body: Optional[str] = None,
    from_email: Optional[str] = None,
    cc: Optional[Iterable[str]] = None,
    bcc: Optional[Iterable[str]] = None,
    fail_silently: bool = False,
) -> None:
    """
    Send an email containing an order status update (or any message).
    - to_email: recipient e-mail (single string) OR comma-separated list accepted.
    - subject: subject line
    - html_body: HTML content 
    - text_body: plain-text fallback 
    - from_email: optional override 
    - cc, bcc: iterables of emails
    - fail_silently: if True don't raise on failure

    The function will try the Django email backend first .
    If Django isn't available it falls back to an smtplib implementation that uses env vars:
        SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_USE_TLS (True/False).
    """
    if not html_body:
        raise ValueError("html_body is required")

    # normalize to list
    if isinstance(to_email, str):
        to_list = [addr.strip() for addr in to_email.split(",") if addr.strip()]
    else:
        to_list = list(to_email)

    # Try Django backend first (if present and configured)
    try:
        import django  # quick check for Django presence
        # If Django present, use its backend
        _send_with_django(
            subject=subject,
            text_body=text_body or "",
            html_body=html_body,
            from_email=from_email,
            to=to_list,
            cc=cc,
            bcc=bcc,
            fail_silently=fail_silently,
        )
        return
    except Exception as django_exc:
        # Not a hard failure — log and fall back to smtplib if possible
        logger.debug("Django email backend not used: %s", django_exc)

    # Fallback to smtplib-based sending using environment variables
    _send_with_smtplib(
        subject=subject,
        text_body=text_body or "",
        html_body=html_body,
        from_email=from_email,
        to=to_list,
        cc=cc,
        bcc=bcc,
        fail_silently=fail_silently,
    )
