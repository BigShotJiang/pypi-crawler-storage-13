"""cloud_notify: tiny library to send HTML emails (raw HTML) for status changes.

Public API:
    send_status_email(to_email, subject, html_body, text_body=None, from_email=None, cc=None, bcc=None, fail_silently=False)
"""
from .notifier import send_status_email

__all__ = ["send_status_email"]
__version__ = "1.0.1"