from setuptools import setup, find_packages

setup(
    name='cloud-notify',
    version='1.0.1',
    packages=find_packages(),
    install_requires=[
        "Django>=3.2,<4.0",
        "boto3>=1.20",
    ],
    author='Hetik Chandaria',
    author_email='hetikchandaria67@gmail.com',
    description='A generic Django-compatible notification library for order status updates.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://pypi.org/project/cloud-notify/',
    license="MIT",
    classifiers=[
        'Programming Language :: Python :: 3',
        'Framework :: Django',
        'Framework :: Django :: 3.2',
        'Programming Language :: Python :: 3.9',
        'Operating System :: OS Independent',
        'License :: OSI Approved :: MIT License',
    ],
    python_requires='>=3.8',
)
