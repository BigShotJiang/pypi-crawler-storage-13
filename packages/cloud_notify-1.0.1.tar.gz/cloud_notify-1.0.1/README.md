# cloud_notify

Tiny library to send HTML emails (raw HTML) for order status updates.

- Works with Django's email backend if used inside a Django project.
- Falls back to `smtplib` using environment variables: `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_USE_TLS`.

## Install

Locally (editable):
