# FinanFut Intelligence Python SDK

Official Python SDK for **FinanFut Intelligence**, a modular AI platform for agents, memory and orchestration.

This package provides a high-level client to interact with FinanFut Intelligence:
- Unified `interact` API for chat and actions
- Application and agent management
- Memory (settings + records)
- Contexts (documents & sessions)
- Billing & usage
- Async requests and developer analytics
- Optional CLI tool: `finanfut`

---

## Installation

```bash
pip install finanfut-sdk
```

Requires **Python >= 3.10**.

---

## Quickstart

```python
from finanfut_sdk import FinanFutClient

client = FinanFutClient(
    api_key="YOUR_API_KEY",
    application_id="YOUR_APPLICATION_ID",
)

response = client.interact.query("Hello! Schedule a meeting tomorrow at 10.")
print(response.answer)
```

---

## Configuration (optional)

### Local config file

```bash
mkdir -p ~/.finanfut
```

Create `~/.finanfut/config.json`:

```json
{
  "api_key": "YOUR_API_KEY",
  "application_id": "YOUR_APPLICATION_ID",
  "api_url": "https://finanfut-intelligence.onrender.com"
}
```

Then:

```python
client = FinanFutClient()  # reads from config/env
```

### Environment variables supported

- `FINANFUT_API_KEY`
- `FINANFUT_APPLICATION_ID`
- `FINANFUT_API_URL`

`FINANFUT_API_URL` accepts either the bare host or a URL that already
includes `/api` or `/api/v1`; the SDK normalitza l'adreça perquè no s'hi
afegeixin segments duplicats.

---

## Using agents and intents

```python
# List agents
agents = client.agents.list()

for agent in agents:
    print(agent.name, agent.ai_model_id or "default model")

# Use a specific application agent and intent
response = client.interact.query(
    query="Add an event to my calendar.",
    application_agent_id="UUID_OF_APPLICATION_AGENT",
    intent_id="UUID_OF_INTENT",
)
print(response.answer)
```

`ai_model_id` reflects the catalog entry resolved by the backend and should be
used whenever you need to persist or audit the concrete model tied to an
agent.

---

## Memory API

```python
settings = client.memory.settings.get(application_id="APP_UUID")

records = client.memory.records.query(
    application_id="APP_UUID",
    application_agent_id="AGENT_UUID",
    query="What was the last scheduled event?"
)
```

---

## Billing & usage

```python
usage = client.billing.get_usage()
print("Total tokens used:", usage.tokens_used)
```

---

## CLI usage

```bash
finanfut init
finanfut interact "Hi!"
finanfut usage
```

---

## Document QA uploads

Use `client.documents.upload` to ingest files or free text for the document QA
agent. You can optionally set `document_type` to bypass automatic
classification and force the backend to tag the file with a known type such as
`context_general`, `examples_set`, `action_definition`, or `schema_contract`.

```python
from pathlib import Path
from finanfut_sdk import FinanFutClient

client = FinanFutClient(api_key="YOUR_API_KEY", application_id="APP_ID")

# Upload a PDF as contextual knowledge
detail = client.documents.upload(
    file_path=Path("knowledge.pdf"),
    document_type="context_general",
)
print(detail.document_type, detail.document_type_label)

# Upload pasted text with a strict contract type
schema_doc = client.documents.upload(
    text="{\"name\": \"Ada\", \"role\": \"engineer\"}",
    file_name="profile.json",
    mime_type="application/json",
    document_type="schema_contract",
)
print(schema_doc.document_type_version)

# Override classification for a curated examples set
client.documents.upload(
    content="Example A -> Response A", file_name="examples.md", document_type="examples_set"
)
```

---

## License

This project is licensed under the MIT License.
