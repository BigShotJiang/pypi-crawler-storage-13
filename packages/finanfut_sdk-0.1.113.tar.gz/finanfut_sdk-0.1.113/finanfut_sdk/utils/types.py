"""Typed models used across the FinanFut SDK."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Mapping, Optional, Type, TypeVar

from pydantic import BaseModel, Field, UUID4

try:  # Pydantic v2
    from pydantic import ConfigDict
except ImportError:  # pragma: no cover - Pydantic v1 fallback
    ConfigDict = None

ModelT = TypeVar("ModelT", bound=BaseModel)
BASE_MODEL_CONFIG = ConfigDict(from_attributes=True, populate_by_name=True, extra="allow") if ConfigDict else None
BASE_MODEL_CONFIG_KWARGS = dict(BASE_MODEL_CONFIG or {})


if BASE_MODEL_CONFIG:

    class SDKBaseModel(BaseModel):
        model_config = ConfigDict(**BASE_MODEL_CONFIG_KWARGS)

else:

    class SDKBaseModel(BaseModel):
        class Config:
            orm_mode = True
            allow_population_by_field_name = True
            extra = "allow"


class TokenUsage(SDKBaseModel):
    """Token usage summary for an interaction."""

    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    total_tokens: Optional[int] = None


class ActionResult(SDKBaseModel):
    """Represents an action returned by FinanFut agents."""

    name: Optional[str] = None
    payload: Optional[Dict[str, Any]] = Field(default_factory=dict)


class Answer(SDKBaseModel):
    """Structured answer payload returned by FinanFut Intelligence."""

    content: Optional[str] = None


class IntentResult(SDKBaseModel):
    """Result content for an intent execution."""

    content: Optional[str] = None


class IntentResponse(SDKBaseModel):
    """Metadata for a resolved intent inside ``metadata.intent_responses``."""

    intent: Optional[str] = None
    parameters: Dict[str, Any] = Field(default_factory=dict)
    result: Optional[IntentResult] = None
    raw_model_output: Optional[Any] = None


class InteractionResponse(SDKBaseModel):
    """High-level response returned by `/api/v1/interact`."""

    answer: Optional[Answer | str] = None
    actions: List[ActionResult] = Field(default_factory=list)
    tokens: Optional[TokenUsage] = None
    tokens_used: Optional[int] = None
    sandbox: Optional[bool] = None
    request_id: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    intent_responses: List[IntentResponse] = Field(default_factory=list)
    agent_id: Optional[str] = None
    context_used: Optional[Any] = None
    application_agent_id: Optional[str] = None
    application_agent_intent_id: Optional[str] = None
    intent_id: Optional[str] = None
    intent_name: Optional[str] = None
    intent_label: Optional[str] = None
    available_intent_names: List[str] = Field(default_factory=list)
    available_intents: List[Intent] = Field(default_factory=list)
    raw_model_output: Optional[Any] = None
    meta: Dict[str, Any] = Field(default_factory=dict)
    raw: Dict[str, Any] = Field(default_factory=dict)


def build_interaction_response(
    data: Mapping[str, Any], meta: Optional[Mapping[str, Any]] = None
) -> InteractionResponse:
    """Create an :class:`InteractionResponse` from backend payloads."""

    safe_meta = dict(meta or {})
    if isinstance(data, Mapping):
        safe_data: Dict[str, Any] = dict(data)
    else:
        safe_data = {"answer": data}

    nested_response: Optional[Mapping[str, Any]] = None
    for key in ("response", "result"):
        candidate = safe_data.get(key)
        if isinstance(candidate, Mapping):
            nested_response = candidate
            break

    merged_data: Dict[str, Any] = dict(safe_data)
    if isinstance(nested_response, Mapping):
        for key, value in nested_response.items():
            if value is None and key in merged_data and merged_data[key] is not None:
                continue
            if value is not None or key not in merged_data:
                merged_data[key] = value

    def _first_not_none(*values: Any) -> Any:
        for value in values:
            if value is not None:
                return value
        return None

    def _first_mapping(*values: Any) -> Optional[Mapping[str, Any]]:
        for value in values:
            if isinstance(value, Mapping):
                return value
        return None

    def _normalize_answer(raw_answer: Any) -> Any:
        if isinstance(raw_answer, Mapping):
            return _model_validate(Answer, raw_answer)
        if raw_answer is None:
            return None
        return _model_validate(Answer, {"content": str(raw_answer)})

    token_payload = _first_not_none(
        merged_data.get("tokens"),
        merged_data.get("token_usage"),
        merged_data.get("tokens_used"),
        safe_meta.get("token_usage"),
        safe_meta.get("tokens"),
        merged_data.get("metadata", {}).get("token_usage")
        if isinstance(merged_data.get("metadata"), Mapping)
        else None,
    )

    request_identifier = _first_not_none(
        merged_data.get("request_id"),
        merged_data.get("requestId"),
        safe_data.get("request_id"),
        safe_data.get("requestId"),
        safe_meta.get("request_id"),
        safe_meta.get("requestId"),
    )

    intent_payload = _first_mapping(
        merged_data.get("intent"),
        safe_data.get("intent"),
        nested_response.get("intent") if isinstance(nested_response, Mapping) else None,
    )
    normalized_intent = normalize_intent_payload(intent_payload) if intent_payload else None

    actions_payload = merged_data.get("actions") or []
    if isinstance(actions_payload, Mapping):
        actions_payload = [actions_payload]
    elif not isinstance(actions_payload, list):
        actions_payload = []

    metadata_payload = _first_mapping(
        merged_data.get("metadata"),
        merged_data.get("meta"),
        safe_meta.get("metadata"),
        safe_meta.get("meta"),
    )
    metadata_payload = metadata_payload if metadata_payload is not None else {}

    available_intents_payload = _first_not_none(
        merged_data.get("available_intents"),
        safe_meta.get("available_intents"),
    )
    available_intents: List[Intent] = []
    if isinstance(available_intents_payload, Mapping):
        available_intents_payload = [available_intents_payload]
    if isinstance(available_intents_payload, list):
        for item in available_intents_payload:
            normalized = normalize_intent_payload(item)
            if normalized is None:
                continue
            available_intents.append(_model_validate(Intent, normalized))

    available_intent_names = _first_not_none(
        merged_data.get("available_intent_names"),
        safe_meta.get("available_intent_names"),
    )
    intent_responses_payload = metadata_payload.get("intent_responses") if isinstance(metadata_payload, Mapping) else None
    intent_responses: List[IntentResponse] = []
    if isinstance(intent_responses_payload, list):
        for item in intent_responses_payload:
            if not isinstance(item, Mapping):
                continue
            intent_responses.append(_model_validate(IntentResponse, item))

    if not available_intent_names:
        names_from_intent_responses = [
            intent_response.intent
            for intent_response in intent_responses
            if intent_response.intent
        ]
        available_intent_names = names_from_intent_responses or [
            intent.name for intent in available_intents if intent.name
        ]

    token_usage_payload = _coerce_token_usage(token_payload)

    tokens_used = None
    if isinstance(token_payload, (int, float)):
        tokens_used = int(token_payload)
    elif isinstance(token_payload, Mapping):
        tokens_used = token_payload.get("total_tokens") or token_payload.get("tokens_used")

    intent_id = _first_not_none(
        merged_data.get("intent_id"),
        merged_data.get("intentId"),
        (normalized_intent or {}).get("intent_id"),
        (normalized_intent or {}).get("id"),
        safe_meta.get("intent_id"),
        safe_meta.get("intentId"),
    )
    application_agent_intent_id = _first_not_none(
        merged_data.get("application_agent_intent_id"),
        merged_data.get("applicationAgentIntentId"),
        (normalized_intent or {}).get("application_agent_intent_id"),
        safe_meta.get("application_agent_intent_id"),
        safe_meta.get("applicationAgentIntentId"),
    )

    application_agent_id = _first_not_none(
        merged_data.get("application_agent_id"),
        merged_data.get("applicationAgentId"),
        (normalized_intent or {}).get("application_agent_id"),
        safe_meta.get("application_agent_id"),
    )

    agent_id = _first_not_none(
        merged_data.get("agent_id"),
        merged_data.get("agentId"),
        safe_meta.get("agent_id"),
        safe_meta.get("agentId"),
    )

    raw_model_output = _first_not_none(
        merged_data.get("raw_model_output"),
        merged_data.get("raw_output"),
        next((item.raw_model_output for item in intent_responses if item.raw_model_output is not None), None),
    )

    return _model_validate(
        InteractionResponse,
        {
            "answer": _normalize_answer(
                _first_not_none(merged_data.get("answer"), safe_data.get("answer"))
            ),
            "actions": actions_payload,
            "tokens": token_usage_payload,
            "tokens_used": tokens_used,
            "sandbox": bool(merged_data.get("sandbox", safe_meta.get("sandbox", False))),
            "request_id": request_identifier,
            "metadata": metadata_payload,
            "intent_responses": intent_responses,
            "agent_id": agent_id,
            "context_used": merged_data.get("context_used")
            or merged_data.get("context"),
            "application_agent_id": application_agent_id,
            "intent_id": intent_id,
            "intent_name": _first_not_none(
                merged_data.get("intent_name"),
                merged_data.get("intentName"),
                (normalized_intent or {}).get("name"),
            ),
            "intent_label": _first_not_none(
                merged_data.get("intent_label"),
                merged_data.get("intentLabel"),
                (normalized_intent or {}).get("label"),
            ),
            "application_agent_intent_id": application_agent_intent_id,
            "available_intent_names": available_intent_names or [],
            "available_intents": available_intents,
            "raw_model_output": raw_model_output,
            "meta": safe_meta,
            "raw": merged_data,
        },
    )


def normalize_intent_payload(item: Any) -> Optional[Dict[str, Any]]:
    """Flatten nested intent payloads while preserving metadata values.

    Backend responses sometimes wrap the real intent metadata under an ``intent``
    key. This helper ensures ``name``, ``label`` and identifier fields survive
    the merge even when outer keys are ``null``.
    """

    if not isinstance(item, Mapping):
        return None

    payload: Dict[str, Any] = dict(item)
    nested_intent = payload.pop("intent", None)

    merged: Dict[str, Any] = {}

    def _set_if_present(key: str, value: Any) -> None:
        if value is not None and key not in merged:
            merged[key] = value

    if isinstance(nested_intent, Mapping):
        for key, value in nested_intent.items():
            if value is not None:
                merged[key] = value

    link_id = (
        payload.get("id")
        or payload.get("application_agent_intent_id")
        or payload.get("applicationAgentIntentId")
    )

    intent_id = (
        (nested_intent.get("intent_id") if isinstance(nested_intent, Mapping) else None)
        or (nested_intent.get("id") if isinstance(nested_intent, Mapping) else None)
        or payload.get("intent_id")
        or payload.get("intentId")
        or payload.get("id")
        or link_id
    )
    _set_if_present("intent_id", intent_id)
    _set_if_present("id", intent_id)

    application_agent_intent_id = (
        (nested_intent.get("application_agent_intent_id") if isinstance(nested_intent, Mapping) else None)
        or payload.get("application_agent_intent_id")
        or payload.get("applicationAgentIntentId")
        or link_id
    )
    _set_if_present("application_agent_intent_id", application_agent_intent_id)

    application_agent_id = (
        (nested_intent.get("application_agent_id") if isinstance(nested_intent, Mapping) else None)
        or payload.get("application_agent_id")
        or payload.get("applicationAgentId")
    )
    _set_if_present("application_agent_id", application_agent_id)

    for source in (payload, nested_intent if isinstance(nested_intent, Mapping) else {}):
        for key, value in source.items():
            if key in {
                "intent_id",
                "intentId",
                "id",
                "application_agent_intent_id",
                "applicationAgentIntentId",
                "intent",
            }:
                continue
            existing = merged.get(key)
            if value is None and existing is not None:
                continue
            if existing is None or value is not None:
                merged[key] = value

    return merged


def _model_validate(model: Type[ModelT], data: Any) -> ModelT:
    """Compatibility helper for Pydantic v1 and v2 validation."""

    validate = getattr(model, "model_validate", None)
    if callable(validate):
        return validate(data)
    return model.parse_obj(data)


def _coerce_token_usage(payload: Any) -> Optional[TokenUsage]:
    if payload is None:
        return None
    if isinstance(payload, Mapping):
        return _model_validate(TokenUsage, payload)
    if isinstance(payload, (int, float)):
        return _model_validate(TokenUsage, {"total_tokens": int(payload)})
    return None


class MemoryRecord(SDKBaseModel):
    """Represents a memory entry."""

    record_id: Optional[str] = None
    content: str
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )


class MemorySettings(SDKBaseModel):
    """Configuration for memory storage."""

    enabled: bool
    retention_days: Optional[int] = None
    max_records: Optional[int] = None


class MemoryQueryResponse(SDKBaseModel):
    """Response payload returned by memory query endpoints."""

    records: List[MemoryRecord] = Field(default_factory=list)
    total: Optional[int] = None


class BillingUsage(SDKBaseModel):
    """Current usage metrics."""

    period: str
    tokens_used: int
    cost: float


class BillingPlan(SDKBaseModel):
    """Generic billing plan descriptor."""

    plan_id: Optional[str] = None
    name: Optional[str] = None
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )


class TransactionRecord(SDKBaseModel):
    """Billing transaction entry."""

    transaction_id: str
    amount: float
    currency: str
    created_at: str
    description: Optional[str] = None


class Agent(SDKBaseModel):
    """Agent metadata."""

    agent_id: str
    name: str
    description: Optional[str] = None
    ai_model_id: Optional[str] = None


class Intent(SDKBaseModel):
    """Intent metadata compatible with backend responses."""

    intent_id: Optional[str] = Field(None, alias="id")
    application_agent_intent_id: Optional[str] = None
    application_agent_id: Optional[str] = None
    name: Optional[str] = None
    label: Optional[str] = None
    slug: Optional[str] = None
    code: Optional[str] = None
    description: Optional[str] = None
    enabled: Optional[bool] = None
    parameters: Dict[str, Any] = Field(default_factory=dict)
    default_parameters: Dict[str, Any] = Field(default_factory=dict)
    input_schema: Optional[Dict[str, Any]] = None
    output_schema: Optional[Dict[str, Any]] = None

    if BASE_MODEL_CONFIG:
        model_config = ConfigDict(**BASE_MODEL_CONFIG_KWARGS)
    else:
        class Config(SDKBaseModel.Config):
            extra = "allow"


if hasattr(InteractionResponse, "model_rebuild"):
    InteractionResponse.model_rebuild()
elif hasattr(InteractionResponse, "update_forward_refs"):
    InteractionResponse.update_forward_refs(Intent=Intent)



class Application(SDKBaseModel):
    """Application metadata."""

    application_id: str
    name: str
    status: str


class ApplicationAgent(SDKBaseModel):
    """Application-scoped agent metadata."""

    application_agent_id: UUID4
    application_id: UUID4
    agent_id: Optional[UUID4] = None
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict, alias="metadata_")
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    if BASE_MODEL_CONFIG:
        model_config = ConfigDict(**BASE_MODEL_CONFIG_KWARGS)
    else:
        class Config(SDKBaseModel.Config):
            extra = "allow"


class ApplicationAgentList(SDKBaseModel):
    """Paginated application agent response payload."""

    items: List[ApplicationAgent] = Field(default_factory=list)
    total: int = 0
    limit: int = 0
    offset: int = 0


class AccessToken(SDKBaseModel):
    """Metadata describing a rotating access token."""

    token_id: str
    description: Optional[str] = None
    created_at: Optional[str] = None
    last_used_at: Optional[str] = None


class AccessTokenCreateRequest(SDKBaseModel):
    """Request payload for creating a new access token."""

    description: Optional[str] = None
    scopes: List[str] = Field(default_factory=list)


class AccessTokenListResponse(SDKBaseModel):
    """Paginated collection of access tokens."""

    items: List[AccessToken] = Field(default_factory=list)
    total: Optional[int] = None


class DocumentFile(SDKBaseModel):
    """Metadata about an uploaded document."""

    id: UUID4
    file_name: str
    mime_type: Optional[str] = None
    status: str
    chunk_count: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    document_type_id: Optional[UUID4] = None
    document_type: Optional[str] = None
    document_type_label: Optional[str] = None
    document_type_version: Optional[int] = None
    document_type_strict_validation: Optional[bool] = None
    document_type_embedding_enabled: Optional[bool] = None
    document_type_chunking_strategy: Optional[Dict[str, Any]] = None
    latest_processing_id: Optional[UUID4] = None
    processing_summary: Optional[str] = None
    processing_confidence: Optional[float] = None
    processing_version: int = 0
    classification_metadata: Optional[Dict[str, Any]] = None


class DocumentDetail(DocumentFile):
    """Full document payload returned after upload or lookup."""

    text_content: str = ""
    error: Optional[str] = None
    content_base64: Optional[str] = Field(default=None, repr=False)


class DocumentAnswer(SDKBaseModel):
    """Answer payload returned by the document QA endpoint."""

    answer: str
    request_id: Optional[UUID4] = None


class DocumentType(SDKBaseModel):
    """Descriptor for a pipeline document type."""

    id: UUID4
    name: str
    label: Optional[str] = None
    description: Optional[str] = None
    expected_format: Optional[str] = None
    parse_strategy: Optional[str] = None
    output_contract: Optional[Dict[str, Any]] = None
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )
    version: int = 1
    strict_validation: Optional[bool] = None
    embedding_enabled: Optional[bool] = None
    chunking_strategy: Dict[str, Any] = Field(default_factory=dict)
    is_active: Optional[bool] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class DocumentTypeDetail(DocumentType):
    """Detailed descriptor for a document type."""


class ValidationReport(SDKBaseModel):
    """Validation status after running the processing pipeline."""

    is_valid: bool
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)


class DeclarativeAction(SDKBaseModel):
    """Action emitted by the pipeline for downstream automation."""

    id: UUID4
    processing_record_id: UUID4
    document_id: UUID4
    application_id: UUID4
    name: str
    handler: str
    endpoint: Optional[str] = None
    description: Optional[str] = None
    version: int
    parameters: Dict[str, Any] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )
    processed_by_agent_id: Optional[UUID4] = None
    processed_by_agent_name: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class DocumentProcessingRecord(SDKBaseModel):
    """One processing run executed for a document."""

    id: UUID4
    document_id: UUID4
    application_id: UUID4
    document_type_id: Optional[UUID4] = None
    document_type_version: Optional[int] = None
    status: str
    summary: Optional[str] = None
    confidence: Optional[float] = None
    version: int
    processing_version: int = 1
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )
    parsed_content: Optional[Dict[str, Any]] = None
    raw_response: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    processor_agent_id: Optional[UUID4] = None
    processor_agent_name: Optional[str] = None
    execution_time_ms: Optional[int] = None
    tokens_used: int = 0
    parser_version: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class DocumentProcessingResponse(SDKBaseModel):
    """Full payload returned after requesting document processing."""

    record: DocumentProcessingRecord
    parsed_content: Optional[Dict[str, Any]] = None
    validation: ValidationReport
    dry_run: bool = False
    action: Optional[DeclarativeAction] = None


class DocumentRunsResponse(SDKBaseModel):
    """Historical processing runs."""

    runs: List[DocumentProcessingRecord] = Field(default_factory=list)


class DocumentParsedResponse(SDKBaseModel):
    """Latest parsed content and associated action."""

    record: Optional[DocumentProcessingRecord] = None
    action: Optional[DeclarativeAction] = None


class ContextDocumentLink(SDKBaseModel):
    """Context document relationship metadata."""

    document_id: UUID4
    position: Optional[int] = None
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class ContextSummary(SDKBaseModel):
    """High-level summary returned when listing contexts."""

    id: UUID4
    application_id: UUID4
    name: str
    description: Optional[str] = None
    status: str
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )
    document_count: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class ContextDetail(ContextSummary):
    """Context detail including linked documents."""

    documents: List[ContextDocumentLink] = Field(
        default_factory=list, alias="document_links"
    )


class ContextList(SDKBaseModel):
    """Paginated response returned by the contexts API."""

    items: List[ContextSummary] = Field(default_factory=list)
    total: int = 0
    limit: int = 0
    offset: int = 0


class ContextSessionSummary(SDKBaseModel):
    """Summary of a context session."""

    id: UUID4
    name: str
    status: str
    context_id: Optional[UUID4] = None
    created_at: datetime
    updated_at: Optional[datetime] = None


class ContextSessionMessage(SDKBaseModel):
    """Message captured inside a context session."""

    id: UUID4
    session_id: UUID4
    context_id: Optional[UUID4] = None
    agent_name: str
    intent: Optional[str] = None
    role: str
    query: Optional[str] = None
    answer: Optional[str] = None
    tokens_used: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime


class ContextSessionDetail(ContextSessionSummary):
    """Detailed session with metadata and messages."""

    metadata: Dict[str, Any] = Field(default_factory=dict)
    messages: List[ContextSessionMessage] = Field(default_factory=list)


class ContextSessionList(SDKBaseModel):
    """Response returned when listing context sessions."""

    items: List[ContextSessionSummary] = Field(default_factory=list)
