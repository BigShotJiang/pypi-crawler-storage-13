import pygame
import os
from PygameTool import PGMessageBox


def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("PGMessageBox Test")

    box = PGMessageBox(
        x=400,
        y=300,
        size=0.4,
        title="提示",
        message="是否继续？",
        background_image=None,
        confirm_text="确定",
        cancel_text="取消",
        screen=screen,
        Title_Center=True,
        Message_Center=True,
    )

    done = {"exit": False}

    def on_confirm():
        print("confirm")
        done["exit"] = True

    def on_cancel():
        print("cancel")
        done["exit"] = True

    def on_update():
        print("update")

    box.bind_confirm(on_confirm)
    box.bind_cancel(on_cancel)
    box.bind_update(on_update)
    box.show()

    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_u:
                    # 将第三按钮文本在 None 与 "更新" 之间切换
                    box.update_text = None if box.update_text is not None else "更新"
                elif event.key == pygame.K_b:
                    candidates = ["example.png", "bg.jpg", "bg.png"]
                    path = next((p for p in candidates if os.path.isfile(p)), None)
                    box.set_background(path) if path else box.set_background(None)
                elif event.key == pygame.K_SPACE:
                    box.show()
            box.handle_event(event)

        screen.fill((30, 30, 30))
        box.draw()
        pygame.display.flip()
        clock.tick(60)
        if done["exit"] and not box.visible:
            running = False

    pygame.quit()


if __name__ == "__main__":
    main()