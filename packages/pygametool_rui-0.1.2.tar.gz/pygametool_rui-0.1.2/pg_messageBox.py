# h:\Python\简化用开发工具\PygameTool\pg_messageBox.py
import pygame
from typing import Optional, Callable, Tuple, Union


class PGMessageBox:
    def __init__(self,
                 x: int = 400, y: int = 300,
                 size: Union[Tuple[int, int], float] = (480, 300),
                 title: str = "提示",
                 message: str = "提示信息",
                 background_image: Optional[str] = None,
                 confirm_text: str = "确定",
                 update_text: Optional[str] = None,
                 cancel_text: str = "取消",
                 font_name: str = "kaiti",
                 font_size: int = 20,
                 screen: Optional[pygame.Surface] = None,
                 Title_Center: bool = False,
                 Message_Center: bool = False):
        self.x, self.y = x, y
        self.screen: Optional[pygame.Surface] = screen
        self.title_center = Title_Center
        self.message_center = Message_Center
        if isinstance(size, tuple):
            self.w, self.h = int(size[0]), int(size[1])
        elif isinstance(size, float):
            target_screen = self.screen or pygame.display.get_surface()
            sw = target_screen.get_width() if target_screen else 800
            width = int(sw * size)
            phi = 1.618
            height = int(width / phi)
            self.w, self.h = max(100, width), max(80, height)
        else:
            self.w, self.h = 480, 300
        self.title, self.message = title, message
        self.background_image_path = background_image
        self.confirm_text = confirm_text
        self.update_text = update_text
        self.cancel_text = cancel_text

        self.visible = False
        self.result: Optional[bool] = None  # True=confirm, False=cancel, None=none
        self.on_confirm: Optional[Callable[[], None]] = None
        self.on_update: Optional[Callable[[], None]] = None
        self.on_cancel: Optional[Callable[[], None]] = None

        self.font_title = pygame.font.SysFont(font_name, font_size + 4, bold=True)
        self.font_body = pygame.font.SysFont(font_name, font_size)
        self.font_btn = pygame.font.SysFont(font_name, font_size)

        self._bg_surface: Optional[pygame.Surface] = None  # 弹窗内部背景图
        self._title_bar_height = 36
        self._padding = 16
        self._radius = 8

        # 预计算弹窗矩形（基于中心坐标）
        self._rect = pygame.Rect(int(self.x - self.w / 2), int(self.y - self.h / 2), self.w, self.h)
        self._close_rect = pygame.Rect(0, 0, self._title_bar_height, self._title_bar_height)  # 右上角X区域
        self._confirm_rect = pygame.Rect(0, 0, 120, 40)
        self._update_rect = pygame.Rect(0, 0, 120, 40)
        self._cancel_rect = pygame.Rect(0, 0, 120, 40)
        self._close_hover = False

        if self.background_image_path:
            self.set_background(self.background_image_path)

    def set_background(self, path: str):
        """加载背景图片并按弹窗内部区域自适应缩放居中裁剪"""
        try:
            img = pygame.image.load(path).convert_alpha()
            inner_w = self.w - self._padding * 2
            inner_h = self.h - self._padding * 2 - self._title_bar_height
            if inner_w <= 0 or inner_h <= 0:
                self._bg_surface = None
                return
            # 等比缩放后居中裁剪
            iw, ih = img.get_width(), img.get_height()
            scale = max(inner_w / iw, inner_h / ih)
            scaled = pygame.transform.smoothscale(img, (int(iw * scale), int(ih * scale)))
            sx, sy = scaled.get_width(), scaled.get_height()
            cx = (sx - inner_w) // 2
            cy = (sy - inner_h) // 2
            self._bg_surface = scaled.subsurface(pygame.Rect(cx, cy, inner_w, inner_h)).copy()
        except Exception:
            self._bg_surface = None

    def bind_confirm(self, func: Callable[[], None]): self.on_confirm = func
    def bind_update(self, func: Callable[[], None]): self.on_update = func
    def bind_cancel(self, func: Callable[[], None]): self.on_cancel = func

    def show(self): 
        self.visible = True
        self.result = None

    def hide(self): 
        self.visible = False

    def _layout_buttons(self):
        """将按钮固定在弹窗底部并左右/居中对齐"""
        y = self._rect.bottom - self._padding - self._confirm_rect.height
        # 左侧：确定（弹窗内部左侧）
        self._confirm_rect.topleft = (self._rect.left + self._padding, y)
        # 中间：更新（根据是否有文字决定是否显示）
        self._update_rect.center = (self._rect.centerx, y + self._update_rect.height // 2)
        # 右侧：取消（弹窗内部右侧）
        self._cancel_rect.topright = (self._rect.right - self._padding, y)

        # 右上角关闭按钮（位于弹窗的右上角）
        self._close_rect.topleft = (self._rect.right - self._title_bar_height, self._rect.top)

    def handle_event(self, event: pygame.event.Event):
        """处理鼠标事件，X 按钮与 Cancel 行为一致，悬浮时 X 变红"""
        if not self.visible:
            return
        if event.type == pygame.MOUSEMOTION:
            mx, my = event.pos
            self._close_hover = self._close_rect.collidepoint(mx, my)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            # 关闭按钮
            if self._close_rect.collidepoint(mx, my):
                if self.on_cancel: self.on_cancel()
                self.result = False
                self.hide()
                return
            # 确定
            if self._confirm_rect.collidepoint(mx, my):
                if self.on_confirm: self.on_confirm()
                self.result = True
                self.hide()
                return
            # 更新（仅当有文字时视为启用）
            if (self.update_text is not None) and self._update_rect.collidepoint(mx, my):
                if self.on_update: self.on_update()
                return
            # 取消
            if self._cancel_rect.collidepoint(mx, my):
                if self.on_cancel: self.on_cancel()
                self.result = False
                self.hide()
                return

    def draw(self, surface: Optional[pygame.Surface] = None):
        """绘制半透明遮罩、弹窗、标题栏、正文与底部按钮"""
        if not self.visible:
            return
        if surface is None:
            surface = self.screen or pygame.display.get_surface()
        if surface is None:
            return
        self._layout_buttons()

        # 半透明背景遮罩
        sw, sh = surface.get_width(), surface.get_height()
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 120))
        surface.blit(overlay, (0, 0))

        # 弹窗主体
        pygame.draw.rect(surface, (245, 245, 245), self._rect, border_radius=self._radius)
        pygame.draw.rect(surface, (180, 180, 180), self._rect, width=2, border_radius=self._radius)

        # 标题栏
        title_bar = pygame.Rect(self._rect.left, self._rect.top, self._rect.width, self._title_bar_height)
        title_color = (230, 230, 230)
        pygame.draw.rect(surface, title_color, title_bar, border_top_left_radius=self._radius, border_top_right_radius=self._radius)
        # 标题文本
        title_surf = self.font_title.render(self.title, True, (30, 30, 30))
        if self.title_center:
            tx = title_bar.centerx - title_surf.get_width() // 2
        else:
            tx = title_bar.left + self._padding
        ty_title = title_bar.top + (self._title_bar_height - title_surf.get_height()) // 2
        surface.blit(title_surf, (tx, ty_title))
        # 右上角关闭按钮
        close_bg = (220, 80, 80) if self._close_hover else title_color
        pygame.draw.rect(surface, close_bg, self._close_rect)
        x_surf = self.font_btn.render("X", True, (255, 255, 255))
        surface.blit(x_surf, (self._close_rect.centerx - x_surf.get_width() // 2,
                              self._close_rect.centery - x_surf.get_height() // 2))

        # 背景图区域与正文
        inner_rect = pygame.Rect(self._rect.left + self._padding,
                                 self._rect.top + self._title_bar_height + self._padding,
                                 self._rect.width - self._padding * 2,
                                 self._rect.height - self._title_bar_height - self._padding * 2)
        if self._bg_surface:
            surface.blit(self._bg_surface, inner_rect.topleft)
        # 正文文本（简单换行：按窗口宽度拆行）
        msg_lines = self._wrap_text(self.message, self.font_body, inner_rect.width)
        ty = inner_rect.top
        for line in msg_lines:
            line_surf = self.font_body.render(line, True, (40, 40, 40))
            if self.message_center:
                lx = inner_rect.centerx - line_surf.get_width() // 2
            else:
                lx = inner_rect.left
            surface.blit(line_surf, (lx, ty))
            ty += line_surf.get_height() + 6

        # 底部按钮（固定在弹窗内底部）
        self._draw_button(surface, self._confirm_rect, self.confirm_text, bg=(80, 160, 80))
        if self.update_text is not None:
            self._draw_button(surface, self._update_rect, self.update_text, bg=(80, 120, 200))
        self._draw_button(surface, self._cancel_rect, self.cancel_text, bg=(200, 80, 80))

    def _draw_button(self, surface: pygame.Surface, rect: pygame.Rect, text: str, bg=(200, 200, 200)):
        pygame.draw.rect(surface, bg, rect, border_radius=6)
        pygame.draw.rect(surface, (160, 160, 160), rect, width=2, border_radius=6)
        ts = self.font_btn.render(text, True, (255, 255, 255))
        surface.blit(ts, (rect.centerx - ts.get_width() // 2, rect.centery - ts.get_height() // 2))

    @staticmethod
    def _wrap_text(text: str, font: pygame.font.Font, max_w: int):
        """基于字符宽度的简单换行，不依赖外部库"""
        lines, curr = [], ""
        for ch in text:
            w = font.size(curr + ch)[0]
            if w <= max_w or not curr:
                curr += ch
            else:
                lines.append(curr)
                curr = ch
        if curr:
            lines.append(curr)
        return lines


__all__ = ["PGMessageBox"]
