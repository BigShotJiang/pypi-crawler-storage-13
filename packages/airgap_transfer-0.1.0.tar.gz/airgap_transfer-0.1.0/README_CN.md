# Airgap Transfer

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![Version](https://img.shields.io/badge/version-0.1.0-blue.svg)](https://github.com/RLHQ/airgap-transfer/releases)
[![Status](https://img.shields.io/badge/status-beta-orange.svg)](https://github.com/RLHQ/airgap-transfer)

**用于气隙和隔离环境的双向文件传输工具。**

通过键盘输入模拟和二维码视频流，向隔离系统（VDI、堡垒机、气隙网络）传输文件或从中提取文件。

[中文文档](README_CN.md) | [English](README.md)

## 特性

### 🎹 键盘传输
- **通过键盘输入传输文件** - 通过模拟键盘打字发送文件
- **自动执行** - 脚本在远程系统上自动执行
- **SHA256 验证** - 内置校验和验证
- **速度预设** - 针对不同连接类型优化（本地虚拟机、远程桌面等）

### 📱 二维码传输
- **将文件编码为二维码** - 生成用于屏幕共享的视频流
- **从视频解码** - 从屏幕录制中提取文件
- **高容错性** - 对视频质量问题具有鲁棒性
- **进度跟踪** - 编码/解码过程中的实时反馈

### 🛠️ 专业设计
- **统一 CLI** - 单个 `airgap` 命令，包含直观的子命令
- **简洁的 Python API** - 可在自己的项目中用作库
- **类型提示** - 完整的类型注解，提供更好的 IDE 支持
- **模块化** - 组织良好的代码库，易于贡献

## 快速开始

### 安装

> **注意**：本项目目前为 v0.1.0 版本，尚未发布到 PyPI。请从源码安装：

```bash
# 克隆仓库
git clone https://github.com/RLHQ/airgap-transfer.git
cd airgap-transfer

# 使用 uv 安装（推荐）
uv sync                              # 基础包
uv sync --extra all                  # 带二维码支持
uv sync --extra all --extra dev      # 包含开发工具

# 或使用 pip（兼容方式）
pip install -e .
pip install -e ".[all]"
pip install -e ".[all,dev]"
```

**发布到 PyPI 后（未来）：**
```bash
pip install airgap-transfer         # 基础包
pip install airgap-transfer[all]    # 带二维码支持
```

### 使用示例

#### 键盘传输

```bash
# 开发环境（使用 uv）
uv run airgap send myfile.pdf

# 指定远程系统上的输出路径
uv run airgap send myfile.pdf --output /tmp/received.pdf

# 使用速度预设
uv run airgap send myfile.pdf --fast    # 用于本地虚拟机
uv run airgap send myfile.pdf --slow    # 用于高延迟连接

# 自定义倒计时
uv run airgap send myfile.pdf --countdown 10

# 生产环境（已安装）
airgap send myfile.pdf
```

#### 二维码传输

```bash
# 开发环境（使用 uv）
uv run airgap qr-encode myfile.pdf | ffplay -framerate 1 -f image2pipe -i -

# 或保存为视频
uv run airgap qr-encode myfile.pdf | ffmpeg -framerate 1 -f image2pipe -i - output.mp4

# 从录制视频解码（接收端）
uv run airgap qr-decode recording.mp4 output.pdf

# 与原始文件验证
uv run airgap qr-decode recording.mp4 output.pdf --verify original.pdf

# VDI 环境（仅使用 python3 和 qrcode）
python3 qr_sender.py myfile.pdf 5 | ffplay -framerate 1 -f image2pipe -i -
```

### Python API

```python
from airgap_transfer import KeyboardTransfer, QREncoder, QRDecoder

# 键盘传输
transfer = KeyboardTransfer("myfile.pdf")
stats = transfer.send(countdown=5)
print(f"传输耗时 {stats['elapsed_time']:.1f}秒")

# 二维码编码
import sys
encoder = QREncoder("myfile.pdf")
encoder.encode_to_stream(sys.stdout.buffer)

# 二维码解码
decoder = QRDecoder("recording.mp4")
success = decoder.decode_to_file("output.pdf")
if success:
    print("文件解码成功！")
```

### 完整工作流示例

**场景**：向 VDI 环境传输配置文件

```bash
# 1. 在外部机器上
git clone https://github.com/RLHQ/airgap-transfer.git
cd airgap-transfer
uv sync  # 使用 uv 安装依赖

# 2. 开始传输（你有 5 秒时间切换窗口）
uv run airgap send config.yaml --output /home/user/config.yaml

# 3. 切换到 VDI 终端窗口并保持焦点
# 4. 脚本自动打字并执行
# 5. 在 VDI 终端验证输出：
#    ✓ 文件传输成功！校验和已验证
#    文件保存到：/home/user/config.yaml
```

## 使用场景

### 场景 1：VDI 访问（常见用例）

你需要向/从虚拟桌面基础设施（VDI）传输文件，但有以下限制：
- ✅ 启用了屏幕共享
- ✅ 允许键盘输入
- ❌ 禁用文件传输
- ❌ 禁用剪贴板共享

**解决方案**：使用键盘传输或二维码

#### 向 VDI 发送文件（外部 → VDI）：
```bash
# 在外部机器上运行：
uv run airgap send document.pdf --countdown 10

# 脚本将自动在 VDI 终端中打字
# 文件将被解码并通过 SHA256 验证
```

#### 从 VDI 获取文件（VDI → 外部）：

**步骤 1**：向 VDI 传输发送工具（一次性设置）
```bash
# 在外部机器上，向 VDI 发送编码器脚本
uv run airgap send src/airgap_transfer/qrcode/encoder.py --output ~/qr_sender.py
```

**步骤 2**：在 VDI 中生成二维码
```bash
# 在 VDI 终端（仅需 python3 和 qrcode 包）
python3 qr_sender.py myfile.pdf 5 | ffplay -framerate 1 -f image2pipe -i -
```

**步骤 3**：在外部机器上解码
```bash
# 录制二维码视频，然后：
uv run airgap qr-decode recording.mp4 output.pdf --verify original.pdf
```

### 场景 2：堡垒机

通过具有严格安全控制的跳板机/堡垒机传输文件。

```bash
# 向堡垒机传输脚本
uv run airgap send deployment_script.sh --output /tmp/deploy.sh
```

### 场景 3：气隙网络

向完全隔离的网络传输文件，无任何连接。

```bash
# 在联网系统上编码文件（开发环境）
uv run airgap qr-encode sensitive_data.gpg | ffplay -framerate 1 -f image2pipe -i -

# 在气隙环境中录制屏幕
# 在气隙系统上解码（开发环境）
uv run airgap qr-decode recording.mp4 sensitive_data.gpg

# 或在气隙系统上使用 python3（仅需 qrcode 包）
python3 qr_sender.py sensitive_data.gpg 5 | ffplay -framerate 1 -f image2pipe -i -
```

## 工作原理

### 键盘传输

1. **编码**：文件进行 base64 编码并包装在 bash 脚本中
2. **生成**：脚本包含解码和验证逻辑
3. **打字**：通过模拟键盘逐字符输入内容
4. **执行**：脚本在远程终端自动执行
5. **验证**：SHA256 校验和确认传输成功

### 二维码传输

1. **分块**：文件分割成二维码大小的块
2. **编码**：每个块编码为二维码图像
3. **流式传输**：二维码作为视频序列显示
4. **捕获**：屏幕录制捕获二维码序列
5. **解码**：处理视频以提取和重组文件

## 系统要求

### 系统要求
- **开发环境**：Python 3.9 或更高版本
- **VDI/气隙环境**：Python 3.8 或更高版本（仅 QR 发送端）
- Linux、macOS 或 Windows（键盘传输需要 GUI 支持）

### Python 依赖

**开发环境**（本地机器）：
- 包管理：使用 `uv` 管理依赖
- 基础包：`pynput`（键盘传输）
- 二维码完整功能：`qrcode`、`opencv-python`、`pyzbar`
- 运行命令：使用 `uv run` 前缀

**VDI/气隙环境**（隔离系统，仅 QR 发送端）：
- 仅需安装：`qrcode` 包
- Python 版本：3.8+ 兼容
- 运行命令：使用 `python3` 命令
- 不需要：`opencv-python`、`pyzbar`（这些仅用于解码端）

### 外部工具（用于二维码视频）
- `ffplay` 或 `ffmpeg`（用于播放/录制二维码视频）
- 屏幕录制软件（OBS、QuickTime 等）用于捕获二维码

### 性能预期

| 文件大小 | 传输方法 | 预计时间 | 推荐度 |
|---------|---------|---------|--------|
| < 10 KB | 键盘 | < 1 分钟 | ⭐⭐⭐⭐⭐ |
| 10-100 KB | 键盘 | 1-10 分钟 | ⭐⭐⭐⭐ |
| < 10 KB | 二维码 | < 30 秒 | ⭐⭐⭐⭐⭐ |
| 10-50 KB | 二维码 | 30 秒-2 分钟 | ⭐⭐⭐⭐ |
| > 100 KB | 任一 | > 10 分钟 | ⭐⭐（先压缩）|

## 从旧版脚本迁移

如果你之前使用独立脚本：

```bash
# 旧方式
python transfer_file_v2.py myfile.pdf

# 新方式（开发环境）
uv run airgap send myfile.pdf

# 旧方式
python qrtest_pipe.py myfile.pdf 5 | ffplay -framerate 1 -f image2pipe -i -

# 新方式（开发环境）
uv run airgap qr-encode myfile.pdf | ffplay -framerate 1 -f image2pipe -i -

# VDI 环境（仅使用 python3）
python3 qr_sender.py myfile.pdf 5 | ffplay -framerate 1 -f image2pipe -i -

# 旧方式
python qrdecode_video.py recording.mp4 output.pdf

# 新方式（开发环境）
uv run airgap qr-decode recording.mp4 output.pdf
```

旧版脚本仍在仓库中可供参考。

## 开发

```bash
# 克隆仓库
git clone https://github.com/RLHQ/airgap-transfer.git
cd airgap-transfer

# 使用 uv 安装所有依赖（推荐）
uv sync --extra all --extra dev

# 运行测试（即将推出）
uv run pytest

# 格式化代码
uv run black src/ tests/
uv run ruff check src/ tests/

# 类型检查
uv run mypy src/

# 构建包
uv run python -m build
```

## 项目结构

```
airgap-transfer/
├── src/airgap_transfer/     # 主包
│   ├── keyboard/            # 键盘传输模块
│   ├── qrcode/              # 二维码传输模块
│   ├── cli/                 # 命令行界面
│   ├── utils/               # 实用函数
│   └── installer/           # 安装器模块（计划中）
├── tests/                   # 测试套件
├── examples/                # 示例脚本
├── docs/                    # 文档
└── scripts/                 # 开发脚本
```

## 路线图

### v0.1.0（当前）
- ✅ 键盘传输
- ✅ 二维码传输
- ✅ 统一 CLI
- ✅ Python API
- ✅ 专业项目结构

### v0.2.0（计划中）
- 🔄 气隙环境的安装器模块
- 🔄 独立发送包生成
- 🔄 配置文件支持
- 🔄 增强文档

### v0.3.0（未来）
- 📋 批量传输支持
- 📋 恢复/重试功能
- 📋 压缩支持
- 📋 加密选项

## 环境说明

本项目针对两种不同环境进行了优化：

### 开发环境（本地/外部机器）
- **Python 版本**：3.9+
- **包管理器**：`uv`（推荐）或 `pip`
- **运行方式**：`uv run airgap <command>`
- **功能**：完整功能（键盘传输 + 二维码编码/解码）
- **依赖**：所有依赖包（pynput、qrcode、opencv-python、pyzbar）

### VDI/气隙环境（隔离系统）
- **Python 版本**：3.8+（使用系统自带 python3）
- **包管理器**：系统 pip（通常受限）
- **运行方式**：`python3 <script>.py`
- **功能**：仅 QR 编码发送（用于从 VDI 导出文件）
- **依赖**：仅需 `qrcode` 包（通常已预装）
- **特点**：轻量级，最小依赖，适合受限环境

## 安全注意事项

⚠️ **重要安全提示**：

- 此工具设计用于对隔离系统的**合法管理访问**
- 所有传输应符合组织的安全策略
- 文件默认**不加密** - 如需要请使用 GPG 等工具
- 屏幕录制可能对他人可见 - 注意周围环境
- 键盘传输在远程系统上创建**临时文件**
- 始终**验证校验和**以确保数据完整性

## 贡献

欢迎贡献！我们希望在以下方面获得帮助：
- 📖 文档改进
- 🧪 更多测试覆盖
- 🐛 错误报告和修复
- 💡 功能建议
- 🌍 翻译

## 许可证

本项目采用 MIT 许可证 - 详见 [LICENSE](LICENSE) 文件。

## 致谢

- 受访问隔离环境的实际挑战启发
- 使用 [pynput](https://pypi.org/project/pynput/)、[qrcode](https://pypi.org/project/qrcode/) 和 [OpenCV](https://opencv.org/) 构建
- 感谢所有贡献者和用户！

---

**注意**：此工具仅供授权使用。在向/从隔离系统传输文件之前，请务必获得适当的权限。
