from pathlib import Path

from esprit.model import SpreadsheetModel
from esprit.services.file_service import FileActions


def test_file_actions_save_and_load(tmp_path: Path) -> None:
    model = SpreadsheetModel()
    model.set_title("Test Sheet")
    model.set_cell(0, 0, "hello")

    actions = FileActions(model)
    destination = tmp_path / "sheet.json"

    saved_path, message, severity, success = actions.save(destination)
    assert saved_path == destination
    assert success is True
    assert severity == "information"
    assert "Saved" in message

    new_model = SpreadsheetModel()
    loader = FileActions(new_model)
    succeeded, load_message, load_severity = loader.load(destination)
    assert succeeded is True
    assert load_severity == "information"
    assert "Loaded" in load_message
    assert new_model.get_title() == "Test Sheet"
    assert new_model.get_cell(0, 0) == "hello"
