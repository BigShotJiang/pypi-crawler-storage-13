"""Tests for the TableManager helper."""

from esprit.model import SpreadsheetModel
from esprit.ui.table_manager import TableManager


class DummyTable:
    def __init__(self):
        self.last_call: tuple[tuple[int, int], str] | None = None

    def update_cell(self, *_, **__):
        raise AssertionError("TableManager should use update_cell_at")

    def update_cell_at(self, coordinate: tuple[int, int], value: str) -> None:
        self.last_call = (coordinate, value)


class DummyLabel:
    def __init__(self):
        self.rendered = ""

    def update(self, text: str) -> None:
        self.rendered = text


def test_update_cell_uses_coordinate_api() -> None:
    model = SpreadsheetModel()
    model.set_cell(0, 0, "Updated")

    table = DummyTable()
    status = DummyLabel()
    manager = TableManager(model, table, status)

    manager.update_cell(0, 0)

    assert table.last_call == ((0, 1), "Updated")
