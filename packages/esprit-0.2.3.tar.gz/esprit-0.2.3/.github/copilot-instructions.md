# Repository Guidelines

## Project Structure & Module Organization

- `esprit/app.py` hosts the Textual `SpreadsheetApp` and wires controllers, services, and UI helpers together. Keep it thin—delegate logic to the purpose-built modules below.
- `esprit/main.py` remains the CLI entry point. Extend CLI parsing here, not in `app.py`.
- `esprit/model.py` owns spreadsheet metadata, typed cell parsing/formatting, and JSON serialization. Reuse its helpers (e.g., `parse_url_input`, `sort_by_column`) anywhere data needs to stay consistent.
- `esprit/config.py` (plus `sample-config.toml`) defines `EspritConfig` and loads user overrides from `~/.config/esprit/config.toml`. Add runtime settings here, then thread them through `SpreadsheetApp`.
- `esprit/dialogs.py` now keeps Textual dialog widgets such as `InitDialog`. Add new modal UX here rather than inline in the app.
- `esprit/controllers/` contains input-focused controllers (`CellEditController`, `CommandPrompt`). Use this package for future workflow or stateful input managers.
- `esprit/services/` contains non-UI logic that still touches Textual widgets: `FileActions` handles load/save and `RowService` manages row mutations. Introduce new services when logic grows beyond a few lines in the app layer.
- `esprit/ui/` contains view utilities (`table_manager.TableManager`) and `ui/spreadsheet.tcss`. Any presentation-specific helper should live here.
- `esprit/utils/` holds generic helpers like `textual_helpers.requires_cursor`. Prefer reusing these decorators before duplicating guard logic in the app.
- `tests/` mirrors runtime modules: `test_model.py`, `test_services.py`, `test_table_manager.py`, plus fixtures such as `tests/spreadsheet.json`. Add new suites following the same structure.

## Build, Test, and Development Commands
- `uv venv && source .venv/bin/activate` — create and activate a Python 3.12 virtual environment (preferred for all work).
- `python -m pip install -e .` — install esprit in editable mode along with Textual/Rich runtime dependencies.
- `esprit` — launch the terminal UI; accepts the same key bindings documented in `SpreadsheetApp.BINDINGS`.
- `pytest` — run the growing test suite (add `pytest` to your dev environment if not already present).

## Coding Style & Naming Conventions
- Use ruff check/format
- Use type hints
- Run mypy to confirm type checks

## TUI

- esprit uses Textual for its TUI framework
- Refer to Textual reference and documentation for proper use: https://textual.textualize.io/reference/
- Textual CSS is not standard CSS in a browser, similar but confirm properties exist before making up and using. https://textual.textualize.io/css_types/


## Commit & Pull Request Guidelines

- Do not issue any git commands
- This project uses jujutsu vcs (jj)

## Configuration & Data Tips

- Persist spreadsheets using `SpreadsheetModel.to_json()` and deserialize with `SpreadsheetModel.from_json()` so column counts and metadata stay aligned.
- Sample spreadsheet data lives in `tests/spreadsheet.json`; use it (or add to `tests/data/`) for manual verification.
- `metadata.columns` defines display names and field types (`string`, `number`, `boolean`, `url`). Always adjust `model.cols` when changing metadata so `TableManager` renders correctly.
- `cells` uses `"row,col"` keys. Keep `model.rows` and `model.cols` synchronized before calling into `TableManager.refresh_all()`.
- URL cells persist as `{"title": "Spec", "url": "https://…"}`. `CellEditController` expects the `Title | https://` format; reuse its helpers when adding new entry points to edit URLs.
- Boolean and number parsing already lives in the model. Call `parse_boolean_input` / `parse_number_input` instead of reimplementing validation.
- In-app editing of URL cells accepts `Title | https://…` and `ctrl+enter` launches the stored link (guarded by `action_open_link`).
- Respect Textual’s async event loop: avoid long-running blocking calls inside action handlers. Move I/O to worker threads or preprocess data before attaching it to the UI.


## Instructions

- Do not run git commands. The repo is managed using jujutsu (jj-vcs) and is
  typically in a detached head state.

- Code coverage is a game, do not play it. We don't need "pragma: no cover" or
  coverage reports. Focus on writing clear, maintainable code and meaningful tests
  instead.