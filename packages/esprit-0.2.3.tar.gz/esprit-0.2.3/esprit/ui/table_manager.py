"""Helpers for keeping the DataTable in sync with the spreadsheet model."""

from __future__ import annotations

from textual.widgets import DataTable, Label

from ..model import SpreadsheetModel


class TableManager:
    """Keeps the Textual DataTable synchronized with the SpreadsheetModel."""

    def __init__(self, model: SpreadsheetModel, table: DataTable, status_label: Label):
        self._model = model
        self.table = table
        self._status = status_label

    def initialize(self) -> None:
        """Configure defaults and render the initial table."""
        self.table.cursor_type = "cell"
        self.refresh_all()

    def refresh_all(self) -> None:
        """Rebuild the entire table from model metadata and cells."""
        self.table.clear(columns=True)
        columns = [""] + self._model.get_column_headers()
        self.table.add_columns(*columns)

        for row in range(self._model.rows):
            row_values = [str(row + 1)]
            for col in range(self._model.cols):
                row_values.append(self._cell_display_value(row, col))
            self.table.add_row(*row_values, key=f"row_{row}")

    def update_cell(self, row: int, col: int) -> None:
        """Update a single cell value without rebuilding the full table."""
        if not (0 <= row < self._model.rows and 0 <= col < self._model.cols):
            self.refresh_all()
            return

        display_value = self._cell_display_value(row, col)
        try:
            self.table.update_cell_at((row, col + 1), display_value)
        except (KeyError, ValueError):
            # Fallback if the DataTable structure changed unexpectedly.
            self.refresh_all()

    def update_status(self, row: int, col: int) -> None:
        """Refresh the status bar text based on the active cell."""
        if not (0 <= row < self._model.rows and 0 <= col < self._model.cols):
            self._status.update("")
            return

        if self._model.get_column_type(col) == "url":
            text = self._model.get_cell_status_text(row, col)
            self._status.update(text or "")
            return

        self._status.update("")

    def _cell_display_value(self, row: int, col: int) -> str:
        value = self._model.get_cell(row, col)
        return value if value else " " * 4
