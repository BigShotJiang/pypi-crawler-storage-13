"""Textual application for the Esprit structured table editor."""

import webbrowser
from pathlib import Path
from typing import Optional
from textual.app import App, Binding, ComposeResult
from textual.coordinate import Coordinate
from textual.widgets import DataTable, Footer, Header, Input, Label

from .config import EspritConfig, load_config
from .controllers.command_prompt import CommandPrompt
from .controllers.edit_controller import CellEditController
from .dialogs import InitDialog
from .model import SpreadsheetModel
from .services.file_service import FileActions
from .services.row_service import RowService
from .ui.table_manager import TableManager
from .utils.textual_helpers import requires_cursor


class SpreadsheetApp(App):
    CSS_PATH = "ui/spreadsheet.tcss"

    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit"),
        Binding("ctrl+i", "insert_row", "Ins Row"),
        Binding("ctrl+k", "delete_row", "Del Row"),
        Binding("alt+up", "move_row_up", "Move Row Up"),
        Binding("alt+down", "move_row_down", "Move Row Down"),
        Binding("ctrl+enter", "open_link", "Open Link", show=False),
        Binding("enter", "edit_cell", "Edit"),
        Binding("escape", "cancel_edit", "Cancel", show=False),
        Binding("s", "sort_column", "Sort"),
    ]

    # Disable command palette
    ENABLE_COMMAND_PALETTE = False

    def __init__(self, start_file: Optional[Path] = None):
        super().__init__()
        self.config: EspritConfig = load_config()
        self.model = SpreadsheetModel()
        self.current_file: Optional[Path] = None
        self.input_mode: Optional[str] = None  # Can be: None, "cell_edit", "command"
        self.start_file = start_file
        self.dirty = False
        self.default_input_placeholder = "Enter cell value..."
        self.init_dialog: Optional[InitDialog] = None
        self.theme = self.config.theme
        self._last_sorted_column: Optional[int] = None
        self._sort_ascending = True
        self.table_manager: Optional[TableManager] = None
        self.edit_controller: Optional[CellEditController] = None
        self.command_prompt: Optional[CommandPrompt] = None
        self.row_service: Optional[RowService] = None
        self.file_actions = FileActions(self.model)

    def compose(self) -> ComposeResult:
        yield Header()
        yield DataTable(id="spreadsheet")
        yield Label("", id="status")
        yield Input(placeholder=self.default_input_placeholder, id="cell_input")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#spreadsheet", DataTable)
        status = self.query_one("#status", Label)
        cell_input = self.query_one("#cell_input", Input)

        self.table_manager = TableManager(self.model, table, status)
        self.file_actions.attach_table_manager(self.table_manager)
        self.table_manager.initialize()

        self.row_service = RowService(self.model, self.table_manager)
        self.edit_controller = CellEditController(
            self.model,
            cell_input,
            self.table_manager,
            self.default_input_placeholder,
            self.notify,
        )
        self.command_prompt = CommandPrompt(cell_input, self.default_input_placeholder)

        if self.start_file and not self.start_file.exists():
            self.show_init_dialog()
            return

        self.title = self.model.get_title()

        if self.start_file and self.start_file.exists():
            self.load_file(self.start_file)

    def update_status(self, row: int, col: int) -> None:
        if self.table_manager is None:
            return
        self.table_manager.update_status(row, col)

    def on_data_table_cell_selected(self, event: DataTable.CellSelected) -> None:
        if event.coordinate.column != 0:  # Skip row number column
            col = event.coordinate.column - 1  # Adjust for row number column
            row = event.coordinate.row
            self.update_status(row, col)

    def on_data_table_cell_highlighted(self, event: DataTable.CellHighlighted) -> None:
        if event.coordinate.column != 0:  # Skip row number column
            col = event.coordinate.column - 1  # Adjust for row number column
            row = event.coordinate.row
            self.update_status(row, col)

    def on_key(self, event) -> None:
        if self.init_dialog is not None:
            return
        if event.key == "enter" and self.input_mode is None:
            table = self.query_one("#spreadsheet", DataTable)
            coordinate = table.cursor_coordinate
            is_last_row = coordinate.row == self.model.rows - 1
            if coordinate.column == 0 and is_last_row:
                self._append_row_at_end()
            else:
                self.action_edit_cell()
            event.prevent_default()

    @requires_cursor(require_data_column=True)
    def action_edit_cell(self, table: DataTable, coordinate: Coordinate) -> None:
        if self.edit_controller is None:
            return
        col = coordinate.column - 1
        row = coordinate.row
        self.edit_controller.begin_edit(row, col)
        self.input_mode = "cell_edit"

    def action_cancel_edit(self) -> None:
        if self.input_mode == "cell_edit" and self.edit_controller is not None:
            self.edit_controller.cancel()
            self.input_mode = None
        elif self.input_mode == "command" and self.command_prompt is not None:
            self.command_prompt.cancel()
            self.input_mode = None
        table = self.query_one("#spreadsheet", DataTable)
        table.focus()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if self.input_mode == "cell_edit":
            if self.edit_controller is None:
                return
            if self.edit_controller.commit(event.input.value):
                self.is_dirty = True
                self.input_mode = None
                table = self.query_one("#spreadsheet", DataTable)
                table.focus()
        elif self.input_mode == "command" and self.command_prompt is not None:
            self.input_mode = None
            self.command_prompt.consume(event.input.value)
            table = self.query_one("#spreadsheet", DataTable)
            table.focus()

    def action_save(self) -> None:
        destination, message, severity, success = self.file_actions.save(
            self.current_file
        )
        self.notify(message, severity=severity)
        if success:
            self.current_file = destination
            self.is_dirty = False

    def load_file(self, file_path: Path) -> None:
        success, message, severity = self.file_actions.load(file_path)
        self.notify(message, severity=severity)
        if success:
            self.current_file = file_path
            self.title = self.model.get_title()
            self.is_dirty = False

    def action_quit(self):
        if self.is_dirty:
            self.action_save()

        self.exit()

    @requires_cursor(require_data_column=True)
    def action_open_link(self, table: DataTable, coordinate: Coordinate) -> None:
        row = coordinate.row
        col = coordinate.column - 1
        if self.model.get_column_type(col) != "url":
            self.notify("Select a URL column cell to open", severity="warning")
            return
        href = self.model.get_cell_url(row, col)
        if href:
            webbrowser.open(href)
        else:
            self.notify("No URL set for this cell", severity="warning")

    @requires_cursor(require_data_column=True, warning="Select a column to sort")
    def action_sort_column(self, table: DataTable, coordinate: Coordinate) -> None:
        sort_column = coordinate.column - 1

        if self._last_sorted_column == sort_column:
            self._sort_ascending = not self._sort_ascending
        else:
            self._last_sorted_column = sort_column
            self._sort_ascending = True

        self.model.sort_by_column(sort_column, ascending=self._sort_ascending)
        self.is_dirty = True

        cursor_row = coordinate.row
        cursor_col = coordinate.column
        if self.table_manager is not None:
            self.table_manager.refresh_all()
        table.move_cursor(row=cursor_row, column=cursor_col)

    @requires_cursor()
    def action_insert_row(self, table: DataTable, coordinate: Coordinate) -> None:
        if self.row_service is None:
            return
        self.row_service.insert(table, coordinate.row, coordinate.column)
        self.is_dirty = True

    def _append_row_at_end(self) -> None:
        """Append an empty row to the end of the spreadsheet."""
        if self.row_service is None:
            return
        table = self.query_one("#spreadsheet", DataTable)
        self.row_service.append(table)
        self.is_dirty = True

    @requires_cursor()
    def action_delete_row(self, table: DataTable, coordinate: Coordinate) -> None:
        if self.row_service is None:
            return
        if self.model.rows <= 1:
            self.notify("Cannot delete the last row", severity="warning")
            return
        self.row_service.delete(table, coordinate.row, coordinate.column)
        self.is_dirty = True

    @requires_cursor()
    def action_move_row_up(self, table: DataTable, coordinate: Coordinate) -> None:
        if self.row_service is None:
            return
        if coordinate.row == 0:
            return
        self.row_service.move_up(table, coordinate.row, coordinate.column)
        self.is_dirty = True

    @requires_cursor()
    def action_move_row_down(self, table: DataTable, coordinate: Coordinate) -> None:
        if self.row_service is None:
            return
        if coordinate.row >= self.model.rows - 1:
            return
        self.row_service.move_down(table, coordinate.row, coordinate.column)
        self.is_dirty = True

    def show_init_dialog(self) -> None:
        """Show the initialization dialog for creating a new spreadsheet."""
        if self.init_dialog is None:
            self.init_dialog = InitDialog(self._handle_init_complete)
            self.mount(self.init_dialog)

    def _handle_init_complete(self, data: dict | None) -> None:
        """Handle completion of the init dialog."""
        self.init_dialog = None
        if data:
            # Initialize model with the specified title and columns
            columns = data.get("columns", [])
            title = data.get("title", "Untitled Spreadsheet")
            self.model.metadata = {"title": title, "columns": columns}
            self.model.cols = len(columns)
            self.model.rows = 20  # Default number of rows
            self.model.cells = {}
            self.current_file = self.start_file
            self.title = title
            if self.table_manager is not None:
                self.table_manager.refresh_all()
            self.is_dirty = True
            self.notify(f"Initialized new spreadsheet with {len(columns)} columns")
        else:
            # User cancelled, exit the application
            self.exit()
