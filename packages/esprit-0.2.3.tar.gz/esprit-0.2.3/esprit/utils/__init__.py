"""Utility helpers for Textual integration."""
