"""Decorators and helpers shared across Textual actions."""

from __future__ import annotations

from functools import wraps
from typing import Any, Callable, Concatenate, ParamSpec, TypeVar

from textual.coordinate import Coordinate
from textual.widgets import DataTable

P = ParamSpec("P")
R = TypeVar("R")


def requires_cursor(
    require_data_column: bool = False, warning: str | None = None
) -> Callable[
    [Callable[Concatenate[Any, DataTable, Coordinate, P], R]],
    Callable[Concatenate[Any, P], R | None],
]:
    """Decorator ensuring an action has access to a live cursor selection."""

    def decorator(
        func: Callable[Concatenate[Any, DataTable, Coordinate, P], R],
    ) -> Callable[Concatenate[Any, P], R | None]:
        @wraps(func)
        def wrapper(self: Any, *args: P.args, **kwargs: P.kwargs) -> R | None:
            if getattr(self, "init_dialog", None) is not None:
                return None
            if getattr(self, "input_mode", None) is not None:
                return None

            table = self.query_one("#spreadsheet", DataTable)
            coordinate = table.cursor_coordinate
            if coordinate is None:
                return None

            if require_data_column and coordinate.column == 0:
                if warning and hasattr(self, "notify"):
                    self.notify(warning, severity="warning")
                return None

            return func(self, table, coordinate, *args, **kwargs)

        return wrapper

    return decorator
