"""Domain services for file and row operations."""
