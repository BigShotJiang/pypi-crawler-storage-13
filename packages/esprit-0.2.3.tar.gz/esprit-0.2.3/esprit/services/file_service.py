"""File I/O helpers for SpreadsheetApp."""

from __future__ import annotations

from pathlib import Path
from textual.app import SeverityLevel
from typing import Optional

from ..model import SpreadsheetModel
from ..ui.table_manager import TableManager


class FileActions:
    def __init__(
        self, model: SpreadsheetModel, table_manager: TableManager | None = None
    ):
        self._model = model
        self._table_manager = table_manager

    def attach_table_manager(self, manager: TableManager) -> None:
        self._table_manager = manager

    def save(
        self, current_file: Optional[Path]
    ) -> tuple[Optional[Path], str, SeverityLevel, bool]:
        """Persist the spreadsheet to disk."""
        destination = current_file or Path("spreadsheet.json")
        try:
            destination.write_text(self._model.to_json())
            return destination, f"Saved to {destination}", "information", True
        except Exception as exc:
            return current_file, f"Error saving: {exc}", "error", False

    def load(self, file_path: Path) -> tuple[bool, str, SeverityLevel]:
        """Load a spreadsheet from disk, updating the DataTable when possible."""
        try:
            contents = file_path.read_text()
        except FileNotFoundError:
            return False, f"{file_path} not found", "warning"
        except Exception as exc:
            return False, f"Error opening {file_path}: {exc}", "error"

        self._model.from_json(contents)
        if self._table_manager is not None:
            self._table_manager.refresh_all()
        return True, f"Loaded {file_path}", "information"
