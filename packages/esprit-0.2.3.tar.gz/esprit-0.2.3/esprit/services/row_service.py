"""Row manipulation helpers for SpreadsheetApp."""

from __future__ import annotations

from textual.widgets import DataTable

from ..model import SpreadsheetModel
from ..ui.table_manager import TableManager


class RowService:
    def __init__(self, model: SpreadsheetModel, table_manager: TableManager):
        self._model = model
        self._table_manager = table_manager

    def insert(self, table: DataTable, row: int, column: int) -> None:
        self._model.insert_row(row)
        self._table_manager.refresh_all()
        table.move_cursor(row=row, column=column)

    def append(self, table: DataTable) -> None:
        new_row = self._model.rows
        self._model.insert_row(new_row)
        self._table_manager.refresh_all()
        table.move_cursor(row=new_row, column=0)

    def delete(self, table: DataTable, row: int, column: int) -> None:
        self._model.delete_row(row)
        self._table_manager.refresh_all()
        new_row = min(row, self._model.rows - 1)
        table.move_cursor(row=new_row, column=column)

    def move_up(self, table: DataTable, row: int, column: int) -> None:
        self._model.swap_rows(row, row - 1)
        self._table_manager.refresh_all()
        table.move_cursor(row=row - 1, column=column)

    def move_down(self, table: DataTable, row: int, column: int) -> None:
        self._model.swap_rows(row, row + 1)
        self._table_manager.refresh_all()
        table.move_cursor(row=row + 1, column=column)
