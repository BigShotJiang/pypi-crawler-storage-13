"""Controller for cell edit workflows."""

from __future__ import annotations

from typing import Callable, Optional

from textual.widgets import Input

from ..model import SpreadsheetModel
from ..ui.table_manager import TableManager

NotificationFunc = Callable[..., None]


class CellEditController:
    """Manages edit-mode input for spreadsheet cells."""

    def __init__(
        self,
        model: SpreadsheetModel,
        input_widget: Input,
        table_manager: TableManager,
        default_placeholder: str,
        notify: NotificationFunc,
    ) -> None:
        self._model = model
        self._input = input_widget
        self._table_manager = table_manager
        self._default_placeholder = default_placeholder
        self._notify = notify
        self._target_cell: Optional[tuple[int, int]] = None

    def begin_edit(self, row: int, col: int) -> None:
        """Display the input widget configured for the requested cell."""
        placeholder, value = self._input_state_for(row, col)
        self._target_cell = (row, col)
        self._input.placeholder = placeholder
        self._input.value = value
        self._input.display = True
        self._input.focus()

    def commit(self, raw_value: str) -> bool:
        """Persist the edited value back into the model."""
        if self._target_cell is None:
            return False

        row, col = self._target_cell
        if not self._apply_value(row, col, raw_value):
            return False

        self._table_manager.update_cell(row, col)
        self._target_cell = None
        self._reset_input()
        return True

    def cancel(self) -> None:
        """Abort the current edit session."""
        self._target_cell = None
        self._reset_input()

    def _input_state_for(self, row: int, col: int) -> tuple[str, str]:
        column_type = self._model.get_column_type(col)
        if column_type == "url":
            value = self._model.get_url_edit_value(row, col)
            return "Title | https://example.com", value
        if column_type == "number":
            raw_value = self._model.get_cell_raw(row, col)
            return "Enter a number...", "" if raw_value is None else str(raw_value)
        if column_type == "boolean":
            raw_value = self._model.get_cell_raw(row, col)
            if raw_value is True:
                return "true/false, yes/no, 1/0", "true"
            if raw_value is False:
                return "true/false, yes/no, 1/0", "false"
            return "true/false, yes/no, 1/0", ""
        return self._default_placeholder, self._model.get_cell(row, col)

    def _apply_value(self, row: int, col: int, raw_value: str) -> bool:
        column_type = self._model.get_column_type(col)
        value = raw_value or ""

        if column_type == "url":
            title, href = self._model.parse_url_input(value)
            if not title and not href:
                self._model.set_cell(row, col, "")
            else:
                self._model.set_cell(row, col, {"title": title, "url": href})
            return True

        if column_type == "number":
            is_valid, parsed = self._model.parse_number_input(value)
            if not is_valid:
                self._notify("Invalid number format", severity="error")
                return False
            self._model.set_cell(row, col, parsed)
            return True

        if column_type == "boolean":
            is_valid, parsed = self._model.parse_boolean_input(value)
            if not is_valid:
                self._notify(
                    "Invalid boolean value (use true/false, yes/no, 1/0)",
                    severity="error",
                )
                return False
            self._model.set_cell(row, col, parsed)
            return True

        self._model.set_cell(row, col, value)
        return True

    def _reset_input(self) -> None:
        self._input.display = False
        self._input.value = ""
        self._input.placeholder = self._default_placeholder
