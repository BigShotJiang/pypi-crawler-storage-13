"""Command prompt helper built on top of the shared Input widget."""

from __future__ import annotations

from typing import Callable, Optional

from textual.widgets import Input


class CommandPrompt:
    def __init__(self, input_widget: Input, default_placeholder: str):
        self._input = input_widget
        self._default_placeholder = default_placeholder
        self._callback: Optional[Callable[[str], None]] = None

    def prompt(self, prompt_text: str, callback: Callable[[str], None]) -> None:
        """Show the command input and store its completion callback."""
        self._callback = callback
        self._input.placeholder = prompt_text
        self._input.value = ""
        self._input.display = True
        self._input.focus()

    def consume(self, raw_value: str) -> None:
        """Submit the user's response to the stored callback."""
        callback = self._callback
        self._callback = None
        value = raw_value.strip().lower()
        self._reset_input()
        if callback:
            callback(value)

    def cancel(self) -> None:
        """Hide the prompt without triggering the callback."""
        self._callback = None
        self._reset_input()

    def is_active(self) -> bool:
        return self._callback is not None

    def _reset_input(self) -> None:
        self._input.display = False
        self._input.value = ""
        self._input.placeholder = self._default_placeholder
