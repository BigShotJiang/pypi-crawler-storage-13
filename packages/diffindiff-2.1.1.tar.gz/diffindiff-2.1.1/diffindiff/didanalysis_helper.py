#-----------------------------------------------------------------------
# Name:        didanalysis_helper (diffindiff package)
# Purpose:     Helper functions for didanalysis module
# Author:      Thomas Wieland 
#              ORCID: 0000-0001-5168-9846
#              mail: geowieland@googlemail.com              
# Version:     1.0.0
# Last update: 2025-11-22 10:23
# Copyright (c) 2025 Thomas Wieland
#-----------------------------------------------------------------------

import pandas as pd
import statsmodels.api as sm
from statsmodels.formula.api import ols
from patsy import dmatrices
import diffindiff.didtools as tools
import diffindiff.config as config


def create_fixed_effects(
    data: pd.DataFrame,
    col: str,
    type: str = "unit",
    drop_first: bool = False,
    verbose: bool = config.VERBOSE
    ):
     
    if type not in config.FE_TYPES:
        raise ValueError(f"Parameter 'type' must be one of the following: {', '.join(config.FE_TYPES)}")

    for key, value in config.EFFECTS_TYPES["FE"]["types"].items():

        if value["FE"] == type:
            
            prefix = value["dummy_prefix"]
            
            if verbose:
                print(f"Creating {value['description']} for column '{col}' with prefix '{prefix}{config.DELIMITER}'", end = " ... ")
    
    dummy_unit_original = list(data[col].astype(str).unique())
    
    dummy_unit_vars = [f"{prefix}{config.DELIMITER}{tools.clean_column_name(val)}" for val in dummy_unit_original]    
    
    dummies = pd.DataFrame(
        pd.get_dummies(
            data = data[col].astype(str),
            dtype = int,
            prefix = prefix,
            prefix_sep = config.DELIMITER,
            drop_first = drop_first
            )
        )

    dummies.columns = [tools.clean_column_name(col) for col in dummies.columns]

    data = pd.concat([data, dummies], axis=1)

    dummies_join = " + ".join(dummies.columns)

    if verbose:
        print("OK")

    return [
        data, 
        dummies_join, 
        dummy_unit_vars,
        dummy_unit_original
        ]

def create_specific_time_trends(    
    data: pd.DataFrame,
    time_col: str,
    FE_vars: list,
    type: str = "ITT",
    verbose: bool = config.VERBOSE
    ):
    
    if type not in config.TIME_TRENDS_TYPES:
        raise ValueError(f"Parameter 'type' must be one of the following: {', '.join(config.TIME_TRENDS_TYPES)}")
    
    tools.check_columns(
        df = data,
        columns = FE_vars,
        verbose = verbose
        )
    
    data = tools.date_counter(
        data,
        time_col,
        new_col=config.TIME_COUNTER_COL,
        verbose = verbose
        )
    
    if verbose:
        print(f"Creating {config.EFFECTS_TYPES[type]['description']} for {len(FE_vars)} entities with suffix '{config.DELIMITER}{config.TIME_COL}'", end = " ... ")
    
    id_x_time = pd.DataFrame()
    
    for col in FE_vars:
        
        if col in data.columns:
            
            id_x_time[col] = data[col] * data[config.TIME_COUNTER_COL]
            new_col_name = f"{col}{config.DELIMITER_INTERACT}{config.TIME_COL}"
            id_x_time = id_x_time.rename(columns={col: new_col_name})
            
    data = pd.concat([data, id_x_time], axis = 1)
    
    time_trend_vars = id_x_time.columns
    id_x_time_join = " + ".join(time_trend_vars)
    
    if verbose:
        print("OK")
    
    return [
        data, 
        id_x_time_join, 
        time_trend_vars
        ]

def create_specific_treatment_effects(
    data: pd.DataFrame,
    treatment_col: list,
    FE_vars: list,
    type: str = "ITE",
    verbose: bool = config.VERBOSE
    ):
    
    if type not in config.SPECIFIC_EFFFECTS_TYPES:
        raise ValueError(f"Parameter 'type' must be one of the following: {', '.join(config.SPECIFIC_EFFFECTS_TYPES)}")
    
    tools.check_columns(
        df = data,
        columns = FE_vars,
        verbose = verbose
        )
    
    if verbose:
        print(f"Creating {config.EFFECTS_TYPES[type]['description']} for {len(FE_vars)} entities and {len(treatment_col)} treatments", end = " ... ")
        
    id_x_treatment = pd.DataFrame()
            
    for col in FE_vars:
        
        if col in data.columns:
        
            for treatment in treatment_col:
                
                id_x_treatment[col] = data[col] * data[treatment]
                new_col_name = f"{treatment}{config.DELIMITER}{col}{config.DELIMITER_INTERACT}{config.TIME_COL}"
                id_x_treatment = id_x_treatment.rename(columns={col: new_col_name})
                
    data = pd.concat([data, id_x_treatment], axis = 1)
    
    id_treatment_vars = id_x_treatment.columns
    id_x_treatment_join = ' + '.join(id_treatment_vars)
    
    return [
        data, 
        id_x_treatment_join, 
        id_treatment_vars
        ]
        
def create_spillover(
    data: pd.DataFrame,
    unit_col: str,
    treatment_col: list,
    spillover_treatment: list = [],
    spillover_units: list = [],
    verbose: bool = config.VERBOSE
    ):

    if spillover_treatment is None or spillover_treatment == []:
        raise ValueError("Parameter 'spillover_treatment' does not contain any treatment")
    if spillover_units is None or treatment_col == []:
        raise ValueError("Parameter 'spillover_units' does not contain any treatment")

    if verbose:
        print(f"Creating spillover variables for treatment(s) {', '.join(treatment_col)} and {len(spillover_units)} units", end = " ... ")

    spillover_unit_vars = []
    spillover_treatment_vars = []

    for i, treatment in enumerate(treatment_col):

        data[f"Spillover_unit_{treatment}"] = 0
        data[f"Spillover_{treatment}"] = 0

        spillover_unit_vars.append(f"Spillover_unit_{treatment}")
        spillover_unit_vars.append(f"Spillover_{treatment}")

        data.loc[data[unit_col].astype(str).isin(spillover_units), f"Spillover_unit_{treatment}"] = 1
        data.loc[data[unit_col].astype(str).isin(spillover_units), f"Spillover_{treatment}"] = data.loc[data[unit_col].astype(str).isin(spillover_units), f"Spillover_unit_{treatment}"]*data.loc[data[unit_col].astype(str).isin(spillover_units), treatment]

    spillover_treatment_vars_join = ' + '.join(spillover_treatment_vars)

    if verbose:
        print("OK")

    return [
        data,
        spillover_treatment_vars_join,
        spillover_treatment_vars
        ]

def data_diagnostics(
    data: pd.DataFrame,
    unit_col: str,
    time_col: str,
    outcome_col: str,
    cols_relevant: list = [],
    drop_missing: bool = True,
    missing_replace_by_zero: bool = False,
    verbose: bool = config.VERBOSE
    ):

    modeldata_ismissing = tools.is_missing(
        data, 
        drop_missing = drop_missing,
        missing_replace_by_zero = missing_replace_by_zero,
        verbose = verbose
        )    

    if modeldata_ismissing[0]:        

        if drop_missing or missing_replace_by_zero:
            data = modeldata_ismissing[2]           

        if not drop_missing and not missing_replace_by_zero:
            print("WARNING: Missing values are not cleaned. Model may crash.")   
    
    other_cols_relevant = [col for col in cols_relevant if col not in [unit_col, time_col, outcome_col]]

    modeldata_isbalanced = tools.is_balanced(
        data = data,
        unit_col = unit_col,
        time_col = time_col,
        outcome_col = outcome_col,
        other_cols = other_cols_relevant,
        verbose = verbose
        )
    
    data_diagnostics = {
        "is_balanced": modeldata_isbalanced, 
        "is_missing": modeldata_ismissing[0], 
        "drop_missing": drop_missing, 
        "missing_replace_by_zero": missing_replace_by_zero
        }
    
    return data_diagnostics

def treatment_diagnostics(
    data: pd.DataFrame,
    unit_col: str,
    time_col: str,
    treatment_col: list,
    outcome_col: str,
    pre_post: bool = False,
    confint_alpha = 0.05,
    verbose: bool = config.VERBOSE    
    ):
    
    if verbose:
        print("Treatment diagnostics:")

    no_treatments = len(treatment_col)

    treatment_diagnostics_results = {}

    staggered_adoption = False

    for i, treatment in enumerate(treatment_col):    
        is_notreatment_result = tools.is_notreatment(
            data = data,
            unit_col = unit_col,
            treatment_col = treatment,
            verbose = verbose 
            )        
        is_parallel_result = tools.is_parallel(
            data = data,
            unit_col = unit_col,
            time_col = time_col,
            treatment_col = treatment,
            outcome_col = outcome_col,
            pre_post = pre_post,
            alpha = confint_alpha,
            verbose = verbose
            )        
        is_simultaneous_result = tools.is_simultaneous(
            data = data,
            unit_col = unit_col,
            time_col = time_col,
            treatment_col = treatment,
            verbose = verbose
            )        
        is_binary_result = tools.is_binary(
            data = data,
            treatment_col = treatment,
            verbose = verbose
            )
        
        treatment_diagnostics_results[i] = { 
            "treatment": treatment,
            "is_notreatment": is_notreatment_result[0],
            "treatment_group": is_notreatment_result[1],
            "control_group": is_notreatment_result[2],
            "is_parallel": is_parallel_result[0],
            "is_simultaneous": is_simultaneous_result,
            "is_binary": is_binary_result[0],
            "treatment_format": is_binary_result[1]
            }

    staggered_count = 0
    for key, value in treatment_diagnostics_results.items():
        if not value["is_simultaneous"]:
            staggered_count = staggered_count+1
    if staggered_count > 0:
        staggered_adoption = True

    untreated = tools.untreated_units(
        data = data,
        unit_col = unit_col,
        treatment_col = treatment_col,
        verbose = verbose
        )
    
    if verbose:
        print(f"There are {no_treatments} treatments (simultaneous: {no_treatments-staggered_count}, staggered: {staggered_count}) with {untreated[0]} treated and {untreated[1]} untreated units.")

    return [
        treatment_diagnostics_results,
        staggered_adoption,
        untreated
    ]

def ols_fit(
    data,
    formula,
    confint_alpha = 0.05    
    ):
    
    ols_model = ols(
        formula, 
        data = data
        ).fit()
    
    ols_coef = ols_model.params
    ols_coef_se = ols_model.bse
    ols_coef_t = ols_model.tvalues
    ols_coef_p = ols_model.pvalues
    ols_coef_ci = ols_model.conf_int(alpha = confint_alpha)
    
    ols_predictions = ols_model.get_prediction(data).summary_frame(alpha=confint_alpha)
    
    return [
        ols_model,
        ols_coef,
        ols_coef_se,
        ols_coef_t,
        ols_coef_p,
        ols_coef_ci,
        ols_predictions
    ]
    
def mle_fit(
    data,
    formula,
    confint_alpha = 0.05,
    family=sm.families.Gaussian(),
    link=sm.families.links.identity()
    ):
    
    y, X = dmatrices(
        formula, 
        data=data, 
        return_type = "dataframe"
        )

    mle_model = sm.GLM(
        y, 
        X, 
        family=family(link=link)
        ).fit()

    mle_coef = mle_model.params
    mle_coef_se = mle_model.bse
    mle_coef_z = mle_model.tvalues
    mle_coef_p = mle_model.pvalues
    mle_coef_ci = mle_model.conf_int(alpha=confint_alpha)
    
    mle_predictions = mle_model.get_prediction(X).summary_frame(alpha=confint_alpha)

    return [
        mle_coef,
        mle_coef_se,
        mle_coef_z,
        mle_coef_p,
        mle_coef_ci,
        mle_predictions
    ]