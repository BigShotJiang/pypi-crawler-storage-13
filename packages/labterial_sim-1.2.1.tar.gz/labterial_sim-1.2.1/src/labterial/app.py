import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import os
import sys

# --- SETUP ---
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

try:
    from .database_mgr import get_all_materials, insert_from_dataframe
    from .physics import simular_ensayo
except ImportError:
    from database_mgr import get_all_materials, insert_from_dataframe
    from physics import simular_ensayo

MPA_TO_KSI = 0.1450377

LABEL_MAP = {
    "name": "Material", "category": "Categoría",
    "elastic_modulus": "Módulo de Young (E)", "yield_strength": "Límite Elástico (Sy)",
    "ultimate_strength": "Resistencia Máxima (Su)", "poisson_ratio": "Coeficiente Poisson (ν)",
    "density": "Densidad", "cost": "Costo", "max_temp": "Temp. Máx"
}

def translate_df(df):
    return df.rename(columns=LABEL_MAP)

def configure_page():
    st.set_page_config(page_title="Labterial Edu", layout="wide", page_icon="🧪")
    st.title("🧪 Labterial: Suite de Ingeniería")

def load_data():
    return get_all_materials()

def render_sidebar(df_raw):
    st.sidebar.header("🔍 Filtros")
    st.sidebar.divider()
    st.sidebar.subheader("👨‍🏫 Modo Profesor")
    show_math = st.sidebar.checkbox("Mostrar Explicación Física", value=True)
    st.sidebar.divider()
    if isinstance(df_raw, pd.DataFrame) and 'category' in df_raw.columns:
        cats = df_raw['category'].unique().tolist()
        sel_cats = st.sidebar.multiselect("Categoría", cats, default=cats)
        if sel_cats: return df_raw[df_raw['category'].isin(sel_cats)], show_math
    return df_raw, show_math

def render_tab_management(df_mats):
    c1, c2 = st.columns([2, 1])
    with c1:
        st.subheader("📋 Inventario")
        st.dataframe(translate_df(df_mats), use_container_width=True, height=400)
    with c2:
        st.subheader("Gestión")
        with st.expander("📥 Importar CSV"):
            up = st.file_uploader("Archivo", type=['csv'])
            if up and st.button("Cargar"):
                try:
                    df_new = pd.read_csv(up)
                    a, i, e = insert_from_dataframe(df_new)
                    if e: st.error(e)
                    else: st.success(f"Ok: {a}"); st.rerun()
                except Exception as ex: st.error(ex)
        try:
            from pathlib import Path
            pkg = __package__ if __package__ else 'labterial'
            db_path = Path.home() / f".{pkg}" / "materials.db"
            if not db_path.exists(): db_path = Path(__file__).parent.parent.parent / 'data' / 'materials.db'
            if db_path.exists():
                with open(db_path, "rb") as fp: st.download_button("💾 Backup BD", fp, "materials.db")
        except: pass

# --- FUNCIÓN PEDAGÓGICA EXPANDIDA ---
def render_math_explainer(dat, modo, units, factor, unit_label, geom_params=None):
    E = dat['elastic_modulus'] * factor
    Sy = dat['yield_strength'] * factor
    Su = dat['ultimate_strength'] * factor
    
    st.info(f"📘 **Análisis Físico-Matemático Detallado: {modo}**")
    
    t1, t2 = st.tabs(["1. Mecánica Elástica (Lineal)", "2. Plasticidad y Falla (No Lineal)"])
    
    if modo == "Flexion":
        L, b, d = geom_params if geom_params else (100, 10, 5)
        # Inercia rectangular
        I = (b * d**3) / 12
        
        with t1:
            c_txt, c_eq = st.columns([3, 2])
            with c_txt:
                st.markdown("### 📐 Teoría de la Viga (Euler-Bernoulli)")
                st.markdown("""
                En la flexión, el material no se estira uniformemente. Existe un **Eje Neutro** en el centro que no sufre deformación.
                *   Las fibras superiores se **comprimen**.
                *   Las fibras inferiores se **traccionan**.
                
                La resistencia depende de la **Inercia ($I$)**, que es la oposición geométrica a rotar. Nota que la altura ($d$) está elevada al cubo ($d^3$), por lo que aumentar el espesor es la forma más eficiente de ganar rigidez.
                """)
                st.caption(f"Momento de Inercia calculado: $I = {I:,.1f} \\text{{ mm}}^4$")
            with c_eq:
                st.markdown("#### Esfuerzo Máximo (Fórmula de la Escuadría)")
                st.latex(r"\sigma_{max} = \frac{M \cdot c}{I} \Rightarrow \frac{3 \cdot F \cdot L}{2 \cdot b \cdot d^2}")
                st.markdown("#### Deflexión Máxima")
                st.latex(r"\delta = \frac{F \cdot L^3}{48 \cdot E \cdot I}")
        
        with t2:
            st.markdown("### 💥 Módulo de Ruptura (MOR)")
            st.markdown(f"""
            Aunque el material es el mismo que en tracción, en flexión suele aguantar una carga aparente mayor (**{1.2*Su:.0f} {unit_label}** vs {Su:.0f} {unit_label}).
            
            **¿Por qué?** En tracción pura, todo el volumen está al límite, así que cualquier defecto interno causa la falla. 
            En flexión, solo una "piel" delgada inferior está al esfuerzo máximo, reduciendo estadísticamente la probabilidad de que un defecto crítico esté justo ahí (Mecánica de Fractura Probabilística).
            
            **La Caída Final:** La gráfica baja porque se inicia una grieta en la cara inferior que se propaga hacia arriba, reduciendo la sección efectiva de la viga ($d$ disminuye).
            """)

    elif modo == "Torsion":
        Nu = dat.get('poisson_ratio', 0.3)
        G = E / (2 * (1 + Nu))
        Ty = Sy * 0.577
        
        with t1:
            c_txt, c_eq = st.columns([3, 2])
            with c_txt:
                st.markdown("### 🔄 Cizalladura Pura (Shear)")
                st.markdown("""
                Imagina el material como un mazo de cartas. En torsión, no estamos separando las cartas (tracción), sino **deslizándolas** unas sobre otras.
                
                La rigidez que gobierna esto no es $E$, sino el **Módulo de Cortante ($G$)**. Para materiales isotrópicos, $G$ está matemáticamente ligado a $E$ a través del Coeficiente de Poisson ($\\nu$).
                """)
                st.caption(f"Relación Elástica: $G \\approx 0.38 E$ (para metales típicos)")
                st.markdown(f"**Calculado:** $G = {G:,.0f} \\text{{ {unit_label} }}$")
            with c_eq:
                st.markdown("#### Ley de Hooke (Corte)")
                st.latex(r"\tau = G \cdot \gamma")
                st.markdown("""
                * $\\tau$: Esfuerzo Cortante
                * $G$: Módulo de Rigidez
                * $\gamma$: Deformación Angular
                """)
        with t2:
            st.markdown("### ⚡ Criterio de Falla de Von Mises")
            st.markdown(f"""
            ¿Cuándo deja de ser elástico el material si lo retuerces?
            La **Teoría de la Energía de Distorsión** (Von Mises) establece que el material fluye cuando la energía de deformación alcanza un límite crítico.
            
            Matemáticamente, esto predice que la resistencia al corte es el **57.7%** de la resistencia a la tracción.
            """)
            st.latex(r"\tau_{yield} = \frac{\sigma_{yield}}{\sqrt{3}} \approx 0.577 \cdot \sigma_{yield}")
            st.markdown(f"Por eso, tu límite elástico estimado baja de **{Sy:.0f}** a **{Ty:.0f} {unit_label}**.")

    elif modo == "Compresion":
        with t1:
            c_txt, c_eq = st.columns([3, 2])
            with c_txt:
                st.markdown("### 🧱 Efecto Poisson y Fricción")
                st.markdown(f"""
                Al aplastar el material, los átomos se acercan. Por conservación de volumen (aproximada), el material trata de expandirse hacia los lados.
                
                El **Coeficiente de Poisson ($\\nu = {dat.get('poisson_ratio', 0.3)}$)** dicta qué tanto se "engorda" la probeta.
                * $\\nu = 0.5$: Volumen constante (Gomas).
                * $\\nu = 0.3$: Metales típicos.
                * $\\nu = 0.0$: Corcho (no se ensancha).
                """)
            with c_eq:
                st.markdown("#### Ley Constitutiva")
                st.latex(r"\sigma_{axial} = - E \cdot \epsilon_{axial}")
                st.latex(r"\epsilon_{transversal} = - \nu \cdot \epsilon_{axial}")
        
        with t2:
            st.markdown("### 📈 ¿Por qué no baja la gráfica?")
            st.markdown("""
            A diferencia de la tracción, donde se forma un cuello que debilita la pieza (**Estricción**), en compresión ocurre lo contrario: el **Abarrilamiento**.
            
            1.  El área transversal aumenta ($A > A_0$).
            2.  Como $\sigma = F/A_0$ (Esfuerzo Ingenieril), y el material real se vuelve más denso y fuerte por endurecimiento, la máquina necesita cada vez más fuerza.
            3.  No hay un punto de inestabilidad geométrica en materiales dúctiles; simplemente se aplastan hasta ser una lámina.
            """)

    else: # Tension (Tracción)
        with t1:
            c_txt, c_eq = st.columns([3, 2])
            with c_txt:
                st.markdown("### 🔗 Fuerzas Interatómicas")
                st.markdown("""
                En la zona lineal, estamos estirando los enlaces químicos (metálicos, covalentes) sin romperlos. Es como estirar millones de resortes microscópicos.
                
                La pendiente de esta recta, el **Módulo de Young ($E$)**, es una medida directa de la fuerza de esos enlaces químicos. Por eso el Tungsteno (enlaces fuertes) tiene un $E$ alto y los polímeros (enlaces débiles) un $E$ bajo.
                """)
                st.caption(f"Rigidez medida: $E = {E:,.0f} \\text{{ {unit_label} }}$")
            with c_eq:
                st.markdown("#### Ley de Hooke Uniaxial")
                st.latex(r"\sigma = E \cdot \epsilon")
        
        with t2:
            st.markdown("### 🔨 Dislocaciones y Endurecimiento")
            st.markdown(f"""
            Cuando pasamos el límite **Sy** ({Sy:.0f} {unit_label}), ocurren deslizamientos irreversibles en la estructura cristalina (movimiento de dislocaciones).
            
            **Endurecimiento por Deformación:** Curiosamente, deformar el metal lo hace más fuerte al principio (la curva sube). Las dislocaciones se "enredan" entre sí, dificultando el movimiento posterior.
            
            **Estricción (Necking):** Al llegar a **Su** ({Su:.0f} {unit_label}), el endurecimiento ya no puede compensar la reducción de área. Se forma un cuello local y la carga cae hasta la fractura.
            """)
            st.latex(r"\sigma_{plastica} = K \cdot \epsilon^n")

def render_tab_simulation(df_mats, show_math):
    if df_mats.empty: st.warning("Sin datos."); return
    st.header("🔬 Laboratorio Virtual")
    col_ctrl, col_plot = st.columns([1, 3])
    geom = None

    with col_ctrl:
        st.subheader("Configuración")
        units = st.radio("Unidades", ["SI (MPa)", "Imperial (ksi)"], horizontal=True)
        is_imperial = "Imperial" in units
        unit_label = "ksi" if is_imperial else "MPa"
        factor = MPA_TO_KSI if is_imperial else 1.0
        
        st.divider()
        mats_avail = df_mats['name'].unique()
        sel = st.multiselect("Probetas", options=mats_avail, default=[mats_avail[0]] if len(mats_avail)>0 else None)
        
        st.divider()
        modo = st.radio("Ensayo", ["Tension", "Compresion", "Torsion", "Flexion"])
        
        slider_max_def = 15.0
        if modo == "Flexion":
            st.info("📏 Geometría (mm)")
            c_L, c_dim = st.columns(2)
            with c_L: L_val = st.number_input("Largo (L)", value=200.0)
            with c_dim: 
                b_val = st.number_input("Ancho (b)", value=20.0)
                d_val = st.number_input("Espesor (d)", value=10.0)
            geom = (L_val, b_val, d_val)
            slider_max_def = 5.0
        
        lbl = "Límite Carrera (%)" if (modo!="Torsion") else "Ángulo (rad)"
        max_v = 40.0 if modo!="Torsion" else 1.0
        slider = st.slider(lbl, 0.1, max_v, slider_max_def)
        limit = slider/100 if modo!="Torsion" else slider

    with col_plot:
        if not sel: st.info("Selecciona material."); return
        fig = go.Figure()
        export_data = []

        for mat in sel:
            dat = df_mats[df_mats['name'] == mat].iloc[0]
            props = dict(dat); props['category'] = dat.get('category', 'Metal')
            
            df_sim = simular_ensayo(props, modo, max_strain_machine=limit)
            
            if modo == "Flexion":
                sigma_si = df_sim["Esfuerzo (MPa)"]
                epsilon_si = df_sim["Deformacion (mm/mm)"]
                F_val = (2 * sigma_si * b_val * (d_val**2)) / (3 * L_val)
                Delta_val = (epsilon_si * (L_val**2)) / (6 * d_val)
                x_vals = Delta_val; y_vals = F_val
                x_title = "Deflexión (mm)"; y_title = "Fuerza (N)"
                if is_imperial:
                    x_vals *= 0.0393701; y_vals *= 0.224809
                    x_title = "Deflexión (in)"; y_title = "Fuerza (lbf)"
            else:
                y_vals = df_sim["Esfuerzo (MPa)"] * factor
                x_col = "Deformacion (%)" if modo!="Torsion" else "Deformacion (rad)"
                x_vals = df_sim[x_col]
                x_title = x_col.replace("Deformacion", "Deformación")
                y_title = f"Esfuerzo ({unit_label})"

            fig.add_trace(go.Scatter(x=x_vals, y=y_vals, mode='lines', name=mat, line=dict(width=3)))
            
            df_tmp = pd.DataFrame({x_title: x_vals, y_title: y_vals, 'Material': mat})
            export_data.append(df_tmp)

        title_map = {"Tension": "Tracción", "Compresion": "Compresión", "Torsion": "Torsión", "Flexion": "Ensayo de Flexión"}
        fig.update_layout(title=f"{title_map[modo]}", xaxis_title=x_title, yaxis_title=y_title, 
                          hovermode="x unified", template="plotly_white")
        if modo != "Flexion": fig.update_xaxes(range=[0, slider])
        st.plotly_chart(fig, use_container_width=True)
        
        if export_data:
            df_exp = pd.concat(export_data)
            st.download_button("💾 Descargar Datos (CSV)", df_exp.to_csv(index=False).encode('utf-8'), "simulacion.csv")

        if show_math and len(sel) == 1:
            render_math_explainer(df_mats[df_mats['name'] == sel[0]].iloc[0], modo, units, factor, unit_label, geom)
            
        st.divider()
        st.subheader("📊 Benchmarking")
        df_sub = df_mats[df_mats['name'].isin(sel)].copy()
        opts = {"yield_strength": f"Resistencia (Sy)", "elastic_modulus": f"Rigidez (E)", "density": "Densidad", "cost": "Costo"}
        opts = {k:v for k,v in opts.items() if k in df_sub.columns}
        if opts:
            prop = st.selectbox("Comparar:", list(opts.keys()), format_func=lambda x: opts[x])
            vals = df_sub[prop].values
            if is_imperial and prop in ["yield_strength", "elastic_modulus"]: vals = vals * factor
            fig_bar = px.bar(df_sub, x='name', y=vals, color='name', text_auto='.1f', title=opts[prop])
            fig_bar.update_layout(showlegend=False, template="plotly_white", yaxis_title=opts[prop])
            st.plotly_chart(fig_bar, use_container_width=True)

def render_tab_reports(df_mats):
    st.header("📑 Reportes")
    if df_mats.empty: return
    c1, c2 = st.columns(2)
    with c1: sel = st.multiselect("Materiales", df_mats['name'].unique())
    with c2: cols = st.multiselect("Propiedades", [c for c in df_mats.columns if c!='id'], default=['name','yield_strength'], format_func=lambda x: LABEL_MAP.get(x, x))
    if sel and cols:
        df = df_mats[df_mats['name'].isin(sel)][cols]
        st.dataframe(df, use_container_width=True)
        t1, t2 = st.tabs(["CSV", "LaTeX"])
        with t1: st.download_button("Descargar CSV", df.to_csv(index=False).encode('utf-8'), "data.csv", "text/csv")
        with t2: st.code(df.to_latex(index=False, float_format="%.2f"), language='latex')

def main():
    configure_page()
    try: df_raw = load_data()
    except: return
    df_mats, show_math = render_sidebar(df_raw)
    t1, t2, t3 = st.tabs(["📦 Base de Datos", "📈 Simulación", "📑 Reportes"])
    with t1: render_tab_management(df_mats)
    with t2: render_tab_simulation(df_mats, show_math)
    with t3: render_tab_reports(df_mats)

if __name__ == "__main__":
    main()
