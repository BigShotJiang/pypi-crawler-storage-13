# cmpparis-aws

AWS utilities for cmpparis libraries (S3, SSM, SES, Secrets Manager).

## Installation

```bash
pip install cmpparis-aws
```

## Features

- S3 file management
- SSM Parameter Store access
- SES email sending
- Secrets Manager integration

## Usage

```python
from cmpparis_aws import S3, get_parameter, send_email

s3 = S3()
s3.upload_file("local.csv", "bucket", "remote.csv")
```
