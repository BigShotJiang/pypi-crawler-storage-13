class PipelexBundleBlueprintValueError(ValueError):
    pass
