"""Metadata deduced from git at build time."""

id: str
short_id: str

id = "eedabd001c7bc80444e6684771eef3582ef67b8a"
short_id = "eedabd0"
