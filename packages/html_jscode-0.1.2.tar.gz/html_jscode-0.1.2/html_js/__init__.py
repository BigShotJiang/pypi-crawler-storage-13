# HTML-JS paketinin Python entegrasyonu
html_js_code = """
<!DOCTYPE html>
<html>
<head>
<title>Örnek Sayfa</title>
</head>
<body>
<p>Merhaba!</p>
</body>
</html>
"""