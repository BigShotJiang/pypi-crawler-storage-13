# pylanauagectrl/__init__.py
def selam():
    print("Selam!")
