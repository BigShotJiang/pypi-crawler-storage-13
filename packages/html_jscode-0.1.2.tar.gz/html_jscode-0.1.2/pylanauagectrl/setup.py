from setuptools import setup, find_packages

setup(
    name="PyLanauageCtrl",
    version="1.0.1",
    packages=find_packages(),
    author="Hamza Al",                 # İstediğin isim
    author_email="maverahmzl@gmail.com",   # Geçerli bir email
    description="Python Türkçe modül",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/username/PyLanauageCtrl",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)
