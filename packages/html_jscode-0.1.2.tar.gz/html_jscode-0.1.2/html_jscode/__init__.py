
class HTMLBar:
    def __init__(self):
        print("HTMLBar nesnesi olu�turuldu!")

    def create_bar(self, html_code):
        with open("merhaba.html", "w", encoding="utf-8") as f:
            f.write(html_code)
        print("merhaba.html olu�turuldu!")
