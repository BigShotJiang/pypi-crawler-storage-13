from html import js

class HTMLBar:
    def __init__(self):
        self.html_codes = [
            "<a>", "<abbr>", "<address>", "<area>", "<article>", "<aside>",
            "<b>", "<base>", "<bdi>", "<bdo>", "<blockquote>",
            "<body>", "<br>", "<button>", "<canvas>",
            "<div>", "<data>", "<datalist>", "<dd>", "<del>", "<details>", "<dfn>", "<dialog>", "<dl>", "<dt>",
            "<em>", "<embed>",
            "<fieldset>", "<figcaption>", "<figure>", "<footer>", "<form>",
            "<h1>", "<h2>", "<h3>", "<h4>", "<h5>", "<h6>", "<head>", "<header>", "<hr>", "<html>",
            "<i>", "<iframe>", "<img>", "<input>", "<ins>", "<iframe>",
            "<kbd>",
            "<label>", "<legend>", "<li>", "<link>",
            "<main>", "<map>", "<mark>", "<meta>", "<meter>",
            "<nav>", "<noscript>",
            "<ol>", "<option>", "<output>",
            "<p>", "<param>", "<picture>",
            "<q>",
            "<rp>", "<rt>", "<ruby>", "<script>", "<section>", "<select>", "<small>", "<source>", "<span>", "<strong>", "<style>", "<sub>", "<summary>", "<sup>",
            "<table>", "<tbody>", "<td>", "<template>", "<textarea>", "<tfoot>", "<th>", "<thead>", "<time>", "<title>", "<tr>", "<track>",
            "<ul>", "<u>",
            "<video>", "<wbr>",
            "<iframe>"
        ]

    def show(self):
        print("HTML Codes Available:")
        for code in self.html_codes:
            print(code)

    def js_control(self, code: str):
        print(f"Running JS Code:\n{code}")
