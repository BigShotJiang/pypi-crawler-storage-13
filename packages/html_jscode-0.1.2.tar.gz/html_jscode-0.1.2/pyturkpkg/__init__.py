# pyturkpkg init dosyası

def selamla(isim="Dünya"):
    """Türkçe selam verir."""
    return f"Merhaba {isim}!"
    
def tesekkur_et():
    """Teşekkür mesajı."""
    return "Teşekkür ederim!"
    
def veda_et():
    """Veda mesajı."""
    return "Hoşça kal!"
