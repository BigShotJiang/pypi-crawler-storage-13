# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name="html-jscode",
    version="0.1.2",
    packages=find_packages(),
    install_requires=[],
    python_requires='>=3.7',
    author="Your Name",
    author_email="you@example.com",
    description="Python ile HTML ve JS kodlarını paket olarak kullanmanı sağlar",
    url="https://github.com/yourusername/html-jscode",
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
