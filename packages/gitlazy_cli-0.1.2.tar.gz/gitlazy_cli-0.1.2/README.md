# GitLazy (`gz`)

`gz` is a cross-platform Git automation helper designed to streamline everyday workflows. It stages, summarizes, commits, rebases, and pushes changes with a single command, adapting intelligently to the state of your repository.

## Features
- Works from any subdirectory by auto-detecting the repository root (or via an explicit path argument).
- Generates commit messages with `[add]`, `[refactor]`, or `[removed]` tags based on the staged changes.
- Summarizes added, modified, renamed, and removed files in the commit body.
- Performs `git pull --rebase --autostash` for safe synchronization.
- Pushes automatically when an upstream is configured and guides you when it is not.
- Handles conflicts gracefully by surfacing clear next steps.

## Installation

### Via PyPI (recommended)
```bash
pip install gitlazy-cli
```

This installs the `gz` console script on your PATH.

### Manual install (macOS / Linux)
```bash
sudo cp gz /usr/bin/gz
# or, without sudo:
mkdir -p ~/.local/bin
cp gz ~/.local/bin/
chmod +x ~/.local/bin/gz
# ensure ~/.local/bin is on your PATH
```

### Manual install (Windows PowerShell or CMD)
1. Install Python 3.8+ and Git.
2. Save `gz` to `%USERPROFILE%\bin\gz`.
3. Create `gz.cmd` somewhere on your `PATH` containing:
   ```bat
   @echo off
   python "%USERPROFILE%\bin\gz" %*
   ```

Now `gz` is available globally.

## Usage
```bash
# Run from the current repo
gz

# Target an explicit repo
gz /path/to/repo

# Or via python -m
python -m gitlazy /path/to/repo
```

### Example Output
```
[refactor] 2 updated, 1 added
3 files changed, 54 insertions(+), 23 deletions(-)
Done. Changes committed, rebased, and pushed.
```

## Behavior
- Always stages everything with `git add -A`.
- Skips committing when no changes are staged but still performs a safe pull/push.
- Skips pull/push and prints the upstream command when the current branch has no upstream configured.
- On pull failures, surfaces Git’s stderr and reminds you to finish any rebase with `git rebase --continue` before pushing.
- When no upstream is configured:
  ```
  git push --set-upstream origin <branch>
  ```

## Acceptance Checks
1. **Add only**: create a repo, add files, run `gz` → `[add] <count> added`.
2. **Modify + add**: modify and add files, run `gz` → `[refactor] … updated, … added`.
3. **Rename + delete**: rename and delete files, run `gz` → `[removed] … renamed, … removed`.
4. **No changes**: run `gz` with a clean tree → prints “Nothing to commit. Syncing with remote…” and still pulls/pushes.
5. **New branch**: run on a branch without upstream → shows `git push --set-upstream origin <branch>`.
6. **Cross-path**: run from subfolders or via `gz /path/to/repo` → operates on the correct repository.
7. **Outside repo**: run where no `.git` exists → exits with a helpful error message.

## Development Notes
- Python 3.8+ package with a single CLI module.
- Depends only on the Python standard library modules: `os`, `sys`, `pathlib`, `subprocess`, and `shutil`.

### Building and publishing
```bash
python -m build
twine upload dist/*
```
Use TestPyPI first: `twine upload --repository testpypi dist/*`.

---

Happy automating! 🎯
