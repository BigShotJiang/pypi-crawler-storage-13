"""gitlazy package."""

__all__ = ["main", "__version__"]
__version__ = "0.1.2"

from .cli import main
