#!/usr/bin/env python3
"""CLI entrypoint for the gitlazy workflow helper."""

import os
import sys
import subprocess
from pathlib import Path
import shutil


class GitLazyError(Exception):
    """Custom exception for gitlazy failures."""

    def __init__(self, message, result=None):
        super().__init__(message)
        self.result = result


def is_windows():
    return os.name == "nt"


def bold(text):
    if is_windows():
        return text
    return f"\033[1m{text}\033[0m"


def ensure_git():
    if shutil.which("git") is None:
        raise GitLazyError("Git executable not found in PATH.")


def repo_root_for(path):
    path = Path(path).resolve()
    if path.is_file():
        path = path.parent
    for candidate in [path] + list(path.parents):
        git_dir = candidate / ".git"
        if git_dir.exists():
            return candidate
    return None


def git_env_cwd(path):
    if path is None:
        return []
    return ["-C", str(path)]


def git(*args, repo=None, check=True, capture_output=False):
    cmd = ["git"]
    cmd.extend(git_env_cwd(repo))
    cmd.extend(args)
    result = subprocess.run(
        cmd,
        text=True,
        capture_output=capture_output,
        check=False,
    )
    if check and result.returncode != 0:
        message = result.stderr.strip() or result.stdout.strip() or "Git command failed."
        raise GitLazyError(message, result=result)
    return result


def summarize_status(repo):
    result = git("diff", "--cached", "--name-status", repo=repo, capture_output=True)
    added = []
    modified = []
    renamed = []
    removed = []

    for raw_line in result.stdout.strip().splitlines():
        parts = raw_line.split("\t")
        if not parts:
            continue
        code = parts[0]
        if code.startswith("R"):
            if len(parts) >= 3:
                renamed.append((parts[1], parts[2]))
        elif code.startswith("A"):
            if len(parts) >= 2:
                added.append(parts[1])
        elif code.startswith("M"):
            if len(parts) >= 2:
                modified.append(parts[1])
        elif code.startswith("D"):
            if len(parts) >= 2:
                removed.append(parts[1])

    return {
        "added": added,
        "modified": modified,
        "renamed": renamed,
        "removed": removed,
    }


def choose_tag(summary):
    added = len(summary["added"])
    modified = len(summary["modified"])
    renamed = len(summary["renamed"])
    removed = len(summary["removed"])

    if (renamed > 0) or (removed > 0):
        return "[removed]"
    if added > 0 and modified == 0 and renamed == 0 and removed == 0:
        return "[add]"
    if added == 0 and modified == 0 and renamed == 0 and removed == 0:
        return "[refactor]"
    return "[refactor]"


def detect_short_summary(summary):
    parts = []
    renamed_count = len(summary["renamed"])
    removed_count = len(summary["removed"])
    modified_count = len(summary["modified"])
    added_count = len(summary["added"])

    if renamed_count:
        parts.append(f"{renamed_count} renamed")
    if removed_count:
        parts.append(f"{removed_count} removed")
    if modified_count:
        parts.append(f"{modified_count} updated")
    if added_count:
        parts.append(f"{added_count} added")

    if not parts:
        return "no changes"
    if len(parts) == 1:
        return parts[0]
    return ", ".join(parts)


def build_title(tag, summary):
    short = detect_short_summary(summary)
    return f"{tag} {short}"


def diff_shortstat(repo):
    result = git("diff", "--cached", "--shortstat", repo=repo, capture_output=True)
    return result.stdout.strip()


def build_body(summary, stats_line):
    sections = []
    if stats_line:
        sections.append(stats_line)

    if summary["added"]:
        added_lines = "\n".join(f"- {path}" for path in summary["added"])
        sections.append(f"Added:\n{added_lines}")

    if summary["modified"]:
        modified_lines = "\n".join(f"- {path}" for path in summary["modified"])
        sections.append(f"Modified:\n{modified_lines}")

    if summary["renamed"]:
        renamed_lines = "\n".join(f"- {old} -> {new}" for old, new in summary["renamed"])
        sections.append(f"Renamed:\n{renamed_lines}")

    if summary["removed"]:
        removed_lines = "\n".join(f"- {path}" for path in summary["removed"])
        sections.append(f"Removed:\n{removed_lines}")

    return "\n\n".join(sections)


def pull_rebase_autostash(repo):
    result = git(
        "pull",
        "--rebase",
        "--autostash",
        repo=repo,
        capture_output=True,
        check=False,
    )
    if result.stdout:
        print(result.stdout.strip())
    if result.returncode != 0:
        if result.stderr:
            print(result.stderr.strip(), file=sys.stderr)
        print(
            "Pull with rebase failed. Resolve conflicts or errors, then rerun. "
            "If already in a rebase, run `git rebase --continue` followed by `git push`.",
            file=sys.stderr,
        )
        raise GitLazyError("Pull with rebase failed.", result=result)


def current_branch(repo):
    result = git(
        "rev-parse",
        "--abbrev-ref",
        "HEAD",
        repo=repo,
        capture_output=True,
    )
    return result.stdout.strip()


def has_upstream(repo):
    result = git(
        "rev-parse",
        "--abbrev-ref",
        "--symbolic-full-name",
        "@{u}",
        repo=repo,
        capture_output=True,
        check=False,
    )
    return result.returncode == 0


def push_if_possible(repo, branch):
    if has_upstream(repo):
        result = git("push", repo=repo, capture_output=True, check=False)
        if result.stdout:
            print(result.stdout.strip())
        if result.returncode != 0:
            if result.stderr:
                print(result.stderr.strip(), file=sys.stderr)
            raise GitLazyError("Push failed.", result=result)
        print(bold("OK"), "pushed to upstream.")
        return True
    else:
        print(
            "No upstream branch detected. Run:\n"
            f"  git push --set-upstream origin {branch}"
        )
        return False


def workflow(repo):
    git("add", "-A", repo=repo)
    summary = summarize_status(repo)
    total_changes = sum(
        len(summary[key]) for key in ("added", "modified", "renamed", "removed")
    )
    performed_commit = False

    if total_changes == 0:
        print("Nothing to commit. Syncing with remote...")
    else:
        tag = choose_tag(summary)
        title = build_title(tag, summary)
        stats_line = diff_shortstat(repo)
        body = build_body(summary, stats_line)

        print(title)
        if stats_line:
            print(stats_line)

        commit_result = git(
            "commit",
            "-m",
            title,
            "-m",
            body,
            repo=repo,
            capture_output=True,
            check=False,
        )
        if commit_result.stdout:
            print(commit_result.stdout.strip())
        if commit_result.returncode != 0:
            if commit_result.stderr:
                print(commit_result.stderr.strip(), file=sys.stderr)
            raise GitLazyError("Commit failed.", result=commit_result)
        performed_commit = True

    branch = current_branch(repo)
    upstream_exists = has_upstream(repo)
    performed_rebase = False

    if upstream_exists:
        pull_rebase_autostash(repo)
        performed_rebase = True
        pushed = push_if_possible(repo, branch)
    else:
        print(
            f"No upstream branch detected for {branch}. Skipping pull.\n"
            f"Run:\n  git push --set-upstream origin {branch}"
        )
        pushed = False

    if performed_commit and pushed:
        if performed_rebase:
            print("Done. Changes committed, rebased, and pushed.")
        else:
            print("Done. Changes committed and pushed.")
    elif performed_commit and performed_rebase:
        print("Done. Changes committed and rebased.")
    elif performed_commit:
        print("Done. Changes committed. Configure an upstream to push.")
    elif performed_rebase and pushed:
        print("Done. Synced with remote.")
    elif performed_rebase:
        print("Done. Rebasing complete. Configure an upstream to push.")
    else:
        print("Done. No upstream configured; nothing pulled or pushed.")


def parse_args(argv):
    if len(argv) > 2:
        raise GitLazyError("Usage: gz [path]")
    if len(argv) == 2:
        return Path(argv[1]).resolve()
    return Path.cwd()


def main(argv=None):
    argv = argv or sys.argv
    try:
        ensure_git()
        target = parse_args(argv)
        repo_root = repo_root_for(target)
        if repo_root is None:
            raise GitLazyError(
                f"No Git repository found at or above {target}"
            )
        workflow(repo_root)
    except GitLazyError as err:
        print(err, file=sys.stderr)
        if err.result and err.result.stdout:
            print(err.result.stdout.strip(), file=sys.stderr)
        if err.result and err.result.stderr:
            print(err.result.stderr.strip(), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Operation cancelled.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
