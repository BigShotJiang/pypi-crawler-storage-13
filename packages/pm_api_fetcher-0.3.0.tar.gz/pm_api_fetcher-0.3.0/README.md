# pm-api-fetcher

Focused helpers for downloading Polymarket series data and exporting the open
events/markets to JSON so they can be consumed elsewhere.

## Features

- **Fetch Event Summary**: Get active markets and token IDs for a specific event by slug (`get_event_summary_with_slug`).
- **Fetch Series Events**: Retrieve all open events and their markets for a Polymarket series (`get_series_open_events_with_id`).


## Quickstart

```bash
cd pm-api-fetcher
uv sync --group dev
uv run pytest
```

## Usage

### Fetch Event Summary by Slug

Fetch a single event and its active markets using its slug.

```python
from pm_api_fetcher import get_event_summary_with_slug

slug = "democratic-presidential-nominee-2028"
summary = get_event_summary_with_slug(slug)

print(f"Event: {summary['event_id']}")
for market in summary['markets']:
    print(f"- {market['question']} (Yes: {market['yes_token']})")
```

### Fetch All Open Events in a Series

Fetch all active events and markets for a given series ID.

```python
from pm_api_fetcher import get_series_open_events_with_id

# Series 35 is typically the main series
events = get_series_open_events_with_id(series_id=35)

for event in events:
    print(f"Event: {event['title']}")
    print(f"Active Markets: {len(event['markets'])}")
```



## Tooling

- `uv run pre-commit install` – enable the linting pipeline locally
- `uv run pylint src` – static analysis
- `uv run mypy --config-file mypy.toml src` – type checking

## Releasing

1. Update the version in both `pyproject.toml` and `src/pm_api_fetcher/__init__.py`.
2. Run the local gates before tagging:
	```bash
	uv run pytest
	uv build
	```
3. Create an annotated tag that matches the new version (e.g. `git tag -a v0.3.0 -m "v0.3.0"`), then push it with `git push origin v0.3.0`.
4. Push `git push origin release-v0.3.0`. The GitHub Action `ci-cd` will re-run tests, build the wheel/sdist, and automatically upload to PyPI via Trusted Publisher (OIDC).
