# CXR-K2 Model

Premium CXR claim analysis model with enhanced precision and deeper analysis.

## Installation

```bash
pip install cxr-k2
```

## Quick Start

```python
from cxr_k2 import analyze

claim = {
    "claimId": "CLM-001",
    "patientId": "PAT-001",
    "providerId": "PROV-001",
    "serviceDate": "2024-01-15",
    "procedureCode": "99213",
    "billedAmount": 120.0,
    "metadata": {"reviewThreshold": 0.75}
}

result = analyze(claim, tenant_id="tenant-123")
print(result["verdict"])
```

## Features

- 7-plane fusion with enhanced precision weights
- Deeper policy and archetype analysis
- More conservative thresholds

## Model Capabilities

- Fusion Planes: 7
- Monte Carlo: No
- Speed Profile: Thorough
- Precision Level: Enhanced

## Usage

```python
from cxr_k2 import get_model

model = get_model()
result = model.analyze(claim, tenant_id)
```

