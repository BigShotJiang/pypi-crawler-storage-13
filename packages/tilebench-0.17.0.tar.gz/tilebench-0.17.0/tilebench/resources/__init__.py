"""tilebench viz resources."""
