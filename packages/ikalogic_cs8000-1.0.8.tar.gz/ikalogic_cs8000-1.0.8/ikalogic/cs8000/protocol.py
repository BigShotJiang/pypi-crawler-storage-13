"""
CS8000 Protocol Constants
"""

EOF = 0x1A

class CMD:
    """Command constants for CS8000 protocol"""
    NONE = 0x00
    STEPS_COUNT = 0x01
    LOOPS_COUNT = 0x02
    LOAD_STEP = 0x03
    SEQ_RESET = 0x04
    FORCE_TRIG = 0x05
    GET_STATUS = 0x06
    ARM_TRIGGER = 0x07
    SPI_CS = 0x0A
    SPI_TRX = 0x0B
    REBOOT = 0x0C