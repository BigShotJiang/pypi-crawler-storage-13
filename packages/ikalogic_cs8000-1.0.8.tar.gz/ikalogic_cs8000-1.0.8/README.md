# CS8000 Python API

Python library for controlling [CS8000 series RF switches](https://ikalogic.com/rf-switches/cs8216/intro/).

## Installation

```bash
pip install ikalogic-cs8000
```

## Quick Start

```python
from ikalogic import cs8000

# Create instance and connect
sw = cs8000.CS8000("CS8216")
sw.open()  # Auto-detect first available device

# Switch connections
sw.prepare(1, 1)  # Connect COM1 to CH1
sw.prepare(2, 0)  # Disconnect COM2
sw.commit()
# Close connection
sw.close()
```

## Documentation
Full documentation is available at: https://ikalogic.com/kb/cs8000-api/cs8000_home/