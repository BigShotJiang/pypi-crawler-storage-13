
from setuptools import setup, find_packages

setup(
    name="pypip2",
    version="1.2.0",
    packages=find_packages(),
    description="Pip creator Free",
    include_package_data=True,
)
