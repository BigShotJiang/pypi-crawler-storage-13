def bye():
    print('Goodbye from ek2')
