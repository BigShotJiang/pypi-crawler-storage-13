def hello():
    print('Hello from ek1')
