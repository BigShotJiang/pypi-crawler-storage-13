"""Task-specific text tightening for compression."""

from typing import List

from ..types import TaskContext
from .normalize import segment_sentences


def tighten_for_summarization(text: str) -> str:
    """Optimize text for summarization tasks.

    Preserves causal links and chronological order.

    Args:
        text: Input text

    Returns:
        Tightened text
    """
    # For summarization, preserve chronological markers
    # Already handled by semantic compression preserving facts and entities
    return text


def tighten_for_extraction(text: str) -> str:
    """Optimize text for extraction tasks.

    Keeps only relevant fields, removes narrative.

    Args:
        text: Input text

    Returns:
        Tightened text
    """
    sentences = segment_sentences(text)

    # For extraction, keep only sentences with structured data
    # (entities, numbers, facts)
    # This is aggressive - remove narrative sentences
    import re

    structured_sentences = []
    for sentence in sentences:
        # Keep if contains: numbers, dates, names (capitals), or list markers
        has_structure = bool(
            re.search(r"\d+|[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*|^[-*•]\s", sentence)
        )
        if has_structure:
            structured_sentences.append(sentence)

    return " ".join(structured_sentences) if structured_sentences else text


def tighten_for_reasoning(text: str) -> str:
    """Optimize text for reasoning tasks.

    Preserves premises and logical connections.

    Args:
        text: Input text

    Returns:
        Tightened text
    """
    # Preserve logical connectors
    # Already handled by semantic compression
    return text


def tighten_for_rag(text: str) -> str:
    """Optimize text for RAG tasks.

    Maximizes information density for retrieval.

    Args:
        text: Input text

    Returns:
        Tightened text
    """
    # For RAG, convert to dense bullet-point style
    sentences = segment_sentences(text)

    # Remove transitional phrases
    import re

    transitions = [
        r"^(however|moreover|furthermore|additionally|also|besides),?\s*",
        r"^(therefore|thus|hence|consequently),?\s*",
        r"^(meanwhile|in addition|on the other hand),?\s*",
    ]

    cleaned_sentences = []
    for sentence in sentences:
        for pattern in transitions:
            sentence = re.sub(pattern, "", sentence, flags=re.IGNORECASE)
        if sentence.strip():
            cleaned_sentences.append(sentence.strip())

    return " ".join(cleaned_sentences)


def apply_task_specific_tightening(text: str, task: TaskContext) -> str:
    """Apply task-specific tightening strategies.

    Args:
        text: Input text
        task: Task context

    Returns:
        Task-optimized text
    """
    if task == TaskContext.TRANSLATION:
        # Skip compression for translation
        return text

    if task == TaskContext.SUMMARIZATION:
        return tighten_for_summarization(text)

    if task == TaskContext.EXTRACTION:
        return tighten_for_extraction(text)

    if task == TaskContext.REASONING:
        return tighten_for_reasoning(text)

    if task == TaskContext.RAG:
        return tighten_for_rag(text)

    if task == TaskContext.QUESTION_ANSWERING:
        # Similar to RAG - maximize information density
        return tighten_for_rag(text)

    # Default: no additional tightening
    return text


class TaskSpecificTightener:
    """Task-specific tightening pass for compression pipeline."""

    def __init__(self, task: TaskContext) -> None:
        """Initialize tightener.

        Args:
            task: Task context
        """
        self.task = task

    def process(self, text: str) -> str:
        """Process text through task-specific tightening.

        Args:
            text: Input text

        Returns:
            Task-optimized text
        """
        return apply_task_specific_tightening(text, self.task)

    def should_run(self, state: "PipelineState") -> bool:  # type: ignore
        """Check if pass should run."""
        return True

    @property
    def name(self) -> str:
        """Get pass name."""
        return "summarize"
