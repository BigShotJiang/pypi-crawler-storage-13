"""Token Reducer - Intelligent token reduction for LLM applications.

Reduce token counts by 50-70% while preserving semantic meaning and context.
"""

__version__ = "0.1.0"

from .api import (
    CompressionConfig,
    batch_compress_text,
    compress_code,
    compress_text,
    compress_with_config,
)
from .types import (
    CodeCompressionResult,
    CompressionLevel,
    CompressionMetrics,
    CompressionResult,
    TaskContext,
)

__all__ = [
    # Main API functions
    "compress_text",
    "compress_code",
    "batch_compress_text",
    "compress_with_config",
    # Configuration
    "CompressionConfig",
    # Enums
    "TaskContext",
    "CompressionLevel",
    # Result types
    "CompressionResult",
    "CodeCompressionResult",
    "CompressionMetrics",
    # Version
    "__version__",
]

