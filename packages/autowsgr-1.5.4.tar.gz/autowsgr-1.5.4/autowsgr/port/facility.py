class Bathroom:
    pass
