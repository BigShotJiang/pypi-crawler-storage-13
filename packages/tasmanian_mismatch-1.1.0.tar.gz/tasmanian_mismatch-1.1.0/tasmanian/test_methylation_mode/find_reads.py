#!/usr/bin/env python
from sys import stdin, argv, stderr

'''
samtools view unaligned.bam | python find_reads.py ids_from_aligned
'''

# open unaligned bam:
unaligned_bam = {}

with open(argv[2], 'r') as f:
    for line in f:
        line = line.strip("\n")
        split_line = line.split("\t")
        key = split_line[0]
        flag = split_line[1]

        if key in unaligned_bam:
            unaligned_bam[key][flag] = line
        else:
            unaligned_bam[key] = {flag: line}


# read reads_ids to interpolate
with open(argv[1], 'r') as f:
    ids = [ i.split("\t")[0] for i in f ]

not_good = []
for k in ids:
    if k not in unaligned_bam:
        not_good.append(k)
    else:
        for flag, read in unaligned_bam[k].items():
            print(read)


stderr.write('\n'.join(not_good))
