#!/usr/bin/env python3

import asyncio
import os
from pathlib import Path

import typer
from dotenv import load_dotenv

from .coding import run_build_task, run_coding_agent
from .init import init_project

load_dotenv()

app = typer.Typer()


@app.command()
def echo(message: str):
    typer.echo(message)


@app.command()
def init(directory: str = typer.Argument(".")):
    directory = os.path.abspath(directory)
    typer.echo(f"Initializing project in {os.path.basename(directory)}")
    if not os.path.exists(directory):
        typer.echo(f"Directory {directory} does not exist.")
        raise typer.Exit(1)
    init_project(directory)
    os.makedirs(".threading", exist_ok=True)
    typer.echo(f"Project initialized in {os.path.basename(directory)}.")


@app.command()
def build(
    model: str = typer.Option("gpt-5.1", "--model", "-m", help="Model ID to use for the agent."),
    require_approval: bool = typer.Option(False, "--require-approval", "-r", help="Require manual confirmation for operations."),
):
    """Run a build task using the coding agent. This will build the project and run the tests."""

    task = """
    You are an agent specialized in building and refactoring code. You job is to take the current project codebase, and generate 
    a new codebase under the .threading directory, that is more efficient, maintainable, and readable.
    Your new codebase should be a complete and working codebase, that can be used to build and run the project.

    You will need to use the following technologies:
    - Docker - this is the primary technology you will use to containerize the project to ensure reproducibility.
    - Python - this is the primary language you will use to write the code.
    - Hydra - this is the primary library you will use, if the project has many configuration options.


    For example, your input project could involve a series of scripts. You will need to read them all,
    understand their purpose, and then generate a new codebase that is more efficient, maintainable, and readable.


    You might have the following files:
    main.py # big script that runs the entire project
    visualize.py # script that visualizes the data


    You will create the following files:
    src/data/load_data.py # script that loads the data
    src/data/preprocess_data.py # script that preprocesses the data
    src/data/split_data.py # script that splits the data
    src/data/visualize_data.py # script that visualizes the data
    src/train/train_model.py # script that trains the model
    src/model/model.py # model class
    ...


    Additionally, you will need to use other technologies (as specified by the project) to build the project.
    """
    workspace_path = Path(".threading").resolve()
    
    if not workspace_path.exists():
        typer.echo(f"Workspace directory does not exist: {workspace_path}")
        raise typer.Exit(1)
    
    # Determine project root (directory containing .threading)
    project_root = workspace_path.parent.resolve()
    
    # Auto-approve by default unless require_approval flag is set
    auto_approve = not require_approval
    
    typer.echo(f"Running build task in {workspace_path}")
    
    try:
        asyncio.run(run_build_task(workspace_path, task, model, auto_approve, project_root))
    except Exception as e:
        typer.echo(f"Build task failed: {e}", err=True)
        raise typer.Exit(1)


@app.command()
def code(
    model: str = typer.Option("gpt-5.1", "--model", "-m", help="Model ID to use for the agent."),
    require_approval: bool = typer.Option(False, "--require-approval", "-r", help="Require manual confirmation for operations."),
):
    """Start an interactive LLM chat shell for coding tasks."""
    workspace_path = Path(".threading").resolve()
    
    if not workspace_path.exists():
        typer.echo(f"Workspace directory does not exist: {workspace_path}")
        typer.echo("Run 'thread init' first to initialize the project.")
        raise typer.Exit(1)
    
    # Determine project root (directory containing .threading)
    project_root = workspace_path.parent.resolve()
    
    # Auto-approve by default unless require_approval flag is set
    auto_approve = not require_approval
    
    try:
        asyncio.run(run_coding_agent(workspace_path, model, auto_approve, None, project_root))
    except Exception as e:
        typer.echo(f"Chat session failed: {e}", err=True)
        raise typer.Exit(1)


def cli():
    app()


if __name__ == "__main__":
    cli()
