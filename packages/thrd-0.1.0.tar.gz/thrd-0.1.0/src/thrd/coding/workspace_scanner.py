"""Workspace scanning utilities."""

import os
from pathlib import Path


def scan_workspace(workspace_path: Path) -> str:
    """Scan the workspace directory and return formatted file contents."""
    files_content = []
    
    # Common text file extensions
    text_extensions = {
        '.txt', '.md', '.py', '.json', '.yaml', '.yml', '.cfg', '.ini', 
        '.toml', '.xml', '.html', '.css', '.js', '.ts', '.sh', '.bat',
        '.rs', '.go', '.java', '.cpp', '.c', '.h', '.hpp', '.cs', '.rb',
        '.php', '.swift', '.kt', '.scala', '.clj', '.sql', '.r', '.m',
        '.dockerfile', '.env', '.gitignore', '.dockerignore'
    }
    
    ignored_dirs = {
        '.git', '__pycache__', '.venv', 'venv', 'node_modules', 
        '.mypy_cache', '.pytest_cache', '.ruff_cache', '.hypothesis',
        '.idea', '.vscode', '.DS_Store'
    }
    
    if not workspace_path.exists():
        return ""
    
    for root, dirs, files in os.walk(workspace_path):
        # Filter out ignored directories
        dirs[:] = [d for d in dirs if d not in ignored_dirs]
        
        for filename in sorted(files):
            file_path = Path(root) / filename
            
            # Skip if not a text file (by extension)
            if file_path.suffix.lower() not in text_extensions:
                continue
            
            # Skip binary files or very large files (> 1MB)
            try:
                if file_path.stat().st_size > 1024 * 1024:
                    continue
            except OSError:
                continue
            
            # Get relative path from workspace root
            try:
                relative_path = file_path.relative_to(workspace_path).as_posix()
            except ValueError:
                continue
            
            # Read file contents
            try:
                content = file_path.read_text(encoding='utf-8')
                files_content.append(f"===== {relative_path}\n{content}")
            except (UnicodeDecodeError, OSError):
                # Skip binary files or files that can't be read
                continue
    
    if not files_content:
        return ""
    
    return "<BEGIN_FILES>\n" + "\n".join(files_content) + "\n<END_FILES>\n"


def scan_project_root(project_root: Path, workspace_path: Path) -> str:
    """Scan the project root directory and return formatted file contents.
    
    Excludes the workspace directory and other ignored directories.
    Files are read-only for the agent - they cannot be edited.
    """
    files_content = []
    
    # Common text file extensions
    text_extensions = {
        '.txt', '.md', '.py', '.json', '.yaml', '.yml', '.cfg', '.ini', 
        '.toml', '.xml', '.html', '.css', '.js', '.ts', '.sh', '.bat',
        '.rs', '.go', '.java', '.cpp', '.c', '.h', '.hpp', '.cs', '.rb',
        '.php', '.swift', '.kt', '.scala', '.clj', '.sql', '.r', '.m',
        '.dockerfile', '.env', '.gitignore', '.dockerignore'
    }
    
    ignored_dirs = {
        '.git', '__pycache__', '.venv', 'venv', 'node_modules', 
        '.mypy_cache', '.pytest_cache', '.ruff_cache', '.hypothesis',
        '.idea', '.vscode', '.DS_Store'
    }
    
    # Resolve paths to absolute
    project_root = project_root.resolve()
    workspace_path = workspace_path.resolve()
    
    # Get workspace directory name relative to project root to exclude it
    try:
        workspace_relative = workspace_path.relative_to(project_root)
        workspace_dir_name = workspace_relative.parts[0] if workspace_relative.parts else None
    except ValueError:
        # Workspace is not within project root, so no exclusion needed
        workspace_dir_name = None
    
    if not project_root.exists():
        return ""
    
    for root, dirs, files in os.walk(project_root):
        # Filter out ignored directories
        dirs[:] = [d for d in dirs if d not in ignored_dirs]
        
        # Exclude the workspace directory
        if workspace_dir_name and workspace_dir_name in dirs:
            dirs.remove(workspace_dir_name)
        
        for filename in sorted(files):
            file_path = Path(root) / filename
            
            # Skip if not a text file (by extension)
            if file_path.suffix.lower() not in text_extensions:
                continue
            
            # Skip binary files or very large files (> 1MB)
            try:
                if file_path.stat().st_size > 1024 * 1024:
                    continue
            except OSError:
                continue
            
            # Get relative path from project root
            try:
                relative_path = file_path.relative_to(project_root).as_posix()
            except ValueError:
                continue
            
            # Read file contents
            try:
                content = file_path.read_text(encoding='utf-8')
                files_content.append(f"===== {relative_path}\n{content}")
            except (UnicodeDecodeError, OSError):
                # Skip binary files or files that can't be read
                continue
    
    if not files_content:
        return ""
    
    return "<BEGIN_PROJECT_FILES>\n" + "\n".join(files_content) + "\n<END_PROJECT_FILES>\n"

