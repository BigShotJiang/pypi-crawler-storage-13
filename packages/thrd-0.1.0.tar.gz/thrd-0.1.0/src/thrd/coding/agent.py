"""Coding agent setup and task execution."""

import asyncio
import os
import random
import re
from pathlib import Path

from agents import Agent, ApplyPatchTool, ModelSettings, Runner, function_tool, trace

from .approval_tracker import ApprovalTracker
from .command_runner import CommandRunner
from .workspace_editor import WorkspaceEditor
from .workspace_scanner import scan_workspace, scan_project_root


def _is_rate_limit_error(exc: Exception) -> bool:
    """Check if an exception is a rate limit (429) error."""
    error_msg = str(exc)
    
    # Check for "Error code: 429" format (from agents library)
    if "Error code: 429" in error_msg:
        return True
    
    # Check for status_code attribute (common in HTTP libraries)
    if hasattr(exc, 'status_code') and exc.status_code == 429:
        return True
    
    # Check for response attribute with status_code
    if hasattr(exc, 'response') and hasattr(exc.response, 'status_code'):
        if exc.response.status_code == 429:
            return True
    
    # Check exception type name for rate limit indicators
    exc_type_name = type(exc).__name__.lower()
    if 'ratelimit' in exc_type_name or 'rate_limit' in exc_type_name:
        return True
    
    # Check error message for rate limit indicators (case-insensitive)
    error_msg_lower = error_msg.lower()
    if '429' in error_msg_lower or 'rate limit' in error_msg_lower or 'too many requests' in error_msg_lower:
        return True
    
    return False


def _parse_retry_after(error_msg: str) -> float | None:
    """Parse the retry-after time from error message.
    
    Looks for patterns like "Please try again in 5.176s" or "try again in 5.176 seconds"
    Returns the number of seconds, or None if not found.
    """
    # Pattern to match "try again in X.XXXs" or "try again in X.XXX seconds"
    patterns = [
        r"try again in ([\d.]+)\s*s",
        r"try again in ([\d.]+)\s*seconds?",
        r"retry after ([\d.]+)\s*s",
        r"retry after ([\d.]+)\s*seconds?",
    ]
    
    for pattern in patterns:
        match = re.search(pattern, error_msg, re.IGNORECASE)
        if match:
            try:
                return float(match.group(1))
            except ValueError:
                continue
    
    return None




class CodingAgent:
    """Manages the coding agent and task execution."""
    
    def __init__(
        self,
        workspace_path: Path,
        model: str,
        auto_approve: bool = True,
        project_root: Path | None = None,
    ) -> None:
        """Initialize the coding agent."""
        self.workspace_path = workspace_path.resolve()
        self.workspace_path.mkdir(exist_ok=True)
        self.model = model
        self.auto_approve = auto_approve
        self.project_root = project_root.resolve() if project_root else None
        
        self.approvals = ApprovalTracker()
        self.editor = WorkspaceEditor(self.workspace_path, self.approvals, auto_approve)
        self.command_runner = CommandRunner(self.workspace_path, self.approvals, auto_approve)
        
        # Create tools
        self.patch_tool = ApplyPatchTool(editor=self.editor)
        
        @function_tool
        def run_command(command: str) -> str:
            """Execute a shell command in the workspace directory. Use this to run scripts, build commands, tests, or any other shell operations."""
            return self.command_runner.run_command(command)
        
        self.run_command_tool = run_command
        
        # Create agent
        instructions_parts = [
            f"You can edit files inside {self.workspace_path} using the apply_patch tool. "
            "When modifying an existing file, include the file contents between "
            "<BEGIN_FILES> and <END_FILES> in your prompt. "
        ]
        
        if self.project_root:
            instructions_parts.append(
                f"You can read files from the project root ({self.project_root}) for reference, "
                "but you CANNOT edit them. Files from the project root are marked with "
                "<BEGIN_PROJECT_FILES> and <END_PROJECT_FILES>. "
                "You can only create and edit files within the workspace directory."
            )
        
        instructions_parts.append(
            "You can execute shell commands using the run_command tool to build, test, or run scripts."
        )
        
        self.agent = Agent(
            name="Patch Assistant",
            model=model,
            instructions="".join(instructions_parts),
            tools=[self.patch_tool, self.run_command_tool],
            model_settings=ModelSettings(tool_choice="required"),
        )
        
        self.previous_response_id: str | None = None

    async def run_task(self, task: str) -> str | None:
        """Run a single task and return the new response ID."""
        # Scan project root and workspace, include existing files in the prompt
        project_files = ""
        if self.project_root:
            project_files = scan_project_root(self.project_root, self.workspace_path)
        
        workspace_files = scan_workspace(self.workspace_path)
        
        # Build the prompt with existing files if any
        prompt_parts = []
        if project_files:
            prompt_parts.append(project_files)
        if workspace_files:
            prompt_parts.append(workspace_files)
        
        if prompt_parts:
            prompt = "\n".join(prompt_parts) + "\n" + task
        else:
            prompt = task
        
        print("[run] Executing task...")
        print(f"[llm] User prompt: {task}\n")
        
        # Retry with exponential backoff on rate limit errors
        max_retries = 5
        initial_delay = 1.0
        max_delay = 60.0
        
        for attempt in range(max_retries + 1):
            try:
                result = await Runner.run(
                    self.agent,
                    prompt,
                    previous_response_id=self.previous_response_id,
                )
                break
            except Exception as e:
                # Only retry on rate limit errors
                if not _is_rate_limit_error(e):
                    raise
                
                # If this was the last attempt, raise the exception
                if attempt >= max_retries:
                    print(f"[error] Rate limit error after {max_retries + 1} attempts. Giving up.")
                    raise
                
                # Try to parse retry-after time from error message
                error_msg = str(e)
                retry_after = _parse_retry_after(error_msg)
                
                if retry_after is not None:
                    # Use the server-suggested retry time, add small jitter
                    delay = retry_after + (retry_after * 0.1 * random.random())  # 0-10% jitter
                    delay = min(delay, max_delay)  # Cap at max_delay
                else:
                    # Fall back to exponential backoff if we can't parse the retry time
                    delay = min(initial_delay * (2 ** attempt), max_delay)
                    # Add jitter (random 0-25% of delay) to avoid thundering herd
                    jitter = delay * 0.25 * random.random()
                    delay = delay + jitter
                
                print(f"[retry] Rate limit error (attempt {attempt + 1}/{max_retries + 1}). "
                      f"Retrying in {delay:.2f} seconds...")
                await asyncio.sleep(delay)
        
        # Print LLM responses and tool calls
        self._print_llm_responses(result)
        
        print("\n[llm] ====================\n")
        print(f"[run] Final output:\n{result.final_output}\n")
        
        self.previous_response_id = result.last_response_id
        return self.previous_response_id

    def _print_llm_responses(self, result) -> None:
        """Print LLM responses and tool calls for debugging."""
        print("\n[llm] === LLM Responses ===")
        if hasattr(result, 'new_items') and result.new_items:
            for idx, item in enumerate(result.new_items, 1):
                if hasattr(item, 'raw_item'):
                    raw = item.raw_item
                    if isinstance(raw, dict):
                        role = raw.get('role', 'unknown')
                        
                        # Print assistant messages
                        if role == 'assistant':
                            print(f"\n[llm] Assistant message {idx}:")
                            if 'content' in raw and raw['content']:
                                content = raw['content']
                                if isinstance(content, list):
                                    for part_idx, part in enumerate(content):
                                        if isinstance(part, dict):
                                            part_type = part.get('type', 'unknown')
                                            if part_type == 'text':
                                                text = part.get('text', '')
                                                print(f"[llm] Text content:\n{text}")
                                            elif part_type == 'tool_call':
                                                tool_call = part.get('tool_call', {})
                                                tool_name = tool_call.get('name', 'unknown')
                                                tool_id = tool_call.get('id', 'unknown')
                                                print(f"[llm] Tool call: {tool_name} (id: {tool_id})")
                                elif isinstance(content, str):
                                    print(f"[llm] Text content:\n{content}")
                            else:
                                print("[llm] (No content)")
                        
                        # Print tool calls separately
                        if 'tool_calls' in raw and raw['tool_calls']:
                            print(f"\n[llm] Tool calls in message {idx}:")
                            for tool_idx, tool_call in enumerate(raw['tool_calls'], 1):
                                tool_name = tool_call.get('function', {}).get('name', 'unknown')
                                tool_args = tool_call.get('function', {}).get('arguments', '{}')
                                tool_id = tool_call.get('id', 'unknown')
                                print(f"[llm]   Tool call {tool_idx}: {tool_name} (id: {tool_id})")
                                print(f"[llm]   Arguments: {tool_args}")
                        
                        # Print tool results
                        if role == 'tool':
                            tool_name = raw.get('name', 'unknown')
                            tool_content = raw.get('content', '')
                            print(f"\n[llm] Tool result from {tool_name}:")
                            print(f"[llm] {tool_content}")
        
        # Also check if there are messages in the result
        if hasattr(result, 'messages'):
            print("\n[llm] === All Messages ===")
            for idx, msg in enumerate(result.messages, 1):
                if hasattr(msg, 'role'):
                    print(f"[llm] Message {idx}: {msg.role}")
                    if hasattr(msg, 'content'):
                        content = msg.content
                        if isinstance(content, str):
                            print(f"[llm] {content[:500]}..." if len(content) > 500 else f"[llm] {content}")


async def run_build_task(
    workspace_path: Path,
    task: str,
    model: str = "gpt-5.1",
    auto_approve: bool = True,
    project_root: Path | None = None,
) -> str:
    """Run a single build task using the coding agent, then drop into interactive chat."""
    with trace("build_task"):
        # Determine project root if not provided
        if project_root is None:
            workspace_resolved = workspace_path.resolve()
            # Try to find project root by going up from workspace until we find a directory with common project files
            # or use the parent directory if workspace is .threading/workspace
            if workspace_resolved.name == "workspace" and workspace_resolved.parent.name == ".threading":
                project_root = workspace_resolved.parent.parent
            else:
                # Default to current working directory
                project_root = Path(os.getcwd()).resolve()
        
        agent = CodingAgent(workspace_path, model, auto_approve, project_root)
        
        print(f"[build] Project root: {agent.project_root}")
        print(f"[build] Workspace root: {agent.workspace_path}")
        print(f"[build] Using model: {model}")
        print(f"[build] Task: {task}\n")
        
        await agent.run_task(task)
        
        print("\n[build] Build task completed successfully.")
        print("[info] Entering interactive chat mode. Type 'exit' or 'quit' to end the session.\n")
        
        # Interactive chat loop
        while True:
            try:
                user_input = input("> ").strip()
                
                if not user_input:
                    continue
                
                # Check for exit commands
                if user_input.lower() in ("exit", "quit", "q"):
                    print("[info] Exiting...")
                    break
                
                await agent.run_task(user_input)
                
            except KeyboardInterrupt:
                print("\n[info] Exiting...")
                break
            except EOFError:
                print("\n[info] Exiting...")
                break
        
        return agent.previous_response_id or ""


async def run_coding_agent(
    workspace_path: Path,
    model: str,
    auto_approve: bool = True,
    objective: str | None = None,
    project_root: Path | None = None,
) -> None:
    """Run the coding agent with optional initial objective (interactive mode)."""
    with trace("apply_patch_example"):
        # Determine project root if not provided
        if project_root is None:
            workspace_resolved = workspace_path.resolve()
            # Try to find project root by going up from workspace until we find a directory with common project files
            # or use the parent directory if workspace is .threading/workspace
            if workspace_resolved.name == "workspace" and workspace_resolved.parent.name == ".threading":
                project_root = workspace_resolved.parent.parent
            else:
                # Default to current working directory
                project_root = Path(os.getcwd()).resolve()
        
        agent = CodingAgent(workspace_path, model, auto_approve, project_root)
        
        print(f"[info] Project root: {agent.project_root}")
        print(f"[info] Workspace root: {agent.workspace_path}")
        print(f"[info] Using model: {model}")
        print("[info] Type 'exit' or 'quit' to end the session\n")
        
        # Run initial objective if provided
        if objective:
            await agent.run_task(objective)
        
        # Interactive loop
        while True:
            try:
                task = input("> ").strip()
                
                if not task:
                    continue
                
                # Check for exit commands
                if task.lower() in ("exit", "quit", "q"):
                    print("[info] Exiting...")
                    break
                
                await agent.run_task(task)
                
            except KeyboardInterrupt:
                print("\n[info] Exiting...")
                break
            except EOFError:
                print("\n[info] Exiting...")
                break

