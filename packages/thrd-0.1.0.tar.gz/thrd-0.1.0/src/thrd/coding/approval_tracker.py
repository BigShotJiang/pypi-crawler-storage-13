"""Approval tracking for operations."""

import hashlib

from agents.editor import ApplyPatchOperation


class ApprovalTracker:
    """Tracks approved operations to avoid duplicate approvals."""
    
    def __init__(self) -> None:
        self._approved: set[str] = set()

    def fingerprint(self, operation: ApplyPatchOperation, relative_path: str) -> str:
        """Generate a fingerprint for a patch operation."""
        hasher = hashlib.sha256()
        hasher.update(operation.type.encode("utf-8"))
        hasher.update(b"\0")
        hasher.update(relative_path.encode("utf-8"))
        hasher.update(b"\0")
        hasher.update((operation.diff or "").encode("utf-8"))
        return hasher.hexdigest()

    def fingerprint_command(self, command: str) -> str:
        """Generate a fingerprint for a command."""
        hasher = hashlib.sha256()
        hasher.update(b"command")
        hasher.update(b"\0")
        hasher.update(command.encode("utf-8"))
        return hasher.hexdigest()

    def remember(self, fingerprint: str) -> None:
        """Mark a fingerprint as approved."""
        self._approved.add(fingerprint)

    def is_approved(self, fingerprint: str) -> bool:
        """Check if a fingerprint is already approved."""
        return fingerprint in self._approved

