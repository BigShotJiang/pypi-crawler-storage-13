#!/usr/bin/env python3
"""CLI entry point for the coding agent."""

import argparse
import asyncio
from pathlib import Path

from dotenv import load_dotenv

from .agent import run_coding_agent

load_dotenv()


def main() -> None:
    """Main entry point for the coding agent CLI."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--require-approval",
        action="store_true",
        default=False,
        help="Require manual confirmation for operations.",
    )
    parser.add_argument(
        "--model",
        default="gpt-5.1",
        help="Model ID to use for the agent.",
    )
    parser.add_argument(
        "objective",
        nargs="?",
        default=None,
        help="Optional initial objective/task for the agent to accomplish.",
    )
    args = parser.parse_args()
    
    workspace_path = Path("workspace").resolve()
    # Determine project root (parent of workspace directory)
    project_root = workspace_path.parent.resolve()
    # Auto-approve by default unless require_approval flag is set
    auto_approve = not args.require_approval
    asyncio.run(run_coding_agent(workspace_path, args.model, auto_approve, args.objective, project_root))


if __name__ == "__main__":
    main()

