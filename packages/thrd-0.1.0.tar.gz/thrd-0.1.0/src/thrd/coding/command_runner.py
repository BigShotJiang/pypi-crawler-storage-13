"""Command execution utilities."""

import os
import subprocess
from pathlib import Path

from .approval_tracker import ApprovalTracker


class CommandRunner:
    """Handles shell command execution in the workspace."""
    
    def __init__(self, root: Path, approvals: ApprovalTracker, auto_approve: bool) -> None:
        self._root = root.resolve()
        self._approvals = approvals
        # Auto-approve by default unless explicitly disabled or env var requires approval
        # Env var APPLY_PATCH_REQUIRE_APPROVAL="1" overrides to require approval
        if os.environ.get("APPLY_PATCH_REQUIRE_APPROVAL") == "1":
            self._auto_approve = False
        else:
            self._auto_approve = auto_approve

    def run_command(self, command: str) -> str:
        """Run a shell command in the workspace directory."""
        print(f"\n[tool] run_command called")
        print(f"[tool] command: {command}")
        
        fingerprint = self._approvals.fingerprint_command(command)
        
        if not (self._auto_approve or self._approvals.is_approved(fingerprint)):
            print("\n[command] approval required")
            print(f"- command: {command}")
            answer = input("Proceed? [Y/n] ").strip().lower()
            if answer in {"n", "no"}:
                raise RuntimeError("Command execution rejected by user.")
        
        self._approvals.remember(fingerprint)
        
        try:
            # Run command in the workspace directory
            # Use stdin=DEVNULL to prevent hanging on input prompts
            # Use start_new_session=True to create a new process group for better cleanup
            result = subprocess.run(
                command,
                shell=True,
                cwd=self._root,
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout
                stdin=subprocess.DEVNULL,  # Prevent hanging on input
                start_new_session=True,  # Create new process group
                bufsize=1,  # Line buffering
            )
            
            output_parts = []
            if result.stdout:
                output_parts.append(f"STDOUT:\n{result.stdout}")
            if result.stderr:
                output_parts.append(f"STDERR:\n{result.stderr}")
            if result.returncode != 0:
                output_parts.append(f"Exit code: {result.returncode}")
            
            output = "\n".join(output_parts) if output_parts else "Command executed successfully (no output)"
            print(f"[tool] run_command result:\n{output}\n")
            return output
        except subprocess.TimeoutExpired as e:
            error_msg = "Command execution timed out after 5 minutes."
            print(f"[tool] run_command error: {error_msg}")
            # Try to kill the process if it's still running
            if hasattr(e, 'process') and e.process:
                try:
                    e.process.kill()
                    e.process.wait(timeout=5)
                except Exception:
                    pass
            raise RuntimeError(error_msg)
        except Exception as e:
            error_msg = f"Command execution failed: {e}"
            print(f"[tool] run_command error: {error_msg}")
            raise RuntimeError(error_msg)

