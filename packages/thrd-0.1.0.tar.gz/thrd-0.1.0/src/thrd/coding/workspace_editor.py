"""Workspace file editing operations."""

import os
from pathlib import Path

from agents import apply_diff
from agents.editor import ApplyPatchOperation, ApplyPatchResult

from .approval_tracker import ApprovalTracker


class WorkspaceEditor:
    """Handles file operations in the workspace."""
    
    def __init__(self, root: Path, approvals: ApprovalTracker, auto_approve: bool) -> None:
        self._root = root.resolve()
        self._approvals = approvals
        # Auto-approve by default unless explicitly disabled or env var requires approval
        # Env var APPLY_PATCH_REQUIRE_APPROVAL="1" overrides to require approval
        if os.environ.get("APPLY_PATCH_REQUIRE_APPROVAL") == "1":
            self._auto_approve = False
        else:
            self._auto_approve = auto_approve

    def create_file(self, operation: ApplyPatchOperation) -> ApplyPatchResult:
        """Create a new file in the workspace."""
        relative = self._relative_path(operation.path)
        print(f"\n[tool] apply_patch called")
        print(f"[tool] operation: create_file")
        print(f"[tool] path: {relative}")
        self._require_approval(operation, relative)
        target = self._resolve(operation.path, ensure_parent=True)
        diff = operation.diff or ""
        content = apply_diff("", diff, mode="create")
        target.write_text(content, encoding="utf-8")
        result = ApplyPatchResult(output=f"Created {relative}")
        print(f"[tool] apply_patch result: {result.output}\n")
        return result

    def update_file(self, operation: ApplyPatchOperation) -> ApplyPatchResult:
        """Update an existing file in the workspace."""
        relative = self._relative_path(operation.path)
        print(f"\n[tool] apply_patch called")
        print(f"[tool] operation: update_file")
        print(f"[tool] path: {relative}")
        self._require_approval(operation, relative)
        target = self._resolve(operation.path)
        original = target.read_text(encoding="utf-8")
        diff = operation.diff or ""
        patched = apply_diff(original, diff)
        target.write_text(patched, encoding="utf-8")
        result = ApplyPatchResult(output=f"Updated {relative}")
        print(f"[tool] apply_patch result: {result.output}\n")
        return result

    def delete_file(self, operation: ApplyPatchOperation) -> ApplyPatchResult:
        """Delete a file from the workspace."""
        relative = self._relative_path(operation.path)
        print(f"\n[tool] apply_patch called")
        print(f"[tool] operation: delete_file")
        print(f"[tool] path: {relative}")
        self._require_approval(operation, relative)
        target = self._resolve(operation.path)
        target.unlink(missing_ok=True)
        result = ApplyPatchResult(output=f"Deleted {relative}")
        print(f"[tool] apply_patch result: {result.output}\n")
        return result

    def _relative_path(self, value: str) -> str:
        """Get the relative path from workspace root."""
        resolved = self._resolve(value)
        return resolved.relative_to(self._root).as_posix()

    def _resolve(self, relative: str, ensure_parent: bool = False) -> Path:
        """Resolve a path relative to the workspace root."""
        candidate = Path(relative)
        target = candidate if candidate.is_absolute() else (self._root / candidate)
        target = target.resolve()
        try:
            target.relative_to(self._root)
        except ValueError:
            raise RuntimeError(f"Operation outside workspace: {relative}") from None
        if ensure_parent:
            target.parent.mkdir(parents=True, exist_ok=True)
        return target

    def _require_approval(self, operation: ApplyPatchOperation, display_path: str) -> None:
        """Require approval for an operation unless auto-approved."""
        fingerprint = self._approvals.fingerprint(operation, display_path)
        if self._auto_approve or self._approvals.is_approved(fingerprint):
            self._approvals.remember(fingerprint)
            return

        print("\n[apply_patch] approval required")
        print(f"- type: {operation.type}")
        print(f"- path: {display_path}")
        if operation.diff:
            preview = operation.diff if len(operation.diff) < 400 else f"{operation.diff[:400]}…"
            print("- diff preview:\n", preview)
        answer = input("Proceed? [Y/n] ").strip().lower()
        if answer in {"n", "no"}:
            raise RuntimeError("Apply patch operation rejected by user.")
        self._approvals.remember(fingerprint)

