ALLOWED_EXTENSIONS = {
    ".txt",
    ".md",
    ".py",
    ".json",
    ".yaml",
    ".yml",
    ".cfg",
    ".ini",
}


IGNORED_DIRECTORIES = {
    # version control
    ".git",
    ".hg",
    ".svn",
    # caches
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".hypothesis",
    ".nox",
    ".ipynb_checkpoints",
    # virtual environments
    ".venv",
    "venv",
    "env",
    ".env",
    "virtualenv",
    ".virtualenv",
    # build artifacts
    "build",
    "dist",
    ".eggs",
    "*.egg-info",
    # IDE/editor
    ".idea",
    ".vscode",
    ".spyproject",
    # deployment/infra
    ".serverless",
    ".serverless_cache",
    ".aws-sam",
    ".terraform",
    # OS-specific
    ".DS_Store",
    "Thumbs.db",
    "lost+found",
}
