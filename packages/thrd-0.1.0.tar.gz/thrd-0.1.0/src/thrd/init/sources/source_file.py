from dataclasses import dataclass


@dataclass
class SourceFile:
    file: str
    absolute_path: str
    error: bool
    error_message: str
    contents: str
