import os
import logging
from dataclasses import asdict
import json

from .source_file import SourceFile
from .source_allow_list import IGNORED_DIRECTORIES, ALLOWED_EXTENSIONS


class DirectoryScanner:
    MAX_FILE_SIZE_BYTES = 1024 * 1024  # 1 MB

    @staticmethod
    def _has_allowed_extension(filename: str) -> bool:
        _, extension = os.path.splitext(filename)
        return extension.lower() in ALLOWED_EXTENSIONS

    @staticmethod
    def _is_within_size_limit(filepath: str) -> bool:
        return os.path.getsize(filepath) <= DirectoryScanner.MAX_FILE_SIZE_BYTES

    @staticmethod
    def _read_file_safely(filepath: str, relative_path: str) -> SourceFile:
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                contents = f.read()
            return SourceFile(
                file=relative_path,
                absolute_path=os.path.abspath(filepath),
                error=False,
                error_message="",
                contents=contents,
            )
        except Exception as e:
            logging.exception(f"Failed to read file: {filepath}")
            return SourceFile(
                file=relative_path,
                absolute_path=os.path.abspath(filepath),
                error=True,
                error_message="Could not read file: " + str(e),
                contents="",
            )

    @staticmethod
    def source_file_list_to_string(source_files: list[SourceFile]) -> str:
        return json.dumps([asdict(item) for item in source_files], indent=2)

    @staticmethod
    def scan(directory: str) -> list[SourceFile]:
        results = []

        for root, dirs, files in os.walk(directory):
            # Filter out ignored directories by modifying dirs in-place
            dirs[:] = [d for d in dirs if d not in IGNORED_DIRECTORIES]

            for filename in sorted(files):
                if not DirectoryScanner._has_allowed_extension(filename):
                    continue

                filepath = os.path.join(root, filename)

                if not DirectoryScanner._is_within_size_limit(filepath):
                    continue

                relative_path = os.path.relpath(filepath, directory)
                source_file = DirectoryScanner._read_file_safely(
                    filepath, relative_path
                )
                results.append(source_file)

        return results
