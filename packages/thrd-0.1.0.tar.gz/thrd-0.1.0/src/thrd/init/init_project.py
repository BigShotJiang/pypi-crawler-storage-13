from .sources.directory_scanner import DirectoryScanner


def init_project(directory: str = "."):
    contents = DirectoryScanner.scan(directory)
    print("\n")
    print(DirectoryScanner.source_file_list_to_string(contents))
