from setuptools import setup, find_packages


setup(
    name="goodgute",  
    author="Paddy",
    version="0.1.3",
    packages=find_packages(),
        install_requires=[
        "numpy<2",
        "fastapi==0.115.0",
        "uvicorn==0.30.0",
        "transformers==4.44.0",
        "torch==2.2.2",
        "pydantic==2.8.2",
        "sentencepiece==0.1.99",
        "requests",
        "sacremoses==0.0.53",
    ],
    entry_points={
        "console_scripts": [
            "GoodGute=goodgute.cli:main",
        ],
    },
)
