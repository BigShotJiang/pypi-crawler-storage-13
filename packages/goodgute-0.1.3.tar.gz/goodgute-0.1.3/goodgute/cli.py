import argparse
from .translator import translate_text
import warnings


def main():

    parser = argparse.ArgumentParser(description="GoodGute")
    parser.add_argument("-t", "--textfile", required=True, help="")
    args = parser.parse_args()

    with open(args.textfile, "r", encoding="utf-8") as f:
        text = f.read()

    translation = translate_text(text)
    print("Translation Result:\n", translation)
    warnings.filterwarnings("ignore")


if __name__ == "__main__":
    main()
