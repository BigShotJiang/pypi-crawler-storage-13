pub const BOLD: &str = "\x1b[1m";
pub const CYAN: &str = "\x1b[0;36m";
pub const GREEN: &str = "\x1b[1;38;5;82m";
pub const ORANGE: &str = "\x1b[1;38;5;214m";
pub const RESET: &str = "\x1b[0m";