pub const FROM: &str = "from";
pub const TO: &str = "to";
pub const DATA: &str = "data";
pub const LABEL: &str = "label";
pub const TYPE: &str = "type";
pub const BAD_JSON_MESSAGE: &str = "JSON was not well-formatted";