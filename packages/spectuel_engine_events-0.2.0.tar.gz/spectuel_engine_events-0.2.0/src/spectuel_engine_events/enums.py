from enum import Enum


class Side(str, Enum):
    ASK = "ask"
    BID = "bid"
