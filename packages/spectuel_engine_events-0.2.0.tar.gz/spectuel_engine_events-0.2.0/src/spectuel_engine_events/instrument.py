from enum import Enum
from typing import Literal
from uuid import UUID

from .model import CustomBaseModel


class InstrumentEventType(str, Enum):
    NEW_INSTRUMENT = "new"  # Instrument appended to the engine


class NewInstrumentEvent(CustomBaseModel):
    type: Literal[InstrumentEventType.NEW_INSTRUMENT] = InstrumentEventType.NEW_INSTRUMENT
    instrument_id: UUID
