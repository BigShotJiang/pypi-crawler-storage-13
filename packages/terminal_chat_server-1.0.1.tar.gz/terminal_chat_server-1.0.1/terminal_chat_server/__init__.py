"""
Terminal Chat Server - A lightweight terminal-based chat server with room access codes.
"""

__version__ = "1.0.1"
__author__ = "Peter Gatitu"
__email__ = "gatitu@evidflow.com"

from .server import TerminalChatServer

__all__ = ["TerminalChatServer"]
