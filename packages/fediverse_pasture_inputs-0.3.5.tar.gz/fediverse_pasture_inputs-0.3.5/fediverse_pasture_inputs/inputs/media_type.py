# SPDX-FileCopyrightText: 2025 Helge
#
# SPDX-License-Identifier: MIT

from fediverse_pasture_inputs.types import InputData, Details
from fediverse_pasture_inputs.utils import pre_format, escape_markdown

details = Details(
    extractor={
        "activity": lambda x: pre_format(
            escape_markdown(x.get("object", {}).get("content"))
        )
        + pre_format(x.get("object", {}).get("mediaType")),
        "mastodon": lambda x: pre_format(escape_markdown(x.get("content", "-"))),
        "misskey": lambda x: pre_format(escape_markdown(x.get("text", "-"))),
    },
    title={
        "mastodon": "| content | mediaType | content | Example |",
        "misskey": "| content | mediaType | contentMap | text | Example |",
    },
)

media_types = ["text/html", "text/markdown", "text/plain"]

data = InputData(
    title="Media Types",
    frontmatter="""This support table illustrates what
happens when varying media types are chosen.
""",
    filename="media_type.md",
    group="Object Properties",
    examples=[
        {"content": "<b>text</b>", "mediaType": media_type}
        for media_type in media_types
    ]
    + [{"content": "__text__", "mediaType": media_type} for media_type in media_types]
    + [{"content": "**text**", "mediaType": media_type} for media_type in media_types],
    details=details,
)
