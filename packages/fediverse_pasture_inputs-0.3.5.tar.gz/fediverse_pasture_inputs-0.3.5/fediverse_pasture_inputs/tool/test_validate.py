from .validate import load_object_schema, object_validate


def test_load_object_schema():
    result = load_object_schema()

    assert "type" in result


def test_validate_object():
    valid, _ = object_validate(
        {
            "@context": [
                "https://www.w3.org/ns/activitystreams",
                {"Hashtag": "as:Hashtag", "sensitive": "as:sensitive"},
            ],
            "attributedTo": "http://actor.example",
            "content": "content",
            "id": "http://actor.example/object/GkPlv6304dk",
            "name": "name",
            "published": "2025-11-20T08:43:55Z",
            "summary": "summary",
            "to": ["https://www.w3.org/ns/activitystreams#Public"],
            "type": "Note",
        }
    )
    assert valid


def test_invalid_obj():
    valid, _ = object_validate(
        {
            "@context": [
                "https://www.w3.org/ns/activitystreams",
                {"Hashtag": "as:Hashtag", "sensitive": "as:sensitive"},
            ],
            "attributedTo": "http://actor.example",
            "content": "content",
            "name": "name",
            "published": "2025-11-20T08:43:55Z",
            "summary": "summary",
            "to": ["https://www.w3.org/ns/activitystreams#Public"],
            "type": "Note",
        }
    )

    assert not valid
