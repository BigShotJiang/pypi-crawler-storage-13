import json
import logging

from fediverse_pasture_inputs.tool.validate import object_validate
from fediverse_pasture_inputs.types import InputData

from .write import write_json, write_support_table
from .transformer import ExampleTransformer

logger = logging.getLogger(__name__)


async def page_from_inputs(fp, inputs: InputData):
    transformer = ExampleTransformer()

    fp.write(f"# {inputs.title}\n\n")
    fp.write(inputs.frontmatter)

    if inputs.support:
        await write_support_table(fp, inputs, transformer)

    fp.write("\n\n## Objects \n\n")

    for idx, ex in enumerate(inputs.examples):
        fp.write(f"\n### Object {idx + 1}\n\n")
        obj = await transformer.create_object(ex)
        valid, ex = object_validate(obj)

        if not valid:
            fp.write("❌❌❌ does not obey schema ❌❌❌\n\n```\n")
            fp.write(str(ex))
            fp.write("\n```\n\n\n")

        write_json(fp, obj)

    fp.write("\n\n## Activities \n\n")

    for idx, ex in enumerate(inputs.examples):
        fp.write(f"\n### Activity {idx + 1}\n\n")
        write_json(fp, await transformer.create_activity(ex))


def add_dict_to_zip(zipcontainer, data: dict, filename: str):
    formatted = json.dumps(data, indent=2).encode("utf-8")
    with zipcontainer.open(filename, "w") as f:
        f.write(formatted)


async def add_samples_to_zip(zipcontainer, inputs: InputData):
    transformer = ExampleTransformer()

    base = inputs.filename.removesuffix(".md")

    for idx, ex in enumerate(inputs.examples):
        add_dict_to_zip(
            zipcontainer,
            await transformer.create_activity(ex) or {},
            f"activity/{base}_{idx}.json",
        )
        add_dict_to_zip(
            zipcontainer,
            await transformer.create_object(ex) or {},
            f"object/{base}_{idx}.json",
        )
