import json
import logging

from fediverse_pasture_inputs.tool.transformer import ExampleTransformer
from fediverse_pasture_inputs.tool.validate import object_validate
from fediverse_pasture_inputs.types import InputData

logger = logging.getLogger(__name__)


def write_json(fp, data):
    fp.write("```json\n")
    fp.write(json.dumps(data, indent=2, sort_keys=True))
    fp.write("\n```\n\n")


async def write_support_table(fp, inputs: InputData, transformer: ExampleTransformer):
    if not inputs.support:
        raise ValueError("You cannot call this, without support support")

    fp.write("\n\n## Support Table Preview\n\n")
    fp.write(f"| {inputs.support.title} | Object | Activity |\n")
    fp.write("| --- | --- | --- | \n")
    for idx, ex in enumerate(inputs.examples):
        activity = await transformer.create_activity(ex)

        if activity is None:
            logger.info("activity not found for %s", idx)
            activity = {}

        transformed = inputs.support.result["activity"](activity)  # type: ignore
        obj = await transformer.create_object(ex)
        valid, _ = object_validate(obj)

        obj_item = f"[Object](#object-{idx + 1})"

        if not valid:
            obj_item += " 🚨"

        fp.write(f"| {transformed} | {obj_item} | [Activity](#activity-{idx + 1}) |\n")
