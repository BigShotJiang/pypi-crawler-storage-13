import json
from jsonschema import ValidationError, validate


def load_object_schema():
    with open("schemas/activity-pub-object.schema.json") as fp:
        return json.load(fp)


schema = load_object_schema()


def object_validate(obj: dict):
    try:
        validate(obj, schema=schema)
        return True, None
    except ValidationError as e:
        return False, e
