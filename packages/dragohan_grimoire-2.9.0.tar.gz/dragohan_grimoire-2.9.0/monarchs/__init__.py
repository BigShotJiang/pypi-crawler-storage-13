"""
💀 SHADOW MONARCH SYSTEM + ORGAN SYSTEMS 💀
Unified initialization for:
- Agents (lead/data/ops)
- Systems (data system, business system, etc.)
"""

# ---------------------------
# Step 1: Import agent registry first
# ---------------------------
from .registry import register_monarch

# ---------------------------
# Step 2: Import agent factory
# ---------------------------
from .factory import summon, waitfor

# ---------------------------
# Step 3: Import monarchs (agents)
# These trigger @register_monarch decorators
# ---------------------------
from . import lead
from . import data
from . import restaurant

# ---------------------------
# Step 4: Import Organ Systems
# ---------------------------
from .systems import summon_system

# ---------------------------
# Step 5: Exports
# ---------------------------
__all__ = [
    "summon",            # Agent summoning
    "summon_system",     # System summoning
    "waitfor",
    "register_monarch"
]

# ---------------------------
# Step 6: Shadow Banner
# ---------------------------
def _show_banner():
    banner = """
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   💀 SHADOW MONARCH SYSTEM AWAKENED 💀                        ║
║   Agents + Organ Systems Ready                                ║
║                                                               ║
║   Your Shadow Army Stands Ready:                             ║
║   ├─ summon("lead")        → Lead Enrichment Monarch          ║
║   ├─ summon("data")        → Data Analysis Monarch            ║
║   ├─ summon("ops")         → Operations Monarch               ║
║                                                               ║
║   Your Organ Systems Stand Ready:                             ║
║   ├─ summon_system("data") → Data Orchestration System        ║
║   └─ summon_system(...)    → More systems soon…               ║
║                                                               ║
║   Commands of Power:                                          ║
║   ├─ await agent.action()          → Async execution          ║
║   ├─ waitfor(agent.action())       → Blocking sync            ║
║   ├─ system(data)                  → Single-call pipeline     ║
║   ├─ while system.works: ...        → Streaming mode          ║
║                                                               ║
║   The weak code alone. The strong code with agents + systems. ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
"""
    print(banner)

_show_banner()


