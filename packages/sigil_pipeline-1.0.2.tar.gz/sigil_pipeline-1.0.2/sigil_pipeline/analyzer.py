"""
Analyzer module for running static analysis tools on Rust crates.

Provides functions to run Clippy, Geiger, outdated, and documentation checks.

Copyright (c) 2025 Dave Tofflemire, SigilDERG Project
"""

import json
import logging
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

# Import OS-agnostic cargo utilities from sigil_pipeline.utils
from .utils import (
    build_cargo_command,
    build_cargo_subcommand_command,
    check_cargo_available,
)

logger = logging.getLogger(__name__)


@dataclass
class ClippyResult:
    """Results from running cargo clippy."""

    warning_count: int = 0
    error_count: int = 0
    warnings: List[Dict[str, Any]] = None
    errors: List[Dict[str, Any]] = None
    success: bool = True

    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []
        if self.errors is None:
            self.errors = []


@dataclass
class GeigerResult:
    """Results from running cargo geiger."""

    total_unsafe_items: int = 0
    unsafe_functions: int = 0
    unsafe_expressions: int = 0
    unsafe_impls: int = 0
    unsafe_methods: int = 0
    packages_with_unsafe: int = 0
    success: bool = True


@dataclass
class OutdatedResult:
    """Results from running cargo outdated."""

    outdated_count: int = 0
    total_dependencies: int = 0
    outdated_ratio: float = 0.0
    success: bool = True


@dataclass
class DocStats:
    """Documentation statistics for a crate."""

    total_files: int = 0
    files_with_docs: int = 0
    total_doc_comments: int = 0
    doc_coverage: float = 0.0
    has_docs: bool = False


@dataclass
class LicenseResult:
    """Results from license checking."""

    crate_license: Optional[str] = None
    """Primary license of the crate (from Cargo.toml)."""
    all_licenses: List[str] = None
    """All licenses found in crate and dependencies."""
    has_allowed_license: bool = True
    """Whether crate has at least one allowed license."""
    success: bool = True

    def __post_init__(self):
        if self.all_licenses is None:
            self.all_licenses = []


@dataclass
class DenyResult:
    """Results from cargo-deny security and license auditing."""

    advisories_found: int = 0
    """Number of security advisories found."""
    license_violations: int = 0
    """Number of license violations."""
    banned_dependencies: int = 0
    """Number of banned dependencies."""
    highest_severity: Optional[str] = None
    """Highest severity level found (e.g., 'critical', 'high', 'medium', 'low')."""
    passed: bool = True
    """Whether all deny checks passed."""
    success: bool = True
    """Whether cargo-deny ran successfully."""


@dataclass
class CrateAnalysisReport:
    """Complete analysis report for a crate."""

    crate_name: str
    crate_dir: Path
    clippy: ClippyResult
    geiger: Optional[GeigerResult] = None
    outdated: Optional[OutdatedResult] = None
    docs: Optional[DocStats] = None
    license: Optional[LicenseResult] = None
    deny: Optional[DenyResult] = None
    edition: Optional[str] = None


def run_clippy(
    crate_dir: Path, timeout: int = 600, env: Optional[Dict[str, str]] = None
) -> ClippyResult:
    """
    Run cargo clippy on a crate and parse the results.

    Args:
        crate_dir: Path to crate directory
        timeout: Command timeout in seconds

    Returns:
        ClippyResult with warning/error counts
    """
    if not check_cargo_available():
        logger.error("cargo is not available")
        return ClippyResult(success=False)

    cmd = build_cargo_command(
        "clippy",
        "--message-format=json",
        "--quiet",
        "--",
        "-W",
        "clippy::all",
    )

    try:
        result = subprocess.run(
            cmd,
            cwd=crate_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

        warnings = []
        errors = []

        # Parse JSON output (line-delimited JSON)
        for line in result.stdout.splitlines():
            if not line.strip():
                continue
            try:
                msg = json.loads(line)
                if msg.get("reason") == "compiler-message":
                    message_data = msg.get("message", {})
                    level = message_data.get("level", "")
                    if level == "warning":
                        warnings.append(msg)
                    elif level == "error":
                        errors.append(msg)
            except json.JSONDecodeError:
                continue

        return ClippyResult(
            warning_count=len(warnings),
            error_count=len(errors),
            warnings=warnings,
            errors=errors,
            success=result.returncode == 0 or len(errors) == 0,
        )

    except subprocess.TimeoutExpired:
        logger.warning(f"Clippy timed out for {crate_dir}")
        return ClippyResult(success=False)
    except Exception as e:
        logger.error(f"Failed to run clippy on {crate_dir}: {e}")
        return ClippyResult(success=False)


def run_geiger(
    crate_dir: Path, timeout: int = 600, env: Optional[Dict[str, str]] = None
) -> Optional[GeigerResult]:
    """
    Run cargo geiger on a crate and parse the results.

    Args:
        crate_dir: Path to crate directory
        timeout: Command timeout in seconds

    Returns:
        GeigerResult with unsafe code metrics, or None if failed
    """
    if not check_cargo_available():
        logger.warning("cargo is not available")
        return None

    cmd = build_cargo_subcommand_command("geiger", "--format=json")

    try:
        # Merge with system environment
        process_env = None
        if env:
            import os

            process_env = os.environ.copy()
            process_env.update(env)

        result = subprocess.run(
            cmd,
            cwd=crate_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=process_env,
        )

        if result.returncode != 0 or not result.stdout:
            return None

        try:
            data = json.loads(result.stdout)
        except json.JSONDecodeError:
            logger.warning(f"Failed to parse geiger JSON for {crate_dir}")
            return None

        packages = data.get("packages", [])

        total_unsafe_functions = 0
        total_unsafe_expressions = 0
        total_unsafe_impls = 0
        total_unsafe_methods = 0
        packages_with_unsafe = 0

        for package in packages:
            unsafety = package.get("unsafety", {})
            used = unsafety.get("used", {})

            unsafe_functions = used.get("functions", {}).get("unsafe_", 0)
            unsafe_expressions = used.get("exprs", {}).get("unsafe_", 0)
            unsafe_impls = used.get("item_impls", {}).get("unsafe_", 0)
            unsafe_methods = used.get("methods", {}).get("unsafe_", 0)

            total_unsafe_functions += unsafe_functions
            total_unsafe_expressions += unsafe_expressions
            total_unsafe_impls += unsafe_impls
            total_unsafe_methods += unsafe_methods

            if any(
                [unsafe_functions, unsafe_expressions, unsafe_impls, unsafe_methods]
            ):
                packages_with_unsafe += 1

        total_unsafe_items = (
            total_unsafe_functions
            + total_unsafe_expressions
            + total_unsafe_impls
            + total_unsafe_methods
        )

        return GeigerResult(
            total_unsafe_items=total_unsafe_items,
            unsafe_functions=total_unsafe_functions,
            unsafe_expressions=total_unsafe_expressions,
            unsafe_impls=total_unsafe_impls,
            unsafe_methods=total_unsafe_methods,
            packages_with_unsafe=packages_with_unsafe,
            success=True,
        )

    except subprocess.TimeoutExpired:
        logger.warning(f"Geiger timed out for {crate_dir}")
        return None
    except Exception as e:
        logger.warning(f"Failed to run geiger on {crate_dir}: {e}")
        return None


def run_outdated(
    crate_dir: Path, timeout: int = 600, env: Optional[Dict[str, str]] = None
) -> Optional[OutdatedResult]:
    """
    Run cargo outdated on a crate and parse the results.

    Args:
        crate_dir: Path to crate directory
        timeout: Command timeout in seconds

    Returns:
        OutdatedResult with dependency age metrics, or None if failed
    """
    if not check_cargo_available():
        logger.warning("cargo is not available")
        return None

    cmd = build_cargo_subcommand_command("outdated", "--format=json")

    try:
        # Merge with system environment
        process_env = None
        if env:
            import os

            process_env = os.environ.copy()
            process_env.update(env)

        result = subprocess.run(
            cmd,
            cwd=crate_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=process_env,
        )

        if result.returncode != 0:
            return None

        outdated_count = 0
        total_dependencies = 0

        try:
            data = json.loads(result.stdout)
            if isinstance(data, dict) and "dependencies" in data:
                dependencies = data["dependencies"]
                total_dependencies = len(dependencies)
                outdated_deps = [
                    dep
                    for dep in dependencies
                    if dep.get("latest") != dep.get("project")
                ]
                outdated_count = len(outdated_deps)
        except json.JSONDecodeError:
            # Try parsing text output
            lines = result.stdout.split("\n")
            outdated_lines = [
                line for line in lines if "outdated" in line.lower() or "->" in line
            ]
            outdated_count = len(outdated_lines)

        outdated_ratio = (
            outdated_count / total_dependencies if total_dependencies > 0 else 0.0
        )

        return OutdatedResult(
            outdated_count=outdated_count,
            total_dependencies=total_dependencies,
            outdated_ratio=outdated_ratio,
            success=True,
        )

    except subprocess.TimeoutExpired:
        logger.warning(f"Outdated timed out for {crate_dir}")
        return None
    except Exception as e:
        logger.warning(f"Failed to run outdated on {crate_dir}: {e}")
        return None


def run_doc_check(crate_dir: Path) -> DocStats:
    """
    Check documentation coverage in a crate.

    Args:
        crate_dir: Path to crate directory

    Returns:
        DocStats with documentation metrics
    """
    src_dir = crate_dir / "src"
    if not src_dir.exists():
        return DocStats()

    total_files = 0
    files_with_docs = 0
    total_doc_comments = 0

    # Count .rs files and doc comments
    for rs_file in src_dir.rglob("*.rs"):
        total_files += 1
        try:
            content = rs_file.read_text(encoding="utf-8", errors="ignore")
            # Count doc comments (/// and //!)
            doc_count = content.count("///") + content.count("//!")
            if doc_count > 0:
                files_with_docs += 1
                total_doc_comments += doc_count
        except Exception as e:
            logger.debug(f"Failed to read {rs_file}: {e}")
            continue

    doc_coverage = files_with_docs / total_files if total_files > 0 else 0.0

    return DocStats(
        total_files=total_files,
        files_with_docs=files_with_docs,
        total_doc_comments=total_doc_comments,
        doc_coverage=doc_coverage,
        has_docs=files_with_docs > 0,
    )


def run_license_check(
    crate_dir: Path,
    allowed_licenses: Optional[List[str]] = None,
    timeout: int = 300,
    env: Optional[Dict[str, str]] = None,
) -> Optional[LicenseResult]:
    """
    Check licenses for a crate using cargo-license.

    Args:
        crate_dir: Path to crate directory
        allowed_licenses: List of allowed license names (optional)
        timeout: Command timeout in seconds

    Returns:
        LicenseResult with license information, or None if failed
    """
    if not check_cargo_available():
        logger.warning("cargo is not available")
        return None

    # Try cargo-license first (more reliable)
    cmd = build_cargo_subcommand_command("license", "--json")

    try:
        # Merge with system environment
        process_env = None
        if env:
            import os

            process_env = os.environ.copy()
            process_env.update(env)

        result = subprocess.run(
            cmd,
            cwd=crate_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=process_env,
        )

        if result.returncode == 0 and result.stdout:
            try:
                data = json.loads(result.stdout)
                licenses = []
                crate_license = None

                # Parse cargo-license JSON output
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict):
                            license_name = item.get("license")
                            if license_name:
                                licenses.append(license_name)
                                # First item is usually the crate itself
                                if crate_license is None:
                                    crate_license = license_name
                elif isinstance(data, dict):
                    # Alternative format
                    crate_license = data.get("license") or data.get("crate_license")
                    deps = data.get("dependencies", [])
                    for dep in deps:
                        dep_license = dep.get("license")
                        if dep_license:
                            licenses.append(dep_license)

                # Check if any license is allowed using centralized function
                has_allowed = True
                if allowed_licenses and licenses:
                    from .utils import check_license_compliance

                    # Check each found license against allowlist
                    has_allowed = any(
                        check_license_compliance(lic, allowed_licenses)
                        for lic in licenses
                    )

                return LicenseResult(
                    crate_license=crate_license,
                    all_licenses=list(set(licenses)),  # Deduplicate
                    has_allowed_license=has_allowed,
                    success=True,
                )
            except json.JSONDecodeError:
                # Fall through to text parsing
                pass

        # Fallback: Try to parse Cargo.toml directly
        cargo_toml = crate_dir / "Cargo.toml"
        if cargo_toml.exists():
            try:
                content = cargo_toml.read_text(encoding="utf-8")
                # Simple regex to find license field
                license_match = re.search(
                    r'license\s*=\s*["\']([^"\']+)["\']', content, re.IGNORECASE
                )
                if license_match:
                    crate_license = license_match.group(1)
                    licenses = [crate_license]

                    # Check if license is allowed using centralized function
                    has_allowed = True
                    if allowed_licenses:
                        from .utils import check_license_compliance

                        has_allowed = check_license_compliance(
                            crate_license, allowed_licenses
                        )

                    return LicenseResult(
                        crate_license=crate_license,
                        all_licenses=licenses,
                        has_allowed_license=has_allowed,
                        success=True,
                    )
            except Exception as e:
                logger.debug(f"Failed to parse Cargo.toml for license: {e}")

        # If cargo-license failed, return None (license check unavailable)
        return None

    except subprocess.TimeoutExpired:
        logger.warning(f"License check timed out for {crate_dir}")
        return None
    except Exception as e:
        logger.warning(f"Failed to run license check on {crate_dir}: {e}")
        return None


def run_deny_check(
    crate_dir: Path, timeout: int = 600, env: Optional[Dict[str, str]] = None
) -> Optional[DenyResult]:
    """
    Run cargo deny on a crate to check for security advisories and license violations.

    Args:
        crate_dir: Path to crate directory
        timeout: Command timeout in seconds
        env: Optional environment variables dict to pass to subprocess

    Returns:
        DenyResult with security and license audit results, or None if failed
    """
    if not check_cargo_available():
        logger.warning("cargo is not available")
        return None

    cmd = build_cargo_subcommand_command("deny", "check", "--format", "json")

    try:
        # Merge with system environment
        process_env = None
        if env:
            import os

            process_env = os.environ.copy()
            process_env.update(env)

        result = subprocess.run(
            cmd,
            cwd=crate_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=process_env,
        )

        if result.returncode != 0 and not result.stdout:
            # cargo-deny may return non-zero on violations, but still output JSON
            return None

        advisories_found = 0
        license_violations = 0
        banned_dependencies = 0
        highest_severity = None
        passed = True

        try:
            data = json.loads(result.stdout)
            # Parse cargo-deny JSON output structure
            # Structure varies by version, but typically has 'advisories', 'licenses', 'bans'
            if isinstance(data, dict):
                # Advisories
                advisories = data.get("advisories", {})
                if isinstance(advisories, dict):
                    advisories_found = len(advisories.get("found", []))
                    # Extract highest severity
                    for adv in advisories.get("found", []):
                        severity = adv.get("severity", "").lower()
                        if severity and (
                            highest_severity is None
                            or _severity_rank(severity)
                            > _severity_rank(highest_severity)
                        ):
                            highest_severity = severity

                # License violations
                licenses = data.get("licenses", {})
                if isinstance(licenses, dict):
                    license_violations = len(licenses.get("violations", []))

                # Banned dependencies
                bans = data.get("bans", {})
                if isinstance(bans, dict):
                    banned_dependencies = len(bans.get("violations", []))

                # Determine if passed (no violations)
                passed = (
                    advisories_found == 0
                    and license_violations == 0
                    and banned_dependencies == 0
                )
        except json.JSONDecodeError:
            # If JSON parsing fails, check return code
            # cargo-deny returns 0 on success, non-zero on violations
            passed = result.returncode == 0

        return DenyResult(
            advisories_found=advisories_found,
            license_violations=license_violations,
            banned_dependencies=banned_dependencies,
            highest_severity=highest_severity,
            passed=passed,
            success=True,
        )

    except subprocess.TimeoutExpired:
        logger.warning(f"Deny check timed out for {crate_dir}")
        return None
    except Exception as e:
        logger.warning(f"Failed to run deny check on {crate_dir}: {e}")
        return None


def _severity_rank(severity: str) -> int:
    """Rank severity levels for comparison (higher = more severe)."""
    ranks = {"critical": 4, "high": 3, "medium": 2, "low": 1, "unknown": 0}
    return ranks.get(severity.lower(), 0)


def analyze_crate(
    crate_dir: Path, config: Optional[Any] = None, env: Optional[Dict[str, str]] = None
) -> CrateAnalysisReport:
    """
    Run all static analysis tools on a crate.

    Args:
        crate_dir: Path to crate directory
        config: Optional pipeline config (for license checking)

    Returns:
        CrateAnalysisReport with all analysis results
    """
    crate_name = crate_dir.name.split("-")[0]  # Extract name from dir

    logger.info(f"Analyzing {crate_name}...")

    # Run all analysis tools
    clippy_result = run_clippy(crate_dir, env=env)
    geiger_result = run_geiger(crate_dir, env=env)
    outdated_result = run_outdated(crate_dir, env=env)
    doc_stats = run_doc_check(crate_dir)

    # Run license check if enabled
    license_result = None
    if config and getattr(config, "enable_license_scan", False):
        allowed_licenses = getattr(config, "allowed_licenses", None)
        license_result = run_license_check(crate_dir, allowed_licenses, env=env)

    # Run cargo-deny check if enabled
    deny_result = None
    if config and getattr(config, "enable_deny_scan", False):
        deny_result = run_deny_check(crate_dir, env=env)

    # Get edition from Cargo.toml
    from .utils import get_crate_edition

    edition = get_crate_edition(crate_dir)

    return CrateAnalysisReport(
        crate_name=crate_name,
        crate_dir=crate_dir,
        clippy=clippy_result,
        geiger=geiger_result,
        outdated=outdated_result,
        docs=doc_stats,
        license=license_result,
        deny=deny_result,
        edition=edition,
    )
