"""
Main pipeline orchestration module.

Coordinates the entire pipeline: crawl → analyze → filter → build → export.

Copyright (c) 2025 Dave Tofflemire, SigilDERG Project
"""

import asyncio
import logging
from pathlib import Path
from collections import Counter
from typing import Iterator, List, Optional

from . import config, crawler, analyzer, filter, dataset_builder, exporter, utils

logger = logging.getLogger(__name__)


def load_crate_list(crate_list_path: Optional[str] = None) -> List[str]:
    """
    Load crate list from file or use default.

    Args:
        crate_list_path: Path to crate list file (optional)

    Returns:
        List of crate names
    """
    if crate_list_path:
        path = Path(crate_list_path)
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                crates = [line.strip() for line in f if line.strip()]
            logger.info(f"Loaded {len(crates)} crates from {crate_list_path}")
            return crates
        else:
            logger.warning(f"Crate list file not found: {crate_list_path}")

    # Try default location
    default_path = Path("data/crate_list.txt")
    if default_path.exists():
        with open(default_path, "r", encoding="utf-8") as f:
            crates = [line.strip() for line in f if line.strip()]
        logger.info(f"Loaded {len(crates)} crates from default location")
        return crates

    logger.warning("No crate list found, returning empty list")
    return []


async def process_crate(
    crate_name: str,
    config: config.PipelineConfig,
    temp_dir: Path,
    cargo_env: Optional[dict] = None,
) -> tuple[Optional[List[dict]], Optional[str]]:
    """
    Process a single crate: fetch, analyze, filter, and collect code files.

    Args:
        crate_name: Name of the crate to process
        config: Pipeline configuration
        temp_dir: Temporary directory for crate extraction
        cargo_env: Environment variables for cargo commands (CARGO_TARGET_DIR, etc.)

    Returns:
        Tuple of (file_list: Optional[List[dict]], rejection_reason: Optional[str])
        If accepted, returns (file_list, None). If rejected, returns (None, reason).
    """
    try:
        # Fetch crate
        logger.info(f"Fetching {crate_name}...")
        crate_dir = crawler.fetch_crate(
            crate_name,
            config=config,
            temp_dir=temp_dir,
        )

        if not crate_dir:
            logger.warning(f"Failed to fetch {crate_name}")
            return None, "fetch_failed"

        # Analyze crate
        logger.info(f"Analyzing {crate_name}...")
        report = analyzer.analyze_crate(crate_dir, config, env=cargo_env)

        # Check if crate meets criteria (returns tuple: (accepted, reason))
        is_acceptable, rejection_reason = filter.is_crate_acceptable(report, config)
        if not is_acceptable:
            logger.info(
                f"Skipping {crate_name}: does not meet quality criteria ({rejection_reason})"
            )
            return None, rejection_reason

        # Collect code files
        code_files = []
        src_dir = crate_dir / "src"
        if src_dir.exists():
            for rs_file in src_dir.rglob("*.rs"):
                try:
                    content = rs_file.read_text(encoding="utf-8", errors="ignore")
                    code_files.append(
                        {
                            "path": str(rs_file.relative_to(crate_dir)),
                            "code": content,
                            "crate_name": crate_name,
                        }
                    )
                except Exception as e:
                    logger.debug(f"Failed to read {rs_file}: {e}")

        # Filter code files (now returns generator)
        filtered_files = list(filter.filter_code_files(code_files, config))

        logger.info(
            f"{crate_name}: {len(filtered_files)}/{len(code_files)} files passed filters"
        )

        return filtered_files, None

    except Exception as e:
        logger.error(f"Error processing {crate_name}: {e}", exc_info=True)
        return None, "processing_error"


async def run_pipeline(cfg: config.PipelineConfig) -> None:
    """
    Run the complete pipeline.

    Args:
        cfg: Pipeline configuration
    """
    # Set up logging
    utils.setup_logging(cfg.log_level)

    logger.info("Starting Sigil Pipeline")
    logger.info(f"Configuration: {cfg.to_dict()}")

    # Load crate list
    if cfg.crates:
        crates = cfg.crates
    else:
        crates = load_crate_list(cfg.crate_list_path)

    if not crates:
        logger.error("No crates to process")
        return

    # Apply limit
    if cfg.limit:
        crates = crates[: cfg.limit]
        logger.info(f"Limited to {len(crates)} crates")

    # Create output directory
    output_dir = Path(cfg.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Initialize metrics tracking (Priority 5.1)
    processed_count = 0
    skipped_count = 0
    reason_counts = Counter()

    # Use temporary directory for crate extraction
    with utils.TempDir(prefix="sigil_crates_") as temp_dir:
        # Setup shared cargo target directory if enabled (Priority 3.1)
        cargo_env = {}
        if cfg.reuse_cargo_target:
            if cfg.cargo_target_dir:
                target_dir = Path(cfg.cargo_target_dir)
            else:
                # Create shared target in temp dir
                target_dir = temp_dir / "target_cache"
            target_dir.mkdir(parents=True, exist_ok=True)
            cargo_env["CARGO_TARGET_DIR"] = str(target_dir.resolve())
            logger.info(f"Using shared cargo target directory: {target_dir}")
        # Process crates with concurrency control
        semaphore = asyncio.Semaphore(cfg.max_threads)

        async def process_with_semaphore(crate_name: str):
            async with semaphore:
                return await process_crate(crate_name, cfg, temp_dir, cargo_env)

        # Create tasks with crate name mapping
        task_to_crate = {}
        tasks = []
        for crate in crates:
            task = asyncio.create_task(process_with_semaphore(crate))
            task_to_crate[task] = crate
            tasks.append(task)

        # Process crates and collect results with reason tracking (Priority 2.1 - Streaming Architecture)
        # Use asyncio.as_completed to process as crates complete
        crate_file_generator_parts = []
        # as_completed yields futures/tasks as they complete, we need to track which is which
        pending = {task: crate for task, crate in zip(tasks, crates)}
        for completed_task in asyncio.as_completed(tasks):
            try:
                result = await completed_task
                # Find crate name from pending dict
                crate_name = pending.pop(completed_task, "unknown")
                if isinstance(result, Exception):
                    logger.error(f"Task failed with exception: {result}")
                    skipped_count += 1
                    reason_counts["processing_error"] += 1
                elif result[0] is None:
                    # Crate was filtered out
                    skipped_count += 1
                    reason = result[1] or "unknown"
                    # Normalize reason for metrics (Priority 5.1)
                    if "edition" in reason:
                        reason_counts["edition"] += 1
                    elif "clippy" in reason:
                        reason_counts["clippy"] += 1
                    elif (
                        "documentation" in reason
                        or "docs" in reason
                        or "no documentation" in reason
                    ):
                        reason_counts["docs"] += 1
                    elif "license" in reason:
                        reason_counts["license"] += 1
                    elif "unsafe" in reason:
                        reason_counts["unsafe"] += 1
                    elif "outdated" in reason:
                        reason_counts["outdated"] += 1
                    elif "deny" in reason or "advisory" in reason:
                        reason_counts["deny"] += 1
                    elif "platform" in reason:
                        reason_counts["platform"] += 1
                    elif "fetch_failed" in reason:
                        reason_counts["fetch_failed"] += 1
                    else:
                        reason_counts["other"] += 1
                else:
                    # Crate accepted
                    file_list, _ = result
                    processed_count += 1
                    crate_file_generator_parts.append(file_list)
            except Exception as e:
                logger.error(f"Error processing {crate_name}: {e}", exc_info=True)
                skipped_count += 1
                reason_counts["processing_error"] += 1

    logger.info(
        f"Processed {processed_count} crates, skipped {skipped_count}, "
        f"collected {sum(len(files) for files in crate_file_generator_parts)} code files"
    )

    # Create unified generator for all files (Priority 2.1 - Streaming Architecture)
    def iter_all_code_files() -> Iterator[dict]:
        """Unified generator for all code files (crates + Stack)."""
        # Yield from processed crates
        for file_list in crate_file_generator_parts:
            for file_dict in file_list:
                yield file_dict

        # Yield from Stack dataset if enabled (streaming, not materialized)
        if cfg.include_stack_dataset:
            logger.info("Processing Stack dataset files...")
            stack_count = 0
            stack_filtered = 0
            for file_dict in crawler.iter_stack_files(
                cfg.stack_dataset_path,
                use_streaming=cfg.stack_dataset_use_streaming,
                hf_dataset_name=cfg.stack_dataset_hf_name,
            ):
                stack_count += 1
                # Filter using generator-based filter
                filtered_iter = filter.filter_code_files([file_dict], cfg)
                filtered_list = list(filtered_iter)
                if filtered_list:
                    yield filtered_list[0]
                else:
                    stack_filtered += 1
            logger.info(
                f"Stack dataset: {stack_count - stack_filtered}/{stack_count} files passed filters"
            )

    # Build dataset entries with format validation (streaming)
    logger.info("Building dataset entries...")
    phase1_spec_path = getattr(cfg, "phase1_spec_path", None)
    if phase1_spec_path:
        phase1_spec_path = Path(phase1_spec_path)
    else:
        # Try default location
        default_spec = Path("docs/phase1_format_spec.json")
        phase1_spec_path = default_spec if default_spec.exists() else None

    # Chain generators: files -> filtered -> dataset entries -> JSONL (Priority 2.1)
    filtered_files = filter.filter_code_files(iter_all_code_files(), cfg)
    samples = dataset_builder.build_dataset_entries(
        filtered_files,
        validate_format=cfg.validate_format,
        phase1_spec_path=phase1_spec_path,
    )

    # Export JSONL directly from generator (streaming write)
    logger.info(f"Writing dataset to {cfg.output_path}...")
    sample_count = exporter.write_jsonl(samples, cfg.output_path)

    # Initialize metrics
    metrics = {}

    # Optionally merge with Phase 1 data if specified
    if cfg.merge_with_phase1 and cfg.phase1_dataset_path:
        logger.info(f"Merging with Phase 1 dataset: {cfg.phase1_dataset_path}")
        merged_path = str(Path(cfg.output_path).parent / "merged_phase1_phase2.jsonl")
        merged_count = exporter.merge_phase1_phase2(
            phase1_path=cfg.phase1_dataset_path,
            phase2_path=cfg.output_path,
            output_path=merged_path,
            shuffle=cfg.shuffle_merged,
            phase2_weight=cfg.phase2_weight,
        )
        logger.info(f"Merged {merged_count} total samples to {merged_path}")
        metrics["merged_with_phase1"] = {
            "enabled": True,
            "phase1_path": cfg.phase1_dataset_path,
            "phase2_samples": sample_count,
            "total_samples": merged_count,
            "merged_path": merged_path,
            "shuffled": cfg.shuffle_merged,
            "phase2_weight": cfg.phase2_weight,
        }
    else:
        metrics["merged_with_phase1"] = {"enabled": False}

    # Write metrics with granular filter breakdown (Priority 5.1)
    metrics.update(
        {
            "total_samples": sample_count,
            "crates_processed": processed_count,
            "crates_skipped": skipped_count,
            "total_crates": len(crates),
            "filter_breakdown": dict(reason_counts),  # Granular filter reasons
            "stack_dataset": {
                "enabled": cfg.include_stack_dataset,
            },
            "config": cfg.to_dict(),
        }
    )

    metrics_path = output_dir / "metrics.json"
    exporter.write_metrics(metrics, str(metrics_path))

    logger.info("Pipeline completed successfully")
    logger.info(f"Output: {cfg.output_path}")
    logger.info(f"Metrics: {metrics_path}")


def main():
    """Main entry point for the pipeline."""
    import argparse

    parser = argparse.ArgumentParser(description="Sigil Pipeline - Rust crate analysis")
    parser.add_argument("--crates", nargs="+", help="Crate names to process")
    parser.add_argument("--crate-list", help="Path to crate list file")
    parser.add_argument(
        "--output",
        default="output/sigil_phase2_dataset.jsonl",
        help="Output JSONL path",
    )
    parser.add_argument(
        "--max-threads", type=int, default=4, help="Max parallel threads"
    )
    parser.add_argument("--limit", type=int, help="Limit number of crates")
    parser.add_argument("--log-level", default="INFO", help="Logging level")
    parser.add_argument("--config", help="Path to config JSON/YAML file")
    parser.add_argument(
        "--stack-dataset-path",
        help="Path to local Stack dataset directory (default: datasets/the-stack-rust-clean)",
    )
    parser.add_argument(
        "--stack-dataset-streaming",
        action="store_true",
        help="Enable streaming from HuggingFace if local dataset not found",
    )
    parser.add_argument(
        "--stack-dataset-hf-name",
        help="HuggingFace dataset name for streaming (default: ammarnasr/the-stack-rust-clean)",
    )
    parser.add_argument(
        "--merge-with-phase1",
        action="store_true",
        help="Merge Phase 2 output with Phase 1 dataset",
    )
    parser.add_argument(
        "--phase1-dataset-path",
        help="Path to Phase 1 dataset JSONL file or HuggingFace dataset name",
    )
    parser.add_argument(
        "--phase1-spec-path",
        help="Path to Phase 1 format specification JSON file (for validation)",
    )
    parser.add_argument(
        "--include-stack-dataset",
        action="store_true",
        default=True,
        help="Include Stack dataset files (default: True)",
    )
    parser.add_argument(
        "--no-include-stack-dataset",
        dest="include_stack_dataset",
        action="store_false",
        help="Exclude Stack dataset files",
    )

    args = parser.parse_args()

    # Load config
    if args.config:
        cfg_path = Path(args.config)
        if cfg_path.suffix == ".yaml" or cfg_path.suffix == ".yml":
            cfg = config.PipelineConfig.from_yaml(cfg_path)
        else:
            cfg = config.PipelineConfig.from_json(cfg_path)
    else:
        cfg = config.PipelineConfig()

    # Override with command-line args
    if args.crates:
        cfg.crates = args.crates
    if args.crate_list:
        cfg.crate_list_path = args.crate_list
    if args.output:
        cfg.output_path = args.output
    if args.max_threads:
        cfg.max_threads = args.max_threads
    if args.limit:
        cfg.limit = args.limit
    if args.log_level:
        cfg.log_level = args.log_level
    if args.stack_dataset_path:
        cfg.stack_dataset_path = args.stack_dataset_path
    if args.stack_dataset_streaming:
        cfg.stack_dataset_use_streaming = True
    if args.stack_dataset_hf_name:
        cfg.stack_dataset_hf_name = args.stack_dataset_hf_name
    if args.merge_with_phase1:
        cfg.merge_with_phase1 = True
    if args.phase1_dataset_path:
        cfg.phase1_dataset_path = args.phase1_dataset_path
    if args.phase1_spec_path:
        cfg.phase1_spec_path = args.phase1_spec_path
    if hasattr(args, "include_stack_dataset"):
        cfg.include_stack_dataset = args.include_stack_dataset

    # Run pipeline
    asyncio.run(run_pipeline(cfg))


if __name__ == "__main__":
    main()
