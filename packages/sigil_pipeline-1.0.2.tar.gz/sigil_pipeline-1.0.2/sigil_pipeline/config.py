"""
Configuration module for the Sigil Pipeline.

Defines PipelineConfig dataclass with all configurable settings.

Copyright (c) 2025 Dave Tofflemire, SigilDERG Project
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional


@dataclass
class PipelineConfig:
    """
    Configuration for the Sigil Pipeline.

    All settings are configurable via constructor arguments, JSON/YAML files,
    or environment variables.
    """

    # Crates to analyze
    crates: List[str] = field(default_factory=list)
    """List of crate names to analyze. If empty, loads from crate_list_path or default."""

    crate_list_path: Optional[str] = None
    """Path to file containing crate names (one per line). If None, uses default."""

    # Dataset integration
    include_stack_dataset: bool = True
    """Whether to include files from the Stack Rust dataset."""

    stack_dataset_path: str = "datasets/the-stack-rust-clean"
    """Path to the Stack Rust dataset (local directory, defaults to datasets/)."""

    stack_dataset_use_streaming: bool = False
    """Whether to stream from HuggingFace if local dataset not found. Default: False (local only)."""

    stack_dataset_hf_name: Optional[str] = "ammarnasr/the-stack-rust-clean"
    """HuggingFace dataset name to use if streaming is enabled and local path not found."""

    phase1_dataset_path: Optional[str] = None
    """Path to Phase 1 dataset JSONL file or HuggingFace dataset name to merge with Phase 2 output."""

    phase1_spec_path: Optional[str] = None
    """Path to Phase 1 format specification JSON file (for validation)."""

    validate_format: bool = True
    """Validate Phase 2 samples against Phase 1 format specification."""

    merge_with_phase1: bool = False
    """Whether to merge Phase 2 output with Phase 1 dataset."""

    shuffle_merged: bool = True
    """Shuffle merged dataset (recommended for training)."""

    phase2_weight: float = 1.0
    """Weight for Phase 2 samples in weighted sampling (1.0 = equal weight with Phase 1)."""

    # Performance settings
    max_threads: int = 4
    """Maximum number of parallel threads for crate processing (default: 4, max recommended: 8)."""

    # Output settings
    output_path: str = "output/sigil_phase2_dataset.jsonl"
    """Path to output JSONL file."""

    output_dir: str = "output"
    """Directory for output files."""

    # Quality thresholds
    allow_edition_2018: bool = False
    """Allow Rust 2018 edition crates. Default: False (only 2021+)."""

    max_clippy_warnings: int = 0
    """Maximum allowed Clippy warnings. Default: 0 (strict idiomatic code)."""

    require_docs: bool = True
    """Require documentation comments. Default: True."""

    min_doc_coverage: float = 0.0
    """Minimum documentation coverage ratio (0.0-1.0). Default: 0.0 (any docs)."""

    # License filtering
    allowed_licenses: List[str] = field(
        default_factory=lambda: ["MIT", "Apache-2.0", "BSD", "ISC", "MIT/Apache-2.0"]
    )
    """List of allowed licenses. Crates with other licenses will be filtered out."""

    enable_license_scan: bool = True
    """Enable license checking via cargo-license. Default: True."""

    # Quality filtering enhancements
    max_unsafe_items: Optional[int] = None
    """Maximum allowed unsafe code items (from Geiger). None = no filter, 0 = no unsafe allowed."""

    max_outdated_ratio: Optional[float] = None
    """Maximum allowed ratio of outdated dependencies (0.0-1.0). None = no filter."""

    # Cargo-deny configuration
    enable_deny_scan: bool = False
    """Enable cargo-deny security and license auditing. Default: False (optional, can be slow)."""

    max_deny_severity: Optional[str] = None
    """Maximum allowed deny severity level. None = no filter based on severity."""

    fail_on_deny_violations: bool = True
    """Fail crate if cargo-deny reports any violations. Default: True."""

    # File filtering
    max_line_length: int = 100
    """Maximum average line length. Files exceeding this are filtered out (matches Stack dataset criteria)."""

    min_alphabetic_ratio: float = 0.3
    """Minimum ratio of alphabetic characters. Default: 0.3 (filters minified code, matches Stack dataset criteria)."""

    max_line_length_hard_cap: int = 500
    """Hard cap for maximum line length in any code file. Default: 500 (matches Stack dataset criteria)."""

    # Tool configuration
    reuse_cargo_target: bool = True
    """Reuse a shared cargo target directory for faster builds. Default: True."""

    cargo_target_dir: Optional[str] = None
    """Path to shared cargo target directory. If None, uses default location."""

    # Processing limits
    limit: Optional[int] = None
    """Limit number of crates to process. If None, processes all."""

    # Logging
    log_level: str = "INFO"
    """Logging level: DEBUG, INFO, WARNING, ERROR."""

    verbose: bool = False
    """Enable verbose logging output."""

    @classmethod
    def from_dict(cls, data: dict) -> "PipelineConfig":
        """Create config from dictionary."""
        return cls(**data)

    @classmethod
    def from_json(cls, path: str | Path) -> "PipelineConfig":
        """Load config from JSON file."""
        import json

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)

    @classmethod
    def from_yaml(cls, path: str | Path) -> "PipelineConfig":
        """Load config from YAML file."""
        try:
            import yaml

            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
            return cls.from_dict(data)
        except ImportError:
            raise ImportError("PyYAML is required for YAML config files")

    def to_dict(self) -> dict:
        """Convert config to dictionary."""
        return {
            "crates": self.crates,
            "crate_list_path": self.crate_list_path,
            "include_stack_dataset": self.include_stack_dataset,
            "stack_dataset_path": self.stack_dataset_path,
            "stack_dataset_use_streaming": self.stack_dataset_use_streaming,
            "stack_dataset_hf_name": self.stack_dataset_hf_name,
            "max_threads": self.max_threads,
            "output_path": self.output_path,
            "output_dir": self.output_dir,
            "allow_edition_2018": self.allow_edition_2018,
            "max_clippy_warnings": self.max_clippy_warnings,
            "require_docs": self.require_docs,
            "min_doc_coverage": self.min_doc_coverage,
            "allowed_licenses": self.allowed_licenses,
            "enable_license_scan": self.enable_license_scan,
            "max_unsafe_items": self.max_unsafe_items,
            "max_outdated_ratio": self.max_outdated_ratio,
            "enable_deny_scan": self.enable_deny_scan,
            "max_deny_severity": self.max_deny_severity,
            "fail_on_deny_violations": self.fail_on_deny_violations,
            "max_line_length": self.max_line_length,
            "min_alphabetic_ratio": self.min_alphabetic_ratio,
            "reuse_cargo_target": self.reuse_cargo_target,
            "cargo_target_dir": self.cargo_target_dir,
            "limit": self.limit,
            "log_level": self.log_level,
            "verbose": self.verbose,
            "phase1_dataset_path": self.phase1_dataset_path,
            "phase1_spec_path": self.phase1_spec_path,
            "validate_format": self.validate_format,
            "merge_with_phase1": self.merge_with_phase1,
            "shuffle_merged": self.shuffle_merged,
            "phase2_weight": self.phase2_weight,
        }
