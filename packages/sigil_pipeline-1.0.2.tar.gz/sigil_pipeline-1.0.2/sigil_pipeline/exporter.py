"""
Exporter module for writing JSONL datasets and metrics.

Handles streaming JSONL output and merging multiple dataset files.
Supports Phase 1/Phase 2 merging with shuffle and weighting options.

Copyright (c) 2025 Dave Tofflemire, SigilDERG Project
"""

import json
import logging
import random
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

logger = logging.getLogger(__name__)

# Optional HuggingFace datasets library
try:
    from datasets import load_dataset  # type: ignore[import-untyped]

    HF_DATASETS_AVAILABLE = True
except ImportError:
    HF_DATASETS_AVAILABLE = False
    load_dataset = None  # type: ignore[assignment]


def write_jsonl(samples: Iterator[dict], output_path: str) -> int:
    """
    Write dataset samples to a JSONL file in streaming fashion.

    Args:
        samples: Iterator of sample dicts with 'prompt' and 'gen' keys
        output_path: Path to output JSONL file

    Returns:
        Number of samples written
    """
    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    count = 0
    with open(output_file, "w", encoding="utf-8") as f:
        for sample in samples:
            try:
                # Validate sample structure
                if "prompt" not in sample or "gen" not in sample:
                    logger.warning(f"Skipping invalid sample: {sample.keys()}")
                    continue

                # Write as JSON line
                json_line = json.dumps(sample, ensure_ascii=False)
                f.write(json_line + "\n")
                count += 1

                if count % 1000 == 0:
                    logger.info(f"Written {count} samples...")

            except Exception as e:
                logger.error(f"Failed to write sample: {e}")
                continue

    logger.info(f"Wrote {count} samples to {output_path}")
    return count


def load_phase1_dataset(
    dataset_path: str, max_samples: Optional[int] = None
) -> Iterator[Dict[str, Any]]:
    """
    Load Phase 1 dataset from HuggingFace or local file.

    Args:
        dataset_path: HuggingFace dataset name or local file path
        max_samples: Maximum number of samples to load (None for all)

    Yields:
        Sample dictionaries with 'prompt' and 'gen' keys
    """
    # Check if it's a HuggingFace dataset name
    if (
        "/" in dataset_path
        and "\\" not in dataset_path
        and not Path(dataset_path).exists()
    ):
        # Likely a HuggingFace dataset
        if HF_DATASETS_AVAILABLE and load_dataset is not None:
            try:
                logger.info(f"Loading Phase 1 dataset from HuggingFace: {dataset_path}")
                dataset = load_dataset(dataset_path, split="train", streaming=True)

                count = 0
                for item in dataset:
                    # Handle different dataset structures
                    if "prompt" in item and "gen" in item:
                        yield {"prompt": item["prompt"], "gen": item["gen"]}
                    elif "instruction" in item and "output" in item:
                        # Alternative field names
                        yield {"prompt": item["instruction"], "gen": item["output"]}
                    else:
                        logger.warning(
                            f"Unexpected Phase 1 dataset structure: {item.keys()}"
                        )
                        continue

                    count += 1
                    if max_samples and count >= max_samples:
                        break

            except Exception as e:
                logger.error(f"Failed to load HuggingFace dataset: {e}")
                return
        else:
            logger.error("HuggingFace datasets library not available")
            return

    # Treat as local file
    local_path = Path(dataset_path)
    if not local_path.exists():
        logger.error(f"Phase 1 dataset file not found: {dataset_path}")
        return

    logger.info(f"Loading Phase 1 dataset from local file: {dataset_path}")
    count = 0
    with open(local_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            try:
                sample = json.loads(line)
                if "prompt" in sample and "gen" in sample:
                    yield sample
                    count += 1
                    if max_samples and count >= max_samples:
                        break
            except json.JSONDecodeError as e:
                logger.warning(f"Invalid JSON in Phase 1 dataset: {e}")
                continue


def merge_jsonl_files(
    input_files: List[str],
    output_path: str,
    shuffle: bool = True,
    weights: Optional[List[float]] = None,
) -> int:
    """
    Merge multiple JSONL files into a single file.

    Args:
        input_files: List of input JSONL file paths
        output_path: Path to output merged JSONL file
        shuffle: Whether to shuffle the merged dataset (default: True)
        weights: Optional list of weights for each file (for weighted sampling)

    Returns:
        Total number of samples merged
    """
    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    # Collect all samples first (needed for shuffling/weighting)
    all_samples = []
    file_counts = []

    for input_file in input_files:
        input_path = Path(input_file)
        if not input_path.exists():
            logger.warning(f"Input file not found: {input_file}")
            continue

        logger.info(f"Loading {input_file}...")
        file_count = 0

        with open(input_path, "r", encoding="utf-8") as in_f:
            for line in in_f:
                line = line.strip()
                if not line:
                    continue

                try:
                    # Validate JSON
                    sample = json.loads(line)
                    if "prompt" not in sample or "gen" not in sample:
                        logger.warning(f"Invalid sample in {input_file}")
                        continue

                    all_samples.append(sample)
                    file_count += 1

                except json.JSONDecodeError as e:
                    logger.warning(f"Invalid JSON in {input_file}: {e}")
                    continue

        file_counts.append(file_count)
        logger.info(f"  Loaded {file_count} samples from {input_file}")

    # Apply weighting if specified
    if weights and len(weights) == len(input_files):
        weighted_samples = []
        for i, (samples_from_file, weight) in enumerate(zip(all_samples, weights)):
            # Repeat samples based on weight
            repeat_count = max(1, int(weight))
            for _ in range(repeat_count):
                weighted_samples.extend(samples_from_file)
        all_samples = weighted_samples
        logger.info(
            f"Applied weights: {weights}, total samples after weighting: {len(all_samples)}"
        )

    # Shuffle if requested
    if shuffle:
        logger.info("Shuffling merged dataset...")
        random.shuffle(all_samples)

    # Write merged dataset
    total_count = 0
    with open(output_file, "w", encoding="utf-8") as out_f:
        for sample in all_samples:
            json_line = json.dumps(sample, ensure_ascii=False)
            out_f.write(json_line + "\n")
            total_count += 1

    logger.info(f"Merged {total_count} total samples to {output_path}")
    return total_count


def merge_phase1_phase2(
    phase1_path: str,
    phase2_path: str,
    output_path: str,
    shuffle: bool = True,
    phase2_weight: float = 1.0,
) -> int:
    """
    Merge Phase 1 and Phase 2 datasets with optional weighting.

    Args:
        phase1_path: Path to Phase 1 dataset (HuggingFace name or local file)
        phase2_path: Path to Phase 2 dataset JSONL file
        output_path: Path to output merged JSONL file
        shuffle: Whether to shuffle the merged dataset (default: True)
        phase2_weight: Weight for Phase 2 samples (1.0 = equal to Phase 1)

    Returns:
        Total number of samples merged
    """
    logger.info(f"Merging Phase 1 ({phase1_path}) and Phase 2 ({phase2_path})...")

    # Load Phase 1 samples
    phase1_samples = list(load_phase1_dataset(phase1_path))
    logger.info(f"Loaded {len(phase1_samples)} samples from Phase 1")

    # Load Phase 2 samples
    phase2_samples = []
    phase2_file = Path(phase2_path)
    if not phase2_file.exists():
        logger.error(f"Phase 2 file not found: {phase2_path}")
        return 0

    with open(phase2_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    sample = json.loads(line)
                    if "prompt" in sample and "gen" in sample:
                        phase2_samples.append(sample)
                except json.JSONDecodeError:
                    continue

    logger.info(f"Loaded {len(phase2_samples)} samples from Phase 2")

    # Apply weighting
    if phase2_weight != 1.0:
        # Repeat Phase 2 samples based on weight
        phase2_repeat = max(1, int(phase2_weight))
        phase2_samples = phase2_samples * phase2_repeat
        logger.info(
            f"Applied Phase 2 weight {phase2_weight}, total Phase 2 samples: {len(phase2_samples)}"
        )

    # Combine samples
    all_samples = phase1_samples + phase2_samples

    # Shuffle if requested
    if shuffle:
        logger.info("Shuffling merged dataset...")
        random.shuffle(all_samples)

    # Write merged dataset
    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    total_count = 0
    with open(output_file, "w", encoding="utf-8") as out_f:
        for sample in all_samples:
            json_line = json.dumps(sample, ensure_ascii=False)
            out_f.write(json_line + "\n")
            total_count += 1

    logger.info(
        f"Merged dataset: {len(phase1_samples)} Phase 1 + {len(phase2_samples)} Phase 2 = "
        f"{total_count} total samples"
    )
    logger.info(f"Saved to: {output_path}")

    return total_count


def write_metrics(metrics: Dict, output_path: str) -> None:
    """
    Write pipeline metrics to a JSON file.

    Args:
        metrics: Dictionary of metrics
        output_path: Path to output JSON file
    """
    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)

    logger.info(f"Wrote metrics to {output_path}")
