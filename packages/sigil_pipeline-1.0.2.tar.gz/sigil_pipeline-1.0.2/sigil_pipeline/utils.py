"""
Utility functions for the Sigil Pipeline.

Provides subprocess wrappers, file I/O, temporary directory management,
and OS-agnostic cargo command construction.

Copyright (c) 2025 Dave Tofflemire, SigilDERG Project
"""

import json
import logging
import platform
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def run_command(
    cmd: List[str],
    cwd: Optional[Path] = None,
    timeout: Optional[int] = None,
) -> subprocess.CompletedProcess:
    """
    Run a command with proper error handling and cross-platform support.

    Args:
        cmd: Command as list of strings
        cwd: Working directory (optional)
        timeout: Command timeout in seconds (optional)

    Returns:
        CompletedProcess with stdout, stderr, returncode
    """
    try:
        result = subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result
    except subprocess.TimeoutExpired:
        logger.warning(f"Command timed out: {' '.join(cmd)}")
        raise
    except Exception as e:
        logger.error(f"Failed to run command {' '.join(cmd)}: {e}")
        raise


def read_json(path: str | Path) -> Dict[str, Any]:
    """
    Read a JSON file.

    Args:
        path: Path to JSON file

    Returns:
        Parsed JSON data as dictionary
    """
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: str | Path, data: Dict[str, Any]) -> None:
    """
    Write data to a JSON file.

    Args:
        path: Path to output JSON file
        data: Data to write (must be JSON-serializable)
    """
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


class TempDir:
    """
    Context manager for temporary directories.

    Automatically cleans up the directory when exiting the context.
    """

    def __init__(self, prefix: str = "sigil_", cleanup: bool = True):
        """
        Initialize temporary directory.

        Args:
            prefix: Prefix for temporary directory name
            cleanup: Whether to clean up on exit (default: True)
        """
        self.prefix = prefix
        self.cleanup = cleanup
        self.path: Optional[Path] = None

    def __enter__(self) -> Path:
        """Create and return temporary directory path."""
        self.path = Path(tempfile.mkdtemp(prefix=self.prefix))
        return self.path

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Clean up temporary directory."""
        if self.cleanup and self.path and self.path.exists():
            try:
                shutil.rmtree(self.path)
            except Exception as e:
                logger.warning(f"Failed to clean up temp directory {self.path}: {e}")


def get_crate_edition(crate_dir: Path) -> Optional[str]:
    """
    Read the Rust edition from Cargo.toml.

    Args:
        crate_dir: Path to extracted crate directory

    Returns:
        Edition string (e.g., "2021", "2018") or None if not found
    """
    import re

    cargo_toml = crate_dir / "Cargo.toml"
    if not cargo_toml.exists():
        return None

    try:
        content = cargo_toml.read_text(encoding="utf-8")
        # Look for edition = "2021" or edition = "2018"
        match = re.search(r'edition\s*=\s*["\'](\d+)["\']', content)
        if match:
            return match.group(1)
    except Exception as e:
        logger.warning(f"Failed to read Cargo.toml in {crate_dir}: {e}")

    return None


def setup_logging(level: str = "INFO") -> None:
    """
    Set up basic logging configuration.

    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR)
    """
    import logging as log_module

    log_level = getattr(log_module, level.upper(), log_module.INFO)
    log_module.basicConfig(
        level=log_level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


# ============================================================================
# OS-agnostic cargo command utilities
# ============================================================================


def get_cargo_command() -> str:
    """
    Get the appropriate cargo command for the current platform.

    On Windows, returns 'cargo.exe' if it exists, otherwise 'cargo'.
    On Unix-like systems (Linux, macOS), returns 'cargo'.

    This function checks if cargo is available in PATH and returns the
    appropriate executable name based on the platform.

    Returns:
        str: The cargo command to use ('cargo' or 'cargo.exe')

    Examples:
        >>> cmd = get_cargo_command()
        >>> # On Windows: 'cargo.exe' (if available) or 'cargo'
        >>> # On Linux/macOS: 'cargo'
    """
    system = platform.system().lower()

    if system == "windows":
        # On Windows, try cargo.exe first, then fall back to cargo
        # (cargo.exe is more reliable on Windows)
        if shutil.which("cargo.exe"):
            return "cargo.exe"
        elif shutil.which("cargo"):
            return "cargo"
        else:
            # If neither found, default to cargo.exe (Windows convention)
            return "cargo.exe"
    else:
        # On Unix-like systems (Linux, macOS, etc.), use 'cargo'
        return "cargo"


def build_cargo_command(subcommand: str, *args: str) -> List[str]:
    """
    Build a cargo command list with OS-agnostic cargo executable.

    Args:
        subcommand: The cargo subcommand (e.g., 'build', 'test', 'clippy')
        *args: Additional arguments to pass to the cargo command

    Returns:
        List[str]: Command list ready for subprocess execution

    Examples:
        >>> cmd = build_cargo_command('build', '--release')
        >>> # Returns: ['cargo.exe', 'build', '--release'] on Windows
        >>> # Returns: ['cargo', 'build', '--release'] on Linux/macOS

        >>> cmd = build_cargo_command('clippy', '--message-format=json', '--', '-W', 'clippy::all')
        >>> # Returns: ['cargo.exe', 'clippy', '--message-format=json', '--', '-W', 'clippy::all'] on Windows
    """
    cargo_cmd = get_cargo_command()
    return [cargo_cmd, subcommand] + list(args)


def build_cargo_subcommand_command(subcommand: str, *args: str) -> List[str]:
    """
    Build a cargo subcommand command (e.g., cargo-audit, cargo-geiger).

    Cargo subcommands are installed as separate executables (cargo-audit, cargo-geiger, etc.)
    and are invoked via 'cargo <subcommand>' syntax.

    Args:
        subcommand: The cargo subcommand name (e.g., 'audit', 'geiger', 'outdated')
        *args: Additional arguments to pass to the subcommand

    Returns:
        List[str]: Command list ready for subprocess execution

    Examples:
        >>> cmd = build_cargo_subcommand_command('audit', '--json')
        >>> # Returns: ['cargo.exe', 'audit', '--json'] on Windows
        >>> # Returns: ['cargo', 'audit', '--json'] on Linux/macOS
    """
    cargo_cmd = get_cargo_command()
    return [cargo_cmd, subcommand] + list(args)


def check_cargo_available() -> bool:
    """
    Check if cargo is available in the system PATH.

    Returns:
        bool: True if cargo is available, False otherwise
    """
    cargo_cmd = get_cargo_command()
    return shutil.which(cargo_cmd) is not None


def check_license_compliance(license_str: str, allowed_list: List[str]) -> bool:
    """
    Check if a license string (possibly SPDX expression) matches any allowed license.

    Handles SPDX expressions like "MIT OR Apache-2.0" by splitting on OR/AND
    and checking if any component matches the allowlist.

    Args:
        license_str: License string from Cargo.toml or crates.io (may be SPDX expression)
        allowed_list: List of allowed license names (e.g., ["MIT", "Apache-2.0"])

    Returns:
        True if license is allowed, False otherwise
    """
    if not license_str or not allowed_list:
        return False

    # Normalize input: lowercase, strip whitespace
    license_normalized = license_str.strip().lower()

    # Normalize allowed list
    allowed_normalized = {
        lic.lower().strip().replace("-", "").replace("_", "") for lic in allowed_list
    }

    # Handle SPDX expressions: split on " OR " or " AND " or "/"
    # Common patterns: "MIT OR Apache-2.0", "MIT/Apache-2.0", "MIT AND Apache-2.0"
    separators = [" or ", " and ", "/"]
    components = [license_normalized]

    for sep in separators:
        new_components = []
        for comp in components:
            new_components.extend(part.strip() for part in comp.split(sep))
        components = new_components

    # Check if any component matches an allowed license
    for component in components:
        component_clean = component.replace("-", "").replace("_", "")
        if component_clean in allowed_normalized:
            return True

    # Also check exact match (normalized)
    license_clean = license_normalized.replace("-", "").replace("_", "")
    return license_clean in allowed_normalized


def is_platform_specific_crate(crate_dir: Path) -> Optional[str]:
    """
    Detect if a crate is platform-specific by checking Cargo.toml dependencies.

    Checks for known platform-specific dependencies that indicate the crate
    may not compile on the current platform.

    Args:
        crate_dir: Path to crate directory

    Returns:
        Platform name if platform-specific detected (e.g., "windows", "unix"),
        None if not clearly platform-specific or if detection failed
    """
    cargo_toml = crate_dir / "Cargo.toml"
    if not cargo_toml.exists():
        return None

    try:
        content = cargo_toml.read_text(encoding="utf-8")
        current_platform = platform.system().lower()

        # Known Windows-specific dependencies
        windows_deps = [
            "winapi",
            "windows",
            "windows-sys",
            "winreg",
            "winres",
            "winrt",
        ]

        # Known Unix/Linux-specific dependencies
        unix_deps = [
            "libc",
            "nix",
            "sysinfo",
            "alsa",
            "pulseaudio",
            "wayland",
            "x11",
        ]

        # Known macOS-specific dependencies
        macos_deps = [
            "core-foundation",
            "core-graphics",
            "cocoa",
            "objc",
        ]

        # Check for platform-specific dependencies
        content_lower = content.lower()

        if current_platform == "windows":
            # On Windows, check for Unix/macOS-specific deps
            for dep in unix_deps + macos_deps:
                if f'"{dep}"' in content_lower or f"'{dep}'" in content_lower:
                    return "unix"  # Likely Unix/macOS-only
        elif current_platform == "linux":
            # On Linux, check for Windows/macOS-specific deps
            for dep in windows_deps:
                if f'"{dep}"' in content_lower or f"'{dep}'" in content_lower:
                    return "windows"  # Likely Windows-only
            for dep in macos_deps:
                if f'"{dep}"' in content_lower or f"'{dep}'" in content_lower:
                    return "macos"  # Likely macOS-only
        elif current_platform == "darwin":  # macOS
            # On macOS, check for Windows-specific deps
            for dep in windows_deps:
                if f'"{dep}"' in content_lower or f"'{dep}'" in content_lower:
                    return "windows"  # Likely Windows-only

        # Check for platform-specific features
        if "[target." in content:
            # Has platform-specific targets, but we can't determine compatibility
            # without more analysis - let compilation handle it
            return None

        return None

    except Exception as e:
        logger.debug(f"Failed to check platform-specific dependencies: {e}")
        return None
