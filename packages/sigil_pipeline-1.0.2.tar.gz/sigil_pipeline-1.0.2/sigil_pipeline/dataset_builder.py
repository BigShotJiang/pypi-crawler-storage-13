"""
Dataset builder module for creating prompt-gen pairs from code.

Converts filtered code files into training examples with prompts and code.
Matches Phase 1 format exactly for consistent tokenization and training.

Copyright (c) 2025 Dave Tofflemire, SigilDERG Project
"""

import logging
import re
import textwrap
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, Optional

from .analyzer import CrateAnalysisReport
from .format_validator import FormatValidator

logger = logging.getLogger(__name__)


def extract_description_from_docs(code: str) -> Optional[str]:
    """
    Extract a description from doc comments in code.

    Args:
        code: Code content with potential doc comments

    Returns:
        Description string or None if not found
    """
    # Look for module-level doc comment (//! or /// at start)
    module_doc_match = re.search(
        r"^//![\s]*(.+?)(?:\n\n|\n//[^!]|$)",
        code,
        re.MULTILINE | re.DOTALL,
    )
    if module_doc_match:
        desc = module_doc_match.group(1).strip()
        # Clean up markdown and extra whitespace
        desc = re.sub(r"#+\s*", "", desc)  # Remove markdown headers
        desc = re.sub(r"\s+", " ", desc)  # Normalize whitespace
        return desc[:200]  # Limit length

    # Look for function doc comments
    fn_doc_match = re.search(
        r"^///[\s]*(.+?)(?:\n\s*///|\n\s*pub fn|\n\s*fn|$)",
        code,
        re.MULTILINE | re.DOTALL,
    )
    if fn_doc_match:
        desc = fn_doc_match.group(1).strip()
        desc = re.sub(r"#+\s*", "", desc)
        desc = re.sub(r"\s+", " ", desc)
        return desc[:200]

    return None


def detect_code_patterns(code: str) -> Dict[str, Any]:
    """
    Detect patterns in code to help generate better prompts.

    Args:
        code: Code content

    Returns:
        Dictionary of detected patterns
    """
    patterns = {
        "has_main": "fn main" in code,
        "has_async": "async fn" in code or "tokio::" in code or "async-std" in code,
        "has_error_handling": "anyhow" in code
        or "Result<" in code
        or ".unwrap()" in code
        or ".expect(" in code,
        "has_serde": "serde" in code.lower()
        or "Serialize" in code
        or "Deserialize" in code,
        "has_iterators": ".iter()" in code
        or ".map(" in code
        or ".filter(" in code
        or ".collect()" in code,
        "has_collections": "Vec<" in code
        or "HashMap<" in code
        or "HashSet<" in code
        or "BTreeMap<" in code,
        "has_strings": "String::" in code or "&str" in code or ".to_string()" in code,
        "has_io": "std::io" in code or "File::" in code or "read_line" in code,
        "has_networking": "http" in code.lower()
        or "reqwest" in code.lower()
        or "hyper" in code.lower(),
        "has_concurrency": "thread::" in code
        or "Arc<" in code
        or "Mutex<" in code
        or "RwLock<" in code,
        "function_names": re.findall(r"fn\s+(\w+)", code),
    }
    return patterns


def generate_prompt_for_code(
    code: str,
    crate_name: Optional[str] = None,
    analysis: Optional[CrateAnalysisReport] = None,
    file_path: Optional[str] = None,
) -> str:
    """
    Generate an instruction prompt for the given code snippet matching Phase 1 style.

    Phase 1 prompts typically follow patterns like:
    - "Write a Rust program that does X... Output only the code."
    - "Write a Rust code example that demonstrates Y..."

    Args:
        code: Code content
        crate_name: Name of the crate (optional)
        analysis: Crate analysis report (optional)
        file_path: Path to the file (optional, used for hints)

    Returns:
        Instruction prompt string matching Phase 1 style
    """
    # Try to extract description from doc comments first (most reliable)
    description = extract_description_from_docs(code)

    # Detect code patterns for better prompt generation
    patterns = detect_code_patterns(code)

    # Use file path as hint if available
    path_hint = None
    if file_path:
        path_lower = file_path.lower()
        if "iterator" in path_lower or "iter" in path_lower:
            path_hint = "uses iterators"
        elif "error" in path_lower or "result" in path_lower:
            path_hint = "handles errors"
        elif "async" in path_lower or "future" in path_lower:
            path_hint = "uses async/await"
        elif "serde" in path_lower or "serialize" in path_lower:
            path_hint = "demonstrates serialization"
        elif "example" in path_lower:
            # Extract example name
            example_match = re.search(r"example[_-]?(\w+)", path_lower)
            if example_match:
                example_name = example_match.group(1).replace("_", " ")
                path_hint = f"demonstrates {example_name}"

    # Build prompt based on available information
    if description:
        # Use doc comment description
        # Clean up description for prompt
        desc_clean = description.lower().strip()
        # Remove common prefixes
        desc_clean = re.sub(r"^(this|a|an|the)\s+", "", desc_clean)
        # Ensure it starts with a verb or description
        prompt = f"Write a Rust program that {desc_clean}"
    elif path_hint:
        # Use path-based hint
        prompt = f"Write a Rust program that {path_hint}"
    elif patterns["has_main"]:
        # It's a main function, infer from patterns
        if patterns["has_error_handling"]:
            prompt = "Write a Rust program that demonstrates error handling"
        elif patterns["has_async"]:
            prompt = "Write a Rust program that demonstrates async/await usage"
        elif patterns["has_serde"]:
            prompt = "Write a Rust program that demonstrates serialization"
        elif patterns["has_iterators"]:
            prompt = "Write a Rust program that uses iterators to process data"
        elif patterns["has_networking"]:
            prompt = "Write a Rust program that makes HTTP requests"
        elif patterns["has_io"]:
            prompt = "Write a Rust program that reads and writes files"
        else:
            prompt = "Write a Rust program"
    elif patterns["function_names"]:
        # Extract function name and convert to description
        fn_name = patterns["function_names"][0]
        # Convert snake_case to readable description
        fn_desc = fn_name.replace("_", " ")
        # Try to infer action from function name
        if fn_name.startswith("get_") or fn_name.startswith("fetch_"):
            prompt = f"Write a Rust function that retrieves {fn_desc[4:]}"
        elif fn_name.startswith("set_") or fn_name.startswith("update_"):
            prompt = f"Write a Rust function that updates {fn_desc[4:]}"
        elif fn_name.startswith("create_") or fn_name.startswith("new_"):
            prompt = f"Write a Rust function that creates {fn_desc[6:]}"
        elif fn_name.startswith("parse_") or fn_name.startswith("read_"):
            prompt = f"Write a Rust function that parses {fn_desc[6:]}"
        else:
            prompt = f"Write a Rust function that {fn_desc}"
    elif patterns["has_iterators"]:
        prompt = "Write a Rust code example that uses iterators to process data"
    elif patterns["has_error_handling"]:
        prompt = "Write a Rust code example that demonstrates error handling"
    elif crate_name:
        # Fix grammar: "Write a Rust code snippet using the {crate} crate." (Priority 6.1)
        prompt = f"Write a Rust code snippet using the {crate_name} crate"
    else:
        # Generic fallback matching Phase 1 style
        prompt = "Write idiomatic Rust code"

    # Ensure prompt ends with instruction (Phase 1 style)
    # Phase 1 prompts often end with "Output only the code." but check if it's already there
    if "output only" not in prompt.lower() and "code" not in prompt.lower()[-20:]:
        # Don't always add "Output only the code" - Phase 1 may not have it consistently
        # Just ensure the prompt is clear and direct
        pass

    # Normalize prompt (remove extra whitespace, ensure proper capitalization)
    prompt = re.sub(r"\s+", " ", prompt).strip()
    if prompt and not prompt[0].isupper():
        prompt = prompt[0].upper() + prompt[1:]

    return prompt


def format_code_for_gen(code: str, phase1_spec: Optional[Dict[str, Any]] = None) -> str:
    """
    Format code for the 'gen' field to match Phase 1 format.

    Args:
        code: Raw code content
        phase1_spec: Phase 1 format specification (optional)

    Returns:
        Formatted code string
    """
    # Strip and dedent code
    formatted = textwrap.dedent(code).strip()

    # Check Phase 1 spec for backticks requirement
    if phase1_spec:
        code_formatting = phase1_spec.get("format_requirements", {}).get(
            "code_formatting", {}
        )
        has_backticks = code_formatting.get("has_backticks", False)

        # If Phase 1 didn't use backticks, ensure we don't have them
        if not has_backticks:
            # Remove any triple backticks and language tags
            formatted = re.sub(r"```rust\n?", "", formatted)
            formatted = re.sub(r"```\n?", "", formatted)
            formatted = formatted.strip()

    # Ensure consistent line endings (Unix-style)
    formatted = formatted.replace("\r\n", "\n").replace("\r", "\n")

    return formatted


def build_dataset_entries(
    files: Iterable[dict],
    validate_format: bool = True,
    phase1_spec_path: Optional[Path] = None,
) -> Iterator[dict]:
    """
    Convert an iterable of code files into dataset samples (prompt-gen pairs).

    Matches Phase 1 format exactly: {"prompt": "...", "gen": "..."}
    Refactored to accept Iterable and yield (Priority 2.1 - Streaming Architecture).

    Args:
        files: Iterable of file dicts with 'path', 'code', and optionally 'crate_name'
        validate_format: Whether to validate samples against Phase 1 format
        phase1_spec_path: Path to Phase 1 format specification (optional)

    Yields:
        Dicts with 'prompt' and 'gen' keys matching Phase 1 format
    """
    # Load format validator if needed
    validator = None
    phase1_spec = None
    if validate_format:
        validator = FormatValidator(phase1_spec_path)
        if validator.phase1_spec:
            phase1_spec = validator.phase1_spec

    validation_errors = []
    sample_count = 0

    for file_info in files:
        code = file_info.get("code", "")
        if not code:
            continue

        # Format code for gen field (match Phase 1 format)
        formatted_code = format_code_for_gen(code, phase1_spec)

        # Generate prompt matching Phase 1 style
        crate_name = file_info.get("crate_name")
        file_path = file_info.get("path")
        prompt = generate_prompt_for_code(formatted_code, crate_name, None, file_path)

        # Create sample with exact Phase 1 structure
        sample = {
            "prompt": prompt,
            "gen": formatted_code,
        }

        # Validate format if requested
        if validator:
            is_valid, errors = validator.validate_sample(sample)
            if not is_valid:
                validation_errors.append(
                    {
                        "file": file_path,
                        "errors": errors,
                    }
                )
                logger.debug(f"Format validation failed for {file_path}: {errors}")
                # Continue anyway, but log the error

        sample_count += 1
        yield sample

    if validation_errors:
        logger.warning(
            f"Format validation found {len(validation_errors)} samples with issues. "
            f"Check logs for details."
        )

    logger.info(f"Generated {sample_count} dataset samples")
