# Sigil Pipeline v1.0.2

A static analysis pipeline for generating high-quality Rust code datasets for model fine-tuning. The pipeline analyzes Rust crates using static analysis tools and generates training datasets in JSONL format.

**Version 1.0.2** includes:
- License pre-checking from crates.io API
- Cargo-deny security auditing integration
- Streaming architecture for memory-efficient processing
- Granular filter metrics and observability
- Enhanced quality filtering (unsafe code, outdated dependencies)
- Platform compatibility detection
- Shared cargo target directory for faster builds

## Overview

Sigil Pipeline performs comprehensive static analysis on Rust crates to identify high-quality, idiomatic code suitable for training code generation models. It combines:

- **Curated Rust crates** analyzed through static analysis tools
- **The Stack Rust Clean dataset** files (from HuggingFace)
- **Format validation** to ensure consistent dataset structure

The pipeline generates JSONL datasets with prompt-generation pairs that can be used directly for fine-tuning language models.

## Features

### Static Code Analysis

- **Clippy**: Detects idiomatic code patterns and lint violations
- **Cargo Geiger**: Analyzes unsafe code usage and safety metrics
- **Cargo Outdated**: Assesses dependency maintenance status
- **Cargo License**: Checks license compliance (with centralized verification logic)
- **Cargo Deny**: Performs security and license auditing (optional, configurable)
- **License Pre-Check**: Validates licenses from crates.io API before downloading

### Quality Filtering

- **Rust Edition**: Filters to 2021+ edition crates (modern Rust)
- **Clippy Warnings**: Configurable threshold (default: 0 warnings for strict idiomatic code)
- **Documentation**: Requires documentation comments on public items
- **Test/Bench Exclusion**: Automatically filters out test and benchmark files
- **Size/Sanity Filters**: Applies Stack dataset filtering criteria (line length, alphabetic ratio)
- **License Filtering**: Only includes permissively licensed code (MIT, Apache-2.0, BSD, etc.) with SPDX expression support
- **Unsafe Code Filtering**: Optional threshold for maximum unsafe code items (from Geiger)
- **Outdated Dependencies**: Optional threshold for maximum outdated dependency ratio
- **Platform Compatibility**: Automatically skips OS-specific crates incompatible with current platform
- **Security Auditing**: Optional cargo-deny integration for security advisories and license violations

### Dataset Generation

- **Prompt Generation**: Creates instruction prompts from code and documentation (with grammar fixes)
- **Format Validation**: Ensures consistent dataset structure matching Phase 1 format
- **Stack Dataset Integration**: Streams files from HuggingFace datasets or uses local cache
- **Dataset Merging**: Combines multiple datasets with shuffle and weighting options
- **Streaming Architecture**: Generator-based pipeline for memory-efficient processing of large datasets
- **Granular Metrics**: Detailed filter reason breakdown for observability

## Requirements

- **Python 3.12+**
- **Rust toolchain** (1.56+ for 2021 edition, 1.72+ for 2024 edition)
- **Cargo subcommands**:
  - `cargo clippy` (included with rustup)
  - `cargo geiger`
  - `cargo outdated`
  - `cargo license`
  - `cargo deny`

See [docs/SETUP.md](docs/SETUP.md) for detailed setup instructions.

## Installation

```bash
# Clone the repository
git clone https://github.com/Superuser666-Sigil/SigilDERG-Data_Production.git
cd SigilDERG-Data_Production

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -e ".[datasets]"

# Install Rust analysis tools
cargo install cargo-geiger cargo-outdated cargo-license cargo-deny
rustup component add clippy
```

## Quick Start

### Command Line

```bash
# Analyze specific crates
python -m sigil_pipeline.main --crates serde tokio actix-web

# Use crate list file
python -m sigil_pipeline.main --crate-list data/crate_list.txt

# Include Stack dataset (from local cache)
python -m sigil_pipeline.main \
  --include-stack-dataset \
  --stack-dataset-path "datasets/the-stack-rust-clean" \
  --output output/dataset.jsonl

# Include Stack dataset with streaming fallback
python -m sigil_pipeline.main \
  --include-stack-dataset \
  --stack-dataset-path "datasets/the-stack-rust-clean" \
  --stack-dataset-streaming \
  --output output/dataset.jsonl

# Merge with existing dataset
python -m sigil_pipeline.main \
  --merge-with-phase1 \
  --phase1-dataset-path "data/phase1.jsonl" \
  --shuffle-merged \
  --output output/merged.jsonl
```

### Python API

```python
import asyncio
from sigil_pipeline.config import PipelineConfig
from sigil_pipeline.main import run_pipeline

async def main():
    config = PipelineConfig(
        crates=["serde", "tokio"],
        include_stack_dataset=True,
        output_path="output/dataset.jsonl",
    )
    
    await run_pipeline(config)

if __name__ == "__main__":
    asyncio.run(main())
```

## Configuration

The pipeline uses a `PipelineConfig` dataclass for all settings. Key options:

```python
from sigil_pipeline.config import PipelineConfig

config = PipelineConfig(
    # Crates to analyze
    crates=["serde", "tokio"],
    crate_list_path="data/crate_list.txt",  # Or specify individual crates
    
    # Stack dataset integration
    include_stack_dataset=True,
    stack_dataset_path="ammarnasr/the-stack-rust-clean",
    
    # Quality thresholds
    allow_edition_2018=False,  # Only 2021+ edition
    max_clippy_warnings=0,  # Strict idiomatic code
    require_docs=True,  # Require documentation
    
    # Advanced filtering
    max_unsafe_items=None,  # Optional: max unsafe code items (None = no filter)
    max_outdated_ratio=None,  # Optional: max outdated dependency ratio
    enable_deny_scan=False,  # Optional: cargo-deny security auditing
    
    # File filtering
    max_line_length=100,  # Matches Stack dataset criteria
    min_alphabetic_ratio=0.3,  # Filters minified code
    
    # Dataset merging
    merge_with_phase1=False,
    phase1_dataset_path=None,
    shuffle_merged=True,
    phase2_weight=1.0,
    
    # Performance
    reuse_cargo_target=True,  # Share cargo target directory for faster builds
    
    # Output
    output_path="output/dataset.jsonl",
    max_threads=4,  # Parallel processing
)
```

Configuration can be loaded from JSON or YAML files:

```bash
python -m sigil_pipeline.main --config config.yaml
```

## Output Format

The pipeline generates JSONL files (one JSON object per line) with the following structure:

```jsonl
{"prompt": "Write a Rust program that demonstrates error handling", "gen": "use anyhow::Result;\n\nfn main() -> Result<()> {\n    // ...\n}"}
{"prompt": "Write a Rust code example that uses iterators", "gen": "fn process_data(items: &[i32]) -> Vec<i32> {\n    items.iter().map(|x| x * 2).collect()\n}"}
```

Each line contains:
- `prompt`: Instruction prompt describing what the code does
- `gen`: Generated code (plain text, UTF-8 encoded)

See [docs/DATASET_SCHEMA.md](docs/DATASET_SCHEMA.md) for detailed format specification.

## Project Structure

```
sigil_pipeline/          # Main pipeline package
├── main.py             # Pipeline orchestration and CLI entry point
├── config.py           # Configuration management
├── crawler.py          # Crate downloading and Stack dataset integration
├── analyzer.py         # Static analysis tools execution
├── filter.py           # Quality filtering heuristics
├── dataset_builder.py  # Prompt generation and dataset assembly
├── exporter.py         # JSONL export and dataset merging
├── format_validator.py # Format validation
└── utils.py            # Utilities (cargo commands, file I/O, etc.)

tools/                  # Analysis and comparison tools
├── analyze_phase1_format.py
└── compare_phase_formats.py

tests/                  # Test suite
docs/                   # Documentation
```

## Tools

### Format Analysis

```bash
# Analyze dataset format from checkpoint
python tools/analyze_phase1_format.py \
  --checkpoint checkpoint-2000 \
  --output docs/format_spec.json
```

### Format Comparison

```bash
# Compare two dataset formats
python tools/compare_phase_formats.py \
  dataset1.jsonl \
  dataset2.jsonl \
  --max-samples 50 \
  --output comparison_report.json
```

## Testing

```bash
# Run all tests
pytest tests/

# Run format validation tests
pytest tests/test_format_alignment.py -v

# Run local CI checks
python test_ci_local.py
```

## Documentation

- **[Setup Guide](docs/SETUP.md)**: Rust toolchain and cargo subcommand installation
- **[Dataset Schema](docs/DATASET_SCHEMA.md)**: Detailed dataset format specification
- **[OS-Agnostic Cargo Commands](docs/OS_AGNOSTIC_CARGO_COMMANDS.md)**: Cross-platform cargo usage
- **[Testing CI Locally](docs/TESTING_CI_LOCALLY.md)**: Local CI workflow testing

## Docker

The project includes Docker support for containerized execution:

```bash
# Build image
docker build -t sigil-pipeline .

# Run pipeline
docker-compose up
```

See `docker-compose.yml` and `Dockerfile` for configuration details.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- **Rust community** for excellent analysis tools (Clippy, Geiger, etc.)
- **HuggingFace** for the Stack dataset and datasets library
- **The Stack dataset** contributors for providing high-quality Rust code

---

**Sigil Pipeline** - Generating high-quality Rust code datasets for model fine-tuning.
