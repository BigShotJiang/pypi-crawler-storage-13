"""
LangChain callback handler for Oso observability integration.

Example usage:
    from langchain_oso import OsoObservabilityCallback

    callback = OsoObservabilityCallback(
        auth_token="your-oso-auth-token",
        agent_id="my-support-agent"
    )

    agent = create_agent(callbacks=[callback])
    result = await agent.ainvoke({"input": "Hello"})
    await callback.aclose()

    # Or use as context manager:
    async with OsoObservabilityCallback(auth_token="...") as callback:
        agent = create_agent(callbacks=[callback])
        result = await agent.ainvoke({"input": "Hello"})
"""

import os
import json
import time
import uuid
import logging
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
from langchain_core.callbacks.base import AsyncCallbackHandler
import httpx


logger = logging.getLogger(__name__)


class OsoObservabilityCallback(AsyncCallbackHandler):
    """
    LangChain callback handler that sends agent events to Oso observability.

    Automatically captures:
    - LLM calls (model, prompts, responses, token usage)
    - Tool executions (name, inputs, outputs, duration, errors)
    - Agent reasoning (decisions, thoughts, intermediate steps)
    - Chain executions (starts, ends, inputs, outputs)
    - Errors at any stage

    Args:
        endpoint: Oso observability endpoint URL (default: OSO_ENDPOINT env var
                  or https://cloud.osohq.com/api/events)
        auth_token: Oso authentication token (default: OSO_AUTH_TOKEN env var)
        enabled: Whether to send events (default: OSO_OBSERVABILITY_ENABLED env var or True)
        session_id: Session ID to group related conversations (default: auto-generated UUID)
        metadata: Additional metadata to attach to all events
        agent_id: Agent identifier for tracking (default: "default-agent")
    """

    def __init__(
        self,
        endpoint: Optional[str] = None,
        auth_token: Optional[str] = None,
        enabled: Optional[bool] = None,
        session_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        agent_id: Optional[str] = None,
    ):
        self.endpoint = endpoint or os.getenv(
            "OSO_ENDPOINT", "https://cloud.osohq.com/api/events"
        )
        self.auth_token = auth_token or os.getenv("OSO_AUTH_TOKEN")
        self.enabled = (
            enabled
            if enabled is not None
            else os.getenv("OSO_OBSERVABILITY_ENABLED", "true").lower() == "true"
        )
        self.session_id = session_id or str(uuid.uuid4())
        self.metadata = metadata or {}
        self.agent_id = agent_id or "default-agent"

        self.execution_id = str(uuid.uuid4())
        self.execution_start_time = time.time()
        self.tool_start_times: Dict[str, float] = {}
        self.client = httpx.AsyncClient(timeout=None)  # No timeout, close when agent stops

        # Accumulate data for summary event
        self.llm_calls: List[Dict] = []
        self.tool_calls: List[Dict] = []
        self.agent_steps: List[Dict] = []
        self.errors: List[Dict] = []

        logger.debug(
            f"OsoObservabilityCallback initialized: endpoint={self.endpoint}, "
            f"agent_id={self.agent_id}, session_id={self.session_id}, enabled={self.enabled}"
        )

    async def __aenter__(self):
        """Context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - ensures HTTP client cleanup."""
        await self.aclose()
        return False

    # LLM callbacks

    async def on_llm_start(
        self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any
    ) -> None:
        """Called when LLM starts processing."""
        if serialized is None:
            model_name = "unknown"
        else:
            model_name = serialized.get("name", serialized.get("id", ["unknown"])[-1])

        await self._send_event(
            "llm.started",
            {"model": model_name, "prompts": prompts, "num_prompts": len(prompts)},
        )

    async def on_llm_end(self, response: Any, **kwargs: Any) -> None:
        """Called when LLM completes."""
        try:
            llm_output = {}
            if hasattr(response, "llm_output") and response.llm_output:
                llm_output = response.llm_output

            token_usage = llm_output.get("token_usage", {})
            generations = []
            if hasattr(response, "generations") and response.generations:
                for gen_list in response.generations:
                    for gen in gen_list:
                        generations.append(
                            {
                                "text": gen.text if hasattr(gen, "text") else str(gen),
                                "metadata": (
                                    gen.generation_info
                                    if hasattr(gen, "generation_info")
                                    else {}
                                ),
                            }
                        )

            call_data = {
                "model": llm_output.get("model_name", "unknown"),
                "generations": generations,
                "token_usage": {
                    "prompt_tokens": token_usage.get("prompt_tokens", 0),
                    "completion_tokens": token_usage.get("completion_tokens", 0),
                    "total_tokens": token_usage.get("total_tokens", 0),
                },
            }

            self.llm_calls.append(call_data)
            await self._send_event("llm.completed", call_data)

        except Exception as e:
            logger.error(f"Error in on_llm_end: {e}", exc_info=True)
            await self._send_event("llm.error", {"error": str(e)})

    async def on_llm_error(self, error: Exception, **kwargs: Any) -> None:
        """Called when LLM encounters an error."""
        error_data = {"error_type": type(error).__name__, "error_message": str(error)}
        self.errors.append({"type": "llm_error", **error_data})
        await self._send_event("llm.error", error_data)

    # Tool callbacks

    async def on_tool_start(
        self, serialized: Dict[str, Any], input_str: str, **kwargs: Any
    ) -> None:
        """Called when a tool execution starts."""
        if serialized is None:
            tool_name = "unknown"
            tool_description = ""
        else:
            tool_name = serialized.get("name", "unknown")
            tool_description = serialized.get("description", "")

        run_id = kwargs.get("run_id", "unknown")
        self.tool_start_times[str(run_id)] = time.time()

        await self._send_event(
            "tool.started",
            {
                "tool_name": tool_name,
                "tool_description": tool_description,
                "input": input_str,
                "run_id": str(run_id),
            },
        )

    async def on_tool_end(self, output: str, **kwargs: Any) -> None:
        """Called when a tool execution completes successfully."""
        run_id = str(kwargs.get("run_id", "unknown"))
        start_time = self.tool_start_times.get(run_id)
        duration_ms = (time.time() - start_time) * 1000 if start_time else None

        tool_data = {"output": output, "duration_ms": duration_ms, "run_id": run_id}

        self.tool_calls.append(tool_data)
        await self._send_event("tool.completed", tool_data)

        if run_id in self.tool_start_times:
            del self.tool_start_times[run_id]

    async def on_tool_error(self, error: Exception, **kwargs: Any) -> None:
        """Called when a tool execution fails."""
        run_id = str(kwargs.get("run_id", "unknown"))
        start_time = self.tool_start_times.get(run_id)
        duration_ms = (time.time() - start_time) * 1000 if start_time else None

        error_data = {
            "error_type": type(error).__name__,
            "error_message": str(error),
            "duration_ms": duration_ms,
            "run_id": run_id,
        }

        self.errors.append({"type": "tool_error", **error_data})
        await self._send_event("tool.error", error_data)

        if run_id in self.tool_start_times:
            del self.tool_start_times[run_id]

    # Agent callbacks

    async def on_agent_action(self, action: Any, **kwargs: Any) -> None:
        """Called when agent decides to take an action."""
        step_data = {
            "step_type": "action",
            "tool": action.tool,
            "tool_input": action.tool_input,
            "reasoning": action.log,
        }

        self.agent_steps.append(step_data)
        await self._send_event("agent.action", step_data)

    async def on_agent_finish(self, finish: Any, **kwargs: Any) -> None:
        """Called when agent completes execution."""
        finish_data = {
            "return_values": finish.return_values,
            "final_reasoning": finish.log if hasattr(finish, "log") else None,
        }

        await self._send_event("agent.finished", finish_data)
        await self._send_execution_summary()

    # Chain callbacks

    async def on_chain_start(
        self, serialized: Dict[str, Any], inputs: Dict[str, Any], **kwargs: Any
    ) -> None:
        """Called when a chain starts executing."""
        if serialized is None:
            chain_name = "unknown"
        else:
            chain_name = serialized.get("name", serialized.get("id", ["unknown"])[-1])

        await self._send_event("chain.started", {"chain_name": chain_name, "inputs": inputs})

    async def on_chain_end(self, outputs: Dict[str, Any], **kwargs: Any) -> None:
        """Called when a chain completes."""
        await self._send_event("chain.completed", {"outputs": outputs})

    async def on_chain_error(self, error: Exception, **kwargs: Any) -> None:
        """Called when a chain encounters an error."""
        error_data = {"error_type": type(error).__name__, "error_message": str(error)}
        self.errors.append({"type": "chain_error", **error_data})
        await self._send_event("chain.error", error_data)

    # Internal methods

    async def _send_event(self, event_type: str, data: Dict[str, Any]):
        """Send a single event to Oso observability backend."""
        if not self.enabled:
            return

        try:
            payload = {
                "event_type": event_type,
                "execution_id": self.execution_id,
                "session_id": self.session_id,
                "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                "data": data,
                "metadata": self.metadata,
                "agent_id": self.agent_id,
            }

            logger.debug(f"Sending event: {event_type}")

            headers = {"Content-Type": "application/json"}
            if self.auth_token:
                headers["Authorization"] = f"Bearer {self.auth_token}"

            response = await self.client.post(self.endpoint, json=payload, headers=headers)

            if response.status_code not in [200, 201, 202]:
                logger.warning(
                    f"Oso backend returned {response.status_code} for event {event_type}"
                )
            else:
                logger.debug(f"Event {event_type} sent successfully")

        except httpx.TimeoutException:
            logger.warning(f"Timeout sending event {event_type} to Oso")
        except httpx.RequestError as e:
            logger.warning(f"Network error sending event {event_type}: {type(e).__name__}")
        except Exception as e:
            logger.error(
                f"Error sending event {event_type}: {type(e).__name__}: {e}", exc_info=True
            )

    async def _send_execution_summary(self):
        """Send a summary of the entire execution."""
        duration_ms = (time.time() - self.execution_start_time) * 1000

        total_tokens = sum(
            call.get("token_usage", {}).get("total_tokens", 0) for call in self.llm_calls
        )

        summary = {
            "execution_id": self.execution_id,
            "session_id": self.session_id,
            "duration_ms": duration_ms,
            "llm_calls_count": len(self.llm_calls),
            "tool_calls_count": len(self.tool_calls),
            "agent_steps_count": len(self.agent_steps),
            "errors_count": len(self.errors),
            "total_tokens": total_tokens,
            "llm_calls": self.llm_calls,
            "tool_calls": self.tool_calls,
            "agent_steps": self.agent_steps,
            "errors": self.errors,
        }

        await self._send_event("execution.summary", summary)

    async def aclose(self):
        """Close the HTTP client."""
        logger.debug("Closing HTTP client")
        await self.client.aclose()
