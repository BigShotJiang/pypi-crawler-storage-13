"""Oso observability integration for LangChain."""

from langchain_oso.callbacks import OsoObservabilityCallback
from langchain_oso.version import __version__

__all__ = ["OsoObservabilityCallback", "__version__"]
