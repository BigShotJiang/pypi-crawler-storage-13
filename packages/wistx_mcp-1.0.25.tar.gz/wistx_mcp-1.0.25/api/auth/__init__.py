"""Authentication module."""

