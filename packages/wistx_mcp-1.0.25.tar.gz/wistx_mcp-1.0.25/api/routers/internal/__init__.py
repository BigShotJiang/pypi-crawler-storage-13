"""Internal admin endpoints."""

from api.routers.internal import admin, webhooks

__all__ = ["admin", "webhooks"]

