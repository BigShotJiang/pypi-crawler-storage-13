![Coolbooy's Logo](https://imgur.com/gallery/free-fire-Oe2e0UX#tn4fi4c.jpeg)

🚀 Full Booster + One-Tap Headshot Sensitivity Engine.

🔰 SL Android Official ™ 🇱🇰

👨‍💻 Developer: 𝐈𝐌 𝐂𝐎𝐎𝐋 𝐁𝐎𝐎𝐘 𝓢𝓱𝓪𝓭𝓸𝔀 𝓚𝓲𝓷𝓰

---

🚀 Overview

IM-COOL-BOOY-FF is an Android/Termux-based performance enhancement toolkit designed for Free Fire players.

It provides:

Real-time ping and FPS monitoring

Network boost & stability tools

Full data booster engine

Auto-generated headshot sensitivity settings

Game launch + auto booster mode

Device and network diagnostics


The tool works without root and uses optimized system commands + performance analytics.


---

🌟 Features

🔥 1. Live Ping + FPS Monitor

Real-time ping measurement

FPS analyzer using dumpsys

Moving average smoothing

Clean terminal dashboard


⚡ 2. Data Booster (Extra Boost Mode)

Ping stabilizer

DNS optimization

Network refresh

MI 9T special Qualcomm turbo booster

Automatic recovery during high-ping spikes


📶 3. Engineering Mode Helper

Instant access to Android 4636 testing menu

Useful for network changes, signal tests, and radio info


🌐 4. APN Quick Access

Opens APN settings instantly

Useful for fixing internet/APN issues

📄 5. Full System + Network Report

Generates a detailed report at:

/sdcard/Download/coolreport.txt

Includes:

Device info

Android version

SIM / network details

Signal logs

Netstats

GFXInfo FPS dump


🎮 6. Auto-Boost + Game Launcher

Launches Free Fire

Starts booster loop in background

Optimizes game latency instantly


🎯 7. One-Tap Headshot Sensitivity Engine

Automatically detects DPI and creates:

General sensitivity

Red Dot

2x / 4x scope

AWM

Free Look

Fire Button size


Perfect for one-tap headshot players.


---
📦 Installation

(After publishing to PyPI)

01. pip install IM-COOL-BOOY-FF

Run the tool:

02. IM-COOL-BOOY-FF
---

🛠 Requirements

Android (Termux)

Python 3.10+

No root needed

Works on all brands (Xiaomi, Samsung, Oppo, Vivo, Realme, Huawei, etc.)

---

⚠️ Disclaimer

This tool is created for educational and optimization purposes only.
It does not modify game files or provide cheating methods.
Use responsibly.


---

❤️ Developer

Created with passion by IM COOL BOOY – Shadow King

💠 Let me know if you want me to add this directly into your Python code or CLI help message too.!

📱 Social Media & Contact: ⤵️

➡️ Telegram Group:  https://t.me/SL_Android

➡️  Developer: https://t.me/COOLBOOY550
