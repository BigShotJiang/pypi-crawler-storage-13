## #!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 30 15:44:26 2020
Copyright 2020 Peter Rakyta, Ph.D.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions andP
limitations under the License.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/.

@author: Peter Rakyta, Ph.D.
"""

## \file qgd_Circuit.py
##    \brief A Python interface class representing  Squander circuit.


import numpy as np
from os import path
from squander.gates.qgd_Circuit_Wrapper import qgd_Circuit_Wrapper


from squander.gates.gates_Wrapper import (
    U1,
    U2,
    U3,
    H,
    X,
    Y,
    Z,
    S,
    Sdg,
    T,
    Tdg,
    CH,
    CNOT,
    CZ,
    R,
    RX,
    RY,
    RZ,
    SX,
    SYC,
    CRY,
    CRZ,
    CRX,
    CP,
    CR,
    CROT,
    CCX,
    CSWAP,
    SWAP)


##
# @brief A QGD Python interface class for the Gates_Block.
class qgd_Circuit(qgd_Circuit_Wrapper):
    
    
## 
# @brief Constructor of the class.
# @param qbit_num: the number of qubits spanning the operations
# @return An instance of the class

    def __init__( self, qbit_num ):

        # call the constructor of the wrapper class
        super().__init__( qbit_num )

    """
    def __getstate__(self):
        # Return a dictionary of the object's state

        return super().__getstate__()

    def __setstate__(self, state):

        print( state )
        super().__setstate__( state )
    

    def __new__(cls, *args, **kwargs):

        print( "NEEEEEEEEEEEEEW", args)
        return super().__new__(cls, *args, **kwargs)
    """

#@brief Call to add a U1 gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input argument: target_qbit (int)

    def add_U1( self, target_qbit):

	# call the C wrapper function
        super().add_U1(target_qbit)

#@brief Call to add a U2 gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input argument: target_qbit (int)

    def add_U2( self, target_qbit):

	# call the C wrapper function
        super().add_U2(target_qbit)

#@brief Call to add a U3 gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input argument: target_qbit (int)

    def add_U3( self, target_qbit):

	# call the C wrapper function
        super().add_U3(target_qbit)

#@brief Call to add a RX gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).

    def add_RX( self, target_qbit):

	# call the C wrapper function
        super().add_RX(target_qbit)

#@brief Call to add a R gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).
    def add_R( self, target_qbit):

	# call the C wrapper function
        super().add_R(target_qbit)

#@brief Call to add a RY gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).

    def add_RY( self, target_qbit):

	# call the C wrapper function
        super().add_RY(target_qbit)

#@brief Call to add a RZ gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).

    def add_RZ( self, target_qbit):

	# call the C wrapper function
        super().add_RZ(target_qbit)

#@brief Call to add a CNOT gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_CNOT( self, target_qbit, control_qbit):

	# call the C wrapper function
        super().add_CNOT(target_qbit, control_qbit)

#@brief Call to add a CZ gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_CZ( self, target_qbit, control_qbit):

	# call the C wrapper function
        super().add_CZ(target_qbit, control_qbit)

#@brief Call to add a CH gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_CH( self, target_qbit, control_qbit):

	# call the C wrapper function
        super().add_CH(target_qbit, control_qbit)

#@brief Call to add a CU gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_CU( self, target_qbit, control_qbit):

	# call the C wrapper function
        super().add_CU(target_qbit, control_qbit)
	
#@brief Call to add a SYC gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_SYC( self, target_qbit, control_qbit):

	# call the C wrapper function
        super().add_SYC(target_qbit, control_qbit)


#@brief Call to add a Hadamard gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int)

    def add_H( self, target_qbit):

	# call the C wrapper function
        super().add_H(target_qbit)

#@brief Call to add a X gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int)

    def add_X( self, target_qbit):

	# call the C wrapper function
        super().add_X(target_qbit)

#@brief Call to add a Y gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).

    def add_Y( self, target_qbit):

	# call the C wrapper function
        super().add_Y(target_qbit)

#@brief Call to add a Z gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).

    def add_Z( self, target_qbit):

	# call the C wrapper function
        super().add_Z(target_qbit)

#@brief Call to add a SX gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).

    def add_SX( self, target_qbit):

	# call the C wrapper function
        super().add_SX(target_qbit)

#@brief Call to add a S gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).

    def add_S( self, target_qbit):

	# call the C wrapper function
        super().add_S(target_qbit)

#@brief Call to add a Sdg gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).

    def add_Sdg( self, target_qbit):

	# call the C wrapper function
        super().add_Sdg(target_qbit)

#@brief Call to add a T gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).

    def add_T( self, target_qbit):

	# call the C wrapper function
        super().add_T(target_qbit)

#@brief Call to add a Tdg gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).

    def add_Tdg( self, target_qbit):

	# call the C wrapper function
        super().add_Tdg(target_qbit)

#@brief Call to add adaptive gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_adaptive( self, target_qbit, control_qbit):

	# call the C wrapper function
        super().add_adaptive(target_qbit, control_qbit)
        
#@brief Call to add a CROT gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int).

    def add_CROT( self, target_qbit, control_qbit):

	# call the C wrapper function
        super(qgd_Circuit, self).add_CROT(target_qbit, control_qbit)

#@brief Call to add a CR gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_CR( self, target_qbit, control_qbit):

	# call the C wrapper function
        super(qgd_Circuit, self).add_CR(target_qbit, control_qbit)

#@brief Call to add a CRY gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_CRY( self, target_qbit, control_qbit):

	# call the C wrapper function
        super(qgd_Circuit, self).add_CRY(target_qbit, control_qbit)

#@brief Call to add a CRZ gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_CRZ( self, target_qbit, control_qbit):

	# call the C wrapper function
        super(qgd_Circuit, self).add_CRZ(target_qbit, control_qbit)

#@brief Call to add a CRX gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_CRX( self, target_qbit, control_qbit):

	# call the C wrapper function
        super(qgd_Circuit, self).add_CRX(target_qbit, control_qbit)

#@brief Call to add a CP gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_CP( self, target_qbit, control_qbit):

	# call the C wrapper function
        super(qgd_Circuit, self).add_CP(target_qbit, control_qbit)

#@brief Call to add a SWAP gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbits (list of int) - list of target qubits (at least 2).

    def add_SWAP( self, target_qbits, target_qbit2=-1):
        # Ensure target_qbits is a list
        if isinstance(target_qbits, (list, tuple)):
            super(qgd_Circuit, self).add_SWAP(list(target_qbits))
        if isinstance(target_qbits,int) and target_qbit2 != -1:
            super(qgd_Circuit, self).add_SWAP(list(target_qbits))

#@brief Call to add a CSWAP (Fredkin) gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbits (list of int) - target qubits (exactly 2 for standard CSWAP),
#                        control_qbits (int or list of int) - control qubit (exactly 1 for standard CSWAP).
#@note Accepts both list and single integer inputs for control_qbits. Examples:
#      add_CSWAP([0,1], 2) -> control_qbits becomes [2] (standard Fredkin gate)
#      add_CSWAP([0,1], [2]) -> control_qbits stays [2] (standard Fredkin gate)
#@note Currently only supports exactly 1 control qubit (standard Fredkin gate).

    def add_CSWAP( self, target_qbits, control_qbits):
        # Convert target_qbits to list if needed
        if not isinstance(target_qbits, (list, tuple)):
            raise TypeError("target_qbits must be a list or tuple")
        target_qbits = list(target_qbits)

        # Convert control_qbits to list if it's a single integer
        if isinstance(control_qbits, int):
            control_qbits = [control_qbits]
        elif isinstance(control_qbits, (list, tuple)):
            control_qbits = list(control_qbits)
        else:
            raise TypeError("control_qbits must be an int, list, or tuple")

	# call the C wrapper function
        super(qgd_Circuit, self).add_CSWAP(target_qbits, control_qbits)

#@brief Call to add a CCX gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbits (list of int or single int) - control qubits (at least 2).
#@note control_qbits can be a list or tuple. Example:
#      add_CCX(0, [1,2]) -> standard CCX with 2 controls

    def add_CCX( self, target_qbit, control_qbits):
        # Convert control_qbits to list if needed
        if isinstance(control_qbits, int):
            raise TypeError("control_qbits must be a list or tuple (CCX requires at least 2 control qubits)")
        elif isinstance(control_qbits, (list, tuple)):
            control_qbits = list(control_qbits)
        else:
            raise TypeError("control_qbits must be a list or tuple")

	# call the C wrapper function
        super(qgd_Circuit, self).add_CCX(target_qbit, control_qbits)

#@brief Call to add adaptive gate to the front of the gate structure.
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: target_qbit (int), control_qbit (int).

    def add_Circuit( self, gate):

	# call the C wrapper function
        super().add_Circuit(gate) 

#@brief Call to retrieve the matrix of the operation. 
#@param self A pointer pointing to an instance of the class qgd_Circuit.
#@param Input arguments: parameters_mtx.

    def get_Matrix( self, parameters_mtx):

	# call the C wrapper function
        return super().get_Matrix(parameters_mtx)


#@brief Call to get the parameters of the matrices. 
#@param self A pointer pointing to an instance of the class qgd_Circuit.

    def get_Parameter_Num( self):

	# call the C wrapper function
        return super().get_Parameter_Num()



#@brief Call to apply the gate operation on the input matrix
#@param Input arguments: parameters_mtx, unitary_mtx.
    def apply_to( self, parameters_mtx, unitary_mtx, parallel=1):

	# call the C wrapper function
        super().apply_to( parameters_mtx, unitary_mtx, parallel=parallel )



##
# @brief Call to get the second Rényi entropy
# @param parameters A float64 numpy array
# @param input_state A complex array storing the input state. If None |0> is created.
# @param qubit_list A subset of qubits for which the Rényi entropy should be calculated.
# @Return Returns with the calculated entropy
    def get_Second_Renyi_Entropy(self, parameters=None, input_state=None, qubit_list=None ):

        # validate input parameters

        qbit_num = self.get_Qbit_Num()

        qubit_list_validated = list()
        if isinstance(qubit_list, list) or isinstance(qubit_list, tuple):
            for item in qubit_list:
                if isinstance(item, int):
                    qubit_list_validated.append(item)
                    qubit_list_validated = list(set(qubit_list_validated))
                else:
                    print("Elements of qbit_list should be integers")
                    return
        elif qubit_list == None:
            qubit_list_validated = [ x for x in range(qbit_num) ]

        else:
            print("Elements of qbit_list should be integers")
            return
        

        if parameters is None:
            print( "get_Second_Renyi_entropy: array of input parameters is None")
            return None


        if input_state is None:
            matrix_size = 1 << qbit_num
            input_state = np.zeros( (matrix_size,1), dtype=np.complex128 )
            input_state[0] = 1

        # evaluate the entropy
        entropy = super().get_Second_Renyi_Entropy( parameters, input_state, qubit_list_validated)  


        return entropy



##
# @brief Call to get the number of qubits in the circuit
# @return Returns with the number of qubits
    def get_Qbit_Num(self):
    
        return super().get_Qbit_Num()


##
# @brief Call to get the list of qubits involved in the circuit
# @return Returns with the list of qubits
    def get_Qbits(self):
    
        return super().get_Qbits()


#@brief Call to set hte min fusion in the circuit
#@param Input arguments: min_fusion
    def set_min_fusion( self, min_fusion):

        super().set_min_fusion(min_fusion)

        
##
# @brief Call to get the list of gates (or subcircuits) in the circuit
# @return Returns with the list of gates
    def get_Gates(self):
    
        return super().get_Gates()  
        
        
##
# @brief Call to get statisctics on the gate counts in the circuit.
# @return Returns with the dictionary containing the gate counts
    def get_Gate_Nums(self):
    
        return super().get_Gate_Nums()                


##
# @brief Call to remap the qubits in the circuit. 
# @param qbit_map The map conatining the qbit map in a form of dict: {int(initial_qbit): int(remapped_qbit)}. 
# @param qbit_num The number of qbits in the remaped circuits (Can be different than in the original circuit) 
# @return Returns with the newly created, remapped circuit
    def Remap_Qbits(self, qbit_map, qbit_num=None):

        if qbit_num == None:
            qbit_num = self.get_Qbit_Num()


        return super().Remap_Qbits( qbit_map, qbit_num)
    



#@brief Call to get the starting index of the parameters in the parameter array corresponding to the circuit in which the current gate is incorporated.
    def get_Parameter_Start_Index( self ):

	# call the C wrapper function
        return super().get_Parameter_Start_Index()


#@brief Method to get the list of parent gate indices. Then the parent gates can be obtained from the list of gates involved in the circuit.
    def get_Parents( self, gate):

	# call the C wrapper function
        return super().get_Parents( gate )


#@brief Method to get the list of child gate indices. Then the children gates can be obtained from the list of gates involved in the circuit.
    def get_Children( self, gate):

	# call the C wrapper function
        return super().get_Children( gate )


#@brief Add a generic gate to the circuit
    def add_Gate(self,qgd_gate):


        if isinstance(qgd_gate,H):
            self.add_H(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,X):
            self.add_X(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,Y):
            self.add_Y(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,Z):
            self.add_Z(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,CH):
            self.add_CH(qgd_gate.get_Target_Qbit(),qgd_gate.get_Control_Qbit())
        elif isinstance(qgd_gate,CZ):
            self.add_CZ(qgd_gate.get_Target_Qbit(),qgd_gate.get_Control_Qbit())
        elif isinstance(qgd_gate,RX):
            self.add_RX(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,RY):
            self.add_RY(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,RZ):
            self.add_RZ(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,SX):
            self.add_SX(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,U1):
            self.add_U1(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,U2):
            self.add_U2(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,U3):
            self.add_U3(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,CRY):
            self.add_CRY(qgd_gate.get_Target_Qbit(),qgd_gate.get_Control_Qbit())
        elif isinstance(qgd_gate,CNOT):
            self.add_CNOT(qgd_gate.get_Target_Qbit(),qgd_gate.get_Control_Qbit())
        elif isinstance(qgd_gate,S):
            self.add_S(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,Sdg):
            self.add_Sdg(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,T):
            self.add_T(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,Tdg):
            self.add_Tdg(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,R):
            self.add_R(qgd_gate.get_Target_Qbit())
        elif isinstance(qgd_gate,CROT):
            self.add_CROT(qgd_gate.get_Target_Qbit(),qgd_gate.get_Control_Qbit())
        elif isinstance(qgd_gate,CR):
            self.add_CR(qgd_gate.get_Target_Qbit(),qgd_gate.get_Control_Qbit())
        elif isinstance(qgd_gate,SYC):
            self.add_SYC(qgd_gate.get_Target_Qbit(),qgd_gate.get_Control_Qbit())
        elif isinstance(qgd_gate,CRZ):
            self.add_CRZ(qgd_gate.get_Target_Qbit(),qgd_gate.get_Control_Qbit())
        elif isinstance(qgd_gate,CRX):
            self.add_CRX(qgd_gate.get_Target_Qbit(),qgd_gate.get_Control_Qbit())
        elif isinstance(qgd_gate,CP):
            self.add_CP(qgd_gate.get_Target_Qbit(),qgd_gate.get_Control_Qbit())
        elif isinstance(qgd_gate,SWAP):
            self.add_SWAP(qgd_gate.get_Target_Qbits())
        elif isinstance(qgd_gate,CSWAP):
            self.add_CSWAP(qgd_gate.get_Target_Qbits(), qgd_gate.get_Control_Qbits())
        elif isinstance(qgd_gate,CCX):
            self.add_CCX(qgd_gate.get_Target_Qbit(), qgd_gate.get_Control_Qbits())
        else:
            raise Exception("Cannot add gate: unimplemented gate type")
