"""
Blessed Posthog connector for Airbyte SDK.

Auto-generated from OpenAPI specification.
"""

from .connector import PosthogConnector

__all__ = ["PosthogConnector"]
