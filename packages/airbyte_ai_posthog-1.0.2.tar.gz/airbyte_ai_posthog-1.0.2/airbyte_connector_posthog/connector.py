"""
Auto-generated posthog connector. Do not edit manually.

Generated from OpenAPI specification.
"""

from typing import TYPE_CHECKING, Optional, Any, Dict, overload
try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal
from pathlib import Path

if TYPE_CHECKING:
    from ._vendored.connector_sdk.executor import ConnectorExecutor
    from .types import (
        ProjectsList,
        ProjectsListParams,
    )


class PosthogConnector:
    """
    Type-safe Posthog API connector.

    Auto-generated from OpenAPI specification with full type safety.
    """

    connector_name = "posthog"
    connector_version = "1.0.2"
    vendored_sdk_version = "0.1.0"  # Version of vendored connector-sdk

    def __init__(self, executor: "ConnectorExecutor"):
        """Initialize connector with an executor."""
        self._executor = executor

    @classmethod
    def create(
        cls,
        secrets: dict[str, str],
        config_path: Optional[str] = None    ) -> "PosthogConnector":
        """
        Create a new posthog connector instance.

        Args:
            secrets: API secrets/credentials
            config_path: Optional path to connector config (uses bundled default if None)
        Returns:
            Configured PosthogConnector instance
        """
        from ._vendored.connector_sdk.executor import ConnectorExecutor

        if not config_path:
            config_path = str(cls.get_default_config_path())

        executor = ConnectorExecutor(config_path=config_path, secrets=secrets)
        connector = cls(executor)

        return connector

    @classmethod
    def get_default_config_path(cls) -> Path:
        """Get path to bundled connector config."""
        return Path(__file__).parent / "connector.yaml"

    # ===== TYPED EXECUTE METHOD (Recommended Interface) =====
    @overload
    def execute(
        self,
        resource: Literal["projects"],
        verb: Literal["list"],
        params: "ProjectsListParams"
    ) -> "ProjectsList": ...

    @overload
    def execute(
        self,
        resource: str,
        verb: str,
        params: Dict[str, Any]
    ) -> Dict[str, Any]: ...

    def execute(
        self,
        resource: str,
        verb: str,
        params: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Execute a resource operation with full type safety.

        This is the recommended interface for blessed connectors as it:
        - Uses the same signature as non-blessed connectors
        - Provides full IDE autocomplete for resource/verb/params
        - Makes migration from generic to blessed connectors seamless

        Args:
            resource: Resource name (e.g., "customers")
            verb: Operation verb (e.g., "create", "retrieve", "list")
            params: Operation parameters (typed based on resource+verb)

        Returns:
            Typed response based on the operation

        Example:
            customer = connector.execute(
                resource="customers",
                verb="retrieve",
                params={"id": "cus_123"}
            )
        """
        return self._executor.execute(resource, verb, params or {})

    # ===== CONVENIENCE METHODS (Backward Compatible) =====

    def list_projects(
        self,
        **kwargs
    ) -> "ProjectsList":
        """
        List projects

        Returns:
            ProjectsList
        """
        params = {k: v for k, v in {
            **kwargs
        }.items() if v is not None}

        return self._executor.execute("projects", "list", params)