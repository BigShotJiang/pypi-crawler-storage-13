"""
Auto-generated type definitions for posthog connector.

Generated from OpenAPI specification schemas.
"""

from typing import TypedDict, NotRequired, Any

# ===== RESPONSE TYPE DEFINITIONS =====

class Project(TypedDict, total=False):
    """Project object from PostHog"""
    id: Any
    uuid: NotRequired[Any]
    name: Any
    organization: NotRequired[Any]
    created_at: NotRequired[Any]
    updated_at: NotRequired[Any]
    anonymize_ips: NotRequired[Any]
    completed_snippet_onboarding: NotRequired[Any]
    ingested_event: NotRequired[Any]
    test_account_filters: NotRequired[Any]
    slack_incoming_webhook: NotRequired[Any]

class ProjectsList(TypedDict, total=False):
    """Paginated list of projects"""
    count: NotRequired[Any]
    next: NotRequired[Any]
    previous: NotRequired[Any]
    results: NotRequired[Any]

# ===== OPERATION PARAMS TYPE DEFINITIONS =====

class ProjectsListParams(TypedDict, total=False):
    """Parameters for projects.list operation"""
    pass
