"""
Tests for Posthog blessed connector.
"""

from airbyte_connector_posthog import PosthogConnector


def test_connector_creation():
    """Test creating PosthogConnector instance."""
    connector = PosthogConnector.create(secrets={"api_key": "test_key"})
    assert connector.connector_name == "posthog"
    assert connector.connector_version


def test_connector_metadata():
    """Test connector metadata."""
    assert PosthogConnector.connector_name == "posthog"
    assert hasattr(PosthogConnector, "connector_version")


def test_default_config_path():
    """Test default config path exists."""
    config_path = PosthogConnector.get_default_config_path()
    assert config_path.exists()
    assert config_path.name == "connector.yaml"
