# Posthog Connector for Airbyte SDK

Type-safe Posthog API connector with full IDE autocomplete support.

**Version:** 1.0.2

## Installation

```bash
uv pip install airbyte-connector-posthog
```

## Usage

```python
from airbyte_connector_posthog import PosthogConnector

# Create connector
connector = PosthogConnector.create(secrets={"api_key": "your_api_key"})

# Use typed methods with full IDE autocomplete
# (See Available Operations below for all methods)
```

## Available Operations

### Projects Operations
- `list_projects()` - List projects

## Type Definitions

All response types are fully typed using TypedDict for IDE autocomplete support.
Import types from `airbyte_connector_posthog.types`.

## Documentation

Generated from OpenAPI 3.0 specification.

For API documentation, see the service's official API docs.
