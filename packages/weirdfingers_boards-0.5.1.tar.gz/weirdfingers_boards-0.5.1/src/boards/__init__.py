"""
Boards Backend SDK
Open-source creative toolkit for AI-generated content
"""

__version__ = "0.5.1"

from .config import settings

__all__ = ["settings", "__version__"]
