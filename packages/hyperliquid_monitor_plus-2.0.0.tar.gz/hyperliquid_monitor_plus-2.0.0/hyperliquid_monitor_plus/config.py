"""
Configuration management for Hyperliquid Monitor

This module handles configuration through environment variables,
making it easy to deploy in different environments without code changes.

Usage:
    from hyperliquid_monitor_plus.config import ADDRESSES, DB_PATH
    
    monitor = HyperliquidMonitor(addresses=ADDRESSES, db_path=DB_PATH)
"""

import os
from typing import List
from dotenv import load_dotenv
from hyperliquid_monitor_plus.database import init_database

# Load environment variables from .env file
load_dotenv()

# Get addresses from environment variable
# Format: MONITORED_ADDRESSES="0x123...,0x456...,0x789..."
ADDRESSES: List[str] = [
    addr.strip() 
    for addr in os.getenv("MONITORED_ADDRESSES", "").split(",") 
    if addr.strip()
]

# Initialize database and get path
# Default: "trades.db" in current directory
DB_PATH: str = init_database(os.getenv("DB_PATH", "trades.db"))

# Optional: Get other configuration from environment
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
SILENT_MODE: bool = os.getenv("SILENT_MODE", "false").lower() == "true"

# Validate configuration
if not ADDRESSES and os.getenv("MONITORED_ADDRESSES") is not None:
    raise ValueError(
        "MONITORED_ADDRESSES is set but contains no valid addresses. "
        "Format: MONITORED_ADDRESSES='0x123...,0x456...'"
    )
