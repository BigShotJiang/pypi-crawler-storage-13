"""
Hyperliquid Monitor - Fixed Version 2
A production-ready monitor for tracking whale wallet transactions on Hyperliquid DEX

This version fixes all critical bugs and compatibility issues:
- Correct side mapping (A=SELL, B=BUY)
- Proper address handling
- Support for multiple addresses
- Thread-safe database operations
- Production-ready error handling
"""

import signal
import sys
import threading
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional

from hyperliquid.info import Info
from hyperliquid.utils import constants

from hyperliquid_monitor_plus.database import TradeDatabase
from hyperliquid_monitor_plus.types import Trade, TradeCallback

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def validate_address(address: str) -> bool:
    """Validate Ethereum address format"""
    return isinstance(address, str) and len(address) == 42 and address.startswith('0x')


class HyperliquidMonitor:
    def __init__(self, 
                 addresses: List[str], 
                 db_path: Optional[str] = None,
                 callback: Optional[TradeCallback] = None,
                 silent: bool = False):
        """
        Initialize the Hyperliquid monitor.
        
        Args:
            addresses: List of addresses to monitor
            db_path: Optional path to SQLite database. If None, trades won't be stored
            callback: Optional callback function that will be called for each trade
            silent: If True, callback notifications will be suppressed even if callback is provided.
                   Useful for silent database recording. Default is False.
                   
        Note:
            Due to SDK limitations, only fills are monitored (not order updates).
            This is sufficient for whale tracking as fills represent actual executed trades.
        """
        # Validate addresses
        for addr in addresses:
            if not validate_address(addr):
                raise ValueError(f"Invalid Ethereum address format: {addr}")
        
        self.info = Info(constants.MAINNET_API_URL)
        self.addresses = addresses
        self.callback = callback if not silent else None
        self.silent = silent
        self.db = TradeDatabase(db_path) if db_path else None
        self._stop_event = threading.Event()
        self._db_lock = threading.Lock() if db_path else None
        
        if silent and not db_path:
            raise ValueError("Silent mode requires a database path to be specified")
            
    def handle_shutdown(self, signum=None, frame=None):
        """Handle shutdown signals"""
        if self._stop_event.is_set():
            sys.exit(0)
            
        logger.info("Shutting down gracefully...")
        self._stop_event.set()
        self.cleanup()
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        signal.signal(signal.SIGTERM, signal.SIG_DFL)
        sys.exit(0)
        
    def cleanup(self):
        """Clean up resources"""
        if self.db:
            if self._db_lock:
                with self._db_lock:
                    self.db.close()
            else:
                self.db.close()
            if not self.silent:
                logger.info("Database connection closed.")

    def create_fills_handler(self, address: str):
        """
        Creates an event handler specifically for userFills
        
        Note: We only use userFills subscription because:
        1. userEvents doesn't support multiple users (SDK limitation)
        2. userFills includes all necessary fill data with user address
        3. For whale tracking, fills (executed trades) are the most important data
        """
        def handle_fills(event: Dict[str, Any]) -> None:
            if self._stop_event.is_set():
                return
                
            if not isinstance(event, dict):
                logger.warning(f"Received non-dict event: {type(event)}")
                return
                
            data = event.get("data", {})
            
            # Verify this is for our address
            # userFills data includes "user" field
            event_user = data.get("user", "").lower()
            if event_user != address.lower():
                logger.debug(f"Ignoring fill for different address: {event_user}")
                return
            
            # Handle fills
            if "fills" in data:
                for fill in data["fills"]:
                    if not isinstance(fill, dict):
                        logger.warning(f"Received non-dict fill: {type(fill)}")
                        continue
                    try:
                        trade = self._process_fill(fill, address)
                        if self.db:
                            with self._db_lock:
                                self.db.store_fill(fill, address)
                        if self.callback and not self.silent:
                            self.callback(trade)
                    except Exception as e:
                        if not self.silent:
                            logger.error(f"Error processing fill: {e}", exc_info=True)
        
        return handle_fills

    def _process_fill(self, fill: Dict, address: str) -> Trade:
        """Process fill information and return Trade object"""
        # Validate required fields
        if "side" not in fill:
            raise ValueError("Fill data missing required 'side' field")
        
        timestamp = datetime.fromtimestamp(int(fill.get("time", 0)) / 1000)
        
        # FIXED: Correct side mapping (A = Ask = SELL, B = Bid = BUY)
        side = "SELL" if fill["side"] == "A" else "BUY"
        
        return Trade(
            timestamp=timestamp,
            address=address,
            coin=fill.get("coin", "Unknown"),
            side=side,
            size=float(fill.get("sz", 0)),
            price=float(fill.get("px", 0)),
            trade_type="FILL",
            direction=fill.get("dir"),
            tx_hash=fill.get("hash"),
            fee=float(fill.get("fee", 0)),
            fee_token=fill.get("feeToken"),  # Note: API uses camelCase
            start_position=float(fill.get("startPosition", 0)),
            closed_pnl=float(fill.get("closedPnl", 0))
        )
            
    def start(self) -> None:
        """Start monitoring addresses"""
        if not self.addresses:
            raise ValueError("No addresses configured to monitor")
            
        # Set up signal handlers
        signal.signal(signal.SIGINT, self.handle_shutdown)
        signal.signal(signal.SIGTERM, self.handle_shutdown)
        
        logger.info(f"Starting monitor for {len(self.addresses)} address(es)...")
        
        # Subscribe to fills for each address
        # NOTE: We only subscribe to userFills, not userEvents
        # userEvents doesn't support multiple users due to SDK limitations
        # For whale tracking, fills (actual executed trades) are the most important
        for address in self.addresses:
            fills_handler = self.create_fills_handler(address)
            
            # Subscribe to fills
            self.info.subscribe(
                {"type": "userFills", "user": address},
                fills_handler
            )
            
            logger.info(f"✅ Subscribed to fills for address: {address}")
        
        logger.info("Monitor started successfully. Waiting for fills...")
        logger.info("Note: Only fills (executed trades) are monitored, not order updates")
        
        try:
            while not self._stop_event.is_set():
                self._stop_event.wait(1)
        except KeyboardInterrupt:
            self.handle_shutdown()

    def stop(self):
        """Stop the monitor"""
        logger.info("Stopping monitor...")
        self._stop_event.set()
        self.cleanup()
