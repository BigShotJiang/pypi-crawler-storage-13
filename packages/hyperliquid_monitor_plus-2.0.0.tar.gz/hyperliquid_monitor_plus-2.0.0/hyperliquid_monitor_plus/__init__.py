"""
Hyperliquid Monitor - Production-Ready Version

A robust and reliable monitor for tracking whale wallet transactions on Hyperliquid DEX.

This version includes:
- Correct side mapping (A=SELL, B=BUY) 
- Proper address handling
- Support for multiple addresses simultaneously
- Thread-safe database operations
- Production-ready error handling and logging
- Optimized database queries with indexes
- Environment-based configuration with .env support

Author: Pezhman Hajipour
Version: 2.0.0
License: MIT
"""

__version__ = "2.0.0"
__author__ = "Pezhman Hajipour"
__license__ = "MIT"

from hyperliquid_monitor_plus.monitor import HyperliquidMonitor, validate_address
from hyperliquid_monitor_plus.database import TradeDatabase, init_database
from hyperliquid_monitor_plus.types import Trade, TradeCallback, TradeType, TradeSide

# Config is optional - users can import if needed
try:
    from hyperliquid_monitor_plus import config
except ImportError:
    config = None

__all__ = [
    "HyperliquidMonitor",
    "TradeDatabase",
    "Trade",
    "TradeCallback",
    "TradeType",
    "TradeSide",
    "validate_address",
    "init_database",
    "config",
]
