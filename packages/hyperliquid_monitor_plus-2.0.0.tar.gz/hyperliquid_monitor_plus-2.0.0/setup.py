from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

# Read requirements
requirements = (this_directory / "requirements.txt").read_text(encoding="utf-8").splitlines()

setup(
    name="hyperliquid-monitor-plus",
    version="2.0.0",
    author="Pezhman Hajipour",
    author_email="",
    description="Production-ready monitor for tracking whale wallet transactions on Hyperliquid DEX",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Pezhman5252/hyperliquid-monitor-plus",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Financial and Insurance Industry",
        "Topic :: Office/Business :: Financial :: Investment",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    keywords="hyperliquid whale tracking crypto trading monitoring dex",
    project_urls={
        "Bug Reports": "https://github.com/Pezhman5252/hyperliquid-monitor-plus/issues",
        "Source": "https://github.com/Pezhman5252/hyperliquid-monitor-plus",
    },
    include_package_data=True,
)
