"""
Example: Monitor a single whale wallet

This example shows how to monitor a single whale address and print
all their trading activity in real-time.
"""

from hyperliquid_monitor_plus import HyperliquidMonitor, Trade


def print_trade(trade: Trade):
    """Callback function to print trade information"""
    print(f"""
    ═══════════════════════════════════════
    🐋 Whale Trade Detected!
    ═══════════════════════════════════════
    Time:       {trade.timestamp}
    Address:    {trade.address[:10]}...
    Coin:       {trade.coin}
    Side:       {trade.side}
    Size:       {trade.size}
    Price:      ${trade.price:,.2f}
    Value:      ${trade.size * trade.price:,.2f}
    PnL:        ${trade.closed_pnl:,.2f}
    Fee:        {trade.fee} {trade.fee_token}
    TX Hash:    {trade.tx_hash}
    ═══════════════════════════════════════
    """)


def main():
    # Example whale address (replace with actual address)
    whale_address = "0x010461C14e146ac35Fe42271BDC1134EE31C703a"
    
    print(f"Starting monitor for whale: {whale_address}")
    print("Press Ctrl+C to stop...")
    print()
    
    # Create monitor instance
    monitor = HyperliquidMonitor(
        addresses=[whale_address],
        db_path="whale_trades.db",  # Store trades in database
        callback=print_trade         # Print each trade
    )
    
    # Start monitoring
    try:
        monitor.start()
    except KeyboardInterrupt:
        print("\n\nStopping monitor...")
        monitor.stop()
        print("Monitor stopped.")


if __name__ == "__main__":
    main()
