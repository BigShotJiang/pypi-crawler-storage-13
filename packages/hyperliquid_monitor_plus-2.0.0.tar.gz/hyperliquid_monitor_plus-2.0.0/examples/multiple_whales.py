"""
Example: Monitor multiple whale wallets simultaneously

This example shows how to track multiple whale addresses at the same time.
All trades are stored in a single database and printed in real-time.
"""

from hyperliquid_monitor_plus import HyperliquidMonitor, Trade


def print_trade(trade: Trade):
    """Callback function to print trade information with whale identification"""
    # Color code based on side
    side_emoji = "🟢" if trade.side == "BUY" else "🔴"
    
    print(f"""
{side_emoji} {trade.coin} | {trade.side} | Size: {trade.size} @ ${trade.price:,.2f}
   Whale: {trade.address[:10]}... | Value: ${trade.size * trade.price:,.2f} | PnL: ${trade.closed_pnl:,.2f}
   Time: {trade.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
    """)


def main():
    # List of whale addresses to monitor
    whale_addresses = [
        "0x010461C14e146ac35Fe42271BDC1134EE31C703a",  # Whale 1
        "0x00000000001D8d6A175f1fC0F9e4Ae0D51f68e5F",  # Whale 2
        "0x4bBa290826C253BD854121346c370a9886d1bC26",  # Whale 3
    ]
    
    print(f"🐋 Starting monitor for {len(whale_addresses)} whales...")
    print("=" * 60)
    for i, addr in enumerate(whale_addresses, 1):
        print(f"   Whale {i}: {addr}")
    print("=" * 60)
    print("\nPress Ctrl+C to stop...\n")
    
    # Create monitor instance for multiple addresses
    monitor = HyperliquidMonitor(
        addresses=whale_addresses,
        db_path="multiple_whales.db",  # All trades in one database
        callback=print_trade
    )
    
    # Start monitoring
    try:
        monitor.start()
    except KeyboardInterrupt:
        print("\n\n🛑 Stopping monitor...")
        monitor.stop()
        print("✅ Monitor stopped successfully.")


if __name__ == "__main__":
    main()
