"""
Example: Using environment-based configuration

This example shows how to use .env file for configuration,
which is the recommended approach for production deployments.

Prerequisites:
1. Create a .env file (copy from .env.example)
2. Add your wallet addresses to MONITORED_ADDRESSES
3. Run this script
"""

from hyperliquid_monitor_plus.config import ADDRESSES, DB_PATH, SILENT_MODE
from hyperliquid_monitor_plus import HyperliquidMonitor

def main():
    """Main function using environment configuration"""
    
    # Check if addresses are configured
    if not ADDRESSES:
        print("❌ No addresses configured!")
        print("Please set MONITORED_ADDRESSES in your .env file")
        print("Example: MONITORED_ADDRESSES='0x123...,0x456...'")
        return
    
    print("🔧 Configuration loaded from environment:")
    print(f"  - Monitoring {len(ADDRESSES)} address(es)")
    print(f"  - Database: {DB_PATH}")
    print(f"  - Silent mode: {SILENT_MODE}")
    print()
    
    # Create monitor using environment configuration
    monitor = HyperliquidMonitor(
        addresses=ADDRESSES,
        db_path=DB_PATH,
        callback=trade_callback,
        silent=SILENT_MODE
    )
    
    print("✅ Monitor initialized successfully")
    print("🚀 Starting to monitor whale wallets...")
    print("Press Ctrl+C to stop\n")
    
    # Start monitoring
    monitor.start()

def trade_callback(trade):
    """Callback function for trade notifications"""
    print(f"\n{'='*60}")
    print(f"🐋 Whale Trade Detected!")
    print(f"{'='*60}")
    print(f"Address:  {trade.address}")
    print(f"Side:     {trade.side}")
    print(f"Coin:     {trade.coin}")
    print(f"Size:     {trade.size:.4f}")
    print(f"Price:    ${trade.price:.4f}")
    print(f"Value:    ${trade.size * trade.price:,.2f}")
    print(f"Time:     {trade.timestamp}")
    print(f"{'='*60}\n")

if __name__ == "__main__":
    main()
