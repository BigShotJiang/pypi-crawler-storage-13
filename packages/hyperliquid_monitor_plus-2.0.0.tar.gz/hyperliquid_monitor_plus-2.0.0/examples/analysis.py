"""
Example: Analyze stored whale trading data

This example shows how to query and analyze the trading data
stored in the database by the monitor.
"""

from hyperliquid_monitor_plus import TradeDatabase


def print_statistics(stats: dict):
    """Pretty print trading statistics"""
    print("\n" + "=" * 60)
    print(f"📊 TRADING STATISTICS FOR: {stats['address'][:16]}...")
    print("=" * 60)
    print(f"\n📈 Overall Performance:")
    print(f"   Total Fills:     {stats['total_fills']}")
    print(f"   Buy Trades:      {stats['buy_count']}")
    print(f"   Sell Trades:     {stats['sell_count']}")
    print(f"   Total Volume:    ${stats['total_volume']:,.2f}")
    print(f"   Buy Volume:      ${stats['buy_volume']:,.2f}")
    print(f"   Sell Volume:     ${stats['sell_volume']:,.2f}")
    print(f"   Total PnL:       ${stats['total_pnl']:,.2f}")
    print(f"   Total Fees:      ${stats['total_fees']:,.4f}")
    
    print(f"\n🏆 Top Traded Coins:")
    for coin, count in stats['top_coins'][:5]:
        print(f"   {coin:8} - {count} trades")
    
    print(f"\n📅 Activity Period:")
    print(f"   First Trade:     {stats['first_trade']}")
    print(f"   Last Trade:      {stats['last_trade']}")
    print("=" * 60 + "\n")


def analyze_coin(db: TradeDatabase, address: str, coin: str):
    """Analyze trading for a specific coin"""
    summary = db.get_coin_summary(address, coin)
    
    print(f"\n💰 {coin} Trading Analysis:")
    print(f"   Total Trades:    {summary['total_trades']}")
    print(f"   Buy Count:       {summary['buy_count']}")
    print(f"   Sell Count:      {summary['sell_count']}")
    print(f"   Total Bought:    {summary['total_bought']:.4f}")
    print(f"   Total Sold:      {summary['total_sold']:.4f}")
    print(f"   Net Position:    {summary['net_position']:.4f}")
    print(f"   Avg Buy Price:   ${summary['avg_buy_price']:,.2f}")
    print(f"   Avg Sell Price:  ${summary['avg_sell_price']:,.2f}")
    print(f"   Total PnL:       ${summary['total_pnl']:,.2f}")


def main():
    # Connect to the database
    db = TradeDatabase("whale_trades.db")
    
    # Example whale address
    whale_address = "0x010461C14e146ac35Fe42271BDC1134EE31C703a"
    
    print("\n🔍 WHALE TRADING ANALYSIS")
    print("=" * 60)
    
    # Get overall statistics
    stats = db.get_address_statistics(whale_address)
    print_statistics(stats)
    
    # Analyze specific coins if there are any trades
    if stats['top_coins']:
        top_coin = stats['top_coins'][0][0]  # Get the most traded coin
        analyze_coin(db, whale_address, top_coin)
    
    # Get recent activity (last 60 minutes)
    print("\n⏰ Recent Activity (Last 60 minutes):")
    recent = db.get_recent_activity(minutes=60, address=whale_address)
    if recent:
        print(f"   Found {len(recent)} recent trades")
        for trade in recent[:5]:  # Show last 5
            print(f"   - {trade[3]} | {trade[4]} | {trade[5]} @ ${trade[6]:,.2f}")
    else:
        print("   No recent activity")
    
    # Get latest fills
    print(f"\n📝 Latest 10 Fills:")
    latest_fills = db.get_fills_by_address(whale_address, limit=10)
    if latest_fills:
        for fill in latest_fills:
            timestamp = fill[1]
            coin = fill[3]
            side = fill[4]
            size = fill[5]
            price = fill[6]
            print(f"   {timestamp} | {coin:8} | {side:4} | {size:8.4f} @ ${price:,.2f}")
    else:
        print("   No fills found")
    
    print("\n" + "=" * 60)
    print("✅ Analysis complete!\n")
    
    # Close database connection
    db.close()


if __name__ == "__main__":
    main()
