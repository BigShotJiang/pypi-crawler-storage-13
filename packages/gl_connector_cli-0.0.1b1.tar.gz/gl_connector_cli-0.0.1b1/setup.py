"""Setup script for Bosa Modules."""

from setuptools import setup

if __name__ == "__main__":
    setup(
        build_with_nuitka=True,
        name="gl-connector-cli-binary",
        version="0.0.1b1",
    )
