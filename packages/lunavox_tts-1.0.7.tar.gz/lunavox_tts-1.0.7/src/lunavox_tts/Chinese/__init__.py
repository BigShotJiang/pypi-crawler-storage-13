﻿"""Chinese frontend package."""

