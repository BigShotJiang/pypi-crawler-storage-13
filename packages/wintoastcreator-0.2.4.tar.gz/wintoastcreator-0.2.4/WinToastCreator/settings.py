import keyboard
import time
import winreg

def toggle_focus():
    keyboard.press_and_release('win+n')
    time.sleep(1.5)
    keyboard.press_and_release('enter')
    keyboard.press_and_release('win+n')
    time.sleep(0.5)
    print('Режим «Не беспокоить» успешно переключён!')

def enable_notify_icon_on_the_taskbar():
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", 0, winreg.KEY_SET_VALUE)
        
        winreg.SetValueEx(key, "ShowNotificationIcon", 0, winreg.REG_DWORD, 1)
        winreg.CloseKey(key)
        
        print("Иконка уведомления успешно включена")
        return True
    
    except PermissionError:
        raise PermissionError("Нет прав администратора. Запустите скрипт от имени администратора") from None
    except Exception as e:
        raise RuntimeError(f"Ошибка при включении иконки: {e}") from None

def disable_notify_icon_on_the_taskbar():
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", 0, winreg.KEY_SET_VALUE)
        
        winreg.SetValueEx(key, "ShowNotificationIcon", 0, winreg.REG_DWORD, 0)
        winreg.CloseKey(key)
        
        print("Иконка уведомления успешно отключена")
        return True

    except PermissionError:
        raise PermissionError("Нет прав администратора. Запустите скрипт от имени администратора") from None
    except Exception as e:
        raise RuntimeError(f"Ошибка при отключении иконки: {e}") from None