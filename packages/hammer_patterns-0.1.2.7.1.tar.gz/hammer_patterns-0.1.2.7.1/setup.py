from setuptools import setup, find_packages

setup(
    name="hammer_patterns",
    version="0.1.2.7.1",
    packages=find_packages(),     # <--- FIXED
    description="Fun ASCII hammer and custom patterns",
    author="Deepinder Singh",
    python_requires='>=3.6',

    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",

    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
