# Hammer Patterns

A Python package for working with hammer patterns.  
Just write hammer() and assign the size after that it show i pattern 

## Features

- Feature 1: easy to make patterns
- Feature 2: fast 
- Feature 3: Easy for the students for the dsa questions

## Installation

You can install it directly from PyPI:

```bash
pip install hammer_patterns
