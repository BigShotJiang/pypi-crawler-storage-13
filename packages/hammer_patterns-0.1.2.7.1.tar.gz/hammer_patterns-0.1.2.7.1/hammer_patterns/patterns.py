import time


def hammer():
 a = int(input("Enter the number"))
 

 for x in range(1,a+1):
    spa = a-x
    star = 2*a-1
    print(" "*spa+"*"*star)
 print("*"*a*a)
 print("*"*a*a)
 print("*"*a*a)
 print("*"*a*a)
 for x in range(a,0,-1):
      spa1 = a-x
      star1 = 2*x-1
      print(" "*spa1+"*"*star1)


def c_star():
   a = input("Enter the shape")
   n = int(input("Enter the number of prints"))
   for x in range(1,n+1):
      space = n-x
      stars = 2*x-1
      print(" "*space+a*stars)




