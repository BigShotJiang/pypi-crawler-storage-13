from __future__ import annotations

from unittest.mock import Mock

import requests

from finanfut_sdk.interact import InteractClient
from tests.helpers import DummyResponse


def _headers(_: object | None = None) -> dict[str, str]:
    return {"Authorization": "Bearer test", "Content-Type": "application/json"}


def test_interact_query_preserves_extras_envelope() -> None:
    payload = {"data": {"answer": "ok"}}
    session = Mock(spec=requests.Session)
    session.post.return_value = DummyResponse(payload)

    client = InteractClient(
        api_url="https://api.example.com", session=session, header_provider=_headers
    )

    client.query("hello", extras={"metadata": {"agent_key": "post_generator"}})

    sent_payload = session.post.call_args.kwargs["json"]
    assert sent_payload["extras"] == {"metadata": {"agent_key": "post_generator"}}
    assert "metadata" not in sent_payload


def test_interact_query_parses_complex_response_payload() -> None:
    payload = {
        "status": "success",
        "data": {
            "response": {
                "answer": {"text": "Hola"},
                "metadata": {"agent_key": "post_generator", "requested_intent": "generate"},
                "tokens_used": {
                    "prompt_tokens": 10,
                    "completion_tokens": 5,
                    "total_tokens": 15,
                },
                "actions": [
                    {"name": "publish", "payload": {"channel": "social", "status": "queued"}}
                ],
                "context_used": [{"source": "memory"}],
                "application_agent_id": "fa52d162-01fc-499a-8fa3-9c370a0fca7a",
                "intent_id": "aafc2bfb-902b-492d-909d-77ca318286d5",
                "raw_model_output": {"raw": True},
            },
            "request_id": "req-123",
        },
        "meta": {"token_usage": {"total_tokens": 20}},
    }

    session = Mock(spec=requests.Session)
    session.post.return_value = DummyResponse(payload)
    client = InteractClient(
        api_url="https://api.example.com", session=session, header_provider=_headers
    )

    response = client.query("hola")

    assert response.answer == {"text": "Hola"}
    assert response.metadata["agent_key"] == "post_generator"
    assert response.tokens and response.tokens.total_tokens == 15
    assert response.tokens_used == 15
    assert response.context_used == [{"source": "memory"}]
    assert response.application_agent_id == "fa52d162-01fc-499a-8fa3-9c370a0fca7a"
    assert response.intent_id == "aafc2bfb-902b-492d-909d-77ca318286d5"
    assert response.raw_model_output == {"raw": True}
    assert response.request_id == "req-123"
    assert response.meta == {"token_usage": {"total_tokens": 20}}
    assert response.raw["answer"] == {"text": "Hola"}
