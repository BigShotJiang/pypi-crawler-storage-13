"""Documents client implementation."""

from __future__ import annotations

import mimetypes
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import requests

from ._base import BaseApiClient, HeaderProvider
from .utils.types import (
    DocumentAnswer,
    DocumentDetail,
    DocumentFile,
    DocumentParsedResponse,
    DocumentProcessingResponse,
    DocumentRunsResponse,
    DocumentType,
    DocumentTypeDetail,
)

Payload = Dict[str, Any]


class DocumentsClient(BaseApiClient):
    """Manage the document QA pipeline and processing endpoints."""

    def __init__(
        self,
        *,
        api_url: str,
        session: Optional[requests.Session] = None,
        header_provider: HeaderProvider,
    ) -> None:
        super().__init__(api_url=api_url, session=session, header_provider=header_provider)

    def list(
        self,
        *,
        application_id: Optional[str] = None,
        status: Optional[str] = None,
        limit: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> List[DocumentFile]:
        """Return the latest documents for the current application."""

        params: Dict[str, Any] = {}
        if application_id is not None:
            params["application_id"] = application_id
        if status is not None:
            params["document_status"] = status
        if limit is not None:
            params["limit"] = limit
        payload = self._request("GET", "/api/v1/documents", params=params, timeout=timeout)
        data = self._extract_data(payload)
        if isinstance(data, list):
            return [DocumentFile.parse_obj(item) for item in data]
        if isinstance(data, dict):
            return [DocumentFile.parse_obj(data)]
        return []

    def upload(
        self,
        *,
        file_path: Optional[Union[str, Path]] = None,
        content: Optional[Union[str, bytes]] = None,
        text: Optional[str] = None,
        document_id: Optional[str] = None,
        file_name: Optional[str] = None,
        mime_type: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> DocumentDetail:
        """Upload a document either from disk, raw bytes, or pasted text."""

        files_payload: Optional[Dict[str, Any]] = None
        json_payload: Optional[Dict[str, Any]] = None

        if file_path is not None:
            path = Path(file_path)
            if not path.exists():
                raise FileNotFoundError(f"Document not found: {path}")
            resolved_name = file_name or path.name
            resolved_mime = mime_type or mimetypes.guess_type(resolved_name)[0] or "application/octet-stream"
            files_payload = {"file": (resolved_name, path.read_bytes(), resolved_mime)}
            json_payload = {"id": document_id} if document_id else None
        elif content is not None:
            raw_bytes = content.encode("utf-8") if isinstance(content, str) else content
            resolved_name = file_name or "document"
            resolved_mime = mime_type or mimetypes.guess_type(resolved_name)[0] or "application/octet-stream"
            files_payload = {"file": (resolved_name, raw_bytes, resolved_mime)}
            json_payload = {"id": document_id} if document_id else None
        elif text is not None:
            if not text.strip():
                raise ValueError("text content cannot be empty")
            json_payload = {
                "text_content": text,
                "file_name": file_name or "pasted-text.txt",
                "mime_type": mime_type or "text/plain",
            }
            if document_id:
                json_payload["id"] = document_id
        else:
            raise ValueError("file_path, content, or text must be provided")

        response = self._request(
            "POST",
            "/api/v1/documents/upload",
            json=json_payload,
            files=files_payload,
            timeout=timeout,
        )
        data = self._extract_data(response)
        return DocumentDetail.parse_obj(data)

    def get(
        self,
        document_id: str,
        *,
        include_binary: bool = False,
        timeout: Optional[float] = None,
    ) -> DocumentDetail:
        payload = self._request(
            "GET",
            f"/api/v1/documents/{document_id}",
            params={"include_binary": str(bool(include_binary)).lower()},
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return DocumentDetail.parse_obj(data)

    def delete(self, document_id: str, *, timeout: Optional[float] = None) -> None:
        self._request(
            "DELETE",
            f"/api/v1/documents/{document_id}",
            timeout=timeout,
            expect_json=False,
        )

    def ask(
        self,
        document_id: str,
        question: str,
        *,
        timeout: Optional[float] = None,
    ) -> DocumentAnswer:
        payload = self._request(
            "POST",
            f"/api/v1/documents/{document_id}/ask",
            json={"question": question},
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return DocumentAnswer.parse_obj(data)

    def process(
        self,
        document_id: str,
        *,
        reprocess: bool = False,
        timeout: Optional[float] = None,
    ) -> DocumentProcessingResponse:
        body: Payload = {"reprocess": reprocess}
        payload = self._request(
            "POST", f"/api/v1/documents/{document_id}/process", json=body, timeout=timeout
        )
        data = self._extract_data(payload)
        return DocumentProcessingResponse.parse_obj(data)

    def list_processing_runs(
        self, document_id: str, *, timeout: Optional[float] = None
    ) -> DocumentRunsResponse:
        payload = self._request(
            "GET", f"/api/v1/documents/{document_id}/runs", timeout=timeout
        )
        data = self._extract_data(payload)
        if isinstance(data, list):
            data = {"runs": data}
        return DocumentRunsResponse.parse_obj(data)

    def get_parsed(
        self, document_id: str, *, timeout: Optional[float] = None
    ) -> DocumentParsedResponse:
        payload = self._request(
            "GET", f"/api/v1/documents/{document_id}/parsed", timeout=timeout
        )
        data = self._extract_data(payload)
        if isinstance(data, dict) and "record" not in data:
            data = {"record": data}
        return DocumentParsedResponse.parse_obj(data)

    def list_types(self, *, timeout: Optional[float] = None) -> List[DocumentType]:
        payload = self._request(
            "GET", "/api/v1/documents/document-pipeline/types", timeout=timeout
        )
        data = self._extract_data(payload)
        items = (data.get("items") if isinstance(data, dict) else data) or []
        return [DocumentType.parse_obj(item) for item in items]

    def get_type(
        self, type_identifier: str, *, timeout: Optional[float] = None
    ) -> DocumentTypeDetail:
        payload = self._request(
            "GET",
            f"/api/v1/documents/document-pipeline/types/{type_identifier}",
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return DocumentTypeDetail.parse_obj(data)

