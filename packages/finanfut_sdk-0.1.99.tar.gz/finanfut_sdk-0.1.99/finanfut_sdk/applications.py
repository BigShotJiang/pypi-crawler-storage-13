"""Applications module implementation."""

from __future__ import annotations

from typing import Any, List, Optional

import requests

from ._base import BaseApiClient, HeaderProvider
from .utils.types import Application, ApplicationAgent, ApplicationAgentList


class ApplicationAgentsClient(BaseApiClient):
    """Manage application-scoped agent resources."""

    def __init__(
        self,
        *,
        api_url: str,
        session: Optional[requests.Session] = None,
        header_provider: HeaderProvider,
    ) -> None:
        super().__init__(api_url=api_url, session=session, header_provider=header_provider)

    def list(
        self, application_id: str, *, offset: int = 0, limit: int = 50, timeout: Optional[float] = None
    ) -> ApplicationAgentList:
        """Return agents configured for a specific application."""

        payload = self._request(
            "GET",
            f"/api/v1/applications/{application_id}/agents",
            params={"offset": offset, "limit": limit},
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return ApplicationAgentList.parse_obj(data)

    def get(
        self, application_id: str, application_agent_id: str, *, timeout: Optional[float] = None
    ) -> ApplicationAgent:
        """Fetch a single application agent."""

        payload = self._request(
            "GET",
            f"/api/v1/applications/{application_id}/agents/{application_agent_id}",
            timeout=timeout,
        )
        data = self._extract_data(payload)
        return ApplicationAgent.parse_obj(data)


class ApplicationsClient(BaseApiClient):
    """Manage applications linked to the account."""

    def __init__(
        self,
        *,
        api_url: str,
        session: Optional[requests.Session] = None,
        header_provider: HeaderProvider,
    ) -> None:
        super().__init__(api_url=api_url, session=session, header_provider=header_provider)
        self._agents = ApplicationAgentsClient(
            api_url=api_url, session=session, header_provider=header_provider
        )

    def list(self, *, timeout: Optional[float] = None) -> List[Application]:
        """List available applications for the API key."""

        payload = self._request("GET", "/api/v1/applications", timeout=timeout)
        data = self._extract_data(payload)
        if isinstance(data, list):
            return [Application.parse_obj(item) for item in data]
        if isinstance(data, dict):
            return [Application.parse_obj(data)]
        return []

    def get(self, application_id: str, *, timeout: Optional[float] = None) -> Application:
        """Fetch a single application by identifier."""

        payload = self._request(
            "GET", f"/api/v1/applications/{application_id}", timeout=timeout
        )
        data: Dict[str, Any] = self._extract_data(payload)
        return Application.parse_obj(data)

    @property
    def agents(self) -> ApplicationAgentsClient:
        """Access application-specific agent helpers."""

        return self._agents
