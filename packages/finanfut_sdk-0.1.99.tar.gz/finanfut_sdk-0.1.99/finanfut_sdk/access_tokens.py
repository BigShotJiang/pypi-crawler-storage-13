"""Access tokens module implementation."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import requests

from ._base import BaseApiClient, HeaderProvider
from .utils.types import AccessToken, AccessTokenCreateRequest, AccessTokenListResponse


class AccessTokensClient(BaseApiClient):
    """Manage rotating access tokens for the current account."""

    def __init__(
        self,
        *,
        api_url: str,
        session: Optional[requests.Session] = None,
        header_provider: HeaderProvider,
    ) -> None:
        super().__init__(api_url=api_url, session=session, header_provider=header_provider)

    def list(self, *, timeout: Optional[float] = None) -> AccessTokenListResponse:
        """Return all active access tokens."""

        payload = self._request("GET", "/api/v1/access-tokens", timeout=timeout)
        data = self._extract_data(payload)
        if isinstance(data, list):
            data = {"items": data}
        return AccessTokenListResponse.parse_obj(data)

    def create(
        self,
        description: Optional[str] = None,
        scopes: Optional[List[str]] = None,
        payload: Optional[Union[AccessTokenCreateRequest, Dict[str, Any]]] = None,
        *,
        timeout: Optional[float] = None,
    ) -> AccessToken:
        """Create and return a new access token descriptor."""

        if payload is not None:
            body = (
                payload.dict(exclude_none=True)
                if isinstance(payload, AccessTokenCreateRequest)
                else {k: v for k, v in dict(payload).items() if v is not None}
            )
        else:
            body = {"description": description, "scopes": scopes or []}
        api_payload = self._request(
            "POST", "/api/v1/access-tokens", json=body or None, timeout=timeout
        )
        data: Dict[str, Any] = self._extract_data(api_payload)
        return AccessToken.parse_obj(data)

    def revoke(self, token_id: str, *, timeout: Optional[float] = None) -> None:
        """Revoke an existing access token."""

        self._request(
            "DELETE", f"/api/v1/access-tokens/{token_id}", timeout=timeout, expect_json=False
        )
