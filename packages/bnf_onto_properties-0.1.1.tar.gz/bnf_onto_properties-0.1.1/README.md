# BNF Ontology properties

A simple package to get the properties of the BNF (Bibliothèque nationale de France) Ontology.
