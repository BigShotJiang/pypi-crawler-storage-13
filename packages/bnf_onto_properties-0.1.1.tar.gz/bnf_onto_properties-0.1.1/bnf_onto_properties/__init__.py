from .bnf_onto_properties import *
