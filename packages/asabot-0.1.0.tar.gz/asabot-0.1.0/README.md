# asa

一个示例 Python 库，用来演示如何打包和发布到 PyPI。

## 安装

通过 PyPI 安装时，项目名是 `asabot`：

```bash
pip install asabot
```

安装后导入名仍然是 `asa`：

```python
from asa import Bot, on_group_message, on_keyword, Event

bot = Bot(
    ws_url="ws://127.0.0.1:3001",
    http_url="http://127.0.0.1:3000",
    token="your-napcat-token",  # 也可以用环境变量 NAPCAT_TOKEN
)


@on_group_message
@on_keyword("ping", "测试")
async def handle_ping(event: Event, bot: Bot):
    # 这里处理收到的消息
    print("got message:", event.text)


bot.run()
```

## 开发

```bash
pip install -e .[dev]
pytest
```
