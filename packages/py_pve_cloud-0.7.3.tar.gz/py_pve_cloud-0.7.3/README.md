# py-pve-cloud

this is the core python library package that serves as a foundation for pve cloud.

## alembic orm

this project uses sqlalchemy + alembic integrated into the collection for management of the patroni database schema.

edit `src/orm/alchemy.py` database classes and run `alembic revision --autogenerate -m "revision description"` from the orm folder, to commit your changes into the general migrations. before you need to do a `pip install .` to get the needed orm pypi packages.

get env var auth

```bash
PVE_HOST_IP=192.168.10.200

PATRONI_PASS=$(ssh root@$PVE_HOST_IP cat /etc/pve/cloud/secrets/patroni.pass)
PROXY_IP=$(ssh root@$PVE_HOST_IP cat /etc/pve/cloud/cluster_vars.yaml | yq '.pve_haproxy_floating_ip_internal')
export PG_CONN_STR=postgresql+psycopg2://postgres:$PATRONI_PASS@$PROXY_IP:5000/pve_cloud?sslmode=disable
```
to create a new migration the database needs to be on the latest version, run `alembic upgrade head` to upgrade it.

## Releasing to pypi manually

```bash
export PYPI_TOKEN= # set pve cloud pypi account access token

rm -rf dist
python3 -m build
python3 -m twine upload dist/*
```

## Developing locally

activate your venv and simply run `pip install -e .` to install this package in edit mode. Any changes will be live.

### Watchdog TDD

run the tddog cli as described in pve_cloud tdd docs.