# 更新日誌

## [0.2.5] - 2024-11-24

### 修復
- 🐛 修復 rx.el.textarea on_change 事件處理錯誤
- 🔧 簡化事件綁定，直接傳遞值

## [0.2.4] - 2024-11-24

### 修復
- 🐛 再次確認 rx.el.textarea 修復已生效
- 🔧 新增啟動時版本顯示，方便除錯

## [0.2.3] - 2024-11-24

### 緊急修復
- 🚑 修復 rx.text_area 導致的 VarAttributeError 崩潰
- 🔧 改用原生 rx.el.textarea 確保事件處理正確

## [0.2.2] - 2024-11-24

### 修復
- 🐛 改用 rx.text_area 搭配 on_key_down 事件
- ✨ 完美支援 Enter 送出，Shift+Enter 換行
- 🔧 移除 resize 手柄保持介面整潔

## [0.2.1] - 2024-11-24

### 修復
- 🐛 改用 on_key_up 事件處理 Enter 鍵
- 🔧 移除 form 包裹，直接處理按鍵事件

## [0.2.0] - 2024-11-24

### 改進
- ✨ 改用 rx.input 取代 rx.text_area（Enter 鍵送出更可靠）
- 🔧 修改 handle_user_message 支援表單數據
- 🎯 簡化輸入體驗

## [0.1.9] - 2024-11-24

### 修復
- 🐛 修復 rows 參數類型錯誤（需要字串不是整數）

## [0.1.8] - 2024-11-24

### 修復
- 🐛 改用 rx.form 處理 Enter 鍵送出
- 🔧 修復 "Invalid event chain" 錯誤
- ✨ Enter 送出，Shift+Enter 換行

## [0.1.7] - 2024-11-24

### 修復
- 🐛 改用 JavaScript 直接處理 Enter 鍵事件
- 🔧 移除有問題的 handle_key_down 方法

## [0.1.6] - 2024-11-24

### 修復
- 🐛 修復 Enter 鍵送出功能的 AttributeError
- 🔧 正確處理 on_key_down 事件參數

## [0.1.5] - 2024-11-24

### 修復
- 🐛 修復 port 設定問題，明確指定 frontend_port=3001
- 🔧 確保服務正確啟動在 localhost:3001

## [0.1.4] - 2024-11-24

### 修復
- 🔧 改用 subprocess 方式啟動 Reflex

## [0.1.3] - 2024-11-24

### 修復
- 🐛 修復 uvx 安裝後 localhost:3001 無法訪問的問題
- 🔧 改用臨時目錄方式啟動 Reflex

## [0.1.2] - 2024-11-24

### 修復
- 🐛 簡化啟動邏輯

## [0.1.1] - 2024-11-24

### 修復
- 🐛 修復 uvx 安裝後無法啟動的問題

## [0.1.0] - 2024-11-24

### 新增
- ✨ 支援 uvx 一行指令安裝
- 📝 新增 INSTALL.md 詳細安裝指南
- 🎨 重寫 README，更強調 high functioning ADHD 的真實困境

### 修復
- 🐛 修復聊天輸入框 Enter 鍵無法送出的問題
  - 現在 Enter 送出訊息
  - Shift+Enter 換行
  - 不再需要用滑鼠點擊送出按鈕

### 改進
- 📖 README 更有同理心，減少技術術語
- 🎯 強調「你不孤單」的訊息
- 💙 更溫暖、更支持性的語氣

## [0.1.0] - 初始版本

### 功能
- 能量感知模式（高能量/低能量）
- AI 對話助手（Gemini 2.5 Flash）
- 專案掃描功能
- Zen 風格 UI 設計
- API Key 本地儲存
