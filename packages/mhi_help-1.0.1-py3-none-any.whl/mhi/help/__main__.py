"""
MHI Help - Command Line Interface
"""

import mhi.help

from mhi.help.buildtime import BUILD_TIME

def version():
    """Display package version info"""

    print(f"MHI Help Library v{mhi.help.__version__} ({BUILD_TIME})")
    print("(c) Manitoba Hydro International Ltd.")

main = mhi.help.Main(mhi.help, version)
main()
