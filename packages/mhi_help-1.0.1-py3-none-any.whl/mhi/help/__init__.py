"""
mhi.help

Root of embedded HTML help files
"""

import os
import re
import sys

from argparse import ArgumentParser, Namespace
from itertools import product
from pathlib import Path
from typing import Optional

__version__ = '1.0.1'

class Main:
    """
    Command-line trampoline
    """

    def __init__(self, package, version_func, default_func=None):

        self._package = package
        self._version_func = version_func
        self._parser = ArgumentParser(prog=f'py -m {package.__name__}')

        if default_func is None:
            if package.__name__ == 'mhi.help':
                default_func = self._open
            else:
                default_func = self._version

        self._parser.set_defaults(func=default_func)

        self._subparsers = self._parser.add_subparsers()

        self._add_open()
        self._add_version()
        self._add_release()

    def _add_open(self):

        cmd = 'open'
        subparser = self.add_parser(cmd, "Open the module's documentation",
                                    aliases=['help'])
        subparser.set_defaults(func=self._open)

    def _open(self, _args: Namespace) -> int:

        return package_help(self._package)

    def _add_version(self):

        cmd = 'version'
        subparser = self.add_parser(cmd, "Display the version info")
        subparser.set_defaults(func=self._version)

    def _version(self, _args: Namespace):

        self._version_func()

    def _add_release(self):

        cmd = 'release'
        subparser = self.add_parser(cmd, "Display the release identifier")
        subparser.set_defaults(func=self._release)

    def _release(self, _args: Namespace):
        """Display package release identifier"""

        pkg = self._package
        if hasattr(pkg, '__version__'):
            version = pkg.__version__
        else:
            version = pkg.VERSION

        print(version)

    def add_parser(self, cmd: str, cmd_help: str, **kwargs) -> ArgumentParser:
        """
        Add a subparser to the main command parser
        """

        return self._subparsers.add_parser(cmd, help=cmd_help, **kwargs)

    def __call__(self):

        args = self._parser.parse_args()
        return args.func(args)


def package_help(pkg):
    """
    Open the help of a particular package

    Parameters:
        pkg: The package to show the help from
    """

    name = pkg.__package__
    if not name.startswith('mhi.'):
        raise ValueError(f"Invalid package {name}")

    if name == 'mhi.help':
        paths = ['.']
    else:
        paths = [
            name[4:].replace('.', '-'),
            name[4:].replace('.', '/'),
            ]

    # Look for the help rooted in ...
    roots = [
        # this package's tree
        Path(__file__).parent,
        # that package's source tree
        Path(pkg.__file__).parents[name.count('.')] / 'help',
        ]

    indexes = [root / 'html' / path / 'index.html'
               for root, path in product(roots, paths)]
    for index in indexes:
        if index.is_file():
            os.startfile(index)
            break
    else:
        print(f'Help file "{indexes[0]}" not found', file=sys.stderr)
        sys.exit(1)
