#!/usr/bin/env python3
import mhi.enerplot

# Launch or Connect to the Enerplot application
enerplot = mhi.enerplot.application()

# Load the "Enerplot_Examples" workspace
enerplot.load_workspace("Enerplot_Examples", folder=enerplot.examples)

# List all books in workspace
print("Books:")
for book in enerplot.books().values():
    print("  {:10s} {}".format(book.name, book.description))
print()

# List all datafiles in workspace
print("Datafiles:")
for datafile in enerplot.datafiles().values():
    print("  {:10s} {}".format(datafile.label, datafile.filename))
print()

