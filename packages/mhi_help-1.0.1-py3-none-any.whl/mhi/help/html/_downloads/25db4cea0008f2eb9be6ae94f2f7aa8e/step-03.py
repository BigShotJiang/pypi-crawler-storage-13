#!/usr/bin/env python3
import mhi.enerplot

# Launch or Connect to the Enerplot application
enerplot = mhi.enerplot.application()

# Load the Enerplot_Examples workspace
enerplot.load_workspace("Enerplot_Examples", enerplot.examples)

# Get rid of the `notes` book.
notes = enerplot.book("notes")
notes.unload()
