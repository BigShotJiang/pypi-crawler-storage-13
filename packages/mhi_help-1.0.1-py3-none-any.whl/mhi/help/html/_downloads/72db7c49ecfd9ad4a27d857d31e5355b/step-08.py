#!/usr/bin/env python3
import mhi.enerplot

# Launch or Connect to the Enerplot application
enerplot = mhi.enerplot.application()

# Load the Enerplot_Examples workspace
enerplot.load_workspace("Enerplot_Examples", enerplot.examples)

# Get rid of the `notes` book.
notes = enerplot.book("notes")
notes.unload()

# Add a new sheet to "book1"
book1 = enerplot.book("book1")
sheet2 = book1.new_sheet("Sheet2", "Created by Python script")
sheet2.focus()

# Add a graph frame, with title and x-axis label
frame = sheet2.graph_frame(1, 1, 40, 36, title="Cigre Rectifier", xtitle="Time")

# Add Rectifier AC voltages to the graph frame's top graph
cigre = enerplot.datafile("Cigre_47.csv")
ph_a = cigre["Rectifier\\AC Voltage:1"]
ph_b = cigre["Rectifier\\AC Voltage:2"]
ph_c = cigre["Rectifier\\AC Voltage:3"]

top = frame.panel(0)
top.properties(title="Phase Voltages (kV)")
top.add_curves(ph_a, ph_b, ph_c)
top.zoom(xmax=0.15, ymax=1.0, ymin=-0.2)

# Add second graph to graph frame
bottom = frame.add_overlay_graph()
bottom.properties(title="Zero Sequence Voltage (V)")

# Create Zero Sequence channel
v_zero = [ (va+vb+vc)*1000 for va,vb,vc in zip(ph_a.data, ph_b.data, ph_c.data) ]
zero_seq = cigre.set_channel(v_zero, "Zero Sequence", "Script Output")
bottom.add_curves(zero_seq)
