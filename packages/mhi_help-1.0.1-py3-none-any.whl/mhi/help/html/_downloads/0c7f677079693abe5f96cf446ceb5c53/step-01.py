#!/usr/bin/env python3
import mhi.enerplot

# Launch or Connect to the Enerplot application
enerplot = mhi.enerplot.application()
