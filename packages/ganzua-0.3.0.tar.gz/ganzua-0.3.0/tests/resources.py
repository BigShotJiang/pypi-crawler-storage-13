import importlib.resources
import pathlib

_RESOURCES = importlib.resources.files()

# The `importlib.resources` API only guarantees the `Traversable` interface.
# This matters when resources aren't installed as actual files,
# e.g. when a Python package is installed as a Zip archive.
# However, these resources are only used during development,
# which always uses an editable install.
# So we know that these resources are ordinary file paths.
assert isinstance(_RESOURCES, pathlib.Path)  # noqa: S101  # assert

OLD_UV_LOCKFILE = _RESOURCES / "old-uv-project/uv.lock"
NEW_UV_LOCKFILE = _RESOURCES / "new-uv-project/uv.lock"
MINOR_UV_LOCKFILE = _RESOURCES / "minor-uv-project/uv.lock"
OLD_UV_PYPROJECT = _RESOURCES / "old-uv-project/pyproject.toml"
NEW_UV_PYPROJECT = _RESOURCES / "new-uv-project/pyproject.toml"
OLD_POETRY_LOCKFILE = _RESOURCES / "old-poetry-project/poetry.lock"
NEW_POETRY_LOCKFILE = _RESOURCES / "new-poetry-project/poetry.lock"
NEW_POETRY_PYPROJECT = _RESOURCES / "new-poetry-project/pyproject.toml"
SOURCES_POETRY_LOCKFILE = _RESOURCES / "sources-poetry/poetry.lock"
SOURCES_UV_LOCKFILE = _RESOURCES / "sources-uv/uv.lock"
SETUPTOOLS_DYNAMIC_VERSION_LOCKFILE = _RESOURCES / "setuptools-dynamic-version/uv.lock"

README = _RESOURCES / "../README.md"
EMPTY = pathlib.Path("/dev/null")
