import rasterio
import geopandas as gpd
import numpy as np
from shapely.geometry import shape
from skimage import measure
import torch
import os
import json
from .models.hf_model_manager import HuggingFaceModelManager

class FloodGeoAITool:
    def __init__(self, model_path=None, model_name='default', repo_id=None):
        """
        Initialize the GeoAI tool with your trained model.
        """
        # Set device first
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
        # Set Hugging Face repo if using HF models
        if repo_id is None:
            repo_id = "yourusername/flood-detection-model"
        
        self.model_manager = HuggingFaceModelManager(repo_id)
        
        if model_path:
            # Use custom model path
            self.model_path = model_path
            print(f"Using custom model: {model_path}")
        else:
            # Download from Hugging Face
            self.model_path = self.model_manager.get_model_path(model_name)
            print(f"Using pre-trained model: {model_name}")
            
        self.model = self.load_model()
        print(f"✓ Model loaded successfully")
        
    def load_model(self):
        """
        Load your trained flood detection model.
        Uses U-Net with ResNet34 encoder architecture.
        """
        try:
            # Load the model file
            model_data = torch.load(self.model_path, map_location='cpu')
            
            # Check if it's a state dictionary or complete model
            if isinstance(model_data, dict):
                print("Detected state dictionary format - loading into U-Net with ResNet34 encoder")
                # Create model with exact training architecture
                from .models.flood_model import FloodDetectionModel
                model = FloodDetectionModel(num_channels=6, num_classes=2, encoder_weights=None)
                model.load_state_dict(model_data)
            else:
                print("Detected complete model object")
                model = model_data
            
            model.eval()  # Set to evaluation mode
            return model.to(self.device)
            
        except Exception as e:
            print(f"Error loading model: {e}")
            print("Please ensure:")
            print("1. segmentation_models_pytorch is installed: pip install segmentation-models-pytorch")
            print("2. The model file is not corrupted")
            print("3. PyTorch versions are compatible")
            raise

    def preprocess_image(self, image_array):
        """
        Preprocess the satellite image to match your model's training data.
        Your model was trained on Sentinel-2 bands 2, 3, 4, 8, 11, 12.
        """
        # Normalize to [0, 1] for uint16 data (Sentinel-2)
        if image_array.dtype == np.uint16:
            image_array = image_array.astype(np.float32) / 10000.0  # Sentinel-2 scaling
        elif image_array.dtype == np.uint8:
            image_array = image_array.astype(np.float32) / 255.0
            
        # Ensure the image has the right number of bands and order
        if len(image_array.shape) == 2:  # Single band
            image_array = np.expand_dims(image_array, axis=0)
        elif len(image_array.shape) == 3:  # Multiple bands
            # Move channels to first dimension if needed (H,W,C) -> (C,H,W)
            if image_array.shape[2] <= 6:  # If channels are last
                image_array = np.moveaxis(image_array, 2, 0)
        
        return image_array

    def select_sentinel_bands(self, image_array, band_indices=[1, 2, 3, 7, 10, 11]):
        """
        Select specific Sentinel-2 bands that your model was trained on.
        Band indices: 2, 3, 4, 8, 11, 12 (0-indexed: 1, 2, 3, 7, 10, 11)
        """
        if image_array.shape[0] >= 12:  # Has at least 12 bands (full Sentinel-2)
            selected_bands = image_array[band_indices, :, :]
            print(f"Selected Sentinel-2 bands: {[i+1 for i in band_indices]}")
            return selected_bands
        elif image_array.shape[0] == 6:
            print("Image already has 6 bands - assuming correct band order")
            return image_array
        else:
            print(f"Warning: Image has {image_array.shape[0]} bands, expected 6 or 12")
            print("Using first 6 bands available")
            return image_array[:6, :, :]

    def detect_surface_water(self, image_path, confidence_threshold=0.5):
        """
        Run your trained model on the satellite image to detect water.
        Returns a binary water mask.
        """
        with rasterio.open(image_path) as src:
            # Read all bands
            image_data = src.read()
            transform = src.transform
            crs = src.crs
        
        print(f"Input image shape: {image_data.shape}")
        print(f"Image has {image_data.shape[0]} bands")
        
        # Select the specific Sentinel-2 bands your model was trained on
        processed_image = self.select_sentinel_bands(image_data)
        print(f"After band selection: {processed_image.shape}")
        
        # Preprocess the image (normalization, etc.)
        processed_image = self.preprocess_image(processed_image)
        print(f"Processed image shape: {processed_image.shape}")
        print(f"Data type: {processed_image.dtype}, Range: [{processed_image.min():.3f}, {processed_image.max():.3f}]")
        
        # Convert to tensor
        input_tensor = torch.from_numpy(processed_image).unsqueeze(0).float().to(self.device)
        print(f"Input tensor shape: {input_tensor.shape}")
        
        # Run inference
        with torch.no_grad():
            if self.model is not None:
                output = self.model(input_tensor)
                print(f"Model output shape: {output.shape}")
                
                # Handle model output - your model has 2 classes (background=0, water=1)
                if output.shape[1] == 2:  # 2-class segmentation
                    # Apply softmax and get water class (class 1)
                    probabilities = torch.softmax(output, dim=1)
                    water_probabilities = probabilities[:, 1, :, :]  # Class 1 is water
                    water_mask = (water_probabilities.squeeze().cpu().numpy() > confidence_threshold).astype(np.uint8)
                else:
                    raise ValueError(f"Unexpected number of output classes: {output.shape[1]}")
            else:
                # Fallback if model loading failed
                print("Using fallback water detection")
                water_mask = self.fallback_water_detection(processed_image)
        
        print(f"Water mask shape: {water_mask.shape}")
        print(f"Water pixels detected: {np.sum(water_mask)} ({np.sum(water_mask)/water_mask.size*100:.2f}%)")
        
        return water_mask, transform, crs

    def fallback_water_detection(self, image_data):
        """
        Simple fallback water detection using NDWI-like calculation.
        Use this only if your model fails to load.
        """
        if image_data.shape[0] >= 4:  # Has at least 4 bands
            # For Sentinel-2: band 3 (Green) and band 8 (NIR)
            green = image_data[2]  # Green band (index 2 = band 3)
            nir = image_data[3]    # NIR band (index 3 = band 8 in our selection)
        else:
            # For RGB images, use modified calculation
            green = image_data[1]  # Green band
            nir = image_data[0]    # Red band as approximation
            
        # Calculate NDWI-like index
        ndwi = (green - nir) / (green + nir + 1e-8)
        water_mask = (ndwi > 0.2).astype(np.uint8)
        
        return water_mask

    # ... (keep the rest of the methods the same: polygonize_water_mask, analyze_flood_impact, generate_risk_map, run_analysis)

    def debug_model_info(self):
        """Debug method to inspect the loaded model."""
        print("=== Model Debug Information ===")
        print(f"Model type: {type(self.model)}")
        if hasattr(self.model, 'model'):
            print(f"Model architecture: {type(self.model.model)}")
        
        print(f"Model device: {next(self.model.parameters()).device}")
        
        total_params = sum(p.numel() for p in self.model.parameters())
        print(f"Total parameters: {total_params:,}")
        
        # Test if model is callable
        try:
            test_input = torch.randn(1, 6, 256, 256).to(self.device)  # 6 channels for your model
            test_output = self.model(test_input)
            print(f"Model test successful. Input: {test_input.shape}, Output: {test_output.shape}")
        except Exception as e:
            print(f"Model test failed: {e}")