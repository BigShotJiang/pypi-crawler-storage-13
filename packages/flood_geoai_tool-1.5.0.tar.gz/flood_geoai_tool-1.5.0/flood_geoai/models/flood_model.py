# flood_geoai/models/flood_model.py
import torch
import torch.nn as nn
try:
    import segmentation_models_pytorch as smp
except ImportError:
    print("Warning: segmentation_models_pytorch not installed. Please install it with: pip install segmentation-models-pytorch")
    smp = None

class FloodDetectionModel(nn.Module):
    """
    U-Net model with ResNet34 encoder for flood detection.
    Matches the training configuration exactly.
    """
    def __init__(self, num_channels=6, num_classes=2, encoder_weights="imagenet"):
        super(FloodDetectionModel, self).__init__()
        
        if smp is None:
            raise ImportError("segmentation_models_pytorch is required. Install with: pip install segmentation-models-pytorch")
        
        # Create U-Net with ResNet34 encoder - exactly as trained
        self.model = smp.Unet(
            encoder_name="resnet34",
            encoder_weights=encoder_weights,
            in_channels=num_channels,
            classes=num_classes,
        )
    
    def forward(self, x):
        return self.model(x)