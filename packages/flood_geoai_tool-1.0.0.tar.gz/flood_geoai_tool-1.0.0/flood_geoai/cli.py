import argparse
import sys
from .core import FloodGeoAITool

def main():
    parser = argparse.ArgumentParser(description='Flood GeoAI Tool')
    
    hf_group = parser.add_argument_group('Hugging Face options')
    hf_group.add_argument('--hf-repo', default='yourusername/flood-detection-model',
                         help='Hugging Face repository ID')
    hf_group.add_argument('--model-name', default='default', 
                         help='Model variant to use')
    hf_group.add_argument('--list-models', action='store_true',
                         help='List available model variants')
    hf_group.add_argument('--search-models', action='store_true',
                         help='Search Hugging Face for flood models')
    
    model_group = parser.add_argument_group('Custom model options')
    model_group.add_argument('--model', '-m', help='Path to custom model file')
    
    analysis_group = parser.add_argument_group('Analysis options')
    analysis_group.add_argument('--image', '-i', required=True, help='Satellite image path')
    analysis_group.add_argument('--buildings', '-b', required=True, help='Building footprints path')
    analysis_group.add_argument('--output', '-o', default='./output', help='Output directory')
    analysis_group.add_argument('--confidence', '-c', type=float, default=0.5,
                               help='Confidence threshold')
    
    args = parser.parse_args()
    
    try:
        if args.search_models:
            from .models.advanced_hf_manager import AdvancedHFModelManager
            manager = AdvancedHFModelManager()
            manager.search_models("flood detection satellite")
            return
        
        if args.list_models:
            tool = FloodGeoAITool(repo_id=args.hf_repo)
            models = tool.list_models()
            print("Available models:")
            for name, info in models.items():
                print(f"  {name}: {info['description']}")
            return
        
        tool = FloodGeoAITool(
            model_path=args.model,
            model_name=args.model_name,
            repo_id=args.hf_repo
        )
        
        results = tool.run_analysis(
            satellite_image_path=args.image,
            building_footprints_path=args.buildings,
            output_dir=args.output
        )
        
        print("✓ Analysis completed successfully!")
        
    except Exception as e:
        print(f"✗ Error: {str(e)}", file=sys.stderr)
        sys.exit(1)
        