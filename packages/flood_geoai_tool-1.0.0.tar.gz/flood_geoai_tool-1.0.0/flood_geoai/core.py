import os
import torch
import rasterio
import geopandas as gpd
import numpy as np
from shapely.geometry import shape
from skimage import measure
from .models.hf_model_manager import HuggingFaceModelManager

class FloodGeoAITool:
    def __init__(self, model_path=None, model_name='default', repo_id=None):
        """
        Initialize tool with Hugging Face model support.
        """
        if repo_id is None:
            repo_id = "yourusername/flood-detection-model"
            
        self.model_manager = HuggingFaceModelManager(repo_id)
        
        if model_path:
            self.model_path = model_path
            print(f"Using custom model: {model_path}")
        else:
            self.model_path = self.model_manager.get_model_path(model_name)
            print(f"Using pre-trained model: {model_name}")
            
        self.model = self.load_model()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"✓ Model loaded successfully")
        print(f"✓ Using device: {self.device}")
    
    def load_model(self):
        """Load the model with proper error handling."""
        try:
            if not os.path.exists(self.model_path):
                raise FileNotFoundError(f"Model file not found: {self.model_path}")
            
            if self.model_path.endswith(('.pth', '.pt')):
                model = torch.load(self.model_path, map_location=self.device)
                if hasattr(model, 'eval'):
                    model.eval()
                return model
            else:
                raise ValueError("Unsupported model format")
                
        except Exception as e:
            print(f"✗ Failed to load model: {e}")
            raise
    
    def preprocess_image(self, image_array):
        """Preprocess satellite image for the model."""
        if image_array.dtype == np.uint16:
            image_array = image_array / 65535.0
        elif image_array.dtype == np.uint8:
            image_array = image_array / 255.0
            
        if len(image_array.shape) == 2:
            image_array = np.expand_dims(image_array, axis=0)
        elif len(image_array.shape) == 3:
            if image_array.shape[2] <= 4:
                image_array = np.moveaxis(image_array, 2, 0)
        
        return image_array.astype(np.float32)
    
    def detect_surface_water(self, image_path, confidence_threshold=0.5):
        """Run model inference on satellite image."""
        with rasterio.open(image_path) as src:
            image_data = src.read()
            transform = src.transform
            crs = src.crs
        
        processed_image = self.preprocess_image(image_data)
        input_tensor = torch.from_numpy(processed_image).unsqueeze(0)
        
        with torch.no_grad():
            output = self.model(input_tensor)
            
            if isinstance(output, torch.Tensor):
                if output.shape[1] == 1:
                    predictions = torch.sigmoid(output).squeeze().numpy()
                    water_mask = (predictions > confidence_threshold).astype(np.uint8)
                else:
                    predictions = torch.softmax(output, dim=1).squeeze().numpy()
                    water_mask = (np.argmax(predictions, axis=0) == 1).astype(np.uint8)
            else:
                raise ValueError("Model output format not recognized")
        
        return water_mask, transform, crs
    
    def polygonize_water_mask(self, water_mask, transform, crs, min_area=100):
        """Convert raster mask to vector polygons."""
        contours = measure.find_contours(water_mask, 0.5)
        
        polygons = []
        for contour in contours:
            coords = [rasterio.transform.xy(transform, row, col) for row, col in contour]
            polygon = shape({"type": "Polygon", "coordinates": [coords]})
            
            if polygon.area >= min_area:
                polygons.append(polygon)
        
        if polygons:
            water_gdf = gpd.GeoDataFrame({
                'id': range(len(polygons)),
                'class': ['water'] * len(polygons),
                'area_sq_m': [poly.area for poly in polygons],
                'geometry': polygons
            }, crs=crs)
            return water_gdf
        else:
            return gpd.GeoDataFrame(columns=['id', 'class', 'area_sq_m', 'geometry'], crs=crs)
    
    def analyze_flood_impact(self, water_polygons_gdf, buildings_gdf):
        """Analyze which buildings are affected by water."""
        buildings_gdf = buildings_gdf.copy()
        buildings_gdf['flood_status'] = 'dry'
        
        if water_polygons_gdf.empty:
            stats = {
                'total_buildings': len(buildings_gdf),
                'flooded_buildings': 0,
                'flooded_percentage': 0.0,
                'total_water_area': 0.0
            }
            return buildings_gdf, stats
        
        water_union = water_polygons_gdf.unary_union
        buildings_in_water_mask = buildings_gdf.geometry.intersects(water_union)
        buildings_gdf.loc[buildings_in_water_mask, 'flood_status'] = 'flooded'
        
        stats = {
            'total_buildings': len(buildings_gdf),
            'flooded_buildings': buildings_in_water_mask.sum(),
            'flooded_percentage': (buildings_in_water_mask.sum() / len(buildings_gdf)) * 100,
            'total_water_area': water_polygons_gdf.geometry.area.sum()
        }
        
        return buildings_gdf, stats
    
    def run_analysis(self, satellite_image_path, building_footprints_path, output_dir="./output"):
        """Run complete flood analysis pipeline."""
        import json
        os.makedirs(output_dir, exist_ok=True)
        
        print("Step 1: Detecting surface water...")
        water_mask, transform, crs = self.detect_surface_water(satellite_image_path)
        
        print("Step 2: Converting water mask to polygons...")
        water_polygons = self.polygonize_water_mask(water_mask, transform, crs)
        
        print("Step 3: Loading building footprints...")
        buildings = gpd.read_file(building_footprints_path)
        if buildings.crs != crs:
            buildings = buildings.to_crs(crs)
        
        print("Step 4: Analyzing flood impact...")
        buildings_with_status, stats = self.analyze_flood_impact(water_polygons, buildings)
        
        print("Step 5: Saving results...")
        if not water_polygons.empty:
            water_polygons.to_file(f"{output_dir}/detected_water.shp")
        
        buildings_with_status.to_file(f"{output_dir}/flood_risk_map.shp")
        
        if 'flood_status' in buildings_with_status.columns:
            flooded_buildings = buildings_with_status[buildings_with_status['flood_status'] == 'flooded']
            if not flooded_buildings.empty:
                flooded_buildings.to_file(f"{output_dir}/flooded_buildings.shp")
        
        with open(f"{output_dir}/statistics.json", 'w') as f:
            json.dump(stats, f, indent=2)
        
        print(f"✓ Analysis complete! {stats['flooded_buildings']} buildings flooded")
        return buildings_with_status, water_polygons, stats
    
    def list_models(self):
        """List available models."""
        return self.model_manager.list_available_models()
    
    def get_model_info(self, model_name='default'):
        """Get model information."""
        return self.model_manager.get_model_info(model_name)