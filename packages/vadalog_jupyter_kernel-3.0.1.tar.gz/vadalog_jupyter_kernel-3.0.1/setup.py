"""Setup script for vadalog-jupyter-kernel."""

from setuptools import setup

# This is a minimal setup.py for compatibility
# All configuration is in pyproject.toml
setup()

