# Vadalog Jupyter Kernel

A Jupyter kernel for executing [Vadalog](http://www.prometheux.co.uk) knowledge graph queries in JupyterLab.

## Installation

### From PyPI (Recommended)

```bash
pip install vadalog-jupyter-kernel
```

### From Source

```bash
git clone https://github.com/prometheuxresearch/vadalog-parallel.git
cd vadalog-parallel/vadalog-jupyter-kernel
pip install -e .
```

## Configuration

The kernel needs to know where your Vadalog backend is running. Default is `http://localhost:8080`.

### Option 1: Use Default Configuration

The kernel will automatically use `http://localhost:8080` if no configuration is provided.

### Option 2: Custom Configuration

Create a configuration file:

```json
{
  "vadalog_endpoint": "http://your-vadalog-server:8080"
}
```

Install the kernel with your config:

```bash
python -m vadalog_kernel.install --config /path/to/your/config.json
```

## Usage

1. Start your Vadalog backend:
   ```bash
   docker run -p 8080:8080 vadalog/vadalog-server
   ```

2. Start JupyterLab:
   ```bash
   jupyter lab
   ```

3. Create a new notebook and select the **Vadalog** kernel

4. Write Vadalog code:
   ```vadalog
   @input("person").
   person("Alice").
   person("Bob").
   
   @output("greeting").
   greeting(X, "Hello " + X) :- person(X).
   ```

5. Run the cell and see the results!

## Features

- ✅ Execute Vadalog queries
- ✅ Display results as formatted HTML tables
- ✅ Execution timing
- ✅ Error handling and reporting
- ✅ Works with [vadalog-extension](https://pypi.org/project/vadalog-extension/) for enhanced UI

## Requirements

- Python >= 3.8
- JupyterLab >= 4.0.0
- Vadalog backend server

## Recommended

Install with the JupyterLab extension for the best experience:

```bash
pip install vadalog-jupyter-kernel vadalog-extension
```

This gives you:
- Syntax highlighting
- Code linting
- Stop button integration
- Beautiful output formatting

## License

BSD 3-Clause License - see LICENSE file for details.

## About Vadalog

Vadalog is a powerful knowledge graph system developed by [Prometheux Limited](http://www.prometheux.co.uk).

## Support

- **Homepage**: http://www.prometheux.co.uk
- **Repository**: https://github.com/prometheuxresearch/vadalog-parallel
