import sqlite3
from datetime import datetime


class QueryLogger(object):
    def __init__(self, db_file):
        self.db = sqlite3.connect(db_file)
        self.db.execute("CREATE TABLE IF NOT EXISTS queries(date datetime, username text, query text, status text)")
        self.db.commit()

    def log_query(self, username, query, status):
        self.db.execute(
            'INSERT INTO queries(date, username, query, status) VALUES(?,?,?, ?)',
            (
                datetime.now(),
                username,
                query,
                status
            )
        )
        self.db.commit()
