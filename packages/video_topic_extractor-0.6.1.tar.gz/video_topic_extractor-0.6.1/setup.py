from setuptools import setup, find_packages

setup(
    name="video_topic_extractor",
    version="0.6.1",
    author="Eldar Eliyev",
    author_email="your-email@example.com",
    description="Extracts topics from lesson videos using speech recognition and NLP",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/video_topic_extractor",
    packages=find_packages(),
    install_requires=[
        "moviepy",
        "speechrecognition",
        "spacy"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
)
