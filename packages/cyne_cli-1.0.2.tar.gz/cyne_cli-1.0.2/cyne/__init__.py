"""
cyne-CLI - A powerful ReAct Python Assistant with AI capabilities
Made by Cynerza

This package provides an intelligent assistant that can:
- Think through complex problems
- Search the web for information
- Read and write files
- Execute bash commands
- Maintain conversation history
- Manage plans and tasks with progress tracking

Usage:
    cyne              # Start interactive mode
    cyne --think      # Start with think mode enabled
    cyne --test       # Run test queries
    cyne --history    # Show session history
    cyne --stats      # Show usage statistics
"""

__version__ = "1.0.2"
__author__ = "Cynerza"
__email__ = "support@cynerza.com"

from .core.agent_manager import agent_manager
from .core.session_history import session_history

__all__ = ["agent_manager", "session_history"]
