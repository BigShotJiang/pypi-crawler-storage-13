"""
Tests for telemetry and metrics collection.
"""

import json
import tempfile
import time
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from src.executor.telemetry import (EventType, LogLevel, MetricsCollector,
                                    MetricSnapshot, StructuredLogger,
                                    TelemetryEvent, TelemetryManager,
                                    configure_telemetry, get_telemetry)


class TestTelemetryEvent:
    """Tests for TelemetryEvent dataclass."""

    def test_event_creation(self):
        """Test creating a telemetry event."""
        event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.INFO,
            event_type=EventType.CACHE_HIT,
            message="Test event",
            tool_name="test_tool",
            token_cost=50
        )

        assert event.level == LogLevel.INFO
        assert event.event_type == EventType.CACHE_HIT
        assert event.message == "Test event"
        assert event.tool_name == "test_tool"
        assert event.token_cost == 50

    def test_event_to_dict(self):
        """Test converting event to dictionary."""
        event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.ERROR,
            event_type=EventType.EXECUTION_ERROR,
            message="Test error",
            error="Something went wrong",
            metadata={'details': 'test'}
        )

        data = event.to_dict()

        assert data['level'] == 'ERROR'
        assert data['event_type'] == 'execution_error'
        assert data['message'] == "Test error"
        assert data['error'] == "Something went wrong"
        assert data['metadata'] == {'details': 'test'}
        assert 'timestamp' in data

    def test_event_optional_fields(self):
        """Test event with only required fields."""
        event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.INFO,
            event_type=EventType.CACHE_HIT,
            message="Test"
        )

        data = event.to_dict()

        # Optional fields should not be in dict
        assert 'session_id' not in data
        assert 'user' not in data
        assert 'tool_name' not in data
        assert 'token_cost' not in data


class TestMetricSnapshot:
    """Tests for MetricSnapshot."""

    def test_snapshot_creation(self):
        """Test creating a metric snapshot."""
        snapshot = MetricSnapshot(timestamp=datetime.utcnow())

        assert snapshot.cache_hits == 0
        assert snapshot.cache_misses == 0
        assert snapshot.sandbox_executions == 0

    def test_cache_hit_rate_calculation(self):
        """Test cache hit rate calculation."""
        snapshot = MetricSnapshot(timestamp=datetime.utcnow())
        snapshot.cache_hits = 80
        snapshot.cache_misses = 20

        assert snapshot.cache_hit_rate() == 0.8

    def test_cache_hit_rate_no_data(self):
        """Test cache hit rate with no data."""
        snapshot = MetricSnapshot(timestamp=datetime.utcnow())

        assert snapshot.cache_hit_rate() == 0.0

    def test_generation_success_rate(self):
        """Test generation success rate calculation."""
        snapshot = MetricSnapshot(timestamp=datetime.utcnow())
        snapshot.generation_successes = 9
        snapshot.generation_failures = 1

        assert snapshot.generation_success_rate() == 0.9

    def test_avg_execution_time(self):
        """Test average execution time calculation."""
        snapshot = MetricSnapshot(timestamp=datetime.utcnow())
        snapshot.sandbox_executions = 10
        snapshot.total_execution_time_ms = 1000.0

        assert snapshot.avg_execution_time_ms() == 100.0

    def test_avg_execution_time_no_executions(self):
        """Test average execution time with no executions."""
        snapshot = MetricSnapshot(timestamp=datetime.utcnow())

        assert snapshot.avg_execution_time_ms() == 0.0


class TestStructuredLogger:
    """Tests for StructuredLogger."""

    def test_logger_creation(self):
        """Test creating a structured logger."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_file = Path(tmpdir) / "test.log"
            logger = StructuredLogger("test", log_file)

            assert logger.name == "test"
            assert log_file.exists()

    def test_log_event(self):
        """Test logging an event."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_file = Path(tmpdir) / "test.log"
            logger = StructuredLogger("test", log_file)

            event = TelemetryEvent(
                timestamp=datetime.utcnow(),
                level=LogLevel.INFO,
                event_type=EventType.CACHE_HIT,
                message="Test event"
            )

            logger.log_event(event)

            # Verify log file contains event
            log_content = log_file.read_text()
            assert "Test event" in log_content
            assert "cache_hit" in log_content


class TestMetricsCollector:
    """Tests for MetricsCollector."""

    def test_collector_creation(self):
        """Test creating a metrics collector."""
        collector = MetricsCollector()

        assert collector._current.cache_hits == 0
        assert collector._current.sandbox_executions == 0

    def test_record_cache_hit(self):
        """Test recording cache hit event."""
        collector = MetricsCollector()

        event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.INFO,
            event_type=EventType.CACHE_HIT,
            message="Cache hit",
            token_cost=50
        )

        collector.record_event(event)

        snapshot = collector.get_current_snapshot()
        assert snapshot.cache_hits == 1
        assert snapshot.total_tokens_used == 50

    def test_record_cache_miss(self):
        """Test recording cache miss event."""
        collector = MetricsCollector()

        event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.INFO,
            event_type=EventType.CACHE_MISS,
            message="Cache miss",
            token_cost=650
        )

        collector.record_event(event)

        snapshot = collector.get_current_snapshot()
        assert snapshot.cache_misses == 1
        assert snapshot.total_tokens_used == 650

    def test_record_sandbox_execution(self):
        """Test recording sandbox execution event."""
        collector = MetricsCollector()

        event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.INFO,
            event_type=EventType.SANDBOX_EXECUTION,
            message="Execution",
            duration_ms=150.5,
            memory_mb=25.0
        )

        collector.record_event(event)

        snapshot = collector.get_current_snapshot()
        assert snapshot.sandbox_executions == 1
        assert snapshot.total_execution_time_ms == 150.5
        assert snapshot.total_memory_mb == 25.0
        assert snapshot.max_memory_mb == 25.0

    def test_record_tool_generation(self):
        """Test recording tool generation events."""
        collector = MetricsCollector()

        # Success
        success_event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.INFO,
            event_type=EventType.TOOL_GENERATION_SUCCESS,
            message="Generated",
            token_cost=650
        )
        collector.record_event(success_event)

        # Failure
        failure_event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.ERROR,
            event_type=EventType.TOOL_GENERATION_FAILURE,
            message="Failed"
        )
        collector.record_event(failure_event)

        snapshot = collector.get_current_snapshot()
        assert snapshot.tools_generated == 1
        assert snapshot.generation_successes == 1
        assert snapshot.generation_failures == 1

    def test_record_errors(self):
        """Test recording error events."""
        collector = MetricsCollector()

        event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.ERROR,
            event_type=EventType.EXECUTION_ERROR,
            message="Error occurred"
        )

        collector.record_event(event)

        snapshot = collector.get_current_snapshot()
        assert snapshot.total_errors == 1

    def test_get_recent_errors(self):
        """Test retrieving recent errors."""
        collector = MetricsCollector()

        # Log some info and errors
        for i in range(5):
            info_event = TelemetryEvent(
                timestamp=datetime.utcnow(),
                level=LogLevel.INFO,
                event_type=EventType.CACHE_HIT,
                message=f"Info {i}"
            )
            collector.record_event(info_event)

            error_event = TelemetryEvent(
                timestamp=datetime.utcnow(),
                level=LogLevel.ERROR,
                event_type=EventType.EXECUTION_ERROR,
                message=f"Error {i}"
            )
            collector.record_event(error_event)

        errors = collector.get_recent_errors(limit=3)
        assert len(errors) == 3
        assert all(e.level == LogLevel.ERROR for e in errors)

    def test_session_tracking(self):
        """Test session creation and destruction tracking."""
        collector = MetricsCollector()

        # Create session
        create_event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.INFO,
            event_type=EventType.SESSION_CREATED,
            message="Session created",
            session_id="test_session"
        )
        collector.record_event(create_event)

        snapshot = collector.get_current_snapshot()
        assert snapshot.active_sessions == 1

        # Get session summary
        summary = collector.get_session_summary("test_session")
        assert summary is not None
        assert summary['session_id'] == "test_session"

        # Destroy session
        destroy_event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=LogLevel.INFO,
            event_type=EventType.SESSION_DESTROYED,
            message="Session destroyed",
            session_id="test_session"
        )
        collector.record_event(destroy_event)

        snapshot = collector.get_current_snapshot()
        assert snapshot.active_sessions == 0

    def test_recent_events_limit(self):
        """Test that recent events are limited."""
        collector = MetricsCollector()
        collector._max_events = 10  # Set small limit for test

        # Log more events than limit
        for i in range(15):
            event = TelemetryEvent(
                timestamp=datetime.utcnow(),
                level=LogLevel.INFO,
                event_type=EventType.CACHE_HIT,
                message=f"Event {i}"
            )
            collector.record_event(event)

        assert len(collector._recent_events) == 10

    def test_snapshot_persistence(self):
        """Test snapshot persistence to disk."""
        with tempfile.TemporaryDirectory() as tmpdir:
            metrics_dir = Path(tmpdir)
            collector = MetricsCollector(persist_dir=metrics_dir)

            # Record some events
            event = TelemetryEvent(
                timestamp=datetime.utcnow(),
                level=LogLevel.INFO,
                event_type=EventType.CACHE_HIT,
                message="Test"
            )
            collector.record_event(event)

            # Take snapshot
            collector.take_snapshot()

            # Verify snapshot file created
            snapshot_files = list(metrics_dir.glob("metrics_*.json"))
            assert len(snapshot_files) == 1

            # Verify content
            with open(snapshot_files[0]) as f:
                data = json.load(f)
                assert data['cache_hits'] == 1


class TestTelemetryManager:
    """Tests for TelemetryManager."""

    def test_manager_creation(self):
        """Test creating telemetry manager."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_dir = Path(tmpdir) / "logs"
            metrics_dir = Path(tmpdir) / "metrics"

            manager = TelemetryManager(
                name="test",
                log_dir=log_dir,
                metrics_dir=metrics_dir
            )

            assert manager.name == "test"
            assert log_dir.exists()
            assert metrics_dir.exists()

    def test_log_event(self):
        """Test logging event through manager."""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = TelemetryManager(
                name="test",
                log_dir=Path(tmpdir),
                metrics_dir=Path(tmpdir)
            )

            manager.log_event(
                event_type=EventType.CACHE_HIT,
                message="Test event",
                tool_name="test_tool"
            )

            # Verify metrics recorded
            stats = manager.get_stats()
            current = stats['current_metrics']
            assert current['cache_hits'] == 1

    def test_track_operation(self):
        """Test operation tracking context manager."""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = TelemetryManager(
                name="test",
                log_dir=Path(tmpdir),
                metrics_dir=Path(tmpdir)
            )

            with manager.track_operation(
                event_type=EventType.SANDBOX_EXECUTION,
                operation_name="test_op",
                tool_name="test_tool"
            ) as metadata:
                time.sleep(0.01)  # Simulate work
                metadata['result'] = 'success'

            # Verify event logged with duration
            stats = manager.get_stats()
            current = stats['current_metrics']
            assert current['sandbox_executions'] == 1
            assert current['total_execution_time_ms'] > 0

    def test_set_and_clear_context(self):
        """Test setting and clearing default context."""
        manager = TelemetryManager(name="test")

        manager.set_context(user="testuser", environment="test")
        assert manager.default_context['user'] == "testuser"
        assert manager.default_context['environment'] == "test"

        manager.clear_context()
        assert len(manager.default_context) == 0

    def test_get_stats(self):
        """Test getting comprehensive stats."""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = TelemetryManager(
                name="test",
                log_dir=Path(tmpdir),
                metrics_dir=Path(tmpdir)
            )

            # Log various events
            manager.log_event(EventType.CACHE_HIT, "Hit")
            manager.log_event(EventType.CACHE_MISS, "Miss")
            manager.log_event(EventType.TOOL_GENERATION_SUCCESS, "Success")

            stats = manager.get_stats()

            assert 'timestamp' in stats
            assert 'current_metrics' in stats
            assert 'computed_metrics' in stats
            assert 'recent_errors' in stats
            assert 'active_sessions' in stats

            current = stats['current_metrics']
            assert current['cache_hits'] == 1
            assert current['cache_misses'] == 1
            assert current['generation_successes'] == 1


class TestGlobalTelemetry:
    """Tests for global telemetry instance."""

    def test_get_telemetry_singleton(self):
        """Test that get_telemetry returns singleton."""
        t1 = get_telemetry()
        t2 = get_telemetry()

        assert t1 is t2

    def test_configure_telemetry(self):
        """Test configuring global telemetry."""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = configure_telemetry(
                name="custom",
                log_dir=Path(tmpdir),
                metrics_dir=Path(tmpdir)
            )

            assert manager.name == "custom"

            # Verify it's now the global instance
            assert get_telemetry() is manager


class TestIntegration:
    """Integration tests for telemetry system."""

    def test_complete_workflow(self):
        """Test complete telemetry workflow."""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = TelemetryManager(
                name="integration_test",
                log_dir=Path(tmpdir) / "logs",
                metrics_dir=Path(tmpdir) / "metrics"
            )

            # Simulate tool execution workflow
            session_id = "test_session_123"

            # 1. Session created
            manager.log_event(
                EventType.SESSION_CREATED,
                "Session created",
                session_id=session_id
            )

            # 2. Cache miss
            manager.log_event(
                EventType.CACHE_MISS,
                "Tool not in cache",
                tool_name="google_forms",
                token_cost=650
            )

            # 3. Tool generation success
            manager.log_event(
                EventType.TOOL_GENERATION_SUCCESS,
                "Tool generated",
                tool_name="google_forms",
                token_cost=650
            )

            # 4. Cache write
            manager.log_event(
                EventType.CACHE_WRITE,
                "Tool cached",
                tool_name="google_forms"
            )

            # 5. Sandbox execution
            manager.log_event(
                EventType.SANDBOX_EXECUTION,
                "Executed function",
                tool_name="google_forms",
                session_id=session_id,
                duration_ms=125.5,
                memory_mb=15.0
            )

            # 6. Session destroyed
            manager.log_event(
                EventType.SESSION_DESTROYED,
                "Session destroyed",
                session_id=session_id
            )

            # Verify final state
            stats = manager.get_stats()
            current = stats['current_metrics']
            computed = stats['computed_metrics']

            assert current['cache_misses'] == 1
            assert current['generation_successes'] == 1
            assert current['cache_writes'] == 1
            assert current['sandbox_executions'] == 1
            assert current['total_tokens_used'] == 1300  # 650 * 2
            assert current['active_sessions'] == 0  # Session destroyed

    def test_performance_minimal_overhead(self):
        """Test that telemetry has minimal performance overhead."""
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = TelemetryManager(
                name="perf_test",
                log_dir=Path(tmpdir) / "logs",
                metrics_dir=Path(tmpdir) / "metrics"
            )

            # Measure time to log 1000 events
            start = time.time()
            for i in range(1000):
                manager.log_event(
                    EventType.CACHE_HIT,
                    f"Event {i}",
                    tool_name="test"
                )
            duration = time.time() - start

            # Should be very fast (< 1 second for 1000 events)
            assert duration < 1.0

            # Verify all events recorded
            stats = manager.get_stats()
            assert stats['current_metrics']['cache_hits'] == 1000
