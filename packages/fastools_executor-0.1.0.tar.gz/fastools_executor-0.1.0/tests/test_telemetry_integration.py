"""
Integration tests demonstrating telemetry in coordinator.
"""

import tempfile
from pathlib import Path

import pytest

from src.executor.coordinator import Coordinator
from src.executor.sandbox import Sandbox
from src.executor.session_manager import SessionManager
from src.executor.telemetry import EventType, configure_telemetry


class TestTelemetryIntegration:
    """Integration tests for telemetry with coordinator."""

    def test_telemetry_in_coordinator(self):
        """Test that coordinator logs telemetry events."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Configure telemetry with temp dirs
            telemetry = configure_telemetry(
                name="integration_test",
                log_dir=Path(tmpdir) / "logs",
                metrics_dir=Path(tmpdir) / "metrics"
            )

            # Create coordinator (uses global telemetry)
            sandbox = Sandbox()
            session_manager = SessionManager(sandbox)
            coordinator = Coordinator(
                cache_dir=Path(tmpdir) / "cache",
                session_manager=session_manager
            )

            # Get initial stats
            initial_stats = coordinator.get_stats()
            initial_telemetry = initial_stats['telemetry']
            initial_metrics = initial_telemetry['current_metrics']

            # Verify telemetry structure
            assert 'current_metrics' in initial_telemetry
            assert 'computed_metrics' in initial_telemetry
            assert 'recent_errors' in initial_telemetry
            assert 'active_sessions' in initial_telemetry

            # Verify metrics exist
            assert 'cache_hits' in initial_metrics
            assert 'cache_misses' in initial_metrics
            assert 'sandbox_executions' in initial_metrics
            assert 'total_tokens_used' in initial_metrics

    def test_cache_hit_logging(self):
        """Test that cache hits are logged."""
        with tempfile.TemporaryDirectory() as tmpdir:
            telemetry = configure_telemetry(
                name="cache_test",
                log_dir=Path(tmpdir) / "logs",
                metrics_dir=Path(tmpdir) / "metrics"
            )

            # Log cache hit manually (simulating coordinator behavior)
            telemetry.log_event(
                event_type=EventType.CACHE_HIT,
                message="Tool loaded from cache",
                tool_name="test_tool",
                token_cost=50
            )

            # Verify metrics updated
            stats = telemetry.get_stats()
            current = stats['current_metrics']

            assert current['cache_hits'] == 1
            assert current['total_tokens_used'] == 50

            # Verify computed metrics
            computed = stats['computed_metrics']
            # With 1 hit and 0 misses, hit rate should be 1.0
            assert computed['cache_hit_rate'] == 1.0

    def test_cache_miss_and_generation(self):
        """Test cache miss and tool generation logging."""
        with tempfile.TemporaryDirectory() as tmpdir:
            telemetry = configure_telemetry(
                name="generation_test",
                log_dir=Path(tmpdir) / "logs",
                metrics_dir=Path(tmpdir) / "metrics"
            )

            # Simulate cache miss
            telemetry.log_event(
                event_type=EventType.CACHE_MISS,
                message="Tool not in cache",
                tool_name="google_forms",
                token_cost=650
            )

            # Simulate successful generation
            telemetry.log_event(
                event_type=EventType.TOOL_GENERATION_SUCCESS,
                message="Tool generated",
                tool_name="google_forms",
                token_cost=650
            )

            # Simulate cache write
            telemetry.log_event(
                event_type=EventType.CACHE_WRITE,
                message="Tool cached",
                tool_name="google_forms"
            )

            # Verify metrics
            stats = telemetry.get_stats()
            current = stats['current_metrics']

            assert current['cache_misses'] == 1
            assert current['generation_successes'] == 1
            assert current['cache_writes'] == 1
            assert current['total_tokens_used'] == 1300  # 650 * 2

            computed = stats['computed_metrics']
            assert computed['generation_success_rate'] == 1.0

    def test_sandbox_execution_logging(self):
        """Test sandbox execution metrics."""
        with tempfile.TemporaryDirectory() as tmpdir:
            telemetry = configure_telemetry(
                name="sandbox_test",
                log_dir=Path(tmpdir) / "logs",
                metrics_dir=Path(tmpdir) / "metrics"
            )

            # Log multiple executions
            for i in range(5):
                telemetry.log_event(
                    event_type=EventType.SANDBOX_EXECUTION,
                    message=f"Execution {i}",
                    tool_name="test_tool",
                    session_id="test_123",
                    duration_ms=100.0 + i * 10,
                    memory_mb=10.0 + i
                )

            # Verify metrics
            stats = telemetry.get_stats()
            current = stats['current_metrics']
            computed = stats['computed_metrics']

            assert current['sandbox_executions'] == 5
            # 100+110+120+130+140
            assert current['total_execution_time_ms'] == 600.0
            assert computed['avg_execution_time_ms'] == 120.0  # 600/5

    def test_error_tracking(self):
        """Test error event tracking."""
        with tempfile.TemporaryDirectory() as tmpdir:
            telemetry = configure_telemetry(
                name="error_test",
                log_dir=Path(tmpdir) / "logs",
                metrics_dir=Path(tmpdir) / "metrics"
            )

            # Log various errors
            from src.executor.telemetry import LogLevel

            telemetry.log_event(
                event_type=EventType.EXECUTION_ERROR,
                message="Execution failed",
                level=LogLevel.ERROR,
                error="ValueError: Invalid input"
            )

            telemetry.log_event(
                event_type=EventType.AUTH_FAILURE,
                message="Auth failed",
                level=LogLevel.ERROR,
                error="Invalid credentials"
            )

            telemetry.log_event(
                event_type=EventType.SANDBOX_VIOLATION,
                message="Security violation",
                level=LogLevel.ERROR,
                error="Attempted to import os"
            )

            # Verify metrics
            stats = telemetry.get_stats()
            current = stats['current_metrics']

            assert current['total_errors'] == 1
            assert current['auth_failures'] == 1
            assert current['sandbox_violations'] == 1

            # Verify recent errors
            recent_errors = stats['recent_errors']
            assert len(recent_errors) == 3
            assert all(e['level'] == 'ERROR' for e in recent_errors)

    def test_session_tracking(self):
        """Test session lifecycle tracking."""
        with tempfile.TemporaryDirectory() as tmpdir:
            telemetry = configure_telemetry(
                name="session_test",
                log_dir=Path(tmpdir) / "logs",
                metrics_dir=Path(tmpdir) / "metrics"
            )

            # Create session
            telemetry.log_event(
                event_type=EventType.SESSION_CREATED,
                message="Session created",
                session_id="test_session_123"
            )

            # Verify active session tracked
            stats = telemetry.get_stats()
            assert stats['current_metrics']['active_sessions'] == 1

            active_sessions = stats['active_sessions']
            assert len(active_sessions) == 1
            assert active_sessions[0]['session_id'] == "test_session_123"

            # Destroy session
            telemetry.log_event(
                event_type=EventType.SESSION_DESTROYED,
                message="Session destroyed",
                session_id="test_session_123"
            )

            # Verify session removed
            stats = telemetry.get_stats()
            assert stats['current_metrics']['active_sessions'] == 0
            assert len(stats['active_sessions']) == 0

    def test_operation_tracking(self):
        """Test tracking operations with context manager."""
        with tempfile.TemporaryDirectory() as tmpdir:
            telemetry = configure_telemetry(
                name="operation_test",
                log_dir=Path(tmpdir) / "logs",
                metrics_dir=Path(tmpdir) / "metrics"
            )

            # Track an operation
            with telemetry.track_operation(
                event_type=EventType.SANDBOX_EXECUTION,
                operation_name="test_function",
                tool_name="test_tool",
                session_id="test_123"
            ) as metadata:
                # Simulate work
                import time
                time.sleep(0.01)

                # Add result metadata
                metadata['result_size'] = 1024

            # Verify event was logged
            stats = telemetry.get_stats()
            current = stats['current_metrics']

            assert current['sandbox_executions'] == 1
            assert current['total_execution_time_ms'] > 0

    def test_complete_workflow_telemetry(self):
        """Test telemetry for a complete execution workflow."""
        with tempfile.TemporaryDirectory() as tmpdir:
            telemetry = configure_telemetry(
                name="workflow_test",
                log_dir=Path(tmpdir) / "logs",
                metrics_dir=Path(tmpdir) / "metrics"
            )

            session_id = "workflow_123"

            # 1. Session creation
            telemetry.log_event(
                EventType.SESSION_CREATED,
                "Session created",
                session_id=session_id
            )

            # 2. Cache miss (first execution)
            telemetry.log_event(
                EventType.CACHE_MISS,
                "Tool not cached",
                tool_name="google_forms",
                token_cost=650
            )

            # 3. Tool generation
            telemetry.log_event(
                EventType.TOOL_GENERATION_SUCCESS,
                "Tool generated",
                tool_name="google_forms",
                token_cost=650
            )

            # 4. Cache write
            telemetry.log_event(
                EventType.CACHE_WRITE,
                "Tool written to cache",
                tool_name="google_forms"
            )

            # 5. Sandbox execution
            telemetry.log_event(
                EventType.SANDBOX_EXECUTION,
                "Executed list_forms",
                tool_name="google_forms",
                session_id=session_id,
                duration_ms=125.5,
                memory_mb=15.0,
                token_cost=50
            )

            # 6. Second execution (cache hit)
            telemetry.log_event(
                EventType.CACHE_HIT,
                "Tool loaded from cache",
                tool_name="google_forms",
                token_cost=50
            )

            # 7. Second sandbox execution
            telemetry.log_event(
                EventType.SANDBOX_EXECUTION,
                "Executed get_form",
                tool_name="google_forms",
                session_id=session_id,
                duration_ms=110.0,
                memory_mb=12.0,
                token_cost=50
            )

            # 8. Session destruction
            telemetry.log_event(
                EventType.SESSION_DESTROYED,
                "Session destroyed",
                session_id=session_id
            )

            # Verify final state
            stats = telemetry.get_stats()
            current = stats['current_metrics']
            computed = stats['computed_metrics']

            # Cache metrics
            assert current['cache_hits'] == 1
            assert current['cache_misses'] == 1
            assert current['cache_writes'] == 1
            assert computed['cache_hit_rate'] == 0.5  # 1 hit, 1 miss

            # Generation metrics
            assert current['generation_successes'] == 1
            assert computed['generation_success_rate'] == 1.0

            # Execution metrics
            assert current['sandbox_executions'] == 2
            assert current['total_execution_time_ms'] == 235.5
            assert computed['avg_execution_time_ms'] == 117.75

            # Token metrics
            assert current['total_tokens_used'] == 1450  # 650+650+50+50+50

            # Session metrics
            assert current['active_sessions'] == 0  # Session destroyed
