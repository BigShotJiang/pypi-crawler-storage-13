"""
Executor module - compatibility layer for test imports.
Re-exports from executor module.
"""

from executor.cache import ToolCache
from executor.coordinator import Coordinator
from executor.sandbox import Sandbox


def execute_tool_function(tool_code: str, function_name: str, **kwargs):
    """
    Execute a tool function for testing purposes.

    Args:
        tool_code: Python code of the tool
        function_name: Name of function to call
        **kwargs: Arguments to pass to the function

    Returns:
        Result from function execution
    """
    # Create a temporary module and execute the tool code
    import importlib.util
    import sys
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write(tool_code)
        temp_path = f.name

    try:
        # Load module from file
        spec = importlib.util.spec_from_file_location("temp_tool", temp_path)
        if spec is None or spec.loader is None:
            return {"error": "Could not load module"}

        module = importlib.util.module_from_spec(spec)
        sys.modules["temp_tool"] = module
        spec.loader.exec_module(module)

        # Call function
        if hasattr(module, function_name):
            func = getattr(module, function_name)
            return func(**kwargs)
        else:
            return {"error": f"Function {function_name} not found"}

    finally:
        import os
        try:
            os.unlink(temp_path)
        except BaseException:
            pass
        if "temp_tool" in sys.modules:
            del sys.modules["temp_tool"]


__all__ = ["Coordinator", "Sandbox", "ToolCache", "execute_tool_function"]
