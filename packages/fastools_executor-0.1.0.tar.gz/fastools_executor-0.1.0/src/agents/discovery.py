"""
Google API Discovery Service integration for tool generation.

This module provides discovery document parsing and mapping to generate
high-fidelity Google API client code with accurate:
- Service/resource paths
- Method signatures
- Parameter schemas
- OAuth scopes
- Type hints from schemas
"""

import logging
import re
from typing import Any, Dict, List, Optional, Tuple

try:
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
except ImportError:
    # Fallback for testing/offline mode
    build = None
    HttpError = Exception

logger = logging.getLogger(__name__)


class DiscoveryDocParser:
    """
    Parser for Google API Discovery documents.

    Provides methods to:
    - Fetch discovery docs for APIs
    - Parse service structure (resources, methods)
    - Map methods to required scopes
    - Extract parameter schemas
    - Generate type hints from schemas
    """

    # Common Google API name mappings
    API_NAME_MAP = {
        "google forms": "forms",
        "forms": "forms",
        "gmail": "gmail",
        "google mail": "gmail",
        "google sheets": "sheets",
        "sheets": "sheets",
        "spreadsheets": "sheets",
        "google drive": "drive",
        "drive": "drive",
        "google calendar": "calendar",
        "calendar": "calendar",
        "youtube": "youtube",
    }

    # Discovery service cache
    _discovery_cache = {}

    def __init__(self):
        """Initialize discovery doc parser."""
        self.discovery_service = None

    def _get_api_info(self, api_description: str) -> Tuple[str, str]:
        """
        Extract API name and version from description.

        Args:
            api_description: Human-readable API description (e.g., "Google Forms API v1")

        Returns:
            Tuple of (api_name, api_version)

        Examples:
            "Google Forms API v1" -> ("forms", "v1")
            "Gmail API v1" -> ("gmail", "v1")
            "Google Sheets" -> ("sheets", "v4")
        """
        # Clean up description
        desc_lower = api_description.lower().strip()

        # Extract version
        version_match = re.search(r'v\d+', desc_lower)
        version = version_match.group(0) if version_match else None

        # Remove "API" and version from description
        name_part = desc_lower.replace(" api", "").replace("api", "")
        if version:
            name_part = name_part.replace(version, "")
        name_part = name_part.strip()

        # Map to canonical API name
        api_name = self.API_NAME_MAP.get(name_part, name_part.replace(" ", ""))

        # Default versions if not specified
        default_versions = {
            "forms": "v1",
            "gmail": "v1",
            "sheets": "v4",
            "drive": "v3",
            "calendar": "v3",
            "youtube": "v3",
        }

        if not version:
            version = default_versions.get(api_name, "v1")

        return api_name, version

    def fetch_discovery_doc(
        self,
        api_description: str,
        cached: bool = True
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch discovery document for an API.

        Args:
            api_description: Human-readable API description
            cached: Use cached discovery doc if available

        Returns:
            Discovery document dict, or None if not found

        Example:
            doc = parser.fetch_discovery_doc("Google Forms API v1")
            # Returns full discovery document with schemas, resources, methods
        """
        api_name, api_version = self._get_api_info(api_description)
        cache_key = f"{api_name}:{api_version}"

        # Check cache
        if cached and cache_key in self._discovery_cache:
            logger.info(f"Using cached discovery doc for {cache_key}")
            return self._discovery_cache[cache_key]

        try:
            logger.info(f"Fetching discovery doc: {api_name} {api_version}")

            # Build discovery service (no auth required for discovery)
            service = build(api_name, api_version, cache_discovery=False)

            # Get the discovery document
            # The service object has _rootDesc which contains the discovery doc
            if hasattr(service, '_rootDesc'):
                doc = service._rootDesc
                self._discovery_cache[cache_key] = doc
                logger.info(
                    f"✓ Fetched discovery doc for {api_name} {api_version}")
                return doc
            else:
                logger.warning(
                    f"Discovery doc not available for {api_name} {api_version}")
                return None

        except Exception as e:
            # Catch all exceptions (including HttpError if available)
            logger.error(f"Error fetching discovery doc: {e}")
            return None

    def extract_resources(
            self, discovery_doc: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract resource hierarchy from discovery document.

        Args:
            discovery_doc: Discovery document dict

        Returns:
            Dict mapping resource names to resource definitions

        Example:
            resources = parser.extract_resources(doc)
            # {'forms': {...}, 'responses': {...}}
        """
        return discovery_doc.get("resources", {})

    def extract_methods(
        self,
        discovery_doc: Dict[str, Any],
        resource_path: Optional[str] = None
    ) -> Dict[str, Dict[str, Any]]:
        """
        Extract methods from discovery document.

        Args:
            discovery_doc: Discovery document dict
            resource_path: Optional resource path (e.g., "forms.responses")

        Returns:
            Dict mapping method names to method definitions

        Example:
            methods = parser.extract_methods(doc, "forms")
            # {'list': {...}, 'get': {...}, 'create': {...}}
        """
        if resource_path:
            # Navigate to specific resource
            parts = resource_path.split(".")
            current = discovery_doc.get("resources", {})

            for part in parts:
                if part in current:
                    current = current[part]
                else:
                    return {}

            return current.get("methods", {})
        else:
            # Get top-level methods
            return discovery_doc.get("methods", {})

    def map_method_to_scopes(
        self,
        discovery_doc: Dict[str, Any],
        method_name: str,
        resource_path: Optional[str] = None
    ) -> List[str]:
        """
        Map a method to its required OAuth scopes.

        Args:
            discovery_doc: Discovery document dict
            method_name: Method name (e.g., "list", "get")
            resource_path: Optional resource path

        Returns:
            List of required OAuth scope URLs

        Example:
            scopes = parser.map_method_to_scopes(doc, "list", "forms")
            # ['https://www.googleapis.com/auth/forms.responses.readonly']
        """
        methods = self.extract_methods(discovery_doc, resource_path)

        if method_name not in methods:
            # Fall back to API-level scopes
            return discovery_doc.get(
                "auth",
                {}).get(
                "oauth2",
                {}).get(
                "scopes",
                {}).keys()

        method_def = methods[method_name]
        method_scopes = method_def.get("scopes", [])

        if method_scopes:
            return method_scopes

        # Fall back to API-level scopes
        return list(
            discovery_doc.get(
                "auth",
                {}).get(
                "oauth2",
                {}).get(
                "scopes",
                {}).keys())

    def get_minimal_scope(
        self,
        discovery_doc: Dict[str, Any],
        method_name: str,
        resource_path: Optional[str] = None,
        readonly: bool = True
    ) -> str:
        """
        Get the minimal required scope for a method.

        Args:
            discovery_doc: Discovery document dict
            method_name: Method name
            resource_path: Optional resource path
            readonly: Prefer readonly scopes if available

        Returns:
            Minimal OAuth scope URL

        Example:
            scope = parser.get_minimal_scope(doc, "list", "forms", readonly=True)
            # 'https://www.googleapis.com/auth/forms.responses.readonly'
        """
        scopes = self.map_method_to_scopes(
            discovery_doc, method_name, resource_path)

        if not scopes:
            # No scopes defined, return a sensible default
            api_name = discovery_doc.get("name", "unknown")
            return f"https://www.googleapis.com/auth/{api_name}.readonly"

        # If readonly preferred, find readonly scope
        if readonly:
            readonly_scopes = [s for s in scopes if "readonly" in s.lower()]
            if readonly_scopes:
                return readonly_scopes[0]

        # Return first (usually most permissive) scope
        return scopes[0]

    def extract_parameter_schema(
        self,
        discovery_doc: Dict[str, Any],
        method_name: str,
        resource_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Extract parameter schema for a method.

        Args:
            discovery_doc: Discovery document dict
            method_name: Method name
            resource_path: Optional resource path

        Returns:
            Dict mapping parameter names to parameter definitions

        Example:
            params = parser.extract_parameter_schema(doc, "list", "forms")
            # {'pageSize': {'type': 'integer', 'maximum': 100, ...}, ...}
        """
        methods = self.extract_methods(discovery_doc, resource_path)

        if method_name not in methods:
            return {}

        return methods[method_name].get("parameters", {})

    def schema_to_python_type(self, schema: Dict[str, Any]) -> str:
        """
        Convert JSON schema type to Python type hint.

        Args:
            schema: Parameter schema definition

        Returns:
            Python type hint string

        Example:
            type_hint = parser.schema_to_python_type({'type': 'integer'})
            # 'int'

            type_hint = parser.schema_to_python_type({'type': 'array', 'items': {'type': 'string'}})
            # 'List[str]'
        """
        schema_type = schema.get("type", "string")

        # Map JSON schema types to Python types
        type_map = {
            "string": "str",
            "integer": "int",
            "number": "float",
            "boolean": "bool",
            "object": "Dict[str, Any]",
            "array": "List[Any]",
            "null": "None",
        }

        base_type = type_map.get(schema_type, "Any")

        # Handle arrays with item type
        if schema_type == "array" and "items" in schema:
            item_type = self.schema_to_python_type(schema["items"])
            return f"List[{item_type}]"

        return base_type

    def generate_method_signature(
        self,
        discovery_doc: Dict[str, Any],
        method_name: str,
        resource_path: Optional[str] = None,
        function_name: Optional[str] = None
    ) -> Tuple[str, List[Tuple[str, str, Any]]]:
        """
        Generate method signature with type hints from discovery doc.

        Args:
            discovery_doc: Discovery document dict
            method_name: Method name
            resource_path: Optional resource path
            function_name: Optional custom function name

        Returns:
            Tuple of (signature string, list of (param_name, type_hint, default))

        Example:
            sig, params = parser.generate_method_signature(doc, "list", "forms")
            # ("list_forms(page_size: int = 100) -> Dict[str, Any]",
            #  [("page_size", "int", 100)])
        """
        params_schema = self.extract_parameter_schema(
            discovery_doc, method_name, resource_path)

        # Build parameter list
        params = []
        for param_name, param_def in params_schema.items():
            type_hint = self.schema_to_python_type(param_def)
            default = param_def.get("default")
            required = param_def.get("required", False)

            # Convert to Python naming convention
            py_param_name = param_name.replace(".", "_")

            if not required and default is None:
                # Optional parameter
                if type_hint != "None":
                    type_hint = f"Optional[{type_hint}]"
                default = None

            params.append((py_param_name, type_hint, default))

        # Generate function name
        if not function_name:
            api_name = discovery_doc.get("name", "api")
            if resource_path:
                function_name = f"{method_name}_{
                    resource_path.replace(
                        '.', '_')}"
            else:
                function_name = f"{method_name}_{api_name}"

        # Build signature
        param_strs = []
        for name, type_hint, default in params:
            if default is not None:
                if isinstance(default, str):
                    param_strs.append(f"{name}: {type_hint} = '{default}'")
                else:
                    param_strs.append(f"{name}: {type_hint} = {default}")
            else:
                param_strs.append(f"{name}: {type_hint}")

        signature = f"{function_name}({', '.join(param_strs)}) -> Dict[str, Any]"

        return signature, params

    def get_service_path(
        self,
        discovery_doc: Dict[str, Any],
        resource_path: Optional[str] = None
    ) -> str:
        """
        Get the Python code path for building a service.

        Args:
            discovery_doc: Discovery document dict
            resource_path: Optional resource path

        Returns:
            Python code string for accessing the resource

        Example:
            path = parser.get_service_path(doc, "forms.responses")
            # "service.forms().responses()"
        """
        if not resource_path:
            return "service"

        parts = resource_path.split(".")
        path_parts = [f"{part}()" for part in parts]

        return f"service.{'.'.join(path_parts)}"

    def extract_api_metadata(
            self, discovery_doc: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract metadata from discovery document.

        Args:
            discovery_doc: Discovery document dict

        Returns:
            Dict with API metadata

        Example:
            metadata = parser.extract_api_metadata(doc)
            # {'name': 'forms', 'version': 'v1', 'title': 'Google Forms API', ...}
        """
        return {
            "name": discovery_doc.get(
                "name", "unknown"), "version": discovery_doc.get(
                "version", "v1"), "title": discovery_doc.get(
                "title", "Unknown API"), "description": discovery_doc.get(
                    "description", ""), "docs_url": discovery_doc.get(
                        "documentationLink", ""), "base_url": discovery_doc.get(
                            "baseUrl", ""), "root_url": discovery_doc.get(
                                "rootUrl", ""), "service_path": discovery_doc.get(
                                    "servicePath", ""), "batch_path": discovery_doc.get(
                                        "batchPath", ""), "scopes": list(
                                            discovery_doc.get(
                                                "auth", {}).get(
                                                    "oauth2", {}).get(
                                                        "scopes", {}).keys()), }
