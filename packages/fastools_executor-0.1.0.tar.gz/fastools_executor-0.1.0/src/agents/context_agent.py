"""
Context Agent - On-demand tool generation with WebSearch/WebFetch research.

This module implements User Story 2: Generate New Tool On-Demand (Context Agent).
It handles research, code generation, validation, and caching of new tools.
"""

import ast
import json
import logging
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from research import (ConfigManager, FallbackAdapter, ResearchAdapter,
                      create_adapter)

from .discovery import DiscoveryDocParser
from .validator import ToolValidator

# Setup logging
logger = logging.getLogger(__name__)


def build_agent_request(
    tool_name: str,
    api_description: str,
    user_intent: str,
    timeout_seconds: int = 60,
    validation_required: bool = True,
    retry_context: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Build agent request following agent-protocol.md contract.

    Args:
        tool_name: Service identifier (e.g., "google_forms")
        api_description: Human-readable API name and version
        user_intent: What operation user wants to perform
        timeout_seconds: Max time for complete generation cycle
        validation_required: Whether to validate tool before returning
        retry_context: Previous error details if this is a retry

    Returns:
        dict: Agent request following contract specification
    """
    return {
        "request_type": "generate_tool",
        "request_id": str(uuid.uuid4()),
        "tool_name": tool_name,
        "api_description": api_description,
        "user_intent": user_intent,
        "timeout_seconds": timeout_seconds,
        "validation_required": validation_required,
        "retry_context": retry_context
    }


class ContextAgent:
    """
    Context agent for on-demand tool generation.

    Features:
    - Research phase: WebSearch + WebFetch for API documentation (≤7s)
    - Generation phase: Create tool code following tool-schema.md (≤1s)
    - Validation phase: Syntax, imports, test execution (≤2s)
    - Retry logic: Max 3 attempts with backoff (0s, 1s, 2s)
    - Token absorption: ~630 tokens absorbed, ~120 returned to parent
    """

    # Token costs for research (absorbed by agent)
    TOKEN_COST_WEB_SEARCH = 200
    TOKEN_COST_WEB_FETCH = 300
    TOKEN_COST_ANALYSIS = 100
    TOKEN_COST_GENERATION = 100
    TOKEN_COST_VALIDATION = 50

    def __init__(
        self,
        web_search_fn=None,
        web_fetch_fn=None,
        research_adapter: Optional[ResearchAdapter] = None,
        config_manager: Optional[ConfigManager] = None
    ):
        """
        Initialize context agent.

        Args:
            web_search_fn: Optional WebSearch function (for testing/legacy)
            web_fetch_fn: Optional WebFetch function (for testing/legacy)
            research_adapter: Optional research adapter (will auto-create if not provided)
            config_manager: Optional config manager for adapter creation
        """
        self.validator = ToolValidator()
        self.web_search = web_search_fn
        self.web_fetch = web_fetch_fn
        self.discovery_parser = DiscoveryDocParser()

        # Initialize research adapter
        if research_adapter:
            self.research_adapter = research_adapter
        else:
            # Try to create configured adapter, fall back to FallbackAdapter if
            # needed
            try:
                self.research_adapter = create_adapter(
                    config_manager=config_manager)
                logger.info(
                    f"Using research adapter: {
                        self.research_adapter.provider_name}")
            except Exception as e:
                logger.warning(
                    f"Failed to create research adapter: {e}. Using fallback.")
                from research.base import ResearchConfig
                self.research_adapter = FallbackAdapter(ResearchConfig())

    def generate_tool(
        self,
        tool_name: str,
        api_description: str,
        user_intent: str,
        timeout_seconds: int = 60,
        validation_required: bool = True,
        retry_context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Generate a tool on-demand with research and validation.

        Args:
            tool_name: Service identifier (e.g., "google_forms")
            api_description: Human-readable API name and version
            user_intent: What operation user wants to perform
            timeout_seconds: Max time for complete generation cycle
            validation_required: Whether to validate tool before returning
            retry_context: Previous error details if this is a retry

        Returns:
            dict: Success response with tool_code and metadata, or error response
        """
        start_time = time.time()
        request_id = str(uuid.uuid4())

        logger.info(f"[{request_id}] Generating tool: {tool_name}")
        logger.info(f"  API: {api_description}")
        logger.info(f"  Intent: {user_intent}")

        # Determine attempt number from retry context
        attempt_number = 1
        if retry_context:
            attempt_number = retry_context.get("attempt_number", 1)

        # Retry with backoff
        for attempt in range(attempt_number, 4):  # Max 3 attempts
            try:
                # Apply backoff delay on retries
                if attempt > 1:
                    backoff_delay = attempt - 1  # 0s, 1s, 2s
                    logger.info(
                        f"[{request_id}] Retry attempt {attempt}, backoff: {backoff_delay}s")
                    time.sleep(backoff_delay)

                # Phase 1: Research (≤7s)
                research_start = time.time()
                api_details, docs_url = self._research_phase(
                    api_description=api_description,
                    user_intent=user_intent,
                    retry_context=retry_context
                )
                research_time = time.time() - research_start

                if research_time > 7:
                    logger.warning(
                        f"[{request_id}] Research took {research_time:.2f}s (target: ≤7s)")

                # Phase 2: Code Generation (≤1s)
                gen_start = time.time()
                tool_code, functions = self._generation_phase(
                    tool_name=tool_name,
                    api_details=api_details,
                    docs_url=docs_url,
                    user_intent=user_intent
                )
                gen_time = time.time() - gen_start

                if gen_time > 1:
                    logger.warning(
                        f"[{request_id}] Generation took {gen_time:.2f}s (target: ≤1s)")

                # Phase 3: Validation (≤2s)
                if validation_required:
                    val_start = time.time()
                    validation_result = self.validator.validate_tool(
                        tool_code=tool_code,
                        tool_name=tool_name
                    )
                    val_time = time.time() - val_start

                    if val_time > 2:
                        logger.warning(
                            f"[{request_id}] Validation took {val_time:.2f}s (target: ≤2s)")

                    if not validation_result["syntax_check"] == "passed":
                        # Validation failed - retry if attempts remain
                        if attempt < 3:
                            retry_context = {
                                "attempt_number": attempt + 1,
                                "previous_error": "validation_failed",
                                "error_details": validation_result.get(
                                    "error",
                                    "Syntax check failed"),
                                "previous_code": tool_code,
                                "suggested_fix": "Fix syntax errors"}
                            continue
                        else:
                            # Max retries reached
                            return self._error_response(
                                request_id=request_id,
                                error_type="validation_failed",
                                message=validation_result.get(
                                    "error",
                                    "Validation failed after 3 attempts"),
                                details={
                                    "tool_name": tool_name,
                                    "validation_result": validation_result,
                                    "attempt_count": attempt},
                                retry_recommended=False)
                else:
                    validation_result = {
                        "syntax_check": "skipped",
                        "test_execution": "skipped",
                        "test_output": "Validation not required"
                    }

                # Success! Build response
                generation_time = time.time() - start_time

                logger.info(
                    f"[{request_id}] ✓ Tool generated successfully in {generation_time:.2f}s")

                # Calculate token absorption
                tokens_absorbed = (
                    self.TOKEN_COST_WEB_SEARCH +
                    self.TOKEN_COST_WEB_FETCH +
                    self.TOKEN_COST_ANALYSIS +
                    self.TOKEN_COST_GENERATION +
                    self.TOKEN_COST_VALIDATION
                )

                return {
                    "status": "success",
                    "request_id": request_id,
                    "tool_code": tool_code,
                    "metadata": {
                        "tool_name": tool_name,
                        "api_name": api_details.get("name", api_description),
                        "api_version": api_details.get("version", "v1"),
                        "docs_url": docs_url,
                        "functions": functions,
                        "generated_at": datetime.now(timezone.utc).isoformat()
                    },
                    "generation_time": generation_time,
                    "research_stats": {
                        "web_searches": 1,  # One search per generation
                        "web_fetches": 1,   # One fetch per generation
                        "tokens_absorbed": tokens_absorbed
                    },
                    "validation_result": validation_result
                }

            except Exception as e:
                logger.error(f"[{request_id}] Error in attempt {attempt}: {e}")

                # If this is the last attempt, return error
                if attempt >= 3:
                    return self._error_response(
                        request_id=request_id,
                        error_type="generation_failed",
                        message=f"Tool generation failed after 3 attempts: {
                            str(e)}",
                        details={
                            "tool_name": tool_name,
                            "api_description": api_description,
                            "attempt_count": attempt,
                            "error": str(e)},
                        retry_recommended=False)

                # Prepare retry context for next attempt
                retry_context = {
                    "attempt_number": attempt + 1,
                    "previous_error": "generation_failed",
                    "error_details": str(e),
                    "suggested_fix": "Adjust generation parameters"
                }

        # Should never reach here, but just in case
        return self._error_response(
            request_id=request_id,
            error_type="generation_failed",
            message="Tool generation failed: max retries exceeded",
            details={"tool_name": tool_name},
            retry_recommended=False
        )

    def _research_phase(
        self,
        api_description: str,
        user_intent: str,
        retry_context: Optional[Dict[str, Any]] = None
    ) -> Tuple[Dict[str, Any], str]:
        """
        Research phase: Use research adapter for API documentation.

        Args:
            api_description: Human-readable API name and version
            user_intent: What operation user wants to perform
            retry_context: Previous error details if this is a retry

        Returns:
            tuple: (api_details dict, docs_url string)

        Target: ≤7s
        """
        logger.info(f"  Research: {api_description}")

        # Build search query
        query = f"{api_description} API documentation {user_intent}"

        # Use research adapter
        result = self.research_adapter.search(query)

        if result.success:
            # Extract API details from research result
            api_details = self._parse_research_result(result, api_description)
            docs_url = result.data.get("docs_url", "") if result.data else ""

            # If no docs URL in result, construct one
            if not docs_url:
                docs_url = self._construct_docs_url(api_description)

            return api_details, docs_url
        else:
            # Research failed, use fallback
            logger.warning(
                f"Research failed: {
                    result.error}. Using fallback data.")
            return self._fallback_research(api_description, user_intent)

    def _parse_research_result(
        self,
        result,
        api_description: str
    ) -> Dict[str, Any]:
        """
        Parse research result into API details.

        Args:
            result: ResearchResult from adapter
            api_description: Original API description

        Returns:
            Dict with API details
        """
        # Extract name and version
        match = re.match(r"(.+?)\s+API\s+(v\d+)", api_description)
        if match:
            api_name = match.group(1)
            api_version = match.group(2)
        else:
            api_name = api_description
            api_version = "v1"

        # Get data from result
        data = result.data or {}

        # Build api_details from research result
        api_details = {
            "name": data.get("api_name", api_name),
            "version": data.get("api_version", api_version),
            "endpoints": data.get("endpoints", []),
            "authentication": "oauth2",
            "scopes": data.get("scopes", []),
            "response_format": "json",
            "research_content": data.get("content", "")
        }

        return api_details

    def _fallback_research(
        self,
        api_description: str,
        user_intent: str
    ) -> Tuple[Dict[str, Any], str]:
        """
        Fallback research when adapter fails.

        Args:
            api_description: API description
            user_intent: User intent

        Returns:
            tuple: (api_details, docs_url)
        """
        # Extract API name and version
        match = re.match(r"(.+?)\s+API\s+(v\d+)", api_description)
        if match:
            api_name = match.group(1)
            api_version = match.group(2)
        else:
            api_name = api_description
            api_version = "v1"

        # Construct minimal API details
        api_details = {
            "name": api_name,
            "version": api_version,
            "endpoints": [],
            "authentication": "oauth2",
            "scopes": [],
            "response_format": "json"
        }

        docs_url = self._construct_docs_url(api_description)

        return api_details, docs_url

    def _construct_docs_url(self, api_description: str) -> str:
        """
        Construct documentation URL from API description.

        Args:
            api_description: API description

        Returns:
            Documentation URL
        """
        # Extract version
        version_match = re.search(r'v\d+', api_description.lower())
        version = version_match.group(0) if version_match else "v1"

        # Check for Google APIs
        if "google" in api_description.lower() or "gmail" in api_description.lower():
            # Extract service name
            api_lower = api_description.lower()
            service_name = api_lower.replace(
                "google ",
                "").replace(
                " api",
                "").replace(
                " ",
                "")
            return f"https://developers.google.com/{service_name}/api/reference/rest/{version}"
        else:
            # Generic URL
            service = api_description.lower().replace(" api", "").replace(" ", "-")
            return f"https://api.example.com/{service}/docs"

    def _is_utility_request(
            self,
            api_description: str,
            user_intent: str) -> bool:
        """
        Detect if request is for a utility tool (non-API) vs API tool.

        Args:
            api_description: Human-readable API name and version
            user_intent: What operation user wants to perform

        Returns:
            bool: True if utility request, False if API request
        """
        # Keywords that indicate API tools
        api_keywords = [
            "google", "gmail", "forms", "sheets", "drive", "calendar",
            "api", "oauth", "authentication", "rest", "endpoint"
        ]

        # Keywords that indicate utility tools
        utility_keywords = [
            "json", "csv", "xml", "parse", "extract", "format",
            "date", "time", "text", "string", "calculate", "convert",
            "validate", "transform", "process", "filter", "sort",
            "merge", "split", "encode", "decode", "hash", "regex"
        ]

        # Combine description and intent for analysis
        text = f"{api_description} {user_intent}".lower()

        # Count matches
        api_matches = sum(1 for keyword in api_keywords if keyword in text)
        utility_matches = sum(
            1 for keyword in utility_keywords if keyword in text)

        # If more utility keywords than API keywords, treat as utility
        if utility_matches > api_matches:
            return True

        # If no API keywords and has utility keywords, treat as utility
        if api_matches == 0 and utility_matches > 0:
            return True

        # Default to API tool
        return False

    def _generation_phase(
        self,
        tool_name: str,
        api_details: Dict[str, Any],
        docs_url: str,
        user_intent: str
    ) -> Tuple[str, List[Dict[str, str]]]:
        """
        Code generation phase: Create tool code following tool-schema.md.

        Routes to appropriate generator based on tool type (API vs utility).

        Args:
            tool_name: Service identifier
            api_details: API details from research phase
            docs_url: Documentation URL
            user_intent: What operation user wants to perform

        Returns:
            tuple: (tool_code string, functions list)

        Target: ≤1s
        """
        logger.info(f"  Generating code for: {tool_name}")

        # Detect if this is a utility tool or API tool
        api_description = api_details.get("name", tool_name)
        is_utility = self._is_utility_request(api_description, user_intent)

        if is_utility:
            logger.info(f"  Detected utility tool request")
            return self._generate_utility_tool(
                tool_name=tool_name,
                api_details=api_details,
                docs_url=docs_url,
                user_intent=user_intent
            )
        else:
            logger.info(f"  Detected API tool request")
            return self._generate_api_tool(
                tool_name=tool_name,
                api_details=api_details,
                docs_url=docs_url,
                user_intent=user_intent
            )

    def _generate_utility_tool(
        self,
        tool_name: str,
        api_details: Dict[str, Any],
        docs_url: str,
        user_intent: str
    ) -> Tuple[str, List[Dict[str, str]]]:
        """
        Generate utility tool (non-API) with pure Python functions.

        Args:
            tool_name: Service identifier
            api_details: API details (may contain utility description)
            docs_url: Documentation URL
            user_intent: What operation user wants to perform

        Returns:
            tuple: (tool_code string, functions list)
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        utility_name = api_details.get("name", tool_name)

        # Generate header
        header = f"""# tools/{tool_name}.py
# Auto-generated by context-agent v2.0
# Utility: {utility_name}
# Docs: {docs_url}
# Generated: {timestamp}
# ─────────────────────────────────────────────────────────────"""

        # Generate imports (no Google API imports)
        imports = """
from typing import Dict, List, Optional, Any, Union
import json
import re
from datetime import datetime
"""

        # Generate utility functions based on user intent
        functions_code = []
        functions_metadata = []

        # Determine utility type from intent
        intent_lower = user_intent.lower()

        if "json" in intent_lower and (
                "path" in intent_lower or "extract" in intent_lower):
            # JSON path extraction utility
            func = '''
def extract_json_path(data: Union[Dict, List], path: str) -> Any:
    """Extract value from JSON data using dot notation path.

    Args:
        data: JSON data structure (dict or list)
        path: Dot notation path (e.g., "user.name" or "items[0].id")

    Returns:
        Any: Extracted value, or None if path not found

    Raises:
        ValueError: If path format is invalid
        TypeError: If data is not dict or list
    """
    if not isinstance(data, (dict, list)):
        return {
            "error": "Data must be dict or list",
            "error_type": "TypeError",
            "suggested_resolution": "Provide valid JSON data structure"
        }

    if not path:
        return {
            "error": "Path cannot be empty",
            "error_type": "ValueError",
            "suggested_resolution": "Provide valid dot notation path"
        }

    try:
        # Split path and traverse
        current = data
        parts = re.split(r'\\.(?![^\\[]*\\])', path)  # Split by . not inside []

        for part in parts:
            # Handle array indexing
            if '[' in part and ']' in part:
                key = part[:part.index('[')]
                index = int(part[part.index('[')+1:part.index(']')])

                if key:
                    current = current[key][index]
                else:
                    current = current[index]
            else:
                current = current[part]

        return current

    except (KeyError, IndexError, TypeError, ValueError) as e:
        return {
            "error": f"Path not found: {str(e)}",
            "error_type": type(e).__name__,
            "suggested_resolution": "Verify path exists in data structure"
        }
'''
            functions_code.append(func)
            functions_metadata.append({
                "name": "extract_json_path",
                "signature": "extract_json_path(data: Union[Dict, List], path: str) -> Any"
            })

        elif "date" in intent_lower or "time" in intent_lower:
            # Date formatting utility
            func = '''
def format_date(date_str: str, input_format: str = "%Y-%m-%d", output_format: str = "%B %d, %Y") -> str:
    """Format date string from one format to another.

    Args:
        date_str: Input date string
        input_format: Input format (strftime format, default: "%Y-%m-%d")
        output_format: Output format (strftime format, default: "%B %d, %Y")

    Returns:
        str: Formatted date string

    Raises:
        ValueError: If date_str doesn't match input_format
    """
    if not date_str:
        return {
            "error": "Date string cannot be empty",
            "error_type": "ValueError",
            "suggested_resolution": "Provide valid date string"
        }

    try:
        date_obj = datetime.strptime(date_str, input_format)
        return date_obj.strftime(output_format)
    except ValueError as e:
        return {
            "error": f"Date parsing failed: {str(e)}",
            "error_type": "ValueError",
            "suggested_resolution": f"Ensure date matches format {input_format}"
        }
'''
            functions_code.append(func)
            functions_metadata.append({
                "name": "format_date",
                "signature": "format_date(date_str: str, input_format: str = '%Y-%m-%d', output_format: str = '%B %d, %Y') -> str"
            })

        else:
            # Generic text processing utility
            func = '''
def process_text(text: str, operation: str = "upper", **kwargs) -> str:
    """Process text with various operations.

    Args:
        text: Input text to process
        operation: Operation to perform (upper, lower, title, strip, replace)
        **kwargs: Additional arguments for specific operations

    Returns:
        str: Processed text

    Raises:
        ValueError: If text is empty or operation is invalid
    """
    if not text:
        return {
            "error": "Text cannot be empty",
            "error_type": "ValueError",
            "suggested_resolution": "Provide non-empty text"
        }

    valid_operations = ["upper", "lower", "title", "strip", "replace"]
    if operation not in valid_operations:
        return {
            "error": f"Invalid operation: {operation}",
            "error_type": "ValueError",
            "suggested_resolution": f"Use one of: {', '.join(valid_operations)}"
        }

    try:
        if operation == "upper":
            return text.upper()
        elif operation == "lower":
            return text.lower()
        elif operation == "title":
            return text.title()
        elif operation == "strip":
            return text.strip()
        elif operation == "replace":
            old = kwargs.get("old", "")
            new = kwargs.get("new", "")
            return text.replace(old, new)
        else:
            return text
    except Exception as e:
        return {
            "error": str(e),
            "error_type": type(e).__name__,
            "suggested_resolution": "Check operation parameters"
        }
'''
            functions_code.append(func)
            functions_metadata.append({
                "name": "process_text",
                "signature": "process_text(text: str, operation: str = 'upper', **kwargs) -> str"
            })

        # Combine all parts
        tool_code = header + imports + "\n".join(functions_code)

        return tool_code, functions_metadata

    def _generate_api_tool(
        self,
        tool_name: str,
        api_details: Dict[str, Any],
        docs_url: str,
        user_intent: str
    ) -> Tuple[str, List[Dict[str, str]]]:
        """
        Generate API tool with Google API client imports using discovery docs.

        Args:
            tool_name: Service identifier
            api_details: API details from research phase
            docs_url: Documentation URL
            user_intent: What operation user wants to perform

        Returns:
            tuple: (tool_code string, functions list)
        """
        timestamp = datetime.now(timezone.utc).isoformat()
        api_name = api_details.get("name", tool_name)
        api_version = api_details.get("version", "v1")

        # Try to fetch discovery document
        api_description = f"{api_name} API {api_version}"
        discovery_doc = self.discovery_parser.fetch_discovery_doc(
            api_description)

        if discovery_doc:
            logger.info(f"Using discovery doc for {api_name} {api_version}")
            return self._generate_from_discovery_doc(
                tool_name, discovery_doc, docs_url, user_intent, timestamp
            )
        else:
            logger.warning(
                f"Discovery doc not found, using template for {api_name}")
            return self._generate_from_template(
                tool_name, api_details, docs_url, user_intent, timestamp
            )

    def _generate_from_discovery_doc(
        self,
        tool_name: str,
        discovery_doc: Dict[str, Any],
        docs_url: str,
        user_intent: str,
        timestamp: str
    ) -> Tuple[str, List[Dict[str, str]]]:
        """
        Generate API tool code from discovery document.

        Args:
            tool_name: Service identifier
            discovery_doc: Discovery document
            docs_url: Documentation URL
            user_intent: User intent
            timestamp: Generation timestamp

        Returns:
            tuple: (tool_code string, functions list)
        """
        # Extract metadata from discovery doc
        metadata = self.discovery_parser.extract_api_metadata(discovery_doc)
        api_name = metadata["name"]
        api_version = metadata["version"]
        api_title = metadata["title"]

        # Use docs URL from discovery doc if available
        if metadata["docs_url"]:
            docs_url = metadata["docs_url"]

        # Generate header
        header = f"""# tools/{tool_name}.py
# Auto-generated by context-agent v2.1 (discovery doc)
# API: {api_title} ({api_name} {api_version})
# Docs: {docs_url}
# Generated: {timestamp}
# ─────────────────────────────────────────────────────────────"""

        # Generate imports - use src.auth_manager for canonical import
        imports = """
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from src.auth_manager import get_credentials
from typing import Dict, List, Optional, Any
"""

        # Extract resources and methods
        resources = self.discovery_parser.extract_resources(discovery_doc)

        # Determine which resource/methods to generate based on user intent
        methods_to_generate = self._select_methods_from_intent(
            user_intent, resources, discovery_doc
        )

        # Generate functions
        functions_code = []
        functions_metadata = []

        for resource_path, method_name in methods_to_generate:
            func_code, func_meta = self._generate_method_from_discovery(
                discovery_doc, resource_path, method_name, api_name, api_version)
            functions_code.append(func_code)
            functions_metadata.append(func_meta)

        # If no methods generated, fall back to common methods
        if not functions_code:
            logger.warning(
                "No methods matched intent, generating common methods")
            func_code, func_meta = self._generate_common_methods(
                discovery_doc, api_name, api_version
            )
            functions_code.extend(func_code)
            functions_metadata.extend(func_meta)

        # If still no methods, fall back to template generation
        if not functions_code:
            logger.warning(
                "Discovery doc has no usable methods, falling back to template")
            timestamp = datetime.now(timezone.utc).isoformat()
            api_details = {"name": api_name, "version": api_version}
            return self._generate_from_template(
                tool_name, api_details, docs_url, user_intent, timestamp
            )

        # Combine all parts
        tool_code = header + imports + "\n".join(functions_code)

        return tool_code, functions_metadata

    def _select_methods_from_intent(
        self,
        user_intent: str,
        resources: Dict[str, Any],
        discovery_doc: Dict[str, Any]
    ) -> List[Tuple[Optional[str], str]]:
        """
        Select methods to generate based on user intent.

        Args:
            user_intent: User intent description
            resources: Resources from discovery doc
            discovery_doc: Full discovery document

        Returns:
            List of (resource_path, method_name) tuples
        """
        intent_lower = user_intent.lower()
        methods_to_generate = []

        # Map intent keywords to method names
        intent_method_map = {
            "list": "list",
            "get": "get",
            "create": "create",
            "insert": "insert",
            "update": "update",
            "patch": "patch",
            "delete": "delete",
            "send": "send",
            "search": "search",
            "query": "list",
        }

        # Check for method keywords in intent
        for keyword, method_name in intent_method_map.items():
            if keyword in intent_lower:
                # Check if method exists in any resource
                for resource_name, resource_def in resources.items():
                    resource_methods = resource_def.get("methods", {})
                    if method_name in resource_methods:
                        methods_to_generate.append(
                            (resource_name, method_name))

                # Also check top-level methods
                top_level_methods = discovery_doc.get("methods", {})
                if method_name in top_level_methods:
                    methods_to_generate.append((None, method_name))

        return methods_to_generate

    def _generate_method_from_discovery(
        self,
        discovery_doc: Dict[str, Any],
        resource_path: Optional[str],
        method_name: str,
        api_name: str,
        api_version: str
    ) -> Tuple[str, Dict[str, str]]:
        """
        Generate a single method from discovery doc.

        Args:
            discovery_doc: Discovery document
            resource_path: Resource path (e.g., "forms")
            method_name: Method name (e.g., "list")
            api_name: API name
            api_version: API version

        Returns:
            Tuple of (function code, function metadata)
        """
        # Get minimal required scope
        scope = self.discovery_parser.get_minimal_scope(
            discovery_doc, method_name, resource_path, readonly=True
        )

        # Map scope URL to friendly name for auth_manager
        scope_friendly = self._map_scope_to_friendly(scope)

        # Generate method signature
        signature, params = self.discovery_parser.generate_method_signature(
            discovery_doc, method_name, resource_path
        )

        # Extract function name from signature
        func_name = signature.split("(")[0]

        # Get service path
        service_path = self.discovery_parser.get_service_path(
            discovery_doc, resource_path)

        # Build parameter validation code
        validation_code = []
        for param_name, type_hint, default in params:
            if "Optional" not in type_hint and default is None:
                validation_code.append(f"""
    if not {param_name}:
        return {{
            "error": "{param_name} is required",
            "error_type": "ValueError",
            "suggested_resolution": "Provide {param_name} parameter"
        }}""")

        validation_str = "\n".join(validation_code) if validation_code else ""

        # Build parameter dict for API call
        param_dict_items = [
            f"'{p[0]}': {p[0]}" for p in params if p[2] is not None]
        param_dict = "{" + ", ".join(param_dict_items) + \
            "}" if param_dict_items else "{}"

        # Get method description
        methods = self.discovery_parser.extract_methods(
            discovery_doc, resource_path)
        method_def = methods.get(method_name, {})
        method_desc = method_def.get("description", f"{method_name} operation")

        # Build parameter documentation
        param_docs = []
        for p in params:
            param_name = p[0]
            # Safely get parameter description
            param_def = method_def.get('parameters', {}).get(param_name, {})
            param_desc = param_def.get('description', 'Parameter')
            param_docs.append(f"        {param_name}: {param_desc}")

        params_doc = chr(10).join(param_docs) if param_docs else "        None"

        # Generate function code
        func_code = f'''
def {signature}:
    """{method_desc}

    Args:
{params_doc}

    Returns:
        dict: API response data

    Raises:
        ValueError: If required parameters are missing
        HttpError: If API call fails
        AuthError: If credentials are invalid
    """{validation_str}

    try:
        creds = get_credentials('{scope_friendly}')
        service = build('{api_name}', '{api_version}', credentials=creds)
        result = {service_path}.{method_name}(**{param_dict}).execute()
        return result
    except HttpError as e:
        return {{
            "error": str(e),
            "error_type": "HttpError",
            "suggested_resolution": "Check API quota, permissions, and parameters"
        }}
    except Exception as e:
        return {{
            "error": str(e),
            "error_type": type(e).__name__,
            "suggested_resolution": "Review error and check API documentation"
        }}
'''

        func_meta = {
            "name": func_name,
            "signature": signature
        }

        return func_code, func_meta

    def _generate_common_methods(
        self,
        discovery_doc: Dict[str, Any],
        api_name: str,
        api_version: str
    ) -> Tuple[List[str], List[Dict[str, str]]]:
        """
        Generate common methods (list, get) when intent matching fails.

        Args:
            discovery_doc: Discovery document
            api_name: API name
            api_version: API version

        Returns:
            Tuple of (list of function codes, list of function metadata)
        """
        functions_code = []
        functions_metadata = []

        # Get first resource
        resources = self.discovery_parser.extract_resources(discovery_doc)
        if resources:
            first_resource = list(resources.keys())[0]

            # Generate list method if available
            if "list" in resources[first_resource].get("methods", {}):
                func_code, func_meta = self._generate_method_from_discovery(
                    discovery_doc, first_resource, "list", api_name, api_version
                )
                functions_code.append(func_code)
                functions_metadata.append(func_meta)

            # Generate get method if available
            if "get" in resources[first_resource].get("methods", {}):
                func_code, func_meta = self._generate_method_from_discovery(
                    discovery_doc, first_resource, "get", api_name, api_version
                )
                functions_code.append(func_code)
                functions_metadata.append(func_meta)

        # If no methods generated from discovery doc, return empty
        # The caller should fall back to template generation
        return functions_code, functions_metadata

    def _map_scope_to_friendly(self, scope_url: str) -> str:
        """
        Map OAuth scope URL to friendly name for AuthManager.

        Args:
            scope_url: Full OAuth scope URL

        Returns:
            Friendly scope name (or URL if no mapping)

        Example:
            'https://www.googleapis.com/auth/forms.readonly' -> 'forms_readonly'
        """
        # Extract scope from URL
        if "googleapis.com/auth/" in scope_url:
            scope_part = scope_url.split("googleapis.com/auth/")[1]
            # Convert to friendly name
            return scope_part.replace(".", "_")

        # Return as-is if not recognized
        return scope_url

    def _generate_from_template(
        self,
        tool_name: str,
        api_details: Dict[str, Any],
        docs_url: str,
        user_intent: str,
        timestamp: str
    ) -> Tuple[str, List[Dict[str, str]]]:
        """
        Generate API tool from template (fallback when discovery doc unavailable).

        Args:
            tool_name: Service identifier
            api_details: API details
            docs_url: Documentation URL
            user_intent: User intent
            timestamp: Generation timestamp

        Returns:
            tuple: (tool_code string, functions list)
        """
        api_name = api_details.get("name", tool_name)
        api_version = api_details.get("version", "v1")

        header = f"""# tools/{tool_name}.py
# Auto-generated by context-agent v2.1 (template fallback)
# API: {api_name} {api_version}
# Docs: {docs_url}
# Generated: {timestamp}
# ─────────────────────────────────────────────────────────────"""

        # Generate imports - use src.auth_manager for canonical import
        imports = """
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from src.auth_manager import get_credentials
from typing import Dict, List, Optional, Any
"""

        # Generate functions based on endpoints
        functions_code = []
        functions_metadata = []

        # Determine scope from API name
        service_name = tool_name.replace("google_", "").replace("_", "")
        scope = f"{service_name}_readonly"

        # Generate list function
        list_func = f'''
def list_{service_name}(max_results: int = 100) -> Dict[str, Any]:
    """List user's {api_name} items.

    Args:
        max_results: Maximum number of items to return (1-100)

    Returns:
        dict: {{'items': [list of item objects], 'nextPageToken': str}}

    Raises:
        ValueError: If max_results is out of range
        HttpError: If API call fails
        AuthError: If credentials are invalid
    """
    if not 1 <= max_results <= 100:
        return {{
            "error": "max_results must be between 1 and 100",
            "error_type": "ValueError",
            "suggested_resolution": "Adjust max_results parameter"
        }}

    try:
        creds = get_credentials('{scope}')
        service = build('{service_name}', '{api_version}', credentials=creds)
        result = service.{service_name}().list(pageSize=max_results).execute()
        return result
    except HttpError as e:
        return {{
            "error": str(e),
            "error_type": "HttpError",
            "suggested_resolution": "Check API quota and permissions"
        }}
    except Exception as e:
        return {{
            "error": str(e),
            "error_type": type(e).__name__,
            "suggested_resolution": "Check API quota and permissions"
        }}
'''

        functions_code.append(list_func)
        functions_metadata.append({
            "name": f"list_{service_name}",
            "signature": f"list_{service_name}(max_results: int = 100) -> Dict[str, Any]"
        })

        # Generate get function
        get_func = f'''
def get_{service_name}_item(item_id: str) -> Dict[str, Any]:
    """Get a specific {api_name} item by ID.

    Args:
        item_id: The item ID to retrieve

    Returns:
        dict: Item object with metadata

    Raises:
        ValueError: If item_id is empty
        HttpError: If item not found or API fails
        AuthError: If credentials are invalid
    """
    if not item_id:
        return {{
            "error": "item_id cannot be empty",
            "error_type": "ValueError",
            "suggested_resolution": "Provide a valid item ID"
        }}

    try:
        creds = get_credentials('{scope}')
        service = build('{service_name}', '{api_version}', credentials=creds)
        result = service.{service_name}().get(id=item_id).execute()
        return result
    except HttpError as e:
        return {{
            "error": str(e),
            "error_type": "HttpError",
            "suggested_resolution": "Verify item_id exists and is accessible"
        }}
    except Exception as e:
        return {{
            "error": str(e),
            "error_type": type(e).__name__,
            "suggested_resolution": "Verify item_id exists and is accessible"
        }}
'''

        functions_code.append(get_func)
        functions_metadata.append({
            "name": f"get_{service_name}_item",
            "signature": f"get_{service_name}_item(item_id: str) -> Dict[str, Any]"
        })

        # Combine all parts
        tool_code = header + imports + "\n".join(functions_code)

        return tool_code, functions_metadata

    def _error_response(
        self,
        request_id: str,
        error_type: str,
        message: str,
        details: Dict[str, Any],
        retry_recommended: bool = True,
        suggested_resolution: str = None
    ) -> Dict[str, Any]:
        """
        Create error response following agent-protocol.md contract.

        Args:
            request_id: Request UUID
            error_type: Error type (research_failed, generation_failed, etc.)
            message: Error message
            details: Error details dict
            retry_recommended: Whether retry is recommended
            suggested_resolution: Custom resolution suggestion

        Returns:
            dict: Error response following contract specification
        """
        if suggested_resolution is None:
            suggested_resolution = self._get_default_resolution(error_type)

        return {
            "status": "error",
            "request_id": request_id,
            "error_type": error_type,
            "message": message,
            "details": details,
            "suggested_resolution": suggested_resolution,
            "retry_recommended": retry_recommended,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

    def _get_default_resolution(self, error_type: str) -> str:
        """Get default resolution suggestion for error type."""
        resolutions = {
            "research_failed": "Try alternative API version or check API availability",
            "generation_failed": "Check API documentation availability and format",
            "validation_failed": "Review generated code for syntax or import errors",
            "timeout": "Increase timeout or simplify the operation",
            "auth_failed": "Re-authenticate with OAuth2 flow",
            "unsupported_api": "API not compatible with this system"}
        return resolutions.get(error_type,
                               "Review error details and try again")
