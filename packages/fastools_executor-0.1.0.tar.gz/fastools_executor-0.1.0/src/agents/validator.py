"""
Tool Validator - Validates generated tools for syntax, imports, and execution.

This module implements validation phase for User Story 2.
It validates:
- Syntax correctness using ast.parse()
- Import safety (allowed/blocked lists)
- Test execution (load tool and call function)
"""

import ast
import importlib.util
import logging
import os
import sys
import tempfile
from typing import Any, Dict, List, Set

# Setup logging
logger = logging.getLogger(__name__)


class ToolValidator:
    """
    Validates generated tools for syntax, imports, and execution.

    Features:
    - Syntax validation using ast.parse()
    - Import validation against allowed/blocked lists
    - Test execution with minimal parameters
    - Result structure validation
    """

    # Blocked imports - security-sensitive modules
    BLOCKED_IMPORTS = {
        'os', 'sys', 'subprocess', 'socket', 'socketserver',
        'multiprocessing', 'threading', 'ctypes', 'importlib',
        'imp', '__import__', 'eval', 'exec', 'compile',
        'open', 'file', 'input', 'raw_input', 'pathlib',
        'urllib', 'http.client'
    }

    # Allowed imports - safe standard library and approved third-party
    ALLOWED_IMPORTS = {
        # Standard library
        'json', 'datetime', 're', 'math', 'collections',
        'itertools', 'functools', 'operator', 'typing',
        'string', 'decimal', 'fractions', 'statistics',
        # Data processing
        'pandas', 'numpy',
        # API clients
        'googleapiclient', 'google.auth', 'google_auth_oauthlib',
        'requests', 'urllib.parse', 'urllib.request',
        # Internal
        'auth_manager'
    }

    def validate_tool(
        self,
        tool_code: str,
        tool_name: str,
        test_execution: bool = True
    ) -> Dict[str, Any]:
        """
        Validate generated tool code.

        Args:
            tool_code: Python code to validate
            tool_name: Name of the tool
            test_execution: Whether to execute test (default: True)

        Returns:
            dict: Validation result with syntax_check, test_execution, test_output
        """
        result = {
            "syntax_check": "pending",
            "test_execution": "pending",
            "test_output": "",
            "error": None
        }

        # Step 1: Syntax validation
        try:
            tree = ast.parse(tool_code)
            result["syntax_check"] = "passed"
            logger.info(f"✓ Syntax validation passed for {tool_name}")
        except SyntaxError as e:
            result["syntax_check"] = "failed"
            result["error"] = f"Syntax error at line {e.lineno}: {e.msg}"
            logger.error(
                f"✗ Syntax validation failed for {tool_name}: {
                    result['error']}")
            return result

        # Step 2: Import validation
        try:
            self._validate_imports(tree)
            logger.info(f"✓ Import validation passed for {tool_name}")
        except ValueError as e:
            result["syntax_check"] = "failed"
            result["error"] = str(e)
            logger.error(
                f"✗ Import validation failed for {tool_name}: {
                    result['error']}")
            return result

        # Step 3: Test execution (if requested)
        if test_execution:
            try:
                test_result = self._test_execution(tool_code, tool_name)
                result["test_execution"] = "passed" if test_result["success"] else "failed"
                result["test_output"] = test_result["output"]

                if not test_result["success"]:
                    result["error"] = test_result.get(
                        "error", "Test execution failed")
                    logger.error(
                        f"✗ Test execution failed for {tool_name}: {
                            result['error']}")
                else:
                    logger.info(f"✓ Test execution passed for {tool_name}")

            except Exception as e:
                result["test_execution"] = "failed"
                result["error"] = f"Test execution error: {str(e)}"
                logger.error(
                    f"✗ Test execution error for {tool_name}: {
                        result['error']}")
        else:
            result["test_execution"] = "skipped"
            result["test_output"] = "Test execution not requested"

        return result

    def _validate_imports(self, tree: ast.AST) -> None:
        """
        Validate that tool only imports allowed modules.

        Args:
            tree: AST of tool code

        Raises:
            ValueError: If blocked import is found
        """
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    self._check_import(alias.name)

            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                self._check_import(module)

    def _check_import(self, module_name: str) -> None:
        """
        Check if import is allowed.

        Args:
            module_name: Name of module to check

        Raises:
            ValueError: If import is blocked
        """
        if not module_name:
            return

        # Check blocked imports
        module_parts = module_name.split('.')
        for i in range(len(module_parts)):
            check_name = '.'.join(module_parts[:i + 1])
            if check_name in self.BLOCKED_IMPORTS:
                raise ValueError(
                    f"Import '{module_name}' is blocked for security reasons"
                )

        # Check allowed imports
        top_level = module_parts[0]
        if top_level not in self.ALLOWED_IMPORTS:
            # Check if it's a submodule of an allowed package
            allowed = any(
                module_name.startswith(allowed_mod) or
                top_level == allowed_mod.split('.')[0]
                for allowed_mod in self.ALLOWED_IMPORTS
            )
            if not allowed:
                raise ValueError(
                    f"Import '{module_name}' is not in allowed imports list"
                )

    def _is_utility_tool(self, tool_code: str) -> bool:
        """
        Detect if tool is a utility (non-API) tool.

        Args:
            tool_code: Python code to analyze

        Returns:
            bool: True if utility tool, False if API tool
        """
        # Check for utility indicators
        has_auth_manager = "from auth_manager import" in tool_code
        has_google_api = "from googleapiclient" in tool_code
        has_utility_header = "# Utility:" in tool_code

        # Utility tools don't have auth_manager or googleapiclient imports
        if not has_auth_manager and not has_google_api:
            return True

        # Explicit utility header
        if has_utility_header:
            return True

        return False

    def validate_utility_function(
        self,
        function: callable,
        function_name: str
    ) -> Dict[str, Any]:
        """
        Validate utility function with sample inputs.

        Args:
            function: Function to test
            function_name: Name of function

        Returns:
            dict: {success: bool, output: str, error: str}
        """
        # Determine sample inputs based on function name
        test_cases = []

        if "json" in function_name.lower() and "path" in function_name.lower():
            # JSON path extraction test
            test_cases = [
                {
                    "args": ({"user": {"name": "Alice"}}, "user.name"),
                    "expected_type": str,
                    "description": "Extract nested JSON path"
                },
                {
                    "args": ([{"id": 1}, {"id": 2}], "[0].id"),
                    "expected_type": int,
                    "description": "Extract from array"
                }
            ]
        elif "date" in function_name.lower() or "format" in function_name.lower():
            # Date formatting test
            test_cases = [
                {
                    "args": ("2025-01-10",),
                    "expected_type": (str, dict),  # Can return error dict
                    "description": "Format date string"
                }
            ]
        elif "text" in function_name.lower() or "process" in function_name.lower():
            # Text processing test
            test_cases = [
                {
                    "args": ("hello world",),
                    "expected_type": str,
                    "description": "Process text"
                }
            ]
        else:
            # Generic test - try calling with no args
            test_cases = [
                {
                    "args": (),
                    "expected_type": (str, dict, list, int, float, bool),
                    "description": "Generic function call"
                }
            ]

        results = []
        for test_case in test_cases:
            try:
                result = function(*test_case["args"])

                # Check if result is error dict
                is_error = isinstance(result, dict) and "error" in result

                # Validate result type
                if not is_error:
                    if not isinstance(result, test_case["expected_type"]):
                        results.append({
                            "success": False,
                            "test": test_case["description"],
                            "error": f"Expected {test_case['expected_type']}, got {type(result).__name__}"
                        })
                        continue

                results.append({
                    "success": True,
                    "test": test_case["description"],
                    "result": str(result)[:100]  # Truncate long results
                })

            except Exception as e:
                # Allow exceptions if they're caught and returned as error dict
                results.append({
                    "success": False,
                    "test": test_case["description"],
                    "error": str(e)
                })

        # Overall success if at least one test passed
        success = any(r["success"] for r in results)

        return {
            "success": success,
            "output": f"✓ Utility validation - {len([r for r in results if r['success']])}/{len(results)} tests passed",
            "error": None if success else "Some tests failed",
            "test_results": results
        }

    def _test_execution(
        self,
        tool_code: str,
        tool_name: str
    ) -> Dict[str, Any]:
        """
        Test tool execution by loading and calling a function.

        Args:
            tool_code: Python code of tool
            tool_name: Name of tool

        Returns:
            dict: {success: bool, output: str, error: str}

        Target: ≤2s
        """
        # Create temporary file for tool
        with tempfile.NamedTemporaryFile(
            mode='w',
            suffix='.py',
            delete=False
        ) as temp_file:
            temp_file.write(tool_code)
            temp_path = temp_file.name

        try:
            # Load module from file
            spec = importlib.util.spec_from_file_location(tool_name, temp_path)
            if spec is None or spec.loader is None:
                return {
                    "success": False,
                    "output": "",
                    "error": "Could not load module spec"
                }

            module = importlib.util.module_from_spec(spec)
            sys.modules[tool_name] = module
            spec.loader.exec_module(module)

            # Find first function to test
            # Exclude typing imports and built-in types
            typing_names = {
                'Dict',
                'List',
                'Optional',
                'Any',
                'Union',
                'Tuple',
                'Set'}
            functions = [
                name for name in dir(module)
                if callable(getattr(module, name))
                and not name.startswith('_')
                and name not in typing_names
                # Has function code
                and hasattr(getattr(module, name), '__code__')
            ]

            if not functions:
                return {
                    "success": False,
                    "output": "",
                    "error": "No testable functions found"
                }

            # Test first function with minimal args
            test_func_name = functions[0]
            test_func = getattr(module, test_func_name)

            # Check if this is a utility tool
            is_utility = self._is_utility_tool(tool_code)

            if is_utility:
                # Test utility function with sample inputs
                logger.info(f"Testing utility function: {test_func_name}")
                result = self.validate_utility_function(
                    test_func, test_func_name)

                # Add function count to output
                result["output"] = f"{
                    result['output']} - found {
                    len(functions)} function(s)"

                return result
            else:
                # API tool - skip actual execution to avoid auth issues
                # Mock auth_manager.get_credentials to avoid real auth
                # In production, this would use mock credentials

                return {
                    "success": True,
                    "output": f"✓ Tool validation passed - found {len(functions)} function(s)",
                    "error": None
                }

        except Exception as e:
            return {
                "success": False,
                "output": "",
                "error": str(e)
            }

        finally:
            # Clean up temp file
            try:
                os.unlink(temp_path)
            except BaseException:
                pass

            # Clean up imported module
            if tool_name in sys.modules:
                del sys.modules[tool_name]
