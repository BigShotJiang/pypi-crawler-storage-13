"""
Optional Prometheus metrics export for fastools executor.

Provides /metrics endpoint compatible with Prometheus scraping.
Requires prometheus_client package (optional dependency).
"""

import time
from pathlib import Path
from typing import Any, Dict, Optional

try:
    from prometheus_client import (CONTENT_TYPE_LATEST, CollectorRegistry,
                                   Counter, Gauge, Histogram, Summary,
                                   generate_latest)
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False


class PrometheusExporter:
    """
    Prometheus metrics exporter.

    Exports metrics in Prometheus format via /metrics endpoint.
    Requires prometheus_client package.
    """

    def __init__(self, registry: Optional['CollectorRegistry'] = None):
        """
        Initialize Prometheus exporter.

        Args:
            registry: Optional custom registry (creates new if None)

        Raises:
            ImportError: If prometheus_client is not installed
        """
        if not PROMETHEUS_AVAILABLE:
            raise ImportError(
                "prometheus_client is required for Prometheus export. "
                "Install with: pip install prometheus-client"
            )

        self.registry = registry or CollectorRegistry()

        # Cache metrics
        self.cache_hits = Counter(
            'fastools_cache_hits_total',
            'Total number of cache hits',
            registry=self.registry
        )
        self.cache_misses = Counter(
            'fastools_cache_misses_total',
            'Total number of cache misses',
            registry=self.registry
        )
        self.cache_writes = Counter(
            'fastools_cache_writes_total',
            'Total number of cache writes',
            registry=self.registry
        )
        self.cache_errors = Counter(
            'fastools_cache_errors_total',
            'Total number of cache errors',
            registry=self.registry
        )

        # Tool generation metrics
        self.tools_generated = Counter(
            'fastools_tools_generated_total',
            'Total number of tools generated',
            registry=self.registry
        )
        self.generation_failures = Counter(
            'fastools_generation_failures_total',
            'Total number of tool generation failures',
            registry=self.registry
        )

        # Sandbox execution metrics
        self.sandbox_executions = Counter(
            'fastools_sandbox_executions_total',
            'Total number of sandbox executions',
            registry=self.registry
        )
        self.sandbox_violations = Counter(
            'fastools_sandbox_violations_total',
            'Total number of sandbox security violations',
            registry=self.registry
        )
        self.execution_duration = Histogram(
            'fastools_execution_duration_seconds',
            'Sandbox execution duration in seconds',
            buckets=[0.01, 0.05, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0],
            registry=self.registry
        )

        # Resource metrics
        self.active_sessions = Gauge(
            'fastools_active_sessions',
            'Number of active sandbox sessions',
            registry=self.registry
        )
        self.total_memory_mb = Gauge(
            'fastools_memory_usage_mb',
            'Total memory usage in MB',
            registry=self.registry
        )
        self.max_memory_mb = Gauge(
            'fastools_max_memory_mb',
            'Maximum memory usage in MB',
            registry=self.registry
        )

        # Error metrics
        self.total_errors = Counter(
            'fastools_errors_total',
            'Total number of errors',
            labelnames=['error_type'],
            registry=self.registry
        )
        self.auth_failures = Counter(
            'fastools_auth_failures_total',
            'Total number of authentication failures',
            registry=self.registry
        )

        # Token usage metrics
        self.tokens_used = Counter(
            'fastools_tokens_used_total',
            'Total number of tokens used',
            registry=self.registry
        )

    def update_from_snapshot(self, snapshot: Dict[str, Any]):
        """
        Update Prometheus metrics from a metrics snapshot.

        Args:
            snapshot: Metrics snapshot from MetricsCollector
        """
        # Update counters (increment by difference from last update)
        # Note: Prometheus counters only go up, so we track the difference
        # This is a simplified approach; in production you'd want to track
        # state

        # Update gauges (these can go up and down)
        self.active_sessions.set(snapshot.get('active_sessions', 0))
        self.total_memory_mb.set(snapshot.get('total_memory_mb', 0))
        self.max_memory_mb.set(snapshot.get('max_memory_mb', 0))

    def increment_cache_hit(self):
        """Increment cache hit counter."""
        self.cache_hits.inc()

    def increment_cache_miss(self):
        """Increment cache miss counter."""
        self.cache_misses.inc()

    def increment_cache_write(self):
        """Increment cache write counter."""
        self.cache_writes.inc()

    def increment_cache_error(self):
        """Increment cache error counter."""
        self.cache_errors.inc()

    def increment_tool_generated(self):
        """Increment tools generated counter."""
        self.tools_generated.inc()

    def increment_generation_failure(self):
        """Increment generation failure counter."""
        self.generation_failures.inc()

    def increment_sandbox_execution(self, duration_seconds: float):
        """
        Record sandbox execution.

        Args:
            duration_seconds: Execution duration in seconds
        """
        self.sandbox_executions.inc()
        self.execution_duration.observe(duration_seconds)

    def increment_sandbox_violation(self):
        """Increment sandbox violation counter."""
        self.sandbox_violations.inc()

    def increment_error(self, error_type: str):
        """
        Increment error counter by type.

        Args:
            error_type: Type of error
        """
        self.total_errors.labels(error_type=error_type).inc()

    def increment_auth_failure(self):
        """Increment auth failure counter."""
        self.auth_failures.inc()

    def add_tokens_used(self, count: int):
        """
        Add to tokens used counter.

        Args:
            count: Number of tokens used
        """
        self.tokens_used.inc(count)

    def update_active_sessions(self, count: int):
        """
        Update active sessions gauge.

        Args:
            count: Number of active sessions
        """
        self.active_sessions.set(count)

    def update_memory_usage(self, total_mb: float, max_mb: float):
        """
        Update memory usage gauges.

        Args:
            total_mb: Total memory usage in MB
            max_mb: Maximum memory usage in MB
        """
        self.total_memory_mb.set(total_mb)
        self.max_memory_mb.set(max_mb)

    def generate_metrics(self) -> bytes:
        """
        Generate Prometheus metrics in text format.

        Returns:
            Metrics in Prometheus text format
        """
        return generate_latest(self.registry)

    def get_content_type(self) -> str:
        """
        Get content type for metrics response.

        Returns:
            Content type string
        """
        return CONTENT_TYPE_LATEST


def create_metrics_server(
    exporter: PrometheusExporter,
    port: int = 9090,
    addr: str = '0.0.0.0'
) -> Optional[Any]:
    """
    Create a simple HTTP server for Prometheus metrics.

    Args:
        exporter: PrometheusExporter instance
        port: Port to listen on
        addr: Address to bind to

    Returns:
        HTTP server instance or None if prometheus_client not available

    Example:
        >>> exporter = PrometheusExporter()
        >>> server = create_metrics_server(exporter, port=9090)
        >>> # Metrics available at http://localhost:9090/metrics
    """
    if not PROMETHEUS_AVAILABLE:
        return None

    from prometheus_client import start_http_server

    # Start HTTP server
    start_http_server(port, addr=addr, registry=exporter.registry)

    return {
        'port': port,
        'addr': addr,
        'url': f'http://{addr}:{port}/metrics'
    }


class PrometheusIntegration:
    """
    Integration layer between TelemetryManager and Prometheus.

    Automatically updates Prometheus metrics from telemetry events.
    """

    def __init__(self, exporter: PrometheusExporter):
        """
        Initialize Prometheus integration.

        Args:
            exporter: PrometheusExporter instance
        """
        self.exporter = exporter

    def handle_event(self, event: Dict[str, Any]):
        """
        Handle a telemetry event and update Prometheus metrics.

        Args:
            event: Telemetry event dictionary
        """
        event_type = event.get('event_type')

        # Cache events
        if event_type == 'cache_hit':
            self.exporter.increment_cache_hit()
        elif event_type == 'cache_miss':
            self.exporter.increment_cache_miss()
        elif event_type == 'cache_write':
            self.exporter.increment_cache_write()
        elif event_type == 'cache_error':
            self.exporter.increment_cache_error()

        # Tool generation events
        elif event_type == 'tool_generation_success':
            self.exporter.increment_tool_generated()
        elif event_type == 'tool_generation_failure':
            self.exporter.increment_generation_failure()

        # Sandbox events
        elif event_type == 'sandbox_execution':
            duration_ms = event.get('duration_ms', 0)
            self.exporter.increment_sandbox_execution(duration_ms / 1000.0)
        elif event_type == 'sandbox_violation':
            self.exporter.increment_sandbox_violation()

        # Error events
        elif event_type == 'execution_error':
            error_type = event.get('metadata', {}).get('error_type', 'unknown')
            self.exporter.increment_error(error_type)
        elif event_type == 'auth_failure':
            self.exporter.increment_auth_failure()

        # Token usage
        if event.get('token_cost'):
            self.exporter.add_tokens_used(event['token_cost'])

        # Session events
        if event_type == 'session_created':
            # Update would need current count from session manager
            pass
        elif event_type == 'session_destroyed':
            # Update would need current count from session manager
            pass
