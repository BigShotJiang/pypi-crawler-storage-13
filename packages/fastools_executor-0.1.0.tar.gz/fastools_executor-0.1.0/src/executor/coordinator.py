"""
Execution coordinator - orchestrates tool execution with caching and error handling.

This module is the main entry point for tool execution, handling:
- Cache checking and loading
- Delegation to agent for missing tools
- Sandbox execution
- Error handling and structured responses
- Logging and metrics
"""

import logging
import time
import traceback
from dataclasses import asdict, dataclass
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from agents.context_agent import ContextAgent

from .cache import CacheError, ToolCache
from .sandbox import MemoryExceededError, Sandbox, SandboxViolationError
from .session_manager import SessionLimitError, SessionManager
from .telemetry import EventType, LogLevel, get_telemetry

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


class ErrorType(str, Enum):
    """Standard error types for structured error responses."""
    RATE_LIMITED = "rate_limited"
    AUTH_ERROR = "auth_error"
    VALIDATION_ERROR = "validation_error"
    GENERATION_FAILED = "generation_failed"
    SANDBOX_VIOLATION = "sandbox_violation"
    MEMORY_EXCEEDED = "memory_exceeded"
    TIMEOUT_ERROR = "timeout_error"
    EXECUTION_ERROR = "execution_error"
    CACHE_ERROR = "cache_error"
    SESSION_LIMIT_ERROR = "session_limit_error"


@dataclass
class ExecutionResult:
    """Result of tool execution."""
    success: bool
    tool_name: str
    execution_time: float
    token_cost: int
    was_cached: bool
    result: Optional[Any] = None
    error: Optional[str] = None
    error_type: Optional[ErrorType] = None
    suggested_resolution: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = asdict(self)
        if self.error_type:
            data['error_type'] = self.error_type.value
        return data


@dataclass
class CacheCheckResult:
    """Result of cache check operation."""
    exists: bool
    tool_name: str
    token_cost: int
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class ToolList:
    """List of cached tools with metadata."""
    tools: List[Dict[str, Any]]
    total_count: int
    cache_stats: Dict[str, Any]


@dataclass
class WorkflowStep:
    """A single step in a workflow."""
    tool_name: str
    function_name: str
    arguments: Dict[str, Any]
    step_name: Optional[str] = None


@dataclass
class WorkflowResult:
    """Result of workflow execution."""
    success: bool
    total_execution_time: float
    total_token_cost: int
    steps_completed: int
    total_steps: int
    results: List[Any]
    step_results: List[ExecutionResult]
    error: Optional[str] = None
    failed_step: Optional[int] = None
    workflow_state: Optional[Dict[str, Any]] = None


class Coordinator:
    """
    Main execution coordinator.

    Features:
    - Execute cached tools with token optimization
    - Check cache for tool existence
    - List available tools
    - Structured error handling
    - Execution logging and metrics
    """

    # Token costs (approximate)
    TOKEN_COST_CACHED = 50
    TOKEN_COST_GENERATION = 650
    TOKEN_COST_UNCACHED = 3750

    def __init__(
        self,
        cache_dir: Optional[str] = None,
        session_manager: Optional[SessionManager] = None
    ):
        """
        Initialize coordinator.

        Args:
            cache_dir: Tool cache directory
            session_manager: Session manager instance (creates new if None)
        """
        self.cache = ToolCache(cache_dir=cache_dir)
        self.agent = ContextAgent()

        if session_manager is None:
            sandbox = Sandbox()
            session_manager = SessionManager(sandbox)
            session_manager.start_cleanup_worker()

        self.session_manager = session_manager
        self.sandbox = session_manager.sandbox

        # Get telemetry instance
        self.telemetry = get_telemetry()

        logger.info("Coordinator initialized")

    def execute_tool(
        self,
        tool_name: str,
        function_name: str,
        arguments: Dict[str, Any],
        session_id: Optional[str] = None,
        timeout: int = 30
    ) -> ExecutionResult:
        """
        Execute a tool function with caching.

        Args:
            tool_name: Name of the tool
            function_name: Function to call
            arguments: Function arguments
            session_id: Session ID (creates new if None)
            timeout: Execution timeout in seconds

        Returns:
            ExecutionResult with execution details
        """
        start_time = time.time()
        logger.info(
            f"[EXEC START] tool={tool_name} function={function_name} "
            f"session_id={session_id or 'new'} timeout={timeout}s"
        )
        logger.debug(f"[EXEC ARGS] {arguments}")

        # Log tool generation request
        self.telemetry.log_event(
            event_type=EventType.TOOL_GENERATION_REQUEST,
            message=f"Tool execution requested: {tool_name}.{function_name}",
            tool_name=tool_name,
            session_id=session_id,
            metadata={'function': function_name, 'timeout': timeout}
        )

        # Create session if needed
        if session_id is None:
            session_id = f"{tool_name}_{int(time.time())}"

        try:
            # Check cache
            metadata = self.cache.check_cache(tool_name)

            if metadata is None:
                # Tool not in cache - delegate to agent to generate
                logger.info(
                    f"[CACHE MISS] tool={tool_name} - delegating to agent for generation")
                logger.info(
                    f"[TOKEN COST] Estimated generation cost: {
                        self.TOKEN_COST_GENERATION} tokens")

                # Log cache miss
                self.telemetry.log_event(
                    event_type=EventType.CACHE_MISS,
                    message=f"Cache miss for tool: {tool_name}",
                    tool_name=tool_name,
                    token_cost=self.TOKEN_COST_GENERATION
                )

                # Generate tool with context agent
                agent_response = self.agent.generate_tool(
                    tool_name=tool_name,
                    api_description=f"{
                        tool_name.replace(
                            '_',
                            ' ').title()} API v1",
                    user_intent=f"Call {function_name} function",
                    validation_required=True)

                # Check if generation succeeded
                if agent_response["status"] != "success":
                    tokens_used = agent_response.get(
                        "research_stats", {}).get(
                        "tokens_absorbed", self.TOKEN_COST_GENERATION)
                    logger.error(
                        f"[GENERATION FAILED] tool={tool_name} tokens={tokens_used} " f"message={
                            agent_response.get('message')}")

                    # Log generation failure
                    self.telemetry.log_event(
                        event_type=EventType.TOOL_GENERATION_FAILURE,
                        message=f"Tool generation failed: {tool_name}",
                        level=LogLevel.ERROR,
                        tool_name=tool_name,
                        token_cost=tokens_used,
                        error=agent_response.get('message'),
                        metadata=agent_response.get("details")
                    )

                    return ExecutionResult(
                        success=False,
                        tool_name=tool_name,
                        execution_time=time.time() - start_time,
                        token_cost=agent_response.get(
                            "research_stats",
                            {}).get(
                            "tokens_absorbed",
                            self.TOKEN_COST_GENERATION),
                        was_cached=False,
                        error=agent_response.get(
                            "message",
                            "Tool generation failed"),
                        error_type=ErrorType.GENERATION_FAILED,
                        suggested_resolution=agent_response.get(
                            "suggested_resolution",
                            "Review error details"),
                        metadata=agent_response.get("details"))

                # Save generated tool to cache
                try:
                    tool_code = agent_response["tool_code"]
                    self.cache.write_tool(
                        tool_name=tool_name,
                        code=tool_code,
                        use_locking=True
                    )
                    generation_tokens = agent_response.get(
                        "research_stats", {}).get(
                        "tokens_absorbed", self.TOKEN_COST_GENERATION)
                    logger.info(
                        f"[GENERATION SUCCESS] tool={tool_name} tokens={generation_tokens} "
                        f"cached=True"
                    )

                    # Log generation success and cache write
                    self.telemetry.log_event(
                        event_type=EventType.TOOL_GENERATION_SUCCESS,
                        message=f"Tool generated successfully: {tool_name}",
                        tool_name=tool_name,
                        token_cost=generation_tokens
                    )
                    self.telemetry.log_event(
                        event_type=EventType.CACHE_WRITE,
                        message=f"Tool cached: {tool_name}",
                        tool_name=tool_name
                    )

                except CacheError as e:
                    logger.error(f"Failed to cache generated tool: {e}")
                    return self._error_response(
                        tool_name=tool_name,
                        error=f"Generated tool but failed to cache: {str(e)}",
                        error_type=ErrorType.CACHE_ERROR,
                        start_time=start_time,
                        was_cached=False
                    )

            # Load tool from cache
            tool_module = self.cache.load_tool(tool_name, validate=True)
            logger.info(f"[CACHE HIT] tool={tool_name} loading from cache")
            logger.info(
                f"[TOKEN COST] Cached execution cost: {
                    self.TOKEN_COST_CACHED} tokens")

            # Log cache hit
            self.telemetry.log_event(
                event_type=EventType.CACHE_HIT,
                message=f"Cache hit for tool: {tool_name}",
                tool_name=tool_name,
                token_cost=self.TOKEN_COST_CACHED
            )

            # Create or get session
            try:
                if self.session_manager.get_session_info(session_id) is None:
                    self.session_manager.create_session(session_id)
            except SessionLimitError as e:
                return self._error_response(
                    tool_name=tool_name,
                    error=str(e),
                    error_type=ErrorType.SESSION_LIMIT_ERROR,
                    start_time=start_time,
                    was_cached=True
                )

            # Build execution code
            exec_code = f"""
{tool_module.code}

# Call the function and store result
RESULT = {function_name}(**{arguments!r})
"""

            # Execute in sandbox
            result = self.sandbox.execute_code(
                session_id=session_id,
                code=exec_code,
                timeout=timeout
            )

            # Update session activity
            self.session_manager.update_activity(
                session_id,
                result.get('memory_used_mb', 0)
            )

            execution_time = time.time() - start_time

            # Log sandbox execution
            self.telemetry.log_event(
                event_type=EventType.SANDBOX_EXECUTION,
                message=f"Sandbox execution: {tool_name}.{function_name}",
                tool_name=tool_name,
                session_id=session_id,
                duration_ms=execution_time * 1000,
                memory_mb=result.get('memory_used_mb', 0),
                metadata={'success': result['success']}
            )

            if result['success']:
                logger.info(
                    f"[EXEC SUCCESS] tool={tool_name} function={function_name} " f"time={
                        execution_time:.3f}s tokens={
                        self.TOKEN_COST_CACHED} " f"memory={
                        result.get(
                            'memory_used_mb',
                            0):.2f}MB cached=True")

                return ExecutionResult(
                    success=True,
                    tool_name=tool_name,
                    execution_time=execution_time,
                    token_cost=self.TOKEN_COST_CACHED,
                    was_cached=True,
                    result=result.get('result'),
                    metadata={
                        'function': function_name,
                        'memory_used_mb': result.get('memory_used_mb', 0),
                        'session_id': session_id
                    }
                )
            else:
                # Execution failed
                error_type = self._classify_error(result)

                logger.error(
                    f"[EXEC FAILED] tool={tool_name} function={function_name} " f"time={
                        execution_time:.3f}s error_type={
                        error_type.value} " f"error={
                        result.get('error')}")

                return self._error_response(
                    tool_name=tool_name,
                    error=result.get('error', 'Unknown error'),
                    error_type=error_type,
                    start_time=start_time,
                    was_cached=True,
                    details=result
                )

        except CacheError as e:
            logger.error(f"[CACHE ERROR] tool={tool_name} error={str(e)}")
            return self._error_response(
                tool_name=tool_name,
                error=str(e),
                error_type=ErrorType.CACHE_ERROR,
                start_time=start_time,
                was_cached=False
            )

        except Exception as e:
            logger.error(
                f"[UNEXPECTED ERROR] tool={tool_name} error={
                    type(e).__name__}: {
                    str(e)}\n" f"{
                    traceback.format_exc()}")
            return self._error_response(
                tool_name=tool_name,
                error=f"{type(e).__name__}: {str(e)}",
                error_type=ErrorType.EXECUTION_ERROR,
                start_time=start_time,
                was_cached=False
            )

    def execute_workflow(
        self,
        steps: List[WorkflowStep],
        session_id: Optional[str] = None,
        timeout: int = 30,
        pass_results: bool = True
    ) -> WorkflowResult:
        """
        Execute a multi-tool workflow with state management.

        Args:
            steps: List of workflow steps to execute
            session_id: Shared session ID for all steps (creates new if None)
            timeout: Execution timeout per step in seconds
            pass_results: Whether to pass results between steps (default: True)

        Returns:
            WorkflowResult with execution details and all step results
        """
        start_time = time.time()
        logger.info(
            f"[WORKFLOW START] steps={
                len(steps)} session_id={
                session_id or 'new'} " f"pass_results={pass_results}")

        # Create shared session if not provided
        if session_id is None:
            session_id = f"workflow_{int(time.time())}"

        step_results: List[ExecutionResult] = []
        results: List[Any] = []
        workflow_state: Dict[str, Any] = {}
        total_token_cost = 0

        for step_idx, step in enumerate(steps):
            step_name = step.step_name or f"Step {step_idx + 1}"
            logger.info(
                f"[WORKFLOW STEP] index={step_idx + 1}/{len(steps)} name={step_name} "
                f"tool={step.tool_name} function={step.function_name}"
            )

            # Prepare arguments - optionally inject previous results
            arguments = step.arguments.copy()
            if pass_results and step_idx > 0:
                # Make previous result available in workflow_state
                workflow_state[f'step_{step_idx}_result'] = results[-1] if results else None
                workflow_state['previous_result'] = results[-1] if results else None

            try:
                # Execute step with shared session
                result = self.execute_tool(
                    tool_name=step.tool_name,
                    function_name=step.function_name,
                    arguments=arguments,
                    session_id=session_id,
                    timeout=timeout
                )

                step_results.append(result)
                total_token_cost += result.token_cost

                if not result.success:
                    # Step failed - return workflow failure
                    error_msg = (
                        f"Workflow failed at {step_name} "
                        f"({step.tool_name}.{step.function_name}): {result.error}"
                    )
                    logger.error(
                        f"[WORKFLOW FAILED] step={step_idx + 1}/{len(steps)} "
                        f"tool={step.tool_name} tokens={total_token_cost} "
                        f"error={result.error}"
                    )

                    return WorkflowResult(
                        success=False,
                        total_execution_time=time.time() - start_time,
                        total_token_cost=total_token_cost,
                        steps_completed=step_idx,
                        total_steps=len(steps),
                        results=results,
                        step_results=step_results,
                        error=error_msg,
                        failed_step=step_idx,
                        workflow_state=workflow_state
                    )

                # Step succeeded - store result
                results.append(result.result)
                logger.info(
                    f"[WORKFLOW STEP SUCCESS] step={step_idx + 1}/{len(steps)} "
                    f"name={step_name} tokens={result.token_cost}"
                )

            except Exception as e:
                # Unexpected error during step execution
                error_msg = (
                    f"Workflow failed at {step_name} "
                    f"({step.tool_name}.{step.function_name}): {type(e).__name__}: {str(e)}"
                )
                logger.error(
                    f"[WORKFLOW ERROR] step={
                        step_idx + 1}/{
                        len(steps)} " f"error={
                        type(e).__name__}: {
                        str(e)}\n{
                        traceback.format_exc()}")

                # Create error result for failed step
                error_result = ExecutionResult(
                    success=False,
                    tool_name=step.tool_name,
                    execution_time=time.time() - start_time,
                    token_cost=0,
                    was_cached=False,
                    error=str(e),
                    error_type=ErrorType.EXECUTION_ERROR
                )
                step_results.append(error_result)

                return WorkflowResult(
                    success=False,
                    total_execution_time=time.time() - start_time,
                    total_token_cost=total_token_cost,
                    steps_completed=step_idx,
                    total_steps=len(steps),
                    results=results,
                    step_results=step_results,
                    error=error_msg,
                    failed_step=step_idx,
                    workflow_state=workflow_state
                )

        # All steps completed successfully
        total_time = time.time() - start_time
        logger.info(
            f"[WORKFLOW SUCCESS] steps={len(steps)} time={total_time:.3f}s "
            f"tokens={total_token_cost}"
        )

        return WorkflowResult(
            success=True,
            total_execution_time=total_time,
            total_token_cost=total_token_cost,
            steps_completed=len(steps),
            total_steps=len(steps),
            results=results,
            step_results=step_results,
            workflow_state=workflow_state
        )

    def check_cache(self, tool_name: str) -> CacheCheckResult:
        """
        Check if a tool exists in cache.

        Args:
            tool_name: Name of the tool

        Returns:
            CacheCheckResult with existence and metadata
        """
        logger.info(f"[CACHE CHECK] tool={tool_name}")

        metadata = self.cache.check_cache(tool_name)

        if metadata:
            logger.debug(
                f"[CACHE CHECK HIT] tool={tool_name} functions={len(metadata.functions)} "
                f"size={metadata.size_bytes / 1024:.1f}KB"
            )
            return CacheCheckResult(
                exists=True,
                tool_name=tool_name,
                token_cost=self.TOKEN_COST_CACHED,
                metadata={
                    'description': metadata.description,
                    'functions': metadata.functions,
                    'api_type': metadata.api_type,
                    'size_bytes': metadata.size_bytes,
                    'modified_at': metadata.modified_at.isoformat()
                }
            )
        else:
            logger.debug(f"[CACHE CHECK MISS] tool={tool_name}")
            return CacheCheckResult(
                exists=False,
                tool_name=tool_name,
                token_cost=self.TOKEN_COST_GENERATION
            )

    def list_tools(self, pattern: str = "*.py") -> ToolList:
        """
        List all cached tools.

        Args:
            pattern: Glob pattern for filtering

        Returns:
            ToolList with tool metadata
        """
        logger.info(f"[LIST TOOLS] pattern={pattern}")

        tools = self.cache.list_tools(pattern)
        cache_stats = self.cache.get_cache_stats()

        logger.debug(f"[LIST TOOLS RESULT] found={len(tools)} tools")

        tool_list = [
            {
                'name': tool.name,
                'description': tool.description,
                'api_type': tool.api_type,
                'functions': tool.functions,
                'size_bytes': tool.size_bytes,
                'modified_at': tool.modified_at.isoformat()
            }
            for tool in tools
        ]

        return ToolList(
            tools=tool_list,
            total_count=len(tool_list),
            cache_stats=cache_stats
        )

    def invalidate_cache(self, tool_name: str) -> bool:
        """
        Invalidate a cached tool to force regeneration.

        Args:
            tool_name: Name of the tool

        Returns:
            True if tool was invalidated
        """
        logger.info(f"[CACHE INVALIDATE] tool={tool_name}")
        result = self.cache.invalidate_cache(tool_name)
        if result:
            logger.info(f"[CACHE INVALIDATE SUCCESS] tool={tool_name}")
        else:
            logger.warning(f"[CACHE INVALIDATE NOT FOUND] tool={tool_name}")
        return result

    def _classify_error(self, result: Dict[str, Any]) -> ErrorType:
        """
        Classify error type from execution result.

        Args:
            result: Execution result dict

        Returns:
            ErrorType enum value
        """
        error_type_str = result.get('error_type', '')

        if error_type_str == 'sandbox_violation':
            return ErrorType.SANDBOX_VIOLATION
        elif error_type_str == 'memory_exceeded':
            return ErrorType.MEMORY_EXCEEDED
        elif 'timeout' in error_type_str.lower():
            return ErrorType.TIMEOUT_ERROR
        else:
            return ErrorType.EXECUTION_ERROR

    def _error_response(
        self,
        tool_name: str,
        error: str,
        error_type: ErrorType,
        start_time: float,
        was_cached: bool,
        details: Optional[Dict] = None
    ) -> ExecutionResult:
        """
        Create structured error response.

        Args:
            tool_name: Tool name
            error: Error message
            error_type: Error type enum
            start_time: Execution start time
            was_cached: Whether tool was from cache
            details: Additional error details

        Returns:
            ExecutionResult with error information
        """
        suggested_resolution = self._get_resolution_suggestion(error_type)

        return ExecutionResult(
            success=False,
            tool_name=tool_name,
            execution_time=time.time() - start_time,
            token_cost=self.TOKEN_COST_CACHED if was_cached else 0,
            was_cached=was_cached,
            error=error,
            error_type=error_type,
            suggested_resolution=suggested_resolution,
            metadata=details
        )

    def _get_resolution_suggestion(self, error_type: ErrorType) -> str:
        """
        Get suggested resolution for error type.

        Args:
            error_type: Error type enum

        Returns:
            Suggestion string
        """
        suggestions = {
            ErrorType.RATE_LIMITED: "Wait and retry after the specified time. Consider reducing request frequency.",
            ErrorType.AUTH_ERROR: "Check credentials and re-authenticate if needed. Run auth flow for the required scope.",
            ErrorType.VALIDATION_ERROR: "Verify input parameters match the expected format and types.",
            ErrorType.GENERATION_FAILED: "Tool generation failed. Check API documentation availability.",
            ErrorType.SANDBOX_VIOLATION: "Tool attempted blocked operation. Review tool code for security violations.",
            ErrorType.MEMORY_EXCEEDED: "Reduce data size or processing complexity. Consider breaking into smaller operations.",
            ErrorType.TIMEOUT_ERROR: "Operation took too long. Increase timeout or optimize the operation.",
            ErrorType.EXECUTION_ERROR: "Check error details for specific issue. Review tool implementation.",
            ErrorType.CACHE_ERROR: "Cache operation failed. Check file permissions and disk space.",
            ErrorType.SESSION_LIMIT_ERROR: "Too many active sessions. Wait for idle sessions to be cleaned up."}

        return suggestions.get(error_type,
                               "Review error details and try again.")

    def get_stats(self) -> Dict[str, Any]:
        """
        Get coordinator statistics including telemetry data.

        Returns:
            Dict with comprehensive stats
        """
        telemetry_stats = self.telemetry.get_stats()

        return {
            'cache_stats': self.cache.get_cache_stats(),
            'session_stats': self.session_manager.get_stats(),
            'token_costs': {
                'cached': self.TOKEN_COST_CACHED,
                'generation': self.TOKEN_COST_GENERATION,
                'uncached': self.TOKEN_COST_UNCACHED
            },
            'telemetry': telemetry_stats
        }
