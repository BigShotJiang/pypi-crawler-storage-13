"""
Structured telemetry and metrics collection for fastools executor.

This module provides:
- JSON structured logging with contextual fields
- Metrics collection and aggregation
- Session tracking and analysis
- Optional Prometheus metrics export
"""

import json
import logging
import threading
import time
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set


class LogLevel(str, Enum):
    """Standard log levels."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class EventType(str, Enum):
    """Types of telemetry events."""
    TOOL_GENERATION_REQUEST = "tool_generation_request"
    TOOL_GENERATION_SUCCESS = "tool_generation_success"
    TOOL_GENERATION_FAILURE = "tool_generation_failure"
    CACHE_HIT = "cache_hit"
    CACHE_MISS = "cache_miss"
    CACHE_WRITE = "cache_write"
    CACHE_ERROR = "cache_error"
    SANDBOX_EXECUTION = "sandbox_execution"
    SANDBOX_VIOLATION = "sandbox_violation"
    AUTH_SUCCESS = "auth_success"
    AUTH_FAILURE = "auth_failure"
    RESOURCE_QUOTA_VIOLATION = "resource_quota_violation"
    SESSION_CREATED = "session_created"
    SESSION_DESTROYED = "session_destroyed"
    EXECUTION_ERROR = "execution_error"
    WORKFLOW_START = "workflow_start"
    WORKFLOW_COMPLETE = "workflow_complete"
    WORKFLOW_FAILED = "workflow_failed"


@dataclass
class TelemetryEvent:
    """A single telemetry event."""
    timestamp: datetime
    level: LogLevel
    event_type: EventType
    message: str
    session_id: Optional[str] = None
    user: Optional[str] = None
    tool_name: Optional[str] = None
    duration_ms: Optional[float] = None
    token_cost: Optional[int] = None
    memory_mb: Optional[float] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        data = {
            'timestamp': self.timestamp.isoformat(),
            'level': self.level.value,
            'event_type': self.event_type.value,
            'message': self.message
        }

        # Add optional fields if present
        if self.session_id:
            data['session_id'] = self.session_id
        if self.user:
            data['user'] = self.user
        if self.tool_name:
            data['tool_name'] = self.tool_name
        if self.duration_ms is not None:
            data['duration_ms'] = self.duration_ms
        if self.token_cost is not None:
            data['token_cost'] = self.token_cost
        if self.memory_mb is not None:
            data['memory_mb'] = self.memory_mb
        if self.error:
            data['error'] = self.error
        if self.metadata:
            data['metadata'] = self.metadata

        return data


@dataclass
class MetricSnapshot:
    """Point-in-time snapshot of metrics."""
    timestamp: datetime

    # Cache metrics
    cache_hits: int = 0
    cache_misses: int = 0
    cache_writes: int = 0
    cache_errors: int = 0

    # Tool generation metrics
    tools_generated: int = 0
    generation_successes: int = 0
    generation_failures: int = 0

    # Sandbox metrics
    sandbox_executions: int = 0
    sandbox_violations: int = 0
    total_execution_time_ms: float = 0.0

    # Resource metrics
    total_memory_mb: float = 0.0
    max_memory_mb: float = 0.0
    active_sessions: int = 0

    # Error metrics
    total_errors: int = 0
    auth_failures: int = 0
    resource_violations: int = 0

    # Token metrics
    total_tokens_used: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        data = asdict(self)
        # Convert datetime to ISO string
        data['timestamp'] = self.timestamp.isoformat()
        return data

    def cache_hit_rate(self) -> float:
        """Calculate cache hit rate."""
        total = self.cache_hits + self.cache_misses
        return self.cache_hits / total if total > 0 else 0.0

    def generation_success_rate(self) -> float:
        """Calculate tool generation success rate."""
        total = self.generation_successes + self.generation_failures
        return self.generation_successes / total if total > 0 else 0.0

    def avg_execution_time_ms(self) -> float:
        """Calculate average execution time."""
        return (self.total_execution_time_ms / self.sandbox_executions
                if self.sandbox_executions > 0 else 0.0)


class StructuredLogger:
    """JSON structured logger with contextual fields."""

    def __init__(self, name: str, log_file: Optional[Path] = None):
        """
        Initialize structured logger.

        Args:
            name: Logger name
            log_file: Optional log file path
        """
        self.name = name
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)

        # Console handler with JSON formatter
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(JsonFormatter())
        self.logger.addHandler(console_handler)

        # File handler if specified
        if log_file:
            log_file.parent.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(log_file)
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(JsonFormatter())
            self.logger.addHandler(file_handler)

    def log_event(self, event: TelemetryEvent):
        """Log a telemetry event."""
        log_data = event.to_dict()

        # Map level to logging function
        level_map = {
            LogLevel.DEBUG: self.logger.debug,
            LogLevel.INFO: self.logger.info,
            LogLevel.WARNING: self.logger.warning,
            LogLevel.ERROR: self.logger.error,
            LogLevel.CRITICAL: self.logger.critical
        }

        log_func = level_map.get(event.level, self.logger.info)
        log_func(json.dumps(log_data))


class JsonFormatter(logging.Formatter):
    """JSON log formatter."""

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        # If message is already JSON, use it directly
        try:
            data = json.loads(record.getMessage())
            return json.dumps(data)
        except (json.JSONDecodeError, ValueError):
            # Not JSON - create structured record
            log_data = {
                'timestamp': datetime.utcnow().isoformat(),
                'level': record.levelname,
                'logger': record.name,
                'message': record.getMessage()
            }

            if record.exc_info:
                log_data['exception'] = self.formatException(record.exc_info)

            return json.dumps(log_data)


class MetricsCollector:
    """
    Metrics collection and aggregation.

    Collects metrics in-memory with periodic persistence.
    Thread-safe for concurrent access.
    """

    def __init__(self, persist_dir: Optional[Path] = None):
        """
        Initialize metrics collector.

        Args:
            persist_dir: Optional directory for metric persistence
        """
        self.persist_dir = persist_dir
        if persist_dir:
            persist_dir.mkdir(parents=True, exist_ok=True)

        # Current metrics (thread-safe)
        self._lock = threading.RLock()
        self._current = MetricSnapshot(timestamp=datetime.utcnow())

        # Historical snapshots (last 24 hours, hourly)
        self._history: List[MetricSnapshot] = []
        self._max_history = 24  # Keep 24 hours of hourly snapshots

        # Recent events for error analysis (last 100)
        self._recent_events: List[TelemetryEvent] = []
        self._max_events = 100

        # Session tracking
        self._session_start_times: Dict[str, datetime] = {}
        self._session_metrics: Dict[str, MetricSnapshot] = {}

    def record_event(self, event: TelemetryEvent):
        """
        Record a telemetry event and update metrics.

        Args:
            event: Telemetry event to record
        """
        with self._lock:
            # Store recent event
            self._recent_events.append(event)
            if len(self._recent_events) > self._max_events:
                self._recent_events.pop(0)

            # Update current metrics based on event type
            if event.event_type == EventType.CACHE_HIT:
                self._current.cache_hits += 1
            elif event.event_type == EventType.CACHE_MISS:
                self._current.cache_misses += 1
            elif event.event_type == EventType.CACHE_WRITE:
                self._current.cache_writes += 1
            elif event.event_type == EventType.CACHE_ERROR:
                self._current.cache_errors += 1
            elif event.event_type == EventType.TOOL_GENERATION_SUCCESS:
                self._current.tools_generated += 1
                self._current.generation_successes += 1
            elif event.event_type == EventType.TOOL_GENERATION_FAILURE:
                self._current.generation_failures += 1
            elif event.event_type == EventType.SANDBOX_EXECUTION:
                self._current.sandbox_executions += 1
                if event.duration_ms:
                    self._current.total_execution_time_ms += event.duration_ms
            elif event.event_type == EventType.SANDBOX_VIOLATION:
                self._current.sandbox_violations += 1
            elif event.event_type == EventType.AUTH_FAILURE:
                self._current.auth_failures += 1
            elif event.event_type == EventType.RESOURCE_QUOTA_VIOLATION:
                self._current.resource_violations += 1
            elif event.event_type == EventType.EXECUTION_ERROR:
                self._current.total_errors += 1

            # Update token metrics
            if event.token_cost:
                self._current.total_tokens_used += event.token_cost

            # Update memory metrics
            if event.memory_mb:
                self._current.total_memory_mb = event.memory_mb
                self._current.max_memory_mb = max(
                    self._current.max_memory_mb,
                    event.memory_mb
                )

            # Track session-specific metrics
            if event.session_id:
                if event.event_type == EventType.SESSION_CREATED:
                    self._session_start_times[event.session_id] = event.timestamp
                    self._session_metrics[event.session_id] = MetricSnapshot(
                        timestamp=event.timestamp
                    )
                    self._current.active_sessions = len(
                        self._session_start_times)
                elif event.event_type == EventType.SESSION_DESTROYED:
                    self._session_start_times.pop(event.session_id, None)
                    self._session_metrics.pop(event.session_id, None)
                    self._current.active_sessions = len(
                        self._session_start_times)

    def get_current_snapshot(self) -> MetricSnapshot:
        """Get current metric snapshot."""
        with self._lock:
            snapshot = MetricSnapshot(timestamp=datetime.utcnow())
            snapshot.__dict__.update(self._current.__dict__)
            snapshot.timestamp = datetime.utcnow()
            return snapshot

    def get_recent_errors(self, limit: int = 10) -> List[TelemetryEvent]:
        """
        Get recent error events.

        Args:
            limit: Maximum number of errors to return

        Returns:
            List of recent error events
        """
        with self._lock:
            errors = [
                e for e in self._recent_events
                if e.level in (LogLevel.ERROR, LogLevel.CRITICAL)
            ]
            return errors[-limit:]

    def get_session_summary(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get summary for a specific session.

        Args:
            session_id: Session identifier

        Returns:
            Session summary dict or None if not found
        """
        with self._lock:
            if session_id not in self._session_start_times:
                return None

            start_time = self._session_start_times[session_id]
            metrics = self._session_metrics.get(
                session_id,
                MetricSnapshot(timestamp=start_time)
            )

            return {
                'session_id': session_id,
                'start_time': start_time.isoformat(),
                'duration_seconds': (
                    datetime.utcnow() -
                    start_time).total_seconds(),
                'metrics': metrics.to_dict()}

    def get_all_sessions_summary(self) -> List[Dict[str, Any]]:
        """Get summary for all active sessions."""
        with self._lock:
            return [
                self.get_session_summary(sid)
                for sid in self._session_start_times.keys()
            ]

    def take_snapshot(self):
        """Take a snapshot of current metrics and add to history."""
        with self._lock:
            snapshot = self.get_current_snapshot()
            self._history.append(snapshot)

            # Trim history
            if len(self._history) > self._max_history:
                self._history.pop(0)

            # Persist if configured
            if self.persist_dir:
                self._persist_snapshot(snapshot)

    def _persist_snapshot(self, snapshot: MetricSnapshot):
        """Persist snapshot to disk."""
        if not self.persist_dir:
            return

        filename = f"metrics_{
            snapshot.timestamp.strftime('%Y%m%d_%H%M%S')}.json"
        filepath = self.persist_dir / filename

        with open(filepath, 'w') as f:
            json.dump(snapshot.to_dict(), f, indent=2)

    def reset_current(self):
        """Reset current metrics (used for testing or periodic resets)."""
        with self._lock:
            self._current = MetricSnapshot(timestamp=datetime.utcnow())


class TelemetryManager:
    """
    Main telemetry manager coordinating logging and metrics.

    Provides a unified interface for telemetry operations.
    """

    def __init__(
        self,
        name: str = "fastools",
        log_dir: Optional[Path] = None,
        metrics_dir: Optional[Path] = None
    ):
        """
        Initialize telemetry manager.

        Args:
            name: Application name
            log_dir: Optional directory for log files
            metrics_dir: Optional directory for metrics persistence
        """
        self.name = name

        # Setup structured logging
        log_file = log_dir / f"{name}.log" if log_dir else None
        self.logger = StructuredLogger(name, log_file)

        # Setup metrics collection
        self.metrics = MetricsCollector(metrics_dir)

        # Default context (can be overridden per-call)
        self.default_context: Dict[str, Any] = {}

    def log_event(
        self,
        event_type: EventType,
        message: str,
        level: LogLevel = LogLevel.INFO,
        **kwargs
    ):
        """
        Log an event with automatic metrics recording.

        Args:
            event_type: Type of event
            message: Event message
            level: Log level
            **kwargs: Additional event fields (session_id, user, tool_name, etc.)
        """
        # Create event
        event = TelemetryEvent(
            timestamp=datetime.utcnow(),
            level=level,
            event_type=event_type,
            message=message,
            **{**self.default_context, **kwargs}
        )

        # Log to structured logger
        self.logger.log_event(event)

        # Record in metrics
        self.metrics.record_event(event)

    @contextmanager
    def track_operation(
        self,
        event_type: EventType,
        operation_name: str,
        **context
    ):
        """
        Context manager for tracking operation duration.

        Args:
            event_type: Type of event
            operation_name: Name of operation
            **context: Additional context fields

        Yields:
            Dict that can be updated with result metadata
        """
        start_time = time.time()
        metadata = {}
        error = None

        try:
            yield metadata
        except Exception as e:
            error = str(e)
            raise
        finally:
            duration_ms = (time.time() - start_time) * 1000

            self.log_event(
                event_type=event_type,
                message=f"{operation_name} completed" if not error else f"{operation_name} failed",
                level=LogLevel.INFO if not error else LogLevel.ERROR,
                duration_ms=duration_ms,
                error=error,
                metadata=metadata,
                **context)

    def get_stats(self) -> Dict[str, Any]:
        """
        Get comprehensive telemetry statistics.

        Returns:
            Dict with metrics, recent errors, and session info
        """
        snapshot = self.metrics.get_current_snapshot()

        return {
            'timestamp': datetime.utcnow().isoformat(),
            'current_metrics': snapshot.to_dict(),
            'computed_metrics': {
                'cache_hit_rate': snapshot.cache_hit_rate(),
                'generation_success_rate': snapshot.generation_success_rate(),
                'avg_execution_time_ms': snapshot.avg_execution_time_ms()
            },
            'recent_errors': [
                e.to_dict() for e in self.metrics.get_recent_errors(limit=10)
            ],
            'active_sessions': self.metrics.get_all_sessions_summary()
        }

    def set_context(self, **context):
        """Set default context for all events."""
        self.default_context.update(context)

    def clear_context(self):
        """Clear default context."""
        self.default_context.clear()


# Global telemetry instance (can be configured)
_telemetry: Optional[TelemetryManager] = None


def get_telemetry() -> TelemetryManager:
    """
    Get global telemetry instance.

    Returns:
        TelemetryManager instance
    """
    global _telemetry
    if _telemetry is None:
        # Initialize with default settings
        log_dir = Path.home() / ".claude" / "tools" / "logs"
        metrics_dir = Path.home() / ".claude" / "tools" / "metrics"
        _telemetry = TelemetryManager(
            name="fastools",
            log_dir=log_dir,
            metrics_dir=metrics_dir
        )
    return _telemetry


def configure_telemetry(
    name: str = "fastools",
    log_dir: Optional[Path] = None,
    metrics_dir: Optional[Path] = None
) -> TelemetryManager:
    """
    Configure global telemetry instance.

    Args:
        name: Application name
        log_dir: Optional log directory
        metrics_dir: Optional metrics directory

    Returns:
        Configured TelemetryManager
    """
    global _telemetry
    _telemetry = TelemetryManager(
        name=name,
        log_dir=log_dir,
        metrics_dir=metrics_dir
    )
    return _telemetry
