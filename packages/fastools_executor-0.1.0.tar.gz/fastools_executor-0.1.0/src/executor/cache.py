"""
Tool cache management for dynamically generated tools.

This module handles discovering, loading, and caching tools in the ~/.claude/tools/ directory.
"""

import ast
import fcntl
import glob
import hashlib
import json
import os
import re
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class ToolMetadata:
    """Metadata extracted from a cached tool."""
    name: str
    file_path: str
    description: str
    api_type: Optional[str]
    functions: List[str]
    created_at: Optional[datetime]
    modified_at: datetime
    size_bytes: int
    line_count: int
    checksum: Optional[str] = None  # SHA256 checksum
    schema_version: str = "1.0"  # Cache format version


@dataclass
class ToolModule:
    """Loaded tool module with metadata."""
    metadata: ToolMetadata
    code: str
    ast_tree: ast.Module
    module: Any  # The actual Python module after import


class CacheError(Exception):
    """Base exception for cache operations."""
    pass


class CacheLockError(Exception):
    """Raised when cache lock cannot be acquired."""
    pass


class CacheCorruptionError(Exception):
    """Raised when cached tool file is corrupted."""
    pass


class SchemaValidationError(Exception):
    """Raised when cache schema validation fails."""
    pass


class ToolCache:
    """
    Manages the tool cache at ~/.claude/tools/.

    Features:
    - Tool discovery with glob patterns
    - Metadata extraction from tool files
    - Syntax validation using ast.parse()
    - Schema validation with versioning
    - SHA256 checksums for integrity
    - Corruption detection and recovery
    - Atomic writes for cache safety
    - File locking for concurrency
    - Cache invalidation
    """

    SCHEMA_VERSION = "1.0"
    CHECKSUM_FILE_SUFFIX = ".sha256"

    def __init__(
        self,
        cache_dir: Optional[str] = None,
        lock_timeout: float = 5.0,
        stale_lock_timeout: float = 60.0,
        enable_checksums: bool = True,
        enable_schema_validation: bool = True
    ):
        """
        Initialize tool cache.

        Args:
            cache_dir: Cache directory path (default: ~/.claude/tools)
            lock_timeout: Maximum time to wait for lock in seconds (default: 5)
            stale_lock_timeout: Time after which locks are considered stale in seconds (default: 60)
            enable_checksums: Enable checksum validation (default: True)
            enable_schema_validation: Enable schema validation (default: True)
        """
        if cache_dir is None:
            cache_dir = os.path.expanduser('~/.claude/tools')

        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.lock_timeout = lock_timeout
        self.stale_lock_timeout = stale_lock_timeout
        self.enable_checksums = enable_checksums
        self.enable_schema_validation = enable_schema_validation

        # Create metadata directory for checksums and schema info
        self.metadata_dir = self.cache_dir / '.metadata'
        self.metadata_dir.mkdir(exist_ok=True)

    def _calculate_checksum(self, content: str) -> str:
        """
        Calculate SHA256 checksum for content.

        Args:
            content: Content to checksum

        Returns:
            Hexadecimal checksum string
        """
        return hashlib.sha256(content.encode('utf-8')).hexdigest()

    def _save_checksum(self, tool_name: str, checksum: str):
        """
        Save checksum to metadata directory.

        Args:
            tool_name: Name of the tool
            checksum: Checksum to save
        """
        checksum_path = self.metadata_dir / \
            f"{tool_name}{self.CHECKSUM_FILE_SUFFIX}"
        with open(checksum_path, 'w') as f:
            f.write(checksum)

    def _load_checksum(self, tool_name: str) -> Optional[str]:
        """
        Load checksum from metadata directory.

        Args:
            tool_name: Name of the tool

        Returns:
            Checksum string or None if not found
        """
        checksum_path = self.metadata_dir / \
            f"{tool_name}{self.CHECKSUM_FILE_SUFFIX}"
        if not checksum_path.exists():
            return None

        try:
            with open(checksum_path, 'r') as f:
                return f.read().strip()
        except Exception:
            return None

    def _verify_checksum(self, tool_name: str, content: str) -> bool:
        """
        Verify content checksum against stored checksum.

        Args:
            tool_name: Name of the tool
            content: Content to verify

        Returns:
            True if checksum matches, False otherwise
        """
        if not self.enable_checksums:
            return True

        stored_checksum = self._load_checksum(tool_name)
        if stored_checksum is None:
            # No checksum stored - regenerate it
            return True

        calculated_checksum = self._calculate_checksum(content)
        return calculated_checksum == stored_checksum

    def _validate_cache_schema(self, metadata_dict: Dict[str, Any]) -> bool:
        """
        Validate cache metadata against schema.

        Args:
            metadata_dict: Metadata dictionary to validate

        Returns:
            True if valid, False otherwise

        Raises:
            SchemaValidationError: If schema validation fails
        """
        if not self.enable_schema_validation:
            return True

        required_fields = {
            'name': str,
            'file_path': str,
            'description': str,
            'functions': list,
            'modified_at': (str, datetime),
            'size_bytes': int,
            'line_count': int,
            'schema_version': str
        }

        # Check required fields
        for field, expected_type in required_fields.items():
            if field not in metadata_dict:
                raise SchemaValidationError(f"Missing required field: {field}")

            value = metadata_dict[field]
            if not isinstance(value, expected_type):
                raise SchemaValidationError(
                    f"Invalid type for {field}: expected {expected_type}, got {
                        type(value)}")

        # Validate schema version
        if metadata_dict.get('schema_version') != self.SCHEMA_VERSION:
            # Allow migration from older schemas
            self._migrate_schema(metadata_dict)

        return True

    def _migrate_schema(self, metadata_dict: Dict[str, Any]):
        """
        Migrate metadata from older schema versions.

        Args:
            metadata_dict: Metadata to migrate (modified in place)
        """
        old_version = metadata_dict.get('schema_version', '0.0')

        # Migration logic for future schema changes
        if old_version == '0.0':
            # Add new fields introduced in 1.0
            metadata_dict.setdefault('checksum', None)
            metadata_dict['schema_version'] = '1.0'

    def _acquire_file_lock(
            self,
            file_path: Path,
            timeout: Optional[float] = None) -> bool:
        """
        Acquire file lock using fcntl (Unix) for concurrent access.

        Args:
            file_path: Path to file to lock
            timeout: Lock timeout (uses self.lock_timeout if None)

        Returns:
            True if lock acquired

        Raises:
            CacheLockError: If unable to acquire lock
        """
        if timeout is None:
            timeout = self.lock_timeout

        lock_file = open(file_path, 'a')
        start_time = time.time()

        while True:
            try:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                return True
            except IOError:
                elapsed = time.time() - start_time
                if elapsed >= timeout:
                    lock_file.close()
                    raise CacheLockError(
                        f"Could not acquire file lock for {file_path} within {timeout}s")
                time.sleep(0.05)

    def _release_file_lock(self, file_path: Path):
        """
        Release file lock.

        Args:
            file_path: Path to file to unlock
        """
        try:
            with open(file_path, 'r') as lock_file:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
        except Exception as e:
            print(f"Warning: Failed to release file lock for {file_path}: {e}")

    def list_tools(self, pattern: str = "*.py") -> List[ToolMetadata]:
        """
        List all tools in cache matching pattern.

        Args:
            pattern: Glob pattern for file matching (default: *.py)

        Returns:
            List of ToolMetadata for matching tools
        """
        tools = []
        search_path = self.cache_dir / pattern

        for file_path in glob.glob(str(search_path)):
            if file_path.endswith('.lock'):
                continue  # Skip lock files

            try:
                metadata = self._extract_metadata(file_path)
                tools.append(metadata)
            except Exception as e:
                # Log error but continue with other tools
                print(
                    f"Warning: Failed to extract metadata from {file_path}: {e}")
                continue

        # Sort by modification time (newest first)
        tools.sort(key=lambda t: t.modified_at, reverse=True)
        return tools

    def check_cache(self, tool_name: str) -> Optional[ToolMetadata]:
        """
        Check if a tool exists in cache and return its metadata.

        Args:
            tool_name: Name of the tool (without .py extension)

        Returns:
            ToolMetadata if tool exists, None otherwise
        """
        file_path = self.cache_dir / f"{tool_name}.py"

        if not file_path.exists():
            return None

        try:
            # Read content for validation
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Check syntax corruption
            if not self._validate_tool_syntax(str(file_path)):
                # Corrupted file - attempt recovery
                self._handle_corruption(
                    tool_name, file_path, content, "syntax_error")
                return None

            # Verify checksum if enabled
            if self.enable_checksums and not self._verify_checksum(
                    tool_name, content):
                # Checksum mismatch - attempt recovery
                self._handle_corruption(
                    tool_name, file_path, content, "checksum_mismatch")
                return None

            return self._extract_metadata(str(file_path))
        except Exception as e:
            raise CacheError(f"Failed to check cache for '{tool_name}': {e}")

    def _acquire_lock(self, tool_name: str) -> bool:
        """
        Acquire a lock file for tool generation.

        Args:
            tool_name: Name of the tool

        Returns:
            True if lock acquired, False if timeout

        Raises:
            CacheLockError: If unable to acquire lock within timeout
        """
        lock_path = self.cache_dir / f"{tool_name}.lock"
        start_time = time.time()

        while True:
            # Clean stale locks first
            self._clean_stale_lock(lock_path)

            # Try to create lock file
            try:
                # Use exclusive creation (fails if file exists)
                with open(lock_path, 'x') as f:
                    f.write(str(time.time()))
                return True
            except FileExistsError:
                # Lock exists, check timeout
                elapsed = time.time() - start_time
                if elapsed >= self.lock_timeout:
                    raise CacheLockError(
                        f"Could not acquire lock for '{tool_name}' within "
                        f"{self.lock_timeout}s"
                    )

                # Wait a bit before retrying
                time.sleep(0.1)

    def _release_lock(self, tool_name: str):
        """
        Release a lock file.

        Args:
            tool_name: Name of the tool
        """
        lock_path = self.cache_dir / f"{tool_name}.lock"
        try:
            if lock_path.exists():
                lock_path.unlink()
        except Exception as e:
            print(f"Warning: Failed to release lock for '{tool_name}': {e}")

    def _clean_stale_lock(self, lock_path: Path):
        """
        Clean up a stale lock file.

        Args:
            lock_path: Path to the lock file
        """
        if not lock_path.exists():
            return

        try:
            # Check lock age
            lock_age = time.time() - lock_path.stat().st_mtime

            if lock_age > self.stale_lock_timeout:
                print(
                    f"Removing stale lock: {
                        lock_path.name} (age: {
                        lock_age:.1f}s)")
                lock_path.unlink()
        except Exception as e:
            print(f"Warning: Failed to clean stale lock {lock_path}: {e}")

    def _validate_tool_syntax(self, file_path: str) -> bool:
        """
        Validate tool file syntax.

        Args:
            file_path: Path to tool file

        Returns:
            True if valid, False if corrupted
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                code = f.read()

            # Try to parse with AST
            ast.parse(code)
            return True

        except SyntaxError:
            return False
        except Exception:
            # Other errors (file read, etc.) - assume corrupted
            return False

    def _handle_corruption(
        self,
        tool_name: str,
        file_path: Path,
        content: str = None,
        corruption_type: str = "unknown"
    ):
        """
        Handle corrupted tool file with recovery attempts.

        Args:
            tool_name: Name of the tool
            file_path: Path to corrupted file
            content: File content (if available)
            corruption_type: Type of corruption detected
        """
        print(
            f"Warning: Detected corrupted tool file '{tool_name}' ({corruption_type})")

        # Log corruption event
        self._log_corruption_event(tool_name, corruption_type)

        try:
            # Attempt recovery strategies
            recovered = False

            # Strategy 1: Try to salvage backup if exists
            backup_path = self.cache_dir / f"{tool_name}.py.bak"
            if backup_path.exists():
                print(f"Attempting recovery from backup: {backup_path}")
                try:
                    with open(backup_path, 'r', encoding='utf-8') as f:
                        backup_content = f.read()

                    # Validate backup
                    if self._validate_tool_syntax_from_content(backup_content):
                        # Restore from backup
                        with open(file_path, 'w', encoding='utf-8') as f:
                            f.write(backup_content)

                        # Update checksum
                        if self.enable_checksums:
                            checksum = self._calculate_checksum(backup_content)
                            self._save_checksum(tool_name, checksum)

                        print(
                            f"Successfully recovered '{tool_name}' from backup")
                        recovered = True
                except Exception as e:
                    print(f"Backup recovery failed: {e}")

            # Strategy 2: If corruption is only checksum mismatch, update
            # checksum
            if not recovered and corruption_type == "checksum_mismatch" and content:
                if self._validate_tool_syntax_from_content(content):
                    print(
                        f"Checksum mismatch but syntax valid, updating checksum")
                    checksum = self._calculate_checksum(content)
                    self._save_checksum(tool_name, checksum)
                    recovered = True

            # If recovery failed, delete corrupted file
            if not recovered:
                file_path.unlink()
                print(f"Deleted corrupted file: {file_path}")

                # Clean up associated metadata
                checksum_path = self.metadata_dir / \
                    f"{tool_name}{self.CHECKSUM_FILE_SUFFIX}"
                if checksum_path.exists():
                    checksum_path.unlink()

                # Trigger regeneration will happen automatically on next
                # request

        except Exception as e:
            print(f"Error handling corruption for '{tool_name}': {e}")
            raise CacheCorruptionError(
                f"Failed to handle corruption for '{tool_name}': {e}")

    def _validate_tool_syntax_from_content(self, content: str) -> bool:
        """
        Validate Python syntax from content string.

        Args:
            content: Python code to validate

        Returns:
            True if valid, False otherwise
        """
        try:
            ast.parse(content)
            return True
        except SyntaxError:
            return False
        except Exception:
            return False

    def _log_corruption_event(self, tool_name: str, corruption_type: str):
        """
        Log corruption event to metadata directory.

        Args:
            tool_name: Name of the tool
            corruption_type: Type of corruption
        """
        log_path = self.metadata_dir / "corruption.log"
        try:
            with open(log_path, 'a') as f:
                timestamp = datetime.utcnow().isoformat()
                f.write(f"{timestamp} | {tool_name} | {corruption_type}\n")
        except Exception as e:
            print(f"Warning: Failed to log corruption event: {e}")

    def load_tool(self, tool_name: str, validate: bool = True) -> ToolModule:
        """
        Load a tool from cache with validation.

        Args:
            tool_name: Name of the tool (without .py extension)
            validate: Whether to validate syntax (default: True)

        Returns:
            ToolModule with loaded code and metadata

        Raises:
            CacheError: If tool not found or validation fails
        """
        file_path = self.cache_dir / f"{tool_name}.py"

        if not file_path.exists():
            raise CacheError(f"Tool '{tool_name}' not found in cache")

        try:
            # Read tool code
            with open(file_path, 'r', encoding='utf-8') as f:
                code = f.read()

            # Extract metadata
            metadata = self._extract_metadata(str(file_path))

            # Validate syntax if requested
            ast_tree = None
            if validate:
                try:
                    ast_tree = ast.parse(code, filename=str(file_path))
                except SyntaxError as e:
                    raise CacheError(
                        f"Syntax error in tool '{tool_name}': {
                            e.msg} at line {
                            e.lineno}")

            return ToolModule(
                metadata=metadata,
                code=code,
                ast_tree=ast_tree,
                module=None  # Module loaded separately during execution
            )

        except CacheError:
            raise
        except Exception as e:
            raise CacheError(f"Failed to load tool '{tool_name}': {e}")

    def write_tool(
        self,
        tool_name: str,
        code: str,
        metadata: Optional[Dict[str, Any]] = None,
        use_locking: bool = True,
        create_backup: bool = True
    ) -> str:
        """
        Write a tool to cache with atomic write operation, file locking, and checksums.

        Args:
            tool_name: Name of the tool (without .py extension)
            code: Python code for the tool
            metadata: Optional metadata to include in header comment
            use_locking: Whether to use file locking (default: True)
            create_backup: Whether to create backup before overwrite (default: True)

        Returns:
            Path to the written tool file

        Raises:
            CacheError: If write operation fails
            CacheLockError: If unable to acquire lock
        """
        file_path = self.cache_dir / f"{tool_name}.py"
        temp_path = self.cache_dir / f"{tool_name}.py.tmp"
        backup_path = self.cache_dir / f"{tool_name}.py.bak"

        # Acquire lock if requested
        if use_locking:
            self._acquire_lock(tool_name)

        try:
            # Validate syntax before writing
            try:
                ast.parse(code)
            except SyntaxError as e:
                raise CacheError(
                    f"Invalid Python syntax: {e.msg} at line {e.lineno}"
                )

            # Add metadata header if provided
            if metadata:
                # Ensure schema version is set
                metadata.setdefault('schema_version', self.SCHEMA_VERSION)
                header = self._generate_header(tool_name, metadata)
                code = header + "\n\n" + code

            # Create backup of existing file
            if create_backup and file_path.exists():
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        backup_content = f.read()
                    with open(backup_path, 'w', encoding='utf-8') as f:
                        f.write(backup_content)
                except Exception as e:
                    print(
                        f"Warning: Failed to create backup for '{tool_name}': {e}")

            # Calculate checksum before writing
            checksum = None
            if self.enable_checksums:
                checksum = self._calculate_checksum(code)

            # Atomic write: write to temp file, then rename
            with open(temp_path, 'w', encoding='utf-8') as f:
                f.write(code)

            # Atomic rename (overwrites existing file)
            temp_path.rename(file_path)

            # Save checksum after successful write
            if checksum:
                self._save_checksum(tool_name, checksum)

            return str(file_path)

        except CacheError:
            raise
        except Exception as e:
            # Clean up temp file on error
            if temp_path.exists():
                temp_path.unlink()
            raise CacheError(f"Failed to write tool '{tool_name}': {e}")
        finally:
            # Always release lock
            if use_locking:
                self._release_lock(tool_name)

    def invalidate_cache(self, tool_name: str) -> bool:
        """
        Delete a tool from cache to force regeneration.

        Args:
            tool_name: Name of the tool (without .py extension)

        Returns:
            True if tool was deleted, False if not found
        """
        file_path = self.cache_dir / f"{tool_name}.py"

        if file_path.exists():
            try:
                file_path.unlink()
                return True
            except Exception as e:
                raise CacheError(
                    f"Failed to invalidate cache for '{tool_name}': {e}")

        return False

    def _extract_metadata(self, file_path: str) -> ToolMetadata:
        """
        Extract metadata from a tool file.

        Parses the header comment and AST to extract tool information.

        Args:
            file_path: Path to the tool file

        Returns:
            ToolMetadata
        """
        path = Path(file_path)
        tool_name = path.stem

        # Read file
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Get file stats
        stat = path.stat()
        size_bytes = stat.st_size
        modified_at = datetime.fromtimestamp(stat.st_mtime)
        line_count = content.count('\n') + 1

        # Extract description from docstring or header comment
        description = "No description"
        api_type = None
        created_at = None

        # Try to parse header comment
        header_match = re.search(
            r'"""(.*?)"""',
            content[:500],  # Check first 500 chars
            re.DOTALL
        )
        if header_match:
            header = header_match.group(1)
            description = header.split('\n')[0].strip()

            # Extract metadata from header
            if 'API:' in header:
                api_match = re.search(r'API:\s*(\w+)', header)
                if api_match:
                    api_type = api_match.group(1)

            if 'Created:' in header:
                created_match = re.search(
                    r'Created:\s*(\d{4}-\d{2}-\d{2})',
                    header
                )
                if created_match:
                    try:
                        created_at = datetime.fromisoformat(
                            created_match.group(1))
                    except ValueError:
                        pass

        # Extract function names from AST
        functions = []
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    if not node.name.startswith('_'):  # Skip private functions
                        functions.append(node.name)
        except SyntaxError:
            # If syntax error, still return metadata but mark as invalid
            description = f"[SYNTAX ERROR] {description}"

        # Calculate/load checksum
        checksum = None
        if self.enable_checksums:
            checksum = self._load_checksum(tool_name)
            if checksum is None:
                # Generate checksum if missing
                checksum = self._calculate_checksum(content)
                self._save_checksum(tool_name, checksum)

        return ToolMetadata(
            name=tool_name,
            file_path=file_path,
            description=description,
            api_type=api_type,
            functions=functions,
            created_at=created_at,
            modified_at=modified_at,
            size_bytes=size_bytes,
            line_count=line_count,
            checksum=checksum,
            schema_version=self.SCHEMA_VERSION
        )

    def _generate_header(self, tool_name: str,
                         metadata: Dict[str, Any]) -> str:
        """
        Generate header comment for a tool.

        Args:
            tool_name: Name of the tool
            metadata: Metadata dictionary

        Returns:
            Header comment string
        """
        lines = [
            '"""',
            metadata.get('description', f'{tool_name} tool'),
            '',
        ]

        if 'api_type' in metadata:
            lines.append(f"API: {metadata['api_type']}")

        lines.append(f"Created: {datetime.utcnow().date().isoformat()}")

        if 'version' in metadata:
            lines.append(f"Version: {metadata['version']}")

        if 'author' in metadata:
            lines.append(f"Author: {metadata['author']}")

        lines.append('"""')

        return '\n'.join(lines)

    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.

        Returns:
            Dict with cache stats (total_tools, total_size_mb, etc.)
        """
        tools = self.list_tools()

        total_size = sum(tool.size_bytes for tool in tools)
        total_lines = sum(tool.line_count for tool in tools)

        # Group by API type
        api_types: Dict[str, int] = {}
        for tool in tools:
            if tool.api_type:
                api_types[tool.api_type] = api_types.get(tool.api_type, 0) + 1

        return {
            'total_tools': len(tools),
            'total_size_mb': total_size / (1024 * 1024),
            'total_lines': total_lines,
            'api_types': api_types,
            'cache_dir': str(self.cache_dir)
        }
