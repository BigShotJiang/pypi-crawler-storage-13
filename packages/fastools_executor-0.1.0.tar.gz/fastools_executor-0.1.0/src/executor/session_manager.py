"""
Global session management for tracking active sessions and resource limits.

This module enforces global limits:
- Maximum 50 active sessions
- Maximum 5GB total memory usage
- Auto-cleanup of idle sessions after 30 minutes
"""

import threading
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from .sandbox import Sandbox, SandboxSession


@dataclass
class SessionInfo:
    """Information about an active session."""
    session_id: str
    created_at: datetime
    last_activity: datetime
    memory_mb: float
    execution_count: int


class SessionLimitError(Exception):
    """Raised when session limits are exceeded."""
    pass


class SessionManager:
    """
    Global session manager enforcing resource limits.

    Features:
    - Track active session count (max 50)
    - Track total memory usage (max 5GB)
    - Reject new sessions when limits reached
    - Auto-cleanup idle sessions (30min timeout)
    - Background cleanup worker
    """

    MAX_SESSIONS = 50
    MAX_TOTAL_MEMORY_GB = 5
    SESSION_TIMEOUT_MINUTES = 30
    CLEANUP_INTERVAL_MINUTES = 5

    def __init__(self, sandbox: Sandbox):
        """
        Initialize session manager.

        Args:
            sandbox: Sandbox instance to manage
        """
        self.sandbox = sandbox
        self.session_info: Dict[str, SessionInfo] = {}
        self._lock = threading.RLock()  # Use RLock to allow reentrant locking
        self._cleanup_thread: Optional[threading.Thread] = None
        self._stop_cleanup = threading.Event()

    def create_session(self, session_id: str) -> SandboxSession:
        """
        Create a new session with limit enforcement.

        Args:
            session_id: Unique session identifier

        Returns:
            Created SandboxSession

        Raises:
            SessionLimitError: If session count or memory limit exceeded
            ValueError: If session already exists
        """
        with self._lock:
            # Check session count limit
            if len(self.session_info) >= self.MAX_SESSIONS:
                raise SessionLimitError(
                    f"Maximum session count ({self.MAX_SESSIONS}) reached. "
                    f"Please wait for idle sessions to be cleaned up."
                )

            # Check total memory limit
            total_memory_gb = self.get_total_memory_gb()
            if total_memory_gb >= self.MAX_TOTAL_MEMORY_GB:
                raise SessionLimitError(
                    f"Maximum total memory ({
                        self.MAX_TOTAL_MEMORY_GB}GB) reached. " f"Current usage: {
                        total_memory_gb:.2f}GB")

            # Create session in sandbox
            session = self.sandbox.create_session(session_id)

            # Track session info
            now = datetime.utcnow()
            self.session_info[session_id] = SessionInfo(
                session_id=session_id,
                created_at=now,
                last_activity=now,
                memory_mb=0.0,
                execution_count=0
            )

            return session

    def update_activity(self, session_id: str, memory_mb: float):
        """
        Update session activity timestamp and memory usage.

        Args:
            session_id: Session to update
            memory_mb: Current memory usage in MB
        """
        with self._lock:
            if session_id in self.session_info:
                info = self.session_info[session_id]
                info.last_activity = datetime.utcnow()
                info.memory_mb = memory_mb
                info.execution_count += 1

    def destroy_session(self, session_id: str) -> bool:
        """
        Destroy a session and release resources.

        Args:
            session_id: Session to destroy

        Returns:
            True if session was destroyed, False if not found
        """
        with self._lock:
            # Remove from sandbox
            destroyed = self.sandbox.destroy_session(session_id)

            # Remove tracking info
            if session_id in self.session_info:
                del self.session_info[session_id]
                return True

            return destroyed

    def get_session_info(self, session_id: str) -> Optional[SessionInfo]:
        """
        Get information about a session.

        Args:
            session_id: Session identifier

        Returns:
            SessionInfo if found, None otherwise
        """
        with self._lock:
            return self.session_info.get(session_id)

    def list_sessions(self) -> List[SessionInfo]:
        """
        List all active sessions.

        Returns:
            List of SessionInfo for all active sessions
        """
        with self._lock:
            return list(self.session_info.values())

    def get_total_memory_gb(self) -> float:
        """
        Get total memory usage across all sessions.

        Returns:
            Total memory in GB
        """
        with self._lock:
            total_mb = sum(
                info.memory_mb for info in self.session_info.values())
            return total_mb / 1024

    def get_session_count(self) -> int:
        """
        Get count of active sessions.

        Returns:
            Number of active sessions
        """
        with self._lock:
            return len(self.session_info)

    def cleanup_idle_sessions(self) -> List[str]:
        """
        Clean up sessions that have been idle for too long.

        Returns:
            List of session IDs that were cleaned up
        """
        timeout = timedelta(minutes=self.SESSION_TIMEOUT_MINUTES)
        now = datetime.utcnow()
        cleaned_up = []

        with self._lock:
            # Find expired sessions
            expired = [
                session_id
                for session_id, info in self.session_info.items()
                if now - info.last_activity > timeout
            ]

            # Clean up expired sessions
            for session_id in expired:
                self.sandbox.destroy_session(session_id)
                del self.session_info[session_id]
                cleaned_up.append(session_id)

        if cleaned_up:
            print(f"Cleaned up {len(cleaned_up)} idle sessions: {cleaned_up}")

        return cleaned_up

    def start_cleanup_worker(self):
        """
        Start background worker for periodic cleanup.

        The worker checks every CLEANUP_INTERVAL_MINUTES for idle sessions
        and cleans them up automatically.
        """
        if self._cleanup_thread is not None and self._cleanup_thread.is_alive():
            return  # Already running

        self._stop_cleanup.clear()
        self._cleanup_thread = threading.Thread(
            target=self._cleanup_worker,
            daemon=True,
            name="SessionCleanupWorker"
        )
        self._cleanup_thread.start()

    def stop_cleanup_worker(self):
        """
        Stop the background cleanup worker.
        """
        if self._cleanup_thread is None:
            return

        self._stop_cleanup.set()
        self._cleanup_thread.join(timeout=5)
        self._cleanup_thread = None

    def _cleanup_worker(self):
        """
        Background worker that periodically cleans up idle sessions.

        Runs every CLEANUP_INTERVAL_MINUTES until stopped.
        """
        interval_seconds = self.CLEANUP_INTERVAL_MINUTES * 60

        while not self._stop_cleanup.is_set():
            try:
                self.cleanup_idle_sessions()
            except Exception as e:
                print(f"Error in cleanup worker: {e}")

            # Wait for next interval or until stopped
            self._stop_cleanup.wait(timeout=interval_seconds)

    def get_stats(self) -> Dict[str, any]:
        """
        Get session manager statistics.

        Returns:
            Dict with stats (active_sessions, total_memory_gb, etc.)
        """
        with self._lock:
            return {
                'active_sessions': len(self.session_info),
                'max_sessions': self.MAX_SESSIONS,
                'total_memory_gb': self.get_total_memory_gb(),
                'max_memory_gb': self.MAX_TOTAL_MEMORY_GB,
                'session_timeout_minutes': self.SESSION_TIMEOUT_MINUTES,
                'cleanup_interval_minutes': self.CLEANUP_INTERVAL_MINUTES,
                'cleanup_worker_running': (
                    self._cleanup_thread is not None and
                    self._cleanup_thread.is_alive()
                )
            }

    def __enter__(self):
        """Context manager entry - start cleanup worker."""
        self.start_cleanup_worker()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - stop cleanup worker."""
        self.stop_cleanup_worker()
