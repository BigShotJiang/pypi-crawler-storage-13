"""
Sandbox execution environment using RestrictedPython with process isolation.

This module provides secure sandboxed execution of dynamically generated tools
with timeout enforcement, CPU/memory quotas, and safe stderr capture.
"""

import ast
import io
import multiprocessing as mp
import os
import queue
import resource
import signal
import sys
import traceback
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional, Set

from RestrictedPython import PrintCollector, compile_restricted, safe_globals
from RestrictedPython.Guards import (guarded_iter_unpack_sequence,
                                     safe_builtins, safer_getattr)


@dataclass
class SandboxSession:
    """Represents an active sandbox session."""
    session_id: str
    created_at: datetime
    memory_used_mb: float
    state: Dict[str, Any]
    globals: Dict[str, Any]


class SandboxViolationError(Exception):
    """Raised when code attempts blocked operations."""
    pass


class MemoryExceededError(Exception):
    """Raised when session memory limit is exceeded."""
    pass


class TimeoutError(Exception):
    """Raised when execution exceeds timeout."""
    pass


class ResourceLimitError(Exception):
    """Raised when CPU or memory quota is exceeded."""
    pass


def _set_resource_limits(cpu_time_seconds: int, memory_mb: int):
    """
    Set CPU and memory limits for worker process.

    Args:
        cpu_time_seconds: Maximum CPU time in seconds
        memory_mb: Maximum memory in megabytes
    """
    # Set CPU time limit (user + system time)
    resource.setrlimit(
        resource.RLIMIT_CPU,
        (cpu_time_seconds,
         cpu_time_seconds + 1))

    # Set memory limit (address space)
    memory_bytes = memory_mb * 1024 * 1024
    resource.setrlimit(resource.RLIMIT_AS, (memory_bytes, memory_bytes))

    # Set stack size limit (prevent stack overflow)
    resource.setrlimit(
        resource.RLIMIT_STACK,
        (8 * 1024 * 1024,
         8 * 1024 * 1024))


def _setup_worker_globals(
        blocked_imports: Set[str], allowed_imports: Set[str]) -> Dict[str, Any]:
    """
    Setup safe globals in worker process (must be picklable).

    Args:
        blocked_imports: Set of blocked import names
        allowed_imports: Set of allowed import names

    Returns:
        Dictionary of safe globals
    """
    from RestrictedPython import PrintCollector, safe_globals
    from RestrictedPython.Guards import (guarded_iter_unpack_sequence,
                                         safe_builtins, safer_getattr)

    # Start with RestrictedPython's safe globals
    safe_globals_dict = safe_globals.copy()

    # Create guarded import function
    def _guarded_import(name: str, *args, **kwargs):
        """Guarded import in worker."""
        from src.executor.sandbox import SandboxViolationError

        # Check blocked
        module_parts = name.split('.')
        for i in range(len(module_parts)):
            check_name = '.'.join(module_parts[:i + 1])
            if check_name in blocked_imports:
                raise SandboxViolationError(
                    f"Import '{name}' is blocked for security reasons"
                )

        # Check allowed
        top_level = module_parts[0]
        if top_level not in allowed_imports:
            allowed = any(
                top_level.startswith(allowed_mod.split('.')[0])
                for allowed_mod in allowed_imports
            )
            if not allowed:
                raise SandboxViolationError(
                    f"Import '{name}' is not in allowed imports list"
                )

        return __import__(name, *args, **kwargs)

    # Create a print collector instance
    print_collector = PrintCollector()

    # Add safe builtins with all necessary guards
    safe_globals_dict['__builtins__'] = {
        **safe_builtins,
        '_getiter_': iter,
        '_iter_unpack_sequence_': guarded_iter_unpack_sequence,
        '_apply_': lambda f, *args, **kwargs: f(*args, **kwargs),
        '_getitem_': lambda obj, index: obj[index],
        '_getattr_': safer_getattr,
        '_write_': lambda x: x,
        '_print_': print_collector,  # Use instance
        '_inplacevar_': lambda op, x, y: op(x, y),
        # Add print as a function that uses the collector
        'print': lambda *args, **kwargs: print_collector(*args, **kwargs),
        'dict': dict,
        'list': list,
        'str': str,
        'int': int,
        'float': float,
        'bool': bool,
        'tuple': tuple,
        'set': set,
        'frozenset': frozenset,
        'bytes': bytes,
        'bytearray': bytearray,
        'range': range,
        'len': len,
        'sum': sum,
        'min': min,
        'max': max,
        'abs': abs,
        'all': all,
        'any': any,
        'enumerate': enumerate,
        'zip': zip,
        'sorted': sorted,
        'reversed': reversed,
        'map': map,
        'filter': filter,
    }

    # Store print collector reference for later retrieval
    safe_globals_dict['_print_collector_'] = print_collector

    # Remove dangerous functions
    for blocked in ['__import__', 'eval', 'exec', 'compile', 'open']:
        safe_globals_dict['__builtins__'].pop(blocked, None)

    # Add guarded import
    safe_globals_dict['__builtins__']['__import__'] = _guarded_import

    return safe_globals_dict


def _execute_in_worker(
    code_str: str,
    cpu_time: int,
    memory_mb: int,
    result_queue: mp.Queue,
    session_id: str,
    blocked_imports: Set[str],
    allowed_imports: Set[str]
):
    """
    Worker process function that executes code with resource limits.

    Args:
        code_str: Python code string to compile and execute
        cpu_time: CPU time limit in seconds
        memory_mb: Memory limit in MB
        result_queue: Queue for returning results
        session_id: Session identifier for error reporting
        blocked_imports: Set of blocked module names
        allowed_imports: Set of allowed module names
    """
    # Redirect stdout and stderr
    stdout_capture = io.StringIO()
    stderr_capture = io.StringIO()
    old_stdout = sys.stdout
    old_stderr = sys.stderr

    try:
        # Set resource limits
        _set_resource_limits(cpu_time, memory_mb)

        # Redirect output
        sys.stdout = stdout_capture
        sys.stderr = stderr_capture

        # Setup safe globals in worker
        session_globals = _setup_worker_globals(
            blocked_imports, allowed_imports)

        # Compile with RestrictedPython in worker
        from RestrictedPython import compile_restricted
        byte_code = compile_restricted(
            code_str,
            filename=f'<session-{session_id}>',
            mode='exec'
        )

        # Execute the code
        exec(byte_code, session_globals)

        # Get result from RESULT variable
        result = session_globals.get(
            '__result__', session_globals.get(
                'RESULT', session_globals.get(
                    'result', None)))

        # Calculate memory usage
        memory_used = sys.getsizeof(session_globals) / (1024 * 1024)

        # Capture print output from PrintCollector
        printed_output = ''
        _print = session_globals.get('_print_collector_')
        if _print and hasattr(_print, 'txt'):
            printed_output = '\n'.join(
                str(line) for line in _print.txt) + '\n' if _print.txt else ''

        # Return success
        result_queue.put({
            'success': True,
            'result': result,
            'memory_used_mb': memory_used,
            'stdout': stdout_capture.getvalue() + printed_output,
            'stderr': stderr_capture.getvalue()
        })

    except MemoryError as e:
        result_queue.put({
            'success': False,
            'error': f"Memory limit exceeded: {str(e)}",
            'error_type': 'memory_exceeded',
            'stdout': stdout_capture.getvalue(),
            'stderr': stderr_capture.getvalue()
        })

    except Exception as e:
        # Determine error type based on exception name
        error_name = type(e).__name__
        if 'SandboxViolation' in error_name:
            error_type = 'sandbox_violation'
        elif 'MemoryExceeded' in error_name:
            error_type = 'memory_exceeded'
        else:
            error_type = 'execution_error'

        result_queue.put({
            'success': False,
            'error': f"{error_name}: {str(e)}",
            'error_type': error_type,
            'traceback': traceback.format_exc(),
            'stdout': stdout_capture.getvalue(),
            'stderr': stderr_capture.getvalue()
        })

    finally:
        # Restore stdout/stderr
        sys.stdout = old_stdout
        sys.stderr = old_stderr


class Sandbox:
    """
    RestrictedPython-based sandbox for secure code execution with process isolation.

    Features:
    - Blocked imports (os, sys, subprocess, socket)
    - Allowed imports (json, datetime, re, math, pandas, numpy, googleapiclient, requests)
    - Memory limits (100MB per session)
    - CPU time limits
    - Timeout enforcement
    - Process isolation
    - Safe stderr/stdout capture
    - Session isolation and state management
    """

    # Blocked imports - security-sensitive modules
    BLOCKED_IMPORTS = {
        'os', 'sys', 'subprocess', 'socket', 'socketserver',
        'multiprocessing', 'threading', 'ctypes', 'importlib',
        'imp', '__import__', 'eval', 'exec', 'compile',
        'open', 'file', 'input', 'raw_input'
    }

    # Allowed imports - safe standard library and approved third-party
    ALLOWED_IMPORTS = {
        # Standard library
        'json', 'datetime', 're', 'math', 'collections',
        'itertools', 'functools', 'operator', 'typing',
        'string', 'decimal', 'fractions', 'statistics',
        'time',  # Added for timeout/sleep operations
        # Data processing
        'pandas', 'numpy',
        # API clients
        'googleapiclient', 'google.auth', 'google_auth_oauthlib',
        'requests', 'urllib.parse', 'urllib.request',
    }

    def __init__(
        self,
        memory_limit_mb: int = 100,
        cpu_time_limit: int = 30,
        default_timeout: int = 30
    ):
        """
        Initialize sandbox with resource limits.

        Args:
            memory_limit_mb: Maximum memory per session in MB (default: 100)
            cpu_time_limit: Maximum CPU time in seconds (default: 30)
            default_timeout: Default execution timeout in seconds (default: 30)
        """
        self.memory_limit_mb = memory_limit_mb
        self.cpu_time_limit = cpu_time_limit
        self.default_timeout = default_timeout
        self.sessions: Dict[str, SandboxSession] = {}
        self._setup_safe_globals()

        # Process pool for execution (lazy initialization)
        self._process_pool = None

    def _get_process_pool(self) -> mp.Pool:
        """Get or create process pool for execution."""
        if self._process_pool is None:
            # Use spawn method for better isolation
            ctx = mp.get_context('spawn')
            self._process_pool = ctx.Pool(processes=4)
        return self._process_pool

    def _setup_safe_globals(self) -> Dict[str, Any]:
        """
        Setup safe global namespace for restricted execution.

        Returns:
            Dictionary of safe globals with restricted builtins
        """
        # Start with RestrictedPython's safe globals
        safe_globals_dict = safe_globals.copy()

        # Add safe builtins with all necessary guards
        safe_globals_dict['__builtins__'] = {
            **safe_builtins,
            '_getiter_': iter,  # Use Python's built-in iter for iteration
            '_iter_unpack_sequence_': guarded_iter_unpack_sequence,
            # Add _apply_ for function calls
            '_apply_': lambda f, *args, **kwargs: f(*args, **kwargs),
            # Add _getitem_ for indexing
            '_getitem_': lambda obj, index: obj[index],
            # Add _getattr_ for safe attribute access
            '_getattr_': safer_getattr,
            # Add _write_ for variable assignments
            '_write_': lambda x: x,
            # Add _print_ for print statements (RestrictedPython transforms
            # print() calls)
            '_print_': PrintCollector,
            # Add _inplacevar_ for in-place operations (+=, -=, etc.)
            '_inplacevar_': lambda op, x, y: op(x, y),
            # Add built-in types
            'dict': dict,
            'list': list,
            'str': str,
            'int': int,
            'float': float,
            'bool': bool,
            'tuple': tuple,
            'set': set,
            'frozenset': frozenset,
            'bytes': bytes,
            'bytearray': bytearray,
            # Add common built-in functions
            'range': range,
            'len': len,
            'sum': sum,
            'min': min,
            'max': max,
            'abs': abs,
            'all': all,
            'any': any,
            'enumerate': enumerate,
            'zip': zip,
            'sorted': sorted,
            'reversed': reversed,
            'map': map,
            'filter': filter,
        }

        # Remove dangerous functions
        for blocked in ['__import__', 'eval', 'exec', 'compile', 'open']:
            safe_globals_dict['__builtins__'].pop(blocked, None)

        # Add custom import guard
        safe_globals_dict['__builtins__']['__import__'] = self._guarded_import

        return safe_globals_dict

    def _guarded_import(self, name: str, *args, **kwargs):
        """
        Guarded import function that enforces allowed/blocked lists.

        Args:
            name: Module name to import

        Returns:
            Imported module if allowed

        Raises:
            SandboxViolationError: If import is blocked
        """
        # Check if module or any parent is blocked
        module_parts = name.split('.')
        for i in range(len(module_parts)):
            check_name = '.'.join(module_parts[:i + 1])
            if check_name in self.BLOCKED_IMPORTS:
                raise SandboxViolationError(
                    f"Import '{name}' is blocked for security reasons"
                )

        # Check if module is in allowed list (top-level check)
        top_level = module_parts[0]
        if top_level not in self.ALLOWED_IMPORTS:
            # Allow submodules of allowed packages
            allowed = any(
                top_level.startswith(allowed_mod.split('.')[0])
                for allowed_mod in self.ALLOWED_IMPORTS
            )
            if not allowed:
                raise SandboxViolationError(
                    f"Import '{name}' is not in allowed imports list"
                )

        # Import is allowed
        return __import__(name, *args, **kwargs)

    def create_session(self, session_id: str) -> SandboxSession:
        """
        Create a new sandbox session.

        Args:
            session_id: Unique identifier for session

        Returns:
            Created SandboxSession

        Raises:
            ValueError: If session already exists
        """
        if session_id in self.sessions:
            raise ValueError(f"Session '{session_id}' already exists")

        session = SandboxSession(
            session_id=session_id,
            created_at=datetime.utcnow(),
            memory_used_mb=0.0,
            state={},
            globals=self._setup_safe_globals()
        )

        self.sessions[session_id] = session
        return session

    def execute_code(
        self,
        session_id: str,
        code: str,
        timeout: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Execute code in sandboxed session with process isolation.

        Args:
            session_id: Session to execute in
            code: Python code to execute
            timeout: Execution timeout in seconds (uses default if None)

        Returns:
            Dict with execution results:
                - success: bool
                - result: Any (if successful)
                - error: str (if failed)
                - memory_used_mb: float
                - stdout: str (captured stdout)
                - stderr: str (captured stderr)

        Raises:
            ValueError: If session doesn't exist
            MemoryExceededError: If memory limit exceeded
            SandboxViolationError: If code attempts blocked operations
            TimeoutError: If execution exceeds timeout
        """
        if session_id not in self.sessions:
            raise ValueError(f"Session '{session_id}' not found")

        session = self.sessions[session_id]
        timeout = timeout if timeout is not None else self.default_timeout

        # Check memory before execution
        if session.memory_used_mb > self.memory_limit_mb:
            raise MemoryExceededError(
                f"Session memory {session.memory_used_mb}MB exceeds limit "
                f"{self.memory_limit_mb}MB"
            )

        try:
            # Validate syntax with RestrictedPython (raises SyntaxError if
            # invalid)
            try:
                compile_restricted(
                    code,
                    filename=f'<session-{session_id}>',
                    mode='exec'
                )
            except SyntaxError as e:
                return {
                    'success': False,
                    'error': f"SyntaxError: {str(e)}",
                    'error_type': 'execution_error',
                    'memory_used_mb': session.memory_used_mb
                }

            # Create result queue
            # Use fork on Linux (better compatibility), spawn on Windows
            ctx = mp.get_context('fork' if hasattr(os, 'fork') else 'spawn')
            result_queue = ctx.Queue()

            # Start worker process - pass code string and import rules
            process = ctx.Process(
                target=_execute_in_worker,
                args=(
                    code,  # Pass string, compile in worker
                    self.cpu_time_limit,
                    self.memory_limit_mb,
                    result_queue,
                    session_id,
                    self.BLOCKED_IMPORTS,
                    self.ALLOWED_IMPORTS
                )
            )

            process.start()

            # Wait for result with timeout
            try:
                result = result_queue.get(timeout=timeout)
                process.join(timeout=1)  # Graceful shutdown

                # Update session memory
                if result.get('success'):
                    session.memory_used_mb = result.get('memory_used_mb', 0)

                return result

            except queue.Empty:
                # Timeout occurred - kill process
                process.terminate()
                process.join(timeout=2)

                if process.is_alive():
                    # Force kill if still alive
                    process.kill()
                    process.join()

                return {
                    'success': False,
                    'error': f"Execution exceeded timeout of {timeout} seconds",
                    'error_type': 'timeout',
                    'memory_used_mb': session.memory_used_mb}

        except SandboxViolationError as e:
            return {
                'success': False,
                'error': f"Sandbox violation: {str(e)}",
                'error_type': 'sandbox_violation',
                'memory_used_mb': session.memory_used_mb
            }

        except MemoryExceededError as e:
            return {
                'success': False,
                'error': str(e),
                'error_type': 'memory_exceeded',
                'memory_used_mb': session.memory_used_mb
            }

        except Exception as e:
            return {
                'success': False,
                'error': f"{type(e).__name__}: {str(e)}",
                'error_type': 'execution_error',
                'traceback': traceback.format_exc(),
                'memory_used_mb': session.memory_used_mb
            }

    def destroy_session(self, session_id: str) -> bool:
        """
        Destroy a sandbox session and release resources.

        Args:
            session_id: Session to destroy

        Returns:
            True if session was destroyed, False if not found
        """
        if session_id in self.sessions:
            del self.sessions[session_id]
            return True
        return False

    def get_session(self, session_id: str) -> Optional[SandboxSession]:
        """
        Get session by ID.

        Args:
            session_id: Session identifier

        Returns:
            SandboxSession if found, None otherwise
        """
        return self.sessions.get(session_id)

    def list_sessions(self) -> List[str]:
        """
        List all active session IDs.

        Returns:
            List of session IDs
        """
        return list(self.sessions.keys())

    def get_total_memory_usage(self) -> float:
        """
        Get total memory usage across all sessions.

        Returns:
            Total memory in MB
        """
        return sum(
            session.memory_used_mb for session in self.sessions.values())

    def cleanup(self):
        """Clean up resources including process pool."""
        if self._process_pool is not None:
            self._process_pool.terminate()
            self._process_pool.join()
            self._process_pool = None

    def __del__(self):
        """Cleanup on deletion."""
        self.cleanup()
