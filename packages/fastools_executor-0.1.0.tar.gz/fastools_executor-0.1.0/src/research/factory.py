"""
Factory for creating research adapters.

Provides a simple interface for creating the appropriate adapter based on configuration.
"""

import logging
from typing import Optional

from .base import ResearchAdapter, ResearchConfig
from .config import ConfigManager
from .context7 import Context7Adapter
from .fallback import FallbackAdapter
from .perplexity import PerplexityAdapter

logger = logging.getLogger(__name__)


def create_adapter(
    provider: Optional[str] = None,
    config_manager: Optional[ConfigManager] = None,
    mcp_client=None
) -> ResearchAdapter:
    """
    Create a research adapter instance.

    Args:
        provider: Provider name ('perplexity', 'context7', or None for default)
        config_manager: Optional ConfigManager instance (will create one if not provided)
        mcp_client: Optional MCP client for Context7 adapter

    Returns:
        ResearchAdapter instance

    Raises:
        ValueError: If provider is unknown or not available
    """
    if config_manager is None:
        config_manager = ConfigManager()

    # Determine provider
    if provider is None:
        provider = config_manager.get_default_provider()
        logger.info(f"Using default research provider: {provider}")

    provider = provider.lower()

    # Create appropriate adapter
    if provider == "perplexity":
        config = config_manager.get_perplexity_config()

        if not config.api_key:
            logger.warning(
                "Perplexity API key not configured. "
                "Set PERPLEXITY_API_KEY environment variable or add to config file.")

        return PerplexityAdapter(config)

    elif provider == "context7":
        config = config_manager.get_context7_config()

        if mcp_client is None:
            logger.warning(
                "Context7 adapter requires MCP client. "
                "Adapter will return errors until MCP client is provided."
            )

        return Context7Adapter(config, mcp_client=mcp_client)

    elif provider == "fallback":
        # Fallback uses minimal configuration
        config = ResearchConfig(
            max_requests_per_minute=100,
            max_retries=1,
            cache_enabled=True,
            cache_ttl=7200
        )
        return FallbackAdapter(config)

    else:
        raise ValueError(
            f"Unknown research provider: {provider}. "
            f"Supported providers: perplexity, context7, fallback"
        )


def create_multi_adapter(
    providers: list,
    config_manager: Optional[ConfigManager] = None,
    mcp_client=None
) -> list:
    """
    Create multiple adapters with fallback chain.

    Args:
        providers: List of provider names in order of preference
        config_manager: Optional ConfigManager instance
        mcp_client: Optional MCP client for Context7

    Returns:
        List of ResearchAdapter instances
    """
    adapters = []

    for provider in providers:
        try:
            adapter = create_adapter(provider, config_manager, mcp_client)
            adapters.append(adapter)
        except ValueError as e:
            logger.warning(f"Failed to create adapter for {provider}: {e}")

    if not adapters:
        raise ValueError(
            "No valid adapters could be created from provider list")

    return adapters
