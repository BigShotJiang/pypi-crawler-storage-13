"""
Context7 adapter for documentation retrieval.

Uses Context7 MCP server for library-specific documentation.
"""

import logging
from typing import Any, Dict, Optional

from .base import ResearchAdapter, ResearchConfig, ResearchResult

logger = logging.getLogger(__name__)


class Context7Adapter(ResearchAdapter):
    """
    Adapter for Context7 documentation service.

    Uses Context7 MCP server (if available) to fetch library documentation.
    """

    @property
    def provider_name(self) -> str:
        """Return provider name."""
        return "context7"

    def __init__(self, config: ResearchConfig, mcp_client=None):
        """
        Initialize Context7 adapter.

        Args:
            config: Research configuration
            mcp_client: Optional MCP client instance (for dependency injection)
        """
        super().__init__(config)
        self.mcp_client = mcp_client

    def _make_request(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> ResearchResult:
        """
        Fetch documentation using Context7 MCP.

        Args:
            query: Library name or search query
            context: Optional context (e.g., {"library_id": "/org/project", "topic": "..."})

        Returns:
            ResearchResult with documentation or error
        """
        if not self.mcp_client:
            return ResearchResult(
                success=False,
                error="Context7 MCP client not available",
                error_type="not_configured",
                provider=self.provider_name
            )

        try:
            # Check if we have a library ID already
            library_id = None
            if context and "library_id" in context:
                library_id = context["library_id"]
            else:
                # Need to resolve library name to ID first
                library_name = self._extract_library_name(query)
                if library_name:
                    resolve_result = self._resolve_library_id(library_name)
                    if not resolve_result.success:
                        return resolve_result
                    library_id = resolve_result.data.get("library_id")

            if not library_id:
                return ResearchResult(
                    success=False,
                    error="Could not determine library ID from query",
                    error_type="invalid_query",
                    provider=self.provider_name
                )

            # Fetch documentation
            topic = context.get("topic") if context else None
            tokens = self.config.extra_config.get("tokens", 5000)

            docs = self.mcp_client.call_tool(
                "mcp__context7__get-library-docs",
                {
                    "context7CompatibleLibraryID": library_id,
                    "topic": topic,
                    "tokens": tokens
                }
            )

            return ResearchResult(
                success=True,
                data={
                    "library_id": library_id,
                    "documentation": docs.get("content", ""),
                    "topic": topic,
                    "raw_response": docs
                },
                provider=self.provider_name,
                tokens_used=tokens
            )

        except Exception as e:
            logger.exception("Error fetching Context7 documentation")
            return ResearchResult(
                success=False,
                error=f"Context7 request failed: {str(e)}",
                error_type="request_error",
                provider=self.provider_name
            )

    def _resolve_library_id(self, library_name: str) -> ResearchResult:
        """
        Resolve library name to Context7 library ID.

        Args:
            library_name: Name of the library (e.g., "google-api-python-client")

        Returns:
            ResearchResult with library_id in data
        """
        try:
            result = self.mcp_client.call_tool(
                "mcp__context7__resolve-library-id",
                {"libraryName": library_name}
            )

            libraries = result.get("libraries", [])
            if not libraries:
                return ResearchResult(
                    success=False,
                    error=f"No libraries found matching '{library_name}'",
                    error_type="not_found",
                    provider=self.provider_name
                )

            # Take the first (most relevant) match
            library = libraries[0]
            library_id = library.get("id")

            if not library_id:
                return ResearchResult(
                    success=False,
                    error="Library found but missing ID",
                    error_type="invalid_response",
                    provider=self.provider_name
                )

            return ResearchResult(
                success=True,
                data={
                    "library_id": library_id,
                    "library_name": library.get("name"),
                    "description": library.get("description"),
                    "all_matches": libraries
                },
                provider=self.provider_name
            )

        except Exception as e:
            logger.exception("Error resolving library ID")
            return ResearchResult(
                success=False,
                error=f"Failed to resolve library: {str(e)}",
                error_type="request_error",
                provider=self.provider_name
            )

    def _extract_library_name(self, query: str) -> Optional[str]:
        """
        Extract library name from query.

        Args:
            query: Search query

        Returns:
            Library name or None
        """
        # Simple extraction - look for common patterns
        query_lower = query.lower()

        # Direct library names
        if "google-api-python-client" in query_lower:
            return "google-api-python-client"
        if "googleapiclient" in query_lower:
            return "google-api-python-client"

        # Extract from patterns like "documentation for X"
        import re
        patterns = [
            r"documentation for (.+?)(?:\s|$)",
            r"docs for (.+?)(?:\s|$)",
            r"(.+?)\s+api",
            r"(.+?)\s+library"
        ]

        for pattern in patterns:
            match = re.search(pattern, query_lower)
            if match:
                return match.group(1).strip()

        return None
