"""
Base classes for research adapters.

Defines the interface and common functionality for all research providers.
"""

import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class ResearchConfig:
    """Configuration for research adapters."""

    # API credentials
    api_key: Optional[str] = None

    # Rate limiting
    max_requests_per_minute: int = 10
    max_requests_per_hour: int = 100

    # Retry configuration
    max_retries: int = 3
    retry_backoff_base: float = 1.0  # Exponential backoff: base^attempt seconds
    retry_on_rate_limit: bool = True

    # Timeouts
    request_timeout: int = 30  # seconds

    # Cache settings
    cache_enabled: bool = True
    cache_ttl: int = 3600  # seconds

    # Provider-specific settings
    extra_config: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ResearchResult:
    """Result from a research operation."""

    # Response data
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    error_type: Optional[str] = None

    # Metadata
    provider: str = ""
    query: str = ""
    response_time: float = 0.0
    tokens_used: int = 0
    cached: bool = False

    # Rate limit info
    rate_limit_remaining: Optional[int] = None
    rate_limit_reset: Optional[int] = None

    # Retry info
    attempt_number: int = 1
    retry_after: Optional[int] = None

    # Timestamp
    timestamp: str = field(
        default_factory=lambda: datetime.now(
            timezone.utc).isoformat())


class RateLimiter:
    """Simple token bucket rate limiter."""

    def __init__(self, max_per_minute: int, max_per_hour: int):
        """
        Initialize rate limiter.

        Args:
            max_per_minute: Maximum requests per minute
            max_per_hour: Maximum requests per hour
        """
        self.max_per_minute = max_per_minute
        self.max_per_hour = max_per_hour
        self.minute_tokens = max_per_minute
        self.hour_tokens = max_per_hour
        self.last_minute_reset = time.time()
        self.last_hour_reset = time.time()

    def acquire(self, wait: bool = True) -> bool:
        """
        Acquire a token for making a request.

        Args:
            wait: If True, wait until token is available. If False, return immediately.

        Returns:
            bool: True if token acquired, False if rate limited and wait=False
        """
        now = time.time()

        # Reset minute tokens
        if now - self.last_minute_reset >= 60:
            self.minute_tokens = self.max_per_minute
            self.last_minute_reset = now

        # Reset hour tokens
        if now - self.last_hour_reset >= 3600:
            self.hour_tokens = self.max_per_hour
            self.last_hour_reset = now

        # Check if tokens available
        if self.minute_tokens <= 0 or self.hour_tokens <= 0:
            if not wait:
                return False

            # Calculate wait time
            wait_time = 0
            if self.minute_tokens <= 0:
                wait_time = max(wait_time, 60 - (now - self.last_minute_reset))
            if self.hour_tokens <= 0:
                wait_time = max(wait_time, 3600 - (now - self.last_hour_reset))

            logger.info(f"Rate limited, waiting {wait_time:.1f}s")
            time.sleep(wait_time)

            # Recurse to try again after waiting
            return self.acquire(wait=wait)

        # Consume tokens
        self.minute_tokens -= 1
        self.hour_tokens -= 1
        return True

    def get_status(self) -> Dict[str, Any]:
        """Get current rate limit status."""
        now = time.time()
        return {
            "minute_tokens_remaining": self.minute_tokens,
            "minute_reset_in": 60 - (now - self.last_minute_reset),
            "hour_tokens_remaining": self.hour_tokens,
            "hour_reset_in": 3600 - (now - self.last_hour_reset)
        }


class ResearchAdapter(ABC):
    """
    Base class for research adapters.

    All research providers must implement this interface.
    """

    def __init__(self, config: ResearchConfig):
        """
        Initialize adapter with configuration.

        Args:
            config: Research configuration
        """
        self.config = config
        self.rate_limiter = RateLimiter(
            max_per_minute=config.max_requests_per_minute,
            max_per_hour=config.max_requests_per_hour
        )
        self._cache: Dict[str, ResearchResult] = {}

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Return the provider name (e.g., 'perplexity', 'context7')."""
        pass

    @abstractmethod
    def _make_request(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> ResearchResult:
        """
        Make actual API request to the provider.

        Args:
            query: Search query or documentation request
            context: Optional context information

        Returns:
            ResearchResult with response data or error

        Raises:
            NotImplementedError: Must be implemented by subclass
        """
        pass

    def search(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> ResearchResult:
        """
        Perform research with rate limiting, caching, and retry logic.

        Args:
            query: Search query
            context: Optional context information

        Returns:
            ResearchResult with response or error
        """
        # Check cache
        cache_key = self._get_cache_key(query, context)
        if self.config.cache_enabled and cache_key in self._cache:
            cached = self._cache[cache_key]
            # Check if cache is still valid
            cached_time = datetime.fromisoformat(
                cached.timestamp.replace('Z', '+00:00'))
            age = (datetime.now(timezone.utc) - cached_time).total_seconds()
            if age < self.config.cache_ttl:
                logger.info(f"Cache hit for query: {query[:50]}...")
                cached.cached = True
                return cached

        # Retry loop
        last_error = None
        for attempt in range(1, self.config.max_retries + 1):
            try:
                # Rate limiting
                if not self.rate_limiter.acquire(wait=True):
                    return ResearchResult(
                        success=False,
                        error="Rate limit exceeded",
                        error_type="rate_limit",
                        provider=self.provider_name,
                        query=query,
                        attempt_number=attempt
                    )

                # Make request
                start_time = time.time()
                result = self._make_request(query, context)
                result.response_time = time.time() - start_time
                result.attempt_number = attempt
                result.query = query
                result.provider = self.provider_name

                # Cache successful results
                if result.success and self.config.cache_enabled:
                    self._cache[cache_key] = result

                return result

            except Exception as e:
                last_error = e
                logger.warning(
                    f"Request failed (attempt {attempt}/{self.config.max_retries}): {e}")

                # Apply exponential backoff
                if attempt < self.config.max_retries:
                    backoff = self.config.retry_backoff_base ** attempt
                    logger.info(f"Retrying in {backoff}s...")
                    time.sleep(backoff)

        # All retries exhausted
        return ResearchResult(
            success=False,
            error=f"Request failed after {
                self.config.max_retries} attempts: {last_error}",
            error_type="request_failed",
            provider=self.provider_name,
            query=query,
            attempt_number=self.config.max_retries)

    def fetch_docs(
        self,
        url: str,
        topic: Optional[str] = None
    ) -> ResearchResult:
        """
        Fetch documentation from a URL.

        Args:
            url: Documentation URL
            topic: Optional topic to focus on

        Returns:
            ResearchResult with documentation content
        """
        query = f"Documentation for {url}"
        if topic:
            query += f" focusing on {topic}"

        return self.search(query, context={"url": url, "topic": topic})

    def _get_cache_key(
            self, query: str, context: Optional[Dict[str, Any]]) -> str:
        """Generate cache key from query and context."""
        import hashlib
        import json

        data = {"query": query, "context": context or {}}
        key_str = json.dumps(data, sort_keys=True)
        return hashlib.md5(key_str.encode()).hexdigest()

    def clear_cache(self):
        """Clear the result cache."""
        self._cache.clear()

    def get_stats(self) -> Dict[str, Any]:
        """Get adapter statistics."""
        return {
            "provider": self.provider_name,
            "cache_size": len(self._cache),
            "rate_limit_status": self.rate_limiter.get_status()
        }
