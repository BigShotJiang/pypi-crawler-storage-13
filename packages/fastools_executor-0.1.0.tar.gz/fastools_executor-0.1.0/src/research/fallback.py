"""
Fallback research adapter using basic web search.

Provides a simple fallback when premium services (Perplexity, Context7) are unavailable.
Uses mock data or basic HTTP requests as needed.
"""

import logging
import re
from typing import Any, Dict, Optional

from .base import ResearchAdapter, ResearchConfig, ResearchResult

logger = logging.getLogger(__name__)


class FallbackAdapter(ResearchAdapter):
    """
    Fallback research adapter.

    Provides basic functionality when premium research services are unavailable:
    - Mock API documentation for known Google APIs
    - Basic URL patterns for common documentation sites
    - Simplified responses for testing and development
    """

    @property
    def provider_name(self) -> str:
        """Return provider name."""
        return "fallback"

    def _make_request(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> ResearchResult:
        """
        Generate fallback response.

        Args:
            query: Search query or documentation request
            context: Optional context information

        Returns:
            ResearchResult with mock data or basic info
        """
        logger.info(f"Using fallback adapter for query: {query[:50]}...")

        # Extract API information from query
        api_info = self._extract_api_info(query)

        if api_info:
            return self._generate_api_docs(api_info)
        else:
            return self._generate_generic_response(query)

    def _extract_api_info(self, query: str) -> Optional[Dict[str, str]]:
        """
        Extract API information from query.

        Args:
            query: Search query

        Returns:
            Dict with api_name and api_version, or None
        """
        query_lower = query.lower()

        # Known Google APIs
        google_apis = {
            "google forms": {"name": "Google Forms", "service": "forms", "version": "v1"},
            "forms api": {"name": "Google Forms", "service": "forms", "version": "v1"},
            "google sheets": {"name": "Google Sheets", "service": "sheets", "version": "v4"},
            "sheets api": {"name": "Google Sheets", "service": "sheets", "version": "v4"},
            "gmail": {"name": "Gmail", "service": "gmail", "version": "v1"},
            "gmail api": {"name": "Gmail", "service": "gmail", "version": "v1"},
            "google drive": {"name": "Google Drive", "service": "drive", "version": "v3"},
            "drive api": {"name": "Google Drive", "service": "drive", "version": "v3"},
            "google calendar": {"name": "Google Calendar", "service": "calendar", "version": "v3"},
            "calendar api": {"name": "Google Calendar", "service": "calendar", "version": "v3"}
        }

        for key, info in google_apis.items():
            if key in query_lower:
                # Extract version if explicitly mentioned
                version_match = re.search(r'v\d+', query_lower)
                if version_match:
                    info["version"] = version_match.group(0)
                return info

        return None

    def _generate_api_docs(self, api_info: Dict[str, str]) -> ResearchResult:
        """
        Generate mock API documentation.

        Args:
            api_info: Dict with name, service, version

        Returns:
            ResearchResult with mock documentation
        """
        name = api_info["name"]
        service = api_info["service"]
        version = api_info["version"]

        # Generate documentation URL
        docs_url = f"https://developers.google.com/{service}/api/reference/rest/{version}"

        # Generate mock endpoints
        endpoints = self._generate_mock_endpoints(service, version)

        # Generate mock scopes
        scopes = [
            f"https://www.googleapis.com/auth/{service}",
            f"https://www.googleapis.com/auth/{service}.readonly"
        ]

        content = f"""# {name} API {version}

## Overview
The {name} API allows you to interact with {name} programmatically.

## Authentication
Uses OAuth2 with the following scopes:
{chr(10).join(f"- {scope}" for scope in scopes)}

## Common Endpoints

{chr(10).join(f"### {ep['method'].upper()} {ep['path']}{chr(10)}{ep['description']}{chr(10)}" for ep in endpoints)}

## Documentation
For full API reference, see: {docs_url}
"""

        return ResearchResult(
            success=True,
            data={
                "content": content,
                "api_name": name,
                "api_version": version,
                "service_name": service,
                "docs_url": docs_url,
                "endpoints": endpoints,
                "scopes": scopes,
                "citations": [docs_url]
            },
            provider=self.provider_name,
            tokens_used=0  # Fallback uses no external tokens
        )

    def _generate_mock_endpoints(self, service: str, version: str) -> list:
        """
        Generate mock API endpoints.

        Args:
            service: Service name (e.g., 'forms', 'sheets')
            version: API version (e.g., 'v1', 'v4')

        Returns:
            List of endpoint dicts
        """
        # Common patterns for Google APIs
        resource = service.rstrip('s')  # Remove trailing 's' for singular

        endpoints = [
            {
                "method": "list",
                "path": f"/{service}",
                "description": f"List user's {service}"
            },
            {
                "method": "get",
                "path": f"/{service}/{{id}}",
                "description": f"Get a specific {resource}"
            },
            {
                "method": "create",
                "path": f"/{service}",
                "description": f"Create a new {resource}"
            },
            {
                "method": "update",
                "path": f"/{service}/{{id}}",
                "description": f"Update a {resource}"
            },
            {
                "method": "delete",
                "path": f"/{service}/{{id}}",
                "description": f"Delete a {resource}"
            }
        ]

        return endpoints

    def _generate_generic_response(self, query: str) -> ResearchResult:
        """
        Generate generic response for unknown queries.

        Args:
            query: Search query

        Returns:
            ResearchResult with generic info
        """
        content = f"""# Search Results for: {query}

The fallback adapter is being used because premium research services are not available.

## What this means:
- Real-time web search is not available
- API documentation may be incomplete or mocked
- For production use, configure a research provider (Perplexity or Context7)

## Configuration:
Set up a research provider by:
1. Adding API key to environment variable: PERPLEXITY_API_KEY
2. Or creating config file at: ~/.claude/research_config.json

## Current Query:
{query}

## Recommendations:
- If searching for API documentation, specify the API name explicitly
- Check that your query includes relevant keywords
- Configure a research provider for better results
"""

        return ResearchResult(
            success=True,
            data={
                "content": content,
                "query": query,
                "is_fallback": True,
                "citations": []
            },
            provider=self.provider_name,
            tokens_used=0
        )
