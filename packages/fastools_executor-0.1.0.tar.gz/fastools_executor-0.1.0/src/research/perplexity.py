"""
Perplexity AI adapter for research operations.

Uses Perplexity's Sonar API for real-time web search and documentation retrieval.
"""

import logging
from typing import Any, Dict, Optional

import requests

from .base import ResearchAdapter, ResearchConfig, ResearchResult

logger = logging.getLogger(__name__)


class PerplexityAdapter(ResearchAdapter):
    """
    Adapter for Perplexity AI Sonar API.

    Provides web search and documentation retrieval using Perplexity's API.
    """

    SONAR_API_URL = "https://api.perplexity.ai/chat/completions"
    DEFAULT_MODEL = "sonar"

    @property
    def provider_name(self) -> str:
        """Return provider name."""
        return "perplexity"

    def _make_request(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> ResearchResult:
        """
        Make request to Perplexity Sonar API.

        Args:
            query: Search query or documentation request
            context: Optional context (e.g., {"url": "...", "topic": "..."})

        Returns:
            ResearchResult with API response or error
        """
        if not self.config.api_key:
            return ResearchResult(
                success=False,
                error="Perplexity API key not configured",
                error_type="auth_error",
                provider=self.provider_name
            )

        # Build request payload
        messages = self._build_messages(query, context)
        model = self.config.extra_config.get("model", self.DEFAULT_MODEL)

        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": self.config.extra_config.get("max_tokens", 1000),
            "temperature": self.config.extra_config.get("temperature", 0.2),
            "return_citations": self.config.extra_config.get("return_citations", True),
            "return_images": self.config.extra_config.get("return_images", False)
        }

        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json"
        }

        try:
            response = requests.post(
                self.SONAR_API_URL,
                json=payload,
                headers=headers,
                timeout=self.config.request_timeout
            )

            # Check for rate limiting
            if response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", 60))
                return ResearchResult(
                    success=False,
                    error="Rate limit exceeded",
                    error_type="rate_limit",
                    provider=self.provider_name,
                    retry_after=retry_after,
                    rate_limit_remaining=0
                )

            # Check for authentication errors
            if response.status_code == 401:
                return ResearchResult(
                    success=False,
                    error="Invalid API key",
                    error_type="auth_error",
                    provider=self.provider_name
                )

            # Raise for other HTTP errors
            response.raise_for_status()

            # Parse response
            data = response.json()
            content = self._extract_content(data)
            citations = self._extract_citations(data)

            # Extract rate limit info from headers
            rate_limit_remaining = response.headers.get(
                "X-RateLimit-Remaining")
            rate_limit_reset = response.headers.get("X-RateLimit-Reset")

            # Estimate tokens used
            tokens_used = data.get("usage", {}).get("total_tokens", 0)

            return ResearchResult(
                success=True,
                data={
                    "content": content,
                    "citations": citations,
                    "raw_response": data},
                provider=self.provider_name,
                tokens_used=tokens_used,
                rate_limit_remaining=int(rate_limit_remaining) if rate_limit_remaining else None,
                rate_limit_reset=int(rate_limit_reset) if rate_limit_reset else None)

        except requests.Timeout:
            # Timeout errors should be retried by base class
            raise

        except requests.RequestException as e:
            # Request errors should be retried by base class
            raise

        except Exception as e:
            # Unexpected errors should be retried by base class
            logger.exception("Unexpected error in Perplexity request")
            raise

    def _build_messages(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None
    ) -> list:
        """
        Build messages array for Perplexity API.

        Args:
            query: User query
            context: Optional context information

        Returns:
            List of message dicts
        """
        messages = []

        # Add system message if configured
        system_prompt = self.config.extra_config.get("system_prompt")
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })

        # Build user message
        user_message = query

        # Add context if provided
        if context:
            if "url" in context:
                user_message += f"\n\nFocus on documentation at: {
                    context['url']}"
            if "topic" in context:
                user_message += f"\n\nSpecifically looking for information about: {
                    context['topic']}"

        messages.append({
            "role": "user",
            "content": user_message
        })

        return messages

    def _extract_content(self, response_data: Dict[str, Any]) -> str:
        """
        Extract content from Perplexity response.

        Args:
            response_data: Raw API response

        Returns:
            Extracted text content
        """
        choices = response_data.get("choices", [])
        if not choices:
            return ""

        message = choices[0].get("message", {})
        return message.get("content", "")

    def _extract_citations(self, response_data: Dict[str, Any]) -> list:
        """
        Extract citations from Perplexity response.

        Args:
            response_data: Raw API response

        Returns:
            List of citation URLs
        """
        citations = response_data.get("citations", [])
        return citations if isinstance(citations, list) else []
