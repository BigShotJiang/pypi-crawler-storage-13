"""
Research adapters module for external API documentation fetching.

This module provides adapters for various research providers (Perplexity, Context7, etc.)
with rate limiting, retry logic, and configuration management.
"""

from .base import ResearchAdapter, ResearchConfig, ResearchResult
from .config import ConfigManager
from .context7 import Context7Adapter
from .factory import create_adapter, create_multi_adapter
from .fallback import FallbackAdapter
from .perplexity import PerplexityAdapter

__all__ = [
    "ResearchAdapter",
    "ResearchConfig",
    "ResearchResult",
    "PerplexityAdapter",
    "Context7Adapter",
    "FallbackAdapter",
    "create_adapter",
    "create_multi_adapter",
    "ConfigManager"
]
