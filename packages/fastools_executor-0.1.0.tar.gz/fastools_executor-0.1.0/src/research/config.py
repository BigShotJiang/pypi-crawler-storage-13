"""
Configuration management for research adapters.

Handles loading API keys from environment variables and config files.
"""

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

from .base import ResearchConfig

logger = logging.getLogger(__name__)


class ConfigManager:
    """
    Manages configuration for research adapters.

    Loads API keys and settings from:
    1. Environment variables
    2. Config file at ~/.claude/research_config.json
    3. Default values
    """

    DEFAULT_CONFIG_PATH = Path.home() / ".claude" / "research_config.json"

    def __init__(self, config_path: Optional[Path] = None):
        """
        Initialize configuration manager.

        Args:
            config_path: Optional path to config file (defaults to ~/.claude/research_config.json)
        """
        self.config_path = config_path or self.DEFAULT_CONFIG_PATH
        self._config_data: Dict[str, Any] = {}
        self._load_config()

    def _load_config(self):
        """Load configuration from file if it exists."""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r') as f:
                    self._config_data = json.load(f)
                logger.info(f"Loaded research config from {self.config_path}")
            except Exception as e:
                logger.warning(
                    f"Failed to load config from {
                        self.config_path}: {e}")
                self._config_data = {}
        else:
            logger.debug(
                f"Config file not found at {
                    self.config_path}, using defaults")
            self._config_data = {}

    def get_perplexity_config(self) -> ResearchConfig:
        """
        Get Perplexity adapter configuration.

        Returns:
            ResearchConfig for Perplexity
        """
        # Try environment variable first
        api_key = os.environ.get("PERPLEXITY_API_KEY")

        # Fall back to config file
        if not api_key:
            api_key = self._config_data.get("perplexity", {}).get("api_key")

        # Get other settings
        perplexity_config = self._config_data.get("perplexity", {})

        return ResearchConfig(
            api_key=api_key,
            max_requests_per_minute=perplexity_config.get("max_requests_per_minute", 10),
            max_requests_per_hour=perplexity_config.get("max_requests_per_hour", 100),
            max_retries=perplexity_config.get("max_retries", 3),
            retry_backoff_base=perplexity_config.get("retry_backoff_base", 1.5),
            request_timeout=perplexity_config.get("request_timeout", 30),
            cache_enabled=perplexity_config.get("cache_enabled", True),
            cache_ttl=perplexity_config.get("cache_ttl", 3600),
            extra_config={
                "model": perplexity_config.get("model", "sonar"),
                "max_tokens": perplexity_config.get("max_tokens", 1000),
                "temperature": perplexity_config.get("temperature", 0.2),
                "return_citations": perplexity_config.get("return_citations", True),
                "system_prompt": perplexity_config.get("system_prompt")
            }
        )

    def get_context7_config(self) -> ResearchConfig:
        """
        Get Context7 adapter configuration.

        Returns:
            ResearchConfig for Context7
        """
        context7_config = self._config_data.get("context7", {})

        return ResearchConfig(
            api_key=None,  # Context7 uses MCP, no API key needed
            max_requests_per_minute=context7_config.get(
                "max_requests_per_minute", 20),
            max_requests_per_hour=context7_config.get(
                "max_requests_per_hour", 200),
            max_retries=context7_config.get("max_retries", 2),
            retry_backoff_base=context7_config.get("retry_backoff_base", 1.0),
            request_timeout=context7_config.get("request_timeout", 15),
            cache_enabled=context7_config.get("cache_enabled", True),
            cache_ttl=context7_config.get(
                "cache_ttl", 7200),  # 2 hours for docs
            extra_config={
                "tokens": context7_config.get("tokens", 5000)
            }
        )

    def get_default_provider(self) -> str:
        """
        Get the default research provider.

        Returns:
            Provider name ('perplexity', 'context7', etc.)
        """
        return self._config_data.get("default_provider", "perplexity")

    def validate_config(self) -> Dict[str, Any]:
        """
        Validate current configuration.

        Returns:
            Dict with validation status and any errors
        """
        issues = []

        # Check Perplexity API key
        perplexity_config = self.get_perplexity_config()
        if not perplexity_config.api_key:
            issues.append({
                "provider": "perplexity",
                "issue": "API key not configured",
                "resolution": "Set PERPLEXITY_API_KEY environment variable or add to config file"
            })

        # Check config file permissions
        if self.config_path.exists():
            stat = self.config_path.stat()
            mode = stat.st_mode & 0o777
            if mode != 0o600:
                issues.append({
                    "provider": "all",
                    "issue": f"Config file has insecure permissions: {oct(mode)}",
                    "resolution": f"Run: chmod 600 {self.config_path}"
                })

        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "config_path": str(self.config_path),
            "config_exists": self.config_path.exists()
        }

    def create_example_config(self, force: bool = False) -> bool:
        """
        Create example configuration file.

        Args:
            force: If True, overwrite existing file

        Returns:
            bool: True if created, False if already exists and force=False
        """
        if self.config_path.exists() and not force:
            logger.warning(f"Config file already exists at {self.config_path}")
            return False

        # Ensure directory exists
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

        example_config = {
            "default_provider": "perplexity",
            "perplexity": {
                "api_key": "YOUR_PERPLEXITY_API_KEY_HERE",
                "max_requests_per_minute": 10,
                "max_requests_per_hour": 100,
                "max_retries": 3,
                "retry_backoff_base": 1.5,
                "request_timeout": 30,
                "cache_enabled": True,
                "cache_ttl": 3600,
                "model": "sonar",
                "max_tokens": 1000,
                "temperature": 0.2,
                "return_citations": True,
                "system_prompt": None
            },
            "context7": {
                "max_requests_per_minute": 20,
                "max_requests_per_hour": 200,
                "max_retries": 2,
                "retry_backoff_base": 1.0,
                "request_timeout": 15,
                "cache_enabled": True,
                "cache_ttl": 7200,
                "tokens": 5000
            }
        }

        try:
            with open(self.config_path, 'w') as f:
                json.dump(example_config, f, indent=2)

            # Set secure permissions
            self.config_path.chmod(0o600)

            logger.info(f"Created example config at {self.config_path}")
            return True

        except Exception as e:
            logger.error(f"Failed to create example config: {e}")
            return False
