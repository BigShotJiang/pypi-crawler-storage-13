"""CLI module - command line interface."""

from .executor_cli import cli, main

__all__ = ['cli', 'main']
