#!/usr/bin/env python3
"""
Command-line interface for the FAS Tool Executor.

Provides commands for executing tools, checking cache, and managing tools.
"""

import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

try:
    import click
except ImportError:
    print(
        "Error: 'click' package is required. Install with: pip install click",
        file=sys.stderr)
    sys.exit(1)

from executor.coordinator import Coordinator, WorkflowStep


# ANSI color codes for terminal output
class Colors:
    """Terminal color codes."""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    BOLD = '\033[1m'
    RESET = '\033[0m'


def color_text(text: str, color: str) -> str:
    """Wrap text with color code."""
    if sys.stdout.isatty():
        return f"{color}{text}{Colors.RESET}"
    return text


def format_error(message: str) -> str:
    """Format error message with red color."""
    return color_text(f"✗ {message}", Colors.RED)


def format_success(message: str) -> str:
    """Format success message with green color."""
    return color_text(f"✓ {message}", Colors.GREEN)


def format_warning(message: str) -> str:
    """Format warning message with yellow color."""
    return color_text(f"⚠ {message}", Colors.YELLOW)


def format_info(message: str) -> str:
    """Format info message with cyan color."""
    return color_text(message, Colors.CYAN)


def format_table(headers: list, rows: list, max_width: int = 80) -> str:
    """
    Format data as a simple table.

    Args:
        headers: List of column headers
        rows: List of row data (each row is a list)
        max_width: Maximum width for truncation

    Returns:
        Formatted table string
    """
    if not rows:
        return "No data to display"

    # Calculate column widths
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))

    # Ensure total width doesn't exceed max_width
    total_width = sum(col_widths) + len(headers) * 3 - 1
    if total_width > max_width:
        # Proportionally reduce column widths
        scale = max_width / total_width
        col_widths = [max(10, int(w * scale)) for w in col_widths]

    # Build table
    lines = []

    # Header
    header_line = " | ".join(
        h.ljust(
            col_widths[i]) for i,
        h in enumerate(headers))
    lines.append(color_text(header_line, Colors.BOLD))
    lines.append("-" * len(header_line))

    # Rows
    for row in rows:
        row_line = " | ".join(
            str(cell)[:col_widths[i]].ljust(col_widths[i])
            for i, cell in enumerate(row)
        )
        lines.append(row_line)

    return "\n".join(lines)


def output_json(data: Any) -> None:
    """Output data as formatted JSON."""
    print(json.dumps(data, indent=2, default=str))


def output_result(result: Dict[str, Any], json_output: bool = False) -> None:
    """
    Output execution result in human-readable or JSON format.

    Args:
        result: Result dictionary
        json_output: If True, output as JSON
    """
    if json_output:
        output_json(result)
        return

    # Human-readable output
    if result.get('success'):
        print(format_success(f"Execution successful: {result['tool_name']}"))
        print(f"  Execution time: {result['execution_time']:.2f}s")
        print(f"  Token cost: {result['token_cost']}")
        print(f"  Cached: {'Yes' if result['was_cached'] else 'No'}")

        if result.get('result'):
            print(f"\n{color_text('Result:', Colors.BOLD)}")
            print(json.dumps(result['result'], indent=2, default=str))
    else:
        print(format_error(f"Execution failed: {result['tool_name']}"))
        print(f"  Error type: {result.get('error_type', 'unknown')}")
        print(f"  Message: {result.get('error', 'No error message')}")

        if result.get('suggested_resolution'):
            print(f"\n{color_text('Suggested resolution:', Colors.YELLOW)}")
            print(f"  {result['suggested_resolution']}")


@click.group()
@click.option('--cache-dir', type=click.Path(), help='Tool cache directory')
@click.pass_context
def cli(ctx, cache_dir):
    """
    FAS Tool Executor - Execute API tools with automatic caching.

    The executor provides token-efficient execution of API tools by caching
    generated tools and reusing them across calls.
    """
    ctx.ensure_object(dict)
    ctx.obj['cache_dir'] = cache_dir
    ctx.obj['coordinator'] = Coordinator(cache_dir=cache_dir)


@cli.command()
@click.argument('tool_name')
@click.argument('function_name')
@click.option('--args', '-a', help='Function arguments as JSON string')
@click.option('--session-id', '-s',
              help='Session ID (creates new if not provided)')
@click.option('--timeout', '-t', type=int, default=30,
              help='Execution timeout in seconds')
@click.option('--json', 'json_output', is_flag=True, help='Output as JSON')
@click.pass_context
def execute(
        ctx,
        tool_name,
        function_name,
        args,
        session_id,
        timeout,
        json_output):
    """
    Execute a tool function.

    TOOL_NAME: Name of the tool (e.g., google_forms)
    FUNCTION_NAME: Function to call (e.g., list_forms)

    Examples:

      # Execute with simple arguments
      fastools execute google_forms list_forms --args '{"max_results": 10}'

      # Execute with session reuse
      fastools execute google_sheets get_values --session-id abc123

      # Execute with JSON output
      fastools execute google_docs create_doc --args '{"title": "Test"}' --json
    """
    coordinator = ctx.obj['coordinator']

    # Parse arguments
    arguments = {}
    if args:
        try:
            arguments = json.loads(args)
        except json.JSONDecodeError as e:
            print(format_error(f"Invalid JSON arguments: {e}"))
            sys.exit(1)

    # Execute tool
    try:
        result = coordinator.execute_tool(
            tool_name=tool_name,
            function_name=function_name,
            arguments=arguments,
            session_id=session_id,
            timeout=timeout
        )

        # Output result
        output_result(result.to_dict(), json_output=json_output)

        # Exit with error code if execution failed
        if not result.success:
            sys.exit(1)

    except Exception as e:
        print(format_error(f"Unexpected error: {e}"))
        if json_output:
            output_json({"error": str(e), "success": False})
        sys.exit(1)


@cli.command()
@click.option('--pattern', '-p', default='*.py',
              help='Glob pattern for filtering')
@click.option('--json', 'json_output', is_flag=True, help='Output as JSON')
@click.pass_context
def list_tools(ctx, pattern, json_output):
    """
    List all cached tools.

    Examples:

      # List all tools
      fastools list-tools

      # List Google API tools
      fastools list-tools --pattern 'google_*'

      # Output as JSON
      fastools list-tools --json
    """
    coordinator = ctx.obj['coordinator']

    try:
        result = coordinator.list_tools(pattern=pattern)

        if json_output:
            output_json({
                'tools': result.tools,
                'total_count': result.total_count,
                'cache_stats': result.cache_stats
            })
        else:
            # Human-readable table output
            print(format_info(f"Cached Tools (pattern: {pattern})"))
            print()

            if result.tools:
                # Prepare table data
                headers = ['Name', 'API Type', 'Functions', 'Size', 'Modified']
                rows = [
                    [
                        tool['name'],
                        tool['api_type'],
                        str(len(tool['functions'])),
                        f"{tool['size_bytes'] / 1024:.1f}KB",
                        tool['modified_at'].split('T')[0]  # Just the date
                    ]
                    for tool in result.tools
                ]

                print(format_table(headers, rows))
                print()
                print(format_success(f"Total: {result.total_count} tools"))
            else:
                print(
                    format_warning(
                        f"No tools found matching pattern: {pattern}"))

            # Show cache stats
            if result.cache_stats:
                print()
                print(format_info("Cache Statistics:"))
                print(
                    f"  Total tools: {
                        result.cache_stats.get(
                            'total_tools', 0)}")
                print(
                    f"  Total size: {
                        result.cache_stats.get(
                            'total_size_mb',
                            0):.2f}MB")

    except Exception as e:
        print(format_error(f"Failed to list tools: {e}"))
        sys.exit(1)


@cli.command()
@click.argument('tool_name')
@click.option('--json', 'json_output', is_flag=True, help='Output as JSON')
@click.pass_context
def check_cache(ctx, tool_name, json_output):
    """
    Check if a tool exists in cache.

    TOOL_NAME: Name of the tool to check

    Examples:

      # Check if tool is cached
      fastools check-cache google_forms

      # Check with JSON output
      fastools check-cache google_sheets --json
    """
    coordinator = ctx.obj['coordinator']

    try:
        result = coordinator.check_cache(tool_name)

        if json_output:
            output_json({
                'exists': result.exists,
                'tool_name': result.tool_name,
                'token_cost': result.token_cost,
                'metadata': result.metadata
            })
        else:
            if result.exists:
                print(format_success(f"Tool '{tool_name}' is cached"))
                print(f"  Token cost: {result.token_cost}")

                if result.metadata:
                    print(
                        f"  Description: {
                            result.metadata.get(
                                'description',
                                'N/A')}")
                    print(
                        f"  API type: {
                            result.metadata.get(
                                'api_type',
                                'N/A')}")
                    print(
                        f"  Functions: {len(result.metadata.get('functions', []))}")
                    print(
                        f"  Size: {
                            result.metadata.get(
                                'size_bytes',
                                0) / 1024:.1f}KB")
                    print(
                        f"  Modified: {
                            result.metadata.get(
                                'modified_at',
                                'N/A')}")
            else:
                print(format_warning(f"Tool '{tool_name}' is not cached"))
                print(f"  Will be generated on first execution")
                print(f"  Estimated token cost: {result.token_cost}")

    except Exception as e:
        print(format_error(f"Failed to check cache: {e}"))
        sys.exit(1)


@cli.command()
@click.argument('tool_name')
@click.option('--confirm', is_flag=True, help='Skip confirmation prompt')
@click.pass_context
def invalidate_cache(ctx, tool_name, confirm):
    """
    Invalidate a cached tool to force regeneration.

    TOOL_NAME: Name of the tool to invalidate

    Examples:

      # Invalidate a tool (with confirmation)
      fastools invalidate-cache google_forms

      # Invalidate without confirmation
      fastools invalidate-cache google_forms --confirm
    """
    coordinator = ctx.obj['coordinator']

    # Confirm deletion unless --confirm flag is set
    if not confirm:
        if not click.confirm(
                f"Are you sure you want to invalidate '{tool_name}'?"):
            print("Cancelled.")
            return

    try:
        success = coordinator.invalidate_cache(tool_name)

        if success:
            print(format_success(f"Tool '{tool_name}' has been invalidated"))
            print("  The tool will be regenerated on next execution")
        else:
            print(format_warning(f"Tool '{tool_name}' was not found in cache"))

    except Exception as e:
        print(format_error(f"Failed to invalidate cache: {e}"))
        sys.exit(1)


@cli.command()
@click.option('--json', 'json_output', is_flag=True, help='Output as JSON')
@click.option('--errors', is_flag=True, help='Show recent errors')
@click.option('--sessions', is_flag=True, help='Show session details')
@click.pass_context
def stats(ctx, json_output, errors, sessions):
    """
    Show executor statistics and telemetry.

    Examples:

      # Show statistics
      fastools stats

      # Show with recent errors
      fastools stats --errors

      # Show with session details
      fastools stats --sessions

      # Show as JSON
      fastools stats --json
    """
    coordinator = ctx.obj['coordinator']

    try:
        stats = coordinator.get_stats()

        if json_output:
            output_json(stats)
        else:
            print(format_info("Executor Statistics"))
            print()

            # Telemetry metrics
            telemetry = stats.get('telemetry', {})
            current = telemetry.get('current_metrics', {})
            computed = telemetry.get('computed_metrics', {})

            # Cache metrics
            cache = stats.get('cache_stats', {})
            print(color_text("Cache Metrics:", Colors.BOLD))
            print(f"  Total tools: {cache.get('total_tools', 0)}")
            print(f"  Total size: {cache.get('total_size_mb', 0):.2f}MB")
            print(f"  Cache hits: {current.get('cache_hits', 0)}")
            print(f"  Cache misses: {current.get('cache_misses', 0)}")
            print(f"  Hit rate: {computed.get('cache_hit_rate', 0):.1%}")
            print(f"  Cache writes: {current.get('cache_writes', 0)}")
            print(f"  Cache errors: {current.get('cache_errors', 0)}")
            print()

            # Tool generation metrics
            print(color_text("Tool Generation:", Colors.BOLD))
            print(f"  Tools generated: {current.get('tools_generated', 0)}")
            print(f"  Successes: {current.get('generation_successes', 0)}")
            print(f"  Failures: {current.get('generation_failures', 0)}")
            print(
                f"  Success rate: {
                    computed.get(
                        'generation_success_rate',
                        0):.1%}")
            print()

            # Sandbox execution metrics
            print(color_text("Sandbox Execution:", Colors.BOLD))
            print(
                f"  Total executions: {
                    current.get(
                        'sandbox_executions',
                        0)}")
            print(
                f"  Avg execution time: {
                    computed.get(
                        'avg_execution_time_ms',
                        0):.2f}ms")
            print(
                f"  Sandbox violations: {
                    current.get(
                        'sandbox_violations',
                        0)}")
            print()

            # Session stats
            session = stats.get('session_stats', {})
            print(color_text("Sessions:", Colors.BOLD))
            print(
                f"  Active sessions: {
                    session.get(
                        'active_sessions',
                        0)}/{
                    session.get(
                        'max_sessions',
                        50)}")
            print(
                f"  Total memory: {
                    session.get(
                        'total_memory_gb',
                        0):.2f}GB/{
                    session.get(
                        'max_memory_gb',
                        5):.1f}GB")
            print(
                f"  Cleanup worker: {
                    'Running' if session.get('cleanup_worker_running') else 'Stopped'}")
            print()

            # Error metrics
            print(color_text("Error Metrics:", Colors.BOLD))
            print(f"  Total errors: {current.get('total_errors', 0)}")
            print(f"  Auth failures: {current.get('auth_failures', 0)}")
            print(
                f"  Resource violations: {
                    current.get(
                        'resource_violations',
                        0)}")
            print()

            # Token usage
            tokens = stats.get('token_costs', {})
            print(color_text("Token Usage:", Colors.BOLD))
            print(
                f"  Total tokens used: {
                    current.get(
                        'total_tokens_used',
                        0)}")
            print(f"  Cached execution cost: {tokens.get('cached', 0)} tokens")
            print(f"  Generation cost: {tokens.get('generation', 0)} tokens")
            print(f"  Uncached cost: {tokens.get('uncached', 0)} tokens")

            # Show recent errors if requested
            if errors:
                recent_errors = telemetry.get('recent_errors', [])
                if recent_errors:
                    print()
                    print(
                        color_text(
                            f"Recent Errors ({
                                len(recent_errors)}):",
                            Colors.BOLD))
                    for err in recent_errors[-5:]:  # Show last 5
                        timestamp = err.get('timestamp', 'Unknown')
                        message = err.get('message', 'No message')
                        error_msg = err.get('error', '')
                        print(f"  [{timestamp}] {message}")
                        if error_msg:
                            print(f"    Error: {error_msg}")

            # Show session details if requested
            if sessions:
                active_sessions = telemetry.get('active_sessions', [])
                if active_sessions:
                    print()
                    print(
                        color_text(
                            f"Active Sessions ({
                                len(active_sessions)}):",
                            Colors.BOLD))
                    for sess in active_sessions:
                        session_id = sess.get('session_id', 'Unknown')
                        duration = sess.get('duration_seconds', 0)
                        print(f"  {session_id}: {duration:.1f}s")

    except Exception as e:
        print(format_error(f"Failed to get statistics: {e}"))
        sys.exit(1)


def main():
    """Main entry point for CLI."""
    try:
        cli(obj={})
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(130)


if __name__ == '__main__':
    main()
