import logging
from sys import api_version

from flask import Blueprint, request, jsonify

from aiq.churn.main.server.services.PredictionService import PredictionService
api_version = "1"



logger = logging.getLogger(__name__)
def create_prediction_bp_v1(prediction_service: PredictionService):
    prediction_bp = Blueprint('prediction_bp', __name__, url_prefix='/churn_predictor/v1/')

    @prediction_bp.route('/predict', methods=['POST'])
    def predict():
        data = request.get_json()
        #logger.info(data.__class__.__name__)
        prediction_result = prediction_service.predict(data)
        prediction_result = prediction_service.predict(data)
        return jsonify(prediction_result.to_dict(api_version)), 200

# POST /churn_predictor/v1/loadModel - JSON: {model_name, service_name, model_version, username, password}
    @prediction_bp.route('/loadModel', methods=['POST'])
    def load_model_result():
        data = request.get_json()
        load_model_result = prediction_service.load_model_result(data)
        return jsonify(load_model_result.to_dict(api_version)), 200

    return prediction_bp