from flask import Blueprint

from aiq.churn.main.server.controllers.v1.ModelAndTrainingContoller import create_model_and_training_bp_v1
from aiq.churn.main.server.controllers.v1.PredictionController import create_prediction_bp_v1


def create_prediction_bp(prediction_service, api_version: str) -> Blueprint | None:
    match api_version:
        case '1':
            return create_prediction_bp_v1(prediction_service)
    return None

def create_model_and_training_bp(model_and_training_service, api_version: str) -> Blueprint | None:
    match api_version:
        case '1':
            return create_model_and_training_bp_v1(model_and_training_service)
    return None