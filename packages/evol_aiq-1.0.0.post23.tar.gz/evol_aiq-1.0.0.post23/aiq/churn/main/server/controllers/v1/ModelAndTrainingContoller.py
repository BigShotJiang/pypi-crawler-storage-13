import logging
from sys import api_version

from flask import Blueprint, request, jsonify

from aiq.churn.main.server.services import ModelAndTrainingService

api_version = "1"

logger = logging.getLogger(__name__)
def create_model_and_training_bp_v1(model_and_training_service: ModelAndTrainingService):
    model_and_training_bp = Blueprint('model_and_training_bp', __name__, url_prefix='/model_and_training/v1/')

    # POST /model_and_training/v1/startTrain - JSON: {username, password}
    @model_and_training_bp.route('/startTrain', methods=['POST'])
    def start_train():
        data = request.get_json()
        start_train_result = model_and_training_service.start_train(data)
        return jsonify(start_train_result.to_dict(api_version)), 200

    # POST /model_and_training/v1/publishModel - JSON: {model_name, service_name, model_version, username, password}
    # please create directory structure service/model/version/
    @model_and_training_bp.route('/publishModel', methods=['POST'])
    def publish_model():
        data = request.get_json()
        publish_model_result = model_and_training_service.publishModel(data)
        return jsonify(publish_model_result.to_dict(api_version)), 200

    # @model_and_training_bp.route('/loadModel', methods=['POST'])
    # def load_model_result():
    #     data = request.get_json()
    #     load_model_result = model_and_training_service.load_model_result(data)
    #     return jsonify(load_model_result.to_dict(api_version)), 200

    return model_and_training_bp