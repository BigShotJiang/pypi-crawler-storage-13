.. include:: ../../../.github/CONTRIBUTING.rst
