from pathlib import Path
from typing import Optional
import datetime 

import streamlit as st
import streamlit.components.v1 as components


# and that the code to display that component is in the "frontend" folder
frontend_dir = (Path(__file__).parent / "frontend").absolute()
_component_func = components.declare_component(
	"streamlit_month_selector", path=str(frontend_dir)
)

def date_input(
    label: str,
    value: Optional[str] = "",
    key: Optional[str] = None,
    labelCollapse:bool = False
):
    """
    Create a Streamlit text input that returns the value whenever a key is pressed.
    """
    component_value = _component_func(
        label=label,
        value=value,
        key=key,
        default=value,
        labelCollapse=labelCollapse
    )

    return component_value


def main():
    st.write("## Example")
    col = st.columns(2)
    with col[0]:
        value = date_input("Choose date", '2025-W35', labelCollapse=False)
    with col[1]:
        st.text_input('Choose date')
    st.write(value)



if __name__ == "__main__":
    main()
