# streamlit-month-selector

this component offers you to input and choose single month from year

## Installation instructions 

```sh
pip install streamlit-month-selector
```

## Usage instructions

```python
import streamlit as st

from streamlit_month_selector import streamlit_month_selector

value = streamlit_month_selector()

st.write(value)
