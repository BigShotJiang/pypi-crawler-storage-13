CONTENT = """
import random
import networkx as nx
import matplotlib.pyplot as plt

graph = {
    0: [1, 2],
    1: [0, 2, 3],
    2: [0, 1],
    3: [1]
}
num_nodes = len(graph)
colors = [0, 1, 2, 3]
POP_SIZE, MUT_RATE, GENS = 6, 0.2, 50

def fitness(chrom):
    conflicts = sum(chrom[n] == chrom[nb] for n in graph for nb in graph[n])
    return 1 / (1 + conflicts)

def init_pop():
    return [[random.choice(colors) for _ in range(num_nodes)] for _ in range(POP_SIZE)]

def crossover(p1, p2):
    point = random.randint(1, num_nodes - 1)
    child = p1[:point] + p2[point:]
    if random.random() < MUT_RATE:
        child[random.randint(0, num_nodes - 1)] = random.choice(colors)
    return child

pop = init_pop()
for _ in range(GENS):
    pop.sort(key=lambda c: -fitness(c))
    if fitness(pop[0]) == 1.0:
        break
    new_pop = pop[:2]
    while len(new_pop) < POP_SIZE:
        p1, p2 = random.sample(pop[:4], 2)
        new_pop.append(crossover(p1, p2))
    pop = new_pop

best = pop[0]
used_colors = len(set(best))

print("Best Coloring:", best)
print("Colors Used:", used_colors)
G = nx.Graph(graph)
color_map = ['red', 'green', 'blue', 'yellow']
node_colors = [color_map[c % len(color_map)] for c in best]
nx.draw(G, with_labels=True, node_color=node_colors, node_size=800, font_color='white')
plt.title(f"Graph Coloring using GA | Colors used: {used_colors}")
plt.show()
"""

class Lab:
    def __repr__(self):
        return CONTENT

lab10 = Lab()
