from .lab1 import lab1
from .lab5 import lab5
from .lab6 import lab6
from .lab7 import lab7
from .lab10 import lab10

__all__ = ["lab1", "lab5", "lab6", "lab7", "lab10"]
