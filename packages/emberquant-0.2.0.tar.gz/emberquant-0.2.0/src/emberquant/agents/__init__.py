"""EmberQuant agents for financial processing."""

from emberquant.agents.auditor import AuditReport, AuditorAgent, AuditorConfig
from emberquant.agents.base import AgentConfig, BaseAgent
from emberquant.agents.clerk import ClerkAgent, ClerkConfig
from emberquant.agents.modeler import ModelerAgent, ModelingConfig, ForecastModel, ScenarioAnalysis, CostStructure
from emberquant.agents.controller import ControllerAgent, ControllerConfig, NarrativeReport

__all__ = [
    "BaseAgent",
    "AgentConfig",
    "ClerkAgent",
    "ClerkConfig",
    "AuditorAgent",
    "AuditorConfig",
    "AuditReport",
    "ModelerAgent",
    "ModelingConfig",
    "ForecastModel",
    "ScenarioAnalysis",
    "CostStructure",
    "ControllerAgent",
    "ControllerConfig",
    "NarrativeReport",
]
