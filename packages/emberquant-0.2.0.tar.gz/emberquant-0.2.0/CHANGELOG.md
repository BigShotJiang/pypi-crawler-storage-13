# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Released]

## [0.1.0] - 2025-11-21

### Added
- Initial release of EmberQuant
- **EmberFrame**: Semantic DataFrame with automatic financial type inference
- **EmberGraph**: DAG-based orchestration system for agent workflows
- **ClerkAgent**: Data ingestion and normalization agent
- **AuditorAgent**: Financial analysis agent with Benford's law and variance detection
- **Adapters**: Support for CSV, Excel, QuickBooks (mock), and Xero (mock)
- **Core Functions**:
  - `connect()`: Unified interface for data source connections
  - `plan()`: Rule-based execution planning
  - `execute_plan()`: Plan execution with EmberGraph
- **CLI**: Command-line interface with `audit`, `info`, and `version` commands
- Comprehensive test suite with unit and integration tests
- Full type hints throughout the codebase
- Apache 2.0 license

### Documentation
- Complete README with examples and architecture overview
- API documentation structure
- Contributing guidelines

[0.1.0]: https://github.com/emberquant/emberquant/releases/tag/v0.1.0
