import boto3
from botocore.exceptions import ClientError

class TicketTracker:
    def __init__(self, table_name, region="us-east-1"):
        self.dynamodb = boto3.resource("dynamodb", region_name=region)
        self.table = self.dynamodb.Table(table_name)

    def update_status(self, ticket_id, status, comments=""):
        """Update ticket status and comments in DynamoDB."""
        try:
            self.table.update_item(
                Key={"ticket_id": ticket_id},
                UpdateExpression="SET #s = :val, comments = :c",
                ExpressionAttributeNames={"#s": "status"},
                ExpressionAttributeValues={":val": status, ":c": comments},
            )
            return {"success": True, "ticket_id": ticket_id, "status": status}
        except ClientError as e:
            return {"success": False, "error": str(e)}

    def get_all_tickets(self):
        """Fetch all tickets for dashboard tracking."""
        try:
            response = self.table.scan()
            return response.get("Items", [])
        except ClientError as e:
            return {"success": False, "error": str(e)}