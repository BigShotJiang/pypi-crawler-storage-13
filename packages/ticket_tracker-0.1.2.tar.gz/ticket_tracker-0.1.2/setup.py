from setuptools import setup, find_packages

setup(
    name="ticket_tracker",
    version="0.1.2",
    packages=find_packages(),  # this auto-includes ticket_tracker/
    install_requires=["boto3"],
    python_requires=">=3.6",
)