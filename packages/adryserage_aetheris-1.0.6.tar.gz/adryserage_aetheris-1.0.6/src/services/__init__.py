"""
Services utilitaires : Recherche de documentation, analyse de dépendances, génération de code
"""

