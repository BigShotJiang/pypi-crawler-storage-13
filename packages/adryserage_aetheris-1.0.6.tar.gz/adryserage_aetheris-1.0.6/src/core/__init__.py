"""
Modules core : Configuration, logging, et orchestrateur principal
"""

