"""
Modèles de données (dataclasses)
"""

