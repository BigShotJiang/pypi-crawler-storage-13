"""Public exports for the screenshot batch package."""

__version__ = "0.1.0"

from .client import ScreenshotServiceClient
from .coordinator import (
    ScreenshotBatchCoordinator,
    ScreenshotBatchResult,
    ScreenshotJobSpec,
    ScreenshotMultiRunCoordinator,
    ScreenshotRunSummary,
    is_batch_successful,
)
from .exceptions import (
    ScreenshotAPIError,
    ScreenshotBatchError,
    ScreenshotClientError,
    ScreenshotConfigError,
    ScreenshotTimeoutError,
)

__all__ = [
    # Client
    "ScreenshotServiceClient",
    # Exceptions
    "ScreenshotClientError",
    "ScreenshotAPIError",
    "ScreenshotBatchError",
    "ScreenshotConfigError",
    "ScreenshotTimeoutError",
    # Coordinators and results
    "ScreenshotBatchCoordinator",
    "ScreenshotBatchResult",
    "ScreenshotJobSpec",
    "ScreenshotMultiRunCoordinator",
    "ScreenshotRunSummary",
    "is_batch_successful",
]
