"""
💀 SHADOW MONARCH FRAMEWORK 💀

Universal calling for agents AND systems:
    agent = summon("lead")
    system = summon_system("data")
    
Same interface everywhere:
    result = agent(data)
    result = system(data)
    result = await agent.run(data)
    result = await system.run(data)
"""

# Import factory (mock agents for testing)
from .factory import summon

# Import systems (provides summon_system and waitfor)
from .systems import summon_system, waitfor

# Export everything
__all__ = [
    "summon",
    "summon_system",
    "waitfor"
]


def _show_banner():
    """Show Shadow Monarch banner"""
    banner = """
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   💀 SHADOW MONARCH SYSTEMS - FIXED VERSION 💀                ║
║                                                               ║
║   UNIVERSAL CALLING STYLE:                                   ║
║   ├─ system = summon_system("data")                          ║
║   ├─ result = system(data)              # Sync               ║
║   ├─ result = await system.run(data)    # Async              ║
║   └─ result = waitfor(system.run(data)) # Blocking           ║
║                                                               ║
║   STREAMING STYLE:                                           ║
║   ├─ system.run(data, stream=True)                           ║
║   └─ while system.works:                                     ║
║       print(system.current)                                  ║
║                                                               ║
║   Simple as fuck. Works everywhere. Shadow Monarch style.    ║
║                                                               ║
║   💀 ARISE 💀                                                  ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
    """
    print(banner)

_show_banner()
