"""Luminosity entities."""
