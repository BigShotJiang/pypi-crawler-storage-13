"""MQTT Entities."""
