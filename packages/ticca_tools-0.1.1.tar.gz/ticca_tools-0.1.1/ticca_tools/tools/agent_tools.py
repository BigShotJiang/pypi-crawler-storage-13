"""Agent tools - list and invoke agents."""

import logging

logger = logging.getLogger(__name__)


def register_agent_tools(server):
    """
    Register agent tools with the server.

    Args:
        server: ToolServer instance
    """

    async def list_agents_impl():
        """List available agents."""
        # TODO: Implement actual agent listing
        return {
            'success': True,
            'agents': [],
            'count': 0
        }

    async def invoke_agent_impl(agent_name: str, prompt: str):
        """Invoke another agent."""
        # TODO: Implement actual agent invocation
        return {
            'success': True,
            'agent': agent_name,
            'output': f'Response from {agent_name} (stub)'
        }

    server.register_tool(
        name='list_agents',
        func=list_agents_impl,
        category='Agent Tools',
        description='List available agents',
        requires_approval=False
    )

    server.register_tool(
        name='invoke_agent',
        func=invoke_agent_impl,
        category='Agent Tools',
        description='Invoke another agent',
        requires_approval=False
    )

    logger.info(f"✅ Registered 2 agent tools")
