"""Command runner tools - shell command execution."""

import logging

logger = logging.getLogger(__name__)


def register_command_tools(server):
    """
    Register command runner tools with the server.

    Args:
        server: ToolServer instance
    """

    async def run_shell_command_impl(command: str, cwd: str = None, timeout: int = 60):
        """Execute a shell command."""
        # TODO: Implement actual shell command execution
        # IMPORTANT: This should match the implementation from backend/app/tools/command_runner.py
        return {
            'success': True,
            'command': command,
            'stdout': f'Output of: {command} (stub)',
            'stderr': '',
            'exit_code': 0,
            'execution_time': 0.1
        }

    async def share_reasoning_impl(reasoning: str, next_steps: str = None):
        """Share agent reasoning."""
        # TODO: Implement reasoning sharing
        return {
            'success': True
        }

    server.register_tool(
        name='agent_run_shell_command',
        func=run_shell_command_impl,
        category='Command Runner',
        description='Execute shell commands with monitoring',
        requires_approval=True
    )

    server.register_tool(
        name='agent_share_your_reasoning',
        func=share_reasoning_impl,
        category='Command Runner',
        description='Share agent reasoning and next steps',
        requires_approval=False
    )

    logger.info(f"✅ Registered 2 command runner tools")
