"""
gRPC Tool Server Implementation

Hosts tools and executes them remotely with API key authentication.
"""

import asyncio
import json
import logging
import time
import traceback
from concurrent import futures
from typing import Dict, Any, Callable, Optional

import grpc
from grpc import aio

from ticca_tools.server.auth import AuthManager

# TODO: Generate from proto
# from ticca_tools.generated import tool_service_pb2, tool_service_pb2_grpc

logger = logging.getLogger(__name__)


class ToolRegistry:
    """Registry for tools available on this server."""

    def __init__(self):
        self._tools: Dict[str, Callable] = {}
        self._metadata: Dict[str, Dict[str, Any]] = {}

    def register(
        self,
        name: str,
        func: Callable,
        category: str,
        description: str,
        requires_approval: bool = False,
        schema: Dict[str, Any] = None
    ):
        """Register a tool function."""
        self._tools[name] = func
        self._metadata[name] = {
            'name': name,
            'category': category,
            'description': description,
            'requires_approval': requires_approval,
            'schema': schema or {}
        }
        logger.debug(f"✅ Registered tool: {name}")

    def get_tool(self, name: str) -> Optional[Callable]:
        """Get tool function by name."""
        return self._tools.get(name)

    def list_tools(self, category: str = None) -> list:
        """List all tools, optionally filtered by category."""
        tools = []
        for name, meta in self._metadata.items():
            if category is None or meta['category'] == category:
                tools.append(meta)
        return tools

    def get_metadata(self, name: str) -> Dict[str, Any]:
        """Get metadata for a specific tool."""
        return self._metadata.get(name, {})

    def get_tool_count(self) -> int:
        """Get the total number of registered tools."""
        return len(self._tools)


class ToolExecutionServicer:  # (tool_service_pb2_grpc.ToolExecutionServiceServicer):
    """
    gRPC servicer for tool execution with authentication.
    """

    def __init__(
        self,
        registry: ToolRegistry,
        auth_manager: AuthManager,
        server_id: str
    ):
        self._registry = registry
        self._auth_manager = auth_manager
        self._server_id = server_id
        self._start_time = time.time()
        self._request_count = 0
        self._success_count = 0
        self._error_count = 0

    async def ExecuteTool(self, request, context):
        """
        Execute a tool with authentication.

        ALL requests must include valid API key in metadata.
        """
        # ============================================================
        # AUTHENTICATION CHECK
        # ============================================================
        self._auth_manager.abort_if_unauthorized(context)

        # ============================================================
        # TOOL EXECUTION
        # ============================================================
        start_time = time.time()
        request_id = request.request_id
        tool_name = request.tool_name

        self._request_count += 1

        logger.info(f"📥 [{request_id}] {tool_name}")

        try:
            # Get tool function
            tool_func = self._registry.get_tool(tool_name)
            if not tool_func:
                self._error_count += 1
                logger.error(f"❌ [{request_id}] Tool not found: {tool_name}")
                # return tool_service_pb2.ToolResponse(
                #     request_id=request_id,
                #     success=False,
                #     error_message=f"Tool '{tool_name}' not found on server '{self._server_id}'",
                #     execution_time_ms=int((time.time() - start_time) * 1000)
                # )
                raise NotImplementedError("Proto generation required")

            # Parse arguments
            try:
                arguments = json.loads(request.arguments_json)
            except json.JSONDecodeError as e:
                self._error_count += 1
                logger.error(f"❌ [{request_id}] Invalid JSON: {e}")
                # return tool_service_pb2.ToolResponse(...)
                raise NotImplementedError("Proto generation required")

            # Execute with timeout
            timeout = request.timeout_seconds if request.timeout_seconds > 0 else None

            try:
                if timeout:
                    result = await asyncio.wait_for(
                        tool_func(**arguments),
                        timeout=timeout
                    )
                else:
                    result = await tool_func(**arguments)

                execution_time_ms = int((time.time() - start_time) * 1000)
                self._success_count += 1

                logger.info(f"✅ [{request_id}] Completed in {execution_time_ms}ms")

                # Serialize result
                result_json = json.dumps(result)

                # return tool_service_pb2.ToolResponse(...)
                raise NotImplementedError("Proto generation required")

            except asyncio.TimeoutError:
                self._error_count += 1
                logger.error(f"⏰ [{request_id}] Timeout after {timeout}s")
                # return tool_service_pb2.ToolResponse(...)
                raise NotImplementedError("Proto generation required")

            except Exception as e:
                self._error_count += 1
                logger.error(f"💥 [{request_id}] Execution failed: {e}")
                logger.error(traceback.format_exc())
                # return tool_service_pb2.ToolResponse(...)
                raise NotImplementedError("Proto generation required")

        except Exception as e:
            self._error_count += 1
            logger.error(f"💥 [{request_id}] Request handling failed: {e}")
            logger.error(traceback.format_exc())
            # return tool_service_pb2.ToolResponse(...)
            raise NotImplementedError("Proto generation required")

    async def ExecuteToolStreaming(self, request, context):
        """Execute tool with streaming (authenticated)."""
        self._auth_manager.abort_if_unauthorized(context)

        # TODO: Implement streaming after proto generation
        raise NotImplementedError("Proto generation required")

    async def ListTools(self, request, context):
        """List available tools (authenticated)."""
        self._auth_manager.abort_if_unauthorized(context)

        tools = self._registry.list_tools(category=request.category or None)

        # TODO: Return actual proto message
        raise NotImplementedError("Proto generation required")

    async def GetToolSchema(self, request, context):
        """Get tool schema (authenticated)."""
        self._auth_manager.abort_if_unauthorized(context)

        meta = self._registry.get_metadata(request.tool_name)

        if not meta:
            context.abort(
                grpc.StatusCode.NOT_FOUND,
                f"Tool '{request.tool_name}' not found"
            )

        # TODO: Return actual proto message
        raise NotImplementedError("Proto generation required")

    async def HealthCheck(self, request, context):
        """
        Health check endpoint.

        NOTE: Health check does NOT require authentication
        (so main backend can check server status before registering)
        """
        uptime = int(time.time() - self._start_time)
        tool_count = self._registry.get_tool_count()

        # TODO: Return actual proto message
        # return tool_service_pb2.HealthCheckResponse(
        #     status=tool_service_pb2.HealthCheckResponse.HEALTHY,
        #     version="1.0.0",
        #     tool_count=tool_count,
        #     uptime_seconds=uptime,
        #     server_id=self._server_id,
        #     request_count=self._request_count,
        #     success_count=self._success_count,
        #     error_count=self._error_count
        # )
        raise NotImplementedError("Proto generation required")


class ToolServer:
    """
    gRPC server for tool execution with API key authentication.
    """

    def __init__(
        self,
        port: int = 50051,
        host: str = '0.0.0.0',
        max_workers: int = 10,
        auth_manager: AuthManager = None,
        server_id: str = None
    ):
        self._port = port
        self._host = host
        self._max_workers = max_workers
        self._registry = ToolRegistry()
        self._auth_manager = auth_manager or AuthManager()
        self._server_id = server_id or 'unknown'
        self._server = None

    def register_tool(
        self,
        name: str,
        func: Callable,
        category: str,
        description: str,
        requires_approval: bool = False,
        schema: Dict[str, Any] = None
    ):
        """Register a tool on this server."""
        self._registry.register(
            name, func, category, description,
            requires_approval, schema
        )

    def get_tool_count(self) -> int:
        """Get the number of registered tools."""
        return self._registry.get_tool_count()

    async def start(self):
        """Start the gRPC server."""
        self._server = aio.server(
            futures.ThreadPoolExecutor(max_workers=self._max_workers)
        )

        servicer = ToolExecutionServicer(
            self._registry,
            self._auth_manager,
            self._server_id
        )

        # TODO: Add servicer after proto generation
        # tool_service_pb2_grpc.add_ToolExecutionServiceServicer_to_server(
        #     servicer, self._server
        # )

        listen_addr = f'{self._host}:{self._port}'
        self._server.add_insecure_port(listen_addr)

        logger.info(f"🚀 Starting gRPC server on {listen_addr}")
        await self._server.start()

        logger.info(f"✅ Server started with {self.get_tool_count()} tools")

    async def stop(self, grace_period: float = 5.0):
        """Stop the gRPC server."""
        if self._server:
            logger.info("🛑 Stopping server...")
            await self._server.stop(grace_period)
            logger.info("✅ Server stopped")

    async def wait_for_termination(self):
        """Wait for server termination."""
        if self._server:
            await self._server.wait_for_termination()
