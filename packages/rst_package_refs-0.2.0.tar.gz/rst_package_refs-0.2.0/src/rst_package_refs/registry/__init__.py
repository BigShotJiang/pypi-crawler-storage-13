"""Root of registry collection."""
