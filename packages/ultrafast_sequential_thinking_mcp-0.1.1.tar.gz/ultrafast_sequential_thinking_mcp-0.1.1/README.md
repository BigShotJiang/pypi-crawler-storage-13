# ultrafast-sequential-thinking-mcp

Python wrapper around the Rust [techgopal/ultrafast-mcp-sequential-thinking](https://github.com/techgopal/ultrafast-mcp-sequential-thinking) project using PyO3.

## Usage

```bash
python cli/start_server.py
```

## Details

This is a PyO3 wrapper that provides Python bindings for the lite version of the Rust ultrafast-mcp-sequential-thinking MCP server with minimal configuration. For detailed documentation and features, see the submodule `ultrafast-mcp-sequential-thinking/`.
