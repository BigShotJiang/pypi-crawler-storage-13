use pyo3::prelude::*;

mod server_main;

/// A Python module implemented in Rust.
#[pymodule]
mod ultrafast_sequential_thinking_mcp {
    use crate::server_main;
    use pyo3::prelude::*;

    #[pyfunction]
    fn server(py: Python) -> PyResult<Bound<PyAny>> {
        pyo3_async_runtimes::tokio::future_into_py(py, async {
            server_main::server_main().await.map_err(|e| {
                PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("Server error: {}", e))
            })?;
            Ok(())
        })
    }
}
