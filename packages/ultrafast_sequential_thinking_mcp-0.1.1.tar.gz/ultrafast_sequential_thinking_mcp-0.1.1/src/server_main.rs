use tracing::{error, info};
use tracing_subscriber::EnvFilter;
use ultrafast_mcp::{ServerCapabilities, ServerInfo, ToolsCapability};
use ultrafast_mcp_sequential_thinking::SequentialThinkingServer;

pub(crate) async fn server_main() -> Result<(), Box<dyn std::error::Error>> {
    // Initialize basic logging
    init_logging();

    info!("Starting Sequential Thinking Server (Lite)");

    // Create server with minimal configuration
    let server = SequentialThinkingServer::with_config(
        ServerInfo {
            name: "sequential-thinking-lite".to_string(),
            version: env!("CARGO_PKG_VERSION").to_string(),
            description: Some(
                "Minimal MCP server for sequential thinking - stdio only".to_string(),
            ),
            homepage: Some(
                "https://github.com/techgopal/ultrafast-mcp-sequential-thinking".to_string(),
            ),
            repository: Some(
                "https://github.com/techgopal/ultrafast-mcp-sequential-thinking".to_string(),
            ),
            authors: Some(vec!["techgopal <techgopal2@gmail.com>".to_string()]),
            license: Some("MIT".to_string()),
        },
        ServerCapabilities {
            tools: Some(ToolsCapability {
                list_changed: Some(true),
            }),
            ..Default::default()
        },
        false, // enable thought logging
    );

    // Create and run MCP server with stdio transport only
    let mcp_server = server.create_mcp_server();

    info!("Server ready - using stdio transport only");
    info!("No configuration needed - running with default settings");

    // Run the server
    if let Err(e) = mcp_server.run_stdio().await {
        error!("Server error: {}", e);
        return Err(e.into());
    }

    Ok(())
}

/// Initialize minimal logging configuration
fn init_logging() {
    let env_filter = EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info"));

    tracing_subscriber::fmt()
        .with_env_filter(env_filter)
        .with_ansi(atty::is(atty::Stream::Stderr))
        .init();
}
