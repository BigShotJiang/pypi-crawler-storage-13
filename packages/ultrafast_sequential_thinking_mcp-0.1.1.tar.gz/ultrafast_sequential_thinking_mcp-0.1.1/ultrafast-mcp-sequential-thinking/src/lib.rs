//! # UltraFast MCP Sequential Thinking
//!
//! High-performance, Rust-based Model Context Protocol (MCP) stdio server implementation
//! for sequential thinking, built on the UltraFast MCP framework.
//!
//! This library provides a complete server-side implementation of the sequential thinking concept
//! using stdio transport, offering significant performance advantages over the official
//! TypeScript version while maintaining full compatibility with the MCP 2025-06-18 specification.
//!
//! ## Features
//!
//! - **Stdio Transport**: Uses stdio for MCP protocol communication
//! - **Dynamic Problem Breakdown**: Break complex problems into manageable steps
//! - **Reflective Thinking**: Revise and refine thoughts as understanding deepens
//! - **Branching Logic**: Explore alternative paths of reasoning
//! - **Adaptive Planning**: Adjust the total number of thoughts dynamically
//! - **Solution Verification**: Generate and verify solution hypotheses
//! - **Context Preservation**: Maintain thinking context across multiple steps
//! - **High Performance**: 10-100x faster than TypeScript implementation
//! - **Type Safety**: Compile-time guarantees for protocol compliance
//!
//! ## Quick Start
//!
//! This crate provides a high-performance, type-safe Rust implementation of the Model Context Protocol (MCP) server for sequential thinking. It communicates via stdio and can be used with any MCP-compatible client.
//!
//! ### Example: Create a Server and Process Thoughts
//!
//! ```rust,no_run
//! use ultrafast_mcp_sequential_thinking::{SequentialThinkingServer, ThoughtData};
//!
//! #[tokio::main]
//! async fn main() -> anyhow::Result<()> {
//!     // Create a new sequential thinking server
//!     let server = SequentialThinkingServer::new();
//!
//!     // Create an MCP stdio server instance
//!     let _mcp_server = server.create_mcp_server();
//!
//!     // The MCP server can now be started to listen for stdio connections
//!
//!     Ok(())
//! }
//! ```
//!
//! See the crate documentation and module docs for more details and advanced usage.

pub mod config;
pub mod session;
pub mod thinking;

// Re-export main types for convenience
pub use session::{SessionManager, SessionMetadata, ThinkingSession};
pub use thinking::{ThinkingEngine, ThoughtData, ThoughtProcessor};

// Re-export server type
pub use crate::thinking::server::SequentialThinkingServer;

// Re-export error types
pub use crate::thinking::error::{SequentialThinkingError, SequentialThinkingResult};

// Re-export configuration types
pub use crate::config::{ServerConfig, ThinkingConfig};

pub use crate::thinking::ThinkingStats;


/// Result type for sequential thinking operations
pub type Result<T> = std::result::Result<T, SequentialThinkingError>;

/// Default configuration for the sequential thinking server
pub fn default_server_config() -> ServerConfig {
    ServerConfig {
        name: "ultrafast-sequential-thinking".to_string(),
        version: env!("CARGO_PKG_VERSION").to_string(),
        thinking: ThinkingConfig::default(),
        logging: config::LoggingConfig::default(),
        security: config::SecurityConfig::default(),
    }
}


#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_configs() {
        let server_config = default_server_config();
        assert_eq!(server_config.name, "ultrafast-sequential-thinking");
        assert_eq!(server_config.version, env!("CARGO_PKG_VERSION"));
    }
}
