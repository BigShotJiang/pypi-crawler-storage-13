import asyncio
from ultrafast_sequential_thinking_mcp import server



async def main():
    await server()


asyncio.run(main())
