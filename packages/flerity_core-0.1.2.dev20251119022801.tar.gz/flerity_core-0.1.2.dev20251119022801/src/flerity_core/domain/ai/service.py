"""Consolidated AI service with all functionality merged."""

import hashlib
import os
import re
from typing import Any, TYPE_CHECKING
from uuid import UUID

from flerity_core.db.uow import UnitOfWork

if TYPE_CHECKING:
    from ..catalogs.service import CatalogsService
from flerity_core.utils.clock import utcnow
from flerity_core.utils.logging import get_logger
from flerity_core.utils.request_tracking import RequestTracker
from flerity_core.utils.domain_logger import get_domain_logger
from flerity_core.utils.errors import NotFoundError

# Use relative imports
from .schemas import (
    AIProviderTimeout,
    IcebreakerRequest,
    IcebreakerResponse,
    JobCreatedResponse,
    SuggestionItem,
    SuggestionRequest,
    SuggestionResponse,
    ThreadContext,
)
from .prompts_repository import AIPromptsRepository
from .prompt_formatter import prompt_formatter

logger = get_logger(__name__)
domain_logger = get_domain_logger(__name__)


class PromptNotFoundError(NotFoundError):
    """Raised when AI prompt template is not found in database."""
    
    def __init__(self, kind: str, tone: str, language: str, country: str = None, gender: str = None):
        self.kind = kind
        self.tone = tone
        self.language = language
        self.country = country
        self.gender = gender
        
        message = f"AI prompt template not found: kind={kind}, tone={tone}, language={language}"
        if country:
            message += f", country={country}"
        if gender:
            message += f", gender={gender}"
            
        super().__init__(message)


class ToneNotFoundError(NotFoundError):
    """Raised when tone description is not found in database."""
    
    def __init__(self, tone: str, language: str):
        self.tone = tone
        self.language = language
        super().__init__(f"Tone description not found: tone={tone}, language={language}")


class AIService:
    """AI service for generating suggestions and icebreakers."""

    def __init__(
        self,
        bedrock_client,
        catalogs_service: "CatalogsService",
        ai_generation_repository=None,
        rag_service=None,
        prompts_repo=None  # Add for backward compatibility
    ):
        self.bedrock_client = bedrock_client
        self.catalogs_service = catalogs_service
        self.ai_generation_repository = ai_generation_repository
        self.rag_service = rag_service
        self.prompts_repo = prompts_repo  # For backward compatibility with tests

    def _get_user_locale(self, context: ThreadContext) -> str:
        """Get user locale from context."""
        if hasattr(context, 'user_locale') and context.user_locale:
            return context.user_locale.language
        elif hasattr(context, 'locale') and context.locale:
            return context.locale.language
        return 'pt-BR'  # Default

    async def generate_suggestions(
        self,
        context: ThreadContext,
        request: SuggestionRequest,
        uow: UnitOfWork
    ) -> SuggestionResponse:
        """Generate conversation suggestions."""
        return await self._generate(
            context=context,
            request=request,
            uow=uow,
            operation="generate_suggestions",
            prompt_kind="suggestion",
            max_tokens=500,
            temperature=0.7,
            response_class=SuggestionResponse
        )

    async def generate_icebreakers(
        self,
        context: ThreadContext,
        request: IcebreakerRequest,
        uow: UnitOfWork
    ) -> IcebreakerResponse:
        """Generate icebreakers."""
        return await self._generate(
            context=context,
            request=request,
            uow=uow,
            operation="generate_icebreakers",
            prompt_kind="icebreaker",
            max_tokens=400,
            temperature=0.8,
            response_class=IcebreakerResponse
        )

    async def _generate(
        self,
        context: ThreadContext,
        request: SuggestionRequest | IcebreakerRequest,
        uow: UnitOfWork,
        operation: str,
        prompt_kind: str,
        max_tokens: int,
        temperature: float,
        response_class
    ):
        """Generic generation method."""
        with RequestTracker(user_id=context.user_id, operation=operation) as tracker:
            try:
                tracking_context = domain_logger.operation_start(
                    operation,
                    user_id=str(context.user_id),
                    thread_id=str(context.thread_id) if context.thread_id else None,
                    tone=request.tone,
                    max_suggestions=request.max_suggestions
                )

                prompt = await self._build_prompt(context, request, prompt_kind, uow)
                response_text = await self._generate_text(prompt, max_tokens, temperature)
                items = self._parse_response(response_text)
                generation_id = await self._create_audit_record(
                    context, request, prompt, response_text, items, uow
                )

                result = self._build_response(
                    response_class, context, items, generation_id, request
                )

                domain_logger.operation_success(tracking_context, {
                    "items_count": len(items),
                    "generation_id": str(generation_id) if generation_id else None
                })
                tracker.log_success(items_count=len(items))

                return result

            except Exception as e:
                error_id = tracker.log_error(e, context={
                    "user_id": str(context.user_id),
                    "thread_id": str(context.thread_id) if context.thread_id else None
                })
                domain_logger.operation_error(tracking_context, str(e), {"error_id": error_id})
                raise

    async def _build_prompt(
        self,
        context: ThreadContext,
        request: SuggestionRequest | IcebreakerRequest,
        kind: str,
        uow: UnitOfWork
    ) -> str:
        """Build prompt using database template."""
        language = self._get_user_locale(context)
        
        # Get template from database (required)
        prompt_template = await self._get_prompt_template(kind, language, request.tone, uow)
        
        if not prompt_template:
            raise PromptNotFoundError(
                kind=kind,
                tone=request.tone,
                language=language
            )
        
        # Build variables and format template
        variables = await self._build_prompt_variables(context, request, kind, language)
        return prompt_formatter.format_template(prompt_template, variables)

    async def _get_prompt_template(self, kind: str, language: str, tone: str, uow: UnitOfWork) -> str | None:
        """Get prompt template from database."""
        # Use prompts_repo if available (for testing)
        if self.prompts_repo:
            template = await self.prompts_repo.get_prompt(
                kind=kind,
                context_type="general",
                tone=tone,
                country="BR" if language == "pt-BR" else "US",
                gender="neutral"
            )
            return template.template if template else None
        
        # Production path
        country = "BR" if language == "pt-BR" else "US"
        
        # Create repository with UoW session
        repository = AIPromptsRepository(uow.session)
        
        # Try specific tone first
        template = await repository.get_prompt(
            kind=kind,
            context_type="general",
            tone=tone,
            country=country,
            gender="neutral"
        )
        
        # Fallback to friendly tone if specific tone not found
        if not template and tone != "friendly":
            template = await repository.get_prompt(
                kind=kind,
                context_type="general",
                tone="friendly",
                country=country,
                gender="neutral"
            )
        
        # Return the template content, not the object
        return template.template if template else None

    async def _build_prompt_variables(
        self,
        context: ThreadContext,
        request: SuggestionRequest | IcebreakerRequest,
        kind: str,
        language: str
    ) -> dict[str, Any]:
        """Build variables for prompt template."""
        tone_description = await self._get_tone_description(request.tone, language)
        
        if kind == "suggestion":
            return prompt_formatter.build_suggestion_variables(
                messages_context=self._build_messages_context(context, request),
                max_suggestions=request.max_suggestions,
                tone_description=tone_description,
                hint_section=self._build_hint_section_sync(request, language),
                rag_examples="",  # Simplified for now
                age_range=self._calculate_age_range(context),
                context=context
            )
        else:  # icebreaker
            return prompt_formatter.build_icebreaker_variables(
                max_suggestions=request.max_suggestions,
                tone_description=tone_description,
                context_section=self._build_context_section(request, language),
                age_range=self._calculate_age_range(context),
                context=context
            )

    async def _get_tone_description(self, tone: str, language: str) -> str:
        """Get tone description from catalogs service."""
        try:
            description = await self.catalogs_service.get_tone_description(tone, language)
            if not description:
                raise ToneNotFoundError(tone=tone, language=language)
            return description
        except Exception as e:
            logger.error(f"Failed to get tone description from catalogs: {e}")
            raise ToneNotFoundError(tone=tone, language=language) from e

    def _build_hint_section_sync(self, request: SuggestionRequest, language: str) -> str:
        """Build hint section for suggestions."""
        if not hasattr(request, 'hint') or not request.hint:
            return ""
        
        sanitized_hint = self._sanitize_hint(request.hint)
        if not sanitized_hint:
            return ""
        
        hint_labels = {
            'pt-BR': f"- Dica adicional: {sanitized_hint}",
            'en-US': f"- Additional hint: {sanitized_hint}",
            'es-ES': f"- Pista adicional: {sanitized_hint}"
        }
        return hint_labels.get(language, hint_labels['pt-BR'])

    def _sanitize_hint(self, hint: str) -> str:
        """Sanitize hint input."""
        if not hint:
            return ""
        
        sanitized = re.sub(r'[<>"\']', '', hint.strip())
        return sanitized[:200]

    def _build_messages_context(self, context: ThreadContext, request: SuggestionRequest) -> str:
        """Build messages context for suggestions."""
        last_n = getattr(request, 'last_n_messages', 10)
        return "\n".join([
            f"- {msg.get('sender', 'Unknown')}: {msg.get('content', '')}"
            for msg in context.recent_messages[-last_n:]
        ])

    def _build_context_section(self, request: IcebreakerRequest, language: str) -> str:
        """Build context section for icebreakers."""
        context_parts = []
        
        if hasattr(request, 'bio_text') and request.bio_text:
            bio_labels = {
                'pt-BR': f"Informações do perfil: {request.bio_text}",
                'en-US': f"Profile information: {request.bio_text}",
                'es-ES': f"Información del perfil: {request.bio_text}"
            }
            context_parts.append(bio_labels.get(language, bio_labels['pt-BR']))
        
        if hasattr(request, 'image_url') and request.image_url:
            image_labels = {
                'pt-BR': "A pessoa compartilhou uma foto de perfil. Use detalhes visuais para criar icebreakers personalizados.",
                'en-US': "The person shared a profile photo. Use visual details to create personalized icebreakers.",
                'es-ES': "La persona compartió una foto de perfil. Usa detalles visuales para crear icebreakers personalizados."
            }
            context_parts.append(image_labels.get(language, image_labels['pt-BR']))
        
        if context_parts:
            context_instructions = {
                'pt-BR': "\n\nUse essas informações para criar icebreakers personalizados e relevantes.",
                'en-US': "\n\nUse this information to create personalized and relevant icebreakers.",
                'es-ES': "\n\nUsa esta información para crear icebreakers personalizados y relevantes."
            }
            instruction = context_instructions.get(language, context_instructions['pt-BR'])
            return "\n\n" + "\n\n".join(context_parts) + instruction
        
        return ""

    def _calculate_age_range(self, context: ThreadContext) -> str:
        """Calculate age range from context."""
        if hasattr(context, 'user_birth_year') and context.user_birth_year:
            from datetime import datetime
            current_year = datetime.now().year
            current_age = current_year - context.user_birth_year
            min_age = max(18, current_age - 5)
            max_age = min(65, current_age + 5)
            return f"{min_age}-{max_age}"
        return "25-45"

    async def _generate_text(self, prompt: str, max_tokens: int, temperature: float) -> str:
        """Generate text using Bedrock."""
        if not self.bedrock_client:
            raise AIProviderTimeout("Bedrock client not available")
        
        return await self.bedrock_client.generate_text(
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature
        )



    def _parse_response(self, response: str) -> list[SuggestionItem]:
        """Parse AI response into suggestion items."""
        import json
        
        # Try JSON parsing first
        try:
            parsed = json.loads(response.strip())
            if isinstance(parsed, list):
                return [SuggestionItem(text=item) for item in parsed if item and len(item) > 3][:5]
        except (json.JSONDecodeError, ValueError):
            pass
        
        # Fallback to line-by-line parsing
        items = []
        lines = response.strip().split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Remove numbering, bullets, etc.
            line = re.sub(r'^[\d\.\-\*\+\s]+', '', line).strip()
            if line and len(line) > 3:
                items.append(SuggestionItem(text=line))
        
        return items[:5]
    
    # Backward compatibility alias
    def _parse_suggestions(self, response: str) -> list[SuggestionItem]:
        """Backward compatibility alias for _parse_response."""
        return self._parse_response(response)
    
    def _parse_icebreakers(self, response: str) -> list[SuggestionItem]:
        """Backward compatibility alias for _parse_response."""
        return self._parse_response(response)
    
    def _build_topic_guidance(self, topics: list, avoid_topics: list, language: str) -> str:
        """Build topic guidance section for prompts."""
        # Fallback to English if language not supported
        if language not in ['pt-BR', 'en-US', 'es-ES']:
            language = 'en-US'
        
        guidance_parts = []
        
        if topics:
            topic_names = [topic.name for topic in topics if hasattr(topic, 'name')]
            if topic_names:
                labels = {
                    'pt-BR': f"Focar em tópicos: {', '.join(topic_names)}",
                    'en-US': f"Focus on topics: {', '.join(topic_names)}",
                    'es-ES': f"Enfocarse en temas: {', '.join(topic_names)}"
                }
                guidance_parts.append(labels.get(language, labels['en-US']))
        
        if avoid_topics:
            avoid_names = []
            for topic in avoid_topics:
                if hasattr(topic, 'name'):
                    avoid_names.append(topic.name)
                elif hasattr(topic, 'description'):
                    avoid_names.append(topic.description)
            if avoid_names:
                labels = {
                    'pt-BR': f"Evitar tópicos: {', '.join(avoid_names)}",
                    'en-US': f"Avoid topics: {', '.join(avoid_names)}",
                    'es-ES': f"Evitar temas: {', '.join(avoid_names)}"
                }
                guidance_parts.append(labels.get(language, labels['en-US']))
        
        return '\n'.join(guidance_parts) if guidance_parts else ''

    def _build_response(
        self,
        response_class,
        context: ThreadContext,
        items: list[SuggestionItem],
        generation_id: UUID | None,
        request: SuggestionRequest | IcebreakerRequest
    ):
        """Build response object."""
        if response_class == SuggestionResponse:
            return SuggestionResponse(
                thread_id=context.thread_id,
                suggestions=items,
                generated_at=utcnow(),
                based_on={"last_n_messages": getattr(request, 'last_n_messages', 10)},
                generation_id=generation_id
            )
        else:  # IcebreakerResponse
            return IcebreakerResponse(
                thread_id=context.thread_id,
                icebreakers=items,
                generated_at=utcnow(),
                generation_id=generation_id
            )

    async def _create_audit_record(
        self,
        context: ThreadContext = None,
        request: SuggestionRequest | IcebreakerRequest = None,
        prompt: str = None,
        response: str = None,
        items: list[SuggestionItem] = None,
        uow: UnitOfWork = None,
        **kwargs  # Accept additional kwargs for backward compatibility
    ) -> UUID | None:
        """Create audit record for generation."""
        if not self.ai_generation_repository:
            return None
        
        try:
            # Handle both old and new calling patterns
            if 'thread_id' in kwargs:
                # Old pattern - called with kwargs only
                thread_id = kwargs.get('thread_id')
                user_id = None  # Not available in old pattern
                request_type = kwargs.get('kind', 'unknown')
                prompt_text = kwargs.get('prompt_hash', '')
                response_text = str(kwargs.get('output', {}))
                items_count = len(kwargs.get('output', {}).get('suggestions', []))
                uow_param = kwargs.get('uow', uow)
            else:
                # New pattern
                thread_id = context.thread_id if context else None
                user_id = context.user_id if context else None
                request_type = type(request).__name__ if request else 'unknown'
                prompt_text = prompt or ''
                response_text = response or ''
                items_count = len(items) if items else 0
                uow_param = uow
            
            if not uow_param:
                return None
                
            record = await self.ai_generation_repository.create_generation_record(
                user_id=user_id,
                thread_id=thread_id,
                request_type=request_type,
                prompt=prompt_text,
                response=response_text,
                items_count=items_count,
                uow=uow_param
            )
            return record.id if record else None
        except Exception:
            return None

    async def _build_suggestion_prompt(
        self,
        context: ThreadContext,
        request: SuggestionRequest,
        uow: UnitOfWork
    ) -> str:
        """Build suggestion prompt - backward compatibility method."""
        return await self._build_prompt(context, request, "suggestion", uow)
    
    async def _build_icebreaker_prompt(
        self,
        context: ThreadContext,
        request: IcebreakerRequest,
        uow: UnitOfWork
    ) -> str:
        """Build icebreaker prompt - backward compatibility method."""
        return await self._build_prompt(context, request, "icebreaker", uow)

    async def get_job_status(self, job_id: UUID, uow: UnitOfWork) -> dict | None:
        """Get job status by ID."""
        from flerity_core.domain.ai.repository import AIJobsRepository
        
        with RequestTracker(operation="get_job_status") as tracker:
            try:
                tracking_context = domain_logger.operation_start(
                    "get_job_status",
                    job_id=str(job_id)
                )
                
                repository = AIJobsRepository(uow.session)
                job = await repository.get_by_id(job_id)
                
                if not job:
                    domain_logger.operation_success(tracking_context, {"found": False})
                    tracker.log_success(found=False)
                    return None
                
                result = {
                    "id": str(job.id),
                    "user_id": str(job.user_id),
                    "thread_id": str(job.thread_id) if job.thread_id else None,
                    "kind": job.kind,
                    "status": job.status,
                    "params": job.params,
                    "result": job.result,
                    "error": job.error,
                    "created_at": job.created_at.isoformat(),
                    "updated_at": job.updated_at.isoformat()
                }
                
                domain_logger.operation_success(tracking_context, {"found": True})
                tracker.log_success(found=True)
                
                return result
                
            except Exception as e:
                error_id = tracker.log_error(e, context={"job_id": str(job_id)})
                domain_logger.operation_error(tracking_context, str(e), {"error_id": error_id})
                raise


