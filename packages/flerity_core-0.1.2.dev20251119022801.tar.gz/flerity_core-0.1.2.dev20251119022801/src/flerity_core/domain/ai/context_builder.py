"""AI domain context builder - converts generic UserContext to ThreadContext."""

from uuid import UUID

from ..auth.schemas import UserContext
from .schemas import ThreadContext, UserLocale


def build_thread_context(
    user_context: UserContext,
    thread_id: UUID | None = None,
    recent_messages: list | None = None
) -> ThreadContext:
    """
    Convert UserContext to ThreadContext for AI services.
    
    This function belongs to the AI domain and knows how to construct
    ThreadContext from generic UserContext.
    
    Args:
        user_context: Generic user context from JWT token
        thread_id: Optional thread ID
        recent_messages: Optional list of recent messages
        
    Returns:
        ThreadContext with AI-specific fields
    """
    return ThreadContext(
        thread_id=thread_id,
        user_id=user_context.user_id,
        recent_messages=recent_messages or [],
        locale=UserLocale(
            language=user_context.locale.split('-')[0],  # pt-BR -> pt
            country=user_context.country
        ),
        user_tier=user_context.tier,
        user_birth_year=user_context.birth_year
    )
