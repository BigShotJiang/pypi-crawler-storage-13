"""Analytics domain context builder - converts generic UserContext to analytics-specific context."""

from ..auth.schemas import UserContext


def build_analytics_context(
    user_context: UserContext,
    timezone: str | None = None
) -> dict:
    """
    Convert UserContext to analytics context.
    
    This function belongs to the Analytics domain and creates
    a context dict with analytics-specific fields.
    
    Args:
        user_context: Generic user context from JWT token
        timezone: Optional timezone override
        
    Returns:
        Dict with analytics context fields
    """
    return {
        "user_id": user_context.user_id,
        "tier": user_context.tier,
        "locale": user_context.locale,
        "timezone": timezone or "UTC",
        "age_range": user_context.age_range,
        "country": user_context.country
    }
