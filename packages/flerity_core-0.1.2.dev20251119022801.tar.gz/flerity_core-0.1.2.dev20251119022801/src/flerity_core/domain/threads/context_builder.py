"""Threads domain context builder - converts generic UserContext to threads-specific context."""

from ..auth.schemas import UserContext


def build_threads_context(user_context: UserContext) -> dict:
    """
    Convert UserContext to threads context.
    
    This function belongs to the Threads domain and creates
    a context dict with threads-specific fields.
    
    Args:
        user_context: Generic user context from JWT token
        
    Returns:
        Dict with threads context fields
    """
    return {
        "user_id": user_context.user_id,
        "locale": user_context.locale,
        "tier": user_context.tier,
        "tone": user_context.tone
    }
