"""Dynamic tone validation utilities."""

from typing import Any

from ..domain.catalogs.service import CatalogsService
from ..db.uow import async_uow_factory
from .errors import ValidationError


async def validate_tone_dynamic(
    tone: str, 
    language: str = "pt-BR",
    session_factory: Any = None
) -> str:
    """Dynamic tone validation using database."""
    if not session_factory:
        from ..db.engine import get_async_session_factory
        session_factory = get_async_session_factory()
    
    catalogs_service = CatalogsService(session_factory)
    
    try:
        is_valid = await catalogs_service.validate_tone(tone, language)
        
        if not is_valid:
            # Get available tones for error message
            valid_tones = await catalogs_service.get_tones(language)
            valid_keys = [t.key for t in valid_tones]
            raise ValidationError(f"Tone must be one of: {valid_keys}")
        
        return tone
    except ValidationError:
        raise
    except Exception:
        # Fallback to hardcoded validation if service fails
        common_tones = {"friendly", "witty", "empathetic", "professional"}
        if tone not in common_tones:
            raise ValidationError(f"Tone must be one of: {list(common_tones)}")
        return tone


def get_valid_tones_sync() -> set[str]:
    """Get valid tones synchronously (fallback for Pydantic validators)."""
    return {"friendly", "witty", "empathetic", "professional"}


def validate_tone_sync(tone: str) -> str:
    """Synchronous tone validation for Pydantic models."""
    valid_tones = get_valid_tones_sync()
    if tone not in valid_tones:
        raise ValueError(f"Tone must be one of: {list(valid_tones)}")
    return tone
