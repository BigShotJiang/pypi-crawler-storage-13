import sys
import importlib
from pathlib import Path
from traceback import print_tb, print_exception
import traceback


def remove_modules(package):
    ''
    for m in sys.modules.copy():
        if package in m:
            del sys.modules[m]


package = sys.argv[1]
failed = 0
n = 0
p = Path(package)
sys.path.insert(0, str(p.parent))
for c in sorted(p.glob('**/*.py')):
    remove_modules(package)
    if '__' not in c.stem and c.stem != 'setup' and c.stem != 'main':
        n += 1
        name = p.name + '.' + c.stem
        try:
            importlib.import_module(name)
            print('✓', name)
        except:
            failed += 1
            e = sys.exception()
            print(failed, name)

            print('Traceback (most recent call last):')
            print_tb(e.__traceback__, file=sys.stdout)
            print(f'{type(e).__name__}: {str(e)}')
            print()
print()
print(failed, 'module(s) failed out of', n)
