Regression
**********


.. toctree::

   diffusion
   dirichlet
