"""tests for topology"""
