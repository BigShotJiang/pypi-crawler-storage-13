"""tests for ranking"""
