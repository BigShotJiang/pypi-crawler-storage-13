"""tests for embedding"""
