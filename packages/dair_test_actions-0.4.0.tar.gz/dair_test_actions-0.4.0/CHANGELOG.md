## v0.4.0 (2025-11-18)

### Feat

- **actions**: added pre-release-version-check and updated README.md with instructions

### Fix

- **publish-to-pypi**: added PYPI_TOKEN check

## v0.3.0 (2025-11-18)

### Feat

- **build-and-test**: tweaked os runs
- **actions**: added pypi publish (#12)
- **actions**: added sync-to-public.yaml
- **actions**: build-and-test.yaml

### Fix

- **actions**: inherited secrets (#5)
- **build-and-test**: tweaked to hardcode branches and secrets (#6)
- **actions**: inherited secrets
- **tests**: fixed param call

## v0.2.0 (2025-11-18)

### Feat

- **.gitignore**: added pre-commit
- **first-commit**: first commit

### Fix

- **actions**: test build-and-test
- **actions**: fixed reference to config
