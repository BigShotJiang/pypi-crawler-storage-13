"""Service management for ThreatWinds Pentest CLI."""

from .agent_install import (
    download_agent,
    extract_agent,
    setup_python_environment,
    install_systemd_service,
    start_agent_service,
    stop_agent_service,
    remove_agent_service,
    is_service_installed,
    is_service_running,
    get_agent_path,
)

__all__ = [
    "download_agent",
    "extract_agent",
    "setup_python_environment",
    "install_systemd_service",
    "start_agent_service",
    "stop_agent_service",
    "remove_agent_service",
    "is_service_installed",
    "is_service_running",
    "get_agent_path",
]
