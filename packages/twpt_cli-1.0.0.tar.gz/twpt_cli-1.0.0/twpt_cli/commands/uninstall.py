"""Uninstall command for ThreatWinds Pentest CLI."""

import sys
from pathlib import Path

import click
from rich.console import Console

from twpt_cli.docker import (
    stop_container,
    remove_container,
    is_container_running,
    container_exists,
)
from twpt_cli.config import DEFAULT_PT_PATH, clear_credentials

console = Console()


@click.command()
@click.option(
    '--remove-data',
    is_flag=True,
    help='Also remove configuration and data files'
)
@click.option(
    '--yes',
    is_flag=True,
    help='Skip confirmation prompt'
)
def uninstall(remove_data: bool, yes: bool):
    """Uninstall the ThreatWinds pentest toolkit.

    This command will:
    1. Stop the running container
    2. Remove the container
    3. Optionally remove configuration and data files

    Note: Docker image will not be removed. Use 'docker image rm' manually if needed.
    """
    console.print("\n╔══════════════════════════════════════════════╗", style="cyan")
    console.print("║     ThreatWinds Pentest Toolkit Uninstall     ║", style="cyan")
    console.print("╚══════════════════════════════════════════════╝\n", style="cyan")

    # Confirm uninstall
    if not yes:
        console.print("⚠ This will remove the pentest container", style="yellow bold")
        if remove_data:
            console.print("⚠ This will also remove all configuration and data files", style="yellow bold")

        response = console.input("\nDo you want to continue? [y/N]: ")
        if response.lower() != 'y':
            console.print("Uninstall cancelled", style="yellow")
            sys.exit(0)

    # Check if container exists
    if container_exists():
        # Step 1: Stop container if running
        if is_container_running():
            console.print("Step 1: Stopping container...", style="blue")
            if not stop_container():
                console.print("⚠ Failed to stop container gracefully", style="yellow")

        # Step 2: Remove container
        console.print("\nStep 2: Removing container...", style="blue")
        if not remove_container():
            console.print("⚠ Failed to remove container", style="yellow")
    else:
        console.print("No container found to remove", style="yellow")

    # Step 3: Remove data if requested
    if remove_data:
        console.print("\nStep 3: Removing configuration and data...", style="blue")
        remove_configuration_data()

    # Success message
    console.print("\n" + "="*50, style="green")
    console.print("✓ Uninstall complete!", style="green bold")
    console.print("="*50 + "\n", style="green")

    console.print("The following items have been removed:", style="cyan")
    console.print("  • Pentest container", style="white")
    if remove_data:
        console.print("  • Configuration files", style="white")
        console.print("  • Data directory", style="white")

    console.print("\nThe following items were NOT removed:", style="yellow")
    console.print("  • Docker image (ghcr.io/threatwinds/twpt-agent)", style="white")
    console.print("  • twpt-cli command (use pip uninstall twpt-cli)", style="white")

    console.print("\nTo remove the Docker image manually:", style="dim")
    console.print("  docker image rm ghcr.io/threatwinds/twpt-agent:latest", style="white")

    console.print("\nTo remove the CLI tool:", style="dim")
    console.print("  pip uninstall twpt-cli", style="white")


def remove_configuration_data():
    """Remove configuration and data files."""
    try:
        # Clear credentials
        clear_credentials()
        console.print("  ✓ Credentials removed", style="green")

        # Remove data directory
        data_dir = DEFAULT_PT_PATH / "data"
        if data_dir.exists():
            import shutil
            shutil.rmtree(data_dir)
            console.print("  ✓ Data directory removed", style="green")

        # Remove config directory if empty
        if DEFAULT_PT_PATH.exists():
            # Check if directory is empty
            if not any(DEFAULT_PT_PATH.iterdir()):
                DEFAULT_PT_PATH.rmdir()
                console.print("  ✓ Configuration directory removed", style="green")
            else:
                console.print(f"  ⚠ Configuration directory not empty: {DEFAULT_PT_PATH}", style="yellow")

    except Exception as e:
        console.print(f"  ⚠ Error removing data: {e}", style="yellow")