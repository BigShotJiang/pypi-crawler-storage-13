# CXR-K-Sim1 Model

Simulation-focused CXR model with Monte Carlo financial forecasting and risk analysis.

## Installation

```bash
pip install cxr-k-sim1
```

## Quick Start

```python
from cxr_k_sim1 import analyze

claim = {
    "claimId": "CLM-001",
    "patientId": "PAT-001",
    "providerId": "PROV-001",
    "serviceDate": "2024-01-15",
    "procedureCode": "99213",
    "billedAmount": 1000.0,
    "metadata": {"reviewThreshold": 0.85}
}

result = analyze(claim, tenant_id="tenant-123")
print(result["financialImpact"]["monteCarlo"])
```

## Features

- 7-plane fusion
- Monte Carlo simulation (mean, percentiles, confidence interval)
- Denial scenario simulation
- Risk distribution analysis

## Usage

```python
from cxr_k_sim1 import get_model

model = get_model()
result = model.analyze(claim, tenant_id)
```

