"""
CXR-K-Sim1 Model Package

Simulation model with Monte Carlo financial forecasting.
"""

from kernel_service import get_registry

__version__ = "0.1.0"


def get_model():
    """Get the CXR-K-Sim1 model instance"""
    registry = get_registry()
    return registry.get_model("cxr-k-sim1")


def analyze(claim: dict, tenant_id: str) -> dict:
    """
    Analyze a claim using CXR-K-Sim1.

    Args:
        claim: Claim payload dictionary
        tenant_id: Tenant identifier

    Returns:
        Analysis result dictionary
    """
    model = get_model()
    return model.analyze(claim, tenant_id)


__all__ = ["get_model", "analyze", "__version__"]

