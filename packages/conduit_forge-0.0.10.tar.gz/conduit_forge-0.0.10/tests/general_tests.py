import time as time
from functools import wraps
from colorama import Fore, Back, Style

from components import Component, Port, Pipe, Elbow, T_connector
from current import Current
import mosaic as mosaic
import solvers as my_solvers

import thermo as thermo
import sympy as sy
import icecream as ice


"""
This file will be used to test if the other functions, classes and class methods are working as intended

The first ideia was to make every test in the format of a function. Than, i would write a script to run this function
in the end of this file, or in the terminal, if i learn to run a function that is inside a python file (in the terminal).
this script would call the function and display the results that i wish to see.
"""

"""----- This Area is reserved for Decorators -----"""


def timer(func):
    """Print the runtime of the decorated function"""

    @wraps(func)
    def wrapper_timer(*args, **kwargs):
        start_time = time.perf_counter()
        value = func(*args, **kwargs)
        end_time = time.perf_counter()
        run_time = end_time - start_time

        if run_time <= 1.5:
            back_color = Back.GREEN
        elif (run_time >= 1.5) and (run_time <= 2.5):
            back_color = Back.YELLOW
        elif (run_time >= 2.5) and (run_time <= 3.5):
            back_color = Back.RED
        elif run_time >= 2.5:
            back_color = Back.LIGHTBLACK_EX
        print(
            f"{Fore.BLACK + back_color}\nFinished {func.__name__}() in {run_time:.4f} seconds{Style.RESET_ALL}"
        )
        # print(Style.RESET_ALL)
        return value

    return wrapper_timer


"""----- This Area is reserved for Tests -----"""


def mosaic_joint():
    # Test to see if the joint method from mosaic is adding new joints to the joints list
    test_mosaic_1 = mosaic.Mosaic(joints_list=[])
    port_1 = Port(geometry="cylinder", characteristic_length=32, location=None)
    port_2 = Port(geometry="cylinder", characteristic_length=32, location=None)
    # test_mosaic_1.joint(port_1, port_2)
    return test_mosaic_1.joints_list

def Pipe_ports():
    # The dimensions are in centimeters
    test_pipe = Pipe(internal_diam=3, length=200)
    print(
        f"The input port diameter is {test_pipe.component_ports[0].characteristic_legth}"
    )
    # ice.ic(test_pipe.inputs_quantity)

def Mosaic_joint_list():
    # Test to check if the joints are being created as intended
    p_1 = Pipe(internal_diam=1, length=2)
    p_2 = Pipe(internal_diam=3, length=4)

    # print(f'plugged inputs in p_2> {p_2.plugged_inputs}')
    m_1 = p_1 + p_2

    print(
        f"\nlista de juntas do mosaico m_1: {mosaic.Mosaic.mosaic_objects[0].joints_list}"
    )
    print(
        f"\np_1.plugged_outputs diameter: {p_1.plugged_outputs[0].characteristic_legth}"
    )
    # Mosaic.mosaic_objects_reader()
    # It seems that the m_1 is being correctly identified as a mosaic object

    # print(f'\nthis is the list of joint in the mosaic created for this test: {m_1.joints_list}')

    """
    I want the behaviour of the  __add__ of the components and currents to be like this:

    m_1 = p_1 + p_2

    If the user states that:

    p_2 + p_3

    I would like to make the software so that the p_3 is automatically added to the m_1 mosaic, without the need to
    declare the alteration of the m_1 mosaic explicitly, like this:

    m_1 = p_2 + p_3

    In theory, i wolud like that the user does not even need to declare that the addition p_1 + p_2 = m_1

    
    """

def Pipe_id():
    """
    Test to see if the ID created in component is being inherited correctly in
    the child classes, like Pipe and etc.
    """
    pipe = Pipe(internal_diam=2, length=4)
    print(f"\n o ID do tubo deste teste é: {pipe.id}")

def find_mosaic_from_component_class():
    """
    this function will be used to check if the find_mosaic method declared inside the Component Class
    is working as intended
    """
    pipe_1 = Pipe(1, 2)
    pipe_2 = Pipe(3, 4)
    pipe_3 = Pipe(5, 6)
    pipe_4 = Pipe(7, 8)

    print(f"\n")

    ice.ic(Component.component_objects)

    print(f"\nThose are the ID's of the ports of all the pipes")
    ice.ic(pipe_1.all_component_ports[0].id)
    ice.ic(pipe_1.all_component_ports[1].id)
    print(f"\n")
    ice.ic(pipe_2.all_component_ports[0].id)
    ice.ic(pipe_2.all_component_ports[1].id)
    print(f"\n")
    ice.ic(pipe_3.all_component_ports[0].id)
    ice.ic(pipe_3.all_component_ports[1].id)
    print(f"\n")
    ice.ic(pipe_4.all_component_ports[0].id)
    ice.ic(pipe_4.all_component_ports[1].id)
    print(f"\n")
    print(f"\nThose are the ID's stored inside the joints created inside each mosaic")

    m_1 = pipe_1 + pipe_2

    print(f"\nTHis is the ID of the m_1 mosaic")
    ice.ic(mosaic.Mosaic.mosaic_objects[0].id)
    print(f"\nThese are the ID's inside the m_1 joints_list:")
    ice.ic(mosaic.Mosaic.mosaic_objects[0].joints_list[0][0].id)
    ice.ic(mosaic.Mosaic.mosaic_objects[0].joints_list[0][1].id)

    ice.ic(mosaic.Mosaic.mosaic_objects)

    m_2 = pipe_3 + pipe_4

    # print(f'\nTHis is the ID of the m_2 mosaic')
    # ice.ic(Mosaic.mosaic_objects[1].id)
    # print(f'\nThese are the ID\'s inside the m_1 joints_list:')
    # ice.ic(Mosaic.mosaic_objects[1].joints_list[0][0].id)
    # ice.ic(Mosaic.mosaic_objects[1].joints_list[0][1].id)

    # THis method is being called from the pipe_1 object because i have to declare this function outside the component class when i have time

    # return pipe_1.find_mosaic()

    # print(f'\nEssa é a lista ed todas as portas do pipe_1: {pipe_1.all_component_ports}')
    # print(f'\nEsse é o diametro da primeira porta na lista de portas do Pipe_1: {pipe_1.all_component_ports[0].characteristic_legth}')

def find_location_of_port_from_port_class():

    pipe_1 = Pipe(1, 2)
    pipe_2 = Pipe(3, 4)
    # pipe_3 = Pipe(5,6)
    # pipe_4 = Pipe(7,8)

    m_1 = pipe_1 + pipe_2
    # m_2 = pipe_3 + pipe_4

    ice.ic(pipe_1.all_component_ports[0].id)
    ice.ic(pipe_1.all_component_ports[1].id)
    ice.ic(pipe_2.all_component_ports[0].id)
    ice.ic(pipe_2.all_component_ports[1].id)

    x = 0
    y = 0
    z = 0
    # Access the list of mosaic objects
    for obj in mosaic.Mosaic.mosaic_objects:
        # access the joints_list of one of the mosaics
        for obj in mosaic.Mosaic.mosaic_objects[x].joints_list:
            # access one element of the joints_list of the mosaic
            for obj in mosaic.Mosaic.mosaic_objects[x].joints_list[y]:
                print(f"\n")
                ice.ic(mosaic.Mosaic.mosaic_objects[x].joints_list[y])
                ice.ic(y)
            y += 1
        x += 1

    print(f"\nTHis is the ID of the m_1 mosaic")
    ice.ic(mosaic.Mosaic.mosaic_objects[0].id)

    # print(f'\nThese are the ID\'s inside the m_1 joints_list:')
    # ice.ic(mosaic.Mosaic.mosaic_objects[0].joints_list[0][0])
    # ice.ic(mosaic.Mosaic.mosaic_objects[0].joints_list[0][1])

    # ice.ic(mosaic.Mosaic.mosaic_objects[0].joints_list[0][0][1])
    # for i in components.Port.port_objects:'

    # print(m_1.id)

    print(
        f"\nall(list(map(Port.is_generic_port,pipe_2.all_component_ports))) = {all(list(map(Port.is_generic_port,pipe_2.all_component_ports)))}"
    )
    ice.ic(all(list(map(Port.is_generic_port, pipe_2.all_component_ports))))

    print(f"\n{list(map(Port.is_generic_port,pipe_2.all_component_ports))}")
    ice.ic(list(map(Port.is_generic_port, pipe_2.all_component_ports)))

    # return pipe_1.all_component_ports[0].find_location_of_port

def map_test():
    import components

    pipe_1 = Pipe(1, 2)
    pipe_2 = Pipe(3, 4)
    pipe_3 = Pipe(5, 6)
    pipe_4 = Pipe(7, 8)

    m_1 = pipe_1 + pipe_2
    m_2 = pipe_3 + pipe_4

    return list(map(components.Port.is_generic_port, pipe_1.all_component_ports))

# print(f'\n{map_test()}\n')

# if [obj == True for obj in map_test()]:
#     print()

"""
I have to create a test to check if adding two component objects uses both __add__ and __radd__.

I think that the desired behaviour is for the addition to only use the __add__, to create only one joint in the mosaic that the two components belong.

The problem is that i don't know if using the addition to the first element would call the reflected addition to the second element, as it is being added
to another element from the left side
"""

def find_location_of_component_from_comp_class():

    pipe_1 = Pipe(1, 2)
    pipe_2 = Pipe(3, 4)
    pipe_3 = Pipe(5, 6)
    pipe_4 = Pipe(7, 8)

    print(f"\n{pipe_2.plugged_inputs = }")
    print(f"\n{pipe_2.plugged_inputs[0].id = }")
    print(f"\n{pipe_2.plugged_inputs[0].characteristic_legth = }")
    print(f"\n{pipe_2.plugged_inputs[0].geometry = }")
    print(f"\n{pipe_2.all_component_ports = }")

    print(f"\n{pipe_3.component_input_ports[0].id = }")
    print(f"\n{pipe_3.component_input_ports[0].characteristic_legth = }")
    print(f"\n{pipe_3.component_input_ports[0].geometry = }")
    print(f"\n{pipe_3.all_component_ports = }")
    print(f"\n{pipe_3.plugged_inputs = }")

    print(f"\n{pipe_4.component_input_ports = }")
    print(f"\n{pipe_4.component_input_ports[0].id = }")
    print(f"\n{pipe_4.component_input_ports[0].characteristic_legth = }")
    print(f"\n{pipe_4.component_input_ports[0].geometry = }")
    print(f"\n{pipe_4.all_component_ports = }")

    m_1 = pipe_1 + pipe_2
    m_2 = pipe_3 + pipe_4

    print(f"\n{pipe_1.location = }")
    print(f"\n{pipe_2.location = }")
    print(f"\n{pipe_3.location = }")
    print(f"\n{pipe_4.location = }")

    # m_3 = pipe_2 + pipe_3

    print(f"\n\n{pipe_2.location = }")
    print(f"\n{pipe_3.location = }\n\n")
    print([m.id for m in mosaic.Mosaic.mosaic_objects])

    if isinstance(m_1, mosaic.Mosaic) == True:
        print(f"\n{m_1.id = }")

    if isinstance(m_2, mosaic.Mosaic) == True:
        print(f"\n{m_2.id = }")

    # if isinstance(m_3, mosaic.Mosaic) == True:
    #     print(f'\n{m_3.id = }')

    return pipe_1.location

# find_location_of_component_from_comp_class()

# Solvers testing
# this part should make the sympy calculate the absolute viscosity using only the reynolds equation
# a = my_solvers.reynolds(r_n=1, rho = 2, char_length=3, vel = 4)

# print(f'\n{type(a)}')

@timer
def comp_add_and_radd_with_current() -> Port | None:

    pipe_1 = Pipe(1, 2)
    pipe_2 = Pipe(3, 4)
    pure_water = thermo.Chemical("water", T=303)  # temperature in Kelvin
    current_1 = Current(composition=pure_water, mass_flow=3)

    current_2 = Current(composition=pure_water, mass_flow=4)
    # I need to test if the code accesses the __add__ from component even if the component on the right side of the addition
    m_1: mosaic.Mosaic = current_1 + pipe_1

    print(f"\n\n{pipe_1.id = }")
    print(f"\n{pipe_1.all_component_ports[0].id = }")
    print(f"\n{pipe_1.all_component_ports[1].id = }")
    print(f"\n{pipe_1.component_input_ports[0].id = }")
    print(f"\n{pipe_1.component_output_ports[0].id = }")
    print(f"\n{pipe_1.plugged_outputs[0].id = }")
    print(f"\n{current_1.id = }")
    print(f"\n{current_1.location = }")

    # m_1 is returning a NoneType Object, even after this code worked some days ago
    print(f"\n{m_1.id = }")

    # test if the addition of two currents raises an error

    # test if the addition of a current already plugged in a component raises an error
    # The problem with the creation of m_2 is that it is not returnning a mosaic, but a NoneType object
    # m_2 = current_2 + pipe_1
    # print(f'\n\n{m_2.id = }')

    m_3: mosaic.Mosaic = current_2 + pipe_2
    print(f"\n{pipe_2.id = }")
    print(f"\n{pipe_2.location = }")
    print(f"\n{pipe_2.all_component_ports[0].id = }")
    print(f"\n{pipe_2.all_component_ports[1].id = }")
    print(f"\n{pipe_2.component_input_ports[0].id = }")
    print(f"\n{pipe_2.plugged_outputs[0].id = }")
    print(f"\n{pipe_2.plugged_inputs[0] = }")
    print(f"\n{current_2.id = }")
    print(f"\n{current_2.location = }")
    print(f"\n{m_3.id = }")
    print(f"\n{m_3.joints_list = }")

    # test if the current supports the walrus operator (:=) to create a composition in the declaration of the current
    # without having to declare the composition individualy, before the declaration of the current
    # current_2 = Current(composition:= thermo.Chemical('water', T = 313)) # temperature in Kelvin

    """
    for m in mosaic.Mosaic.mosaic_objects:
        print(f'\n{m.joints_list = }')
        for j in m.joints_list:
            if len(j)>1:
                for p in Port.port_objects:
                    if j[1][1] == p.id or j[0] == p.id:
                        return p.id, p.characteristic_length, p.geometry, p.location
    """

@timer
def current_propperties_test():
    """
    This test should be used to test if the properties from the current (like temperature, pressure, mass_flow,
    volumetric flow, density, and etc) are being returned as expected.

    The propperties testes here will be used to structurate the mosaic methods which will iterate on the components and
    currents which they contain.
    """

    pure_water = thermo.Chemical("water", T=303)  # temperature in Kelvin
    current_1 = Current(composition=pure_water, mass_flow=2, P=200_000)

    # test ot return a current's temperature and pressure for composition = thermo.Chemical
    current_temp = current_1.temperature
    print(f"\n{current_1.temperature = }")
    print(f"\n{current_1.pressure = }")

    # test to rerturn a current's temperature and pressure for composition = thermo.Mixture
    mix = thermo.Mixture(["toluene", "etanol"], ws=[0.6, 0.4], P=300_000)
    mixed_current = Current(composition=mix, mass_flow=3)
    print(f"\n{mixed_current.temperature = }")
    print(f"\n{mixed_current.pressure = }")

    # test to return a current's viscosity (which should come from the composition, declared as a chemical or as a mixture)
    print(f"\n{current_1.ab_viscosity() = }")

    # this is the test to see if the abviscosity where created inside of the class
    print(f"\n{current_1._ab_viscosity = }")

    # i have to create a method to see if the voscosity already exists, and to reacalculate the v iscosity if needed

    r"""
    For the composition created as a chemical, with the chemical being 'water', and the temperature being 303K, the viscosity
    of the water at this temperature was right, it was 0.0007999 Pa/s using the thermo library, and to confirm this i used the
    site: <https://www.omnicalculator.com/pt/fisica/calculadora-viscosidade-da-agua>. which gave the same result, but in
    mPa/s.
    """
    # test if the current is able to get the temperature and pressure from the composition, if those values are not given
    # when the current is created

    # test if i can get the density from the current
    print(f"\n{current_1.density() = }")

    # this is the test to see if the density where created inside of the class
    print(f"\n{current_1._density = }")

    time.sleep(3)

def mass_conservation_from_component():




    pure_water = thermo.Chemical("water", T=303)  # temperature in Kelvin
    current_1 = Current(composition=pure_water, mass_flow=2, P=200_000)

    print(f'\n{current_1.id = }')

    p1 = Pipe(internal_diam = 3, length = 4)

    """
    Um dos problemas que eu estou tendo é que quando eu printo a lista de portas de p1, essa lista contém quatro portas.
    
    Além disso eu percebi que algumas portas que são processadas no metodo de conservação de massa do Component tem
    geometria None. Isso pode indicar que o componente ainda está com portas genéricas na sua lista de portas após a sua
    criação.

    Uma forma de resolver isso poderia ser alterar a classe Pipe e todas as demais que herdam de Component pra tirar as
    portas genéricas de dentro da lista self.component_ports logo quando esses objetos são criados
    """

    print(f'{p1.component_ports = }')
    print(f'{p1.component_ports[0].id = }')
    print(f'{p1.component_ports[1].id = }')

    #print(f'\n{p1.location = }')
    #print(f'\n{current_1.location = }\n')

    #for port in p1.component_ports:
        #print(f'\n\n\n* ---->{port.local_current = }\n')

    m1 = p1 + current_1

    #print(f'\n{p1.location = }')
    #print(f'\n{current_1.location = }\n')

    """for port in p1.component_ports:
        if port.local_current != None:
            print(f'\n\n\n* {port.local_current.id = }\n')
            print(f'{port.id = }')
        
        elif port.local_current != None:
            print(f'\n\n\n* {port.local_current = }\n')
            print(f'{port.id = }')
        else:
            print(f'\nsomething went wrong')
            print(f'\n\n\n* {port.local_current = }\n')
            print(f'{port.id = }')


            #raise ValueError(f'something went wrong')"""


    """
    This part indicates that both the currents from p1 are the same.

    I guess that this show why both of the currents from both p1 ports where showing the same pressure when i printed them

    I guess this problem is being caused by something inside the __add__ method from the component

    The problem should be with the part that sets the local curret of a port to be equal to the current plugged to said
    component. there should be a problem with some thing that runns for both ports, instead of just one of them.

    If this is the case, i still have to detect where it happens and how to fix it.

    I guess the error is in this part because the self.outlet_list from the mass conservation method is empty.

    This means that the for loop on that part is never starting, and the code just passes by it.
    """


    p1.mass_conservation()

    print(f'\n\n\n{p1.component_ports[0].local_current.velocity = }')
    print(f'\n{p1.component_ports[0].local_current.composition = }')
    print(f'\n{p1.component_ports[0].local_current.mass_flow = }')
    print(f'\n{p1.component_ports[0].local_current.density() = }')
    print(f'\n{p1.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{p1.component_ports[0].local_current.volume_flow = }\n\n')
    
    


    print(f'\n{p1.component_ports[1].local_current.velocity = }')
    print(f'\n{p1.component_ports[1].local_current.composition = }')
    print(f'\n{p1.component_ports[1].local_current.mass_flow = }')
    print(f'\n{p1.component_ports[1].local_current.density() = }')
    print(f'\n{p1.component_ports[1].local_current.pressure = } Pa')
    print(f'\n{p1.component_ports[1].local_current.volume_flow = }')
    
import components
def mass_conservation_custom_component_Y():
    # This test should be made after the mass conservation from component test
    #this test should be used to see if the mass conservation is working propperlly for all types of components

    #The first part is to test if the mass concervation is working with just one inlet and two outlets

    pure_water = thermo.Chemical("water", T = 303)  # temperature in Kelvin
    current_1 = Current(composition = pure_water, mass_flow = 3, P = 300_000)

    
    Y_connector = components.Y_connector(internal_diam=[3, 1, 2])

    for port in Y_connector.component_ports:
        print(f'\n{port.id = }')

    m_1 = Y_connector + current_1

    print(f'\n{m_1.joints_list = }')

    Y_connector.mass_conservation()

    print(f'\n\n\n{Y_connector.component_ports[0].local_current.velocity = }')
    print(f'\n{Y_connector.component_ports[0].local_current.composition = }')
    print(f'\n{Y_connector.component_ports[0].local_current.mass_flow = }')
    print(f'\n{Y_connector.component_ports[0].local_current.density() = }')
    print(f'\n{Y_connector.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{Y_connector.component_ports[0].local_current.volume_flow = }\n\n')
    
    
    print(f'\n{Y_connector.component_ports[1].local_current.velocity = }')
    print(f'\n{Y_connector.component_ports[1].local_current.composition = }')
    print(f'\n{Y_connector.component_ports[1].local_current.mass_flow = }')
    print(f'\n{Y_connector.component_ports[1].local_current.density() = }')
    print(f'\n{Y_connector.component_ports[1].local_current.pressure = } Pa')
    print(f'\n{Y_connector.component_ports[1].local_current.volume_flow = }\n\n')


    # print(f'{Y_connector.component_ports[2] = }')
    # print(f'{Y_connector.component_ports[2].id = }')
    # print(f'{Y_connector.component_ports[2].local_current = }')
    
    # The thrid port of the Y Connector says that the local current is None, even after the mass conservation of the
    #Component

    print(f'\n{Y_connector.component_ports[2].local_current.velocity = }')
    print(f'\n{Y_connector.component_ports[2].local_current.composition = }')
    print(f'\n{Y_connector.component_ports[2].local_current.mass_flow = }')
    print(f'\n{Y_connector.component_ports[2].local_current.density() = }')
    print(f'\n{Y_connector.component_ports[2].local_current.pressure = } Pa')
    print(f'\n{Y_connector.component_ports[2].local_current.volume_flow = }')

def mass_conservation_custom_component_T():
    #The second part is to test if the mass concervation is working with two inlets and one outlet

    pure_water = thermo.Chemical("water", T = 303)  # temperature in Kelvin
    current_2 = Current(composition = pure_water, mass_flow = 3, P = 300_000)
    current_3 = Current(composition = pure_water, mass_flow = 3, P = 300_000)

    print(f'\n{current_2.id = }')
    print(f'\n{current_3.id = }')

    T_connector = components.Y_connector(internal_diam=[3, 1, 2])

    print(f'\n{T_connector.id = }')

    print(f'\n{mosaic.Mosaic.mosaic_objects= }')

    print(f'\n{T_connector.i = }')

    m2 = T_connector + current_2

    print(f'\n{mosaic.Mosaic.mosaic_objects= }')
    print(f'\n{T_connector.i = }')

    print(f'\n\n\n{T_connector.component_ports[0].local_current.velocity = }')
    print(f'\n{T_connector.component_ports[0].local_current.id = }')
    print(f'\n{T_connector.component_ports[0].local_current.composition = }')
    print(f'\n{T_connector.component_ports[0].local_current.mass_flow = }')
    print(f'\n{T_connector.component_ports[0].local_current.density() = }')
    print(f'\n{T_connector.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{T_connector.component_ports[0].local_current.volume_flow = }\n\n')
    
    
    #print(f'\n{T_connector.component_ports[1].local_current.velocity = }')
    #print(f'\n{T_connector.component_ports[1].local_current.id = }')
    #print(f'\n{T_connector.component_ports[1].local_current.composition = }')
    #print(f'\n{T_connector.component_ports[1].local_current.mass_flow = }')
    #print(f'\n{T_connector.component_ports[1].local_current.density() = }')
    #print(f'\n{T_connector.component_ports[1].local_current.pressure = } Pa')
    #print(f'\n{T_connector.component_ports[1].local_current.volume_flow = }\n\n')

    # print(f'\n{T_connector.component_ports[2].local_current.velocity = }')
    # print(f'\n{T_connector.component_ports[2].local_current.id = }')
    # print(f'\n{T_connector.component_ports[2].local_current.composition = }')
    # print(f'\n{T_connector.component_ports[2].local_current.mass_flow = }')
    # print(f'\n{T_connector.component_ports[2].local_current.density() = }')
    # print(f'\n{T_connector.component_ports[2].local_current.pressure = } Pa')
    # print(f'\n{T_connector.component_ports[2].local_current.volume_flow = }')
    

    m2 = T_connector + current_3

    print(f'\n{mosaic.Mosaic.mosaic_objects= }')
    print(f'\n{T_connector.i = }')

    print(f'{m2.joints_list = }')


    print(f'\n\n\n{T_connector.component_ports[0].local_current.velocity = }')
    print(f'\n{T_connector.component_ports[0].local_current.id = }')
    print(f'\n{T_connector.component_ports[0].local_current.composition = }')
    print(f'\n{T_connector.component_ports[0].local_current.mass_flow = }')
    print(f'\n{T_connector.component_ports[0].local_current.density() = }')
    print(f'\n{T_connector.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{T_connector.component_ports[0].local_current.volume_flow = }\n\n')
    
    
    print(f'\n{T_connector.component_ports[1].local_current.velocity = }')
    print(f'\n{T_connector.component_ports[1].local_current.id = }')
    print(f'\n{T_connector.component_ports[1].local_current.composition = }')
    print(f'\n{T_connector.component_ports[1].local_current.mass_flow = }')
    print(f'\n{T_connector.component_ports[1].local_current.density() = }')
    print(f'\n{T_connector.component_ports[1].local_current.pressure = } Pa')
    print(f'\n{T_connector.component_ports[1].local_current.volume_flow = }\n\n')

    T_connector.mass_conservation()

    print(f'\n\n\n{T_connector.component_ports[0].local_current.velocity = }')
    print(f'\n{T_connector.component_ports[0].local_current.id = }')
    print(f'\n{T_connector.component_ports[0].local_current.composition = }')
    print(f'\n{T_connector.component_ports[0].local_current.mass_flow = }')
    print(f'\n{T_connector.component_ports[0].local_current.density() = }')
    print(f'\n{T_connector.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{T_connector.component_ports[0].local_current.volume_flow = }\n\n')
    
    
    print(f'\n{T_connector.component_ports[1].local_current.velocity = }')
    print(f'\n{T_connector.component_ports[1].local_current.id = }')
    print(f'\n{T_connector.component_ports[1].local_current.composition = }')
    print(f'\n{T_connector.component_ports[1].local_current.mass_flow = }')
    print(f'\n{T_connector.component_ports[1].local_current.density() = }')
    print(f'\n{T_connector.component_ports[1].local_current.pressure = } Pa')
    print(f'\n{T_connector.component_ports[1].local_current.volume_flow = }\n\n')

    print(f'\n{T_connector.component_ports[2].local_current.velocity = }')
    print(f'\n{T_connector.component_ports[2].local_current.composition = }')
    print(f'\n{T_connector.component_ports[2].local_current.mass_flow = }')
    print(f'\n{T_connector.component_ports[2].local_current.density() = }')
    print(f'\n{T_connector.component_ports[2].local_current.pressure = } Pa')
    print(f'\n{T_connector.component_ports[2].local_current.volume_flow = }')


    # print(f'{Y_connector.component_ports[2] = }')
    # print(f'{Y_connector.component_ports[2].id = }')
    # print(f'{Y_connector.component_ports[2].local_current = }')
    
    # The thrid port of the Y Connector says that the local current is None, even after the mass conservation of the
    #Component
   
def mass_conservation_custom_component_multiple_IO_1():
    #The third part is to test if the mass concervation will work with a component with 4 ports, with one inlet and
    #multiple outlets

    pure_water = thermo.Chemical("water", T = 303)  # temperature in Kelvin
    current_a = Current(composition = pure_water, mass_flow = 3, P = 300_000)
    current_b = Current(composition = pure_water, mass_flow = 3, P = 300_000)

    print(f'\n{current_a.id = }')
    print(f'\n{current_b.id = }')

    X_connector = components.X_connector(internal_diam=[3, 1, 2, 4])

    print(f'\n{X_connector.id = }')

    m1 = X_connector + current_a
    m1 = X_connector + current_b
    

    X_connector.mass_conservation()

    print(f'\n\n\n{X_connector.component_ports[0].local_current.velocity = }')
    print(f'\n{X_connector.component_ports[0].local_current.id = }')
    print(f'\n{X_connector.component_ports[0].local_current.composition = }')
    print(f'\n{X_connector.component_ports[0].local_current.mass_flow = }')
    print(f'\n{X_connector.component_ports[0].local_current.density() = }')
    print(f'\n{X_connector.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{X_connector.component_ports[0].local_current.volume_flow = }\n\n')
    
    print(f'\n{X_connector.component_ports[1].local_current.velocity = }')
    print(f'\n{X_connector.component_ports[1].local_current.id = }')
    print(f'\n{X_connector.component_ports[1].local_current.composition = }')
    print(f'\n{X_connector.component_ports[1].local_current.mass_flow = }')
    print(f'\n{X_connector.component_ports[1].local_current.density() = }')
    print(f'\n{X_connector.component_ports[1].local_current.pressure = } Pa')
    print(f'\n{X_connector.component_ports[1].local_current.volume_flow = }\n\n')

    print(f'\n{X_connector.component_ports[2].local_current.velocity = }')
    print(f'\n{X_connector.component_ports[2].local_current.composition = }')
    print(f'\n{X_connector.component_ports[2].local_current.mass_flow = }')
    print(f'\n{X_connector.component_ports[2].local_current.density() = }')
    print(f'\n{X_connector.component_ports[2].local_current.pressure = } Pa')
    print(f'\n{X_connector.component_ports[2].local_current.volume_flow = }\n\n')

    print(f'\n{X_connector.component_ports[3].local_current.velocity = }')
    print(f'\n{X_connector.component_ports[3].local_current.composition = }')
    print(f'\n{X_connector.component_ports[3].local_current.mass_flow = }')
    print(f'\n{X_connector.component_ports[3].local_current.density() = }')
    print(f'\n{X_connector.component_ports[3].local_current.pressure = } Pa')
    print(f'\n{X_connector.component_ports[3].local_current.volume_flow = }')

def mass_conservation_custom_component_multiple_IO_2():

    #The fith part is to test if the mass concervation will work with a component with 4 ports, with one outlet and
    #multiple inlets
    ...

def mass_conservation_custom_component_multiple_IO_3():

    #The sixth The fith part is to test if the mass concervation will work with a component with 4 ports, with multiple
    #inlets and multiple outlets
    ...

def mass_conservation_custom_component_multiple_IO_4():

    #The seventh part is to test if the mass concervation will work with a componente with 5 or six ports component,
    #with multiple inlets and multiple outlets 
    ...

def mass_conservation_from_mosaic():

    #This test should have a simple mosaic first, and then the other tests will have more complex ones
    pure_water = thermo.Chemical('water', T = 303)  # temperature in Kelvin
    current_a = Current(composition = pure_water, mass_flow = 3, P = 300_000)
    

    print(f'\n{current_a.id = }')
    print(f'\n{current_a.location = }')
    

    p1 = components.Pipe(internal_diam=0.03, length = 3)


    print(f'\n{p1.id = }')

    for port in p1.component_ports:
        print(f'{port.id = }')


    m1 = p1 + current_a

    print(f'\n{m1.id = }')
    print(f'\n{current_a.location = }')

    m1.mass_conservation()

    print(f'\n\n\n{p1.component_ports[0].local_current.velocity = }')
    print(f'\n{p1.component_ports[0].local_current.composition = }')
    print(f'\n{p1.component_ports[0].local_current.mass_flow = }')
    print(f'\n{p1.component_ports[0].local_current.density() = }')
    print(f'\n{p1.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{p1.component_ports[0].local_current.volume_flow = }\n\n')
    
    
    """
    The error with printing the composition of the outlet current is that somehow, the pressure P inside the Chemical
    object from the Thermo llibrary is None.

    When the code tryes to represent the chemical object when i call the print composition command, the Thermo code raises
    an error.

    The problem with this is that this was not supposed to be happening, and it never happened before.

    A way to make this error stop is to give this pressure a value, but his would give me some problems when the energy
    conservation part will be coded.

    By now, i'll just try to do not print the compositio of currents with a composition that has a P = None
    """

    print(f'\n{p1.component_ports[1].local_current.velocity = }')
    #print(f'\n{p1.component_ports[1].local_current.composition = }')
    print(f'\n{p1.component_ports[1].local_current.mass_flow = }')
    print(f'\n{p1.component_ports[1].local_current.density() = }')
    print(f'\n{p1.component_ports[1].local_current.pressure = } Pa')
    print(f'\n{p1.component_ports[1].local_current.volume_flow = }\n\n')

def energy_conservation_from_component():
    #Let's go!
    ...

def position_test_comp_and_mosaic():

    pure_water = thermo.Chemical('water', T = 303)  # temperature in Kelvin
    current_a = Current(composition = pure_water, mass_flow = 3, P = 300_000)
    

    p1 = Pipe(internal_diam = 3, length = 4, orientation = 45)
    p2 = Pipe(internal_diam = 3, length = 7)
    p3 = Pipe(internal_diam = 3, length = 4)
    p4 = Pipe(internal_diam = 3, length = 7)

    print(f'\n\n{p1.id = }')
    print(f'\n -->{p1.component_ports[0].id = }')
    print(f'\n -->{p1.component_ports[1].id = }')

    print(f'\n\n{p2.id = }')
    print(f'\n -->{p2.component_ports[0].id = }')
    print(f'\n -->{p2.component_ports[1].id = }')

    print(f'\n\n{p3.id = }')
    print(f'\n -->{p3.component_ports[0].id = }')
    print(f'\n -->{p3.component_ports[1].id = }')

    print(f'\n\n{p4.id = }\n')
    print(f'\n -->{p4.component_ports[0].id = }')
    print(f'\n -->{p4.component_ports[1].id = }')

    print(f'\n\n{current_a.id = }\n')

    m1 = p1 + current_a

    print(f'\n{p1.i = } {p1.j = } {p1.add_counter = }')     
    print(f'\n{p2.i = } {p2.j = } {p2.add_counter = }')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  

    m1 = p1 + p2
    print(f'\n{p1.i = } {p1.j = } {p1.add_counter = }')     
    print(f'\n{p2.i = } {p2.j = } {p2.add_counter = }')


    m1 = p2 + p3
    print(f'\n{p2.i = } {p2.j = } {p2.add_counter = }')
    print(f'\n{p3.i = } {p3.j = } {p3.add_counter = }')    
    

    m1 = p3 + p4

    print(f'\n{p3.i = } {p3.j = } {p3.add_counter = }')  
    print(f'\n{p4.i = } {p4.j = } {p4.add_counter = }')


    print(f'\n{m1.joints_list = }')

    # p1.position_solver()
    print(f'\n{p1.component_ports[0].spacial_position = }')
    print(f'\n{p1.component_ports[1].spacial_position = }\n')

    # p2.position_solver()
    print(f'\n{p2.component_ports[0].spacial_position = }')
    print(f'\n{p2.component_ports[1].spacial_position = }\n')

    # p3.position_solver()
    print(f'\n{p3.component_ports[0].spacial_position = }')
    print(f'\n{p3.component_ports[1].spacial_position = }\n')

    # p4.position_solver()
    print(f'\n{p4.component_ports[0].spacial_position = }')
    print(f'\n{p4.component_ports[1].spacial_position = }\n')


def position_test_part_two():

    pure_water = thermo.Chemical('water', T = 303)  # temperature in Kelvin
    current_a = Current(composition = pure_water, mass_flow = 3, P = 300_000)
    

    p1 = Pipe(internal_diam = 3, length = 4, orientation = 45)
    p2 = Pipe(internal_diam = 3, length = 7, orientation = 60)
    p3 = Pipe(internal_diam = 3, length = 4, orientation = 0)
    p4 = Pipe(internal_diam = 3, length = 7, orientation = -30)

    print(f'\n\n{p1.id = }')
    print(f'\n -->{p1.component_ports[0].id = }')
    print(f'\n -->{p1.component_ports[1].id = }')

    print(f'\n\n{p2.id = }')
    print(f'\n -->{p2.component_ports[0].id = }')
    print(f'\n -->{p2.component_ports[1].id = }')

    print(f'\n\n{p3.id = }')
    print(f'\n -->{p3.component_ports[0].id = }')
    print(f'\n -->{p3.component_ports[1].id = }')

    print(f'\n\n{p4.id = }\n')
    print(f'\n -->{p4.component_ports[0].id = }')
    print(f'\n -->{p4.component_ports[1].id = }')

    print(f'\n\n{current_a.id = }\n')

    m1 = p1 + current_a

    print(f'\n{p1.i = } {p1.j = } {p1.add_counter = }')     
    print(f'\n{p2.i = } {p2.j = } {p2.add_counter = }')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  

    m1 = p1 + p2
    print(f'\n{p1.i = } {p1.j = } {p1.add_counter = }')     
    print(f'\n{p2.i = } {p2.j = } {p2.add_counter = }')


    m1 = p2 + p3
    print(f'\n{p2.i = } {p2.j = } {p2.add_counter = }')
    print(f'\n{p3.i = } {p3.j = } {p3.add_counter = }')    
    

    m1 = p3 + p4

    print(f'\n{p3.i = } {p3.j = } {p3.add_counter = }')  
    print(f'\n{p4.i = } {p4.j = } {p4.add_counter = }')


    print(f'\n{m1.joints_list = }')

    # p1.position_solver()
    print(f'\n{p1.component_ports[0].spacial_position = }')
    print(f'\n{p1.component_ports[1].spacial_position = }\n')

    # p2.position_solver()
    print(f'\n{p2.component_ports[0].spacial_position = }')
    print(f'\n{p2.component_ports[1].spacial_position = }\n')

    # p3.position_solver()
    print(f'\n{p3.component_ports[0].spacial_position = }')
    print(f'\n{p3.component_ports[1].spacial_position = }\n')

    # p4.position_solver()
    print(f'\n{p4.component_ports[0].spacial_position = }')
    print(f'\n{p4.component_ports[1].spacial_position = }\n')

def position_test_part_three():
    pure_water = thermo.Chemical('water', T = 303)  # temperature in Kelvin
    current_a = Current(composition = pure_water, mass_flow = 3, P = 300_000)
    

    p1 = Pipe(internal_diam = 3, length = 4, orientation = 45)
    p2 = Pipe(internal_diam = 3, length = 7, orientation = 60)
    p3 = Pipe(internal_diam = 3, length = 4, orientation = 0)
    p4 = Pipe(internal_diam = 3, length = 7, orientation = -30)

    e1 = Elbow(internal_diam=3)
    
    e2 = Elbow(internal_diam=3)

    print(f'\n\n{p1.id = }')
    print(f'\n -->{p1.component_ports[0].id = }')
    print(f'\n -->{p1.component_ports[1].id = }')

    print(f'\n\n{p2.id = }')
    print(f'\n -->{p2.component_ports[0].id = }')
    print(f'\n -->{p2.component_ports[1].id = }')

    print(f'\n\n{p3.id = }')
    print(f'\n -->{p3.component_ports[0].id = }')
    print(f'\n -->{p3.component_ports[1].id = }')

    print(f'\n\n{p4.id = }\n')
    print(f'\n -->{p4.component_ports[0].id = }')
    print(f'\n -->{p4.component_ports[1].id = }')

    print(f'\n\n{current_a.id = }\n')

    m1 = p1 + current_a

    print(f'\n{p1.i = } {p1.j = } {p1.add_counter = }')     
    print(f'\n{p2.i = } {p2.j = } {p2.add_counter = }')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  

    m1 = p1 + e1
    print(f'\n{p1.i = } {p1.j = } {p1.add_counter = }')     
    print(f'\n{p2.i = } {p2.j = } {p2.add_counter = }')


    m1 = e1 + p2
    print(f'\n{p2.i = } {p2.j = } {p2.add_counter = }')
    print(f'\n{p3.i = } {p3.j = } {p3.add_counter = }')    
    

    m1 = p2 + e2

    print(f'\n{p3.i = } {p3.j = } {p3.add_counter = }')  
    print(f'\n{p4.i = } {p4.j = } {p4.add_counter = }')

    
    m1 = e2 + p3

    m1 = p3 + p4

    print(f'\n{m1.joints_list = }')

    # p1.position_solver()
    print(f'\n{p1.component_ports[0].spacial_position = }')
    print(f'\n{p1.component_ports[1].spacial_position = }\n')

    # p2.position_solver()
    print(f'\n{p2.component_ports[0].spacial_position = }')
    print(f'\n{p2.component_ports[1].spacial_position = }\n')

    # p3.position_solver()
    print(f'\n{p3.component_ports[0].spacial_position = }')
    print(f'\n{p3.component_ports[1].spacial_position = }\n')

    # p4.position_solver()
    print(f'\n{p4.component_ports[0].spacial_position = }')
    print(f'\n{p4.component_ports[1].spacial_position = }\n')

def mass_conservation_from_mosaic_part_two():
    #This test should have a simple mosaic first, and then the other tests will have more complex ones
    pure_water = thermo.Chemical('water', T = 303)  # temperature in Kelvin
    current_a = Current(composition = pure_water, mass_flow = 3, P = 300_000)
    

    print(f'\n{current_a.id = }')
    print(f'\n{current_a.location = }')
    

    p1 = components.Pipe(internal_diam=0.03, length = 3)
    p2 = components.Pipe(internal_diam=0.03, length = 3)


    print(f'\n{p1.id = }')

    for port in p1.component_ports:
        print(f'{port.id = }')

    print(f'\n\n{p2.id = }')

    for port in p2.component_ports:
        print(f'{port.id = }')


    m1 = p1 + current_a

    print(f'\n\n{m1.joints_list = }\n\n')
    print(f'{p1.location = }')
    print(f'{p2.location = }')

    m1 = p1 + p2

    print(f'\n{m1.id = }')
    print(f'\n{current_a.location = }')

    print(f'\n\n{m1.joints_list = }\n\n')
    print(f'{p1.location = }')
    print(f'{p2.location = }')

    for m in mosaic.Mosaic.mosaic_objects:
        print(f'\n{m.id = }')

    m1.mass_conservation()

    print(f'\n\n\n{p2.component_ports[0].local_current.velocity = }')
    print(f'\n{p2.component_ports[0].local_current.id = }')
    #print(f'\n{p2.component_ports[0].local_current.composition = }')
    print(f'\n{p2.component_ports[0].local_current.mass_flow = }')
    print(f'\n{p2.component_ports[0].local_current.density() = }')
    print(f'\n{p2.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{p2.component_ports[0].local_current.volume_flow = }\n\n')

    print(f'\n\n\n{p2.component_ports[0].local_current.velocity = }')
    print(f'\n{p2.component_ports[0].local_current.id = }')
    #print(f'\n{p2.component_ports[0].local_current.composition = }')
    print(f'\n{p2.component_ports[0].local_current.mass_flow = }')
    print(f'\n{p2.component_ports[0].local_current.density() = }')
    print(f'\n{p2.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{p2.component_ports[0].local_current.volume_flow = }\n\n\n\n')

    print(f'\n\n\n{p2.component_ports[0].local_current.velocity = }')
    print(f'\n{p2.component_ports[0].local_current.id = }')
    #print(f'\n{p2.component_ports[0].local_current.composition = }')
    print(f'\n{p2.component_ports[0].local_current.mass_flow = }')
    print(f'\n{p2.component_ports[0].local_current.density() = }')
    print(f'\n{p2.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{p2.component_ports[0].local_current.volume_flow = }\n\n')

    print(f'\n\n\n{p2.component_ports[1].local_current.velocity = }')
    print(f'\n{p2.component_ports[1].local_current.id = }')
    #print(f'\n{p2.component_ports[1].local_current.composition = }')
    print(f'\n{p2.component_ports[1].local_current.mass_flow = }')
    print(f'\n{p2.component_ports[1].local_current.density() = }')
    print(f'\n{p2.component_ports[1].local_current.pressure = } Pa')
    print(f'\n{p2.component_ports[1].local_current.volume_flow = }\n\n')

def reynolds_from_component():
    pure_water = thermo.Chemical('water', T = 303)  # temperature in Kelvin
    current_a = Current(composition = pure_water, mass_flow = 3, P = 300_000)

    p1 = Pipe(internal_diam = 3, length = 4)
    
    m1 = p1+current_a

    m1.mass_conservation()

    print(f'\n\n\n{p1.component_ports[0].local_current.velocity = }')
    print(f'\n{p1.component_ports[0].local_current.composition = }')
    print(f'\n{p1.component_ports[0].local_current.mass_flow = }')
    print(f'\n{p1.component_ports[0].local_current.density() = }')
    print(f'\n{p1.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{p1.component_ports[0].local_current.volume_flow = }\n\n')
    
    


    print(f'\n{p1.component_ports[1].local_current.velocity = }')
    # print(f'\n{p1.component_ports[1].local_current.composition = }')
    print(f'\n{p1.component_ports[1].local_current.mass_flow = }')
    print(f'\n{p1.component_ports[1].local_current.density() = }')
    print(f'\n{p1.component_ports[1].local_current.pressure = } Pa')
    print(f'\n{p1.component_ports[1].local_current.volume_flow = }')
    

    print(f'\n{p1.reynolds(position = 0) = }')

    print(f'\n\n{p1.reynolds(position = 1) = }')
    ...

def reynolds_from_mosaic():
    """
    this test will test the behaviour of the calculation of the reynolds number inside a pipe or a group of pipes.

    It will be used to adjust the adjacent methods to work for the final method (called by the user) to be good and easy
    to use.
    """

    p1 = Pipe(internal_diam = 3, length = 4)
    p2 = Pipe(internal_diam = 3, length = 7)

    m1 = p1 + p2

    # I will put here the commands i qould like to use to call each method from the mosaic, as the user should do
    
    """
    I have to decide what will be the mathod for the user to set the location to calculate reynolds in one of the ports
    of a component with multiple inlet and/or outlet ports, specially in the cases where there are multiple ports with
    the same diameter.

    One form of solving this problem is telling the user to sellect the port of the component plugged to it.

    Example:

    if a pipe is plugged to the begginng of a Y connector, and two other pipes are plugged to the other ends.

    If the user whants to calculate the reynolds number on the first outlet port, the user should instead, try to
    calculate it on the inlet of the pipe that is linked to said port of the Y connector.

    The problem with this method is with cases that one multiple inlet/outlet ports connector is linked to another.
    in this case, i don't know what shold be the best bethod to the user to sellect the port he desires to do such calculation.
    """

    #this means that i whant to calculate the reynolds number on the outlet of the p1 Pipe
    m1.reynolds(component = p1, position = 1)

    #pressure on the inlet port of the p2 Pipe, and the loc keywok has to be optional, as the port
    m1.pressure(component = p2, position = p2.component_ports[0])

    # head pressure loss
    # this is the list that should contain all the components on the path that the user desires to calculate the pressure loss
    # this should return a float with the pressure loss on this path
    m1.charge_loss(path_list = [])

    #mass flow
    m1.mass_flow(p2, port = 'out')

    #volumetric flow
    m1.v_flow(p2, port = 'out')

    #NPSH
    m1.NPSH(p2, port = 'out')

def mass_conserevation_error():

    """
    This method will be used to see if the mass conservation from the component raises the correct error when two currents
    enter a Pipe and, obviously, there is no outlet port. This scenartio should raise an error
    """

    water = thermo.Chemical('water', T = 303)  # temperature in Kelvin
    current_1 = Current(composition = water, mass_flow = 3, P = 300_000)

    current_2 = Current(composition = water, mass_flow = 3, P = 300_000)

    pipe_a = Pipe(internal_diam = 3, length = 4)
    
    mosaic_1 = pipe_a+current_1

    mosaic_1 = pipe_a + current_2

    mosaic_1.mass_conservation()

    print(f'\n\n\n{pipe_a.component_ports[0].local_current.velocity = }')
    print(f'\n{pipe_a.component_ports[0].local_current.composition = }')
    print(f'\n{pipe_a.component_ports[0].local_current.mass_flow = }')
    print(f'\n{pipe_a.component_ports[0].local_current.density() = }')
    print(f'\n{pipe_a.component_ports[0].local_current.pressure = } Pa')
    print(f'\n{pipe_a.component_ports[0].local_current.volume_flow = }\n\n')
    
    


    print(f'\n{pipe_a.component_ports[1].local_current.velocity = }')
    # print(f'\n{pipe_a.component_ports[1].local_current.composition = }')
    print(f'\n{pipe_a.component_ports[1].local_current.mass_flow = }')
    print(f'\n{pipe_a.component_ports[1].local_current.density() = }')
    print(f'\n{pipe_a.component_ports[1].local_current.pressure = } Pa')
    print(f'\n{pipe_a.component_ports[1].local_current.volume_flow = }')
    

    print(f'\n{pipe_a.reynolds(position = 0) = }')

    print(f'\n\n{pipe_a.reynolds(position = 1) = }')

@timer
def main():
    #mass_conservation_from_mosaic_part_two()

    position_test_part_three()

    #reynolds_from_component()

    #mass_conserevation_error()
    
# if __name__ == 'main':
#     main()

main()

