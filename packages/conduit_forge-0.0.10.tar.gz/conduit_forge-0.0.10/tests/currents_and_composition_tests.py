from .decorators import timer
from conduitforge.components import (
    Component,
    MajorLossComponent,
    MinorLossComponent,
    Port,
    Pipe,
    T_connector,
)

from conduitforge.mosaic import Mosaic
from conduitforge.current import Current
from conduitforge.pump import Pump

import matplotlib

matplotlib.use("Qt5Agg")
# matplotlib.use("TkAgg")

import thermo
import sympy as sy
from uuid import UUID, uuid4
from ulid import ULID

import networkx as nx
import matplotlib.pyplot as plt


from mpl_toolkits.mplot3d import Axes3D
from typing import Optional
from pprint import pprint
from copy import deepcopy

from colorama import Fore, Back, Style


def composition_leak():
    """
    This test will be used to determinate if pressures and compositions can pass
    and 'leak' from one port/current to the other

    My theory is that, for the super simple system, maybe, when i say
    p1[0].P = Pca, and p1[1].P = 0. the 0 value may be thrown to every other
    pressure, because they are equalled by some equations. The way to solve this
    is simmilar to the method used inside the __add__ method from component, for
    the number of mosaics > 1. Maybe i have to create an intermediate object,
    and then delete said object, so that the numerical value is not re,ated to some
    variable or object anymore.

    This problem may happen also because two or more variables are pointing to
    the same memory address and, if said value is changed, all the valriables change


    """

    # Criação da composição química da corrente a
    pure_water = thermo.Chemical("water", T=303, P=300_000)

    # Criação da corrente a
    ca = Current(composition=pure_water)

    # Criação do tubo 1
    p1 = Pipe(internal_diam=0.05, length=4, orientation=0)

    print(f"\n{ca.id = }")

    print(f"\n{ca.pressure_name = }")

    print(f"\n{p1 = }")
    print(f"\n{p1.component_ports[0].id = }")
    print(f"\n{p1.component_ports[0].local_current.id = }")
    print(f"\n{p1.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p1.component_ports[1].id = }")
    print(f"\n{p1.component_ports[1].local_current.id = }")
    print(f"\n{p1.component_ports[1].local_current.pressure_name = }\n")

    a: list = [1, 2, 3]
    b = a
    print("\nBefore append in b\n")
    print(f"\n{id(a) = }")
    print(f"\n{id(b) = }")
    print(f"\n{b = }\n\n")

    b.append(4)

    print("\nAfter append in b")
    print(f"\n{a = }")
    print(f"\n{b = }")
    # # Criação do mosaico 1
    # m1 = p1 + ca

    # m1.automatic_solver(generate_dir_graph=True, data_in_dir_graph=True, verify=True)

    # print(f"\n\n{m1.solved_system = }\n")

    # print(f"\n\n{m1.equation_list = }\n")

    # print(f"\n\n{m1.var_list = }")
    # print(f"\n{m1.initial_values = }")


@timer
def deepcopy_tests():
    """
    This test will be used to see if the base objects (int, str, float, bool)
    are changed and or affected by the deepcopy native method (from the base python library)
    """

    standard_volume_flow = 5
    local_vol_flow = 0

    print("\nBefore")
    print(f"\n{id(standard_volume_flow) = }")
    print(f"\n{id(local_vol_flow) = }")
    print(f"\n{standard_volume_flow = }")
    print(f"\n{local_vol_flow = }")

    local_vol_flow = standard_volume_flow

    print("\nAfter")
    print(f"\n{id(standard_volume_flow) = }")
    print(f"\n{id(local_vol_flow) = }")
    print(f"\n{standard_volume_flow = }")
    print(f"\n{local_vol_flow = }")

    print("---------------------------------")

    other_standard_volume_flow = 6
    other_local_vol_flow = 0

    print("\nBefore")
    print(f"\n{id(other_standard_volume_flow) = }")
    print(f"\n{id(other_local_vol_flow) = }")
    print(f"\n{other_standard_volume_flow = }")
    print(f"\n{other_local_vol_flow = }")

    other_local_vol_flow = deepcopy(other_standard_volume_flow)

    print("\nBefore")
    print(f"\n{id(other_standard_volume_flow) = }")
    print(f"\n{id(other_local_vol_flow) = }")
    print(f"\n{other_standard_volume_flow = }")
    print(f"\n{other_local_vol_flow = }")


def curr_test():
    pure_water = thermo.Chemical(ID="water", T=303, P=300_000)
    ca = Current(composition=pure_water)


if __name__ == "__main__":
    # * composition_leak()
    deepcopy_tests()
