import networkx as nx

G = nx.DiGraph()
G.add_edge(1, 2)
print("NetworkX está funcionando!")
