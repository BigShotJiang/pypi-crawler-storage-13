import time as time
from functools import wraps
from colorama import Fore, Back, Style

def timer(func):
    """Print the runtime of the decorated function"""

    @wraps(func)
    def wrapper_timer(*args, **kwargs):
        start_time = time.perf_counter()
        value = func(*args, **kwargs)
        end_time = time.perf_counter()
        run_time = end_time - start_time

        if run_time <= 1.5:
            back_color = Back.GREEN
        elif (run_time >= 1.5) and (run_time <= 2.5):
            back_color = Back.YELLOW
        elif (run_time >= 2.5) and (run_time <= 3.5):
            back_color = Back.RED
        elif run_time >= 2.5:
            back_color = Back.LIGHTBLACK_EX
        print(
            f"{Fore.BLACK + back_color}\nFinished {func.__name__}() in {run_time:.4f} seconds{Style.RESET_ALL}"
        )
        # print(Style.RESET_ALL)
        return value

    return wrapper_timer