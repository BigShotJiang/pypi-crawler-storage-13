# from CONDUIT_FORGE import src.
# from ..src import components
# from ..src import current
# from ..src import mosaic

from .decorators import timer
from .verificador_objetos_mutaveis_compatrtilhados import relatorio_compartilhamentos
from conduitforge.components import (
    Component,
    MajorLossComponent,
    MinorLossComponent,
    Port,
    Pipe,
    T_connector,
)
from conduitforge.pump import Pump

from conduitforge.mosaic import Mosaic
from conduitforge.current import Current
from conduitforge.pump import Pump

import matplotlib

matplotlib.use("Qt5Agg")
# matplotlib.use("TkAgg")

import thermo
import sympy as sy
from uuid import UUID, uuid4
from ulid import ULID

import networkx as nx
import matplotlib.pyplot as plt


from mpl_toolkits.mplot3d import Axes3D
from typing import Optional
from pprint import pprint

from colorama import Fore, Back, Style


r"""

This file will be used to generate prints of the code, to use as ilustrations inside
a scientific paper.
"""


def Pipe_com_e_sem_orientation():
    # Criação do tubo 1
    p1 = Pipe(internal_diam=0.05, length=4, orientation=90)

    # Criação do tubo 2
    p2 = Pipe(internal_diam=0.05, length=4)


def exemplo_de_mosaico_com_multiplos_componentes_e_correntes():
    """
    Essa função foi criada para representar um mosaico na forma de Y, mas
    não tem o propósito de ser rodada e simulada

    Esse mosaico foi feito para ser no formato mostrado a seguir:
    ca
    |p1
    |-t -p3 ->
    |p2
    ^
    cb

    Esse é um mosaico na forma de y, com ca e cb entrando, e a saida é em p3
    """

    # Criação da composição química da corrente a
    benzene_1 = thermo.Chemical("benzene", T=303, P=300_000)
    benzene_2 = thermo.Chemical("benzene", T=303, P=300_000)

    # Criação da corrente a
    ca = Current(composition=benzene_1)

    # Criação da corrente a
    cb = Current(composition=benzene_2)

    # Criação do tubo 1
    p1 = Pipe(internal_diam=0.05, length=4, orientation=90)

    # Criação do tubo 2
    p2 = Pipe(internal_diam=0.05, length=4, orientation=90)

    # Criação do tubo 3
    p3 = Pipe(internal_diam=0.05, length=4, orientation=0)

    t = T_connector(internal_diam=0.05)

    # mosaico_1 = p1 + ca

    # mosaico_1 = p1 + t

    # mosaico_1 = p2 + t

    # mosaico_1 = p2 + cb

    # mosaico_1 = p3 + t

    # // Usando como exemplo o simple_mosaic_test, eu pensei em uma forma alterantiva
    # // de criar o mosaico m1, pra minimizar erros

    # // Essa forma seria começar a compor o mosaico pelo tubo p3 e t1
    # // e só depois disso eu iria colocar as correntes de entrada, ca e cb

    mosaico_1 = p3 + t
    mosaico_1 = t + p2
    mosaico_1 = t + p1
    mosaico_1 = p1 + ca
    mosaico_1 = p2 + cb

    mosaico_1.automatic_solve(generate_dir_graph=True, data_in_dir_graph=True)


def exemplo_de_classes_e_herança():
    class Avião:
        def __init__(
            self, tipo_de_motor, capacidade_de_passageiros, velocidade_de_cruzeiro
        ):
            self.tipo_de_motor = tipo_de_motor
            self.capacidade_de_passageiros = capacidade_de_passageiros
            self.velocidade_de_cruzeiro = velocidade_de_cruzeiro

        def decolar(self): ...

        def pousar(self): ...

        def ligar(self): ...
        def desligar(self): ...

    class AviãoComTremDePouso(Avião):
        def __init__(
            self, tipo_de_motor, capacidade_de_passageiros, velocidade_de_cruzeiro
        ):
            super.__init__(
                tipo_de_motor, capacidade_de_passageiros, velocidade_de_cruzeiro
            )

        def baixar_trém_de_pouso(self): ...

    Cessna_172_Skyhawk = Avião(
        tipo_de_motor="pistão Lyncoming",
        capacidade_de_passageiros=3,
        velocidade_de_cruzeiro=226,
    )

    Cessna_172_Skyhawk.ligar()
    Cessna_172_Skyhawk.decolar()
    Cessna_172_Skyhawk.pousar()
    Cessna_172_Skyhawk.desligar()

    Boeing_737 = AviãoComTremDePouso(
        tipo_de_motor="turbofan",
        capacidade_de_passageiros=160,
        velocidade_de_cruzeiro=912,
    )

    Boeing_737.ligar()
    Boeing_737.decolar()
    Boeing_737.baixar_trém_de_pouso()
    Boeing_737.pousar()
    Boeing_737.desligar()


def gráfico_direcionado_mock_up_sistema_super_simples(): ...


def exemplo_de_uuid_v4():
    a = uuid4()

    print(f"\n{a = }\n")


def exemplo_de_ulid():
    b = ULID()

    print(f"\n{b = }\n")


@timer
def simple_mosaic_test():
    """
    This test will be used to verify if simple mosaics are solved correctly

    The mosaic solved is shown below
                 p2

                 ^
                 |
    ca -> p1 -> t1 -> p3

    """

    water = thermo.Chemical("water", T=293.15, P=300_000)  # temperature in Kelvin
    ca = Current(composition=water)

    p1 = Pipe(internal_diam=0.03, length=0.4, orientation=0)
    p2 = Pipe(internal_diam=0.03, length=0.7, orientation=90)
    p3 = Pipe(internal_diam=0.03, length=0.4, orientation=0)

    t1 = T_connector(internal_diam=3)

    m1 = p1 + ca
    m1 = p1 + t1
    m1 = t1 + p2
    m1 = t1 + p3

    print(f"\n\n{m1.joints_list = }")

    print(f"\n{ca.id = }")

    print(f"\n{ca.pressure_name = }")

    print(f"\n{p1 = }")
    print(f"\n{p1.component_ports[0].id = }")
    print(f"\n{p1.component_ports[0].local_current.id = }")
    print(f"\n{p1.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p1.component_ports[1].id = }")
    print(f"\n{p1.component_ports[1].local_current.id = }")
    print(f"\n{p1.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p2 = }")
    print(f"\n{p2.component_ports[0].id = }")
    print(f"\n{p2.component_ports[0].local_current.id = }")
    print(f"\n{p2.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p2.component_ports[1].id = }")
    print(f"\n{p2.component_ports[1].local_current.id = }")
    print(f"\n{p2.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p3 = }")
    print(f"\n{p3.component_ports[0].id = }")
    print(f"\n{p3.component_ports[0].local_current.id = }")
    print(f"\n{p3.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p3.component_ports[1].id = }")
    print(f"\n{p3.component_ports[1].local_current.id = }")
    print(f"\n{p3.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{t1 = }")
    print(f"\n{t1.component_ports[0].id = }")
    print(f"\n{t1.component_ports[0].local_current.id = }")
    print(f"\n{t1.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[1].id = }")
    print(f"\n{t1.component_ports[1].local_current.id = }")
    print(f"\n{t1.component_ports[1].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[2].id = }")
    print(f"\n{t1.component_ports[2].local_current.id = }")
    print(f"\n{t1.component_ports[2].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[3].id = }")

    m1.create_graph_2()

    m1.symple_q_p_guess()
    m1.equation_gathering_from_graph()

    freedom_deg_number = len(m1.all_eq_variables) - len(m1.equation_list)

    pprint(
        f"This is the number of variables in the system \
            {m1.all_eq_variables = }"
    )

    pprint(
        f"This is the number of variables in the system \
            {len(m1.all_eq_variables) = }"
    )

    pprint(
        f"This is the number of equations in the system \
            {len(m1.equation_list) = }"
    )

    pprint(
        f"This is the number of degrees of freedom of the equation system \
            {freedom_deg_number = }"
    )

    pprint(f"\n\n{m1.equations_dict = }\n\n")

    print(f"{len(m1.equation_list) = }")

    m1.equations_solver()

    print(f"\n{m1.solved_system = }\n")

    formated_solved_system: dict = dict(zip(m1.var_list, m1.solved_system))

    pprint(f"{formated_solved_system = }")

    print(f"\n\n{m1.graph.nodes() = }\n")
    print(f"\n{list(m1.graph.nodes()) = }\n")
    print(f"\n{list(m1.graph.nodes())[0] = }\n")
    print(f"\n{type(list(m1.graph.nodes())[0]) = }\n")
    print(f"\n{str(list(m1.graph.nodes())[0]) = }\n")

    print(f"\n\n{m1.var_list = }\n")
    print(f"\n{m1.var_list[0] = }\n")
    print(f"\n{type(m1.var_list[0]) = }\n")
    print(f"\n{str(m1.var_list[0]) = }\n")

    plt.figure(1, figsize=(8, 6))

    pos1 = nx.spring_layout(m1.graph, k=3, seed=12)

    # Desenha o grafo com o layout escolhido, mostrando as conexões (arestas)
    nx.draw(
        m1.graph,
        pos1,
        with_labels=True,
        node_color="lightblue",
        node_size=500,
        font_size=7,
        font_color="black",
        edge_color="gray",
        arrows=True,
        connectionstyle="arc3,rad=0.2",
    )

    # * Mostra o gráfico
    plt.show(block=True)

    plt.figure(2, figsize=(8, 6))

    pos2 = nx.spring_layout(nx.to_undirected(m1.graph), seed=12)

    # * Desenhar o grafico com o layout escolhido, mostrando as conexões (arestas)
    nx.draw(
        nx.to_undirected(m1.graph),
        pos2,
        with_labels=False,
        node_color="lightblue",
        node_size=500,
        font_size=12,
        font_color="black",
        edge_color="gray",
        arrows=True,
        connectionstyle="arc3,rad=0.2",
    )

    labels = {
        n: f"{n}\npressure={d.get("pressure")}\nvol_flow={d.get("vol_flow")}"
        for n, d in m1.graph.nodes(data=True)
    }

    nx.draw_networkx_labels(m1.graph, pos2, labels, font_size=9, font_color="black")

    # * Mostra o gráfico
    plt.show(block=True)


@timer
def three_outlet_one_inlet_mosaic():
    """
    This test will be used to verify if simple mosaics are solved correctly

    The mosaic solved is shown below
                 p2          p5

                 ^           ^
                 |           |
    ca -> p1 -> t1 -> p3 -> t2 -> p4

    """

    water = thermo.Chemical("water", T=293.15, P=300_000)  # temperature in Kelvin
    ca = Current(composition=water)

    p1 = Pipe(internal_diam=0.03, length=0.4, orientation=0)
    p2 = Pipe(internal_diam=0.03, length=0.7, orientation=90)
    p3 = Pipe(internal_diam=0.03, length=0.4, orientation=0)
    p4 = Pipe(internal_diam=0.03, length=0.7, orientation=90)
    p5 = Pipe(internal_diam=0.03, length=0.4, orientation=0)

    t1 = T_connector(internal_diam=3)

    t2 = T_connector(internal_diam=3)

    m1 = p1 + ca
    m1 = p1 + t1
    m1 = t1 + p2
    m1 = t1 + p3
    m1 = p3 + t2
    m1 = t2 + p5
    m1 = t2 + p4

    print(f"\n{ca.id = }")

    print(f"\n{ca.pressure_name = }")

    print(f"\n{p1 = }")
    print(f"\n{p1.component_ports[0].id = }")
    print(f"\n{p1.component_ports[0].local_current.id = }")
    print(f"\n{p1.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p1.component_ports[1].id = }")
    print(f"\n{p1.component_ports[1].local_current.id = }")
    print(f"\n{p1.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p2 = }")
    print(f"\n{p2.component_ports[0].id = }")
    print(f"\n{p2.component_ports[0].local_current.id = }")
    print(f"\n{p2.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p2.component_ports[1].id = }")
    print(f"\n{p2.component_ports[1].local_current.id = }")
    print(f"\n{p2.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p3 = }")
    print(f"\n{p3.component_ports[0].id = }")
    print(f"\n{p3.component_ports[0].local_current.id = }")
    print(f"\n{p3.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p3.component_ports[1].id = }")
    print(f"\n{p3.component_ports[1].local_current.id = }")
    print(f"\n{p3.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p4 = }")
    print(f"\n{p4.component_ports[0].id = }")
    print(f"\n{p4.component_ports[0].local_current.id = }")
    print(f"\n{p4.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p4.component_ports[1].id = }")
    print(f"\n{p4.component_ports[1].local_current.id = }")
    print(f"\n{p4.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p5 = }")
    print(f"\n{p5.component_ports[0].id = }")
    print(f"\n{p5.component_ports[0].local_current.id = }")
    print(f"\n{p5.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p5.component_ports[1].id = }")
    print(f"\n{p5.component_ports[1].local_current.id = }")
    print(f"\n{p5.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{t1 = }")
    print(f"\n{t1.component_ports[0].id = }")
    print(f"\n{t1.component_ports[0].local_current.id = }")
    print(f"\n{t1.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[1].id = }")
    print(f"\n{t1.component_ports[1].local_current.id = }")
    print(f"\n{t1.component_ports[1].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[2].id = }")
    print(f"\n{t1.component_ports[2].local_current.id = }")
    print(f"\n{t1.component_ports[2].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[3].id = }")

    print(f"\n{t2 = }")
    print(f"\n{t2.component_ports[0].id = }")
    print(f"\n{t2.component_ports[0].local_current.id = }")
    print(f"\n{t2.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[1].id = }")
    print(f"\n{t2.component_ports[1].local_current.id = }")
    print(f"\n{t2.component_ports[1].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[2].id = }")
    print(f"\n{t2.component_ports[2].local_current.id = }")
    print(f"\n{t2.component_ports[2].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[3].id = }")

    m1.create_graph_2()

    m1.symple_q_p_guess(volume_flow_guess=0.1, pressure_guess=1_000)
    m1.equation_gathering_from_graph()

    freedom_deg_number = len(m1.all_eq_variables) - len(m1.equation_list)

    pprint(
        f"This is the number of variables in the system \
            {m1.all_eq_variables = }"
    )

    pprint(
        f"This is the number of variables in the system \
            {len(m1.all_eq_variables) = }"
    )

    pprint(
        f"This is the number of equations in the system \
            {len(m1.equation_list) = }"
    )

    pprint(
        f"This is the number of degrees of freedom of the equation system \
            {freedom_deg_number = }"
    )

    pprint(f"\n\n{m1.equations_dict = }\n\n")

    print(f"{len(m1.equation_list) = }")

    m1.equations_solver()

    print(f"\n{m1.solved_system = }\n")

    formated_solved_system: dict = dict(zip(m1.var_list, m1.solved_system))

    pprint(f"{formated_solved_system = }")

    print(f"\n\n{m1.graph.nodes() = }\n")
    print(f"\n{list(m1.graph.nodes()) = }\n")
    print(f"\n{list(m1.graph.nodes())[0] = }\n")
    print(f"\n{type(list(m1.graph.nodes())[0]) = }\n")
    print(f"\n{str(list(m1.graph.nodes())[0]) = }\n")

    print(f"\n\n{m1.var_list = }\n")
    print(f"\n{m1.var_list[0] = }\n")
    print(f"\n{type(m1.var_list[0]) = }\n")
    print(f"\n{str(m1.var_list[0]) = }\n")

    plt.figure(1, figsize=(8, 6))

    pos1 = nx.spring_layout(m1.graph, k=3, seed=12)

    # Desenha o grafo com o layout escolhido, mostrando as conexões (arestas)
    nx.draw(
        m1.graph,
        pos1,
        with_labels=True,
        node_color="lightblue",
        node_size=500,
        font_size=7,
        font_color="black",
        edge_color="gray",
        arrows=True,
        connectionstyle="arc3,rad=0.2",
    )

    # * Mostra o gráfico
    plt.show(block=True)

    plt.figure(2, figsize=(8, 6))

    pos2 = nx.spring_layout(nx.to_undirected(m1.graph), seed=12)

    # * Desenhar o grafico com o layout escolhido, mostrando as conexões (arestas)
    nx.draw(
        nx.to_undirected(m1.graph),
        pos2,
        with_labels=False,
        node_color="lightblue",
        node_size=500,
        font_size=12,
        font_color="black",
        edge_color="gray",
        arrows=True,
        connectionstyle="arc3,rad=0.2",
    )

    labels = {
        n: f"{n}\npressure={d.get("pressure")}\nvol_flow={d.get("vol_flow")}"
        for n, d in m1.graph.nodes(data=True)
    }

    nx.draw_networkx_labels(m1.graph, pos2, labels, font_size=9, font_color="black")

    # * Mostra o gráfico
    plt.show(block=True)


@timer
def simplifyed_three_outlet_one_inlet_mosaic():
    """
    This test will be used to verify if simple mosaics are solved correctly

    The mosaic solved is shown below
          ^
          |
          t2 ->
          ^
          |
    ca -> t1 ->

    """

    water = thermo.Chemical("water", T=293.15, P=300_000)  # temperature in Kelvin
    ca = Current(composition=water)

    # p1 = Pipe(internal_diam=0.03, length=0.4, orientation=0)
    # p2 = Pipe(internal_diam=0.03, length=0.7, orientation=90)
    # p3 = Pipe(internal_diam=0.03, length=0.4, orientation=0)

    t1 = T_connector(internal_diam=3)
    t2 = T_connector(internal_diam=3)

    # m1 = p1 + ca
    # m1 = p1 + t1
    # m1 = t1 + t2

    m1 = t1 + ca
    m1 = t1 + t2

    print(f"\n{ca.id = }")

    print(f"\n{ca.pressure_name = }")

    # print(f"\n{p1 = }")
    # print(f"\n{p1.component_ports[0].id = }")
    # print(f"\n{p1.component_ports[0].local_current.id = }")
    # print(f"\n{p1.component_ports[0].local_current.pressure_name = }\n")
    # print(f"\n{p1.component_ports[1].id = }")
    # print(f"\n{p1.component_ports[1].local_current.id = }")
    # print(f"\n{p1.component_ports[1].local_current.pressure_name = }\n")

    # print(f"\n{p2 = }")
    # print(f"\n{p2.component_ports[0].id = }")
    # print(f"\n{p2.component_ports[0].local_current.id = }")
    # print(f"\n{p2.component_ports[0].local_current.pressure_name = }\n")
    # print(f"\n{p2.component_ports[1].id = }")
    # print(f"\n{p2.component_ports[1].local_current.id = }")
    # print(f"\n{p2.component_ports[1].local_current.pressure_name = }\n")

    # print(f"\n{p3 = }")
    # print(f"\n{p3.component_ports[0].id = }")
    # print(f"\n{p3.component_ports[0].local_current.id = }")
    # print(f"\n{p3.component_ports[0].local_current.pressure_name = }\n")
    # print(f"\n{p3.component_ports[1].id = }")
    # print(f"\n{p3.component_ports[1].local_current.id = }")
    # print(f"\n{p3.component_ports[1].local_current.pressure_name = }\n")

    # print(f"\n{p4 = }")
    # print(f"\n{p4.component_ports[0].id = }")
    # print(f"\n{p4.component_ports[0].local_current.id = }")
    # print(f"\n{p4.component_ports[0].local_current.pressure_name = }\n")
    # print(f"\n{p4.component_ports[1].id = }")
    # print(f"\n{p4.component_ports[1].local_current.id = }")
    # print(f"\n{p4.component_ports[1].local_current.pressure_name = }\n")

    # print(f"\n{p5 = }")
    # print(f"\n{p5.component_ports[0].id = }")
    # print(f"\n{p5.component_ports[0].local_current.id = }")
    # print(f"\n{p5.component_ports[0].local_current.pressure_name = }\n")
    # print(f"\n{p5.component_ports[1].id = }")
    # print(f"\n{p5.component_ports[1].local_current.id = }")
    # print(f"\n{p5.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{t1 = }")
    print(f"\n{t1.component_ports[0].id = }")
    print(f"\n{t1.component_ports[0].local_current.id = }")
    print(f"\n{t1.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[1].id = }")
    print(f"\n{t1.component_ports[1].local_current.id = }")
    print(f"\n{t1.component_ports[1].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[2].id = }")
    print(f"\n{t1.component_ports[2].local_current.id = }")
    print(f"\n{t1.component_ports[2].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[3].id = }")

    print(f"\n{t2 = }")
    print(f"\n{t2.component_ports[0].id = }")
    print(f"\n{t2.component_ports[0].local_current.id = }")
    print(f"\n{t2.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[1].id = }")
    print(f"\n{t2.component_ports[1].local_current.id = }")
    print(f"\n{t2.component_ports[1].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[2].id = }")
    print(f"\n{t2.component_ports[2].local_current.id = }")
    print(f"\n{t2.component_ports[2].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[3].id = }")

    m1.automatic_solver(generate_dir_graph=True, data_in_dir_graph=True, verify=True)

    """
    m1.create_graph_2()

    m1.symple_q_p_guess(volume_flow_guess=1, pressure_guess=300_000)
    m1.equation_gathering_from_graph()

    freedom_deg_number = len(m1.all_eq_variables) - len(m1.equation_list)

    pprint(
        f"This is the number of variables in the system \
            {m1.all_eq_variables = }"
    )

    pprint(
        f"This is the number of variables in the system \
            {len(m1.all_eq_variables) = }"
    )

    pprint(
        f"This is the number of equations in the system \
            {len(m1.equation_list) = }"
    )

    pprint(
        f"This is the number of degrees of freedom of the equation system \
            {freedom_deg_number = }"
    )

    pprint(f"\n\n{m1.equations_dict = }\n\n")

    print(f"{len(m1.equation_list) = }")

    m1.equations_solver(verify=True)

    print(f"\n{m1.solved_system = }\n")

    formated_solved_system: dict = dict(zip(m1.var_list, m1.solved_system))

    pprint(f"{formated_solved_system = }")

    print(f"\n\n{m1.graph.nodes() = }\n")
    print(f"\n{list(m1.graph.nodes()) = }\n")
    print(f"\n{list(m1.graph.nodes())[0] = }\n")
    print(f"\n{type(list(m1.graph.nodes())[0]) = }\n")
    print(f"\n{str(list(m1.graph.nodes())[0]) = }\n")

    print(f"\n\n{m1.var_list = }\n")
    print(f"\n{m1.var_list[0] = }\n")
    print(f"\n{type(m1.var_list[0]) = }\n")
    print(f"\n{str(m1.var_list[0]) = }\n")

    plt.figure(1, figsize=(8, 6))

    pos1 = nx.spring_layout(m1.graph, k=3, seed=12)

    # Desenha o grafo com o layout escolhido, mostrando as conexões (arestas)
    nx.draw(
        m1.graph,
        pos1,
        with_labels=True,
        node_color="lightblue",
        node_size=500,
        font_size=7,
        font_color="black",
        edge_color="gray",
        arrows=True,
        connectionstyle="arc3,rad=0.2",
    )

    # * Mostra o gráfico
    plt.show(block=True)

    plt.figure(2, figsize=(8, 6))

    pos2 = nx.spring_layout(nx.to_undirected(m1.graph), seed=12)

    # * Desenhar o grafico com o layout escolhido, mostrando as conexões (arestas)
    nx.draw(
        nx.to_undirected(m1.graph),
        pos2,
        with_labels=False,
        node_color="lightblue",
        node_size=500,
        font_size=12,
        font_color="black",
        edge_color="gray",
        arrows=True,
        connectionstyle="arc3,rad=0.2",
    )

    labels = {
        n: f"{n}\npressure={d.get("pressure")}\nvol_flow={d.get("vol_flow")}"
        for n, d in m1.graph.nodes(data=True)
    }

    nx.draw_networkx_labels(m1.graph, pos2, labels, font_size=9, font_color="black")

    # * Mostra o gráfico
    plt.show(block=True)

    """


@timer
def ultra_simplifyed_three_outlet_one_inlet_mosaic():
    """
    This test will be used to verify if simple mosaics are solved correctly

    The mosaic solved is shown below
          ^
          |
          t2 ->
          ^
          |
    ca  -> t1 ->

    """
    ...


@timer
def super_simple_system():
    """
    This system will just be used to assure that the library is also capable of
    handling simple and/or small systems too.

    The system tested is shown below:

    ca -> p1
    """

    # Criação da composição química da corrente a
    pure_water = thermo.Chemical("water", T=303, P=300_000)

    # Criação da corrente a
    ca = Current(composition=pure_water)

    # Criação do tubo 1
    p1 = Pipe(internal_diam=0.05, length=4, orientation=0)

    print(f"\n{ca.id = }")

    print(f"\n{ca.pressure_name = }")

    print(f"\n{p1 = }")
    print(f"\n{p1.component_ports[0].id = }")
    print(f"\n{p1.component_ports[0].local_current.id = }")
    print(f"\n{p1.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p1.component_ports[1].id = }")
    print(f"\n{p1.component_ports[1].local_current.id = }")
    print(f"\n{p1.component_ports[1].local_current.pressure_name = }\n")

    # Criação do mosaico 1
    m1 = p1 + ca

    m1.automatic_solver(
        v_flow_guess=0.1,
        p_guess=300_000,
        generate_dir_graph=True,
        data_in_dir_graph=True,
        verify=True,
    )

    print(f"\n\n{m1.solved_system = }\n")

    print(f"\n\n{m1.equation_list = }\n")

    print(f"\n\n{m1.var_list = }")
    print(f"\n{m1.initial_values = }")


def um_ramo_simples(): ...


def Y_bifutcado(): ...


@timer
def characteristic_system():
    """
    This test was created to determinate if the components do have some variable
    inside all of its equations that is:
        1 - Unique
        2 - Is explicitly returned (as a Sy.Symbol) inside each and every componentequation

    If such variable exists, the second step is to verify of there are other característic
    variables inside each component.

    """
    # // Esse codigo veio direto do módulo component_tests.py

    pure_water = thermo.Chemical("water", T=303, P=300_000)  # temperature in Kelvin
    current_a = Current(composition=pure_water)

    #! THose in yellow (marked woth #//) are the old data, from when results where not converging
    # // p1 = Pipe(internal_diam=3, length=4, orientation=-90)
    # // p2 = Pipe(internal_diam=3, length=7, orientation=0)
    # // p3 = Pipe(internal_diam=3, length=4, orientation=90)
    # // p4 = Pipe(internal_diam=3, length=7, orientation=0)

    # //t1 = T_connector(internal_diam=3)
    # //t2 = T_connector(internal_diam=3)

    p1 = Pipe(internal_diam=0.05, length=4, orientation=-90)
    p2 = Pipe(internal_diam=0.05, length=7, orientation=0)
    p3 = Pipe(internal_diam=0.05, length=4, orientation=90)
    p4 = Pipe(internal_diam=0.05, length=7, orientation=0)

    t1 = T_connector(internal_diam=0.05)
    t2 = T_connector(internal_diam=0.05)

    # all_components: list[Component] = [p1, p2, p3, p4, t1, t2]

    print(f"\n{current_a.id = }")
    print(f"\n{current_a.pressure_name = }")

    print(f"\n{p1 = }")
    print(f"\n{p1.component_ports[0].id = }")
    print(f"\n{p1.component_ports[0].local_current.id = }")
    print(f"\n{p1.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p1.component_ports[1].id = }")
    print(f"\n{p1.component_ports[1].local_current.id = }")
    print(f"\n{p1.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p2 = }")
    print(f"\n{p2.component_ports[0].id = }")
    print(f"\n{p2.component_ports[0].local_current.id = }")
    print(f"\n{p2.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p2.component_ports[1].id = }")
    print(f"\n{p2.component_ports[1].local_current.id = }")
    print(f"\n{p2.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p3 = }")
    print(f"\n{p3.component_ports[0].id = }")
    print(f"\n{p3.component_ports[0].local_current.id = }")
    print(f"\n{p3.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p3.component_ports[1].id = }")
    print(f"\n{p3.component_ports[1].local_current.id = }")
    print(f"\n{p3.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p4 = }")
    print(f"\n{p4.component_ports[0].id = }")
    print(f"\n{p4.component_ports[0].local_current.id = }")
    print(f"\n{p4.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p4.component_ports[1].id = }")
    print(f"\n{p4.component_ports[1].local_current.id = }")
    print(f"\n{p4.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{t1 = }")
    print(f"\n{t1.component_ports[0].id = }")
    print(f"\n{t1.component_ports[0].local_current.id = }")
    print(f"\n{t1.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[1].id = }")
    print(f"\n{t1.component_ports[1].local_current.id = }")
    print(f"\n{t1.component_ports[1].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[2].id = }")
    print(f"\n{t1.component_ports[2].local_current.id = }")
    print(f"\n{t1.component_ports[2].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[3].id = }")

    print(f"\n{t2 = }")
    print(f"\n{t2.component_ports[0].id = }")
    print(f"\n{t2.component_ports[0].local_current.id = }")
    print(f"\n{t2.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[1].id = }")
    print(f"\n{t2.component_ports[1].local_current.id = }")
    print(f"\n{t2.component_ports[1].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[2].id = }")
    print(f"\n{t2.component_ports[2].local_current.id = }")
    print(f"\n{t2.component_ports[2].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[3].id = }")

    m1: Optional[Mosaic] = t1 + current_a

    m1 = t1 + p1
    m1 = p1 + p2
    m1 = p2 + p3

    m1 = t1 + p4

    m1 = p4 + t2

    m1 = t2 + p3

    assert m1 is not None
    assert m1.graph is not None

    print(f"\n\n\n{m1.id = }\n\n\n")

    m1.automatic_solver(
        v_flow_guess=0.1,
        p_guess=200_000,
        generate_dir_graph=True,
        data_in_dir_graph=True,
        verify=True,
    )


@timer
def characteristic_system_with_elbows(): ...


@timer
def characteristic_system_with_inlet_pump():
    """
    This test was created to determinate if the components do have some variable
    inside all of its equations that is:
        1 - Unique
        2 - Is explicitly returned (as a Sy.Symbol) inside each and every componentequation

    If such variable exists, the second step is to verify of there are other característic
    variables inside each component.

    """
    # // Esse codigo veio direto do módulo component_tests.py

    pure_water = thermo.Chemical("water", T=303, P=300_000)  # temperature in Kelvin
    current_a = Current(composition=pure_water)

    #! THose in yellow (marked woth #//) are the old data, from when results where not converging
    # // p1 = Pipe(internal_diam=3, length=4, orientation=-90)
    # // p2 = Pipe(internal_diam=3, length=7, orientation=0)
    # // p3 = Pipe(internal_diam=3, length=4, orientation=90)
    # // p4 = Pipe(internal_diam=3, length=7, orientation=0)

    # //t1 = T_connector(internal_diam=3)
    # //t2 = T_connector(internal_diam=3)

    p1 = Pipe(internal_diam=0.05, length=4, orientation=-90)
    p2 = Pipe(internal_diam=0.05, length=7, orientation=0)
    p3 = Pipe(internal_diam=0.05, length=4, orientation=90)
    p4 = Pipe(internal_diam=0.05, length=7, orientation=0)

    t1 = T_connector(internal_diam=0.05)
    t2 = T_connector(internal_diam=0.05)

    # all_components: list[Component] = [p1, p2, p3, p4, t1, t2]

    print(f"\n{current_a.id = }")
    print(f"\n{current_a.pressure_name = }")

    print(f"\n{p1 = }")
    print(f"\n{p1.component_ports[0].id = }")
    print(f"\n{p1.component_ports[0].local_current.id = }")
    print(f"\n{p1.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p1.component_ports[1].id = }")
    print(f"\n{p1.component_ports[1].local_current.id = }")
    print(f"\n{p1.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p2 = }")
    print(f"\n{p2.component_ports[0].id = }")
    print(f"\n{p2.component_ports[0].local_current.id = }")
    print(f"\n{p2.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p2.component_ports[1].id = }")
    print(f"\n{p2.component_ports[1].local_current.id = }")
    print(f"\n{p2.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p3 = }")
    print(f"\n{p3.component_ports[0].id = }")
    print(f"\n{p3.component_ports[0].local_current.id = }")
    print(f"\n{p3.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p3.component_ports[1].id = }")
    print(f"\n{p3.component_ports[1].local_current.id = }")
    print(f"\n{p3.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{p4 = }")
    print(f"\n{p4.component_ports[0].id = }")
    print(f"\n{p4.component_ports[0].local_current.id = }")
    print(f"\n{p4.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{p4.component_ports[1].id = }")
    print(f"\n{p4.component_ports[1].local_current.id = }")
    print(f"\n{p4.component_ports[1].local_current.pressure_name = }\n")

    print(f"\n{t1 = }")
    print(f"\n{t1.component_ports[0].id = }")
    print(f"\n{t1.component_ports[0].local_current.id = }")
    print(f"\n{t1.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[1].id = }")
    print(f"\n{t1.component_ports[1].local_current.id = }")
    print(f"\n{t1.component_ports[1].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[2].id = }")
    print(f"\n{t1.component_ports[2].local_current.id = }")
    print(f"\n{t1.component_ports[2].local_current.pressure_name = }\n")
    print(f"\n{t1.component_ports[3].id = }")

    print(f"\n{t2 = }")
    print(f"\n{t2.component_ports[0].id = }")
    print(f"\n{t2.component_ports[0].local_current.id = }")
    print(f"\n{t2.component_ports[0].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[1].id = }")
    print(f"\n{t2.component_ports[1].local_current.id = }")
    print(f"\n{t2.component_ports[1].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[2].id = }")
    print(f"\n{t2.component_ports[2].local_current.id = }")
    print(f"\n{t2.component_ports[2].local_current.pressure_name = }\n")
    print(f"\n{t2.component_ports[3].id = }")

    m1: Optional[Mosaic] = t1 + current_a

    m1 = t1 + p1
    m1 = p1 + p2
    m1 = p2 + p3

    m1 = t1 + p4

    m1 = p4 + t2

    m1 = t2 + p3

    assert m1 is not None
    assert m1.graph is not None

    print(f"\n\n\n{m1.id = }\n\n\n")

    m1.automatic_solver(
        v_flow_guess=0.1,
        p_guess=200_000,
        generate_dir_graph=True,
        data_in_dir_graph=True,
        verify=True,
    )


if __name__ == "__main__":
    # * comp_characteristic_eq()

    # simple_mosaic_test()
    # exemplo_de_uuid_v4()
    # exemplo_de_ulid()

    # ?super_simple_system()

    # ? simple_mosaic_test()

    # // The next test to be evaluated is the
    # // super_simplified_system_with_pump()

    # // super_simplified_system_with_pump()

    # // exemplo_de_mosaico_com_multiplos_componentes_e_correntes()

    #! three_outlet_one_inlet_mosaic()

    #!simplifyed_three_outlet_one_inlet_mosaic()

    # * simple_mosaic_pump_test_pressurization()

    # * experimental_solving_algorithm()

    # * super_simplified_system_with_pump()

    characteristic_system()

    relatorio_compartilhamentos()
