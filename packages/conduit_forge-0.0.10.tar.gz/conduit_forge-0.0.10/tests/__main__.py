import conduitforge

"""
This file will be used to run the tests as a package.

I created this file because i had a problem when the mosaic_tests file was runned directly.
"""
