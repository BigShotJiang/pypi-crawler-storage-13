    print(f'\n{p1.component_ports[0].local_current.volume_flow = }\n\n')
