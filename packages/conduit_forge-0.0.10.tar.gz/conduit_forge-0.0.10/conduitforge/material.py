from uuid import UUID, uuid4

import csv
import os

class Material():
    material_objects: list = []

    def __init__(self, code='AISI 304', class_system='AISI'):
        
        self.id = uuid4()
        self.classification_system: str = class_system
        self.code: str = code #this is like a nickname, and will be used to search through all the registered materials
        
        self.rougthnes: None | float = None
        
        base_dir_path = os.path.dirname(__file__)
        file_path = os.path.join(base_dir_path, 'data', 'material_data.csv')

        # csv.QUOTE_NONNUMERIC
        # csv.QUOTE_NOTNULL

        with open(file_path, mode='r', newline='') as csvfile:
            
            reader = csv.DictReader(csvfile)
            for row in reader:
                try:
                    if row[self.classification_system] == self.code:
                        self.rougthnes = float(row['superficial_rougthness'])
                    
                except TypeError:
                    raise TypeError(f'The rougthnes = {self.rougthnes} is not a number ')
                

        if self.rougthnes is None:    
            raise ValueError(f'{self.code} not found in column {self.classification_system}')

       
        Material.material_objects.append(self)

class CustomMaterial(Material):
    def __init__(self, code, class_system):
        """
        This class will be used if the user needs toa create a material that is not inside the ones loaded into the library

        The properties should be set manually.

        (*Opt feature) I could create a method that registers the material created by the user inside the library 'database'
        so that the user doe not need to create the same material every thime he/she wants to use said material.
            The 'custom material' would be registered only inside the users machine

            This feature need to identify and prevent the creation of duplicates
        """

        # This will be the norm used to determinate the code, like AISI, ISO and others. I'll let ISO by standard
        
        self.code = code
        self.classification_system: str = class_system