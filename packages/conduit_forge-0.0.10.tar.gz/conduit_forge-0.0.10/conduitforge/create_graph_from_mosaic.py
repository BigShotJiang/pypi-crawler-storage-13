
from uuid import uuid4, UUID
from typing import List, Union, TypeAlias
from matplotlib.rcsetup import all_backends
import networkx as nx
import matplotlib.pyplot as plt

from colorama import Fore, Back, Style

from . import components
from . import current as current 
from . import solvers as solvers
from .geom_handler import base_geom_objects as bgo
from .errors import OptionalFeature, ConduitForgeError

"""
This file will store the rework version of the create_graph method untill it's complete.
"""

def create_graph(self) -> None:
        """
        This method is the one responsible for creating the direct graph that represents the Components connections
        between each other inside the Mosaic.
        """

        self.graph = nx.DiGraph()

        for some_comp in components.Component.component_objects:
            if some_comp.location == self.id:
                for some_port in some_comp.component_ports:

                    back_color = Back.YELLOW
                    self.graph.add_node(some_port.id, pos = some_port.spacial_position.coords)
                    print(f'\n\n{Fore.BLACK + back_color}\n{some_port.id = }\n{some_port.spacial_position = }{Style.RESET_ALL}')

            elif some_comp.location != self.id:
                pass

            else:
                raise TypeError
        """    
        for joint in self.joints_list:
            for obj_index, obj in enumerate(joint):
                for port in components.Port.port_objects:
                    if port.id == obj:
                        #self.graph.add_node(port.id, pos = port.spacial_coordinates)

                        for component in components.Component.component_objects:
                            if port.location == component.id:
                                for comp_port in component.component_ports:

                                    back_color = Back.YELLOW
 
                                    self.graph.add_node(comp_port.id, pos = port.spacial_position.coords)

                                    print(f'\n\n{Fore.BLACK + back_color}\n{port.id = }\n{port.spacial_position = }{Style.RESET_ALL}')
                                   
                        # for component in components.Component,component_objects:
                        #     if component.id == port.location:
                        #         if all(components.Port.is_generic_port(comp_port) == False for comp_port in component.component_ports):
                        #             for component_port in component:
                        #                 self.graph.add_node(component_port.id, )
                    else:
                        pass

        """       

        """
        The next step is to check to what compnent each point belongs. After this checking, if the components are pipes,
        the two nodes will be used to create an edge.
        """
        nodes_list = list(self.graph.nodes()) #//data = True

        edges = []

        for comp in components.Component.component_objects:
            if comp.location == self.id:
                #This part means that all the components that have the self mosaic as their location, will be used
                #to create the edges of the graph

                component_ports[0]_node = comp.component_ports[0].spacial_position.id

                for port in comp.component_ports:
                    if ((comp.component_ports[0].spacial_position != None) \
                        and (port.id != comp.component_ports[0].spacial_position) \
                        and (self.graph.has_edge(port.id, comp.component_ports[0].spacial_position))\
                        and (comp.component_ports[0].spacial_position in self.graph.nodes)):

                        #Se o nó tiver o mesmo uuid que o ponto raiz, esse nó vai ser chamado de nó raiz

                        

                        edges.append((component_ports[0]_node, port_node))

                    elif ((comp.component_ports[0].spacial_position.has_none_coord() == True) and (comp.component_ports[0] == None)):
                        raise ValueError
                    
                    elif((comp.component_ports[0].spacial_position.has_none_coord() == False)):
                        raise ValueError
                    
                    else:
                        raise TypeError(f'The comp.component_ports[0].spacial_position.has_none_coord should be a bool!')

        #// from this part on, is the oldder method     

        for joint in self.joints_list:
            for obj, obj_index in enumerate(joint):
                
                #edges = [] #*: List
                for some_comp in components.Component.component_objects:
                    for some_comp_port in some_comp.component_ports:

                        component_ports[0]: components.Port | None = None
                        #some_comp_port_node

                        #* This part finds the root point of some component 
                        if component_ports[0] == None:

                            for some_port in components.Port.port_objects:
                                #The error fix in this part was solved by just changing from come_comp_port
                                # to some_comp, in the right side of the if statement

                                #! The error is inside this part, because the parameter for comparaion of two ports can't
                                #! be the coordinates, but it must be the id
                                if some_port.spacial_position.coords == some_comp.component_ports[0].spacial_position.coords:
                                    component_ports[0] = some_port

                        elif component_ports[0] != None:
                            pass

                        else:
                            raise ValueError
                        
                        #* This part finds the nodes inside a component, and creates the edges inside the graph
                        for node in nodes_list:
                            for port in components.Port.port_objects:
                                if port.id == node:

                                    # I dont know if i can change from node.pos to port.spacial_position.coords, on the line below

                                    if port.spacial_position.coords == some_comp_port.spacial_position.coords:
                            
                                        some_comp_port_node = node

                                        for some_node in nodes_list:
                                            for single_port in components.Port.port_objects:
                                                if single_port.id == some_node:
                                                    if single_port.spacial_position.coords == component_ports[0].spacial_position.coords:
                                                        
                                                        component_ports[0]_node = some_node
                                                        edges.append((component_ports[0]_node, some_comp_port_node))
                                    
                                    else:
                                        pass

                                    