from dataclasses import dataclass

"""
* THis is an optional feature, and i will just make this part after all the mandatory features are up and running


This folder will be used to create personalized errors for this library


"""



#This is a dummy i took from the Pint Library, but i still need to learn more until i create my own error classes
class ConduitForgeError(Exception):
    "This is the base class for all the Conduit Forge errors"
    pass

class MassConservationError(ConduitForgeError):
    """This error is raised when the mass conservation from the mosaic shows an internal error, or when
    the numerical Newton-Raphson method does not converge"""
    def __init__(self, message="Mass Conservation Error"):
        self.message = message
        super().__init__(self.message)

class ConvergenceError(MassConservationError):
    """This error is raised when the numerical Newton-Raphson method does not converge"""
    def __init__(self, message="The Mass Equations given does not converge!"):
        self.message = message
        super().__init__(self.message)

class ObjectNotFound(ConduitForgeError):
    def __init__(self, message="Object not found!"):
        self.message = message
        super().__init__(self.message)

class OptionalFeature(ConduitForgeError):
    def __init__(self, message="This is an Optional feature, and it is not implemented, but maybe some day it will be"):
        self.message = message
        super().__init__(self.message)




"""
This is a dummy i took from the Pint Library, but i still need to learn more until i create my own error classes

@dataclass(frozen=False)
class EmptyCurrent(ValueError, ConduitForgeError):
    \"\"\"Raised when a Current object is None\"\"\"

    name: str
    definition_type: type
    msg: str

    def __str__(self):
        msg = f"The current from the prt'{self.name}' ({self.definition_type}): {self.msg}"
        return msg

    def __reduce__(self):
        return self.__class__, tuple(getattr(self, f.name) for f in fields(self))
        
"""