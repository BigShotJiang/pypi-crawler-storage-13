"""Some introductory text goes here, but i had no idea what to write"""

__version__ = "0.0.10"

# from conduitforge import errors
# from conduitforge import data
# from conduitforge.geom_handler import bgo
# from conduitforge import components
# from conduitforge import current
# from conduitforge import mosaic
# from conduitforge import pump

from .errors import (
    ConduitForgeError,
    MassConservationError,
    ConvergenceError,
    ObjectNotFound,
    OptionalFeature,
)

from .components import (
    Port,
    Pipe,
    T_connector,
    Elbow180DegFlanged,
    Elbow90DegSmoothFlanged,
    Elbow90DegChanferFlanged,
    Elbow45DegThreaded,
    Straight_Fitting,
)

from .current import Current
from .mosaic import Mosaic
from .pump import Pump

__all__ = [
    "ConduitForgeError",
    "MassConservationError",
    "ConvergenceError",
    "ObjectNotFound",
    "OptionalFeature",
    "Port",
    "Pipe",
    "T_connector",
    "Elbow180DegFalnged",
    "Elbow90DegSmoothFlanged",
    "Elbow90DegChanferFlanged",
    "Elbow45DegThreaded",
    "Straight_Fitting",
    "Current",
    "Mosaic",
    "Pump",
]
