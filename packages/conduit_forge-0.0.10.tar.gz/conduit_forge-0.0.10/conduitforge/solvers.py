from . import components
from . import  current

import sympy as sy

"""
    if absolute_viscosity == None and kinematic_viscosity == None:
        #this part is used when the user needs to calculate thee absolute viscosity just from the reynolds equation
        absolute_viscosity = sy.solve(Re.subs(values), absolute_viscosity)

    if absolute_viscosity == None and kinematic_viscosity != None and rho_fluid != None:
        print(f'\ndentro do if da eq da viscosidade absoluta')
        absolute_viscosity = sy.solve(k_viscosity.subs(values), absolute_viscosity)

    if kinematic_viscosity == None and absolute_viscosity != None and rho_fluid != None:
        print(f'\ndentro do if da eq da viscosidade cinematica')
        kinematic_viscosity = sy.solve(k_viscosity.subs(values), kinematic_viscosity)
    
    print(f'\nAqui começa a parte depois dos if\'s da viscosidade')
    if reynolds_number == None and rho_fluid != None and characteristic_length != None and absolute_viscosity != None and velocity != None:
        reynolds = sy.solve(Re.subs(values),reynolds_number)
        return reynolds
    
    if rho_fluid == None and reynolds_number != None and characteristic_length != None and absolute_viscosity != None and velocity != None:
        rho = sy.solve(Re.subs(values),rho_fluid)
        return rho
    
    if characteristic_length == None and rho_fluid != None and reynolds_number != None and absolute_viscosity != None and velocity != None:
        length = sy.solve(Re.subs(values),characteristic_length)
        return length
    
    print(f'\n Depois desse pedaço começa o if para calcular a viscosidade absoluta')
    if absolute_viscosity == None and rho_fluid != None and characteristic_length != None and reynolds_number != None and velocity != None:
        print(f'\nEssa parte ja pe dentro do if da viscosidade absoluta')
        abs_viscosity = sy.solve(Re.subs(values),k_viscosity)
        return abs_viscosity
    
    if velocity == None and rho_fluid != None and characteristic_length != None and absolute_viscosity != None and reynolds_number != None:
        local_velocity = sy.solve(Re.subs(values),velocity)
        return local_velocity
    """
    

def darcy_friction_factor():
    """

    TODO : [High]
    This function will be used in the calculation of the Darcy's frction factor, 'f', also known in portuguese as 'fator
    de atrito'.

    In the fluid mechanics book from Çengel, there is a listing of a funtion that is more accurate in the calulation of
    the friction factor that the Colebrook correlation. This function thou, only can be used in some intervals of the 
    reynolds number and the rougthness of the inner pipe surface.

    My idea is to build this function so that whenever the reynolds number and the rougthness are in the determined
    interval, it used the more accurate funtion to calculate the friction factor instead of the Colebrook correlation.

    The problem is that i don't know if this alternation between both correlations could generate some error for the user
    or make the calculation unstable and unprevisible.
    """
    pass