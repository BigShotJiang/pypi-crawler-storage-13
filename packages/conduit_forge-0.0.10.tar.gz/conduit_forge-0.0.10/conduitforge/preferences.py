
"""
This folder will store the user preferences, such as measurement unities, like length, mass, energy, power and etc.

This folder will also store the user preferences for decimal places on the rounding of some numbers, like length, time,
mass flow and etc.

This folder will contain a class that can only have one instance, and said instance will store those preferences

This instance will also store the default preferences
"""

class Preferences:
    def __init__(self) -> None:
        self.rounding: int = 2
        self.measurement_system: str = 'SI'

        self.length_unity: str
        self.time_unity: str
        self.mass_unity: str
        self.temperature_unity: str
        self.quantity_of_matter: str

        self.measurement_systems: dict ={
            'SI' : ['m',
                    ['s', 'min', 'hour', 'day', 'week', 'month', 'year'],
                    'kg',
                    'K',
                    'mol'],
            'Imperial': [['in', 'ft', 'yd', 'mi'],
                         [['s', 'min', 'hour', 'day', 'week', 'month', 'year']],
                         ['oz', 'pd'],
                         [],
                         []]
        }

        self.gravity = 9.81 #* m/(s^2)
        ...