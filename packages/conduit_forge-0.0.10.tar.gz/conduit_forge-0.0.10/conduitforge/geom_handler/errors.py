

class BaseGeomModuleError(Exception):
    "This is the base class for all the Base Geometry Module Error errors"
    pass

class OperationNotAllowedError(BaseGeomModuleError):
    """This error is raised when the mass conservation from the mosaic shows an internal error, or when
    the numerical Newton-Raphson method does not converge"""
    def __init__(self, message="This opperation can not be made with those objects"):
        self.message = message
        super().__init__(self.message)