"""
The data file stores all the data folders and modules used by this library

    The material_data.csv stores some common codes (like ISO and AISI standards) for each pipe material.
    The material_data.csv can also recieve custom materials from the user, but those materials i'll only exist inside the
    users machine, for convenience, so that the user does not have to declare the same material when he/she uses the
    library.

    -> The surface rougthness inside the CSV material_data file is measured in milimeters
    The source of the data contained inside the material_data.csv is:

    <links here>

    The pump_data file will store some common pumps data. 
    The pump_data can also recieve custom pumps from the user, but those pumps i'll only exist inside the
    users machine, for convenience, so that the user does not have to declare the same pump when he/she uses the
    library.
    The source of the data contained inside the material_data.csv is:

    <links here>

The materiaql_data.csv file shoudn't have any quotes or double quotes around its column names or vales, so that the code
works

    
"""