import thermo as thermo

"""
This file stores all of the common constants that are used or may be used inside this library.

"""

g: float = 9.81  # gravity acceleration at sea level, measured in m/s^2
manometric_atm_pressure: float | int = (
    0  # Pa , this is the manometric atmosferic pressure
)
absolute_atm_pressure: float | int = (
    101325  # Pa , this is the manometric atmosferic pressure
)

pure_water = thermo.Chemical("water", T=298.15, P=absolute_atm_pressure)

# numerical_tolerance for the difference in the calculations made inside the library (1*(10**-6))
n_tol = 0.000001
