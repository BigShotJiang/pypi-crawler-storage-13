# FraQ NetTrade Python Abstractions

SDK for developing trading strategies in Python for the FraQ NetTrade platform.

## Installation

```bash
pip install fraq-nettrade-abstractions
```

## Quick Start

```python
from fraq_nettrade_abstractions import Strategy

class MyStrategy(Strategy):
    def on_start(self, context):
        """Initialize your strategy"""
        self.sma_fast = context['indicators'].sma(period=10)
        self.sma_slow = context['indicators'].sma(period=20)
    
    def on_bar(self, symbol, index):
        """Trading logic - called on each bar"""
        if self.sma_fast[index] > self.sma_slow[index]:
            return {'action': 'buy', 'volume': 1.0}
        elif self.sma_fast[index] < self.sma_slow[index]:
            return {'action': 'sell', 'volume': 1.0}
        return None
```

## Running Your Strategy

1. Save your strategy to a `.py` file
2. Open FraQ application
3. Load your Python strategy file
4. Run backtest

## Debugging

```python
from fraq_nettrade_abstractions import Strategy, enable_debugger

class MyStrategy(Strategy):
    def on_start(self, context):
        enable_debugger()  # Wait for VS Code debugger
        # Your strategy code with breakpoints
```

**Debug workflow:**

1. Start FraQ with `--debug` flag
2. Attach VS Code to port 5678
3. Set breakpoints in your strategy
4. Press Enter in FraQ console

## API Reference

### Strategy Class

Base class for all trading strategies.

**Methods to implement:**

- `on_start(context)` - Called once when backtest starts
- `on_bar(symbol, index)` - Called on each bar (required)
- `on_tick(symbol)` - Called on each tick (optional)
- `on_stop()` - Called when backtest ends (optional)

### Context Object

Passed to `on_start()`:

```python
{
    'account': {
        'balance': float,
        'equity': float,
        'margin_used': float,
        'margin_available': float
    },
    'symbols': [
        {
            'name': str,
            'bid': float,
            'ask': float,
        }
    ],
    'indicators': IndicatorFactory
}
```

### Symbol Object

Passed to `on_bar()` and `on_tick()`:

```python
{
    'name': 'EURUSD',
    'bid': 1.0850,
    'ask': 1.0852,
    'spread': 0.0002,
    'close': 1.0851,
    'bars': [
        {
            'open': 1.0840,
            'high': 1.0855,
            'low': 1.0835,
            'close': 1.0850,
            'volume': 1000.0,
            'time': '2024-01-01T00:00:00'
        }
    ]
}
```

### Trade Signals

Return from `on_bar()` or `on_tick()`:

```python
# Buy signal
{'action': 'buy', 'volume': 1.0}

# Sell signal
{'action': 'sell', 'volume': 1.0}

# Close all positions
{'action': 'close', 'volume': 0}

# No action
None
```

## Built-in Indicators

Access via `context['indicators']` in `on_start()`:

- `sma(period)` - Simple Moving Average
- `ema(period)` - Exponential Moving Average
- `rsi(period)` - Relative Strength Index
- `macd(fast, slow, signal)` - MACD
- `bollinger(period, stddev)` - Bollinger Bands

## Examples

See the [examples directory](https://github.com/FraQLabs/FraQ-NetTrade/tree/master/examples) for complete strategy examples.

## License

MIT License - see LICENSE file for details

## Support

- GitHub: https://github.com/FraQLabs/FraQ-NetTrade
- Issues: https://github.com/FraQLabs/FraQ-NetTrade/issues
