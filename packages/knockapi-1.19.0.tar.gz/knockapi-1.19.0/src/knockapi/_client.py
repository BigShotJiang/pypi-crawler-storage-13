# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, Mapping
from typing_extensions import Self, override

import httpx

from . import _exceptions
from ._qs import Querystring
from ._types import (
    Omit,
    Timeout,
    NotGiven,
    Transport,
    ProxiesTypes,
    RequestOptions,
    not_given,
)
from ._utils import is_given, get_async_library
from ._version import __version__
from .resources import audiences, workflows, bulk_operations
from ._streaming import Stream as Stream, AsyncStream as AsyncStream
from ._exceptions import KnockError, APIStatusError
from ._base_client import (
    DEFAULT_MAX_RETRIES,
    SyncAPIClient,
    AsyncAPIClient,
)
from .resources.users import users
from .resources.objects import objects
from .resources.tenants import tenants
from .resources.channels import channels
from .resources.messages import messages
from .resources.providers import providers
from .resources.schedules import schedules
from .resources.integrations import integrations

__all__ = ["Timeout", "Transport", "ProxiesTypes", "RequestOptions", "Knock", "AsyncKnock", "Client", "AsyncClient"]


class Knock(SyncAPIClient):
    users: users.UsersResource
    objects: objects.ObjectsResource
    tenants: tenants.TenantsResource
    bulk_operations: bulk_operations.BulkOperationsResource
    messages: messages.MessagesResource
    providers: providers.ProvidersResource
    integrations: integrations.IntegrationsResource
    workflows: workflows.WorkflowsResource
    schedules: schedules.SchedulesResource
    channels: channels.ChannelsResource
    audiences: audiences.AudiencesResource
    with_raw_response: KnockWithRawResponse
    with_streaming_response: KnockWithStreamedResponse

    # client options
    api_key: str
    branch: str | None

    def __init__(
        self,
        *,
        api_key: str | None = None,
        branch: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#client) for more details.
        http_client: httpx.Client | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new synchronous Knock client instance.

        This automatically infers the following arguments from their corresponding environment variables if they are not provided:
        - `api_key` from `KNOCK_API_KEY`
        - `branch` from `KNOCK_BRANCH`
        """
        if api_key is None:
            api_key = os.environ.get("KNOCK_API_KEY")
        if api_key is None:
            raise KnockError(
                "The api_key client option must be set either by passing api_key to the client or by setting the KNOCK_API_KEY environment variable"
            )
        self.api_key = api_key

        if branch is None:
            branch = os.environ.get("KNOCK_BRANCH")
        self.branch = branch

        if base_url is None:
            base_url = os.environ.get("KNOCK_BASE_URL")
        if base_url is None:
            base_url = f"https://api.knock.app"

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

        self._idempotency_header = "Idempotency-Key"

        self.users = users.UsersResource(self)
        self.objects = objects.ObjectsResource(self)
        self.tenants = tenants.TenantsResource(self)
        self.bulk_operations = bulk_operations.BulkOperationsResource(self)
        self.messages = messages.MessagesResource(self)
        self.providers = providers.ProvidersResource(self)
        self.integrations = integrations.IntegrationsResource(self)
        self.workflows = workflows.WorkflowsResource(self)
        self.schedules = schedules.SchedulesResource(self)
        self.channels = channels.ChannelsResource(self)
        self.audiences = audiences.AudiencesResource(self)
        self.with_raw_response = KnockWithRawResponse(self)
        self.with_streaming_response = KnockWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="brackets")

    @property
    @override
    def auth_headers(self) -> dict[str, str]:
        api_key = self.api_key
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": "false",
            "X-Knock-Branch": self.branch if self.branch is not None else Omit(),
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        branch: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.Client | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            branch=branch or self.branch,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class AsyncKnock(AsyncAPIClient):
    users: users.AsyncUsersResource
    objects: objects.AsyncObjectsResource
    tenants: tenants.AsyncTenantsResource
    bulk_operations: bulk_operations.AsyncBulkOperationsResource
    messages: messages.AsyncMessagesResource
    providers: providers.AsyncProvidersResource
    integrations: integrations.AsyncIntegrationsResource
    workflows: workflows.AsyncWorkflowsResource
    schedules: schedules.AsyncSchedulesResource
    channels: channels.AsyncChannelsResource
    audiences: audiences.AsyncAudiencesResource
    with_raw_response: AsyncKnockWithRawResponse
    with_streaming_response: AsyncKnockWithStreamedResponse

    # client options
    api_key: str
    branch: str | None

    def __init__(
        self,
        *,
        api_key: str | None = None,
        branch: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultAsyncHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#asyncclient) for more details.
        http_client: httpx.AsyncClient | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new async AsyncKnock client instance.

        This automatically infers the following arguments from their corresponding environment variables if they are not provided:
        - `api_key` from `KNOCK_API_KEY`
        - `branch` from `KNOCK_BRANCH`
        """
        if api_key is None:
            api_key = os.environ.get("KNOCK_API_KEY")
        if api_key is None:
            raise KnockError(
                "The api_key client option must be set either by passing api_key to the client or by setting the KNOCK_API_KEY environment variable"
            )
        self.api_key = api_key

        if branch is None:
            branch = os.environ.get("KNOCK_BRANCH")
        self.branch = branch

        if base_url is None:
            base_url = os.environ.get("KNOCK_BASE_URL")
        if base_url is None:
            base_url = f"https://api.knock.app"

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

        self._idempotency_header = "Idempotency-Key"

        self.users = users.AsyncUsersResource(self)
        self.objects = objects.AsyncObjectsResource(self)
        self.tenants = tenants.AsyncTenantsResource(self)
        self.bulk_operations = bulk_operations.AsyncBulkOperationsResource(self)
        self.messages = messages.AsyncMessagesResource(self)
        self.providers = providers.AsyncProvidersResource(self)
        self.integrations = integrations.AsyncIntegrationsResource(self)
        self.workflows = workflows.AsyncWorkflowsResource(self)
        self.schedules = schedules.AsyncSchedulesResource(self)
        self.channels = channels.AsyncChannelsResource(self)
        self.audiences = audiences.AsyncAudiencesResource(self)
        self.with_raw_response = AsyncKnockWithRawResponse(self)
        self.with_streaming_response = AsyncKnockWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="brackets")

    @property
    @override
    def auth_headers(self) -> dict[str, str]:
        api_key = self.api_key
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": f"async:{get_async_library()}",
            "X-Knock-Branch": self.branch if self.branch is not None else Omit(),
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        branch: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            branch=branch or self.branch,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class KnockWithRawResponse:
    def __init__(self, client: Knock) -> None:
        self.users = users.UsersResourceWithRawResponse(client.users)
        self.objects = objects.ObjectsResourceWithRawResponse(client.objects)
        self.tenants = tenants.TenantsResourceWithRawResponse(client.tenants)
        self.bulk_operations = bulk_operations.BulkOperationsResourceWithRawResponse(client.bulk_operations)
        self.messages = messages.MessagesResourceWithRawResponse(client.messages)
        self.providers = providers.ProvidersResourceWithRawResponse(client.providers)
        self.integrations = integrations.IntegrationsResourceWithRawResponse(client.integrations)
        self.workflows = workflows.WorkflowsResourceWithRawResponse(client.workflows)
        self.schedules = schedules.SchedulesResourceWithRawResponse(client.schedules)
        self.channels = channels.ChannelsResourceWithRawResponse(client.channels)
        self.audiences = audiences.AudiencesResourceWithRawResponse(client.audiences)


class AsyncKnockWithRawResponse:
    def __init__(self, client: AsyncKnock) -> None:
        self.users = users.AsyncUsersResourceWithRawResponse(client.users)
        self.objects = objects.AsyncObjectsResourceWithRawResponse(client.objects)
        self.tenants = tenants.AsyncTenantsResourceWithRawResponse(client.tenants)
        self.bulk_operations = bulk_operations.AsyncBulkOperationsResourceWithRawResponse(client.bulk_operations)
        self.messages = messages.AsyncMessagesResourceWithRawResponse(client.messages)
        self.providers = providers.AsyncProvidersResourceWithRawResponse(client.providers)
        self.integrations = integrations.AsyncIntegrationsResourceWithRawResponse(client.integrations)
        self.workflows = workflows.AsyncWorkflowsResourceWithRawResponse(client.workflows)
        self.schedules = schedules.AsyncSchedulesResourceWithRawResponse(client.schedules)
        self.channels = channels.AsyncChannelsResourceWithRawResponse(client.channels)
        self.audiences = audiences.AsyncAudiencesResourceWithRawResponse(client.audiences)


class KnockWithStreamedResponse:
    def __init__(self, client: Knock) -> None:
        self.users = users.UsersResourceWithStreamingResponse(client.users)
        self.objects = objects.ObjectsResourceWithStreamingResponse(client.objects)
        self.tenants = tenants.TenantsResourceWithStreamingResponse(client.tenants)
        self.bulk_operations = bulk_operations.BulkOperationsResourceWithStreamingResponse(client.bulk_operations)
        self.messages = messages.MessagesResourceWithStreamingResponse(client.messages)
        self.providers = providers.ProvidersResourceWithStreamingResponse(client.providers)
        self.integrations = integrations.IntegrationsResourceWithStreamingResponse(client.integrations)
        self.workflows = workflows.WorkflowsResourceWithStreamingResponse(client.workflows)
        self.schedules = schedules.SchedulesResourceWithStreamingResponse(client.schedules)
        self.channels = channels.ChannelsResourceWithStreamingResponse(client.channels)
        self.audiences = audiences.AudiencesResourceWithStreamingResponse(client.audiences)


class AsyncKnockWithStreamedResponse:
    def __init__(self, client: AsyncKnock) -> None:
        self.users = users.AsyncUsersResourceWithStreamingResponse(client.users)
        self.objects = objects.AsyncObjectsResourceWithStreamingResponse(client.objects)
        self.tenants = tenants.AsyncTenantsResourceWithStreamingResponse(client.tenants)
        self.bulk_operations = bulk_operations.AsyncBulkOperationsResourceWithStreamingResponse(client.bulk_operations)
        self.messages = messages.AsyncMessagesResourceWithStreamingResponse(client.messages)
        self.providers = providers.AsyncProvidersResourceWithStreamingResponse(client.providers)
        self.integrations = integrations.AsyncIntegrationsResourceWithStreamingResponse(client.integrations)
        self.workflows = workflows.AsyncWorkflowsResourceWithStreamingResponse(client.workflows)
        self.schedules = schedules.AsyncSchedulesResourceWithStreamingResponse(client.schedules)
        self.channels = channels.AsyncChannelsResourceWithStreamingResponse(client.channels)
        self.audiences = audiences.AsyncAudiencesResourceWithStreamingResponse(client.audiences)


Client = Knock

AsyncClient = AsyncKnock
