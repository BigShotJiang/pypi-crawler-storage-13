
IScrypto

This package contains Python translations of several classic encryption algorithms,
originally provided as C source files. The goal was to keep the logic identical to the C code,
while making the modules easy to import and test in Python.

Modules included:
- caesar
- diffie (Diffie-Hellman)
- rsa_basic (simple RSA example)
- new_rsa (alternate RSA)
- playfair
- rail_fence
- columnar (columnar transposition)
- vigenere
- hill_cipher

Build and install locally:
1. python -m venv .venv
2. source .venv/bin/activate   # Linux/macOS  (use the appropriate activation command on Windows)
3. pip install build
4. python -m build
5. pip install dist/IScrypto-0.1.0-py3-none-any.whl
