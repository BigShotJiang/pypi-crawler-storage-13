
"""Playfair cipher - translation from playfair_cipher.c."""

matrix = [['' for _ in range(5)] for __ in range(5)]

def create_matrix(keyword: str):
    used = [False]*26
    k = 0
    for ch in keyword.upper():
        if ch == 'J':
            ch = 'I'
        if 'A' <= ch <= 'Z' and not used[ord(ch)-65]:
            used[ord(ch)-65] = True
            matrix[k//5][k%5] = ch
            k += 1
    for code in range(ord('A'), ord('Z')+1):
        ch = chr(code)
        if ch == 'J':
            continue
        if not used[code-65]:
            used[code-65] = True
            matrix[k//5][k%5] = ch
            k += 1

def print_matrix():
    for r in matrix:
        print(' '.join(r))

def encrypt_message(message: str, keyword: str):
    create_matrix(keyword)
    prepared = []
    i = 0
    n = len(message)
    while i < n:
        ch1 = message[i].upper()
        if ch1 == 'J':
            ch1 = 'I'
        if not ('A' <= ch1 <= 'Z'):
            i += 1
            continue
        j = i+1
        ch2 = ''
        while j < n:
            ch2 = message[j].upper()
            if ch2 == 'J':
                ch2 = 'I'
            if 'A' <= ch2 <= 'Z':
                break
            j += 1
        if j < n and ch1 == ch2:
            prepared.append(ch1)
            prepared.append('X')
            i += 1
        elif j < n:
            prepared.append(ch1)
            prepared.append(ch2)
            i = j+1
        else:
            prepared.append(ch1)
            prepared.append('X')
            print('used bogus character X.')
            break
    prepared = ''.join(prepared)
    out = []
    for i in range(0, len(prepared), 2):
        a = prepared[i]
        b = prepared[i+1]
        row1 = col1 = row2 = col2 = None
        for r in range(5):
            for c in range(5):
                if matrix[r][c] == a:
                    row1, col1 = r, c
                if matrix[r][c] == b:
                    row2, col2 = r, c
        if row1 == row2:
            out.append(matrix[row1][(col1+1)%5])
            out.append(matrix[row2][(col2+1)%5])
        elif col1 == col2:
            out.append(matrix[(row1+1)%5][col1])
            out.append(matrix[(row2+1)%5][col2])
        else:
            out.append(matrix[row1][col2])
            out.append(matrix[row2][col1])
    return prepared, ''.join(out)

def decrypt_message(ciphertext: str, keyword: str):
    create_matrix(keyword)
    out = []
    for i in range(0, len(ciphertext), 2):
        a = ciphertext[i]
        b = ciphertext[i+1]
        row1 = col1 = row2 = col2 = None
        for r in range(5):
            for c in range(5):
                if matrix[r][c] == a:
                    row1, col1 = r, c
                if matrix[r][c] == b:
                    row2, col2 = r, c
        if row1 == row2:
            out.append(matrix[row1][(col1-1)%5])
            out.append(matrix[row2][(col2-1)%5])
        elif col1 == col2:
            out.append(matrix[(row1-1)%5][col1])
            out.append(matrix[(row2-1)%5][col2])
        else:
            out.append(matrix[row1][col2])
            out.append(matrix[row2][col1])
    return ''.join(out)
