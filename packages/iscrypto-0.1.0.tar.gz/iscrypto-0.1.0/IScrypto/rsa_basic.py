
"""Simple RSA example translating rsa.c logic."""

def gcd(a: int, b: int) -> int:
    while b != 0:
        a, b = b, a % b
    return a

def power_mod(a: int, n: int, m: int) -> int:
    ans = 1 % m
    for _ in range(n):
        ans = (ans * a) % m
    return ans

def generate_keys(p: int, q: int):
    n = p * q
    phi = (p - 1) * (q - 1)
    e = -1
    for i in range(2, n):
        if i != p and i != q and gcd(phi, i) == 1:
            e = i
            break
    if e == -1:
        raise ValueError("Couldn't find a valid e.")
    d = -1
    for i in range(2, phi):
        if (e * i) % phi == 1:
            d = i
            break
    if d == -1:
        raise ValueError("Inverse does not exist")
    return (n, e), (n, d)

def encrypt(M: int, pub: tuple) -> int:
    n, e = pub
    return power_mod(M, e, n) % n

def decrypt(C: int, priv: tuple) -> int:
    n, d = priv
    return power_mod(C, d, n) % n
