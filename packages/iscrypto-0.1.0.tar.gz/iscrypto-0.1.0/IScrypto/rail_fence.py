
"""Rail Fence cipher translation from rail_fence.c."""

def remove_spaces(s: str) -> str:
    return ''.join(ch for ch in s if ch != ' ')

def encrypt(text: str, key: int) -> str:
    n = len(text)
    rail = [['\n'] * n for _ in range(key)]
    row = 0
    col = 0
    dir_down = True
    for i in range(n):
        if row == 0:
            dir_down = True
        if row == key - 1:
            dir_down = False
        rail[row][col] = text[i]
        col += 1
        if dir_down:
            row += 1
        else:
            row -= 1
    out = []
    for i in range(key):
        for j in range(n):
            if rail[i][j] != '\n':
                out.append(rail[i][j])
    return ''.join(out)

def decrypt(cipher: str, key: int) -> str:
    n = len(cipher)
    rail = [['\n'] * n for _ in range(key)]
    row = 0
    col = 0
    dir_down = True
    for i in range(n):
        if row == 0:
            dir_down = True
        if row == key - 1:
            dir_down = False
        rail[row][col] = '*'
        col += 1
        if dir_down:
            row += 1
        else:
            row -= 1
    index = 0
    for i in range(key):
        for j in range(n):
            if rail[i][j] == '*' and index < n:
                rail[i][j] = cipher[index]
                index += 1
    row = 0
    col = 0
    dir_down = True
    out = []
    for i in range(n):
        if row == 0:
            dir_down = True
        if row == key - 1:
            dir_down = False
        if rail[row][col] != '\n':
            out.append(rail[row][col])
            col += 1
        if dir_down:
            row += 1
        else:
            row -= 1
    return ''.join(out)
