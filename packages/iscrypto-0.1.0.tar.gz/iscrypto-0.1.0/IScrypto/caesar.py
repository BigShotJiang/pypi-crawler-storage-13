
"""Caesar cipher module - faithful to the original C program main.c."""

def caesar_encrypt_text(text: str, shift: int = 3) -> str:
    result = []
    for ch in text:
        b = ord(ch)
        c = b + shift
        if ('a' <= ch <= 'z') or ('A' <= ch <= 'Z'):
            if ('a' <= ch <= 'z' and c > ord('z')) or ('A' <= ch <= 'Z' and c > ord('Z')):
                c -= 26
            result.append(chr(c))
        else:
            result.append(ch)
    return ''.join(result)

def caesar_decrypt_text(text: str, shift: int = 3) -> str:
    return caesar_encrypt_text(text, -shift)

def encrypt_file(infile: str = 'plain.txt', outfile: str = 'cipher.txt', shift: int = 3):
    with open(infile, 'r', encoding='utf-8') as f:
        buffer = f.read()
    enc = caesar_encrypt_text(buffer, shift=shift)
    with open(outfile, 'w', encoding='utf-8') as f:
        f.write(enc)

def decrypt_file(infile: str = 'cipher.txt', outfile: str = 'decrypted.txt', shift: int = 3):
    with open(infile, 'r', encoding='utf-8') as f:
        buffer = f.read()
    dec = caesar_decrypt_text(buffer, shift=shift)
    with open(outfile, 'w', encoding='utf-8') as f:
        f.write(dec)
