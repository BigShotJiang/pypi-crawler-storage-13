
"""Hill cipher translation from hill_cipher.c for 3x3 key matrices"""

def get_key_matrix(key: str):
    keyMatrix = [[0]*3 for _ in range(3)]
    k = 0
    for i in range(3):
        for j in range(3):
            keyMatrix[i][j] = (ord(key[k])) % 65
            k += 1
    return keyMatrix

def encrypt_matrix(cipherMatrix, keyMatrix, messageVector):
    for i in range(3):
        cipherMatrix[i][0] = 0
        for x in range(3):
            cipherMatrix[i][0] += keyMatrix[i][x] * messageVector[x][0]
        cipherMatrix[i][0] = cipherMatrix[i][0] % 26

def decrypt_matrix(cipherMatrix, keyMatrix, messageVector):
    for i in range(3):
        messageVector[i][0] = 0
        for x in range(3):
            messageVector[i][0] += keyMatrix[i][x] * cipherMatrix[x][0]
        messageVector[i][0] = messageVector[i][0] % 26

def determinant(matrix):
    det = (matrix[0][0]*(matrix[1][1]*matrix[2][2] - matrix[1][2]*matrix[2][1])
           - matrix[0][1]*(matrix[1][0]*matrix[2][2] - matrix[1][2]*matrix[2][0])
           + matrix[0][2]*(matrix[1][0]*matrix[2][1] - matrix[1][1]*matrix[2][0]))
    return det

def mod_inverse(a, m):
    a = a % m
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return -1

def adjoint(matrix):
    adj = [[0]*3 for _ in range(3)]
    adj[0][0] =  (matrix[1][1]*matrix[2][2] - matrix[1][2]*matrix[2][1])
    adj[0][1] = -(matrix[0][1]*matrix[2][2] - matrix[0][2]*matrix[2][1])
    adj[0][2] =  (matrix[0][1]*matrix[1][2] - matrix[0][2]*matrix[1][1])
    adj[1][0] = -(matrix[1][0]*matrix[2][2] - matrix[1][2]*matrix[2][0])
    adj[1][1] =  (matrix[0][0]*matrix[2][2] - matrix[0][2]*matrix[2][0])
    adj[1][2] = -(matrix[0][0]*matrix[1][2] - matrix[0][2]*matrix[1][0])
    adj[2][0] =  (matrix[1][0]*matrix[2][1] - matrix[1][1]*matrix[2][0])
    adj[2][1] = -(matrix[0][0]*matrix[2][1] - matrix[0][1]*matrix[2][0])
    adj[2][2] =  (matrix[0][0]*matrix[1][1] - matrix[0][1]*matrix[1][0])
    return adj

def inverse_key_matrix(keyMatrix):
    det = determinant(keyMatrix)
    det = (det % 26 + 26) % 26
    invDet = mod_inverse(det, 26)
    if invDet == -1:
        return None
    adj = adjoint(keyMatrix)
    inv = [[0]*3 for _ in range(3)]
    for i in range(3):
        for j in range(3):
            val = adj[i][j] * invDet
            val = (val % 26 + 26) % 26
            inv[i][j] = val
    return inv

def HillCipher(message: str, key: str):
    keyMatrix = get_key_matrix(key)
    messageVector = [[0] for _ in range(3)]
    for i in range(3):
        messageVector[i][0] = (ord(message[i])) % 65
    cipherMatrix = [[0] for _ in range(3)]
    encrypt_matrix(cipherMatrix, keyMatrix, messageVector)
    CipherText = ''.join(chr(cipherMatrix[i][0] + 65) for i in range(3))
    return CipherText

def HillCipherDecrypt(cipher: str, key: str):
    keyMatrix = get_key_matrix(key)
    invKeyMatrix = inverse_key_matrix(keyMatrix)
    if invKeyMatrix is None:
        return None
    cipherVector = [[0] for _ in range(3)]
    for i in range(3):
        cipherVector[i][0] = (ord(cipher[i])) % 65
    messageVector = [[0] for _ in range(3)]
    decrypt_matrix(cipherVector, invKeyMatrix, messageVector)
    PlainText = ''.join(chr(messageVector[i][0] + 65) for i in range(3))
    return PlainText
