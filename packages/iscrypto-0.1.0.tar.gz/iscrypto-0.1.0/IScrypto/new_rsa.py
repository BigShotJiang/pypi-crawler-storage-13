
"""Alternative RSA translation based on new_rsa.c."""

def euler_totient(x: int, y: int) -> int:
    return (x - 1) * (y - 1)

def gcd(a: int, b: int) -> int:
    while b != 0:
        a, b = b, a % b
    return a

def select_e(phi: int) -> int:
    for i in range(2, phi):
        if gcd(i, phi) == 1:
            return i
    return -1

def mod_inverse(e: int, phi: int) -> int:
    a1, a2 = phi, e
    b1, b2 = 0, 1
    while a2 != 0:
        q = a1 // a2
        r = a1 % a2
        b = b1 - q * b2
        a1, a2 = a2, r
        b1, b2 = b2, b
    if a1 != 1:
        return -1
    if b1 < 0:
        b1 += phi
    return b1

def power_mod(base: int, exp: int, mod: int) -> int:
    ans = 1 % mod
    base %= mod
    for _ in range(exp):
        ans = (ans * base) % mod
    return ans

def encrypt(m: int, e: int, n: int) -> int:
    return power_mod(m, e, n)

def decrypt(c: int, d: int, n: int) -> int:
    return power_mod(c, d, n)

def make_keys(p: int, q: int):
    n = p * q
    phi_n = euler_totient(p, q)
    e = select_e(phi_n)
    if e == -1:
        raise ValueError("Could not find valid e.")
    d = mod_inverse(e, phi_n)
    if d == -1:
        raise ValueError("Modular inverse does not exist (gcd != 1)." )
    return (n, e), (n, d)
