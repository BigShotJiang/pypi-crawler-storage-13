
"""Diffie-Hellman key exchange - modular exponentiation implementation."""

def modexp(base: int, exp: int, mod: int) -> int:
    result = 1 % mod
    base %= mod
    while exp > 0:
        if exp & 1:
            result = (result * base) % mod
        exp //= 2
        base = (base * base) % mod
    return result

def diffie_exchange(p: int, g: int, a: int, b: int):
    A = modexp(g, a, p)
    B = modexp(g, b, p)
    sA = modexp(B, a, p)
    sB = modexp(A, b, p)
    return A, B, sA, sB
