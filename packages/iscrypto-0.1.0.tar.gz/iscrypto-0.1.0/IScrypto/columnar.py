
"""Columnar transposition cipher translation from columinar_t.c."""
import math

def get_key_order(key: str):
    key_digits = [int(ch) for ch in key]
    temp = key_digits[:]
    sorted_vals = sorted(temp)
    order = [0]*len(key)
    for i, val in enumerate(sorted_vals):
        for j in range(len(temp)):
            if temp[j] == val and order[j] == 0:
                order[j] = i+1
                break
    return order

def encrypt(text: str, key: str) -> str:
    clean = ''.join(ch for ch in text if not ch.isspace()).upper()
    key_len = len(key)
    text_len = len(clean)
    rows = math.ceil(text_len / key_len)
    matrix = [['X']*key_len for _ in range(rows)]
    idx = 0
    for r in range(rows):
        for c in range(key_len):
            if idx < text_len:
                matrix[r][c] = clean[idx]
                idx += 1
    order = get_key_order(key)
    out = []
    for num in range(1, key_len+1):
        for c in range(key_len):
            if order[c] == num:
                for r in range(rows):
                    out.append(matrix[r][c])
    return ''.join(out)

def decrypt(cipher: str, key: str) -> str:
    key_len = len(key)
    cipher_len = len(cipher)
    rows = math.ceil(cipher_len / key_len)
    matrix = [['']*key_len for _ in range(rows)]
    order = get_key_order(key)
    idx = 0
    for num in range(1, key_len+1):
        for c in range(key_len):
            if order[c] == num:
                for r in range(rows):
                    if idx < cipher_len:
                        matrix[r][c] = cipher[idx]
                        idx += 1
    out = []
    for r in range(rows):
        for c in range(key_len):
            out.append(matrix[r][c])
    return ''.join(out)
