
"""Vigenere cipher translation from vigenere.c."""

def generate_key(s: str, keyword: str) -> str:
    n = len(s)
    k = len(keyword)
    res = []
    j = 0
    for i in range(n):
        if j == k:
            j = 0
        res.append(keyword[j])
        j += 1
    return ''.join(res)

def cipher_text(s: str, key: str) -> str:
    n = len(s)
    out = []
    for i in range(n):
        x = ((ord(s[i].upper()) - ord('A')) + (ord(key[i].upper()) - ord('A'))) % 26 + ord('A')
        out.append(chr(x))
    return ''.join(out)

def original_text(cipher: str, key: str) -> str:
    n = len(cipher)
    out = []
    for i in range(n):
        x = ((ord(cipher[i].upper()) - ord('A')) - (ord(key[i].upper()) - ord('A')) + 26) % 26 + ord('A')
        out.append(chr(x))
    return ''.join(out)
