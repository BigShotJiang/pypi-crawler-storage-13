import typer
import yaml
from .workflow_runner import run_workflow

app = typer.Typer(pretty_exceptions_enable=False)


@app.command()
def run(
    path: str,
    authorization: str | None = typer.Option(
        None, "--auth", help="Authorization header value"
    ),
    operator_id: str | None = typer.Option(
        None, "--operator-id", help="x-operator-id header value"
    ),
    facility_id: str | None = typer.Option(
        None, "--facility-id", help="x-facility-id header value"
    ),
    header: list[str] = typer.Option(
        [], "--header", "-H", help="Header override 'Name:Value' (can be repeated)"
    ),
    body: list[str] = typer.Option(
        [], "--body", "-B", help="Body override 'path.to.key:Value' (can be repeated)"
    ),
):
    """
    Run a workflow YAML file. You can override headers via CLI options.

    Examples:
      flagflow run sample.yaml --auth "Bearer TOKEN" --operator-id 123 --facility-id 456
    """
    overrides = {}
    if authorization:
        overrides["Authorization"] = authorization
    if operator_id:
        overrides["x-operator-id"] = operator_id
    if facility_id:
        overrides["x-facility-id"] = facility_id

    # Parse repeatable --header entries (format: Name: Value)
    for entry in header:
        if ":" in entry:
            name, val = entry.split(":", 1)
            overrides[name.strip()] = val.strip()
        else:
            print(f"Ignoring malformed header override: '{entry}'. Expected 'Name:Value'.")

    # Parse repeatable --body entries (format: path.to.key:Value)
    body_overrides: dict = {}

    def _set_nested(d: dict, keys: list, value):
        cur = d
        for k in keys[:-1]:
            if k not in cur or not isinstance(cur[k], dict):
                cur[k] = {}
            cur = cur[k]
        cur[keys[-1]] = value

    for entry in body:
        if ":" in entry:
            keypath, valstr = entry.split(":", 1)
            keypath = keypath.strip()
            try:
                val = yaml.safe_load(valstr.strip())
            except Exception:
                val = valstr.strip()
            if keypath:
                keys = keypath.split(".")
                _set_nested(body_overrides, keys, val)
        else:
            print(f"Ignoring malformed body override: '{entry}'. Expected 'path.to.key:Value'.")

    run_workflow(path, header_overrides=overrides, body_overrides=body_overrides)


if __name__ == "__main__":
    app()
