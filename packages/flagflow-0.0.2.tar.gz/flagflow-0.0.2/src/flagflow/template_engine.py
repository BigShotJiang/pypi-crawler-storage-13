import httpx
import re 

def do_request(method: str, url: str, json: dict):
    resp = httpx.request(method=method, url=url, json=json, timeout=10)

    print(f"[{method}] {url} → {resp.status_code}")
    if resp.text:
        print(resp.text)

    resp.raise_for_status()

def render_template(template: str, context: dict) -> str:
    def replace(match):
        key = match.group(1).strip()
        return str(context.get(key, match.group(0)))

    return re.sub(r"{{\s*(.*?)\s*}}", replace, template)
