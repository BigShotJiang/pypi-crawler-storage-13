"""Type definitions for LenzyAI SDK."""

from typing import List, Optional, TypedDict
from typing_extensions import Literal


class MessageRole:
    """Message role constants."""
    USER = "USER"
    ASSISTANT = "ASSISTANT"


MessageRoleType = Literal["USER", "ASSISTANT"]


class Message(TypedDict, total=False):
    """
    A single message in a conversation.

    Attributes:
        role: The role of the message sender ("USER" or "ASSISTANT")
        content: The content of the message
        externalId: Optional unique identifier for the message
    """
    role: MessageRoleType
    content: str
    externalId: str
