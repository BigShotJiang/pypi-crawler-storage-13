from setuptools import setup, find_packages

setup(
    name="datacal",
    version="1.1.1.2",  # No "v"
    author="Ankit Yadav",
    author_email="ankit@yadav@example.com",
    description="Basic mathematics operations and string utilities.",
    long_description="This package provides basic arithmetic operations and mathematical functions.",
    long_description_content_type="text/markdown",
    python_requires='>=3.6',
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'datacal=datacal.calculator:main'  # BOTH MUST EXIST
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)