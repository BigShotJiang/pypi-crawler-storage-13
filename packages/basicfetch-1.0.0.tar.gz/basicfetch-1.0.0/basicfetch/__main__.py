#!/usr/bin/env python3
"""
BasicFetch main entry point
Allows running the package with python -m basicfetch
"""

from . import main

if __name__ == "__main__":
    main()
