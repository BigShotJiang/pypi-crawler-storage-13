import os
from typing import List

data = {
    "AIX": {
        "colors": [2, 7],
        "logo": "${c1}        .oys///oyhddddhyo///sy+.\n${c1}      /yo:+hNNNNNNNNNNNNNNNNh+:oy/\n${c1}    :h/:yNNNNNNNNNNNNNNNNNNNNNNy-+h:\n${c1}  `ys.yNNNNNNNNNNNNNNNNNNNNNNNNNNy.ys\n${c1} `h+-mNNNNNNNNNNNNNNNNNNNNNNNNNNNNm-oh\n${c1} h+-NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN.oy\n${c1}/d`mNNNNNNN/::mNNNd::m+:/dNNNo::dNNNd`m:\n${c1}h//NNNNNNN: . .NNNh  mNo  od. -dNNNNN:+y\n${c1}N.sNNNNNN+ -N/ -NNh  mNNd.   sNNNNNNNo-m\n${c1}N.sNNNNNs  +oo  /Nh  mNNs` ` /mNNNNNNo-m\n${c1}h//NNNNh  ossss` +h  md- .hm/ `sNNNNN:+y\n${c1}:d`mNNN+/yNNNNNd//y//h//oNNNNy//sNNNd`m-\n${c1} yo-NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNm.ss\n${c1} `h+-mNNNNNNNNNNNNNNNNNNNNNNNNNNNNm-oy\n${c1}   sy.yNNNNNNNNNNNNNNNNNNNNNNNNNNs.yo\n${c1}    :h+-yNNNNNNNNNNNNNNNNNNNNNNs-oh-\n${c1}      :ys:/yNNNNNNNNNNNNNNNmy/:sy:\n${c1}        .+ys///osyhhhhys+///sy+.\n${c1}            -/osssossossso/-",
    },
    "Hash": {
        "colors": [123],
        "logo": "${c1}\n${c1}      +   ######   +\n${c1}    ###   ######   ###\n${c1}  #####   ######   #####\n${c1} ######   ######   ######\n${c1}\n${c1}####### '\"###### '\"########\n${c1}#######   ######   ########\n${c1}#######   ######   ########\n${c1}\n${c1} ###### '\"###### '\"######\n${c1}  #####   ######   #####\n${c1}    ###   ######   ###\n${c1}      ~   ######   ~",
    },
    "alpine_small": {
        "colors": [4, 7],
        "logo": "${c1}  /${c2}/ ${c1}\\\\  \\\\\n${c1} /${c2}/   ${c1}\\\\  \\\\\n${c1}/${c2}//    ${c1}\\\\  \\\\\n${c1}${c2}//      ${c1}\\\\  \\\\\n${c1}         \\\\",
    },
    "Alpine": {
        "colors": [4, 5, 7, 6],
        "logo": "${c1}      :dddddddddddddddddddddddddd:\n${c1}     /dddddddddddddddddddddddddddd/\n${c1}    +dddddddddddddddddddddddddddddd+\n${c1}  `sdddddddddddddddddddddddddddddddds`\n${c1} `ydddddddddddd++hdddddddddddddddddddy`\n${c1}.hddddddddddd+`  `+ddddh:-sdddddddddddh.\n${c1}hdddddddddd+`      `+y:    .sddddddddddh\n${c1}ddddddddh+`   `//`   `.`     -sddddddddd\n${c1}ddddddh+`   `/hddh/`   `:s-    -sddddddd\n${c1}ddddh+`   `/+/dddddh/`   `+s-    -sddddd\n${c1}ddd+`   `/o` :dddddddh/`   `oy-    .yddd\n${c1}hdddyo+ohddyosdddddddddho+oydddy++ohdddh\n${c1}.hddddddddddddddddddddddddddddddddddddh.\n${c1} `yddddddddddddddddddddddddddddddddddy`\n${c1}  `sdddddddddddddddddddddddddddddddds`\n${c1}    +dddddddddddddddddddddddddddddd+\n${c1}     /dddddddddddddddddddddddddddd/\n${c1}      :dddddddddddddddddddddddddd:\n${c1}       .hddddddddddddddddddddddh.",
    },
    "Alter": {
        "colors": [6, 6],
        "logo": "${c1}                    ^WWWw\n${c1}                   'wwwwww\n${c1}                  !wwwwwwww\n${c1}                 #`wwwwwwwww\n${c1}                @wwwwwwwwwwww\n${c1}               wwwwwwwwwwwwwww\n${c1}              wwwwwwwwwwwwwwwww\n${c1}             wwwwwwwwwwwwwwwwwww\n${c1}            wwwwwwwwwwwwwwwwwwww,\n${c1}           w~1i.wwwwwwwwwwwwwwwww,\n${c1}         3~:~1lli.wwwwwwwwwwwwwwww.\n${c1}        :~~:~?ttttzwwwwwwwwwwwwwwww\n${c1}       #<~:~~~~?llllltO-.wwwwwwwwwww\n${c1}      #~:~~:~:~~?ltlltlttO-.wwwwwwwww\n${c1}     @~:~~:~:~:~~(zttlltltlOda.wwwwwww\n${c1}    @~:~~: ~:~~:~:(zltlltlO    a,wwwwww\n${c1}   8~~:~~:~~~~:~~~~_1ltltu          ,www\n${c1}  5~~:~~:~~:~~:~~:~~~_1ltq             N,,\n${c1} g~:~~:~~~:~~:~~:~:~~~~1q                N,",
    },
    "Amazon": {
        "colors": [3, 7],
        "logo": "${c1}      `.:+shmMMMMMMMMMMMMMMmhs+:.`\n${c1}    -+hNNMMMMMMMMMMMMMMMMMMMMMMNNho-\n${c1}.``      -/+shmNNMMMMMMNNmhs+/-      ``.\n${c1}dNmhs+:.       `.:/oo/:.`       .:+shmNd\n${c1}dMMMMMMMNdhs+:..        ..:+shdNMMMMMMMd\n${c1}dMMMMMMMMMMMMMMNds    odNMMMMMMMMMMMMMMd\n${c1}dMMMMMMMMMMMMMMMMh    yMMMMMMMMMMMMMMMMd\n${c1}dMMMMMMMMMMMMMMMMh    yMMMMMMMMMMMMMMMMd\n${c1}dMMMMMMMMMMMMMMMMh    yMMMMMMMMMMMMMMMMd\n${c1}dMMMMMMMMMMMMMMMMh    yMMMMMMMMMMMMMMMMd\n${c1}dMMMMMMMMMMMMMMMMh    yMMMMMMMMMMMMMMMMd\n${c1}dMMMMMMMMMMMMMMMMh    yMMMMMMMMMMMMMMMMd\n${c1}dMMMMMMMMMMMMMMMMh    yMMMMMMMMMMMMMMMMd\n${c1}dMMMMMMMMMMMMMMMMh    yMMMMMMMMMMMMMMMMd\n${c1}dMMMMMMMMMMMMMMMMh    yMMMMMMMMMMMMMMMMd\n${c1}.:+ydNMMMMMMMMMMMh    yMMMMMMMMMMMNdy+:.\n${c1}     `.:+shNMMMMMh    yMMMMMNhs+:``\n${c1}            `-+shy    shs+:`",
    },
    "Anarchy": {
        "colors": [7, 4],
        "logo": "${c2}                        ${c2}..${c1}\n${c2}                      ${c2}:..${c1}\n${c2}                    ${c2}:+++.${c1}\n${c2}              .:::++${c2}++++${c1}+::.\n${c2}          .:+######${c2}++++${c1}######+:.\n${c2}       .+#########${c2}+++++${c1}##########:.\n${c2}     .+##########${c2}+++++++${c1}##${c2}+${c1}#########+.\n${c2}    +###########${c2}+++++++++${c1}############:\n${c2}   +##########${c2}++++++${c1}#${c2}++++${c1}#${c2}+${c1}###########+\n${c2}  +###########${c2}+++++${c1}###${c2}++++${c1}#${c2}+${c1}###########+\n${c2} :##########${c2}+${c1}#${c2}++++${c1}####${c2}++++${c1}#${c2}+${c1}############:\n${c2} ###########${c2}+++++${c1}#####${c2}+++++${c1}#${c2}+${c1}###${c2}++${c1}######+\n${c2}.##########${c2}++++++${c1}#####${c2}++++++++++++${c1}#######.\n${c2}.##########${c2}+++++++++++++++++++${c1}###########.\n${c2} #####${c2}++++++++++++++${c1}###${c2}++++++++${c1}#########+\n${c2} :###${c2}++++++++++${c1}#########${c2}+++++++${c1}#########:\n${c2}  +######${c2}+++++${c1}##########${c2}++++++++${c1}#######+\n${c2}   +####${c2}+++++${c1}###########${c2}+++++++++${c1}#####+\n${c2}    :##${c2}++++++${c1}############${c2}++++++++++${c1}##:\n${c2}     .${c2}++++++${c1}#############${c2}++++++++++${c1}+.\n${c2}      :${c2}++++${c1}###############${c2}+++++++${c1}::\n${c2}     .${c2}++. .:+${c1}##############${c2}+++++++${c1}..\n${c2}     ${c2}.:.${c1}      ..::++++++::..:${c2}++++${c1}+.\n${c2}     ${c2}.${c1}                       ${c2}.:+++${c1}.\n${c2}                                ${c2}.:${c1}:\n${c2}                                   ${c2}..${c1}\n${c2}                                    ${c2}..${c1}",
    },
    "android_small": {
        "colors": [2, 7],
        "logo": "${c1}   ';,.-----.,;'\n${c1}  ,'           ',\n${c1} /    O     O    \\\\\n${c1}|                 |\n${c1}'-----------------'",
    },
    "Android": {
        "colors": [2, 7],
        "logo": "${c1}          +hydNNNNdyh+\n${c1}        +mMMMMMMMMMMMMm+\n${c1}      `dMM${c2}m:${c1}NMMMMMMN${c2}:m${c1}MMd`\n${c1}      hMMMMMMMMMMMMMMMMMMh\n${c1}  ..  yyyyyyyyyyyyyyyyyyyy  ..\n${c1}.mMMm`MMMMMMMMMMMMMMMMMMMM`mMMm.\n${c1}:MMMM-MMMMMMMMMMMMMMMMMMMM-MMMM:\n${c1}:MMMM-MMMMMMMMMMMMMMMMMMMM-MMMM:\n${c1}:MMMM-MMMMMMMMMMMMMMMMMMMM-MMMM:\n${c1}:MMMM-MMMMMMMMMMMMMMMMMMMM-MMMM:\n${c1}-MMMM-MMMMMMMMMMMMMMMMMMMM-MMMM-\n${c1} +yy+ MMMMMMMMMMMMMMMMMMMM +yy+\n${c1}      mMMMMMMMMMMMMMMMMMMm\n${c1}      `/++MMMMh++hMMMM++/`\n${c1}          MMMMo  oMMMM\n${c1}          MMMMo  oMMMM\n${c1}          oNMm-  -mMNs",
    },
    "Antergos": {
        "colors": [4, 6],
        "logo": "${c2}            .-/osssssssso/.\n${c2}           :osyysssssssyyys+-\n${c2}        `.+yyyysssssssssyyyyy+.\n${c2}       `/syyyyyssssssssssyyyyys-`\n${c2}      `/yhyyyyysss${c1}++${c2}ssosyyyyhhy/`\n${c2}     .ohhhyyyys${c1}o++/+o${c2}so${c1}+${c2}syy${c1}+${c2}shhhho.\n${c2}    .shhhhys${c1}oo++//+${c2}sss${c1}+++${c2}yyy${c1}+s${c2}hhhhs.\n${c2}   -yhhhhs${c1}+++++++o${c2}ssso${c1}+++${c2}yyy${c1}s+o${c2}hhddy:\n${c2}  -yddhhy${c1}o+++++o${c2}syyss${c1}++++${c2}yyy${c1}yooy${c2}hdddy-\n${c2} .yddddhs${c1}o++o${c2}syyyyys${c1}+++++${c2}yyhh${c1}sos${c2}hddddy`\n${c2}`odddddhyosyhyyyyyy${c1}++++++${c2}yhhhyosddddddo\n${c2}.dmdddddhhhhhhhyyyo${c1}+++++${c2}shhhhhohddddmmh.\n${c2}ddmmdddddhhhhhhhso${c1}++++++${c2}yhhhhhhdddddmmdy\n${c2}dmmmdddddddhhhyso${c1}++++++${c2}shhhhhddddddmmmmh\n${c2}-dmmmdddddddhhys${c1}o++++o${c2}shhhhdddddddmmmmd-\n${c2}.smmmmddddddddhhhhhhhhhdddddddddmmmms.\n${c2}   `+ydmmmdddddddddddddddddddmmmmdy/.\n${c2}      `.:+ooyyddddddddddddyyso+:.`",
    },
    "antiX": {
        "colors": [1, 7, 3],
        "logo": "${c1}                    \\\n${c1}         , - ~ ^ ~ - \\        /\n${c1}     , '              \\ ' ,  /\n${c1}   ,                   \\   '/\n${c1}  ,                     \\  / ,\n${c1} ,___,                   \\/   ,\n${c1} /   |   _  _  _|_ o     /\\   ,\n${c1}|,   |  / |/ |  |  |    /  \\  ,\n${c1} \\,_/\\_/  |  |_/|_/|_/_/    \\,\n${c1}   ,                  /     ,\\\n${c1}     ,               /  , '   \\\n${c1}      ' - , _ _ _ ,  '",
    },
    "AOSC OS/Retro": {
        "colors": [4, 7, 1, 3],
        "logo": "${c2}     ...................\n${c2}   .....................${c1}################${c2}\n${c2} ..............     ....${c1}################${c2}\n${c2}..............       ...${c1}################${c2}\n${c2}.............         ..${c1}****************${c2}\n${c2}............     .     .${c1}****************${c2}\n${c2}...........     ...     ${c1}................${c2}\n${c2}..........     .....     ${c1}...............${c2}\n${c2}.........     .......     ...\n${c2} .${c3}......                   ${c2}.\n${c2}  ${c3}.....      .....${c2}....    ${c4}...........\n${c2}  ${c3}....      ......${c2}.       ${c4}...........\n${c2}  ${c3}...      .......        ${c4}...........\n${c2}  ${c3}................        ${c4}***********\n${c2}  ${c3}................        ${c4}###########\n${c2}  ${c3}****************\n${c2}  ${c3}################",
    },
    "AOSC OS": {
        "colors": [4, 7, 1],
        "logo": "${c2}         .ohNMMMMMMMMMMMMMMNho.\n${c2}      `+mMMMMMMMMMMmdmNMMMMMMMMm+`\n${c2}     +NMMMMMMMMMMMM/   `./smMMMMMN+\n${c2}   .mMMMMMMMMMMMMMMo        -yMMMMMm.\n${c2}  :NMMMMMMMMMMMMMMMs          .hMMMMN:\n${c2} .NMMMMhmMMMMMMMMMMm+/-         oMMMMN.\n${c2} dMMMMs  ./ymMMMMMMMMMMNy.       sMMMMd\n${c2}-MMMMN`      oMMMMMMMMMMMN:      `NMMMM-\n${c2}/MMMMh       NMMMMMMMMMMMMm       hMMMM/\n${c2}/MMMMh       NMMMMMMMMMMMMm       hMMMM/\n${c2}-MMMMN`      :MMMMMMMMMMMMy.     `NMMMM-\n${c2} dMMMMs       .yNMMMMMMMMMMMNy/. sMMMMd\n${c2} .NMMMMo         -/+sMMMMMMMMMMMmMMMMN.\n${c2}  :NMMMMh.          .MMMMMMMMMMMMMMMN:\n${c2}   .mMMMMMy-         NMMMMMMMMMMMMMm.\n${c2}     +NMMMMMms/.`    mMMMMMMMMMMMN+\n${c2}      `+mMMMMMMMMNmddMMMMMMMMMMm+`\n${c2}         .ohNMMMMMMMMMMMMMMNho.\n${c2}             .:+syhhhhys+:.",
    },
    "Apricity": {
        "colors": [4, 7, 1],
        "logo": "${c2}          ``...``              `:. -/:\n${c2}     `-+ymNMMMMMNmho-`      :sdNNm/\n${c2}   `+dMMMMMMMMMMMMMMMmo` sh:.:::-\n${c2}  /mMMMMMMMMMMMMMMMMMMMm/`sNd/\n${c2} oMMMMMMMMMMMMMMMMMMMMMMMs -`\n${c2}:MMMMMMMMMMMMMMMMMMMMMMMMM/\n${c2}NMMMMMMMMMMMMMMMMMMMMMMMMMd\n${c2}MMMMMMMmdmMMMMMMMMMMMMMMMMd\n${c2}MMMMMMy` .mMMMMMMMMMMMmho:`\n${c2}MMMMMMNo/sMMMMMMMNdy+-.`-/\n${c2}MMMMMMMMMMMMNdy+:.`.:ohmm:\n${c2}MMMMMMMmhs+-.`.:+ymNMMMy.\n${c2}MMMMMM/`.-/ohmNMMMMMMy-\n${c2}MMMMMMNmNNMMMMMMMMmo.\n${c2}MMMMMMMMMMMMMMMms:`\n${c2}MMMMMMMMMMNds/.\n${c2}dhhyys+/-`",
    },
    "arcolinux_small": {
        "colors": [7, 4],
        "logo": "${c2}         ooo\n${c2}        ooooo\n${c2}       ooooooo\n${c2}      ooooooooo\n${c2}     ooooo ooooo\n${c2}    ooooo   ooooo\n${c2}   ooooo     ooooo\n${c2}  ooooo  ${c1}<oooooooo>${c2}\n${c2} ooooo      ${c1}<oooooo>${c2}\n${c2}ooooo          ${c1}<oooo>${c2}",
    },
    "ArcoLinux": {
        "colors": [7, 4],
        "logo": "${c2}                   ooo:\n${c2}                  yoooo/\n${c2}                 yooooooo\n${c2}                yooooooooo\n${c2}               yooooooooooo\n${c2}             .yooooooooooooo\n${c2}            .oooooooooooooooo\n${c2}           .oooooooarcoooooooo\n${c2}          .ooooooooo-oooooooooo\n${c2}         .ooooooooo-  oooooooooo\n${c2}        :ooooooooo.    :ooooooooo\n${c2}       :ooooooooo.      :ooooooooo\n${c2}      :oooarcooo         .oooarcooo\n${c2}     :ooooooooy           .ooooooooo\n${c2}    :ooooooooo   ${c1}/ooooooooooooooooooo${c2}\n${c2}   :ooooooooo      ${c1}.-ooooooooooooooooo.${c2}\n${c2}  ooooooooo-             ${c1}-ooooooooooooo.${c2}\n${c2} ooooooooo-                 ${c1}.-oooooooooo.${c2}\n${c2}ooooooooo.                     ${c1}-ooooooooo${c2}",
    },
    "arch_small": {
        "colors": [6, 7, 1],
        "logo": "${c1}     /  \\\\\n${c1}    /\\\\   \\\\\n${c1}${c2}   /      \\\\\n${c1}  /   ,,   \\\\\n${c1} /   |  |  -\\\\\n${c1}/_-''    ''-_\\\\",
    },
    "arch_old": {
        "colors": [6, 7, 1],
        "logo": "${c1}         _=(SDGJT=_\n${c1}       _GTDJHGGFCVS)\n${c1}      ,GTDJGGDTDFBGX0\n${c1}${c1}     JDJDIJHRORVFSBSVL${c2}-=+=,_\n${c1}${c1}    IJFDUFHJNXIXCDXDSV,${c2}  \"DEBL\n${c1}${c1}   [LKDSDJTDU=OUSCSBFLD.${c2}   '?ZWX,\n${c1}${c1}  ,LMDSDSWH'     `DCBOSI${c2}     DRDS],\n${c1}${c1}  SDDFDFH'         !YEWD,${c2}   )HDROD\n${c1}${c1} !KMDOCG            &GSU|${c2}\\_GFHRGO\\'\n${c1}${c1} HKLSGP'${c2}           __${c1}\\TKM0${c2}\\GHRBV)'\n${c1}${c1}JSNRVW'${c2}       __+MNAEC${c1}\\IOI,${c2}\\BN'\n${c1}${c1}HELK['${c2}    __,=OFFXCBGHC${c1}\\FD)\n${c1}${c1}?KGHE ${c2}\\_-#DASDFLSV='${c1}    'EF\n${c1}'EHTI                    !H\n${c1} `0F'                    '!",
    },
    "ArchBox": {
        "colors": [2, 7, 1],
        "logo": "${c1}         ..-/oshhhhhh`   `::::-.\n${c1}     .:/ohhhhhhhhhhhh`        `-::::.\n${c1} .+shhhhhhhhhhhhhhhhh`             `.::-.\n${c1} /`-:+shhhhhhhhhhhhhh`            .-/+shh\n${c1} /      .:/ohhhhhhhhh`       .:/ohhhhhhhh\n${c1} /           `-:+shhh`  ..:+shhhhhhhhhhhh\n${c1} /                 .:ohhhhhhhhhhhhhhhhhhh\n${c1} /                  `hhhhhhhhhhhhhhhhhhhh\n${c1} /                  `hhhhhhhhhhhhhhhhhhhh\n${c1} /                  `hhhhhhhhhhhhhhhhhhhh\n${c1} /                  `hhhhhhhhhhhhhhhhhhhh\n${c1} /      .+o+        `hhhhhhhhhhhhhhhhhhhh\n${c1} /     -hhhhh       `hhhhhhhhhhhhhhhhhhhh\n${c1} /     ohhhhho      `hhhhhhhhhhhhhhhhhhhh\n${c1} /:::+`hhhhoos`     `hhhhhhhhhhhhhhhhhs+`\n${c1}    `--/:`   /:     `hhhhhhhhhhhho/-\n${c1}             -/:.   `hhhhhhs+:-`\n${c1}                ::::/ho/-`",
    },
    "ARCHlabs": {
        "colors": [6, 6, 7, 1],
        "logo": "${c1}                    'kKk,\n${c1}                   .dKKKx.\n${c1}                  .oKXKXKd.\n${c1}                 .l0XXXXKKo.\n${c1}                 c0KXXXXKX0l.\n${c1}                :0XKKOxxOKX0l.\n${c1}               :OXKOc. .c0XX0l.\n${c1}              :OK0o. ${c4}...${c1}'dKKX0l.\n${c1}             :OX0c  ${c4};xOx'${c1}'dKXX0l.\n${c1}            :0KKo.${c4}.o0XXKd'.${c1}lKXX0l.\n${c1}           c0XKd.${c4}.oKXXXXKd..${c1}oKKX0l.\n${c1}         .c0XKk;${c4}.l0K0OO0XKd..${c1}oKXXKo.\n${c1}        .l0XXXk:${c4},dKx,.'l0XKo.${c1}.kXXXKo.\n${c1}       .o0XXXX0d,${c4}:x;   .oKKx'${c1}.dXKXXKd.\n${c1}      .oKXXXXKK0c.${c4};.    :00c'${c1}cOXXXXXKd.\n${c1}     .dKXXXXXXXXk,${c4}.     cKx'${c1}'xKXXXXXXKx'\n${c1}    'xKXXXXK0kdl:.     ${c4}.ok; ${c1}.cdk0KKXXXKx'\n${c1}   'xKK0koc,..         ${c4}'c, ${c1}    ..,cok0KKk,\n${c1}  ,xko:'.             ${c4}.. ${c1}           .':okx;\n${c1} .,'.                                   .',.",
    },
    "ArchStrike": {
        "colors": [8, 6],
        "logo": "${c1}                  **.\n${c1}                 ****\n${c1}                ******\n${c1}                *******\n${c1}              ** *******\n${c1}             **** *******\n${c1}            ${c1}****${c2}_____${c1}***${c2}/${c1}*\n${c1}           ***${c2}/${c1}*******${c2}//${c1}***\n${c1}          **${c2}/${c1}********${c2}///${c1}*${c2}/${c1}**\n${c1}         **${c2}/${c1}*******${c2}////${c1}***${c2}/${c1}**\n${c1}        **${c2}/${c1}****${c2}//////.,${c1}****${c2}/${c1}**\n${c1}       ***${c2}/${c1}*****${c2}/////////${c1}**${c2}/${c1}***\n${c1}      ****${c2}/${c1}****    ${c2}/////${c1}***${c2}/${c1}****\n${c1}     ******${c2}/${c1}***  ${c2}////   ${c1}**${c2}/${c1}******\n${c1}    ********${c2}/${c1}* ${c2}///      ${c1}*${c2}/${c1}********\n${c1}  ,******     ${c2}// ______ /    ${c1}******,",
    },
    "XFerience": {
        "colors": [6, 6, 7, 1],
        "logo": "${c1}        .-/+++ooooooooo+++:-`\n${c1}     `-/+oooooooooooooooooo++:.\n${c1}    -/+oooooo/+ooooooooo+/ooo++:`\n${c1}  `/+oo++oo.   .+oooooo+.-: +:-o+-\n${c1} `/+o/.  -o.    :oooooo+ ```:.+oo+-\n${c1}`:+oo-    -/`   :oooooo+ .`-`+oooo/.\n${c1}.+ooo+.    .`   `://///+-+..oooooo+:`\n${c1}-+ooo:`                ``.-+oooooo+/`\n${c1}-+oo/`                       :+oooo/.\n${c1}.+oo:            ..-/. .      -+oo+/`\n${c1}`/++-         -:::++::/.      -+oo+-\n${c1} ./o:          `:///+-     `./ooo+:`\n${c1}  .++-         `` /-`   -:/+oooo+:`\n${c1}   .:+/:``          `-:ooooooo++-\n${c1}     ./+o+//:...../+oooooooo++:`\n${c1}       `:/++ooooooooooooo++/-`\n${c1}          `.-//++++++//:-.`\n${c1}               ``````",
    },
    "ArchMerge": {
        "colors": [6, 6, 7, 1],
        "logo": "${c1}                  sMN-\n${c1}                 +MMMm`\n${c1}                /MMMMMd`\n${c1}               :NMMMMMMy\n${c1}              -NMMMMMMMMs\n${c1}             .NMMMMMMMMMM+\n${c1}            .mMMMMMMMMMMMM+\n${c1}            oNMMMMMMMMMMMMM+\n${c1}          `+:-+NMMMMMMMMMMMM+\n${c1}          .sNMNhNMMMMMMMMMMMM/\n${c1}        `hho/sNMMMMMMMMMMMMMMM/\n${c1}       `.`omMMmMMMMMMMMMMMMMMMM+\n${c1}      .mMNdshMMMMd+::oNMMMMMMMMMo\n${c1}     .mMMMMMMMMM+     `yMMMMMMMMMs\n${c1}    .NMMMMMMMMM/        yMMMMMMMMMy\n${c1}   -NMMMMMMMMMh         `mNMMMMMMMMd`\n${c1}  /NMMMNds+:.`             `-/oymMMMm.\n${c1} +Mmy/.                          `:smN:\n${c1}/+.                                  -o.",
    },
    "Arch": {
        "colors": [6, 6, 7, 1],
        "logo": "${c1}                  .o+`\n${c1}                 `ooo/\n${c1}                `+oooo:\n${c1}               `+oooooo:\n${c1}               -+oooooo+:\n${c1}             `/:-:++oooo+:\n${c1}            `/++++/+++++++:\n${c1}           `/++++++++++++++:\n${c1}          `/+++o${c2}oooooooo${c1}oooo/`\n${c1}${c2}         ${c1}./${c2}ooosssso++osssssso${c1}+`\n${c1}${c2}        .oossssso-````/ossssss+`\n${c1}       -osssssso.      :ssssssso.\n${c1}      :osssssss/        osssso+++.\n${c1}     /ossssssss/        +ssssooo/-\n${c1}   `/ossssso+/:-        -:/+osssso+-\n${c1}  `+sso+:-`                 `.-/+oso:\n${c1} `++:.                           `-/+/\n${c1} .`                                 `/",
    },
    "artix_small": {
        "colors": [6, 6, 7, 1],
        "logo": "${c1}     /  \\\\\n${c1}    /`'.,\\\\\n${c1}   /     ',\n${c1}  /      ,`\\\\\n${c1} /   ,.'`.  \\\\\n${c1}/.,'`     `'.\\\\",
    },
    "Artix": {
        "colors": [6, 6, 7, 1],
        "logo": "${c1}                  'o'\n${c1}                 'ooo'\n${c1}                'ooxoo'\n${c1}               'ooxxxoo'\n${c1}              'oookkxxoo'\n${c1}             'oiioxkkxxoo'\n${c1}            ':;:iiiioxxxoo'\n${c1}               `'.;::ioxxoo'\n${c1}          '-.      `':;jiooo'\n${c1}         'oooio-..     `'i:io'\n${c1}        'ooooxxxxoio:,.   `'-;'\n${c1}       'ooooxxxxxkkxoooIi:-.  `'\n${c1}      'ooooxxxxxkkkkxoiiiiiji'\n${c1}     'ooooxxxxxkxxoiiii:'`     .i'\n${c1}    'ooooxxxxxoi:::'`       .;ioxo'\n${c1}   'ooooxooi::'`         .:iiixkxxo'\n${c1}  'ooooi:'`                `'';ioxxo'\n${c1} 'i:'`                          '':io'\n${c1}'`                                   `'",
    },
    "Arya": {
        "colors": [2, 1],
        "logo": "${c1}${c1}               -syyyy/${c2}-yyyyyy+\n${c1}${c1}              .syyyyy/${c2}-yyyyyy+\n${c1}${c1}              :yyyyyy/${c2}-yyyyyy+\n${c1}${c1}           `/ :yyyyyy/${c2}-yyyyyy+\n${c1}${c1}          .+s :yyyyyy/${c2}-yyyyyy+\n${c1}${c1}         .oys :yyyyyy/${c2}-yyyyyy+\n${c1}${c1}        -oyys :yyyyyy/${c2}-yyyyyy+\n${c1}${c1}       :syyys :yyyyyy/${c2}-yyyyyy+\n${c1}${c1}      /syyyys :yyyyyy/${c2}-yyyyyy+\n${c1}${c1}     +yyyyyys :yyyyyy/${c2}-yyyyyy+\n${c1}${c1}   .oyyyyyyo. :yyyyyy/${c2}-yyyyyy+ ---------\n${c1}${c1}  .syyyyyy+`  :yyyyyy/${c2}-yyyyy+-+syyyyyyyy\n${c1}${c1} -syyyyyy/    :yyyyyy/${c2}-yyys:.syyyyyyyyyy\n${c1}${c1}:syyyyyy/     :yyyyyy/${c2}-yyo.:syyyyyyyyyyy",
    },
    "Bedrock": {
        "colors": [8, 7],
        "logo": "${c1}--------------------------------------\n${c1}--------------------------------------\n${c1}---${c2}\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\${c1}-----------------------\n${c1}----${c2}\\\\\\\\\\\\      \\\\\\\\\\\\${c1}----------------------\n${c1}-----${c2}\\\\\\\\\\\\      \\\\\\\\\\\\${c1}---------------------\n${c1}------${c2}\\\\\\\\\\\\      \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\${c1}------\n${c1}-------${c2}\\\\\\\\\\\\                    \\\\\\\\\\\\${c1}-----\n${c1}--------${c2}\\\\\\\\\\\\                    \\\\\\\\\\\\${c1}----\n${c1}---------${c2}\\\\\\\\\\\\        ______      \\\\\\\\\\\\${c1}---\n${c1}----------${c2}\\\\\\\\\\\\                   ///${c1}---\n${c1}-----------${c2}\\\\\\\\\\\\                 ///${c1}----\n${c1}------------${c2}\\\\\\\\\\\\               ///${c1}-----\n${c1}-------------${c2}\\\\\\\\\\\\////////////////${c1}------\n${c1}--------------------------------------\n${c1}--------------------------------------\n${c1}--------------------------------------",
    },
    "Bitrig": {
        "colors": [2, 7],
        "logo": "${c1}   -MMo-dMd`\n${c1}   oMN- oMN`\n${c1}   yMd  /NM:\n${c1}  .mMmyyhMMs\n${c1}  :NMMMhsmMh\n${c1}  +MNhNNoyMm-\n${c1}  hMd.-hMNMN:\n${c1}  mMmsssmMMMo\n${c1} .MMdyyhNMMMd\n${c1} oMN.`/dMddMN`\n${c1} yMm/hNm+./MM/\n${c1}.dMMMmo.``.NMo\n${c1}:NMMMNmmmmmMMh\n${c1}/MN/-------oNN:\n${c1}hMd.       .dMh\n${c1}sm/         /ms",
    },
    "BlackArch": {
        "colors": [1, 1, 0, 1],
        "logo": "${c3}                   11\n${c3}                  ====${c1}\n${c3}                  .${c3}//${c1}\n${c3}                 `o${c3}//${c1}:\n${c3}                `+o${c3}//${c1}o:\n${c3}               `+oo${c3}//${c1}oo:\n${c3}               -+oo${c3}//${c1}oo+:\n${c3}             `/:-:+${c3}//${c1}ooo+:\n${c3}            `/+++++${c3}//${c1}+++++:\n${c3}           `/++++++${c3}//${c1}++++++:\n${c3}          `/+++o${c2}ooo${c3}//${c2}ooo${c1}oooo/`\n${c3}${c2}         ${c1}./${c2}ooosssso${c3}//${c2}osssssso${c1}+`\n${c3}${c2}        .oossssso-`${c3}//${c1}`/ossssss+`\n${c3}       -osssssso.  ${c3}//${c1}  :ssssssso.\n${c3}      :osssssss/   ${c3}//${c1}   osssso+++.\n${c3}     /ossssssss/   ${c3}//${c1}   +ssssooo/-\n${c3}   `/ossssso+/:-   ${c3}//${c1}   -:/+osssso+-\n${c3}  `+sso+:-`        ${c3}//${c1}       `.-/+oso:\n${c3} `++:.             ${c3}//${c1}            `-/+/\n${c3} .`                ${c3}/${c1}                `/",
    },
    "BLAG": {
        "colors": [5, 7],
        "logo": "${c1}            ,MK:\n${c1}            xMMMX:\n${c1}           .NMMMMMX;\n${c1}           lMMMMMMMM0clodkO0KXWW:\n${c1}           KMMMMMMMMMMMMMMMMMMX'\n${c1}      .;d0NMMMMMMMMMMMMMMMMMMK.\n${c1} .;dONMMMMMMMMMMMMMMMMMMMMMMx\n${c1}'dKMMMMMMMMMMMMMMMMMMMMMMMMl\n${c1}   .:xKWMMMMMMMMMMMMMMMMMMM0.\n${c1}       .:xNMMMMMMMMMMMMMMMMMK.\n${c1}          lMMMMMMMMMMMMMMMMMMK.\n${c1}          ,MMMMMMMMWkOXWMMMMMM0\n${c1}          .NMMMMMNd.     `':ldko\n${c1}           OMMMK:\n${c1}           oWk,\n${c1}           ;:",
    },
    "BlankOn": {
        "colors": [1, 7, 3],
        "logo": "${c2}${c2}      -smMMMMMMMMMMMMMMMMmy-`    ${c1}`yyyyy+\n${c2}${c2}   `:dMMMMMMMMMMMMMMMMMMMMMMd/`  ${c1}`yyyyys\n${c2}${c2}  .hMMMMMMMNmhso/++symNMMMMMMMh- ${c1}`yyyyys\n${c2}${c2} -mMMMMMMms-`         -omMMMMMMN-${c1}.yyyyys\n${c2}${c2}.mMMMMMMy.              .yMMMMMMm:${c1}yyyyys\n${c2}${c2}sMMMMMMy                 `sMMMMMMh${c1}yyyyys\n${c2}${c2}NMMMMMN:                  .NMMMMMN${c1}yyyyys\n${c2}${c2}MMMMMMm.                   NMMMMMN${c1}yyyyys\n${c2}${c2}hMMMMMM+                  /MMMMMMN${c1}yyyyys\n${c2}${c2}:NMMMMMN:                :mMMMMMM+${c1}yyyyys\n${c2}${c2} oMMMMMMNs-            .sNMMMMMMs.${c1}yyyyys\n${c2}${c2}  +MMMMMMMNho:.`  `.:ohNMMMMMMNo ${c1}`yyyyys\n${c2}${c2}   -hMMMMMMMMNNNmmNNNMMMMMMMMh-  ${c1}`yyyyys\n${c2}${c2}     :yNMMMMMMMMMMMMMMMMMMNy:`   ${c1}`yyyyys\n${c2}${c2}       .:sdNMMMMMMMMMMNds/.      ${c1}`yyyyyo\n${c2}${c2}           `.:/++++/:.`           ${c1}:oys+.",
    },
    "BlueLight": {
        "colors": [7, 4],
        "logo": "${c1}              oMMMMMMMMMMMMMMMMMMMMMMMMM\n${c1}              oMMMMMMMMMMMMMMMMMMMMMMMMM\n${c1}              oMMMMMMMMMMMMMMMMMMMMMMMMM\n${c1}              -+++++++++++++++++++++++mM${c2}\n${c1}             ```````````````````````..${c1}dM${c2}\n${c1}           ```````````````````````....${c1}dM${c2}\n${c1}         ```````````````````````......${c1}dM${c2}\n${c1}       ```````````````````````........${c1}dM${c2}\n${c1}     ```````````````````````..........${c1}dM${c2}\n${c1}   ```````````````````````............${c1}dM${c2}\n${c1}.::::::::::::::::::::::-..............${c1}dM${c2}\n${c1} `-+yyyyyyyyyyyyyyyyyyyo............${c1}+mMM${c2}\n${c1}     -+yyyyyyyyyyyyyyyyo..........${c1}+mMMMM${c2}\n${c1}        ./syyyyyyyyyyyyo........${c1}+mMMMMMM${c2}\n${c1}           ./oyyyyyyyyyo......${c1}+mMMMMMMMM${c2}\n${c1}              omdyyyyyyo....${c1}+mMMMMMMMMMM${c2}\n${c1}              ${c1}oMMM${c2}mdhyyo..${c1}+mMMMMMMMMMMMM\n${c1}              oNNNNNNm${c2}dso${c1}mMMMMMMMMMMMMMM",
    },
    "bonsai": {
        "colors": [6, 2, 3],
        "logo": "${c2}   ${c2}#######,  ${c2},#####,\n${c2}   ${c2}#####',#  ${c2}'######\n${c2}    ${c2}''###'${c3}';,,,'${c2}###'\n${c2}   ${c3}       ,;  ''''\n${c2}   ${c3}      ;;;   ${c2},#####,\n${c2}   ${c3}     ;;;'  ,,;${c2};;###\n${c2}   ${c3}     ';;;;''${c2}'####'\n${c2}   ${c3}      ;;;\n${c2}   ${c3}   ,.;;';'',,,\n${c2}   ${c3}  '     '\n${c2}${c1} #\n${c2} #                        O\n${c2} ##, ,##,',##, ,##  ,#,   ,\n${c2} # # #  # #''# #,,  # #   #\n${c2} '#' '##' #  #  ,,# '##;, #",
    },
    "BSD": {
        "colors": [1, 7, 4, 3, 6],
        "logo": "${c1}            /(        )`\n${c1}            \\ \\___   / |\n${c1}            /- _  `-/  '\n${c1}           (${c2}/\\/ \\ ${c1}\\   /\\\n${c1}           ${c2}/ /   | `    ${c1}\\\n${c1}           ${c3}O O   ${c2}) ${c1}/    |\n${c1}           ${c2}`-^--'${c1}`<     '\n${c1}          (_.)  _  )   /\n${c1}           `.___/`    /\n${c1}             `-----' /\n${c1}${c4}<----.     __ / __   \\\n${c1}${c4}<----|====${c1}O)))${c4}==${c1}) \\) /${c4}====|\n${c1}<----'    ${c1}`--' `.__,' \\\n${c1}             |        |\n${c1}              \\       /       /\\\n${c1}         ${c5}______${c1}( (_  / \\______/\n${c1}       ${c5},'  ,-----'   |\n${c1}       `--{__________)",
    },
    "BunsenLabs": {
        "colors": [7, 7],
        "logo": "${c1}      -yMMs\n${c1}    `yMMMMN`\n${c1}   -NMMMMMMm.\n${c1}  :MMMMMMMMMN-\n${c1} .NMMMMMMMMMMM/\n${c1} yMMMMMMMMMMMMM/\n${c1}`MMMMMMNMMMMMMMN.\n${c1}-MMMMN+ /mMMMMMMy\n${c1}-MMMm`   `dMMMMMM\n${c1}`MMN.     .NMMMMM.\n${c1} hMy       yMMMMM`\n${c1} -Mo       +MMMMN\n${c1}  /o       +MMMMs\n${c1}           +MMMN`\n${c1}           hMMM:\n${c1}          `NMM/\n${c1}          +MN:\n${c1}          mh.\n${c1}         -/",
    },
    "Calculate": {
        "colors": [7, 3],
        "logo": "${c1}                           ,,+++++++,.\n${c1}                         .,,,....,,,${c2}+**+,,.${c1}\n${c1}                       ............,${c2}++++,,,${c1}\n${c1}                      ...............\n${c1}                    ......,,,........\n${c1}                  .....+*#####+,,,*+.\n${c1}              .....,*###############,..,,,,,,..\n${c1}           ......,*#################*..,,,,,..,,,..\n${c1}         .,,....*####################+***+,,,,...,++,\n${c1}       .,,..,..*#####################*,\n${c1}     ,+,.+*..*#######################.\n${c1}   ,+,,+*+..,########################*\n${c1}.,++++++.  ..+##**###################+\n${c1}.....      ..+##***#################*.\n${c1}           .,.*#*****##############*.\n${c1}           ..,,*********#####****+.\n${c1}     ${c2}.,++*****+++${c1}*****************${c2}+++++,.${c1}\n${c1}      ${c2},++++++**+++++${c1}***********${c2}+++++++++,${c1}\n${c1}     ${c2}.,,,,++++,..  .,,,,,.....,+++,.,,${c1}",
    },
    "Carbs": {
        "colors": [4, 5, 4, 4, 4, 4],
        "logo": "${c2}          ..,;:ccccccc:;'..\n${c2}       ..,clllc:;;;;;:cllc,.\n${c2}      .,cllc,...     ..';;'.\n${c2}     .;lol;..           ..\n${c2}    .,lol;.\n${c2}    .coo:.\n${c2}   .'lol,.\n${c2}   .,lol,.\n${c2}   .,lol,.\n${c2}    'col;.\n${c2}    .:ooc'.\n${c2}    .'col:.\n${c2}     .'cllc'..          .''.\n${c2}      ..:lolc,'.......',cll,.\n${c2}        ..;cllllccccclllc;'.\n${c2}          ...',;;;;;;,,...\n${c2}                .....",
    },
    "centos_small": {
        "colors": [3, 2, 4, 5, 7],
        "logo": "${c2}${c2} |\\\\  ${c1}|${c4}  /|\n${c2}${c2} | \\\\ ${c1}|${c4} / |\n${c2}${c4}<---- ${c3}---->\n${c2}${c3} | / ${c2}|${c1} \\\\ |\n${c2}${c3} |/__${c2}|${c1}__\\\\|\n${c2}${c2}     v",
    },
    "CentOS": {
        "colors": [3, 2, 4, 5, 7],
        "logo": "${c1}               .PLTJ.\n${c1}              <><><><>\n${c1}     ${c2}KKSSV' 4KKK ${c1}LJ${c4} KKKL.'VSSKK\n${c1}     ${c2}KKV' 4KKKKK ${c1}LJ${c4} KKKKAL 'VKK\n${c1}     ${c2}V' ' 'VKKKK ${c1}LJ${c4} KKKKV' ' 'V\n${c1}     ${c2}.4MA.' 'VKK ${c1}LJ${c4} KKV' '.4Mb.\n${c1}${c4}   . ${c2}KKKKKA.' 'V ${c1}LJ${c4} V' '.4KKKKK ${c3}.\n${c1}${c4} .4D ${c2}KKKKKKKA.'' ${c1}LJ${c4} ''.4KKKKKKK ${c3}FA.\n${c1}${c4}<QDD ++++++++++++  ${c3}++++++++++++ GFD>\n${c1}${c4} 'VD ${c3}KKKKKKKK'.. ${c2}LJ ${c1}..'KKKKKKKK ${c3}FV\n${c1}${c4}   ' ${c3}VKKKKK'. .4 ${c2}LJ ${c1}K. .'KKKKKV ${c3}'\n${c1}     ${c3} 'VK'. .4KK ${c2}LJ ${c1}KKA. .'KV'\n${c1}     ${c3}A. . .4KKKK ${c2}LJ ${c1}KKKKA. . .4\n${c1}     ${c3}KKA. 'KKKKK ${c2}LJ ${c1}KKKKK' .4KK\n${c1}     ${c3}KKSSA. VKKK ${c2}LJ ${c1}KKKV .4SSKK\n${c1}${c2}              <><><><>\n${c1}               'MKKM'\n${c1}                 ''",
    },
    "Chakra": {
        "colors": [4, 5, 7, 6],
        "logo": "${c1}   ,kkkkkkkk.,    'kkkkkkkkk,\n${c1}   ,kkkkkkkkkkkk., 'kkkkkkkkk.\n${c1}  ,kkkkkkkkkkkkkkkk,'kkkkkkkk,\n${c1} ,kkkkkkkkkkkkkkkkkkk'kkkkkkk.\n${c1}  \"''\"''',;::,,\"''kkk''kkkkk;   __\n${c1}      ,kkkkkkkkkk, \"k''kkkkk' ,kkkk\n${c1}    ,kkkkkkk' ., ' .: 'kkkk',kkkkkk\n${c1}  ,kkkkkkkk'.k'   ,  ,kkkk;kkkkkkkkk\n${c1} ,kkkkkkkk';kk 'k  \"'k',kkkkkkkkkkkk\n${c1}.kkkkkkkkk.kkkk.'kkkkkkkkkkkkkkkkkk'\n${c1};kkkkkkkk''kkkkkk;'kkkkkkkkkkkkk''\n${c1}'kkkkkkk; 'kkkkkkkk.,\"\"''\"''\"\"\n${c1}  ''kkkk;  'kkkkkkkkkk.,\n${c1}     ';'    'kkkkkkkkkkkk.,\n${c1}             ';kkkkkkkkkk'\n${c1}               ';kkkkkk'\n${c1}                  \"''\"",
    },
    "ChaletOS": {
        "colors": [4, 7, 1],
        "logo": "${c1}         `/sdNNmhyssssydmNNdo:`\n${c1}       :hNmy+-`          .-+hNNs-\n${c1}     /mMh/`       `+:`       `+dMd:\n${c1}   .hMd-        -sNNMNo.  /yyy  /mMs`\n${c1}  -NM+       `/dMd/--omNh::dMM   `yMd`\n${c1} .NN+      .sNNs:/dMNy:/hNmo/s     yMd`\n${c1} hMs    `/hNd+-smMMMMMMd+:omNy-    `dMo\n${c1}:NM.  .omMy:/hNMMMMMMMMMMNy:/hMd+`  :Md`\n${c1}/Md` `sm+.omMMMMMMMMMMMMMMMMd/-sm+  .MN:\n${c1}/Md`      MMMMMMMMMMMMMMMMMMMN      .MN:\n${c1}:NN.      MMMMMMm....--NMMMMMN      -Mm.\n${c1}`dMo      MMMMMMd      mMMMMMN      hMs\n${c1} -MN:     MMMMMMd      mMMMMMN     oMm`\n${c1}  :NM:    MMMMMMd      mMMMMMN    +Mm-\n${c1}   -mMy.  mmmmmmh      dmmmmmh  -hMh.\n${c1}     oNNs-                    :yMm/\n${c1}      .+mMdo:`            `:smMd/`\n${c1}         -ohNNmhsoo++osshmNNh+.\n${c1}            `./+syyhhyys+:``",
    },
    "Chapeau": {
        "colors": [2, 7],
        "logo": "${c1}            ////////.\n${c1}          ////////${c2}y+${c1}//.\n${c1}        ////////${c2}mMN${c1}/////.\n${c1}      ////////${c2}mMN+${c1}////////.\n${c1}    ////////////////////////.\n${c1}  /////////+${c2}shhddhyo${c1}+////////.\n${c1} ////////${c2}ymMNmdhhdmNNdo${c1}///////.\n${c1}///////+${c2}mMms${c1}////////${c2}hNMh${c1}///////.\n${c1}///////${c2}NMm+${c1}//////////${c2}sMMh${c1}///////\n${c1}//////${c2}oMMNmmmmmmmmmmmmMMm${c1}///////\n${c1}//////${c2}+MMmssssssssssssss+${c1}///////\n${c1}`//////${c2}yMMy${c1}////////////////////\n${c1} `//////${c2}smMNhso++oydNm${c1}////////\n${c1}  `///////${c2}ohmNMMMNNdy+${c1}///////\n${c1}    `//////////${c2}++${c1}//////////\n${c1}       `////////////////.\n${c1}           -////////-",
    },
    "Chrom": {
        "colors": [2, 1, 3, 4, 7],
        "logo": "${c2}        .,coooooooooooooc,.\n${c2}     .,lllllllllllllllllllll,.\n${c2}    ;ccccccccccccccccccccccccc;\n${c2}${c1}  '${c2}ccccccccccccccccccccccccccccc.\n${c2}${c1} ,oo${c2}c::::::::okO${c5}000${c3}0OOkkkkkkkkkkk:\n${c2}${c1}.ooool${c2};;;;:x${c5}K0${c4}kxxxxxk${c5}0X${c3}K0000000000.\n${c2}${c1}:oooool${c2};,;O${c5}K${c4}ddddddddddd${c5}KX${c3}000000000d\n${c2}${c1}lllllool${c2};l${c5}N${c4}dllllllllllld${c5}N${c3}K000000000\n${c2}${c1}lllllllll${c2}o${c5}M${c4}dccccccccccco${c5}W${c3}K000000000\n${c2}${c1};cllllllllX${c5}X${c4}c:::::::::c${c5}0X${c3}000000000d\n${c2}${c1}.ccccllllllO${c5}Nk${c4}c;,,,;cx${c5}KK${c3}0000000000.\n${c2}${c1} .cccccclllllxOO${c5}OOO${c1}Okx${c3}O0000000000;\n${c2}${c1}  .:ccccccccllllllllo${c3}O0000000OOO,\n${c2}${c1}    ,:ccccccccclllcd${c3}0000OOOOOOl.\n${c2}${c1}      '::ccccccccc${c3}dOOOOOOOkx:.\n${c2}${c1}        ..,::cccc${c3}xOOOkkko;.\n${c2}${c1}            ..,:${c3}dOkxl:.",
    },
    "cleanjaro_small": {
        "colors": [7, 7],
        "logo": "${c1}█████ ██████████\n${c1}█████\n${c1}█████\n${c1}█████\n${c1}████████████████\n${c1}████████████████",
    },
    "Cleanjaro": {
        "colors": [7, 7],
        "logo": "${c1}███████▌ ████████████████\n${c1}███████▌ ████████████████\n${c1}███████▌\n${c1}███████▌\n${c1}███████▌\n${c1}███████▌\n${c1}███████▌\n${c1}█████████████████████████\n${c1}█████████████████████████\n${c1}█████████████████████████\n${c1}▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀",
    },
    "ClearOS": {
        "colors": [2],
        "logo": "${c1}         .-:////////////////:-.\n${c1}      `-////////////////////////-`\n${c1}     -////////////////////////////-\n${c1}   `//////////////-..-//////////////`\n${c1}  ./////////////:      ://///////////.\n${c1} `//////:..-////:      :////-..-//////`\n${c1} ://////`    -///:.``.:///-`    ://///:\n${c1}`///////:.     -////////-`    `:///////`\n${c1}.//:--////:.     -////-`    `:////--://.\n${c1}./:    .////:.     --`    `:////-    :/.\n${c1}`//-`    .////:.        `:////-    `-//`\n${c1} :///-`    .////:.    `:////-    `-///:\n${c1} `/////-`    -///:    :///-    `-/////`\n${c1}  `//////-   `///:    :///`   .//////`\n${c1}   `:////:   `///:    :///`   -////:`\n${c1}     .://:   `///:    :///`   -//:.\n${c1}       .::   `///:    :///`   -:.\n${c1}             `///:    :///`\n${c1}              `...    ...`",
    },
    "Clover": {
        "colors": [2, 6],
        "logo": "${c1}             `oNMMMNNMMMNo`\n${c1}           `oNMMMMMMMMMMMMNo`\n${c1}          oNMMMMMMMMMMMMMMMMNo\n${c1}          `sNMMMMMMMMMMMMMMNs`\n${c1}     `omo`  `sNMMMMMMMMMMNs`  `omo`\n${c1}   `oNMMMNo`  `sNMMMMMMNs`  `oNMMMNo`\n${c1} `oNMMMMMMMNo`  `oNMMNs`  `oNMMMMMMMNo`\n${c1}oNMMMMMMMMMMMNo`  `sy`  `oNMMMMMMMMMMMNo\n${c1}`sNMMMMMMMMMMMMNo.${c2}oNNs${c1}.oNMMMMMMMMMMMMNs`\n${c1}`oNMMMMMMMMMMMMNs.${c2}oNNs${c1}.oNMMMMMMMMMMMMNo`\n${c1}oNMMMMMMMMMMMNs`  `sy`  `oNMMMMMMMMMMMNo\n${c1} `oNMMMMMMMNs`  `oNMMNo`  `oNMMMMMMMNs`\n${c1}   `oNMMMNs`  `sNMMMMMMNs`  `oNMMMNs`\n${c1}     `oNs`  `sNMMMMMMMMMMNs`  `oNs`\n${c1}          `sNMMMMMMMMMMMMMMNs`\n${c1}          +NMMMMMMMMMMMMMMMMNo\n${c1}           `oNMMMMMMMMMMMMNo`\n${c1}             `oNMMMNNMMMNs`\n${c1}               `omo``oNs`",
    },
    "Condres": {
        "colors": [2, 3, 6],
        "logo": "${c1}${c1}`oyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy+${c3}:++.\n${c1}${c2}/o${c1}+oyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy/${c3}oo++.\n${c1}${c2}/y+${c1}syyyyyyyyyyyyyyyyyyyyyyyyyyyyy${c3}+ooo++.\n${c1}${c2}/hy+${c1}oyyyhhhhhhhhhhhhhhyyyyyyyyy${c3}+oo+++++.\n${c1}${c2}/hhh+${c1}shhhhhdddddhhhhhhhyyyyyyy${c3}+oo++++++.\n${c1}${c2}/hhdd+${c1}oddddddddddddhhhhhyyyys${c3}+oo+++++++.\n${c1}${c2}/hhddd+${c1}odmmmdddddddhhhhyyyy${c3}+ooo++++++++.\n${c1}${c2}/hhdddmo${c1}odmmmdddddhhhhhyyy${c3}+oooo++++++++.\n${c1}${c2}/hdddmmms${c1}/dmdddddhhhhyyys${c3}+oooo+++++++++.\n${c1}${c2}/hddddmmmy${c1}/hdddhhhhyyyyo${c3}+oooo++++++++++:\n${c1}${c2}/hhdddmmmmy${c1}:yhhhhyyyyy+${c3}+oooo+++++++++++:\n${c1}${c2}/hhddddddddy${c1}-syyyyyys+${c3}ooooo++++++++++++:\n${c1}${c2}/hhhddddddddy${c1}-+yyyy+${c3}/ooooo+++++++++++++:\n${c1}${c2}/hhhhhdddddhhy${c1}./yo:${c3}+oooooo+++++++++++++/\n${c1}${c2}/hhhhhhhhhhhhhy${c1}:-.${c3}+sooooo+++++++++++///:\n${c1}${c2}:sssssssssssso++${c1}${c3}`:/:--------.````````",
    },
    "CRUX": {
        "colors": [4, 5, 7, 6],
        "logo": "${c1}      oddxkkkxxdoo\n${c1}     ddcoddxxxdoool\n${c1}     xdclodod  olol\n${c1}     xoc  xdd  olol\n${c1}     xdc  ${c2}k00${c1}Okdlol\n${c1}     xxd${c2}kOKKKOkd${c1}ldd\n${c1}     xdco${c2}xOkdlo${c1}dldd\n${c1}     ddc:cl${c2}lll${c1}oooodo\n${c1}   odxxdd${c3}xkO000kx${c1}ooxdo\n${c1}  oxdd${c3}x0NMMMMMMWW0od${c1}kkxo\n${c1} oooxd${c3}0WMMMMMMMMMW0o${c1}dxkx\n${c1}docldkXW${c3}MMMMMMMWWN${c1}Odolco\n${c1}xx${c2}dx${c1}kxxOKN${c3}WMMWN${c1}0xdoxo::c\n${c1}${c2}xOkkO${c1}0oo${c3}odOW${c2}WW${c1}XkdodOxc:l\n${c1}${c2}dkkkxkkk${c3}OKX${c2}NNNX0Oxx${c1}xc:cd\n${c1}${c2} odxxdx${c3}xllod${c2}ddooxx${c1}dc:ldo\n${c1}${c2}   lodd${c1}dolccc${c2}ccox${c1}xoloo",
    },
    "Cucumber": {
        "colors": [2, 3],
        "logo": "${c1}        `:/+//${c2}::--------${c1}:://+/:`\n${c1}      -++/:${c2}----..........----${c1}:/++-\n${c1}    .++:${c2}---...........-......---${c1}:++.\n${c1}   /+:${c2}---....-::/:/--//:::-....---${c1}:+/\n${c1} `++:${c2}--.....:---::/--/::---:.....--${c1}:++`\n${c1} /+:${c2}--.....--.--::::-/::--.--.....--${c1}:+/\n${c1}-o:${c2}--.......-:::://--/:::::-.......--${c1}:o-\n${c1}/+:${c2}--...-:-::---:::..:::---:--:-...--${c1}:+/\n${c1}o/:${c2}-...-:.:.-/:::......::/:.--.:-...-${c1}:/o\n${c1}o/${c2}--...::-:/::/:-......-::::::-/-...-${c1}:/o\n${c1}/+:${c2}--..-/:/:::--:::..:::--::////-..--${c1}:+/\n${c1}-o:${c2}--...----::/:::/--/:::::-----...--${c1}:o-\n${c1} /+:${c2}--....://:::.:/--/:.::://:....--${c1}:+/\n${c1} `++:${c2}--...-:::.--.:..:.--.:/:-...--${c1}:++`\n${c1}   /+:${c2}---....----:-..-:----....---${c1}:+/\n${c1}    .++:${c2}---..................---${c1}:++.\n${c1}      -/+/:${c2}----..........----${c1}:/+/-\n${c1}        `:/+//${c2}::--------:::${c1}/+/:`\n${c1}           `.-://++++++//:-.`",
    },
    "dahlia": {
        "colors": [1, 7, 3],
        "logo": "${c1}                  .#.\n${c1}                *%@@@%*\n${c1}        .,,,,,(&@@@@@@@&/,,,,,.\n${c1}       ,#@@@@@@@@@@@@@@@@@@@@@#.\n${c1}       ,#@@@@@@@&#///#&@@@@@@@#.\n${c1}     ,/%&@@@@@%/,    .,(%@@@@@&#/.\n${c1}   *#&@@@@@@#,.         .*#@@@@@@&#,\n${c1} .&@@@@@@@@@(            .(@@@@@@@@@&&.\n${c1}#@@@@@@@@@@(               )@@@@@@@@@@@#\n${c1} °@@@@@@@@@@(            .(@@@@@@@@@@@°\n${c1}   *%@@@@@@@(.           ,#@@@@@@@%*\n${c1}     ,(&@@@@@@%*.     ./%@@@@@@%(,\n${c1}       ,#@@@@@@@&(***(&@@@@@@@#.\n${c1}       ,#@@@@@@@@@@@@@@@@@@@@@#.\n${c1}        ,*****#&@@@@@@@&(*****,\n${c1}               ,/%@@@%/.\n${c1}                  ,#,",
    },
    "debian_small": {
        "colors": [1, 7, 3],
        "logo": "${c1} /  __ \\\\\n${c1}|  /    |\n${c1}|  \\\\___-\n${c1}-_\n${c1}  --_",
    },
    "Debian": {
        "colors": [1, 7, 3],
        "logo": '${c2}    ,g$$$$$$$$$$$$$$$P.\n${c2}  ,g$$P"     """Y$$.".\n${c2} ,$$P\'              `$$$.\n${c2}\',$$P       ,ggs.     `$$b:\n${c2}`d$$\'     ,$P"\'   ${c1}.${c2}    $$$\n${c2} $$P      d$\'     ${c1},${c2}    $$P\n${c2} $$:      $$.   ${c1}-${c2}    ,d$$\'\n${c2} $$;      Y$b._   _,d$P\'\n${c2} Y$$.    ${c1}`.${c2}`"Y$$$$P"\'\n${c2}${c2} `$$b      ${c1}"-.__\n${c2}${c2}  `Y$$\n${c2}   `Y$$.\n${c2}     `$$b.\n${c2}       `Y$$b.\n${c2}          `"Y$b._\n${c2}              `"""',
    },
    "Deepin": {
        "colors": [2, 7],
        "logo": "${c1}         .';;;;;.       .,;,.\n${c1}      .,;;;;;;;.       ';;;;;;;.\n${c1}    .;::::::::'     .,::;;,''''',.\n${c1}   ,'.::::::::    .;;'.          ';\n${c1}  ;'  'cccccc,   ,' :: '..        .:\n${c1} ,,    :ccccc.  ;: .c, '' :.       ,;\n${c1}.l.     cllll' ., .lc  :; .l'       l.\n${c1}.c       :lllc  ;cl:  .l' .ll.      :'\n${c1}.l        'looc. .   ,o:  'oo'      c,\n${c1}.o.         .:ool::coc'  .ooo'      o.\n${c1} ::            .....   .;dddo      ;c\n${c1}  l:...            .';lddddo.     ,o\n${c1}   lxxxxxdoolllodxxxxxxxxxc      :l\n${c1}    ,dxxxxxxxxxxxxxxxxxxl.     'o,\n${c1}      ,dkkkkkkkkkkkkko;.    .;o;\n${c1}        .;okkkkkdl;.    .,cl:.\n${c1}            .,:cccccccc:,.",
    },
    "DesaOS": {
        "colors": [2, 7],
        "logo": "${c1}███████████████████████\n${c1}███████████████████████\n${c1}███████████████████████\n${c1}████████               ███████\n${c1}████████               ███████\n${c1}████████               ███████\n${c1}████████               ███████\n${c1}████████               ███████\n${c1}████████               ███████\n${c1}████████               ███████\n${c1}██████████████████████████████\n${c1}██████████████████████████████\n${c1}████████████████████████\n${c1}████████████████████████\n${c1}████████████████████████",
    },
    "Devuan": {
        "colors": [5, 7],
        "logo": "${c1}           `':ddd;:,.\n${c1}                 `'dPPd:,.\n${c1}                     `:b$$b`.\n${c1}                        'P$$$d`\n${c1}                         .$$$$$`\n${c1}                         ;$$$$$P\n${c1}                      .:P$$$$$$`\n${c1}                  .,:b$$$$$$$;'\n${c1}             .,:dP$$$$$$$$b:'\n${c1}      .,:;db$$$$$$$$$$Pd'`\n${c1} ,db$$$$$$$$$$$$$$b:'`\n${c1}:$$$$$$$$$$$$b:'`\n${c1} `$$$$$bd:''`\n${c1}   `'''`",
    },
    "DracOS": {
        "colors": [1, 7, 3],
        "logo": "${c1}          -os:\n${c1}            -os/`\n${c1}              :sy+-`\n${c1}               `/yyyy+.\n${c1}                 `+yyyyo-\n${c1}                   `/yyyys:\n${c1}`:osssoooo++-        +yyyyyy/`\n${c1}   ./yyyyyyo         yo`:syyyy+.\n${c1}      -oyyy+         +-   :yyyyyo-\n${c1}        `:sy:        `.    `/yyyyys:\n${c1}           ./o/.`           .oyyso+oo:`\n${c1}              :+oo+//::::///:-.`     `.`",
    },
    "DarkOs": {
        "colors": [1, 6, 5, 3, 2],
        "logo": "${c3}${c1}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⠋⡆⢹⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c5}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡆⢀⣤⢛⠛⣠⣿⠀⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c6}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⣿⠟⣡⠊⣠⣾⣿⠃⣠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c2}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣯⣿⠀⠊⣤⣿⣿⣿⠃⣴⣧⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c1}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣶⣿⣿⡟⣠⣶⣿⣿⣿⢋⣤⠿⠛⠉⢁⣭⣽⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c4}  ⠀⠀⠀⠀⠀⠀ ⠀⣠⠖⡭⢉⣿⣯⣿⣯⣿⣿⣿⣟⣧⠛⢉⣤⣶⣾⣿⣿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c5}⠀⠀⠀⠀⠀⠀⠀⠀⣴⣫⠓⢱⣯⣿⢿⠋⠛⢛⠟⠯⠶⢟⣿⣯⣿⣿⣿⣿⣿⣿⣦⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c2}⠀⠀⠀⠀⠀⠀⢀⡮⢁⣴⣿⣿⣿⠖⣠⠐⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠛⠛⠛⢿⣶⣄⠀⠀⠀⠀⠀⠀⠀\n${c3}${c3}⠀⠀⠀⠀⢀⣤⣷⣿⣿⠿⢛⣭⠒⠉⠀⠀⠀⣀⣀⣄⣤⣤⣴⣶⣶⣶⣿⣿⣿⣿⣿⠿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c1}⠀⢀⣶⠏⠟⠝⠉⢀⣤⣿⣿⣶⣾⣿⣿⣿⣿⣿⣿⣟⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c6}⢴⣯⣤⣶⣿⣿⣿⣿⣿⡿⣿⣯⠉⠉⠉⠉⠀⠀⠀⠈⣿⡀⣟⣿⣿⢿⣿⣿⣿⣿⣿⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c5}⠀⠀⠀⠉⠛⣿⣧⠀⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⠃⣿⣿⣯⣿⣦⡀⠀⠉⠻⣿⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c3}⠀⠀⠀⠀⠀⠀⠉⢿⣮⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠀⣯⠉⠉⠛⢿⣿⣷⣄⠀⠈⢻⣆⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c2}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠢⠀⠀⠀⠀⠀⠀⠀⢀⢡⠃⣾⣿⣿⣦⠀⠀⠀⠙⢿⣿⣤⠀⠙⣄⠀⠀⠀⠀⠀⠀⠀\n${c3}${c6}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⢋⡟⢠⣿⣿⣿⠋⢿⣄⠀⠀⠀⠈⡄⠙⣶⣈⡄⠀⠀⠀⠀⠀⠀\n${c3}${c1}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠚⢲⣿⠀⣾⣿⣿⠁⠀⠀⠉⢷⡀⠀⠀⣇⠀⠀⠈⠻⡀⠀⠀⠀⠀⠀\n${c3}${c4}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢢⣀⣿⡏⠀⣿⡿⠀⠀⠀⠀⠀⠀⠙⣦⠀⢧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c3}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠿⣧⣾⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣮⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n${c3}${c5}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠙⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
    },
    "Itc": {
        "colors": [1],
        "logo": "${c1}${c1}....................-==============:...\n${c1}${c1}...:===========-....-==============:...\n${c1}${c1}...-===========:....-==============-...\n${c1}${c1}....*==========+........-::********-...\n${c1}${c1}....*===========+.:*====**==*+-.-......\n${c1}${c1}....:============*+-..--:+**====*---...\n${c1}${c1}......::--........................::...\n${c1}${c1}..+-:+-.+::*:+::+:-++::++-.:-.*.:++:++.\n${c1}${c1}..:-:-++++:-::--:+::-::.:++-++:++--:-:.    ⠀⠀⠀⠀⠀\n${c1}⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
    },
    "dragonfly_old": {
        "colors": [1, 7, 3],
        "logo": '${c1}                 ${c3} ()${c1}I${c3}()\n${c1}            ${c1} "==.__:-:__.=="\n${c1}            "==.__/~|~\\__.=="\n${c1}            "==._(  Y  )_.=="\n${c1} ${c2}.-\'~~""~=--...,__${c1}\\/|\\/${c2}__,...--=~""~~\'-.\n${c1}(               ..=${c1}\\\\=${c1}/${c2}=..               )\n${c1} `\'-.        ,.-"`;${c1}/=\\\\${c2};"-.,_        .-\'`\n${c1}     `~"-=-~` .-~` ${c1}|=|${c2} `~-. `~-=-"~`\n${c1}          .-~`    /${c1}|=|${c2}\\    `~-.\n${c1}       .~`       / ${c1}|=|${c2} \\       `~.\n${c1}   .-~`        .\'  ${c1}|=|${c2}  `.        `~-.\n${c1} (`     _,.-="`  ${c1}  |=|${c2}    `"=-.,_     `)\n${c1}  `~"~"`        ${c1}   |=|${c2}           `"~"~`\n${c1}                 ${c1}  /=\\\\\n${c1}                   \\\\=/\n${c1}                    ^',
    },
    "dragonfly_small": {
        "colors": [1, 7, 3],
        "logo": "${c2}('-_${c1}|${c2}_-')\n${c2} >--${c1}|${c2}--<\n${c2}(_-'${c1}|${c2}'-_)\n${c2}    ${c1}|\n${c2}    |\n${c2}    |",
    },
    "DragonFly": {
        "colors": [1, 7, 3],
        "logo": "${c2}${c2}|   `-,       ${c1},^,       ${c2},-'   |\n${c2}${c2} `,    `-,   ${c3}(/ \\)   ${c2},-'    ,'\n${c2}${c2}   `-,    `-,${c1}/   \\${c2},-'    ,-'\n${c2}${c2}      `------${c1}(   )${c2}------'\n${c2}${c2}  ,----------${c1}(   )${c2}----------,\n${c2}${c2} |        _,-${c1}(   )${c2}-,_        |\n${c2}${c2}  `-,__,-'   ${c1}\\   /${c2}   `-,__,-'\n${c2}${c1}              | |\n${c2}              | |\n${c2}              | |\n${c2}              | |\n${c2}              | |\n${c2}              | |\n${c2}              `|'",
    },
    "Drauger": {
        "colors": [1, 7],
        "logo": "${c1}                `:+``+:`\n${c1}               `/++``++/.\n${c1}              .++/.  ./++.\n${c1}             :++/`    `/++:\n${c1}           `/++:        :++/`\n${c1}          ./+/-          -/+/.\n${c1}         -++/.            ./++-\n${c1}        :++:`              `:++:\n${c1}      `/++-                  -++/`\n${c1}     ./++.                    ./+/.\n${c1}    -++/`                      `/++-\n${c1}   :++:`                        `:++:\n${c1} `/++-                            -++/`\n${c1}.:-.`..............................`.-:.\n${c1}`.-/++++++++++++++++++++++++++++++++/-.`",
    },
    "elementary_small": {
        "colors": [4, 7, 1],
        "logo": "${c2} / ____  \\\\\n${c2}/  |  /  /\\\\\n${c2}|__\\\\ /  / |\n${c2}\\\\   /__/  /\n${c2} \\\\_______/",
    },
    "Elementary": {
        "colors": [4, 7, 1],
        "logo": "${c2}      eeeeeeeeeeeeeeeeeeeeeee\n${c2}    eeeee  eeeeeeeeeeee   eeeee\n${c2}  eeee   eeeee       eee     eeee\n${c2} eeee   eeee          eee     eeee\n${c2}eee    eee            eee       eee\n${c2}eee   eee            eee        eee\n${c2}ee    eee           eeee       eeee\n${c2}ee    eee         eeeee      eeeeee\n${c2}ee    eee       eeeee      eeeee ee\n${c2}eee   eeee   eeeeee      eeeee  eee\n${c2}eee    eeeeeeeeee     eeeeee    eee\n${c2} eeeeeeeeeeeeeeeeeeeeeeee    eeeee\n${c2}  eeeeeeee eeeeeeeeeeee      eeee\n${c2}    eeeee                 eeeee\n${c2}      eeeeeee         eeeeeee\n${c2}         eeeeeeeeeeeeeeeee",
    },
    "EndeavourOS": {
        "colors": [1, 5, 4],
        "logo": "${c1}${c1}                   ./${c2}sssso${c3}-\n${c1}${c1}                 `:${c2}osssssss+${c3}-\n${c1}${c1}               `:+${c2}sssssssssso${c3}/.\n${c1}${c1}             `-/o${c2}ssssssssssssso${c3}/.\n${c1}${c1}           `-/+${c2}sssssssssssssssso${c3}+:`\n${c1}${c1}         `-:/+${c2}sssssssssssssssssso${c3}+/.\n${c1}${c1}       `.://o${c2}sssssssssssssssssssso${c3}++-\n${c1}${c1}      .://+${c2}ssssssssssssssssssssssso${c3}++:\n${c1}${c1}    .:///o${c2}ssssssssssssssssssssssssso${c3}++:\n${c1}${c1}  `:////${c2}ssssssssssssssssssssssssssso${c3}+++.\n${c1}${c1}`-////+${c2}ssssssssssssssssssssssssssso${c3}++++-\n${c1}${c1} `..-+${c2}oosssssssssssssssssssssssso${c3}+++++/`\n${c1}   ./++++++++++++++++++++++++++++++/:.\n${c1}  `:::::::::::::::::::::::::------``",
    },
    "Endless": {
        "colors": [1, 7],
        "logo": "${c1}        -odMMNhso//////oshNMMdo-\n${c1}      /dMMh+.              .+hMMd/\n${c1}    /mMNo`                    `oNMm:\n${c1}  `yMMo`                        `oMMy`\n${c1} `dMN-                            -NMd`\n${c1} hMN.                              .NMh\n${c1}/MM/                  -os`          /MM/\n${c1}dMm    `smNmmhs/- `:sNMd+   ``       mMd\n${c1}MMy    oMd--:+yMMMMMNo.:ohmMMMNy`    yMM\n${c1}MMy    -NNyyhmMNh+oNMMMMMy:.  dMo    yMM\n${c1}dMm     `/++/-``/yNNh+/sdNMNddMm-    mMd\n${c1}/MM/          `dNy:       `-::-     /MM/\n${c1} hMN.                              .NMh\n${c1} `dMN-                            -NMd`\n${c1}  `yMMo`                        `oMMy`\n${c1}    /mMNo`                    `oNMm/\n${c1}      /dMMh+.              .+hMMd/\n${c1}        -odMMNhso//////oshNMMdo-\n${c1}           `:+yhmNMMMMNmhy+:`",
    },
    "EuroLinux": {
        "colors": [4, 7],
        "logo": "${c1}         -wwwWWWWWWWWWwww-\n${c1}        -WWWWWWWWWWWWWWWWWWw-\n${c1}          \\WWWWWWWWWWWWWWWWWWW-\n${c1}  _Ww      `WWWWWWWWWWWWWWWWWWWw\n${c1} -W${c2}E${c1}Www                -WWWWWWWWW-\n${c1}_WW${c2}U${c1}WWWW-                _WWWWWWWW\n${c1}_WW${c2}R${c1}WWWWWWWWWWWWWWWWWWWWWWWWWWWWWW-\n${c1}wWW${c2}O${c1}WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW\n${c1}WWW${c2}L${c1}WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWw\n${c1}WWW${c2}I${c1}WWWWWWWWWWWWWWWWWWWWWWWWWWWWww-\n${c1}wWW${c2}N${c1}WWWWw\n${c1} WW${c2}U${c1}WWWWWWw\n${c1} wW${c2}X${c1}WWWWWWWWww\n${c1}   wWWWWWWWWWWWWWWWw\n${c1}    wWWWWWWWWWWWWWWWw\n${c1}       WWWWWWWWWWWWWw\n${c1}           wWWWWWWWw",
    },
    "Exherbo": {
        "colors": [4, 7, 1],
        "logo": "${c2}OXo.\n${c2}NXdX0:    .cok0KXNNXXK0ko:.\n${c2}KX  '0XdKMMK;.xMMMk, .0MMMMMXx;  ...\n${c2}'NO..xWkMMx   kMMM    cMMMMMX,NMWOxOXd.\n${c2}  cNMk  NK    .oXM.   OMMMMO. 0MMNo  kW.\n${c2}  lMc   o:       .,   .oKNk;   ;NMMWlxW'\n${c2} ;Mc    ..   .,,'    .0M${c1}g;${c2}WMN'dWMMMMMMO\n${c2} XX        ,WMMMMW.  cM${c1}cfli${c2}WMKlo.   .kMk\n${c2}.Mo        .WM${c1}GD${c2}MW.   XM${c1}WO0${c2}MMk        oMl\n${c2},M:         ,XMMWx::,''oOK0x;          NM.\n${c2}'Ml      ,kNKOxxxxxkkO0XXKOd:.         oMk\n${c2} NK    .0Nxc${c3}:::::::::::::::${c2}fkKNk,      .MW\n${c2} ,Mo  .NXc${c3}::${c2}qXWXb${c3}::::::::::${c2}oo${c3}::${c2}lNK.    .MW\n${c2}  ;Wo oMd${c3}:::${c2}oNMNP${c3}::::::::${c2}oWMMMx${c3}:${c2}c0M;   lMO\n${c2}   'NO;W0c${c3}:::::::::::::::${c2}dMMMMO${c3}::${c2}lMk  .WM'\n${c2}     xWONXdc${c3}::::::::::::::${c2}oOOo${c3}::${c2}lXN. ,WMd\n${c2}      'KWWNXXK0Okxxo,${c3}:::::::${c2},lkKNo  xMMO\n${c2}        :XMNxl,';:lodxkOO000Oxc. .oWMMo\n${c2}          'dXMMXkl;,.        .,o0MMNo'\n${c2}             ':d0XWMMMMWNNNNMMMNOl'\n${c2}                   ':okKXWNKkl'",
    },
    "fedora_small": {
        "colors": [4, 7, 1],
        "logo": "${c2}     /   __)${c1}\\\\${c2}\n${c2}     |  /  ${c1}\\\\ \\\\${c2}\n${c2}  ${c1}__${c2}_|  |_${c1}_/ /${c2}\n${c2} ${c1}/ ${c2}(_    _)${c1}_/${c2}\n${c2}${c1}/ /${c2}  |  |\n${c2}${c1}\\\\ \\\\${c2}__/  |\n${c2} ${c1}\\\\${c2}(_____/",
    },
    "Feren": {
        "colors": [4, 7, 1],
        "logo": "${c1} :+ooooooooo+.\n${c1}-o+oooooooooo+-\n${c1}..`/+++++++++++/...`````````````````\n${c1}   .++++++++++++++++++++++++++/////-\n${c1}    ++++++++++++++++++++++++++++++++//:`\n${c1}    -++++++++++++++++++++++++++++++/-`\n${c1}     ++++++++++++++++++++++++++++:.\n${c1}     -++++++++++++++++++++++++/.\n${c1}      +++++++++++++++++++++/-`\n${c1}      -++++++++++++++++++//-`\n${c1}        .:+++++++++++++//////-\n${c1}           .:++++++++//////////-\n${c1}             `-++++++---:::://///.\n${c1}           `.:///+++.             `\n${c1}          `.........",
    },
    "freebsd_small": {
        "colors": [1, 7, 3],
        "logo": "${c1}\\\\_)       (_/\n${c1}|           |\n${c1}|           |\n${c1} ;         ;\n${c1}  '-_____-'",
    },
    "FreeMiNT": {
        "colors": [7],
        "logo": "${c1}          ##         #########\n${c1}                    ####      ##\n${c1}            ####  ####        ##\n${c1}####        ####  ##        ##\n${c1}        ####    ####      ##  ##\n${c1}        ####  ####  ##  ##  ##\n${c1}            ####  ######\n${c1}        ######  ##  ##  ####\n${c1}      ####    ################\n${c1}    ####        ##  ####\n${c1}    ##            ####  ######\n${c1}    ##      ##    ####  ####\n${c1}    ##    ##  ##    ##  ##  ####\n${c1}      ####  ##          ##  ##",
    },
    "Frugalware": {
        "colors": [4, 7, 1],
        "logo": "${c1}         /o+++++++++/::-.`\n${c1}        `o+++++++++++++++o++/::-.`\n${c1}        /+++++++++++++++++++++++oo++/:-.``\n${c1}       .o+ooooooooooooooooooosssssssso++oo++/:-`\n${c1}       ++osoooooooooooosssssssssssssyyo+++++++o:\n${c1}      -o+ssoooooooooooosssssssssssssyyo+++++++s`\n${c1}      o++ssoooooo++++++++++++++sssyyyyo++++++o:\n${c1}     :o++ssoooooo${c2}/-------------${c1}+syyyyyo+++++oo\n${c1}    `o+++ssoooooo${c2}/-----${c1}+++++ooosyyyyyyo++++os:\n${c1}    /o+++ssoooooo${c2}/-----${c1}ooooooosyyyyyyyo+oooss\n${c1}   .o++++ssooooos${c2}/------------${c1}syyyyyyhsosssy-\n${c1}   ++++++ssooooss${c2}/-----${c1}+++++ooyyhhhhhdssssso\n${c1}  -s+++++syssssss${c2}/-----${c1}yyhhhhhhhhhhhddssssy.\n${c1}  sooooooyhyyyyyh${c2}/-----${c1}hhhhhhhhhhhddddyssy+\n${c1} :yooooooyhyyyhhhyyyyyyhhhhhhhhhhdddddyssy`\n${c1} yoooooooyhyyhhhhhhhhhhhhhhhhhhhddddddysy/\n${c1}-ysooooooydhhhhhhhhhhhddddddddddddddddssy\n${c1} .-:/+osssyyyysyyyyyyyyyyyyyyyyyyyyyyssy:\n${c1}       ``.-/+oosysssssssssssssssssssssss\n${c1}               ``.:/+osyysssssssssssssh.\n${c1}                        `-:/+osyyssssyo\n${c1}                                .-:+++`",
    },
    "Funtoo": {
        "colors": [5, 7],
        "logo": "${c1}  :XXl;:.                      .OXo\n${c1}.'OXO''  .''''''''''''''''''''':XNd..'oco.lco,\n${c1}xXXXXXX, cXXXNNNXXXXNNXXXXXXXXNNNNKOOK; d0O .k\n${c1}  kXX  xXo  KNNN0  KNN.       'xXNo   :c; 'cc.\n${c1}  kXX  xNo  KNNN0  KNN. :xxxx. 'NNo\n${c1}  kXX  xNo  loooc  KNN. oNNNN. 'NNo\n${c1}  kXX  xN0:.       KNN' oNNNX' ,XNk\n${c1}  kXX  xNNXNNNNNNNNXNNNNNNNNXNNOxXNX0Xl\n${c1}  ...  ......................... .;cc;.",
    },
    "GalliumOS": {
        "colors": [4, 7, 1],
        "logo": "${c1}yyooooooooooooooooooooooooooooooooo+/:::\n${c1}yyysoooooooooooooooooooooooooooo+/::::::\n${c1}yyyyyoooooooooooooooooooooooo+/:::::::::\n${c1}yyyyyysoooooooooooooooooo++/::::::::::::\n${c1}yyyyyyysoooooooooooooo++/:::::::::::::::\n${c1}yyyyyyyyysoooooo${c2}sydddys${c1}+/:::::::::::::::\n${c1}yyyyyyyyyysooo${c2}smMMMMMMMNd${c1}+::::::::::::::\n${c1}yyyyyyyyyyyyo${c2}sMMMMMMMMMMMN${c1}/:::::::::::::\n${c1}yyyyyyyyyyyyy${c2}dMMMMMMMMMMMM${c1}o//:::::::::::\n${c1}yyyyyyyyyyyyy${c2}hMMMMMMMMMMMm${c1}--//::::::::::\n${c1}yyyyyyyyyyyyyy${c2}hmMMMMMMMNy${c1}:..-://::::::::\n${c1}yyyyyyyyyyyyyyy${c2}yyhhyys+:${c1}......://:::::::\n${c1}yyyyyyyyyyyyyyys+:--...........-///:::::\n${c1}yyyyyyyyyyyys+:--................://::::\n${c1}yyyyyyyyyo+:-.....................-//:::\n${c1}yyyyyyo+:-..........................://:\n${c1}yyyo+:-..............................-//\n${c1}o/:-...................................:",
    },
    "Garuda": {
        "colors": [7, 7],
        "logo": '${c1}            _╓╗╣╫╠╠╠╠╠╠╠╠╠╠╠╠╠╕╗╗┐_\n${c1}         ╥╢╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╥,\n${c1}       ╗╠╠╠╠╠╠╠╝╜╜╜╜╝╢╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠┐\n${c1}      ╣╠╠╠╠╠╠╠╠╢╣╢╗╕ , `"╘╠╠╠╠╠╠╠╠╠╠╠╠╠╠╔╥_\n${c1}    ╒╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╕╙╥╥╜   `"╜╠╬╠╠╠╠╠╠╠╠╠╠╠╥,\n${c1}    ╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╗╥╥╥╥╗╗╬╠╠╠╠╠╠╠╝╙╠╠╣╠╠╠╠╢┐\n${c1}   ╣╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╥╬╣╠╠╠╠╠╠╠╠╗\n${c1}  ╒╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╗\n${c1}  ╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠\n${c1}  ╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╬     ```"╜╝╢╠╠╡\n${c1} ╒╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╣,         ╘╠╪\n${c1} ╞╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╢┐        ╜\n${c1} `╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╗\n${c1} ,╬╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠"╕\n${c1} ╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╗\n${c1} ╝^╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╝╣╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╠╡\n${c1}  ╔╜`╞┘╢╛╜ ╡╢╠"╚╠╠╜╝┌╞╞"╢╠╠╠╠╠╠╠╠╠╠╣╩╢╪\n${c1}     ╜╒"   `╜    `      ╜╙╕  └╣╠╠╠╠╕ ╞╙╖\n${c1}                                ╠╠╠\n${c1}                                 ╜',
    },
    "gentoo_small": {
        "colors": [5, 7],
        "logo": "${c1}(       \\\\\n${c1}\\    0   \\\\\n${c1}${c2} \\        )\n${c1} /      _/\n${c1}(     _-\n${c1}\\____-",
    },
    "Gentoo": {
        "colors": [5, 7],
        "logo": "${c1}     -o${c2}dNMMMMMMMMNNmhy+${c1}-`\n${c1}   -y${c2}NMMMMMMMMMMMNNNmmdhy${c1}+-\n${c1} `o${c2}mMMMMMMMMMMMMNmdmmmmddhhy${c1}/`\n${c1} om${c2}MMMMMMMMMMMN${c1}hhyyyo${c2}hmdddhhhd${c1}o`\n${c1}.y${c2}dMMMMMMMMMMd${c1}hs++so/s${c2}mdddhhhhdm${c1}+`\n${c1} oy${c2}hdmNMMMMMMMN${c1}dyooy${c2}dmddddhhhhyhN${c1}d.\n${c1}  :o${c2}yhhdNNMMMMMMMNNNmmdddhhhhhyym${c1}Mh\n${c1}    .:${c2}+sydNMMMMMNNNmmmdddhhhhhhmM${c1}my\n${c1}       /m${c2}MMMMMMNNNmmmdddhhhhhmMNh${c1}s:\n${c1}    `o${c2}NMMMMMMMNNNmmmddddhhdmMNhs${c1}+`\n${c1}  `s${c2}NMMMMMMMMNNNmmmdddddmNMmhs${c1}/.\n${c1} /N${c2}MMMMMMMMNNNNmmmdddmNMNdso${c1}:`\n${c1}+M${c2}MMMMMMNNNNNmmmmdmNMNdso${c1}/-\n${c1}yM${c2}MNNNNNNNmmmmmNNMmhs+/${c1}-`\n${c1}/h${c2}MMNNNNNNNNMNdhs++/${c1}-`\n${c1}`/${c2}ohdmmddhys+++/:${c1}.`\n${c1}  `-//////:--.",
    },
    "Pentoo": {
        "colors": [5, 7],
        "logo": "${c2}        :yNMMMMMMMMMMMMMMMMNy:\n${c2}      :dMMMMMMMMMMMMMMMMMMMMMMd:\n${c2}     oMMMMMMMho/-....-/ohMMMMMMMo\n${c2}    oMMMMMMy.            .yMMMMMMo\n${c2}   .MMMMMMo                oMMMMMM.\n${c2}   +MMMMMm                  mMMMMM+\n${c2}   oMMMMMh                  hMMMMMo\n${c2} //hMMMMMm//${c1}`${c2}          ${c1}`${c2}////mMMMMMh//\n${c2}MMMMMMMMMMM${c1}/${c2}      ${c1}/o/`${c2}  ${c1}.${c2}smMMMMMMMMMMM\n${c2}MMMMMMMMMMm      ${c1}`NMN:${c2}    ${c1}.${c2}yMMMMMMMMMM\n${c2}MMMMMMMMMMMh${c1}:.${c2}              dMMMMMMMMM\n${c2}MMMMMMMMMMMMMy${c1}.${c2}            ${c1}-${c2}NMMMMMMMMM\n${c2}MMMMMMMMMMMd:${c1}`${c2}           ${c1}-${c2}yNMMMMMMMMMM\n${c2}MMMMMMMMMMh${c1}`${c2}          ${c1}./${c2}hNMMMMMMMMMMMM\n${c2}MMMMMMMMMM${c1}s${c2}        ${c1}.:${c2}ymMMMMMMMMMMMMMMM\n${c2}MMMMMMMMMMN${c1}s:..-/${c2}ohNMMMMMMMMMMMMMMMMMM\n${c2}MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n${c2}MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n${c2} MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM",
    },
    "gNewSense": {
        "colors": [4, 5, 7, 6],
        "logo": "${c1}               .oocchhhhhhhhhhccoo.\n${c1}        .ochhlllllllc hhhhhh ollllllhhco.\n${c1}    ochlllllllllll hhhllllllhhh lllllllllllhco\n${c1} .cllllllllllllll hlllllo  +hllh llllllllllllllc.\n${c1}ollllllllllhco''  hlllllo  +hllh  ``ochllllllllllo\n${c1}hllllllllc'       hllllllllllllh       `cllllllllh\n${c1}ollllllh          +llllllllllll+          hllllllo\n${c1} `cllllh.           ohllllllho           .hllllc'\n${c1}    ochllc.            ++++            .cllhco\n${c1}       `+occooo+.                .+ooocco+'\n${c1}              `+oo++++      ++++oo+'",
    },
    "GNOME": {
        "colors": [4],
        "logo": "${c1}                 @@@@@@      @@@@@@@@@@@@\n${c1}        ,@@.    @@@@@@@    *@@@@@@@@@@@@\n${c1}       @@@@@%   @@@@@@(    @@@@@@@@@@@&\n${c1}       @@@@@@    @@@@*     @@@@@@@@@#\n${c1}@@@@*   @@@@,              *@@@@@%\n${c1}@@@@@.\n${c1} @@@@#         @@@@@@@@@@@@@@@@\n${c1}         ,@@@@@@@@@@@@@@@@@@@@@@@,\n${c1}      ,@@@@@@@@@@@@@@@@@@@@@@@@@@&\n${c1}    .@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n${c1}    @@@@@@@@@@@@@@@@@@@@@@@@@@@\n${c1}   @@@@@@@@@@@@@@@@@@@@@@@@(\n${c1}   @@@@@@@@@@@@@@@@@@@@%\n${c1}    @@@@@@@@@@@@@@@@\n${c1}     @@@@@@@@@@@@*        @@@@@@@@/\n${c1}      &@@@@@@@@@@        @@@@@@@@@*\n${c1}        @@@@@@@@@@@,    @@@@@@@@@*\n${c1}          ,@@@@@@@@@@@@@@@@@@@@&\n${c1}              &@@@@@@@@@@@@@@\n${c1}                     ...",
    },
    "GNU": {
        "colors": [7, 7],
        "logo": "${c1}  .'   .- - |          | - -.  `.\n${c1} /.'  /                     `.   \\\n${c1}:/   :      _...   ..._      ``   :\n${c1}::   :     /._ .`:'_.._\\.    ||   :\n${c1}::    `._ ./  ,`  :    \\ . _.''   .\n${c1}`:.      /   |  -.  \\-. \\\\_      /\n${c1}  \\:._ _/  .'   .@)  \\@) ` `\\ ,.'\n${c1}     _/,--'       .- .\\,-.`--`.\n${c1}       ,'/''     (( \\ `  )\n${c1}        /'/'  \\    `-'  (\n${c1}         '/''  `._,-----'\n${c1}          ''/'    .,---'\n${c1}           ''/'      ;:\n${c1}             ''/''  ''/\n${c1}               ''/''/''\n${c1}                 '/'/'\n${c1}                  `;",
    },
    "GoboLinux": {
        "colors": [5, 4, 6, 2],
        "logo": "${c1} / ____|     | |\n${c1}| |  __  ___ | |__   ___\n${c1}| | |_ |/ _ \\| '_ \\ / _ \\\n${c1}| |__| | (_) | |_) | (_) |\n${c1} \\_____|\\___/|_.__/ \\___/",
    },
    "Grombyang": {
        "colors": [4, 2, 1],
        "logo": "${c1}         eeeeeeeeeeeeeeeee\n${c1}      eeeeeeeeeeeeeeeeeeeeeee\n${c1}    eeeee       ${c2}.o+       ${c1}eeee\n${c1}  eeee         ${c2}`ooo/         ${c1}eeee\n${c1} eeee         ${c2}`+oooo:         ${c1}eeee\n${c1}eee          ${c2}`+oooooo:          ${c1}eee\n${c1}eee          ${c2}-+oooooo+:         ${c1}eee\n${c1}ee         ${c2}`/:oooooooo+:         ${c1}ee\n${c1}ee        ${c2}`/+   +++    +:        ${c1}ee\n${c1}ee              ${c2}+o+\\             ${c1}ee\n${c1}eee             ${c2}+o+\\            ${c1}eee\n${c1}eee        ${c2}//  \\\\ooo/  \\\\\\        ${c1}eee\n${c1} eee      ${c2}//++++oooo++++\\\\\\     ${c1}eee\n${c1}  eeee    ${c2}::::++oooo+:::::   ${c1}eeee\n${c1}    eeeee   ${c3}Grombyang OS ${c1}  eeee\n${c1}      eeeeeeeeeeeeeeeeeeeeeee\n${c1}         eeeeeeeeeeeeeeeee",
    },
    "guix_small": {
        "colors": [3, 7, 6, 1, 8],
        "logo": "${c1}|__ \\\\        / __|\n${c1}   \\\\ \\\\      / /\n${c1}    \\\\ \\\\    / /\n${c1}     \\\\ \\\\  / /\n${c1}      \\\\ \\\\/ /\n${c1}       \\\\__/",
    },
    "Guix": {
        "colors": [3, 7, 6, 1, 8],
        "logo": "${c1} `--..```..`           `..```..--`\n${c1}   .-:///-:::.       `-:::///:-.\n${c1}      ````.:::`     `:::.````\n${c1}           -//:`    -::-\n${c1}            ://:   -::-\n${c1}            `///- .:::`\n${c1}             -+++-:::.\n${c1}              :+/:::-\n${c1}              `-....`",
    },
    "haiku_small": {
        "colors": [2, 8],
        "logo": "${c1}      /   \\\\\n${c1}*--_ ;     ; _--*\n${c1}\\\\   '\"     \"'   /\n${c1} '.           .'\n${c1}.-'\"         \"'-.\n${c1} '-.__.   .__.-'\n${c1}       |_|",
    },
    "Haiku": {
        "colors": [2, 8],
        "logo": "${c2}       'l:;'${c1},${c2}'ck.    .;dc:.\n${c2}       co    ${c1}..${c2}k.  .;;   ':o.\n${c2}       co    ${c1}..${c2}k. ol      ${c1}.${c2}0.\n${c2}       co    ${c1}..${c2}k. oc     ${c1}..${c2}0.\n${c2}       co    ${c1}..${c2}k. oc     ${c1}..${c2}0.\n${c2}.Ol,.  co ${c1}...''${c2}Oc;kkodxOdddOoc,.\n${c2} ';lxxlxOdxkxk0kd${c1}oooll${c2}dl${c1}ccc:${c2}clxd;\n${c2}     ..${c1}oOolllllccccccc:::::${c2}od;\n${c2}       cx:ooc${c1}:::::::;${c2}cooolcX.\n${c2}       cd${c1}.${c2}''cloxdoollc' ${c1}...${c2}0.\n${c2}       cd${c1}......${c2}k;${c1}.${c2}xl${c1}....  .${c2}0.\n${c2}       .::c${c1};..${c2}cx;${c1}.${c2}xo${c1}..... .${c2}0.\n${c2}          '::c'${c1}...${c2}do${c1}..... .${c2}K,\n${c2}                  cd,.${c1}....:${c2}O,${c1}\n${c2}                    ':clod:'${c1}\n${c2}                        ${c1}",
    },
    "Huayra": {
        "colors": [4, 7],
        "logo": "${c2}            .       .       `\n${c2}       ``    -      .      .\n${c2}        `.`   -` `. -  `` .`\n${c2}          ..`-`-` + -  / .`     ```\n${c2}          .--.+--`+:- :/.` .-``.`\n${c2}            -+/so::h:.d-`./:`.`\n${c2}              :hNhyMomy:os-...-.  ````\n${c2}               .dhsshNmNhoo+:-``.```\n${c2}                ${c1}`ohy:-${c2}NMds+::-.``\n${c2}            ````${c1}.hNN+`${c2}mMNho/:-....````\n${c2}       `````     `../dmNhoo+/:..``\n${c2}    ````            .dh++o/:....`\n${c2}.+s/`                `/s-.-.:.`` ````\n${c2}::`                    `::`..`\n${c2}                          .` `..\n${c2}                                ``",
    },
    "hyperbola_small": {
        "colors": [8],
        "logo": "${c1}    \\____/\n${c1}    .--.\n${c1}   /    \\\\\n${c1}  /  ___ \\\\\n${c1} / .`   `.\\\\\n${c1}/.`      `.\\\\",
    },
    "Hyperbola": {
        "colors": [8],
        "logo": "${c1}                     KX              W\n${c1}                    WO0W          NX0O\n${c1}                    NOO0NW  WNXK0OOKW\n${c1}                    W0OOOOOOOOOOOOKN\n${c1}                     N0OOOOOOO0KXW\n${c1}                       WNXXXNW\n${c1}                 NXK00000KN\n${c1}             WNK0OOOOOOOOOO0W\n${c1}           NK0OOOOOOOOOOOOOO0W\n${c1}         X0OOOOOOO00KK00OOOOOK\n${c1}       X0OOOO0KNWW      WX0OO0W\n${c1}     X0OO0XNW              KOOW\n${c1}   N00KNW                   KOW\n${c1} NKXN                       W0W\n${c1}WW                           W",
    },
    "Kali": {
        "colors": [4, 8],
        "logo": "${c1}            ..,;:ccc,.\n${c1}          ......''';lxO.\n${c1}.....''''..........,:ld;\n${c1}           .';;;:::;,,.x,\n${c1}      ..'''.            0Xxoc:,.  ...\n${c1}  ....                ,ONkc;,;cokOdc',.\n${c1} .                   OMo           ':${c2}dd${c1}o.\n${c1}                    dMc               :OO;\n${c1}                    0M.                 .:o.\n${c1}                    ;Wd\n${c1}                     ;XO,\n${c1}                       ,d0Odlc;,..\n${c1}                           ..',;:cdOOd::,.\n${c1}                                    .:d;.':;.\n${c1}                                       'd,  .'\n${c1}                                         ;l   ..\n${c1}                                          .o\n${c1}                                            c\n${c1}                                            .'\n${c1}                                             .",
    },
    "KaOS": {
        "colors": [4, 7, 1],
        "logo": "${c1}  .....         ..OSSAAAAAAA..\n${c1} .KKKKSS.     .SSAAAAAAAAAAA.\n${c1}.KKKKKSO.    .SAAAAAAAAAA...\n${c1}KKKKKKS.   .OAAAAAAAA.\n${c1}KKKKKKS.  .OAAAAAA.\n${c1}KKKKKKS. .SSAA..\n${c1}.KKKKKS..OAAAAAAAAAAAA........\n${c1} DKKKKO.=AA=========A===AASSSO..\n${c1}  AKKKS.==========AASSSSAAAAAASS.\n${c1}  .=KKO..========ASS.....SSSSASSSS.\n${c1}    .KK.       .ASS..O.. =SSSSAOSS:\n${c1}     .OK.      .ASSSSSSSO...=A.SSA.\n${c1}       .K      ..SSSASSSS.. ..SSA.\n${c1}                 .SSS.AAKAKSSKA.\n${c1}                    .SSS....S..",
    },
    "KDE": {
        "colors": [2, 7],
        "logo": "${c1}         `---.``   ``   `.---.`\n${c1}      .--.`        ``        `-:-.\n${c1}    `:/:     `.----//----.`     :/-\n${c1}   .:.    `---`          `--.`    .:`\n${c1}  .:`   `--`                .:-    `:.\n${c1} `/    `:.      `.-::-.`      -:`   `/`\n${c1} /.    /.     `:++++++++:`     .:    .:\n${c1}`/    .:     `+++++++++++/      /`   `+`\n${c1}/+`   --     .++++++++++++`     :.   .+:\n${c1}`/    .:     `+++++++++++/      /`   `+`\n${c1} /`    /.     `:++++++++:`     .:    .:\n${c1} ./    `:.      `.:::-.`      -:`   `/`\n${c1}  .:`   `--`                .:-    `:.\n${c1}   .:.    `---`          `--.`    .:`\n${c1}    `:/:     `.----//----.`     :/-\n${c1}      .-:.`        ``        `-:-.\n${c1}         `---.``   ``   `.---.`\n${c1}             `..---+/---..`",
    },
    "Kibojoe": {
        "colors": [2, 7, 4],
        "logo": "${c3}           -/+ooooo+/:.`\n${c3}          ${c1}`${c3}yyyo${c2}+++/++${c3}osss${c1}.\n${c3}         ${c1}+NMN${c3}yssssssssssss${c1}.\n${c3}       ${c1}.dMMMMN${c3}sssssssssssy${c1}Ns`\n${c3}      +MMMMMMMm${c3}sssssssssssh${c1}MNo`\n${c3}    `hMMMMMNNNMd${c3}sssssssssssd${c1}MMN/\n${c3}   .${c3}syyyssssssy${c1}NNmmmmd${c3}sssss${c1}hMMMMd:\n${c3}  -NMmh${c3}yssssssssyhhhhyssyh${c1}mMMMMMMMy`\n${c3} -NMMMMMNN${c3}mdhyyyyyyyhdm${c1}NMMMMMMMMMMMN+\n${c3}`NMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMd.\n${c3}ods+/:-----://+oyydmNMMMMMMMMMMMMMMMMMN-\n${c3}`                     .-:+osyhhdmmNNNmdo",
    },
    "Kogaion": {
        "colors": [4, 7, 1],
        "logo": "${c1}           ;;;     ,;;\n${c1}         ,;;;;     ;;;;\n${c1}      ,;;;;;;;;    ;;;;\n${c1}     ;;;;;;;;;;;   ;;;;;\n${c1}    ,;;;;;;;;;;;;  ';;;;;,\n${c1}    ;;;;;;;;;;;;;;, ';;;;;;;\n${c1}    ;;;;;;;;;;;;;;;;;, ';;;;;\n${c1};    ';;;;;;;;;;;;;;;;;;, ;;;\n${c1};;;,  ';;;;;;;;;;;;;;;;;;;,;;\n${c1};;;;;,  ';;;;;;;;;;;;;;;;;;,\n${c1};;;;;;;;,  ';;;;;;;;;;;;;;;;,\n${c1};;;;;;;;;;;;, ';;;;;;;;;;;;;;\n${c1}';;;;;;;;;;;;; ';;;;;;;;;;;;;\n${c1} ';;;;;;;;;;;;;, ';;;;;;;;;;;\n${c1}  ';;;;;;;;;;;;;  ;;;;;;;;;;\n${c1}    ';;;;;;;;;;;; ;;;;;;;;\n${c1}        ';;;;;;;; ;;;;;;\n${c1}           ';;;;; ;;;;\n${c1}             ';;; ;;",
    },
    "Korora": {
        "colors": [4, 7, 1],
        "logo": "${c2}             _add55555555554${c1}:\n${c2}           _w?'${c1}``````````'${c2})k${c1}:\n${c2}          _Z'${c1}`${c2}            ]k${c1}:\n${c2}          m(${c1}`${c2}             )k${c1}:\n${c2}     _.ss${c1}`${c2}m[${c1}`${c2},            ]e${c1}:\n${c2}   .uY\"^`${c1}`${c2}Xc${c1}`${c2}?Ss.         d(${c1}`\n${c2}  jF'${c1}`${c2}    `@.  ${c1}`${c2}Sc      .jr${c1}`\n${c2} jr${c1}`${c2}       `?n_ ${c1}`${c2}$;   _a2\"${c1}`\n${c2}.m${c1}:${c2}          `~M${c1}`${c2}1k${c1}`${c2}5?!`${c1}`\n${c2}:#${c1}:${c2}             ${c1}`${c2})e${c1}```\n${c2}:m${c1}:${c2}             ,#'${c1}`\n${c2}:#${c1}:${c2}           .s2'${c1}`\n${c2}:m,________.aa7^${c1}`\n${c2}:#baaaaaaas!J'${c1}`\n${c2} ```````````",
    },
    "KSLinux": {
        "colors": [4, 7, 1],
        "logo": "${c1} K  K  U   U R   R o   o\n${c1} KKK   U   U RRRR  o   o\n${c1} K  K  U   U R  R  o   o\n${c1} K   K  UUU  R   R  ooo\n${c1}\n${c1}${c2}  SSS   AAA  W   W  AAA\n${c1} S     A   A W   W A   A\n${c1}  SSS  AAAAA W W W AAAAA\n${c1}     S A   A WW WW A   A\n${c1}  SSS  A   A W   W A   A",
    },
    "Kubuntu": {
        "colors": [4, 7, 1],
        "logo": "${c1}        .:oyyyyyyyyyyyyyyyyyyo:`\n${c1}      -oyyyyyyyo${c2}dMMy${c1}yyyyyyysyyyyo-\n${c1}    -syyyyyyyyyy${c2}dMMy${c1}oyyyy${c2}dmMMy${c1}yyyys-\n${c1}   oyyys${c2}dMy${c1}syyyy${c2}dMMMMMMMMMMMMMy${c1}yyyyyyo\n${c1} `oyyyy${c2}dMMMMy${c1}syysoooooo${c2}dMMMMy${c1}yyyyyyyyo`\n${c1} oyyyyyy${c2}dMMMMy${c1}yyyyyyyyyyys${c2}dMMy${c1}sssssyyyo\n${c1}-yyyyyyyy${c2}dMy${c1}syyyyyyyyyyyyyys${c2}dMMMMMy${c1}syyy-\n${c1}oyyyysoo${c2}dMy${c1}yyyyyyyyyyyyyyyyyy${c2}dMMMMy${c1}syyyo\n${c1}yyys${c2}dMMMMMy${c1}yyyyyyyyyyyyyyyyyysosyyyyyyyy\n${c1}yyys${c2}dMMMMMy${c1}yyyyyyyyyyyyyyyyyyyyyyyyyyyyy\n${c1}oyyyyysos${c2}dy${c1}yyyyyyyyyyyyyyyyyy${c2}dMMMMy${c1}syyyo\n${c1}-yyyyyyyy${c2}dMy${c1}syyyyyyyyyyyyyys${c2}dMMMMMy${c1}syyy-\n${c1} oyyyyyy${c2}dMMMy${c1}syyyyyyyyyyys${c2}dMMy${c1}oyyyoyyyo\n${c1} `oyyyy${c2}dMMMy${c1}syyyoooooo${c2}dMMMMy${c1}oyyyyyyyyo\n${c1}   oyyysyyoyyyys${c2}dMMMMMMMMMMMy${c1}yyyyyyyo\n${c1}    -syyyyyyyyy${c2}dMMMy${c1}syyy${c2}dMMMy${c1}syyyys-\n${c1}      -oyyyyyyy${c2}dMMy${c1}yyyyyysosyyyyo-\n${c1}        ./oyyyyyyyyyyyyyyyyyyo/.\n${c1}           `.:/oosyyyysso/:.`",
    },
    "LEDE": {
        "colors": [4, 7, 1],
        "logo": "${c1}    /        /\\\n${c1}   /  LE    /  \\\n${c1}  /    DE  /    \\\n${c1} /________/  LE  \\\n${c1} \\        \\   DE /\n${c1}  \\    LE  \\    /\n${c1}   \\  DE    \\  /\n${c1}    \\________\\/",
    },
    "Linux": {
        "colors": [7, 8, 3],
        "logo": "${c2}${c2}       #######\n${c2}${c2}       ##${c1}O${c2}#${c1}O${c2}##\n${c2}${c2}       #${c3}#####${c2}#\n${c2}${c2}     ##${c1}##${c3}###${c1}##${c2}##\n${c2}${c2}    #${c1}##########${c2}##\n${c2}${c2}   #${c1}############${c2}##\n${c2}${c2}   #${c1}############${c2}###\n${c2}${c3}  ##${c2}#${c1}###########${c2}##${c3}#\n${c2}${c3}######${c2}#${c1}#######${c2}#${c3}######\n${c2}${c3}#######${c2}#${c1}#####${c2}#${c3}#######\n${c2}${c3}  #####${c2}#######${c3}#####",
    },
    "linuxlite_small": {
        "colors": [3, 7],
        "logo": "${c1}  /  \\\\\n${c1} / ${c2}/ ${c1}/\n${c1}> ${c2}/ ${c1}/\n${c1}\\\\ ${c2}\\\\ ${c1}\\\\\n${c1} \\\\_${c2}\\\\${c1}_\\\\\n${c1}${c2}    \\\\",
    },
    "LMDE": {
        "colors": [2, 7],
        "logo": "${c2}${c1}      .:++++ooooosssoo:.\n${c2}    .+o++::.      `.:oos+.\n${c2}${c1}   :oo:.`             -+oo${c2}:\n${c2}${c1} ${c2}`${c1}+o/`    .${c2}::::::${c1}-.    .++-${c2}`\n${c2}${c1}${c2}`${c1}/s/    .yyyyyyyyyyo:   +o-${c2}`\n${c2}${c1}${c2}`${c1}so     .ss       ohyo` :s-${c2}:\n${c2}${c1}${c2}`${c1}s/     .ss  h  m  myy/ /s`${c2}`\n${c2}${c1}`s:     `oo  s  m  Myy+-o:`\n${c2}`oo      :+sdoohyoydyso/.\n${c2} :o.      .:////////++:\n${c2}${c1} `/++        ${c2}-:::::-\n${c2}${c1}  ${c2}`${c1}++-\n${c2}${c1}   ${c2}`${c1}/+-\n${c2}${c1}     ${c2}.${c1}+/.\n${c2}${c1}       ${c2}.${c1}:+-.\n${c2}          `--.``",
    },
    "Lubuntu": {
        "colors": [4, 7, 1],
        "logo": "${c1}        ./mdhhhhhhhhhhhhhhhhhhhhhh.\n${c1}     :mdhhhhhhhhhhhhhhhhhhhhhhhhhhhm`\n${c1}   :ymhhhhhhhhhhhhhhhyyyyyyhhhhhhhhhy:\n${c1}  `odhyyyhhhhhhhhhy+-````./syhhhhhhhho`\n${c1} `hhy..:oyhhhhhhhy-`:osso/..:/++oosyyyh`\n${c1} dhhs   .-/syhhhhs`shhhhhhyyyyyyyyyyyyhs\n${c1}:hhhy`  yso/:+syhy/yhhhhhshhhhhhhhhhhhhh:\n${c1}hhhhho. +hhhys++oyyyhhhhh-yhhhhhhhhhhhhhs\n${c1}hhhhhhs-`/syhhhhyssyyhhhh:-yhhhhhhhhhhhhh\n${c1}hhhhhhs  `:/+ossyyhyyhhhhs -yhhhhhhhhhhhh\n${c1}hhhhhhy/ `syyyssyyyyhhhhhh: :yhhhhhhhhhhs\n${c1}:hhhhhhyo:-/osyhhhhhhhhhhho  ohhhhhhhhhh:\n${c1} sdhhhhhhhyyssyyhhhhhhhhhhh+  +hhhhhhhhs\n${c1} `shhhhhhhhhhhhhhhhhhhhhhy+` .yhhhhhhhh`\n${c1}  +sdhhhhhhhhhhhhhhhhhyo/. `/yhhhhhhhd`\n${c1}   `:shhhhhhhhhh+---..``.:+yyhhhhhhh:\n${c1}     `:mdhhhhhh/.syssyyyyhhhhhhhd:`\n${c1}        `+smdhhh+shhhhhhhhhhhhdm`\n${c1}           `sNmdddhhhhhhhddm-`",
    },
    "Lunar": {
        "colors": [4, 7, 3],
        "logo": "${c1}  -ohys/-`                    `:+shy/`\n${c1}     -omNNdyo/`          :+shmNNy/`\n${c1}             ${c3}      -\n${c1}                 /mMmo\n${c1}                 hMMMN`\n${c1}                 .NMMs\n${c1}    ${c1}  -:+oooo+//: ${c3}/MN${c1}. -///oooo+/-`\n${c1}     /:.`          ${c3}/${c1}           `.:/`\n${c1}${c3}          __\n${c1}         |  |   _ _ ___ ___ ___\n${c1}         |  |__| | |   | .'|  _|\n${c1}         |_____|___|_|_|__,|_|",
    },
    "mac_small": {
        "colors": [2, 3, 1, 5, 4],
        "logo": "${c1}    _ :'_\n${c1}${c2} .'`_`-'_``.\n${c1}:________.-'\n${c1}${c3}:_______:\n${c1}:_______:\n${c1}${c4} :_______`-;\n${c1}${c5}  `._.-._.'",
    },
    "mageia_small": {
        "colors": [6, 7],
        "logo": "${c1}    *\n${c1}   **\n${c1}${c2} /\\\\__/\\\\\n${c1}/      \\\\\n${c1}\\\\      /\n${c1} \\\\____/",
    },
    "Mageia": {
        "colors": [6, 7],
        "logo": "${c1}         °°   .°°.\n${c1}         .°°°. °°\n${c1}         .   .\n${c1}          °°° .°°°.\n${c1}      .°°°.   '___'\n${c1}${c2}     .${c1}'___'     ${c2}   .\n${c1}   :dkxc;'.  ..,cxkd;\n${c1} .dkk. kkkkkkkkkk .kkd.\n${c1}.dkk.  ';cloolc;.  .kkd\n${c1}ckk.                .kk;\n${c1}xO:                  cOd\n${c1}xO:                  lOd\n${c1}lOO.                .OO:\n${c1}.k00.              .00x\n${c1} .k00;            ;00O.\n${c1}  .lO0Kc;,,,,,,;c0KOc.\n${c1}     ;d00KKKKKK00d;\n${c1}        .,KKKK,.",
    },
    "MagpieOS": {
        "colors": [2, 1, 3, 5],
        "logo": "${c1}     .x00kk00:    O0kk00k;\n${c1}    l00:   :00.  o0k   :O0k.\n${c1}  .k0k.     x${c2}d$dddd${c1}k'    .d00;\n${c1}  k0k.      ${c2}.dddddl       ${c1}o00,\n${c1} o00.        ${c2}':cc:.        ${c1}d0O\n${c1}.00l                       ,00.\n${c1}l00.                       d0x\n${c1}k0O                     .:k0o\n${c1}O0k                 ;dO0000d.\n${c1}k0O               .O0O${c2}xxxxk${c1}00:\n${c1}o00.              k0O${c2}dddddd${c1}occ\n${c1}'00l              x0O${c2}dddddo${c3};..${c1}\n${c1} x00.             .x00${c2}kxxd${c3}:..${c1}\n${c1} .O0x               .:oxxx${c4}Okl.${c1}\n${c1}  .x0d                     ${c4},xx,${c1}\n${c1}    .:o.          ${c4}.xd       ckd${c1}\n${c1}       ..          ${c4}dxl     .xx;\n${c1}                    :xxolldxd'\n${c1}                      ;oxdl.",
    },
    "Mandriva": {
        "colors": [4, 3],
        "logo": "${c2}                       `-.\n${c2}${c1}      `               ${c2}.---\n${c2}${c1}    -/               ${c2}-::--`\n${c2}${c1}  `++    ${c2}`----...```-:::::.\n${c2}${c1} `os.      ${c2}.::::::::::::::-```     `  `\n${c2}${c1} +s+         ${c2}.::::::::::::::::---...--`\n${c2}${c1}-ss:          ${c2}`-::::::::::::::::-.``.``\n${c2}${c1}/ss-           ${c2}.::::::::::::-.``   `\n${c2}${c1}+ss:          ${c2}.::::::::::::-\n${c2}${c1}/sso         ${c2}.::::::-::::::-\n${c2}${c1}.sss/       ${c2}-:::-.`   .:::::\n${c2}${c1} /sss+.    ${c2}..`${c1}  `--`    ${c2}.:::\n${c2}${c1}  -ossso+/:://+/-`        ${c2}.:`\n${c2}${c1}    -/+ooo+/-.              ${c2}`",
    },
    "manjaro_small": {
        "colors": [2, 7],
        "logo": "${c1}||||||||| ||||\n${c1}||||      ||||\n${c1}|||| |||| ||||\n${c1}|||| |||| ||||\n${c1}|||| |||| ||||\n${c1}|||| |||| ||||",
    },
    "Manjaro": {
        "colors": [2, 7],
        "logo": "${c1}██████████████████  ████████\n${c1}██████████████████  ████████\n${c1}██████████████████  ████████\n${c1}████████            ████████\n${c1}████████  ████████  ████████\n${c1}████████  ████████  ████████\n${c1}████████  ████████  ████████\n${c1}████████  ████████  ████████\n${c1}████████  ████████  ████████\n${c1}████████  ████████  ████████\n${c1}████████  ████████  ████████\n${c1}████████  ████████  ████████\n${c1}████████  ████████  ████████",
    },
    "Maui": {
        "colors": [6, 7],
        "logo": "${c1}         .:/oooooooooooooooo+:.\n${c1}      `:+ooooooooooooooooooooooo:`\n${c1}    `:oooooooooooooooooooooooooooo/`\n${c1}    ..```-oooooo/-`` `:oooooo+:.` `--\n${c1}  :.      +oo+-`       /ooo/`       -/\n${c1} -o.     `o+-          +o/`         -o:\n${c1}`oo`     ::`  :o/     `+.  .+o`     /oo.\n${c1}/o+      .  -+oo-     `   /oo/     `ooo/\n${c1}+o-        /ooo+`       .+ooo.     :ooo+\n${c1}++       .+oooo:       -oooo+     `oooo+\n${c1}:.      .oooooo`      :ooooo-     :oooo:\n${c1}`      .oooooo:      :ooooo+     `ooo+-`\n${c1}      .+oooooo`     -oooooo:     `o/-\n${c1}      +oooooo:     .ooooooo.\n${c1}     /ooooooo`     /ooooooo/       ..\n${c1}    `:oooooooo/:::/ooooooooo+:--:/:`\n${c1}      `:+oooooooooooooooooooooo+:`\n${c1}         .:+oooooooooooooooo+:.\n${c1}             `.-://////:-.`",
    },
    "Mer": {
        "colors": [4, 7, 1],
        "logo": "${c1}                         .-`\n${c1}                       `y`-o+`\n${c1}                        ``NMMy\n${c1}                      .--`:++.\n${c1}                    .hNNNNs\n${c1}                    /MMMMMN\n${c1}                    `ommmd/ +/\n${c1}                      ````  +/\n${c1}                     `:+sssso/-`\n${c1}  .-::. `-::-`     `smNMNmdmNMNd/      .://-`\n${c1}.ymNMNNdmNMMNm+`  -dMMh:.....+dMMs   `sNNMMNo\n${c1}dMN+::NMMy::hMM+  mMMo `ohhy/ `dMM+  yMMy::-\n${c1}MMm   yMM-  :MMs  NMN` `:::::--sMMh  dMM`\n${c1}MMm   yMM-  -MMs  mMM+ `ymmdsymMMMs  dMM`\n${c1}NNd   sNN-  -NNs  -mMNs-.--..:dMMh`  dNN\n${c1}---   .--`  `--.   .smMMmdddmMNdo`   .--\n${c1}                     ./ohddds+:`\n${c1}                     +h- `.:-.\n${c1}                     ./`.dMMMN+\n${c1}                        +MMMMMd\n${c1}                        `+dmmy-\n${c1}                      ``` .+`\n${c1}                     .dMNo-y.\n${c1}                     `hmm/\n${c1}                         .:`\n${c1}                         dMs",
    },
    "Minix": {
        "colors": [1, 7, 3],
        "logo": "${c2}   sdyooymmNNy.     ``    .smNmmdysNd\n${c2}   odyoso+syNNmysoyhhdhsoomNmm+/osdm/\n${c2}    :hhy+-/syNNmddhddddddmNMNo:sdNd:\n${c2}     `smNNdNmmNmddddddddddmmmmmmmy`\n${c2}   `ohhhhdddddmmNNdmddNmNNmdddddmdh-\n${c2}   odNNNmdyo/:/-/hNddNy-`..-+ydNNNmd:\n${c2} `+mNho:`   smmd/ sNNh :dmms`   -+ymmo.\n${c2}-od/       -m${c1}mm${c2}mo -NN+ +m${c1}mm${c2}m-       yms:\n${c2}+sms -.`    :so:  .NN+  :os/     .-`mNh:\n${c2}.-hyh+:////-     -sNNd:`    .--://ohNs-\n${c2} `:hNNNNNNNMMd/sNMmhsdMMh/ymmNNNmmNNy/\n${c2}  -+sNNNNMMNNNsmNMo: :NNmymNNNNMMMms:\n${c2}    //oydNMMMMydMMNysNMMmsMMMMMNyo/`\n${c2}       ../-yNMMy--/::/-.sMMmos+.`\n${c2}           -+oyhNsooo+omy/```\n${c2}              `::ohdmds-`",
    },
    "linuxmint_small": {
        "colors": [2, 7],
        "logo": "${c1}|_          \\\\\n${c1}  | ${c2}| _____ ${c1}|\n${c1}  | ${c2}| | | | ${c1}|\n${c1}  | ${c2}| | | | ${c1}|\n${c1}  | ${c2}\\\\__${c2}___/ ${c1}|\n${c1}  \\\\_________/",
    },
    "mx_small": {
        "colors": [4, 6, 7],
        "logo": "${c3}     \\\\\\\\/\n${c3}      \\\\\\\\\n${c3}   /\\\\/ \\\\\\\\\n${c3}  /  \\\\  /\\\\\n${c3} /    \\\\/  \\\\\n${c3}/__________\\\\",
    },
    "MX": {
        "colors": [4, 6, 7],
        "logo": "${c3}MMMMMMMMMMNs..yMMMMMMMMMMMMMm: +NMMMMMMM\n${c3}MMMMMMMMMN+    :mMMMMMMMMMNo` -dMMMMMMMM\n${c3}MMMMMMMMMMMs.   `oNMMMMMMh- `sNMMMMMMMMM\n${c3}MMMMMMMMMMMMN/    -hMMMN+  :dMMMMMMMMMMM\n${c3}MMMMMMMMMMMMMMh-    +ms. .sMMMMMMMMMMMMM\n${c3}MMMMMMMMMMMMMMMN+`   `  +NMMMMMMMMMMMMMM\n${c3}MMMMMMMMMMMMMMNMMd:    .dMMMMMMMMMMMMMMM\n${c3}MMMMMMMMMMMMm/-hMd-     `sNMMMMMMMMMMMMM\n${c3}MMMMMMMMMMNo`   -` :h/    -dMMMMMMMMMMMM\n${c3}MMMMMMMMMd:       /NMMh-   `+NMMMMMMMMMM\n${c3}MMMMMMMNo`         :mMMN+`   `-hMMMMMMMM\n${c3}MMMMMMh.            `oNMMd:    `/mMMMMMM\n${c3}MMMMm/                -hMd-      `sNMMMM\n${c3}MMNs`                   -          :dMMM\n${c3}Mm:                                 `oMM\n${c3}MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM",
    },
    "Namib": {
        "colors": [1],
        "logo": "${c1}       -/yyys              syyy/-\n${c1}     -shy                      yhs-\n${c1}   -yhs                          shy-\n${c1}  +hy                              yh+\n${c1} +ds                                sd+\n${c1}/ys                  so              sy/\n${c1}sh                 smMMNdyo           hs\n${c1}yo               ymMMMMNNMMNho        oy\n${c1}N             ydMMMNNMMMMMMMMMmy       N\n${c1}N         shmMMMMNNMMMMMMMMMMMMMNy     N\n${c1}yo  ooshmNMMMNNNNMMMMMMMMMMMMMMMMMms  oy\n${c1}sd yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy ds\n${c1}/ys                                  sy/\n${c1} +ds                                sd+\n${c1}  +hy                              yh+\n${c1}   -yhs                          shy-\n${c1}     -shy                      yhs-\n${c1}       -/yyys              syyy/-\n${c1}          .:+shysyhyhhysyhs+:.",
    },
    "Neptune": {
        "colors": [7],
        "logo": "${c1}        .+ymNNdyooo/:+oooymNNmy/`\n${c1}     `/hNNh/.`             `-+dNNy:`\n${c1}    /mMd/.          .++.:oy/   .+mMd-\n${c1}  `sMN/             oMMmdy+.     `oNNo\n${c1} `hMd.           `/ymy/.           :NMo\n${c1} oMN-          `/dMd:               /MM-\n${c1}`mMy          -dMN+`                 mMs\n${c1}.MMo         -NMM/                   yMs\n${c1} dMh         mMMMo:`                `NMo\n${c1} /MM/        /ymMMMm-               sMN.\n${c1}  +Mm:         .hMMd`              oMN/\n${c1}   +mNs.      `yNd/`             -dMm-\n${c1}    .yMNs:    `/.`            `/yNNo`\n${c1}      .odNNy+-`           .:ohNNd/.\n${c1}         -+ymNNmdyyyyyyydmNNmy+.\n${c1}             `-//sssssss//.",
    },
    "netbsd_small": {
        "colors": [5, 7],
        "logo": "${c2}${c2} \\\\\\\\        ${c1}__,---\\`_\n${c2}${c2}  \\\\\\\\       ${c1}\\`.____\n${c2}${c2}   \\\\\\\\${c1}-______,----\\`-\n${c2}${c2}    \\\\\\\\\n${c2}     \\\\\\\\\n${c2}      \\\\\\\\",
    },
    "NetBSD": {
        "colors": [5, 7],
        "logo": "${c1}${c2}y${c1}/s+:-``    `.-:+oydNMMMMNhs/-``\n${c1}${c2}-m+${c1}NMMMMMMMMMMMMMMMMMMMNdhmNMMMmdhs+/-`\n${c1} ${c2}-m+${c1}NMMMMMMMMMMMMMMMMMMMMmy+:`\n${c1}  ${c2}-N/${c1}dMMMMMMMMMMMMMMMds:`\n${c1}   ${c2}-N/${c1}hMMMMMMMMMmho:`\n${c1}    ${c2}-N/${c1}-:/++/:.`\n${c1}${c2}     :M+\n${c1}      :Mo\n${c1}       :Ms\n${c1}        :Ms\n${c1}         :Ms\n${c1}          :Ms\n${c1}           :Ms\n${c1}            :Ms\n${c1}             :Ms\n${c1}              :Ms",
    },
    "Netrunner": {
        "colors": [4, 7, 1],
        "logo": "${c1}        -smMMMMMMMMMMMMMMMMMMds-\n${c1}      +mMMMMMMMMMMMMMMMMMMMMMMMMd+\n${c1}    /mMMMMMMMMMMMMMMMMMMMMMMMMMMMMm/\n${c1}  `hMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy`\n${c1} .mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMd`\n${c1} dMMMMMMMMMMMMMMMMMMMMMMNdhmMMMMMMMMMMh\n${c1}+MMMMMMMMMMMMMNmhyo+/-.   -MMMMMMMMMMMM/\n${c1}mMMMMMMMMd+:.`           `mMMMMMMMMMMMMd\n${c1}MMMMMMMMMMMdy/.          yMMMMMMMMMMMMMM\n${c1}MMMMMMMMMMMMMMMNh+`     +MMMMMMMMMMMMMMM\n${c1}mMMMMMMMMMMMMMMMMMs    -NMMMMMMMMMMMMMMd\n${c1}+MMMMMMMMMMMMMMMMMN.  `mMMMMMMMMMMMMMMM/\n${c1} dMMMMMMMMMMMMMMMMMy  hMMMMMMMMMMMMMMMh\n${c1} `dMMMMMMMMMMMMMMMMM-+MMMMMMMMMMMMMMMd`\n${c1}  `hMMMMMMMMMMMMMMMMmMMMMMMMMMMMMMMMy\n${c1}    /mMMMMMMMMMMMMMMMMMMMMMMMMMMMMm:\n${c1}      +dMMMMMMMMMMMMMMMMMMMMMMMMd/\n${c1}        -odMMMMMMMMMMMMMMMMMMdo-\n${c1}           `:+ydmNMMMMNmhy+-`",
    },
    "Nitrux": {
        "colors": [4],
        "logo": "${c1}`/yo\n${c1}`/yo\n${c1}`/yo      .+:.\n${c1}`/yo      .sys+:.`\n${c1}`/yo       `-/sys+:.`\n${c1}`/yo           ./sss+:.`\n${c1}`/yo              .:oss+:-`\n${c1}`/yo                 ./o///:-`\n${c1}`/yo              `.-:///////:`\n${c1}`/yo           `.://///++//-``\n${c1}`/yo       `.-:////++++/-`\n${c1}`/yo    `-://///++o+/-`\n${c1}`/yo `-/+o+++ooo+/-`\n${c1}`/s+:+oooossso/.`\n${c1}`//+sssssso:.\n${c1}`+syyyy+:`\n${c1}:+s+-",
    },
    "nixos_small": {
        "colors": [4, 6],
        "logo": "${c1} ==\\\\\\\\__\\\\\\\\/ //\n${c1}   //   \\\\\\\\//\n${c1}==//     //==\n${c1} //\\\\\\\\___//\n${c1}// /\\\\\\\\  \\\\\\\\==\n${c1}  // \\\\\\\\  \\\\\\\\",
    },
    "NixOS": {
        "colors": [4, 6],
        "logo": "${c1}${c1}          ':::::    ${c2}':::::.  ::::'\n${c1}${c1}            :::::     ${c2}'::::.:::::\n${c1}${c1}      .......:::::..... ${c2}::::::::\n${c1}${c1}     ::::::::::::::::::. ${c2}::::::    ${c1}::::.\n${c1}    ::::::::::::::::::::: ${c2}:::::.  ${c1}.::::'\n${c1}${c2}           .....           ::::' ${c1}:::::'\n${c1}${c2}          :::::            '::' ${c1}:::::'\n${c1}${c2} ........:::::               ' ${c1}:::::::::::.\n${c1}${c2}:::::::::::::                 ${c1}:::::::::::::\n${c1}${c2} ::::::::::: ${c1}..              ${c1}:::::\n${c1}${c2}     .::::: ${c1}.:::            ${c1}:::::\n${c1}${c2}    .:::::  ${c1}:::::          ${c1}'''''    ${c2}.....\n${c1}    :::::   ${c1}':::::.  ${c2}......:::::::::::::'\n${c1}     :::     ${c1}::::::. ${c2}':::::::::::::::::'\n${c1}${c1}            .:::::::: ${c2}'::::::::::\n${c1}${c1}           .::::''::::.     ${c2}'::::.\n${c1}${c1}          .::::'   ::::.     ${c2}'::::.\n${c1}${c1}         .::::      ::::      ${c2}'::::.",
    },
    "Nurunner": {
        "colors": [4],
        "logo": "${c1}                ;00cxXl\n${c1}              ;K0,   .xNo.\n${c1}            :KO'       .lXx.\n${c1}          cXk.    ;xl     cXk.\n${c1}        cXk.    ;k:.,xo.    cXk.\n${c1}     .lXx.    :x::0MNl,dd.    :KO,\n${c1}   .xNx.    cx;:KMMMMMNo'dx.    ;KK;\n${c1} .dNl.    cd,cXMMMMMMMMMWd,ox'    'OK:\n${c1};WK.    'K,.KMMMMMMMMMMMMMWc.Kx     lMO\n${c1} 'OK:    'dl'xWMMMMMMMMMM0::x:    'OK:\n${c1}   .kNo    .xo'xWMMMMMM0;:O:    ;KK;\n${c1}     .dXd.   .do,oNMMO;ck:    ;00,\n${c1}        oNd.   .dx,;'cO;    ;K0,\n${c1}          oNx.    okk;    ;K0,\n${c1}            lXx.        :KO'\n${c1}              cKk'    cXk.\n${c1}                ;00:lXx.\n${c1}                  ,kd.",
    },
    "NuTyX": {
        "colors": [4, 1],
        "logo": "${c1}                                    .\n${c1}                                 ...\n${c1}                               ...\n${c1}            ....     .........--.\n${c1}       ..-++-----....--++++++---.\n${c1}    .-++++++-.   .-++++++++++++-----..\n${c1}  .--...  .++..-+++--.....-++++++++++--..\n${c1} .     .-+-. .**-            ....  ..-+----..\n${c1}     .+++.  .*+.         +            -++-----.\n${c1}   .+++++-  ++.         .*+.     .....-+++-----.\n${c1}  -+++-++. .+.          .-+***++***++--++++.  .\n${c1} -+-. --   -.          -*- ......        ..--.\n${c1}.-. .+-    .          -+.\n${c1}.  .+-                +.\n${c1}   --                 --\n${c1}  -+----.              .-\n${c1}  -++-.+.                .\n${c1} .++. --\n${c1}  +.  ----.\n${c1}  .  .+. ..\n${c1}      -  .\n${c1}      .",
    },
    "OBRevenge": {
        "colors": [1, 7, 3],
        "logo": "${c1}     _@@@@   @@@g_\n${c1}   _@@@@@@   @@@@@@\n${c1}  _@@@@@@M   W@@@@@@_\n${c1} j@@@@P        ^W@@@@\n${c1} @@@@L____  _____Q@@@@\n${c1}Q@@@@@@@@@@j@@@@@@@@@@\n${c1}@@@@@    T@j@    T@@@@@\n${c1}@@@@@ ___Q@J@    _@@@@@\n${c1}@@@@@fMMM@@j@jggg@@@@@@\n${c1}@@@@@    j@j@^MW@P @@@@\n${c1}Q@@@@@ggg@@f@   @@@@@@L\n${c1}^@@@@WWMMP  ^    Q@@@@\n${c1} @@@@@_         _@@@@l\n${c1}  W@@@@@g_____g@@@@@P\n${c1}   @@@@@@@@@@@@@@@@l\n${c1}    ^W@@@@@@@@@@@P\n${c1}       ^TMMMMTll",
    },
    "openbsd_small": {
        "colors": [3, 7, 6, 1, 8],
        "logo": "${c1}    \\\\-     -/\n${c1} \\\\_/         \\\\\n${c1} |        ${c2}O O${c1} |\n${c1} |_  <   )  3 )\n${c1} / \\\\         /\n${c1}    /-_____-\\\\",
    },
    "OpenBSD": {
        "colors": [3, 7, 6, 1, 8],
        "logo": "${c3}                                    (_)\n${c3}${c1}              |    .\n${c3}${c1}          .   |L  /|   .         ${c3} _\n${c3}${c1}      _ . |\\ _| \\--+._/| .       ${c3}(_)\n${c3}${c1}     / ||\\| Y J  )   / |/| ./\n${c3}    J  |)'( |        ` F`.'/       ${c3} _\n${c3}${c1}  -<|  F         __     .-<        ${c3}(_)\n${c3}${c1}    | /       .-'${c3}. ${c1}`.  /${c3}-. ${c1}L___\n${c3}    J \\\\      <    ${c3}\\ ${c1} | | ${c5}O${c3}\\\\${c1}|.-' ${c3} _\n${c3}${c1}  _J \\\\  .-    \\\\${c3}/ ${c5}O ${c3}| ${c1}| \\\\  |${c1}F    ${c3}(_)\n${c3}${c1} '-F  -<_.     \\\\   .-'  `-' L__\n${c3}__J  _   _.     >-'  ${c1})${c4}._.   ${c1}|-'\n${c3}${c1} `-|.'   /_.          ${c4}\\_|  ${c1} F\n${c3}  /.-   .                _.<\n${c3} /'    /.'             .'  `\\\\\n${c3}  /L  /'   |/      _.-'-\\\\\n${c3} /'J       ___.---'\\|\n${c3}   |\\  .--' V  | `. `\n${c3}   |/`. `-.     `._)\n${c3}      / .-.\\\\\n${c3}      \\\\ (  `\\\\\n${c3}       `.\\\\",
    },
    "openEuler": {
        "colors": [4, 7, 1],
        "logo": "${c1}                       (#####\n${c1}                     (((########  #####\n${c1}                    (((        ##########    __...__\n${c1}             ((((((((           #######    /((((((###\\\n${c1}           (((((((((((   .......           \\(((((####/\n${c1}          ((((((    ((((#########            *******\n${c1}    %((((((#          ((########\n${c1} /////(((((              ###\n${c1}/////(((((((#   (((&\n${c1}         (((((((((((((\n${c1}          ((((((((((((\n${c1}           (((((((((     ((((((###\n${c1}                       /((((((######\n${c1}                      //((((((######\n${c1}                       /((((((#####\n${c1}                        *********/",
    },
    "OpenIndiana": {
        "colors": [4, 7, 1],
        "logo": "${c2}                         .yh+\n${c2}\n${c2}           ${c1}-+syyyo+-     ${c2} /+.\n${c2}         ${c1}+ddo/---/sdh/   ${c2} ym-\n${c2}       ${c1}`hm+        `sms${c2}   ym-```````.-.\n${c2}       ${c1}sm+           sm/ ${c2} ym-         +s\n${c2}       ${c1}hm.           /mo ${c2} ym-         /h\n${c2}       ${c1}omo           ym: ${c2} ym-       `os`\n${c2}        ${c1}smo`       .ym+ ${c2}  ym-     .os-\n${c2}     ``  ${c1}:ymy+///oyms- ${c2}   ym-  .+s+.\n${c2}   ..`     ${c1}`:+oo+/-`  ${c2}    -//oyo-\n${c2} -:`                   .:oys/.\n${c2}+-               `./oyys/.\n${c2}h+`      `.-:+oyyyo/-`\n${c2}`/ossssysso+/-.`",
    },
    "openmamba": {
        "colors": [7, 2],
        "logo": "${c1}           .-/+ooooooooo+/:-`\n${c1}        ./ooooooooooooooooooo+:.\n${c1}      -+oooooooooooooooooooooooo+-\n${c1}    .+ooooooooo+/:---::/+ooooooooo+.\n${c1}   :oooooooo/-`          `-/oo${c2}s´${c1}oooo.${c2}s´${c1}\n${c1}  :ooooooo/`                `${c2}sNds${c1}ooo${c2}sNds${c1}\n${c1} -ooooooo-                   ${c2}:dmy${c1}ooo${c2}:dmy${c1}\n${c1} +oooooo:                      :oooooo-\n${c1}.ooooooo                        .://:`\n${c1}:oooooo+                        ./+o+:`\n${c1}-ooooooo`                      `oooooo+\n${c1}`ooooooo:                      /oooooo+\n${c1} -ooooooo:                    :ooooooo.\n${c1}  :ooooooo+.                .+ooooooo:\n${c1}   :oooooooo+-`          `-+oooooooo:\n${c1}    .+ooooooooo+/::::://oooooooooo+.\n${c1}      -+oooooooooooooooooooooooo+-\n${c1}        .:ooooooooooooooooooo+:.\n${c1}           `-:/ooooooooo+/:.`\n${c1}                 ``````",
    },
    "OpenMandriva": {
        "colors": [4],
        "logo": "${c1}            `-:/+++++++//:-.`\n${c1}         .:+++oooo+/:.``   ``\n${c1}      `:+ooooooo+:.  `-:/++++++/:.`\n${c1}     -+oooooooo:` `-++o+/::::://+o+/-\n${c1}   `/ooooooooo-  -+oo/.`        `-/oo+.\n${c1}  `+ooooooooo.  :os/`              .+so:\n${c1}  +sssssssss/  :ss/                 `+ss-\n${c1} :ssssssssss`  sss`                  .sso\n${c1} ossssssssss  `yyo                    sys\n${c1}`sssssssssss` `yys                   `yys\n${c1}`sssssssssss:  +yy/                  +yy:\n${c1} oyyyyyyyyyys. `oyy/`              `+yy+\n${c1} :yyyyyyyyyyyo. `+yhs:.         `./shy/\n${c1}  oyyyyyyyyyyys:` .oyhys+:----/+syhy+. `\n${c1}  `syyyyyyyyyyyyo-` .:osyhhhhhyys+:``.:`\n${c1}   `oyyyyyyyyyyyyys+-`` `.----.```./oo.\n${c1}     /yhhhhhhhhhhhhhhyso+//://+osyhy/`\n${c1}      `/yhhhhhhhhhhhhhhhhhhhhhhhhy/`\n${c1}        `:oyhhhhhhhhhhhhhhhhhhyo:`\n${c1}            .:+syhhhhhhhhys+:-`\n${c1}                 ``....``",
    },
    "OpenStage": {
        "colors": [2],
        "logo": "${c1}              .(((((((,\n${c1}             /(((((((((/\n${c1}           .(((((/,/(((((,\n${c1}          *(((((*   ,(((((/\n${c1}          (((((*      .*/((\n${c1}         *((((/  (//(/*\n${c1}         /((((*  ((((((((((,\n${c1}      .  /((((*  (((((((((((((.\n${c1}     ((. *((((/        ,((((((((\n${c1}   ,(((/  (((((/     **   ,((((((*\n${c1}  /(((((. .(((((/   //(((*  *(((((/\n${c1} .(((((,    ((/   .(((((/.   .(((((,\n${c1} /((((*        ,(((((((/      ,(((((\n${c1} /(((((((((((((((((((/.  /(((((((((/\n${c1} /(((((((((((((((((,   /(((((((((((/\n${c1}     */(((((//*.      */((/(/(/*",
    },
    "OpenWrt": {
        "colors": [4, 7, 1],
        "logo": "${c1}|       |.-----.-----.-----.\n${c1}|   -   ||  _  |  -__|     |\n${c1}|_______||   __|_____|__|__|\n${c1}         |__|\n${c1} ________        __\n${c1}|  |  |  |.----.|  |_\n${c1}|  |  |  ||   _||   _|\n${c1}|________||__|  |____|",
    },
    "Oracle": {
        "colors": [1, 7, 3],
        "logo": "${c1}      `-/+++++++++++++++++/-.`\n${c1}   `/syyyyyyyyyyyyyyyyyyyyyyys/.\n${c1}  :yyyyo/-...............-/oyyyy/\n${c1} /yyys-                     .oyyy+\n${c1}.yyyy`                       `syyy-\n${c1}:yyyo                         /yyy/\n${c1}.yyyy`                       `syyy-\n${c1} /yyys.                     .oyyyo\n${c1}  /yyyyo:-...............-:oyyyy/`\n${c1}   `/syyyyyyyyyyyyyyyyyyyyyyys+.\n${c1}     `.:/+ooooooooooooooo+/:.`",
    },
    "OS Elbrus": {
        "colors": [4, 7, 3],
        "logo": "${c1}   ██▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀██\n${c1}   ██                       ██\n${c1}   ██   ███████   ███████   ██\n${c1}   ██   ██   ██   ██   ██   ██\n${c1}   ██   ██   ██   ██   ██   ██\n${c1}   ██   ██   ██   ██   ██   ██\n${c1}   ██   ██   ██   ██   ██   ██\n${c1}   ██   ██   ███████   ███████\n${c1}   ██   ██                  ██\n${c1}   ██   ██▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄██\n${c1}   ██   ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀██\n${c1}   ██                       ██\n${c1}   ███████████████████████████",
    },
    "PacBSD": {
        "colors": [1, 7, 3],
        "logo": "${c1}  `:ddNMd-                         -o--`\n${c1} -sMMMMh:                          `+N+``\n${c1} yMMMMMs`     .....-/-...           `mNh/\n${c1} yMMMMMmh+-`:sdmmmmmmMmmmmddy+-``./ddNMMm\n${c1} yNMMNMMMMNdyyNNMMMMMMMMMMMMMMMhyshNmMMMm\n${c1} :yMMMMMMMMMNdooNMMMMMMMMMMMMMMMMNmy:mMMd\n${c1}  +MMMMMMMMMmy:sNMMMMMMMMMMMMMMMMMMMmshs-\n${c1}  :hNMMMMMMN+-+MMMMMMMMMMMMMMMMMMMMMMMs.\n${c1} .omysmNNhy/+yNMMMMMMMMMMNMMMMMMMMMNdNNy-\n${c1} /hMM:::::/hNMMMMMMMMMMMm/-yNMMMMMMN.mMNh`\n${c1}.hMMMMdhdMMMMMMMMMMMMMMmo  `sMMMMMMN mMMm-\n${c1}:dMMMMMMMMMMMMMMMMMMMMMdo+  oMMMMMMN`smMNo`\n${c1}/dMMMMMMMMMMMMMMMMMMMMMNd/` :yMMMMMN:-hMMM.\n${c1}:dMMMMMMMMMMMMMMMMMMMMMNh`  oMMMMMMNo/dMNN`\n${c1}:hMMMMMMMMMMMMMMMMMMMMMMNs--sMMMMMMMNNmy++`\n${c1} sNMMMMMMMMMMMMMMMMMMMMMMMmmNMMMMMMNho::o.\n${c1} :yMMMMMMMMMMMMMNho+sydNNNNNNNmysso/` -//\n${c1}  /dMMMMMMMMMMMMMs-  ````````..``\n${c1}   .oMMMMMMMMMMMMNs`               ./y:`\n${c1}     +dNMMNMMMMMMMmy`          ``./ys.\n${c1}      `/hMMMMMMMMMMMNo-``    `.+yy+-`\n${c1}        `-/hmNMNMMMMMMmmddddhhy/-`\n${c1}            `-+oooyMMMdsoo+/:.",
    },
    "parabola_small": {
        "colors": [5, 7],
        "logo": "${c1}.`_//_//_/ / `.\n${c1}          /  .`\n${c1}         / .`\n${c1}        /.`\n${c1}       /`",
    },
    "Parabola": {
        "colors": [5, 7],
        "logo": "${c1}                   `.`  `:++.   `-+o+.\n${c1}             `` `:+/. `:+/.   `-+oooo+\n${c1}        ``-::-.:+/. `:+/.   `-+oooooo+\n${c1}    `.-:///-  ..`   .-.   `-+oooooooo-\n${c1} `..-..`                 `+ooooooooo:\n${c1}``                        :oooooooo/\n${c1}                          `ooooooo:\n${c1}                          `oooooo:\n${c1}                          -oooo+.\n${c1}                          +ooo/`\n${c1}                         -ooo-\n${c1}                        `+o/.\n${c1}                        /+-\n${c1}                       //`\n${c1}                      -.",
    },
    "Pardus": {
        "colors": [3, 7, 6, 1, 8],
        "logo": "${c1}/Md- -/ymMdmNNdhso/::/oshdNNmdMmy/. :dM/\n${c1}mN.     oMdyy- -y          `-dMo     .Nm\n${c1}.mN+`  sMy hN+ -:             yMs  `+Nm.\n${c1} `yMMddMs.dy `+`               sMddMMy`\n${c1}   +MMMo  .`  .                 oMMM+\n${c1}   `NM/    `````.`    `.`````    +MN`\n${c1}   yM+   `.-:yhomy    ymohy:-.`   +My\n${c1}   yM:          yo    oy          :My\n${c1}   +Ms         .N`    `N.      +h sM+\n${c1}   `MN      -   -::::::-   : :o:+`NM`\n${c1}    yM/    sh   -dMMMMd-   ho  +y+My\n${c1}    .dNhsohMh-//: /mm/ ://-yMyoshNd`\n${c1}      `-ommNMm+:/. oo ./:+mMNmmo:`\n${c1}     `/o+.-somNh- :yy: -hNmos-.+o/`\n${c1}    ./` .s/`s+sMdd+``+ddMs+s`/s. `/.\n${c1}        : -y.  -hNmddmNy.  .y- :\n${c1}         -+       `..`       +-",
    },
    "Parrot": {
        "colors": [6, 7],
        "logo": "${c1}`mMMMMMMMMMMMNmmdhy-\n${c1} dMMMMMMMMMMMMMMMMMMs`\n${c1} +MMsohNMMMMMMMMMMMMMm/\n${c1} .My   .+dMMMMMMMMMMMMMh.\n${c1}  +       :NMMMMMMMMMMMMNo\n${c1}           `yMMMMMMMMMMMMMm:\n${c1}             /NMMMMMMMMMMMMMy`\n${c1}              .hMMMMMMMMMMMMMN+\n${c1}                  ``-NMMMMMMMMMd-\n${c1}                     /MMMMMMMMMMMs`\n${c1}                      mMMMMMMMsyNMN/\n${c1}                      +MMMMMMMo  :sNh.\n${c1}                      `NMMMMMMm     -o/\n${c1}                       oMMMMMMM.\n${c1}                       `NMMMMMM+\n${c1}                        +MMd/NMh\n${c1}                         mMm -mN`\n${c1}                         /MM  `h:\n${c1}                          dM`   .\n${c1}                          :M-\n${c1}                           d:\n${c1}                           -+\n${c1}                            -",
    },
    "Parsix": {
        "colors": [3, 1, 7, 8],
        "logo": "${c2}               ${c2}.syssssys.\n${c2}       ${c1}.--.    ${c2}ssssssssso${c1}   ..--.\n${c2}     :++++++:  ${c2}+ssssssss+${c1} ./++/+++:\n${c2}    /+++++++++.${c2}.yssooooy`${c1}-+///////o-\n${c2}    /++++++++++.${c2}+soooos:${c1}:+////////+-\n${c2}     :+++++////o-${c2}oooooo-${c1}+/////////-\n${c2}      `-/++//++-${c4}.-----.-${c1}:+/////:-\n${c2}  ${c3}-://::--${c1}-:/:${c4}.--.````.--.${c1}:::-${c3}--::::::.\n${c2}${c3}-/:::::::://:${c4}.:-`      `-:${c3}`:/:::::::--/-\n${c2}${c3}/::::::::::/-${c4}--.        .-.${c3}-/://///::::/\n${c2}${c3}-/:::::::::/:${c4}`:-.      .-:${c3}`:///////////-\n${c2} `${c3}-::::--${c1}.-://.${c4}---....---${c1}`:+/:-${c3}--::::-`\n${c2}       ${c1}-/+///+o/-${c4}.----.${c1}.:oo+++o+.\n${c2}     ${c1}-+/////+++o:${c2}syyyyy.${c1}o+++++++++:\n${c2}    ${c1}.+////+++++-${c2}+sssssy+${c1}.++++++++++\\\n${c2}    ${c1}.+:/++++++.${c2}.yssssssy-${c1}`+++++++++:\n${c2}     ${c1}:/+++++-  ${c2}+sssssssss  ${c1}-++++++-\n${c2}       ${c1}`--`    ${c2}+sssssssso    ${c1}`--`\n${c2}                ${c2}+sssssy+`\n${c2}                 ${c2}`.::-`",
    },
    "PCLinuxOS": {
        "colors": [4, 7, 1],
        "logo": "${c1}        dyssyhhhhhhhhhhhssyhN\n${c1}     Nysyhhyo/:-.....-/oyhhhssd\n${c1}   Nsshhy+.              `/shhysm\n${c1}  dohhy/                    -shhsy\n${c1} dohhs`                       /hhys\n${c1}N+hho   ${c2}+ssssss+-   .+syhys+   ${c1}/hhsy\n${c1}ohhh`   ${c2}ymmo++hmm+`smmy/::+y`   ${c1}shh+\n${c1}+hho    ${c2}ymm-  /mmy+mms          ${c1}:hhod\n${c1}/hh+    ${c2}ymmhhdmmh.smm/          ${c1}.hhsh\n${c1}+hhs    ${c2}ymm+::-`  /mmy`    `    ${c1}/hh+m\n${c1}yyhh-   ${c2}ymm-       /dmdyosyd`  ${c1}`yhh+\n${c1} ohhy`  ${c2}://`         -/+++/-   ${c1}ohhom\n${c1} N+hhy-                      `shhoh\n${c1}   sshho.                  `+hhyom\n${c1}    dsyhhs/.            `:ohhhoy\n${c1}      dysyhhhso///://+syhhhssh\n${c1}         dhyssyhhhhhhyssyyhN\n${c1}              mddhdhdmN",
    },
    "Peppermint": {
        "colors": [1, 15, 3],
        "logo": "${c1}${c1}           PPPP${c2}MMMMMMM${c1}PPPPPPPPPPP\n${c1}${c1}         PPPP${c2}MMMMMMMMMM${c1}PPPPPPPP${c2}MM${c1}PP\n${c1}${c1}       PPPPPPPP${c2}MMMMMMM${c1}PPPPPPPP${c2}MMMMM${c1}PP\n${c1}${c1}     PPPPPPPPPPPP${c2}MMMMMM${c1}PPPPPPP${c2}MMMMMMM${c1}PP\n${c1}${c1}    PPPPPPPPPPPP${c2}MMMMMMM${c1}PPPP${c2}M${c1}P${c2}MMMMMMMMM${c1}PP\n${c1}${c1}   PP${c2}MMMM${c1}PPPPPPPPPP${c2}MMM${c1}PPPPP${c2}MMMMMMM${c1}P${c2}MM${c1}PPPP\n${c1}${c1}   P${c2}MMMMMMMMMM${c1}PPPPPP${c2}MM${c1}PPPPP${c2}MMMMMM${c1}PPPPPPPP\n${c1}${c1}  P${c2}MMMMMMMMMMMM${c1}PPPPP${c2}MM${c1}PP${c2}M${c1}P${c2}MM${c1}P${c2}MM${c1}PPPPPPPPPPP\n${c1}${c1}  P${c2}MMMMMMMMMMMMMMMM${c1}PP${c2}M${c1}P${c2}MMM${c1}PPPPPPPPPPPPPPPP\n${c1}${c1}  P${c2}MMM${c1}PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP${c2}MMMMM${c1}P\n${c1}${c1}  PPPPPPPPPPPPPPPP${c2}MMM${c1}P${c2}M${c1}P${c2}MMMMMMMMMMMMMMMM${c1}PP\n${c1}${c1}  PPPPPPPPPPP${c2}MM${c1}P${c2}MM${c1}PPPP${c2}MM${c1}PPPPP${c2}MMMMMMMMMMM${c1}PP\n${c1}${c1}   PPPPPPPP${c2}MMMMMM${c1}PPPPP${c2}MM${c1}PPPPPP${c2}MMMMMMMMM${c1}PP\n${c1}${c1}   PPPP${c2}MM${c1}P${c2}MMMMMMM${c1}PPPPPP${c2}MM${c1}PPPPPPPPPP${c2}MMMM${c1}PP\n${c1}${c1}    PP${c2}MMMMMMMMM${c1}P${c2}M${c1}PPPP${c2}MMMMMM${c1}PPPPPPPPPPPPP\n${c1}${c1}     PP${c2}MMMMMMM${c1}PPPPPPP${c2}MMMMMM${c1}PPPPPPPPPPPP\n${c1}${c1}       PP${c2}MMMM${c1}PPPPPPPPP${c2}MMMMMMM${c1}PPPPPPPP\n${c1}${c1}         PP${c2}MM${c1}PPPPPPPP${c2}MMMMMMMMMM${c1}PPPP\n${c1}${c1}           PPPPPPPPPP${c2}MMMMMMMM${c1}PPPP\n${c1}${c1}               PPPPPPPPPPPPPP",
    },
    "Porteus": {
        "colors": [6, 7],
        "logo": "${c1}         -+ydmNNNNNNNmdy+-\n${c1}      .+dNmdhs+//////+shdmdo.\n${c1}    .smmy+-`             ./sdy:\n${c1}  `omdo.    `.-/+osssso+/-` `+dy.\n${c1} `yms.   `:shmNmdhsoo++osyyo-``oh.\n${c1} hm/   .odNmds/.`    ``.....:::-+s\n${c1}/m:  `+dNmy:`   `./oyhhhhyyooo++so\n${c1}ys  `yNmy-    .+hmmho:-.`     ```\n${c1}s:  yNm+`   .smNd+.\n${c1}`` /Nm:    +dNd+`\n${c1}   yN+   `smNy.\n${c1}   dm    oNNy`\n${c1}   hy   -mNm.\n${c1}   +y   oNNo\n${c1}   `y`  sNN:\n${c1}    `:  +NN:\n${c1}     `  .mNo\n${c1}         /mm`\n${c1}          /my`\n${c1}           .sy`\n${c1}             .+:\n${c1}                `",
    },
    "postmarketos_small": {
        "colors": [2, 7],
        "logo": "${c1}       /  \\\\\n${c1}      /    \\\\\n${c1}      \\\\__   \\\\\n${c1}    /\\\\__ \\\\  _\\\\\n${c1}   /   /  \\\\/ __\n${c1}  /   / ____/  \\\\\n${c1} /    \\\\ \\\\       \\\\\n${c1}/_____/ /________\\\\",
    },
    "PostMarketOS": {
        "colors": [2, 7],
        "logo": "${c1}                /  \\\\\n${c1}               /    \\\\\n${c1}              /      \\\\\n${c1}             /        \\\\\n${c1}            /          \\\\\n${c1}            \\\\           \\\\\n${c1}          /\\\\ \\\\____       \\\\\n${c1}         /  \\\\____ \\\\       \\\\\n${c1}        /       /  \\\\       \\\\\n${c1}       /       /    \\\\    ___\\\\\n${c1}      /       /      \\\\  / ____\n${c1}     /       /        \\\\/ /    \\\\\n${c1}    /       / __________/      \\\\\n${c1}   /        \\\\ \\\\                 \\\\\n${c1}  /          \\\\ \\\\                 \\\\\n${c1} /           / /                  \\\\\n${c1}/___________/ /____________________\\\\",
    },
    "Proxmox": {
        "colors": [7, 202],
        "logo": "${c1}       `hMMMMMMd/          /dMMMMMMh`\n${c1}        `sMMMMMMMd:      :mMMMMMMMs`\n${c1}${c2}`-/+oo+/:${c1}`.yMMMMMMMh-  -hMMMMMMMy.`${c2}:/+oo+/-`\n${c1}`:oooooooo/${c1}`-hMMMMMMMyyMMMMMMMh-`${c2}/oooooooo:`\n${c1}  `/oooooooo:${c1}`:mMMMMMMMMMMMMm:`${c2}:oooooooo/`\n${c1}    ./ooooooo+-${c1} +NMMMMMMMMN+ ${c2}-+ooooooo/.\n${c1}      .+ooooooo+-${c1}`oNMMMMNo`${c2}-+ooooooo+.\n${c1}        -+ooooooo/.${c1}`sMMs`${c2}./ooooooo+-\n${c1}          :oooooooo/${c1}`..`${c2}/oooooooo:\n${c1}          :oooooooo/`${c1}..${c2}`/oooooooo:\n${c1}        -+ooooooo/.`${c1}sMMs${c2}`./ooooooo+-\n${c1}      .+ooooooo+-`${c1}oNMMMMNo${c2}`-+ooooooo+.\n${c1}    ./ooooooo+-${c1} +NMMMMMMMMN+ ${c2}-+ooooooo/.\n${c1}  `/oooooooo:`${c1}:mMMMMMMMMMMMMm:${c2}`:oooooooo/`\n${c1}`:oooooooo/`${c1}-hMMMMMMMyyMMMMMMMh-${c2}`/oooooooo:`\n${c1}`-/+oo+/:`${c1}.yMMMMMMMh-  -hMMMMMMMy.${c2}`:/+oo+/-`\n${c1}${c1}        `sMMMMMMMm:      :dMMMMMMMs`\n${c1}       `hMMMMMMd/          /dMMMMMMh`\n${c1}         `://:`              `://:`",
    },
    "pureos_small": {
        "colors": [2, 7, 7],
        "logo": "${c1}|  _________  |\n${c1}| |         | |\n${c1}| |         | |\n${c1}| |_________| |\n${c1}|_____________|",
    },
    "PureOS": {
        "colors": [2, 7, 7],
        "logo": "${c1}dNm//////////////////////////////////mNd\n${c1}dNd                                  dNd\n${c1}dNd                                  dNd\n${c1}dNd                                  dNd\n${c1}dNd                                  dNd\n${c1}dNd                                  dNd\n${c1}dNd                                  dNd\n${c1}dNd                                  dNd\n${c1}dNd                                  dNd\n${c1}dNm//////////////////////////////////mNd\n${c1}dmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmd",
    },
    "Qubes": {
        "colors": [4, 5, 7, 6],
        "logo": "${c1}            `.----------.`\n${c1}        `..----------------..`\n${c1}     `.------------------------.``\n${c1} `..-------------....-------------..`\n${c1}.::----------..``    ``..----------:+:\n${c1}:////:----..`            `..---:/ossso\n${c1}:///////:`                  `/osssssso\n${c1}:///////:                    /ssssssso\n${c1}:///////:                    /ssssssso\n${c1}:///////:                    /ssssssso\n${c1}:///////:                    /ssssssso\n${c1}:///////:                    /ssssssso\n${c1}:////////-`                .:sssssssso\n${c1}:///////////-.`        `-/osssssssssso\n${c1}`//////////////:-```.:+ssssssssssssso-\n${c1}  .-://////////////sssssssssssssso/-`\n${c1}     `.:///////////sssssssssssssso:.\n${c1}         .-:///////ssssssssssssssssss/`\n${c1}            `.:////ssss+/+ssssssssssss.\n${c1}                `--//-    `-/osssso/.",
    },
    "Radix": {
        "colors": [1, 2],
        "logo": "${c2}             `/yhyoosdms`\n${c2}            -o+/ohmmho-\n${c2}           ..`.:/:-`\n${c2}     `.--:::-.``${c1}\n${c2}  .+ydNMMMMMMNmhs:`\n${c2}`omMMMMMMMMMMMMMMNh-\n${c2}oNMMMNmddhhyyhhhddmy.\n${c2}mMMMMNmmddhhysoo+/:-`\n${c2}yMMMMMMMMMMMMMMMMNNh.\n${c2}-dmmmmmNNMMMMMMMMMMs`\n${c2} -+oossyhmMMMMMMMMd-\n${c2} `sNMMMMMMMMMMMMMm:\n${c2}  `yMMMMMMNmdhhhh:\n${c2}   `sNMMMMMNmmho.\n${c2}    `+mMMMMMMMy.\n${c2}      .yNMMMm+`\n${c2}       `:yd+.",
    },
    "Raspbian_small": {
        "colors": [2, 1],
        "logo": "${c1}  '. \\\\ ' ' / .'\n${c1}${c2}   .~ .~~~..~.\n${c1}  : .~.'~'.~. :\n${c1} ~ (   ) (   ) ~\n${c1}( : '~'.~.'~' : )\n${c1} ~ .~ (   ) ~. ~\n${c1}  (  : '~' :  )\n${c1}   '~ .~~~. ~'\n${c1}       '~'",
    },
    "Raspbian": {
        "colors": [2, 1],
        "logo": "${c1} `+oooooooooooo:   `+oooooooooooo:\n${c1}  /oooo++//ooooo:  ooooo+//+ooooo.\n${c1}  `+ooooooo:-:oo-  +o+::/ooooooo:\n${c1}   `:oooooooo+``    `.oooooooo+-\n${c1}     `:++ooo/.        :+ooo+/.`\n${c1}        ${c2}...`  `.----.` ``..\n${c1}     .::::-``:::::::::.`-:::-`\n${c1}    -:::-`   .:::::::-`  `-:::-\n${c1}   `::.  `.--.`  `` `.---.``.::`\n${c1}       .::::::::`  -::::::::` `\n${c1} .::` .:::::::::- `::::::::::``::.\n${c1}-:::` ::::::::::.  ::::::::::.`:::-\n${c1}::::  -::::::::.   `-::::::::  ::::\n${c1}-::-   .-:::-.``....``.-::-.   -::-\n${c1} .. ``       .::::::::.     `..`..\n${c1}   -:::-`   -::::::::::`  .:::::`\n${c1}   :::::::` -::::::::::` :::::::.\n${c1}   .:::::::  -::::::::. ::::::::\n${c1}    `-:::::`   ..--.`   ::::::.\n${c1}      `...`  `...--..`  `...`\n${c1}            .::::::::::\n${c1}             `.-::::-`",
    },
    "Redcore": {
        "colors": [1],
        "logo": "${c1}               RRRRRRRRRRRRR\n${c1}        RRRRRRRRRR      RRRRR\n${c1}   RRRRRRRRRRRRRRRRRRRRRRRRRRR\n${c1} RRRRRRR  RRR         RRR RRRRRRRR\n${c1}RRRRR    RR                 RRRRRRRRR\n${c1}RRRR    RR     RRRRRRRR      RR RRRRRR\n${c1}RRRR   R    RRRRRRRRRRRRRR   RR   RRRRR\n${c1}RRRR   R  RRRRRRRRRRRRRRRRRR  R   RRRRR\n${c1}RRRR     RRRRRRRRRRRRRRRRRRR  R   RRRR\n${c1} RRR     RRRRRRRRRRRRRRRRRRRR R   RRRR\n${c1}  RRR    RRRRRRRRRRRRRRRRRRRR    RRRR\n${c1}    RR   RRRRRRRRRRRRRRRRRRR    RRR\n${c1}     RR   RRRRRRRRRRRRRRRRR    RRR\n${c1}       RR   RRRRRRRRRRRRRR   RR\n${c1}         R       RRRR      RR",
    },
    "Regata": {
        "colors": [7, 1, 4, 5, 3, 2],
        "logo": "${c1}        dho/.`hh${c2}.:/+/:.${c1}hhh`:+yd\n${c1}      do-hhhhhh${c2}/sssssss+`${c1}hhhhh./yd\n${c1}    h/`hhhhhhh${c2}-sssssssss:${c1}hhhhhhhh-yd\n${c1}  do`hhhhhhhhh${c2}`ossssssso.${c1}hhhhhhhhhh/d\n${c1} d/hhhhhhhhhhhh${c2}`/ossso/.${c1}hhhhhhhhhhhh.h\n${c1} /hhhhhhhhhhhh${c3}`-/osyso/-`${c1}hhhhhhhhhhhh.h\n${c1}shh${c4}-/ooo+-${c1}hhh${c3}:syyso+osyys/`${c1}hhh${c5}`+oo`${c1}hhh/\n${c1}h${c4}`ohhhhhhho`${c3}+yyo.${c1}hhhhh${c3}.+yyo`${c5}.sssssss.${c1}h`h\n${c1}s${c4}:hhhhhhhhho${c3}yys`${c1}hhhhhhh${c3}.oyy/${c5}ossssssso-${c1}hs\n${c1}s${c4}.yhhhhhhhy/${c3}yys`${c1}hhhhhhh${c3}.oyy/${c5}ossssssso-${c1}hs\n${c1}hh${c4}./syyys+.${c1} ${c3}+yy+.${c1}hhhhh${c3}.+yyo`${c5}.ossssso/${c1}h`h\n${c1}shhh${c4}``.`${c1}hhh${c3}`/syyso++oyys/`${c1}hhh${c5}`+++-`${c1}hh:h\n${c1}d/hhhhhhhhhhhh${c3}`-/osyso+-`${c1}hhhhhhhhhhhh.h\n${c1} d/hhhhhhhhhhhh${c6}`/ossso/.${c1}hhhhhhhhhhhh.h\n${c1}  do`hhhhhhhhh${c6}`ossssssso.${c1}hhhhhhhhhh:h\n${c1}    h/`hhhhhhh${c6}-sssssssss:${c1}hhhhhhhh-yd\n${c1}      h+.hhhhhh${c6}+sssssss+${c1}hhhhhh`/yd\n${c1}        dho:.hhh${c6}.:+++/.${c1}hhh`-+yd\n${c1}            ddhso+++++osyhd",
    },
    "Regolith": {
        "colors": [1],
        "logo": "${c1}                 ``....```\n${c1}            `.:/++++++/::-.`\n${c1}          -/+++++++:.`\n${c1}        -++++++++:`\n${c1}      `/++++++++-\n${c1}     `/++++++++.                    -/+/\n${c1}     /++++++++/             ``   .:+++:.\n${c1}    -+++++++++/          ./++++:+++/-`\n${c1}    :+++++++++/         `+++++++/-`\n${c1}    :++++++++++`      .-/+++++++`\n${c1}   `:++++++++++/``.-/++++:-:::-`      `\n${c1} `:+++++++++++++++++/:.`            ./`\n${c1}:++/-:+++++++++/:-..              -/+.\n${c1}+++++++++/::-...:/+++/-..````..-/+++.\n${c1}`......``.::/+++++++++++++++++++++/.\n${c1}         -/+++++++++++++++++++++/.\n${c1}           .:/+++++++++++++++/-`\n${c1}              `.-:://////:-.",
    },
    "Rosa": {
        "colors": [4, 7, 1],
        "logo": "${c1}        ROSA               AROS\n${c1}      ROS   SAROSAROSAROSAR   AROS\n${c1}    RO   ROSAROSAROSAROSAROSAR   RO\n${c1}  ARO  AROSAROSAROSARO      AROS  ROS\n${c1} ARO  ROSAROS         OSAR   ROSA  ROS\n${c1} RO  AROSA   ROSAROSAROSA    ROSAR  RO\n${c1}RO  ROSAR  ROSAROSAROSAR  R  ROSARO  RO\n${c1}RO  ROSA  AROSAROSAROSA  AR  ROSARO  AR\n${c1}RO AROS  ROSAROSAROSA   ROS  AROSARO AR\n${c1}RO AROS  ROSAROSARO   ROSARO  ROSARO AR\n${c1}RO  ROS  AROSAROS   ROSAROSA AROSAR  AR\n${c1}RO  ROSA  ROS     ROSAROSAR  ROSARO  RO\n${c1} RO  ROS     AROSAROSAROSA  ROSARO  AR\n${c1} ARO  ROSA   ROSAROSAROS   AROSAR  ARO\n${c1}  ARO  OROSA      R      ROSAROS  ROS\n${c1}    RO   AROSAROS   AROSAROSAR   RO\n${c1}     AROS   AROSAROSAROSARO   AROS\n${c1}        ROSA               SARO\n${c1}           ROSAROSAROSAROSAR",
    },
    "sabotage": {
        "colors": [4, 7, 1],
        "logo": "${c2} ||..  '     |||     ||   ||  .|'    ||\n${c2}  ''|||.    |  ||    ||'''|.  ||      ||\n${c2}.     '||  .''''|.   ||    || '|.     ||\n${c2}|'....|'  .|.  .||. .||...|'   ''|...|'\n${c2}\n${c2}|''||''|     |      ..|'''.|  '||''''|\n${c2}   ||       |||    .|'     '   ||  .\n${c2}   ||      |  ||   ||    ....  ||''|\n${c2}   ||     .''''|.  '|.    ||   ||\n${c2}  .||.   .|.  .||.  ''|...'|  .||.....|",
    },
    "Sabayon": {
        "colors": [4, 7, 1],
        "logo": "${c1}         ..             ..\n${c1}      ..                   ..\n${c1}    ..           ${c2}o           ${c1}..\n${c1}  ..            ${c2}:W'            ${c1}..\n${c1} ..             ${c2}.d.             ${c1}..\n${c1}:.             ${c2}.KNO              ${c1}.:\n${c1}:.             ${c2}cNNN.             ${c1}.:\n${c1}:              ${c2}dXXX,              ${c1}:\n${c1}:   ${c2}.          dXXX,       .cd,   ${c1}:\n${c1}:   ${c2}'kc ..     dKKK.    ,ll;:'    ${c1}:\n${c1}:     ${c2}.xkkxc;..dkkkc',cxkkl       ${c1}:\n${c1}:.     ${c2}.,cdddddddddddddo:.       ${c1}.:\n${c1} ..         ${c2}:lllllll:           ${c1}..\n${c1}   ..         ${c2}',,,,,          ${c1}..\n${c1}     ..                     ..\n${c1}        ..               ..\n${c1}          ...............",
    },
    "Sailfish": {
        "colors": [4, 5, 7, 6],
        "logo": "${c1}              _#b (b\n${c1}            _@@   @_         _,\n${c1}          _#^@ _#*^^*gg,aa@^^\n${c1}          #- @@^  _a@^^\n${c1}          @_  *g#b\n${c1}          ^@_   ^@_\n${c1}            ^@_   @\n${c1}             @(b (b\n${c1}            #b(b#^\n${c1}          _@_#@^\n${c1}       _a@a*^\n${c1}   ,a@*^",
    },
    "SalentOS": {
        "colors": [2, 1, 3, 7],
        "logo": "${c1}        .-:+oshdNMMMMMMNdhyo+:-.`\n${c1}  -oydmMMMMMMMMMMMMMMMMMMMMMMMMMMNdhs/\n${c1}${c4} +hdddm${c1}NMMMMMMMMMMMMMMMMMMMMMMMMN${c4}mdddh+`\n${c1}${c2}`MMMMMN${c4}mdddddm${c1}MMMMMMMMMMMM${c4}mdddddm${c3}NMMMMM-\n${c1}${c2} mMMMMMMMMMMMN${c4}ddddhyyhhddd${c3}NMMMMMMMMMMMM`\n${c1}${c2} dMMMMMMMMMMMMMMMMM${c4}oo${c3}MMMMMMMMMMMMMMMMMN`\n${c1}${c2} yMMMMMMMMMMMMMMMMM${c4}hh${c3}MMMMMMMMMMMMMMMMMd\n${c1}${c2} +MMMMMMMMMMMMMMMMM${c4}hh${c3}MMMMMMMMMMMMMMMMMy\n${c1}${c2} :MMMMMMMMMMMMMMMMM${c4}hh${c3}MMMMMMMMMMMMMMMMMo\n${c1}${c2} .MMMMMMMMMMMMMMMMM${c4}hh${c3}MMMMMMMMMMMMMMMMM/\n${c1}${c2} `NMMMMMMMMMMMMMMMM${c4}hh${c3}MMMMMMMMMMMMMMMMM-\n${c1}${c2}  mMMMMMMMMMMMMMMMM${c4}hh${c3}MMMMMMMMMMMMMMMMN`\n${c1}${c2}  hMMMMMMMMMMMMMMMM${c4}hh${c3}MMMMMMMMMMMMMMMMm\n${c1}${c2}  /MMMMMMMMMMMMMMMM${c4}hh${c3}MMMMMMMMMMMMMMMMy\n${c1}${c2}   .+hMMMMMMMMMMMMM${c4}hh${c3}MMMMMMMMMMMMMms:\n${c1}${c2}      `:smMMMMMMMMM${c4}hh${c3}MMMMMMMMMNh+.\n${c1}${c2}          .+hMMMMMM${c4}hh${c3}MMMMMMdo:\n${c1}${c2}             `:smMM${c4}yy${c3}MMNy/`\n${c1}                 ${c2}.- ${c4}`${c3}:.",
    },
    "Scientific": {
        "colors": [4, 7, 1],
        "logo": "${c1}                +:    //\n${c1}               /;      /;\n${c1}              -X        H.\n${c1}.//;;;:;;-,   X=        :+   .-;:=;:;#;.\n${c1}M-       ,=;;;#:,      ,:#;;:=,       ,@\n${c1}:#           :#.=/++++/=.$=           #=\n${c1} ,#;         #/:+/;,,/++:+/         ;+.\n${c1}   ,+/.    ,;@+,        ,#H;,    ,/+,\n${c1}      ;+;;/= @.  ${c3}.H${c2}#${c3}#X   ${c1}-X :///+;\n${c1}      ;+=;;;.@,  ${c2}.X${c3}M${c2}@$.  ${c1}=X.//;=#/.\n${c1}   ,;:      :@#=        =$H:     .+#-\n${c1} ,#=         #;-///==///-//         =#,\n${c1};+           :#-;;;:;;;;-X-           +:\n${c1}@-      .-;;;;M-        =M/;;;-.      -X\n${c1} :;;::;;-.    #-        :+    ,-;;-;:==\n${c1}              ,X        H.\n${c1}               ;/      #=\n${c1}                //    +;\n${c1}                 '////'",
    },
    "Septor": {
        "colors": [4, 7, 4],
        "logo": "${c1}ssssssssssssssssssssssssssssssssssssssss\n${c1}ssssssssssssssssssssssssssssssssssssssss\n${c1}ssssssssssssssssssssssssssssssssssssssss\n${c1}ssssssssss${c2};okOOOOOOOOOOOOOOko;${c1}ssssssssss\n${c1}sssssssss${c2}oNWWWWWWWWWWWWWWWWWWNo${c1}sssssssss\n${c1}ssssssss${c2}:WWWWWWWWWWWWWWWWWWWWWW:${c1}ssssssss\n${c1}ssssssss${c2}lWWWWWk${c1}ssssssssss${c2}lddddd:${c1}ssssssss\n${c1}ssssssss${c2}cWWWWWNKKKKKKKKKKKKOx:${c1}ssssssssss\n${c1}${c3}yy${c1}sssssss${c2}OWWWWWWWWWWWWWWWWWWWWx${c1}sssssss${c3}yy\n${c1}yyyyyyyyyy${c2}:kKNNNNNNNNNNNNWWWWWW:${c3}yyyyyyyy\n${c1}yyyyyyyy${c2}sccccc;${c3}yyyyyyyyyy${c2}kWWWWW:${c3}yyyyyyyy\n${c1}yyyyyyyy${c2}:WWWWWWNNNNNNNNNNWWWWWW;${c3}yyyyyyyy\n${c1}yyyyyyyy${c2}.dWWWWWWWWWWWWWWWWWWWNd${c3}yyyyyyyyy\n${c1}yyyyyyyyyy${c2}sdO0KKKKKKKKKKKK0Od;${c3}yyyyyyyyyy\n${c1}yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy\n${c1}yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy\n${c1}yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy\n${c1}yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy\n${c1}yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy",
    },
    "Serene": {
        "colors": [6, 6],
        "logo": "${c1}          .                      .\n${c1}        :                          :\n${c1}      -                       _______----_-\n${c1}     s               __----'''     __----\n${c1} __h_            _-'           _-'     h\n${c1} '-._''--.._    ;           _-'         y\n${c1}  :  ''-._  '-._/        _-'             :\n${c1}  y       ':_       _--''                y\n${c1}  m    .--'' '-._.;'                     m\n${c1}  m   :        :                         m\n${c1}  y    '.._     '-__                     y\n${c1}  :        '--._    '''----___           :\n${c1}   y            '--._         ''-- _    y\n${c1}    h                '--._          :  h\n${c1}     s                  __';         vs\n${c1}      -         __..--''             -\n${c1}        :_..--''                   :\n${c1}          .                     _ .\n${c1}            `''---______---''-``",
    },
    "SharkLinux": {
        "colors": [4, 7],
        "logo": "${c1}                          `:yNMMMMs\n${c1}                       `-smMMMMMMN.\n${c1}                     .+dNMMMMMMMMs\n${c1}                   .smNNMMMMMMMMm`\n${c1}                 .sNNNNNNNMMMMMM/\n${c1}               `omNNNNNNNMMMMMMm\n${c1}              /dNNNNNNNNMMMMMMM+\n${c1}            .yNNNNNNNNNMMMMMMMN`\n${c1}           +mNNNNNNNNNMMMMMMMMh\n${c1}         .hNNNNNNNNNNMMMMMMMMMs\n${c1}        +mMNNNNNNNNMMMMMMMMMMMs\n${c1}      .hNMMNNNNMMMMMMMMMMMMMMMd\n${c1}    .oNNNNNNNNNNMMMMMMMMMMMMMMMo\n${c1} `:+syyssoo++++ooooossssssssssso:",
    },
    "Siduction": {
        "colors": [4, 4],
        "logo": '${c1}               jQh: =$w\n${c1}               QWmwawQW\n${c1}               )$QQQQ@(   ..\n${c1}         _a_a.   ~??^  syDY?Sa,\n${c1}       _mW>-<$c       jWmi  imm.\n${c1}       ]QQwayQE       4QQmgwmQQ`\n${c1}        ?WWQWP\'       -9QQQQQ@\'._aas,\n${c1} _a%is.        .adYYs,. -"?!` aQB*~^3$c\n${c1}_Qh;.nm       .QWc. {QL      ]QQp;..vmQ/\n${c1}"QQmmQ@       -QQQggmQP      ]QQWmggmQQ(\n${c1} -???"         "$WQQQY`  __,  ?QQQQQQW!\n${c1}        _yZ!?q,   -   .yWY!!Sw, "???^\n${c1}       .QQa_=qQ       mQm>..vmm\n${c1}        $QQWQQP       $QQQgmQQ@\n${c1}         "???"   _aa, -9WWQQWY`\n${c1}               _mB>~)$a  -~~\n${c1}               mQms_vmQ.\n${c1}               ]WQQQQQP\n${c1}                -?T??"',
    },
    "slackware_small": {
        "colors": [4, 7, 1],
        "logo": "${c1}  /  ______|\n${c1}  | |______\n${c1}  \\\\______  \\\\\n${c1}   ______| |\n${c1}| |________/\n${c1}|____________",
    },
    "Slackware": {
        "colors": [4, 7, 1],
        "logo": "${c1}            :::::::::::::::::::\n${c1}         :::::::::::::::::::::::::\n${c1}       ::::::::${c2}cllcccccllllllll${c1}::::::\n${c1}    :::::::::${c2}lc               dc${c1}:::::::\n${c1}   ::::::::${c2}cl   clllccllll    oc${c1}:::::::::\n${c1}  :::::::::${c2}o   lc${c1}::::::::${c2}co   oc${c1}::::::::::\n${c1} ::::::::::${c2}o    cccclc${c1}:::::${c2}clcc${c1}::::::::::::\n${c1} :::::::::::${c2}lc        cclccclc${c1}:::::::::::::\n${c1}::::::::::::::${c2}lcclcc          lc${c1}::::::::::::\n${c1}::::::::::${c2}cclcc${c1}:::::${c2}lccclc     oc${c1}:::::::::::\n${c1}::::::::::${c2}o    l${c1}::::::::::${c2}l    lc${c1}:::::::::::\n${c1} :::::${c2}cll${c1}:${c2}o     clcllcccll     o${c1}:::::::::::\n${c1} :::::${c2}occ${c1}:${c2}o                  clc${c1}:::::::::::\n${c1}  ::::${c2}ocl${c1}:${c2}ccslclccclclccclclc${c1}:::::::::::::\n${c1}   :::${c2}oclcccccccccccccllllllllllllll${c1}:::::\n${c1}    ::${c2}lcc1lcccccccccccccccccccccccco${c1}::::\n${c1}      ::::::::::::::::::::::::::::::::\n${c1}        ::::::::::::::::::::::::::::\n${c1}           ::::::::::::::::::::::\n${c1}                ::::::::::::",
    },
    "SliTaz": {
        "colors": [3, 3],
        "logo": "${c1}      @@   @@                  @    @/\n${c1}     @@   @@                   @@   @@\n${c1}    @@  %@@                     @@   @@\n${c1}   @@  %@@@       @@@@@.       @@@@  @@\n${c1}  @@@    @@@@    @@@@@@@    &@@@    @@@\n${c1}   @@@@@@@ %@@@@@@@@@@@@ &@@@% @@@@@@@/\n${c1}       ,@@@@@@@@@@@@@@@@@@@@@@@@@\n${c1}  .@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@/\n${c1}@@@@@@.  @@@@@@@@@@@@@@@@@@@@@  /@@@@@@\n${c1}@@    @@@@@  @@@@@@@@@@@@,  @@@@@   @@@\n${c1}@@ @@@@.    @@@@@@@@@@@@@%    #@@@@ @@.\n${c1}@@ ,@@      @@@@@@@@@@@@@      @@@  @@\n${c1}@   @@.     @@@@@@@@@@@@@     @@@  *@\n${c1}@    @@     @@@@@@@@@@@@      @@   @\n${c1}      @      @@@@@@@@@.     #@\n${c1}       @      ,@@@@@       @",
    },
    "SmartOS": {
        "colors": [6, 7],
        "logo": "${c1}yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy\n${c1}yyyys             oyyyyyyyyyyyyyyyy\n${c1}yyyys  yyyyyyyyy  oyyyyyyyyyyyyyyyy\n${c1}yyyys  yyyyyyyyy  oyyyyyyyyyyyyyyyy\n${c1}yyyys  yyyyyyyyy  oyyyyyyyyyyyyyyyy\n${c1}yyyys  yyyyyyyyy  oyyyyyyyyyyyyyyyy\n${c1}yyyys  yyyyyyyyyyyyyyyyyyyyyyyyyyyy\n${c1}yyyyy                         syyyy\n${c1}yyyyyyyyyyyyyyyyyyyyyyyyyyyy  syyyy\n${c1}yyyyyyyyyyyyyyyy  syyyyyyyyy  syyyy\n${c1}yyyyyyyyyyyyyyyy  oyyyyyyyyy  syyyy\n${c1}yyyyyyyyyyyyyyyy  oyyyyyyyyy  syyyy\n${c1}yyyyyyyyyyyyyyyy  syyyyyyyyy  syyyy\n${c1}yyyyyyyyyyyyyyyy              yyyyy\n${c1}yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy\n${c1}yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy",
    },
    "Solus": {
        "colors": [4, 7, 1],
        "logo": "${c2}          `-+/------------.`\n${c2}       .---:mNo---------------.\n${c2}     .-----yMMMy:---------------.\n${c2}   `------oMMMMMm/----------------`\n${c2}  .------/MMMMMMMN+----------------.\n${c2} .------/NMMMMMMMMm-+/--------------.\n${c2}`------/NMMMMMMMMMN-:mh/-------------`\n${c2}.-----/NMMMMMMMMMMM:-+MMd//oso/:-----.\n${c2}-----/NMMMMMMMMMMMM+--mMMMh::smMmyo:--\n${c2}----+NMMMMMMMMMMMMMo--yMMMMNo-:yMMMMd/.\n${c2}.--oMMMMMMMMMMMMMMMy--yMMMMMMh:-yMMMy-`\n${c2}`-sMMMMMMMMMMMMMMMMh--dMMMMMMMd:/Ny+y.\n${c2}`-/+osyhhdmmNNMMMMMm-/MMMMMMMmh+/ohm+\n${c2}  .------------:://+-/++++++${c1}oshddys:\n${c2}   -hhhhyyyyyyyyyyyhhhhddddhysssso-\n${c2}    `:ossssssyysssssssssssssssso:`\n${c2}      `:+ssssssssssssssssssss+-\n${c2}         `-/+ssssssssssso+/-`\n${c2}              `.-----..`",
    },
    "Sparky": {
        "colors": [1, 7],
        "logo": "${c1}           .            `-:-`\n${c1}          .o`       .-///-`\n${c1}         `oo`    .:/++:.\n${c1}         os+`  -/+++:` ``.........```\n${c1}        /ys+`./+++/-.-::::::----......``\n${c1}       `syyo`++o+--::::-::/+++/-``\n${c1}       -yyy+.+o+`:/:-:sdmmmmmmmmdy+-`\n${c1}::-`   :yyy/-oo.-+/`ymho++++++oyhdmdy/`\n${c1}`/yy+-`.syyo`+o..o--h..osyhhddhs+//osyy/`\n${c1}  -ydhs+-oyy/.+o.-: ` `  :/::+ydhy+```-os-\n${c1}   .sdddy::syo--/:.     `.:dy+-ohhho    ./:\n${c1}     :yddds/:+oo+//:-`- /+ +hy+.shhy:     ``\n${c1}      `:ydmmdysooooooo-.ss`/yss--oyyo\n${c1}        `./ossyyyyo+:-/oo:.osso- .oys\n${c1}       ``..-------::////.-oooo/   :so\n${c1}    `...----::::::::--.`/oooo:    .o:\n${c1}           ```````     ++o+:`     `:`\n${c1}                     ./+/-`        `\n${c1}                   `-:-.\n${c1}                   ``",
    },
    "Star": {
        "colors": [7],
        "logo": "${c1}                  `yy-\n${c1}                 `y.`y`\n${c1}    ``           s-  .y            `\n${c1}    +h//:..`    +/    /o    ``..:/so\n${c1}     /o``.-::/:/+      o/://::-.`+o`\n${c1}      :s`     `.        .`     `s/\n${c1}       .y.                    .s-\n${c1}        `y-                  :s`\n${c1}      .-//.                  /+:.\n${c1}   .:/:.                       .:/:.\n${c1}-+o:.                             .:+:.\n${c1}-///++///:::`              .-::::///+so-\n${c1}       ``..o/              d-....```\n${c1}           s.     `/.      d\n${c1}           h    .+o-+o-    h.\n${c1}           h  -o/`   `/o:  s:\n${c1}          -s/o:`       `:o/+/\n${c1}          /s-             -yo",
    },
    "SteamOS": {
        "colors": [5, 7],
        "logo": "${c1}        .,'onNMMMMMNNnn',.\n${c1}     .'oNMANKMMMMMMMMMMMNNn'.\n${c1}   .'ANMMMMMMMXKNNWWWPFFWNNMNn.\n${c1}  ;NNMMMMMMMMMMNWW'' ,.., 'WMMM,\n${c1} ;NMMMMV+##+VNWWW' .+;'':+, 'WMW,\n${c1},VNNWP+${c2}######${c1}+WW,  ${c2}+:    ${c1}:+, +MMM,\n${c1}'${c2}+#############,   +.    ,+' ${c1}+NMMM\n${c1}${c2}  '*#########*'     '*,,*' ${c1}.+NMMMM.\n${c1}${c2}     `'*###*'          ,.,;###${c1}+WNM,\n${c1}${c2}         .,;;,      .;##########${c1}+W\n${c1}${c2},',.         ';  ,+##############'\n${c1} '###+. :,. .,; ,###############'\n${c1}  '####.. `'' .,###############'\n${c1}    '#####+++################'\n${c1}      '*##################*'\n${c1}         ''*##########*''\n${c1}              ''''''",
    },
    "t2": {
        "colors": [7, 4],
        "logo": "${c2}TTTTTTTTTT\n${c2}    tt   ${c1}222${c2}\n${c2}    tt  ${c1}2   2${c2}\n${c2}    tt     ${c1}2${c2}\n${c2}    tt    ${c1}2${c2}\n${c2}    tt  ${c1}22222${c2}",
    },
    "SwagArch": {
        "colors": [4, 7, 1],
        "logo": "${c2}   ,lkXMMNK0OkkxkkOKWMMMMMMMMMM;\n${c2} 'K0xo  ..,;:c:.     `'lKMMMMM0\n${c2}     .lONMMMMMM'         `lNMk'\n${c2}${c2}    ;WMMMMMMMMMO.              ${c1}....::...\n${c2}${c2}    OMMMMMMMMMMMMKl.       ${c1}.,;;;;;ccccccc,\n${c2}${c2}    `0MMMMMMMMMMMMMM0:         ${c1}.. .ccccccc.\n${c2}${c2}      'kWMMMMMMMMMMMMMNo.   ${c1}.,:'  .ccccccc.\n${c2}${c2}        `c0MMMMMMMMMMMMMN,${c1},:c;    :cccccc:\n${c2}${c2} ckl.      `lXMMMMMMMMMX${c1}occcc:.. ;ccccccc.\n${c2}${c2}dMMMMXd,     `OMMMMMMWk${c1}ccc;:''` ,ccccccc:\n${c2}${c2}XMMMMMMMWKkxxOWMMMMMNo${c1}ccc;     .cccccccc.\n${c2}${c2} `':ldxO0KXXXXXK0Okdo${c1}cccc.     :cccccccc.\n${c2}                    :ccc:'     `cccccccc:,\n${c2}                                   ''",
    },
    "Tails": {
        "colors": [5, 7],
        "logo": "${c1}  ./yhNh\n${c1}syy/Nshh         `:o/\n${c1}N:dsNshh  █   `ohNMMd\n${c1}N-/+Nshh      `yMMMMd\n${c1}N-yhMshh       yMMMMd\n${c1}N-s:hshh  █    yMMMMd so//.\n${c1}N-oyNsyh       yMMMMd d  Mms.\n${c1}N:hohhhd:.     yMMMMd  syMMM+\n${c1}Nsyh+-..+y+-   yMMMMd   :mMM+\n${c1}+hy-      -ss/`yMMMM     `+d+\n${c1}  :sy/.     ./yNMMMMm      ``\n${c1}    .+ys- `:+hNMMMMMMy/`\n${c1}      `hNmmMMMMMMMMMMMMdo.\n${c1}       dMMMMMMMMMMMMMMMMMNh:\n${c1}       +hMMMMMMMMMMMMMMMMMmy.\n${c1}         -oNMMMMMMMMMMmy+.`\n${c1}           `:yNMMMds/.`\n${c1}              .//`",
    },
    "Trisquel": {
        "colors": [4, 6],
        "logo": "${c1}                      ▄█████████▄\n${c1}      ▄▄▄▄▄▄         ████▀   ▀████\n${c1}   ▄██████████▄     ████▀   ▄▄ ▀███\n${c1} ▄███▀▀   ▀▀████     ███▄   ▄█   ███\n${c1}▄███   ▄▄▄   ████▄    ▀██████   ▄███\n${c1}███   █▀▀██▄  █████▄     ▀▀   ▄████\n${c1}▀███      ███  ███████▄▄  ▄▄██████\n${c1}${c1} ▀███▄   ▄███  █████████████${c2}████▀\n${c1}${c1}  ▀█████████    ███████${c2}███▀▀▀\n${c1}    ▀▀███▀▀     ██████▀▀\n${c1}               ██████▀   ▄▄▄▄\n${c1}              █████▀   ████████\n${c1}              █████   ███▀  ▀███\n${c1}               ████▄   ██▄▄▄  ███\n${c1}                █████▄   ▀▀  ▄██\n${c1}                  ██████▄▄▄████\n${c1}                     ▀▀█████▀▀",
    },
    "Ubuntu-GNOME": {
        "colors": [4, 5, 7, 6],
        "logo": "${c3}        .oooooooo\n${c3}      .oooo```soooo\n${c3}    .oooo`     `soooo\n${c3}   .ooo`   ${c4}.o.${c3}   `\\/ooo.\n${c3}   :ooo   ${c4}:oooo.${c3}   `\\/ooo.\n${c3}    sooo    ${c4}`ooooo${c3}    \\/oooo\n${c3}     \\/ooo    ${c4}`soooo${c3}    `ooooo\n${c3}      `soooo    ${c4}`\\/ooo${c3}    `soooo\n${c3}${c4}./oo    ${c3}`\\/ooo    ${c4}`/oooo.${c3}   `/ooo\n${c3}${c4}`\\/ooo.   ${c3}`/oooo.   ${c4}`/oooo.${c3}   ``\n${c3}${c4}  `\\/ooo.    ${c3}/oooo     ${c4}/ooo`\n${c3}${c4}     `ooooo    ${c3}``    ${c4}.oooo\n${c3}${c4}       `soooo.     .oooo`\n${c3}         `\\/oooooooooo`\n${c3}            ``\\/oo``",
    },
    "ubuntu_old": {
        "colors": [1, 7, 3],
        "logo": "${c1}${c2}                 yyyyy- ${c1}-yyyyyy+\n${c1}${c2}              ${c2}://+//////${c1}-yyyyyyo\n${c1}${c3}          .++ ${c2}.:/++++++/-${c1}.+sss/`\n${c1}${c3}        .:++o:  ${c2}/++++++++/:--:/-\n${c1}${c3}       o:+o+:++.${c2}`..```.-/oo+++++/\n${c1}${c3}      .:+o:+o/.${c2}          `+sssoo+/\n${c1}${c2} .++/+:${c3}+oo+o:`${c2}             /sssooo.\n${c1}${c2}/+++//+:${c3}`oo+o${c2}               /::--:.\n${c1}${c2}+/+o+++${c3}`o++o${c1}               ++////.\n${c1}${c2} .++.o+${c3}++oo+:`${c1}             /dddhhh.\n${c1}${c3}      .+.o+oo:.${c1}          `oddhhhh+\n${c1}${c3}       +.++o+o`${c1}`-````.:ohdhhhhh+\n${c1}${c3}        `:o+++ ${c1}`ohhhhhhhhyo++os:\n${c1}${c3}          .o:${c1}`.syhhhhhhh/${c3}.oo++o`\n${c1}${c1}              /osyyyyyyo${c3}++ooo+++/\n${c1}${c1}                  ````` ${c3}+oo+++o:\n${c1}${c3}                         `oo++.",
    },
    "ubuntu_small": {
        "colors": [1, 7, 3],
        "logo": "${c1}     ---(_)\n${c1} _/  ---  \\\\\n${c1}(_) |   |\n${c1}  \\\\  --- _/\n${c1}     ---(_)",
    },
    "Venom": {
        "colors": [8, 4],
        "logo": "${c1}   mMMMMMMm        dMMMMMMm\n${c1}   /MMMMMMMo      +MMMMMMM/\n${c1}    yMMMMMMN      mMMMMMMy\n${c1}     NMMMMMMs    oMMMMMMm\n${c1}     +MMMMMMN:   NMMMMMM+\n${c1}      hMMMMMMy  sMMMMMMy\n${c1}      :NMMMMMM::NMMMMMN:\n${c1}       oMMMMMMyyMMMMMM+\n${c1}        dMMMMMMMMMMMMh\n${c1}        /MMMMMMMMMMMN:\n${c1}         sMMMMMMMMMMo\n${c1}          mMMMMMMMMd\n${c1}          +MMMMMMMN:\n${c1}            ::::::",
    },
    "void_small": {
        "colors": [2, 8],
        "logo": "${c1} _ \\\\______ -\n${c1}| \\\\  ___  \\\\ |\n${c1}| | /   \\ | |\n${c1}| | \\___/ | |\n${c1}| \\\\______ \\\\_|\n${c1} -_______\\\\",
    },
    "Void": {
        "colors": [2, 8],
        "logo": "${c1}            _.=+==++=++=+=+===;.\n${c1}             -=+++=+===+=+=+++++=_\n${c1}        .     -=:``     `--==+=++==.\n${c1}       _vi,    `            --+=++++:\n${c1}      .uvnvi.       _._       -==+==+.\n${c1}     .vvnvnI`    .;==|==;.     :|=||=|.\n${c1}${c2}+QmQQm${c1}pvvnv; ${c2}_yYsyQQWUUQQQm #QmQ#${c1}:${c2}QQQWUV$QQm.\n${c1}${c2} -QQWQW${c1}pvvo${c2}wZ?.wQQQE${c1}==<${c2}QWWQ/QWQW.QQWW${c1}(: ${c2}jQWQE\n${c1}${c2}  -$QQQQmmU'  jQQQ@${c1}+=<${c2}QWQQ)mQQQ.mQQQC${c1}+;${c2}jWQQ@'\n${c1}${c2}   -$WQ8Y${c1}nI:   ${c2}QWQQwgQQWV${c1}`${c2}mWQQ.jQWQQgyyWW@!\n${c1}${c1}     -1vvnvv.     `~+++`        ++|+++\n${c1}      +vnvnnv,                 `-|===\n${c1}       +vnvnvns.           .      :=-\n${c1}        -Invnvvnsi..___..=sv=.     `\n${c1}          +Invnvnvnnnnnnnnvvnn;.\n${c1}            ~|Invnvnvvnvvvnnv}+`\n${c1}               -~|{*l}*|~",
    },
    "Obarun": {
        "colors": [6, 6, 7, 1],
        "logo": "${c1}                ;cooolc;,\n${c1}             ,coool;\n${c1}           ,loool,\n${c1}          loooo;\n${c1}        :ooool\n${c1}       cooooc            ,:ccc;\n${c1}      looooc           :oooooool\n${c1}     cooooo          ;oooooooooo,\n${c1}    :ooooo;         :ooooooooooo\n${c1}    oooooo          oooooooooooc\n${c1}   :oooooo         :ooooooooool\n${c1}   loooooo         ;oooooooool\n${c1}   looooooc        .coooooooc\n${c1}   cooooooo:           ,;co;\n${c1}   ,ooooooool;       ,:loc\n${c1}    cooooooooooooloooooc\n${c1}     ;ooooooooooooool;\n${c1}       ;looooooolc;",
    },
    "Windows": {
        "colors": [1, 2, 4, 3],
        "logo": '${c1}       :tt:::tt333EE3\n${c1}${c1}       Et:::ztt33EEEL${c2} @Ee.,      ..,\n${c1}${c1}      ;tt:::tt333EE7${c2} ;EEEEEEttttt33#\n${c1}${c1}     :Et:::zt333EEQ.${c2} $EEEEEttttt33QL\n${c1}${c1}     it::::tt333EEF${c2} @EEEEEEttttt33F\n${c1}${c1}    ;3=*^```"*4EEV${c2} :EEEEEEttttt33@.\n${c1}${c3}    ,.=::::!t=., ${c1}`${c2} @EEEEEEtttz33QF\n${c1}${c3}   ;::::::::zt33)${c2}   "4EEEtttji3P*\n${c1}${c3}  :t::::::::tt33.${c4}:Z3z..${c2}  ``${c4} ,..g.\n${c1}${c3}  i::::::::zt33F${c4} AEEEtttt::::ztF\n${c1}${c3} ;:::::::::t33V${c4} ;EEEttttt::::t3\n${c1}${c3} E::::::::zt33L${c4} @EEEtttt::::z3F\n${c1}${c3}{3=*^```"*4E3)${c4} ;EEEtttt:::::tZ`\n${c1}${c3}             `${c4} :EEEEtttt::::z7\n${c1}                 "VEzjt:;;z>*`',
    },
    "Xubuntu": {
        "colors": [4, 7, 1],
        "logo": "${c1}        .+yddddddddddddddddddy+.\n${c1}      :yddddddddddddddddddddddddy:\n${c1}    -yddddddddddddddddddddhdddddddy-\n${c1}   odddddddddddyshdddddddh`dddd+ydddo\n${c1} `yddddddhshdd-   ydddddd+`ddh.:dddddy`\n${c1} sddddddy   /d.   :dddddd-:dy`-ddddddds\n${c1}:ddddddds    /+   .dddddd`yy`:ddddddddd:\n${c1}sdddddddd`    .    .-:/+ssdyodddddddddds\n${c1}ddddddddy                  `:ohddddddddd\n${c1}dddddddd.                      +dddddddd\n${c1}sddddddy                        ydddddds\n${c1}:dddddd+                      .oddddddd:\n${c1} sdddddo                   ./ydddddddds\n${c1} `yddddd.              `:ohddddddddddy`\n${c1}   oddddh/`      `.:+shdddddddddddddo\n${c1}    -ydddddhyssyhdddddddddddddddddy-\n${c1}      :yddddddddddddddddddddddddy:\n${c1}        .+yddddddddddddddddddy+.\n${c1}           `-/osyhddddhyso/-`",
    },
    "IRIX": {
        "colors": [4, 7],
        "logo": "${c1}     `:+ydNMMMMMMMM.-MMMMMMMMMdyo:.\n${c1}   `hMMMMMMNhs/sMMM-:MMM+/shNMMMMMMh`\n${c1}   -NMMMMMmo-` /MMM-/MMM- `-omMMMMMN.\n${c1} `.`-+hNMMMMMNhyMMM-/MMMshmMMMMMmy+...`\n${c1}+mMNds:-:sdNMMMMMMMyyMMMMMMMNdo:.:sdMMm+\n${c1}dMMMMMMmy+.-/ymNMMMMMMMMNmy/-.+hmMMMMMMd\n${c1}oMMMMmMMMMNds:.+MMMmmMMN/.-odNMMMMmMMMM+\n${c1}.MMMM-/ymMMMMMmNMMy..hMMNmMMMMMmy/-MMMM.\n${c1} hMMM/ `/dMMMMMMMN////NMMMMMMMd/. /MMMh\n${c1} /MMMdhmMMMmyyMMMMMMMMMMMMhymMMMmhdMMM:\n${c1} `mMMMMNho//sdMMMMM//NMMMMms//ohNMMMMd\n${c1}  `/so/:+ymMMMNMMMM` mMMMMMMMmh+::+o/`\n${c1}     `yNMMNho-yMMMM` NMMMm.+hNMMNh`\n${c1}     -MMMMd:  oMMMM. NMMMh  :hMMMM-\n${c1}      -yNMMMmooMMMM- NMMMyomMMMNy-\n${c1}        .omMMMMMMMM-`NMMMMMMMmo.\n${c1}          `:hMMMMMM. NMMMMMh/`\n${c1}             .odNm+  /dNms.",
    },
    "Zorin": {
        "colors": [4, 6],
        "logo": "${c1}       .osssssssssssssssssssssso.\n${c1}      .+oooooooooooooooooooooooo+.\n${c1}\n${c1}\n${c1}  `::::::::::::::::::::::.         .:`\n${c1} `+ssssssssssssssssss+:.`     `.:+ssso`\n${c1}.ossssssssssssssso/.       `-+ossssssso.\n${c1}ssssssssssssso/-`      `-/osssssssssssss\n${c1}.ossssssso/-`      .-/ossssssssssssssso.\n${c1} `+sss+:.      `.:+ssssssssssssssssss+`\n${c1}  `:.         .::::::::::::::::::::::`\n${c1}\n${c1}\n${c1}      .+oooooooooooooooooooooooo+.\n${c1}       -osssssssssssssssssssssso-\n${c1}        `osssssssssssssssssssso`",
    },
    "Darwin": {
        "colors": [2, 3, 1, 1, 5, 4],
        "logo": "${c1}                 ,xNMM.\n${c1}               .OMMMMo\n${c1}               OMMM0,\n${c1}     .;loddo:' loolloddol;.\n${c1}   cKMMMMMMMMMMNWMMMMMMMMMM0:\n${c1}${c2} .KMMMMMMMMMMMMMMMMMMMMMMMWd.\n${c1} XMMMMMMMMMMMMMMMMMMMMMMMX.\n${c1}${c3};MMMMMMMMMMMMMMMMMMMMMMMM:\n${c1}:MMMMMMMMMMMMMMMMMMMMMMMM:\n${c1}${c4}.MMMMMMMMMMMMMMMMMMMMMMMMX.\n${c1} kMMMMMMMMMMMMMMMMMMMMMMMMWd.\n${c1} ${c5}.XMMMMMMMMMMMMMMMMMMMMMMMMMMk\n${c1}  .XMMMMMMMMMMMMMMMMMMMMMMMMK.\n${c1}    ${c6}kMMMMMMMMMMMMMMMMMMMMMMd\n${c1}     ;KMMMMMMMWXXWMMMMMMMk.\n${c1}       .cooc,.    .,coo:.",
    },
    "SunOS": {
        "colors": [3, 7],
        "logo": "${c1}          `--    `+-    .:\n${c1}           .+:  `++:  -/+-     .\n${c1}    `.::`  -++/``:::`./+/  `.-/.\n${c1}      `++/-`.`          ` /++:`\n${c1}  ``   ./:`                .: `..`.-\n${c1}``./+/:-                     -+++:-\n${c1}    -/+`                      :.",
    },
    "Clear Linux OS | Clear_Linux": {
        "colors": [4, 3, 7, 6],
        "logo": "${c1}       BBBBBBBBB\n${c1}     BBBBBBBBBBBBBBB\n${c1}   BBBBBBBBBBBBBBBBBBBB\n${c1}   BBBBBBBBBBB         BBB\n${c1}  BBBBBBBB${c2}YYYYY\n${c1}${c1}  BBBBBBBB${c2}YYYYYY\n${c1}${c1}  BBBBBBBB${c2}YYYYYYY\n${c1}${c1}  BBBBBBBBB${c2}YYYYY${c3}W\n${c1}${c4} GG${c1}BBBBBBBY${c2}YYYY${c3}WWW\n${c1}${c4} GGG${c1}BBBBBBB${c2}YY${c3}WWWWWWWW\n${c1}${c4} GGGGGG${c1}BBBBBB${c3}WWWWWWWW\n${c1}${c4} GGGGGGGG${c1}BBBB${c3}WWWWWWWW\n${c1}${c4}GGGGGGGGGGG${c1}BBB${c3}WWWWWWW\n${c1}${c4}GGGGGGGGGGGGG${c1}B${c3}WWWWWW\n${c1}${c4}GGGGGGGG${c3}WWWWWWWWWWW\n${c1}${c4}GG${c3}WWWWWWWWWWWWWWWW\n${c1} WWWWWWWWWWWWWWWW\n${c1}      WWWWWWWWWW\n${c1}          WWW",
    },
    "Container Linux by CoreOS | Container_Linux": {
        "colors": [4, 7, 1],
        "logo": "${c1}          .';:cccccccc:;'.\n${c1}        ':ccccclc${c3}lllllllll${c1}cc:.\n${c1}     .;cccccccc${c3}lllllllllllllll${c1}c,\n${c1}    ;clllccccc${c3}llllllllllllllllll${c1}c,\n${c1}  .cllclccccc${c3}lllll${c2}lll${c3}llllllllllll${c1}c:\n${c1}  ccclclcccc${c3}cllll${c2}kWMMNKk${c3}llllllllll${c1}c:\n${c1} :ccclclcccc${c3}llll${c2}oWMMMMMMWO${c3}lllllllll${c1}c,\n${c1}.ccllllllccc${c3}clll${c2}OMMMMMMMMM0${c3}lllllllll${c1}c\n${c1}.lllllclcccc${c3}llll${c2}KMMMMMMMMMMo${c3}llllllll${c1}c.\n${c1}.lllllllcccc${c3}clll${c2}KMMMMMMMMN0${c3}lllllllll${c1}c.\n${c1}.cclllllcccc${c3}lllld${c2}xkkxxdo${c3}llllllllllc${c1}lc\n${c1} :cccllllllcccc${c3}lllccllllcclccc${c1}cccccc;\n${c1} .ccclllllllcccccccc${c3}lll${c1}ccccclccccccc\n${c1}  .cllllllllllclcccclccclccllllcllc\n${c1}    :cllllllllccclcllllllllllllcc;\n${c1}     .cccccccccccccclcccccccccc:.\n${c1}       .;cccclccccccllllllccc,.\n${c1}          .';ccccclllccc:;..\n${c1}                .....",
    },
    "crux_small|KISS": {
        "colors": [4, 5, 7, 6],
        "logo": "${c1}   (${c3}.· ${c1}|\n${c1}   (${c2}<> ${c1}|\n${c1}  / ${c3}__  ${c1}\\\\\n${c1} ( ${c3}/  \\\\ ${c1}/|\n${c1}${c2}_${c1}/\\\\ ${c3}__)${c1}/${c2}_${c1})\n${c1}${c2}\\/${c1}-____${c2}\\/",
    },
    "Fedora | RFRemix": {
        "colors": [4, 7, 1],
        "logo": "${c1}       :-------------------::\n${c1}     :-----------${c2}/shhOHbmp${c1}---:\\\\\n${c1}   /-----------${c2}omMMMNNNMMD  ${c1}---:\n${c1}  :-----------${c2}sMMMMNMNMP${c1}.    ---:\n${c1} :-----------${c2}:MMMdP${c1}-------    ---\\\\\n${c1},------------${c2}:MMMd${c1}--------    ---:\n${c1}:------------${c2}:MMMd${c1}-------    .---:\n${c1}:----    ${c2}oNMMMMMMMMMNho${c1}     .----:\n${c1}:--     .${c2}+shhhMMMmhhy++${c1}   .------/\n${c1}:-    -------${c2}:MMMd${c1}--------------:\n${c1}:-   --------${c2}/MMMd${c1}-------------;\n${c1}:-    ------${c2}/hMMMy${c1}------------:\n${c1}:--${c2} :dMNdhhdNMMNo${c1}------------;\n${c1}:---${c2}:sdNMMMMNds:${c1}------------:\n${c1}:------${c2}:://:${c1}-------------::\n${c1}:---------------------://",
    },
    "FreeBSD|HardenedBSD": {
        "colors": [4, 7, 3],
        "logo": "${c2}  ${c2}` `.....---...${c1}....--.```   -/\n${c2}  ${c2}+o   .--`         ${c1}/y:`      +.\n${c2}  ${c2} yo`:.            ${c1}:o      `+-\n${c2}    ${c2}y/               ${c1}-/`   -o/\n${c2}   ${c2}.-                  ${c1}::/sy+:.\n${c2}   ${c2}/                     ${c1}`--  /\n${c2}  ${c2}`:                          ${c1}:`\n${c2}  ${c2}`:                          ${c1}:`\n${c2}   ${c2}/                          ${c1}/\n${c2}   ${c2}.-                        ${c1}-.\n${c2}    ${c2}--                      ${c1}-.\n${c2}     ${c2}`:`                  ${c1}`:`\n${c2}       .--             `--.\n${c2}          .---.....----.",
    },
    "januslinux|janus|Ataraxia Linux|Ataraxia": {
        "colors": [4, 5, 6, 2],
        "logo": "${c1}        loooooo\n${c1}          loooo coooool\n${c1} looooooooooooooooooool\n${c1}  looooooooooooooooo\n${c1}         lool   cooo\n${c1}        coooooooloooooooo\n${c1}     clooooo  ;lood  cloooo\n${c1}  :loooocooo cloo      loooo\n${c1} loooo  :ooooool       loooo\n${c1}looo    cooooo        cooooo\n${c1}looooooooooooo      ;loooooo ${c2}looooooc\n${c1}${c1}looooooooo loo   cloooooool    ${c2}looooc\n${c1}${c1} cooo       cooooooooooo       ${c2}looolooooool\n${c1}${c1}            cooo:     ${c2}coooooooooooooooooool\n${c1}                       loooooooooooolc:   loooc;\n${c1}                             cooo:    loooooooooooc\n${c1}                            ;oool         looooooo:\n${c1}                           coool          olc,\n${c1}                          looooc   ,,\n${c1}                        coooooc    loc\n${c1}                       :oooool,    coool:, looool:,\n${c1}                       looool:      ooooooooooooooo:\n${c1}                       cooolc        .ooooooooooool",
    },
    "Linux Lite | Linux_Lite": {
        "colors": [3, 7],
        "logo": "${c1}      .l0MMMMMO\n${c1}   .kNMMMMMWMMMN,\n${c1}   KMMMMMMKMMMMMMo\n${c1}  'MMMMMMNKMMMMMM:\n${c1}  kMMMMMMOMMMMMMO\n${c1} .MMMMMMX0MMMMMW.\n${c1} oMMMMMMxWMMMMM:\n${c1} WMMMMMNkMMMMMO\n${c1}:MMMMMMOXMMMMW\n${c1}.0MMMMMxMMMMM;\n${c1}:;cKMMWxMMMMO\n${c1}'MMWMMXOMMMMl\n${c1} kMMMMKOMMMMMX:\n${c1} .WMMMMKOWMMM0c\n${c1}  lMMMMMWO0MNd:'\n${c1}   oollXMKXoxl;.\n${c1}     ':. .: .'\n${c1}              ..\n${c1}                .",
    },
    "mac | Darwin": {
        "colors": [2, 3, 1, 1, 5, 4],
        "logo": "${c1}                 ,xNMM.\n${c1}               .OMMMMo\n${c1}               OMMM0,\n${c1}     .;loddo:' loolloddol;.\n${c1}   cKMMMMMMMMMMNWMMMMMMMMMM0:\n${c1}${c2} .KMMMMMMMMMMMMMMMMMMMMMMMWd.\n${c1} XMMMMMMMMMMMMMMMMMMMMMMMX.\n${c1}${c3};MMMMMMMMMMMMMMMMMMMMMMMM:\n${c1}:MMMMMMMMMMMMMMMMMMMMMMMM:\n${c1}${c4}.MMMMMMMMMMMMMMMMMMMMMMMMX.\n${c1} kMMMMMMMMMMMMMMMMMMMMMMMMWd.\n${c1} ${c5}.XMMMMMMMMMMMMMMMMMMMMMMMMMMk\n${c1}  .XMMMMMMMMMMMMMMMMMMMMMMMMK.\n${c1}    ${c6}kMMMMMMMMMMMMMMMMMMMMMMd\n${c1}     ;KMMMMMMMWXXWMMMMMMMk.\n${c1}       .cooc,.    .,coo:.",
    },
    "Linux Mint Old | LinuxMintOld | mint_old": {
        "colors": [2, 7],
        "logo": "${c1}MMm----::-://////////////oymNMd+`\n${c1}MMd      ${c2}/++                ${c1}-sNMd:\n${c1}MMNso/`  ${c2}dMM    `.::-. .-::.` ${c1}.hMN:\n${c1}ddddMMh  ${c2}dMM   :hNMNMNhNMNMNh: ${c1}`NMm\n${c1}    NMm  ${c2}dMM  .NMN/-+MMM+-/NMN` ${c1}dMM\n${c1}    NMm  ${c2}dMM  -MMm  `MMM   dMM. ${c1}dMM\n${c1}    NMm  ${c2}dMM  -MMm  `MMM   dMM. ${c1}dMM\n${c1}    NMm  ${c2}dMM  .mmd  `mmm   yMM. ${c1}dMM\n${c1}    NMm  ${c2}dMM`  ..`   ...   ydm. ${c1}dMM\n${c1}    hMM- ${c2}+MMd/-------...-:sdds  ${c1}dMM\n${c1}    -NMm- ${c2}:hNMNNNmdddddddddy/`  ${c1}dMM\n${c1}     -dMNs-${c2}``-::::-------.``    ${c1}dMM\n${c1}      `/dMNmy+/:-------------:/yMMM\n${c1}         ./ydNMMMMMMMMMMMMMMMMMMMMM\n${c1}            .MMMMMMMMMMMMMMMMMMM",
    },
    "Linux Mint | LinuxMint | mint": {
        "colors": [2, 7],
        "logo": "${c2}${c2}          .-MMMMMMMMMMMMMMM-.\n${c2}      .-MMMM${c1}`..-:::::::-..`${c2}MMMM-.\n${c2}    .:MMMM${c1}.:MMMMMMMMMMMMMMM:.${c2}MMMM:.\n${c2}   -MMM${c1}-M---MMMMMMMMMMMMMMMMMMM.${c2}MMM-\n${c2} `:MMM${c1}:MM`  :MMMM:....::-...-MMMM:${c2}MMM:`\n${c2} :MMM${c1}:MMM`  :MM:`  ``    ``  `:MMM:${c2}MMM:\n${c2}.MMM${c1}.MMMM`  :MM.  -MM.  .MM-  `MMMM.${c2}MMM.\n${c2}:MMM${c1}:MMMM`  :MM.  -MM-  .MM:  `MMMM-${c2}MMM:\n${c2}:MMM${c1}:MMMM`  :MM.  -MM-  .MM:  `MMMM:${c2}MMM:\n${c2}:MMM${c1}:MMMM`  :MM.  -MM-  .MM:  `MMMM-${c2}MMM:\n${c2}.MMM${c1}.MMMM`  :MM:--:MM:--:MM:  `MMMM.${c2}MMM.\n${c2} :MMM${c1}:MMM-  `-MMMMMMMMMMMM-`  -MMM-${c2}MMM:\n${c2}  :MMM${c1}:MMM:`                `:MMM:${c2}MMM:\n${c2}   .MMM${c1}.MMMM:--------------:MMMM.${c2}MMM.\n${c2}     '-MMMM${c1}.-MMMMMMMMMMMMMMM-.${c2}MMMM-'\n${c2}       '.-MMMM${c1}``--:::::--``${c2}MMMM-.'\n${c2}${c2}            '-MMMMMMMMMMMMM-'\n${c2}${c2}               ``-:::::-``",
    },
    "Open Source Media Center | osmc": {
        "colors": [4, 7, 1],
        "logo": "${c1}        .+hMNho/:..``..:/ohNMh+.\n${c1}      :hMdo.                .odMh:\n${c1}    -dMy-                      -yMd-\n${c1}   sMd-                          -dMs\n${c1}  hMy       +.            .+       yMh\n${c1} yMy        dMs.        .sMd        yMy\n${c1}:Mm         dMNMs`    `sMNMd        `mM:\n${c1}yM+         dM//mNs``sNm//Md         +My\n${c1}mM-         dM:  +NNNN+  :Md         -Mm\n${c1}mM-         dM: `oNN+    :Md         -Mm\n${c1}yM+         dM/+NNo`     :Md         +My\n${c1}:Mm`        dMMNs`       :Md        `mM:\n${c1} yMy        dMs`         -ms        yMy\n${c1}  hMy       +.                     yMh\n${c1}   sMd-                          -dMs\n${c1}    -dMy-                      -yMd-\n${c1}      :hMdo.                .odMh:\n${c1}        .+hMNho/:..``..:/ohNMh+.\n${c1}            -+shdmNNNNmdhs+-",
    },
    "PCBSD | TrueOS": {
        "colors": [1, 7, 3],
        "logo": "${c1}                        s.\n${c1}                        +y\n${c1}                        yN\n${c1}                       -MN  `.\n${c1}                      :NMs `m\n${c1}                    .yMMm` `No\n${c1}            `-/+++sdMMMNs+-`+Ms\n${c1}        `:oo+-` .yMMMMy` `-+oNMh\n${c1}      -oo-     +NMMMM/       oMMh-\n${c1}    .s+` `    oMMMMM/     -  oMMMhy.\n${c1}   +s`- ::   :MMMMMd     -o `mMMMy`s+\n${c1}  y+  h .Ny+oNMMMMMN/    sh+NMMMMo  +y\n${c1} s+ .ds  -NMMMMMMMMMMNdhdNMMMMMMh`   +s\n${c1}-h .NM`   `hMMMMMMMMMMMMMMNMMNy:      h-\n${c1}y- hMN`     hMMmMMMMMMMMMNsdMNs.      -y\n${c1}m` mMMy`    oMMNoNMMMMMMo`  sMMMo     `m\n${c1}m` :NMMMdyydMMMMo+MdMMMs     sMMMd`   `m\n${c1}h-  `+ymMMMMMMMM--M+hMMN/    +MMMMy   -h\n${c1}:y     `.sMMMMM/ oMM+.yMMNddNMMMMMm   y:\n${c1} y:   `s  dMMN- .MMMM/ :MMMMMMMMMMh  :y\n${c1} `h:  `mdmMMM/  yMMMMs  sMMMMMMMMN- :h`\n${c1}   so  -NMMMN   /mmd+  `dMMMMMMMm- os\n${c1}    :y: `yMMM`       `+NMMMMMMNo`:y:\n${c1}      /s+`.omy      /NMMMMMNh/.+s:\n${c1}        .+oo:-.     /mdhs+::oo+.\n${c1}            -/o+++++++++++/-",
    },
    "popos_small | pop_os_small": {
        "colors": [6, 7],
        "logo": "${c1}\\\\   _ \\\\        __\n${c1} \\\\ \\\\ \\\\ \\\\      / /\n${c1}  \\\\ \\\\_\\\\ \\\\    / /\n${c1}   \\\\  ___\\\\  /_/\n${c1}    \\\\ \\\\    _\n${c1}   __\\\\_\\\\__(_)_\n${c1}  (___________)`",
    },
    "Pop!_OS | popos | pop_os": {
        "colors": [6, 7],
        "logo": "${c1}         /////////////////////\n${c1}      ///////${c2}*767${c1}////////////////\n${c1}    //////${c2}7676767676*${c1}//////////////\n${c1}   /////${c2}76767${c1}//${c2}7676767${c1}//////////////\n${c1}  /////${c2}767676${c1}///${c2}*76767${c1}///////////////\n${c1} ///////${c2}767676${c1}///${c2}76767${c1}.///${c2}7676*${c1}///////\n${c1}/////////${c2}767676${c1}//${c2}76767${c1}///${c2}767676${c1}////////\n${c1}//////////${c2}76767676767${c1}////${c2}76767${c1}/////////\n${c1}///////////${c2}76767676${c1}//////${c2}7676${c1}//////////\n${c1}////////////,${c2}7676${c1},///////${c2}767${c1}///////////\n${c1}/////////////*${c2}7676${c1}///////${c2}76${c1}////////////\n${c1}///////////////${c2}7676${c1}////////////////////\n${c1} ///////////////${c2}7676${c1}///${c2}767${c1}////////////\n${c1}  //////////////////////${c2}'${c1}////////////\n${c1}   //////${c2}.7676767676767676767,${c1}//////\n${c1}    /////${c2}767676767676767676767${c1}/////\n${c1}      ///////////////////////////\n${c1}         /////////////////////\n${c1}             /////////////",
    },
    "Puppy | Quirky Werewolf | Precise Puppy": {
        "colors": [4, 7],
        "logo": "${c1}  -ohmNNmh+/hMMMMMMMMNNNNd+dMMMMNM+\n${c1} yMMMMNNmmddo/NMMMNNNNNNNNNo+NNNNNy\n${c1}.NNNNNNmmmddds:MMNNNNNNNNNNNh:mNNN/\n${c1}-NNNdyyyhdmmmd`dNNNNNmmmmNNmdd/os/\n${c1}.Nm+shddyooo+/smNNNNmmmmNh.   :mmd.\n${c1} NNNNy:`   ./hmmmmmmmNNNN:     hNMh\n${c1} NMN-    -++- +NNNNNNNNNNm+..-sMMMM-\n${c1}.MMo    oNNNNo hNNNNNNNNmhdNNNMMMMM+\n${c1}.MMs    /NNNN/ dNmhs+:-`  yMMMMMMMM+\n${c1} mMM+     .. `sNN+.      hMMMMhhMMM-\n${c1} +MMMmo:...:sNMMMMMms:` hMMMMm.hMMy\n${c1}  yMMMMMMMMMMMNdMMMMMM::/+o+//dMMd`\n${c1}   sMMMMMMMMMMN+:oyyo:sMMMNNMMMNy`\n${c1}    :mMMMMMMMMMMMmddNMMMMMMMMmh/\n${c1}      /dMMMMMMMMMMMMMMMMMMNdy/`\n${c1}        .+hNMMMMMMMMMNmdhs/.\n${c1}            .:/+ooo+/:-.",
    },
    "Reborn OS | Reborn": {
        "colors": [2, 2, 8],
        "logo": "${c3}        mMMMMMMMMM  MMMMMMMMMm\n${c3}       NM                    MN\n${c3}      MM  ${c1}dddddddd  dddddddd  ${c3}MN\n${c3}     mM  ${c1}dd                dd  ${c3}MM\n${c3}        ${c1}dd  hhhhhh   hhhhh  dd\n${c3}   ${c3}mM      ${c1}hh            hh      ${c3}Mm\n${c3}  NM  ${c1}hd       ${c3}mMMMMMMd       ${c1}dh  ${c3}MN\n${c3} NM  ${c1}dd  hh   ${c3}mMMMMMMMMm   ${c1}hh  dd  ${c3}MN\n${c3}NM  ${c1}dd  hh   ${c3}mMMMMMMMMMMm   ${c1}hh  dd  ${c3}MN\n${c3} NM  ${c1}dd  hh   ${c3}mMMMMMMMMm   ${c1}hh  dd  ${c3}MN\n${c3}  NM  ${c1}hd       ${c3}mMMMMMMm       ${c1}dh  ${c3}MN\n${c3}   mM      ${c1}hh            hh      ${c3}Mm\n${c3}        ${c1}dd  hhhhhh  hhhhhh  dd\n${c3}     ${c3}MM  ${c1}dd                dd  ${c3}MM\n${c3}      MM  ${c1}dddddddd  dddddddd  ${c3}MN\n${c3}       NM                    MN\n${c3}        mMMMMMMMMM  MMMMMMMMMm",
    },
    "Red Star | Redstar": {
        "colors": [1, 7, 3],
        "logo": "${c1}                  .oK0l\n${c1}                 :0KKKKd.\n${c1}               .xKO0KKKKd\n${c1}              ,Od' .d0000l\n${c1}             .c;.   .'''...           ..'.\n${c1}.,:cloddxxxkkkkOOOOkkkkkkkkxxxxxxxxxkkkx:\n${c1};kOOOOOOOkxOkc'...',;;;;,,,'',;;:cllc:,.\n${c1} .okkkkd,.lko  .......',;:cllc:;,,'''''.\n${c1}   .cdo. :xd' cd:.  ..';'',,,'',,;;;,'.\n${c1}      . .ddl.;doooc'..;oc;'..';::;,'.\n${c1}        coo;.oooolllllllcccc:'.  .\n${c1}       .ool''lllllccccccc:::::;.\n${c1}       ;lll. .':cccc:::::::;;;;'\n${c1}       :lcc:'',..';::::;;;;;;;,,.\n${c1}       :cccc::::;...';;;;;,,,,,,.\n${c1}       ,::::::;;;,'.  ..',,,,'''.\n${c1}        ........          ......",
    },
    "redhat_old | rhel_old": {
        "colors": [1, 7, 3],
        "logo": "${c1}            `////////::.`-/.\n${c1}            -: ....-////////.\n${c1}            //:-::///////////`\n${c1}     `--::: `-://////////////:\n${c1}     //////-    ``.-:///////// .`\n${c1}     `://////:-.`    :///////::///:`\n${c1}       .-/////////:---/////////////:\n${c1}          .-://////////////////////.\n${c1}${c2}         yMN+`.-${c1}::///////////////-`\n${c1}${c2}      .-`:NMMNMs`  `..-------..`\n${c1}       MN+/mMMMMMhoooyysshsss\n${c1}MMM    MMMMMMMMMMMMMMyyddMMM+\n${c1} MMMM   MMMMMMMMMMMMMNdyNMMh`     hyhMMM\n${c1}  MMMMMMMMMMMMMMMMyoNNNMMM+.   MMMMMMMM\n${c1}   MMNMMMNNMMMMMNM+ mhsMNyyyyMNMMMMsMM",
    },
    "Redhat | Red Hat | rhel": {
        "colors": [1],
        "logo": "${c1}          MMMMMMMMMMMMMMMMMM\n${c1}          MMMMMMMMMMMMMMMMMMMM.\n${c1}         MMMMMMMMMMMMMMMMMMMMMM\n${c1}        ,MMMMMMMMMMMMMMMMMMMMMM:\n${c1}        MMMMMMMMMMMMMMMMMMMMMMMM\n${c1}  .MMMM'  MMMMMMMMMMMMMMMMMMMMMM\n${c1} MMMMMM    `MMMMMMMMMMMMMMMMMMMM.\n${c1}MMMMMMMM      MMMMMMMMMMMMMMMMMM .\n${c1}MMMMMMMMM.       `MMMMMMMMMMMMM' MM.\n${c1}MMMMMMMMMMM.                     MMMM\n${c1}`MMMMMMMMMMMMM.                 ,MMMMM.\n${c1} `MMMMMMMMMMMMMMMMM.          ,MMMMMMMM.\n${c1}    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n${c1}      MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM:\n${c1}         MMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n${c1}            `MMMMMMMMMMMMMMMMMMMMMMMM:\n${c1}                ``MMMMMMMMMMMMMMMMM'",
    },
    "Refracted Devuan | Refracted_Devuan": {
        "colors": [8, 7],
        "logo": '${c2}                            VW\n${c2}                           VVW\\\\\n${c2}                         .yWWW\\\\\n${c2} ,;,,u,;yy;;v;uyyyyyyy  ,WWWWW^\n${c2}    *WWWWWWWWWWWWWWWW/  $VWWWWw      ,\n${c2}        ^*%WWWWWWVWWX  $WWWW**    ,yy\n${c2}        ,    "**WWW/\' **\'   ,yy/WWW*`\n${c2}       &WWWWwy    `*`  <,ywWW%VWWW*\n${c2}     yWWWWWWWWWW*    .,   "**WW%W\n${c2}   ,&WWWWWM*"`  ,y/  &WWWww   ^*\n${c2}  XWWX*^   ,yWWWW09 .WWWWWWWWwy,\n${c2} *`        &WWWWWM  WWWWWWWWWWWWWww,\n${c2}           (WWWWW` /#####WWW***********\n${c2}           ^WWWW\n${c2}            VWW\n${c2}            Wh.\n${c2}            V/',
    },
    "Source Mage | Source_Mage": {
        "colors": [4, 7, 1],
        "logo": "${c2}.+sdmNMMMMMMMMMMy`\n${c2}.-::/yMMMMMMMMMMMm-\n${c2}      sMMMMMMMMMMMm/\n${c2}     /NMMMMMMMMMMMMMm:\n${c2}    .MMMMMMMMMMMMMMMMM:\n${c2}    `MMMMMMMMMMMMMMMMMN.\n${c2}     NMMMMMMMMMMMMMMMMMd\n${c2}     mMMMMMMMMMMMMMMMMMMo\n${c2}     hhMMMMMMMMMMMMMMMMMM.\n${c2}     .`/MMMMMMMMMMMMMMMMMs\n${c2}        :mMMMMMMMMMMMMMMMN`\n${c2}         `sMMMMMMMMMMMMMMM+\n${c2}           /NMMMMMMMMMMMMMN`\n${c2}             oMMMMMMMMMMMMM+\n${c2}          ./sd.-hMMMMMMMMmmN`\n${c2}      ./+oyyyh- `MMMMMMMMMmNh\n${c2}                 sMMMMMMMMMmmo\n${c2}                 `NMMMMMMMMMd:\n${c2}                  -dMMMMMMMMMo\n${c2}                    -shmNMMms.",
    },
    "sunos_small | solaris_small": {
        "colors": [3, 7],
        "logo": "${c1}   .   :;  ::  ;:   .\n${c1}   .;. ..      .. .;.\n${c1}..  ..             ..  ..\n${c1} .;,                 ,;.",
    },
    "SunOS | Solaris": {
        "colors": [3, 7],
        "logo": "${c1}          `--    `+-    .:\n${c1}           .+:  `++:  -/+-     .\n${c1}    `.::`  -++/``:::`./+/  `.-/.\n${c1}      `++/-`.`          ` /++:`\n${c1}  ``   ./:`                .: `..`.-\n${c1}``./+/:-                     -+++:-\n${c1}    -/+`                      :.",
    },
    "openSUSE Leap | openSUSE_Leap": {
        "colors": [2, 7],
        "logo": "${c2}               ./oooooo/-\n${c2}            `:oooooooooooo:.\n${c2}          -+oooooooooooooooo+-`\n${c2}       ./oooooooooooooooooooooo/-\n${c2}      :oooooooooooooooooooooooooo:\n${c2}    `  `-+oooooooooooooooooooo/-   `\n${c2} `:oo/-   .:ooooooooooooooo+:`  `-+oo/.\n${c2}`/oooooo:.   -/oooooooooo/.   ./oooooo/.\n${c2}  `:+ooooo+-`  `:+oooo+-   `:oooooo+:`\n${c2}     .:oooooo/.   .::`   -+oooooo/.\n${c2}        -/oooooo:.    ./oooooo+-\n${c2}          `:+ooooo+-:+oooooo:`\n${c2}             ./oooooooooo/.\n${c2}                -/oooo+:`\n${c2}                  `:/.",
    },
    "openSUSE Tumbleweed | openSUSE_Tumbleweed": {
        "colors": [2, 7],
        "logo": "${c2}     .,cdxxxoc,.               .:kKMMMNWMMMNk:.\n${c2}    cKMMN0OOOKWMMXo. ;        ;0MWk:.      .:OMMk.\n${c2}  ;WMK;.       .lKMMNM,     :NMK,             .OMW;\n${c2} cMW;            'WMMMN   ,XMK,                 oMM'\n${c2}.MMc               ..;l. xMN:                    KM0\n${c2}'MM.                   'NMO                      oMM\n${c2}.MM,                 .kMMl                       xMN\n${c2} KM0               .kMM0. .dl:,..               .WMd\n${c2} .XM0.           ,OMMK,    OMMMK.              .XMK\n${c2}   oWMO:.    .;xNMMk,       NNNMKl.          .xWMx\n${c2}     :ONMMNXMMMKx;          .  ,xNMWKkxllox0NMWk,\n${c2}         .....                    .:dOOXXKOxl,",
    },
    "opensuse_small | suse_small": {
        "colors": [2, 7],
        "logo": "${c1}__|   __ \\\\\n${c1}     / .\\\\ \\\\\n${c1}     \\\\__/ |\n${c1}   _______|\n${c1}   \\\\_______\n${c1}__________/",
    },
    "openSUSE | open SUSE | SUSE": {
        "colors": [2, 7],
        "logo": "${c2}       .;d00xl:^''''''^:ok00d;.\n${c2}     .d00l'                'o00d.\n${c2}   .d0Kd'${c1}  Okxol:;,.          ${c2}:O0d.\n${c2}  .OK${c1}KKK0kOKKKKKKKKKKOxo:,      ${c2}lKO.\n${c2} ,0K${c1}KKKKKKKKKKKKKKK0P^${c2},,,${c1}^dx:${c2}    ;00,\n${c2}.OK${c1}KKKKKKKKKKKKKKKk'${c2}.oOPPb.${c1}'0k.${c2}   cKO.\n${c2}:KK${c1}KKKKKKKKKKKKKKK: ${c2}kKx..dd ${c1}lKd${c2}   'OK:\n${c2}dKK${c1}KKKKKKKKKOx0KKKd ${c2}^0KKKO' ${c1}kKKc${c2}   dKd\n${c2}dKK${c1}KKKKKKKKKK;.;oOKx,..${c2}^${c1}..;kKKK0.${c2}  dKd\n${c2}:KK${c1}KKKKKKKKKK0o;...^cdxxOK0O/^^'  ${c2}.0K:\n${c2} kKK${c1}KKKKKKKKKKKKK0x;,,......,;od  ${c2}lKk\n${c2} '0K${c1}KKKKKKKKKKKKKKKKKKKK00KKOo^  ${c2}c00'\n${c2}  'kK${c1}KKOxddxkOO00000Okxoc;''   ${c2}.dKk'\n${c2}    l0Ko.                    .c00l'\n${c2}     'l0Kk:.              .;xK0l'\n${c2}        'lkK0xl:;,,,,;:ldO0kl'\n${c2}            '^:ldxkkkkxdl:^'",
    },
    "Ubuntu Cinnamon | Ubuntu-Cinnamon": {
        "colors": [1],
        "logo": "${c1}        `:/oooooooooooooooooo/-`\n${c1}      -/oooooooooooooooooooo+ooo/-\n${c1}    .+oooooooooooooooooo+/-`.ooooo+.\n${c1}   :oooooooooooo+//:://++:. .ooooooo:\n${c1}  /oooooooooo+o:`.----.``./+/oooooooo/\n${c1} /ooooooooo+. +ooooooooo+:``/ooooooooo/\n${c1}.ooooooooo: .+ooooooooooooo- -ooooooooo.\n${c1}/oooooo/o+ .ooooooo:`+oo+ooo- :oooooooo/\n${c1}ooo+:. .o: :ooooo:` .+/. ./o+:/ooooooooo\n${c1}oooo/-`.o: :ooo/` `/+.     ./.:ooooooooo\n${c1}/oooooo+o+``++. `:+-          /oooooooo/\n${c1}.ooooooooo/``  -+:`          :ooooooooo.\n${c1} /ooooooooo+--+/`          .+ooooooooo/\n${c1}  /ooooooooooo+.`      `.:++:oooooooo/\n${c1}   :oooooooooooooo++++oo+-` .ooooooo:\n${c1}    .+ooooooooooooooooooo+:..ooooo+.\n${c1}      -/oooooooooooooooooooooooo/-\n${c1}        `-/oooooooooooooooooo/:`\n${c1}            .-:/++oooo++/:-.",
    },
    "Ubuntu Budgie | Ubuntu-Budgie": {
        "colors": [4, 7, 1],
        "logo": "${c2}        :smMMMMMMMMMMMhs+:++yhs:\n${c2}     `omMMMMMMMMMMMN+`        `odo`\n${c2}    /NMMMMMMMMMMMMN-            `sN/\n${c2}  `hMMMMmhhmMMMMMMh               sMh`\n${c2} .mMmo-     /yMMMMm`              `MMm.\n${c2} mN/       yMMMMMMMd-              MMMm\n${c2}oN-        oMMMMMMMMMms+//+o+:    :MMMMo\n${c2}m/          +NMMMMMMMMMMMMMMMMm. :NMMMMm\n${c2}M`           .NMMMMMMMMMMMMMMMNodMMMMMMM\n${c2}M-            sMMMMMMMMMMMMMMMMMMMMMMMMM\n${c2}mm`           mMMMMMMMMMNdhhdNMMMMMMMMMm\n${c2}oMm/        .dMMMMMMMMh:      :dMMMMMMMo\n${c2} mMMNyo/:/sdMMMMMMMMM+          sMMMMMm\n${c2} .mMMMMMMMMMMMMMMMMMs           `NMMMm.\n${c2}  `hMMMMMMMMMMM.oo+.            `MMMh`\n${c2}    /NMMMMMMMMMo                sMN/\n${c2}     `omMMMMMMMMy.            :dmo`\n${c2}        :smMMMMMMMh+-`   `.:ohs:\n${c2}           ./oydmMMMMMMdhyo/.",
    },
    "Ubuntu MATE | Ubuntu-MATE": {
        "colors": [2, 7],
        "logo": "${c1}        .odMMMMMMMMMMMMMMMMMMdo.\n${c1}      /dMMMMMMMMMMMMMMMmMMMMMMMMd/\n${c1}    :mMMMMMMMMMMMMNNNNM/`/yNMMMMMMm:\n${c1}  `yMMMMMMMMMms:..-::oM:    -omMMMMMy`\n${c1} `dMMMMMMMMy-.odNMMMMMM:    -odMMMMMMd`\n${c1} hMMMMMMMm-.hMMy/....+M:`/yNm+mMMMMMMMh\n${c1}/MMMMNmMN-:NMy`-yNMMMMMmNyyMN:`dMMMMMMM/\n${c1}hMMMMm -odMMh`sMMMMMMMMMMs sMN..MMMMMMMh\n${c1}NMMMMm    `/yNMMMMMMMMMMMM: MM+ mMMMMMMN\n${c1}NMMMMm    `/yNMMMMMMMMMMMM: MM+ mMMMMMMN\n${c1}hMMMMm -odMMh sMMMMMMMMMMs oMN..MMMMMMMh\n${c1}/MMMMNNMN-:NMy`-yNMMMMMNNsyMN:`dMMMMMMM/\n${c1} hMMMMMMMm-.hMMy/....+M:.+hNd+mMMMMMMMh\n${c1} `dMMMMMMMMy-.odNMMMMMM:    :smMMMMMMd`\n${c1}   yMMMMMMMMMms/..-::oM:    .+dMMMMMy\n${c1}    :mMMMMMMMMMMMMNNNNM: :smMMMMMMm:\n${c1}      /dMMMMMMMMMMMMMMMdNMMMMMMMd/\n${c1}        .odMMMMMMMMMMMMMMMMMMdo.\n${c1}           `:+shmNNMMNNmhs+:`",
    },
    "Ubuntu Studio | Ubuntu-Studio": {
        "colors": [6, 7],
        "logo": "${c1}         `.:+++++++++++${c2}ooo${c1}++:.`\n${c1}       ./+++++++++++++${c2}sMMMNdyo${c1}+/.\n${c1}     .++++++++++++++++${c2}oyhmMMMMms${c1}++.\n${c1}   `/+++++++++${c2}osyhddddhys${c1}+${c2}osdMMMh${c1}++/`\n${c1}  `+++++++++${c2}ydMMMMNNNMMMMNds${c1}+${c2}oyyo${c1}++++`\n${c1}  +++++++++${c2}dMMNhso${c1}++++${c2}oydNMMmo${c1}++++++++`\n${c1} :+${c2}odmy${c1}+++${c2}ooysoohmNMMNmyoohMMNs${c1}+++++++:\n${c1} ++${c2}dMMm${c1}+${c2}oNMd${c1}++${c2}yMMMmhhmMMNs+yMMNo${c1}+++++++\n${c1}`++${c2}NMMy${c1}+${c2}hMMd${c1}+${c2}oMMMs${c1}++++${c2}sMMN${c1}++${c2}NMMs${c1}+++++++.\n${c1}`++${c2}NMMy${c1}+${c2}hMMd${c1}+${c2}oMMMo${c1}++++${c2}sMMN${c1}++${c2}mMMs${c1}+++++++.\n${c1} ++${c2}dMMd${c1}+${c2}oNMm${c1}++${c2}yMMNdhhdMMMs${c1}+y${c2}MMNo${c1}+++++++\n${c1} :+${c2}odmy${c1}++${c2}oo${c1}+${c2}ss${c1}+${c2}ohNMMMMmho${c1}+${c2}yMMMs${c1}+++++++:\n${c1}  +++++++++${c2}hMMmhs+ooo+oshNMMms${c1}++++++++\n${c1}  `++++++++${c2}oymMMMMNmmNMMMMmy+oys${c1}+++++`\n${c1}   `/+++++++++${c2}oyhdmmmmdhso+sdMMMs${c1}++/\n${c1}     ./+++++++++++++++${c2}oyhdNMMMms${c1}++.\n${c1}       ./+++++++++++++${c2}hMMMNdyo${c1}+/.\n${c1}         `.:+++++++++++${c2}sso${c1}++:.\n${c1}              ..-::::::-..",
    },
    "Ubuntu | i3buntu": {
        "colors": [1, 7, 3],
        "logo": "${c1}        `:+ssssssssssssssssss+:`\n${c1}      -+ssssssssssssssssssyyssss+-\n${c1}    .ossssssssssssssssss${c2}dMMMNy${c1}sssso.\n${c1}   /sssssssssss${c2}hdmmNNmmyNMMMMh${c1}ssssss/\n${c1}  +sssssssss${c2}hm${c1}yd${c2}MMMMMMMNddddy${c1}ssssssss+\n${c1} /ssssssss${c2}hNMMM${c1}yh${c2}hyyyyhmNMMMNh${c1}ssssssss/\n${c1}.ssssssss${c2}dMMMNh${c1}ssssssssss${c2}hNMMMd${c1}ssssssss.\n${c1}+ssss${c2}hhhyNMMNy${c1}ssssssssssss${c2}yNMMMy${c1}sssssss+\n${c1}oss${c2}yNMMMNyMMh${c1}ssssssssssssss${c2}hmmmh${c1}ssssssso\n${c1}oss${c2}yNMMMNyMMh${c1}sssssssssssssshmmmh${c1}ssssssso\n${c1}+ssss${c2}hhhyNMMNy${c1}ssssssssssss${c2}yNMMMy${c1}sssssss+\n${c1}.ssssssss${c2}dMMMNh${c1}ssssssssss${c2}hNMMMd${c1}ssssssss.\n${c1} /ssssssss${c2}hNMMM${c1}yh${c2}hyyyyhdNMMMNh${c1}ssssssss/\n${c1}  +sssssssss${c2}dm${c1}yd${c2}MMMMMMMMddddy${c1}ssssssss+\n${c1}   /sssssssssss${c2}hdmNNNNmyNMMMMh${c1}ssssss/\n${c1}    .ossssssssssssssssss${c2}dMMMNy${c1}sssso.\n${c1}      -+sssssssssssssssss${c2}yyy${c1}ssss+-\n${c1}        `:+ssssssssssssssssss+:`\n${c1}            .-/+oossssoo+/-.",
    },
    "[Windows 10]|on Windows 10|Windows 8| Windows 10 |windows10|windows8": {
        "colors": [6, 7],
        "logo": "${c1}                    ....,,:;+ccllll\n${c1}      ...,,+:;  cllllllllllllllllll\n${c1},cclllllllllll  lllllllllllllllllll\n${c1}llllllllllllll  lllllllllllllllllll\n${c1}llllllllllllll  lllllllllllllllllll\n${c1}llllllllllllll  lllllllllllllllllll\n${c1}llllllllllllll  lllllllllllllllllll\n${c1}llllllllllllll  lllllllllllllllllll\n${c1}\n${c1}llllllllllllll  lllllllllllllllllll\n${c1}llllllllllllll  lllllllllllllllllll\n${c1}llllllllllllll  lllllllllllllllllll\n${c1}llllllllllllll  lllllllllllllllllll\n${c1}llllllllllllll  lllllllllllllllllll\n${c1}`'ccllllllllll  lllllllllllllllllll\n${c1}       `' \\\\*::  :ccllllllllllllllll\n${c1}                       ````''*::cll\n${c1}                                 ``",
    },
    "Profelis SambaBOX | SambaBOX": {
        "colors": [3, 6],
        "logo": "${c1}                    #\n${c1}               *////#####\n${c1}           /////////#########(\n${c1}      .((((((/////    ,####(#(((((\n${c1}  /#######(((*             (#(((((((((.\n${c1}//((#(#(#,        ((##(        ,((((((//\n${c1}//////        #(##########(       //////\n${c1}//////    ((#(#(#(#(##########(/////////\n${c1}/////(    (((((((#########(##((((((/////\n${c1}/(((#(                             ((((/\n${c1}####(#                             ((###\n${c1}#########(((/////////(((((((((,    (#(#(\n${c1}########(   /////////(((((((*      #####\n${c1}####///,        *////(((         (((((((\n${c1}.///////////                .//(((((((((\n${c1}     ///////////,       *(/////((((*\n${c1}         ,/(((((((((##########/.\n${c1}             .((((((#######\n${c1}                  ((##*",
    },
}


def get_logo(distro_name: str, nocolor: bool = False) -> List[str]:
    """
    Distro ismini ver, renkli ASCII art listesi al

    Args:
        distro_name: Distro adı (örn: "Arch", "Alpine", "Debian")

    Returns:
        List[str]: Renkli ASCII art satırlarının listesi
    """

    # Distro verisini bul
    distro_data = data.get(distro_name)
    if not distro_data:
        # Büyük/küçük harf duyarsız arama
        for name, data_item in data.items():
            if "|" in name:
                # Çoklu isimler için ayır
                for sub_name in name.split("|"):
                    if sub_name.strip().lower() == distro_name.lower():
                        distro_data = data_item
                        break
            if name.lower() == distro_name.lower():
                distro_data = data_item
                break

    if not distro_data:
        return [f"❌ '{distro_name}' distrosu bulunamadı"]

    # Orijinal neofetch color komutu (tam kopya)
    def color(color_code):
        """Orijinal neofetch color komutunu tam olarak taklit eder"""
        reset = "\033[0m"

        # Orijinal neofetch color() fonksiyonu
        if color_code in ["0", "1", "2", "3", "4", "5", "6"]:
            return f"{reset}\033[3{color_code}m"
        elif color_code in ["7", "fg"]:
            return f"\033[37m{reset}"
        else:
            # 256 renk desteği
            return f"\033[38;5;{color_code}m"

    # ASCII bold kodu
    ascii_bold = "\033[1m"

    # ASCII art'ı renkli olarak render et
    rendered = distro_data["logo"]
    colors = distro_data["colors"]

    # Orijinal neofetch set_colors sistemi gibi renkleri ayarla
    c1 = (
        color(colors[0] if len(colors) > 0 else "7") + ascii_bold if not nocolor else ""
    )
    c2 = (
        color(colors[1] if len(colors) > 1 else "7") + ascii_bold if not nocolor else ""
    )
    c3 = (
        color(colors[2] if len(colors) > 2 else "7") + ascii_bold if not nocolor else ""
    )
    c4 = (
        color(colors[3] if len(colors) > 3 else "7") + ascii_bold if not nocolor else ""
    )
    c5 = (
        color(colors[4] if len(colors) > 4 else "7") + ascii_bold if not nocolor else ""
    )
    c6 = (
        color(colors[5] if len(colors) > 5 else "7") + ascii_bold if not nocolor else ""
    )

    # Renk kodlarını değiştir (orijinal neofetch sistemi gibi)
    rendered = (
        rendered.replace("${c1}", c1)
        .replace("${c2}", c2)
        .replace("${c3}", c3)
        .replace("${c4}", c4)
        .replace("${c5}", c5)
        .replace("${c6}", c6)
    )

    # Reset kodu ekle
    rendered += "\033[0m"

    # Satırlara böl ve liste olarak döndür
    return rendered.split("\n")


def get_available_distros() -> List[str]:
    """Mevcut tüm distro isimlerini döndürür"""
    return sorted(list(data.keys()))


# Test
if __name__ == "__main__":
    import sys

    print("🐧 Distro Logo Getter - Test")
    print("=" * 40)

    args = sys.argv[1:]
    if args:
        for distro in args:
            print(f"\n🔍 {distro} logosu:")
            print("-" * 30)
            logo_lines = get_logo(distro)
            for line in logo_lines:
                print(line)
