"""BasicFetch Package

Copyright (C) 2025 Yakup Kaya (@y4kupkaya)
Licensed under GNU General Public License v3.0
"""

from .basicfetch import main

__version__ = "1.0.0"
__author__ = "Yakup Kaya"
__email__ = "contact@yakupkaya.me"
__license__ = "GPL-3.0"
