# Quick Start Guide

Get up and running with Burt Logger in 5 minutes!

## Installation

```bash
pip install burt-logger
```

## Minimal Example

```python
from burt_logger import LLMLogger

# 1. Initialize (takes 2 lines)
logger = LLMLogger(
    endpoint="https://your-backend.com/logs",
    api_key="your-api-key"
)

# 2. Log your LLM calls (1 line after each LLM call)
logger.log(
    request={"model": "gpt-4", "prompt": "Hello!"},
    response={"completion": "Hi there!", "tokens": 10}
)

# 3. Shutdown gracefully (1 line at the end)
logger.shutdown()
```

That's it! 3 lines of code and you're collecting training data.

## With OpenAI

```python
from openai import OpenAI
from burt_logger import LLMLogger

client = OpenAI(api_key="your-openai-key")
logger = LLMLogger(endpoint="...", api_key="...")

# Make your normal OpenAI call
response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "user", "content": "What is 2+2?"}]
)

# Just add this one line to log it
logger.log(
    request={"model": "gpt-3.5-turbo", "messages": [...]},
    response={"completion": response.choices[0].message.content}
)

logger.shutdown()
```

## Best Practices

### Use Context Manager (Auto-cleanup)

```python
with LLMLogger(endpoint="...", api_key="...") as logger:
    # Your code
    logger.log(...)
    # Automatic cleanup on exit
```

### Add Metadata for Better Analysis

```python
logger.log(
    request={...},
    response={...},
    metadata={
        "user_id": "user_123",
        "session_id": "session_abc",
        "environment": "production",
        "feature": "chatbot"
    }
)
```

### Configure for Your Use Case

```python
# High-volume app? Increase batch size
logger = LLMLogger(
    ...,
    batch_size=50,          # Send in larger batches
    flush_interval=10.0,    # Wait longer before flushing
)

# Slow network? Increase retries
logger = LLMLogger(
    ...,
    max_retries=5,
    max_retry_delay=120.0,
)

# Debug issues? Enable logging
logger = LLMLogger(..., debug=True)
```

## Testing Locally

Want to test without a real backend? Use a local mock server:

```python
# test_local.py
from burt_logger import LLMLogger
import time

logger = LLMLogger(
    endpoint="http://localhost:8000/logs",  # Local server
    api_key="test-key",
    debug=True  # See what's happening
)

# Log some test data
for i in range(5):
    logger.log(
        request={"test": i},
        response={"result": i * 2}
    )
    time.sleep(0.5)

logger.shutdown()
```

Run a simple local server to see the requests:

```python
# server.py
from http.server import BaseHTTPRequestHandler, HTTPServer
import json

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        body = self.rfile.read(content_length)
        data = json.loads(body)

        print(f"\nReceived {len(data['logs'])} logs:")
        print(json.dumps(data, indent=2))

        self.send_response(200)
        self.end_headers()

HTTPServer(('', 8000), Handler).serve_forever()
```

## Common Issues

### "Queue is full" warnings

Your app is logging faster than the backend can handle. Solutions:

-  Increase `max_queue_size`
-  Increase `batch_size` to send more logs at once
-  Check if your backend is slow

### Logs not being sent

-  Check `debug=True` to see what's happening
-  Verify your `endpoint` is correct
-  Check `get_stats()` for failed logs
-  Make sure you call `shutdown()` at the end

### Import errors

```bash
# Make sure requests is installed
pip install requests

# Or install with all dependencies
pip install burt-logger
```

## Next Steps

-  Read the full [README.md](README.md) for detailed docs
-  Check out [examples/](examples/) for complete examples
-  Run the test suite: `pytest tests/`

## Support

-  Email: bobby@trainburt.com

---

Happy logging! 🚀
