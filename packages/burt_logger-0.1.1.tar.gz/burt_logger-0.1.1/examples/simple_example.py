"""
Simple example of using burt-logger without external LLM providers.

This example demonstrates the basic usage pattern and features
without requiring OpenAI or Anthropic API keys.
"""

import time
from burt_logger import LLMLogger


def simulate_llm_call(model: str, prompt: str):
    """
    Simulate an LLM API call for demonstration purposes.
    
    In a real application, this would be replaced with actual
    calls to OpenAI, Anthropic, or other LLM providers.
    """
    # Simulate some processing time
    time.sleep(0.1)
    
    return {
        "id": f"sim_{int(time.time() * 1000)}",
        "model": model,
        "completion": f"This is a simulated response to: {prompt}",
        "tokens": {
            "prompt": len(prompt.split()),
            "completion": 10,
            "total": len(prompt.split()) + 10,
        },
    }


def main():
    print("=== Burt Logger Simple Example ===\n")
    
    # Initialize logger
    logger = LLMLogger(
        endpoint="https://api.example.com/logs",
        api_key="sk-demo-key",
        batch_size=3,  # Small batch size for demonstration
        flush_interval=2.0,  # Flush every 2 seconds
        debug=True,  # See what's happening under the hood
    )
    
    print("Logger initialized. Sending sample logs...\n")
    
    # Example 1: Basic logging
    print("Example 1: Basic logging")
    request = {
        "model": "gpt-3.5-turbo",
        "prompt": "What is machine learning?",
        "temperature": 0.7,
    }
    response = simulate_llm_call(request["model"], request["prompt"])
    
    success = logger.log(request=request, response=response)
    print(f"Log queued: {success}\n")
    
    # Example 2: Logging with metadata
    print("Example 2: Logging with metadata")
    request = {
        "model": "gpt-4",
        "prompt": "Explain neural networks",
        "max_tokens": 500,
    }
    response = simulate_llm_call(request["model"], request["prompt"])
    
    logger.log(
        request=request,
        response=response,
        metadata={
            "user_id": "user_123",
            "session_id": "session_abc",
            "feature": "chatbot",
            "environment": "production",
        },
    )
    print("Log with metadata queued\n")
    
    # Example 3: Multiple logs to trigger batching
    print("Example 3: Multiple logs (will trigger batching)")
    for i in range(5):
        request = {
            "model": "claude-3-sonnet",
            "prompt": f"Question number {i + 1}",
        }
        response = simulate_llm_call(request["model"], request["prompt"])
        logger.log(request=request, response=response)
        print(f"  Queued log {i + 1}/5")
    
    print()
    
    # Example 4: Manual flush
    print("Example 4: Manual flush")
    logger.log(
        request={"model": "test", "prompt": "Final test"},
        response=simulate_llm_call("test", "Final test"),
    )
    print("Flushing queue manually...")
    logger.flush(timeout=5.0)
    print("Flush complete\n")
    
    # Show statistics
    print("Logger Statistics:")
    stats = logger.get_stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")
    print()
    
    # Graceful shutdown
    print("Shutting down logger...")
    logger.shutdown()
    print("Done!")


if __name__ == "__main__":
    main()

