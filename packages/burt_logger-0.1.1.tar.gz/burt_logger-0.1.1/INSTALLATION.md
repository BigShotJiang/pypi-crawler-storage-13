# Installation Guide

## Quick Installation

```bash
pip install burt-logger
```

## Development Installation

If you're contributing to the project or want to modify the code:

### 1. Clone the Repository

```bash
git clone https://github.com/trainburt/burt-logger-python.git
cd burt-logger-python
```

### 2. Install in Editable Mode

```bash
# Install package in editable mode
pip install -e .

# Or install with development dependencies
pip install -e ".[dev]"
```

### 3. Verify Installation

```bash
python verify_install.py
```

You should see:

```
✓ All tests passed! Burt Logger is ready to use.
```

### 4. Run Examples

```bash
python examples/simple_example.py
```

## Installation Methods

### Method 1: pip (Recommended)

```bash
pip install burt-logger
```

### Method 2: From Source

```bash
git clone https://github.com/trainburt/burt-logger-python.git
cd burt-logger-python
pip install .
```

### Method 3: From Source (Development)

```bash
git clone https://github.com/trainburt/burt-logger-python.git
cd burt-logger-python
pip install -e ".[dev]"
```

## Requirements

-  **Python**: 3.7 or higher
-  **Dependencies**:
   -  `requests` >= 2.25.0 (automatically installed)

## Verifying Installation

### Basic Test

```python
python -c "from burt_logger import LLMLogger; print('Success!')"
```

### Full Verification

```bash
python verify_install.py
```

This runs comprehensive tests to ensure everything works correctly.

## Common Issues

### Issue: "ModuleNotFoundError: No module named 'burt_logger'"

**Solution**: Install the package first

```bash
pip install burt-logger
# or for development
pip install -e .
```

### Issue: "The 'requests' library is required"

**Solution**: Install requests

```bash
pip install requests
# or reinstall burt-logger
pip install --force-reinstall burt-logger
```

### Issue: "Permission denied" during installation

**Solution**: Use --user flag

```bash
pip install --user burt-logger
```

Or use a virtual environment (recommended):

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install burt-logger
```

## Virtual Environment Setup

### Using venv (Recommended)

```bash
# Create virtual environment
python -m venv venv

# Activate (Linux/Mac)
source venv/bin/activate

# Activate (Windows)
venv\Scripts\activate

# Install package
pip install burt-logger
```

### Using conda

```bash
# Create environment
conda create -n burt-logger python=3.9

# Activate
conda activate burt-logger

# Install package
pip install burt-logger
```

## Development Setup

For contributors and developers:

```bash
# Clone repository
git clone https://github.com/trainburt/burt-logger-python.git
cd burt-logger-python

# Create virtual environment
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Install with dev dependencies
pip install -e ".[dev]"

# Verify installation
python verify_install.py

# Run tests
pytest

# Run examples
python examples/simple_example.py
```

## Upgrading

```bash
# Upgrade to latest version
pip install --upgrade burt-logger

# Upgrade to specific version
pip install burt-logger==0.2.0
```

## Uninstalling

```bash
pip uninstall burt-logger
```

## Platform-Specific Notes

### macOS

```bash
# Use pip3 if you have multiple Python versions
pip3 install burt-logger
python3 -c "from burt_logger import LLMLogger"
```

### Linux

```bash
# May need python3-pip
sudo apt-get install python3-pip  # Ubuntu/Debian
sudo yum install python3-pip       # CentOS/RHEL

pip3 install burt-logger
```

### Windows

```bash
# Install from command prompt or PowerShell
pip install burt-logger

# If pip is not found, try:
python -m pip install burt-logger
```

## Docker

```dockerfile
FROM python:3.9-slim

# Install burt-logger
RUN pip install burt-logger

# Your application code
COPY . /app
WORKDIR /app

CMD ["python", "your_app.py"]
```

## Checking Installation

After installation, check the version:

```python
from burt_logger import __version__
print(__version__)  # Should print: 0.1.0
```

## Next Steps

After successful installation:

1. **Quick Start**: Read [QUICKSTART.md](QUICKSTART.md)
2. **Examples**: Check [examples/](examples/) directory
3. **Documentation**: Read [README.md](README.md)
4. **Contributing**: See [CONTRIBUTING.md](CONTRIBUTING.md)

## Support

If you encounter any installation issues:

1. Check this guide for common solutions
2. Verify your Python version: `python --version`
3. Try in a clean virtual environment
4. Open an issue: https://github.com/yourusername/burt-logger-python/issues
5. Email: support@burt.ai

---

Happy logging! 🚀
