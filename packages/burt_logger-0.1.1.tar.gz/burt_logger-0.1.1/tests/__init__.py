"""Tests for burt-logger package."""

