"""
Burt Logger - A lightweight Python package for collecting LLM training data.

This package provides a simple interface to log LLM request/response data
to a backend API for training dataset creation and model fine-tuning.
"""

from .logger import LLMLogger

__version__ = "0.1.0"
__all__ = ["LLMLogger"]

