# math\_playground

A simple Python package providing mathematical utility functions for educational purposes.

## Features

This package includes two main modules:

### Module 1: Core Math Functions

* **factorial(n)** - Calculate factorial of a non-negative integer
* **fibonacci(n)** - Generate first n Fibonacci numbers
* **fibonacci\_nth(n)** - Get the nth Fibonacci number

### Module 2: Statistics \& Prime Numbers

* **is\_prime(n)** - Check if a number is prime
* **get\_primes(limit)** - Get all prime numbers up to a limit
* **mean(numbers)** - Calculate mean of a list
* **median(numbers)** - Calculate median of a list
* **mode(numbers)** - Find the most frequent value

## Installation

### From TestPyPI

```bash
pip install -i https://test.pypi.org/simple/ math-playground-student
```

### From Source

```bash
git clone <your-repo-url>
cd math-playground
pip install -e .
```

## Usage

```python
from math\\\_playground import factorial, fibonacci, is\\\_prime, mean, median

# Calculate factorial
print(factorial(5))  # Output: 120

# Generate Fibonacci sequence
print(fibonacci(7))  # Output: \\\[0, 1, 1, 2, 3, 5, 8]

# Check if number is prime
print(is\\\_prime(17))  # Output: True

# Calculate statistics
numbers = \\\[1, 2, 3, 4, 5]
print(mean(numbers))    # Output: 3.0
print(median(numbers))  # Output: 3
```

## Development

### Running Tests

```bash
cd tests
python test\\\_sample.py
```

### Building the Package

```bash
pip install build
python -m build
```

### Publishing to TestPyPI

```bash
pip install twine
python -m twine upload --repository testpypi dist/\\\*
```

## Requirements

* Python >= 3.7

## Author

Your Name - your.email@example.com

## Project Structure

```
math\\\_playground/
├── src/
│   └── math\\\_playground/
│       ├── \\\_\\\_init\\\_\\\_.py
│       ├── module1.py
│       └── module2.py
├── tests/
│   ├── test\\\_sample.py
│   └── demo\\\_usage.py
├── pyproject.toml
├── README.md
└── LICENSE
```

## Version History

* **0.1.0** - Initial release with basic math and statistics functions
