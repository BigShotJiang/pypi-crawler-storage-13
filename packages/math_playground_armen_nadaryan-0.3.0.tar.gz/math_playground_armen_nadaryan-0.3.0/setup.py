from setuptools import setup, find_packages


setup(
    name='math_playground',
    version='0.3',
    packages=find_packages(),
    install_requires=[
        ]

)