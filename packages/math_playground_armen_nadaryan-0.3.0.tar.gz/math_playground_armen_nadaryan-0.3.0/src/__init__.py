import os
from pathlib import Path

from module1 import factorial, fibonacci, fibonacci_nth
from module2 import is_prime, get_primes, mean, median, mode

__version__ = "0.1.0"

__all__ = [
    "factorial",
    "fibonacci",
    "fibonacci_nth",
    "is_prime",
    "get_primes",
    "mean",
    "median",
    "mode",
]