def is_prime(n):
    """
    Check if a number is prime.
    
    Args:
        n (int): Number to check
        
    Returns:
        bool: True if n is prime, False otherwise
    """
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    
    # Check odd divisors up to sqrt(n)
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def get_primes(limit):
    """
    Get all prime numbers up to a given limit.
    
    Args:
        limit (int): Upper bound (inclusive)
        
    Returns:
        list: List of prime numbers up to limit
    """
    if limit < 2:
        return []
    
    primes = []
    for num in range(2, limit + 1):
        if is_prime(num):
            primes.append(num)
    return primes


def mean(numbers):
    """
    Calculate the mean (average) of a list of numbers.
    
    Args:
        numbers (list): List of numbers
        
    Returns:
        float: Mean of the numbers
        
    Raises:
        ValueError: If the list is empty
    """
    if not numbers:
        raise ValueError("Cannot calculate mean of empty list")
    return sum(numbers) / len(numbers)


def median(numbers):
    """
    Calculate the median of a list of numbers.
    
    Args:
        numbers (list): List of numbers
        
    Returns:
        float: Median of the numbers
        
    Raises:
        ValueError: If the list is empty
    """
    if not numbers:
        raise ValueError("Cannot calculate median of empty list")
    
    sorted_numbers = sorted(numbers)
    n = len(sorted_numbers)
    mid = n // 2
    
    if n % 2 == 0:
        return (sorted_numbers[mid - 1] + sorted_numbers[mid]) / 2
    else:
        return sorted_numbers[mid]


def mode(numbers):
    """
    Find the mode (most frequent value) of a list of numbers.
    
    Args:
        numbers (list): List of numbers
        
    Returns:
        int/float: Most frequent number
        
    Raises:
        ValueError: If the list is empty
    """
    if not numbers:
        raise ValueError("Cannot calculate mode of empty list")
    
    frequency = {}
    for num in numbers:
        frequency[num] = frequency.get(num, 0) + 1
    
    return max(frequency, key=frequency.get)