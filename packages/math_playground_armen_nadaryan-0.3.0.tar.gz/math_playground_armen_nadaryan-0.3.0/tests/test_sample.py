import sys
sys.path.insert(0, '../src')

from src import (
    factorial, fibonacci, fibonacci_nth,
    is_prime, get_primes, mean, median, mode
)

def test_factorial():
    """Test factorial function"""
    print("Testing factorial...")
    assert factorial(0) == 1, "factorial(0) failed"
    assert factorial(1) == 1, "factorial(1) failed"
    assert factorial(5) == 120, "factorial(5) failed"
    assert factorial(10) == 3628800, "factorial(10) failed"
    print("✓ factorial tests passed")

def test_fibonacci():
    """Test fibonacci function"""
    print("Testing fibonacci...")
    assert fibonacci(0) == [], "fibonacci(0) failed"
    assert fibonacci(1) == [0], "fibonacci(1) failed"
    assert fibonacci(5) == [0, 1, 1, 2, 3], "fibonacci(5) failed"
    assert fibonacci(7) == [0, 1, 1, 2, 3, 5, 8], "fibonacci(7) failed"
    print("✓ fibonacci tests passed")

def test_fibonacci_nth():
    """Test fibonacci_nth function"""
    print("Testing fibonacci_nth...")
    assert fibonacci_nth(0) == 0, "fibonacci_nth(0) failed"
    assert fibonacci_nth(1) == 1, "fibonacci_nth(1) failed"
    assert fibonacci_nth(6) == 8, "fibonacci_nth(6) failed"
    assert fibonacci_nth(10) == 55, "fibonacci_nth(10) failed"
    print("✓ fibonacci_nth tests passed")

def test_is_prime():
    """Test is_prime function"""
    print("Testing is_prime...")
    assert is_prime(2) == True, "is_prime(2) failed"
    assert is_prime(17) == True, "is_prime(17) failed"
    assert is_prime(4) == False, "is_prime(4) failed"
    assert is_prime(1) == False, "is_prime(1) failed"
    assert is_prime(0) == False, "is_prime(0) failed"
    print("✓ is_prime tests passed")

def test_get_primes():
    """Test get_primes function"""
    print("Testing get_primes...")
    assert get_primes(10) == [2, 3, 5, 7], "get_primes(10) failed"
    assert get_primes(1) == [], "get_primes(1) failed"
    assert get_primes(20) == [2, 3, 5, 7, 11, 13, 17, 19], "get_primes(20) failed"
    print("✓ get_primes tests passed")

def test_mean():
    """Test mean function"""
    print("Testing mean...")
    assert mean([1, 2, 3, 4, 5]) == 3.0, "mean([1,2,3,4,5]) failed"
    assert mean([10, 20, 30]) == 20.0, "mean([10,20,30]) failed"
    assert mean([5]) == 5.0, "mean([5]) failed"
    print("✓ mean tests passed")

def test_median():
    """Test median function"""
    print("Testing median...")
    assert median([1, 2, 3, 4, 5]) == 3, "median([1,2,3,4,5]) failed"
    assert median([1, 2, 3, 4]) == 2.5, "median([1,2,3,4]) failed"
    assert median([5]) == 5, "median([5]) failed"
    print("✓ median tests passed")

def test_mode():
    """Test mode function"""
    print("Testing mode...")
    assert mode([1, 2, 2, 3, 4]) == 2, "mode([1,2,2,3,4]) failed"
    assert mode([1, 1, 1, 2, 3]) == 1, "mode([1,1,1,2,3]) failed"
    print("✓ mode tests passed")

def run_all_tests():
    """Run all tests"""
    print("=" * 50)
    print("Running math_playground tests...")
    print("=" * 50)
    
    try:
        test_factorial()
        test_fibonacci()
        test_fibonacci_nth()
        test_is_prime()
        test_get_primes()
        test_mean()
        test_median()
        test_mode()
        
        print("=" * 50)
        print("✓ All tests passed successfully!")
        print("=" * 50)
        
    except AssertionError as e:
        print(f"\\n✗ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\\n✗ Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    run_all_tests()