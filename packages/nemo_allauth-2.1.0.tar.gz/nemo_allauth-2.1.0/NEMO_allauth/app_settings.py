# Plugin settings
AUTO_CONNECT_VERIFIED_EMAIL = True
TRUST_SUPERUSERS_EMAIL = True
SEND_EMAIL_VERIFICATION_ON_USER_SAVE = True

# All auth settings
SITE_ID = 1
ACCOUNT_DEFAULT_HTTP_PROTOCOL = "https"
ACCOUNT_LOGIN_METHODS = {"email"}
ACCOUNT_SIGNUP_FIELDS = ["email*"]

ACCOUNT_EMAIL_VERIFICATION = "mandatory"
SOCIALACCOUNT_EMAIL_VERIFICATION = ACCOUNT_EMAIL_VERIFICATION

ACCOUNT_ADAPTER = "NEMO_allauth.adapter.NEMOAccountAdapter"
SOCIALACCOUNT_ADAPTER = "NEMO_allauth.adapter.NEMOSocialAccountAdapter"

# See https://django-allauth.readthedocs.io/en/latest/release-notes.html#security-notice for details
SOCIALACCOUNT_LOGIN_ON_GET = True
