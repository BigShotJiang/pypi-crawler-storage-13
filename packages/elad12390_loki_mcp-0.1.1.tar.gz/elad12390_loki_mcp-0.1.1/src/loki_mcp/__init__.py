import os
import subprocess
import sys
import shutil
from pathlib import Path


def main():
    """
    Entry point for the Loki MCP Server wrapper.
    It builds the Go binary if not present and runs it.
    """
    package_dir = Path(__file__).parent
    go_src_dir = package_dir / "go_src"

    # Name of the binary
    bin_name = "loki-mcp-server"
    if sys.platform == "win32":
        bin_name += ".exe"

    bin_path = package_dir / bin_name

    # Check if we need to build
    if not bin_path.exists():
        print(f"Binary not found at {bin_path}. Building...", file=sys.stderr)

        # Verify Go is installed
        if not shutil.which("go"):
            print("Error: 'go' is not installed or not in PATH.", file=sys.stderr)
            print("Please install Go 1.24+ to use this package.", file=sys.stderr)
            sys.exit(1)

        # Build the binary
        cmd_path = go_src_dir / "cmd" / "server"
        if not cmd_path.exists():
            # Fallback for development (running from root without pip install)
            # If we are in the root of the repo, go_src might not exist as a subdir
            # but the actual source is at ../../
            repo_root = package_dir.parent.parent
            cmd_path = repo_root / "cmd" / "server"

        if not cmd_path.exists():
            print(
                f"Error: Could not find Go source code at {go_src_dir} or {cmd_path}",
                file=sys.stderr,
            )
            sys.exit(1)

        try:
            # We build into the package directory so it's cached for next time
            subprocess.check_call(
                ["go", "build", "-o", str(bin_path), "."],
                cwd=str(cmd_path),
                env={**os.environ, "CGO_ENABLED": "0"},
            )
            print("Build complete.", file=sys.stderr)
        except subprocess.CalledProcessError as e:
            print(f"Error building Go binary: {e}", file=sys.stderr)
            sys.exit(1)

    # Run the binary
    try:
        # Pass all arguments through to the binary
        result = subprocess.call([str(bin_path)] + sys.argv[1:])
        sys.exit(result)
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as e:
        print(f"Error running binary: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
