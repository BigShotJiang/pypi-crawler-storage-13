from pathlib import Path
import os
import json
import pickle
from datetime import datetime

import typer
from loguru import logger

import pandas as pd

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report

from project_name.config import read_params_from_yaml, project_root, Params
from project_name.config import ModelType

app = typer.Typer()


def load_model(params: Params):
    match params.train_params.model_type:
        case ModelType.LOGISTIC_REGRESSION:
            model = LogisticRegression(
                multi_class=params.train_params.logistic_regression.multi_class,
                solver=params.train_params.logistic_regression.solver,
                max_iter=params.train_params.logistic_regression.max_iter,
                random_state=params.random_state,
            )
        case ModelType.RANDOM_FOREST:
            model = RandomForestClassifier(
                n_estimators=params.train_params.random_forest.n_estimators,
                max_depth=params.train_params.random_forest.max_depth,
                random_state=params.random_state,
            )
        case ModelType.DECISION_TREE:
            model = DecisionTreeClassifier(
                criterion=params.train_params.decision_tree.criterion,
                max_depth=params.train_params.decision_tree.max_depth,
                random_state=params.random_state,
            )
    return model


def split_x_y(df: pd.DataFrame, target_column_name: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    y = df[target_column_name]
    x = df.drop(target_column_name, axis=1)
    return x, y


def save_file_path(params: Params, orig_path: str, filename: str):
    """
    Form correct output folder with different folders for models
    """
    folder = project_root / orig_path / str(params.train_params.model_type.value)
    os.makedirs(folder, exist_ok=True)
    return folder / filename


@app.command()
def main(
        params_path: Path,
):
    params = read_params_from_yaml(params_path)

    df_train = pd.read_csv(project_root / params.generate_dataset.train_data_path)
    df_test = pd.read_csv(project_root / params.generate_dataset.test_data_path)

    x_train, y_train = split_x_y(df_train, params.generate_dataset.target_column_name)
    x_test, y_test = split_x_y(df_test, params.generate_dataset.target_column_name)
    logger.info("Dataset is loaded. Loading model...")

    model = load_model(params)
    logger.info(f"{model} is loaded. Starting training...")

    model.fit(x_train, y_train)
    logger.info("Trained successfully. Saving...")

    model_path = save_file_path(params, params.models_path, "model.pkl")
    with open(model_path, "wb") as f:
        pickle.dump(model, f)
    logger.success(f"Model is saved to {project_root / params.models_path}")

    y_pred = model.predict(x_test)

    report = classification_report(y_test, y_pred, output_dict=True)

    report_path = save_file_path(params, params.report_path, "classification_report.json")
    with open(report_path, "w") as json_file:
        json.dump(report, json_file, indent=4)


if __name__ == "__main__":
    app()
