import os
import pickle
from pathlib import Path
import pandas as pd
import typer
from loguru import logger
from project_name.config import read_params_from_yaml, project_root, Params

app = typer.Typer()

def get_latest_model_path(model_dir: Path) -> Path:
    model_files = list(model_dir.glob("model.pkl"))
    if not model_files:
        raise FileNotFoundError(f"No model in directory: {model_dir}")
    latest_model = max(model_files, key=os.path.getmtime)
    return latest_model


def load_latest_model(params: Params):
    model_dir = (
        project_root / params.models_path / str(params.train_params.model_type.value)
    )

    if not model_dir.exists():
        raise FileNotFoundError(f"No such model directory: {model_dir}")

    model_path = get_latest_model_path(model_dir)

    with open(model_path, "rb") as f:
        model = pickle.load(f)
        print(type(model))

    return model, model_path


@app.command()
def main(
    params_path: Path

):
    params = read_params_from_yaml(params_path)
    new_data_path = project_root / params.generate_dataset.full_data_path

    new_data = pd.read_csv(new_data_path)
    logger.info(f"{new_data_path} is loaded")

    model, model_path = load_latest_model(params)
    logger.info(f"Model {model} loaded from directory: {model_path}")

    x_new = new_data.drop(
        columns=[params.generate_dataset.target_column_name], errors="ignore"
    )

    predictions = model.predict(x_new)
    logger.success(f"{len(predictions)} predictions are done")

    predictions_path = project_root / params.predictions_path / "inference_predictions.csv"
    os.makedirs(os.path.dirname(predictions_path), exist_ok=True)

    result_df = new_data.copy()
    result_df["predictions"] = predictions
    result_df.to_csv(predictions_path, index=False)
    logger.info(f"Predictions saved to {predictions_path}")


if __name__ == "__main__":
    app()
