from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad, unpad
from base64 import b64encode, b64decode
import hashlib
import hmac
import binascii

KEY = b'2tBeoEyJTunmWUGq7bQH2Abn0k2NhhurOaqBfyxCuLVgn4AVj7swcawe53uDUno'
IV = b'0102030405060708'

def get_cipher(ssecurity: str):
    key = b64decode(ssecurity)
    return AES.new(key, AES.MODE_CBC, IV)

def encrypt_data(data: str, ssecurity: str) -> str:
    cipher = get_cipher(ssecurity)
    encrypted = cipher.encrypt(pad(data.encode(), AES.block_size))
    return b64encode(encrypted).decode()

def decrypt_response(encrypted: str, ssecurity: str) -> str:
    cipher = get_cipher(ssecurity)
    decrypted = unpad(cipher.decrypt(b64decode(encrypted)), AES.block_size)
    return decrypted.decode()

def generate_sign(path: str, params_str: str, ssecurity: str) -> str:
    sign_str = f"POST\n{path}\n{params_str}"
    digest = hmac.new(KEY, sign_str.encode(), hashlib.sha1).digest()
    hex_digest = binascii.hexlify(digest).decode()
    return encrypt_data(hex_digest, ssecurity)

def generate_signature(path: str, encrypted_params: list, sign: str, ssecurity: str) -> str:
    params_part = "&".join(encrypted_params)
    sha1_input = f"POST&{path}&{params_part}&sign={sign}&{ssecurity}"
    return b64encode(hashlib.sha1(sha1_input.encode()).digest()).decode()