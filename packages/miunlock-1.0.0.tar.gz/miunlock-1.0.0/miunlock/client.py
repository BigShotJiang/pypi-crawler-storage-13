import requests
import json
import random
import hashlib
from base64 import b64encode
from .crypto import encrypt_data, decrypt_response, generate_sign, generate_signature
from .regions import SUBDOMAINS

class MiUnlockClient:
    def __init__(self, cookies: dict, pcId: str, token: str, product: str,
                 method: str = "getPublicKey", regionConfig: str = "Singapore"):
        
        self.cookies = cookies
        self.pcId = pcId
        self.token = token
        self.product = product
        self.method = method
        self.regionConfig = regionConfig
        
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "offici5l/MiUnlockTool"})
        self.ssecurity = None
        self.subdomain = SUBDOMAINS.get(regionConfig)
        if not self.subdomain:
            raise ValueError(f"Invalid region: {regionConfig}. Choose from: {list(SUBDOMAINS.keys())}")

        self._login_and_get_ssecurity()

    def _login_and_get_ssecurity(self):
        url = f"https://account.xiaomi.com/pass/serviceLogin?sid=unlockApi&{self.method}=true"
        r = self.session.get(url, cookies=self.cookies)
        if not r.history:
            raise ValueError("No redirect found. Check cookies.")
        
        pragma = r.history[0].headers.get('extension-pragma', '{}')
        data = json.loads(pragma)
        self.ssecurity = data.get('ssecurity')
        if not self.ssecurity:
            raise ValueError("Failed to get ssecurity. Invalid cookies?")
        
        self.cookies.update(r.cookies.get_dict())

    def _send(self, path: str, param_order: list, params_raw: dict):
        # تحويل data إلى base64 إذا وجد
        if 'data' in params_raw:
            params_raw['data'] = b64encode(json.dumps(params_raw['data']).encode()).decode()

        params_raw["sid"] = "miui_unlocktool_client"
        
        # إنشاء sign_params بدون تشفير
        sign_params = "&".join(f"{k}={params_raw[k]}" for k in param_order)
        sign = generate_sign(path, sign_params, self.ssecurity)
        
        # تشفير الباراميترز
        encrypted_params = [f"{k}={encrypt_data(str(params_raw[k]), self.ssecurity)}" for k in param_order]
        encrypted_params.extend([f"sign={sign}", self.ssecurity])
        
        signature = generate_signature(path, encrypted_params, sign, self.ssecurity)
        
        # إرسال الطلب
        post_data = {k: encrypt_data(str(params_raw[k]), self.ssecurity) for k in param_order}
        post_data.update({"sign": sign, "signature": signature})
        
        url = f"https://{self.subdomain}.miui.com{path}"
        r = self.session.post(url, params=post_data, cookies=self.cookies)
        
        if not r.text:
            return {"error": "Empty response"}
        
        decrypted = decrypt_response(r.text, self.ssecurity)
        return json.loads(decrypted)

    def get_nonce(self):
        r = ''.join(random.choices("abcdefghijklmnopqrstuvwxyz", k=16))
        return self._send('/api/v2/nonce', ['r', 'sid'], {'r': r})

    def unlock(self, userId: str):
        nonce_resp = self.get_nonce()
        nonce = nonce_resp.get('nonce')
        if not nonce:
            return nonce_resp

        data = {
            "clientId": "2",
            "clientVersion": "7.6.727.43",
            "deviceInfo": {
                "boardVersion": "",
                "deviceName": "",
                "product": self.product,
                "socId": ""
            },
            "deviceToken": self.token,
            "language": "en",
            "operate": "unlock",
            "pcId": hashlib.md5(self.pcId.encode()).hexdigest(),
            "region": "",
            "uid": userId
        }

        return self._send('/api/v3/ahaUnlock', ['appId', 'data', 'nonce', 'sid'], {
            'appId': '1',
            'data': data,
            'nonce': nonce
        })