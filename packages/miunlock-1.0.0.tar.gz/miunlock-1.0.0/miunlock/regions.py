SUBDOMAINS = {
    "Singapore": "unlock.update.intl",
    "China": "unlock.update",
    "India": "in-unlock.update.intl",
    "Russia": "ru-unlock.update.intl",
    "Europe": "eu-unlock.update.intl",
}

REGION_TO_CONFIG = {v: k for k, v in SUBDOMAINS.items()}