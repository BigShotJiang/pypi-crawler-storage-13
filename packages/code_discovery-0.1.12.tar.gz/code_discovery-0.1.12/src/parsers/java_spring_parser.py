"""Spring Boot API parser."""

import re
from pathlib import Path
from typing import List, Optional, Dict, Any
from parsers.base import BaseParser
from core.models import (
    APIEndpoint,
    APIParameter,
    APIResponse,
    AuthenticationRequirement,
    AuthenticationType,
    DiscoveryResult,
    FrameworkType,
    HTTPMethod,
    ParameterLocation,
)


class SpringBootParser(BaseParser):
    """Parser for Spring Boot REST APIs."""

    def parse(self) -> DiscoveryResult:
        """Parse Spring Boot source files for API endpoints."""
        endpoints = []
        java_files = self.find_files("*.java")

        for java_file in java_files:
            content = self.read_file(java_file)
            if content and self._is_rest_controller(content):
                endpoints.extend(self._parse_controller(java_file, content))

        return DiscoveryResult(
            framework=FrameworkType.SPRING_BOOT,
            endpoints=endpoints,
            title="Spring Boot API",
        )

    def get_framework_type(self) -> FrameworkType:
        """Get the framework type."""
        return FrameworkType.SPRING_BOOT

    def _is_rest_controller(self, content: str) -> bool:
        """Check if the class is a REST controller."""
        return "@RestController" in content or "@Controller" in content

    def _parse_controller(self, file_path: Path, content: str) -> List[APIEndpoint]:
        """Parse a controller file for endpoints."""
        endpoints = []
        
        # Extract class-level @RequestMapping
        class_path = self._extract_class_request_mapping(content)
        
        # Find all method annotations
        methods = self._extract_methods(content)
        
        for method_info in methods:
            endpoint = self._create_endpoint(
                method_info,
                class_path,
                file_path,
            )
            if endpoint:
                endpoints.append(endpoint)

        return endpoints

    def _extract_class_request_mapping(self, content: str) -> str:
        """Extract class-level @RequestMapping path."""
        # Match @RequestMapping("/path") or @RequestMapping(value = "/path")
        patterns = [
            r'@RequestMapping\s*\(\s*"([^"]+)"\s*\)',
            r'@RequestMapping\s*\(\s*value\s*=\s*"([^"]+)"\s*\)',
            r'@RequestMapping\s*\(\s*path\s*=\s*"([^"]+)"\s*\)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, content)
            if match:
                return match.group(1)
        
        return ""

    def _extract_methods(self, content: str) -> List[Dict[str, Any]]:
        """Extract method information from controller."""
        methods = []
        
        # Patterns for different Spring annotations
        mapping_patterns = [
            (r'@GetMapping\s*\(\s*"([^"]+)"\s*\)', HTTPMethod.GET),
            (r'@PostMapping\s*\(\s*"([^"]+)"\s*\)', HTTPMethod.POST),
            (r'@PutMapping\s*\(\s*"([^"]+)"\s*\)', HTTPMethod.PUT),
            (r'@DeleteMapping\s*\(\s*"([^"]+)"\s*\)', HTTPMethod.DELETE),
            (r'@PatchMapping\s*\(\s*"([^"]+)"\s*\)', HTTPMethod.PATCH),
            (r'@RequestMapping\s*\([^)]*method\s*=\s*RequestMethod\.(\w+)[^)]*value\s*=\s*"([^"]+)"[^)]*\)', None),
        ]
        
        for pattern, default_method in mapping_patterns:
            for match in re.finditer(pattern, content):
                if default_method:
                    path = match.group(1)
                    http_method = default_method
                else:
                    http_method = HTTPMethod[match.group(1).upper()]
                    path = match.group(2)
                
                # Extract method signature and body
                method_start = match.end()
                method_signature = self._extract_method_signature(content, method_start)
                
                methods.append({
                    "path": path,
                    "method": http_method,
                    "signature": method_signature,
                    "position": match.start(),
                })
        
        return methods

    def _extract_method_signature(self, content: str, start_pos: int) -> str:
        """Extract Java method signature after annotation, handling multi-line parameters."""
        # Look for method declaration start
        remaining = content[start_pos:]
        
        # Find method visibility modifier
        visibility_match = re.search(r'^(public|private|protected)\s+', remaining)
        if visibility_match:
            method_start_idx = visibility_match.start()
            after_visibility = visibility_match.end()
        else:
            method_start_idx = 0
            after_visibility = 0
        
        # Now find the method name - it's the last identifier before the opening paren
        # This handles nested generics in return types like ResponseEntity<List<Tutorial>>
        # Pattern: find identifier followed by opening paren
        method_name_pattern = r'(\w+)\s*\('
        method_name_match = re.search(method_name_pattern, remaining[after_visibility:])
        if not method_name_match:
            return ""
        
        # The opening paren is at after_visibility + method_name_match.end() - 1
        paren_start = after_visibility + method_name_match.end() - 1
        
        # Find matching closing parenthesis, handling nested parens and annotations
        paren_count = 0
        i = paren_start
        in_string = False
        string_char = None
        
        while i < len(remaining) and i < paren_start + 2000:  # Reasonable limit
            char = remaining[i]
            
            # Track string literals to avoid matching parens inside strings
            if char in ['"', "'"] and (i == 0 or remaining[i-1] != '\\'):
                if not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char:
                    in_string = False
                    string_char = None
            
            if not in_string:
                if char == '(':
                    paren_count += 1
                elif char == ')':
                    paren_count -= 1
                    if paren_count == 0:
                        # Found matching closing paren - include it
                        method_end_idx = i + 1
                        return remaining[method_start_idx:method_end_idx]
            i += 1
        
        # Fallback: if we can't find matching paren, try single-line pattern
        method_pattern = r'(public|private|protected)?\s+[\w<>[\],\s]+\s+\w+\s*\([^)]*\)'
        match = re.search(method_pattern, remaining[:500])
        if match:
            return match.group(0)
        
        return ""

    def _create_endpoint(
        self,
        method_info: Dict[str, Any],
        class_path: str,
        file_path: Path,
    ) -> Optional[APIEndpoint]:
        """Create an APIEndpoint from method information."""
        # Combine class path and method path
        full_path = self._combine_paths(class_path, method_info["path"])
        full_path = self.normalize_path(full_path)
        
        # Extract parameters from signature
        parameters = self._extract_parameters(method_info["signature"], full_path)
        
        # Extract request body if present
        request_body = self._extract_request_body(method_info["signature"], file_path)
        
        # Extract response schema from return type
        response_schema = self._extract_response_schema(method_info["signature"], file_path)
        
        # Create endpoint
        endpoint = APIEndpoint(
            path=full_path,
            method=method_info["method"],
            operation_id=self._generate_operation_id(full_path, method_info["method"]),
            parameters=parameters,
            request_body=request_body,
            responses=[
                APIResponse(
                    status_code=200,
                    description="Successful response",
                    schema=response_schema,
                )
            ],
            source_file=self.get_relative_path(file_path),
        )
        
        return endpoint

    def _combine_paths(self, base: str, path: str) -> str:
        """Combine base path and method path."""
        if not base:
            return path
        if not path:
            return base
        
        # Remove trailing slash from base and leading slash from path
        base = base.rstrip('/')
        path = path.lstrip('/')
        
        return f"{base}/{path}"

    def _extract_parameters(self, signature: str, path: str) -> List[APIParameter]:
        """Extract parameters from method signature."""
        parameters = []
        
        # Extract path parameters
        path_vars = self.extract_path_variables(path)
        for var in path_vars:
            # Try to find @PathVariable annotation with type
            # Handle both @PathVariable("id") long id and @PathVariable long id
            # Pattern 1: @PathVariable("id") Type id
            pattern1 = rf'@PathVariable\s*\([^)]*["\']?{var}["\']?[^)]*\)\s+(?:final\s+)?([\w<>[\],\s]+)\s+{var}'
            # Pattern 2: @PathVariable Type id (no quotes)
            pattern2 = rf'@PathVariable\s+(?:final\s+)?([\w<>[\],\s]+)\s+{var}'
            
            param_type = "string"
            match = re.search(pattern1, signature, re.MULTILINE | re.DOTALL)
            if match:
                param_type = self._java_type_to_openapi_type(match.group(1).strip())
            else:
                match = re.search(pattern2, signature, re.MULTILINE | re.DOTALL)
                if match:
                    param_type = self._java_type_to_openapi_type(match.group(1).strip())
            
            parameters.append(
                APIParameter(
                    name=var,
                    location=ParameterLocation.PATH,
                    required=True,
                    type=param_type,
                )
            )
        
        # Extract query parameters from @RequestParam with types
        # Handle both single-line and multi-line: @RequestParam(...)\n Type paramName
        # Pattern matches: @RequestParam(required = false) String title
        pattern = r'@RequestParam\s*(?:\(([^)]*)\))?\s+(?:final\s+)?([\w<>[\],\s]+)\s+(\w+)'
        for match in re.finditer(pattern, signature, re.MULTILINE | re.DOTALL):
            annotation_params = match.group(1) if match.group(1) else ""
            param_type = self._java_type_to_openapi_type(match.group(2).strip())
            param_name = match.group(3)
            if param_name not in path_vars:
                # Check if required (default is true for @RequestParam)
                # Look for required=false in the annotation parameters
                required = "required=false" not in annotation_params and "required = false" not in annotation_params
                parameters.append(
                    APIParameter(
                        name=param_name,
                        location=ParameterLocation.QUERY,
                        required=required,
                        type=param_type,
                    )
                )
        
        # Extract header parameters from @RequestHeader
        pattern = r'@RequestHeader\s*(?:\([^)]*\))?\s+(?:final\s+)?([\w<>[\],\s]+)\s+(\w+)'
        for match in re.finditer(pattern, signature):
            param_type = self._java_type_to_openapi_type(match.group(1).strip())
            param_name = match.group(2)
            parameters.append(
                APIParameter(
                    name=param_name,
                    location=ParameterLocation.HEADER,
                    required=False,
                    type=param_type,
                )
            )
        
        return parameters

    def _extract_request_body(self, signature: str, file_path: Optional[Path] = None) -> Optional[Dict[str, Any]]:
        """Extract request body from method signature."""
        # Look for @RequestBody annotation
        if "@RequestBody" not in signature:
            return None
        
        # Extract parameter type after @RequestBody
        # Handle multi-line: @RequestBody\n Type paramName
        pattern = r'@RequestBody\s+(?:@\w+\s+)*(?:final\s+)?([\w<>[\],\s]+)\s+\w+'
        match = re.search(pattern, signature, re.MULTILINE | re.DOTALL)
        if match:
            param_type = match.group(1).strip()
            schema = self._java_type_to_schema(param_type, file_path)
            return {
                "required": True,
                "content": {
                    "application/json": {
                        "schema": schema,
                    }
                },
            }
        
        return None

    def _extract_response_schema(self, signature: str, file_path: Optional[Path] = None) -> Optional[Dict[str, Any]]:
        """Extract response schema from method return type."""
        # Extract return type from method signature
        # Pattern: public ReturnType methodName(...)
        # Need to capture the full return type including nested generics like ResponseEntity<List<Tutorial>>
        
        # Method signature format: [visibility] ReturnType methodName(params)
        # We need to extract ReturnType
        
        # Find visibility modifier (optional)
        visibility_match = re.search(r'^(public|private|protected)\s+', signature)
        if visibility_match:
            start_pos = visibility_match.end()
        else:
            # No visibility modifier, start from beginning
            start_pos = 0
        
        # Now we need to find where the method name starts
        # The method name comes after the return type and before the opening paren
        # We need to handle nested generics in the return type
        
        # Find the opening parenthesis of the method parameters
        # This marks the end of the return type + method name
        paren_pos = signature.find('(')
        if paren_pos == -1:
            return None
        
        # Extract everything from start_pos to paren_pos
        # This gives us: ReturnType methodName
        return_and_method = signature[start_pos:paren_pos].strip()
        
        # Now we need to separate return type from method name
        # Method name is the last word before the paren
        # But return type can have spaces and generics: ResponseEntity<List<Tutorial>>
        
        # Find the last word (method name) - it's the last identifier before the paren
        # Pattern: find last sequence of word characters
        method_name_match = re.search(r'(\w+)\s*$', return_and_method)
        if not method_name_match:
            return None
        
        method_name_start = method_name_match.start()
        return_type = return_and_method[:method_name_start].strip()
        
        # Skip void and HttpStatus
        if return_type in ["void", "Void", "HttpStatus"] or not return_type:
            return None
        
        # Parse the return type schema
        schema = self._java_type_to_schema(return_type, file_path)
        return schema

    def _java_type_to_openapi_type(self, java_type: str) -> str:
        """Convert Java type to OpenAPI type."""
        java_type = java_type.strip()
        type_map = {
            "int": "integer",
            "Integer": "integer",
            "long": "integer",
            "Long": "integer",
            "float": "number",
            "Float": "number",
            "double": "number",
            "Double": "number",
            "boolean": "boolean",
            "Boolean": "boolean",
            "String": "string",
            "char": "string",
            "Character": "string",
        }
        return type_map.get(java_type, "string")

    def _java_type_to_schema(self, java_type: str, file_path: Optional[Path] = None) -> Dict[str, Any]:
        """Convert Java type to OpenAPI schema, parsing model classes if available."""
        java_type = java_type.strip()

        # Handle generic types like List<String>, Map<String, Object>, ResponseEntity<List<T>>
        if "<" in java_type:
            # Extract base type and inner type(s)
            base_type = java_type.split("<")[0].strip()
            
            # Extract inner type - handle nested generics like ResponseEntity<List<Tutorial>>
            # Find the matching closing bracket
            inner_start = java_type.find("<") + 1
            bracket_count = 0
            inner_end = inner_start
            for i in range(inner_start, len(java_type)):
                if java_type[i] == '<':
                    bracket_count += 1
                elif java_type[i] == '>':
                    if bracket_count == 0:
                        inner_end = i
                        break
                    bracket_count -= 1
            
            inner_type = java_type[inner_start:inner_end].strip()
            
            if base_type in ["List", "ArrayList", "Set", "HashSet"]:
                # Parse inner type schema recursively
                inner_schema = self._java_type_to_schema(inner_type, file_path)
                return {"type": "array", "items": inner_schema}
            elif base_type in ["Map", "HashMap"]:
                return {"type": "object", "additionalProperties": True}
            elif base_type in ["ResponseEntity"]:
                # Handle ResponseEntity<T> or ResponseEntity<List<T>> - extract inner type recursively
                return self._java_type_to_schema(inner_type, file_path)

        # Handle simple types
        openapi_type = self._java_type_to_openapi_type(java_type)
        if openapi_type != "string":
            return {"type": openapi_type}

        # Try to find and parse the Java model class
        if file_path:
            model_schema = self._parse_java_model(java_type, file_path)
            if model_schema:
                return model_schema

        # Default to object for complex types
        return {"type": "object"}

    def _parse_java_model(self, class_name: str, controller_file: Path) -> Optional[Dict[str, Any]]:
        """Parse a Java model class to extract field definitions."""
        # Search for the model class file in the repository
        java_files = self.find_files("*.java")
        
        for java_file in java_files:
            # Skip controller files
            if "controller" in str(java_file).lower() or "Controller" in java_file.name:
                continue
            
            content = self.read_file(java_file)
            if not content:
                continue
            
            # Check if this file contains the class we're looking for
            # Look for class declaration: public class ClassName
            class_pattern = rf'public\s+class\s+{re.escape(class_name)}\b'
            if not re.search(class_pattern, content):
                continue
            
            # Extract fields from the class
            properties = {}
            required = []
            
            # Pattern to match field declarations: private Type fieldName;
            # or: private Type fieldName = defaultValue;
            # Handle both single-line and multi-line declarations
            field_pattern = r'private\s+([\w<>[\],\s]+)\s+(\w+)(?:\s*=\s*[^;]+)?\s*;'
            
            for match in re.finditer(field_pattern, content, re.MULTILINE):
                field_type = match.group(1).strip()
                field_name = match.group(2).strip()
                
                # Skip if it's a method (has parentheses) or if field_name looks like a method
                if '(' in field_type or ')' in field_type:
                    continue
                
                # Convert Java type to OpenAPI type
                openapi_type = self._java_type_to_openapi_type(field_type)
                
                # Check if field has a default value (making it optional)
                field_declaration = match.group(0)
                has_default = '=' in field_declaration
                
                if not has_default:
                    required.append(field_name)
                
                properties[field_name] = {
                    "type": openapi_type,
                }
            
            if properties:
                schema = {
                    "type": "object",
                    "properties": properties,
                }
                if required:
                    schema["required"] = required
                return schema
        
        return None

    def _generate_operation_id(self, path: str, method: HTTPMethod) -> str:
        """Generate operation ID from path and method."""
        # Remove leading slash and convert to camelCase
        path_parts = [p for p in path.split('/') if p and not p.startswith('{')]
        operation_id = method.value.lower() + ''.join(p.capitalize() for p in path_parts)
        return operation_id

