"""FastAPI parser."""

import ast
import re
from pathlib import Path
from typing import List, Optional, Dict, Any
from parsers.base import BaseParser
from core.models import (
    APIEndpoint,
    APIParameter,
    APIResponse,
    DiscoveryResult,
    FrameworkType,
    HTTPMethod,
    ParameterLocation,
)


class FastAPIParser(BaseParser):
    """Parser for FastAPI applications."""

    def parse(self) -> DiscoveryResult:
        """Parse FastAPI source files for API endpoints."""
        endpoints = []
        py_files = self.find_files("*.py")

        for py_file in py_files:
            content = self.read_file(py_file)
            if content and self._has_fastapi_imports(content):
                endpoints.extend(self._parse_file(py_file, content))

        return DiscoveryResult(
            framework=FrameworkType.FASTAPI,
            endpoints=endpoints,
            title="FastAPI",
        )

    def get_framework_type(self) -> FrameworkType:
        """Get the framework type."""
        return FrameworkType.FASTAPI

    def _has_fastapi_imports(self, content: str) -> bool:
        """Check if file imports FastAPI."""
        return "from fastapi import" in content or "import fastapi" in content

    def _parse_file(self, file_path: Path, content: str) -> List[APIEndpoint]:
        """Parse a Python file for FastAPI endpoints."""
        endpoints = []
        
        try:
            tree = ast.parse(content)
            
            # Find router and app variables
            routers = self._find_routers(tree)
            
            # Parse function decorators
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    endpoint = self._parse_function(node, content, file_path, routers)
                    if endpoint:
                        endpoints.append(endpoint)
        except SyntaxError as e:
            print(f"Syntax error parsing {file_path}: {e}")
        
        return endpoints

    def _find_routers(self, tree: ast.AST) -> Dict[str, str]:
        """Find router definitions and their prefixes."""
        routers = {}
        
        for node in ast.walk(tree):
            # Look for APIRouter(prefix="/path")
            if isinstance(node, ast.Assign):
                if isinstance(node.value, ast.Call):
                    if hasattr(node.value.func, 'attr') and node.value.func.attr == 'APIRouter':
                        # Extract router name
                        if node.targets:
                            router_name = node.targets[0].id if hasattr(node.targets[0], 'id') else None
                            # Extract prefix
                            prefix = self._extract_router_prefix(node.value)
                            if router_name and prefix:
                                routers[router_name] = prefix
        
        return routers

    def _extract_router_prefix(self, call_node: ast.Call) -> Optional[str]:
        """Extract prefix from APIRouter call."""
        for keyword in call_node.keywords:
            if keyword.arg == 'prefix':
                if isinstance(keyword.value, ast.Constant):
                    return keyword.value.value
        return None

    def _parse_function(
        self,
        func_node: ast.FunctionDef,
        content: str,
        file_path: Path,
        routers: Dict[str, str],
    ) -> Optional[APIEndpoint]:
        """Parse a function for FastAPI route decorator."""
        # Check decorators for HTTP methods
        for decorator in func_node.decorator_list:
            endpoint = self._parse_decorator(
                decorator,
                func_node,
                content,
                file_path,
                routers,
            )
            if endpoint:
                return endpoint
        
        return None

    def _parse_decorator(
        self,
        decorator: ast.AST,
        func_node: ast.FunctionDef,
        content: str,
        file_path: Path,
        routers: Dict[str, str],
    ) -> Optional[APIEndpoint]:
        """Parse a decorator for HTTP method and path."""
        # Handle app.get(), router.post(), etc.
        if isinstance(decorator, ast.Call):
            if hasattr(decorator.func, 'attr'):
                method_name = decorator.func.attr.upper()
                if method_name in ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']:
                    http_method = HTTPMethod[method_name]
                    
                    # Extract path
                    path = self._extract_path_from_decorator(decorator)
                    if not path:
                        path = f"/{func_node.name}"
                    
                    # Get router prefix if applicable
                    router_name = decorator.func.value.id if hasattr(decorator.func.value, 'id') else None
                    if router_name and router_name in routers:
                        path = routers[router_name].rstrip('/') + path
                    
                    # Normalize path
                    path = self.normalize_path(path)
                    
                    # Extract parameters
                    parameters = self._extract_parameters_from_function(func_node, path, content)
                    
                    # Extract request body
                    request_body = self._extract_request_body(func_node, path, content)
                    
                    # Extract response model
                    response_model = self._extract_response_model(decorator, func_node, content)
                    
                    # Create endpoint
                    return APIEndpoint(
                        path=path,
                        method=http_method,
                        summary=ast.get_docstring(func_node),
                        operation_id=func_node.name,
                        parameters=parameters,
                        request_body=request_body,
                        responses=[
                            APIResponse(
                                status_code=200,
                                description="Successful response",
                                schema=response_model,
                            )
                        ],
                        source_file=self.get_relative_path(file_path),
                        source_line=func_node.lineno,
                    )
        
        return None

    def _extract_path_from_decorator(self, decorator: ast.Call) -> Optional[str]:
        """Extract path from decorator arguments."""
        # First positional argument
        if decorator.args:
            if isinstance(decorator.args[0], ast.Constant):
                return decorator.args[0].value
        
        # Keyword argument 'path'
        for keyword in decorator.keywords:
            if keyword.arg == 'path':
                if isinstance(keyword.value, ast.Constant):
                    return keyword.value.value
        
        return None

    def _extract_response_model(
        self, decorator: ast.Call, func_node: ast.FunctionDef, content: str
    ) -> Optional[Dict[str, Any]]:
        """Extract response_model from decorator and return type."""
        # Check decorator for response_model
        response_model_name = None
        for keyword in decorator.keywords:
            if keyword.arg == 'response_model':
                if hasattr(keyword.value, 'id'):
                    response_model_name = keyword.value.id
                elif isinstance(keyword.value, ast.Subscript):
                    # Handle List[Model], Optional[Model], etc.
                    if hasattr(keyword.value.value, 'id'):
                        response_model_name = keyword.value.value.id
                    elif isinstance(keyword.value.value, ast.Name):
                        response_model_name = keyword.value.value.id
        
        # Check function return type annotation
        if not response_model_name and func_node.returns:
            response_model_name = self._extract_type_name(func_node.returns)
        
        if response_model_name:
            # Try to find the model definition
            schema = self._find_pydantic_model_schema(response_model_name, content)
            if schema:
                return schema
        
        return None

    def _extract_type_name(self, annotation: ast.AST) -> Optional[str]:
        """Extract type name from annotation."""
        if isinstance(annotation, ast.Name):
            return annotation.id
        elif isinstance(annotation, ast.Subscript):
            # Handle List[Model], Optional[Model], etc.
            if isinstance(annotation.value, ast.Name):
                if annotation.value.id in ['List', 'Optional', 'Union']:
                    if annotation.slice and hasattr(annotation.slice, 'value'):
                        if isinstance(annotation.slice.value, ast.Name):
                            return annotation.slice.value.id
                    elif annotation.slice and isinstance(annotation.slice, ast.Name):
                        return annotation.slice.id
        return None

    def _extract_parameters_from_function(
        self,
        func_node: ast.FunctionDef,
        path: str,
        content: str,
    ) -> List[APIParameter]:
        """Extract parameters from function signature."""
        parameters = []
        
        # Extract path parameters
        path_vars = self.extract_path_variables(path)
        
        # Analyze function arguments
        for i, arg in enumerate(func_node.args.args):
            arg_name = arg.arg
            
            # Skip 'self' and 'cls'
            if arg_name in ['self', 'cls']:
                continue
            
            # Check for FastAPI parameter annotations (Path, Query, Header, etc.)
            location, required, param_type = self._extract_fastapi_parameter_info(
                arg, arg_name, path_vars, func_node, content
            )
            
            if location != ParameterLocation.BODY:  # Body params are handled separately
                parameters.append(
                    APIParameter(
                        name=arg_name,
                        location=location,
                        required=required,
                        type=param_type,
                    )
                )
        
        return parameters

    def _extract_fastapi_parameter_info(
        self,
        arg: ast.arg,
        arg_name: str,
        path_vars: List[str],
        func_node: ast.FunctionDef,
        content: str,
    ) -> tuple:
        """Extract FastAPI parameter information."""
        # Default values
        location = ParameterLocation.QUERY
        required = True
        param_type = "string"
        
        # Check if it's a path parameter
        if arg_name in path_vars:
            location = ParameterLocation.PATH
            required = True
        else:
            # Check for FastAPI parameter annotations in function body or decorators
            # Look for Path(), Query(), Header(), etc. in the function signature context
            # This is a simplified approach - in practice, we'd need to analyze the AST more deeply
            required = self._is_parameter_required(arg, func_node)
        
        # Extract type annotation
        if arg.annotation:
            param_type = self._extract_type_annotation(arg.annotation)
        
        return location, required, param_type

    def _is_parameter_required(self, arg: ast.arg, func_node: ast.FunctionDef) -> bool:
        """Check if parameter is required (no default value)."""
        if not func_node.args.defaults:
            return True
        
        # Calculate index of this argument
        arg_index = func_node.args.args.index(arg)
        # Skip 'self' or 'cls' if present
        if func_node.args.args and func_node.args.args[0].arg in ['self', 'cls']:
            arg_index -= 1
        
        # Check if there's a default value for this argument
        defaults_start = len(func_node.args.args) - len(func_node.args.defaults)
        if arg_index < defaults_start:
            return True
        
        return False

    def _extract_request_body(
        self, func_node: ast.FunctionDef, path: str, content: str
    ) -> Optional[Dict[str, Any]]:
        """Extract request body from FastAPI function."""
        # Look for Pydantic model parameters (typically for POST/PUT/PATCH)
        path_vars = self.extract_path_variables(path)
        
        for arg in func_node.args.args:
            if arg.arg in ['self', 'cls']:
                continue
            
            # Check if parameter has a type annotation that looks like a Pydantic model
            if arg.annotation:
                type_name = self._extract_type_name(arg.annotation)
                if type_name:
                    # Check if it's not a path variable
                    if arg.arg not in path_vars:
                        # Try to find Pydantic model schema
                        schema = self._find_pydantic_model_schema(type_name, content)
                        if schema:
                            return {
                                "required": True,
                                "content": {
                                    "application/json": {
                                        "schema": schema,
                                    }
                                },
                            }
        
        return None

    def _find_pydantic_model_schema(self, model_name: str, content: str) -> Optional[Dict[str, Any]]:
        """Find Pydantic model definition and extract schema."""
        try:
            tree = ast.parse(content)
            
            # Look for class definition with BaseModel
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef) and node.name == model_name:
                    # Check if it inherits from BaseModel
                    for base in node.bases:
                        if isinstance(base, ast.Name) and base.id == 'BaseModel':
                            # Extract fields from the model
                            properties = {}
                            required = []
                            
                            for item in node.body:
                                if isinstance(item, ast.AnnAssign):
                                    if isinstance(item.target, ast.Name):
                                        field_name = item.target.id
                                        field_type = self._extract_type_annotation(item.annotation)
                                        
                                        # Check if field has default value
                                        if item.value is None:
                                            required.append(field_name)
                                        
                                        properties[field_name] = {
                                            "type": field_type,
                                        }
                            
                            if properties:
                                schema = {
                                    "type": "object",
                                    "properties": properties,
                                }
                                if required:
                                    schema["required"] = required
                                return schema
        except Exception:
            pass
        
        # Fallback: return object schema
        return {"type": "object"}

    def _extract_type_annotation(self, annotation: ast.AST) -> str:
        """Extract type from annotation."""
        if isinstance(annotation, ast.Name):
            type_map = {
                'int': 'integer',
                'float': 'number',
                'bool': 'boolean',
                'str': 'string',
                'dict': 'object',
                'list': 'array',
            }
            return type_map.get(annotation.id, 'string')
        elif isinstance(annotation, ast.Subscript):
            # Handle List[int], Dict[str, int], etc.
            if isinstance(annotation.value, ast.Name):
                if annotation.value.id == 'List':
                    return 'array'
                elif annotation.value.id == 'Dict':
                    return 'object'
        return 'string'

