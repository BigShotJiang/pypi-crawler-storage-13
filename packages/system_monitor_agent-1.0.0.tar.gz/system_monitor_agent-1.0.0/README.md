# System Monitor Agent

A lightweight telemetry agent for collecting system performance metrics (CPU, memory, disk, network) and sending them securely to a monitoring backend.

## Installation

```bash
pip install .
```

## Configuration
Edit the `.env` file:
```
BACKEND_URL=http://your-backend-server:5000/api/metrics
AUTH_TOKEN=your-agent-token
INTERVAL=10
QUEUE_LIMIT=50
```

## Usage
Run:
```bash
monitor-agent
```
