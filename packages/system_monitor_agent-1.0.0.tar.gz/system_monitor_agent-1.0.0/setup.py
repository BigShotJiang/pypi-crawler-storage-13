from setuptools import setup, find_packages

setup(
    name="system-monitor-agent",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "psutil>=5.9.0",
        "requests>=2.31.0",
        "python-dotenv>=1.0.0"
    ],
    entry_points={
        'console_scripts': [
            'monitor-agent=agent.collector:main'
        ],
    },
    author="Mohammad Sami Bhat",
    description="Lightweight telemetry agent for distributed system monitoring",
    license="MIT",
    python_requires='>=3.8'
)
