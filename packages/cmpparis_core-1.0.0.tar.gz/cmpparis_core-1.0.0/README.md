# cmpparis-core

Core utilities for cmpparis libraries.

## Installation

```bash
pip install cmpparis-core
```

## Features

- Error handling utilities
- File management helpers
- Common utility functions

## Usage

```python
from cmpparis_core import format_date, remove_diacritics
```
