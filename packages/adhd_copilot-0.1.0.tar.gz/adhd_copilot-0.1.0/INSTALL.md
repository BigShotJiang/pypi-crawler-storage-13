# 安裝指南

## 方法一：一行指令安裝（推薦）

最簡單的方式，不需要 clone 專案：

```bash
uvx adhd-copilot
```

### 如果還沒安裝 uv

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# 或使用 pip
pip install uv

# 或使用 Homebrew (macOS)
brew install uv
```

## 方法二：從原始碼安裝

```bash
# 1. Clone 專案
git clone https://github.com/richblack/ADHD-copilot.git
cd ADHD-copilot

# 2. 執行安裝腳本
chmod +x install.sh
./install.sh

# 3. 啟動服務
chmod +x run_service.sh
./run_service.sh
```

## 首次使用

1. 開啟瀏覽器訪問 `http://localhost:3001`
2. 選擇你現在的能量狀態（電力充足 / 低耗電模式）
3. 點擊右上角設定圖示 ⚙️
4. 輸入你的 [Gemini API Key](https://makersuite.google.com/app/apikey)（免費申請）
5. 設定專案主目錄（例如：`/Users/你的名字/Documents/projects`）
6. 開始對話！

## 取得 Gemini API Key

1. 前往 [Google AI Studio](https://makersuite.google.com/app/apikey)
2. 登入你的 Google 帳號
3. 點擊「Create API Key」
4. 複製 API Key（格式：`AIzaSy...`）
5. 貼到 ADHD Copilot 的設定中

免費額度：每分鐘 15 次請求，每天 1500 次請求（對個人使用綽綽有餘）

## 疑難排解

### uvx 找不到套件

如果 `uvx adhd-copilot` 失敗，可能是因為套件還沒發布到 PyPI。請使用方法二從原始碼安裝。

### 無法連接到 localhost:3001

確認沒有其他服務佔用 3001 port：

```bash
lsof -i :3001
```

如果有，可以修改 `rxconfig.py` 中的 port 設定。

### API Key 無效

確認：
1. API Key 格式正確（以 `AIzaSy` 開頭）
2. 已在 Google AI Studio 啟用 Gemini API
3. 沒有超過免費額度限制

## 更新

### 使用 uvx 安裝的版本

```bash
uvx --refresh adhd-copilot
```

### 從原始碼安裝的版本

```bash
cd ADHD-copilot
git pull
./run_service.sh
```
