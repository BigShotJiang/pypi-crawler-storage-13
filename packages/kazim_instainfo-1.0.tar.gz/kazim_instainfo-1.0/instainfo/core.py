import requests,instaloader
username = input(f'enter user : ')
def get_info():
    headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.8',
        'priority': 'u=1, i',
        'referer': 'https://www.instagram.com/{}/?__a=1'.format(username),
        'sec-ch-ua': '"Chromium";v="140", "Not=A?Brand";v="24", "Brave";v="140"',
        'sec-ch-ua-full-version-list': '"Chromium";v="140.0.0.0", "Not=A?Brand";v="24.0.0.0", "Brave";v="140.0.0.0"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-model': '""',
        'sec-ch-ua-platform': '"Windows"',
        'sec-ch-ua-platform-version': '"10.0.0"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'sec-gpc': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
        'x-asbd-id': '359341',
        'x-csrftoken': 'x2iSMy4TfpHQgb8TsCnyvu',
        'x-ig-app-id': '936619743392459',
        'x-ig-www-claim': '0',
        'x-requested-with': 'XMLHttpRequest',
        'x-web-device-id': 'DA13BB67-4458-4780-8A99-17DB92B17718',
        'x-web-session-id': 'gba5vd:4a2vce:sghd2l',

    }

    params = {
        'username': username,
    }

    response = requests.get(
        'https://www.instagram.com/api/v1/users/web_profile_info/',
        params=params,
        headers=headers,
    )
    try:
        data = response.json()['data']['user']
        bio = data['biography']
        followers = data['edge_followed_by']['count']
        following = data['edge_follow']['count']
        name = data['full_name']
        bussiness = data['is_business_account']
        id = data['id']
        private = data['is_private']
        verf = data['is_verified']
        photo = data['profile_pic_url']
        messages=f"""
    ________________[HIT]________________
    username : {params['username']}
    bio : {bio}
    followers : {followers}
    following : {following}
    name : {name}
    bussiness : {bussiness}
    id : {id}
    url : {photo}
    private : {private}
    verification : {verf}
    ________________[HIT]________________
        """
        print(messages)
    except:
        messages=f"""
    ________________[HIT]________________
    username : {params['username']}
    ________________[HIT]________________
        """
        print(messages)
get_info()