from setuptools import setup, find_packages

setup(
    name="kazim_instainfo",
    version="1.0",
    packages=find_packages(),
    install_requires=["requests", "instaloader"],
    description="Instagram info library",
    author="ITSH",
)
