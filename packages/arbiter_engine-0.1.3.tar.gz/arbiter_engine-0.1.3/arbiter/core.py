from __future__ import annotations

from typing import List, Sequence, Tuple

from .api import compare


def iter(
    query: str,
    candidates: Sequence[str],
    use_freq: bool = True,
    top_k: int | None = None,
) -> List[Tuple[str, float]]:
    """
    Syntactic sugar for the standard ARBITER compare operation.
    Mirrors the CLI and top-level API and returns sorted (candidate, score) tuples.
    """

    resp = compare(query, list(candidates), use_freq=use_freq, top_k=top_k or len(candidates))
    return [(item.text, item.score) for item in resp.all]
