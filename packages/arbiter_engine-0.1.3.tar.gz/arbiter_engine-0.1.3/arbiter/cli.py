import argparse

from .core import iter


def main():
    parser = argparse.ArgumentParser(prog="arb", description="Arbiter coherence CLI.")
    parser.add_argument("query", help="Query text to evaluate.")
    parser.add_argument("candidates", nargs="+", help="Candidate completions to score.")
    args = parser.parse_args()

    results = iter(args.query, args.candidates)

    print(f"\nQuery: {args.query}\n")
    for text, score in results:
        print(f"{score:0.3f}  {text}")


if __name__ == "__main__":
    main()
