from __future__ import annotations

import os
from dataclasses import dataclass
from typing import List, Optional

import requests

PRIVATE_API_URL = "https://api.arbiter.traut.ai/v1/compare"
PUBLIC_API_URL = "https://api.arbiter.traut.ai/public/compare"


@dataclass
class CompareItem:
    text: str
    score: float


@dataclass
class CompareResponse:
    query: str
    top: List[CompareItem]
    all: List[CompareItem]


def compare(
    query: str,
    candidates: List[str],
    use_freq: bool = True,
    top_k: Optional[int] = None,
    key: Optional[str] = None,
    timeout: int = 10,
) -> CompareResponse:
    """Call the Arbiter compare API and structure the response."""
    payload = {
        "query": query,
        "candidates": list(candidates),
        "top_k": top_k or len(candidates),
        "use_freq": use_freq,
    }

    api_key = key or os.getenv("ARBITER_API_KEY")
    url = PRIVATE_API_URL if api_key else PUBLIC_API_URL
    headers = {"Authorization": f"Bearer {api_key}"} if api_key else None

    response = requests.post(url, json=payload, headers=headers, timeout=timeout)
    response.raise_for_status()
    data = response.json()

    def _map(items):
        return [
            CompareItem(text=item["text"], score=float(item["score"]))
            for item in items
        ]

    all_items = _map(data.get("all", []))
    top_items = _map(data.get("top", [])) or all_items[: payload["top_k"]]

    return CompareResponse(
        query=data.get("query", query),
        top=top_items,
        all=all_items,
    )


def api_iter(query, candidates, key):
    """Legacy helper maintained for backwards compatibility."""
    resp = compare(query, list(candidates), key=key)
    return [(item.text, item.score) for item in resp.all]
