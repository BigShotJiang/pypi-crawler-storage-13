"""Local fallback routes through the public Arbiter API."""

from __future__ import annotations

import requests

API_URL = "https://api.arbiter.traut.ai/public/compare"


def local_iter(query, candidates):
    payload = {
        "query": query,
        "candidates": list(candidates),
        "use_freq": True,
        "top_k": len(candidates),
    }

    response = requests.post(API_URL, json=payload, timeout=10)
    response.raise_for_status()
    data = response.json()

    return [(item["text"], item["score"]) for item in data["all"]]
