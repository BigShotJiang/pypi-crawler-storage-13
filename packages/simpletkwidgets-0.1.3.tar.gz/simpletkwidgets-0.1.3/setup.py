from setuptools import setup, find_packages

setup(
    name='simpletkwidgets', 
    version='0.1.3', 
    packages=find_packages(),
    install_requires=[],
    description='A simple wrapper for Tkinter widgets, ideal for beginners.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='superprogrammer',
    author_email='superprogrammer22@gmail.com',
    url='https://github.com/superprogrammer22-modules/simpletkwidgets',
    license='MIT',
    classifiers=[ 
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Topic :: Software Development :: User Interfaces',
    ],
)
