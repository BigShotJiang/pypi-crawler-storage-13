# simpletkwidgets
### 🚀 Finally, GUI Made Easy!

Hey! I'm **The Super Programmer**, and this is my new module, `simpletkwidgets`! 👋

Are you struggling to use **Tkinter** for simple GUI creation? This wrapper is for you! Add buttons, labels, entry boxes, and tabs with just single-line functions. Focus on your application logic, not complex widget syntax!

## 💾 Installation

You can install `simpletkwidgets` directly using pip:

```bash
pip install simpletkwidgets

```markdown
## ✨ Quick Start Example

Compare the complexity of native Tkinter vs. `simpletkwidgets` to build a button that greets the user:

```python
import tkinter as tk
from simpletkwidgets import button, entry, get_entry_data

# 1. Setup the main window
root = tk.Tk()
root.title("Simplicity Test")

# 2. Add an input field and store its variable
name_var = entry(root, "Enter your name...", width_setting=30)

# 3. Add a button that uses the input data
def show_greeting():
    name = get_entry_data(name_var)
    messagebox.showinfo("Result", f"Hello, {name}!")

button(root, 
       "Say Hello!", 
       what_to_do=show_greeting, 
       background_color="purple", 
       font_color="white")

root.mainloop()

```

```markdown
## 📢 Spread the Word!

Want to see how simple it is? 
* **Documentation:** Check out the official package page on **PyPI** for full details: [pypi.org/project/simpletkwidgets/](https://pypi.org/project/simpletkwidgets/)
* **Video Tutorials:** [Add your YouTube/TikTok link here when you make the video!]

## ⚖️ License

This project is licensed under the MIT 