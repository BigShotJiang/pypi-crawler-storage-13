"""
视频读取工具模块

提供从视频文件读取帧的功能，用于离线模式数据收集
"""

import cv2
import numpy as np
from typing import Generator, Optional, Tuple
from pathlib import Path


class VideoReader:
    """
    视频读取器

    用于从视频文件逐帧读取，支持帧率控制和跳帧采样

    示例:
        reader = VideoReader('moive/1.mp4', frame_interval=2)
        for frame_idx, frame in reader:
            print(f"Frame {frame_idx}: {frame.shape}")
    """

    def __init__(
        self,
        video_path: str,
        frame_interval: int = 0,
        target_fps: Optional[int] = None,
        interval: Optional[float] = None,
        start_frame: int = 0,
        max_frames: Optional[int] = None
    ):
        """
        初始化视频读取器

        参数:
            video_path: 视频文件路径
            frame_interval: 帧间隔，0表示读取所有帧，1表示每隔1帧读取一次
            target_fps: 目标帧率（如果指定，会根据原始帧率自动计算帧间隔）
            interval: 采样间隔（秒），如果指定，会根据视频帧率自动计算帧间隔
            start_frame: 起始帧索引
            max_frames: 最大读取帧数（None表示读取到视频结束）
        """
        self.video_path = Path(video_path)
        if not self.video_path.exists():
            raise FileNotFoundError(f"Video file not found: {video_path}")

        self.frame_interval = frame_interval
        self.start_frame = start_frame
        self.max_frames = max_frames

        # 打开视频
        self.cap = cv2.VideoCapture(str(self.video_path))
        if not self.cap.isOpened():
            raise RuntimeError(f"Failed to open video: {video_path}")

        # 获取视频信息
        self.original_fps = self.cap.get(cv2.CAP_PROP_FPS)
        self.frame_count = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.frame_width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.frame_height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        # 优先级: interval > target_fps > frame_interval
        if interval is not None:
            # 根据间隔时间计算跳帧数
            self.frame_interval = int(self.original_fps * interval) - 1
            if self.frame_interval < 0:
                self.frame_interval = 0
            print(f"Auto-calculated frame_interval={self.frame_interval} for interval={interval}s")
        elif target_fps is not None and target_fps < self.original_fps:
            # 如果指定了目标帧率，自动计算跳帧
            self.frame_interval = int(self.original_fps / target_fps) - 1
            print(f"Auto-calculated frame_interval={self.frame_interval} for target_fps={target_fps}")

        self.current_frame_idx = 0
        self.frames_read = 0

        print(f"Video loaded: {self.video_path.name}")
        print(f"  - Resolution: {self.frame_width}x{self.frame_height}")
        print(f"  - FPS: {self.original_fps:.2f}")
        print(f"  - Total frames: {self.frame_count}")
        print(f"  - Frame interval: {self.frame_interval} (every {self.frame_interval+1} frames)")

    def __iter__(self) -> Generator[Tuple[int, np.ndarray], None, None]:
        """
        迭代器接口

        生成:
            (frame_index, frame): 帧索引和帧数据
        """
        # 跳转到起始帧
        if self.start_frame > 0:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, self.start_frame)
            self.current_frame_idx = self.start_frame

        while True:
            # 检查是否达到最大帧数
            if self.max_frames is not None and self.frames_read >= self.max_frames:
                break

            # 读取帧
            ret, frame = self.cap.read()
            if not ret:
                break

            frame_idx = self.current_frame_idx
            self.current_frame_idx += 1

            # 跳帧处理
            if self.frame_interval > 0:
                # 跳过接下来的N帧
                for _ in range(self.frame_interval):
                    ret = self.cap.grab()  # grab()比read()快，只解码不返回
                    self.current_frame_idx += 1
                    if not ret:
                        break

            self.frames_read += 1
            yield frame_idx, frame

    def read_frame(self) -> Optional[Tuple[int, np.ndarray]]:
        """
        读取单帧

        返回:
            (frame_index, frame) 或 None（视频结束）
        """
        try:
            return next(iter(self))
        except StopIteration:
            return None

    def seek(self, frame_idx: int):
        """
        跳转到指定帧

        参数:
            frame_idx: 目标帧索引
        """
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
        self.current_frame_idx = frame_idx

    def reset(self):
        """重置到视频开头"""
        self.seek(self.start_frame)
        self.frames_read = 0

    def close(self):
        """关闭视频文件"""
        if self.cap is not None:
            self.cap.release()

    def __del__(self):
        """析构函数，确保资源释放"""
        self.close()

    def __enter__(self):
        """上下文管理器入口"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器退出"""
        self.close()

    def get_info(self) -> dict:
        """
        获取视频信息

        返回:
            包含视频元数据的字典
        """
        return {
            'path': str(self.video_path),
            'fps': self.original_fps,
            'frame_count': self.frame_count,
            'width': self.frame_width,
            'height': self.frame_height,
            'duration_seconds': self.frame_count / self.original_fps if self.original_fps > 0 else 0,
            'frame_interval': self.frame_interval,
            'effective_fps': self.original_fps / (self.frame_interval + 1)
        }


class VideoWriter:
    """
    视频写入器

    用于保存帧序列为视频文件（可选功能，用于调试或可视化）

    示例:
        writer = VideoWriter('output.mp4', fps=30, frame_size=(640, 480))
        for frame in frames:
            writer.write(frame)
        writer.close()
    """

    def __init__(
        self,
        output_path: str,
        fps: int = 30,
        frame_size: Tuple[int, int] = (640, 480),
        fourcc: str = 'mp4v'
    ):
        """
        初始化视频写入器

        参数:
            output_path: 输出视频路径
            fps: 帧率
            frame_size: 帧大小 (width, height)
            fourcc: 编码器 ('mp4v', 'XVID', 'H264'等)
        """
        self.output_path = output_path
        self.fps = fps
        self.frame_size = frame_size

        # 创建VideoWriter
        fourcc_code = cv2.VideoWriter_fourcc(*fourcc)
        self.writer = cv2.VideoWriter(
            output_path,
            fourcc_code,
            fps,
            frame_size
        )

        if not self.writer.isOpened():
            raise RuntimeError(f"Failed to create video writer: {output_path}")

        print(f"VideoWriter initialized: {output_path}")

    def write(self, frame: np.ndarray):
        """
        写入一帧

        参数:
            frame: 图像帧，shape=(H, W, 3)
        """
        # 确保帧大小匹配
        if frame.shape[:2][::-1] != self.frame_size:
            frame = cv2.resize(frame, self.frame_size)

        self.writer.write(frame)

    def close(self):
        """关闭写入器"""
        if self.writer is not None:
            self.writer.release()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


if __name__ == '__main__':
    # 测试代码
    import sys

    if len(sys.argv) > 1:
        video_path = sys.argv[1]
    else:
        video_path = 'moive/1.mp4'

    print(f"Testing VideoReader with: {video_path}")

    try:
        with VideoReader(video_path, frame_interval=30, max_frames=10) as reader:
            # 打印视频信息
            info = reader.get_info()
            print("\nVideo Info:")
            for key, value in info.items():
                print(f"  {key}: {value}")

            # 读取几帧
            print("\nReading frames...")
            for frame_idx, frame in reader:
                print(f"  Frame {frame_idx}: shape={frame.shape}")

    except FileNotFoundError as e:
        print(f"Error: {e}")
        print("Please provide a valid video path")
