"""
图像预处理工具模块

提供图像处理相关的工具函数
"""

import cv2
import numpy as np
from typing import List, Tuple, Optional


def resize_frame(frame: np.ndarray, width: int, height: int) -> np.ndarray:
    """
    调整图像大小

    参数:
        frame: 输入图像，shape=(H, W, C) 或 (H, W)
        width: 目标宽度
        height: 目标高度

    返回:
        调整后的图像，shape=(height, width, C) 或 (height, width)
    """
    return cv2.resize(frame, (width, height), interpolation=cv2.INTER_AREA)


def to_grayscale(frame: np.ndarray) -> np.ndarray:
    """
    转换为灰度图

    参数:
        frame: RGB或BGR图像，shape=(H, W, 3)

    返回:
        灰度图像，shape=(H, W)
    """
    if len(frame.shape) == 2:
        # 已经是灰度图
        return frame

    # OpenCV默认是BGR格式
    return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


def normalize(frame: np.ndarray) -> np.ndarray:
    """
    归一化到[0, 1]

    参数:
        frame: 输入图像，dtype=uint8

    返回:
        归一化后的图像，dtype=float32，范围[0, 1]
    """
    return frame.astype(np.float32) / 255.0


def stack_frames(frames: List[np.ndarray]) -> np.ndarray:
    """
    堆叠多帧图像

    参数:
        frames: 帧列表，每个元素shape=(H, W)

    返回:
        堆叠后的图像，shape=(num_frames, H, W)
    """
    return np.stack(frames, axis=0)


def preprocess_frame(
    frame: np.ndarray,
    train_resolution: List[int],
    normalize_img: bool = True
) -> np.ndarray:
    """
    完整的帧预处理流程，用于训练和推理

    返回格式：CHW (Channels, Height, Width)，可直接用于 PyTorch 模型

    参数:
        frame: 原始帧，shape=(H, W, C) 或 (H, W)
        train_resolution: [height, width, channels] 目标分辨率和通道数
        normalize_img: 是否归一化到[0, 1]

    返回:
        预处理后的帧，CHW格式
        - 灰度图: shape=(1, height, width), dtype=float32 (如果normalize) 或 uint8
        - RGB图: shape=(3, height, width), dtype=float32 (如果normalize) 或 uint8
    """
    height, width, channels = train_resolution
    processed = frame

    # 调整大小
    if processed.shape[0] != height or processed.shape[1] != width:
        processed = resize_frame(processed, width, height)

    # 通道转换
    if channels == 1 and len(processed.shape) == 3:
        processed = to_grayscale(processed)
    elif channels == 3 and len(processed.shape) == 2:
        processed = cv2.cvtColor(processed, cv2.COLOR_GRAY2BGR)

    # 归一化
    if normalize_img:
        processed = normalize(processed)

    # 转换为 CHW 格式
    if len(processed.shape) == 2:
        # Grayscale: (H, W) -> (1, H, W)
        processed = np.expand_dims(processed, axis=0)
    else:
        # RGB: (H, W, C) -> (C, H, W)
        processed = np.transpose(processed, (2, 0, 1))

    return processed


class FrameBuffer:
    """
    帧缓冲区，用于堆叠多帧作为状态

    示例:
        # 灰度图模式
        buffer = FrameBuffer(stack_size=4, frame_shape=(84, 84))
        for frame in video:
            stacked = buffer.add_frame(frame)  # shape=(4, 84, 84)

        # RGB模式
        buffer = FrameBuffer(stack_size=4, frame_shape=(540, 960, 3))
        for frame in video:
            stacked = buffer.add_frame(frame)  # shape=(4, 540, 960, 3)
    """

    def __init__(self, stack_size: int, frame_shape: Tuple[int, ...]):
        """
        初始化帧缓冲区

        参数:
            stack_size: 堆叠帧数
            frame_shape: 单帧的形状 (H, W) 或 (H, W, C)
        """
        self.stack_size = stack_size
        self.frame_shape = frame_shape
        self.buffer: List[np.ndarray] = []

    def reset(self):
        """清空缓冲区"""
        self.buffer = []

    def add_frame(self, frame: np.ndarray) -> Optional[np.ndarray]:
        """
        添加一帧到缓冲区

        参数:
            frame: 预处理后的帧，shape=(H, W) 或 (H, W, C)

        返回:
            如果缓冲区已满，返回堆叠后的帧
            - 灰度图: shape=(stack_size, H, W)
            - RGB图: shape=(stack_size, H, W, C)
            否则返回None
        """
        self.buffer.append(frame)

        # 保持缓冲区大小
        if len(self.buffer) > self.stack_size:
            self.buffer.pop(0)

        # 缓冲区未满，返回None或重复第一帧填充
        if len(self.buffer) < self.stack_size:
            # 初始阶段：重复当前帧填充
            return stack_frames([frame] * self.stack_size)

        # 缓冲区已满，返回堆叠帧
        return stack_frames(self.buffer)

    def get_state(self) -> Optional[np.ndarray]:
        """
        获取当前状态（堆叠帧）

        返回:
            shape=(stack_size, H, W) 或 None
        """
        if len(self.buffer) < self.stack_size:
            return None
        return stack_frames(self.buffer)


def visualize_frame(frame: np.ndarray, window_name: str = 'Frame', wait_key: int = 1):
    """
    可视化帧（调试用）

    参数:
        frame: 图像帧
        window_name: 窗口名称
        wait_key: 等待时间（毫秒），0表示等待按键
    """
    # 如果是归一化的图像，恢复到0-255
    if frame.dtype == np.float32 or frame.dtype == np.float64:
        display_frame = (frame * 255).astype(np.uint8)
    else:
        display_frame = frame

    cv2.imshow(window_name, display_frame)
    cv2.waitKey(wait_key)


def save_frame(frame: np.ndarray, filepath: str):
    """
    保存帧到文件

    参数:
        frame: 图像帧
        filepath: 保存路径
    """
    # 如果是归一化的图像，恢复到0-255
    if frame.dtype == np.float32 or frame.dtype == np.float64:
        save_frame = (frame * 255).astype(np.uint8)
    else:
        save_frame = frame

    cv2.imwrite(filepath, save_frame)
    print(f"Frame saved to {filepath}")


if __name__ == '__main__':
    # 测试代码
    print("Testing image_processing module...")

    # 测试预处理 - RGB转灰度并resize
    dummy_frame = np.random.randint(0, 255, (1920, 1080, 3), dtype=np.uint8)
    train_resolution = [540, 960, 1]  # 灰度图
    processed = preprocess_frame(dummy_frame, train_resolution)
    print(f"RGB->Gray: shape={processed.shape}, dtype={processed.dtype}, range=[{processed.min():.3f}, {processed.max():.3f}]")
    print(f"  Expected shape: (1, 540, 960), Got: {processed.shape}")

    # 测试预处理 - RGB保持RGB并resize
    train_resolution = [540, 960, 3]  # RGB图
    processed = preprocess_frame(dummy_frame, train_resolution)
    print(f"RGB->RGB: shape={processed.shape}, dtype={processed.dtype}, range=[{processed.min():.3f}, {processed.max():.3f}]")
    print(f"  Expected shape: (3, 540, 960), Got: {processed.shape}")

    # 测试不normalize
    processed = preprocess_frame(dummy_frame, train_resolution, normalize_img=False)
    print(f"No normalize: shape={processed.shape}, dtype={processed.dtype}, range=[{processed.min()}, {processed.max()}]")
    print(f"  Expected shape: (3, 540, 960), Got: {processed.shape}")

    # 测试帧缓冲区
    buffer = FrameBuffer(stack_size=4, frame_shape=(84, 84))
    for i in range(5):
        frame = np.random.rand(84, 84).astype(np.float32)
        stacked = buffer.add_frame(frame)
        if stacked is not None:
            print(f"Iteration {i}: Stacked frame shape: {stacked.shape}")

    print("All tests passed!")
