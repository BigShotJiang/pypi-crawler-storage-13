# autowzry_lite 构建说明

## 项目说明

autowzry_lite 是从完整版 autowzry 库精简提取的版本，仅保留图像识别和移动控制核心功能。

**从完整版移除**：游戏自动化流程（打金、任务、匹配等200+函数）、活动系统、组队系统等。

**保留功能**：6个lite识别函数、3个对战控制函数、必要的图片资源（约20-40个）。

## 目录结构

```
autowzry_lite/
├── README.md                          # 本文件
├── BUILD_PRINCIPLES.md                # 构建核心原则
├── AGENT_BUILD_GUIDE.md               # Agent构建详细步骤
├── build_log.txt                      # 构建日志（构建后生成）
└── autowzry/                          # 精简后的包目录
    ├── __init__.py
    ├── wzry.py                        # 精简后的核心文件
    ├── version.py                     # 版本信息
    └── assets/                        # 图片资源目录
        ├── tpl*.png                   # 对战检测图片
        └── android.960.540.dict.yaml  # 分辨率配置
```

## 构建方法

### 方法1：使用AI Agent构建（推荐）

**优势**：智能适应代码变化，无需调试解析逻辑，兼容性更好。

**操作步骤**：

1. 打开 Claude Code 或其他 AI Agent
2. 发送以下指令：

```
按照 autowzry_lite/AGENT_BUILD_GUIDE.md 的步骤，
遵守 autowzry_lite/BUILD_PRINCIPLES.md 的原则，
构建 autowzry_lite
```

3. Agent 将自动执行构建，包括：
   - 从 `D:/SoftData/git/autowzry` 提取代码
   - 精简类和函数
   - 复制图片资源
   - 生成版本文件和构建日志

4. 查看 `build_log.txt` 确认构建结果

**Agent协作规范**（遵守 docs/guides/AGENT_COLLABORATION_RULES.md）：
- Agent 在构建前会先总结理解的任务，等待确认
- 使用 TodoWrite 跟踪15个构建步骤的进度
- 每完成一步立即更新状态
- 构建完成后汇报结果（提取了多少函数、多少图片）

### 方法2：手动构建

参考 `BUILD_PRINCIPLES.md` 中的规则手动提取代码。

**不推荐**：工作量大，容易遗漏依赖。

## 更新流程

当完整版 autowzry 更新时：

**使用Agent重新构建**：
```
按照 autowzry_lite/AGENT_BUILD_GUIDE.md 的步骤，
遵守 autowzry_lite/BUILD_PRINCIPLES.md 的原则，
构建 autowzry_lite
```

Agent 会：
1. 自动检测新的 lite 函数（如果有）
2. 识别函数名或位置变化
3. 更新图片资源列表
4. 生成新的构建日志

**查看变化**：
```
比较新旧 build_log.txt，查看：
- 新增或移除的函数
- 新增或移除的图片
- 版本信息变化
```

## 文档说明

### BUILD_PRINCIPLES.md - 核心原则

定义构建的核心原则：
- 功能完整性：保留的功能必须完整可用
- 最小依赖：只保留必要的代码
- 依赖外部化：不复制外部库
- 保持兼容性：与 autowzry-agent 兼容
- 版本可追溯：记录版本和构建信息

详细说明了：
- 需要保留的内容（函数、类、图片）
- 需要移除的内容
- 代码组织结构
- 智能判断规则
- 特殊情况处理

### AGENT_BUILD_GUIDE.md - Agent操作指南

提供给AI Agent的详细操作步骤：
- 15个构建步骤的详细说明
- 每步的具体操作和注意事项
- 智能提取方法
- 错误处理策略
- 验证清单

Agent读取此文档后可以自动完成构建，无需人工干预。

## 版本信息

- **lite版本**: 基于 autowzry 最新版本提取
- **提取日期**: 见 `autowzry/version.py` 中的 `lite_build_time`
- **源版本**: 见 `autowzry/version.py` 中的 `lite_source_version`
- **包含函数**: 见 `build_log.txt`

## 常见问题

### Q: 为什么使用Agent构建而非Python脚本？

A: Agent有以下优势：
- **适应变化**：代码结构变化时自动调整策略
- **智能理解**：理解代码语义，不依赖固定行号
- **零调试**：无需处理解析错误和边界情况
- **灵活性**：可以处理新增函数、重命名等情况

### Q: 构建失败怎么办？

A:
1. 查看Agent的错误提示
2. 检查源路径是否正确：`D:/SoftData/git/autowzry`
3. 确认源文件存在：`autowzry/wzry.py`、`autowzry/version.py`
4. 向Agent提供错误信息，它会调整策略重试

### Q: 如何验证构建结果？

A:
1. 检查 `build_log.txt` 确认提取了所有必要函数
2. 在 autowzry-agent 项目中测试导入：
   ```python
   import sys
   sys.path.insert(0, 'autowzry_lite')
   from autowzry.wzry import wzry_task
   task = wzry_task(connect=False)
   ```
3. 验证 lite 函数可以调用

### Q: 构建日志在哪里？

A: `autowzry_lite/build_log.txt`

包含：
- 构建时间和源版本
- 提取的函数列表（约12个）
- 复制的图片列表（约20-40个）
- 复制的配置文件

## 依赖项

autowzry_lite 依赖以下外部库（需单独安装）：

```bash
pip install airtest_mobileauto
```

包含的组件：
- ImageDetector - 图像检测器
- MotionDetector - 移动方向检测器
- Template - 图片模板类
- deviceOB - 设备控制类
- Settings - 配置管理

这些库是开放的，不包含在lite版本中。
