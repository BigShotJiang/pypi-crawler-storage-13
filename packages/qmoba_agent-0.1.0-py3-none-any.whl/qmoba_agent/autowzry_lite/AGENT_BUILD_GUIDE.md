# Agent 构建 autowzry_lite 操作指南

## 文档说明

本文档供 AI Agent（如 Claude Code）阅读，用于从完整版 autowzry 提取精简版 autowzry_lite。

**为什么使用 Agent 而非固定脚本？**
- autowzry 代码会持续更新，函数位置、名称可能变化
- 图片文件名可能更新
- 依赖关系可能调整
- Agent 能够智能理解代码结构，自动适应这些变化
- 无需调试复杂的解析逻辑

## 调用方式

用户会说：
```
按照 autowzry_lite/AGENT_BUILD_GUIDE.md 的步骤，
遵守 autowzry_lite/BUILD_PRINCIPLES.md 的原则，
构建 autowzry_lite
```

你应该：
1. 阅读本文档（AGENT_BUILD_GUIDE.md）了解详细步骤
2. 阅读 BUILD_PRINCIPLES.md 了解核心原则
3. 按步骤执行构建任务

## 路径配置

```
源目录: D:/SoftData/git/autowzry/autowzry/
目标目录: D:/SoftData/git/autowzry-agent/autowzry_lite/autowzry/
日志文件: D:/SoftData/git/autowzry-agent/autowzry_lite/build_log.txt
```

## 构建步骤

### 步骤0：准备工作

**创建 TodoWrite 任务列表**，包含以下任务：
1. 读取源文件获取版本信息
2. 提取 wzry.py 文件头部（import和许可证）
3. 提取工具函数（版本号、项目介绍等）
4. 提取并精简 wzry_figure 类
5. 提取并精简 wzry_task 类的 __init__ 方法
6. 提取 lite 识别函数（6个）
7. 提取对战控制函数（3个）
8. 提取辅助函数（check_run_status等）
9. 从代码中识别需要的图片文件
10. 复制图片资源到 assets 目录
11. 复制配置文件
12. 生成 version.py
13. 生成 __init__.py
14. 生成构建日志

**初始化构建日志变量**：
- 提取的函数列表（记录函数名）
- 复制的图片列表（记录文件名）
- 源版本信息
- 构建时间

### 步骤1：读取源文件信息

**目标**：获取源代码版本和基本信息

**操作**：
```
1. 读取 D:/SoftData/git/autowzry/autowzry/version.py
2. 提取最后一行的 last_modified 值作为源版本
3. 记录到构建日志
4. 标记 Todo #1 为 completed
```

**注意事项**：
- version.py 有多行 last_modified，取最后一行
- 提取格式：`last_modified = "2025-11-19 13:31:53"`

### 步骤2：提取文件头部

**目标**：保留 import 语句和文件说明

**操作**：
```
1. 读取 D:/SoftData/git/autowzry/autowzry/wzry.py
2. 从文件开头提取到第一个 class 或 def 定义之前的所有内容
3. 这部分包括：
   - 文件编码声明（#!/usr/bin/env python3 等）
   - import 语句（from airtest_mobileauto import ...）
   - 许可证声明（如果有）
   - 全局变量定义（updata_time1 等）
4. 保存到输出缓冲区
5. 标记 Todo #2 为 completed
```

**注意事项**：
- 完整保留所有 import 语句，不要修改
- 保留 try-except ImportError 块
- 保留全局变量定义

### 步骤3：提取工具函数

**目标**：提取独立的工具函数

**需要提取的函数**：
- `版本号(判断版本=False, delta_days=30)` - 版本检查函数
- `项目介绍()` - 项目信息显示

**操作**：
```
1. 在 wzry.py 中搜索 "def 版本号"
2. 提取完整函数体（从 def 行到下一个同级 def 或 class 之前）
3. 在 wzry.py 中搜索 "def 项目介绍"
4. 提取完整函数体
5. 添加到输出缓冲区，前面加注释 "# ==================== 工具函数 ===================="
6. 记录到构建日志：提取的函数列表
7. 标记 Todo #3 为 completed
```

**智能提取方法**：
- 使用 Read 工具读取文件，使用 Grep 搜索函数名
- 函数结束判断：遇到同级或更外层的 def/class 定义
- 包含函数的文档字符串和所有注释

### 步骤4：提取并精简 wzry_figure 类

**目标**：提取图片元素类，但只保留必要的图片定义

**需要保留的属性**（完整列表见 BUILD_PRINCIPLES.md）：
- 对战检测相关：普攻、移动、钱袋、对战图片元素等
- 界面判断相关：大厅元素、房间元素、战绩页面元素等

**操作**：
```
1. 在 wzry.py 中搜索 "class wzry_figure"
2. 提取整个类定义（从 class 行到下一个 class 之前）
3. 保留类定义、__init__ 方法签名、文档字符串
4. 在 __init__ 方法内部：
   - 保留所有非 self.xxx = 的代码（如 current_dir、assets_dir 等）
   - 保留 BUILD_PRINCIPLES.md 中列出的图片属性定义
   - 删除其他图片属性定义（如活动、礼包、匹配相关）
5. 添加到输出缓冲区，前面加注释 "# ==================== 图片元素类（精简版） ===================="
6. 标记 Todo #4 为 completed
```

**智能过滤方法**：
- 不要手动判断每一行，使用语义理解
- 查看 BUILD_PRINCIPLES.md 中的保留列表
- 如果不确定某个属性是否需要，检查后续的 lite 函数是否使用它
- 保留所有的列表定义（如 self.对战图片元素 = []）及其 append 语句

**简化版 wzry_runinfo 类**：
```
在 wzry_figure 类之前添加简化的 wzry_runinfo：

class wzry_runinfo:
    def __init__(self):
        self._starttime = time.time()
```

### 步骤5：提取 wzry_task 类的 __init__ 方法

**目标**：提取类定义和初始化方法

**操作**：
```
1. 在 wzry.py 中搜索 "class wzry_task"
2. 提取类定义行和文档字符串
3. 提取 __init__ 方法的完整定义
4. __init__ 方法包括：
   - 方法签名：def __init__(self, connect=True)
   - assets_dir 设置
   - 设备连接相关初始化（self.移动端 = deviceOB(...)）
   - Tool、图片、APPOB 等对象初始化
5. 在 __init__ 方法结束后停止（不提取其他方法）
6. 添加到输出缓冲区，前面加注释 "# ==================== 主任务类（精简版） ===================="
7. 标记 Todo #5 为 completed
```

**注意事项**：
- __init__ 方法可能很长（100+ 行），需要完整提取
- 包含多个条件判断（if connect: ...）都要保留
- 停止条件：遇到下一个 def 方法定义

### 步骤6：提取 lite 识别函数

**目标**：提取6个核心识别函数

**需要提取的函数**（搜索关键字）：
1. `def lite_连接设备(self)`
2. `def lite_当前画面(self)`
3. `def lite_判断对战(self, screen=None)`
4. `def lite_判断死亡(self, img=None)`
5. `def lite_判断移动方向(self, img1=None, img2=None, custom_regions=None, figpath=None)`
6. `def lite_判断当前界面(self, only_norm=True)`

**操作**：
```
1. 在输出缓冲区添加注释：
   "\n    # ==================== lite识别函数 ====================\n"
2. 对于每个函数：
   a. 在 wzry.py 中搜索函数定义（用 Grep 工具）
   b. 提取完整函数体（包括文档字符串、注释、所有代码）
   c. 添加到输出缓冲区
   d. 记录到构建日志
3. 标记 Todo #6 为 completed
```

**智能识别方法**：
- 这些函数都是 wzry_task 类的方法，注意缩进
- 函数可能很长（lite_判断死亡 有40多行）
- 完整保留函数内的所有逻辑，包括注释

### 步骤7：提取对战控制函数

**目标**：提取3个控制函数

**需要提取的函数**：
1. `def 对战中_移动(self, angle=0.0, duration=1)`
2. `def 对战中_攻击(self, index=0)`
3. `def 对战中_信号(self, index=0)`

**操作**：
```
1. 在输出缓冲区添加注释：
   "\n    # ==================== 对战控制函数 ====================\n"
2. 对于每个函数：
   a. 在 wzry.py 中搜索函数名
   b. 提取完整函数体
   c. 添加到输出缓冲区
   d. 记录到构建日志
3. 标记 Todo #7 为 completed
```

**注意事项**：
- 这些函数通常较短（10-20行）
- 可能调用 self.移动端.xxx 或 self.Tool.xxx 方法

### 步骤8：提取辅助函数

**目标**：提取其他必要的辅助函数

**需要提取的函数**：
- `def check_run_status(self)` - 检查设备状态
- 其他被 lite 函数调用的方法（如果有）

**操作**：
```
1. 在输出缓冲区添加注释：
   "\n    # ==================== 辅助函数 ====================\n"
2. 提取 check_run_status 函数
3. 检查前面提取的 lite 函数，查看是否调用了其他 self.xxx 方法
4. 如果有，提取这些方法（智能判断）
5. 记录到构建日志
6. 标记 Todo #8 为 completed
```

**智能依赖分析**：
- 查看提取的函数中是否有 `self.xxx()` 调用
- 如果调用的方法不在已提取列表中，考虑是否需要提取
- 常见的依赖：self.Tool.xxx、self.移动端.xxx（这些是外部对象，不需要提取）

### 步骤9：识别需要的图片文件

**目标**：从代码中提取所有 Template 引用的图片

**操作**：
```
1. 在已提取的所有代码中搜索 Template(r"xxx.png") 模式
2. 使用正则表达式提取所有 .png 文件名：
   模式：Template\(r"(tpl[^"]+\.png)"
3. 去重，生成图片文件列表
4. 记录到构建日志
5. 标记 Todo #9 为 completed
```

**预期结果**：
- 约 20-40 个图片文件
- 文件名格式：tpl[数字].png

### 步骤10：复制图片资源

**目标**：将图片文件复制到目标 assets 目录

**操作**：
```
1. 创建目标目录：D:/SoftData/git/autowzry-agent/autowzry_lite/autowzry/assets/
2. 对于每个图片文件：
   a. 源路径：D:/SoftData/git/autowzry/autowzry/assets/{filename}
   b. 目标路径：D:/SoftData/git/autowzry-agent/autowzry_lite/autowzry/assets/{filename}
   c. 检查源文件是否存在
   d. 复制文件（保留时间戳）
   e. 记录到构建日志（成功/失败）
3. 标记 Todo #10 为 completed
```

**注意事项**：
- 如果源文件不存在，记录警告但继续（可能是代码中已废弃的图片）
- 使用 Bash 的 cp 命令或类似工具

### 步骤11：复制配置文件

**目标**：复制必要的配置文件

**需要复制的文件**：
- `android.960.540.dict.yaml` - 分辨率配置字典

**操作**：
```
1. 源路径：D:/SoftData/git/autowzry/autowzry/assets/android.960.540.dict.yaml
2. 目标路径：D:/SoftData/git/autowzry-agent/autowzry_lite/autowzry/assets/android.960.540.dict.yaml
3. 检查文件是否存在
4. 复制文件
5. 记录到构建日志
6. 标记 Todo #11 为 completed
```

### 步骤12：生成 version.py

**目标**：创建版本文件，记录源版本和构建时间

**操作**：
```
1. 从步骤1获取的源版本信息
2. 生成内容：
   - 复制源文件的所有 last_modified 行
   - 添加 lite 版本信息：
     lite_build_time = "2025-11-24 HH:MM:SS"  # 当前时间
     lite_source_version = "2025-11-19 13:31:53"  # 源版本
3. 写入：D:/SoftData/git/autowzry-agent/autowzry_lite/autowzry/version.py
4. 标记 Todo #12 为 completed
```

**文件格式示例**：
```python
last_modified = "2025-11-05 13:55:10"
last_modified = "2025-11-11 16:03:36"
last_modified = "2025-11-19 13:31:53"

# lite版本构建信息
lite_build_time = "2025-11-24 10:30:00"
lite_source_version = "2025-11-19 13:31:53"
```

### 步骤13：生成 __init__.py

**目标**：创建包初始化文件

**操作**：
```
1. 生成内容（固定模板）：
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
autowzry_lite - 精简版识别库

从完整版 autowzry 提取，仅包含核心识别和控制功能
"""

from .wzry import wzry_task, wzry_figure

__all__ = ['wzry_task', 'wzry_figure']

2. 写入：D:/SoftData/git/autowzry-agent/autowzry_lite/autowzry/__init__.py
3. 标记 Todo #13 为 completed
```

### 步骤14：生成构建日志

**目标**：记录完整的构建信息

**操作**：
```
1. 收集所有构建过程中记录的信息：
   - 构建时间（当前时间）
   - 源版本（从 version.py 读取）
   - 源路径和目标路径
   - 提取的函数列表（函数名）
   - 复制的图片列表（文件名，按字母排序）
   - 复制的配置文件

2. 生成日志文件格式：
==============================================================
autowzry_lite 构建日志
==============================================================

构建时间: 2025-11-24 10:30:00
源版本: 2025-11-19 13:31:53
源路径: D:/SoftData/git/autowzry/autowzry/
目标路径: D:/SoftData/git/autowzry-agent/autowzry_lite/autowzry/

提取的函数 (XX 个):
  - 版本号
  - 项目介绍
  - lite_连接设备
  - lite_当前画面
  - lite_判断对战
  - lite_判断死亡
  - lite_判断移动方向
  - lite_判断当前界面
  - 对战中_移动
  - 对战中_攻击
  - 对战中_信号
  - check_run_status

提取的类:
  - wzry_runinfo (简化版)
  - wzry_figure (精简版)
  - wzry_task (精简版 - 仅 __init__ 和 lite 函数)

复制的图片 (XX 个):
  - tpl1689666416575.png
  - tpl1702267006237.png
  - ...
  (按字母排序)

复制的配置文件:
  - android.960.540.dict.yaml

==============================================================
构建完成
==============================================================

3. 写入：D:/SoftData/git/autowzry-agent/autowzry_lite/build_log.txt
4. 标记 Todo #14 为 completed
```

### 步骤15：最终确认

**操作**：
```
1. 检查所有 Todo 是否已完成
2. 验证生成的文件：
   - autowzry/wzry.py
   - autowzry/version.py
   - autowzry/__init__.py
   - autowzry/assets/*.png (20-40个)
   - autowzry/assets/android.960.540.dict.yaml
   - build_log.txt
3. 向用户报告：
   - 构建成功
   - 生成的文件列表
   - 提取了多少个函数
   - 复制了多少个图片
   - 构建日志位置
```

## 注意事项

### 代码提取原则

1. **完整性**：提取函数时包含完整的函数体，不要遗漏任何代码
2. **保留注释**：保留所有文档字符串、行内注释
3. **保留空行**：保留函数间的空行，维持代码可读性
4. **缩进一致**：提取类方法时保持正确的缩进（4空格或1tab）

### 智能判断

1. **函数边界**：通过缩进级别判断函数结束，不依赖固定行号
2. **依赖分析**：如果 lite 函数调用了其他方法，智能判断是否需要提取
3. **图片识别**：从 Template 语句中提取文件名，不依赖预设列表

### 错误处理

1. **文件不存在**：如果源文件不存在，报告错误并停止
2. **函数未找到**：如果某个函数找不到，记录警告但继续
3. **图片缺失**：如果图片文件不存在，记录警告但继续

### 灵活适应

1. **函数名变化**：如果函数名改变，通过搜索 "lite_" 前缀找到所有lite函数
2. **新增函数**：如果发现新的 lite_ 函数，一并提取
3. **参数变化**：函数签名变化不影响提取，提取完整的 def 行

## 验证清单

构建完成后，Agent 应该确认：

- [ ] wzry.py 文件已生成，包含所有 lite 函数
- [ ] version.py 包含源版本和构建时间
- [ ] __init__.py 正确导出 wzry_task 和 wzry_figure
- [ ] assets 目录包含所有需要的图片
- [ ] build_log.txt 详细记录了构建过程
- [ ] 所有 Todo 任务标记为 completed
- [ ] 向用户报告了构建结果

## 示例对话

**用户输入**：
```
按照 autowzry_lite/AGENT_BUILD_GUIDE.md 的步骤，
遵守 autowzry_lite/BUILD_PRINCIPLES.md 的原则，
构建 autowzry_lite
```

**Agent 应该回复**：
```
好的，我现在开始构建 autowzry_lite。

首先我会创建 Todo 任务列表来跟踪进度，然后按照以下步骤执行：

1. 读取源文件版本信息
2. 提取 wzry.py 文件头部
3. 提取工具函数
4. 提取并精简 wzry_figure 类
5. 提取 wzry_task 类
... (列出所有步骤)

开始执行...

[执行构建过程，实时更新 Todo 状态]

构建完成！生成的文件：
- autowzry/wzry.py (提取了 12 个函数)
- autowzry/version.py
- autowzry/__init__.py
- autowzry/assets/ (复制了 28 个图片)
- build_log.txt

详细构建日志已保存到 build_log.txt
```
