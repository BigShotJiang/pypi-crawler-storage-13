#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
autowzry_lite - 精简版识别库

从完整版 autowzry 提取，仅包含核心识别和控制功能
"""

from .wzry import wzry_task, wzry_figure

__all__ = ['wzry_task', 'wzry_figure']
