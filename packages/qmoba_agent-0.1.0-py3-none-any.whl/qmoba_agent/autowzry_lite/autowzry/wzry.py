#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
from time import sleep
import random
import time
import traceback
import os
import sys
import multiprocessing
import math


def 自动化农活演示(self, **kwargs):
    if not kwargs:
        return
    for key, value in kwargs.items():
        setattr(self, key, value)
#
# autowzry · 自动化农活演示
# Copyright (C) 2025 cndaqiang
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.


##################################
# Author : cndaqiang             #
# Update : 2024-12-08            #
# Build  : 2023-11-10            #
# What   : autowzry              #
##################################

try:
    # from airtest_mobileauto import *
    # 建议将 from airtest_mobileauto import * 替换为以下具体导入:
    from airtest_mobileauto.control import (
        Settings,
        DQWheel,
        deviceOB,
        appOB,
        TimeECHO,
        TimeErr,
        fun_name,
        funs_name,
        run_class_command,
        touch,
        exists,
        swipe,
        Template,
        save_yaml,
        TaskManager,
        connect_status,
        check_requirements
    )
    from airtest_mobileauto.tool.image_detector import ImageDetector
    from airtest_mobileauto.tool.image_motion_detector import MotionDetector
except ImportError:
    traceback.print_exc()
    print("模块 [airtest_mobileauto] 导入不存在，请安装 airtest_mobileauto")
    print("运行以下命令安装：")
    print("python -m pip install airtest_mobileauto --upgrade")
    raise ImportError("模块 [airtest_mobileauto] 导入失败")

updata_time1 = "2025年10月01日"


# ==================== 工具函数 ====================

def 版本号(判断版本=False, delta_days=30):
    try:
        # 如果模块没有被打包成包，直接导入模块
        from version import last_modified
    except ImportError:
        # 如果模块已经打包成包，使用相对导入
        try:
            from .version import last_modified
        except:
            last_modified = "Unknow"
    #
    if not 判断版本:
        return last_modified
    #
    # 判断版本是否过低, 避免玩家采用旧版本, 导致操作失误扣信誉分情况
    if last_modified != "Unknow":
        buildtime = time.mktime(time.strptime(last_modified, "%Y-%m-%d %H:%M:%S"))
        now = time.time()
        if now - buildtime > 60 * 60 * 24 * delta_days:  # 超过N天结束
            TimeECHO(f"\n软件版本 {last_modified} 过低, 请前往项目主页检查更新.")
            return False
    #
    return True
#
    TimeECHO(f"Build time: {版本号(判断版本=False)}")


def 项目介绍():
    # 项目介绍信息
    介绍content = [
        ">" * 20,
        "本项目无任何交流群组，完全免费，请警惕任何收费信息。",
        "使用者必须在遵循《腾讯游戏许可及服务协议》以及法律法规的情况下使用，不得用于非法用途。",
        "使用本项目所产生的一切法律责任由使用者自行承担。",
        "项目主页: https://github.com/cndaqiang/autowzry",
        "运行教程: https://cndaqiang.github.io/wzry.doc",
        f"Python version: {sys.version}",
        f"Executable: {sys.executable}",
        "<" * 20
    ]
    content = "\n\n"
    for i in 介绍content:
        content += i+"\n"
    TimeECHO(content)
    sleep(1)


# ==================== 运行信息类（简化版） ====================

class wzry_runinfo:
    def __init__(self):
        self._starttime = time.time()


# ==================== 图片元素类（精简版） ====================

class wzry_figure:
    # 图片元素信息,
    # 方便更新,
    # 以及用于统一更新图片传递给所有进程
    def __init__(self, Tool=None):
        # 静态资源
        current_dir = os.path.dirname(os.path.abspath(__file__))
        assets_dir = os.path.join(current_dir, 'assets')
        Settings.figdirs.append(assets_dir)
        seen = set()
        Settings.figdirs = [x for x in Settings.figdirs if not (x in seen or seen.add(x))]
        #
        self.Tool = DQWheel() if Tool == None else Tool
        #
        # 一些图库, 后期使用图片更新
        self.登录界面开始游戏图标 = Template(r"tpl1692947242096.png", record_pos=(-0.004, 0.158), resolution=(960, 540), threshold=0.9)
        # 这些图标的record_pos必须准确,用于其他16:9分辨率无法识别时点击
        self.大厅对战图标 = Template(r"tpl1723219359665.png", record_pos=(-0.1, 0.14), resolution=(960, 540))
        self.大厅娱乐模式 = Template(r"tpl1723219381063.png", record_pos=(0.24, 0.14), resolution=(960, 540))
        self.大厅排位赛 = Template(r"tpl1739510088247.png", record_pos=(0.103, 0.131), resolution=(960, 540))
        #
        self.账号重新登录元素 = []
        self.账号重新登录元素.append(Template(r"tpl1692946938717.png", record_pos=(-0.108, 0.159), resolution=(960, 540), threshold=0.9))
        self.账号重新登录元素.append(Template(r"tpl1760667139147.png", record_pos=(-0.107, 0.159), resolution=(960, 540)))
        #
        self.大厅元素 = []
        self.大厅元素.append(self.大厅对战图标)
        self.大厅元素.append(self.大厅排位赛)
        self.大厅元素.append(self.大厅娱乐模式)
        #
        self.房间一个空位 = Template(r"tpl1690442701046.png", record_pos=(-0.01, -0.027), resolution=(1920, 1080))
        self.房间三个空位 = Template(r"tpl1759974144570.png", record_pos=(-0.01, -0.027), resolution=(1920, 1080))
        #
        self.房间元素 = []
        self.房间元素.append(self.房间一个空位)
        self.房间元素.append(self.房间三个空位)
        self.房间元素.append(Template(r"tpl1700304317380.png", record_pos=(-0.38, -0.252), resolution=(960, 540)))
        self.房间元素.append(Template(r"tpl1691463676972.png", record_pos=(0.356, -0.258), resolution=(960, 540)))
        self.房间元素.append(Template(r"tpl1700304304172.png", record_pos=(0.39, -0.259), resolution=(960, 540)))
        # 对战页面元素
        self.普攻 = Template(r"tpl1689666416575.png", record_pos=(0.362, 0.2), resolution=(960, 540), threshold=0.9)
        self.移动 = Template(r"tpl1702267006237.png", record_pos=(-0.327, 0.16), resolution=(960, 540))
        self.钱袋 = Template(r"tpl1719485696322.png", record_pos=(-0.469, -0.059), resolution=(960, 540), threshold=0.9)
        self.普攻S = [self.普攻]  # 其他特色的攻击图标
        self.移动S = [self.移动]  # 其他特色的移动图标
        #
        self.对战图片元素 = []
        for i in self.普攻S[:1]:
            self.对战图片元素.append(i)
        for i in self.移动S:
            self.对战图片元素.append(i)
        self.对战图片元素.append(Template(r"tpl1719546803645.png", record_pos=(-0.005, 0.223), resolution=(960, 540)))
        self.对战图片元素.append(self.钱袋)
        #
        self.对战恢复按钮 = Template(r"tpl1740116206086.png", record_pos=(0.034, 0.224), resolution=(960, 540))
        self.对战火球按钮 = Template(r"tpl1740116233645.png", record_pos=(0.05, 0.108), resolution=(960, 540))
        self.对战31技能 = Template(r"tpl1740116215897.png", record_pos=(0.198, 0.211), resolution=(960, 540))
        self.对战32技能 = Template(r"tpl1740122028690.png", record_pos=(0.263, 0.111), resolution=(960, 540))
        self.对战33技能 = Template(r"tpl1740122054375.png", record_pos=(0.368, 0.047), resolution=(960, 540))
        self.对战点赞按钮 = Template(r"tpl1740121974421.png", record_pos=(0.332, -0.132), resolution=(960, 540))
        self.对战主动装备 = Template(r"tpl1740122125475.png", record_pos=(0.362, -0.066), resolution=(960, 540))
        self.对战主动技能 = Template(r"tpl1740124404016.png", record_pos=(0.10, 0.22), resolution=(960, 540))
        self.对战买装备左 = Template(r"tpl1740134591195.png", record_pos=(-0.399, -0.056), resolution=(960, 540))
        self.对战买装备右 = Template(r"tpl1740134591195.png", record_pos=(0.399, -0.201), resolution=(960, 540))
        #
        self.钱袋子_模拟战 = Template(r"tpl1690546610171.png", record_pos=(0.391, 0.216), resolution=(960, 540))
        self.刷新金币_模拟战 = Template(r"tpl1690547053276.png", record_pos=(0.458, -0.045), resolution=(960, 540))
        self.关闭钱袋子_模拟战 = Template(r"tpl1690547457483.png", record_pos=(0.392, 0.216), resolution=(960, 540))
        self.对战图片元素_模拟战 = [self.钱袋子_模拟战, self.刷新金币_模拟战]
        # self.关闭钱袋子_模拟战 不能用于识别模拟战状态, 因为确定匹配页面也有叉号
        self.对战图片元素_模拟战.append(Template(r"tpl1690546926096.png", record_pos=(-0.416, -0.076), resolution=(960, 540)))
        self.对战图片元素_模拟战.append(Template(r"tpl1690547491681.png", record_pos=(0.471, 0.165), resolution=(960, 540)))
        self.对战图片元素_模拟战.append(Template(r"tpl1690552290188.png", record_pos=(0.158, 0.089), resolution=(960, 540)))
        # 对战结束的画面
        # 水晶爆炸的胜利失败画面
        self.对战水晶爆炸页面元素 = []
        self.对战水晶爆炸页面元素.append(Template(r"tpl1727237953837.png", record_pos=(-0.008, -0.009), resolution=(960, 540)))  # 失败
        self.对战水晶爆炸页面元素.append(Template(r"tpl1727234712515.png", record_pos=(-0.007, 0.018), resolution=(960, 540)))  # 胜利
        #
        self.MVP结算画面 = []
        # S37更新的团队MVP结算画面
        self.MVP结算画面.append(Template(r"tpl1727231951999.png", record_pos=(0.433, -0.235), resolution=(960, 540)))
        # S38更新的个人MVP结算画面
        # 触摸模式低级MVP
        self.MVP结算画面.append(Template(r"tpl1735099219943.png", record_pos=(0.189, -0.017), resolution=(960, 540)))
        self.MVP结算画面.append(Template(r"tpl1735099226736.png", record_pos=(0.383, -0.016), resolution=(960, 540)))
        self.MVP结算画面.append(Template(r"tpl1735104765902.png", record_pos=(0.19, -0.021), resolution=(960, 540)))
        self.MVP结算画面.append(Template(r"tpl1735104770577.png", record_pos=(0.385, -0.017), resolution=(960, 540)))
        self.MVP结算画面.append(Template(r"tpl1735105627113.png", record_pos=(0.188, -0.014), resolution=(960, 540)))
        # 挂机模式高级MVP等待截图
        #
        self.战绩页面元素 = []
        # 战绩页面, 这两个元素,在娱乐模式中还在使用
        self.战绩页面元素.append(Template(r"tpl1699766285319.png", record_pos=(-0.009, -0.257), resolution=(960, 540)))  # 胜利
        self.战绩页面元素.append(Template(r"tpl1699677826933.png", record_pos=(-0.011, -0.257), resolution=(960, 540)))  # 失败
        for i in self.对战水晶爆炸页面元素:
            self.战绩页面元素.append(i)
        for i in self.MVP结算画面:
            self.战绩页面元素.append(i)


# ==================== 主任务类（精简版） ====================

class wzry_task:
    # todo, 并行判断状态
    # concurrent.futures.ThreadPoolExecutor(max_workers=3)

    def __init__(self, connect=True):
        """
        外部调用autowzry作为lite库使用时, 可以不强制连接设备, connect = False
        """
        # 静态资源
        current_dir = os.path.dirname(os.path.abspath(__file__))
        assets_dir = os.path.join(current_dir, 'assets')
        Settings.figdirs.append(assets_dir)
        seen = set()
        Settings.figdirs = [x for x in Settings.figdirs if not (x in seen or seen.add(x))]
        #
        # device
        self.mynode = Settings.mynode
        self.totalnode = Settings.totalnode
        self.totalnode_bak = self.totalnode
        self.LINK = Settings.LINK_dict[Settings.mynode]
        self.connected = connect
        #
        # ------------------------------------------------------------------------------
        # deviceOB
        self.移动端 = deviceOB(mynode=self.mynode, totalnode=self.totalnode, LINK=self.LINK, connect=connect)
        # 当不connect时, 没有分辨率以及字典文件
        # ------------------------------------------------------------------------------
        # Tool
        # 保存字典，计算参数的文件
        dict_prefix = f"{self.移动端.设备类型}.{max(self.移动端.resolution)}.{min(self.移动端.resolution)}.dict"
        self.dictfile = f"{dict_prefix}.{self.mynode}.yaml"
        # 预设的分辨率对应的触点文件
        dictreso = os.path.join(assets_dir, f"{dict_prefix}.yaml")
        loaddict = not os.path.exists(self.dictfile) and os.path.exists(dictreso)
        self.Tool = DQWheel(var_dict_file=self.dictfile, mynode=self.mynode, totalnode=self.totalnode)
        if loaddict:
            try:
                TimeECHO(f"检测到本程序第一次运行，且分辨率为{self.移动端.resolution}, 加载预设字典中....")
                self.Tool.var_dict = self.Tool.read_dict(dictreso)
                #
                self.Tool.var_dict["运行参数.runstep"] = 0
                self.Tool.save_dict(self.Tool.var_dict, self.dictfile)
            except:
                traceback.print_exc()
        # ------------------------------------------------------------------------------
        # APPOB
        self.设备类型 = self.移动端.设备类型
        self.APPID = "com.tencent.smoba" if "ios" in self.设备类型 else "com.tencent.tmgp.sgame"
        self.APPOB = appOB(APPID=self.APPID, big=True, device=self.移动端)
        # ------------------------------------------------------------------------------
        self.房主 = self.mynode == 0 or self.totalnode == 1
        # ------------------------------------------------------------------------------
        # 图片对象初始化
        self.图片 = wzry_figure(Tool=self.Tool)
        # ------------------------------------------------------------------------------
        # lite版本初始化变量
        self.组队模式 = False
        self.对战模式 = "5v5匹配"
        self.重新登录FILE = f"WZRY.{self.mynode}.重新登录FILE.txt"
        self.无法进行组队FILE = f"WZRY.无法进行组队FILE.txt"
        self.分辨率16v9 = abs(self.移动端.resolution[0]/self.移动端.resolution[1] - 1.77) < 0.1

    # ==================== lite识别函数 ====================

    def lite_连接设备(self):
        if not self.移动端.device:
            self.移动端.连接设备()
        self.connected = True
        self.移动端.resolution = (max(self.移动端.resolution), min(self.移动端.resolution))
        self.分辨率16v9 = abs(self.移动端.resolution[0]/self.移动端.resolution[1] - 1.77) < 0.1

    def lite_当前画面(self):
        """
        返回当前画面的图片
        """
        img = self.移动端.device.snapshot()
        return img

    def lite_判断对战(self, screen=None):
        """
        判断当前是否处于对战中
        """
        对战中, self.图片.对战图片元素 = self.Tool.存在任一张图NEW(self.图片.对战图片元素, "对战图片元素", screen=screen)
        if 对战中:
            return True
        else:
            return False

    def lite_判断死亡(self, img=None):
        """
        img = file_name or cv.read_image()
        # 其他示例, 保存regin区域
        detector.visualize_regions(img,"test.png")
        """
        # 创建一个ImageDetector对象
        # 回城按钮的相对坐标, 攻击按钮，死亡时分数 <= 50, 活得得分>=100, 更多见 image_detector_demo.py
        # 注意：ImageDetector 使用 center_dim0(Y轴/垂直) 和 center_dim1(X轴/水平)
        regions = [{"name": "skill_button", "center_dim0": 0.90, "center_dim1": 0.46}]
        threshold = 60
        # regions = [{"name": "attack_button", "center_dim0": 0.86, "center_dim1": 0.91}];threshold=60
        # regions.append({...})
        detector = ImageDetector(regions=regions, threshold=threshold)
        #
        doublecheck = img is None
        if img is None:
            img = self.lite_当前画面()

        # 判断是否存在此变量, 不存在, 则没有保存
        try:
            if self.saved_deatch_region == True:
                pass
        except:
            self.saved_deatch_region = False
        #
        result, score = detector.detect(img)
        if not self.saved_deatch_region:
            print("img", img.shape, score)
            detector.visualize_regions(img, ".tmp.autowzry.death_region.png")
            self.saved_deatch_region = True
        # 被控制的时候也会是灰色的, 所以1s后再进行判断
        if doublecheck:
            sleep(2)
            img = self.lite_当前画面()
            result, score = detector.detect(img)
        #
        # 返回结果
        if not result:
            TimeECHO(f"[状态]:已死亡")
        return not result

    def lite_判断移动方向(self, img1=None, img2=None, custom_regions=None, figpath=None):
        """
        调试方案:
        i=1;
        while True: print(self.lite_判断移动方向(figpath=f"move.{i}.png")); sleep(3); i=i+1
        """
        if custom_regions is None:
            custom_regions = [
                [0.128, 0.367, 0.302, 0.543],  # 区域1
                [0.231, 0.568, 0.413, 0.744],  # 区域2
                [0.347, 0.325, 0.647, 0.419],  # 区域3
                [0.647, 0.285, 0.827, 0.475]   # 区域4
            ]
        #
        detector = MotionDetector(custom_regions=custom_regions, use_airtest=True)
        if img1 is None or img2 is None:
            img1 = self.lite_当前画面()
            sleep(1)
            img2 = self.lite_当前画面()
        #
        result = detector.detector(img1, img2, region=custom_regions, figpath=figpath)
        #
        return result

    def lite_判断当前界面(self, only_norm=True):
        """
        轻量级状态判断 - 一次截图判断所有界面状态

        Args:
            only_norm (bool): 是否只判断常规图片(大厅、房间、对战),默认False判断所有元素

        Returns:
            str: 状态名称 - "大厅中", "房间中", "对战中", "对战中_模拟战", "战绩页面", "登录界面", "未知"
        """
        # 检查APP是否在前台
        if not self.APPOB.前台APP(0):
            return "未知"

        # 根据对战模式确定对战标签
        对战标签 = "对战中_模拟战" if "模拟战" in self.对战模式 else "对战中"

        # 构建总图片列表和对应的状态列表
        总图片列表 = []
        状态列表 = []

        # 按顺序添加各状态的图片元素
        # 大厅
        for 图片 in self.图片.大厅元素:
            总图片列表.append(图片)
            状态列表.append("大厅中")

        # 房间
        for 图片 in self.图片.房间元素:
            总图片列表.append(图片)
            状态列表.append("房间中")

        # 对战
        对战元素 = self.图片.对战图片元素_模拟战 if "模拟战" in 对战标签 else self.图片.对战图片元素
        for 图片 in 对战元素:
            总图片列表.append(图片)
            状态列表.append(对战标签)

        # 如果不是只判断norm，继续添加战绩和登录元素
        if not only_norm:
            # 战绩
            for 图片 in self.图片.战绩页面元素:
                总图片列表.append(图片)
                状态列表.append("战绩页面")

            # 登录
            登录元素 = [self.图片.登录界面开始游戏图标] + self.图片.账号重新登录元素
            for 图片 in 登录元素:
                总图片列表.append(图片)
                状态列表.append("登录界面")

        # 构建 filename 映射列表 (用于匹配时的稳定索引)
        filename列表 = [图片.filename for 图片 in 总图片列表]

        # 一次性检测所有图片 (单次截图)
        存在, 更新后的图片列表 = self.Tool.存在任一张图(总图片列表, f"{fun_name(1)}.lite状态检测")

        if not 存在:
            TimeECHO(f"{fun_name(1)}: 未识别到任何界面元素")
            return "未知"

        # 找到的图片在更新后列表的首位
        匹配的图片 = 更新后的图片列表[0]

        # 用 filename 找到该图片在原总列表中的位置
        匹配索引 = filename列表.index(匹配的图片.filename)

        # 对应位置的状态就是结果
        匹配的状态 = 状态列表[匹配索引]

        TimeECHO(f"{fun_name(1)}: 识别到状态 = {匹配的状态}, 匹配图片 = {匹配的图片.filename}")
        return 匹配的状态

    # ==================== 对战控制函数 ====================

    def 对战中_移动(self, angle=0.0, duration=1):
        移动poskey = f"移动pos({self.mynode})"
        移动pos = self.Tool.cal_record_pos(self.图片.移动.record_pos, self.移动端.resolution, 移动poskey, savepos=True)
        # 负号 让坐标轴画在图片上
        angle_rad = -math.radians(angle)
        radius = 0.2
        x = radius * math.cos(angle_rad)
        y = radius * math.sin(angle_rad)
        TimeECHO(f"移动中:({angle:3.0f}){移动pos},{[x, y]}")
        swipe(移动pos, vector=[x, y], duration=duration)
        pass
    #

    def 对战中_攻击(self, index=0):
        普攻poskey = f"普攻poskey({self.mynode})"
        普攻pos = self.Tool.cal_record_pos(self.图片.普攻.record_pos, self.移动端.resolution, 普攻poskey, savepos=True)
        TimeECHO(f"普攻")
        touch(普攻pos, times=random.randint(4, 12), duration=random.random()/4)
        pass

    def 对战中_信号(self, index=0):
        # 3技能英雄点击技能
        所有技能图标 = [self.图片.对战31技能, self.图片.对战32技能, self.图片.对战33技能]
        技能图标 = 所有技能图标[random.randint(0, len(所有技能图标)-1)]
        self.Tool.touch_record_pos(record_pos=技能图标.record_pos, resolution=self.移动端.resolution, keystr="对战技能图标")
        点击按钮 = random.randint(0, 12)
        TimeECHO(f"技能装备{点击按钮}")
        if 点击按钮 == 0:
            self.Tool.touch_record_pos(record_pos=self.图片.对战点赞按钮.record_pos, resolution=self.移动端.resolution, keystr="对战点赞按钮")
        elif 点击按钮 == 1:
            self.Tool.touch_record_pos(record_pos=self.图片.对战主动技能.record_pos, resolution=self.移动端.resolution, keystr="对战主动技能")
        elif 点击按钮 == 2:
            self.Tool.touch_record_pos(record_pos=self.图片.对战主动装备.record_pos, resolution=self.移动端.resolution, keystr="对战主动装备")
        elif 点击按钮 == 3:
            self.Tool.touch_record_pos(record_pos=self.图片.对战买装备左.record_pos, resolution=self.移动端.resolution, keystr="对战买装备左")
        elif 点击按钮 == 4:
            self.Tool.touch_record_pos(record_pos=self.图片.对战买装备右.record_pos, resolution=self.移动端.resolution, keystr="对战买装备右")
        elif 点击按钮 == 5:
            self.Tool.touch_record_pos(record_pos=self.图片.对战恢复按钮.record_pos, resolution=self.移动端.resolution, keystr="对战恢复按钮")
        elif 点击按钮 == 6:
            x, y = random.random(), random.random()
            地图pos = (x*(-0.35+0.47)-0.47, y*(-0.1+0.25)-0.25)
            self.Tool.cal_record_pos(地图pos, self.移动端.resolution, "地图pos", savepos=True)
            TimeECHO(f"滑动地图")
            vector = (0.5-x, 0.5-y)
            # swipe(self.Tool.var_dict["地图pos"], vector=vector, duration=random.random()*2.0+1.0)
        else:
            技能图标 = 所有技能图标[点击按钮 % 3]
            self.Tool.touch_record_pos(record_pos=技能图标.record_pos, resolution=self.移动端.resolution, keystr="对战技能图标", savepos=True)
            # 有些技能需要滑动释放
            技能pos = self.Tool.var_dict["对战技能图标"]
            # swipe(技能pos, vector=[0.2,-0.2], duration=random.random()/2+1.0)

    # ==================== 辅助函数 ====================

    def check_run_status(self):
        #
        self.组队模式 = self.组队模式 and not os.path.exists(self.无法进行组队FILE)
        #
        if os.path.exists(self.重新登录FILE):
            content = f"[{funs_name()}]失败:存在[{self.重新登录FILE}]"
            TimeECHO(content)
            self.Tool.touch同步文件(self.Tool.独立同步文件, content=content)
        #
        if self.Tool.存在同步文件(self.Tool.独立同步文件):
            content = f"[{funs_name()}]失败:存在[{self.Tool.独立同步文件}]"
            TimeECHO(content)
            if self.组队模式:
                self.Tool.touch同步文件(self.Tool.辅助同步文件, content=content)
            TimeECHO(content)
            return False
        #
        if self.Tool.存在同步文件(self.Tool.辅助同步文件):
            TimeECHO(f"检测到{self.Tool.辅助同步文件}文件")
            return False
        #
        if os.path.exists(self.Tool.stopfile):
            TimeECHO(f"检测到{self.Tool.stopfile}文件")
            return False
        #
        return True
