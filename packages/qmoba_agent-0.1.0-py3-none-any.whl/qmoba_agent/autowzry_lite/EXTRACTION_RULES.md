# autowzry_lite 精简提取规则

## 提取源路径

- **源目录**: `D:/SoftData/git/autowzry/autowzry/`
- **目标目录**: `D:/SoftData/git/autowzry-agent/autowzry_lite/autowzry/`

## 需要提取的函数和类

### 1. wzry.py 核心函数

从 `wzry.py` 提取以下函数（按行号范围提取完整函数体）：

**lite识别函数（6个）：**
- `lite_连接设备(self)` - 约第3393行
- `lite_当前画面(self)` - 约第3400行
- `lite_判断对战(self, screen=None)` - 约第3407行
- `lite_判断死亡(self, img=None)` - 约第3417行
- `lite_判断移动方向(self, img1=None, img2=None, custom_regions=None, figpath=None)` - 约第3459行
- `lite_判断当前界面(self, only_norm=True)` - 约第3483行

**对战控制函数（3个）：**
- `对战中_移动(self, ...)` - 需要查找完整定义
- `对战中_攻击(self, ...)` - 需要查找完整定义
- `对战中_信号(self, ...)` - 需要查找完整定义

**辅助函数：**
- `check_run_status(self)` - 检查运行状态
- `版本号(判断版本=False, delta_days=30)` - 约第85行
- `项目介绍()` - 约第112行（可选，用于显示信息）

### 2. wzry_figure 类（精简版）

从 `wzry.py` 提取 `wzry_figure` 类（约第196-459行），但只保留以下图片元素：

**对战检测相关：**
- `self.普攻` - tpl1689666416575.png
- `self.移动` - tpl1702267006237.png
- `self.钱袋` - tpl1719485696322.png
- `self.对战图片元素` - 列表定义（约第351-357行）
- `self.对战图片元素_模拟战` - 列表定义（约第382-386行）

**界面判断相关（lite_判断当前界面需要）：**
- `self.大厅元素` - 列表定义（约第311-314行）
- `self.房间元素` - 列表定义（约第325-330行）
- `self.战绩页面元素` - 列表定义（约第429-436行）
- `self.登录界面开始游戏图标` - 约第212行
- `self.账号重新登录元素` - 列表定义（约第307-309行）

**移除的图片元素：**
- 所有活动、礼包、签到相关图片
- 匹配、房间操作相关图片（开始匹配、取消匹配等）
- 英雄选择、分路设置相关图片
- MVP结算、返回按钮等辅助元素

### 3. wzry_task 类（精简版）

提取 `wzry_task` 类的以下部分：

**保留的初始化代码（__init__方法）：**
- 设备连接初始化（约第465-494行）
- Tool、图片、APPOB等基础对象初始化
- 移动端对象创建

**保留的方法：**
- `check_run_status(self)` - 检查设备状态
- 上述9个lite/控制函数

**移除的方法：**
- 所有游戏自动化流程函数（200+个）
- 任务、活动、组队等功能

### 4. wzry_runinfo 类

**可选提取** - 如果lite函数不依赖此类，可以完全移除或只保留简化版：

```python
class wzry_runinfo:
    def __init__(self):
        self._starttime = time.time()
```

## 需要复制的图片资源

从 `assets/` 目录复制以下文件：

### 对战检测图片（必需）
- `tpl1689666416575.png` - 普攻按钮
- `tpl1702267006237.png` - 移动按钮
- `tpl1719485696322.png` - 钱袋
- `tpl1719546803645.png` - 对战元素
- `tpl1690546610171.png` - 钱袋子_模拟战
- `tpl1690547053276.png` - 刷新金币_模拟战
- `tpl1690546926096.png` - 模拟战元素1
- `tpl1690547491681.png` - 模拟战元素2
- `tpl1690552290188.png` - 模拟战元素3

### 界面判断图片（lite_判断当前界面需要）
- `tpl1723219359665.png` - 大厅对战图标
- `tpl1723219381063.png` - 大厅娱乐模式
- `tpl1739510088247.png` - 大厅排位赛
- `tpl1690442701046.png` - 房间一个空位
- `tpl1759974144570.png` - 房间三个空位
- `tpl1700304317380.png` - 房间元素1
- `tpl1691463676972.png` - 房间元素2
- `tpl1700304304172.png` - 房间元素3
- `tpl1692947242096.png` - 登录界面开始游戏
- `tpl1692946938717.png` - 账号重新登录1
- `tpl1760667139147.png` - 账号重新登录2

### 战绩页面图片
- `tpl1699766285319.png` - 胜利
- `tpl1699677826933.png` - 失败
- `tpl1727237953837.png` - 水晶爆炸_失败
- `tpl1727234712515.png` - 水晶爆炸_胜利
- `tpl1727231951999.png` - MVP结算1
- `tpl1735099219943.png` - MVP结算2
- `tpl1735099226736.png` - MVP结算3

### 配置文件
- `android.960.540.dict.yaml` - 分辨率配置字典

**总计约30个图片文件**，相比完整版的200+个图片大幅精简。

## 代码修改规则

### 1. 导入语句保持不变

保留所有 `airtest_mobileauto` 的导入，不做修改：

```python
from airtest_mobileauto.control import Settings, DQWheel, deviceOB, ...
from airtest_mobileauto.tool.image_detector import ImageDetector
from airtest_mobileauto.tool.image_motion_detector import MotionDetector
```

### 2. wzry_figure 类简化

只保留 `__init__` 方法和上述列出的图片元素定义，移除其他所有图片定义。

### 3. wzry_task 类简化

**保留：**
- `__init__` 方法中的基础初始化代码
- 9个lite/控制函数的完整实现
- `check_run_status` 方法

**移除：**
- 所有其他方法定义

### 4. 版本信息处理

复制 `version.py` 并在文件末尾添加lite构建信息：

```python
# 原有的 last_modified 行保持不变
last_modified = "2025-11-19 13:31:53"

# 添加lite版本信息
lite_build_time = "2025-11-24 XX:XX:XX"  # 构建脚本自动填充
lite_source_version = "2025-11-19 13:31:53"  # 来源版本
```

## 自动提取策略

转换脚本 `build_autowzry_lite.py` 应实现：

1. **函数提取**：
   - 使用正则表达式匹配函数定义行
   - 向下扫描直到下一个同级 `def` 或类定义
   - 提取完整函数体（包括注释和文档字符串）

2. **类提取**：
   - 提取 `wzry_figure` 完整类定义
   - 删除不需要的图片元素赋值语句
   - 保留必需的 `self.对战图片元素` 等列表定义

3. **图片复制**：
   - 解析保留的 `Template(r"xxx.png")` 语句
   - 提取所有图片文件名
   - 从源 assets 目录复制到目标目录

4. **日志记录**：
   - 记录提取的函数名称和行号
   - 记录复制的图片文件列表
   - 记录提取时间和源版本信息

## 构建输出

生成的 `build_log.txt` 格式示例：

```
=== autowzry_lite 构建日志 ===
构建时间: 2025-11-24 10:30:00
源版本: 2025-11-19 13:31:53
源路径: D:/SoftData/git/autowzry/autowzry/

提取的函数:
  - lite_连接设备 (行 3393-3399)
  - lite_当前画面 (行 3400-3406)
  - lite_判断对战 (行 3407-3416)
  - lite_判断死亡 (行 3417-3458)
  - lite_判断移动方向 (行 3459-3482)
  - lite_判断当前界面 (行 3483-3550)
  - 对战中_移动 (行 XXXX-XXXX)
  - 对战中_攻击 (行 XXXX-XXXX)
  - 对战中_信号 (行 XXXX-XXXX)

提取的类:
  - wzry_figure (精简版)
  - wzry_task (精简版)

复制的图片资源 (30个):
  - tpl1689666416575.png
  - tpl1702267006237.png
  - ...

配置文件:
  - android.960.540.dict.yaml
```
