# autowzry_lite 构建核心原则

## 文档说明

本文档定义了从 autowzry 提取 autowzry_lite 的核心原则，供 Agent 和脚本共同遵守。

## 核心原则

### 原则1：功能完整性

**保留的功能必须完整可用**
- 提取的每个函数必须包含完整的函数体
- 不能只提取部分代码或截断函数
- 保留所有依赖的辅助函数和类方法

### 原则2：最小依赖

**只保留必要的代码，移除所有不相关功能**
- 不保留游戏自动化流程（打金、任务、匹配等）
- 不保留UI自动化相关代码（除了lite函数需要的）
- 图片资源只保留lite函数实际使用的

### 原则3：依赖外部化

**不复制外部库代码**
- ImageDetector、MotionDetector 等检测库不包含在lite版本中
- airtest_mobileauto 相关类保持 import
- 假定使用者已安装 airtest_mobileauto

### 原则4：保持兼容性

**生成的代码必须与 autowzry-agent 兼容**
- 类名不变：wzry_task、wzry_figure
- 函数签名不变：参数名和默认值保持一致
- import 语句不变：保持原有的导入结构

### 原则5：版本可追溯

**每次构建都要记录版本信息**
- 记录源 autowzry 的版本（from version.py）
- 记录 lite 构建时间
- 记录提取了哪些函数和图片

## 需要保留的内容

### 1. 导入语句（完整保留）

```python
from airtest_mobileauto.control import (
    Settings,
    DQWheel,
    deviceOB,
    appOB,
    TimeECHO,
    TimeErr,
    ...
)
from airtest_mobileauto.tool.image_detector import ImageDetector
from airtest_mobileauto.tool.image_motion_detector import MotionDetector
```

**原则**：所有 import 完整保留，包括 try-except 块

### 2. 工具函数

**必须提取**：
- `版本号(判断版本, delta_days)` - 版本检查
- `项目介绍()` - 项目信息（可选）

**原则**：这些函数被 wzry_task 使用，必须保留

### 3. wzry_runinfo 类（简化版）

**只保留**：
```python
class wzry_runinfo:
    def __init__(self):
        self._starttime = time.time()
```

**原则**：如果 lite 函数不使用此类的其他方法，只保留最简版本

### 4. wzry_figure 类（精简版）

**保留的属性**：

#### 对战检测相关
- `self.普攻` - Template(r"tpl1689666416575.png", ...)
- `self.移动` - Template(r"tpl1702267006237.png", ...)
- `self.钱袋` - Template(r"tpl1719485696322.png", ...)
- `self.普攻S` - 列表
- `self.移动S` - 列表
- `self.对战图片元素` - 列表（包含所有 append 语句）
- `self.钱袋子_模拟战`
- `self.刷新金币_模拟战`
- `self.关闭钱袋子_模拟战`
- `self.对战图片元素_模拟战` - 列表

#### 界面判断相关（lite_判断当前界面需要）
- `self.大厅对战图标`
- `self.大厅娱乐模式`
- `self.大厅排位赛`
- `self.大厅元素` - 列表
- `self.房间一个空位`
- `self.房间三个空位`
- `self.房间元素` - 列表
- `self.登录界面开始游戏图标`
- `self.账号重新登录元素` - 列表
- `self.对战水晶爆炸页面元素` - 列表
- `self.MVP结算画面` - 列表
- `self.战绩页面元素` - 列表

**保留的初始化代码**：
```python
def __init__(self, Tool=None):
    # 静态资源
    current_dir = os.path.dirname(os.path.abspath(__file__))
    assets_dir = os.path.join(current_dir, 'assets')
    Settings.figdirs.append(assets_dir)
    seen = set()
    Settings.figdirs = [x for x in Settings.figdirs if not (x in seen or seen.add(x))]
    #
    self.Tool = DQWheel() if Tool == None else Tool
    # ... 图片定义
```

**移除的属性**：
- 所有活动相关（礼包、签到、祈愿等）
- 匹配流程相关（开始匹配、取消匹配等）
- 英雄选择相关
- 返回按钮、确定按钮等UI元素（除非lite函数使用）
- 分路设置、房主头像等组队相关

**判断方法**：
如果某个属性：
1. 在 `对战图片元素` 或 `对战图片元素_模拟战` 列表中 → 保留
2. 在 `大厅元素`、`房间元素`、`战绩页面元素` 列表中 → 保留
3. 被上述列表引用（如 self.普攻S） → 保留
4. 其他 → 移除

### 5. wzry_task 类（精简版）

**保留的方法**：

#### __init__ 方法（完整）
```python
def __init__(self, connect=True):
    # 完整保留所有初始化代码
    # 包括：
    # - assets_dir 设置
    # - 设备连接（self.移动端 = deviceOB(...)）
    # - Tool 初始化
    # - 图片对象初始化（self.图片 = wzry_figure(...)）
    # - APPOB 初始化
```

#### lite 识别函数（6个）
1. `lite_连接设备(self)` - 连接设备
2. `lite_当前画面(self)` - 获取截图
3. `lite_判断对战(self, screen=None)` - 判断是否在对战
4. `lite_判断死亡(self, img=None)` - 判断死亡状态
5. `lite_判断移动方向(self, img1=None, img2=None, custom_regions=None, figpath=None)` - 移动方向检测
6. `lite_判断当前界面(self, only_norm=True)` - 界面状态检测

#### 对战控制函数（3个）
1. `对战中_移动(self, angle=0.0, duration=1)` - 控制移动
2. `对战中_攻击(self, index=0)` - 控制攻击
3. `对战中_信号(self, index=0)` - 释放技能

#### 辅助函数
- `check_run_status(self)` - 检查设备状态
- 其他被 lite 函数调用的方法（智能识别）

**移除的方法**：
- 所有游戏流程自动化函数（200+ 个）
- 任务、活动、组队等功能
- 除上述列表外的所有其他方法

### 6. 图片资源

**提取方法**：
1. 从保留的代码中搜索所有 `Template(r"xxx.png")` 语句
2. 提取文件名列表
3. 从 `D:/SoftData/git/autowzry/autowzry/assets/` 复制这些文件

**预期数量**：20-40 个 PNG 文件

**配置文件**：
- `android.960.540.dict.yaml` - 分辨率配置

## 需要移除的内容

### 移除原则

**如果代码满足以下任一条件，则移除**：
1. 不在上述"需要保留的内容"列表中
2. 与游戏自动化流程相关（打金、任务、匹配、组队等）
3. 与活动、礼包、签到等辅助功能相关
4. 是UI自动化代码（点击、滑动流程），但不被 lite 函数使用

### 具体移除列表

#### wzry_figure 类中移除
- 大厅活动、祈愿、灵宝、战令相关图片
- 邮件、个人中心相关图片
- 匹配流程图片（进入匹配、确定匹配等）
- 英雄选择、分路设置图片
- 返回按钮、确定按钮等通用UI元素
- 火焰山、梦境大乱斗、模拟战入口等模式图标（除非检测需要）

#### wzry_task 类中移除
- `进入对战房间`、`进行人机匹配` 等自动化流程函数
- `领取奖励`、`完成任务` 等辅助功能
- `组队`、`创建房间` 等组队功能
- 除 lite 函数和对战控制外的所有其他方法

## 代码组织结构

### wzry.py 文件结构

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# 1. 文件头部
#    - 编码声明
#    - import 语句
#    - 许可证（如果有）
#    - 全局变量

# 2. 工具函数
#    - 版本号()
#    - 项目介绍()

# 3. wzry_runinfo 类（简化版）

# 4. wzry_figure 类（精简版）
#    - __init__ 方法
#    - 只保留必要的图片元素定义

# 5. wzry_task 类（精简版）
#    - __init__ 方法
#    - lite 识别函数（6个）
#    - 对战控制函数（3个）
#    - 辅助函数
```

### version.py 文件结构

```python
# 保留所有 last_modified 行
last_modified = "2025-11-05 13:55:10"
last_modified = "2025-11-11 16:03:36"
...
last_modified = "2025-11-19 13:31:53"

# 添加 lite 版本信息
lite_build_time = "2025-11-24 10:30:00"
lite_source_version = "2025-11-19 13:31:53"
```

### __init__.py 文件结构

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""autowzry_lite - 精简版识别库"""

from .wzry import wzry_task, wzry_figure

__all__ = ['wzry_task', 'wzry_figure']
```

## 智能判断规则

### 函数依赖分析

**如果 lite 函数调用了 self.xxx() 方法**：
1. 检查该方法是否已在保留列表中
2. 如果不在，判断它是否是外部对象的方法：
   - `self.Tool.xxx()` → 外部对象，不需要提取
   - `self.移动端.xxx()` → 外部对象，不需要提取
   - `self.图片.xxx` → 访问图片属性，不需要提取方法
   - `self.APPOB.xxx()` → 外部对象，不需要提取
3. 如果是 wzry_task 自身的方法，考虑提取

### 图片元素判断

**对于 wzry_figure 中的每个属性**：
1. 如果被添加到 `对战图片元素` 列表 → 保留
2. 如果被添加到 `大厅元素`、`房间元素`、`战绩页面元素` → 保留
3. 如果在 lite 函数代码中被引用 → 保留
4. 否则 → 移除

### 代码块完整性

**提取代码时保持完整性**：
- 提取函数包含从 `def` 到下一个同级定义之间的所有内容
- 包括文档字符串、注释、空行
- 包括函数内的所有逻辑分支（if/else/try/except）

## 验证规则

### 构建后验证

**生成的 autowzry_lite 应该满足**：
1. 可以被 autowzry-agent 的 compatibility.py 导入
2. `wzry_task(connect=False)` 可以成功初始化
3. 所有 lite 函数都存在且签名正确
4. 所有引用的图片文件都已复制
5. 没有语法错误（Python 可以 import）

### 功能验证清单

- [ ] import 语句完整，没有缺失的依赖
- [ ] wzry_task 类可以实例化
- [ ] lite_连接设备 可以调用
- [ ] lite_当前画面 可以调用
- [ ] lite_判断对战 可以调用
- [ ] lite_判断死亡 可以调用
- [ ] lite_判断移动方向 可以调用
- [ ] lite_判断当前界面 可以调用
- [ ] 对战中_移动 可以调用
- [ ] 对战中_攻击 可以调用
- [ ] 对战中_信号 可以调用
- [ ] assets 目录下的图片可以被 Template 加载

## 特殊情况处理

### 情况1：函数名变化

**如果 autowzry 更新后函数名改变**：
- 搜索关键字而非固定函数名
- 例如：搜索所有以 `lite_` 开头的函数
- 在构建日志中记录找到的函数列表

### 情况2：新增 lite 函数

**如果发现新的 lite_ 函数**：
- 自动提取所有 lite_ 前缀的函数
- 在构建日志中标注新增的函数

### 情况3：依赖关系变化

**如果 lite 函数开始依赖新的辅助方法**：
- 通过代码分析识别新的依赖
- 提取这些依赖方法
- 在构建日志中记录依赖变化

### 情况4：图片文件缺失

**如果代码引用的图片文件不存在**：
- 在构建日志中记录警告
- 继续构建（可能是废弃的代码）
- 不终止构建过程

## 与 autowzry-agent 的兼容性

### compatibility.py 的期望

autowzry-agent 的 compatibility.py 期望：
```python
from autowzry.wzry import wzry_task

# 初始化（不连接设备）
autowzry = wzry_task(connect=False)

# 调用 lite 函数
screen = autowzry.lite_当前画面()
is_in_battle = autowzry.lite_判断对战(screen=screen)
is_dead = autowzry.lite_判断死亡(frame=screen)
direction = autowzry.lite_判断移动方向(img1, img2)

# 调用控制函数
autowzry.对战中_移动(angle=90, duration=1)
autowzry.对战中_攻击(index=0)
```

**兼容性要求**：
1. 类名必须是 `wzry_task`
2. `__init__(connect=False)` 必须支持不连接设备
3. 所有 lite 函数签名必须与完整版一致
4. 所有对战控制函数签名必须与完整版一致

### 不依赖的功能

autowzry-agent **不使用**以下功能，可以安全移除：
- 自动匹配、自动组队
- 自动完成任务
- 自动领取奖励
- 自动进入对战房间
- UI自动化流程（除了控制函数）

## 总结

**核心原则总结**：
1. 保留 lite 函数的完整功能
2. 移除所有游戏自动化相关代码
3. 保持与 autowzry-agent 的兼容性
4. 记录完整的构建日志
5. 智能适应代码变化

**判断准则**：
- 如果不确定是否保留某段代码，检查 lite 函数是否使用它
- 如果不确定是否保留某个图片，检查代码是否引用它
- 如果不确定某个方法是否需要，分析依赖关系

**灵活性**：
- Agent 应该智能判断，而非死板遵循规则
- 代码变化时，Agent 应该理解意图并调整策略
- 优先保证功能完整性，其次考虑代码精简
