"""
游戏状态检测模块

职责：
1. 检测游戏状态（死亡、击杀、助攻等）
2. 返回状态字典（True/False）
3. 根据状态字典计算得分
"""


class GameState:
    """游戏状态检测和得分计算"""

    def __init__(self, compatibility_layer, enabled_states=None):
        """
        初始化游戏状态模块

        参数:
            compatibility_layer: 兼容层实例（用于调用检测函数）
            enabled_states: 启用的状态列表，如 ['dead', 'alive', 'kill', 'assist']
                          None 表示使用默认值
        """
        self.compat = compatibility_layer

        # 启用的状态列表
        if enabled_states is None:
            enabled_states = ['in_battle', 'dead', 'alive', 'kill', 'assist']
        self.enabled_states = enabled_states

        # 状态对应的得分
        self.state_scores = {
            'in_battle': 0,     # 不参与得分，只用于筛选
            'dead': -2,
            'alive': 0.01,
            'kill': 1,
            'assist': 1
        }

        print(f"[GameState] Initialized")
        print(f"  Enabled states: {self.enabled_states}")
        print(f"  State scores: {self.state_scores}")

    def get_frame_state(self, frame1, frame2) -> dict:
        """
        获取当前帧的状态字典

        参数:
            frame1: 当前帧图像
            frame2: 下一帧图像（用于检测kill/assist变化）

        返回:
            状态字典，如 {'in_battle': True, 'dead': False, 'alive': True, 'kill': False, 'assist': False}
        """
        state_dict = {}

        # 检测是否在战斗中
        in_battle = self.compat.is_in_battle(screen=frame1)

        if 'in_battle' in self.enabled_states:
            state_dict['in_battle'] = in_battle

        # dead 和 alive 只在 in_battle 时判断
        if in_battle:
            is_dead = self.compat.is_dead(frame=frame1)
            if 'dead' in self.enabled_states:
                state_dict['dead'] = is_dead
            if 'alive' in self.enabled_states:
                state_dict['alive'] = not is_dead
        else:
            # 不在战斗中，都是 False，不参与统计
            if 'dead' in self.enabled_states:
                state_dict['dead'] = False
            if 'alive' in self.enabled_states:
                state_dict['alive'] = False

        # 检测击杀（比较两帧的击杀数）
        if 'kill' in self.enabled_states:
            kill_count1 = self.compat.detect_kill_count(frame=frame1)
            kill_count2 = self.compat.detect_kill_count(frame=frame2)
            state_dict['kill'] = kill_count2 > kill_count1

        # 检测助攻（比较两帧的助攻数）
        if 'assist' in self.enabled_states:
            assist_count1 = self.compat.detect_assist_count(frame=frame1)
            assist_count2 = self.compat.detect_assist_count(frame=frame2)
            state_dict['assist'] = assist_count2 > assist_count1

        return state_dict

    def sum_reward(self, state_dict: dict) -> float:
        """
        根据状态字典计算总得分

        参数:
            state_dict: 状态字典，如 {'dead': False, 'alive': True, 'kill': True, 'assist': False}

        返回:
            总得分
        """
        total = 0.0

        for state_name in self.enabled_states:
            if state_name in state_dict and state_dict[state_name]:
                # 状态为True时，累加对应得分
                total += self.state_scores.get(state_name, 0.0)

        return total


if __name__ == '__main__':
    # 测试代码
    print("Testing GameState...")

    # 模拟兼容层
    class MockCompat:
        def is_dead(self, frame):
            return False

    compat = MockCompat()
    game_state = GameState(compat)

    # 测试获取状态
    import numpy as np
    dummy_frame = np.zeros((540, 960, 3), dtype=np.uint8)
    state_dict = game_state.get_frame_state(dummy_frame)
    print(f"\nState dict: {state_dict}")

    # 测试计算得分
    test_state = {'dead': False, 'alive': True, 'kill': True, 'assist': False}
    reward = game_state.sum_reward(test_state)
    print(f"\nTest state: {test_state}")
    print(f"Total reward: {reward}")  # 应该是 0.01 + 1 = 1.01

    print("\n[OK] All tests passed!")
