"""
动作空间模块

定义游戏的动作空间，提供：
1. 动作空间定义（哪些action及其维度）
2. 模型输出转换为cmd
3. 执行动作（委托给兼容层）
4. 查询接口（供其他模块使用）
"""

from typing import Dict, List, Optional, Tuple
import numpy as np


class ActionSpace:
    """
    动作空间定义

    核心职责：
    1. 定义动作空间结构（如 move:4维, attack:10维）
    2. 将模型输出转换为cmd字典
    3. 执行动作（委托给兼容层）
    4. 提供查询接口

    示例:
        action_space = ActionSpace(compat, enabled_actions=['move', 'attack'])

        # 查询
        print(action_space.get_total_dim())  # 14
        print(action_space.get_action_keys())  # ['move', 'attack']

        # 模型输出转cmd
        model_output = np.array([0.1, 0.2, 0.3, 0.4, 0.5, ...])  # 14维
        cmd = action_space.output_to_cmd(model_output)
        # cmd = {'move': [0.1, 0.2, 0.3, 0.4], 'attack': [0.5, ...]}

        # 执行
        action_space.execute_action(cmd)
    """

    def __init__(
        self,
        compatibility_layer=None,
        enabled_actions: Optional[List[str]] = None
    ):
        """
        初始化动作空间

        参数:
            compatibility_layer: 兼容层实例
            enabled_actions: 启用的动作列表，如 ['move', 'attack', 'skill']
                           None 表示使用默认值 ['move', 'attack']
        """
        self.compat = compatibility_layer

        if enabled_actions is None:
            enabled_actions = ['move', 'attack']

        self.enabled_actions = enabled_actions

        # 定义动作空间：{action_name: dimension}
        self.actions: Dict[str, int] = {}

        if 'move' in enabled_actions:
            self.actions['move'] = 4  # 上, 下, 左, 右

        if 'attack' in enabled_actions:
            self.actions['attack'] = 10  # 10个攻击目标

        if 'skill' in enabled_actions:
            self.actions['skill'] = 10  # 10个技能

        # 动作奖励权重：执行不同动作获得的奖励
        # 用于训练时根据执行的动作索引获取奖励
        self.action_rewards: Dict[str, List[float]] = {
            'move': [0.01, 0.01, 0.01, 0.1],  # 上, 下, 左, 右（所有移动+0.01，向右+0.1，10倍奖励）
            'attack': [0.0] * 10,
            'skill': [0.0] * 10
        }

        print(f"[ActionSpace] Initialized with actions: {self.actions}")
        print(f"[ActionSpace] Total dimension: {self.get_total_dim()}")

    # ==================== 查询接口 ====================

    def get_action_keys(self) -> List[str]:
        """
        获取激活的action名称列表

        返回:
            ['move', 'attack'] 等
        """
        return list(self.actions.keys())

    def get_action_dims(self) -> Dict[str, int]:
        """
        获取每个action的维度

        返回:
            {'move': 4, 'attack': 10}
        """
        return self.actions.copy()

    def get_total_dim(self) -> int:
        """
        获取总维度（所有action维度之和）

        返回:
            总维度数
        """
        return sum(self.actions.values())

    # ==================== 模型输出转换 ====================

    def output_to_cmd(self, model_output: np.ndarray) -> Dict[str, List[float]]:
        """
        将模型输出转换为cmd字典

        参数:
            model_output: 模型输出的一维数组，长度应等于 get_total_dim()
                         例如：[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, ...]

        返回:
            cmd字典，例如：
            {
                'move': [0.1, 0.2, 0.3, 0.4],
                'attack': [0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4]
            }
        """
        if len(model_output) != self.get_total_dim():
            raise ValueError(
                f"模型输出维度 {len(model_output)} 与动作空间维度 {self.get_total_dim()} 不匹配"
            )

        cmd = {}
        start_idx = 0

        for action_name, dim in self.actions.items():
            end_idx = start_idx + dim
            cmd[action_name] = model_output[start_idx:end_idx].tolist()
            start_idx = end_idx

        return cmd

    # ==================== 获取cmd ====================

    def get_cmd(self, actions: Optional[List[str]] = None, img1=None, img2=None) -> Dict[str, List[float]]:
        """
        获取cmd（从兼容层获取当前状态的动作数据）

        参数:
            actions: 要获取的action列表，None表示获取所有激活的action
            img1: 第一张图片（用于移动方向检测）
            img2: 第二张图片（用于移动方向检测）

        返回:
            cmd字典，例如：
            {
                'move': [0.1, 0.2, 0.3, 0.4],
                'attack': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            }
        """
        if actions is None:
            actions = self.get_action_keys()

        cmd = {}

        for action_name in actions:
            if action_name == 'move':
                # 调用兼容层检测移动方向
                if self.compat is not None:
                    cmd['move'] = self.compat.detect_movement_direction(img1, img2)
                else:
                    cmd['move'] = [0.0, 0.0, 0.0, 0.0]

            elif action_name == 'attack':
                # 暂时返回全0
                cmd['attack'] = [0.0] * 10

            elif action_name == 'skill':
                # 暂时返回全0
                cmd['skill'] = [0.0] * 10

        return cmd

    # ==================== 执行接口 ====================

    def execute_action(self, cmd: Dict[str, List[float]]):
        """
        执行动作（委托给兼容层）

        参数:
            cmd: 动作命令字典，例如：
                {
                    'move': [0.1, 0.2, 0.3, 0.4],  # 上下左右的得分
                    'attack': [0, 0, 1, 0, ...]     # 10个目标的得分
                }
        """
        if self.compat is None:
            print("[ActionSpace] Warning: No compatibility layer, skip execution")
            return

        # 委托给兼容层执行
        if 'move' in cmd:
            self.compat.execute_move(cmd)

        if 'attack' in cmd:
            self.compat.execute_attack(cmd)

        if 'skill' in cmd:
            self.compat.execute_skill(cmd)

    # ==================== 帧动作和奖励计算 ====================

    def get_frame_action(self, frame1, frame2) -> Dict[str, List[float]]:
        """
        获取当前帧的动作字典

        参数:
            frame1: 当前帧图像
            frame2: 下一帧图像（用于推断移动方向）

        返回:
            动作字典，如 {'move': [0,0,0,1], 'attack': [0]*10}
        """
        action_dict = {}

        for action_name in self.enabled_actions:
            if action_name == 'move':
                # 通过两帧推断移动方向
                if self.compat is not None:
                    action_dict['move'] = self.compat.detect_movement_direction(frame1, frame2)
                else:
                    action_dict['move'] = [0.0, 0.0, 0.0, 0.0]

            elif action_name == 'attack':
                # 暂时返回全0
                action_dict['attack'] = [0.0] * 10

            elif action_name == 'skill':
                # 暂时返回全0
                action_dict['skill'] = [0.0] * 10

        return action_dict

    def get_action_slices(self) -> List[Tuple[int, int]]:
        """
        获取每个action在模型输出中的索引范围

        返回:
            [(start, end), ...] 例如 [(0, 4), (4, 14)]
        """
        slices = []
        start = 0
        for action_name in self.enabled_actions:
            dim = self.actions[action_name]
            slices.append((start, start + dim))
            start += dim
        return slices

    def get_action_rewards_list(self) -> List[List[float]]:
        """
        获取每个action的rewards数组（按enabled_actions顺序）

        返回:
            [[0, 0, 0, 0.1], [0]*10, ...]
        """
        return [self.action_rewards[name] for name in self.enabled_actions]


if __name__ == '__main__':
    # 测试代码
    print("Testing ActionSpace...")

    # 测试初始化
    action_space = ActionSpace(
        compatibility_layer=None,
        enabled_actions=['move', 'attack']
    )

    # 测试查询接口
    print("\n=== Query Interface ===")
    print(f"Action keys: {action_space.get_action_keys()}")
    print(f"Action dims: {action_space.get_action_dims()}")
    print(f"Total dim: {action_space.get_total_dim()}")

    # 测试模型输出转换
    print("\n=== Model Output to CMD ===")
    model_output = np.random.rand(14)  # 4 + 10 = 14
    print(f"Model output shape: {model_output.shape}")

    cmd = action_space.output_to_cmd(model_output)
    print(f"CMD: {cmd}")
    print(f"  move: {len(cmd['move'])} values")
    print(f"  attack: {len(cmd['attack'])} values")

    # 测试执行（无兼容层，应跳过）
    print("\n=== Execute Action ===")
    action_space.execute_action(cmd)

    # 测试get_frame_action
    print("\n=== Get Frame Action ===")
    action_dict = action_space.get_frame_action(None, None)
    print(f"Action dict: {action_dict}")

    print("\n[OK] All tests passed!")
