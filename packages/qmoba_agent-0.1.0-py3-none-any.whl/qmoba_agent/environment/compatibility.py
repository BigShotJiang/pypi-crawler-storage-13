"""
兼容层模块 - 整合 autowzry API，支持离线视频和在线对战两种模式

项目说明：
- autowzry-agent: 本项目，基于强化学习的游戏AI训练框架
- autowzry: 图像识别库，提供游戏画面检测和设备控制功能
- autowzry_lite: autowzry的精简版本，包含在本项目的util目录下

此模块提供统一接口，封装：
1. 在线模式：使用 autowzry 库 + airtest_mobileauto 控制真实设备
2. 离线模式：从视频文件读取帧进行训练

作者：autowzry-agent
日期：2025-11-14
"""

import sys
import os
import numpy as np
from typing import Optional, Dict, Any, Tuple
import cv2
import time

# autowzry 库将在 CompatibilityLayer.__init__ 中根据 config.use_autowzry_lite 动态导入


class CompatibilityLayer:
    """
    兼容层 - 统一接口支持在线/离线模式

    在线模式：
        - 使用 autowzry.lite_当前画面() 获取实时画面
        - 使用 autowzry.对战中_移动/攻击 控制游戏
        - 使用 autowzry.lite_判断对战/死亡 进行状态检测

    离线模式：
        - 从视频文件读取帧
        - 不支持动作执行（纯训练）
    """

    def __init__(self,
                 mode: str = "offline",
                 config=None,
                 autowzry_config: Optional[str] = None,
                 video_reader=None,
                 video_path: Optional[str] = None,
                 frame_interval: int = 2,
                 interval: Optional[float] = None,
                 check_interval: int = 30):
        """
        初始化兼容层

        Args:
            mode: "online" 或 "offline"
            config: Config 配置对象（autowzry-agent的配置）
            autowzry_config: autowzry库的配置文件路径（字符串，在线模式需要，用于设备连接）
            video_reader: VideoReader 实例（离线模式可选，优先使用此参数）
            video_path: 视频文件路径（离线模式可选，video_reader为None时自动创建）
            frame_interval: 帧间隔（离线模式，默认2表示每3帧取1帧）
            interval: 采样间隔（秒），如果指定，会根据视频帧率自动计算跳帧
            check_interval: 设备连接检查间隔（秒），默认30秒
        """
        # 配置管理
        if config is None:
            from qmoba_agent.config.config import Config
            config = Config.default()
        self.config = config
        self.use_autowzry_lite = config.use_autowzry_lite

        # 根据 config.use_autowzry_lite 动态导入 autowzry
        source_name = "autowzry_lite" if self.use_autowzry_lite else "autowzry"
        try:
            from airtest_mobileauto.control import Settings
            self.Settings = Settings

            if self.use_autowzry_lite:
                # 使用本地 autowzry_lite
                from qmoba_agent.autowzry_lite.autowzry.wzry import wzry_task
            else:
                # 使用已安装的 autowzry
                from autowzry.wzry import wzry_task

            print(f"[OK] 使用 {source_name}")
        except ImportError as e:
            raise ImportError(f"无法导入 {source_name}: {e}")

        # 初始化基本属性
        self.mode = mode
        self.autowzry = wzry_task(connect=False)  # 统一延迟连接
        self.video_reader = None
        self.frame_iterator = None

        # 帧计数器和元数据
        self.capture_count = 0
        self.start_time = time.time()
        self.current_frame_idx = 0

        # 设备连接状态管理（在线模式使用）
        self.device_connected = False
        self.last_check_time = 0
        self.check_interval = check_interval

        # 视频延迟初始化配置（离线模式使用）
        self._video_path = video_path
        self._frame_interval = frame_interval
        self._interval = interval
        self._video_initialized = False

        # 配置 airtest_mobileauto（在线和离线都需要）
        if autowzry_config is None:
            autowzry_config = self.config.autowzry_config
        if autowzry_config is not None:
            if not isinstance(autowzry_config, str):
                raise TypeError(f"autowzry_config 必须是字符串路径，但收到: {type(autowzry_config)}")
            self.Settings.Config(autowzry_config)

        # 特殊处理：如果直接提供了 video_reader，立即初始化
        if video_reader is not None:
            self.video_reader = video_reader
            self.frame_iterator = iter(video_reader)
            self._video_initialized = True

        # 验证模式
        if mode not in ["online", "offline"]:
            raise ValueError(f"无效的模式: {mode}，应为 'online' 或 'offline'")

        # 打印初始化信息
        if mode == "online":
            print(f"[OK] Compatibility layer initialized (online mode, source: {source_name})")
        else:
            if video_reader is not None:
                print(f"[OK] Compatibility layer initialized (offline mode, using VideoReader, source: {source_name})")
            elif video_path is not None:
                print(f"[OK] Compatibility layer initialized (offline mode, video on demand, source: {source_name})")
                print(f"  Video: {video_path}")
            else:
                print(f"[OK] Compatibility layer initialized (offline mode, data-only, source: {source_name})")

        # 初始化 action 模块
        from qmoba_agent.environment.action_space import ActionSpace
        self.action = ActionSpace(
            compatibility_layer=self,
            enabled_actions=self.config.enabled_actions
        )

        # 初始化 game_state 模块
        from qmoba_agent.environment.game_state import GameState
        self.game_state = GameState(
            compatibility_layer=self,
            enabled_states=self.config.enabled_states
        )

        # 初始化 data_manager 模块
        from qmoba_agent.data.data_manager import DataManager
        self.data_manager = DataManager(
            compatibility_layer=self,
            action_space=self.action,
            game_state=self.game_state
        )

        # 如果启用训练，初始化 buffer
        if self.config.enable_training:
            from qmoba_agent.data.training_buffer import TrainingBuffer
            self.training_buffer = TrainingBuffer(
                data_manager=self.data_manager,
                action_space=self.action,
                game_state=self.game_state,
                capacity=self.config.buffer_capacity,
                config=self.config
            )

    # ==================== 视频延迟初始化管理 ====================

    def _ensure_video_initialized(self) -> bool:
        """
        确保视频已初始化（延迟加载）

        策略：
        1. 如果已经初始化过，直接返回 True
        2. 如果没有提供视频路径，返回 False
        3. 首次调用时打开视频文件

        Returns:
            bool: 初始化成功返回 True，失败返回 False
        """
        if self.mode != "offline":
            return False

        # 已经初始化过
        if self._video_initialized:
            return True

        # 没有提供视频路径
        if self._video_path is None:
            return False

        # 首次初始化视频
        print(f"[Video] 首次打开视频文件...")
        try:
            from qmoba_agent.utils.video_reader import VideoReader

            if not os.path.exists(self._video_path):
                raise FileNotFoundError(f"视频文件不存在: {self._video_path}")

            self.video_reader = VideoReader(
                self._video_path,
                frame_interval=self._frame_interval,
                interval=self._interval
            )
            self.frame_iterator = iter(self.video_reader)
            self._video_initialized = True

            print(f"[Video] [OK] 视频文件已打开")
            if self._interval:
                print(f"  Interval: {self._interval}s (frame_interval: {self.video_reader.frame_interval})")
            else:
                print(f"  Frame interval: {self._frame_interval}")
            print(f"  FPS: {self.video_reader.original_fps:.2f}")
            print(f"  Resolution: {self.video_reader.frame_width}x{self.video_reader.frame_height}")

            return True

        except Exception as e:
            print(f"[Video] [ERROR] 视频初始化失败: {e}")
            return False

    # ==================== 设备连接管理 ====================

    def _ensure_device_connected(self) -> bool:
        """
        确保设备连接（简化版）

        策略：
        1. 首次调用时连接设备
        2. 之后假设连接正常（截图成功本身就证明设备在线）
        3. 不做定期检查（避免卡顿）

        Returns:
            bool: 连接成功返回 True，失败返回 False
        """
        if self.mode != "online":
            return False

        # 首次连接
        if not self.device_connected:
            print("[Device] 首次连接设备...")
            return self._connect_device()

        # 已连接过，假设连接正常
        # 截图成功本身就证明设备在线，不需要额外检查
        return True

    def _connect_device(self) -> bool:
        """
        两级重试连接设备

        1. 第一级：尝试 移动端.连接设备()
        2. 第二级：如果失败，尝试 移动端.重启重连设备()

        Returns:
            bool: 连接成功返回 True
        """
        try:
            # 第一级：尝试连接设备
            print("[Device] 尝试连接设备...")
            self.autowzry.lite_连接设备()

            # 验证连接是否成功
            if self.autowzry.check_run_status():
                print("[Device] [OK] 设备连接成功")
                self.device_connected = True
                self.last_check_time = time.time()
                return True

            # 第二级：连接失败，尝试重启重连
            print("[Device] [WARN] 连接失败，尝试重启重连设备...")
            self.autowzry.移动端.重启重连设备(timeout=60)  # 等待最多60秒
            self.autowzry.lite_连接设备()

            # 再次验证
            if self.autowzry.check_run_status():
                print("[Device] [OK] 重启重连成功")
                self.device_connected = True
                self.last_check_time = time.time()
                return True

            # 两级重试都失败
            print("[Device] [ERROR] 设备连接失败，所有重试均失败")
            return False

        except Exception as e:
            print(f"[Device] [ERROR] 连接异常: {e}")
            return False

    # ==================== 画面获取 ====================

    def capture_screen(self) -> np.ndarray:
        """
        获取当前画面（统一接口）

        Returns:
            np.ndarray: RGB 格式的图像 (H, W, 3), uint8
        """
        if self.mode == "online":
            # 在线模式：延迟连接设备
            if not self._ensure_device_connected():
                raise RuntimeError("设备连接失败，无法获取画面")

            frame = self.autowzry.lite_当前画面()
            self.capture_count += 1
            return frame

        else:
            # 离线模式：延迟初始化视频
            if not self._ensure_video_initialized():
                raise RuntimeError(
                    "离线模式下未提供视频源，无法获取画面。\n"
                    "如需从视频读取帧，请在初始化时提供 video_reader 或 video_path 参数。"
                )

            try:
                frame_idx, frame = next(self.frame_iterator)
                self.current_frame_idx = frame_idx
                self.capture_count += 1
                return frame
            except StopIteration:
                raise StopIteration("视频已读取完毕")

    def detect_movement_direction(self, img1=None, img2=None, usemode: bool = False) -> list:
        '''
        检测移动方向得分。

        参数:
        img1 -- 第一张图片
        img2 -- 第二张图片，如果未提供则获取设备上的截图
        usemode -- 如果为 True，则直接返回上下左右的概率分布作为移动方向得分向量。

        返回:
        返回格式为 [上得分, 下得分, 左得分, 右得分] 的列表，这四个分值反映了移动方向的概率分布。
        '''
        if usemode:
            #若是真则不通过img做分析，直接返回上下左右的概率分布，但目前该概率分布固定为向右移动，代码仅用于测试模型。
            return [0.0, 0.0, 0.0, 1.0]

        if img2 is None:
            #如果img2未提供，会先从设备上获取截图
            img2 = self.capture_screen()
        #调用 autowzry 的lite功能函数进行实际的方向分析
        result = self.autowzry.lite_判断移动方向(img1=img1, img2=img2)
        #返回实际方向分析的结果
        return result

    def get_frame_metadata(self) -> Dict[str, Any]:
        """
        获取当前帧的元数据（统一接口）

        Returns:
            dict: 包含 frame_idx, timestamp, source 等信息
        """
        if self.mode == "online":
            return {
                'frame_idx': self.capture_count - 1,
                'timestamp': time.time() - self.start_time,
                'source': 'device',
                'mode': 'online'
            }
        else:
            # 离线模式：基于视频FPS计算时间戳
            if self.video_reader is None:
                return {
                    'frame_idx': self.capture_count - 1,
                    'timestamp': 0.0,
                    'source': 'unknown',
                    'mode': 'offline'
                }

            return {
                'frame_idx': self.current_frame_idx,
                'timestamp': self.current_frame_idx / self.video_reader.original_fps,
                'source': 'video',
                'mode': 'offline',
                'video_fps': self.video_reader.original_fps
            }

    # ==================== 状态判断 ====================

    def is_in_battle(self, screen: Optional[np.ndarray] = None) -> bool:
        """
        判断是否处于对战中

        Args:
            screen: 可选，指定画面。None 则自动获取当前画面

        Returns:
            bool: True 表示在对战中
        """
        if self.mode == "online":
            if screen is None:
                screen = self.capture_screen()
            return self.autowzry.lite_判断对战(screen=screen)

        else:
            # 离线模式：简化判断（实际应用中可用 OCR 或其他方法）
            # 这里假设视频中都是对战画面
            return True

    def is_dead(self, frame: Optional[np.ndarray] = None) -> bool:
        """
        判断是否死亡

        Args:
            frame: 可选，指定画面。None 则自动获取当前画面

        Returns:
            bool: True 表示已死亡
        """
        if frame is None:
            frame = self.capture_screen()
        return self.autowzry.lite_判断死亡(frame)

    def detect_kill_count(self, frame: Optional[np.ndarray] = None) -> int:
        """
        检测击杀数

        Args:
            frame: 可选，指定画面

        Returns:
            int: 击杀数
        """
        # 注意：根据 image.py 和 wzry.py，此功能暂未开发
        # 无论在线还是离线模式都返回 0
        return 0

    def detect_assist_count(self, frame: Optional[np.ndarray] = None) -> int:
        """
        检测助攻数

        Args:
            frame: 可选，指定画面

        Returns:
            int: 助攻数
        """
        # 注意：根据 image.py 和 wzry.py，此功能暂未开发
        # 无论在线还是离线模式都返回 0
        return 0

    # ==================== 动作执行 ====================
    def enter_battle_state(self):
        '''
        进入对战状态

        离线模式：循环截图直到检测到进入对战状态
        在线模式 + autowzry_lite：循环截图直到检测到进入对战状态（需手动进入，每10秒检测一次）
        在线模式 + autowzry：自动调用进入对战房间和人机匹配
        '''
        if self.mode == 'offline':
            # 离线模式：循环截图检测
            while not self.is_in_battle(screen=self.capture_screen()):
                pass
            print('[OK] 离线模式：已进入对战状态')

        elif self.mode == 'online':
            if not self._ensure_device_connected():
                raise RuntimeError('设备连接失败')

            if self.use_autowzry_lite:
                # autowzry_lite：提示手动进入，每10秒检测一次
                print('[提示] 使用autowzry_lite，不支持自动进入对战，请手动进入对战')
                while not self.is_in_battle(screen=self.capture_screen()):
                    time.sleep(10)
                print('[OK] 在线模式(autowzry_lite)：已进入对战状态')

            else:
                # autowzry：自动进入对战
                self.autowzry.进入对战房间()
                self.autowzry.进行人机匹配()
                print('[OK] 在线模式(autowzry)：已调用进入对战')

    def execute_move(self, cmd={}):
        '''
        执行移动动作

        参数:
        cmd -- 命令字典，包含：
            'move': [上, 下, 左, 右] 四个方向的得分/概率
            'move_duration': 移动持续时间（可选，默认为1）

        在线模式：根据最大得分方向执行移动
        离线模式：不处理
        '''
        if self.mode == 'offline':
            return

        # 获取移动方向和持续时间
        move = cmd.get('move', [0, 0, 0, 0])
        duration = cmd.get('move_duration', 1)

        # 转换为 numpy 数组
        move_array = np.array(move)

        # 找到最大值和索引
        max_value = float(np.max(move_array))

        # 如果最大值太小，不移动
        if max_value < 1e-6:
            print(f'execute_move: skipped (max_value={max_value:.3e} too low)')
            #return
            pass

        max_idx = int(np.argmax(move_array))

        # 方向映射：[上, 下, 左, 右] -> [90, 270, 180, 0]
        angle_map = [90.0, 270.0, 180.0, 0.0]
        angle = angle_map[max_idx]

        # 调用autowzry移动函数
        self.autowzry.对战中_移动(angle=angle, duration=duration)
        print(f'execute_move: angle={angle}, duration={duration}, move={move}')


    def execute_attack(self, cmd={}):
        '''
        执行攻击动作

        参数:
        cmd -- 命令字典，包含：
            'attack': 10个元素的数组，表示不同攻击目标的得分/概率

        在线模式：根据最大得分执行攻击
        离线模式：不处理
        '''
        if self.mode == 'offline':
            return

        # 获取攻击目标数组
        attack = cmd.get('attack', [0] * 10)

        # 找到最大值的索引
        index = attack.index(max(attack))

        # 调用autowzry攻击函数
        self.autowzry.对战中_攻击(index=index)


    def execute_skill(self, cmd={}):
        '''
        执行技能动作

        参数:
        cmd -- 命令字典，包含：
            'skill': 10个元素的数组，表示不同技能的得分/概率

        在线模式：根据最大得分执行技能
        离线模式：不处理
        '''
        if self.mode == 'offline':
            return

        # 获取技能数组
        skill = cmd.get('skill', [0] * 10)

        # 找到最大值的索引
        index = skill.index(max(skill))

        # 调用autowzry技能函数
        self.autowzry.对战中_信号(index=index)


    # ==================== 辅助功能 ====================

    def detect_interface(self, only_norm: bool = True) -> str:
        """
        检测当前界面状态

        Args:
            only_norm: 是否只判断常规界面

        Returns:
            str: 界面状态（"大厅中", "房间中", "对战中", "战绩页面", "未知"）
        """
        if self.mode == "online":
            return self.autowzry.lite_判断当前界面(only_norm=only_norm)
        else:
            # 离线模式：假设视频都是对战画面
            return "对战中"

    def cleanup(self):
        """
        清理资源
        """
        if self.mode == "online" and self.autowzry is not None:
            # 可以在这里添加清理代码
            pass
        print("[OK] Cleanup completed")


# ==================== 测试代码（仅离线模式） ====================

def test_offline_mode():
    """
    测试离线模式（使用视频文件）
    """
    print("=" * 60)
    print("测试：兼容层 - 离线模式")
    print("=" * 60)

    # 导入 VideoReader
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
    from utils.video_reader import VideoReader

    # 初始化视频读取器
    video_path = "D:/Desktop/autowzry-agent/moive/1.mp4"
    if not os.path.exists(video_path):
        print(f"[ERROR] Video file not found: {video_path}")
        return

    video_reader = VideoReader(video_path, frame_interval=2)
    print(f"[OK] Video reader initialized")

    # 初始化兼容层
    compat = CompatibilityLayer(mode="offline", video_reader=iter(video_reader))

    # 测试画面获取
    print("\n[Test] Capturing frames...")
    for i in range(3):
        try:
            frame = compat.capture_screen()
            print(f"  Frame {i+1}: shape={frame.shape}, dtype={frame.dtype}")
        except StopIteration:
            print("  [ERROR] Video finished")
            break

    # 测试状态判断
    print("\n[Test] State detection...")
    print(f"  In battle: {compat.is_in_battle()}")
    print(f"  Is dead: {compat.is_dead()}")
    print(f"  Kill count: {compat.detect_kill_count()}")
    print(f"  Assist count: {compat.detect_assist_count()}")

    # 测试动作执行（离线模式应跳过）
    print("\n[Test] Action execution (should be skipped in offline mode)...")
    action_move = {"type": "move", "angle": 90, "duration": 1}
    action_attack = {"type": "attack"}
    print(f"  Move action: {compat.execute_action(action_move)}")
    print(f"  Attack action: {compat.execute_action(action_attack)}")

    # 测试界面检测
    print("\n[Test] Interface detection...")
    print(f"  Current interface: {compat.detect_interface()}")

    # 清理
    compat.cleanup()

    print("\n[OK] Offline mode test completed")
    print("=" * 60)


if __name__ == "__main__":
    # 仅测试离线模式（不测试在线模式）
    test_offline_mode()
