"""
Trainer Module
"""

import os
import torch
import torch.nn.functional as F
import numpy as np
from typing import Optional
from qmoba_agent.core.lightweight_dqn import LightweightDQN as custom_model
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt


class Trainer:
    """Trainer for DQN"""

    def __init__(self, compatibility_layer, config):
        """
        Init trainer

        Args:
            compatibility_layer: CompatibilityLayer instance
            config: Config instance
        """
        self.compat = compatibility_layer
        self.config = config

        # Get modules from compatibility layer
        self.action = self.compat.action
        self.buffer = self.compat.training_buffer

        # Init model
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') if config.device == 'auto' else torch.device(config.device)
        self.model = self._init_model()
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=config.learning_rate)

        print(f"[Trainer] Init")
        print(f"  Device: {self.device}")
        print(f"  Model: {self.model.__class__.__name__}")
        print(f"  Learning rate: {config.learning_rate}")
        print(f"  Gamma: {config.gamma}")

        # Target Network
        if config.use_target_network:
            import copy
            self.target_model = copy.deepcopy(self.model)
            self.target_model.eval()
            print(f"  Using Target Network: True")
            print(f"  Target update every {config.target_update_epochs} epochs")
        else:
            self.target_model = self.model
            print(f"  Using Target Network: False")

        # Load model if resume_model is set
        if config.resume_model is not None and config.resume_model != '':
            if os.path.exists(config.resume_model):
                self.load_model(config.resume_model)
                # Update target network after loading
                if config.use_target_network:
                    self.target_model.load_state_dict(self.model.state_dict())
            else:
                print(f"[WARNING] Resume model not found: {config.resume_model}, starting from scratch")

        # Training history
        self.history = {
            'epoch': [],
            'loss': []
        }

        # Calculate samples_per_epoch
        buffer_size = len(self.buffer)
        if config.samples_per_epoch is None:
            # Default: use all buffer data
            self.samples_per_epoch = buffer_size
        else:
            self.samples_per_epoch = config.samples_per_epoch

        # Determine if we need to resample each epoch
        self.use_sampling = (self.samples_per_epoch < buffer_size)

        print(f"  Samples per epoch: {self.samples_per_epoch}")
        print(f"  Use sampling: {self.use_sampling}")

        # Prepare action reward tensors for GPU computation
        self.action_slices = self.action.get_action_slices()
        action_rewards_list = self.action.get_action_rewards_list()
        self.action_rewards_tensors = [
            torch.tensor(rewards, dtype=torch.float32, device=self.device)
            for rewards in action_rewards_list
        ]

        # AMP (Automatic Mixed Precision)
        self.use_amp = config.use_amp and torch.cuda.is_available()
        if self.use_amp:
            self.scaler = torch.amp.GradScaler('cuda')
            print(f"  Using AMP: True (FP16 mixed precision)")
        else:
            self.scaler = None
            print(f"  Using AMP: False")

    def _init_model(self):
        """Init model based on action space and train_resolution"""
        # Get train_resolution from config
        train_resolution = self.config.train_resolution  # [height, width, channels]
        height, width, _ = train_resolution

        # Get input_channels from buffer (determined by data format)
        input_channels = self.buffer.input_channels

        # Get num_actions from action space
        action_dims = self.action.get_action_dims()
        # Use total dimension of all enabled actions
        num_actions = self.action.get_total_dim()

        # Get model_mode from config
        model_mode = self.config.model_mode

        model = custom_model(
            input_channels=input_channels,
            input_height=height,
            input_width=width,
            num_actions=num_actions,
            mode=model_mode
        )
        model.to(self.device)

        print(f"  Train resolution: {train_resolution}")
        print(f"  Model mode: {model_mode}")
        print(f"  Input channels: {input_channels} (from buffer)")
        print(f"  Input size: {height}x{width}")
        print(f"  Action dims: {action_dims}")
        print(f"  Total output dim: {num_actions}")

        # Get model parameters breakdown
        params_breakdown = model.get_params_breakdown()
        print(f"  Total params: {params_breakdown['total']:,}")
        print(f"  Conv params: {params_breakdown['conv']:,} ({params_breakdown['conv_ratio']*100:.1f}%)")
        print(f"  Head params: {params_breakdown['head']:,} ({params_breakdown['head_ratio']*100:.1f}%)")

        return model

    def train(self):
        """Train the model"""
        print(f"\n[Train] Starting training...")
        print(f"  Epochs: {self.config.num_epochs}")
        print(f"  Batch size: {self.config.batch_size}")
        print(f"  Buffer size: {len(self.buffer)}")
        print(f"  Samples per epoch: {self.samples_per_epoch}")

        # If not using sampling, build DataLoader once before training
        dataloader = None
        if not self.use_sampling:
            dataloader = self.buffer.get_dataloader(
                batch_size=self.config.batch_size,
                shuffle=True,
                device=self.device,
                sample_size=None  # Use all data
            )

        for epoch in range(self.config.num_epochs):
            # If using sampling, build new DataLoader each epoch
            if self.use_sampling:
                dataloader = self.buffer.get_dataloader(
                    batch_size=self.config.batch_size,
                    shuffle=True,
                    device=self.device,
                    sample_size=self.samples_per_epoch
                )

            epoch_losses = []

            # Train all batches in this epoch
            for batch in dataloader:
                self.optimizer.zero_grad()

                if self.use_amp:
                    with torch.amp.autocast('cuda'):
                        loss = self._compute_loss(batch)
                    self.scaler.scale(loss).backward()
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                else:
                    loss = self._compute_loss(batch)
                    loss.backward()
                    self.optimizer.step()

                # Record batch loss
                epoch_losses.append(loss.item())

            # Calculate average loss for this epoch
            avg_loss = np.mean(epoch_losses)

            # Record training history
            self.history['epoch'].append(epoch + 1)
            self.history['loss'].append(avg_loss)

            # Update target network periodically
            if self.config.use_target_network and (epoch + 1) % self.config.target_update_epochs == 0:
                self.target_model.load_state_dict(self.model.state_dict())
                scale_info = f", Scale: {self.scaler.get_scale():.0f}" if self.use_amp else ""
                print(f"  Epoch {epoch+1}/{self.config.num_epochs}, Avg Loss: {avg_loss:.4f}{scale_info} [Target Network Updated]")
            elif (epoch + 1) % 10 == 0 or epoch == 0:
                scale_info = f", Scale: {self.scaler.get_scale():.0f}" if self.use_amp else ""
                print(f"  Epoch {epoch+1}/{self.config.num_epochs}, Avg Loss: {avg_loss:.4f}{scale_info}")

            # Save checkpoint periodically (overwrite same file)
            if (epoch + 1) % self.config.save_interval == 0:
                self.save_model()

        # Save final model (same as checkpoint)
        self.save_model()
        print(f"[Train] Done")

    def _compute_loss(self, batch):
        """
        Compute DQN loss

        Args:
            batch: Dict with keys ['state', 'next_state', 'move', 'reward']
                   All values are already tensors on self.device

        Returns:
            loss: Scalar tensor
        """
        # Data is already tensor and on device from DataLoader
        states = batch['state'].float()
        next_states = batch['next_state'].float()
        state_rewards = batch['reward'].float()  # (batch,) state rewards only
        move_labels = batch['move'].float()

        # Images are already preprocessed in CHW format (C, H, W) from buffer
        # No need for any format conversion

        # Current Q values
        q_values = self.model(states)  # (batch, total_dim)

        # Compute action rewards on GPU
        action_rewards = self._compute_action_reward(q_values)  # (batch,)

        # Total rewards = state rewards + action rewards
        rewards = state_rewards + action_rewards  # (batch,)

        # Get action index from labels (only use move for now)
        actions = move_labels.argmax(dim=1)  # (batch,)

        # Select Q value for executed action
        q_value = q_values.gather(1, actions.unsqueeze(1)).squeeze(1)  # (batch,)

        # Target Q values (use target network)
        with torch.no_grad():
            next_q_values = self.target_model(next_states)  # (batch, total_dim)
            max_next_q = next_q_values.max(dim=1)[0]  # (batch,)
            target_q = rewards + self.config.gamma * max_next_q

        # DQN loss
        loss = F.mse_loss(q_value, target_q)
        return loss

    def _compute_action_reward(self, q_values):
        """
        Compute action reward from Q values (on GPU)

        Args:
            q_values: (batch, total_dim) model output

        Returns:
            (batch,) action rewards
        """
        batch_size = q_values.shape[0]
        batch_rewards = torch.zeros(batch_size, device=self.device)

        for i, (start, end) in enumerate(self.action_slices):
            q_slice = q_values[:, start:end]  # (batch, action_dim)
            action_indices = q_slice.argmax(dim=1)  # (batch,)
            rewards = self.action_rewards_tensors[i][action_indices]  # (batch,)
            batch_rewards += rewards

        return batch_rewards

    def save_model(self, path: Optional[str] = None):
        """Save model"""
        if path is None:
            os.makedirs(self.config.checkpoint_dir, exist_ok=True)
            path = os.path.join(self.config.checkpoint_dir, f'model_{self.config.model_mode}.pth')

        # Use model's save method to include hyperparameters
        self.model.save(path)
        print(f"[Save] Model saved to: {path}")

    def load_model(self, path: str):
        """Load model"""
        checkpoint = torch.load(path, map_location=self.device)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        print(f"[Load] Model loaded from: {path}")

    def plot_training_history(self, save_dir: Optional[str] = None):
        """
        Plot training history (loss curve)

        Args:
            save_dir: Directory to save the plot. If None, use checkpoint_dir
        """
        if len(self.history['epoch']) == 0:
            print(f"[WARNING] No training history to plot")
            return

        if save_dir is None:
            save_dir = self.config.checkpoint_dir

        os.makedirs(save_dir, exist_ok=True)

        # Generate filename with timestamp
        from datetime import datetime
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        plot_path = os.path.join(save_dir, f'training_history_{timestamp}.png')
        txt_path = os.path.join(save_dir, f'training_history_{timestamp}.txt')

        # Save training history to txt file
        with open(txt_path, 'w', encoding='utf-8') as f:
            f.write('Epoch\tLoss\n')
            for epoch, loss in zip(self.history['epoch'], self.history['loss']):
                f.write(f'{epoch}\t{loss:.6f}\n')
        print(f"[Save] Training history data saved to: {txt_path}")

        # Create figure
        plt.figure(figsize=(10, 6))
        plt.plot(self.history['epoch'], self.history['loss'], 'b-', linewidth=2, label='Loss')
        plt.xlabel('Epoch', fontsize=12)
        plt.ylabel('Loss (log10 scale)', fontsize=12)
        plt.title('Training Loss Curve', fontsize=14)
        plt.yscale('log')  # Use log10 scale for y-axis
        plt.grid(True, alpha=0.3, which='both')  # Show grid for both major and minor ticks
        plt.legend(fontsize=10)
        plt.tight_layout()

        # Save figure
        plt.savefig(plot_path, dpi=150)
        plt.close()

        print(f"[Plot] Training history saved to: {plot_path}")
