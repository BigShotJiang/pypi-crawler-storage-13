# -*- coding: utf-8 -*-
"""
Data Manager Module
"""

import os
import time
import h5py
import numpy as np
from datetime import datetime
from typing import Optional, Dict, Any, List


class StreamingRecorder:
    """流式HDF5记录器 - 边记录边写入磁盘，避免内存爆炸"""

    def __init__(self, filepath: str):
        """
        初始化流式记录器

        Args:
            filepath: HDF5文件完整路径

        Note:
            如果文件已存在，会先备份到 filepath.backup（覆盖旧备份）
        """
        self.filepath = filepath
        self.frame_count = 0

        # 创建目录
        os.makedirs(os.path.dirname(filepath) or '.', exist_ok=True)

        # 如果文件已存在，备份到 .backup（覆盖旧备份）
        if os.path.exists(filepath):
            backup_path = filepath + '.backup'
            if os.path.exists(backup_path):
                os.remove(backup_path)
            os.rename(filepath, backup_path)
            print(f"[StreamingRecorder] Backed up existing file to {backup_path}")

        # 初始化HDF5文件（创建空文件，设置初始属性）
        with h5py.File(filepath, 'w') as f:
            f.attrs['num_frames'] = 0
            f.attrs['created_at'] = datetime.now().isoformat()
            f.attrs['recording_mode'] = 'streaming'

    def append_frame(self, frame_data: Dict[str, Any]):
        """
        追加一帧数据到HDF5文件

        Args:
            frame_data: 帧数据字典，例如 {'image': array, 'timestamp': 0.1, 'q_values': array}

        Note:
            每次调用会立即写入磁盘，内存占用小
        """
        with h5py.File(self.filepath, 'a') as f:
            # 创建帧组
            frame_name = f'frame_{self.frame_count:06d}'
            grp = f.create_group(frame_name)

            # 保存数据
            for key, value in frame_data.items():
                if isinstance(value, np.ndarray):
                    grp.create_dataset(key, data=value, compression='gzip')
                else:
                    grp.create_dataset(key, data=value)

            # 更新帧计数
            self.frame_count += 1
            f.attrs['num_frames'] = self.frame_count

    def finalize(self) -> str:
        """
        完成记录，更新文件属性

        Returns:
            str: 文件路径
        """
        with h5py.File(self.filepath, 'a') as f:
            f.attrs['finished_at'] = datetime.now().isoformat()

        return self.filepath

    def get_frame_count(self) -> int:
        """获取已记录的帧数"""
        return self.frame_count


class DataManager:
    """Data Manager"""

    def __init__(self, compatibility_layer=None, action_space=None, game_state=None):
        self.compat = compatibility_layer
        self.action = action_space
        self.game_state = game_state
        print(f"[DataManager] Init (compat={self.compat is not None}, action={self.action is not None}, game_state={self.game_state is not None})")

    def _get_frame_list(self, f) -> List[str]:
        """
        获取HDF5文件中排序后的帧名称列表

        Args:
            f: h5py.File对象

        Returns:
            List[str]: 排序后的帧名称列表，例如['frame_000000', 'frame_000001', ...]
        """
        frame_names = [key for key in f.keys() if key.startswith('frame_')]
        frame_names.sort()
        return frame_names

    def create_streaming_recorder(self, filepath: str) -> StreamingRecorder:
        """
        创建流式记录器

        Args:
            filepath: HDF5文件完整路径

        Returns:
            StreamingRecorder: 流式记录器实例
        """
        # 创建目录
        os.makedirs(os.path.dirname(filepath) or '.', exist_ok=True)
        return StreamingRecorder(filepath)

    def collect(self, filepath: str, max_frames: Optional[int] = None, interval: float = 1.0) -> str:
        """
        采集帧数据（使用流式写入）

        Args:
            filepath: 输出文件完整路径
            max_frames: 最大帧数（None表示无限制）
            interval: 采集间隔（秒）

        Returns:
            str: 保存的文件路径
        """
        if self.compat is None:
            raise ValueError("Need compatibility layer")

        print(f"[Collect] Start (max={max_frames}, interval={interval}s)")

        # 创建流式记录器
        recorder = self.create_streaming_recorder(filepath)

        try:
            while True:
                if max_frames and recorder.get_frame_count() >= max_frames:
                    break

                # 捕获画面
                image = self.compat.capture_screen()
                metadata = self.compat.get_frame_metadata()

                # 立即写入磁盘
                recorder.append_frame({
                    'image': image,
                    'timestamp': metadata['timestamp']
                })

                # 定期打印进度
                if recorder.get_frame_count() % 50 == 0:
                    print(f"  Collected: {recorder.get_frame_count()} frames")

                # 在线模式需要等待
                if self.compat.mode == 'online':
                    time.sleep(interval)

        except StopIteration:
            print(f"  Video ended")
        except KeyboardInterrupt:
            print(f"  User interrupted")

        # 完成记录
        print(f"[Collect] Done, total {recorder.get_frame_count()} frames")
        filepath = recorder.finalize()

        file_size = os.path.getsize(filepath) / (1024 * 1024)
        print(f"[Save] File: {filepath}, size: {file_size:.2f} MB")

        return filepath


    def load_dataset(self, filepath: str, keys: Optional[List[str]] = None, frame_range: Optional[tuple] = None):
        """
        Load complete dataset from HDF5 (including frame names and file attrs)

        Args:
            filepath: HDF5 file path
            keys: List of keys to load (None = load all keys)
            frame_range: Tuple of (start, end) indices in sorted frame list (None = load all frames)

        Returns:
            Tuple[List[Dict], List[str], Dict]: (frames_data, frame_names, file_attrs)
                - frames_data: List of frame data dictionaries
                - frame_names: List of frame names (e.g., ['frame_000050', 'frame_000051', ...])
                - file_attrs: File-level attributes dictionary
        """
        frames_data = []
        frame_names = []

        with h5py.File(filepath, 'r') as f:
            # 获取排序后的帧列表
            frame_list = self._get_frame_list(f)
            num_frames = len(frame_list)
            start, end = frame_range if frame_range else (0, num_frames)

            print(f"[LoadDataset] Loading: {filepath} (range: {start}-{end-1})")

            # 使用索引切片
            for frame_name in frame_list[start:end]:
                grp = f[frame_name]
                frame_data = {}

                if keys is None:
                    load_keys = list(grp.keys())
                else:
                    load_keys = keys

                for key in load_keys:
                    if key in grp:
                        frame_data[key] = grp[key][()]

                frames_data.append(frame_data)
                frame_names.append(frame_name)

            # 读取文件级别的attrs
            file_attrs = dict(f.attrs)

        print(f"[LoadDataset] Done, total {len(frames_data)} frames")
        return frames_data, frame_names, file_attrs

    def label(self, filepath: str, overwrite: bool = False):
        """
        Label dataset: compute actions and states for each frame, save to HDF5

        Args:
            filepath: HDF5 file path
            overwrite: Whether to overwrite existing fields
        """
        print(f"[Label] Labeling: {filepath}")

        with h5py.File(filepath, 'a') as f:
            # 获取排序后的帧列表
            frame_list = self._get_frame_list(f)
            num_frames = len(frame_list)

            # 遍历每一帧
            for i in range(num_frames):
                grp = f[frame_list[i]]
                img = grp['image'][()]

                # 获取下一帧
                if i < num_frames - 1:
                    next_img = f[frame_list[i + 1]]['image'][()]
                else:
                    next_img = img  # 最后一帧用自己

                # Compute state_dict
                if self.game_state:
                    state_dict = self.game_state.get_frame_state(img, next_img)

                    # 保存 state_dict 的每个字段
                    for key, value in state_dict.items():
                        field_name = f'state_{key}'
                        if field_name in grp and not overwrite:
                            continue
                        if field_name in grp:
                            del grp[field_name]
                        grp.create_dataset(field_name, data=value)

                # Compute action_dict
                if self.action:
                    action_dict = self.action.get_frame_action(img, next_img)

                    # 保存 action_dict 的每个字段
                    for key, values in action_dict.items():
                        field_name = f'action_{key}'
                        if field_name in grp and not overwrite:
                            continue
                        if field_name in grp:
                            del grp[field_name]
                        grp.create_dataset(field_name, data=values)

                if (i + 1) % 50 == 0:
                    print(f"  Progress: {i+1}/{num_frames}")

            f.attrs['labeled_at'] = datetime.now().isoformat()

        print(f"[Label] Done")

    def update(self, filepath: str, actions: Optional[List[str]] = None, overwrite: bool = False):
        """Update dataset with action fields (deprecated, use label() instead)"""
        print("[WARNING] update() is deprecated, use label() instead")
        self.label(filepath, overwrite=overwrite)

    def info(self, filepath: str) -> Dict[str, Any]:
        """Get dataset info"""
        with h5py.File(filepath, 'r') as f:
            info = {
                'num_frames': f.attrs['num_frames'],
                'created_at': f.attrs.get('created_at', 'unknown'),
                'updated_at': f.attrs.get('updated_at', 'never'),
                'action_keys': f.attrs.get('action_keys', 'none'),
            }

            # 获取排序后的帧列表
            frame_list = self._get_frame_list(f)
            if frame_list:
                # 使用第一个帧获取available_keys
                grp = f[frame_list[0]]
                info['available_keys'] = list(grp.keys())

        return info

    def add_attrs(self, filepath: str, attrs: Dict[str, Any]):
        """Add custom attributes to HDF5 file"""
        with h5py.File(filepath, 'a') as f:
            for key, value in attrs.items():
                f.attrs[key] = value


    def save_dataset(self,
                     filepath: str,
                     frames_data: List[Dict],
                     frame_names: Optional[List[str]] = None,
                     file_attrs: Optional[Dict] = None) -> str:
        """
        保存帧数据到HDF5文件（支持任意字段和自定义帧名称）

        Args:
            filepath: 输出文件路径（完整路径，不是文件名）
            frames_data: 帧数据列表，每个元素是字典，包含该帧的所有datasets
                        例如：[
                            {'image': array, 'timestamp': 0.1, 'move': array, 'reward': -10.0},
                            {'image': array, 'timestamp': 0.2, 'move': array, 'reward': 0.01},
                            ...
                        ]
            frame_names: 帧名称列表（可选），长度必须与frames_data相同
                        例如：['frame_000050', 'frame_000051', ...]
                        如果不提供则使用frame_{i:06d}格式（i从0开始）
            file_attrs: 文件级别的额外attrs（可选）
                       例如：{'original_file': 'xxx.hdf5', 'extracted_range': (50, 100)}

        Returns:
            str: 保存的文件路径
        """
        if not frames_data:
            raise ValueError("frames_data is empty")

        if frame_names and len(frame_names) != len(frames_data):
            raise ValueError(f"frame_names length ({len(frame_names)}) != frames_data length ({len(frames_data)})")

        print(f"[SaveDataset] Saving to: {filepath}")
        print(f"  Frames: {len(frames_data)}")
        if frame_names:
            print(f"  Using custom frame names (first: {frame_names[0]}, last: {frame_names[-1]})")

        with h5py.File(filepath, 'w') as f:
            # 如果提供了额外的attrs，先添加进去
            if file_attrs:
                for key, value in file_attrs.items():
                    f.attrs[key] = value

            # 始终设置这两个基本attrs（覆盖file_attrs中可能存在的旧值）
            f.attrs['num_frames'] = len(frames_data)
            f.attrs['created_at'] = datetime.now().isoformat()

            # 保存每一帧
            for i, frame_data in enumerate(frames_data):
                # 使用自定义名称或默认名称
                frame_name = frame_names[i] if frame_names else f'frame_{i:06d}'
                grp = f.create_group(frame_name)

                # 保存该帧的所有字段（作为datasets）
                for key, value in frame_data.items():
                    if isinstance(value, np.ndarray):
                        grp.create_dataset(key, data=value, compression='gzip')
                    else:
                        grp.create_dataset(key, data=value)

        file_size = os.path.getsize(filepath) / (1024 * 1024)
        print(f"[SaveDataset] Done, size: {file_size:.2f} MB")
        return filepath


if __name__ == '__main__':
    print("Testing DataManager...")
    dm = DataManager()
    print("[Test] Init success")
