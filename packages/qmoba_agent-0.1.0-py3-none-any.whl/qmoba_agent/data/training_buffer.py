# -*- coding: utf-8 -*-
"""
Training Buffer Module
"""

import numpy as np
import random
import h5py
import os
from datetime import datetime
from typing import Optional, Dict, List
import torch
from torch.utils.data import Dataset, DataLoader
from qmoba_agent.utils.image_processing import preprocess_frame


class TrainingBuffer:
    """Training Buffer - connects dataset and model/training"""

    def __init__(
        self,
        data_manager=None,
        action_space=None,
        game_state=None,
        capacity: int = 100000,
        config=None
    ):
        """
        Init buffer

        Args:
            data_manager: DataManager instance (if None, create new one)
            action_space: ActionSpace instance (for action keys and reward calculation)
            game_state: GameState instance (for state reward calculation)
            capacity: Max capacity
            config: Config instance (for train_resolution)
        """
        # Init or use provided data_manager
        if data_manager is None:
            from data_manager import DataManager
            self.data_manager = DataManager()
        else:
            self.data_manager = data_manager

        self.action = action_space
        self.game_state = game_state
        self.capacity = capacity
        self.config = config

        # Input channels (determined by config.use_last_state and train_resolution)
        # use_last_state=True: channels * 2, False: channels
        base_channels = config.train_resolution[2] if (config and hasattr(config, 'train_resolution')) else 3
        self.input_channels = base_channels * 2 if (config and getattr(config, 'use_last_state', True)) else base_channels

        # Storage: list of dicts
        self.samples = []
        self.size = 0

        print(f"[TrainingBuffer] Init")
        print(f"  Capacity: {capacity}")
        print(f"  Input channels: {self.input_channels}")
        print(f"  Has action: {self.action is not None}")
        print(f"  Has game_state: {self.game_state is not None}")
        if config and hasattr(config, 'train_resolution'):
            print(f"  Train resolution: {config.train_resolution}")

    def load(self, filepath: str, max_frames: Optional[int] = None):
        """
        Load data from HDF5

        Args:
            filepath: HDF5 file path
            max_frames: Max frames to load
        """
        print(f"[Load] Loading: {filepath}")

        # Get action keys if available
        action_keys = self.action.get_action_keys() if self.action else []

        # Load frames using DataManager (load all available keys)
        frame_range = (0, max_frames) if max_frames else None
        frames, frame_names, _ = self.data_manager.load_dataset(filepath, keys=None, frame_range=frame_range)

        # Check if required fields exist
        if frames:
            first_frame = frames[0]
            missing_keys = []

            # Check action fields
            for key in action_keys:
                if f'action_{key}' not in first_frame:
                    missing_keys.append(f'action_{key}')

            # Check state fields
            if 'state_in_battle' not in first_frame:
                missing_keys.append('state_in_battle')

            if missing_keys:
                print(f"[WARNING] Missing keys in HDF5: {missing_keys}")
                print(f"[WARNING] Please run: data_manager.label('{filepath}')")

        # Build samples from consecutive frames
        skipped = 0
        for i in range(len(frames) - 1):
            if self.size >= self.capacity:
                print(f"  Buffer full")
                break

            frame = frames[i]

            # Filter: only keep battle frames where player is alive
            # Read state from HDF5 (already labeled)
            in_battle = frame.get('state_in_battle', False)
            is_dead = frame.get('state_dead', False)

            if not in_battle or is_dead:
                skipped += 1
                continue

            # Get images
            state = frame['image']
            next_state = frames[i + 1]['image']

            # Get last_state if use_last_state is enabled
            use_last_state = self.config and getattr(self.config, 'use_last_state', True)
            if use_last_state:
                if i == 0:
                    last_state = frames[0]['image']
                else:
                    # Check if i-1 is in battle
                    if frames[i - 1].get('state_in_battle', False):
                        last_state = frames[i - 1]['image']
                    else:
                        last_state = frame['image']

            # Preprocess images if config is available
            if self.config and hasattr(self.config, 'train_resolution'):
                state = preprocess_frame(state, self.config.train_resolution, normalize_img=True)
                next_state = preprocess_frame(next_state, self.config.train_resolution, normalize_img=True)
                if use_last_state:
                    last_state = preprocess_frame(last_state, self.config.train_resolution, normalize_img=True)
                    # Concatenate: first merge next_state, then merge state
                    next_state = np.concatenate([state, next_state], axis=0)
                    state = np.concatenate([last_state, state], axis=0)

            sample = {
                'state': state,
                'next_state': next_state,
                'frame_name': frame_names[i]
            }

            # Read action fields from HDF5
            for key in action_keys:
                field_name = f'action_{key}'
                sample[key] = frame.get(field_name, None)

            # Calculate reward from next state (s -> a -> s', reward from s')
            # Reward is environment feedback after executing action
            reward = 0.0

            # Get next frame for reward calculation
            next_frame = frames[i + 1]

            # State reward from next state
            if self.game_state:
                state_dict = {
                    'in_battle': next_frame.get('state_in_battle', False),
                    'dead': next_frame.get('state_dead', False),
                    'alive': next_frame.get('state_alive', False),
                    'kill': next_frame.get('state_kill', False),
                    'assist': next_frame.get('state_assist', False)
                }
                reward = self.game_state.sum_reward(state_dict)

            sample['reward'] = reward

            self.add(sample)

            if (i + 1) % 100 == 0:
                print(f"  Loaded: {i+1}/{len(frames)-1}")

        print(f"[Load] Done, buffer size: {self.size}, skipped: {skipped}")

    def add(self, sample: Dict):
        """Add one sample"""
        if self.size < self.capacity:
            self.samples.append(sample)
            self.size += 1
        else:
            # FIFO
            idx = self.size % self.capacity
            self.samples[idx] = sample
            self.size += 1

    def preprocess(self, state: np.ndarray) -> np.ndarray:
        """Preprocess state (placeholder)"""
        # TODO: Add preprocessing
        return state

    def clear(self):
        """Clear buffer"""
        self.samples = []
        self.size = 0
        print("[TrainingBuffer] Cleared")

    def save_to_hdf5(self, filepath: str):
        """
        Save all buffer samples to HDF5

        This method saves all samples in the buffer to an HDF5 file for inspection.
        Each sample is saved as a separate frame group.

        Args:
            filepath: Output HDF5 file path
        """
        if self.size == 0:
            raise ValueError("Buffer is empty, nothing to save")

        # Create directory if not exists
        os.makedirs(os.path.dirname(filepath), exist_ok=True)

        print(f"[Save] Saving buffer to: {filepath}")

        # Get all keys from first sample (dynamic field detection)
        sample_keys = list(self.samples[0].keys())
        num_samples = min(self.size, self.capacity)

        with h5py.File(filepath, 'w') as f:
            # Save metadata
            f.attrs['num_frames'] = num_samples
            f.attrs['created_at'] = datetime.now().isoformat()
            f.attrs['source'] = 'TrainingBuffer'
            f.attrs['buffer_capacity'] = self.capacity
            f.attrs['available_keys'] = sample_keys

            # Save each sample as a frame
            for i in range(num_samples):
                sample = self.samples[i]
                grp = f.create_group(f'frame_{i:06d}')

                # Save all fields dynamically
                for key in sample_keys:
                    value = sample[key]
                    if value is not None:
                        # Use compression for large arrays (images)
                        if isinstance(value, np.ndarray) and value.size > 1000:
                            grp.create_dataset(key, data=value, compression='gzip')
                        else:
                            grp.create_dataset(key, data=value)

                if (i + 1) % 100 == 0:
                    print(f"  Saved: {i+1}/{num_samples}")

        file_size = os.path.getsize(filepath) / (1024 * 1024)
        print(f"[Save] Done, size: {file_size:.2f} MB")

    def __len__(self):
        return min(self.size, self.capacity)

    def sample_indices(self, sample_size: int) -> List[int]:
        """
        Sample indices from buffer (reuse existing sample logic)

        Args:
            sample_size: Number of samples to draw

        Returns:
            List of sampled indices
        """
        buffer_size = len(self)
        if sample_size > buffer_size:
            raise ValueError(f"Sample size ({sample_size}) > buffer size ({buffer_size})")
        return random.sample(range(buffer_size), sample_size)

    def get_dataloader(self, batch_size: int, shuffle: bool = True, device: str = 'cpu', sample_size: Optional[int] = None):
        """
        Get PyTorch DataLoader for training

        Args:
            batch_size: Batch size
            shuffle: Whether to shuffle data order
            device: Device to put tensors on ('cpu' or 'cuda')
            sample_size: Number of samples to randomly sample from buffer.
                        If None or >= buffer size, use all samples.
                        If < buffer size, randomly sample this many samples (using existing sample logic).

        Returns:
            DataLoader instance
        """
        buffer_size = len(self)

        # Determine which samples to use
        if sample_size is None or sample_size >= buffer_size:
            # Use all samples
            selected_samples = self.samples[:buffer_size]
        else:
            # Use existing sample logic for random sampling
            indices = self.sample_indices(sample_size)
            selected_samples = [self.samples[i] for i in indices]

        dataset = BufferDataset(selected_samples, device=device)
        dataloader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=shuffle,
            num_workers=0,  # Use 0 to avoid multiprocessing issues
            pin_memory=False  # Data already on device
        )
        return dataloader


class BufferDataset(Dataset):
    """PyTorch Dataset wrapper for TrainingBuffer"""

    def __init__(self, samples: List[Dict], device: str = 'cpu'):
        """
        Init dataset

        Args:
            samples: List of sample dicts
            device: Device to put tensors on
        """
        self.samples = samples
        self.device = device

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        """
        Get one sample and convert to tensors on device

        Returns:
            Dict with all fields as tensors on device
        """
        sample = self.samples[idx]

        # Convert all fields to tensors and move to device
        tensor_sample = {}
        for key, value in sample.items():
            if value is not None and isinstance(value, np.ndarray):
                tensor_sample[key] = torch.from_numpy(value).to(self.device)
            elif value is not None and isinstance(value, (int, float)):
                tensor_sample[key] = torch.tensor(value, dtype=torch.float32).to(self.device)
            else:
                # Keep string or None as-is
                tensor_sample[key] = value

        return tensor_sample


if __name__ == '__main__':
    print("Testing TrainingBuffer...")
    buffer = TrainingBuffer()
    print("[Test] Init success")
