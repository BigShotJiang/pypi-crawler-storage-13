"""
配置管理模块

本模块管理 autowzry-agent 项目的配置。

项目说明：
- autowzry-agent: 本项目，基于强化学习的游戏AI训练框架
- autowzry: 图像识别库，提供游戏画面检测和设备控制功能
- autowzry_lite: autowzry的精简版本，包含在本项目的util目录下

配置文件说明：
- agent配置文件 (agent.config.yaml): 本项目的配置，包含训练参数、buffer设置等
- autowzry配置文件 (config.device.yaml): autowzry库的配置，包含设备连接信息
"""

import os
import yaml
from dataclasses import dataclass, field, asdict
from typing import List


@dataclass
class Config:
    """autowzry-agent 训练配置"""
    # 训练开关
    enable_training: bool = False

    # autowzry库选择：True使用本项目的autowzry_lite，False尝试使用已安装的autowzry
    use_autowzry_lite: bool = True

    # autowzry库的配置文件路径（用于设备连接和图像识别）
    autowzry_config: str = "config/config.device.yaml"

    # Buffer
    buffer_capacity: int = 320

    # 训练分辨率 [height, width, channels]
    train_resolution: List[int] = field(default_factory=lambda: [540, 960, 3])

    # 是否使用laststate+state合并模式
    use_last_state: bool = True

    # 模型配置
    model_mode: str = 'mini'  # 模型规模: 'mini', 'full', 'high'

    # 启用的状态和动作
    enabled_states: List[str] = field(default_factory=lambda: ['in_battle', 'dead', 'alive', 'kill', 'assist'])
    enabled_actions: List[str] = field(default_factory=lambda: ['move'])

    # 训练参数
    num_epochs: int = 160
    batch_size: int = 4
    learning_rate: float = 1e-4
    gamma: float = 0.99
    samples_per_epoch: int = None  # 每个epoch使用的样本数，None表示使用所有buffer数据

    # Target Network
    use_target_network: bool = True  # 是否使用目标网络
    target_update_epochs: int = 5    # 每N个epoch更新一次目标网络

    # Mixed Precision Training
    use_amp: bool = True  # 是否使用AMP混合精度训练（默认开启，mini模式推荐）

    # Device
    device: str = 'auto'  # 训练设备: 'auto', 'cpu', 'cuda', 'cuda:0', 'cuda:1', etc.

    # 数据
    data_dir: str = "./workspace/episodes"
    train_files: List[str] = field(default_factory=list)

    # 保存
    checkpoint_dir: str = "./workspace/checkpoints"
    save_interval: int = 32
    resume_model: str = None  # 恢复训练的模型路径，None表示不加载

    @classmethod
    def from_yaml(cls, path: str) -> 'Config':
        """从YAML文件加载配置"""
        with open(path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)

        # Read model_mode first
        model_mode = data.get('model', {}).get('mode', 'full')

        # Read use_amp config, if None, decide based on model_mode
        use_amp_config = data.get('training', {}).get('use_amp', None)
        if use_amp_config is None:
            use_amp = (model_mode == 'mini')
        else:
            use_amp = use_amp_config

        return cls(
            enable_training=data.get('enable_training', False),
            use_autowzry_lite=data.get('use_autowzry_lite', True),
            autowzry_config=data.get('autowzry_config', 'config/config.device.yaml'),
            buffer_capacity=data.get('buffer', {}).get('capacity', 320),
            train_resolution=data.get('train_resolution', [540, 960, 3]),
            use_last_state=data.get('use_last_state', True),
            model_mode=model_mode,
            enabled_states=data.get('enabled_states', ['in_battle', 'dead', 'alive', 'kill', 'assist']),
            enabled_actions=data.get('enabled_actions', ['move', 'attack']),
            num_epochs=data.get('training', {}).get('num_epochs', 32),
            batch_size=data.get('training', {}).get('batch_size', 4),
            learning_rate=data.get('training', {}).get('learning_rate', 1e-4),
            gamma=data.get('training', {}).get('gamma', 0.99),
            samples_per_epoch=data.get('training', {}).get('samples_per_epoch', None),
            use_target_network=data.get('training', {}).get('use_target_network', True),
            target_update_epochs=data.get('training', {}).get('target_update_epochs', 5),
            use_amp=use_amp,
            device=data.get('training', {}).get('device', 'auto'),
            data_dir=data.get('data', {}).get('dir', './workspace/episodes'),
            train_files=data.get('data', {}).get('train_files', []),
            checkpoint_dir=data.get('checkpoint', {}).get('dir', './workspace/checkpoints'),
            save_interval=data.get('checkpoint', {}).get('save_interval', 32),
            resume_model=data.get('checkpoint', {}).get('resume_model', None),
        )

    @classmethod
    def default(cls) -> 'Config':
        """返回默认配置"""
        return cls()

    def save_yaml(self, path: str):
        """保存配置到YAML文件"""
        data = {
            'enable_training': self.enable_training,
            'use_autowzry_lite': self.use_autowzry_lite,
            'autowzry_config': self.autowzry_config,
            'buffer': {
                'capacity': self.buffer_capacity
            },
            'train_resolution': self.train_resolution,
            'use_last_state': self.use_last_state,
            'model': {
                'mode': self.model_mode
            },
            'enabled_states': self.enabled_states,
            'enabled_actions': self.enabled_actions,
            'training': {
                'num_epochs': self.num_epochs,
                'batch_size': self.batch_size,
                'learning_rate': self.learning_rate,
                'gamma': self.gamma,
                'samples_per_epoch': self.samples_per_epoch,
                'use_target_network': self.use_target_network,
                'target_update_epochs': self.target_update_epochs,
                'use_amp': self.use_amp,
                'device': self.device
            },
            'data': {
                'dir': self.data_dir,
                'train_files': self.train_files
            },
            'checkpoint': {
                'dir': self.checkpoint_dir,
                'save_interval': self.save_interval,
                'resume_model': self.resume_model
            }
        }

        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, allow_unicode=True, default_flow_style=False)


if __name__ == '__main__':
    config = Config.default()
    output_path = 'config/agent.config.yaml.in'
    config.save_yaml(output_path)
    print(f"Default config saved to: {output_path}")
