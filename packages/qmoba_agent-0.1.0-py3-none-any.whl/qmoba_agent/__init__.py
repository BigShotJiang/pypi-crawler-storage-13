"""
QMobaAgent - A reinforcement learning framework template for MOBA game AI training

This package provides a complete pipeline for training game AI agents:
- Data collection from videos or devices
- Data labeling with game states and actions
- DQN model training
- Model evaluation and battle testing

Main modules:
- config: Configuration management
- core: DQN model and trainer
- data: Data management and training buffer
- environment: Game environment compatibility layer
- utils: Utility functions for image processing and video reading
"""

__version__ = "0.1.0"

# Export commonly used classes for convenience
from qmoba_agent.config.config import Config
from qmoba_agent.environment.compatibility import CompatibilityLayer
from qmoba_agent.core.lightweight_dqn import LightweightDQN
from qmoba_agent.core.trainer import Trainer

__all__ = [
    "Config",
    "CompatibilityLayer",
    "LightweightDQN",
    "Trainer",
]
