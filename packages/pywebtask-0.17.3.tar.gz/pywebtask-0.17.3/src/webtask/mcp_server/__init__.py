"""MCP server for webtask."""
