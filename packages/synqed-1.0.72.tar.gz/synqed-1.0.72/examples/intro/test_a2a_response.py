"""
Test script to directly call the A2A agent and inspect the response structure.
"""

import asyncio
import aiohttp
import json

async def test_a2a_agent():
    """Send a test message to the A2A agent and print the full response."""
    
    url = "http://localhost:8001"
    
    # Build A2A Message structure
    a2a_message = {
        "message_id": "test-msg-123",
        "context_id": None,
        "role": "user",
        "parts": [{"text": "Hello, this is a test message"}]
    }
    
    # Build JSON-RPC request
    request_payload = {
        "jsonrpc": "2.0",
        "method": "message/send",
        "params": {
            "message": a2a_message,
            "configuration": {
                "blocking": True
            }
        },
        "id": 1
    }
    
    print("="*80)
    print("SENDING REQUEST:")
    print("="*80)
    print(json.dumps(request_payload, indent=2))
    print()
    
    async with aiohttp.ClientSession() as session:
        async with session.post(
            url,
            json=request_payload,
            headers={"Content-Type": "application/json"}
        ) as response:
            print("="*80)
            print(f"RESPONSE STATUS: {response.status}")
            print("="*80)
            
            response_text = await response.text()
            print("Raw response text:")
            print(response_text)
            print()
            
            response_data = json.loads(response_text)
            print("="*80)
            print("PARSED RESPONSE:")
            print("="*80)
            print(json.dumps(response_data, indent=2))
            print()
            
            print("="*80)
            print("RESPONSE STRUCTURE ANALYSIS:")
            print("="*80)
            print(f"Top-level keys: {list(response_data.keys())}")
            
            if "result" in response_data:
                result = response_data["result"]
                print(f"Result keys: {list(result.keys())}")
                print(f"Result type: {type(result)}")
                
                if "task" in result:
                    print("✓ Found 'task' in result (wrapped)")
                    print(f"  Task keys: {list(result['task'].keys())}")
                elif "task_id" in result:
                    print("✓ Result IS the task directly (unwrapped)")
                    print(f"  Task keys: {list(result.keys())}")
                else:
                    print("✗ No task found in result")
            
            print("="*80)

if __name__ == "__main__":
    asyncio.run(test_a2a_agent())

