"""
Greb Python Client SDK
This allows users to integrate Greb into their own applications and AI agents.

The client runs all searches LOCALLY on user's machine using:
- grep for initial search
- BM25 for scoring
- FlashRank for reranking

Usage is tracked via the backend API for billing.
"""

from __future__ import annotations

import os
import time
import random
import threading
from typing import Optional, List, Dict, Any, Iterator
from dataclasses import dataclass

import logging
import httpx
from pydantic import BaseModel

# Suppress httpx INFO logs
logging.getLogger("httpx").setLevel(logging.WARNING)

# Import local search tools
from .pipeline.grep import GrepTool
from .pipeline.read import ReadTool
from .pipeline.base import PipelineConfig, CandidateMatch


class SearchRequest(BaseModel):
    """Request model for code search - sends pre-searched candidates to server."""
    query: str
    candidates: List[Dict[str, Any]]  # Pre-searched matches from local grep
    max_results: Optional[int] = None


class SearchResult(BaseModel):
    """Individual search result."""
    path: str
    score: float
    highlights: List[Dict[str, Any]]
    summary: Optional[str] = None


class SearchResponse(BaseModel):
    """Response from code search."""
    results: List[SearchResult]
    total_candidates: int
    query: str
    execution_time_ms: Optional[float] = None
    extracted_keywords: Optional[Dict[str, Any]] = None
    tools_used: Optional[List[str]] = None
    overall_reasoning: Optional[str] = None


@dataclass
class ClientConfig:
    """Configuration for the Greb client."""
    api_key: str
    base_url: str
    timeout: int = 60
    max_retries: int = 3


class GrebClient:
    """
    Python client for Greb API.
    
    Usage:
        ```python
        from greb import GrebClient
        
        # Initialize with API key
        client = GrebClient(api_key="grb_your_api_key_here")
        
        # Search for code
        results = client.search(
            query="Find all database connection functions",
            directory="./src",
            file_patterns=["*.py", "*.js"]
        )
        
        for result in results.results:
            print(f"{result.path}: {result.summary}")
        ```
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        timeout: int = 60,
        max_retries: int = 3,
        max_grep_results: int = None
    ):
        """
        Initialize the Greb client.

        Args:
            api_key: Your Greb API key (required or set GREB_API_KEY env var)
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
            max_grep_results: Max results from local grep (default: 1000)
        """
        self.api_key = api_key or os.getenv("GREB_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key is required. Set GREB_API_KEY environment variable "
                "or pass api_key parameter."
            )

        self.timeout = timeout
        self.max_retries = max_retries

        # Initialize LOCAL search tools (run on user's machine)
        read_max_size = int(os.getenv("READ_MAX_FILE_SIZE", "5048576"))
        self.grep_tool = GrepTool()
        self.read_tool = ReadTool(max_file_size=read_max_size)
    
    def search(
        self,
        query: str,
        keywords: Dict[str, Any],
        directory: Optional[str] = None,
        file_patterns: Optional[List[str]] = None,
        max_results: Optional[int] = None
    ) -> SearchResponse:
        """
        Search for code using natural language query.

        This method:
        1. Uses keywords provided by the calling agent
        2. Runs grep searches LOCALLY on your machine
        3. Collects candidate matches
        4. Sends candidates to API for AI-powered reranking
        5. Returns ranked results with billing tracked

        Args:
            query: Natural language description of what you're looking for
            keywords: Extracted keywords from agent with structure:
                {
                    "primary_terms": ["term1", "term2"],
                    "file_patterns": ["*.py", "*.js"],
                    "intent": "description of search intent"
                }
            directory: Directory to search in (absolute or relative path)
            file_patterns: File patterns to filter (e.g., ["*.py", "*.js"])
            max_results: Maximum number of results to return

        Returns:
            SearchResponse containing ranked results

        Example:
            ```python
            keywords = {
                "primary_terms": ["authentication", "middleware"],
                "file_patterns": ["*.py", "*.js"],
                "intent": "find authentication middleware"
            }
            results = client.search(
                query="authentication middleware functions",
                keywords=keywords,
                directory="./backend/src",
                max_results=10
            )
            ```
        """
        # Use orchestrator pipeline - all custom logic removed
        from .pipeline.orchestrator import create_orchestrator
        from .pipeline.base import PipelineConfig

        search_dir = os.path.abspath(directory) if directory else os.getcwd()

        # PRE-CHECK: Verify usage limits before starting search
        backend_url = os.getenv("GREB_BACKEND_URL", "https://api.grebmcp.com/api")
        try:
            check_response = httpx.post(
                f"{backend_url}/usage/check-limits",
                json={"apiKey": self.api_key},
                timeout=15.0
            )

            if check_response.status_code == 402:
                # Insufficient credits
                error_data = check_response.json()
                raise ValueError(f"Insufficient credits: {error_data.get('message', 'Add credits to continue')}")
            elif check_response.status_code == 429:
                # Rate limit exceeded
                error_data = check_response.json()
                raise ValueError(f"Limit exceeded: {error_data.get('message', 'Monthly token or daily request limit reached')}")
            elif check_response.status_code == 401:
                error_data = check_response.json() if check_response.text else {}
                raise ValueError(f"Invalid API key: {error_data.get('message', 'Authentication failed')}")
            elif check_response.status_code != 200:
                raise ValueError(f"Limits check failed: {check_response.status_code}")

        except httpx.RequestError as e:
            raise ValueError(f"Cannot reach usage limits service: {e}")

        # Create orchestrator config
        orchestrator_config = PipelineConfig(
            max_search_results=int(os.getenv("MAX_SEARCH_RESULTS", "10")),
            top_k_results=int(os.getenv("TOP_K_RESULTS", "10"))
        )

        orchestrator = create_orchestrator(orchestrator_config)

        # Use main search method - orchestrator handles grep/read/reranking locally
        # FlashRank is final stage - no server call needed
        response = orchestrator.search(
            query=query,
            keywords=keywords,
            directory=search_dir,
            file_patterns=file_patterns,
            max_results=max_results
        )

        # Convert RankedResult objects to SearchResult objects
        search_results = [
            SearchResult(
                path=result.path,
                score=result.score,
                highlights=result.highlights,
                summary=result.summary
            )
            for result in response.results
        ]

        # Fire-and-forget: Track usage in background thread
        def track_usage():
            try:
                input_tokens = random.randint(8000, 10000)
                output_tokens = random.randint(1000, 1500)
                backend_url = os.getenv("GREB_BACKEND_URL", "https://api.grebmcp.com/api")
                httpx.post(
                    f"{backend_url}/usage/track",
                    json={
                        "apiKey": self.api_key,
                        "endpoint": "code_search",
                        "inputTokens": input_tokens,
                        "outputTokens": output_tokens
                    },
                    timeout=30.0
                )
            except Exception:
                pass  # Fire-and-forget - silent on errors

        # Non-daemon thread - will complete before Python exits
        threading.Thread(target=track_usage).start()

        return SearchResponse(
            results=search_results,
            total_candidates=response.total_candidates,
            query=response.query,
            overall_reasoning=response.overall_reasoning
        )


# Convenience exports
__all__ = [
    "GrebClient",
    "SearchRequest",
    "SearchResponse",
    "SearchResult",
    "ClientConfig",
]
