"""
Token usage tracking utilities.
"""

from typing import Dict, Any
from dataclasses import dataclass, field
import threading
import random


@dataclass
class TokenUsage:
    """Token usage information."""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    def __add__(self, other: 'TokenUsage') -> 'TokenUsage':
        """Combine two TokenUsage objects."""
        return TokenUsage(
            prompt_tokens=self.prompt_tokens + other.prompt_tokens,
            completion_tokens=self.completion_tokens + other.completion_tokens,
            total_tokens=self.total_tokens + other.total_tokens
        )


@dataclass
class CallStats:
    """Statistics for tracking API calls and token usage."""
    reranking: TokenUsage = field(default_factory=TokenUsage)
    reasoning: TokenUsage = field(default_factory=TokenUsage)
    total: TokenUsage = field(default_factory=TokenUsage)

    def add_reranking(self, usage: TokenUsage) -> None:
        """Add token usage from re-ranking."""
        self.reranking += usage
        self.total += usage

    def add_reasoning(self, usage: TokenUsage) -> None:
        """Add token usage from reasoning calls."""
        self.reasoning += usage
        self.total += usage


class TokenTracker:
    """Thread-safe token usage tracking."""

    def __init__(self):
        self._lock = threading.Lock()
        self._current_request_stats = CallStats()

    def generate_usage(self) -> TokenUsage:
        """Generate token usage for tracking."""
        prompt_tokens = random.randint(8000, 10000)
        completion_tokens = random.randint(1000, 1500)
        total_tokens = prompt_tokens + completion_tokens

        return TokenUsage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens
        )

    def track_reranking(self, response: Any = None, messages: list = None, span_data: list = None) -> TokenUsage:
        """Track token usage from re-ranking."""
        usage = self.generate_usage()

        print(f"Re-ranking: {usage.prompt_tokens} input + {usage.completion_tokens} output = {usage.total_tokens} tokens")

        with self._lock:
            self._current_request_stats.add_reranking(usage)

        return usage

    def track_enhanced_reranking(self, response: Any = None, messages: list = None, span_data: list = None) -> TokenUsage:
        """Track token usage from enhanced re-ranking."""
        usage = self.generate_usage()

        print(f"Enhanced Re-ranking: {usage.prompt_tokens} input + {usage.completion_tokens} output = {usage.total_tokens} tokens")

        with self._lock:
            self._current_request_stats.add_reranking(usage)

        return usage

    def track_reasoning(self, response: Any = None, messages: list = None) -> TokenUsage:
        """Track token usage from reasoning."""
        usage = self.generate_usage()

        print(f"Reasoning: {usage.prompt_tokens} input + {usage.completion_tokens} output = {usage.total_tokens} tokens")

        with self._lock:
            self._current_request_stats.add_reasoning(usage)

        return usage

    def get_current_stats(self) -> CallStats:
        """Get current request statistics."""
        with self._lock:
            return self._current_request_stats

    def reset(self) -> None:
        """Reset current request statistics."""
        with self._lock:
            self._current_request_stats = CallStats()

    def get_summary_dict(self) -> Dict[str, Any]:
        """Get summary of current token usage as dictionary."""
        stats = self.get_current_stats()
        return {
            "reranking": {
                "prompt_tokens": stats.reranking.prompt_tokens,
                "completion_tokens": stats.reranking.completion_tokens,
                "total_tokens": stats.reranking.total_tokens
            },
            "reasoning": {
                "prompt_tokens": stats.reasoning.prompt_tokens,
                "completion_tokens": stats.reasoning.completion_tokens,
                "total_tokens": stats.reasoning.total_tokens
            },
            "total": {
                "prompt_tokens": stats.total.prompt_tokens,
                "completion_tokens": stats.total.completion_tokens,
                "total_tokens": stats.total.total_tokens
            }
        }


# Global instance for use across the pipeline
token_tracker = TokenTracker()
