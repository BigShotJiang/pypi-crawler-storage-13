"""
Rerank tool implementation - returns results in original order with scores.
"""

from __future__ import annotations

from typing import List, Dict, Any, Optional
from pydantic import BaseModel

from .base import FileSpan, RankedResult, PipelineConfig


class RerankRequest(BaseModel):
    """Request model for reranking."""
    query: str
    spans: List[Dict[str, Any]]
    top_k: int = 5


class RerankResponse(BaseModel):
    """Response model for reranking results."""
    results: List[RankedResult]
    reasoning: Optional[str] = None


class RerankTool:
    """Implements result re-ranking - returns results in original order."""

    def __init__(self, config: PipelineConfig):
        self.config = config

    def rerank_spans(
        self,
        query: str,
        spans: List[FileSpan],
        top_k: Optional[int] = None
    ) -> List[RankedResult]:
        """
        Return file spans in original order with scores.

        Args:
            query: The original search query
            spans: List of FileSpan objects to rank
            top_k: Number of top results to return (overrides config)

        Returns:
            List of RankedResult objects
        """
        if not spans:
            return []

        top_k = top_k or self.config.top_k_results

        # Return spans in original order with decreasing scores
        results = []
        for i, span in enumerate(spans[:top_k]):
            # Generate score decreasing from 0.95 to 0.50
            score = 0.95 - (i * 0.05)
            if score < 0.50:
                score = 0.50

            result = RankedResult(
                path=span.path,
                score=score,
                highlights=[{
                    "line_start": span.start_line,
                    "line_end": span.end_line,
                    "span": {
                        "start_line": span.start_line,
                        "end_line": span.end_line,
                        "text": span.text
                    }
                }]
            )
            results.append(result)

        return results

    def rerank_spans_with_context(
        self,
        natural_query: str,
        extracted_keywords,
        spans: List[FileSpan],
        top_k: Optional[int] = None
    ) -> List[RankedResult]:
        """
        Return file spans in original order with scores and summaries.

        Args:
            natural_query: Original natural language query from user
            extracted_keywords: Keywords extracted (unused)
            spans: List of FileSpan objects to rank
            top_k: Number of top results to return

        Returns:
            List of RankedResult objects with enhanced context
        """
        if not spans:
            return []

        top_k = top_k or self.config.top_k_results

        # Return spans in original order with decreasing scores
        results = []
        for i, span in enumerate(spans[:top_k]):
            # Generate score decreasing from 0.95 to 0.50
            score = 0.95 - (i * 0.05)
            if score < 0.50:
                score = 0.50

            file_name = span.path.split('/')[-1] if '/' in span.path else span.path.split('\\')[-1]

            result = RankedResult(
                path=span.path,
                score=score,
                highlights=[{
                    "line_start": span.start_line,
                    "line_end": span.end_line,
                    "span": {
                        "start_line": span.start_line,
                        "end_line": span.end_line,
                        "text": span.text
                    }
                }],
                file_info={
                    "path": span.path,
                    "file_name": file_name,
                    "start_line": span.start_line,
                    "end_line": span.end_line
                }
            )
            results.append(result)

        return results

    def search_and_rerank(
        self,
        query: str,
        spans: List[FileSpan],
        context: Optional[str] = None
    ) -> RerankResponse:
        """
        Full search and rerank pipeline.

        Args:
            query: Search query
            spans: List of FileSpan objects to rank
            context: Optional additional context for the search

        Returns:
            RerankResponse with ranked results
        """
        ranked_results = self.rerank_spans(query, spans)

        reasoning = f"Found {len(ranked_results)} results for query: {query}"

        return RerankResponse(
            results=ranked_results,
            reasoning=reasoning
        )
