from setuptools import setup, find_packages
setup(
    name="odai_downloader",
    version="1.0.1",
    packages=find_packages(),
    install_requires=[
        "httpx"
    ],
    python_requires=">=3.7",
)