from typing import *
import httpx


from ..models import *
from ..api_config import APIConfig, HTTPException

def getTaskHistory(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, task_identifier : str, limit : Optional[int] = None, offset : Optional[int] = None, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> TaskHistoryResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/tasks/{task_identifier}/history'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
            'limit' : limit,
'offset' : offset
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    with httpx.Client(base_url=base_path, verify=api_config.verify) as client:
        response = client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'getTaskHistory failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return TaskHistoryResponse(**body) if body is not None else TaskHistoryResponse()
def getTaskTimeline(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, task_identifier : str, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> TaskTimelineResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/tasks/{task_identifier}/timeline'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    with httpx.Client(base_url=base_path, verify=api_config.verify) as client:
        response = client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'getTaskTimeline failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return TaskTimelineResponse(**body) if body is not None else TaskTimelineResponse()
def getWorkspaceEvents(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, entity_type : Optional[Union[str,None]] = None, entity_id : Optional[Union[str,None]] = None, event_type : Optional[Union[str,None]] = None, actor_id : Optional[Union[str,None]] = None, since : Optional[Union[str,None]] = None, until : Optional[Union[str,None]] = None, limit : Optional[int] = None, offset : Optional[int] = None, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> EventListResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/events'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
            'entity_type' : entity_type,
'entity_id' : entity_id,
'event_type' : event_type,
'actor_id' : actor_id,
'since' : since,
'until' : until,
'limit' : limit,
'offset' : offset
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    with httpx.Client(base_url=base_path, verify=api_config.verify) as client:
        response = client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'getWorkspaceEvents failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return EventListResponse(**body) if body is not None else EventListResponse()
def getEvent(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, event_id : int, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> Event:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/events/{event_id}'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    with httpx.Client(base_url=base_path, verify=api_config.verify) as client:
        response = client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'getEvent failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return Event(**body) if body is not None else Event()