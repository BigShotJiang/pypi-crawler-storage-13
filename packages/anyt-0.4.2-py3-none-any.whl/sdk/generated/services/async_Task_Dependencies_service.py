from typing import *
import httpx


from ..models import *
from ..api_config import APIConfig, HTTPException

async def getTaskDependencies(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, task_identifier : str, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> List[DependencyTaskInfo]:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/tasks/{task_identifier}/dependencies'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'getTaskDependencies failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return [DependencyTaskInfo(**item) for item in body]
async def addTaskDependency(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, task_identifier : str, data : AddDependencyRequest, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> DependencyResponse:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/tasks/{task_identifier}/dependencies'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'post',
        httpx.URL(path),
        headers=headers,
        params=query_params,
                        json = data.model_dump()
                    )

    if response.status_code != 201:
        raise HTTPException(response.status_code, f'addTaskDependency failed with status code: {response.status_code}')
    else:
                body = None if 201 == 204 else response.json()

    return DependencyResponse(**body) if body is not None else DependencyResponse()
async def removeTaskDependency(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, task_identifier : str, depends_on_identifier : str, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> None:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/tasks/{task_identifier}/dependencies/{depends_on_identifier}'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'delete',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 204:
        raise HTTPException(response.status_code, f'removeTaskDependency failed with status code: {response.status_code}')
    else:
                body = None if 204 == 204 else response.json()

    return None

async def getTaskDependents(api_config_override : Optional[APIConfig] = None, *, workspace_id : int, task_identifier : str, X_API_Key : Optional[Union[str,None]] = None, X_Worker_Token : Optional[Union[str,None]] = None, X_Test_User_Id : Optional[Union[str,None]] = None) -> List[DependencyTaskInfo]:
    api_config = api_config_override if api_config_override else APIConfig()

    base_path = api_config.base_path
    path = f'/v1/workspaces/{workspace_id}/tasks/{task_identifier}/dependents'
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer { api_config.get_access_token() }',
        'X-API-Key' : X_API_Key,
'X-Worker-Token' : X_Worker_Token,
'X-Test-User-Id' : X_Test_User_Id
    }
    headers = {key:value for (key,value) in headers.items() if value is not None and not (key == 'Authorization' and value == 'Bearer None')}
    query_params : Dict[str,Any] = {
        }

    query_params = {key:value for (key,value) in query_params.items() if value is not None}

    async with httpx.AsyncClient(base_url=base_path, verify=api_config.verify) as client:
        response = await client.request(
            'get',
        httpx.URL(path),
        headers=headers,
        params=query_params,
            )

    if response.status_code != 200:
        raise HTTPException(response.status_code, f'getTaskDependents failed with status code: {response.status_code}')
    else:
                body = None if 200 == 204 else response.json()

    return [DependencyTaskInfo(**item) for item in body]