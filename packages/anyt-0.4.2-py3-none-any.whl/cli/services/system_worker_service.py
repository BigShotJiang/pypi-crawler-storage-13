"""System worker service with business logic for demo task execution.

⚠️ DEPRECATED - DO NOT USE ⚠️

This service is deprecated and kept only for backwards compatibility.
Use SystemWorkerCoordinator instead for workflow-based execution.

The current approach uses:
- SystemWorkerCoordinator with WorkflowExecutor
- Built-in demo_project.yaml workflow (src/cli/worker/workflows/)
- Claude Code integration via anyt/claude-code@v1 action
- No custom Python code for AI execution

This legacy service only supports simple README updates and should not
be used for new development.

See: SystemWorkerCoordinator in cli.services.system_worker_coordinator
"""

import shutil
import subprocess
from pathlib import Path
from typing import Any, Optional

from rich.console import Console

from cli.client.workers import WorkersAPIClient
from cli.services.base import BaseService

console = Console()


class SystemWorkerService(BaseService):
    """DEPRECATED: Legacy system worker service.

    ⚠️ This service is deprecated. Use SystemWorkerCoordinator instead.

    SystemWorkerCoordinator provides workflow-based execution using the
    built-in demo_project.yaml workflow, which is simpler and more
    maintainable than this imperative approach.

    This legacy service only supports:
    - Simple README updates
    - Basic task claiming and completion
    - Git operations

    For AI-powered task execution, use SystemWorkerCoordinator.

    Example (DEPRECATED - use SystemWorkerCoordinator instead):
        ```python
        # Legacy approach (deprecated)
        service = SystemWorkerService.from_config()
        task = await service.get_next_task()
        success = await service.execute_demo_task(task, workspace_dir)

        # Current approach (use this instead)
        coordinator = SystemWorkerCoordinator(workspace_dir=Path("/tmp/workspace"))
        await coordinator.run()
        ```
    """

    workers_client: WorkersAPIClient

    def _init_clients(self) -> None:
        """Initialize API clients.

        DEPRECATED: This service is deprecated. Use SystemWorkerCoordinator
        with workflow-based execution instead.
        """
        self.workers_client = WorkersAPIClient.from_env()
        console.print(
            "[yellow]⚠️  SystemWorkerService is deprecated. "
            "Use SystemWorkerCoordinator with workflow-based execution.[/yellow]"
        )

    async def get_next_task(self) -> Optional[dict[str, Any]]:
        """Get next task to process.

        Retrieves the highest priority TODO task from demo projects.

        Returns:
            Task dict if available, None if no tasks found
        """
        # List TODO tasks from demo projects
        tasks = await self.workers_client.list_demo_tasks(status="todo", limit=1)

        if not tasks:
            return None

        # Return first task as dict (convert from wrapper)
        task = tasks[0]
        return task.to_generated().model_dump(mode="json")

    async def claim_task(self, identifier: str) -> dict[str, Any]:
        """Claim task by updating status and assignee.

        Sets:
        - status = "active"
        - assignee_type = "agent"
        - owner_id = "system-worker"

        Args:
            identifier: Task identifier (e.g., DEMO-42)

        Returns:
            Updated task dict

        Raises:
            NotFoundError: If task not found
            APIError: On other HTTP errors
        """
        # Update task to active with system assignee
        task = await self.workers_client.update_task(
            identifier=identifier,
            status="active",
            assignee_type="agent",
            owner_id="system-worker",
        )

        # Add claiming comment
        await self.workers_client.add_comment(
            identifier=identifier,
            content="🤖 Task claimed by system worker\n\nStarting execution...",
        )

        return task.to_generated().model_dump(mode="json")

    async def execute_demo_task(
        self,
        task: dict[str, Any],
        workspace_dir: Path,
    ) -> bool:
        """Execute a demo task workflow.

        Complete workflow:
        1. Claim task (set status to active)
        2. Get repository clone info
        3. Clone repository
        4. Make changes (update README)
        5. Commit and push changes
        6. Complete task with success comment
        7. Cleanup temporary directory

        Args:
            task: Task dict (from get_next_task or list_demo_tasks)
            workspace_dir: Directory to use for cloning repos

        Returns:
            True if execution succeeded, False if failed
        """
        identifier = task.get("identifier", "")
        repo_dir: Optional[Path] = None

        try:
            # 1. Claim task
            console.print(f"[cyan]Claiming task {identifier}...[/cyan]")
            await self.claim_task(identifier)

            # 2. Get clone info
            project_id = task.get("project", {}).get("id")
            if not project_id:
                raise ValueError("Task missing project.id")

            console.print(
                f"[cyan]Getting clone info for project {project_id}...[/cyan]"
            )
            clone_info = await self.workers_client.get_clone_info(project_id)

            # 3. Clone repository
            repo_dir = workspace_dir / f"demo-{project_id}"
            console.print(f"[cyan]Cloning repository to {repo_dir}...[/cyan]")
            await self._clone_repo(clone_info.clone_url, repo_dir)

            # Add progress comment
            await self.workers_client.add_comment(
                identifier=identifier,
                content="📦 Repository cloned successfully\n\nMaking changes...",
            )

            # 4. Make changes
            console.print("[cyan]Making changes to repository...[/cyan]")
            changes_result = await self._make_changes(task, repo_dir)

            files_changed = changes_result["files_changed"]

            await self.workers_client.add_comment(
                identifier=identifier,
                content=f"📝 Changes made to README\n\nFiles modified: {len(files_changed)}",
            )

            # 5. Commit and push
            commit_message = f"feat: {task.get('title', 'Update')}"
            console.print("[cyan]Committing and pushing changes...[/cyan]")
            await self._commit_and_push(repo_dir, commit_message)

            # Add progress comment
            await self.workers_client.add_comment(
                identifier=identifier,
                content="✅ Changes committed and pushed\n\nFinalizing task...",
            )

            # 6. Complete task
            console.print(f"[green]Completing task {identifier}...[/green]")

            # Build completion comment with change summary
            completion_comment = (
                f"✅ Task completed successfully\n\n"
                f"**Files Changed:** {len(files_changed)}\n\n"
                f"{changes_result['summary']}\n\n"
                f"Changes have been pushed to the repository."
            )

            await self.complete_task(
                identifier=identifier,
                comment=completion_comment,
            )

            # 7. Cleanup
            if repo_dir and repo_dir.exists():
                console.print("[cyan]Cleaning up temporary directory...[/cyan]")
                shutil.rmtree(repo_dir)

            console.print(f"[green]✓[/green] Task {identifier} completed successfully")
            return True

        except Exception as e:
            console.print(f"[red]✗[/red] Task execution failed: {e}")

            # Mark task as failed
            await self.fail_task(identifier, str(e))

            # Cleanup on error
            if repo_dir and repo_dir.exists():
                try:
                    shutil.rmtree(repo_dir)
                except Exception as cleanup_error:
                    console.print(
                        f"[yellow]Warning: Cleanup failed: {cleanup_error}[/yellow]"
                    )

            return False

    async def complete_task(
        self,
        identifier: str,
        comment: Optional[str] = None,
    ) -> dict[str, Any]:
        """Mark task as completed.

        Updates status to "done" and adds optional success comment.

        Args:
            identifier: Task identifier (e.g., DEMO-42)
            comment: Optional completion comment

        Returns:
            Updated task dict

        Raises:
            NotFoundError: If task not found
            APIError: On other HTTP errors
        """
        # Add completion comment first
        if comment:
            await self.workers_client.add_comment(
                identifier=identifier, content=comment
            )

        # Update status to done
        task = await self.workers_client.update_task(
            identifier=identifier,
            status="done",
        )

        return task.to_generated().model_dump(mode="json")

    async def fail_task(
        self,
        identifier: str,
        error: str,
    ) -> dict[str, Any]:
        """Mark task as failed.

        Updates status to "blocked" and adds error comment.

        Args:
            identifier: Task identifier (e.g., DEMO-42)
            error: Error message/reason for failure

        Returns:
            Updated task dict

        Raises:
            NotFoundError: If task not found
            APIError: On other HTTP errors
        """
        # Add error comment
        error_comment = f"❌ Task execution failed\n\nError: {error}"
        await self.workers_client.add_comment(
            identifier=identifier, content=error_comment
        )

        # Update status to blocked
        task = await self.workers_client.update_task(
            identifier=identifier,
            status="blocked",
        )

        return task.to_generated().model_dump(mode="json")

    async def _clone_repo(
        self,
        clone_url: str,
        repo_dir: Path,
    ) -> None:
        """Clone git repository.

        Args:
            clone_url: Git clone URL (may include token)
            repo_dir: Directory to clone into

        Raises:
            subprocess.CalledProcessError: If git clone fails
        """
        # Ensure parent directory exists
        repo_dir.parent.mkdir(parents=True, exist_ok=True)

        # Remove existing directory if present
        if repo_dir.exists():
            shutil.rmtree(repo_dir)

        # Clone repository (suppress output to hide credentials)
        result = subprocess.run(
            ["git", "clone", clone_url, str(repo_dir)],
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode != 0:
            # Sanitize error message (remove potential credentials)
            error_msg = result.stderr.replace(clone_url, "[REDACTED]")
            raise subprocess.CalledProcessError(
                result.returncode,
                ["git", "clone", "[REDACTED]", str(repo_dir)],
                output=result.stdout,
                stderr=error_msg,
            )

    async def _make_changes(
        self,
        task: dict[str, Any],
        repo_dir: Path,
    ) -> dict[str, Any]:
        """Make changes to repository (README update only).

        DEPRECATED: This method only supports simple README updates.
        Use SystemWorkerCoordinator with workflow-based execution instead.

        Args:
            task: Task dict with title and description
            repo_dir: Repository directory

        Returns:
            {
                "method": "readme",
                "files_changed": list[str],
                "summary": str,
            }
        """
        # Simple README update
        console.print("[cyan]Updating README...[/cyan]")
        return self._make_changes_fallback(task, repo_dir)

    def _make_changes_fallback(
        self,
        task: dict[str, Any],
        repo_dir: Path,
    ) -> dict[str, Any]:
        """Simple README update method.

        Args:
            task: Task dict with title and description
            repo_dir: Repository directory

        Returns:
            {
                "method": "readme",
                "files_changed": list[str],
                "summary": str,
            }
        """
        # Find README file
        readme_path = None
        for readme_name in ["README.md", "README.MD", "readme.md", "Readme.md"]:
            candidate = repo_dir / readme_name
            if candidate.exists():
                readme_path = candidate
                break

        # Create README if not found
        if not readme_path:
            readme_path = repo_dir / "README.md"
            readme_path.write_text("# Demo Project\n\n")

        # Read existing content
        content = readme_path.read_text()

        # Add task completion note
        task_title = task.get("title", "Unknown task")
        task_id = task.get("identifier", "")
        update_note = f"\n\n## Updates\n\n- [{task_id}] {task_title}\n"

        # Check if updates section exists
        if "## Updates" in content:
            # Append to updates section
            content = content.replace(
                "## Updates\n", f"## Updates\n- [{task_id}] {task_title}\n"
            )
        else:
            # Add new updates section
            content += update_note

        # Write updated content
        readme_path.write_text(content)

        return {
            "method": "readme",
            "files_changed": ["README.md"],
            "summary": f"Updated README.md with task completion note: [{task_id}] {task_title}",
        }

    async def _commit_and_push(
        self,
        repo_dir: Path,
        message: str,
    ) -> None:
        """Commit and push changes.

        Args:
            repo_dir: Repository directory
            message: Commit message

        Raises:
            subprocess.CalledProcessError: If git operations fail
        """
        # Configure git user (required for commits)
        subprocess.run(
            ["git", "config", "user.name", "AnyTask System Worker"],
            cwd=repo_dir,
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["git", "config", "user.email", "worker@anyt.dev"],
            cwd=repo_dir,
            check=True,
            capture_output=True,
        )

        # Stage all changes
        subprocess.run(
            ["git", "add", "."],
            cwd=repo_dir,
            check=True,
            capture_output=True,
        )

        # Commit changes
        subprocess.run(
            ["git", "commit", "-m", message],
            cwd=repo_dir,
            check=True,
            capture_output=True,
        )

        # Push to remote (suppress output to hide credentials)
        result = subprocess.run(
            ["git", "push", "origin", "main"],
            cwd=repo_dir,
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode != 0:
            # Try 'master' branch if 'main' failed
            result = subprocess.run(
                ["git", "push", "origin", "master"],
                cwd=repo_dir,
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode != 0:
                # Sanitize error message
                error_msg = result.stderr
                raise subprocess.CalledProcessError(
                    result.returncode,
                    ["git", "push"],
                    output=result.stdout,
                    stderr=error_msg,
                )
