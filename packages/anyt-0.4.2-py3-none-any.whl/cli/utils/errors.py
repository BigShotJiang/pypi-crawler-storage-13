"""Error handling utilities for production and development modes."""

import os
from typing import TYPE_CHECKING, NoReturn

import typer

from cli.commands.formatters import OutputManager, stderr_console

if TYPE_CHECKING:
    pass  # pyright: ignore[reportMissingImports]


def is_debug_mode() -> bool:
    """Check if debug mode is enabled via ANYT_DEBUG environment variable."""
    debug_value = os.getenv("ANYT_DEBUG", "false").lower()
    return debug_value in ("1", "true", "yes", "on")


def install_traceback_handler() -> None:
    """Install rich traceback handler if in debug mode."""
    if is_debug_mode():
        from rich.traceback import install

        install(show_locals=True, width=120, word_wrap=True)


def handle_api_error(
    error: Exception, context: str = "", json_output: bool = False
) -> NoReturn:
    """Handle API errors with user-friendly messages in production mode.

    Args:
        error: The exception that occurred
        context: Optional context about what operation failed (e.g., "adding comment")
        json_output: Whether to output errors in JSON format

    Raises:
        SystemExit: Always exits with code 1 after displaying error
    """
    # Import at runtime to avoid circular imports and missing module errors
    try:
        from sdk.generated.api_config import HTTPException  # pyright: ignore[reportMissingImports]
    except ImportError:
        HTTPException = None  # type: ignore[assignment,misc]

    # In debug mode, let the exception propagate for full stack trace
    if is_debug_mode():
        raise error

    # Create output manager for consistent error formatting
    output = OutputManager(json_mode=json_output)

    if HTTPException is not None and isinstance(error, HTTPException):
        status_code = error.status_code  # pyright: ignore[reportAttributeAccessIssue]

        # Common HTTP error codes with helpful messages
        if status_code == 401:
            message = "Authentication failed. Please check your API key."
            error_code = "UNAUTHORIZED"
            if not json_output:
                stderr_console.print("[red]Error:[/red] Authentication failed")
                stderr_console.print("\nPlease check your API key:")
                stderr_console.print(
                    "  1. Ensure ANYT_API_KEY environment variable is set"
                )
                stderr_console.print("  2. Verify the API key is valid and not expired")
                stderr_console.print(
                    "  3. Check the API URL is correct (ANYT_API_URL or workspace config)"
                )
                stderr_console.print("\nExample:")
                stderr_console.print(
                    "  [cyan]export ANYT_API_KEY=anyt_agent_...[/cyan]"
                )

        elif status_code == 403:
            message = (
                "Permission denied. You don't have access to perform this operation."
            )
            error_code = "FORBIDDEN"
            if not json_output:
                stderr_console.print("[red]Error:[/red] Permission denied")
                stderr_console.print(
                    "\nYou don't have permission to perform this operation. Please check:"
                )
                stderr_console.print("  - You are using the correct workspace")
                stderr_console.print("  - Your API key has the required permissions")

        elif status_code == 404:
            message = "Resource not found. Please check identifiers and access."
            error_code = "NOT_FOUND"
            if not json_output:
                stderr_console.print("[red]Error:[/red] Resource not found")
                stderr_console.print(
                    "\nThe requested resource could not be found. Please check:"
                )
                stderr_console.print("  - Task/workspace identifiers are correct")
                stderr_console.print("  - You have access to the workspace")

        elif status_code == 409:
            message = "Conflict. The operation conflicts with existing data."
            error_code = "CONFLICT"
            if not json_output:
                stderr_console.print("[red]Error:[/red] Conflict")
                stderr_console.print(
                    "\nThe operation conflicts with existing data (e.g., circular dependency)"
                )

        elif status_code == 422:
            message = "Validation error. The data provided is invalid."
            error_code = "VALIDATION_ERROR"
            if not json_output:
                stderr_console.print("[red]Error:[/red] Validation error")
                stderr_console.print(
                    "\nThe data provided is invalid. Please check your input."
                )

        elif status_code >= 500:
            message = f"Server error (HTTP {status_code}). Please try again later."
            error_code = "SERVER_ERROR"
            if not json_output:
                stderr_console.print(
                    f"[red]Error:[/red] Server error (HTTP {status_code})"
                )
                stderr_console.print("\nThe AnyTask API server encountered an error.")
                stderr_console.print(
                    "Please try again later or contact support if the issue persists."
                )

        else:
            message = f"API request failed (HTTP {status_code}): {str(error)}"
            error_code = f"HTTP_{status_code}"
            if not json_output:
                stderr_console.print(
                    f"[red]Error:[/red] API request failed (HTTP {status_code})"
                )
                stderr_console.print(f"\n{str(error)}")

        # Output error in JSON or exit in normal mode
        if json_output:
            # output.error() always raises typer.Exit
            output.error(
                message, error_code=error_code, data={"status_code": status_code}
            )
        else:
            # Debug mode hint
            stderr_console.print(
                "\n[dim]For detailed error information, run with: export ANYT_DEBUG=true[/dim]"
            )
            raise typer.Exit(1)

    else:
        # Generic error handling
        message = str(error)
        error_code = type(error).__name__.upper()

        if json_output:
            # output.error() always raises typer.Exit
            output.error(message, error_code=error_code)
        else:
            stderr_console.print(f"[red]Error:[/red] {message}")
            stderr_console.print(
                "\n[dim]For detailed error information, run with: export ANYT_DEBUG=true[/dim]"
            )
            raise typer.Exit(1)

    # This line should never be reached, but satisfies mypy
    raise typer.Exit(1)


def format_validation_error(error: Exception) -> str:
    """Format validation errors in a user-friendly way.

    Args:
        error: Validation exception

    Returns:
        Formatted error message
    """
    # Extract useful information from Pydantic validation errors
    error_str = str(error)

    # If it's a Pydantic error, try to extract field-specific messages
    if "validation error" in error_str.lower():
        return f"Invalid data: {error_str}"

    return error_str
