"""
Git-related workflow actions.
"""

import asyncio
from typing import Any, Dict

from .base import Action
from ..context import ExecutionContext


class CheckoutAction(Action):
    """Git checkout action."""

    async def execute(
        self, params: Dict[str, Any], ctx: ExecutionContext
    ) -> Dict[str, Any]:
        """Checkout a git branch."""
        branch = params.get("branch", "main")
        clean = params.get("clean", False)

        commands: list[str] = []
        if clean:
            commands.append("git reset --hard")
            commands.append("git clean -fd")
        commands.append(f"git checkout {branch}")
        commands.append("git pull origin {branch}")

        for cmd in commands:
            process = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=ctx.workspace_dir,
            )
            stdout, stderr = await process.communicate()

            if process.returncode != 0:
                raise RuntimeError(f"Git command failed: {stderr.decode()}")

        return {"branch": branch, "clean": clean}


class GitCommitAction(Action):
    """Git commit and optionally push action."""

    async def execute(
        self, params: Dict[str, Any], ctx: ExecutionContext
    ) -> Dict[str, Any]:
        """Commit changes to git and optionally push.

        Args:
            params: Action parameters
                - message: Commit message (default: "Automated commit")
                - add: Files to add - "all" or specific files (default: "all")
                - push: Whether to push after commit (default: False)
                - branch: Branch to push to (optional, uses current branch)
                - force: Use --force-with-lease for push (default: False)

        Returns:
            Dict with commit_hash, committed status, and pushed status
        """
        message = params.get("message", "Automated commit")
        add = params.get("add", "all")
        push = params.get("push", False)
        branch = params.get("branch")
        force = params.get("force", False)

        # Configure git user (required for commits)
        await asyncio.create_subprocess_shell(
            "git config user.name 'AnyTask System Worker'",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=ctx.workspace_dir,
        )
        await asyncio.create_subprocess_shell(
            "git config user.email 'worker@anyt.dev'",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=ctx.workspace_dir,
        )

        # Add files
        if add == "all":
            add_cmd = "git add -A"
        else:
            add_cmd = f"git add {add}"

        process = await asyncio.create_subprocess_shell(
            add_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=ctx.workspace_dir,
        )
        await process.communicate()

        # Commit
        commit_cmd: list[str] = ["git", "commit", "-m", message]
        process = await asyncio.create_subprocess_exec(
            *commit_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=ctx.workspace_dir,
        )

        stdout, stderr = await process.communicate()

        if process.returncode != 0:
            # Check if it's just "nothing to commit"
            if b"nothing to commit" in stdout or b"nothing to commit" in stderr:
                return {"commit_hash": None, "committed": False, "pushed": False}
            raise RuntimeError(f"Git commit failed: {stderr.decode()}")

        # Get commit hash
        process = await asyncio.create_subprocess_shell(
            "git rev-parse --short HEAD",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=ctx.workspace_dir,
        )
        stdout, _ = await process.communicate()
        commit_hash = stdout.decode().strip()

        result = {"commit_hash": commit_hash, "committed": True, "pushed": False}

        # Push if requested
        if push:
            # Get current branch if not specified
            if not branch:
                process = await asyncio.create_subprocess_shell(
                    "git rev-parse --abbrev-ref HEAD",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=ctx.workspace_dir,
                )
                stdout, stderr = await process.communicate()

                if process.returncode != 0:
                    raise RuntimeError(
                        f"Failed to get current branch: {stderr.decode()}"
                    )

                branch = stdout.decode().strip()

            # Push to remote
            # Use --force-with-lease if force=true (safe for retries)
            push_cmd = ["git", "push", "-u", "origin", branch]
            if force:
                push_cmd.append("--force-with-lease")

            process = await asyncio.create_subprocess_exec(
                *push_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=ctx.workspace_dir,
            )

            stdout, stderr = await process.communicate()

            if process.returncode != 0:
                raise RuntimeError(f"Git push failed: {stderr.decode()}")

            result["pushed"] = True
            result["branch"] = branch

        return result
