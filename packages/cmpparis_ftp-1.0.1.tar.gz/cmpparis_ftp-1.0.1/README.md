# cmpparis-ftp

FTP/SFTP utilities for cmpparis libraries.

## Installation

```bash
pip install cmpparis-ftp
```

## Features

- FTP/SFTP file transfer
- Secure authentication
- Simple API

## Usage

```python
from cmpparis_ftp import FTP

ftp = FTP("ftp.example.com", "user", "password")
ftp.upload_file("local.csv", "remote.csv")
ftp.close()
```
