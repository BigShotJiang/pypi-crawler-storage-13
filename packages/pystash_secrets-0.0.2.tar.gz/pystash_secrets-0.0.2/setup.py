from setuptools import setup, find_packages

setup(
    name="pystash_secrets",
    version="0.0.2",
    packages=find_packages(),
    install_requires=[],
    description="Paquete inicial para reservar el nombre en PyPI",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Jose Antonio",
    url="https://github.com/pepe.94/pystash-secrets",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
