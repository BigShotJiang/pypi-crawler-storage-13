from fastapi_sqlalchemy_profiler import __version__


def test_version():
    assert isinstance(__version__, str)
