import logging
import time
from contextvars import ContextVar
from typing import Any

from sqlalchemy import event
from sqlalchemy.ext.asyncio import AsyncEngine

logger = logging.getLogger("fastapi-sqlalchemy-profiler")
from .state import RECENT_SQL_PROFILES

_current_request: ContextVar[Any] = ContextVar("_current_request", default=None)


def attach_sqlalchemy_listeners(engine: AsyncEngine):
    logger.info("""
───────────────────────────────────────────────
 fastapi-sqlalchemy-profiler initialized
 © Claybyte LLC — https://www.claybyte.com
───────────────────────────────────────────────
""")
    sync_engine = engine.sync_engine

    @event.listens_for(sync_engine, "before_cursor_execute")
    def before_cursor_execute(conn, cursor, stmt, params, ctx, many):
        req = _current_request.get()
        if req is None:
            return

        req.state._sql_start = time.time()
        req.state._sql_stmt = stmt
        req.state._sql_params = params

    @event.listens_for(sync_engine, "after_cursor_execute")
    def after_cursor_execute(conn, cursor, stmt, params, ctx, many):
        req = _current_request.get()
        if req is None:
            return

        start = getattr(req.state, "_sql_start", None)
        if start is None:
            return

        duration_ms = (time.time() - start) * 1000

        req.state.sql_profile.append(
            {
                "statement": str(getattr(req.state, "_sql_stmt", stmt)),
                "params": getattr(req.state, "_sql_params", params),
                "time_ms": duration_ms,
            }
        )


def finalize_request(request):
    """
    Build summary for HTML profiler.
    """
    queries = getattr(request.state, "sql_profile", [])
    if not queries:
        return

    total = sum(q["time_ms"] for q in queries)
    avg = total / len(queries)
    slowest = max(queries, key=lambda q: q["time_ms"])

    # N+1 detection
    from collections import Counter

    normalized = [" ".join(q["statement"].lower().split()) for q in queries]
    counts = Counter(normalized)
    n1_list = [
        {"sql": sql, "count": count} for sql, count in counts.items() if count > 1
    ]

    RECENT_SQL_PROFILES.append(
        {
            "path": request.url.path,
            "method": request.method,
            "queries": queries,
            "timestamp": request.state._timestamp,
            "total_queries": len(queries),
            "total_time": total,
            "avg_time": avg,
            "slowest_time": slowest["time_ms"],
            "n_plus_one": n1_list,
        }
    )
