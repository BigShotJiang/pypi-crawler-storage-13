from html import escape

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

from .state import RECENT_SQL_PROFILES

router = APIRouter(prefix="/debug/sql-profiler", include_in_schema=False)


@router.get("", response_class=HTMLResponse)
async def profiler_page():
    profiles = list(RECENT_SQL_PROFILES)[::-1]

    # COUNT how many requests had N+1
    count_n1 = sum(1 for p in profiles if p["n_plus_one"])

    html_parts = [
        """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>FastAPI SQLAlchemy Profiler</title>
<style>
/* ---------------------------
   CLAYBYTE BRAND THEME
   Color palette:
   - Primary Blue: #007aff
   - Secondary Purple: #6C47FF
   - Dark slate background: #0f172a
   --------------------------- */

body {
  margin: 0;
  padding: 0;
  background: #0f172a;
  color: #e2e8f0;
  font-family: 'Inter', system-ui, sans-serif;
}

/* HEADER */
header {
  background: linear-gradient(90deg, #1e293b 0%, #0f172a 100%);
  padding: 18px 26px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #334155;
  box-shadow: 0 4px 14px rgba(0,0,0,0.25);
  position: sticky;
  top: 0;
  z-index: 50;
}

header h1 {
  font-size: 22px;
  margin: 0;
  font-weight: 600;
  color: #60a5fa;
}

.meta {
  font-size: 13px;
  color: #9ca3af;
}

/* REFRESH BUTTON */
.refresh-btn {
  padding: 6px 14px;
  background: linear-gradient(90deg, #007aff 0%, #6C47FF 100%);
  color: white;
  border-radius: 6px;
  font-size: 13px;
  border: none;
  cursor: pointer;
  text-decoration: none;
  transition: opacity 0.2s;
}
.refresh-btn:hover {
  opacity: 0.85;
}

/* MAIN */
main {
  padding: 22px;
}

/* CARDS */
.profile-card {
  background: #1e293b;
  border: 1px solid #334155;
  border-radius: 14px;
  padding: 20px;
  margin-bottom: 18px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.25);
  transition: transform 0.2s, box-shadow 0.3s;
}
.profile-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 30px rgba(0,0,0,0.35);
}

/* METHOD BADGES */
.badge {
  padding: 3px 8px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
}
.badge-get   { background: #0ea5e933; color: #7dd3fc; }
.badge-post  { background: #10b98133; color: #6ee7b7; }
.badge-put   { background: #f59e0b33; color: #fcd34d; }
.badge-delete{ background: #ef444433; color: #fca5a5; }

/* SUMMARY */
.summary {
  font-size: 14px;
  color: #cbd5e1;
  margin-bottom: 10px;
}

/* N+1 WARNING */
.n1-warning {
  margin: 10px 0;
  padding: 16px;
  background: #7f1d1d;
  border-left: 4px solid #ef4444;
  border-radius: 10px;
  color: #fecaca;
}
.pill-count {
  background: #ef4444;
  color: white;
  padding: 2px 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: bold;
}

/* QUERIES */
details summary {
  cursor: pointer;
  font-size: 14px;
  color: #93c5fd;
  margin-bottom: 10px;
}
.query-meta {
  margin-bottom: 6px;
}
.pill-time {
  background: #60a5fa33;
  color: #60a5fa;
  padding: 3px 8px;
  border-radius: 6px;
  font-size: 12px;
}

/* SQL BLOCK */
pre {
  background: #0f0f0f;
  border: 1px solid #1e293b;
  border-radius: 10px;
  padding: 12px;
  font-size: 12px;
  overflow-x: auto;
  white-space: pre-wrap;
  color: #e5e7eb;
}

/* FOOTER */
footer {
  margin-top: 30px;
  text-align: center;
  color: #64748b;
  font-size: 12px;
  padding-top: 18px;
  border-top: 1px solid #334155;
}
footer a {
  color: #60a5fa;
  text-decoration: none;
}
footer a:hover {
  text-decoration: underline;
}
</style>

</head>
<body>
<header>
  <div style="display:flex; align-items:center; gap:14px;">
    <img src="https://www.claybyte.com/logo-5.png"
         alt="Claybyte Logo"
         style="height:44px; border-radius:8px;">

    <div>
      <h1>SQL Profiler</h1>
      <div class="meta">FastAPI • SQLAlchemy Debug Dashboard</div>
    </div>
  </div>

  <a href="" class="refresh-btn">↻ Refresh</a>
</header>
<main>
"""
    ]

    if not profiles:
        html_parts.append("<p>No SQL activity yet.</p>")
    else:
        for profile in profiles:
            method = escape(profile["method"])
            badge_color = "badge-get" if method == "GET" else "badge-post"

            html_parts.append('<div class="profile-card">')

            # Request meta
            html_parts.append(
                f'<div class="profile-header">'
                f'<div><span class="badge {badge_color}">{method}</span> '
                f'<span class="path">{escape(profile["path"])}</span></div>'
                f'<div class="timestamp">{profile["timestamp"]}</div>'
                f"</div>"
            )

            # Summary
            html_parts.append(
                f'<div class="summary">'
                f"Queries: {profile['total_queries']} • "
                f"Total: {profile['total_time']:.2f} ms • "
                f"Avg: {profile['avg_time']:.2f} ms • "
                f"Slowest: {profile['slowest_time']:.2f} ms"
                f"</div>"
            )

            # N+1
            if profile["n_plus_one"]:
                html_parts.append(
                    '<div class="n1-warning">'
                    '<strong style="color:#f87171;">⚠️ N+1 queries detected:</strong><br/><br/>'
                )

                for n1 in profile["n_plus_one"]:
                    sql_preview = escape(n1["sql"][:350])
                    if len(n1["sql"]) > 350:
                        sql_preview += "..."

                    html_parts.append(
                        f"<div>"
                        f'<div class="pill-count">× {n1["count"]}</div>'
                        f"<pre>{sql_preview}</pre>"
                        f"</div>"
                    )

                html_parts.append("</div>")

            # Queries
            html_parts.append("<details><summary>Show queries</summary>")
            for q in profile["queries"]:
                html_parts.append(
                    f'<div class="query">'
                    f'<div class="query-meta"><span class="pill-time">{q["time_ms"]:.2f} ms</span></div>'
                    f"<pre>{escape(q['statement'])}</pre>"
                    f"</div>"
                )
            html_parts.append("</details>")

            html_parts.append("</div>")  # end card

    html_parts.append(
        """
<footer>
  Built by <a href="https://www.claybyte.com" target="_blank">
    Claybyte LLC
  </a> • fastapi-sqlalchemy-profiler
</footer>
"""
    )
    html_parts.append("</main></body></html>")

    return HTMLResponse("".join(html_parts))
