"""
fastapi-sqlalchemy-profiler
SQL profiler for FastAPI + SQLAlchemy with N+1 detection and HTML UI.
Developed by Claybyte LLC — https://www.claybyte.com
"""

__author__ = "Claybyte LLC"
__license__ = "MIT"
__version__ = "0.1.2"
__url__ = "https://github.com/claybyte-llc/fastapi-sqlalchemy-profiler"

from .events import attach_sqlalchemy_listeners
from .html_router import router as profiler_router
from .middleware import SQLProfilerMiddleware

__all__ = [
    "SQLProfilerMiddleware",
    "attach_sqlalchemy_listeners",
    "profiler_router",
]
