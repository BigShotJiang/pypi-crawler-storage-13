from collections import deque
from typing import Any, Deque, Dict

# Rolling buffer: last 100 requests
RECENT_SQL_PROFILES: Deque[Dict[str, Any]] = deque(maxlen=100)
