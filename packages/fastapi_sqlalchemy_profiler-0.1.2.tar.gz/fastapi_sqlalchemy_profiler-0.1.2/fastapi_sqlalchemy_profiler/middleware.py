"""
SQLProfilerMiddleware
Part of fastapi-sqlalchemy-profiler
Developed by Claybyte LLC — https://www.claybyte.com
"""

import datetime

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from .events import _current_request, finalize_request


class SQLProfilerMiddleware(BaseHTTPMiddleware):
    """
    Tracks SQL queries per request and stores them.
    """

    def __init__(self, app, enabled: bool = True):
        super().__init__(app)
        self.enabled = enabled

    async def dispatch(self, request: Request, call_next):
        if not self.enabled:
            return await call_next(request)

        request.state.sql_profile = []
        request.state._timestamp = datetime.datetime.utcnow().isoformat() + "Z"

        token = _current_request.set(request)
        try:
            response = await call_next(request)
        finally:
            _current_request.reset(token)
            finalize_request(request)

        return response
