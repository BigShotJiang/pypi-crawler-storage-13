"""
Система конфигурации через .env
"""

import os
from typing import Optional, Literal
from dataclasses import dataclass
from pathlib import Path


@dataclass
class DatabaseConfig:
    """Конфигурация базы данных"""
    engine: Literal["sqlite", "postgresql"] = "sqlite"
    host: Optional[str] = None
    port: Optional[int] = None
    database: Optional[str] = "bot.db"
    user: Optional[str] = None
    password: Optional[str] = None
    
    @property
    def connection_string(self) -> str:
        """Строка подключения к БД"""
        if self.engine == "sqlite":
            return f"sqlite:///{self.database}"
        elif self.engine == "postgresql":
            return f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"
        raise ValueError(f"Неподдерживаемый движок БД: {self.engine}")


@dataclass
class BotConfig:
    """Конфигурация бота"""
    token: str
    webhook_url: Optional[str] = None
    webhook_secret: Optional[str] = None
    mode: Literal["polling", "webhook"] = "polling"


@dataclass
class WebConfig:
    """Конфигурация веб-сервера"""
    enabled: bool = False
    host: str = "0.0.0.0"
    port: int = 8080
    secret_key: str = "change-me-in-production"
    admin_enabled: bool = True
    cors_origins: str = "*"


@dataclass
class MiniAppConfig:
    """Конфигурация Mini App"""
    enabled: bool = False
    url: Optional[str] = None
    short_name: Optional[str] = None


@dataclass
class Config:
    """Главная конфигурация приложения"""
    bot: BotConfig
    database: DatabaseConfig
    web: WebConfig
    miniapp: MiniAppConfig
    
    # Дополнительные настройки
    debug: bool = False
    log_level: str = "INFO"


def load_config(env_file: Optional[str] = ".env") -> Config:
    """
    Загрузить конфигурацию из .env файла
    
    Args:
        env_file: Путь к .env файлу
        
    Returns:
        Конфигурация приложения
    """
    # Загрузка .env файла
    if env_file and Path(env_file).exists():
        from dotenv import load_dotenv
        load_dotenv(env_file)
    
    # Database config
    db_engine = os.getenv("DB_ENGINE", "sqlite")
    db_config = DatabaseConfig(
        engine=db_engine,
        database=os.getenv("DB_NAME", "bot.db"),
        host=os.getenv("DB_HOST"),
        port=int(os.getenv("DB_PORT", "5432")) if os.getenv("DB_PORT") else None,
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
    )
    
    # Bot config
    bot_token = os.getenv("BOT_TOKEN")
    if not bot_token:
        raise ValueError("BOT_TOKEN не найден в переменных окружения")
    
    bot_config = BotConfig(
        token=bot_token,
        webhook_url=os.getenv("WEBHOOK_URL"),
        webhook_secret=os.getenv("WEBHOOK_SECRET"),
        mode=os.getenv("BOT_MODE", "polling"),
    )
    
    # Web config
    web_config = WebConfig(
        enabled=os.getenv("WEB_ENABLED", "false").lower() == "true",
        host=os.getenv("WEB_HOST", "0.0.0.0"),
        port=int(os.getenv("WEB_PORT", "8080")),
        secret_key=os.getenv("WEB_SECRET_KEY", "change-me-in-production"),
        admin_enabled=os.getenv("ADMIN_ENABLED", "true").lower() == "true",
        cors_origins=os.getenv("CORS_ORIGINS", "*"),
    )
    
    # Mini App config
    miniapp_config = MiniAppConfig(
        enabled=os.getenv("MINIAPP_ENABLED", "false").lower() == "true",
        url=os.getenv("MINIAPP_URL"),
        short_name=os.getenv("MINIAPP_SHORT_NAME"),
    )
    
    return Config(
        bot=bot_config,
        database=db_config,
        web=web_config,
        miniapp=miniapp_config,
        debug=os.getenv("DEBUG", "false").lower() == "true",
        log_level=os.getenv("LOG_LEVEL", "INFO"),
    )

