# CRIPSTEGZ

Image LSB Steganography + Crypto Tool (AES-256-CBC encrypted payload inside PNG images).
