# my_schema_lib/base.py

from .fields import Field

class BaseSchema:
    allow_extra = False

    def __init__(self, **kwargs):
        self._raw = {}
        fields = self._collect_fields()

        # Validate each known field
        for name, field in fields.items():
            value = kwargs.get(name, None)
            self._raw[name] = field.validate(value, name)

        # Optional: reject unknown fields
        if not self.allow_extra:
            unknown = set(kwargs.keys()) - set(fields.keys())
            if unknown:
                raise ValueError(f"Unknown fields: {', '.join(unknown)}")

        self.validate(self._raw)

    @classmethod
    def _collect_fields(cls):
        return {
            name: value
            for name, value in cls.__dict__.items()
            if isinstance(value, Field)
        }

    def validate(self, data):
        """Optionally override for custom validation."""
        pass

    def to_dict(self):
        return self._raw

    @classmethod
    def from_dict(cls, data):
        return cls(**data)
