# my_schema_lib/fields.py

class Field:
    def __init__(self, field_type, required=True, default=None):
        self.field_type = field_type
        self.required = required
        self.default = default

    def validate(self, value, name):
        if value is None:
            if self.required:
                raise ValueError(f"Field '{name}' is required.")
            return self.default

        # Nested schema support
        if hasattr(self.field_type, "validate") and isinstance(value, dict):
            return self.field_type.from_dict(value)

        # List support
        if self.field_type == list:
            if not isinstance(value, list):
                raise ValueError(f"Field '{name}' must be a list.")
            return value

        # Basic type checking
        if not isinstance(value, self.field_type):
            raise ValueError(
                f"Field '{name}' must be of type {self.field_type.__name__}, got {type(value).__name__}."
            )

        return value
