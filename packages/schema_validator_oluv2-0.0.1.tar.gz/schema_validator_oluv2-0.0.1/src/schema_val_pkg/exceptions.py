class ValidationError(Exception):
    """Represents a schema validation failure."""
    pass
