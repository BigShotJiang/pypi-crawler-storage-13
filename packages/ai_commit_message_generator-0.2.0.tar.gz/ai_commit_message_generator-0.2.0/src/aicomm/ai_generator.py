from .preprocess import clean_diff
import os
import re

# Try to import OpenAI
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

def generate_with_openai(diff):
    """Generate commit message using OpenAI API"""
    api_key = os.environ.get('OPENAI_API_KEY')
    if not api_key:
        return None
    
    try:
        client = OpenAI(api_key=api_key)
        
        prompt = f"""Generate a concise git commit message for the following code changes.
Follow conventional commits format (feat/fix/refactor/docs/style/test/chore).
Keep it under 50 characters, be specific about what changed.

Diff:
{diff[:2000]}

Commit message:"""
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=50,
            temperature=0.3
        )
        
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"OpenAI API error: {e}")
        return None

def generate_rule_based(diff):
    """Fallback: fast rule-based commit message generation"""
    cleaned = clean_diff(diff)
    
    if not cleaned.strip():
        return "chore: update project files"
    
    lines = cleaned.splitlines()
    added_lines = [l[1:].strip() for l in lines if l.startswith('+')]
    removed_lines = [l[1:].strip() for l in lines if l.startswith('-')]
    
    added_count = len(added_lines)
    removed_count = len(removed_lines)
    
    # Analyze what changed
    added_text = ' '.join(added_lines).lower()
    
    if 'fix' in added_text or 'bug' in added_text:
        prefix = 'fix'
    elif 'test' in added_text:
        prefix = 'test'
    elif 'def ' in added_text or 'class ' in added_text:
        prefix = 'feat'
    elif 'import ' in added_text:
        prefix = 'chore'
    elif added_count > removed_count:
        prefix = 'feat'
    elif removed_count > added_count:
        prefix = 'refactor'
    else:
        prefix = 'chore'
    
    # Generate message
    if added_count > 0 and removed_count > 0:
        return f"{prefix}: update code (+{added_count}/-{removed_count})"
    elif added_count > 0:
        return f"{prefix}: add new features (+{added_count})"
    elif removed_count > 0:
        return f"{prefix}: remove code (-{removed_count})"
    else:
        return "chore: update files"

def generate_commit_message(diff):
    """Generate commit message - tries OpenAI first, falls back to rules"""
    
    # Try OpenAI if available
    if OPENAI_AVAILABLE and os.environ.get('OPENAI_API_KEY'):
        message = generate_with_openai(diff)
        if message:
            return message
    
    # Fallback to rule-based
    return generate_rule_based(diff)
