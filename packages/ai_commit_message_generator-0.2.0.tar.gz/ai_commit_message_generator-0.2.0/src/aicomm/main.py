import argparse
import subprocess
from .get_diff import get_latest_diff
from .ai_generator import generate_commit_message

def auto_commit(msg):
    # Use subprocess to properly escape the commit message
    subprocess.run(['git', 'add', '.'], check=False)
    subprocess.run(['git', 'commit', '-m', msg], check=True)

def main(argv=None):
    parser = argparse.ArgumentParser(description="AI Commit Message Generator")
    parser.add_argument("--paste", type=str, help="Provide diff text manually")
    parser.add_argument("--commit", action="store_true")
    args = parser.parse_args(argv)

    diff = args.paste if args.paste else get_latest_diff()
    msg = generate_commit_message(diff)

    print("\nSuggested Commit Message:\n📝", msg, "\n")

    if args.commit:
        auto_commit(msg)
        print("Committed successfully.")
