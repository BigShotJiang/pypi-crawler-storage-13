import re

def clean_diff(diff_text):
    if not diff_text:
        return ""

    cleaned = re.sub(r'(^---.*|^\+\+\+.*|^index .*|^@@ .*@@.*)',
                     '', diff_text, flags=re.MULTILINE)

    lines = cleaned.splitlines()
    return "\n".join(l for l in lines if l.startswith('+') or l.startswith('-'))
