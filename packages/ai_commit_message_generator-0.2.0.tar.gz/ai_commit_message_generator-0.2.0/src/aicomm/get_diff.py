from git import Repo, InvalidGitRepositoryError

def get_latest_diff(repo_path='.'):
    try:
        repo = Repo(repo_path)
    except InvalidGitRepositoryError:
        raise RuntimeError("Not a valid git repository.")

    try:
        return repo.git.diff('HEAD~1', 'HEAD')
    except Exception:
        return repo.git.diff('--staged')
