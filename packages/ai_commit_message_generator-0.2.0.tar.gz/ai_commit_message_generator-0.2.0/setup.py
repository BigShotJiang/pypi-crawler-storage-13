from setuptools import setup, find_packages

setup(
    name="ai-commit-message-generator",
    version="0.2.0",
    packages=find_packages("src"),
    package_dir={"": "src"},
    entry_points={"console_scripts": ["aicomm=aicomm.cli:run"]},
    install_requires=[
        "gitpython",
        "openai>=1.0.0"
    ],
    python_requires=">=3.8",
)
