from aicomm.preprocess import clean_diff

def test_clean_diff():
    diff = "--- a/file\n+++ b/file\n-line\n+newline"
    cleaned = clean_diff(diff)
    assert "+newline" in cleaned
