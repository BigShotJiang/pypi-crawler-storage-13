# Ardent Python SDK

Official Python SDK for Ardent AI - Simplify your data engineering tasks with AI-powered automation.

[![PyPI version](https://badge.fury.io/py/ardent-sdk.svg)](https://badge.fury.io/py/ardent-sdk)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

## Installation

```bash
pip install ardent-sdk
```

## Quick Start

```python
from ardent import ArdentClient

# Initialize the client
with ArdentClient(api_key="sk-ard_test_xxxxx") as client:
    # Create and execute a job
    job = client.create_job("Analyze sales data and generate report")
    result = client.execute_job(
        jobID=job["id"],
        message="Analyze sales data and generate report",
        files_share_name=job["files_share_name"],
        userID=job["userID"]
    )
    print(result)

    # Setup a data connector
    connector = client.setup_connector(
        service_name="postgresql",
        connection_details={
            "host": "localhost",
            "port": 5432,
            "database": "mydb",
            "username": "user",
            "password": "pass"
        },
        name="Production Database",
        selected_paths=["public.users", "public.orders"]
    )
```

## Features

- **Job Management**: Create and execute AI-powered data engineering tasks
- **Data Connectors**: Connect to PostgreSQL, MySQL, MongoDB, Airflow, and more
- **Data Discovery**: Automatically discover schemas and data structures
- **Intelligent Indexing**: Index and vectorize your data for AI operations
- **Context Management**: Automatic resource cleanup with context managers
- **Type Safety**: Full type hints for better IDE support

## Documentation

For comprehensive documentation, including:
- Complete API reference
- Advanced usage patterns
- Release process and versioning
- Development and contribution guidelines

**Visit: [docs/sdk/sdk-py.md](../docs/sdk/sdk-py.md)**

## Error Handling

```python
from ardent import ArdentClient, ArdentAPIError, ArdentAuthError

try:
    with ArdentClient(public_key, secret_key) as client:
        job = client.create_job("My task")
except ArdentAuthError:
    print("Authentication failed - check your API keys")
except ArdentAPIError as e:
    print(f"API error: {e}")
```

## Requirements

- Python 3.8+
- httpx >= 0.24.0
- python-dotenv >= 0.19.0

## Support

- **Documentation**: https://docs.ardentai.io
- **Issues**: [GitHub Issues](https://github.com/ArdentAILabs/ArdentAPI/issues)
- **Email**: vikram@ardentai.io

## License

MIT License - see the [LICENSE](LICENSE) file for details.
