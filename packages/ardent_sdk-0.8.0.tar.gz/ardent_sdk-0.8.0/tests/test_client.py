import os
from ardent import ArdentClient, ArdentError, ArdentValidationError
from dotenv import load_dotenv
from uuid import uuid4

load_dotenv()

Ardent_Client = ArdentClient(
    api_key=os.getenv("ARDENT_API_KEY"),
    base_url=os.getenv("BASE_URL", "http://127.0.0.1:8000"),
)
