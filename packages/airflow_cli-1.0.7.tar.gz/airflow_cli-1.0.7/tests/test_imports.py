import pytest
from src import docker_utils, os_utils, cli


def test_imports():
    """Verify that all modules can be imported without error."""
    assert docker_utils is not None
    assert os_utils is not None
    assert cli is not None
