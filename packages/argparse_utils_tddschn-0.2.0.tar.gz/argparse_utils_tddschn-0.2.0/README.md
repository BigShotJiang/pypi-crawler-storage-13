# Argparse Utils (tddschn)

Utilities for dynamically removing or renaming argparse arguments without rewriting the original CLI definition.

## Features
- Remove an option (including from mutually exclusive groups) by dest or option string.
- Replace an argument's option strings atomically with conflict detection.

## Installation
```bash
pip install argparse-utils-tddschn
```

## Usage
```python
import argparse
from argparse_utils import remove_argument, replace_argument_names

parser = argparse.ArgumentParser()
parser.add_argument("-c", "--config")
parser.add_argument("--dry-run", action="store_true")

remove_argument(parser, "--dry-run")
replace_argument_names(parser, "--config", ["-C", "--configuration"])
```

## Development
```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
pytest
```

## License
MIT