# AIcompiler

AIcompiler is a tool that lets you write pseudocode and automatically converts it into standard C code using AI. Although the tool generates your C code, you will still need to have GCC installed to compile it yourself.

> **Credits**: Original tool created by **LordWeegie**. Enhanced and packaged for PyPI by **Max** with additional features and security improvements.

## Features

- 🔐 **Secure API key storage** with password-based encryption
- 🔄 **Multi-provider support**: DeepSeek, OpenAI, Gemini, Custom APIs
- 💻 **Full CLI application** with interactive prompts
- 📁 **Flexible file handling** - interactive or command-line arguments
- 👁️ **Code preview** - view generated C code
- 🛡️ **Encrypted configuration** stored securely

## Enhancements by Max

- **PyPI Package Distribution**: Made installable via pip
- **Secure Authentication**: Encrypted API key storage with master password
- **Multi-Provider Support**: Works with DeepSeek, OpenAI, Gemini, and custom APIs
- **Improved CLI**: Better user interface with interactive prompts
- **Code Preview**: View generated code without opening files
- **Error Handling**: Robust error handling and user feedback
- **Configuration Management**: Easy setup and configuration system

## Original Features by LordWeegie

- Core pseudocode to C conversion functionality
- DeepSeek API integration
- File input/output system
- Basic CLI interface

## Installation

### Method 1: Install from PyPI (Recommended)
```bash
pip install aicompiler
