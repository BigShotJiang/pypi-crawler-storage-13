from typing import List
from typing_extensions import TypedDict

# 加载 PP-OCRv5 模型（maxSideLen 一般为 640）
def load_v5(maxSideLen: int = ...) -> bool: ...

class OCRResult(TypedDict):
    text: str
    confidence: float
    x: int
    y: int
    ex: int
    ey: int
    width: int
    height: int
    centerX: int
    centerY: int
    angle: float
    orientation: int
def recognize(
    input: str, x: int, y: int, ex: int, ey: int, confidenceThreshold: float
) -> List[OCRResult]: ...

# 释放模型资源
def free() -> None: ...
