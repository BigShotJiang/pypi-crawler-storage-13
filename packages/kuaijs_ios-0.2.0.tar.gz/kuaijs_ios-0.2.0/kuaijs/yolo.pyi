from typing import List, Optional
from typing_extensions import TypedDict

# 加载 YOLOv11 模型，返回模型ID
def load_v11(paramPath: str, binPath: str, nc: int) -> Optional[str]: ...

# 目标检测（返回边框/置信度/类别等）
class YoloResult(TypedDict):
    x: int
    y: int
    ex: int
    ey: int
    centerX: int
    centerY: int
    width: int
    height: int
    confidence: float
    classId: int
def detect(
    modelId: str, input: str, targetSize: int, threshold: float, nmsThreshold: float
) -> List[YoloResult]: ...

# 释放指定模型/所有模型
def free(modelId: str) -> None: ...
def free_all() -> None: ...
