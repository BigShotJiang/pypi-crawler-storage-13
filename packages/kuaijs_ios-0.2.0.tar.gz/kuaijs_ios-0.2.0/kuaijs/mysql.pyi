from typing import Any, List
from typing_extensions import TypedDict

# 连接配置：host/port/username/password/database/charset
class MySQLConfig(TypedDict, total=False):
    host: str
    port: int
    username: str
    password: str
    database: str
    charset: str
def connect(config: MySQLConfig) -> bool: ...
def disconnect() -> None: ...
def is_connected() -> bool: ...

# 查询/执行，返回字典：rows/affectedRows/insertId/success/error
class MySQLResult(TypedDict, total=False):
    rows: List[dict]
    affectedRows: int
    insertId: int
    success: bool
    error: str
def query(sql: str, params: List[Any] = ...) -> MySQLResult: ...
def execute(sql: str, params: List[Any] = ...) -> MySQLResult: ...

# 事务控制
def begin_transaction() -> bool: ...
def commit() -> bool: ...
def rollback() -> bool: ...
