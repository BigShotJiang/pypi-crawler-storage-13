# Arbiter — The Coherence Engine

Arbiter measures semantic coherence between a query and multiple candidates. It mirrors the production API, so teams can prototype with the local CLI and import the same interface in Python.

## Features
- `arb.iter(query, candidates)` helper returns scored candidates sorted by coherence.
- CLI: `arb "query" "cand1" "cand2" ...` prints ranked results.
- Works immediately via the public Arbiter endpoint; set `ARBITER_API_KEY` to target private quotas.

## Installation

```bash
pip install arbiter-engine
```

## Python Usage

```python
from arbiter import iter

scores = iter("jaguar speed", ["animal running", "car performance"])
for text, score in scores:
    print(f"{score:.3f}  {text}")
```

## CLI Usage

```bash
arb "jaguar speed" "animal running" "car performance"
```

## API Keys

The package automatically routes to Arbiter’s public endpoint. Provide an API key to access your private quota and frequency-mapped embeddings:

```bash
export ARBITER_API_KEY=arb_xxx
```

## License

MIT
