"""
Arbiter Engine - Semantic Coherence Infrastructure

Usage:
    # The pun way
    >>> import arbiter_engine as arb
    >>> arb.iter("query", ["a", "b", "c"])
    
    # The semantic way
    >>> from arbiter_engine import rank
    >>> r = rank("query", ["a", "b", "c"])
    >>> print(r.top.text)
    
    # CLI
    $ arb "query" candidate1 candidate2 candidate3
    $ arb --json "query" candidate1 candidate2
"""

from .core import iter, rank
from .api import Ranking, Ranked, ArbiterError, ArbiterNetworkError, ArbiterAPIError, ArbiterRateLimitError
from .version import __version__

__all__ = [
    # Functions
    "iter",
    "rank",
    # Data types
    "Ranking",
    "Ranked",
    # Exceptions
    "ArbiterError",
    "ArbiterNetworkError", 
    "ArbiterAPIError",
    "ArbiterRateLimitError",
    # Meta
    "__version__",
]
