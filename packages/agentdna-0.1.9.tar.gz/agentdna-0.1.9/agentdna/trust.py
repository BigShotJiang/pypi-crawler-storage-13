import json
import os
from typing import Any, Dict, Optional

import requests
from rubix.client import RubixClient
from rubix.signer import Signer
from rubix.did import online_signature_verify, signatureResponseError

from .node_client import NodeClient


class RubixTrustService:
    """
    Handles:
      - RubixClient + Signer
      - DID management
      - Signing envelopes
      - Verifying signatures via /api/verify-signature
    """

    def __init__(
        self,
        alias: str,
        timeout: float = 300.0,
    ) -> None:
        node = NodeClient(alias=alias)
        self.base_url = node.get_base_url().rstrip("/")
        self.timeout = timeout

        client = RubixClient(node_url=self.base_url, timeout=timeout)

        self.signer = Signer(rubixClient=client, alias=alias)
        self.did = self.signer.did

        print("✅ RubixTrustService DID:", self.did)
        print("✅ RubixTrustService base URL:", self.base_url)

    # ---------- signing ----------

    def sign_envelope(self, envelope: Dict[str, Any]) -> Dict[str, Any]:
        """
        Sign an envelope dict and return a block:
          { "agent": <did>, "envelope": {...}, "signature": "<hex>" }
        """
        print("Agent is going to sign")
        print("Public Key (hex): ", self.signer.get_keypair().public_key)
        keypair = self.signer.get_keypair()

        envelope_json = json.dumps(envelope, sort_keys=True)
        envelope_bytes = envelope_json.encode("utf-8")
        signature_bytes = keypair.sign(envelope_bytes)
        signature_hex = signature_bytes.hex()
        return {
            "agent": self.did,
            "envelope": envelope,
            "signature": signature_hex,
        }

    # ---------- verification ----------

    def verify_envelope(
        self,
        signer_did: str,
        envelope: Dict[str, Any],
        signature: str,                 # hex string from sign_envelope
        timeout: Optional[float] = None # kept for API compat, not used
    ) -> bool:
        """
        Verify that `signature` is valid for the given DID + envelope.
        Uses Rubix node's online_signature_verify helper.
        """

        # 1) Build canonical JSON exactly as in sign_envelope
        envelope_json = json.dumps(envelope, sort_keys=True)
        message_bytes = envelope_json.encode("utf-8")

        # 2) Convert hex string -> raw bytes for verifier
        try:
            signature_bytes = bytes.fromhex(signature)
        except ValueError:
            print("⚠️ verify_envelope: invalid hex signature string")
            return False

        # 3) Delegate to Rubix helper
        try:
            is_valid = online_signature_verify(
                rubixNodeBaseUrl=self.base_url,
                did=signer_did,
                message=message_bytes,
                signature=signature_bytes,
            )
            return bool(is_valid)
        except signatureResponseError as e:
            print(f"⚠️ verify_envelope error: {e}")
            return False
        
    def verify_message_payload(
        self,
        raw_text: str,
        mode: str = "light",  # "light" or "heavy"
    ) -> dict:
        """
        Verify signatures inside a host/agent JSON bundle.

        raw_text: the text from the incoming message (host or remote).
        mode:
          - "light": verify only `host` block if present
          - "heavy": verify `host` + any blocks in `responses` list, if present

        Returns:
          {
            "original_message": <str>,    # what ADK should see
            "host_ok": True/False/None,
            "response_results": [ { "index": i, "ok": bool }, ... ] or None,
            "trust_issues": [ ... ] or None,
        }
        """
        trust_issues: list[str] = []
        host_ok: bool | None = None
        response_results: list[dict] = []

        # Default: assume the raw_text is the original message.
        original_message = raw_text

        # Try to parse JSON
        try:
            payload = json.loads(raw_text)
        except Exception:
            return {
                "original_message": original_message,
                "host_ok": None,
                "response_results": None,
                "trust_issues": None,
            }

        if not isinstance(payload, dict):
            return {
                "original_message": original_message,
                "host_ok": None,
                "response_results": None,
                "trust_issues": None,
            }

        # ----- HOST BLOCK -----
        host_block = payload.get("host")
        if host_block:
            env = host_block.get("envelope", {})
            sig = host_block.get("signature")
            did = host_block.get("agent")

            # derive original_message if present
            if isinstance(env, dict) and "original_message" in env:
                original_message = env["original_message"]

            if did and env and sig:
                host_ok = self.verify_envelope(did, env, sig)
                if not host_ok:
                    trust_issues.append("Host signature invalid")
            else:
                trust_issues.append("Host block missing DID/envelope/signature")

        # ----- HEAVY MODE: RESPONSES LIST -----
        if mode == "heavy":
            responses = payload.get("responses", [])
            if isinstance(responses, list):
                for idx, block in enumerate(responses):
                    if not isinstance(block, dict):
                        continue
                    did = block.get("agent")
                    env = block.get("envelope", {})
                    sig = block.get("signature")
                    if not (did and env and sig):
                        trust_issues.append(f"Response[{idx}] missing DID/envelope/signature")
                        response_results.append({"index": idx, "ok": False})
                        continue

                    ok = self.verify_envelope(did, env, sig)
                    response_results.append({"index": idx, "ok": bool(ok)})
                    if not ok:
                        trust_issues.append(f"Response[{idx}] signature invalid")

        return {
            "original_message": original_message,
            "host_ok": host_ok,
            "response_results": response_results or None,
            "trust_issues": trust_issues or None,
        }