import datetime
import os
from collections import defaultdict
from typing import Dict, List


class Report:
    """
    Bulunan zafiyetleri severity bazlı toplayan rapor sınıfı.
    Hem Markdown hem basit HTML çıktı üretebilir.
    """

    def __init__(self, target: str):
        self.target = target
        self.findings: Dict[str, List[dict]] = defaultdict(list)

    def add(self, severity: str, category: str, url: str, detail: str):
        self.findings[severity].append(
            {"category": category, "url": url, "detail": detail}
        )

    def summary(self):
        return {k: len(v) for k, v in self.findings.items()}

    def write_markdown(self, path: str):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"# ZNUZHG Pentest Report\n\n")
            f.write(f"**Target:** `{self.target}`\n\n")
            f.write(f"**Generated at:** {datetime.datetime.now().isoformat()}\n\n")

            f.write("## Summary\n\n")
            for sev, count in self.summary().items():
                f.write(f"- **{sev.upper()}**: {count} finding(s)\n")
            f.write("\n---\n")

            for sev in sorted(self.findings.keys()):
                f.write(f"\n## {sev.upper()} Findings\n\n")
                for idx, item in enumerate(self.findings[sev], 1):
                    f.write(f"### {idx}. {item['category']}\n")
                    f.write(f"- URL: `{item['url']}`\n")
                    f.write(f"- Detail:\n\n```\n{item['detail']}\n```\n\n")

    def write_html(self, path: str):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write("<!DOCTYPE html><html><head><meta charset='utf-8'>")
            f.write("<title>ZNUZHG Pentest Report</title>")
            f.write(
                "<style>body{font-family:Arial, sans-serif;background:#0b1020;color:#f5f5f5;padding:20px}"
                "h1,h2,h3{color:#00ffc8}code,pre{background:#111827;padding:8px;border-radius:6px;display:block}"
                ".sev-high{color:#ff4d4d}.sev-medium{color:#ffc14d}.sev-low{color:#4dc3ff}.sev-info{color:#c4c4c4}"
                "a{color:#38bdf8}</style>"
            )
            f.write("</head><body>")
            f.write("<h1>ZNUZHG Pentest Report</h1>")
            f.write(f"<p><b>Target:</b> {self.target}</p>")
            f.write(f"<p><b>Generated at:</b> {datetime.datetime.now().isoformat()}</p>")

            f.write("<h2>Summary</h2><ul>")
            for sev, count in self.summary().items():
                cls = f"sev-{sev}"
                f.write(f"<li class='{cls}'><b>{sev.upper()}</b>: {count} finding(s)</li>")
            f.write("</ul><hr>")

            for sev in sorted(self.findings.keys()):
                cls = f"sev-{sev}"
                f.write(f"<h2 class='{cls}'>{sev.upper()} Findings</h2>")
                for idx, item in enumerate(self.findings[sev], 1):
                    f.write(f"<h3>{idx}. {item['category']}</h3>")
                    f.write(f"<p><b>URL:</b> <code>{item['url']}</code></p>")
                    f.write("<pre><code>")
                    f.write(item["detail"])
                    f.write("</code></pre>")
            f.write("</body></html>")
