"""
Streaming utilities for ads4gpts-core

This module provides utilities for working with async streams:
- merge_streams: Sequentially process two async streams
"""

from .merge_streams import merge_streams

__all__ = [
    'merge_streams',
]