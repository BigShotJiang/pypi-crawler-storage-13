"""
Integration agent module for ads4gpts-core

Provides functions to invoke the LangGraph integration agent with
proper configuration and client setup.
"""

from .create_client import create_client
from .configure_graph import configure_graph
from .integration_agent import invoke_integration_agent

__all__ = [
    'create_client',
    'configure_graph',
    'invoke_integration_agent',
]