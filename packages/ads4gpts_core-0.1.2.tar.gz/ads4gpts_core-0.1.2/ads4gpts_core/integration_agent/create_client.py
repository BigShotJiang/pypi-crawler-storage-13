"""
Create LangGraph client
"""
from typing import Optional
from langgraph_sdk import get_client


def create_client(api_url: str, api_key: Optional[str] = None):
    """
    Create LangGraph client
    
    Args:
        api_url: The API URL for the LangGraph service
        api_key: Optional API key for authentication
        
    Returns:
        LangGraph Client instance
        
    Example:
```python
        client = create_client(
            api_url="http://localhost:8123",
            api_key="your-api-key"  # optional
        )
```
    """
    return get_client(url=api_url, api_key=api_key)