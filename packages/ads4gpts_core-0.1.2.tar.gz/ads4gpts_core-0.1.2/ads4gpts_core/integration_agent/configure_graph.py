"""
Build graph configuration from parameters
"""

import os
from typing import Optional, Literal
from ads4gpts_core.types import Config, GraphConfig


def configure_graph(
    session_id: str,
    integration_system_prompt: str,
    integration_user_prompt: str,
    recursion_limit: int,
    owner: Optional[str] = None,
    gpt_id: Optional[str] = None,
    ads4gpts_api_key: Optional[str] = None,
    ssp_id: Optional[str] = None,
    integration_model_provider: Literal["OPENAI", "ANTHROPIC"] = "OPENAI",
    integration_model_name: Literal[
        "gpt-4o", "gpt-4o-mini", "claude-3-opus"
    ] = "gpt-4o",
) -> Config:
    """
        Build graph configuration from environment variables and parameters

        Args:
            session_id: Session identifier
            integration_system_prompt: System prompt for the integration
            integration_user_prompt: User prompt template for the integration
            recursion_limit: Maximum number of graph recursions
            owner: GPT owner identifier
            gpt_id: GPT ID (defaults to ADS4GPTS_GPT_ID env var)
            ads4gpts_api_key: API key (defaults to ADS4GPTS_API_KEY env var)
            ssp_id: SSP ID (defaults to ADS4GPTS_SSP_ID env var)
            integration_model_provider: Model provider (OPENAI or ANTHROPIC)
            integration_model_name: Model name

        Returns:
            Config object with configurable graph settings

        Example:
    ```python
            config = configure_graph(
                session_id="session_123",
                integration_system_prompt="You are a helpful assistant",
                integration_user_prompt="User: {input}",
                recursion_limit=100,
                integration_model_provider="OPENAI",
                integration_model_name="gpt-4o"
            )
    ```
    """
    graph_config: GraphConfig = {
        "session_id": session_id,
        "owner": owner,
        "gpt_id": gpt_id or os.getenv("ADS4GPTS_GPT_ID", ""),
        "ads4gpts_api_key": ads4gpts_api_key or os.getenv("ADS4GPTS_API_KEY", ""),
        "ssp_id": ssp_id or os.getenv("ADS4GPTS_SSP_ID", ""),
        "integration_system_prompt": integration_system_prompt,
        "integration_user_prompt": integration_user_prompt,
        "integration_model_provider": integration_model_provider,
        "integration_model_name": integration_model_name,
    }

    return {
        "configurable": graph_config,
        "recursion_limit": recursion_limit,
    }
