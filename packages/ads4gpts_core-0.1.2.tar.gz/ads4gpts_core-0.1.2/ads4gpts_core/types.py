"""
Type definitions for integration agent
"""
from typing import TypedDict, Literal, Any, NotRequired


class GraphConfig(TypedDict):
    """Configuration for the graph"""
    session_id: str
    gpt_id: str
    ads4gpts_api_key: str
    ssp_id: str
    integration_system_prompt: str
    integration_user_prompt: str
    integration_model_provider: Literal['OPENAI', 'ANTHROPIC']
    integration_model_name: Literal['gpt-4o', 'gpt-4o-mini', 'claude-3-opus']


class Config(TypedDict):
    """LangGraph configuration"""
    configurable: GraphConfig
    recursion_limit: int


class InvokeIntegrationAgentArgs(TypedDict):
    """Arguments for invoking the integration agent"""
    # Runtime specific params
    user_input: str
    message_history: list[Any]
    thread_id: str
    session_id: str
    is_first_run: NotRequired[bool]
    is_interrupted: bool
    owner: str
    
    # Additional config params
    integration_model_provider: Literal['OPENAI', 'ANTHROPIC']
    integration_model_name: Literal['gpt-4o', 'gpt-4o-mini', 'claude-3-opus']
    integration_user_prompt: str
    integration_system_prompt: str


class ClientConfig(TypedDict):
    """Configuration for creating a client"""
    api_url: str
    api_key: NotRequired[str]