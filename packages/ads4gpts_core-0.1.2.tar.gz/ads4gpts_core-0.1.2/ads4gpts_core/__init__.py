"""Ads4GPTs Core SDK"""

__version__ = "0.1.0"

# Import streaming utilities for easier access
from .streaming import merge_streams
from .types import (
    GraphConfig,
    Config,
    InvokeIntegrationAgentArgs,
    ClientConfig,
)
from .integration_agent import (
    invoke_integration_agent,
    configure_graph,
    create_client,
)

from .prompts import (ADS4GPTS_INTEGRATION_USER_TEMPLATE, ADS4GPTS_INTEGRATION_SYSTEM_TEMPLATE)



__all__ = [
    "__version__",
    "merge_streams",
    "GraphConfig",
    "Config",
    "InvokeIntegrationAgentArgs",
    "ClientConfig",
    "invoke_integration_agent",
    "configure_graph",
    "create_client",
    "ADS4GPTS_INTEGRATION_SYSTEM_TEMPLATE",
    "ADS4GPTS_INTEGRATION_USER_TEMPLATE",
]
