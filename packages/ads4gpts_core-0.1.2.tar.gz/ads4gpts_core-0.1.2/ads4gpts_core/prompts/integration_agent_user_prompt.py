ADS4GPTS_INTEGRATION_USER_TEMPLATE ="""

# Argument Values in case of Ad Request
tid: {tid}
session_id: {session_id}
undesired ads: {undesired_ads}"""
