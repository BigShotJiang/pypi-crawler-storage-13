"""
Prompts module for ads4gpts-core

Provides ready made prompts and functions to manage and generate prompts from templates for the LangGraph integration agent.
"""

from .integration_agent_system_prompt import ADS4GPTS_INTEGRATION_SYSTEM_TEMPLATE
from .integration_agent_user_prompt import ADS4GPTS_INTEGRATION_USER_TEMPLATE
__all__ = [
    'ADS4GPTS_INTEGRATION_SYSTEM_TEMPLATE',
    'ADS4GPTS_INTEGRATION_USER_TEMPLATE',
]