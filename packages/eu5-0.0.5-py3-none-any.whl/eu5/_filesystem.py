# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import os
import platform
from pathlib import Path

from platformdirs import user_documents_dir

if platform.system() == "Windows":
    _BASE_GAME_PATH = Path(os.environ.get("PROGRAMFILES", r"C:\\Program Files"))
    _DOCUMENTS_PATH = Path(user_documents_dir())
else:
    _BASE_GAME_PATH = Path.home() / ".local/share"
    _DOCUMENTS_PATH = (
        Path("~").expanduser()
        / ".local/share/Steam/steamapps/compatdata/3450310/pfx/drive_c/users/steamuser/Documents"
    )

GAME_PATH = _BASE_GAME_PATH / "Steam" / "steamapps" / "common" / "Europa Universalis V"
USER_PATH = _DOCUMENTS_PATH / "Paradox Interactive" / "Europa Universalis V"
