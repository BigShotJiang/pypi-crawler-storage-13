# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import hashlib
import json
import pickle
import platform
import shutil
import subprocess
import tarfile
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

from eu5._cache import get_cache_dir

SAVE_CACHE_DIR = get_cache_dir("saves")


def _ensure_rakaly() -> str:
    if Path("./rakaly").exists():
        return "./rakaly"
    return _download_rakaly()


def _download_rakaly() -> str:
    system = platform.system().lower()

    if system == "linux":
        url = "https://github.com/rakaly/cli/releases/download/v0.8.1/rakaly-0.8.1-x86_64-unknown-linux-musl.tar.gz"
    elif system == "darwin":
        url = "https://github.com/rakaly/cli/releases/download/v0.8.1/rakaly-0.8.1-x86_64-apple-darwin.tar.gz"
    elif system == "windows":
        url = "https://github.com/rakaly/cli/releases/download/v0.8.1/rakaly-0.8.1-x86_64-pc-windows-msvc.zip"
    else:
        raise RuntimeError(f"Unsupported platform: {system}")

    print("Downloading Rakaly CLI...")
    urllib.request.urlretrieve(url, "rakaly_download")  # noqa: S310

    if url.endswith(".zip"):
        with zipfile.ZipFile("rakaly_download", "r") as f:
            f.extractall(".")  # noqa: S202
    else:
        with tarfile.open("rakaly_download", "r:gz") as f:
            f.extractall(".")  # noqa: S202

    Path("rakaly_download").unlink()

    for p in Path().glob("**/rakaly*"):
        if p.is_file() and "rakaly" in p.name and p.suffix == "":
            p.rename("rakaly")
            Path("rakaly").chmod(0o755)
            break

    for p in Path().glob("rakaly-*"):
        if p.is_dir():
            shutil.rmtree(p)

    return "./rakaly"


def _build_root_map(data: dict[str, Any]) -> dict[str, Any]:
    remainder = data["remainder"]
    iterator = iter(remainder)
    root: dict[str, Any] = {}
    for key in iterator:
        root[key] = next(iterator)
    return root


def load_save_data(save_path: str | Path) -> dict[str, Any]:
    save_path = Path(save_path)
    file_hash = hashlib.md5(save_path.read_bytes()).hexdigest()  # noqa: S324

    # Remove other pickle files for this save stem (keep only the current hash)
    for cache in SAVE_CACHE_DIR.glob(f"{save_path.stem}_*.pkl"):
        name = cache.stem
        _, cache_file_hash = name.rsplit("_", 1)
        if cache_file_hash != file_hash:
            cache.unlink()

    cache_file = SAVE_CACHE_DIR / f"{save_path.stem}_{file_hash}.pkl"
    if cache_file.exists():
        try:
            with cache_file.open("rb") as f:
                return pickle.load(f)  # noqa: S301
        except Exception:
            cache_file.unlink(missing_ok=True)

    rakaly = _ensure_rakaly()
    result = subprocess.run(  # noqa: S603
        [rakaly, "json", str(save_path)], capture_output=True, text=True, check=True
    )
    raw_data = json.loads(result.stdout.encode())
    data = _build_root_map(raw_data)

    with cache_file.open("wb") as f:
        pickle.dump(data, f)

    return data
