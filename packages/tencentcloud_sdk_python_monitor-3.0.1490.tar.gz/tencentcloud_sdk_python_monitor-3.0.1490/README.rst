============================
Tencent Cloud SDK for Python
============================

Tencent Cloud Python Monitor SDK is the official software development kit, which allows Python developers to write software that makes use of Tencent Cloud services like CVM and CBS.
The SDK works on Python versions:

   * 2.7 and greater, including 3.x

Quick Start
-----------

First, install the library:

.. code-block:: sh

    $ pip install tencentcloud-sdk-python-common
    $ pip install tencentcloud-sdk-python-monitor

or download source code from github and install:

.. code-block:: sh

    $ git clone https://github.com/tencentcloud/tencentcloud-sdk-python.git
    $ cd tencentcloud-sdk-python
    $ python package.py --components common monitor

