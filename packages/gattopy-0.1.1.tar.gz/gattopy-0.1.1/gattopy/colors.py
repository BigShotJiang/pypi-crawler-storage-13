"""
ANSI color codes for terminal output.
"""

import os
import platform
import sys


class Colors:
    """ANSI color codes for terminal output."""

    # Basic colors
    BLACK = "\033[30m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    # Bright colors
    BRIGHT_BLACK = "\033[90m"
    BRIGHT_RED = "\033[91m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_BLUE = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN = "\033[96m"
    BRIGHT_WHITE = "\033[97m"

    # Styles
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    UNDERLINE = "\033[4m"

    # Reset
    RESET = "\033[0m"

    @staticmethod
    def is_supported() -> bool:
        """
        Check if the terminal supports colors.

        Returns:
            True if colors are supported, False otherwise
        """
        # Check if NO_COLOR environment variable is set
        if os.environ.get("NO_COLOR"):
            return False

        # Check if FORCE_COLOR is set
        if os.environ.get("FORCE_COLOR"):
            return True

        # Check if stdout is a TTY
        if not hasattr(sys.stdout, "isatty"):
            return False

        if not sys.stdout.isatty():
            return False

        # Check platform
        if sys.platform == "win32":
            # Windows 10+ supports ANSI colors
            try:
                # Windows version format: "10.0.19041" or similar
                version = platform.version()
                if version:
                    major = int(version.split(".")[0])
                    return major >= 10
                # If we can't determine version, assume modern Windows
                return True
            except Exception:
                # If any error, assume colors are supported on modern Windows
                return True

        # Unix-like systems generally support colors
        return True

    @classmethod
    def disable(cls):
        """Disable all colors by setting them to empty strings."""
        cls.BLACK = ""
        cls.RED = ""
        cls.GREEN = ""
        cls.YELLOW = ""
        cls.BLUE = ""
        cls.MAGENTA = ""
        cls.CYAN = ""
        cls.WHITE = ""
        cls.BRIGHT_BLACK = ""
        cls.BRIGHT_RED = ""
        cls.BRIGHT_GREEN = ""
        cls.BRIGHT_YELLOW = ""
        cls.BRIGHT_BLUE = ""
        cls.BRIGHT_MAGENTA = ""
        cls.BRIGHT_CYAN = ""
        cls.BRIGHT_WHITE = ""
        cls.BOLD = ""
        cls.DIM = ""
        cls.ITALIC = ""
        cls.UNDERLINE = ""
        cls.RESET = ""


def colorize(text: str, color: str, bold: bool = False) -> str:
    """
    Apply color to text.

    Args:
        text: Text to colorize
        color: Color code (e.g., Colors.GREEN)
        bold: Whether to make text bold

    Returns:
        Colorized text with reset at the end
    """
    if not Colors.is_supported():
        return text

    prefix = f"{Colors.BOLD}{color}" if bold else color
    return f"{prefix}{text}{Colors.RESET}"


# Auto-disable colors if not supported
if not Colors.is_supported():
    Colors.disable()
