"""
Gattopy - A minimalist Python profiling library

Gattopy provides simple and elegant tools for measuring performance of Python functions.
Features time profiling, memory tracking, and beautiful reporting.
"""

__version__ = "0.1.0"

from .core import MemoryProfiler, Profiler, ProfileResult, TimeProfiler
from .decorators import gatto, profile, profile_memory, profile_time
from .reporting import Reporter, format_profile_report
from .utils import (
    aggregate_results,
    benchmark,
    compare_functions,
    format_bytes,
    format_time,
)

__all__ = [
    # Version
    "__version__",
    # Core classes
    "ProfileResult",
    "TimeProfiler",
    "MemoryProfiler",
    "Profiler",
    # Decorators (gatto is the main one)
    "gatto",
    "profile",
    "profile_time",
    "profile_memory",
    # Reporting
    "Reporter",
    "format_profile_report",
    # Utilities
    "format_bytes",
    "format_time",
    "benchmark",
    "compare_functions",
    "aggregate_results",
]
