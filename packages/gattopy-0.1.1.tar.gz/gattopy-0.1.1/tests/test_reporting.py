"""
Tests for reporting functionality.
"""

import json
import tempfile
from pathlib import Path

import pytest

from gattopy.core import ProfileResult
from gattopy.reporting import Reporter


class TestReporter:
    """Test cases for Reporter class."""

    def test_initialization(self):
        """Test Reporter initialization."""
        reporter = Reporter()
        assert reporter is not None
        assert reporter.results == []

    def test_add_result(self):
        """Test adding results."""
        reporter = Reporter()
        result = ProfileResult(
            function_name="test_func", execution_time=1.5, memory_peak=10.0
        )

        reporter.add_result(result)
        assert len(reporter.results) == 1
        assert reporter.results[0] == result

    def test_clear(self):
        """Test clearing results."""
        reporter = Reporter()
        result = ProfileResult(function_name="test", execution_time=1.0)

        reporter.add_result(result)
        assert len(reporter.results) == 1

        reporter.clear()
        assert len(reporter.results) == 0

    def test_generate_summary_empty(self):
        """Test summary generation with no results."""
        reporter = Reporter()
        summary = reporter.generate_summary()

        assert "No profiling results available" in summary

    def test_generate_summary_with_results(self):
        """Test summary generation with results."""
        reporter = Reporter()

        result1 = ProfileResult(
            function_name="func1", execution_time=1.0, memory_peak=5.0
        )
        result2 = ProfileResult(
            function_name="func2", execution_time=2.0, memory_peak=10.0
        )

        reporter.add_result(result1)
        reporter.add_result(result2)

        summary = reporter.generate_summary()
        assert "func1" in summary
        assert "func2" in summary
        assert "AGGREGATE STATISTICS" in summary

    def test_to_dict(self):
        """Test conversion to dictionary."""
        reporter = Reporter()
        result = ProfileResult(
            function_name="test", execution_time=1.5, memory_peak=8.0
        )

        reporter.add_result(result)
        data = reporter.to_dict()

        assert data["total_results"] == 1
        assert len(data["results"]) == 1
        assert data["results"][0]["function_name"] == "test"
        assert "summary" in data

    def test_save_json(self):
        """Test saving to JSON file."""
        reporter = Reporter()
        result = ProfileResult(
            function_name="test", execution_time=1.0, memory_peak=5.0
        )
        reporter.add_result(result)

        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = Path(tmpdir) / "test.json"
            reporter.save_json(str(filepath))

            assert filepath.exists()

            # Verify JSON content
            with open(filepath, "r") as f:
                data = json.load(f)

            assert data["total_results"] == 1
            assert data["results"][0]["function_name"] == "test"

    def test_save_csv(self):
        """Test saving to CSV file."""
        reporter = Reporter()
        result = ProfileResult(
            function_name="test",
            execution_time=1.5,
            memory_peak=10.0,
            memory_current=8.0,
        )
        reporter.add_result(result)

        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = Path(tmpdir) / "test.csv"
            reporter.save_csv(str(filepath))

            assert filepath.exists()

            # Verify CSV content
            content = filepath.read_text()
            assert "function_name,execution_time" in content
            assert "test,1.5" in content

    def test_save_markdown(self):
        """Test saving to Markdown file."""
        reporter = Reporter()
        result = ProfileResult(
            function_name="test", execution_time=1.0, memory_peak=5.0
        )
        reporter.add_result(result)

        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = Path(tmpdir) / "test.md"
            reporter.save_markdown(str(filepath))

            assert filepath.exists()

            # Verify Markdown content
            content = filepath.read_text()
            assert "# Gattopy Profiling Report" in content
            assert "test" in content
            assert "|" in content  # Table formatting

    def test_summary_statistics(self):
        """Test summary statistics calculation."""
        reporter = Reporter()

        # Add multiple results
        for i in range(5):
            result = ProfileResult(
                function_name=f"func{i}",
                execution_time=float(i + 1),
                memory_peak=float((i + 1) * 2),
            )
            reporter.add_result(result)

        summary = reporter._generate_summary_dict()

        assert "time" in summary
        assert summary["time"]["count"] == 5
        assert summary["time"]["total"] == 15.0  # 1+2+3+4+5
        assert summary["time"]["average"] == 3.0
        assert summary["time"]["min"] == 1.0
        assert summary["time"]["max"] == 5.0

        assert "memory_peak_mb" in summary
        assert summary["memory_peak_mb"]["count"] == 5
