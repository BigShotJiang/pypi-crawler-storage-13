import logging
import subprocess
import sys
import threading
import traceback
import webbrowser
from typing import Literal

import termuxgui as tg

from . import command, constants, settings, utils, utils_gui


def build_gui(
    connection: tg.Connection,
    logger: logging.Logger,
    logger_activity: logging.Logger,
    logger_init: logging.Logger,
):
    threadlock = threading.Lock()

    utils.print_msg(logger, "Loading existing settings...")
    existing_settings = settings.load_settings()

    utils.print_msg(logger, "Initializing GUI...")
    activity = tg.Activity(connection)
    activity.interceptbackbutton(True)

    utils.print_msg(logger, "Building GUI...")
    root_container = tg.LinearLayout(activity)

    utils.print_msg(logger_init, "GUI: Initializing container...")
    scroll_container = tg.NestedScrollView(activity, root_container)
    container = tg.LinearLayout(activity, scroll_container)
    container.setmargin(10, "top")
    container.setmargin(10, "right")
    container.setmargin(80, "bottom")
    container.setmargin(10, "left")

    utils.print_msg(logger_init, "GUI: Initializing title...")
    title = tg.TextView(activity, constants.WIDGET_TITLE, container)
    title.settextsize(25)

    title_desc = tg.TextView(activity, "by tochiResources", container)
    title_desc.settextsize(12)

    title_desc = tg.TextView(
        activity, f"v{constants.METADATA.get('version')}", container
    )
    title_desc.settextsize(12)
    title_desc.setmargin(20, "bottom")

    utils.print_msg(logger_init, "GUI: Initializing metadata container...")
    metadata_container_scroll = tg.NestedScrollView(activity, container)
    metadata_container = tg.LinearLayout(activity, metadata_container_scroll)
    metadata_container.setheight(200)
    metadata_container.setmargin(10, "bottom")

    paste_btn: tg.Button | None = None
    input_fields: dict[str, tg.EditText] = {}
    checkbox_fields: dict[str, tg.Checkbox] = {}
    checkbox_labels = [
        "Force Keyframes at Cuts",
        "Verbose Logging",
        "Check for Updates at Startup",
    ]

    input_field_index = 0
    textareas = ["Filename Template", "Additional Arguments"]
    utils.print_msg(logger_init, "GUI: Initializing input fields...")
    for label, placeholder in settings.defaults.items():
        input_value = existing_settings.get(label, placeholder)
        if label in checkbox_labels or label == "last_update_check_unix":
            continue

        utils.print_msg(
            logger_init,
            f'GUI: Initializing label #{input_field_index + 1} -> "{label}"...',
        )
        input_field_label = tg.TextView(activity, label, container)
        input_field_label.settextsize(18)
        input_field_label.setmargin(6, "top")

        utils.print_msg(logger_init, "GUI: Initializing field...")
        height = None
        if label in textareas:
            height = tg.View.WRAP_CONTENT
            input_value = " ".join(input_value)
        input_fields[label] = tg.EditText(activity, input_value, container, True)
        input_fields[label].settextsize(16)
        input_fields[label].setmargin(2, "top")
        if height:
            input_fields[label].setheight(height)

        if label == "Media URL":
            utils.print_msg(logger_init, "GUI: Initializing clipboard button...")
            paste_btn = tg.Button(activity, "📋 Paste URL from clipboard", container)
            paste_btn.setmargin(6, "bottom")
            input_field_index += 1
            continue

        input_fields[label].setmargin(6, "bottom")
        input_field_index += 1

    checkbox_fields_index = 0
    for label in checkbox_labels:
        utils.print_msg(
            logger_init,
            f'GUI: Initializing checkbox #{checkbox_fields_index + 1} -> "{label}"...',
        )
        checkbox_fields[label] = tg.Checkbox(activity, label, container)
        checkbox_fields[label].setmargin(6, "bottom")
        checkbox_fields[label].settextsize(16)
        checkbox_fields[label].setchecked(existing_settings.get(label, True))
        checkbox_fields_index += 1

    utils.print_msg(logger_init, "GUI: Initializing button #1...")
    reset_settings_btn = tg.Button(activity, "Reset Settings", container)

    utils.print_msg(logger_init, "GUI: Initializing button #2...")
    check_update_btn = tg.Button(activity, "Check for Updates", container)

    utils.print_msg(logger_init, "GUI: Initializing button row...")
    run_row = tg.LinearLayout(activity, container, False)

    utils.print_msg(logger_init, "GUI: Initializing button #3...")
    exit_btn = tg.Button(activity, "Exit", run_row)

    utils.print_msg(logger_init, "GUI: Initializing button #4...")
    run_btn = tg.Button(activity, "Run", run_row)

    utils.print_msg(logger_init, "GUI: Initializing status container...")
    status_text_container = tg.LinearLayout(activity, container)
    status_text_title = tg.TextView(activity, "Status", status_text_container)
    status_text_title.settextsize(18)
    status_text_title.setmargin(10, "top")
    status_text_title.setmargin(5, "bottom")

    latest_version = utils.check_for_updates(existing_settings)
    if latest_version:
        utils_gui.display_toast(connection, "New update available!")
        utils.print_msg(logger, f"New update available (v{latest_version})")
        check_update_btn.settext(f"New update available (v{latest_version})")

    def get_configs(
        input_fields: dict[str, tg.EditText], checkbox_fields: dict[str, tg.Checkbox]
    ) -> dict[Literal["inputs", "checkboxes", "all_parsed"], dict]:
        config_inputs = {
            label: value.gettext().strip() for label, value in input_fields.items()
        }
        config_checkboxes = {
            label: value.checked for label, value in checkbox_fields.items()
        }
        config_all_parsed = {
            **config_inputs,
            **config_checkboxes,
        }
        for label in [
            "Filename Template",
            "Additional Arguments",
        ]:
            config_all_parsed[label] = config_inputs[label].split(" ")
        return {
            "inputs": config_inputs,
            "checkboxes": config_checkboxes,
            "all_parsed": config_all_parsed,
        }

    def handle_ui_events(event: tg.Event):
        if event.type == tg.Event.text:
            input_id = event.value["id"]

            if input_id == input_fields["Media URL"]:
                try:
                    media_url = input_fields["Media URL"].gettext().strip()
                    if checkbox_fields["Verbose Logging"].checked:
                        utils_gui.append_text(
                            logger,
                            activity,
                            status_text_container,
                            f"GUI: Media url upated -> {media_url}",
                        )
                    if utils.is_valid_url(media_url):

                        def update_metadata():
                            with threadlock:
                                utils.print_msg(logger, "GUI: Fetching metadata...")
                                metadata = command.get_metadata(media_url)
                                media_thumbnail_url = metadata.get("thumbnail")
                                media_uploader = metadata.get("uploader")
                                media_title = metadata.get("title")
                                media_duration = metadata.get("duration")

                                metadata_container.clearchildren()

                                if media_thumbnail_url:
                                    thumbnail_view = utils_gui.get_thumbnail_view(
                                        activity,
                                        metadata_container,
                                        media_thumbnail_url,
                                    )
                                    thumbnail_view.setmargin(6, "bottom")

                                if media_uploader:
                                    media_uploader_view = tg.TextView(
                                        activity,
                                        f"Uploader: {media_uploader}",
                                        metadata_container,
                                    )
                                    media_uploader_view.settextsize(14)
                                    media_uploader_view.setmargin(2, "bottom")

                                if media_title:
                                    media_title_view = tg.TextView(
                                        activity,
                                        f"Title: {media_title}",
                                        metadata_container,
                                    )
                                    media_title_view.settextsize(14)
                                    media_title_view.setmargin(2, "bottom")

                                if media_duration:
                                    media_duration_view = tg.TextView(
                                        activity,
                                        f"Duration: {media_duration}",
                                        metadata_container,
                                    )
                                    media_duration_view.settextsize(14)

                        threading.Thread(target=update_metadata, daemon=True).start()
                except Exception as e:
                    utils_gui.print_event_error(e, logger, connection, "text")

        if event.type == tg.Event.click:
            click_id = event.value["id"]

            if (
                click_id == checkbox_fields["Force Keyframes at Cuts"]
                or click_id == checkbox_fields["Verbose Logging"]
                or click_id == checkbox_fields["Check for Updates at Startup"]
            ):
                try:

                    def update_settings(
                        input_fields: dict[str, tg.EditText],
                        checkbox_fields: dict[str, tg.Checkbox],
                    ):
                        with threadlock:
                            configs = get_configs(input_fields, checkbox_fields)
                            settings.save_settings(configs.get("all_parsed"))

                    threading.Thread(
                        target=update_settings,
                        args=(input_fields, checkbox_fields),
                        daemon=True,
                    ).start()
                except Exception as e:
                    utils_gui.print_event_error(e, logger, connection, "click")

            if click_id == paste_btn:
                try:

                    def paste_clipboard():
                        with threadlock:
                            try:
                                clip = subprocess.check_output(
                                    ["termux-clipboard-get"], text=True
                                ).strip()
                                if clip and "\n" not in clip:
                                    input_fields["Media URL"].settext(clip)
                                else:
                                    utils_gui.append_text(
                                        logger,
                                        activity,
                                        status_text_container,
                                        "Clipboard is empty or multi-line",
                                    )
                            except Exception as _e:
                                utils_gui.print_event_error(
                                    _e,
                                    logger,
                                    connection,
                                    "click",
                                    f"Clipboard unavailable: {str(_e)}",
                                )

                    threading.Thread(target=paste_clipboard, daemon=True).start()
                except Exception as e:
                    utils_gui.print_event_error(e, logger, connection, "click")

            if click_id == check_update_btn:
                try:

                    def check_update():
                        with threadlock:
                            latest_version = utils.check_for_updates(
                                existing_settings, update_settings=True, force=True
                            )
                            if latest_version:
                                check_update_btn.settext(
                                    f"New update available (v{latest_version})"
                                )
                                webbrowser.open(constants.GITHUB_REPO_URL)
                            else:
                                utils_gui.display_toast(
                                    connection, "No updates available"
                                )
                                check_update_btn.settext("Check for Updates")

                    threading.Thread(target=check_update, daemon=True).start()
                except Exception as e:
                    utils_gui.print_event_error(e, logger, connection, "click")

            if click_id == reset_settings_btn:
                try:

                    def reset_settings():
                        with threadlock:
                            utils_gui.append_text(
                                logger,
                                activity,
                                status_text_container,
                                "Resetting settings...",
                            )
                            settings.reset_settings()
                            inputs_defaults = settings.defaults
                            for item in input_fields.items():
                                label = item[0]
                                if label == "Media URL":
                                    continue
                                input_fields[label].settext(inputs_defaults[label])
                            utils_gui.append_text(
                                logger,
                                activity,
                                status_text_container,
                                "Settings has been reset!",
                            )

                    threading.Thread(target=reset_settings, daemon=True).start()
                except Exception as e:
                    utils_gui.print_event_error(e, logger, connection, "click")

            if click_id == run_btn:
                try:

                    def download_media(
                        input_fields: dict[str, tg.EditText],
                        checkbox_fields: dict[str, tg.Checkbox],
                    ):
                        with threadlock:
                            try:
                                status_text_container.clearchildren()
                                configs = get_configs(input_fields, checkbox_fields)
                                settings.save_settings(configs.get("all_parsed"))
                                command.run_yt_dlp(
                                    configs.get("inputs"),
                                    configs.get("checkboxes"),
                                    activity,
                                    status_text_container,
                                    logger,
                                )
                            except Exception as e:
                                utils_gui.append_text(
                                    logger,
                                    activity,
                                    status_text_container,
                                    f"GUI error: {str(e)}",
                                )

                    threading.Thread(
                        target=download_media,
                        args=(input_fields, checkbox_fields),
                        daemon=True,
                    ).start()
                except Exception as e:
                    utils_gui.print_event_error(e, logger, connection, "click")

            if click_id == exit_btn:
                try:
                    utils_gui.append_text(
                        logger, activity, status_text_container, "Exiting..."
                    )
                    logging.shutdown()
                    sys.exit(0)
                except Exception as e:
                    utils_gui.print_event_error(e, logger, connection, "click")

    utils.print_msg(logger_init, "GUI: Initializing event listeners...")

    for event in connection.events():
        utils_gui.handle_lifecycle_events(logger_activity, connection, event)
        handle_ui_events(event)


def launch_gui(
    logger: logging.Logger, activity_logs: bool = True, init_logs: bool = False
):
    try:
        utils.print_msg(
            logger,
            f"GUI logs in Termux is {'enabled' if not logger.disabled else 'disabled'}",
        )
        utils.print_msg(
            logger,
            f"GUI activity logging is {'enabled' if activity_logs else 'disabled'}",
        )
        utils.print_msg(
            logger,
            f"GUI initialization logging is {'enabled' if init_logs else 'disabled'}",
        )

        if not utils.detect_termux():
            utils.print_msg(
                logger,
                f"{constants.WIDGET_TITLE} must run inside Termux. Make sure '$HOME' and '$PREFIX' environment variables are set.",
                "error",
            )
            logging.shutdown()
            sys.exit(1)

        logger.debug("Initializing Activity logger...")
        logger_activity = utils_gui.get_logger(not activity_logs)

        logger.debug("Initializing Initialization logger...")
        logger_init = utils_gui.get_logger(not init_logs)

        logger.debug("Creating connection...")

        with tg.Connection() as connection:
            build_gui(connection, logger, logger_activity, logger_init)

        logging.debug("Exiting GUI...")
        logging.shutdown()
        sys.exit(0)

    except Exception:
        e = traceback.format_exc()
        utils.print_msg(logger, f"GUI critical error: {e}", "critical")
        logging.shutdown()
        sys.exit(1)
