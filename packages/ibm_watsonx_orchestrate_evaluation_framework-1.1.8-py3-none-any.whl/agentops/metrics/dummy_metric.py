from langfuse.api.resources.commons.types.score_data_type import ScoreDataType

from agentops.metrics import Evaluation
from agentops.metrics.metrics import LangfuseMetric


class DummyMetric(Evaluation):
    def __init__(self, llm_client=None, config=None):
        super().__init__(llm_client, config)

    def evaluate(
        self,
        messages,
        ground_truth,
        extracted_context,
        metadata=None,
    ):
        extracted_context["metric"].update(
            {
                self.__class__.__name__: {
                    "dummy_metric": LangfuseMetric(
                        eval_name="dummy_metric",
                        value=True,
                        metadata=metadata,
                        data_type="BOOLEAN",
                    )
                }
            }
        )

        return extracted_context
