import json
from typing import List, Union

from agentops.extractors import ExpectedToolExtractor, ExtractLabeledMessages
from agentops.metrics.evaluations import Evaluation
from agentops.metrics.metrics import LangfuseMetric, ToolCallAndRoutingMetrics
from agentops.type import ContentType
from agentops.utils.gold_label import get_gold_tool_calls


class ToolCalling(Evaluation):
    def __init__(self, llm_client=None, config=None):
        super().__init__(llm_client, config)
        self.dependencies = [ExtractLabeledMessages(), ExpectedToolExtractor()]

    def evaluate(
        self, messages, ground_truth, extracted_context, metadata, **kwargs
    ) -> Union[LangfuseMetric, List[LangfuseMetric]]:

        labeled_messages = (
            extracted_context.get("extractor")
            .get(ExtractLabeledMessages.__name__)
            .get("labeled_messages")
        )
        expected_tools = extracted_context.get("extractor").get(
            ExpectedToolExtractor.__name__
        )

        dataset_name = kwargs.get("dataset", "")

        tool_dictionary = get_gold_tool_calls(ground_truth=ground_truth)
        total_tool_calls = len(
            [
                message
                for message in messages
                if message.type == ContentType.tool_call
            ]
        )
        relevant_tool_calls = len(labeled_messages)
        tool_calls_with_incorrect_parameter = len(
            expected_tools.get("incorrect_param_tool_idx")
        )
        correct_tool_calls = expected_tools.get("correct_tool_calls")

        # TODO: think about the dataset name
        # TODO: total_steps
        tool_call_metrics = ToolCallAndRoutingMetrics(
            dataset_name=dataset_name,
            total_tool_calls=total_tool_calls,
            expected_tool_calls=len(tool_dictionary),
            correct_tool_calls=len(correct_tool_calls),
            relevant_tool_calls=relevant_tool_calls,
            tool_calls_with_incorrect_parameter=tool_calls_with_incorrect_parameter,
        )

        tool_call_metrics = tool_call_metrics.model_dump()

        metrics = []
        tools = [
            "total_tool_calls",
            "correct_tool_calls",
            "expected_tool_calls",
            "tool_calls_with_incorrect_parameter",
            "tool_call_recall",
            "tool_call_precision",
        ]
        for tool in tools:
            metric = LangfuseMetric(
                eval_name=tool,
                value=tool_call_metrics.get(tool),
                metadata=metadata,
                data_type="NUMERIC",
            )
            metrics.append(metric)

        extracted_context["metric"].update(
            {
                self.__class__.__name__: {
                    name: metric for name, metric in zip(tools, metrics)
                }
            }
        )

        return extracted_context
