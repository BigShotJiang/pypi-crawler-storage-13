from abc import ABC, abstractmethod
from typing import Any, Dict, List, Mapping, Optional

from agentops.type import Message, OrchestrateDataset


class Extractor(ABC):
    def __init__(self, config: Optional[Dict] = None):
        self.config = config
        self._dependencies = []

    @property
    def dependencies(self):
        if not self._dependencies:
            return []

        return self._dependencies

    @dependencies.setter
    def dependencies(self, d):
        self._dependencies = d

    @abstractmethod
    def extract(
        self,
        messages: List[Message],
        ground_truth: Optional[OrchestrateDataset] = None,
        extracted_context: Mapping[str, Any] = {},
        **kwargs,
    ) -> Any:
        """Extract data from messages."""
        raise NotImplementedError
