from agentops.extractors.extractor_base import Extractor


class DummyExtractor(Extractor):
    """Example purpose only"""

    def __init__(self, config=None):
        super().__init__(config)

    def extract(
        self,
        messages,
        ground_truth,
        extracted_context={},
        **kwargs,
    ):

        extracted_context["extractor"].update(
            {self.__class__.__name__: {"dummy_metric": 1234}}
        )

        return extracted_context
