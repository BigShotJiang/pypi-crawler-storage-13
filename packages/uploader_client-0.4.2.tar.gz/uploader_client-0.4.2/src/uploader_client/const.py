DEFAULT_REQUEST_TIMEOUT = 300  # Таймаут запроса, секунд
DEFAULT_REQUEST_RETRIES = 5  # Количество повторных попыток
DEFAULT_RETRY_FACTOR = 1  # Шаг увеличения задержки м.д. запросами
DEFAULT_DATAMART_URL = 'http://localhost:8090'
DEFAULT_DATAMART_NAME = 'test'

# Дефолтные значения из httpx для пула соединений
DEFAULT_MAX_CONNECTIONS = 15  # Максимальное количество одновременных соединений
DEFAULT_MAX_KEEPALIVE_CONNECTIONS = 5  # Максимальное количество keep-alive соединений
DEFAULT_POOL_TIMEOUT = 5.0  # Таймаут ожидания свободного соединения из пула, сек

FILE_STATUS_SUCCESS = 'success'
