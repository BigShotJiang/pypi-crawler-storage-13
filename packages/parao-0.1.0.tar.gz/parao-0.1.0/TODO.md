
# Union or tuple[type] for
- Coder.typ 
- Arg key element
- Shorthand key element

# multi values
- for multi triggered actions
- via merge method on Param, used in Arguments._solve_values

# less aggressive expansion for CLI strings
- ignore: str



# extension suffix for File i.e. File.md, File.txt -> Annotated[File, "md"]

# fancy composite coders?
list[Figure]
dict[str, Figure | Dir | ROOT]