import numpy as np
import krippendorff
from collections import Counter
from statsmodels.stats.inter_rater import fleiss_kappa
from sklearn.metrics import accuracy_score, f1_score, recall_score, precision_score, roc_auc_score
from balinese_nlp.textpreprocessor import TextPreprocessor

preprocessor = TextPreprocessor()


def _calculate_accuracy_score(y_true, y_predicted_labels):
    score = accuracy_score(y_true, y_predicted_labels)
    return score


def _calculate_f1_score_macro(y_true, y_predicted_labels):
    score = f1_score(y_true, y_predicted_labels, average='macro')
    return score


def _calculate_f1_score_weighted(y_true, y_predicted_labels):
    score = f1_score(y_true, y_predicted_labels, average='weighted')
    return score


def _calculate_recall_score_macro(y_true, y_predicted_labels):
    score = recall_score(y_true, y_predicted_labels, average='macro')
    return score


def _calculate_recall_score_weighted(y_true, y_predicted_labels):
    score = recall_score(
        y_true, y_predicted_labels, average='weighted')
    return score


def _calculate_precision_score_macro(y_true, y_predicted_labels):
    score = precision_score(
        y_true, y_predicted_labels, average='macro')
    return score


def _calculate_precision_score_weighted(y_true, y_predicted_labels):
    score = precision_score(
        y_true, y_predicted_labels, average='weighted')
    return score


def _calculate_roc_auc_score_macro(y_true, y_predicted_labels):
    score = roc_auc_score(
        y_true, y_predicted_labels, average='macro')
    return score


def _calculate_roc_auc_score_weighted(y_true, y_predicted_labels):
    score = roc_auc_score(
        y_true, y_predicted_labels, average='weighted')
    return score


def _calculate_fleiss_kappa_score(y_true, y_predicted_labels):
    y_true = y_true.astype(int)
    y_predicted_labels = y_predicted_labels.astype(int)
    annotation_data = np.array([
        y_true,
        y_predicted_labels
    ]).T
    # ada berapa banyak anotator
    num_items = len(annotation_data[:, 0])
    num_categories = 2  # label 0 atau 1
    # transforming data into correct format
    transformed_data = np.zeros((num_items, num_categories))
    for i, item_annotation in enumerate(annotation_data):
        for ann in item_annotation:
            transformed_data[i, ann] += 1

    # calculate fleiss kappa
    score = fleiss_kappa(transformed_data)
    return score


def _calculate_krippendorff(y_true, y_predicted_labels):
    y_true = y_true.astype(int)
    y_predicted_labels = y_predicted_labels.astype(int)
    annotation_data = np.array([
        y_true,
        y_predicted_labels
    ])
    score = krippendorff.alpha(reliability_data=annotation_data,
                               level_of_measurement='nominal')
    return score


def _calculate_rouge_L(system_summary, ground_truth_summary):
    def _longest_common_subsequence(X, Y):
        """Membantu menghitung Longest Common Subsequence."""
        m = len(X)
        n = len(Y)
        L = [[0 for _ in range(n + 1)] for _ in range(m + 1)]

        for i in range(m + 1):
            for j in range(n + 1):
                if i == 0 or j == 0:
                    L[i][j] = 0
                elif X[i-1] == Y[j-1]:
                    L[i][j] = L[i-1][j-1] + 1
                else:
                    L[i][j] = max(L[i-1][j], L[i][j-1])
        return L[m][n]

    def _get_n_grams(tokens, n_gram):
        """Membantu mendapatkan n-gram dari list token."""
        return [tuple(tokens[i:i+n_gram]) for i in range(len(tokens) - n_gram + 1)]
    scores = dict()
    # tokenize system and ground truth summary
    tokens_A = preprocessor.balinese_word_tokenize(
        system_summary)
    tokens_B = preprocessor.balinese_word_tokenize(
        ground_truth_summary)

    len_A = len(tokens_A)
    len_B = len(tokens_B)

    # --- ROUGE-L (Longest Common Subsequence) ---
    lcs_count = _longest_common_subsequence(tokens_A, tokens_B)

    precision_l = lcs_count / len_A if len_A > 0 else 0
    recall_l = lcs_count / len_B if len_B > 0 else 0
    f1_l = (2 * precision_l * recall_l) / (precision_l +
                                           recall_l) if (precision_l + recall_l) > 0 else 0

    scores['rouge_L_precision'] = precision_l
    scores['rouge_L_recall'] = recall_l
    scores['rouge_L_f1_score'] = f1_l
    return scores


def _calculate_rouge(system_summary, ground_truth_summary, n_rouge=1):
    def _get_n_grams(tokens, n_gram):
        """Membantu mendapatkan n-gram dari list token."""
        return [tuple(tokens[i:i+n_gram]) for i in range(len(tokens) - n_gram + 1)]
    scores = dict()

    # tokenize system and ground truth summary
    tokens_A = preprocessor.balinese_word_tokenize(
        system_summary)
    tokens_B = preprocessor.balinese_word_tokenize(
        ground_truth_summary)

    # get n-gram
    ngrams_A = _get_n_grams(tokens_A, n_rouge)
    ngrams_B = _get_n_grams(tokens_B, n_rouge)

    # Use Counter to count occurrences for clipping
    count_A = Counter(ngrams_A)
    count_B = Counter(ngrams_B)

    # Calculate intersection_count (clipped count)
    intersection_count = 0
    for ngram, count in count_A.items():
        intersection_count += min(count, count_B[ngram])

    # total_ngrams for denominator must be the actual number of n-grams, including duplicates
    total_ngrams_A = sum(count_A.values())
    total_ngrams_B = sum(count_B.values())

    precision = intersection_count / total_ngrams_A if total_ngrams_A > 0 else 0
    recall = intersection_count / total_ngrams_B if total_ngrams_B > 0 else 0
    f1 = (2 * precision * recall) / (precision +
                                     recall) if (precision + recall) > 0 else 0

    scores[f'rouge_{n_rouge}_precision'] = precision
    scores[f'rouge_{n_rouge}_recall'] = recall
    scores[f'rouge_{n_rouge}_f1_score'] = f1

    return scores
