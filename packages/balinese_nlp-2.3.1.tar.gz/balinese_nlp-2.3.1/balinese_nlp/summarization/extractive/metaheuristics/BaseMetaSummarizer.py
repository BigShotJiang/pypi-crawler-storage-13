import numpy as np
import pandas as pd
import math
from balinese_nlp.textpreprocessor import TextPreprocessor
from balinese_nlp.summarization.extractive.utils import (
    _calculate_accuracy_score,
    _calculate_f1_score_macro,
    _calculate_f1_score_weighted,
    _calculate_fleiss_kappa_score,
    _calculate_krippendorff,
    _calculate_precision_score_macro,
    _calculate_precision_score_weighted,
    _calculate_recall_score_macro,
    _calculate_recall_score_weighted,
    _calculate_roc_auc_score_macro,
    _calculate_roc_auc_score_weighted,
    _calculate_rouge,
    _calculate_rouge_L,
)


class BaseMetaSummarizer:
    optimizer = None
    IS_FIT = False
    _IS_SOLVE = False
    BREAK_IF_CONVERGENCE = None
    LIST_BEST_FITNESS = list()
    FITNESS_FUNCTION = None
    TEXTPREPOCESSOR = None

    def __init__(self,
                 N_AGENTS,
                 MAX_ITERATIONS,
                 MAX_KONVERGEN,
                 BREAK_IF_CONVERGENCE,
                 FUNCTIONS,
                 ):
        self.optimizer = {
            "name": None,
            "params": {
                'N_AGENTS': N_AGENTS,
                'MAX_ITERATIONS': MAX_ITERATIONS,
                "MAX_KONVERGEN": MAX_KONVERGEN,
                "FUNCTIONS": {
                    **FUNCTIONS,
                    'lowerbound': 0,
                    'upperbound': 1
                },
            }
        }
        self.EVALUATION_FUNCTION = {
            'accuracy': _calculate_accuracy_score,
            'f1_macro': _calculate_f1_score_macro,
            'f1_weighted': _calculate_f1_score_weighted,
            'recall_macro': _calculate_recall_score_macro,
            'recall_weighted': _calculate_recall_score_weighted,
            'precision_macro': _calculate_precision_score_macro,
            'precision_weighted': _calculate_precision_score_weighted,
            'fleiss': _calculate_fleiss_kappa_score,
            'krippendorff': _calculate_krippendorff,
            'roc_auc_macro': _calculate_roc_auc_score_macro,
            'roc_auc_weighted': _calculate_roc_auc_score_weighted,
            'rouge_1_f1_score': _calculate_rouge,
            'rouge_1_recall': _calculate_rouge,
            'rouge_1_precision': _calculate_rouge,
            'rouge_2_f1_score': _calculate_rouge,
            'rouge_2_recall': _calculate_rouge,
            'rouge_2_precision': _calculate_rouge,
            'rouge_L_f1_score': _calculate_rouge_L,
            'rouge_L_recall': _calculate_rouge_L,
            'rouge_L_precision': _calculate_rouge_L,
        }
        self.TEXTPREPOCESSOR = TextPreprocessor()
        self._IS_SOLVE = False
        self.IS_FIT = False
        self.BREAK_IF_CONVERGENCE = BREAK_IF_CONVERGENCE
        self.LIST_BEST_FITNESS = list()  # record best fitness each iterations
        self.FITNESS_FUNCTION = self.__fitness_function_score
        # check apakah masing-masing parameter yang dimasukan sudah sesuai ketentuan
        if self.optimizer['params']['FUNCTIONS']['compression_rate'] < 0.5 or self.optimizer['params']['FUNCTIONS']['compression_rate'] > 1:
            raise ValueError(
                'Compression rate must be in this interval: 0.5 <= comp_rate <= 1')

    def fit(self, dfs_train):
        """Fit the input data

        Args:
            dfs_train (dict): dictionary of dataframe from each title. The dictionary key contains title and the value contain the df of extracted features from each title. Provide the same shape(dimension) of df in each title. In the last of title you must provide the 'extractive_summary' label which contains 1/0 label, where 1 is important summary sentence and 0 is not important summary sentence
        """
        if not isinstance(dfs_train, dict):
            raise TypeError(
                'Provide dfs_train as dictionary, where key is title text and value is extracted features from each title')

        if len(dfs_train) <= 0:
            raise ValueError('Please insert your dfs_train!')

        # check apakah dimensi yang diberikan user sudah sesuai dengan dimensi dfs_train
        N_FEATURES = self.optimizer['params']['FUNCTIONS']['n_features']
        for title, df in dfs_train.items():
            X = df.drop(['preprocessed_sentences', 'labels'], axis=1)
            if N_FEATURES != X.shape[1]:
                raise ValueError(
                    f'Please format your df {title} in dfs_train in the same N_FEATURES ({N_FEATURES}) size!')

        self.dfs_train = dfs_train
        self.IS_FIT = True

        return self

    def _initialize_agents(self):
        """
        Function for agents initialization based on size of features
        """
        pass

    def __fitness_function_score(self, df_sentences_score_with_label):
        """Menghitung skor kualitas hasil ringkasan dengan metriks tertentu. Metriks yang bisa digunakan:
        - accuracy: Accuracy Score from scikit-learn metrics
        - fleiss: Fleiss Kappa from package statsmodels.stats.inter_rate
        - krippendorff: Kripendorff Alpha from krippendorff package

        Args:
            df_sentences_score_with_label (_type_): dataframe yang berisi susunan indeks kalimat, total skor per kalimat dari fitur-fitur yang digunakan, label ground truth
        """

        metrics = self.optimizer['params']['FUNCTIONS']['metrics']
        for metric in metrics:
            if metric not in [
                'accuracy', 'fleiss', 'krippendorff', 'f1_macro', 'f1_weighted', 'recall_macro', 'recall_weighted', 'precision_macro', 'precision_weighted', 'roc_auc_macro', 'roc_auc_weighted', 'rouge_1_f1_score', 'rouge_1_recall', 'rouge_1_precision', 'rouge_2_f1_score', 'rouge_2_recall', 'rouge_2_precision', 'rouge_L_f1_score', 'rouge_L_recall', 'rouge_L_precision'
            ]:
                raise ValueError(
                    'Please provide metric within these values:\naccuracy, fleiss, krippendorff, f1_macro, f1_weighted, recall_macro, recall_weighted, precision_macro, precision_weighted, roc_auc_macro, roc_auc_weighted, rouge_1_f1_score, rouge_1_recall, rouge_1_precision, rouge_2_f1_score, rouge_2_recall, rouge_2_precision, rouge_L_f1_score, rouge_L_recall, rouge_L_precision')

        compression_rate = self.optimizer['params']['FUNCTIONS']['compression_rate']
        n_sentences = df_sentences_score_with_label.shape[0]

        # sorting sentences berdasarkan total sentence score dikalikan weights dari agent
        df_sentences_score_with_label.sort_values(
            by='total_sentence_score', ascending=False, inplace=True)

        # extract Top-N sentences as system summary
        number_of_compressed_sentences = (compression_rate*n_sentences)
        top_n_extracted_sentences = int(np.ceil(n_sentences -
                                                number_of_compressed_sentences))
        sentence_indexes_summary = df_sentences_score_with_label.head(
            top_n_extracted_sentences)['sentence_idx'].values

        # extract label 1/0 dari top-N sentences
        y_predicted_labels = []
        for idx in range(n_sentences):
            if idx < top_n_extracted_sentences:
                y_predicted_labels.append(1)
            else:
                y_predicted_labels.append(0)
        y_predicted_labels = np.array(y_predicted_labels).astype(int)

        # extract system and ground truth summary untuk perhitungan metriks berbasis ROUGE
        ground_truth_summary = ' '.join(
            df_sentences_score_with_label[
                df_sentences_score_with_label['labels'] == 1
            ].sort_values(by='sentence_idx', ascending=True)['preprocessed_sentences'].values
        )
        system_summary = ' '.join(
            df_sentences_score_with_label[
                df_sentences_score_with_label.index.isin(
                    sentence_indexes_summary)
            ].sort_values(by='sentence_idx', ascending=True)['preprocessed_sentences'].values
        )

        # hitung multi fitness scores based on metrics
        y_true = df_sentences_score_with_label['labels'].values.astype(int)
        mean_multi_fitness_score = 0
        for metric in metrics:
            # hitung metric
            if 'rouge_' in metric:
                n_rouge = 1
                if 'rouge_2' in metric:
                    n_rouge = 2
                fitness_score = self.EVALUATION_FUNCTION[metric](
                    system_summary,
                    ground_truth_summary,
                    n_rouge
                )[metric]
            else:
                fitness_score = self.EVALUATION_FUNCTION[metric](
                    y_true, y_predicted_labels)
            mean_multi_fitness_score += fitness_score
        mean_multi_fitness_score = mean_multi_fitness_score/len(metrics)

        return mean_multi_fitness_score

    def _evaluate_fitness(self, agents):
        """For each agent in agents we calculate the average accuracy/fleiss/krippendorff using all dfs_train

        Args:
            agents (list): list of agents
        """
        pass

    def _adjust_boundaries(self, agents):
        BATAS_BAWAH = self.optimizer['params']['FUNCTIONS']['lowerbound']
        BATAS_ATAS = self.optimizer['params']['FUNCTIONS']['upperbound']
        for idx_agent, agent in enumerate(agents):
            agents[idx_agent]['position'] = np.clip(
                agents[idx_agent]['position'], BATAS_BAWAH, BATAS_ATAS)
        return agents

    def _retrieve_best_agent(self, agents):
        """
        Function untuk retrieve best agent pada iterasi terakhir setelah di solve
        """
        OBJECTIVE = self.optimizer['params']['FUNCTIONS']['objective']

        fitness = np.array([
            agent_data['fitness'] for agent_data in agents
        ])
        best_indices_agents = np.argmin(fitness)
        if OBJECTIVE == 'max':
            best_indices_agents = np.argmax(fitness)

        return agents[best_indices_agents]

    def _retrieve_worst_agent(self, agents):
        """
        Function untuk retrieve worst agent pada iterasi terakhir setelah di solve
        """
        OBJECTIVE = self.optimizer['params']['FUNCTIONS']['objective']

        fitness = np.array([
            agent_data['fitness'] for agent_data in agents
        ])
        worst_indices_agents = np.argmax(fitness)
        if OBJECTIVE == 'max':
            worst_indices_agents = np.argmin(fitness)

        return agents[worst_indices_agents]

    def _check_convergence(self, gbest_fitness, best_fitness_previous, convergence, idx_iteration):
        MAX_KONVERGEN = self.optimizer['params']['MAX_KONVERGEN']
        is_break = False
        if math.isclose(best_fitness_previous, gbest_fitness, rel_tol=1e-9, abs_tol=1e-9):
            convergence += 1
        else:
            convergence = 0
        print(
            f'Generation {idx_iteration + 1}, Best Fitness: {gbest_fitness}, Konvergen: {convergence}')

        if convergence == MAX_KONVERGEN:
            print(f'Convergence is reached = {MAX_KONVERGEN}')
            is_break = True

        best_fitness_previous = gbest_fitness
        return is_break, best_fitness_previous, convergence
