from .BaseMetaSummarizerWeights import BaseMetaSummarizerWeights
import random as rd
import numpy as np


class GeneticAlgorithm(BaseMetaSummarizerWeights):
    """
    Genetic Algorithm (GA) untuk optimasi bobot k-fitur dalam peringkasan teks ekstraktif.
    """

    def __init__(self,
                 N_CHROMOSOMES=50,
                 MAX_ITERATIONS=100,
                 MUTATION_RATE=0.3,
                 IS_APPLY_ELITISM_STRATEGY=True,
                 ELITE_SIZE=4,
                 MAX_KONVERGEN=10,
                 N_TIMES_CROSSOVER=1,
                 OPTIMIZER_NAME='Genetic Algorithm',
                 PARENT_SELECTION='roulette',  # {tournament, roulette}
                 TOURNAMENT_SIZE=10,
                 FUNCTIONS={
                     'n_features': 2,
                     'compression_rate': 0.67,
                     'objective': 'max',
                     # Default metric to optimize
                     'metrics': ['f1_macro', 'rouge_1_f1_score', 'roc_auc_macro']
                 },
                 BREAK_IF_CONVERGENCE=True
                 ):

        super().__init__(
            N_AGENTS=N_CHROMOSOMES,
            MAX_ITERATIONS=MAX_ITERATIONS,
            MAX_KONVERGEN=MAX_KONVERGEN,
            FUNCTIONS=FUNCTIONS,
            BREAK_IF_CONVERGENCE=BREAK_IF_CONVERGENCE,
        )

        self.optimizer['name'] = OPTIMIZER_NAME
        self.optimizer['params'].update({
            'MUTATION_RATE': MUTATION_RATE,
            'IS_APPLY_ELITISM_STRATEGY': IS_APPLY_ELITISM_STRATEGY,
            'ELITE_SIZE': ELITE_SIZE,
            'N_TIMES_CROSSOVER': N_TIMES_CROSSOVER,
            'PARENT_SELECTION': PARENT_SELECTION,
            'TOURNAMENT_SIZE': TOURNAMENT_SIZE,
        })

        # Hitung jumlah populasi baru yang perlu diisi
        N_POPULATION = N_CHROMOSOMES
        if IS_APPLY_ELITISM_STRATEGY:
            N_POPULATION = N_CHROMOSOMES - ELITE_SIZE

        if N_POPULATION % 2 != 0:
            raise ValueError(
                f"Jumlah populasi untuk crossover harus genap (N_AGENTS - ELITE_SIZE = {N_POPULATION}).")

    def solve(self):
        if not self.IS_FIT:
            raise ValueError(
                'Please fit your data first through fit() method!')

        MAX_ITERATIONS = self.optimizer['params']['MAX_ITERATIONS']
        N_AGENTS = self.optimizer['params']['N_AGENTS']

        # 1. Inisialisasi Agents dan Fitness Awal
        agents = self._initialize_agents()
        agents = self._evaluate_fitness(agents)
        best_agent = self._retrieve_best_agent(agents)
        best_fitness_previous = best_agent['fitness']
        self.LIST_BEST_FITNESS.append(best_agent['fitness'])

        # 2. Proses Optimasi
        convergence = 0
        for idx_iteration in range(MAX_ITERATIONS):

            # 3. Elitism Strategy
            elite_agents = self.__apply_elitism_strategy(agents)

            # 4. Generate New Population (Selection, Crossover, Mutation)
            new_population = self.__generate_new_population(agents)

            # 5. Gabungkan Elitism dan Populasi Baru
            agents = elite_agents + new_population

            # 6. Evaluate fitness agents
            agents = self._evaluate_fitness(agents)

            # 7. Update GBest (Best Agent in Swarm)
            current_best_in_gen = self._retrieve_best_agent(agents)
            best_agent = self.__update_gBest(best_agent, current_best_in_gen)

            # 8. Check konvergensi
            self.LIST_BEST_FITNESS.append(best_agent['fitness'])
            is_break, best_fitness_previous, convergence = self._check_convergence(
                best_agent['fitness'], best_fitness_previous, convergence, idx_iteration)
            if is_break and self.BREAK_IF_CONVERGENCE:
                break

        self._IS_SOLVE = True
        return best_agent

    def __update_gBest(self, current_gbest, new_candidate_best):
        """Helper function untuk update GBest (Best Agent)"""
        OBJECTIVE = self.optimizer['params']['FUNCTIONS']['objective']

        if OBJECTIVE == 'max':
            if new_candidate_best['fitness'] > current_gbest['fitness']:
                return new_candidate_best.copy()
        elif OBJECTIVE == 'min':
            if new_candidate_best['fitness'] < current_gbest['fitness']:
                return new_candidate_best.copy()

        return current_gbest

    def __apply_elitism_strategy(self, agents):
        """Mempertahankan sejumlah agen terbaik (Elite) untuk generasi berikutnya."""
        IS_APPLY_ELITISM_STRATEGY = self.optimizer['params']['IS_APPLY_ELITISM_STRATEGY']
        ELITE_SIZE = self.optimizer['params']['ELITE_SIZE']
        OBJECTIVE = self.optimizer['params']['FUNCTIONS']['objective']

        if not IS_APPLY_ELITISM_STRATEGY:
            return []

        # Urutkan agents berdasarkan fitness
        if OBJECTIVE == 'max':
            sorted_agents = sorted(
                agents, key=lambda x: x['fitness'], reverse=True)
        else:
            sorted_agents = sorted(
                agents, key=lambda x: x['fitness'], reverse=False)

        # Ambil elite agents
        elite_agents = [agent.copy() for agent in sorted_agents[:ELITE_SIZE]]
        return elite_agents

    def __selection(self, agents):
        """
        Melakukan seleksi agen untuk crossover.
        Selection options: tournament, roulette
        """
        PARENT_SELECTION = self.optimizer['params']['PARENT_SELECTION']
        OBJECTIVE = self.optimizer['params']['FUNCTIONS']['objective']
        N_AGENTS = self.optimizer['params']['N_AGENTS']

        if PARENT_SELECTION == 'tournament':
            TOURNAMENT_SIZE = self.optimizer['params']['TOURNAMENT_SIZE']
            parent_1 = self.__tournament_selection(
                agents, TOURNAMENT_SIZE, OBJECTIVE)
            parent_2 = self.__tournament_selection(
                agents, TOURNAMENT_SIZE, OBJECTIVE)
        elif PARENT_SELECTION == 'roulette':
            parent_1 = self.__roulette_selection(agents, OBJECTIVE)
            parent_2 = self.__roulette_selection(agents, OBJECTIVE)
        else:
            parent_1 = agents[rd.randint(0, N_AGENTS-1)]
            parent_2 = agents[rd.randint(0, N_AGENTS-1)]

        return parent_1, parent_2

    def __tournament_selection(self, agents, tournament_size, objective):
        """Tournament selection."""
        # Pilih agen secara acak untuk turnamen
        tournament_agents = rd.sample(agents, tournament_size)

        # Tentukan pemenang (agen dengan fitness terbaik)
        best_agent = tournament_agents[0]
        for agent in tournament_agents[1:]:
            if (objective == 'max' and agent['fitness'] > best_agent['fitness']) or \
               (objective == 'min' and agent['fitness'] < best_agent['fitness']):
                best_agent = agent
        return best_agent

    def __roulette_selection(self, agents, objective):
        """Roulette wheel selection."""
        fitnesses = np.array([agent['fitness'] for agent in agents])

        if objective == 'min':
            # Untuk minimasi, ubah menjadi maksimasi (misal: dengan 1 / fitness)
            # Hindari pembagian dengan nol atau nilai yang sangat kecil
            # Menggunakan max(fitness) - fitness + epsilon untuk maksimasi
            max_f = np.max(fitnesses)
            epsilon = 1e-6  # Konstanta kecil untuk menghindari pembagian nol
            selection_values = max_f - fitnesses + epsilon
        else:
            # Untuk maksimasi, gunakan fitness langsung
            selection_values = fitnesses

        # Normalisasi untuk mendapatkan probabilitas
        total_selection_value = np.sum(selection_values)
        probabilities = selection_values / total_selection_value

        # Pilih agen berdasarkan probabilitas
        selected_index = np.random.choice(
            len(agents), size=1, p=probabilities)[0]
        return agents[selected_index]

    def __crossover(self, agent_1, agent_2):
        """
        One-Point Crossover.
        """
        N_TIMES_CROSSOVER = self.optimizer['params']['N_TIMES_CROSSOVER']
        N_DIMENSION = self.optimizer['params']['FUNCTIONS']['n_features']

        child_1 = agent_1.copy()
        child_2 = agent_2.copy()

        for _ in range(N_TIMES_CROSSOVER):

            # Memastikan titik potong ada di antara 1 dan N_DIMENSION-1
            if N_DIMENSION <= 1:
                # Jika dimensi 1, tidak ada crossover yang berarti
                point_crossover = 0
            elif N_DIMENSION == 2:
                # Untuk dimensi 2, hanya ada 1 titik potong yang mungkin (indeks 1)
                point_crossover = 1
            else:
                # Pilih titik potong secara acak dari [1, N_DIMENSION-1]
                point_crossover = np.random.randint(
                    1, N_DIMENSION)

            # Operasi One-Point Crossover
            child_1_pos = child_1['position']
            child_2_pos = child_2['position']

            new_child_1_pos = np.concatenate([
                child_1_pos[:point_crossover], child_2_pos[point_crossover:]
            ])
            new_child_2_pos = np.concatenate([
                child_2_pos[:point_crossover], child_1_pos[point_crossover:]
            ])

            child_1['position'] = new_child_1_pos
            child_2['position'] = new_child_2_pos

        return child_1, child_2

    def __mutation(self, agent):
        """
        Random Replacement Mutation.
        """
        MUTATION_RATE = self.optimizer['params']['MUTATION_RATE']
        N_DIMENSION = self.optimizer['params']['FUNCTIONS']['n_features']
        LOWER_BOUND = self.optimizer['params']['FUNCTIONS']['lowerbound']
        UPPER_BOUND = self.optimizer['params']['FUNCTIONS']['upperbound']

        # Tentukan jumlah gen yang akan dimutasi
        n_mutation = int(np.ceil(MUTATION_RATE * N_DIMENSION))

        # Pilih indeks dimensi yang akan dimutasi
        indices_to_mutate = rd.sample(
            range(N_DIMENSION), min(n_mutation, N_DIMENSION))

        # Lakukan mutasi (ganti dengan nilai acak baru dalam batas)
        for index in indices_to_mutate:
            agent['position'][index] = np.random.uniform(
                LOWER_BOUND, UPPER_BOUND)

        return agent

    def __generate_new_population(self, agents):
        """Melakukan Selection, Crossover, dan Mutation untuk menghasilkan populasi baru."""
        N_AGENTS = self.optimizer['params']['N_AGENTS']
        IS_APPLY_ELITISM_STRATEGY = self.optimizer['params']['IS_APPLY_ELITISM_STRATEGY']
        ELITE_SIZE = self.optimizer['params']['ELITE_SIZE']

        # Hitung ukuran populasi baru yang perlu diisi
        N_POPULATION_TO_GENERATE = N_AGENTS
        if IS_APPLY_ELITISM_STRATEGY:
            N_POPULATION_TO_GENERATE = N_AGENTS - ELITE_SIZE

        new_population = []
        # Generate N_POPULATION_TO_GENERATE/2 pasang anak
        for _ in range(N_POPULATION_TO_GENERATE // 2):

            # 1. Selection
            parent_1, parent_2 = self.__selection(agents)

            # 2. Crossover
            child_1, child_2 = self.__crossover(parent_1, parent_2)

            # 3. Mutation
            child_1 = self.__mutation(child_1)
            child_2 = self.__mutation(child_2)

            # 4. Add to new population
            new_population.append(child_1)
            new_population.append(child_2)

        return new_population
