from balinese_nlp.textpreprocessor.stemming.Context.RemovalInterface import RemovalInterface


class Removal(object):
    """description of class"""

    def __init__(self, visitor, subject, result, removedPart, affixType):
        self.visitor = visitor
        self.subject = subject
        self.result = result
        self.removedPart = removedPart
        self.affixType = affixType
        # print(self.subject)

    def get_visitor(self):
        return self.visitor

    def get_subject(self):
        return self.subject

    def get_result(self):
        return self.result

    def get_removed_part(self):
        return self.removedPart

    def get_affix_type(self):
        return self.affixType
