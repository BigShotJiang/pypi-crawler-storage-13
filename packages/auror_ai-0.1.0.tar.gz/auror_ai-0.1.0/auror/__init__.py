"""
Auror: A distributed task processing framework for AI inference.

This package provides a robust messaging infrastructure for distributed AI inference tasks,
with built-in support for MQTT messaging, OAuth2 authentication, and extensible worker patterns.
"""

__version__ = "0.1.0"
__author__ = "Auror AI Team"

from auror.core.messaging import MessagingCore
from auror.core.worker import Worker

__all__ = ["MessagingCore", "Worker", "__version__"]
