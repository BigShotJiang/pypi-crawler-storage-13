"""
Main entry point for running Auror as a module.

This allows the package to be run as:
    python -m auror
"""

from auror.cli import main

if __name__ == "__main__":
    main()
