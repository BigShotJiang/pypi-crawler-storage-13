"""
Setup configuration for Auror package.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="auror-ai",
    version="0.1.0",
    author="Jordan Roimarmier",
    author_email="contact@roimarmier.xyz",
    description="A distributed task processing framework for AI inference",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/auror-ai/auror",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "paho-mqtt>=1.6.1",
        "requests>=2.31.0",
        "python-dotenv>=1.0.0",
        "transformers>=4.30.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
        ],
        "ltxv": [
            "ltx-video>=0.1.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "auror=auror.cli:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
