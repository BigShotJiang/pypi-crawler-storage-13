"""Tests for Auror package."""
