"""Tests for configuration module."""

import os
import pytest
from auror.config import AurorConfig


class TestAurorConfig:
    """Test suite for AurorConfig class."""

    def test_config_creation(self):
        """Test creating a config with all parameters."""
        config = AurorConfig(
            mqtt_host="broker.example.com",
            mqtt_port=1883,
            mqtt_topic="test/topic",
            client_id="test-client",
            client_secret="test-secret",
            audience="https://api.example.com",
        )

        assert config.mqtt_host == "broker.example.com"
        assert config.mqtt_port == 1883
        assert config.mqtt_topic == "test/topic"
        assert config.client_id == "test-client"
        assert config.client_secret == "test-secret"
        assert config.audience == "https://api.example.com"

    def test_config_from_dict(self):
        """Test creating config from dictionary."""
        config_dict = {
            "mqtt_host": "broker.example.com",
            "mqtt_port": 1883,
            "mqtt_topic": "test/topic",
            "client_id": "test-client",
            "client_secret": "test-secret",
            "audience": "https://api.example.com",
        }

        config = AurorConfig.from_dict(config_dict)

        assert config.mqtt_host == "broker.example.com"
        assert config.mqtt_port == 1883

    def test_config_to_dict(self):
        """Test converting config to dictionary."""
        config = AurorConfig(
            mqtt_host="broker.example.com",
            mqtt_port=1883,
            mqtt_topic="test/topic",
            client_id="test-client",
            client_secret="test-secret",
            audience="https://api.example.com",
        )

        config_dict = config.to_dict()

        assert config_dict["mqtt_host"] == "broker.example.com"
        assert config_dict["mqtt_port"] == 1883
        assert isinstance(config_dict, dict)

    def test_config_from_env_missing_vars(self):
        """Test that from_env raises error when required vars are missing."""
        # Clear any existing env vars
        env_vars = [
            "AUROR_MQTT_HOST",
            "AUROR_CLIENT_ID",
            "AUROR_CLIENT_SECRET",
            "AUROR_AUDIENCE",
        ]

        old_values = {}
        for var in env_vars:
            old_values[var] = os.environ.get(var)
            if var in os.environ:
                del os.environ[var]

        try:
            with pytest.raises(ValueError, match="Missing required environment variables"):
                AurorConfig.from_env()
        finally:
            # Restore env vars
            for var, value in old_values.items():
                if value is not None:
                    os.environ[var] = value

    def test_config_from_env_with_vars(self):
        """Test creating config from environment variables."""
        # Set environment variables
        os.environ["AUROR_MQTT_HOST"] = "broker.example.com"
        os.environ["AUROR_MQTT_PORT"] = "8883"
        os.environ["AUROR_MQTT_TOPIC"] = "custom/topic"
        os.environ["AUROR_CLIENT_ID"] = "env-client"
        os.environ["AUROR_CLIENT_SECRET"] = "env-secret"
        os.environ["AUROR_AUDIENCE"] = "https://env-api.example.com"

        try:
            config = AurorConfig.from_env()

            assert config.mqtt_host == "broker.example.com"
            assert config.mqtt_port == 8883
            assert config.mqtt_topic == "custom/topic"
            assert config.client_id == "env-client"
            assert config.client_secret == "env-secret"
            assert config.audience == "https://env-api.example.com"
        finally:
            # Clean up
            for var in [
                "AUROR_MQTT_HOST",
                "AUROR_MQTT_PORT",
                "AUROR_MQTT_TOPIC",
                "AUROR_CLIENT_ID",
                "AUROR_CLIENT_SECRET",
                "AUROR_AUDIENCE",
            ]:
                if var in os.environ:
                    del os.environ[var]
