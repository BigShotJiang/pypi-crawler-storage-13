# c:\Users\fmc_c\CascadeProjects\windsurf-project\setup.py
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pdfmerger-fernandomc",
    version="1.0.0",
    author="Fernando Martinez Castillo",
    author_email="fmccas@email.com",  # Reemplaza con tu correo
    description="Aplicación GUI para fusionar archivos PDF",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/tuusuario/pdfmerger",
    packages=find_packages(),
    install_requires=["PyPDF2>=3.0.0"],
    python_requires=">=3.6",
    entry_points={
        'gui_scripts': [
            'pdfmerger=pdfmerger:main',
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)