# PDF Merger GUI

Una aplicación simple para fusionar archivos PDF con interfaz gráfica.

## Características
- Interfaz gráfica intuitiva
- Arrastra y suelta archivos PDF
- Reordena páginas fácilmente
- Guarda el archivo fusionado donde prefieras

## Instalación

```bash
pip install pdfmerger-fernandomc

Uso
Ejecuta desde la línea de comandos:
pdfmerger   

Autor
Fernando Martinez Castillo

Licencia
Este proyecto está bajo la licencia MIT. Ver LICENSE para más detalles.


### 5. Crear `LICENSE.txt`

```text
MIT License

Copyright (c) 2025 Fernando Martinez Castillo

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.