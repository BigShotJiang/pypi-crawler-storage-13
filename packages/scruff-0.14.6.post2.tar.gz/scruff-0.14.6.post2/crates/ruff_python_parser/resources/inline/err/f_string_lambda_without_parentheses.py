f"{lambda x: x}"
