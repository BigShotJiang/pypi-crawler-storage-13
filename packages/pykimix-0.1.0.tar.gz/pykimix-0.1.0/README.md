# PyKiMix
A library that mixes Pygame rendering inside a Kivy widget.
