from dataclasses import dataclass

import pybag.ros2.humble.builtin_interfaces as builtin_interfaces
import pybag.ros2.humble.geometry_msgs as geometry_msgs
import pybag.ros2.humble.std_msgs as std_msgs
import pybag.types as t


@dataclass(kw_only=True)
class Goals:
    __msg_name__ = 'nav_msgs/msg/Goals'

    header: std_msgs.Header
    goals: t.Array[geometry_msgs.PoseStamped]


@dataclass(kw_only=True)
class GridCells:
    __msg_name__ = 'nav_msgs/msg/GridCells'

    header: std_msgs.Header
    cell_width: t.float32
    cell_height: t.float32
    cells: t.Array[geometry_msgs.Point]


@dataclass(kw_only=True)
class MapMetaData:
    __msg_name__ = 'nav_msgs/msg/MapMetaData'

    map_load_time: builtin_interfaces.Time
    resolution: t.float32
    width: t.uint32
    height: t.uint32
    origin: geometry_msgs.Pose


@dataclass(kw_only=True)
class OccupancyGrid:
    __msg_name__ = 'nav_msgs/msg/OccupancyGrid'

    header: std_msgs.Header
    info: MapMetaData
    data: t.Array[t.int8]


@dataclass(kw_only=True)
class Odometry:
    __msg_name__ = 'nav_msgs/msg/Odometry'

    header: std_msgs.Header
    child_frame_id: t.string
    pose: geometry_msgs.PoseWithCovariance
    twist: geometry_msgs.TwistWithCovariance


@dataclass(kw_only=True)
class Path:
    __msg_name__ = 'nav_msgs/msg/Path'

    header: std_msgs.Header
    poses: t.Array[geometry_msgs.PoseStamped]
