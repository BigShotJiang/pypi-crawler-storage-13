"""MCP Server for Meteostat"""
