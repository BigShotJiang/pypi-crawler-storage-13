"""Functions for calculating the kinetic energy suppression factor"""

from .suppression import *
