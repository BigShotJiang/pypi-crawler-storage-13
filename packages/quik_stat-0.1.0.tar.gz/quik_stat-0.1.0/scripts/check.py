import pathlib
import sys

import PIL.Image

from extat import webp_dims

status = []


for i, line in enumerate(sys.stdin):
    path = pathlib.Path(line.strip())
    im = PIL.Image.open(path)
    pil_w, pil_h = pil_size = im.size
    imstat_w, imstat_h = imstat_size = webp_dims(path)
    same = pil_size == imstat_size
    status.append(same)
    path = str(path)
    print(f"{i:4} {path:100} {pil_w:4} {pil_h:4} {imstat_w:4} {imstat_h:4} {same}")

n_true = sum(status)
n_total = len(status)
print(f"{n_true} / {n_total} True")
