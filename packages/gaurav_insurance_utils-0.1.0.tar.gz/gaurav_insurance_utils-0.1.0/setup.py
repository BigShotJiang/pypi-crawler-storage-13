# gaurav_insurance_utils/setup.py
from setuptools import setup, find_packages
from pathlib import Path

here = Path(__file__).resolve().parent
readme = ""
readme_file = here / "README.md"
if readme_file.exists():
    readme = readme_file.read_text(encoding="utf8")

setup(
    name="gaurav-insurance-utils",
    version="0.1.0",
    author="Gaurav Sharma",
    description="Small helper utilities for insurance projects (policy validation, claim risk scoring, customer normalization).",
    long_description=readme,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    include_package_data=True,
)
