# gaurav_insurance_utils/tests/test_risk.py
import pytest

from gaurav_insurance_utils.policy_validator import PolicyValidator
from gaurav_insurance_utils.claim_risk import ClaimRiskScorer
from gaurav_insurance_utils.customer_utils import CustomerUtils


def test_policy_validator_valid():
    assert PolicyValidator.is_valid("INS-2024-000001")
    assert PolicyValidator.is_valid("INS-1999-123456")


def test_policy_validator_invalid():
    assert not PolicyValidator.is_valid("INS-24-0001")
    assert not PolicyValidator.is_valid("INVALID-2024-000001")
    assert not PolicyValidator.is_valid("")
    assert not PolicyValidator.is_valid(None)


def test_claim_risk_scoring_simple():
    # low amount, young customer, no previous claims -> low risk
    s = ClaimRiskScorer.score(500, 22, 0)
    assert isinstance(s, int)
    assert s >= 0 and s <= 100
    assert s >= 10  # base score

    # mid amount
    s2 = ClaimRiskScorer.score(8000, 35, 1)
    assert s2 > s

    # high amount & multiple previous claims -> high score
    s3 = ClaimRiskScorer.score(25000, 50, 3)
    assert s3 >= 80


def test_customer_utils_normalize():
    assert CustomerUtils.normalize_email("  Alice@Example.COM ") == "alice@example.com"
    assert CustomerUtils.normalize_phone("(555) 123-4567") == "5551234567"
    assert CustomerUtils.normalize_phone("+1 (555) 123-4567", keep_country_plus=True) == "+15551234567"
    assert CustomerUtils.normalize_phone(None) is None
