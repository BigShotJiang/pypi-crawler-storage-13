# gaurav_insurance_utils/__init__.py
"""
gaurav_insurance_utils
----------------------
Small collection of utilities for the PolicyCare insurance project.

Provided:
 - PolicyValidator: simple insurance policy ID validator
 - ClaimRiskScorer: lightweight rule-based risk scorer
 - CustomerUtils: normalization helpers for customer contact fields
"""

from .policy_validator import PolicyValidator
from .claim_risk import ClaimRiskScorer
from .customer_utils import CustomerUtils

__all__ = ["PolicyValidator", "ClaimRiskScorer", "CustomerUtils"]
__version__ = "0.1.0"
