# gaurav_insurance_utils/customer_utils.py
import re
from typing import Optional


class CustomerUtils:
    """
    Utility helpers to normalize customer contact information.
    """

    @staticmethod
    def normalize_email(email: Optional[str]) -> Optional[str]:
        """
        Strip and lowercase email. Returns None for falsy inputs.
        """
        if not email:
            return None
        return email.strip().lower()

    @staticmethod
    def normalize_phone(phone: Optional[str], keep_country_plus: bool = False) -> Optional[str]:
        """
        Normalize phone number by stripping non-digits. Optionally keep leading '+' if
        a leading '+' and country code present and keep_country_plus=True.

        Returns digits-only string (or '+<digits>' when keep_country_plus=True).
        Returns None for falsy inputs.

        Examples:
            '+1 (555) 123-4567' -> '15551234567' or '+15551234567'
            ' (020) 1234-5678' -> '02012345678'
        """
        if not phone:
            return None
        s = str(phone).strip()
        # Preserve leading plus for optional E.164-like format
        if keep_country_plus and s.startswith("+"):
            digits = re.sub(r"[^\d]", "", s)
            return f"+{digits}"
        # otherwise return only digits
        return re.sub(r"[^\d]", "", s)
