# gaurav_insurance_utils/policy_validator.py
import re
from typing import Pattern


class PolicyValidator:
    """
    Simple policy number validator.

    Expected default format:
        INS-<YEAR>-<6 DIGIT ID>
    Example:
        INS-2024-000123

    Methods:
        is_valid(policy_number: str) -> bool
    """

    # default pattern
    _PATTERN: Pattern = re.compile(r"^INS-\d{4}-\d{6}$")

    @classmethod
    def is_valid(cls, policy_number: str) -> bool:
        """
        Validate a policy number string against the expected pattern.

        Args:
            policy_number: policy id string to validate.

        Returns:
            True if matches pattern, False otherwise.
        """
        if not policy_number:
            return False
        try:
            return bool(cls._PATTERN.match(policy_number.strip()))
        except Exception:
            return False
