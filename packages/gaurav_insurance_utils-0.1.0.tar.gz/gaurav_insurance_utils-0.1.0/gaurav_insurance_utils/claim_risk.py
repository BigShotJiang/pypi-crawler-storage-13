# gaurav_insurance_utils/claim_risk.py
from typing import Union


class ClaimRiskScorer:
    """
    Lightweight risk scoring for claims.

    The scorer uses simple heuristics for demonstration:
      - base score: 10
      - claim_amount > 20000 -> +40
      - claim_amount > 10000 -> +20
      - previous_claims > 2 -> +30
      - customer_age < 25 -> +10

    Final score is clamped to 0..100.

    Usage:
        score = ClaimRiskScorer.score(15000, 30, 1)
    """

    @staticmethod
    def _to_number(value: Union[None, int, float, str], fallback: float = 0.0) -> float:
        if value is None:
            return fallback
        if isinstance(value, (int, float)):
            return float(value)
        try:
            return float(str(value))
        except Exception:
            return fallback

    @classmethod
    def score(cls, claim_amount: Union[int, float, str], customer_age: Union[int, str], previous_claims: Union[int, str]) -> int:
        """
        Compute a risk score in range 0..100.

        Args:
            claim_amount: numeric or numeric-like (string) amount
            customer_age: numeric or numeric-like (string)
            previous_claims: integer-like number of past claims

        Returns:
            int score 0..100
        """
        amt = cls._to_number(claim_amount, 0.0)
        age = int(cls._to_number(customer_age, 35))
        prev = int(cls._to_number(previous_claims, 0))

        score = 10

        if amt > 20000:
            score += 40
        elif amt > 10000:
            score += 20
        elif amt > 5000:
            score += 10

        if prev > 2:
            score += 30
        elif prev == 2:
            score += 15

        if age < 25:
            score += 10
        elif age > 70:
            score += 10  # slightly higher risk for very old customers

        if score < 0:
            score = 0
        if score > 100:
            score = 100

        return int(score)
