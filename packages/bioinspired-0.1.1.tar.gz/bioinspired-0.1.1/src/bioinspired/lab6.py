CONTENT = """
import numpy as np

def sphere_function(x):
    return np.sum(x**2)

def differential_evolution_variant(objective_func, bounds, pop_size, num_gens, F, CR):
    num_params = len(bounds)
    bounds = np.array(bounds)

    # Initialization
    population = np.random.rand(pop_size, num_params)
    min_b, max_b = bounds.T
    diff = np.fabs(min_b - max_b)
    population = min_b + population * diff

    for gen in range(num_gens):
        for i in range(pop_size):
            candidates = list(range(pop_size))
            candidates.remove(i)
            # Select three random vectors
            a, b, c = population[np.random.choice(candidates, 3, replace=False)]

            # **Mutation strategy: Standard DE/rand/1 (using difference)**
            mutant_vector = a + F * (b - c)

            # Enforce bounds
            mutant_vector = np.clip(mutant_vector, min_b, max_b)

            # Crossover and Selection (as in the original code)
            trial_vector = np.copy(population[i])
            crossover_mask = np.random.rand(num_params) < CR
            if not np.any(crossover_mask):
                crossover_mask[np.random.randint(0, num_params)] = True
            trial_vector[crossover_mask] = mutant_vector[crossover_mask]

            if objective_func(trial_vector) < objective_func(population[i]):
                population[i] = trial_vector

        # Print progress
        best_idx = np.argmin([objective_func(p) for p in population])
        best_fitness = objective_func(population[best_idx])
        if (gen + 1) % 100 == 0 or gen == 0:
            print(f"Generation {gen+1:04d}: Best fitness = {best_fitness:.4f}")

    best_idx = np.argmin([objective_func(p) for p in population])
    return population[best_idx], objective_func(population[best_idx])

best_solution, best_fitness = differential_evolution_variant(
        objective_func=sphere_function,
        bounds=[(-5.0, 5.0)] * 2,
        pop_size=10,
        num_gens=1000,
        F=0.8,
        CR=0.9
    )
print("\n--- Optimization finished with DE/rand/1 ---")
print(f"Best found solution: {best_solution}")
print(f"Best fitness value: {best_fitness}")
"""

class Lab:
    def __repr__(self):
        return CONTENT

lab6 = Lab()
