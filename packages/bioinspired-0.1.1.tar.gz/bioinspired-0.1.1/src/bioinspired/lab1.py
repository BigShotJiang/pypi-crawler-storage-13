CONTENT = """
import random
import math

# --- Genetic Algorithm Implementation --- #

# Function to optimize (you can change this)
def objective_function(x):
    # Example: maximize f(x) = x * sin(10 * pi * x) + 2.0
    return x * math.sin(10 * math.pi * x) + 2.0

# Create initial population
def initialize_population(pop_size, bounds):
    return [random.uniform(bounds[0], bounds[1]) for _ in range(pop_size)]

# Fitness function (maximize or minimize)
def fitness(x, maximize=True):
    val = objective_function(x)
    return val if maximize else -val

# Selection (tournament)
def selection(pop, maximize=True):
    i, j = random.sample(range(len(pop)), 2)
    if fitness(pop[i], maximize) > fitness(pop[j], maximize):
        return pop[i]
    else:
        return pop[j]

# Crossover (single-point)
def crossover(parent1, parent2, crossover_rate=0.9):
    if random.random() < crossover_rate:
        alpha = random.random()
        child = alpha * parent1 + (1 - alpha) * parent2
        return child
    else:
        return parent1

# Mutation
def mutate(x, mutation_rate=0.1, bounds=(-1, 2)):
    if random.random() < mutation_rate:
        x = x + random.uniform(-0.1, 0.1)
        x = max(bounds[0], min(bounds[1], x))
    return x

# Main GA function
def genetic_algorithm(pop_size=50, generations=100, bounds=(-1, 2), maximize=True):
    # Initialize population
    population = initialize_population(pop_size, bounds)

    best = population[0]
    for gen in range(generations):
        new_population = []
        for _ in range(pop_size):
            parent1 = selection(population, maximize)
            parent2 = selection(population, maximize)
            child = crossover(parent1, parent2)
            child = mutate(child, bounds=bounds)
            new_population.append(child)
        population = new_population

        # Track best solution
        for ind in population:
            if fitness(ind, maximize) > fitness(best, maximize):
                best = ind

        if gen % 10 == 0:
            print(f"Generation {gen}, Best: x={best:.5f}, f(x)={objective_function(best):.5f}")

    return best


# Run the GA
best_solution = genetic_algorithm()
print("\nOptimal Solution Found:")
print(f"x = {best_solution:.5f}, f(x) = {objective_function(best_solution):.5f}")
"""

class Lab:
    def __repr__(self):
        return CONTENT

lab1 = Lab()
