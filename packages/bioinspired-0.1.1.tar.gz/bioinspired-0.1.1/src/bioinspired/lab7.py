CONTENT = """
import random

# Function to calculate total completion time
def total_completion_time(schedule):
    time = 0
    total = 0
    for job in schedule:
        time += job  # job represents its processing time
        total += time
    return total

# Function to generate neighbors by swapping two jobs
def generate_neighbors(schedule):
    neighbors = []
    for i in range(len(schedule)):
        for j in range(i + 1, len(schedule)):
            new_schedule = schedule[:]
            new_schedule[i], new_schedule[j] = new_schedule[j], new_schedule[i]
            neighbors.append((new_schedule, (i, j)))  # include move
    return neighbors

# Tabu Search Algorithm
def tabu_search(jobs, max_iterations=50, tabu_tenure=5):
    current = jobs[:]
    random.shuffle(current)
    best = current[:]
    tabu_list = []
    best_cost = total_completion_time(best)

    print("Initial schedule:", current, "Cost:", best_cost)

    for _ in range(max_iterations):
        neighbors = generate_neighbors(current)
        best_neighbor = None
        best_neighbor_cost = float('inf')
        best_move = None

        for neighbor, move in neighbors:
            cost = total_completion_time(neighbor)
            # Check tabu or aspiration condition
            if move not in tabu_list or cost < best_cost:
                if cost < best_neighbor_cost:
                    best_neighbor = neighbor
                    best_neighbor_cost = cost
                    best_move = move

        if best_neighbor is None:
            break  # no move possible

        current = best_neighbor
        tabu_list.append(best_move)
        if len(tabu_list) > tabu_tenure:
            tabu_list.pop(0)

        if best_neighbor_cost < best_cost:
            best = best_neighbor
            best_cost = best_neighbor_cost

        print("Iteration cost:", best_cost)

    return best, best_cost

# Example usage
jobs = [5, 3, 8, 6, 4]  # processing times of jobs
best_schedule, best_cost = tabu_search(jobs, max_iterations=20, tabu_tenure=5)

print("\nBest schedule found:", best_schedule)
print("Minimum total completion time:", best_cost)

"""

class Lab:
    def __repr__(self):
        return CONTENT

lab7 = Lab()
