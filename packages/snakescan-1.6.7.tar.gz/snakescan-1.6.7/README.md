# SnakeScan
![PyPI version](https://badge.fury.io/py/SnakeScan.svg)
![License](https://img.shields.io/badge/License-MIT-blue.svg)
![Requires-python](https://img.shields.io/badge/requires--python-3.7+-red)
![Status](https://img.shields.io/badge/State-In%20development-yellow)
![Platforms](https://img.shields.io/badge/Platforms-macOS%20%7C%20Linux%20%7C%20Windows-lightgrey)
#Description
Use to scan Ports and use carefully.Use the library in the terminal, because that's what it's focused on. If you don't want to use the terminal, run it in code, but then some new functions won't be present there.You will need to use it differently.
# Help with using the library 
## If you use the library directly in your code:
 ```
import SnakeScan
SnakeScan.run()
```
- -l  need internet to view public ip you device
- -t threading port search
- -s single search ports
- -i information about host
- -help in host /-help port in host
- -check [host] scan subnet in ip
- exit in host or port off script

## Watcher commands
 ```
 Watcher.start() - Starts checking ports
 Watcher.stop() - Stops port checking
 ```
 ## Help with attributes
```
-P:
snake -p 80,443 #Scanning specific ports
snake -p 80,3437,8080,20-30,79-443 #Scanning individual ports and ranges. If you use ranges, then one port from the beginning is not be taken into account. For example:80-443 then it will start with 81-443, so you need to enter it from 79-443, then it will be taken into account 
snake -p 80,3437,10-0,20-10,443-79 #You can enter ranges the other way around: 80-443,443-80 but the first value will start one port higher
-H:
#Displays a list of attribute usages
snake -h
snake -help
-SP:
-sp:snake -sp #Uses selected pre-selected range and uses for scanning ProcessPoolExecutor
-V:
snake -v #Shows the library version
-GS:
snake www.google.com -gs #Get a certificate from the official website. If you don't enter the hostname, you'll get this error [Errno 111] Connection refused
-T:
snake -t #Uses streams for port scanning
-CH:
snake -ch #Scans the subnet for others IP
-L:
snake -l #Shows your public internet IP address. Internet connection required for use
-I:
snake www.google.com -i #Shows information about the IP address.Can receive information from IPV4 and IPV6
#You can also use all attributes in place:
```
snake -p 100,200,79-443 www.google.com -i -l -t -ch -sp
```
# Library changes

## Added class Watcher:
 ```
 from SnakeScan import Watcher
 Watcher = Watcher(host="localhost",port="80",timeout=1)
 Watcher.start()
 ```
 ## Added multiple use Watcher:
 ```
 from SnakeScan import Watcher
 ports=[53,80,100,160]
 Watchers=[]
 for i in range(len(ports)):
 Watchers.append(Watcher("127.0.0.1",ports[i]))
 Watchers[i].start()
 ```
## Library added for use in terminal to use enter snake or Snake    
```
usage: snake [-h] [-sp] [-v] [-i] [-p PORTS] [-t] [-ch]
             [-l]
             [host]

Snake - It's a command line module SnakeScan. Use him for
more fast starting

positional arguments:
  host

options:
  -h, --help         show this help message and exit
  -sp, --speed       speed scan
  -v, --version      version
  -i, --info         ip info
  -p, --ports PORTS  range ports to scan host
  -t, --thread       fast scan
  -ch, --check       scan subnet
  -l, --local        view you public ip - need internet
```
## Added Info about ipv6
```
snake 2001:db8:: -i or snake [2001:4860:4860::8888] -i
```