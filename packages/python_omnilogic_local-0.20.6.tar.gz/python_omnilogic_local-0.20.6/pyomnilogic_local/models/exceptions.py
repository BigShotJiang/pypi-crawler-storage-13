class OmniParsingError(Exception):
    pass
