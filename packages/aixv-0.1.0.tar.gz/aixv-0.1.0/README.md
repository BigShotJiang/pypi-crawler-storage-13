# AIXV: AI Integrity eXchange & Verification

**The Standard for AI Supply Chain Provenance.**

AIXV is an open protocol for cryptographically verifying the lineage, training data, and safety alignment of Artificial Intelligence models.

## Installation

```bash
pip install aixv
```

## Usage

```bash
aixv verify ./model.pt
```

## Status

This reference implementation is currently in **Pre-Alpha**.
The AIXV Ledger is currently accessible only to member organizations.

For documentation and protocol specifications, visit [aixv.org](https://aixv.org).
