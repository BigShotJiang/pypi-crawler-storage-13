from setuptools import setup, find_packages
from pathlib import Path

# 讀取 README.md 作為 PyPI 長敘述
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="cat_handwriting_recognizer",
    version="1.2.2",
    author="littlecommandcat",
    author_email="cyingda742@gmail.com",
    description="A lightweight handwritten character recognition module using template-based KNN.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/littlecommandcat/cat_handwriting_recognizer",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "numpy",
        "pillow",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Multimedia :: Graphics",
    ],
    python_requires=">=3.10",
)
