from dataclasses import dataclass
from ctypes import cdll, c_int

libc = cdll.msvcrt
libc.tolower.argtypes = [c_int]
libc.tolower.restype = c_int


@dataclass(slots=True)
class Name16:
	name: list[int] = None

	def set(self, string: memoryview):
		self.name = [0] * 16
		if string:
			for i in range(15):
				try:
					self.name[i] = string[i]
					if not string[i]:
						return
				except IndexError:
					# loop until null terminator, not until index errors
					pass

	def convert_to_lower(self):
		for i in range(15):
			try:
				self.name[i] = libc.tolower(self.name[i])
				if not self.name[i]:
					return
			except IndexError:
				# loop until null terminator, not until index errors
				pass

	def set_to_lower(self, string: memoryview):
		self.name = [0] * 16
		for i in range(15):
			try:
				self.name[i] = libc.tolower(string[i])
				if not self.name[i]:
					return
			except IndexError:
				# loop until null terminator, not until index errors
				pass

	def __repr__(self):
		if not self.name:
			return ""
		out = []
		for v in self.name:
			if v == 0:
				break
			out.append(chr(v))
		return "".join(out)
