"""Package initialization for easywheel."""

__version__ = "0.0.1"
