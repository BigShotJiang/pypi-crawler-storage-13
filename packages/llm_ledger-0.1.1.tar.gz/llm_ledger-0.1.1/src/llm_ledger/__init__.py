"""LLM Ledger - Production-ready LLM client with audit trail and deterministic caching."""

from .client import LedgerClient
from .models import (
    LLMRequest,
    LLMResponse,
    ProvenanceMetadata,
    TokenUsage,
    CompletionBuilder
)
from .cache import (
    DeterministicCache,
    CacheBackend,
    InMemoryCache,
    RedisCache
)
from .persistence import LLMPersistence

__version__ = "0.1.1"

__all__ = [
    # Main client
    "LedgerClient",
    
    # Models
    "LLMRequest",
    "LLMResponse",
    "ProvenanceMetadata",
    "TokenUsage",
    "CompletionBuilder",
    
    # Cache
    "DeterministicCache",
    "CacheBackend",
    "InMemoryCache",
    "RedisCache",
    
    # Persistence
    "LLMPersistence",
]
