print('Paket pip-creator-py başarıyla yüklendi!')

def ilk_ek():
    print('ilk ek çalıştı')

def ikinci_ek():
    print('ikinci ek çalıştı')

