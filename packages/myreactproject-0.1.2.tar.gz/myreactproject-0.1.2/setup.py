from setuptools import setup, find_packages

setup(
    name="myreactproject",
    version="0.1.2",
    packages=find_packages(),
    include_package_data=True,
)
