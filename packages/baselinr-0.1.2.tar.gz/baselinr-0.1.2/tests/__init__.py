"""Tests for baselinr."""
