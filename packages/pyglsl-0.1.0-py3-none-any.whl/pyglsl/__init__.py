# pyglsl -- https://github.com/takeiteasy/pyglsl
#
# Copyright (C) 2016 Nicholas Bishop
# Copyright (C) 2025 George Watson
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from .stage import VertexStage, FragmentStage, GeometryStage, TessControlStage, TessEvalStage, ComputeStage
from .interface import (ShaderInterface, UniformBlock, AttributeBlock,
                        FragmentShaderOutputBlock)
from .shaderdef import ShaderDef
from .types import GlslType, GlslArray, GlslStruct

__all__ = [
    'VertexStage',
    'FragmentStage',
    'GeometryStage',
    'TessControlStage',
    'TessEvalStage',
    'ComputeStage',
    'ShaderDef',
    'GlslStruct',
]
