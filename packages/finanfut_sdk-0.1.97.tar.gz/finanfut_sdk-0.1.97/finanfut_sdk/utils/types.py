"""Typed models used across the FinanFut SDK."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Mapping, Optional

from pydantic import BaseModel, Field, UUID4


class SDKBaseModel(BaseModel):
    class Config:
        orm_mode = True
        allow_population_by_field_name = True


class TokenUsage(SDKBaseModel):
    """Token usage summary for an interaction."""

    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    total_tokens: Optional[int] = None


class ActionResult(SDKBaseModel):
    """Represents an action returned by FinanFut agents."""

    name: str
    payload: Dict[str, Any]


class InteractionResponse(SDKBaseModel):
    """High-level response returned by `/api/v1/interact`."""

    answer: Any
    actions: List[ActionResult] = Field(default_factory=list)
    tokens: Optional[TokenUsage] = None
    sandbox: bool = False
    request_id: Optional[str] = None
    meta: Dict[str, Any] = Field(default_factory=dict)


def build_interaction_response(
    data: Mapping[str, Any], meta: Optional[Mapping[str, Any]] = None
) -> InteractionResponse:
    """Create an :class:`InteractionResponse` from backend payloads."""

    safe_meta = dict(meta or {})
    token_payload = (
        data.get("tokens")
        or data.get("token_usage")
        or safe_meta.get("token_usage")
        or safe_meta.get("tokens")
    )
    request_identifier = (
        data.get("request_id")
        or data.get("requestId")
        or safe_meta.get("request_id")
        or safe_meta.get("requestId")
    )
    return InteractionResponse.parse_obj(
        {
            "answer": data.get("answer"),
            "actions": data.get("actions") or [],
            "tokens": token_payload,
            "sandbox": bool(data.get("sandbox", safe_meta.get("sandbox", False))),
            "request_id": request_identifier,
            "meta": safe_meta,
        }
    )


class MemoryRecord(SDKBaseModel):
    """Represents a memory entry."""

    record_id: Optional[str] = None
    content: str
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )


class MemorySettings(SDKBaseModel):
    """Configuration for memory storage."""

    enabled: bool
    retention_days: Optional[int] = None
    max_records: Optional[int] = None


class MemoryQueryResponse(SDKBaseModel):
    """Response payload returned by memory query endpoints."""

    records: List[MemoryRecord] = Field(default_factory=list)
    total: Optional[int] = None


class BillingUsage(SDKBaseModel):
    """Current usage metrics."""

    period: str
    tokens_used: int
    cost: float


class BillingPlan(SDKBaseModel):
    """Generic billing plan descriptor."""

    plan_id: Optional[str] = None
    name: Optional[str] = None
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )


class TransactionRecord(SDKBaseModel):
    """Billing transaction entry."""

    transaction_id: str
    amount: float
    currency: str
    created_at: str
    description: Optional[str] = None


class Agent(SDKBaseModel):
    """Agent metadata."""

    agent_id: str
    name: str
    description: Optional[str] = None
    ai_model_id: Optional[str] = None


class Intent(SDKBaseModel):
    """Intent metadata compatible with backend responses."""

    intent_id: Optional[str] = Field(None, alias="id")
    name: Optional[str] = None
    slug: Optional[str] = None
    code: Optional[str] = None
    description: Optional[str] = None
    enabled: Optional[bool] = None
    input_schema: Optional[Dict[str, Any]] = None
    output_schema: Optional[Dict[str, Any]] = None

    class Config(SDKBaseModel.Config):
        extra = "allow"



class Application(SDKBaseModel):
    """Application metadata."""

    application_id: str
    name: str
    status: str


class ApplicationAgent(SDKBaseModel):
    """Application-scoped agent metadata."""

    application_agent_id: UUID4
    application_id: UUID4
    agent_id: Optional[UUID4] = None
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict, alias="metadata_")
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config(SDKBaseModel.Config):
        extra = "allow"


class ApplicationAgentList(SDKBaseModel):
    """Paginated application agent response payload."""

    items: List[ApplicationAgent] = Field(default_factory=list)
    total: int = 0
    limit: int = 0
    offset: int = 0


class AccessToken(SDKBaseModel):
    """Metadata describing a rotating access token."""

    token_id: str
    description: Optional[str] = None
    created_at: Optional[str] = None
    last_used_at: Optional[str] = None


class AccessTokenCreateRequest(SDKBaseModel):
    """Request payload for creating a new access token."""

    description: Optional[str] = None
    scopes: List[str] = Field(default_factory=list)


class AccessTokenListResponse(SDKBaseModel):
    """Paginated collection of access tokens."""

    items: List[AccessToken] = Field(default_factory=list)
    total: Optional[int] = None


class DocumentFile(SDKBaseModel):
    """Metadata about an uploaded document."""

    id: UUID4
    file_name: str
    mime_type: Optional[str] = None
    status: str
    chunk_count: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    document_type_id: Optional[UUID4] = None
    document_type: Optional[str] = None
    document_type_label: Optional[str] = None
    document_type_version: Optional[int] = None
    document_type_strict_validation: Optional[bool] = None
    document_type_embedding_enabled: Optional[bool] = None
    document_type_chunking_strategy: Optional[Dict[str, Any]] = None
    latest_processing_id: Optional[UUID4] = None
    processing_summary: Optional[str] = None
    processing_confidence: Optional[float] = None
    processing_version: int = 0
    classification_metadata: Optional[Dict[str, Any]] = None


class DocumentDetail(DocumentFile):
    """Full document payload returned after upload or lookup."""

    text_content: str = ""
    error: Optional[str] = None
    content_base64: Optional[str] = Field(default=None, repr=False)


class DocumentAnswer(SDKBaseModel):
    """Answer payload returned by the document QA endpoint."""

    answer: str
    request_id: Optional[UUID4] = None


class DocumentType(SDKBaseModel):
    """Descriptor for a pipeline document type."""

    id: UUID4
    name: str
    label: Optional[str] = None
    description: Optional[str] = None
    expected_format: Optional[str] = None
    parse_strategy: Optional[str] = None
    output_contract: Optional[Dict[str, Any]] = None
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )
    version: int = 1
    strict_validation: Optional[bool] = None
    embedding_enabled: Optional[bool] = None
    chunking_strategy: Dict[str, Any] = Field(default_factory=dict)
    is_active: Optional[bool] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class DocumentTypeDetail(DocumentType):
    """Detailed descriptor for a document type."""


class ValidationReport(SDKBaseModel):
    """Validation status after running the processing pipeline."""

    is_valid: bool
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)


class DeclarativeAction(SDKBaseModel):
    """Action emitted by the pipeline for downstream automation."""

    id: UUID4
    processing_record_id: UUID4
    document_id: UUID4
    application_id: UUID4
    name: str
    handler: str
    endpoint: Optional[str] = None
    description: Optional[str] = None
    version: int
    parameters: Dict[str, Any] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )
    processed_by_agent_id: Optional[UUID4] = None
    processed_by_agent_name: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class DocumentProcessingRecord(SDKBaseModel):
    """One processing run executed for a document."""

    id: UUID4
    document_id: UUID4
    application_id: UUID4
    document_type_id: Optional[UUID4] = None
    document_type_version: Optional[int] = None
    status: str
    summary: Optional[str] = None
    confidence: Optional[float] = None
    version: int
    processing_version: int = 1
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )
    parsed_content: Optional[Dict[str, Any]] = None
    raw_response: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    processor_agent_id: Optional[UUID4] = None
    processor_agent_name: Optional[str] = None
    execution_time_ms: Optional[int] = None
    tokens_used: int = 0
    parser_version: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class DocumentProcessingResponse(SDKBaseModel):
    """Full payload returned after requesting document processing."""

    record: DocumentProcessingRecord
    parsed_content: Optional[Dict[str, Any]] = None
    validation: ValidationReport
    dry_run: bool = False
    action: Optional[DeclarativeAction] = None


class DocumentRunsResponse(SDKBaseModel):
    """Historical processing runs."""

    runs: List[DocumentProcessingRecord] = Field(default_factory=list)


class DocumentParsedResponse(SDKBaseModel):
    """Latest parsed content and associated action."""

    record: Optional[DocumentProcessingRecord] = None
    action: Optional[DeclarativeAction] = None


class ContextDocumentLink(SDKBaseModel):
    """Context document relationship metadata."""

    document_id: UUID4
    position: Optional[int] = None
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class ContextSummary(SDKBaseModel):
    """High-level summary returned when listing contexts."""

    id: UUID4
    application_id: UUID4
    name: str
    description: Optional[str] = None
    status: str
    metadata: Dict[str, Any] = Field(
        default_factory=dict, alias="metadata_"
    )
    document_count: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class ContextDetail(ContextSummary):
    """Context detail including linked documents."""

    documents: List[ContextDocumentLink] = Field(
        default_factory=list, alias="document_links"
    )


class ContextList(SDKBaseModel):
    """Paginated response returned by the contexts API."""

    items: List[ContextSummary] = Field(default_factory=list)
    total: int = 0
    limit: int = 0
    offset: int = 0


class ContextSessionSummary(SDKBaseModel):
    """Summary of a context session."""

    id: UUID4
    name: str
    status: str
    context_id: Optional[UUID4] = None
    created_at: datetime
    updated_at: Optional[datetime] = None


class ContextSessionMessage(SDKBaseModel):
    """Message captured inside a context session."""

    id: UUID4
    session_id: UUID4
    context_id: Optional[UUID4] = None
    agent_name: str
    intent: Optional[str] = None
    role: str
    query: Optional[str] = None
    answer: Optional[str] = None
    tokens_used: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime


class ContextSessionDetail(ContextSessionSummary):
    """Detailed session with metadata and messages."""

    metadata: Dict[str, Any] = Field(default_factory=dict)
    messages: List[ContextSessionMessage] = Field(default_factory=list)


class ContextSessionList(SDKBaseModel):
    """Response returned when listing context sessions."""

    items: List[ContextSessionSummary] = Field(default_factory=list)
