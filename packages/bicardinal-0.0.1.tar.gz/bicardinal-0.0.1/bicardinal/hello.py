
print("Hello Universe!")