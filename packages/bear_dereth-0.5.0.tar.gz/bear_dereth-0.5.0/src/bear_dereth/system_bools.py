"""System boolean checks and getters."""

from funcy_bear.system_bools import (
    get_cwd,
    get_editor,
    get_home,
    get_python_version,
    get_shell,
    get_terminal,
    get_username,
    has_homebrew,
    has_nix,
    has_uv,
)

__all__ = [
    "get_cwd",
    "get_editor",
    "get_home",
    "get_python_version",
    "get_shell",
    "get_terminal",
    "get_username",
    "has_homebrew",
    "has_nix",
    "has_uv",
]
