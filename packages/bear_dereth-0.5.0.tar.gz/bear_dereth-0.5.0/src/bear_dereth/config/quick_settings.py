"""Simple settings manager supporting multiple file formats."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, Self

from bear_dereth.config.settings_path import SettingsHelper
from codec_cub.jsons.file_handler import JSONFileHandler
from codec_cub.toml.file_handler import TomlFileHandler
from codec_cub.yamls.file_handler import YamlFileHandler

if TYPE_CHECKING:
    from codec_cub.general.base_file_handler import BaseFileHandler

FileFormat = Literal["json", "yaml", "toml", "jsonl", "default", "msgpack"]
FileFormats: set[str] = {"json", "yaml", "toml", "jsonl", "msgpack"}


def get_file_handler(fmt: FileFormat, file_path: Path, **kwargs) -> BaseFileHandler[dict[str, Any]]:
    """Get the appropriate file handler for the specified format.

    Args:
        fmt: File format (json, yaml, or toml)
        file_path: Path to the file

    Returns:
        File handler instance for the format

    Raises:
        ValueError: If format is not supported
    """
    handlers: dict[FileFormat, type[BaseFileHandler]] = {
        "json": JSONFileHandler,
        "yaml": YamlFileHandler,
        "toml": TomlFileHandler,
        "msgpack": JSONFileHandler,
        "default": JSONFileHandler,
    }
    return handlers.get(fmt, JSONFileHandler)(file=file_path, **kwargs)


class SimpleKeyStore:
    """A simple settings manager supporting multiple file formats.

    Supports JSON, YAML, and TOML formats with automatic format detection
    based on file extension or explicit format parameter.

    Examples:
        # JSON (default)
        settings = SimpleKeyStore("myapp")

        # YAML
        settings = SimpleKeyStore("myapp", format="yaml")

        # TOML
        settings = SimpleKeyStore("myapp", format="toml")

        # Auto-detect from extension
        settings = SimpleKeyStore("myapp", file_name="config.yaml")
    """

    def __init__(
        self,
        name: str,
        file_name: str | None = None,
        path: Path | str | None = None,
        fmt: FileFormat = "json",
        strict: bool = False,
        **kwargs,
    ) -> None:
        """Initialize the SimpleKeyStore.

        Args:
            name: Settings name (used for default file path)
            file_name: Optional custom file name
            path: Optional custom directory path
            format: File format (json, yaml, toml). Auto-detected from extension if not provided.
            kwargs: Additional arguments passed to the file handler
        """
        self.name: str = name
        suffix: str | None = Path(file_name).suffix.replace(".", "") if file_name else None
        self.file_path: Path = SettingsHelper(
            name=name,
            file=file_name,
            path=path,
            ext=suffix or fmt,
            allowed_extensions=FileFormats,
            strict=strict,
        ).get_path()
        self.handler: BaseFileHandler[dict[str, Any]] = get_file_handler(fmt=fmt, file_path=self.file_path, **kwargs)
        self.settings: dict[str, Any] = self.read()

    def read(self) -> dict[str, Any]:
        """Read settings from the file.

        Returns:
            Dictionary of settings
        """
        try:
            data: dict[str, Any] = self.handler.read()
            return data if isinstance(data, dict) else {}
        except (ValueError, FileNotFoundError):
            return {}

    def write(self) -> None:
        """Write settings to the file."""
        self.handler.write(self.settings)

    def keys(self) -> list[str]:
        """Get a list of all setting keys."""
        return list(self.settings.keys())

    def values(self) -> list[Any]:
        """Get a list of all setting values."""
        return list(self.settings.values())

    def items(self) -> list[tuple[str, Any]]:
        """Get a list of all setting key-value pairs."""
        return list(self.settings.items())

    def all(self) -> dict[str, Any]:
        """Get all settings as a dictionary."""
        return self.settings.copy()

    def delete(self, key: str) -> None:
        """Delete a setting key."""
        if key in self.settings:
            del self.settings[key]
            self.write()

    def clear(self) -> None:
        """Clear all settings."""
        self.settings.clear()
        self.write()

    def set(self, key: str, value: Any) -> None:
        """Set a setting value."""
        self.settings[key] = value
        self.write()

    def get(self, key: str, default: Any = None) -> Any:
        """Get a setting value."""
        return self.settings.get(key, default)

    def has(self, key: str) -> bool:
        """Check if a setting key exists."""
        return key in self.settings

    def closed(self) -> bool:
        """Check if the file handle is closed."""
        return self.handler.closed

    def close(self) -> None:
        """Close the file handle."""
        if not self.handler.closed:
            self.handler.close()

    def __del__(self) -> None:
        self.close()

    def __len__(self) -> int:
        return len(self.settings)

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        self.close()


class SimpleSettingsManager(SimpleKeyStore):
    """An alias for SimpleKeyStore for backward compatibility."""
