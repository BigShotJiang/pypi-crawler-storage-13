"""
MEDUSA - Multi-Language Security Scanner
Universal security scanner with 40+ specialized analyzers for all languages and platforms.
"""

__version__ = "0.11.22"
__author__ = "Pantheon Security"
__license__ = "AGPL-3.0-or-later"

# Core modules are imported on-demand to avoid circular imports
# from medusa.core import parallel, reporter

__all__ = ["__version__"]
