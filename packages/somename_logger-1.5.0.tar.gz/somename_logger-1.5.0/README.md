# Fense_Logger

Fense-Logger is a python library for logging in various targets like console, opensearch, file or mysql

## Installation

Use the package manager [pip] to install fense-logger

```bash
pip install fense-logger
```

## Usage

import fense-logger

## Contributing

Pull requests are welcome. For major changes, please connect to main contributor to discuss and change

Please make sure to update tests as appropriate

## License

For internal usage of Fense Platform
