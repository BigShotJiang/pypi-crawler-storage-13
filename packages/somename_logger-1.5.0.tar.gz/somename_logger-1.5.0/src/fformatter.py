import json
import logging
from datetime import datetime, timezone


class FFormatter(logging.Formatter):
    """'
    Custom Fense Log Formatting Class
    """

    def format(self, record):
        # log_record = LogRecord()
        log_record = {
            # "timestamp": datetime.fromtimestamp(
            #     record.created, tz=timezone.utc
            # ).isoformat(sep=" ", timespec="seconds"),
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
            "level": record.levelname,
            "module": record.module,
            "message": record.message,
        }

        extra = getattr(record, "extra", None)
        if extra:
            rec = extra.__dict__
            for k, v in rec.items():
                log_record[k] = v

        return json.dumps(log_record)
