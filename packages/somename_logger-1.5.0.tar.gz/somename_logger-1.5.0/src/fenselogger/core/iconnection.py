# connections/base_connection.py
from abc import ABC, abstractmethod


class IBaseConnection(ABC):
    @abstractmethod
    def connect(self):
        """Establish and return a connection object"""
        pass

    @abstractmethod
    def close(self):
        """Close connection if applicable"""
        pass
