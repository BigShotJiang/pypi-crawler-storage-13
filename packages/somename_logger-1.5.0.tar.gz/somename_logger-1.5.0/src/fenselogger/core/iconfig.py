"""The Port of Configuration. This is what the callers of this functionality uses"""

from abc import ABC, abstractmethod


class IBaseConfig(ABC):
    @abstractmethod
    def load(self) -> dict:
        """Load configuration and return dict with targets"""
        pass
