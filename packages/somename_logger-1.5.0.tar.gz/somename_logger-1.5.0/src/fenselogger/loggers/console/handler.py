import logging
import sys


class FConsoleHandler(logging.StreamHandler):
    def __init__(self, conn_obj=None, **kwargs):
        super().__init__(sys.stdout)
