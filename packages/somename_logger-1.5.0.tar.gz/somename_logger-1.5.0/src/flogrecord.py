"""
Helper Log Record Class to send in Log function
"""

from typing import Any


class ExtraLog:
    """
        Helper class to add additional fields to log.
        Note: send this object in the "extra" object\n

    Usage:\n
        one = ExtraLog()\n
        one.tenant_id = "tenA1123r"\n
        one.correlation_id = 11\n
        one.customer_name = "ABC Inc"\n
        one.provider_name = "Fortuna Cysec"\n
        logger.info("Discovery Scanning Started", extra={"extra": one})
    """

    def __init__(self):
        self.tenant_id: str
        """
        Tenant Id is mandatory value
        """
        self.correlation_id: str = None
        self.process_name: str = None
        self.sub_process_name: str = None
        self.status: str = None
        self.execution_time_ms: str = None
        self.key_data: dict = {}

    def addKeyData(self, key: str, value: str):
        """
        Add additional Key data to log
        """
        self.key_data[key] = value
        return self

    def toDict(self) -> Any:
        return self.__dict__
