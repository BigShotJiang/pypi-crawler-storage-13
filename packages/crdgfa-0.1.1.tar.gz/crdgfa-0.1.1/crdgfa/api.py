import numpy as np
from typing import Iterable, Tuple
from numpy.typing import NDArray
from .core import Model, read_data, validate_args, write_data


def spectral_cross_sections(
    wavelength: int,
    index: str,
    radius: int,
    Nm: Iterable[int],
    sca: int = 0,
    save_output: bool = False,
) -> Tuple[
    NDArray[np.float64],
    NDArray[np.float64],
    NDArray[np.float64],
    NDArray[np.float64],
    NDArray[np.float64],
]:
    """
    Compute RDGFA-corrected cross sections for spectral refractive indices,
    where the refractive index is taken from tabulated,
    wavelength-dependent data (e.g. Organic,
    Amorphous, Graphitic, Diesel indices from the literature).

    Parameters
    ----------
    wavelength : int
        Incident wavelength in nm. Must match the tabulated wavelengths:
        "266, 354, 444, 532, 632, 848, 1064"
    index : str
        Name of the spectral refractive index:
        "Organic", "Amorphous", "Graphitic", "Diesel"
    radius : int
        Monomer radius in nm. The allowed values depend on the chosen
        refractive index and follow the ranges described in the paper/README
    Nm : iterable of int
        Number of monomers per aggregate
    sca : int, "0, 1"
        If 1, the code will also compute and write angular differential
        scattering cross sections Cvv and Chh for each Nm, using the
        Dobbins & Megaridis (1991) structure factor. If 0, only the
        integrated cross sections are computed.
    save_output : bool, optional
        If True, a text file containing Nm, A, h, Csca, Cabs and Cext is
        written to the "Output/" directory

    Returns
    -------
    A, h, Csca, Cabs, Cext : np.ndarray
        Arrays of the same length as the input Nm array, containing:
        - A    : correction factor for scattering
        - h    : correction factor for absorption
        - Csca : scattering cross section (nm^2)
        - Cabs : absorption cross section (nm^2)
        - Cext : extinction cross section (nm^2 = Csca + Cabs)
    """
    # This string is only used internally by validate_args/read_data/write_data
    # to select the correct branch (spectral vs fixed index).
    name_file = "Run_Spectral.py"

    Nm_arr = np.asarray(Nm, dtype=int)

    validate_args(name_file, wavelength, index, radius, Nm_arr, sca)
    Lambda0, gamma, Theta0, m = read_data(
        name_file,
        wavelength,
        index,
        radius,
    )

    A, h, Csca, Cabs, Cext = Model(
        sca,
        Lambda0,
        gamma,
        Theta0,
        radius,
        wavelength,
        m,
        Nm_arr,
    )

    if save_output:
        write_data(
            name_file,
            A,
            h,
            Csca,
            Cabs,
            Cext,
            wavelength,
            index,
            radius,
            Nm_arr,
        )

    return A, h, Csca, Cabs, Cext


def fixed_cross_sections(
    wavelength: int,
    index: str,
    radius: int,
    Nm: Iterable[int],
    sca: int = 0,
    save_output: bool = False,
) -> Tuple[
    NDArray[np.float64],
    NDArray[np.float64],
    NDArray[np.float64],
    NDArray[np.float64],
    NDArray[np.float64],
]:
    """
    Compute RDGFA-corrected cross sections for constant refractive indices,
    where the refractive index is assumed constant with wavelength
    (e.g. Williams, Bescond, Bond indices).

    Parameters
    ----------
    wavelength : int
        Incident wavelength in nm.
    index : str
        Name of the constant refractive index:
        "Williams", "Bescond", "Bond"
    radius : int
        Monomer radius in nm.
    Nm : iterable of int
        Number of monomers per aggregate.
    sca : int, "0, 1"
        If 1, the code will also compute and write angular differential
        scattering cross sections Cvv and Chh for each Nm, using the
        Dobbins & Megaridis (1991) structure factor. If 0, only the
        integrated cross sections are computed.
    save_output : bool, optional
        If True, a text file containing Nm, A, h, Csca, Cabs and Cext is
        written to the "Output/" directory, reproducing the original
        behavior of the code.

    Returns
    -------
    A, h, Csca, Cabs, Cext : np.ndarray
        Arrays of the same length as the input Nm array, containing:
        - A    : correction factor for scattering
        - h    : correction factor for absorption
        - Csca : scattering cross section (nm^2)
        - Cabs : absorption cross section (nm^2)
        - Cext : extinction cross section (nm^2 = Csca + Cabs)
    """
    # Same idea: this is a logical flag for the internal core functions.
    name_file = "Run_Fixed.py"

    Nm_arr = np.asarray(Nm, dtype=int)

    validate_args(name_file, wavelength, index, radius, Nm_arr, sca)
    Lambda0, gamma, Theta0, m = read_data(
        name_file,
        wavelength,
        index,
        radius,
    )

    A, h, Csca, Cabs, Cext = Model(
        sca,
        Lambda0,
        gamma,
        Theta0,
        radius,
        wavelength,
        m,
        Nm_arr,
    )

    if save_output:
        write_data(
            name_file,
            A,
            h,
            Csca,
            Cabs,
            Cext,
            wavelength,
            index,
            radius,
            Nm_arr,
        )

    return A, h, Csca, Cabs, Cext
