__author__ = "Clément Argentin"
__license__ = "GPL-3.0"
__version__ = "0.1.1"
__url__ = "https://gitlab.coria-cfd.fr/c-rdgfa/C-RDGFA"

from .api import fixed_cross_sections, spectral_cross_sections

__all__ = ["spectral_cross_sections", "fixed_cross_sections"]
