import numpy as np
import pandas as pd
from pathlib import Path
from scipy import integrate
from scipy import interpolate
from functools import partial

BASE_DIR = Path(__file__).resolve().parent


def validate_args(name_file, wavelength, index, radius, Nm, sca):
    print("------Paramaters------")
    print(f"Index: {index}")
    print(f"Monomer radius: {radius}nm")
    print(f"Incident wavelength: {wavelength}nm")

    if name_file == "Run_Spectral.py":
        mywavelength = ["266", "354", "444", "532", "632", "848", "1064"]
        mylist = [
            "Graphitic,Rm=5",
            "Amorphous,Rm=5",
            "Organic,Rm=5",
            "Graphitic,Rm=15",
            "Amorphous,Rm=15",
            "Organic,Rm=15",
            "Graphitic,Rm=30",
            "Amorphous,Rm=30",
            "Organic,Rm=30",
            "Diesel,Rm=17",
        ]
        if f"{index},Rm={radius}" not in mylist:
            raise ValueError("Wrong index or radius")
        elif f"{wavelength}" not in mywavelength:
            raise ValueError("Wrong wavelength")

    elif name_file == "Run_Fixed.py":
        mylist = ["Williams", "Bescond", "Bond"]
        xm = 2 * np.pi / wavelength * radius
        print("Size parameter xm =", "%.2f" % xm)
        if xm > 0.75:
            raise ValueError("xm too large")
        elif f"{index}" not in mylist:
            raise ValueError("Wrong index")

    nmin = np.min(Nm)
    nmax = np.max(Nm)
    npts = np.size(Nm)

    print(
        f"Number of monomers: {nmin:.0f} to {nmax:.0f} "
        f"with {npts:.0f} points"
    )

    if sca == 1:
        print("Allows Cvv calculation \n")
    else:
        print("Does not allow Cvv calculation \n")


def read_data(name_file, wavelength, index, radius):
    if name_file == "Run_Spectral.py":
        input_filename = (
            BASE_DIR / "Fit_parameters" / f"index={index}_radius={radius}.dat"
        )
        data = pd.read_csv(input_filename, index_col=0)
        # Fit parameters
        Lambda0 = data.loc[wavelength, "Lambda(0)"]
        gamma = data.loc[wavelength, "gamma"]
        Theta0 = data.loc[wavelength, "Theta(0)"]
        m = complex(data.loc[wavelength, "m"])

    elif name_file == "Run_Fixed.py":
        input_filename = BASE_DIR / "Fit_parameters" / f"index={index}.dat"
        data = pd.read_csv(input_filename, index_col=0)
        # Fit parameters
        xm = 2 * np.pi / wavelength * radius
        Lambda0 = f(xm, data["xp"], data["Lambda(0)"])
        gamma = f(xm, data["xp"], data["gamma"])
        Theta0 = f(xm, data["xp"], data["Theta(0)"])
        m = complex(data.loc[0, "m"])

    return Lambda0, gamma, Theta0, m


def write_data(
    name_file, A, h, Csca, Cabs, Cext, wavelength, index, radius, Nm
):
    output = {
        "Nm": Nm,
        "A": A,
        "h": h,
        "Csca(nm²)": Csca,
        "Cabs(nm²)": Cabs,
        "Cext(nm²)": Cext,
    }
    output = pd.DataFrame(output)

    if not Path("Output").exists():
        Path("Output").mkdir()

    if name_file == "Run_Spectral.py":
        output_filename = (
            Path("Output")
            / f"output={index}_Rm={radius}nm_wavelength={wavelength}nm.dat"
        )

    elif name_file == "Run_Fixed.py":
        xm = 2 * np.pi / wavelength * radius
        output_filename = (
            Path("Output") / f'output={index}_xm={"%.2f" % xm}.dat'
        )

    output.to_csv(output_filename, float_format="%.2f")


def f(x, x_points, y_points):
    x_points = x_points
    y_points = y_points
    tck = interpolate.splrep(x_points, y_points)
    return interpolate.splev(x, tck)


def calcul_G(x, Rmax, Df, ymin=0.01, ny=200):
    """
    compute elementary disc of thickness dx at x
    """
    y = np.linspace(ymin, np.sqrt(Rmax**2 - x**2), ny)
    G = np.sum(y * (x**2 + y**2) ** ((Df - 3) / 2)) * (y[2] - y[1])
    return G


def calcul_alpha(kapa, Df, kf, Rp):
    """
    compute constant term alpha
    """
    alpha = 2 / 3 / kapa**Df * np.pi * kf * Df * Rp ** (3 - Df)
    return alpha


def calcul_dV(xp, Rmax, alpha, Df):
    """
    compute volume distribution Eq.(16)
    """
    R = abs(Rmax - xp)
    dV = alpha * calcul_G(R, Rmax, Df)
    return dV


def fit_phasor(xp, Lambda0, gamma, Theta0, radius):
    """
    compute Gamma et Theta Eq.(13)
    """
    Amplitude = Lambda0 * np.exp(-gamma * (xp / radius) ** 0.4)
    Phase = Theta0 * (1 - np.exp(-1 * (xp / radius) ** 0.4))
    return Amplitude, Phase


def calcul_Cos(xp, Rmax, alpha, Df, Lambda0, gamma, Theta0, radius):
    """
    compute cosinus in Eq.(15)
    """
    dV = calcul_dV(xp, Rmax, alpha, Df)
    Amplitude, Phase = fit_phasor(xp, Lambda0, gamma, Theta0, radius)
    dCos = Amplitude * np.cos(Phase) * dV
    return dCos


def calcul_Sin(xp, Rmax, alpha, Df, Lambda0, gamma, Theta0, radius):
    """
    compute sinus in Eq.(15)
    """
    dV = calcul_dV(xp, Rmax, alpha, Df)
    Amplitude, Phase = fit_phasor(xp, Lambda0, gamma, Theta0, radius)
    dSin = Amplitude * np.sin(Phase) * dV
    return dSin


def Nm_low(Nm, Ainf, Nmc, b):
    """
    compute A_EM Eq.(17)
    """
    return Ainf + (1 - Ainf) * np.exp(-(((Nm - 1) / (Nmc)) ** b))


def diff_scattering(Rg, Df, wavelength, Amodel, Nm, Fm, radius):
    """
    Compute and write Cvv/Chh following the structure factor (Eq.34) of
    Dobbins & Megaridis (1991)
    """
    theta = np.linspace(0.0001, 180, 181) * np.pi / 180  # rad
    q = 4 * np.pi / wavelength * np.sin(theta / 2)
    e = 2.718
    var = q**2 * Rg**2
    Sq = np.where(
        var <= 1.5 * Df,
        np.exp(-var / 3),
        ((3 * Df) / (2 * e * var)) ** (Df / 2),
    )
    Cvv = (
        Nm_low(Nm, Amodel, 9 / 4, 0.5)
        * Nm**2
        * 16
        * np.pi**4
        * Fm
        * radius**6
        / wavelength**4
        * Sq
    )
    Chh = Cvv * np.cos(theta) ** 2
    output = {
        "Cvv(nm²)": Cvv,
        "Chh(nm²)": Chh,
        "theta": theta * 180 / np.pi,
        "qRg": q * Rg,
        "q²Rg²": q**2 * Rg**2,
    }
    output = pd.DataFrame(output)
    if not Path("Output").exists():
        Path("Output").mkdir()
    output_filename = (
        Path("Output") / f'Cvv_Rg={"%.0f" % Rg}nm_Nm={"%.0f" % Nm}.dat'
    )
    output.to_csv(output_filename, float_format="%.15f")


def integral(
    Nm,
    kapa,
    kf,
    Df,
    alpha,
    Lambda0,
    gamma,
    Theta0,
    radius,
    wavelength,
    Fm,
    sca,
):
    Rg = radius * (Nm / kf) ** (1 / Df)
    Rmax = kapa * Rg
    numCos, err = integrate.quad(
        calcul_Cos,
        0.01,
        2 * Rmax * 0.999,
        args=(Rmax, alpha, Df, Lambda0, gamma, Theta0, radius),
    )
    numSin, err = integrate.quad(
        calcul_Sin,
        0.01,
        2 * Rmax * 0.999,
        args=(Rmax, alpha, Df, Lambda0, gamma, Theta0, radius),
    )
    V, err = integrate.quad(
        calcul_dV, 0.01, 2 * Rmax * 0.999, args=(Rmax, alpha, Df)
    )
    Amodel = ((numCos) ** 2 + (numSin) ** 2) / (V) ** 2
    if sca == 1:
        diff_scattering(Rg, Df, wavelength, Amodel, Nm, Fm, radius)
    return Nm_low(Nm, Amodel, 9 / 4, 0.5), Nm_low(
        Nm, 1.071 * Amodel, 9 / 4, 0.5
    )


def Model(sca, Lambda0, gamma, Theta0, radius, wavelength, m, Nm):
    """
    compute A, h, Csca, Cabs and Cext in function of Nm
    """
    Df = 1.78
    kf = 1.44
    kapa = 1.5
    Fm = abs(((m**2 - 1) / (m**2 + 2)) ** 2)
    Em = ((m**2 - 1) / (m**2 + 2)).imag
    alpha = calcul_alpha(kapa, Df, kf, radius)
    partial_func = partial(
        integral,
        kapa=kapa,
        kf=kf,
        Df=Df,
        alpha=alpha,
        Lambda0=Lambda0,
        gamma=gamma,
        Theta0=Theta0,
        radius=radius,
        wavelength=wavelength,
        Fm=Fm,
        sca=sca,
    )
    A, h = zip(*np.array(list(map(partial_func, Nm))))
    Csca = A * Nm**2 * 128 * np.pi**5 * radius**6 * Fm / (3 * wavelength**4)
    Cabs = h * Nm * 8 * np.pi**2 * radius**3 * Em / wavelength
    Cext = Csca + Cabs
    return A, h, Csca, Cabs, Cext
