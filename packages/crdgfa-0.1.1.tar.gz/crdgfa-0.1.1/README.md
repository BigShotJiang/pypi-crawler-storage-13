# C-RDGFA

[![PyPI](https://img.shields.io/pypi/v/crdgfa.svg)](https://pypi.org/project/crdgfa/)

C-RDGFA is a Rayleigh-Debye-Gans corrected code for fractal aggregates.

It's purpose is to correct the Rayleigh-Debye-Gans approximation for soot fractal aggregates (RDG-SFA). Indeed, soot are known to violated the RDG criteria. Therefore, correction factors are needed to compute accurate radiative properties such as cross sections. These corrections are based on a new approach called phasor in slices in [`1`], where the internal electric field is modelled per aggregate slice along the light propagation axis. This approach reveals a phenomenon of absorption by addition of matter (Trapping) which is similar to the Beer-Lambert law.

The process goes as follow:
1. We initalize the incident wavelength, monomer radius and refractive index.
2. We read the fit parameters depending on the variables initialize in step 1. 
3. We fit the cross sections by following the mathematical development of [`1`] over a given range of number of monomer Nm.

The modelled cross-sections were calculated and found to be accurate for a range of Nm not exceeding `1000` [`1`].

The code is divided into two categories: refractive indices taking into account spectral dependence and constant indices.

## Spectral refractive indices

At the moment the code is implemented with four spectral refractive indices

    Organic [2]
    Amorphous [2]
    Graphitic [2]
    Diesel [3]

with the following wavelength range [`266`,`354`,`444`,`532`,`632`,`848`,`1064`]nm. The cross sections for the first three indices are modelable for three monomer radii [`5`,`15`,`30`]nm, for the fourth, only one radius is available, `17`nm. 

The user has access to fairly accurate cross-sections (see Fig.8 in [`1`]) for indices representative of soot at specific wavelengths. However, the wavelengths are imposed and the radius of the monomers is limited.

## Constant indices

Users who are more interested in a specific size parameter rather than a variable index can choose between three constant refractive indices with respect to wavelength

    m=1.75+i1.03 (Williams index [4])
    m=1.55+i0.86 (Bescond index [2])
    m=1.95+i0.79 (Bond index [5])

Therefore, the radius and wavelength are not limited due to the scale invariant rule. However, the indices will not be representative of soot outside their wavelength used to define them [`2`,`4`,`5`].

The user is encouraged not to exceed a size parameter of `0.75` as the accuracy of the results has not yet been tested.

## Scientific paper
* [`1`] **C. Argentin, M. J. Berg, M. Mazur, R. Ceolato, A. Poux, J. Yon,** A semi-empirical correction for the Rayleigh-Debye-Gans approximation for fractal aggregates based on phasor analysis: Application to soot particles, *Journal of Quantitative Spectroscopy and Radiative Transfer* DOI: Awaiting proofreading
* [`2`] **A. Bescond, J. Yon, F.-X. Ouf, C. Rozé, A. Coppalle, P. Parent, D. Ferry, C. Laffon,** Soot optical properties determined by analyzing extinction spectra in the visible near-uv: Toward an optical speciation according to constituents and structure, *Journal of Aerosol Science 101 (2016) 118–132.* ([10.1016/j.jaerosci.2016.08.001](https://doi.org/10.1016/j.jaerosci.2016.08.001))
* [`3`] **J. Yon, F. Liu, A. Bescond, C. Caumont-Prim, C. Rozé, F.-X. Ouf, A. Coppalle,** Effects of multiple scattering on radiative properties of soot fractal aggregates, *Journal of Quantitative Spectroscopy and Radiative Transfer 133 (2014) 374–381.* ([
10.1016/j.jqsrt.2013.08.022](https://doi.org/10.1016/j.jqsrt.2013.08.022))
* [`4`] **T. C. Williams, C. R. Shaddix, K. A. Jensen, J. M. Suo-Anttila,** Measurement of the dimensionless extinction coefficient of soot within laminar diffusion flames, *International Journal of Heat and Mass Transfer 50 (7-8) (2007) 1616–1630.* ([
10.1016/j.ijheatmasstransfer.2006.08.024](https://doi.org/10.1016/j.ijheatmasstransfer.2006.08.024))
* [`5`] **Bond, T. C., and R. W. Bergstrom,** Light absorption by carbonaceous particles: An investigative review. *Aerosol Sci. Technol. 40(1):27–67.* ([10.1080/j.aerosolscienceandtechnology.2007.02.23](https://doi.org/10.1080/02786820500421521))
* [`6`] **R. A. Dobbins and C. M. Megaridis,** Absorption and scattering of light by polydisperse aggregates, *Applied Optics Vol. 30, Issue 33, pp. 4747-4754 (1991)* ([10.1364/j.ao.1991.11.020](https://doi.org/10.1364/AO.30.004747))

## Installation

Install directly from PyPI:

```bash
pip install crdgfa
```

## Usage

C-RDGFA provides a clean interface with two functions:
- `crdgfa.spectral_cross_sections`
- `crdgfa.fixed_cross_sections`

The user must choose the refractive index, the wavelength, the radius of the monomers and the desired range of monomer numbers. In addition, the user has the option of outputting or not the differential scattering cross section (where the structure factor is derived from [`6`]) by setting the variable `sca` at `1`.

### Exemple 1 - Spectral refractive index
```python
import numpy as np
import crdgfa

Nm = np.arange(1, 1000)  # number of monomers (integers)

A, h, Csca, Cabs, Cext = crdgfa.spectral_cross_sections(
    wavelength=444,        # tabulated wavelengths
    index="Amorphous",     # "Organic", "Amorphous", "Graphitic", "Diesel"
    radius=15,             # allowed radius depends on index
    Nm=Nm,
    sca=0,                 # set to 1 to output angular scattering files
    save_output=True,      # output A h Csca Cabs Cext
)
```

### Exemple 2 - Constant refractive index
```python
import numpy as np
import crdgfa

Nm = np.arange(1, 1000)

A, h, Csca, Cabs, Cext = crdgfa.fixed_cross_sections(
    wavelength=400,        # x_p should be < 0.75
    index="Bond",          # "Williams", "Bescond", or "Bond"
    radius=18,             # x_p should be < 0.75
    Nm=Nm,
    sca=0,                 # set to 1 to output angular scattering files
    save_output=True,      # output A h Csca Cabs Cext
)
```

### Parameter 
`Nm` may be any iterable of integers, allowing for various physical distributions (linear, uniform, logarithmic, etc.).

## Output

The code gives an output file containing six columns (if `save_output=True`):

    Nm: Number of monomer
    A: Corrective term to the RDG for forward scattering
    h: Corrective term to the RDG for absorption
    Csca: Scattering cross section (nm²)
    Cabs: Absorption cross section (nm²)
    Cext: Extinction cross section (nm²)

If the variable `sca` is set at `1` in the file Run_Spectral.py or Run_Fixed.py, for each Nm an output file containing the angular scattering cross section will be generated with four columns:

    Cvv: Differencial scattering cross section in vertical-vertical polarization (nm²)
    Chh: Differencial scattering cross section in horizontal-horizontal polarization (nm²)
    theta: Scattering angle
    qRg: Product of the radius of gyration and the modulus of the scattering vector.
    q²Rg²: Product of the square of the radius of gyration and the square of the modulus of the scattering vector.

## Update

Developers who want to improve the code are invited to read the [CONTRIBUTING.md](CONTRIBUTING.md) file for guidelines.
