"""
Public API optimization.
Filters code to show only public/exported elements.
"""

from __future__ import annotations

from typing import cast

from ..context import ProcessingContext


class PublicApiOptimizer:
    """Handles filtering code for public API only."""
    
    def __init__(self, adapter):
        """
        Initialize with parent adapter for language-specific checks.
        """
        from ..code_base import CodeAdapter
        self.adapter = cast(CodeAdapter, adapter)
    
    def apply(self, context: ProcessingContext) -> None:
        """
        Apply public API filtering.
        Removes private/protected elements, keeping only public/exported ones.

        Args:
            context: Processing context with document and editor
        """
        # Get unified code analyzer for language
        code_analyzer = self.adapter.create_code_analyzer(context.doc)

        # Collect all private elements using analyzer
        private_elements = code_analyzer.collect_private_elements_for_public_api()

        # First compute ranges with decorators for all elements
        element_ranges = [
            (code_analyzer.get_element_range_with_decorators(elem), elem)
            for elem in private_elements
        ]

        # Sort by position (in reverse order for safe removal)
        element_ranges.sort(key=lambda x: x[0][0], reverse=True)

        # Remove private elements with appropriate placeholders
        for (start_char, end_char), private_element in element_ranges:
            start_line = context.doc.get_line_number(start_char)
            end_line = context.doc.get_line_number(end_char)
            context.add_placeholder(private_element.element_type, start_char, end_char, start_line, end_line)
