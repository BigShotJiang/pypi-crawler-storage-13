"""
Processing context for language adapters.
Encapsulates state and provides methods for typical operations.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from .metrics import MetricsCollector
from .placeholders import PlaceholderManager, create_placeholder_manager
from .range_edits import RangeEditor
from .tree_sitter_support import TreeSitterDocument, Node
from ..stats import TokenService


class LightState:
    def __init__(
            self,
            file_path: Path,
            raw_text: str,
            group_size: int
    ):
        self.file_path = file_path
        self.raw_text = raw_text
        self.group_size = group_size

        # Calculate derived fields
        self.filename = file_path.name
        self.ext = file_path.suffix.lstrip(".") if file_path.suffix else ""

class LightweightContext(LightState):
    """
    Lightweight processing context with basic file information.
    Created at an early stage and can be lazily extended to ProcessingContext.
    """

    def __init__(
        self,
        file_path: Path,
        raw_text: str,
        group_size: int,
        template_ctx=None,
        file_label: str = None
    ):
        super().__init__(file_path, raw_text, group_size)

        # For lazy initialization of full context
        self._full_context: Optional[ProcessingContext] = None
        # Template context for processing conditional constructs
        self.template_ctx = template_ctx
        # File label for insertion into documentation
        self.file_label = file_label

    def get_full_context(self, adapter, tokenizer: TokenService) -> ProcessingContext:
        """
        Lazy creation of full ProcessingContext when needed.

        Args:
            tokenizer: Token counting service
            adapter: Language adapter for creating document and placeholder generator

        Returns:
            ProcessingContext initialized from this lightweight context
        """
        if self._full_context is None:
            self._full_context = ProcessingContext.from_lightweight(self, adapter, tokenizer)

        return self._full_context


class ProcessingContext(LightState):
    """
    Processing context, encapsulating doc, editor, placeholders and metrics.
    """

    def __init__(
        self,
        file_path: Path,
        raw_text: str,
        group_size: int,
        adapter_name: str,
        doc: TreeSitterDocument,
        editor: RangeEditor,
        placeholders: PlaceholderManager,
        tokenizer: TokenService,
    ):
        super().__init__(file_path, raw_text, group_size)

        self.doc = doc
        self.editor = editor
        self.placeholders = placeholders
        self.metrics = MetricsCollector(adapter_name)
        self.tokenizer = tokenizer

    def add_placeholder(self, element_type: str, start_char: int, end_char: int, start_line: int, end_line: int,
                        placeholder_prefix: str = "", count: int = 1) -> None:
        """Add placeholder."""
        self.placeholders.add_placeholder(
            element_type, start_char, end_char, start_line, end_line, placeholder_prefix, count
        )
        self.metrics.mark_element_removed(element_type, count)
        self.metrics.mark_placeholder_inserted()

    def add_placeholder_for_node(self, element_type: str, node: Node, count: int = 1) -> None:
        """Add placeholder exactly at node boundaries."""
        self.placeholders.add_placeholder_for_node(element_type, node, self.doc, count=count)
        self.metrics.mark_element_removed(element_type, count)
        self.metrics.mark_placeholder_inserted()

    @classmethod
    def from_lightweight(
        cls,
        lightweight_ctx: LightweightContext,
        adapter,
        tokenizer: TokenService
    ) -> ProcessingContext:
        """
        Create full ProcessingContext from lightweight context.

        Args:
            lightweight_ctx: Lightweight context with basic information
            adapter: Language adapter for creating components
            tokenizer: Token counting service

        Returns:
            Full ProcessingContext
        """
        # Create components for full context
        doc = adapter.create_document(lightweight_ctx.raw_text, lightweight_ctx.ext)
        editor = RangeEditor(lightweight_ctx.raw_text)

        # Create PlaceholderManager with settings from adapter
        placeholders = create_placeholder_manager(
            lightweight_ctx.raw_text,
            adapter.get_comment_style(),
            adapter.cfg.placeholders.style,
        )

        return cls(
            lightweight_ctx.file_path,
            lightweight_ctx.raw_text,
            lightweight_ctx.group_size,
            adapter.name,
            doc,
            editor,
            placeholders,
            tokenizer,
        )
