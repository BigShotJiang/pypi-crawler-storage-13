# CyberLicensing Python SDK

Utilities for integrating with the CyberLicensing service.

## Installation

For now, install directly from the project root:

```bash
pip install cyberlicensing
```

## Client-side usage

```python
from cyberlicensing import LicenseClient

client = LicenseClient(
    base_url="https://licensing.showdown.boo",
    project_id=1,
)
result = client.validate_with_environment("LICENSE-KEY-1234")
print(result)
```

`validate_with_environment` automatically gathers HWID/IP metadata and sends it along with the required `project_id`. Use `validate_license` if you want to provide your own context.

The request body sent to the public endpoint `/api/validate_license` is compatible with the API contract:

```json
{
  "project_id": 1,
  "key": "LICENSE-KEY-1234",
  "hwid": "unique-hardware-id",
  "metadata": {
    "plan": "enterprise",
    "seats": 10
  }
}
```

## Manager-side usage

```python
from cyberlicensing import ManagerClient

manager = ManagerClient(base_url="https://licensing.showdown.boo")
manager.authenticate("admin", "password")
projects = manager.list_projects()
project_id = projects[0]["id"]
license_data = manager.create_license(
    project_id,
    days_valid=30,
    metadata={"plan": "pro"},
)

# Update or revoke a license
manager.update_license(
    license_id=license_data["id"],
    is_active=False,
    metadata={"plan": "revoked", "notes": "Chargeback"},
)
```

Additional helpers:

- `list_licenses(project_id)` – list all licenses (keys + live metadata and usage counters) for a project
- `create_license(project_id, days_valid=None, metadata=None)` – generate a new license key
- `update_license(license_id, is_active=None, expires_at=None, reset_hwid=False, metadata=None)` – ban/disable, move expiration, reset HWID, or overwrite metadata
- `extend_license(project_id, license_id, days)` – convenience method to push expiration forward
- `delete_license(license_id)` – hard-delete a key

## Environment helpers

```python
from cyberlicensing import collect_environment_metadata

print(collect_environment_metadata())
```

Returns HWID, hostname, LAN IP, and (if available) public IP.
