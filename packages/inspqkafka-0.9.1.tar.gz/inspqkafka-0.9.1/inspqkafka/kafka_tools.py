def str2bool(value:str) -> bool:
    if isinstance(value, bool):
        return value
    if value.lower() in ["true", "yes", "oui", "vrai"]:
        return True
    return False
