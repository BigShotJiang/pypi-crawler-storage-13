# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['inspqkafka']

package_data = \
{'': ['*']}

install_requires = \
['confluent_kafka>=1.8,<2.0', 'pytest>=7.0,<8.0']

setup_kwargs = {
    'name': 'inspqkafka',
    'version': '0.9.1',
    'description': '',
    'long_description': '',
    'author': 'Philippe Gauthier',
    'author_email': 'philippe.gauthier@inspq.qc.ca',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
