from .core import BST, AVL, Algo, Node

