from .base_domain_exception import BaseDomainException

__all__ = [
    "BaseDomainException",
]