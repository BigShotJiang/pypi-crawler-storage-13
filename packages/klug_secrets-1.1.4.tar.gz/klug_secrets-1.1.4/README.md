# klug-secrets

CLI tool for managing secrets and environments via KLUG Autocloud API.

## Installation

```bash
pip install klug-secrets
```

## Configuration

Set the API key as an environment variable:

```bash
export KLUG_AUTOCLOUD_API_KEY=your-api-key-here
```

## Usage

### Secrets Management

```bash
# List all secrets (one secret name per line)
klug-secrets secrets list
# Output:
# secret-1
# secret-2
# my-secret

# Get a secret (returns only the value)
klug-secrets secrets get my-secret
# Output:
# secret-value

# Add a secret
klug-secrets secrets add my-secret "secret-value"

# Update a secret
klug-secrets secrets update my-secret --value "new-value"

# Delete a secret
klug-secrets secrets delete my-secret
```

### Environment Management

```bash
# List all environments (one per line: system_id/env_name)
klug-secrets envs list
# Output:
# main/dev
# main/prod
# staging/test

# List environments for a specific system
klug-secrets envs list --system main
# Output:
# main/dev
# main/prod

# Get an environment (returns .env file format)
klug-secrets envs get --system main --env dev
# Output:
# DATABASE_URL=postgres://localhost:5432/mydb
# API_KEY=secret-key-123
# DEBUG=true

# Add environment from .env file
klug-secrets envs add --system main --env dev --file .env

# Add environment from stdin (pipe .env file)
cat .env | klug-secrets envs --system main --env dev

# Add environment with individual variables
klug-secrets envs add --system main --env dev --var DATABASE_URL=postgres://... --var API_KEY=secret

# Update environment from stdin
cat .env | klug-secrets envs update --system main --env dev

# Update environment from file
klug-secrets envs update --system main --env dev --file .env

# Delete environment
klug-secrets envs delete --system main --env dev

# Dump environment to file
klug-secrets envs dump --system main --env dev
# Saves to ./.env.dev
```

## Examples

### Upload .env file from stdin

```bash
cat .env | klug-secrets envs --system main --env production
```

### Upload .env file from file

```bash
klug-secrets envs add --system main --env production --file .env.production
```

## License

MIT License

