"""
KLUG Secrets CLI - Command-line interface for secrets management.
"""

__version__ = '1.0.0'

