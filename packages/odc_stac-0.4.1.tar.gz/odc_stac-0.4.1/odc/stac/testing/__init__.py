"""
Utilities used in tests.
"""
