from datetime import datetime, timedelta
from dataclasses import KW_ONLY, dataclass, field
from itertools import chain


@dataclass
class Employee:
    """
    An employee that can be assigned to shifts.

    Parameters
    ----------
    skills
        The skills that the employee possesses.
    name
        The name of the employee.
    """

    skills: set[str]
    _: KW_ONLY
    name: str = ""


@dataclass
class FlexibleInterval:
    """
    A time interval with flexible start and end times, and flexible duration.

    Parameters
    ----------
    start
        The start time bounds of the interval, as a tuple of (earliest, latest).
    end
        The end time bounds of the interval, as a tuple of (earliest, latest).
    duration
        The duration bounds of the interval, as a tuple of (minimum, maximum).
    """

    start: tuple[datetime, datetime]
    end: tuple[datetime, datetime]
    duration: tuple[timedelta, timedelta]


@dataclass
class Shift:
    """
    A shift that needs to be covered by employees.

    Parameters
    ----------
    num_required
        The number of employees required for this shift.
    skills
        The skills required for this shift. All skills must be possessed by
        an employee to be eligible.
    type
        The type of the shift (e.g., "morning", "evening").
    interval
        The time interval during which the shift takes place.
    breaks
        The breaks that need to be taken during the shift.
    """

    num_required: int = 1
    skills: set[str] = field(default_factory=set)
    type: str = ""

    # Fields that are still evolving
    interval: FlexibleInterval | None = None
    breaks: list[FlexibleInterval] = field(default_factory=list)
    _: KW_ONLY
    name: str = ""


@dataclass
class ProblemData:
    employees: list[Employee]
    shifts: list[Shift]

    @property
    def skills(self) -> set[str]:
        return set(
            chain(
                (skill for empl in self.employees for skill in empl.skills),
                (skill for shift in self.shifts for skill in shift.skills),
            )
        )


@dataclass
class Solution:
    """
    A solution to the employee scheduling problem.

    This is essentially a matrix consisting of employees and shifts, where
    each entry indicates whether an employee is assigned to a shift or not.

    A solution does not need to be complete, which is useful in case a partial
    assignment assignment is decided.
    """

    assignments: dict[str, list[str]]
    unassigned: list[str]
