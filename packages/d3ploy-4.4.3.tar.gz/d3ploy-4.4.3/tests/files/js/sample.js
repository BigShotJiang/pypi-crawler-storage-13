(function() {
  console.log("Hello!");
})();
