(function () {
  console.log("Hello!");
})();
