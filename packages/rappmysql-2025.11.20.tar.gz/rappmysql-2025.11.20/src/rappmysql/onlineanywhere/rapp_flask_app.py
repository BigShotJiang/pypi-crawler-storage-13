from datetime import datetime, date

import numpy as np
from flask import Flask, render_template, request, redirect, url_for, send_file, session
from flask_login import UserMixin, login_user, LoginManager, login_required, logout_user, current_user
import traceback
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import re
import os
import sys
import csv
import connect
import mysql_rm
import rappmysql
# import chelt_plan
# from chelt_plan import CheltuieliPlanificate
# from chelt_plan import DB_Connection as chelt_db_connection
from rappmysql.cheltuieli import chelt_plan
from rappmysql.cheltuieli.chelt_plan import CheltuieliPlanificate
from rappmysql.cheltuieli.chelt_plan import DB_Connection as chelt_db_connection

from rappmysql.masina.auto import Masina, AutoApp
from rappmysql.masina.auto import DB_Connection as auto_db_connection
# from auto import Masina, AutoApp
# from auto import DB_Connection as auto_db_connection
from rappmysql.mruser.myusers import Users
from rappmysql.mruser.myusers import DB_Connection as users_db_connection
# from myusers import Users
# from myusers import DB_Connection as users_db_connection

#from rappmysql.aeroclub.aeroclub import AeroclubSQL


app = Flask(__name__)
app.config["DEBUG"] = True
app.config['SECRET_KEY'] = "my super secret"
login_manager = LoginManager()
login_manager.init_app(app)

try:
    compName = os.getenv('COMPUTERNAME')
    if compName:
        ini_users = rappmysql.ini_users
        ini_chelt = rappmysql.ini_chelt
        ini_masina = rappmysql.ini_masina
        ini_aeroclub = rappmysql.ini_aeroclub
        report_dir = rappmysql.report_dir
except:
    ini_users = '/home/radum/mysite/static/wdb.ini'
    ini_masina = '/home/radum/mysite/static/ini_masina.ini'
    ini_chelt = '/home/radum/mysite/static/ini_chelt.ini'
    ini_aeroclub = '/home/radum/mysite/static/ini_aeroclub.ini'
    report = '/home/radum/mysite/static/report.csv'
    report_dir = '/home/radum/mysite/static'


@login_manager.user_loader
def load_user(user_id):
    print('Module: {}, Def: {}, Caller: {}'.format(__name__,
                                                   sys._getframe().f_code.co_name,
                                                   sys._getframe().f_back.f_code.co_name))
    try:
        try:
            mat = int(user_id)
        except:
            mat = int(re.findall("\[(.+?)\]", user_id)[0])
        matches = ('id', mat)
        users_db = users_db_connection(ini_users)
        name = users_db.users_table.returnCellsWhere('username', matches)[0]
        user = Users(user_name=name,
                     users_table=users_db.users_table,
                     user_apps_table=users_db.user_apps_table)
        return user
    except:
        print(30 * '*', str(traceback.format_exc()))
    finally:
        users_db.close_connection()


@app.route('/', methods=['GET', 'POST'])
def index():
    try:
        return render_template('index.html')
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)


@app.route("/login", methods=["GET", "POST"])
def login():
    try:
        users_db = users_db_connection(ini_users)
        if request.method == "POST":
            username = request.form['username']
            user = Users(user_name=username,
                         users_table=users_db.users_table,
                         user_apps_table=users_db.user_apps_table)

            if user.verify_password(request.form['password']):
                login_user(user)
                if current_user.admin:
                    return render_template('index.html')
                else:
                    auto_db = auto_db_connection(ini_masina)
                    if current_user.auto_app is None:
                        current_user.auto_app = AutoApp(
                            auto_db=auto_db.auto_db,
                            all_cars_table=auto_db.all_cars_table,
                            alimentari=auto_db.alimentari,
                            user_id=current_user.id)
                    return render_template('masina.html')
            else:
                return 'NOT LOGED IN'
        else:
            return render_template("login.html")
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    finally:
        users_db.close_connection()


@app.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    try:
        logout_user()
        return redirect(url_for('index'))
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)


@app.route('/register', methods=['GET', 'POST'])
def register():
    try:
        users_db = users_db_connection(ini_users)
        if request.method == 'POST':
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']
            cols = ('username', 'email', 'password')
            hash = generate_password_hash(password)
            vals = (username, email, hash)
            users_db.users_table.addNewRow(cols, vals)
            return render_template('index.html')
        else:
            return render_template('register.html')
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    finally:
       users_db.close_connection()


@app.route('/add_app/<unused_app>', methods=['GET', 'POST'])
def add_app(unused_app):
    try:
        current_user.add_application(unused_app)
        return redirect(url_for("index"))
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    # finally:
    #    users_db.close_connection()


###cheltuieli###################################################################################
@app.route('/cheltuieli', methods=['GET', 'POST'])
@login_required
def cheltuieli():
    try:
        chelt_db_conn = chelt_db_connection(ini_chelt)
        chelt_app = CheltuieliPlanificate(chelt_db=chelt_db_conn.chelt_db,
                                          chelt_plan=chelt_db_conn.chelt_plan,
                                          yearly_plan=chelt_db_conn.yearly_plan)
        dataFrom, dataBis = chelt_plan.default_interval()
        conto = 'all'
        if request.method == 'POST':
            month = request.form['month']
            year = int(request.form['year'])
            conto = request.form['conto']
            dataFrom = request.form['dataFrom']
            dataBis = request.form['dataBis']
            xdays = request.form['xdays']
            if month != 'interval':
                dataFrom, dataBis = chelt_plan.get_monthly_interval(month, year)
            elif month == 'interval' and xdays != '':
                dataFrom, dataBis = chelt_plan.default_interval()
                dataBis = chelt_plan.calculate_today_plus_x_days(int(xdays))
            elif month == 'interval' and (dataFrom == '' or dataBis == ''):
                dataFrom, dataBis = chelt_plan.default_interval()
            else:
                try:
                    dataFrom = datetime.strptime(dataFrom, "%Y-%m-%d")
                    dataBis = datetime.strptime(dataBis, "%Y-%m-%d")
                    print(dataFrom.date(), dataBis.date())
                except:
                    return render_template('cheltuieli.html', tot_val_of_expenses_income=str(traceback.format_exc()))
        try:
            if isinstance(dataFrom, datetime):
                chelt_app.prepareTablePlan(conto, dataFrom.date(), dataBis.date(), True)
            elif isinstance(dataFrom, date):
                chelt_app.prepareTablePlan(conto, dataFrom, dataBis, True)

            tableHead, table = chelt_plan.convert_to_display_table(chelt_app.tableHead,
                                                        chelt_app.expenses,
                                                        chelt_app.displayExpensesTableHead)

            return render_template('cheltuieli.html',
                                   expenses=table,
                                   expensestableHead=tableHead,
                                   tot_no_of_monthly_expenses=chelt_app.tot_no_of_monthly_expenses,
                                   tot_val_of_monthly_expenses=chelt_app.tot_val_of_monthly_expenses,
                                   tot_no_of_irregular_expenses=chelt_app.tot_no_of_irregular_expenses,
                                   tot_val_of_irregular_expenses=chelt_app.tot_val_of_irregular_expenses,
                                   tot_no_of_expenses=chelt_app.tot_no_of_expenses,
                                   tot_val_of_expenses=chelt_app.tot_val_of_expenses,
                                   summary_table=[''],
                                   tot_val_of_income='chelt_app.tot_val_of_income()',
                                   dataFrom=dataFrom,
                                   dataBis=dataBis
                                   )
        except:
            print(traceback.format_exc())
            return render_template('err.html', myerr=str(traceback.format_exc()))
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    finally:
        chelt_db_conn.close_connection()


@app.route('/add_one_time_transaction', methods=['GET', 'POST'])
@login_required
def add_cheltuieli():
    try:
        chelt_db_conn = chelt_db_connection(ini_chelt)
        chelt_app = CheltuieliPlanificate(chelt_db=chelt_db_conn.chelt_db,
                                          chelt_plan=chelt_db_conn.chelt_plan,
                                          yearly_plan=chelt_db_conn.yearly_plan)

        if request.method == 'GET':
            return render_template('addchelt.html')
        if request.method == 'POST':
            if "add_one_time_chelt" in request.form:
                name = request.form['name']
                value = request.form['value']
                myconto = request.form['myconto']
                pay_day = request.form['pay_day']
                pay_day = datetime.strptime(pay_day, "%Y-%m-%d")
                chelt_app.add_one_time_transactions(name, value, myconto, pay_day)
                return redirect(url_for('cheltuieli'))

    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    finally:
        chelt_db_conn.close_connection()


@app.route('/all_chelt_planned', methods=['GET', 'POST'])
@login_required
def all_chelt_planned():
    try:
        chelt_db_conn = chelt_db_connection(ini_chelt)
        chelt_app = CheltuieliPlanificate(chelt_db=chelt_db_conn.chelt_db,
                                          chelt_plan=chelt_db_conn.chelt_plan,
                                          yearly_plan=chelt_db_conn.yearly_plan)
        if request.method == 'GET':
            table = chelt_app.all_planned_values
            return render_template('expenses.html', table=table)
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    finally:
        chelt_db_conn.close_connection()


@app.route('/edit_cheltuieli/<id_row>', methods=['GET', 'POST'])
@login_required
def edit_cheltuieli(id_row):
    try:
        chelt_db_conn = chelt_db_connection(ini_chelt)
        chelt_app = CheltuieliPlanificate(chelt_db=chelt_db_conn.chelt_db,
                                          chelt_plan=chelt_db_conn.chelt_plan,
                                          yearly_plan=chelt_db_conn.yearly_plan)
        if request.method == 'GET':
            if id_row == 'new':
                row = id_row
            else:
                match = ('id', int(id_row))
                row = chelt_app.chelt_plan.returnRowsWhere(match)[0]
            return render_template('edit_cheltuieli.html', id_row=id_row,
                                   table_head=chelt_app.chelt_plan.columnsProperties, row_vals=row)
        if request.method == 'POST':
            if "copy_as" in request.form:
                id_users = request.form['id_users']
                category = request.form['category']
                name = request.form['name']
                value = request.form['value']
                myconto = request.form['myconto']
                freq = request.form['freq']
                pay_day = request.form['pay_day']
                valid_from = request.form['valid_from']
                valid_to = request.form['valid_to']
                identification = request.form['identification']
                auto_ext = request.form.get('auto_ext', 0)
                cancel_auto_ext = request.form.get('cancel_auto_ext', 'False')

                if cancel_auto_ext == 'True':
                    cancel_auto_ext = int(id_row)
                elif cancel_auto_ext == 'False':
                    cancel_auto_ext = False
                # print(';;;', type(cancel_auto_ext), cancel_auto_ext)
                # return str(cancel_auto_ext)
                # if auto_ext == 'on':
                #     print("Checkbox is checked")
                # else:
                #     # Checkbox was not checked
                #     print("Checkbox is not checked")
                #
                # # post_pay = request.form['post_pay']
                # print('++{}++++'.format(valid_to), type(valid_to))
                # if valid_to == '':
                #     print('BINGOOOOOO')
                # return str(auto_ext)
                new_row_id = chelt_app.add_transactions(category, name, value, myconto, freq, pay_day, valid_from, valid_to, int(auto_ext), identification, cancel_auto_ext)
                table = chelt_app.all_planned_values
                return render_template('expenses.html', table=table)
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    finally:
        chelt_db_conn.close_connection()


@app.route('/delete_transaction/<id_row>', methods=['GET', 'POST'])
def delete_transaction(id_row):
    try:
        chelt_db_conn = chelt_db_connection(ini_chelt)
        chelt_app = CheltuieliPlanificate(chelt_db=chelt_db_conn.chelt_db,
                                          chelt_plan=chelt_db_conn.chelt_plan,
                                          yearly_plan=chelt_db_conn.yearly_plan)
        chelt_app.delete_transaction(id_row)
        table = chelt_app.all_planned_values
        return render_template('expenses.html', table=table)
    except:
        myerr = 'a_{}_a definition {}\n{}'.format(current_user.id, sys._getframe().f_code.co_name,
                                                  str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    finally:
        chelt_db_conn.close_connection()


###masina###################################################################################
@app.route('/masina', methods=['GET', 'POST'])
@login_required
def masina():
    # print('Module: {}, Def: {}, Caller: {}'.format(__name__,
    #                                                sys._getframe().f_code.co_name,
    #                                                sys._getframe().f_back.f_code.co_name))
    # print(20 * '%', request.method)
    try:
        auto_db = auto_db_connection(ini_masina)
        if current_user.auto_app is None:
            current_user.auto_app = AutoApp(
                auto_db=auto_db.auto_db,
                all_cars_table=auto_db.all_cars_table,
                alimentari=auto_db.alimentari,
                user_id=current_user.id)
        if request.method == 'GET':
            return render_template('masina.html')
        elif request.method == 'POST':
            if 'backup_profile' in request.form:
                current_user.auto_app.export_profile(export_files=True)
                return render_template('masina.html')
            elif 'import_backup' in request.form:
                current_user.auto_app.import_profile(import_files=True)
                return render_template('masina.html')
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name,
                                           str(traceback.format_exc()))
        return render_template('err.html', myerr=myerr)
    finally:
        auto_db.close_connection()


@app.route('/summary/<id_car>/<table_name>', methods=['GET', 'POST'])
@login_required
def car_summary(id_car, table_name):
    try:
        auto_db = auto_db_connection(ini_masina)
        if current_user.auto_app is None:
            current_user.auto_app = AutoApp(
                auto_db=auto_db.auto_db,
                all_cars_table=auto_db.all_cars_table,
                alimentari=auto_db.alimentari,
                user_id=current_user.id)

        session['id_car'] = id_car
        if request.method == 'GET':
            # app_masina = Masina(ini_masina, current_user.id, id_car)
            app_masina = Masina(auto_db=auto_db.auto_db,
                                all_cars_table=auto_db.all_cars_table,
                                alimentari=auto_db.alimentari,
                                id_users=current_user.id,
                                id_car=id_car)

            if app_masina.table_totals is not None:
                tabel_totals = []
                for row in app_masina.table_totals:
                    tabel_totals.append(row)
            else:
                tabel_totals = None
            return render_template('car_summary.html',
                                   table_name=table_name,
                                   tabel_alimentari=app_masina.table_alimentari,
                                   tabel_totals=tabel_totals,
                                   last_records=app_masina.last_records_display_table(),
                                   long_term_consumption=app_masina.long_term_consumption
                                   )
        elif request.method == 'POST':
            if 'export_detail_table_as_sql' in request.form:
                with_files = request.form.get('with_files', 'False')
                # print('ÖÖÖÖÖwith_files', with_files, type(with_files))
                if not with_files:
                    output_sql_file = current_user.auto_app.export_car_sql(int(id_car))
                else:
                    output_sql_file = current_user.auto_app.export_car_sql(int(id_car), export_files=True)
                # # return text_to_write
                # pth_to_sql = os.path.join(report_dir, 'aaa.sql')
                # # if os.path.exists(pth_to_sql):
                # #     os.remove(pth_to_sql)
                # # with open(pth_to_sql, 'w') as file:
                # #     for row in text_to_write:
                # #         file.write(row)
                return output_sql_file
            # elif 'export_detail_table_with_files' in request.form:
            #
            #     return output_sql_file
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html', myerr=myerr)
    finally:
        auto_db.close_connection()


@app.route('/addalim/<table_name>', methods=['GET', 'POST'])
def addalim(table_name):
    try:
        auto_db = auto_db_connection(ini_masina)
        if current_user.auto_app is None:
            current_user.auto_app = AutoApp(
                auto_db=auto_db.auto_db,
                all_cars_table=auto_db.all_cars_table,
                alimentari=auto_db.alimentari,
                user_id=current_user.id)

        app_masina = Masina(auto_db=auto_db.auto_db,
                            all_cars_table=auto_db.all_cars_table,
                            alimentari=auto_db.alimentari,
                            id_users=current_user.id,
                            id_car=session['id_car'])
        if request.method == 'GET':
            return render_template('addalim.html',
                                   table_name=table_name,
                                   types_of_costs=app_masina.types_of_costs)
        if request.method == 'POST':
            if "add_alim" in request.form:
                date = request.form['data']
                alim_type = request.form['type']
                eprov = request.form['eprov']
                brutto = request.form['brutto']
                amount = request.form['amount']
                km = request.form['km']
                if alim_type == 'electric':
                    ppu = current_user.auto_app.get_ppu_electric_provider(eprov)
                    brutto = float(amount) * float(ppu)

                app_masina.insert_new_alim(current_id_users=current_user.id, id_all_cars=session['id_car'], data=date,
                                           alim_type=alim_type, brutto=brutto, amount=amount, refuel=None, other=None,
                                           recharges=None, km=km, comment=None, file=None, provider=eprov)
                return redirect(url_for('car_summary', id_car=session['id_car'], table_name=table_name))
    except:
        myerr = 'a_{}_a definition {}\n{}'.format(current_user.id, sys._getframe().f_code.co_name,
                                                  str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    finally:
        auto_db.close_connection()


@app.route('/deleterow/<table_name>/<index>', methods=['GET', 'POST'])
def deleterow(table_name, index):
    try:
        auto_db = auto_db_connection(ini_masina)
        app_masina = Masina(auto_db=auto_db.auto_db,
                            all_cars_table=auto_db.all_cars_table,
                            alimentari=auto_db.alimentari,
                            id_users=current_user.id,
                            id_car=session['id_car'])
        app_masina.delete_row(index)
        return redirect(url_for('consumption_details', table_name=table_name))
    except:
        myerr = 'a_{}_a definition {}\n{}'.format(current_user.id, sys._getframe().f_code.co_name,
                                                  str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    finally:
        auto_db.close_connection()


@app.route('/details/<table_name>', methods=['GET', 'POST'])
def consumption_details(table_name):
    try:
        auto_db = auto_db_connection(ini_masina)
        app_masina = Masina(auto_db=auto_db.auto_db,
                            all_cars_table=auto_db.all_cars_table,
                            alimentari=auto_db.alimentari,
                            id_users=current_user.id,
                            id_car=session['id_car'])
        if current_user.auto_app is None:
            current_user.auto_app = AutoApp(
                auto_db=auto_db.auto_db,
                all_cars_table=auto_db.all_cars_table,
                alimentari=auto_db.alimentari,
                user_id=current_user.id)

        if request.method == 'GET':
            dataFrom, dataBis = app_masina.default_interval
            alim_type = None
            alimentari = app_masina.get_alimentari_for_interval_type(dataFrom, dataBis, alim_type)
            return render_template('car_detailed.html',
                                   table_name=table_name,
                                   id_car=session['id_car'],
                                   userDetails=alimentari,
                                   types_of_costs=app_masina.types_of_costs,
                                   dataFrom=dataFrom.date(),
                                   dataBis=dataBis.date(),
                                   )
        elif request.method == 'POST':
            if 'export_detail_table_as_sql' in request.form:
                car_id = current_user.auto_app.get_id_all_cars(table_name)
                output_sql_file = current_user.auto_app.export_car_sql(car_id)
                return output_sql_file
            elif 'upload_file' in request.form:
                file = request.files['myfile']
                filename = secure_filename(file.filename)
                file.save(filename)
                current_user.auto_app.import_car_with_files(filename)
                return redirect(url_for('consumption_details', table_name=table_name))
            elif "filter" in request.form:
                month = request.form['month']
                year = int(request.form['year'])
                alim_type = request.form['type']
                if alim_type == 'all':
                    alim_type = None
                dataFrom = request.form['dataFrom']
                dataBis = request.form['dataBis']

                if month != 'interval':
                    dataFrom, dataBis = app_masina.get_monthly_interval(month, year)
                elif month == 'interval' and (dataFrom == '' or dataBis == ''):
                    dataFrom, dataBis = app_masina.default_interval
                else:
                    try:
                        dataFrom = datetime.strptime(dataFrom, "%Y-%m-%d")
                        dataBis = datetime.strptime(dataBis, "%Y-%m-%d")
                    except:
                        print(traceback.format_exc())
                alimentari = app_masina.get_alimentari_for_interval_type(dataFrom, dataBis, alim_type)
                return render_template('car_detailed.html',
                                       table_name=table_name,
                                       userDetails=alimentari,
                                       types_of_costs=app_masina.types_of_costs,
                                       dataFrom=dataFrom.date(),
                                       dataBis=dataBis.date(),
                                       )
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html', myerr=myerr)
    finally:
        auto_db.close_connection()


@app.route('/add_masina', methods=['GET', 'POST'])
def add_masina():
    try:
        auto_db = auto_db_connection(ini_masina)
        if current_user.auto_app is None:
            current_user.auto_app = AutoApp(
                auto_db=auto_db.auto_db,
                all_cars_table=auto_db.all_cars_table,
                alimentari=auto_db.alimentari,
                user_id=current_user.id)

        if request.method == 'POST':
            if 'create_user_car' in request.form:
                brand = request.form['brand']
                model = request.form['model']
                car_type = request.form['car_type']
                current_user.auto_app.add_car(brand, model, car_type)
                return render_template('masina.html')
            elif 'import_car_sql' in request.form:
                file = request.files['myfile']
                filename = secure_filename(file.filename)
                file.save(filename)
                current_user.auto_app.import_car_with_files(filename)
                return render_template('masina.html')
            elif 'import_car_with_files' in request.form:
                file = request.files['zip_file']
                filename = secure_filename(file.filename)
                fl = os.path.join(rappmysql.report_dir, filename)
                file.save(fl)
                # with open(fl) as f:
                #     file_content = f.read()
                #     print(file_content)
                current_user.import_car_with_files(fl, import_files=True)
                os.remove(fl)
                return redirect(url_for('index'))
            elif 'import_car_without_files' in request.form:
                file = request.files['zip_file']
                filename = secure_filename(file.filename)
                fl = os.path.join(rappmysql.report_dir, filename)
                file.save(fl)
                # with open(fl) as f:
                #     file_content = f.read()
                #     print(file_content)
                current_user.import_car_with_files(fl)
                os.remove(fl)
                return redirect(url_for('index'))
            return redirect(url_for('index'))
        # return render_template('addcar.html')
        elif request.method == 'GET':
            all_cars_brands = current_user.auto_app.all_cars_array.tolist()
            return render_template('addcar.html', all_cars_brands=all_cars_brands)
    except:
        myerr = 'a_{}_a definition\n{}'.format(sys._getframe().f_code.co_name,
                                                  str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    finally:
        auto_db.close_connection()


# @app.route('/backup_profile', methods=['GET', 'POST'])
# def backup_profile():
#     try:
#         auto_db = auto_db_connection(ini_masina)
#         if current_user.auto_app is None:
#             current_user.auto_app = AutoApp(
#                 auto_db=auto_db.auto_db,
#                 all_cars_table=auto_db.all_cars_table,
#                 alimentari=auto_db.alimentari,
#                 user_id=current_user.id)
#         if request.method == 'GET':
#             # if 'backup_profile' in request.form:
#             current_user.auto_app.export_profile(export_files=True)
#             return render_template('masina.html')
#         # return str(request.method)
#         # if request.method == 'POST':
#         #     if 'create_user_car' in request.form:
#         #         brand = request.form['brand']
#         #         model = request.form['model']
#         #         car_type = request.form['car_type']
#         #         current_user.auto_app.add_car(brand, model, car_type)
#         #         return render_template('masina.html')
#         #     elif 'import_car_sql' in request.form:
#         #         file = request.files['myfile']
#         #         filename = secure_filename(file.filename)
#         #         file.save(filename)
#         #         current_user.auto_app.import_car_with_files(filename)
#         #         return render_template('masina.html')
#         #     elif 'import_car_with_files' in request.form:
#         #         file = request.files['zip_file']
#         #         filename = secure_filename(file.filename)
#         #         fl = os.path.join(rappmysql.report_dir, filename)
#         #         file.save(fl)
#         #         # with open(fl) as f:
#         #         #     file_content = f.read()
#         #         #     print(file_content)
#         #         current_user.import_car_with_files(fl, import_files=True)
#         #         os.remove(fl)
#         #         return redirect(url_for('index'))
#         #     elif 'import_car_without_files' in request.form:
#         #         file = request.files['zip_file']
#         #         filename = secure_filename(file.filename)
#         #         fl = os.path.join(rappmysql.report_dir, filename)
#         #         file.save(fl)
#         #         # with open(fl) as f:
#         #         #     file_content = f.read()
#         #         #     print(file_content)
#         #         current_user.import_car_with_files(fl)
#         #         os.remove(fl)
#         #         return redirect(url_for('index'))
#         #     return redirect(url_for('index'))
#         # # return render_template('addcar.html')
#     except:
#         myerr = 'a_{}_a definition\n{}'.format(sys._getframe().f_code.co_name,
#                                                   str(traceback.format_exc()))
#         return render_template('err.html',
#                                myerr=myerr)
#     finally:
#         auto_db.close_connection()


@app.route('/upload_file/<table_name>/<row_id>', methods=['GET', 'POST'])
def upload_file_to_row(table_name, row_id):
    # print('Module: {}, Def: {}, Caller: {}'.format(__name__, sys._getframe().f_code.co_name,
    #                                                sys._getframe().f_back.f_code.co_name))
    try:
        auto_db = auto_db_connection(ini_masina)
        app_masina = Masina(auto_db=auto_db.auto_db,
                            all_cars_table=auto_db.all_cars_table,
                            alimentari=auto_db.alimentari,
                            id_users=current_user.id,
                            id_car=session['id_car'])

        file = request.files['myfile']
        filename = secure_filename(file.filename)
        fl = os.path.join(rappmysql.report_dir, filename)
        file.save(fl)
        app_masina.upload_file(fl, row_id)
        return redirect(url_for('consumption_details', table_name=table_name))
    except:
        myerr = 'definition {}\n{}'.format(sys._getframe().f_code.co_name, str(traceback.format_exc()))
        return render_template('err.html', myerr=myerr)
    finally:
        auto_db.close_connection()


@app.route('/delete_masina/<id_car>/<table_name>', methods=['GET', 'POST'])
def delete_masina(id_car, table_name):
    try:
        auto_db = auto_db_connection(ini_masina)
        if current_user.auto_app is None:
            current_user.auto_app = AutoApp(
                auto_db=auto_db.auto_db,
                all_cars_table=auto_db.all_cars_table,
                alimentari=auto_db.alimentari,
                user_id=current_user.id)
        current_user.auto_app.delete_auto(table_name)
        return redirect(url_for('masina'))
    except:
        myerr = 'a_{}_a definition {}\n{}'.format(current_user.id, sys._getframe().f_code.co_name,
                                                  str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)
    finally:
        auto_db.close_connection()

########################################################################

@app.route('/aeroclub', methods=['GET', 'POST'])
def aeroclub():
    try:
        app_aeroclub = AeroclubSQL(ini_aeroclub)
        print('app_masina.total_unpaid_flights', app_aeroclub.total_unpaid_flights)
        if request.method == 'POST':
            return redirect(url_for('index'))
        return render_template('aeroclub.html',
                               total_unpaid_flights=app_aeroclub.total_unpaid_flights,
                               flight_time_this_year=app_aeroclub.flight_time_this_year,
                               total_flight_time=app_aeroclub.total_flight_time
                               )
    except:
        myerr = 'a_{}_a definition {}\n{}'.format(current_user.id, sys._getframe().f_code.co_name,
                                                  str(traceback.format_exc()))
        return render_template('err.html',
                               myerr=myerr)



if __name__ == "__main__":
    app.run()

