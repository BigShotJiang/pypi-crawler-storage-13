document.getElementById('demo').innerHTML = 'HHHHHHHH'

function sortTable(n) {
  var table = document.getElementById("myTable1");
  var switching = true;
  var dir = "asc";
  var switchcount = 0;

  while (switching) {
    switching = false;
    var rows = table.rows;

    for (var i = 1; i < rows.length - 1; i++) {
      var shouldSwitch = false;

      var x = rows[i].getElementsByTagName("TD")[n].innerText.trim();
      var y = rows[i + 1].getElementsByTagName("TD")[n].innerText.trim();

      // Try to convert to numbers
      let xNum = parseFloat(x);
      let yNum = parseFloat(y);
      let numeric = !isNaN(xNum) && !isNaN(yNum);

      // Try to convert to dates
      let xDate = parseDate(x);
      let yDate = parseDate(y);
      let bothDates = xDate !== null && yDate !== null;

      let comparison = 0;

      if (numeric) {
        comparison = xNum - yNum;
      }
      else if (bothDates) {
        comparison = xDate - yDate;
      }
      else {
        comparison = x.toLowerCase().localeCompare(y.toLowerCase());
      }

      if (dir === "asc" && comparison > 0) {
        shouldSwitch = true;
        break;
      }
      else if (dir === "desc" && comparison < 0) {
        shouldSwitch = true;
        break;
      }
    }

    if (shouldSwitch) {
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
      switchcount++;
    } else {
      if (switchcount === 0 && dir === "asc") {
        dir = "desc";
        switching = true;
      }
    }
  }
}

/* ===============================
   DATE PARSER (auto-detect format)
   =============================== */
function parseDate(value) {
  if (!value) return null;

  // YYYY-MM-DD or YYYY/MM/DD
  if (/^\d{4}[-\/]\d{2}[-\/]\d{2}$/.test(value)) {
    return new Date(value);
  }

  // DD.MM.YYYY
  if (/^\d{2}\.\d{2}\.\d{4}$/.test(value)) {
    let [d, m, y] = value.split(".");
    return new Date(`${y}-${m}-${d}`);
  }

  // DD/MM/YYYY or MM/DD/YYYY → ambiguous, assume DD/MM/YYYY
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(value)) {
    let [a, b, y] = value.split("/");
    // you can switch if your data is US format:
    return new Date(`${y}-${b}-${a}`);
  }

  return null; // not a date
}


function sortMasinaTable(n) {
  var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
  table = document.getElementById("all_planned_values");
  switching = true;
  //Set the sorting direction to ascending:
  dir = "asc";
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[n];
      y = rows[i + 1].getElementsByTagName("TD")[n];
      /*check if the two rows should switch place,
      based on the direction, asc or desc:*/
      if (dir == "asc") {
        if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch= true;
          break;
        }
      } else if (dir == "desc") {
        if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch = true;
          break;
        }
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
      //Each time a switch is done, increase this count by 1:
      switchcount ++;
    } else {
      /*If no switching has been done AND the direction is "asc",
      set the direction to "desc" and run the while loop again.*/
      if (switchcount == 0 && dir == "asc") {
        dir = "desc";
        switching = true;
      }
    }
  }
}
