# Webis HTML - 智能网页内容提取工具

![Python Version](https://img.shields.io/badge/Python-3.8+-blue)
![Package Version](https://img.shields.io/badge/Version-1.0.6-green)
![License](https://img.shields.io/badge/License-MIT-yellow)

**Webis HTML** 是一个现代化的智能网页内容提取工具，使用 AI 技术自动识别和提取网页中的有价值信息，过滤噪声内容，为知识库构建、数据分析和AI训练提供高质量的文本数据。

## ✨ 特性

- 🚀 **一键提取**: 单个函数调用完成HTML内容提取
- 🔄 **批量处理**: 支持目录级别的批量HTML文件处理  
- 🌐 **URL支持**: 直接从网络URL提取内容
- 🤖 **AI优化**: 集成DeepSeek API进行智能内容过滤
- ⚡ **异步处理**: 高性能异步API调用，支持并发处理
- 🖥️ **多种接口**: 支持Python API、命令行和Web界面
- 📦 **标准包**: 符合PyPI标准，易于安装和分发

## 📦 安装

### 环境要求
- Python 3.8+
- 推荐使用conda进行环境管理

### 快速安装

```bash
# 创建conda环境
conda create -n webis_html python=3.10 -y
conda activate webis_html

# 安装包
pip install -e .
```

### 验证安装

```bash
# 检查CLI命令
webis-html --help

# 检查Python导入
python -c "import webis_html; print('✅ 安装成功!')"
```

## 🚀 快速开始

### 1. 最简单的使用方式

```python
import webis_html

# 从HTML内容提取
html_content = "<html><body><h1>标题</h1><p>内容</p></body></html>"
result = webis_html.extract_from_html(html_content)

# 批量处理目录
result = webis_html.extract_from_directory("./html_files", "./output")

# 从URL提取
result = webis_html.extract_from_url("https://example.com")
```

### 2. 命令行使用

```bash
# 批量处理HTML文件
webis-html extract --input ./html_files --output ./results

# 启动Web界面
webis-html gui

# 查看版本
webis-html version
```

## 📖 详细使用说明

### Python API

#### 便捷函数（推荐）

```python
import webis_html

# 1. 处理HTML内容
html_content = """
<html>
<body>
    <h1>重要标题</h1>
    <p>有价值的内容</p>
    <div class="ad">广告内容</div>
</body>
</html>
"""

result = webis_html.extract_from_html(
    html_content, 
    api_key="your-deepseek-key",  # 可选，用于AI优化
    output_dir="./output"
)

if result['success']:
    print(f"提取成功！共{len(result['results'])}个文本片段")
    for item in result['results']:
        print(f"文件: {item['filename']}")
        print(f"内容: {item['content'][:100]}...")

# 2. 批量处理目录
result = webis_html.extract_from_directory(
    input_dir="./html_files",
    output_dir="./output",
    api_key="your-deepseek-key"  # 可选
)

# 3. 从URL提取
result = webis_html.extract_from_url(
    "https://example.com",
    api_key="your-deepseek-key",
    output_dir="./output"
)
```

#### 高级自定义

```python
import webis_html

# 使用核心组件自定义处理流程
processor = webis_html.HtmlProcessor(input_dir, output_dir)
processor.process_html_folder()

# 生成数据集
webis_html.process_json_folder(content_dir, dataset_file)

# 模型预测
webis_html.process_predictions(dataset_file, results_file)

# 恢复文本
webis_html.restore_text_from_json(results_file, output_dir)
```

### 命令行界面

#### 基本命令

```bash
# 提取HTML内容
webis-html extract --input ./html_files --output ./results --api-key YOUR_KEY

# 详细输出
webis-html extract --input ./html_files --verbose

# 启动Web界面
webis-html gui --web-port 9000 --gui-port 8001

# 测试API连接
webis-html check-api --api-key YOUR_KEY

# 查看版本信息
webis-html version
```

#### 完整示例

```bash
# 处理samples目录中的HTML文件
webis-html extract \
  --input ./samples/input_html \
  --output ./samples/output \
  --api-key sk-your-deepseek-api-key \
  --verbose
```

### Web界面

启动Web界面进行可视化操作：

```bash
# 启动GUI（会自动启动Web API服务器）
webis-html gui

# 自定义端口
webis-html gui --web-port 9000 --gui-port 8001 --api-key YOUR_KEY
```

然后在浏览器中访问 `http://localhost:8001`

## 🔑 API密钥配置

支持多种API密钥配置方式：

### 1. 配置文件（推荐）

创建 `config/api_keys.json`：
```json
{
    "deepseek_api_key": "sk-your-deepseek-api-key-here"
}
```

### 2. 环境变量

```bash
export DEEPSEEK_API_KEY="sk-your-deepseek-api-key-here"
# 或
export LLM_PREDICTOR_API_KEY="sk-your-deepseek-api-key-here"
```

### 3. 命令行参数

```bash
webis-html extract --input ./html --api-key sk-your-key
```

### 4. Python代码

```python
result = webis_html.extract_from_html(html_content, api_key="sk-your-key")
```

## 📁 输出结构

所有处理方法都会生成统一的输出结构：

```
output/
├── content_output/          # HTML预处理结果
│   └── *.json              # 结构化内容数据
├── dataset/                # 数据集文件
│   ├── extra_datasets.json # 训练数据集
│   └── pred_results.json   # 预测结果
├── predicted_texts/        # 基础提取结果
│   └── *.txt              # 提取的文本文件
└── filtered_texts/         # AI优化结果（如果使用DeepSeek API）
    └── *.txt              # 过滤后的高质量文本
```

## 🛠️ 开发和自定义

### 项目结构

```
webis_html/
├── __init__.py             # 主包入口，便捷函数
├── cli/                    # 命令行界面
│   ├── cli.py             # CLI实现
│   └── __main__.py        # CLI入口点
├── core/                   # 核心处理模块
│   ├── html_processor.py  # HTML预处理
│   ├── dataset_processor.py # 数据集生成
│   ├── llm_predictor.py   # AI预测
│   ├── content_restorer.py # 内容恢复
│   └── llm_clean.py       # DeepSeek过滤
├── server/                 # Web服务器
│   ├── __init__.py        # FastAPI应用
│   ├── api/               # API路由
│   └── services/          # 服务组件
├── utils/                  # 工具模块
├── config/                 # 配置文件
├── frontend/              # Web界面
└── scripts/               # 启动脚本
```

### 扩展开发

```python
# 创建自定义处理器
from webis_html.core import HtmlProcessor

class CustomProcessor(HtmlProcessor):
    def custom_process(self, html_content):
        # 自定义处理逻辑
        pass

# 创建Web服务
from webis_html import create_app
import uvicorn

app = create_app()
uvicorn.run(app, host="0.0.0.0", port=8000)
```

## 📊 性能特性

- **异步处理**: 使用httpx和asyncio实现高性能并发
- **智能缓存**: 自动缓存API密钥和配置
- **批量优化**: 针对大量文件的批处理优化
- **内存管理**: 流式处理大文件，避免内存溢出

## 🤝 贡献

欢迎贡献代码！请遵循以下步骤：

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🆘 支持

- 📧 Email: example@example.com
- 🐛 Issues: [GitHub Issues](https://github.com/TheBinKing/Webis/issues)
- 📖 文档: [项目文档](https://webis.tech)

## 🎯 使用场景

- **知识库构建**: 从网页批量提取结构化知识
- **数据挖掘**: 清洗网页数据用于分析
- **AI训练**: 为大语言模型准备高质量训练数据
- **内容迁移**: 网站内容迁移和整理
- **信息提取**: 从HTML中提取关键信息

---

**开始使用 Webis HTML，让网页内容提取变得简单高效！** 🚀