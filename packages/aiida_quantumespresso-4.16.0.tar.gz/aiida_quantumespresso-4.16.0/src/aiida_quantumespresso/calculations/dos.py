"""`CalcJob` implementation for the dos.x code of Quantum ESPRESSO."""

from aiida import orm

from aiida_quantumespresso.calculations.namelists import NamelistsCalculation


class DosCalculation(NamelistsCalculation):
    """`CalcJob` implementation for the dos.x code of Quantum ESPRESSO."""

    _DOS_FILENAME = 'aiida.dos'
    _default_namelists = ['DOS']
    _blocked_keywords = [
        ('DOS', 'fildos', _DOS_FILENAME),
        ('DOS', 'outdir', NamelistsCalculation._OUTPUT_SUBFOLDER),  # noqa: SLF001
        ('DOS', 'prefix', NamelistsCalculation._PREFIX),  # noqa: SLF001
    ]
    _internal_retrieve_list = [_DOS_FILENAME]
    _default_parser = 'quantumespresso.dos'

    @classmethod
    def define(cls, spec):
        """Define the process specification."""

        super().define(spec)
        spec.input('parent_folder', valid_type=(orm.RemoteData, orm.FolderData), required=True)
        spec.output('output_parameters', valid_type=orm.Dict)
        spec.output('output_dos', valid_type=orm.XyData)
        spec.default_output_node = 'output_parameters'
        spec.exit_code(
            330, 'ERROR_READING_DOS_FILE', message='The dos file could not be read from the retrieved folder.'
        )
