import argparse
import sys
import os
from setuptools import setup
#import json

with open("README", 'r') as f:
    long_description = f.read()

parser = argparse.ArgumentParser()
parser.add_argument('--configs', type=str,nargs='*', required = False,default= ' ')
parser.add_argument('--options', type=str,nargs='*', required = False,default= ' ')
parser.add_argument('--cores', type=str, default= '1', required = False)
parser.add_argument('--withQE', type=bool,default = False, required = False)
parser.add_argument('install', type=None)
parser.add_argument('--installed', type=bool,default = False, required = False)
parser.add_argument('--Release', type=bool, default = False, required = False)
parser.add_argument('--pytype', type=str, default ='', required = False)
parser.add_argument('--version', type=str, default ='5.9s', required = False)



args = parser.parse_args()
print(args.configs)
cmd = None
ver = args.version
if (ver == '5.9s'):
    EPW_ver = 5.9
    QE_ver = 7.4

else:

    EPW_ver = 5.9 + (float(ver)-5.9)
    QE_ver = 7.4 + (float(ver)-5.9)

if (args.withQE):
    print('Building with QE')
    os.system('mkdir build')
    os.chdir('build')
    if (args.installed == False):
        os.system(f'wget https://gitlab.com/epw/q-e/-/archive/EPW-{ver}/q-e-EPW-{ver}.tar.gz && tar xfz q-e-EPW-{ver}.tar.gz')
    os.chdir(f'q-e-EPW-{ver}')
    configs = ' '
    for i in range(len(args.configs)):
        configs += f'--{args.configs[i]} '
    if (args.installed == False):
        os.system(f'./configure {configs}')
        os.system(f'make epw -j {args.cores}')
    cmd = os.getcwd()
    os.chdir('../../')

with open('EPWpy/default/code_loc.py','w') as f:
    if (cmd == None):
        f.write(f'code_set = {cmd}')
    else:
        f.write(f'code_set = \'{cmd}/bin\'')
        f.write('\n')
        f.write(f'QE_version = \'{QE_ver}\'')
        f.write('\n')
        f.write(f'EPW_version = \'{EPW_ver}\'')

configs = ' '
for conf in args.options:
    configs += f'{conf}'

if (args.Release):

    os.system(f'{sys.executable} setup_EPWpy.py sdist bdist_wheel')

elif (args.pytype != ''):
    os.system(f'{sys.executable}{args.pytype} setup_EPWpy.py install {configs}')

else:
    os.system(f'{sys.executable} setup_EPWpy.py install {configs}')
