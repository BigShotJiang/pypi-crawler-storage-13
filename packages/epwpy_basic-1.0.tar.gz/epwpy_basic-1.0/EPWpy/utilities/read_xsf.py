import numpy as np


def read_xsf(filein=None):
    """
    This function reads the xsf files
    """
    if filein is None:
        print('No xsf files provided')
    i = 0
    data = []
    read_lattice = False
    read_
    with open(filein,'r') as f:
        for line in f:
            if (i ==1):
                try:
                    nr1x, nr2x, nr3x, nr1, nr2, nr3, nat, ntyp = np.array(line.split()).astype(int)
                    ignore = nat+ntyp+6
                except ValueError:
                    continue
            if (i > 1):
                if (' PRIMCOORD' in line):
                    pass                 
                        
            if (i > 6):
                if (i> ignore):
                    for d in line.split():
                        data.append(float(d))
 
            i +=1
    data = np.array(data).reshape(nr1x,nr2x,nr3x)
    return(data)

if __name__=="__main__":
    """
    Reads xsf file
    """
    data = read_xsf('hBN/pp/total_potential')

    print(np.shape(data))
    data = read_xsf('difference.xsf')

    print(np.shape(data))

