import numpy as np
from EPWpy.utilities.Band import extract_band_scf
from EPWpy.utilities.k_gen import k_mesh
from read_QE_xml import QE_XML
#import matplotlib.pyplot as plt

def recoproc_lat_cart(lattice_vectors, unit = 'm'):
    bohr2m = 5.29177E-11
 
    if (unit == 'm'):
        factor = bohr2m
    a1, a2, a3 = lattice_vectors * factor
    # Reciprocal lattice vectors
    V = np.dot(a1, np.cross(a2, a3))
    b1 = 2*np.pi * np.cross(a2, a3) / V
    b2 = 2*np.pi * np.cross(a3, a1) / V
    b3 = 2*np.pi * np.cross(a1, a2) / V
    #print(b1,b2,b3)

    B = np.vstack([b1, b2, b3])
    return(B)


def kpoints_2pi_alat_to_fractional(k_cart, lattice_vectors, alat):
    """
    Convert k-points in 2pi/alat units to fractional coordinates along lattice vectors.

    Parameters
    ----------
    k_cart : Nx3 array
        k-points in Cartesian 2pi/alat units
    lattice_vectors : 3x3 array
        Lattice vectors (rows) in real-space units (Å or Bohr)
    alat : float
        Lattice parameter (same units as lattice_vectors)

    Returns
    -------
    k_frac : Nx3 array
        Fractional k-points
    """
    # Scale k-points to 1/length units
    k_scaled = k_cart  # now in 1/length units
    a1, a2, a3 = lattice_vectors / alat
    print(lattice_vectors / alat)
    # Reciprocal lattice vectors
    V = np.dot(a1, np.cross(a2, a3))
    b1 = 2*np.pi * np.cross(a2, a3) / V
    b2 = 2*np.pi * np.cross(a3, a1) / V
    b3 = 2*np.pi * np.cross(a1, a2) / V
    #print(b1,b2,b3)

    B = np.vstack([b1, b2, b3]) / (2*np.pi)   #.T
    # Fractional coordinates
    print(B)
    k_frac = k_scaled @ np.linalg.inv(B)   #np.linalg.solve(B, k_scaled.T).T
    return k_frac

def cartesian_to_crystal_kpoints(k_cart, lattice_vectors):
    """
    Convert Cartesian k-points to fractional (crystal) coordinates.

    Parameters
    ----------
    k_cart : array_like
        Nx3 array of k-points in Cartesian coordinates (Å^-1 or Bohr^-1)
    lattice_vectors : array_like
        3x3 lattice vectors (in same units as k_cart)
        Each row is a lattice vector: a1, a2, a3

    Returns
    -------
    k_frac : Nx3 array
        k-points in crystal (fractional) coordinates
    """
    a1, a2, a3 = lattice_vectors
    # Reciprocal lattice
    V = np.dot(a1, np.cross(a2, a3))
    b1 = 2*np.pi * np.cross(a2, a3) / V
    b2 = 2*np.pi * np.cross(a3, a1) / V
    b3 = 2*np.pi * np.cross(a1, a2) / V
    B = np.vstack([b1, b2, b3]).T  # 3x3 reciprocal lattice matrix

    # Convert Cartesian k-points to fractional
    k_frac = np.linalg.solve(B, k_cart.T).T
    return k_frac


def fourier_fit(energies, kpoints, nmax=3, lambda_reg=1e-2, weights=None):
    """
    Smooth Fourier interpolation of DFT bands (BoltzTraP-like).

    Parameters
    ----------
    kpoints : ndarray, shape (Nk, 3)
        Fractional k-points (0-1 along lattice vectors)
    energies : ndarray, shape (Nk,) or (Nk, Nbands)
        Band energies
    nmax : int
        Maximum integer for G-vectors
    lambda_reg : float
        Smoothness regularization parameter
    weights : ndarray, shape (Nk,), optional
        Weights for k-points (higher = more important)

    Returns
    -------
    interp_func : callable
        Function that interpolates energy at any k-point
    coeffs : ndarray, shape (Nbands, nG)
        Fourier coefficients
    Gvecs : ndarray, shape (nG,3)
        Integer reciprocal vectors
    """
    kpoints = np.atleast_2d(kpoints)
    energies = np.atleast_2d(energies)
    Nk, Nb = energies.shape

    # Build integer G-vectors
    Gvecs = np.array([[i, j, k]
                      for i in range(-nmax, nmax+1)
                      for j in range(-nmax, nmax+1)
                      for k in range(-nmax, nmax+1)], dtype=int)
    nG = len(Gvecs)

    # Build Fourier basis matrix
    phase = 2*np.pi * np.dot(kpoints, Gvecs.T)
    A = np.exp(1j * phase)

    # Apply k-point weights if provided
    if weights is not None:
        W = np.sqrt(weights)[:, None]
        A = A * W
        energies_w = energies * W
    else:
        energies_w = energies

    # Smoothness penalty: penalize high-|G| coefficients
    L = np.diag(np.linalg.norm(Gvecs, axis=1)**2)  # |G|^2
    A_aug = np.vstack([A, np.sqrt(lambda_reg)*L])
    coeffs = np.zeros((Nb, nG), dtype=complex)

    for ib in range(Nb):
        e_aug = np.hstack([energies_w[:, ib], np.zeros(nG)])
        c, _, _, _ = np.linalg.lstsq(A_aug, e_aug, rcond=None)
        coeffs[ib] = c

    # Interpolation function
    def interp_func(k):
        k = np.atleast_2d(k)
        phase = 2*np.pi * np.dot(k, Gvecs.T)
        Anew = np.exp(1j * phase)
        return np.real(Anew @ coeffs.T)

    return interp_func, coeffs, Gvecs


def effective_mass_tensor(k_frac, coeffs, Gvecs, bvecs, band=0, return_in_me=True):
    """
    Compute effective mass tensor (3x3) at k-point for any lattice.

    Parameters
    ----------
    k_frac : array_like, shape (3,)
        k-point in fractional coordinates (0-1 along lattice vectors)
    coeffs : complex ndarray, shape (Nbands, nG)
        Fourier coefficients from boltztrap_like_fourier_fit
    Gvecs : int ndarray, shape (nG, 3)
        Integer reciprocal vectors used in Fourier expansion
    bvecs : array_like, shape (3,3)
        Reciprocal lattice vectors (row vectors) in SI units (1/m)
    band : int
        Band index to compute effective mass for
    return_in_me : bool
        Return in units of electron mass (m_e) if True, else kg
    """
    hbar = 1.054571817e-34   # J*s
    hbar_eV = 6.582119569e-16 # eV*s
    m_e = 9.1093837e-31      # kg

    k = np.asarray(k_frac)
    c = coeffs[band]
    phase = 2 * np.pi * np.dot(k, Gvecs.T)
    exp_factor = np.exp(1j * phase)

    # Hessian in fractional k coordinates
    Hess_frac = np.zeros((3,3), dtype=float)
    for alpha in range(3):
        for beta in range(3):
            Hess_frac[alpha, beta] = np.real(np.sum(- (2*np.pi)**2 * Gvecs[:, alpha] * Gvecs[:, beta] * c * exp_factor))

    # Convert to physical k using reciprocal lattice vectors
    # B is 3x3 with bvecs as row vectors
    B = np.asarray(bvecs)  # shape (3,3)
    Hess_phys = B.T @ Hess_frac @ B  # chain rule

    # Inverse mass tensor in kg
    M_tensor = (Hess_phys / (hbar * hbar_eV ))**(-1)
    M_tensor = m_e / M_tensor

    #if return_in_me:
     #   M_tensor /= m_e  # now in units of electron mass

    return M_tensor

if __name__=="__main__":
    bohr2m = 5.29177E-11

    nmax = 5
    nk1 = 18
    nk2 = 18
    nk3 = 18

    band = extract_band_scf('si/nscf/nscf.out')
    kx=[1,0,0]
    ky=[0,1,0]
    kz=[0,0,0]

    h=np.linspace(0.0,1,nk1,endpoint=False)
    k=np.linspace(0.0,1,nk2,endpoint=False)
    l=np.linspace(0.0,1,nk3,endpoint=False)

    kpoints = np.array(k_mesh(h,k,l,kx,ky,kz))

    print(np.shape(band),np.shape(kpoints))

    interp_func, coeffs, Gints = fourier_fit(band,kpoints[:,:3], nmax = nmax)

    qe = QE_XML("si/bs/si.xml")  # or your file name
    qe.summary()
    kpts = qe.get_kpoints()
    eigs = qe.get_eigenvalues()
    cell = qe.get_lattice()
    kpoints_crys = kpoints_2pi_alat_to_fractional(kpts, cell, 10.262000)
    band_dft = extract_band_scf('si/bs/bs.out')
 
    band = []

    for kpt in kpoints_crys:
        band.append(interp_func(kpt))

    band = np.array(band)
    for ib in range(len(band[0,0,:])):
        plt.plot(band[:,0,ib],color = 'k')
        plt.plot(band_dft[:,ib],color = 'crimson')


    plt.show()
    bvecs = recoproc_lat_cart(cell)
    min_arg = np.argmin(band[:,0,4])
    print(effective_mass_tensor(kpoints_crys[min_arg,:], coeffs, Gints, cell*bohr2m, band = 3))

    print(np.shape(band))

