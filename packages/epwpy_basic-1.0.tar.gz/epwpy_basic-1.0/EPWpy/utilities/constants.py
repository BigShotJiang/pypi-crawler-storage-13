import numpy as np
import scipy.constants as sc
########Constants ##################
hbar = 6.582119569*10**-16   #in eV-S
q = 1.602*10**-19      #in Coulomb
c = 3.0*10**10      #in cm/s
CM2MEV = 0.1239841984 # https://physics.nist.gov/cgi-bin/cuu/Value?minvev
Bohr2Ang = 0.5291772108
Ryd2Hart = 0.5
Ang2Bohr = 1.0/Bohr2Ang

class Constants:
    """
    Provides commonly used physical and atomic constants.

    All methods return a numerical value corresponding to the constant.
    """

    def __init__(self):
        """
        Initialize the Constants class.
        Currently, no dynamic attributes are needed.
        """
        pass

    def ryd2hart(self):
        """Conversion factor from Rydberg to Hartree."""
        return 0.5

    def hbar_eVs(self):
        """Reduced Planck constant in eV·s."""
        return 6.582119569e-16

    def hbar_Js(self):
        """Reduced Planck constant in J·s."""
        return 1.054571817e-34

    def eps0(self):
        """Vacuum permittivity (F/m)."""
        return 8.8541878188e-12

    def mu0(self):
        """Vacuum permeability (H/m)."""
        return 1.25663706127e-6

    def q(self):
        """Elementary charge (C)."""
        return 1.602176634e-19

    def bohr2ang(self):
        """Bohr radius in Angstroms."""
        return 0.5291772108

    def ang2bohr(self):
        """Angstrom to Bohr conversion."""
        return 1.0 / self.bohr2ang()

    def cm2meV(self):
        """Conversion factor from cm⁻¹ to meV."""
        return 0.1239841984

    def c_ms(self):
        """Speed of light in m/s."""
        return 299792458

    def c_cms(self):
        """Speed of light in cm/s."""
        return 299792458 * 100

    def thr4(self):
        """
        Return 1E-4
        """
        return 1E-4

    def thr6(self):
        """
        Return 1E-6
        """
        return 1E-6

    def thr8(self):
        """
        Return 1E-8
        """
        return 1E-8

    def thr10(self):
        """
        Return 1E-10
        """
        return 1E-10

    def thr12(self):
        """
        Return 1E-12
        """
        return 1E-12

