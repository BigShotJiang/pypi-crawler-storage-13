import os

def print_tree(startpath, show_files=True, indent=""):
    """Recursively prints folders (and optionally files) as a tree.
       Hidden files/folders (starting with .) are skipped.
       If show_files=False, only directories are shown."""
    try:
        items = sorted([i for i in os.listdir(startpath) if not i.startswith('.')])
    except PermissionError:
        return  # Skip folders without permission

    for i, item in enumerate(items):
        path = os.path.join(startpath, item)

        # Skip files if show_files is False
        if not show_files and not os.path.isdir(path):
            continue

        connector = "└── " if i == len(items) - 1 else "├── "
        print(indent + connector + item)

        if os.path.isdir(path):
            extension = "    " if i == len(items) - 1 else "│   "
            print_tree(path, show_files, indent + extension)

def print_file(file):
    with open(file,'r') as f:
        for line in f:
            print(line)

