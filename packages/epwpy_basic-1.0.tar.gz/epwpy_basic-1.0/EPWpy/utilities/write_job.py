import numpy as np
import os
import inspect
import EPWpy.utilities.epw_pp as epw_pp_module

class write_job:
    """
    Class to write job script
    """
    def __init__(self):
        pass
 
    def write_precondition(self): 
        filename = self.script_params['job_name']
        if os.path.exists(filename):
            os.remove(filename)
        with open(f"{filename}", 'a') as fil:
            fil.write('#!/bin/bash\n')
            for key in self.script_params:
                param = self.script_params[key]
                if '-' in key:  # is a -J, -e, -o, etc. type of flag
                    fil.write(f'#SBATCH {key} {param}\n')
            fil.write(f'\nQE={self.dir_to_QE}\n\n')
        fil.close()

    def write_cd(self, directory='./'):
        try:
            filename = self.script_params['job_name']
        except AttributeError:
            filename = self.writer.script_params['job_name']
        
        with open(f"{filename}", 'a') as fil:
            fil.write(f"cd {directory}\n")
        fil.close()

    def write_mkdir(self, directory='./'):
        try:
            filename = self.script_params['job_name']
        except AttributeError:
            filename = self.writer.script_params['job_name']
        
        with open(f"{filename}", 'a') as fil:
            fil.write(f"mkdir {directory}\n")
        fil.close()

    def write_execute(self,cmd):
        filename = self.script_params['job_name']
        with open(f'{filename}', 'a') as fil:
            fil.write(f'{cmd} \n')
        fil.close()

    def write_pp(self, prefix):
        epw_pp_source = inspect.getsource(epw_pp_module)
        filename = self.script_params['job_name']
        with open(f'pp.py', 'w') as f:
            #f.write('import EPWpy \n')
            #f.write('from EPWpy.utilities import epw_pp \n')
            f.write(epw_pp_source)
            f.write(f'run_pp(\'{prefix}\') \n')
        f.close()
        with open(f'{filename}', 'a') as fil:
            fil.write(f'python ../pp.py \n')
        fil.close()

    


        
