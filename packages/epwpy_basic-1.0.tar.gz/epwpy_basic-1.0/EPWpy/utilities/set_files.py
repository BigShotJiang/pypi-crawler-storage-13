import numpy as np
import os
from EPWpy.utilities.write_job import write_job
from EPWpy.default import set_default as sd
class SetDir(write_job):
    """
    Class to manage directory structure and file writing for simulations.

    This class handles creation of working directories and sets up a writer 
    object for job management. It acts as a base class for higher-level
    simulation interfaces (QE, EPW, Abinit, BGW).

    Attributes
    ----------
    data : any
        User-provided input data, typically a dictionary containing calculation parameters.
    home : str
        Current working directory at the time of initialization.
    home_real : str
        Same as `home`; stores the original working directory for reference.
    sd : SetDefaultVals
        Internal object for default values and writer creation.
    writer : object
        Writer object (created from `SetDefaultVals`) used to write input files or scripts.
    """

    def __init__(self, data):
        """
        Initialize directory manager.

        Sets the home directory, stores input data, and creates a writer
        object for managing input file generation.

        Parameters
        ----------
        data : any
            Input data required for the calculation. Typically a dictionary
            specifying calculation type, k-points, cutoffs, etc.
        """
        self.data = data
        self.home = os.getcwd()
        self.home_real = os.getcwd()
        self.sd = SetDefaultVals()
        self.writer = self.sd.create_writer()

    def set_home(self, write=False):
        """
        Sets home folder
        """
        if (self.writer.script_params['write_script'] == True):
            self.write_cd(self.home)
        try:
            os.chdir(self.home)
        except FileNotFoundError:
            os.chdir(self.home_real)
    def set_work(self, write=False):
        """
        Sets work folder
        """
        if self.writer.script_params['write_script'] == True:
            self.write_cd(self.home+'/'+self.system)
        try:
            os.chdir(self.home+'/'+self.system)
        except FileNotFoundError:
            os.chdir(self.home_real+'/'+self.system)

    def makedir(self, filein):
        """
        Makes a directorty
        """
        if (self.writer.script_params['write_script'] == True): 
            self.write_mkdir(filein)
        else:
            try:
                os.mkdir(filein)
            except FileExistsError:
                pass
    def changedir(self, directory=None):
        """
        Changes to a directory
        """
        if self.writer.script_params['write_script'] == True:
            self.write_cd(directory)
        try:
            os.chdir(directory)
        except FileNotFoundError:
            os.chdir('.')

    def set_folds(self, name, type_run, ins):
        """ 
        sets the folders for methods 
        """        
        if (type_run == 'scf'):
            self.scf_fold = name
            ins.scf_fold = self.scf_fold
            self.state.update({'scf_fold': self.scf_fold})

        if (type_run == 'bs'):
            self.bs_fold = name
            ins.scf_fold = self.scf_fold
            self.state.update({'bs_fold':self.bs_fold})

        if (type_run == 'nscf'):
            self.nscf_fold = name
            ins.scf_fold = self.scf_fold
            ins.nscf_fold = self.nscf_fold
            self.state.update({'nscf_fold':self.nscf_fold})

           
        if (type_run == 'ph'):
            self.ph_fold = name
            ins.scf_fold = self.scf_fold
            ins.ph_fold = self.ph_fold
            self.state.update({'ph_fold':self.ph_fold})

        if (type_run == 'epw1'):
            if (name == 'epw1'):
                name = 'epw'
            self.epw_fold = name
            ins.scf_fold = self.scf_fold
            ins.nscf_fold = self.nscf_fold
            ins.ph_fold = self.ph_fold
            ins.epw_fold = self.epw_fold
            self.state.update({'epw_fold':self.epw_fold})

        else:
            try:
                ins.scf_fold = self.scf_fold
            except AttributeError:
                print('no scf folder')
                #pass
            try:
                ins.nscf_fold = self.nscf_fold
            except AttributeError:
                pass

            try:
                ins.ph_fold = self.ph_fold
            except AttributeError:
                pass

            try:
                ins.epw_fold = self.epw_fold
            except AttributeError:
                pass

    def set_files(self, name, type_run, ins):
        """ 
        Sets the files for methods 
        """        
            
        if (type_run == 'scf'):
            self.scf_file = name
            ins.scf_file = self.scf_file
            self.state.update({'scf_file': self.scf_file})

        if (type_run == 'bs'):
            self.bs_file = name
            ins.scf_file = self.scf_file
            self.state.update({'bs_file':self.bs_file})

        if (type_run == 'nscf'):
            self.nscf_file = name
            ins.scf_file = self.scf_file
            ins.nscf_file = self.nscf_file
            self.state.update({'nscf_file':self.nscf_file})

           
        if (type_run == 'ph'):
            self.ph_file = name
            ins.scf_file = self.scf_file
            ins.ph_file = self.ph_file
            self.state.update({'ph_file':self.ph_file})

        if (type_run == 'epw1'):
            if (name == 'epw1'):
                name = 'epw1'
            self.epw_file = name
            ins.scf_file = self.scf_file
            ins.nscf_file = self.nscf_file
            ins.ph_file= self.ph_file
            ins.epw_file = self.epw_file
            self.state.update({'epw_file':self.epw_file})

        if (type_run == 'epw2'):
            if (name == 'epw2'):
                name = 'epw2'
            self.epw_file = name
            ins.scf_file = self.scf_file
            ins.nscf_file = self.nscf_file
            ins.ph_file= self.ph_file
            ins.epw_file = self.epw_file
            self.state.update({'epw_file':self.epw_file})
        else:
            try:
                ins.scf_file = self.scf_file
            except AttributeError:
                print('No scf file')
                #pass
            try:
                ins.nscf_file = self.nscf_file
            except AttributeError:
                pass

            try:
                ins.ph_file = self.ph_file
            except AttributeError:
                pass

            try:
                ins.epw_file = self.epw_file
            except AttributeError:
                pass

       
