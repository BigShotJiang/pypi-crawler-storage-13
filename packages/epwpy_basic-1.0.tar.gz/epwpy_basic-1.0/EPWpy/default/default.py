####################################default values ###########################################
import numpy as np

BGW_init={'nbnd':100,'shift':[0.0,0.0,0.001],'grid_co':[6,6,6],'grid_fi':[6,6,6]}
BGW_epsilon={'frequency_dependence': 0,'epsilon_cutoff':25}
BGW_sigma={'screening_semiconductor': ' '}
BGW_kernel={'screening_semiconductor': ' '}
BGW_absorption={}
BGW_sig2wan={'spin':1,'eqp':1}
nbnd_BGW=BGW_init['nbnd']
BGW_pw2bgw={'real_or_complex':2,'wfng_flag':'.true.','wfng_file':'\'wfn.cplx\'','wfng_kgrid':'.true.','rhog_flag':'.true.','rhog_file':'\'rho.cplx\'',
            'vxcg_flag':'.false.','vxcg_file':'\'vxc.cplx\'','vxc_flag':'.true.','vxc_file':'\'vxc.dat\'','vxc_diag_nmin': 1,'vxc_diag_nmax':nbnd_BGW,
            'vxc_offdiag_nmin':0,'vxc_offdiag_nmax':0,'wfng_dk1':0,'wfng_dk2':0,'wfng_dk3':0}

abinit_params = {}

vasp_params = {'ENCUT':500, 'ISMEAR':0,'SIGMA':0.01,'PREC':'accurate'}
vasp_kpoint_params = {'len':0,'center':'Gamma','grid':['4 4 4']}


script_params = {'job_name':'script.sh',    # Name of .sh file
                 'write_script':False,        # Determines whether or not script will be written. If False, runs will not be executed and instead be written down
                 'rewrite_script':False,      # If True, rewrites pre-existing script if it shares the same name. If False, writes a new script with time tag.
                 '-J':'Job',                   # Job name
                 '-o':'Job.o%j',               # Name of stdout output file
                 '-e':'Job.e%j',               # Name of stderr error file
                 '-p':'development',           # Queue (partition) name
                 '-N':'1',                     # Total # of nodes (must be 1 for serial)
                 '-n':'56',                    # Total # of mpi tasks (should be 1 for serial)
                 '-t':'00:10:00',              # Run time (hh:mm:ss)
                 '-A':'DMR21002',              # Project/Allocaiton name (req'd if you have more than 1)
                 '--mail-type':'all',          # Send email at begin and end of job
                 '--mail-user':'None'}         # Email



def_folds = {'scf':'scf',
             'ph':'ph',
             'epw1':'epw',
             'epw2':'epw',
             'epw3':'epw',
             'custom':'custom',
             'nscf':'nscf',
             'bs':'bs',
             'pp':'pp',
             'q2r':'q2r',
             'dvscf_q2r':'ph',
             'matdyn':'ph',
             'postahc':'ph',
             'eps':'eps',
             'nscf_tetra':'nscf_tetra',
             'bands':'bs',
             'nscf2supercond':'nscf',
             'dynmat':'ph',
             'dos':'nscf',
             'phdos':'ph',
             'pdos':'nscf',
             'fbw':'fbw',
             'fbw_mu':'fbw_mu',
             'epw_outerbands':'epw_outerbands',
             'nesting':'nesting',
             'phselfen':'phselfen',
             'zg':'zg',
             'wannier':'wannier'}
                
