code_set = '/workspace/Sabya/EPWpy_develop/epwpy/build/q-e-EPW-5.9s/bin'
QE_version = '7.4'
EPW_version = '5.9'