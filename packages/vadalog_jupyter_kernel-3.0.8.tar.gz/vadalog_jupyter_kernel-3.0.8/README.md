# Vadalog Jupyter Kernel

A Jupyter kernel for executing [Vadalog](https://www.prometheux.ai) knowledge graph queries in JupyterLab.

## Installation

```bash
pip install vadalog-jupyter-kernel
```

## Usage

1. Start JupyterLab:
   ```bash
   jupyter lab
   ```

2. Create a new notebook and select the **Vadalog** kernel

3. Write Vadalog code:
   ```vadalog
   @input("person").
   person("Alice").
   person("Bob").
   
   @output("greeting").
   greeting(X, "Hello") :- person(X).
   ```

4. Run the cell and see the results!

## Features

- ✅ Execute Vadalog queries
- ✅ Display results as formatted HTML tables
- ✅ Execution timing
- ✅ Error handling and reporting
- ✅ Works with [vadalog-extension](https://pypi.org/project/vadalog-extension/) for enhanced UI

## Requirements

- Python >= 3.8
- JupyterLab >= 4.0.0
- Vadalog backend server (contact support for access)

## Recommended

Install with the JupyterLab extension for the best experience:

```bash
pip install vadalog-jupyter-kernel vadalog-extension
```

This gives you:
- 🎨 Syntax highlighting
- 🔍 Code linting
- 🛑 Stop button integration
- 📊 Beautiful output formatting
- ⏱️ Execution timing

## Access to Vadalog Backend

The Vadalog backend is required to execute queries. To request access:

- 📧 **Email**: davben@prometheux.co.uk or support@prometheux.co.uk
- 🌐 **Website**: https://www.prometheux.ai

## License

BSD 3-Clause License - see LICENSE file for details.

## About Vadalog

Vadalog is a powerful knowledge graph system developed by [Prometheux Limited](https://www.prometheux.ai).

## Support

- **Homepage**: https://www.prometheux.ai
- **PyPI**: https://pypi.org/project/vadalog-jupyter-kernel/
- **Email**: davben@prometheux.co.uk or support@prometheux.co.uk
