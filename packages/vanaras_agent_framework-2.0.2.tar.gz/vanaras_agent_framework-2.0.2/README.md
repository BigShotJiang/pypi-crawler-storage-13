# Vanaras AI — Agent Framework
[![PyPI](https://img.shields.io/pypi/v/vanaras-agent-framework.svg)]()
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)

<p align="center">
  <img src="https://raw.githubusercontent.com/vanarasai/agent-framework/main/website/static/img/logo.jpg" alt="Vanaras AI Agents" width="300">
</p>

Vanaras is a **Local First**, extensible agent framework for programmatic code tasks, tool execution, and memory-backed context. It provides a minimal planner, a code executor, a memory store (FAISS), and a sandboxed tools layer that agents call to read/write files, run code, and apply patches.

## 📚 Documentation

Full documentation is available at **[vanaras.ai](https://vanaras.ai)** (or run locally with `npm start` in `website/`).

- [Getting Started](https://github.com/vanarasai/agent-framework/blob/main/website/docs/getting-started/installation.md)
- [Core Concepts](https://github.com/vanarasai/agent-framework/blob/main/website/docs/core-concepts/architecture.md)
- [API Reference](https://github.com/vanarasai/agent-framework/blob/main/website/docs/api-reference/api-reference.md)

## 🚀 Key Features

- **Local First**: Designed to run with local LLMs (Ollama/Llama 3.1) by default. Privacy by design.
- **Agentic Workflow**: Don't just run scripts—orchestrate Planner, Developer, Critic, and Validator agents.
- **Templates**: 9 built-in templates for common use cases (RAG, Web Scraper, ETL, etc.).
- **Memory**: Built-in vector memory (FAISS) for long-term context.
- **Dashboard**: Real-time UI to monitor agent activities.

## 🛠️ Installation

```bash
pip install vanaras-agent-framework
```

### Configure LLM (Local First)

1.  **Install Ollama**: [ollama.com](https://ollama.com)
2.  **Pull Model**: `ollama pull llama3.1`
3.  **Run**: Vanaras connects to `localhost:11434` automatically.

*(Optional: Set `VANARAS_LLM_URL` and `VANARAS_API_KEY` for OpenAI)*

## ⚡ Quick Start with CLI

The **Interactive CLI** is the heart of Vanaras. Just type what you want:

```bash
vanaras init my_agent
cd my_agent
vanaras run
```

**Example Session:**
```
🤖 Vanaras Agent Framework
💬 How can I help you today?
> Create a stock price tracker for AAPL and GOOGL. Save the report to markdown.

✨ Working on it...
[Planner] Creating plan...
[Developer] Writing code...
[Critic] Reviewing code...
✅ Done!
```

## 📖 Tutorials

We have comprehensive, **fully agentic** tutorials for every template:

1.  **[Financial Analyst](https://github.com/vanarasai/agent-framework/blob/main/website/docs/tutorials/financial-analyst.md)**: Build an ETL pipeline.
2.  **[Web Scraper](https://github.com/vanarasai/agent-framework/blob/main/website/docs/tutorials/web-scraper.md)**: Track competitor prices.
3.  **[Doc Generator](https://github.com/vanarasai/agent-framework/blob/main/website/docs/tutorials/automating-docs.md)**: Auto-generate documentation.
4.  **[RAG Agent](https://github.com/vanarasai/agent-framework/blob/main/website/docs/tutorials/rag-agent.md)**: Chat with legal documents.
5.  **[Code Analyzer](https://github.com/vanarasai/agent-framework/blob/main/website/docs/tutorials/code-analyzer.md)**: Audit legacy code.
6.  **[Multi-Agent Crew](https://github.com/vanarasai/agent-framework/blob/main/website/docs/tutorials/multi-agent-crew.md)**: Orchestrate a marketing team.
7.  **[Testing Framework](https://github.com/vanarasai/agent-framework/blob/main/website/docs/tutorials/testing-framework.md)**: Auto-generate test suites.
8.  **[API Client](https://github.com/vanarasai/agent-framework/blob/main/website/docs/tutorials/api-client.md)**: Generate SDKs from OpenAPI.
9.  **[CLI App](https://github.com/vanarasai/agent-framework/blob/main/website/docs/tutorials/cli-app.md)**: Build custom CLI tools.

## Enterprise Features 🔒

**Vanaras Enterprise** provides:
- **Security**: SSO, RBAC, Audit Logging
- **Scalability**: Distributed execution
- **Compliance**: SOC 2, GDPR
- **Support**: 24/7 SLA

[Contact Sales](mailto:sales@vanaras.ai)

## License

**Open Source**: Apache 2.0
**Enterprise**: Proprietary

## Community

- [Discord](https://discord.gg/vanaras)
- [GitHub Discussions](https://github.com/Vanaras-AI/agent-framework/discussions)
- [Twitter](https://twitter.com/vanaras_ai)

---

**Made with ❤️ by Vanaras AI**
