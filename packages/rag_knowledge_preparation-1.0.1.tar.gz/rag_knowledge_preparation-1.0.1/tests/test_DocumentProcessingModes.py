import pytest
from pathlib import Path
from unittest.mock import Mock, patch

from rag_knowledge_preparation import (
    convert_document_to_markdown,
    convert_scanned_document_to_markdown,
    convert_document_with_table_processing,
    convert_document_with_maximum_quality,
    list_document_configs
)


class TestProcessingModes:
    
    def test_list_available_configs(self):
        configs = list_document_configs()
        
        assert isinstance(configs, dict)
        assert "basic" in configs
        assert "standard" in configs
        assert "ocr_heavy" in configs
        assert "table_focused" in configs
        assert "high_quality" in configs
        
        for description in configs.values():
            assert isinstance(description, str)
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_basic_mode(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Basic Mode"
        mock_processor.return_value = mock_instance

        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_document_to_markdown(test_file, processing_preset="basic")
            assert result == "# Basic Mode"
            mock_processor.assert_called_once()
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_standard_mode(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Standard Mode"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_document_to_markdown(test_file, processing_preset="standard")
            assert result == "# Standard Mode"
            mock_processor.assert_called_once()
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_ocr_heavy_mode(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# OCR Heavy Mode"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_document_to_markdown(test_file, processing_preset="ocr_heavy")
            assert result == "# OCR Heavy Mode"
            mock_processor.assert_called_once()
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_table_focused_mode(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Table Focused Mode"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_document_to_markdown(test_file, processing_preset="table_focused")
            assert result == "# Table Focused Mode"
            mock_processor.assert_called_once()
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_high_quality_mode(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# High Quality Mode"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_document_to_markdown(test_file, processing_preset="high_quality")
            assert result == "# High Quality Mode"
            mock_processor.assert_called_once()
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_convert_scanned_document_to_markdown(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Scanned Document"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_scanned_document_to_markdown(test_file, api_key="key")
            assert result == "# Scanned Document"
            mock_processor.assert_called_once()
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_convert_document_with_table_processing(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Table Processing"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_document_with_table_processing(test_file, api_key="key")
            assert result == "# Table Processing"
            mock_processor.assert_called_once()
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_convert_document_with_maximum_quality(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Maximum Quality"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_document_with_maximum_quality(test_file, api_key="key")
            assert result == "# Maximum Quality"
            mock_processor.assert_called_once()
        finally:
            test_file.unlink()
