import pytest
from pathlib import Path
from unittest.mock import Mock, patch

from rag_knowledge_preparation import convert_document_to_markdown
from rag_knowledge_preparation.utils.CustomExceptions import UnsupportedFormatError


class TestDifferentFormats:
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_pdf_format(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Test PDF"
        mock_processor.return_value = mock_instance
        
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            result = convert_document_to_markdown(test_file, processing_preset="basic")
            assert result == "# Test PDF"
            mock_processor.assert_called_once()
        finally:
            test_file.unlink()
    
    def test_unsupported_format(self):
        test_file = Path("tests/test_data/test_document.txt")
        test_file.touch()
        
        try:
            with pytest.raises(UnsupportedFormatError):
                convert_document_to_markdown(test_file, processing_preset="basic")
        finally:
            test_file.unlink()


if __name__ == "__main__":
    pytest.main([__file__])
