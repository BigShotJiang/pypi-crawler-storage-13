import pytest
from pathlib import Path
from unittest.mock import Mock, patch

from rag_knowledge_preparation import convert_document_to_markdown
from rag_knowledge_preparation.utils.CustomExceptions import (
    DocumentNotFoundError,
    ConfigurationError,
    UnsupportedFormatError,
    ConversionError
)


class TestErrorHandling:
    
    def test_file_not_found_error(self):
        with pytest.raises(DocumentNotFoundError):
            convert_document_to_markdown("non_existent_file.pdf")
    
    def test_invalid_processing_preset(self):
        # Create a temporary file for testing
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            with pytest.raises(ConfigurationError):
                convert_document_to_markdown(
                    test_file, 
                    processing_preset="invalid_preset"
                )
        finally:
            test_file.unlink()
    
    def test_invalid_configuration_override(self):
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        try:
            with pytest.raises(ConfigurationError):
                convert_document_to_markdown(
                    test_file,
                    processing_preset="standard",
                    invalid_option="test"
                )
        finally:
            test_file.unlink()
    
    def test_unsupported_file_format(self):
        test_file = Path("tests/test_data/test_document.txt")
        test_file.touch()
        
        try:
            with pytest.raises(UnsupportedFormatError):
                convert_document_to_markdown(test_file, processing_preset="basic")
        finally:
            test_file.unlink()
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_conversion_failure(self, mock_processor):
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.side_effect = RuntimeError("Conversion failed")
        mock_processor.return_value = mock_instance
        
        try:
            with pytest.raises(ConversionError, match="Conversion failed"):
                convert_document_to_markdown(test_file, processing_preset="basic")
        finally:
            test_file.unlink()
    
    def test_missing_api_key(self, monkeypatch):
        test_file = Path("tests/test_data/test_document.pdf")
        test_file.touch()
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)
        
        try:
            with pytest.raises(ConfigurationError):
                convert_document_to_markdown(test_file)
        finally:
            test_file.unlink()


if __name__ == "__main__":
    pytest.main([__file__])
