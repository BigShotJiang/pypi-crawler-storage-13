import pytest
from pathlib import Path
from unittest.mock import Mock, patch

from rag_knowledge_preparation import (
    convert_documents_batch,
    convert_folder_to_markdown
)
from rag_knowledge_preparation.utils.CustomExceptions import (
    DocumentNotFoundError,
    ConfigurationError,
    ConversionError
)


class TestBatchProcessing:
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_convert_documents_batch_list(self, mock_processor):
        pdf1 = Path("tests/test_data/test_document.pdf")
        pdf2 = Path("tests/test_data/test_document_second.pdf")
        pdf1.touch()
        pdf2.touch()

        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.side_effect = ["# Document 1", "# Document 2"]
        mock_processor.return_value = mock_instance
        
        try:
            results = convert_documents_batch([pdf1, pdf2], processing_preset="basic", api_key="key")
            
            assert len(results) == 2
            assert results[str(pdf1)] == "# Document 1"
            assert results[str(pdf2)] == "# Document 2"
            assert mock_instance.convert_pdf_to_markdown.call_count == 2
        finally:
            pdf1.unlink(missing_ok=True)
            pdf2.unlink(missing_ok=True)
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_convert_documents_batch_single_file(self, mock_processor):
        pdf = Path("tests/test_data/test_document.pdf")
        pdf.touch()

        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Single Document"
        mock_processor.return_value = mock_instance
        
        try:
            results = convert_documents_batch(pdf, processing_preset="basic", api_key="key")
            
            assert len(results) == 1
            assert results[str(pdf)] == "# Single Document"
            mock_instance.convert_pdf_to_markdown.assert_called_once_with(pdf)
        finally:
            pdf.unlink(missing_ok=True)
    
    def test_convert_documents_batch_file_not_found(self):
        with pytest.raises(DocumentNotFoundError):
            convert_documents_batch(["non_existent_file.pdf"], processing_preset="basic")
    
    def test_convert_documents_batch_invalid_preset(self):
        pdf = Path("tests/test_data/test_document.pdf")
        pdf.touch()
        
        try:
            with pytest.raises(ConfigurationError):
                convert_documents_batch([pdf], processing_preset="invalid_preset")
        finally:
            pdf.unlink(missing_ok=True)
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_convert_documents_batch_conversion_error(self, mock_processor):
        pdf = Path("tests/test_data/test_document.pdf")
        pdf.touch()
        
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.side_effect = RuntimeError("Conversion failed")
        mock_processor.return_value = mock_instance
        
        try:
            with pytest.raises(ConversionError, match="Conversion failed"):
                convert_documents_batch([pdf], processing_preset="basic", api_key="key")
        finally:
            pdf.unlink(missing_ok=True)
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.convert_document_to_markdown')
    def test_convert_folder_to_markdown(self, mock_convert):
        import tempfile

        with tempfile.TemporaryDirectory() as temp_dir:
            folder = Path(temp_dir)
            pdf1 = folder / "doc1.pdf"
            pdf2 = folder / "doc2.pdf"
            pdf1.touch()
            pdf2.touch()
            
            mock_convert.side_effect = ["# Folder Document 1", "# Folder Document 2"]
            
            results = convert_folder_to_markdown(folder, processing_preset="basic", api_key="key")
            
            assert len(results) == 2
            assert results[str(pdf1)] == "# Folder Document 1"
            assert results[str(pdf2)] == "# Folder Document 2"
            assert mock_convert.call_count == 2
    
    def test_convert_folder_to_markdown_folder_not_found(self):
        non_existent_folder = "non_existent_folder"
        
        with pytest.raises(DocumentNotFoundError, match="Folder not found"):
            convert_folder_to_markdown(non_existent_folder, processing_preset="basic")
    
    def test_convert_folder_to_markdown_not_directory(self):
        file_path = "tests/test_data/test_document.pdf"
        Path(file_path).touch()
        
        try:
            with pytest.raises(DocumentNotFoundError, match="not a directory"):
                convert_folder_to_markdown(file_path, processing_preset="basic")
        finally:
            Path(file_path).unlink(missing_ok=True)
    
    @patch('rag_knowledge_preparation.document_processing.DocumentConverter.GeminiOCRProcessor')
    def test_convert_documents_batch_empty_list(self, mock_processor):
        mock_instance = Mock()
        mock_instance.convert_pdf_to_markdown.return_value = "# Empty"
        mock_processor.return_value = mock_instance
        
        results = convert_documents_batch([], processing_preset="basic", api_key="key")
        
        assert results == {}
        mock_processor.assert_not_called()


class TestFindSupportedDocuments:
    
    def test_find_supported_documents(self):
        from rag_knowledge_preparation.document_processing.DocumentConverter import _find_supported_documents
        import tempfile
        
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            pdf_file = temp_path / "keep.pdf"
            txt_file = temp_path / "ignore.txt"
            pdf_file.touch()
            txt_file.touch()
            
            supported_files = _find_supported_documents(temp_path)
            
            assert supported_files == [pdf_file]
    
    def test_find_supported_documents_empty_folder(self):
        from rag_knowledge_preparation.document_processing.DocumentConverter import _find_supported_documents
        
        import tempfile
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            supported_files = _find_supported_documents(temp_path)
            assert supported_files == []


if __name__ == "__main__":
    pytest.main([__file__])
