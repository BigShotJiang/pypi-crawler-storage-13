import pytest
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
import tempfile
import os

from rag_knowledge_preparation import (
    export_codebase_to_markdown,
    analyze_codebase_structure,
    get_codebase_overview,
    CodebaseProcessingConfig,
    get_codebase_config,
    list_available_codebase_configs,
    MetadataConfig,
)
from rag_knowledge_preparation.codebase_processing.utils import DuplicateTracker
from rag_knowledge_preparation.utils.CustomExceptions import (
    DocumentNotFoundError,
    ConfigurationError,
    ConversionError
)


class TestCodebaseProcessing:
    def test_export_codebase_to_markdown_file_not_found(self):
        with pytest.raises(DocumentNotFoundError):
            export_codebase_to_markdown("non_existent_directory")
    
    def test_export_codebase_to_markdown_invalid_preset(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            test_file = temp_path / "test.py"
            test_file.write_text("print('hello')")
            
            with pytest.raises(ConfigurationError):
                export_codebase_to_markdown(
                    temp_path, 
                    processing_preset="invalid_preset"
                )
    
    def test_export_codebase_to_markdown_success(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            test_file = temp_path / "test.py"
            test_file.write_text("print('hello world')")
            
            output_file = temp_path / "output.md"
            result = export_codebase_to_markdown(
                temp_path, 
                output_file=output_file,
                processing_preset="minimal"
            )
            
            assert result == str(output_file)
            assert output_file.exists()
            content = output_file.read_text()
            assert "test.py" in content
            assert "print('hello world')" in content

    def test_export_codebase_includes_readme_overview(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "test.py").write_text("print('hello world')")
            (temp_path / "README.md").write_text(
                "# Sample Project\n\n"
                "This project does amazing things. It includes a clean architecture with modular components,"  
                "deployment notes, and configuration tips."
            )

            output_file = temp_path / "output.md"
            export_codebase_to_markdown(
                temp_path,
                output_file=output_file,
                processing_preset="minimal"
            )

            content = output_file.read_text()
            assert "## Project Overview" in content
            assert "This project does amazing things." in content
            assert "clean architecture" in content

    def test_export_codebase_without_readme_has_no_overview(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "test.py").write_text("print('hello world')")

            output_file = temp_path / "output.md"
            export_codebase_to_markdown(
                temp_path,
                output_file=output_file,
                processing_preset="minimal"
            )

            content = output_file.read_text()
            assert "## Project Overview" not in content
    
    def test_analyze_codebase_structure(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "test.py").write_text("def hello():\n    print('hello')")
            (temp_path / "test.js").write_text("function hello() {\n    console.log('hello');\n}")
            (temp_path / "README.md").write_text("# Test Project")
            
            result = analyze_codebase_structure(temp_path, processing_preset="minimal")
            
            assert result['total_files'] == 3
            assert result['total_lines'] > 0
            assert 'python' in result['languages']
            assert 'javascript' in result['languages']
            assert 'markdown' in result['languages']
    
    def test_get_codebase_overview(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            
            result = get_codebase_overview(temp_path, processing_preset="standard")
            
            assert result['path'] == str(temp_path)
            assert result['name'] == temp_path.name
            assert result['is_directory'] is True
            assert result['is_file'] is False
    
    def test_codebase_processing_config_validation(self):
        config = CodebaseProcessingConfig(max_file_size_mb=2.0)
        assert config.max_file_size_mb == 2.0
        with pytest.raises(ValueError):
            CodebaseProcessingConfig(max_file_size_mb=-1.0)
    
    def test_get_codebase_config(self):
        minimal_config = get_codebase_config("minimal")
        assert minimal_config.include_test_files is False
        
        standard_config = get_codebase_config("standard")
        assert standard_config.include_test_files is True
        
        comprehensive_config = get_codebase_config("comprehensive")
        assert comprehensive_config.max_file_size_mb == 5.0
        with pytest.raises(ValueError):
            get_codebase_config("invalid_config")
    
    def test_list_available_codebase_configs(self):
        configs = list_available_codebase_configs()
        
        assert "minimal" in configs
        assert "standard" in configs
        assert "comprehensive" in configs
        assert isinstance(configs["minimal"], str)
    
    @patch('rag_knowledge_preparation.codebase_processing.core.CodebaseConverter.export_to_markdown')
    def test_export_with_custom_config(self, mock_export):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            test_file = temp_path / "test.py"
            test_file.write_text("print('hello')")
            
            mock_export.return_value = None
            
            export_codebase_to_markdown(
                temp_path,
                processing_preset="standard",
                max_file_size_mb=2.0,
                include_test_files=False
            )
            
            mock_export.assert_called_once()
            call_args = mock_export.call_args
            config = call_args[0][2]
            
            assert config.max_file_size_mb == 2.0
            assert config.include_test_files is False
    
    def test_export_single_file(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            test_file = temp_path / "test.py"
            test_file.write_text("def hello():\n    return 'world'")
            
            output_file = temp_path / "output.md"
            result = export_codebase_to_markdown(
                test_file, 
                output_file=output_file,
                processing_preset="minimal"
            )
            
            assert result == str(output_file)
            assert output_file.exists()
            content = output_file.read_text()
            assert "test.py" in content
            assert "def hello():" in content

    def test_static_assets_ignored_by_default(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "script.py").write_text("print('hi')")
            (temp_path / "logo.svg").write_text("<svg></svg>")

            output_file = temp_path / "output.md"
            export_codebase_to_markdown(
                temp_path,
                output_file=output_file,
                processing_preset="standard"
            )

            content = output_file.read_text()
            assert "logo.svg" not in content

    def test_static_assets_included_when_enabled(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            (temp_path / "script.py").write_text("print('hi')")
            (temp_path / "logo.svg").write_text("<svg></svg>")

            output_file = temp_path / "output.md"
            export_codebase_to_markdown(
                temp_path,
                output_file=output_file,
                processing_preset="standard",
                include_static_assets=True
            )

            content = output_file.read_text()
            assert "logo.svg" in content
    
    def test_export_includes_project_metadata(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            test_file = temp_path / "sample.py"
            test_file.write_text("def hello():\n    return 'world'")
            
            output_file = temp_path / "output.md"
            config = CodebaseProcessingConfig(
                project_name="Demo Project",
                project_aliases=["DPX"],
                project_description="Internal knowledge tooling.",
                metadata_config=MetadataConfig(
                    include_project_description=True,
                    include_project_aliases=True,
                    include_file_aliases=True
                )
            )
            
            export_codebase_to_markdown(
                temp_path,
                output_file=output_file,
                processing_preset="minimal",
                **config.model_dump()
            )
            
            content = output_file.read_text()
            assert "- **Project**: `Demo Project`" in content
            assert "- **Project Aliases**" in content
            assert "`DPX`" in content
            assert "- **Project Description**: Internal knowledge tooling." in content
            assert "- **File Aliases**:" in content

    def test_exclude_extensions_and_dirs(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            docs_dir = temp_path / "docs"
            docs_dir.mkdir()
            (docs_dir / "manual.md").write_text("Docs content")
            (temp_path / "app.log").write_text("should be ignored")
            (temp_path / "main.py").write_text("print('ok')")

            output_file = temp_path / "output.md"
            export_codebase_to_markdown(
                temp_path,
                output_file=output_file,
                processing_preset="standard",
                exclude_directories=["docs"],
                exclude_file_extensions=[".log"]
            )

            content = output_file.read_text()
            assert "manual.md" not in content
            assert "app.log" not in content
            assert "main.py" in content

    def test_duplicate_tracker_collects_shared_files(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            tracker = DuplicateTracker(min_occurrences=2)

            for project_name in ["alpha", "beta"]:
                proj = root / project_name
                proj.mkdir()
                (proj / "shared.py").write_text("print('shared logic')")
                (proj / "unique.py").write_text(f"print('{project_name}')")

                export_codebase_to_markdown(
                    proj,
                    output_file=root / f"{project_name}.md",
                    processing_preset="minimal",
                    duplicate_tracker=tracker,
                    duplicate_content_strategy="link"
                )

            duplicates = tracker.get_duplicates()
            assert len(duplicates) == 1
            record = duplicates[0]
            assert {loc.project for loc in record.locations} == {"alpha", "beta"}
            report_path = root / "shared.md"
            tracker.write_markdown_report(report_path)
            assert "Shared Files" in report_path.read_text()
            beta_md = (root / "beta.md").read_text()
            assert "shared digest" in beta_md


class TestCodebaseAnalysis:
    
    def test_dependency_analyzer(self):
        from rag_knowledge_preparation.codebase_processing.analysis.DependencyAnalyzer import analyze_file_dependencies
        
        python_code = """
import os
import sys
from pathlib import Path
import requests
from .local_module import helper
"""
        
        result = analyze_file_dependencies(python_code, Path("test.py"), "python")
        
        assert "imports" in result
        assert "external_packages" in result
        assert "internal_modules" in result
        assert "standard_library" in result
        
        assert "os" in result["standard_library"]
        assert "sys" in result["standard_library"]
        assert "pathlib" in result["standard_library"]
        assert "requests" in result["external_packages"]
        assert "local_module" in result["internal_modules"]
    
    def test_code_structure_extraction(self):
        from rag_knowledge_preparation.codebase_processing.analysis.CodeAnalyzer import extract_code_structure
        
        python_code = """
class TestClass:
    def __init__(self):
        self.value = 42
    
    def method(self):
        return self.value

def standalone_function():
    return "hello"

CONSTANT = "test"
"""
        
        result = extract_code_structure(Path("test.py"), "python", python_code)
        
        assert "classes" in result
        assert "functions" in result
        assert "constants" in result
        assert "imports" in result
    
    def test_language_detection(self):
        from rag_knowledge_preparation.codebase_processing.analysis.CodeAnalyzer import get_language_from_extension
        
        assert get_language_from_extension(Path("test.py")) == "python"
        assert get_language_from_extension(Path("test.js")) == "javascript"
        assert get_language_from_extension(Path("test.ts")) == "typescript"
        assert get_language_from_extension(Path("test.java")) == "java"
        assert get_language_from_extension(Path("test.go")) == "go"
    
    def test_file_purpose_classification(self):
        from rag_knowledge_preparation.codebase_processing.analysis.CodeAnalyzer import classify_file_by_purpose
        
        assert classify_file_by_purpose(Path("test.py")) == "Tests"
        assert classify_file_by_purpose(Path("README.md")) == "Documentation"
        assert classify_file_by_purpose(Path("config.yaml")) == "Configuration"
        assert classify_file_by_purpose(Path("test_script.sh")) == "Tests"
        assert classify_file_by_purpose(Path("test_file.py")) == "Tests"
        assert classify_file_by_purpose(Path("script.sh")) == "Utilities"
        assert classify_file_by_purpose(Path("main.py")) == "Business Logic"
    
    def test_token_count_estimation(self):
        from rag_knowledge_preparation.codebase_processing.analysis.CodeAnalyzer import estimate_token_count
        
        text = "This is a test string with multiple words."
        token_count = estimate_token_count(text)
        
        assert isinstance(token_count, int)
        assert token_count > 0
        
        text_list = ["Line 1", "Line 2", "Line 3"]
        token_count_list = estimate_token_count(text_list)
        
        assert isinstance(token_count_list, int)
        assert token_count_list > 0


class TestCodeSummarizer:
    
    @patch('rag_knowledge_preparation.codebase_processing.analysis.CodeSummarizer.ChatGoogleGenerativeAI', side_effect=Exception("no model"))
    def test_fallback_summary(self, _mock_chat):
        """Test fallback summary when Gemini client cannot be built."""
        from rag_knowledge_preparation.codebase_processing.analysis.CodeSummarizer import generate_code_summary
        
        python_code = """
def calculate_sum(a, b):
    return a + b

class Calculator:
    def multiply(self, x, y):
        return x * y
"""
        
        summary = generate_code_summary(python_code, Path("test.py"), "python")
        
        assert isinstance(summary, str)
        assert len(summary) > 0
        assert "python" in summary.lower()
    
    @patch('rag_knowledge_preparation.codebase_processing.analysis.CodeSummarizer.ChatGoogleGenerativeAI')
    def test_ai_summary(self, mock_chat):
        """Test AI-powered summary generation."""
        from rag_knowledge_preparation.codebase_processing.analysis.CodeSummarizer import generate_code_summary
        
        mock_instance = Mock()
        mock_response = Mock()
        mock_response.content = "This is a Python file containing a calculator class with mathematical operations."
        mock_instance.invoke.return_value = mock_response
        mock_chat.return_value = mock_instance
        
        python_code = """
class Calculator:
    def add(self, a, b):
        return a + b
"""
        
        summary = generate_code_summary(python_code, Path("test.py"), "python", "test_api_key")
        
        assert isinstance(summary, str)
        assert len(summary) > 0
        mock_chat.assert_called_once()


if __name__ == "__main__":
    pytest.main([__file__])
