from dataclasses import dataclass
from typing import Dict, Optional

DEFAULT_PROMPT = """You are a precise OCR system. Extract all text from this page.

FORMAT: Output ONLY clean Markdown
- Headings: # H1, ## H2, ### H3
- Tables: | col1 | col2 | with alignment
- Lists: - bullet or 1. numbered
- Bold: **text**, Italic: *text*

RULES:
- Transcribe EXACTLY as written - no corrections
- Preserve reading order: top-to-bottom, left-to-right
- Include ALL text: headers, footers, page numbers, footnotes
- Keep paragraph breaks and spacing

TABLES:
- Convert to proper Markdown tables
- If unclear cell: write [...]
- NEVER repeat table content multiple times

IMAGES/DIAGRAMS:
- Describe in [square brackets]: [Icon: description]

SPECIAL:
- Unreadable: [UNCLEAR: text]
- Math: use LaTeX $formula$
- Multi-column: left first, then right

CRITICAL:
- NO preambles like "Here is the text..."
- NO explanations or summaries
- Check for OCR repetition errors in tables

OUTPUT ONLY EXTRACTED MARKDOWN CONTENT.
"""


@dataclass(frozen=True)
class ProcessingConfig:
    """
    Configuration for Gemini OCR-based document processing.

    Attributes:
        model_name: Gemini multimodal model name.
        prompt: Prompt used for each page extraction.
        temperature: Model temperature.
        max_output_tokens: Token cap per page generation.
        dpi: DPI for rasterizing PDF pages.
        page_selection: Optional page selection string like "1-3,5".
        parallel_concurrency: How many pages to process in parallel.
        max_retries: Max retries for transient model errors.
    """
    model_name: str = "gemini-2.5-pro"
    prompt: str = DEFAULT_PROMPT
    temperature: float = 0.2
    max_output_tokens: int = 4096
    dpi: int = 300
    page_selection: Optional[str] = None
    parallel_concurrency: int = 5
    max_retries: int = 4

    def __post_init__(self) -> None:
        if self.dpi <= 0:
            raise ValueError("dpi must be greater than 0")
        if self.parallel_concurrency <= 0:
            raise ValueError("parallel_concurrency must be greater than 0")
        if self.max_retries <= 0:
            raise ValueError("max_retries must be greater than 0")
        if not 0.0 <= self.temperature <= 1.0:
            raise ValueError("temperature must be between 0.0 and 1.0")
        if self.max_output_tokens <= 0:
            raise ValueError("max_output_tokens must be greater than 0")


CONFIGS = {
    "basic": ProcessingConfig(
        dpi=200,
        parallel_concurrency=3,
        max_output_tokens=2048,
    ),
    "standard": ProcessingConfig(),
    "ocr_heavy": ProcessingConfig(
        dpi=350,
        parallel_concurrency=3,
        max_output_tokens=5120,
        max_retries=5,
    ),
    "table_focused": ProcessingConfig(
        dpi=320,
        prompt=DEFAULT_PROMPT
        + "\nWhen tables are present, preserve their structure faithfully.",
    ),
    "high_quality": ProcessingConfig(
        dpi=400,
        parallel_concurrency=2,
        max_output_tokens=6144,
        max_retries=6,
        temperature=0.15,
    ),
}


def get_config(config_name: str = "standard") -> ProcessingConfig:
    """
    Get a predefined processing configuration.

    Args:
        config_name: Name of the configuration preset

    Returns:
        Configuration object

    Raises:
        ValueError: If config_name is not found
    """
    if config_name not in CONFIGS:
        available_configs = ", ".join(CONFIGS.keys())
        raise ValueError(f"Unknown config '{config_name}'. Available configs: {available_configs}")

    return CONFIGS[config_name]


def list_available_configs() -> Dict[str, str]:
    """
    List all available configuration presets with descriptions.

    Returns:
        Configuration names and descriptions
    """
    return {
        "basic": "Lightweight OCR for quick drafts (lower DPI, smaller outputs).",
        "standard": "Balanced OCR with Gemini 2.5 Pro defaults.",
        "ocr_heavy": "Higher DPI and retries for difficult scans.",
        "table_focused": "Table-aware prompt for documents with heavy tabular data.",
        "high_quality": "Maximum quality settings (highest DPI, more tokens, extra retries).",
    }
