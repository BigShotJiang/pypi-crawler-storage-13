import asyncio
import base64
import io
import logging
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from langchain_core.messages import HumanMessage
from pdf2image import convert_from_bytes
from PIL import Image

from .DocumentProcessingConfig import ProcessingConfig, get_config
from ..utils.CustomExceptions import (
    ConfigurationError,
    ConversionError,
    DocumentNotFoundError,
    UnsupportedFormatError,
)
from ..utils.GeminiClient import GeminiClientConfig, create_chat_model
from ..utils.RetryBackoff import async_run_with_retry
from ..utils.FileIO import list_files

logger = logging.getLogger(__name__)


def convert_document_to_markdown(
    document_path: Union[str, Path],
    processing_preset: str = "standard",
    api_key: Optional[str] = None,
    **preset_overrides: Any,
) -> str:
    """
    Convert a PDF document to Markdown using Gemini OCR.

    Args:
        document_path: Path to the PDF file.
        processing_preset: Name of the processing configuration preset.
        api_key: Optional Google API key. Defaults to GOOGLE_API_KEY env var.
        **preset_overrides: Optional overrides for the selected preset.

    Returns:
        Markdown content extracted from the document.
    """
    document_path = Path(document_path)
    if not document_path.exists():
        raise DocumentNotFoundError(f"Document not found: {document_path}")

    if document_path.suffix.lower() != ".pdf":
        raise UnsupportedFormatError("Only PDF files are supported for OCR conversion.")

    try:
        processing_config = _get_customized_config(processing_preset, preset_overrides)
    except ValueError as e:
        raise ConfigurationError(f"Invalid configuration: {e}") from e

    try:
        processor = GeminiOCRProcessor(processing_config, api_key=api_key)
        logger.info("Starting OCR for %s (preset=%s, model=%s)", document_path, processing_preset, processing_config.model_name)
        return processor.convert_pdf_to_markdown(document_path)
    except ConfigurationError:
        raise
    except Exception as e:
        raise ConversionError(f"Failed to convert document: {e}") from e


def _get_customized_config(preset_name: str, overrides: Dict[str, Any]) -> ProcessingConfig:
    """Get configuration with custom overrides applied."""
    try:
        base_config = get_config(preset_name)
    except ValueError as e:
        raise ValueError(f"Invalid preset name: {e}") from e

    if not overrides:
        return base_config

    for option_name in overrides.keys():
        if not hasattr(base_config, option_name):
            raise ValueError(f"Unknown configuration option: {option_name}")

    config_dict = {field: getattr(base_config, field) for field in base_config.__dataclass_fields__}  # type: ignore[attr-defined]
    config_dict.update(overrides)
    return ProcessingConfig(**config_dict)


class GeminiOCRProcessor:
    """Gemini-based OCR pipeline that mirrors the Colab workflow for PDF OCR."""

    def __init__(self, config: ProcessingConfig, api_key: Optional[str] = None) -> None:
        self.config = config
        self._client_config = GeminiClientConfig(
            model_name=self.config.model_name,
            api_key=api_key,
            temperature=self.config.temperature,
            max_output_tokens=self.config.max_output_tokens,
        )

        try:
            self.api_key = self._client_config.resolve_api_key()
            self.llm = create_chat_model(self._client_config)
        except Exception as exc:  # noqa: BLE001
            raise ConfigurationError(str(exc)) from exc

    def convert_pdf_to_markdown(self, document_path: Path) -> str:
        """Synchronously convert a PDF to Markdown."""
        coro = self.convert_pdf_to_markdown_async(document_path)
        return self._run_coroutine(coro)

    async def convert_pdf_to_markdown_async(self, document_path: Path) -> str:
        """Asynchronously convert a PDF to Markdown following the Gemini OCR recipe."""
        try:
            pdf_bytes = document_path.read_bytes()
        except Exception as e:
            raise ConversionError(f"Unable to read document bytes: {e}") from e

        try:
            logger.info("Rasterizing PDF %s at %sdpi", document_path, self.config.dpi)
            images = convert_from_bytes(pdf_bytes, dpi=self.config.dpi, fmt="PNG")
        except Exception as e:
            raise ConversionError(f"Failed to rasterize PDF: {e}") from e

        total_pages = len(images)
        selected_pages = parse_page_selection(self.config.page_selection, total_pages)
        if not selected_pages:
            raise ConversionError("No pages selected after applying page selection.")
        logger.info("Total pages: %s | selected: %s", total_pages, selected_pages)

        try:
            page_results = await self._process_all(images, selected_pages)
        except Exception as e:
            raise ConversionError(f"Failed during OCR processing: {e}") from e

        page_results.sort(key=lambda x: x[0])
        logger.info("Completed OCR for %s pages", len(page_results))
        return merge_markdown(page_results, title=document_path.stem)

    async def _process_all(
        self, images: List[Image.Image], selected_pages: List[int]
    ) -> List[Tuple[int, str]]:
        semaphore = asyncio.Semaphore(self.config.parallel_concurrency)
        tasks = [
            asyncio.create_task(self._process_page(images, idx, semaphore))
            for idx in selected_pages
        ]
        results: List[Tuple[int, str]] = []
        for fut in asyncio.as_completed(tasks):
            results.append(await fut)
        return results

    async def _process_page(
        self, images: List[Image.Image], page_index: int, semaphore: asyncio.Semaphore
    ) -> Tuple[int, str]:
        data_url = _pil_to_b64_png(images[page_index - 1])
        message = HumanMessage(
            content=[
                {"type": "text", "text": self.config.prompt},
                {"type": "image_url", "image_url": {"url": data_url}},
            ]
        )

        async def _invoke() -> str:
            response = await self.llm.ainvoke([message])
            text = (response.content or "").strip()
            if not text:
                raise RuntimeError("Empty response from Gemini.")
            return text

        async with semaphore:
            text = await async_run_with_retry(
                _invoke,
                max_retries=self.config.max_retries,
                min_wait=1.0,
                max_wait=10.0,
            )
            return page_index, text

    @staticmethod
    def _run_coroutine(coro: Any) -> Any:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(coro)

        result: Dict[str, Any] = {}
        error: Dict[str, BaseException] = {}

        def runner() -> None:
            new_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(new_loop)
            try:
                result["value"] = new_loop.run_until_complete(coro)
            except BaseException as exc:  # noqa: BLE001
                error["value"] = exc
            finally:
                new_loop.close()

        thread = threading.Thread(target=runner, daemon=True)
        thread.start()
        thread.join()

        if error:
            raise error["value"]  # type: ignore[misc]
        if "value" not in result:
            raise ConversionError("Failed to execute OCR coroutine.")
        return result["value"]


def _pil_to_b64_png(img: Image.Image) -> str:
    """Convert a PIL image to a base64-encoded PNG data URL."""
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    b64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{b64}"


def parse_page_selection(spec: Optional[str], total_pages: int) -> List[int]:
    """Parse a page selection string into 1-based page indices."""
    if not spec:
        return list(range(1, total_pages + 1))

    wanted = set()
    for chunk in spec.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "-" in chunk:
            start, end = chunk.split("-", 1)
            start, end = int(start), int(end)
            wanted.update(range(start, end + 1))
        else:
            wanted.add(int(chunk))
    return [i for i in sorted(wanted) if 1 <= i <= total_pages]


def merge_markdown(page_texts: List[Tuple[int, str]], title: str) -> str:
    """Merge page-by-page markdown with explicit page headers."""
    lines: List[str] = []
    for idx, txt in page_texts:
        lines.append(f"## Page {idx}\n")
        lines.append(txt.strip())
        lines.append("\n")
    return "\n".join(lines)


def convert_scanned_document_to_markdown(
    document_path: Union[str, Path], api_key: Optional[str] = None
) -> str:
    """
    Convert a scanned document to Markdown using OCR processing.
    This shortcut uses the ocr_heavy preset.
    """
    return convert_document_to_markdown(
        document_path=document_path,
        processing_preset="ocr_heavy",
        api_key=api_key,
    )


def convert_document_with_table_processing(
    document_path: Union[str, Path], api_key: Optional[str] = None
) -> str:
    """
    Convert a document with table-aware prompting.
    Uses the table_focused preset tuned for tabular content.
    """
    return convert_document_to_markdown(
        document_path=document_path,
        processing_preset="table_focused",
        api_key=api_key,
    )


def convert_document_with_maximum_quality(
    document_path: Union[str, Path], api_key: Optional[str] = None
) -> str:
    """
    Convert a document with maximum quality processing (high DPI, more retries).
    Uses the high_quality preset.
    """
    return convert_document_to_markdown(
        document_path=document_path,
        processing_preset="high_quality",
        api_key=api_key,
    )


def convert_documents_batch(
    document_paths: Union[List[Union[str, Path]], tuple, str, Path],
    processing_preset: str = "standard",
    api_key: Optional[str] = None,
    **preset_overrides: Any,
) -> Dict[str, str]:
    """
    Convert multiple PDF documents to Markdown format in batch.

    Args:
        document_paths: List of document paths, or a directory path to process all supported files.
        processing_preset: Processing configuration preset.
        api_key: Optional Google API key. Defaults to GOOGLE_API_KEY env var.
        **preset_overrides: Additional configuration options to override preset.

    Returns:
        Dictionary mapping file paths to their Markdown content.
    """
    if isinstance(document_paths, (str, Path)):
        document_paths = Path(document_paths)
        if document_paths.is_dir():
            document_paths = _find_supported_documents(document_paths)
        else:
            document_paths = [document_paths]

    results: Dict[str, str] = {}
    for doc_path in document_paths:
        markdown_content = convert_document_to_markdown(
            doc_path,
            processing_preset=processing_preset,
            api_key=api_key,
            **preset_overrides,
        )
        results[str(Path(doc_path))] = markdown_content

    return results


def convert_folder_to_markdown(
    folder_path: Union[str, Path],
    processing_preset: str = "standard",
    api_key: Optional[str] = None,
    **preset_overrides: Any,
) -> Dict[str, str]:
    """
    Convert all supported documents in a folder to Markdown format.

    Args:
        folder_path: Path to the folder containing documents.
        processing_preset: Processing configuration preset.
        api_key: Optional Google API key. Defaults to GOOGLE_API_KEY env var.
        **preset_overrides: Additional configuration options to override preset.

    Returns:
        Dictionary mapping file paths to their Markdown content.
    """
    folder_path = Path(folder_path)
    if not folder_path.exists():
        raise DocumentNotFoundError(f"Folder not found: {folder_path}")

    if not folder_path.is_dir():
        raise DocumentNotFoundError(f"Path is not a directory: {folder_path}")

    return convert_documents_batch(
        document_paths=folder_path,
        processing_preset=processing_preset,
        api_key=api_key,
        **preset_overrides,
    )


def _find_supported_documents(folder_path: Path) -> List[Path]:
    """Find all supported document files in a folder. Currently PDF only."""
    supported_files = list_files(folder_path, extensions=[".pdf"])
    return sorted(supported_files)
