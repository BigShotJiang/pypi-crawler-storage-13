from typing import Awaitable, Callable, TypeVar

from tenacity import AsyncRetrying, Retrying, stop_after_attempt, wait_exponential

T = TypeVar("T")


async def async_run_with_retry(
    func: Callable[[], Awaitable[T]],
    max_retries: int = 3,
    min_wait: float = 1.0,
    max_wait: float = 10.0,
) -> T:
    """
    Run an async callable with exponential backoff retries.
    """
    async for attempt in AsyncRetrying(
        stop=stop_after_attempt(max_retries),
        wait=wait_exponential(multiplier=1, min=min_wait, max=max_wait),
        reraise=True,
    ):
        with attempt:
            return await func()
    raise RuntimeError("async_run_with_retry exhausted retries")  # pragma: no cover


def run_with_retry(
    func: Callable[[], T],
    max_retries: int = 3,
    min_wait: float = 1.0,
    max_wait: float = 10.0,
) -> T:
    """
    Run a sync callable with exponential backoff retries.
    """
    for attempt in Retrying(
        stop=stop_after_attempt(max_retries),
        wait=wait_exponential(multiplier=1, min=min_wait, max=max_wait),
        reraise=True,
    ):
        with attempt:
            return func()
    raise RuntimeError("run_with_retry exhausted retries")  # pragma: no cover
