from dataclasses import dataclass
import os
from typing import Optional, Sequence

from .CustomExceptions import ConfigurationError

try:  # noqa: SIM105
    from langchain_google_genai import ChatGoogleGenerativeAI
    GEMINI_CHAT_AVAILABLE = True
except ImportError:  # pragma: no cover - dependency may be optional in some environments
    ChatGoogleGenerativeAI = None  # type: ignore
    GEMINI_CHAT_AVAILABLE = False


DEFAULT_ENV_VARS: tuple[str, ...] = ("GOOGLE_API_KEY",)


@dataclass(frozen=True)
class GeminiClientConfig:
    model_name: str = "gemini-2.5-pro"
    api_key: Optional[str] = None
    temperature: float = 0.2
    max_output_tokens: int = 4096
    env_vars: Sequence[str] = DEFAULT_ENV_VARS

    def resolve_api_key(self) -> str:
        if self.api_key:
            return self.api_key

        for env_var in self.env_vars:
            value = os.getenv(env_var)
            if value:
                return value

        raise ConfigurationError(
            f"Google API key is required. Set {', '.join(self.env_vars)} or pass api_key explicitly."
        )


def create_chat_model(config: GeminiClientConfig) -> "ChatGoogleGenerativeAI":
    """Create a LangChain Gemini chat model using shared configuration."""
    return create_chat_model_with_cls(config, ChatGoogleGenerativeAI)


def create_chat_model_with_cls(config: GeminiClientConfig, chat_cls: Optional[type]) -> "ChatGoogleGenerativeAI":
    """Same as create_chat_model but allows injecting chat class (useful for testing)."""
    if not GEMINI_CHAT_AVAILABLE or chat_cls is None:
        raise ConfigurationError("langchain-google-genai is not installed.")

    resolved_key = config.resolve_api_key()

    return chat_cls(
        model=config.model_name,
        api_key=resolved_key,
        temperature=config.temperature,
        max_output_tokens=config.max_output_tokens,
    )
