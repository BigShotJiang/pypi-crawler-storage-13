import hashlib
from dataclasses import dataclass, field
from typing import Dict, List, Set, Optional


@dataclass
class DuplicateLocation:
    project: str
    path: str


@dataclass
class DuplicateRecord:
    digest: str
    language: Optional[str]
    size: int
    preview: str
    projects: Set[str] = field(default_factory=set)
    locations: List[DuplicateLocation] = field(default_factory=list)


class DuplicateTracker:
    """
    Tracks identical files across multiple exports so we can emit a shared report
    instead of repeating boilerplate in every project.
    """

    def __init__(self, min_occurrences: int = 2, capture_preview: bool = True):
        self.min_occurrences = max(2, min_occurrences)
        self.capture_preview = capture_preview
        self._records: Dict[str, DuplicateRecord] = {}

    @staticmethod
    def _build_digest(content: str) -> str:
        return hashlib.md5(content.encode("utf-8")).hexdigest()

    def register(self, *, project: str, path: str, content: str, language: Optional[str] = None) -> tuple[str, int]:
        digest = self._build_digest(content)
        record = self._records.get(digest)
        if record is None:
            preview = content[:1000] if self.capture_preview else ""
            record = DuplicateRecord(
                digest=digest,
                language=language,
                size=len(content),
                preview=preview,
            )
            self._records[digest] = record

        record.projects.add(project)
        record.locations.append(DuplicateLocation(project=project, path=path))
        return record.digest, len(record.locations)

    def get_duplicates(self) -> List[DuplicateRecord]:
        return [
            record for record in self._records.values()
            if len(record.locations) >= self.min_occurrences
        ]

    def has_duplicates(self) -> bool:
        return any(len(record.locations) >= self.min_occurrences for record in self._records.values())

    def generate_markdown_report(self) -> str:
        duplicates = self.get_duplicates()
        if not duplicates:
            return "# Shared Files\n\nNo shared files were detected.\n"

        lines = ["# Shared Files", ""]
        for record in sorted(duplicates, key=lambda r: (-len(r.locations), r.digest)):
            lines.append(f"## Digest `{record.digest}`")
            lines.append("")
            lines.append(f"- Language: `{record.language or 'unknown'}`")
            lines.append(f"- Size: {record.size} characters")
            lines.append(f"- Projects: {', '.join(sorted(record.projects))}")
            lines.append("")
            lines.append("### Locations")
            lines.append("")
            for location in record.locations:
                lines.append(f"- `{location.project}` → `{location.path}`")
            lines.append("")
            if self.capture_preview and record.preview:
                lines.append("### Preview")
                lines.append("")
                lines.append("```")
                lines.append(record.preview)
                lines.append("```")
                lines.append("")
        return "\n".join(lines).rstrip() + "\n"

    def write_markdown_report(self, output_path) -> None:
        from pathlib import Path

        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.generate_markdown_report(), encoding="utf-8")
