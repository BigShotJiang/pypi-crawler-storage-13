"""Alliance Auth app for managing and synchronizing EVE Online standings."""

# pylint: disable = invalid-name
default_app_config = "standingsmanager.apps.StandingsManagerConfig"

__version__ = "0.0.9"
__title__ = "Standings Manager"
