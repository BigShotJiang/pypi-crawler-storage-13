# -*- coding: utf-8 -*-

import geopandas as gpd
import polyline
import pandas as pd
import shapely.geometry as sg
from shapely.geometry import LineString
import numpy as np
import requests
import json
import georouting.utils as gtl
import folium
import networkx as nx
import osmnx as ox


class GoogleRoute:
    """
    The class "GoogleRoute" which allows to retrieve information from a route provided as an argument.

    The class has the following methods:

    - `get_duration()`: Returns the duration of the route in seconds.

    - `get_distance()`: Returns the distance of the route in meters.

    - `get_route()`: Returns the complete route information.

    - `get_route_geopandas()`: Returns a GeoDataFrame with information such as distance, duration, and speed of each step in the route.

    It is assumed that the polyline module is used for decoding the polyline into a LineString geometry. The GeoDataFrame is created with a specified coordinate reference system (CRS) of "4326".
    """

    def __init__(self, route):
        self.route = route

    def get_duration(self):
        """
        Returns the duration of the route in seconds.

        """
        return self.route[0]["legs"][0]["duration"]["value"]

    def get_distance(self):
        """
        Returns the distance of the route in meters.
        """
        return self.route[0]["legs"][0]["distance"]["value"]

    def get_route(self):
        """
        Returns the complete route information.
        """
        return self.route

    def get_route_geopandas(self):
        """
        Returns a GeoDataFrame with information such as distance, duration, and speed of each step in the route. It is assumed that the polyline module is used for decoding the polyline into a LineString geometry. The GeoDataFrame is created with a specified coordinate reference system (CRS) of "4326".

        """

        steps_google = self.route[0]["legs"][0]["steps"]

        google_route1 = []
        for step in steps_google:
            step_g = {}
            step_g["distance (m)"] = step["distance"]["value"]
            step_g["duration (s)"] = step["duration"]["value"]
            step_g["geometry"] = polyline.decode(
                step["polyline"]["points"], 5, geojson=True
            )
            step_g["geometry"] = LineString(step_g["geometry"])
            google_route1.append(step_g)
        google_route1 = gpd.GeoDataFrame(google_route1, geometry="geometry", crs="4326")
        google_route1["speed (m/s)"] = (
            google_route1["distance (m)"] / google_route1["duration (s)"]
        )
        return google_route1


class BingRoute:
    """
    BingRoute class that allows you to extract various information from a route stored in a dictionary. It has the following functions:

    - `get_duration()`: Returns the travel duration in seconds.
    - `get_distance()`: Returns the travel distance in meters.
    - `get_route()`: Returns the entire route in a dictionary.
    - `get_route_geopandas()`: Returns the route information in a GeoPandas dataframe.

    This function extracts the duration and distance information for each leg of the route, creates a list of shapely LineStrings representing the route, and then creates a GeoDataFrame with columns for the duration, distance, and geometry. Additionally, it calculates the speed in meters per second for each leg.

    The class is designed to work with data returned by the Bing Maps REST Services API, as the data is stored in a dictionary with a specific structure.
    """

    def __init__(self, route):
        self.route = route

    # change the duration to seconds
    def _duration_to_seconds(self, duration):
        """
        change the duration to seconds
        """

        durationUnit = self.route["resourceSets"][0]["resources"][0]["durationUnit"]

        if durationUnit == "Second":
            return duration
        elif durationUnit == "Minute":
            return duration * 60
        elif durationUnit == "Hour":
            return duration * 3600
        else:
            raise ValueError("durationUnit is not recognized")

    # change the distance to meters
    def _distance_to_meters(self, distance):
        """
        change the distance to meters
        """
        distanceUnit = self.route["resourceSets"][0]["resources"][0]["distanceUnit"]
        if distanceUnit in ["mi", "Mile"]:
            distance = distance * 1609.344
        elif distanceUnit in ["km", "Kilometer"]:
            distance = distance * 1000
        return distance

    def get_duration(self):
        "get the travel duration in seconds"
        # durationUnit = self.route["resourceSets"][0]["resources"][0]["durationUnit"]
        travelDuration = self.route["resourceSets"][0]["resources"][0]["travelDuration"]

        return self._duration_to_seconds(travelDuration)

    def get_distance(self):
        "get the travel distance in meters"
        # distanceUnit = self.route["resourceSets"][0]["resources"][0]["distanceUnit"]
        travelDistance = self.route["resourceSets"][0]["resources"][0]["travelDistance"]

        return self._distance_to_meters(travelDistance)

    def get_route(self):
        "get the entire route in a dictionary"
        return self.route

    def get_route_geopandas(self):
        """
        This function extracts the duration and distance information for each leg of the route, creates a list of shapely LineStrings representing the route, and then creates a GeoDataFrame with columns for the duration, distance, and geometry. Additionally, it calculates the speed in meters per second for each leg.

        Returns the route information in a GeoPandas dataframe.

        """
        durations = [
            item["travelDuration"]
            for item in self.route["resourceSets"][0]["resources"][0]["routeLegs"][0][
                "itineraryItems"
            ]
        ]
        # change the duration to seconds
        durations = [self._duration_to_seconds(duration) for duration in durations]

        distances = [
            item["travelDistance"]
            for item in self.route["resourceSets"][0]["resources"][0]["routeLegs"][0][
                "itineraryItems"
            ]
        ]
        # change the distance to meters
        distances = [self._distance_to_meters(distance) for distance in distances]

        startPathIndices = []
        endPathIndices = []
        for item in self.route["resourceSets"][0]["resources"][0]["routeLegs"][0][
            "itineraryItems"
        ]:
            temp = []
            for detail in item["details"]:
                temp.append(detail["startPathIndices"][0])
                temp.append(detail["endPathIndices"][0])
            startPathIndices.append(min(temp))
            endPathIndices.append(max(temp))

        points = self.route["resourceSets"][0]["resources"][0]["routePath"]["line"][
            "coordinates"
        ]

        lines = []
        for start, end in zip(startPathIndices, endPathIndices):
            line_string = points[start : end + 1]
            # change the lon lat to lat lon
            line_string = [(point[1], point[0]) for point in line_string]

            # if the line string is just one point, return linestring with two same points
            if len(line_string) == 1:
                line_string = sg.LineString([line_string[0], line_string[0]])
            else:
                line_string = sg.LineString(line_string)
            lines.append(line_string)
            # # print(line_string)
            # # print(len(line_string))
            # try:
            #     lines.append(sg.LineString(line_string))
            # except:
            #     print(line_string)
            #     print(len(line_string))

        df = pd.DataFrame(
            {"distance (m)": distances, "duration (s)": durations, "geometry": lines}
        )
        gdf = gpd.GeoDataFrame(df, geometry="geometry", crs="EPSG:4326")
        gdf["speed (m/s)"] = gdf["distance (m)"] / gdf["duration (s)"]

        return gdf


class OSRMRoute:

    """
    This class represents a route returned by the OpenStreetMap Routing Machine API.

    Methods:
    - `get_duration()` -> float: Returns the duration of the route in seconds.
    - `get_distance()` -> float: Returns the distance of the route in meters.
    - `get_route()` -> dict: Returns the full route as a dictionary.
    - `get_route_geopandas()` -> geopandas.GeoDataFrame: Returns the route as a GeoDataFrame. The GeoDataFrame contains columns for 'duration (s)', 'distance (m)', 'geometry', and 'speed (m/s)'.
    """

    def __init__(self, route):
        self.route = route

    def get_duration(self):
        """
        Get the duration of the route in seconds.
        """
        return self.route["routes"][0]["duration"]

    def get_distance(self):
        """
        Get the distance of the route in meters.
        """
        return self.route["routes"][0]["distance"]

    def get_route(self):
        """
        Get the full route information as a dictionary.
        """
        return self.route

    def get_route_geopandas(self):
        """
        Get the route as a GeoDataFrame. The GeoDataFrame contains columns for 'duration (s)', 'distance (m)', 'geometry', and 'speed (m/s)'.
        """

        steps = []
        for step in self.route["routes"][0]["legs"][0]["steps"]:
            temp = {}
            temp["geometry"] = gpd.read_file(json.dumps(step["geometry"]))[
                "geometry"
            ].values[0]
            temp["duration (s)"] = step["duration"]
            temp["distance (m)"] = step["distance"]
            steps.append(temp)
        steps = pd.DataFrame(steps)
        # steps["geometry"] = steps["geometry"].map(gpd.read_file)
        steps = gpd.GeoDataFrame(steps, geometry="geometry", crs="4326")
        steps["speed (m/s)"] = steps["distance (m)"] / steps["duration (s)"]
        return steps


class EsriRoute:
    """
    The EsriRoute class is a class for handling a route obtained from the Esri ArcGIS routing service.

    The class has the following methods:

    - `get_duration`: returns the total travel time of the route.

    - `get_distance`: returns the total distance of the route in meters.

    - `get_route`: returns the entire route as a dictionary.

    - `get_route_geopandas`: raises a NotImplementedError. This method is not yet implemented and will be added in the future.


    """

    def __init__(self, route):
        self.route = route

    def get_duration(self):
        return (
            self.route["routes"]["features"][0]["attributes"]["Total_TravelTime"] * 60
        )

    def get_distance(self):
        return (
            self.route["routes"]["features"][0]["attributes"]["Total_Kilometers"] * 1000
        )

    def get_route(self):
        return self.route

    def get_route_geopandas(self):
        linestring = self.route["routes"]["features"][0]["geometry"]["paths"][0]
        gdf = gpd.GeoDataFrame(
            geometry=gpd.GeoSeries(sg.LineString(linestring)), crs="EPSG:4326"
        )

        gdf["speed (m/s)"] = self.get_distance() / self.get_duration()

        return gdf


class OSMNXRoute:
    def __init__(self, route):
        self.route = route[0]
        self.G = route[1]

    def _get_durations(self):
        # OSMnx 2.0+ compatible: manually extract edge attributes
        durations = []
        for u, v in zip(self.route[:-1], self.route[1:]):
            edge_data = self.G.get_edge_data(u, v)
            if edge_data:
                # For MultiDiGraph, edge_data is a dict of dicts
                first_edge = list(edge_data.values())[0]
                durations.append(first_edge.get('travel_time', 0))
        return durations

    def _get_distances(self):
        # OSMnx 2.0+ compatible: manually extract edge attributes
        distances = []
        for u, v in zip(self.route[:-1], self.route[1:]):
            edge_data = self.G.get_edge_data(u, v)
            if edge_data:
                # For MultiDiGraph, edge_data is a dict of dicts
                first_edge = list(edge_data.values())[0]
                distances.append(first_edge.get('length', 0))
        return distances

    def get_duration(self):
        durations = self._get_durations()

        return round(sum(durations))

    def get_distance(self):
        edge_lengths = self._get_distances()

        return round(sum(edge_lengths))

    def get_route(self):
        return self.route

    def get_route_geopandas(self):
        subgraph = self.G.subgraph(self.route)
        gdf_nodes, gdf_edges = ox.graph_to_gdfs(subgraph)

        # gdf_edges["duration (s)"] = self._get_durations()
        # gdf_edges["distance (m)"] = self._get_distances()
        # gdf_edges["speed (m/s)"] = gdf_edges["distance (m)"] / gdf_edges["duration (s)"]

        gdf_edges.rename(
            columns={"length": "distance (m)", "travel_time": "duration (s)"},
            inplace=True,
        )
        gdf_edges["speed (m/s)"] = gdf_edges["distance (m)"] / gdf_edges["duration (s)"]

        gdf_edges = gdf_edges[
            ["duration (s)", "distance (m)", "geometry", "speed (m/s)"]
        ]
        gdf_edges = gdf_edges.reset_index(drop=True)
        return gdf_edges


class BaiduRoute:
    """
    This class represents a route returned by the Baidu Maps Direction API.

    Methods:
    - `get_duration()` -> float: Returns the duration of the route in seconds.
    - `get_distance()` -> float: Returns the distance of the route in meters.
    - `get_route()` -> dict: Returns the full route as a dictionary.
    - `get_route_geopandas()` -> geopandas.GeoDataFrame: Returns the route as a GeoDataFrame.
    """

    def __init__(self, route):
        self.route = route

    def get_duration(self):
        """Get the duration of the route in seconds."""
        return self.route["result"]["routes"][0]["duration"]

    def get_distance(self):
        """Get the distance of the route in meters."""
        return self.route["result"]["routes"][0]["distance"]

    def get_route(self):
        """Get the full route information as a dictionary."""
        return self.route

    def get_route_geopandas(self):
        """
        Get the route as a GeoDataFrame. The GeoDataFrame contains columns for
        'duration (s)', 'distance (m)', 'geometry', and 'speed (m/s)'.
        """
        from shapely.geometry import LineString

        steps = []
        route_data = self.route["result"]["routes"][0]

        for step in route_data.get("steps", []):
            temp = {}
            # Baidu returns path as "lng,lat;lng,lat;..." string
            path_str = step.get("path", "")
            if path_str:
                coords = []
                for point in path_str.split(";"):
                    lng, lat = point.split(",")
                    coords.append((float(lng), float(lat)))
                temp["geometry"] = LineString(coords)
            else:
                # Fallback: create a simple line from start to end location
                start = step.get("start_location", {})
                end = step.get("end_location", {})
                if start and end:
                    temp["geometry"] = LineString([
                        (start.get("lng", 0), start.get("lat", 0)),
                        (end.get("lng", 0), end.get("lat", 0))
                    ])
                else:
                    continue

            temp["duration (s)"] = step.get("duration", 0)
            temp["distance (m)"] = step.get("distance", 0)
            steps.append(temp)

        if not steps:
            # If no steps, return empty GeoDataFrame
            return gpd.GeoDataFrame(
                columns=["geometry", "duration (s)", "distance (m)", "speed (m/s)"],
                crs="EPSG:4326"
            )

        df = pd.DataFrame(steps)
        gdf = gpd.GeoDataFrame(df, geometry="geometry", crs="EPSG:4326")
        gdf["speed (m/s)"] = gdf.apply(
            lambda row: row["distance (m)"] / row["duration (s)"] if row["duration (s)"] > 0 else 0,
            axis=1
        )
        return gdf


class TomTomRoute:
    """
    This class represents a route returned by the TomTom Routing API.

    Methods:
    - `get_duration()` -> float: Returns the duration of the route in seconds.
    - `get_distance()` -> float: Returns the distance of the route in meters.
    - `get_route()` -> dict: Returns the full route as a dictionary.
    - `get_route_geopandas()` -> geopandas.GeoDataFrame: Returns the route as a GeoDataFrame.
    """

    def __init__(self, route):
        self.route = route

    def _first_route(self):
        return (self.route.get("routes") or [None])[0] or {}

    def get_duration(self):
        """Get the duration of the route in seconds."""
        summary = self._first_route().get("summary", {})
        return summary.get("travelTimeInSeconds", 0)

    def get_distance(self):
        """Get the distance of the route in meters."""
        summary = self._first_route().get("summary", {})
        return summary.get("lengthInMeters", 0)

    def get_route(self):
        """Get the full route information as a dictionary."""
        return self.route

    def get_route_geopandas(self):
        """
        Get the route as a GeoDataFrame. The GeoDataFrame contains columns for
        'duration (s)', 'distance (m)', 'geometry', and 'speed (m/s)'.
        """
        route_data = self._first_route()
        legs = route_data.get("legs", [])
        steps = []

        for leg in legs:
            points = leg.get("points", [])
            if not points:
                continue
            geometry = LineString(
                [(p["longitude"], p["latitude"]) for p in points]
            )
            summary = leg.get("summary", {})
            distance = summary.get("lengthInMeters", leg.get("lengthInMeters", 0))
            duration = summary.get("travelTimeInSeconds", leg.get("travelTimeInSeconds", 0))
            steps.append(
                {"distance (m)": distance, "duration (s)": duration, "geometry": geometry}
            )

        if not steps:
            # If no legs were parsed, return an empty GeoDataFrame with expected columns
            return gpd.GeoDataFrame(
                columns=["distance (m)", "duration (s)", "geometry", "speed (m/s)"],
                geometry="geometry",
                crs="EPSG:4326",
            )

        gdf = gpd.GeoDataFrame(steps, geometry="geometry", crs="EPSG:4326")
        gdf["speed (m/s)"] = gdf.apply(
            lambda row: row["distance (m)"] / row["duration (s)"]
            if row["duration (s)"]
            else 0,
            axis=1,
        )
        return gdf


class MapboxRoute:
    def __init__(self, route):
        self.route = route

    def get_duration(self):
        return self.route["routes"][0]["duration"]

    def get_distance(self):
        return self.route["routes"][0]["distance"]

    def get_route(self):
        return self.route

    def get_route_geopandas(self):
        """
        Returns a GeoDataFrame with distance, duration, and speed for the route legs.
        """
        steps = []
        route0 = self.route.get("routes", [{}])[0]

        # Prefer step-level geometries; fall back to full route geometry if missing
        for leg in route0.get("legs", []):
            for step in leg.get("steps", []):
                geom_dict = step.get("geometry")
                if not geom_dict:
                    continue
                geometry = sg.shape(geom_dict)
                duration = step.get("duration", 0)
                distance = step.get("distance", 0)
                steps.append(
                    {
                        "duration (s)": duration,
                        "distance (m)": distance,
                        "geometry": geometry,
                    }
                )

        if not steps and route0.get("geometry"):
            geometry = sg.shape(route0["geometry"])
            steps.append(
                {
                    "duration (s)": route0.get("duration", 0),
                    "distance (m)": route0.get("distance", 0),
                    "geometry": geometry,
                }
            )

        if not steps:
            return gpd.GeoDataFrame(
                columns=["duration (s)", "distance (m)", "geometry", "speed (m/s)"],
                geometry="geometry",
                crs="EPSG:4326",
            )

        gdf = gpd.GeoDataFrame(steps, geometry="geometry", crs="EPSG:4326")
        gdf["speed (m/s)"] = gdf.apply(
            lambda row: row["distance (m)"] / row["duration (s)"]
            if row["duration (s)"]
            else 0,
            axis=1,
        )
        return gdf


class HereRoute:
    def __init__(self, route):
        self.route = route

    def get_duration(self):
        # HERE Routing 7.2 style response
        if "response" in self.route:
            return self.route["response"]["route"][0]["summary"]["travelTime"]
        # HERE Matrix style summary not supported here
        return 0

    def get_distance(self):
        if "response" in self.route:
            return self.route["response"]["route"][0]["summary"]["distance"]
        return 0

    def get_route(self):
        return self.route

    def get_route_geopandas(self):
        """
        Build a GeoDataFrame from the first route leg's shape coordinates.
        """
        if "response" not in self.route:
            return gpd.GeoDataFrame(
                columns=["duration (s)", "distance (m)", "geometry", "speed (m/s)"],
                geometry="geometry",
                crs="EPSG:4326",
            )

        # HERE 7.2 response structure
        leg = (
            self.route["response"]
            .get("route", [{}])[0]
            .get("leg", [{}])[0]
        )
        shape = leg.get("shape", [])
        coords = []
        for pt in shape:
            try:
                lat, lon = pt.split(",")
                coords.append((float(lon), float(lat)))
            except Exception:
                continue
        if not coords:
            return gpd.GeoDataFrame(
                columns=["duration (s)", "distance (m)", "geometry", "speed (m/s)"],
                geometry="geometry",
                crs="EPSG:4326",
            )

        geometry = sg.LineString(coords)
        duration = self.get_duration()
        distance = self.get_distance()
        gdf = gpd.GeoDataFrame(
            [{"duration (s)": duration, "distance (m)": distance, "geometry": geometry}],
            geometry="geometry",
            crs="EPSG:4326",
        )
        gdf["speed (m/s)"] = gdf.apply(
            lambda row: row["distance (m)"] / row["duration (s)"]
            if row["duration (s)"]
            else 0,
            axis=1,
        )
        return gdf


class MapQuestRoute:
    def __init__(self, route):
        self.route = route

    def get_duration(self):
        return self.route["route"]["time"]

    def get_distance(self):
        return self.route["route"]["distance"]

    def get_route(self):
        return self.route

    def get_route_geopandas(self):
        raise NotImplementedError


class ORSRoute:
    """
    OpenRouteService route wrapper.
    """

    def __init__(self, route):
        self.route = route

    def _first_route(self):
        return (self.route.get("routes") or [None])[0] or {}

    def get_duration(self):
        route0 = self._first_route()
        summary = route0.get("summary", {})
        return summary.get("duration", 0)

    def get_distance(self):
        route0 = self._first_route()
        summary = route0.get("summary", {})
        return summary.get("distance", 0)

    def get_route(self):
        return self.route

    def get_route_geopandas(self):
        """
        Returns a GeoDataFrame with distance, duration, and speed.
        """
        route0 = self._first_route()
        segments = route0.get("segments", [])
        steps = []

        # Decode geometry if encoded polyline, else try GeoJSON
        geometry = None
        geom_raw = route0.get("geometry")
        if isinstance(geom_raw, str):
            # ORS uses encoded polyline with precision 5
            coords = polyline.decode(geom_raw, 5)
            geometry = sg.LineString([(c[1], c[0]) for c in coords])
        elif geom_raw:
            geometry = sg.shape(geom_raw)

        for seg in segments:
            duration = seg.get("duration", 0)
            distance = seg.get("distance", 0)
            if geometry is None:
                continue
            steps.append(
                {"duration (s)": duration, "distance (m)": distance, "geometry": geometry}
            )

        if not steps and route0.get("geometry"):
            if geometry is None:
                geom_raw = route0.get("geometry")
                if isinstance(geom_raw, str):
                    coords = polyline.decode(geom_raw, 5)
                    geometry = sg.LineString([(c[1], c[0]) for c in coords])
                else:
                    geometry = sg.shape(geom_raw)
            steps.append(
                {
                    "duration (s)": self.get_duration(),
                    "distance (m)": self.get_distance(),
                    "geometry": geometry,
                }
            )

        if not steps:
            return gpd.GeoDataFrame(
                columns=["duration (s)", "distance (m)", "geometry", "speed (m/s)"],
                geometry="geometry",
                crs="EPSG:4326",
            )

        gdf = gpd.GeoDataFrame(steps, geometry="geometry", crs="EPSG:4326")
        gdf["speed (m/s)"] = gdf.apply(
            lambda row: row["distance (m)"] / row["duration (s)"]
            if row["duration (s)"]
            else 0,
            axis=1,
        )
        return gdf


class Route(object):
    """
    A wrapper class that wraps different routing engines' route objects.

    It will return a Route object that can be used to get the duration, distance, and route information.

    The class has the following methods:

    - `get_duration()`: Returns the duration of the route in seconds.

    - `get_distance()`: Returns the distance of the route in meters.

    - `get_route()`: Returns the complete route information.

    - `get_route_geopandas()`: Returns a GeoDataFrame with information such as distance, duration, and speed of each step in the route.

    """

    def __init__(self, route, origin, destination):
        """
        Initialize a Route object by passing the routing engine's route object.

        :param route: An instance of a routing engine's route object
        """
        self.route = route
        self.origin = origin
        self.destination = destination

    def get_duration(self):
        """
        Get the duration of the route.
        """
        return self.route.get_duration()

    def get_distance(self):
        """
        Get the distance of the route.
        """
        return self.route.get_distance()

    def get_route(self):
        """
        Get the raw route information.
        """
        return self.route.get_route()

    def get_route_geopandas(self):
        """
        Get the route information as a GeoDataFrame.
        """
        return self.route.get_route_geopandas()

    def plot_route(self):
        """
        Plot the route on a map.
        """
        gdf = self.get_route_geopandas()
        m = gdf.explore(
            column="speed (m/s)",
            style_kwds={"weight": 11, "opacity": 0.8},
            cmap="RdYlGn",
        )
        # add a red destination marker, don't show i in the map
        folium.Marker(
            [self.destination[0], self.destination[1]],
            icon=folium.Icon(
                color="red", icon_color="white", icon="circle", prefix="fa"
            ),
        ).add_to(m)

        # folium.Marker([one_od_pair["AHA_ID_lat"],one_od_pair["AHA_ID_lon"]],
        # icon=folium.Icon(color="red",icon_color="white",icon="circle", prefix="fa")).add_to(m)

        return m


# base class for routers
class BaseRouter(object):

    """
    The class BaseRouter serves as a base class for routers, which are used to compute the optimal route between two points. The class has an instance variable mode, which is a string that defines the mode of transportation (e.g. "driving").

    The BaseRouter class has a single method _get_OD_matrix, which takes two arguments origins and destinations and returns an origin-destination matrix. The method creates an empty list items and loops through each origin and destination pair, appending the concatenated origin and destination to the list. The origin-destination matrix is then created from the list items and returned.
    """

    def __init__(self, mode="driving"):
        self.mode = mode

    def _get_OD_matrix(self, origins, destinations):
        items = []
        for i in origins:
            for j in destinations:
                item = i + j
                items.append(item)
        od_matrix = pd.DataFrame(
            items,
            columns=["origin_lat", "origin_lon", "destination_lat", "destination_lon"],
        )

        return od_matrix

    # def get_route(self, origin, destination):
    #     return Route(self._get_request(origin, destination))

    def get_distances_batch(
        self, origins, destinations, max_batch_size=25, append_od=False
    ):
        """
        This method returns a Pandas dataframe contains duration and disatnce for all the `origins` and `destinations` pairs. Use this function if you don't want to get duration and distance for all possible combinations between each origin and each destination.

        The origins and destinations parameters are lists of origin-destination pairs. They should be the same length.

        If the `append_od` parameter is set to True, the method also returns the input origin-destination pairs.
        """

        # convert the origins and destinations to lists
        origins = gtl.convert_to_list(origins)
        destinations = gtl.convert_to_list(destinations)

        # check if the origins and destinations are the same length
        if len(origins) != len(destinations):
            raise ValueError(
                "The origins and destinations should have the same length."
            )

        # divide the origins and destinations into batches

        batches = gtl.get_batch_od_pairs(origins, destinations, max_batch_size)

        # get the distance matrix for each batch
        results = []
        for batch in batches:
            res = self.get_distance_matrix(batch[0], batch[1])
            results.append(res)

        # concatenate the results
        df = pd.concat(results, axis=0)
        # revert the order of the rows
        df = df.iloc[::-1]

        if append_od:
            # convert the origins and destinations to numpy arrays
            origins = np.array(origins)
            destinations = np.array(destinations)
            df["origin_lat"] = origins[:, 0]
            df["origin_lon"] = origins[:, 1]
            df["destination_lat"] = destinations[:, 0]
            df["destination_lon"] = destinations[:, 1]

            df = df[
                [
                    "origin_lat",
                    "origin_lon",
                    "destination_lat",
                    "destination_lon",
                    "distance (m)",
                    "duration (s)",
                ]
            ]

        return df


# add documenation for the class
class WebRouter(BaseRouter):
    """
    The WebRouter class is a class for handling a route obtained from a web-based routing service.

    """

    def __init__(
        self, api_key, mode="driving", timeout=10, language="en", base_url=None
    ):
        self.api_key = api_key
        self.timeout = timeout
        self.language = language
        super().__init__(mode=mode)

    def _get_request(self, url):
        """
        Helper function to make a request to the web-based routing service.
        """

        try:
            response = requests.get(url, timeout=self.timeout)
            response.raise_for_status()
        except requests.exceptions.HTTPError as errh:
            print("Http Error:", errh)

        return response.json()


# make a class for local router
class LocalRouter(BaseRouter):
    def __init__(self, mode="driving"):
        self.mode = mode

    def get_route_time_distance(self, origin, destination):
        raise NotImplementedError

    def get_route_time_distance_matrix(self, origins, destinations):
        raise NotImplementedError

    def get_route_geopandas(self, origin, destination):
        raise NotImplementedError

    def get_route_geopandas_matrix(self, origins, destinations):
        raise NotImplementedError
