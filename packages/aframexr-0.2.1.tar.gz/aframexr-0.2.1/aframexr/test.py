"""Fichero para pruebas de AframeXR"""

import webbrowser
import aframexr

url_data = aframexr.URLData('https://davidlab20.github.io/TFG/examples/data/data.json')
pieChartJSON = aframexr.Chart(url_data, position="-3 5 -8").mark_arc().encode(color='model', theta='sales')
barsChartJSON = aframexr.Chart(url_data, position="0 0 -8").mark_bar().encode(x='model', y='sales')
bubblePlotJSON = aframexr.Chart(url_data).mark_point().encode(x='model', y='sales')
finalChart = pieChartJSON + barsChartJSON + bubblePlotJSON
finalChart.save('test.html')
#webbrowser.open('test.html')
