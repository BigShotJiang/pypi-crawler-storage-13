from uuid import UUID


IdentifierValueType = int | UUID
ValueType = bool | float | int | str | None
