import sys
from jennifer.agent import jennifer_agent
from jennifer.pconstants import *
from .util import VersionInfo

__hooking_module__ = 'httpx'
__minimum_python_version__ = VersionInfo("3.8.0")
_original_httpx_request_async = None
_original_httpx_request_sync = None
__target_version = None


global parse_url_func


def get_target_version():
    global __target_version
    return str(__target_version)


def import_module():
    return __import__(__hooking_module__)


def parse_url2(url):
    from urlparse import urlparse
    return urlparse(url)


def parse_url3(url):
    from urllib import parse
    return parse.urlparse(url)


def _safe_get(properties, idx, default=None):
    try:
        return properties[idx]
    except IndexError:
        return default


def wrap_request_async(origin):
    global parse_url_func

    if sys.version_info.major == 3:
        parse_url_func = parse_url3
    else:
        parse_url_func = parse_url2

    async def handler(self, method, url, **kwargs):
        o = None
        pi = None

        urlx = str(url)
        user_headers = kwargs.get('headers')

        try:
            agent = jennifer_agent()
            if agent is not None:
                o = agent.current_active_object()

                if o is not None:
                    url_info = parse_url_func(urlx)
                    pi = o.profiler.start_external_call(
                        call_type=url_info.scheme,
                        host=url_info.hostname,
                        port=url_info.port or 80,
                        url=urlx,
                        caller='httpx.request_async')

                    if agent.app_config.topology_mode is True:
                        if user_headers is None:
                            user_headers = {}

                        user_headers[agent.app_config.guid_http_header_key] = o.guid
                        user_headers[agent.app_config.topology_http_header_key] = str(o.outgoing_key)
                        user_headers[X_DOMAIN_ID] = str(o.outgoing_sid)
                        user_headers[X_AGENT_ID] = str(o.outgoing_agent_id)
        except Exception as e:
            pass

        err = None
        resp = None

        try:
            resp = await origin(self, method, url, **kwargs)
        except Exception as e:
            err = e

        try:
            if pi is not None:
                key = resp.headers.get(agent.app_config.topology_http_header_key, 0)
                sid = resp.headers.get(X_DOMAIN_ID, 0)
                agent_id = resp.headers.get(X_AGENT_ID, 0)

                o.profiler.end_external_call(pi, err, request_key=key, domain_id=sid, agent_id=agent_id)
        except:
            pass

        if err is not None:
            raise err

        return resp

    return handler


def wrap_request_sync(origin):
    global parse_url_func

    if sys.version_info.major == 3:
        parse_url_func = parse_url3
    else:
        parse_url_func = parse_url2

    def handler(self, method, url, **kwargs):
        o = None
        pi = None

        urlx = str(url)

        user_headers = kwargs.get('headers')

        try:
            agent = jennifer_agent()
            if agent is not None:
                o = agent.current_active_object()

                if o is not None:
                    url_info = parse_url_func(urlx)
                    pi = o.profiler.start_external_call(
                        call_type=url_info.scheme,
                        host=url_info.hostname,
                        port=url_info.port or 80,
                        url=urlx,
                        caller='httpx.request')

                    if agent.app_config.topology_mode is True:
                        if user_headers is None:
                            user_headers = {}

                        user_headers[agent.app_config.guid_http_header_key] = o.guid
                        user_headers[agent.app_config.topology_http_header_key] = str(o.outgoing_key)
                        user_headers[X_DOMAIN_ID] = str(o.outgoing_sid)
                        user_headers[X_AGENT_ID] = str(o.outgoing_agent_id)
        except Exception as e:
            pass

        err = None
        resp = None

        try:
            resp = origin(self, method, url, **kwargs)
        except Exception as e:
            err = e

        try:
            if pi is not None:
                key = resp.headers.get(agent.app_config.topology_http_header_key, 0)
                sid = resp.headers.get(X_DOMAIN_ID, 0)
                agent_id = resp.headers.get(X_AGENT_ID, 0)

                o.profiler.end_external_call(pi, err, request_key=key, domain_id=sid, agent_id=agent_id)
        except:
            pass

        if err is not None:
            raise err

        return resp
    return handler


def unhook(httpx_module):
    global _original_httpx_request_sync
    global _original_httpx_request_async

    if _original_httpx_request_sync is not None:
        httpx_module.Client.request = _original_httpx_request_sync

    if _original_httpx_request_async is not None:
        httpx_module.AsyncClient.request = _original_httpx_request_async

def hook(httpx_module):
    global _original_httpx_request_sync
    global _original_httpx_request_async

    global __target_version
    if 'wrap_send.' in str(httpx_module.Client.request):
        return False

    __target_version = httpx_module.__version__

    _original_httpx_request_sync = httpx_module.Client.request
    _original_httpx_request_async = httpx_module.AsyncClient.request

    httpx_module.Client.request = wrap_request_sync(_original_httpx_request_sync)
    httpx_module.AsyncClient.request = wrap_request_async(_original_httpx_request_async)
    return True
