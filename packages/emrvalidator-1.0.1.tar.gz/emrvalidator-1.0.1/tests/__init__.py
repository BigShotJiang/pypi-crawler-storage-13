"""
Tests for EMRValidator library
"""
