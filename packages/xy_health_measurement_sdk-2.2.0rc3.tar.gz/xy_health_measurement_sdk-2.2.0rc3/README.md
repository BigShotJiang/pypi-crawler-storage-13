# 小阳心健康测量SDK

[使用手册](https://measurement. measurement.cn/docs/sdk/python.html)

## C++ SDK集成

项目中`xy_health_measurement_sdk/resources/libmeasurement.so`依赖需要基于实际部署环境自行编译。本地调试与Docker基础镜像中操作系统环境不一致，使用的`measurement/resources/libmeasurement.so`及其依赖项（如OpenCV等）版本也不同。默认`libmeasurement.so`为Docker镜像版本，如需本地调试，需要自行编译开发环境本并替换。

```bash
cd ../measurement_cpp_client_sdk

# 本地编译
sudo bash build.sh
# 容器编译
mac docker run -it --rm -v $PWD:/app registry.cn-shanghai.aliyuncs.com/measurement/cpp-client-sdk:builder
cd /app && bash build.sh

# 退出容器并拷贝动态库
cd - && cp ../measurement_cpp_client_sdk/cmake-build-release/libmeasurement.so xy_health_measurement_sdk/resources
```

根据不同动态库版本，当前SDK编译为不同版本：本地编译版本版本号为`dev*`，供调试使用。容器编译版本号`rc*`或数字系列，供正式发布和部署使用。
发布时按需调试版本号即可。

## SDK包压缩

- 当前SDK包中`mediapipe`依赖了`opencv-contrib-python`(全量OpenCV版本)、`torch`和`numpy`。opencv和torch包体量较大，且其Python无运行时版本，暂时无法压缩。

## 调试运行

### 本地调试

推荐使用本地Conda解释器。

```bash
conda create -n measurement_client_sdk -y python=3.10 && \
conda activate measurement_client_sdk && \
conda install -y -c conda-forge libstdcxx-ng && \
pip install build toml twine setuptools && \
pip install -r <(python -c "import toml; print('\n'.join(toml.load('pyproject.toml')['project']['dependencies']))")
```

### Docker调试

```bash
SDK_VERSION=2.2.0rc3
# 镜像编译
mac docker buildx build --platform linux/amd64 \
  --build-arg SDK_VERSION=${SDK_VERSION} \
  --build-arg ACCELERATE_CONFIG='--trusted-host packages.aliyun.com -i https://62629dda4e333f02816fb492:%284dbBWuBUHY8@packages.aliyun.com/62629ddec2b7347ce520e075/pypi/xy' \
  -t registry.cn-shanghai.aliyuncs.com/measurement/python-client-sdk:${SDK_VERSION} \
  -t registry.cn-shanghai.aliyuncs.com/measurement/python-client-sdk:latest .

# 运行容器
mac docker run -it --rm \
  -v $PWD:/app \
  -e "PYTHONPATH=/app/:/app/test/" \
  --env-file test/.env \
  registry.cn-shanghai.aliyuncs.com/measurement/python-client-sdk:${SDK_VERSION}
cd test && python3 VideoFileSample.py
```

## 发布

```bash
sudo rm -rf dist *.egg-info && \
python -m build

# publish to aliyun pypi
twine upload -r packages-pypi dist/*
# publish to pypi
python -m twine upload dist/*
```

## 小阳心健康测量客户端SDK 工作流简述

SDK 用于通过视频数据（视频文件或视频流等）进行健康测量。
- `Android/iOS/Web/Python` 等不同平台 SDK 均使用相同的工作流程，仅开发语言不同。当前文档以`Python SDK`为例。
- SDK 所使用数据模型均基于`google protobuf`库所定义跨平台模型
- SDK 数据校验相关类型和异常定义等均使用`Validation（proto）` + `ClientSdkConfig.json`。（相关文件均定义在[`Measurement/Resources`](https://codeup.aliyun.com/xytech/measurement/resource/blob/master/ClientSdkConfig.json)项目下）

  ![Resource](./resources.png)

以下是其主要工作流程的简要说明：

1. 初始化

- 开发者首先创建`Measurement`类的实例，并提供`app_id`、`sdk_key`等认证信息及其他可选配置。这个`Measurement`类是与 SDK 交互的主要入口。

2. 开始测量

- 通过调用`Measurement`实例的`start()`方法并传入初始视频帧来启动测量。
- 这个操作会创建一个名为`MeasurerProcess`的独立进程，专门负责处理核心的测量任务，从而避免阻塞主程序。

3. 认证与连接

- 在`MeasurerProcess`进程中，会创建一个`Rpcer`（RPC客户端）实例。
- `Rpcer`会利用传入的认证信息向服务器请求并获取一个访问令牌（`token`）。
- 获取令牌后，`Rpcer`会建立一个到测量服务器的`WebSocket`长连接。

4. 创建测量会话

- `MeasurerProcess`通过`Rpcer`将初始视频帧发送给服务器，请求创建一个新的测量会话。
- 服务器会返回一个唯一的`measurement_id`作为本次测量的标识。

5. 视频帧处理

- 主程序会持续捕获视频帧，并通过`Measurement`实例的`enqueue()`方法将视频帧放入一个共享的队列中。
- `MeasurerProcess`进程会不断地从队列中取出视频帧进行处理：
  - **人脸检测与验证**: 利用`SignalProcessor`模块检测人脸关键点，并验证当前环境是否满足测量条件（如人脸是否清晰、距离是否合适等）。
  - **特征提取**: `FeatureExtractor`模块会处理视频帧和人脸关键点，提取出用于健康分析的生理信号，并将这些信号打包成数据块（`chunk`）。
  - **数据上传**: 当一个数据块准备好后，`MeasurerProcess`会通过`Rpcer`将其上传到服务器。

6. 接收测量报告

- `Rpcer`会持续监听`WebSocket`连接，接收来自服务器的事件。
- 服务器在处理数据块后，会实时发回阶段性的测量报告（如心率报告），SDK 会触发`chunk_report_generated`事件。
- 当整个测量过程结束后，服务器会发送一份完整的测量报告，SDK 则会触发`whole_report_generated`事件。

7. 停止测量

- 测量可以通过调用`stop()`方法主动停止，也可能因为发生错误或达到设定的测量时长而结束。 
- 停止测量后，`MeasurerProcess`进程会结束，并断开与服务器的连接。

总的来说，SDK 采用的是 主进程+工作进程 的多进程架构。主进程负责视频采集和UI交互，而工作进程则在后台负责核心的计算密集型任务（如特征提取）和与服务器的网络通信。`test/Sample.py`文件提供了一个如何使用该 SDK 的示例，展示了如何通过订阅事件的方式来获取测量数据和报告。

--- 

## 架构分析与优化建议

当前的架构（主进程 + CPU密集型工作进程）是解决Python中GIL（全局解释器锁）限制、避免UI阻塞的一个非常标准且有效的模式。

### 当前架构的合理性与优势

1.  **规避GIL（全局解释器锁）**：这是在Python中采用多进程（`multiprocessing`）而非多线程（`threading`）来处理CPU密集型任务的**最主要原因**。GIL的存在使得同一个Python进程中的多个线程无法在同一时刻利用多核CPU并行执行。而多个进程则拥有各自独立的Python解释器和内存空间，可以被操作系统调度到不同的CPU核心上，实现真正的并行计算。对于视频帧处理这种计算密集型任务，使用多进程是完全正确的选择。

2.  **主进程/UI响应性**：将耗时的计算任务移到独立的`MeasurerProcess`中，确保了主进程（通常负责视频采集和UI渲染）不会被阻塞。这对于提供流畅的用户体验至关重要。

3.  **鲁棒性**：工作进程的崩溃不会直接导致主进程崩溃。主进程可以捕获到工作进程的异常退出，并进行相应的处理（如重启进程、提示用户等），增强了整个应用的稳定性。