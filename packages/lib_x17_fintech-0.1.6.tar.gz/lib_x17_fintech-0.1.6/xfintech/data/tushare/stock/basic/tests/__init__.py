# Basic stock data tests
