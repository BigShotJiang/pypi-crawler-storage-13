from datetime import datetime

import pandas as pd

from xfintech.data.tushare.stock.market.daycdm import Daycdm


class FakeConnection:
    def __init__(self, frame: pd.DataFrame):
        self.frame = frame

    def stk_factor_pro(self, **kwargs):
        return self.frame


class FakeSession:
    def __init__(self, connection: FakeConnection):
        self.connection = connection


def test_daycdm_resolve_conf_defaults():
    fake_conn = FakeConnection(frame=pd.DataFrame())
    session = FakeSession(fake_conn)
    job = Daycdm(session=session)
    assert job.conf.coolant == 2
    assert job.conf.size == 10000
    job.clean()


def test_daycdm_resolve_conf_with_params():
    fake_conn = FakeConnection(frame=pd.DataFrame())
    session = FakeSession(fake_conn)
    job = Daycdm(
        session=session,
        conf={
            "params": {
                "ts_code": "000001.SZ,600000.SH",
                "start_date": "20240101",
                "end_date": "20240131",
            },
            "size": 5000,
        },
    )
    params = job.conf.get_params()
    assert params["ts_code"] == "000001.SZ,600000.SH"
    assert params["start_date"] == "20240101"
    assert params["end_date"] == "20240131"
    assert job.conf.size == 5000
    job.clean()


def test_daycdm_resolve_conf_datetime_conversion():
    fake_conn = FakeConnection(frame=pd.DataFrame())
    session = FakeSession(fake_conn)
    job = Daycdm(
        session=session,
        conf={
            "params": {
                "trade_date": datetime(2024, 1, 15),
                "start_date": datetime(2024, 1, 1),
                "end_date": datetime(2024, 1, 31),
            }
        },
    )
    params = job.conf.get_params()
    assert params["trade_date"] == "20240115"
    assert params["start_date"] == "20240101"
    assert params["end_date"] == "20240131"
    job.clean()


def test_daycdm_resolve_conf_size_limit():
    fake_conn = FakeConnection(frame=pd.DataFrame())
    session = FakeSession(fake_conn)
    job = Daycdm(
        session=session,
        conf={
            "size": 20000,
            "coolant": 0.5,
        },
    )
    assert job.conf.size == 10000
    assert job.conf.coolant == 2
    job.clean()


def test_daycdm_transform_basic():
    data = pd.DataFrame(
        {
            "ts_code": ["000001.SZ", "000002.SZ", "600000.SH"],
            "trade_date": ["20241201", "20241201", "20241201"],
            "change": [0.50, -0.30, 0.80],
            "pct_chg": [2.5, -1.5, 3.2],
            "vol": [1000000, 2000000, 1500000],
            "amount": [50000, 100000, 75000],
            "turnover_rate": [3.5, 4.2, 2.8],
            "turnover_rate_f": [3.8, 4.5, 3.1],
            "volume_ratio": [1.2, 0.9, 1.5],
            "pe": [15.5, 20.3, 18.7],
            "pe_ttm": [16.2, 21.1, 19.4],
            "pb": [2.3, 3.5, 2.8],
            "ps": [1.5, 2.2, 1.8],
            "ps_ttm": [1.6, 2.3, 1.9],
            "dv_ratio": [2.5, 1.8, 3.2],
            "dv_ttm": [2.6, 1.9, 3.3],
            "total_share": [1000000, 2000000, 1500000],
            "float_share": [800000, 1800000, 1200000],
            "free_share": [700000, 1600000, 1000000],
            "total_mv": [5000000, 8000000, 6000000],
            "circ_mv": [4000000, 7200000, 4800000],
            "adj_factor": [1.5, 1.8, 1.2],
            "downdays": [0, 2, 0],
            "updays": [3, 0, 5],
            "lowdays": [10, 5, 15],
            "topdays": [20, 8, 25],
            "open": [20.5, 19.8, 25.3],
            "high": [21.2, 20.5, 26.1],
            "low": [20.1, 19.2, 25.0],
            "close": [20.8, 19.5, 25.8],
        }
    )
    fake_conn = FakeConnection(frame=data)
    session = FakeSession(fake_conn)
    job = Daycdm(session=session)
    result = job.transform(data)
    assert len(result) == 3
    assert "code" in result.columns
    assert "date" in result.columns
    assert "datecode" in result.columns
    assert "change" in result.columns
    assert "percent_change" in result.columns
    assert "volume" in result.columns
    assert "amount" in result.columns
    assert pd.api.types.is_datetime64_any_dtype(result["date"])
    assert result.iloc[0]["datecode"] == "20241201"
    assert result.iloc[0]["change"] == 0.50
    assert result.iloc[0]["percent_change"] == 2.5
    assert result.iloc[0]["volume"] == 1000000
    job.clean()


def test_daycdm_transform_empty_data():
    fake_conn = FakeConnection(frame=pd.DataFrame())
    session = FakeSession(fake_conn)
    job = Daycdm(session=session)
    result = job.transform(None)
    assert result.empty
    assert len(result.columns) == len(job.output.list_column_names())

    empty_df = pd.DataFrame()
    result = job.transform(empty_df)
    assert result.empty
    assert len(result.columns) == len(job.output.list_column_names())
    job.clean()


def test_daycdm_transform_data_quality():
    data = pd.DataFrame(
        {
            "ts_code": ["000001.SZ", "000001.SZ", "000002.SZ"],
            "trade_date": ["20241201", "20241201", "invalid_date"],
            "change": [0.50, 0.50, -0.30],
            "pct_chg": [2.5, 2.5, -1.5],
            "vol": [1000000, 1000000, 2000000],
            "amount": [50000, 50000, 100000],
            "turnover_rate": [3.5, 3.5, 4.2],
            "turnover_rate_f": [3.8, 3.8, 4.5],
            "volume_ratio": [1.2, 1.2, 0.9],
            "pe": [15.5, 15.5, 20.3],
            "pe_ttm": [16.2, 16.2, 21.1],
            "pb": [2.3, 2.3, 3.5],
            "ps": [1.5, 1.5, 2.2],
            "ps_ttm": [1.6, 1.6, 2.3],
            "dv_ratio": [2.5, 2.5, 1.8],
            "dv_ttm": [2.6, 2.6, 1.9],
            "total_share": [1000000, 1000000, 2000000],
            "float_share": [800000, 800000, 1800000],
            "free_share": [700000, 700000, 1600000],
            "total_mv": [5000000, 5000000, 8000000],
            "circ_mv": [4000000, 4000000, 7200000],
            "adj_factor": [1.5, 1.5, 1.8],
            "downdays": [0, 0, 2],
            "updays": [3, 3, 0],
            "lowdays": [10, 10, 5],
            "topdays": [20, 20, 8],
            "open": [20.5, 20.5, 19.8],
            "high": [21.2, 21.2, 20.5],
            "low": [20.1, 20.1, 19.2],
            "close": [20.8, 20.8, 19.5],
        }
    )
    fake_conn = FakeConnection(frame=data)
    session = FakeSession(fake_conn)
    job = Daycdm(session=session)
    result = job.transform(data)
    assert len(result) == 2

    invalid_row = result[result["code"] == "000002.SZ"].iloc[0]
    assert pd.isna(invalid_row["date"])
    job.clean()


def test_daycdm_run_and_cache():
    data = pd.DataFrame(
        {
            "ts_code": ["000001.SZ", "000002.SZ"],
            "trade_date": ["20241201", "20241201"],
            "change": [0.50, -0.30],
            "pct_chg": [2.5, -1.5],
            "vol": [1000000, 2000000],
            "amount": [50000, 100000],
            "turnover_rate": [3.5, 4.2],
            "turnover_rate_f": [3.8, 4.5],
            "volume_ratio": [1.2, 0.9],
            "pe": [15.5, 20.3],
            "pe_ttm": [16.2, 21.1],
            "pb": [2.3, 3.5],
            "ps": [1.5, 2.2],
            "ps_ttm": [1.6, 2.3],
            "dv_ratio": [2.5, 1.8],
            "dv_ttm": [2.6, 1.9],
            "total_share": [1000000, 2000000],
            "float_share": [800000, 1800000],
            "free_share": [700000, 1600000],
            "total_mv": [5000000, 8000000],
            "circ_mv": [4000000, 7200000],
            "adj_factor": [1.5, 1.8],
            "downdays": [0, 2],
            "updays": [3, 0],
            "lowdays": [10, 5],
            "topdays": [20, 8],
            "open": [20.5, 19.8],
            "high": [21.2, 20.5],
            "low": [20.1, 19.2],
            "close": [20.8, 19.5],
        }
    )
    fake_conn = FakeConnection(frame=data)
    session = FakeSession(fake_conn)
    job = Daycdm(session=session)
    result = job.run()
    assert len(result) == 2
    assert "_run" in job.cache

    cached_data = job.cache.get("_run")
    assert len(cached_data) == 2
    pd.testing.assert_frame_equal(result, cached_data)
    job.clean()


def test_daycdm_source_and_output_config():
    fake_conn = FakeConnection(frame=pd.DataFrame())
    session = FakeSession(fake_conn)
    job = Daycdm(session=session)
    assert job.source.name == "stk_factor_pro"
    assert "tushare.pro" in job.source.url
    assert "ts_code" in job.source.args
    assert job.output.name == "daycdm"
    assert job.tags["name"] == "daycdm"
    assert job.tags["module"] == "stock"
    assert job.tags["level"] == "market"
    assert job.tags["frequency"] == "interday"
    assert job.tags["scope"] == "stk_factor_pro"
    job.clean()


def test_daycdm_multi_stock_sorting():
    data = pd.DataFrame(
        {
            "ts_code": ["600000.SH", "000001.SZ", "000002.SZ"],
            "trade_date": ["20241203", "20241201", "20241202"],
            "change": [0.80, 0.50, -0.30],
            "pct_chg": [3.2, 2.5, -1.5],
            "vol": [1500000, 1000000, 2000000],
            "amount": [75000, 50000, 100000],
            "turnover_rate": [2.8, 3.5, 4.2],
            "turnover_rate_f": [3.1, 3.8, 4.5],
            "volume_ratio": [1.5, 1.2, 0.9],
            "pe": [18.7, 15.5, 20.3],
            "pe_ttm": [19.4, 16.2, 21.1],
            "pb": [2.8, 2.3, 3.5],
            "ps": [1.8, 1.5, 2.2],
            "ps_ttm": [1.9, 1.6, 2.3],
            "dv_ratio": [3.2, 2.5, 1.8],
            "dv_ttm": [3.3, 2.6, 1.9],
            "total_share": [1500000, 1000000, 2000000],
            "float_share": [1200000, 800000, 1800000],
            "free_share": [1000000, 700000, 1600000],
            "total_mv": [6000000, 5000000, 8000000],
            "circ_mv": [4800000, 4000000, 7200000],
            "adj_factor": [1.2, 1.5, 1.8],
            "downdays": [0, 0, 2],
            "updays": [5, 3, 0],
            "lowdays": [15, 10, 5],
            "topdays": [25, 20, 8],
            "open": [25.3, 20.5, 19.8],
            "high": [26.1, 21.2, 20.5],
            "low": [25.0, 20.1, 19.2],
            "close": [25.8, 20.8, 19.5],
        }
    )
    fake_conn = FakeConnection(frame=data)
    session = FakeSession(fake_conn)
    job = Daycdm(session=session)
    result = job.transform(data)
    expected_order = ["000001.SZ", "000002.SZ", "600000.SH"]
    actual_order = result["code"].tolist()
    assert actual_order == expected_order
    assert result.index.tolist() == [0, 1, 2]
    job.clean()


def test_daycdm_transform_with_technical_indicators():
    data = pd.DataFrame(
        {
            "ts_code": ["000001.SZ"],
            "trade_date": ["20241201"],
            "change": [0.50],
            "pct_chg": [2.5],
            "vol": [1000000],
            "amount": [50000],
            "turnover_rate": [3.5],
            "turnover_rate_f": [3.8],
            "volume_ratio": [1.2],
            "pe": [15.5],
            "pe_ttm": [16.2],
            "pb": [2.3],
            "ps": [1.5],
            "ps_ttm": [1.6],
            "dv_ratio": [2.5],
            "dv_ttm": [2.6],
            "total_share": [1000000],
            "float_share": [800000],
            "free_share": [700000],
            "total_mv": [5000000],
            "circ_mv": [4000000],
            "adj_factor": [1.5],
            "downdays": [0],
            "updays": [3],
            "lowdays": [10],
            "topdays": [20],
            "open": [20.5],
            "high": [21.2],
            "low": [20.1],
            "close": [20.8],
            "ma_bfq_5": [20.5],
            "ma_bfq_10": [20.3],
            "ema_bfq_5": [20.6],
            "macd_bfq": [0.15],
            "macd_dif_bfq": [0.12],
            "macd_dea_bfq": [0.10],
            "kdj_k_bfq": [65.5],
            "kdj_d_bfq": [62.3],
            "kdj_bfq": [68.7],
            "ma_5": [20.5],
            "ma_10": [20.3],
            "ema_5": [20.6],
        }
    )
    fake_conn = FakeConnection(frame=data)
    session = FakeSession(fake_conn)
    job = Daycdm(session=session)
    result = job.transform(data)
    assert len(result) == 1
    assert "ma_5" in result.columns
    assert "ma_10" in result.columns
    assert "ema_5" in result.columns
    assert "macd" in result.columns
    assert "kdj_k" in result.columns
    assert result.iloc[0]["ma_5"] == 20.5
    assert result.iloc[0]["ma_10"] == 20.3
    assert result.iloc[0]["ema_5"] == 20.6
    job.clean()


def test_daycdm_transform_missing_technical_indicators():
    data = pd.DataFrame(
        {
            "ts_code": ["000001.SZ"],
            "trade_date": ["20241201"],
            "change": [0.50],
            "pct_chg": [2.5],
            "vol": [1000000],
            "amount": [50000],
            "turnover_rate": [3.5],
            "turnover_rate_f": [3.8],
            "volume_ratio": [1.2],
            "pe": [15.5],
            "pe_ttm": [16.2],
            "pb": [2.3],
            "ps": [1.5],
            "ps_ttm": [1.6],
            "dv_ratio": [2.5],
            "dv_ttm": [2.6],
            "total_share": [1000000],
            "float_share": [800000],
            "free_share": [700000],
            "total_mv": [5000000],
            "circ_mv": [4000000],
            "adj_factor": [1.5],
            "downdays": [0],
            "updays": [3],
            "lowdays": [10],
            "topdays": [20],
            "open": [20.5],
            "high": [21.2],
            "low": [20.1],
            "close": [20.8],
        }
    )
    fake_conn = FakeConnection(frame=data)
    session = FakeSession(fake_conn)
    job = Daycdm(session=session)
    result = job.transform(data)
    assert len(result) == 1
    assert pd.isna(result.iloc[0]["ma_5"])
    assert pd.isna(result.iloc[0]["kdj_k"])
    assert pd.isna(result.iloc[0]["macd"])
    job.clean()
