import os
import shutil
from pathlib import Path

def list_files(path="."):
    """Return list of files and folders in the given directory."""
    return os.listdir(path)

def count_files(path="."):
    """Return number of files in a directory."""
    return len(os.listdir(path))

def file_size(path):
    """Return file size in bytes."""
    if not os.path.exists(path):
        return "File not found"
    return os.path.getsize(path)

def delete_file(path):
    """Delete a file."""
    if os.path.exists(path):
        os.remove(path)
        return True
    return False

def make_folder(path):
    """Create a folder."""
    Path(path).mkdir(parents=True, exist_ok=True)
    return True
