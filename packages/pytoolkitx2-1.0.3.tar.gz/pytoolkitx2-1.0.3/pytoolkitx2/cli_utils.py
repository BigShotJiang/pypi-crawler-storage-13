import time
import sys

def loading(message="Loading", duration=3):
    """Simple loading animation."""
    for i in range(duration):
        print(f"{message}{'.' * (i % 4)}", end="\r")
        time.sleep(0.5)
    print(" " * 20, end="\r")

def progress_bar(total=20, delay=0.1):
    """Simple text-based progress bar."""
    for i in range(total + 1):
        bar = "#" * i + "-" * (total - i)
        percent = (i / total) * 100
        print(f"[{bar}] {percent:.0f}%", end="\r")
        time.sleep(delay)
    print()
