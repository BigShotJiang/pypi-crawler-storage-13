from setuptools import setup, find_packages

setup(
    name="pytoolkitx2",
    version="1.0.3",
    author="Rahul Gunjkar",
    description="A multipurpose toolkit for file, math, CLI, and DSA utilities",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    python_requires=">=3.7",
)
