"""
认证API - 提供登录和token刷新功能
"""
import logging
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel
from jettask.webui.config import webui_config
from jettask.webui.utils.jwt_utils import JWTManager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/auth", tags=["认证"])

jwt_manager = JWTManager(
    secret_key=webui_config.jwt_secret_key,
    algorithm=webui_config.jwt_algorithm,
    access_token_expire_minutes=webui_config.jwt_access_token_expire_minutes,
    refresh_token_expire_days=webui_config.jwt_refresh_token_expire_days
)

auth_provider = webui_config.create_auth_provider()
logger.info(f"认证提供者已初始化: {auth_provider}")



class LoginRequest(BaseModel):
    """登录请求"""
    token: str

    class Config:
        json_schema_extra = {
            "example": {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
            }
        }


class TokenResponse(BaseModel):
    """Token响应"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  

    class Config:
        json_schema_extra = {
            "example": {
                "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
                "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
                "token_type": "bearer",
                "expires_in": 1800
            }
        }


class RefreshRequest(BaseModel):
    """刷新token请求"""
    refresh_token: str

    class Config:
        json_schema_extra = {
            "example": {
                "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
            }
        }


class RefreshResponse(BaseModel):
    """刷新token响应"""
    access_token: str
    token_type: str = "bearer"
    expires_in: int

    class Config:
        json_schema_extra = {
            "example": {
                "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
                "token_type": "bearer",
                "expires_in": 1800
            }
        }



@router.post("/login", response_model=TokenResponse, summary="用户登录")
async def login(request: LoginRequest):
    auth_result = await auth_provider.verify_token(request.token)

    if not auth_result.success:
        logger.warning(
            f"登录失败 - {auth_provider.get_provider_name()} token验证失败"
            f" - {auth_result.error_message}"
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=auth_result.error_message or "Token验证失败"
        )

    username = auth_result.username

    if not username:
        logger.error("认证成功但缺少用户名信息")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="认证服务返回的用户信息不完整"
        )

    access_token = jwt_manager.create_access_token(username)
    refresh_token = jwt_manager.create_refresh_token(username)

    logger.info(
        f"用户登录成功: {username} "
        f"(认证方式: {auth_provider.get_provider_name()})"
    )

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        expires_in=webui_config.jwt_access_token_expire_minutes * 60
    )


@router.post("/refresh", response_model=RefreshResponse, summary="刷新访问token")
async def refresh_token(request: RefreshRequest):
    new_access_token = jwt_manager.refresh_access_token(request.refresh_token)

    if not new_access_token:
        logger.warning("Token刷新失败 - 无效或过期的刷新token")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="无效或过期的刷新token，请重新登录"
        )

    payload = jwt_manager.decode_token(request.refresh_token)
    username = payload.get('sub') if payload else 'unknown'
    logger.info(f"Token刷新成功: {username}")

    return RefreshResponse(
        access_token=new_access_token,
        token_type="bearer",
        expires_in=webui_config.jwt_access_token_expire_minutes * 60
    )
