import logging
import os
import queue
import tempfile
import threading
import time
import uuid

import requests
from requests.adapters import HTTPAdapter
from tqdm import tqdm
from urllib3.util.retry import Retry

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
log = logging.getLogger(__name__)


class EnhancedDownloader:
    """增强型下载器，支持单线程和多线程下载，自动检测服务器是否支持分片"""

    def __init__(self):
        self._default_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }

    def create_session(self, retries=3, backoff_factor=3):
        """创建带重试策略的会话"""
        session = requests.Session()
        session.headers.update(self._default_headers)

        retry_strategy = Retry(
            total=retries,
            backoff_factor=backoff_factor,
            status_forcelist=[429, 500, 502, 503, 504, 520, 522, 524],
        )
        adapter = HTTPAdapter(
            max_retries=retry_strategy
        )
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    def check_range_support(self, url, session=None):
        """检查服务器是否支持分片下载"""
        use_session = session if session else self.create_session()
        try:
            head_response = use_session.head(url)
            head_response.raise_for_status()

            # 检查是否支持Range请求
            accept_ranges = head_response.headers.get('accept-ranges', 'none')
            if accept_ranges.lower() == 'bytes':
                # 尝试发送一个简单的Range请求来验证
                try:
                    range_response = use_session.get(url, headers={'Range': 'bytes=0-1'}, stream=True)
                    if range_response.status_code == 206:
                        return True, int(head_response.headers.get('content-length', 0))
                except:
                    pass

            # 获取文件大小
            content_length = int(head_response.headers.get('content-length', 0))
            return False, content_length
        except Exception as e:
            log.warning(f"检查分片支持时出错: {str(e)}")
            return False, 0
        finally:
            if not session:
                use_session.close()

    def _worker(self, task_queue, filename, pbar, completed_ranges, stop_event, downloaded_bytes, url, max_retries=3):
        """工作线程函数，处理队列中的下载任务"""
        while not stop_event.is_set():
            try:
                # 尝试获取新任务
                start, end = task_queue.get(timeout=1)
                range_key = (start, end)

                # 检查任务是否已被完成
                if range_key in completed_ranges:
                    task_queue.task_done()
                    continue

                # 获取该任务的重试次数
                retry_count = task_queue.retries.get(range_key, 0)

                # 如果超过最大重试次数，则放弃任务
                if retry_count >= max_retries:
                    log.error(f"下载块 {start}-{end} 已达到最大重试次数 {max_retries}，放弃下载")
                    task_queue.task_done()
                    continue

                # 执行下载任务
                session = self.create_session()
                try:
                    headers = {'Range': f'bytes={start}-{end}'}
                    chunk_size = 8192
                    response = session.get(url, headers=headers, stream=True, timeout=120)
                    response.raise_for_status()

                    with open(filename, 'r+b') as f:
                        f.seek(start)
                        downloaded = downloaded_bytes[range_key]
                        expected_size = end - start + 1

                        # 更新进度条：减去之前已下载但失败的部分
                        if downloaded > 0:
                            pbar.update(-downloaded)

                        start_time = time.time()
                        for chunk in response.iter_content(chunk_size=chunk_size):
                            if chunk:
                                f.write(chunk)
                                chunk_len = len(chunk)
                                prev_downloaded = downloaded
                                downloaded += chunk_len
                                downloaded_bytes[range_key] = downloaded

                                actual_new_bytes = min(chunk_len, expected_size - prev_downloaded)
                                if actual_new_bytes > 0:
                                    pbar.update(actual_new_bytes)

                                # 检查下载速度，如果太慢则放弃并重新分配任务
                                elapsed = time.time() - start_time
                                if elapsed > 30 and prev_downloaded > 8192 and prev_downloaded / elapsed < 256:
                                    # 如果下载太慢，将其分割成更小的块并重新分配
                                    remaining = expected_size - downloaded
                                    if remaining > 1 * 1024 * 1024:  # 如果剩余数据大于1MB才拆分
                                        # 将剩余部分分割成两个块
                                        mid_point = start + downloaded + remaining // 2
                                        new_range1 = (start + downloaded, mid_point)
                                        new_range2 = (mid_point + 1, end)

                                        # 添加新任务到队列
                                        task_queue.put(new_range1)
                                        task_queue.put(new_range2)

                                        # 更新重试计数
                                        task_queue.retries[new_range1] = retry_count
                                        task_queue.retries[new_range2] = retry_count

                                        # 标记原任务完成
                                        completed_ranges.add(range_key)
                                        raise Exception("Download too slow, split into smaller chunks")

                    completed_ranges.add(range_key)

                except Exception as e:
                    log.info(f"下载块 {start}-{end} 时出错: {e}")
                    # 更新进度条：减去已下载但失败的部分
                    if downloaded_bytes[range_key] > 0:
                        pbar.update(-downloaded_bytes[range_key])
                    downloaded_bytes[range_key] = 0

                    # 增加重试次数
                    task_queue.retries[range_key] = retry_count + 1

                    # 重新放入队列
                    task_queue.put((start, end))
                finally:
                    session.close()
                    task_queue.task_done()

            except queue.Empty:
                # 队列为空，继续等待
                continue
            except Exception as e:
                log.error(f"工作线程出错: {str(e)}")

    def multi_thread_download(self, url, filename, file_size, num_threads=30, temp_dir=None):
        """多线程下载文件"""
        # 确定临时文件路径
        if temp_dir:
            os.makedirs(temp_dir, exist_ok=True)
            temp_filename = os.path.join(temp_dir, f"download_{uuid.uuid4().hex}.tmp")
        else:
            temp_file = tempfile.NamedTemporaryFile(delete=False)
            temp_filename = temp_file.name
            temp_file.close()

        try:
            # 创建与文件大小相同的空文件
            with open(temp_filename, 'wb') as f:
                f.seek(file_size - 1)
                f.write(b'\0')

            with tqdm(total=file_size, unit='B', unit_scale=True, desc='下载进度') as pbar:
                task_queue = queue.Queue()
                completed_ranges = set()
                downloaded_bytes = {}
                stop_event = threading.Event()

                # 初始化任务队列
                bytes_per_thread = file_size // num_threads
                for i in range(num_threads):
                    start = i * bytes_per_thread
                    end = start + bytes_per_thread - 1 if i < num_threads - 1 else file_size - 1
                    task_queue.put((start, end))
                    downloaded_bytes[(start, end)] = 0

                # 初始化重试计数字典
                task_queue.retries = {}

                # 启动工作线程
                workers = []
                # 根据文件大小和系统资源动态调整实际线程数
                actual_threads = min(num_threads, 30)
                for _ in range(actual_threads):
                    w = threading.Thread(target=self._worker,
                                         args=(task_queue, temp_filename, pbar, completed_ranges, stop_event,
                                               downloaded_bytes, url))
                    w.daemon = True
                    w.start()
                    workers.append(w)

                # 等待所有任务完成
                task_queue.join()

                # 通知所有线程停止
                stop_event.set()

                # 等待所有线程结束
                for w in workers:
                    w.join(timeout=5)

            log.info(f"多线程下载完成: {temp_filename}")

            # 如果指定了目标文件名，则将临时文件移动到目标位置
            if filename != temp_filename:
                # 确保目标文件所在目录存在
                os.makedirs(os.path.dirname(filename), exist_ok=True)
                # 先删除可能存在的目标文件
                if os.path.exists(filename):
                    os.remove(filename)
                # 重命名临时文件
                os.rename(temp_filename, filename)
                temp_filename = filename

            return temp_filename

        except Exception as e:
            log.error(f"多线程下载失败: {str(e)}")
            # 清理临时文件
            if os.path.exists(temp_filename):
                try:
                    os.remove(temp_filename)
                except:
                    pass
            raise

    def single_thread_download(self, url, save_path, return_content=False, chunk_size=8192, timeout=30):
        """单线程下载文件"""
        try:
            with requests.get(url, stream=True, timeout=timeout, headers=self._default_headers) as response:
                response.raise_for_status()

                # 获取文件总大小
                total_size = int(response.headers.get('content-length', 0))

                # 如果需要返回内容
                if return_content:
                    log.info("正在下载内容...")
                    content = bytearray()
                    with tqdm(total=total_size, unit='B', unit_scale=True, unit_divisor=1024) as pbar:
                        for chunk in response.iter_content(chunk_size=chunk_size):
                            if chunk:
                                content.extend(chunk)
                                pbar.update(len(chunk))
                    return bytes(content)
                else:
                    # 确保目录存在
                    os.makedirs(os.path.dirname(save_path), exist_ok=True)

                    log.info(f"正在下载文件到: {save_path}")
                    with open(save_path, 'wb') as file, tqdm(
                            total=total_size,
                            unit='B',
                            unit_scale=True,
                            unit_divisor=1024
                    ) as pbar:
                        for chunk in response.iter_content(chunk_size=chunk_size):
                            if chunk:
                                file.write(chunk)
                                file.flush()
                                pbar.update(len(chunk))

                    log.info(f"下载完成! 文件保存至: {save_path}")
                    return save_path

        except requests.exceptions.RequestException as e:
            log.error(f"下载请求失败: {str(e)}")
            raise
        except IOError as e:
            log.error(f"文件保存失败: {str(e)}")
            raise

    # 移除download方法中名为'os'的参数
    def download(self, url, save_path=None, return_content=False, chunk_size=8192, timeout=30,
                 num_threads=30, temp_dir=None, force_single_thread=False, min_size_for_multithread=10 * 1024 * 1024):
        # 函数体保持不变

        """
        智能下载函数，根据服务器支持和文件大小自动选择下载方式

        Args:
            url (str): 下载链接
            save_path (str, optional): 保存文件的路径，如果为None且return_content为False，则自动生成文件名；如果是目录路径，则使用服务器返回的原始文件名
            return_content (bool, optional): 是否返回文件内容而不是保存到本地
            chunk_size (int, optional): 下载块大小
            timeout (int, optional): 请求超时时间（秒）
            num_threads (int, optional): 多线程下载时的线程数
            temp_dir (str, optional): 临时文件目录，用于多线程下载和返回内容时的缓存
            force_single_thread (bool, optional): 是否强制使用单线程下载
            min_size_for_multithread (int, optional): 启用多线程下载的最小文件大小（默认10MB）

        Returns:
            str or bytes: 如果return_content为True，返回文件内容(bytes)；否则返回保存的文件路径(str)
        """
        # 如果需要返回内容，先检查是否可以使用多线程下载
        if return_content:
            # 检查服务器是否支持分片下载
            range_support, file_size = self.check_range_support(url)

            # 如果支持分片且文件大小超过阈值，并且不强制单线程，使用多线程下载到临时文件
            if range_support and file_size >= min_size_for_multithread and not force_single_thread:
                # 在download方法中修改临时文件处理部分（约第330-360行）

                log.info(f"大文件内容返回，使用多线程下载，文件大小: {file_size / 1024 / 1024:.2f}MB")

                # 生成临时文件路径
                if temp_dir:
                    os.makedirs(temp_dir, exist_ok=True)
                    temp_filename = os.path.join(temp_dir, f"temp_{uuid.uuid4().hex}")
                else:
                    # 使用系统临时目录 - 修复：确保正确使用name属性
                    temp_file = tempfile.NamedTemporaryFile(delete=False)
                    temp_filename = temp_file.name  # 正确使用name属性
                    temp_file.close()  # 确保文件关闭

                try:
                    # 使用多线程下载到临时文件
                    self.multi_thread_download(url, temp_filename, file_size, num_threads, temp_dir)

                    # 读取临时文件内容
                    with open(temp_filename, 'rb') as f:
                        content = f.read()

                    log.info(f"成功读取临时文件内容，大小: {len(content)} 字节")
                    return content

                finally:
                    # 清理临时文件
                    if os.path.exists(temp_filename):
                        try:
                            os.remove(temp_filename)
                            log.info(f"已清理临时文件: {temp_filename}")
                        except Exception as e:
                            log.warning(f"清理临时文件失败: {str(e)}")
            else:
                # 小文件或不支持分片或强制单线程，使用单线程下载
                if not range_support:
                    log.info("服务器不支持分片下载，使用单线程下载返回内容")
                elif force_single_thread:
                    log.info("强制使用单线程下载返回内容")
                else:
                    log.info(f"文件大小小于{min_size_for_multithread / 1024 / 1024:.2f}MB，使用单线程下载返回内容")

                return self.single_thread_download(url, None, return_content=True, chunk_size=chunk_size,
                                                   timeout=timeout)

        # 确定保存路径
        if save_path is None or os.path.isdir(save_path):
            # 发送HEAD请求获取文件名和内容类型
            session = self.create_session()
            try:
                head_response = session.head(url)
                head_response.raise_for_status()

                # 尝试从Content-Disposition头中获取原始文件名
                content_disposition = head_response.headers.get('Content-Disposition', '')
                filename = None

                # 从Content-Disposition中提取文件名
                if 'filename=' in content_disposition:
                    import re
                    match = re.findall(r'filename="?([^";]+)', content_disposition)
                    if match:
                        filename = match[0]

                # 如果Content-Disposition中没有，则从URL中获取文件名
                if not filename:
                    filename = os.path.basename(url.split('?')[0])

                # 如果文件名无效，生成时间戳文件名
                if not filename or '.' not in filename:
                    # 生成时间戳文件名
                    timestamp = int(time.time())
                    content_type = head_response.headers.get('content-type', 'application/octet-stream')
                    # 简单的内容类型到文件扩展名的映射
                    ext_map = {
                        'application/pdf': '.pdf',
                        'application/zip': '.zip',
                        'application/xml': '.xml',
                        'text/xml': '.xml',
                        'application/json': '.json',
                        'text/plain': '.txt'
                    }
                    extension = ext_map.get(content_type, '.bin')
                    filename = f"download_{timestamp}{extension}"

                # 根据是否提供了目录路径来决定保存位置
                if save_path is None:
                    # 保存到当前目录
                    save_path = os.path.join(os.getcwd(), filename)
                else:
                    # 保存到用户指定的目录
                    os.makedirs(save_path, exist_ok=True)
                    save_path = os.path.join(save_path, filename)

                log.info(f"将使用服务器原始文件名: {filename}")
            finally:
                session.close()

        # 检查是否需要使用多线程下载
        if not force_single_thread:
            # 检查服务器是否支持分片下载
            range_support, file_size = self.check_range_support(url)

            # 如果支持分片且文件大小超过阈值，使用多线程下载
            if range_support and file_size >= min_size_for_multithread:
                log.info(f"服务器支持分片下载，文件大小: {file_size / 1024 / 1024:.2f}MB，使用多线程下载")
                try:
                    return self.multi_thread_download(url, save_path, file_size, num_threads, temp_dir)
                except Exception as e:
                    log.warning(f"多线程下载失败: {str(e)}，切换到单线程下载")
            else:
                if not range_support:
                    log.info("服务器不支持分片下载，使用单线程下载")
                else:
                    log.info(f"文件大小小于{min_size_for_multithread / 1024 / 1024:.2f}MB，使用单线程下载")
        else:
            log.info("强制使用单线程下载")

        # 使用单线程下载
        return self.single_thread_download(url, save_path, return_content=False, chunk_size=chunk_size, timeout=timeout)


# 创建全局下载器实例
downloader = EnhancedDownloader()


# 提供便捷函数
def download_file(url, save_path=None, return_content=False, chunk_size=8192, timeout=30,
                  num_threads=30, temp_dir=None, force_single_thread=False, min_size_for_multithread=10 * 1024 * 1024):
    """
    便捷下载函数，使用全局下载器实例

    Args:
        url (str): 下载链接
        save_path (str, optional): 保存文件的路径，如果为None且return_content为False，则自动生成文件名
        return_content (bool, optional): 是否返回文件内容而不是保存到本地
        chunk_size (int, optional): 下载块大小
        timeout (int, optional): 请求超时时间（秒）
        num_threads (int, optional): 多线程下载时的线程数
        temp_dir (str, optional): 临时文件目录
        force_single_thread (bool, optional): 是否强制使用单线程下载
        min_size_for_multithread (int, optional): 启用多线程下载的最小文件大小（默认10MB）

    Returns:
        str or bytes: 如果return_content为True，返回文件内容(bytes)；否则返回保存的文件路径(str)
    """
    return downloader.download(
        url=url,
        save_path=save_path,
        return_content=return_content,
        chunk_size=chunk_size,
        timeout=timeout,
        num_threads=num_threads,
        temp_dir=temp_dir,
        force_single_thread=force_single_thread,
        min_size_for_multithread=min_size_for_multithread
    )


# 示例用法
if __name__ == "__main__":
    # 要下载的URL
    target_url = "https://s3.amazonaws.com/data.patentsview.org/claims/g_claims_2025.tsv.zip"

    try:
        # 示例1: 下载并保存到指定路径
        download_path = download_file(target_url, save_path="E:\work\demo\epo_week_leg")
        print(f"文件保存路径: {download_path}")

        # 示例2: 下载并返回内容
        file_content = download_file(target_url, return_content=True)
        print(f"获取到文件内容，大小: {len(file_content)} 字节")

        # 示例3: 下载到自动生成的路径
        # download_path = download_file(target_url)
        # print(f"自动保存路径: {download_path}")

        # 示例4: 强制使用单线程下载
        # download_path = download_file(target_url, force_single_thread=True)
        # print(f"强制单线程下载路径: {download_path}")

    except Exception as e:
        print(f"操作失败: {str(e)}")
