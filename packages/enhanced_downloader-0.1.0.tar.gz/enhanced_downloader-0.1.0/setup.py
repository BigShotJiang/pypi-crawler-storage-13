from setuptools import setup, find_packages
import os

# 读取README.md内容
with open(os.path.join(os.path.dirname(__file__), 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name="enhanced_downloader",  # 包名，pip install 时使用
    version="0.1.0",  # 版本号
    description="一个功能强大的增强型下载模块，支持多线程下载、断点续传和进度显示",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Stabvalue",
    author_email="stabvalue@outlook.com",
    url="https://github.com/Stabvalue/enhanced_downloader",  # 项目地址
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "tqdm>=4.60.0"
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
    python_requires='>=3.7',
)
