"""
Main client class for interacting with GmodStore Job Market.
"""

import os
import time
from typing import List, Optional
from datetime import datetime

import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from .models import Job
from .exceptions import ScrapingError, DriverError


class GmodStoreClient:
    """
    Client for the GmodStore Job Market scraper.

    Example:
        >>> client = GmodStoreClient()
        >>> jobs = client.get_jobs(limit=10)
        >>> for job in jobs:
        ...     print(job.title, job.url)
    """

    BASE_URL = "https://www.gmodstore.com"
    BROWSE_URL = f"{BASE_URL}/jobmarket/jobs/browse"
    DEFAULT_USER_AGENT = "gmodstore-py/0.1.0 (Python SDK)"
    DEFAULT_TIMEOUT = 10

    def __init__(
        self,
        headless: bool = True,
        timeout: int = DEFAULT_TIMEOUT,
        user_agent: Optional[str] = None,
    ):
        """
        Initialize the GmodStore client.

        Args:
            headless: Run Chrome in headless mode
            timeout: Page load timeout in seconds
            user_agent: Custom User-Agent string
        """
        self.headless = headless
        self.timeout = timeout
        self.user_agent = user_agent or self.DEFAULT_USER_AGENT
        self._driver = None

    def _get_driver(self):
        """Create and configure a Chrome driver."""
        if self._driver:
            return self._driver

        chrome_options = Options()

        if self.headless:
            chrome_options.add_argument('--headless=new')

        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--disable-software-rasterizer')
        chrome_options.add_argument('--disable-extensions')
        chrome_options.add_argument('--disable-logging')
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        chrome_options.add_argument('--disable-images')
        chrome_options.add_argument(f'user-agent={self.user_agent}')

        # Performance preferences
        prefs = {
            'profile.managed_default_content_settings.images': 2,
            'profile.default_content_setting_values.notifications': 2,
            'profile.managed_default_content_settings.stylesheets': 2,
        }
        chrome_options.add_experimental_option('prefs', prefs)
        chrome_options.page_load_strategy = 'eager'

        try:
            # Try system chromedriver first (Docker/CI)
            if os.path.exists('/usr/bin/chromedriver'):
                service = Service('/usr/bin/chromedriver')
            else:
                # Fallback to webdriver-manager
                from webdriver_manager.chrome import ChromeDriverManager
                service = Service(ChromeDriverManager().install())

            driver = webdriver.Chrome(service=service, options=chrome_options)
            driver.set_page_load_timeout(self.timeout)
            self._driver = driver
            return driver

        except Exception as e:
            raise DriverError(f"Failed to create Chrome driver: {e}") from e

    def get_jobs(self, limit: int = 20, max_pages: int = 3) -> List[Job]:
        """
        Fetch a list of jobs from GmodStore Job Market.

        Args:
            limit: Maximum number of jobs to return
            max_pages: Maximum number of pages to scrape

        Returns:
            List of Job objects with basic information

        Raises:
            ScrapingError: If scraping fails

        Example:
            >>> jobs = client.get_jobs(limit=10)
            >>> print(f"Found {len(jobs)} jobs")
        """
        headers = {'User-Agent': self.user_agent}
        all_jobs = []
        seen_ids = set()

        try:
            for page in range(1, max_pages + 1):
                if len(all_jobs) >= limit:
                    break

                page_url = f"{self.BROWSE_URL}?sortby=new&page={page}" if page > 1 else f"{self.BROWSE_URL}?sortby=new"

                response = requests.get(page_url, headers=headers, timeout=self.timeout)
                response.raise_for_status()

                soup = BeautifulSoup(response.text, 'html.parser')

                # Find job elements
                job_elements = soup.select('div.contentRow')
                if not job_elements:
                    job_elements = soup.select('li.block-row')
                if not job_elements:
                    job_links = soup.find_all('a', href=lambda x: x and '/jobmarket/jobs/' in x and '/browse' not in x)
                    job_elements = [link.parent for link in job_links]

                if not job_elements:
                    break

                for element in job_elements:
                    if len(all_jobs) >= limit:
                        break

                    try:
                        job_link = element.find('a', href=lambda x: x and '/jobmarket/jobs/' in x and '/browse' not in x)
                        if not job_link:
                            continue

                        job_url = job_link.get('href')
                        if not job_url.startswith('http'):
                            job_url = f"{self.BASE_URL}{job_url}"

                        if '/jobmarket/jobs/create' in job_url:
                            continue

                        raw_id = job_url.split('/jobmarket/jobs/')[-1].split('-')[0]
                        job_id = f"gmodstore_{raw_id}"

                        if job_id in seen_ids:
                            continue
                        seen_ids.add(job_id)

                        title = job_link.get_text(strip=True)
                        if not title:
                            title_elem = element.find(['h3', 'h2', 'div'], class_=lambda x: x and 'title' in str(x).lower())
                            title = title_elem.get_text(strip=True) if title_elem else f"Job {raw_id}"

                        all_jobs.append(Job(
                            id=job_id,
                            title=title,
                            url=job_url,
                            source="gmodstore"
                        ))

                    except Exception as e:
                        continue

                if page < max_pages:
                    time.sleep(0.5)

            return all_jobs

        except requests.RequestException as e:
            raise ScrapingError(f"Failed to fetch job list: {e}") from e

    def get_job_details(self, job_id: str) -> Optional[Job]:
        """
        Fetch detailed information about a specific job.

        Args:
            job_id: The job ID (can include 'gmodstore_' prefix or not)

        Returns:
            Job object with complete information or None

        Raises:
            ScrapingError: If scraping fails

        Example:
            >>> job = client.get_job_details("12345")
            >>> print(job.description)
        """
        # Remove prefix if present
        raw_id = job_id.replace("gmodstore_", "")

        # First, get the jobs list to find the URL
        jobs = self.get_jobs(limit=50)
        job_url = None

        for job in jobs:
            if job.id == f"gmodstore_{raw_id}":
                job_url = job.url
                break

        if not job_url:
            return None

        return self.get_job_details_by_url(job_url)

    def get_job_details_by_url(self, job_url: str) -> Optional[Job]:
        """
        Fetch detailed information using a direct URL.

        Args:
            job_url: Full URL to the job page

        Returns:
            Job object with complete information or None

        Raises:
            ScrapingError: If scraping fails
        """
        driver = None
        try:
            driver = self._get_driver()
            driver.get(job_url)

            # Wait for page to load
            wait = WebDriverWait(driver, 8)
            wait.until(EC.presence_of_element_located((By.CLASS_NAME, "display-4")))
            time.sleep(1)

            soup = BeautifulSoup(driver.page_source, 'html.parser')

            # Extract job ID
            raw_id = job_url.split('/jobmarket/jobs/')[-1].split('-')[0]
            job_id = f"gmodstore_{raw_id}"

            # Get title
            title = f"Job {raw_id}"
            title_elem = soup.find('h1', class_='display-4')
            if title_elem:
                a_tag = title_elem.find('a')
                if a_tag:
                    title = a_tag.get_text(strip=True)
                    if title.startswith('Job: '):
                        title = title[5:]

            # Get description
            description = None
            cards = soup.find_all('div', class_='card')
            for card in cards:
                header = card.find('div', class_='card-header')
                if header and 'Description' in header.get_text():
                    quill_editor = card.find('div', class_='ql-editor')
                    if quill_editor:
                        description = quill_editor.get_text(separator='\n', strip=True)
                        description = '\n'.join(line.strip() for line in description.split('\n') if line.strip())
                        if len(description) > 800:
                            description = description[:797] + "..."
                    break

            # Get budget
            budget = None
            for card in cards:
                title_elem = card.find('h4', class_='card-title')
                if title_elem and 'Budget' in title_elem.get_text():
                    text_elem = card.find('div', class_='card-text')
                    if text_elem:
                        budget = text_elem.get_text(strip=True)
                    break

            # Get category
            category = None
            for card in cards:
                title_elem = card.find('h4', class_='card-title')
                if title_elem and 'Category' in title_elem.get_text():
                    text_elem = card.find('div', class_='card-text')
                    if text_elem:
                        a_tag = text_elem.find('a')
                        category = a_tag.get_text(strip=True) if a_tag else text_elem.get_text(strip=True)
                    break

            # Get applications
            applications = None
            for card in cards:
                title_elem = card.find('h4', class_='card-title')
                if title_elem and 'Applications' in title_elem.get_text():
                    text_elem = card.find('div', class_='card-text')
                    if text_elem:
                        applications = text_elem.get_text(strip=True)
                    break

            return Job(
                id=job_id,
                title=title,
                url=job_url,
                source="gmodstore",
                description=description,
                budget=budget,
                category=category,
                applications=applications,
                created_at=datetime.now()
            )

        except Exception as e:
            raise ScrapingError(f"Failed to fetch job details: {e}") from e

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()

    def close(self):
        """Close the Selenium driver."""
        if self._driver:
            self._driver.quit()
            self._driver = None
