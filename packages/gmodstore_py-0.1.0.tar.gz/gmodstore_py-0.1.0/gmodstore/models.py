"""
Data models for GmodStore SDK.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Dict, Any


@dataclass
class Job:
    """
    Represents a job listing from GmodStore.

    Attributes:
        id: Unique job ID (with 'gmodstore_' prefix)
        title: Job title
        url: Full URL to job posting
        source: Always 'gmodstore'
        description: Job description (from details page)
        budget: Budget information string
        category: Job category
        applications: Number of applications
        created_at: Creation timestamp
    """

    # Required fields
    id: str
    title: str
    url: str
    source: str = "gmodstore"

    # Optional fields
    description: Optional[str] = None
    budget: Optional[str] = None
    category: Optional[str] = None
    applications: Optional[str] = None
    created_at: Optional[datetime] = None

    @classmethod
    def from_scrape(cls, data: Dict[str, Any]) -> "Job":
        """
        Create a Job instance from scraped data.

        Args:
            data: Dictionary with scraped job data

        Returns:
            Job instance
        """
        return cls(
            id=data.get("id", ""),
            title=data.get("title", ""),
            url=data.get("url", ""),
            source="gmodstore",
            description=data.get("description"),
            budget=data.get("budget"),
            category=data.get("category"),
            applications=data.get("applications"),
            created_at=data.get("created_at") or datetime.now(),
        )

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert Job to dictionary format.

        Returns:
            Dictionary representation of the job
        """
        return {
            "id": self.id,
            "title": self.title,
            "url": self.url,
            "source": self.source,
            "description": self.description,
            "budget": self.budget,
            "category": self.category,
            "applications": self.applications,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

    def __repr__(self) -> str:
        """String representation."""
        return f"Job(id={self.id!r}, title={self.title!r})"
