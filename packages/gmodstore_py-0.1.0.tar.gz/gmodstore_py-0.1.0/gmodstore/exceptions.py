"""
Custom exceptions for GmodStore SDK.
"""


class GmodStoreException(Exception):
    """Base exception for all GmodStore SDK errors."""
    pass


class ScrapingError(GmodStoreException):
    """Raised when web scraping fails."""
    pass


class DriverError(GmodStoreException):
    """Raised when Chrome driver initialization or operation fails."""
    pass


class ParseError(GmodStoreException):
    """Raised when HTML parsing fails."""
    pass
