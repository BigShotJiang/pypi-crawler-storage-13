# Quick Start: Local Testing and PyPI Deployment

This is a quick reference guide. For detailed instructions, see `PYPI_DEPLOYMENT.md`.

## Prerequisites

```powershell
# Install required tools
pip install --upgrade build twine pytest
```

## Step-by-Step Deployment

### 1. Run Local Tests (Optional on Windows)

**Note**: Full tests require PyTorch with CUDA. On Windows without GPU, you can skip to building.

```powershell
cd "c:\Users\furka\Desktop\NITSRI PHD\ParallelLLM"

# If you have PyTorch installed:
python -m pytest tests/test_package.py -v
```

### 2. Build Distributions

```powershell
# Clean old builds
Remove-Item -Recurse -Force dist, build, *.egg-info -ErrorAction SilentlyContinue

# Build
python -m build
```

This creates:
- `dist/parallel-llm-0.1.1.tar.gz`
- `dist/parallel_llm-0.1.1-py3-none-any.whl`

### 3. Check Distribution Quality

```powershell
# Verify distributions
python -m twine check dist/*
```

### 4. Upload to Test PyPI

```powershell
python -m twine upload --repository testpypi dist/*
```

Credentials:
- Username: `__token__`
- Password: `pypi-<your-test-pypi-token>`

### 5. Test from Test PyPI

```powershell
# Create test environment
python -m venv test_env_testpypi
test_env_testpypi\Scripts\activate

# Install (dependencies from regular PyPI)
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ parallel-llm

# Basic verification (if torch is available)
python -c "import parallel_llm; print(parallel_llm.__version__)"

# Cleanup
deactivate
Remove-Item -Recurse -Force test_env_testpypi
```

### 6. Upload to Production PyPI

⚠️ **Final check**: Version 0.1.1 can only be uploaded once!

```powershell
python -m twine upload dist/*
```

Credentials:
- Username: `__token__`  
- Password: `pypi-<your-production-token>`

### 7. Verify Production

```powershell
# Create test environment
python -m venv test_env_pypi
test_env_pypi\Scripts\activate

# Install from PyPI
pip install parallel-llm

# Verify
python -c "import parallel_llm; print(f'Success! Version: {parallel_llm.__version__}')"

# Cleanup
deactivate
Remove-Item -Recurse -Force test_env_pypi
```

### 8. Tag Release

```powershell
git tag v0.1.1
git push origin v0.1.1
```

## Using .pypirc for Easy Authentication

Create `C:\Users\furka\.pypirc`:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR_PYPI_TOKEN_HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TESTPYPI_TOKEN_HERE
```

Then upload without password prompts:

```powershell
python -m twine upload --repository testpypi dist/*  # Test PyPI
python -m twine upload --repository pypi dist/*      # Production PyPI
```

## Important Links

- **Test PyPI Package**: https://test.pypi.org/project/parallel-llm/
- **Production PyPI Package**: https://pypi.org/project/parallel-llm/
- **Get API Tokens**: 
  - Test: https://test.pypi.org/manage/account/token/
  - Production: https://pypi.org/manage/account/token/

## Troubleshooting

**"Invalid credentials"**: Use `__token__` (with underscores) as username

**"File already exists"**: That version is already on PyPI. Bump version in `pyproject.toml`

**Build fails**: Make sure `build` and `setuptools` are installed: `pip install --upgrade build setuptools wheel`

## Next Release (0.1.2+)

1. Update version in `pyproject.toml` (line 7)
2. Update version in `parallel_llm/__init__.py` (line 8)
3. Rebuild and follow steps 2-8 above
