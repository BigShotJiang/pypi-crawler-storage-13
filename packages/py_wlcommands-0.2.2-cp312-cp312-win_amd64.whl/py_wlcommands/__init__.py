"""
WL Commands - Command line interface for project management
"""

__version__ = "0.1.52"

from .commands import Command, register_command
