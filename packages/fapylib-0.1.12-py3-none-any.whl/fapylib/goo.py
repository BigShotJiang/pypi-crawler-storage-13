"""Doc String"""
import secrets
import base64
import urllib.parse
from jose import jwt
from hashlib import sha256
from httpx import AsyncClient
from typing import Optional, Any
from sqlmodel import SQLModel, Field
from cryptography.x509 import load_pem_x509_certificate
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from fastapi_sessions.backends.implementations import InMemoryBackend

__all__ = ["GooAuth"]

class GooAuth:
    def __init__(
            self,
            config: Optional[Any] = None,
            client_id: Optional[str] = None, 
            redirect_uri: Optional[str] = None,
            client_secret: Optional[str] = None,
            auth_uri: Optional[str] = None,
            token_uri: Optional[str] = None,
            user_uri: Optional[str] = None,
            refresh_uri: Optional[str] = None,
            revoke_uri: Optional[str] = None,
            jwks_uri: Optional[str] = None,
            cert_uri: Optional[str] = None,
            issuer:  Optional[str] = None,
            scope:  Optional[str] = None,
            
        ):
        def config_fallback(config, attr, fallback):
            defaults = {
            "client_id": "clientid",
            "redirect_uri": "redirecturi",
            "client_secret": "clientsecret",
            "auth_uri": "https://accounts.google.com/o/oauth2/v2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "user_uri": "https://openidconnect.googleapis.com/v1/userinfo",
            "revoke_uri": "https://oauth2.googleapis.com/revoke",
            "jwks_uri": "https://www.googleapis.com/oauth2/v3/certs",
            "cert_uri": "https://www.googleapis.com/oauth2/v1/certs",
            "issuer": "https://accounts.google.com",
            "scope": "openid email profile",
        }
            return getattr(config, attr, None) or fallback or defaults[attr]
        
        self.client_id : str = config_fallback(config, "client_id", client_id)
        self.redirect_uri : str = config_fallback(config, "redirect_uri", redirect_uri)
        self.client_secret : str = config_fallback(config, "client_secret", client_secret)
        self.auth_uri : str = config_fallback(config, "auth_uri", auth_uri)
        self.token_uri : str = config_fallback(config, "token_uri", token_uri)
        self.user_uri : str = config_fallback(config, "user_uri", user_uri)
        self.refresh_uri : str = config_fallback(config, "refresh_uri", refresh_uri)
        self.revoke_uri : str = config_fallback(config, "revoke_uri", revoke_uri)
        self.jwks_uri : str = config_fallback(config, "jwks_uri", jwks_uri)
        self.cert_uri : str = config_fallback(config, "cert_uri", cert_uri)
        self.issuer : str = config_fallback(config, "issuer", issuer)
        self.scope : str = config_fallback(config, "scope", scope)

    async def auth_url(self, prompt: str = "consent") -> str:
        state, nonce = await GoogleUtil.create_session()
        prompt = f"{prompt} select_account" if prompt in ["consent", "login"] else prompt
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "response_type": "code",
            "scope": self.scope,
            "access_type": "offline",
            "prompt": prompt,
            "state": state,
            "nonce": nonce,
        }
        return f"{self.auth_uri}?{urllib.parse.urlencode(params)}"

    async def create(self, code : str):
        async with AsyncClient() as client:
            response = await client.post(self.token_uri, data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "code": code,
                "grant_type": "authorization_code",
                "redirect_uri": self.redirect_uri,
            })
            return response.json()

    async def refresh(self, refresh_token):
        async with AsyncClient() as client:
            response = await client.post(self.token_uri, data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "refresh_token": refresh_token,
                "grant_type": "refresh_token",
                "redirect_uri": self.redirect_uri,
            })
            return response.json()

    async def revoke(self, access_token):
        async with AsyncClient() as client:
            response = await client.post(self.revoke_uri, data={"token": access_token})
        return response.json()
    
    async def userinfo(self, access_token, token_type="Bearer"):
        async with AsyncClient() as client:
            response = await client.get(
                self.user_uri,
                headers={"Authorization": f"{token_type} {access_token}"}
            )
        return response.json()
    
    async def keyalg(self, id_token):
        header = jwt.get_unverified_header(id_token)
        async with AsyncClient() as client:
            if self.jwks_uri:
                jwks = (await client.get(self.jwks_uri)).json()
                key = next((k for k in jwks["keys"] if k["kid"] == header["kid"]), None)
            else:
                certs = (await client.get(self.cert_uri)).json()
                cert = next((key for kid, key in certs.items() if kid == header["kid"]), None)
                cert = load_pem_x509_certificate(cert.encode("utf-8"), default_backend()) if cert else None
                key = cert.public_key().public_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PublicFormat.SubjectPublicKeyInfo
                ) if cert else None

        if not key:
            raise ValueError("No matching key found")
        return key, header["alg"]

    async def verify(self, id_token, access_token):
        try:
            key, alg = await self.keyalg(id_token)
            return jwt.decode(
                token=id_token,
                key=key,
                algorithms=[alg],
                audience=self.client_id,
                issuer=self.issuer,
                access_token=access_token
            )
        except Exception as e:
            print(f"Verification failed: {e}")
            return None

    async def token(self, state : str, code : str):
        session_id = await GoogleUtil.session_id(state)
        if not await GoogleUtil.verify_state(session_id, state):
            return {"status_code": 400, "detail": "Invalid state Error", "token": None, "user": None}
        token_data = await self.create(code)
        if "error" in token_data:
            return {"status_code": 400, "detail": "Invalid Response Error", "token": None, "user": None}
        id_token = token_data["id_token"]
        access_token = token_data["access_token"]
        token_type = token_data["token_type"]
        payload = await self.verify(id_token, access_token)
        if not payload:
            return {"status_code": 400, "detail": "Invalid Response Error", "token": None, "user": None}
        if not await GoogleUtil.verify_nonce(session_id, payload.get("nonce")):
            return {"status_code": 400, "detail": "Invalid Response Error", "token": None, "user": None}
        userinfo = await self.userinfo(access_token, token_type)
        if "error" in userinfo:
            return {"status_code": 400, "detail": "Invalid Response Error", "token": None, "user": None}

        return {
            "status_code": 200,
            "detail": "Authentication successful",
            "token": Token.model_validate({**token_data, **id_token}), 
            "user": User.model_validate({**userinfo, **id_token})
        }

    async def user(self, token, token_type, is_refresh=False):
        if not is_refresh:
            userinfo = await self.userinfo(token, token_type)
            if "error" in userinfo:
                return {"status_code": 400, "detail": "Invalid Response Error", "token": None, "user": None}
            return {
                "status_code": 200,
                "detail": "Authentication successful",
                "token": None, 
                "user": User.model_validate({**userinfo})
            }
        
        token_data = await self.refresh(token)
        if "error" in token_data:
            return {"status_code": 400, "detail": "Invalid Response Error", "token": None, "user": None}
        id_token = token_data["id_token"]
        access_token = token_data["access_token"]
        token_type = token_data["token_type"]
        payload = await self.verify(id_token, access_token)
        if not payload:
            return {"status_code": 400, "detail": "Invalid Response Error", "token": None, "user": None}
        userinfo = await self.userinfo(access_token, token_type)
        if "error" in userinfo:
            return {"status_code": 400, "detail": "Invalid Response Error", "token": None, "user": None}
        
        return {
            "status_code": 200,
            "detail": "Authentication successful",
            "token": Token.model_validate({**token_data, **id_token}), 
            "user": User.model_validate({**userinfo, **id_token})
        }
    
class GoogleUtil:
    @classmethod
    async def create_session(cls):
        nonce = secrets.token_urlsafe(12)
        session_state = secrets.token_urlsafe(32)
        auth_state = await cls.auth_state(session_state)
        session_id = await cls.session_id(auth_state)
        await backend.create(
            session_id, 
            SessionData(
                secure_nonce=nonce, 
                session_state=session_state
            )
        )
        return auth_state, nonce
    
    @classmethod
    async def verify_state(cls, session_id, state, delete_session=False) -> bool:
        session_data = await cls.read_session(session_id)
        if not session_data:
            return False
        if delete_session:
            await cls.delete_session(session_id)
        return await cls.auth_state(session_data.session_state) == state
    
    @classmethod
    async def verify_nonce(cls, session_id, nonce, delete_session=True) -> bool:
        session_data = await cls.read_session(session_id)
        if not session_data:
            return False
        if delete_session:
            await cls.delete_session(session_id)
        return session_data.secure_nonce == nonce
    
    @staticmethod
    async def auth_state(session_state: str) -> str:
        digest = sha256(session_state.encode()).digest()
        return base64.urlsafe_b64encode(digest).rstrip(b"=").decode()

    @staticmethod
    async def session_id(auth_state: str) -> str:
        padding = b"=" * (-len(auth_state.encode()) % 4)
        digest = base64.urlsafe_b64decode(auth_state.encode() + padding)
        return base64.urlsafe_b64encode(digest[:16]).rstrip(b"=").decode()
    
    @staticmethod
    async def read_session(session_id):
        return await backend.read(session_id)
    
    @staticmethod
    async def delete_session(session_id):
        await backend.delete(session_id)

class User(SQLModel):
    id: str = Field(index=True, alias="sub")
    email: str = Field(index=True)
    email_verified: bool = Field()
    name: Optional[str] = Field(default=None)
    given_name: Optional[str] = Field(default=None)
    family_name: Optional[str] = Field(default=None)
    picture: Optional[str] = Field(default=None)
    origin: str = Field(index=True, default="google")

class Token(SQLModel):
    access_token: str = Field()
    refresh_token: Optional[str] = Field(default=None)
    token_type: str = Field()
    expires_in: int = Field()
    iss: str  = Field()
    iat: int = Field()
    exp: int = Field()

class SessionData(SQLModel):
    secure_nonce: str = Field()
    session_state: str = Field()

backend = InMemoryBackend[str, SessionData]()