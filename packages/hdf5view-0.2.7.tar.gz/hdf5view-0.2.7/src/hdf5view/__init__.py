"""hdf5view: a simple viewer for HDF5 files."""

__version__ = "0.2.7"
