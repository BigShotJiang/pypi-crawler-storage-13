"""Tests for linpredict."""

import pytest
from linpredict import fit, predict_next, quick_predict, LineEquation


class TestFit:
    def test_perfect_line(self):
        """Test fitting a perfect linear relationship."""
        eq = fit([1, 2, 3, 4], [2, 4, 6, 8])
        assert eq.slope == pytest.approx(2.0)
        assert eq.intercept == pytest.approx(0.0)

    def test_with_intercept(self):
        """Test line with non-zero intercept."""
        eq = fit([0, 1, 2], [5, 7, 9])
        assert eq.slope == pytest.approx(2.0)
        assert eq.intercept == pytest.approx(5.0)

    def test_negative_slope(self):
        """Test line with negative slope."""
        eq = fit([1, 2, 3], [10, 8, 6])
        assert eq.slope == pytest.approx(-2.0)
        assert eq.intercept == pytest.approx(12.0)

    def test_minimum_points(self):
        """Test with exactly 2 points."""
        eq = fit([0, 1], [0, 5])
        assert eq.slope == pytest.approx(5.0)

    def test_mismatched_lengths_raises(self):
        """Test that mismatched x and y lengths raise error."""
        with pytest.raises(ValueError, match="same length"):
            fit([1, 2, 3], [1, 2])

    def test_insufficient_points_raises(self):
        """Test that single point raises error."""
        with pytest.raises(ValueError, match="at least 2"):
            fit([1], [2])


class TestLineEquation:
    def test_predict_single(self):
        """Test predicting a single value."""
        eq = LineEquation(slope=2.0, intercept=1.0)
        assert eq.predict(5) == pytest.approx(11.0)

    def test_predict_list(self):
        """Test predicting multiple values."""
        eq = LineEquation(slope=2.0, intercept=1.0)
        result = eq.predict([1, 2, 3])
        assert result == [pytest.approx(3.0), pytest.approx(5.0), pytest.approx(7.0)]

    def test_str_positive_intercept(self):
        """Test string representation with positive intercept."""
        eq = LineEquation(slope=2.0, intercept=3.0)
        assert "2.0000x + 3.0000" in str(eq)

    def test_str_negative_intercept(self):
        """Test string representation with negative intercept."""
        eq = LineEquation(slope=2.0, intercept=-3.0)
        assert "2.0000x - 3.0000" in str(eq)


class TestPredictNext:
    def test_predict_one_step(self):
        """Test predicting next single value."""
        x, y = predict_next([1, 2, 3], [2, 4, 6])
        assert x == [pytest.approx(4.0)]
        assert y == [pytest.approx(8.0)]

    def test_predict_multiple_steps(self):
        """Test predicting multiple future values."""
        x, y = predict_next([1, 2, 3], [2, 4, 6], steps=3)
        assert len(x) == 3
        assert x == [pytest.approx(4.0), pytest.approx(5.0), pytest.approx(6.0)]
        assert y == [pytest.approx(8.0), pytest.approx(10.0), pytest.approx(12.0)]


class TestQuickPredict:
    def test_quick_predict_simple(self):
        """Test quick predict with sequential data."""
        result = quick_predict([2, 4, 6, 8])
        assert result == [pytest.approx(10.0)]

    def test_quick_predict_multiple(self):
        """Test quick predict multiple steps."""
        result = quick_predict([0, 3, 6], steps=2)
        assert result == [pytest.approx(9.0), pytest.approx(12.0)]