# LinPredict

[![PyPI version](https://badge.fury.io/py/linpredict.svg)](https://pypi.org/project/linpredict/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Simple linear prediction library. Pass x and y values, get the next predicted value.

## Installation

```bash
pip install linpredict
```

## Quick Start

```python
from linpredict import quick_predict, fit, predict_next

# Simplest usage - just pass y values
predictions = quick_predict([2, 4, 6, 8])
print(predictions)  # [10.0]

# Predict multiple steps ahead
predictions = quick_predict([2, 4, 6, 8], steps=3)
print(predictions)  # [10.0, 12.0, 14.0]
```

## Full Usage

```python
from linpredict import fit, predict_next

# Fit a line to your data
x = [1, 2, 3, 4, 5]
y = [2.1, 3.9, 6.2, 7.8, 10.1]

# Get the line equation
eq = fit(x, y)
print(eq)  # y = 1.9900x + 0.0600

# Access slope and intercept
print(f"Slope: {eq.slope}")      # ~2.0
print(f"Intercept: {eq.intercept}")  # ~0.0

# Predict specific x values
print(eq.predict(6))      # Single prediction
print(eq.predict([6, 7, 8]))  # Multiple predictions

# Or use predict_next for automatic next value
next_x, next_y = predict_next(x, y, steps=2)
print(f"Next x: {next_x}, Next y: {next_y}")
```

## API Reference

### `fit(x, y) -> LineEquation`
Fit a line (y = mx + c) to data points. Returns a `LineEquation` object.

### `predict_next(x, y, steps=1) -> (list, list)`
Predict the next value(s) in sequence. Returns tuple of (next_x_values, predicted_y_values).

### `quick_predict(y, steps=1) -> list`
Quick prediction when you only have y values (assumes x is 0, 1, 2, ...).

### `LineEquation`
- `.slope` - The m in y = mx + c
- `.intercept` - The c in y = mx + c  
- `.predict(x)` - Predict y for given x value(s)

## License

MIT

## Author
PRAVIN MR

GitHub: https://github.com/mr-pravin

Email: mrpravin000@gmail.com