"""
LinPredict - Simple linear prediction from data points.

Example:
    >>> from linpredict import quick_predict
    >>> quick_predict([2, 4, 6, 8])
    [10.0]
"""

from .core import fit, predict_next, quick_predict, LineEquation

__version__ = "0.1.0"
__all__ = ["fit", "predict_next", "quick_predict", "LineEquation"]