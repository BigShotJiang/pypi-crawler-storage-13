"""
LinPredict - Simple linear prediction from x, y data points.
Fit a line (y = mx + c) and predict the next value.
"""

from typing import List, Tuple, Union
from dataclasses import dataclass


@dataclass
class LineEquation:
    """Represents a fitted line y = mx + c"""
    slope: float  # m
    intercept: float  # c

    def predict(self, x: Union[float, List[float]]) -> Union[float, List[float]]:
        """Predict y value(s) for given x value(s)."""
        if isinstance(x, list):
            return [self.slope * xi + self.intercept for xi in x]
        return self.slope * x + self.intercept

    def __str__(self) -> str:
        sign = "+" if self.intercept >= 0 else "-"
        return f"y = {self.slope:.4f}x {sign} {abs(self.intercept):.4f}"


def fit(x: List[float], y: List[float]) -> LineEquation:
    """
    Fit a line to the given x and y data points.

    Args:
        x: List of x values
        y: List of y values (same length as x)

    Returns:
        LineEquation with slope (m) and intercept (c)

    Example:
        >>> eq = fit([1, 2, 3], [2, 4, 6])
        >>> eq.slope
        2.0
    """
    if len(x) != len(y):
        raise ValueError("x and y must have the same length")
    if len(x) < 2:
        raise ValueError("Need at least 2 data points")

    n = len(x)
    sum_x = sum(x)
    sum_y = sum(y)
    sum_xy = sum(xi * yi for xi, yi in zip(x, y))
    sum_x2 = sum(xi ** 2 for xi in x)

    # Calculate slope (m) and intercept (c)
    m = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x ** 2)
    c = (sum_y - m * sum_x) / n

    return LineEquation(slope=m, intercept=c)


def predict_next(x: List[float], y: List[float], steps: int = 1) -> Tuple[List[float], List[float]]:
    """
    Predict the next value(s) in the sequence.

    Args:
        x: List of x values
        y: List of y values
        steps: Number of future steps to predict (default: 1)

    Returns:
        Tuple of (next_x_values, predicted_y_values)

    Example:
        >>> x = [1, 2, 3, 4]
        >>> y = [2, 4, 6, 8]
        >>> next_x, next_y = predict_next(x, y)
        >>> next_y
        [10.0]
    """
    eq = fit(x, y)

    # Determine step size from x values
    step_size = (x[-1] - x[0]) / (len(x) - 1) if len(x) > 1 else 1

    next_x = [x[-1] + step_size * (i + 1) for i in range(steps)]
    next_y = eq.predict(next_x)

    return next_x, next_y


# Convenience function for quick predictions
def quick_predict(y: List[float], steps: int = 1) -> List[float]:
    """
    Predict next value(s) when you only have y values.
    Assumes x values are sequential integers starting from 0.

    Example:
        >>> quick_predict([2, 4, 6, 8])
        [10.0]
    """
    x = list(range(len(y)))
    _, predictions = predict_next(x, y, steps)
    return predictions