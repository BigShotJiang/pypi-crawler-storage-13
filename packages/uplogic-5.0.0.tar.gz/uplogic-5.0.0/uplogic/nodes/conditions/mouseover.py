from bge import logic
from uplogic.nodes import ULConditionNode
from uplogic.utils.raycasting import raycast_mouse


class ULMouseOver(ULConditionNode):
    def __init__(self):
        ULConditionNode.__init__(self)
        self.game_object = None
        self._mouse_entered_status = False
        self._mouse_exited_status = False
        self._mouse_over_status = False
        self._point = None
        self._normal = None
        self.MOUSE_ENTERED = self.add_output(self._get_mouse_entered)
        self.MOUSE_EXITED = self.add_output(self._get_mouse_exited)
        self.MOUSE_OVER = self.add_output(self._get_mouse_over)
        self.POINT = self.add_output(self._get_point)
        self.NORMAL = self.add_output(self._get_normal)
        self._last_target = None

    def _get_mouse_entered(self):
        return self._mouse_entered_status

    def _get_mouse_exited(self):
        return self._mouse_exited_status

    def _get_mouse_over(self):
        return self._mouse_over_status

    def _get_point(self):
        return self._point

    def _get_normal(self):
        return self._normal

    def evaluate(self):
        game_object = self.get_input(self.game_object)
        scene = game_object.scene
        camera = scene.active_camera
        distance = 2.0 * camera.getDistanceTo(game_object)
        target, point, normal, dir, face, uv = raycast_mouse(
            distance=distance
        )
        if not (target is self._last_target):  # mouse over a new object
            # was target, now it isn't -> exited
            if self._last_target is game_object:
                self._mouse_exited_status = True
                self._mouse_over_status = False
                self._mouse_entered_status = False
                self._point = None
                self._normal = None
            # wasn't target, now it is -> entered
            elif (target is game_object):
                self._mouse_entered_status = True
                self._mouse_over_status = False
                self._mouse_exited_status = False
                self._point = point
                self._normal = normal
            self._last_target = target
        else:  # the target has not changed
            # was target, still target -> over
            if self._last_target is game_object:
                self._mouse_entered_status = False
                self._mouse_exited_status = False
                self._mouse_over_status = True
                self._point = point
                self._normal = normal
            else:  # wans't target, still isn't target -> clear
                self._mouse_entered_status = False
                self._mouse_exited_status = False
                self._mouse_over_status = False
                self._point = None
                self._normal = None
