from uplogic.nodes import ULActionNode
from uplogic import console


class ULRemoveListValue(ULActionNode):
    def __init__(self):
        ULActionNode.__init__(self)
        self.condition = None
        self.items = None
        self.val = None
        self.new_list = None
        self.OUT = self.add_output(self.get_done)
        self.LIST = self.add_output(self.get_list)

    def get_done(self):
        return self._done

    def get_list(self):
        return self.new_list

    def evaluate(self):
        if not self.get_condition():
            return
        list_d = self.get_input(self.items)
        val = self.get_input(self.val)
        if val in list_d:
            list_d.remove(val)
        else:
            console.debug("List Remove Value Node: Item '{}' not in List!".format(val))
            return
        self.new_list = list_d
        self._done = True
