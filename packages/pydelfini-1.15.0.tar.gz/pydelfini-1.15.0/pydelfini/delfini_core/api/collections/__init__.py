"""Collections operations"""
