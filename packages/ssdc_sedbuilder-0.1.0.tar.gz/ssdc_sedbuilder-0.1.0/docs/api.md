# API Reference

This API reference describes the Python interface to the ASI-SSDC SED Builder service. 
The package provides functions to query astronomical sources and convert spectral energy distribution data into various formats.

!!! warning
    At present, `sedbuilder` is only internally operational.
    This means you need to be on the ASI-SSDC network to use it.
    We will release to public soon.

!!! note
    At present, only internally hosted catalogs are supported. More will come.


## Functions

::: sedbuilder.requests.get_data
::: sedbuilder.utils.get_data_from_json

## Classes

::: sedbuilder.schemas.Response
