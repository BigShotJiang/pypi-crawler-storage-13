__version__ = "0.0.4"
from .npmai import GeminiAIMode, Gemini, ChatGPT, Grok, Perplexity
