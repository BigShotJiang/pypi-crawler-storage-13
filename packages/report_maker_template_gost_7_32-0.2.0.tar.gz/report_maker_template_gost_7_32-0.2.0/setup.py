from pathlib import Path

from extended_setup import ExtendedSetupManager
from setuptools import find_namespace_packages


ROOT_PACKAGE = 'report_maker.templates.gost_7_32'
ROOT_DIR = Path(ROOT_PACKAGE.replace('.', '/'))

# ToDo: Move this to the `extended-setup-tools`
def _find_packages():
    packages = find_namespace_packages(where='src')
    parent = ROOT_PACKAGE
    sep = '.'
    while sep and parent:
        parent, sep, _ = parent.rpartition(sep)
        if parent in packages:
            packages.remove(parent)
    
    return packages


ExtendedSetupManager(str(ROOT_PACKAGE)).setup \
(
    short_description = "Configuration and templates needed to satisfy GOST-7.32 requirements while building a project",
    category = 'report-maker/templates',
    url = 'https://gitlab.com/Hares-Lab/report-maker/templates/gost-7.32',
    min_python_version = '3.12',
    packages = _find_packages(),
    package_data = { ROOT_PACKAGE: [ 'configs/**/*.conf', 'documents/**/*.docx' ]},
    classifiers =
    [
        'Development Status :: 2 - Pre-Alpha',
        'Environment :: Plugins',
        'Intended Audience :: Developers',
        'Natural Language :: English',
        'Natural Language :: Russian',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3.12',
        'Topic :: Documentation',
        'Topic :: Text Processing :: Markup :: Markdown',
        'Topic :: Text Processing',
        'Topic :: Utilities',
        'Typing :: Typed',
    ]
)
