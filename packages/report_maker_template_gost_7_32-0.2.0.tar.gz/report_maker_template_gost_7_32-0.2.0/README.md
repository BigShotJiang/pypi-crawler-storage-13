# Report Maker - GOST-7.32 Template
This repository stores configuration and templates
needed to satisfy [GOST-7.32] requirements while building a project.

Note that this will not work on its own,
and requires [report-maker] to run.

Also includes front pages for the [GUAP] University.

## Usage
1. Install via pip:
   ```
   pip install report-maker-template-gost-7.32
   ```
2. In your report composer config, set `composer.template: gost-7.32`.
3. If you need to override any part of the styles config,
   you can do so by adding `overrides` key at the composer config:
   ```hocon
   composer.overrides.styles.Normal.font.name: "Cambria"
   composer.overrides.styles.Normal.font.size: "12 pt"  // "pt" is important!
   ```

### Built-in templates
This template also provides the following document templates:

`toc.docx`
:   A *static* document template for the Table of Contents.
    Requires manual reindexing after document rendering.
    ```hocon
    {
        name: toc
        type: from-template
        document_path: "toc.docx"
    }
    ```

`guap-front-pages/front-page-*.docx`
:   A group of *dynamic* document templates
    for the different kind of homework tasks from the [GUAP] university.
    The `front-page-universal.docx` is generic enough to be used for all kind of tasks.
    ```hocon
    {
        name: title
        type: template
        template: "guap-front-pages/front-page-universal.docx"
        attributes: { ... } // described below
    }
    ```
    + `front-page-universal.docx` -- Generic approximation of the templates below
    + `front-page-lab.docx` -- Minimalistic front page for the lab work report
    + `front-page-control.docx` -- Front page for the control homework report
    + `front-page-essay.docx` -- Front page for the essay or research paper report
    + `front-page-term-project.docx` -- Front page for the term/course project report

#### Dynamic template parameters:
* `department.id`: _Discipline_ department ID (`lab` only)
* `department.name`: _Discipline_ department name (all except `lab`)
* `category`: Work type category (`universal` only)
* `title:` Current report title
* `course`: Discipline full name
* `professor.title`: Professor's title, in the standard short form
* `professor.name`: Professor's name, in "F.M. LastName" form
* `author.id`: Author's internal ID
* `author.name`: Author's name, in "F.M. LastName" form
* `author.class`: Author's class ID (not needed)

Example:
```hocon
attributes:
{
    department.id: 43
    department.name: "Кафедра компьютерных технологий и программной инженерии"
    category: "Отчёт о лабораторной работе №"${lab_number}
    title: ${lab_title}
    course: "Основы программирования"
    
    professor.title: "к.т.н., доц."
    professor.name: "И.И. Иванов"
    
    author.id: "2023/1338"
    author.name: "П.О. Зайцев"
    author.class: "4331з"
}
```


## Licensing
*see: [LICENSE.txt](./LICENSE.txt)*

[BSD-2 License].
Copyright (c) Peter Zaitcev, 2025.

[GOST-7.32]: https://cs.msu.ru/sites/cmc/files/docs/2021-11gost_7.32-2017.pdf
[report-maker]: https://gitlab.com/Hares-Lab/report-maker/report-maker
[GUAP]: https://guap.ru
