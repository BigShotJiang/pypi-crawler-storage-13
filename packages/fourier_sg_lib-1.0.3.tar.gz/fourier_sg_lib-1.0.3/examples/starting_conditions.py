import numpy as np
import sglib.sg_soliton_functions as ssf

def kink_kink_start(x,v,x0):
    u0 = ssf.kink_kink(x,t=0,v=v)
    v0 = np.zeros_like(u0)  
    return(u0,v0,'kink_kink_filtered.gif','kink_kink',ssf.kink_kink,True)

def kink_start(x,v,x0):
    u0 = ssf.kink(x,t=0,v=v,x0=x0)
    v0 = ssf.kink_t(x, t=0, x0=x0, v=v)  
    return(u0,v0,'kink_filtered.gif','kink_kink',ssf.kink,True)

def kink_antikink_start(x,v,x0=12):
    u0 = ssf.kink_plus_antikink(x, 0.0,v,x0)
    v0 = ssf.kink_t(x, 0.0, -x0,  v)+ssf.antikink_t(x, 0.0, x0,  -v)
    return(u0,v0,'kink_antikink.gif','kink_antikink',ssf.kink_plus_antikink,True)

def stat_breather_start(x,w):
    u0 = ssf.breather(x,0,v=0,w=w,gamma = 1)
    v0 = np.zeros_like(u0)
    return(u0,v0,'stationary_breather.gif','breather',ssf.breather,False)

def breather_start(x,v,w,gamma):
    u0 = ssf.breather(x,0,v,w,gamma)
    #time derivative
    v0 = ssf.breather_t(x,0,v,w,gamma)
    return(u0,v0,'moving_breather.gif','moving breather',ssf.breather,True)

def breather_breather_start(x,v,w,gamma,x0=15):
    #u0 = ssf.breather(x-x0,0,v=-v,w=w,gamma=gamma) + ssf.breather(x+x0,0,v=v,w=w,gamma=gamma)
    #v0 = ssf.breather_t(x-x0,0,v=-v,w=w,gamma=gamma) + ssf.breather_t(x+x0,0,v=v,w=w,gamma=gamma)
    u0 = ssf.two_breathers(x,0,v,w,gamma,x0)
    v0 = ssf.numeric_2_breathers_dt0(x,v,w,gamma,x0)

    return(u0,v0,'breather_collision.gif','breather_breather',ssf.two_breathers,True)