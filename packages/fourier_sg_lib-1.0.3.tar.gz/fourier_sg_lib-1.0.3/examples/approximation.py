import numpy as np
import gif_gen as gg
import sg_soliton_functions as ssf
import matplotlib.pyplot as plt
import two_soliton_start as two_s
import split_step_Fourier as split_f
from functools import partial
def starting_point():
    # Grid
    Nx, Lx = 1028, 100.0
    x = np.linspace(-Lx/2, Lx/2, Nx, endpoint=False,dtype=np.longdouble)
    dx = x[1]-x[0]
    k = 2*np.pi*np.fft.fftfreq(Nx, d=dx)
    x0=15
    
    # Time
    dt, T = 0.01, 40.0
    steps = int(T/dt)
    save_every = max(1,steps//90)
    speed = 0.5
    w = 0.5
    gamma = 1/np.sqrt(1-speed**2)

    U_t =[]
    orders = [15,14,13,11]
    '''
    method = split_f.strang_split_step
    # Starting point
    u0,v0,name,title,f_a,kfilter = two_s.kink_antikink_start(x,speed,x0)
    # Integration
    for o in orders:
        Ut_approx,time = split_f.integration_loop(u0,v0,steps,save_every,dt,k,kfilter,method,nonlinear_step=partial(split_f.kg_nonlinear_step,order=o))
        U_t.append(Ut_approx)
        print(f"U_t order: {o} done!")
    U_a = np.array([f_a(x,t,speed,x0) for t in time])
    U_t.append(U_a)
    labels = [f"Order: {o}" for o in orders]
    labels.append("Analytic solution") 
    # Making a gif
    gg.giff_comp(x,U_t,time,labels,"Comparision of Taylor approximation\nkink-antikink collision","kink_antikink_order_2nd.gif")
    method = split_f.step_4th_order
    U_t=[]
    for o in orders:
        Ut_approx,time = split_f.integration_loop(u0,v0,steps,save_every,dt,k,kfilter,method,nonlinear_step=partial(split_f.kg_nonlinear_step,order=o))
        U_t.append(Ut_approx)
        print(f"Ut order: {o} done!")
    U_a = np.array([f_a(x,t,speed,x0) for t in time])
    U_t.append(U_a)
    labels = [f"Order: {o}" for o in orders]
    labels.append("Analytic solution") 
    # Making a gif
    gg.giff_comp(x,U_t,time,labels,"Comparision of Taylor approximation\nkink-antikink collision","kink_antikink_order_4th.gif")
    '''
    method = split_f.step_4th_order
    U_t=[]
    orders = [11,10,8,6]
    u0,v0,name,title,f_a,kfilter = two_s.moving_breather(x,speed,w,gamma)
    for o in orders:
        Ut_approx,time = split_f.integration_loop(u0,v0,steps,save_every,dt,k,kfilter,method,nonlinear_step=partial(split_f.kg_nonlinear_step,order=o))
        U_t.append(Ut_approx)
        print(f"Ut order: {o} done!")
    U_a = np.array([f_a(x,t,speed,w,gamma) for t in time])
    U_t.append(U_a)
    labels = [f"Order: {o}" for o in orders]
    labels.append("Analytic solution") 
    # Making a gif
    gg.giff_comp(x,U_t,time,labels,"Comparision of Taylor approximation\nmoving breather",f"breather_v{speed}_w{w}_order_4th.gif")

    method = split_f.strang_split_step
    U_t=[]

    u0,v0,name,title,f_a,kfilter = two_s.moving_breather(x,speed,w,gamma)
    for o in orders:
        Ut_approx,time = split_f.integration_loop(u0,v0,steps,save_every,dt,k,kfilter,method,nonlinear_step=partial(split_f.kg_nonlinear_step,order=o))
        U_t.append(Ut_approx)
        print(f"Ut order: {o} done!")
    U_a = np.array([f_a(x,t,speed,w,gamma) for t in time])
    U_t.append(U_a)
    labels = [f"Order: {o}" for o in orders]
    labels.append("Analytic solution") 
    # Making a gif
    gg.giff_comp(x,U_t,time,labels,"Comparision of Taylor approximation\nmoving breather",f"breather_v{speed}_w{w}_order_2nd.gif")
    #print(timeline[0:4])
starting_point()