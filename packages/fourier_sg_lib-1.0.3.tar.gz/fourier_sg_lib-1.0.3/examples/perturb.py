import numpy as np
import gif_gen as gg
import sg_soliton_functions as ssf
import matplotlib.pyplot as plt
import two_soliton_start as two_s
import split_step_Fourier as split_f
from functools import partial
import measure as msr
def starting_point():
    # Grid
    Nx, Lx = 1028, 100.0
    x = np.linspace(-Lx/2, Lx/2, Nx, endpoint=False,dtype=np.longdouble)
    dx = x[1]-x[0]
    k = 2*np.pi*np.fft.fftfreq(Nx, d=dx)
    x0=15
    
    # Time
    dt, T = 0.01, 40.0
    steps = int(T/dt)
    save_every = max(1,steps//90)
    speed = 0.7
    w = 0.5
    gamma = 1/np.sqrt(1-speed**2)

    U_t =[]
    eps = [-1e-5,1e-5]
    '''
    method = split_f.strang_split_step
    # Starting point
    u0,v0,name,title,f_a,kfilter = two_s.kink_antikink_start(x,speed,x0)
    method = split_f.step_4th_order
    U_t=[]
    for e in eps:
        Ut_approx,time = split_f.integration_loop(u0,v0,steps,save_every,dt,k,kfilter,method,nonlinear_step=partial(split_f.perturb_sg,eps1=0,eps2=e))
        msr.measure_all(Ut_approx,x,time)
        U_t.append(Ut_approx)
        print(f"Ut order: {e} done!")
    U_a = np.array([f_a(x,t,speed,x0) for t in time])
    U_t.append(U_a)
    labels = [f"$\epsilon$ : {e:.0e}" for e in eps]
    labels.append("Analytic solution") 
    # Making a gif
    gg.giff_comp(x,U_t,time,labels,"Comparision of interaction perturbation\nkink-antikink collision","kink_antikink_interactions.gif")
'''
    method = split_f.step_4th_order
    U_t=[]
    eps = [-1e-4,1e-4]
    u0,v0,name,title,f_a,kfilter = two_s.breather_start(x,speed,w,gamma)
    for e in eps:
        Ut_approx,time = split_f.integration_loop(u0,v0,steps,save_every,dt,k,kfilter,method,nonlinear_step=partial(split_f.perturb_sg,eps1=e,eps2=0))
        U_t.append(Ut_approx)
        msr.measure_all(Ut_approx,x,time)
        print(f"Ut order: {e} done!")
    U_a = np.array([f_a(x,t,speed,w,gamma) for t in time])
    U_t.append(U_a)
    msr.measure_all(U_a,x,time)
    labels = [f"$\epsilon$ : {e:.0e}" for e in eps]
    labels.append("Analytic solution") 
    # Making a gif
    gg.giff_comp(x,U_t,time,labels,"Comparision of mass perturbation \nmoving breather",f"breather_v{speed}_w{w}mass.gif")


starting_point()