"""
Stream event merger utility for combining agent and tool streams.

Provides enterprise-grade stream merging following SOLID principles.
"""

import asyncio
import logging
from collections.abc import AsyncGenerator
from typing import Any, Union

from ...runners.interfaces import StreamEvent
from .interfaces import ToolStreamEvent

logger = logging.getLogger(__name__)


class StreamEventMerger:
    """
    Merges multiple async streams into a single ordered stream.
    
    Follows Single Responsibility Principle: Only handles stream merging.
    """
    
    def __init__(self, preserve_order: bool = True, buffer_size: int = 100):
        self._preserve_order = preserve_order
        self._buffer_size = buffer_size
        self._merged_queue: asyncio.Queue[Union[StreamEvent, ToolStreamEvent]] = asyncio.Queue(
            maxsize=buffer_size
        )
        self._active_streams: list[asyncio.Task] = []
        self._is_merging = False
    
    async def merge_streams(
        self,
        agent_stream: AsyncGenerator[StreamEvent, None],
        tool_stream: AsyncGenerator[ToolStreamEvent, None]
    ) -> AsyncGenerator[StreamEvent, None]:
        """
        Merge agent and tool streams into a unified stream.
        
        Args:
            agent_stream: Stream of agent events
            tool_stream: Stream of tool events
            
        Yields:
            Unified stream of events in temporal order
        """
        self._is_merging = True
        
        try:
            # Create tasks for each stream
            agent_task = asyncio.create_task(
                self._consume_agent_stream(agent_stream),
                name="agent_stream_consumer"
            )
            tool_task = asyncio.create_task(
                self._consume_tool_stream(tool_stream),
                name="tool_stream_consumer"
            )
            
            self._active_streams = [agent_task, tool_task]
            
            # Yield merged events
            async for event in self._yield_merged_events():
                yield event
                
        except Exception as e:
            logger.error(f"Error in stream merging: {e}")
            raise
        finally:
            await self._cleanup_streams()
    
    async def _consume_agent_stream(self, stream: AsyncGenerator[StreamEvent, None]) -> None:
        """Consume agent stream and add to merged queue."""
        try:
            async for event in stream:
                await self._merged_queue.put(event)
                logger.debug(f"Queued agent event: {event.event_type}")
        except Exception as e:
            logger.error(f"Error consuming agent stream: {e}")
        finally:
            logger.debug("Agent stream consumer finished")
    
    async def _consume_tool_stream(self, stream: AsyncGenerator[ToolStreamEvent, None]) -> None:
        """Consume tool stream and add to merged queue."""
        try:
            async for tool_event in stream:
                # Convert tool event to stream event
                stream_event = tool_event.to_stream_event()
                await self._merged_queue.put(stream_event)
                logger.debug(f"Queued tool event: {tool_event.event_type.value}")
        except Exception as e:
            logger.error(f"Error consuming tool stream: {e}")
        finally:
            logger.debug("Tool stream consumer finished")
    
    async def _yield_merged_events(self) -> AsyncGenerator[StreamEvent, None]:
        """Yield events from the merged queue in order."""
        agent_completed = False
        
        while self._is_merging or not self._merged_queue.empty() or self._has_active_streams():
            try:
                # Wait for events with timeout to allow periodic checks
                event = await asyncio.wait_for(self._merged_queue.get(), timeout=0.1)
                yield event
                
                # Check for agent completion events
                if event.event_type in ("agent_completed", "agent_error", "execution_completed"):
                    logger.debug(f"Agent completion detected: {event.event_type}")
                    agent_completed = True
                
                # Mark task done for queue management
                self._merged_queue.task_done()
                
                # If agent completed, stop merging after yielding the completion event
                if agent_completed:
                    logger.debug("Breaking merge loop due to agent completion")
                    break
                
            except asyncio.TimeoutError:
                # Check if streams are still active
                if not self._has_active_streams() and self._merged_queue.empty():
                    break
                continue
            except Exception as e:
                logger.error(f"Error yielding merged event: {e}")
                break
        
        logger.debug("Finished yielding merged events")
    
    def _has_active_streams(self) -> bool:
        """Check if any streams are still active."""
        return any(not task.done() for task in self._active_streams)
    
    async def _cleanup_streams(self) -> None:
        """Cleanup active streams and resources."""
        self._is_merging = False
        
        # Cancel active stream tasks
        for task in self._active_streams:
            if not task.done():
                task.cancel()
        
        # Wait for cancellation to complete
        if self._active_streams:
            await asyncio.gather(*self._active_streams, return_exceptions=True)
        
        # Clear queue
        while not self._merged_queue.empty():
            try:
                self._merged_queue.get_nowait()
                self._merged_queue.task_done()
            except asyncio.QueueEmpty:
                break
        
        self._active_streams.clear()
        logger.debug("Stream merger cleanup completed")


class TimeOrderedStreamMerger(StreamEventMerger):
    """
    Stream merger that maintains strict temporal ordering.
    
    Follows Open/Closed Principle: Extends base merger with ordering.
    """
    
    def __init__(self, buffer_size: int = 100, max_time_skew: float = 1.0):
        super().__init__(preserve_order=True, buffer_size=buffer_size)
        self._max_time_skew = max_time_skew
        self._event_buffer: list[Union[StreamEvent, ToolStreamEvent]] = []
    
    async def _yield_merged_events(self) -> AsyncGenerator[StreamEvent, None]:
        """Yield events in strict temporal order."""
        while self._is_merging or not self._merged_queue.empty() or self._has_active_streams():
            try:
                # Collect events for ordering
                event = await asyncio.wait_for(self._merged_queue.get(), timeout=0.1)
                self._event_buffer.append(event)
                
                # Process buffer when it reaches a certain size or timeout
                if len(self._event_buffer) >= 10 or not self._has_active_streams():
                    async for ordered_event in self._flush_ordered_buffer():
                        yield ordered_event
                
                self._merged_queue.task_done()
                
            except asyncio.TimeoutError:
                # Flush remaining events on timeout
                if self._event_buffer:
                    async for ordered_event in self._flush_ordered_buffer():
                        yield ordered_event
                
                if not self._has_active_streams() and self._merged_queue.empty():
                    break
                continue
            except Exception as e:
                logger.error(f"Error in time-ordered merging: {e}")
                break
        
        # Final flush
        async for ordered_event in self._flush_ordered_buffer():
            yield ordered_event
    
    async def _flush_ordered_buffer(self) -> AsyncGenerator[StreamEvent, None]:
        """Flush events from buffer in temporal order."""
        if not self._event_buffer:
            return
        
        # Sort by timestamp
        self._event_buffer.sort(key=lambda e: e.timestamp or 0)
        
        # Yield all buffered events
        for event in self._event_buffer:
            if isinstance(event, ToolStreamEvent):
                yield event.to_stream_event()
            else:
                yield event
        
        # Clear buffer
        self._event_buffer.clear()


class PriorityStreamMerger(StreamEventMerger):
    """
    Stream merger that respects event priorities.
    
    Follows Open/Closed Principle: Extends base merger with prioritization.
    """
    
    EVENT_PRIORITIES = {
        "agent_start": 100,
        "tool_start": 90,
        "tool_progress": 50,
        "tool_result": 60,
        "tool_error": 95,
        "tool_complete": 70,
        "agent_thinking": 40,
        "agent_response": 80,
        "agent_complete": 100,
        "execution_error": 99
    }
    
    def __init__(self, buffer_size: int = 100):
        super().__init__(preserve_order=False, buffer_size=buffer_size)
        self._priority_queue: asyncio.PriorityQueue = asyncio.PriorityQueue(maxsize=buffer_size)
    
    async def _consume_agent_stream(self, stream: AsyncGenerator[StreamEvent, None]) -> None:
        """Consume agent stream with priority queuing."""
        try:
            async for event in stream:
                priority = self._get_event_priority(event.event_type)
                await self._priority_queue.put((-priority, event))  # Negative for descending order
                logger.debug(f"Queued agent event with priority {priority}: {event.event_type}")
        except Exception as e:
            logger.error(f"Error consuming agent stream: {e}")
    
    async def _consume_tool_stream(self, stream: AsyncGenerator[ToolStreamEvent, None]) -> None:
        """Consume tool stream with priority queuing."""
        try:
            async for tool_event in stream:
                stream_event = tool_event.to_stream_event()
                priority = self._get_event_priority(stream_event.event_type)
                await self._priority_queue.put((-priority, stream_event))  # Negative for descending order
                logger.debug(f"Queued tool event with priority {priority}: {tool_event.event_type.value}")
        except Exception as e:
            logger.error(f"Error consuming tool stream: {e}")
    
    async def _yield_merged_events(self) -> AsyncGenerator[StreamEvent, None]:
        """Yield events by priority."""
        while self._is_merging or not self._priority_queue.empty() or self._has_active_streams():
            try:
                priority, event = await asyncio.wait_for(self._priority_queue.get(), timeout=0.1)
                yield event
                self._priority_queue.task_done()
            except asyncio.TimeoutError:
                if not self._has_active_streams() and self._priority_queue.empty():
                    break
                continue
            except Exception as e:
                logger.error(f"Error yielding priority event: {e}")
                break
    
    def _get_event_priority(self, event_type: str) -> int:
        """Get priority for event type."""
        return self.EVENT_PRIORITIES.get(event_type, 30)  # Default priority