"""
Tool streaming monitoring and metrics collection.

Provides enterprise-grade monitoring capabilities for tool streaming.
"""

import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

from .interfaces import ToolEventType


@dataclass
class ToolStreamingMetrics:
    """Metrics for tool streaming operations."""
    
    tool_name: str
    events_emitted: int = 0
    errors_count: int = 0
    start_time: float = field(default_factory=time.time)
    last_event_time: float = field(default_factory=time.time)
    event_type_counts: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    
    def record_event(self, event_type: ToolEventType) -> None:
        """Record an event occurrence."""
        self.events_emitted += 1
        self.last_event_time = time.time()
        self.event_type_counts[event_type.value] += 1
    
    def record_error(self) -> None:
        """Record an error occurrence."""
        self.errors_count += 1
    
    @property
    def duration(self) -> float:
        """Get total duration since start."""
        return time.time() - self.start_time
    
    @property
    def events_per_second(self) -> float:
        """Get events per second rate."""
        duration = self.duration
        return self.events_emitted / duration if duration > 0 else 0.0
    
    def to_dict(self) -> dict[str, Any]:
        """Convert metrics to dictionary."""
        return {
            "tool_name": self.tool_name,
            "events_emitted": self.events_emitted,
            "errors_count": self.errors_count,
            "duration_seconds": self.duration,
            "events_per_second": self.events_per_second,
            "event_type_counts": dict(self.event_type_counts),
            "start_time": self.start_time,
            "last_event_time": self.last_event_time,
        }


class ToolStreamingMonitor:
    """
    Monitor for tool streaming operations.
    
    Follows Single Responsibility Principle: Only monitors streaming operations.
    """
    
    def __init__(self):
        self._tool_metrics: dict[str, ToolStreamingMetrics] = {}
        self._global_start_time = time.time()
    
    def get_or_create_metrics(self, tool_name: str) -> ToolStreamingMetrics:
        """Get or create metrics for a tool."""
        if tool_name not in self._tool_metrics:
            self._tool_metrics[tool_name] = ToolStreamingMetrics(tool_name=tool_name)
        return self._tool_metrics[tool_name]
    
    def record_event(self, tool_name: str, event_type: ToolEventType) -> None:
        """Record an event for monitoring."""
        metrics = self.get_or_create_metrics(tool_name)
        metrics.record_event(event_type)
    
    def record_error(self, tool_name: str) -> None:
        """Record an error for monitoring."""
        metrics = self.get_or_create_metrics(tool_name)
        metrics.record_error()
    
    def get_tool_metrics(self, tool_name: str) -> ToolStreamingMetrics | None:
        """Get metrics for a specific tool."""
        return self._tool_metrics.get(tool_name)
    
    def get_all_metrics(self) -> dict[str, dict[str, Any]]:
        """Get all tool metrics."""
        return {
            tool_name: metrics.to_dict()
            for tool_name, metrics in self._tool_metrics.items()
        }
    
    def get_summary_metrics(self) -> dict[str, Any]:
        """Get summary metrics across all tools."""
        total_events = sum(m.events_emitted for m in self._tool_metrics.values())
        total_errors = sum(m.errors_count for m in self._tool_metrics.values())
        active_tools = len(self._tool_metrics)
        global_duration = time.time() - self._global_start_time
        
        return {
            "total_events": total_events,
            "total_errors": total_errors,
            "active_tools": active_tools,
            "global_duration_seconds": global_duration,
            "global_events_per_second": total_events / global_duration if global_duration > 0 else 0.0,
            "error_rate": total_errors / total_events if total_events > 0 else 0.0,
        }
    
    def reset_metrics(self, tool_name: str | None = None) -> None:
        """Reset metrics for a tool or all tools."""
        if tool_name:
            self._tool_metrics.pop(tool_name, None)
        else:
            self._tool_metrics.clear()
            self._global_start_time = time.time()


# Global monitor instance
_global_monitor = ToolStreamingMonitor()


def get_monitor() -> ToolStreamingMonitor:
    """Get the global tool streaming monitor."""
    return _global_monitor