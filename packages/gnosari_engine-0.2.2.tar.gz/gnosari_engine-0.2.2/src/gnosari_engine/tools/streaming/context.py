"""
Tool streaming context implementation.

Provides concrete implementation for tool event management
following SOLID principles and clean architecture.
"""

import asyncio
import logging
from collections.abc import AsyncGenerator
from typing import Any

from .exceptions import EventEmissionError, StreamCleanupError, StreamContextError
from .interfaces import (
    IToolEventEmitter,
    IToolStreamContext,
    IToolStreamManager,
    ToolEventType,
    ToolStreamEvent
)
from .monitoring import get_monitor

logger = logging.getLogger(__name__)


class ToolStreamContext(IToolStreamContext):
    """
    Concrete implementation of tool streaming context.
    
    Follows Single Responsibility Principle: Only manages tool event emission.
    """
    
    def __init__(self, event_emitter: IToolEventEmitter):
        self._event_emitter = event_emitter
        self._is_active = True
    
    async def emit_start(self, tool_name: str, data: dict[str, Any] | None = None) -> None:
        """Emit tool start event with comprehensive error handling."""
        if not self._is_active:
            return
        
        event = ToolStreamEvent(
            tool_name=tool_name,
            event_type=ToolEventType.TOOL_START,
            data=data or {}
        )
        
        try:
            await self._event_emitter.emit_event(event)
            get_monitor().record_event(tool_name, ToolEventType.TOOL_START)
            logger.debug(f"Emitted start event for tool: {tool_name}")
        except Exception as e:
            get_monitor().record_error(tool_name)
            logger.error(f"Failed to emit start event for tool {tool_name}: {e}")
            raise EventEmissionError(f"Failed to emit start event", tool_name, e)
    
    async def emit_progress(self, tool_name: str, data: dict[str, Any]) -> None:
        """Emit tool progress event with comprehensive error handling."""
        if not self._is_active:
            return
        
        event = ToolStreamEvent(
            tool_name=tool_name,
            event_type=ToolEventType.TOOL_PROGRESS,
            data=data
        )
        
        try:
            await self._event_emitter.emit_event(event)
            get_monitor().record_event(tool_name, ToolEventType.TOOL_PROGRESS)
            logger.debug(f"Emitted progress event for tool: {tool_name}")
        except Exception as e:
            get_monitor().record_error(tool_name)
            logger.error(f"Failed to emit progress event for tool {tool_name}: {e}")
            # Don't raise for progress events - they're not critical
    
    async def emit_result(self, tool_name: str, data: dict[str, Any]) -> None:
        """Emit tool intermediate result event with comprehensive error handling."""
        if not self._is_active:
            return
        
        event = ToolStreamEvent(
            tool_name=tool_name,
            event_type=ToolEventType.TOOL_RESULT,
            data=data
        )
        
        try:
            await self._event_emitter.emit_event(event)
            get_monitor().record_event(tool_name, ToolEventType.TOOL_RESULT)
            logger.debug(f"Emitted result event for tool: {tool_name}")
        except Exception as e:
            get_monitor().record_error(tool_name)
            logger.error(f"Failed to emit result event for tool {tool_name}: {e}")
            # Don't raise for result events - continue execution
    
    async def emit_error(self, tool_name: str, error: Exception) -> None:
        """Emit tool error event with comprehensive error handling."""
        if not self._is_active:
            return
        
        event = ToolStreamEvent(
            tool_name=tool_name,
            event_type=ToolEventType.TOOL_ERROR,
            data={
                "error_type": type(error).__name__,
                "error_message": str(error),
                "error_details": getattr(error, "__dict__", {})
            }
        )
        
        try:
            await self._event_emitter.emit_event(event)
            get_monitor().record_event(tool_name, ToolEventType.TOOL_ERROR)
            get_monitor().record_error(tool_name)
            logger.debug(f"Emitted error event for tool: {tool_name}")
        except Exception as e:
            get_monitor().record_error(tool_name)
            logger.error(f"Failed to emit error event for tool {tool_name}: {e}")
            # Error emission failure is critical - raise
            raise EventEmissionError(f"Failed to emit error event", tool_name, e)
    
    async def emit_complete(self, tool_name: str, data: dict[str, Any] | None = None) -> None:
        """Emit tool completion event with comprehensive error handling."""
        if not self._is_active:
            return
        
        event = ToolStreamEvent(
            tool_name=tool_name,
            event_type=ToolEventType.TOOL_COMPLETE,
            data=data or {}
        )
        
        try:
            await self._event_emitter.emit_event(event)
            get_monitor().record_event(tool_name, ToolEventType.TOOL_COMPLETE)
            logger.debug(f"Emitted complete event for tool: {tool_name}")
        except Exception as e:
            get_monitor().record_error(tool_name)
            logger.error(f"Failed to emit complete event for tool {tool_name}: {e}")
            # Completion event failure is important - raise
            raise EventEmissionError(f"Failed to emit complete event", tool_name, e)
    
    def deactivate(self) -> None:
        """Deactivate context to stop event emission."""
        self._is_active = False
        logger.debug("Tool stream context deactivated")


class AsyncQueueEventEmitter(IToolEventEmitter):
    """
    Event emitter that uses asyncio Queue for event collection.
    
    Follows Single Responsibility Principle: Only handles event queuing.
    """
    
    def __init__(self, event_queue: asyncio.Queue[ToolStreamEvent]):
        self._event_queue = event_queue
    
    async def emit_event(self, event: ToolStreamEvent) -> None:
        """Emit event to the queue."""
        try:
            await self._event_queue.put(event)
        except Exception as e:
            logger.error(f"Failed to queue tool event: {e}")
            raise


class ToolStreamManager(IToolStreamManager):
    """
    Manages tool streaming lifecycle and event collection.
    
    Follows Single Responsibility Principle: Only manages streaming infrastructure.
    """
    
    def __init__(self, max_queue_size: int = 1000):
        self._event_queue: asyncio.Queue[ToolStreamEvent] = asyncio.Queue(maxsize=max_queue_size)
        self._event_emitter = AsyncQueueEventEmitter(self._event_queue)
        self._active_contexts: list[ToolStreamContext] = []
        self._is_collecting = False
        self._collection_task: asyncio.Task | None = None
    
    async def create_stream_context(self) -> IToolStreamContext:
        """Create a new streaming context."""
        context = ToolStreamContext(self._event_emitter)
        self._active_contexts.append(context)
        
        # Start collection if not already running
        if not self._is_collecting:
            await self._start_collection()
        
        logger.debug(f"Created tool stream context. Active contexts: {len(self._active_contexts)}")
        return context
    
    async def collect_events(self) -> AsyncGenerator[ToolStreamEvent, None]:
        """Collect streaming events as they occur."""
        self._is_collecting = True
        
        try:
            while self._is_collecting or not self._event_queue.empty():
                try:
                    # Wait for events with timeout to allow periodic checks
                    event = await asyncio.wait_for(self._event_queue.get(), timeout=0.1)
                    yield event
                    
                    # Mark task as done for queue management
                    self._event_queue.task_done()
                    
                except asyncio.TimeoutError:
                    # Timeout is expected for periodic checks
                    continue
                except Exception as e:
                    logger.error(f"Error collecting tool stream events: {e}")
                    break
        finally:
            self._is_collecting = False
            logger.debug("Tool stream event collection stopped")
    
    async def cleanup(self) -> None:
        """Cleanup streaming resources with comprehensive error handling."""
        logger.debug("Cleaning up tool stream manager")
        cleanup_errors = []
        
        try:
            # Stop collection
            self._is_collecting = False
            
            # Cancel collection task if running
            if self._collection_task and not self._collection_task.done():
                self._collection_task.cancel()
                try:
                    await asyncio.wait_for(self._collection_task, timeout=5.0)
                except (asyncio.CancelledError, asyncio.TimeoutError):
                    logger.debug("Collection task cancelled or timed out during cleanup")
                except Exception as e:
                    cleanup_errors.append(f"Collection task cleanup failed: {e}")
                    logger.error(f"Collection task cleanup failed: {e}")
            
            # Deactivate all contexts
            for i, context in enumerate(self._active_contexts):
                try:
                    context.deactivate()
                except Exception as e:
                    cleanup_errors.append(f"Context {i} deactivation failed: {e}")
                    logger.error(f"Context {i} deactivation failed: {e}")
            
            self._active_contexts.clear()
            
            # Clear remaining events with timeout protection
            cleared_events = 0
            max_clear_attempts = 100  # Prevent infinite loops
            
            while not self._event_queue.empty() and cleared_events < max_clear_attempts:
                try:
                    self._event_queue.get_nowait()
                    self._event_queue.task_done()
                    cleared_events += 1
                except asyncio.QueueEmpty:
                    break
                except Exception as e:
                    cleanup_errors.append(f"Event queue cleanup failed: {e}")
                    logger.error(f"Event queue cleanup failed: {e}")
                    break
            
            if cleared_events >= max_clear_attempts:
                logger.warning(f"Event queue cleanup stopped after {max_clear_attempts} events")
            
            logger.debug(f"Tool stream manager cleanup completed. Cleared {cleared_events} events.")
            
            # If there were cleanup errors, raise them
            if cleanup_errors:
                error_summary = "; ".join(cleanup_errors)
                raise StreamCleanupError(f"Cleanup completed with errors: {error_summary}")
                
        except StreamCleanupError:
            # Re-raise our own exceptions
            raise
        except Exception as e:
            logger.error(f"Unexpected error during tool stream manager cleanup: {e}")
            raise StreamCleanupError(f"Unexpected cleanup error: {e}", original_error=e)
    
    async def _start_collection(self) -> None:
        """Start the collection process."""
        if self._collection_task and not self._collection_task.done():
            return
        
        self._collection_task = asyncio.create_task(self._collection_worker())
        logger.debug("Started tool stream collection worker")
    
    async def _collection_worker(self) -> None:
        """Background worker for event collection management."""
        try:
            async for _ in self.collect_events():
                # Events are yielded by collect_events, this just keeps it running
                pass
        except Exception as e:
            logger.error(f"Tool stream collection worker error: {e}")
        finally:
            logger.debug("Tool stream collection worker stopped")


class NullToolStreamContext(IToolStreamContext):
    """
    Null Object Pattern implementation for when streaming is disabled.
    
    Follows Single Responsibility Principle: Provides no-op streaming.
    """
    
    async def emit_start(self, tool_name: str, data: dict[str, Any] | None = None) -> None:
        """No-op implementation."""
        pass
    
    async def emit_progress(self, tool_name: str, data: dict[str, Any]) -> None:
        """No-op implementation."""
        pass
    
    async def emit_result(self, tool_name: str, data: dict[str, Any]) -> None:
        """No-op implementation."""
        pass
    
    async def emit_error(self, tool_name: str, error: Exception) -> None:
        """No-op implementation."""
        pass
    
    async def emit_complete(self, tool_name: str, data: dict[str, Any] | None = None) -> None:
        """No-op implementation."""
        pass