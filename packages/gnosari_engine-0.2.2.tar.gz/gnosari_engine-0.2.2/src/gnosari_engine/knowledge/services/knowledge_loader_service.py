"""
Knowledge Loader Service - Clean library interface for loading knowledge bases
"""

import logging
from pathlib import Path
from typing import Any, Callable, Optional, Protocol

from ...schemas.domain.knowledge import Knowledge
from ...schemas.domain.team import Team
from ..factories.knowledge_factory import KnowledgeProviderFactory
from ..interfaces import IKnowledgeProvider, IKnowledgeBase
from ..components import LoadingProgress, KnowledgeStatus


class ProgressCallback(Protocol):
    """Protocol for progress callback functions."""
    
    def __call__(self, progress: LoadingProgress) -> None:
        """Called with progress updates during loading."""
        ...


class KnowledgeLoaderService:
    """
    Clean library interface for loading knowledge bases.
    
    This service provides a simple, reusable way to load knowledge sources
    that can be used both from CLI and as a library dependency.
    
    Example usage:
        ```python
        from gnosari_engine.knowledge.services import KnowledgeLoaderService
        
        # Basic usage
        loader = KnowledgeLoaderService()
        result = await loader.load_from_team_config(
            team_config_path="teams/my_team.yaml",
            agent_id="ceo"  # Optional - loads all agents if omitted
        )
        
        # With progress callback
        def on_progress(progress: LoadingProgress):
            print(f"Progress: {progress.progress_percentage:.1f}%")
        
        result = await loader.load_from_team_config(
            team_config_path="teams/my_team.yaml",
            progress_callback=on_progress,
            force_reload=True
        )
        ```
    """
    
    def __init__(
        self, 
        knowledge_factory: Optional[KnowledgeProviderFactory] = None,
        provider: str = "opensearch"
    ):
        """
        Initialize the knowledge loader service.
        
        Args:
            knowledge_factory: Optional factory for creating knowledge providers
            provider: Default provider to use (opensearch, embedchain, etc.)
        """
        self._knowledge_factory = knowledge_factory or KnowledgeProviderFactory()
        self._default_provider = provider
        self._logger = logging.getLogger(__name__)
    
    async def load_from_team_config(
        self,
        team_config_path: str | Path,
        agent_id: Optional[str] = None,
        provider: Optional[str] = None,
        force_reload: bool = False,
        progress_callback: Optional[ProgressCallback] = None
    ) -> "KnowledgeLoadResult":
        """
        Load knowledge sources from a team configuration file.
        
        Args:
            team_config_path: Path to team configuration YAML file
            agent_id: Optional agent ID to load knowledge for (loads all if None)
            provider: Knowledge provider to use (defaults to configured provider)
            force_reload: Whether to force reload existing knowledge bases
            progress_callback: Optional callback for progress updates
        
        Returns:
            KnowledgeLoadResult with loading statistics and status
        
        Raises:
            FileNotFoundError: If team config file doesn't exist
            ValueError: If agent_id is specified but not found
            KnowledgeLoadError: If knowledge loading fails
        """
        team_config_path = Path(team_config_path)
        if not team_config_path.exists():
            raise FileNotFoundError(f"Team configuration not found: {team_config_path}")
        
        provider = provider or self._default_provider
        
        try:
            # Load team configuration
            from ...cli.services import ConfigurationLoader
            config_loader = ConfigurationLoader()
            team = config_loader.load_team_configuration(team_config_path)
            
            # Filter agents
            agents_to_process = self._filter_agents(team, agent_id)
            if not agents_to_process:
                if agent_id:
                    raise ValueError(f"Agent '{agent_id}' not found or has no knowledge sources")
                return KnowledgeLoadResult(
                    success=True,
                    total_agents=0,
                    total_knowledge_bases=0,
                    total_documents=0,
                    errors=[]
                )
            
            # Initialize provider
            knowledge_provider = await self._knowledge_factory.create_provider(provider)
            await knowledge_provider.initialize()
            
            # Load knowledge sources
            return await self._load_knowledge_sources(
                agents_to_process, 
                knowledge_provider, 
                force_reload, 
                progress_callback
            )
            
        except Exception as e:
            self._logger.error(f"Failed to load knowledge sources: {e}", exc_info=True)
            raise KnowledgeLoadError(f"Knowledge loading failed: {e}") from e
    
    async def load_from_knowledge_configs(
        self,
        knowledge_configs: list[Knowledge],
        provider: Optional[str] = None,
        force_reload: bool = False,
        progress_callback: Optional[ProgressCallback] = None
    ) -> "KnowledgeLoadResult":
        """
        Load knowledge bases from a list of Knowledge configurations.
        
        Args:
            knowledge_configs: List of Knowledge domain objects
            provider: Knowledge provider to use
            force_reload: Whether to force reload existing knowledge bases
            progress_callback: Optional callback for progress updates
        
        Returns:
            KnowledgeLoadResult with loading statistics
        """
        provider = provider or self._default_provider
        
        try:
            # Initialize provider
            knowledge_provider = await self._knowledge_factory.create_provider(provider)
            await knowledge_provider.initialize()
            
            # Load each knowledge base
            total_documents = 0
            errors = []
            
            for i, knowledge_config in enumerate(knowledge_configs):
                if progress_callback:
                    progress = LoadingProgress(
                        total_sources=len(knowledge_configs),
                        completed_sources=i,
                        current_source=knowledge_config.id,
                        documents_processed=total_documents,
                        errors=errors
                    )
                    progress_callback(progress)
                
                try:
                    doc_count = await self._load_single_knowledge_base(
                        knowledge_config, 
                        knowledge_provider, 
                        force_reload
                    )
                    total_documents += doc_count
                except Exception as e:
                    error_msg = f"Failed to load knowledge base '{knowledge_config.id}': {e}"
                    errors.append(error_msg)
                    self._logger.error(error_msg)
            
            # Final progress update
            if progress_callback:
                progress = LoadingProgress(
                    total_sources=len(knowledge_configs),
                    completed_sources=len(knowledge_configs),
                    current_source="",
                    documents_processed=total_documents,
                    errors=errors
                )
                progress_callback(progress)
            
            return KnowledgeLoadResult(
                success=len(errors) == 0,
                total_agents=1,  # Not applicable for direct config loading
                total_knowledge_bases=len(knowledge_configs),
                total_documents=total_documents,
                errors=errors
            )
            
        except Exception as e:
            self._logger.error(f"Failed to load knowledge configs: {e}", exc_info=True)
            raise KnowledgeLoadError(f"Knowledge loading failed: {e}") from e
    
    def _filter_agents(self, team: Team, agent_id: Optional[str]) -> list:
        """Filter agents based on agent_id and presence of knowledge sources."""
        if agent_id:
            target_agent = team.get_agent_by_id(agent_id)
            if not target_agent:
                return []
            
            if not hasattr(target_agent, 'knowledge') or not target_agent.knowledge:
                return []
            
            return [target_agent]
        else:
            return [
                agent for agent in team.agents 
                if hasattr(agent, 'knowledge') and agent.knowledge
            ]
    
    async def _load_knowledge_sources(
        self, 
        agents: list, 
        knowledge_provider: IKnowledgeProvider,
        force_reload: bool,
        progress_callback: Optional[ProgressCallback]
    ) -> "KnowledgeLoadResult":
        """Load knowledge sources for all agents."""
        total_documents = 0
        total_knowledge_bases = 0
        errors = []
        
        # Count total knowledge bases for progress tracking
        total_kb_count = sum(len(agent.knowledge) for agent in agents)
        processed_kb_count = 0
        
        for agent in agents:
            for knowledge_config in agent.knowledge:
                if progress_callback:
                    progress = LoadingProgress(
                        total_sources=total_kb_count,
                        completed_sources=processed_kb_count,
                        current_source=f"{agent.id}.{knowledge_config.id}",
                        documents_processed=total_documents,
                        errors=errors
                    )
                    progress_callback(progress)
                
                try:
                    doc_count = await self._load_single_knowledge_base(
                        knowledge_config, 
                        knowledge_provider, 
                        force_reload
                    )
                    total_documents += doc_count
                    total_knowledge_bases += 1
                except Exception as e:
                    error_msg = f"Failed to load knowledge base '{knowledge_config.id}' for agent '{agent.id}': {e}"
                    errors.append(error_msg)
                    self._logger.error(error_msg)
                
                processed_kb_count += 1
        
        # Final progress update
        if progress_callback:
            progress = LoadingProgress(
                total_sources=total_kb_count,
                completed_sources=processed_kb_count,
                current_source="",
                documents_processed=total_documents,
                errors=errors
            )
            progress_callback(progress)
        
        return KnowledgeLoadResult(
            success=len(errors) == 0,
            total_agents=len(agents),
            total_knowledge_bases=total_knowledge_bases,
            total_documents=total_documents,
            errors=errors
        )
    
    async def _load_single_knowledge_base(
        self, 
        knowledge_config: Knowledge, 
        knowledge_provider: IKnowledgeProvider,
        force_reload: bool
    ) -> int:
        """Load a single knowledge base and return document count."""
        knowledge_id = knowledge_config.id
        
        # Get or create knowledge base
        knowledge_base = await knowledge_provider.get_knowledge_base(knowledge_id)
        if not knowledge_base:
            knowledge_base = await knowledge_provider.create_knowledge_base(knowledge_config)
            await knowledge_base.initialize()
        
        # Check if reload is needed
        if not force_reload:
            status = await knowledge_base.get_status()
            if status.document_count > 0:
                self._logger.info(f"Knowledge base '{knowledge_id}' already loaded with {status.document_count} documents")
                return 0
        
        # Load data sources
        total_documents = 0
        for data_source in knowledge_config.data_sources:
            try:
                doc_count = await knowledge_base.add_data_source(
                    data_source,
                    force_reload=force_reload,
                    metadata={
                        "knowledge_id": knowledge_config.id,
                        "knowledge_name": knowledge_config.name,
                        "source_type": knowledge_config.source_type
                    }
                )
                total_documents += doc_count
                self._logger.info(f"Loaded {doc_count} documents from {data_source}")
            except Exception as e:
                self._logger.error(f"Failed to load data source {data_source}: {e}")
                raise
        
        return total_documents


class KnowledgeLoadResult:
    """Result of knowledge loading operation."""
    
    def __init__(
        self,
        success: bool,
        total_agents: int,
        total_knowledge_bases: int,
        total_documents: int,
        errors: list[str]
    ):
        self.success = success
        self.total_agents = total_agents
        self.total_knowledge_bases = total_knowledge_bases
        self.total_documents = total_documents
        self.errors = errors
    
    @property
    def has_errors(self) -> bool:
        """Check if there were any errors during loading."""
        return len(self.errors) > 0
    
    def __str__(self) -> str:
        status = "Success" if self.success else "Partial failure"
        return (
            f"KnowledgeLoadResult({status}: "
            f"{self.total_documents} docs in {self.total_knowledge_bases} knowledge bases "
            f"for {self.total_agents} agents, {len(self.errors)} errors)"
        )


class KnowledgeLoadError(Exception):
    """Raised when knowledge loading fails."""
    pass


__all__ = [
    "KnowledgeLoaderService",
    "KnowledgeLoadResult", 
    "KnowledgeLoadError",
    "ProgressCallback",
]