
import csv
import json
import os
from collections.abc import Iterator
from typing import Any

from pyzmap.exceptions import ZMapParserError


class ZMapParser:

    @staticmethod
    def parse_csv_results(
        file_path: str,
        fields: list[str] | None = None,
    ) -> list[dict[str, str]]:
        if not os.path.isfile(file_path):
            raise ZMapParserError(f"Results file not found: {file_path}")

        try:
            results = []
            with open(file_path, encoding="utf-8") as f:
                # Check if file has a header
                first_line = f.readline().strip()
                f.seek(0)  # Reset to beginning of file

                # If fields not provided and first line contains commas,
                # try to use it as header
                if fields is None and "," in first_line:
                    reader = csv.DictReader(f)
                    for row in reader:
                        results.append(dict(row))
                # If fields provided, use them as column names
                elif fields:
                    reader = csv.reader(f)
                    for row in reader:
                        if len(row) != len(fields):
                            raise ZMapParserError(
                                f"CSV row has {len(row)} fields, but "
                                f"{len(fields)} field names provided",
                            )
                        results.append(
                            {field: value for field, value in zip(fields, row)},
                        )
                # If only IPs (single column), treat each line as an IP
                else:
                    reader = csv.reader(f)
                    for row in reader:
                        if len(row) == 1:
                            results.append({"saddr": row[0]})
                        else:
                            raise ZMapParserError(
                                "CSV has multiple columns but no field names provided",
                            )

            return results

        except (csv.Error, OSError) as e:
            raise ZMapParserError(f"Failed to parse CSV results: {e!s}")

    @staticmethod
    def parse_json_results(file_path: str) -> list[dict[str, Any]]:
        if not os.path.isfile(file_path):
            raise ZMapParserError(f"Results file not found: {file_path}")

        try:
            with open(file_path, encoding="utf-8") as f:
                data = json.load(f)

            # Handle both array and object formats
            if isinstance(data, list):
                return data
            elif isinstance(data, dict):
                return [data]
            else:
                raise ZMapParserError(f"Unexpected JSON format: {type(data)}")

        except (json.JSONDecodeError, OSError) as e:
            raise ZMapParserError(f"Failed to parse JSON results: {e!s}")

    @staticmethod
    def parse_metadata(file_path: str) -> dict[str, Any]:
        if not os.path.isfile(file_path):
            raise ZMapParserError(f"Metadata file not found: {file_path}")

        try:
            with open(file_path, encoding="utf-8") as f:
                return json.load(f)

        except (json.JSONDecodeError, OSError) as e:
            raise ZMapParserError(f"Failed to parse metadata: {e!s}")

    @staticmethod
    def parse_status_updates(file_path: str) -> list[dict[str, Any]]:
        if not os.path.isfile(file_path):
            raise ZMapParserError(f"Status updates file not found: {file_path}")

        try:
            updates = []
            with open(file_path, encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # Convert numeric fields to appropriate types
                    for key, value in row.items():
                        if key in ["time", "sent", "recv", "hits", "cooldown_secs"]:
                            try:
                                row[key] = float(value) if "." in value else int(value)
                            except ValueError:
                                pass  # Keep as string if conversion fails
                    updates.append(row)

            return updates

        except (csv.Error, OSError) as e:
            raise ZMapParserError(f"Failed to parse status updates: {e!s}")

    @staticmethod
    def extract_ips(
        results: list[dict[str, Any]],
        ip_field: str = "saddr",
    ) -> list[str]:
        try:
            return [result[ip_field] for result in results]
        except KeyError:
            raise ZMapParserError(f"IP field '{ip_field}' not found in results")

    @staticmethod
    def stream_results(
        file_path: str,
        fields: list[str] | None = None,
    ) -> Iterator[dict[str, str]]:
        if not os.path.isfile(file_path):
            raise ZMapParserError(f"Results file not found: {file_path}")

        try:
            with open(file_path, encoding="utf-8") as f:
                # Check if file has a header
                first_line = f.readline().strip()
                f.seek(0)  # Reset to beginning of file

                # If fields not provided and first line contains commas,
                # try to use it as header
                if fields is None and "," in first_line:
                    reader = csv.DictReader(f)
                    for row in reader:
                        yield dict(row)
                # If fields provided, use them as column names
                elif fields:
                    reader = csv.reader(f)
                    for row in reader:
                        if len(row) != len(fields):
                            raise ZMapParserError(
                                f"CSV row has {len(row)} fields, but "
                                f"{len(fields)} field names provided",
                            )
                        yield {field: value for field, value in zip(fields, row)}
                # If only IPs (single column), treat each line as an IP
                else:
                    reader = csv.reader(f)
                    for row in reader:
                        if len(row) == 1:
                            yield {"saddr": row[0]}
                        else:
                            raise ZMapParserError(
                                "CSV has multiple columns but no field names provided",
                            )

        except (csv.Error, OSError) as e:
            raise ZMapParserError(f"Failed to parse CSV results: {e!s}")

    @staticmethod
    def count_results(file_path: str) -> int:
        if not os.path.isfile(file_path):
            raise ZMapParserError(f"Results file not found: {file_path}")

        try:
            with open(file_path, encoding="utf-8") as f:
                # Check if it's a CSV with header
                first_line = f.readline().strip()
                has_header = "," in first_line

                # Start count at 0 if header, 1 if already counted first row
                count = 0 if has_header else 1

                # Count remaining lines
                for _ in f:
                    count += 1

            return count

        except OSError as e:
            raise ZMapParserError(f"Failed to read results file: {e!s}")
