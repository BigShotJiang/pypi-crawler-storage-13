
import json
from dataclasses import asdict, dataclass
from typing import Any

from .exceptions import ZMapConfigError


@dataclass
class ZMapScanConfig:

    # Core Options
    target_port: int | None = None
    bandwidth: str | None = None
    rate: int | None = None
    cooldown_time: int | None = None
    interface: str | None = None
    source_ip: str | None = None
    source_port: int | str | None = None
    gateway_mac: str | None = None
    source_mac: str | None = None
    target_mac: str | None = None
    vpn: bool = False

    # Scan Control Options
    max_targets: int | str | None = None
    max_runtime: int | None = None
    max_results: int | None = None
    probes: int | None = None
    retries: int | None = None
    dryrun: bool = False
    seed: int | None = None
    shards: int | None = None
    shard: int | None = None

    # Advanced Options
    sender_threads: int | None = None
    cores: list[int] | str | None = None
    ignore_invalid_hosts: bool = False
    max_sendto_failures: int | None = None
    min_hitrate: float | None = None

    # Metadata Options
    notes: str | None = None
    user_metadata: dict[str, Any] | str | None = None

    def __post_init__(self):
        
        self._validate()

    def _validate(self) -> None:
        
        if self.target_port is not None and not (0 <= self.target_port <= 65535):
            raise ZMapConfigError(
                f"Invalid target port: {self.target_port}. "
                "Must be between 0 and 65535.",
            )

        if self.rate is not None and self.bandwidth is not None:
            raise ZMapConfigError("Cannot specify both rate and bandwidth.")

        if self.source_port is not None:
            if isinstance(self.source_port, str) and "-" in self.source_port:
                parts = self.source_port.split("-")
                if len(parts) != 2 or not all(p.isdigit() for p in parts):
                    raise ZMapConfigError(
                        f"Invalid source port range: {self.source_port}.",
                    )
                start, end = map(int, parts)
                if not (0 <= start <= end <= 65535):
                    raise ZMapConfigError(
                        f"Invalid source port range: {self.source_port}. "
                        "Must be between 0 and 65535.",
                    )
            elif isinstance(self.source_port, int) and not (
                0 <= self.source_port <= 65535
            ):
                raise ZMapConfigError(
                    f"Invalid source port: {self.source_port}. "
                    "Must be between 0 and 65535.",
                )

        if self.max_targets is not None and isinstance(self.max_targets, str):
            if not self.max_targets.endswith("%"):
                try:
                    int(self.max_targets)
                except ValueError:
                    raise ZMapConfigError(
                        f"Invalid max_targets: {self.max_targets}. "
                        "Must be an integer or percentage.",
                    )

        # Validate MAC addresses
        for mac_field in ["gateway_mac", "source_mac", "target_mac"]:
            mac = getattr(self, mac_field)
            if mac is not None and not self._is_valid_mac(mac):
                raise ZMapConfigError(
                    f"Invalid {mac_field}: {mac}. "
                    "Must be in format 'XX:XX:XX:XX:XX:XX'.",
                )

    @staticmethod
    def _is_valid_mac(mac: str) -> bool:
        
        import re

        return bool(re.match(r"^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$", mac))

    def to_dict(self) -> dict[str, Any]:
        
        result = {}
        for key, value in asdict(self).items():
            if value is not None:
                result[key] = value
        return result

    def to_json(self) -> str:
        
        return json.dumps(self.to_dict(), indent=2)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ZMapScanConfig":
        
        return cls(**data)

    @classmethod
    def from_json(cls, json_str: str) -> "ZMapScanConfig":
        
        return cls.from_dict(json.loads(json_str))

    def save_to_file(self, filename: str) -> None:
        
        with open(filename, "w", encoding="utf-8") as f:
            f.write(self.to_json())

    @classmethod
    def load_from_file(cls, filename: str) -> "ZMapScanConfig":
        
        with open(filename, encoding="utf-8") as f:
            return cls.from_json(f.read())
