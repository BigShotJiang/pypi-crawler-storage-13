

class ZMapError(Exception):
    

    pass


class ZMapCommandError(ZMapError):
    

    def __init__(self, command: str, returncode: int, stderr: str):
        self.command = command
        self.returncode = returncode
        self.stderr = stderr
        message = (
            f"ZMap command failed with return code {returncode}:\n"
            f"Command: {command}\nError: {stderr}"
        )
        super().__init__(message)


class ZMapConfigError(ZMapError):
    

    pass


class ZMapInputError(ZMapError):
    

    pass


class ZMapOutputError(ZMapError):
    

    pass


class ZMapParserError(ZMapError):
    

    pass
