
from collections.abc import Callable
from typing import Any

from pyzmap.config import ZMapScanConfig
from pyzmap.input import ZMapInput
from pyzmap.output import ZMapOutput
from pyzmap.parser import ZMapParser
from pyzmap.runner import ZMapRunner


# Option categories for ZMap configuration
class ZMapOptionCategories:
    

    INPUT_OPTIONS = frozenset(
        {
            "blocklist_file",
            "allowlist_file",
            "input_file",
            "ignore_blocklist",
            "ignore_invalid_hosts",
        },
    )

    OUTPUT_OPTIONS = frozenset(
        {
            "output_fields",
            "output_module",
            "output_filter",
            "output_args",
            "log_file",
            "log_directory",
            "metadata_file",
            "status_updates_file",
            "verbosity",
            "quiet",
            "disable_syslog",
        },
    )


class ZMap:

    def __init__(self, zmap_path: str = "zmap"):
        self.runner = ZMapRunner(zmap_path)
        self.config = ZMapScanConfig()
        self.input = ZMapInput()
        self.output = ZMapOutput()

    def scan(
        self,
        target_port: int | None = None,
        subnets: list[str] | None = None,
        output_file: str | None = None,
        callback: Callable[[str], None] | None = None,
        **kwargs: Any,
    ) -> list[str]:
        # Initialize scan configurations
        scan_config = ZMapScanConfig()
        scan_input = ZMapInput()
        scan_output = ZMapOutput()

        # Set core scan parameters
        if target_port is not None:
            scan_config.target_port = target_port

        if subnets:
            scan_input.add_subnets(subnets)

        if output_file:
            scan_output.set_output_file(output_file)

        # Distribute additional parameters to appropriate configuration objects
        self._process_scan_options(kwargs, scan_config, scan_input, scan_output)

        # Execute the scan
        return self.runner.scan(
            config=scan_config,
            input_config=scan_input,
            output_config=scan_output,
            callback=callback,
        )

    @staticmethod
    def _process_scan_options(
        options: dict[str, Any],
        scan_config: ZMapScanConfig,
        scan_input: ZMapInput,
        scan_output: ZMapOutput,
    ) -> None:
        for key, value in options.items():
            if key in ZMapOptionCategories.INPUT_OPTIONS:
                setattr(scan_input, key, value)
            elif key in ZMapOptionCategories.OUTPUT_OPTIONS:
                setattr(scan_output, key, value)
            else:
                setattr(scan_config, key, value)

    def run(self, **kwargs: Any) -> tuple[int, str, str]:
        return self.runner.run_command(**kwargs)

    def get_probe_modules(self) -> list[str]:
        return self.runner.get_probe_modules()

    def get_output_modules(self) -> list[str]:
        return self.runner.get_output_modules()

    def get_output_fields(self, probe_module: str | None = None) -> list[str]:
        return self.runner.get_output_fields(probe_module)

    def get_interfaces(self) -> list[str]:
        return self.runner.get_interfaces()

    def get_version(self) -> str:
        return self.runner.get_version()

    def blocklist_from_file(self, blocklist_file: str) -> None:
        self.input.set_blocklist_file(blocklist_file)

    def allowlist_from_file(self, allowlist_file: str) -> None:
        self.input.set_allowlist_file(allowlist_file)

    def create_blocklist_file(self, subnets: list[str], output_file: str) -> str:
        return self.input.create_blocklist_file(subnets, output_file)

    def create_allowlist_file(self, subnets: list[str], output_file: str) -> str:
        return self.input.create_allowlist_file(subnets, output_file)

    def create_target_file(self, targets: list[str], output_file: str) -> str:
        return self.input.create_target_file(targets, output_file)

    def generate_standard_blocklist(self, output_file: str) -> str:
        return self.input.generate_standard_blocklist(output_file)

    def parse_results(
        self,
        file_path: str,
        fields: list[str] | None = None,
    ) -> list[dict[str, str]]:
        return ZMapParser.parse_csv_results(file_path, fields)

    def parse_metadata(self, file_path: str) -> dict[str, Any]:
        return ZMapParser.parse_metadata(file_path)

    def extract_ips(
        self,
        results: list[dict[str, Any]],
        ip_field: str = "saddr",
    ) -> list[str]:
        return ZMapParser.extract_ips(results, ip_field)

    def stream_results(self, file_path: str, fields: list[str] | None = None):
        return ZMapParser.stream_results(file_path, fields)

    def count_results(self, file_path: str) -> int:
        return ZMapParser.count_results(file_path)
