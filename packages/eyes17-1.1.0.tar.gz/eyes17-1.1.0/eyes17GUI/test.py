from . eyes17 import eyes
from eyes17.SENSORS import TDC7200
dev = eyes17.eyes.open()
from eyes17.SENSORS import BMP180
b = BMP180.connect(dev.I2C)
print(b)
print(b.getRaw())
for a in range(10):
    print(b.readPressure())
#dev.set_sqr1(200000)
#tdc = TDC7200.TDC7200(dev)
#print( tdc.measure1() )
