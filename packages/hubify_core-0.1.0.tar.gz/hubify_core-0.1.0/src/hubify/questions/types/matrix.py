"""Implementations that render questions as matrices of options."""

from __future__ import annotations

from typing import Annotated, Any, ClassVar, cast

from pydantic import Field

from ..contracts import BaseOption, MatrixQuestionContract


class MatrixQuestion(MatrixQuestionContract):
    """Shared base defining rows and columns for matrix questions."""

    rows: list[BaseOption] = Field(..., description="List of row options.")
    columns: list[BaseOption] = Field(..., description="List of column options.")

    def validate_contract(self) -> None:
        """Ensure rows/columns exist and identifiers remain unique."""
        super().validate_contract()
        if not self.rows:
            raise ValueError("Matrix questions require at least one row")
        if not self.columns:
            raise ValueError("Matrix questions require at least one column")
        if len({row.id for row in self.rows}) != len(self.rows):
            raise ValueError("Row identifiers must be unique")
        if len({col.id for col in self.columns}) != len(self.columns):
            raise ValueError("Column identifiers must be unique")


class SingleChoiceMatrixQuestion(MatrixQuestion):
    """Matrix question ensuring only one selection per row."""

    question_type: ClassVar[str] = "single_choice_matrix"
    schema_version: ClassVar[str] = "1.0"

    default_values: Annotated[
        dict[str, str],
        Field(
            default_factory=dict, description="Default values as {row_id: column_id}"
        ),
    ]

    def validate_contract(self) -> None:
        """Ensure default values map only known rows to known columns."""
        super().validate_contract()
        valid_rows = {row.id for row in self.rows}
        valid_columns = {column.id for column in self.columns}
        defaults = cast(dict[str, str], self.default_values)
        for row_id, column_id in defaults.items():
            if row_id not in valid_rows:
                raise ValueError("Default values reference unknown row identifiers")
            if column_id not in valid_columns:
                raise ValueError("Default values reference unknown column identifiers")

    def normalize_answer(self, answer: Any) -> dict[str, str]:
        """Return a clean map of row selections verifying identifier validity."""
        defaults = cast(dict[str, str], self.default_values)
        result = defaults.copy() if answer is None else answer
        if not isinstance(result, dict):
            raise TypeError("Matrix answers must be provided as a mapping")
        valid_rows = {row.id for row in self.rows}
        valid_columns = {column.id for column in self.columns}
        normalized: dict[str, str] = {}
        for row_id, column_id in result.items():
            if row_id not in valid_rows or column_id not in valid_columns:
                raise ValueError("Matrix answer references invalid identifiers")
            normalized[row_id] = column_id
        return normalized


class MultipleChoiceMatrixQuestion(MatrixQuestion):
    """Matrix question allowing multiple column selections per row."""

    question_type: ClassVar[str] = "multiple_choice_matrix"
    schema_version: ClassVar[str] = "1.0"

    default_values: Annotated[
        dict[str, list[str]],
        Field(
            default_factory=dict,
            description="Default values as {row_id: [column_id1, column_id2, ...]}",
        ),
    ]

    def validate_contract(self) -> None:
        """Ensure default multi-selections reference known rows/columns."""
        super().validate_contract()
        valid_rows = {row.id for row in self.rows}
        valid_columns = {column.id for column in self.columns}
        defaults = cast(dict[str, list[str]], self.default_values)
        for row_id, column_ids in defaults.items():
            if row_id not in valid_rows:
                raise ValueError("Default values reference unknown row identifiers")
            if any(column_id not in valid_columns for column_id in column_ids):
                raise ValueError("Default values reference unknown column identifiers")

    def normalize_answer(self, answer: Any) -> dict[str, list[str]]:
        """Normalize multi-selection answers ensuring uniqueness and validity."""
        defaults = cast(dict[str, list[str]], self.default_values)
        result = defaults if answer is None else answer
        if not isinstance(result, dict):
            raise TypeError("Matrix answers must be provided as a mapping")
        valid_rows = {row.id for row in self.rows}
        valid_columns = {column.id for column in self.columns}
        normalized: dict[str, list[str]] = {}
        for row_id, column_ids in result.items():
            if row_id not in valid_rows:
                raise ValueError("Matrix answer references invalid row identifiers")
            if not isinstance(column_ids, list):
                raise TypeError("Matrix selections must be lists")
            clean_ids = []
            for column_id in column_ids:
                if column_id not in valid_columns:
                    raise ValueError(
                        "Matrix answer references invalid column identifiers"
                    )
                if column_id not in clean_ids:
                    clean_ids.append(column_id)
            normalized[row_id] = clean_ids
        return normalized
