"""Implementations for simple questions that expect primitive answers.

Includes text, numeric, float, boolean, and single-choice implementations
that enforce boundaries and normalization through explicit contracts.
"""

from __future__ import annotations

import re
from typing import Any, ClassVar

from pydantic import Field

from ..contracts import BaseOption, SimpleQuestionContract


class TextQuestion(SimpleQuestionContract):
    """Question accepting a single text response with optional validation.

    The question validates length and optional regex patterns, ensuring any
    default or user-provided value complies with the configured constraints.
    """

    question_type: ClassVar[str] = "text"
    schema_version: ClassVar[str] = "1.0"

    default_value: str = Field("", description="Default value for the question.")
    min_length: int = Field(0, description="Minimum character length, 0 for no limit.")
    max_length: int = Field(0, description="Maximum character length, 0 for no limit.")
    pattern: str = Field("", description="Optional regex pattern for validation.")

    def validate_contract(self) -> None:
        """Validate length constraints and default against the regex."""
        super().validate_contract()
        if self.min_length < 0:
            raise ValueError("min_length cannot be negative")
        if self.max_length < 0:
            raise ValueError("max_length cannot be negative")
        if self.max_length and self.min_length > self.max_length:
            raise ValueError("min_length cannot be greater than max_length")
        if self.pattern:
            try:
                re.compile(self.pattern)
            except re.error as exc:  # pragma: no cover - defensive
                raise ValueError("Invalid regex pattern") from exc
        self._ensure_value_within_constraints(self.default_value)

    def _ensure_value_within_constraints(self, value: str) -> None:
        """Check that a value adheres to the min/max length and pattern."""
        if self.min_length and len(value) < self.min_length:
            raise ValueError(f"Text must be at least {self.min_length} characters")
        if self.max_length and len(value) > self.max_length:
            raise ValueError(f"Text must be at most {self.max_length} characters")
        if self.pattern and not re.match(self.pattern, value):
            raise ValueError("Text doesn't match the required pattern")

    def normalize_answer(self, answer: Any) -> str:
        """Return a normalized string that satisfies the configured limits."""
        value = self.default_value if answer is None else str(answer)
        self._ensure_value_within_constraints(value)
        return value


class NumericQuestion(SimpleQuestionContract):
    """Question accepting an integer response within optional bounds."""

    question_type: ClassVar[str] = "numeric"
    schema_version: ClassVar[str] = "1.0"

    default_value: int | None = Field(
        None, description="Default value for the question."
    )
    min_value: int | None = Field(
        None, description="Minimum allowed value, None for no limit."
    )
    max_value: int | None = Field(
        None, description="Maximum allowed value, None for no limit."
    )

    def validate_contract(self) -> None:
        """Ensure min/max boundaries and default value consistency."""
        super().validate_contract()
        if (
            self.min_value is not None
            and self.max_value is not None
            and self.min_value > self.max_value
        ):
            raise ValueError("min_value cannot be greater than max_value")
        if self.default_value is not None:
            self._ensure_in_range(self.default_value)

    def _ensure_in_range(self, value: int) -> None:
        """Raise if the value is outside configured integer bounds."""
        if self.min_value is not None and value < self.min_value:
            raise ValueError("Value is below the minimum allowed")
        if self.max_value is not None and value > self.max_value:
            raise ValueError("Value is above the maximum allowed")

    def normalize_answer(self, answer: Any) -> int:
        """Coerce answers to integers while enforcing range constraints."""
        if answer is None:
            if self.default_value is None:
                raise ValueError("Answer required for numeric question")
            answer = self.default_value
        if isinstance(answer, bool) or not isinstance(answer, int):
            raise TypeError("Numeric question expects an integer answer")
        self._ensure_in_range(answer)
        return answer


class FloatQuestion(SimpleQuestionContract):
    """Question accepting floating point responses with precision control."""

    question_type: ClassVar[str] = "float"
    schema_version: ClassVar[str] = "1.0"

    default_value: float | None = Field(
        None, description="Default value for the question."
    )
    min_value: float | None = Field(
        None, description="Minimum allowed value, None for no limit."
    )
    max_value: float | None = Field(
        None, description="Maximum allowed value, None for no limit."
    )
    decimal_places: int = Field(2, description="Number of decimal places to round to.")

    def validate_contract(self) -> None:
        """Ensure bounds and decimal precision constraints remain valid."""
        super().validate_contract()
        if (
            self.min_value is not None
            and self.max_value is not None
            and self.min_value > self.max_value
        ):
            raise ValueError("min_value cannot be greater than max_value")
        if self.decimal_places < 0:
            raise ValueError("decimal_places cannot be negative")
        if self.default_value is not None:
            self._ensure_in_range(self.default_value)

    def _ensure_in_range(self, value: float) -> None:
        """Raise when a float value sits outside the allowed range."""
        if self.min_value is not None and value < self.min_value:
            raise ValueError("Value is below the minimum allowed")
        if self.max_value is not None and value > self.max_value:
            raise ValueError("Value is above the maximum allowed")

    def normalize_answer(self, answer: Any) -> float:
        """Return a rounded float within the configured bounds."""
        if answer is None:
            if self.default_value is None:
                raise ValueError("Answer required for float question")
            answer = self.default_value
        try:
            value = float(answer)
        except (TypeError, ValueError) as exc:
            raise TypeError("Float question expects a numeric answer") from exc
        self._ensure_in_range(value)
        if self.decimal_places:
            value = round(value, self.decimal_places)
        return value


class BooleanQuestion(SimpleQuestionContract):
    """Question interpreting boolean-like answers (yes/no, true/false)."""

    question_type: ClassVar[str] = "boolean"
    schema_version: ClassVar[str] = "1.0"

    default_value: bool = Field(False, description="Default value for the question.")
    true_label: str = Field("Yes", description="Label for the true option.")
    false_label: str = Field("No", description="Label for the false option.")

    def normalize_answer(self, answer: Any) -> bool:
        """Normalize enriched boolean representations to actual bool values."""
        if answer is None:
            return self.default_value
        if isinstance(answer, bool):
            return answer
        if isinstance(answer, str):
            lowered = answer.strip().lower()
            if lowered in {"true", "1", "yes", "y"}:
                return True
            if lowered in {"false", "0", "no", "n"}:
                return False
        raise TypeError("Boolean question expects a boolean-compatible answer")


class SingleChoiceQuestion(SimpleQuestionContract):
    """Question presenting predefined options with a single valid selection."""

    question_type: ClassVar[str] = "single_choice"
    schema_version: ClassVar[str] = "1.0"

    options: list[BaseOption] = Field(..., description="List of available options.")
    default_value: str | None = Field(
        None, description="Default selected option ID, if any."
    )

    def validate_contract(self) -> None:
        """Ensure options exist, are unique, and default matches an option."""
        super().validate_contract()
        if not self.options:
            raise ValueError("Single choice questions require at least one option")
        option_ids = {opt.id for opt in self.options}
        if len(option_ids) != len(self.options):
            raise ValueError("Option identifiers must be unique")
        if self.default_value and self.default_value not in option_ids:
            raise ValueError("Default value must match one of the option identifiers")

    def normalize_answer(self, answer: Any) -> str:
        """Return a valid option identifier after checking user input."""
        option_ids = {opt.id for opt in self.options}
        if answer is None:
            if self.default_value is None:
                raise ValueError("Answer required for single choice question")
            return self.default_value
        if not isinstance(answer, str):
            raise TypeError("Single choice answer must be an option identifier")
        if answer not in option_ids:
            raise ValueError("Answer must be one of the configured option identifiers")
        return answer
