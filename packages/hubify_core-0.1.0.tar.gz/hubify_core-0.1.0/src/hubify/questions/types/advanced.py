"""Advanced question type implementations with bespoke normalization."""

from __future__ import annotations

from typing import ClassVar

from pydantic import Field

from ..contracts import AdvancedQuestionContract, BaseOption


class VanWestendorpQuestion(AdvancedQuestionContract):
    """Price sensitivity meter capturing consumer price expectations."""

    question_type: ClassVar[str] = "van_westendorp"
    schema_version: ClassVar[str] = "1.0"

    min_price: float = Field(..., description="Minimum price to consider.")
    max_price: float = Field(..., description="Maximum price to consider.")
    step: float = Field(1.0, description="Step size for price options.")
    too_cheap_text: str = Field(
        "At what price would you consider the product to be so inexpensive that you would question the quality?",
        description="Text for the 'too cheap' question.",
    )
    cheap_text: str = Field(
        "At what price would you consider the product to be a bargain?",
        description="Text for the 'cheap' question.",
    )
    expensive_text: str = Field(
        "At what price would you consider the product to be expensive?",
        description="Text for the 'expensive' question.",
    )
    too_expensive_text: str = Field(
        "At what price would you consider the product to be too expensive to purchase?",
        description="Text for the 'too expensive' question.",
    )

    def validate_contract(self) -> None:
        """Ensure price bounds, step sizes, and range ordering are valid."""
        super().validate_contract()
        if self.min_price < 0 or self.max_price < 0:
            raise ValueError("Prices cannot be negative")
        if self.min_price >= self.max_price:
            raise ValueError("min_price must be lower than max_price")
        if self.step <= 0:
            raise ValueError("step must be positive")


class MaxDiffQuestion(AdvancedQuestionContract):
    """Preference analysis question comparing items via MaxDiff sets."""

    question_type: ClassVar[str] = "maxdiff"
    schema_version: ClassVar[str] = "1.0"

    items: list[BaseOption] = Field(..., description="List of items to choose from.")
    comparisons: int = Field(5, description="Number of comparison sets to generate.")
    items_per_set: int = Field(4, description="Number of items per comparison set.")

    def validate_contract(self) -> None:
        """Confirm item count uniqueness and comparison parameters."""
        super().validate_contract()
        if len(self.items) < 2:
            raise ValueError("MaxDiff requires at least two items")
        if len({item.id for item in self.items}) != len(self.items):
            raise ValueError("Item identifiers must be unique")
        if self.items_per_set < 2:
            raise ValueError("items_per_set must be at least two")
        if self.items_per_set > len(self.items):
            raise ValueError("items_per_set cannot exceed the number of items")
        if self.comparisons <= 0:
            raise ValueError("comparisons must be positive")


class HeatmapQuestion(AdvancedQuestionContract):
    """Heatmap-style question capturing spatial feedback on an image."""

    question_type: ClassVar[str] = "heatmap"
    schema_version: ClassVar[str] = "1.0"

    image_url: str = Field(..., description="URL to the base image.")
    width: int = Field(..., description="Width of the image in pixels.")
    height: int = Field(..., description="Height of the image in pixels.")
    color_scale: list[str] = Field(
        ["#00FF00", "#FFFF00", "#FF0000"],
        description="Color scale for the heatmap (low to high).",
    )

    def validate_contract(self) -> None:
        """Ensure image metadata and color scales meet requirements."""
        super().validate_contract()
        if not self.image_url:
            raise ValueError("image_url is required for heatmap questions")
        if self.width <= 0 or self.height <= 0:
            raise ValueError("width and height must be positive integers")
        if not self.color_scale:
            raise ValueError("color_scale must contain at least one color")
