"""Implementations for questions that accept multiple answers."""

from __future__ import annotations

from typing import Annotated, Any, ClassVar

from pydantic import Field

from ..contracts import BaseOption, MultipleQuestionContract


class MultipleChoiceQuestion(MultipleQuestionContract):
    """Question allowing multiple selections from a predefined set of options."""

    question_type: ClassVar[str] = "multiple_choice"
    schema_version: ClassVar[str] = "1.0"

    options: list[BaseOption] = Field(..., description="List of available options.")
    default_values: Annotated[
        list[str],
        Field(default_factory=list, description="Default selected option IDs, if any."),
    ]
    min_selections: int = Field(0, description="Minimum number of selections required.")
    max_selections: int = Field(
        0, description="Maximum number of selections allowed (0 for unlimited)."
    )

    def validate_contract(self) -> None:
        """Ensure option uniqueness and selection bounds remain sane."""
        super().validate_contract()
        if not self.options:
            raise ValueError("Multiple choice questions require at least one option")
        option_ids = {opt.id for opt in self.options}
        if len(option_ids) != len(self.options):
            raise ValueError("Option identifiers must be unique")
        if self.min_selections < 0:
            raise ValueError("min_selections cannot be negative")
        if self.max_selections < 0:
            raise ValueError("max_selections cannot be negative")
        if self.max_selections and self.min_selections > self.max_selections:
            raise ValueError("min_selections cannot exceed max_selections")
        invalid_defaults = [
            value for value in self.default_values if value not in option_ids
        ]
        if invalid_defaults:
            raise ValueError("Default values must match configured option identifiers")

    def normalize_answer(self, answer: Any) -> list[str]:
        """Validate and deduplicate user selections, enforcing count limits."""
        option_ids = {opt.id for opt in self.options}
        values = self.default_values if answer is None else answer
        if not isinstance(values, list):
            raise TypeError("Multiple choice answers must be provided as a list")
        selections = []
        for value in values:
            if not isinstance(value, str):
                raise TypeError("Each selection must be an option identifier")
            if value not in option_ids:
                raise ValueError("Selection must match a configured option identifier")
            if value not in selections:
                selections.append(value)
        if len(selections) < self.min_selections:
            raise ValueError("Not enough selections provided")
        if self.max_selections and len(selections) > self.max_selections:
            raise ValueError("Too many selections provided")
        return selections


class MultiTextQuestion(MultipleQuestionContract):
    """Question that captures multiple lines of free-form text responses."""

    question_type: ClassVar[str] = "multi_text"
    schema_version: ClassVar[str] = "1.0"

    default_values: Annotated[
        list[str], Field(default_factory=list, description="Default text responses.")
    ]
    min_responses: int = Field(1, description="Minimum number of responses required.")
    max_responses: int = Field(
        0, description="Maximum number of responses allowed (0 for unlimited)."
    )

    def validate_contract(self) -> None:
        """Ensure configured min/max response counts make sense."""
        super().validate_contract()
        if self.min_responses < 0:
            raise ValueError("min_responses cannot be negative")
        if self.max_responses < 0:
            raise ValueError("max_responses cannot be negative")
        if self.max_responses and self.min_responses > self.max_responses:
            raise ValueError("min_responses cannot exceed max_responses")

    def normalize_answer(self, answer: Any) -> list[str]:
        """Return sanitized text responses while honoring count limits."""
        values = self.default_values if answer is None else answer
        if not isinstance(values, list):
            raise TypeError("Multi text answers must be provided as a list")
        texts = [str(value) for value in values if str(value).strip()]
        if len(texts) < self.min_responses:
            raise ValueError("Not enough responses provided")
        if self.max_responses and len(texts) > self.max_responses:
            raise ValueError("Too many responses provided")
        return texts
