"""Question system with lazy loading and hierarchical imports.

This module provides a clean, hierarchical namespace for accessing question types,
contracts, and utilities. Imports are lazy-loaded and cached for performance.

Example usage:
    from hubify.questions import TextQuestion, QuestionFactory, BaseQuestionType
    from hubify.questions import BaseQuestionContract
    from hubify.questions.types import simple, matrix, advanced
"""

from __future__ import annotations

import sys
from typing import Any

# Import cache for lazy loading
_import_cache: dict[str, Any] = {}

# Public API exposed at package level
__all__ = [
    # Contracts
    "BaseQuestionContract",
    "SimpleQuestionContract",
    "MultipleQuestionContract",
    "MatrixQuestionContract",
    "AdvancedQuestionContract",
    # Models
    "BaseQuestionType",
    "BaseOption",
    # Enums
    "QuestionCategory",
    "QuestionTypeCode",
    "QUESTION_TYPES",
    # Simple question types
    "TextQuestion",
    "NumericQuestion",
    "FloatQuestion",
    "BooleanQuestion",
    "SingleChoiceQuestion",
    # Multiple question types
    "MultipleChoiceQuestion",
    "MultiTextQuestion",
    # Matrix question types
    "MatrixQuestion",
    "SingleChoiceMatrixQuestion",
    "MultipleChoiceMatrixQuestion",
    # Advanced question types
    "VanWestendorpQuestion",
    "MaxDiffQuestion",
    "HeatmapQuestion",
    # Factory and registry
    "QuestionFactory",
    "get_registered_question",
    "QUESTION_TYPE_REGISTRY",
]


def __getattr__(name: str) -> Any:
    """Lazy load modules and cache them for future access.

    This implements the lazy loading pattern used by LangChain, where imports
    are only performed when actually needed, reducing startup time and memory usage.

    Args:
        name: The attribute name being accessed

    Returns:
        The requested module, class, or function

    Raises:
        AttributeError: If the requested name is not in __all__
    """
    if name not in __all__:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    # Check cache first
    if name in _import_cache:
        return _import_cache[name]

    # Map names to their import locations
    if name in {
        "BaseQuestionContract",
        "SimpleQuestionContract",
        "MultipleQuestionContract",
        "MatrixQuestionContract",
        "AdvancedQuestionContract",
    }:
        from .contracts.base import (
            AdvancedQuestionContract,
            BaseQuestionContract,
            MatrixQuestionContract,
            MultipleQuestionContract,
            SimpleQuestionContract,
        )

        _import_cache["BaseQuestionContract"] = BaseQuestionContract
        _import_cache["SimpleQuestionContract"] = SimpleQuestionContract
        _import_cache["MultipleQuestionContract"] = MultipleQuestionContract
        _import_cache["MatrixQuestionContract"] = MatrixQuestionContract
        _import_cache["AdvancedQuestionContract"] = AdvancedQuestionContract
        return _import_cache[name]

    if name in {"BaseQuestionType", "BaseOption", "QuestionCategory", "QuestionTypeCode", "QUESTION_TYPES"}:
        from .contracts.models import (
            BaseOption,
            BaseQuestionType,
            QuestionCategory,
            QuestionTypeCode,
            QUESTION_TYPES,
        )

        _import_cache["BaseQuestionType"] = BaseQuestionType
        _import_cache["BaseOption"] = BaseOption
        _import_cache["QuestionCategory"] = QuestionCategory
        _import_cache["QuestionTypeCode"] = QuestionTypeCode
        _import_cache["QUESTION_TYPES"] = QUESTION_TYPES
        return _import_cache[name]

    if name in {
        "TextQuestion",
        "NumericQuestion",
        "FloatQuestion",
        "BooleanQuestion",
        "SingleChoiceQuestion",
    }:
        from .types.simple import (
            BooleanQuestion,
            FloatQuestion,
            NumericQuestion,
            SingleChoiceQuestion,
            TextQuestion,
        )

        _import_cache["TextQuestion"] = TextQuestion
        _import_cache["NumericQuestion"] = NumericQuestion
        _import_cache["FloatQuestion"] = FloatQuestion
        _import_cache["BooleanQuestion"] = BooleanQuestion
        _import_cache["SingleChoiceQuestion"] = SingleChoiceQuestion
        return _import_cache[name]

    if name in {"MultipleChoiceQuestion", "MultiTextQuestion"}:
        from .types.multiple import MultipleChoiceQuestion, MultiTextQuestion

        _import_cache["MultipleChoiceQuestion"] = MultipleChoiceQuestion
        _import_cache["MultiTextQuestion"] = MultiTextQuestion
        return _import_cache[name]

    if name in {
        "MatrixQuestion",
        "SingleChoiceMatrixQuestion",
        "MultipleChoiceMatrixQuestion",
    }:
        from .types.matrix import (
            MatrixQuestion,
            MultipleChoiceMatrixQuestion,
            SingleChoiceMatrixQuestion,
        )

        _import_cache["MatrixQuestion"] = MatrixQuestion
        _import_cache["SingleChoiceMatrixQuestion"] = SingleChoiceMatrixQuestion
        _import_cache["MultipleChoiceMatrixQuestion"] = MultipleChoiceMatrixQuestion
        return _import_cache[name]

    if name in {"VanWestendorpQuestion", "MaxDiffQuestion", "HeatmapQuestion"}:
        from .types.advanced import (
            HeatmapQuestion,
            MaxDiffQuestion,
            VanWestendorpQuestion,
        )

        _import_cache["VanWestendorpQuestion"] = VanWestendorpQuestion
        _import_cache["MaxDiffQuestion"] = MaxDiffQuestion
        _import_cache["HeatmapQuestion"] = HeatmapQuestion
        return _import_cache[name]

    if name in {
        "QuestionFactory",
        "get_registered_question",
        "QUESTION_TYPE_REGISTRY",
    }:
        from .registry import (
            QUESTION_TYPE_REGISTRY,
            QuestionFactory,
            get_registered_question,
        )

        _import_cache["QuestionFactory"] = QuestionFactory
        _import_cache["get_registered_question"] = get_registered_question
        _import_cache["QUESTION_TYPE_REGISTRY"] = QUESTION_TYPE_REGISTRY
        return _import_cache[name]

    # Should never reach here due to __all__ check above
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    """Return the list of public attributes for introspection."""
    return sorted(__all__)
