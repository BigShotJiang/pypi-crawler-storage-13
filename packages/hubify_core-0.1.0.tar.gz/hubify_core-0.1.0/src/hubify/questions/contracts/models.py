"""Shared models for question type system."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class QuestionCategory(str, Enum):
    """Enum grouping questions by expected answer structure and behavior.

    Categories help reducers and rendering layers reason about the shape of a
    question (e.g., simple vs matrix) without inspecting every implementation.
    """

    SIMPLE = "simple"
    MULTIPLE = "multiple"
    MATRIX = "matrix"
    ADVANCED = "advanced"


class QuestionTypeCode(str, Enum):
    """Enum enumerating every supported question implementation.

    These stable string codes power the registry, factory, serialization, and
    API payloads. Extending the system requires adding a new entry here and
    ensuring the matching question class sets ``question_type`` accordingly.
    """

    # Simple types
    TEXT = "text"
    NUMERIC = "numeric"
    FLOAT = "float"
    BOOLEAN = "boolean"
    SINGLE_CHOICE = "single_choice"

    # Multiple types
    MULTIPLE_CHOICE = "multiple_choice"
    MULTI_TEXT = "multi_text"

    # Matrix types
    SINGLE_CHOICE_MATRIX = "single_choice_matrix"
    MULTIPLE_CHOICE_MATRIX = "multiple_choice_matrix"

    # Advanced types
    VAN_WESTENDORP = "van_westendorp"
    MAXDIFF = "maxdiff"
    HEATMAP = "heatmap"


class BaseQuestionType(BaseModel):
    """Descriptor describing the capabilities of a question type.

    This metadata is stored centrally in ``QUESTION_TYPES`` and reused for
    serialization, documentation, or UI rendering. It keeps identifiers,
    human-readable text, and category aligned with the concrete question
    classes that surface in ``QUESTION_TYPE_REGISTRY``.
    """

    id: str = Field(..., description="Unique identifier of the question type.")
    code: QuestionTypeCode = Field(
        ..., description="Human readable short code from enum."
    )
    name: str = Field(..., description="Display name of the question type.")
    description: str = Field(
        ..., description="Detailed description of the question type."
    )
    type: QuestionCategory = Field(
        ..., description="Category bucket that defines behaviour expectations."
    )


class BaseOption(BaseModel):
    """Schema describing a selectable option inside choice-based questions.

    Options are small reusable models describing an ID, display label, and
    payload value. They are shared across single choice, multiple choice, and
    matrix questions.
    """

    id: str = Field(..., description="Unique identifier of the option.")
    value: Any = Field(..., description="Payload value stored when selected.")
    label: str = Field(..., description="Label exposed to respondents.")
    description: str = Field(
        "", description="Optional helper description for the option."
    )


# Predefined question type constants - reusable across all questions
QUESTION_TYPES: dict[QuestionTypeCode, BaseQuestionType] = {
    # Simple types
    QuestionTypeCode.TEXT: BaseQuestionType(
        id="qt_text",
        code=QuestionTypeCode.TEXT,
        name="Text Question",
        description="Single line text input",
        type=QuestionCategory.SIMPLE,
    ),
    QuestionTypeCode.NUMERIC: BaseQuestionType(
        id="qt_numeric",
        code=QuestionTypeCode.NUMERIC,
        name="Numeric Question",
        description="Integer number input",
        type=QuestionCategory.SIMPLE,
    ),
    QuestionTypeCode.FLOAT: BaseQuestionType(
        id="qt_float",
        code=QuestionTypeCode.FLOAT,
        name="Float Question",
        description="Decimal number input",
        type=QuestionCategory.SIMPLE,
    ),
    QuestionTypeCode.BOOLEAN: BaseQuestionType(
        id="qt_boolean",
        code=QuestionTypeCode.BOOLEAN,
        name="Boolean Question",
        description="Yes/No question",
        type=QuestionCategory.SIMPLE,
    ),
    QuestionTypeCode.SINGLE_CHOICE: BaseQuestionType(
        id="qt_single_choice",
        code=QuestionTypeCode.SINGLE_CHOICE,
        name="Single Choice Question",
        description="Choose one option from a list",
        type=QuestionCategory.SIMPLE,
    ),
    # Multiple types
    QuestionTypeCode.MULTIPLE_CHOICE: BaseQuestionType(
        id="qt_multiple_choice",
        code=QuestionTypeCode.MULTIPLE_CHOICE,
        name="Multiple Choice Question",
        description="Select multiple options from a list",
        type=QuestionCategory.MULTIPLE,
    ),
    QuestionTypeCode.MULTI_TEXT: BaseQuestionType(
        id="qt_multi_text",
        code=QuestionTypeCode.MULTI_TEXT,
        name="Multi Text Question",
        description="Multiple text inputs",
        type=QuestionCategory.MULTIPLE,
    ),
    # Matrix types
    QuestionTypeCode.SINGLE_CHOICE_MATRIX: BaseQuestionType(
        id="qt_single_choice_matrix",
        code=QuestionTypeCode.SINGLE_CHOICE_MATRIX,
        name="Single Choice Matrix",
        description="Matrix with single selection per row",
        type=QuestionCategory.MATRIX,
    ),
    QuestionTypeCode.MULTIPLE_CHOICE_MATRIX: BaseQuestionType(
        id="qt_multiple_choice_matrix",
        code=QuestionTypeCode.MULTIPLE_CHOICE_MATRIX,
        name="Multiple Choice Matrix",
        description="Matrix with multiple selections per row",
        type=QuestionCategory.MATRIX,
    ),
    # Advanced types
    QuestionTypeCode.VAN_WESTENDORP: BaseQuestionType(
        id="qt_van_westendorp",
        code=QuestionTypeCode.VAN_WESTENDORP,
        name="Van Westendorp Question",
        description="Price sensitivity meter",
        type=QuestionCategory.ADVANCED,
    ),
    QuestionTypeCode.MAXDIFF: BaseQuestionType(
        id="qt_maxdiff",
        code=QuestionTypeCode.MAXDIFF,
        name="MaxDiff Question",
        description="Maximum difference scaling",
        type=QuestionCategory.ADVANCED,
    ),
    QuestionTypeCode.HEATMAP: BaseQuestionType(
        id="qt_heatmap",
        code=QuestionTypeCode.HEATMAP,
        name="Heatmap Question",
        description="Visual interaction over images",
        type=QuestionCategory.ADVANCED,
    ),
}
