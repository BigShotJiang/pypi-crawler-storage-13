"""Abstract base contracts for question types."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, ClassVar

from pydantic import BaseModel, Field, model_validator

from .models import BaseQuestionType, QuestionTypeCode, QUESTION_TYPES


class BaseQuestionContract(BaseModel, ABC):
    """Shared contract for every question implementation.

    Developers should inherit from this class to define any new question type.
    It centralizes the shared schema (id, name, metadata, etc.), enforces
    per-subclass validation through ``validate_contract()``, and guarantees
    that serialization always includes the associated ``type`` metadata that
    describe the capabilities of the question.
    """

    id: str = Field(..., description="Question identifier inside the survey.")
    code: str = Field(
        "", description="Optional short code for referencing the question."
    )
    name: str = Field("", description="Friendly name for authoring environments.")
    description: str = Field(
        ..., description="Prompt or helper text displayed to respondents."
    )
    mandatory: bool = Field(True, description="Whether the question must be answered.")
    metadata: dict[str, Any] | None = Field(
        default=None,
        description="Free-form metadata useful for rendering, analytics, etc.",
    )

    question_type: ClassVar[str]
    schema_version: ClassVar[str] = "1.0"

    @property
    def type_info(self) -> BaseQuestionType:
        """Return the canonical ``BaseQuestionType`` metadata for this question.

        The metadata is resolved via the ``QUESTION_TYPES`` registry using the
        class-level ``question_type`` identifier. This ensures the runtime
        metadata that accompanies every serialized payload stays in sync with
        the concrete class that implements the question.
        """
        return QUESTION_TYPES[QuestionTypeCode(self.question_type)]

    def model_dump(self, **kwargs) -> dict[str, Any]:
        """Serialize the question while appending the type descriptor.

        Delegates most work to Pydantic's ``BaseModel.model_dump`` but then
        merges the ``BaseQuestionType`` metadata into the ``type`` key so API
        consumers always receive rich type information without requiring
        callers to pass it manually.
        """
        data = super().model_dump(**kwargs)
        data["type"] = self.type_info.model_dump()
        return data

    @model_validator(mode="after")
    def _run_contract_validation(self):
        """Invoke subclass-specific validation hooks after parsing completes.

        This validator runs once Pydantic has populated the model, ensuring the
        ``validate_contract`` implementation can rely on all fields already
        being resolved.
        """
        self.validate_contract()
        return self

    @abstractmethod
    def validate_contract(self) -> None:
        """Enforce domain-specific invariants for the particular question type.

        Implementations should raise ``ValueError`` or ``TypeError`` when the
        configuration is invalid (e.g., conflicting ranges or missing options).
        """

    @abstractmethod
    def normalize_answer(self, answer: Any) -> Any:
        """Coerce and validate raw answers into the question's expected shape.

        Implementations must raise when the provided answer cannot be
        interpreted in context (e.g., wrong type, invalid option IDs, too
        few/many choices). Otherwise, they should return the normalized value
        that downstream systems can persist.
        """

    def serialize(self) -> dict[str, Any]:
        """Public representation for API responses or persistence."""
        payload = self.model_dump()
        payload["question_type"] = self.question_type
        payload["schema_version"] = self.schema_version
        return payload


class SimpleQuestionContract(BaseQuestionContract, ABC):
    """Base contract for questions that expect a single primitive answer.

    Simple questions typically allow one response value (text, boolean,
    numeric, etc.) and reuse the ``normalize_answer`` hook to coerce and
    validate that single value.
    """

    def validate_contract(self) -> None:
        """Default validation hook for simple questions."""
        return

    def normalize_answer(self, answer: Any) -> Any:
        """Passthrough normalization for simple questions."""
        return answer


class MultipleQuestionContract(BaseQuestionContract, ABC):
    """Contract for questions that accept multiple primitive answers.

    This provides default normalization that verifies the answer is a list and
    returns an empty list when ``None`` is supplied to represent absence.
    """

    def validate_contract(self) -> None:
        """Default validation hook for multiple questions."""
        return

    def normalize_answer(self, answer: Any) -> Any:
        """Normalize multiple answers ensuring list structure."""
        if answer is None:
            return []
        if not isinstance(answer, list):
            raise TypeError("Expected a list for multiple question answers")
        return answer


class MatrixQuestionContract(BaseQuestionContract, ABC):
    """Contract for matrix-style questions with row/column definitions.

    Implementations of this contract typically coordinate with ``BaseOption``
    rows/columns describing the grid structure and expect normalized answers
    to be mappings keyed by row identifiers.
    """

    def validate_contract(self) -> None:
        """Default validation hook for matrix questions."""
        return

    def normalize_answer(self, answer: Any) -> Any:
        """Normalize matrix answers ensuring dict structure."""
        return answer or {}


class AdvancedQuestionContract(BaseQuestionContract, ABC):
    """Contract for bespoke/advanced question behaviours.

    Complex question types such as MaxDiff, Van Westendorp, or Heatmap live
    under this contract because they usually require additional metadata or
    custom normalization strategies beyond single/multiple answers.
    """

    def validate_contract(self) -> None:
        """Default validation hook for advanced questions."""
        return

    def normalize_answer(self, answer: Any) -> Any:
        """Passthrough normalization for advanced questions."""
        return answer
