"""Auto-discovery registry and factory helpers for question types.

This module inspects the ``hubify.questions.types`` package to register every
question class that declares a ``question_type`` identifier. The registry is
then used to instantiate questions dynamically from JSON payloads via the
``QuestionFactory`` utility.
"""

from __future__ import annotations

import inspect
from collections.abc import Mapping
from typing import Any

from . import types as types_module
from .contracts import BaseQuestionContract

QuestionClass = type[BaseQuestionContract]

# Auto-discover and register all question types from the types module
QUESTION_TYPE_REGISTRY: dict[str, QuestionClass] = {}

for name, obj in inspect.getmembers(types_module, inspect.isclass):
    if (
        issubclass(obj, BaseQuestionContract)
        and hasattr(obj, "question_type")
        and obj is not BaseQuestionContract
    ):
        discovered_code = getattr(obj, "question_type")
        QUESTION_TYPE_REGISTRY[discovered_code] = obj


def get_registered_question(code: str) -> QuestionClass:
    """Return the question class bound to the given registry code.

    Args:
        code: String identifier such as ``"text"`` or ``"numeric"``.

    Raises:
        ValueError: When the code is not part of the automatically filled
            ``QUESTION_TYPE_REGISTRY``.
    """
    try:
        return QUESTION_TYPE_REGISTRY[code]
    except KeyError as exc:  # pragma: no cover - defensive guard
        raise ValueError(f"Unknown question type '{code}'") from exc


class QuestionFactory:
    """Helper to materialize questions from untyped JSON/dict payloads.

    The factory centralizes payload validation, schema version checks, and the
    code-to-class mapping defined by ``QUESTION_TYPE_REGISTRY``.
    """

    @staticmethod
    def create(payload: dict[str, Any]) -> BaseQuestionContract:
        """Instantiate the right question class using the registry.

        The factory accepts either a ``question_type`` key (preferred) or an
        optional nested ``type.code`` entry. Enum values that subclass ``str``
        are accepted, so payloads emitted from Pydantic models continue to
        work alongside plain dictionaries.

        Args:
            payload: The raw payload containing fields used by the concrete
                question class plus routing metadata such as
                ``question_type`` and ``schema_version``.

        Raises:
            ValueError: When ``question_type`` (or the nested ``type.code``) is
                missing or when the payload declares a schema version that
                doesn't match the target question class.
        """
        question_code = payload.get("question_type")
        if not question_code:
            type_info = payload.get("type")
            if isinstance(type_info, Mapping):
                question_code = type_info.get("code")
            else:
                question_code = getattr(type_info, "code", None)
        
        if not question_code:
            raise ValueError("Payload must include 'question_type' or 'type.code'")

        # Handle both enum values and string codes
        # Enums that inherit from str can be compared directly with strings
        question_code_str = str(question_code) if hasattr(question_code, 'value') else question_code
        question_class = get_registered_question(question_code_str)

        schema_version = payload.get("schema_version")
        if schema_version and schema_version != question_class.schema_version:
            raise ValueError(
                f"Payload schema version '{schema_version}' does not match "
                f"'{question_class.schema_version}' for type '{question_code_str}'"
            )

        return question_class(**payload)
