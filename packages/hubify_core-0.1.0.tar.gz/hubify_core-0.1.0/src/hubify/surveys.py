"""Survey level models that compose multiple question types."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from .questions import BaseQuestionContract


class Survey(BaseModel):
    """Model representing a survey.

    Attributes:
        id (str): The ID of the survey.
        name (str): The name of the survey.
        description (str): A brief description of the survey.
        questions (list[BaseQuestionContract]): A list of questions in the survey.
    """

    id: str = Field(..., description="The ID of the survey.")
    name: str = Field(..., description="The name of the survey.")
    description: str = Field(..., description="A brief description of the survey.")
    questions: list[BaseQuestionContract] = Field(
        default_factory=list, description="List of fully instantiated question objects."
    )

    def serialize(self) -> dict[str, Any]:
        """Return an API-ready representation, serializing each question.

        The method builds on Pydantic's ``model_dump`` to include survey fields
        and then replaces the ``questions`` list with their own ``serialize``
        output so that every question preserves ``question_type``, ``schema_version``
        and ``type`` metadata.
        """
        payload = self.model_dump()
        payload["questions"] = [question.serialize() for question in self.questions]
        return payload
