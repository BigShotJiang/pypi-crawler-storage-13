# Hubify

Hubify is a Python package that provides composable survey question models with a
lazy-loaded, hierarchical namespace. The library focuses on:

- A consistent set of `BaseQuestionContract` abstractions powered by
	[Pydantic v2](https://docs.pydantic.dev/latest/).
- Category-specific implementations such as simple, multiple, matrix, and advanced
	questions that automatically register themselves.
- A `QuestionFactory` capable of instantiating question payloads dynamically based on
	their `question_type` metadata.

The runtime package lives under `src/hubify/` and is published on PyPI as the
`hubify-core` distribution while remaining importable via the `hubify` module.

## Getting Started

The project uses [uv](https://github.com/astral-sh/uv) for dependency
management. To install all dependencies:

```bash
uv sync
```

Run the test-suite with:

```bash
uv run pytest
```

To enter a REPL or execute scripts against the synced environment use
`uv run <command>`.

## Package Layout

```
src/hubify/
├── __init__.py        # Package exports and conveniences
├── surveys.py         # Survey composition model
└── questions/
		├── __init__.py    # Lazy-loading namespace + public API
		├── registry.py    # Auto-discovery registry and factory helpers
		├── contracts/     # Base contracts and shared models
		└── types/         # Question implementations grouped by category
```

Documentation describing the architecture and import patterns lives under
`docs/`. Tests validating lazy-loading behaviour and question contracts live in
`tests/`.
