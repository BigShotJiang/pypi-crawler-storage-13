from __future__ import annotations
from re import (Match, match as _match)

from nervels.nodes import ColorNode
from nervels.document import NLSDocument
from nervels.utils import is_color

class NLSParser:
    def __init__(self, content: str) -> None:
        self.lines: list[str] = content.splitlines()
        self.position: int = 0

    def parse(self) -> NLSDocument:
        properties: dict[str, str | ColorNode] = {}
        sections: dict[str, list[str]] = {}

        while self.position < len(self.lines):
            raw: str = self.lines[self.position].strip()
            self.position += 1

            if not raw or raw.startswith("#"):
                continue

            if raw == "{":
                self._parse_root_block(properties, sections)
                break

        return NLSDocument(properties=properties, sections=sections)

    def _parse_root_block(self, properties: dict[str, str | ColorNode], sections: dict[str, list[str]]) -> None:
        while self.position < len(self.lines):
            raw: str = self.lines[self.position].strip()
            self.position += 1

            if not raw or raw.startswith("#"):
                continue

            if raw == "}":
                break

            prop_match: Match[str] | None = _match(pattern=r'^([\w\-]+)\s+"(.+)"$', string=raw)

            if prop_match:
                (key, value) = prop_match[1], prop_match[2]
                properties[key] = ColorNode.parse(value) if is_color(value) else value

                continue

            section_match: Match[str] | None = _match(pattern=r"^([\w\-]+)\s*\{$", string=raw)

            if section_match:
                name: str = section_match[1]
                sections[name] = self._collect_section()

    def _collect_section(self) -> list[str]:
        content: list[str] = []
        base_indent: int | None = None

        while self.position < len(self.lines):
            current: str = self.lines[self.position]

            if current.strip() == "}":
                self.position += 1
                break

            stripped: str = current.strip()

            if stripped and not stripped.startswith("#"):
                if base_indent is None:
                    base_indent = len(current) - len(current.lstrip())

                line_indent:     int = len(current) - len(current.lstrip())
                relative_spaces: int = line_indent - (base_indent or 0)

                content.append((" " * relative_spaces) + stripped)

            self.position += 1

        return content
