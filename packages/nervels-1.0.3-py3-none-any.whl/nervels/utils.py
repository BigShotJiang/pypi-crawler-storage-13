from re import (Match, match as _match, search, findall)

from chromakitx import (ColorFormattable, AnsiColor, XtermColor, CssColor, CustomColor, HSL, RGB, HEX, HSV, NamedColor, InvalidColorError)

def is_color(value: str) -> bool:
    return bool(_match(pattern=r"^(AnsiColor|XTermColor|CssColor|NamedColor)\.\w+|CustomColor\(.+\)$", string=value.strip()))

def build_color(colors: list[str] | str) -> list[ColorFormattable] | ColorFormattable:
    return _build_color_object(colors.strip()) if isinstance(colors, str) else [_build_color_object(color.strip()) for color in colors]

def _build_color_object(text: str) -> ColorFormattable:
    match text:
        case s if any(s.startswith(prefix) for prefix in ("AnsiColor.", "XtermColor.", "CssColor.")):
            for (prefix, cls) in {
                "AnsiColor.":  AnsiColor,
                "XtermColor.": XtermColor,
                "CssColor.":   CssColor
            }.items():
                if s.startswith(prefix):
                    code: str = s[len(prefix):]
                    return getattr(cls, code, AnsiColor.White)

            return AnsiColor.White

        case s if s.startswith("CustomColor("):
            match: Match[str] | None = search(pattern=r"CustomColor\((.+)\)", string=s)

            if not match:
                return AnsiColor.White

            inner: str = match[1].strip()

            for (prefix, cls) in {
                "HSL(": HSL,
                "RGB(": RGB,
                "HSV(": HSV
            }.items():
                if inner.startswith(prefix):
                    values: list[float | int] = _extract_numbers(inner)
                    return CustomColor(cls(*values)) if len(values) == 3 else AnsiColor.White

            if inner.startswith("HEX("):
                hex_match: Match[str] | None = search(pattern=r"HEX\((['\"]?)(#[0-9A-Fa-f]{6})\1\)", string=inner)
                return CustomColor(HEX(hex_match[2])) if hex_match else AnsiColor.White

            return AnsiColor.White

        case s if s.startswith("NamedColor("):
            match: Match[str] | None = search(pattern=r"NamedColor\((['\"])([A-Za-z0-9_]+)\1\)", string=s)

            if not match:
                return AnsiColor.White

            name: str = match[2]

            try:
                return NamedColor(name)
            except InvalidColorError:
                return AnsiColor.White

        case _:
            return AnsiColor.White

def _extract_numbers(expr: str) -> list[float | int]:
    return [float(x) if "." in x else int(x) for x in findall(pattern=r"[-+]?\d*\.?\d+", string=expr)]
