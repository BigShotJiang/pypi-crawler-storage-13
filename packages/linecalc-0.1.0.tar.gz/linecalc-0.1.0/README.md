# linecalc
Line calculator
