"""
Package version number.

_version.py
"""

__version__ = "2.0"
