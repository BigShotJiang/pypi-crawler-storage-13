"""
TinyGenKey - A small secure key generator and validator library.
"""

from .main import (
    # Core classes
    BaseKey,
    Key,
    Keys,

    # Generation helpers
    secure_choice,
    gen_key,
    keys_gen,

    # Verification API
    base_handle_verify,
    ext_verify_handle_list,

    # Presets and preset aliases
    PRESETS,
    KEYS_PRESETS,

    # Character sets
    ALPHANUMERIC_LIST,
    HEX_LIST,
    BASE64_LIST,
    SAFE_LIST,
    LOWERCASE_LIST,
    UPPERCASE_LIST,
    NUMBERS_LIST,
    PRINTABLE_LIST,
    BINARY_LIST,
    OCTAL_LIST,
    DNA_LIST,
    VOWELS_LIST,
    CONSONANTS_LIST,
    EMOJI_LIST,
    SYMBOLS_LIST,
    MORSE_LIST,
    PASSWORD_LIST,

    # Color class and utilities
    c,
    colorize,
    cprint,
    cinput,

    # Color/Style types and maps
    COLOR_NAMES,
    STYLE_NAMES,
    COLOR_MAP,
    STYLE_MAP,
    BG_COLOR_MAP,
    ColorOptions,

    # Errors
    NoneError,
    KeyPresetError,
    ColorNotFoundError,
    StyleNotFoundError,

    # Typed reports
    KeyVerifyReport,

    # REPL
    repl,
)

__all__ = [
    # Classes
    "BaseKey",
    "Key",
    "Keys",

    # Generation
    "secure_choice",
    "gen_key",
    "keys_gen",

    # Verification
    "base_handle_verify",
    "ext_verify_handle_list",

    # Presets
    "PRESETS",
    "KEYS_PRESETS",

    # Charsets
    "ALPHANUMERIC_LIST",
    "HEX_LIST",
    "BASE64_LIST",
    "SAFE_LIST",
    "LOWERCASE_LIST",
    "UPPERCASE_LIST",
    "NUMBERS_LIST",
    "PRINTABLE_LIST",
    "BINARY_LIST",
    "OCTAL_LIST",
    "DNA_LIST",
    "VOWELS_LIST",
    "CONSONANTS_LIST",
    "EMOJI_LIST",
    "SYMBOLS_LIST",
    "MORSE_LIST",
    "PASSWORD_LIST",

    # Color class and utilities
    "c",
    "colorize",
    "cprint",
    "cinput",

    # Color/Style types and maps
    "COLOR_NAMES",
    "STYLE_NAMES",
    "COLOR_MAP",
    "STYLE_MAP",
    "BG_COLOR_MAP",
    "ColorOptions",

    # Errors
    "NoneError",
    "KeyPresetError",
    "ColorNotFoundError",
    "StyleNotFoundError",

    # Report
    "KeyVerifyReport",

    # REPL
    "repl",
]

__version__ = "0.5.1"
__author__ = "Razka Rizaldi"
__email__ = "razka.rizaldis@gmail.com"
__license__ = "MIT"

