# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateRuleResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'rule': 'RuleResponse'
    }

    attribute_map = {
        'rule': 'rule'
    }

    def __init__(self, rule=None):
        r"""CreateRuleResponse

        The model defined in huaweicloud sdk

        :param rule: 
        :type rule: :class:`huaweicloudsdkief.v1.RuleResponse`
        """
        
        super().__init__()

        self._rule = None
        self.discriminator = None

        if rule is not None:
            self.rule = rule

    @property
    def rule(self):
        r"""Gets the rule of this CreateRuleResponse.

        :return: The rule of this CreateRuleResponse.
        :rtype: :class:`huaweicloudsdkief.v1.RuleResponse`
        """
        return self._rule

    @rule.setter
    def rule(self, rule):
        r"""Sets the rule of this CreateRuleResponse.

        :param rule: The rule of this CreateRuleResponse.
        :type rule: :class:`huaweicloudsdkief.v1.RuleResponse`
        """
        self._rule = rule

    def to_dict(self):
        import warnings
        warnings.warn("CreateRuleResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateRuleResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
