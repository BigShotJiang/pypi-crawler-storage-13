OMMX Adapter for OpenJij
=========================

