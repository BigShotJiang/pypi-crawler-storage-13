#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 10 18:39:28 2025

@author: nikos
"""


import numpy as np
from matplotlib import pyplot as plt
from ..plotting.plot_utils import round_it, export_plot
from matplotlib.ticker import MultipleLocator

def generate_plot(X, Y1, Y2, Y1E, args):

    # Left panel coordinates
    ax1_coords = [0.05, 0.145, 0.52, 0.69]

    # Right panel coordinates
    ax2_coords = [0.625,0.145,0.36,0.69]
    
    # Create the figure
    fig = plt.figure(figsize=(15 , 3))

    fig.suptitle(args["title"])
    
    left_panel(fig = fig, ax1_coords = ax1_coords, 
               X = X, Y1 = Y1, Y1E = Y1E, Y2 = Y2, 
               args = args)
    
    right_panel(fig = fig, ax2_coords = ax2_coords, 
                X = X, Y1 = Y1, Y1E = Y1E, Y2 = Y2, 
                args = args)
    
    fpath = export_plot(fig, args)
        
    return(fpath)

def left_panel(fig, ax1_coords, X, Y1, Y1E, Y2, args):
    
    ax = fig.add_axes(ax1_coords)
        
    ax.plot(X, Y1, color = 'tab:blue', label = 'measured')
    ax.plot(X, Y2, color = 'tab:red', label = 'molecular')

    if np.isnan(Y1E).all() == False:
        ax.fill_between(X, Y1 - Y1E, Y1 + Y1E, color = 'tab:blue', alpha = 0.3)

    y1_label = get_y1_label()
    
    x_ticks_1, x_tick_labels_1 = get_x_ticks_1(x_lims = args['x_lims'], 
                                               x_tick = args['x_tick'])


    ax.set_xticks(x_ticks_1, labels = x_tick_labels_1)
    ax.set_xlim([args["x_lims"][0], args["x_lims"][1]])
    ax.set_xlabel(args['x_label'])
    
    x_tick = args['x_tick']
    ax.xaxis.set_minor_locator(MultipleLocator(x_tick / 2.))

    ax.set_ylim([args['y_lims'][0], args['y_lims'][1]])
    ax.set_ylabel(y1_label)
    
    use_lin_scale = args['use_lin_scale']
    
    if use_lin_scale == False:
        ax.set_yscale('log')

    ax.grid(which = 'both')
    
    if ax.get_legend_handles_labels() != ([], []):
        ax.legend(loc = 'lower left')

    ax.axvspan(args['normalization_region'][0], 
               args['normalization_region'][1], 
               alpha = 0.2, facecolor = 'tab:grey')
    
    box_colors = \
        mask_to_color(masks_norm_region = args["masks_norm_region"],
                      norm_region_flag = args['normalization_flag'])
        
    box_edge_x, box_edge_y = box_edges(x_ulim = args['x_lims'][1], 
                                       y_ulim = args['y_lims'][1], 
                                       use_lin_scale = use_lin_scale)
    
    box_text = get_box_text(norm_region = args['normalization_region'], 
                            stats_norm_region = args["stats_norm_region"])
    
    ax = add_text_ax1(ax, 
                      box_colors = box_colors, 
                      box_edge_x = box_edge_x, 
                      box_edge_y = box_edge_y, 
                      box_text = box_text)
    
    return(ax)

def right_panel(fig, ax2_coords, X, Y1, Y1E, Y2, args):
    
    x_ticks_2, x_tick_labels_2 = get_x_ticks_2(x_lims = args['x_lims'], 
                                               x_tick = args['x_tick'])
    
    ax2 = fig.add_axes(ax2_coords)
    
    if np.isnan(Y1E).all() == False:
        ax2.fill_between(X, (Y1 - Y1E - Y2) / Y2, 
                         (Y1 + Y1E - Y2) / Y2, color = 'tab:blue', 
                         alpha = 0.3, label = 'sem')
        
    ax2.plot(X, (Y1 - Y2) / Y2, color = 'tab:blue',label = 'mean')
    
    ax2.axhline(c = 'k')
    
    y2_label = get_y2_label()
    
    ax2.set_xticks(x_ticks_2, labels = x_tick_labels_2)
    ax2.set_xlim([args['x_lims'][0], args['x_lims'][1]])
    ax2.set_xlabel(args['x_label'])
    ax2.xaxis.set_minor_locator(MultipleLocator(args['x_tick']))
    
    y_ticks = np.round(np.arange(-0.40, 0.40 + 0.10, 0.10), decimals = 2)
    ax2.set_yticks(y_ticks, labels = ["%.2f" % tick for tick in y_ticks])
    ax2.set_ylim([y_ticks[0], y_ticks[-1]])
    ax2.set_ylabel(y2_label)
    
    ax2.grid(which = 'both')
    
    ax2.axvspan(args['normalization_region'][0], 
                args['normalization_region'][1], 
                alpha = 0.2, facecolor = 'tab:grey')
    
    return(ax2)

def get_x_label(use_dis):

    # Get the x axis label
    if use_dis:
        x_label = 'Range above the lidar [km]'
        
    else:
        x_label = 'Height above the lidar [km]'
    
    return(x_label)

def get_y1_label():
    
    # Get the y axis labels
    y_label = 'Attn. Bsc. rel. to fit range [$m^{-1} sr^{-1}$]'
    
    return(y_label)


def get_y2_label():
    
    # Get the y axis labels
    y_label = 'Relative Diff.'
    
    return(y_label)

def get_x_ticks_1(x_lims, x_tick):

    x_llim = x_lims[0]
    x_ulim = x_lims[1]
    
    # Check if the given x axis limits are compatible with the x axis tick
    if x_tick >= x_ulim - x_llim:
        raise Exception(f"The region between the provided x axis limits ({x_llim} to {x_ulim} km) is shorter than the x_tick parameter ({x_tick} km)")
    
    # Get the ticks for the first plot
    x_ticks_1 = np.arange(x_tick * np.ceil(x_llim / x_tick), 
                          x_tick * (np.floor(x_ulim / x_tick) + 1.), 
                          x_tick)
    
    if np.abs(x_llim - x_ticks_1[0]) < x_tick * 0.25:
        x_ticks_1[0] = x_llim
    else:
        x_ticks_1 = np.hstack((x_llim, x_ticks_1))

    if np.abs(x_ulim - x_ticks_1[-1]) < x_tick * 0.25:
        x_ticks_1[-1] = x_ulim
    else:
        x_ticks_1 = np.hstack((x_ticks_1, x_ulim))

    x_ticks_1 = np.round(x_ticks_1, decimals = 2)
    
    x_tick_labels_1 = [str(float(tick)).rstrip('0').rstrip('.') for tick in x_ticks_1]
    
    return(x_ticks_1, x_tick_labels_1)

def get_x_ticks_2(x_lims, x_tick):

    x_llim = x_lims[0]
    x_ulim = x_lims[1]
    
    x_tick_2 = 2. * x_tick 

    # Check if the given x axis limits are compatible with the x axis tick
    if x_tick_2 >= x_ulim - x_llim:
        raise Exception(f"The region between the provided x axis limits ({x_llim} to {x_ulim} km) is shorter than two times the x_tick parameter ({x_tick_2} km)")
    
    # Get the ticks for the second plot
    x_tick_2 = 2. * x_tick 
    x_ticks_2 = np.arange(x_tick_2 * np.floor(x_llim / x_tick_2), 
                          x_tick_2 * (np.ceil(x_ulim / x_tick_2) + 1.), 
                          x_tick_2)
    
    x_tick_labels_2 = [str(float(tick)).rstrip('0').rstrip('.') for tick in x_ticks_2]

    return(x_ticks_2, x_tick_labels_2)


def add_text_ax1(ax, box_colors, box_edge_x, box_edge_y, box_text):

    for key in ["normalization_region", "relative_sem", "first_derivative"]:
        ax.text(box_edge_x['column_1'], box_edge_y[key], 
                box_text[key],
                transform = ax.transAxes,
                bbox = dict(facecolor = box_colors[key], alpha = 0.22, zorder = 3))
        
    for key in ["second_derivative", "shapiro_wilk", "cross_criterion"]:
        ax.text(box_edge_x['column_2'], box_edge_y[key], 
                box_text[key],
                transform = ax.transAxes,
                bbox = dict(facecolor = box_colors[key], alpha = 0.22, zorder = 3))

    for key in ["is_positive", "durbin_watson"]:
        ax.text(box_edge_x['column_3'], box_edge_y[key], 
                box_text[key],
                transform = ax.transAxes,
                bbox = dict(facecolor = box_colors[key], alpha = 0.22, zorder = 3))
                
    return(ax)


def mask_to_color(masks_norm_region, norm_region_flag):
    
    if norm_region_flag == 'auto': 
        c_norm = 'tab:green'
    elif norm_region_flag == 'external': 
        c_norm = 'tab:orange'
    else: 
        c_norm = 'tab:red'
        
    if masks_norm_region['relative_sem']: 
        c_msem = 'tab:green'
    else: 
        c_msem = 'tab:orange'
        
    if masks_norm_region['first_derivative']: 
        c_mder = 'tab:green'
    else: 
        c_mder = 'tab:red'
    
    if masks_norm_region['second_derivative']: 
        c_msec = 'tab:green'
    else: 
        c_msec = 'tab:red'
        
    if masks_norm_region['shapiro_wilk']: 
        c_mshp = 'tab:green'
    else: 
        c_mshp = 'tab:red'
    
    if masks_norm_region['cross_criterion']: 
        c_mcrc = 'tab:green'
    else: 
        c_mcrc = 'tab:red'

    if masks_norm_region['is_positive']: 
        c_mpos = 'tab:green'
    else: 
        c_mpos = 'tab:red'

    if masks_norm_region['durbin_watson']: 
        c_mdbw = 'tab:green'
    else: 
        c_mdbw = 'tab:red'
        
    box_colors = {'normalization_region': 'tab:blue',
                  'relative_sem':c_msem,
                  'first_derivative':c_mder,
                  'second_derivative':c_msec,
                  'shapiro_wilk':c_mshp,
                  'cross_criterion':c_mcrc,
                  'is_positive':c_mpos,
                  'durbin_watson':c_mdbw,
                  'normalization_factor':c_norm}
        
    return(box_colors)

def get_box_text(norm_region, stats_norm_region):
        
    n_llim = np.round(norm_region[0], decimals = 2)
    n_ulim = np.round(norm_region[1], decimals = 2)
    
    rsem = stats_norm_region['relative_sem']
    rslope = stats_norm_region['first_derivative']
    
    box_text = {'normalization_region':f'window: {n_llim} - {n_ulim} km',
                'relative_sem':f'rsem: {round_it(rsem, 3)}',
                'first_derivative':f'rslope: {round_it(rslope, 3)}',
                'second_derivative':'Curvature',
                'shapiro_wilk':'Shapiro-Wilk',
                'cross_criterion':'Cross crit',
                'is_positive':'Positive sig',
                'durbin_watson':'Durbin Watson'}
    
    return(box_text)

def box_edges(x_ulim, y_ulim, use_lin_scale):
    
    box_edge_x = {'column_1':0.45,
                  'column_2':0.70,
                  'column_3':0.85}
    
    box_edge_y = {'normalization_region':0.90,
                  'relative_sem':0.77,
                  'first_derivative':0.64,
                  'second_derivative':0.90,
                  'shapiro_wilk':0.77,
                  'cross_criterion':0.64,
                  'is_positive':0.90,
                  'durbin_watson':0.77}       
        
    return(box_edge_x, box_edge_y)