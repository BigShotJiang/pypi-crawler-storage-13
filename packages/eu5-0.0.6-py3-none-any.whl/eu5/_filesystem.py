# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import os
import platform
from pathlib import Path

from platformdirs import user_documents_dir


def _get_windows_steam_path() -> Path:
    candidates = [Path(r"C:\\Program Files")]
    for env in ("ProgramW6432", "PROGRAMFILES(X86)", "PROGRAMFILES"):
        val = os.environ.get(env)
        if val:
            candidates.append(Path(val))
    for base in candidates:
        steam_path_candidate = base / "Steam"
        if steam_path_candidate.exists():
            return steam_path_candidate
    raise ValueError(f"Could not find your Steam path. Searched: {candidates}")


if platform.system() == "Windows":
    _STEAM_PATH = _get_windows_steam_path()
    _DOCUMENTS_PATH = Path(user_documents_dir())
else:
    _STEAM_PATH = Path.home() / ".local/share/Steam"
    _DOCUMENTS_PATH = (
        Path("~").expanduser()
        / ".local/share/Steam/steamapps/compatdata/3450310/pfx/drive_c/users/steamuser/Documents"
    )

GAME_PATH = _STEAM_PATH / "steamapps" / "common" / "Europa Universalis V"
USER_PATH = _DOCUMENTS_PATH / "Paradox Interactive" / "Europa Universalis V"
