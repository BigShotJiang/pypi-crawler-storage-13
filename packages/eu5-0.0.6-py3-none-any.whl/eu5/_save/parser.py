# SPDX-FileCopyrightText: 2025 Adrian Chaves <adrian@chaves.gal>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import contextlib
import hashlib
import json
import logging
import pickle
import platform
import shutil
import subprocess
import tarfile
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

from eu5._cache import get_cache_dir

logger = logging.getLogger(__name__)

SAVE_CACHE_DIR = get_cache_dir("saves")
RAKALY_CACHE_DIR = get_cache_dir("rakaly")


def _ensure_rakaly() -> str:
    system = platform.system().lower()
    rakaly_name = "rakaly.exe" if system == "windows" else "rakaly"

    # Prefer a system-installed `rakaly` if available (check both names)
    which = shutil.which("rakaly") or shutil.which("rakaly.exe")
    if which:
        return which

    # Ensure cache dir exists
    RAKALY_CACHE_DIR.mkdir(parents=True, exist_ok=True)

    # Check cached rakaly
    cached = RAKALY_CACHE_DIR / rakaly_name
    if cached.exists():
        return str(cached)

    # Check for local rakaly with or without .exe extension in cwd
    candidates = [Path("./") / n for n in (rakaly_name, "rakaly", "rakaly.exe")]
    for candidate in candidates:
        if candidate.exists():
            # copy into cache for future runs
            copied = False
            try:
                shutil.copy2(candidate, cached)
                if system != "windows":
                    with contextlib.suppress(Exception):
                        cached.chmod(0o755)
                copied = True
            except Exception as exc:
                logger.exception(
                    "Failed to copy local rakaly candidate %s: %s", candidate, exc
                )
            # prefer cached copy when available, otherwise return the local path
            return str(cached) if copied else str(candidate)

    return _download_rakaly(rakaly_name)


def _download_rakaly(rakaly_name: str) -> str:
    system = platform.system().lower()

    if system == "linux":
        url = "https://github.com/rakaly/cli/releases/download/v0.8.1/rakaly-0.8.1-x86_64-unknown-linux-musl.tar.gz"
    elif system == "windows":
        url = "https://github.com/rakaly/cli/releases/download/v0.8.1/rakaly-0.8.1-x86_64-pc-windows-msvc.zip"
    else:
        raise RuntimeError(f"Unsupported platform: {system}")

    print("Downloading Rakaly CLI...")
    # Use a temporary file name inside the rakaly cache dir
    temp_download = RAKALY_CACHE_DIR / "rakaly_download"
    urllib.request.urlretrieve(url, str(temp_download))  # noqa: S310

    # Extract into the cache dir
    if str(url).endswith(".zip"):
        with zipfile.ZipFile(temp_download, "r") as f:
            f.extractall(str(RAKALY_CACHE_DIR))  # noqa: S202
    else:
        with tarfile.open(temp_download, "r:gz") as f:
            f.extractall(str(RAKALY_CACHE_DIR))  # noqa: S202

    with contextlib.suppress(Exception):
        temp_download.unlink()

    rakaly_dest = RAKALY_CACHE_DIR / rakaly_name

    # Find the extracted binary and move it to the cache root as rakaly_name
    for p in RAKALY_CACHE_DIR.rglob("*"):
        if p.is_file() and p.name.lower().startswith("rakaly"):
            try:
                # Move to final destination if possible, otherwise copy
                p.replace(rakaly_dest)
            except Exception:
                try:
                    shutil.copy2(p, rakaly_dest)
                    with contextlib.suppress(Exception):
                        p.unlink()
                except Exception as exc:
                    logger.exception(
                        "Failed to move or copy extracted rakaly %s: %s", p, exc
                    )
                    continue
            # Make executable on POSIX
            with contextlib.suppress(Exception):
                if system != "windows":
                    rakaly_dest.chmod(0o755)
            break

    # Clean up any extracted subdirs starting with 'rakaly-'
    for p in RAKALY_CACHE_DIR.iterdir():
        if p.is_dir() and p.name.startswith("rakaly-"):
            with contextlib.suppress(Exception):
                shutil.rmtree(p)

    return str(rakaly_dest)


def _build_root_map(data: dict[str, Any]) -> dict[str, Any]:
    remainder = data["remainder"]
    iterator = iter(remainder)
    root: dict[str, Any] = {}
    for key in iterator:
        root[key] = next(iterator)
    return root


def load_save_data(save_path: str | Path) -> dict[str, Any]:
    save_path = Path(save_path)
    file_hash = hashlib.md5(save_path.read_bytes()).hexdigest()  # noqa: S324

    # Remove other pickle files for this save stem (keep only the current hash)
    for cache in SAVE_CACHE_DIR.glob(f"{save_path.stem}_*.pkl"):
        name = cache.stem
        _, cache_file_hash = name.rsplit("_", 1)
        if cache_file_hash != file_hash:
            cache.unlink()

    cache_file = SAVE_CACHE_DIR / f"{save_path.stem}_{file_hash}.pkl"
    if cache_file.exists():
        try:
            with cache_file.open("rb") as f:
                return pickle.load(f)  # noqa: S301
        except Exception:
            cache_file.unlink(missing_ok=True)

    rakaly = _ensure_rakaly()
    # Run rakaly and capture raw bytes to avoid locale-based decoding issues
    result = subprocess.run(  # noqa: S603
        [rakaly, "json", str(save_path)], capture_output=True, check=True
    )

    # Prefer bytes output; json.loads accepts bytes and will decode as UTF-8.
    if result.stdout is None:
        # Provide stderr to help debugging if rakaly produced no stdout
        raise RuntimeError(f"rakaly produced no stdout; stderr: {result.stderr}")

    # Handle bytes, bytearray and memoryview safely; json.loads accepts bytes.
    if isinstance(result.stdout, (bytes, bytearray, memoryview)):
        raw_bytes = bytes(result.stdout)
        raw_data = json.loads(raw_bytes)
    else:
        raw_data = json.loads(result.stdout)
    data = _build_root_map(raw_data)

    with cache_file.open("wb") as f:
        pickle.dump(data, f)

    return data
