#
# BSD 3-Clause License

"""AI Skills."""

__version__ = "0.0.1"
