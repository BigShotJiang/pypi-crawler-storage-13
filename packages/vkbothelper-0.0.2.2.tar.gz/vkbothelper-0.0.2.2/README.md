## Библиотека для помощи в создании ботов на чистом vk_api
![](https://img.shields.io/badge/Python_3.13-darkred)
![](https://img.shields.io/badge/VkApi-blue) <br>
**help** - список всех команд <br>
**get_RGCM** - вывод словарь что возвращает getConversationMembers<br>
**get_vk_api_docs** - вывод подсказка по использованию общих команд vk_api<br>
**get_all_docs** - вывод всей документации<br>
**get_events_docs** - вывод подсказки по использованию events<br>
**get_keyboard_docs** - вывод подсказки по использованию keyboard<br>
**get_name(user_id)** - возврат имени пользователя по его user_id<br>
**get_lname(user_id)** - возврат фамилии пользователя по его user_id<br>
**get_full_name(user_id, separately)** - возврат фамилии и имени пользователя по его user_id, 
настройка separately может принимать два аргумента:<br>
&nbsp;&nbsp;&nbsp;&nbsp;True - вернуть ФИ 2 строчками <br>
&nbsp;&nbsp;&nbsp;&nbsp;False - вернуть ФИ одной строчкой<br>
**send_message(sender, message, keyboard, chat_id)** - отправляет сообщение пользователю<br>
&nbsp;&nbsp;&nbsp;&nbsp;sender - id отправителя сообщения<br>
&nbsp;&nbsp;&nbsp;&nbsp;message - текст что необходимо отправить<br>
&nbsp;&nbsp;&nbsp;&nbsp;keyboard - какую клавиатуру необходимо отрисовать (False = отправить сообщение без клавиатуры)<br>
&nbsp;&nbsp;&nbsp;&nbsp;chat_id - id групового чата (нельзя использовать вместе с sender)<br>
**send_sticker(sender, sticker_id, keyboard, chat_id)** - отправляет стикер пользователю<br>
&nbsp;&nbsp;&nbsp;&nbsp;sender - id отправителя сообщения<br>
&nbsp;&nbsp;&nbsp;&nbsp;sticker_id - номер стикера что необходимо отправить (важно стикер должен быть у создателя в наличии)<br>
&nbsp;&nbsp;&nbsp;&nbsp;keyboard - какую клавиатуру необходимо отрисовать (False = отправить сообщение без клавиатуры)<br>
&nbsp;&nbsp;&nbsp;&nbsp;chat_id - id групового чата (нельзя использовать вместе с sender)<br>
**send_photo(sender, message, image_path, keyboard, chat_id)** - отправляет фото пользователю<br>
&nbsp;&nbsp;&nbsp;&nbsp;sender - id отправителя сообщения<br>
&nbsp;&nbsp;&nbsp;&nbsp;message - текст что необходимо отправить<br>
&nbsp;&nbsp;&nbsp;&nbsp;image_path - путь к фото что необходимо отправить<br>
&nbsp;&nbsp;&nbsp;&nbsp;keyboard - какую клавиатуру необходимо отрисовать (False = отправить сообщение без клавиатуры)<br>
&nbsp;&nbsp;&nbsp;&nbsp;chat_id - id групового чата (нельзя использовать вместе с sender)<br>
**get_skeleton** - выводит скелет бота для быстрого старта<br>