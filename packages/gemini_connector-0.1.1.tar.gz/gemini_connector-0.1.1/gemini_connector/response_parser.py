"""
Utilities for parsing Gemini API responses.
"""


def extract_text(response: dict[str, any]) -> str | None:
    """
    Extract generated text from Gemini API response.

    Args:
        response: Full API response dictionary

    Returns:
        str: Extracted text or None if not found
    """
    if "candidates" not in response or len(response["candidates"]) == 0:
        return None

    candidate = response["candidates"][0]

    if "content" not in candidate or "parts" not in candidate["content"]:
        return None

    parts = candidate["content"]["parts"]
    if len(parts) == 0:
        return None

    return parts[0].get("text")


def extract_all_text_parts(response: dict[str, any]) -> list[str]:
    """
    Extract all text parts from all candidates in the response.

    Args:
        response: Full API response dictionary

    Returns:
        list: All text parts found in the response
    """
    texts = []

    if "candidates" not in response:
        return texts

    for candidate in response["candidates"]:
        if "content" not in candidate or "parts" not in candidate["content"]:
            continue

        for part in candidate["content"]["parts"]:
            text = part.get("text")
            if text:
                texts.append(text)

    return texts


def get_finish_reason(response: dict[str, any]) -> str | None:
    """
    Get the finish reason from the first candidate.

    Args:
        response: Full API response dictionary

    Returns:
        str: Finish reason (e.g., "STOP", "MAX_TOKENS") or None
    """
    if "candidates" not in response or len(response["candidates"]) == 0:
        return None

    return response["candidates"][0].get("finishReason")


def get_safety_ratings(response: dict[str, any]) -> list[dict[str, any]] | None:
    """
    Get safety ratings from the first candidate.

    Args:
        response: Full API response dictionary

    Returns:
        list: Safety ratings or None if not found
    """
    if "candidates" not in response or len(response["candidates"]) == 0:
        return None

    return response["candidates"][0].get("safetyRatings")
