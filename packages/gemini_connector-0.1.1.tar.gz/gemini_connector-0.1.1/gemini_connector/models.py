"""
Gemini API Model Definitions
"""

from enum import Enum


class GeminiModel(str, Enum):
    """
    Available Gemini API models with usage guidance.

    Each model is optimized for different use cases and price points.
    """

    # Current Generation - Gemini 3.x
    GEMINI_3_PRO = "gemini-3-pro-preview"  # Best multimodal understanding, advanced reasoning. Most expensive but highest quality.

    # Current Generation - Gemini 2.5
    GEMINI_2_5_PRO = "gemini-2.5-pro"  # Complex reasoning, coding, STEM, large datasets. Premium pricing for advanced tasks.
    GEMINI_2_5_FLASH = "gemini-2.5-flash"  # Best price-performance balance. Great for high-volume, low-latency apps. Cost-efficient.
    GEMINI_2_5_FLASH_LITE = "gemini-2.5-flash-lite"  # Fastest and cheapest. High-throughput, budget-conscious applications.

    # Specialized - Image Generation
    GEMINI_2_5_FLASH_IMAGE = "gemini-2.5-flash-image"  # Image generation and understanding. Specialized pricing.

    # Previous Generation - Gemini 2.0
    GEMINI_2_0_FLASH_EXP = "gemini-2.0-flash-exp"  # Experimental, 1M context window. May have rate limits, not for production.
    GEMINI_2_0_FLASH = "gemini-2.0-flash"  # Stable 2.0 generation workhorse. Good balance for legacy applications.
    GEMINI_2_0_FLASH_LITE = "gemini-2.0-flash-lite"  # Budget option from 2.0 generation. Lower cost, simpler tasks.

    def __str__(self) -> str:
        """Return the model identifier string."""
        return self.value

    @property
    def is_experimental(self) -> bool:
        """Check if this is an experimental model (not recommended for production)."""
        return "exp" in self.value or "preview" in self.value

    @property
    def is_flash_variant(self) -> bool:
        """Check if this is a Flash variant (optimized for speed/cost)."""
        return "flash" in self.value

    @property
    def is_pro_variant(self) -> bool:
        """Check if this is a Pro variant (optimized for quality/reasoning)."""
        return "pro" in self.value

    @classmethod
    def get_default(cls) -> 'GeminiModel':
        """
        Get the recommended default model.

        Returns the best balance of performance, cost, and stability.
        """
        return cls.GEMINI_2_5_FLASH

    @classmethod
    def get_fastest(cls) -> 'GeminiModel':
        """Get the fastest model for low-latency requirements."""
        return cls.GEMINI_2_5_FLASH_LITE

    @classmethod
    def get_highest_quality(cls) -> 'GeminiModel':
        """Get the highest quality model for complex reasoning."""
        return cls.GEMINI_3_PRO

    @classmethod
    def get_most_economical(cls) -> 'GeminiModel':
        """Get the most cost-effective model."""
        return cls.GEMINI_2_5_FLASH_LITE
