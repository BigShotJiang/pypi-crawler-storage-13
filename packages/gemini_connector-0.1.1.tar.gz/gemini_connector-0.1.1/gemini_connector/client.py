"""
Google Gemini API Client
https://ai.google.dev/gemini-api/docs
"""

import requests
from gemini_connector.models import GeminiModel


class GeminiClient:
    """
    Client for interacting with Google Gemini API.

    This is a generic connector that handles authentication and HTTP communication.
    Applications should use this client and provide their own prompts.
    """

    BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

    def __init__(self, api_key: str, model: GeminiModel | str | None = None):
        """
        Initialize the Gemini API client.

        Args:
            api_key: Google Gemini API key
            model: Model to use (GeminiModel enum or str). Defaults to GeminiModel.GEMINI_2_5_FLASH
        """
        if not api_key:
            raise ValueError("API key is required")

        self.api_key = api_key

        # Handle model parameter
        if model is None:
            self.model = str(GeminiModel.get_default())
        elif isinstance(model, GeminiModel):
            self.model = str(model)
        else:
            self.model = model

    def _build_headers(self) -> dict[str, str]:
        """Build HTTP headers for API requests."""
        return {
            "x-goog-api-key": self.api_key,
            "Content-Type": "application/json"
        }

    def _build_url(self, endpoint: str) -> str:
        """Build full URL for API endpoint."""
        return f"{self.BASE_URL}/models/{self.model}:{endpoint}"

    def generate_content(self, prompt: str, **kwargs) -> dict[str, any]:
        """
        Generate content using Gemini API.

        Args:
            prompt: Text prompt to send to the model
            **kwargs: Additional parameters for the API request (e.g., temperature, maxOutputTokens)

        Returns:
            dict: Full API response

        Raises:
            requests.exceptions.HTTPError: If the API request fails
        """
        url = self._build_url("generateContent")
        headers = self._build_headers()

        payload = {
            "contents": [
                {
                    "parts": [
                        {
                            "text": prompt
                        }
                    ]
                }
            ]
        }

        # Merge any additional parameters
        if kwargs:
            payload.update(kwargs)

        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()

        return response.json()

    def set_model(self, model: GeminiModel | str) -> None:
        """
        Change the model for future requests.

        Args:
            model: New model to use (GeminiModel enum or str)
        """
        if isinstance(model, GeminiModel):
            self.model = str(model)
        else:
            self.model = model
