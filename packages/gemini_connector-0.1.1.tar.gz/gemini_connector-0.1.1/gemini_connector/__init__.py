"""
Gemini Connector - A generic Python library for Google Gemini API connectivity.

This package provides reusable utilities for connecting to Google Gemini API.
It does not contain prompts - those should be provided by your application.
"""

from gemini_connector.client import GeminiClient
from gemini_connector.models import GeminiModel
from gemini_connector.response_parser import (
    extract_text,
    extract_all_text_parts,
    get_finish_reason,
    get_safety_ratings
)
from gemini_connector.exceptions import (
    GeminiAPIError,
    GeminiAuthenticationError,
    GeminiRateLimitError,
    GeminiModelError,
    GeminiResponseError
)

__version__ = "0.1.0"

__all__ = [
    # Client
    "GeminiClient",
    # Models
    "GeminiModel",
    # Response utilities
    "extract_text",
    "extract_all_text_parts",
    "get_finish_reason",
    "get_safety_ratings",
    # Exceptions
    "GeminiAPIError",
    "GeminiAuthenticationError",
    "GeminiRateLimitError",
    "GeminiModelError",
    "GeminiResponseError",
]