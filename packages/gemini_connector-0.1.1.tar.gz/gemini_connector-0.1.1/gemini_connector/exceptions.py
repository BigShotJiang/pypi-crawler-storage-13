"""
Custom exceptions for Gemini API interactions.
"""


class GeminiAPIError(Exception):
    """Base exception for Gemini API errors."""
    pass


class GeminiAuthenticationError(GeminiAPIError):
    """Raised when API key is invalid or missing."""
    pass


class GeminiRateLimitError(GeminiAPIError):
    """Raised when rate limit is exceeded."""
    pass


class GeminiModelError(GeminiAPIError):
    """Raised when there's an issue with the specified model."""
    pass


class GeminiResponseError(GeminiAPIError):
    """Raised when response cannot be parsed or is invalid."""
    pass
