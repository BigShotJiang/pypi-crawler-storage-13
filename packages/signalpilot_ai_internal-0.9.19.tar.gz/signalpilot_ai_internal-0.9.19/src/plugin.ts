import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';

import { ISettingRegistry } from '@jupyterlab/settingregistry';
import {
  ICommandPalette,
  IThemeManager,
  IToolbarWidgetRegistry
} from '@jupyterlab/apputils';
import {
  INotebookTracker,
  NotebookPanel,
  INotebookModel
} from '@jupyterlab/notebook';
import { NotebookDiffTools } from './Notebook/NotebookDiffTools';
import { KernelExecutionListener } from './Chat/ChatContextMenu/KernelExecutionListener';
import { IStateDB } from '@jupyterlab/statedb';
import { IDocumentManager } from '@jupyterlab/docmanager';
import { DocumentRegistry } from '@jupyterlab/docregistry';
import { IDisposable } from '@lumino/disposable';
import { activateSage } from './activateSage';
import { NotebookDeploymentButtonWidget } from './Components/NotebookDeploymentButton';
import {
  getGlobalDiffNavigationWidget,
  getGlobalSnippetCreationWidget,
  setGlobalDiffNavigationWidget,
  setGlobalSnippetCreationWidget
} from './globalWidgets';
import { posthogService } from './Services/PostHogService';
import { initializeReplayIdManagement } from './utils/replayIdManager';
import { AppStateService } from './AppState';
import { SessionTimerBannerWidget } from './Components/SessionTimerBanner/SessionTimerBannerWidget';
import {
  isCloudDemoSession,
  shouldShowSessionTimerBanner
} from './sessionUtils';

/**
 * Initialization data for the sage-ai extension
 */
export const plugin: JupyterFrontEndPlugin<void> = {
  id: 'signalpilot-ai-internal:plugin',
  description: 'SignalPilot AI - Your AI Data Partner',
  autoStart: true,
  requires: [
    INotebookTracker,
    ICommandPalette,
    IThemeManager,
    IStateDB,
    IDocumentManager
  ],
  optional: [ISettingRegistry, IToolbarWidgetRegistry],
  activate: (
    app: JupyterFrontEnd,
    notebooks: INotebookTracker,
    palette: ICommandPalette,
    themeManager: IThemeManager,
    db: IStateDB,
    documentManager: IDocumentManager,
    settingRegistry: ISettingRegistry | null,
    toolbarRegistry: IToolbarWidgetRegistry | null
  ) => {
    console.log('JupyterLab extension signalpilot-ai-internal is activated!');
    console.log(window.location.href);

    // Initialize PostHog
    void posthogService.initialize();

    // Add a toolbar button to Notebook panels (only applies to .ipynb documents)
    class NotebookToolbarButtonExtension
      implements
        DocumentRegistry.IWidgetExtension<NotebookPanel, INotebookModel>
    {
      createNew(
        panel: NotebookPanel,
        context: DocumentRegistry.IContext<INotebookModel>
      ): IDisposable {
        // Create deployment button widget
        const notebookPath = context.path;
        const isNotebookReady = !context.model.isDisposed;
        const button = new NotebookDeploymentButtonWidget(
          app,
          notebookPath,
          isNotebookReady
        );

        // Insert the button into the notebook toolbar
        panel.toolbar.insertItem(
          10,
          'signalpilot-ai-internal:deployment-button',
          button
        );

        // Return the button as disposable
        return button;
      }
    }

    // Register the extension for Notebook documents
    const buttonExtension = new NotebookToolbarButtonExtension();
    app.docRegistry.addWidgetExtension('Notebook', buttonExtension);

    // Handle authentication callback and replay parameter early in the initialization process
    const handleEarlyAuth = async () => {
      // Check for replay parameter FIRST to determine if we need the timer banner
      const urlParams = new URLSearchParams(window.location.search);
      const hasReplayParam = urlParams.has('replay');
      
      if (hasReplayParam) {
        console.log('[Plugin] Replay parameter detected - setting demo mode early');
        await AppStateService.setDemoMode(true);
      }
      
      // Variable to hold the current timer banner instance
      let timerBannerInstance: SessionTimerBannerWidget | null = null;

      // Function to add the timer banner to the DOM
      const addTimerBanner = () => {
        if (timerBannerInstance) {
          console.log('[Plugin] Timer banner already exists, skipping');
          return;
        }

        const isDemoMode = AppStateService.isDemoMode();
        console.log('[Plugin] Adding timer banner - isDemoMode:', isDemoMode);
        timerBannerInstance = new SessionTimerBannerWidget(isDemoMode);

        // Add banner to the DOM at the top, before the main shell
        const mainShell = document.querySelector(
          '.lm-Widget.jp-LabShell.jp-ThemedContainer'
        );
        if (mainShell && mainShell.parentNode) {
          mainShell.parentNode.insertBefore(timerBannerInstance.node, mainShell);
          console.log('[Plugin] Timer banner added to DOM before main shell');
        } else {
          console.warn(
            '[Plugin] Could not find main shell, trying document.body'
          );
          // Fallback: add to beginning of body
          document.body.insertBefore(
            timerBannerInstance.node,
            document.body.firstChild
          );
          console.log('[Plugin] Timer banner added to document.body');
        }
        // Add class to body to apply margin for the banner
        document.body.classList.add('sage-timer-banner-visible');
        console.log('[Plugin] Added sage-timer-banner-visible class to body');
      };

      // Function to remove the timer banner from the DOM
      const removeTimerBanner = () => {
        if (!timerBannerInstance) {
          console.log('[Plugin] No timer banner to remove');
          return;
        }

        console.log('[Plugin] Removing timer banner');
        timerBannerInstance.node.remove();
        timerBannerInstance.dispose();
        timerBannerInstance = null;
        // Remove class from body
        document.body.classList.remove('sage-timer-banner-visible');
        console.log('[Plugin] Removed sage-timer-banner-visible class from body');
      };

      // Function to check and update banner visibility
      const updateBannerVisibility = () => {
        const shouldShow = shouldShowSessionTimerBanner();
        const isShowing = timerBannerInstance !== null;

        console.log(
          '[Plugin] Banner visibility check - shouldShow:',
          shouldShow,
          'isShowing:',
          isShowing,
          'isDemoMode:',
          AppStateService.isDemoMode()
        );

        if (shouldShow && !isShowing) {
          addTimerBanner();
        } else if (!shouldShow && isShowing) {
          removeTimerBanner();
        }
      };

      // Wait for the shell to be ready, then start polling
      app.restored.then(() => {
        // Initial check and add if needed
        updateBannerVisibility();

        // Poll every 30 seconds to check if we should show/hide the banner
        setInterval(() => {
          updateBannerVisibility();
        }, 30000); // 30 seconds
        console.log('[Plugin] Started polling for banner visibility every 30 seconds');
      });

      let replayId: string | null = null;
      let replayIdFromUrl = false; // Track if replayId came from URL

      try {
        // Import StateDBCachingService and JupyterAuthService dynamically to avoid circular dependencies
        const { StateDBCachingService } = await import(
          './utils/backendCaching'
        );
        const { JupyterAuthService } = await import(
          './Services/JupyterAuthService'
        );
        const { 
          isTakeoverModeEnabled, 
          getTakeoverReplayData, 
          disableTakeoverMode 
        } = await import('./utils/replayIdManager');

        // Initialize StateDB caching service early so authentication can use it
        StateDBCachingService.initialize();

        // Check takeover mode from localStorage and set in AppState
        if (isTakeoverModeEnabled()) {
          const takeoverData = getTakeoverReplayData();
          if (takeoverData && takeoverData.messages) {
            AppStateService.setTakeoverMode(true, takeoverData.messages);
            console.log('[Plugin] Takeover mode detected in localStorage, set in AppState');
          } else {
            // Invalid takeover data, clean it up
            disableTakeoverMode();
            console.warn('[Plugin] Invalid takeover data found, cleared');
          }
        }

        // Check for temp_token in URL and handle authentication callback
        const urlParams = new URLSearchParams(window.location.search);
        const tempToken = urlParams.get('temp_token');
        const isCallback = urlParams.get('auth_callback') === 'true';
        
        // Check if replayId is in URL BEFORE initializing
        const urlReplayId = urlParams.get('replay');
        if (urlReplayId) {
          replayIdFromUrl = true;
          console.log('[Replay] ReplayId found in URL:', urlReplayId);
        }
        
        // Initialize replayId management (checks localStorage and restores URL if needed)
        replayId = await initializeReplayIdManagement();
        if (replayId) {
          console.log(
            `[Replay] ReplayId initialized (from ${replayIdFromUrl ? 'URL' : 'localStorage'}):`,
            replayId
          );

          // Remove replay ID from URL immediately after reading it
          const url = new URL(window.location.href);
          if (url.searchParams.has('replay')) {
            url.searchParams.delete('replay');
            window.history.replaceState({}, '', url.toString());
            console.log('[Replay] Removed replay ID from URL');
          }
        }

        if (isCallback && tempToken) {
          console.log(
            'Processing temp_token during plugin initialization:',
            tempToken
          );

          // Handle the auth callback early
          const authSuccess = await JupyterAuthService.handleAuthCallback();
          if (authSuccess) {
            console.log(
              'Authentication successful during plugin initialization'
            );
            void posthogService.identifyUser();
            // User identification is now handled by PostHogService
            console.log('Authentication callback handled');
          } else {
            console.error('Authentication failed during plugin initialization');
          }
        }
      } catch (error) {
        console.error('Error processing early authentication:', error);
      }

      // Continue with normal activation regardless of auth result
      // Pass replayId and whether it came from URL to activateSage
      void activateSage(
        app,
        notebooks,
        palette,
        themeManager,
        db,
        documentManager,
        settingRegistry,
        toolbarRegistry,
        plugin,
        replayId,
        replayIdFromUrl
      );
    };

    // Start the async authentication handling
    void handleEarlyAuth();
  },
  deactivate: () => {
    console.log('JupyterLab extension signalpilot-ai-internal is deactivated!');

    // Cleanup snippet creation widget
    const snippetWidget = getGlobalSnippetCreationWidget();
    if (snippetWidget && !snippetWidget.isDisposed) {
      snippetWidget.dispose();
      setGlobalSnippetCreationWidget(undefined);
    }

    // Cleanup diff navigation widget
    const diffWidget = getGlobalDiffNavigationWidget();
    if (diffWidget && !diffWidget.isDisposed) {
      // Remove from DOM (could be attached to notebook or document.body)
      if (diffWidget.node.parentNode) {
        diffWidget.node.parentNode.removeChild(diffWidget.node);
      }
      diffWidget.dispose();
      setGlobalDiffNavigationWidget(undefined);
    }

    // Cleanup kernel execution listener
    const kernelExecutionListener = KernelExecutionListener.getInstance();
    kernelExecutionListener.dispose();

    // Cleanup theme detection
    NotebookDiffTools.cleanupThemeDetection();
  }
};
