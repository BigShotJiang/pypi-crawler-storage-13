# Rusted Graphs
A python version for Rusted Graphs, built on top of original [rusted-graphs](https://crates.io/crates/rusted_graphs) crate.
Check homepage for more info
[janya.joshi-rj.in/rusted-graphs](https://janya.joshi-rj.in/rusted-graphs)
