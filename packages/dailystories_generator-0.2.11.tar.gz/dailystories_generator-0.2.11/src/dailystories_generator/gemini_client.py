"""Gemini API client for text and image generation."""

import asyncio
import base64
from pathlib import Path
from typing import Optional, Any
from google import genai
from google.genai import types

from dailystories_generator.models import ReferenceImage


def _print_full_response_details(response: Any, context: str = "") -> None:
    """Print comprehensive details of a Gemini API response for debugging."""
    print(f"\n{'='*80}")
    print(f"📋 FULL RESPONSE DETAILS{f' ({context})' if context else ''}")
    print(f"{'='*80}")
    print(f"Response type: {type(response)}")
    print(f"Response dir(): {[attr for attr in dir(response) if not attr.startswith('_')]}")
    
    # Log prompt feedback
    if hasattr(response, "prompt_feedback"):
        feedback = response.prompt_feedback
        print(f"\nPrompt Feedback: {feedback}")
        print(f"Prompt Feedback type: {type(feedback)}")
        print(f"Prompt Feedback dir(): {[attr for attr in dir(feedback) if not attr.startswith('_')]}")
        if hasattr(feedback, "block_reason"):
            print(f"Block Reason: {feedback.block_reason}")
        if hasattr(feedback, "safety_ratings"):
            print(f"Safety Ratings: {feedback.safety_ratings}")
    
    # Log candidates with decoded finish reasons
    if hasattr(response, "candidates") and response.candidates:
        print(f"\nNumber of candidates: {len(response.candidates)}")
        for i, candidate in enumerate(response.candidates):
            print(f"\nCandidate {i}:")
            print(f"  Candidate type: {type(candidate)}")
            print(f"  Candidate dir(): {[attr for attr in dir(candidate) if not attr.startswith('_')]}")
            
            # Print ALL candidate attributes
            for attr in dir(candidate):
                if not attr.startswith('_'):
                    try:
                        value = getattr(candidate, attr)
                        if not callable(value):
                            print(f"  {attr}: {value}")
                    except Exception as e:
                        print(f"  {attr}: <error accessing: {e}>")
            
            if hasattr(candidate, "finish_reason"):
                finish_reason = candidate.finish_reason
                print(f"\n  Finish Reason: {finish_reason}")
                
                # Provide context for specific finish reasons
                if hasattr(types, 'FinishReason'):
                    if finish_reason == types.FinishReason.SAFETY:
                        print(f"  ⚠️  Generation blocked due to safety filters")
                    elif finish_reason == types.FinishReason.IMAGE_SAFETY:
                        print(f"  ⚠️  Image generation blocked due to image safety filters")
                    elif finish_reason == types.FinishReason.PROHIBITED_CONTENT or finish_reason == types.FinishReason.IMAGE_PROHIBITED_CONTENT:
                        print(f"  ⚠️  Content blocked due to policy violations")
                    elif finish_reason == types.FinishReason.OTHER or finish_reason == types.FinishReason.NO_IMAGE:
                        print(f"  ⚠️  Unknown error - possibly an internal Gemini issue")
            
            if hasattr(candidate, "safety_ratings"):
                print(f"\n  Safety Ratings: {candidate.safety_ratings}")
            if hasattr(candidate, "content"):
                content = candidate.content
                print(f"  Content type: {type(content)}")
                print(f"  Content dir(): {[attr for attr in dir(content) if not attr.startswith('_')]}")
                if hasattr(content, "parts"):
                    print(f"  Parts count: {len(list(content.parts))}")
                    for j, part in enumerate(content.parts):
                        if hasattr(part, "text"):
                            print(f"    Part {j} (text): {part.text[:100]}...")
                        elif hasattr(part, "inline_data"):
                            print(f"    Part {j}: inline_data present")
                        else:
                            print(f"    Part {j}: {type(part)}")
                else:
                    print(f"  Content has no parts")
    else:
        print("No candidates in response")
    
    # Check usage metadata
    if hasattr(response, "usage_metadata"):
        print(f"\nUsage Metadata: {response.usage_metadata}")
    
    # Try to print the raw response object using repr
    print(f"\n📄 RAW RESPONSE REPR:")
    try:
        print(f"{repr(response)}")
    except Exception as e:
        print(f"<error getting repr: {e}>")
    print(f"{'='*80}\n")


def create_white_pixel_image() -> bytes:
    """Create a 1x1 white pixel PNG image as a fallback."""
    # PNG header + IHDR + IDAT + IEND chunks for 1x1 white pixel
    return base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="
    )


class GeminiClient:
    """Client for interacting with Google's Gemini API."""
    
    def __init__(self, api_key: str):
        """
        Initialize the Gemini client.
        
        Args:
            api_key: Google API key for Gemini
        """
        self.api_key = api_key
        self.client = genai.Client(api_key=api_key)
    
    async def generate_text(
        self,
        prompt: str,
        system_prompt: str,
        model: str = "gemini-2.5-flash",
        max_tokens: int = 1000,
    ) -> tuple[str, int]:
        """
        Generate text using Gemini.
        
        Args:
            prompt: The user prompt
            system_prompt: The system instruction
            model: The Gemini model to use
            max_tokens: Maximum tokens for output
        
        Returns:
            Tuple of (generated_text, total_tokens)
        """
        try:
            # Prepare config with system instruction
            config = types.GenerateContentConfig(
                system_instruction=system_prompt,
                max_output_tokens=max_tokens,
            )
            
            # Generate content using new SDK (synchronous, wrapped in async)
            response = await asyncio.to_thread(
                self.client.models.generate_content,
                model=model,
                contents=prompt,
                config=config,
            )
            
            # Extract text from response
            response_text = response.text
            
            # Check if response is empty (might have hit token limits)
            if not response_text:
                print(f"WARNING: Response text is empty. Checking finish reason...")
                if hasattr(response, 'candidates') and response.candidates:
                    for candidate in response.candidates:
                        if hasattr(candidate, 'finish_reason'):
                            print(f"  Finish reason: {candidate.finish_reason}")
            
            # Get token count from usage metadata if available
            total_tokens = 0
            if hasattr(response, 'usage_metadata'):
                usage = response.usage_metadata
                if hasattr(usage, 'total_token_count'):
                    total_tokens = usage.total_token_count
                elif hasattr(usage, 'prompt_token_count') and hasattr(usage, 'candidates_token_count'):
                    total_tokens = usage.prompt_token_count + usage.candidates_token_count
            
            return response_text, total_tokens
        except Exception as e:
            print(f"ERROR in generate_text: {e}")
            import traceback
            traceback.print_exc()
            raise
    
    async def generate_image(
        self,
        content_parts: list[str | dict[str, Any]],
        system_instruction: str,
        model: str = "gemini-2.5-flash-image",
        max_output_tokens: Optional[int] = None,
        thinking_level: str = "LOW",
    ) -> tuple[bytes, int, Optional[types.FinishReason]]:
        """
        Generate an image using Gemini with system instruction and thinking config.
        
        Args:
            content_parts: List of content parts (images, text) to pass to the model
            system_instruction: System instruction text
            model: The Gemini image model to use
            max_output_tokens: Maximum number of tokens to generate (optional)
            thinking_level: Thinking level for generation ("LOW" or "HIGH")
        
        Returns:
            Tuple of (image_bytes, tokens_used, finish_reason)
            finish_reason is None on success, or the FinishReason enum value on failure
        """
        # Convert content_parts to new SDK format
        converted_parts = []
        for part in content_parts:
            if isinstance(part, str):
                converted_parts.append(part)
            elif isinstance(part, dict):
                # Convert old format {"mime_type": "...", "data": b"..."} to new SDK format
                if "mime_type" in part and "data" in part:
                    converted_parts.append(
                        types.Part(
                            inline_data=types.Blob(
                                mime_type=part["mime_type"],
                                data=part["data"],
                            )
                        )
                    )
        
        # Create generation config
        config_params = {
            "system_instruction": system_instruction,
        }
        # Only add thinking config if thinking_level is provided (not all models support it)
        if thinking_level:
            config_params["thinking_config"] = types.ThinkingConfig(thinking_level=thinking_level.upper())
        if max_output_tokens is not None:
            config_params["max_output_tokens"] = max_output_tokens
        
        config = types.GenerateContentConfig(**config_params)
        
        try:
            # Generate image using new SDK (wrapped in async)
            response = await asyncio.to_thread(
                self.client.models.generate_content,
                model=model,
                contents=converted_parts,
                config=config,
            )
            
            # Check if response was blocked by safety filters
            if hasattr(response, "prompt_feedback") and response.prompt_feedback:
                feedback = response.prompt_feedback
                block_reason = getattr(feedback, "block_reason", None)
                if block_reason:
                    print(f"ERROR: Gemini blocked the request. Block reason: {block_reason}")
                    if hasattr(feedback, "safety_ratings"):
                        print(f"Safety ratings: {feedback.safety_ratings}")
                    # Don't retry on safety blocks - return white pixel immediately
                    print("⚠️  Returning 1x1 white pixel due to safety block")
                    return create_white_pixel_image(), 0, None
            
            # Extract image data from response
            raw_image_data = None
            if hasattr(response, "parts") and response.parts:
                for part in response.parts:
                    if hasattr(part, "inline_data") and part.inline_data:
                        raw_image_data = part.inline_data.data
                        break
            
            # If we got image data, success!
            if raw_image_data:
                # Get token count if available
                tokens_used = 1
                if hasattr(response, 'usage_metadata'):
                    usage = response.usage_metadata
                    if hasattr(usage, 'total_token_count'):
                        tokens_used = usage.total_token_count
                return raw_image_data, tokens_used, None
            
            # If no image data, check finish reason
            finish_reason = None
            if hasattr(response, "candidates") and response.candidates:
                for candidate in response.candidates:
                    if hasattr(candidate, "finish_reason"):
                        finish_reason = candidate.finish_reason
                        
                        # Print full response details when we FAILED (no image data)
                        _print_full_response_details(response, f"Failed with Finish Reason {finish_reason}")
                        break
            
            # Return failure with finish reason
            print(f"⚠️  Image generation failed with finish reason: {finish_reason}")
            return create_white_pixel_image(), 0, finish_reason
            
        except Exception as e:
            print(f"ERROR: Exception during image generation: {e}")
            import traceback
            traceback.print_exc()
            return create_white_pixel_image(), 0, None


# Import Any for type hints moved to top
