"""Kheera - a playful cucumber-themed utility library."""

from .core import (
    calculate_coolness,
    cool_down,
    cucumberify,
    draw,
    is_fresh,
    rate_kheera,
    slice,
    throw,
    yoga_mode,
)
from .errors import KheeraError
from .health import health_status

__all__ = [
    "calculate_coolness",
    "cool_down",
    "cucumberify",
    "draw",
    "health_status",
    "is_fresh",
    "KheeraError",
    "rate_kheera",
    "slice",
    "throw",
    "yoga_mode",
]

__version__ = "0.1.1"
