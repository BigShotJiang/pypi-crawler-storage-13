# Kheera Quick Reference

Use this condensed sheet when you just need the highlights—features, callable functions, CLI switches, and HTTP endpoints.

## Features
- Cucumber-themed core utilities for slicing, cooling, throwing, and general freshness fun.
- Built-in ASCII art and Matplotlib rendering (`draw`) that outputs PNG bytes on demand.
- Deterministic error codes (e.g., `KHEERA-SLICE-002`, `KHEERA-CUCIFY-413`) for resilient automation.
- Ready-to-run FastAPI backend with JSON responses plus a `/kheera/draw` PNG endpoint.
- Lightweight CLI shipping as the `kheera` console script.

## Python Functions (`kheera` package)
- `draw(return_bytes: bool = False) -> Optional[bytes]`
- `slice(count: int = 5) -> List[str]`
- `cool_down(temp: int = 10) -> str`
- `rate_kheera() -> str`
- `is_fresh() -> str`
- `throw(target: str) -> str`
- `calculate_coolness(name: str) -> str`
- `cucumberify(text: str) -> str`
- `yoga_mode() -> str`
- `health_status() -> HealthStatus`
- `ascii_art() -> str`

## Custom Exceptions (`kheera.errors`)
- `KheeraError(code, message, status_code)`
- `InvalidSliceCountError`
- `CoolingNotEffectiveError`
- `TargetNotFoundError`
- `TextTooLargeError`
- `RottenCucumberError`

## CLI Commands
```
kheera --help
kheera --version
kheera --draw
kheera --slice <n>
```

## REST Endpoints (default host: `http://localhost:8000`)
- `GET /` → API heartbeat
- `GET /kheera/slice?count=<int>`
- `GET /kheera/cool_down?temp=<int>`
- `GET /kheera/rate`
- `GET /kheera/fresh`
- `GET /kheera/throw?target=<str>`
- `GET /kheera/coolness?name=<str>`
- `POST /kheera/cucumberify` (`{"text": "..."}`)
- `GET /kheera/yoga`
- `GET /kheera/ascii`
- `GET /kheera/draw`
- `GET /kheera/health`
- `GET /kheera/error_codes`

## Useful Locations
- Package entry point: `kheera/__init__.py`
- CLI module: `kheera/cli.py`
- Error catalogue: `docs/errors.md`
- API root: `backend/app.py`
- Router definitions: `backend/routers/`
