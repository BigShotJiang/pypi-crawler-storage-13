# MCP 命令执行服务器

一个基于 MCP（Model Context Protocol）的安全命令执行服务器，允许在指定目录中执行 shell 命令。

## 功能特性

- ✅ **安全执行**: 支持目录白名单限制，只能在允许的目录中执行命令
- ✅ **灵活配置**: 可配置默认工作目录和允许访问的目录列表
- ✅ **超时保护**: 内置命令执行超时机制（默认30秒）
- ✅ **异步执行**: 基于 asyncio 的高性能异步处理
- ✅ **MCP 协议**: 完全兼容 MCP 2024-11-05 协议
- ✅ **详细日志**: 所有操作都会记录到 stderr，便于调试

## 安装

### 前置要求

- Python 3.8+
- 无需额外依赖（仅使用标准库）

### 通过 pip 安装（推荐）

```bash
pip install exec-dir-mcp
```

### 从源码安装

```bash
# 克隆或下载项目文件
git clone https://github.com/yunhai-dev/exec-dir-mcp.git
cd exec-dir-mcp

# 或直接使用 main.py 文件
```

## 使用方法

### 基本用法

```bash
# 使用 pip 安装后，直接启动（推荐）
exec-dir-mcp --dir /path/to/your/project

# 或者使用 Python 模块方式
python -m exec_dir_mcp --dir /path/to/your/project

# 从源码运行
python main.py --dir /path/to/your/project

# 指定默认工作目录
exec-dir-mcp --dir /path/to/your/project

# 指定允许的目录列表
exec-dir-mcp --dir /home/user/projects --allowed /home/user/projects --allowed /tmp
```

### 命令行参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--dir` | 默认工作目录 | 当前目录 |
| `--allowed` | 允许访问的目录（可多次使用） | 无（允许所有目录） |

### 使用示例

#### 1. 在默认目录执行命令

```bash
# 启动服务器（默认目录为当前目录）
exec-dir-mcp

# 或者从源码运行
python main.py
```

然后通过 MCP 客户端发送请求：

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "execute_command",
    "arguments": {
      "command": "ls -la"
    }
  }
}
```

#### 2. 指定工作目录执行命令

```bash
# 启动服务器，指定默认目录
exec-dir-mcp --dir /home/user/projects

# 或者从源码运行
python main.py --dir /home/user/projects
```

```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "tools/call",
  "params": {
    "name": "execute_command",
    "arguments": {
      "command": "python script.py",
      "working_dir": "/home/user/projects/my_app",
      "timeout": 60
    }
  }
}
```

#### 3. 使用目录白名单（安全模式）

```bash
# 只允许在指定目录中执行命令
exec-dir-mcp --dir /home/user/projects --allowed /home/user/projects --allowed /tmp/build

# 或者从源码运行
python main.py --dir /home/user/projects --allowed /home/user/projects --allowed /tmp/build
```

尝试在其他目录执行命令会收到错误：

```json
{
  "success": false,
  "error": "目录不在允许列表中: /etc"
}
```

## MCP 协议

### 工具列表

#### execute_command

在指定目录中执行 shell 命令。

**参数：**

- `command` (string, 必需): 要执行的 shell 命令
- `working_dir` (string, 可选): 工作目录（默认使用服务器配置的默认目录）
- `timeout` (integer, 可选): 超时时间，单位秒（默认 30 秒）

**返回结果：**

```json
{
  "success": true,
  "stdout": "命令输出",
  "stderr": "错误输出",
  "returncode": 0,
  "working_dir": "/path/to/working/dir",
  "command": "执行的命令"
}
```

**错误示例：**

```json
{
  "success": false,
  "error": "命令执行超时（30秒）"
}
```

## 安全注意事项

1. **目录限制**:
   - 强烈建议在生产环境中使用 `--allowed` 参数限制可访问的目录
   - 如果不指定 `--allowed`，服务器将允许所有目录访问

2. **命令执行**:
   - 服务器以启动进程的用户权限执行命令
   - 请确保运行服务器的用户具有适当的权限

3. **超时保护**:
   - 默认 30 秒超时，可根据需要调整
   - 超时后进程将被强制终止

4. **日志记录**:
   - 所有操作日志输出到 stderr
   - 生产环境中建议重定向日志到文件

## 与 Claude 集成

该服务器可以与 Claude 桌面版或支持 MCP 的编辑器集成：

```json
{
  "mcpServers": {
    "command-executor": {
      "command": "exec-dir-mcp",
      "args": ["--dir", "/your/projects"],
      "env": {}
    }
  }
}
```

### 从源码集成（开发模式）

如果你从源码运行服务器：

```json
{
  "mcpServers": {
    "command-executor": {
      "command": "python",
      "args": ["/path/to/main.py", "--dir", "/your/projects"],
      "env": {}
    }
  }
}
```

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request！

## 更新日志

### v1.0.1
- 更新 README，支持 PyPI 安装方式
- 优化安装和使用说明

### v1.0.0
- 初始版本
- 支持基本命令执行功能
- 实现目录白名单安全机制
- 支持超时保护
- 完整的 MCP 协议实现
