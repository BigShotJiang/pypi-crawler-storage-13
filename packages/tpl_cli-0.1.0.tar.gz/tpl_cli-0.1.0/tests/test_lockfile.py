from __future__ import annotations

from tpl.lockfile import LOCKFILE_NAME, LockEntry, Lockfile, ProjectInfo


def test_lockfile_round_trip(tmp_path) -> None:
    lock = Lockfile(root=tmp_path)
    entry = LockEntry(
        path="configs/logging.yaml",
        source="gh:you/template",
        version="0.1.0",
        entry="logging.yaml",
        sha256="abc123",
        context={"project_slug": "demo"},
    )

    lock.set_project(
        ProjectInfo(source="gh:you/project", version="0.2.0", context={"name": "demo"})
    )
    lock.upsert(entry)

    persisted = (tmp_path / LOCKFILE_NAME).read_text(encoding="utf-8")
    assert "[[files]]" in persisted
    assert 'path = "configs/logging.yaml"' in persisted

    reloaded = Lockfile(root=tmp_path)
    loaded_entry = reloaded.find("configs/logging.yaml")
    project_info = reloaded.project()

    assert loaded_entry == entry
    assert project_info == ProjectInfo(
        source="gh:you/project", version="0.2.0", context={"name": "demo"}
    )
