class TPLError(Exception):
    """Base exception for tpl errors."""


class GitError(TPLError):
    """Raised when git commands fail."""


class TemplateError(TPLError):
    """Raised for template metadata or rendering issues."""
