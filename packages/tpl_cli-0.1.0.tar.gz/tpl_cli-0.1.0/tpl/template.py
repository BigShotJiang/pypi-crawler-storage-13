from __future__ import annotations

import hashlib
import tomllib
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory

from .errors import TemplateError


@dataclass
class TemplateMetadata:
    name: str
    version: str
    entry: str


def load_metadata(repo_path: Path) -> TemplateMetadata:
    template_toml = repo_path / "TEMPLATE.toml"
    if not template_toml.exists():
        raise TemplateError("Template missing TEMPLATE.toml")

    try:
        data = tomllib.loads(template_toml.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise TemplateError(f"Failed to parse TEMPLATE.toml: {exc}") from exc

    try:
        name = data["name"]
        version = data["version"]
        entry = data["entry"]
    except KeyError as exc:
        raise TemplateError(f"Missing required template metadata field: {exc.args[0]}") from exc

    return TemplateMetadata(name=name, version=version, entry=entry)


def render_template(
    repo_path: Path, extra_context: dict[str, str]
) -> tuple[bytes, TemplateMetadata]:
    metadata = load_metadata(repo_path)

    from cookiecutter.main import cookiecutter  # Lazy import for optional dependency loading.

    with TemporaryDirectory() as tmpdir:
        rendered_path = Path(
            cookiecutter(
                template=str(repo_path),
                no_input=True,
                extra_context=extra_context or None,
                output_dir=tmpdir,
            )
        )
        entry_path = rendered_path / metadata.entry
        if not entry_path.exists():
            raise TemplateError(f"Rendered template missing entry file '{metadata.entry}'")
        file_bytes = entry_path.read_bytes()

    return file_bytes, metadata


def compute_sha256(data: bytes) -> str:
    digest = hashlib.sha256()
    digest.update(data)
    return digest.hexdigest()
