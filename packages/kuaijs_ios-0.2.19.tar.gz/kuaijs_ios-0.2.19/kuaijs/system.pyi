from typing import Any, Dict, List, Optional, Protocol, TypedDict

# 获取内存使用信息（单位：MB）
# 返回键：
# - used: 已使用内存
# - available: 可用内存
# - total: 系统总内存
# - usagePercentage: 使用率（0-100）
class MemoryInfo(Protocol):
    # 已使用内存（MB）
    used: int
    # 可用内存（MB）
    available: int
    # 系统总内存（MB）
    total: int
    # 使用率（0-100）
    usagePercentage: int

# 获取当前运行的应用信息（可能为 None）
class ProcessArguments(Protocol):
    # 环境变量映射（键为字符串，值为任意类型）
    env: Dict[str, Any]
    # 启动参数列表
    args: List[str]

class ActivateAppInfo(Protocol):
    # 应用名称
    name: str
    # 进程 ID
    pid: int
    # 应用 Bundle ID
    bundleId: str
    # 启动参数信息
    processArguments: ProcessArguments

# 设置 WDA 参数
# 参数：
# - params: 支持的键：
#   - mjpegServerScreenshotQuality: int 截图质量（MJPEG）
#   - mjpegServerFramerate: int MJPEG 帧率
#   - screenshotQuality: int 普通截图质量
class WDASettings(TypedDict):
    # MJPEG 截图质量
    mjpegServerScreenshotQuality: Optional[int]
    # MJPEG 帧率
    mjpegServerFramerate: Optional[int]
    # 普通截图质量
    screenshotQuality: Optional[int]

# 启动应用
# 参数：
# - bundle_id: 应用的 Bundle ID，例如 "com.example.app"
# - args: 启动参数列表，例如 ["--flag", "--debug"]
# - env: 环境变量映射，例如 {"ENV": "1"}
def startApp(bundle_id: str, args: List[str] = ..., env: Dict[str, Any] = ...) -> bool:
    """启动应用

    参数:
      bundle_id: 应用 Bundle ID
      args: 启动参数列表
      env: 环境变量映射
    返回:
      bool: 是否启动成功
    """
    ...

# 停止应用
# 参数：
# - bundle_id: 应用的 Bundle ID
def stopApp(bundle_id: str) -> bool:
    """停止应用"""
    ...

# 激活应用到前台
# 参数：
# - bundle_id: 应用的 Bundle ID
def activateApp(bundle_id: str) -> bool:
    """激活应用到前台（未启动则启动）"""
    ...

def activateAppInfo() -> Optional[ActivateAppInfo]:
    """获取当前运行的应用信息（可能为 None）"""
    ...

# 使用系统浏览器打开 URL
# 参数：
# - url: 例如 "https://example.com"
def openURL(url: str) -> bool:
    """使用系统浏览器打开 URL"""
    ...

# 发送系统通知（后台生效）
# 参数：
# - msg: 通知内容
# - title: 通知标题，空或 "undefined" 时使用应用名称
# - id: 通知 ID，相同 ID 会覆盖
def notify(msg: str, title: str = ..., id: str = ...) -> None:
    """发送系统通知（后台生效）"""
    ...

# 设置剪贴板文本（仅前台有效）
# 参数：
# - text: 要写入剪贴板的文本
def setClipboard(text: str) -> bool:
    """设置剪贴板文本（仅前台有效）"""
    ...

# 获取剪贴板文本（仅前台有效）
def getClipboard() -> str:
    """获取剪贴板文本（仅前台有效）"""
    ...

# 是否锁屏
def isLocked() -> bool:
    """是否锁屏"""
    ...

# 锁屏
def lock() -> bool:
    """锁屏"""
    ...

# 解锁
def unlock() -> bool:
    """解锁"""
    ...

def getMemoryInfo() -> MemoryInfo:
    """获取内存使用信息（MB）：used/available/total/usagePercentage"""
    ...

# 获取已使用内存（MB）
def getUsedMemory() -> int:
    """获取已使用内存（MB）"""
    ...

# 获取可用内存（MB）
def getAvailableMemory() -> int:
    """获取可用内存（MB）"""
    ...

# 获取系统总内存（MB）
def getTotalMemory() -> int:
    """获取系统总内存（MB）"""
    ...

# 启动 WDA 服务
def startWDA() -> bool:
    """启动 WDA 服务"""
    ...

# 获取 WDA 状态（是否可用）
def getWDAStatus() -> bool:
    """获取 WDA 状态（是否可用）"""
    ...

def setWDASettings(params: Optional[WDASettings] = ...) -> bool:
    """设置 WDA 参数（质量/帧率/截图质量）"""
    ...
