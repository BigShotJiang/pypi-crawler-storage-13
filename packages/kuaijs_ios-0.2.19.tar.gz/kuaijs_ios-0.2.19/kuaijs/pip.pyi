from typing import Optional, TypedDict

class LogViewParams(TypedDict):
    width: Optional[int]
    height: Optional[int]
    textSize: Optional[int]
    textColor: Optional[str]
    backgroundColor: Optional[str]

def setLogViewParams(params: Optional[LogViewParams] = ...) -> None:
    """设置悬浮窗日志窗口的显示参数（需在显示前调用）"""
    ...

def isPipActive() -> bool:
    """是否开启了悬浮窗"""
    ...

def showLogWindow() -> bool:
    """显示日志窗口（App 必须在前台）"""
    ...

def closeLogWindow() -> bool:
    """关闭日志窗口（App 必须在前台）"""
    ...

def setPipCtrlScript(ctrl: bool) -> bool:
    """设置是否允许悬浮窗控制脚本启停"""
    ...
