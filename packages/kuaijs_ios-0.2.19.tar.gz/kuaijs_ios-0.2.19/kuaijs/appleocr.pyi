from typing import List, Optional, Protocol

# OCR 识别（Apple Vision）
# 参数：
# - input: 输入源（imageId、URL字符串、文件路径或 "screen"）
# - x: 边界框左上角 x 坐标
# - y: 边界框左上角 y 坐标
# - ex: 边界框右下角 x 坐标
# - ey: 边界框右下角 y 坐标
# - languages: 识别语言数组，例如 ["zh-Hans", "en-US"]
class OCRResult(Protocol):
    text: str
    confidence: float
    x: int
    y: int
    ex: int
    ey: int
    width: int
    height: int
    centerX: int
    centerY: int

def recognize(
    input: str,
    x: int = ...,
    y: int = ...,
    ex: int = ...,
    ey: int = ...,
    languages: Optional[List[str]] = ...,
) -> List[OCRResult]:
    """OCR 识别（Apple Vision）

    参数默认值:
      x/y/ex/ey: 0
      languages: ["zh-Hans", "en-US"]
    返回:
      List[OCRResult]: 文本、置信度与位置信息列表
    """
    ...

# 纯数字 OCR 识别
# 参数：同上，过滤非数字，仅保留 0-9 . , - +
# 返回：数字文本结果列表（含位置信息）
def recognizeNumbers(
    input: str,
    x: int = ...,
    y: int = ...,
    ex: int = ...,
    ey: int = ...,
) -> List[OCRResult]:
    """仅识别数字（过滤非数字，保留 0-9 . , - +）

    参数默认值:
      x/y/ex/ey: 0
    返回:
      同 recognize
    """
    ...

# 查找包含目标文本的位置
# 参数：
# - input: 输入源（imageId、URL字符串、文件路径或 "screen"）
# - targetTexts: 要查找的目标文本数组
# - x/y/ex/ey: 搜索区域边界框
# - languages: 识别语言数组（可选）
# 返回：匹配到的文本位置信息列表
def findText(
    input: str,
    texts: List[str],
    x: int = ...,
    y: int = ...,
    ex: int = ...,
    ey: int = ...,
    languages: Optional[List[str]] = ...,
) -> List[OCRResult]:
    """查找指定文本位置

    参数默认值:
      x/y/ex/ey: 0
      languages: ["zh-Hans", "en-US"]
    返回:
      List[OCRResult]: 匹配文本的位置信息列表
    """
    ...
