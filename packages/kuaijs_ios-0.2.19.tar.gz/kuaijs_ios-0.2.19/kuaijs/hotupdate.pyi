from typing import Optional, Protocol, TypedDict

class HotUpdateOptions(TypedDict):
    url: Optional[str]
    version: Optional[int]
    timeout: Optional[int]

class HotUpdateResult(Protocol):
    needUpdate: bool
    error: Optional[str]
    data: Optional[HotUpdateResponse]

class HotUpdateResponse(Protocol):
    download_url: str
    version: int
    download_timeout: int
    dialog: bool
    msg: str
    force: bool
    md5: Optional[str]

# 下载并安装（返回 {updated,error?}）
class InstallResult(Protocol):
    updated: bool
    error: Optional[str]

def checkUpdate(options: Optional[HotUpdateOptions] = ...) -> HotUpdateResult:
    """检查更新

    参数:
      options: 检查参数（url/version/timeout）
    返回:
      HotUpdateResult: needUpdate/data/error
    """
    ...

def downloadAndInstall() -> InstallResult:
    """下载并安装更新（执行成功会自动重启脚本）"""
    ...

# 获取当前应用版本号（整数）
def getCurrentVersion() -> int:
    """获取当前应用版本号（数字）"""
    ...
