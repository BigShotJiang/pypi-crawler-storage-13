import streamlit as st
from datetime import date, datetime
from typing import Optional, Callable, Any


streamlit_dateinput_intl_component = st.components.v2.component(
    "streamlit-dateinput-intl.streamlit_dateinput_intl",
    js="index-*.js",
    html='<div class="react-root"></div>',
)


def _parse_date(value: Any) -> Optional[str]:
    """Parse date value to ISO format string."""
    if value is None:
        return None
    if value == "today":
        return date.today().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, str):
        # Try to parse the string as a date
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return parsed.date().isoformat()
        except (ValueError, AttributeError):
            return value
    return str(value)


def streamlit_dateinput_intl(
    label: Optional[str] = None,
    value: Any = "today",
    min: Optional[Any] = None,
    max: Optional[Any] = None,
    key: Optional[str] = None,
    help: Optional[str] = None,
    on_change: Optional[Callable] = None,
    args: Optional[tuple] = None,
    kwargs: Optional[dict] = None,
    *,
    format: str = "YYYY/MM/DD",
    disabled: bool = False,
    label_visibility: str = "visible",
    width: str = "stretch",
    clearable: bool = False,
):
    """Create a new instance of "streamlit_dateinput_intl".

    Parameters
    ----------
    label: str or None
        A short label explaining to the user what this date input is for.
    value: date, datetime, str, or "today"
        The value of this widget when it first renders. Defaults to "today".
        Can be a date, datetime, ISO format string, or "today".
    min: date, datetime, str, or None
        The minimum selectable date. If None, there is no minimum.
    max: date, datetime, str, or None
        The maximum selectable date. If None, there is no maximum.
    key: str or None
        An optional key that uniquely identifies this component.
    help: str or None
        A tooltip that gets displayed next to the label.
    on_change: callable or None
        An optional callback invoked when this date input's value changes.
    args: tuple or None
        An optional tuple of args to pass to the callback.
    kwargs: dict or None
        An optional dict of kwargs to pass to the callback.
    format: str
        The format string for displaying the date. Defaults to "YYYY/MM/DD".
    disabled: bool
        Whether this date input is disabled. Defaults to False.
    label_visibility: str
        The visibility of the label. Can be "visible", "hidden", or "collapsed".
        Defaults to "visible".
    width: str
        The width of the component. Defaults to "stretch".
    clearable: bool
        Whether this date input is clearable. Defaults to False.
    Returns
    -------
    date or None
        The selected date, or None if no date is selected.
    """
    # Parse date values
    parsed_value = to_iso_string(value)
    parsed_min = to_iso_string(min)
    parsed_max = to_iso_string(max)

    # Call the component
    # The component returns the date value (string or None)
    component_value = streamlit_dateinput_intl_component(
        label=label,
        value=parsed_value,
        min=parsed_min,
        max=parsed_max,
        format=format,
        disabled=disabled,
        label_visibility=label_visibility,
        width=width,
        clearable=clearable,
        on_change=on_change,
        key=key,
        default=None,
    )

    # Handle the returned value
    # It could be a string (ISO date), None, or a dict (if state is returned)
    if component_value is None:
        return None

    # If it's a dict (state object), extract the value
    if isinstance(component_value, dict):
        component_value = component_value.get("value", component_value)

    print("component_value", component_value)

    # Parse the returned value back to a date if it's a string
    if isinstance(component_value, str):
        try:
            return datetime.fromisoformat(component_value).date()
        except (ValueError, AttributeError):
            # If parsing fails, try to parse as date string
            try:
                return datetime.strptime(component_value, "%Y-%m-%d").date()
            except (ValueError, AttributeError):
                return component_value

    return None

# date/datetimeオブジェクトをISO文字列形式に変換
def to_iso_string(d: Optional[Any]) -> Optional[str]:
    if d is None:
        return None
    if isinstance(d, str):
        return d
    if isinstance(d, datetime):
        return d.date().isoformat()
    if isinstance(d, date):
        return d.isoformat()
    return None
