# streamlit-dateinput-intl

DateInput internationalization

## Installation instructions

```sh
uv pip install streamlit-dateinput-intl
```

### Development install (editable)

When developing this component locally, install it in editable mode so Streamlit picks up code changes without rebuilding a wheel. Run this from the directory that contains `pyproject.toml`:

```sh
uv pip install -e . --force-reinstall
```

## Development environment

### Initial Project Setup

If you're setting up a new project from scratch using the Streamlit component template:

1. **Run the cookiecutter script** to generate a new project:
   ```sh
   uvx --from cookiecutter cookiecutter gh:streamlit/component-template --directory cookiecutter/v2
   ```

2. **Follow the instructions** to generate a new project

3. **Navigate into the newly generated project**:
   ```sh
   cd streamlit-dateinput-intl
   ```

4. **Create a virtual environment** using UV:
   ```sh
   uv venv .venv
   ```

5. **Activate the virtual environment**:
   - On macOS/Linux:
     ```sh
     source .venv/bin/activate
     ```
   - On Windows:
     ```sh
     .venv\Scripts\activate
     ```

6. **Build the frontend**:
   ```sh
   cd streamlit_dateinput_intl/frontend
   npm i
   npm run build
   cd ../..
   ```

7. **Install the component and dependencies**:
   ```sh
   uv pip install -e .
   ```

8. **Run the Streamlit app** to test:
   ```sh
   streamlit run ./example.py
   ```

### Ongoing Development

To continue developing after the initial setup:

1. **Prerequisites**: Ensure you have the following installed:
   - Python >= 3.10
   - Node.js >= 24 (LTS)
   - [UV](https://github.com/astral-sh/uv) package manager

2. **Activate the virtual environment** (if not already active):
   - On macOS/Linux:
     ```sh
     source .venv/bin/activate
     ```
   - On Windows:
     ```sh
     .venv\Scripts\activate
     ```

3. **Install frontend dependencies** (if needed):
   ```sh
   cd streamlit_dateinput_intl/frontend
   npm install
   cd ../..
   ```

4. **Install the package in editable mode**:
   ```sh
   uv pip install -e . --force-reinstall
   ```

5. **Install development dependencies** (optional, for testing):
   ```sh
   uv pip install -e ".[devel]"
   ```

6. **For frontend development**, run the watch mode to automatically rebuild on changes:
   ```sh
   cd streamlit_dateinput_intl/frontend
   npm run dev
   ```

Now you're ready to develop! The package is installed in editable mode, so Python changes will be picked up automatically. For frontend changes, either run `npm run dev` in watch mode or manually rebuild with `npm run build` when needed.

## Usage instructions

```python
import streamlit as st

from streamlit_dateinput_intl import streamlit_dateinput_intl

value = streamlit_dateinput_intl()

st.write(value)
```

## Build a wheel

To package this component for distribution:

1. Build the frontend assets (from `streamlit_dateinput_intl/frontend`):

   ```sh
   npm i
   npm run build
   ```

2. Build the Python wheel using UV (from the project root):
   ```sh
   uv build
   ```

This will create a `dist/` directory containing your wheel. The wheel includes the compiled frontend from `streamlit_dateinput_intl/frontend/build`.

### Requirements

- Python >= 3.10
- Node.js >= 24 (LTS)

### Expected output

- `dist/streamlit_dateinput_intl-0.0.1-py3-none-any.whl`
- If you run `uv run --with build python -m build` (without `--wheel`), you’ll also get an sdist: `dist/streamlit-dateinput-intl-0.0.1.tar.gz`
