"""``proxpi`` tests."""
