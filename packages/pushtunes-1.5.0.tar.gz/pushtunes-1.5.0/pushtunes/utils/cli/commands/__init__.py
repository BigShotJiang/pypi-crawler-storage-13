"""CLI command implementations organized by function."""

# Import from the old monolithic commands_old.py module
from pushtunes.utils.cli.commands_old import (
    push_albums,
    push_tracks,
    push_playlist,
    compare_albums,
    compare_tracks,
    compare_playlist,
)

# Import new delete commands from new module structure
from pushtunes.utils.cli.commands.delete import delete_albums, delete_tracks

# Export all commands
__all__ = [
    "push_albums",
    "push_tracks",
    "push_playlist",
    "compare_albums",
    "compare_tracks",
    "compare_playlist",
    "delete_albums",
    "delete_tracks",
]
