from .bot import DDA

__all__ = ['DDA']
```이렇게 하면 사용자는 `from doldol_alarm import DDA` 와 같이 바로 클래스를 가져와 사용할 수 있습니다.

**3. `setup.py` 작성**

```python
from setuptools import setup, find_packages

setup(
    name='doldol_alarm',
    version='0.0.1',
    description='A simple Python package to send messages to a Webex room via a bot.',
    author='Your Name',
    author_email='your_email@example.com',
    url='https://github.com/your_username/doldol_alarm',
    packages=find_packages(),
    install_requires=[
        'webexteamssdk',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)