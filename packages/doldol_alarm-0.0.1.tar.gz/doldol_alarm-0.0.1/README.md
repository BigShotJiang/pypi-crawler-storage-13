# doldol_alert

`doldol_alert`는 Webex 봇을 통해 지정된 Webex 대화방으로 간단하게 메시지를 보낼 수 있도록 도와주는 파이썬 패키지입니다. 코드 실행 중 특정 시점에 알림을 받거나, 로그를 보내는 등의 용도로 활용할 수 있습니다.

## 주요 기능

*   간단한 코드로 Webex 대화방에 메시지 전송
*   클래스 객체를 함수처럼 호출하여 직관적인 사용 가능
*   Webex 봇 토큰을 환경 변수로 안전하게 관리

## 설치하기

PyPI를 통해 쉽게 설치할 수 있습니다.

```bash
pip install doldol_alert
```

## 사전 준비

이 패키지를 사용하기 위해서는 두 가지 정보가 필요합니다.

1.  **Webex 룸 ID (Room ID)**
    *   봇이 메시지를 보낼 대상 대화방의 고유 ID입니다.
    *   봇을 해당 대화방에 초대한 후, [Webex API](https://developer.webex.com/docs/api/v1/rooms/list-rooms) 등을 통해 확인할 수 있습니다.


## 사용 방법

아래는 `doldol_alert`를 사용하여 Webex 대화방으로 메시지를 보내는 예제 코드입니다.

```python
from doldol_alert import DDA

# 메시지를 보낼 Webex Room ID
MY_WEBEX_ROOM_ID = "여기에_메시지를_보낼_방의_ID를_입력하세요"

# 1. (권장) 환경변수에 설정된 봇 토큰을 사용하는 방법
#    DoldolAlert 객체를 생성합니다.
doldol_print = DDA(roomid=MY_WEBEX_ROOM_ID)

# 2. 봇 토큰을 직접 파라미터로 전달하는 방법
# MY_WEBEX_BOT_TOKEN = "여기에_봇_액세스_토큰을_입력하세요"
# doldol_print = doldol_alert.DoldolAlert(roomid=MY_WEBEX_ROOM_ID, webex_bot_token=MY_WEBEX_BOT_TOKEN)


# 이제 객체를 함수처럼 호출하여 메시지를 보낼 수 있습니다.
try:
    print("Webex로 알림을 보냅니다.")
    doldol_print("🚀 작업이 시작되었습니다.")

    # ... (여기에 원하는 작업을 수행하는 코드를 작성) ...
    result = 100 / 5
    doldol_print(f"✔️ 작업이 성공적으로 완료되었습니다. 결과: {result}")

except Exception as e:
    # 예외 발생 시 Webex로 에러 메시지 보내기
    doldol_print(f"🚨 에러가 발생했습니다: {e}")

```

## 라이선스

이 프로젝트는 MIT 라이선스를 따릅니다. 자세한 내용은 `LICENSE` 파일을 참고하세요.