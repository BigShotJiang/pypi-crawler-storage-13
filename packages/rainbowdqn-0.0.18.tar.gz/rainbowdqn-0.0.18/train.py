from rainbowdqn import Agent

agent = Agent(environment="ALE/Pong-v5")
data = agent.loop(verbose=True)

print(data.loss, data.hns, data.rewards)
