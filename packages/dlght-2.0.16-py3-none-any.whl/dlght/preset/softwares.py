SOFTWARE_CONFIG = {
    "v2rayN": {
        "url": "https://github.com/2dust/v2rayN",
        "default_version": "7.15.7",
        "default_files": [
            "v2rayN-windows-64-desktop.zip",
            "v2rayN-windows-64-SelfContained.zip",
            "v2rayN-linux-64.deb",
            "v2rayN-linux-rhel-x64.rpm",
            "v2rayN-macos-64.zip",
            "v2rayN-macos-arm64.zip",
        ],
    },
    "clash-verge": {
        "url": "https://github.com/clash-verge-rev/clash-verge-rev",
        "default_version": "v2.4.3",
        "default_files": [
            "Clash.Verge_2.4.3_x64-setup.exe",
            "Clash.Verge_2.4.3_aarch64.dmg",
            "Clash.Verge_2.4.3_amd64.deb",
            "Clash.Verge-2.4.3-1.x86_64.rpm",
        ],
    },
    "uv": {
        "url": "https://github.com/astral-sh/uv",
        "default_version": "0.9.10",
        "default_files": [
            "uv-installer.ps1",
            "uv-installer.sh",
            "uv-x86_64-pc-windows-msvc.zip",
            "uv-i686-unknown-linux-gnu.tar.gz",
        ],
    },
    "v2rayng": {
        "url": "https://github.com/2dust/v2rayNG",
        "default_version": "1.10.28",
        "default_files": [
            "v2rayNG_1.10.28_arm64-v8a.apk",
            "v2rayNG_1.10.28_universal.apk",
            "v2rayNG_1.10.28_x86.apk",
            "v2rayNG_1.10.28_x86_64.apk",
        ]
    },
    "ClashMetaForAndroid": {
        "url":"https://github.com/MetaCubeX/ClashMetaForAndroid",
        "default_version":"v2.11.19",
        "default_files":[
            "cmfa-2.11.19-meta-universal-release.apk",
            "cmfa-2.11.19-meta-x86-release.apk",
            "cmfa-2.11.19-meta-x86_64-release.apk",
        ]
    }
}
