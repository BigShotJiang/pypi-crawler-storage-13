from __future__ import annotations
from typing import Tuple, Optional, Dict

import weakref
import numpy as np
from scipy.signal import fftconvolve

from .core import PPP, Window, MaskWindow, Image


def _ensure_increasing_r(r: np.ndarray) -> np.ndarray:
    """
    Validate a 1D array of strictly increasing positive radii.

    :param r: Radii array.
    :type r: numpy.ndarray
    :return: Validated radii array.
    :rtype: numpy.ndarray
    :raises ValueError: If not 1D, empty, non-finite, non-positive, or not strictly increasing.
    """
    r = np.asarray(r, float)
    if r.ndim != 1 or r.size == 0:
        raise ValueError("r must be a non-empty 1D array of radii.")
    if not np.all(np.isfinite(r)) or np.any(r <= 0):
        raise ValueError("r must be positive and finite.")
    if np.any(np.diff(r) <= 0):
        raise ValueError("r must be strictly increasing.")
    return r


def _pairs_within(xy: np.ndarray, r_max: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Enumerate unordered pairs of points with separation < r_max.

    :param xy: Point coordinates, shape (n, 2).
    :type xy: numpy.ndarray
    :param r_max: Maximum pair separation.
    :type r_max: float
    :return: Tuple (i, j, d) with indices and distances for each qualifying pair.
    :rtype: Tuple[numpy.ndarray, numpy.ndarray, numpy.ndarray]
    :raises RuntimeError: If SciPy is not installed.
    """
    from scipy.spatial import cKDTree
    tree = cKDTree(xy)
    try:
        pairs = tree.query_pairs(r_max, output_type="ndarray")
    except TypeError:
        pairs_set = tree.query_pairs(r_max)
        if not pairs_set:
            return np.empty(0, int), np.empty(0, int), np.empty(0, float)
        pairs = np.asarray(list(pairs_set), dtype=np.intp).reshape(-1, 2)
    if pairs.size == 0:
        return np.empty(0, int), np.empty(0, int), np.empty(0, float)
    i = pairs[:, 0]
    j = pairs[:, 1]
    diff = xy[j] - xy[i]
    d = np.sqrt((diff * diff).sum(axis=1))
    return i, j, d


class _MaskTransWeights:
    """
    Overlap fractions for all integer pixel shifts via FFT, with bilinear interpolation
    to arbitrary sub-pixel world shifts. Supports fast vectorised queries.
    """

    def __init__(self, win: MaskWindow) -> None:
        """
        Precompute correlation map and normalise by area.

        :param win: MaskWindow instance.
        :type win: MaskWindow
        """
        m = win.mask.astype(float)
        corr = fftconvolve(m, m[::-1, ::-1], mode="full")
        denom = float(np.count_nonzero(m))
        self._frac = (corr / denom) if denom > 0.0 else np.zeros_like(corr, float)
        self._H, self._W = self._frac.shape
        self._ny, self._nx = m.shape
        self._x0 = self._nx - 1  # zero-shift column index
        self._y0 = self._ny - 1  # zero-shift row index
        self._sx, self._sy = win.spacing

    def _gather(self, ix: np.ndarray, iy: np.ndarray) -> np.ndarray:
        """
        Fetch overlap fractions at integer-offset indices.

        :param ix: Integer x-offsets (relative to zero-shift).
        :type ix: numpy.ndarray
        :param iy: Integer y-offsets (relative to zero-shift).
        :type iy: numpy.ndarray
        :return: Overlap fractions.
        :rtype: numpy.ndarray
        """
        ix = ix + self._x0
        iy = iy + self._y0
        ix = np.clip(ix, 0, self._W - 1, out=ix)
        iy = np.clip(iy, 0, self._H - 1, out=iy)
        return self._frac[iy, ix]

    def frac_many(self, delta: np.ndarray) -> np.ndarray:
        """
        Bilinear interpolation of overlap fraction at world shifts.

        :param delta: Array of shifts (m, 2) in world units.
        :type delta: numpy.ndarray
        :return: Overlap fractions (m,).
        :rtype: numpy.ndarray
        """
        dx = delta[:, 0] / self._sx
        dy = delta[:, 1] / self._sy
        mx = np.floor(dx).astype(np.int64); fx = dx - mx
        my = np.floor(dy).astype(np.int64); fy = dy - my
        w00 = (1.0 - fx) * (1.0 - fy)
        w10 = fx * (1.0 - fy)
        w01 = (1.0 - fx) * fy
        w11 = fx * fy
        v00 = self._gather(mx,     my)
        v10 = self._gather(mx + 1, my)
        v01 = self._gather(mx,     my + 1)
        v11 = self._gather(mx + 1, my + 1)
        return w00 * v00 + w10 * v10 + w01 * v01 + w11 * v11


# Cache the FFT-based map per MaskWindow
_MTW_CACHE: "weakref.WeakKeyDictionary[MaskWindow, _MaskTransWeights]" = weakref.WeakKeyDictionary()


class _TranslationCache:
    """
    Provide translation edge-correction weights w = 1 / overlap_fraction(shift).

    Uses an FFT-accelerated path for MaskWindow. Other window types fall back to
    exact overlap_fraction calls with a small memoised cache.
    """

    def __init__(self, win: Window) -> None:
        """
        :param win: Study window.
        :type win: Window
        """
        self._win = win
        self._maskw = None
        if isinstance(win, MaskWindow):
            mtw = _MTW_CACHE.get(win)
            if mtw is None:
                mtw = _MaskTransWeights(win)
                _MTW_CACHE[win] = mtw
            self._maskw = mtw
        self._fallback: Dict[Tuple[float, float], float] = {}

    def weights_many(self, deltas: np.ndarray) -> np.ndarray:
        """
        Compute weights for many shifts.

        :param deltas: Shifts (m, 2) in world units.
        :type deltas: numpy.ndarray
        :return: Weights (m,), with ``inf`` where overlap is zero.
        :rtype: numpy.ndarray
        """
        if self._maskw is not None:
            frac = self._maskw.frac_many(deltas)
            with np.errstate(divide="ignore"):
                w = 1.0 / np.maximum(frac, 1e-15)
            return w
        # Fallback: memoise on rounded deltas
        keys = np.round(deltas, 9)
        out = np.empty(deltas.shape[0], float)
        for k in range(deltas.shape[0]):
            key = (float(keys[k, 0]), float(keys[k, 1]))
            val = self._fallback.get(key)
            if val is None:
                frac = self._win.overlap_fraction(key)
                val = np.inf if frac <= 0.0 else (1.0 / float(frac))
                self._fallback[key] = val
            out[k] = val
        return out


def _distance_to_boundary_at_points(img: Image, xy: np.ndarray) -> np.ndarray:
    """
    Sample a distance image at arbitrary points by nearest cell.

    :param img: Distance-to-boundary image.
    :type img: Image
    :param xy: Query points (n, 2).
    :type xy: numpy.ndarray
    :return: Distances at each query point.
    :rtype: numpy.ndarray
    """
    x0, y0 = img.origin
    sx, sy = img.spacing
    ny, nx = img.values.shape
    ix = np.floor((xy[:, 0] - x0) / sx).astype(int)
    iy = np.floor((xy[:, 1] - y0) / sy).astype(int)
    ix = np.clip(ix, 0, nx - 1)
    iy = np.clip(iy, 0, ny - 1)
    return img.values[iy, ix]


def Kest(ppp: PPP, r: np.ndarray, *, correction: str = "translation") -> np.ndarray:
    """
    Ripley's K-function estimator.

    :param ppp: Point pattern.
    :type ppp: PPP
    :param r: Radii at which to estimate K(r); strictly increasing and positive.
    :type r: numpy.ndarray
    :param correction: Edge correction; ``"translation"`` or ``"border"``.
    :type correction: str
    :return: Estimates of K(r) at each radius.
    :rtype: numpy.ndarray
    :raises ValueError: If ``correction`` is unrecognised.
    """
    r = _ensure_increasing_r(r)
    n = len(ppp)
    if n < 2:
        return np.zeros_like(r)

    win = ppp.window
    area = win.area()
    xy = ppp.xy
    r_max = float(r[-1])

    if correction == "translation":
        i, j, d = _pairs_within(xy, r_max)
        if d.size == 0:
            return np.zeros_like(r)
        cache = _TranslationCache(win)
        deltas = xy[j] - xy[i]
        w = 2.0 * cache.weights_many(deltas)
        hist, _ = np.histogram(d, bins=np.concatenate(([0.0], r)), weights=w)
        csum = np.cumsum(hist)
        return (area / (n * (n - 1))) * csum

    elif correction == "border":
        dtb_img = win.distance_to_boundary()
        db = _distance_to_boundary_at_points(dtb_img, xy)

        from scipy.spatial import cKDTree
        tree = cKDTree(xy)
        K = np.empty_like(r)
        for k, rk in enumerate(r):
            anchors = np.where(db >= rk)[0]
            m = anchors.size
            if m == 0:
                K[k] = np.nan
                continue
            lens = tree.query_ball_point(xy[anchors], rk, return_length=True)
            total = int(np.sum(lens)) - m
            K[k] = (area / (m * n)) * total
        return K

    else:
        raise ValueError(f"Unknown correction '{correction}'")


def Lest(ppp: PPP, r: np.ndarray, *, correction: str = "translation") -> np.ndarray:
    """
    Besag's L-function, ``L(r) = sqrt(K(r) / pi)``.

    :param ppp: Point pattern.
    :type ppp: PPP
    :param r: Radii at which to estimate L(r); strictly increasing and positive.
    :type r: numpy.ndarray
    :param correction: Edge correction; ``"translation"`` or ``"border"``.
    :type correction: str
    :return: Estimates of L(r) at each radius.
    :rtype: numpy.ndarray
    """
    K = Kest(ppp, r, correction=correction)
    return np.sqrt(K / np.pi)


def pcf(ppp: PPP, r_edges: np.ndarray, *, correction: str = "translation") -> Tuple[np.ndarray, np.ndarray]:
    """
    Pair correlation function via annular binning.

    :param ppp: Point pattern.
    :type ppp: PPP
    :param r_edges: Bin edges (strictly increasing, positive), shape (B+1,).
    :type r_edges: numpy.ndarray
    :param correction: Edge correction; ``"translation"`` or ``"border"``.
    :type correction: str
    :return: Tuple ``(r_mid, g)`` with bin midpoints and estimated pcf values.
    :rtype: Tuple[numpy.ndarray, numpy.ndarray]
    :raises ValueError: If bin edges are invalid or ``correction`` is unrecognised.
    """
    r_edges = np.asarray(r_edges, float)
    if r_edges.ndim != 1 or r_edges.size < 2 or np.any(np.diff(r_edges) <= 0) or np.any(r_edges <= 0):
        raise ValueError("r_edges must be strictly increasing and positive.")
    n = len(ppp)
    centres = 0.5 * (r_edges[:-1] + r_edges[1:])
    if n < 2:
        return centres, np.zeros_like(centres)

    win = ppp.window
    area = win.area()
    xy = ppp.xy
    r_max = float(r_edges[-1])

    if correction == "translation":
        i, j, d = _pairs_within(xy, r_max)
        if d.size == 0:
            return centres, np.zeros_like(centres)
        cache = _TranslationCache(win)
        deltas = xy[j] - xy[i]
        w = 2.0 * cache.weights_many(deltas)
        counts, _ = np.histogram(d, bins=r_edges, weights=w)
        ann = np.pi * (r_edges[1:] ** 2 - r_edges[:-1] ** 2)
        g = (area / (n * (n - 1))) * (counts / ann)
        return centres, g

    elif correction == "border":
        dtb_img = win.distance_to_boundary()
        db = _distance_to_boundary_at_points(dtb_img, xy)
        from scipy.spatial import cKDTree
        tree = cKDTree(xy)
        g = np.empty_like(centres)
        for b, (lo, hi) in enumerate(zip(r_edges[:-1], r_edges[1:])):
            anchors = np.where(db >= hi)[0]
            m = anchors.size
            if m == 0:
                g[b] = np.nan
                continue
            len_hi = tree.query_ball_point(xy[anchors], hi, return_length=True)
            if lo > 0.0:
                len_lo = tree.query_ball_point(xy[anchors], lo, return_length=True)
            else:
                len_lo = np.zeros_like(len_hi)
            counts = int(np.sum(len_hi)) - int(np.sum(len_lo))
            ann = np.pi * (hi * hi - lo * lo)
            g[b] = (area / (m * n)) * (counts / ann)
        return centres, g

    else:
        raise ValueError("correction must be 'translation' or 'border'")


def Gest(ppp: PPP, r: np.ndarray, *, method: str = "border") -> np.ndarray:
    """
    Nearest-neighbour distribution ``G(r)``.

    :param ppp: Point pattern.
    :type ppp: PPP
    :param r: Radii at which to evaluate; strictly increasing and positive.
    :type r: numpy.ndarray
    :param method: ``'border'`` (restrict to points with distance-to-boundary ≥ r)
                   or ``'raw'`` (empirical CDF, biased).
    :type method: str
    :return: Estimates of ``G(r)`` in ``[0, 1]`` (``nan`` where undefined for border).
    :rtype: numpy.ndarray
    :raises ValueError: If ``method`` is unrecognised.
    """
    r = _ensure_increasing_r(r)
    n = len(ppp)
    if n == 0:
        return np.zeros_like(r)
    d1 = ppp.nndist(1)
    if method == "raw":
        return np.searchsorted(np.sort(d1), r, side="right") / float(n)
    elif method == "border":
        dtb = _distance_to_boundary_at_points(ppp.window.distance_to_boundary(), ppp.xy)
        G = np.empty_like(r)
        for k, rk in enumerate(r):
            ok = dtb >= rk
            m = np.count_nonzero(ok)
            if m == 0:
                G[k] = np.nan
            else:
                G[k] = np.count_nonzero(d1[ok] <= rk) / float(m)
        return G
    else:
        raise ValueError("method must be 'border' or 'raw'")


def Fest(ppp: PPP, r: np.ndarray, *, nsamp: Optional[int] = None, method: str = "border",
         rng: Optional[np.random.Generator] = None) -> np.ndarray:
    """
    Empty-space function ``F(r)`` via Monte Carlo sampling over the window.

    :param ppp: Point pattern.
    :type ppp: PPP
    :param r: Radii at which to evaluate; strictly increasing and positive.
    :type r: numpy.ndarray
    :param nsamp: Number of random locations; default ``max(1000, 25 * max(1, n))``.
    :type nsamp: Optional[int]
    :param method: ``'border'`` (restrict to locations with distance-to-boundary ≥ r)
                   or ``'raw'`` (empirical CDF at sampled locations, biased).
    :type method: str
    :param rng: Random generator or seed.
    :type rng: Optional[numpy.random.Generator]
    :return: Estimates of ``F(r)`` in ``[0, 1]`` (``nan`` where undefined for border).
    :rtype: numpy.ndarray
    :raises ValueError: If ``method`` is unrecognised.
    """
    r = _ensure_increasing_r(r)
    win = ppp.window
    xy = ppp.xy
    n = len(ppp)

    if nsamp is None:
        nsamp = max(1000, 25 * max(1, n))
    rng = rng if isinstance(rng, np.random.Generator) else np.random.default_rng(rng)

    u = win.sample_uniform(nsamp, rng=rng)

    if n == 0:
        return np.zeros_like(r)

    from scipy.spatial import cKDTree
    tree = cKDTree(xy)
    d_u, _ = tree.query(u, k=1)

    if method == "raw":
        return np.searchsorted(np.sort(d_u), r, side="right") / float(nsamp)
    elif method == "border":
        dtb_u = _distance_to_boundary_at_points(win.distance_to_boundary(), u)
        F = np.empty_like(r)
        for k, rk in enumerate(r):
            ok = dtb_u >= rk
            m = np.count_nonzero(ok)
            if m == 0:
                F[k] = np.nan
            else:
                F[k] = np.count_nonzero(d_u[ok] <= rk) / float(m)
        return F
    else:
        raise ValueError("method must be 'border' or 'raw'")


def Jest(ppp: PPP, r: np.ndarray, *, method_G: str = "border", method_F: str = "border",
         nsamp_F: Optional[int] = None, rng: Optional[np.random.Generator] = None) -> np.ndarray:
    """
    Function ``J(r) = (1 - G(r)) / (1 - F(r))``.

    :param ppp: Point pattern.
    :type ppp: PPP
    :param r: Radii at which to evaluate; strictly increasing and positive.
    :type r: numpy.ndarray
    :param method_G: Method for ``G`` (``'border'`` or ``'raw'``).
    :type method_G: str
    :param method_F: Method for ``F`` (``'border'`` or ``'raw'``).
    :type method_F: str
    :param nsamp_F: Number of samples for ``F`` (if ``None``, uses ``Fest`` default).
    :type nsamp_F: Optional[int]
    :param rng: Random generator or seed (passed to ``Fest``).
    :type rng: Optional[numpy.random.Generator]
    :return: ``J(r)`` with ``nan`` where undefined (division by zero).
    :rtype: numpy.ndarray
    """
    G = Gest(ppp, r, method=method_G)
    F = Fest(ppp, r, nsamp=nsamp_F, method=method_F, rng=rng)
    with np.errstate(invalid="ignore", divide="ignore"):
        J = (1.0 - G) / (1.0 - F)
    return J
