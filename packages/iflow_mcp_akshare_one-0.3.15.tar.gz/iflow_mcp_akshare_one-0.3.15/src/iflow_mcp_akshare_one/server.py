#!/usr/bin/env python3
"""
AKShare One MCP Server

A Model Context Protocol server for AKShare One, providing unified access to Chinese financial market data.
"""

import asyncio
import json
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from . import (
    get_basic_info,
    get_hist_data,
    get_realtime_data,
    get_news_data,
    get_balance_sheet,
    get_income_statement,
    get_cash_flow,
    get_financial_metrics,
    get_inner_trade_data,
)


# Create the server instance
server = Server("akshare-one-mcp")


@server.list_tools()
async def handle_list_tools() -> list[Tool]:
    """List available tools."""
    return [
        Tool(
            name="get_basic_info",
            description="Get basic information for a stock symbol",
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol": {
                        "type": "string",
                        "description": "Stock symbol (e.g., '600000')"
                    },
                    "source": {
                        "type": "string",
                        "enum": ["eastmoney"],
                        "default": "eastmoney",
                        "description": "Data source"
                    }
                },
                "required": ["symbol"]
            }
        ),
        Tool(
            name="get_hist_data",
            description="Get historical market data for a stock symbol",
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol": {
                        "type": "string",
                        "description": "Stock symbol (e.g., '600000')"
                    },
                    "interval": {
                        "type": "string",
                        "enum": ["minute", "hour", "day", "week", "month", "year"],
                        "default": "day",
                        "description": "Time interval"
                    },
                    "interval_multiplier": {
                        "type": "integer",
                        "default": 1,
                        "description": "Interval multiplier (e.g., 5 for 5 minutes)"
                    },
                    "start_date": {
                        "type": "string",
                        "default": "1970-01-01",
                        "description": "Start date (YYYY-MM-DD)"
                    },
                    "end_date": {
                        "type": "string",
                        "default": "2030-12-31",
                        "description": "End date (YYYY-MM-DD)"
                    },
                    "adjust": {
                        "type": "string",
                        "enum": ["none", "qfq", "hfq"],
                        "default": "none",
                        "description": "Adjustment type"
                    },
                    "source": {
                        "type": "string",
                        "enum": ["eastmoney", "eastmoney_direct", "sina"],
                        "default": "eastmoney_direct",
                        "description": "Data source"
                    }
                },
                "required": ["symbol"]
            }
        ),
        Tool(
            name="get_realtime_data",
            description="Get real-time market quotes for a stock symbol",
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol": {
                        "type": "string",
                        "description": "Stock symbol (e.g., '600000')"
                    },
                    "source": {
                        "type": "string",
                        "enum": ["eastmoney", "eastmoney_direct", "xueqiu"],
                        "default": "eastmoney_direct",
                        "description": "Data source"
                    }
                },
                "required": ["symbol"]
            }
        ),
        Tool(
            name="get_news_data",
            description="Get news data for a stock symbol",
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol": {
                        "type": "string",
                        "description": "Stock symbol (e.g., '300059')"
                    },
                    "source": {
                        "type": "string",
                        "enum": ["eastmoney"],
                        "default": "eastmoney",
                        "description": "Data source"
                    }
                },
                "required": ["symbol"]
            }
        ),
        Tool(
            name="get_balance_sheet",
            description="Get balance sheet data for a stock symbol",
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol": {
                        "type": "string",
                        "description": "Stock symbol (e.g., '600600')"
                    },
                    "source": {
                        "type": "string",
                        "enum": ["sina"],
                        "default": "sina",
                        "description": "Data source"
                    }
                },
                "required": ["symbol"]
            }
        ),
        Tool(
            name="get_income_statement",
            description="Get income statement data for a stock symbol",
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol": {
                        "type": "string",
                        "description": "Stock symbol (e.g., '600600')"
                    },
                    "source": {
                        "type": "string",
                        "enum": ["sina"],
                        "default": "sina",
                        "description": "Data source"
                    }
                },
                "required": ["symbol"]
            }
        ),
        Tool(
            name="get_cash_flow",
            description="Get cash flow data for a stock symbol",
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol": {
                        "type": "string",
                        "description": "Stock symbol (e.g., '600600')"
                    },
                    "source": {
                        "type": "string",
                        "enum": ["sina"],
                        "default": "sina",
                        "description": "Data source"
                    }
                },
                "required": ["symbol"]
            }
        ),
        Tool(
            name="get_financial_metrics",
            description="Get financial metrics data for a stock symbol",
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol": {
                        "type": "string",
                        "description": "Stock symbol (e.g., '600600')"
                    },
                    "source": {
                        "type": "string",
                        "enum": ["eastmoney_direct"],
                        "default": "eastmoney_direct",
                        "description": "Data source"
                    }
                },
                "required": ["symbol"]
            }
        ),
        Tool(
            name="get_inner_trade_data",
            description="Get insider trading data for a stock symbol",
            inputSchema={
                "type": "object",
                "properties": {
                    "symbol": {
                        "type": "string",
                        "description": "Stock symbol (e.g., '600000')"
                    },
                    "source": {
                        "type": "string",
                        "enum": ["xueqiu"],
                        "default": "xueqiu",
                        "description": "Data source"
                    }
                },
                "required": ["symbol"]
            }
        )
    ]


@server.call_tool()
async def handle_call_tool(name: str, arguments: dict[str, Any] | None) -> list[TextContent]:
    """Handle tool calls."""
    if arguments is None:
        arguments = {}

    try:
        if name == "get_basic_info":
            result = get_basic_info(
                symbol=arguments["symbol"],
                source=arguments.get("source", "eastmoney")
            )
        elif name == "get_hist_data":
            result = get_hist_data(
                symbol=arguments["symbol"],
                interval=arguments.get("interval", "day"),
                interval_multiplier=arguments.get("interval_multiplier", 1),
                start_date=arguments.get("start_date", "1970-01-01"),
                end_date=arguments.get("end_date", "2030-12-31"),
                adjust=arguments.get("adjust", "none"),
                source=arguments.get("source", "eastmoney_direct")
            )
        elif name == "get_realtime_data":
            result = get_realtime_data(
                symbol=arguments["symbol"],
                source=arguments.get("source", "eastmoney_direct")
            )
        elif name == "get_news_data":
            result = get_news_data(
                symbol=arguments["symbol"],
                source=arguments.get("source", "eastmoney")
            )
        elif name == "get_balance_sheet":
            result = get_balance_sheet(
                symbol=arguments["symbol"],
                source=arguments.get("source", "sina")
            )
        elif name == "get_income_statement":
            result = get_income_statement(
                symbol=arguments["symbol"],
                source=arguments.get("source", "sina")
            )
        elif name == "get_cash_flow":
            result = get_cash_flow(
                symbol=arguments["symbol"],
                source=arguments.get("source", "sina")
            )
        elif name == "get_financial_metrics":
            result = get_financial_metrics(
                symbol=arguments["symbol"],
                source=arguments.get("source", "eastmoney_direct")
            )
        elif name == "get_inner_trade_data":
            result = get_inner_trade_data(
                symbol=arguments["symbol"],
                source=arguments.get("source", "xueqiu")
            )
        else:
            raise ValueError(f"Unknown tool: {name}")

        # Convert DataFrame to JSON string
        result_json = result.to_json(orient="records", date_format="iso")
        return [TextContent(type="text", text=result_json)]

    except Exception as e:
        error_msg = f"Error calling {name}: {str(e)}"
        return [TextContent(type="text", text=error_msg)]


async def main():
    """Main entry point."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


def run_server():
    """Entry point for the CLI command."""
    asyncio.run(main())


if __name__ == "__main__":
    run_server()