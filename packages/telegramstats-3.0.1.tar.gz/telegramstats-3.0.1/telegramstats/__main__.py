import collections
import pathlib
import pickle
from typing import BinaryIO

import click

from .parse import Chat


@click.group()
@click.version_option(package_name="telegramstats", prog_name="telegramstats")
@click.pass_context
def telegramstats(ctx: click.Context):
    """
    Get interesting stats from Telegram chat exports.
    """

    ctx.max_content_width = 10000
    ctx.show_default = True


argument_export_path = click.argument(
    "export_path",
    nargs=-1,
    type=click.Path(
        exists=True,
        file_okay=True,
        dir_okay=True,
        allow_dash=True,
        path_type=pathlib.Path,
    ),
)


@telegramstats.group()
def single():
    """
    Process single-chat Telegram GDPR exports.
    """
    pass


@single.command()
@argument_export_path
def counts_by_user(
    export_path: list[pathlib.Path],
):
    """
    Get cumulative message counts for each user in the given chats.
    """

    chats: list[Chat] = []
    with click.progressbar(export_path, label="Parsing JSON") as paths:
        for path in paths:
            if path.is_dir():
                path = path / "result.json"
            chat = Chat.from_singlechat_export(path)
            chats.append(chat)

    counts = collections.defaultdict(lambda: 0)
    ids = collections.defaultdict(set)

    for chat in chats:
        with click.progressbar(chat.messages, label=chat.name) as messages:
            for message in messages:
                if not message.from_id:
                    continue
                counts[message.from_id] += 1
                ids[message.from_id].add(message.from_)

    for actor_id, count in sorted(counts.items(), key=lambda item: item[1], reverse=True):
        valid_aliases = []
        for alias in ids[actor_id]:
            if alias is None:
                continue
            valid_aliases.append(alias)

        if len(valid_aliases) == 0:
            displayed_aliases = f"Deleted account ({actor_id})"
        else:
            displayed_aliases = " / ".join(valid_aliases)

        click.echo(
            click.style(f"{count}", bold=True) +
            "\t" +
            click.style(displayed_aliases, italic=True),
        )


try:
    import markovify
except ImportError:
    markovify = None
else:
    @single.command()
    @argument_export_path
    @click.option(
        "-o", "--output-file", "output_file",
        type=click.File("wb"),
        required=True,
        help="The .pickle file to store the generated Markovify model in."
    )
    @click.option(
        "--state-size", "state_size",
        type=int,
        default=1,
        help="The state size of the Markov chain (how many previous words are kept in consideration when generating a new one)."
    )
    @click.option(
        "--preview-size", "preview_size",
        type=int,
        default=10,
        help="The number of preview sentences to generate at the end of the process."
    )
    def markovify_chain(
        export_path: list[pathlib.Path],
        output_file: BinaryIO,
        state_size: int = 1,
        preview_size: int = 10,
    ):
        """
        Create a Markovify model from all messages in the given chats.
        """
        chats: list[Chat] = []
        with click.progressbar(export_path, label="Parsing JSON") as paths:
            for path in paths:
                if path.is_dir():
                    path = path / "result.json"
                chat = Chat.from_singlechat_export(path)
                chats.append(chat)

        corpus = []

        for chat in chats:
            with click.progressbar(chat.messages, label=chat.name) as messages:
                for message in messages:
                    if isinstance(message.text, str):
                        text = message.text
                    elif isinstance(message.text, list):
                        text = []
                        for piece in message.text:
                            if isinstance(piece, str):
                                text.append(piece)
                            elif isinstance(piece, dict) and "text" in piece:
                                text.append(piece["text"])
                            else:
                                # explicit continue for clarity
                                continue
                        text = "".join(text)
                    else:
                        continue
                    raw_tokens = text.split()
                    filtered_tokens = filter(bool, raw_tokens)
                    tokens = list(filtered_tokens)
                    corpus.append(tokens)

        chain = markovify.Chain(corpus, state_size=state_size)

        click.secho("Model preview", bold=True)

        padding = len(str(preview_size))

        for n in range(1, preview_size + 1):
            tokens = chain.gen()
            message = " ".join(tokens)
            click.echo(
                click.style(f"{n: >{padding}} | ", bold=True) +
                click.style(message, italic=True),
            )

        # SupportsWrite[bytes] and BinaryIO are the same thing
        # noinspection PyTypeChecker
        pickle.dump(chain, output_file)

if __name__ == "__main__":
    telegramstats()
