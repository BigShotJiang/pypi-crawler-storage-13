# VAULT PASSWORD MANAGER

Broglio Matteo - \
Caputo Lorenzo - 894528 \
El Hanafi Nadim - \
Giuggioli Daniel - \
Fuso Valentina - 


## CONFIGURAZIONE

Il codice viene eseguito in un container Docker con l'immagine di Python 3.11, per necessità di compatibilità con la libreria `libsqlcipher-dev`. Ogni job della pipeline è preceduto da uno script, definito nella sezione _before_script_, che si occupa di installare le dipendenze di sistema necessarie per il suo corretto funzionamento. 


##  STAGE BUILD

Punto di partenza della pipeline. Viene inizializzato e attivato l'ambiente di sviluppo virtuale che sarà poi utilizzato negli stage successivi. Prima di installare le dipendenze contenute nel file `requirements.txt`, viene aggiornato pip all'ultima versione disponibile per questioni di compatibilità ed efficienza.

## STAGE VERIFY

Sono eseguite concorrentemente due tipologie di analisi, relative alla qualità del codice e alla sicurezza, riducendo il tempo totale di esecuzione della pipeline

### VERIFY PROSPECTOR

Prospector è uno strumento di analisi della qualità del codice. La configurazione `allow_failure: true` permette alla pipeline di continuare verso gli stage successivi anche se il job termina con un fallimento. SPIEGARE IL PERCHE' DI QUESTA DECISIONE?**esempio: non tutti gli errori sono dello stesso tipo e quindi non richiedono che l'esecuzione della pipeline si arresti**


### VERIFY BANDIT

Bandit sfrutta l'analisi dell'_Abstract Syntax Tree (AST)_ per comprendere la struttura del codice e identificare costrutti potenzialmente pericolosi. SPIEGARE IL PERCHE' DI QUESTA DECISIONE?

## STAGE TEST

In questa parte, viene verificato il corretto funzionamento del codice come previsto attraverso l'esecuzione dei test indicati in `/src/unittest/test_vault.py`. Il plugin Coverage per Pytest (_pytest-cov_) permette di misurare la percentuale di codice effettivamente eseguita durante i test. Al termine, il comando `pytest --cov=. --cov-report=term` genera una tabella nella quale mostra, per ogni file:
- **Stmts:** numero totale di statement, o linee di codice eseguibili
- **Miss:** numero di statement non eseguiti durante i testi
- **Cover:** percentuale di statement coperti.
La configurazione del coverage `/TOTAL.*\s+(\d+%)$/` estra la percentuale di coverage totale.

## PACKAGE

Questo stage trasforma il codice sorgente, verificato e testato, in pacchetti distribuibili e facilmente installabili in altri ambienti

