from .trace_manager import TraceManager
import functools
import time
import traceback

def track_function(name: str = ""):
    """Attach a span to the CURRENT trace manager if exists."""

    def decorator(func):
        func_name = name or func.__name__

        @functools.wraps(func)
        def wrapper(*args, **kwargs):

            active = TraceManager._active   # 🔥 Now guaranteed to exist

            # If no active trace, run without instrumentation
            if active is None:
                return func(*args, **kwargs)

            # Create span
            sid = active.start_span(func_name, input={"args": args, "kwargs": kwargs})
            start = time.time()

            try:
                result = func(*args, **kwargs)
                latency = int((time.time() - start) * 1000)

                active.end_span(
                    sid,
                    output={"status": "success", "output": result, "latency_ms": latency}
                )

                return result

            except Exception as e:
                latency = int((time.time() - start) * 1000)

                active.end_span(
                    sid,
                    output={
                        "status": "error",
                        "error": str(e),
                        "stacktrace": traceback.format_exc(),
                        "latency_ms": latency,
                    },
                )

                raise

        return wrapper
    return decorator
