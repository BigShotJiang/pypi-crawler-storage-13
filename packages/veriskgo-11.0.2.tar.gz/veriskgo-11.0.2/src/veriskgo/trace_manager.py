# src/veriskgo/trace_manager.py
import time
import uuid
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from contextlib import ContextDecorator
from .sqs import send_to_sqs


def _now():
    return datetime.now(timezone.utc).isoformat()


def _id():
    return str(uuid.uuid4())


class TraceManager(ContextDecorator):
    """Automatic trace manager — opens trace, records spans, sends to SQS on exit."""

    _active: "TraceManager | None" = None

    def __init__(self, name: str, metadata: Optional[Dict[str, Any]] = None):
        self.trace_id = _id()
        self.name = name
        self.metadata = metadata or {}
        self.spans: List[Dict[str, Any]] = []
        self.stack = []

    def __enter__(self):
        TraceManager._active = self   # 🔥 Mark as active

        root_id = _id()
        self.root_id = root_id
        self.spans.append({
            "span_id": root_id,
            "parent_span_id": None,
            "name": self.name,
            "type": "root",
            "timestamp": _now(),
            "input": "",
            "output": "",
            "metadata": self.metadata,
            "duration_ms": 0,
        })
        self.stack.append({"span_id": root_id, "start": time.time()})
        return self

    def start_span(self, name: str, input: Any = None) -> str:
        parent = self.stack[-1]["span_id"]
        sid = _id()

        self.spans.append({
            "span_id": sid,
            "parent_span_id": parent,
            "name": name,
            "type": "child",
            "timestamp": _now(),
            "input": input,
            "output": "",
            "metadata": {},
            "duration_ms": 0,
        })
        self.stack.append({"span_id": sid, "start": time.time()})
        return sid

    def end_span(self, sid: str, output: Any = None):
        for i in reversed(range(len(self.stack))):
            if self.stack[i]["span_id"] == sid:
                entry = self.stack.pop(i)
                dur = int((time.time() - entry["start"]) * 1000)
                break
        else:
            return

        for sp in self.spans:
            if sp["span_id"] == sid:
                sp["output"] = output
                sp["duration_ms"] = dur
                return

    def __exit__(self, exc_type, exc, tb):
        # End all spans...
        while self.stack:
            entry = self.stack.pop()
            sid = entry["span_id"]
            dur = int((time.time() - entry["start"]) * 1000)
            for sp in self.spans:
                if sp["span_id"] == sid:
                    sp["duration_ms"] = dur

        # Prepare bundle and send
        bundle = {
            "event": "trace",
            "trace_id": self.trace_id,
            "trace_name": self.name,
            "trace_metadata": self.metadata,
            "spans": self.spans,
        }

        send_to_sqs(bundle)

        # 🔥 Clear active trace
        TraceManager._active = None


def trace(name: str, metadata: Optional[Dict[str, Any]] = None):
    return TraceManager(name, metadata)
