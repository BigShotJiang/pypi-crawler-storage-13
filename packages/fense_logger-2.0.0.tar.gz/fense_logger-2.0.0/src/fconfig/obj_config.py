# config/object_config.py
from .base_config import IBaseConfig


class ObjectConfig(IBaseConfig):
    def __init__(self, config: dict):
        self._config = config

    def load(self) -> dict:
        return self._config
