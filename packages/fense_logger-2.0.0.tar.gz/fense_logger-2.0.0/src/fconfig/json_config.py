# config/json_config.py
import json

from .base_config import IBaseConfig


class JsonConfig(IBaseConfig):
    def __init__(self, file_path="config.json"):
        self.file_path = file_path

    def load(self) -> dict:
        with open(self.file_path, "r") as f:
            return json.load(f)
