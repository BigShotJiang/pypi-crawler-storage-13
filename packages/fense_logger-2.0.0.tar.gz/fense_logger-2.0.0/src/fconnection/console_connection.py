# connections/console_connection.py
import sys

from .base_connection import IBaseConnection


class FConsoleConnection(IBaseConnection):
    """
    Connects to Console
    """

    def connect(self):
        return sys.stdout

    def close(self):
        pass  # nothing to close
