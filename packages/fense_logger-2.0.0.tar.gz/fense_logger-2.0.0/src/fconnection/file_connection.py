# connections/file_connection.py
from logging.handlers import TimedRotatingFileHandler

from .base_connection import IBaseConnection


class FFileConnection(IBaseConnection):
    """
    Creates and manages to Rotating Log file on the local storage
    """

    def __init__(self, path="app.log", when="D", interval=1, backupCount=7):
        self.path = path
        self.when = when
        self.interval = interval
        self.backupCount = backupCount
        self.handler = None

    def connect(self):
        if not self.handler:
            self.handler = TimedRotatingFileHandler(
                self.path,
                when=self.when,
                interval=self.interval,
                backupCount=self.backupCount,
            )
        return self.handler

    def close(self):
        if self.handler:
            self.handler.close()
