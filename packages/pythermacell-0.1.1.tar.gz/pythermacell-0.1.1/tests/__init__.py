"""Tests for pythermacell package."""
