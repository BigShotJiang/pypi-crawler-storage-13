from nexo.schemas.resource import Resource, ResourceIdentifier

CHECKUP_RESOURCE = Resource(
    identifiers=[ResourceIdentifier(key="checkup", name="Checkup", slug="checkups")],
    details=None,
)
