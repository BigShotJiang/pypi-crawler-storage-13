"""Tests for the CML2NetBox CLI."""

import sys
import os
from unittest.mock import patch
from click.testing import CliRunner

# Add the cml2netbox_pkg directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from cml2netbox_pkg.cli import cml2netbox  # noqa: E402


def test_cli_help():
    """Test that the CLI shows help without errors."""
    runner = CliRunner()
    result = runner.invoke(cml2netbox, ["--help"])
    assert result.exit_code == 0
    assert "CML2NetBox - Sync Cisco Modeling Labs with NetBox" in result.output


def test_cli_version():
    """Test that the CLI shows version without errors."""
    runner = CliRunner()
    result = runner.invoke(cml2netbox, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.output


def test_sync_help():
    """Test that the sync command shows help without errors."""
    runner = CliRunner()
    result = runner.invoke(cml2netbox, ["sync", "--help"])
    assert result.exit_code == 0
    assert "Synchronization commands" in result.output


def test_sync_lab_missing_config():
    """Test that the sync lab command fails with missing configuration."""
    runner = CliRunner()
    # Use isolated environment to avoid loading .env file
    with runner.isolated_filesystem():
        result = runner.invoke(
            cml2netbox, ["sync", "lab"], env={}, catch_exceptions=False
        )
        # The exact exit code might vary, but it should show missing config message
        assert (
            "Missing required configuration" in result.output
            or "CML Server:" in result.output
        )


def test_sync_device_types_missing_config():
    """Test that the sync device-types command fails with missing configuration."""
    runner = CliRunner()
    # Use isolated environment to avoid loading .env file
    with runner.isolated_filesystem():
        result = runner.invoke(
            cml2netbox, ["sync", "device-types"], env={}, catch_exceptions=False
        )
        # The exact exit code might vary, but it should show missing config message
        assert (
            "Missing required configuration" in result.output
            or "CML Server:" in result.output
        )


def test_sync_lab_with_config():
    """Test that the sync lab command works with full configuration."""
    runner = CliRunner()
    result = runner.invoke(
        cml2netbox,
        [
            "--cml2-url",
            "https://cml.example.com",
            "--cml2-user",
            "admin",
            "--cml2-pass",
            "password",
            "--netbox-url",
            "https://netbox.example.com",
            "--netbox-api-token",
            "test-token",
            "sync",
            "lab",
            "Test Lab",
        ],
    )
    assert result.exit_code == 0
    assert "Starting lab topology synchronization" in result.output
    assert "CML Server: https://cml.example.com" in result.output
    assert "NetBox Server: https://netbox.example.com" in result.output
    assert "Lab Name: Test Lab" in result.output


def test_sync_device_types_with_config():
    """Test that the sync device-types command works with full configuration."""
    runner = CliRunner()
    result = runner.invoke(
        cml2netbox,
        [
            "--cml2-url",
            "https://cml.example.com",
            "--cml2-user",
            "admin",
            "--cml2-pass",
            "password",
            "--netbox-url",
            "https://netbox.example.com",
            "--netbox-api-token",
            "test-token",
            "sync",
            "device-types",
        ],
    )
    assert result.exit_code == 0
    assert "Starting device types synchronization" in result.output
    assert "CML Server: https://cml.example.com" in result.output
    assert "NetBox Server: https://netbox.example.com" in result.output


def test_config_options_in_help():
    """Test that configuration options appear in the main help."""
    runner = CliRunner()
    result = runner.invoke(cml2netbox, ["--help"])
    assert result.exit_code == 0
    assert "--cml2-url" in result.output
    assert "--netbox-url" in result.output
    assert "--netbox-api-token" in result.output
    # Lab options should not be in main help
    assert "--lab-name" not in result.output
    assert "--lab-id" not in result.output


def test_sync_lab_missing_lab_name():
    """Test that sync lab command fails when lab name is missing."""
    runner = CliRunner()
    result = runner.invoke(
        cml2netbox,
        [
            "--cml2-url",
            "https://cml.example.com",
            "--cml2-user",
            "admin",
            "--cml2-pass",
            "password",
            "--netbox-url",
            "https://netbox.example.com",
            "--netbox-api-token",
            "test-token",
            "sync",
            "lab",
        ],
    )
    assert result.exit_code == 1
    assert "LAB_NAME: CML Lab Name is required" in result.output


def test_sync_lab_with_lab_id():
    """Test that sync lab command works with lab ID option."""
    runner = CliRunner()
    result = runner.invoke(
        cml2netbox,
        [
            "--cml2-url",
            "https://cml.example.com",
            "--cml2-user",
            "admin",
            "--cml2-pass",
            "password",
            "--netbox-url",
            "https://netbox.example.com",
            "--netbox-api-token",
            "test-token",
            "sync",
            "lab",
            "--lab-id",
            "12345",
            "Test Lab",
        ],
    )
    assert result.exit_code == 0
    assert "Lab Name: Test Lab" in result.output
    assert "Lab ID: 12345" in result.output


def test_sync_lab_argument_overrides_option():
    """Test that lab name argument overrides environment variable."""
    runner = CliRunner()
    with patch.dict(os.environ, {"LAB_NAME": "Environment Lab"}):
        result = runner.invoke(
            cml2netbox,
            [
                "--cml2-url",
                "https://cml.example.com",
                "--cml2-user",
                "admin",
                "--cml2-pass",
                "password",
                "--netbox-url",
                "https://netbox.example.com",
                "--netbox-api-token",
                "test-token",
                "sync",
                "lab",
                "Argument Lab",
            ],
        )
    assert result.exit_code == 0
    assert "Lab Name: Argument Lab" in result.output
    assert "Lab Name: Environment Lab" not in result.output


def test_sync_lab_option_overrides_env():
    """Test that lab ID option works with environment variable for lab name."""
    runner = CliRunner()
    with patch.dict(os.environ, {"LAB_NAME": "Environment Lab"}):
        result = runner.invoke(
            cml2netbox,
            [
                "--cml2-url",
                "https://cml.example.com",
                "--cml2-user",
                "admin",
                "--cml2-pass",
                "password",
                "--netbox-url",
                "https://netbox.example.com",
                "--netbox-api-token",
                "test-token",
                "sync",
                "lab",
                "--lab-id",
                "option123",
            ],
        )
    assert result.exit_code == 0
    assert "Lab Name: Environment Lab" in result.output
    assert "Lab ID: option123" in result.output


def test_sync_lab_with_environment_variables():
    """Test that lab command works with LAB_NAME and LAB_ID environment variables."""
    runner = CliRunner()
    with patch.dict(os.environ, {"LAB_NAME": "Env Lab", "LAB_ID": "env123"}):
        result = runner.invoke(
            cml2netbox,
            [
                "--cml2-url",
                "https://cml.example.com",
                "--cml2-user",
                "admin",
                "--cml2-pass",
                "password",
                "--netbox-url",
                "https://netbox.example.com",
                "--netbox-api-token",
                "test-token",
                "sync",
                "lab",
            ],
        )
    assert result.exit_code == 0
    assert "Lab Name: Env Lab" in result.output
    assert "Lab ID: env123" in result.output


def test_sync_lab_help():
    """Test that lab command help shows the correct options."""
    runner = CliRunner()
    result = runner.invoke(cml2netbox, ["sync", "lab", "--help"])
    assert result.exit_code == 0
    assert "--lab-id" in result.output
    assert "LAB_NAME" in result.output  # Should be in the help text
