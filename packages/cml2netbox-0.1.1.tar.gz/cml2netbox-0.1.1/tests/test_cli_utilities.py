"""Tests for the CLI utilities module."""

import os
import sys
from unittest.mock import patch

# Add the cml2netbox_pkg directory to the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from cml2netbox_pkg.cli_utilities import (  # noqa: E402
    get_config_value,
    Config,
)


def test_get_config_value_with_env():
    """Test get_config_value with environment variable."""
    with patch.dict(os.environ, {"TEST_KEY": "test_value"}):
        result = get_config_value("TEST_KEY")
        assert result == "test_value"


def test_get_config_value_with_alt_key():
    """Test get_config_value with alternative key fallback."""
    with patch.dict(os.environ, {"ALT_KEY": "alt_value"}, clear=True):
        result = get_config_value("MISSING_KEY", "ALT_KEY")
        assert result == "alt_value"


def test_get_config_value_with_default():
    """Test get_config_value with default value."""
    with patch.dict(os.environ, {}, clear=True):
        result = get_config_value("MISSING_KEY", default="default_value")
        assert result == "default_value"


def test_get_config_value_ssl_boolean_conversion():
    """Test that SSL verification values are converted to boolean."""
    # Test true values
    for true_val in ["true", "True", "1", "yes", "on"]:
        with patch.dict(os.environ, {"TEST_VERIFY_SSL": true_val}):
            result = get_config_value("TEST_VERIFY_SSL")
            assert result is True

    # Test false values
    for false_val in ["false", "False", "0", "no", "off"]:
        with patch.dict(os.environ, {"TEST_VERIFY_SSL": false_val}):
            result = get_config_value("TEST_VERIFY_SSL")
            assert result is False


def test_config_initialization():
    """Test Config class initialization."""
    test_env = {
        "CML2_URL": "https://cml.test.com",
        "CML2_USER": "testuser",
        "CML2_PASS": "testpass",
        "CML2_VERIFY_SSL": "true",
        "NETBOX_URL": "https://netbox.test.com",
        "NETBOX_API_TOKEN": "test-token",
        "NETBOX_VERIFY_SSL": "false",
    }

    with patch("cml2netbox_pkg.cli_utilities.load_env_file"):
        with patch.dict(os.environ, test_env, clear=True):
            config = Config()
            assert config.cml2_url == "https://cml.test.com"
            assert config.cml2_user == "testuser"
            assert config.cml2_pass == "testpass"
            assert config.cml2_verify_ssl is True
            assert config.netbox_url == "https://netbox.test.com"
            assert config.netbox_api_token == "test-token"
            assert config.netbox_verify_ssl is False


def test_config_virl2_fallback():
    """Test Config class with VIRL2 environment variables."""
    test_env = {
        "VIRL2_URL": "https://virl2.test.com",
        "VIRL2_USER": "virl2user",
        "VIRL2_PASS": "virl2pass",
        "VIRL2_VERIFY_SSL": "false",
    }

    with patch("cml2netbox_pkg.cli_utilities.load_env_file"):
        with patch.dict(os.environ, test_env, clear=True):
            config = Config()
            assert config.cml2_url == "https://virl2.test.com"
            assert config.cml2_user == "virl2user"
            assert config.cml2_pass == "virl2pass"
            assert config.cml2_verify_ssl is False


def test_config_update_from_click_params():
    """Test updating config from Click parameters."""
    config = Config()

    click_params = {
        "cml2_url": "https://new-cml.com",
        "cml2_user": "newuser",
        "netbox_url": "https://new-netbox.com",
        "netbox_api_token": "new-token",
    }

    config.update_from_click_params(**click_params)

    assert config.cml2_url == "https://new-cml.com"
    assert config.cml2_user == "newuser"
    assert config.netbox_url == "https://new-netbox.com"
    assert config.netbox_api_token == "new-token"


def test_config_validation():
    """Test config validation."""
    # Test with missing configuration using patch to override load_env_file
    with patch("cml2netbox_pkg.cli_utilities.load_env_file"):
        with patch.dict(os.environ, {}, clear=True):
            config = Config()
            missing = config.validate()

            expected_missing = {
                "CML2_URL": "CML server URL is required",
                "CML2_USER": "CML username is required",
                "CML2_PASS": "CML password is required",
                "NETBOX_URL": "NetBox server URL is required",
                "NETBOX_API_TOKEN": "NetBox API token is required",
            }

            assert missing == expected_missing

    # Test with complete configuration
    complete_env = {
        "CML2_URL": "https://cml.test.com",
        "CML2_USER": "testuser",
        "CML2_PASS": "testpass",
        "NETBOX_URL": "https://netbox.test.com",
        "NETBOX_API_TOKEN": "test-token",
    }

    with patch("cml2netbox_pkg.cli_utilities.load_env_file"):
        with patch.dict(os.environ, complete_env, clear=True):
            config = Config()
            missing = config.validate()
            assert missing == {}  # No missing configuration


def test_config_validation_with_lab_name():
    """Test config validation with lab name requirement."""
    complete_env = {
        "CML2_URL": "https://cml.test.com",
        "CML2_USER": "testuser",
        "CML2_PASS": "testpass",
        "NETBOX_URL": "https://netbox.test.com",
        "NETBOX_API_TOKEN": "test-token",
    }

    with patch("cml2netbox_pkg.cli_utilities.load_env_file"):
        with patch.dict(os.environ, complete_env, clear=True):
            config = Config()

            # Test validation without requiring lab name
            missing = config.validate(require_lab_name=False)
            assert missing == {}

            # Test validation requiring lab name (should fail)
            missing = config.validate(require_lab_name=True)
            assert "LAB_NAME" in missing
            assert missing["LAB_NAME"] == "CML Lab Name is required"

            # Test with lab name provided
            config.lab_name = "Test Lab"
            missing = config.validate(require_lab_name=True)
            assert missing == {}


def test_config_update_lab_config():
    """Test Config.update_lab_config method."""
    with patch("cml2netbox_pkg.cli_utilities.load_env_file"):
        with patch.dict(
            os.environ, {"LAB_NAME": "Env Lab", "LAB_ID": "env123"}, clear=True
        ):
            config = Config()

            # Lab config should not exist initially
            assert not hasattr(config, "lab_name")
            assert not hasattr(config, "lab_id")

            # Update with CLI parameters
            config.update_lab_config(lab_name="CLI Lab", lab_id="cli123")

            # CLI parameters should override environment variables
            assert config.lab_name == "CLI Lab"
            assert config.lab_id == "cli123"

            # Test with only some parameters provided
            config.update_lab_config(lab_name="New Lab")
            assert config.lab_name == "New Lab"
            assert config.lab_id == "cli123"  # Should remain unchanged


def test_config_ensure_lab_config():
    """Test Config._ensure_lab_config method."""
    with patch("cml2netbox_pkg.cli_utilities.load_env_file"):
        with patch.dict(
            os.environ, {"LAB_NAME": "Env Lab", "LAB_ID": "env123"}, clear=True
        ):
            config = Config()

            # Lab config should not exist initially
            assert not hasattr(config, "lab_name")
            assert not hasattr(config, "lab_id")

            # Ensure lab config loads from environment
            config._ensure_lab_config()

            assert config.lab_name == "Env Lab"
            assert config.lab_id == "env123"
