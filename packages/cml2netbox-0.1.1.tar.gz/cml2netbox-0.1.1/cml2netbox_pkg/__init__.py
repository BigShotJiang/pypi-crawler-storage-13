"""
CML2NetBox - Sync Cisco Modeling Labs with NetBox

A command-line interface for synchronizing Cisco Modeling Labs (CML)
topologies and device types with NetBox.
"""

__version__ = "0.1.1"
__author__ = "Hank Preston"
__email__ = "hank.preston@gmail.com"
