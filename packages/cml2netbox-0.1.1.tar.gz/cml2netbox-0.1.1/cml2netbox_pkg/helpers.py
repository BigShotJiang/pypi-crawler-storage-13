from virl2_client.models import Node
from typing import Dict, Tuple, Any
import re
import logging

logger = logging.getLogger(__name__)


def sanitize_string(string: str) -> str:
    """Remove parentheses and replace dots with underscores in string."""
    return (
        string.replace("(", "")
        .replace(")", "")
        .replace(".", "_")
        .replace("/", "_")
        .replace("\\", "_")
    )


def subnet_mask_to_cidr(mask: str) -> str:
    """
    Convert subnet mask to CIDR notation.

    Args:
        mask (str): Subnet mask in dotted decimal notation (e.g., "255.255.255.0")

    Returns:
        str: CIDR notation (e.g., "24")
    """
    try:
        # Convert mask to binary and count consecutive 1s
        mask_parts = mask.split(".")
        if len(mask_parts) != 4:
            return mask  # Return original if not valid format

        binary_mask = "".join([format(int(part), "08b") for part in mask_parts])
        cidr = len(binary_mask.split("0")[0])
        return str(cidr)
    except (ValueError, IndexError):
        return mask  # Return original if conversion fails


def process_network_interface_name(interface_name: str) -> Tuple[str, str, str]:
    """
    Process a network interface name into its base type, number, and sub-number.

    Args:
        interface_name (str): The original interface name (e.g., "eth0/0").

    Returns:
        Tuple[str, str, str]: A tuple containing the base_name, number_part, normalized_name
    """
    # Extract base name and numeric parts from interface name
    # Handle cases with and without spaces:
    # e.g., "eth0/0" -> base="eth", number="0/0"
    # e.g., "eth 0/0" -> base="eth", number="0/0"
    # e.g., "GigabitEthernet0/1" -> base="GigabitEthernet", number="0/1"

    # First, normalize spaces in interface name (remove extra spaces and join with single space)
    normalized_name = re.sub(r"\s+", " ", interface_name.strip())

    # Try to match interface with space between type and number
    interface_match = re.match(r"([a-zA-Z]+)\s+(.+)", normalized_name)
    if interface_match:
        base_name = interface_match.group(1)  # e.g., "eth", "vlan"
        number_part = interface_match.group(2)  # e.g., "0/0", "10"
    else:
        # Try to match interface without space (traditional format)
        interface_match = re.match(r"([a-zA-Z]+)(.+)", normalized_name)
        if interface_match:
            base_name = interface_match.group(1)  # e.g., "eth", "GigabitEthernet"
            number_part = interface_match.group(2)  # e.g., "0/0", "0/1"
        else:
            base_name = normalized_name
            number_part = None

    # Normalize interface base names
    if base_name.lower().startswith(("eth", "e")):
        base_name = "Ethernet"
    elif base_name.lower().startswith(("gi", "g")):
        base_name = "GigabitEthernet"
    elif base_name.lower().startswith(("fa", "f")):
        base_name = "FastEthernet"
    elif base_name.lower().startswith(("te", "t")):
        base_name = "TenGigabitEthernet"
    elif base_name.lower().startswith(("po", "port")):
        base_name = "Port-channel"
    elif base_name.lower().startswith(("vl", "vlan")):
        base_name = "Vlan"
    elif base_name.lower().startswith(("lo", "loopback")):
        base_name = "Loopback"
    elif base_name.lower().startswith(("ser", "serial")):
        base_name = "Serial"
    elif base_name.lower().startswith(("tunnel", "tun")):
        base_name = "Tunnel"
    # Support Nexus mgmt interfaces
    elif base_name.lower().startswith(("mgmt", "mg")):
        base_name = "mgmt"
    return base_name, number_part, normalized_name


def _extract_interface_details_from_ios_config(config: str) -> Dict[str, Any]:
    """
    Extract interface details from a CML node configuration.

    Supports various IOS-like configurations including:
    - IOS
    - IOS XR
    - IOS XE
    - ASAv (Adaptive Security Appliance)
    - NX-OS

    Args:
        node (Node): The CML node object.

    Returns:
        Dict[str, Any]: A dictionary containing interface details.
        Each key is the full interface name (e.g., "eth0/0") and contains interface details.
    """
    logger.debug("Parsing IOS configuration for interface details")

    interfaces = {}

    # Regex to match interface blocks
    # This pattern matches from "interface <name>" to the next "!"
    # Updated to handle spaces between interface type and number (e.g., "eth 0/1")
    # Ensures "interface" is at the start of a line (optionally preceded by whitespace)
    interface_pattern = (
        r"^\s*interface\s+(?!range\s)([^\r\n]+?)\s*\r?\n(.*?)(?=^!|^\s*interface\s|\Z)"
    )

    # Find all interface blocks
    interface_matches = re.finditer(
        interface_pattern, config, re.MULTILINE | re.DOTALL | re.IGNORECASE
    )

    interface_count = 0
    for match in interface_matches:
        interface_count += 1
        interface_name = match.group(1)
        interface_config = match.group(2)

        logger.debug(f"Processing interface: {interface_name}")
        base_name, number_part, normalized_name = process_network_interface_name(
            interface_name
        )

        # Use the full interface name as the key to avoid conflicts
        # e.g., "eth0/0", "eth0/1", "eth0/2" will all be separate entries
        # For interfaces with spaces, concatenate base_name and number_part
        if number_part:
            key_name = base_name + number_part
        else:
            key_name = base_name

        interface_details = {
            "interface_name": normalized_name,  # Use normalized name (consistent spacing)
            "description": None,
            "enabled": True,  # Default to enabled
            "ip_address": None,
        }

        # Check for description
        desc_pattern = r"description\s+(.+)"
        desc_match = re.search(desc_pattern, interface_config, re.IGNORECASE)
        if desc_match:
            interface_details["description"] = desc_match.group(1).strip()
            logger.debug(
                f"Found description for {interface_name}: {interface_details['description']}"
            )

        # Check for shutdown status
        # Look for "shutdown" or "shut" (disabled)
        if re.search(
            r"^\s*(shutdown|shut)\s*$", interface_config, re.MULTILINE | re.IGNORECASE
        ):
            interface_details["enabled"] = False
            logger.debug(f"Interface {interface_name} is shutdown")
        # Look for "no shutdown" or "no shut" (enabled)
        elif re.search(
            r"^\s*no\s+(shutdown|shut)\s*$",
            interface_config,
            re.MULTILINE | re.IGNORECASE,
        ):
            interface_details["enabled"] = True
            logger.debug(f"Interface {interface_name} is enabled (no shutdown)")

        # Check for IP address
        # Pattern for "ip address <ip> <mask>" or "ip address dhcp"
        ip_pattern = r"ip\s+address\s+(\S+)(?:\s+(\S+))?"
        ip_match = re.search(ip_pattern, interface_config, re.IGNORECASE)
        if ip_match:
            ip_addr = ip_match.group(1)
            subnet_mask = ip_match.group(2) if ip_match.group(2) else None

            if ip_addr.lower() == "dhcp":
                interface_details["ip_address"] = "dhcp"
                logger.debug(f"Interface {interface_name} configured for DHCP")
            elif subnet_mask:
                # Convert subnet mask to CIDR notation
                cidr = subnet_mask_to_cidr(subnet_mask)
                interface_details["ip_address"] = f"{ip_addr}/{cidr}"
                logger.debug(
                    f"Interface {interface_name} IP: {interface_details['ip_address']}"
                )
            else:
                interface_details["ip_address"] = ip_addr
                logger.debug(f"Interface {interface_name} IP: {ip_addr}")

        # Check for ASAv "nameif" to apply labels to interfaces
        if "nameif" in interface_config:
            nameif_pattern = r"nameif\s+(\S+)"
            nameif_match = re.search(nameif_pattern, interface_config, re.IGNORECASE)
            if nameif_match:
                interface_details["label"] = nameif_match.group(1).strip()
                logger.debug(
                    f"Found nameif for {interface_name}: {interface_details['label']}"
                )

        interfaces[key_name] = interface_details

    logger.debug(f"Parsed {interface_count} interfaces from configuration")
    return interfaces


def _extract_interface_details_from_linuxip_config(config: str) -> Dict[str, Any]:
    """
    Extract interface details from a Linux-like configuration.

    Args:
        config (str): The configuration string.

    Returns:
        Dict[str, Any]: A dictionary containing interface details.
        Each key is the full interface name (e.g., "eth0") and contains interface details.
    """
    logger.debug("Parsing Linux-like configuration for interface details")

    # Note: Remove all comments from the config before processing
    config = "\n".join(
        line.strip() for line in config.split("\n") if not line.strip().startswith("#")
    )

    interfaces = {}

    # Pattern to match various forms of ip address add commands:
    # - ip address add <ip>/<cidr> dev <interface>
    # - ip addr add <ip>/<cidr> dev <interface>
    # - ip add add <ip>/<cidr> dev <interface>
    # - ip a add <ip>/<cidr> dev <interface>
    ip_addr_pattern = r"ip\s+(?:address|addr|add|a)\s+add\s+(\S+)\s+dev\s+(\S+)"

    # Find all IP address assignments
    ip_matches = re.finditer(ip_addr_pattern, config, re.IGNORECASE)

    for match in ip_matches:
        ip_address = match.group(1)  # e.g., "10.10.10.11/24"
        interface_name = match.group(2)  # e.g., "eth0", "bond0.20"

        logger.debug(f"Found IP assignment: {ip_address} on interface {interface_name}")

        # If interface doesn't exist yet, create it with default values
        if interface_name not in interfaces:
            interfaces[interface_name] = {
                "interface_name": interface_name,
                "description": None,
                "enabled": True,
                "ip_address": None,
            }

        # Set or append IP address
        if interfaces[interface_name]["ip_address"] is None:
            interfaces[interface_name]["ip_address"] = ip_address
        else:
            # If multiple IPs on same interface, we could handle this differently
            # For now, just log and keep the first one
            logger.debug(
                f"Interface {interface_name} already has IP {interfaces[interface_name]['ip_address']}, ignoring additional IP {ip_address}"
            )

    logger.debug(f"Parsed {len(interfaces)} interfaces from Linux IP configuration")
    return interfaces


def extract_interface_details_from_node_config(node: Node) -> Dict[str, Any]:
    """
    Extract interface details from a CML node configuration.

    Args:
        node (Node): The CML node object.

    Returns:
        Dict[str, Any]: A dictionary containing interface details.
        Each key is the full interface name (e.g., "eth0/0") and contains interface details.
    """
    # Get the node configuration
    config = node.configuration
    if not config:
        logger.debug(f"No configuration found for node {node.label}")
        return {}

    logger.debug(
        f"Extracting interface details from node {node.label} (type: {node.node_definition})"
    )

    if node.node_definition in [
        "iol",
        "iol-xe",
        "ioll2-xe",
        "iol-xe-serial-4eth",
        "iosv",
        "iosvl2",
        "csr1000v",
        "cat8000v",
        "nxosv9000",
        "asav",
    ]:
        interfaces = _extract_interface_details_from_ios_config(config)
        logger.info(
            f"Extracted {len(interfaces)} interfaces from {node.node_definition} config for node {node.label}"
        )
    # Explicit check for IOS XR node types because of xrd-? node definition naming
    elif node.node_definition in ["iosxrv9000"] or node.node_definition.startswith(
        "xrd"
    ):
        interfaces = _extract_interface_details_from_ios_config(config)
        logger.info(
            f"Extracted {len(interfaces)} interfaces from {node.node_definition} config for node {node.label}"
        )
    elif node.node_definition in [
        "alpine",
        "chrome",
        "desktop",
        "devbox",
        "dnsmasq",
        "firefox",
        "net-tools",
        "netbox-server",
        "nginx",
        "radius",
        "server",
        "splunk",
        "syslog",
        "tacplus",
    ]:
        interfaces = _extract_interface_details_from_linuxip_config(config)
        logger.info(
            f"Extracted {len(interfaces)} interfaces from {node.node_definition} config for node {node.label}"
        )
    elif node.node_definition in ["ftdv"]:
        # FTDv configuration is JSON-like, so we can parse it directly
        try:
            import json

            config_data = json.loads(config)
            ip_address = f"{config_data.get('IPv4Addr', '')}/{subnet_mask_to_cidr(config_data.get('IPv4Mask', ''))}"

            interfaces = {
                "Management0/0": {
                    "interface_name": "Management0/0",
                    "description": "Management Interface",
                    "enabled": True,
                    "ip_address": ip_address,
                },
            }
            logger.info(
                f"Extracted {len(interfaces)} interfaces from FTDv config for node {node.label}"
            )
        except json.JSONDecodeError as e:
            logger.error(
                f"Failed to parse FTDv configuration for node {node.label}: {e}"
            )
            interfaces = {}
    else:
        logger.debug(
            f"Node type '{node.node_definition}' not supported for interface extraction"
        )
        interfaces = {}

    return interfaces


def test_interface_parser():
    """
    Test function to demonstrate the interface parser with sample IOS and Linux configurations.
    """
    # Sample IOS configuration for testing
    sample_ios_config = """
interface eth3/0
 no shut
 ip address 10.10.10.1 255.255.255.0
 description Mangement Interface
!
interface eth0/0
 no shut
 ip address dhcp
 ip nat outside
!
interface eth0/1
 no shut
 description User network
 ip address 192.168.101.1 255.255.255.0
 ip nat inside
!
interface eth0/2
 shutdown
 description Unused interface
!
interface eth 0/3
 shutdown
 description Unused interface
 ip address 10.10.10.10/24
!
interface vlan 10
 no shutdown
 description Management VLAN
 ip address 192.168.10.1 255.255.255.0
!
interface vlan20
 no shutdown
 description User VLAN
 ip address 192.168.20.1 255.255.255.0
!
interface po1
 no shutdown
 description Port-channel 1
!
interface GigabitEthernet0/0
 no shutdown
 description WAN interface
 ip address 10.1.1.1 255.255.255.252
!
interface range Ethernet 1/0 - 3
 no ip address
 shutdown
!
interface e1/0
 description To CML NAT ExtConnector and Internet
 ip address dhcp
 ip nat outside
 no shut
!
interface e1/1
 description To DC1-INET
 ip address 198.51.100.1 255.255.255.0
 ip nat inside
 no shut
!
ip access-list standard NAT-ALLOW
 permit 198.51.100.0 0.0.0.255
!
ip nat inside source list NAT-ALLOW interface eth0/0 overload
!

"""

    # Sample Linux IP configuration for testing
    sample_linux_config = """
ip addr add 10.10.10.11/24 dev eth0
ip addr add 10.192.1.6/24 dev eth0

ip link add link bond0 name bond0.20 type vlan id 20
ip addr add 10.10.20.101/24 dev bond0.20

ip a add 192.168.1.1/24 dev eth1
ip add add 172.16.0.1/16 dev lo

ip address add 192.168.2.1/24 dev eth2
"""

    # Sample IOS XR configuration for testing
    sample_iosxr_config = """
hostname xrd-0
username cisco
group root-lr
group cisco-support
password cisco
!
username admin
group root-lr
group cisco-support
password cisco
!
username lab
group root-lr
group cisco-support
password cisco
!
interface MgmtEth0/RP0/CPU0/0
 no shut 
 description mgmt interface 
 ip address dhcp 
! 
interface gig0/0/0/0
 no shut
 description to users 
 ip address 192.168.101.151/24
!
end
"""

    # Sample ASAv configuraiton for testing
    sample_asav_config = """
hostname asav-0
!
enable password Cisco1@3
!
!
interface Management0/0
 management-only
 nameif management
 security-level 0
 ip address dhcp 
 no shut
! 
interface GigabitEthernet0/0
 nameif inside
 security-level 100
 ip address 192.168.101.152 255.255.255.0 
 no shut 
!
end
"""

    # Sample FTDv configuration for testing
    sample_ftdv_config = """
{
    "EULA": "accept",
    "Hostname": "inserthostname-here",
    "AdminPassword": "Cisc01@3",
    "FirewallMode": "routed",
    "DNS1": "192.168.255.1",
    "DNS2": "",
    "DNS3": "",
    "IPv4Mode": "manual",
    "IPv4Addr": "192.168.101.156",
    "IPv4Mask": "255.255.255.0",
    "IPv4Gw": "192.168.101.1",
    "IPv6Mode": "disabled",
    "IPv6Addr": "",
    "IPv6Mask": "",
    "IPv6Gw": "",
    "FmcIp": "",
    "FmcRegKey": "",
    "FmcNatId": "",
    "ManageLocally":"Yes"
}
"""

    # Sample NX-OS configuration for testing
    sample_nxos_config = """
hostname nxos9000-0
# workaround for booting to loader> prompt
echo 'from cli import cli' > set_boot.py
echo 'import json' >> set_boot.py
echo 'import os' >> set_boot.py
echo 'import time' >> set_boot.py
echo 'bootimage = json.loads(cli("show version | json"))["nxos_file_name"]' >> set_boot.py
echo 'set_boot = cli("conf t ; boot nxos {} ; no event manager applet BOOTCONFIG".format(bootimage))' >> set_boot.py
echo 'i = 0' >> set_boot.py
echo 'while i < 10:' >> set_boot.py
echo '    try:' >> set_boot.py
echo '        save_config = cli("copy running-config startup-config")' >> set_boot.py
echo '        break' >> set_boot.py
echo '    except Exception:' >> set_boot.py
echo '        i += 1' >> set_boot.py
echo '        time.sleep(1)' >> set_boot.py
echo 'os.remove("/bootflash/set_boot.py")' >> set_boot.py
event manager applet BOOTCONFIG
 event syslog pattern "Configured from vty"
 action 1.0 cli python bootflash:set_boot.py
# minimum needed config to login
no password strength-check
username admin role network-admin
username admin password cisco role network-admin
username cisco role network-admin
username cisco password cisco role network-admin
!
interface mgmt0
 description management 
 ip address 192.168.0.155/24
! 
interface e0/0
 description link to switch01 
!
"""

    # Create a mock node object for testing
    class MockNode:
        def __init__(self, config, node_type="iol", label="TestNode"):
            self.configuration = config
            self.node_definition = node_type
            self.label = label

    # Test IOS configuration
    ios_node = MockNode(sample_ios_config, node_type="iol", label="IOS-TestNode")
    print("\n=== IOS Configuration Test ===")
    ios_result = extract_interface_details_from_node_config(ios_node)
    for interface, details in ios_result.items():
        print(f"  {interface}: {details}")

    # Test IOS XR configuration
    iosxr_node = MockNode(
        sample_iosxr_config, node_type="xrd-24_4_2", label="IOSXR-TestNode"
    )
    print("\n=== IOS XR Configuration Test ===")
    iosxr_result = extract_interface_details_from_node_config(iosxr_node)
    for interface, details in iosxr_result.items():
        print(f"  {interface}: {details}")

    # Test ASAv configuration
    asav_node = MockNode(sample_asav_config, node_type="asav", label="ASAv-TestNode")
    print("\n=== ASAv Configuration Test ===")
    asav_result = extract_interface_details_from_node_config(asav_node)
    for interface, details in asav_result.items():
        print(f"  {interface}: {details}")

    # Test NX-OS configuration
    nxos_node = MockNode(
        sample_nxos_config, node_type="nxosv9000", label="NXOS-TestNode"
    )
    print("\n=== NX-OS Configuration Test ===")
    nxos_result = extract_interface_details_from_node_config(nxos_node)
    for interface, details in nxos_result.items():
        print(f"  {interface}: {details}")

    # Test Linux configuration
    linux_node = MockNode(
        sample_linux_config, node_type="alpine", label="Alpine-TestNode"
    )
    print("\n=== Linux Configuration Test ===")
    linux_result = extract_interface_details_from_node_config(linux_node)
    for interface, details in linux_result.items():
        print(f"  {interface}: {details}")

    # Test FTDv configuration
    ftdv_node = MockNode(sample_ftdv_config, node_type="ftdv", label="FTDv-TestNode")
    print("\n=== FTDv Configuration Test ===")
    ftdv_result = extract_interface_details_from_node_config(ftdv_node)
    for interface, details in ftdv_result.items():
        print(f"  {interface}: {details}")

    return ios_result, linux_result


if __name__ == "__main__":
    # Configure logging for standalone execution
    logging.basicConfig(level=logging.DEBUG)
    logger.info("Running interface parser test")
    test_interface_parser()
