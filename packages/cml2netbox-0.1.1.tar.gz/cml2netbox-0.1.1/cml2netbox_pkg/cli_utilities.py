"""
Utility functions and classes for the CML2NetBox CLI.
"""

import os
from pathlib import Path
from typing import Dict, Any

import click
from pynetbox import api as netbox_api
import requests
from virl2_client import ClientLibrary
from .cli_logging import get_logger

# Try to import python-dotenv, but don't fail if it's not available
try:
    from dotenv import load_dotenv

    DOTENV_AVAILABLE = True
except ImportError:
    DOTENV_AVAILABLE = False


def load_env_file():
    """Load environment variables from .env file if it exists and dotenv is available."""
    if DOTENV_AVAILABLE:
        env_file = Path.cwd() / ".env"
        if env_file.exists():
            load_dotenv(env_file)


def get_config_value(key: str, alt_key: str = None, default: Any = None) -> Any:
    """
    Get configuration value with priority order:
    1. Environment variable (key)
    2. Alternative environment variable (alt_key, e.g., VIRL2_* variants)
    3. Default value
    """
    value = os.getenv(key)
    if value is None and alt_key:
        value = os.getenv(alt_key)
    if value is None:
        return default

    # Convert string 'true'/'false' to boolean for SSL verification options
    if key.endswith("_VERIFY_SSL") and isinstance(value, str):
        return value.lower() in ("true", "1", "yes", "on")

    return value


class Config:
    """Configuration container for CML2NetBox."""

    def __init__(self):
        logger = get_logger(__name__)
        logger.debug("Initializing configuration")

        # Load .env file first
        load_env_file()

        # CML Configuration
        self.cml2_url = get_config_value("CML2_URL", "VIRL2_URL")
        self.cml2_user = get_config_value("CML2_USER", "VIRL2_USER")
        self.cml2_pass = get_config_value("CML2_PASS", "VIRL2_PASS")
        self.cml2_verify_ssl = get_config_value(
            "CML2_VERIFY_SSL", "VIRL2_VERIFY_SSL", True
        )
        try:
            self.cml2_client = ClientLibrary(
                url=self.cml2_url,
                username=self.cml2_user,
                password=self.cml2_pass,
                ssl_verify=self.cml2_verify_ssl,
                raise_for_auth_failure=True,
            )
        except Exception as e:
            logger.error(f"CML2 API connectivity test failed: {e}")
            # Check if logger is at DEBUG level to determine whether to raise or exit
            if logger.isEnabledFor(10):  # DEBUG level is 10
                raise e
            else:
                exit(1)

        # NetBox Configuration
        self.netbox_url = get_config_value("NETBOX_URL")
        self.netbox_api_token = get_config_value("NETBOX_API_TOKEN")
        self.netbox_verify_ssl = get_config_value("NETBOX_VERIFY_SSL", default=True)
        self.netbox_client = netbox_api(
            url=self.netbox_url,
            token=self.netbox_api_token,
        )
        self.netbox_client.http_session = requests.Session()
        self.netbox_client.http_session.verify = self.netbox_verify_ssl

        # Test connectivity to CML and NetBox
        try:
            nb_status = self.netbox_client.status()
            logger.debug(f"NetBox API connectivity test successful: {nb_status}")
        except Exception as e:
            logger.error(f"NetBox API connectivity test failed: {e}")
            if logger.isEnabledFor(10):  # DEBUG level is 10
                raise e
            else:
                exit(1)

        logger.debug(f"CML2 URL configured: {'Yes' if self.cml2_url else 'No'}")
        logger.debug(f"NetBox URL configured: {'Yes' if self.netbox_url else 'No'}")

    def update_from_click_params(self, **kwargs):
        """Update configuration from Click command parameters."""
        logger = get_logger(__name__)
        logger.debug(
            f"Updating configuration from CLI parameters: {list(kwargs.keys())}"
        )

        for key, value in kwargs.items():
            if value is not None:
                # Convert CLI parameter names to config attribute names
                attr_name = key.replace("-", "_")
                # For lab-specific attributes, ensure they exist first
                if attr_name in ["lab_name", "lab_id"]:
                    self._ensure_lab_config()
                if hasattr(self, attr_name):
                    setattr(self, attr_name, value)
                    logger.debug(f"Updated {attr_name} from CLI parameter")

    def _ensure_lab_config(self):
        """Ensure lab configuration attributes are initialized."""
        if not hasattr(self, "lab_name"):
            self.lab_name = get_config_value("LAB_NAME")
        if not hasattr(self, "lab_id"):
            self.lab_id = get_config_value("LAB_ID")

    def update_lab_config(self, **kwargs):
        """Update lab-specific configuration from Click parameters."""
        # Initialize lab config from environment variables first
        self._ensure_lab_config()

        # Update with any provided click parameters
        lab_params = {k: v for k, v in kwargs.items() if k in ["lab_name", "lab_id"]}
        self.update_from_click_params(**lab_params)

    def validate(self, require_lab_name=False) -> Dict[str, str]:
        """Validate required configuration parameters. Returns dict of missing parameters."""
        missing = {}

        if not self.cml2_url:
            missing["CML2_URL"] = "CML server URL is required"
        if not self.cml2_user:
            missing["CML2_USER"] = "CML username is required"
        if not self.cml2_pass:
            missing["CML2_PASS"] = "CML password is required"
        if not self.netbox_url:
            missing["NETBOX_URL"] = "NetBox server URL is required"
        if not self.netbox_api_token:
            missing["NETBOX_API_TOKEN"] = "NetBox API token is required"

        # Lab name is required for lab sync operations
        if require_lab_name and not getattr(self, "lab_name", None):
            missing["LAB_NAME"] = "CML Lab Name is required"

        return missing


def validate_config_or_abort(config: Config, require_lab_name: bool = False) -> None:
    """
    Validate configuration and abort with error message if validation fails.

    Args:
        config: Configuration object to validate
        require_lab_name: Whether lab name is required for validation

    Raises:
        click.Abort: If validation fails
    """
    logger = get_logger(__name__)
    logger.debug("Validating configuration")

    missing = config.validate(require_lab_name=require_lab_name)
    if missing:
        logger.error("Configuration validation failed - missing required parameters")
        for param, msg in missing.items():
            logger.error(f"Missing {param}: {msg}")

        click.echo("❌ Missing required configuration:", err=True)
        for param, msg in missing.items():
            click.echo(f"  {param}: {msg}", err=True)
        click.echo(
            "\nConfiguration can be provided via environment variables, .env file, or CLI options.",
            err=True,
        )
        raise click.Abort()

    logger.debug("Configuration validation successful")
