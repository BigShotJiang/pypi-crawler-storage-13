from typing import Dict, Optional, List
from virl2_client import ClientLibrary
from cml2netbox_pkg.cli_logging import get_logger


def get_lab(
    client: ClientLibrary,
    lab_name: str,
    lab_id: str = None,
):
    """
    Retrieve a lab by name and optional ID.

    Args:
        lab_name (str): The name of the lab to retrieve.
        lab_id (str, optional): The ID of the lab to verify if multiple labs exist. Defaults to None.

    Returns:
        Lab: The retrieved lab object.

    Raises:
        ValueError: If the lab is not found or if multiple labs exist with the same name and no ID is provided.
    """
    logger = get_logger(__name__)
    logger.info(f"Searching for lab with name: {lab_name}")

    # Find the lab by name
    labs = client.find_labs_by_title(lab_name)
    logger.debug(f"Found {len(labs)} lab(s) with name '{lab_name}'")

    if len(labs) == 0:
        logger.error(f"No lab found with name '{lab_name}'")
        raise ValueError(f"Lab with name '{lab_name}' not found")

    if len(labs) > 1:
        logger.warning(
            f"Multiple labs found with name '{lab_name}': {[lab.id for lab in labs]}"
        )
        if lab_id is None:
            logger.error(
                f"Multiple labs found with name '{lab_name}' but no LAB_ID specified"
            )
            raise ValueError(
                f"Multiple labs found with name '{lab_name}'. Please specify LAB_ID."
            )
        logger.info(f"Filtering labs by ID: {lab_id}")
        labs = [lab for lab in labs if str(lab.id) == str(lab_id)]
        if not labs:
            logger.error(f"No lab found with name '{lab_name}' and ID '{lab_id}'")
            raise ValueError(f"Lab title '{lab_name}' and ID '{lab_id}' not found")

    selected_lab = labs[0]
    logger.info(
        f"Successfully retrieved lab: {selected_lab.title} (ID: {selected_lab.id})"
    )
    return selected_lab


def print_node_info(lab):
    """
    Print information about nodes in the lab.

    Args:
        lab (Lab): The lab object containing nodes.
    """


def get_all_node_definitions(
    client: ClientLibrary,
) -> Dict[str, Dict]:
    """
    Connects to CML and retrieves all available node definitions.

    Args:
        client (ClientLibrary): The CML client instance

    Returns:
        Dict[str, Dict]: Dictionary of node definitions keyed by node definition ID

    Raises:
        Exception: If connection to CML fails or authentication fails
    """
    logger = get_logger(__name__)

    try:
        # Get all node definitions
        node_definitions = client.definitions.node_definitions()
        logger.info(f"Retrieved {len(node_definitions)} node definitions")

        return node_definitions

    except Exception as e:
        logger.error(f"Failed to retrieve node definitions: {str(e)}")
        # Check if logger is at DEBUG level to determine whether to raise or exit
        if logger.isEnabledFor(10):  # DEBUG level is 10
            raise e
        else:
            exit(1)


def get_node_definition_by_id(
    client: ClientLibrary,
    node_def_id: str,
) -> Optional[Dict]:
    """
    Retrieves a specific node definition by ID.

    Args:
        client (ClientLibrary): The CML client instance
        node_def_id (str): The node definition ID to retrieve

    Returns:
        Optional[Dict]: Node definition details or None if not found
    """
    logger = get_logger(__name__)

    try:
        # Get all node definitions
        all_definitions = get_all_node_definitions(client)

        # Handle both dictionary and list formats
        if isinstance(all_definitions, dict):
            return all_definitions.get(node_def_id)
        elif isinstance(all_definitions, list):
            for node_def in all_definitions:
                if node_def.get("id") == node_def_id:
                    return node_def
            return None
        else:
            logger.warning("Unexpected node definitions format")
            return None

    except Exception as e:
        logger.error(f"Failed to retrieve node definition {node_def_id}: {str(e)}")
        if logger.isEnabledFor(logger.DEBUG):
            raise e
        else:
            exit(1)


def list_node_definition_ids(
    client: ClientLibrary,
) -> List[str]:
    """
    Returns a list of all available node definition IDs.

    Args:
        client (ClientLibrary): The CML client instance

    Returns:
        List[str]: List of node definition IDs
    """
    logger = get_logger(__name__)
    try:
        node_definitions = get_all_node_definitions(client)

        # Handle both dictionary and list formats
        if isinstance(node_definitions, dict):
            return list(node_definitions.keys())
        elif isinstance(node_definitions, list):
            return [node_def.get("id", "unknown") for node_def in node_definitions]
        else:
            logger.warning("Unexpected node definitions format")
            return []

    except Exception as e:
        logger.error(f"Failed to list node definition IDs: {str(e)}")
        return []


def print_node_definitions_summary(client: ClientLibrary) -> None:
    """
    Prints a summary of all available node definitions.

    Args:
        client (ClientLibrary): The CML client instance
    """
    logger = get_logger(__name__)
    try:
        node_definitions = get_all_node_definitions(client)

        print(f"\nFound {len(node_definitions)} node definitions:")
        print("-" * 60)

        # Handle both dictionary and list formats
        if isinstance(node_definitions, dict):
            # If it's a dictionary, iterate over items
            for node_id, node_def in node_definitions.items():
                _print_node_definition_details(node_id, node_def)
        elif isinstance(node_definitions, list):
            # If it's a list, iterate over each node definition
            for node_def in node_definitions:
                node_id = node_def.get("id", "N/A")
                _print_node_definition_details(node_id, node_def)
        else:
            print("Unexpected node definitions format")

    except Exception as e:
        logger.error(f"Failed to print node definitions summary: {str(e)}")


def _print_node_definition_details(node_id: str, node_def: Dict) -> None:
    """
    Helper function to print details of a single node definition.

    Args:
        node_id (str): The node definition ID
        node_def (Dict): The node definition dictionary
    """
    # Extract relevant information from the node definition
    general = node_def.get("general", {})
    ui = node_def.get("ui", {})
    device = node_def.get("device", {})
    sim = node_def.get("sim", {})

    name = general.get("description", "N/A")
    nature = general.get("nature", "N/A")
    ui_label = ui.get("label", "N/A")
    ui_group = ui.get("group", "N/A")

    # Get interface information
    interfaces = device.get("interfaces", {})
    interface_count = interfaces.get("default_count", "N/A")
    mgmt_interfaces = interfaces.get("management", [])

    # Get simulation details
    linux_native = sim.get("linux_native", {})
    ram = linux_native.get("ram", "N/A")
    cpus = linux_native.get("cpus", "N/A")

    print(f"ID: {node_id}")
    print(f"  Name: {name}")
    print(f"  UI Label: {ui_label}")
    print(f"  Group: {ui_group}")
    print(f"  Nature: {nature}")
    print(f"  Default Interfaces: {interface_count}")
    if mgmt_interfaces:
        print(f"  Management Interfaces: {', '.join(mgmt_interfaces)}")
    print(f"  RAM: {ram} MB" if isinstance(ram, int) else f"  RAM: {ram}")
    print(f"  CPUs: {cpus}")
    print("-" * 40)


if __name__ == "__main__":
    # Some basic testing of the functions
    import os
    import logging

    # Used for testing the functions themselves
    logger = logging.getLogger(__name__)
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    client = ClientLibrary(ssl_verify=False)

    lab_name = os.environ.get("LAB_NAME", None)
    # Lab ID only used to verify if multiple labs with same name exist
    lab_id = os.environ.get("LAB_ID", None)

    if lab_name is None:
        logger.error("LAB_NAME environment variable must be set")
        raise ValueError("LAB_NAME must be set")

    lab = get_lab(client, lab_name, lab_id)
