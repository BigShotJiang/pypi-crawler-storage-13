from typing import Dict, Optional
import pynetbox
from cml2netbox_pkg.cli_logging import get_logger

from cml2netbox_pkg.helpers import (
    sanitize_string,
    extract_interface_details_from_node_config,
    process_network_interface_name,
)
from virl2_client.models import Node


def get_or_create_site(
    nb: pynetbox.core.api.Api, site_name: str
) -> pynetbox.core.response.Record:
    """
    Retrieve or create a site in NetBox.

    Args:
        site_name (str): The name of the site.

    Returns:
        Site: The retrieved or created site object.
    """
    logger = get_logger(__name__)
    # Site names can only have letter, numbers, spaces, underscores, and hyphens
    original_name = site_name
    site_name = sanitize_string(site_name)

    if original_name != site_name:
        logger.info(f"Sanitized site name from '{original_name}' to '{site_name}'")

    logger.info(f"Looking for existing site: {site_name}")
    sites = nb.dcim.sites.filter(name=site_name)
    if sites:
        site = list(sites)[0]
        logger.info(f"Found existing site: {site.name} (ID: {site.id})")
        return site
    else:
        logger.info(f"Creating new site: {site_name}")
        site = nb.dcim.sites.create(
            name=site_name, slug=site_name.lower().replace(" ", "-")
        )
        logger.info(f"Created site: {site.name} (ID: {site.id})")
        return site


def get_or_create_device_from_cml_node(
    nb: pynetbox.core.api.Api, node: Node, site: pynetbox.core.response.Record
) -> pynetbox.models.dcim.Devices:
    """
    Retrieve or create a device in NetBox from a CML node.

    Args:
        node (Node): The CML node object.

    Returns:
        Device: The retrieved or created device object.
    """
    logger = get_logger(__name__)
    logger.info(
        f"Processing device for CML node: {node.label} (type: {node.node_definition})"
    )

    device = nb.dcim.devices.get(name=node.label, site_id=site.id)

    if device is None:
        logger.info(f"Device '{node.label}' not found in NetBox, creating new device")

        # CML node definitions use dots, NetBox device type slugs use underscores
        device_type = nb.dcim.device_types.get(
            slug=node.node_definition.replace(".", "_")
        )
        # Check to see if the device type for this node exists in NetBox, if not trigger creation of it
        if device_type is None:
            logger.warning(
                f"Device type '{node.node_definition}' not found in NetBox. Raising error to trigger creation."
            )
            # Raise specific error so that the calling function can process and create device type
            raise TypeError(
                f"Device type not found in NetBox: '{node.node_definition}'"
            )

        logger.debug(f"Found device type: {device_type.model} (ID: {device_type.id})")

        # Using generic role for now, can be customized later
        device_role = nb.dcim.device_roles.get(slug="cml-node")
        if device_role is None:
            logger.info("Creating 'CML Node' device role as it doesn't exist")
            device_role = nb.dcim.device_roles.create(
                name="CML Node",
                slug="cml-node",
                description="Generic role for CML nodes",
            )
            logger.info(
                f"Created device role: {device_role.name} (ID: {device_role.id})"
            )
        else:
            logger.debug(
                f"Using existing device role: {device_role.name} (ID: {device_role.id})"
            )

        # Create the device in NetBox
        logger.info(f"Creating device '{node.label}' in NetBox")
        device = nb.dcim.devices.create(
            name=node.label,
            site=site.id,
            device_type=device_type.id,
            role=device_role.id,
            status="active",
            asset_tag=node.id,
        )
        logger.info(f"Created device: {device.name} (ID: {device.id})")
    else:
        logger.info(f"Found existing device: {device.name} (ID: {device.id})")

    return device


def create_device_interface_from_cml_node(
    nb: pynetbox.core.api.Api, device: pynetbox.models.dcim.Devices, interface: str
) -> pynetbox.models.dcim.Interfaces:
    """
    Create a new interface in NetBox from a CML node.

    Args:
        node (Node): The CML node object.
        device (pynetbox.models.dcim.Devices): The NetBox device object.
        interface (str): The name of the interface.
        details (dict): Details about the interface.

    Returns:
        Interfaces: The created interface object.
    """
    logger = get_logger(__name__)
    logger.info(f"Creating interface '{interface}' for device {device.name}")
    base_name, number_part, normalized_name = process_network_interface_name(interface)

    type_mapping = {
        "port": "1000base-t",
        "ens": "1000base-t",
        "eth": "1000base-t",
        "ethernet": "1000base-t",
        "fastethernet": "100base-tx",
        "gigabitethernet": "1000base-t",
        "tengigabitethernet": "10gbase-t",
        "port-channel": "lag",
        "vlan": "virtual",
        "loopback": "virtual",
        "serial": "t1",
        "tunnel": "tunnel",
    }

    type = type_mapping.get(base_name.lower(), "other")

    logger.info(f"base_name: {base_name} | type: {type}")

    # Create the interface in NetBox
    nb_interface = nb.dcim.interfaces.create(
        name=interface,
        device=device.id,
        type=type,
    )

    if not nb_interface:
        logger.error(
            f"Failed to create interface '{interface}' for device {device.name}"
        )
        return None

    logger.info(f"Created interface: {nb_interface.name} (ID: {nb_interface.id})")

    return nb_interface


def update_device_interfaces_from_cml_node(
    nb: pynetbox.core.api.Api, node: Node, device: pynetbox.models.dcim.Devices
) -> pynetbox.models.dcim.Interfaces:
    """
    Update or create interfaces in NetBox from a CML node.

    Args:
        node (Node): The CML node object.
        device (pynetbox.models.dcim.Devices): The NetBox device object.

    Returns:
        Interfaces: The updated or created interfaces object.
    """
    logger = get_logger(__name__)
    logger.info(f"Updating interfaces for device: {device.name}")

    interfaces_info = extract_interface_details_from_node_config(node)

    if not interfaces_info:
        logger.info(f"No interface configuration found for node {node.label}")
        return []

    logger.info(f"Found {len(interfaces_info)} interfaces in configuration")
    updated_nb_interfaces = []

    for interface, details in interfaces_info.items():
        logger.debug(f"Processing interface: {interface}")
        nb_interface = nb.dcim.interfaces.get(device_id=device.id, name=interface)

        if nb_interface is None:
            logger.warning(
                f"Interface '{interface}' not found in NetBox for device {device.name}"
            )
            nb_interface = create_device_interface_from_cml_node(nb, device, interface)
            if nb_interface is None:
                logger.error(
                    f"Failed to create interface '{interface}' for device {device.name}"
                )
                continue
            logger.info(
                f"Created new interface: {nb_interface.name} (ID: {nb_interface.id})"
            )
        else:
            logger.debug(
                f"Found existing interface: {nb_interface.name} (ID: {nb_interface.id})"
            )

        changes_made = False

        # Update description if provided
        if details.get("description", None) is not None:
            old_desc = nb_interface.description or ""
            new_desc = details.get("description", "")
            if old_desc != new_desc:
                nb_interface.description = new_desc
                changes_made = True
                logger.debug(
                    f"Updated description for {interface}: '{old_desc}' -> '{new_desc}'"
                )

        # Update enabled status
        old_enabled = nb_interface.enabled
        new_enabled = details.get("enabled", True)
        if old_enabled != new_enabled:
            nb_interface.enabled = new_enabled
            changes_made = True
            logger.debug(
                f"Updated enabled status for {interface}: {old_enabled} -> {new_enabled}"
            )

        # Update IP address if provided
        # Find the nb_object_type for interface to use in retrieving IP address
        nb_interface_object_type = nb.extras.object_types.get(
            app_label="dcim", model="interface"
        )
        old_ipaddress = nb.ipam.ip_addresses.filter(
            assigned_object_id=nb_interface.id,
            assigned_object_type=nb_interface_object_type.id,
        )
        if old_ipaddress is not None:
            old_ipaddress = [ip.address for ip in old_ipaddress]
        new_ipaddress = details.get("ip_address", None)
        try:
            if new_ipaddress not in old_ipaddress:
                # TODO: Do I remove the OLD IP
                # if old_ipaddress:
                #     logger.info(f"Removing old IP address from {interface}: {old_ipaddress}")
                #     nb.ipam.ip_addresses.delete(old_ipaddress.id)
                if new_ipaddress == "dhcp":
                    logger.debug(
                        f"Interface {interface} configured for DHCP, skipping IP update"
                    )
                elif new_ipaddress:
                    logger.info(
                        f"Assigning new IP address to {interface}: {new_ipaddress}"
                    )
                    nb.ipam.ip_addresses.create(
                        address=new_ipaddress,
                        assigned_object_id=nb_interface.id,
                        assigned_object_type="dcim.interface",
                    )
                changes_made = True
                logger.debug(
                    f"Updated IP address for {interface}: '{old_ipaddress}' -> '{new_ipaddress}'"
                )
        except pynetbox.core.query.RequestError as e:
            logger.error(f"Failed to update IP address for {interface}: {e}")
            continue

        # Update label if provided
        if details.get("label", None) is not None:
            old_label = nb_interface.label or ""
            new_label = details.get("label", "")
            if old_label != new_label:
                nb_interface.label = new_label
                changes_made = True
                logger.debug(
                    f"Updated label for {interface}: '{old_label}' -> '{new_label}'"
                )

        if changes_made:
            nb_interface.save()
            logger.info(f"Updated interface {interface} in NetBox")
        else:
            logger.debug(f"No changes needed for interface {interface}")

        updated_nb_interfaces.append(nb_interface)

    logger.info(
        f"Processed {len(updated_nb_interfaces)} interfaces for device {device.name}"
    )

    return updated_nb_interfaces


def update_primary_ipv4_address_from_cml_node(
    nb: pynetbox.core.api.Api, node: Node, device: pynetbox.models.dcim.Devices
) -> None:
    """
    Update the primary IPv4 address for a device in NetBox from a CML node.

    Args:
        node (Node): The CML node object.
        device (pynetbox.models.dcim.Devices): The NetBox device object.
    """
    logger = get_logger(__name__)
    if device.primary_ip4:
        logger.info(
            f"Device {device.name} already has a primary IPv4 address: {device.primary_ip4.address}"
        )
        return

    logger.info(f"Updating primary IPv4 address for device: {device.name}")

    # Extract primary IPv4 address from the node configuration
    interfaces_info = extract_interface_details_from_node_config(node)
    # Assume the first interface configured with an IP is the primary interface
    primary_interface = None
    for interface, details in interfaces_info.items():
        if (
            details.get("ip_address", None) is not None
            and details.get("ip_address") != "dhcp"
        ):
            primary_interface = interface
            primary_ip = details["ip_address"]
            logger.info(
                f"Found primary interface: {primary_interface} with IP {primary_ip}"
            )
            # Break after finding the first interface with an IP address
            break

    if primary_interface is None:
        logger.warning(
            f"No primary interface with an IP address found for device {device.name}"
        )
        return None

    # Find the IP address in NetBox
    ip_address = nb.ipam.ip_addresses.get(address=primary_ip, device_id=device.id)
    if not ip_address:
        logger.error(f"Primary IP address {primary_ip} not found in NetBox")
        return None
    else:
        logger.info(
            f"Found existing IP address: {ip_address.address} (ID: {ip_address.id})"
        )

    # Set the primary IP address for the device
    device.primary_ip4 = ip_address
    device.save()
    logger.info(
        f"Updated primary IPv4 address for device {device.name} to {primary_ip}"
    )

    return device.primary_ip4


def connect_cables_from_cml_node(
    nb: pynetbox.core.api.Api, node: Node
) -> pynetbox.models.dcim.Cables:
    """
    Connect cables in NetBox based on the CML node's link configurations.

    Args:
        node (Node): The CML node object.
        device (pynetbox.models.dcim.Devices): The NetBox device object.
    Returns:
        List[Cable]: A list of created cable objects.
    """
    logger = get_logger(__name__)
    logger.info(f"Connecting cables for CML node {node.label}")

    cables = []

    links = node.links()
    if not links:
        logger.info(f"No links found for node {node.label}")
        return

    for link in links:
        if link.interface_a.node != node:
            logger.debug("Skipping link where current node is not interface_a")
            continue

        # To handle cases where multiple CML Labs on same NetBox server
        # filter by site as well.
        this_site = nb.dcim.sites.get(name=node.lab.title)

        this_device = nb.dcim.devices.get(name=node.label, site_id=this_site.id)
        if not this_device:
            logger.error(f"Device {node.label} not found in NetBox")
            continue
        this_device_interface = nb.dcim.interfaces.get(
            device_id=this_device.id, name=link.interface_a.label
        )
        if not this_device_interface:
            logger.error(
                f"Interface {link.interface_a.label} not found for device {this_device.name}"
            )
            continue

        if this_device_interface.cable:
            logger.info(
                f"Interface {this_device_interface.name} already has a cable: {this_device_interface.cable.id}"
            )
            continue

        # Find the other device and interface
        other_device = nb.dcim.devices.get(
            name=link.interface_b.node.label, site_id=this_site.id
        )
        if not other_device:
            logger.error(f"Device {link.interface_b.node.label} not found in NetBox")
            continue
        other_device_interface = nb.dcim.interfaces.get(
            device_id=other_device.id, name=link.interface_b.label
        )
        if not other_device_interface:
            logger.error(
                f"Interface {link.interface_b.label} not found for device {other_device.name}"
            )
            continue

        # Create cable in NetBox
        cable = nb.dcim.cables.create(
            type="cat6",
            status="connected",
            a_terminations=[
                {"object_type": "dcim.interface", "object_id": this_device_interface.id}
            ],
            b_terminations=[
                {
                    "object_type": "dcim.interface",
                    "object_id": other_device_interface.id,
                }
            ],
        )
        if not cable:
            logger.error(
                f"Failed to create cable between {this_device.name} and {other_device.name}"
            )
            continue
        logger.info(
            f"Created cable {cable.id} between {this_device.name} and {other_device.name}"
        )
        cables.append(cable)

    if cables:
        logger.info(f"Connected {len(cables)} cables for node {node.label}")
    else:
        logger.info(f"No cables created for node {node.label}")

    return cables


def create_nb_device_type(
    nb: pynetbox.core.api.Api,
    node_def: Dict,
) -> pynetbox.models.dcim.DeviceTypes:
    """
    Create a NetBox device type from a CML node definition.

    Args:
        node_def (Dict): The node definition dictionary
        nb_url (str): NetBox URL
        nb_token (str): NetBox API token

    Returns:
        Optional[Dict]: Created device type data or None if creation failed
    """
    logger = get_logger(__name__)
    try:
        # Extract data from CML node definition
        node_id = node_def.get("id", "unknown")
        ui = node_def.get("ui", {})
        general = node_def.get("general", {})

        model = ui.get("label", node_id)  # Use label as model, fallback to id
        slug = node_id.replace(".", "_")  # Use id as slug
        description = general.get("description", "").split("\n")[
            0
        ]  # First line of description

        logger.info(f"Creating NetBox device type for CML node: {node_id}")

        # Get or create CML manufacturer
        manufacturer = get_or_create_manufacturer(nb, "CML")
        if not manufacturer:
            logger.error("Failed to get or create CML manufacturer")
            return None

        # Check if device type already exists
        existing_device_type = nb.dcim.device_types.get(slug=slug)
        if existing_device_type:
            logger.info(f"Device type with slug '{slug}' already exists, updating...")
            # Update existing device type
            existing_device_type.model = model
            existing_device_type.description = description
            existing_device_type.manufacturer = manufacturer.id
            existing_device_type.save()
            logger.info(f"Updated device type: {model}")
            device_type = existing_device_type
        else:
            # Create new device type
            device_type_data = {
                "model": model,
                "slug": slug,
                "manufacturer": manufacturer.id,
                "description": description,
            }

            device_type = nb.dcim.device_types.create(device_type_data)
            logger.info(f"Created device type: {model} (slug: {slug})")

        # Create default interfaces
        interfaces = node_def.get("device", {}).get("interfaces", {})
        management_interfaces = interfaces.get("management", [])
        physical_interfaces = interfaces.get("physical", [])
        logger.info(
            f"Creating {len(management_interfaces)} management interfaces  & {len(physical_interfaces)} physical interfaces for device type: {device_type.model}"
        )

        nb_interfaces = []
        for interface in management_interfaces:
            nb_interfaces.append(
                _create_nb_interface_template(
                    nb, device_type.id, interface, management_only=True
                )
            )

        for interface in physical_interfaces:
            nb_interfaces.append(
                _create_nb_interface_template(
                    nb, device_type.id, interface, management_only=False
                )
            )

        # Create default serial interfaces
        num_serial_interfaces = interfaces.get("serial_ports", 0)
        logger.info(
            f"Creating {num_serial_interfaces} serial interfaces for device type: {device_type.model}"
        )
        for i in range(num_serial_interfaces):
            _create_nb_console_template(nb, device_type.id, f"Serial {i}")

        return device_type

    except Exception as e:
        logger.error(
            f"Failed to create NetBox device type for {node_def.get('id', 'unknown')}: {str(e)}"
        )
        # Check if logger is at DEBUG level to determine whether to raise or exit
        if logger.isEnabledFor(10):  # DEBUG level is 10
            raise e
        else:
            exit(1)


def get_or_create_manufacturer(
    nb: pynetbox.core.api.Api, manufacturer_name: str
) -> Optional[Dict]:
    """
    Get or create a manufacturer in NetBox.

    Args:
        nb: NetBox API client
        manufacturer_name (str): Name of the manufacturer

    Returns:
        Optional[Dict]: Manufacturer object or None if creation failed
    """
    logger = get_logger(__name__)
    try:
        # Check if manufacturer exists
        manufacturer = nb.dcim.manufacturers.get(name=manufacturer_name)
        if manufacturer:
            logger.info(f"Found existing manufacturer: {manufacturer_name}")
            return manufacturer

        # Create manufacturer if it doesn't exist
        manufacturer_data = {
            "name": manufacturer_name,
            "slug": manufacturer_name.lower(),
        }

        manufacturer = nb.dcim.manufacturers.create(manufacturer_data)
        logger.info(f"Created manufacturer: {manufacturer_name}")
        return manufacturer

    except Exception as e:
        logger.error(
            f"Failed to get or create manufacturer {manufacturer_name}: {str(e)}"
        )
        # Check if logger is at DEBUG level to determine whether to raise or exit
        if logger.isEnabledFor(10):  # DEBUG level is 10
            raise e
        else:
            exit(1)


def _create_nb_interface_template(
    nb: pynetbox.core.api.Api,
    device_type_id: int,
    interface_name: str,
    management_only: bool = False,
) -> Optional[Dict]:
    """
    Create a NetBox interface template for a device type.

    Args:
        nb: NetBox API client
        device_type_id (int): ID of the device type
        interface_name (str): Name of the interface
        management_only (bool): Whether this is a management-only interface

    Returns:
        Optional[Dict]: Created interface template or None if creation failed
    """
    logger = get_logger(__name__)
    try:
        # Check if interface template already exists
        existing_template = nb.dcim.interface_templates.get(
            device_type_id=device_type_id, name=interface_name
        )
        if existing_template:
            logger.info(
                f"Interface template '{interface_name}' already exists for device type {device_type_id}"
            )
            return existing_template

        # Create interface template data
        interface_data = {
            "device_type": device_type_id,
            "name": interface_name,
            "type": "1000base-t",
            "mgmt_only": management_only,
        }

        # Create the interface template
        interface_template = nb.dcim.interface_templates.create(interface_data)
        logger.info(
            f"Created interface template: {interface_name} (mgmt_only: {management_only})"
        )

        return interface_template

    except Exception as e:
        logger.error(
            f"Failed to create interface template '{interface_name}': {str(e)}"
        )
        # Check if logger is at DEBUG level to determine whether to raise or exit
        if logger.isEnabledFor(10):  # DEBUG level is 10
            raise e
        else:
            exit(1)


def _create_nb_console_template(
    nb: pynetbox.core.api.Api, device_type_id: int, console_name: str
) -> Optional[Dict]:
    """
    Create a NetBox console port template for a device type.

    Args:
        nb: NetBox API client
        device_type_id (int): ID of the device type
        console_name (str): Name of the console port

    Returns:
        Optional[Dict]: Created console port template or None if creation failed
    """
    logger = get_logger(__name__)
    try:
        # Check if console port template already exists
        existing_template = nb.dcim.console_port_templates.get(
            device_type_id=device_type_id, name=console_name
        )
        if existing_template:
            logger.info(
                f"Console port template '{console_name}' already exists for device type {device_type_id}"
            )
            return existing_template

        # Create console port template data
        console_data = {
            "device_type": device_type_id,
            "name": console_name,
        }

        # Create the console port template
        console_template = nb.dcim.console_port_templates.create(console_data)
        logger.info(f"Created console port template: {console_name}")

        return console_template

    except Exception as e:
        logger.error(
            f"Failed to create console port template '{console_name}': {str(e)}"
        )
        # Check if logger is at DEBUG level to determine whether to raise or exit
        if logger.isEnabledFor(10):  # DEBUG level is 10
            raise e
        else:
            exit(1)


if __name__ == "__main__":
    # Some basic testing of the functions
    import os
    import logging
    from cml2netbox_pkg.cml_helpers import get_lab
    from virl2_client import ClientLibrary

    logger = logging.getLogger(__name__)
    # Configure logging for standalone execution
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # NetBox configuration
    NETBOX_URL = os.getenv("NETBOX_URL", None)
    NETBOX_TOKEN = os.getenv("NETBOX_API_TOKEN", None)

    if not NETBOX_URL or not NETBOX_TOKEN:
        logger.error(
            "NETBOX_URL and NETBOX_API_TOKEN environment variables must be set"
        )
        raise ValueError("NETBOX_URL and NETBOX_API_TOKEN must be set")

    logger.info(f"Connecting to NetBox at: {NETBOX_URL}")
    nb = pynetbox.api(NETBOX_URL, token=NETBOX_TOKEN)
    # Verify connection is working. Will raise an error if not
    try:
        nb.status()
        logger.info("Successfully connected to NetBox")
    except Exception as e:
        logger.error(f"Failed to connect to NetBox: {e}")
        raise

    # Example usage
    lab_name = os.environ.get("LAB_NAME", "Default Lab")
    logger.info(f"Running NetBox helpers example with lab: {lab_name}")

    site = get_or_create_site(nb, lab_name)
    logger.info(f"Using site: {site.name}")

    cml2_client = ClientLibrary(ssl_verify=False)
    lab = get_lab(cml2_client, lab_name)

    nodes = lab.nodes()
    logger.info(f"Lab '{lab.title}' (ID: {lab.id}) found with {len(nodes)} nodes.")

    # Example CML node
    if nodes:
        example_node = nodes[0]
        logger.info(f"Processing example node: {example_node.label}")

        device = get_or_create_device_from_cml_node(nb, example_node, site)
        logger.info(f"Device in NetBox: {device.name} (ID: {device.id})")

        node = example_node
        links = node.links()
    else:
        logger.warning("No nodes found in lab")
