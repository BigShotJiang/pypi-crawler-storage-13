#!/usr/bin/env python3
"""
CML2NetBox CLI Tool

A command-line interface for synchronizing Cisco Modeling Labs (CML)
topologies and device types with NetBox.
"""

import click
from cml2netbox_pkg.cml_helpers import (
    get_all_node_definitions,
    get_lab,
    get_node_definition_by_id,
)
from cml2netbox_pkg.netbox_helpers import (
    create_nb_device_type,
    get_or_create_device_from_cml_node,
    get_or_create_site,
    update_device_interfaces_from_cml_node,
    update_primary_ipv4_address_from_cml_node,
    connect_cables_from_cml_node,
)
from .cli_utilities import Config, validate_config_or_abort
from .cli_logging import setup_logging, get_logger

try:
    from . import __version__
except ImportError:
    # Fallback for when running directly
    __version__ = "0.1.0"


@click.group()
@click.version_option(version=__version__)
@click.option("--cml2-url", help="CML server URL (e.g., https://10.1.20.10)")
@click.option("--cml2-user", help="CML username")
@click.option("--cml2-pass", help="CML password")
@click.option(
    "--cml2-verify-ssl",
    type=bool,
    default=None,
    help="Verify CML SSL certificate (default: True)",
)
@click.option("--netbox-url", help="NetBox server URL")
@click.option(
    "--netbox-api-token", help="NetBox API token (must have READ/WRITE permissions)"
)
@click.option(
    "--netbox-verify-ssl",
    type=bool,
    default=None,
    help="Verify NetBox SSL certificate (default: True)",
)
@click.option(
    "-v", "--verbose", is_flag=True, help="Enable verbose logging (DEBUG level)"
)
@click.pass_context
def cml2netbox(
    ctx,
    cml2_url,
    cml2_user,
    cml2_pass,
    cml2_verify_ssl,
    netbox_url,
    netbox_api_token,
    netbox_verify_ssl,
    verbose,
):
    """
    CML2NetBox - Sync Cisco Modeling Labs with NetBox

    This tool helps synchronize CML topologies and device types with NetBox,
    a leading open source IPAM and DCIM solution.

    Configuration can be provided via:\n
    1. Environment variables (CML2_*, NETBOX_*) or VIRL2_* variants for CML\n
    2. .env file in the current directory\n
    3. Command line options (shown above)\n
    """
    # Setup logging first
    setup_logging(verbose=verbose)
    logger = get_logger(__name__)
    logger.info("CML2NetBox CLI started")

    # Initialize configuration
    config = Config()

    # Update config with any provided CLI parameters
    cli_params = {
        "cml2_url": cml2_url,
        "cml2_user": cml2_user,
        "cml2_pass": cml2_pass,
        "cml2_verify_ssl": cml2_verify_ssl,
        "netbox_url": netbox_url,
        "netbox_api_token": netbox_api_token,
        "netbox_verify_ssl": netbox_verify_ssl,
    }
    config.update_from_click_params(**cli_params)

    # Store config in context for subcommands
    ctx.ensure_object(dict)
    ctx.obj["config"] = config


@cml2netbox.group()
@click.pass_context
def sync(ctx):
    """
    Synchronization commands for CML and NetBox integration.
    """
    pass


@sync.command()
@click.argument("lab_name", required=False)
@click.option(
    "--lab-id", help="CML Lab ID (required when multiple labs have the same name)"
)
@click.pass_context
def lab(ctx, lab_name, lab_id):
    """
    Sync CML lab topology with NetBox.

    This command will synchronize a CML lab topology with NetBox,
    creating devices, interfaces, and connections as needed.

    LAB_NAME: The name/title of the CML lab to synchronize. Can also be
    provided via LAB_NAME environment variable.
    """
    logger = get_logger(__name__)
    config = ctx.obj["config"]

    # Update lab configuration from CLI parameters
    lab_params = {
        "lab_name": lab_name,
        "lab_id": lab_id,
    }
    config.update_lab_config(**lab_params)

    # Validate configuration (lab name is required for lab sync)
    validate_config_or_abort(config, require_lab_name=True)

    logger.info("Starting lab topology synchronization")
    logger.info(f"CML Server: {config.cml2_url}")
    logger.info(f"NetBox Server: {config.netbox_url}")
    logger.info(f"Lab Name: {config.lab_name}")
    if getattr(config, "lab_id", None):
        logger.info(f"Lab ID: {config.lab_id}")

    click.echo("🔄 Starting lab topology synchronization...")
    click.echo(f"📡 CML Server: {config.cml2_url}")
    click.echo(f"🗄️  NetBox Server: {config.netbox_url}")
    click.echo(f"🧪 Lab Name: {config.lab_name}")
    if getattr(config, "lab_id", None):
        click.echo(f"🔍 Lab ID: {config.lab_id}")
    click.echo("Beginning lab synchronization now.")

    # Lookup lab in CML
    lab = get_lab(config.cml2_client, config.lab_name, config.lab_id)

    # Lookup or create site in NetBox
    site = get_or_create_site(config.netbox_client, lab.title)

    # Process the nodes in the lab to add to NetBox
    nodes = lab.nodes()

    # Create all devices in NetBox from CML
    click.echo(f"Adding {len(nodes)} nodes from CML lab '{lab.title}' to NetBox")
    for i, node in enumerate(nodes, 1):
        if i % 5 == 0:
            click.echo(f"📊 Processed {i}/{len(nodes)} devices...")

        # Create the device in NetBox from the CML Node
        try:
            device = get_or_create_device_from_cml_node(
                config.netbox_client, node, site
            )
        # Look for TypeError to indicate a missing device-type in NetBox for the node
        except TypeError as e:
            if e.args and "Device type not found in NetBox" in e.args[0]:
                logger.warning(
                    f"Device type '{node.node_definition}' not found in NetBox, creating it."
                )
                # Get the Node Definition from CML
                node_definition = get_node_definition_by_id(
                    config.cml2_client, node.node_definition
                )

                # Create the Device Type in NetBox
                create_nb_device_type(config.netbox_client, node_definition)

                # Retry creating the device
                try:
                    device = get_or_create_device_from_cml_node(
                        config.netbox_client, node, site
                    )
                except Exception as e:
                    logger.error(
                        f"Failed to create device for node '{node.label}' after creating device type: {e}"
                    )
                    continue
            else:
                logger.error(
                    f"Failed to create NetBox device for node '{node.label}': {e}"
                )
                continue

        # Update the device interfaces and IP address
        update_device_interfaces_from_cml_node(config.netbox_client, node, device)
        update_primary_ipv4_address_from_cml_node(config.netbox_client, node, device)

    # Now we'll connect cables based on the CML node configurations
    click.echo(
        f"Adding cables for {len(nodes)} nodes from CML lab '{lab.title}' to NetBox"
    )
    for i, node in enumerate(nodes, 1):
        if i % 5 == 0:
            click.echo(f"📊 Processed cables for {i}/{len(nodes)} devices...")
        connect_cables_from_cml_node(config.netbox_client, node)

    logger.info(f"Completed synchronization of {len(nodes)} nodes to NetBox")


@sync.command(name="device-types")
@click.option(
    "--include-node-def",
    "filter_node_definitions",
    multiple=True,
    help="Include only specific node definition IDs (e.g., 'iol-xe'). Can be specified multiple times.",
    default=None,
)
@click.pass_context
def device_types(ctx, filter_node_definitions):
    """
    Sync CML device types with NetBox device types.

    This command will synchronize CML node definitions with NetBox
    device types, ensuring consistent device models across both systems.
    """
    logger = get_logger(__name__)
    config = ctx.obj["config"]

    # Validate configuration
    validate_config_or_abort(config)

    logger.info("Starting device types synchronization")
    logger.info(f"CML Server: {config.cml2_url}")
    logger.info(f"NetBox Server: {config.netbox_url}")

    click.echo("🔄 Starting device types synchronization...")
    click.echo(f"📡 CML Server: {config.cml2_url}")
    click.echo(f"🗄️  NetBox Server: {config.netbox_url}")
    click.echo("Beginning Device Type Synchronization...")

    # Get all node definitions from CML
    results = {}
    node_definitions = get_all_node_definitions(config.cml2_client)

    # for node_id, node_def in node_definitions.items():
    for i, node_definition in enumerate(node_definitions):
        if i % 5 == 0:
            click.echo(
                f"📊 Processed device types for {i}/{len(node_definitions)} node definitions..."
            )

        node_definition_id = node_definition.get("id", "unknown")

        # Skip if filtering and node not in filter list
        if (
            filter_node_definitions
            and node_definition_id not in filter_node_definitions
        ):
            logger.debug(
                f"Skipping node definition {node_definition_id} (not in filter list)"
            )
            continue

        # Create NetBox device type
        result = create_nb_device_type(config.netbox_client, node_definition)
        results[node_definition_id] = result is not None

        if result:
            logger.info(f"Successfully processed node: {node_definition_id}")
        else:
            logger.error(f"Failed to process node: {node_definition_id}")

    # Print result details
    click.echo("\nDevice Type Synchronization Results:")
    click.echo("-" * 60)
    click.echo(f"{"Node ID":<30} Status")
    for node_definition_id, success in results.items():
        status = "✅ SUCCESS" if success else "❌ FAILED"
        click.echo(f"{node_definition_id:<30} {status}")


if __name__ == "__main__":
    cml2netbox()
