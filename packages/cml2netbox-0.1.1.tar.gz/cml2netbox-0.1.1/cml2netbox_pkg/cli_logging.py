"""
Logging configuration for CML2NetBox CLI tool.
"""

import logging
import sys
from datetime import datetime
from pathlib import Path


def setup_logging(verbose: bool = False) -> None:
    """
    Setup logging configuration for the CLI tool.

    Args:
        verbose: If True, set log level to DEBUG. Otherwise, use INFO.
    """
    # Generate timestamp for log filename
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    log_filename = f"{timestamp}-cml2netbox.log"
    log_path = Path.cwd() / log_filename

    # Set log level based on verbose flag
    log_level = logging.DEBUG if verbose else logging.INFO

    # Create formatter
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Setup file handler
    file_handler = logging.FileHandler(log_path)
    file_handler.setLevel(log_level)
    file_handler.setFormatter(formatter)

    # Setup console handler for errors and warnings
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(logging.ERROR)
    console_handler.setFormatter(formatter)

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)

    # Clear any existing handlers
    root_logger.handlers.clear()

    # Add handlers
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    # Log the initial setup
    logger = logging.getLogger(__name__)
    logger.info(f"Logging initialized - Log file: {log_path}")
    logger.info(f"Log level: {'DEBUG' if verbose else 'INFO'}")


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for the given name.

    Args:
        name: Logger name, typically __name__ from the calling module.

    Returns:
        Configured logger instance.
    """
    return logging.getLogger(name)
