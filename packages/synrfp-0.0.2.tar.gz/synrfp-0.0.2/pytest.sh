#!/bin/bash

pytest tests