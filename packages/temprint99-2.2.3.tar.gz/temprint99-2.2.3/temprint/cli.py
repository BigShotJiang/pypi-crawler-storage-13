import os
import json
from .core.tempprint import (
    tprint, temp_print, inline_print, overwrite_print, line, header, box,
    success, error, warn, highlight, logo_temp_live
)
from .core.file import read_file, create_txt, create_py, edit_file
from .core.project import create_python_project
from .core.terminal import (
    list_files, delete_file, rename_file, copy_file, move_file,
    change_dir, goto_sdcard
)
from .core.ai import ai_generate, ai_explain_file, ai_summarize_file

HISTORY_FILE = "ai_history.json"

# Load AI history
if os.path.exists(HISTORY_FILE):
    with open(HISTORY_FILE, "r") as f:
        ai_sessions = json.load(f)
else:
    ai_sessions = []

# ---------------------------
# ASK AI FUNCTION
# ---------------------------
def ask_ai(prompt):
    global ai_sessions
    ai_sessions.append({"role": "Me", "text": prompt})

    # Prepare context for last 10 messages
    context = ""
    for msg in ai_sessions[-10:]:
        context += f"{msg['role']}: {msg['text']}\n"

    # Call AI
    response = ai_generate(context)

    ai_sessions.append({"role": "AI", "text": response})

    # Save to file
    with open(HISTORY_FILE, "w") as f:
        json.dump(ai_sessions, f, indent=2)

    return response

# ---------------------------
# CLEAR SCREEN
# ---------------------------
def clear():
    os.system("cls" if os.name == "nt" else "clear")

# ---------------------------
# MAIN MENU
# ---------------------------
def main_menu():
    print("\n=== TEMPRINT ===")
    print("1) Ask AI")
    print("2) AI Explain File")
    print("3) AI Summarize File")
    print("4) Automation Project")
    print("5) Create TXT")
    print("6) Create PY")
    print("7) Edit File")
    print("8) Create Folder / Project")
    print("9) List Files")
    print("10) Delete File")
    print("11) Rename File")
    print("12) Copy File")
    print("13) Move File")
    print("14) Change Directory")
    print("15) /sdcard")
    print("16) Read File")
    print("17) Print Tools")
    print("18) Clear AI History")
    print("0) Exit")    
    return input("Select: ")

# ---------------------------
# PRINT TOOL MENU
# ---------------------------
def print_menu():
    while True:
        clear()
        print("\n=== PRINT TOOLS ===")
        print("1) temp_print")
        print("2) inline_print")
        print("3) overwrite_print")
        print("4) line")
        print("5) header")
        print("6) box")
        print("7) success")
        print("8) error")
        print("9) warning")
        print("10) highlight")
        print("11) logo_temp_live")
        print("12) Back")
        choice = input("Choose: ")

        if choice == "1":
            temp_print(input("Text: "), 2)
        elif choice == "2":
            inline_print(input("Text: "))
        elif choice == "3":
            overwrite_print(input("Text: "))
        elif choice == "4":
            line()
        elif choice == "5":
            header(input("Header: "))
        elif choice == "6":
            box(input("Text: "))
        elif choice == "7":
            success(input("Text: "))
        elif choice == "8":
            error(input("Text: "))
        elif choice == "9":
            warn(input("Text: "))
        elif choice == "10":
            highlight(input("Text: "))
        elif choice == "11":
            logo = input("Enter multiline logo:\n")
            r = int(input("Repeat: "))
            d = float(input("Delay: "))
            logo_temp_live(logo, r, d)
        elif choice == "12":
            break
        else:
            print("Invalid option.")
            input("Press Enter to continue...")

def project_generator():

    import os, tempfile, zipfile, json, ast, difflib, shutil

    header("UNIVERSAL PROJECT GENERATOR v4.1 (Dynamic Engine)")

    path = input("Enter file/folder/zip path: ").strip()

    # ---------- TYPE DETECTOR ----------
    def detect_input_type(path):
        if not os.path.exists(path): return "missing"
        if os.path.isdir(path): return "folder"

        ext = os.path.splitext(path)[1].lower()
        if ext in [".zip"]: return "zip"
        if ext in [".py"]: return "python"
        if ext in [".json"]: return "json"
        if ext in [".html", ".htm"]: return "html"
        if ext in [".txt"]: return "text"

        # Try detect manually
        try:
            data = open(path, "r", encoding="utf-8", errors="ignore").read(400)
            if "<html" in data.lower(): return "html"
            if data.strip().startswith("{"): return "json"
            if "def " in data or "import " in data: return "python"
        except:
            pass

        return "custom"

    ftype = detect_input_type(path)
    if ftype == "missing":
        error("Path not found.")
        return

    temp = tempfile.mkdtemp(prefix="pg4_")
    loaded_files = {}  # filename -> content

    # ---------- LOAD ----------
    if ftype == "zip":
        with zipfile.ZipFile(path, "r") as z:
            z.extractall(temp)
        for root, dirs, files in os.walk(temp):
            for f in files:
                p = os.path.join(root, f)
                rel = os.path.relpath(p, temp)
                loaded_files[rel] = open(p, "r", encoding="utf-8", errors="ignore").read()

    elif ftype == "folder":
        for root, dirs, files in os.walk(path):
            for f in files:
                p = os.path.join(root, f)
                rel = os.path.relpath(p, path)
                loaded_files[rel] = open(p, "r", encoding="utf-8", errors="ignore").read()

    else:
        loaded_files[os.path.basename(path)] = open(path, "r", encoding="utf-8", errors="ignore").read()

    box("FILES LOADED:\n" + "\n".join(loaded_files.keys()))

    # ---------- ANALYSIS ----------
    reports = []
    for fname, code in loaded_files.items():
        try:
            rep = ai_explain_file(path if len(loaded_files)==1 else fname)
        except:
            rep = ai_generate(f"Analyze file `{fname}` for bugs, missing parts, logic flaws:\n\n{code}")
        reports.append(f"=== {fname} ===\n{rep}")

    analysis = "\n".join(reports)
    box("ANALYSIS:\n" + analysis[:8000])

    # ---------- FEATURE & MISSING FILE DETECTION ----------
    features = ai_generate(
        "Based on this project analysis, list:\n"
        "- Needed new features\n"
        "- Missing files\n"
        "- Missing modules\n"
        "- Missing functions\n"
        "- Required project architecture\n"
        "Return strictly as a bullet list."
        "\n\nANALYSIS:\n" + analysis
    )

    # Save idea memory
    idea_text = "=== ANALYSIS ===\n" + analysis + "\n\n=== FEATURES & STRUCTURE ===\n" + features
    open("idea.txt", "w", encoding="utf-8").write(idea_text)
    success("Saved idea.txt")

    # ---------- AI DYNAMIC PROJECT STRUCTURE ----------
    structure_text = ai_generate(
        "Using idea.txt, generate a FULL PROJECT FILE TREE.\n"
        "Do NOT include code, only filenames.\n"
        "Use UNIX-style paths.\n"
        "Include ALL required missing files.\n"
        "Be accurate.\n\n"
        + idea_text
    )

    # Parse structure
    file_list = []
    for line in structure_text.splitlines():
        line=line.strip().replace("-","").strip()
        if "." in line:
            if "/" in line:
                file_list.append(line)
            else:
                file_list.append(line)

    file_list = list(set(file_list))  # remove duplicates

    # Add original files
    for fname in loaded_files.keys():
        if fname not in file_list:
            file_list.append(fname)

    box("PROJECT FILE TREE:\n" + "\n".join(file_list))

    # ---------- FILE GENERATION ----------
    rewritten = {}

    for fname in file_list:
        if fname in loaded_files:
            original = loaded_files[fname]
        else:
            original = ""

        temp_print(f"Generating {fname}...", 0.3)

        prompt = f"""
Generate full code for `{fname}`.
Use idea.txt for logic, structure, and missing features.
Rules:
- Do NOT generate markdown
- Do NOT generate explanations
- Return ONLY code
- Keep original logic if file existed
- Improve, fix, complete

Original content (if any):
{original}
"""
        try:
            new_code = ai_generate(prompt)
        except:
            new_code = original

        rewritten[fname] = new_code

    # ---------- VALIDATION ----------
    def validate(fname, code):
        if fname.endswith(".py"):
            try:
                ast.parse(code)
                return True, "OK"
            except Exception as e:
                return False, str(e)
        if fname.endswith(".json"):
            try:
                json.loads(code)
                return True, "OK"
            except Exception as e:
                return False, str(e)
        if fname.endswith(".html"):
            if "<html" in code.lower(): return True, "OK"
            return True, "OK"
        return True, "OK"

    # retry 3 times
    for i in range(3):
        invalid = []
        for fname, code in rewritten.items():
            ok, msg = validate(fname, code)
            if not ok:
                invalid.append((fname, msg))

        if not invalid:
            break

        warn("Some files invalid; retrying fixes...")
        for fname, msg in invalid:
            rewritten[fname] = ai_generate(
                f"Fix syntax errors in `{fname}`:\nERROR: {msg}\nCONTENT:\n{rewritten[fname]}"
            )

    # ---------- PREVIEW ----------
    previews = []
    for fname in rewritten:
        old = loaded_files.get(fname, "").splitlines()
        new = rewritten[fname].splitlines()
        diff = "\n".join(difflib.unified_diff(
            old, new, fromfile="old/"+fname, tofile="new/"+fname, lineterm=""
        ))
        previews.append(f"=== {fname} ===\n{diff}")

    box("PREVIEW:\n" + "\n".join(previews))

    # ---------- COMMIT ----------
    if input("Type COMMIT to save files: ").strip() != "COMMIT":
        warn("Aborted.")
        shutil.rmtree(temp, ignore_errors=True)
        return

    target = input("Output folder (blank=current): ").strip() or os.getcwd()
    os.makedirs(target, exist_ok=True)

    for fname, code in rewritten.items():
        out_path = os.path.join(target, fname)
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        open(out_path, "w", encoding="utf-8").write(code)
        tprint("Wrote: " + out_path)

    success("Done! your Project Created.")
    shutil.rmtree(temp, ignore_errors=True)
# ---------------------------
# MAIN CLI LOOP
# ---------------------------
def main():
    clear()
    print("Welcome to Temprint99 CLI")

    while True:
        choice = main_menu()

        if choice == "1":
            # Persistent AI chat loop
            print("\n=== AI Chat (type 'exit' or 'back' to return to main menu) ===")
            while True:
                prompt = input("Me: ")
                if prompt.lower() in ["exit", "back"]:
                    break
                response = ask_ai(prompt)
                print(f"AI: {response}")

        elif choice == "2":
            path = input("File: ")
            print(ai_explain_file(path))
        elif choice == "3":
            path = input("File: ")
            print(ai_summarize_file(path))
        elif choice == "4":
            project_generator()
        elif choice == "5":
            path = input("File name: ")
            code = input("Code: ")
            print(create_py(path, code))
        elif choice == "6":
            path = input("File: ")
            print(edit_file(path))
        elif choice == "7":
            name = input("Project / Folder name: ")
            print(create_python_project(name))
        elif choice == "8":
            print(list_files())
        elif choice == "9":
            path = input("File: ")
            print(delete_file(path))
        elif choice == "10":
            old = input("Old: ")
            new = input("New: ")
            print(rename_file(old, new))
        elif choice == "11":
            src = input("Source: ")
            dst = input("Target: ")
            print(copy_file(src, dst))
        elif choice == "12":
            src = input("Source: ")
            dst = input("Target: ")
            print(move_file(src, dst))
        elif choice == "13":
            path = input("Path: ")
            print(change_dir(path))
        elif choice == "14":
            print(goto_sdcard())
        elif choice == "15":
            path = input("Path: ")
            print(read_file(path))
        elif choice == "16":
            print_menu()
        elif choice == "0":
            print("Goodbye.")
            break
        elif choice == "17":
            ai_sessions.clear()
            if os.path.exists(HISTORY_FILE):
                os.remove(HISTORY_FILE)
            print("AI chat history cleared.")
        else:
            print("Invalid option.")
            input("Press Enter to continue...")