from setuptools import setup, find_packages

setup(
    name="anshutils", # Unique name for PyPI
    version="0.2.0",
    packages=find_packages(), # This will automatically detect all packages 
    #by going through all subfolders starting from the root package folder (i.e "utils")
    install_requires=[
        # Add any dependencies your package needs here
    ],
    python_requires='>=3.6',
    author="Ansh Lamba",
    author_email="ansh.lamba@example.com"
)