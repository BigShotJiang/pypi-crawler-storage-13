import requests
import json
from .core import unlock
from .regions import SUBDOMAINS


class MiUnlockClient:
    def __init__(
        self,
        cookies: dict,
        pcId: str,
        token: str,
        product: str,
        method: str,
        regionConfig: str = "Singapore",
    ):
        self.cookies = cookies
        self.pcId = pcId
        self.token = token
        self.product = product
        self.method = method
        self.regionConfig = regionConfig

        self.session = requests.Session()
        self.subdomain = SUBDOMAINS[regionConfig]
        self.ssecurity = self._get_ssecurity()

    def _get_ssecurity(self):
        url = f"https://account.xiaomi.com/pass/serviceLogin?sid=unlockApi&{self.method}=true"
        r = self.session.get(url, cookies=self.cookies)
        if not r.history:
            raise ValueError("Invalid cookies or method")
        pragma = r.history[0].headers["extension-pragma"]
        data = json.loads(pragma)
        self.cookies.update(r.cookies.get_dict())
        return data["ssecurity"]

    def unlock(self):
        return unlock(
            self.session,
            self.subdomain,
            self.ssecurity,
            self.cookies,
            self.token,
            self.product,
            self.pcId
        )