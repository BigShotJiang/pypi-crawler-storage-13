## cdf 

### Fixed

- updated `AgentCRUD` capabilities
- removed repeated delete action in `Robotics` resource

## templates

No changes.