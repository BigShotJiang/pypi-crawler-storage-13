# ismoiloff

**OGSTH system access module with machine-code authentication**  

`ismoiloff` is a Python library that allows you to securely access OGSTH remote code system to the ISMOILOFF's code base. Designed for CLI and programmatic use.

---

## Features

- Using ismoiloff's codes without a lot troubles
- ISMOILOFF ning kodlarini ishlatish.

---

## Installation

You can install via **pip**:

```bash
pip install ismoiloff
