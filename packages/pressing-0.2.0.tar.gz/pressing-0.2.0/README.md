# pressing

A Python automation module for simulating keyboard and pixel actions.

```python
import pressing
from pressing import (
    press,
    release,
    click,
    run_macro,
    pressed,
    pixel,
    pixel_color,
    pixel_is,
    write,
    hotkey,
    wait,
    wait_key,
    hold,
    mouse_click,
    mouse_move,
    creator,
)

# Change typing speed
pressing.typewait = 0.05

# Display creator info
creator()

# Keyboard actions
press("shift")
click("a")
release("shift")

write("hello world")
hotkey("ctrl", "s")

# Run a macro list
run_macro(["a", "b", "c", "enter"])

# Wait for a key press
wait_key("space")

# Pixel checks
color = pixel_color(500, 300)
print("Pixel color:", color)

if pixel_is(500, 300, (255, 0, 0)):
    print("That pixel is red.")

# Pixel + RGB tuple check
if pixel((500, 300), (255, 255, 255)):
    print("Match!")

# Mouse actions
mouse_move(300, 400)
mouse_click("left")