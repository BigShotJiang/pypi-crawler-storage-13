from pynput.keyboard import Key, Controller
import time
import keyboard
import win32gui
import win32api
import win32con

typewait = 0.1
kb = Controller()

def safe(keyname):
    return getattr(Key, keyname, None)

SPECIAL_KEYS = {
    "alt": safe("alt"),
    "lalt": safe("alt_l"),
    "ralt": safe("alt_r"),
    "ctrl": safe("ctrl"),
    "lctrl": safe("ctrl_l"),
    "rctrl": safe("ctrl_r"),
    "shift": safe("shift"),
    "lshift": safe("shift_l"),
    "rshift": safe("shift_r"),
    "cmd": safe("cmd"),
    "win": safe("cmd"),
    "meta": safe("cmd"),
    "super": safe("cmd"),

    "tab": safe("tab"),
    "enter": safe("enter"),
    "esc": safe("esc"),
    "escape": safe("esc"),
    "backspace": safe("backspace"),
    "delete": safe("delete"),
    "del": safe("delete"),
    "insert": safe("insert"),
    "home": safe("home"),
    "end": safe("end"),
    "pageup": safe("page_up"),
    "pagedown": safe("page_down"),
    "up": safe("up"),
    "down": safe("down"),
    "left": safe("left"),
    "right": safe("right"),

    " ": safe("space"),
    "space": safe("space"),

    **{f"f{i}": safe(f"f{i}") for i in range(1, 25)},

    "capslock": safe("caps_lock"),
    "numlock": safe("num_lock"),
    "scrolllock": safe("scroll_lock"),
    "pause": safe("pause"),
    "printscreen": safe("print_screen"),
}

def pixel(x, y):
    """
    pixel reader using Win32 GetPixel.
    Returns (R, G, B)
    """
    hdc = win32gui.GetWindowDC(win32gui.GetDesktopWindow())
    color = win32gui.GetPixel(hdc, x, y)
    win32gui.ReleaseDC(win32gui.GetDesktopWindow(), hdc)

    return (
        color & 0xff,
        (color >> 8) & 0xff,
        (color >> 16) & 0xff
    )


def pixel_is(x, y, rgb):
    """True if pixel at (x, y) matches rgb tuple."""
    return pixel(x, y) == tuple(rgb)


def pixel(pos, rgb):
    """
    Block until pixel matches rgb.
    Uses win32 pixel reading.
    """
    x, y = pos
    target = tuple(rgb)

    while True:
        if pixel(x, y) == target:
            return True
        time.sleep(0.001)


def pixel_color(x, y):
    """Return RGB of pixel instantly."""
    return pixel(x, y)

def pressed(k):
    """Return True if key is currently held."""
    try:
        return keyboard.is_pressed(k)
    except:
        return False


def wait_key(k):
    print(f"Waiting for key: {k}")
    keyboard.wait(k)

def get_key_obj(k):
    k_lower = str(k).lower()
    if k_lower in SPECIAL_KEYS and SPECIAL_KEYS[k_lower] is not None:
        return SPECIAL_KEYS[k_lower]
    return k

def run_macro(cmd_list):
    import pressing

    for cmd in cmd_list:
        time.sleep(pressing.typewait)

        if cmd.endswith("+"):
            kb.press(get_key_obj(cmd[:-1]))
            continue

        if cmd.endswith("-"):
            kb.release(get_key_obj(cmd[:-1]))
            continue

        if len(cmd) == 1 or cmd.lower() in SPECIAL_KEYS:
            key = get_key_obj(cmd)
            kb.press(key)
            kb.release(key)
            continue

        for ch in cmd:
            kb.press(ch)
            kb.release(ch)

def creator():
    print("Pressing was created by Mongoose")


def press(character):
    if isinstance(character, list):
        cmds = [f"{c}+" for c in character]
    else:
        cmds = [f"{character}+"]
    run_macro(cmds)


def release(character):
    if isinstance(character, list):
        cmds = [f"{c}-" for c in character]
    else:
        cmds = [f"{character}-"]
    run_macro(cmds)


def click(character):
    if isinstance(character, list):
        cmds = [f"{c}" for c in character]
    else:
        cmds = [f"{character}"]
    run_macro(cmds)


def write(text):
    """Type instantly using click() — no keyboard.write delay."""
    for ch in text:
        click(ch)


def hotkey(keys):
    """Press multiple keys together."""
    for k in keys:
        press(k)
    for k in reversed(keys):
        release(k)


def hold(key, seconds):
    press(key)
    time.sleep(seconds)
    release(key)
