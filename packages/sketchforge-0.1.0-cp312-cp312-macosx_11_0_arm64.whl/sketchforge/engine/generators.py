# Handlers for @fastapi (Forward)
