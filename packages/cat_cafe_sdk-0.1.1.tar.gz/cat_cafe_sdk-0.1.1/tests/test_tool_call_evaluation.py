"""Test tool call evaluation functionality."""

import pytest
from cat_cafe.sdk import (
    tool_correctness_evaluator,
    basic_tool_correctness_evaluator,
    exact_tool_correctness_evaluator,
    ToolCorrectnessConfig,
    match_tool_calls,
    EvaluationContext,
    ToolCall,
    generate,
    evaluate,
)
from cat_cafe.sdk.client import DatasetExample


class TestToolCallMatching:
    """Test core tool call matching algorithms."""

    def test_exact_matching_perfect(self):
        """Test exact matching with perfect tool calls."""
        expected = [ToolCall(name="search", args={"query": "python", "limit": 10})]
        actual = [ToolCall(name="search", args={"query": "python", "limit": 10})]

        result = match_tool_calls(expected, actual, "exact")

        assert result.overall_score == 1.0
        assert result.precision == 1.0
        assert result.recall == 1.0
        assert len(result.matches) == 1
        assert result.matches[0].match_type == "exact"
        assert len(result.extra_tools) == 0
        assert len(result.missing_tools) == 0

    def test_exact_matching_wrong_order(self):
        """Test exact matching fails with wrong order."""
        expected = [
            ToolCall(name="search", args={"query": "python"}),
            ToolCall(name="summarize", args={"text": "results"}),
        ]
        actual = [
            ToolCall(name="summarize", args={"text": "results"}),
            ToolCall(name="search", args={"query": "python"}),
        ]

        result = match_tool_calls(expected, actual, "exact")

        assert result.overall_score == 0.0
        assert result.precision == 0.0
        assert result.recall == 0.0
        assert all(m.match_type == "partial" for m in result.matches)

    def test_strict_matching_order_independent(self):
        """Test strict matching succeeds regardless of order."""
        expected = [
            ToolCall(name="search", args={"query": "python"}),
            ToolCall(name="summarize", args={"text": "results"}),
        ]
        actual = [
            ToolCall(name="summarize", args={"text": "results"}),
            ToolCall(name="search", args={"query": "python"}),
        ]

        result = match_tool_calls(expected, actual, "strict")

        assert result.overall_score == 1.0
        assert result.precision == 1.0
        assert result.recall == 1.0
        assert all(m.match_type == "exact" for m in result.matches)

    def test_fuzzy_matching_partial_similarity(self):
        """Test fuzzy matching gives partial credit."""
        expected = [ToolCall(name="search", args={"query": "python", "limit": 10})]
        actual = [ToolCall(name="search", args={"query": "python tutorials", "limit": 5})]

        result = match_tool_calls(expected, actual, "fuzzy")

        assert 0.5 <= result.overall_score < 1.0  # Partial similarity
        assert result.precision == 1.0
        assert result.matches[0].match_type == "partial"
        assert result.matches[0].similarity_score > 0.5

    def test_fuzzy_matching_different_tool_names(self):
        """Test fuzzy matching with different tool names."""
        expected = [ToolCall(name="search", args={"query": "python"})]
        actual = [ToolCall(name="lookup", args={"query": "python"})]

        result = match_tool_calls(expected, actual, "fuzzy")

        # Should get some similarity for matching arguments but different names
        assert result.overall_score < 0.5  # Below fuzzy threshold
        assert result.matches[0].match_type == "missing"  # Below threshold

    def test_extra_tools_handling(self):
        """Test handling of extra (unexpected) tools."""
        expected = [ToolCall(name="search", args={"query": "python"})]
        actual = [
            ToolCall(name="search", args={"query": "python"}),
            ToolCall(name="extra", args={"param": "value"}),
        ]

        result = match_tool_calls(expected, actual, "strict")

        assert result.overall_score == 1.0  # Expected call was found
        assert result.precision == 0.5  # Only half of actual calls were expected
        assert result.recall == 1.0  # All expected calls were found
        assert len(result.extra_tools) == 1
        assert result.extra_tools[0].name == "extra"

    def test_missing_tools_handling(self):
        """Test handling of missing (expected but not called) tools."""
        expected = [
            ToolCall(name="search", args={"query": "python"}),
            ToolCall(name="missing", args={"param": "value"}),
        ]
        actual = [ToolCall(name="search", args={"query": "python"})]

        result = match_tool_calls(expected, actual, "strict")

        assert result.overall_score == 0.5  # Only half of expected calls found
        assert result.precision == 1.0  # All actual calls were expected
        assert result.recall == 0.5  # Only half of expected calls found
        assert len(result.missing_tools) == 1
        assert result.missing_tools[0].name == "missing"

    def test_empty_lists(self):
        """Test matching with empty lists."""
        # Both empty
        result = match_tool_calls([], [], "strict")
        assert result.overall_score == 1.0
        assert result.precision == 1.0
        assert result.recall == 1.0

        # Only expected empty
        result = match_tool_calls([], [ToolCall(name="unexpected", args={})], "strict")
        assert result.precision == 0.0
        assert result.recall == 1.0  # No expected calls to miss

        # Only actual empty
        result = match_tool_calls([ToolCall(name="expected", args={})], [], "strict")
        assert result.precision == 1.0  # No false positives
        assert result.recall == 0.0


class TestToolCorrectnessEvaluator:
    """Test the tool correctness evaluator."""

    def test_perfect_tool_calls(self):
        """Test evaluator with perfect tool call matching."""
        context = EvaluationContext(
            example_id="test-1",
            input={"messages": [{"role": "user", "content": "Search for Python"}]},
            output={"messages": [{"role": "assistant", "content": "Searching..."}]},
            actual_output={"messages": [{"role": "assistant", "content": "I found some Python resources"}]},
            expected_tool_calls=[ToolCall(name="search", args={"query": "python"})],
            actual_tool_calls=[ToolCall(name="search", args={"query": "python"})],
        )

        result = tool_correctness_evaluator(context)

        assert result.score == 1.0
        assert result.metadata["precision"] == 1.0
        assert result.metadata["recall"] == 1.0
        assert result.metadata["mode"] == "strict"
        assert "Perfect match" in result.metadata["reason"]

    def test_no_tool_calls_expected_or_actual(self):
        """Test evaluator when no tool calls are expected or made."""
        context = EvaluationContext(
            example_id="test-2",
            input={"messages": [{"role": "user", "content": "What is 2+2?"}]},
            output={"messages": [{"role": "assistant", "content": "4"}]},
            actual_output={"messages": [{"role": "assistant", "content": "4"}]},
            expected_tool_calls=None,
            actual_tool_calls=None,
        )

        result = tool_correctness_evaluator(context)

        assert result.score == 1.0
        assert "No tool calls expected or made" in result.metadata["reason"]

    def test_unexpected_tool_calls(self):
        """Test evaluator when tool calls are made but none expected."""
        context = EvaluationContext(
            example_id="test-3",
            input={"messages": [{"role": "user", "content": "Hello"}]},
            output={"messages": [{"role": "assistant", "content": "Hi!"}]},
            actual_output={"messages": [{"role": "assistant", "content": "Hi there!"}]},
            expected_tool_calls=None,
            actual_tool_calls=[ToolCall(name="greet", args={})],
        )

        result = tool_correctness_evaluator(context)

        assert result.score == 0.0
        assert "Unexpected tool calls made" in result.metadata["reason"]
        assert result.metadata["expected_count"] == 0
        assert result.metadata["actual_count"] == 1

    def test_missing_tool_calls(self):
        """Test evaluator when expected tool calls are missing."""
        context = EvaluationContext(
            example_id="test-4",
            input={"messages": [{"role": "user", "content": "Search for Python"}]},
            output={"messages": [{"role": "assistant", "content": "Searching..."}]},
            actual_output={
                "messages": [{"role": "assistant", "content": "I'll look that up"}]
            },  # No actual tool call made
            expected_tool_calls=[ToolCall(name="search", args={"query": "python"})],
            actual_tool_calls=None,
        )

        result = tool_correctness_evaluator(context)

        assert result.score == 0.0
        assert "Missing tool calls" in result.metadata["reason"]
        assert result.metadata["precision"] == 1.0  # No false positives
        assert result.metadata["recall"] == 0.0  # All expected calls missed

    def test_custom_config(self):
        """Test evaluator with custom configuration."""
        context = EvaluationContext(
            example_id="test-5",
            input={"messages": [{"role": "user", "content": "Test"}]},
            output={"messages": [{"role": "assistant", "content": "Result"}]},
            actual_output={"messages": [{"role": "assistant", "content": "Got it"}]},
            expected_tool_calls=[ToolCall(name="test", args={})],
            actual_tool_calls=[ToolCall(name="test", args={})],
        )

        config = ToolCorrectnessConfig(mode="fuzzy", weight_precision=0.7, weight_recall=0.3)
        result = tool_correctness_evaluator(context, config)

        assert result.score == 1.0  # Perfect match
        assert result.metadata["mode"] == "fuzzy"
        assert result.metadata["config"]["weight_precision"] == 0.7

    def test_builtin_evaluators(self):
        """Test the built-in evaluator convenience functions."""
        context = EvaluationContext(
            example_id="test-6",
            input={"messages": [{"role": "user", "content": "Test"}]},
            output={"messages": [{"role": "assistant", "content": "Result"}]},
            actual_output={"messages": [{"role": "assistant", "content": "Got it"}]},
            expected_tool_calls=[ToolCall(name="test", args={})],
            actual_tool_calls=[ToolCall(name="test", args={})],
        )

        # Test basic evaluator
        result_basic = basic_tool_correctness_evaluator(context)
        assert result_basic.metadata["mode"] == "strict"

        # Test exact evaluator
        result_exact = exact_tool_correctness_evaluator(context)
        assert result_exact.metadata["mode"] == "exact"

        # All should give perfect scores for this case
        assert result_basic.score == 1.0
        assert result_exact.score == 1.0


class TestToolCallEvaluationIntegration:
    """Test integration with the evaluation pipeline."""

    def test_evaluate_with_tool_correctness(self):
        """Test using tool correctness evaluator with evaluate() function."""
        # Create evaluation context
        context = EvaluationContext(
            example_id="integration-test",
            input={"messages": [{"role": "user", "content": "Search for AI"}]},
            output={"messages": [{"role": "assistant", "content": "Searching..."}]},
            actual_output={"messages": [{"role": "assistant", "content": "I found some AI resources"}]},
            expected_tool_calls=[ToolCall(name="search", args={"query": "AI"})],
            actual_tool_calls=[ToolCall(name="search", args={"query": "AI"})],
        )

        # Use evaluate() with tool correctness evaluator
        results = evaluate([context], [basic_tool_correctness_evaluator])

        assert len(results) == 1
        result = results[0]

        assert result["example_id"] == "integration-test"
        assert "basic_tool_correctness_evaluator" in result["evaluation_scores"]
        assert result["evaluation_scores"]["basic_tool_correctness_evaluator"] == 1.0

        # Check metadata
        evaluator_meta = result["evaluator_metadata"]["basic_tool_correctness_evaluator"]
        assert evaluator_meta["mode"] == "strict"
        assert evaluator_meta["precision"] == 1.0
        assert evaluator_meta["recall"] == 1.0

    def test_mock_test_function_with_tool_calls(self):
        """Test a mock test function that returns tool call data."""

        def mock_test_function(example: DatasetExample) -> str:
            """Mock test function that simulates tool usage."""
            return "Executed search successfully"

        # Mock the AgentTrace to simulate tool call extraction
        class MockAgentTrace:
            def __init__(self, tools):
                self.tools_called = tools
                self.final_response = "Search completed"

        def mock_test_with_trace(example: DatasetExample) -> MockAgentTrace:
            """Mock test function that returns trace with tool calls."""
            return MockAgentTrace([ToolCall(name="search", args={"query": "test"})])

        # Create dataset example
        dataset_example = DatasetExample(
            input={"messages": [{"role": "user", "content": "Search for test"}]},
            output={"messages": [{"role": "assistant", "content": "Searching..."}]},
            expected_tool_calls=[ToolCall(name="search", args={"query": "test"})],
        )

        # Test context generation
        contexts = generate([dataset_example], mock_test_with_trace)

        assert len(contexts) == 1
        context = contexts[0]
        assert context.actual_tool_calls is not None
        assert len(context.actual_tool_calls) == 1
        assert context.actual_tool_calls[0].name == "search"

        # Test evaluation
        results = evaluate(contexts, [basic_tool_correctness_evaluator])
        assert len(results) == 1
        assert results[0]["evaluation_scores"]["basic_tool_correctness_evaluator"] == 1.0


class TestEdgeCases:
    """Test edge cases and error conditions."""

    def test_invalid_matching_mode(self):
        """Test invalid matching mode raises error."""
        with pytest.raises(ValueError, match="Unknown matching mode"):
            match_tool_calls([], [], "invalid_mode")

    def test_tool_call_with_none_args(self):
        """Test tool calls with None arguments."""
        expected = [ToolCall(name="test", args=None)]
        actual = [ToolCall(name="test", args=None)]

        result = match_tool_calls(expected, actual, "strict")
        assert result.overall_score == 1.0

    def test_tool_call_with_empty_args(self):
        """Test tool calls with empty argument dictionaries."""
        expected = [ToolCall(name="test", args={})]
        actual = [ToolCall(name="test", args={})]

        result = match_tool_calls(expected, actual, "strict")
        assert result.overall_score == 1.0

    def test_complex_argument_structures(self):
        """Test tool calls with complex nested arguments."""
        complex_args = {
            "query": "test",
            "filters": {"type": "document", "date": "2024"},
            "options": ["sort", "limit"],
        }

        expected = [ToolCall(name="complex_search", args=complex_args)]
        actual = [ToolCall(name="complex_search", args=complex_args)]

        result = match_tool_calls(expected, actual, "strict")
        assert result.overall_score == 1.0

    def test_argument_similarity_with_fuzzy_matching(self):
        """Test argument similarity calculation in fuzzy mode."""
        expected = [ToolCall(name="search", args={"query": "python programming"})]
        actual = [ToolCall(name="search", args={"query": "python tutorial"})]

        result = match_tool_calls(expected, actual, "fuzzy")

        # Should get high similarity due to matching tool name and similar query
        assert result.overall_score > 0.5
        assert result.matches[0].similarity_score > 0.5
