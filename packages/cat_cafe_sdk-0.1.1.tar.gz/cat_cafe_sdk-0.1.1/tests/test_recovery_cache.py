"""Tests for experiment recovery cache functionality."""

import json
import tempfile
from pathlib import Path
from datetime import datetime
from unittest.mock import patch, Mock

import pytest

from cat_cafe.sdk import CATCafeClient, Dataset, Example


@pytest.fixture
def temp_cache_dir():
    """Create a temporary directory for cache testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def client_with_cache(temp_cache_dir):
    """Create a client with a temporary cache directory."""
    return CATCafeClient(cache_dir=temp_cache_dir)


@pytest.fixture
def sample_dataset():
    """Create a sample dataset for testing."""
    return Dataset(
        id="test-dataset-123",
        name="Test Dataset",
        description="A test dataset",
        tags=["test"],
        metadata={"key": "value"},
        example_count=3,
        version=1,
        created_at="2024-01-01T00:00:00Z",
        updated_at="2024-01-01T00:00:00Z",
        examples=[
            Example(
                id="ex1",
                input={"messages": [{"role": "user", "content": "Hello"}]},
                output={"messages": [{"role": "assistant", "content": "Hi"}]},
                metadata={"index": 0},
            ),
            Example(
                id="ex2",
                input={"messages": [{"role": "user", "content": "How are you?"}]},
                output={"messages": [{"role": "assistant", "content": "I'm fine"}]},
                metadata={"index": 1},
            ),
            Example(
                id="ex3",
                input={"messages": [{"role": "user", "content": "Goodbye"}]},
                output={"messages": [{"role": "assistant", "content": "Bye"}]},
                metadata={"index": 2},
            ),
        ],
    )


class TestExperimentIDGeneration:
    """Test experiment ID generation."""

    def test_generate_experiment_id_format(self, client_with_cache):
        """Test that generated IDs follow expected format."""
        exp_id = client_with_cache._generate_experiment_id()

        assert exp_id.startswith("exp-")
        parts = exp_id.split("-")
        assert len(parts) == 5  # exp-YYYY-MM-DD-XXXXXX

        # Check date format
        date_str = f"{parts[1]}-{parts[2]}-{parts[3]}"
        datetime.strptime(date_str, "%Y-%m-%d")  # Should not raise

        # Check random part
        assert len(parts[4]) == 6

    def test_generate_unique_ids(self, client_with_cache):
        """Test that multiple IDs are unique."""
        ids = [client_with_cache._generate_experiment_id() for _ in range(10)]
        assert len(set(ids)) == 10  # All should be unique


class TestExperimentMetadataCaching:
    """Test experiment metadata caching."""

    def test_cache_experiment_metadata(self, client_with_cache, sample_dataset):
        """Test caching experiment metadata with dataset snapshot."""
        exp_id = "test-exp-123"
        config = {"name": "Test Experiment", "tags": ["test"]}

        client_with_cache._cache_experiment_metadata(exp_id, sample_dataset, config)

        # Check metadata file exists
        metadata_file = client_with_cache._get_experiment_cache_dir(exp_id) / "metadata.json"
        assert metadata_file.exists()

        # Load and verify content
        with open(metadata_file, "r") as f:
            metadata = json.load(f)

        assert metadata["experiment_id"] == exp_id
        assert metadata["config"] == config
        assert metadata["dataset"]["id"] == "test-dataset-123"
        assert len(metadata["dataset"]["examples"]) == 3
        assert metadata["dataset"]["examples"][0]["id"] == "ex1"

    def test_get_cached_experiment_metadata(self, client_with_cache, sample_dataset):
        """Test retrieving cached experiment metadata."""
        exp_id = "test-exp-123"
        config = {"name": "Test Experiment"}

        # Cache metadata
        client_with_cache._cache_experiment_metadata(exp_id, sample_dataset, config)

        # Retrieve it
        metadata = client_with_cache._get_cached_experiment_metadata(exp_id)

        assert metadata is not None
        assert metadata["experiment_id"] == exp_id
        assert metadata["config"]["name"] == "Test Experiment"
        assert metadata["dataset"]["id"] == "test-dataset-123"

    def test_get_nonexistent_metadata(self, client_with_cache):
        """Test retrieving non-existent metadata returns None."""
        metadata = client_with_cache._get_cached_experiment_metadata("nonexistent")
        assert metadata is None

    def test_has_experiment_cache(self, client_with_cache, sample_dataset):
        """Test checking if experiment cache exists."""
        exp_id = "test-exp-123"

        # Should not exist initially
        assert not client_with_cache._has_experiment_cache(exp_id)

        # Cache metadata
        client_with_cache._cache_experiment_metadata(exp_id, sample_dataset, {})

        # Should exist now
        assert client_with_cache._has_experiment_cache(exp_id)


class TestExampleResultCaching:
    """Test individual example result caching."""

    def test_cache_example_result(self, client_with_cache):
        """Test caching a successful example result."""
        exp_id = "test-exp-123"
        example_id = "ex1"
        result = {"output": "Hello!", "scores": {"accuracy": 0.9}, "duration": 1.5}

        client_with_cache._cache_example_result(exp_id, example_id, result)

        # Check result file exists
        result_file = client_with_cache._get_experiment_cache_dir(exp_id) / "results" / f"{example_id}.json"
        assert result_file.exists()

        # Load and verify content
        with open(result_file, "r") as f:
            cached_result = json.load(f)

        assert cached_result["example_id"] == example_id
        assert cached_result["output"] == "Hello!"
        assert cached_result["scores"]["accuracy"] == 0.9
        assert "cached_at" in cached_result

    def test_cache_example_error(self, client_with_cache):
        """Test caching a failed example."""
        exp_id = "test-exp-123"
        example_id = "ex1"
        error = "Connection timeout"

        client_with_cache._cache_example_error(exp_id, example_id, error)

        # Check error file exists
        error_file = client_with_cache._get_experiment_cache_dir(exp_id) / "results" / f"{example_id}.error"
        assert error_file.exists()

        # Load and verify content
        with open(error_file, "r") as f:
            error_data = json.load(f)

        assert error_data["example_id"] == example_id
        assert error_data["error"] == error
        assert "failed_at" in error_data

    def test_error_file_removed_on_success(self, client_with_cache):
        """Test that error file is removed when example succeeds on retry."""
        exp_id = "test-exp-123"
        example_id = "ex1"

        # First cache an error
        client_with_cache._cache_example_error(exp_id, example_id, "Initial failure")
        error_file = client_with_cache._get_experiment_cache_dir(exp_id) / "results" / f"{example_id}.error"
        assert error_file.exists()

        # Then cache a successful result
        client_with_cache._cache_example_result(exp_id, example_id, {"output": "Success!"})

        # Error file should be gone
        assert not error_file.exists()

        # Result file should exist
        result_file = client_with_cache._get_experiment_cache_dir(exp_id) / "results" / f"{example_id}.json"
        assert result_file.exists()

    def test_get_cached_example_result(self, client_with_cache):
        """Test retrieving cached example result."""
        exp_id = "test-exp-123"
        example_id = "ex1"
        result = {"output": "Test output", "scores": {"metric": 0.8}}

        # Cache result
        client_with_cache._cache_example_result(exp_id, example_id, result)

        # Retrieve it
        cached_result = client_with_cache._get_cached_example_result(exp_id, example_id)

        assert cached_result is not None
        assert cached_result["output"] == "Test output"
        assert cached_result["scores"]["metric"] == 0.8

    def test_is_example_completed(self, client_with_cache):
        """Test checking if example is completed."""
        exp_id = "test-exp-123"
        example_id = "ex1"

        # Should not be completed initially
        assert not client_with_cache._is_example_completed(exp_id, example_id)

        # Cache a result
        client_with_cache._cache_example_result(exp_id, example_id, {"output": "Done"})

        # Should be completed now
        assert client_with_cache._is_example_completed(exp_id, example_id)

        # Error files don't count as completed
        client_with_cache._cache_example_error(exp_id, "ex2", "Failed")
        assert not client_with_cache._is_example_completed(exp_id, "ex2")


class TestCompletionTracking:
    """Test tracking completed examples."""

    def test_get_completed_example_ids(self, client_with_cache):
        """Test getting set of completed example IDs."""
        exp_id = "test-exp-123"

        # Initially empty
        completed = client_with_cache._get_completed_example_ids(exp_id)
        assert len(completed) == 0

        # Add some results
        client_with_cache._cache_example_result(exp_id, "ex1", {"output": "1"})
        client_with_cache._cache_example_result(exp_id, "ex2", {"output": "2"})
        client_with_cache._cache_example_error(exp_id, "ex3", "Failed")  # Error doesn't count

        completed = client_with_cache._get_completed_example_ids(exp_id)
        assert completed == {"ex1", "ex2"}
        assert "ex3" not in completed


class TestExperimentCompletion:
    """Test experiment completion marking and cleanup."""

    def test_mark_experiment_completed(self, client_with_cache):
        """Test marking experiment as completed."""
        exp_id = "test-exp-123"

        client_with_cache._mark_experiment_completed(exp_id)

        completed_file = client_with_cache._get_experiment_cache_dir(exp_id) / "completed"
        assert completed_file.exists()

        # Check timestamp
        timestamp = completed_file.read_text()
        datetime.fromisoformat(timestamp)  # Should not raise

    def test_clean_experiment_cache(self, client_with_cache, sample_dataset):
        """Test cleaning up experiment cache."""
        exp_id = "test-exp-123"

        # Create some cache data
        client_with_cache._cache_experiment_metadata(exp_id, sample_dataset, {})
        client_with_cache._cache_example_result(exp_id, "ex1", {"output": "test"})

        cache_dir = client_with_cache._get_experiment_cache_dir(exp_id)
        assert cache_dir.exists()

        # Clean it up
        client_with_cache._clean_experiment_cache(exp_id)

        # Should be gone
        assert not cache_dir.exists()


class TestAtomicOperations:
    """Test atomic file operations for concurrent safety."""

    def test_atomic_result_write(self, client_with_cache):
        """Test that result caching uses atomic writes."""
        exp_id = "test-exp-123"
        example_id = "ex1"

        # Patch the file write to simulate interruption
        results_dir = client_with_cache._get_experiment_cache_dir(exp_id) / "results"
        results_dir.mkdir(parents=True, exist_ok=True)

        with patch("builtins.open") as mock_open:
            # Let the temp file write succeed but rename fail
            mock_open.return_value.__enter__.return_value = Mock()

            with patch.object(Path, "rename") as mock_rename:
                mock_rename.side_effect = OSError("Simulated failure")

                # Should handle the error gracefully
                with pytest.raises(OSError):
                    client_with_cache._cache_example_result(exp_id, example_id, {"output": "test"})

        # Final file should not exist
        result_file = results_dir / f"{example_id}.json"
        assert not result_file.exists()
