"""Tests for dataset caching functionality."""

import json
import tempfile
from datetime import datetime, timedelta
from unittest.mock import patch

import pytest

from cat_cafe.sdk import CATCafeClient, Dataset, Example


@pytest.fixture
def temp_cache_dir():
    """Create a temporary directory for cache testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def client_with_cache(temp_cache_dir):
    """Create a client with a temporary cache directory."""
    return CATCafeClient(cache_dir=temp_cache_dir)


@pytest.fixture
def sample_dataset():
    """Create a sample dataset for testing."""
    return Dataset(
        id="test-dataset-123",
        name="Test Dataset",
        description="A test dataset",
        tags=["test"],
        metadata={"key": "value"},
        example_count=2,
        version=1,
        created_at="2024-01-01T00:00:00Z",
        updated_at="2024-01-01T00:00:00Z",
        examples=[
            Example(
                id="ex1",
                input={"messages": [{"role": "user", "content": "Hello"}]},
                output={"messages": [{"role": "assistant", "content": "Hi"}]},
                metadata={"test": True},
            ),
            Example(
                id="ex2",
                input={"messages": [{"role": "user", "content": "Goodbye"}]},
                output={"messages": [{"role": "assistant", "content": "Bye"}]},
                metadata={"test": True},
            ),
        ],
    )


class TestDatasetCaching:
    """Test dataset caching functionality."""

    def test_cache_dataset(self, client_with_cache, sample_dataset):
        """Test caching a dataset."""
        dataset_id = "test-dataset-123"

        # Cache the dataset
        client_with_cache._cache_dataset(dataset_id, sample_dataset)

        # Check cache file exists
        cache_path = client_with_cache._get_dataset_cache_path(dataset_id)
        assert cache_path.exists()

        # Load and verify cache content
        with open(cache_path, "r") as f:
            cache_data = json.load(f)

        assert "cached_at" in cache_data
        assert cache_data["dataset"]["id"] == dataset_id
        assert cache_data["dataset"]["name"] == "Test Dataset"
        assert len(cache_data["dataset"]["examples"]) == 2

    def test_get_cached_dataset_fresh(self, client_with_cache, sample_dataset):
        """Test retrieving a fresh cached dataset."""
        dataset_id = "test-dataset-123"

        # Cache the dataset
        client_with_cache._cache_dataset(dataset_id, sample_dataset)

        # Retrieve from cache
        cached = client_with_cache._get_cached_dataset(dataset_id, ttl_hours=24)

        assert cached is not None
        assert cached.id == dataset_id
        assert cached.name == "Test Dataset"
        assert len(cached.examples) == 2
        assert cached.examples[0].input["messages"][0]["content"] == "Hello"

    def test_get_cached_dataset_expired(self, client_with_cache, sample_dataset):
        """Test that expired cache returns None."""
        dataset_id = "test-dataset-123"

        # Cache the dataset
        client_with_cache._cache_dataset(dataset_id, sample_dataset)

        # Modify cache timestamp to be old
        cache_path = client_with_cache._get_dataset_cache_path(dataset_id)
        with open(cache_path, "r") as f:
            cache_data = json.load(f)

        old_time = datetime.now() - timedelta(hours=25)
        cache_data["cached_at"] = old_time.isoformat()

        with open(cache_path, "w") as f:
            json.dump(cache_data, f)

        # Try to get with 24 hour TTL
        cached = client_with_cache._get_cached_dataset(dataset_id, ttl_hours=24)
        assert cached is None

        # But should work with longer TTL
        cached = client_with_cache._get_cached_dataset(dataset_id, ttl_hours=48)
        assert cached is not None

    def test_is_dataset_stale(self, client_with_cache, sample_dataset):
        """Test checking if dataset is stale."""
        dataset_id = "test-dataset-123"

        # No cache should be stale
        assert client_with_cache.is_dataset_stale(dataset_id) is True

        # Fresh cache should not be stale
        client_with_cache._cache_dataset(dataset_id, sample_dataset)
        assert client_with_cache.is_dataset_stale(dataset_id) is False

        # Old cache should be stale
        cache_path = client_with_cache._get_dataset_cache_path(dataset_id)
        with open(cache_path, "r") as f:
            cache_data = json.load(f)

        old_time = datetime.now() - timedelta(hours=25)
        cache_data["cached_at"] = old_time.isoformat()

        with open(cache_path, "w") as f:
            json.dump(cache_data, f)

        assert client_with_cache.is_dataset_stale(dataset_id) is True

    def test_fetch_dataset_with_cache(self, client_with_cache, sample_dataset):
        """Test fetch_dataset uses cache when available."""
        dataset_id = "test-dataset-123"

        # Pre-cache the dataset
        client_with_cache._cache_dataset(dataset_id, sample_dataset)

        # Mock the API calls to ensure they're not made
        with patch.object(client_with_cache, "get_dataset_info") as mock_info:
            with patch.object(client_with_cache, "get_dataset_examples") as mock_examples:
                # Fetch should use cache
                dataset = client_with_cache.fetch_dataset(dataset_id)

                # API should not be called
                mock_info.assert_not_called()
                mock_examples.assert_not_called()

                # Should get cached data
                assert dataset.id == dataset_id
                assert dataset.name == "Test Dataset"

    def test_fetch_dataset_cache_fallback(self, client_with_cache, sample_dataset):
        """Test fetch_dataset falls back to cache when server fails."""
        dataset_id = "test-dataset-123"

        # Pre-cache the dataset with old timestamp to make it stale
        client_with_cache._cache_dataset(dataset_id, sample_dataset)

        # Make cache appear stale so fetch_dataset tries server first
        cache_path = client_with_cache._get_dataset_cache_path(dataset_id)
        with open(cache_path, "r") as f:
            cache_data = json.load(f)

        # Set cached_at to 25 hours ago (older than default TTL)
        old_time = datetime.now() - timedelta(hours=25)
        cache_data["cached_at"] = old_time.isoformat()

        with open(cache_path, "w") as f:
            json.dump(cache_data, f)

        # Set offline_mode to warn
        client_with_cache.offline_mode = "warn"

        # Mock API to fail with a more realistic exception
        with patch.object(client_with_cache, "get_dataset_info") as mock_info:
            mock_info.side_effect = Exception("Connection failed")

            # Use warnings capture instead of pytest.warns
            import warnings

            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                # Fetch with default TTL (24 hours) - cache is stale so will try server
                dataset = client_with_cache.fetch_dataset(dataset_id)

                # Check if warning was issued
                assert len(w) == 1
                assert issubclass(w[0].category, UserWarning)
                assert "Failed to fetch dataset from server" in str(w[0].message)

            assert dataset.id == dataset_id
            assert dataset.name == "Test Dataset"

    def test_fetch_dataset_no_cache(self, client_with_cache):
        """Test fetch_dataset with caching disabled."""
        dataset_id = "test-dataset-123"

        # Mock successful API response
        with patch.object(client_with_cache, "get_dataset_info") as mock_info:
            with patch.object(client_with_cache, "get_dataset_examples") as mock_examples:
                mock_info.return_value = {"id": dataset_id, "name": "Test Dataset", "example_count": 1}
                mock_examples.return_value = [
                    {
                        "id": "ex1",
                        "input": {"messages": [{"role": "user", "content": "Test"}]},
                        "output": {"messages": [{"role": "assistant", "content": "Response"}]},
                    }
                ]

                # Fetch without cache
                client_with_cache.fetch_dataset(dataset_id, use_cache=False)

                # API should be called
                mock_info.assert_called_once()
                mock_examples.assert_called_once()

                # Should not create cache
                cache_path = client_with_cache._get_dataset_cache_path(dataset_id)
                assert not cache_path.exists()

    def test_explicit_cache_dataset(self, client_with_cache):
        """Test explicitly caching a dataset."""
        dataset_id = "test-dataset-123"

        # Mock successful API response
        with patch.object(client_with_cache, "fetch_dataset") as mock_fetch:
            mock_fetch.return_value = Dataset(id=dataset_id, name="Cached Dataset", examples=[])

            # Explicitly cache
            client_with_cache.cache_dataset(dataset_id)

            # Should fetch without cache
            mock_fetch.assert_called_once_with(dataset_id, use_cache=False)

            # Cache should exist
            cache_path = client_with_cache._get_dataset_cache_path(dataset_id)
            assert cache_path.exists()
