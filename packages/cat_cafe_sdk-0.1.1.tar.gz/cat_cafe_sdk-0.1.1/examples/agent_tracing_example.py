"""Example showing how to capture agent execution traces in experiments."""

from typing import Iterable, Union
import time

from cat_cafe.sdk.output_types import AgentTrace, AgentStep, ToolCall, LLMCall
from cat_cafe.sdk import Example


def _build_example(*, example_id: str, prompt: str, response: str, tags: Iterable[str] | None = None) -> Example:
    example = Example(
        id=example_id,
        input={"messages": [{"role": "user", "content": prompt}]},
        output={"messages": [{"role": "assistant", "content": response}]},
        metadata={},
    )
    if tags:
        example.tags = list(tags)
    return example


def _latest_user_input(example: Example) -> str:
    messages = example.input.get("messages", []) if isinstance(example.input, dict) else []
    if not isinstance(messages, list):
        return ""
    return messages[-1]["content"] if messages else ""


def simple_test_function(example: Example) -> str:
    """Current simple approach - just return final answer."""
    return "Paris is the capital of France"


def enhanced_test_function(example: Example) -> AgentTrace:
    """Enhanced approach - capture the agent's entire reasoning process."""
    start_time = time.time()

    # Simulate agent execution with tracing
    trace = AgentTrace(final_response="", agent_type="react")

    user_prompt = _latest_user_input(example)

    # Step 1: Agent analyzes the question
    step1 = AgentStep(
        action="analyze_question",
        input=user_prompt,
        output="Need to find the capital of France",
        step_type="thought",
    )
    trace.steps.append(step1)
    trace.reasoning_trace.append("I need to search for information about France's capital")

    # Step 2: Agent searches for information
    search_tool = ToolCall(
        name="web_search",
        args={"query": "capital of France"},
        result="Paris is the capital and largest city of France...",
        execution_time_ms=800.0,
    )
    trace.tools_called.append(search_tool)

    step2 = AgentStep(
        action="search",
        input="capital of France",
        output="Found information: Paris is the capital...",
        step_type="action",
        execution_time_ms=800.0,
    )
    trace.steps.append(step2)

    # Step 3: LLM call to process search results
    llm_call = LLMCall(
        prompt="Based on this search result: 'Paris is the capital and largest city of France', what is the capital of France?",
        response="The capital of France is Paris.",
        model="gpt-4",
        tokens_used=45,
        token_cost=0.002,
        latency_ms=1200.0,
        step_context="reasoning",
    )
    trace.llm_calls.append(llm_call)

    step3 = AgentStep(
        action="reasoning",
        input="Search results about France",
        output="The capital of France is Paris",
        step_type="thought",
        execution_time_ms=1200.0,
    )
    trace.steps.append(step3)
    trace.reasoning_trace.append("Based on the search results, I can confidently say Paris is the capital")

    # Step 4: Format final response
    step4 = AgentStep(
        action="format_response",
        input="Paris is the capital",
        output="Final answer: Paris is the capital of France",
        step_type="action",
    )
    trace.steps.append(step4)

    # Set final response and aggregate metrics
    trace.final_response = "Final answer: Paris is the capital of France"
    trace.total_tokens = sum(call.tokens_used for call in trace.llm_calls if call.tokens_used)
    trace.total_cost = sum(call.token_cost for call in trace.llm_calls if call.token_cost)
    trace.execution_time_ms = (time.time() - start_time) * 1000
    trace.context_retrieved = [
        search_tool.result  # type: ignore[arg-type]
    ]

    return trace


def rag_test_function(example: Example) -> AgentTrace:
    """Example of RAG agent tracing."""
    trace = AgentTrace(final_response="", agent_type="rag")

    user_prompt = _latest_user_input(example)

    trace.steps.append(
        AgentStep(
            action="query_analysis",
            input=user_prompt,
            output="User asking about French capital",
            step_type="thought",
        )
    )

    retrieval_tool = ToolCall(
        name="vector_search",
        args={"query": "France capital", "top_k": 3},
        result=["Doc1: Paris is France's capital", "Doc2: Located on Seine River", "Doc3: Population 2.1M"],
        execution_time_ms=150.0,
    )
    trace.tools_called.append(retrieval_tool)
    trace.context_retrieved = retrieval_tool.result

    llm_call = LLMCall(
        prompt="Context: Paris is France's capital. Question: What is the capital of France?",
        response="Based on the provided context, Paris is the capital of France.",
        model="gpt-3.5-turbo",
        tokens_used=32,
        token_cost=0.0008,
        latency_ms=900.0,
        step_context="generation",
    )
    trace.llm_calls.append(llm_call)

    trace.final_response = llm_call.response
    trace.total_tokens = llm_call.tokens_used
    trace.total_cost = llm_call.token_cost
    trace.execution_time_ms = 1050.0

    return trace


def evaluator_with_trace_access(example: Example, output: Union[str, AgentTrace]) -> float:
    """Evaluator that can analyze agent traces."""

    final_response = output if isinstance(output, str) else output.final_response
    correctness_score = 0.8 if "Paris" in final_response else 0.0

    if isinstance(output, AgentTrace):
        if any(tool.name == "web_search" for tool in output.tools_called):
            correctness_score += 0.1
        if output.step_count > 5:
            correctness_score -= 0.1
        if output.total_tokens and output.total_tokens < 100:
            correctness_score += 0.05

    return min(1.0, correctness_score)


if __name__ == "__main__":
    example = _build_example(
        example_id="geo-1",
        prompt="What is the capital of France?",
        response="Paris",
        tags=["geography"],
    )

    simple_result = simple_test_function(example)
    print("Simple result:", simple_result)

    enhanced_result = enhanced_test_function(example)
    print("Enhanced result:", enhanced_result.final_response)
    print("Steps taken:", enhanced_result.step_count)
    print("Tools used:", enhanced_result.tool_usage_summary)
    print("Total tokens:", enhanced_result.total_tokens)
    print("Reasoning:", enhanced_result.reasoning_trace)
