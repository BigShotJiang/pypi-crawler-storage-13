#!/usr/bin/env python3
"""Example usage of CAT Cafe SDK tool call evaluation features.

This example demonstrates how to use the tool call evaluation functionality
inspired by DeepEval's tool correctness metrics, adapted for the CAT Cafe
experiment system.
"""

from cat_cafe.sdk import (
    # Core evaluation functions
    generate,
    evaluate,
    run_experiment,
    # Tool call evaluation
    tool_correctness_evaluator,
    basic_tool_correctness_evaluator,
    exact_tool_correctness_evaluator,
    ToolCorrectnessConfig,
    # Data models
    ToolCall,
    AgentTrace,
)
from typing import Iterable

from cat_cafe.sdk.client import DatasetExample, Dataset, Example


def _make_example(
    *,
    example_id: str,
    prompt: str,
    response: str,
    tags: Iterable[str] | None = None,
    expected_tools: Iterable[ToolCall] | None = None,
) -> Example:
    example = Example(
        id=example_id,
        input={"messages": [{"role": "user", "content": prompt}]},
        output={"messages": [{"role": "assistant", "content": response}]},
        metadata={},
    )
    if tags:
        example.tags = list(tags)
    if expected_tools is not None:
        example.expected_tool_calls = list(expected_tools)
    return example


def _latest_prompt(example: DatasetExample) -> str:
    messages = example.input.get("messages", []) if isinstance(example.input, dict) else []
    if not isinstance(messages, list):
        return ""
    return messages[-1]["content"].lower() if messages else ""


def create_example_dataset():
    """Create a sample dataset with expected tool calls for evaluation."""
    examples = [
        _make_example(
            example_id="weather-query",
            prompt="What's the weather like in San Francisco today?",
            response="Let me check the current weather for you.",
            tags=["weather"],
            expected_tools=[
                ToolCall(name="get_weather", args={"location": "San Francisco", "date": "today", "units": "fahrenheit"})
            ],
        ),
        _make_example(
            example_id="multi-tool-search",
            prompt="Find Python tutorials and summarize the best one",
            response="I'll search for Python tutorials and provide a summary.",
            tags=["search"],
            expected_tools=[
                ToolCall(name="web_search", args={"query": "Python tutorials", "limit": 10}),
                ToolCall(name="summarize_content", args={"url": "https://example.com/best-tutorial"}),
            ],
        ),
        _make_example(
            example_id="no-tools-needed",
            prompt="What is 2 + 2?",
            response="2 + 2 equals 4.",
            tags=["math"],
            expected_tools=None,
        ),
        _make_example(
            example_id="calculator-task",
            prompt="Calculate 15 * 27 + 89",
            response="Let me calculate that for you.",
            tags=["math"],
            expected_tools=[ToolCall(name="calculator", args={"expression": "15 * 27 + 89"})],
        ),
    ]

    return Dataset(
        id="tool-evaluation-examples",
        name="Tool Call Evaluation Examples",
        description="Sample dataset for demonstrating tool call evaluation",
        examples=examples,
    )


# Example test functions that simulate different tool calling scenarios


def perfect_agent(example: DatasetExample) -> AgentTrace:
    """Test function that makes exactly the expected tool calls."""
    user_input = _latest_prompt(example)

    tools_called = []

    if "weather" in user_input:
        tools_called = [
            ToolCall(name="get_weather", args={"location": "San Francisco", "date": "today", "units": "fahrenheit"})
        ]
        response = "The weather in San Francisco today is 72°F and sunny with light clouds."

    elif "python tutorials" in user_input or "find" in user_input:
        tools_called = [
            ToolCall(name="web_search", args={"query": "Python tutorials", "limit": 10}),
            ToolCall(name="summarize_content", args={"url": "https://example.com/best-tutorial"}),
        ]
        response = "I found excellent Python tutorials. The best one covers everything from basics to advanced topics with hands-on examples."

    elif "calculate" in user_input:
        tools_called = [ToolCall(name="calculator", args={"expression": "15 * 27 + 89"})]
        response = "15 × 27 + 89 = 494"

    else:
        # Simple math - no tools needed
        response = "2 + 2 equals 4."

    return AgentTrace(
        final_response=response, tools_called=tools_called, execution_time_ms=150.0, agent_type="perfect_agent"
    )


def slightly_imperfect_agent(example: DatasetExample) -> AgentTrace:
    """Test function with minor differences in tool calls."""
    user_input = _latest_prompt(example)

    tools_called = []

    if "weather" in user_input:
        # Different units parameter
        tools_called = [
            ToolCall(name="get_weather", args={"location": "San Francisco", "date": "today", "units": "celsius"})
        ]
        response = "The weather in San Francisco today is 22°C and sunny."

    elif "python tutorials" in user_input or "find" in user_input:
        # Missing second tool call
        tools_called = [ToolCall(name="web_search", args={"query": "Python programming tutorials", "limit": 5})]
        response = "I found some Python tutorials for you."

    elif "calculate" in user_input:
        # Same tool call
        tools_called = [ToolCall(name="calculator", args={"expression": "15 * 27 + 89"})]
        response = "The result is 494."

    else:
        response = "2 + 2 equals 4."

    return AgentTrace(
        final_response=response,
        tools_called=tools_called,
        execution_time_ms=180.0,
        agent_type="slightly_imperfect_agent",
    )


def wrong_tools_agent(example: DatasetExample) -> AgentTrace:
    """Test function that uses wrong tools."""
    user_input = _latest_prompt(example)

    tools_called = []

    if "weather" in user_input:
        # Wrong tool entirely
        tools_called = [ToolCall(name="web_search", args={"query": "San Francisco weather today"})]
        response = "I searched the web for weather information."

    elif "python tutorials" in user_input or "find" in user_input:
        # Wrong tool name
        tools_called = [ToolCall(name="google_search", args={"query": "Python tutorials"})]
        response = "I used Google to search for tutorials."

    elif "calculate" in user_input:
        # Unexpected additional tool
        tools_called = [
            ToolCall(name="calculator", args={"expression": "15 * 27 + 89"}),
            ToolCall(name="format_number", args={"number": 494, "format": "currency"}),
        ]
        response = "The calculation result is $494.00."

    else:
        response = "2 + 2 equals 4."

    return AgentTrace(
        final_response=response, tools_called=tools_called, execution_time_ms=200.0, agent_type="wrong_tools_agent"
    )


def demonstrate_basic_evaluation():
    """Demonstrate basic tool call evaluation with different agents."""
    print("🧪 CAT Cafe Tool Call Evaluation Demo")
    print("=" * 50)

    # Create dataset
    dataset = create_example_dataset()

    # Test different agents
    agents = [
        ("Perfect Agent", perfect_agent),
        ("Slightly Imperfect Agent", slightly_imperfect_agent),
        ("Wrong Tools Agent", wrong_tools_agent),
    ]

    for agent_name, agent_function in agents:
        print(f"\n📊 Evaluating: {agent_name}")
        print("-" * 40)

        # Generate evaluation contexts
        contexts = generate(dataset.examples, agent_function)

        # Evaluate with basic tool correctness
        results = evaluate(contexts, [basic_tool_correctness_evaluator])

        # Calculate and display results
        total_score = sum(r["evaluation_scores"]["basic_tool_correctness_evaluator"] for r in results)
        avg_score = total_score / len(results)

        print(f"Average Tool Correctness Score: {avg_score:.3f}")

        # Show per-example breakdown
        for i, result in enumerate(results):
            example = dataset.examples[i]
            score = result["evaluation_scores"]["basic_tool_correctness_evaluator"]
            metadata = result["evaluator_metadata"]["basic_tool_correctness_evaluator"]

            print(f"  • {example.id}: {score:.2f} - {metadata['reason']}")
            if metadata.get("extra_tools"):
                print(f"    Extra tools: {len(metadata['extra_tools'])}")
            if metadata.get("missing_tools"):
                print(f"    Missing tools: {len(metadata['missing_tools'])}")


def demonstrate_matching_modes():
    """Demonstrate different matching modes (exact, strict)."""
    print("\n🔍 Matching Mode Comparison")
    print("=" * 40)

    # Create simple test case
    dataset = create_example_dataset()

    # Test slightly imperfect agent with different modes
    modes = ["exact", "strict"]

    for mode in modes:
        print(f"\n📋 {mode.upper()} Mode:")

        config = ToolCorrectnessConfig(mode=mode)
        contexts = generate([dataset.examples[0]], slightly_imperfect_agent)  # Weather example

        # Evaluate with custom config
        def custom_evaluator(context):
            return tool_correctness_evaluator(context, config)

        results = evaluate(contexts, [custom_evaluator])
        result = results[0]

        score = result["evaluation_scores"]["custom_evaluator"]
        metadata = result["evaluator_metadata"]["custom_evaluator"]

        print(f"  Score: {score:.3f}")
        print(f"  Precision: {metadata['precision']:.3f}")
        print(f"  Recall: {metadata['recall']:.3f}")
        print(f"  Reason: {metadata['reason']}")


def demonstrate_custom_configurations():
    """Demonstrate custom evaluation configurations."""
    print("\n⚙️  Custom Configuration Examples")
    print("=" * 40)

    dataset = create_example_dataset()
    contexts = generate([dataset.examples[1]], slightly_imperfect_agent)  # Multi-tool example

    # Different weight configurations
    configs = [
        ("Precision-Heavy", ToolCorrectnessConfig(mode="strict", weight_precision=0.8, weight_recall=0.2)),
        ("Recall-Heavy", ToolCorrectnessConfig(mode="strict", weight_precision=0.2, weight_recall=0.8)),
        ("Balanced", ToolCorrectnessConfig(mode="strict", weight_precision=0.5, weight_recall=0.5)),
    ]

    for config_name, config in configs:
        print(f"\n📊 {config_name} Configuration:")

        def custom_evaluator(context):
            return tool_correctness_evaluator(context, config)

        results = evaluate(contexts, [custom_evaluator])
        result = results[0]

        score = result["evaluation_scores"]["custom_evaluator"]
        metadata = result["evaluator_metadata"]["custom_evaluator"]

        print(f"  Final Score: {score:.3f}")
        print(f"  Precision: {metadata['precision']:.3f} (weight: {config.weight_precision})")
        print(f"  Recall: {metadata['recall']:.3f} (weight: {config.weight_recall})")
        print(f"  Reason: {metadata['reason']}")


def demonstrate_run_experiment():
    """Demonstrate the high-level run_experiment() function."""
    print("\n🚀 Complete Experiment Run")
    print("=" * 40)

    dataset = create_example_dataset()

    # Run complete experiment with multiple evaluators
    evaluators = [
        basic_tool_correctness_evaluator,
        exact_tool_correctness_evaluator,
    ]

    # Use the perfect agent for this demo
    experiment_result = run_experiment(dataset.examples, perfect_agent, evaluators)

    print(f"Total Examples: {experiment_result['summary']['total_examples']}")
    print(f"Successful Examples: {experiment_result['summary']['successful_examples']}")
    print(f"Total Execution Time: {experiment_result['summary']['total_execution_time_ms']:.1f}ms")

    print("\nAverage Scores by Evaluator:")
    for evaluator_name, avg_score in experiment_result["summary"]["average_scores"].items():
        print(f"  • {evaluator_name}: {avg_score:.3f}")

    # Show detailed results for first example
    print(f"\nDetailed Results for '{dataset.examples[0].id}':")
    result = experiment_result["results"][0]

    for evaluator_name, score in result["evaluation_scores"].items():
        metadata = result["evaluator_metadata"][evaluator_name]
        print(f"  • {evaluator_name}: {score:.2f}")
        print(f"    Mode: {metadata.get('mode', 'N/A')}")
        print(f"    Reason: {metadata.get('reason', 'N/A')}")


if __name__ == "__main__":
    # Run all demonstrations
    demonstrate_basic_evaluation()
    demonstrate_matching_modes()
    demonstrate_custom_configurations()
    demonstrate_run_experiment()

    print("\n✅ Tool Call Evaluation Demo Complete!")
    print("\nNext steps:")
    print("1. Create your own dataset with expected_tool_calls")
    print("2. Implement test functions that return AgentTrace objects")
    print("3. Use tool_correctness_evaluator with your preferred configuration")
    print("4. Analyze results and iterate on your agent's tool usage")
