#!/usr/bin/env python3
"""Test the tool call evaluator end-to-end with realistic examples."""

from typing import Iterable

from cat_cafe.sdk import DatasetExample, tool_correctness_evaluator, ToolCorrectnessConfig, ToolCall, generate
from cat_cafe.sdk.client import Example, Dataset


def _make_example(
    *,
    example_id: str,
    prompt: str,
    response: str,
    tags: Iterable[str] | None = None,
    expected_tools: Iterable[ToolCall] | None = None,
) -> Example:
    """Create an Example using structured chat payloads."""
    example = Example(
        id=example_id,
        input={"messages": [{"role": "user", "content": prompt}]},
        output={"messages": [{"role": "assistant", "content": response}]},
        metadata={},
    )

    if tags:
        example.tags = list(tags)

    if expected_tools is not None:
        example.expected_tool_calls = list(expected_tools)

    return example


def _user_prompt(example: DatasetExample) -> str:
    """Extract the latest user message from the example input."""
    messages = example.input.get("messages", []) if isinstance(example.input, dict) else list(example.input)
    return messages[-1]["content"] if messages else ""


# Create test dataset with expected tool calls
def create_tool_call_dataset():
    examples = [
        _make_example(
            example_id="weather-query",
            prompt="What's the weather in San Francisco?",
            response="Let me check the weather for you.",
            tags=["weather"],
            expected_tools=[ToolCall(name="get_weather", args={"location": "San Francisco", "units": "celsius"})],
        ),
        _make_example(
            example_id="search-and-summarize",
            prompt="Search for Python tutorials and summarize the top result",
            response="I'll search for Python tutorials and summarize the best one.",
            tags=["search"],
            expected_tools=[
                ToolCall(name="web_search", args={"query": "Python tutorials", "limit": 10}),
                ToolCall(name="summarize_webpage", args={"url": "https://example.com/python-tutorial"}),
            ],
        ),
        _make_example(
            example_id="no-tools-needed",
            prompt="What is 2+2?",
            response="2+2 equals 4.",
            tags=["math"],
            expected_tools=None,
        ),
    ]

    return Dataset(
        id="tool-call-test",
        name="Tool Call Test Dataset",
        description="Testing tool call evaluation",
        examples=examples,
    )


# Mock test functions that simulate different tool calling scenarios
def perfect_tool_function(example: DatasetExample) -> str:
    """Test function that makes exactly the expected tool calls."""
    user_input = _user_prompt(example)

    if "weather" in user_input.lower():
        # Simulate perfect weather tool call
        return "The weather in San Francisco is 18°C and sunny."
    elif "search" in user_input.lower():
        # Simulate perfect search + summarize calls
        return "I found great Python tutorials. The top result covers basics through advanced topics."
    else:
        # No tool calls needed
        return "2+2 equals 4."


def imperfect_tool_function(example: DatasetExample) -> str:
    """Test function that makes slightly different tool calls."""
    user_input = _user_prompt(example)

    if "weather" in user_input.lower():
        # Wrong units in arguments
        return "The weather in San Francisco is 64°F and sunny."
    elif "search" in user_input.lower():
        # Missing second tool call
        return "I found some Python tutorials for you."
    else:
        return "2+2 equals 4."


def wrong_tool_function(example: DatasetExample) -> str:
    """Test function that makes wrong tool calls."""
    user_input = _user_prompt(example)

    if "weather" in user_input.lower():
        # Wrong tool entirely
        return "I searched the web for weather information."
    elif "search" in user_input.lower():
        # Wrong tool name
        return "I used the search engine to find information."
    else:
        return "2+2 equals 4."


# Mock trace extraction to simulate different tool calling patterns
class MockAgentTrace:
    def __init__(self, tools_called=None):
        self.tools_called = tools_called or []
        self.final_response = "Mock response"


def mock_test_function_with_perfect_tools(example: DatasetExample) -> MockAgentTrace:
    """Returns trace with perfect tool calls."""
    user_input = _user_prompt(example)

    if "weather" in user_input.lower():
        tools = [ToolCall(name="get_weather", args={"location": "San Francisco", "units": "celsius"})]
        return MockAgentTrace(tools)
    elif "search" in user_input.lower():
        tools = [
            ToolCall(name="web_search", args={"query": "Python tutorials", "limit": 10}),
            ToolCall(name="summarize_webpage", args={"url": "https://example.com/python-tutorial"}),
        ]
        return MockAgentTrace(tools)
    else:
        return MockAgentTrace([])


def mock_test_function_with_fuzzy_tools(example: DatasetExample) -> MockAgentTrace:
    """Returns trace with similar but not identical tool calls."""
    user_input = _user_prompt(example)

    if "weather" in user_input.lower():
        # Similar but not identical arguments
        tools = [ToolCall(name="get_weather", args={"location": "San Francisco, CA", "units": "fahrenheit"})]
        return MockAgentTrace(tools)
    elif "search" in user_input.lower():
        # Different search parameters and missing second call
        tools = [ToolCall(name="web_search", args={"query": "Python programming tutorials", "limit": 5})]
        return MockAgentTrace(tools)
    else:
        return MockAgentTrace([])


def test_tool_call_evaluation():
    print("🧪 Testing Tool Call Evaluation")
    print("=" * 50)

    # Create test dataset
    dataset = create_tool_call_dataset()

    # Test scenarios
    scenarios = [
        ("Perfect Tool Calls", mock_test_function_with_perfect_tools, "strict"),
        ("Fuzzy Tool Calls", mock_test_function_with_fuzzy_tools, "fuzzy"),
        ("Strict Fuzzy Calls", mock_test_function_with_fuzzy_tools, "strict"),
        ("Exact Perfect Calls", mock_test_function_with_perfect_tools, "exact"),
    ]

    for scenario_name, test_func, mode in scenarios:
        print(f"\n📊 {scenario_name} ({mode} mode)")
        print("-" * 40)

        try:
            # Create evaluation contexts using generate()
            contexts = generate(dataset.examples, test_func)

            # Create evaluator config
            config = ToolCorrectnessConfig(mode=mode)

            # Evaluate each context
            total_score = 0.0
            for i, context in enumerate(contexts):
                result = tool_correctness_evaluator(context, config)

                example = dataset.examples[i]
                print(f"\n  Example: {example.id}")
                print(f"  Score: {result.score:.2f}")
                print(f"  Reason: {result.metadata['reason']}")
                print(f"  Expected tools: {result.metadata['expected_count']}")
                print(f"  Actual tools: {result.metadata['actual_count']}")
                print(f"  Precision: {result.metadata['precision']:.2f}")
                print(f"  Recall: {result.metadata['recall']:.2f}")

                if result.metadata.get("extra_tools"):
                    print(f"  Extra tools: {len(result.metadata['extra_tools'])}")
                if result.metadata.get("missing_tools"):
                    print(f"  Missing tools: {len(result.metadata['missing_tools'])}")

                total_score += result.score

            avg_score = total_score / len(contexts)
            print(f"\n  📈 Average Score: {avg_score:.2f}")

        except Exception as e:
            print(f"  ❌ Error: {e}")
            import traceback

            traceback.print_exc()

    print("\n✅ Tool Call Evaluation Test Complete!")


def test_matching_modes():
    print("\n🔍 Testing Different Matching Modes")
    print("=" * 50)

    # Create simple test case
    expected_tools = [ToolCall(name="search", args={"query": "python", "limit": 10})]

    test_cases = [
        ("Exact Match", [ToolCall(name="search", args={"query": "python", "limit": 10})]),
        ("Different Args", [ToolCall(name="search", args={"query": "python tutorials", "limit": 5})]),
        ("Different Tool", [ToolCall(name="lookup", args={"query": "python", "limit": 10})]),
        (
            "Extra Tool",
            [
                ToolCall(name="search", args={"query": "python", "limit": 10}),
                ToolCall(name="summarize", args={"text": "results"}),
            ],
        ),
        ("Missing Tool", []),
    ]

    from cat_cafe.sdk.tool_call_matching import match_tool_calls

    modes = ["exact", "strict", "fuzzy"]

    for case_name, actual_tools in test_cases:
        print(f"\n📋 {case_name}")
        print("-" * 30)

        for mode in modes:
            result = match_tool_calls(expected_tools, actual_tools, mode)
            print(f"  {mode.title()}: {result.overall_score:.2f} (P: {result.precision:.2f}, R: {result.recall:.2f})")


if __name__ == "__main__":
    test_tool_call_evaluation()
    test_matching_modes()
