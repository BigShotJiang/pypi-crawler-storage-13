"""In-memory OpenTelemetry trace capture for experiment runners.

This module provides utilities to capture OpenTelemetry traces during test execution
without relying on external trace backends. It leverages OpenInference auto-instrumentation
to automatically capture LLM calls and convert them to rich AgentTrace objects.
"""

from contextlib import contextmanager
from typing import Dict, List, Optional, Any, Iterator
from threading import Lock

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SpanProcessor, ReadableSpan
from opentelemetry.sdk.resources import Resource, SERVICE_NAME
from opentelemetry.trace import StatusCode

from .output_types import AgentTrace, AgentStep, LLMCall, ToolCall


class InMemorySpanProcessor(SpanProcessor):
    """Custom span processor that captures spans in memory for experiment runners."""

    def __init__(self):
        self.spans: List[ReadableSpan] = []
        self._lock = Lock()
        self.trace_spans: Dict[str, List[ReadableSpan]] = {}

    def on_start(self, span: ReadableSpan, parent_context=None) -> None:
        """Called when a span is started."""
        pass

    def on_end(self, span: ReadableSpan) -> None:
        """Called when a span is ended - capture it."""
        with self._lock:
            self.spans.append(span)

            # Group by trace ID for easier processing
            trace_id = span.get_span_context().trace_id
            trace_id_hex = f"{trace_id:032x}"

            if trace_id_hex not in self.trace_spans:
                self.trace_spans[trace_id_hex] = []
            self.trace_spans[trace_id_hex].append(span)

    def shutdown(self) -> None:
        """Shutdown the processor."""
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush - no-op for in-memory processor."""
        return True

    def get_spans_for_trace(self, trace_id: str) -> List[ReadableSpan]:
        """Get all spans for a specific trace ID."""
        with self._lock:
            return self.trace_spans.get(trace_id, []).copy()

    def clear(self) -> None:
        """Clear all captured spans."""
        with self._lock:
            self.spans.clear()
            self.trace_spans.clear()


class TraceCapture:
    """Context manager for capturing OpenTelemetry traces during test execution."""

    def __init__(self):
        self.span_processor = InMemorySpanProcessor()
        self._original_tracer_provider = None
        self._custom_tracer_provider = None

    def __enter__(self) -> "TraceCapture":
        """Set up in-memory trace capture."""
        # Store original tracer provider
        self._original_tracer_provider = trace.get_tracer_provider()

        # Create custom tracer provider with in-memory processor
        resource = Resource({SERVICE_NAME: "cat-cafe-experiment-runner"})
        self._custom_tracer_provider = TracerProvider(resource=resource)
        self._custom_tracer_provider.add_span_processor(self.span_processor)

        # Set as active tracer provider
        trace.set_tracer_provider(self._custom_tracer_provider)

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Clean up trace capture and restore original tracer provider."""
        # Force flush any pending spans
        self.span_processor.force_flush()

        # Restore original tracer provider
        if self._original_tracer_provider:
            trace.set_tracer_provider(self._original_tracer_provider)

        # Shutdown custom provider
        if self._custom_tracer_provider:
            self._custom_tracer_provider.shutdown()

    def get_captured_traces(self) -> Dict[str, List[ReadableSpan]]:
        """Get all captured traces grouped by trace ID."""
        return self.span_processor.trace_spans.copy()

    def get_latest_trace_id(self) -> Optional[str]:
        """Get the trace ID of the most recently captured trace."""
        if not self.span_processor.spans:
            return None

        # Get the most recent span and return its trace ID
        latest_span = self.span_processor.spans[-1]
        trace_id = latest_span.get_span_context().trace_id
        return f"{trace_id:032x}"


def convert_otlp_spans_to_agent_trace(spans: List[ReadableSpan]) -> AgentTrace:
    """Convert OTLP spans to AgentTrace format.

    This function analyzes captured OpenTelemetry spans (typically from OpenInference
    instrumentation) and converts them to our rich AgentTrace format.

    Args:
        spans: List of OpenTelemetry ReadableSpan objects

    Returns:
        AgentTrace object with extracted steps, LLM calls, and tool usage
    """
    if not spans:
        return AgentTrace(final_response="")

    # Sort spans by start time to understand execution order
    sorted_spans = sorted(spans, key=lambda s: s.start_time)

    trace = AgentTrace(final_response="")
    trace.agent_type = "auto_instrumented"

    # Track execution timing
    start_time = sorted_spans[0].start_time
    end_time = max(span.end_time or span.start_time for span in spans)
    trace.execution_time_ms = (end_time - start_time) / 1_000_000  # Convert from nanoseconds

    for span in sorted_spans:
        attributes = dict(span.attributes) if span.attributes else {}

        # Extract LLM calls (OpenInference LLM spans)
        if _is_llm_span(span, attributes):
            llm_call = _extract_llm_call(span, attributes)
            if llm_call:
                trace.llm_calls.append(llm_call)

                # Add as a reasoning step
                step = AgentStep(
                    action="llm_call",
                    input=llm_call.prompt[:100] + "..." if len(llm_call.prompt) > 100 else llm_call.prompt,
                    output=llm_call.response[:100] + "..." if len(llm_call.response) > 100 else llm_call.response,
                    step_type="thought",
                    execution_time_ms=llm_call.latency_ms,
                )
                trace.steps.append(step)

        # Extract tool calls (OpenInference tool spans)
        elif _is_tool_span(span, attributes):
            tool_call = _extract_tool_call(span, attributes)
            if tool_call:
                trace.tools_called.append(tool_call)

                # Add as an action step
                step = AgentStep(
                    action="tool_call",
                    input=f"{tool_call.name}({tool_call.args})",
                    output=str(tool_call.result)[:100] + "..."
                    if len(str(tool_call.result)) > 100
                    else str(tool_call.result),
                    step_type="action",
                    execution_time_ms=tool_call.execution_time_ms,
                )
                trace.steps.append(step)

        # Extract other spans as generic steps
        else:
            step = _extract_generic_step(span, attributes)
            if step:
                trace.steps.append(step)

    # Calculate aggregate metrics
    trace.total_tokens = sum(call.tokens_used for call in trace.llm_calls if call.tokens_used)
    trace.total_cost = sum(call.token_cost for call in trace.llm_calls if call.token_cost)

    # Extract final response from the last LLM call or span output
    if trace.llm_calls:
        trace.final_response = trace.llm_calls[-1].response
    elif spans:
        # Try to get final response from span attributes
        final_span = sorted_spans[-1]
        attributes = dict(final_span.attributes) if final_span.attributes else {}
        trace.final_response = attributes.get("output.value", attributes.get("response", ""))

    return trace


def _is_llm_span(span: ReadableSpan, attributes: Dict[str, Any]) -> bool:
    """Check if span represents an LLM call."""
    # OpenInference LLM span indicators
    return (
        "llm" in span.name.lower()
        or "openai" in span.name.lower()
        or any(key.startswith("llm.") for key in attributes.keys())
        or "gen_ai.system" in attributes
        or "gen_ai.operation.name" in attributes
    )


def _is_tool_span(span: ReadableSpan, attributes: Dict[str, Any]) -> bool:
    """Check if span represents a tool/function call."""
    return (
        "function" in span.name.lower()
        or "tool" in span.name.lower()
        or any(key.startswith("tool.") for key in attributes.keys())
        or "function_call" in attributes
    )


def _extract_llm_call(span: ReadableSpan, attributes: Dict[str, Any]) -> Optional[LLMCall]:
    """Extract LLM call information from span."""
    try:
        # Get basic info
        prompt = attributes.get("llm.prompts", attributes.get("input.value", ""))
        response = attributes.get("llm.responses", attributes.get("output.value", ""))
        model = attributes.get("llm.model_name", attributes.get("gen_ai.request.model", ""))

        # Calculate execution time
        duration_ns = span.end_time - span.start_time if span.end_time else 0
        latency_ms = duration_ns / 1_000_000

        # Extract token usage
        tokens_used = None
        token_cost = None

        if "llm.token.counts.input" in attributes and "llm.token.counts.output" in attributes:
            input_tokens = attributes.get("llm.token.counts.input", 0)
            output_tokens = attributes.get("llm.token.counts.output", 0)
            tokens_used = input_tokens + output_tokens
        elif "gen_ai.usage.input_tokens" in attributes and "gen_ai.usage.output_tokens" in attributes:
            input_tokens = attributes.get("gen_ai.usage.input_tokens", 0)
            output_tokens = attributes.get("gen_ai.usage.output_tokens", 0)
            tokens_used = input_tokens + output_tokens

        return LLMCall(
            prompt=str(prompt),
            response=str(response),
            model=model,
            tokens_used=tokens_used,
            token_cost=token_cost,
            latency_ms=latency_ms,
            timestamp=str(span.start_time),
            step_context="auto_extracted",
        )
    except Exception:
        return None


def _extract_tool_call(span: ReadableSpan, attributes: Dict[str, Any]) -> Optional[ToolCall]:
    """Extract tool call information from span."""
    try:
        name = span.name
        args = {}
        result = attributes.get("output.value", attributes.get("result", ""))

        # Try to extract arguments from attributes
        for key, value in attributes.items():
            if key.startswith("input.") and key != "input.value":
                arg_name = key.replace("input.", "")
                args[arg_name] = value

        # Calculate execution time
        duration_ns = span.end_time - span.start_time if span.end_time else 0
        execution_time_ms = duration_ns / 1_000_000

        # Check for errors
        error = None
        if span.status.status_code == StatusCode.ERROR:
            error = span.status.description

        return ToolCall(name=name, args=args, result=result, error=error, execution_time_ms=execution_time_ms)
    except Exception:
        return None


def _extract_generic_step(span: ReadableSpan, attributes: Dict[str, Any]) -> Optional[AgentStep]:
    """Extract generic step information from span."""
    try:
        action = span.name
        input_data = attributes.get("input.value", "")
        output_data = attributes.get("output.value", "")

        # Calculate execution time
        duration_ns = span.end_time - span.start_time if span.end_time else 0
        execution_time_ms = duration_ns / 1_000_000

        # Determine step type based on span characteristics
        step_type = "action"
        if "thought" in span.name.lower() or "reasoning" in span.name.lower():
            step_type = "thought"
        elif "observe" in span.name.lower() or "result" in span.name.lower():
            step_type = "observation"

        return AgentStep(
            action=action,
            input=str(input_data),
            output=str(output_data),
            step_type=step_type,
            execution_time_ms=execution_time_ms,
            timestamp=str(span.start_time),
        )
    except Exception:
        return None


@contextmanager
def capture_agent_trace() -> Iterator[TraceCapture]:
    """Context manager for capturing agent traces during test execution.

    Usage:
        with capture_agent_trace() as capture:
            # Run test function that makes LLM calls
            result = my_agent_function(input_data)

            # Convert captured traces to AgentTrace
            trace_id = capture.get_latest_trace_id()
            if trace_id:
                spans = capture.get_captured_traces()[trace_id]
                agent_trace = convert_otlp_spans_to_agent_trace(spans)
                agent_trace.final_response = result
    """
    capture = TraceCapture()
    try:
        yield capture.__enter__()
    finally:
        capture.__exit__(None, None, None)
