"""CAT Cafe SDK for Continuous Alignment Testing."""

from .client import (
    CATCafeClient,
    Experiment,
    ExperimentResult,
    ExperimentDetail,
    EvaluationMetric,
    EvaluatorResult,  # Backwards compatibility
    DatasetConfig,
    DatasetExample,
    DatasetImport,
    Example,
    Dataset,
)

# Experiment runner functionality now lives in the cat-experiments package.

# Evaluation models and functions
from .output_types import EvaluationContext, AgentTrace, ToolCall
from .evaluation import generate, generate_async, evaluate, evaluate_async, run_experiment

# Tool call evaluation
from .evaluators import (
    tool_correctness_evaluator,
    basic_tool_correctness_evaluator,
    exact_tool_correctness_evaluator,
    ToolCorrectnessConfig,
)
from .tool_call_matching import match_tool_calls, ToolCallMatch, ToolCallMatchingResult

__version__ = "0.1.0"

__all__ = [
    # Client
    "CATCafeClient",
    "Experiment",
    "ExperimentResult",
    "ExperimentDetail",
    "EvaluationMetric",
    "EvaluatorResult",  # Backwards compatibility
    "DatasetConfig",
    "DatasetExample",
    "DatasetImport",
    "Example",
    "Dataset",
    # Evaluation models and functions
    "EvaluationContext",
    "AgentTrace",
    "ToolCall",
    "generate",
    "generate_async",
    "evaluate",
    "evaluate_async",
    "run_experiment",
    # Tool call evaluation
    "tool_correctness_evaluator",
    "basic_tool_correctness_evaluator",
    "exact_tool_correctness_evaluator",
    "ToolCorrectnessConfig",
    "match_tool_calls",
    "ToolCallMatch",
    "ToolCallMatchingResult",
]
