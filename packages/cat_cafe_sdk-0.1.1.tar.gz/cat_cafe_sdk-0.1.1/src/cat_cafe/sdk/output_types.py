"""Enhanced output types for capturing agent execution traces and rich outputs."""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Union

from cat.experiments.models import ToolCall


@dataclass
class AgentStep:
    """Represents a single step in an agent's reasoning process."""

    action: str  # "search", "reasoning", "tool_call", "format_response", etc.
    input: str  # What the agent received for this step
    output: str  # What the agent produced from this step
    step_type: str = "action"  # "action", "observation", "thought", "tool_use"
    timestamp: Optional[str] = None
    execution_time_ms: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMCall:
    """Represents a single LLM API call within an agent trace."""

    prompt: str
    response: str
    model: Optional[str] = None
    tokens_used: Optional[int] = None
    token_cost: Optional[float] = None
    latency_ms: Optional[float] = None
    timestamp: Optional[str] = None
    step_context: Optional[str] = None  # Which agent step this call belongs to
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentTrace:
    """Captures the complete execution trace of an agent."""

    final_response: str
    steps: List[AgentStep] = field(default_factory=list)
    llm_calls: List[LLMCall] = field(default_factory=list)
    tools_called: List[ToolCall] = field(default_factory=list)

    # Aggregated metrics
    total_tokens: Optional[int] = None
    total_cost: Optional[float] = None
    execution_time_ms: Optional[float] = None

    # Agent reasoning
    reasoning_trace: List[str] = field(default_factory=list)  # Thought process
    context_retrieved: List[str] = field(default_factory=list)  # RAG context

    # Metadata
    agent_type: Optional[str] = None  # "react", "plan_execute", "cot", etc.
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def step_count(self) -> int:
        """Number of reasoning steps taken."""
        return len(self.steps)

    @property
    def tool_usage_summary(self) -> Dict[str, int]:
        """Count of each tool used."""
        tool_counts = {}
        for tool in self.tools_called:
            tool_counts[tool.name] = tool_counts.get(tool.name, 0) + 1
        return tool_counts


@dataclass
class SimpleOutput:
    """Simple string output with optional metadata (backward compatibility)."""

    final_response: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    execution_time_ms: Optional[float] = None
    token_cost: Optional[float] = None


# Union type for all possible test function outputs
TestFunctionOutput = Union[str, SimpleOutput, AgentTrace]


@dataclass
class EnhancedExperimentResult:
    """Enhanced experiment result with rich output capture."""

    example_id: str
    input_data: Dict[str, Any]
    output: Optional[Dict[str, Any]]

    # Enhanced output fields
    raw_output: TestFunctionOutput  # The actual output from test function
    final_response: str  # Extracted final response for compatibility

    # Evaluation results
    evaluation_scores: Dict[str, float] = field(default_factory=dict)
    evaluator_metadata: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    # Execution metadata
    metadata: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    execution_time_ms: Optional[float] = None
    evaluator_execution_times_ms: Dict[str, float] = field(default_factory=dict)

    def extract_final_response(self) -> str:
        """Extract final response string from any output type."""
        if isinstance(self.raw_output, str):
            return self.raw_output
        elif isinstance(self.raw_output, (SimpleOutput, AgentTrace)):
            return self.raw_output.final_response
        else:
            return str(self.raw_output)

    def get_agent_trace(self) -> Optional[AgentTrace]:
        """Get agent trace if output contains one."""
        if isinstance(self.raw_output, AgentTrace):
            return self.raw_output
        return None

    def get_tool_usage(self) -> List[ToolCall]:
        """Extract tool usage from any output type."""
        if isinstance(self.raw_output, AgentTrace):
            return self.raw_output.tools_called
        return []

    def get_total_tokens(self) -> Optional[int]:
        """Extract total token usage."""
        if isinstance(self.raw_output, AgentTrace):
            return self.raw_output.total_tokens
        return None


@dataclass
class EvaluationContext:
    """Runtime evaluation context containing expected and actual data for evaluators.

    This is the intermediate model between DatasetExample and ExperimentResult,
    analogous to DeepEval's LLMTestCase. It contains both expected data from
    the dataset and actual execution results from the test function.

    This model lives in the SDK because it's used during experiment execution
    and is consumed by evaluators running in the SDK environment.
    """

    # From DatasetExample (expected data)
    example_id: str
    input: Dict[str, Any]
    output: Dict[str, Any]

    # From test function execution (actual data)
    actual_output: Union[str, Dict[str, Any], List[Any]]

    # Optional fields (with defaults)
    expected_tool_calls: Optional[List[ToolCall]] = None
    actual_tool_calls: Optional[List[ToolCall]] = None
    execution_trace: Optional[AgentTrace] = None

    # Execution metadata
    execution_time_ms: Optional[float] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize evaluation context for caching."""
        return {
            "example_id": self.example_id,
            "input": self.input,
            "output": self.output,
            "expected_tool_calls": [tc.__dict__ for tc in (self.expected_tool_calls or [])],
            "actual_output": self.actual_output,
            "actual_tool_calls": [tc.__dict__ for tc in (self.actual_tool_calls or [])],
            "execution_trace": self.execution_trace.__dict__ if self.execution_trace else None,
            "execution_time_ms": self.execution_time_ms,
            "error": self.error,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvaluationContext":
        """Deserialize evaluation context from cache."""
        return cls(
            example_id=data["example_id"],
            input=data["input"],
            output=data.get("output", {}),
            expected_tool_calls=[ToolCall(**tc) for tc in (data.get("expected_tool_calls") or [])],
            actual_output=data["actual_output"],
            actual_tool_calls=[ToolCall(**tc) for tc in (data.get("actual_tool_calls") or [])],
            execution_trace=AgentTrace(**data["execution_trace"]) if data.get("execution_trace") else None,
            execution_time_ms=data.get("execution_time_ms"),
            error=data.get("error"),
            metadata=data.get("metadata", {}),
        )
