"""Tool call matching logic for evaluating tool correctness.

This module provides algorithms for comparing expected vs actual tool calls,
inspired by DeepEval's tool correctness evaluation but adapted for our ToolCall model.

Matching modes:
- exact: Tool calls must match exactly (name, arguments, order)
- strict: Tool calls must match name and arguments (order doesn't matter)
- fuzzy: Uses LCS algorithm for partial matching with similarity scoring
"""

from typing import List, Dict, Any, Tuple, Optional, Literal
from dataclasses import dataclass
import json
from difflib import SequenceMatcher

from .output_types import ToolCall


@dataclass
class ToolCallMatch:
    """Result of matching a single expected tool call against actual calls."""

    expected_tool: ToolCall
    matched_tool: Optional[ToolCall]
    similarity_score: float  # 0.0 to 1.0
    match_type: Literal["exact", "partial", "missing"]
    differences: Dict[str, Any]  # Details about what differed


@dataclass
class ToolCallMatchingResult:
    """Complete result of matching expected vs actual tool calls."""

    matches: List[ToolCallMatch]
    overall_score: float  # 0.0 to 1.0
    precision: float  # Proportion of actual calls that were expected
    recall: float  # Proportion of expected calls that were found
    extra_tools: List[ToolCall]  # Actual tools not in expected
    missing_tools: List[ToolCall]  # Expected tools not found in actual
    mode: Literal["exact", "strict", "fuzzy"]


def match_tool_calls(
    expected: List[ToolCall], actual: List[ToolCall], mode: Literal["exact", "strict", "fuzzy"] = "strict"
) -> ToolCallMatchingResult:
    """Match expected tool calls against actual tool calls.

    Args:
        expected: List of expected tool calls
        actual: List of actual tool calls from execution
        mode: Matching strategy to use

    Returns:
        Detailed matching results with scores and comparisons
    """
    if mode == "exact":
        return _match_exact(expected, actual)
    elif mode == "strict":
        return _match_strict(expected, actual)
    elif mode == "fuzzy":
        return _match_fuzzy(expected, actual)
    else:
        raise ValueError(f"Unknown matching mode: {mode}")


def _match_exact(expected: List[ToolCall], actual: List[ToolCall]) -> ToolCallMatchingResult:
    """Exact matching: order matters, all details must match perfectly."""
    matches = []

    # Compare position by position
    for i in range(max(len(expected), len(actual))):
        if i < len(expected) and i < len(actual):
            expected_tool = expected[i]
            actual_tool = actual[i]

            if _tools_equal(expected_tool, actual_tool):
                match = ToolCallMatch(
                    expected_tool=expected_tool,
                    matched_tool=actual_tool,
                    similarity_score=1.0,
                    match_type="exact",
                    differences={},
                )
            else:
                differences = _compute_tool_differences(expected_tool, actual_tool)
                match = ToolCallMatch(
                    expected_tool=expected_tool,
                    matched_tool=actual_tool,
                    similarity_score=0.0,
                    match_type="partial",
                    differences=differences,
                )
            matches.append(match)

        elif i < len(expected):
            # Missing actual tool
            match = ToolCallMatch(
                expected_tool=expected[i],
                matched_tool=None,
                similarity_score=0.0,
                match_type="missing",
                differences={"missing": True},
            )
            matches.append(match)

    # Calculate metrics
    exact_matches = [m for m in matches if m.match_type == "exact"]
    overall_score = len(exact_matches) / len(expected) if expected else 1.0

    # In exact mode, precision = recall = overall_score
    precision = recall = overall_score

    # Extra tools are those beyond expected length
    extra_tools = actual[len(expected) :] if len(actual) > len(expected) else []
    missing_tools = [m.expected_tool for m in matches if m.match_type == "missing"]

    return ToolCallMatchingResult(
        matches=matches,
        overall_score=overall_score,
        precision=precision,
        recall=recall,
        extra_tools=extra_tools,
        missing_tools=missing_tools,
        mode="exact",
    )


def _match_strict(expected: List[ToolCall], actual: List[ToolCall]) -> ToolCallMatchingResult:
    """Strict matching: order doesn't matter, but name and arguments must match exactly."""
    matches = []
    used_actual = set()  # Track which actual tools we've matched

    for expected_tool in expected:
        best_match = None
        best_score = 0.0
        best_index = -1

        for i, actual_tool in enumerate(actual):
            if i in used_actual:
                continue

            if _tools_equal(expected_tool, actual_tool):
                # Perfect match found
                best_match = actual_tool
                best_score = 1.0
                best_index = i
                break

        if best_match:
            used_actual.add(best_index)
            match = ToolCallMatch(
                expected_tool=expected_tool,
                matched_tool=best_match,
                similarity_score=best_score,
                match_type="exact",
                differences={},
            )
        else:
            match = ToolCallMatch(
                expected_tool=expected_tool,
                matched_tool=None,
                similarity_score=0.0,
                match_type="missing",
                differences={"missing": True},
            )

        matches.append(match)

    # Calculate metrics
    exact_matches = [m for m in matches if m.match_type == "exact"]
    overall_score = len(exact_matches) / len(expected) if expected else 1.0

    # Precision: how many actual calls were expected
    precision = len(exact_matches) / len(actual) if actual else 1.0

    # Recall: how many expected calls were found
    recall = len(exact_matches) / len(expected) if expected else 1.0

    # Extra tools are unused actual tools
    extra_tools = [tool for i, tool in enumerate(actual) if i not in used_actual]
    missing_tools = [m.expected_tool for m in matches if m.match_type == "missing"]

    return ToolCallMatchingResult(
        matches=matches,
        overall_score=overall_score,
        precision=precision,
        recall=recall,
        extra_tools=extra_tools,
        missing_tools=missing_tools,
        mode="strict",
    )


def _match_fuzzy(expected: List[ToolCall], actual: List[ToolCall]) -> ToolCallMatchingResult:
    """Fuzzy matching: uses similarity scoring for partial matches."""
    matches = []
    used_actual = set()

    for expected_tool in expected:
        best_match = None
        best_score = 0.0
        best_index = -1
        best_differences = {}

        for i, actual_tool in enumerate(actual):
            if i in used_actual:
                continue

            similarity, differences = _compute_tool_similarity(expected_tool, actual_tool)

            if similarity > best_score:
                best_match = actual_tool
                best_score = similarity
                best_index = i
                best_differences = differences

        # Only consider it a match if similarity is above threshold
        if best_score >= 0.5:  # Configurable threshold
            used_actual.add(best_index)
            match_type = "exact" if best_score == 1.0 else "partial"
            match = ToolCallMatch(
                expected_tool=expected_tool,
                matched_tool=best_match,
                similarity_score=best_score,
                match_type=match_type,
                differences=best_differences,
            )
        else:
            match = ToolCallMatch(
                expected_tool=expected_tool,
                matched_tool=None,
                similarity_score=0.0,
                match_type="missing",
                differences={"missing": True},
            )

        matches.append(match)

    # Calculate metrics using weighted scores
    total_similarity = sum(m.similarity_score for m in matches)
    overall_score = total_similarity / len(expected) if expected else 1.0

    # Precision considers partial matches
    matched_count = len([m for m in matches if m.matched_tool is not None])
    precision = matched_count / len(actual) if actual else 1.0

    # Recall considers partial matches with their similarity scores
    recall = total_similarity / len(expected) if expected else 1.0

    # Extra tools
    extra_tools = [tool for i, tool in enumerate(actual) if i not in used_actual]
    missing_tools = [m.expected_tool for m in matches if m.match_type == "missing"]

    return ToolCallMatchingResult(
        matches=matches,
        overall_score=overall_score,
        precision=precision,
        recall=recall,
        extra_tools=extra_tools,
        missing_tools=missing_tools,
        mode="fuzzy",
    )


def _tools_equal(tool1: ToolCall, tool2: ToolCall) -> bool:
    """Check if two tool calls are exactly equal."""
    return tool1.name == tool2.name and tool1.args == tool2.args


def _compute_tool_differences(expected: ToolCall, actual: ToolCall) -> Dict[str, Any]:
    """Compute specific differences between two tool calls."""
    differences = {}

    if expected.name != actual.name:
        differences["name"] = {"expected": expected.name, "actual": actual.name}

    if expected.args != actual.args:
        differences["args"] = {"expected": expected.args, "actual": actual.args}

    return differences


def _compute_tool_similarity(expected: ToolCall, actual: ToolCall) -> Tuple[float, Dict[str, Any]]:
    """Compute similarity score between two tool calls using multiple factors."""
    differences = _compute_tool_differences(expected, actual)

    # Start with base similarity
    similarity_components = []

    # Name similarity (most important)
    name_similarity = _string_similarity(expected.name, actual.name)
    similarity_components.append(("name", name_similarity, 0.6))  # 60% weight

    # Arguments similarity (important but complex)
    args_similarity = _arguments_similarity(expected.args, actual.args)
    similarity_components.append(("args", args_similarity, 0.4))  # 40% weight

    # Weighted average
    weighted_sum = sum(score * weight for _, score, weight in similarity_components)
    total_weight = sum(weight for _, _, weight in similarity_components)
    overall_similarity = weighted_sum / total_weight

    return overall_similarity, differences


def _string_similarity(s1: str, s2: str) -> float:
    """Calculate string similarity using SequenceMatcher."""
    if not s1 and not s2:
        return 1.0
    if not s1 or not s2:
        return 0.0

    return SequenceMatcher(None, s1.lower(), s2.lower()).ratio()


def _arguments_similarity(args1: Optional[Dict[str, Any]], args2: Optional[Dict[str, Any]]) -> float:
    """Calculate similarity between argument dictionaries."""
    # Handle None cases
    if args1 is None and args2 is None:
        return 1.0
    if args1 is None or args2 is None:
        return 0.0

    # Empty dict cases
    if not args1 and not args2:
        return 1.0
    if not args1 or not args2:
        return 0.0

    # Convert to JSON strings for comparison
    try:
        str1 = json.dumps(args1, sort_keys=True)
        str2 = json.dumps(args2, sort_keys=True)

        # Exact match
        if str1 == str2:
            return 1.0

        # Use LCS-like algorithm for partial matching
        return _dict_similarity(args1, args2)

    except (TypeError, ValueError):
        # Fallback to string comparison if JSON serialization fails
        return _string_similarity(str(args1), str(args2))


def _dict_similarity(dict1: Dict[str, Any], dict2: Dict[str, Any]) -> float:
    """Calculate similarity between dictionaries using key-value matching."""
    all_keys = set(dict1.keys()) | set(dict2.keys())
    if not all_keys:
        return 1.0

    matching_keys = 0
    total_value_similarity = 0.0

    for key in all_keys:
        if key in dict1 and key in dict2:
            # Both have the key, check value similarity
            val1, val2 = dict1[key], dict2[key]

            if val1 == val2:
                matching_keys += 1
                total_value_similarity += 1.0
            else:
                # Partial credit for similar values
                if isinstance(val1, str) and isinstance(val2, str):
                    total_value_similarity += _string_similarity(val1, val2)
                else:
                    # Different types or complex values - no credit
                    total_value_similarity += 0.0

        # If key is missing from either dict, no credit for that key

    # Average similarity across all keys
    return total_value_similarity / len(all_keys)
