"""CAT Cafe SDK client for external experiment integration."""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Union
import httpx
import json
import warnings
import uuid
from pathlib import Path
from datetime import datetime, timedelta

from cat.experiments.models import DatasetExample as _DatasetExample


@dataclass
class Experiment:
    """Experiment configuration."""

    __test__ = False  # Tell pytest this is not a test class

    name: str
    description: str
    dataset_id: str
    dataset_version: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ExperimentResult:
    """A single experiment result."""

    __test__ = False  # Tell pytest this is not a test class

    example_id: str
    input_data: Dict[str, Any]
    output: Optional[Dict[str, Any]]
    actual_output: Dict[str, Any] | str
    evaluation_scores: Dict[str, float] = field(default_factory=dict)
    evaluator_metadata: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    execution_time_ms: Optional[float] = None  # Test function execution time in milliseconds
    evaluator_execution_times_ms: Dict[str, float] = field(default_factory=dict)  # Per-evaluator execution times


@dataclass
class DatasetConfig:
    """Dataset configuration for creation."""

    name: str
    description: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


DatasetExample = _DatasetExample


@dataclass
class DatasetImport:
    """Complete dataset with examples for import."""

    name: str
    description: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    examples: List[DatasetExample] = field(default_factory=list)


Example = _DatasetExample


@dataclass
class Dataset:
    """A dataset retrieved from the API."""

    id: str
    name: str
    description: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    example_count: int = 0
    version: int = 1
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    examples: List[Example] = field(default_factory=list)


@dataclass
class ExperimentDetail:
    """Complete experiment details including metadata and results."""

    experiment_id: str
    name: str
    description: str
    dataset_id: str
    dataset_version: Optional[str]
    tags: List[str]
    metadata: Dict[str, Any]
    status: str
    created_at: str
    completed_at: Optional[str]
    summary: Dict[str, Any]
    created_by: str
    results: List[ExperimentResult]


@dataclass
class EvaluationMetric:
    """Evaluation metric result with name, score, and metadata."""

    name: str
    score: float
    metadata: Dict[str, Any] = field(default_factory=dict)


# Backwards compatibility alias
EvaluatorResult = EvaluationMetric


def _extract_evaluator_result(result: Any, evaluator_name: str) -> tuple[str, float, Dict[str, Any]]:
    """Extract name, score and metadata from various evaluator return types.

    Supported return types:
    - float: Just a score
    - tuple[float, dict]: Score and metadata dictionary
    - EvaluationMetric: Structured result object (preferred)
    - EvaluatorResult: Legacy alias for EvaluationMetric
    """
    if isinstance(result, (EvaluationMetric, EvaluatorResult)):
        name = getattr(result, "name", evaluator_name)  # Use evaluator_name as fallback
        return name, result.score, result.metadata
    elif isinstance(result, tuple):
        if len(result) == 2:
            score, metadata = result
            if isinstance(score, (int, float)):
                if isinstance(metadata, dict):
                    return evaluator_name, float(score), metadata
                else:
                    # Convert non-dict metadata to dict with "reason" key
                    return evaluator_name, float(score), {"reason": str(metadata)}
            else:
                raise ValueError(
                    f"Invalid tuple format for {evaluator_name}: Expected (float, dict) or (float, str), got ({type(score)}, {type(metadata)})"
                )
        else:
            raise ValueError(f"Invalid tuple length for {evaluator_name}: Expected 2 elements, got {len(result)}")
    elif isinstance(result, (int, float)):
        return evaluator_name, float(result), {}
    else:
        raise ValueError(
            f"Invalid evaluator return type for {evaluator_name}: Expected float, tuple[float, dict], or EvaluationMetric, got {type(result)}"
        )


class CATCafeClient:
    """Client for running external experiments against CAT."""

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        project_id: str = "default",
        session=None,
        cache_dir: Optional[str] = None,
    ):
        self.base_url = base_url
        # project_id kept for backward compatibility but no longer used in URLs
        self.project_id = project_id
        self._session: Optional[Any] = session  # For testing or custom sessions
        self.cache_dir = Path(cache_dir) if cache_dir else Path(".cat_cache")
        self.offline_mode = "warn"  # Can be set later

    def _build_api_url(self, endpoint: str) -> str:
        """Build API URL for an endpoint."""
        # Remove leading slash if present
        endpoint = endpoint.lstrip("/")
        return f"/api/{endpoint}"

    def _make_request(self, method: str, url: str, **kwargs):
        """Make HTTP request using either httpx client or test client."""
        if self._session:
            # Use test client (for testing)
            if method.upper() == "GET":
                return self._session.get(url, **kwargs)
            elif method.upper() == "POST":
                return self._session.post(url, **kwargs)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
        else:
            # Use httpx client
            full_url = f"{self.base_url}{url}"
            with httpx.Client() as client:
                if method.upper() == "GET":
                    return client.get(full_url, **kwargs)
                elif method.upper() == "POST":
                    return client.post(full_url, **kwargs)
                else:
                    raise ValueError(f"Unsupported HTTP method: {method}")

    @staticmethod
    def _hydrate_dataset_metadata(metadata: Optional[Dict[str, Any]], tags: List[str]) -> Dict[str, Any]:
        """Ensure dataset metadata mirrors important top-level fields for downstream tooling."""

        base: Dict[str, Any] = dict(metadata or {})
        if tags and "tags" not in base:
            base["tags"] = list(tags)
        return base

    def _get_dataset_cache_path(self, dataset_id: str) -> Path:
        """Get the cache file path for a dataset."""
        return self.cache_dir / "datasets" / f"{dataset_id}.json"

    @staticmethod
    def _json_default(value: Any) -> Any:
        """Convert non-standard JSON data (e.g., datetime) to serializable forms."""
        if isinstance(value, datetime):
            return value.isoformat()
        raise TypeError(f"{value.__class__.__name__} is not JSON serializable")

    def _cache_dataset(self, dataset_id: str, dataset_data: Union[Dict, Dataset]) -> None:
        """Cache dataset data to local file system."""
        cache_path = self._get_dataset_cache_path(dataset_id)
        cache_path.parent.mkdir(parents=True, exist_ok=True)

        # Convert Dataset object to dict if needed
        if isinstance(dataset_data, Dataset):
            examples_payload = []
            for ex in dataset_data.examples:
                metadata = dict(ex.metadata)
                # Ensure expected tool calls are JSON-serializable
                if "expected_tool_calls" in metadata:
                    metadata["expected_tool_calls"] = [
                        tc if isinstance(tc, dict) else getattr(tc, "to_dict", lambda: tc)()
                        for tc in metadata["expected_tool_calls"]
                    ]
                example_payload: dict[str, Any] = {
                    "id": ex.id,
                    "input": ex.input,
                    "output": ex.output,
                    "metadata": metadata,
                    "created_at": ex.created_at,
                    "updated_at": ex.updated_at,
                }
                examples_payload.append(example_payload)

            data_to_cache = {
                "id": dataset_data.id,
                "name": dataset_data.name,
                "description": dataset_data.description,
                "tags": list(dataset_data.tags),
                "metadata": dict(dataset_data.metadata),
                "example_count": dataset_data.example_count,
                "version": dataset_data.version,
                "created_at": dataset_data.created_at,
                "updated_at": dataset_data.updated_at,
                "examples": examples_payload,
            }
        else:
            data_to_cache = dataset_data

        # Add cache metadata
        cache_data = {"cached_at": datetime.now().isoformat(), "dataset": data_to_cache}

        with open(cache_path, "w") as f:
            json.dump(cache_data, f, indent=2, default=self._json_default)

    def _get_cached_dataset(self, dataset_id: str, ttl_hours: float = 24) -> Optional[Dataset]:
        """Get dataset from cache if available and not expired."""
        cache_path = self._get_dataset_cache_path(dataset_id)

        if not cache_path.exists():
            return None

        try:
            with open(cache_path, "r") as f:
                cache_data = json.load(f)

            # Check if cache is expired
            cached_at = datetime.fromisoformat(cache_data["cached_at"])
            if ttl_hours != float("inf") and datetime.now() - cached_at > timedelta(hours=ttl_hours):
                return None

            # Convert to Dataset object
            dataset_data = cache_data["dataset"]
            examples = []
            for ex_data in dataset_data.get("examples", []):
                metadata = dict(ex_data.get("metadata", {}))
                if "tags" in ex_data:
                    metadata.setdefault("tags", ex_data.get("tags", []))
                if ex_data.get("source_trace_id") is not None:
                    metadata["source_trace_id"] = ex_data["source_trace_id"]
                if ex_data.get("source_node_id") is not None:
                    metadata["source_node_id"] = ex_data["source_node_id"]

                example = Example(
                    input=ex_data.get("input", {}),
                    output=ex_data.get("output", {}),
                    metadata=metadata,
                    id=ex_data.get("id"),
                    created_at=ex_data.get("created_at"),
                    updated_at=ex_data.get("updated_at"),
                )
                examples.append(example)

            dataset = Dataset(
                id=dataset_data["id"],
                name=dataset_data["name"],
                description=dataset_data.get("description"),
                metadata=dataset_data.get("metadata", {}),
                example_count=dataset_data.get("example_count", len(examples)),
                version=dataset_data.get("version", 1),
                created_at=dataset_data.get("created_at"),
                updated_at=dataset_data.get("updated_at"),
                examples=examples,
            )

            return dataset

        except (json.JSONDecodeError, KeyError, ValueError):
            # Invalid cache file
            return None

    def is_dataset_stale(self, dataset_id: str) -> bool:
        """Check if the cached dataset is stale (expired or outdated)."""
        cache_path = self._get_dataset_cache_path(dataset_id)

        if not cache_path.exists():
            return True

        try:
            with open(cache_path, "r") as f:
                cache_data = json.load(f)

            cached_at = datetime.fromisoformat(cache_data["cached_at"])
            # Consider stale if older than 24 hours
            return datetime.now() - cached_at > timedelta(hours=24)

        except (json.JSONDecodeError, KeyError, ValueError):
            return True

    def cache_dataset(self, dataset_id: str, ttl_hours: int = 24) -> None:
        """Explicitly cache a dataset from the server."""
        try:
            dataset = self.fetch_dataset(dataset_id, use_cache=False)  # Force fresh fetch
            self._cache_dataset(dataset_id, dataset)
        except Exception as e:
            if self.offline_mode == "fail":
                raise
            elif self.offline_mode == "warn":
                warnings.warn(f"Failed to cache dataset {dataset_id}: {e}")

    def get_cached_dataset(self, dataset_id: str) -> Optional[Dataset]:
        """Get a dataset from cache, regardless of age."""
        return self._get_cached_dataset(dataset_id, ttl_hours=float("inf"))

    # Recovery cache methods for experiments
    def _get_experiment_cache_dir(self, experiment_id: str) -> Path:
        """Get the cache directory for an experiment."""
        return self.cache_dir / "experiments" / experiment_id

    def _cache_experiment_metadata(self, experiment_id: str, dataset: Dataset, config: Dict[str, Any]) -> None:
        """Cache experiment metadata including full dataset snapshot."""
        cache_dir = self._get_experiment_cache_dir(experiment_id)
        cache_dir.mkdir(parents=True, exist_ok=True)

        dataset_metadata = self._hydrate_dataset_metadata(dataset.metadata, dataset.tags)

        metadata = {
            "experiment_id": experiment_id,
            "cached_at": datetime.now().isoformat(),
            "config": config,
            "dataset": {
                "id": dataset.id,
                "name": dataset.name,
                "description": dataset.description,
                "metadata": dataset_metadata,
                "example_count": dataset.example_count,
                "version": dataset.version,
                "examples": [
                    {
                        "id": ex.id,
                        "input": ex.input,
                        "output": ex.output,
                        "source_trace_id": ex.source_trace_id,
                        "source_node_id": ex.source_node_id,
                        "metadata": ex.metadata,
                    }
                    for ex in dataset.examples
                ],
            },
        }

        with open(cache_dir / "metadata.json", "w") as f:
            json.dump(metadata, f, indent=2)

    def _get_cached_experiment_metadata(self, experiment_id: str) -> Optional[Dict[str, Any]]:
        """Get cached experiment metadata if available."""
        metadata_file = self._get_experiment_cache_dir(experiment_id) / "metadata.json"

        if not metadata_file.exists():
            return None

        try:
            with open(metadata_file, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return None

    def _cache_example_result(self, experiment_id: str, example_id: str, result: Dict[str, Any]) -> None:
        """Cache a successful example result."""
        results_dir = self._get_experiment_cache_dir(experiment_id) / "results"
        results_dir.mkdir(parents=True, exist_ok=True)

        # Use atomic write
        result_file = results_dir / f"{example_id}.json"
        temp_file = result_file.with_suffix(".tmp")

        result_data = {"example_id": example_id, "cached_at": datetime.now().isoformat(), **result}

        with open(temp_file, "w") as f:
            json.dump(result_data, f, indent=2)

        # Atomic rename
        temp_file.rename(result_file)

        # Remove error file if it exists
        error_file = results_dir / f"{example_id}.error"
        if error_file.exists():
            error_file.unlink()

    def _cache_example_error(self, experiment_id: str, example_id: str, error: str) -> None:
        """Cache a failed example for retry."""
        results_dir = self._get_experiment_cache_dir(experiment_id) / "results"
        results_dir.mkdir(parents=True, exist_ok=True)

        error_file = results_dir / f"{example_id}.error"
        error_data = {"example_id": example_id, "error": error, "failed_at": datetime.now().isoformat()}

        with open(error_file, "w") as f:
            json.dump(error_data, f, indent=2)

    def _get_cached_example_result(self, experiment_id: str, example_id: str) -> Optional[Dict[str, Any]]:
        """Get cached result for an example if available."""
        result_file = self._get_experiment_cache_dir(experiment_id) / "results" / f"{example_id}.json"

        if not result_file.exists():
            return None

        try:
            with open(result_file, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return None

    def _is_example_completed(self, experiment_id: str, example_id: str) -> bool:
        """Check if an example has been successfully completed."""
        result_file = self._get_experiment_cache_dir(experiment_id) / "results" / f"{example_id}.json"
        return result_file.exists()

    def _get_completed_example_ids(self, experiment_id: str) -> set:
        """Get set of completed example IDs."""
        results_dir = self._get_experiment_cache_dir(experiment_id) / "results"

        if not results_dir.exists():
            return set()

        completed = set()
        for file in results_dir.glob("*.json"):
            # Extract example ID from filename
            completed.add(file.stem)

        return completed

    def _has_experiment_cache(self, experiment_id: str) -> bool:
        """Check if experiment has existing cache."""
        metadata_file = self._get_experiment_cache_dir(experiment_id) / "metadata.json"
        return metadata_file.exists()

    def _mark_experiment_completed(self, experiment_id: str) -> None:
        """Mark an experiment as completed in cache."""
        cache_dir = self._get_experiment_cache_dir(experiment_id)
        cache_dir.mkdir(parents=True, exist_ok=True)
        completed_file = cache_dir / "completed"
        completed_file.write_text(datetime.now().isoformat())

    def _clean_experiment_cache(self, experiment_id: str) -> None:
        """Remove experiment cache directory."""
        import shutil

        cache_dir = self._get_experiment_cache_dir(experiment_id)
        if cache_dir.exists():
            shutil.rmtree(cache_dir)

    def _generate_experiment_id(self) -> str:
        """Generate a unique experiment ID."""
        # Format: exp-YYYY-MM-DD-XXXXXX (date + 6 char random)
        date_str = datetime.now().strftime("%Y-%m-%d")
        random_str = str(uuid.uuid4())[:6]
        return f"exp-{date_str}-{random_str}"

    def get_dataset(self, dataset_id: str, version: Optional[str] = None) -> Dict:
        """Fetch dataset examples from CAT server."""
        url = self._build_api_url(f"datasets/{dataset_id}/examples")
        params = {"version": version} if version else {}
        response = self._make_request("GET", url, params=params)
        response.raise_for_status()
        return response.json()

    def start_experiment(self, experiment_config: Experiment) -> str:
        """Create experiment record, returns experiment_id."""
        url = self._build_api_url("experiments")
        response = self._make_request(
            "POST",
            url,
            json={
                "name": experiment_config.name,
                "description": experiment_config.description,
                "dataset_id": experiment_config.dataset_id,
                "dataset_version": experiment_config.dataset_version,
                "tags": experiment_config.tags,
                "metadata": experiment_config.metadata,
            },
        )
        response.raise_for_status()
        return response.json()["experiment_id"]

    def get_experiment(self, experiment_id: str) -> Dict:
        """Get experiment details."""
        url = self._build_api_url(f"experiments/{experiment_id}")
        response = self._make_request("GET", url)
        response.raise_for_status()
        return response.json()

    def submit_results(self, experiment_id: str, results: List[ExperimentResult]):
        """Submit experiment results to CAT server."""
        url = self._build_api_url(f"experiments/{experiment_id}/results")
        results_data = [
            {
                "example_id": r.example_id,
                "input_data": r.input_data,
                "output": r.output,
                "actual_output": r.actual_output,
                "evaluation_scores": r.evaluation_scores,
                "evaluator_metadata": r.evaluator_metadata,
                "metadata": r.metadata,
                "error": r.error,
            }
            for r in results
        ]
        response = self._make_request("POST", url, json={"results": results_data})
        response.raise_for_status()

    def complete_experiment(self, experiment_id: str, summary: Optional[Dict[str, Any]] = None):
        """Mark experiment as completed."""
        url = self._build_api_url(f"experiments/{experiment_id}/complete")
        response = self._make_request("POST", url, json={"summary": summary or {}})
        response.raise_for_status()

    def get_experiment_results(self, experiment_id: str) -> List[Dict]:
        """Get experiment results for an experiment."""
        url = self._build_api_url(f"experiments/{experiment_id}/results")
        response = self._make_request("GET", url)
        response.raise_for_status()
        return response.json()["results"]

    def list_experiments(self) -> List[Dict]:
        """List all experiments."""
        url = self._build_api_url("experiments")
        response = self._make_request("GET", url)
        response.raise_for_status()
        return response.json()["experiments"]

    def list_experiments_by_dataset(self, dataset_id: str) -> List[Dict]:
        """List experiments for a specific dataset."""
        url = self._build_api_url(f"datasets/{dataset_id}/experiments")
        response = self._make_request("GET", url)
        response.raise_for_status()
        return response.json()["experiments"]

    def get_experiment_detail(self, experiment_id: str) -> Dict:
        """Get experiment with its results.

        Returns a dict with 'experiment' and 'results' keys.
        """
        url = self._build_api_url(f"experiments/{experiment_id}/detail")
        response = self._make_request("GET", url)
        response.raise_for_status()
        return response.json()

    def compare_experiments(self, experiment_a: str, experiment_b: str) -> Dict:
        """Compare two experiments side-by-side.

        Args:
            experiment_a: ID of the first experiment
            experiment_b: ID of the second experiment

        Returns:
            Comparison data including results and summary statistics
        """
        url = self._build_api_url("experiments/compare")
        params = {"experiment_a": experiment_a, "experiment_b": experiment_b}
        response = self._make_request("GET", url, params=params)
        response.raise_for_status()
        return response.json()

    def get_experiment_timeline(self, dataset_id: str) -> Dict:
        """Get timeline data for experiments on a dataset.

        Returns timeline data optimized for visualization including
        aggregated metrics and experiment metadata.
        """
        url = self._build_api_url(f"datasets/{dataset_id}/experiments/timeline")
        response = self._make_request("GET", url)
        response.raise_for_status()
        return response.json()

    def get_evaluation_metrics(self) -> List[Dict]:
        """Get available evaluation metrics from CAT."""
        url = self._build_api_url("evaluation-metrics")
        response = self._make_request("GET", url)
        response.raise_for_status()
        return response.json()["metrics"]

    def create_dataset(self, dataset: DatasetConfig) -> str:
        """Create a new dataset and return its ID."""
        url = self._build_api_url("datasets")
        response = self._make_request(
            "POST",
            url,
            json={
                "name": dataset.name,
                "description": dataset.description,
                "tags": dataset.tags,
                "metadata": self._hydrate_dataset_metadata(dataset.metadata, dataset.tags),
            },
        )
        response.raise_for_status()
        return response.json()["id"]

    def get_dataset_info(self, dataset_id: str) -> Dict:
        """Get dataset information by ID."""
        url = self._build_api_url(f"datasets/{dataset_id}")
        response = self._make_request("GET", url)
        response.raise_for_status()
        return response.json()

    def add_dataset_example(self, dataset_id: str, example: DatasetExample) -> str:
        """Add an example to a dataset and return the example ID."""
        url = self._build_api_url(f"datasets/{dataset_id}/examples")
        response = self._make_request(
            "POST",
            url,
            json={
                "input": example.input,
                "output": example.output,
                "tags": example.tags,
                "metadata": example.metadata,
            },
        )
        response.raise_for_status()
        return response.json()["example_id"]

    def get_dataset_examples(self, dataset_id: str, version: Optional[str] = None) -> List[Dict]:
        """Get examples from a dataset."""
        url = self._build_api_url(f"datasets/{dataset_id}/examples")
        params = {"version": version} if version else {}
        response = self._make_request("GET", url, params=params)
        response.raise_for_status()
        return response.json()

    def list_datasets(self) -> List[Dict]:
        """List all datasets."""
        url = self._build_api_url("datasets")
        response = self._make_request("GET", url)
        response.raise_for_status()
        return response.json()

    def add_example_from_trace(
        self,
        dataset_id: str,
        trace_id: str,
        node_id: str,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Create a dataset example from a trace span.

        Args:
            dataset_id: Target dataset ID
            trace_id: Tempo trace identifier
            node_id: LLM span node ID within the trace
            tags: Optional tags to annotate the new example
            metadata: Optional metadata to merge into the example

        Returns:
            Response payload from the API including the created example and updated dataset metadata.
        """

        payload = {
            "trace_id": trace_id,
            "node_id": node_id,
            "tags": tags or [],
            "metadata": metadata or {},
        }

        url = self._build_api_url(f"datasets/{dataset_id}/examples/from-span")
        response = self._make_request("POST", url, json=payload)
        response.raise_for_status()

        result = response.json()

        # Refresh dataset cache with latest metadata if available
        dataset_info = result.get("dataset")
        if dataset_info:
            try:
                self._cache_dataset(dataset_id, dataset_info)
            except Exception:
                # Cache failures should not break primary operation
                pass

        return result

    def find_dataset_by_name(self, name: str) -> Optional[Dict]:
        """Find a dataset by name. Returns None if not found."""
        datasets = self.list_datasets()
        for dataset in datasets:
            if dataset.get("name") == name:
                return dataset
        return None

    def fetch_dataset(
        self, dataset_id: str, version: Optional[str] = None, use_cache: bool = True, cache_ttl_hours: int = 24
    ) -> Dataset:
        """Fetch a complete dataset with its examples as structured objects.

        Args:
            dataset_id: The dataset ID to fetch
            version: Optional specific version to fetch
            use_cache: Whether to use cached version if available
            cache_ttl_hours: How long cached datasets are considered fresh

        Returns:
            Dataset object with examples
        """
        # Try to get from cache first if enabled
        if use_cache and version is None:  # Only cache latest version
            cached_dataset = self._get_cached_dataset(dataset_id, ttl_hours=cache_ttl_hours)
            if cached_dataset:
                return cached_dataset

        try:
            # Get dataset info
            dataset_info = self.get_dataset_info(dataset_id)

            # Get examples
            examples_data = self.get_dataset_examples(dataset_id, version=version)

            # Convert examples to structured objects
            examples = []
            for example_data in examples_data:
                metadata = dict(example_data.get("metadata", {}))
                if "tags" in example_data:
                    metadata.setdefault("tags", example_data.get("tags", []))
                if example_data.get("source_trace_id") is not None:
                    metadata["source_trace_id"] = example_data["source_trace_id"]
                if example_data.get("source_node_id") is not None:
                    metadata["source_node_id"] = example_data["source_node_id"]

                example = Example(
                    input=example_data.get("input", {}),
                    output=example_data.get("output", {}),
                    metadata=metadata,
                    id=example_data.get("id"),
                    created_at=example_data.get("created_at"),
                    updated_at=example_data.get("updated_at"),
                )
                examples.append(example)

            # Create structured dataset object
            dataset = Dataset(
                id=dataset_info["id"],
                name=dataset_info["name"],
                description=dataset_info.get("description"),
                tags=dataset_info.get("tags", []),
                metadata=dict(dataset_info.get("metadata", {})),
                example_count=dataset_info.get("example_count", 0),
                version=dataset_info.get("version", 1),
                created_at=dataset_info.get("created_at"),
                updated_at=dataset_info.get("updated_at"),
                examples=examples,
            )

            # Cache the dataset if caching is enabled
            if use_cache and version is None:
                self._cache_dataset(dataset_id, dataset)

            return dataset

        except Exception as e:
            # If fetching fails, try cache as fallback
            if use_cache:
                cached_dataset = self._get_cached_dataset(dataset_id, ttl_hours=float("inf"))  # Accept any age
                if cached_dataset:
                    if self.offline_mode == "warn":
                        warnings.warn(f"Failed to fetch dataset from server, using cached version: {e}")
                    return cached_dataset

            # Re-raise if no cache available
            raise

    def fetch_dataset_by_name(self, name: str) -> Optional[Dataset]:
        """Fetch a complete dataset by name with its examples as structured objects."""
        dataset_info = self.find_dataset_by_name(name)
        if not dataset_info:
            return None

        return self.fetch_dataset(dataset_info["id"])

    def import_dataset(self, dataset_import: DatasetImport) -> Dict:
        """Import a complete dataset with examples in one API call."""
        url = self._build_api_url("datasets/import")

        # Convert DatasetExample objects to dictionaries
        examples_data = []
        for example in dataset_import.examples:
            example_dict = {
                "input": example.input,
                "output": example.output,
                "tags": list(example.tags),
                "metadata": example.metadata,
            }
            # Add source fields if present
            if example.source_trace_id is not None:
                example_dict["source_trace_id"] = example.source_trace_id
            if example.source_node_id is not None:
                example_dict["source_node_id"] = example.source_node_id
            examples_data.append(example_dict)

        response = self._make_request(
            "POST",
            url,
            json={
                "name": dataset_import.name,
                "description": dataset_import.description,
                "tags": dataset_import.tags,
                "metadata": dataset_import.metadata,
                "examples": examples_data,
            },
        )
        response.raise_for_status()
        return response.json()

    def _prepare_dataset(self, dataset: Union[Dataset, str, Dict], use_cache: bool) -> Dataset:
        """Prepare dataset object from various input types."""
        if isinstance(dataset, str):
            # Fetch dataset by ID
            return self.fetch_dataset(dataset, use_cache=use_cache)
        elif isinstance(dataset, dict):
            # Convert dict to Dataset object
            return self._dataset_from_dict(dataset)
        else:
            # Already a Dataset object
            return dataset

    def _dataset_from_dict(self, dataset_dict: Dict) -> Dataset:
        """Convert a dictionary to a Dataset object."""
        examples = []
        for ex_data in dataset_dict.get("examples", []):
            metadata = dict(ex_data.get("metadata", {}))
            if "tags" in ex_data:
                metadata.setdefault("tags", ex_data.get("tags", []))
            if ex_data.get("source_trace_id") is not None:
                metadata["source_trace_id"] = ex_data["source_trace_id"]
            if ex_data.get("source_node_id") is not None:
                metadata["source_node_id"] = ex_data["source_node_id"]
            example = Example(
                input=ex_data.get("input", {}),
                output=ex_data.get("output", {}),
                metadata=metadata,
                id=ex_data.get("id"),
                created_at=ex_data.get("created_at"),
                updated_at=ex_data.get("updated_at"),
            )
            examples.append(example)

        return Dataset(
            id=dataset_dict.get("id", "unknown"),
            name=dataset_dict.get("name", "Unknown Dataset"),
            description=dataset_dict.get("description"),
            tags=dataset_dict.get("tags", []),
            metadata=dataset_dict.get("metadata", {}),
            example_count=len(examples),
            version=dataset_dict.get("version", 1),
            examples=examples,
        )

    def _dataset_from_cache_data(self, cache_data: Dict) -> Dataset:
        """Convert cached dataset data to Dataset object."""
        examples = []
        for ex_data in cache_data.get("examples", []):
            metadata = dict(ex_data.get("metadata", {}))
            if "tags" in ex_data:
                metadata.setdefault("tags", ex_data.get("tags", []))
            if ex_data.get("source_trace_id") is not None:
                metadata["source_trace_id"] = ex_data["source_trace_id"]
            if ex_data.get("source_node_id") is not None:
                metadata["source_node_id"] = ex_data["source_node_id"]
            example = Example(
                input=ex_data.get("input", {}),
                output=ex_data.get("output", {}),
                metadata=metadata,
                id=ex_data.get("id"),
                created_at=ex_data.get("created_at"),
                updated_at=ex_data.get("updated_at"),
            )
            examples.append(example)

        return Dataset(
            id=cache_data["id"],
            name=cache_data["name"],
            description=cache_data.get("description"),
            tags=cache_data.get("tags", []),
            metadata=cache_data.get("metadata", {}),
            example_count=cache_data.get("example_count", len(examples)),
            version=cache_data.get("version", 1),
            examples=examples,
        )

    def _apply_sampling(self, dataset: Dataset, sample_rate: float, random_seed: Optional[int] = None) -> Dataset:
        """Apply sampling to dataset examples based on sample_rate.

        For N examples:
        - sample_rate = 0.3: Run 30% of examples once (0.3 * N examples)
        - sample_rate = 1.0: Run each example once (N examples)
        - sample_rate = 1.3: Run each example once + 30% again (1.3 * N total runs)
        - sample_rate = 2.7: Run each example twice + 70% a third time (2.7 * N total runs)

        Args:
            dataset: Original dataset
            sample_rate: Float indicating sampling rate
            random_seed: Random seed for deterministic sampling

        Returns:
            Dataset with sampled examples
        """
        import random

        if random_seed is not None:
            random.seed(random_seed)

        examples = dataset.examples
        total_examples = len(examples)

        if sample_rate <= 0:
            # No examples to run
            return Dataset(
                id=dataset.id,
                name=dataset.name,
                description=dataset.description,
                metadata={**dataset.metadata, "sample_rate": sample_rate, "random_seed": random_seed},
                example_count=0,
                version=dataset.version,
                created_at=dataset.created_at,
                updated_at=dataset.updated_at,
                examples=[],
            )

        # Calculate total runs we want
        target_total_runs = int(sample_rate * total_examples)

        sampled_examples = []

        if sample_rate < 1.0:
            # Run subset of examples once
            num_to_run = target_total_runs
            selected_examples = random.sample(examples, min(num_to_run, total_examples))
            sampled_examples = selected_examples

        else:
            # Run each example at least floor(sample_rate) times
            base_runs_per_example = int(sample_rate)

            # Add base runs for each example
            for example in examples:
                for run_num in range(base_runs_per_example):
                    if base_runs_per_example == 1:
                        # Single run - keep original example
                        sampled_examples.append(example)
                    else:
                        # Multiple runs - create copy with unique ID
                        sampled_example = Example(
                            id=f"{example.id}_run_{run_num + 1}",
                            input=example.input,
                            output=example.output,
                            source_trace_id=example.source_trace_id,
                            source_node_id=example.source_node_id,
                            metadata={**example.metadata, "sample_run": run_num + 1, "original_id": example.id},
                            tags=example.tags + [f"run_{run_num + 1}"],
                            created_at=example.created_at,
                            updated_at=example.updated_at,
                        )
                        sampled_examples.append(sampled_example)

            # Calculate how many additional runs we need
            runs_so_far = total_examples * base_runs_per_example
            additional_runs_needed = target_total_runs - runs_so_far

            # Add additional runs by randomly selecting examples
            if additional_runs_needed > 0:
                additional_examples = random.sample(examples, min(additional_runs_needed, total_examples))
                for example in additional_examples:
                    sampled_example = Example(
                        id=f"{example.id}_run_{base_runs_per_example + 1}",
                        input=example.input,
                        output=example.output,
                        source_trace_id=example.source_trace_id,
                        source_node_id=example.source_node_id,
                        metadata={
                            **example.metadata,
                            "sample_run": base_runs_per_example + 1,
                            "original_id": example.id,
                        },
                        tags=example.tags + [f"run_{base_runs_per_example + 1}"],
                        created_at=example.created_at,
                        updated_at=example.updated_at,
                    )
                    sampled_examples.append(sampled_example)

        # Return new dataset with sampled examples
        return Dataset(
            id=dataset.id,
            name=dataset.name,
            description=dataset.description,
            metadata={**dataset.metadata, "sample_rate": sample_rate, "random_seed": random_seed},
            example_count=len(sampled_examples),
            version=dataset.version,
            created_at=dataset.created_at,
            updated_at=dataset.updated_at,
            examples=sampled_examples,
        )

    def _calculate_summary(self, results: List[ExperimentResult]) -> Dict[str, Any]:
        """Calculate summary statistics from results."""
        total = len(results)
        successful = len([r for r in results if r.error is None])

        # Aggregate scores
        score_totals = {}
        score_counts = {}

        # Collect timing data
        execution_times = []
        evaluator_timing_data = {}

        for result in results:
            if result.error is None:
                for metric, score in result.evaluation_scores.items():
                    if metric not in score_totals:
                        score_totals[metric] = 0
                        score_counts[metric] = 0
                    score_totals[metric] += score
                    score_counts[metric] += 1

                # Collect execution time if available
                if result.execution_time_ms is not None:
                    execution_times.append(result.execution_time_ms)

                # Collect evaluator timing data
                for evaluator_name, eval_time_ms in result.evaluator_execution_times_ms.items():
                    if evaluator_name not in evaluator_timing_data:
                        evaluator_timing_data[evaluator_name] = []
                    evaluator_timing_data[evaluator_name].append(eval_time_ms)

        # Calculate averages
        score_averages = {}
        for metric, total_score in score_totals.items():
            if score_counts[metric] > 0:
                score_averages[f"{metric}_avg"] = total_score / score_counts[metric]

        # Calculate timing statistics
        timing_stats = {}
        if execution_times:
            timing_stats.update(
                {
                    "avg_execution_time_ms": sum(execution_times) / len(execution_times),
                    "min_execution_time_ms": min(execution_times),
                    "max_execution_time_ms": max(execution_times),
                    "total_execution_time_ms": sum(execution_times),
                }
            )

        # Calculate evaluator timing statistics
        evaluator_timing_stats = {}
        for evaluator_name, eval_times in evaluator_timing_data.items():
            if eval_times:
                evaluator_timing_stats[f"{evaluator_name}_avg_time_ms"] = sum(eval_times) / len(eval_times)
                evaluator_timing_stats[f"{evaluator_name}_min_time_ms"] = min(eval_times)
                evaluator_timing_stats[f"{evaluator_name}_max_time_ms"] = max(eval_times)
                evaluator_timing_stats[f"{evaluator_name}_total_time_ms"] = sum(eval_times)

        return {
            "total_examples": total,
            "successful_examples": successful,
            "success_rate": successful / total if total > 0 else 0.0,
            **score_averages,
            **timing_stats,
            **evaluator_timing_stats,
        }
