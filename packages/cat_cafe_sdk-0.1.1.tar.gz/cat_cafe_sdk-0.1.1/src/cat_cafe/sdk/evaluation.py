"""Core evaluation functions for CAT Cafe experiments.

This module provides the foundational generate() and evaluate() functions that
compose together to form the experiment execution pipeline, similar to DeepEval's
evaluation system but with our unique test function abstraction.
"""

import time
import inspect
import traceback
from typing import List, Callable, Dict, Any, Optional, Union, Awaitable

from .output_types import EvaluationContext, AgentTrace, TestFunctionOutput, ToolCall
from .client import DatasetExample, EvaluationMetric, _extract_evaluator_result
from .trace_capture import capture_agent_trace


def generate(
    examples: List[DatasetExample],
    test_function: Callable[[DatasetExample], TestFunctionOutput],
    cache_config: Optional[Dict[str, Any]] = None,
) -> List[EvaluationContext]:
    """Generate evaluation contexts by executing test function on dataset examples.

    This function converts dataset examples into rich evaluation contexts by:
    1. Running the test function on each example
    2. Extracting actual output and tool calls from the test function result
    3. Creating EvaluationContext objects with both expected and actual data
    4. Optionally caching contexts for performance

    Args:
        examples: List of dataset examples to process
        test_function: Function that takes an example and returns output/trace
        cache_config: Optional caching configuration (TODO: implement)

    Returns:
        List of evaluation contexts ready for evaluator consumption
    """
    contexts = []

    for example in examples:
        start_time = time.time()
        error = None
        actual_output = ""
        actual_tool_calls = None
        execution_trace = None
        example_metadata = dict(example.metadata or {})
        if hasattr(example, "tags"):
            tags = getattr(example, "tags", [])
            if tags and "tags" not in example_metadata:
                example_metadata["tags"] = list(tags)

        try:
            # Execute test function with trace capture
            with capture_agent_trace() as capture:
                result = test_function(example)

            # Extract data from test function result
            actual_output, result_tool_calls, execution_trace = _extract_execution_data(result)

            # Also try to extract tool calls from captured OpenTelemetry traces
            trace_tool_calls = _extract_tool_calls_from_capture(capture)

            # Combine tool calls from both sources (prefer result tool calls if available)
            actual_tool_calls = result_tool_calls or trace_tool_calls

        except Exception as e:
            error = str(e)
            actual_output = ""  # Keep actual_output empty on error for consistency with legacy behavior

        execution_time_ms = (time.time() - start_time) * 1000

        # Create evaluation context with error traceback if there was an error
        context_metadata = {}
        if error:
            context_metadata["error_traceback"] = traceback.format_exc()

        expected_tool_calls_data = example_metadata.get("expected_tool_calls")
        expected_tool_calls = (
            [tc if isinstance(tc, ToolCall) else ToolCall.from_dict(tc) for tc in expected_tool_calls_data]
            if expected_tool_calls_data
            else None
        )

        context = EvaluationContext(
            example_id=getattr(example, "id", f"example_{len(contexts)}"),
            input=dict(example.input or {}),
            output=dict(example.output or {}),
            expected_tool_calls=expected_tool_calls,
            actual_output=actual_output,
            actual_tool_calls=actual_tool_calls,
            execution_trace=execution_trace,
            execution_time_ms=execution_time_ms,
            error=error,
            metadata={**example_metadata, **context_metadata},
        )

        contexts.append(context)

    return contexts


async def generate_async(
    examples: List[DatasetExample],
    test_function: Union[
        Callable[[DatasetExample], TestFunctionOutput], Callable[[DatasetExample], Awaitable[TestFunctionOutput]]
    ],
    cache_config: Optional[Dict[str, Any]] = None,
) -> List[EvaluationContext]:
    """Async version of generate() that handles both sync and async test functions.

    This function converts dataset examples into rich evaluation contexts by:
    1. Running the test function on each example (awaiting if async)
    2. Extracting actual output and tool calls from the test function result
    3. Creating EvaluationContext objects with both expected and actual data
    4. Optionally caching contexts for performance

    Args:
        examples: List of dataset examples to process
        test_function: Function (sync or async) that takes an example and returns output/trace
        cache_config: Optional caching configuration (TODO: implement)

    Returns:
        List of evaluation contexts ready for evaluator consumption
    """
    contexts = []
    is_async_func = inspect.iscoroutinefunction(test_function)

    for example in examples:
        start_time = time.time()
        error = None
        actual_output = ""
        actual_tool_calls = None
        execution_trace = None
        example_metadata = dict(example.metadata or {})
        if hasattr(example, "tags"):
            tags = getattr(example, "tags", [])
            if tags and "tags" not in example_metadata:
                example_metadata["tags"] = list(tags)

        try:
            # Execute test function with trace capture
            with capture_agent_trace() as capture:
                if is_async_func:
                    result = await test_function(example)
                else:
                    result = test_function(example)

            # Extract data from test function result
            actual_output, result_tool_calls, execution_trace = _extract_execution_data(result)

            # Also try to extract tool calls from captured OpenTelemetry traces
            trace_tool_calls = _extract_tool_calls_from_capture(capture)

            # Combine tool calls from both sources (prefer result tool calls if available)
            actual_tool_calls = result_tool_calls or trace_tool_calls

        except Exception as e:
            error = str(e)
            actual_output = ""  # Keep actual_output empty on error for consistency with legacy behavior

        execution_time_ms = (time.time() - start_time) * 1000

        # Create evaluation context with error traceback if there was an error
        context_metadata = {}
        if error:
            context_metadata["error_traceback"] = traceback.format_exc()

        expected_tool_calls_data = example_metadata.get("expected_tool_calls")
        expected_tool_calls = (
            [tc if isinstance(tc, ToolCall) else ToolCall.from_dict(tc) for tc in expected_tool_calls_data]
            if expected_tool_calls_data
            else None
        )

        context = EvaluationContext(
            example_id=getattr(example, "id", f"example_{len(contexts)}"),
            input=dict(example.input or {}),
            output=dict(example.output or {}),
            expected_tool_calls=expected_tool_calls,
            actual_output=actual_output,
            actual_tool_calls=actual_tool_calls,
            execution_trace=execution_trace,
            execution_time_ms=execution_time_ms,
            error=error,
            metadata={**example_metadata, **context_metadata},
        )

        contexts.append(context)

    return contexts


def evaluate(
    contexts: List[EvaluationContext],
    evaluators: List[Callable[[EvaluationContext], EvaluationMetric]],
) -> List[Dict[str, Any]]:
    """Evaluate contexts with given evaluators.

    This function is our equivalent to DeepEval's evaluate() - it takes evaluation
    contexts and runs multiple evaluators on them, collecting scores and metadata.

    Args:
        contexts: List of evaluation contexts to evaluate
        evaluators: List of evaluator functions

    Returns:
        List of evaluation results (one per context)
    """
    results = []

    for context in contexts:
        result = {
            "example_id": context.example_id,
            "input_data": dict(context.input or {}),
            "output": dict(context.output or {}),
            "actual_output": context.actual_output,
            "evaluation_scores": {},
            "evaluator_metadata": {},
            "metadata": {
                "execution_time_ms": context.execution_time_ms,
                "error": context.error,
                **dict(context.metadata or {}),
            },
            "error": context.error,
        }

        # Run each evaluator
        for evaluator in evaluators:
            evaluator_name = evaluator.__name__

            try:
                eval_start_time = time.time()
                eval_result = evaluator(context)
                eval_time = (time.time() - eval_start_time) * 1000

                # Use safe extraction to handle different return types (float, tuple, EvaluationMetric)
                name, score, metadata = _extract_evaluator_result(eval_result, evaluator_name)
                result["evaluation_scores"][evaluator_name] = score
                result["evaluator_metadata"][evaluator_name] = {**metadata, "execution_time_ms": eval_time}

            except Exception as e:
                result["evaluation_scores"][evaluator_name] = 0.0
                result["evaluator_metadata"][evaluator_name] = {"error": str(e), "execution_time_ms": 0.0}

        results.append(result)

    return results


async def evaluate_async(
    contexts: List[EvaluationContext],
    evaluators: List[
        Union[
            Callable[[EvaluationContext], EvaluationMetric], Callable[[EvaluationContext], Awaitable[EvaluationMetric]]
        ]
    ],
) -> List[Dict[str, Any]]:
    """Async version of evaluate() that handles both sync and async evaluators.

    This function is our async equivalent to DeepEval's evaluate() - it takes evaluation
    contexts and runs multiple evaluators on them, collecting scores and metadata.

    Args:
        contexts: List of evaluation contexts to evaluate
        evaluators: List of evaluator functions (sync or async)

    Returns:
        List of evaluation results (one per context)
    """
    results = []

    for context in contexts:
        result = {
            "example_id": context.example_id,
            "input_data": dict(context.input or {}),
            "output": dict(context.output or {}),
            "actual_output": context.actual_output,
            "evaluation_scores": {},
            "evaluator_metadata": {},
            "metadata": {
                "execution_time_ms": context.execution_time_ms,
                "error": context.error,
                **dict(context.metadata or {}),
            },
            "error": context.error,
        }

        # Run each evaluator (handle both sync and async)
        for evaluator in evaluators:
            evaluator_name = evaluator.__name__

            try:
                eval_start_time = time.time()

                if inspect.iscoroutinefunction(evaluator):
                    eval_result = await evaluator(context)
                else:
                    eval_result = evaluator(context)

                eval_time = (time.time() - eval_start_time) * 1000

                # Use safe extraction to handle different return types (float, tuple, EvaluationMetric)
                name, score, metadata = _extract_evaluator_result(eval_result, evaluator_name)
                result["evaluation_scores"][evaluator_name] = score
                result["evaluator_metadata"][evaluator_name] = {**metadata, "execution_time_ms": eval_time}

            except Exception as e:
                result["evaluation_scores"][evaluator_name] = 0.0
                result["evaluator_metadata"][evaluator_name] = {"error": str(e), "execution_time_ms": 0.0}

        results.append(result)

    return results


def run_experiment(
    examples: List[DatasetExample],
    test_function: Callable[[DatasetExample], TestFunctionOutput],
    evaluators: List[Callable[[EvaluationContext], EvaluationMetric]],
    cache_config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """High-level experiment runner that composes generate() and evaluate().

    This is the convenience function that most users will call. It combines
    context generation and evaluation into a single operation.

    Args:
        examples: Dataset examples to test
        test_function: Function to execute on each example
        evaluators: Evaluator functions to run on results
        cache_config: Optional caching configuration

    Returns:
        Experiment results with summary statistics
    """
    # Step 1: Generate contexts (with potential caching)
    contexts = generate(examples, test_function, cache_config)

    # Step 2: Evaluate contexts
    results = evaluate(contexts, evaluators)

    # Step 3: Calculate summary statistics
    total_examples = len(results)
    successful_examples = len([r for r in results if not r["error"]])

    # Calculate average scores per evaluator
    evaluator_averages = {}
    for evaluator in evaluators:
        evaluator_name = evaluator.__name__
        scores = [r["evaluation_scores"].get(evaluator_name, 0.0) for r in results if not r["error"]]
        evaluator_averages[evaluator_name] = sum(scores) / len(scores) if scores else 0.0

    return {
        "results": results,
        "summary": {
            "total_examples": total_examples,
            "successful_examples": successful_examples,
            "failed_examples": total_examples - successful_examples,
            "average_scores": evaluator_averages,
            "total_execution_time_ms": sum(r["metadata"].get("execution_time_ms", 0) for r in results),
        },
    }


def _extract_execution_data(
    result: TestFunctionOutput,
) -> tuple[Union[str, Dict[str, Any], List[Any]], Optional[List[ToolCall]], Optional[AgentTrace]]:
    """Extract output, tool calls, and trace data from test function result.

    This function handles different types of test function outputs and extracts
    the relevant data for creating an EvaluationContext.

    Args:
        result: The result from executing a test function

    Returns:
        Tuple of (actual_output, actual_tool_calls, execution_trace)
    """
    actual_output: Union[str, Dict[str, Any], List[Any]] = ""
    actual_tool_calls = None
    execution_trace = None

    if isinstance(result, str):
        # Simple string output
        actual_output = result

    elif isinstance(result, AgentTrace):
        # Rich agent trace with tool calls
        actual_output = result.final_response
        actual_tool_calls = result.tools_called
        execution_trace = result

    elif hasattr(result, "final_response"):
        # SimpleOutput or other objects with final_response
        actual_output = result.final_response

        # Check if this object also has tool calls
        if hasattr(result, "tools_called"):
            actual_tool_calls = result.tools_called

    elif isinstance(result, dict) or isinstance(result, list):
        actual_output = result

    else:
        # Fallback: convert to string
        actual_output = str(result)

    return actual_output, actual_tool_calls, execution_trace


def _extract_tool_calls_from_capture(capture) -> Optional[List[ToolCall]]:
    """Extract tool calls from captured OpenTelemetry traces.

    This function converts OpenTelemetry spans into ToolCall objects,
    providing a fallback when the test function doesn't directly return tool calls.

    Args:
        capture: TraceCapture object from capture_agent_trace()

    Returns:
        List of ToolCall objects extracted from traces, or None if no tool calls found
    """
    try:
        # Get the latest trace ID (most recent execution)
        trace_id = capture.get_latest_trace_id()
        if not trace_id:
            return None

        # Get spans for this trace
        all_traces = capture.get_captured_traces()
        spans = all_traces.get(trace_id, [])

        if not spans:
            return None

        # Convert spans to AgentTrace to leverage existing extraction logic
        agent_trace = capture.spans_to_agent_trace(spans)

        # Return the extracted tool calls
        return agent_trace.tools_called if agent_trace else None

    except Exception:
        # If extraction fails, return None (no tool calls found)
        return None
