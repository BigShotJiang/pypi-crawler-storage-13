# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

The `/home/coolhand/shared` directory is a comprehensive Python library providing reusable AI development infrastructure. It's designed to be imported by multiple projects and contains:

- **LLM Provider Abstraction**: Unified interface for 10+ AI providers (OpenAI, Anthropic, xAI, Mistral, Cohere, Gemini, etc.)
- **Orchestration Framework**: BaseOrchestrator pattern for building multi-agent workflows with streaming support
- **MCP Server Infrastructure**: Model Context Protocol servers exposing tools, resources, and orchestration capabilities
- **Data Fetching Clients**: Structured clients for ArXiv, Census, GitHub, NASA, News APIs, Semantic Scholar, Wikipedia, YouTube, and more
- **Document Generation**: PDF, DOCX, and Markdown output with professional formatting
- **Configuration Management**: Multi-source config loading (defaults, config files, .env, environment variables)
- **Utilities**: Vision (image analysis), TTS, document parsers, async adapters, time utilities, validation

This library is published as `dr-eamer-ai-shared` and follows the naming convention "Dreamwalker" for orchestration tools.

## Key Architecture

### LLM Providers (`llm_providers/`)

All providers implement `BaseLLMProvider` with standardized methods:
- `complete()`: Generate completions
- `stream_complete()`: Stream completions
- `generate_image()`: Image generation (OpenAI, xAI)
- `analyze_image()`: Vision capabilities (OpenAI, Anthropic, xAI, Gemini)

Use `ProviderFactory` to instantiate providers:
```python
from llm_providers import ProviderFactory

provider = ProviderFactory.create_provider(
    provider_name='xai',  # or 'openai', 'anthropic', etc.
    api_key='your-key',
    model='grok-3'
)

response = provider.complete(messages=[...])
```

**Complexity Router**: `complexity_router.py` implements automatic provider selection based on task complexity (uses cheaper models for simple tasks, expensive models for complex ones).

### Orchestration Framework (`orchestration/`)

Build multi-agent workflows by extending `BaseOrchestrator`:

**Required Methods:**
1. `decompose_task()`: Break task into subtasks
2. `execute_subtask()`: Execute individual subtasks
3. `synthesize_results()`: Combine results into final output

**Built-in Orchestrators:**
- `DreamCascadeOrchestrator`: Hierarchical research (Belter → Drummer → Camina tiers)
- `DreamSwarmOrchestrator`: Multi-domain parallel search
- `SequentialOrchestrator`: Staged execution with per-step handlers
- `ConditionalOrchestrator`: Runtime branch selection
- `IterativeOrchestrator`: Looped refinement until success predicate

**Streaming Support**: All orchestrators emit `StreamEvent` objects for real-time progress tracking via SSE/webhooks.

**Document Generation**: Automatic PDF/DOCX/Markdown generation with configurable templates.

### MCP Server (`mcp/`)

The Model Context Protocol server exposes orchestrator agents and utilities:

**Main Server**: `unified_server.py` - Comprehensive MCP server with tools and resources
**Tools Exposed**:
- `dream_research`: Execute Dream Cascade workflow
- `dream_search`: Execute Dream Swarm workflow
- `dreamwalker_status`: Check workflow status
- `dreamwalker_cancel`: Cancel running workflow
- `dreamwalker_patterns`: List orchestrator patterns
- `dreamwalker_list_tools`: List registered tools
- `dreamwalker_execute_tool`: Execute a registered tool

**Resources Exposed**:
- `orchestrator://{pattern}/info`: Orchestrator metadata
- `orchestrator://{task_id}/status`: Workflow status
- `orchestrator://{task_id}/results`: Workflow results

**Streaming**: SSE endpoint at `/stream/{task_id}` for real-time updates

**Other Servers**:
- `providers_server.py`: LLM provider discovery and invocation
- `data_server.py`: Data fetching client tools
- `cache_server.py`: Redis-based caching
- `utility_server.py`: General utilities
- `web_search_server.py`: Web search integration

**Running MCP Server**:
```bash
cd /home/coolhand/shared/mcp
python unified_server.py
# Serves at http://localhost:5060
```

### Data Fetching (`data_fetching/`)

Structured API clients with consistent error handling:
- `arxiv_client.py`: Academic paper search
- `census_client.py`: US Census data
- `github_client.py`: GitHub repository/user data
- `nasa_client.py`: NASA imagery and data
- `news_client.py`: News articles via NewsAPI
- `semantic_scholar.py`: Academic citations and papers
- `wikipedia_client.py`: Wikipedia content
- `youtube_client.py`: YouTube video metadata
- `fec_client.py`: Federal Election Commission data
- `judiciary_client.py`: Court records
- `mal_client.py`: MyAnimeList data

Use `ClientFactory` for instantiation:
```python
from data_fetching import ClientFactory

client = ClientFactory.create_client('arxiv', api_key='optional')
results = client.search(query='quantum computing', max_results=10)
```

### Configuration (`config.py`)

Multi-source configuration with clear precedence:
1. Default values
2. Custom config file (e.g., `.myapp`)
3. `.env` file
4. Environment variables
5. Command-line arguments

```python
from config import ConfigManager

config = ConfigManager(
    app_name='myapp',
    defaults={'MODEL': 'grok-3', 'PROVIDER': 'xai'}
)

model = config.get('MODEL')
api_key = config.get_api_key('xai')
available = config.list_available_providers()
```

### Web Interface (`web/dreamwalker/`)

Flask control panel for MCP orchestrator:
- Dashboard for health, tools, resources
- Launch workflows with custom parameters
- SSE proxy for browser-based streaming
- REST API for orchestration management

**Running Dreamwalker**:
```bash
export MCP_BASE_URL=http://localhost:5060
python -m web.dreamwalker.app
# Serves at http://localhost:5000
```

## Common Development Tasks

### Running Tests

```bash
# Run all tests
pytest

# Run specific test file
pytest tests/test_orchestrators.py

# Run with verbose output
pytest -v

# Run with coverage
pytest --cov=. --cov-report=html
```

### Building and Installing

```bash
# Install in editable mode (for development)
pip install -e .

# Install with all optional dependencies
pip install -e .[all]

# Install specific provider dependencies
pip install -e .[anthropic,openai,xai]

# Build distribution packages
python setup.py sdist bdist_wheel
```

### Using Shared Components in Other Projects

```python
# In another project, reference shared library
import sys
sys.path.insert(0, '/home/coolhand/shared')

# Or install as package
pip install -e /home/coolhand/shared

# Then import normally
from llm_providers import ProviderFactory
from orchestration import DreamCascadeOrchestrator
from config import ConfigManager
from data_fetching import ClientFactory
```

### Creating Custom Orchestrators

1. Extend `BaseOrchestrator`
2. Implement 3 required methods: `decompose_task()`, `execute_subtask()`, `synthesize_results()`
3. Configure with `OrchestratorConfig` or create custom config class
4. Use built-in helpers: `_execute_agents_parallel()`, `_emit_event()`, `_generate_documents()`

See `orchestration/templates/orchestrator_template.py` for boilerplate.

Reference `ORCHESTRATOR_GUIDE.md` for detailed implementation guide.

## Important Conventions

### Naming Conventions
- **"Dreamwalker"** is the public-facing name for orchestration tools and MCP servers
- **"Dream Cascade"** refers to hierarchical research orchestrators (formerly "Beltalowda")
- **"Dream Swarm"** refers to multi-domain search orchestrators
- Internal code may use legacy names (`BeltalowdaOrchestrator`, `SwarmOrchestrator`) but these are aliased to new names

### Code Style
- All code credits Luke Steuber as author
- Use first person ("I") in documentation, not "we"
- No "Created with Claude" or similar AI attribution comments
- Type hints required for public APIs
- Docstrings required for all public functions/classes

### API Keys and Secrets
- Store in `/home/coolhand/API_KEYS.md` (referenced by global CLAUDE.md)
- Never commit API keys to version control
- Use `ConfigManager` to load keys from environment/config files
- Keys are masked when displayed via `config.as_dict(mask_secrets=True)`

### Port Allocation
- MCP server: `5060`
- Dreamwalker UI: `5080` (when managed by service_manager)
- Development testing: `5010-5019`, `5050-5059`
- Caddy reverse proxy handles `/5010-5019` → `localhost:5010-5019`

### File Organization
- Shared components go in `/home/coolhand/shared`
- Tests go in `tests/` directory
- MCP servers in `mcp/` subdirectory
- Documentation (guides, benchmarks) in root or relevant subdirectory

## Dependencies

### Core Dependencies
- `python-dotenv>=1.0.0`: Environment variable loading
- `requests>=2.32.5`: HTTP client (security patched)
- `pillow>=11.0.0`: Image processing
- `aiohttp>=3.12.14`: Async HTTP operations

### Provider-Specific (Optional)
Install only what you need via extras:
- `anthropic`: Claude models
- `openai`: GPT models, DALL-E, Whisper
- `xai`: Grok models (uses OpenAI-compatible API)
- `mistral`: Mistral models
- `cohere`: Cohere models
- `gemini`: Google Gemini models
- `huggingface`: HuggingFace models

### MCP Server Dependencies
- `flask>=3.0.0`, `flask-cors>=4.0.0`: Web framework
- `gunicorn>=21.0.0`: Production WSGI server
- `gevent>=24.0.0`: Async worker support (greenlet-based)

### Document Generation (Optional)
- `reportlab>=4.0.0`: PDF generation
- `python-docx>=1.0.0`: DOCX generation

## Integration with Main System

This shared library is part of a larger ecosystem:
- **Server**: dr.eamer.dev, d.reamwalker.com, d.reamwalk.com
- **Web Root**: `/home/coolhand/html`
- **Service Manager**: `/home/coolhand/service_manager.py` manages services
- **Caddy Config**: `/etc/caddy/Caddyfile` for reverse proxy
- **Projects Directory**: Other projects import from this shared library

When making changes that affect other projects, test integration points:
1. Verify imports work from external projects
2. Check MCP server endpoints are accessible
3. Ensure Dreamwalker UI connects to MCP server correctly
4. Validate service_manager can start/stop services

## Troubleshooting

### Import Errors
If imports fail, ensure:
1. `sys.path.insert(0, '/home/coolhand/shared')` is called before imports
2. Or install package: `pip install -e /home/coolhand/shared`
3. Check for circular imports in module structure

### API Provider Issues
If provider calls fail:
1. Verify API key is set: `config.has_api_key('provider_name')`
2. Check provider is available: `config.list_available_providers()`
3. Install provider extras: `pip install -e .[provider_name]`
4. Check `/home/coolhand/API_KEYS.md` for key configuration

### MCP Server Not Starting
1. Check port 5060 is available: `sudo lsof -i :5060`
2. Verify dependencies installed: `pip install -r mcp/requirements.txt`
3. Check logs for import errors or missing API keys
4. Ensure `/home/coolhand/shared` is in PYTHONPATH

### Orchestrator Execution Failures
1. Verify LLM provider is configured and has API key
2. Check task complexity matches model capabilities
3. Review streaming events for error details
4. Enable debug logging: `logging.basicConfig(level=logging.DEBUG)`

## Testing Philosophy

- Write tests for public APIs and orchestrator workflows
- Mock external API calls (don't hit real APIs in tests)
- Test configuration loading from multiple sources
- Validate streaming event emission
- Test error handling and graceful degradation
- Use pytest fixtures for common setup

## Documentation

Key documentation files in this repository:
- `ORCHESTRATOR_GUIDE.md`: Building custom orchestrators
- `ORCHESTRATOR_SELECTION_GUIDE.md`: Choosing the right pattern
- `ORCHESTRATOR_BENCHMARKS.md`: Performance characteristics
- Sample workflows in `orchestration/templates/`

Web-based documentation:
- Generated docs at `https://dr.eamer.dev/shared/`
- Tool catalog and API reference in Dreamwalker UI

## Version Control

This library is part of a monorepo at `https://github.com/lukeslp/kernel`

When committing changes:
1. Add and commit every 1.5 hours during active development
2. Write clear commit messages describing "why" not just "what"
3. Use format: `type(scope): message` (e.g., `feat(orchestration): add conditional orchestrator`)
4. Test changes before committing: `pytest`
5. Update CLAUDE.md when making architectural changes
