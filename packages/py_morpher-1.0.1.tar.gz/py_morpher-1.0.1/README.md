py-morpher


Одна строчка — любой формат данных

from morph import morph

df       = morph(data, to="pandas")     # → pandas.DataFrame
users    = morph(data, to=User)         # → List[User] (Pydantic)
dicts    = morph(users, to=dict)        # → list[dict] / dict

Больше никаких ручных циклов, model_dump(), DataFrame(data), if-ов и «а вдруг список, а вдруг словарь».
Одна функция — всё.


Установка

pip install py-morpher


10 секунд магии

from morph import morph
from pydantic import BaseModel

# Обычные данные (из API, JSON, БД…)
data = [
    {"name": "Аня", "age": 17, "city": "Москва"},
    {"name": "Дима", "age": 19, "city": "Питер"},
]

# 1. В таблицу
df = morph(data, to="pandas")
print(df)
   name  age   city
0   Аня   17  Москва
1   Дима   19   Питер

# 2. В умные объекты (с валидацией)
class User(BaseModel):
    name: str
    age: int
    city: str

users = morph(data, to=User)
print(users[0].name)  # Аня

# 3. Обратно в словари (для JSON/API)
clean_dicts = morph(users, to=dict)
 → [{'name': 'Аня', 'age': 17, 'city': 'Москва'}, ...]

# 4. Кривые данные? Сама поймает
bad = {"name": "Вася", "age": "age": "не число"}
try:
    morph(bad, to=User)
except Exception as e:
    print("Ошибка поймана →", e)


Поддерживаемые преобразования (пока)

Откуда → Куда,Работает?,Команда
list[dict] → DataFrame,Yes,"to=""pandas"" или to=""df"""
dict → DataFrame,Yes,"to=""pandas"""
list[dict] → List[Model],Yes,`to=MyModel
Model / List[Model] → dict,Yes,"to=dict или to=""json"""
DataFrame → list[dict],Yes,to=dict
любой примитив → dict,Yes,"to=dict (обернёт в {""data"": value})"


# Почему это круто

Ноль ручного маппинга
Автоматическая валидация через Pydantic
Минимум кода — максимум читаемости
Идеально для FastAPI, скриптов аналитики, парсеров, ботов


Автор: busyaaa_1
GitHub: https://github.com/busyaaa-1/py-morph/
PyPI: https://pypi.org/project/py-morpher/


Заливай, пользуйся, кайфуй.
Твои данные теперь слушаются с одного слова.

# ⭐ Если понравилось — звёздочка на GitHub будет самой приятной благодарностью