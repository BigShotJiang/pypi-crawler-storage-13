"""
Tests for TrGEN Configuration Management

Tests the configuration import/export functionality including:
- Configuration creation and serialization
- File I/O operations  
- Client integration
- Error handling
"""

import unittest
import tempfile
import os
import json
from datetime import datetime
from unittest.mock import Mock, patch

# Import the modules to test
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from trgenpy import (
    TrgenClient,
    TrgenConfiguration,
    TrgenConfigurationManager,
    TriggerPortConfig,
    PortProgrammingState,
    TrgenPin
)


class TestTrgenConfiguration(unittest.TestCase):
    """Test the TrgenConfiguration class and related components."""
    
    def test_configuration_creation(self):
        """Test basic configuration creation."""
        config = TrgenConfiguration()
        
        self.assertIsNotNone(config.metadata)
        self.assertIsNotNone(config.defaults)
        self.assertIsNotNone(config.network)
        self.assertIsInstance(config.trigger_ports, dict)
        self.assertEqual(config.defaults.default_trigger_duration_us, 20)
    
    def test_trigger_port_config(self):
        """Test TriggerPortConfig functionality."""
        port_config = TriggerPortConfig(32)
        
        self.assertEqual(port_config.memory_length, 32)
        self.assertEqual(len(port_config.memory_instructions), 32)
        self.assertEqual(port_config.last_instruction_index, -1)
        self.assertEqual(port_config.programming_state, PortProgrammingState.NOT_PROGRAMMED)
        self.assertFalse(port_config.has_programmed_instructions())
        
        # Add some instructions
        port_config.memory_instructions[0] = 0x12345678
        port_config.memory_instructions[1] = 0x87654321
        port_config._find_last_instruction_index()
        
        self.assertEqual(port_config.last_instruction_index, 1)
        self.assertTrue(port_config.has_programmed_instructions())
        self.assertIn("0x12345678", port_config.get_instructions_string())
    
    def test_configuration_serialization(self):
        """Test configuration to/from dictionary conversion."""
        config = TrgenConfiguration()
        config.metadata.project_name = "Test Project"
        config.metadata.author = "Test Author"
        
        # Add a trigger port
        port_config = TriggerPortConfig(32)
        port_config.id = 0
        port_config.name = "Test Port"
        port_config.type = "NeuroScan"
        config.trigger_ports["NS0"] = port_config
        
        # Convert to dict and back
        config_dict = config.to_dict()
        restored_config = TrgenConfiguration.from_dict(config_dict)
        
        self.assertEqual(restored_config.metadata.project_name, "Test Project")
        self.assertEqual(restored_config.metadata.author, "Test Author")
        self.assertIn("NS0", restored_config.trigger_ports)
        self.assertEqual(restored_config.trigger_ports["NS0"].name, "Test Port")


class TestTrgenConfigurationManager(unittest.TestCase):
    """Test the TrgenConfigurationManager class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.client = Mock(spec=TrgenClient)
        self.client.ip = "192.168.123.1"
        self.client.port = 4242
        self.client.timeout = 2.0
        self.client.default_trigger_duration_us = 20
        self.client.create_trgen = Mock()
        self.client.set_trgen_memory = Mock()
        self.client.set_default_duration = Mock()
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def test_ensure_trgen_extension(self):
        """Test file extension handling."""
        # Test adding extension
        path1 = TrgenConfigurationManager._ensure_trgen_extension("test")
        self.assertEqual(path1, "test.trgen")
        
        # Test preserving existing extension
        path2 = TrgenConfigurationManager._ensure_trgen_extension("test.trgen")
        self.assertEqual(path2, "test.trgen")
        
        # Test case insensitive
        path3 = TrgenConfigurationManager._ensure_trgen_extension("test.TRGEN")
        self.assertEqual(path3, "test.TRGEN")
    
    def test_export_configuration(self):
        """Test configuration export."""
        file_path = os.path.join(self.temp_dir, "test_config")
        
        exported_path = TrgenConfigurationManager.export_configuration(
            client=self.client,
            file_path=file_path,
            project_name="Test Export",
            description="Test description",
            author="Test Author"
        )
        
        self.assertTrue(exported_path.endswith(".trgen"))
        self.assertTrue(os.path.exists(exported_path))
        
        # Check file content
        with open(exported_path, 'r') as f:
            content = f.read()
        
        self.assertIn("# TrGEN Configuration File", content)
        self.assertIn("Test Export", content)
        
        # Check JSON content
        json_start = content.find('{')
        json_content = content[json_start:]
        config_dict = json.loads(json_content)
        
        self.assertEqual(config_dict["metadata"]["project_name"], "Test Export")
        self.assertEqual(config_dict["metadata"]["author"], "Test Author")
    
    def test_import_configuration(self):
        """Test configuration import."""
        # First export a configuration
        file_path = os.path.join(self.temp_dir, "test_import.trgen")
        
        TrgenConfigurationManager.export_configuration(
            client=self.client,
            file_path=file_path,
            project_name="Import Test",
            description="Test import functionality"
        )
        
        # Now import it into a new client
        new_client = Mock(spec=TrgenClient)
        new_client.create_trgen = Mock()
        new_client.set_trgen_memory = Mock()
        new_client.set_default_duration = Mock()
        
        imported_config = TrgenConfigurationManager.import_configuration(
            client=new_client,
            file_path=file_path
        )
        
        self.assertEqual(imported_config.metadata.project_name, "Import Test")
        new_client.set_default_duration.assert_called_once()
    
    def test_load_configuration(self):
        """Test loading configuration without applying to client."""
        # Create and save a configuration
        config = TrgenConfiguration()
        config.metadata.project_name = "Load Test"
        config.metadata.author = "Load Author"
        
        file_path = os.path.join(self.temp_dir, "load_test.trgen")
        TrgenConfigurationManager.save_configuration(config, file_path)
        
        # Load it back
        loaded_config = TrgenConfigurationManager.load_configuration(file_path)
        
        self.assertEqual(loaded_config.metadata.project_name, "Load Test")
        self.assertEqual(loaded_config.metadata.author, "Load Author")
    
    def test_list_configuration_files(self):
        """Test listing configuration files in a directory."""
        # Create some test files
        test_files = ["config1.trgen", "config2.trgen", "not_config.txt", "config3.TRGEN"]
        
        for filename in test_files:
            file_path = os.path.join(self.temp_dir, filename)
            with open(file_path, 'w') as f:
                f.write("test content")
        
        # List .trgen files
        trgen_files = TrgenConfigurationManager.list_configuration_files(self.temp_dir)
        
        # Should find 3 .trgen files (case insensitive)
        self.assertEqual(len(trgen_files), 3)
        
        # Check that only .trgen files are included
        for file_path in trgen_files:
            self.assertTrue(os.path.basename(file_path).lower().endswith('.trgen'))
    
    def test_error_handling(self):
        """Test error handling for various scenarios."""
        # Test with None client
        with self.assertRaises(ValueError):
            TrgenConfigurationManager.export_configuration(None, "test.trgen")
        
        # Test with non-existent file
        with self.assertRaises(FileNotFoundError):
            TrgenConfigurationManager.load_configuration("non_existent.trgen")
        
        # Test with wrong extension
        wrong_ext_file = os.path.join(self.temp_dir, "wrong.txt")
        with open(wrong_ext_file, 'w') as f:
            f.write("test")
        
        with self.assertRaises(ValueError):
            TrgenConfigurationManager.load_configuration(wrong_ext_file)

    def test_import_configuration_with_hardware_programming(self):
        """Test configuration import with automatic hardware programming."""
        # First export a configuration
        file_path = os.path.join(self.temp_dir, "test_programming.trgen")
        
        TrgenConfigurationManager.export_configuration(
            client=self.client,
            file_path=file_path,
            project_name="Programming Test",
            description="Test hardware programming"
        )
        
        # Create a new mock client for import
        import_client = Mock(spec=TrgenClient)
        import_client.set_trgen_memory = Mock()
        import_client.set_default_duration = Mock()
        
        # Create a function that returns different mock ports based on ID
        def create_mock_port(port_id):
            mock_port = Mock()
            mock_port.id = port_id
            mock_port.memory = [0] * 32  # Mock memory array with 32 elements
            mock_port.set_instruction = Mock()
            return mock_port
        
        import_client.create_trgen = Mock(side_effect=create_mock_port)
        
        # Import the configuration
        imported_config = TrgenConfigurationManager.import_configuration(
            import_client,
            file_path
        )
        
        # Verify that ports were created and programmed
        self.assertTrue(import_client.create_trgen.called)
        self.assertTrue(import_client.set_trgen_memory.called)
        
        # Verify that create_trgen was called for each enabled port
        # There should be 26 ports total (8 NS + 8 SA + 2 TMS + 8 GPIO)
        self.assertEqual(import_client.create_trgen.call_count, 26)
        
        # Verify that set_trgen_memory was called for each enabled port
        self.assertEqual(import_client.set_trgen_memory.call_count, 26)
    
    def test_apply_port_configurations_selective(self):
        """Test selective port configuration application."""
        # Create a configuration with multiple ports
        config = TrgenConfiguration()
        
        # Add a few test ports
        ns0_config = TriggerPortConfig(32)
        ns0_config.id = 0
        ns0_config.name = "NeuroScan 0"
        ns0_config.type = "NeuroScan"
        ns0_config.enabled = True
        config.trigger_ports["NS0"] = ns0_config
        
        sa1_config = TriggerPortConfig(32)
        sa1_config.id = 9
        sa1_config.name = "Synamps 1"
        sa1_config.type = "Synamps"
        sa1_config.enabled = True
        config.trigger_ports["SA1"] = sa1_config
        
        gpio2_config = TriggerPortConfig(32)
        gpio2_config.id = 20
        gpio2_config.name = "GPIO 2"
        gpio2_config.type = "GPIO"
        gpio2_config.enabled = False  # This one is disabled
        config.trigger_ports["GPIO2"] = gpio2_config
        
        # Create mock client
        mock_client = Mock(spec=TrgenClient)
        
        def create_mock_port(port_id):
            mock_port = Mock()
            mock_port.id = port_id
            mock_port.memory = [0] * 32
            mock_port.set_instruction = Mock()
            return mock_port
        
        mock_client.create_trgen = Mock(side_effect=create_mock_port)
        mock_client.set_trgen_memory = Mock()
        
        # Test selective application - only NS0 and SA1
        ports_programmed = TrgenConfigurationManager.apply_port_configurations_selective(
            mock_client, 
            config, 
            port_filters=["NS0", "SA1"]
        )
        
        # Should program 2 ports (NS0 and SA1, but not GPIO2 because it's in filter but disabled)
        self.assertEqual(ports_programmed, 2)
        self.assertEqual(mock_client.create_trgen.call_count, 2)
        self.assertEqual(mock_client.set_trgen_memory.call_count, 2)
        
        # Verify correct port IDs were called
        create_calls = [call.args[0] for call in mock_client.create_trgen.call_args_list]
        self.assertIn(0, create_calls)  # NS0
        self.assertIn(9, create_calls)  # SA1

    def test_selective_port_programming(self):
        """Test selective port configuration and programming."""
        # Create a test configuration
        config = TrgenConfiguration()
        
        # Add multiple ports
        for i in range(4):
            port_config = TriggerPortConfig(32)
            port_config.id = i
            port_config.name = f"Test Port {i}"
            port_config.enabled = True
            config.trigger_ports[f"NS{i}"] = port_config
        
        # Mock client for selective programming
        selective_client = Mock(spec=TrgenClient)
        selective_client.set_trgen_memory = Mock()
        
        def create_mock_port(port_id):
            mock_port = Mock()
            mock_port.id = port_id
            mock_port.memory = [0] * 32
            mock_port.set_instruction = Mock()
            return mock_port
        
        selective_client.create_trgen = Mock(side_effect=create_mock_port)
        
        # Test selective programming - only program NS0 and NS2
        selected_ports = ['NS0', 'NS2']
        ports_programmed = TrgenConfigurationManager.apply_port_configurations_selective(
            selective_client,
            config,
            selected_ports
        )
        
        # Should have programmed exactly 2 ports
        self.assertEqual(ports_programmed, 2)
        self.assertEqual(selective_client.set_trgen_memory.call_count, 2)

    def test_configuration_with_custom_instructions(self):
        """Test configuration with custom programmed instructions."""
        # Create configuration with custom instructions
        config = TrgenConfiguration()
        
        port_config = TriggerPortConfig(32)
        port_config.id = 0
        port_config.enabled = True
        port_config.memory_instructions = [0x12345678, 0x9ABCDEF0, 0x00000000] + [0] * 29
        port_config.last_instruction_index = 1
        port_config.programming_state = "Programmed"
        
        config.trigger_ports["NS0"] = port_config
        
        # Mock client
        client = Mock(spec=TrgenClient)
        client.set_trgen_memory = Mock()
        
        def create_mock_port(port_id):
            mock_port = Mock()
            mock_port.id = port_id
            mock_port.memory = [0] * 32
            mock_port.set_instruction = Mock()
            return mock_port
        
        client.create_trgen = Mock(side_effect=create_mock_port)
        
        # Apply configuration
        TrgenConfigurationManager._apply_port_configurations_to_client(client, config)
        
        # Verify programming occurred
        self.assertTrue(client.set_trgen_memory.called)
        self.assertTrue(port_config.has_programmed_instructions())
        
        instructions_string = port_config.get_instructions_string()
        self.assertIn("0x12345678", instructions_string)
        self.assertIn("0x9ABCDEF0", instructions_string)

    def test_disabled_port_not_programmed(self):
        """Test that disabled ports are not programmed to hardware."""
        # Create configuration with disabled port
        config = TrgenConfiguration()
        
        port_config = TriggerPortConfig(32)
        port_config.id = 0
        port_config.enabled = False  # Disabled port
        port_config.memory_instructions = [0x12345678] + [0] * 31
        port_config.last_instruction_index = 0
        
        config.trigger_ports["NS0"] = port_config
        
        # Mock client
        client = Mock(spec=TrgenClient)
        client.create_trgen = Mock()
        client.set_trgen_memory = Mock()
        
        mock_port = Mock()
        client.create_trgen.return_value = mock_port
        
        # Apply configuration
        TrgenConfigurationManager._apply_port_configurations_to_client(client, config)
        
        # Verify that create_trgen was called but set_trgen_memory was not
        self.assertTrue(client.create_trgen.called)
        self.assertFalse(client.set_trgen_memory.called)

    def test_error_handling_during_programming(self):
        """Test error handling when programming fails."""
        config = TrgenConfiguration()
        
        port_config = TriggerPortConfig(32)
        port_config.id = 0
        port_config.enabled = True
        config.trigger_ports["NS0"] = port_config
        
        # Mock client that raises exception during programming
        client = Mock(spec=TrgenClient)
        client.create_trgen = Mock()
        client.set_trgen_memory = Mock(side_effect=Exception("Programming failed"))
        
        mock_port = Mock()
        client.create_trgen.return_value = mock_port
        
        # Should not raise exception, just log error
        with patch('builtins.print') as mock_print:
            TrgenConfigurationManager._apply_port_configurations_to_client(client, config)
            
            # Check that error was logged
            error_logged = any("Error applying configuration" in str(call) for call in mock_print.call_args_list)
            self.assertTrue(error_logged)


class TestTrgenClientIntegration(unittest.TestCase):
    """Test integration with TrgenClient class."""
    
    def test_client_default_duration(self):
        """Test default duration functionality in TrgenClient."""
        # Test default value
        client1 = TrgenClient()
        self.assertEqual(client1.get_default_duration(), 20)
        
        # Test custom default value
        client2 = TrgenClient(default_trigger_duration_us=50)
        self.assertEqual(client2.get_default_duration(), 50)
        
        # Test setting default duration
        client1.set_default_duration(75)
        self.assertEqual(client1.get_default_duration(), 75)
        
        # Test invalid duration
        with self.assertRaises(ValueError):
            client1.set_default_duration(0)
        
        with self.assertRaises(ValueError):
            client1.set_default_duration(-10)


if __name__ == '__main__':
    unittest.main()