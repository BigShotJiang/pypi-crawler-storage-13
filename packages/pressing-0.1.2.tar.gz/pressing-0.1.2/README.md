# pressing

`pressing` is a simple Python macro library that simulates key presses, releases, and taps using **pynput**.

Perfect for automation scripts, macros, key simulation, and lightweight botting.

---

## 🔧 Installation

```bash
pip install pressing
