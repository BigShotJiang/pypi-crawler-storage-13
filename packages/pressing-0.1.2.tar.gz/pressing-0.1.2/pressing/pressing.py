from pynput.keyboard import Key, Controller
import time
import pyautogui

typewait = 0.1

kb = Controller()

SPECIAL_KEYS = {
    "alt": Key.alt,
    "lalt": Key.alt_l,
    "ralt": Key.alt_r,
    "ctrl": Key.ctrl,
    "lctrl": Key.ctrl_l,
    "rctrl": Key.ctrl_r,
    "shift": Key.shift,
    "lshift": Key.shift_l,
    "rshift": Key.shift_r,
    "cmd": Key.cmd,
    "win": Key.cmd,
    "meta": Key.cmd,
    "super": Key.cmd,

    "tab": Key.tab,
    "enter": Key.enter,
    "esc": Key.esc,
    "escape": Key.esc,
    "backspace": Key.backspace,
    "delete": Key.delete,
    "del": Key.delete,
    "insert": Key.insert,
    "home": Key.home,
    "end": Key.end,
    "pageup": Key.page_up,
    "pagedown": Key.page_down,
    "up": Key.up,
    "down": Key.down,
    "left": Key.left,
    "right": Key.right,

    " ": Key.space,
    "space": Key.space,

    **{f"f{i}": getattr(Key, f"f{i}") for i in range(1, 25)},

    "capslock": Key.caps_lock,
    "numlock": Key.num_lock,
    "scrolllock": Key.scroll_lock,
    "pause": Key.pause,
    "printscreen": Key.print_screen,
}

def get_key_obj(k):
    k_lower = str(k).lower()
    if k_lower in SPECIAL_KEYS:
        return SPECIAL_KEYS[k_lower]
    return k

def run_macro(cmd_list):
    for cmd in cmd_list:
        cmd = str(cmd)
        time.sleep(typewait)
        
        if cmd.endswith("+"):
            keyname = cmd[:-1]
            kb.press(get_key_obj(keyname))
            continue

        if cmd.endswith("-"):
            keyname = cmd[:-1]
            kb.release(get_key_obj(keyname))
            continue

        if len(cmd) == 1 or cmd.lower() in SPECIAL_KEYS:
            key = get_key_obj(cmd)
            kb.press(key)
            kb.release(key)
            continue

        for ch in cmd:
            key = get_key_obj(ch)
            kb.press(key)
            kb.release(key)

def creator():
    print("Pressing was created by Mongoose")

def press(character):
    """Hold a key or list of keys."""
    if isinstance(character, list):
        commands = [f"{c}+" for c in character]
    else:
        commands = [f"{character}+"]
    run_macro(commands)

def release(character):
    """Release a key or list of keys."""
    if isinstance(character, list):
        commands = [f"{c}-" for c in character]
    else:
        commands = [f"{character}-"]
    run_macro(commands)

def click(character):
    """Tap a key or list of keys (press + release)."""
    if isinstance(character, list):
        commands = [f"{c}" for c in character]
    else:
        commands = [f"{character}"]
    run_macro(commands)

def getpixel(x, y):
    """Utility function for pixel reading."""
    return pyautogui.screenshot().getpixel((x, y))

