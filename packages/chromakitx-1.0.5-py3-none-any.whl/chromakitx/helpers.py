# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from chromakitx.colors import (CustomColor, TextStyle)
from chromakitx.color import Color
from chromakitx.constants import ANSI_PATTERN
from chromakitx.interfaces import ColorFormattable
from chromakitx.models import RGB

def interpolate_color(start: RGB, end: RGB, steps: int) -> list[RGB]:
    if steps < 2:
        return [start]

    colors: list[RGB] = []

    for i in range(steps):
        ratio: float = i / (steps - 1)

        r: int = int(start.r + (end.r - start.r) * ratio)
        g: int = int(start.g + (end.g - start.g) * ratio)
        b: int = int(start.b + (end.b - start.b) * ratio)

        colors.append(RGB(r, g, b))

    return colors

def generate_palette(base_color: RGB, count: int = 5) -> list[RGB]:
    if count < 1:
        return []

    if count == 1:
        return [base_color]

    lighter: RGB = RGB(min(255, base_color.r + 50), min(255, base_color.g + 50), min(255, base_color.b + 50))
    darker:  RGB = RGB(max(0, base_color.r - 50), max(0, base_color.g - 50), max(0, base_color.b - 50))

    return interpolate_color(darker, lighter, count)

def colorize(text: str, color: ColorFormattable, background: ColorFormattable | None = None) -> str:
    result: str = Color(color) + text

    if background:
        result = Color(background, is_background=True) + result

    result += Color(TextStyle.RESET)
    return result

def strip_ansi(text: str) -> str:
    return ANSI_PATTERN.sub(repl='', string=text)

def gradient(text: str, start_color: RGB, end_color: RGB) -> str:
    if not text:
        return text

    length: int = len(text)

    if length == 1:
        return colorize(text, CustomColor(start_color))

    result: list[str] = []

    for (i, char) in enumerate(text):
        ratio: float = i / (length - 1)

        r: int = int(start_color.r + (end_color.r - start_color.r) * ratio)
        g: int = int(start_color.g + (end_color.g - start_color.g) * ratio)
        b: int = int(start_color.b + (end_color.b - start_color.b) * ratio)

        color: CustomColor = CustomColor(RGB(r, g, b))
        result.append(colorize(char, color))

    return ''.join(result)
