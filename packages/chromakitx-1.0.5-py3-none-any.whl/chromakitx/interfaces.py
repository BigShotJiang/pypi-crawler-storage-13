# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from typing import (Protocol, runtime_checkable, TypeVar, Type)
from enum import Enum

from chromakitx.exceptions import InvalidColorError

@runtime_checkable
class ColorFormattable(Protocol):
    def format(self, is_background: bool = False) -> str:
        ...

T: TypeVar = TypeVar("T", bound="EnumColor")

class EnumColor(Enum):
    @classmethod
    def from_name(cls: Type[T], name: str) -> T:
        normalized: str = name.replace('_', '').replace('-', '').replace(' ', '').lower()

        for member in cls:
            if member.name.lower().replace('_', '') == normalized:
                return member

        raise InvalidColorError(color_value=name, message="Unknown color name '" + name + "' in " + cls.__name__)

    def format(self, is_background: bool = False) -> str:
        raise NotImplementedError(self.__class__.__name__ + ".format() must be implemented in subclasses")
