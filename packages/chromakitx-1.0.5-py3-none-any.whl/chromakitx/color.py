# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from chromakitx.exceptions import InvalidColorError
from chromakitx.interfaces import ColorFormattable

class Color:
    __slots__: tuple[str] = ('_formatted',)

    def __init__(self, color: ColorFormattable, is_background: bool = False) -> None:
        if not isinstance(color, ColorFormattable):
            raise InvalidColorError(color_value=color, message="Color must implement ColorFormattable, got " + type(color).__name__)

        self._formatted: str = color.format(is_background)

    @property
    def formatted(self) -> str:
        return self._formatted

    def __str__(self) -> str:
        return self._formatted

    def __repr__(self) -> str:
        return "Color('" + self._formatted + "')"

    def __add__(self, other: object) -> str:
        match other:
            case str():
                return self._formatted + other

            case Color():
                return self._formatted + other._formatted

            case _:
                return NotImplemented

    def __radd__(self, other: object) -> str:
        match other:
            case str():
                return other + self._formatted

            case Color():
                return other._formatted + self._formatted

            case _:
                return NotImplemented

    def __eq__(self, other: object) -> bool:
        return NotImplemented if not isinstance(other, Color) else self._formatted == other._formatted

    def __hash__(self) -> int:
        return hash(self._formatted)
