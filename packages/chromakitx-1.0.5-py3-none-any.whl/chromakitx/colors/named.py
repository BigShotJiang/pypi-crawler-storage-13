# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from chromakitx.colors import (AnsiColor, CssColor, TextStyle, XtermColor)
from chromakitx.exceptions import InvalidColorError
from chromakitx.interfaces import ColorFormattable

class NamedColor(ColorFormattable):
    __slots__: tuple[str] = ('_enum',)

    def __init__(self, name: str) -> None:
        found: ColorFormattable | None = None

        for cls in {AnsiColor, CssColor, TextStyle, XtermColor}:
            try:
                found = cls.from_name(name)
                break
            except InvalidColorError:
                continue

        if not found:
            raise InvalidColorError(color_value=name, message="Unknown named color '" + name + "'")

        self._enum: ColorFormattable = found

    def format(self, is_background: bool = False) -> str:
        return self._enum.format(is_background)
