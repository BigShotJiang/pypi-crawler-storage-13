# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from types import UnionType

from chromakitx.constants import (ANSI_RGB_ESCAPE, ANSI_RGB_BG_ESCAPE)
from chromakitx.exceptions import InvalidColorError
from chromakitx.models import (RGB, HSL, HEX, HSV)
from chromakitx.utils import (hex_to_rgb, hsl_to_rgb, hsv_to_rgb)
from chromakitx.interfaces import ColorFormattable

_ModelType: UnionType = RGB | HSL | HEX | HSV

class CustomColor(ColorFormattable):
    __slots__: tuple[str] = ('_rgb',)

    def __init__(self, color: _ModelType) -> None:
        match color:
            case RGB():
                self._rgb: RGB = color

            case HEX():
                self._rgb: RGB = hex_to_rgb(color)

            case HSL():
                self._rgb: RGB = hsl_to_rgb(color)

            case HSV():
                self._rgb: RGB = hsv_to_rgb(color)

            case _:
                raise InvalidColorError(color_value=color, message="CustomColor requires RGB, HSL, HEX or HSV, got " + type(color).__name__)

    def format(self, is_background: bool = False) -> str:
        (r, g, b) = self._rgb
        return (ANSI_RGB_ESCAPE if not is_background else ANSI_RGB_BG_ESCAPE) % (r, g, b)
