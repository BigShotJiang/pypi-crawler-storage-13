# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from re import (Pattern, compile)

ANSI_ESCAPE: str = "\x1B[%im"
ANSI_RGB_ESCAPE: str = "\x1B[38;2;%i;%i;%im"
ANSI_RGB_BG_ESCAPE: str = "\x1B[48;2;%i;%i;%im"

MIN_RGB_VALUE: int = 0
MAX_RGB_VALUE: int = 255
MIN_HSL_VALUE: float = 0.0
MAX_HSL_VALUE: float = 1.0
MIN_HSV_VALUE: float = 0.0
MAX_HSV_VALUE: float = 100.0
VALID_HEX_LENGTHS: tuple[int, int] = (3, 6)
VALID_HEX_CHARS: str = "0123456789ABCDEF"
RGB_MAX_VALUE: int = 255

HEX_PATTERN:  Pattern[str] = compile(pattern=r'^[0-9A-F]{6}$')
ANSI_PATTERN: Pattern[str] = compile(pattern=r'\x1B(?:\[[0-9;?]*[A-Za-z]|\][^\x07]*\x07|[PX^_].*?\x1b\\)')
