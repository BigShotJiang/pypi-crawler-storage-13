"""Test `quaxed`."""
