"""Test `quaxed.operator`."""
