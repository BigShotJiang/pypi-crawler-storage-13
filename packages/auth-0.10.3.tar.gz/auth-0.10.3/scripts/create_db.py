
import sqlite3

from sqlalchemy.exc import OperationalError
from sqlalchemy import text

from auth.database import engine
from auth.config import get_settings, DatabaseType
from auth.models.sql import Base


import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_tables():
    # ... (rest of the function)
    try:
        Base.metadata.create_all(bind=engine, checkfirst=True)
        logger.info("Tables created successfully.")
    except (OperationalError, sqlite3.OperationalError) as e:
        # ... (rest of the except block)
        logger.info("Tables already exist.")

if __name__ == "__main__":
    create_tables()
