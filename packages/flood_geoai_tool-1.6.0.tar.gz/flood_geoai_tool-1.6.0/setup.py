from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="flood-geoai-tool",
    version="1.6.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A GeoAI tool for flood risk assessment using satellite imagery and Hugging Face models",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/flood-geoai-tool",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9", 
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: GIS",
        "Topic :: Scientific/Engineering :: Image Recognition",
    ],
    python_requires=">=3.8",
    install_requires=[
        "rasterio>=1.2.0",
        "geopandas>=0.10.0",
        "torch>=1.9.0,<2.0.0",  # Limit to PyTorch 1.x for compatibility
        "torchvision>=0.10.0,<0.16.0",  # Compatible version
        "scikit-image>=0.18.0", 
        "numpy>=1.21.0",
        "shapely>=1.8.0",
        "fiona>=1.8.0",
        "pillow>=8.0.0",
        "huggingface-hub>=0.16.0",
        "tqdm>=4.60.0",
        "segmentation-models-pytorch==0.3.2",  # Specific compatible version
        "timm<0.9.0",  # Compatible timm version
    ],
    entry_points={
        "console_scripts": [
            "flood-geoai=flood_geoai.cli:main",
        ],
    },
    include_package_data=True,
    keywords=[
        "gis", "remote-sensing", "flood", "ai", "satellite-imagery", 
        "huggingface", "deep-learning", "computer-vision", "geospatial"
    ],
)