# flood_geoai/models/flood_model.py
import torch
import torch.nn as nn

class FloodDetectionModel(nn.Module):
    """
    Custom U-Net model for flood detection.
    Uses a custom implementation to avoid dependency issues.
    """
    def __init__(self, num_channels=6, num_classes=2):
        super(FloodDetectionModel, self).__init__()
        
        # Use custom U-Net implementation
        from .custom_unet import CustomUNet
        self.model = CustomUNet(n_channels=num_channels, n_classes=num_classes)
    
    def forward(self, x):
        return self.model(x)