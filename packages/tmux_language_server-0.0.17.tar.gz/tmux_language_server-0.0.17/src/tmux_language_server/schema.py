r"""Schema
==========
"""

from dataclasses import dataclass
from typing import Self

from lsp_tree_sitter import UNI
from lsp_tree_sitter.schema import Trie
from lsprotocol.types import Position, Range
from tree_sitter import Node

DIRECTIVES = {
    "set_option_directive",
    "source_file_directive",
}


@dataclass
class TmuxTrie(Trie):
    r"""Tmux Trie."""

    value: dict[str, Self] | list[Self] | str

    @classmethod
    def from_node(cls, node: Node, parent: Self | None) -> Self:
        r"""From node.

        :param node:
        :type node: Node
        :param parent:
        :type parent: Self | None
        :rtype: Self
        """
        if node.type == "value":
            return cls(UNI(node).range, parent, UNI(node).text.strip("'\""))
        if node.type == "file":
            trie = cls(Range(Position(0, 0), Position(1, 0)), parent, {})
            for child in node.children:
                if child.type not in DIRECTIVES:
                    continue
                # directive name
                _type = child.type.split("_directive")[0].replace("_", "-")
                # add directive name to trie.value if it doesn't exist
                _value: dict[str, Trie] = trie.value  # type: ignore
                if _type not in _value:
                    trie.value[_type] = cls(  # type: ignore
                        UNI(child).range,
                        trie,
                        {} if _type != "source-file" else [],
                    )
                # the dictionary's key corresponding to directive name
                subtrie: Trie = trie.value[_type]  # type: ignore
                # currently, only support set and source
                # set is a dict, source is a list
                value = subtrie.value  # type: ignore
                # fill subtrie.value
                if child.type == "set_option_directive":
                    value: dict[str, Trie]
                    value[UNI(child.children[-2]).text] = cls.from_node(
                        child.children[-1], subtrie
                    )
                elif child.type == "source_file_directive":
                    value += [  # type: ignore
                        cls(
                            UNI(child.children[1]).range,
                            subtrie,
                            UNI(child.children[1]).text,
                        )
                    ]
            return trie
        raise NotImplementedError(node.type)
