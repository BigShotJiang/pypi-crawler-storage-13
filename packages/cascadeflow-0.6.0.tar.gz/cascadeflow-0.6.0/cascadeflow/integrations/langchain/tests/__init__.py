"""Tests for LangChain integration."""
