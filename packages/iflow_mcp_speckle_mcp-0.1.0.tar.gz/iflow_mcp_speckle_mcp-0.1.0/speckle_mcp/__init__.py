"""Speckle MCP Server - A Model Context Protocol server for Speckle integration."""

__version__ = "0.1.0"