"""TextQL Client - Clean API wrapper around protocol buffers"""

from typing import Optional, Iterator
import grpc
from .platform import chat_pb2, chat_pb2_grpc
from .platform import connectors_pb2, connectors_pb2_grpc
from .platform import playbooks_pb2, playbooks_pb2_grpc


class _ClientCallDetails(
    grpc.ClientCallDetails,
):
    """Wrapper for client call details to modify method path"""

    def __init__(self, method, timeout, metadata, credentials, wait_for_ready, compression):
        self.method = method
        self.timeout = timeout
        self.metadata = metadata
        self.credentials = credentials
        self.wait_for_ready = wait_for_ready
        self.compression = compression


class _PathPrefixInterceptor(grpc.UnaryUnaryClientInterceptor, grpc.UnaryStreamClientInterceptor):
    """Interceptor to add /v1 prefix to gRPC method paths for ConnectRPC compatibility"""

    def __init__(self, prefix: str = "/v1"):
        self._prefix = prefix

    def intercept_unary_unary(self, continuation, client_call_details, request):
        new_details = self._update_path(client_call_details)
        return continuation(new_details, request)

    def intercept_unary_stream(self, continuation, client_call_details, request):
        new_details = self._update_path(client_call_details)
        return continuation(new_details, request)

    def _update_path(self, client_call_details):
        new_method = self._prefix + client_call_details.method
        return _ClientCallDetails(
            new_method,
            client_call_details.timeout,
            client_call_details.metadata,
            client_call_details.credentials,
            client_call_details.wait_for_ready if hasattr(client_call_details, 'wait_for_ready') else None,
            client_call_details.compression if hasattr(client_call_details, 'compression') else None,
        )


class ChatTools:
    """Configuration for chat tools and capabilities"""

    def __init__(
        self,
        connector_ids: Optional[list[int]] = None,
        web_search_enabled: bool = False,
        sql_enabled: bool = True,
        ontology_enabled: bool = False,
        experimental_enabled: bool = False,
        tableau_enabled: bool = False,
        auto_approve_enabled: bool = False,
        python_enabled: bool = True,
        streamlit_enabled: bool = False,
        google_drive_enabled: bool = False,
        powerbi_enabled: bool = False,
    ):
        self.connector_ids = connector_ids or []
        self.web_search_enabled = web_search_enabled
        self.sql_enabled = sql_enabled
        self.ontology_enabled = ontology_enabled
        self.experimental_enabled = experimental_enabled
        self.tableau_enabled = tableau_enabled
        self.auto_approve_enabled = auto_approve_enabled
        self.python_enabled = python_enabled
        self.streamlit_enabled = streamlit_enabled
        self.google_drive_enabled = google_drive_enabled
        self.powerbi_enabled = powerbi_enabled

    def to_proto(self) -> chat_pb2.ChatTools:
        """Convert to protobuf message"""
        return chat_pb2.ChatTools(
            connector_ids=self.connector_ids,
            web_search_enabled=self.web_search_enabled,
            sql_enabled=self.sql_enabled,
            ontology_enabled=self.ontology_enabled,
            experimental_enabled=self.experimental_enabled,
            tableau_enabled=self.tableau_enabled,
            auto_approve_enabled=self.auto_approve_enabled,
            python_enabled=self.python_enabled,
            streamlit_enabled=self.streamlit_enabled,
            google_drive_enabled=self.google_drive_enabled,
            powerbi_enabled=self.powerbi_enabled,
        )


class ChatClient:
    """Client for TextQL chat operations"""

    def __init__(self, channel: grpc.Channel, api_key: str):
        self._stub = chat_pb2_grpc.ChatServiceStub(channel)
        self._api_key = api_key

    def stream(
        self,
        question: str,
        chat_id: Optional[str] = None,
        tools: Optional[ChatTools] = None,
    ) -> Iterator[chat_pb2.StreamResponse]:
        """
        Stream a chat conversation

        Args:
            question: The question to ask
            chat_id: Optional existing chat ID to continue
            tools: ChatTools configuration for enabling various capabilities

        Yields:
            Stream response chunks

        Example:
            tools = ChatTools(
                connector_ids=[513],
                web_search_enabled=True,
                sql_enabled=True,
                python_enabled=True
            )
            stream = client.chat.stream(
                question="Tell me about the connected datasource",
                chat_id="b165f422-3097-46e0-bf22-244c3efed9ff",
                tools=tools
            )
            for response in stream:
                if response.HasField('text'):
                    print(response.text, end='', flush=True)
        """
        request = chat_pb2.StreamRequest(
            question=question,
            chat_id=chat_id,
            tools=tools.to_proto() if tools else None,
        )

        metadata = [("authorization", f"Bearer {self._api_key}")]
        yield from self._stub.Stream(request, metadata=metadata)

    def chat(
        self,
        question: str,
        chat_id: Optional[str] = None,
        tools: Optional[ChatTools] = None,
    ) -> chat_pb2.ChatResponse:
        """
        Send a chat message (non-streaming)

        Args:
            question: The question to ask
            chat_id: Optional existing chat ID to continue
            tools: ChatTools configuration

        Returns:
            ChatResponse with the complete answer

        Example:
            tools = ChatTools(connector_ids=[513])
            response = client.chat.chat(
                question="What is the total revenue?",
                tools=tools
            )
            print(response.response)
        """
        request = chat_pb2.ChatRequest(
            question=question,
            chat_id=chat_id,
            tools=tools.to_proto() if tools else None,
        )

        metadata = [("authorization", f"Bearer {self._api_key}")]
        return self._stub.Chat(request, metadata=metadata)


class ConnectorsClient:
    """Client for TextQL connector operations"""

    def __init__(self, channel: grpc.Channel, api_key: str):
        self._stub = connectors_pb2_grpc.ConnectorServiceStub(channel)
        self._api_key = api_key

    def list(self) -> connectors_pb2.ListConnectorsResponse:
        """
        List all connectors

        Returns:
            ListConnectorsResponse with all available connectors

        Example:
            connectors = client.connectors.list()
            for connector in connectors.connectors:
                print(f"{connector.id}: {connector.name}")
        """
        request = connectors_pb2.ListConnectorsRequest()
        metadata = [("authorization", f"Bearer {self._api_key}")]
        return self._stub.ListConnectors(request, metadata=metadata)


class PlaybooksClient:
    """Client for TextQL playbook operations"""

    def __init__(self, channel: grpc.Channel, api_key: str):
        self._stub = playbooks_pb2_grpc.PlaybookServiceStub(channel)
        self._api_key = api_key

    def list(self) -> playbooks_pb2.ListPlaybooksResponse:
        """
        List all playbooks

        Returns:
            ListPlaybooksResponse with all available playbooks
        """
        request = playbooks_pb2.ListPlaybooksRequest()
        metadata = [("authorization", f"Bearer {self._api_key}")]
        return self._stub.ListPlaybooks(request, metadata=metadata)


class TextQLClient:
    """
    Main TextQL client

    Usage:
        from textql import TextQLClient, ChatTools

        client = TextQLClient(
            api_key='your-api-key',
            base_url='https://staging.textql.com'
        )

        # Stream a chat
        tools = ChatTools(
            connector_ids=[513],
            web_search_enabled=True,
            sql_enabled=True,
            python_enabled=True
        )

        stream = client.chat.stream(
            question="Tell me about the connected datasource",
            chat_id="b165f422-3097-46e0-bf22-244c3efed9ff",
            tools=tools
        )

        for response in stream:
            if response.HasField('text'):
                print(response.text, end='', flush=True)
            elif response.HasField('metadata'):
                print(f"\\nChat ID: {response.metadata.chat_id}")

        # List connectors
        connectors = client.connectors.list()
        for conn in connectors.connectors:
            print(f"{conn.id}: {conn.name}")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.textql.com",
        secure: bool = True,
    ):
        """
        Initialize TextQL client

        Args:
            api_key: Your TextQL API key (base64 encoded)
            base_url: Base URL for the API (default: https://api.textql.com)
            secure: Use secure channel (default: True)
        """
        self._api_key = api_key
        self._base_url = base_url.replace("https://", "").replace("http://", "")

        # Create interceptor for ConnectRPC path prefix
        interceptor = _PathPrefixInterceptor(prefix="/v1")

        if secure:
            base_channel = grpc.secure_channel(
                self._base_url, grpc.ssl_channel_credentials()
            )
        else:
            base_channel = grpc.insecure_channel(self._base_url)

        # Wrap channel with interceptor
        self._channel = grpc.intercept_channel(base_channel, interceptor)

        # Initialize service clients
        self.chat = ChatClient(self._channel, api_key)
        self.connectors = ConnectorsClient(self._channel, api_key)
        self.playbooks = PlaybooksClient(self._channel, api_key)

    def close(self):
        """Close the gRPC channel"""
        self._channel.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
