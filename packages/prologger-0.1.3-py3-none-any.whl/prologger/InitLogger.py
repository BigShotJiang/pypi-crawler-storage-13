# -*- coding: utf-8 -*-
# @Time    : 2025/11/21 14:21
# @Author  : Henry.Yu
# @Site    :
# @File    : setup_logger.py
# @Software: PyCharm
from loguru import logger
import sys


def init_logger(log_file_path: str,
                rotation_time: str = "00:00",
                retention_period: str = "7 days",
                file_level: str = "DEBUG",
                console_level: str = "INFO"
               ) -> logger:
    """
    使用 Loguru 配置日志系统，并确保只配置一次。

    :param log_file_path: 日志文件的完整路径和名称 (例如: "./logs/gate_master.log")。
    :param rotation_time: 每天轮转的时间点 (例如: "05:00" 表示每天 5 点)。
    :param retention_period: 旧日志文件的保留时间 (例如: "30 days", "1 week", "10 MB")。
    :param file_level: 写入文件日志的最低级别 (例如: "DEBUG", "INFO")。
    :param console_level: 打印到控制台的最低级别。
    :return: 配置好的 Loguru logger 实例。
    """

    # --- 1. 清除所有已存在的日志目标，确保配置唯一 ---
    logger.remove()

    # --- 2. 添加控制台输出 (StreamHandler) ---
    logger.add(
        sys.stderr,
        level=console_level,
        colorize=True,  # 启用颜色，使控制台日志更易读
        format="<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | {level: <8} | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
    )

    # --- 3. 添加文件日志 (带轮转和保留) ---
    logger.add(
        log_file_path,
        level=file_level,
        rotation=rotation_time,  # 每天轮转时间
        retention=retention_period,  # 日志保留策略
        enqueue=True,  # 启用多进程/多线程安全
        encoding='utf-8'
    )

    # 提醒：Loguru 的 logger 实例是单例的，可以直接在任何地方导入 logger 使用。
    return logger


if __name__ == '__main__':
    log_file_path = "../logs/trade_center_example.log"
    custom_logger = init_logger(log_file_path)
    custom_logger.info("This is a test log message.")