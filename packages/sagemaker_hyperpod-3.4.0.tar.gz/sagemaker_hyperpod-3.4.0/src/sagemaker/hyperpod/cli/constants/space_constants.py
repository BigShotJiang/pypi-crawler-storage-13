# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
SPACE_GROUP = "workspace.jupyter.org"
SPACE_VERSION = "v1alpha1"
SPACE_PLURAL = "workspaces"
# Immutable fields that cannot be updated after space creation
IMMUTABLE_FIELDS = {
    "storage",  # storage is immutable per Go struct validation
}
ENABLE_MIG_PROFILE_VALIDATION = False
