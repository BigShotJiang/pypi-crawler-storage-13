from setuptools import setup, find_packages

setup(
    name="egmail",                      # PyPI name
    version="1.0.0",
    packages=find_packages(),
    author="EGALEX5",
    author_email="egale5x@gmail.com",
    description="A super-simple Gmail sending library",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/EGALEX5/egmail",   # optional GitHub link
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
