# EGMail
A super-simple Gmail sending library for sending emails using Gmail SMTP.

## Features
- Easy to use
- Minimal code
- Works with Gmail App Passwords
- Perfect for automation or CLI tools

## Installation
```bash
pip install egmail
