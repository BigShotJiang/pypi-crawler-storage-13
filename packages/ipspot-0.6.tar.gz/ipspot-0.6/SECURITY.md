# Security Policy

## Supported Versions

| Version       | Supported          |
| ------------- | ------------------ |
| 0.6           | :white_check_mark: |
| < 0.6         | :x:                |

## Reporting a Vulnerability

Please report security vulnerabilities by email to [ipspot@openscilab.com](mailto:ipspot@openscilab.com "ipspot@openscilab.com").

If the security vulnerability is accepted, a dedicated bugfix release will be issued as soon as possible (depending on the complexity of the fix).