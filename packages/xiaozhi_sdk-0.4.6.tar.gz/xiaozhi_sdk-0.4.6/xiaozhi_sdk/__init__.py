__version__ = "0.4.6"

from xiaozhi_sdk.core import XiaoZhiWebsocket  # noqa
