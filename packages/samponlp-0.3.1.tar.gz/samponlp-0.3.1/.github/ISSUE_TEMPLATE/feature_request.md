---
name: Feature Request
about: Suggest an idea for this project
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered.

**Use case**
Describe a specific use case where this feature would be helpful.

**Additional context**
Add any other context or screenshots about the feature request here.

**Would you be willing to contribute this feature?**
- [ ] Yes, I can submit a pull request
- [ ] No, but I can help with testing
- [ ] I need help implementing this
