# veriskgo/cli.py

import argparse
import time
import json
import os
from datetime import datetime

METRICS_FILE = "/tmp/veriskgo_metrics.json"


def watch_metrics():
    print("🔍 Watching VeriskGO metrics...\n")
    print(f"Reading from: {METRICS_FILE}\n")

    while True:
        os.system("cls" if os.name == "nt" else "clear")
        print("=== VeriskGO Metrics (live) ===")
        print(f"Updated: {datetime.utcnow().isoformat()}Z\n")

        try:
            with open(METRICS_FILE, "r") as f:
                metrics = json.load(f)

            # Pretty print
            for k, v in metrics.items():
                print(f"{k:25} : {v}")

        except Exception as e:
            print("⚠️ Unable to read metrics:", e)

        print("\n(Refreshing every 2s)")
        time.sleep(2)


def main():
    parser = argparse.ArgumentParser(
        prog="veriskgo",
        description="VeriskGO Telemetry CLI"
    )

    sub = parser.add_subparsers(dest="command")

    metrics_cmd = sub.add_parser("metrics", help="Metrics commands")
    metrics_cmd.add_argument("action", choices=["watch"], help="Watch live metrics")

    args = parser.parse_args()

    if args.command == "metrics" and args.action == "watch":
        watch_metrics()
    else:
        parser.print_help()
