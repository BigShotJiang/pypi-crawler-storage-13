# Simple Logs

Ein minimalistischer, farbiger Terminal-Logger für Python.

## Installation
```bash
pip install SimpleColoredLogs
```

## Verwendung
```python
from logs import Logs, LogLevel

# Einfache Logs
Logs.debug("DATABASE", "Verbindung hergestellt")
Logs.success("API", "Server gestartet")
Logs.error("AUTH", "Login fehlgeschlagen")

# Mit File-Logging
Logs.configure(log_file="app.log")

# Nur wichtige Logs
Logs.configure(min_level=LogLevel.WARN)
```

## Features

- 🎨 Farbige Terminal-Ausgabe
- 📁 Optional File-Logging
- 🎯 Level-Filtering
- ⚙️ Custom Handler
- 🕐 Konfigurierbares Timestamp-Format


### 6. **LICENSE** (MIT)

MIT License

Copyright (c) 2024 OPPRO.NET Network

Permission is hereby granted, free of charge...


### 7. **.gitignore**
```
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg