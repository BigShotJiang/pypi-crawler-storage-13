"""Test prompt functionality."""
