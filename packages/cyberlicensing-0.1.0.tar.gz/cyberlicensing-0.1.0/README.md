# CyberLicensing Python SDK

Utilities for integrating with the CyberLicensing service.

## Installation

For now, install directly from the project root:

```bash
pip install -r requirements.txt
pip install -e sdk
```

(Once published to PyPI, replace with `pip install cyberlicensing`.)

## Client-side usage

```python
from cyberlicensing import LicenseClient

client = LicenseClient(base_url="https://licensing.showdown.boo")
result = client.validate_with_environment("LICENSE-KEY-1234")
print(result)
```

`validate_with_environment` automatically gathers HWID/IP metadata. Use `validate_license` if you want to provide your own context.

## Manager-side usage

```python
from cyberlicensing import ManagerClient

manager = ManagerClient(base_url="https://licensing.showdown.boo")
manager.authenticate("admin", "password")
projects = manager.list_projects()
project_id = projects[0]["id"]
license_data = manager.create_license(project_id, days_valid=30, metadata={"plan": "pro"})
```

Additional helpers:

- `update_metadata_schema(project_id, fields)` – define metadata template (with `client_editable` flags)
- `extend_license(project_id, license_id, days)` – convenience method to push expiration forward
- `delete_license(license_id)` – revoke a key entirely

## Environment helpers

```python
from cyberlicensing import collect_environment_metadata

print(collect_environment_metadata())
```

Returns HWID, hostname, LAN IP, and (if available) public IP.
