"""Unit tests for jira_helper.py."""

import pytest
import typer

from jps_jira_utils.jira_helper import load_jira_env


def test_load_jira_env_success(monkeypatch) -> None:
    """Test successful loading of credentials from environment.

    Args:
        monkeypatch: To set fake environment variables.
    """
    monkeypatch.setenv("JIRA_BASE_URL", "https://test.atlassian.net")
    monkeypatch.setenv("JIRA_EMAIL", "user@company.com")
    monkeypatch.setenv("JIRA_API_TOKEN", "abc123")

    base_url, email, token = load_jira_env()
    assert base_url == "https://test.atlassian.net"
    assert email == "user@company.com"
    assert token == "abc123"


def test_load_jira_env_missing_vars_exits(monkeypatch, capsys) -> None:
    """Test that missing env vars trigger typer.Exit with error message.

    Args:
        monkeypatch: To unset variables.
        capsys: Capture stdout/stderr.
    """
    monkeypatch.delenv("JIRA_BASE_URL", raising=False)
    monkeypatch.delenv("JIRA_EMAIL", raising=False)
    monkeypatch.delenv("JIRA_API_TOKEN", raising=False)

    with pytest.raises(typer.Exit):
        load_jira_env()

    captured = capsys.readouterr()
    assert "Error: Missing Jira credentials." in captured.err
    assert "JIRA_BASE_URL, JIRA_EMAIL, JIRA_API_TOKEN" in captured.err
