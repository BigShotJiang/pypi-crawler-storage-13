import logging
import sys
from pathlib import Path


def setup_logging(log_file: Path) -> logging.Logger:
    """Configure root logger with file and console handlers.

    Args:
        log_file: Path to the log file.

    Returns:
        Configured logger instance.
    """
    logger = logging.getLogger("add_comment")
    logger.setLevel(logging.INFO)

    log_file.parent.mkdir(parents=True, exist_ok=True)

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.INFO)

    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(logging.WARNING)

    formatter = logging.Formatter(
        "%(levelname)s : %(asctime)s : %(pathname)s : %(lineno)d : %(message)s"
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    logger.handlers.clear()
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger
