import typer


def read_multiline_input(prompt: str) -> str:
    """Read multiline comment until two consecutive blank lines.

    Args:
        prompt: The prompt to display to the user.

    Returns:
        str: The multiline input as a single string.
    """
    typer.echo(prompt)
    lines: list[str] = []
    empty_count = 0
    while True:
        try:
            line = input()
        except EOFError:
            break
        if line.strip() == "":
            empty_count += 1
            if empty_count >= 2:
                break
        else:
            empty_count = 0
        lines.append(line)
    return "\n".join(lines).rstrip("\n")
