import os
from pathlib import Path

import typer
from dotenv import load_dotenv


def load_jira_env() -> tuple[str, str, str]:
    """Load Jira credentials from ~/.jira.env or environment.

    Returns:
        A tuple of (base_url, email, api_token).

    Raises:
        Exit: If any credentials are missing.
    """
    env_path = Path.home() / ".jira.env"
    if env_path.exists():
        load_dotenv(env_path)

    base_url = os.environ.get("JIRA_BASE_URL", "").strip().rstrip("/")
    email = os.environ.get("JIRA_EMAIL", "").strip()
    token = os.environ.get("JIRA_API_TOKEN", "").strip()

    if not all([base_url, email, token]):
        typer.echo("Error: Missing Jira credentials.", err=True)
        typer.echo("Required: JIRA_BASE_URL, JIRA_EMAIL, JIRA_API_TOKEN", err=True)
        typer.echo("Put them in ~/.jira.env or export to shell", err=True)
        raise typer.Exit(code=1)

    return base_url, email, token
