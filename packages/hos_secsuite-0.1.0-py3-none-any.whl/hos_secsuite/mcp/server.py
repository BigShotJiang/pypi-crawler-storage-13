"""FastAPI MCP server with WebSocket streaming."""

from typing import Any, Dict, Optional

from hos_secsuite.mcp.tools import execute_tool_async

def _auth_token() -> Optional[str]:
    import os
    return os.getenv("HOS_MCP_TOKEN")

def _check_auth(header: Optional[str]) -> bool:
    token = _auth_token()
    if not token:
        return True
    if not header:
        return False
    if header.startswith("Bearer "):
        return header.split(" ", 1)[1] == token
    return False

def create_app():
    try:
        from fastapi import FastAPI, WebSocket, Request, HTTPException
    except Exception:
        return None
    app = FastAPI()

    rate_state: Dict[str, Dict[str, Any]] = {}

    def _key_from_request(req: Request) -> str:
        tok = req.headers.get("Authorization") or ""
        ip = req.client.host if req.client else "unknown"
        return tok or ip

    def _rate_limit(key: str, limit: int = 60, window_sec: int = 60) -> bool:
        import time
        now = time.time()
        st = rate_state.get(key)
        if not st:
            rate_state[key] = {"start": now, "count": 1}
            return True
        if now - st["start"] > window_sec:
            rate_state[key] = {"start": now, "count": 1}
            return True
        st["count"] += 1
        return st["count"] <= limit

    from hos_secsuite.utils.logger import get_logger
    _log = get_logger("hos.mcp")

    @app.post("/tool")
    async def tool_endpoint(request: Request, payload: Dict[str, Any]):
        if not _check_auth(request.headers.get("Authorization")):
            raise HTTPException(status_code=401, detail="unauthorized")
        key = _key_from_request(request)
        if not _rate_limit(key):
            _log.warning("rate_limited key=%s", key)
            raise HTTPException(status_code=429, detail="rate_limited")
        tool_type = payload.get("type")
        args = payload.get("arguments", {})
        _log.info("tool_call type=%s args=%s", tool_type, str(args)[:300])
        res = await execute_tool_async(tool_type, args)
        _log.info("tool_resp type=%s status=%s", tool_type, res.get("status"))
        return res

    @app.websocket("/ws")
    async def ws_endpoint(ws: WebSocket):
        await ws.accept()
        await ws.send_json({"status": "ready"})
        try:
            while True:
                msg = await ws.receive_json()
                res = await execute_tool_async(msg.get("type"), msg.get("arguments", {}))
                await ws.send_json(res)
        except Exception:
            await ws.close()
    return app

def main():
    app = create_app()
    if app is None:
        print("fastapi_missing")
        return
    try:
        import uvicorn
    except Exception:
        print("uvicorn_missing")
        return
    uvicorn.run(app, host="0.0.0.0", port=8000)

