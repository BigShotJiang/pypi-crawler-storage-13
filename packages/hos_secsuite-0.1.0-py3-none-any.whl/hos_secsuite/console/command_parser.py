"""Top-level argument parser for hos-console."""

import argparse

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="hos-console")
    parser.add_argument("-v", "--version", action="store_true")
    parser.add_argument("--logo-variant", default="classic")
    parser.add_argument("--animated-logo", action="store_true")
    parser.add_argument("--non-interactive", action="store_true")
    parser.add_argument("--no-ansi", action="store_true")
    return parser

