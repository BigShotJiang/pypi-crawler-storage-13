# 🩺 DuneAI — Automated NSCLC Segmentation  
### *(PyPI package: `duneai-auto`)*

**DuneAI** provides automated detection and segmentation of non-small-cell lung cancer (NSCLC) from CT images using a pretrained deep-learning model.  
This PyPI wrapper (`duneai-auto`) packages the complete inference + viewing system while keeping the **original research code and model files external**, ensuring no proprietary content is redistributed.

This package provides:

- A **CLI to run automatic segmentation** on a dataset of CT volumes  
- A **viewer CLI** to inspect `.nrrd` images and predicted masks  
- Full compatibility with the original DuneAI pipeline (Primakov et al., *Nature Communications*, 2022)  
- Safe loading of the legacy **Keras 2.2.x model (JSON + HDF5)** on **modern TensorFlow 2.20.0**  
- A cross-platform, fully upgraded implementation of the inference code

---

# ⚙️ Installation

Install from PyPI:

```bash
pip install duneai-auto
```

Optional visualization extras (Jupyter/ipywidgets):

```bash
pip install "duneai-auto[vis]"
```

This installs:

- TensorFlow 2.20
- scikit-image, SimpleITK, statsmodels, OpenCV
- matplotlib (viewer backend)
- All runtime libraries from your tested environment
- Optional notebook support (ipywidgets, notebook) if [vis] is chosen

---

# 📂 Required External Assets

**(Not included in the PyPI package)**

You must clone/download the original research repository:

```bash
git clone https://github.com/primakov/DuneAI-Automated-detection-and-segmentation-of-non-small-cell-lung-cancer-computed-tomography-images.git
cd DuneAI-Automated-detection-and-segmentation-of-non-small-cell-lung-cancer-computed-tomography-images
```

You need the following folders from it:

```
Automatic segmentation script/
    TheDuneAI.py
    Generator_v1.py
    lung_extraction_funcs_13_09.py
    ...

Automatic segmentation script/model_files/
    model_v7.json
    weights_v7.hdf5

Software for qualitative assesment/test_data/
    (example CT volumes)
```

The CLI automatically locates these files if you run from the repo root, or you can manually override via:

```bash
export DUNEAI_ALGO_DIR="/path/to/Automatic segmentation script"
```

---

# 🚀 Quick Start

## 1) Automated Segmentation

```bash
duneai \
  --model "Automatic segmentation script/model_files" \
  --data  "Software for qualitative assesment/test_data" \
  --out   "results"
```

**Where:**
- `--model` → directory containing `model_v7.json` and `weights_v7.hdf5`
- `--data` → input CT dataset (NRRD format, one directory per patient recommended)
- `--out` → output directory

**Output structure:**

```
results/<PatientID>_(DL)/
├── image.nrrd     # resaved source CT
└── DL_mask.nrrd   # predicted segmentation mask (uint8, 0/255)
```

**Masks are:**
- generated at 512×512
- re-embedded into the original voxel grid
- rescaled to original spacing
- saved as 0/255 uint8 for viewer compatibility

---

## 👁️ Viewing Results

### A) Standalone GUI Viewer

```bash
duneai-view --gui \
  --img  "results/pat1_(DL)/image.nrrd" \
  --mask "results/pat1_(DL)/DL_mask.nrrd"
```

**GUI Features:**
- Slice navigation (slider, mouse wheel, J/K, ↑/↓)
- Window/Level controls with presets: Lung, Mediastinum, Bone
- Mask overlay (filled or contour)
- Opacity & color selector
- Jump to next/previous annotated slice
- Mask smoothing / cleanup
- Automatic area & volume computation (uses NRRD spacing)
- PNG export (S or "Save PNG")

**macOS note:**
```python
import matplotlib
matplotlib.use("TkAgg")
```

### B) Notebook Viewer (optional)

```python
from duneai_auto.viewer import notebook_view

notebook_view(
    img_path="results/pat1_(DL)/image.nrrd",
    mask_path="results/pat1_(DL)/DL_mask.nrrd",
)
```

---

# 🧠 How the Pipeline Works

1. **Preprocessing**
   - Lung windowing
   - Resampling to consistent voxel sizes
   - Automatic lung extraction
   - Cropping to 512×512 via Generator_v1

2. **Inference (Modern TensorFlow 2.20 compatible)**
   - Loads original Keras 2.2.x JSON model
   - Safely deserializes using explicit custom object mappings
   - Loads HDF5 weights
   - Runs full-volume (Z×512×512×1) inference using batch mode

3. **Re-embedding**
   - Rebuilds segmentation into a "normalized canvas" using the original exclusive indexing logic
   - Resizes back to original voxel grid

4. **Export**
   - Image & mask saved as `.nrrd`
   - Ensures:
     - original spacing
     - original origin
     - uint8 mask (0/255)

---

# ⚡ Command Reference

| Command | Description |
|---------|-------------|
| `duneai` | Run automated segmentation on a dataset (main command) |
| `duneai-auto` | Alias for `duneai` |
| `duneai-view` | Standalone viewer for `.nrrd` image & mask files |

## Common Flags

**For `duneai`:**
- `--model PATH`
- `--data PATH`
- `--out PATH`
- `--quiet`

**For `duneai-view`:**
- `--gui` — open standalone GUI
- `--img` — path to `image.nrrd`
- `--mask` — path to `DL_mask.nrrd`
- `--interactive` — notebook mode (if available)

---

# 🧪 System Requirements

**Python:** 3.9–3.11

**Core runtime dependencies (installed automatically):**
- TensorFlow 2.20.0
- NumPy ≥ 1.23
- SciPy ≥ 1.10
- SimpleITK ≥ 2.2
- scikit-image ≥ 0.25
- statsmodels ≥ 0.14
- pandas ≥ 2.3
- scikit-learn ≥ 1.7
- OpenCV ≥ 4.5
- tqdm
- matplotlib ≥ 3.6

**Optional:**
- Notebook viewer: `ipywidgets`, `notebook`
- GPU support depends on your TensorFlow installation – this package does not enforce GPU CUDA wheels.

---

# 🛠️ Troubleshooting

| Issue | Possible Cause | Solution |
|-------|---------------|----------|
| Missing `model_v7.json` | Wrong `--model` path | Point to the folder containing both model files |
| Missing `weights_v7.hdf5` | Same as above | Verify you copied from original repo |
| GUI does not open on macOS | Tk backend missing | `matplotlib.use("TkAgg")` |
| Empty or tiny mask | Threshold too strict | Reduce threshold (e.g., 0.5) |
| Shape mismatch warnings | Variable spacing/shape | Auto-resize will fix; extreme anisotropy reduces quality |
| ContourPilot import failure | Algorithm folder not found | Set `DUNEAI_ALGO_DIR` or run inside repo root |

---

# 🧾 Changelog (Key Updates)

## v1.3.0
- Robust legacy Keras JSON + HDF5 model loading on TF 2.20
- Added explicit custom object mappings for compatibility
- Restored original exclusive indexing during re-embedding
- Mask export updated to uint8 (0/255) for optimal viewer clarity
- New GUI viewer:
  - WW/WL presets
  - Opacity, color selection
  - Filled/contour modes
  - PNG export
  - Morphological smoothing
  - Area + volume calculation
- Cross-platform patient ID handling
- Maintains full compatibility with original generator & preprocessing

---

# 👩‍⚕️ Authors

**🧑‍💻 A. Lohachab**
- Updated TensorFlow/Keras migration
- CLI development
- GUI viewer
- PyPI packaging (`duneai-auto`)

**🧑‍🔬 S. Primakov**
- Original DuneAI research implementation
- Pipeline & model architecture
- Lung extraction and preprocessing algorithms

**Original Research Repository:**  
https://github.com/primakov/DuneAI-Automated-detection-and-segmentation-of-non-small-cell-lung-cancer-computed-tomography-images

**Published in:**  
Nature Communications, 2022  
https://www.nature.com/articles/s41467-022-30841-3

---

# 🧩 License

MIT License © 2025 — Maastricht University
