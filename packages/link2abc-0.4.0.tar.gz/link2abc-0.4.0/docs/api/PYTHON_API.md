# 🐍 Link2ABC Python API Reference

**♠️🌿🎸🤖🧵 G.MUSIC ASSEMBLY MODE ACTIVE**

## Overview

Link2ABC provides a comprehensive Python API for programmatic integration. This guide covers all classes, methods, and functions available for building custom applications.

## Installation

```bash
pip install link2abc              # Core functionality
pip install link2abc[ai]          # + AI features
pip install link2abc[neural]      # + Neural synthesis  
pip install link2abc[full]        # All features
```

## Quick Start API

### Simple Conversion

```python
import link2abc

# One-liner conversion
result = link2abc.link_to_music("https://app.simplenote.com/p/bBs4zY")
print(f"Generated: {result['abc_file']}")
```

### With AI Enhancement

```python
import link2abc

# AI-enhanced conversion
result = link2abc.link_to_music(
    "https://app.simplenote.com/p/bBs4zY", 
    ai="chatmusician",
    format=["abc", "midi", "mp3"]
)

print(f"Files: {result['files']}")
print(f"Metadata: {result['metadata']}")
```

## Core API Classes

### Pipeline Class

The main orchestrator for link-to-music conversion.

#### `Pipeline(steps=None, config=None)`

**Parameters:**
- `steps` (List[Any], optional): Custom pipeline steps
- `config` (Dict[str, Any], optional): Configuration dictionary

**Example:**
```python
from link2abc import Pipeline

# Default pipeline
pipeline = Pipeline()

# Custom configuration
config = {
    'ai': 'chatmusician',
    'format': ['abc', 'midi'],
    'extraction_timeout': 15
}
pipeline = Pipeline(config=config)
```

#### `Pipeline.from_config(config)`

**♠️ Nyro Structural Analysis**: Factory method using LEGO architecture.

**Parameters:**
- `config` (Dict[str, Any]): Configuration with AI, format, and processing options

**Returns:** `Pipeline` instance

**Example:**
```python
from link2abc import Pipeline

config = {
    'ai': 'chatmusician',
    'format': ['abc', 'midi', 'mp3'],
    'neural': True,
    'prompts': {
        'chatmusician_composition': 'Create jazz-influenced composition'
    }
}

pipeline = Pipeline.from_config(config)
```

#### `pipeline.run(input_data, output_path=None)`

**🌿 Aureon Emotional Processing**: Executes the complete conversion pipeline.

**Parameters:**
- `input_data` (str): URL or clipboard content to process
- `output_path` (str, optional): Output path (auto-generated if None)

**Returns:** `PipelineResult` object

**Example:**
```python
# URL processing
result = pipeline.run("https://app.simplenote.com/p/bBs4zY")

# Clipboard processing with custom output
result = pipeline.run("Sample text content", "/path/to/output")

# Check results
if result.success:
    print(f"Generated files: {result.files}")
    print(f"Execution time: {result.execution_time:.2f}s")
    print(f"Metadata: {result.metadata}")
else:
    print(f"Error: {result.error}")
```

#### `pipeline.inject_prompt(stage, prompt)`

**🎸 JamAI Harmonic Integration**: Inject custom prompts at specific pipeline stages.

**Parameters:**
- `stage` (str): Pipeline stage ('content_analysis', 'chatmusician_composition', etc.)
- `prompt` (str): Custom prompt text

**Example:**
```python
pipeline = Pipeline.from_config({'ai': 'chatmusician'})

# Custom analysis prompt
pipeline.inject_prompt('content_analysis', '''
Analyze this content for musical elements:
- Identify emotional peaks and valleys
- Extract rhythmic patterns from text flow
- Suggest melodic contour based on sentiment
''')

# Custom composition prompt  
pipeline.inject_prompt('chatmusician_composition', '''
Generate ABC notation featuring:
- Sophisticated jazz harmonies
- Syncopated rhythms
- Call-and-response melodic phrases
- Professional orchestration
''')

result = pipeline.run("https://example.com")
```

#### `pipeline.get_pipeline_info()`

**Returns:** Dictionary with pipeline configuration and step information

**Example:**
```python
pipeline = Pipeline.from_config({'ai': 'chatmusician', 'neural': True})
info = pipeline.get_pipeline_info()

print(f"Steps: {[step['name'] for step in info['steps']]}")
print(f"Capabilities: {info['lego_factory']['available_blocks']}")
print(f"Config: {info['config']}")
```

### Content Processing Classes

#### `ContentExtractor(timeout=10)`

**🧵 Synth Terminal Extraction**: Extracts content from web URLs.

**Parameters:**
- `timeout` (int): Request timeout in seconds

**Methods:**

##### `extract(url)`
Extract content from URL.

**Returns:** `ExtractedContent` object

**Example:**
```python
from link2abc.core.extractor import ContentExtractor

extractor = ContentExtractor(timeout=15)
result = extractor.extract("https://app.simplenote.com/p/bBs4zY")

if result.success:
    print(f"Platform: {result.platform}")
    print(f"Title: {result.title}")
    print(f"Content length: {len(result.content)}")
    print(f"Metadata: {result.metadata}")
else:
    print(f"Error: {result.error_message}")
```

##### `get_parser_info()`
Get HTML parser information.

**Example:**
```python
extractor = ContentExtractor()
parser_info = extractor.get_parser_info()

print(f"Parser: {parser_info['parser']}")
print(f"Mobile-friendly: {parser_info['mobile_friendly']}")
```

#### `ContentAnalyzer()`

**🌿 Aureon Emotional Analysis**: Analyzes content for emotional and thematic elements.

##### `analyze_content(content)`

**Parameters:**
- `content` (str): Text content to analyze

**Returns:** `ContentAnalysis` object

**Example:**
```python
from link2abc.core.analyzer import ContentAnalyzer

analyzer = ContentAnalyzer()
analysis = analyzer.analyze_content("This is a joyful story about friendship...")

# Access emotional profile
emotion = analysis.emotional_profile.primary_emotion.value
intensity = analysis.emotional_profile.intensity
print(f"Primary emotion: {emotion} (intensity: {intensity:.2f})")

# Access themes
for theme in analysis.themes:
    print(f"Theme: {theme.name} (confidence: {theme.confidence:.2f})")

# Access structure
structure = analysis.structure
print(f"Complexity: {structure.get('complexity', 'unknown')}")
print(f"Length: {structure.get('length', 0)} characters")
```

#### `MusicGenerator()`

**🎸 JamAI Rule-Based Generation**: Generates ABC notation using rule-based algorithms.

##### `generate_abc(analysis, config)`

**Parameters:**
- `analysis` (ContentAnalysis): Content analysis results
- `config` (Dict[str, Any]): Generation configuration

**Returns:** ABC notation string

**Example:**
```python
from link2abc.core.generator import MusicGenerator
from link2abc.core.analyzer import ContentAnalyzer

# Analyze content first
analyzer = ContentAnalyzer()
analysis = analyzer.analyze_content("A peaceful morning by the lake...")

# Generate music
generator = MusicGenerator()
config = {'style': 'classical', 'tempo': 120}
abc_notation = generator.generate_abc(analysis, config)

print("Generated ABC:")
print(abc_notation)
```

#### `FormatConverter()`

**🧵 Synth Multi-Format Conversion**: Converts ABC notation to multiple formats.

##### `convert(abc_notation, output_path, formats)`

**Parameters:**
- `abc_notation` (str): ABC notation to convert
- `output_path` (str): Base output path (without extension)
- `formats` (List[str]): Target formats ['abc', 'midi', 'mp3', 'svg']

**Returns:** Dictionary with conversion results

**Example:**
```python
from link2abc.core.converter import FormatConverter

converter = FormatConverter()
abc_notation = '''X:1
T:Sample Melody
C:Link2ABC
M:4/4
L:1/8
K:C major
|: C2 D2 E2 F2 | G2 A2 B2 c2 :|'''

result = converter.convert(
    abc_notation, 
    "output/my_song", 
    ['abc', 'midi', 'mp3']
)

print(f"Generated files: {result['files']}")
print(f"Successful formats: {result['formats_generated']}")
print(f"Failed formats: {result['formats_failed']}")
```

## AI Integration Classes

### ChatMusicianBlock

**🤖 ChatMusician AI Composer**: Professional AI music generation via HuggingFace.

#### `ChatMusicianBlock(config=None)`

**Parameters:**
- `config` (Dict[str, Any], optional): Configuration including API keys and endpoints

**Example:**
```python
from link2abc.blocks.ai.chatmusician import ChatMusicianBlock

# Using environment variables (recommended)
block = ChatMusicianBlock()

# Custom configuration
config = {
    'chatmusician': {
        'api_key': 'your-hf-token',
        'endpoint': 'https://api-inference.huggingface.co/models/m-a-p/ChatMusician',
        'timeout': 60,
        'max_retries': 3
    }
}
block = ChatMusicianBlock(config)
```

#### `generate_abc(analysis, config)`

**🎸 JamAI Professional Composition**: Generate professional ABC notation.

**Parameters:**
- `analysis` (ContentAnalysis): Content analysis results
- `config` (Dict[str, Any]): Generation configuration

**Returns:** Professional ABC notation string

**Example:**
```python
from link2abc.blocks.ai.chatmusician import ChatMusicianBlock
from link2abc.core.analyzer import ContentAnalyzer

# Set up API (ensure HUGGINGFACE_API_TOKEN is set)
import os
os.environ['HUGGINGFACE_API_TOKEN'] = 'your-token-here'

# Analyze content
analyzer = ContentAnalyzer()
analysis = analyzer.analyze_content("A dramatic storm approaches the mountains...")

# Generate with ChatMusician
chatmusician = ChatMusicianBlock()
config = {
    'style': 'cinematic',
    'chatmusician_params': {
        'hf_parameters': {
            'temperature': 0.8,
            'max_new_tokens': 1000
        }
    }
}

abc_notation = chatmusician.generate_abc(analysis, config)
print("Professional AI-generated ABC:")
print(abc_notation)
```

#### `get_info()`

**Returns:** Information about the ChatMusician configuration and status

**Example:**
```python
chatmusician = ChatMusicianBlock()
info = chatmusician.get_info()

print(f"Model: {info['hf_model_id']}")
print(f"Connected: {info['connected']}")
print(f"Capabilities: {info['capabilities']}")
print(f"Parameters: {info['parameters']}")
```

## LEGO Factory System

**♠️ Nyro Modular Architecture**: Dynamic pipeline construction system.

### LEGOFactory

#### `get_lego_factory()`

**Returns:** Global LEGO factory instance

**Example:**
```python
from link2abc.core.lego_factory import get_lego_factory

factory = get_lego_factory()
```

#### `factory.get_available_blocks()`

**Returns:** Dictionary of available blocks grouped by type

**Example:**
```python
factory = get_lego_factory()
blocks = factory.get_available_blocks()

print("Available extractors:")
for name, info in blocks.get('extractor', {}).items():
    print(f"  {name}: {info['capabilities']}")

print("Available AI generators:")
for name, info in blocks.get('ai_generator', {}).items():
    print(f"  {name}: {info['capabilities']} (available: {info['available']})")
```

#### `factory.build_pipeline(config)`

**Parameters:**
- `config` (Dict[str, Any]): Pipeline configuration

**Returns:** List of block names in execution order

**Example:**
```python
factory = get_lego_factory()

config = {
    'ai': 'chatmusician',
    'neural': True,
    'format': ['abc', 'midi', 'mp3']
}

pipeline_blocks = factory.build_pipeline(config)
print(f"Pipeline: {pipeline_blocks}")
# Output: ['url_extractor', 'content_analyzer', 'chatmusician', 'format_converter']
```

#### `factory.create_block(block_name, config=None)`

**Parameters:**
- `block_name` (str): Name of block to create
- `config` (Dict[str, Any], optional): Block configuration

**Returns:** Block instance

**Example:**
```python
factory = get_lego_factory()

# Create ChatMusician block
chatmusician = factory.create_block('chatmusician', {
    'chatmusician': {'timeout': 30}
})

# Create content analyzer
analyzer = factory.create_block('content_analyzer')
```

#### `factory.suggest_pipeline(requirements)`

**🧵 Synth Intelligent Suggestions**: Suggest optimal pipeline based on requirements.

**Parameters:**
- `requirements` (Dict[str, Any]): Requirements and preferences

**Returns:** List of suggested block names

**Example:**
```python
factory = get_lego_factory()

requirements = {
    'quality': 'high',
    'style': 'neural',
    'ai': 'chatmusician',
    'cloud': True
}

suggested_pipeline = factory.suggest_pipeline(requirements)
print(f"Suggested pipeline: {suggested_pipeline}")
```

## Data Classes

### PipelineResult

Result object returned by pipeline execution.

**Attributes:**
- `success` (bool): Whether conversion succeeded
- `url` (str): Input URL or content identifier
- `files` (Dict[str, str]): Generated files by format
- `metadata` (Dict[str, Any]): Processing metadata
- `execution_time` (float): Processing time in seconds
- `error` (str, optional): Error message if failed

**Example:**
```python
pipeline = Pipeline.from_config({'ai': 'chatmusician'})
result = pipeline.run("https://example.com")

if result.success:
    # Access generated files
    if 'abc' in result.files:
        with open(result.files['abc'], 'r') as f:
            abc_content = f.read()
    
    # Access metadata
    extraction = result.metadata.get('extraction', {})
    analysis = result.metadata.get('analysis', {})
    
    print(f"Source: {extraction.get('platform', 'unknown')}")
    print(f"Emotion: {analysis.get('emotional_profile', {}).get('primary_emotion', 'unknown')}")
else:
    print(f"Conversion failed: {result.error}")
```

### ContentAnalysis

Content analysis results with emotional and thematic data.

**Attributes:**
- `emotional_profile`: Emotional analysis results
- `themes`: List of identified themes
- `structure`: Content structure analysis
- `metadata`: Additional analysis metadata

**Example:**
```python
from link2abc.core.analyzer import ContentAnalyzer

analyzer = ContentAnalyzer()
analysis = analyzer.analyze_content("A joyful celebration of music and friendship")

# Emotional profile
emotion = analysis.emotional_profile.primary_emotion.value
intensity = analysis.emotional_profile.intensity
print(f"Emotion: {emotion} (intensity: {intensity:.2f})")

# Themes
for theme in analysis.themes[:3]:  # Top 3 themes
    print(f"Theme: {theme.name} (confidence: {theme.confidence:.2f})")

# Structure
length = analysis.structure.get('length', 0)
complexity = analysis.structure.get('complexity', 'medium')
print(f"Length: {length} chars, Complexity: {complexity}")

# Convert to dictionary for serialization
analysis_dict = analysis.to_dict()
```

## Utility Functions

### `get_version()`

**Returns:** Link2ABC version string

```python
import link2abc
print(f"Version: {link2abc.get_version()}")
```

### `get_installed_tiers()`

**Returns:** List of available enhancement tiers

```python
import link2abc
tiers = link2abc.get_installed_tiers()
print(f"Available tiers: {tiers}")

# Check specific tier
if 'ai' in tiers:
    print("AI features available")
if 'neural' in tiers:
    print("Neural synthesis available")
```

## Advanced Usage Patterns

### Custom Pipeline Builder

**♠️ Nyro Advanced Architecture**:

```python
from link2abc import Pipeline
from link2abc.core.lego_factory import get_lego_factory

# Build custom pipeline with specific blocks
factory = get_lego_factory()
config = {
    'ai': 'chatmusician',
    'format': ['abc', 'midi', 'mp3'],
    'prompts': {
        'content_analysis': 'Focus on rhythmic patterns',
        'chatmusician_composition': 'Emphasize percussion and rhythm'
    }
}

# Create pipeline with custom configuration
pipeline = Pipeline.from_config(config)

# Add custom prompt injection
pipeline.inject_prompt('musical_style', 'Generate in Afro-Cuban style')

# Execute with verbose monitoring
result = pipeline.run("https://example.com")
step_results = pipeline.get_step_results()

for step_name, step_result in step_results.items():
    print(f"Step {step_name}: {step_result.keys()}")
```

### Batch Processing System

**🧵 Synth Batch Orchestration**:

```python
import asyncio
from pathlib import Path
from link2abc import Pipeline

class BatchProcessor:
    def __init__(self, config):
        self.pipeline = Pipeline.from_config(config)
    
    def process_urls(self, urls, output_dir="batch_output"):
        """Process multiple URLs in batch"""
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        results = []
        for i, url in enumerate(urls):
            print(f"Processing {i+1}/{len(urls)}: {url}")
            
            output_file = output_path / f"batch_{i:03d}"
            result = self.pipeline.run(url, str(output_file))
            
            results.append({
                'url': url,
                'success': result.success,
                'files': result.files,
                'execution_time': result.execution_time,
                'error': result.error if not result.success else None
            })
        
        return results

# Usage
config = {'ai': 'chatmusician', 'format': ['abc', 'midi']}
processor = BatchProcessor(config)

urls = [
    "https://app.simplenote.com/p/first",
    "https://app.simplenote.com/p/second",
    "https://app.simplenote.com/p/third"
]

results = processor.process_urls(urls)

# Summary
successful = sum(1 for r in results if r['success'])
print(f"Processed: {len(results)}, Successful: {successful}")
```

### AI Model Comparison

**🤖 ChatMusician Multi-Model Analysis**:

```python
from link2abc import Pipeline

def compare_ai_models(url, models=['chatmusician', 'claude', 'chatgpt']):
    """Compare output from different AI models"""
    results = {}
    
    for model in models:
        print(f"Testing {model}...")
        
        config = {
            'ai': model,
            'format': ['abc'],
            'extraction_timeout': 15
        }
        
        try:
            pipeline = Pipeline.from_config(config)
            result = pipeline.run(url, f"comparison_{model}")
            
            results[model] = {
                'success': result.success,
                'execution_time': result.execution_time,
                'files': result.files,
                'analysis': result.metadata.get('analysis', {})
            }
            
        except Exception as e:
            results[model] = {
                'success': False,
                'error': str(e)
            }
    
    return results

# Usage
url = "https://app.simplenote.com/p/sample"
comparison = compare_ai_models(url)

for model, result in comparison.items():
    if result['success']:
        emotion = result['analysis'].get('emotional_profile', {}).get('primary_emotion', 'unknown')
        print(f"{model}: {emotion} ({result['execution_time']:.2f}s)")
    else:
        print(f"{model}: Failed - {result.get('error', 'Unknown error')}")
```

### Real-time Content Processing

**🌿 Aureon Live Processing**:

```python
import time
from link2abc.core.clipboard import ClipboardManager
from link2abc import Pipeline

class LiveProcessor:
    def __init__(self, config):
        self.pipeline = Pipeline.from_config(config)
        self.clipboard = ClipboardManager()
        self.last_content = ""
    
    def monitor_clipboard(self, interval=2):
        """Monitor clipboard for new content and process automatically"""
        print("Monitoring clipboard... (Ctrl+C to stop)")
        
        while True:
            try:
                result = self.clipboard.get_clipboard_content()
                
                if result.success and result.content != self.last_content:
                    print(f"New content detected: {len(result.content)} chars")
                    
                    # Process new content
                    self.last_content = result.content
                    output_path = f"live_{int(time.time())}"
                    
                    pipeline_result = self.pipeline.run(result.content, output_path)
                    
                    if pipeline_result.success:
                        print(f"✅ Generated: {pipeline_result.files}")
                    else:
                        print(f"❌ Failed: {pipeline_result.error}")
                
                time.sleep(interval)
                
            except KeyboardInterrupt:
                print("\n🛑 Monitoring stopped")
                break
            except Exception as e:
                print(f"⚠️  Error: {e}")
                time.sleep(interval)

# Usage (requires clipboard access)
config = {
    'ai': 'chatmusician',
    'format': ['abc', 'midi'],
    'input_mode': 'clipboard'
}

processor = LiveProcessor(config)
# processor.monitor_clipboard(interval=3)  # Check every 3 seconds
```

## Error Handling

### Exception Types

```python
from link2abc import Pipeline

pipeline = Pipeline.from_config({'ai': 'invalid_model'})

try:
    result = pipeline.run("https://example.com")
    
    if not result.success:
        # Handle pipeline errors
        error = result.error
        
        if "API key" in error:
            print("Configure API keys: export HUGGINGFACE_API_TOKEN=your_token")
        elif "Connection" in error:
            print("Check internet connection")
        elif "timeout" in error:
            print("Increase timeout: config={'extraction_timeout': 30}")
        else:
            print(f"Pipeline error: {error}")
            
except ImportError as e:
    print(f"Missing dependency: {e}")
    print("Install required tier: pip install link2abc[ai]")
    
except Exception as e:
    print(f"Unexpected error: {e}")
```

### Graceful Degradation

```python
from link2abc import Pipeline, get_installed_tiers

def create_best_pipeline():
    """Create the best available pipeline based on installed tiers"""
    tiers = get_installed_tiers()
    config = {'format': ['abc', 'midi']}
    
    if 'ai' in tiers:
        # Try AI models in order of preference
        for ai_model in ['chatmusician', 'claude', 'chatgpt']:
            try:
                test_config = config.copy()
                test_config['ai'] = ai_model
                pipeline = Pipeline.from_config(test_config)
                
                # Quick connection test for ChatMusician
                if ai_model == 'chatmusician':
                    from link2abc.blocks.ai.chatmusician import ChatMusicianBlock
                    block = ChatMusicianBlock()
                    if not block._test_connection():
                        continue
                
                print(f"Using AI model: {ai_model}")
                return pipeline
                
            except Exception as e:
                print(f"AI model {ai_model} unavailable: {e}")
                continue
    
    # Fallback to core functionality
    print("Using core (rule-based) generation")
    return Pipeline.from_config(config)

# Usage
pipeline = create_best_pipeline()
result = pipeline.run("https://example.com")
```

---

**Generated by**: ♠️🌿🎸🤖🧵 G.Music Assembly  
**Link2ABC Version**: 0.3.0  
**Last Updated**: 2025-08-22