# 🛠️ Link2ABC Troubleshooting Guide

**♠️🌿🎸🤖🧵 G.MUSIC ASSEMBLY MODE ACTIVE**

## Overview

This guide covers common issues, error messages, and solutions for Link2ABC. Use this resource to diagnose and resolve problems quickly.

## Installation Issues

### Import Errors

#### `ImportError: cannot import name 'cli_entry_point'`

**Problem**: CLI entry point not properly configured in installation.

**Solution**:
```bash
# Reinstall the package
pip uninstall link2abc
pip install link2abc

# Or install from source
cd /path/to/link2abc
pip install -e .
```

**Test Fix**:
```bash
python -c "import link2abc; print('✅ Import successful')"
```

#### `ImportError: No module named 'linktune'`

**Problem**: Package not installed or not in Python path.

**Solutions**:
1. Install the package: `pip install link2abc`
2. Check Python environment: `which python` and `pip list | grep link2abc`
3. Virtual environment issue: `source venv/bin/activate`

#### `ModuleNotFoundError: No module named 'music21'`

**Problem**: Core dependency missing.

**Solution**:
```bash
pip install music21>=8.1.0
# Or reinstall with all dependencies
pip install --force-reinstall link2abc
```

### Tier Installation Issues

#### `Block 'chatmusician' requires 'ai' tier`

**Problem**: AI features requested but AI tier not installed.

**Solution**:
```bash
pip install link2abc[ai]
```

**Verify Installation**:
```bash
python -c "import link2abc; print('AI available:', 'ai' in link2abc.get_installed_tiers())"
```

#### Neural/Cloud Tier Issues

**Neural Tier (large download)**:
```bash
# Requires ~2GB download and 8GB+ RAM
pip install link2abc[neural]

# If download fails, try:
pip install --no-cache-dir link2abc[neural]
```

**Cloud Tier**:
```bash
pip install link2abc[cloud]

# Verify AWS dependencies
python -c "import boto3; print('✅ Cloud tier ready')"
```

## Network and Connection Issues

### Content Extraction Failures

#### `Network error: HTTPSConnectionPool... Max retries exceeded`

**Problem**: Network connectivity or DNS resolution issues.

**Test Network**:
```bash
curl -I https://example.com
ping 8.8.8.8
```

**Solutions**:
1. Check internet connection
2. Try different URL
3. Increase timeout: `--config` with `extraction_timeout: 30`
4. Use proxy if required

#### `Content extraction failed: 403 Forbidden`

**Problem**: Website blocking automated requests.

**Solutions**:
1. Try different user agent
2. Use clipboard mode instead: `link2abc --clipboard`
3. Manually copy content and process

### API Connection Issues

#### `ChatMusician API key not configured`

**Problem**: HuggingFace API token not set.

**Solution**:
```bash
export HUGGINGFACE_API_TOKEN="hf_your_token_here"
# Or add to ~/.bashrc for persistence
echo 'export HUGGINGFACE_API_TOKEN="hf_your_token_here"' >> ~/.bashrc
```

**Test Configuration**:
```bash
python -c "
import os
print('HF Token:', 'SET' if os.environ.get('HUGGINGFACE_API_TOKEN') else 'NOT SET')
"
```

#### `Claude API connection failed`

**Problem**: Anthropic API key missing or invalid.

**Solution**:
```bash
export ANTHROPIC_API_KEY="sk-ant-your_key_here"
```

**Test**:
```bash
python -c "
import os, requests
token = os.environ.get('ANTHROPIC_API_KEY')
if token:
    print('✅ Anthropic token configured')
else:
    print('❌ ANTHROPIC_API_KEY not set')
"
```

#### `HuggingFace API error: 503 - Model loading`

**Problem**: AI model is loading on HuggingFace servers (normal).

**Solution**: Wait and retry. Models auto-load on demand.

```bash
# Retry with longer timeout
link2abc https://example.com --ai chatmusician --verbose
```

**Expected Behavior**: First request may take 30-60 seconds for model loading.

## Clipboard Issues

### Termux/Android Clipboard

#### `Failed to access clipboard: No clipboard method available`

**Problem**: Termux clipboard API not installed.

**Solution**:
```bash
pkg update && pkg upgrade
pkg install termux-api
```

**Test Clipboard**:
```bash
# Copy some text, then test:
termux-clipboard-get
```

#### `Clipboard content retrieved via manual_input`

**Problem**: Automatic clipboard access failed, manual input prompted.

**Solutions**:
1. Install proper clipboard tools
2. Use file input instead: `link2abc file:///path/to/content.txt`
3. Paste content when prompted

### Desktop Clipboard Issues

#### Linux clipboard problems

**Solutions**:
```bash
# Install xclip or xsel
sudo apt-get install xclip
# or
sudo apt-get install xsel

# Test
echo "test" | xclip -selection clipboard
xclip -selection clipboard -o
```

#### macOS clipboard issues

**Solution**: `pbcopy`/`pbpaste` should be available by default.

**Test**:
```bash
echo "test" | pbcopy
pbpaste
```

## Music Generation Issues

### ABC Notation Problems

#### `Invalid ABC notation generated`

**Problem**: Generated ABC has syntax errors.

**Diagnosis**:
```bash
# Check ABC file manually
cat output/generated.abc

# Validate with online ABC checker
# or use abc2midi if available
```

**Solutions**:
1. Use different AI model: `--ai claude` instead of `--ai chatmusician`
2. Try simpler content
3. Use core generation: remove `--ai` flag

#### `MIDI conversion failed`

**Problem**: ABC to MIDI conversion errors.

**Check Dependencies**:
```bash
python -c "import music21; print('✅ music21 available')"
```

**Solutions**:
1. Reinstall music21: `pip install --force-reinstall music21`
2. Use ABC-only output: `--format abc`
3. Check ABC syntax validity

#### `MP3 conversion requires external tools`

**Problem**: MP3 generation needs additional software.

**Solutions**:

**Linux/Termux**:
```bash
pkg install ffmpeg  # Termux
# or
sudo apt-get install ffmpeg  # Ubuntu/Debian
```

**macOS**:
```bash
brew install ffmpeg
```

**Alternative**: Use online ABC to MP3 converters or stick to MIDI format.

### AI Generation Issues

#### `Temperature parameter out of range`

**Problem**: AI generation parameters invalid.

**Solution**: Check custom prompts and parameters:
```yaml
# In prompt file, ensure valid parameters
chatmusician_params:
  hf_parameters:
    temperature: 0.7  # Must be 0.0-1.0
    max_new_tokens: 800  # Reasonable limit
```

#### `Generated text contains no valid ABC notation`

**Problem**: AI model output doesn't contain proper ABC format.

**Solutions**:
1. Try different prompt style
2. Use different AI model
3. Fall back to core generation

**Debug**:
```bash
# Use verbose mode to see AI output
link2abc https://example.com --ai chatmusician --verbose
```

## Performance Issues

### Slow Processing

#### `Execution time > 30 seconds`

**Problem**: Processing taking too long.

**Solutions**:
1. Increase timeout: `extraction_timeout: 60` in config
2. Use simpler AI model or core generation
3. Reduce content complexity
4. Check network speed

#### `Memory usage too high`

**Problem**: System running out of memory, especially with neural tier.

**Solutions**:
1. Close other applications
2. Use AI tier instead of neural: `pip install link2abc[ai]`
3. Process smaller content chunks
4. Increase system swap space

### Concurrent Processing Issues

#### `Too many open files`

**Problem**: Batch processing hitting system limits.

**Solution**:
```bash
# Increase file descriptor limit
ulimit -n 4096

# Or in script:
import resource
resource.setrlimit(resource.RLIMIT_NOFILE, (4096, 4096))
```

## Configuration Issues

### Config File Problems

#### `Failed to load config file`

**Problem**: YAML or JSON syntax errors.

**Diagnosis**:
```bash
# Validate YAML
python -c "import yaml; yaml.safe_load(open('config.yaml'))"

# Or online YAML validator
```

**Common YAML errors**:
- Incorrect indentation (use spaces, not tabs)
- Missing colons after keys
- Unquoted strings with special characters

#### `Config directory not found`

**Problem**: Link2ABC config directory missing.

**Solution**:
```bash
mkdir -p ~/.link2abc
# Run setup wizard
link2abc --init
```

### Environment Variable Issues

#### `Environment variables not loaded`

**Problem**: API keys not being read.

**Solutions**:
```bash
# Check current environment
env | grep -E "(HUGGINGFACE|ANTHROPIC|OPENAI)"

# Load from file
source ~/.link2abc/.env

# Add to shell profile
echo 'source ~/.link2abc/.env' >> ~/.bashrc
```

## Debugging Techniques

### Verbose Mode Debugging

**Enable Maximum Verbosity**:
```bash
link2abc https://example.com --verbose --ai chatmusician
```

**Python API Debugging**:
```python
import logging
logging.basicConfig(level=logging.DEBUG)

import link2abc
# API calls will show detailed logs
```

### Component Testing

**Test Individual Components**:
```python
# Test content extraction
from link2abc.core.extractor import ContentExtractor
extractor = ContentExtractor()
result = extractor.extract("https://example.com")
print(f"Extraction: {result.success}")

# Test content analysis  
from link2abc.core.analyzer import ContentAnalyzer
analyzer = ContentAnalyzer()
analysis = analyzer.analyze_content("test content")
print(f"Analysis: {analysis.emotional_profile.primary_emotion.value}")

# Test music generation
from link2abc.core.generator import MusicGenerator
generator = MusicGenerator()
abc = generator.generate_abc(analysis, {})
print(f"Generated ABC length: {len(abc)}")
```

### Performance Profiling

**Basic Performance Measurement**:
```python
import time
import link2abc

start_time = time.time()
result = link2abc.link_to_music("https://example.com")
execution_time = time.time() - start_time

print(f"Total time: {execution_time:.2f}s")
print(f"Pipeline time: {result.execution_time:.2f}s")
```

## Error Code Reference

### Common Exit Codes

- `0`: Success
- `1`: General error (network, parsing, etc.)
- `2`: Configuration error
- `3`: API/Authentication error
- `4`: File system error

### HTTP Error Codes

- `403`: Forbidden (website blocking)
- `404`: Content not found
- `429`: Rate limited (API)
- `503`: Service unavailable (model loading)

## Getting Help

### Community Support

1. **GitHub Issues**: https://github.com/jgwill/link2abc/issues
2. **Discussions**: https://github.com/jgwill/link2abc/discussions
3. **Documentation**: https://link2abc.readthedocs.io

### Reporting Bugs

**Include in Bug Reports**:
```bash
# System information
uname -a
python --version
pip show link2abc

# Error reproduction
link2abc --version
link2abc --list-tiers
# Exact command that failed
# Complete error message
```

### Emergency Fallbacks

**When All Else Fails**:
1. Use core functionality only: remove `--ai` and `--neural` flags
2. Use clipboard mode: `link2abc --clipboard`
3. Process smaller content chunks
4. Try different content sources
5. Reinstall completely: `pip uninstall link2abc && pip install link2abc`

## Version-Specific Issues

### Link2ABC v0.3.0 Known Issues

1. **CLI Entry Point**: Use Python API directly if CLI fails
2. **Neural Harmony**: Missing module reported in some installations
3. **Format Conversion**: MP3 requires external tools

### Compatibility Matrix

| Python Version | Core | AI | Neural | Cloud |
|---------------|------|----|---------| ------|
| 3.8           | ✅   | ✅  | ⚠️      | ✅    |
| 3.9           | ✅   | ✅  | ✅      | ✅    |
| 3.10          | ✅   | ✅  | ✅      | ✅    |
| 3.11          | ✅   | ✅  | ✅      | ✅    |
| 3.12          | ✅   | ✅  | ⚠️      | ✅    |

**Legend**: ✅ Fully supported, ⚠️ Partial/experimental support

---

**Generated by**: ♠️🌿🎸🤖🧵 G.Music Assembly  
**Link2ABC Version**: 0.3.0  
**Last Updated**: 2025-08-22  
**Test Status**: Core functionality verified ✅, AI pending API tokens ⚠️