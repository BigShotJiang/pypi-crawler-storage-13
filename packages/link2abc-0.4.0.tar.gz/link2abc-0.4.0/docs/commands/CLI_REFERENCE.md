# 🎵 Link2ABC CLI Reference Guide

**♠️🌿🎸🤖🧵 G.MUSIC ASSEMBLY MODE ACTIVE**

## Overview

Link2ABC provides a comprehensive command-line interface for transforming web content into ABC music notation using AI technology. This reference covers every command, option, and parameter available.

## Command Syntax

```bash
link2abc [URL] [OPTIONS]
link2abc --clipboard [OPTIONS]
link2abc [SPECIAL_COMMANDS]
```

## Core Commands

### Basic Conversion

#### `link2abc <URL>`
Convert any web URL to ABC music notation.

**Syntax:**
```bash
link2abc https://example.com
```

**Example:**
```bash
link2abc https://app.simplenote.com/p/bBs4zY
```

**Output:**
```
🎵 Converting: https://app.simplenote.com/p/bBs4zY
✅ Conversion completed successfully!

📄 Generated files:
   🎵 ABC: output/linktune_simplenote_1692789123_abc123.abc (1.2 KB)
   🎵 MIDI: output/linktune_simplenote_1692789123_abc123.mid (856 bytes)

⏱️  Execution time: 0.84s
```

#### `link2abc --clipboard` / `link2abc -c`
Convert clipboard content to ABC notation (mobile-friendly).

**Syntax:**
```bash
link2abc --clipboard
link2abc -c
```

**Example Usage:**
1. Copy any text content to clipboard
2. Run: `link2abc -c`
3. Music files are generated from clipboard content

**Termux/Android Setup:**
```bash
pkg install termux-api
link2abc --clipboard
```

## AI Enhancement Options

### `--ai <MODEL>`
Enable AI-powered music generation.

**Available Models:**
- `chatmusician` - Professional AI composer (6.74B parameters)
- `claude` - Sophisticated content analysis
- `chatgpt` - Creative interpretation
- `auto` - Automatically choose best available

**Examples:**

#### ChatMusician (Professional Composition)
```bash
link2abc https://app.simplenote.com/p/bBs4zY --ai chatmusician
```
Generates professional-quality ABC notation with:
- Advanced harmonies and chord progressions
- Style transfer (Jazz, Classical, Celtic, Folk)
- Ornamental expressions (grace notes, trills)
- Emotional intelligence matching content

#### Claude (Deep Analysis)
```bash
link2abc https://app.simplenote.com/p/bBs4zY --ai claude
```
Provides sophisticated content analysis with:
- Cultural context understanding
- Nuanced emotional profiling
- Thematic depth analysis

#### ChatGPT (Creative Interpretation)
```bash
link2abc https://app.simplenote.com/p/bBs4zY --ai chatgpt
```
Offers creative content interpretation with:
- Musical creativity enhancement
- Narrative understanding
- Artistic interpretation

#### Auto-Selection
```bash
link2abc https://app.simplenote.com/p/bBs4zY --ai auto
```
Automatically selects the best available AI model based on:
- Available API keys
- Content complexity
- Quality requirements

## Output Format Options

### `--format <FORMATS>` / `-f <FORMATS>`
Specify output formats (comma-separated).

**Available Formats:**
- `abc` - ABC notation (text format)
- `midi` - MIDI audio file
- `mp3` - MP3 audio file (requires external tools)
- `svg` - SVG visual score
- `jpg` - JPEG visual score

**Examples:**

#### Single Format
```bash
link2abc https://example.com --format abc
```

#### Multiple Formats
```bash
link2abc https://example.com --format abc,midi,mp3
link2abc https://example.com -f abc,midi,svg,jpg
```

#### All Formats
```bash
link2abc https://example.com --format abc,midi,mp3,svg,jpg
```

## Advanced Options

### `--output <FILENAME>` / `-o <FILENAME>`
Specify custom output filename (without extension).

**Example:**
```bash
link2abc https://example.com --output my_composition
# Creates: my_composition.abc, my_composition.mid
```

### `--prompt-file <FILE>` / `-p <FILE>`
Use custom YAML prompts for AI generation.

**Create prompts.yaml:**
```yaml
content_analysis: |
  Analyze this content for musical elements:
  - Identify emotional tone and energy level
  - Extract key themes and narrative arc
  - Suggest appropriate musical genre

chatmusician_composition: |
  Generate ABC notation that:
  - Reflects the emotional journey
  - Uses sophisticated harmonic progressions
  - Includes ornamental expressions
  - Maintains musical coherence
```

**Usage:**
```bash
link2abc https://example.com --ai chatmusician --prompt-file prompts.yaml
```

### `--config <FILE>`
Load configuration from YAML/JSON file.

**Create config.yaml:**
```yaml
ai:
  default: "chatmusician"
  chatmusician:
    endpoint: "https://api-inference.huggingface.co/models/m-a-p/ChatMusician"
    model: "latest"

output:
  default_format: ["abc", "midi"]
  directory: "~/Music/Link2ABC"

neural:
  enabled: true
  complexity: "medium"
```

**Usage:**
```bash
link2abc https://example.com --config config.yaml
```

## Neural Processing Options

### `--neural`
Enable neural synthesis with advanced AI music generation.

**Requirements:**
```bash
pip install link2abc[neural]  # ~2GB download, 8GB+ RAM
```

**Example:**
```bash
link2abc https://example.com --neural
```

**Features:**
- Orpheus neural synthesis integration
- Advanced audio synthesis
- Voice input processing
- Semantic content analysis

### Combined Neural + AI
```bash
link2abc https://example.com --ai chatmusician --neural --format abc,midi,mp3
```

## Cloud Execution Options

### `--cloud`
Execute processing in the cloud with auto-termination.

**Requirements:**
```bash
pip install link2abc[cloud]
```

**Example:**
```bash
link2abc https://example.com --cloud
```

### `--cost-optimize`
Enable cost optimization for cloud processing.

**Example:**
```bash
link2abc https://example.com --cloud --cost-optimize
```

**Features:**
- Auto-terminating cloud instances
- Cost-effective processing
- Optimized resource allocation
- Smart scheduling

## Utility Commands

### `--version`
Display Link2ABC version information.

**Example:**
```bash
link2abc --version
```

**Output:**
```
Link2ABC v0.3.0
Transform any link into ABC music notation with AI - simple as that!
```

### `--list-tiers`
Show available enhancement tiers and installation status.

**Example:**
```bash
link2abc --list-tiers
```

**Output:**
```
🧱 Available Link2ABC Tiers:
  ✅ core - Basic rule-based generation
  ✅ ai - AI-enhanced composition (ChatMusician via HuggingFace, Claude, ChatGPT)
  ❌ neural - Install with: pip install link2abc[neural]
  ❌ cloud - Install with: pip install link2abc[cloud]
```

### `--test`
Test basic functionality with example content.

**Example:**
```bash
link2abc --test
```

**Output:**
```
🧪 Testing Link2ABC basic functionality...
✅ Basic test passed!
   Generated: {'abc': 'output/test_example.abc', 'midi': 'output/test_example.mid'}
   Execution time: 0.43s
```

### `--test-ai`
Test AI functionality for all available models.

**Requirements:** AI tier installed (`pip install link2abc[ai]`)

**Example:**
```bash
link2abc --test-ai
```

**Output:**
```
🤖 Testing Link2ABC AI functionality...
   Testing chatmusician...
   ✅ chatmusician test passed! (HuggingFace API accessible)
   Testing claude...
   ✅ claude test passed!
   Testing chatgpt...
   ❌ chatgpt not available
```

### `--init`
Interactive setup wizard for complete Link2ABC configuration.

**Example:**
```bash
link2abc --init
```

**Features:**
- Step-by-step configuration
- AI service setup (API keys)
- Output directory selection
- Format preferences
- Cloud configuration
- Neural processing setup
- Configuration file generation

## Verbose Output

### `--verbose` / `-v`
Enable detailed output for debugging and analysis.

**Example:**
```bash
link2abc https://example.com --ai chatmusician --verbose
```

**Additional Output:**
```
🔧 Configuration: {'ai': 'chatmusician', 'format': ['abc', 'midi']}
🔗 Pipeline steps: ['URL Content Extractor', 'Content Analyzer', 'ChatMusician AI Composer', 'Multi-Format Converter']
📋 Clipboard content retrieved via termux-api
📝 Content length: 2847 characters
📝 Preview: This is a sample text content that will be converted...

📝 Content extracted from: simplenote
   Title: Sample Note

🎭 Analysis:
   Emotion: contemplation
   Intensity: 0.73
   Themes: technology, creativity, innovation
```

## Environment Variables

Link2ABC supports configuration via environment variables:

### API Keys
```bash
export HUGGINGFACE_API_TOKEN="hf_xxxxxxxxxxxxx"
export CHATMUSICIAN_API_KEY="cm_xxxxxxxxxxxxx"
export ANTHROPIC_API_KEY="sk-ant-xxxxxxxxxxxxx"
export OPENAI_API_KEY="sk-xxxxxxxxxxxxx"
```

### Langfuse Integration
```bash
export LANGFUSE_PUBLIC_KEY="pk_xxxxxxxxxxxxx"
export LANGFUSE_SECRET_KEY="sk_xxxxxxxxxxxxx"
```

### Cloud Services
```bash
export AWS_ACCESS_KEY_ID="AKIAXXXXXXXXXXXXX"
export AWS_SECRET_ACCESS_KEY="xxxxxxxxxxxxxxxxxxxxxxx"
```

### Model Configuration
```bash
export CHATMUSICIAN_MODEL_ID="m-a-p/ChatMusician"
export CHATMUSICIAN_ENDPOINT="https://api-inference.huggingface.co/models/m-a-p/ChatMusician"
export CHATMUSICIAN_TIMEOUT="60"
export CHATMUSICIAN_USE_LOCAL="false"
```

## Common Usage Patterns

### Quick Start
```bash
# Basic conversion
link2abc https://app.simplenote.com/p/bBs4zY

# With AI enhancement
link2abc https://app.simplenote.com/p/bBs4zY --ai chatmusician

# Multiple formats
link2abc https://app.simplenote.com/p/bBs4zY --format abc,midi,mp3
```

### Mobile/Termux Workflow
```bash
# Setup (one-time)
pkg install termux-api
pip install link2abc

# Copy text, then:
link2abc -c --ai chatmusician --format abc,midi
```

### Professional Workflow
```bash
# Setup configuration
link2abc --init

# Use custom prompts
link2abc https://example.com --ai chatmusician --prompt-file custom_prompts.yaml

# High-quality output
link2abc https://example.com --ai chatmusician --neural --format abc,midi,mp3,svg
```

### Batch Processing
```bash
# Process multiple URLs
for url in $(cat urls.txt); do
    link2abc "$url" --ai chatmusician --output "batch_$(date +%s)"
done
```

### Development/Testing
```bash
# Test installation
link2abc --test
link2abc --test-ai

# Debug mode
link2abc https://example.com --verbose

# Check available features
link2abc --list-tiers
```

## Error Handling

### Common Errors and Solutions

#### Network Issues
```bash
❌ Conversion failed: Content extraction failed: Connection timeout
```
**Solution:** Check internet connection, try again

#### Missing API Keys
```bash
❌ Conversion failed: ChatMusician API key not configured
```
**Solution:** Set environment variable or run `link2abc --init`

#### Invalid URL
```bash
❌ Conversion failed: Invalid URL format
```
**Solution:** Ensure URL is complete with protocol (https://)

#### Clipboard Issues
```bash
❌ Failed to access clipboard: No clipboard method available
```
**Solution:** Install `termux-api` on Android or ensure clipboard tools on desktop

#### Tier Not Installed
```bash
❌ Block 'chatmusician' requires 'ai' tier
```
**Solution:** Install required tier: `pip install link2abc[ai]`

## Performance Guidelines

### Execution Times
- **Basic (core)**: 0.1-0.5 seconds
- **AI Enhanced**: 1-5 seconds
- **Neural Processing**: 5-15 seconds
- **Cloud Execution**: 0.3-2 seconds + startup

### Cost Estimates (Cloud)
- **Basic Processing**: $0.001-0.01 per conversion
- **AI Generation**: $0.01-0.05 per conversion
- **Neural Synthesis**: $0.05-0.20 per conversion

### Memory Usage
- **Core**: ~50MB RAM
- **AI**: ~200MB RAM
- **Neural**: ~2GB+ RAM (requires neural dependencies)

## Best Practices

1. **Start Simple**: Begin with basic conversion, then add AI enhancement
2. **Test Configuration**: Use `--test` and `--test-ai` to verify setup
3. **Use Verbose Mode**: Add `--verbose` for debugging and understanding
4. **Configure Once**: Run `--init` wizard for optimal setup
5. **Mobile Optimization**: Use `--clipboard` mode for mobile workflows
6. **Batch Processing**: Process multiple items efficiently
7. **Format Selection**: Choose appropriate output formats for your needs
8. **API Key Management**: Store API keys securely in environment variables

---

**Generated by**: ♠️🌿🎸🤖🧵 G.Music Assembly  
**Link2ABC Version**: 0.3.0  
**Last Updated**: 2025-08-22