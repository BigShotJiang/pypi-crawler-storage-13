"""Input domain implementation."""
