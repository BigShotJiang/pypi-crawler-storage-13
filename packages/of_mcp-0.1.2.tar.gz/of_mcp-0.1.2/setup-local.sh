#!/bin/bash
# Quick setup script to use CLI with local backend

echo "🚀 MCP Gateway CLI - Local Setup"
echo ""

# Check if backend is running
if ! curl -s http://localhost:8000/health > /dev/null 2>&1; then
    echo "⚠️  Backend not running on localhost:8000"
    echo "   Start it first with: cd mcp-proxy && npm run dev"
    echo ""
    exit 1
fi

echo "✅ Backend is running on localhost:8000"
echo ""

# Activate virtual environment
cd "$(dirname "$0")"
source .venv/bin/activate

# Set API URL
export MCPGW_API_URL=http://localhost:8000/api/v1

echo "🔧 Configuration:"
echo "   API URL: $MCPGW_API_URL"
echo "   Config: ~/.mcpgw/config.json"
echo ""

# Check if already logged in
if [ -f ~/.mcpgw/config.json ] && grep -q "token" ~/.mcpgw/config.json; then
    echo "✅ Already authenticated"
    echo ""
    echo "Run: mcpgw workspace list"
else
    echo "🔐 Login Required"
    echo ""
    echo "Run: mcpgw auth login"
    echo ""
fi

echo "📚 Available commands:"
echo "   mcpgw auth login              # Login with email/password"
echo "   mcpgw workspace list          # List your workspaces"
echo "   mcpgw workspace create        # Create new workspace"
echo "   mcpgw backend list WS_ID      # List backends"
echo "   mcpgw catalog list            # Browse catalog"
echo "   mcpgw agent create WS_ID      # Create agent"
echo ""
echo "💡 Tip: Keep this terminal open or add to ~/.zshrc:"
echo "   export MCPGW_API_URL=http://localhost:8000/api/v1"
echo "   alias mcpgw='source ~/of/mcp-gateway/cli/.venv/bin/activate && mcpgw'"
