class Mcpgw < Formula
  include Language::Python::Virtualenv

  desc "MCP Gateway CLI - Manage Model Context Protocol servers for Claude Desktop"
  homepage "https://mcpgw.io"
  url "https://files.pythonhosted.org/packages/source/m/mcpgw/mcpgw-0.1.0.tar.gz"
  sha256 "REPLACE_WITH_ACTUAL_SHA256"
  license "MIT"
  head "https://github.com/orangefennec/mcp-gateway.git", branch: "main", subdirectory: "cli"

  depends_on "python@3.12"

  resource "click" do
    url "https://files.pythonhosted.org/packages/source/c/click/click-8.1.7.tar.gz"
    sha256 "ca9853ad459e787e2192211578cc907e7594e294c7ccc834310722b41b9ca6de"
  end

  resource "requests" do
    url "https://files.pythonhosted.org/packages/source/r/requests/requests-2.31.0.tar.gz"
    sha256 "942c5a758f98d5e3ac8cd099e17c3ca3aa7a5d1e8dc359f6e64c4dc20ca29c9d"
  end

  resource "urllib3" do
    url "https://files.pythonhosted.org/packages/source/u/urllib3/urllib3-2.1.0.tar.gz"
    sha256 "df7aa8afb0148fa78488e7899b2c59b5f4ffcfa82e6c54ccb9dd37c1d7b52d54"
  end

  resource "certifi" do
    url "https://files.pythonhosted.org/packages/source/c/certifi/certifi-2023.11.17.tar.gz"
    sha256 "9b469f3a900bf28dc19b8cfbf8019bf47f7fdd1a65a1d4ffb98fc14166beb4d1"
  end

  resource "charset-normalizer" do
    url "https://files.pythonhosted.org/packages/source/c/charset-normalizer/charset-normalizer-3.3.2.tar.gz"
    sha256 "f30c3cb33b24454a82faecaf01b19c18562b1e89558fb6c56de4d9118a032fd5"
  end

  resource "idna" do
    url "https://files.pythonhosted.org/packages/source/i/idna/idna-3.6.tar.gz"
    sha256 "9ecdbbd083b06798ae1e86adcbfe8ab1479cf864e4ee30fe4e46a003d12491ca"
  end

  def install
    virtualenv_install_with_resources
    
    # Create shell completion files
    generate_completions_from_executable(bin/"mcpgw", shells: [:bash, :zsh, :fish],
                                         shell_parameter_format: :click)
    
    # Install shell alias helper
    (prefix/"etc/profile.d").mkpath
    (prefix/"etc/profile.d/mcpgw_alias.sh").write <<~EOS
      # MCP Gateway CLI alias
      alias mg='mcpgw'
    EOS
  end

  def caveats
    <<~EOS
      MCP Gateway CLI has been installed!
      
      Commands:
        mcpgw      - Full command
        mg         - Short alias (add to your shell: alias mg='mcpgw')
      
      Quick Start:
        mcpgw auth login
        mcpgw quickstart
        mcpgw add github
        mcpgw generate
      
      Documentation: https://docs.mcpgw.io
      
      To add the 'mg' alias to your shell, add this to your ~/.zshrc or ~/.bashrc:
        alias mg='mcpgw'
    EOS
  end

  test do
    assert_match "mcpgw", shell_output("#{bin}/mcpgw --version")
    assert_match "Usage:", shell_output("#{bin}/mcpgw --help")
  end
end
