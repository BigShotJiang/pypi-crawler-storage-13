#!/bin/bash
# Script to bump version and create a git tag for automatic PyPI publishing

set -e

if [ -z "$1" ]; then
    echo "Usage: ./bump-version.sh <version>"
    echo "Example: ./bump-version.sh 0.1.1"
    exit 1
fi

NEW_VERSION=$1

# Validate version format (semantic versioning)
if ! [[ $NEW_VERSION =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo "❌ Error: Version must be in format X.Y.Z (e.g., 0.1.1)"
    exit 1
fi

echo "📦 Bumping version to $NEW_VERSION"

# Update version in pyproject.toml
sed -i.bak "s/^version = \".*\"/version = \"$NEW_VERSION\"/" pyproject.toml && rm pyproject.toml.bak

# Update version in setup.py
sed -i.bak "s/version=\".*\"/version=\"$NEW_VERSION\"/" setup.py && rm setup.py.bak

echo "✅ Updated version files"

# Git operations
git add pyproject.toml setup.py
git commit -m "Bump version to $NEW_VERSION"

# Create git tag
git tag -a "v$NEW_VERSION" -m "Release version $NEW_VERSION"

echo ""
echo "✅ Version bumped to $NEW_VERSION"
echo ""
echo "Next steps:"
echo "1. Push changes:  git push"
echo "2. Push tag:      git push origin v$NEW_VERSION"
echo ""
echo "The GitHub Action will automatically publish to PyPI when the tag is pushed!"
