# Publishing Guide

## PyPI (pip install)

### One-time Setup

1. **Create PyPI account**: https://pypi.org/account/register/
2. **Generate API token**: https://pypi.org/manage/account/token/
3. **Add to GitHub Secrets**: 
   - Go to repo Settings → Secrets → Actions
   - Add `PYPI_API_TOKEN` with your token

### Publishing

**Option 1: Automatic (via GitHub Release)**
```bash
# Create a git tag and release
git tag v0.1.0
git push origin v0.1.0

# Go to GitHub → Releases → Create new release
# Select tag v0.1.0
# Publish release
# GitHub Actions will automatically publish to PyPI
```

**Option 2: Manual**
```bash
cd cli

# Install tools
pip install build twine

# Build
python -m build

# Upload to PyPI
python -m twine upload dist/*
# Enter your PyPI username and password/token
```

### Users Install
```bash
pip install mcpgw
mcpgw --help
```

---

## Homebrew (brew install)

### One-time Setup

1. **Fork homebrew-core**: https://github.com/Homebrew/homebrew-core
2. **Or create your own tap** (easier):
   ```bash
   # Create tap repository
   gh repo create homebrew-tap --public
   ```

### Publishing to Your Own Tap

```bash
# 1. First publish to PyPI (see above)

# 2. Get SHA256 of published package
curl -sL https://pypi.org/pypi/mcpgw/json | jq -r '.urls[] | select(.packagetype=="sdist") | .digests.sha256'

# 3. Update mcpgw.rb with the SHA256
# Edit line 7: sha256 "REPLACE_WITH_ACTUAL_SHA256"

# 4. Create homebrew-tap repo and add formula
mkdir -p homebrew-tap/Formula
cp cli/mcpgw.rb homebrew-tap/Formula/
cd homebrew-tap
git add Formula/mcpgw.rb
git commit -m "Add mcpgw formula"
git push origin main
```

### Users Install from Your Tap
```bash
# Add your tap
brew tap orangefennec/tap

# Install
brew install mcpgw

# Use
mcpgw --help
```

### Publishing to Official Homebrew (Advanced)

After your tool is stable and has some users:

```bash
# 1. Ensure package is on PyPI
# 2. Fork homebrew-core
# 3. Add Formula/mcpgw.rb
# 4. Submit PR to homebrew-core
# 5. Wait for review and merge
```

Then users can install with just:
```bash
brew install mcpgw
```

---

## Distribution Methods Summary

| Method | Command | Ease | Reach |
|--------|---------|------|-------|
| **PyPI** | `pip install mcpgw` | Easy | Global |
| **Your Homebrew Tap** | `brew tap orangefennec/tap && brew install mcpgw` | Medium | Mac/Linux |
| **Official Homebrew** | `brew install mcpgw` | Hard | Mac/Linux (high trust) |
| **GitHub Release** | `pip install https://github.com/...` | Easy | Manual |

---

## Quick Start Checklist

- [ ] Publish to PyPI (via GitHub Actions or manual)
- [ ] Create homebrew-tap repository
- [ ] Update mcpgw.rb with correct SHA256
- [ ] Push formula to homebrew-tap
- [ ] Test installation: `brew tap orangefennec/tap && brew install mcpgw`
- [ ] Update main README with installation instructions

---

## Testing Before Publishing

```bash
# Test PyPI build
cd cli
python -m build
pip install dist/mcpgw-0.1.0-py3-none-any.whl
mcpgw --help

# Test Homebrew formula locally
brew install --build-from-source ./cli/mcpgw.rb
```
