# MCP Gateway CLI - Publishing Checklist

## ✅ What's Ready

### Installation Methods
1. **✅ Curl Installer** (`install.sh`)
   - One-liner: `curl -fsSL https://get.mcpgw.io | sh`
   - Auto-detects platform (macOS/Linux)
   - Sets up shell aliases (`mg` = `mcpgw`)
   - Validates Python 3.9+

2. **✅ Homebrew Formula** (`mcpgw.rb`)
   - Complete formula with all dependencies
   - Shell completion support
   - Post-install caveats

3. **✅ PyPI Package** (ready to publish)
   - `pyproject.toml` configured
   - `setup.py` configured  
   - README.md with badges

4. **✅ Release Script** (`publish-release.sh`)
   - Automated PyPI publishing
   - Homebrew formula SHA256 updates
   - Git tagging

---

## 📋 Publishing Steps

### 1. Publish to PyPI (First Time)

```bash
cd cli/

# Create PyPI account at https://pypi.org/account/register/
# Create API token at https://pypi.org/manage/account/token/

# Set credentials
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-xxxxx  # Your API token

# Run release script
./publish-release.sh 0.1.0
```

### 2. Create Homebrew Tap

```bash
# Create GitHub repo: orangefennec/homebrew-mcpgw
gh repo create orangefennec/homebrew-mcpgw --public

# Clone and setup
git clone https://github.com/orangefennec/homebrew-mcpgw.git
cd homebrew-mcpgw

# Copy formula
cp ../mcp-gateway/cli/mcpgw.rb Formula/mcpgw.rb

# Commit
git add Formula/mcpgw.rb
git commit -m "Add mcpgw formula"
git push
```

Then users install with:
```bash
brew tap orangefennec/mcpgw
brew install mcpgw
```

### 3. Host install.sh on get.mcpgw.io

**Option A: GitHub Pages**
```bash
# In orangefennec/homebrew-mcpgw repo
cp ../mcp-gateway/cli/install.sh .
echo "get.mcpgw.io" > CNAME

git add install.sh CNAME
git commit -m "Add install script"
git push

# Enable GitHub Pages in repo settings pointing to main branch
# Add CNAME record: get.mcpgw.io -> orangefennec.github.io/homebrew-mcpgw
```

**Option B: Cloudflare Pages**
```bash
# Upload install.sh to Cloudflare Pages
# Point get.mcpgw.io -> Pages deployment
```

**Option C: Simple redirect**
Point `get.mcpgw.io` to `https://raw.githubusercontent.com/orangefennec/mcp-gateway/main/cli/install.sh`

---

## 🎯 Next Steps (Priority Order)

### Week 1: Minimum Viable CLI

#### Day 1-2: Implement Core Commands
- [ ] `mcpgw add <backend>` - Add from marketplace
- [ ] `mcpgw list` - List enabled backends
- [ ] `mcpgw generate` - Generate claude_desktop_config.json
- [ ] `mcpgw quickstart` - Interactive wizard

#### Day 3: Test & Polish
- [ ] Test install script on clean machine
- [ ] Test full workflow end-to-end
- [ ] Add error handling and helpful messages

#### Day 4-5: Publish v0.1.0
- [ ] Publish to PyPI
- [ ] Create Homebrew tap
- [ ] Setup get.mcpgw.io redirect
- [ ] Test all installation methods

### Week 2: Documentation & Marketing

- [ ] Update docs.mcpgw.io with CLI guide
- [ ] Create video walkthrough (30-60 sec)
- [ ] Blog post: "Get started with MCP Gateway in 60 seconds"
- [ ] Tweet announcement with terminal recording
- [ ] Post to r/ClaudeAI, HackerNews

### Week 3: Sample Scripts & Templates

Create in `/examples/quickstart/`:
- [ ] `github-assistant.sh` - GitHub + Linear + Slack
- [ ] `data-analyst.sh` - Postgres + Python + Files
- [ ] `customer-support.sh` - Zendesk + Gmail + Notion

---

## 📦 Package Versions

### Current
- **mcpgw**: 0.1.0 (not published yet)

### Dependencies
- click >= 8.0.0
- requests >= 2.25.0

### Python Support
- 3.9+
- 3.10, 3.11, 3.12 tested

---

## 🔗 URLs to Setup

1. **PyPI Package**: https://pypi.org/project/mcpgw/
2. **Homebrew Tap**: https://github.com/orangefennec/homebrew-mcpgw
3. **Install Script**: https://get.mcpgw.io
4. **Docs**: https://docs.mcpgw.io/cli
5. **GitHub Release**: https://github.com/orangefennec/mcp-gateway/releases

---

## 📊 Success Metrics

### Week 1
- [ ] 10 PyPI downloads
- [ ] 5 GitHub stars
- [ ] 3 successful user installs

### Month 1
- [ ] 100 PyPI downloads
- [ ] 50 GitHub stars
- [ ] 10 paying customers (free trial → paid)

### Month 3
- [ ] 1000 PyPI downloads
- [ ] 200 GitHub stars
- [ ] 50 paying customers
- [ ] Featured in Anthropic community

---

## 🚨 Pre-Launch Checklist

Before running `./publish-release.sh 0.1.0`:

- [ ] Test CLI locally: `pip install -e . && mcpgw --help`
- [ ] Test auth flow: `mcpgw auth login`
- [ ] Test workspace commands
- [ ] Update version in pyproject.toml and setup.py
- [ ] Update CHANGELOG.md
- [ ] Create PyPI account and API token
- [ ] Test Homebrew formula locally
- [ ] Prepare announcement tweet/post
- [ ] Update marketing site with CLI info

---

## 💡 Marketing Copy

### Tweet
```
🚀 MCP Gateway CLI is here!

Get Claude Desktop enterprise-ready in 60 seconds:

curl -fsSL https://get.mcpgw.io | sh
mcpgw quickstart

✅ PII redaction
✅ Audit logs  
✅ Team access
✅ Rate limits

Built for teams who want Claude but need security first.
```

### HackerNews
```
Show HN: MCP Gateway CLI - Enterprise MCP in 60 seconds

We built a CLI to make it dead simple to add security, audit trails,
and team management to Claude Desktop's Model Context Protocol.

One-liner install, then `mcpgw quickstart` walks you through:
- Adding GitHub/Slack/etc MCP servers
- Configuring PII redaction
- Generating secure Claude configs

Perfect for teams where security blocked Claude Desktop adoption.

pip install mcpgw
```

---

**Status**: Ready to ship! 🎉

Just need to implement the core commands (`add`, `list`, `generate`, `quickstart`) and publish.
