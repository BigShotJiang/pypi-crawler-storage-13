#!/bin/bash
set -e

echo "🧪 Testing Local Installation"
echo ""

cd "$(dirname "$0")"

# Test installing from local wheel
echo "1️⃣ Creating test environment..."
python3 -m venv test-env
source test-env/bin/activate

echo "2️⃣ Installing from wheel..."
pip install -q dist/mcpgw-0.1.0-py3-none-any.whl

echo "3️⃣ Testing CLI..."
mcpgw --help

echo ""
echo "4️⃣ Testing commands..."
mcpgw auth --help
mcpgw workspace --help
mcpgw backend --help

echo ""
echo "✅ Local installation works!"
echo ""
echo "To test manually:"
echo "  source test-env/bin/activate"
echo "  mcpgw --help"
echo ""
echo "To cleanup:"
echo "  deactivate"
echo "  rm -rf test-env"
