#!/bin/bash
set -e

# MCP Gateway CLI Release Script
# Publishes to PyPI and updates Homebrew formula

VERSION="${1:-}"
if [ -z "$VERSION" ]; then
    echo "Usage: ./publish-release.sh <version>"
    echo "Example: ./publish-release.sh 0.1.1"
    exit 1
fi

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}═══════════════════════════════════════${NC}"
echo -e "${BLUE}  MCP Gateway CLI Release v${VERSION}${NC}"
echo -e "${BLUE}═══════════════════════════════════════${NC}"
echo ""

# Step 1: Update version in files
echo -e "${BLUE}[1/6]${NC} Updating version in pyproject.toml and setup.py..."
sed -i.bak "s/version = \".*\"/version = \"${VERSION}\"/" pyproject.toml
sed -i.bak "s/version=\".*\"/version=\"${VERSION}\"/" setup.py
rm -f pyproject.toml.bak setup.py.bak
echo -e "${GREEN}✓${NC} Version updated to ${VERSION}"

# Step 2: Clean previous builds
echo -e "${BLUE}[2/6]${NC} Cleaning previous builds..."
rm -rf dist/ build/ *.egg-info
echo -e "${GREEN}✓${NC} Cleaned"

# Step 3: Build package
echo -e "${BLUE}[3/6]${NC} Building Python package..."
python3 -m pip install --upgrade build twine
python3 -m build
echo -e "${GREEN}✓${NC} Package built"

# Step 4: Upload to PyPI
echo -e "${BLUE}[4/6]${NC} Uploading to PyPI..."
echo -e "${YELLOW}Note:${NC} Make sure TWINE_USERNAME and TWINE_PASSWORD are set"
python3 -m twine upload dist/*
echo -e "${GREEN}✓${NC} Uploaded to PyPI"

# Step 5: Calculate SHA256 for Homebrew formula
echo -e "${BLUE}[5/6]${NC} Calculating SHA256 for Homebrew..."
TARBALL="dist/mcpgw-${VERSION}.tar.gz"
if [ -f "$TARBALL" ]; then
    SHA256=$(shasum -a 256 "$TARBALL" | awk '{print $1}')
    echo -e "${GREEN}✓${NC} SHA256: ${SHA256}"
    
    # Update Homebrew formula
    sed -i.bak "s|url \".*\"|url \"https://files.pythonhosted.org/packages/source/m/mcpgw/mcpgw-${VERSION}.tar.gz\"|" mcpgw.rb
    sed -i.bak "s/sha256 \".*\"/sha256 \"${SHA256}\"/" mcpgw.rb
    rm -f mcpgw.rb.bak
    echo -e "${GREEN}✓${NC} Homebrew formula updated"
else
    echo -e "${YELLOW}⚠${NC}  Tarball not found, skipping SHA256 update"
fi

# Step 6: Create git tag
echo -e "${BLUE}[6/6]${NC} Creating git tag..."
git add pyproject.toml setup.py mcpgw.rb
git commit -m "Release v${VERSION}"
git tag -a "v${VERSION}" -m "Release v${VERSION}"
echo -e "${GREEN}✓${NC} Git tag created"

echo ""
echo -e "${GREEN}═══════════════════════════════════════${NC}"
echo -e "${GREEN}  Release v${VERSION} Complete!${NC}"
echo -e "${GREEN}═══════════════════════════════════════${NC}"
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo -e "  1. Push to GitHub: ${BLUE}git push && git push --tags${NC}"
echo -e "  2. Test PyPI install: ${BLUE}pip install mcpgw==${VERSION}${NC}"
echo -e "  3. Create GitHub release at: https://github.com/orangefennec/mcp-gateway/releases/new"
echo -e "  4. Update Homebrew tap (if you have one): Push mcpgw.rb to tap repo"
echo ""
echo -e "${YELLOW}Installation commands:${NC}"
echo -e "  pip:  ${BLUE}pip install mcpgw${NC}"
echo -e "  brew: ${BLUE}brew install mcpgw${NC} (after tap setup)"
echo -e "  curl: ${BLUE}curl -fsSL https://get.mcpgw.io | sh${NC}"
echo ""
