"""Resource classes for MCP Gateway API endpoints."""

from typing import Dict, Any, List, Optional


class BaseResource:
    """Base class for API resources."""
    
    def __init__(self, client):
        self.client = client


class WorkspaceResource(BaseResource):
    """Workspace management operations."""
    
    def list(self, **params) -> List[Dict[str, Any]]:
        """
        List all workspaces.
        
        Returns:
            List of workspace dictionaries
        """
        return self.client.request('GET', '/workspaces', params=params)
    
    def get(self, workspace_id: str) -> Dict[str, Any]:
        """
        Get a specific workspace.
        
        Args:
            workspace_id: Workspace ID
            
        Returns:
            Workspace dictionary
        """
        return self.client.request('GET', f'/workspaces/{workspace_id}')
    
    def create(self, name: str, description: str = None, **kwargs) -> Dict[str, Any]:
        """
        Create a new workspace.
        
        Args:
            name: Workspace name
            description: Workspace description
            **kwargs: Additional workspace properties
            
        Returns:
            Created workspace dictionary
        """
        data = {'name': name, **kwargs}
        if description:
            data['description'] = description
        
        return self.client.request('POST', '/workspaces', json=data)
    
    def update(self, workspace_id: str, **kwargs) -> Dict[str, Any]:
        """
        Update a workspace.
        
        Args:
            workspace_id: Workspace ID
            **kwargs: Fields to update
            
        Returns:
            Updated workspace dictionary
        """
        return self.client.request('PUT', f'/workspaces/{workspace_id}', json=kwargs)
    
    def delete(self, workspace_id: str) -> Dict[str, Any]:
        """
        Delete a workspace.
        
        Args:
            workspace_id: Workspace ID
            
        Returns:
            Deletion response
        """
        return self.client.request('DELETE', f'/workspaces/{workspace_id}')


class BackendResource(BaseResource):
    """Backend management operations."""
    
    def list(self, workspace_id: str, **params) -> List[Dict[str, Any]]:
        """
        List backends in a workspace.
        
        Args:
            workspace_id: Workspace ID
            
        Returns:
            List of backend dictionaries
        """
        return self.client.request('GET', f'/workspaces/{workspace_id}/backends', params=params)
    
    def get(self, workspace_id: str, backend_id: str) -> Dict[str, Any]:
        """
        Get a specific backend.
        
        Args:
            workspace_id: Workspace ID
            backend_id: Backend ID
            
        Returns:
            Backend dictionary
        """
        return self.client.request('GET', f'/workspaces/{workspace_id}/backends/{backend_id}')
    
    def add(
        self,
        workspace_id: str,
        name: str,
        url: str,
        description: str = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Add a backend to a workspace.
        
        Args:
            workspace_id: Workspace ID
            name: Backend name
            url: Backend URL
            description: Backend description
            **kwargs: Additional backend properties
            
        Returns:
            Created backend dictionary
        """
        data = {'name': name, 'url': url, **kwargs}
        if description:
            data['description'] = description
        
        return self.client.request('POST', f'/workspaces/{workspace_id}/backends', json=data)
    
    def update(self, workspace_id: str, backend_id: str, **kwargs) -> Dict[str, Any]:
        """
        Update a backend.
        
        Args:
            workspace_id: Workspace ID
            backend_id: Backend ID
            **kwargs: Fields to update
            
        Returns:
            Updated backend dictionary
        """
        return self.client.request(
            'PUT',
            f'/workspaces/{workspace_id}/backends/{backend_id}',
            json=kwargs
        )
    
    def remove(self, workspace_id: str, backend_id: str) -> Dict[str, Any]:
        """
        Remove a backend from a workspace.
        
        Args:
            workspace_id: Workspace ID
            backend_id: Backend ID
            
        Returns:
            Deletion response
        """
        return self.client.request('DELETE', f'/workspaces/{workspace_id}/backends/{backend_id}')


class AgentResource(BaseResource):
    """Agent management operations."""
    
    def list(self, workspace_id: str, **params) -> List[Dict[str, Any]]:
        """
        List agents in a workspace.
        
        Args:
            workspace_id: Workspace ID
            
        Returns:
            List of agent dictionaries
        """
        return self.client.request('GET', f'/workspaces/{workspace_id}/agents', params=params)
    
    def get(self, workspace_id: str, agent_id: str) -> Dict[str, Any]:
        """
        Get a specific agent.
        
        Args:
            workspace_id: Workspace ID
            agent_id: Agent ID
            
        Returns:
            Agent dictionary
        """
        return self.client.request('GET', f'/workspaces/{workspace_id}/agents/{agent_id}')
    
    def create(
        self,
        workspace_id: str,
        name: str,
        description: str = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Create an agent in a workspace.
        
        Args:
            workspace_id: Workspace ID
            name: Agent name
            description: Agent description
            **kwargs: Additional agent properties
            
        Returns:
            Created agent dictionary (includes API key)
        """
        data = {'name': name, **kwargs}
        if description:
            data['description'] = description
        
        return self.client.request('POST', f'/workspaces/{workspace_id}/agents', json=data)
    
    def update(self, workspace_id: str, agent_id: str, **kwargs) -> Dict[str, Any]:
        """
        Update an agent.
        
        Args:
            workspace_id: Workspace ID
            agent_id: Agent ID
            **kwargs: Fields to update
            
        Returns:
            Updated agent dictionary
        """
        return self.client.request(
            'PUT',
            f'/workspaces/{workspace_id}/agents/{agent_id}',
            json=kwargs
        )
    
    def delete(self, workspace_id: str, agent_id: str) -> Dict[str, Any]:
        """
        Delete an agent.
        
        Args:
            workspace_id: Workspace ID
            agent_id: Agent ID
            
        Returns:
            Deletion response
        """
        return self.client.request('DELETE', f'/workspaces/{workspace_id}/agents/{agent_id}')


class CatalogResource(BaseResource):
    """Backend catalog operations."""
    
    def list(self, category: Optional[str] = None, **params) -> List[Dict[str, Any]]:
        """
        List available backends in the catalog.
        
        Args:
            category: Optional category filter
            
        Returns:
            List of catalog backend dictionaries
        """
        if category:
            params['category'] = category
        
        return self.client.request('GET', '/catalog/backends', params=params)
    
    def get(self, backend_id: str) -> Dict[str, Any]:
        """
        Get details of a catalog backend.
        
        Args:
            backend_id: Backend ID
            
        Returns:
            Catalog backend dictionary
        """
        return self.client.request('GET', f'/catalog/backends/{backend_id}')
    
    def enable(self, workspace_id: str, backend_id: str, **kwargs) -> Dict[str, Any]:
        """
        Enable a catalog backend for a workspace.
        
        Args:
            workspace_id: Workspace ID
            backend_id: Catalog backend ID
            **kwargs: Additional configuration
            
        Returns:
            Enabled backend dictionary
        """
        return self.client.request(
            'POST',
            f'/workspaces/{workspace_id}/catalog/{backend_id}/enable',
            json=kwargs
        )
