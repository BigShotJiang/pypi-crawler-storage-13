"""
of-mcp: MCP Gateway CLI and Python SDK

Command-line interface and Python SDK for managing MCP Gateway workspaces, backends, and agents.

CLI Usage:
    $ mcpgw auth login
    $ mcpgw workspace list
    $ mcpgw backend add WORKSPACE_ID --name Gmail --url http://...

SDK Usage:
    >>> from of_mcp import MCPGatewayClient
    >>> client = MCPGatewayClient(token="your-token")
    >>> workspaces = client.workspaces.list()
    >>> workspace = client.workspaces.create(name="Production")
"""

from .client import MCPGatewayClient
from .resources import WorkspaceResource, BackendResource, AgentResource, CatalogResource
from .exceptions import MCPGatewayError, AuthenticationError, NotFoundError, ValidationError, APIError

__version__ = "0.1.2"

__all__ = [
    'MCPGatewayClient',
    'WorkspaceResource',
    'BackendResource', 
    'AgentResource',
    'CatalogResource',
    'MCPGatewayError',
    'AuthenticationError',
    'NotFoundError',
    'ValidationError',
    'APIError',
]
