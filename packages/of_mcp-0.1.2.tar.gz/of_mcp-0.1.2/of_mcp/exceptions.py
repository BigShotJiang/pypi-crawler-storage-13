"""Custom exceptions for the MCP Gateway SDK."""


class MCPGatewayError(Exception):
    """Base exception for MCP Gateway SDK errors."""
    pass


class AuthenticationError(MCPGatewayError):
    """Raised when authentication fails."""
    pass


class NotFoundError(MCPGatewayError):
    """Raised when a resource is not found."""
    pass


class ValidationError(MCPGatewayError):
    """Raised when input validation fails."""
    pass


class APIError(MCPGatewayError):
    """Raised when the API returns an error."""
    
    def __init__(self, message, status_code=None, response=None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response
