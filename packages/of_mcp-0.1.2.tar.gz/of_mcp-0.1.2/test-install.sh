#!/bin/bash
set -e

echo "🧪 Testing MCP Gateway CLI Installation"
echo ""

cd "$(dirname "$0")"

# Test 1: Build package
echo "1️⃣ Testing package build..."
python -m build
echo "   ✅ Build successful"
echo ""

# Test 2: Install in virtual env
echo "2️⃣ Testing installation..."
python -m venv test-env
source test-env/bin/activate
pip install -q dist/*.whl
echo "   ✅ Installation successful"
echo ""

# Test 3: Run CLI
echo "3️⃣ Testing CLI execution..."
mcpgw --help > /dev/null
echo "   ✅ CLI works"
echo ""

# Test 4: Check commands
echo "4️⃣ Testing commands..."
mcpgw auth --help > /dev/null
mcpgw workspace --help > /dev/null
mcpgw backend --help > /dev/null
mcpgw agent --help > /dev/null
mcpgw catalog --help > /dev/null
echo "   ✅ All commands available"
echo ""

# Cleanup
deactivate
rm -rf test-env
echo "🎉 All tests passed!"
echo ""
echo "Ready to publish!"
