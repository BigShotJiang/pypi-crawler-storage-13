from enum import Enum
from typing import Any, Literal
from uuid import UUID

from pydantic import Field

from .enums import StrategyType
from .model import CustomBaseModel


MODIFY_SENTINEL = "*"


class CommandType(str, Enum):
    NEW_ORDER = "new_order"
    CANCEL_ORDER = "cancel_order"
    MODIFY_ORDER = "modify_order"
    NEW_INSTRUMENT = "new_instrument"


class Command(CustomBaseModel):
    type: CommandType
    data: Any


class NewOrderCommand(CustomBaseModel):
    type: Literal[CommandType.NEW_ORDER] = CommandType.NEW_ORDER
    strategy_type: StrategyType
    data: Any
    instrument_id: str


class NewSingleOrder(CustomBaseModel):
    order: dict


class NewOCOOrder(CustomBaseModel):
    legs: list[dict] = Field(max_length=2)


class NewOTOOrder(CustomBaseModel):
    parent: dict
    child: dict


class NewOTOCOOrder(CustomBaseModel):
    parent: dict
    oco_legs: list[dict] = Field(max_length=2)


class c(CustomBaseModel):
    order_id: UUID
    symbol: str


class ModifyOrderCommand(CustomBaseModel):
    order_id: str
    symbol: str
    limit_price: float | None = None
    stop_price: float | None = None


class NewInstrumentCommand(CustomBaseModel):
    instrument_id: str
