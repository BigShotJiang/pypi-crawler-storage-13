from typing import Literal

from .enums import TradeEventType
from ..model import CustomBaseModel


class NewTradeEvent(CustomBaseModel):
    type: Literal[TradeEventType.NEW_TRADE] = TradeEventType.NEW_TRADE
