"""
INTEGRATE Plotting Module - Visualization and Analysis Tools

This module provides comprehensive visualization capabilities for the INTEGRATE
geophysical data integration package. It creates publication-quality plots for
data analysis, prior/posterior visualization, and results interpretation.

Key Features:
    - 1D profile plots for layered earth models
    - 2D spatial mapping and interpolation
    - Data-model comparison visualizations
    - Statistical plots (uncertainty, probability maps)
    - Geometry and survey layout visualization
    - Customizable plotting styles and colormaps

Main Function Categories:
    - plot_profile_*(): 1D vertical profile plotting
    - plot_data_*(): Observational data visualization
    - plot_geometry(): Survey geometry and layout
    - plot_feature_2d(): 2D spatial parameter mapping
    - plot_T_EV(): Temperature and evidence visualization
    - plot_*_stats(): Statistical analysis plots

Plot Types:
    - Discrete categorical models (geological units)
    - Continuous parameter models (resistivity, conductivity)
    - Uncertainty and probability distributions
    - Data fit and residual analysis
    - Cumulative thickness and property maps

Output Formats:
    - Interactive matplotlib figures
    - High-resolution PNG/PDF export
    - Customizable figure sizing and DPI

Author: Thomas Mejer Hansen
Email: tmeha@geo.au.dk
"""

import os
import numpy as np
import h5py
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from integrate.integrate import integrate_posterior_stats
from integrate.integrate_io import get_geometry, get_number_of_data
from integrate.integrate import posterior_cumulative_thickness


def get_colormap_and_limits(cmap_type='default', custom_clim=None):
    """
    Return colormap and associated limits for different visualization types.

    Creates various colormaps and their associated color limits for different
    geophysical data visualization needs, with a focus on resistivity and
    electromagnetic data plotting.

    Parameters
    ----------
    cmap_type : str, optional
        Type of colormap to return (default is 'default'):
        - 'default': Red-white-blue-black colormap for general use
        - 'resistivity': Log-scale colormap optimized for resistivity data
        - 'entropy': Grayscale colormap for uncertainty visualization
        - 'discrete': Categorical colormap for discrete classifications
        - 'temperature': Hot colormap for temperature/evidence fields
        - 'elevation': Terrain-like colormap for topographic data
        - 'seismic': Blue-white-red colormap for seismic data
    custom_clim : list or tuple, optional
        Custom color limits as [min, max]. If provided, overrides default
        limits for the specified colormap type (default is None).

    Returns
    -------
    cmap : matplotlib.colors.Colormap
        The colormap object ready for use in matplotlib plotting functions.
    clim : list
        Color scale limits as [min, max] values appropriate for the colormap.

    Notes
    -----
    Default colormap creates a smooth transition: red (low) → white (medium)
    → blue (high) → black (very high), which is effective for resistivity
    visualization where extreme values need emphasis.

    Examples
    --------
    >>> cmap, clim = get_colormap_and_limits('default')
    >>> # Use with matplotlib: plt.imshow(data, cmap=cmap, vmin=clim[0], vmax=clim[1])

    >>> cmap, clim = get_colormap_and_limits('resistivity', custom_clim=[10, 1000])
    >>> # Custom limits override defaults for resistivity colormap
    """

    if cmap_type == 'default':
        # Red to white to blue to black colormap
        colors = ['red', 'white', 'blue', 'black']
        n_bins = 256
        cmap = LinearSegmentedColormap.from_list('default', colors, N=n_bins)
        clim = [1, 2600]

    elif cmap_type == 'resistivity':
        # Hardcoded resistivity colormap extracted from Daugaard HDF5 file
        # Original source: daugaard_valley_new_N1000000_dmax90_TX07_20231016_2x4_RC20-33_Nh280_Nf12.h5
        # Shape: (3, 443) - RGB channels with 443 color entries
        # From GEUS
        resistivity_cmap_array = np.array([
    # Red channel
    [0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.004178, 0.004484, 0.004797, 0.005117, 0.005444, 0.005779, 0.006122, 0.006473, 0.006832, 0.007199, 0.007575, 0.007662, 0.007259, 0.006847, 0.006425, 0.005993, 0.005552, 0.005100, 0.004637, 0.004164, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.017649, 0.105370, 0.195134, 0.286988, 0.380983, 0.477166, 0.575590, 0.614686, 0.644298, 0.674600, 0.705608, 0.737337, 0.769806, 0.803031, 0.830849, 0.848855, 0.867281, 0.886135, 0.905429, 0.925172, 0.945375, 0.966048, 0.987203, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 0.999405, 0.995215, 0.990927, 0.986539, 0.982049, 0.977455, 0.972753, 0.967942, 0.963019, 0.957981, 0.952826, 0.944180, 0.927868, 0.911177, 0.894097, 0.876619, 0.858733, 0.840432, 0.821704, 0.802539, 0.786885, 0.774726, 0.762284, 0.749552, 0.736523, 0.723191, 0.709548, 0.695588, 0.681302, 0.666684, 0.652006, 0.643651, 0.635101, 0.626352, 0.617399, 0.608238, 0.598863, 0.589270, 0.579454, 0.569409, 0.559130, 0.548611, 0.537848, 0.526834, 0.515563, 0.504029, 0.502916, 0.501892, 0.500844, 0.499772, 0.498675, 0.497552, 0.496403, 0.495228, 0.494025, 0.492794, 0.491534, 0.490245, 0.488926, 0.487576, 0.486195, 0.484781, 0.483335, 0.481855, 0.480340, 0.478791, 0.477205, 0.475582, 0.473921, 0.472222, 0.470483, 0.468704, 0.466883, 0.465020, 0.463113, 0.461162, 0.459672, 0.458212, 0.456719, 0.455190, 0.453626, 0.452026, 0.450388, 0.448713, 0.446998, 0.445243, 0.443448, 0.441610, 0.439730, 0.437806, 0.435837, 0.433823, 0.431761, 0.429651, 0.427493, 0.425284, 0.423023, 0.420710, 0.418343, 0.415921, 0.413442, 0.410906, 0.408310, 0.405654, 0.402937, 0.400156, 0.397310, 0.394531, 0.394531, 0.394531, 0.394531, 0.394531, 0.394531, 0.394531, 0.394531, 0.394531, 0.394531, 0.394531, 0.394531],
    # Green channel
    [0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.005996, 0.010486, 0.015081, 0.019783, 0.024595, 0.029518, 0.034556, 0.039712, 0.044988, 0.050386, 0.055911, 0.061564, 0.067348, 0.073268, 0.079325, 0.085524, 0.091866, 0.098357, 0.104999, 0.111795, 0.118750, 0.125866, 0.133149, 0.140601, 0.148227, 0.156030, 0.164015, 0.172186, 0.180548, 0.189104, 0.197859, 0.202732, 0.206970, 0.211307, 0.215745, 0.220286, 0.224933, 0.229688, 0.234554, 0.239534, 0.244629, 0.249843, 0.255178, 0.260638, 0.266225, 0.271942, 0.277792, 0.283779, 0.289905, 0.296173, 0.302588, 0.309152, 0.315869, 0.322743, 0.329776, 0.336973, 0.344338, 0.351875, 0.359086, 0.366018, 0.373112, 0.380371, 0.387799, 0.395400, 0.403178, 0.411137, 0.419281, 0.427615, 0.436144, 0.444871, 0.453801, 0.462939, 0.472291, 0.481860, 0.491651, 0.501671, 0.511925, 0.522417, 0.533154, 0.544140, 0.554678, 0.564420, 0.574389, 0.584590, 0.595029, 0.605711, 0.616642, 0.627827, 0.639273, 0.650986, 0.662971, 0.675236, 0.687786, 0.700629, 0.713770, 0.727218, 0.740979, 0.750365, 0.757228, 0.764251, 0.771438, 0.778792, 0.786318, 0.794018, 0.801898, 0.809962, 0.818214, 0.826657, 0.835298, 0.844139, 0.853187, 0.862445, 0.872810, 0.883504, 0.894447, 0.905645, 0.917104, 0.928830, 0.940829, 0.953107, 0.965672, 0.978529, 0.991685, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 0.987917, 0.957677, 0.926732, 0.895066, 0.862663, 0.829505, 0.795575, 0.760854, 0.725325, 0.694938, 0.667846, 0.640122, 0.611752, 0.582721, 0.553015, 0.522616, 0.491509, 0.459678, 0.422602, 0.383502, 0.343492, 0.302549, 0.260653, 0.217780, 0.173910, 0.129017, 0.083079, 0.036070, 0.006763, 0.015584, 0.024611, 0.033849, 0.043301, 0.052974, 0.062872, 0.073000, 0.083365, 0.093971, 0.104824, 0.118996, 0.143518, 0.168611, 0.194289, 0.220565, 0.247453, 0.274967, 0.303123, 0.331934, 0.361416, 0.391585, 0.413115, 0.378949, 0.343987, 0.308210, 0.271600, 0.234138, 0.195802, 0.156574, 0.116432, 0.075355, 0.033321, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906],
    # Blue channel
    [0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.570312, 0.571016, 0.571970, 0.572948, 0.573947, 0.574971, 0.576018, 0.577089, 0.578185, 0.579307, 0.580455, 0.581630, 0.582832, 0.584063, 0.585321, 0.586609, 0.587928, 0.589276, 0.590657, 0.592069, 0.593514, 0.594993, 0.596507, 0.598055, 0.599640, 0.601262, 0.602921, 0.604619, 0.606357, 0.608135, 0.609955, 0.611817, 0.613722, 0.615671, 0.617667, 0.619708, 0.621797, 0.623935, 0.626123, 0.628361, 0.630652, 0.632996, 0.635394, 0.637849, 0.640360, 0.642931, 0.645561, 0.648252, 0.651006, 0.653824, 0.656708, 0.659659, 0.662678, 0.665768, 0.668930, 0.672166, 0.675477, 0.678865, 0.682332, 0.685880, 0.689510, 0.693225, 0.697027, 0.700917, 0.704898, 0.708703, 0.712295, 0.715971, 0.719733, 0.723582, 0.727521, 0.731551, 0.735676, 0.739896, 0.744215, 0.748635, 0.753157, 0.757785, 0.762521, 0.767366, 0.772325, 0.777399, 0.782592, 0.787905, 0.793342, 0.798906, 0.804599, 0.810425, 0.816387, 0.822488, 0.828730, 0.835118, 0.841655, 0.848344, 0.855189, 0.862194, 0.865477, 0.868126, 0.870836, 0.873610, 0.876448, 0.879353, 0.882325, 0.885366, 0.888478, 0.891663, 0.894921, 0.898256, 0.901668, 0.905160, 0.908733, 0.912390, 0.916131, 0.919960, 0.923878, 0.927887, 0.931990, 0.936188, 0.940484, 0.944880, 0.949378, 0.953981, 0.958691, 0.961661, 0.963047, 0.964466, 0.965918, 0.967403, 0.968924, 0.970479, 0.972071, 0.973700, 0.975367, 0.977073, 0.978818, 0.980604, 0.982432, 0.984302, 0.986216, 0.988174, 0.990178, 0.992229, 0.994327, 0.996474, 0.998672, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 1.000000, 0.984193, 0.941895, 0.898611, 0.854319, 0.808996, 0.762617, 0.715157, 0.666592, 0.616896, 0.555634, 0.480842, 0.404307, 0.325989, 0.245847, 0.163838, 0.079919, 0.007721, 0.007136, 0.006538, 0.005925, 0.005299, 0.004657, 0.004001, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.004054, 0.004454, 0.004863, 0.005282, 0.005711, 0.006150, 0.006599, 0.007058, 0.007528, 0.007649, 0.007241, 0.006822, 0.006394, 0.005957, 0.005509, 0.005050, 0.004581, 0.004101, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.003906, 0.004172, 0.004512, 0.004860, 0.005216, 0.005580, 0.005953, 0.006334, 0.006725, 0.007124, 0.007533, 0.022095, 0.066203, 0.111339, 0.157525, 0.204788, 0.253151, 0.302641, 0.353284, 0.405106, 0.458135, 0.512400, 0.563039, 0.598879, 0.635554, 0.673084, 0.711487, 0.750785, 0.790998, 0.832148, 0.874256, 0.917346, 0.961439, 0.999405, 0.995215, 0.990927, 0.986539, 0.982049, 0.977455, 0.972753, 0.967942, 0.963019, 0.957981, 0.952826, 0.944180, 0.927868, 0.911177, 0.894097, 0.876619, 0.858733, 0.840432, 0.821704, 0.802539, 0.786885, 0.774726, 0.762284, 0.749552, 0.736523, 0.723191, 0.709548, 0.695588, 0.681302, 0.666684, 0.652006, 0.643651, 0.635101, 0.626352, 0.617399, 0.608238, 0.598863, 0.589270, 0.579454, 0.569409, 0.559130, 0.548611, 0.537848, 0.526834, 0.515563, 0.504029, 0.502916, 0.501892, 0.500844, 0.499772, 0.498675, 0.497552, 0.496403, 0.495228, 0.494025, 0.492794, 0.491534, 0.490245, 0.488926, 0.487576, 0.486195, 0.484781, 0.483335, 0.481855, 0.480340, 0.478791, 0.477205, 0.475582, 0.473921, 0.472222, 0.470483, 0.468704, 0.466883, 0.465020, 0.463113, 0.461162, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938, 0.460938]
])

        from matplotlib.colors import ListedColormap
        cmap = ListedColormap(resistivity_cmap_array.T)
        clim = [0.1, 2600]

    elif cmap_type == 'entropy':
        # Grayscale for uncertainty/entropy
        colors = ['white', 'gray', 'black']
        cmap = LinearSegmentedColormap.from_list('entropy', colors, N=256)
        clim = [0, 1]

    elif cmap_type == 'discrete':
        # Categorical colormap for discrete classifications
        cmap = plt.cm.Set1
        clim = [0.5, 8.5]  # Typical for 8 categories

    elif cmap_type == 'temperature':
        # Hot colormap for temperature/evidence fields
        cmap = plt.cm.hot_r
        clim = [1, 100]

    elif cmap_type == 'elevation':
        # Terrain-like colormap for elevation data
        cmap = plt.cm.terrain
        clim = [0, 100]  # Meters above sea level

    elif cmap_type == 'evidence':
        # XXX
        colors = ['darkblue',  'darkred']
        cmap = LinearSegmentedColormap.from_list('evidence', colors, N=256)
        cmap = plt.cm.magma
        clim = [-60,0]

    elif cmap_type == 'seismic':
        # Blue-white-red for seismic/anomaly data
        colors = ['darkblue', 'blue', 'lightblue', 'white', 'lightcoral', 'red', 'darkred']
        cmap = LinearSegmentedColormap.from_list('seismic', colors, N=256)
        clim = [-1, 1]

    else:
        # Fallback to default if unknown type
        colors = ['red', 'white', 'blue', 'black']
        cmap = LinearSegmentedColormap.from_list('default', colors, N=256)
        clim = [1, 2600]

    # Override with custom limits if provided
    if custom_clim is not None:
        if len(custom_clim) == 2:
            clim = list(custom_clim)
        else:
            raise ValueError("custom_clim must be a list or tuple of length 2 [min, max]")

    return cmap, clim


def plot_posterior_cumulative_thickness(f_post_h5, im=2, icat=[0], property='median', usePrior=False, **kwargs):
    """
    Plot posterior cumulative thickness for specified categories.

    Creates a scatter plot showing the spatial distribution of cumulative thickness
    statistics (median, mean, standard deviation, or relative standard deviation)
    for selected geological categories from posterior sampling results.

    Parameters
    ----------
    f_post_h5 : str
        Path to the HDF5 file containing posterior sampling results.
    im : int, optional
        Model index for thickness calculation (default is 2).
    icat : int or list of int, optional
        Category index or list of category indices to include in thickness calculation
        (default is [0]).
    property : {'median', 'mean', 'std', 'relstd'}, optional
        Statistical property to plot (default is 'median'):
        - 'median': median thickness
        - 'mean': mean thickness  
        - 'std': standard deviation of thickness
        - 'relstd': relative standard deviation (std/median)
    usePrior : bool, optional
        Whether to use prior data instead of posterior data (default is False).
    **kwargs : dict
        Additional keyword arguments:
        - hardcopy : bool, save plot as PNG file (default False)
        - s : float, scatter point size (default 10)

    Returns
    -------
    matplotlib.figure.Figure
        The matplotlib figure object containing the plot.

    Notes
    -----
    The function calls ig.posterior_cumulative_thickness() to compute thickness
    statistics and creates a 2D scatter plot with equal aspect ratio and colorbar.
    Output files are saved with descriptive names when hardcopy=True.
    """

    if isinstance(icat, int):
        icat = np.array([icat])

    out = posterior_cumulative_thickness(f_post_h5, im=2, icat=icat, usePrior=usePrior, **kwargs)
    if not isinstance(out, tuple):
        # Then output failed
        return

    thick_mean = out[0] 
    thick_median = out[1] 
    thick_std = out[2] 
    class_names = out[3] 
    X = out[4] 
    Y = out[5] 

    # set hardcopy to True as kwarg if not already set
    kwargs.setdefault('hardcopy', False)
    kwargs.setdefault('s', 10)
    s = kwargs['s']

    fig = plt.figure(figsize=(8, 8))
    if property == 'median':
        plt.scatter(X, Y, c=thick_median, cmap='jet', s=s)
    elif property == 'mean':
        plt.scatter(X, Y, c=thick_mean, cmap='jet', s=s)
    elif property == 'std':
        plt.scatter(X, Y, c=thick_std, cmap='jet', s=s)
    elif property == 'relstd':
        thick_std_rel = thick_std / thick_median
        plt.scatter(X, Y, c=thick_std_rel, cmap='gray_r', s=s, vmin=0, vmax=2)

    plt.colorbar().set_label('Thickness (m)')
    title_txt = 'Cumulative Thickness - %s - %s ' % (property, class_names)
    if usePrior:
        title_txt = title_txt + ' - Prior'
    plt.title(title_txt)
    plt.grid()
    plt.axis('equal')

    if kwargs['hardcopy']:
        # get filename without extension
        icat_str = '-'.join([str(i) for i in icat])
        f_png = '%s_im%d_ic%s_%s' % (os.path.splitext(f_post_h5)[0], im, icat_str, property)
        if usePrior:
            f_png = f_png + '_prior'
        plt.savefig(f_png + '.png')
        # plt.show()

    return fig

def plot_feature_2d(f_post_h5, key='', i1=1, i2=1e+9, im=1, iz=0, uselog=1, title=None, hardcopy=False, cmap=None, clim=None, **kwargs):
    """
    Create 2D spatial scatter plot of model parameter features.

    Generates a 2D scatter plot showing the spatial distribution of a specific
    model parameter feature from posterior sampling results. Supports both
    logarithmic and linear scaling with customizable colormaps and limits.

    Parameters
    ----------
    f_post_h5 : str
        Path to the HDF5 file containing posterior sampling results.
    key : str, optional
        Dataset key within the model group to plot. If empty string, uses
        the first available key in the model group (default is '').
    i1 : int, optional
        Starting data point index for plotting (1-based indexing, default is 1).
    i2 : float, optional
        Ending data point index for plotting. If larger than data size,
        uses all available data (default is 1e+9).
    im : int, optional
        Model index to plot from (e.g., 1 for M1, 2 for M2, default is 1).
    iz : int, optional
        Feature/layer index within the model parameter array (default is 0).
    uselog : int, optional
        Apply logarithmic normalization to color scale (1=True, 0=False, default is 1).
    title : str, optional
        Additional text to append to the plot title (default is '').
    hardcopy : bool, optional
        Save the plot as a PNG file (default is False).
    cmap : list or str, optional
        Colormap specification. If empty list, uses colormap from prior file
        attributes (default is []).
    clim : list, optional
        Color scale limits as [min, max]. If empty list, uses limits from
        prior file attributes (default is []).
    **kwargs : dict
        Additional keyword arguments passed to matplotlib scatter function.
        Common options include showInfo for debug output level.

    Returns
    -------
    None
        Function creates and displays the plot but does not return a value.

    Notes
    -----
    The function automatically retrieves geometry data and colormap/limit
    information from linked prior and data files. Plot files are saved with
    descriptive names including indices and feature information when hardcopy=True.
    """
    from matplotlib.colors import LogNorm

    showInfo = kwargs.get('showInfo', 0)

    #kwargs.setdefault('hardcopy', False)
    kwargs.setdefault('s', 1)
    dstr = '/M%d' % im
    
    with h5py.File(f_post_h5,'r') as f_post:
        f_prior_h5 = f_post['/'].attrs['f5_prior']
        f_data_h5 = f_post['/'].attrs['f5_data']
    

    with h5py.File(f_prior_h5,'r') as f_prior:
        if 'name' in f_prior[dstr].attrs:
            name = f_prior[dstr].attrs['name']
        else:    
            name = dstr

        
    X, Y, LINE, ELEVATION = get_geometry(f_data_h5)
    wx = 10
    wy = (np.max(Y)-np.min(Y))/(np.max(X)-np.min(X)) * wx
    
    if showInfo>1:
        print("f_prior_h5 = %s" % f_prior_h5)


    cmap_ref, clim_ref = get_colormap_and_limits('resistivity')
    if cmap is None:
        # Check prior file for colormap
        cmap = cmap_ref
        
    if clim_ref is None:
        clim = clim_ref

    if showInfo>2:
        print("clim=%s" % str(clim))
        print("cmap=%s" % str(cmap))
    
    nd = X.shape[0]
    if i1<1: 
        i1=0
    if i2>nd-1:
        i2=nd

    if i2<i1:
        i2=i1+1

    if len(key)==0:
        with h5py.File(f_post_h5,'r') as f_post:
            key = list(f_post[dstr].keys())[0]
        print("No key was given. Using the first key found: %s" % key)

    if showInfo>0:
        print("Plotting Feature %d from %s/%s" % (iz, dstr,key))

    with h5py.File(f_post_h5,'r') as f_post:

        if dstr in f_post:
            if key in f_post[dstr].keys():
                D = f_post[dstr][key][:,iz][:]
                # plot this KEY
                plt.figure(1, figsize=(wx, wy))
                if uselog:
                    plt.scatter(X[i1:i2],Y[i1:i2],c=D[i1:i2],
                                cmap = cmap,
                                norm=LogNorm(),
                                **kwargs)      
                else:        
                    plt.scatter(X[i1:i2],Y[i1:i2],c=D[i1:i2],
                                cmap = cmap,
                                **kwargs)      
                plt.grid()
                plt.xlabel('X')                
                plt.colorbar()
                print(title)
                if title is None:
                    title = "%s/%s[%d,:] %s" %(dstr,key,iz,name)
                plt.title(title)
                plt.axis('equal')
                plt.clim(clim)
                
                if hardcopy:
                    f_png = '%s_%d_%d_%d_%s%02d_feature.png' % (os.path.splitext(f_post_h5)[0],i1,i2,im,key,iz)
                    plt.savefig(f_png)
                #plt.show()
                
            else:
                print("Key %s not found in %s" % (key, dstr))
    return


def plot_T_EV(f_post_h5, i1=1, i2=1e+9, T_min=1, T_max=100, pl='all', hardcopy=False, **kwargs):
    """
    Plot temperature and evidence field values from posterior sampling results.

    Creates 2D spatial scatter plots showing the distribution of temperature (T),
    evidence (EV), and number of data points across the survey area. Temperature
    indicates sampling efficiency while evidence shows data fit quality.

    Parameters
    ----------
    f_post_h5 : str
        Path to the HDF5 file containing posterior sampling results.
    i1 : int, optional
        Starting data point index for plotting (1-based indexing, default is 1).
    i2 : float, optional
        Ending data point index for plotting. If larger than data size,
        uses all available data (default is 1e+9).
    s : int, optional
        Size of scatter plot markers in points (default is 5).
    T_min : int, optional
        Minimum temperature value for color scale normalization (default is 1).
    T_max : int, optional
        Maximum temperature value for color scale normalization (default is 100).
    pl : {'all', 'T', 'EV', 'ND', 'LOGL_mean'}, optional
        Type of plot to generate (default is 'all'):
        - 'all': plot all available types
        - 'T': temperature field only
        - 'EV': evidence field only  
        - 'ND': number of data points only
        - 'LOGL_mean': mean log-likelihood divided by (-2*n_data_used) only
    hardcopy : bool, optional
        Save plots as PNG files with descriptive names (default is False).
    **kwargs : dict
        Additional keyword arguments passed to matplotlib scatter function.

    Returns
    -------
    None
        Function creates and displays plots but does not return values.

    Notes
    -----
    Temperature values are displayed on log10 scale. Evidence values are
    clamped to reasonable ranges (1st to 99th percentile) for better visualization.
    The number of data plot shows non-NaN data count per location.
    """

    s=kwargs.setdefault('s', 1)

    with h5py.File(f_post_h5,'r') as f_post:
        f_prior_h5 = f_post['/'].attrs['f5_prior']
        f_data_h5 = f_post['/'].attrs['f5_data']
    
    X, Y, LINE, ELEVATION = get_geometry(f_data_h5)
    clim=(T_min,T_max)
        
    wx = 10
    wy = (np.max(Y)-np.min(Y))/(np.max(X)-np.min(X)) * wx
    print('Plot size: wx=%f, wy=%f' % (wx, wy))


    with h5py.File(f_post_h5,'r') as f_post:
        T=f_post['/T'][:].T
        EV=f_post['/EV'][:].T
        try:
            T_mul=f_post['/T_mul'][:]
        except:
            T_mul=[]

        try:
            EV_mul=f_post['/EV_mul'][:]
        except:
            EV_mu=[]
            
        try:
            LOGL_mean=f_post['/LOGL_mean'][:]
        except:
            LOGL_mean=None

    nd = X.shape[0]
    if i1<1: 
        i1=0
    if i2>nd-1:
        i2=nd

    if i2<i1:
        i2=i1+1
    
    if (pl=='all') or (pl=='T'):
        plt.figure(1, figsize=(wx,wy))
        plt.scatter(X[i1:i2],Y[i1:i2],c=np.log10(T[i1:i2]),cmap='jet',**kwargs)            
        plt.grid()
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.clim(np.log10(clim))      
        plt.colorbar(label='log10(T)')
        plt.title('Temperature')
        plt.axis('equal')
        if hardcopy:
            # get filename without extension        
            f_png = '%s_%d_%d_T.png' % (os.path.splitext(f_post_h5)[0],i1,i2)
            plt.savefig(f_png)
            plt.show()

    if (pl=='all') or (pl=='EV'):
        # get the 99% percentile of EV values
        EV_max = np.percentile(EV,99)
        EV_max = 0
        EV_min = np.percentile(EV,1)
        #EV_min = -30
        cmap_ev, clim = get_colormap_and_limits(cmap_type='evidence', custom_clim=[EV_min, EV_max])
        #if 'vmin' not in kwargs:
        #    kwargs['vmin'] = EV_min
        #if 'vmax' not in kwargs:
        #    kwargs['vmax'] = EV_max
        #print('EV_min=%f, EV_max=%f' % (EV_min, EV_max))
        plt.figure(2, figsize=(wx,wy))
        plt.scatter(X[i1:i2],Y[i1:i2],c=EV[i1:i2],cmap=cmap_ev, vmin=clim[0], vmax=clim[1], **kwargs)            
        plt.grid()
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.colorbar()
        plt.title('log(EV)')
        plt.axis('equal')
        if hardcopy:
            # get filename without extension
            f_png = '%s_%d_%d_EV.png' % (os.path.splitext(f_post_h5)[0],i1,i2)
            plt.savefig(f_png)
            plt.show()
    if (pl=='all') or (pl=='ND'):
        # 
        f_data = h5py.File(f_data_h5,'r')
        ndata,ns = f_data['/%s' % 'D1']['d_obs'].shape
        # find number of nan values on d_obs
        non_nan = np.sum(~np.isnan(f_data['/%s' % 'D1']['d_obs']), axis=1)
        #print(non_nan)

        plt.figure(3, figsize=(wx, wy))
        plt.scatter(X[i1:i2],Y[i1:i2],c=non_nan[i1:i2],cmap='jet', **kwargs)            
        plt.grid()
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.colorbar(label='Number of Data')
        plt.title('N data')
        plt.axis('equal')
        if hardcopy:
            # get filename without extension
            f_png = '%s_%d_%d_ND.png' % (os.path.splitext(f_post_h5)[0],i1,i2)
            plt.savefig(f_png)
            plt.show()
            
    if (pl=='all') or (pl=='LOGL_mean'):
        if LOGL_mean is not None:
            # Plot mean log-likelihood normalized by (-2*n_data_used)
            # Use first data type (index 0) or sum across data types if multiple
            if len(LOGL_mean.shape) == 2:
                # If multiple data types, sum across them for visualization
                LOGL_mean_plot = np.nansum(LOGL_mean, axis=1)
            else:
                LOGL_mean_plot = LOGL_mean
                
            # Get reasonable color limits (1st to 99th percentile)
            #LOGL_min = np.nanpercentile(LOGL_mean_plot, 1)
            #LOGL_max = np.nanpercentile(LOGL_mean_plot, 99)
            LOGL_min = 0
            LOGL_max = 5
            
            # Create custom colormap: red -> white -> blue with white at value 1
            # Red-white takes 1/5 (0 to 1), white-blue takes 4/5 (1 to 5)
            from matplotlib.colors import LinearSegmentedColormap, Normalize
            
            # Define color segments with proper proportions
            # Value 1 should be at position 0.2 (1/5) in the colormap
            colors = ['red', 'white', 'blue']
            n_seg = len(colors) - 1
            # Create segments: 0->1 takes 20% (0.0 to 0.2), 1->5 takes 80% (0.2 to 1.0)
            segment_positions = [0.0, 0.2, 1.0]
            custom_cmap = LinearSegmentedColormap.from_list('custom', list(zip(segment_positions, colors)), N=256)
            
            # Use standard normalization
            norm = Normalize(vmin=LOGL_min, vmax=LOGL_max)
            
            plt.figure(4, figsize=(wx, wy))
            plt.plot(X[i1:i2], Y[i1:i2], color='lightgray', zorder=-1, marker='.', linestyle='None', markersize=2*s)  # Background points in light gray
            scatter = plt.scatter(X[i1:i2], Y[i1:i2], c=LOGL_mean_plot[i1:i2],  
                                cmap=custom_cmap, norm=norm, **kwargs)
            plt.grid()
            plt.xlabel('X')
            plt.ylabel('Y')
            plt.colorbar(scatter, label='LOGL_mean')
            plt.title('Mean Log-Likelihood / (-2*n_data_used)')
            plt.axis('equal')
            if hardcopy:
                # get filename without extension
                f_png = '%s_%d_%d_LOGL_mean.png' % (os.path.splitext(f_post_h5)[0], i1, i2)
                plt.savefig(f_png)
                plt.show()
        else:
            print('LOGL_mean data not found in %s' % f_post_h5)

    return


def plot_geometry(f_data_h5, i1=0, i2=0, ii=np.array(()), pl='ELEVATION', hardcopy=False, ax=None, **kwargs):
    """
    Plot survey geometry data from INTEGRATE HDF5 files.

    Creates 2D scatter plots showing the spatial distribution of survey lines,
    elevation data, and data point indices. Useful for visualizing survey
    layout and data coverage.

    Parameters
    ----------
    f_data_h5 : str
        Path to the HDF5 file containing geometry data. Can be either a data
        file or posterior file (function automatically detects and uses correct file).
    i1 : int, optional
        Starting index for data points to plot (0-based indexing, default is 0).
    i2 : int, optional
        Ending index for data points to plot. If 0, uses all available data
        (default is 0).
    ii : numpy.ndarray, optional
        Specific array of indices to plot. If provided, overrides i1 and i2
        (default is empty array).
    pl : {'all', 'LINE', 'ELEVATION', 'id', 'NDATA'}, optional
        Type of geometry plot to generate (default is 'all'):
        - 'all': plot all geometry types
        - 'LINE': survey line numbers only
        - 'ELEVATION': elevation data only
        - 'id': data point indices only
        - 'NDATA': number of valid (non-NaN) data points per location
    hardcopy : bool, optional
        Save plots as PNG files with descriptive names (default is False).
    ax : matplotlib.axes.Axes, optional
        Matplotlib axes object to plot on. If None, creates new figures
        (default is None).
    **kwargs : dict
        Additional keyword arguments passed to matplotlib scatter function.
    s : int, optional
        Size of scatter plot markers in points (default is 1).
    cmap : str or matplotlib.colors.Colormap, optional
        Colormap to use for color-coding the scatter plots (default is 'jet').
        Can be any valid matplotlib colormap name or colormap object.

    Returns
    -------
    None
        Function creates and displays plots but does not return values.

    Notes
    -----
    The function automatically extracts geometry data (X, Y, LINE, ELEVATION)
    and creates equal-aspect plots with appropriate colorbars and grid lines.
    All data points are shown as light gray background with selected points highlighted.
    """

    kwargs.setdefault('s', 1)
    kwargs.setdefault('cmap', 'jet')

    import h5py
    # Test if f_data_h5 is in fact f_post_h5 type file
    with h5py.File(f_data_h5,'r') as f_data:
        if 'f5_prior' in f_data['/'].attrs:
            f_data_h5 = f_data['/'].attrs['f5_data']
    print('f_data_h5=%s' % f_data_h5)        
    X, Y, LINE, ELEVATION = get_geometry(f_data_h5)
    
    wx = 10
    wy = (np.max(Y)-np.min(Y))/(np.max(X)-np.min(X)) * wx
    print('Plot size: wx=%f, wy=%f' % (wx, wy))
    nd = X.shape[0]

    if len(ii)==0:
        if i1==0:
            i1=0
        if i2==0:
            i2=nd
        if i2<i1:
            i2=i1+1
        if i1<1: 
            i1=0
        if i2>nd-1:
            i2=nd
        ii = np.arange(i1,i2)

    markersize = kwargs.pop('markersize', .1)

    tit = f_png = '%s_%d_%d.png' % (os.path.splitext(f_data_h5)[0],i1,i2)

    # When ax is provided, default to showing LINE data if pl='all'
    if ax is not None and pl == 'all':
        pl = 'LINE'
    
    if (pl=='all') or (pl=='LINE'):
        if ax is None:
            plt.figure(figsize=(wx,wy))
            current_ax = plt.gca()
        else:
            current_ax = ax
        
        current_ax.plot(X,Y,'.',color='lightgray', zorder=-1, markersize=1)
        scatter = current_ax.scatter(X[ii],Y[ii],c=LINE[ii],**kwargs)            
        current_ax.grid()
        current_ax.set_xlabel('X')
        current_ax.set_ylabel('Y')
        
        if ax is None:
            plt.colorbar(scatter, label='LINE')
            plt.title('LINE')
            plt.axis('equal')
            if hardcopy:
                # get filename without extension        
                f_png = '%s_%d_%d_LINE.png' % (os.path.splitext(f_data_h5)[0],i1,i2)
                plt.savefig(f_png)
            #plt.show()
        else:
            current_ax.set_title('LINE')
            current_ax.set_aspect('equal')
        if pl == 'all':
            plt.show()

    if ax is None and ((pl=='all') or (pl=='ELEVATION')):
        plt.figure(figsize=(wx,wy))
        current_ax = plt.gca()
            
        scatter = current_ax.scatter(X[ii],Y[ii],c=ELEVATION[ii],**kwargs)            
        current_ax.grid()
        current_ax.set_xlabel('X')
        current_ax.set_ylabel('Y')
        plt.colorbar(scatter, label='ELEVATION')
        plt.title('ELEVATION')
        plt.axis('equal')
        if hardcopy:
            # get filename without extension        
            f_png = '%s_%d_%d_ELEVATION.png' % (os.path.splitext(f_data_h5)[0],i1,i2)
            plt.savefig(f_png)

        if pl == 'all':
            plt.show()
    

    elif ax is not None and pl == 'ELEVATION':
        scatter = ax.scatter(X[ii],Y[ii],c=ELEVATION[ii],**kwargs)            
        ax.grid()
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_title('ELEVATION')
        ax.set_aspect('equal')

        if pl == 'all':
            plt.show()

    if ax is None and ((pl=='all') or (pl=='id')):
        plt.figure(figsize=(wx,wy))
        current_ax = plt.gca()
            
        scatter = current_ax.scatter(X[ii],Y[ii],c=ii,**kwargs)  
        current_ax.grid()
        current_ax.set_xlabel('X')
        current_ax.set_ylabel('Y')
        plt.colorbar(scatter, label='id')
        plt.title('id')
        plt.axis('equal')
        if hardcopy:
            # get filename without extension        
            f_png = '%s_%d_%d_id.png' % (os.path.splitext(f_data_h5)[0],i1,i2)
            plt.savefig(f_png)

        if pl == 'all':
            plt.show()

    elif ax is not None and pl == 'id':
        scatter = ax.scatter(X[ii],Y[ii],c=ii,**kwargs)
        ax.grid()
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_title('id')
        ax.set_aspect('equal')

        if pl == 'all':
            plt.show()
    if ax is None and ((pl=='all') or (pl=='NDATA')):
        # Get number of data using the new function
        try:
            # Get data counts for all datasets (returns 2D array)
            data_counts = get_number_of_data(f_data_h5, count_nan=False)

            # If multiple datasets, sum across datasets to get total valid data per location
            if data_counts.shape[0] > 1:
                n_data_per_location = np.sum(data_counts, axis=0)
            else:
                n_data_per_location = data_counts[0, :]

            plt.figure(figsize=(wx,wy))
            current_ax = plt.gca()            
            scatter = current_ax.scatter(X[ii],Y[ii],c=n_data_per_location[ii],**kwargs)
            current_ax.grid()
            current_ax.set_xlabel('X')
            current_ax.set_ylabel('Y')
            plt.colorbar(scatter, label='Number of valid data points')
            plt.title('Number of Data (non-NaN)')
            plt.axis('equal')
            if hardcopy:
                # get filename without extension
                f_png = '%s_%d_%d_NDATA.png' % (os.path.splitext(f_data_h5)[0],i1,i2)
                plt.savefig(f_png)
            plt.show()
        except Exception as e:
            print(f"Warning: Could not plot number of data: {e}")
            print("This requires valid d_obs datasets in the HDF5 file")
        if pl == 'all':
            plt.show()

    elif ax is not None and pl == 'NDATA':
        # Get number of data using the new function
        try:
            # Get data counts for all datasets (returns 2D array)
            data_counts = get_number_of_data(f_data_h5, count_nan=False)

            # If multiple datasets, sum across datasets to get total valid data per location
            if data_counts.shape[0] > 1:
                n_data_per_location = np.sum(data_counts, axis=0)
            else:
                n_data_per_location = data_counts[0, :]

            scatter = ax.scatter(X[ii],Y[ii],c=n_data_per_location[ii],**kwargs)
            ax.grid()
            ax.set_xlabel('X')
            ax.set_ylabel('Y')
            ax.set_title('Number of Data (non-NaN)')
            ax.set_aspect('equal')
        except Exception as e:
            print(f"Warning: Could not plot number of data: {e}")
            print("This requires valid d_obs datasets in the HDF5 file")

        if pl == 'all':
            plt.show()
    return



def plot_profile(f_post_h5, i1=1, i2=1e+9, ii=np.array(()), im=0, xaxis='index', gap_threshold=None, panels=None, **kwargs):
    """
    Plot 1D profiles from posterior sampling results.

    This function creates vertical profile plots showing the posterior distribution
    of model parameters as a function of depth or model layer. Automatically
    detects model type (discrete or continuous) and calls appropriate plotting function.

    Parameters
    ----------
    f_post_h5 : str
        Path to the HDF5 file containing posterior sampling results.
    i1 : int, optional
        Starting index for the data points to plot (1-based indexing, default is 1).
    i2 : float, optional
        Ending index for the data points to plot (1-based indexing, default is 1e+9).
    ii : numpy.ndarray, optional
        Specific array of indices to plot. If provided, overrides i1 and i2 (default is empty array).
    im : int, optional
        Model identifier to plot. If 0, automatically detects and plots all models (default is 0).
    xaxis : str, optional
        X-axis type for plotting. Options: 'id' (data index), 'x' (X coordinate), 'y' (Y coordinate), 'index' (sequential 0,1,2...) (default is 'index').
    gap_threshold : float, optional
        Threshold for making large gaps transparent. If the distance between consecutive data points exceeds this value, the region becomes transparent. If None, no gap transparency is applied (default is None).
    panels : list of str or None, optional
        Controls which panels to display. Options depend on model type:

        For continuous models: ['value', 'std', 'stats']
        For discrete models: ['mode', 'entropy', 'stats']

        See plot_profile_continuous() and plot_profile_discrete() for detailed options (default is None, shows all panels).
    **kwargs : dict
        Additional plotting arguments passed to discrete/continuous plotting functions.
        Both model types support 'alpha' (float, 0.0-1.0) to apply uncertainty-based
        transparency to the main profile panel (median/mean for continuous, mode for discrete).

    Returns
    -------
    None
        Creates matplotlib plots.

    Notes
    -----
    The function automatically computes posterior statistics if not present in the file.
    For discrete models, calls plot_profile_discrete(). For continuous models,
    calls plot_profile_continuous().

    Examples
    --------
    Plot all models with all panels:

    >>> plot_profile(f_post_h5, im=0)

    Plot only median resistivity for model 1:

    >>> plot_profile(f_post_h5, im=1, panels=['value'])

    Plot mode and stats for discrete model 2:

    >>> plot_profile(f_post_h5, im=2, panels=['mode', 'stats'])

    Plot discrete model with full uncertainty transparency on mode:

    >>> plot_profile(f_post_h5, im=2, alpha=1.0)

    Plot continuous model with partial transparency:

    >>> plot_profile(f_post_h5, im=1, alpha=0.5)
    """

    with h5py.File(f_post_h5,'r') as f_post:
        f_prior_h5 = f_post['/'].attrs['f5_prior']
        f_data_h5 = f_post['/'].attrs['f5_data']

    # Check if M1 exist in f_post_h5
    updatePostStat = False
    with h5py.File(f_post_h5,'r') as f_post:
        if '/M1' not in f_post:
            print('No posterior stats found in %s - computing them now' % f_post_h5)
            updatePostStat = True
    if updatePostStat:
            integrate_posterior_stats(f_post_h5)
            
    if (im==0):
        print('Plot profile for all model parameters')

        with h5py.File(f_prior_h5,'r') as f_prior:
            for key in f_prior.keys():
                im = int(key[1:])
                try:
                    if key[0]=='M':
                        plot_profile(f_post_h5, i1, i2, ii, im=im, xaxis=xaxis, gap_threshold=gap_threshold, panels=panels, **kwargs)
                except Exception as e:
                    print('Error in plot_profile for key=%s: %s' % (key, str(e)))
                    import traceback
                    traceback.print_exc()
        return


    Mstr = '/M%d' % im
    with h5py.File(f_prior_h5,'r') as f_prior:
        is_discrete = f_prior[Mstr].attrs['is_discrete']
    #print(Mstr)
    #print(is_discrete)

    if is_discrete:
        plot_profile_discrete(f_post_h5, i1, i2, ii, im, xaxis, gap_threshold, panels, **kwargs)
    elif not is_discrete:
        plot_profile_continuous(f_post_h5, i1, i2, ii, im, xaxis, gap_threshold, panels, **kwargs)


def plot_profile_discrete(f_post_h5, i1=1, i2=1e+9, ii=np.array(()), im=1, xaxis='index', gap_threshold=None, panels=None, **kwargs):
    """
    Create vertical profile plots for discrete categorical model parameters.

    Generates a 3-panel plot showing discrete model parameter distributions
    with depth, including mode, entropy, and temperature/evidence curves.
    Designed for geological unit classification results.

    Parameters
    ----------
    f_post_h5 : str
        Path to the HDF5 file containing posterior sampling results.
    i1 : int, optional
        Starting data point index for profile plotting (1-based indexing, default is 1).
    i2 : float, optional
        Ending data point index for profile plotting. If larger than data size,
        uses all available data (default is 1e+9).
    ii : numpy.ndarray, optional
        Specific array of indices to plot. If provided, overrides i1 and i2 (default is empty array).
    im : int, optional
        Model index to plot (e.g., 1 for M1, 2 for M2, default is 1).
    xaxis : str, optional
        X-axis type for plotting. Options: 'id' (data index), 'x' (X coordinate), 'y' (Y coordinate), 'index' (sequential 0,1,2...) (default is 'index').
    gap_threshold : float, optional
        Threshold for making large gaps transparent. If the distance between consecutive data points exceeds this value, regions after the gaps become completely transparent to indicate missing data. If None, no gap transparency is applied (default is None).
    panels : list of str or None, optional
        Controls which panels to display. Each panel maintains consistent size regardless of which are shown.
        Options:
        - None (default): Show all panels ['mode', 'entropy', 'stats']
        - ['mode']: Only mode (most probable class)
        - ['entropy']: Only entropy (uncertainty)
        - ['stats']: Only temperature and log-likelihood
        - Any combination of the above (e.g., ['mode', 'stats'])
        Accepted panel names: 'mode', 'entropy', 'stats', 'temperature', 't'
    **kwargs : dict
        Additional keyword arguments:
        - alpha : float, transparency scaling factor based on entropy (0.0 to 1.0).
          alpha=0.0 means no transparency (default), alpha=1.0 means full entropy-based
          transparency where high-uncertainty regions become transparent
        - hardcopy : bool, save plot as PNG file (default False)
        - txt : str, additional text for filename
        - showInfo : int, level of debug output (0=none, >0=verbose)
        - clim : list, color scale limits for discrete classes

    Returns
    -------
    None
        Function creates and displays the plot but does not return values.

    Notes
    -----
    The plot structure uses 3 subplots (matching plot_profile_continuous()):
    - ax[0]: Mode - most probable class at each depth/location (optionally with entropy transparency)
    - ax[1]: Entropy - uncertainty measure (0=certain, 1=maximum uncertainty)
    - ax[2]: Temperature and evidence curves

    Class names and colors are automatically retrieved from prior file attributes.
    Depth coordinates are computed relative to surface elevation.

    When alpha > 0, the mode panel shows both classification and uncertainty in one view:
    solid colors indicate high certainty, transparent colors indicate high uncertainty.
    The alpha value (0.0 to 1.0) controls the strength of this transparency effect.

    Examples
    --------
    Show only mode profile:

    >>> plot_profile_discrete(f_post_h5, panels=['mode'])

    Show mode with full uncertainty transparency (alpha=1.0):

    >>> plot_profile_discrete(f_post_h5, panels=['mode'], alpha=1.0)

    Show mode with partial transparency (alpha=0.5):

    >>> plot_profile_discrete(f_post_h5, panels=['mode'], alpha=0.5)

    Show mode and stats (no entropy):

    >>> plot_profile_discrete(f_post_h5, panels=['mode', 'stats'])

    Show only entropy:

    >>> plot_profile_discrete(f_post_h5, panels=['entropy'])

    Show all panels with transparency on mode:

    >>> plot_profile_discrete(f_post_h5, alpha=1.0)
    """
    from matplotlib.colors import LogNorm

    kwargs.setdefault('hardcopy', False)
    txt = kwargs.get('txt','')
    showInfo = kwargs.get('showInfo', 0)
    alpha = kwargs.get('alpha', 0.0)  # Transparency scaling factor (0.0 to 1.0)

    # Default to showing all panels
    if panels is None:
        panels = ['mode', 'entropy', 'stats']

    # Normalize panel names to lowercase
    panels = [p.lower() for p in panels]

    # Determine which panels to show
    show_mode = 'mode' in panels
    show_entropy = 'entropy' in panels
    show_stats = any(p in panels for p in ['stats', 't', 'temperature'])

    with h5py.File(f_post_h5,'r') as f_post:
        f_prior_h5 = f_post['/'].attrs['f5_prior']
        f_data_h5 = f_post['/'].attrs['f5_data']
    
    X, Y, LINE, ELEVATION = get_geometry(f_data_h5)

    Mstr = '/M%d' % im

    if showInfo>0:
        print("Plotting profile %s from %s" % (Mstr, f_post_h5))

    with h5py.File(f_prior_h5,'r') as f_prior:
        try:
            z = f_prior[Mstr].attrs['z'][:].flatten()
        except:
            z = f_prior[Mstr].attrs['x'][:].flatten()
        is_discrete = f_prior[Mstr].attrs['is_discrete']
        if 'clim' in f_prior[Mstr].attrs.keys():
            clim = f_prior[Mstr].attrs['clim'][:].flatten()
        else:
            # if clim set in kwargs, use it, otherwise use default
            if 'clim' in kwargs:
                clim = kwargs['clim']
            else:
                clim = [.1, 2600]
                clim = [10, 500]
        if 'class_id' in f_prior[Mstr].attrs.keys():
            class_id = f_prior[Mstr].attrs['class_id'][:].flatten()
        else:   
            print('No class_id found')
        if 'class_name' in f_prior[Mstr].attrs.keys():
            class_name = f_prior[Mstr].attrs['class_name'][:].flatten()
        else:
            class_name = []
        n_class = len(class_name)
        if 'cmap' in f_prior[Mstr].attrs.keys():
            cmap = f_prior[Mstr].attrs['cmap'][:]
        else:
            cmap = plt.cm.jet(np.linspace(0, 1, n_class)).T
        from matplotlib.colors import ListedColormap
        cmap = ListedColormap(cmap.T)            

    if not is_discrete:
        print("%s refers to a continuous model. Use plot_profile_continuous instead" % Mstr)

    with h5py.File(f_post_h5,'r') as f_post:
        Mode=f_post[Mstr+'/Mode'][:].T
        Entropy=f_post[Mstr+'/Entropy'][:].T
        P=f_post[Mstr+'/P'][:]
        T=f_post['/T'][:].T
        try:
            LOGL_mean=f_post['/LOGL_mean'][:]
        except:
            LOGL_mean=None

    nm = Mode.shape[0]
    if nm<=1:
        print('Only nm=%d, model parameters. no profile will be plot' % (nm))
        return 1

    nd = LINE.shape[0]
    id = np.arange(nd)
    # Create a meshgrid from X and Y
    XX, ZZ = np.meshgrid(X,z)
    YY, ZZ = np.meshgrid(Y,z)
    ID, ZZ = np.meshgrid(id,z)

    ID = np.sort(ID, axis=0)
    ZZ = np.sort(ZZ, axis=0)

    # compute the depth from the surface plus the elevation
    for i in range(nd):
        ZZ[:,i] = ELEVATION[i]-ZZ[:,i]

    # Index selection logic - use specific indices if provided, otherwise use range
    if len(ii)==0:
        if i1<1:
            i1=0
        if i2>nd-1:
            i2=nd-1
        ii = np.arange(i1,i2)
    else:
        # Ensure ii indices are within bounds
        ii = np.array(ii)
        ii = ii[ii < nd]  # Remove indices >= nd
        ii = ii[ii >= 0]  # Remove negative indices

    # Sort indices based on chosen x-axis to ensure monotonic ordering
    if xaxis == 'x':
        # Sort by X coordinates
        x_vals = X[ii]
        sort_order = np.argsort(x_vals)
        ii = ii[sort_order]
    elif xaxis == 'y':
        # Sort by Y coordinates
        y_vals = Y[ii]
        sort_order = np.argsort(y_vals)
        ii = ii[sort_order]
    elif xaxis == 'id':
        # Sort by data index (sort ii directly)
        ii = np.sort(ii)
    # For 'index', no additional sorting needed (will be sequential 0,1,2,3...)

    # X-axis selection logic
    if xaxis == 'id':
        # Use data index (default behavior)
        XAXIS_DATA, ZZ_XAXIS = np.meshgrid(id, z)
        XAXIS_DATA = np.sort(XAXIS_DATA, axis=0)
        ZZ_XAXIS = np.sort(ZZ_XAXIS, axis=0)
        # compute the depth from the surface plus the elevation
        for i in range(nd):
            ZZ_XAXIS[:,i] = ELEVATION[i]-ZZ_XAXIS[:,i]
        # Get center of grid cells
        IID = XAXIS_DATA[:,ii]
        IIZ = ZZ_XAXIS[:,ii]
        # Create x-axis values for temperature plotting
        x_axis_values = XAXIS_DATA[0,ii]
    elif xaxis == 'x':
        # Use X coordinates
        XAXIS_DATA, ZZ_XAXIS = np.meshgrid(X, z)
        XAXIS_DATA = np.sort(XAXIS_DATA, axis=0)
        ZZ_XAXIS = np.sort(ZZ_XAXIS, axis=0)
        # compute the depth from the surface plus the elevation
        for i in range(nd):
            ZZ_XAXIS[:,i] = ELEVATION[i]-ZZ_XAXIS[:,i]
        # Get center of grid cells
        IID = XAXIS_DATA[:,ii]
        IIZ = ZZ_XAXIS[:,ii]
        # Create x-axis values for temperature plotting
        x_axis_values = XAXIS_DATA[0,ii]
    elif xaxis == 'y':
        # Use Y coordinates
        XAXIS_DATA, ZZ_XAXIS = np.meshgrid(Y, z)
        XAXIS_DATA = np.sort(XAXIS_DATA, axis=0)
        ZZ_XAXIS = np.sort(ZZ_XAXIS, axis=0)
        # compute the depth from the surface plus the elevation
        for i in range(nd):
            ZZ_XAXIS[:,i] = ELEVATION[i]-ZZ_XAXIS[:,i]
        # Get center of grid cells
        IID = XAXIS_DATA[:,ii]
        IIZ = ZZ_XAXIS[:,ii]
        # Create x-axis values for temperature plotting
        x_axis_values = XAXIS_DATA[0,ii]
    elif xaxis == 'index':
        # Use sequential indices 0,1,2,3... for the SELECTED points only
        # Create sequential x-axis for selected indices
        n_selected = len(ii)
        sequential_x = np.arange(n_selected)
        XAXIS_SEQUENTIAL, ZZ_XAXIS = np.meshgrid(sequential_x, z)

        # For depth, we still need to use the original indices for elevation
        ZZ_ORIGINAL = np.zeros_like(ZZ_XAXIS)
        for i, orig_idx in enumerate(ii):
            ZZ_ORIGINAL[:,i] = ELEVATION[orig_idx] - z

        # Get center of grid cells - now sequential
        IID = XAXIS_SEQUENTIAL
        IIZ = ZZ_ORIGINAL
        # Create x-axis values for temperature plotting
        x_axis_values = sequential_x
    else:
        # Default to 'id' if invalid option provided
        print(f"Warning: Unknown xaxis option '{xaxis}'. Using 'id' instead.")
        XAXIS_DATA, ZZ_XAXIS = np.meshgrid(id, z)
        XAXIS_DATA = np.sort(XAXIS_DATA, axis=0)
        ZZ_XAXIS = np.sort(ZZ_XAXIS, axis=0)
        # compute the depth from the surface plus the elevation
        for i in range(nd):
            ZZ_XAXIS[:,i] = ELEVATION[i]-ZZ_XAXIS[:,i]
        # Get center of grid cells
        IID = XAXIS_DATA[:,ii]
        IIZ = ZZ_XAXIS[:,ii]
        # Create x-axis values for temperature plotting
        x_axis_values = XAXIS_DATA[0,ii]
    # IID, IIZ is the center of the cell. Create new grids, DDc, ZZc, that hold the the cordńers if the grids. 
    # DDc should have cells of size 1, while ZZc should be the same as ZZ but with a row added at the bottom that is the same as the last row of ZZ plus 100
    DDc = np.zeros((IID.shape[0]+1,IID.shape[1]+1))
    ZZc = np.zeros((IID.shape[0]+1,IID.shape[1]+1))
    DDc[:-1,:-1] = IID - 0.5
    DDc[:-1,-1] = IID[:,-1] + 0.5
    DDc[-1,:] = DDc[-2,:] + 1

    ZZc[:-1,:-1] = IIZ
    ZZc[-1,:] = ZZc[-2,:] + 1

    # Gap detection and transparency
    gap_alpha = None
    if gap_threshold is not None and len(x_axis_values) > 1:
        showInfo = kwargs.get('showInfo', 0)
        if showInfo > 0:
            print(f"Gap transparency: threshold={gap_threshold}, x_values={x_axis_values}")

        # Calculate distances between consecutive x-axis points
        x_diffs = np.diff(x_axis_values)

        # Create alpha mask for gaps: 1.0 for normal spacing, 0.0 for large gaps
        gap_alpha = np.ones(IID.shape)  # Shape: (nz, n_selected)

        # Find positions where gaps exceed threshold
        large_gaps = x_diffs > gap_threshold

        if np.any(large_gaps):
            gap_count = np.sum(large_gaps)
            if showInfo > 0:
                print(f"Found {gap_count} large gaps (>{gap_threshold})")

            # For each large gap, make cells that fall within the gap region transparent
            for i, is_large_gap in enumerate(large_gaps):
                if is_large_gap:
                    # Gap exists between x_axis_values[i] and x_axis_values[i+1]
                    gap_start = x_axis_values[i]
                    gap_end = x_axis_values[i+1]

                    if showInfo > 0:
                        print(f"Gap {i}: from {gap_start:.1f} to {gap_end:.1f} (width: {x_diffs[i]:.1f})")

                    # Find which cells in the DDc grid fall within this gap
                    # DDc contains the corner coordinates of each cell
                    for col in range(IID.shape[1]):
                        # Get the x-coordinate range for this column
                        cell_x_start = DDc[0, col]
                        cell_x_end = DDc[0, col + 1]

                        # Check if this cell overlaps with the gap region
                        # Cell overlaps if: cell_start < gap_end AND cell_end > gap_start
                        if cell_x_start < gap_end and cell_x_end > gap_start:
                            # This cell is within or overlaps the gap region
                            gap_alpha[:, col] = 0.0
                            if showInfo > 1:  # More verbose debugging
                                print(f"  Made column {col} transparent (cell range: {cell_x_start:.1f}-{cell_x_end:.1f})")

    # ii is a numpy array from i1 to i2
    # ii = np.arange(i1,i2)

    # Create a figure with 3 subplots (always create all to maintain consistent sizing)
    # This matches the structure of plot_profile_continuous()
    fig, ax = plt.subplots(3,1,figsize=(20,10), gridspec_kw={'height_ratios': [3, 3, 1]})

    # Hide panels that are not requested
    if not show_mode:
        ax[0].axis('off')
    if not show_entropy:
        ax[1].axis('off')
    if not show_stats:
        ax[2].axis('off')

    # MODE panel (ax[0]) - only if requested
    if show_mode:
        mode_data = Mode[:,ii]
        if gap_alpha is not None:
            # Use masked array to hide transparent regions
            mode_data = np.ma.masked_where(gap_alpha == 0.0, mode_data)

        # Apply pcolormesh
        im1 = ax[0].pcolormesh(DDc, ZZc, mode_data,
                cmap=cmap,
                vmin=clim[0]-.5,
                vmax=clim[1]+.5,
                shading='auto')

        # Apply entropy-based transparency if alpha > 0
        if alpha > 0:
            # Transparency scaled by alpha: alpha * Entropy
            # When Entropy=0 (certain): transparency=0 (opaque)
            # When Entropy=1 (uncertain): transparency=alpha (scaled)
            im1.set_alpha(1 - alpha * Entropy[:,ii])
            ax[0].set_title('Mode (with uncertainty transparency)')
        else:
            ax[0].set_title('Mode')

        # Set the ticks at the center of each color band (at class_id values)
        cbar1 = fig.colorbar(im1, ax=ax[0], label='label')
        cbar1.set_ticks(class_id)
        cbar1.set_ticklabels(class_name)
        cbar1.ax.invert_yaxis()
        ax[0].set_ylabel('Elevation (m)')

    # ENTROPY panel (ax[1]) - only if requested
    if show_entropy:
        import matplotlib
        entropy_data = Entropy[:,ii]
        if gap_alpha is not None:
            # Use masked array to hide transparent regions
            entropy_data = np.ma.masked_where(gap_alpha == 0.0, entropy_data)

        im2 = ax[1].pcolormesh(DDc, ZZc, entropy_data,
                cmap=matplotlib.colors.LinearSegmentedColormap.from_list("", ["white", "black", "red"]),
                shading='auto')
        im2.set_clim(0,1)
        ax[1].set_title('Entropy')
        ax[1].set_ylabel('Elevation (m)')
        fig.colorbar(im2, ax=ax[1], label='Entropy')

    ## Remove x-tick labels from non-bottom panels
    if show_mode:
        ax[0].set_xticks([])
    if show_entropy:
        ax[1].set_xticks([])

    # Plot STATS panel (ax[2]) - only if requested
    if show_stats:
        im4 = ax[2].semilogy(x_axis_values,T[ii], 'k.', label='T')
        ax[2].set_xlim(x_axis_values.min(), x_axis_values.max())
        ax[2].set_ylim(0.99, 200)
        ax[2].set_ylabel('Temperature', color='k')
        ax[2].tick_params(axis='y', labelcolor='k')

        if LOGL_mean is not None:
            # Create second y-axis for LOGL_mean
            ax2_twin = ax[2].twinx()
            ax2_twin.plot(x_axis_values, LOGL_mean[ii], 'r.', label='LOGL_mean')
            # Add dotted red line at y=1
            ax2_twin.axhline(y=1, color='r', linestyle=':', linewidth=1, alpha=0.7)
            ax2_twin.set_ylim(0, 5)
            ax2_twin.set_ylabel('LOGL_mean', color='r')
            ax2_twin.tick_params(axis='y', labelcolor='r')

            # Combine legends from both axes
            lines1, labels1 = ax[2].get_legend_handles_labels()
            lines2, labels2 = ax2_twin.get_legend_handles_labels()
            ax[2].legend(lines1 + lines2, labels1 + labels2, loc='upper right')
        else:
            ax[2].legend(loc='upper right')

        plt.grid(True)

    plt.tight_layout()

    # Create an invisible colorbar for the last subplot to maintain alignment
    if show_stats and show_entropy:
        try:
            cbar4 = fig.colorbar(im2, ax=ax[2])
            cbar4.solids.set(alpha=0)
            cbar4.outline.set_visible(False)
            cbar4.ax.set_yticks([])  # Hide the colorbar ticks
            cbar4.ax.set_yticklabels([])  # Hide the colorbar ticks labels
        except:
            pass  # If im2 doesn't exist, skip colorbar


    # get filename without extension
    if kwargs['hardcopy']:
        # Add panel information to filename if panels were specified
        if panels is not None and panels != ['mode', 'entropy', 'stats']:
            panel_str = '_panels_' + '-'.join(panels)
        else:
            panel_str = ''
        f_png = '%s__%d_%d_profile_%s%s%s.png' % (os.path.splitext(f_post_h5)[0],ii[0],ii[-1],Mstr[1:],panel_str,txt)
        plt.savefig(f_png)
    plt.show()

    return

def plot_profile_continuous(f_post_h5, i1=1, i2=1e+9, ii=np.array(()), im=1, xaxis='index', gap_threshold=None, panels=None, **kwargs):
    """
    Create vertical profile plots for continuous model parameters.

    Generates a 4-panel plot showing continuous parameter distributions with depth,
    including mean/median values, standard deviation, and temperature/evidence curves.
    Supports transparency based on uncertainty for better visualization.

    Parameters
    ----------
    f_post_h5 : str
        Path to the HDF5 file containing posterior sampling results.
    i1 : int, optional
        Starting data point index for profile plotting (1-based indexing, default is 1).
    i2 : float, optional
        Ending data point index for profile plotting. If larger than data size,
        uses all available data (default is 1e+9).
    ii : numpy.ndarray, optional
        Specific array of indices to plot. If provided, overrides i1 and i2 (default is empty array).
    im : int, optional
        Model index to plot (e.g., 1 for M1, 2 for M2, default is 1).
    xaxis : str, optional
        X-axis type for plotting. Options: 'id' (data index), 'x' (X coordinate), 'y' (Y coordinate), 'index' (sequential 0,1,2...) (default is 'id').
    gap_threshold : float, optional
        Threshold for making large gaps transparent. If the distance between consecutive data points exceeds this value, regions after the gaps become completely transparent to indicate missing data. If None, no gap transparency is applied (default is None).
    panels : list of str or None, optional
        Controls which panels to display. Each panel maintains consistent size regardless of which are shown.
        Options:
        - None (default): Show all panels ['value', 'std', 'stats']
        - ['value']: Only median/mean resistivity
        - ['std']: Only standard deviation
        - ['stats']: Only temperature and log-likelihood
        - Any combination of the above (e.g., ['value', 'stats'])
        Accepted panel names: 'value', 'median', 'mean', 'std', 'uncertainty', 'stats', 'temperature', 't'
    **kwargs : dict
        Additional keyword arguments:
        - hardcopy : bool, save plot as PNG file (default False)
        - cmap : str or colormap, color scheme for plotting (default 'jet')
        - key : {'Mean', 'Median'}, statistic to plot (default 'Median')
        - alpha : float, transparency scaling factor based on normalized standard deviation (0.0 to 1.0).
          alpha=0.0 means no transparency (default), alpha=1.0 means full uncertainty-based
          transparency where high-uncertainty regions become transparent
        - txt : str, additional text for filename
        - showInfo : int, level of debug output (0=none, >0=verbose)
        - clim : list, color scale limits [min, max]

    Returns
    -------
    None
        Function creates and displays the plot but does not return values.

    Notes
    -----
    The plot structure uses 3 subplots:
    - ax[0]: Mean or median values (for multi-layer) or line plot with confidence bounds (for single parameter)
    - ax[1]: Standard deviation (for multi-layer, hidden for single parameter)
    - ax[2]: Temperature and evidence curves

    For multi-layer models (nm > 1):
    - Panel 0: Mean or median values with logarithmic color scale
    - Panel 1: Standard deviation with grayscale colormap
    - Panel 2: Temperature and evidence curves

    For single-parameter models (nm = 1):
    - Panel 0: Line plot with mean ± 2*std confidence bounds
    - Panel 1: Hidden
    - Panel 2: Temperature and evidence curves

    Transparency can be applied based on uncertainty levels when alpha > 0.
    Depth coordinates are computed relative to surface elevation.

    Examples
    --------
    Show only median resistivity profile:

    >>> plot_profile_continuous(f_post_h5, panels=['value'])

    Show median with full uncertainty transparency (alpha=1.0):

    >>> plot_profile_continuous(f_post_h5, panels=['value'], alpha=1.0)

    Show median with partial transparency (alpha=0.5):

    >>> plot_profile_continuous(f_post_h5, panels=['value'], alpha=0.5)

    Show median and stats (no std):

    >>> plot_profile_continuous(f_post_h5, panels=['value', 'stats'])

    Show only standard deviation:

    >>> plot_profile_continuous(f_post_h5, panels=['std'])
    """
    from matplotlib.colors import LogNorm

    cmap_def, clim_def = get_colormap_and_limits('resistivity')

    kwargs.setdefault('hardcopy', False)
    kwargs.setdefault('cmap', None)
    kwargs.setdefault('clim', None)

    alpha = kwargs.get('alpha',0.0)
    key = kwargs.get('key','Median')
    txt = kwargs.get('txt','')
    showInfo = kwargs.get('showInfo', 0)

    # Default to showing all panels
    if panels is None:
        panels = ['value', 'std', 'stats']

    # Normalize panel names to lowercase
    panels = [p.lower() for p in panels]

    # Determine which panels to show
    show_value = any(p in panels for p in ['value', 'median', 'mean'])
    show_std = any(p in panels for p in ['std', 'uncertainty'])
    show_stats = any(p in panels for p in ['stats', 't', 'temperature'])
    
    with h5py.File(f_post_h5,'r') as f_post:
        f_prior_h5 = f_post['/'].attrs['f5_prior']
        f_data_h5 = f_post['/'].attrs['f5_data']
    with h5py.File(f_prior_h5,'r') as f_prior:
        if 'name' in f_prior['/M%d' % im].attrs:
            name = f_prior['/M%d' % im].attrs['name']
        else:
            name='M%d' % im

    X, Y, LINE, ELEVATION = get_geometry(f_data_h5)

    Mstr = '/M%d' % im
    clim_ref, cmap_ref = h5_get_clim_cmap(f_prior_h5, Mstr)

    if showInfo>0:
        print("Plotting profile %s from %s" % (Mstr, f_post_h5))

    with h5py.File(f_prior_h5,'r') as f_prior:
        if 'z' in f_prior[Mstr].attrs.keys():
            z = f_prior[Mstr].attrs['z'][:].flatten()
        elif 'x' in f_prior[Mstr].attrs.keys():
            z = f_prior[Mstr].attrs['x'][:].flatten()
        else:
            z=np.array(0)
        is_discrete = f_prior[Mstr].attrs['is_discrete']

        ## climits
        if 'clim' in kwargs and kwargs['clim'] is not None:
            #print('using clim from kwargs')
            clim = kwargs['clim']
        elif 'clim' in f_prior[Mstr].attrs.keys():
            #print('Getting clim from attribute')
            clim = f_prior[Mstr].attrs['clim'][:].flatten()
        else:
            #print('using clim from prior attributes or default')
            clim = clim_def
        
        ## climits
        if 'cmap' in kwargs and kwargs['cmap'] is not None:
            #print('using cmap from kwargs')
            cmap = kwargs['cmap']
        elif 'cmap' in f_prior[Mstr].attrs.keys():
            #print('Getting cmap from attribute')
            cmap = f_prior[Mstr].attrs['cmap'][:]
            from matplotlib.colors import ListedColormap
            cmap = ListedColormap(cmap.T)
        else:
            #print('using default cmap')
            cmap = cmap_ref

    if is_discrete:
        print("%s refers to a discrete model. Use plot_profile_discrete instead" % Mstr)


    with h5py.File(f_post_h5,'r') as f_post:
        Mean=f_post[Mstr+'/Mean'][:].T
        Median=f_post[Mstr+'/Median'][:].T
        Std=f_post[Mstr+'/Std'][:].T
        T=f_post['/T'][:].T
        try:
            LOGL_mean=f_post['/LOGL_mean'][:]
        except:
            LOGL_mean=None

    # Compute alpha matrix 'A' for transparency based on uncertainty
    # Normalize Std to [0, 1] range based on its own min/max values
    # Then apply alpha scaling: alpha * normalized_Std
    A = np.ones(Std.shape)  # Start with fully opaque (alpha=1)
    if alpha > 0:
        # Normalize Std to [0, 1] based on min/max of Std values
        Std_min = np.nanmin(Std)
        Std_max = np.nanmax(Std)
        if Std_max > Std_min:
            Std_normalized = (Std - Std_min) / (Std_max - Std_min)
        else:
            Std_normalized = np.zeros_like(Std)

        # Apply alpha scaling: higher uncertainty = more transparent
        # A = 1 - alpha * Std_normalized
        # When Std=Std_min (low uncertainty): A=1 (opaque)
        # When Std=Std_max (high uncertainty): A=1-alpha (transparent)
        A = 1 - alpha * Std_normalized
    
    nm = Mean.shape[0]
    if nm<=1:
        pass
        #print('Only nm=%d, model parameters. no profile will be plot' % (nm))
        #return 1

    # Check for out of range
    nd = LINE.shape[0]
    if i1<1: 
        i1=0
    if i2>nd-1:
        i2=nd-1
    id = np.arange(nd)
    
    if nm>=1:
        # Create a meshgrid from X and Y
        XX, ZZ = np.meshgrid(X,z)
        YY, ZZ = np.meshgrid(Y,z)
        ID, ZZ = np.meshgrid(id,z)

        ID = np.sort(ID, axis=0)
        ZZ = np.sort(ZZ, axis=0)

        # compute the depth from the surface plus the elevation
        for i in range(nd):
            ZZ[:,i] = ELEVATION[i]-ZZ[:,i]

        # Index selection logic - use specific indices if provided, otherwise use range
        if len(ii)==0:
            if i1<1:
                i1=0
            if i2>nd-1:
                i2=nd-1
            ii = np.arange(i1,i2)
        else:
            # Ensure ii indices are within bounds
            ii = np.array(ii)
            ii = ii[ii < nd]  # Remove indices >= nd
            ii = ii[ii >= 0]  # Remove negative indices

        # Sort indices based on chosen x-axis to ensure monotonic ordering
        if xaxis == 'x':
            # Sort by X coordinates
            x_vals = X[ii]
            sort_order = np.argsort(x_vals)
            ii = ii[sort_order]
        elif xaxis == 'y':
            # Sort by Y coordinates
            y_vals = Y[ii]
            sort_order = np.argsort(y_vals)
            ii = ii[sort_order]
        elif xaxis == 'id':
            # Sort by data index (sort ii directly)
            ii = np.sort(ii)
        # For 'index', no additional sorting needed ('index' will be sequential)

        # X-axis selection logic
        if xaxis == 'id':
            # Use data index (default behavior)
            XAXIS_DATA, ZZ_XAXIS = np.meshgrid(id, z)
            XAXIS_DATA = np.sort(XAXIS_DATA, axis=0)
            ZZ_XAXIS = np.sort(ZZ_XAXIS, axis=0)
            # compute the depth from the surface plus the elevation
            for i in range(nd):
                ZZ_XAXIS[:,i] = ELEVATION[i]-ZZ_XAXIS[:,i]
            # Get center of grid cells
            IID = XAXIS_DATA[:,ii]
            IIZ = ZZ_XAXIS[:,ii]
            # Create x-axis values for temperature plotting
            x_axis_values = XAXIS_DATA[0,ii]
        elif xaxis == 'x':
            # Use X coordinates
            XAXIS_DATA, ZZ_XAXIS = np.meshgrid(X, z)
            XAXIS_DATA = np.sort(XAXIS_DATA, axis=0)
            ZZ_XAXIS = np.sort(ZZ_XAXIS, axis=0)
            # compute the depth from the surface plus the elevation
            for i in range(nd):
                ZZ_XAXIS[:,i] = ELEVATION[i]-ZZ_XAXIS[:,i]
            # Get center of grid cells
            IID = XAXIS_DATA[:,ii]
            IIZ = ZZ_XAXIS[:,ii]
            # Create x-axis values for temperature plotting
            x_axis_values = XAXIS_DATA[0,ii]
        elif xaxis == 'y':
            # Use Y coordinates
            XAXIS_DATA, ZZ_XAXIS = np.meshgrid(Y, z)
            XAXIS_DATA = np.sort(XAXIS_DATA, axis=0)
            ZZ_XAXIS = np.sort(ZZ_XAXIS, axis=0)
            # compute the depth from the surface plus the elevation
            for i in range(nd):
                ZZ_XAXIS[:,i] = ELEVATION[i]-ZZ_XAXIS[:,i]
            # Get center of grid cells
            IID = XAXIS_DATA[:,ii]
            IIZ = ZZ_XAXIS[:,ii]
            # Create x-axis values for temperature plotting
            x_axis_values = XAXIS_DATA[0,ii]
        elif xaxis == 'index':
            # Use sequential indices 0,1,2,3... for the SELECTED points only
            # Create sequential x-axis for selected indices
            n_selected = len(ii)
            sequential_x = np.arange(n_selected)
            XAXIS_SEQUENTIAL, ZZ_XAXIS = np.meshgrid(sequential_x, z)

            # For depth, we still need to use the original indices for elevation
            ZZ_ORIGINAL = np.zeros_like(ZZ_XAXIS)
            for i, orig_idx in enumerate(ii):
                ZZ_ORIGINAL[:,i] = ELEVATION[orig_idx] - z

            # Get center of grid cells - now sequential
            IID = XAXIS_SEQUENTIAL
            IIZ = ZZ_ORIGINAL
            # Create x-axis values for temperature plotting
            x_axis_values = sequential_x
        else:
            # Default to 'id' if invalid option provided
            print(f"Warning: Unknown xaxis option '{xaxis}'. Using 'id' instead.")
            XAXIS_DATA, ZZ_XAXIS = np.meshgrid(id, z)
            XAXIS_DATA = np.sort(XAXIS_DATA, axis=0)
            ZZ_XAXIS = np.sort(ZZ_XAXIS, axis=0)
            # compute the depth from the surface plus the elevation
            for i in range(nd):
                ZZ_XAXIS[:,i] = ELEVATION[i]-ZZ_XAXIS[:,i]
            # Get center of grid cells
            IID = XAXIS_DATA[:,ii]
            IIZ = ZZ_XAXIS[:,ii]
            # Create x-axis values for temperature plotting
            x_axis_values = XAXIS_DATA[0,ii]
        # IID, IIZ is the center of the cell. Create new grids, DDc, ZZc, that hold the the cordńers if the grids. 
        # DDc should have cells of size 1, while ZZc should be the same as ZZ but with a row added at the bottom that is the same as the last row of ZZ plus 100
        DDc = np.zeros((IID.shape[0]+1,IID.shape[1]+1))
        ZZc = np.zeros((IID.shape[0]+1,IID.shape[1]+1))
        DDc[:-1,:-1] = IID - 0.5
        DDc[:-1,-1] = IID[:,-1] + 0.5
        DDc[-1,:] = DDc[-2,:] + 1

        ZZc[:-1,:-1] = IIZ
        ZZc[-1,:] = ZZc[-2,:] + 1

        # Gap detection and transparency
        gap_alpha = None
        if gap_threshold is not None and len(x_axis_values) > 1:
            showInfo = kwargs.get('showInfo', 0)
            if showInfo > 0:
                print(f"Gap transparency: threshold={gap_threshold}, x_values={x_axis_values}")

            # Calculate distances between consecutive x-axis points
            x_diffs = np.diff(x_axis_values)

            # Create alpha mask for gaps: 1.0 for normal spacing, 0.0 for large gaps
            gap_alpha = np.ones(IID.shape)  # Shape: (nz, n_selected)

            # Find positions where gaps exceed threshold
            large_gaps = x_diffs > gap_threshold

            if np.any(large_gaps):
                gap_count = np.sum(large_gaps)
                if showInfo > 0:
                    print(f"Found {gap_count} large gaps (>{gap_threshold})")

                # For each large gap, make cells that fall within the gap region transparent
                for i, is_large_gap in enumerate(large_gaps):
                    if is_large_gap:
                        # Gap exists between x_axis_values[i] and x_axis_values[i+1]
                        gap_start = x_axis_values[i]
                        gap_end = x_axis_values[i+1]

                        if showInfo > 0:
                            print(f"Gap {i}: from {gap_start:.1f} to {gap_end:.1f} (width: {x_diffs[i]:.1f})")

                        # Find which cells in the DDc grid fall within this gap
                        # DDc contains the corner coordinates of each cell
                        for col in range(IID.shape[1]):
                            # Get the x-coordinate range for this column
                            cell_x_start = DDc[0, col]
                            cell_x_end = DDc[0, col + 1]

                            # Check if this cell overlaps with the gap region
                            # Cell overlaps if: cell_start < gap_end AND cell_end > gap_start
                            if cell_x_start < gap_end and cell_x_end > gap_start:
                                # This cell is within or overlaps the gap region
                                gap_alpha[:, col] = 0.0
                                if showInfo > 1:  # More verbose debugging
                                    print(f"  Made column {col} transparent (cell range: {cell_x_start:.1f}-{cell_x_end:.1f})")

    # Create a figure with 3 subplots (always create all to maintain consistent sizing)
    fig, ax = plt.subplots(3,1,figsize=(20,10), gridspec_kw={'height_ratios': [3, 3, 1]})

    # Hide panels that are not requested
    if not show_value:
        ax[0].axis('off')
    if not show_std:
        ax[1].axis('off')
    if not show_stats:
        ax[2].axis('off')

    if show_value and (nm>1) and (key=='Mean'):
        isp=0
        # MEAN
        mean_data = Mean[:,ii]
        if gap_alpha is not None:
            # Use masked array to hide gap regions completely
            mean_data = np.ma.masked_where(gap_alpha == 0.0, mean_data)

        im1 = ax[isp].pcolormesh(DDc, ZZc, mean_data,
                cmap=cmap,
                shading='auto',
                norm=LogNorm())
        im1.set_clim(clim[0],clim[1])
        # Apply uncertainty-based transparency if enabled
        if alpha>0:
            im1.set_alpha(A[:,ii])
        ax[isp].set_title('Mean %s' % name)
        ax[isp].set_ylabel('Elevation (m)')
        fig.colorbar(im1, ax=ax[isp], label='%s' % name)

    if show_value and (nm>1) and (key=='Median'):
        isp=0
        # MEDIAN
        median_data = Median[:,ii]
        if gap_alpha is not None:
            # Use masked array to hide gap regions completely
            median_data = np.ma.masked_where(gap_alpha == 0.0, median_data)

        im2 = ax[isp].pcolormesh(DDc, ZZc, median_data,
                cmap=cmap,
                shading='auto',
                norm=LogNorm())  # Set color scale to logarithmic
        im2.set_clim(clim[0],clim[1])
        # Apply uncertainty-based transparency if enabled
        if alpha>0:
            im2.set_alpha(A[:,ii])
        ax[isp].set_title('Median %s' % name)
        ax[isp].set_ylabel('Elevation (m)')
        fig.colorbar(im2, ax=ax[isp], label='%s' % name)

    if show_std and nm>1:
        isp=1
        # STD
        import matplotlib
        std_data = Std[:,ii]
        if gap_alpha is not None:
            # Use masked array to hide gap regions completely
            std_data = np.ma.masked_where(gap_alpha == 0.0, std_data)

        im3 = ax[isp].pcolormesh(DDc, ZZc, std_data,
                    cmap=matplotlib.colors.LinearSegmentedColormap.from_list("", ["white", "black", "red"]),
                    shading='auto')
        im3.set_clim(0,1)
        ax[isp].set_title('Std %s' % name)
        ax[isp].set_ylabel('Elevation (m)')
        fig.colorbar(im3, ax=ax[isp], label='Standard deviation (Ohm.m)')

    # Handle single parameter case (nm <= 1)
    if show_value and nm<=1:
        isp=1

        im3 = ax[1].plot(id[ii],Mean[:,ii].T, 'k', label='Mean')
        ax[1].plot(id[ii],Mean[:,ii].T+2*Std[:,ii].T, 'k:', label='P97.5')
        ax[1].plot(id[ii],Mean[:,ii].T-2*Std[:,ii].T, 'k:', label='P2.5')

        ax[1].plot(id[ii],Median[:,ii].T, 'r', label='Median')
        # add legend
        ax[1].legend(loc='upper right')
        # add grd on
        ax[1].grid(True)

        # set axis limits
        ax[1].set_xlim(ii.min(),ii.max())
        ax[1].set_title(name)
        ax[1].set_ylabel(name)
        ax[0].axis('off')

    ## Remove x-tick labels from non-bottom panels
    if show_value:
        ax[0].set_xticks([])
    if show_std:
        ax[1].set_xticks([])

    # Plot STATS panel (ax[2]) - only if requested
    if show_stats:
        im4 = ax[2].semilogy(x_axis_values,T[ii], 'k.', label='T')
        ax[2].set_xlim(x_axis_values.min(), x_axis_values.max())
        ax[2].set_ylim(0.99, 200)
        ax[2].set_ylabel('Temperature', color='k')
        ax[2].tick_params(axis='y', labelcolor='k')

        if LOGL_mean is not None:
            # Create second y-axis for LOGL_mean
            ax2_twin = ax[2].twinx()
            ax2_twin.plot(x_axis_values, LOGL_mean[ii], 'r.', label='LOGL_mean')
            # Add dotted red line at y=1
            ax2_twin.axhline(y=1, color='r', linestyle=':', linewidth=1, alpha=0.7)
            ax2_twin.set_ylim(0, 5)
            ax2_twin.set_ylabel('LOGL_mean', color='r')
            ax2_twin.tick_params(axis='y', labelcolor='r')

            # Combine legends from both axes
            lines1, labels1 = ax[2].get_legend_handles_labels()
            lines2, labels2 = ax2_twin.get_legend_handles_labels()
            ax[2].legend(lines1 + lines2, labels1 + labels2, loc='upper right')
        else:
            ax[2].legend(loc='upper right')

        plt.grid(True)

    plt.tight_layout()

    if show_stats and nm>1:
        # Create an invisible colorbar for the last subplot to maintain alignment
        try:
            cbar4 = fig.colorbar(im3, ax=ax[2])
            cbar4.solids.set(alpha=0)
            cbar4.outline.set_visible(False)
            cbar4.ax.set_yticks([])  # Hide the colorbar ticks
            cbar4.ax.set_yticklabels([])  # Hide the colorbar ticks labels
        except:
            pass  # If im3 doesn't exist (std panel not shown), skip colorbar


    # get filename without extension
    if kwargs['hardcopy']:
        # Add panel information to filename if panels were specified
        if panels is not None and panels != ['value', 'std', 'stats']:
            panel_str = '_panels_' + '-'.join(panels)
        else:
            panel_str = ''
        f_png = '%s__%d_%d_profile_%s%s%s.png' % (os.path.splitext(f_post_h5)[0],ii[0],ii[-1],Mstr[1:],panel_str,txt)
        plt.savefig(f_png)
    plt.show()

    return

def plot_data_xy(f_data_h5, Dkey='D1', data_key='d_obs', data_channel=0, uselog=False, clim=[], **kwargs):
    """
    Create 2D spatial plot of actual data values from electromagnetic surveys.

    Generates a scatter plot showing the spatial distribution of survey data
    with color-coding based on actual measured values. Useful for visualizing
    data distribution and identifying spatial patterns.

    Parameters
    ----------
    f_data_h5 : str
        Path to the HDF5 file containing observational data.
    Dkey : str, optional
        Data group identifier to plot (e.g., 'D1', 'D2', default is 'D1').
    data_key : str, optional
        Data dataset to plot within the group (default is 'd_obs').
        Options: 'd_obs', 'd_std', or other datasets in the data group.
    data_channel : int, optional
        Channel/gate number to plot for multi-channel data (default is 0).
        For data of shape [N_stations, N_channels], selects which channel to display.
    uselog : bool, optional
        Apply logarithmic scaling to the colorbar (default is False).
    clim : list, optional
        Color scale limits as [min, max]. If empty list, uses automatic limits
        (default is []).
    **kwargs : dict
        Additional keyword arguments:
        - hardcopy : bool, save plot as PNG file (default False)
        - s : int, marker size for scatter plot (default 20)
        - cmap : str, colormap name (default 'viridis')

    Returns
    -------
    matplotlib.figure.Figure
        The matplotlib figure object containing the plot.

    Notes
    -----
    Coordinates are automatically scaled to kilometers for better readability.
    The plot uses equal aspect ratio and includes grid lines. For multi-channel
    data, only the specified channel is displayed. Figure size is automatically 
    adjusted based on the aspect ratio of the survey area.
    """
    import matplotlib.pyplot as plt
    import matplotlib.colors
    import h5py
    import numpy as np
    
    kwargs.setdefault('hardcopy', False)
    kwargs.setdefault('s', 20)
    kwargs.setdefault('cmap', 'viridis')
    
    # Get geometry
    X, Y, LINE, ELEVATION = get_geometry(f_data_h5)
    
    # Load data
    with h5py.File(f_data_h5, 'r') as f:
        if Dkey not in f:
            raise ValueError(f"Data group '{Dkey}' not found in file")
        if data_key not in f[Dkey]:
            raise ValueError(f"Data key '{data_key}' not found in group '{Dkey}'")
            
        data = f[Dkey][data_key][:]
        
        # Get name attribute if it exists
        name_attr = f[Dkey].attrs.get('name', None)
    
    # Handle data dimensions
    if data.ndim == 1:
        plot_data = data
    elif data.ndim == 2:
        if data_channel >= data.shape[1]:
            raise ValueError(f"Channel {data_channel} not available. Data has {data.shape[1]} channels.")
        plot_data = data[:, data_channel]
    else:
        raise ValueError(f"Unsupported data dimensions: {data.shape}")
    
    # Calculate figure ratio and create plot
    ratio = (X.max()-X.min())/(Y.max()-Y.min())
    fig, ax = plt.subplots(figsize=(12, 12/ratio))
    
    # Create title
    if name_attr is not None:
        title = f"Data set {Dkey}: {name_attr} - {data_key}"
    else:
        title = f"Data set {Dkey} - {data_key}"
    
    if data.ndim == 2 and data.shape[1] > 1:
        title += f" (channel {data_channel})"
    
    ax.set_title(title)
    
    # Create scatter plot
    if uselog:
        # Handle NaN and non-positive values for log scaling
        plot_data_clean = plot_data.copy()
        plot_data_clean[~np.isfinite(plot_data_clean) | (plot_data_clean <= 0)] = 1e-12
        scatter = ax.scatter(X/1000, Y/1000, c=plot_data_clean, s=kwargs['s'], cmap=kwargs['cmap'], 
                           norm=matplotlib.colors.LogNorm())
    else:
        scatter = ax.scatter(X/1000, Y/1000, c=plot_data, s=kwargs['s'], cmap=kwargs['cmap'])
    
    # Apply colorbar limits if provided
    if len(clim) == 2:
        scatter.set_clim(clim[0], clim[1])
    
    cbar = plt.colorbar(scatter)
    cbar.set_label(f"{data_key}")
    
    ax.set_xlabel('X (km)')
    ax.set_ylabel('Y (km)')
    ax.axis('equal')
    ax.grid()

    if kwargs['hardcopy']:
        f_png = f"{os.path.splitext(f_data_h5)[0]}_{Dkey}_{data_key}_ch{data_channel}.png"
        plt.savefig(f_png)
    
    # Check if we're in a Jupyter notebook environment
    #try:
    #    # If we're in a notebook, don't call plt.show() to avoid double display
    #    get_ipython()
    #    # We're in an IPython/Jupyter environment, figure will auto-display
    #except NameError:
    #    # We're not in a notebook, need to explicitly show
    #    plt.show()
    
    return fig

def plot_data(f_data_h5, i_plot=[], Dkey=[], plType='imshow', uselog=True, **kwargs):
    """
    Plot observational data from an HDF5 file.
    
    This function creates visualizations of electromagnetic data including time-series plots,
    2D image displays, and other data representations. Supports multiple data types and
    plotting styles for comprehensive data analysis.
    
    :param f_data_h5: Path to the HDF5 file containing observational data
    :type f_data_h5: str
    :param i_plot: Indices of data points to plot. If empty, plots all available data
    :type i_plot: list or array-like, optional
    :param Dkey: Data keys/identifiers to plot. If empty, uses all available datasets
    :type Dkey: str or list, optional
    :param plType: Plotting method - 'imshow' for 2D image display, 'plot' for line plots
    :type plType: str, optional
    :param uselog: Apply logarithmic scaling to data visualization (default is True)
    :type uselog: bool, optional
    :param kwargs: Additional plotting arguments including hardcopy, figsize, colormap options
    :type kwargs: dict
    
    :returns: None (creates matplotlib plots)
    :rtype: None
    
    .. note::
        The function automatically handles different data formats and creates appropriate
        visualizations based on data dimensions and type. Supports saving plots to file
        when hardcopy=True is specified in kwargs.

    :raises: None
    """

    import numpy as np
    import matplotlib.pyplot as plt
    import matplotlib
    import h5py

    # Check if the data file f_data_h5 exists
    if not os.path.exists(f_data_h5):
        print("plot_data: File %s does not exist" % f_data_h5)
        return


    f_data = h5py.File(f_data_h5,'r')

    if len(Dkey)==0:
        nd = 0
        Dkeys = []
        for key in f_data.keys():
            if key[0]=='D':
                print("plot_data: Found data set %s" % key)
                Dkeys.append(key)
            nd += 1
        Dkey=Dkeys[0]
        print("plot_data: Using data set %s" % Dkey)
 
    noise_model = f_data['/%s' % Dkey].attrs['noise_model']
    
    # Get name attribute if it exists
    name_attr = f_data['/%s' % Dkey].attrs.get('name', None)
    
    # Force plot type for discrete/multinomial data
    if noise_model == 'multinomial' or Dkey.upper() in ['D2', 'D3', 'D4', 'D5']:
        plType = 'plot'
    
    if noise_model == 'gaussian':
        noise_model = 'Gaussian'
        d_obs = f_data['/%s' % Dkey]['d_obs'][:]
        d_std = f_data['/%s' % Dkey]['d_std'][:]


        ndata,ns = f_data['/%s' % Dkey]['d_obs'].shape
        # set i_plot as an array from 0 to ndata
        if len(i_plot)==0:
            i_plot = np.arange(ndata)
            #i_plot = 1000+np.arange(5000)

        # remove all values in i_plot that are larger than the number of data
        i_plot = i_plot[i_plot<ndata]
        # remove all values in i_plot that are smaller than 0
        i_plot = i_plot[i_plot>=0]
        
        # reaplce values larger than 1 with nan in d_std
        d_std[d_std>1] = np.nan

        # find number of nan values on d_obs
        non_nan = np.sum(~np.isnan(d_obs), axis=1)

        # Calculate the extent
        xlim = [i_plot.min(), i_plot.max()]
        extent = [xlim[0], xlim[1], 0, d_obs.shape[1]]

        # plot figure with data

        fig, ax = plt.subplots(4,1,figsize=(10,12), gridspec_kw={'height_ratios': [3, 3, 3, 1]})

        # Set suptitle with optional name attribute

        if plType=='plot':
            if uselog:
                im1 = ax[0].semilogy(d_obs[i_plot,:], linewidth=.5)
                im2 = ax[1].semilogy(d_std[i_plot,:], linewidth=.5)
                im3 = ax[2].semilogy((d_obs[i_plot,:]/d_std[i_plot,:]), linewidth=.5)
            else:
                im1 = ax[0].plot(d_obs[i_plot,:], linewidth=.5)
                im2 = ax[1].plot(d_std[i_plot,:], linewidth=.5)
                im3 = ax[2].plot((d_obs[i_plot,:]/d_std[i_plot,:]), linewidth=.5)
            ax[0].set_xlim(xlim)
            ax[1].set_xlim(xlim)
            ax[2].set_xlim(xlim)
            ax[2].set_ylim([.5, 50])
            ax[0].set_ylabel('d_obs')
            ax[1].set_ylabel('d_std')
            ax[2].set_ylabel('S/N (d_obs/d_std)')

        elif plType=='imshow':            
            if uselog:
                # Handle NaN and invalid values for LogNorm
                d_obs_clean = d_obs[i_plot,:].copy()
                d_std_clean = d_std[i_plot,:].copy()
                
                # Replace NaN/inf/zero values with small positive values for LogNorm
                d_obs_clean[~np.isfinite(d_obs_clean) | (d_obs_clean <= 0)] = 1e-12
                d_std_clean[~np.isfinite(d_std_clean) | (d_std_clean <= 0)] = 1e-12
                
                im1 = ax[0].imshow(d_obs_clean.T, aspect='auto', cmap='jet_r', norm=matplotlib.colors.LogNorm(), extent=extent)
                im2 = ax[1].imshow(d_std_clean.T, aspect='auto', cmap='hot_r', norm=matplotlib.colors.LogNorm(), extent=extent)
            else:
                im1 = ax[0].imshow(d_obs[i_plot,:].T, aspect='auto', cmap='jet_r', extent=extent)
                im2 = ax[1].imshow(d_std[i_plot,:].T, aspect='auto', cmap='hot_r', extent=extent)
            
            # For signal-to-noise ratio, handle division by zero and set reasonable limits
            snr_data = d_obs[i_plot,:] / d_std[i_plot,:]
            snr_data = np.where(np.isfinite(snr_data), snr_data, 1.0)
            im3 = ax[2].imshow(snr_data.T, aspect='auto', vmin = 0.5, vmax = 50, extent=extent)

            fig.colorbar(im1, ax=ax[0])
            fig.colorbar(im2, ax=ax[1])
            fig.colorbar(im3, ax=ax[2])
        
            ax[0].set_ylabel('gate number')
            ax[1].set_ylabel('gate number')
            ax[2].set_ylabel('gate number')
                
            ax[0].set_title('d_obs: observed data')
            ax[1].set_title('d_std: standard deviation')
            #ax[2].set_title('d_std/d_obs: relative standard deviation')
            
        
        im4 = ax[3].plot(i_plot,non_nan[i_plot], 'k.', markersize=.5)
        ax[3].set_ylabel('Number of data')
        ax[3].set_xlim(xlim)

        if plType=='imshow':            
            # Create an invisible colorbar for the last subplot
            cbar4 = fig.colorbar(im3, ax=ax[3])
            cbar4.solids.set(alpha=0)
            cbar4.outline.set_visible(False)
            cbar4.ax.set_yticks([])  # Hide the colorbar ticks
            cbar4.ax.set_yticklabels([])  # Hide the colorbar ticks labels

        ax[-1].set_xlabel('Index')
        
        ax[0].grid()
        ax[1].grid()
        ax[2].grid()
        ax[3].grid()

        if name_attr is not None:
            fig.suptitle("Dataset %s: %s" % (Dkey, name_attr))
        else:
            fig.suptitle("Dataset %s" % Dkey)

        plt.tight_layout()
    else:
        print("plot_data: Unknown noise model: %s" % noise_model)
        
    # set plot in kwarg to True if not allready set
    if 'hardcopy' not in kwargs:
        kwargs['hardcopy'] = True
    if kwargs['hardcopy']:
        # strip the filename from f_data_h5
        plt.savefig('%s_%s_%s.png' % (os.path.splitext(f_data_h5)[0],Dkey,plType))




def plot_data_prior(f_prior_data_h5,
                    f_data_h5, 
                    nr=1000,
                    id=1,
                    id_data = None,
                    d_str='d_obs', 
                    alpha=0.5,
                    ylim=None, 
                    **kwargs):
    """
    Compare observed data with prior model predictions.

    Creates a logarithmic plot showing prior data realizations (model predictions)
    overlaid with observed data. Useful for validating forward models and
    assessing prior-data compatibility before inversion.

    Parameters
    ----------
    f_prior_data_h5 : str
        Path to the HDF5 file containing prior data realizations from forward modeling.
    f_data_h5 : str
        Path to the HDF5 file containing observed data.
    nr : int, optional
        Maximum number of prior realizations to plot (default is 1000).
    id : int, optional
        Data set identifier for prior data (default is 1).
    id_data : int, optional
        Data set identifier for observed data. If None, uses same as id (default is None).
    d_str : str, optional
        Data array key within the dataset (default is 'd_obs').
    alpha : float, optional
        Transparency level for prior realization lines, range 0-1 (default is 0.5).
    ylim : tuple or list, optional
        Y-axis limits as (ymin, ymax). If None, uses automatic scaling (default is None).
    **kwargs : dict
        Additional keyword arguments:
        - hardcopy : bool, save plot as PNG file (default True)

    Returns
    -------
    bool
        True if plotting was successful.

    Notes
    -----
    Prior realizations are plotted as thin black lines with specified transparency.
    Observed data is plotted as thin red lines. The number of plotted realizations
    is limited by both the nr parameter and available data. Random sampling is
    used when more realizations are available than requested.
    """
    import h5py
    import numpy as np
    import matplotlib.pyplot as plt

    if id_data is None:
        id_data = id
    
    cols=['wheat','black','red']

    f_data = h5py.File(f_data_h5)
    f_prior_data = h5py.File(f_prior_data_h5)
    
    # Get data dimensions to determine plot type
    prior_data = None
    obs_data = None
    is_1d = False
    
    # Load prior data
    dh5_str_prior = 'D%d' % (id)
    if dh5_str_prior in f_prior_data:
        npr = f_prior_data[dh5_str_prior].shape[0]
        nr_prior = np.min([nr, npr])
        i_use = np.sort(np.random.choice(npr, nr_prior, replace=False))
        prior_data = f_prior_data[dh5_str_prior][i_use]
        
        # Check if data is 1D (only one column)
        if prior_data.shape[1] == 1:
            is_1d = True
            prior_data = prior_data.flatten()
    else:   
        print('%s not in f_prior_data' % dh5_str_prior)
    
    # Load observed data
    dh5_str_obs = 'D%d/%s' % (id_data, d_str)
    if dh5_str_obs in f_data:
        d_obs_full = f_data[dh5_str_obs][:]
        if len(d_obs_full.shape) == 1:
            d_obs_full = d_obs_full.reshape(-1, 1)
        ns, nd = d_obs_full.shape
        nr_obs = np.min([nr, ns])    
        i_use_d = np.sort(np.random.choice(ns, nr_obs, replace=False))
        obs_data = d_obs_full[i_use_d, :]
        
        # Check if observed data is also 1D
        if obs_data.shape[1] == 1:
            is_1d = True
            obs_data = obs_data.flatten()
    else:
        print('%s not in f_data' % dh5_str_obs)
    
    plt.figure(figsize=(7,6))
    
    if is_1d:
        # Create histogram plot for 1D data
        bins = 50
        
        if prior_data is not None:
            plt.hist(prior_data, bins=bins, alpha=alpha, color=cols[1], 
                    label='Prior data', density=True, histtype='stepfilled')
        
        if obs_data is not None:
            plt.hist(obs_data, bins=bins, alpha=alpha, color=cols[2], 
                    label='Observed data', density=True, histtype='stepfilled')
        
        plt.xlabel('Data Value')
        plt.ylabel('Probability Density')
        plt.legend()
        plt.title('Prior data vs Observed data (1D Histogram)')
    else:
        # Original 2D line plot
        if prior_data is not None:
            plt.semilogy(prior_data.T, '-', alpha=alpha, linewidth=0.1, 
                        color=cols[1], label='Prior data')
        
        if obs_data is not None:
            plt.semilogy(obs_data.T, '-', alpha=alpha, linewidth=0.1, 
                        label='Observed data', color=cols[2])
        
        plt.xlabel('Data #')
        plt.ylabel('Data Value')
        plt.title('Prior data (black) and observed data (red)')
    
    if ylim is not None:
        if is_1d:
            plt.xlim(ylim)  # For histogram, ylim becomes xlim
        else:
            plt.ylim(ylim)

    plt.grid()
    plt.tight_layout()
    
    f_data.close()
    f_prior_data.close()

    # set plot in kwarg to True if not allready set
    if 'hardcopy' not in kwargs:
        kwargs['hardcopy'] = True
    if kwargs['hardcopy']:
        # strip the filename from f_data_h5
        plt.savefig('%s_%s_id%d_%s.png' % (os.path.splitext(f_data_h5)[0],os.path.splitext(f_prior_data_h5)[0],id,d_str))
    plt.show()
    
    return True

def plot_data_prior_post(f_post_h5, i_plot=-1, nr=200, id=0, ylim=None, Dkey=[], **kwargs):
    """
    Compare prior predictions, posterior predictions, and observed data.

    Creates logarithmic plots showing the evolution from prior to posterior
    predictions compared to observed data. Displays data fit quality and
    sampling results with temperature and evidence information.

    Parameters
    ----------
    f_post_h5 : str
        Path to the HDF5 file containing posterior sampling results.
    i_plot : int, optional
        Index of specific observation to plot. If -1, plots random selection
        of data points (default is -1).
    nr : int, optional
        Maximum number of realizations to plot for each type (default is 200).
    id : int or list of int, optional
        Data set identifier(s) to plot. If 0, plots all available datasets.
        If list, plots each dataset separately (default is 0).
    ylim : tuple or list, optional
        Y-axis limits as (ymin, ymax). If None, uses automatic scaling (default is None).
    Dkey : list or str, optional
        Explicit data key specification. If empty, automatically detects
        available datasets (default is []).
    **kwargs : dict
        Additional keyword arguments:
        - showInfo : int, level of debug output (0=none, >0=verbose)
        - is_log : bool, use linear instead of logarithmic y-axis (default False)
        - hardcopy : bool, save plot as PNG file (default False)
        - title : str, custom title for the plot. If not provided, uses default format
          'Data set {Dkey}, Observation # {i_plot+1}'

    Returns
    -------
    None
        Function creates and displays plots but does not return values.

    Notes
    -----
    The plot shows three data types:
    - Prior realizations (wheat/gray lines): model predictions before inversion
    - Posterior realizations (black lines): model predictions after inversion 
    - Observed data (red dots with error bars): actual measurements
    
    For specific observations (i_plot >= 0), temperature and log evidence
    values are displayed. Random subsets are used when more realizations
    are available than requested.
    """
    import numpy as np
    import matplotlib.pyplot as plt
    import matplotlib
    import h5py
    import os
    
    showInfo = kwargs.get('showInfo', 0)
    is_log = kwargs.get('is_log', False)
    hardcopy = kwargs.get('hardcopy', False)
    
    ## Check if the data file f_data_h5 exists
    if not os.path.exists(f_post_h5):
        print("plot_data: File %s does not exist" % f_data_h5)
        return


    f_post = h5py.File(f_post_h5,'r')

    f_prior_h5 = f_post['/'].attrs['f5_prior']
    f_data_h5 = f_post['/'].attrs['f5_data']
    
    # Load LOGL_mean if it exists
    try:
        LOGL_mean = f_post['/LOGL_mean'][:]
    except:
        LOGL_mean = None


    # if id is a list of integers, then loop over them and call 
    # plot_data_prior_post for each id
    if isinstance(id, list):
        for i in id:
            plot_data_prior_post(f_post_h5, i_plot=i_plot, nr=nr, id=i, ylim=ylim, **kwargs)
        return

    if id==0:
        # get number of data sets in f_post_h5
        nd = 0
        id_plot = []
        with h5py.File(f_data_h5,'r') as f_data:
            for key in f_data.keys():
                if key[0]=='D':
                    if showInfo>0:
                        print("plot_data_prior_post: Found data set %s" % key)
                    nd += 1
                    id_plot.append(nd)  

        #print(id_plot)
        plot_data_prior_post(f_post_h5, i_plot=i_plot, nr=nr, id=id_plot, ylim=ylim, **kwargs)
        return

    if id>0:
        Dkey = 'D%d' % id

    f_data = h5py.File(f_data_h5,'r')
    f_prior = h5py.File(f_prior_h5,'r')

    cols=['gray','black','red']
    cols=['wheat','black','red']

    if len(Dkey)==0:
        nd = 0
        Dkeys = []
        for key in f_data.keys():
            if key[0]=='D':
                if showInfo>0:
                    print("plot_data_prior_post: Found data set %s" % key)
                Dkeys.append(key)
            nd += 1
        Dkey=Dkeys[0]
        if showInfo>0:
            print("plot_data_prior_post: Using data set %s" % Dkey)

    noise_model = f_data['/%s' % Dkey].attrs['noise_model']
    if noise_model == 'gaussian':
        noise_model = 'Gaussian'
        d_obs = f_data['/%s' % Dkey]['d_obs'][:]
        try:
            d_std = f_data['/%s' % Dkey]['d_std'][:]
        except:
            if 'Cd' in f_data['/%s' % Dkey].keys():
                # if 'Cd' is 3 dim then take the diagonal
                if len(f_data['/%s' % Dkey]['Cd'].shape)==3:
                    d_std = np.sqrt(np.diag(f_data['/%s' % Dkey]['Cd'][i_plot]))
                else:
                    d_std = np.sqrt(f_data['/%s' % Dkey]['Cd'])
            else:
                d_std = np.zeros(d_obs.shape)

        if i_plot==-1:
            # get 400 random unique index of d_obs
            i_use = np.random.choice(d_obs.shape[0], nr, replace=False)
        else:
            nr = np.min([nr,d_obs.shape[0]])
            i_use = f_post['/i_use'][i_plot,0:nr]
            i_use = i_use.flatten()
        nr=len(i_use)
        
        ns,ndata = f_data['/%s' % Dkey]['d_obs'].shape
        d_post = np.zeros((nr,ndata))
        d_prior = np.zeros((nr,ndata))
        
        N = f_prior[Dkey].shape[0]
        # set id_plot to be nr random locagtions in 1:ndata
        i_prior_plot = np.random.randint(0,N,nr)
        for i in range(nr):
            d_prior[i]=f_prior[Dkey][i_prior_plot[i],:]    
            if i_plot>-1:
                d_post[i]=f_prior[Dkey][i_use[i],:]
    
        #i_plot=[]
        fig, ax = plt.subplots(1,1,figsize=(7,7))
        if ndata>1:
            if is_log:
                if showInfo>1:
                    print('plot_data_prior_post: Plotting log10(d_prior)')
                    print('This is not implemented yet')
                ax.plot(d_prior.T,'-',linewidth=.2, label='d_prior', color=cols[0])
                ax.plot(d_post.T,'-',linewidth=.2, label='d_prior', color=cols[1])
                ax.plot(d_obs[i_plot,:],'.',markersize=6, label='d_obs', color=cols[2])
                try:
                    ax.plot(d_obs[i_plot,:]-2*d_std[i_plot,:],'-',linewidth=1, label='d_obs', color=cols[2])
                    ax.plot(d_obs[i_plot,:]+2*d_std[i_plot,:],'-',linewidth=1, label='d_obs', color=cols[2])
                except:
                    pass
                plt.ylabel('log10(dBDt)')
            else:
                ax.semilogy(d_prior.T,'-',linewidth=.2, label='d_prior', color=cols[0])

                if i_plot>-1:            
                    ax.semilogy(d_post.T,'-',linewidth=.2, label='d_prior', color=cols[1])
                
                    ax.semilogy(d_obs[i_plot,:],'.',markersize=6, label='d_obs', color=cols[2])
                    try:
                        ax.semilogy(d_obs[i_plot,:]-2*d_std[i_plot,:],'-',linewidth=1, label='d_obs', color=cols[2])
                        ax.semilogy(d_obs[i_plot,:]+2*d_std[i_plot,:],'-',linewidth=1, label='d_obs', color=cols[2])
                    except:
                        pass
                    #ax.text(0.1, 0.1, 'Data set %s, Observation # %d' % (Dkey, i_plot+1), transform=ax.transAxes)
                else:   
                    # select nr random unqiue index of d_obs
                    i_d = np.random.choice(d_obs.shape[0], nr, replace=False)
                    if is_log:
                        ax.plot(d_obs[i_d,:].T,'-',linewidth=.1, label='d_obs', color=cols[2])
                        ax.plot(d_obs[i_d,:].T,'*',linewidth=.1, label='d_obs', color=cols[2])
                    else:
                        ax.semilogy(d_obs[i_d,:].T,'-',linewidth=1, label='d_obs', color=cols[2])
                        ax.semilogy(d_obs[i_d,:].T,'*',linewidth=1, label='d_obs', color=cols[2])

                if ylim is not None:            
                    plt.ylim(ylim)
                plt.ylabel('dBDt')

                plt.xlabel('Data #')
                plt.grid()


        else:   
            # nadat=1
            plt.hist(d_prior.flatten(), bins=50, alpha=0.5, color=cols[0], label='d_prior', density=True)
            plt.hist(d_post.flatten(), bins=50, alpha=0.5, color=cols[1], label='d_post', density=True)
            # plot a vertical solid line at x=d_obs[i_plot], and two dashed lines at d_obs[i_plot]-2*d_std[i_plot] and d_obs[i_plot]+2*d_std[i_plot]
            plt.plot([d_obs[i_plot],d_obs[i_plot]], [0, plt.ylim()[1]], 'r-', label='d_obs', linewidth=2)
            
            plt.xlabel('Value')
            plt.ylabel('PDF')
            plt.legend()

            plt.grid()
        

        if i_plot>-1:
            
            ax.text(0.1, 0.1, 'T = %4.2f.' % (f_post['/T'][i_plot]), transform=ax.transAxes)
            ax.text(0.1, 0.2, 'log(EV) = %4.2f.' % (f_post['/EV'][i_plot]), transform=ax.transAxes)
            try:
                if LOGL_mean is not None:
                        ax.text(0.1, 0.3, 'LOGL_mean = %4.2f.' % (LOGL_mean[i_plot,0]), transform=ax.transAxes)
            except:
                pass
            # Use custom title if provided, otherwise use default
            if 'title' in kwargs:
                plt.title(kwargs['title'])
            else:
                plt.title('Data set %s, Observation # %d' % (Dkey, i_plot+1))


        #plt.legend()

 
        if hardcopy:
            # strip the filename from f_data_h5
            # get filename without extension of f_post_h5
            if i_plot==-1:
                plt.savefig('%s_%s.png' % (os.path.splitext(f_post_h5)[0],Dkey))
            else:
                plt.savefig('%s_%s_id%05d.png' % (os.path.splitext(f_post_h5)[0],Dkey,i_plot))
        plt.show()


def find_points_along_line_segments(X, Y, Xl, Yl, ID=None, tolerance=None, method='closest'):
    """
    Find point indices that lie along or near specified line segments.

    Parameters:
    -----------
    X : array-like
        X coordinates of points
    Y : array-like
        Y coordinates of points
    Xl : array-like
        X coordinates defining line segment endpoints (length = number of segments)
    Yl : array-like
        Y coordinates defining line segment endpoints (length = number of segments)
    ID : array-like, optional
        Point identifiers (same length as X, Y)
    tolerance : float, optional
        Maximum distance from line segments to include points
        If None, uses 1% of the maximum coordinate range
    method : str, optional
        Selection method: 'closest' (default), 'within_tolerance', or 'perpendicular'

    Returns:
    --------
    indices : numpy.ndarray
        Indices of points that lie along the line segments
    distances : numpy.ndarray
        Distances from selected points to their nearest line segments
    segment_ids : numpy.ndarray
        Which line segment each selected point is closest to

    Notes:
    ------
    For 3 line segments, len(Xl) = len(Yl) = 3, defining segments:
    - Segment 0: from (Xl[0], Yl[0]) to (Xl[1], Yl[1])
    - Segment 1: from (Xl[1], Yl[1]) to (Xl[2], Yl[2])
    - etc.

    Examples:
    ---------
    >>> X = np.array([1, 2, 3, 4, 5])
    >>> Y = np.array([1, 2, 3, 4, 5])
    >>> Xl = np.array([0, 3, 6])  # Two line segments
    >>> Yl = np.array([0, 3, 6])
    >>> indices, distances, seg_ids = find_points_along_line_segments(X, Y, Xl, Yl)
    """
    import numpy as np

    X = np.array(X)
    Y = np.array(Y)
    Xl = np.array(Xl)
    Yl = np.array(Yl)

    if len(X) != len(Y):
        raise ValueError("X and Y must have the same length")

    if len(Xl) != len(Yl):
        raise ValueError("Xl and Yl must have the same length")

    if len(Xl) < 2:
        raise ValueError("Need at least 2 points to define line segments")

    if ID is not None:
        ID = np.array(ID)
        if len(ID) != len(X):
            raise ValueError("ID must have the same length as X and Y")

    # Set default tolerance if not provided
    if tolerance is None:
        x_range = np.max(X) - np.min(X)
        y_range = np.max(Y) - np.min(Y)
        tolerance = 0.01 * max(x_range, y_range)

    n_points = len(X)
    n_segments = len(Xl) - 1

    # Store results for each point
    min_distances = np.full(n_points, np.inf)
    closest_segments = np.full(n_points, -1, dtype=int)

    # Calculate distance from each point to each line segment
    for seg_idx in range(n_segments):
        # Line segment endpoints
        x1, y1 = Xl[seg_idx], Yl[seg_idx]
        x2, y2 = Xl[seg_idx + 1], Yl[seg_idx + 1]

        # Vector from start to end of segment
        dx = x2 - x1
        dy = y2 - y1
        segment_length_sq = dx*dx + dy*dy

        if segment_length_sq < 1e-12:  # Degenerate segment (same start/end point)
            # Distance to single point
            distances = np.sqrt((X - x1)**2 + (Y - y1)**2)
        else:
            # Calculate perpendicular distance to line segment
            # Project each point onto the line segment
            t = ((X - x1) * dx + (Y - y1) * dy) / segment_length_sq

            # Clamp t to [0, 1] to stay within segment bounds
            t = np.clip(t, 0, 1)

            # Find closest points on segment
            closest_x = x1 + t * dx
            closest_y = y1 + t * dy

            # Calculate distances
            distances = np.sqrt((X - closest_x)**2 + (Y - closest_y)**2)

        # Update minimum distances and closest segments
        mask = distances < min_distances
        min_distances[mask] = distances[mask]
        closest_segments[mask] = seg_idx

    # Select points based on method
    if method == 'closest':
        # Select points within tolerance of their closest segment
        selected_mask = min_distances <= tolerance
    elif method == 'within_tolerance':
        # Same as closest for this implementation
        selected_mask = min_distances <= tolerance
    elif method == 'perpendicular':
        # Select points within tolerance and prefer perpendicular distances
        selected_mask = min_distances <= tolerance
    else:
        raise ValueError(f"Unknown method: {method}")

    # Get indices of selected points
    selected_indices = np.where(selected_mask)[0]

    return (selected_indices,
            min_distances[selected_indices],
            closest_segments[selected_indices])


def plot_prior_stats(f_prior_h5, Mkey=[], nr=100, use_log=None, showInfo=0, **kwargs):
    """
    Visualize prior model parameter distributions and sample realizations.

    Creates comprehensive plots showing parameter histograms, logarithmic
    distributions, and spatial/temporal realizations for prior model
    parameters. Useful for validating prior distributions before inversion.

    Parameters
    ----------
    f_prior_h5 : str
        Path to the HDF5 file containing prior model realizations.
    Mkey : str or list, optional
        Model parameter key(s) to plot (e.g., 'M1', 'M2'). If empty list,
        plots statistics for all available model parameters (default is []).
    nr : int, optional
        Maximum number of realizations to display in realization plots.
        Actual number used is minimum of nr and available realizations (default is 100).
    use_log : bool or None, optional
        Whether to use log10 scale for both histogram and realizations plot. If None
        (default), automatically determines scale based on data range:
        - Discrete parameters: always linear
        - Continuous parameters: log if data spans > 2 orders of magnitude, else linear
        Set to True to force log10 scale, or False to force linear scale.
        For continuous parameters, this controls both the histogram bins (log10 values)
        and the color normalization in the realizations plot (LogNorm vs linear).
    showInfo : int, optional
        Verbosity level for diagnostic output. If > 0, prints data range and
        auto-selected scale choice (default is 0).
    **kwargs : dict
        Additional keyword arguments:
        - hardcopy : bool, save plots as PNG files (default True)

    Returns
    -------
    None
        Function creates and displays plots but does not return values.

    Notes
    -----
    For continuous parameters, creates a 1x2 subplot layout with custom width ratios:
    - Left (narrow): Histogram (log10 or linear) with horizontal orientation
    - Right (wide, 2x wider): Realizations plot with corresponding normalization
      (LogNorm for log scale, linear for linear scale)

    For discrete parameters, creates similar layout but with:
    - Left (narrow): Class distribution histogram with class names (always linear)
    - Right (wide): Categorical realizations with class names and colors (always linear)

    The `use_log` parameter controls scaling for BOTH subplots:
    - Histogram: log10(values) vs linear values on y-axis
    - Realizations: LogNorm vs linear colormap normalization

    **Automatic Scale Selection (when use_log=None):**
    For continuous parameters, the function automatically chooses between log and
    linear scale based on the data range. Log scale is used if the data spans more
    than 2 orders of magnitude (e.g., 0.1 to 100 or larger), otherwise linear scale
    is used. This ensures appropriate visualization for both wide-range parameters
    (like resistivity) and narrow-range parameters (like thickness in meters).

    Color limits and colormaps are automatically retrieved from file attributes.
    Multi-dimensional parameters show spatial patterns, while single parameters
    show temporal variation.

    The layout uses matplotlib GridSpec with width_ratios=[1, 2] to make the
    realizations subplot wider than the histogram subplot.

    Examples
    --------
    >>> # Plot with default (log10 for continuous, linear for discrete)
    >>> plot_prior_stats('prior.h5', Mkey='M1')
    >>>
    >>> # Force linear scale for continuous parameter
    >>> plot_prior_stats('prior.h5', Mkey='M1', use_log=False)
    >>>
    >>> # Force log scale
    >>> plot_prior_stats('prior.h5', Mkey='M1', use_log=True)
    """
    from matplotlib.colors import LogNorm
    
    f_prior = h5py.File(f_prior_h5,'r')

    # If Mkey is not set, plot for all M* keys in prior and return
    if len(Mkey)==0:
        for key in f_prior.keys():
            if (key[0]=='M'):
                plot_prior_stats(f_prior_h5, Mkey=key, nr=nr, use_log=use_log, showInfo=showInfo, **kwargs)

        f_prior.close()
        return  

    if Mkey[0]!='/':
        Mkey = '/%s' % Mkey

    # check if Mkey is in the keys of f_prior
    if Mkey not in f_prior.keys():
        print("Mkey=%s not found in %s" % (Mkey, f_prior_h5))
        return

    # check if name is in the attributes of key Mkey
    if 'name' in f_prior['/%s'%Mkey].attrs.keys():
        name = '%s:%s' %  (Mkey[1::],f_prior['/%s'%Mkey].attrs['name'][:])
        name = '%s' %  (f_prior['/%s'%Mkey].attrs['name'][:])


        #print(name)
    else:
        name = Mkey


    f_prior['/%s'%Mkey].attrs.keys()
    if 'x' in f_prior['/%s'%Mkey].attrs.keys():
        z = f_prior['/%s'%Mkey].attrs['x']
    else:
        z = f_prior['/%s'%Mkey].attrs['z']


    # update nr if it is larger than the number of realizations in f_prior[Mkey]
    if len(f_prior[Mkey][:])<nr:
        nr = np.min([nr, len(f_prior[Mkey][:])])
        print('plot_prior_stats: Using %d realizations' % nr)

    M = f_prior[Mkey][:]
    N, Nm = M.shape
    clim,cmap = h5_get_clim_cmap(f_prior_h5, Mstr=Mkey)

    is_discrete = f_prior['/%s'%Mkey].attrs['is_discrete']

    # Determine whether to use log scale
    if use_log is None:
        # Automatic selection based on data characteristics
        if is_discrete:
            # Always use linear for discrete parameters
            use_log_scale = False
        else:
            # For continuous parameters, check if data spans many orders of magnitude
            M_positive = M[M > 0]  # Only consider positive values
            if len(M_positive) > 0:
                data_min = np.min(M_positive)
                data_max = np.max(M_positive)
                # Use log if data spans more than 2 orders of magnitude
                orders_of_magnitude = np.log10(data_max / data_min)
                use_log_scale = orders_of_magnitude > 2.0
                if showInfo > 0:
                    print(f'plot_prior_stats: Data range: {data_min:.2e} to {data_max:.2e} ({orders_of_magnitude:.1f} orders of magnitude)')
                    print(f'plot_prior_stats: Auto-selected {"log" if use_log_scale else "linear"} scale')
            else:
                # No positive values, use linear
                use_log_scale = False
    else:
        # User explicitly set use_log
        use_log_scale = use_log

    if not is_discrete:
        # CONTINUOUS

        # Create figure with GridSpec for custom layout (left narrow, right wide)
        fig = plt.figure(figsize=(14, 6))
        import matplotlib.gridspec as gridspec
        gs = gridspec.GridSpec(1, 2, width_ratios=[1, 2], figure=fig)

        # Left subplot: Histogram (log or linear)
        ax_left = fig.add_subplot(gs[0])

        if use_log_scale:
            # Log10 histogram
            M_hist = M.flatten()
            M_hist = M_hist[M_hist > 0]  # Remove zeros and negative values
            if len(M_hist) > 0:
                m1 = ax_left.hist(np.log10(M_hist), 101, orientation='horizontal')
            else:
                # If no positive values, create empty histogram
                m1 = ax_left.hist([], 101, orientation='horizontal')

            ax_left.set_ylabel('log10(%s)' % name)

            # Set ytick labels as 10^x where x is the ytick value
            ax_left.set_yticks(ax_left.get_yticks())  # Ensure ticks are set
            ticks = ax_left.get_yticks()
            ax_left.set_yticks(ticks)
            ax_left.set_yticklabels(['$10^{%3.1f}$'%i for i in ticks])
        else:
            # Linear histogram
            M_hist = M.flatten()
            m1 = ax_left.hist(M_hist, 101, orientation='horizontal')
            ax_left.set_ylabel(name)

        ax_left.set_xlabel('Counts')
        ax_left.grid()

        # Right subplot: Realizations (wider)
        ax_right = fig.add_subplot(gs[1])

        X,Y = np.meshgrid(np.arange(1,nr+1),z)
        ax_right.invert_yaxis()
        if Nm>1:
            # Apply log or linear normalization based on use_log_scale
            if use_log_scale:
                m2 = ax_right.pcolor(X,Y,M[0:nr,:].T,
                                cmap=cmap,
                                shading='auto',
                                norm=LogNorm())
            else:
                m2 = ax_right.pcolor(X,Y,M[0:nr,:].T,
                                cmap=cmap,
                                shading='auto')
            # set clim to clim
            m2.set_clim(clim[0],clim[1])
            fig.colorbar(m2, ax=ax_right, label=Mkey[1::])
        else:
            m2 = ax_right.plot(np.arange(1,nr+1),M[0:nr,:].flatten())
            ax_right.set_xlim(1,nr)

        ax_right.set_xlabel('Realization #')
        ax_right.set_ylabel(name)

        tit = '%s - %s ' % (os.path.splitext(f_prior_h5)[0],name)
        plt.suptitle(tit)

    else:
        # DISCRETE

        # get attribute class_name if it exist

        if 'class_id' in f_prior[Mkey].attrs.keys():
            class_id = f_prior[Mkey].attrs['class_id'][:].flatten()
        else:
            print('No class_id found')
        if 'class_name' in f_prior[Mkey].attrs.keys():
            class_name = f_prior[Mkey].attrs['class_name'][:].flatten()
        else:
            class_name = []
        n_class = len(class_name)

        # Create figure with GridSpec for custom layout (left narrow, right wide)
        fig = plt.figure(figsize=(14, 6))
        import matplotlib.gridspec as gridspec
        gs = gridspec.GridSpec(1, 2, width_ratios=[1, 3], figure=fig)

        # Left subplot: Histogram (for discrete, we can show class distribution)
        ax_left = fig.add_subplot(gs[0])

        # Create histogram with class boundaries
        m1 = ax_left.hist(M.flatten(), bins=np.arange(0.5, n_class+1.5, 1), orientation='horizontal')
        ax_left.set_ylabel(name)
        ax_left.set_xlabel('Counts')
        ax_left.set_yticks(np.arange(n_class)+1)
        ax_left.set_yticklabels(class_name)
        ax_left.grid()

        # Right subplot: Realizations (wider)
        ax_right = fig.add_subplot(gs[1])

        X,Y = np.meshgrid(np.arange(1,nr+1),z)
        ax_right.invert_yaxis()
        if Nm>1:
            m2 = ax_right.pcolor(X,Y,M[0:nr,:].T,
                            cmap=cmap,
                            shading='auto')
            # set clim to clim
            m2.set_clim(clim[0]-.5,clim[1]+.5)
            cbar1 = fig.colorbar(m2, ax=ax_right, label='%s : %s' %(Mkey[1::],name))
            cbar1.set_ticks(np.arange(n_class)+1)
            cbar1.set_ticklabels(class_name)
            cbar1.ax.invert_yaxis()
        else:
            m2 = ax_right.plot(np.arange(1,nr+1),M[0:nr,:].flatten())
            ax_right.set_xlim(1,nr)

        ax_right.set_xlabel('Realization #')
        ax_right.set_ylabel('Depth (m)')

        tit = '%s - %s ' % (os.path.splitext(f_prior_h5)[0],name)
        #plt.suptitle(tit)

    f_prior.close()

    if 'hardcopy' not in kwargs:
        kwargs['hardcopy'] = True
    if kwargs['hardcopy']:
        # strip the filename from f_data_h5
        plt.savefig('%s_%s.png' % (os.path.splitext(f_prior_h5)[0],Mkey[1::]))


# function that reads cmap and clim if they are set
def h5_get_clim_cmap(f_prior_h5, Mstr='/M1'):
    """
    Retrieve color scale limits and colormap from prior model attributes.

    Extracts visualization parameters stored in HDF5 file attributes,
    providing default values when attributes are not present. Used by
    plotting functions for consistent color scaling across visualizations.

    Parameters
    ----------
    f_prior_h5 : str
        Path to the HDF5 file containing prior model data.
    Mstr : str, optional
        Model parameter key string (e.g., '/M1', '/M2', default is '/M1').

    Returns
    -------
    clim : list
        Color scale limits as [min_value, max_value]. Returns [10, 500]
        as default if 'clim' attribute is not found.
    cmap : matplotlib.colors.ListedColormap or str  
        Colormap object created from stored colormap array, or 'jet'
        string as default if 'cmap' attribute is not found.

    Notes
    -----
    The function automatically converts stored colormap arrays to matplotlib
    ListedColormap objects with proper transposition. Color limits and
    colormaps are typically set during prior model generation to ensure
    consistent visualization across different plotting functions.
    """
    with h5py.File(f_prior_h5,'r') as f_prior:
        if 'clim' in f_prior[Mstr].attrs.keys():
            clim = f_prior[Mstr].attrs['clim'][:].flatten()
        else:
            clim = [.1, 2600]
            clim = [10, 500]
        if 'cmap' in f_prior[Mstr].attrs.keys():
            cmap = f_prior[Mstr].attrs['cmap'][:]
            from matplotlib.colors import ListedColormap
            cmap = ListedColormap(cmap.T)
        else:
            cmap = 'jet'

        return clim, cmap


def plot_cumulative_probability_profile(P_hypothesis, i1=0, i2=0, label=None, colors = None, hardcopy=True, name='cumulative_probability_profile'):
    """
    Plot the cumulative probability profile of different hypotheses.
    
    This function visualizes how the probability of different hypotheses accumulates
    over a sequence of data points, with each hypothesis represented as a colored
    area in a stacked plot.
    
    :param P_hypothesis: A 2D array where each row represents a hypothesis and each column represents a data point. Values should be probabilities
    :type P_hypothesis: numpy.ndarray
    :param i1: Starting index for the x-axis (data points)
    :type i1: int, optional
    :param i2: Ending index for the x-axis (data points). If 0, uses the number of data points in P_hypothesis
    :type i2: int, optional
    :param label: List of labels for each hypothesis. If None, generic labels will be created
    :type label: list of str, optional
    :param colors: List of colors for each hypothesis. If None, colors from the 'hot' colormap will be used
    :type colors: list or numpy.ndarray, optional
    :param hardcopy: If True, saves the figure to a file
    :type hardcopy: bool, optional
    :param name: Base name for the output file when hardcopy is True
    :type name: str, optional
    
    :returns: None (displays the plot and optionally saves it to a file)
    :rtype: None
    
    .. note::
        The plot shows how probabilities accumulate across hypotheses, with each hypothesis
        represented as a colored band. The total height of all bands at any x position equals 1.0
        (or the sum of probabilities for that data point).
    """

    import matplotlib.pyplot as plt
    import numpy as np

    nhypothesis = P_hypothesis.shape[0]

    if i2==0:
        i2 = P_hypothesis.shape[1]

    if label is None:
        # Generate  list of length nhypothesis, with generic label names
        label = [f'Hypothesiss {i+1}' for i in range(nhypothesis)]

    # Define nypothesis colors from the hot colormap
    if colors is None:
        colors = plt.cm.hot(np.linspace(0, 1, nhypothesis))

    ii  = np.arange(i1,i2,1)
    P_hypothesis_plot = P_hypothesis[:,ii]
    fig, ax = plt.subplots(figsize=(12, 6))

    
    # Calculate cumulative probabilities
    cum_probs = np.zeros((P_hypothesis_plot.shape[0] + 1, P_hypothesis_plot.shape[1]))
    for i in range(P_hypothesis_plot.shape[0]):
        cum_probs[i+1] = cum_probs[i] + P_hypothesis_plot[i]

    # Plot filled areas between cumulative probabilities
    for i in range(P_hypothesis_plot.shape[0]):
        ax.fill_between(
            ii, 
            cum_probs[i], 
            cum_probs[i+1], 
            color=colors[i], 
            alpha=0.7,
            label=label[i]
        )

    # Add labels and title
    ax.set_xlabel('Data point index')
    ax.set_ylabel('Cumulative Probability')
    ax.set_title('Cumulative Probability of Hypotheses')
    ax.legend(loc='upper right')

    # Optional: Limit x-axis if needed to focus on a specific range
    # ax.set_xlim(0, 1000)  # Uncomment to focus on first 1000 data points

    plt.tight_layout()
    # Save the figure if hardcopy is True
    if hardcopy:
        plt.savefig(name, dpi=300)
        print("Saved figure as %s.png" % (name))
    plt.show()
    

