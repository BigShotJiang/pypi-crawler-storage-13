""" Simple module """
