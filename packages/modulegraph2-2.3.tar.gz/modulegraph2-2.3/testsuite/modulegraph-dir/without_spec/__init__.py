del __spec__
