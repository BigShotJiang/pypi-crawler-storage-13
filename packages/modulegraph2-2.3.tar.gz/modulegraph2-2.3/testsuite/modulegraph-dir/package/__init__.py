""" init """
foo = 42
