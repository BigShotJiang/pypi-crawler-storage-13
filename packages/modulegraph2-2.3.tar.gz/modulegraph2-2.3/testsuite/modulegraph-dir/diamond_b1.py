import diamond_c
