# AiAgentic_Wrap

A lightweight and extensible agent framework for LLM-powered automation.

## Installation
pip install aiagentic_wrap

## Usage
```python
from aiagentic_wrap import Agent

agent = Agent("TestAgent")
print(agent.run("Say Hello"))
