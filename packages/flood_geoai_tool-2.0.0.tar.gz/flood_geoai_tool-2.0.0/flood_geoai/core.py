import rasterio
import geopandas as gpd
import numpy as np
from shapely.geometry import shape
from skimage import measure
import torch
import torch.nn as nn
import os
import json
from .models.hf_model_manager import HuggingFaceModelManager

class FlexibleModelLoader:
    """Handles loading of various model architectures"""
    
    @staticmethod
    def create_compatible_model(state_dict, in_channels=6, num_classes=2):
        """Create a model architecture compatible with the state dict"""
        print("Analyzing state dict architecture...")
        keys = list(state_dict.keys())
        print(f"First 10 keys: {keys[:10]}")
        
        # Check for ResNet encoder patterns
        if any('encoder.conv1.weight' in key for key in keys):
            print("Detected ResNet-based U-Net architecture (from segmentation_models_pytorch)")
            from .models.flood_model import FloodDetectionModel
            model = FloodDetectionModel(num_channels=in_channels, num_classes=num_classes)
            
            try:
                # Try strict loading first
                model.load_state_dict(state_dict)
                print("✓ Successfully loaded with strict=True")
                return model
            except:
                # Fall back to partial loading
                print("Trying partial loading (strict=False)...")
                model.load_state_dict(state_dict, strict=False)
                print("✓ Successfully loaded with strict=False")
                return model
        
        # Fallback to simple U-Net
        print("Using fallback U-Net architecture")
        from .models.flood_model import CompatibleUNet
        model = CompatibleUNet(in_channels=in_channels, out_channels=num_classes)
        model.load_state_dict(state_dict, strict=False)
        return model

class FloodGeoAITool:
    def __init__(self, model_path=None, model_name='default', repo_id=None):
        """
        Initialize the GeoAI tool with your trained model.
        """
        # Set device first
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
        # Set Hugging Face repo if using HF models
        if repo_id is None:
            repo_id = "yourusername/flood-detection-model"
        
        self.model_manager = HuggingFaceModelManager(repo_id)
        
        if model_path:
            # Use custom model path
            self.model_path = model_path
            print(f"Using custom model: {model_path}")
        else:
            # Download from Hugging Face
            self.model_path = self.model_manager.get_model_path(model_name)
            print(f"Using pre-trained model: {model_name}")
            
        self.model = self.load_model()
        print(f"✓ Model loaded successfully")
        
    def load_model(self):
        """
        Load your trained flood detection model.
        Handles various model formats and architectures.
        """
        try:
            # Load the model file
            model_data = torch.load(self.model_path, map_location='cpu')
            print(f"Loaded model data type: {type(model_data)}")
            
            if isinstance(model_data, dict):
                print("Detected state dictionary format")
                # Use flexible model loader
                model = FlexibleModelLoader.create_compatible_model(model_data)
            else:
                print("Detected complete model object")
                model = model_data
            
            model.eval()
            model = model.to(self.device)
            
            # Verify model can make predictions
            self._verify_model(model)
            
            return model
            
        except Exception as e:
            print(f"Error loading model: {e}")
            print("\nTroubleshooting options:")
            print("1. Check if the model file is corrupted")
            print("2. Try downloading the model again")
            print("3. Ensure PyTorch versions are compatible")
            print("4. Contact model provider for architecture details")
            raise
    
    def _verify_model(self, model):
        """Verify that the model can process input correctly"""
        print("Verifying model functionality...")
        try:
            # Test with integer input to match our preprocessing
            test_input = torch.randint(0, 10000, (1, 6, 256, 256), dtype=torch.float32).to(self.device)
            with torch.no_grad():
                test_output = model(test_input)
            print(f"✓ Model test passed. Input: {test_input.shape}, Output: {test_output.shape}")
        except Exception as e:
            print(f"✗ Model test failed: {e}")
            raise

    def preprocess_image(self, image_array, normalize=True):
        """
        Preprocess the satellite image.
        Optionally keep as integers or normalize to [0,1].
        """
        original_dtype = image_array.dtype
        print(f"Original image dtype: {original_dtype}")
        
        if normalize:
            # Normalize to [0, 1] range
            if image_array.dtype == np.uint16:
                image_array = image_array.astype(np.float32) / 65535.0
                print("Normalized uint16 to [0,1] range")
            elif image_array.dtype == np.uint8:
                image_array = image_array.astype(np.float32) / 255.0
                print("Normalized uint8 to [0,1] range")
            else:
                image_array = image_array.astype(np.float32)
                print("Converted to float32")
        else:
            # Keep as integers, just ensure correct dtype
            if image_array.dtype in [np.uint8, np.uint16, np.int16, np.int32]:
                # Keep original integer type
                print(f"Keeping original integer type: {image_array.dtype}")
            else:
                # Convert to int32 for consistency
                image_array = image_array.astype(np.int32)
                print("Converted to int32")
            
        # Ensure the image has the right number of bands and order
        if len(image_array.shape) == 2:  # Single band
            image_array = np.expand_dims(image_array, axis=0)
        elif len(image_array.shape) == 3:  # Multiple bands
            # Move channels to first dimension if needed (H,W,C) -> (C,H,W)
            if image_array.shape[2] <= 6:  # If channels are last
                image_array = np.moveaxis(image_array, 2, 0)
        
        print(f"Final image dtype: {image_array.dtype}")
        print(f"Value range: [{image_array.min()}, {image_array.max()}]")
        
        return image_array

    def select_sentinel_bands(self, image_array, band_indices=[1, 2, 3, 7, 10, 11]):
        """
        Select specific Sentinel-2 bands that your model was trained on.
        Band indices: 2, 3, 4, 8, 11, 12 (0-indexed: 1, 2, 3, 7, 10, 11)
        """
        if image_array.shape[0] >= 12:  # Has at least 12 bands (full Sentinel-2)
            selected_bands = image_array[band_indices, :, :]
            print(f"Selected Sentinel-2 bands: {[i+1 for i in band_indices]}")
            return selected_bands
        elif image_array.shape[0] == 6:
            print("Image already has 6 bands - assuming correct band order")
            return image_array
        else:
            print(f"Warning: Image has {image_array.shape[0]} bands, expected 6 or 12")
            print("Using first 6 bands available")
            return image_array[:6, :, :]

    def detect_surface_water(self, image_path, confidence_threshold=0.5, normalize_input=True):
        """
        Run your trained model on the satellite image to detect water.
        Returns a binary water mask.
        """
        with rasterio.open(image_path) as src:
            # Read all bands
            image_data = src.read()
            transform = src.transform
            crs = src.crs
        
        print(f"Input image shape: {image_data.shape}")
        print(f"Image has {image_data.shape[0]} bands")
        print(f"Original data type: {image_data.dtype}")
        
        # Select the specific Sentinel-2 bands your model was trained on
        processed_image = self.select_sentinel_bands(image_data)
        print(f"After band selection: {processed_image.shape}")
        
        # Preprocess the image (optionally keep as integers)
        processed_image = self.preprocess_image(processed_image, normalize=normalize_input)
        print(f"Processed image shape: {processed_image.shape}")
        print(f"Final data type: {processed_image.dtype}")
        print(f"Value range: [{processed_image.min()}, {processed_image.max()}]")
        
        # Convert to tensor - use appropriate dtype
        if processed_image.dtype in [np.float32, np.float64]:
            input_tensor = torch.from_numpy(processed_image).unsqueeze(0).float().to(self.device)
        else:
            # For integer types, convert to float32 but keep integer values
            input_tensor = torch.from_numpy(processed_image.astype(np.float32)).unsqueeze(0).to(self.device)
        
        print(f"Input tensor shape: {input_tensor.shape}")
        print(f"Input tensor dtype: {input_tensor.dtype}")
        print(f"Input tensor range: [{input_tensor.min().item():.1f}, {input_tensor.max().item():.1f}]")
        
        # Run inference
        with torch.no_grad():
            if self.model is not None:
                output = self.model(input_tensor)
                print(f"Model output shape: {output.shape}")
                
                # Handle model output - your model has 2 classes (background=0, water=1)
                if output.shape[1] == 2:  # 2-class segmentation
                    # Apply softmax and get water class (class 1)
                    probabilities = torch.softmax(output, dim=1)
                    water_probabilities = probabilities[:, 1, :, :]  # Class 1 is water
                    water_mask = (water_probabilities.squeeze().cpu().numpy() > confidence_threshold).astype(np.uint8)
                elif output.shape[1] == 1:  # Binary segmentation with sigmoid
                    predictions = torch.sigmoid(output).squeeze().cpu().numpy()
                    water_mask = (predictions > confidence_threshold).astype(np.uint8)
                else:
                    raise ValueError(f"Unexpected number of output classes: {output.shape[1]}")
            else:
                # Fallback if model loading failed
                print("Using fallback water detection")
                water_mask = self.fallback_water_detection(processed_image)
        
        print(f"Water mask shape: {water_mask.shape}")
        print(f"Water pixels detected: {np.sum(water_mask)} ({np.sum(water_mask)/water_mask.size*100:.2f}%)")
        
        return water_mask, transform, crs

    def fallback_water_detection(self, image_data):
        """Fallback water detection using NDWI."""
        if image_data.shape[0] >= 4:
            green = image_data[2]  # Green band
            nir = image_data[3]    # NIR band
        else:
            green = image_data[1]
            nir = image_data[0]
            
        ndwi = (green - nir) / (green + nir + 1e-8)
        water_mask = (ndwi > 0.2).astype(np.uint8)
        return water_mask

    def polygonize_water_mask(self, water_mask, transform, crs, min_area=1000):
        """Convert raster mask to vector polygons."""
        contours = measure.find_contours(water_mask, 0.5)
        
        polygons = []
        for contour in contours:
            coords = [rasterio.transform.xy(transform, row, col) for row, col in contour]
            polygon = shape({"type": "Polygon", "coordinates": [coords]})
            
            if polygon.area >= min_area:
                polygons.append(polygon)
        
        if polygons:
            water_gdf = gpd.GeoDataFrame({
                'id': range(len(polygons)),
                'class': ['water'] * len(polygons),
                'area_sq_m': [poly.area for poly in polygons],
                'geometry': polygons
            }, crs=crs)
            return water_gdf
        else:
            return gpd.GeoDataFrame(columns=['id', 'class', 'area_sq_m', 'geometry'], crs=crs)

    def analyze_flood_impact(self, water_polygons_gdf, buildings_gdf):
        """Analyze flood impact on buildings."""
        buildings_gdf = buildings_gdf.copy()
        buildings_gdf['flood_status'] = 'dry'
        
        if water_polygons_gdf.empty:
            stats = {
                'total_buildings': len(buildings_gdf),
                'flooded_buildings': 0,
                'flooded_percentage': 0.0,
                'total_water_area': 0.0
            }
            return buildings_gdf, stats
        
        water_union = water_polygons_gdf.unary_union
        buildings_in_water_mask = buildings_gdf.geometry.intersects(water_union)
        buildings_gdf.loc[buildings_in_water_mask, 'flood_status'] = 'flooded'
        
        stats = {
            'total_buildings': len(buildings_gdf),
            'flooded_buildings': buildings_in_water_mask.sum(),
            'flooded_percentage': (buildings_in_water_mask.sum() / len(buildings_gdf)) * 100,
            'total_water_area': water_polygons_gdf.geometry.area.sum()
        }
        
        print(f"Found {stats['flooded_buildings']} flooded buildings out of {stats['total_buildings']} total")
        return buildings_gdf, stats

    def generate_risk_map(self, buildings_gdf, water_polygons_gdf, buffer_distance=50):
        """Generate flood risk map."""
        buildings_gdf = buildings_gdf.copy()
        
        if water_polygons_gdf.empty:
            buildings_gdf['risk_level'] = 'low'
            return buildings_gdf
        
        water_union = water_polygons_gdf.unary_union
        high_risk_zone = water_union.buffer(buffer_distance)
        medium_risk_zone = water_union.buffer(buffer_distance * 2).difference(high_risk_zone)
        
        def assign_risk(geometry, flood_status):
            if flood_status == 'flooded':
                return 'very high'
            elif geometry.intersects(high_risk_zone):
                return 'high'
            elif geometry.intersects(medium_risk_zone):
                return 'medium'
            else:
                return 'low'
        
        buildings_gdf['risk_level'] = buildings_gdf.apply(
            lambda row: assign_risk(row.geometry, row.flood_status), 
            axis=1
        )
        
        return buildings_gdf

    def run_analysis(self, satellite_image_path, building_footprints_path, output_dir="./output", 
                    confidence_threshold=0.5, use_integer_values=False):
        """
        Run complete flood analysis pipeline.
        
        Args:
            use_integer_values: If True, preserve integer pixel values during processing
        """
        os.makedirs(output_dir, exist_ok=True)
        
        print("Step 1: Detecting surface water...")
        water_mask, transform, crs = self.detect_surface_water(
            satellite_image_path, confidence_threshold, normalize_input=not use_integer_values
        )
        
        print("Step 2: Converting water mask to polygons...")
        water_polygons = self.polygonize_water_mask(water_mask, transform, crs)
        
        print("Step 3: Loading building footprints...")
        buildings = gpd.read_file(building_footprints_path)
        print(f"Loaded {len(buildings)} buildings")
        
        if buildings.crs != crs:
            print(f"Converting buildings CRS from {buildings.crs} to {crs}")
            buildings = buildings.to_crs(crs)
        
        print("Step 4: Analyzing flood impact...")
        buildings_with_status, stats = self.analyze_flood_impact(water_polygons, buildings)
        
        print("Step 5: Generating risk map...")
        risk_map = self.generate_risk_map(buildings_with_status, water_polygons)
        
        print("Step 6: Saving results...")
        if not water_polygons.empty:
            water_polygons.to_file(f"{output_dir}/detected_water.shp")
            print(f"Saved water polygons: {len(water_polygons)} features")
        
        risk_map.to_file(f"{output_dir}/flood_risk_map.shp")
        print(f"Saved risk map: {len(risk_map)} buildings")
        
        if 'flood_status' in risk_map.columns:
            flooded_buildings = risk_map[risk_map['flood_status'] == 'flooded']
            if not flooded_buildings.empty:
                flooded_buildings.to_file(f"{output_dir}/flooded_buildings.shp")
                print(f"Saved flooded buildings: {len(flooded_buildings)} buildings")
        
        # Save statistics as JSON
        with open(f"{output_dir}/statistics.json", 'w') as f:
            json.dump(stats, f, indent=2)
        
        print("\n" + "="*50)
        print("ANALYSIS COMPLETE!")
        print("="*50)
        print(f"Total buildings: {stats['total_buildings']}")
        print(f"Flooded buildings: {stats['flooded_buildings']}")
        print(f"Flood percentage: {stats['flooded_percentage']:.2f}%")
        print(f"Total water area: {stats['total_water_area']:.2f} sq units")
        print(f"Results saved to: {output_dir}")
        print("="*50)
        
        return risk_map, water_polygons, stats

    def debug_model_info(self):
        """Debug method to inspect the loaded model."""
        print("=== Model Debug Information ===")
        print(f"Model type: {type(self.model)}")
        print(f"Model device: {next(self.model.parameters()).device}")
        
        total_params = sum(p.numel() for p in self.model.parameters())
        print(f"Total parameters: {total_params:,}")
        
        # Test model with proper input
        try:
            test_input = torch.randn(1, 6, 256, 256).to(self.device)
            with torch.no_grad():
                test_output = self.model(test_input)
            print(f"Model test successful. Input: {test_input.shape}, Output: {test_output.shape}")
        except Exception as e:
            print(f"Model test failed: {e}")