"""
Command-line interface for Flood GeoAI Tool.
"""

import argparse
import sys
from .core import FloodGeoAITool

def main():
    parser = argparse.ArgumentParser(description='Flood GeoAI Tool - Flood Risk Assessment')
    
    # Model options
    model_group = parser.add_argument_group('Model options')
    model_group.add_argument('--model', '-m', help='Path to custom model file')
    model_group.add_argument('--model-name', default='default', 
                           help='Pre-trained model to use')
    model_group.add_argument('--hf-repo', default='hatimoo22/flood-detection-model',
                           help='Hugging Face repository ID')
    model_group.add_argument('--list-models', action='store_true',
                           help='List available pre-trained models')
    
    # Analysis options
    analysis_group = parser.add_argument_group('Analysis options')
    analysis_group.add_argument('--image', '-i', required=True, help='Path to satellite image')
    analysis_group.add_argument('--buildings', '-b', required=True, help='Path to building footprints')
    analysis_group.add_argument('--output', '-o', default='./output', help='Output directory')
    analysis_group.add_argument('--confidence', '-c', type=float, default=0.5,
                               help='Confidence threshold for water detection')
    analysis_group.add_argument('--use-integer-values', action='store_true',
                               help='Preserve integer pixel values during processing')
    
    args = parser.parse_args()
    
    try:
        if args.list_models:
            tool = FloodGeoAITool(repo_id=args.hf_repo)
            models = tool.model_manager.list_available_models()
            print("Available pre-trained models:")
            for name, info in models.items():
                print(f"  {name}: {info['description']} ({info['size_mb']} MB)")
            return
        
        # Initialize tool
        tool = FloodGeoAITool(
            model_path=args.model,
            model_name=args.model_name,
            repo_id=args.hf_repo
        )
        
        # Run analysis
        results = tool.run_analysis(
            satellite_image_path=args.image,
            building_footprints_path=args.buildings,
            output_dir=args.output,
            confidence_threshold=args.confidence,
            use_integer_values=args.use_integer_values
        )
        
        print("✓ Analysis completed successfully!")
        print(f"Results saved to: {args.output}")
        
    except Exception as e:
        print(f"✗ Error: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()