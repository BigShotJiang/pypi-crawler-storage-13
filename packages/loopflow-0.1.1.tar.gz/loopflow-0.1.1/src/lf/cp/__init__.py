"""cp - Copy codebase context to clipboard for LLM interactions."""
