"""Command runner tools - shell command execution."""

import logging
import subprocess
import time
from typing import Dict, Any

logger = logging.getLogger(__name__)


def _run_shell_command(command: str, cwd: str = None, timeout: int = 60) -> Dict[str, Any]:
    """Execute a shell command and return results."""
    if not command or not command.strip():
        return {
            'success': False,
            'command': command,
            'error': 'Command cannot be empty',
            'stdout': None,
            'stderr': None,
            'exit_code': None,
            'execution_time': None
        }

    start_time = time.time()

    try:
        # Run the command with timeout
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=timeout
        )

        execution_time = time.time() - start_time

        # Limit output length to prevent massive token usage
        stdout = result.stdout
        stderr = result.stderr

        # Truncate if too long (keep last 50000 chars)
        if stdout and len(stdout) > 50000:
            stdout = "... [truncated] ...\n" + stdout[-50000:]
        if stderr and len(stderr) > 50000:
            stderr = "... [truncated] ...\n" + stderr[-50000:]

        return {
            'success': result.returncode == 0,
            'command': command,
            'stdout': stdout,
            'stderr': stderr,
            'exit_code': result.returncode,
            'execution_time': execution_time
        }

    except subprocess.TimeoutExpired:
        execution_time = time.time() - start_time
        return {
            'success': False,
            'command': command,
            'error': f'Command timed out after {timeout} seconds',
            'stdout': None,
            'stderr': None,
            'exit_code': -1,
            'execution_time': execution_time,
            'timeout': True
        }

    except Exception as e:
        execution_time = time.time() - start_time
        return {
            'success': False,
            'command': command,
            'error': f'Error executing command: {str(e)}',
            'stdout': None,
            'stderr': None,
            'exit_code': -1,
            'execution_time': execution_time
        }


def register_command_tools(server):
    """
    Register command runner tools with the server.

    Args:
        server: ToolServer instance
    """

    async def run_shell_command_impl(command: str, cwd: str = None, timeout: int = 60):
        """Execute a shell command."""
        return _run_shell_command(command, cwd, timeout)

    async def share_reasoning_impl(reasoning: str, next_steps: str = None):
        """Share agent reasoning.

        This is a no-op in the standalone tool server - reasoning
        should be handled by the backend/agent system.
        """
        logger.info(f"Agent reasoning: {reasoning}")
        if next_steps:
            logger.info(f"Next steps: {next_steps}")

        return {
            'success': True
        }

    server.register_tool(
        name='agent_run_shell_command',
        func=run_shell_command_impl,
        category='Command Runner',
        description='Execute shell commands with monitoring',
        requires_approval=True
    )

    server.register_tool(
        name='agent_share_your_reasoning',
        func=share_reasoning_impl,
        category='Command Runner',
        description='Share agent reasoning and next steps',
        requires_approval=False
    )

    logger.info(f"✅ Registered 2 command runner tools")
