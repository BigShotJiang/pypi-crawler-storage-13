"""File operations tools - read, list, grep."""

import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile

logger = logging.getLogger(__name__)

# Common ignore patterns for directories
DIR_IGNORE_PATTERNS = [
    "node_modules/",
    ".git/",
    "__pycache__/",
    "*.pyc",
    ".venv/",
    "venv/",
    ".pytest_cache/",
    ".mypy_cache/",
    "dist/",
    "build/",
    "*.egg-info/",
    ".DS_Store",
    "Thumbs.db",
]


def register_file_tools(server):
    """
    Register file operation tools with the server.

    Args:
        server: ToolServer instance
    """

    async def read_file_impl(file_path: str, start_line: int = None, num_lines: int = None):
        """Read file contents."""
        try:
            file_path = os.path.abspath(os.path.expanduser(file_path))

            if not os.path.exists(file_path):
                return {'success': False, 'error': f'File {file_path} does not exist'}

            if not os.path.isfile(file_path):
                return {'success': False, 'error': f'{file_path} is not a file'}

            with open(file_path, 'r', encoding='utf-8') as f:
                if start_line is not None and num_lines is not None:
                    lines = f.readlines()
                    start_idx = max(0, start_line - 1)
                    end_idx = min(len(lines), start_idx + num_lines)
                    content = "".join(lines[start_idx:end_idx])
                else:
                    content = f.read()

            num_tokens = len(content) // 4

            return {
                'success': True,
                'content': content,
                'num_tokens': num_tokens,
                'file_path': file_path
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

    async def list_files_impl(directory: str = ".", recursive: bool = True):
        """List files in directory."""
        try:
            directory = os.path.abspath(os.path.expanduser(directory))

            if not os.path.exists(directory):
                return {'success': False, 'error': f'Directory {directory} does not exist'}

            if not os.path.isdir(directory):
                return {'success': False, 'error': f'{directory} is not a directory'}

            results = []

            # Find ripgrep
            rg_path = shutil.which("rg")
            if not rg_path:
                python_dir = os.path.dirname(sys.executable)
                for rg_dir in ["bin", "Scripts"]:
                    venv_rg_path = os.path.join(python_dir, rg_dir, "rg")
                    if os.path.exists(venv_rg_path):
                        rg_path = venv_rg_path
                        break

            if recursive and rg_path:
                # Use ripgrep for recursive listing
                ignore_file = None
                try:
                    with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".ignore") as f:
                        ignore_file = f.name
                        for pattern in DIR_IGNORE_PATTERNS:
                            f.write(f"{pattern}\n")

                    cmd = [rg_path, "--files", "--ignore-file", ignore_file, directory]
                    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

                    files = result.stdout.strip().split("\n") if result.stdout.strip() else []

                    for full_path in files:
                        if not full_path or not os.path.exists(full_path):
                            continue

                        if full_path.startswith(directory):
                            rel_path = full_path[len(directory):].lstrip(os.sep)
                        else:
                            rel_path = full_path

                        if os.path.isfile(full_path):
                            size = os.path.getsize(full_path)
                            results.append({
                                'path': rel_path,
                                'type': 'file',
                                'size': size,
                                'full_path': full_path
                            })
                finally:
                    if ignore_file and os.path.exists(ignore_file):
                        os.unlink(ignore_file)
            else:
                # Non-recursive listing
                try:
                    entries = os.listdir(directory)
                    for entry in sorted(entries):
                        full_path = os.path.join(directory, entry)
                        if not os.path.exists(full_path):
                            continue

                        if os.path.isdir(full_path):
                            results.append({
                                'path': entry,
                                'type': 'directory',
                                'size': 0,
                                'full_path': full_path
                            })
                        elif os.path.isfile(full_path):
                            size = os.path.getsize(full_path)
                            results.append({
                                'path': entry,
                                'type': 'file',
                                'size': size,
                                'full_path': full_path
                            })
                except Exception as e:
                    return {'success': False, 'error': str(e)}

            return {
                'success': True,
                'files': results,
                'count': len(results),
                'directory': directory
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

    async def grep_impl(pattern: str, path: str = "."):
        """Search for pattern in files."""
        try:
            path = os.path.abspath(os.path.expanduser(path))
            matches = []

            # Find ripgrep
            rg_path = shutil.which("rg")
            if not rg_path:
                python_dir = os.path.dirname(sys.executable)
                for rg_dir in ["bin", "Scripts"]:
                    venv_rg_path = os.path.join(python_dir, rg_dir, "rg")
                    if os.path.exists(venv_rg_path):
                        rg_path = venv_rg_path
                        break

            if not rg_path:
                return {'success': False, 'error': 'ripgrep (rg) not found'}

            ignore_file = None
            try:
                with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".ignore") as f:
                    ignore_file = f.name
                    for pat in DIR_IGNORE_PATTERNS:
                        f.write(f"{pat}\n")

                cmd = [
                    rg_path, "--json", "--max-count", "50",
                    "--max-filesize", "5M", "--type=all",
                    "--ignore-file", ignore_file, pattern, path
                ]

                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

                for line in result.stdout.strip().split("\n"):
                    if not line:
                        continue
                    try:
                        match_data = json.loads(line)
                        if match_data.get("type") == "match":
                            data = match_data.get("data", {})
                            file_path = data.get("path", {}).get("text", "")
                            line_number = data.get("line_number")
                            line_content = data.get("lines", {}).get("text", "").strip()

                            if file_path and line_number:
                                matches.append({
                                    'file_path': file_path,
                                    'line_number': line_number,
                                    'line_content': line_content[:512]
                                })

                                if len(matches) >= 50:
                                    break
                    except json.JSONDecodeError:
                        continue
            finally:
                if ignore_file and os.path.exists(ignore_file):
                    os.unlink(ignore_file)

            return {
                'success': True,
                'matches': matches,
                'count': len(matches),
                'pattern': pattern,
                'path': path
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

    # Register tools
    server.register_tool(
        name='read_file',
        func=read_file_impl,
        category='File Operations',
        description='Read file contents with optional line range',
        requires_approval=False
    )

    server.register_tool(
        name='list_files',
        func=list_files_impl,
        category='File Operations',
        description='List files in a directory recursively or non-recursively',
        requires_approval=False
    )

    server.register_tool(
        name='grep',
        func=grep_impl,
        category='File Operations',
        description='Search for pattern in files using ripgrep',
        requires_approval=False
    )

    logger.info(f"✅ Registered 3 file operation tools")
