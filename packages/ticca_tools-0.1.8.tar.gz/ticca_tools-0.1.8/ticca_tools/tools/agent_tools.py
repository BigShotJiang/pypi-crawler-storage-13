"""Agent tools - list and invoke agents.

NOTE: These tools require access to the ticca2 backend database and agent system.
In a standalone tool server context, these tools will return appropriate error messages
directing users to use the backend API instead.
"""

import logging

logger = logging.getLogger(__name__)


def register_agent_tools(server):
    """
    Register agent tools with the server.

    Args:
        server: ToolServer instance
    """

    async def list_agents_impl():
        """List available agents.

        This requires access to the backend database, which is not available
        in the standalone tool server context.
        """
        return {
            'success': False,
            'agents': [],
            'count': 0,
            'error': 'Agent listing requires backend database access. Please use the ticca2 backend API /agents endpoint instead.'
        }

    async def invoke_agent_impl(agent_name: str, prompt: str, session_id: str = None):
        """Invoke another agent.

        This requires access to the backend database and agent system, which is not
        available in the standalone tool server context.
        """
        return {
            'success': False,
            'agent': agent_name,
            'output': None,
            'error': 'Agent invocation requires backend database and agent system access. Please use the ticca2 backend API /agents/{agent_name}/invoke endpoint instead.'
        }

    server.register_tool(
        name='list_agents',
        func=list_agents_impl,
        category='Agent Tools',
        description='List available agents (requires backend access)',
        requires_approval=False
    )

    server.register_tool(
        name='invoke_agent',
        func=invoke_agent_impl,
        category='Agent Tools',
        description='Invoke another agent (requires backend access)',
        requires_approval=False
    )

    logger.info(f"✅ Registered 2 agent tools (backend-dependent, will return errors)")
