"""Base Player class - core initialization and properties."""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from ..client import WiiMClient
from ..models import DeviceInfo, PlayerStatus
from ..state import StateSynchronizer

if TYPE_CHECKING:
    from ..group import Group
    from ..upnp.client import UpnpClient
else:
    Group = None

_LOGGER = logging.getLogger(__name__)


class PlayerBase:
    """Base player with core state and initialization."""

    def __init__(
        self,
        client: WiiMClient,
        upnp_client: UpnpClient | None = None,
        on_state_changed: Callable[[], None] | None = None,
    ) -> None:
        """Initialize a Player instance.

        Args:
            client: WiiMClient instance for this device.
            upnp_client: Optional UPnP client for queue management and events.
            on_state_changed: Optional callback function called when state is updated.
        """
        self.client = client
        self._upnp_client = upnp_client
        self._group: Group | None = None

        # State management
        self._state_synchronizer = StateSynchronizer()
        self._on_state_changed = on_state_changed

        # Cached state (updated via refresh())
        self._status_model: PlayerStatus | None = None
        self._device_info: DeviceInfo | None = None
        self._last_refresh: float | None = None

        # Cached audio output status (updated via refresh())
        self._audio_output_status: dict[str, Any] | None = None

        # Cached EQ presets (updated via refresh())
        self._eq_presets: list[str] | None = None

        # Cached metadata (audio quality info - updated via refresh())
        self._metadata: dict[str, Any] | None = None

        # Cached Bluetooth history (updated via refresh() every 60 seconds)
        self._bluetooth_history: list[dict[str, Any]] = []
        self._last_bt_history_check: float = 0

        # Availability tracking
        self._available: bool = True  # Assume available until proven otherwise

        # Position tracking (for position_updated_at)
        self._last_position_update: float | None = None
        self._last_position: int | None = None
        self._last_track_signature: str | None = None

        # Hybrid position estimation (for smooth updates between polls)
        self._estimated_position: int | None = None
        self._estimation_start_time: float | None = None
        self._estimation_base_position: int | None = None

        # Position timer for active updates (for clients displaying media position)
        self._position_timer_task: asyncio.Task | None = None
        self._position_timer_interval: float = 1.0  # Update every 1 second
        self._position_timer_running: bool = False
        self._last_timer_position: int | None = None  # Track last position sent to callback

        # Cover art cache (in-memory, keyed by URL hash)
        # Format: {url_hash: (image_bytes, content_type, timestamp)}
        self._cover_art_cache: dict[str, tuple[bytes, str, float]] = {}
        self._cover_art_cache_max_size: int = 10  # Max cached images per player
        self._cover_art_cache_ttl: float = 3600.0  # 1 hour TTL

    @property
    def role(self) -> str:
        """Current role: 'solo', 'master', or 'slave'.

        Returns:
            'solo' if not in a group, 'master' if group master, 'slave' if slave.
        """
        if self._group is None:
            return "solo"
        if self._group.master == self:
            if len(self._group.slaves) == 0:
                return "solo"
            return "master"
        return "slave"

    @property
    def is_solo(self) -> bool:
        """True if this player is not in a group."""
        return self._group is None

    @property
    def is_master(self) -> bool:
        """True if this player is the master of a group."""
        return self._group is not None and self._group.master == self

    @property
    def is_slave(self) -> bool:
        """True if this player is a slave in a group."""
        return self._group is not None and self._group.master != self

    @property
    def group(self) -> Group | None:
        """Group this player belongs to, or None if solo."""
        return self._group

    @property
    def host(self) -> str:
        """Device hostname or IP address."""
        return self.client.host

    @property
    def port(self) -> int:
        """Device port number."""
        return self.client.port

    @property
    def timeout(self) -> float:
        """Network timeout in seconds."""
        return self.client.timeout

    @property
    def name(self) -> str | None:
        """Device name from cached device_info."""
        if self._device_info:
            return self._device_info.name
        return None

    @property
    def model(self) -> str | None:
        """Device model from cached device_info."""
        if self._device_info:
            return self._device_info.model
        return None

    @property
    def firmware(self) -> str | None:
        """Firmware version from cached device_info."""
        if self._device_info:
            return self._device_info.firmware
        return None

    @property
    def mac_address(self) -> str | None:
        """MAC address from cached device_info."""
        if self._device_info:
            return self._device_info.mac
        return None

    @property
    def uuid(self) -> str | None:
        """Device UUID from cached device_info."""
        if self._device_info:
            return self._device_info.uuid
        return None

    @property
    def available(self) -> bool:
        """Device availability status."""
        return self._available

    @property
    def status_model(self) -> PlayerStatus | None:
        """Cached PlayerStatus model (None if not refreshed yet)."""
        return self._status_model

    @property
    def device_info(self) -> DeviceInfo | None:
        """Cached DeviceInfo model (None if not refreshed yet)."""
        return self._device_info

    def __repr__(self) -> str:
        """String representation."""
        role = self.role
        return f"Player(host={self.host!r}, role={role!r})"

    # === Position Timer (for active position updates) ===

    async def _position_timer_loop(self) -> None:
        """Background task to update position while playing.

        Updates position every second and triggers callbacks when position changes.
        This provides smooth position updates for clients displaying media position.
        """
        _LOGGER.debug("Position timer started for %s", self.host)

        while self._position_timer_running:
            try:
                # Check if still playing
                play_state = self._status_model.play_state if self._status_model else None
                is_playing = play_state and str(play_state).lower() in ("play", "playing", "load")

                if not is_playing:
                    # Not playing - stop timer
                    _LOGGER.debug("Position timer stopping (not playing) for %s", self.host)
                    self._position_timer_running = False
                    break

                # Calculate estimated position
                if self._estimation_base_position is not None and self._estimation_start_time is not None:
                    elapsed = time.time() - self._estimation_start_time
                    estimated = self._estimation_base_position + int(elapsed)

                    # Clamp to duration if available
                    if self._status_model and self._status_model.duration:
                        try:
                            duration = int(float(self._status_model.duration))
                            if duration > 0:
                                estimated = min(estimated, duration)
                        except (TypeError, ValueError):
                            pass

                    # Only update and trigger callback if position changed by 1+ second
                    # This avoids callback spam while still providing smooth updates
                    if self._last_timer_position is None or abs(estimated - self._last_timer_position) >= 1:
                        self._estimated_position = estimated
                        self._last_timer_position = estimated

                        # Trigger callback if position changed significantly
                        if self._on_state_changed:
                            try:
                                self._on_state_changed()
                            except Exception as err:
                                _LOGGER.debug("Error in position timer callback for %s: %s", self.host, err)

                await asyncio.sleep(self._position_timer_interval)

            except asyncio.CancelledError:
                _LOGGER.debug("Position timer cancelled for %s", self.host)
                break
            except Exception as err:
                _LOGGER.warning("Error in position timer loop for %s: %s", self.host, err)
                await asyncio.sleep(self._position_timer_interval)

        _LOGGER.debug("Position timer stopped for %s", self.host)

    def _start_position_timer(self) -> None:
        """Start position update timer if playing.

        The timer runs in the background and updates position every second,
        triggering callbacks for clients displaying media position.
        """
        if self._position_timer_running:
            return  # Already running

        play_state = self._status_model.play_state if self._status_model else None
        is_playing = play_state and str(play_state).lower() in ("play", "playing", "load")

        if not is_playing:
            return  # Not playing, don't start timer

        if self._estimation_base_position is None:
            return  # No base position yet, wait for first poll/event

        self._position_timer_running = True
        self._last_timer_position = None  # Reset to trigger callback on first update

        try:
            loop = asyncio.get_running_loop()
            self._position_timer_task = loop.create_task(self._position_timer_loop())
            _LOGGER.debug("Position timer started for %s", self.host)
        except RuntimeError:
            # No event loop running (sync context) - timer won't work
            # This is OK, position will still be calculated on-demand
            self._position_timer_running = False
            _LOGGER.debug("No event loop available for position timer on %s (sync context)", self.host)

    def _stop_position_timer(self) -> None:
        """Stop position update timer."""
        if not self._position_timer_running:
            return

        self._position_timer_running = False
        if self._position_timer_task:
            self._position_timer_task.cancel()
            self._position_timer_task = None
        self._last_timer_position = None
        _LOGGER.debug("Position timer stopped for %s", self.host)

    async def _cleanup_position_timer(self) -> None:
        """Clean up position timer (async cleanup for proper task cancellation)."""
        if self._position_timer_task:
            self._position_timer_running = False
            self._position_timer_task.cancel()
            try:
                await self._position_timer_task
            except asyncio.CancelledError:
                pass
            self._position_timer_task = None
            _LOGGER.debug("Position timer cleaned up for %s", self.host)
