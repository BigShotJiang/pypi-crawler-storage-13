class Humansize:
    def __init__(self, val):
        self.val = val

    def __format__(self, spec):
        if self.val < 2**10:
            return format(self.val, spec) + "   B"
        elif self.val < 2**20:
            return format(self.val / (2**10), spec) + " kiB"
        elif self.val < 2**30:
            return format(self.val / (2**20), spec) + " MiB"
        else:
            return format(self.val / (2**30), spec) + " GiB"
