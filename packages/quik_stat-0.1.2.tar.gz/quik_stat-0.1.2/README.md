# stat-tools

A small collection of simple CLI utilities for displaying stats about sets of files.
Currently `stat-tools` provides two utility commands, `extat` for showing statistics
about path suffixes (aka file extensions), and `imstat` for displaying information about
image files, e.g resolution, size, format etc.


# Usage
Both commands function by reading a set of files, separated by newlines, to analyze from
stdin. Neither command provides any filesystem search or filtering functionality; it is
the responsibility of an external tool to generate the list of paths to analyze and pass
it to the stat-tools command over stdin. This design decision greatly simplifies the
implementation of `stat-tools` and affords users maximum flexibility and control.

The intended use pattern is using a filesystem search tool such as [GNU
`find`](https://www.gnu.org/software/findutils/manual/html_mono/find.html),
[`fd`](https://github.com/sharkdp/fd?tab=readme-ov-file#how-to-use), or in simple cases
`ls` to generate a list of file paths which is then piped to the desired `stat-tools`
command:

```bash
# Report statistics on all files under `/some/root/path`
find some/root/path -type f | extat
```

## extat
`extat` provides statistics about the path suffixes (aka "file extensions") present in
the input list. This includes the number of paths with the suffix, the total number of
paths, analyzed, the percentage of all paths having the suffix, the total file size of
all files having the suffix, and the portion of total set file size represented by the
suffix 

## imstat
`imstat` works the same way `extat` does, but is designed to only process image files,
e.g. [jpeg](https://en.wikipedia.org/wiki/JPEG) files, and
[webp](https://en.wikipedia.org/wiki/WebP) files, and instead of printing statistics
about the path suffixes, it prints information about each file's image metadata, e.g.
resolution and file size info
