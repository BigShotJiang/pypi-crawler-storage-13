import pytest
from numpy import unique
from plotly.graph_objs import Scatter

from glue.core import Data

pytest.importorskip("glue_jupyter")

from glue_jupyter import JupyterApplication  # noqa: E402
from glue_jupyter.bqplot.histogram import BqplotHistogramView  # noqa: E402

from glue_plotly.common import sanitize  # noqa: E402
from glue_plotly.common.dotplot import dot_size, traces_for_layer  # noqa: E402
from glue_plotly.viewers.histogram.dotplot_layer_artist import (
    PlotlyDotplotLayerArtist,  # noqa: E402
)
from glue_plotly.viewers.histogram.viewer import PlotlyHistogramView  # noqa: E402


class SimpleDotplotViewer(PlotlyHistogramView):
    _data_artist_cls = PlotlyDotplotLayerArtist
    _subset_artist_cls = PlotlyDotplotLayerArtist

    def close(self, warn=False):
        self.figure.close()


class TestDotplot:

    def setup_method(self, method):
        x = [86,  86,  76,  78,  93, 100,  90,  87,  73,  61,  71,  68,  78,
             9,  87,  32,  34,   2,  57,  79,  48,   5,   8,  19,   7,  78,
             16,  15,  58,  34,  20,  63,  96,  97,  86,  92,  35,  59,  75,
             0,  53,  45,  59,  74,  59,   4,  69,  76,  97,  77,  24,  99,
             50,   6,   1,  55,  13,  40,  27,  17,  92,  72,  40,  29,  64,
             38,  77,  11,  91,  23,  59,  92,   5,  88,  15,  90,  40, 100,
             47,  28,   3,  44,  89,  75,  13,  94,  95,  43,  17,  88,   6,
             94, 100,  28,  45,  36,  63,  14,  90,  66]
        self.data = Data(label="dotplot", x=x)
        self.app = JupyterApplication()
        self.app.session.data_collection.append(self.data)
        self.viewer = self.app.new_data_viewer(SimpleDotplotViewer)
        self.viewer.add_data(self.data)
        self.mask, self.sanitized = sanitize(self.data["x"])

        viewer_state = self.viewer.state
        viewer_state.hist_n_bin = 18
        viewer_state.x_axislabel_size = 14
        viewer_state.y_axislabel_size = 8
        viewer_state.x_ticklabel_size = 18
        viewer_state.y_ticklabel_size = 20
        viewer_state.x_min = 0
        viewer_state.x_max = 100
        viewer_state.y_min = 0
        viewer_state.y_max = 15
        viewer_state.x_axislabel = "X Axis"
        viewer_state.y_axislabel = "Y Axis"

        self.layer = self.viewer.layers[0]
        self.layer.state.color = "#0e1dab"
        self.layer.state.alpha = 0.85

    def teardown_method(self, method):
        self.viewer.close(warn=False)
        self.viewer = None
        self.app = None

    def test_basic_dots(self):
        traces = traces_for_layer(self.viewer, self.layer.state)
        assert len(traces) == 1
        dots = traces[0]
        assert isinstance(dots, Scatter)

        assert len(unique(dots.x)) == 18
        expected_y = (1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 1,
                      2, 3, 4, 5, 6, 1, 2, 3, 4, 1, 2, 3, 1, 2,
                      3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2,
                      3, 4, 5, 1, 2, 1, 2, 3, 4, 5, 6, 7, 1, 2,
                      3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 8,
                      1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3,
                      4, 5, 6, 7, 8, 9, 10, 11, 1, 2, 3, 4, 5,
                      6, 7, 8)

        assert dots.y == expected_y

        # Default figure is 900x600, with margins of 50 on each side
        width = 900 - 50 - 50
        height = 600 - 50 - 50
        diam = 0.95 * min(height / 15, (5/9) * width / 8)
        assert dots.marker.size == diam

    def test_dot_radius_defined(self):
        """
        This test makes sure that we correctly get the default value for the dot radius
        when both axes have no range.
        """
        self.viewer.state.x_min = 1
        self.viewer.state.x_max = 1
        self.viewer.state.y_min = 1
        self.viewer.state.y_max = 1

        assert dot_size(self.viewer, self.layer.state) == 0.95


class TestDotsHistogram:

    def setup_method(self, method):
        x = [86,  86,  76,  78,  93, 100,  90,  87,  73,  61,  71,  68,  78,
             9,  87,  32,  34,   2,  57,  79,  48,   5,   8,  19,   7,  78,
             16,  15,  58,  34,  20,  63,  96,  97,  86,  92,  35,  59,  75,
             0,  53,  45,  59,  74,  59,   4,  69,  76,  97,  77,  24,  99,
             50,   6,   1,  55,  13,  40,  27,  17,  92,  72,  40,  29,  64,
             38,  77,  11,  91,  23,  59,  92,   5,  88,  15,  90,  40, 100,
             47,  28,   3,  44,  89,  75,  13,  94,  95,  43,  17,  88,   6,
             94, 100,  28,  45,  36,  63,  14,  90,  66]
        self.data = Data(label="dotplot", x=x)
        self.app = JupyterApplication()
        self.app.session.data_collection.append(self.data)
        self.viewer = self.app.new_data_viewer(BqplotHistogramView)
        self.viewer.add_data(self.data)
        self.mask, self.sanitized = sanitize(self.data["x"])

        viewer_state = self.viewer.state
        viewer_state.hist_n_bin = 18
        viewer_state.x_axislabel_size = 14
        viewer_state.y_axislabel_size = 8
        viewer_state.x_ticklabel_size = 18
        viewer_state.y_ticklabel_size = 20
        viewer_state.x_min = 0
        viewer_state.x_max = 100
        viewer_state.y_min = 0
        viewer_state.y_max = 15
        viewer_state.x_axislabel = "X Axis"
        viewer_state.y_axislabel = "Y Axis"

        self.layer = self.viewer.layers[0]
        self.layer.state.color = "#0e1dab"
        self.layer.state.alpha = 0.85

    def teardown_method(self, method):
        self.viewer = None
        self.app = None

    def test_basic_dots(self):
        traces = traces_for_layer(self.viewer, self.layer.state)
        assert len(traces) == 1
        dots = traces[0]
        assert isinstance(dots, Scatter)

        assert len(unique(dots.x)) == 18
        expected_y = (1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 1,
                      2, 3, 4, 5, 6, 1, 2, 3, 4, 1, 2, 3, 1, 2,
                      3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2,
                      3, 4, 5, 1, 2, 1, 2, 3, 4, 5, 6, 7, 1, 2,
                      3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 8,
                      1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3,
                      4, 5, 6, 7, 8, 9, 10, 11, 1, 2, 3, 4, 5,
                      6, 7, 8)

        assert dots.y == expected_y

        width = 1200
        height = 600
        diam = 0.95 * min(height / 15, width / 18)
        assert dots.marker.size == diam

    def test_dot_radius_defined(self):
        """
        This test makes sure that we correctly get the default value for the dot radius
        when both axes have no range.
        """
        self.viewer.state.x_min = 1
        self.viewer.state.x_max = 1
        self.viewer.state.y_min = 1
        self.viewer.state.y_max = 1

        assert dot_size(self.viewer, self.layer.state) == 0.95
