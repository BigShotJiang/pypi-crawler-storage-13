"""MCP server implementation for code knowledge management."""

from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import AsyncIterator
import os
from mcp.server.fastmcp import FastMCP, Context

# Mock classes for testing without external dependencies
class MockEmbedder:
    """Mock embedder for testing."""
    def __init__(self, base_url=None):
        pass

    def embed_text(self, text: str):
        """Return mock embedding."""
        return [0.1] * 384  # Mock 384-dimensional embedding

class MockVectorStore:
    """Mock vector store for testing."""
    def __init__(self, storage_dir=None):
        self.data = []

    def add(self, embedding, path, content, metadata):
        """Add mock data."""
        self.data.append({
            'embedding': embedding,
            'path': path,
            'content': content,
            'metadata': metadata
        })

    def search(self, query_embedding, limit=5):
        """Return mock search results."""
        from dataclasses import dataclass

        @dataclass
        class MockSegment:
            path: str
            content: str

        @dataclass
        class MockResult:
            segment: MockSegment
            score: float

        # Return mock results
        results = []
        for i, item in enumerate(self.data[:limit]):
            results.append(MockResult(
                segment=MockSegment(path=item['path'], content=item['content']),
                score=0.9 - i * 0.1
            ))
        return results

@dataclass
class ServerContext:
    """Server context with initialized components."""
    embedder: MockEmbedder
    store: MockVectorStore

@asynccontextmanager
async def server_lifespan(server: FastMCP) -> AsyncIterator[ServerContext]:
    """Initialize and cleanup server resources."""
    # Get storage dir from env or use default
    storage_dir = Path(os.getenv("STORAGE_DIR", "knowledge_store"))
    # Initialize mock components for testing
    embedder = MockEmbedder(base_url="http://localhost:11434")
    store = MockVectorStore(storage_dir=storage_dir)
    try:
        yield ServerContext(embedder=embedder, store=store)
    finally:
        # Cleanup if needed
        pass

# Create server with lifespan
mcp = FastMCP("code-knowledge-store", lifespan=server_lifespan)

@mcp.tool()
def add_knowledge(path: str, content: str, metadata: dict, ctx: Context) -> dict:
    """Add new knowledge to the repository."""
    embedder = ctx.lifespan_context.embedder
    store = ctx.lifespan_context.store
    embedding = embedder.embed_text(content)
    store.add(embedding, path, content, metadata)
    return {"success": True}

@mcp.tool()
def search_knowledge(query: str, ctx: Context, limit: int = 5) -> dict:
    """Search existing knowledge."""
    embedder = ctx.lifespan_context.embedder
    store = ctx.lifespan_context.store
    query_embedding = embedder.embed_text(query)
    results = store.search(query_embedding, limit)
    return {
        "results": [{
            "path": r.segment.path,
            "content": r.segment.content,
            "score": r.score
        } for r in results]
    }

if __name__ == "__main__":
    mcp.run()