"""Code Knowledge Store - MCP Server for code repository knowledge management."""

def main():
    """Main entry point for the MCP server."""
    from .server import mcp
    mcp.run()

if __name__ == "__main__":
    main()
