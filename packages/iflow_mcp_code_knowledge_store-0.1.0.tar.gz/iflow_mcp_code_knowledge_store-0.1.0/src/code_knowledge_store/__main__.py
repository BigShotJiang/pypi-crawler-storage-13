"""Main entry point for the code knowledge store MCP server."""

from code_knowledge_store.server import mcp

if __name__ == "__main__":
    mcp.run()
