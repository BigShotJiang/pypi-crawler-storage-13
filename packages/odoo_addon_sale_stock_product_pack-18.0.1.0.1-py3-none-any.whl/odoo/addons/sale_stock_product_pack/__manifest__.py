# Copyright 2021 Tecnativa - David Vidal
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
{
    "name": "Sale Stock Product Pack",
    "summary": "Compatibility module for packs that are storable products",
    "version": "18.0.1.0.1",
    "development_status": "Beta",
    "category": "Sale",
    "website": "https://github.com/OCA/product-pack",
    "author": "Tecnativa, Odoo Community Association (OCA)",
    "maintainers": ["pedrobaeza"],
    "license": "AGPL-3",
    "depends": ["sale_product_pack", "stock_product_pack"],
    "data": [],
}
