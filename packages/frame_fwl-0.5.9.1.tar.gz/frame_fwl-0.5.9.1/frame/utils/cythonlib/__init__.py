'''# Cythonlib
Cython fast compilator.
Functions - 
    - cython: run cython code
    - runfile: fun .pyx file
    - setupfile: setup .pyx file to system like a lib.'''

from cythonlib.cython import (
    cython, 
    runfile, 
    setupfile, 
    CythonCompilationError, 
    CythonImportError, 
    CythonRuntimeError
)