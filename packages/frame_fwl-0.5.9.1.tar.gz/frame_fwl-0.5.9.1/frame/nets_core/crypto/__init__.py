'''
# Nets.Crypto Module

Modules - 
    - hashes - hash methods.
    - rand_system - randow generating system based on [secrets].
'''

from .hashes import (ClassApi as HashCryptoApi)
from .rand_system import (ClassApi as RandCryptoApi)
from .bip39_wordlist import (wordlist as bip39wl)