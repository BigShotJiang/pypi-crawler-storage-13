import time, logging

numbers = '12347890'
letters_ru = 'ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮйцукенгшщзхъфывапролджэячсмитьбю'
letters_en = 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM'
symbols = '!@#$%^&*(){}[]_+=-.,?:;/\\|'


class Logger:
    def __init__(self, filename: str):
        self.file = filename
        self.logs = []
    def log(self, level: int | str, msg: str):
        log = f'{str(level).upper()} : [{time.time()}] : {msg}'
        self.logs.append(log)
        return self
    def debug(self, msg: str):
        return self.log('debug', msg)
    def critical(self, msg: str):
        return self.log('critical', msg)
    def classic(self, msg: str):
        return self.log('log', msg)
    def error(self, msg: str):
        return self.log('error', msg)
    def exception(self, msg: str):
        return self.log('exception', msg)
    def save(self):
        with open(self.file, 'w') as logfile: logfile.write('\n'.join(self.logs))

class UnsafePassword(Exception):
    def __init__(self, *args):
        super().__init__(*args)

def validate_password_strength(password):
    string = str(password)
    list_pass = list(string)
    unsafe = UnsafePassword
    if len(string) < 8: raise unsafe('Length less then 8.')
    have = {'lowercase': False, 'uppercase': False, 'numbers': False, 'symbols': False}
    for letter in list_pass:
        l = letter in list(letters_en.lower())
        u = letter in list(letters_en.upper())
        s = letter in list(symbols)
        n = letter in list(numbers)
        if l: have['lowercase'] += list(letters_en.lower()).index(letter) + have['lowercase']
        if u: have['uppercase'] += list(letters_en.upper()).index(letter) + have['uppercase']
        if s: have['symbols'] += list(symbols).index(letter) + have['symbols']
        if n: have['numbers'] += list(numbers).index(letter) + have['numbers']
    entropy = 0
    for i in have.keys():
        if have[i] == False: raise unsafe(f'Password has no {i}.')
        entropy += have[i]
    if entropy < 200: raise unsafe(f'Entropy less then 200 ({entropy}).')
    return password

