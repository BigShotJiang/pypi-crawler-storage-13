"""
QTAM - Q-Transform Amplitude Modulation

A PyTorch implementation of invertible Q-transform and multi-configuration Q-scanning
for time-frequency analysis of gravitational wave data and other signals.
"""

__version__ = "0.1.0"

# Import main classes for easy access
from .core import (
    QTile,
    SingleQTransform,
    QScan,
    # Window functions
    planck_taper_window_range,
    kaiser_window_range,
    tukey_window,
    bisquare_window,
    hann_window,
)

from .scan import (
    QTileMulti,
    SingleQMultiTransform,
    QScanMulti,
    # Batched window functions
    planck_taper_window_range_batch,
    kaiser_window_range_batch,
    tukey_window_batch,
    bisquare_window_batched,
    hann_window_batched,
)

# Define what gets imported with "from qtam import *"
__all__ = [
    # Core module
    "QTile",
    "SingleQTransform", 
    "QScan",
    "planck_taper_window_range",
    "kaiser_window_range", 
    "tukey_window",
    "bisquare_window",
    "hann_window",
    
    # Scan module
    "QTileMulti",
    "SingleQMultiTransform",
    "QScanMulti",
    "planck_taper_window_range_batch",
    "kaiser_window_range_batch",
    "tukey_window_batch", 
    "bisquare_window_batched",
    "hann_window_batched",
]
