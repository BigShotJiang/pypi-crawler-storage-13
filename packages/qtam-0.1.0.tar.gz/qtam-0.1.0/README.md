# QTAM - Q-Transform with Amplitude Modulation

A full PyTorch implementation of the invertible Q-transform. QTAM exploits Amplitude Modulation and de-Modulation to increase and decrease the size of the produced spectrograms, making it possible to encode all the physical information of a signal in 2D images of modest dimensions. The analytical invertibility of QTAM ensures that no physically relevant features are lost when going from time to time-frequency representation and vice versa. The package include classes for multi-configuration Q-scanning for time-frequency analysis; the user can perform a scan over the parameter space to choose the frequency window and Q value which best suite their analysis.  

More information can be found at: "https://github.com/dottormale/Qtransform_torch/tree/main/QTAM".

## Installation

```bash
pip install qtam
