import pytest
import torch
import numpy as np
from qtam.core import (
    QTile, SingleQTransform, QScan,
    planck_taper_window_range, kaiser_window_range,
    tukey_window, bisquare_window, hann_window
)


class TestWindowFunctions:
    """Test window function implementations"""
    
    def test_planck_taper_window(self):
        window = planck_taper_window_range(100, epsilon=0.1)
        assert window.shape == (100,)
        assert torch.all(window >= 0)
        assert torch.all(window <= 1)
        assert window[0] == 0.0
        assert window[-1] == 0.0
    
    def test_kaiser_window(self):
        window = kaiser_window_range(100, beta=8.6)
        assert window.shape == (100,)
        assert torch.all(window >= 0)
        assert torch.all(window <= 1)
    
    def test_tukey_window(self):
        window = tukey_window(100, alpha=0.1)
        assert window.shape == (100,)
        assert torch.all(window >= 0)
        assert torch.all(window <= 1)
    
    def test_bisquare_window(self):
        window = bisquare_window(100)
        assert window.shape == (100,)
        assert torch.all(window >= 0)
        assert torch.all(window <= 1)
    
    def test_hann_window(self):
        window = hann_window(100)
        assert window.shape == (100,)
        assert torch.all(window >= 0)
        assert torch.all(window <= 1)


class TestQTile:
    """Test QTile functionality"""
    
    @pytest.fixture
    def sample_data(self):
        duration = 1.0
        sample_rate = 4096
        t = torch.linspace(0, duration, int(sample_rate * duration))
        # Create a simple signal with known frequency components
        signal = torch.sin(2 * np.pi * 100 * t) + 0.5 * torch.sin(2 * np.pi * 200 * t)
        return signal.unsqueeze(0).unsqueeze(0)  # [1, 1, T]
    
    @pytest.fixture
    def qtile(self):
        return QTile(
            q=8.0,
            frequency=100.0,
            duration=1.0,
            sample_rate=4096,
            mismatch=0.2,
            window_param="bisquare"
        )
    
    def test_qtile_initialization(self, qtile):
        assert qtile.q == 8.0
        assert qtile.frequency == 100.0
        assert qtile.duration == 1.0
        assert qtile.sample_rate == 4096
        assert qtile.window is not None
        assert qtile.full_window is not None
    
    def test_qtile_forward_energy(self, qtile, sample_data):
        # Test energy output
        fseries = torch.fft.rfft(sample_data, norm='ortho')
        output = qtile(fseries, polar_mode=True, energy_mode=True)
        
        assert output.shape[0] == 1  # batch dimension
        assert output.shape[1] == 1  # channel dimension
        assert output.shape[2] == 1  # energy only (no phase)
        assert torch.all(output >= 0)  # energy should be non-negative
    
    def test_qtile_forward_phase(self, qtile, sample_data):
        # Test phase output
        fseries = torch.fft.rfft(sample_data, norm='ortho')
        output = qtile(fseries, polar_mode=True, energy_mode=False, phase_mode=True)
        
        assert output.shape[2] == 2  # energy and phase
        energy = output[:, :, 0, :]
        phase = output[:, :, 1, :]
        assert torch.all(energy >= 0)
        assert torch.all(phase >= -np.pi)
        assert torch.all(phase <= np.pi)
    
    def test_qtile_invertibility(self, qtile, sample_data):
        # Test that forward + inverse recovers original (approximately)
        fseries_original = torch.fft.rfft(sample_data, norm='ortho')
        
        # Forward transform
        tile_output = qtile(fseries_original, polar_mode=True, energy_mode=True, phase_mode=True)
        
        # Inverse transform
        fseries_reconstructed = qtile.invert(tile_output, polar_mode=True, energy_mode=True, phase_mode=True)
        
        # Should be close to original
        assert torch.allclose(fseries_original, fseries_reconstructed, rtol=1e-3, atol=1e-5)


class TestSingleQTransform:
    """Test SingleQTransform functionality"""
    
    @pytest.fixture
    def sample_data(self):
        duration = 1.0
        sample_rate = 4096
        t = torch.linspace(0, duration, int(sample_rate * duration))
        signal = torch.sin(2 * np.pi * 100 * t) + 0.5 * torch.sin(2 * np.pi * 200 * t)
        return signal.unsqueeze(0).unsqueeze(0)  # [1, 1, T]
    
    @pytest.fixture
    def single_q_transform(self):
        return SingleQTransform(
            duration=1.0,
            sample_rate=4096,
            q=8.0,
            frange=[50, 500],
            mismatch=0.2,
            num_freq=10,  # Fixed number for predictable testing
            logf=False
        )
    
    def test_transform_initialization(self, single_q_transform):
        assert single_q_transform.q == 8.0
        assert len(single_q_transform.freqs) > 0
        assert len(single_q_transform.qtile_transforms) == len(single_q_transform.freqs)
    
    def test_forward_transform(self, single_q_transform, sample_data):
        output = single_q_transform(
            sample_data,
            polar_mode=True,
            energy_mode=True,
            phase_mode=False
        )
        
        # Check output dimensions
        assert len(output.shape) == 5  # [B, C, P, F, T]
        assert output.shape[0] == 1  # batch
        assert output.shape[1] == 1  # channels
        assert output.shape[2] == 1  # energy only
        assert output.shape[3] == len(single_q_transform.freqs)  # frequencies
        assert torch.all(output >= 0)  # energy non-negative
    
    def test_downsampling(self, single_q_transform, sample_data):
        # Test efficient downsampling
        output = single_q_transform(
            sample_data,
            num_time=128,  # Downsample to 128 time bins
            polar_mode=True,
            energy_mode=True
        )
        
        assert output.shape[-1] == 128  # Check downsampled time dimension
    
    def test_invertibility(self, single_q_transform, sample_data):
        # Test full inversion
        spectrogram = single_q_transform(
            sample_data,
            polar_mode=True,
            energy_mode=True,
            phase_mode=True
        )
        
        reconstructed = single_q_transform.invert_qtransform(
            spectrogram,
            polar_mode=True,
            energy_mode=True,
            phase_mode=True
        )
        
        # Should reconstruct original signal approximately
        assert reconstructed.shape == sample_data.shape
        # Note: Perfect reconstruction isn't guaranteed due to windowing effects
        # but basic shape and properties should match
    
    def test_single_tile_inversion(self, single_q_transform, sample_data):
        # Test inversion using only one frequency tile
        spectrogram = single_q_transform(
            sample_data,
            polar_mode=True,
            energy_mode=True,
            phase_mode=True
        )
        
        # Invert using just the first frequency tile
        reconstructed = single_q_transform.invert_qtransform(
            spectrogram,
            idx=0,  # Use first frequency tile
            polar_mode=True,
            energy_mode=True,
            phase_mode=True
        )
        
        assert reconstructed.shape == sample_data.shape


class TestQScan:
    """Test QScan functionality"""
    
    @pytest.fixture
    def sample_data(self):
        duration = 1.0
        sample_rate = 4096
        t = torch.linspace(0, duration, int(sample_rate * duration))
        signal = torch.sin(2 * np.pi * 100 * t)
        return signal.unsqueeze(0).unsqueeze(0)
    
    @pytest.fixture
    def q_scan(self):
        return QScan(
            duration=1.0,
            sample_rate=4096,
            spectrogram_shape=(128, 128),
            qrange=[4, 16],  # Small range for faster testing
            frange=[50, 300],
            mismatch=0.2
        )
    
    def test_q_scan_initialization(self, q_scan):
        assert len(q_scan.qs) > 0
        assert len(q_scan.q_transforms) == len(q_scan.qs)
        assert all(q >= 4 and q <= 16 for q in q_scan.qs)
    
    def test_get_max_energy(self, q_scan, sample_data):
        # Compute transforms first
        for transform in q_scan.q_transforms:
            transform.compute_qtiles(sample_data)
        
        max_energy = q_scan.get_max_energy()
        assert max_energy > 0  # Should have some energy
    
    def test_energy_computation_dimensions(self, q_scan, sample_data):
        for transform in q_scan.q_transforms:
            transform.compute_qtiles(sample_data)
        
        # Test different dimension options
        both = q_scan.get_max_energy(dimension="both")
        neither = q_scan.get_max_energy(dimension="neither")
        channel = q_scan.get_max_energy(dimension="channel")
        batch = q_scan.get_max_energy(dimension="batch")
        
        # All should return valid energy values
        assert both > 0
        assert torch.all(neither > 0)
        assert torch.all(channel > 0)
        assert torch.all(batch > 0)


class TestDeviceCompatibility:
    """Test that components work on different devices"""
    
    def test_qtile_device_move(self):
        qtile = QTile(
            q=8.0,
            frequency=100.0,
            duration=1.0,
            sample_rate=4096,
            mismatch=0.2
        )
        
        if torch.cuda.is_available():
            qtile = qtile.cuda()
            assert qtile.window.device.type == 'cuda'
            assert qtile.full_window.device.type == 'cuda'
    
    def test_transform_device_move(self):
        transform = SingleQTransform(
            duration=1.0,
            sample_rate=4096,
            q=8.0,
            frange=[50, 500]
        )
        
        if torch.cuda.is_available():
            transform = transform.cuda()
            for qtile in transform.qtile_transforms:
                assert qtile.window.device.type == 'cuda'


if __name__ == "__main__":
    pytest.main([__file__])
