import pytest
import torch
import numpy as np
from qtam.scan import (
    QTileMulti, SingleQMultiTransform, QScanMulti,
    planck_taper_window_range_batch, kaiser_window_range_batch,
    tukey_window_batch, bisquare_window_batched, hann_window_batched
)


class TestBatchedWindowFunctions:
    """Test batched window function implementations"""
    
    def test_planck_taper_batch(self):
        epsilons = torch.tensor([0.1, 0.2, 0.3])
        windows = planck_taper_window_range_batch(100, epsilons)
        
        assert windows.shape == (3, 100)  # [batch, length]
        assert torch.all(windows >= 0)
        assert torch.all(windows <= 1)
        assert torch.all(windows[:, 0] == 0.0)
        assert torch.all(windows[:, -1] == 0.0)
    
    def test_kaiser_batch(self):
        betas = torch.tensor([5.0, 8.6, 12.0])
        windows = kaiser_window_range_batch(100, betas)
        
        assert windows.shape == (3, 100)
        assert torch.all(windows >= 0)
        assert torch.all(windows <= 1)
    
    def test_tukey_batch(self):
        alphas = torch.tensor([0.1, 0.2, 0.3])
        windows = tukey_window_batch(100, alphas)
        
        assert windows.shape == (3, 100)
        assert torch.all(windows >= 0)
        assert torch.all(windows <= 1)
    
    def test_bisquare_batched(self):
        windows = bisquare_window_batched(100, batch_size=3)
        assert windows.shape == (3, 100)
        assert torch.all(windows >= 0)
        assert torch.all(windows <= 1)
    
    def test_hann_batched(self):
        windows = hann_window_batched(100, batch_size=3)
        assert windows.shape == (3, 100)
        assert torch.all(windows >= 0)
        assert torch.all(windows <= 1)


class TestQTileMulti:
    """Test multi-configuration QTile"""
    
    @pytest.fixture
    def sample_data(self):
        duration = 1.0
        sample_rate = 4096
        t = torch.linspace(0, duration, int(sample_rate * duration))
        signal = torch.sin(2 * np.pi * 100 * t)
        return signal.unsqueeze(0).unsqueeze(0)  # [1, 1, T]
    
    @pytest.fixture
    def qtile_multi_basic(self):
        return QTileMulti(
            q=8.0,
            frequency=100.0,
            duration=1.0,
            sample_rate=4096,
            mismatch=0.2,
            window_types=["bisquare", "hann"],
            device="cpu"
        )
    
    @pytest.fixture
    def qtile_multi_param(self):
        return QTileMulti(
            q=8.0,
            frequency=100.0,
            duration=1.0,
            sample_rate=4096,
            mismatch=0.2,
            window_types=["tukey", "kaiser"],
            taus=[0.1, 0.2],
            betas=[8.6, 12.0],
            device="cpu"
        )
    
    def test_qtile_multi_initialization(self, qtile_multi_basic):
        assert qtile_multi_basic.q == 8.0
        assert len(qtile_multi_basic.configs) == 2  # bisquare + hann
        assert qtile_multi_basic.window.shape[0] == 2  # 2 configurations
        assert qtile_multi_basic.full_window.shape[2] == 2  # 2 configurations
    
    def test_qtile_multi_parameterized(self, qtile_multi_param):
        # Should have 2 tukeys + 2 kaisers = 4 configurations
        assert len(qtile_multi_param.configs) == 4
        assert qtile_multi_param.window.shape[0] == 4
        assert qtile_multi_param.full_window.shape[2] == 4
    
    def test_qtile_multi_forward(self, qtile_multi_basic, sample_data):
        fseries = torch.fft.rfft(sample_data, norm='ortho')
        output = qtile_multi_basic(fseries, polar_mode=True, energy_mode=True)
        
        # Output should have configuration dimension
        assert len(output.shape) == 5  # [B, C, P, n_cfg, T]
        assert output.shape[3] == 2  # 2 configurations
        assert torch.all(output >= 0)  # energy non-negative
    
    def test_config_structure(self, qtile_multi_basic):
        configs = qtile_multi_basic.configs
        assert len(configs) == 2
        # Check config format: (q, window_type, tau, beta)
        for config in configs:
            assert len(config) == 4
            assert config[0] == 8.0  # q value
            assert config[1] in ["bisquare", "hann"]


class TestSingleQMultiTransform:
    """Test multi-configuration single Q transform"""
    
    @pytest.fixture
    def sample_data(self):
        duration = 1.0
        sample_rate = 4096
        t = torch.linspace(0, duration, int(sample_rate * duration))
        signal = torch.sin(2 * np.pi * 100 * t) + 0.5 * torch.sin(2 * np.pi * 150 * t)
        return signal.unsqueeze(0).unsqueeze(0)  # [1, 1, T]
    
    @pytest.fixture
    def single_q_multi(self):
        return SingleQMultiTransform(
            duration=1.0,
            sample_rate=4096,
            spectrogram_shape=(128, 128),
            q=8.0,
            frange=[50, 200],
            window_types=["bisquare", "tukey"],
            taus=[0.1, 0.2],
            num_freq=5,  # Fixed for predictable testing
            device="cpu"
        )
    
    def test_initialization(self, single_q_multi):
        assert single_q_multi.q == 8.0
        assert len(single_q_multi.freqs) == 5
        assert len(single_q_multi.qtile_multi_transforms) == 5
        assert len(single_q_multi.configs) == 3  # bisquare + 2 tukeys
    
    def test_forward(self, single_q_multi, sample_data):
        output = single_q_multi(
            sample_data,
            polar_mode=True,
            energy_mode=True,
            phase_mode=False
        )
        
        # Check output dimensions: [B, C, P, n_cfg, n_freq, T]
        assert len(output.shape) == 6
        assert output.shape[0] == 1  # batch
        assert output.shape[1] == 1  # channels  
        assert output.shape[2] == 1  # energy only
        assert output.shape[3] == 3  # configurations
        assert output.shape[4] == 5  # frequencies
        assert torch.all(output >= 0)
    
    def test_get_max_energy_per_element(self, single_q_multi, sample_data):
        single_q_multi.compute_qtiles(
            sample_data,
            polar_mode=True,
            energy_mode=True,
            phase_mode=False
        )
        
        best_val, best_configs, best_spec = single_q_multi.get_max_energy(
            criterion="total",
            per_element=True
        )
        
        assert best_val.shape == (1, 1)  # [B, C]
        assert best_configs.shape == (1, 1)  # [B, C]
        assert best_spec.shape == (1, 1, 5, single_q_multi.qtiles.shape[-1])  # [B, C, F, T]
    
    def test_get_max_energy_global(self, single_q_multi, sample_data):
        single_q_multi.compute_qtiles(
            sample_data,
            polar_mode=True,
            energy_mode=True,
            phase_mode=False
        )
        
        best_val, best_configs, best_spec = single_q_multi.get_max_energy(
            criterion="total",
            per_element=False
        )
        
        # Global should return scalar values
        assert isinstance(best_val, (float, torch.Tensor))
        assert best_spec.shape == (5, single_q_multi.qtiles.shape[-1])  # [F, T]
    
    def test_different_criteria(self, single_q_multi, sample_data):
        single_q_multi.compute_qtiles(
            sample_data,
            polar_mode=True,
            energy_mode=True,
            phase_mode=False
        )
        
        # Test different selection criteria
        for criterion in ["pixel", "total", "median"]:
            best_val, best_configs, best_spec = single_q_multi.get_max_energy(
                criterion=criterion,
                per_element=True
            )
            assert best_val.shape == (1, 1)


class TestQScanMulti:
    """Test multi-Q multi-configuration scanning"""
    
    @pytest.fixture
    def sample_data(self):
        duration = 1.0
        sample_rate = 4096
        t = torch.linspace(0, duration, int(sample_rate * duration))
        # Create signal with multiple frequency components
        signal = (
            torch.sin(2 * np.pi * 80 * t) + 
            0.7 * torch.sin(2 * np.pi * 120 * t) +
            0.3 * torch.sin(2 * np.pi * 180 * t)
        )
        return signal.unsqueeze(0).unsqueeze(0)  # [1, 1, T]
    
    @pytest.fixture
    def q_scan_multi(self):
        return QScanMulti(
            duration=1.0,
            sample_rate=4096,
            spectrogram_shape=(128, 128),
            qrange=[4, 12],  # Small range for faster testing
            qlist=None,
            frange=[50, 200],
            window_types=["bisquare", "tukey"],
            taus=[0.1, 0.2],
            device="cpu",
            max_window_size=False
        )
    
    @pytest.fixture
    def q_scan_multi_with_qlist(self):
        return QScanMulti(
            duration=1.0,
            sample_rate=4096,
            spectrogram_shape=(128, 128),
            qrange=[4, 12],
            qlist=[4.0, 8.0, 12.0],  # Specific Q values
            frange=[50, 200],
            window_types=["bisquare"],
            device="cpu"
        )
    
    def test_initialization(self, q_scan_multi):
        assert len(q_scan_multi.qs) > 0
        assert len(q_scan_multi.transforms) == len(q_scan_multi.qs)
        assert all(hasattr(transform, 'configs') for transform in q_scan_multi.transforms)
    
    def test_qlist_initialization(self, q_scan_multi_with_qlist):
        assert q_scan_multi_with_qlist.qs == [4.0, 8.0, 12.0]
        assert len(q_scan_multi_with_qlist.transforms) == 3
    
    def test_scan_mode_true_per_element(self, q_scan_multi, sample_data):
        best_specs, best_qs, best_configs = q_scan_multi(
            sample_data,
            scan_mode=True,
            per_element=True,
            polar_mode=True,
            energy_mode=True,
            phase_mode=False
        )
        
        # Should return lists/arrays for each batch/channel element
        assert isinstance(best_specs, list)
        assert isinstance(best_specs[0], list)
        assert best_qs.shape == (1, 1)  # [B, C]
        assert best_configs.shape == (1, 1)  # [B, C]
    
    def test_scan_mode_true_global(self, q_scan_multi, sample_data):
        best_spec, best_q, best_config = q_scan_multi(
            sample_data,
            scan_mode=True,
            per_element=False,
            polar_mode=True,
            energy_mode=True,
            phase_mode=False
        )
        
        # Should return single values for global best
        assert isinstance(best_spec, torch.Tensor)
        assert isinstance(best_q, torch.Tensor)
        assert isinstance(best_config, (tuple, np.ndarray))
    
    def test_scan_mode_false(self, q_scan_multi, sample_data):
        results = q_scan_multi(
            sample_data,
            scan_mode=False,
            polar_mode=True,
            energy_mode=True,
            phase_mode=False
        )
        
        # Should return list of transforms
        assert isinstance(results, list)
        assert len(results) == len(q_scan_multi.transforms)
        for result in results:
            assert isinstance(result, torch.Tensor)
    
    def test_different_criteria(self, q_scan_multi, sample_data):
        for criterion in ["pixel", "total", "median"]:
            best_spec, best_q, best_config = q_scan_multi(
                sample_data,
                scan_mode=True,
                per_element=False,
                criterion=criterion,
                polar_mode=True,
                energy_mode=True,
                phase_mode=False
            )
            assert isinstance(best_spec, torch.Tensor)
            assert best_spec.numel() > 0
    
    def test_frequency_range_restriction(self, q_scan_multi, sample_data):
        # Test with restricted frequency range
        best_spec, best_q, best_config = q_scan_multi(
            sample_data,
            scan_mode=True,
            per_element=False,
            fsearch_range=[70, 130],  # Only search in this range
            polar_mode=True,
            energy_mode=True,
            phase_mode=False
        )
        assert isinstance(best_spec, torch.Tensor)


class TestEdgeCases:
    """Test edge cases and error conditions"""
    
    def test_empty_window_types(self):
        # Should handle empty window types list
        with pytest.raises(ValueError):
            QTileMulti(
                q=8.0,
                frequency=100.0,
                duration=1.0,
                sample_rate=4096,
                mismatch=0.2,
                window_types=[],  # Empty list
                device="cpu"
            )
    
    def test_missing_parameters(self):
        # Should require taus for tukey/planck-taper
        with pytest.raises(AssertionError):
            QTileMulti(
                q=8.0,
                frequency=100.0,
                duration=1.0,
                sample_rate=4096,
                mismatch=0.2,
                window_types=["tukey"],
                # taus missing
                device="cpu"
            )
    
    def test_invalid_criterion(self, single_q_multi, sample_data):
        single_q_multi.compute_qtiles(sample_data)
        
        with pytest.raises(ValueError):
            single_q_multi.get_max_energy(criterion="invalid_criterion")
    
    def test_complex_mode_scan_error(self, q_scan_multi, sample_data):
        # Scanning shouldn't work with complex mode
        with pytest.raises(ValueError):
            q_scan_multi(
                sample_data,
                scan_mode=True,
                complex_mode=True  # Not supported for scanning
            )


class TestPerformance:
    """Test performance and memory usage"""
    
    def test_memory_usage_batched_windows(self):
        # Test that batched windows are memory efficient
        betas = torch.tensor([5.0, 6.0, 7.0, 8.0, 9.0, 10.0])
        windows = kaiser_window_range_batch(1000, betas)
        
        # Should create all windows with single operation
        assert windows.shape == (6, 1000)
        # Memory should be reasonable (not 6x individual windows)


if __name__ == "__main__":
    pytest.main([__file__])
