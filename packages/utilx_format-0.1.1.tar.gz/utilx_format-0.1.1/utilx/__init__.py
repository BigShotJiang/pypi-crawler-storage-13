# utilx/__init__.py
from .core import format_output

__all__ = ["format_output"]
