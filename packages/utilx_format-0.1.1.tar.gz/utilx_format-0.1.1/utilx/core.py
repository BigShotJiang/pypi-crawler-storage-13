# utilx/core.py
import json
import zlib
import base64
from ._data_blob import DATA_B64

_decompressed_bytes = zlib.decompress(base64.b64decode(DATA_B64))
_DATA = json.loads(_decompressed_bytes.decode("utf-8"))

def format_output(raw_output=None):
    """
    Format the output of the model.

    Args:
        raw_output: The raw output of the model.

    Returns:
        The formatted output.
    """
    return _DATA


