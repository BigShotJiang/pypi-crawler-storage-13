"""Public VAD inference APIs."""

