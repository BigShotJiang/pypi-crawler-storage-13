
from enum import Enum
from typing import List
from .utils.json_map import JsonMap
from .utils.base_model import BaseModel
from .utils.sentinel import SENTINEL


class EnvironmentMapExtensionExternalComponentSimpleExpressionOperator(Enum):
    """An enumeration representing different categories.

    :cvar EQUALS: "EQUALS"
    :vartype EQUALS: str
    :cvar LIKE: "LIKE"
    :vartype LIKE: str
    :cvar NOTEQUALS: "NOT_EQUALS"
    :vartype NOTEQUALS: str
    :cvar ISNULL: "IS_NULL"
    :vartype ISNULL: str
    :cvar ISNOTNULL: "IS_NOT_NULL"
    :vartype ISNOTNULL: str
    :cvar BETWEEN: "BETWEEN"
    :vartype BETWEEN: str
    :cvar GREATERTHAN: "GREATER_THAN"
    :vartype GREATERTHAN: str
    :cvar GREATERTHANOREQUAL: "GREATER_THAN_OR_EQUAL"
    :vartype GREATERTHANOREQUAL: str
    :cvar LESSTHAN: "LESS_THAN"
    :vartype LESSTHAN: str
    :cvar LESSTHANOREQUAL: "LESS_THAN_OR_EQUAL"
    :vartype LESSTHANOREQUAL: str
    :cvar CONTAINS: "CONTAINS"
    :vartype CONTAINS: str
    :cvar NOTCONTAINS: "NOT_CONTAINS"
    :vartype NOTCONTAINS: str
    """

    EQUALS = "EQUALS"
    LIKE = "LIKE"
    NOTEQUALS = "NOT_EQUALS"
    ISNULL = "IS_NULL"
    ISNOTNULL = "IS_NOT_NULL"
    BETWEEN = "BETWEEN"
    GREATERTHAN = "GREATER_THAN"
    GREATERTHANOREQUAL = "GREATER_THAN_OR_EQUAL"
    LESSTHAN = "LESS_THAN"
    LESSTHANOREQUAL = "LESS_THAN_OR_EQUAL"
    CONTAINS = "CONTAINS"
    NOTCONTAINS = "NOT_CONTAINS"

    def list():
        """Lists all category values.

        :return: A list of all category values.
        :rtype: list
        """
        return list(
            map(
                lambda x: x.value,
                EnvironmentMapExtensionExternalComponentSimpleExpressionOperator._member_map_.values(),
            )
        )


class EnvironmentMapExtensionExternalComponentSimpleExpressionProperty(Enum):
    """An enumeration representing different categories.

    :cvar ACCOUNTID: "ACCOUNT_ID"
    :vartype ACCOUNTID: str
    :cvar ENVIRONMENTMAPEXTENSIONID: "ENVIRONMENT_MAP_EXTENSION_ID"
    :vartype ENVIRONMENTMAPEXTENSIONID: str
    :cvar PACKAGEDCOMPONENTUID: "PACKAGED_COMPONENT_UID"
    :vartype PACKAGEDCOMPONENTUID: str
    :cvar COMPONENTID: "COMPONENT_ID"
    :vartype COMPONENTID: str
    :cvar COMPONENTVERSION: "COMPONENT_VERSION"
    :vartype COMPONENTVERSION: str
    :cvar COMPONENTNAME: "COMPONENT_NAME"
    :vartype COMPONENTNAME: str
    :cvar COMPONENTTYPE: "COMPONENT_TYPE"
    :vartype COMPONENTTYPE: str
    """

    ACCOUNTID = "ACCOUNT_ID"
    ENVIRONMENTMAPEXTENSIONID = "ENVIRONMENT_MAP_EXTENSION_ID"
    PACKAGEDCOMPONENTUID = "PACKAGED_COMPONENT_UID"
    COMPONENTID = "COMPONENT_ID"
    COMPONENTVERSION = "COMPONENT_VERSION"
    COMPONENTNAME = "COMPONENT_NAME"
    COMPONENTTYPE = "COMPONENT_TYPE"

    def list():
        """Lists all category values.

        :return: A list of all category values.
        :rtype: list
        """
        return list(
            map(
                lambda x: x.value,
                EnvironmentMapExtensionExternalComponentSimpleExpressionProperty._member_map_.values(),
            )
        )


@JsonMap({})
class EnvironmentMapExtensionExternalComponentSimpleExpression(BaseModel):
    """EnvironmentMapExtensionExternalComponentSimpleExpression

    :param argument: argument, defaults to None
    :type argument: List[str], optional
    :param operator: operator
    :type operator: EnvironmentMapExtensionExternalComponentSimpleExpressionOperator
    :param property: property
    :type property: EnvironmentMapExtensionExternalComponentSimpleExpressionProperty
    """

    def __init__(
        self,
        operator: EnvironmentMapExtensionExternalComponentSimpleExpressionOperator,
        property: EnvironmentMapExtensionExternalComponentSimpleExpressionProperty,
        argument: List[str] = SENTINEL,
        **kwargs
    ):
        """EnvironmentMapExtensionExternalComponentSimpleExpression

        :param argument: argument, defaults to None
        :type argument: List[str], optional
        :param operator: operator
        :type operator: EnvironmentMapExtensionExternalComponentSimpleExpressionOperator
        :param property: property
        :type property: EnvironmentMapExtensionExternalComponentSimpleExpressionProperty
        """
        if argument is not SENTINEL:
            self.argument = argument
        self.operator = self._enum_matching(
            operator,
            EnvironmentMapExtensionExternalComponentSimpleExpressionOperator.list(),
            "operator",
        )
        self.property = self._enum_matching(
            property,
            EnvironmentMapExtensionExternalComponentSimpleExpressionProperty.list(),
            "property",
        )
        self._kwargs = kwargs
