#include <vector>
#include <iostream>
#include <unordered_map>
#include "load_inst.hpp"
#include "build_mdd.hpp"
#include "freq_miner.hpp"
#include "utility.hpp"

namespace largehm {

using namespace std;

int Add_arc(int item,
            unsigned long long int last_arc,
            int& itmset,
            unordered_map<int, unsigned long long int>& ancest_map);

void Add_vec(vector<int>& items_lim,
             unordered_map<int, unsigned long long int>& ancest_map,
             unsigned long long int last_arc,
             int itmset);

vector<Arc>  Tree;
vector<VArc> VTree;
vector<CArc> CTree;

void Build_MDD(vector<int>& items, vector<int>& items_lim) {

    unordered_map<int, unsigned long long int> ancest_map;

    unsigned long long int last_arc = 0;
    int itmset = 0;
    for (vector<int>::iterator it = items.begin(); it != items.end(); ++it)
        last_arc = Add_arc(*it, last_arc, itmset, ancest_map);

    if (!items_lim.empty())
        Add_vec(items_lim, ancest_map, last_arc, itmset);
}

int Add_arc(int item,
            unsigned long long int last_arc,
            int& itmset,
            unordered_map<int, unsigned long long int>& ancest_map) {

    unsigned int anct;
    unordered_map<int, unsigned long long int>::iterator p = ancest_map.find(abs(item));
    if (p == ancest_map.end())
        anct = 0;
    else
        anct = p->second;

    if (item < 0)
        ++itmset;

    unsigned long long int last_sibl = Tree[last_arc].chld;

    if (last_sibl == 0) {
        Tree.emplace_back(item, itmset, anct);
        last_sibl = Tree.size() - 1;
        Tree[last_arc].chld = last_sibl;
        if (anct == 0)
            DFS[abs(item) - 1].str_pnt.push_back(last_sibl);

    }
    else {
        while (Tree[last_sibl].item != item) {
            if (Tree[last_sibl].sibl == 0) {
                Tree.emplace_back(item, itmset, anct);
                Tree[last_sibl].sibl = Tree.size() - 1;
                last_sibl = Tree.size() - 1;
                if (anct == 0)
                    DFS[abs(item) - 1].str_pnt.push_back(last_sibl);
                break;
            }
            last_sibl = Tree[last_sibl].sibl;
        }
    }

    if (anct == 0)
        ++DFS[abs(item) - 1].freq;

    ++Tree[last_sibl].freq;

    ancest_map[abs(item)] = last_sibl;

    return last_sibl;
}

void Add_vec(vector<int>& items_lim,
             unordered_map<int, unsigned long long int>& ancest_map,
             unsigned long long int last_arc,
             int itmset) {

    items_lim.shrink_to_fit();
    vector<bool> counted(L, 0);

    if (Tree[last_arc].itmset > 0) {
        vector<unsigned long long int> ancest(L + 1, 0); // last element is CArc child
        for (unordered_map<int, unsigned long long int>::iterator p = ancest_map.begin();
             p != ancest_map.end(); ++p) {
            ancest[p->first - 1] = p->second;
            counted[p->first - 1] = 1;
        }
        for (int i = 0; i < (int)items_lim.size(); ++i) {
            int cur_itm = abs(items_lim[i]);
            if (!counted[cur_itm - 1]) {
                if (i + 1 < (int)items_lim.size()) {
                    VDFS[cur_itm - 1].str_pnt.push_back(-i - 1); // negative = CTree
                    VDFS[cur_itm - 1].seq_ID.push_back(CTree.size());
                }
                ++DFS[cur_itm - 1].freq;
                counted[cur_itm - 1] = 1;
            }
        }
        CTree.emplace_back(ancest, items_lim);
        Tree[last_arc].chld = CTree.size() - 1;
        Tree[last_arc].itmset = -itmset; // negative itmset = connection to CTree
    }
    else {
        vector<unsigned long long int>& ancest = CTree[Tree[last_arc].chld].ancest;
        for (int i = 0; i < (int)items_lim.size(); ++i) {
            int cur_itm = abs(items_lim[i]);
            if (!counted[cur_itm - 1] && ancest[cur_itm - 1] == 0) {
                if (i + 1 < (int)items_lim.size()) {
                    VDFS[cur_itm - 1].str_pnt.push_back(i + 1);
                    VDFS[cur_itm - 1].seq_ID.push_back(VTree.size());
                }
                ++DFS[cur_itm - 1].freq;
                counted[cur_itm - 1] = 1;
            }
        }
        VTree.emplace_back(items_lim,
                           CTree[Tree[last_arc].chld].ancest.back());
        // VTree siblings and CTree children are +1 of their actual position
        CTree[Tree[last_arc].chld].ancest.back() = VTree.size();
    }
}

} // namespace largehm
