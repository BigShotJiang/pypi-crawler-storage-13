#pragma once

#include <vector>
#include <string>
#include <fstream>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <time.h>

namespace largehm {

using namespace std;

bool Load_instance(string& items_file, double thresh);

extern string out_file, folder;

extern bool b_disp, b_write, use_dic, just_build, pre_pro, itmset_exists;

extern unsigned int M, L, mlim, time_limit;

extern unsigned long long int N, theta, E;

extern clock_t start_time;

} // namespace largehm
