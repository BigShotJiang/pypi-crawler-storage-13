import rasterio
import geopandas as gpd
import numpy as np
from shapely.geometry import shape
from skimage import measure
import torch
import torch.nn as nn
import os
import json
from .models.hf_model_manager import HuggingFaceModelManager

class FloodGeoAITool:
    def __init__(self, model_path=None, model_name='default', repo_id=None):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
        if repo_id is None:
            repo_id = "yourusername/flood-detection-model"
        
        self.model_manager = HuggingFaceModelManager(repo_id)
        
        if model_path:
            self.model_path = model_path
            print(f"Using custom model: {model_path}")
        else:
            self.model_path = self.model_manager.get_model_path(model_name)
            print(f"Using pre-trained model: {model_name}")
            
        self.model = self.load_model()
        print(f"✓ Model loaded successfully")
    
    def load_model(self):
        try:
            model_data = torch.load(self.model_path, map_location='cpu')
            
            if isinstance(model_data, dict):
                print("Detected state dictionary format")
                from .models.flood_model import CompatibleUNet
                model = CompatibleUNet(in_channels=6, out_channels=2)
                model.load_state_dict(model_data, strict=False)
            else:
                model = model_data
            
            model.eval()
            return model.to(self.device)
            
        except Exception as e:
            print(f"Error loading model: {e}")
            raise
    
    def preprocess_image(self, image_array, normalize=True):
        original_dtype = image_array.dtype
        
        if normalize:
            if image_array.dtype == np.uint16:
                image_array = image_array.astype(np.float32) / 65535.0
            elif image_array.dtype == np.uint8:
                image_array = image_array.astype(np.float32) / 255.0
            else:
                image_array = image_array.astype(np.float32)
        else:
            if image_array.dtype in [np.uint8, np.uint16, np.int16, np.int32]:
                pass
            else:
                image_array = image_array.astype(np.int32)
            
        if len(image_array.shape) == 2:
            image_array = np.expand_dims(image_array, axis=0)
        elif len(image_array.shape) == 3:
            if image_array.shape[2] <= 6:
                image_array = np.moveaxis(image_array, 2, 0)
        
        return image_array

    def select_sentinel_bands(self, image_array, band_indices=[1, 2, 3, 7, 10, 11]):
        if image_array.shape[0] >= 12:
            selected_bands = image_array[band_indices, :, :]
            return selected_bands
        elif image_array.shape[0] == 6:
            return image_array
        else:
            return image_array[:6, :, :]

    def detect_surface_water(self, image_path, confidence_threshold=0.5, normalize_input=True):
        with rasterio.open(image_path) as src:
            image_data = src.read()
            transform = src.transform
            crs = src.crs
        
        processed_image = self.select_sentinel_bands(image_data)
        processed_image = self.preprocess_image(processed_image, normalize=normalize_input)
        
        input_tensor = torch.from_numpy(processed_image).unsqueeze(0).float().to(self.device)
        
        with torch.no_grad():
            output = self.model(input_tensor)
            
            if output.shape[1] == 2:
                probabilities = torch.softmax(output, dim=1)
                water_probabilities = probabilities[:, 1, :, :]
                water_mask = (water_probabilities.squeeze().cpu().numpy() > confidence_threshold).astype(np.uint8)
            else:
                predictions = torch.sigmoid(output).squeeze().cpu().numpy()
                water_mask = (predictions > confidence_threshold).astype(np.uint8)
        
        return water_mask, transform, crs

    def polygonize_water_mask(self, water_mask, transform, crs, min_area=1000):
        contours = measure.find_contours(water_mask, 0.5)
        
        polygons = []
        for contour in contours:
            coords = [rasterio.transform.xy(transform, row, col) for row, col in contour]
            polygon = shape({"type": "Polygon", "coordinates": [coords]})
            
            if polygon.area >= min_area:
                polygons.append(polygon)
        
        if polygons:
            water_gdf = gpd.GeoDataFrame({
                'id': range(len(polygons)),
                'class': ['water'] * len(polygons),
                'area_sq_m': [poly.area for poly in polygons],
                'geometry': polygons
            }, crs=crs)
            return water_gdf
        else:
            return gpd.GeoDataFrame(columns=['id', 'class', 'area_sq_m', 'geometry'], crs=crs)

    def analyze_flood_impact(self, water_polygons_gdf, buildings_gdf):
        buildings_gdf = buildings_gdf.copy()
        buildings_gdf['flood_status'] = 'dry'
        
        if water_polygons_gdf.empty:
            stats = {
                'total_buildings': len(buildings_gdf),
                'flooded_buildings': 0,
                'flooded_percentage': 0.0,
                'total_water_area': 0.0
            }
            return buildings_gdf, stats
        
        water_union = water_polygons_gdf.unary_union
        buildings_in_water_mask = buildings_gdf.geometry.intersects(water_union)
        buildings_gdf.loc[buildings_in_water_mask, 'flood_status'] = 'flooded'
        
        stats = {
            'total_buildings': len(buildings_gdf),
            'flooded_buildings': buildings_in_water_mask.sum(),
            'flooded_percentage': (buildings_in_water_mask.sum() / len(buildings_gdf)) * 100,
            'total_water_area': water_polygons_gdf.geometry.area.sum()
        }
        
        return buildings_gdf, stats

    def generate_risk_map(self, buildings_gdf, water_polygons_gdf, buffer_distance=50):
        buildings_gdf = buildings_gdf.copy()
        
        if water_polygons_gdf.empty:
            buildings_gdf['risk_level'] = 'low'
            return buildings_gdf
        
        water_union = water_polygons_gdf.unary_union
        high_risk_zone = water_union.buffer(buffer_distance)
        medium_risk_zone = water_union.buffer(buffer_distance * 2).difference(high_risk_zone)
        
        def assign_risk(geometry, flood_status):
            if flood_status == 'flooded':
                return 'very high'
            elif geometry.intersects(high_risk_zone):
                return 'high'
            elif geometry.intersects(medium_risk_zone):
                return 'medium'
            else:
                return 'low'
        
        buildings_gdf['risk_level'] = buildings_gdf.apply(
            lambda row: assign_risk(row.geometry, row.flood_status), 
            axis=1
        )
        
        return buildings_gdf

    # THIS IS THE CRITICAL METHOD THAT WAS MISSING
    def run_analysis(self, satellite_image_path, building_footprints_path, output_dir="./output", 
                    confidence_threshold=0.5, use_integer_values=False):
        """
        Run complete flood analysis pipeline.
        """
        os.makedirs(output_dir, exist_ok=True)
        
        print("Step 1: Detecting surface water...")
        water_mask, transform, crs = self.detect_surface_water(
            satellite_image_path, confidence_threshold, normalize_input=not use_integer_values
        )
        
        print("Step 2: Converting water mask to polygons...")
        water_polygons = self.polygonize_water_mask(water_mask, transform, crs)
        
        print("Step 3: Loading building footprints...")
        buildings = gpd.read_file(building_footprints_path)
        
        if buildings.crs != crs:
            buildings = buildings.to_crs(crs)
        
        print("Step 4: Analyzing flood impact...")
        buildings_with_status, stats = self.analyze_flood_impact(water_polygons, buildings)
        
        print("Step 5: Generating risk map...")
        risk_map = self.generate_risk_map(buildings_with_status, water_polygons)
        
        print("Step 6: Saving results...")
        if not water_polygons.empty:
            water_polygons.to_file(f"{output_dir}/detected_water.shp")
        
        risk_map.to_file(f"{output_dir}/flood_risk_map.shp")
        
        if 'flood_status' in risk_map.columns:
            flooded_buildings = risk_map[risk_map['flood_status'] == 'flooded']
            if not flooded_buildings.empty:
                flooded_buildings.to_file(f"{output_dir}/flooded_buildings.shp")
        
        with open(f"{output_dir}/statistics.json", 'w') as f:
            json.dump(stats, f, indent=2)
        
        print(f"Analysis complete! {stats['flooded_buildings']} buildings flooded")
        return risk_map, water_polygons, stats