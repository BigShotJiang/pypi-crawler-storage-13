shiboken_library_soversion = "6.10"

version = "6.10.1"
version_info = (6, 10, 1, "", "")

__build_date__ = '2025-11-18T13:35:08+00:00'




__setup_py_package_version__ = '6.10.1'
__qt_macos_min_deployment_target__ = '13'
