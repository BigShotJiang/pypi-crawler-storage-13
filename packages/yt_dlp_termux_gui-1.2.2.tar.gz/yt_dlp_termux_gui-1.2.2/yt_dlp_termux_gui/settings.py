import json
import os

from . import constants, utils

defaults = {
    "Media URL": "https://example.com/video",
    "Output Directory": "~/storage/downloads",
    "Start Time (optional)": "*00:00",
    "End Time (optional)": "inf",
    "Cookies File (optional)": os.path.join(constants.SETTINGS_DIR, "cookies.txt"),
    "Filename Template": "%(uploader).30B - %(title)s (%(extractor)s) [%(upload_date>%Y-%m-%d)s].%(ext)s",
    "Additional Arguments": " ".join(constants.ADDITIONAL_ARGS_TEMPLATE),
    "Force Keyframes at Cuts": "True",
    "Verbose Logging": "False",
    "Check for Updates at Startup": "True",
    "last_update_check_unix": "0",
}


def parse_settings(existing_settings: dict, from_file: bool = True, skip: bool = False) -> dict:
    if skip:
        return existing_settings
    parsed_settings: dict = {}
    def to_str(key: str) -> bool:
        parsed_settings[key] = str(existing_settings[key])
    def to_bool(key: str) -> bool:
        parsed_settings[key] = to_str(key)
        parsed_settings[key] = True if existing_settings[key] == "True" or existing_settings[key] is True else False
    def to_int(key: str) -> bool:
        if key not in ["last_update_check_unix"]:
            return
        parsed_settings[key] = int(existing_settings[key])
    for k, v in existing_settings.items():
        if from_file and k in ["Force Keyframes at Cuts", "Verbose Logging", "Check for Updates at Startup"]:
            to_bool(k)
        elif from_file and k in ["last_update_check_unix"]:
            to_int(k)
        else:
            to_str(k)
    return parsed_settings


def load_settings(with_defaults: bool = True, parse: bool = True) -> dict:
    skip = not parse
    utils.assign_permissions_to_path(constants.PACKAGE_CONFIG_DIR)
    if os.path.exists(constants.SETTINGS_PATH):
        with open(constants.SETTINGS_PATH, "r") as f:
            existing_settings: dict = json.load(f)
            if not with_defaults:
                return parse_settings(existing_settings, skip=skip)
            settings_with_defaults: dict = {}
            for k, v in existing_settings.items():
                settings_with_defaults[k] = v
            for k, v in defaults.items():
                if k not in settings_with_defaults:
                    settings_with_defaults[k] = v
            return parse_settings(settings_with_defaults, skip=skip)
    if not with_defaults:
        return {}
    return parse_settings(defaults, skip=skip)


def save_settings(existing_settings: dict):
    utils.assign_permissions_to_path(constants.PACKAGE_CONFIG_DIR)
    settings_dir = os.path.dirname(constants.SETTINGS_PATH)
    os.makedirs(settings_dir, exist_ok=True)
    updated_settings = parse_settings(existing_settings, from_file=False)
    updated_settings.pop("Media URL", None)
    with open(constants.SETTINGS_PATH, "w") as f:
        json.dump(updated_settings, f, indent=2)


def reset_settings():
    save_settings(defaults)
