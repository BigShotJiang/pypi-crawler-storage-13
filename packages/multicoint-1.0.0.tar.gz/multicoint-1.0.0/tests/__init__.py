"""Tests for multicoint package"""
