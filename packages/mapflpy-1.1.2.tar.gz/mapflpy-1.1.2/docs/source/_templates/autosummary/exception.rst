{{ fullname }}
{{ underline }}

.. autoexception:: {{ fullname }}