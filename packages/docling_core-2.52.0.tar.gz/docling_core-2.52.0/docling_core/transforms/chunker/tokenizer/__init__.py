"""Define the tokenizer types."""
