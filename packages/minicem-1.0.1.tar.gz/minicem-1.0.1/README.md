# minicem

Kompakt, insan tarafından okunabilir minik bir metin formatı ve Python için
encoder/decoder fonksiyonları.

Amaç: JSON kadar gürültülü olmayan, config dosyalarında rahat yazılabilen,
hem tek satırlık hem de YAML benzeri çok satırlı yapıları destekleyen ufak bir
ara format.

## Özellikler

- ✅ Dict ve list yapıları:
  - `{key:val, key2:val2}`
  - `[1,2,3]`
- ✅ Kompakt bool ve None:
  - `True  -> +1`
  - `False -> +0`
  - `None  -> _`
- ✅ Yorum desteği:
  - Tırnak dışındaki `#` sonrası yorum kabul edilir.
- ✅ Tek satır veya çok satırlı (YAML benzeri) blok formatı
- ✅ Basit Python tipleri:
  - `dict`, `list`, `str`, `int`, `float`, `bool`, `None`

## Kurulum

PyPI'ya yüklendikten sonra:

```bash
pip install minicem
