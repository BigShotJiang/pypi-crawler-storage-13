"""
Watt meter CLI commands.
"""
