# codeXglitch

🔍 **Offline Static Analysis for Python** — Find logic errors, performance issues, and security bugs without cloud services.

codeXglitch is a lightweight static analysis tool that helps beginner and experienced developers catch bugs early. It uses small, efficient pattern-based detectors and doesn't require internet or external ML services.

## Features

✨ **Works Offline** — No cloud, no internet required

🤖 **Lightweight ML Models** — Uses pattern-based detection, not heavy neural networks

🐛 **Detects Multiple Bug Types:**
- Logic Errors (division by zero, always-true conditions, suspicious comparisons)
- Performance Issues (nested loops, inefficient operations)
- Security Vulnerabilities (eval/exec usage, hardcoded secrets, unsafe functions)

🎓 **Beginner-Friendly** — Clear error messages with suggestions

⚡ **Fast Analysis** — Analyzes files and directories in milliseconds

## Installation

```bash
pip install -e .
```

## Usage

### Command Line

```bash
# Analyze a single file
codeXglitch analyze myfile.py

# Analyze entire directory
codeXglitch analyze src/ --recursive

# Output as JSON
codeXglitch analyze src/ --format json

# Only show critical issues
codeXglitch analyze src/ --severity critical
```

### Python API

```python
from codesense import CodeAnalyzer

analyzer = CodeAnalyzer()

# Analyze a file
issues = analyzer.analyze_file("myfile.py")

# Analyze code directly
code = """
x = 10 / 0  # Division by zero
if y == True:  # Suspicious comparison
    pass
"""

issues = analyzer.analyze_code(code)

for issue in issues:
    print(issue)
    if issue.suggestion:
        print(f"  → {issue.suggestion}")
```

## Output Examples

### Text Format (Default)
```
myfile.py:1:8 [CRITICAL] L005: Division by zero will cause runtime error
  → Check denominator before division
myfile.py:2:4 [LOW] L001: Use 'if x:' instead of 'if x == True'
  → Use 'if x:' for clearer code

Summary:
  Critical: 1
  Low: 1
```

### JSON Format
```json
[
  {
    "file": "myfile.py",
    "line": 1,
    "column": 8,
    "code": "L005",
    "message": "Division by zero will cause runtime error",
    "severity": "critical",
    "rule": "division_by_zero",
    "suggestion": "Check denominator before division"
  }
]
```

## Supported Rules

### Logic Errors (L-series)
- **L001**: Comparison with True (use `if x:` instead)
- **L002**: Comparison with False (use `if not x:` instead)
- **L003**: Condition is always True
- **L004**: Condition is always False
- **L005**: Division by zero

### Performance Issues (P-series)
- **P001**: Nested loop with append() - Consider list comprehension
- **P002**: len() called in loop - Store length in variable

### Security Issues (S-series)
- **S001**: Use of eval() - Use ast.literal_eval() or json.loads() instead
- **S002**: Use of exec() - Avoid for security reasons
- **S003**: Unvalidated user input() - Validate and sanitize input
- **S004**: Use of os.system() - Use subprocess.run() with shell=False
- **S005**: Hardcoded secrets - Use environment variables

### Miscellaneous (M-series)
- **M001**: Typo detection
- **M002**: Suspicious variable names

## Development

### Install Development Dependencies

```bash
pip install -e .
pip install -r requirements-dev.txt
```

### Run Tests

```bash
python tests/test_analyzer.py
```

### Run Analysis on codeXglitch Itself

```bash
codeXglitch analyze src/ --recursive
```

## How It Works

CodeSense-AI uses Python's `ast` module to parse code into an Abstract Syntax Tree, then applies multiple independent analyzers:

1. **Logic Analyzer** — Detects illogical code patterns
2. **Performance Analyzer** — Finds inefficient operations
3. **Security Analyzer** — Identifies security anti-patterns

Each analyzer uses pattern matching and simple heuristics — no heavy ML models required!

## Project Structure

```
codesense-ai/
├── src/codesense/
│   ├── __init__.py          # Main package
│   ├── analyzer.py          # Main analyzer orchestrator
│   ├── issue.py             # Issue representation
│   ├── cli.py               # Command-line interface
│   ├── analyzers/
│   │   ├── logic_analyzer.py
│   │   ├── performance_analyzer.py
│   │   └── security_analyzer.py
│   └── models/
│       └── ml_predictor.py  # Simple ML-based pattern detection
├── tests/
│   └── test_analyzer.py
└── README.md
```

## Limitations

- Analyzes Python code only
- Pattern-based detection (not AI/ML cloud)
- Best suited for beginner-to-intermediate code
- May produce false positives/negatives

## License

MIT License - see LICENSE file for details

## Contributing

Contributions welcome! Feel free to:
- Report bugs and issues
- Suggest new detection rules
- Improve existing analyzers
- Add more test cases
