"""
Main code analyzer orchestrator
"""

import ast
from pathlib import Path
from typing import List, Optional

from .issue import Issue
from .analyzers.logic_analyzer import LogicAnalyzer
from .analyzers.performance_analyzer import PerformanceAnalyzer
from .analyzers.security_analyzer import SecurityAnalyzer


class CodeAnalyzer:
    """Main analyzer that orchestrates all bug detectors"""
    
    def __init__(self):
        self.analyzers = [
            LogicAnalyzer(),
            PerformanceAnalyzer(),
            SecurityAnalyzer(),
        ]
    
    def analyze_file(self, file_path: str) -> List[Issue]:
        """Analyze a single Python file for bugs"""
        issues = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                code = f.read()
        except (IOError, OSError) as e:
            return issues
        
        try:
            tree = ast.parse(code)
        except SyntaxError:
            return issues
        
        # Run all analyzers
        for analyzer in self.analyzers:
            try:
                found_issues = analyzer.analyze(tree, code, file_path)
                issues.extend(found_issues)
            except Exception:
                # Silently skip analyzers that fail
                pass
        
        # Sort by line and column
        issues.sort(key=lambda x: (x.line, x.column))
        return issues
    
    def analyze_directory(self, dir_path: str, pattern: str = "**/*.py") -> List[Issue]:
        """Analyze all Python files in a directory"""
        issues = []
        path = Path(dir_path)
        
        for py_file in path.glob(pattern):
            if '.venv' not in py_file.parts and '__pycache__' not in py_file.parts:
                file_issues = self.analyze_file(str(py_file))
                issues.extend(file_issues)
        
        return sorted(issues, key=lambda x: (x.file, x.line, x.column))
    
    def analyze_code(self, code: str, file_name: str = "<string>") -> List[Issue]:
        """Analyze code from a string"""
        issues = []
        
        try:
            tree = ast.parse(code)
        except SyntaxError:
            return issues
        
        for analyzer in self.analyzers:
            try:
                found_issues = analyzer.analyze(tree, code, file_name)
                issues.extend(found_issues)
            except Exception:
                pass
        
        issues.sort(key=lambda x: (x.line, x.column))
        return issues
