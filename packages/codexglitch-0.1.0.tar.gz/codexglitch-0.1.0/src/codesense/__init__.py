"""
codeXglitch - Static Analysis Tool for Bug Detection
A lightweight, offline bug detection tool using small ML models.
"""

__version__ = "0.1.0"
__author__ = "codeXglitch Team"
__license__ = "MIT"

from .analyzer import CodeAnalyzer
from .issue import Issue, IssueSeverity

__all__ = ["CodeAnalyzer", "Issue", "IssueSeverity"]
