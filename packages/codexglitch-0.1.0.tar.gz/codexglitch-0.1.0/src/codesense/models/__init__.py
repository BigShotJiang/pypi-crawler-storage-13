"""
Models package initialization
"""

from .ml_predictor import SimpleBugPredictor

__all__ = ["SimpleBugPredictor"]
