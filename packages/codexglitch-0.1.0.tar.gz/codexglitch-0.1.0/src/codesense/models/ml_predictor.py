"""
Lightweight ML-based pattern detector
"""

import ast
import re
from typing import List, Dict, Tuple

from ..issue import Issue, IssueSeverity


class SimpleBugPredictor:
    """
    Lightweight ML-inspired bug predictor using pattern matching
    No external ML libraries - uses simple statistical patterns
    """
    
    def __init__(self):
        # Common bug patterns with confidence scores
        self.patterns = {
            # Naming patterns that suggest bugs
            'undefined_var': re.compile(r'\b[A-Z_]+\s*='),  # ALL_CAPS might be used as variable
            'single_char_var': re.compile(r'\b[a-z]\s*='),  # Single letter variables in loops
        }
        self.suspicious_names = ['tmp', 'temp', 'x', 'xx', 'y', 'z', 'a', 'b', 'c']
    
    def predict_issues(self, tree: ast.AST, code: str, file_path: str) -> List[Issue]:
        """Predict potential bugs using pattern analysis"""
        issues = []
        code_lines = code.split('\n')
        
        # Check for common misspellings and typos
        issues.extend(self._check_common_mistakes(code_lines, file_path))
        
        # Check variable naming patterns
        issues.extend(self._check_variable_patterns(tree, code_lines, file_path))
        
        return issues
    
    def _check_common_mistakes(self, code_lines: List[str], file_path: str) -> List[Issue]:
        """Detect common programming mistakes"""
        issues = []
        
        # Check for common typos like 'lenght' instead of 'length'
        typo_patterns = {
            'lenght': ('length', 'Typo in variable name'),
            'lengh': ('len', 'Typo in variable name'),
            'recieve': ('receive', 'Typo in variable name'),
        }
        
        for line_num, line in enumerate(code_lines, 1):
            for typo, (correct, msg) in typo_patterns.items():
                if typo in line:
                    issues.append(Issue(
                        file=file_path,
                        line=line_num,
                        column=line.find(typo),
                        code="M001",
                        message=f"Possible typo: '{typo}' (did you mean '{correct}'?)",
                        severity=IssueSeverity.LOW,
                        rule="typo_detection",
                        suggestion=f"Use '{correct}' instead"
                    ))
        
        return issues
    
    def _check_variable_patterns(self, tree: ast.AST, code_lines: List[str], file_path: str) -> List[Issue]:
        """Check for suspicious variable naming patterns"""
        issues = []
        
        class VarChecker(ast.NodeVisitor):
            def __init__(self, parent_obj):
                self.parent = parent_obj
                self.issues = []
                self.file_path = file_path
                self.code_lines = code_lines
            
            def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
                # Check function parameter names
                for arg in node.args.args:
                    if arg.arg in self.parent.suspicious_names:
                        self.issues.append(Issue(
                            file=self.file_path,
                            line=node.lineno,
                            column=node.col_offset,
                            code="M002",
                            message=f"Suspicious parameter name: '{arg.arg}'",
                            severity=IssueSeverity.LOW,
                            rule="suspicious_variable_name",
                            suggestion=f"Use more descriptive name instead of '{arg.arg}'"
                        ))
                
                self.generic_visit(node)
        
        checker = VarChecker(self)
        checker.visit(tree)
        return checker.issues
