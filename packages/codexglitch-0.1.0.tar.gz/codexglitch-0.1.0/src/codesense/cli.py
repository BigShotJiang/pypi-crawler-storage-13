"""
Command-line interface for CodeSense-AI
"""

import sys
import json
import argparse
from pathlib import Path
from typing import List

from codesense import CodeAnalyzer, Issue


def format_json(issues: List[Issue]) -> str:
    """Format issues as JSON"""
    return json.dumps([issue.to_dict() for issue in issues], indent=2)


def format_text(issues: List[Issue]) -> str:
    """Format issues as human-readable text"""
    if not issues:
        return "✓ No issues found!"
    
    lines = []
    severity_counts = {}
    
    for issue in issues:
        severity = issue.severity.value
        severity_counts[severity] = severity_counts.get(severity, 0) + 1
        lines.append(str(issue))
        if issue.suggestion:
            lines.append(f"  → {issue.suggestion}")
    
    lines.append("")
    lines.append("Summary:")
    for severity in ["critical", "high", "medium", "low"]:
        count = severity_counts.get(severity, 0)
        if count > 0:
            lines.append(f"  {severity.capitalize()}: {count}")
    
    return "\n".join(lines)


def format_github(issues: List[Issue]) -> str:
    """Format issues for GitHub Actions workflow"""
    lines = []
    for issue in issues:
        # GitHub format: ::warning file=file.py,line=1,col=2::message
        prefix = "::" + issue.severity.value
        lines.append(
            f"{prefix} file={issue.file},line={issue.line},col={issue.column}::"
            f"[{issue.code}] {issue.message}"
        )
    return "\n".join(lines)


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="CodeSense-AI - Offline static analysis tool for bug detection",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  codesense-ai analyze myfile.py
  codesense-ai analyze src/ --recursive
  codesense-ai analyze src/ --format json
  codesense-ai analyze src/ --format github
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Command to run')
    
    # Analyze command
    analyze_parser = subparsers.add_parser('analyze', help='Analyze Python files')
    analyze_parser.add_argument(
        'path',
        help='File or directory to analyze'
    )
    analyze_parser.add_argument(
        '--recursive', '-r',
        action='store_true',
        help='Recursively analyze directories'
    )
    analyze_parser.add_argument(
        '--format', '-f',
        choices=['text', 'json', 'github'],
        default='text',
        help='Output format (default: text)'
    )
    analyze_parser.add_argument(
        '--severity', '-s',
        choices=['low', 'medium', 'high', 'critical'],
        help='Only show issues of this severity or higher'
    )
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    if args.command == 'analyze':
        return analyze_command(args)
    
    return 1


def analyze_command(args) -> int:
    """Execute analyze command"""
    analyzer = CodeAnalyzer()
    path = Path(args.path)
    
    if not path.exists():
        print(f"Error: Path '{args.path}' does not exist", file=sys.stderr)
        return 1
    
    # Analyze file or directory
    if path.is_file():
        issues = analyzer.analyze_file(str(path))
    else:
        pattern = "**/*.py" if args.recursive else "*.py"
        issues = analyzer.analyze_directory(str(path), pattern)
    
    # Filter by severity if specified
    if args.severity:
        severity_levels = {'critical': 3, 'high': 2, 'medium': 1, 'low': 0}
        min_level = severity_levels[args.severity]
        issues = [
            issue for issue in issues
            if severity_levels[issue.severity.value] >= min_level
        ]
    
    # Format and print output
    if args.format == 'json':
        print(format_json(issues))
    elif args.format == 'github':
        output = format_github(issues)
        if output:
            print(output)
        else:
            print("✓ No issues found!")
    else:  # text
        print(format_text(issues))
    
    # Return non-zero if critical issues found
    critical_issues = [i for i in issues if i.severity.value == 'critical']
    return 1 if critical_issues else 0


if __name__ == '__main__':
    sys.exit(main())
