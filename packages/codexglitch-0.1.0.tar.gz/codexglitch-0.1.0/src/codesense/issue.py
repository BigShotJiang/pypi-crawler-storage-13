"""
Issue representation and severity levels
"""

from enum import Enum
from dataclasses import dataclass
from typing import Optional


class IssueSeverity(Enum):
    """Bug severity levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class Issue:
    """Represents a detected code issue"""
    file: str
    line: int
    column: int
    code: str
    message: str
    severity: IssueSeverity
    rule: str
    suggestion: Optional[str] = None
    
    def __str__(self) -> str:
        return (
            f"{self.file}:{self.line}:{self.column} "
            f"[{self.severity.value.upper()}] {self.code}: {self.message}"
        )
    
    def to_dict(self) -> dict:
        """Convert issue to dictionary"""
        return {
            "file": self.file,
            "line": self.line,
            "column": self.column,
            "code": self.code,
            "message": self.message,
            "severity": self.severity.value,
            "rule": self.rule,
            "suggestion": self.suggestion,
        }
