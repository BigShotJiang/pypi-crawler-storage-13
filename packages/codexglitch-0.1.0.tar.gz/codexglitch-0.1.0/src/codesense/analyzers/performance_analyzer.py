"""
Performance issue detection analyzer
"""

import ast
from typing import List

from .base import BaseAnalyzer
from ..issue import Issue, IssueSeverity


class PerformanceAnalyzer(BaseAnalyzer):
    """Detects performance issues in Python code"""
    
    def analyze(self, tree: ast.AST, code: str, file_path: str) -> List[Issue]:
        """Analyze code for performance issues"""
        self.issues = []
        self.code_lines = code.split('\n')
        self.file_path = file_path
        
        visitor = PerformanceVisitor(self.file_path, self.code_lines)
        visitor.visit(tree)
        
        return visitor.issues


class PerformanceVisitor(ast.NodeVisitor):
    """AST visitor for performance issues"""
    
    def __init__(self, file_path: str, code_lines: List[str]):
        self.file_path = file_path
        self.code_lines = code_lines
        self.issues = []
        self.in_loop = False
        self.loop_depth = 0
    
    def visit_For(self, node: ast.For) -> None:
        """Check for performance issues in loops"""
        self.loop_depth += 1
        self.in_loop = True
        
        # Check for list.append in nested loops
        self._check_loop_body(node.body)
        
        self.generic_visit(node)
        self.loop_depth -= 1
        if self.loop_depth == 0:
            self.in_loop = False
    
    def visit_While(self, node: ast.While) -> None:
        """Check while loops"""
        self.loop_depth += 1
        self.in_loop = True
        
        self._check_loop_body(node.body)
        
        self.generic_visit(node)
        self.loop_depth -= 1
        if self.loop_depth == 0:
            self.in_loop = False
    
    def _check_loop_body(self, body: List[ast.stmt]) -> None:
        """Check loop body for performance issues"""
        for stmt in body:
            if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
                call = stmt.value
                if isinstance(call.func, ast.Attribute):
                    if (call.func.attr == "append" and self.loop_depth > 1):
                        self.issues.append(Issue(
                            file=self.file_path,
                            line=stmt.lineno,
                            column=stmt.col_offset,
                            code="P001",
                            message="Nested loop with append() may be slow",
                            severity=IssueSeverity.MEDIUM,
                            rule="nested_loop_append",
                            suggestion="Consider list comprehension or pre-allocating list"
                        ))
    
    def visit_Call(self, node: ast.Call) -> None:
        """Check for inefficient function calls"""
        if isinstance(node.func, ast.Name):
            # Check for len() in loop condition
            if node.func.id == "len" and self.in_loop:
                if isinstance(node.func, ast.Name):
                    self.issues.append(Issue(
                        file=self.file_path,
                        line=node.lineno,
                        column=node.col_offset,
                        code="P002",
                        message="Calling len() in loop may be inefficient",
                        severity=IssueSeverity.LOW,
                        rule="len_in_loop",
                        suggestion="Store length in variable before loop"
                    ))
        
        self.generic_visit(node)
    
    def visit_ListComp(self, node: ast.ListComp) -> None:
        """Check list comprehensions"""
        self.generic_visit(node)
