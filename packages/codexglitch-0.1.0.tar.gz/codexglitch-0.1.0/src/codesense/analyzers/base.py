"""
Base analyzer class
"""

import ast
from abc import ABC, abstractmethod
from typing import List

from ..issue import Issue


class BaseAnalyzer(ABC):
    """Base class for all analyzers"""
    
    def __init__(self):
        self.issues = []
        self.code_lines = []
        self.file_path = ""
    
    @abstractmethod
    def analyze(self, tree: ast.AST, code: str, file_path: str) -> List[Issue]:
        """Analyze AST tree and return list of issues"""
        pass
    
    def _get_line_content(self, line_num: int) -> str:
        """Get the content of a specific line"""
        if 0 < line_num <= len(self.code_lines):
            return self.code_lines[line_num - 1]
        return ""
    
    def _find_column_for_issue(self, node: ast.AST) -> int:
        """Get column offset from AST node"""
        return getattr(node, 'col_offset', 0)
