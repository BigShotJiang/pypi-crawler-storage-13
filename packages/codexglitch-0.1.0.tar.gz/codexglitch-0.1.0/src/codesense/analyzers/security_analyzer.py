"""
Security issue detection analyzer
"""

import ast
from typing import List

from .base import BaseAnalyzer
from ..issue import Issue, IssueSeverity


class SecurityAnalyzer(BaseAnalyzer):
    """Detects security issues in Python code"""
    
    def analyze(self, tree: ast.AST, code: str, file_path: str) -> List[Issue]:
        """Analyze code for security issues"""
        self.issues = []
        self.code_lines = code.split('\n')
        self.file_path = file_path
        
        visitor = SecurityVisitor(self.file_path, self.code_lines)
        visitor.visit(tree)
        
        return visitor.issues


class SecurityVisitor(ast.NodeVisitor):
    """AST visitor for security issues"""
    
    def __init__(self, file_path: str, code_lines: List[str]):
        self.file_path = file_path
        self.code_lines = code_lines
        self.issues = []
    
    def visit_Call(self, node: ast.Call) -> None:
        """Check for dangerous function calls"""
        if isinstance(node.func, ast.Name):
            # Check for eval()
            if node.func.id == "eval":
                self.issues.append(Issue(
                    file=self.file_path,
                    line=node.lineno,
                    column=node.col_offset,
                    code="S001",
                    message="Use of eval() is dangerous",
                    severity=IssueSeverity.CRITICAL,
                    rule="eval_usage",
                    suggestion="Use ast.literal_eval() or json.loads() instead"
                ))
            # Check for exec()
            elif node.func.id == "exec":
                self.issues.append(Issue(
                    file=self.file_path,
                    line=node.lineno,
                    column=node.col_offset,
                    code="S002",
                    message="Use of exec() is dangerous",
                    severity=IssueSeverity.CRITICAL,
                    rule="exec_usage",
                    suggestion="Avoid exec() for security reasons"
                ))
            # Check for input() without validation
            elif node.func.id == "input" and len(node.args) == 0:
                self.issues.append(Issue(
                    file=self.file_path,
                    line=node.lineno,
                    column=node.col_offset,
                    code="S003",
                    message="User input() without validation",
                    severity=IssueSeverity.MEDIUM,
                    rule="unvalidated_input",
                    suggestion="Validate and sanitize user input"
                ))
        
        # Check for os.system()
        elif isinstance(node.func, ast.Attribute):
            if node.func.attr == "system":
                if isinstance(node.func.value, ast.Name) and node.func.value.id == "os":
                    self.issues.append(Issue(
                        file=self.file_path,
                        line=node.lineno,
                        column=node.col_offset,
                        code="S004",
                        message="Use of os.system() may be unsafe",
                        severity=IssueSeverity.HIGH,
                        rule="os_system_usage",
                        suggestion="Use subprocess.run() with shell=False"
                    ))
        
        self.generic_visit(node)
    
    def visit_Assign(self, node: ast.Assign) -> None:
        """Check for hardcoded secrets"""
        if isinstance(node.value, ast.Constant):
            value_str = str(node.value.value).lower()
            # Check for common secret patterns
            if any(keyword in value_str for keyword in ["password", "api_key", "secret"]):
                self.issues.append(Issue(
                    file=self.file_path,
                    line=node.lineno,
                    column=node.col_offset,
                    code="S005",
                    message="Hardcoded secret detected",
                    severity=IssueSeverity.CRITICAL,
                    rule="hardcoded_secret",
                    suggestion="Use environment variables or config files"
                ))
        
        self.generic_visit(node)
