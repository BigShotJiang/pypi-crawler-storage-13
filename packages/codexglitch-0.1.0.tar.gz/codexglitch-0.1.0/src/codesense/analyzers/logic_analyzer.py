"""
Logic error detection analyzer
"""

import ast
from typing import List

from .base import BaseAnalyzer
from ..issue import Issue, IssueSeverity


class LogicAnalyzer(BaseAnalyzer):
    """Detects common logic errors in Python code"""
    
    def analyze(self, tree: ast.AST, code: str, file_path: str) -> List[Issue]:
        """Analyze code for logic errors"""
        self.issues = []
        self.code_lines = code.split('\n')
        self.file_path = file_path
        
        visitor = LogicVisitor(self.file_path, self.code_lines)
        visitor.visit(tree)
        
        return visitor.issues


class LogicVisitor(ast.NodeVisitor):
    """AST visitor for logic errors"""
    
    def __init__(self, file_path: str, code_lines: List[str]):
        self.file_path = file_path
        self.code_lines = code_lines
        self.issues = []
    
    def visit_Compare(self, node: ast.Compare) -> None:
        """Check for suspicious comparisons"""
        # Detect: if x == True (should be 'if x')
        for comparator in node.comparators:
            if isinstance(comparator, ast.Constant):
                if comparator.value is True:
                    self.issues.append(Issue(
                        file=self.file_path,
                        line=node.lineno,
                        column=node.col_offset,
                        code="L001",
                        message="Use 'if x:' instead of 'if x == True'",
                        severity=IssueSeverity.LOW,
                        rule="logic_comparison_with_true",
                        suggestion="Use 'if x:' for clearer code"
                    ))
                elif comparator.value is False:
                    self.issues.append(Issue(
                        file=self.file_path,
                        line=node.lineno,
                        column=node.col_offset,
                        code="L002",
                        message="Use 'if not x:' instead of 'if x == False'",
                        severity=IssueSeverity.LOW,
                        rule="logic_comparison_with_false",
                        suggestion="Use 'if not x:' for clearer code"
                    ))
        
        self.generic_visit(node)
    
    def visit_If(self, node: ast.If) -> None:
        """Check for unreachable code and always-true conditions"""
        # Check for always-true conditions
        if isinstance(node.test, ast.Constant):
            if node.test.value:
                self.issues.append(Issue(
                    file=self.file_path,
                    line=node.lineno,
                    column=node.col_offset,
                    code="L003",
                    message="Condition is always True",
                    severity=IssueSeverity.MEDIUM,
                    rule="always_true_condition",
                    suggestion="Remove unnecessary condition"
                ))
            else:
                self.issues.append(Issue(
                    file=self.file_path,
                    line=node.lineno,
                    column=node.col_offset,
                    code="L004",
                    message="Condition is always False",
                    severity=IssueSeverity.MEDIUM,
                    rule="always_false_condition",
                    suggestion="Remove dead code block"
                ))
        
        self.generic_visit(node)
    
    def visit_BinOp(self, node: ast.BinOp) -> None:
        """Check for suspicious binary operations"""
        # Detect: x / 0
        if isinstance(node.op, ast.Div):
            if isinstance(node.right, ast.Constant) and node.right.value == 0:
                self.issues.append(Issue(
                    file=self.file_path,
                    line=node.lineno,
                    column=node.col_offset,
                    code="L005",
                    message="Division by zero will cause runtime error",
                    severity=IssueSeverity.CRITICAL,
                    rule="division_by_zero",
                    suggestion="Check denominator before division"
                ))
        
        self.generic_visit(node)
    
    def visit_Return(self, node: ast.Return) -> None:
        """Check for inconsistent return statements"""
        self.generic_visit(node)
