# Procaptcha

Procaptcha is a simple Python library for generating captcha images with distortion, noise, and security lines. Captchas are automatically saved inside the package directory.

## Installation

pip install Procaptcha

## Usage

```python
from Procaptcha import generate_captcha

path, code = generate_captcha("example.png")
print(path)
print(code)