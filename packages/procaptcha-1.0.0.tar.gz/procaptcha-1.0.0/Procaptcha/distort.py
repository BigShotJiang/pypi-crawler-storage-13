from PIL import Image
import math


def wave_distortion(image, amplitude=5, wavelength=30):
    width, height = image.size
    pixels = image.load()
    new_image = Image.new("RGB", (width, height))
    new_pixels = new_image.load()

    for x in range(width):
        for y in range(height):
            offset = int(amplitude * math.sin(2 * math.pi * y / wavelength))
            new_x = x + offset

            if 0 <= new_x < width:
                new_pixels[x, y] = pixels[new_x, y]
            else:
                new_pixels[x, y] = (255, 255, 255)

    return new_image