import os

# путь до папки Procaptcha
BASE_PATH = os.path.dirname(os.path.abspath(__file__))

# папка для хранения капч внутри проекта
CAPTCHA_FOLDER = os.path.join(BASE_PATH, "captchas")

# создаём папку, если её нет
os.makedirs(CAPTCHA_FOLDER, exist_ok=True)