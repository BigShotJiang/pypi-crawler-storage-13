import os
import random
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from .distort import wave_distortion
from .config import CAPTCHA_FOLDER


def generate_code(length=5):
    chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(random.choice(chars) for _ in range(length))


def generate_captcha(save_as: str, length=5, width=180, height=70):
    code = generate_code(length)
    img = Image.new("RGB", (width, height), (255, 255, 255))
    draw = ImageDraw.Draw(img)

    try:
        font = ImageFont.truetype("arial.ttf", 40)
    except:
        font = ImageFont.load_default()

    for _ in range(300):
        draw.point(
            (random.randint(0, width), random.randint(0, height)),
            fill=(random.randint(100, 255),) * 3
        )

    for _ in range(5):
        draw.line(
            (
                random.randint(0, width),
                random.randint(0, height),
                random.randint(0, width),
                random.randint(0, height)
            ),
            fill=(random.randint(0, 255),) * 3,
            width=2
        )

    draw.text((20, 15), code, font=font, fill=(0, 0, 0))
    img = wave_distortion(img, amplitude=6, wavelength=40)
    img = img.filter(ImageFilter.GaussianBlur(0.5))

    full_path = os.path.join(CAPTCHA_FOLDER, save_as)
    img.save(full_path)

    return full_path, code