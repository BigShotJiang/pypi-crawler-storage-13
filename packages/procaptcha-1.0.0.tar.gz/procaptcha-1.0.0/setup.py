from setuptools import setup, find_packages

setup(
    name="Procaptcha",
    version="1.0.0",
    packages=find_packages(),
    install_requires=["Pillow"],
    description="A captcha generator with distortion, noise, and security features",
    author="maksalmaz",
    python_requires=">=3.7",
)