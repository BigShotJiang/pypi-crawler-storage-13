
from django.urls import path

from . import clientcard_views

app_name = "app"

urlpatterns = [

    path('', clientcard_views.clientcard_list, name="index"),  # ← Esta es la URL por defecto    
    path('clientcard-list/', clientcard_views.clientcard_list, name="clientcard_list"),
    path('clientcard-create/', clientcard_views.clientcard_create, name="clientcard_create"),
    path('clientcard-edit/<int:id>', clientcard_views.clientcard_edit, name="clientcard_edit"),
    path('clientcard-detail/<int:id>', clientcard_views.clientcard_detail, name="clientcard_detail"),
    path('clientcard-delete/<int:id>', clientcard_views.clientcard_delete, name="clientcard_delete"),    

]
