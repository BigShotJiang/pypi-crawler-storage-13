
# domain/exceptions.py

class ClientCardError(Exception):
    """Excepción base para errores relacionados con el dominio ClientCard."""
    pass


class ClientCardValueError(ClientCardError):
    """Error de valor en atributos de la entidad ClientCard."""
    def __init__(self, detail: str, field: str = "value"):
        self.field = field
        self.detail = detail
        if field == "value":
            super().__init__(f"Value error: {detail}.")
        else:
            super().__init__(f"Field error in '{field}': {detail}.")


class ClientCardValidationError(ClientCardError):
    """Errores de validación de datos antes de guardar el modelo."""
    def __init__(self, errors):
        self.errors = errors
        super().__init__("Validation in ClientCard failed.")

class ClientCardAlreadyExistsError(ClientCardError):
    """Cuando se intenta crear una ClientCard que ya existe."""
    def __init__(self, detail: str, field: str = "value"):
        self.field = field        
        self.detail = detail
        super().__init__(f"ClientCard already exists.")

class ClientCardNotFoundError(ClientCardError):
    """Cuando se intenta acceder a una ClientCard inexistente."""
    def __init__(self, id):
        self.id = id
        super().__init__(f"ClientCard with ID {id} not found.")

class ClientCardOperationNotAllowedError(ClientCardError):
    """Cuando se intenta realizar una operación no permitida."""
    def __init__(self, operation_name: str):
        super().__init__(f"Operation '{operation_name}' not allowed in ClientCard.")        


class ClientCardPermissionError(ClientCardError):
    """Cuando el usuario no tiene permisos para modificar o acceder."""
    def __init__(self):
        super().__init__("Permission not allowed in ClientCard.")      
