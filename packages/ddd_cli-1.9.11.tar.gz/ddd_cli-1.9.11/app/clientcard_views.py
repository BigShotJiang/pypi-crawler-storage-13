
from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from .utils.filter_dict import clean_dict_of_keys

# importa las excepciones personalizadas
from .domain.exceptions import (
    ClientCardValueError,
    ClientCardValidationError,
    ClientCardAlreadyExistsError,
    ClientCardNotFoundError,
    ClientCardOperationNotAllowedError,
    ClientCardPermissionError
)

# importa las excepciones de repositorio
from .infrastructure.exceptions import (
    ConnectionDataBaseError,
    RepositoryError
)

# Importar formularios específicos de la entidad
from app.clientcard_forms import (
    ClientCardCreateForm, 
    ClientCardEditGetForm, 
    ClientCardEditPostForm, 
    ClientCardViewForm
)

# Importar servicios específicos del dominio
from app.services.clientcard_service import ClientCardService


def clientcard_list(request):
    """
    Vista genérica para mostrar una lista de todas las instancias de clientCard.
    """

    clientCardList = [] #inicialize list

    # Obtener la lista del repositorio
    try:
        clientCardList = ClientCardService().list()

    except (ClientCardValueError) as e:
        messages.error(request,  str(e))
    except (ConnectionDataBaseError, RepositoryError) as e:
        messages.error(request, "There was an error accessing the database or repository: " + str(e))
    except Exception as e:
        messages.error(request, "An unexpected error occurred: " + str(e))

    # Renderizar la plantilla con la lista
    return render(request, 'app/clientcard_web_list.html', {
        'clientCardList': clientCardList
    })


def clientcard_create(request):
    """
    Vista genérica para crear una nueva instancia de clientCard utilizando un servicio.
    """

    if request.method == "POST":

        # Validar los datos del formulario
        form = ClientCardCreateForm(request.POST, request.FILES)

        if form.is_valid():
            try:        
                form_data = form.cleaned_data

                # Obtener el ID de la entidad relacionada si existe
                external_id = request.POST.get('external_id', None)

                # Obtener la lista de ids de externals seleccionadas
                externals_ids = form_data.get('externals', [])

                # LLamar al servicio de creación
                ClientCardService().create(data=form_data, external_id=external_id, externals=externals_ids)

                # Mostrar mensaje de éxito y redirigir
                messages.success(request, f"Successfully created clientCard")
                return redirect('app:clientcard_list')

            except ClientCardAlreadyExistsError as e:
                messages.error(request, "Already Exists Error: " + str(e))
            except (ClientCardValueError, ClientCardValidationError) as e:
                form.add_error(None, "Validation Error: " + str(e))
            except (ConnectionDataBaseError, RepositoryError) as e:
                messages.error(request, "There was an error accessing the database or repository: " + str(e))
            except Exception as e:
                messages.error(request, "An unexpected error occurred: " + str(e))
        else:
            messages.error(request, "There were errors in the form. Please correct them")
    else:
        # Formulario vacío para solicitudes GET
        form = ClientCardCreateForm()

    # Renderizar la plantilla con el formulario
    return render(request, 'app/clientcard_web_create.html', {'form': form}) 


def clientcard_edit(request, id=None):
    """
    Vista genérica para editar una instancia existente de clientCard utilizando un servicio.
    """

    if id is None:
        # Redireccion si no se proporciona un ID
        return redirect('app:clientcard_list')

    try:
        # Obtener los datos de la entidad desde el servicio
        clientCard = ClientCardService().retrieve(entity_id=id)

    except ClientCardNotFoundError as e:
        messages.error(request,  "Not Found Error: " + str(e))
        return redirect('app:clientcard_list')
    except ClientCardValueError as e:
        messages.error(request,  "Value Error: " + str(e))
        return redirect('app:clientcard_list')
    except (ConnectionDataBaseError, RepositoryError) as e:
        messages.error(request, "There was an error accessing the database or repository: " + str(e))
        return redirect('app:clientcard_list')
    except Exception as e:
        messages.error(request, "An unexpected error occurred: " + str(e))
        return redirect('app:clientcard_list')

    if request.method == "POST":

        # Validar los datos del formulario
        form = ClientCardEditPostForm(request.POST, request.FILES)

        if form.is_valid():
            try:
                form_data = form.cleaned_data            
                
                # obtenemos del request los campos especiales del formulario
                # ejemplo: password = request.POST.get('password', None)
                # ejemplo: photo = request.FILES.get('photo', None)
                # y los enviamos como parametros al servicio de actualizacion

                # Obtener el ID de la entidad relacionada si existe
                external_id = request.POST.get('external_id', None)

                # Obtener la lista de ids de externals seleccionadas
                externals_ids = form_data.get('externals', [])         
                
                # Limpiar los campos no actualizables del diccionario de datos
                form_data = clean_dict_of_keys(form_data, keys=ClientCardEditPostForm.ENTITY_NOT_UPDATABLE_FIELDS)

                # LLamar al servicio de actualización
                ClientCardService().update(entity_id=id, data=form_data, external_id=external_id, externals=externals_ids)

                # Mostrar mensaje de éxito
                messages.success(request, f"Successfully updated clientCard")

                # Redireccionar a la lista de clientCards
                return redirect('app:clientcard_list')

            except ClientCardNotFoundError as e:
                messages.error(request,  "Not Found Error: " + str(e))                
            except (ClientCardValueError, ClientCardValidationError) as e:
                form.add_error(None, "Validation Error: " + str(e))
            except (ConnectionDataBaseError, RepositoryError) as e:
                messages.error(request, "There was an error accessing the database or repository: " + str(e))
            except Exception as e:
                messages.error(request, "An unexpected error occurred: " + str(e))

        else:
            messages.error(request, "There were errors in the form. Please correct them")

    # request.method == "GET":
    else:  
        # Initialize the form with existing data
        form = ClientCardEditGetForm(initial={
            'id': clientCard.get('id'),
            'attributeName': clientCard.get('attributeName'),
            'attributeEmail': clientCard.get('attributeEmail')
        })

    # Renderizar la plantilla con el formulario
    return render(request, 'app/clientcard_web_edit.html', {'form': form})


def clientcard_detail(request, id=None):
    """
    Vista genérica para mostrar los detalles de una instancia específica de clientCard.
    """
    if id is None:
        return redirect('app:clientcard_list')

    try:
        # Obtener los datos de la entidad desde el servicio
        clientCard = ClientCardService().retrieve(entity_id=id)

    except ClientCardNotFoundError as e:
        messages.error(request,  "Not Found Error: " + str(e))        
        return redirect('app:clientcard_list')
    except ClientCardValueError as e:
        messages.error(request,  str(e))
        return redirect('app:clientcard_list')
    except (ConnectionDataBaseError, RepositoryError) as e:
        messages.error(request, "There was an error accessing the database or repository: " + str(e))
        return redirect('app:clientcard_list')
    except Exception as e:
        messages.error(request, "An unexpected error occurred: " + str(e))
        return redirect('app:clientcard_list')

    # Renderizar la plantilla con el formulario de vista
    form = ClientCardViewForm(initial={
        'attributeName': clientCard.get('attributeName'),
        'attributeEmail': clientCard.get('attributeEmail')
    })

    return render(request, 'app/clientcard_web_detail.html', {'form': form})


def clientcard_delete(request, id=None):
    """
    Vista genérica para eliminar una instancia existente de clientCard utilizando un servicio.
    """
    if id is None:
        messages.error(request, "Non Valid id to delete")
        return redirect('app:clientcard_list')

    try:
        # LLamar al servicio de eliminación
        ClientCardService().delete(entity_id=id)
        messages.success(request, f"Successfully deleted clientCard")

    except ClientCardNotFoundError as e:
        messages.error(request,  "Not Found Error: " + str(e))             
    except (ClientCardValueError, ClientCardValidationError) as e:
        messages.error(request,  "Validation Error: " + str(e))
    except (ConnectionDataBaseError, RepositoryError) as e:
        messages.error(request, "There was an error accessing the database or repository: " + str(e))
    except Exception as e:
        messages.error(request, "An unexpected error occurred: " + str(e))

    return redirect('app:clientcard_list')

