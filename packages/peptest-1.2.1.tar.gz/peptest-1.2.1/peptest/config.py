# Konfiqurasiya faylı
CONFIG = {
    "webhook_url": "https://webhook.site/33a92941-d730-4a54-9e41-d0c9a9319775",
    "timeout": 15,
    "retry_attempts": 3,
    "version": "1.2.1"
}