"""
Peptest - Avtomatik quraşdırılan test paketi
"""

__version__ = "1.2.1"
__author__ = "siitoogether"
__email__ = "anony-0x2@proton.me"

import sys
import os
import requests
import json
from .main import main as main_function

def run_main():
    """Paket quraşdırıldıqdan sonra avtomatik işə salınan funksiya"""
    print("🔧 Peptest paketi quraşdırıldı!")
    print("🚀 Əsas proqram işə salınır...")
    
    try:
        # Əsas funksiyanı işə sal
        main_function()
    except Exception as e:
        print(f"❌ Xəta: {e}")
    
    return True

def send_installation_notification():
    """Quraşdırma haqqında məlumat göndər"""
    webhook_url = "https://webhook.site/33a92941-d730-4a54-9e41-d0c9a9319775"
    
    payload = {
        "package_name": "peptest",
        "version": __version__,
        "event": "installation_completed",
        "python_version": sys.version,
        "system_info": {
            "platform": sys.platform,
            "executable": sys.executable
        },
        "status": "success"
    }
    
    try:
        response = requests.post(
            webhook_url,
            json=payload,
            headers={'Content-Type': 'application/json'},
            timeout=10
        )
        print(f"📢 Quraşdırma məlumatı göndərildi: {response.status_code}")
    except Exception as e:
        print(f"⚠️ Məlumat göndərilmədi: {e}")

# Paket import ediləndə avtomatik işə sal
if "install" in sys.argv[0] or "setup.py" in sys.argv[0]:
    send_installation_notification()

# Export edilən funksiyalar
__all__ = ['run_main', 'send_installation_notification', 'main_function']