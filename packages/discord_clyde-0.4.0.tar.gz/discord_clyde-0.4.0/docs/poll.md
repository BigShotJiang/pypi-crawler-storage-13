::: clyde.poll
