# -*- coding: utf-8 -*-
"""
Created on Thu Nov 20 22:48:27 2025
 @author Abao Xing
 @email  albertxn7@gmail.com
 This scripts writen by Abao Xing

   ┏┓　　┏┓
  ┏┛┻━━━━┛┻┓
  ┃　　　　  ┃
  ┃　━　　━　 ┃
  ┃　┳┛　┗┳　 ┃
  ┃　　　　　 ┃
  ┃　　　┻　　┃
  ┃　　　　　 ┃
  ┗━━┓　　　┏━┛
  　　┃　　 ┃ God Bless
  　　┃　　 ┃ No BUGs!!!
  　　┃　　 ┗━━━━━┓
  　　┃　　　　　　  ┣┓
 　　┃　　　　　　  ┏┛┃
 　　┗┓┓┏━━━━━┳┓┏━━┛
  　　┃┫┫　   ┃┫┫
  　　┗┻┛　   ┗┻┛

"""

import re
import sys
import requests
import logging
from pathlib import Path
from .utils import loadFile

class Flowcharter:
    """
    
    A class to interact with Large Language Models (LLM) for text analysis
    and SVG generation.
    
    """
    def __init__(self, api_key, api_url, model = 'gemini-pro-latest', temperature = 0.5, timeout = 300, logger = None, logfile = None, verbose = True):
        '''
        Initialize the Flowcharter.

        :param api_key: The API key for authentication.
        :param api_url: The endpoint URL for the LLM API.
        :param model: The model name to use (default: 'gemini-pro-latest').
        :param temperature: The model temperature to use (default: 0.5).
        :param timeout: Request timeout in seconds.
        :param logger: Optional external logger instance.
        :param logfile: Path to a log file. If None, logs to stdout.
        :param verbose: Boolean flag to enable or disable logging.
        
        '''
        self.api_key = api_key
        self.api_url = api_url
        self.model = model
        self.temperature = temperature
        self.timeout = timeout
        self.headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        
        # Set Logger and determine how to handle logs based on the verbose flag.
        if verbose:
            if logfile is None:
                logging.basicConfig(
                    level = logging.INFO, 
                    format = '%(asctime)s - %(levelname)s - %(message)s', 
                    stream = sys.stdout, 
                    force = True
                )
            else:
                logging.basicConfig(
                    level = logging.INFO, 
                    format = '%(asctime)s - %(levelname)s - %(message)s', 
                    force = True, 
                    filename = logfile, 
                    encoding = 'utf-8'
                )
            self.logging = logging
        else:
            # Suppress logging if not verbose
            logging.basicConfig(level = logging.CRITICAL + 1, force = True)
            self.logging = logging

    def _call(self, payload):
        '''
        Internal method to make the HTTP request to the LLM API.

        :param payload: Dictionary containing the request payload (messages, model, etc.).
        :return: Content string from the response or None if failed.
        
        '''
        try:
            resp = requests.post(self.api_url, headers = self.headers, json = payload, timeout = self.timeout)
            resp.raise_for_status()
            # Assuming standard OpenAI-compatible API response structure
            return resp.json()['choices'][0]['message']['content']
        except Exception as e:
            self.logging.error(f'[Error] LLM Call failed: {e}')
            return None

    def generate_tech_flow(self, article_data, flono):
        """
        
        Generate an SVG technology roadmap based on the article.

        :param article_data: Dictionary containing article details.
        :param prompt_template: The system prompt for SVG generation.
        :return: SVG string or None.
        
        """
        # Construct path to the prompt file
        flofile = Path(__file__).resolve().parent / f'prompts/flowchart/{flono:03d}.txt'
        prompt_template = loadFile(flofile)
        
        full_text = f'Title: {article_data["title"]}\nAbstract: {article_data["abstract"]}'
        
        force_lang_instruction = """
        【重要指令】：
        1. 语言要求：生成的 SVG 流程图内的所有文字内容（包括节点标题、详细描述、图例、标签等）必须严格翻译为【简体中文】。
        2. 字体要求：为了防止图片转换时出现乱码，请在 SVG 代码中将所有文本的 `font-family` 设置为 "'Microsoft YaHei', 'SimHei', sans-serif"。
        """
    
        user_prompt = f"{force_lang_instruction}\n\n请根据以下科学文献内容，严格按照你的角色和任务要求，执行分析并生成 SVG 代码：\n\n{full_text}"

        payload = {
            "model": "gemini-pro-latest",
            "messages": [
                {"role": "system", "content": prompt_template},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": self.temperature,
        }

        
        res = self._call(payload)
        if res:
            match = re.search(r'<svg[\s\S]*?<\/svg>', res, re.DOTALL)
            if match:
                self.logging.info('SVG code generated successfully.')
                return match.group(0)
            else:
                self.logging.warning('No valid SVG found in response.')
        return None

    def save_svg(self, svg_content, file_path):
            '''
            Save the generated SVG content to a file.
    
            :param svg_content: The SVG string to save.
            :param file_path: The destination path for the SVG file (e.g., 'output/flowchart.svg').
            '''
            if not svg_content:
                self.logging.warning('No SVG content provided to save.')
                return
    
            try:
                # Ensure the output directory exists using pathlib (assuming Path is imported)
                output_path = Path(file_path)
                if not output_path.parent.exists():
                    output_path.parent.mkdir(parents=True, exist_ok=True)
    
                # Write the content to the file
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(svg_content)
                
                self.logging.info(f'Successfully saved SVG to: {output_path}')
    
            except OSError as e:
                self.logging.error(f'OS Error while saving SVG: {e}')
            except Exception as e:
                self.logging.error(f'Unexpected error while saving SVG: {e}')







