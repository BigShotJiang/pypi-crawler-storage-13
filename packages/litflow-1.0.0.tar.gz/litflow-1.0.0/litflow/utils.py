# -*- coding: utf-8 -*-
"""
Created on Thu Nov 20 22:47:42 2025
 @author Abao Xing
 @email  albertxn7@gmail.com
 This scripts writen by Abao Xing

   ┏┓　　┏┓
  ┏┛┻━━━━┛┻┓
  ┃　　　　  ┃
  ┃　━　　━　 ┃
  ┃　┳┛　┗┳　 ┃
  ┃　　　　　 ┃
  ┃　　　┻　　┃
  ┃　　　　　 ┃
  ┗━━┓　　　┏━┛
  　　┃　　 ┃ God Bless
  　　┃　　 ┃ No BUGs!!!
  　　┃　　 ┗━━━━━┓
  　　┃　　　　　　  ┣┓
 　　┃　　　　　　  ┏┛┃
 　　┗┓┓┏━━━━━┳┓┏━━┛
  　　┃┫┫　   ┃┫┫
  　　┗┻┛　   ┗┻┛

"""

import os
import time
import io
import sys
import logging
from selenium import webdriver
from selenium.webdriver.edge.service import Service
from selenium.webdriver.edge.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

try:
    import cairosvg
    CAIROSVG_AVAILABLE = True
except ImportError:
    CAIROSVG_AVAILABLE = False

class BrowserHelper:
    
    """
    Helper class for browser automation using Selenium.
    Primarily used for capturing screenshots of specific web elements.
    
    """
    def __init__(self, driver_path, logger = None, logfile = None, verbose = True):
        
        """
        Initialize the BrowserHelper with driver path and logging configuration.

        :param driver_path: Path to the Edge WebDriver executable.
        :param logger: External logger instance (optional).
        :param logfile: Path to a log file (optional).
        :param verbose: Boolean to enable/disable console output.
        
        """
        self.driver_path = driver_path
        # Set Logger and determine how to handle logs based on the verbose flag.
        if verbose:
            if logfile is None:
                logging.basicConfig(
                    level = logging.INFO, 
                    format = '%(asctime)s - %(levelname)s - %(message)s', 
                    stream = sys.stdout, 
                    force = True
                )
            else:
                logging.basicConfig(
                    level = logging.INFO, 
                    format = '%(asctime)s - %(levelname)s - %(message)s', 
                    force = True, 
                    filename = logfile, 
                    encoding = 'utf-8'
                )
            self.logging = logging
        else:
            # Suppress logging if not verbose
            logging.basicConfig(level = logging.CRITICAL + 1, force = True)
            self.logging = logging

    def capture_header(self, url, output_path):
        
        """
        Capture the article header using Selenium and save it as an image.

        :param url: The URL of the article.
        :param output_path: The file path to save the screenshot.
        :return: True if successful, False otherwise.
        
        """
        if not os.path.exists(self.driver_path):
            self.logging.error(f'Driver not found: {self.driver_path}')
            return False

        service = Service(self.driver_path)
        options = Options()
        options.add_argument('--headless')
        options.add_argument('--window-size=1920,1080')
        options.add_argument('--log-level=3')
        options.add_argument('--ignore-certificate-errors')
        options.add_argument('--allow-insecure-localhost')
        options.add_argument('--disable-dev-shm-usage')
        
        driver = None
        try:
            driver = webdriver.Edge(service = service, options = options)
            driver.get(url)
            
            # Simple Cookie handling logic
            try:
                cookie_btn = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[@data-cc-action='accept']"))
                )
                cookie_btn.click()
                time.sleep(1)
            except Exception:
                pass

            # Wait for the header element and take a screenshot
            header = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, 'c-article-header'))
            )
            
            # Add 10px padding to the element via JavaScript before screenshot
            # This ensures the screenshot includes a margin around the content
            driver.execute_script('arguments[0].style.padding = "10px";', header)
            
            header.screenshot(output_path)
            self.logging.info(f'Header screenshot saved to {output_path}')
            return True
        except Exception as e:
            self.logging.error(f'Screenshot failed: {e}')
            return False
        finally:
            if driver:
                driver.quit()
                
def svg_to_png_stream(svg_string):
    
    """
    Convert SVG string to PNG byte stream using cairosvg.

    :param svg_string: The SVG content as a string.
    :return: BytesIO object containing PNG data, or None if failed.
    
    """
    if not CAIROSVG_AVAILABLE or not svg_string:
        if not CAIROSVG_AVAILABLE:
            logging.warning('CairoSVG is not available.')
        return None
    try:
        png_data = cairosvg.svg2png(bytestring = svg_string.encode('utf-8'))
        return io.BytesIO(png_data)
    except Exception as e:
        logging.error(f'[Error] SVG conversion failed: {e}')
        return None
    
def loadFile(filepath):
    """ 
    
    Read the prompt file
    """
    with open(filepath, 'r', encoding = 'utf-8') as f:
        return f.read()