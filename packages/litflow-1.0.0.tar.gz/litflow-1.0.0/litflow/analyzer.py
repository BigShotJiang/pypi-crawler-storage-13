# -*- coding: utf-8 -*-
"""
Created on Thu Nov 20 22:48:27 2025
 @author Abao Xing
 @email  albertxn7@gmail.com
 This scripts writen by Abao Xing

   ┏┓　　┏┓
  ┏┛┻━━━━┛┻┓
  ┃　　　　  ┃
  ┃　━　　━　 ┃
  ┃　┳┛　┗┳　 ┃
  ┃　　　　　 ┃
  ┃　　　┻　　┃
  ┃　　　　　 ┃
  ┗━━┓　　　┏━┛
  　　┃　　 ┃ God Bless
  　　┃　　 ┃ No BUGs!!!
  　　┃　　 ┗━━━━━┓
  　　┃　　　　　　  ┣┓
 　　┃　　　　　　  ┏┛┃
 　　┗┓┓┏━━━━━┳┓┏━━┛
  　　┃┫┫　   ┃┫┫
  　　┗┻┛　   ┗┻┛

"""

import sys
import json
import time
import logging
import requests
from pathlib import Path
from .utils import loadFile

class LLMAnalyzer:
    '''
    A class to interact with Large Language Models (LLM) for text analysis
    and structured data generation.
    
    '''
    def __init__(self, api_key, api_url, model = 'gemini-pro-latest', temperature = 0.5, timeout = 300, logger = None, logfile = None, verbose = True):
        '''
        Initialize the LLMAnalyzer.

        :param api_key: The API key for authentication.
        :param api_url: The endpoint URL for the LLM API.
        :param model: The model name to use (default: 'gemini-pro-latest').
        :param temperature: The model temperature to use (default: 0.5).
        :param timeout: Request timeout in seconds.
        :param logger: Optional external logger instance.
        :param logfile: Path to a log file. If None, logs to stdout.
        :param verbose: Boolean flag to enable or disable logging.
        
        '''
        self.api_key = api_key
        self.api_url = api_url
        self.model = model
        self.temperature = temperature
        self.timeout = timeout
        self.headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }

        # Set Logger and determine how to handle logs based on the verbose flag.
        if verbose:
            if logfile is None:
                logging.basicConfig(
                    level = logging.INFO,
                    format = '%(asctime)s - %(levelname)s - %(message)s',
                    stream = sys.stdout,
                    force = True
                )
            else:
                logging.basicConfig(
                    level = logging.INFO,
                    format = '%(asctime)s - %(levelname)s - %(message)s',
                    force = True,
                    filename = logfile,
                    encoding = 'utf-8'
                )
            self.logging = logging
        else:
            # Suppress logging if not verbose (set level higher than CRITICAL)
            logging.basicConfig(level=logging.CRITICAL + 1, force=True)
            self.logging = logging

    def _call(self, payload):
        '''
        Internal method to make the HTTP request to the LLM API.

        :param payload: Dictionary containing the request payload (messages, model, etc.).
        :return: Content string from the response or None if failed.
        
        '''
        try:
            resp = requests.post(self.api_url, headers = self.headers, json = payload, timeout = self.timeout)
            resp.raise_for_status()
            # Assuming standard OpenAI-compatible API response structure
            return resp.json()['choices'][0]['message']['content']
        except Exception as e:
            self.logging.error(f'[Error] LLM Call failed: {e}')
            return None

    def find_section_text(self, sections_list, title_keyword):
        '''
        Helper function: Find section content based on a keyword in the title.

        :param sections_list: List of section dictionaries.
        :param title_keyword: Keyword to search for (e.g., 'Results').
        :return: The content of the section or an empty string if not found.
        
        '''
        keyword = title_keyword.lower()
        for section in sections_list:
            if keyword in section.get('title', '').lower():
                return section.get('content', '')
        
        # Log a warning if the section is missing
        if hasattr(self, 'logging'):
            self.logging.warning(f'Section "{title_keyword}" not found in JSON data.')
        
        return ''

    def alchemy(self, article_data, alcno):
        '''
        Generate article analysis in JSON format using the LLM.

        :param article_data: Dictionary containing article details (title, abstract, sections, etc.).
        :param alcno: The alchemy prompt number/ID to load the specific system prompt.
        :return: Parsed JSON dictionary or None.
        
        '''
        # Construct path to the prompt file
        alcfile = Path(__file__).resolve().parent / f'prompts/alchemy/{alcno:03d}.txt'
        alchemy_prompt = loadFile(alcfile)
        
        try:
            # Extract data from the dictionary for LLM input
            article_title = article_data.get('title', '[No Title]')
            # Check for nested abstract structure
            article_abstract = article_data['abstract'].get('content', '[No Abstract]')
            sections_list = article_data.get('sections', [])

            # Extract specific sections
            results_text = self.find_section_text(sections_list, 'Results')
            methods_text = self.find_section_text(sections_list, 'Methods')
            introduction_text = self.find_section_text(sections_list, 'Introduction')
            discussion_text = self.find_section_text(sections_list, 'Discussion')
            all_figures_list = article_data.get('figures', [])

            # Validate essential data
            if article_abstract == '[No Abstract]':
                self.logging.critical('Error: The retrieved abstract is empty. Cannot proceed with LLM analysis.')
                time.sleep(5)
                sys.exit(1)

        except Exception as e:
            self.logging.critical(f'Error: Failed to prepare LLM input data: {e}')
            time.sleep(5)
            sys.exit(1)
        
        # Format figure captions for the prompt
        figures_prompt_text = '\n\n--- Available Figures (ID and Caption) ---\n'
        if not all_figures_list:
            figures_prompt_text += 'None.\n'
        else:
            for fig in all_figures_list:
                figures_prompt_text += f"ID: {fig.get('id', 'N/A')}\nCaption: {fig.get('caption', 'No caption')}\n\n"
    
        # Construct the user prompt
        user_prompt = f'''
        文章标题: {article_title}
        文章摘要 (Abstract): {article_abstract}
        文章引言 (Introduction): {introduction_text}
        文章 "Results" 章节内容: {results_text}
        文章讨论 (Discussion): {discussion_text}
        文章 "Methods" 章节内容: {methods_text}
        图注内容：{figures_prompt_text}
        '''

        payload = {
            'model': self.model,
            'messages': [
                {'role': 'system', 'content': alchemy_prompt},
                {'role': 'user', 'content': user_prompt}
            ],
            'temperature': self.temperature,
        }
    
        self.logging.info(f'Sending request to LLM (Model: {self.model})...')
        res = self._call(payload)
        
        if res:
            # Clean markdown code blocks if present in the response
            if '```json' in res:
                res = res.split('```json')[1].split('```')[0]
            elif '```' in res:
                res = res.split('```')[1].split('```')[0]
            
            try:
                self.logging.info('Successfully received and parsed JSON response.')
                return json.loads(res.strip())
            except json.JSONDecodeError as e:
                self.logging.error(f'Failed to parse JSON response: {e}')
                self.logging.debug(f'Raw response content: {res}')
                return None
        
        self.logging.error('LLM returned no response.')
        return None