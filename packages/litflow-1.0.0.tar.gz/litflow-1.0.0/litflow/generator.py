# -*- coding: utf-8 -*-
"""
Created on Thu Nov 20 22:48:43 2025
@author: Abao Xing
@email: albertxn7@gmail.com
@description: This script defines the DocxReportGenerator class for generating
              structured Word documents from article data and analysis.
"""

import io
import os
import sys
import requests
import logging
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH

# Attempt to import cairosvg; mark as unavailable if import fails
try:
    import cairosvg
    CAIROSVG_AVAILABLE = True
except ImportError:
    CAIROSVG_AVAILABLE = False

class DocxReportGenerator:
    """
    A class to generate Microsoft Word reports (.docx) based on structured
    article data and LLM analysis results.
    """

    def __init__(self, output_path, logger = None, logfile = None, verbose = True):
        """
        Initialize the report generator.

        :param output_path: Full path where the document will be saved (e.g., 'report.docx').
        :param logger: External logger instance (optional).
        :param logfile: Path to a log file (optional).
        :param verbose: If True, logs to stdout; otherwise, suppresses logs.
        """
        self.output_path = output_path
        self.doc = Document()
        self._init_styles()
        
        # Configure logging based on verbose flag and logfile path
        if verbose:
            if logfile is None:
                logging.basicConfig(
                    level = logging.INFO,
                    format = '%(asctime)s - %(levelname)s - %(message)s',
                    stream = sys.stdout,
                    force = True
                )
            else:
                logging.basicConfig(
                    level = logging.INFO,
                    format = '%(asctime)s - %(levelname)s - %(message)s',
                    force = True,
                    filename = logfile,
                    encoding = 'utf-8'
                )
            self.logging = logging
        else:
            # Suppress logging if not verbose (set level higher than CRITICAL)
            logging.basicConfig(level = logging.CRITICAL + 1, force = True)
            self.logging = logging

    def _init_styles(self):
        """
        Initialize base document styles.
        Sets the default font to 'SimSun' (宋体) to support East Asian characters.
        """
        style = self.doc.styles['Normal']
        style.font.name = '宋体'
        # Configure East Asian font settings
        rpr = style.element.get_or_add_rPr()
        rFonts = rpr.get_or_add_rFonts()
        rFonts.set(qn('w:eastAsia'), '宋体')

    def _set_font_style(self, run, font_name = '宋体', size_pt = 10.5, bold = False, italic = False, color_rgb = None):
        """
        Helper function: Apply font styles to a specific Run object.
        """
        run.font.size = Pt(size_pt)
        run.font.bold = bold
        run.font.italic = italic
        if color_rgb:
            run.font.color.rgb = RGBColor(*color_rgb)
        
        # Set East Asian font explicitly
        r = run._r
        rpr = r.get_or_add_rPr()
        rFonts = rpr.get_or_add_rFonts()
        rFonts.set(qn('w:eastAsia'), font_name)

    def add_styled_paragraph(self, text, style_name = None, size_pt = 10.5, font_name = '宋体', 
                             bold = False, italic = False, alignment = None, color_rgb = None):
        """
        Add a paragraph with specific styling to the document.
        """
        if style_name:
            para = self.doc.add_paragraph(style = style_name)
        else:
            para = self.doc.add_paragraph()
        
        run = para.add_run(text)
        self._set_font_style(run, font_name = font_name, size_pt = size_pt, 
                             bold = bold, italic = italic, color_rgb = color_rgb)
        
        if alignment is not None:
            para.alignment = alignment
        return para

    def add_image_from_url(self, image_url, width_inches = 6.0):
        """
        Download an image from a URL and add it to the document.
        """
        try:
            self.logging.info(f'Downloading image: {image_url[:50]}...')
            response = requests.get(image_url, timeout = 10)
            response.raise_for_status()
            image_stream = io.BytesIO(response.content)
            
            para = self.doc.add_paragraph()
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = para.add_run()
            run.add_picture(image_stream, width = Inches(width_inches))
        except requests.exceptions.RequestException as e:
            self.logging.warning(f'Failed to download image {image_url}: {e}')
            self.add_styled_paragraph(f'[Image download failed: {image_url}]', size_pt = 9, italic = True)
        except Exception as e:
            self.logging.warning(f'Error inserting image: {e}')
            self.add_styled_paragraph('[Image insertion error]', size_pt = 9, italic = True)

    def add_svg_as_png(self, svg_string, width_inches = 6.0):
        """
        Convert an SVG string to PNG using CairoSVG and add it to the document.
        """
        if not CAIROSVG_AVAILABLE:
            self.logging.warning('CairoSVG library missing, skipping SVG insertion.')
            self.add_styled_paragraph('[SVG Roadmap generation failed - CairoSVG missing]', size_pt = 9, italic = True)
            return

        if not svg_string or '<svg' not in svg_string:
            self.logging.warning('SVG string is empty or invalid, skipping SVG insertion.')
            self.add_styled_paragraph('[SVG Roadmap not generated or invalid]', size_pt = 9, italic = True)
            return

        try:
            self.logging.info('Converting SVG to PNG...')
            png_data = cairosvg.svg2png(bytestring = svg_string.encode('utf-8'))
            image_stream = io.BytesIO(png_data)

            para = self.doc.add_paragraph()
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = para.add_run()
            run.add_picture(image_stream, width = Inches(width_inches))
            self.logging.info('SVG Roadmap successfully inserted.')

        except Exception as e:
            self.logging.warning(f'SVG conversion or insertion failed: {e}')
            self.add_styled_paragraph(f'[SVG Roadmap conversion failed: {e}]', size_pt = 9, italic = True)

    def build(self, article_data, llm_analysis, header_screenshot_path = None, svg_flowchart_string = None):
        """
        Core logic to assemble the document structure.

        :param article_data: Dictionary containing raw article data (title, figures, references, url).
        :param llm_analysis: Dictionary containing analysis results from the LLM.
        :param header_screenshot_path: Local file path to the article header screenshot.
        :param svg_flowchart_string: SVG string for the technical roadmap/flowchart.
        """
        
        # --- 1. Data Extraction ---
        chinese_title = llm_analysis.get('title', '[Title generation failed]')
        intro = llm_analysis.get('intro', '[Editor review generation failed]')
        highlights = llm_analysis.get('highlights', '[Highlights generation failed]')
        background = llm_analysis.get('background', '[Background generation failed]')
        conclusion = llm_analysis.get('conclusion', '[Conclusion generation failed]')
        methods_summary = llm_analysis.get('methods_summary', '[Methods summary generation failed]')
        
        # References and Figures
        references = article_data.get('references', [])
        all_figures_list = article_data.get('figures', [])
        figure_lookup = {fig.get('id'): fig for fig in all_figures_list}
        translated_captions = llm_analysis.get('translated_captions', {})

        self.logging.info(f'Creating document: {self.output_path}...')

        # --- 2. Title ---
        self.logging.info('Adding: Title')
        self.add_styled_paragraph(chinese_title, size_pt = 22, bold = True, font_name = '黑体', 
                                  alignment = WD_ALIGN_PARAGRAPH.CENTER)
        self.add_styled_paragraph('This article is for academic exchange purposes; citations are noted.', 
                                  size_pt = 10.5, font_name = '宋体')
        self.doc.add_paragraph()

        # --- 3. Cover Image ---
        self.logging.info('Adding: Cover Image')
        if header_screenshot_path and os.path.exists(header_screenshot_path):
            try:
                para = self.doc.add_paragraph()
                para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                run = para.add_run()
                run.add_picture(header_screenshot_path, width = Inches(6.0))
            except Exception as e:
                self.add_styled_paragraph(f'[Failed to insert screenshot: {e}]', size_pt = 9, italic = True)
        else:
            self.add_styled_paragraph('[Cover screenshot not found]', size_pt = 9, italic = True, 
                                      alignment = WD_ALIGN_PARAGRAPH.CENTER)
        self.doc.add_paragraph()

        # --- 4. Editor's Review ---
        self.logging.info('Adding: Editor\'s Review')
        self.add_styled_paragraph('Editor\'s Review', size_pt = 14, bold = True, font_name = '黑体')
        self.add_styled_paragraph(intro, size_pt = 10.5, font_name = '宋体')
        self.doc.add_paragraph()

        # --- 5. Research Highlights ---
        self.logging.info('Adding: Research Highlights')
        self.add_styled_paragraph('Research Highlights', size_pt = 14, bold = True, font_name = '黑体')
        self.add_styled_paragraph(highlights, size_pt = 10.5, font_name = '宋体')
        self.doc.add_paragraph()

        # --- 6. Background ---
        self.logging.info('Adding: Background')
        self.add_styled_paragraph('Background', size_pt = 14, bold = True, font_name = '黑体')
        self.add_styled_paragraph(background, size_pt = 10.5, font_name = '宋体')
        self.doc.add_paragraph()

        # --- 7. Methods and Design (including SVG) ---
        self.logging.info('Adding: Methods and Experimental Design')
        self.add_styled_paragraph('Methods and Experimental Design', size_pt = 14, bold = True, font_name = '黑体')
        self.add_styled_paragraph('We focus on introducing research ideas and methods. The following flowchart is for reference.', 
                                  size_pt = 10.5, font_name = '宋体')
        
        if svg_flowchart_string:
            self.add_svg_as_png(svg_flowchart_string, width_inches = 6.0)
            
        self.add_styled_paragraph(methods_summary, size_pt = 10.5, font_name = '宋体')
        self.doc.add_paragraph()

        # --- 8. Main Results (Mixed Text & Images) ---
        self.logging.info('Adding: Main Results')
        self.add_styled_paragraph('Main Results', size_pt = 14, bold = True, font_name = '黑体')

        structured_results = llm_analysis.get('structured_results', [])
        
        if not structured_results:
            # --- Fallback Scheme ---
            self.logging.warning('Failed to retrieve "structured_results". Using simple summary mode.')
            old_summary = llm_analysis.get('main_results_summary', '[Main results summary generation failed]')
            self.add_styled_paragraph(old_summary, size_pt = 10.5, font_name = '宋体')
            self.doc.add_paragraph()

            self.logging.warning('Adding all scraped Figures...')
            if all_figures_list:
                for fig in all_figures_list:
                    fig_id = fig.get('id', 'N/A')
                    caption_to_use = translated_captions.get(fig_id, fig.get('caption', f'[{fig_id} Caption missing]'))

                    self.logging.info(f'Adding: {fig_id}')
                    self.add_image_from_url(fig['url'], width_inches = 6.0)
                    self.add_styled_paragraph(caption_to_use, size_pt = 9, font_name = '宋体', italic = True, 
                                              alignment = WD_ALIGN_PARAGRAPH.CENTER)
                    self.doc.add_paragraph()
            else:
                self.add_styled_paragraph('[No Figures found]', size_pt = 9, italic = True)
        else:
            # --- Structured Mixed Content ---
            self.logging.info(f'Successfully retrieved {len(structured_results)} structured results.')
            
            for i, result_item in enumerate(structured_results):
                sub_title = result_item.get('title', f'[Result {i + 1}]')
                text_summary = result_item.get('text_summary', '[Text summary for this result missing]')
                figure_ids_to_add = result_item.get('corresponding_figures', [])

                # Add Subtitle
                self.logging.info(f'Adding: {sub_title}')
                self.add_styled_paragraph(sub_title, size_pt = 12, bold = True, font_name = '黑体')

                # Add Images
                valid_figures_inserted = 0
                for fig_id in figure_ids_to_add:
                    if fig_id in figure_lookup:
                        fig_data = figure_lookup[fig_id]
                        caption_to_use = translated_captions.get(fig_id, fig_data.get('caption', f'[{fig_id} Caption missing]'))

                        self.logging.info(f'-> Inserting image: {fig_id}')
                        self.add_image_from_url(fig_data['url'], width_inches = 6.0)
                        self.add_styled_paragraph(caption_to_use, size_pt = 9, font_name = '宋体', italic = True, 
                                                  alignment = WD_ALIGN_PARAGRAPH.CENTER)
                        valid_figures_inserted += 1
                    else:
                        self.logging.info(f'-> [Skipped] Resource \'{fig_id}\' is not a scrapable figure.')

                # Add Text Summary
                self.add_styled_paragraph(text_summary, size_pt = 10.5, font_name = '宋体')
                self.doc.add_paragraph() # Paragraph separator

        # --- 9. Conclusion ---
        self.logging.info('Adding: Conclusion')
        self.add_styled_paragraph('Conclusion', size_pt = 14, bold = True, font_name = '黑体')
        self.add_styled_paragraph(conclusion, size_pt = 10.5, font_name = '宋体')
        self.doc.add_paragraph()

        # --- 10. References ---
        self.logging.info('Adding: References')
        self.add_styled_paragraph('References', size_pt = 14, bold = True, font_name = '黑体')
        if references:
            for ref in references:
                self.add_styled_paragraph(ref, size_pt = 9, font_name = 'Times New Roman', italic = True)
        else:
            self.add_styled_paragraph('[No references scraped]', size_pt = 9, italic = True)
        self.doc.add_paragraph()

        # --- 11. Footer Disclaimer ---
        self.add_styled_paragraph('The content is for personal learning purposes. Please contact for deletion if there is any infringement or objection.', 
                                  size_pt = 10.5, font_name = '宋体')

        # --- 12. Save ---
        try:
            self.doc.save(self.output_path)
            self.logging.info('--- Document generation completed ---')
            self.logging.info(f'File saved to: {self.output_path}')
            return True
        except Exception as e:
            self.logging.error(f'Error: Failed to save .docx file: {e}')
            return False