# -*- coding: utf-8 -*-
"""
Created on Thu Nov 20 22:48:18 2025
 @author Abao Xing
 @email  albertxn7@gmail.com
 This scripts writen by Abao Xing

   ┏┓　　┏┓
  ┏┛┻━━━━┛┻┓
  ┃　　　　  ┃
  ┃　━　　━　 ┃
  ┃　┳┛　┗┳　 ┃
  ┃　　　　　 ┃
  ┃　　　┻　　┃
  ┃　　　　　 ┃
  ┗━━┓　　　┏━┛
  　　┃　　 ┃ God Bless
  　　┃　　 ┃ No BUGs!!!
  　　┃　　 ┗━━━━━┓
  　　┃　　　　　　  ┣┓
 　　┃　　　　　　  ┏┛┃
 　　┗┓┓┏━━━━━┳┓┏━━┛
  　　┃┫┫　   ┃┫┫
  　　┗┻┛　   ┗┻┛

"""

import re
import sys
import logging
import requests
from lxml import html
from urllib.parse import urljoin

class NatureScraper:
    
    """
    A scraper class designed to extract content from Nature.com articles.
    It captures titles, abstracts, sections, references, and figures.
    
    """
    def __init__(self, url, user_agent, logger = None, logfile = None, verbose = True):
        
        """
        Initialize the scraper with URL and configuration.

        :param url: Target article URL.
        :param user_agent: User-Agent string for headers.
        :param logger: External logger instance (optional).
        :param logfile: Path to a log file (optional).
        :param verbose: Boolean to enable/disable console output.
        
        """
        self.url = url
        self.headers = {
            'User-Agent': user_agent
        }
        
        # Set Logger and determine how to handle logs based on the verbose flag.
        if verbose:
            if logfile is None:
                logging.basicConfig(
                    level = logging.INFO, 
                    format = '%(asctime)s - %(levelname)s - %(message)s', 
                    stream = sys.stdout, 
                    force = True
                )
            else:
                logging.basicConfig(
                    level = logging.INFO, 
                    format = '%(asctime)s - %(levelname)s - %(message)s', 
                    force = True, 
                    filename = logfile, 
                    encoding = 'utf-8'
                )
            self.logging = logging
        else:
            # Suppress logging if not verbose
            logging.basicConfig(level = logging.CRITICAL + 1, force = True)
            self.logging = logging

    def run(self):
        
        """
        Execute scraping and return a standardized dictionary containing article data.
        
        :return: Dictionary with keys: url, title, abstract, sections, figures, references.
        :rtype: dict or None
        
        """
        self.logging.info(f'Scraping: {self.url}')
        
        utf8_parser = html.HTMLParser(encoding = 'utf-8')
        
        try:
            # Fetch the main article page
            resp = requests.get(self.url, headers = self.headers)
            resp.raise_for_status()
            tree = html.fromstring(resp.content, parser = utf8_parser)
            
            # Main contents
            data = {
                'url': self.url,
                'title': '',
                'abstract': '',
                'sections': [],
                'figures': [],
                'references': []
            }

            # 1. Parse Title
            try:
                title = tree.xpath("//h1[contains(@class, 'c-article-title')]/text()")[0].strip()
                data['title'] = title
            except Exception:
                self.logging.warning('Article title not found.')

            # 2. Parse Abstract
            try:
                abstract_section = tree.xpath("//section[@aria-labelledby='Abs1']")[0]
                abstract_title = abstract_section.xpath('.//h2/text()')[0].strip()
                abstract_content = '\n'.join(
                    p.text_content().strip()
                    for p in abstract_section.xpath(".//div[contains(@class, 'c-article-section__content')]//p")
                )
                data['abstract'] = {'title': abstract_title, 'content': abstract_content}
            except Exception:
                self.logging.warning('Abstract not found.')

            # 3. Parse Main Sections
            self.logging.info('Scraping main sections ...')
            try:
                main_content = tree.xpath("//div[contains(@class, 'main-content')]")
                iii = 1
                if main_content:
                    sections = main_content[0].xpath('.//section[@data-title]')
                    for section in sections:
                        title_node = section.xpath('.//h2')
                        if not title_node: continue
                        
                        title = title_node[0].text_content().strip()
                        content_node = section.xpath(".//div[contains(@class, 'c-article-section__content')]")
                        if not content_node: continue
    
                        elements = content_node[0].xpath('.//h3 | .//p')
                        content_parts = []
                        for el in elements:
                            text = el.text_content().strip()
                            if not text: continue
                            
                            if el.tag == 'h3':
                                content_parts.append(f'\n\n--- {text} ---\n')
                            elif el.tag == 'p':
                                content_parts.append(text)
                        
                        content = '\n'.join(content_parts)
                        
                        # Removing specific characters based on original regex logic
                        content = re.sub(r'[\\\(.*?\\\)]', '', content)
                        data['sections'].append({'title': title, 'content': content})
                        self.logging.info(f'Section {iii}: {title}')
                        iii += 1
                
                self.logging.info(f"Successfully scraped {len(data['sections'])} sections.")
                
            except Exception as e:
                self.logging.error(f'Error scraping main sections: {e}')

            # 4. Parse References (Logic: First reference only based on original code)
            self.logging.info('Scraping references ...')
            try:
                
                # Note: Original logic limits to the first reference item (position() <= 1)
                reference_items = tree.xpath('//*[@id="article-info-content"]/div/div[2]/p[1]')
                ref_text = reference_items[0].text_content()
                # Remove \n
                ref_text = re.sub(r'\n\s*', ' ', ref_text)
                if ref_text:
                    data['references'].append(ref_text)
                self.logging.info(f"Successfully scraped {len(data['references'])} references.")
            except Exception as e:
                self.logging.error(f'Error scraping references: {e}')

            # 5. Parse Figures (Backdoor logic: iterating through /figures/{i})
            self.logging.info('Scraping figures ...')
            for i in range(1, 20):
                try:
                    fig_url = f'{self.url}/figures/{i}'
                    fig_response = requests.get(fig_url, headers = self.headers)
                    fig_response.raise_for_status()
                    fig_tree = html.fromstring(fig_response.content, parser = utf8_parser)
    
                    try:
                        fig_title_check = fig_tree.xpath("//h1[contains(@class, 'c-article-satellite-title')]/text()")[0].strip()
                    except Exception:
                        self.logging.info(f'Stopped at Figure {i} (Figure page not found). Scraping figures finished.')
                        break
    
                    img_src = ''
                    try:
                        # Try extracting high-res webp source
                        img_src = fig_tree.xpath("//source[@type='image/webp']/@srcset")[0]
                        img_src = img_src.split(',')[0].split(' ')[0]
                    except Exception:
                        try:
                            # Fallback to standard img src
                            img_src = fig_tree.xpath("//div[contains(@class, 'c-article-figure-content')]//img/@src")[0]
                        except Exception as e_img:
                            self.logging.warning(f'Figure {i} page is valid, but image source not found: {e_img}')
                            continue
    
                    # Normalize URL
                    if img_src.startswith('//'):
                        img_src = 'https:' + img_src
                    elif not img_src.startswith('https:'):
                        img_src = urljoin('https://www.nature.com', img_src)
                    img_src = img_src.split('?')[0]
    
                    caption = ''
                    try:
                        fig_title = fig_title_check
                        desc_nodes = fig_tree.xpath("//div[contains(@class, 'c-article-figure-description')]//p")
                        desc = '\n'.join(p.text_content().strip() for p in desc_nodes)
                        caption = f'{fig_title}\n{desc}'
                    except Exception as e:
                        self.logging.warning(f'Caption extraction failed for Figure {i}: {e}')
                        caption = f'{fig_title_check}\n[Caption extraction failed]'
    
                    data['figures'].append({'id': f'figure_{i}', 'url': img_src, 'caption': caption})
                    self.logging.info(f'Successfully scraped Figure {i}.')
    
                except requests.exceptions.RequestException as e:
                    self.logging.error(f'Request error at Figure {i}: {e}')
                    self.logging.info(f'Stopped at Figure {i}. Scraping figures finished.')
                    break

        except requests.exceptions.RequestException as e:
            self.logging.critical(f'Network error while scraping main article page: {e}')
            return None
        except Exception as e:
            self.logging.critical(f'Unknown error while parsing main article page: {e}')
            return None
        
        self.logging.info(f'Scraping {self.url} Completed !!!')
        return data