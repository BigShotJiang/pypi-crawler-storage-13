# -*- coding: utf-8 -*-
"""
Created on Thu Nov 20 22:49:23 2025
 @author Abao Xing
 @email  albertxn7@gmail.com
 This scripts writen by Abao Xing

   ┏┓　　┏┓
  ┏┛┻━━━━┛┻┓
  ┃　　　　  ┃
  ┃　━　　━　 ┃
  ┃　┳┛　┗┳　 ┃
  ┃　　　　　 ┃
  ┃　　　┻　　┃
  ┃　　　　　 ┃
  ┗━━┓　　　┏━┛
  　　┃　　 ┃ 神兽保佑
  　　┃　　 ┃ 代码无BUG！！！
  　　┃　　 ┗━━━━━┓
  　　┃　　　　　　  ┣┓
 　　┃　　　　　　  ┏┛┃
 　　┗┓┓┏━━━━━┳┓┏━━┛
  　　┃┫┫　   ┃┫┫
  　　┗┻┛　   ┗┻┛

"""

from .scrapers import NatureScraper
from .analyzer import LLMAnalyzer
from .flowchart import Flowcharter
from .generator import DocxReportGenerator
from .utils import BrowserHelper

__all__ = ['NatureScraper', 'LLMAnalyzer', 'DocxReportGenerator', 'BrowserHelper', 'Flowcharter']