# -*- coding: utf-8 -*-
"""
Created on Thu Nov 20 22:49:39 2025
 @author Abao Xing
 @email  albertxn7@gmail.com
 This scripts writen by Abao Xing

   ┏┓　　┏┓
  ┏┛┻━━━━┛┻┓
  ┃　　　　  ┃
  ┃　━　　━　 ┃
  ┃　┳┛　┗┳　 ┃
  ┃　　　　　 ┃
  ┃　　　┻　　┃
  ┃　　　　　 ┃
  ┗━━┓　　　┏━┛
  　　┃　　 ┃ 神兽保佑
  　　┃　　 ┃ 代码无BUG！！！
  　　┃　　 ┗━━━━━┓
  　　┃　　　　　　  ┣┓
 　　┃　　　　　　  ┏┛┃
 　　┗┓┓┏━━━━━┳┓┏━━┛
  　　┃┫┫　   ┃┫┫
  　　┗┻┛　   ┗┻┛

pip install -r requirements.txt
pip install -e .

pip install setuptools twine
python setup.py sdist bdist_wheel

"""

import os
import codecs
from setuptools import setup, find_packages

# these things are needed for the README.md show on pypi
here = os.path.abspath(os.path.dirname(__file__))
 
with codecs.open(os.path.join(here, 'README.md'), encoding = 'utf-8') as fh:
    long_description = '\n' + fh.read()


VERSION = '1.0.0'
DESCRIPTION = 'A tool for scraping and analyzing scientific literature.'
LONG_DESCRIPTION = 'None'


setup(
    name = 'litflow',
    version = VERSION,
    packages = find_packages(),
    install_requires = [
        'requests',
        'lxml',
        'selenium',
        'python-docx',
        'cairosvg',
        'pyyaml'
    ],
    author = 'Abao Xing',
    description = DESCRIPTION,
    long_description_content_type = 'text/markdown',
    long_description = LONG_DESCRIPTION,
)