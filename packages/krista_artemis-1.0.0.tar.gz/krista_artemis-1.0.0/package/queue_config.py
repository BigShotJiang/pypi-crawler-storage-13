"""
Queue Configuration for AMQP (qpid-proton) implementation.

Loads configuration from queue_config.json and provides access to connection settings,
queue definitions, and AMQP-specific settings.
"""

import json
import os
from typing import Dict, Any, Optional


class QueueConfig:
    """Load queue configuration from queue_config.json file."""

    def __init__(self, config_file: str = "app/config/queue_config.json"):
        self.config_file = config_file
        self.config = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        """Load queue configuration from JSON file."""
        if not os.path.exists(self.config_file):
            raise FileNotFoundError(
                f"Queue config file '{self.config_file}' not found. "
                "Please create it with the required queue server credentials."
            )

        try:
            with open(self.config_file, 'r') as f:
                config = json.load(f)
            return config
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in {self.config_file}: {e}")

    # ===== CONNECTION SETTINGS =====

    @property
    def host(self) -> str:
        """Get queue host from environment variable or config file."""
        return os.getenv('ARTEMIS_HOST', self.config.get('host', 'artemis'))

    @property
    def port(self) -> int:
        """Get AMQP port from environment variable or config file."""
        # AMQP uses port 5672 by default (not 61613 which is STOMP)
        port = os.getenv('ARTEMIS_AMQP_PORT')
        if port:
            return int(port)
        # Check if config has amqp_port, otherwise default to 5672
        return self.config.get('port', 5672)

    @property
    def username(self) -> str:
        """Get queue username from environment variable or config file."""
        return os.getenv('ARTEMIS_USER', self.config.get('username', 'admin'))

    @property
    def password(self) -> str:
        """Get queue password from environment variable or config file."""
        return os.getenv('ARTEMIS_PASSWORD', self.config.get('password', 'admin'))

    @property
    def protocol(self) -> str:
        """Protocol to use: 'amqp'"""
        return 'amqp'

    def get_connection_url(self) -> str:
        """Get AMQP connection URL for ActiveMQ Artemis."""
        return f"amqp://{self.host}:{self.port}"

    def get_credentials(self) -> Dict[str, str]:
        """Get credentials as dictionary."""
        return {
            'username': self.username,
            'password': self.password
        }

    # ===== MANAGEMENT API SETTINGS (for queue creation) =====

    @property
    def management_host(self) -> str:
        """Get management API host."""
        return os.getenv('ARTEMIS_MANAGEMENT_HOST', self.config.get('management_host', self.host))

    @property
    def management_port(self) -> int:
        """Get management API port (Jolokia)."""
        port = os.getenv('ARTEMIS_MANAGEMENT_PORT')
        if port:
            return int(port)
        return self.config.get('management_port', 8161)

    def get_management_url(self) -> str:
        """Get management API URL."""
        return f"http://{self.management_host}:{self.management_port}/console/jolokia"

    # ===== RECONNECT SETTINGS =====

    @property
    def reconnect_enabled(self) -> bool:
        """Check if reconnect is enabled."""
        reconnect = self.config.get('reconnect', {})
        return reconnect.get('enabled', True)

    @property
    def reconnect_max_attempts(self) -> int:
        """Get maximum reconnect attempts."""
        reconnect = self.config.get('reconnect', {})
        return reconnect.get('max_attempts', 5)

    @property
    def reconnect_delay(self) -> int:
        """Get reconnect delay in seconds."""
        reconnect = self.config.get('reconnect', {})
        return reconnect.get('delay', 5)

    # ===== QUEUE DEFINITIONS =====

    def get_queue_names(self) -> list:
        """Get list of all configured queue names."""
        queues = self.config.get('queues', {})
        return list(queues.keys())

    def get_queue_config(self, queue_name: str) -> Optional[Dict[str, Any]]:
        """Get configuration for a specific queue."""
        queues = self.config.get('queues', {})
        return queues.get(queue_name)

    def get_queue_full_name(self, queue_name: str) -> str:
        """Get full queue name from config."""
        queue_config = self.get_queue_config(queue_name)
        if queue_config is None:
            raise ValueError(f"Queue '{queue_name}' not found in configuration")
        return queue_config.get('name', queue_name)

    def get_queue_description(self, queue_name: str) -> str:
        """Get description for a queue."""
        queue_config = self.get_queue_config(queue_name)
        if queue_config is None:
            return ""
        return queue_config.get('description', '')

    def get_all_queues_config(self) -> Dict[str, Any]:
        """Get configuration for all queues."""
        return self.config.get('queues', {})

    def get_queue_handler_timeout(self, queue_name: str) -> int:
        """Get handler timeout for a specific queue."""
        queue_config = self.get_queue_config(queue_name)
        if queue_config is None:
            return 60  # Default timeout
        return queue_config.get('handler_timeout_seconds', 60)

    def get_queue_message_ttl(self, queue_name: str) -> int:
        """Get message TTL in seconds for a specific queue."""
        queue_config = self.get_queue_config(queue_name)
        if queue_config is None:
            return -1  # Default: 1 hour
        return queue_config.get('message_ttl_seconds', -1)

