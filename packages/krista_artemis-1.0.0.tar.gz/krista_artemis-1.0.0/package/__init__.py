"""
Queue module for ActiveMQ Artemis integration using AMQP 1.0 protocol (qpid-proton).

This module provides a complete AMQP implementation with:
- Proper transaction support for reliable message retry
- Immediate message redelivery on failure
- Better performance than STOMP
- More reliable acknowledgements
"""

from .message import QueueMessage
from .consumer_manager import QueueConsumerManager
from .consumer import QueueConsumer
from .producer import QueueProducer
from .queue_config import QueueConfig
from .queue_creator import QueueCreator

__version__ = "1.0.1"

__all__ = ['QueueMessage', 'QueueConsumerManager', 'QueueConsumer', 'QueueProducer', 'QueueConfig', 'QueueCreator']

