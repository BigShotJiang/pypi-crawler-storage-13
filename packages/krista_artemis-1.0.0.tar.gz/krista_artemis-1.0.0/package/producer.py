"""
Queue Producer - Send messages to ActiveMQ Artemis queues using AMQP 1.0.

This module provides functionality to send messages to Artemis queues using the AMQP protocol
via qpid-proton library. It verifies queue existence, creates queues if needed, and handles
connection errors with retry logic.

Advantages over STOMP:
- Proper transaction support
- Better performance
- More reliable delivery confirmations
- Industry-standard protocol
"""

import logging
import json
import time
import uuid
from typing import Any, Dict, Optional
from proton import Message
from proton.handlers import MessagingHandler
from proton.reactor import Container
from .queue_config import QueueConfig
from .queue_creator import QueueCreator

logger = logging.getLogger(__name__)


class SendHandler(MessagingHandler):
    """Handler for sending messages with confirmation."""

    def __init__(self, url: str, address: str, message: Message):
        super(SendHandler, self).__init__()
        self.url = url
        self.address = address
        self.message = message
        self.confirmed = False
        self.error = None
        self.sent = False

    def on_start(self, event):
        """Called when the container starts."""
        # Connect to broker
        # The broker's amqpIdleTimeout setting (120000ms) controls the connection timeout
        # Proton will automatically handle heartbeats based on the negotiated idle timeout
        self.conn = event.container.connect(self.url)
        event.container.create_sender(self.conn, self.address)

    def on_sendable(self, event):
        """Called when the sender is ready to send."""
        if not self.sent:
            event.sender.send(self.message)
            self.sent = True

    def on_accepted(self, event):
        """Called when the message is accepted by the broker."""
        self.confirmed = True
        event.connection.close()

    def on_rejected(self, event):
        """Called when the message is rejected by the broker."""
        self.error = f"Message rejected: {event.delivery.remote.condition}"
        event.connection.close()

    def on_released(self, event):
        """Called when the message is released by the broker."""
        self.error = "Message released by broker"
        event.connection.close()

    def on_settled(self, event):
        """Called when the delivery is settled."""
        if not self.confirmed and not self.error:
            # Check delivery state
            if event.delivery.remote_state == event.delivery.ACCEPTED:
                self.confirmed = True
            elif event.delivery.remote_state == event.delivery.REJECTED:
                self.error = "Message rejected by broker"
            else:
                self.error = f"Message settled with state: {event.delivery.remote_state}"
        event.connection.close()

    def on_transport_error(self, event):
        """Called when there's a transport error."""
        condition = event.transport.condition
        self.error = f"Transport error: {condition}"
        event.connection.close()


class QueueProducer:
    """Producer for sending messages to ActiveMQ Artemis queues using AMQP."""

    def __init__(
        self,
        config: QueueConfig = None,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        retry_backoff: float = 5.0,
        queue_creator_max_retries: int = None,
        queue_creator_retry_delay: float = None,
        queue_creator_retry_backoff: float = None
    ):
        """
        Initialize queue producer.

        Args:
            config: QueueConfig instance (if None, creates default)
            max_retries: Maximum retries for sending messages
            retry_delay: Initial retry delay in seconds
            retry_backoff: Backoff multiplier for retries
            queue_creator_max_retries: Max retries for queue creation (uses max_retries if None)
            queue_creator_retry_delay: Retry delay for queue creation (uses retry_delay if None)
            queue_creator_retry_backoff: Backoff for queue creation (uses retry_backoff if None)
        """
        self.config = config if config else QueueConfig()
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.retry_backoff = retry_backoff

        # Initialize queue creator with separate retry settings
        self.queue_creator = QueueCreator(
            config=self.config,
            max_retries=queue_creator_max_retries if queue_creator_max_retries is not None else max_retries,
            retry_delay=queue_creator_retry_delay if queue_creator_retry_delay is not None else retry_delay,
            retry_backoff=queue_creator_retry_backoff if queue_creator_retry_backoff is not None else retry_backoff
        )

        # Build AMQP connection URL
        credentials = self.config.get_credentials()
        self.connection_url = (
            f"amqp://{credentials['username']}:{credentials['password']}"
            f"@{self.config.host}:{self.config.port}"
        )

    def _ensure_queue_exists(self, queue_name: str) -> str:
        """
        Ensure queue exists in broker, create if it doesn't.

        Args:
            queue_name: Queue key from config

        Returns:
            Full queue name

        Raises:
            ValueError: If queue not found in configuration
            ConnectionError: If cannot connect to management API
        """
        queue_config = self.config.get_queue_config(queue_name)
        if not queue_config:
            raise ValueError(
                f"Queue '{queue_name}' not found in configuration. "
                f"Available queues: {', '.join(self.config.get_queue_names())}"
            )

        full_queue_name = queue_config.get('name', queue_name)
        routing_type = queue_config.get('routing_type', 'ANYCAST').upper()

        # Check if queue exists
        if self.queue_creator.queue_exists(full_queue_name, routing_type):
            logger.debug(f"Queue '{full_queue_name}' already exists ({routing_type})")
        else:
            # Create queue
            logger.info(f"Queue '{full_queue_name}' does not exist, creating...")
            durable = queue_config.get('durable', True)
            auto_delete = queue_config.get('auto_delete', False)
            self.queue_creator.create_queue(full_queue_name, durable, auto_delete, routing_type)
            logger.info(f"✓ Queue created successfully")

        return full_queue_name

    def send_message(
        self,
        queue_name: str,
        message: Any,
        headers: Optional[Dict[str, str]] = None
    ) -> bool:
        """
        Send a message to a queue with retry logic.

        Args:
            queue_name: Queue key from configuration (e.g., 'default', 'chat')
            message: Message to send (will be JSON-serialized if dict/list)
            headers: Optional headers to include with the message

        Returns:
            True if message was sent successfully

        Raises:
            ValueError: If queue not found in configuration
            ConnectionError: If cannot connect to broker
            Exception: If message sending fails after retries
        """
        # Ensure queue exists
        full_queue_name = self._ensure_queue_exists(queue_name)

        # Prepare message body
        if isinstance(message, (dict, list)):
            message_body = json.dumps(message)
            content_type = 'application/json'
        else:
            message_body = str(message)
            content_type = 'text/plain'

        # Log the message body
        logger.info(f"Preparing message for queue '{queue_name}': {message_body}")
        if headers:
            logger.info(f"Message headers: {headers}")

        # Get message TTL from queue config
        message_ttl_seconds = self.config.get_queue_message_ttl(queue_name)
        
        # Create AMQP message
        msg_kwargs = {
            'body': message_body,
            'content_type': content_type,
            'durable': True,  # Message survives broker restart
            'id': str(uuid.uuid4())  # Unique message ID
        }
        
        # Only set TTL if not "never expire" (-1 or 0)
        if message_ttl_seconds > 0:
            msg_kwargs['ttl'] = message_ttl_seconds
            logger.info(f"Message TTL set to {message_ttl_seconds} seconds for queue '{queue_name}'")
        else:
            logger.info(f"Message TTL disabled (never expire) for queue '{queue_name}'")
        
        msg = Message(**msg_kwargs)

        # Add custom headers if provided
        if headers:
            msg.properties = headers

        # Send with retry logic
        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                logger.info(
                    f"Sending message to queue '{full_queue_name}' "
                    f"(attempt {attempt + 1}/{self.max_retries + 1})..."
                )

                # Create handler and container
                handler = SendHandler(self.connection_url, full_queue_name, msg)
                container = Container(handler)
                container.run()

                # Check if message was confirmed
                if handler.confirmed:
                    logger.info(
                        f"✓ Message sent successfully to queue '{full_queue_name}'. "
                        f"Message body: {message_body}"
                    )
                    return True
                elif handler.error:
                    raise Exception(handler.error)
                else:
                    raise Exception("Message sending failed without error details")

            except Exception as e:
                last_error = e
                if attempt < self.max_retries:
                    delay = self.retry_delay * (self.retry_backoff ** attempt)
                    logger.warning(
                        f"Failed to send message to queue '{full_queue_name}' "
                        f"(attempt {attempt + 1}/{self.max_retries + 1}): {e}. "
                        f"Message body: {message_body}. "
                        f"Retrying in {delay:.1f}s..."
                    )
                    time.sleep(delay)
                else:
                    logger.error(
                        f"Failed to send message to queue '{full_queue_name}' "
                        f"after {self.max_retries + 1} attempts: {e}. "
                        f"Message body: {message_body}"
                    )
                continue

        # All retries failed
        raise Exception(
            f"Failed to send message to queue '{full_queue_name}' after {self.max_retries + 1} attempts: {last_error}. "
            f"Message body: {message_body}"
        ) from last_error

