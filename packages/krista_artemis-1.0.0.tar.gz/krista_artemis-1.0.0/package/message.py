"""
Queue Message Wrapper

This module provides a wrapper around the Proton Message class to abstract
the AMQP library dependency from application code.

This allows the queue_qpid module to be externalized without requiring
the application to have direct dependencies on python-qpid-proton.
"""

from typing import Any, Dict, Optional


class QueueMessage:
    """
    Wrapper for AMQP message that abstracts the underlying Proton Message.
    
    This class provides a clean interface for accessing message properties
    without exposing the Proton library to application code.
    
    Attributes:
        body: Message body (can be string, dict, list, etc.)
        id: Unique message identifier
        properties: Message properties/headers (dict)
        content_type: MIME type of the message content
        correlation_id: Correlation ID for request/response patterns
        reply_to: Reply-to address for responses
        subject: Message subject/topic
        annotations: Message annotations (dict)
    """
    
    def __init__(self, proton_message):
        """
        Initialize QueueMessage from a Proton Message.
        
        Args:
            proton_message: The underlying proton.Message object
        """
        self._proton_message = proton_message
    
    @property
    def body(self) -> Any:
        """Get message body."""
        return self._proton_message.body
    
    @property
    def id(self) -> Optional[str]:
        """Get message ID."""
        return self._proton_message.id
    
    @property
    def properties(self) -> Optional[Dict[str, Any]]:
        """Get message properties/headers."""
        return self._proton_message.properties
    
    @property
    def content_type(self) -> Optional[str]:
        """Get message content type."""
        return self._proton_message.content_type
    
    @property
    def correlation_id(self) -> Optional[str]:
        """Get correlation ID."""
        return self._proton_message.correlation_id
    
    @property
    def reply_to(self) -> Optional[str]:
        """Get reply-to address."""
        return self._proton_message.reply_to
    
    @property
    def subject(self) -> Optional[str]:
        """Get message subject."""
        return self._proton_message.subject
    
    @property
    def annotations(self) -> Optional[Dict[str, Any]]:
        """Get message annotations."""
        return self._proton_message.annotations
    
    def __str__(self) -> str:
        """String representation of the message."""
        return f"QueueMessage(id={self.id}, body={self.body})"
    
    def __repr__(self) -> str:
        """Detailed representation of the message."""
        return (
            f"QueueMessage(id={self.id}, body={self.body}, "
            f"properties={self.properties}, content_type={self.content_type})"
        )

