"""
Queue Creator - Create queues in ActiveMQ Artemis via Jolokia management API.

This module provides functionality to create queues in Artemis using the
Jolokia REST API. It handles connection errors, provides retry logic with
exponential backoff, and provides clear error messages.

Note: This is the same implementation as the STOMP version since queue creation
uses the Jolokia management API, not the messaging protocol.
"""

import logging
import requests
import time
from requests.auth import HTTPBasicAuth
from typing import Dict, Any
from .queue_config import QueueConfig

logger = logging.getLogger(__name__)


class QueueCreator:
    """Create and manage queues in ActiveMQ Artemis with retry logic."""

    def __init__(
        self,
        config: QueueConfig,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        retry_backoff: float = 5.0
    ):
        """
        Initialize queue creator.

        Args:
            config: QueueConfig instance
            max_retries: Maximum number of retry attempts (default: 3)
            retry_delay: Initial retry delay in seconds (default: 1.0)
            retry_backoff: Backoff multiplier for retries (default: 2.0)
        """
        self.config = config
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.retry_backoff = retry_backoff

        # Build management API URL
        self.management_url = self.config.get_management_url()
        self.auth = HTTPBasicAuth(self.config.username, self.config.password)

    def _make_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make a request to Jolokia API with retry logic.

        Args:
            payload: Jolokia request payload

        Returns:
            Response JSON

        Raises:
            ConnectionError: If cannot connect after retries
            Exception: If request fails after retries
        """
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                response = requests.post(
                    self.management_url,
                    json=payload,
                    auth=self.auth,
                    timeout=10
                )

                if response.status_code == 200:
                    return response.json()
                else:
                    raise Exception(
                        f"Jolokia API returned status {response.status_code}: {response.text}"
                    )

            except requests.exceptions.ConnectionError as e:
                last_error = e
                if attempt < self.max_retries:
                    delay = self.retry_delay * (self.retry_backoff ** attempt)
                    logger.warning(
                        f"Cannot connect to Artemis management API (attempt {attempt + 1}/{self.max_retries + 1}). "
                        f"Retrying in {delay:.1f}s..."
                    )
                    time.sleep(delay)
                continue

            except Exception as e:
                last_error = e
                if attempt < self.max_retries:
                    delay = self.retry_delay * (self.retry_backoff ** attempt)
                    logger.warning(
                        f"Request failed (attempt {attempt + 1}/{self.max_retries + 1}): {e}. "
                        f"Retrying in {delay:.1f}s..."
                    )
                    time.sleep(delay)
                continue

        # All retries failed
        if isinstance(last_error, requests.exceptions.ConnectionError):
            raise ConnectionError(
                f"Cannot connect to Artemis management API at {self.management_url} after {self.max_retries + 1} attempts. "
                f"Make sure Artemis is running and accessible."
            ) from last_error
        else:
            raise Exception(
                f"Request to Artemis management API failed after {self.max_retries + 1} attempts: {last_error}"
            ) from last_error

    def create_queue(
        self,
        queue_name: str,
        durable: bool = True,
        auto_delete: bool = False,
        routing_type: str = "ANYCAST"
    ) -> bool:
        """
        Create a queue in Artemis.

        Args:
            queue_name: Name of the queue to create
            durable: Whether the queue should be durable (survives broker restart)
            auto_delete: Whether to purge the queue when no consumers are connected
            routing_type: Routing type - "ANYCAST" (queue) or "MULTICAST" (topic)

        Returns:
            True if queue was created successfully or already exists

        Raises:
            ConnectionError: If cannot connect to Artemis management API
            Exception: If queue creation fails
        """
        # Check if queue already exists
        if self.queue_exists(queue_name, routing_type):
            logger.debug(f"Queue '{queue_name}' already exists ({routing_type})")
            return True

        logger.info(f"Creating queue '{queue_name}' ({routing_type})...")

        # Create queue using Jolokia API
        payload = {
            "type": "exec",
            "mbean": "org.apache.activemq.artemis:broker=\"0.0.0.0\"",
            "operation": "createQueue(java.lang.String,java.lang.String,java.lang.String,java.lang.String,boolean,int,boolean,boolean)",
            "arguments": [
                queue_name,      # address
                routing_type,    # routingType - ANYCAST or MULTICAST
                queue_name,      # queueName
                "",              # filterStr
                durable,         # durable
                -1,              # maxConsumers
                auto_delete,     # purgeOnNoConsumers
                True             # autoCreateAddress
            ]
        }

        result = self._make_request(payload)

        # Check if operation was successful
        if result.get('status') == 200:
            logger.info(f"✓ Queue '{queue_name}' created successfully")
            return True
        else:
            error_msg = result.get('error', 'Unknown error')
            raise Exception(f"Failed to create queue '{queue_name}': {error_msg}")

    def queue_exists(self, queue_name: str, routing_type: str = "ANYCAST") -> bool:
        """
        Check if a queue exists in Artemis.

        Args:
            queue_name: Name of the queue to check
            routing_type: Routing type - "ANYCAST" (queue) or "MULTICAST" (topic)

        Returns:
            True if queue exists, False otherwise

        Raises:
            ConnectionError: If cannot connect to Artemis management API
            Exception: If the check fails
        """
        routing_type_lower = routing_type.lower()

        payload = {
            "type": "read",
            "mbean": f"org.apache.activemq.artemis:broker=\"0.0.0.0\",component=addresses,address=\"{queue_name}\",subcomponent=queues,routing-type=\"{routing_type_lower}\",queue=\"{queue_name}\""
        }

        try:
            result = self._make_request(payload)
            # If we get a 200 status and value is not None, queue exists
            return result.get('status') == 200 and result.get('value') is not None
        except Exception as e:
            # If the mbean doesn't exist, queue doesn't exist
            if "InstanceNotFoundException" in str(e):
                return False
            # Re-raise other errors
            raise

