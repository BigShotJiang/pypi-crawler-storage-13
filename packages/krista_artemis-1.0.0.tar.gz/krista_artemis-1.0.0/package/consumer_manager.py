"""
Queue Consumer Manager - Manages multiple queue consumers using AMQP.

This module provides a manager that:
1. Registers consumers for specific queues with optional handlers
2. Creates a consumer thread for each registered queue
3. Provides graceful shutdown for all consumers
4. Thread-safe operations

Usage:
    from app.queue_qpid.consumer_manager import QueueConsumerManager
    from app.queue_qpid.queue_config import QueueConfig

    # Create manager with config
    config = QueueConfig()
    manager = QueueConsumerManager(config)

    # Register consumers with handlers
    manager.register_consumer('default', my_handler)
    manager.register_consumer('chat', my_chat_handler)

    # Start all consumers
    manager.start()

    # Wait for shutdown
    manager.wait()

    # Stop all consumers
    manager.stop()
"""

import logging
import threading
from typing import Dict, Callable, Optional
from .queue_config import QueueConfig
from .consumer import QueueConsumer

logger = logging.getLogger(__name__)


class QueueConsumerManager:
    """
    Manager for multiple queue consumers using AMQP.

    Creates and manages consumer threads for registered queues.
    Each consumer runs in its own thread.

    Features:
    - Creates consumers for registered queues
    - One thread per registered consumer
    - Graceful shutdown of all consumers
    - Thread-safe operations
    """

    def __init__(
        self,
        config: QueueConfig,
        retry_delay: int = 10,
        max_retry_delay: int = 60
    ):
        """
        Initialize consumer manager.

        Args:
            config: QueueConfig instance
            retry_delay: Initial retry delay for all consumers (default: 10 seconds)
            max_retry_delay: Maximum retry delay for all consumers (default: 300 seconds)
        """
        self.config = config
        self.retry_delay = retry_delay
        self.max_retry_delay = max_retry_delay

        # Storage for consumers and threads
        self.consumers: Dict[str, QueueConsumer] = {}
        self.threads: Dict[str, threading.Thread] = {}

        self.running = False
        self._lock = threading.Lock()

    def register_consumer(self, queue_name: str, handler: Optional[Callable] = None):
        """
        Register a consumer for a specific queue with an optional handler.

        Creates a QueueConsumer internally and registers it.
        The consumer will be started when start() is called.

        Args:
            queue_name: Queue key from config (e.g., 'default', 'chat')
            handler: Optional callable that takes (message: Message).
                     If None, the default handler will be used.

        Example:
            from app.queue_qpid.consumer_manager import QueueConsumerManager
            from app.queue_qpid.queue_config import QueueConfig

            def my_handler(message):
                print(f"Received: {message.body}")

            config = QueueConfig()
            manager = QueueConsumerManager(config)

            # Register with custom handler
            manager.register_consumer('default', my_handler)

            # Register with default handler
            manager.register_consumer('chat')

            manager.start()

        Raises:
            RuntimeError: If consumer already registered for this queue
            ValueError: If queue_name not found in configuration
        """
        with self._lock:
            # Check if already registered
            if queue_name in self.consumers:
                raise RuntimeError(
                    f"Consumer already registered for queue '{queue_name}'. "
                    f"Use unregister_consumer() first if you want to replace it."
                )

            # Validate queue exists in config
            queue_config = self.config.get_queue_config(queue_name)
            if not queue_config:
                raise ValueError(
                    f"Queue '{queue_name}' not found in configuration. "
                    f"Available queues: {', '.join(self.config.get_queue_names())}"
                )

            # Create consumer
            consumer = QueueConsumer(
                config=self.config,
                queue_name=queue_name,
                handler=handler,
                retry_delay=self.retry_delay,
                max_retry_delay=self.max_retry_delay
            )

            # Register consumer
            self.consumers[queue_name] = consumer

            handler_type = "custom handler" if handler else "default handler"
            logger.info(f"✓ Registered consumer for queue '{queue_name}' with {handler_type}")

    def unregister_consumer(self, queue_name: str):
        """
        Unregister a consumer for a specific queue.

        If the consumer is running, it will be stopped first.

        Args:
            queue_name: Queue key from config (e.g., 'default', 'chat')

        Raises:
            ValueError: If no consumer registered for this queue
        """
        with self._lock:
            if queue_name not in self.consumers:
                raise ValueError(f"No consumer registered for queue '{queue_name}'")

            # Stop consumer if running
            if queue_name in self.threads:
                logger.info(f"Stopping consumer for '{queue_name}' before unregistering...")
                consumer = self.consumers[queue_name]
                consumer.stop()

                # Wait for thread to finish
                thread = self.threads[queue_name]
                thread.join(timeout=10)

                if thread.is_alive():
                    logger.warning(f"Thread for '{queue_name}' did not stop gracefully")

                del self.threads[queue_name]

            # Remove consumer
            del self.consumers[queue_name]
            logger.info(f"✓ Unregistered consumer for queue '{queue_name}'")

    def get_registered_queues(self):
        """
        Get list of all registered queue names.

        Returns:
            List of queue names that have registered consumers
        """
        with self._lock:
            return list(self.consumers.keys())

    def is_registered(self, queue_name: str) -> bool:
        """
        Check if a consumer is registered for a specific queue.

        Args:
            queue_name: Queue key from config

        Returns:
            True if consumer is registered, False otherwise
        """
        with self._lock:
            return queue_name in self.consumers

    def start(self):
        """
        Start all registered consumers in separate threads.

        Only consumers that have been registered will be started.
        """
        with self._lock:
            if self.running:
                logger.warning("Consumer manager already running")
                return

            self.running = True

        if not self.consumers:
            logger.error("No consumers registered. Use register_consumer() to register queues first.")
            return

        # Start each consumer in its own thread
        logger.info("=" * 60)
        logger.info("Starting Queue Consumer Manager (AMQP)")
        logger.info(f"Total registered consumers: {len(self.consumers)}")
        logger.info("=" * 60)

        for queue_name, consumer in self.consumers.items():
            # Skip if already running
            if queue_name in self.threads and self.threads[queue_name].is_alive():
                logger.warning(f"Consumer for '{queue_name}' already running, skipping")
                continue

            thread = threading.Thread(
                target=consumer.run,
                name=f"Consumer-{queue_name}",
                daemon=False
            )
            thread.start()
            self.threads[queue_name] = thread
            logger.info(f"✓ Started consumer thread for '{queue_name}'")

        logger.info("=" * 60)
        logger.info("All consumers started successfully")
        logger.info("Press Ctrl+C to stop all consumers")
        logger.info("=" * 60)

    def stop(self):
        """Stop all consumers gracefully."""
        with self._lock:
            if not self.running:
                logger.warning("Consumer manager not running")
                return

            self.running = False

        logger.info("=" * 60)
        logger.info("Stopping all consumers...")
        logger.info("=" * 60)

        # Stop all consumers
        for queue_name, consumer in self.consumers.items():
            logger.info(f"Stopping consumer for '{queue_name}'...")
            consumer.stop()

        # Wait for all threads to finish (with timeout)
        for queue_name, thread in self.threads.items():
            logger.info(f"Waiting for thread '{queue_name}' to finish...")
            thread.join(timeout=10)
            if thread.is_alive():
                logger.warning(f"Thread '{queue_name}' did not stop gracefully")
            else:
                logger.info(f"✓ Thread '{queue_name}' stopped")

        logger.info("=" * 60)
        logger.info("All consumers stopped")
        logger.info("=" * 60)

    def wait(self):
        """
        Wait for all consumer threads to finish.

        This blocks until all consumers are stopped (e.g., by Ctrl+C or calling stop()).
        """
        try:
            for _queue_name, thread in self.threads.items():
                thread.join()
        except KeyboardInterrupt:
            logger.info("\nReceived interrupt signal")
            self.stop()

    def __enter__(self):
        """Context manager entry."""
        self.start()
        return self

    def __exit__(self, _exc_type, _exc_val, _exc_tb):
        """Context manager exit."""
        self.stop()

