"""
Generic Queue Consumer - Single queue consumer with AMQP 1.0 protocol.

This module provides a consumer for a single queue with:
1. Configurable acknowledgment modes (auto, client)
2. Manual acknowledgment for reliable message retry
3. Automatic reconnection with exponential backoff
4. Immediate message redelivery on failure (no connection tricks needed!)
5. Survives broker downtime
6. Graceful shutdown
7. Custom message handlers
8. Memory efficient

Acknowledgment Modes:
- 'auto': Messages auto-acknowledged (at-most-once delivery, no retry)
- 'client': Manual acknowledgment (at-least-once delivery, RECOMMENDED)

Advantages over STOMP:
- Messages are redelivered IMMEDIATELY on REJECT (not when connection closes)
- Broker's redelivery-delay and max-delivery-attempts settings work correctly
- No NACK issues (NACK doesn't exist in AMQP)
- Better performance and reliability

Usage:
    from app.queue_qpid.consumer import QueueConsumer
    from app.queue_qpid.queue_config import QueueConfig
    from app.queue_qpid import QueueMessage

    def my_handler(message: QueueMessage):
        print(f"Received: {message.body}")
        print(f"Message ID: {message.id}")
        print(f"Properties: {message.properties}")
        # If this raises an exception:
        # - 'auto' mode: message is lost
        # - 'client' mode: message is rejected and redelivered

    consumer = QueueConsumer(
        config=QueueConfig(),
        queue_name='default',  # ack_mode read from config
        handler=my_handler
    )

    consumer.run()
"""

import logging
import threading
import time
from typing import Callable, Dict, Optional
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError

from proton import Message
from proton.handlers import MessagingHandler
from proton.reactor import Container
from .queue_config import QueueConfig
from .queue_creator import QueueCreator
from .message import QueueMessage

logger = logging.getLogger(__name__)


class HandlerTimeoutError(Exception):
    """Raised when message handler exceeds timeout."""
    pass


class MessageHandler(MessagingHandler):
    """AMQP message handler with configurable acknowledgment modes."""

    def __init__(
        self,
        url: str,
        address: str,
        handler: Optional[Callable] = None,
        consumer: Optional['QueueConsumer'] = None,
        ack_mode: str = 'client',
        delivery_attempts: Optional[Dict[str, int]] = None,
        handler_timeout_seconds: int = None
    ):
        """
        Initialize message handler.

        Args:
            url: AMQP connection URL
            address: Queue address to consume from
            handler: Optional custom message handler function
            consumer: Reference to parent QueueConsumer
            ack_mode: Acknowledgment mode ('auto', 'client')
                     - 'auto': Messages auto-acknowledged (at-most-once delivery)
                     - 'client': Manual acknowledgment (at-least-once delivery, RECOMMENDED)
            handler_timeout_seconds: Maximum time (in seconds) allowed for handler execution
                                    If handler exceeds this time, HandlerTimeoutError is raised
        """
        # CRITICAL: Disable auto_accept for manual acknowledgment mode
        # In auto mode, let the library auto-accept
        # In client mode, we manually settle deliveries
        auto_accept = (ack_mode == 'auto')
        super(MessageHandler, self).__init__(auto_accept=auto_accept)

        self.url = url
        self.address = address
        self.handler = handler
        self.consumer = consumer
        self.ack_mode = ack_mode
        self.message_count = 0
        self.running = True
        self.handler_timeout_seconds = handler_timeout_seconds or 60  # Default fallback

        # Store connection reference for graceful shutdown
        self.connection = None

        # Track delivery attempts per message ID (for retry logic)
        self.delivery_attempts = delivery_attempts or {}
        self.max_delivery_attempts = 10  # Should match broker config

        # Thread pool executor for running handlers with timeout
        # Increased workers for concurrent message processing
        self.executor = ThreadPoolExecutor(
            max_workers=10, 
            thread_name_prefix=f"Handler-{address}"
        )

    def on_start(self, event):
        """Called when the container starts."""
        logger.info(f"[{self.address}] Connecting to broker...")

        # Connect to broker
        # The broker's amqpIdleTimeout setting (120000ms) controls the connection timeout
        # Proton will automatically handle heartbeats based on the negotiated idle timeout
        self.connection = event.container.connect(self.url)

        # Create receiver - all modes use the same receiver creation
        event.container.create_receiver(self.connection, self.address)

        # Log acknowledgment mode
        if self.ack_mode == 'auto':
            logger.info(f"[{self.address}] ✓ Consumer running with AUTO acknowledgment (no retry)")
        elif self.ack_mode == 'client':
            logger.info(f"[{self.address}] ✓ Consumer running with CLIENT acknowledgment")
        else:
            logger.warning(f"[{self.address}] Unknown acknowledgment mode '{self.ack_mode}', using CLIENT mode")
            self.ack_mode = 'client'
            logger.info(f"[{self.address}] ✓ Consumer running with CLIENT acknowledgment")

        logger.info(f"[{self.address}] ✓ Connected to broker")
        logger.info(f"[{self.address}] ✓ Subscribed to queue")

    def on_connection_opened(self, event):
        """Called when the connection is opened."""
        logger.info(f"[{self.address}] Connection opened")

    def on_message(self, event):
        """Called when a message is received."""
        if not self.running:
            return

        self.message_count += 1
        message = event.message

        logger.info(
            f"[{self.address}] Message #{self.message_count} received. "
            f"Message ID: {message.id}, Body: {message.body}"
        )

        # Handle based on acknowledgment mode
        if self.ack_mode == 'client':
            self._handle_client_ack(event, message)
        else:  # auto
            self._handle_auto_ack(event, message)

    def _handle_auto_ack(self, event, message: Message):
        """Handle message with auto-acknowledgment (at-most-once) - non-blocking."""
        # Wrap Proton Message in QueueMessage to abstract library dependency
        queue_message = QueueMessage(message)

        logger.info(f"[{self.address}] Processing message. Body: {queue_message.body}")

        # Submit handler to executor WITHOUT blocking
        future = self.executor.submit(
            self._process_message_auto_async,
            queue_message
        )
        
        # Don't wait for result - let it process asynchronously
        logger.info(f"[{self.address}] Message submitted for async processing (auto-ack)")

    def _process_message_auto_async(self, queue_message):
        """Process message asynchronously for auto-ack mode."""
        try:
            # Process the message with timeout
            handler_func = self.handler if self.handler else self.default_handler
            
            # Create a separate future for timeout handling
            handler_future = self.executor.submit(handler_func, queue_message)
            
            try:
                # Wait for completion with timeout
                handler_future.result(timeout=self.handler_timeout_seconds)
                
                # Message is automatically acknowledged by proton
                logger.info(
                    f"[{self.address}] ✅ Message processed successfully (auto-ack). "
                    f"Body: {queue_message.body}"
                )
                
            except FutureTimeoutError:
                # Cancel the running handler
                handler_future.cancel()
                logger.error(
                    f"[{self.address}] ⏱️ Handler timeout: Handler execution exceeded {self.handler_timeout_seconds} seconds. "
                    f"Body: {queue_message.body}",
                    exc_info=True
                )
                logger.warning(
                    f"[{self.address}] Message lost (auto-ack mode doesn't support retry). "
                    f"Body: {queue_message.body}"
                )
                
        except Exception as e:
            logger.error(
                f"[{self.address}] ❌ Error processing message: {e}. "
                f"Body: {queue_message.body}",
                exc_info=True
            )
            logger.warning(
                f"[{self.address}] Message lost (auto-ack mode doesn't support retry). "
                f"Body: {queue_message.body}"
            )

    def _handle_client_ack(self, event, message: Message):
        """Handle message with manual acknowledgment (at-least-once) - non-blocking."""
        
        # Wrap Proton Message in QueueMessage to abstract library dependency
        queue_message = QueueMessage(message)
        
        # Get message ID for tracking delivery attempts
        msg_id = queue_message.id
        if not msg_id:
            import hashlib
            msg_id = hashlib.md5(str(queue_message.body).encode()).hexdigest()[:16]

        logger.info(f"[{self.address}] Processing message. Body: {queue_message.body}")

        # Submit handler to executor WITHOUT blocking
        future = self.executor.submit(
            self._process_message_async,
            queue_message,
            msg_id,
            event.delivery,
            event.connection
        )
        
        # Don't wait for result - let it process asynchronously
        logger.info(f"[{self.address}] Message submitted for async processing: {msg_id}")

    def _process_message_async(self, queue_message, msg_id, delivery, connection):
        """Process message asynchronously and handle acknowledgment."""
        try:
            # Process the message with timeout
            handler_func = self.handler if self.handler else self.default_handler
            
            # Create a separate future for timeout handling
            handler_future = self.executor.submit(handler_func, queue_message)
            
            try:
                # Wait for completion with timeout
                handler_future.result(timeout=self.handler_timeout_seconds)
                
                # Success - accept the delivery
                delivery.update(delivery.ACCEPTED)
                delivery.settle()
                
                # Clear delivery attempts for this message
                if msg_id in self.delivery_attempts:
                    del self.delivery_attempts[msg_id]
                
                logger.info(
                    f"[{self.address}] ✅ Message processed successfully - delivery accepted. "
                    f"Body: {queue_message.body}"
                )
                
            except FutureTimeoutError:
                # Cancel the running handler
                handler_future.cancel()
                self._handle_message_failure(queue_message, msg_id, delivery, "Handler timeout")
                
        except Exception as e:
            self._handle_message_failure(queue_message, msg_id, delivery, str(e))

    def _handle_message_failure(self, queue_message, msg_id, delivery, error_msg):
        """Handle message processing failure with retry logic."""
        logger.error(
            f"[{self.address}] ❌ Error processing message: {error_msg}. "
            f"Body: {queue_message.body}"
        )
        
        # Track delivery attempts
        self.delivery_attempts[msg_id] = self.delivery_attempts.get(msg_id, 0) + 1
        attempt_count = self.delivery_attempts[msg_id]
        
        logger.info(
            f"[{self.address}] Delivery attempt {attempt_count}/{self.max_delivery_attempts} "
            f"for message {msg_id}. Body: {queue_message.body}"
        )
        
        if attempt_count >= self.max_delivery_attempts:
            # Max attempts reached - reject to send to DLQ
            logger.warning(
                f"[{self.address}] Max delivery attempts ({self.max_delivery_attempts}) reached - "
                f"rejecting message to send to DLQ. Body: {queue_message.body}"
            )
            delivery.update(delivery.REJECTED)
            delivery.settle()
            
            # Clear tracking for this message
            del self.delivery_attempts[msg_id]
        else:
            # Release for immediate redelivery
            logger.info(
                f"[{self.address}] Releasing message for immediate redelivery "
                f"(attempt {attempt_count}/{self.max_delivery_attempts}). Body: {queue_message.body}"
            )
            delivery.update(delivery.RELEASED)
            delivery.settle()

    def on_connection_closed(self, event):
        """Called when connection is closed."""
        if self.running:
            logger.warning(f"[{self.address}] Connection closed unexpectedly - will reconnect")
        else:
            logger.info(f"[{self.address}] Connection closed")
        # Stop the container to exit container.run() and allow reconnection
        if event.container:
            event.container.stop()

    def on_disconnected(self, event):
        """Called when disconnected from broker."""
        if self.running:
            logger.warning(f"[{self.address}] Disconnected from broker - will reconnect")
        else:
            logger.info(f"[{self.address}] Disconnected from broker")
        # Stop the container to exit container.run() and allow reconnection
        if event.container:
            event.container.stop()

    def on_transport_error(self, event):
        """Called when there's a transport error."""
        condition = event.transport.condition
        if self.running:
            logger.error(f"[{self.address}] Transport error: {condition} - will reconnect")
        else:
            logger.error(f"[{self.address}] Transport error: {condition}")
        # Stop the container to exit container.run() and allow reconnection
        if event.container:
            event.container.stop()

    def default_handler(self, message: QueueMessage):
        """Default message handler - override with custom handler."""
        logger.info(f"[{self.address}] Processing message with default handler")
        logger.info(f"[{self.address}] Message body: {message.body}")

    def stop(self):
        """Stop the handler."""
        self.running = False

        # Shutdown executor gracefully
        if hasattr(self, 'executor'):
            try:
                logger.debug(f"[{self.address}] Shutting down handler executor...")
                self.executor.shutdown(wait=True, cancel_futures=True)
                logger.debug(f"[{self.address}] Handler executor shut down")
            except Exception as e:
                logger.debug(f"[{self.address}] Error shutting down executor: {e}")

        # Close connection to stop the container
        if self.connection:
            try:
                self.connection.close()
            except Exception as e:
                logger.debug(f"[{self.address}] Error closing connection: {e}")


class QueueConsumer:
    """
    Consumer for a single queue with automatic reconnection using AMQP.

    Features:
    - Configurable acknowledgment modes (auto, client)
    - Manual acknowledgment for reliable retry
    - Automatic reconnection with exponential backoff
    - Immediate message redelivery on failure
    - Survives broker downtime
    - Graceful shutdown
    - Memory efficient

    Acknowledgment mode is read from queue configuration (ack_mode property).
    Supported modes:
    - 'auto' → Auto-acknowledge (at-most-once, no retry)
    - 'client' → Manual acknowledge (at-least-once, RECOMMENDED)
    - anything else → Defaults to 'client'
    """

    def __init__(
        self,
        config: QueueConfig,
        queue_name: str,
        handler: Optional[Callable] = None,
        retry_delay: int = 10,
        max_retry_delay: int = 60
    ):
        """
        Initialize queue consumer.

        Args:
            config: QueueConfig instance
            queue_name: Queue key from config (e.g., 'default', 'chat')
            handler: Optional custom message handler (receives Message object)
            retry_delay: Initial retry delay in seconds (for reconnection)
            max_retry_delay: Maximum retry delay in seconds (for reconnection)
        """
        self.config = config
        self.queue_name = queue_name
        self.handler = handler
        self.retry_delay = retry_delay
        self.max_retry_delay = max_retry_delay
        self.running = False
        self.shutdown_event = threading.Event()
        self.queue_creator = None
        self.queue_full_name = None
        self.connection_url = None
        self.current_handler = None  # Store reference to current handler
        self.ack_mode = None  # Will be set from config during initialization

    def _ensure_queue_exists(self, queue_name: str) -> str:
        """
        Ensure queue exists in broker, create if it doesn't.

        Args:
            queue_name: Queue key from config

        Returns:
            Full queue name

        Raises:
            ValueError: If queue not found in configuration
            ConnectionError: If cannot connect to management API
        """
        if self.queue_creator is None:
            self.queue_creator = QueueCreator(config=self.config)

        queue_config = self.config.get_queue_config(queue_name)
        if not queue_config:
            raise ValueError(
                f"Queue '{queue_name}' not found in configuration. "
                f"Available queues: {', '.join(self.config.get_queue_names())}"
            )

        full_queue_name = queue_config.get('name', queue_name)
        routing_type = queue_config.get('routing_type', 'ANYCAST').upper()

        # Check if queue exists
        if self.queue_creator.queue_exists(full_queue_name, routing_type):
            logger.debug(f"[{queue_name}] Queue '{full_queue_name}' already exists ({routing_type})")
        else:
            # Create queue
            logger.info(f"[{queue_name}] Queue '{full_queue_name}' does not exist, creating...")
            durable = queue_config.get('durable', True)
            auto_delete = queue_config.get('auto_delete', False)
            self.queue_creator.create_queue(full_queue_name, durable, auto_delete, routing_type)
            logger.info(f"[{queue_name}] ✓ Queue created successfully")

        return full_queue_name

    def run(self):
        """
        Run the consumer with automatic reconnection.

        This method blocks until stop() is called or an unrecoverable error occurs.
        """
        logger.info(f"[{self.queue_name}] Starting consumer...")

        # Ensure queue exists
        try:
            self.queue_full_name = self._ensure_queue_exists(self.queue_name)
        except Exception as e:
            logger.error(f"[{self.queue_name}] Failed to ensure queue exists: {e}")
            raise

        # Get acknowledgement mode from config
        queue_config = self.config.get_queue_config(self.queue_name)
        self.ack_mode = queue_config.get('ack_mode', 'client')

        # Validate and normalize ack_mode
        valid_modes = ['auto', 'client']
        if self.ack_mode not in valid_modes:
            logger.warning(
                f"[{self.queue_name}] Invalid ack_mode '{self.ack_mode}' in config. "
                f"Valid values: {', '.join(valid_modes)}. Defaulting to 'client'."
            )
            self.ack_mode = 'client'

        logger.info(f"[{self.queue_name}] Using acknowledgment mode: {self.ack_mode}")

        # Build AMQP connection URL
        credentials = self.config.get_credentials()
        self.connection_url = (
            f"amqp://{credentials['username']}:{credentials['password']}"
            f"@{self.config.host}:{self.config.port}"
        )

        self.running = True
        current_retry_delay = self.retry_delay

        while self.running and not self.shutdown_event.is_set():
            try:
                logger.info(f"[{self.queue_name}] Connecting to {self.config.host}:{self.config.port}...")

                delivery_attempts = self.current_handler.delivery_attempts if self.current_handler else {}

                # Get handler timeout from queue config
                handler_timeout_seconds = self.config.get_queue_handler_timeout(self.queue_name)

                # Create handler and container
                self.current_handler = MessageHandler(
                    url=self.connection_url,
                    address=self.queue_full_name,
                    handler=self.handler,
                    consumer=self,
                    ack_mode=self.ack_mode,
                    delivery_attempts=delivery_attempts,
                    handler_timeout_seconds=handler_timeout_seconds
                )

                # Run container (blocks until connection closes)
                container = Container(self.current_handler)
                container.run()

                # If we get here, connection closed gracefully
                if not self.running:
                    logger.info(f"[{self.queue_name}] Consumer stopped gracefully")
                    break

                # Connection closed unexpectedly - retry
                logger.warning(f"[{self.queue_name}] Connection closed, reconnecting in {current_retry_delay}s...")
                time.sleep(current_retry_delay)

                # Exponential backoff
                current_retry_delay = min(current_retry_delay * 2, self.max_retry_delay)

            except KeyboardInterrupt:
                logger.info(f"\n[{self.queue_name}] Received interrupt signal")
                self.stop()
                break

            except Exception as e:
                if not self.running:
                    break

                logger.error(f"[{self.queue_name}] Error in consumer: {e}", exc_info=True)
                logger.info(f"[{self.queue_name}] Reconnecting in {current_retry_delay}s...")
                time.sleep(current_retry_delay)

                # Exponential backoff
                current_retry_delay = min(current_retry_delay * 2, self.max_retry_delay)

        logger.info(f"[{self.queue_name}] ✓ Consumer stopped")

    def stop(self):
        """Stop the consumer gracefully."""
        logger.info(f"[{self.queue_name}] Stopping consumer...")
        self.running = False
        self.shutdown_event.set()

        # Stop the current handler to close the connection
        if self.current_handler:
            self.current_handler.stop()

