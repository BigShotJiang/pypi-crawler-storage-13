"""
Test suite for PyCompTox.
"""
