import sys
import tempfile
from pathlib import Path
import xml.etree.ElementTree as ET
from .md2json import parse_to_model

def main():
    if len(sys.argv) < 3:
        print('Usage: python -m hos_m2f.md2xml <input.md> <output.xml>')
        sys.exit(1)
    inp = Path(sys.argv[1])
    outp = Path(sys.argv[2])
    text = inp.read_text(encoding='utf-8')
    with tempfile.TemporaryDirectory() as td:
        model = parse_to_model(text, Path(td))
        root = ET.Element('document')
        for b in model['blocks']:
            t = b['type']
            if t == 'heading':
                e = ET.SubElement(root, 'heading')
                e.set('level', str(b.get('level', 1)))
                e.text = b.get('text', '')
            elif t == 'text':
                e = ET.SubElement(root, 'paragraph')
                e.text = b.get('text', '')
            elif t == 'code':
                e = ET.SubElement(root, 'code')
                e.set('lang', b.get('lang',''))
                e.text = b.get('text','')
            elif t == 'image':
                e = ET.SubElement(root, 'image')
                e.set('kind', b.get('kind',''))
                e.set('path', b.get('path',''))
            elif t == 'table':
                e = ET.SubElement(root, 'table')
                h = ET.SubElement(e, 'header')
                for c in b.get('header',[]):
                    ET.SubElement(h,'cell').text = c
                body = ET.SubElement(e,'body')
                for r in b.get('rows',[]):
                    row = ET.SubElement(body,'row')
                    for c in r:
                        ET.SubElement(row,'cell').text = c
            elif t == 'anchor':
                e = ET.SubElement(root, 'anchor')
                e.set('name', b.get('name',''))
            elif t == 'list':
                e = ET.SubElement(root, 'list')
                e.set('kind', b.get('kind',''))
                e.text = b.get('text','')
        tree = ET.ElementTree(root)
        ET.indent(tree, space='  ')
        tree.write(str(outp), encoding='utf-8', xml_declaration=True)
    print(f'Converted to XML: {inp} -> {outp}')

if __name__ == '__main__':
    main()

