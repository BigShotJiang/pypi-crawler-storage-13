from random import randint

def encrypt(text):
    tmp = 0
    encypted_text = ""
    
    for i in range(len(text)):
        if tmp == 0:
            encypted_text = encypted_text + chr(randint(33, 126))
            encypted_text = encypted_text + chr(ord(text[i]) + 1)
            
            tmp = tmp + 1
        else:
            encypted_text = encypted_text + chr(ord(text[i]) + 1)
            tmp = tmp - 1
    return encypted_text


            