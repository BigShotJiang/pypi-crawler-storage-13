# LatentSense Python SDK

## Overview

The LatentSense Python SDK provides a convenient client for interacting with the Latentsense Interactive API. It simplifies authentication, file uploads, and requests to various API endpoints for text analysis and manipulation.

## Installation

`pip install latentsense-sdk`

## Configuration

The client can be configured by passing parameters to its constructor or by using environment variables.

### Constructor Arguments
You can initialize the client directly with your credentials:
```python
from latentsense_sdk import LatentSenseClient

client = LatentSenseClient(
    project_id="your-project-id",
    api_key="your-api-key",
)
```

### Environment Variables
If constructor arguments are not provided, the client will fall back to reading from environment variables:

- `LST_PROJECT_ID`: Your LatentSense project ID.
- `LST_API_KEY`: Your LatentSense API key.

For example, in your shell:
```bash
export LST_PROJECT_ID="your-project-id"
export LST_API_KEY="your-api-key"
```

## Usage

See `https://docs.latentsense.com`

Here's a basic example of how to initialize the client and use it to redact Personally Identifiable Information (PII) from a document.

```python
import os
from latentsense_sdk import LatentSenseClient

# The client is configured via environment variables.
# Ensure they are set before running, for example:
# os.environ["LST_PROJECT_ID"] = "your-project-id"
# os.environ["LST_API_KEY"] = "your-api-key"

client = LatentSenseClient()

# Example 1: Redact PII from a file on disk
try:
    with open("document.txt", "w") as f:
        f.write("John Doe lives at 123 Main St. His email is john.doe@example.com.")

    files_to_redact = ["document.txt"]
    redacted_results = client.redact_pii(files=files_to_redact)

    for result in redacted_results:
        print(f"--- Results for {result.original_file_name} ---")
        print(f"Redacted text: {result.redacted_text}")

finally:
    if os.path.exists("document.txt"):
        os.remove("document.txt")


# Example 2: Redact PII from in-memory content
in_memory_file = ("report.txt", "This is a report about Jane Smith.")
redacted_results = client.redact_pii(files=[in_memory_file])

for result in redacted_results:
    print(f"--- Results for {result.original_file_name} ---")
    print(f"Redacted text: {result.redacted_text}")

```
