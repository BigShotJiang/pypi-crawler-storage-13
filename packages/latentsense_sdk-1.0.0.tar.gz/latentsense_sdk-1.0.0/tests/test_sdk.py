from dotenv import load_dotenv

load_dotenv(dotenv_path="tests/.env")

from src.latentsense_sdk.ls_shared.redaction_shared import (
    RedactionFileAnalysisWithOriginal,
)
from src.latentsense_sdk.ls_shared.rels_shared import (
    ReasonerXFileAnalysisWithOriginal,
    AiRexMessage,
    RelsFileAnalysisWithOriginal,
)
from src.latentsense_sdk import LatentSenseClient


def test_create_rex_map():
    """
    Tests that the create_rex_map function returns a valid response.
    """
    client = LatentSenseClient()
    sample_file = ("sample.txt", "This is a test file for Rex map creation.")

    response = client.create_rex_map(files=[sample_file], concepts=["fruit", "loops"])

    assert isinstance(response, list)
    assert len(response) == 1
    assert isinstance(response[0], ReasonerXFileAnalysisWithOriginal)
    assert response[0].file.name == "sample.txt"


def test_create_rex_message():
    """
    Tests that the create_rex_message function returns a valid response.
    """
    client = LatentSenseClient()
    sample_file = (
        "sample.txt",
        "This is a test file for Rex map creation. Apples are a type of fruit.",
    )

    rex_map_response = client.create_rex_map(files=[sample_file], concepts=["fruit"])
    run_id = rex_map_response[0].runId

    message = "What is a type of fruit?"
    response = client.create_rex_message(message=message, run_id=run_id)

    assert isinstance(response, AiRexMessage)
    assert isinstance(response.text, str)
    assert len(response.text) > 0


def test_get_salient_relationships():
    """
    Tests that the get_salient_relationships function returns a valid response.
    """
    client = LatentSenseClient()
    sample_file = ("sample.txt", "This is a test file for salient relationships.")
    response = client.get_salient_relationships(files=[sample_file], intent_text="test")
    assert isinstance(response, list)
    assert len(response) == 1
    assert isinstance(response[0], RelsFileAnalysisWithOriginal)
    assert response[0].file.name == "sample.txt"


def test_redact_by_relevance():
    """
    Tests that the redact_by_relevance function returns a valid response.
    """
    client = LatentSenseClient()
    sample_file = ("sample.txt", "This is a test file for relevance redaction.")
    response = client.redact_by_relevance(
        files=[sample_file], relevance_term="test", cutoff=0.5
    )
    assert isinstance(response, list)
    assert len(response) == 1
    assert isinstance(response[0], RedactionFileAnalysisWithOriginal)
    assert response[0].file.name == "sample.txt"


def test_redact_pii():
    """
    Tests that the redact_pii function returns a valid response.
    """
    client = LatentSenseClient()
    sample_file = (
        "sample.txt",
        "This is a test file for PII redaction. My name is John Doe.",
    )
    response = client.redact_pii(files=[sample_file])
    assert isinstance(response, list)
    assert len(response) == 1
    assert isinstance(response[0], RedactionFileAnalysisWithOriginal)
    assert response[0].file.name == "sample.txt"
