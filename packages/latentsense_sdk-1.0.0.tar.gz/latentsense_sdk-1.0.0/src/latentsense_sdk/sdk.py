import os

import requests
from typing import List, Optional, Any, Union, Tuple, IO, Dict, Literal

from .ls_shared.redaction_shared import RedactionFileAnalysisWithOriginal
from .ls_shared.rels_shared import (
    ReasonerXFileAnalysisWithOriginal,
    RelsFileAnalysisWithOriginal,
    AiRexMessage,
)


FileInput = Union[str, Tuple[str, str]]


class LatentSenseClient:
    """
    A Python client for the Latentsense Interactive API.

    This client handles authentication, project ID, and the complexities
    of file uploads, supporting both file paths and in-memory string content.
    """

    def __init__(
        self,
        project_id: Optional[str] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        self.project_id = project_id or os.environ.get("LST_PROJECT_ID")
        self.api_key = api_key or os.environ.get("LST_API_KEY")

        if not self.project_id:
            raise ValueError(
                "Project ID must be provided or set as LST_PROJECT_ID environment variable."
            )
        if not self.api_key:
            raise ValueError(
                "API key must be provided or set as LST_API_KEY environment variable."
            )

        self.base_url = base_url or os.environ.get(
            "LST_API_BASE_URL", "https://controller.latentsense.com"
        )
        self._session = requests.Session()
        self._session.headers.update(
            {"x-api-key": self.api_key, "Accept": "application/json"}
        )

    def _prepare_payload(self, **file_parts) -> Tuple[List[tuple], List[IO]]:
        """Prepares the multipart/form-data payload and tracks opened files."""
        multipart_payload = []
        opened_files = []

        def add_to_payload(part_name: str, file_input: FileInput):
            if isinstance(file_input, str):  # Input is a file path
                # Open the file and add its object to the tracking list
                f = open(file_input, "rb")
                opened_files.append(f)
                multipart_payload.append(
                    (part_name, (os.path.basename(file_input), f, "text/plain"))
                )
            elif (
                isinstance(file_input, tuple) and len(file_input) == 2
            ):  # Input is (filename, content)
                filename, content = file_input
                # Content can be passed directly
                multipart_payload.append((part_name, (filename, content, "text/plain")))
            else:
                raise TypeError(
                    f"Invalid file input type for '{part_name}': {file_input}. Must be a path (str) or a (filename, content) tuple."
                )

        for part_name, file_inputs in file_parts.items():
            if not file_inputs:
                continue

            if isinstance(file_inputs, list):
                for file_input in file_inputs:
                    add_to_payload(part_name, file_input)
            else:
                add_to_payload(part_name, file_inputs)

        return multipart_payload, opened_files

    def create_rex_map(
        self,
        files: List[FileInput],
        concepts: Optional[List[str]] = None,
        files_for_comparison: Optional[List[FileInput]] = None,
        files1_name: str = "set_1",
        files2_name: str = "set_2",
    ) -> List[ReasonerXFileAnalysisWithOriginal]:
        """
        Creates a Rex knowledge map to analyze the files.
        This is useful for breaking down large texts into facts for later analysis, summary, or question answering.
        LLM analysis of the map can be created with `create_rex_message`

        Each file can be provided as:
        - A string representing the file path (e.g., "my_docs/report.txt").
        - A tuple of (filename, content) (e.g., ("report.txt", "This is my content...")).

        files: A list of primary files to be analyzed.
        concepts: Optional list of terms expected to be existing nodes in the map.
            Particularly useful if you already have a map or list of nodes and want
            the new map to be compatible.
        files_for_comparison: Optional list of a second set of files for comparison.
            Edges from this file set will be labelled differently from `files`.
        files1_name: The name for the primary file set in the response.
        files2_name: The name for the comparison file set in the response.
        """
        endpoint = f"{self.base_url}/{self.project_id}/rex-map"
        opened_files = []

        try:
            file_parts = {"files": files, "files2": files_for_comparison}
            if concepts:
                joined_concepts = ",".join(concepts)
            else:
                joined_concepts = ""
            file_parts["concepts"] = ("concepts.txt", joined_concepts)

            multipart_payload, opened_files = self._prepare_payload(**file_parts)

            data_payload = {"files1_name": files1_name, "files2_name": files2_name}
            if concepts:
                data_payload["concepts"] = concepts

            json_response = self._session.post(
                endpoint, files=multipart_payload, data=data_payload
            )
            response = [
                ReasonerXFileAnalysisWithOriginal.parse_obj(obj)
                for obj in json_response.json()
            ]
            return response
        finally:
            for f in opened_files:
                f.close()

    def create_message(
        self, messages: List[Dict[Literal["role", "content"], str]]
    ) -> str:
        """
        Sends the given messages and returns the llm response.

        This is used for interacting with the chat model in a conversational manner.
        Prompt the LLM as you would ask yourself the question. System messages are rarely needed.
        If processing many items, batching is more efficient.

        messages: A list of message objects.
                  Example: [{"role": "user", "content": "Hello, world!"}]
        """
        endpoint = f"{self.base_url}/api/chat/{self.project_id}/message"

        response = self._session.post(endpoint, json=messages)
        response.raise_for_status()
        # The response body is a JSON-encoded string, e.g., "Hello back"
        return response.json()

    def get_salient_relationships(
        self, files: List[FileInput], intent_text: str = None
    ) -> List[RelsFileAnalysisWithOriginal]:
        """
        Lists relationship propositions in the documents that are deemed salient
        and relevant to the intent text.

        Relationships are (subject, predicate, object) triplets. Each has a salience
        score (how much it stands out) and a relevance score (how relevant it is
        to the intent text). This is a paid endpoint.

        files: A list of files to be analyzed. Each file can be a path (str)
               or a (filename, content) tuple.
        intent_text (optional): Text to check for relevance against (e.g., a term, concept, or phrase).
        """
        endpoint = f"{self.base_url}/{self.project_id}/salient-relationships"
        opened_files = []
        try:
            file_parts = {"files": files}
            if intent_text is None:
                intent_text = ""
            file_parts["claim_concepts"] = ("claim_concepts.txt", intent_text)

            multipart_payload, opened_files = self._prepare_payload(**file_parts)

            data_payload = {"intent_text": intent_text}

            response = self._session.post(
                endpoint, files=multipart_payload, data=data_payload
            )
            response.raise_for_status()
            return [
                RelsFileAnalysisWithOriginal.parse_obj(obj) for obj in response.json()
            ]
        finally:
            for f in opened_files:
                f.close()

    def create_rex_message(
        self, message: str, run_id: str, graph_info: Optional[Dict[str, Any]] = None
    ) -> AiRexMessage:
        """
        Sends a message to a specific ReasonerX (Rex) graph session to get a response.

        message: The message/question to send to the graph.
        run_id: The ID of the Rex graph run to interact with. This is found
                as `runId` for each file in the response from `create_rex_map`.
        """
        endpoint = f"{self.base_url}/api/chat/{self.project_id}/rex-message"
        params = {
            "message": message,
            "run_id": run_id,
        }

        response = self._session.post(endpoint, params=params, json=graph_info)
        response.raise_for_status()
        return AiRexMessage.parse_obj(response.json())

    def redact_by_relevance(
        self, files: List[FileInput], relevance_term: str, cutoff: float
    ) -> List[RedactionFileAnalysisWithOriginal]:
        """
        Removes information from documents that is relevant to a given term.

        You can tune how much text is redacted with the `cutoff` parameter. A value
        closer to 0 will redact more, and a value closer to 1 will redact less.
        It is usually assumed that any subsequent work will use the redacted version of
        the text to avoid information leakage.
        This is a paid endpoint.

        files: A list of files to be redacted. Each file can be a path (str)
               or a (filename, content) tuple.
        relevance_term: The concept, term, or phrase to redact.
        cutoff: A number between 0 and 1 to control redaction sensitivity.
        """
        endpoint = f"{self.base_url}/{self.project_id}/redact-relevance"
        params = {"cutoff": cutoff}
        opened_files = []
        try:
            file_parts = {
                "files": files,
                "relevance_term": ("relevance_term.txt", relevance_term),
            }
            multipart_payload, opened_files = self._prepare_payload(**file_parts)

            response = self._session.post(
                endpoint, params=params, files=multipart_payload
            )
            response.raise_for_status()
            return [
                RedactionFileAnalysisWithOriginal.parse_obj(obj)
                for obj in response.json()
            ]
        finally:
            for f in opened_files:
                f.close()

    def redact_pii(
        self, files: List[FileInput]
    ) -> List[RedactionFileAnalysisWithOriginal]:
        """
        Redacts PII (Personally Identifiable Information) from documents.

        Removes names, dates, addresses, contact info, etc., to make sensitive
        documents safer for sharing or analysis.
        It is usually assumed that any subsequent work will use the redacted version of
        the text to avoid information leakage.
        This is a paid endpoint.

        files: A list of files to be redacted. Each file can be a path (str)
               or a (filename, content) tuple.
        """
        endpoint = f"{self.base_url}/{self.project_id}/redact-pii"
        opened_files = []
        try:
            multipart_payload, opened_files = self._prepare_payload(files=files)

            response = self._session.post(endpoint, files=multipart_payload)
            response.raise_for_status()
            return [
                RedactionFileAnalysisWithOriginal.parse_obj(obj)
                for obj in response.json()
            ]
        finally:
            for f in opened_files:
                f.close()
