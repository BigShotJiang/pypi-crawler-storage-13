from typing import List, Union

import pydantic
from .base import SimpleTextFile
from .segments import Segment


class SpanIsAiAnalysis(pydantic.BaseModel):
    id: int
    segment: Segment
    probability_ai: float


class AnalysisForFile(pydantic.BaseModel):
    spanAnalyses: List[Union[Segment, SpanIsAiAnalysis]]
    probability_ai: float


class FileIsAiAnalysis(pydantic.BaseModel):
    file: SimpleTextFile
    analyses: AnalysisForFile


class FileIsAiAnalysisWithOriginal(FileIsAiAnalysis):
    runId: str
    originalBytes: str
