/// Example tools demonstrating external system integration

pub mod weather_api;
pub mod math;

pub use weather_api::WeatherApiTool;
pub use math::SimpleMathTool;

