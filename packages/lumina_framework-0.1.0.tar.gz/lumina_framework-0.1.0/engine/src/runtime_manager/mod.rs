/// Runtime utilities for concurrency management
/// 
/// This module provides:
/// - Shared Tokio runtime manager (for Python bindings)
/// - Task scheduling utilities
/// - Concurrency primitives

pub mod manager;

pub use manager::{
    init_runtime,
    get_runtime_handle,
    try_get_runtime_handle,
    is_runtime_initialized,
    spawn,
    spawn_blocking,
};

