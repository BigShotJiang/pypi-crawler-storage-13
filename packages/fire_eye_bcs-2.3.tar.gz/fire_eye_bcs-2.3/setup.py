import io
from setuptools import setup, find_packages
try:
    with io.open("README.md", "r", encoding="utf-8") as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = "A powerful tool by BANGLADESH CYBER SQUAD for cybersecurity tasks."

setup(
    name="fire-eye-BCS",
    version="2.3",
    packages=find_packages(),
    install_requires=[
        "requests",
        "aiohttp",
        "rich",
    ],
    entry_points={
        "console_scripts": [
            "fire-eye=fire_eye.main:run"
        ]
    },
    author="BANGLADESH CYBER SQUAD",
    description="A powerful tool by BANGLADESH CYBER SQUAD",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/TEAMBCS/Fire-Eye.git",
    license="MIT License",
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Security",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
)
