
import asyncio
import os
from pathlib import Path

from agi_cluster.agi_distributor import AGI
from agi_env import AgiEnv


def _resolve_apps_dir() -> Path:
    apps_dir_env = os.environ.get("APPS_DIR")
    if apps_dir_env:
        return Path(apps_dir_env).expanduser().resolve()
    return Path(__file__).resolve().parents[2] / "apps"


APPS_DIR = str(_resolve_apps_dir())
APP = "link_sim_project"

async def main():
    app_env = AgiEnv(apps_dir=APPS_DIR, app=APP, verbose=1)
    res = await AGI.install(app_env, 
                            modes_enabled=15,
                            scheduler="192.168.20.111", 
                            workers={'192.168.20.111': 1, '192.168.20.130': 1})
    print(res)
    return res

if __name__ == "__main__":
    asyncio.get_event_loop().run_until_complete(main())
