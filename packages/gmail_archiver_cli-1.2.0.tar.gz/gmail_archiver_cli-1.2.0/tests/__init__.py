"""Tests for Gmail Archiver."""
