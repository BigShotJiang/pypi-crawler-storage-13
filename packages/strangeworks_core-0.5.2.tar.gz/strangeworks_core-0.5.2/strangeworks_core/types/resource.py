"""resource.py."""

import json
from enum import Enum
from typing import Any, Dict, Optional

from pydantic import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    Field,
    JsonValue,
    model_validator,
)
from typing_extensions import Self

from strangeworks_core.types.product import Product


class KeyType(str, Enum):
    """Enum to specify key type."""

    BOOL = "BOOL"
    STRING = "STRING"
    SECURE = "SECURE"
    INT = "INT"
    FLOAT = "FLOAT"
    JSON = "JSON"


class ResourceConfiguration(BaseModel):
    """Configuration Key-Value Pair Attached to a Resource.

    Returns
    -------
    ResourceConfiguration
    """

    # use the alias to serialize so that the value_type field shows up as `type`
    # in model_jump output.
    model_config = ConfigDict(serialize_by_alias=True)

    key: str
    value_type: KeyType = Field(
        validation_alias=AliasChoices("type", "value_type", "valueType"),
        serialization_alias="type",
    )
    valueString: str | None = None
    valueJson: JsonValue | None = None
    valueSecure: str | None = None
    valueFloat: float | None = None
    valueInt: int | None = None
    valueBool: bool | None = None
    is_editable: bool = True
    is_internal: bool = False

    @model_validator(mode="before")
    def convert_value_json(cls, values):
        """Handle JSON as string values."""
        # Convert string valueJson to dict if needed
        if isinstance(values, dict) and "valueJson" in values:
            value_json = values["valueJson"]
            if isinstance(value_json, str):
                try:
                    values["valueJson"] = json.loads(value_json)
                except json.JSONDecodeError:
                    raise ValueError(
                        "valueJson not valid JSON object. Use valueString for regular string values."  # noqa
                    )
        return values

    @model_validator(mode="after")
    def check_values(self) -> Self:
        """Validate object.

        Verifies that there is a value present for the given type.
        """
        if self.value_type == KeyType.STRING and self.valueString is None:
            raise ValueError("valueString must be specified")
        if self.value_type == KeyType.BOOL and self.valueBool is None:
            raise ValueError("valueBool must be specified")
        if self.value_type == KeyType.JSON and self.valueJson is None:
            raise ValueError("valueJson must be specifed")
        if self.value_type == KeyType.SECURE and self.valueSecure is None:
            raise ValueError("valueSecure must be specified")
        if self.value_type == KeyType.INT and self.valueInt is None:
            raise ValueError("valueInt must be specifed")
        if self.value_type == KeyType.FLOAT and self.valueFloat is None:
            raise ValueError("valueFloat must be specified")
        return self

    @property
    def value(self) -> JsonValue:
        """Return the value of the"""
        if self.value_type == KeyType.BOOL:
            return self.valueJson
        if self.value_type == KeyType.STRING:
            return self.valueString
        if self.value_type == KeyType.FLOAT:
            return self.valueFloat
        if self.value_type == KeyType.INT:
            return self.valueInt
        if self.value_type == KeyType.SECURE:
            return self.valueSecure
        if self.value_type == KeyType.JSON:
            return self.valueJson


class Resource(BaseModel):
    """Represents a Platform Resource object.

    Attributes
    ----------
    slug: str
        User-friendly identifier.
    resource_id: Optional[str]
        Internal identifier.
    status: Optional[str]
        Status of the resource.
    name: Optional[str]
        Resource name
    is_deleted: Optional[bool]
        Indicates whether resource has been deleted.
    product: Optional[Product]
        Product object associated with the resource.
    """

    slug: str
    resource_id: Optional[str] = Field(
        default=None, validation_alias=AliasChoices("id", "resource_id")
    )
    status: Optional[str] = None
    name: Optional[str] = None
    is_deleted: Optional[bool] = Field(
        default=None, validation_alias=AliasChoices("is_deleted", "isDeleted")
    )
    product: Optional[Product] = None
    configurations: Optional[list[ResourceConfiguration]] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Resource":
        """Generate a Resource object from a dictionary.

        The key names in the dictionary must match field names as specified by the
        GraphQL schema for Resource.

        Parameters
        ----------
        cls
            Class that will be instantiated.
        d: Dict
            Resource object attributes represented as a dictionary.

        Return
        ------
        An intance of the Resource object.
        """
        return cls(**d)

    def proxy_url(
        self,
        path: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> str:
        """Return the proxy URL for the resource.

        Parameters
        ----------
        path: Optional[str]
            additional path to append to the proxy url. Defaults to None.

        base_url: Optional[str]
            base url (for example, https://api.strangeworks.com) to use for the proxy
            url. Defaults to None.

        Returns
        ------
        str:
           url that the proxy will use to make calls to the resource.
        """

        _proxy_url = (
            f"/products/{self.product.slug}/resource/{self.slug}/"
            if path is None
            else f"/products/{self.product.slug}/resource/{self.slug}/{path.strip('/')}"
        )
        return _proxy_url if base_url is None else f"{base_url.strip('/')}{_proxy_url}"
