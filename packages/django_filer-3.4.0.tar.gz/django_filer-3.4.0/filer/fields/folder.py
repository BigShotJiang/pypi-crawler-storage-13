import warnings

from django import forms
from django.contrib.admin.sites import site
from django.contrib.admin.widgets import ForeignKeyRawIdWidget
from django.core.exceptions import ObjectDoesNotExist
from django.db import models
from django.template.loader import render_to_string
from django.urls import reverse
from django.utils.http import urlencode
from django.utils.safestring import mark_safe

from ..models import Folder
from ..settings import ICON_CSS_LIB
from ..utils.compatibility import truncate_words
from ..utils.model_label import get_model_label


class AdminFolderWidget(ForeignKeyRawIdWidget):
    choices = None
    input_type = "hidden"
    is_hidden = False

    def render(self, name, value, attrs=None, renderer=None):
        obj = self.obj_for_value(value)
        css_id = attrs.get("id")
        css_id_folder = "%s_folder" % css_id
        css_id_description_txt = "%s_description_txt" % css_id
        if attrs is None:
            attrs = {}
        related_url = None

        if value:
            try:
                folder = Folder.objects.get(pk=value)
                related_url = folder.get_admin_directory_listing_url_path()
            except Exception:
                pass
        if not related_url:
            related_url = reverse("admin:filer-directory_listing-last")
        params = self.url_parameters()
        params["_pick"] = "folder"
        if params:
            url = "?" + urlencode(sorted(params.items()))
        else:
            url = ""
        if "class" not in attrs:
            # The JavaScript looks for this hook.
            attrs["class"] = "vForeignKeyRawIdAdminField"
        super_attrs = attrs.copy()
        hidden_input = super(ForeignKeyRawIdWidget, self).render(
            name, value, super_attrs
        )  # grandparent super

        # TODO: "id_" is hard-coded here. This should instead use the correct
        # API to determine the ID dynamically.
        context = {
            "hidden_input": hidden_input,
            "lookup_url": f"{related_url}{url}",
            "lookup_name": name,
            "span_id": css_id_description_txt,
            "object": obj,
            "clear_id": "%s_clear" % css_id,
            "descid": css_id_description_txt,
            "foldid": css_id_folder,
            "id": css_id,
        }
        html = render_to_string("admin/filer/widgets/admin_folder.html", context)
        return mark_safe(html)

    def label_for_value(self, value):
        obj = self.obj_for_value(value)
        return "&nbsp;<strong>%s</strong>" % truncate_words(obj, 14)

    def obj_for_value(self, value):
        if not value:
            return None
        try:
            key = self.rel.get_related_field().name
            obj = self.rel.model._default_manager.get(**{key: value})
        except ObjectDoesNotExist:
            obj = None
        return obj

    class Media:
        css = {"all": ("filer/css/admin_filer.css",) + ICON_CSS_LIB}
        js = (
            "filer/js/addons/popup_handling.js",
            "filer/js/widgets/admin-folder-widget.js",
        )


class AdminFolderFormField(forms.ModelChoiceField):
    widget = AdminFolderWidget

    def __init__(self, rel, queryset, to_field_name, *args, **kwargs):
        self.rel = rel
        self.queryset = queryset
        self.limit_choices_to = kwargs.pop("limit_choices_to", None)
        self.to_field_name = to_field_name
        self.max_value = None
        self.min_value = None
        kwargs.pop("widget", None)
        kwargs.pop("blank", None)
        forms.Field.__init__(self, widget=self.widget(rel, site), *args, **kwargs)

    def widget_attrs(self, widget):
        widget.required = self.required
        return {}


class FilerFolderField(models.ForeignKey):
    default_form_class = AdminFolderFormField
    default_model_class = Folder

    def __init__(self, **kwargs):
        # We hard-code the `to` argument for ForeignKey.__init__
        dfl = get_model_label(self.default_model_class)
        if "to" in kwargs.keys():  # pragma: no cover
            old_to = get_model_label(kwargs.pop("to"))
            if old_to.lower() != dfl.lower():
                msg = "{} can only be a ForeignKey to {}; {} passed".format(
                    self.__class__.__name__, dfl, old_to
                )
                warnings.warn(msg, SyntaxWarning)
        kwargs["to"] = dfl
        super().__init__(**kwargs)

    def formfield(self, **kwargs):
        defaults = {
            "form_class": self.default_form_class,
            "rel": self.remote_field,
        }
        defaults.update(kwargs)
        return super().formfield(**defaults)
