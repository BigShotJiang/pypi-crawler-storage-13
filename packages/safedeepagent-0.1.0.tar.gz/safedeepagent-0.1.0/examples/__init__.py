"""DeepAgent examples"""
