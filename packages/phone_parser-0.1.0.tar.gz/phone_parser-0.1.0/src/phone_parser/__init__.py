from .core import get_phone_info, parse_phone_info

__version__ = "0.1.0"
__all__ = ['get_phone_info', 'parse_phone_info']