import json
import phonenumbers
from phonenumbers import carrier
import os

def _load_codes_data():
    current_dir = os.path.dirname(__file__)
    data_path = os.path.join(current_dir, 'data', 'codes.json')
    
    with open(data_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def parse_phone_info(phone_number):
    try:
        phone_str = str(phone_number).replace('+', '').replace(' ', '')
        
        codes_data = _load_codes_data()
        best_match = None
        
        for code_info in codes_data[1:]:
            code = code_info["Код"].replace('+', '').replace(' ', '')
            if phone_str.startswith(code):
                if best_match is None or len(code) > len(best_match["code"]):
                    best_match = {
                        "code": code,
                        "operator": code_info.get("Оператор", ""),
                        "region": code_info.get("Регион", ""),
                        "city": code_info.get("Город", "")
                    }
        
        if best_match:
            operator = best_match["operator"]
            region = best_match["region"]
            city = best_match["city"]
            
            location_parts = []
            if region and region.strip():
                location_parts.append(region.strip())
            if city and city.strip():
                location_parts.append(city.strip())
            
            location = ", ".join(location_parts) if location_parts else "Неизвестно"
            
            if not operator or not operator.strip():
                parsed_number = phonenumbers.parse("+" + phone_str, "RU")
                operator = carrier.name_for_number(parsed_number, "ru") or "Неизвестно"
            
            return operator.strip(), location, "Россия"
        
        parsed_number = phonenumbers.parse("+" + phone_str, "RU")
        operator = carrier.name_for_number(parsed_number, "ru") or "Неизвестно"
        return operator, "Неизвестно", "Россия"
        
    except Exception as e:
        return "Неизвестно", "Неизвестно", "Россия"

def get_phone_info(phone_number):
    return parse_phone_info(phone_number)