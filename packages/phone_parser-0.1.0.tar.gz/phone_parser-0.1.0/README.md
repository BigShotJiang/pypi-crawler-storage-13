# Phone Parser

Библиотека для парсинга российских номеров телефона.

## Установка

```bash
pip install phone-parser
```
