import pandas as pd
from importlib import resources

def load_data():
    try:
        with resources.path("neuroaihub", "NeuroAIHub_Database.xlsx") as db_path:
            xls = pd.ExcelFile(db_path, engine="openpyxl")
    except FileNotFoundError:
        raise FileNotFoundError("NeuroAIHub_Database.xlsx not found in package.")

    sheet_names = xls.sheet_names
    dataframes = {
        sheet: pd.read_excel(xls, sheet_name=sheet).assign(category=sheet)
        for sheet in sheet_names
    }

    combined_df = pd.concat(dataframes.values(), ignore_index=True)

    cols = [
        "year", "access_type", "institution", "country", "modality", "resolution",
        "subject_no", "slice_scan_no", "age_range", "disease", "segmentation_mask",
        "healthy_control", "staging_information", "clinical_data_score",
        "histopathology", "lab_data"
    ]
    for c in cols:
        if c in combined_df.columns:
            combined_df[c] = (
                combined_df[c].astype(str)
                .replace("nan", "", regex=False)
                .fillna("")
            )
            combined_df[f"{c}_clean"] = (
                combined_df[c]
                .str.replace(r"\s*\(.*\)", "", regex=True)
                .str.strip()
            )

    for c in ["year_clean", "subject_no_clean", "slice_scan_no_clean"]:
        if c in combined_df.columns:
            combined_df[c] = pd.to_numeric(combined_df[c], errors="coerce")

    return dataframes, combined_df, sheet_names
