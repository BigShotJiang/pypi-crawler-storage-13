from .speed_viterbi import *

__doc__ = speed_viterbi.__doc__
if hasattr(speed_viterbi, "__all__"):
    __all__ = speed_viterbi.__all__