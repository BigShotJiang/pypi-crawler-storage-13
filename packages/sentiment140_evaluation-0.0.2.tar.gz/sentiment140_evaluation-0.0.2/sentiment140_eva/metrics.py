"""
Metrics Calculator
==================

This module provides utilities for calculating evaluation metrics.
"""

import logging
from typing import Any, Dict, List

import numpy as np
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix, f1_score, precision_score,
                             recall_score)

logger = logging.getLogger(__name__)


class MetricsCalculator:
    """
    Calculates various evaluation metrics for classification models.
    """

    LABEL_MAP = {0: "negative", 2: "neutral", 4: "positive"}

    def __init__(self, label_names: List[str] = None):
        """
        Initialize the metrics calculator.

        Args:
            label_names: List of label names (e.g., ['negative', 'positive'])
        """
        self.label_names = label_names

    def calculate_metrics(
        self, y_true: np.ndarray, y_pred: np.ndarray
    ) -> Dict[str, Any]:
        """
        Calculate comprehensive evaluation metrics.

        Args:
            y_true: True labels
            y_pred: Predicted labels

        Returns:
            Dictionary containing various metrics
        """
        logger.info("Calculating evaluation metrics...")

        # Basic metrics
        accuracy = accuracy_score(y_true, y_pred)

        # Determine average type based on number of classes
        n_classes = len(np.unique(y_true))
        unique_labels = sorted(np.unique(np.concatenate([y_true, y_pred])))

        # Use 'macro' for multi-class or when labels are not 0/1
        # This handles Sentiment140's 0,4 labels correctly
        if n_classes == 2 and set(unique_labels) == {0, 1}:
            average = "binary"
            pos_label = 1
        else:
            average = "macro"
            pos_label = None

        # Calculate metrics with appropriate settings
        if average == "binary":
            precision = precision_score(
                y_true, y_pred, average=average, pos_label=pos_label, zero_division=0
            )
            recall = recall_score(
                y_true, y_pred, average=average, pos_label=pos_label, zero_division=0
            )
            f1 = f1_score(
                y_true, y_pred, average=average, pos_label=pos_label, zero_division=0
            )
        else:
            precision = precision_score(
                y_true, y_pred, average=average, zero_division=0
            )
            recall = recall_score(y_true, y_pred, average=average, zero_division=0)
            f1 = f1_score(y_true, y_pred, average=average, zero_division=0)

        # Per-class metrics
        precision_per_class = precision_score(
            y_true, y_pred, average=None, zero_division=0
        )
        recall_per_class = recall_score(y_true, y_pred, average=None, zero_division=0)
        f1_per_class = f1_score(y_true, y_pred, average=None, zero_division=0)

        # Confusion matrix
        cm = confusion_matrix(y_true, y_pred)

        # Create label names if not provided
        if self.label_names is None:
            self.label_names = [
                self.LABEL_MAP.get(label, str(label)) for label in unique_labels
            ]

        metrics = {
            "accuracy": float(accuracy),
            "precision_macro": float(precision),
            "recall_macro": float(recall),
            "f1_macro": float(f1),
            "confusion_matrix": cm.tolist(),
            "per_class_metrics": {
                label_name: {
                    "precision": float(prec),
                    "recall": float(rec),
                    "f1_score": float(f1_val),
                }
                for label_name, prec, rec, f1_val in zip(
                    self.label_names,
                    precision_per_class,
                    recall_per_class,
                    f1_per_class,
                )
            },
            "n_samples": len(y_true),
            "n_classes": n_classes,
        }

        logger.info(
            f"Metrics calculated - Accuracy: {accuracy:.4f}, F1 (macro): {f1:.4f}"
        )

        return metrics

    def get_classification_report(
        self, y_true: np.ndarray, y_pred: np.ndarray, digits: int = 4
    ) -> str:
        """
        Generate a detailed classification report.

        Args:
            y_true: True labels
            y_pred: Predicted labels
            digits: Number of decimal places in output

        Returns:
            Classification report as string
        """
        return classification_report(
            y_true,
            y_pred,
            target_names=self.label_names,
            digits=digits,
            zero_division=0,
        )

    def get_confusion_matrix(
        self, y_true: np.ndarray, y_pred: np.ndarray
    ) -> np.ndarray:
        """
        Calculate confusion matrix.

        Args:
            y_true: True labels
            y_pred: Predicted labels

        Returns:
            Confusion matrix
        """
        return confusion_matrix(y_true, y_pred)

    def format_metrics_report(self, metrics: Dict[str, Any]) -> str:
        """
        Format metrics into a readable report.

        Args:
            metrics: Dictionary of metrics

        Returns:
            Formatted report string
        """
        report = f"""
# Evaluation Metrics Report

## Overall Performance
- Accuracy: {metrics['accuracy']:.4f}
- Precision (macro): {metrics['precision_macro']:.4f}
- Recall (macro): {metrics['recall_macro']:.4f}
- F1-Score (macro): {metrics['f1_macro']:.4f}

## Per-Class Performance
"""

        for class_name, class_metrics in metrics["per_class_metrics"].items():
            report += f"""
### {class_name.capitalize()}
- Precision: {class_metrics['precision']:.4f}
- Recall: {class_metrics['recall']:.4f}
- F1-Score: {class_metrics['f1_score']:.4f}
"""

        report += f"""
## Confusion Matrix
{np.array(metrics['confusion_matrix'])}

## Dataset Info
- Total Samples: {metrics['n_samples']:,}
- Number of Classes: {metrics['n_classes']}
"""

        return report


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    # Example usage
    y_true = np.array([0, 0, 4, 4, 0, 4, 0, 4])
    y_pred = np.array([0, 4, 4, 4, 0, 0, 0, 4])

    calculator = MetricsCalculator(label_names=["negative", "positive"])

    metrics = calculator.calculate_metrics(y_true, y_pred)
    print(calculator.format_metrics_report(metrics))

    print("\n" + calculator.get_classification_report(y_true, y_pred))
