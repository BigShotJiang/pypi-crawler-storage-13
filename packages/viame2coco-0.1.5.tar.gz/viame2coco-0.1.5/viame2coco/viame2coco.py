import pycocowriter
import csv
import json
import itertools
from collections.abc import Iterable
import pycocowriter.coco
from pycocowriter.csv2coco import Iterable2COCO, Iterable2COCOConfig
from pycocowriter.coco import COCOLicense, COCOInfo, COCOData
from .viame_manual_annotations import *
import logging

logger = logging.getLogger(__name__)

COCO_CC0_LICENSE = COCOLicense(
    'CC0 1.0 Universal',
    0,
    'https://creativecommons.org/public-domain/cc0/'
)

viame_csv_config_default = {
    'filename': 1,
    'label': 9, 
    'bbox_tlbr': {
        'tlx': 2,
        'tly': 3,
        'brx': 4,
        'bry': 5
    }
}

def is_viame_metadata_row(row: Sequence[str]) -> bool:
    '''
    determines whether this row is a "metadata" row in a viame
    csv

    Parameters
    ----------
    row: Sequence[str]
    a row read in from a VIAME-style annotation csv

    Returns
    -------
    is_metadata: bool
    true if the row arg is a metadata row
    '''
    is_metadata = row[0].startswith('#')
    return is_metadata

def skip_viame_metadata_rows(
        viame_rows: Iterable[Sequence[str]]) -> Iterable[Sequence[str]]:
    '''
    skip any metadata rows in a sequence of VIAME-style annotation rows
    as read from a VIAME output csv

    Parameters
    ----------
    viame_rows: Iterable[Sequence[str]]
    an iterable of rows as read from a VIAME-style annotation csv output

    Returns
    -------
    viame_rows: Iterable[Sequence[str]]
    the same iterable of rows, but having skipped any metadata rows
    '''
    row = next(viame_rows)
    while is_viame_metadata_row(row):
        row = next(viame_rows)
    yield row
    yield from viame_rows

def read_viame_metadata_rows(
        viame_rows: Iterable[Sequence[str]]) -> tuple[list[Sequence[str]], Iterable[Sequence[str]]]:
    '''
    skip any metadata rows in a sequence of VIAME-style annotation rows
    as read from a VIAME output csv, and return those rows along with the remainder
    of the annotations iterator.

    Parameters
    ----------
    viame_rows: Iterable[Sequence[str]]
    an iterable of rows as read from a VIAME-style annotation csv output

    Returns
    -------
    metadata_rows: list[Sequence[str]]
    the metadata rows

    viame_rows: Iterable[Sequence[str]]
    the same iterable of rows, but having skipped any metadata rows
    '''
    metadata_rows = []
    for row in viame_rows:
        if not is_viame_metadata_row(row):
            return metadata_rows, itertools.chain([row], viame_rows)
        metadata_rows.append(row)
    return metadata_rows, iter(())

def determine_viame_version(viame_metadata_rows: list[Sequence[str]]) -> int:
    '''
    Determine the viame "version" from the metadata rows.
    We need these to figure out how to parse the remainder of the file

    Parameters
    ----------
    viame_metadata_rows: list[Sequence[str]]
    rows read by `read_viame_metadata_rows`

    Returns
    ----------
    version: int
    a pseudo-version of VIAME that we can use to parse the rest of the file
    '''
    logger.info('\n'.join(map(', '.join, metadata_rows)))

def passrows(iterable: Iterable, n: int = 0) -> Iterable:
    '''
    yield the first `n` rows in `iterable`.
    Useful with `itertools.chain` and `map` to 
    apply a function to only certain rows of an iterable

    Parameters
    ----------
    iterable: Iterable
        any iterable
    n: int
        the number of rows to skip

    Returns
    -------
    iterable: Iterable
        the iterable arg, but starting from the n+1th row
    '''
    for i in range(n):
        yield next(iterable)

def viame2coco_data(
        viame_csv_file: str, 
        video_file: str | None = None, 
        video_frame_outfile_dir: str | None = None, 
        viame_csv_config : dict | None = None) -> tuple[
            list[pycocowriter.coco.COCOImage],
            list[pycocowriter.coco.COCOAnnotation],
            list[pycocowriter.coco.COCOCategory]
        ]:
    '''
    extract the images, annotations, and categories from a VIAME-style
    annotation csv, into COCO format.  Filters the data to only MANUAL
    annotations.

    If the annotations are for a video file, also extract the images
    for the manually-annotated frames

    Parameters
    ----------
    viame_csv_file: str
        the file path location for the VIAME-style annotation csv
    video_file: str | None
        the file path location for the video which has been
        annotated.  If there is no video (i.e. the annotations
        are for images), then this should be None
    video_frame_outfile_dir: str | None
        a directory to which the extracted frames are writ
    viame_csv_config : dict | None
        the dictionary that specifies which fields are present, 
        and in which columns they are located. 
        Passed to pycocowriter.csv2coco.Iterable2COCOConfig. 
        If None, then viame2coco.viame2coco.viame_csv_config is used
    
    Returns
    -------
    images: list[COCOImage]
        a list of images contained in the CSV file, in COCO format,
        with appropriately-generated surrogate keys
    annotations: list[COCOAnnotation]
        a list of the annotations contained in the CSV file, with
        appropriate surrogate-key references to the images and categories
    categories: list[COCOCategory]
        a list of the categories contained in the CSV file, in COCO format,
        with appropriately-generated surrogate keys
    '''
    with open(viame_csv_file, 'r') as f:
        reader = csv.reader(f)
        metadata, data = read_viame_metadata_rows(reader)
        viame_version = determine_viame_version(metadata)
        if video_file is not None:            
            #TODO probably should hoist this into a higher function            
            if video_frame_outfile_dir is None:
                csv_location = os.path.split(viame_csv_file)[0]
                video_frame_outfile_dir = csv_location
            data = extract_viame_video_annotations(
                data, video_file, outfile_dir=video_frame_outfile_dir
            )
        if viame_csv_config is None:
            viame_csv_config = viame_csv_config_default
        csv2coco = Iterable2COCO(
            Iterable2COCOConfig(viame_csv_config)
        )
        images, annotations, categories = csv2coco.parse(data)
        return images, annotations, categories

def viame2coco(
        viame_csv_file: str, 
        description: str, 
        video_file: str | None = None, 
        video_frame_outfile_dir: str | None = None,
        viame_csv_config : dict | None = None, 
        license: pycocowriter.coco.COCOLicense = COCO_CC0_LICENSE, 
        version: str = '0.1') -> pycocowriter.coco.COCOData:
    '''
    Convert a VIAME-style annotation csv into COCO format

    Parameters
    ----------
    viame_csv_file: str
        the file path location for the VIAME-style annotation csv
    descriptions: str
        the description of this dataset
    video_file: str | None
        the file path location for the video which has been
        annotated.  If there is no video (i.e. the annotations
        are for images), then this should be None
    video_frame_outfile_dir: str | None
        a directory to which the extracted frames are writ
    viame_csv_config : dict | None
        the dictionary that specifies which fields are present, 
        and in which columns they are located. 
        If None, then viame2coco.viame2coco.viame_csv_config is used
    license: COCOLicense
        the license under which these images are provided
        Defaults to CC0 https://creativecommons.org/public-domain/cc0/
    version: str
        the version of this dataset, as a string
        defaults to '0.1'
    '''

    now = datetime.datetime.now(datetime.timezone.utc)
    coco_info = COCOInfo(
        year = now.year,
        version = version, 
        description = description, 
        date_created = now
    )

    images, annotations, categories = viame2coco_data(
        viame_csv_file, video_file=video_file, 
        video_frame_outfile_dir=video_frame_outfile_dir, 
        viame_csv_config = viame_csv_config
    )

    return COCOData(
        coco_info, 
        images, 
        annotations, 
        [license], 
        categories
    )
