"""
Setup script for questions-mcp-server
"""
from setuptools import setup, find_packages

setup(
    name="questions-mcp-server",
    version="1.0.0",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'src': ['**/*.yaml', '**/*.sql'],
    },
)
