@echo off
REM Questions MCP Server 启动脚本 (Windows)

echo 启动 Questions MCP Server...

REM 激活虚拟环境
if exist ".venv\Scripts\activate.bat" (
    call .venv\Scripts\activate.bat
    echo √ 虚拟环境已激活
) else (
    echo 警告: 虚拟环境不存在，请先运行 deploy.bat
    pause
    exit /b 1
)

REM 检查配置文件
if not exist ".env" (
    echo 警告: .env 文件不存在，使用默认配置
)

REM 启动服务
echo 正在启动服务...
python -m src.main

pause
