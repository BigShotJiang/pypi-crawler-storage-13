# 🩺 DuneAI

**DuneAI** — Automated detection and segmentation of non-small-cell lung cancer (NSCLC) CT images.  
This package lets clinicians and researchers segment CT volumes with a pretrained deep-learning model and **review results with an interactive viewer** (Jupyter or standalone GUI).

---

## ⚙️ Installation

Install from PyPI (recommended):

```bash
pip install duneai-cli
```

To include optional visualization support:

```bash
pip install "duneai-cli[vis]"
```

> **Note:** The `[vis]` extra installs `matplotlib` and `ipywidgets`.\
> For the standalone GUI (no Jupyter), `matplotlib` is sufficient.

---

## 🚀 Quick Start

### 1) Run automated segmentation

```bash
duneai-run \
  --model /path/to/model_files \
  --data  /path/to/patient_data \
  --out   ./results
```

**Example**

```bash
duneai-run \
  --model "model_files" \
  --data  "test_data" \
  --out   "results"
```

- `--model` → folder containing `model_v7.json` and `weights_v7.hdf5`  
- `--data`  → folder containing CT images (e.g., `.nrrd`), one folder per patient  
- `--out`   → output directory for results

Each patient folder will produce:

```
results/<PatientName>_(DL)/
├── image.nrrd     # resaved source image
└── DL_mask.nrrd   # predicted segmentation (uint8, 0/255)
```

---

## 👁️ View the Results

You can use either the **standalone GUI** or the **Jupyter viewer**.

### Option A — Standalone GUI (recommended for clinicians)

```bash
duneai-view --gui \
  --img  "results/pat1_(DL)/image.nrrd" \
  --mask "results/pat1_(DL)/DL_mask.nrrd"
```

**Features:**

- **Slice navigation:** slider, mouse wheel, or keys `J/K` (↓/↑).  
- **Window/Level controls:** sliders + presets (**Lung**, **Mediastinum**, **Bone**).  
- **Mask overlay:** filled or contour; **opacity** and **color** picker.  
- **Next/Prev mask slice** buttons to jump across slices with annotations.  
- **Quantification:** per-slice **area (mm²)** and total **volume (mL)** (uses NRRD spacing).  
- **Mask smoothing:** optional morphological clean-up for jaggy edges.  
- **Save PNG:** capture the current view (`S` key or “Save PNG” button).  
- **Shortcuts:** `J/K` or ↓/↑ (slice), `N/P` (next/prev mask slice), `M` (toggle mask), `C` (filled/contour), `S` (save).

> macOS users: if no window appears, try setting the backend:
> ```python
> import matplotlib; matplotlib.use("TkAgg")
> ```

### Option B — Jupyter (ipywidgets)

```python
from duneai_cli.viewer import notebook_view

notebook_view(
    img_path="results/pat1_(DL)/image.nrrd",
    mask_path="results/pat1_(DL)/DL_mask.nrrd",
)
```

Controls include **slice**, **WW/WL**, **overlay mode**, **opacity**, and **color**.

---

## 🧠 How It Works

1. **Preprocessing:** lung windowing, resampling, and extraction.  
2. **Inference:** legacy Keras 2.2.x model loaded safely on modern TF/Keras.  
3. **Re-embedding:** predicts on 512×512 crops and writes back to the **original voxel grid** using the **original (exclusive) indexing**.  
4. **Export:** both the input CT (`image.nrrd`) and segmentation (`DL_mask.nrrd`) with original spacing/origin are written per patient.

---

## ⚡ Command Reference

| Command       | Description                                       |
|---------------|---------------------------------------------------|
| `duneai-run`  | Run automated segmentation on a dataset           |
| `duneai-view` | Launch viewer for `.nrrd` image and mask files    |

**Common flags**

- `--gui` / `--interactive` (Jupyter) for `duneai-view`  
- `--quiet` to reduce logs (where applicable)

---

## 🧪 System Requirements

- **Python:** 3.8 – 3.12  
- **Core deps:** TensorFlow ≥ 2.10, Keras ≥ 2.10, SimpleITK, NumPy, OpenCV, tqdm  
- **Visualization (optional):** matplotlib, ipywidgets

> On some platforms you may need system packages/drivers for `SimpleITK` and GPU-enabled TensorFlow.

---

## 🛠️ Troubleshooting

| Issue | Possible Cause | Fix |
|------|-----------------|-----|
| `FileNotFoundError: Missing model_v7.json` | Model directory not provided | Specify with `--model /path/to/model_files` |
| Empty/transparent mask | Threshold too high for your data | Re-run with a lower threshold (e.g., `thr=0.5` in code) |
| Shape mismatch warnings | Dataset variance in shape/spacing | Fixed by robust re-embedding + resizing in v1.3+ |
| GUI doesn’t open (macOS) | Matplotlib backend | `matplotlib.use("TkAgg")` before launching viewer |

---

## 🧾 Changelog (highlights)

- **v1.3.0**  
  - Robust **legacy Keras JSON + HDF5** loading on modern TF/Keras with custom mappings.  
  - **Exclusive indexing** preserved during re-embedding; safer clamping.  
  - Masks saved as **uint8 (0/255)** for better visibility in viewers.  
  - New **GUI viewer**: WW/WL presets, opacity, color, filled/contour, smoothing, quantification, PNG export.  
  - Cross‑platform patient ID handling; generator compatibility kept.

---

## 👩‍⚕️ Authors

- **A. Lohachab** — Cross-platform compatibility, TF/Keras upgrades, visualization tools, packaging for PyPI  
- **S. Primakov** — Original research codebase  
  *Original repository supporting the research paper published in*  
  **Nature Communications (Primakov et al., 2022)** —  
  [github.com/primakov/DuneAI-Automated-detection-and-segmentation-of-non-small-cell-lung-cancer-computed-tomography-images](https://github.com/primakov/DuneAI-Automated-detection-and-segmentation-of-non-small-cell-lung-cancer-computed-tomography-images)


---

## 🧩 License

MIT License © 2025 — Maastricht University 
