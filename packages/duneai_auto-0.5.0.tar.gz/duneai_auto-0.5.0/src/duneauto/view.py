# duneai/viewer.py
from __future__ import annotations
import argparse
from pathlib import Path
import SimpleITK as sitk
import numpy as np

# For optional smoothing
from scipy import ndimage as ndi


# -------------------- Core utils --------------------
def _window(img: np.ndarray, ww: float, wl: float) -> np.ndarray:
    """Apply CT window/level to HU image, return float32 in [0, 1]."""
    lo = wl - ww / 2.0
    hi = wl + ww / 2.0
    x = img.astype(np.float32)
    x = np.clip(x, lo, hi)
    x = (x - lo) / max(hi - lo, 1e-6)
    return x


def _load(img_path: str | Path, mask_path: str | Path):
    img_itk = sitk.ReadImage(str(img_path))
    mask_itk = sitk.ReadImage(str(mask_path))

    img_np = sitk.GetArrayFromImage(img_itk)   # (Z, Y, X)
    mask_np = sitk.GetArrayFromImage(mask_itk).astype(np.uint8)

    spacing_xyz = img_itk.GetSpacing()  # (sx, sy, sz) in mm
    origin_xyz = img_itk.GetOrigin()

    print("✅ Loaded successfully")
    print(f"Image shape: {img_np.shape} | dtype: {img_np.dtype}")
    print(f"Mask  shape: {mask_np.shape} | dtype: {mask_np.dtype}")
    if img_np.shape != mask_np.shape:
        print("⚠️ image and mask shapes differ — overlay may be misaligned.")

    meta = {
        "spacing_xyz": spacing_xyz,
        "origin_xyz": origin_xyz,
        "voxel_volume_mm3": float(spacing_xyz[0] * spacing_xyz[1] * spacing_xyz[2]),
        "inplane_area_mm2": float(spacing_xyz[0] * spacing_xyz[1]),
    }
    return img_np, mask_np, meta


def _mask_slices(mask: np.ndarray) -> np.ndarray:
    """Indices of slices containing any mask."""
    return np.where(mask.reshape(mask.shape[0], -1).any(axis=1))[0]


# -------------------- Jupyter viewer --------------------
def notebook_view(img_path: str | Path, mask_path: str | Path):
    import matplotlib.pyplot as plt
    from ipywidgets import interact, IntSlider, FloatSlider, Checkbox, Dropdown

    img_np, mask_np, meta = _load(img_path, mask_path)
    slices_with_mask = _mask_slices(mask_np)
    default_slice = int(slices_with_mask[len(slices_with_mask)//2]) if len(slices_with_mask) else img_np.shape[0] // 2

    def _draw(idx, ww, wl, show_mask, mode, opacity, color):
        im = _window(img_np, ww, wl)[idx]
        plt.figure(figsize=(8, 8))
        plt.imshow(im, cmap="gray", interpolation="nearest")
        if show_mask:
            m = mask_np[idx] > 0
            if m.any():
                if mode == "filled":
                    rgba = np.zeros((*m.shape, 4), np.float32)
                    rgba[m, :] = [*COLOR_MAP[color], float(opacity)]
                    plt.imshow(rgba, interpolation="nearest")
                else:
                    plt.contour(m.astype(np.uint8), levels=[0.5], colors=[color], linewidths=2.0)
        plt.title(f"Slice {idx}  |  WW/WL: {ww:.0f}/{wl:.0f}")
        plt.axis("off")
        plt.show()

    COLOR_MAP = {
        "red":   (1.0, 0.0, 0.0),
        "orange":(1.0, 0.5, 0.0),
        "lime":  (0.0, 1.0, 0.0),
        "cyan":  (0.0, 1.0, 1.0),
        "magenta":(1.0, 0.0, 1.0),
    }

    interact(
        _draw,
        idx=IntSlider(min=0, max=img_np.shape[0]-1, value=default_slice, step=1, description="Slice"),
        ww=FloatSlider(min=100, max=3000, value=1500, step=10, description="WW"),
        wl=FloatSlider(min=-1000, max=1000, value=-600, step=10, description="WL"),
        show_mask=Checkbox(value=True, description="Show mask"),
        mode=Dropdown(options=["filled", "contour"], value="filled", description="Overlay"),
        opacity=FloatSlider(min=0.0, max=1.0, value=0.4, step=0.05, description="Opacity"),
        color=Dropdown(options=list(COLOR_MAP.keys()), value="orange", description="Mask color"),
    )


# -------------------- Rich GUI (no Jupyter required) --------------------
def gui_view(img_path: str | Path, mask_path: str | Path):
    import matplotlib
    import matplotlib.pyplot as plt
    from matplotlib.widgets import Slider, CheckButtons, RadioButtons, Button

    # If no window appears on macOS, try:
    # matplotlib.use("TkAgg")

    img_np, mask_np, meta = _load(img_path, mask_path)
    slices_with_mask = _mask_slices(mask_np)
    idx = int(slices_with_mask[len(slices_with_mask)//2]) if len(slices_with_mask) else img_np.shape[0] // 2

    # --- Defaults / presets ---
    PRESETS = {
        "Lung":        (1500, -600),
        "Mediastinum": (350,   50),
        "Bone":        (2500,  500),
    }
    ww, wl = PRESETS["Lung"]
    opacity = 0.40
    overlay_mode = "filled"
    color = "orange"
    smooth = False
    smooth_iter = 1

    COLOR_MAP = {
        "red":   (1.0, 0.0, 0.0),
        "orange":(1.0, 0.5, 0.0),
        "lime":  (0.0, 1.0, 0.0),
        "cyan":  (0.0, 1.0, 1.0),
        "magenta":(1.0, 0.0, 1.0),
    }

    # --- Figure & layout ---
    fig = plt.figure(figsize=(9.5, 9.5))
    ax_img    = plt.axes([0.05, 0.22, 0.70, 0.73])
    ax_slider = plt.axes([0.05, 0.17, 0.70, 0.03])
    ax_ww     = plt.axes([0.05, 0.12, 0.32, 0.03])
    ax_wl     = plt.axes([0.43, 0.12, 0.32, 0.03])
    ax_checkL = plt.axes([0.78, 0.67, 0.20, 0.18])
    ax_radioM = plt.axes([0.78, 0.54, 0.20, 0.11])
    ax_radioC = plt.axes([0.78, 0.41, 0.20, 0.11])
    ax_opac   = plt.axes([0.78, 0.36, 0.20, 0.03])
    ax_preset = plt.axes([0.78, 0.28, 0.20, 0.07])
    ax_maskBtns = plt.axes([0.78, 0.21, 0.20, 0.06])
    ax_save   = plt.axes([0.78, 0.14, 0.20, 0.06])
    ax_info   = plt.axes([0.05, 0.05, 0.93, 0.06])

    ax_img.set_axis_off()
    im = ax_img.imshow(_window(img_np, ww, wl)[idx], cmap="gray", interpolation="nearest")

    overlay_im = None
    contour_handle = None

    def current_mask(slice_idx: int) -> np.ndarray:
        m = mask_np[slice_idx] > 0
        if smooth and m.any():
            m = ndi.binary_opening(m, iterations=smooth_iter)
            m = ndi.binary_closing(m, iterations=smooth_iter)
        return m

    def update_overlay():
        nonlocal overlay_im, contour_handle
        # clear previous
        if overlay_im is not None:
            overlay_im.remove()
            overlay_im = None
        if contour_handle is not None:
            for coll in contour_handle.collections:
                coll.remove()
            contour_handle = None

        if not chk_vals()[0]:  # Show mask?
            fig.canvas.draw_idle()
            return

        m = current_mask(int(slider.val))
        if not m.any():
            fig.canvas.draw_idle()
            return

        if radio_mode.value_selected == "filled":
            rgba = np.zeros((*m.shape, 4), dtype=np.float32)
            rgba[m, :] = [*COLOR_MAP[radio_color.value_selected], float(opacity_slider.val)]
            overlay_im = ax_img.imshow(rgba, interpolation="nearest")
        else:
            contour_handle = ax_img.contour(m.astype(np.uint8), levels=[0.5], colors=[radio_color.value_selected], linewidths=2.0)

        fig.canvas.draw_idle()

    def update_image():
        idx_i = int(slider.val)
        im.set_data(_window(img_np, ww_slider.val, wl_slider.val)[idx_i])
        update_overlay()
        update_info(idx_i)

    def update_info(idx_i: int):
        ax_info.clear()
        ax_info.set_axis_off()
        # area & volume
        m = mask_np[idx_i] > 0
        pix_area = meta["inplane_area_mm2"]
        slice_area_mm2 = float(m.sum()) * pix_area
        total_vol_ml = float(mask_np.sum()) * meta["voxel_volume_mm3"] / 1000.0  # mm^3 -> mL
        sx, sy, sz = meta["spacing_xyz"]
        info = (
            f"Slice {idx_i}/{img_np.shape[0]-1} | WW/WL: {ww_slider.val:.0f}/{wl_slider.val:.0f} "
            f"| Spacing (mm): {sx:.2f}×{sy:.2f}×{sz:.2f} "
            f"| Area (slice): {slice_area_mm2:.1f} mm² "
            f"| Volume (mask): {total_vol_ml:.1f} mL"
        )
        ax_info.text(0.01, 0.5, info, va="center", ha="left", fontsize=10)
        fig.canvas.draw_idle()

    # ---------- Widgets ----------
    slider = Slider(ax_slider, "Slice", 0, img_np.shape[0]-1, valinit=idx, valstep=1)
    ww_slider = Slider(ax_ww, "WW", 100, 3000, valinit=ww, valstep=10)
    wl_slider = Slider(ax_wl, "WL", -1000, 1000, valinit=wl, valstep=10)

    checks = CheckButtons(ax_checkL, ["Show mask", "Smooth mask"], [True, False])
    def chk_vals():
        return checks.get_status()

    radio_mode = RadioButtons(ax_radioM, ("filled", "contour"), active=0)
    radio_color = RadioButtons(ax_radioC, ("orange", "red", "lime", "cyan", "magenta"), active=0)
    opacity_slider = Slider(ax_opac, "Opacity", 0.0, 1.0, valinit=opacity, valstep=0.05)

    # Preset buttons
    preset_axes = [plt.axes([ax_preset.get_position().x0 + i*0.067, ax_preset.get_position().y0, 0.06, 0.06]) for i in range(3)]
    btn_lung = Button(preset_axes[0], "Lung")
    btn_med  = Button(preset_axes[1], "Mediast.")
    btn_bone = Button(preset_axes[2], "Bone")

    # Next/Prev mask slice
    btn_prev_mask = Button(plt.axes([ax_maskBtns.get_position().x0, ax_maskBtns.get_position().y0, 0.095, 0.06]), "◀ Mask")
    btn_next_mask = Button(plt.axes([ax_maskBtns.get_position().x0+0.105, ax_maskBtns.get_position().y0, 0.095, 0.06]), "Mask ▶")

    # Save PNG
    btn_save = Button(ax_save, "Save PNG")

    # ---------- Callbacks ----------
    def on_slice(val):
        update_image()

    def on_ww(val):
        update_image()

    def on_wl(val):
        update_image()

    def on_checks(label):
        nonlocal smooth
        show_mask, smooth = chk_vals()
        update_overlay()
        update_info(int(slider.val))

    def on_mode(label):
        update_overlay()

    def on_color(label):
        update_overlay()

    def on_opacity(val):
        update_overlay()

    def apply_preset(name: str):
        ww_p, wl_p = PRESETS[name]
        ww_slider.set_val(ww_p)
        wl_slider.set_val(wl_p)

    def prev_mask_slice(event=None):
        if len(slices_with_mask) == 0:
            return
        cur = int(slider.val)
        prevs = slices_with_mask[slices_with_mask < cur]
        new_idx = int(prevs[-1]) if len(prevs) else int(slices_with_mask[-1])
        slider.set_val(new_idx)

    def next_mask_slice(event=None):
        if len(slices_with_mask) == 0:
            return
        cur = int(slider.val)
        nexts = slices_with_mask[slices_with_mask > cur]
        new_idx = int(nexts[0]) if len(nexts) else int(slices_with_mask[0])
        slider.set_val(new_idx)

    def save_png(event=None):
        out = Path(img_path).with_suffix("")  # base
        out_dir = out.parent
        out_file = out_dir / f"view_slice{int(slider.val)}_ww{int(ww_slider.val)}_wl{int(wl_slider.val)}.png"
        fig.savefig(str(out_file), dpi=150, bbox_inches="tight")
        print(f"💾 Saved {out_file}")

    # Mouse wheel & keys
    def on_scroll(event):
        step = 1 if event.button == "up" else -1
        new_idx = int(np.clip(int(slider.val) + step, 0, img_np.shape[0]-1))
        slider.set_val(new_idx)

    def on_key(event):
        if event.key in ("j", "down"):
            new_idx = min(int(slider.val) + 1, img_np.shape[0]-1)
            slider.set_val(new_idx)
        elif event.key in ("k", "up"):
            new_idx = max(int(slider.val) - 1, 0)
            slider.set_val(new_idx)
        elif event.key == "m":
            # toggle mask
            states = checks.get_status()
            checks.set_active(0)  # toggles "Show mask"
        elif event.key == "c":
            # toggle filled/contour
            cur = radio_mode.value_selected
            radio_mode.set_active(1 if cur == "filled" else 0)
        elif event.key == "n":
            next_mask_slice()
        elif event.key == "p":
            prev_mask_slice()
        elif event.key == "s":
            save_png()

    # Bind
    slider.on_changed(on_slice)
    ww_slider.on_changed(on_ww)
    wl_slider.on_changed(on_wl)
    checks.on_clicked(on_checks)
    radio_mode.on_clicked(on_mode)
    radio_color.on_clicked(on_color)
    opacity_slider.on_changed(on_opacity)
    btn_lung.on_clicked(lambda e: apply_preset("Lung"))
    btn_med.on_clicked(lambda e: apply_preset("Mediastinum"))
    btn_bone.on_clicked(lambda e: apply_preset("Bone"))
    btn_prev_mask.on_clicked(prev_mask_slice)
    btn_next_mask.on_clicked(next_mask_slice)
    btn_save.on_clicked(save_png)

    cid_scroll = fig.canvas.mpl_connect("scroll_event", on_scroll)
    cid_key = fig.canvas.mpl_connect("key_press_event", on_key)

    # Initial draw
    update_image()
    plt.show()


# -------------------- Simple CLI fallback --------------------
def cli_view(img_path: str | Path, mask_path: str | Path):
    import matplotlib.pyplot as plt
    img_np, mask_np, meta = _load(img_path, mask_path)
    mid = img_np.shape[0] // 2
    im = _window(img_np, 1500, -600)[mid]
    m = mask_np[mid] > 0

    plt.figure(figsize=(8, 8))
    plt.imshow(im, cmap="gray", interpolation="nearest")
    if m.any():
        overlay = np.zeros((*m.shape, 4), dtype=np.float32)
        overlay[m, :] = [1.0, 0.5, 0.0, 0.40]
        plt.imshow(overlay, interpolation="nearest")
    plt.axis("off")
    plt.title(f"Middle slice {mid} | WW/WL 1500/-600")
    plt.show()


# -------------------- CLI entry --------------------
def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="duneai-view", description="View CT + segmentation mask (NRRD).")
    p.add_argument("--img", required=True, type=Path, help="Path to image.nrrd")
    p.add_argument("--mask", required=True, type=Path, help="Path to DL_mask.nrrd")
    p.add_argument("--interactive", action="store_true", help="Jupyter ipywidgets (not for terminals)")
    p.add_argument("--gui", action="store_true", help="Open a window with slider/controls (no Jupyter needed)")
    return p.parse_args()


def main() -> int:
    args = _parse_args()
    if args.gui:
        gui_view(args.img, args.mask)
    elif args.interactive:
        notebook_view(args.img, args.mask)
    else:
        cli_view(args.img, args.mask)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
