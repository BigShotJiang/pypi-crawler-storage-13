from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ALGO_DIR_NAME = "Automatic segmentation script"
ALGO_FILE_NAME = "TheDuneAI.py"


def _find_algo_dir() -> Path | None:
    """
    Try to locate the folder that contains TheDuneAI.py.

    Search order:
      1. Environment variable DUNEAI_ALGO_DIR
      2. CWD and its parents:   <dir>/<ALGO_DIR_NAME>/<ALGO_FILE_NAME>
      3. Package location and its parents (for editable installs in the repo)
    """
    # 1) Environment variable (explicit override)
    env = os.environ.get("DUNEAI_ALGO_DIR")
    if env:
        p = Path(env).expanduser().resolve()
        if (p / ALGO_FILE_NAME).exists():
            return p

    # 2) Walk from current working directory upwards
    here = Path.cwd().resolve()
    for parent in (here, *here.parents):
        candidate = parent / ALGO_DIR_NAME / ALGO_FILE_NAME
        if candidate.exists():
            return candidate.parent

    # 3) Walk from the installed package location upwards
    pkg_dir = Path(__file__).resolve().parent
    for parent in (pkg_dir, *pkg_dir.parents):
        candidate = parent / ALGO_DIR_NAME / ALGO_FILE_NAME
        if candidate.exists():
            return candidate.parent

    return None


def _maybe_add_algo_path() -> Path:
    """
    Locate the algorithm directory and add it to sys.path
    so that `from TheDuneAI import ContourPilot` works.
    """
    algo_dir = _find_algo_dir()
    if algo_dir is None:
        raise RuntimeError(
            "Could not locate TheDuneAI.py.\n"
            f"Looked for '{ALGO_DIR_NAME}/{ALGO_FILE_NAME}' relative to:\n"
            "  • The current working directory and its parents\n"
            "  • The installed duneai-auto package location and its parents\n\n"
            "To fix this, either:\n"
            f"  • Run `duneai` from a checkout that contains '{ALGO_DIR_NAME}/{ALGO_FILE_NAME}', OR\n"
            f"  • Set the environment variable DUNEAI_ALGO_DIR to the folder that contains {ALGO_FILE_NAME}.\n"
        )

    algo_str = str(algo_dir)
    if algo_str not in sys.path:
        sys.path.insert(0, algo_str)
    return algo_dir


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="duneai",
        description="Run DuneAI automated NSCLC CT segmentation.",
    )
    parser.add_argument(
        "--model",
        "-m",
        type=Path,
        required=True,
        help="Directory with model_v7.json and weights_v7.hdf5.",
    )
    parser.add_argument(
        "--data",
        "-d",
        type=Path,
        required=True,
        help="Directory with patient CT data (nrrd).",
    )
    parser.add_argument(
        "--out",
        "-o",
        type=Path,
        required=True,
        help="Output directory for segmentation results.",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Reduce console output.",
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()

    # Import late so users can point to any checkout containing TheDuneAI.py
    _maybe_add_algo_path()
    try:
        from TheDuneAI import ContourPilot  # type: ignore
    except Exception as e:  # noqa: BLE001
        raise RuntimeError(
            "TheDuneAI.py was not importable even after locating the algorithm directory.\n"
            f"Make sure '{ALGO_FILE_NAME}' defines `ContourPilot` and is readable."
        ) from e

    model_path: Path = args.model
    data_path: Path = args.data
    out_path: Path = args.out

    if not model_path.exists():
        raise FileNotFoundError(f"Model directory not found: {model_path}")
    if not data_path.exists():
        raise FileNotFoundError(f"Data directory not found: {data_path}")

    out_path.mkdir(parents=True, exist_ok=True)

    print(f"[RUN] MODEL_DIR : {model_path} (ok)")
    print(f"[RUN] DATA_DIR  : {data_path} (ok)")
    print(f"[RUN] OUT_DIR   : {out_path}")

    cp = ContourPilot(
        model_path=str(model_path),
        data_path=str(data_path),
        output_path=str(out_path),
        verbosity=not args.quiet,
    )
    rc = cp.segment()
    if rc == 0:
        print(f"[OK] Segmentation completed. Results: {out_path}")
    else:
        print(f"[WARN] Segmentation returned code {rc}.")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
