from setuptools import setup, find_packages

setup(
    name="budget-recommender",
    version="0.1.0",
    description="Dynamic budget tracking and goal recommendation library",
    author="Your Name",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.8",
    include_package_data=True,
)
