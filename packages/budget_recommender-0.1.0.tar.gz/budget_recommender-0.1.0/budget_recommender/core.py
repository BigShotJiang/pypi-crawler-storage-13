import datetime

class BudgetGoal:
    """
    Represents a personal budgeting goal.
    """
    def __init__(self, goal_name, target_amount, target_date, target_category, priority, savings):
        self.goal_name = goal_name
        self.target_amount = target_amount
        self.target_date = target_date  # Should be a datetime.date object
        self.target_category = target_category
        self.priority = priority
        self.savings = savings

class RecommendationEngine:
    """
    Generates savings recommendations for a list of BudgetGoal objects.
    """
    def __init__(self, goals):
        self.goals = goals  # Expects a list of BudgetGoal objects

    def generate_recommendations(self):
        recommendations = []
        now = datetime.datetime.now(datetime.timezone.utc)
        current_date_str = now.strftime('%A, %B %d, %Y, %-I %p GMT')  # E.g. "Tuesday, November 18, 2025, 5 PM GMT"

        for goal in self.goals:
            days_left = (goal.target_date - now.date()).days
            months_left = max(days_left // 30, 1)  # Avoid division by zero and negative months
            remaining = max(goal.target_amount - goal.savings, 0)
            monthly_need = round(remaining / months_left, 2)
            progress = round((goal.savings / goal.target_amount) * 100, 1) if goal.target_amount else 0

            message = (
                f"-----\n"
                f"Goal: '{goal.goal_name}' ({goal.target_category})\n"
                f"Target Amount: ${goal.target_amount:.2f}\n"
                f"Current Savings: ${goal.savings:.2f}\n"
                f"Remaining to Save: ${remaining:.2f}\n"
                f"Target Date: {goal.target_date.strftime('%A, %B %d, %Y')}\n"
                f"Priority: {goal.priority}\n"
                f"Progress: {progress}% complete\n"
                f"\n"
                f"To reach '{goal.goal_name}', save about ${monthly_need:.2f} per month for the next {months_left} months.\n"
                f"Current date: {current_date_str}\n"
            )

            if progress >= 100:
                message += "🎉 Congratulations! You've reached your goal!\n"
            elif months_left <= 2:
                message += "⚠️ Urgent: Deadline is soon. Consider increasing your savings rate or changing your goal date.\n"

            recommendations.append({
                "goal_name": goal.goal_name,
                "target_category": goal.target_category,
                "priority": goal.priority,
                "months_left": months_left,
                "monthly_saving_needed": monthly_need,
                "progress_percent": progress,
                "remaining": remaining,
                "message": message
            })

        return recommendations
