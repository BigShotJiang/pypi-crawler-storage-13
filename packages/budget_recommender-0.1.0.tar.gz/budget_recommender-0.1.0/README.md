# budget-recommender

A simple and dynamic Python library for personal budget tracking and goal recommendations.

## Features

- Define multiple budgeting goals dynamically (name, amount, date, category, priority, savings).
- Get personalized savings recommendations for each goal.
- Designed for integration with web apps and external data sources (e.g., AWS DynamoDB).

## Installation

