"""
Logs - Simple Terminal Logger
Ein minimalistischer, farbiger Logger für Python-Projekte
"""

from datetime import datetime
from typing import Optional, Callable
from pathlib import Path
import sys
from colorama import Fore, Style, init

# Colorama initialisieren
init(autoreset=True)


class LogLevel:
    """Log-Level Definitionen"""
    DEBUG = 0
    INFO = 1
    SUCCESS = 2
    WARN = 3
    ERROR = 4
    FATAL = 5


class Logs:
    """
    Einfacher Terminal Logger mit Colorama-Farbunterstützung
    
    Beispiel:
        from logs import Logs
        
        # Einfache Verwendung
        Logs.debug("DATABASE", "Erfolgreich eingerichtet")
        Logs.success("API", "Server gestartet auf Port 8000")
        
        # Mit File-Logging
        Logs.configure(log_file="app.log")
        
        # Mit Custom Format
        Logs.configure(timestamp_format="%H:%M:%S")
        
        # Mit Min-Level (nur WARN und höher)
        Logs.configure(min_level=LogLevel.WARN)
    """
    
    # Konfiguration
    enabled = True
    show_timestamp = True
    timestamp_format = "%Y-%m-%d %H:%M:%S"
    min_level = LogLevel.DEBUG
    log_file: Optional[Path] = None
    colorize = True
    
    # Callbacks für Custom-Handler
    _handlers: list[Callable] = []
    
    # Level-Farben
    _colors = {
        LogLevel.DEBUG: Fore.CYAN,
        LogLevel.INFO: Fore.WHITE,
        LogLevel.SUCCESS: Fore.GREEN,
        LogLevel.WARN: Fore.YELLOW,
        LogLevel.ERROR: Fore.RED,
        LogLevel.FATAL: Fore.MAGENTA,
    }
    
    _level_names = {
        LogLevel.DEBUG: "DEBUG",
        LogLevel.INFO: "INFO",
        LogLevel.SUCCESS: "SUCCESS",
        LogLevel.WARN: "WARN",
        LogLevel.ERROR: "ERROR",
        LogLevel.FATAL: "FATAL",
    }
    
    @classmethod
    def _format_timestamp(cls) -> str:
        """Formatiert den aktuellen Zeitstempel"""
        if not cls.show_timestamp:
            return ""
        return f"[{datetime.now().strftime(cls.timestamp_format)}] "
    
    @classmethod
    def _write_to_file(cls, message: str):
        """Schreibt Log in Datei"""
        if cls.log_file:
            try:
                with open(cls.log_file, 'a', encoding='utf-8') as f:
                    # Ohne Farbcodes in Datei
                    clean_message = message
                    for color in [Fore.CYAN, Fore.WHITE, Fore.GREEN, Fore.YELLOW, 
                                  Fore.RED, Fore.MAGENTA, Style.BRIGHT, Style.RESET_ALL]:
                        clean_message = clean_message.replace(color, '')
                    f.write(clean_message + '\n')
            except Exception as e:
                print(f"[Logs] Fehler beim Schreiben in Log-Datei: {e}", file=sys.stderr)
    
    @classmethod
    def _log(cls, level: int, category: str, message: str):
        """
        Interne Log-Methode
        
        Args:
            level: Log-Level (LogLevel.DEBUG, etc.)
            category: Kategorie der Nachricht
            message: Die Nachricht
        """
        if not cls.enabled or level < cls.min_level:
            return
        
        timestamp = cls._format_timestamp()
        level_name = cls._level_names[level]
        color = cls._colors[level]
        
        # Format: [TIMESTAMP] [LEVEL] [CATEGORY] MSG
        if cls.colorize:
            output = (
                f"{timestamp}"
                f"{color}{Style.BRIGHT}[{level_name}]{Style.RESET_ALL} "
                f"{Style.BRIGHT}[{category}]{Style.RESET_ALL} "
                f"{message}"
            )
        else:
            output = f"{timestamp}[{level_name}] [{category}] {message}"
        
        # Ausgabe
        print(output)
        
        # In Datei schreiben
        cls._write_to_file(output)
        
        # Custom Handler aufrufen
        for handler in cls._handlers:
            try:
                handler(level, category, message)
            except Exception as e:
                print(f"[Logs] Handler-Fehler: {e}", file=sys.stderr)
    
    @classmethod
    def debug(cls, category: str, message: str):
        """
        DEBUG Level - Für Debugging-Informationen
        
        Args:
            category: Kategorie (z.B. "DATABASE", "API")
            message: Log-Nachricht
        """
        cls._log(LogLevel.DEBUG, category, message)
    
    @classmethod
    def info(cls, category: str, message: str):
        """
        INFO Level - Für allgemeine Informationen
        
        Args:
            category: Kategorie (z.B. "SYSTEM", "CONFIG")
            message: Log-Nachricht
        """
        cls._log(LogLevel.INFO, category, message)
    
    @classmethod
    def success(cls, category: str, message: str):
        """
        SUCCESS Level - Für erfolgreiche Operationen
        
        Args:
            category: Kategorie (z.B. "DATABASE", "API")
            message: Log-Nachricht
        """
        cls._log(LogLevel.SUCCESS, category, message)
    
    @classmethod
    def warn(cls, category: str, message: str):
        """
        WARN Level - Für Warnungen
        
        Args:
            category: Kategorie (z.B. "SECURITY", "PERFORMANCE")
            message: Log-Nachricht
        """
        cls._log(LogLevel.WARN, category, message)
    
    @classmethod
    def error(cls, category: str, message: str):
        """
        ERROR Level - Für Fehler
        
        Args:
            category: Kategorie (z.B. "AUTH", "NETWORK")
            message: Log-Nachricht
        """
        cls._log(LogLevel.ERROR, category, message)
    
    @classmethod
    def fatal(cls, category: str, message: str):
        """
        FATAL Level - Für kritische Fehler
        
        Args:
            category: Kategorie (z.B. "SYSTEM", "DATABASE")
            message: Log-Nachricht
        """
        cls._log(LogLevel.FATAL, category, message)
    
    @classmethod
    def configure(cls, 
                  enabled: Optional[bool] = None,
                  show_timestamp: Optional[bool] = None,
                  timestamp_format: Optional[str] = None,
                  min_level: Optional[int] = None,
                  log_file: Optional[str] = None,
                  colorize: Optional[bool] = None):
        """
        Konfiguriert den Logger
        
        Args:
            enabled: Logger aktiviert/deaktiviert
            show_timestamp: Zeitstempel anzeigen
            timestamp_format: Zeitstempel-Format (z.B. "%H:%M:%S")
            min_level: Minimales Log-Level (z.B. LogLevel.WARN)
            log_file: Pfad zur Log-Datei (None = kein File-Logging)
            colorize: Farbige Ausgabe aktivieren/deaktivieren
        """
        if enabled is not None:
            cls.enabled = enabled
        if show_timestamp is not None:
            cls.show_timestamp = show_timestamp
        if timestamp_format is not None:
            cls.timestamp_format = timestamp_format
        if min_level is not None:
            cls.min_level = min_level
        if log_file is not None:
            cls.log_file = Path(log_file) if log_file else None
        if colorize is not None:
            cls.colorize = colorize
    
    @classmethod
    def add_handler(cls, handler: Callable[[int, str, str], None]):
        """
        Fügt einen Custom-Handler hinzu
        
        Args:
            handler: Callable mit Signatur (level: int, category: str, message: str)
        
        Beispiel:
            def my_handler(level, category, message):
                if level >= LogLevel.ERROR:
                    send_alert(f"{category}: {message}")
            
            Logs.add_handler(my_handler)
        """
        cls._handlers.append(handler)
    
    @classmethod
    def remove_handler(cls, handler: Callable):
        """Entfernt einen Handler"""
        if handler in cls._handlers:
            cls._handlers.remove(handler)
    
    @classmethod
    def clear_handlers(cls):
        """Entfernt alle Handler"""
        cls._handlers.clear()
    
    @classmethod
    def reset(cls):
        """Setzt alle Einstellungen auf Standard zurück"""
        cls.enabled = True
        cls.show_timestamp = True
        cls.timestamp_format = "%Y-%m-%d %H:%M:%S"
        cls.min_level = LogLevel.DEBUG
        cls.log_file = None
        cls.colorize = True
        cls.clear_handlers()