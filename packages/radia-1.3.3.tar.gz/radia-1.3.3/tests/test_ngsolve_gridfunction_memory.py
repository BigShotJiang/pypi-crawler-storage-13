#!/usr/bin/env python
"""
Test memory behavior of NGSolve GridFunction.Set() with Python CoefficientFunction

This test checks if memory accumulation occurs in NGSolve's GridFunction.Set()
mechanism itself, without using radia_ngsolve.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'build', 'Release'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src', 'python'))

import gc
import psutil
from ngsolve import *
from netgen.occ import *

print("=" * 80)
print("NGSolve GridFunction.Set() Memory Test")
print("=" * 80)
print()

# Create small NGSolve mesh (same as radia_ngsolve test)
box = Box((0.02, 0, 0), (0.05, 0.03, 0.03))
geo = OCCGeometry(box)
mesh = Mesh(geo.GenerateMesh(maxh=0.015))

print(f"Mesh: {mesh.nv} vertices, {mesh.ne} elements")
print()

# Create FE space and GridFunction
fes = HCurl(mesh, order=1)
gf = GridFunction(fes)

print(f"FE Space: {fes.ndof} DOFs")
print()

# Define a simple Python function that computes a vector field
# This simulates what radia_ngsolve does
call_count = [0]  # Use list to allow modification in nested function

def simple_field(mip):
    call_count[0] += 1
    # Get coordinates
    pnt = mip.point
    x, y, z = pnt[0], pnt[1], pnt[2]
    # Simple calculation (no Radia, just math)
    Bx = x * 0.1
    By = y * 0.1
    Bz = z * 0.1
    return (Bx, By, Bz)

cf = CoefficientFunction(simple_field, dims=(3,))

# Measure memory usage
process = psutil.Process()

def get_memory_mb():
    """Get current memory usage in MB"""
    return process.memory_info().rss / 1024 / 1024

print("Testing memory with repeated GridFunction.Set() calls...")
print()
print("Step    Memory (MB)   Delta (MB)   Notes")
print("-" * 60)

mem_start = get_memory_mb()
print(f"0       {mem_start:8.2f}       --         Initial")

# Perform 100 iterations of GridFunction.Set()
num_iterations = 100
mem_values = [mem_start]

for i in range(1, num_iterations + 1):
    # Force garbage collection before each iteration
    gc.collect()

    # Call GridFunction.Set() - this internally calls Evaluate() many times
    gf.Set(cf)

    # Measure memory after Set()
    mem_current = get_memory_mb()
    mem_delta = mem_current - mem_values[-1]
    mem_values.append(mem_current)

    # Print every 10 iterations
    if i % 10 == 0:
        total_increase = mem_current - mem_start
        print(f"{i:3d}     {mem_current:8.2f}    {mem_delta:+8.2f}    Total: +{total_increase:.2f} MB")

print()

# Final statistics
mem_end = get_memory_mb()
total_leak = mem_end - mem_start
avg_leak_per_iteration = total_leak / num_iterations

print("=" * 60)
print("Summary:")
print(f"  Mesh vertices:        {mesh.nv}")
print(f"  Iterations:           {num_iterations}")
print(f"  Total Evaluate calls: {call_count[0]}")
print(f"  Initial memory:       {mem_start:.2f} MB")
print(f"  Final memory:         {mem_end:.2f} MB")
print(f"  Total increase:       {total_leak:.2f} MB")
print(f"  Avg per iteration:    {avg_leak_per_iteration*1024:.1f} KB")
print()

# Verdict
if total_leak > 10.0:  # More than 10 MB leak
    print(f"[FAIL] Significant memory leak in NGSolve GridFunction.Set(): {total_leak:.2f} MB")
    print(f"       This suggests the leak is in NGSolve itself, not radia_ngsolve")
elif total_leak > 1.0:  # 1-10 MB
    print(f"[WARNING] Possible memory leak in NGSolve: {total_leak:.2f} MB")
    print(f"          May be normal GC behavior or NGSolve internals")
else:
    print(f"[PASS] No significant memory leak: {total_leak:.2f} MB")
    print(f"       NGSolve memory management appears correct")

print("=" * 60)
