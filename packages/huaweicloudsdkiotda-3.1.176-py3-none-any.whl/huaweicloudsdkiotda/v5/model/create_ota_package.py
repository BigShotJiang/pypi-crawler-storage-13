# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateOtaPackage:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'app_id': 'str',
        'package_type': 'str',
        'product_id': 'str',
        'module_name': 'str',
        'version': 'str',
        'support_source_versions': 'list[str]',
        'description': 'str',
        'custom_info': 'str',
        'file_location': 'FileLocation'
    }

    attribute_map = {
        'app_id': 'app_id',
        'package_type': 'package_type',
        'product_id': 'product_id',
        'module_name': 'module_name',
        'version': 'version',
        'support_source_versions': 'support_source_versions',
        'description': 'description',
        'custom_info': 'custom_info',
        'file_location': 'file_location'
    }

    def __init__(self, app_id=None, package_type=None, product_id=None, module_name=None, version=None, support_source_versions=None, description=None, custom_info=None, file_location=None):
        r"""CreateOtaPackage

        The model defined in huaweicloud sdk

        :param app_id: **参数说明**：资源空间ID。存在多资源空间的用户需要使用该接口时，建议携带该参数指定创建的升级包归属到哪个资源空间下。 **取值范围**：长度不超过36，只允许字母、数字、下划线（_）、连接符（-）的组合。
        :type app_id: str
        :param package_type: **参数说明**：升级包类型。 **取值范围**：软件包必须设置为：softwarePackage，固件包必须设置为：firmwarePackage, 模块包必须设置为：modulePackage。
        :type package_type: str
        :param product_id: **参数说明**：设备关联的产品ID，用于唯一标识一个产品模型，创建产品后获得。方法请参见 [[创建产品](https://support.huaweicloud.com/api-iothub/iot_06_v5_0050.html)](tag:hws)[[创建产品](https://support.huaweicloud.com/intl/zh-cn/api-iothub/iot_06_v5_0050.html)](tag:hws_hk)。 **取值范围**：长度不超过36，只允许字母、数字、下划线（_）、连接符（-）的组合。
        :type product_id: str
        :param module_name: **参数说明**：OTA模块名称，产品下唯一且不可修改。当package_type为modulePackage时，支持该参数 **取值范围**：长度不超过64，只允许英文字母、数字、下划线（_）、连接符（-）、英文点（.）的组合。
        :type module_name: str
        :param version: **参数说明**：升级包版本号。 **取值范围**：长度不超过256，只允许字母、数字、下划线（_）、连接符（-）、英文点（.）的组合。
        :type version: str
        :param support_source_versions: **参数说明**：支持用于升级此版本包的设备源版本号列表。最多支持20个源版本号。 **取值范围**：源版本号列表，源版本号只允许字母、数字、下划线（_）、连接符（-）、英文点（.）的组合。
        :type support_source_versions: list[str]
        :param description: **参数说明**：用于描述升级包的功能等信息。 **取值范围**：长度不超过1024。
        :type description: str
        :param custom_info: **参数说明**：推送给设备的自定义信息。添加该升级包完成，并创建升级任务后，物联网平台向设备下发升级通知时，会下发该自定义信息给设备。 **取值范围**：长度不超过4096。
        :type custom_info: str
        :param file_location: 
        :type file_location: :class:`huaweicloudsdkiotda.v5.FileLocation`
        """
        
        

        self._app_id = None
        self._package_type = None
        self._product_id = None
        self._module_name = None
        self._version = None
        self._support_source_versions = None
        self._description = None
        self._custom_info = None
        self._file_location = None
        self.discriminator = None

        self.app_id = app_id
        self.package_type = package_type
        self.product_id = product_id
        if module_name is not None:
            self.module_name = module_name
        self.version = version
        if support_source_versions is not None:
            self.support_source_versions = support_source_versions
        if description is not None:
            self.description = description
        if custom_info is not None:
            self.custom_info = custom_info
        self.file_location = file_location

    @property
    def app_id(self):
        r"""Gets the app_id of this CreateOtaPackage.

        **参数说明**：资源空间ID。存在多资源空间的用户需要使用该接口时，建议携带该参数指定创建的升级包归属到哪个资源空间下。 **取值范围**：长度不超过36，只允许字母、数字、下划线（_）、连接符（-）的组合。

        :return: The app_id of this CreateOtaPackage.
        :rtype: str
        """
        return self._app_id

    @app_id.setter
    def app_id(self, app_id):
        r"""Sets the app_id of this CreateOtaPackage.

        **参数说明**：资源空间ID。存在多资源空间的用户需要使用该接口时，建议携带该参数指定创建的升级包归属到哪个资源空间下。 **取值范围**：长度不超过36，只允许字母、数字、下划线（_）、连接符（-）的组合。

        :param app_id: The app_id of this CreateOtaPackage.
        :type app_id: str
        """
        self._app_id = app_id

    @property
    def package_type(self):
        r"""Gets the package_type of this CreateOtaPackage.

        **参数说明**：升级包类型。 **取值范围**：软件包必须设置为：softwarePackage，固件包必须设置为：firmwarePackage, 模块包必须设置为：modulePackage。

        :return: The package_type of this CreateOtaPackage.
        :rtype: str
        """
        return self._package_type

    @package_type.setter
    def package_type(self, package_type):
        r"""Sets the package_type of this CreateOtaPackage.

        **参数说明**：升级包类型。 **取值范围**：软件包必须设置为：softwarePackage，固件包必须设置为：firmwarePackage, 模块包必须设置为：modulePackage。

        :param package_type: The package_type of this CreateOtaPackage.
        :type package_type: str
        """
        self._package_type = package_type

    @property
    def product_id(self):
        r"""Gets the product_id of this CreateOtaPackage.

        **参数说明**：设备关联的产品ID，用于唯一标识一个产品模型，创建产品后获得。方法请参见 [[创建产品](https://support.huaweicloud.com/api-iothub/iot_06_v5_0050.html)](tag:hws)[[创建产品](https://support.huaweicloud.com/intl/zh-cn/api-iothub/iot_06_v5_0050.html)](tag:hws_hk)。 **取值范围**：长度不超过36，只允许字母、数字、下划线（_）、连接符（-）的组合。

        :return: The product_id of this CreateOtaPackage.
        :rtype: str
        """
        return self._product_id

    @product_id.setter
    def product_id(self, product_id):
        r"""Sets the product_id of this CreateOtaPackage.

        **参数说明**：设备关联的产品ID，用于唯一标识一个产品模型，创建产品后获得。方法请参见 [[创建产品](https://support.huaweicloud.com/api-iothub/iot_06_v5_0050.html)](tag:hws)[[创建产品](https://support.huaweicloud.com/intl/zh-cn/api-iothub/iot_06_v5_0050.html)](tag:hws_hk)。 **取值范围**：长度不超过36，只允许字母、数字、下划线（_）、连接符（-）的组合。

        :param product_id: The product_id of this CreateOtaPackage.
        :type product_id: str
        """
        self._product_id = product_id

    @property
    def module_name(self):
        r"""Gets the module_name of this CreateOtaPackage.

        **参数说明**：OTA模块名称，产品下唯一且不可修改。当package_type为modulePackage时，支持该参数 **取值范围**：长度不超过64，只允许英文字母、数字、下划线（_）、连接符（-）、英文点（.）的组合。

        :return: The module_name of this CreateOtaPackage.
        :rtype: str
        """
        return self._module_name

    @module_name.setter
    def module_name(self, module_name):
        r"""Sets the module_name of this CreateOtaPackage.

        **参数说明**：OTA模块名称，产品下唯一且不可修改。当package_type为modulePackage时，支持该参数 **取值范围**：长度不超过64，只允许英文字母、数字、下划线（_）、连接符（-）、英文点（.）的组合。

        :param module_name: The module_name of this CreateOtaPackage.
        :type module_name: str
        """
        self._module_name = module_name

    @property
    def version(self):
        r"""Gets the version of this CreateOtaPackage.

        **参数说明**：升级包版本号。 **取值范围**：长度不超过256，只允许字母、数字、下划线（_）、连接符（-）、英文点（.）的组合。

        :return: The version of this CreateOtaPackage.
        :rtype: str
        """
        return self._version

    @version.setter
    def version(self, version):
        r"""Sets the version of this CreateOtaPackage.

        **参数说明**：升级包版本号。 **取值范围**：长度不超过256，只允许字母、数字、下划线（_）、连接符（-）、英文点（.）的组合。

        :param version: The version of this CreateOtaPackage.
        :type version: str
        """
        self._version = version

    @property
    def support_source_versions(self):
        r"""Gets the support_source_versions of this CreateOtaPackage.

        **参数说明**：支持用于升级此版本包的设备源版本号列表。最多支持20个源版本号。 **取值范围**：源版本号列表，源版本号只允许字母、数字、下划线（_）、连接符（-）、英文点（.）的组合。

        :return: The support_source_versions of this CreateOtaPackage.
        :rtype: list[str]
        """
        return self._support_source_versions

    @support_source_versions.setter
    def support_source_versions(self, support_source_versions):
        r"""Sets the support_source_versions of this CreateOtaPackage.

        **参数说明**：支持用于升级此版本包的设备源版本号列表。最多支持20个源版本号。 **取值范围**：源版本号列表，源版本号只允许字母、数字、下划线（_）、连接符（-）、英文点（.）的组合。

        :param support_source_versions: The support_source_versions of this CreateOtaPackage.
        :type support_source_versions: list[str]
        """
        self._support_source_versions = support_source_versions

    @property
    def description(self):
        r"""Gets the description of this CreateOtaPackage.

        **参数说明**：用于描述升级包的功能等信息。 **取值范围**：长度不超过1024。

        :return: The description of this CreateOtaPackage.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this CreateOtaPackage.

        **参数说明**：用于描述升级包的功能等信息。 **取值范围**：长度不超过1024。

        :param description: The description of this CreateOtaPackage.
        :type description: str
        """
        self._description = description

    @property
    def custom_info(self):
        r"""Gets the custom_info of this CreateOtaPackage.

        **参数说明**：推送给设备的自定义信息。添加该升级包完成，并创建升级任务后，物联网平台向设备下发升级通知时，会下发该自定义信息给设备。 **取值范围**：长度不超过4096。

        :return: The custom_info of this CreateOtaPackage.
        :rtype: str
        """
        return self._custom_info

    @custom_info.setter
    def custom_info(self, custom_info):
        r"""Sets the custom_info of this CreateOtaPackage.

        **参数说明**：推送给设备的自定义信息。添加该升级包完成，并创建升级任务后，物联网平台向设备下发升级通知时，会下发该自定义信息给设备。 **取值范围**：长度不超过4096。

        :param custom_info: The custom_info of this CreateOtaPackage.
        :type custom_info: str
        """
        self._custom_info = custom_info

    @property
    def file_location(self):
        r"""Gets the file_location of this CreateOtaPackage.

        :return: The file_location of this CreateOtaPackage.
        :rtype: :class:`huaweicloudsdkiotda.v5.FileLocation`
        """
        return self._file_location

    @file_location.setter
    def file_location(self, file_location):
        r"""Sets the file_location of this CreateOtaPackage.

        :param file_location: The file_location of this CreateOtaPackage.
        :type file_location: :class:`huaweicloudsdkiotda.v5.FileLocation`
        """
        self._file_location = file_location

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateOtaPackage):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
