# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListDeviceByDeviceCertificateResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'devices': 'list[DeviceSimple]',
        'page': 'Page'
    }

    attribute_map = {
        'devices': 'devices',
        'page': 'page'
    }

    def __init__(self, devices=None, page=None):
        r"""ListDeviceByDeviceCertificateResponse

        The model defined in huaweicloud sdk

        :param devices: 设备证书列表
        :type devices: list[:class:`huaweicloudsdkiotda.v5.DeviceSimple`]
        :param page: 
        :type page: :class:`huaweicloudsdkiotda.v5.Page`
        """
        
        super().__init__()

        self._devices = None
        self._page = None
        self.discriminator = None

        if devices is not None:
            self.devices = devices
        if page is not None:
            self.page = page

    @property
    def devices(self):
        r"""Gets the devices of this ListDeviceByDeviceCertificateResponse.

        设备证书列表

        :return: The devices of this ListDeviceByDeviceCertificateResponse.
        :rtype: list[:class:`huaweicloudsdkiotda.v5.DeviceSimple`]
        """
        return self._devices

    @devices.setter
    def devices(self, devices):
        r"""Sets the devices of this ListDeviceByDeviceCertificateResponse.

        设备证书列表

        :param devices: The devices of this ListDeviceByDeviceCertificateResponse.
        :type devices: list[:class:`huaweicloudsdkiotda.v5.DeviceSimple`]
        """
        self._devices = devices

    @property
    def page(self):
        r"""Gets the page of this ListDeviceByDeviceCertificateResponse.

        :return: The page of this ListDeviceByDeviceCertificateResponse.
        :rtype: :class:`huaweicloudsdkiotda.v5.Page`
        """
        return self._page

    @page.setter
    def page(self, page):
        r"""Sets the page of this ListDeviceByDeviceCertificateResponse.

        :param page: The page of this ListDeviceByDeviceCertificateResponse.
        :type page: :class:`huaweicloudsdkiotda.v5.Page`
        """
        self._page = page

    def to_dict(self):
        import warnings
        warnings.warn("ListDeviceByDeviceCertificateResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListDeviceByDeviceCertificateResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
