# Copyright (C) 2022-2025  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU General Public License version 3, or any later version
# See top-level LICENSE file for more information

pytest_plugins = [
    "swh.graph.pytest_plugin",
    "swh.storage.pytest_plugin",
    "swh.core.s3.pytest_plugin",
]
