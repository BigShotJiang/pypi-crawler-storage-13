import asyncio

from context_async_sqlalchemy import (
    atomic_db_session,
    close_db_session,
    commit_db_session,
    db_session,
    new_non_ctx_atomic_session,
    new_non_ctx_session,
    run_in_new_ctx,
)
from sqlalchemy import insert

from ..database import master
from ..models import ExampleTable


async def handler_multiple_sessions() -> None:
    """
    In some situations, you need to have multiple sessions running
        simultaneously. For example, to run several queries concurrently.
    """
    await asyncio.gather(
        _insert(),
        run_in_new_ctx(_insert),
        run_in_new_ctx(_insert_manual),
        _insert_non_ctx(),
        _insert_non_ctx_manual(),
    )


async def _insert() -> None:
    async with atomic_db_session(master) as session:
        stmt = insert(ExampleTable).values(text="example_multiple_sessions")
        await session.execute(stmt)


async def _insert_manual() -> None:
    session = await db_session(master)
    stmt = insert(ExampleTable).values(text="example_multiple_sessions")
    await session.execute(stmt)
    await commit_db_session(master)

    # You can manually close the session if you want, but it is not necessary
    await close_db_session(master)


async def _insert_non_ctx() -> None:
    async with new_non_ctx_atomic_session(master) as session:
        stmt = insert(ExampleTable).values(text="example_multiple_sessions")
        await session.execute(stmt)


async def _insert_non_ctx_manual() -> None:
    async with new_non_ctx_session(master) as session:
        stmt = insert(ExampleTable).values(text="example_multiple_sessions")
        await session.execute(stmt)
        await session.commit()
