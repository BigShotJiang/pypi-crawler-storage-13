# pydaasiot

[![PyPI version](https://img.shields.io/pypi/v/pydaasiot.svg)](https://pypi.org/project/pydaasiot/)
[![Python versions](https://img.shields.io/pypi/pyversions/pydaasiot.svg)](https://pypi.org/project/pydaasiot/)
[![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20Linux-blue.svg)](#-supported-platforms)
[![License](https://img.shields.io/badge/license-MPL--2.0-green.svg)](LICENSE)

**pydaasiot** are the official Python bindings for the **DaaS-IoT SDK**.  
They expose the full power of the Device-as-a-Service paradigm directly into Python, enabling fast integration of IoT communication primitives, overlay networking, and time synchronization.

---

## 🌐 Overview

The **DaaS-IoT SDK** is a high-performance library for distributed IoT environments.  
It provides an overlay communication model on top of TCP/IP, supports multiple network drivers, and integrates precise ATS (Accurate Time Synchronization) mechanisms.

The Python package `pydaasiot` allows developers and researchers to leverage these features without writing C++ code, simplifying prototyping and integration into data pipelines and services.

---

## ✨ Main Features

- Initialize and manage **DaaS-IoT nodes**.  
- Add and configure network drivers (currently **INET4** and **Bluetooth**; upcoming: Serial, USB, UART, MQTT).  
- Send and receive packets between devices.  
- Retrieve and manage ATS synchronization parameters.  
- Cross-platform: prebuilt wheels for **Windows (MSVC)** and **Linux (manylinux2014)**.

---

## 🚀 Installation

Install from PyPI with:

```bash
pip install pydaasiot
```

Wheels are available for Python 3.9 – 3.12.  
`pip` will automatically select the appropriate build for your system.

---

## 🧪 Quick Example

```python
import pydaasiot

# Initialize a DaaS-IoT node
node = pydaasiot.Node()
node.init()

# Add a network driver (example: IPv4 link)
node.add_driver(2, "127.0.0.1:5000")

# Send a packet
node.push(b"Hello from Python")

# Receive packets (non-blocking)
packets = node.pull()
print("Received:", packets)

# Access ATS parameters
ats = node.get_sync_params()
print("ATS:", ats)
```

---

## 🖥️ Supported Platforms

- **Windows** (x86_64, MSVC)  
- **Linux** (x86_64, manylinux2014)  

macOS support is planned for a future release.

---

## 📚 Documentation

- Full SDK documentation: [GitHub repository](https://github.com/your-org/pydaasiot)  
- Examples are available under `examples/` in the repository.

---

## 🤝 Contributing

Contributions are welcome!  
Please use GitHub issues and pull requests to propose improvements or report bugs.

---

## 📄 License

Released under the terms of the **Mozilla Public License 2.0 (MPL-2.0)**.  
See the [LICENSE](LICENSE) file for details.
