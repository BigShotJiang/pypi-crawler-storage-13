from __future__ import annotations
import time
import sys
import threading
import asyncio
import heapq
import zstandard
from enum import Enum
from typing import Any, Callable, TypeVar, ParamSpec, Optional
from collections import OrderedDict, defaultdict
from dataclasses import dataclass
from functools import wraps
import xxhash
import fasteners
import psutil
import pyinstrument
import msgspec

T = TypeVar('T')
P = ParamSpec('P')

class CacheStrategy(Enum):
    LRU = "lru"
    MRU = "mru"
    TTL = "ttl"
    LFU = "lfu"
    ARC = "arc"

@dataclass(frozen=True)
class CacheInfo:
    hits: int
    misses: int
    maxsize: int
    currsize: int
    strategy: CacheStrategy
    memory_used: int
    avg_response_time: float
    total_operations: int
    ttl: Optional[float] = None

class CompressionManager:
    __slots__ = ('_compressor', '_decompressor')
    
    def __init__(self):
        self._compressor = zstandard.ZstdCompressor(level=3, threads=0)
        self._decompressor = zstandard.ZstdDecompressor()
    
    def compress(self, data: bytes) -> bytes:
        return self._compressor.compress(data)
    
    def decompress(self, data: bytes) -> bytes:
        return self._decompressor.decompress(data)

_COMPRESSION_MANAGER = CompressionManager()

class CacheEntry:
    __slots__ = ("value", "timestamp", "access_count", "expires_at", "size", "compressed")

    def __init__(self, value: Any, ttl: Optional[float] = None, compress: bool = True):
        self.timestamp = time.perf_counter()
        self.access_count = 0
        self.expires_at = self.timestamp + ttl if ttl is not None else None
        self.compressed = False
        
        if compress:
            try:
                serialized = msgspec.msgpack.encode(value)
                if len(serialized) > 1024:
                    self.value = _COMPRESSION_MANAGER.compress(serialized)
                    self.compressed = True
                else:
                    self.value = value
            except Exception:
                self.value = value
        else:
            self.value = value
            
        self.size = sys.getsizeof(self.value)

    def get_value(self) -> Any:
        if self.compressed:
            try:
                decompressed = _COMPRESSION_MANAGER.decompress(self.value)
                return msgspec.msgpack.decode(decompressed)
            except Exception:
                return self.value
        return self.value

    def is_expired(self) -> bool:
        return self.expires_at is not None and time.perf_counter() > self.expires_at

    def touch(self):
        self.access_count += 1

def _convert_to_bytes(obj: Any) -> bytes:
    if obj is None:
        return b'None'
    elif isinstance(obj, bytes):
        return obj
    elif isinstance(obj, str):
        return obj.encode('utf-8')
    elif isinstance(obj, (int, float, bool)):
        return str(obj).encode('utf-8')
    else:
        try:
            return msgspec.msgpack.encode(obj)
        except Exception:
            return str(obj).encode('utf-8')

def _optimized_make_key(args, kwargs, typed):
    hasher = xxhash.xxh64()
    
    for arg in args:
        hasher.update(_convert_to_bytes(arg))
    
    for k, v in sorted(kwargs.items()):
        hasher.update(_convert_to_bytes(k))
        hasher.update(_convert_to_bytes(v))
    
    return hasher.digest()

class FastLockManager:
    def __init__(self, num_shards: int = 16):
        self._shards = [defaultdict(fasteners.ReaderWriterLock) for _ in range(num_shards)]
        self._global_lock = fasteners.ReaderWriterLock()
        self._num_shards = num_shards
    
    def _get_shard(self, key: Any) -> int:
        if isinstance(key, bytes):
            return xxhash.xxh32(key).intdigest() % self._num_shards
        return hash(key) % self._num_shards
    
    def get_lock(self, key: Any = None) -> fasteners.ReaderWriterLock:
        if key is None:
            return self._global_lock
        
        shard_idx = self._get_shard(key)
        key_str = key.hex() if isinstance(key, bytes) else str(key)
        return self._shards[shard_idx][key_str]

class MemoryUsageTracker:
    __slots__ = ('_memory_threshold', '_check_interval', '_last_check', '_last_result')
    
    def __init__(self, memory_threshold: float = 0.8):
        self._memory_threshold = memory_threshold
        self._check_interval = 5.0
        self._last_check = 0.0
        self._last_result = False
    
    def should_evict(self) -> bool:
        current_time = time.time()
        if current_time - self._last_check < self._check_interval:
            return self._last_result
            
        self._last_check = current_time
        memory_percent = psutil.virtual_memory().percent / 100.0
        self._last_result = memory_percent > self._memory_threshold
        return self._last_result

class CacheBase:
    __slots__ = ('_cache', '_hits', '_misses', '_maxsize', '_strategy', '_lock_manager',
                 '_current_size', '_total_response_time', '_total_operations', '_memory_limit',
                 '_sample_counter', '_sample_rate', '_compress_threshold', '_memory_tracker', 
                 '_profiler', '_enable_profiling')

    def __init__(self, maxsize: Optional[int] = 128, strategy: CacheStrategy = CacheStrategy.LRU,
                 memory_limit: Optional[int] = None, compress: bool = True, enable_profiling: bool = False):
        self._lock_manager = FastLockManager()
        self._cache = {}
        self._hits = 0
        self._misses = 0
        self._maxsize = maxsize
        self._strategy = strategy
        self._current_size = 0
        self._total_response_time = 0.0
        self._total_operations = 0
        self._memory_limit = memory_limit or (psutil.virtual_memory().available * 0.1)
        self._sample_counter = 0
        self._sample_rate = 100
        self._compress_threshold = compress
        self._enable_profiling = enable_profiling
        self._profiler = pyinstrument.Profiler() if enable_profiling else None
        self._memory_tracker = MemoryUsageTracker()

    def _record_time(self, start_time: float) -> None:
        if start_time > 0:
            self._sample_counter += 1
            if self._sample_counter >= self._sample_rate:
                end_time = time.perf_counter()
                self._total_response_time += (end_time - start_time) * self._sample_rate
                self._total_operations += self._sample_rate
                self._sample_counter = 0

    def _make_fast_key(self, key: Any) -> bytes:
        return _convert_to_bytes(key)

    def get(self, key: Any) -> Any:
        if self._enable_profiling:
            self._profiler.start()
        
        start_time = time.perf_counter() if self._sample_counter == 0 else 0
        fast_key = self._make_fast_key(key)
        
        with self._lock_manager.get_lock(fast_key).read_lock():
            entry = self._cache.get(fast_key)
            if entry is None:
                self._misses += 1
                self._record_time(start_time)
                if self._enable_profiling:
                    self._profiler.stop()
                return None
            
            if entry.is_expired():
                self._remove_key(fast_key)
                self._misses += 1
                self._record_time(start_time)
                if self._enable_profiling:
                    self._profiler.stop()
                return None
            
            self._update_access(fast_key, entry)
            self._hits += 1
            value = entry.get_value()
            self._record_time(start_time)
            if self._enable_profiling:
                self._profiler.stop()
            return value

    def set(self, key: Any, value: Any, ttl: Optional[float] = None) -> None:
        if self._enable_profiling:
            self._profiler.start()
            
        start_time = time.perf_counter() if self._sample_counter == 0 else 0
        fast_key = self._make_fast_key(key)
        
        entry = CacheEntry(value, ttl, self._compress_threshold)
        entry_size = entry.size
        
        with self._lock_manager.get_lock(fast_key).write_lock():
            if fast_key in self._cache:
                self._remove_key(fast_key)
            
            if self._maxsize is not None and self._maxsize <= 0:
                return
            
            self._cache[fast_key] = entry
            self._current_size += entry_size
            self._update_access(fast_key, entry)
        
        self._evict_if_needed()
        self._record_time(start_time)
        
        if self._enable_profiling:
            self._profiler.stop()

    def _remove_key(self, key: bytes) -> None:
        if key in self._cache:
            entry = self._cache[key]
            del self._cache[key]
            self._current_size -= entry.size

    def _update_access(self, key: bytes, entry: CacheEntry) -> None:
        entry.touch()

    def _evict_if_needed(self) -> None:
        while self._should_evict() and self._cache:
            self._evict_one()

    def _evict_one(self) -> None:
        pass

    def _should_evict(self) -> bool:
        if self._maxsize is not None and len(self._cache) >= self._maxsize:
            return True
        if self._memory_limit is not None and self._current_size >= self._memory_limit:
            return True
        if self._memory_tracker.should_evict():
            return True
        return False

    def delete(self, key: Any) -> bool:
        if self._enable_profiling:
            self._profiler.start()
            
        start_time = time.perf_counter() if self._sample_counter == 0 else 0
        fast_key = self._make_fast_key(key)
        
        with self._lock_manager.get_lock(fast_key).write_lock():
            if fast_key in self._cache:
                self._remove_key(fast_key)
                self._record_time(start_time)
                if self._enable_profiling:
                    self._profiler.stop()
                return True
            
            self._record_time(start_time)
            if self._enable_profiling:
                self._profiler.stop()
            return False

    def clear(self) -> None:
        with self._lock_manager.get_lock().write_lock():
            self._cache.clear()
            self._hits = 0
            self._misses = 0
            self._current_size = 0
            self._total_response_time = 0.0
            self._total_operations = 0
            self._sample_counter = 0

    def info(self) -> CacheInfo:
        with self._lock_manager.get_lock().read_lock():
            avg_response_time = (self._total_response_time / self._total_operations 
                               if self._total_operations > 0 else 0.0)
            
            return CacheInfo(
                hits=self._hits,
                misses=self._misses,
                maxsize=self._maxsize or 0,
                currsize=len(self._cache),
                strategy=self._strategy,
                memory_used=self._current_size,
                avg_response_time=avg_response_time,
                total_operations=self._total_operations,
                ttl=None
            )

    def get_profile_stats(self) -> Optional[str]:
        if self._profiler:
            return self._profiler.output_text(unicode=True, color=True)
        return None

class HighPerformanceCache(CacheBase):
    __slots__ = ('_order',)

    def __init__(self, maxsize: Optional[int] = 128, strategy: CacheStrategy = CacheStrategy.LRU, 
                 memory_limit: Optional[int] = None, compress: bool = True, enable_profiling: bool = False):
        super().__init__(maxsize, strategy, memory_limit, compress, enable_profiling)
        self._order = OrderedDict()

    def _update_access(self, key: bytes, entry: CacheEntry) -> None:
        if self._strategy == CacheStrategy.LRU:
            if key in self._order:
                self._order.move_to_end(key)
            else:
                self._order[key] = True
        elif self._strategy == CacheStrategy.MRU:
            if key in self._order:
                self._order.move_to_end(key, last=False)
            else:
                self._order[key] = True

    def _remove_key(self, key: bytes) -> None:
        if key in self._order:
            del self._order[key]
        super()._remove_key(key)

    def _evict_one(self) -> None:
        if not self._order:
            return
            
        if self._strategy == CacheStrategy.LRU:
            key, _ = self._order.popitem(last=False)
        elif self._strategy == CacheStrategy.MRU:
            key, _ = self._order.popitem(last=True)
        
        if key in self._cache:
            super()._remove_key(key)

    def clear(self) -> None:
        with self._lock_manager.get_lock().write_lock():
            self._order.clear()
            super().clear()

class OptimizedLFUCache(CacheBase):
    __slots__ = ('_freq_nodes', '_min_freq', '_freq_dict')

    def __init__(self, maxsize: Optional[int] = 128, memory_limit: Optional[int] = None, 
                 compress: bool = True, enable_profiling: bool = False):
        super().__init__(maxsize, CacheStrategy.LFU, memory_limit, compress, enable_profiling)
        self._freq_nodes = defaultdict(OrderedDict)
        self._min_freq = 1
        self._freq_dict = {}

    def _remove_key(self, key: bytes) -> None:
        if key in self._freq_dict:
            freq = self._freq_dict[key]
            if key in self._freq_nodes[freq]:
                del self._freq_nodes[freq][key]
                if not self._freq_nodes[freq]:
                    del self._freq_nodes[freq]
                    if freq == self._min_freq:
                        self._min_freq += 1
            del self._freq_dict[key]
        super()._remove_key(key)

    def _update_access(self, key: bytes, entry: CacheEntry) -> None:
        entry.touch()
        old_freq = self._freq_dict.get(key, 0)
        new_freq = old_freq + 1
        
        if old_freq > 0:
            if key in self._freq_nodes[old_freq]:
                del self._freq_nodes[old_freq][key]
                if not self._freq_nodes[old_freq]:
                    del self._freq_nodes[old_freq]
        
        self._freq_nodes[new_freq][key] = entry
        self._freq_dict[key] = new_freq
        
        if new_freq == 1:
            self._min_freq = 1

    def _evict_one(self) -> None:
        if not self._freq_nodes:
            return
            
        while self._min_freq not in self._freq_nodes and self._freq_nodes:
            self._min_freq = min(self._freq_nodes.keys())
            
        if self._min_freq in self._freq_nodes and self._freq_nodes[self._min_freq]:
            key, _ = self._freq_nodes[self._min_freq].popitem(last=False)
            if not self._freq_nodes[self._min_freq]:
                del self._freq_nodes[self._min_freq]
            if key in self._freq_dict:
                del self._freq_dict[key]
            if key in self._cache:
                super()._remove_key(key)

class TTLCache(CacheBase):
    __slots__ = ('_default_ttl', '_expiry_heap', '_access_heap', '_cleanup_thread', 
                 '_cleanup_interval', '_running', '_cleanup_event')

    def __init__(self, maxsize: Optional[int] = 128, default_ttl: Optional[float] = None, 
                 memory_limit: Optional[int] = None, cleanup_interval: float = 60.0, 
                 compress: bool = True, enable_profiling: bool = False):
        super().__init__(maxsize, CacheStrategy.TTL, memory_limit, compress, enable_profiling)
        self._default_ttl = default_ttl
        self._expiry_heap = []
        self._access_heap = []
        self._cleanup_interval = cleanup_interval
        self._running = True
        self._cleanup_event = threading.Event()
        
        self._cleanup_thread = threading.Thread(target=self._background_cleanup, daemon=True)
        self._cleanup_thread.start()

    def _background_cleanup(self) -> None:
        while self._running:
            self.cleanup_expired()
            self._cleanup_event.wait(timeout=self._cleanup_interval)

    def cleanup_expired(self) -> int:
        with self._lock_manager.get_lock().write_lock():
            now = time.perf_counter()
            expired_count = 0
            
            while self._expiry_heap and self._expiry_heap[0][0] <= now:
                expires_at, key = heapq.heappop(self._expiry_heap)
                if key in self._cache and self._cache[key].expires_at == expires_at:
                    if self._cache[key].is_expired():
                        super()._remove_key(key)
                        expired_count += 1
            
            return expired_count

    def set(self, key: Any, value: Any, ttl: Optional[float] = None) -> None:
        if self._enable_profiling:
            self._profiler.start()
            
        start_time = time.perf_counter() if self._sample_counter == 0 else 0
        fast_key = self._make_fast_key(key)
        
        with self._lock_manager.get_lock(fast_key).write_lock():
            if fast_key in self._cache:
                self._remove_key(fast_key)
            
            actual_ttl = ttl if ttl is not None else self._default_ttl
            entry = CacheEntry(value, actual_ttl, self._compress_threshold)
            entry_size = entry.size
            
            if self._maxsize is not None and self._maxsize <= 0:
                return
            
            self._cache[fast_key] = entry
            self._current_size += entry_size
            
            if actual_ttl is not None:
                heapq.heappush(self._expiry_heap, (entry.expires_at, fast_key))
            heapq.heappush(self._access_heap, (entry.timestamp, fast_key))
        
        self._evict_if_needed()
        self._record_time(start_time)
        
        if self._enable_profiling:
            self._profiler.stop()

    def _evict_one(self) -> None:
        if not self._access_heap:
            return
            
        while self._access_heap:
            _, key = heapq.heappop(self._access_heap)
            if key in self._cache:
                super()._remove_key(key)
                break

    def close(self) -> None:
        self._running = False
        self._cleanup_event.set()
        if self._cleanup_thread.is_alive():
            self._cleanup_thread.join(timeout=1.0)

    def info(self) -> CacheInfo:
        with self._lock_manager.get_lock().read_lock():
            base_info = super().info()
            return CacheInfo(
                hits=base_info.hits,
                misses=base_info.misses,
                maxsize=base_info.maxsize,
                currsize=base_info.currsize,
                strategy=base_info.strategy,
                memory_used=base_info.memory_used,
                avg_response_time=base_info.avg_response_time,
                total_operations=base_info.total_operations,
                ttl=self._default_ttl
            )

class ARCCache(CacheBase):
    __slots__ = ('_t1', '_t2', '_b1', '_b2', '_p', '_size')
    
    def __init__(self, maxsize: Optional[int] = 128, memory_limit: Optional[int] = None, 
                 compress: bool = True, enable_profiling: bool = False):
        super().__init__(maxsize, CacheStrategy.ARC, memory_limit, compress, enable_profiling)
        self._size = maxsize or 128
        self._t1 = OrderedDict()
        self._t2 = OrderedDict()
        self._b1 = OrderedDict()
        self._b2 = OrderedDict()
        self._p = 0

    def _remove_key(self, key: bytes) -> None:
        for cache_dict in [self._t1, self._t2, self._b1, self._b2]:
            if key in cache_dict:
                del cache_dict[key]
        super()._remove_key(key)

    def _update_access(self, key: bytes, entry: CacheEntry) -> None:
        entry.touch()
        if key in self._t1:
            del self._t1[key]
            self._t2[key] = entry
        elif key in self._t2:
            self._t2.move_to_end(key)

    def get(self, key: Any) -> Any:
        if self._enable_profiling:
            self._profiler.start()
            
        start_time = time.perf_counter() if self._sample_counter == 0 else 0
        fast_key = self._make_fast_key(key)
        
        with self._lock_manager.get_lock(fast_key).read_lock():
            entry = self._cache.get(fast_key)
            if entry is not None and not entry.is_expired():
                self._update_access(fast_key, entry)
                self._hits += 1
                value = entry.get_value()
                self._record_time(start_time)
                if self._enable_profiling:
                    self._profiler.stop()
                return value
            
            found_in_ghost = False
            if fast_key in self._b1:
                self._p = min(self._p + max(1, len(self._b2) // len(self._b1)), self._size)
                found_in_ghost = True
                self._b1.pop(fast_key)
            elif fast_key in self._b2:
                self._p = max(self._p - max(1, len(self._b1) // len(self._b2)), 0)
                found_in_ghost = True
                self._b2.pop(fast_key)
            
            if found_in_ghost:
                self._t2[fast_key] = entry
                self._hits += 1
                if entry:
                    value = entry.get_value()
                    self._record_time(start_time)
                    if self._enable_profiling:
                        self._profiler.stop()
                    return value
            
            self._misses += 1
            self._record_time(start_time)
            if self._enable_profiling:
                self._profiler.stop()
            return None

    def _replace(self, key: bytes) -> None:
        if len(self._t1) >= max(1, self._p):
            old_key, old_entry = self._t1.popitem(last=False)
            self._b1[old_key] = old_entry
            if old_key in self._cache:
                super()._remove_key(old_key)
        else:
            if self._t2:
                old_key, old_entry = self._t2.popitem(last=False)
                self._b2[old_key] = old_entry
                if old_key in self._cache:
                    super()._remove_key(old_key)

    def _evict_one(self) -> None:
        total_len = len(self._t1) + len(self._t2)
        if total_len == 0:
            return
            
        total_size = len(self._t1) + len(self._b1)
        if total_size >= self._size:
            if len(self._t1) < self._size:
                if self._b1:
                    self._b1.popitem(last=False)
                self._replace(None)
            else:
                key, _ = self._t1.popitem(last=False)
                if key in self._cache:
                    super()._remove_key(key)
        else:
            total_all = len(self._t1) + len(self._t2) + len(self._b1) + len(self._b2)
            if total_all >= 2 * self._size:
                if self._b1:
                    self._b1.popitem(last=False)
                elif self._b2:
                    self._b2.popitem(last=False)
            self._replace(None)

    def set(self, key: Any, value: Any, ttl: Optional[float] = None) -> None:
        if self._enable_profiling:
            self._profiler.start()
            
        start_time = time.perf_counter() if self._sample_counter == 0 else 0
        fast_key = self._make_fast_key(key)
        
        entry = CacheEntry(value, ttl, self._compress_threshold)
        
        with self._lock_manager.get_lock(fast_key).write_lock():
            if fast_key in self._cache:
                self._remove_key(fast_key)
            
            if self._maxsize is not None and self._maxsize <= 0:
                return
            
            self._cache[fast_key] = entry
            self._current_size += entry.size
            
            if fast_key in self._b1:
                self._b1.pop(fast_key)
                self._t2[fast_key] = entry
            elif fast_key in self._b2:
                self._b2.pop(fast_key)
                self._t2[fast_key] = entry
            else:
                self._t1[fast_key] = entry
        
        self._evict_if_needed()
        self._record_time(start_time)
        
        if self._enable_profiling:
            self._profiler.stop()

class AsyncCache:
    __slots__ = ('_cache', '_locks', '_strategy', '_num_shards')
    
    def __init__(self, maxsize: int = 128, strategy: CacheStrategy = CacheStrategy.LRU, 
                 compress: bool = True, enable_profiling: bool = False, num_shards: int = 8):
        self._strategy = strategy
        self._num_shards = num_shards
        self._locks = [asyncio.Lock() for _ in range(num_shards)]
        
        if strategy == CacheStrategy.ARC:
            self._cache = ARCCache(maxsize, compress=compress, enable_profiling=enable_profiling)
        elif strategy == CacheStrategy.LFU:
            self._cache = OptimizedLFUCache(maxsize, compress=compress, enable_profiling=enable_profiling)
        elif strategy == CacheStrategy.TTL:
            self._cache = TTLCache(maxsize, compress=compress, enable_profiling=enable_profiling)
        else:
            self._cache = HighPerformanceCache(maxsize, strategy, compress=compress, enable_profiling=enable_profiling)

    def _get_shard(self, key: Any) -> int:
        key_bytes = _convert_to_bytes(key)
        return xxhash.xxh32(key_bytes).intdigest() % self._num_shards

    async def get(self, key: Any) -> Any:
        shard = self._get_shard(key)
        async with self._locks[shard]:
            return self._cache.get(key)

    async def set(self, key: Any, value: Any, ttl: Optional[float] = None) -> None:
        shard = self._get_shard(key)
        async with self._locks[shard]:
            self._cache.set(key, value, ttl)

    async def delete(self, key: Any) -> bool:
        shard = self._get_shard(key)
        async with self._locks[shard]:
            return self._cache.delete(key)

    async def clear(self) -> None:
        async with self._locks[0]:
            self._cache.clear()

    async def info(self) -> CacheInfo:
        async with self._locks[0]:
            return self._cache.info()

_cache_registry = set()
_registry_lock = threading.RLock()

def cache(
    maxsize: Optional[int] = 128,
    ttl: Optional[float] = None,
    strategy: CacheStrategy | str = CacheStrategy.LRU,
    typed: bool = False,
    memory_limit: Optional[int] = None,
    compress: bool = True,
    enable_profiling: bool = False
):
    strategy_map = {
        "lru": CacheStrategy.LRU,
        "lfu": CacheStrategy.LFU,
        "mru": CacheStrategy.MRU,
        "ttl": CacheStrategy.TTL,
        "arc": CacheStrategy.ARC,
    }

    if isinstance(strategy, str):
        cache_strategy = strategy_map.get(strategy.lower(), CacheStrategy.LRU)
    else:
        cache_strategy = strategy
    
    def decorator(user_function: Callable[P, T]) -> Callable[P, T]:
        if cache_strategy == CacheStrategy.TTL or ttl is not None:
            cache_instance = TTLCache(maxsize, ttl, memory_limit, compress=compress, enable_profiling=enable_profiling)
        elif cache_strategy == CacheStrategy.LFU:
            cache_instance = OptimizedLFUCache(maxsize, memory_limit, compress=compress, enable_profiling=enable_profiling)
        elif cache_strategy == CacheStrategy.ARC:
            cache_instance = ARCCache(maxsize, memory_limit, compress=compress, enable_profiling=enable_profiling)
        else:
            cache_instance = HighPerformanceCache(maxsize, cache_strategy, memory_limit, compress=compress, enable_profiling=enable_profiling)
        
        with _registry_lock:
            _cache_registry.add(cache_instance)
        
        @wraps(user_function)
        def sync_wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            key = _optimized_make_key(args, kwargs, typed)
            
            cached_result = cache_instance.get(key)
            if cached_result is not None:
                return cached_result
            
            result = user_function(*args, **kwargs)
            cache_instance.set(key, result, ttl)
            return result
        
        @wraps(user_function)
        async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            key = _optimized_make_key(args, kwargs, typed)
            
            cached_result = cache_instance.get(key)
            if cached_result is not None:
                return cached_result
            
            result = user_function(*args, **kwargs)
            if asyncio.iscoroutine(result):
                result = await result
            
            cache_instance.set(key, result, ttl)
            return result
        
        wrapper = async_wrapper if asyncio.iscoroutinefunction(user_function) else sync_wrapper
        
        wrapper.cache_clear = cache_instance.clear
        wrapper.cache_info = cache_instance.info
        wrapper.cache_profile = cache_instance.get_profile_stats
        
        def cache_delete_wrapper(*args: P.args, **kwargs: P.kwargs) -> bool:
            key_to_delete = _optimized_make_key(args, kwargs, typed)
            return cache_instance.delete(key_to_delete)
        
        wrapper.cache_delete = cache_delete_wrapper
        
        if isinstance(cache_instance, TTLCache):
            wrapper.cleanup_expired = cache_instance.cleanup_expired
            wrapper.close = cache_instance.close
        
        return wrapper
    
    return decorator

def async_cache(
    maxsize: Optional[int] = 128,
    ttl: Optional[float] = None,
    strategy: CacheStrategy | str = CacheStrategy.LRU,
    typed: bool = False,
    compress: bool = True,
    enable_profiling: bool = False,
    num_shards: int = 8
):
    strategy_map = {
        "lru": CacheStrategy.LRU,
        "lfu": CacheStrategy.LFU,
        "mru": CacheStrategy.MRU,
        "ttl": CacheStrategy.TTL,
        "arc": CacheStrategy.ARC,
    }

    if isinstance(strategy, str):
        cache_strategy = strategy_map.get(strategy.lower(), CacheStrategy.LRU)
    else:
        cache_strategy = strategy
    
    def decorator(user_function: Callable[P, T]) -> Callable[P, T]:
        cache_instance = AsyncCache(maxsize, cache_strategy, compress, enable_profiling, num_shards)
        
        @wraps(user_function)
        async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            key = _optimized_make_key(args, kwargs, typed)
            
            cached_result = await cache_instance.get(key)
            if cached_result is not None:
                return cached_result
            
            result = user_function(*args, **kwargs)
            if asyncio.iscoroutinefunction(user_function):
                result = await result
            
            await cache_instance.set(key, result, ttl)
            return result
        
        async_wrapper.cache_clear = cache_instance.clear
        async_wrapper.cache_info = cache_instance.info
        async_wrapper.cache_delete = lambda *args, **kwargs: cache_instance.delete(
            _optimized_make_key(args, kwargs, typed)
        )
        
        return async_wrapper
    
    return decorator

class cached_property:
    __slots__ = ('_ttl', '_func', '_attrname', '_lock', '__doc__')

    def __init__(self, ttl: Optional[float] = None):
        self._ttl = ttl
        self._func = None
        self._attrname = None
        self._lock = threading.RLock()
        self.__doc__ = None

    def __call__(self, func: Callable) -> 'cached_property':
        self._func = func
        self.__doc__ = func.__doc__
        return self
    
    def __set_name__(self, owner, name):
        if self._attrname is None:
            self._attrname = name
        elif name != self._attrname:
            raise TypeError("Cannot assign cached_property to different names")
    
    def __get__(self, instance, owner=None):
        if instance is None:
            return self
        
        cache = instance.__dict__
        cache_key = f"_{self._attrname}_cached"
        cache_time_key = f"_{self._attrname}_timestamp"
        
        now = time.perf_counter()
        
        with self._lock:
            cached_value = cache.get(cache_key)
            cached_time = cache.get(cache_time_key, 0)
            
            is_valid = (cached_value is not None and 
                        (self._ttl is None or now - cached_time < self._ttl))
            
            if is_valid:
                return cached_value
            
            result = self._func(instance)
            
            cache[cache_key] = result
            cache[cache_time_key] = now
            return result
    
    def expire(self, instance) -> bool:
        cache_key = f"_{self._attrname}_cached"
        cache_time_key = f"_{self._attrname}_timestamp"
        
        with self._lock:
            deleted = False
            if cache_key in instance.__dict__:
                del instance.__dict__[cache_key]
                deleted = True
            if cache_time_key in instance.__dict__:
                del instance.__dict__[cache_time_key]
            return deleted

class AsyncCachedProperty:
    __slots__ = ('_ttl', '_func', '_attrname', '_lock', '__doc__')

    def __init__(self, ttl: Optional[float] = None):
        self._ttl = ttl
        self._func = None
        self._attrname = None
        self._lock = asyncio.Lock()
        self.__doc__ = None
    
    def __call__(self, func: Callable) -> 'AsyncCachedProperty':
        self._func = func
        self.__doc__ = func.__doc__
        return self
    
    def __set_name__(self, owner, name):
        if self._attrname is None:
            self._attrname = name
        elif name != self._attrname:
            raise TypeError("Cannot assign AsyncCachedProperty to different names")
    
    async def __get__(self, instance, owner=None):
        if instance is None:
            return self
        
        cache = instance.__dict__
        cache_key = f"_{self._attrname}_cached"
        cache_time_key = f"_{self._attrname}_timestamp"
        
        now = time.perf_counter()
        
        async with self._lock:
            cached_value = cache.get(cache_key)
            cached_time = cache.get(cache_time_key, 0)
            
            is_valid = (cached_value is not None and 
                        (self._ttl is None or now - cached_time < self._ttl))
            
            if is_valid:
                return cached_value
            
            result = self._func(instance)
            if asyncio.iscoroutine(result):
                result = await result
            
            cache[cache_key] = result
            cache[cache_time_key] = now
            return result
    
    def expire(self, instance) -> bool:
        cache_key = f"_{self._attrname}_cached"
        cache_time_key = f"_{self._attrname}_timestamp"
        
        deleted = False
        if cache_key in instance.__dict__:
            del instance.__dict__[cache_key]
            deleted = True
        if cache_time_key in instance.__dict__:
            del instance.__dict__[cache_time_key]
        return deleted

def cache_clear_all() -> None:
    with _registry_lock:
        for cache_instance in list(_cache_registry):
            try:
                cache_instance.clear()
            except Exception:
                pass

def get_cache_info() -> list[CacheInfo]:
    with _registry_lock:
        return [cache_instance.info() for cache_instance in list(_cache_registry)]

def get_global_stats() -> dict:
    all_info = get_cache_info()
    total_hits = sum(info.hits for info in all_info)
    total_misses = sum(info.misses for info in all_info)
    total_operations = sum(info.total_operations for info in all_info)
    total_memory = sum(info.memory_used for info in all_info)

    total_requests = total_hits + total_misses
    
    return {
        'total_caches': len(all_info),
        'total_hits': total_hits,
        'total_misses': total_misses,
        'total_operations': total_operations,
        'total_memory_bytes': total_memory,
        'total_memory_mb': total_memory / 1024 / 1024,
        'global_hit_rate': total_hits / total_requests if total_requests > 0 else 0,
        'avg_operations_per_cache': total_operations / len(all_info) if all_info else 0
    }

async def async_cache_clear_all() -> None:
    with _registry_lock:
        for cache_instance in list(_cache_registry):
            try:
                cache_instance.clear()
            except Exception:
                pass

async def async_get_cache_info() -> list[CacheInfo]:
    with _registry_lock:
        return [cache_instance.info() for cache_instance in list(_cache_registry)]

async def async_get_global_stats() -> dict:
    all_info = await async_get_cache_info()
    total_hits = sum(info.hits for info in all_info)
    total_misses = sum(info.misses for info in all_info)
    total_operations = sum(info.total_operations for info in all_info)
    total_memory = sum(info.memory_used for info in all_info)

    total_requests = total_hits + total_misses
    
    return {
        'total_caches': len(all_info),
        'total_hits': total_hits,
        'total_misses': total_misses,
        'total_operations': total_operations,
        'total_memory_bytes': total_memory,
        'total_memory_mb': total_memory / 1024 / 1024,
        'global_hit_rate': total_hits / total_requests if total_requests > 0 else 0,
        'avg_operations_per_cache': total_operations / len(all_info) if all_info else 0
    }