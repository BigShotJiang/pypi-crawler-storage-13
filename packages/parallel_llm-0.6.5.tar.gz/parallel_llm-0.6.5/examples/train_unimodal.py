"""
Training script for Unimodal (Text-only) Parallel-LLM using WikiText-2.
Demonstrates distributed training with FSDP, diffusion loss, and real-world data loading.
"""
import os
import sys
import torch
import torch.distributed as dist
from torch.utils.data import DataLoader, DistributedSampler
from transformers import AutoTokenizer
from datasets import load_dataset
from parallel_llm.core import DiffusionTransformer, ModelConfig
from parallel_llm.training import DistributedTrainer, TrainingConfig
from parallel_llm.utils import TextDataset

def setup_distributed():
    """Initialize distributed training environment"""
    if "LOCAL_RANK" in os.environ:
        dist.init_process_group(backend="nccl")
        local_rank = int(os.environ["LOCAL_RANK"])
        torch.cuda.set_device(local_rank)
        return local_rank
    else:
        print("Not running in distributed mode. Using CPU/Single GPU.")
        return 0

def main():
    print("="*60)
    print("Parallel-LLM Unimodal Training Example (WikiText-2)")
    print("="*60)

    # 1. Setup Distributed Environment
    local_rank = setup_distributed()
    is_main_process = local_rank == 0

    if is_main_process:
        print("Starting Unimodal Training")

    # 2. Configuration
    # Model Configuration (TinyLlama-1.1B dimensions)
    model_config = ModelConfig(
        vocab_size=32000,      # Will be updated after loading tokenizer
        hidden_size=2048,
        num_hidden_layers=22,
        num_attention_heads=32,
        num_diffusion_steps=64,
        use_flash_attention=True if torch.cuda.is_available() else False,
        dtype=torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float32
    )

    # Training Configuration
    train_config = TrainingConfig(
        output_dir="./checkpoints/unimodal_wikitext",
        num_train_steps=1000,
        batch_size=4,  # Adjust based on VRAM (4 fits on 16GB with grad checkpointing)
        learning_rate=3e-4,
        warmup_steps=100,
        use_fsdp=False, # Enable if multiple GPUs available
        mixed_precision="bf16" if torch.cuda.is_bf16_supported() else "fp16",
        gradient_checkpointing=True, # Save memory
        logging_steps=10,
        save_steps=500,
        eval_steps=200,
        use_torch_compile=True
    )

    # 3. Data Preparation
    if is_main_process:
        print("Loading tokenizer (TinyLlama)...")

    tokenizer = AutoTokenizer.from_pretrained("TinyLlama/TinyLlama-1.1B-Chat-v1.0")
    tokenizer.pad_token = tokenizer.eos_token
    model_config.vocab_size = tokenizer.vocab_size

    if is_main_process:
        print("Loading WikiText-2 dataset...")
    
    # Load streaming to avoid memory issues
    dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="train", streaming=True)
    
    # Take a subset for demo purposes (e.g., first 10k examples)
    dataset = dataset.take(10000)

    train_dataset = TextDataset(
        dataset=dataset,
        tokenizer=tokenizer,
        max_length=512
    )

    sampler = None
    if "LOCAL_RANK" in os.environ and dist.is_initialized():
        sampler = DistributedSampler(train_dataset)

    train_dataloader = DataLoader(
        train_dataset,
        batch_size=train_config.batch_size,
        sampler=sampler,
        shuffle=False, # Streaming dataset cannot be shuffled easily
        num_workers=2,
        pin_memory=True
    )

    # 4. Model Initialization
    if is_main_process:
        print("Initializing DiffusionTransformer model...")

    model = DiffusionTransformer(model_config)

    # 5. Trainer Initialization
    trainer = DistributedTrainer(
        model=model,
        train_config=train_config,
        model_config=model_config,
        train_dataloader=train_dataloader
    )

    # 6. Start Training
    if is_main_process:
        print("Starting training loop...")

    trainer.train()

    if is_main_process:
        print("Training complete!")

if __name__ == "__main__":
    main()
