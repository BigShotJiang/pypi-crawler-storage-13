"""Nav-Rewards Meta information."""

__title__ = "rewards"
__description__ = (
    "Framework for Sending Kudos and Rewards (Badges) to users. "
    "Supporting several rules and environment/context variables."
)
__version__ = "0.0.2"
__copyright__ = "Copyright (c) 2020-2025 Jesus Lara"
__author__ = "Jesus Lara"
__author_email__ = "jesuslarag@gmail.com"
__license__ = "MIT"
