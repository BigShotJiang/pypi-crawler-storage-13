# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import logging
import abc
from browserstack_sdk.sdk_cli.bstack1llllll111l_opy_ import bstack1llllll1111_opy_
class bstack1ll1ll111ll_opy_(abc.ABC):
    bin_session_id: str
    bstack1llllll111l_opy_: bstack1llllll1111_opy_
    def __init__(self):
        self.bstack1ll1l11ll1l_opy_ = None
        self.config = None
        self.bin_session_id = None
        self.bstack1llllll111l_opy_ = None
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)
    def bstack1ll1l1lll1l_opy_(self):
        return (self.bstack1ll1l11ll1l_opy_ != None and self.bin_session_id != None and self.bstack1llllll111l_opy_ != None)
    def configure(self, bstack1ll1l11ll1l_opy_, config, bin_session_id: str, bstack1llllll111l_opy_: bstack1llllll1111_opy_):
        self.bstack1ll1l11ll1l_opy_ = bstack1ll1l11ll1l_opy_
        self.config = config
        self.bin_session_id = bin_session_id
        self.bstack1llllll111l_opy_ = bstack1llllll111l_opy_
        if self.bin_session_id:
            self.logger.debug(bstack1111_opy_ (u"ࠨ࡛ࡼ࡫ࡧࠬࡸ࡫࡬ࡧࠫࢀࡡࠥࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡥࡥࠢࡰࡳࡩࡻ࡬ࡦࠢࡾࡷࡪࡲࡦ࠯ࡡࡢࡧࡱࡧࡳࡴࡡࡢ࠲ࡤࡥ࡮ࡢ࡯ࡨࡣࡤࢃ࠺ࠡࡤ࡬ࡲࡤࡹࡥࡴࡵ࡬ࡳࡳࡥࡩࡥ࠿ࠥእ") + str(self.bin_session_id) + bstack1111_opy_ (u"ࠢࠣኦ"))
    def bstack1l1llll1ll1_opy_(self):
        if not self.bin_session_id:
            raise ValueError(bstack1111_opy_ (u"ࠣࡤ࡬ࡲࡤࡹࡥࡴࡵ࡬ࡳࡳࡥࡩࡥࠢࡦࡥࡳࡴ࡯ࡵࠢࡥࡩࠥࡔ࡯࡯ࡧࠥኧ"))
    @abc.abstractmethod
    def is_enabled(self) -> bool:
        return False