# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import os
class RobotHandler():
    def __init__(self, args, logger, bstack11111l11l1_opy_, bstack1111111l11_opy_):
        self.args = args
        self.logger = logger
        self.bstack11111l11l1_opy_ = bstack11111l11l1_opy_
        self.bstack1111111l11_opy_ = bstack1111111l11_opy_
    @staticmethod
    def version():
        import robot
        return robot.__version__
    @staticmethod
    def bstack1111l1ll1l_opy_(bstack1llllll1l1l_opy_):
        bstack1llllll1ll1_opy_ = []
        if bstack1llllll1l1l_opy_:
            tokens = str(os.path.basename(bstack1llllll1l1l_opy_)).split(bstack1111_opy_ (u"ࠣࡡࠥკ"))
            camelcase_name = bstack1111_opy_ (u"ࠤࠣࠦლ").join(t.title() for t in tokens)
            suite_name, bstack1llllll1lll_opy_ = os.path.splitext(camelcase_name)
            bstack1llllll1ll1_opy_.append(suite_name)
        return bstack1llllll1ll1_opy_
    @staticmethod
    def bstack1lllllll111_opy_(typename):
        if bstack1111_opy_ (u"ࠥࡅࡸࡹࡥࡳࡶ࡬ࡳࡳࠨმ") in typename:
            return bstack1111_opy_ (u"ࠦࡆࡹࡳࡦࡴࡷ࡭ࡴࡴࡅࡳࡴࡲࡶࠧნ")
        return bstack1111_opy_ (u"࡛ࠧ࡮ࡩࡣࡱࡨࡱ࡫ࡤࡆࡴࡵࡳࡷࠨო")