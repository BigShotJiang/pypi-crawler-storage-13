# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import json
import multiprocessing
import os
from bstack_utils.config import Config
class bstack11lll1111l_opy_():
  def __init__(self, args, logger, bstack11111l11l1_opy_, bstack1111111l11_opy_, bstack1lllllll1l1_opy_):
    self.args = args
    self.logger = logger
    self.bstack11111l11l1_opy_ = bstack11111l11l1_opy_
    self.bstack1111111l11_opy_ = bstack1111111l11_opy_
    self.bstack1lllllll1l1_opy_ = bstack1lllllll1l1_opy_
  def bstack1l1l11l1ll_opy_(self, bstack1lllllllll1_opy_, bstack1lll1l111_opy_, bstack1lllllll11l_opy_=False):
    bstack1lll1l1l1l_opy_ = []
    manager = multiprocessing.Manager()
    bstack111111l11l_opy_ = manager.list()
    bstack1l1l11ll11_opy_ = Config.bstack11l11l11l_opy_()
    if bstack1lllllll11l_opy_:
      for index, platform in enumerate(self.bstack11111l11l1_opy_[bstack1111_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫგ")]):
        if index == 0:
          bstack1lll1l111_opy_[bstack1111_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬდ")] = self.args
        bstack1lll1l1l1l_opy_.append(multiprocessing.Process(name=str(index),
                                                    target=bstack1lllllllll1_opy_,
                                                    args=(bstack1lll1l111_opy_, bstack111111l11l_opy_)))
    else:
      for index, platform in enumerate(self.bstack11111l11l1_opy_[bstack1111_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ე")]):
        bstack1lll1l1l1l_opy_.append(multiprocessing.Process(name=str(index),
                                                    target=bstack1lllllllll1_opy_,
                                                    args=(bstack1lll1l111_opy_, bstack111111l11l_opy_)))
    i = 0
    for t in bstack1lll1l1l1l_opy_:
      try:
        if bstack1l1l11ll11_opy_.get_property(bstack1111_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬვ")):
          os.environ[bstack1111_opy_ (u"ࠬࡉࡕࡓࡔࡈࡒ࡙ࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡆࡄࡘࡆ࠭ზ")] = json.dumps(self.bstack11111l11l1_opy_[bstack1111_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩთ")][i % self.bstack1lllllll1l1_opy_])
      except Exception as e:
        self.logger.debug(bstack1111_opy_ (u"ࠢࡆࡴࡵࡳࡷࠦࡷࡩ࡫࡯ࡩࠥࡹࡴࡰࡴ࡬ࡲ࡬ࠦࡣࡶࡴࡵࡩࡳࡺࠠࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࠢࡧࡩࡹࡧࡩ࡭ࡵ࠽ࠤࢀࢃࠢი").format(str(e)))
      i += 1
      t.start()
    for t in bstack1lll1l1l1l_opy_:
      t.join()
    return list(bstack111111l11l_opy_)