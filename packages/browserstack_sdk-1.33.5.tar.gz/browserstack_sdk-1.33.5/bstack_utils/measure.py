# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import logging
from functools import wraps
from typing import Optional
from bstack_utils.constants import EVENTS, STAGE
from bstack_utils.bstack11l1lll1l_opy_ import get_logger
from bstack_utils.bstack11l1l1l1l1_opy_ import bstack1lll11lll11_opy_
bstack11l1l1l1l1_opy_ = bstack1lll11lll11_opy_()
logger = get_logger(__name__)
def measure(event_name: EVENTS, stage: STAGE, hook_type: Optional[str] = None, bstack11l111111_opy_: Optional[str] = None):
    bstack1111_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࡉ࡫ࡣࡰࡴࡤࡸࡴࡸࠠࡵࡱࠣࡰࡴ࡭ࠠࡵࡪࡨࠤࡸࡺࡡࡳࡶࠣࡸ࡮ࡳࡥࠡࡱࡩࠤࡦࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡࡧࡻࡩࡨࡻࡴࡪࡱࡱࠎࠥࠦࠠࠡࡣ࡯ࡳࡳ࡭ࠠࡸ࡫ࡷ࡬ࠥ࡫ࡶࡦࡰࡷࠤࡳࡧ࡭ࡦࠢࡤࡲࡩࠦࡳࡵࡣࡪࡩ࠳ࠐࠠࠡࠢࠣࠦࠧࠨṗ")
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            label: str = event_name.value
            bstack1l1llllll11_opy_: str = bstack11l1l1l1l1_opy_.bstack11ll1111l11_opy_(label)
            start_mark: str = label + bstack1111_opy_ (u"ࠧࡀࡳࡵࡣࡵࡸࠧṘ")
            end_mark: str = label + bstack1111_opy_ (u"ࠨ࠺ࡦࡰࡧࠦṙ")
            result = None
            try:
                if stage.value == STAGE.bstack1111l1l11_opy_.value:
                    bstack11l1l1l1l1_opy_.mark(start_mark)
                    result = func(*args, **kwargs)
                elif stage.value == STAGE.END.value:
                    result = func(*args, **kwargs)
                    bstack11l1l1l1l1_opy_.end(label, start_mark, end_mark, status=True, failure=None,hook_type=hook_type,test_name=bstack11l111111_opy_)
                elif stage.value == STAGE.bstack1l1l11111l_opy_.value:
                    start_mark: str = bstack1l1llllll11_opy_ + bstack1111_opy_ (u"ࠢ࠻ࡵࡷࡥࡷࡺࠢṚ")
                    end_mark: str = bstack1l1llllll11_opy_ + bstack1111_opy_ (u"ࠣ࠼ࡨࡲࡩࠨṛ")
                    bstack11l1l1l1l1_opy_.mark(start_mark)
                    result = func(*args, **kwargs)
                    bstack11l1l1l1l1_opy_.end(label, start_mark, end_mark, status=True, failure=None, hook_type=hook_type,test_name=bstack11l111111_opy_)
            except Exception as e:
                bstack11l1l1l1l1_opy_.end(label, start_mark, end_mark, status=False, failure=str(e), hook_type=hook_type,
                                       test_name=bstack11l111111_opy_)
            return result
        return wrapper
    return decorator