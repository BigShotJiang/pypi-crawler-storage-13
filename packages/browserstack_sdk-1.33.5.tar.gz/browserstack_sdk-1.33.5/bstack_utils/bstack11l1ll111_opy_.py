# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
from time import sleep
from datetime import datetime
from urllib.parse import urlencode
from bstack_utils.bstack11l1lll1l1l_opy_ import bstack11l1lll1lll_opy_
from bstack_utils.constants import *
import json
class bstack1l11ll11l_opy_:
    def __init__(self, bstack11ll11lll_opy_, bstack11l1llll111_opy_):
        self.bstack11ll11lll_opy_ = bstack11ll11lll_opy_
        self.bstack11l1llll111_opy_ = bstack11l1llll111_opy_
        self.bstack11l1llll11l_opy_ = None
    def __call__(self):
        bstack11l1lll1ll1_opy_ = {}
        while True:
            self.bstack11l1llll11l_opy_ = bstack11l1lll1ll1_opy_.get(
                bstack1111_opy_ (u"ࠫࡳ࡫ࡸࡵࡡࡳࡳࡱࡲ࡟ࡵ࡫ࡰࡩࠬ៎"),
                int(datetime.now().timestamp() * 1000)
            )
            bstack11l1lll11ll_opy_ = self.bstack11l1llll11l_opy_ - int(datetime.now().timestamp() * 1000)
            if bstack11l1lll11ll_opy_ > 0:
                sleep(bstack11l1lll11ll_opy_ / 1000)
            params = {
                bstack1111_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ៏"): self.bstack11ll11lll_opy_,
                bstack1111_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ័"): int(datetime.now().timestamp() * 1000)
            }
            bstack11l1lll1l11_opy_ = bstack1111_opy_ (u"ࠢࡩࡶࡷࡴࡸࡀ࠯࠰ࠤ៑") + bstack11l1lll11l1_opy_ + bstack1111_opy_ (u"ࠣ࠱ࡤࡹࡹࡵ࡭ࡢࡶࡨ࠳ࡦࡶࡩ࠰ࡸ࠴࠳្ࠧ")
            if self.bstack11l1llll111_opy_.lower() == bstack1111_opy_ (u"ࠤࡵࡩࡸࡻ࡬ࡵࡵࠥ៓"):
                bstack11l1lll1ll1_opy_ = bstack11l1lll1lll_opy_.results(bstack11l1lll1l11_opy_, params)
            else:
                bstack11l1lll1ll1_opy_ = bstack11l1lll1lll_opy_.bstack11l1lll111l_opy_(bstack11l1lll1l11_opy_, params)
            if str(bstack11l1lll1ll1_opy_.get(bstack1111_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪ។"), bstack1111_opy_ (u"ࠫ࠷࠶࠰ࠨ៕"))) != bstack1111_opy_ (u"ࠬ࠺࠰࠵ࠩ៖"):
                break
        return bstack11l1lll1ll1_opy_.get(bstack1111_opy_ (u"࠭ࡤࡢࡶࡤࠫៗ"), bstack11l1lll1ll1_opy_)