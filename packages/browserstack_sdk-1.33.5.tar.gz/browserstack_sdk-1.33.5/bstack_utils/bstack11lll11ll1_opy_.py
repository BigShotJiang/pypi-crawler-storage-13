# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import re
from bstack_utils.bstack11l1ll11_opy_ import bstack1lllll1ll1l1_opy_
def bstack1lllll1l1lll_opy_(fixture_name):
    if fixture_name.startswith(bstack1111_opy_ (u"ࠪࡣࡽࡻ࡮ࡪࡶࡢࡷࡪࡺࡵࡱࡡࡩࡹࡳࡩࡴࡪࡱࡱࡣ࡫࡯ࡸࡵࡷࡵࡩࠬ ")):
        return bstack1111_opy_ (u"ࠫࡸ࡫ࡴࡶࡲ࠰ࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ ")
    elif fixture_name.startswith(bstack1111_opy_ (u"ࠬࡥࡸࡶࡰ࡬ࡸࡤࡹࡥࡵࡷࡳࡣࡲࡵࡤࡶ࡮ࡨࡣ࡫࡯ࡸࡵࡷࡵࡩࠬ ")):
        return bstack1111_opy_ (u"࠭ࡳࡦࡶࡸࡴ࠲ࡳ࡯ࡥࡷ࡯ࡩࠬ ")
    elif fixture_name.startswith(bstack1111_opy_ (u"ࠧࡠࡺࡸࡲ࡮ࡺ࡟ࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡩࡹࡳࡩࡴࡪࡱࡱࡣ࡫࡯ࡸࡵࡷࡵࡩࠬ ")):
        return bstack1111_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰ࠰ࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ ")
    elif fixture_name.startswith(bstack1111_opy_ (u"ࠩࡢࡼࡺࡴࡩࡵࡡࡷࡩࡦࡸࡤࡰࡹࡱࡣ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡥࡦࡪࡺࡷࡹࡷ࡫ࠧ ")):
        return bstack1111_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲ࠲ࡳ࡯ࡥࡷ࡯ࡩࠬ ")
def bstack1lllll1l1l11_opy_(fixture_name):
    return bool(re.match(bstack1111_opy_ (u"ࠫࡣࡥࡸࡶࡰ࡬ࡸࡤ࠮ࡳࡦࡶࡸࡴࢁࡺࡥࡢࡴࡧࡳࡼࡴࠩࡠࠪࡩࡹࡳࡩࡴࡪࡱࡱࢀࡲࡵࡤࡶ࡮ࡨ࠭ࡤ࡬ࡩࡹࡶࡸࡶࡪࡥ࠮ࠫࠩ "), fixture_name))
def bstack1lllll1l1l1l_opy_(fixture_name):
    return bool(re.match(bstack1111_opy_ (u"ࠬࡤ࡟ࡹࡷࡱ࡭ࡹࡥࠨࡴࡧࡷࡹࡵࢂࡴࡦࡣࡵࡨࡴࡽ࡮ࠪࡡࡰࡳࡩࡻ࡬ࡦࡡࡩ࡭ࡽࡺࡵࡳࡧࡢ࠲࠯࠭ "), fixture_name))
def bstack1lllll1ll1ll_opy_(fixture_name):
    return bool(re.match(bstack1111_opy_ (u"࠭࡞ࡠࡺࡸࡲ࡮ࡺ࡟ࠩࡵࡨࡸࡺࡶࡼࡵࡧࡤࡶࡩࡵࡷ࡯ࠫࡢࡧࡱࡧࡳࡴࡡࡩ࡭ࡽࡺࡵࡳࡧࡢ࠲࠯࠭​"), fixture_name))
def bstack1lllll1l11l1_opy_(fixture_name):
    if fixture_name.startswith(bstack1111_opy_ (u"ࠧࡠࡺࡸࡲ࡮ࡺ࡟ࡴࡧࡷࡹࡵࡥࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡠࡨ࡬ࡼࡹࡻࡲࡦࠩ‌")):
        return bstack1111_opy_ (u"ࠨࡵࡨࡸࡺࡶ࠭ࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ‍"), bstack1111_opy_ (u"ࠩࡅࡉࡋࡕࡒࡆࡡࡈࡅࡈࡎࠧ‎")
    elif fixture_name.startswith(bstack1111_opy_ (u"ࠪࡣࡽࡻ࡮ࡪࡶࡢࡷࡪࡺࡵࡱࡡࡰࡳࡩࡻ࡬ࡦࡡࡩ࡭ࡽࡺࡵࡳࡧࠪ‏")):
        return bstack1111_opy_ (u"ࠫࡸ࡫ࡴࡶࡲ࠰ࡱࡴࡪࡵ࡭ࡧࠪ‐"), bstack1111_opy_ (u"ࠬࡈࡅࡇࡑࡕࡉࡤࡇࡌࡍࠩ‑")
    elif fixture_name.startswith(bstack1111_opy_ (u"࠭࡟ࡹࡷࡱ࡭ࡹࡥࡴࡦࡣࡵࡨࡴࡽ࡮ࡠࡨࡸࡲࡨࡺࡩࡰࡰࡢࡪ࡮ࡾࡴࡶࡴࡨࠫ‒")):
        return bstack1111_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯࠯ࡩࡹࡳࡩࡴࡪࡱࡱࠫ–"), bstack1111_opy_ (u"ࠨࡃࡉࡘࡊࡘ࡟ࡆࡃࡆࡌࠬ—")
    elif fixture_name.startswith(bstack1111_opy_ (u"ࠩࡢࡼࡺࡴࡩࡵࡡࡷࡩࡦࡸࡤࡰࡹࡱࡣࡲࡵࡤࡶ࡮ࡨࡣ࡫࡯ࡸࡵࡷࡵࡩࠬ―")):
        return bstack1111_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲ࠲ࡳ࡯ࡥࡷ࡯ࡩࠬ‖"), bstack1111_opy_ (u"ࠫࡆࡌࡔࡆࡔࡢࡅࡑࡒࠧ‗")
    return None, None
def bstack1lllll1llll1_opy_(hook_name):
    if hook_name in [bstack1111_opy_ (u"ࠬࡹࡥࡵࡷࡳࠫ‘"), bstack1111_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࠨ’")]:
        return hook_name.capitalize()
    return hook_name
def bstack1lllll1ll111_opy_(hook_name):
    if hook_name in [bstack1111_opy_ (u"ࠧࡴࡧࡷࡹࡵࡥࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ‚"), bstack1111_opy_ (u"ࠨࡵࡨࡸࡺࡶ࡟࡮ࡧࡷ࡬ࡴࡪࠧ‛")]:
        return bstack1111_opy_ (u"ࠩࡅࡉࡋࡕࡒࡆࡡࡈࡅࡈࡎࠧ“")
    elif hook_name in [bstack1111_opy_ (u"ࠪࡷࡪࡺࡵࡱࡡࡰࡳࡩࡻ࡬ࡦࠩ”"), bstack1111_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࡢࡧࡱࡧࡳࡴࠩ„")]:
        return bstack1111_opy_ (u"ࠬࡈࡅࡇࡑࡕࡉࡤࡇࡌࡍࠩ‟")
    elif hook_name in [bstack1111_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠࡨࡸࡲࡨࡺࡩࡰࡰࠪ†"), bstack1111_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡰࡩࡹ࡮࡯ࡥࠩ‡")]:
        return bstack1111_opy_ (u"ࠨࡃࡉࡘࡊࡘ࡟ࡆࡃࡆࡌࠬ•")
    elif hook_name in [bstack1111_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࡣࡲࡵࡤࡶ࡮ࡨࠫ‣"), bstack1111_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࡤࡩ࡬ࡢࡵࡶࠫ․")]:
        return bstack1111_opy_ (u"ࠫࡆࡌࡔࡆࡔࡢࡅࡑࡒࠧ‥")
    return hook_name
def bstack1lllll1ll11l_opy_(node, scenario):
    if hasattr(node, bstack1111_opy_ (u"ࠬࡩࡡ࡭࡮ࡶࡴࡪࡩࠧ…")):
        parts = node.nodeid.rsplit(bstack1111_opy_ (u"ࠨ࡛ࠣ‧"))
        params = parts[-1]
        return bstack1111_opy_ (u"ࠢࡼࡿࠣ࡟ࢀࢃࠢ ").format(scenario.name, params)
    return scenario.name
def bstack1lllll1lll11_opy_(node):
    try:
        examples = []
        if hasattr(node, bstack1111_opy_ (u"ࠨࡥࡤࡰࡱࡹࡰࡦࡥࠪ ")):
            examples = list(node.callspec.params[bstack1111_opy_ (u"ࠩࡢࡴࡾࡺࡥࡴࡶࡢࡦࡩࡪ࡟ࡦࡺࡤࡱࡵࡲࡥࠨ‪")].values())
        return examples
    except:
        return []
def bstack1lllll1l1ll1_opy_(feature, scenario):
    return list(feature.tags) + list(scenario.tags)
def bstack1lllll1lll1l_opy_(report):
    try:
        status = bstack1111_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ‫")
        if report.passed or (report.failed and hasattr(report, bstack1111_opy_ (u"ࠦࡼࡧࡳࡹࡨࡤ࡭ࡱࠨ‬"))):
            status = bstack1111_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬ‭")
        elif report.skipped:
            status = bstack1111_opy_ (u"࠭ࡳ࡬࡫ࡳࡴࡪࡪࠧ‮")
        bstack1lllll1ll1l1_opy_(status)
    except:
        pass
def bstack1lll1l11l1_opy_(status):
    try:
        bstack1lllll1l11ll_opy_ = bstack1111_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ ")
        if status == bstack1111_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨ‰"):
            bstack1lllll1l11ll_opy_ = bstack1111_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩ‱")
        elif status == bstack1111_opy_ (u"ࠪࡷࡰ࡯ࡰࡱࡧࡧࠫ′"):
            bstack1lllll1l11ll_opy_ = bstack1111_opy_ (u"ࠫࡸࡱࡩࡱࡲࡨࡨࠬ″")
        bstack1lllll1ll1l1_opy_(bstack1lllll1l11ll_opy_)
    except:
        pass
def bstack1lllll1lllll_opy_(item=None, report=None, summary=None, extra=None):
    return