# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import threading
import logging
logger = logging.getLogger(__name__)
bstack1lllll11ll11_opy_ = 1000
bstack1lllll1l111l_opy_ = 2
class bstack1lllll111lll_opy_:
    def __init__(self, handler, bstack1lllll1l1111_opy_=bstack1lllll11ll11_opy_, bstack1lllll11lll1_opy_=bstack1lllll1l111l_opy_):
        self.queue = []
        self.handler = handler
        self.bstack1lllll1l1111_opy_ = bstack1lllll1l1111_opy_
        self.bstack1lllll11lll1_opy_ = bstack1lllll11lll1_opy_
        self.lock = threading.Lock()
        self.timer = None
        self.bstack1llllll1l11_opy_ = None
    def start(self):
        if not (self.timer and self.timer.is_alive()):
            self.bstack1lllll11l1ll_opy_()
    def bstack1lllll11l1ll_opy_(self):
        self.bstack1llllll1l11_opy_ = threading.Event()
        def bstack1lllll11l111_opy_():
            self.bstack1llllll1l11_opy_.wait(self.bstack1lllll11lll1_opy_)
            if not self.bstack1llllll1l11_opy_.is_set():
                self.bstack1lllll11l11l_opy_()
        self.timer = threading.Thread(target=bstack1lllll11l111_opy_, daemon=True)
        self.timer.start()
    def bstack1lllll11llll_opy_(self):
        try:
            if self.bstack1llllll1l11_opy_ and not self.bstack1llllll1l11_opy_.is_set():
                self.bstack1llllll1l11_opy_.set()
            if self.timer and self.timer.is_alive() and self.timer != threading.current_thread():
                self.timer.join()
        except Exception as e:
            logger.debug(bstack1111_opy_ (u"ࠬࡡࡳࡵࡱࡳࡣࡹ࡯࡭ࡦࡴࡠࠤࡊࡾࡣࡦࡲࡷ࡭ࡴࡴ࠺ࠡࠩ‴") + (str(e) or bstack1111_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡦࡳࡺࡲࡤࠡࡰࡲࡸࠥࡨࡥࠡࡥࡲࡲࡻ࡫ࡲࡵࡧࡧࠤࡹࡵࠠࡴࡶࡵ࡭ࡳ࡭ࠢ‵")))
        finally:
            self.timer = None
    def bstack1lllll11ll1l_opy_(self):
        if self.timer:
            self.bstack1lllll11llll_opy_()
        self.bstack1lllll11l1ll_opy_()
    def add(self, event):
        with self.lock:
            self.queue.append(event)
            if len(self.queue) >= self.bstack1lllll1l1111_opy_:
                threading.Thread(target=self.bstack1lllll11l11l_opy_).start()
    def bstack1lllll11l11l_opy_(self, source = bstack1111_opy_ (u"ࠧࠨ‶")):
        with self.lock:
            if not self.queue:
                self.bstack1lllll11ll1l_opy_()
                return
            data = self.queue[:self.bstack1lllll1l1111_opy_]
            del self.queue[:self.bstack1lllll1l1111_opy_]
        self.handler(data)
        if source != bstack1111_opy_ (u"ࠨࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠪ‷"):
            self.bstack1lllll11ll1l_opy_()
    def shutdown(self):
        self.bstack1lllll11llll_opy_()
        while self.queue:
            self.bstack1lllll11l11l_opy_(source=bstack1111_opy_ (u"ࠩࡶ࡬ࡺࡺࡤࡰࡹࡱࠫ‸"))