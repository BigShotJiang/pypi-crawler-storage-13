# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import threading
from collections import deque
from bstack_utils.constants import *
class bstack1l11l1ll11_opy_:
    def __init__(self):
        self._1lllllll11ll_opy_ = deque()
        self._1lllllll1l11_opy_ = {}
        self._1llllllll1l1_opy_ = False
        self._lock = threading.RLock()
    def bstack1lllllllll1l_opy_(self, test_name, bstack1lllllll1l1l_opy_):
        with self._lock:
            bstack1llllllll111_opy_ = self._1lllllll1l11_opy_.get(test_name, {})
            return bstack1llllllll111_opy_.get(bstack1lllllll1l1l_opy_, 0)
    def bstack1lllllllll11_opy_(self, test_name, bstack1lllllll1l1l_opy_):
        with self._lock:
            bstack1llllllll1ll_opy_ = self.bstack1lllllllll1l_opy_(test_name, bstack1lllllll1l1l_opy_)
            self.bstack1lllllll1ll1_opy_(test_name, bstack1lllllll1l1l_opy_)
            return bstack1llllllll1ll_opy_
    def bstack1lllllll1ll1_opy_(self, test_name, bstack1lllllll1l1l_opy_):
        with self._lock:
            if test_name not in self._1lllllll1l11_opy_:
                self._1lllllll1l11_opy_[test_name] = {}
            bstack1llllllll111_opy_ = self._1lllllll1l11_opy_[test_name]
            bstack1llllllll1ll_opy_ = bstack1llllllll111_opy_.get(bstack1lllllll1l1l_opy_, 0)
            bstack1llllllll111_opy_[bstack1lllllll1l1l_opy_] = bstack1llllllll1ll_opy_ + 1
    def bstack11ll1lll11_opy_(self, bstack1lllllll111l_opy_, bstack1lllllll1lll_opy_):
        bstack1llllllll11l_opy_ = self.bstack1lllllllll11_opy_(bstack1lllllll111l_opy_, bstack1lllllll1lll_opy_)
        event_name = bstack11l1l111111_opy_[bstack1lllllll1lll_opy_]
        bstack1l1l111l111_opy_ = bstack1111_opy_ (u"ࠤࡾࢁ࠲ࢁࡽ࠮ࡽࢀࠦ῁").format(bstack1lllllll111l_opy_, event_name, bstack1llllllll11l_opy_)
        with self._lock:
            self._1lllllll11ll_opy_.append(bstack1l1l111l111_opy_)
    def bstack11ll11ll11_opy_(self):
        with self._lock:
            return len(self._1lllllll11ll_opy_) == 0
    def bstack11l11ll1l1_opy_(self):
        with self._lock:
            if self._1lllllll11ll_opy_:
                bstack1lllllll11l1_opy_ = self._1lllllll11ll_opy_.popleft()
                return bstack1lllllll11l1_opy_
            return None
    def capturing(self):
        with self._lock:
            return self._1llllllll1l1_opy_
    def bstack11ll11l1_opy_(self):
        with self._lock:
            self._1llllllll1l1_opy_ = True
    def bstack11lll11111_opy_(self):
        with self._lock:
            self._1llllllll1l1_opy_ = False