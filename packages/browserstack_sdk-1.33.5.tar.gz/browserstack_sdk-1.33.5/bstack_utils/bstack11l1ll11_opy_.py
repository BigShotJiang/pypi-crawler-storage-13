# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import json
import os
import threading
from bstack_utils.config import Config
from bstack_utils.constants import EVENTS, STAGE
from bstack_utils.helper import bstack11l1111l11l_opy_, bstack1l11l1lll1_opy_, bstack11lll1l11_opy_, bstack11l111l111_opy_, \
    bstack111lll1lll1_opy_
from bstack_utils.measure import measure
def bstack1l1l1lll1l_opy_(bstack1llll1ll1ll1_opy_):
    for driver in bstack1llll1ll1ll1_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
@measure(event_name=EVENTS.bstack1l1l1l1l1l_opy_, stage=STAGE.bstack1l1l11111l_opy_)
def bstack1llll1l111_opy_(driver, status, reason=bstack1111_opy_ (u"ࠪࠫ₆")):
    bstack1l1l11ll11_opy_ = Config.bstack11l11l11l_opy_()
    if bstack1l1l11ll11_opy_.bstack11111ll1ll_opy_():
        return
    bstack11l1lll1l1_opy_ = bstack1lllllllll_opy_(bstack1111_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠧ₇"), bstack1111_opy_ (u"ࠬ࠭₈"), status, reason, bstack1111_opy_ (u"࠭ࠧ₉"), bstack1111_opy_ (u"ࠧࠨ₊"))
    driver.execute_script(bstack11l1lll1l1_opy_)
@measure(event_name=EVENTS.bstack1l1l1l1l1l_opy_, stage=STAGE.bstack1l1l11111l_opy_)
def bstack1l111ll11l_opy_(page, status, reason=bstack1111_opy_ (u"ࠨࠩ₋")):
    try:
        if page is None:
            return
        bstack1l1l11ll11_opy_ = Config.bstack11l11l11l_opy_()
        if bstack1l1l11ll11_opy_.bstack11111ll1ll_opy_():
            return
        bstack11l1lll1l1_opy_ = bstack1lllllllll_opy_(bstack1111_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠬ₌"), bstack1111_opy_ (u"ࠪࠫ₍"), status, reason, bstack1111_opy_ (u"ࠫࠬ₎"), bstack1111_opy_ (u"ࠬ࠭₏"))
        page.evaluate(bstack1111_opy_ (u"ࠨ࡟ࠡ࠿ࡁࠤࢀࢃࠢₐ"), bstack11l1lll1l1_opy_)
    except Exception as e:
        print(bstack1111_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡵࡷࡥࡹࡻࡳࠡࡨࡲࡶࠥࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠢࡾࢁࠧₑ"), e)
def bstack1lllllllll_opy_(type, name, status, reason, bstack111l1ll11_opy_, bstack11l1l111_opy_):
    bstack1l11llll1l_opy_ = {
        bstack1111_opy_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮ࠨₒ"): type,
        bstack1111_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬₓ"): {}
    }
    if type == bstack1111_opy_ (u"ࠪࡥࡳࡴ࡯ࡵࡣࡷࡩࠬₔ"):
        bstack1l11llll1l_opy_[bstack1111_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧₕ")][bstack1111_opy_ (u"ࠬࡲࡥࡷࡧ࡯ࠫₖ")] = bstack111l1ll11_opy_
        bstack1l11llll1l_opy_[bstack1111_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩₗ")][bstack1111_opy_ (u"ࠧࡥࡣࡷࡥࠬₘ")] = json.dumps(str(bstack11l1l111_opy_))
    if type == bstack1111_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩₙ"):
        bstack1l11llll1l_opy_[bstack1111_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬₚ")][bstack1111_opy_ (u"ࠪࡲࡦࡳࡥࠨₛ")] = name
    if type == bstack1111_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠧₜ"):
        bstack1l11llll1l_opy_[bstack1111_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨ₝")][bstack1111_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭₞")] = status
        if status == bstack1111_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ₟") and str(reason) != bstack1111_opy_ (u"ࠣࠤ₠"):
            bstack1l11llll1l_opy_[bstack1111_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ₡")][bstack1111_opy_ (u"ࠪࡶࡪࡧࡳࡰࡰࠪ₢")] = json.dumps(str(reason))
    bstack11l111l11l_opy_ = bstack1111_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࡾࠩ₣").format(json.dumps(bstack1l11llll1l_opy_))
    return bstack11l111l11l_opy_
def bstack1l11l1l1ll_opy_(url, config, logger, bstack1ll1ll11l1_opy_=False):
    hostname = bstack1l11l1lll1_opy_(url)
    is_private = bstack11l111l111_opy_(hostname)
    try:
        if is_private or bstack1ll1ll11l1_opy_:
            file_path = bstack11l1111l11l_opy_(bstack1111_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬ₤"), bstack1111_opy_ (u"࠭࠮ࡣࡵࡷࡥࡨࡱ࠭ࡤࡱࡱࡪ࡮࡭࠮࡫ࡵࡲࡲࠬ₥"), logger)
            if os.environ.get(bstack1111_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡌࡐࡅࡄࡐࡤࡔࡏࡕࡡࡖࡉ࡙ࡥࡅࡓࡔࡒࡖࠬ₦")) and eval(
                    os.environ.get(bstack1111_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡍࡑࡆࡅࡑࡥࡎࡐࡖࡢࡗࡊ࡚࡟ࡆࡔࡕࡓࡗ࠭₧"))):
                return
            if (bstack1111_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭₨") in config and not config[bstack1111_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧ₩")]):
                os.environ[bstack1111_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡐࡔࡉࡁࡍࡡࡑࡓ࡙ࡥࡓࡆࡖࡢࡉࡗࡘࡏࡓࠩ₪")] = str(True)
                bstack1llll1ll1l1l_opy_ = {bstack1111_opy_ (u"ࠬ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠧ₫"): hostname}
                bstack111lll1lll1_opy_(bstack1111_opy_ (u"࠭࠮ࡣࡵࡷࡥࡨࡱ࠭ࡤࡱࡱࡪ࡮࡭࠮࡫ࡵࡲࡲࠬ€"), bstack1111_opy_ (u"ࠧ࡯ࡷࡧ࡫ࡪࡥ࡬ࡰࡥࡤࡰࠬ₭"), bstack1llll1ll1l1l_opy_, logger)
    except Exception as e:
        pass
def bstack11ll11ll1_opy_(caps, bstack1llll1ll1lll_opy_):
    if bstack1111_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩ₮") in caps:
        caps[bstack1111_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪ₯")][bstack1111_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࠩ₰")] = True
        if bstack1llll1ll1lll_opy_:
            caps[bstack1111_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬ₱")][bstack1111_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ₲")] = bstack1llll1ll1lll_opy_
    else:
        caps[bstack1111_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡲ࡯ࡤࡣ࡯ࠫ₳")] = True
        if bstack1llll1ll1lll_opy_:
            caps[bstack1111_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ₴")] = bstack1llll1ll1lll_opy_
def bstack1lllll1ll1l1_opy_(bstack111l1111l1_opy_):
    bstack1llll1lll111_opy_ = bstack11lll1l11_opy_(threading.current_thread(), bstack1111_opy_ (u"ࠨࡶࡨࡷࡹ࡙ࡴࡢࡶࡸࡷࠬ₵"), bstack1111_opy_ (u"ࠩࠪ₶"))
    if bstack1llll1lll111_opy_ == bstack1111_opy_ (u"ࠪࠫ₷") or bstack1llll1lll111_opy_ == bstack1111_opy_ (u"ࠫࡸࡱࡩࡱࡲࡨࡨࠬ₸"):
        threading.current_thread().testStatus = bstack111l1111l1_opy_
    else:
        if bstack111l1111l1_opy_ == bstack1111_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ₹"):
            threading.current_thread().testStatus = bstack111l1111l1_opy_