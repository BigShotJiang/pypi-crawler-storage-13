# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
from browserstack_sdk.bstack11l11l11_opy_ import bstack1111ll1l1_opy_
from browserstack_sdk.bstack1111lllll1_opy_ import RobotHandler
def bstack1l1l1lllll_opy_(framework):
    if framework.lower() == bstack1111_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬ᭤"):
        return bstack1111ll1l1_opy_.version()
    elif framework.lower() == bstack1111_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬ᭥"):
        return RobotHandler.version()
    elif framework.lower() == bstack1111_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧ᭦"):
        import behave
        return behave.__version__
    else:
        return bstack1111_opy_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ᭧")
def bstack11l1lll1_opy_():
    import importlib.metadata
    framework_name = []
    framework_version = []
    try:
        from selenium import webdriver
        framework_name.append(bstack1111_opy_ (u"ࠩࡶࡩࡱ࡫࡮ࡪࡷࡰࠫ᭨"))
        framework_version.append(importlib.metadata.version(bstack1111_opy_ (u"ࠥࡷࡪࡲࡥ࡯࡫ࡸࡱࠧ᭩")))
    except:
        pass
    try:
        import playwright
        framework_name.append(bstack1111_opy_ (u"ࠫࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠨ᭪"))
        framework_version.append(importlib.metadata.version(bstack1111_opy_ (u"ࠧࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠤ᭫")))
    except:
        pass
    return {
        bstack1111_opy_ (u"࠭࡮ࡢ࡯ࡨ᭬ࠫ"): bstack1111_opy_ (u"ࠧࡠࠩ᭭").join(framework_name),
        bstack1111_opy_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ᭮"): bstack1111_opy_ (u"ࠩࡢࠫ᭯").join(framework_version)
    }