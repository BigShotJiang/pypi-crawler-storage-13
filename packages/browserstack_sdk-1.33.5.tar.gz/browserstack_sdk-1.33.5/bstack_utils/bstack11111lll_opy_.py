# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
class bstack1l11ll1ll1_opy_:
    def __init__(self, handler):
        self._1llll1lll11l_opy_ = None
        self.handler = handler
        self._1llll1lll1ll_opy_ = self.bstack1llll1llll11_opy_()
        self.patch()
    def patch(self):
        self._1llll1lll11l_opy_ = self._1llll1lll1ll_opy_.execute
        self._1llll1lll1ll_opy_.execute = self.bstack1llll1lll1l1_opy_()
    def bstack1llll1lll1l1_opy_(self):
        def execute(this, driver_command, *args, **kwargs):
            self.handler(bstack1111_opy_ (u"ࠣࡤࡨࡪࡴࡸࡥࠣ₄"), driver_command, None, this, args)
            response = self._1llll1lll11l_opy_(this, driver_command, *args, **kwargs)
            self.handler(bstack1111_opy_ (u"ࠤࡤࡪࡹ࡫ࡲࠣ₅"), driver_command, response)
            return response
        return execute
    def reset(self):
        self._1llll1lll1ll_opy_.execute = self._1llll1lll11l_opy_
    @staticmethod
    def bstack1llll1llll11_opy_():
        from selenium.webdriver.remote.webdriver import WebDriver
        return WebDriver