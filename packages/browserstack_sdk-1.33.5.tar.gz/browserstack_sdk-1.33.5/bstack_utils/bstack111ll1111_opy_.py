# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
from bstack_utils.constants import bstack11l1llll1l1_opy_
def bstack1l11111ll1_opy_(bstack11l1llll1ll_opy_):
    from browserstack_sdk.sdk_cli.cli import cli
    from bstack_utils.helper import bstack1ll1l11l_opy_
    host = bstack1ll1l11l_opy_(cli.config, [bstack1111_opy_ (u"ࠢࡢࡲ࡬ࡷࠧ៊"), bstack1111_opy_ (u"ࠣࡣࡸࡸࡴࡳࡡࡵࡧࠥ់"), bstack1111_opy_ (u"ࠤࡤࡴ࡮ࠨ៌")], bstack11l1llll1l1_opy_)
    return bstack1111_opy_ (u"ࠪࡿࢂ࠵ࡻࡾࠩ៍").format(host, bstack11l1llll1ll_opy_)