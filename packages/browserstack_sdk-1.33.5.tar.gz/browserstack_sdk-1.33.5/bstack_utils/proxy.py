# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import os
from urllib.parse import urlparse
from bstack_utils.config import Config
from bstack_utils.messages import bstack111l111lll1_opy_
bstack1l1l11ll11_opy_ = Config.bstack11l11l11l_opy_()
def bstack1llllll11111_opy_(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False
def bstack1llllll11ll1_opy_(bstack1llllll11l1l_opy_, bstack1llllll1111l_opy_):
    from pypac import get_pac
    from pypac import PACSession
    from pypac.parser import PACFile
    import socket
    if os.path.isfile(bstack1llllll11l1l_opy_):
        with open(bstack1llllll11l1l_opy_) as f:
            pac = PACFile(f.read())
    elif bstack1llllll11111_opy_(bstack1llllll11l1l_opy_):
        pac = get_pac(url=bstack1llllll11l1l_opy_)
    else:
        raise Exception(bstack1111_opy_ (u"ࠧࡑࡣࡦࠤ࡫࡯࡬ࡦࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡪࡾࡩࡴࡶ࠽ࠤࢀࢃࠧΊ").format(bstack1llllll11l1l_opy_))
    session = PACSession(pac)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((bstack1111_opy_ (u"ࠣ࠺࠱࠼࠳࠾࠮࠹ࠤ῜"), 80))
        bstack1llllll111l1_opy_ = s.getsockname()[0]
        s.close()
    except:
        bstack1llllll111l1_opy_ = bstack1111_opy_ (u"ࠩ࠳࠲࠵࠴࠰࠯࠲ࠪ῝")
    proxy_url = session.get_pac().find_proxy_for_url(bstack1llllll1111l_opy_, bstack1llllll111l1_opy_)
    return proxy_url
def bstack1l1lll11_opy_(config):
    return bstack1111_opy_ (u"ࠪ࡬ࡹࡺࡰࡑࡴࡲࡼࡾ࠭῞") in config or bstack1111_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨ῟") in config
def bstack1lll1llll1_opy_(config):
    if not bstack1l1lll11_opy_(config):
        return
    if config.get(bstack1111_opy_ (u"ࠬ࡮ࡴࡵࡲࡓࡶࡴࡾࡹࠨῠ")):
        return config.get(bstack1111_opy_ (u"࠭ࡨࡵࡶࡳࡔࡷࡵࡸࡺࠩῡ"))
    if config.get(bstack1111_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼࠫῢ")):
        return config.get(bstack1111_opy_ (u"ࠨࡪࡷࡸࡵࡹࡐࡳࡱࡻࡽࠬΰ"))
def bstack1l111ll1ll_opy_(config, bstack1llllll1111l_opy_):
    proxy = bstack1lll1llll1_opy_(config)
    proxies = {}
    if config.get(bstack1111_opy_ (u"ࠩ࡫ࡸࡹࡶࡐࡳࡱࡻࡽࠬῤ")) or config.get(bstack1111_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࡒࡵࡳࡽࡿࠧῥ")):
        if proxy.endswith(bstack1111_opy_ (u"ࠫ࠳ࡶࡡࡤࠩῦ")):
            proxies = bstack1111llll1_opy_(proxy, bstack1llllll1111l_opy_)
        else:
            proxies = {
                bstack1111_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫῧ"): proxy
            }
    bstack1l1l11ll11_opy_.bstack1llll1111_opy_(bstack1111_opy_ (u"࠭ࡰࡳࡱࡻࡽࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠭Ῠ"), proxies)
    return proxies
def bstack1111llll1_opy_(bstack1llllll11l1l_opy_, bstack1llllll1111l_opy_):
    proxies = {}
    global bstack1llllll111ll_opy_
    if bstack1111_opy_ (u"ࠧࡑࡃࡆࡣࡕࡘࡏ࡙࡛ࠪῩ") in globals():
        return bstack1llllll111ll_opy_
    try:
        proxy = bstack1llllll11ll1_opy_(bstack1llllll11l1l_opy_, bstack1llllll1111l_opy_)
        if bstack1111_opy_ (u"ࠣࡆࡌࡖࡊࡉࡔࠣῪ") in proxy:
            proxies = {}
        elif bstack1111_opy_ (u"ࠤࡋࡘ࡙ࡖࠢΎ") in proxy or bstack1111_opy_ (u"ࠥࡌ࡙࡚ࡐࡔࠤῬ") in proxy or bstack1111_opy_ (u"ࠦࡘࡕࡃࡌࡕࠥ῭") in proxy:
            bstack1llllll11l11_opy_ = proxy.split(bstack1111_opy_ (u"ࠧࠦࠢ΅"))
            if bstack1111_opy_ (u"ࠨ࠺࠰࠱ࠥ`") in bstack1111_opy_ (u"ࠢࠣ῰").join(bstack1llllll11l11_opy_[1:]):
                proxies = {
                    bstack1111_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧ῱"): bstack1111_opy_ (u"ࠤࠥῲ").join(bstack1llllll11l11_opy_[1:])
                }
            else:
                proxies = {
                    bstack1111_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࠩῳ"): str(bstack1llllll11l11_opy_[0]).lower() + bstack1111_opy_ (u"ࠦ࠿࠵࠯ࠣῴ") + bstack1111_opy_ (u"ࠧࠨ῵").join(bstack1llllll11l11_opy_[1:])
                }
        elif bstack1111_opy_ (u"ࠨࡐࡓࡑ࡛࡝ࠧῶ") in proxy:
            bstack1llllll11l11_opy_ = proxy.split(bstack1111_opy_ (u"ࠢࠡࠤῷ"))
            if bstack1111_opy_ (u"ࠣ࠼࠲࠳ࠧῸ") in bstack1111_opy_ (u"ࠤࠥΌ").join(bstack1llllll11l11_opy_[1:]):
                proxies = {
                    bstack1111_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࠩῺ"): bstack1111_opy_ (u"ࠦࠧΏ").join(bstack1llllll11l11_opy_[1:])
                }
            else:
                proxies = {
                    bstack1111_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫῼ"): bstack1111_opy_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࠢ´") + bstack1111_opy_ (u"ࠢࠣ῾").join(bstack1llllll11l11_opy_[1:])
                }
        else:
            proxies = {
                bstack1111_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧ῿"): proxy
            }
    except Exception as e:
        print(bstack1111_opy_ (u"ࠤࡶࡳࡲ࡫ࠠࡦࡴࡵࡳࡷࠨ "), bstack111l111lll1_opy_.format(bstack1llllll11l1l_opy_, str(e)))
    bstack1llllll111ll_opy_ = proxies
    return proxies