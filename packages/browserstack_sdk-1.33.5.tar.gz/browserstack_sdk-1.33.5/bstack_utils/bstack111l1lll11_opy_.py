# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import json
import logging
import os
import datetime
import threading
from bstack_utils.constants import EVENTS, STAGE
from bstack_utils.helper import bstack11ll11llll1_opy_, bstack11ll1l1l1ll_opy_, bstack1l1l1ll11_opy_, error_handler, bstack111ll11llll_opy_, bstack111ll1l1l11_opy_, bstack111llllll11_opy_, bstack11l1111l11_opy_, bstack11lll1l11_opy_
from bstack_utils.measure import measure
from bstack_utils.bstack1lllll11l1l1_opy_ import bstack1lllll111lll_opy_
import bstack_utils.bstack1111111ll_opy_ as bstack1lll1l11ll_opy_
from bstack_utils.bstack111ll11l1l_opy_ import bstack11l11l1l1l_opy_
import bstack_utils.accessibility as bstack11l1111l1l_opy_
from bstack_utils.bstack111llll1l_opy_ import bstack111llll1l_opy_
from bstack_utils.bstack111l1ll111_opy_ import bstack111l1l1ll1_opy_
from bstack_utils.constants import bstack11l1l11lll_opy_
bstack1llll11l111l_opy_ = bstack1111_opy_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥࡲࡰࡱ࡫ࡣࡵࡱࡵ࠱ࡴࡨࡳࡦࡴࡹࡥࡧ࡯࡬ࡪࡶࡼ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡧࡴࡳࠧ⅀")
logger = logging.getLogger(__name__)
class bstack1ll1ll111_opy_:
    bstack1lllll11l1l1_opy_ = None
    bs_config = None
    bstack111l1l1ll_opy_ = None
    @classmethod
    @error_handler(class_method=True)
    @measure(event_name=EVENTS.bstack11l1l1ll11l_opy_, stage=STAGE.bstack1l1l11111l_opy_)
    def launch(cls, bs_config, bstack111l1l1ll_opy_):
        cls.bs_config = bs_config
        cls.bstack111l1l1ll_opy_ = bstack111l1l1ll_opy_
        try:
            cls.bstack1lll1lllllll_opy_()
            bstack11ll1l111l1_opy_ = bstack11ll11llll1_opy_(bs_config)
            bstack11ll11ll11l_opy_ = bstack11ll1l1l1ll_opy_(bs_config)
            data = bstack1lll1l11ll_opy_.bstack1llll11111l1_opy_(bs_config, bstack111l1l1ll_opy_)
            config = {
                bstack1111_opy_ (u"ࠨࡣࡸࡸ࡭࠭⅁"): (bstack11ll1l111l1_opy_, bstack11ll11ll11l_opy_),
                bstack1111_opy_ (u"ࠩ࡫ࡩࡦࡪࡥࡳࡵࠪ⅂"): cls.default_headers()
            }
            response = bstack1l1l1ll11_opy_(bstack1111_opy_ (u"ࠪࡔࡔ࡙ࡔࠨ⅃"), cls.request_url(bstack1111_opy_ (u"ࠫࡦࡶࡩ࠰ࡸ࠵࠳ࡧࡻࡩ࡭ࡦࡶࠫ⅄")), data, config)
            if response.status_code != 200:
                bstack1l1l111ll1_opy_ = response.json()
                if bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠬࡹࡵࡤࡥࡨࡷࡸ࠭ⅅ")] == False:
                    cls.bstack1llll111lll1_opy_(bstack1l1l111ll1_opy_)
                    return
                cls.bstack1llll1111l1l_opy_(bstack1l1l111ll1_opy_[bstack1111_opy_ (u"࠭࡯ࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠭ⅆ")])
                cls.bstack1lll1lllll11_opy_(bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧⅇ")])
                return None
            bstack1llll1111ll1_opy_ = cls.bstack1lll1llllll1_opy_(response)
            return bstack1llll1111ll1_opy_, response.json()
        except Exception as error:
            logger.error(bstack1111_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤࡼ࡮ࡩ࡭ࡧࠣࡧࡷ࡫ࡡࡵ࡫ࡱ࡫ࠥࡨࡵࡪ࡮ࡧࠤ࡫ࡵࡲࠡࡖࡨࡷࡹࡎࡵࡣ࠼ࠣࡿࢂࠨⅈ").format(str(error)))
            return None
    @classmethod
    @error_handler(class_method=True)
    def stop(cls, bstack1llll11111ll_opy_=None):
        if not bstack11l11l1l1l_opy_.on() and not bstack11l1111l1l_opy_.on():
            return
        if os.environ.get(bstack1111_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡍ࡛࡙࠭ⅉ")) == bstack1111_opy_ (u"ࠥࡲࡺࡲ࡬ࠣ⅊") or os.environ.get(bstack1111_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣ࡚࡛ࡉࡅࠩ⅋")) == bstack1111_opy_ (u"ࠧࡴࡵ࡭࡮ࠥ⅌"):
            logger.error(bstack1111_opy_ (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡹࡴࡰࡲࠣࡦࡺ࡯࡬ࡥࠢࡵࡩࡶࡻࡥࡴࡶࠣࡸࡴࠦࡔࡦࡵࡷࡌࡺࡨ࠺ࠡࡏ࡬ࡷࡸ࡯࡮ࡨࠢࡤࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡸࡴࡱࡥ࡯ࠩ⅍"))
            return {
                bstack1111_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧⅎ"): bstack1111_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧ⅏"),
                bstack1111_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪ⅐"): bstack1111_opy_ (u"ࠪࡘࡴࡱࡥ࡯࠱ࡥࡹ࡮ࡲࡤࡊࡆࠣ࡭ࡸࠦࡵ࡯ࡦࡨࡪ࡮ࡴࡥࡥ࠮ࠣࡦࡺ࡯࡬ࡥࠢࡦࡶࡪࡧࡴࡪࡱࡱࠤࡲ࡯ࡧࡩࡶࠣ࡬ࡦࡼࡥࠡࡨࡤ࡭ࡱ࡫ࡤࠨ⅑")
            }
        try:
            cls.bstack1lllll11l1l1_opy_.shutdown()
            data = {
                bstack1111_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩ⅒"): bstack11l1111l11_opy_()
            }
            if not bstack1llll11111ll_opy_ is None:
                data[bstack1111_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟࡮ࡧࡷࡥࡩࡧࡴࡢࠩ⅓")] = [{
                    bstack1111_opy_ (u"࠭ࡲࡦࡣࡶࡳࡳ࠭⅔"): bstack1111_opy_ (u"ࠧࡶࡵࡨࡶࡤࡱࡩ࡭࡮ࡨࡨࠬ⅕"),
                    bstack1111_opy_ (u"ࠨࡵ࡬࡫ࡳࡧ࡬ࠨ⅖"): bstack1llll11111ll_opy_
                }]
            config = {
                bstack1111_opy_ (u"ࠩ࡫ࡩࡦࡪࡥࡳࡵࠪ⅗"): cls.default_headers()
            }
            bstack11l1llll1ll_opy_ = bstack1111_opy_ (u"ࠪࡥࡵ࡯࠯ࡷ࠳࠲ࡦࡺ࡯࡬ࡥࡵ࠲ࡿࢂ࠵ࡳࡵࡱࡳࠫ⅘").format(os.environ[bstack1111_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣ࡚࡛ࡉࡅࠤ⅙")])
            bstack1llll111llll_opy_ = cls.request_url(bstack11l1llll1ll_opy_)
            response = bstack1l1l1ll11_opy_(bstack1111_opy_ (u"ࠬࡖࡕࡕࠩ⅚"), bstack1llll111llll_opy_, data, config)
            if not response.ok:
                raise Exception(bstack1111_opy_ (u"ࠨࡓࡵࡱࡳࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡴ࡯ࡵࠢࡲ࡯ࠧ⅛"))
        except Exception as error:
            logger.error(bstack1111_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡳࡵࡱࡳࠤࡧࡻࡩ࡭ࡦࠣࡶࡪࡷࡵࡦࡵࡷࠤࡹࡵࠠࡕࡧࡶࡸࡍࡻࡢ࠻࠼ࠣࠦ⅜") + str(error))
            return {
                bstack1111_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨ⅝"): bstack1111_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨ⅞"),
                bstack1111_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫ⅟"): str(error)
            }
    @classmethod
    @error_handler(class_method=True)
    def bstack1lll1llllll1_opy_(cls, response):
        bstack1l1l111ll1_opy_ = response.json() if not isinstance(response, dict) else response
        bstack1llll1111ll1_opy_ = {}
        if bstack1l1l111ll1_opy_.get(bstack1111_opy_ (u"ࠫ࡯ࡽࡴࠨⅠ")) is None:
            os.environ[bstack1111_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤࡐࡗࡕࠩⅡ")] = bstack1111_opy_ (u"࠭࡮ࡶ࡮࡯ࠫⅢ")
        else:
            os.environ[bstack1111_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡋ࡙ࡗࠫⅣ")] = bstack1l1l111ll1_opy_.get(bstack1111_opy_ (u"ࠨ࡬ࡺࡸࠬⅤ"), bstack1111_opy_ (u"ࠩࡱࡹࡱࡲࠧⅥ"))
        os.environ[bstack1111_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢ࡙࡚ࡏࡄࠨⅦ")] = bstack1l1l111ll1_opy_.get(bstack1111_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭Ⅷ"), bstack1111_opy_ (u"ࠬࡴࡵ࡭࡮ࠪⅨ"))
        logger.info(bstack1111_opy_ (u"࠭ࡔࡦࡵࡷ࡬ࡺࡨࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࡹ࡬ࡸ࡭ࠦࡩࡥ࠼ࠣࠫⅩ") + os.getenv(bstack1111_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡖࡗࡌࡈࠬⅪ")));
        if bstack11l11l1l1l_opy_.bstack1llll111111l_opy_(cls.bs_config, cls.bstack111l1l1ll_opy_.get(bstack1111_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡺࡹࡥࡥࠩⅫ"), bstack1111_opy_ (u"ࠩࠪⅬ"))) is True:
            bstack1lllll111111_opy_, build_hashed_id, bstack1llll1111lll_opy_ = cls.bstack1lll1llll1ll_opy_(bstack1l1l111ll1_opy_)
            if bstack1lllll111111_opy_ != None and build_hashed_id != None:
                bstack1llll1111ll1_opy_[bstack1111_opy_ (u"ࠪࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠪⅭ")] = {
                    bstack1111_opy_ (u"ࠫ࡯ࡽࡴࡠࡶࡲ࡯ࡪࡴࠧⅮ"): bstack1lllll111111_opy_,
                    bstack1111_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡣ࡭ࡧࡳࡩࡧࡧࡣ࡮ࡪࠧⅯ"): build_hashed_id,
                    bstack1111_opy_ (u"࠭ࡡ࡭࡮ࡲࡻࡤࡹࡣࡳࡧࡨࡲࡸ࡮࡯ࡵࡵࠪⅰ"): bstack1llll1111lll_opy_
                }
            else:
                bstack1llll1111ll1_opy_[bstack1111_opy_ (u"ࠧࡰࡤࡶࡩࡷࡼࡡࡣ࡫࡯࡭ࡹࡿࠧⅱ")] = {}
        else:
            bstack1llll1111ll1_opy_[bstack1111_opy_ (u"ࠨࡱࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹࠨⅲ")] = {}
        bstack1llll11l11l1_opy_, build_hashed_id = cls.bstack1llll111l1ll_opy_(bstack1l1l111ll1_opy_)
        if bstack1llll11l11l1_opy_ != None and build_hashed_id != None:
            bstack1llll1111ll1_opy_[bstack1111_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩⅳ")] = {
                bstack1111_opy_ (u"ࠪࡥࡺࡺࡨࡠࡶࡲ࡯ࡪࡴࠧⅴ"): bstack1llll11l11l1_opy_,
                bstack1111_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭ⅵ"): build_hashed_id,
            }
        else:
            bstack1llll1111ll1_opy_[bstack1111_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬⅶ")] = {}
        if bstack1llll1111ll1_opy_[bstack1111_opy_ (u"࠭࡯ࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠭ⅷ")].get(bstack1111_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩⅸ")) != None or bstack1llll1111ll1_opy_[bstack1111_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨⅹ")].get(bstack1111_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫⅺ")) != None:
            cls.bstack1llll1111l11_opy_(bstack1l1l111ll1_opy_.get(bstack1111_opy_ (u"ࠪ࡮ࡼࡺࠧⅻ")), bstack1l1l111ll1_opy_.get(bstack1111_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭ⅼ")))
        return bstack1llll1111ll1_opy_
    @classmethod
    def bstack1lll1llll1ll_opy_(cls, bstack1l1l111ll1_opy_):
        if bstack1l1l111ll1_opy_.get(bstack1111_opy_ (u"ࠬࡵࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽࠬⅽ")) == None:
            cls.bstack1llll1111l1l_opy_()
            return [None, None, None]
        if bstack1l1l111ll1_opy_[bstack1111_opy_ (u"࠭࡯ࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠭ⅾ")][bstack1111_opy_ (u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨⅿ")] != True:
            cls.bstack1llll1111l1l_opy_(bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠨࡱࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹࠨↀ")])
            return [None, None, None]
        logger.debug(bstack1111_opy_ (u"ࠩࡾࢁࠥࡈࡵࡪ࡮ࡧࠤࡨࡸࡥࡢࡶ࡬ࡳࡳࠦࡓࡶࡥࡦࡩࡸࡹࡦࡶ࡮ࠤࠫↁ").format(bstack11l1l11lll_opy_))
        os.environ[bstack1111_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡃࡗࡌࡐࡉࡥࡃࡐࡏࡓࡐࡊ࡚ࡅࡅࠩↂ")] = bstack1111_opy_ (u"ࠫࡹࡸࡵࡦࠩↃ")
        if bstack1l1l111ll1_opy_.get(bstack1111_opy_ (u"ࠬࡰࡷࡵࠩↄ")):
            os.environ[bstack1111_opy_ (u"࠭ࡃࡓࡇࡇࡉࡓ࡚ࡉࡂࡎࡖࡣࡋࡕࡒࡠࡅࡕࡅࡘࡎ࡟ࡓࡇࡓࡓࡗ࡚ࡉࡏࡉࠪↅ")] = json.dumps({
                bstack1111_opy_ (u"ࠧࡶࡵࡨࡶࡳࡧ࡭ࡦࠩↆ"): bstack11ll11llll1_opy_(cls.bs_config),
                bstack1111_opy_ (u"ࠨࡲࡤࡷࡸࡽ࡯ࡳࡦࠪↇ"): bstack11ll1l1l1ll_opy_(cls.bs_config)
            })
        if bstack1l1l111ll1_opy_.get(bstack1111_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫↈ")):
            os.environ[bstack1111_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡃࡗࡌࡐࡉࡥࡈࡂࡕࡋࡉࡉࡥࡉࡅࠩ↉")] = bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭↊")]
        if bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠬࡵࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽࠬ↋")].get(bstack1111_opy_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࡹࠧ↌"), {}).get(bstack1111_opy_ (u"ࠧࡢ࡮࡯ࡳࡼࡥࡳࡤࡴࡨࡩࡳࡹࡨࡰࡶࡶࠫ↍")):
            os.environ[bstack1111_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡇࡌࡍࡑ࡚ࡣࡘࡉࡒࡆࡇࡑࡗࡍࡕࡔࡔࠩ↎")] = str(bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠩࡲࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺࠩ↏")][bstack1111_opy_ (u"ࠪࡳࡵࡺࡩࡰࡰࡶࠫ←")][bstack1111_opy_ (u"ࠫࡦࡲ࡬ࡰࡹࡢࡷࡨࡸࡥࡦࡰࡶ࡬ࡴࡺࡳࠨ↑")])
        else:
            os.environ[bstack1111_opy_ (u"ࠬࡈࡓࡠࡖࡈࡗ࡙ࡕࡐࡔࡡࡄࡐࡑࡕࡗࡠࡕࡆࡖࡊࡋࡎࡔࡊࡒࡘࡘ࠭→")] = bstack1111_opy_ (u"ࠨ࡮ࡶ࡮࡯ࠦ↓")
        return [bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠧ࡫ࡹࡷࠫ↔")], bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠨࡤࡸ࡭ࡱࡪ࡟ࡩࡣࡶ࡬ࡪࡪ࡟ࡪࡦࠪ↕")], os.environ[bstack1111_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡁࡍࡎࡒ࡛ࡤ࡙ࡃࡓࡇࡈࡒࡘࡎࡏࡕࡕࠪ↖")]]
    @classmethod
    def bstack1llll111l1ll_opy_(cls, bstack1l1l111ll1_opy_):
        if bstack1l1l111ll1_opy_.get(bstack1111_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪ↗")) == None:
            cls.bstack1lll1lllll11_opy_()
            return [None, None]
        if bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫ↘")][bstack1111_opy_ (u"ࠬࡹࡵࡤࡥࡨࡷࡸ࠭↙")] != True:
            cls.bstack1lll1lllll11_opy_(bstack1l1l111ll1_opy_[bstack1111_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭↚")])
            return [None, None]
        if bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧ↛")].get(bstack1111_opy_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࡴࠩ↜")):
            logger.debug(bstack1111_opy_ (u"ࠩࡗࡩࡸࡺࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡃࡷ࡬ࡰࡩࠦࡣࡳࡧࡤࡸ࡮ࡵ࡮ࠡࡕࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࠦ࠭↝"))
            parsed = json.loads(os.getenv(bstack1111_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚࡟ࡂࡅࡆࡉࡘ࡙ࡉࡃࡋࡏࡍ࡙࡟࡟ࡄࡑࡑࡊࡎࡍࡕࡓࡃࡗࡍࡔࡔ࡟࡚ࡏࡏࠫ↞"), bstack1111_opy_ (u"ࠫࢀࢃࠧ↟")))
            capabilities = bstack1lll1l11ll_opy_.bstack1lll1llll11l_opy_(bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠬ↠")][bstack1111_opy_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࡹࠧ↡")][bstack1111_opy_ (u"ࠧࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭↢")], bstack1111_opy_ (u"ࠨࡰࡤࡱࡪ࠭↣"), bstack1111_opy_ (u"ࠩࡹࡥࡱࡻࡥࠨ↤"))
            bstack1llll11l11l1_opy_ = capabilities[bstack1111_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࡗࡳࡰ࡫࡮ࠨ↥")]
            os.environ[bstack1111_opy_ (u"ࠫࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠩ↦")] = bstack1llll11l11l1_opy_
            if bstack1111_opy_ (u"ࠧࡧࡵࡵࡱࡰࡥࡹ࡫ࠢ↧") in bstack1l1l111ll1_opy_ and bstack1l1l111ll1_opy_.get(bstack1111_opy_ (u"ࠨࡡࡱࡲࡢࡥࡺࡺ࡯࡮ࡣࡷࡩࠧ↨")) is None:
                parsed[bstack1111_opy_ (u"ࠧࡴࡥࡤࡲࡳ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨ↩")] = capabilities[bstack1111_opy_ (u"ࠨࡵࡦࡥࡳࡴࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩ↪")]
            os.environ[bstack1111_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡥࡁࡄࡅࡈࡗࡘࡏࡂࡊࡎࡌࡘ࡞ࡥࡃࡐࡐࡉࡍࡌ࡛ࡒࡂࡖࡌࡓࡓࡥ࡙ࡎࡎࠪ↫")] = json.dumps(parsed)
            scripts = bstack1lll1l11ll_opy_.bstack1lll1llll11l_opy_(bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠪ↬")][bstack1111_opy_ (u"ࠫࡴࡶࡴࡪࡱࡱࡷࠬ↭")][bstack1111_opy_ (u"ࠬࡹࡣࡳ࡫ࡳࡸࡸ࠭↮")], bstack1111_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ↯"), bstack1111_opy_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࠨ↰"))
            bstack111llll1l_opy_.bstack1llllll1l1_opy_(scripts)
            commands = bstack1l1l111ll1_opy_[bstack1111_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨ↱")][bstack1111_opy_ (u"ࠩࡲࡴࡹ࡯࡯࡯ࡵࠪ↲")][bstack1111_opy_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡷ࡙ࡵࡗࡳࡣࡳࠫ↳")].get(bstack1111_opy_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡸ࠭↴"))
            bstack111llll1l_opy_.bstack11ll11l1l1l_opy_(commands)
            bstack11ll11lll1l_opy_ = capabilities.get(bstack1111_opy_ (u"ࠬ࡭࡯ࡰࡩ࠽ࡧ࡭ࡸ࡯࡮ࡧࡒࡴࡹ࡯࡯࡯ࡵࠪ↵"))
            bstack111llll1l_opy_.bstack11l1llllll1_opy_(bstack11ll11lll1l_opy_)
            bstack111llll1l_opy_.store()
        return [bstack1llll11l11l1_opy_, bstack1l1l111ll1_opy_[bstack1111_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡤ࡮ࡡࡴࡪࡨࡨࡤ࡯ࡤࠨ↶")]]
    @classmethod
    def bstack1llll1111l1l_opy_(cls, response=None):
        os.environ[bstack1111_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡖࡗࡌࡈࠬ↷")] = bstack1111_opy_ (u"ࠨࡰࡸࡰࡱ࠭↸")
        os.environ[bstack1111_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡍ࡛࡙࠭↹")] = bstack1111_opy_ (u"ࠪࡲࡺࡲ࡬ࠨ↺")
        os.environ[bstack1111_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡄࡘࡍࡑࡊ࡟ࡄࡑࡐࡔࡑࡋࡔࡆࡆࠪ↻")] = bstack1111_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ↼")
        os.environ[bstack1111_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡆ࡚ࡏࡌࡅࡡࡋࡅࡘࡎࡅࡅࡡࡌࡈࠬ↽")] = bstack1111_opy_ (u"ࠢ࡯ࡷ࡯ࡰࠧ↾")
        os.environ[bstack1111_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡇࡌࡍࡑ࡚ࡣࡘࡉࡒࡆࡇࡑࡗࡍࡕࡔࡔࠩ↿")] = bstack1111_opy_ (u"ࠤࡱࡹࡱࡲࠢ⇀")
        cls.bstack1llll111lll1_opy_(response, bstack1111_opy_ (u"ࠥࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠥ⇁"))
        return [None, None, None]
    @classmethod
    def bstack1lll1lllll11_opy_(cls, response=None):
        os.environ[bstack1111_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣ࡚࡛ࡉࡅࠩ⇂")] = bstack1111_opy_ (u"ࠬࡴࡵ࡭࡮ࠪ⇃")
        os.environ[bstack1111_opy_ (u"࠭ࡂࡔࡡࡄ࠵࠶࡟࡟ࡋ࡙ࡗࠫ⇄")] = bstack1111_opy_ (u"ࠧ࡯ࡷ࡯ࡰࠬ⇅")
        os.environ[bstack1111_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡌ࡚ࡘࠬ⇆")] = bstack1111_opy_ (u"ࠩࡱࡹࡱࡲࠧ⇇")
        cls.bstack1llll111lll1_opy_(response, bstack1111_opy_ (u"ࠥࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠥ⇈"))
        return [None, None, None]
    @classmethod
    def bstack1llll1111l11_opy_(cls, jwt, build_hashed_id):
        os.environ[bstack1111_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡉࡗࡅࡣࡏ࡝ࡔࠨ⇉")] = jwt
        os.environ[bstack1111_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤ࡛ࡕࡊࡆࠪ⇊")] = build_hashed_id
    @classmethod
    def bstack1llll111lll1_opy_(cls, response=None, product=bstack1111_opy_ (u"ࠨࠢ⇋")):
        if response == None or response.get(bstack1111_opy_ (u"ࠧࡦࡴࡵࡳࡷࡹࠧ⇌")) == None:
            logger.error(product + bstack1111_opy_ (u"ࠣࠢࡅࡹ࡮ࡲࡤࠡࡥࡵࡩࡦࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠥ⇍"))
            return
        for error in response[bstack1111_opy_ (u"ࠩࡨࡶࡷࡵࡲࡴࠩ⇎")]:
            bstack111ll1l1111_opy_ = error[bstack1111_opy_ (u"ࠪ࡯ࡪࡿࠧ⇏")]
            error_message = error[bstack1111_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬ⇐")]
            if error_message:
                if bstack111ll1l1111_opy_ == bstack1111_opy_ (u"ࠧࡋࡒࡓࡑࡕࡣࡆࡉࡃࡆࡕࡖࡣࡉࡋࡎࡊࡇࡇࠦ⇑"):
                    logger.info(error_message)
                else:
                    logger.error(error_message)
            else:
                logger.error(bstack1111_opy_ (u"ࠨࡄࡢࡶࡤࠤࡺࡶ࡬ࡰࡣࡧࠤࡹࡵࠠࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠦࠢ⇒") + product + bstack1111_opy_ (u"ࠢࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡦࡸࡩࠥࡺ࡯ࠡࡵࡲࡱࡪࠦࡥࡳࡴࡲࡶࠧ⇓"))
    @classmethod
    def bstack1lll1lllllll_opy_(cls):
        if cls.bstack1lllll11l1l1_opy_ is not None:
            return
        cls.bstack1lllll11l1l1_opy_ = bstack1lllll111lll_opy_(cls.bstack1llll111l11l_opy_)
        cls.bstack1lllll11l1l1_opy_.start()
    @classmethod
    def bstack111l1l1lll_opy_(cls):
        if cls.bstack1lllll11l1l1_opy_ is None:
            return
        cls.bstack1lllll11l1l1_opy_.shutdown()
    @classmethod
    @error_handler(class_method=True)
    def bstack1llll111l11l_opy_(cls, bstack1111llll11_opy_, event_url=bstack1111_opy_ (u"ࠨࡣࡳ࡭࠴ࡼ࠱࠰ࡤࡤࡸࡨ࡮ࠧ⇔")):
        config = {
            bstack1111_opy_ (u"ࠩ࡫ࡩࡦࡪࡥࡳࡵࠪ⇕"): cls.default_headers()
        }
        logger.debug(bstack1111_opy_ (u"ࠥࡴࡴࡹࡴࡠࡦࡤࡸࡦࡀࠠࡔࡧࡱࡨ࡮ࡴࡧࠡࡦࡤࡸࡦࠦࡴࡰࠢࡷࡩࡸࡺࡨࡶࡤࠣࡪࡴࡸࠠࡦࡸࡨࡲࡹࡹࠠࡼࡿࠥ⇖").format(bstack1111_opy_ (u"ࠫ࠱ࠦࠧ⇗").join([event[bstack1111_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩ⇘")] for event in bstack1111llll11_opy_])))
        response = bstack1l1l1ll11_opy_(bstack1111_opy_ (u"࠭ࡐࡐࡕࡗࠫ⇙"), cls.request_url(event_url), bstack1111llll11_opy_, config)
        bstack11ll11ll1ll_opy_ = response.json()
    @classmethod
    def bstack1lll11lll1_opy_(cls, bstack1111llll11_opy_, event_url=bstack1111_opy_ (u"ࠧࡢࡲ࡬࠳ࡻ࠷࠯ࡣࡣࡷࡧ࡭࠭⇚")):
        logger.debug(bstack1111_opy_ (u"ࠣࡵࡨࡲࡩࡥࡤࡢࡶࡤ࠾ࠥࡇࡴࡵࡧࡰࡴࡹ࡯࡮ࡨࠢࡷࡳࠥࡧࡤࡥࠢࡧࡥࡹࡧࠠࡵࡱࠣࡦࡦࡺࡣࡩࠢࡺ࡭ࡹ࡮ࠠࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨ࠾ࠥࢁࡽࠣ⇛").format(bstack1111llll11_opy_[bstack1111_opy_ (u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭⇜")]))
        if not bstack1lll1l11ll_opy_.bstack1llll111ll1l_opy_(bstack1111llll11_opy_[bstack1111_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧ⇝")]):
            logger.debug(bstack1111_opy_ (u"ࠦࡸ࡫࡮ࡥࡡࡧࡥࡹࡧ࠺ࠡࡐࡲࡸࠥࡧࡤࡥ࡫ࡱ࡫ࠥࡪࡡࡵࡣࠣࡻ࡮ࡺࡨࠡࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩ࠿ࠦࡻࡾࠤ⇞").format(bstack1111llll11_opy_[bstack1111_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩ⇟")]))
            return
        bstack1l11l1l1l_opy_ = bstack1lll1l11ll_opy_.bstack1llll111l111_opy_(bstack1111llll11_opy_[bstack1111_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪ⇠")], bstack1111llll11_opy_.get(bstack1111_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࠩ⇡")))
        if bstack1l11l1l1l_opy_ != None:
            if bstack1111llll11_opy_.get(bstack1111_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࠪ⇢")) != None:
                bstack1111llll11_opy_[bstack1111_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࠫ⇣")][bstack1111_opy_ (u"ࠪࡴࡷࡵࡤࡶࡥࡷࡣࡲࡧࡰࠨ⇤")] = bstack1l11l1l1l_opy_
            else:
                bstack1111llll11_opy_[bstack1111_opy_ (u"ࠫࡵࡸ࡯ࡥࡷࡦࡸࡤࡳࡡࡱࠩ⇥")] = bstack1l11l1l1l_opy_
        if event_url == bstack1111_opy_ (u"ࠬࡧࡰࡪ࠱ࡹ࠵࠴ࡨࡡࡵࡥ࡫ࠫ⇦"):
            cls.bstack1lll1lllllll_opy_()
            logger.debug(bstack1111_opy_ (u"ࠨࡳࡦࡰࡧࡣࡩࡧࡴࡢ࠼ࠣࡅࡩࡪࡩ࡯ࡩࠣࡨࡦࡺࡡࠡࡶࡲࠤࡧࡧࡴࡤࡪࠣࡻ࡮ࡺࡨࠡࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩ࠿ࠦࡻࡾࠤ⇧").format(bstack1111llll11_opy_[bstack1111_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫ⇨")]))
            cls.bstack1lllll11l1l1_opy_.add(bstack1111llll11_opy_)
        elif event_url == bstack1111_opy_ (u"ࠨࡣࡳ࡭࠴ࡼ࠱࠰ࡵࡦࡶࡪ࡫࡮ࡴࡪࡲࡸࡸ࠭⇩"):
            cls.bstack1llll111l11l_opy_([bstack1111llll11_opy_], event_url)
    @classmethod
    @error_handler(class_method=True)
    def bstack11ll1ll1l1_opy_(cls, logs):
        for log in logs:
            bstack1llll11l1111_opy_ = {
                bstack1111_opy_ (u"ࠩ࡮࡭ࡳࡪࠧ⇪"): bstack1111_opy_ (u"ࠪࡘࡊ࡙ࡔࡠࡎࡒࡋࠬ⇫"),
                bstack1111_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪ⇬"): log[bstack1111_opy_ (u"ࠬࡲࡥࡷࡧ࡯ࠫ⇭")],
                bstack1111_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ⇮"): log[bstack1111_opy_ (u"ࠧࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪ⇯")],
                bstack1111_opy_ (u"ࠨࡪࡷࡸࡵࡥࡲࡦࡵࡳࡳࡳࡹࡥࠨ⇰"): {},
                bstack1111_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪ⇱"): log[bstack1111_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫ⇲")],
            }
            if bstack1111_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫ⇳") in log:
                bstack1llll11l1111_opy_[bstack1111_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ⇴")] = log[bstack1111_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭⇵")]
            elif bstack1111_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧ⇶") in log:
                bstack1llll11l1111_opy_[bstack1111_opy_ (u"ࠨࡪࡲࡳࡰࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨ⇷")] = log[bstack1111_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩ⇸")]
            cls.bstack1lll11lll1_opy_({
                bstack1111_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧ⇹"): bstack1111_opy_ (u"ࠫࡑࡵࡧࡄࡴࡨࡥࡹ࡫ࡤࠨ⇺"),
                bstack1111_opy_ (u"ࠬࡲ࡯ࡨࡵࠪ⇻"): [bstack1llll11l1111_opy_]
            })
    @classmethod
    @error_handler(class_method=True)
    def bstack1lll1llll1l1_opy_(cls, steps):
        bstack1llll111ll11_opy_ = []
        for step in steps:
            bstack1llll1111111_opy_ = {
                bstack1111_opy_ (u"࠭࡫ࡪࡰࡧࠫ⇼"): bstack1111_opy_ (u"ࠧࡕࡇࡖࡘࡤ࡙ࡔࡆࡒࠪ⇽"),
                bstack1111_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧ⇾"): step[bstack1111_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨ⇿")],
                bstack1111_opy_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭∀"): step[bstack1111_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ∁")],
                bstack1111_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭∂"): step[bstack1111_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧ∃")],
                bstack1111_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ∄"): step[bstack1111_opy_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ∅")]
            }
            if bstack1111_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩ∆") in step:
                bstack1llll1111111_opy_[bstack1111_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪ∇")] = step[bstack1111_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫ∈")]
            elif bstack1111_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ∉") in step:
                bstack1llll1111111_opy_[bstack1111_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭∊")] = step[bstack1111_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧ∋")]
            bstack1llll111ll11_opy_.append(bstack1llll1111111_opy_)
        cls.bstack1lll11lll1_opy_({
            bstack1111_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩࠬ∌"): bstack1111_opy_ (u"ࠩࡏࡳ࡬ࡉࡲࡦࡣࡷࡩࡩ࠭∍"),
            bstack1111_opy_ (u"ࠪࡰࡴ࡭ࡳࠨ∎"): bstack1llll111ll11_opy_
        })
    @classmethod
    @error_handler(class_method=True)
    @measure(event_name=EVENTS.bstack1lll11111l_opy_, stage=STAGE.bstack1l1l11111l_opy_)
    def bstack1l11l11lll_opy_(cls, screenshot):
        cls.bstack1lll11lll1_opy_({
            bstack1111_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨ∏"): bstack1111_opy_ (u"ࠬࡒ࡯ࡨࡅࡵࡩࡦࡺࡥࡥࠩ∐"),
            bstack1111_opy_ (u"࠭࡬ࡰࡩࡶࠫ∑"): [{
                bstack1111_opy_ (u"ࠧ࡬࡫ࡱࡨࠬ−"): bstack1111_opy_ (u"ࠨࡖࡈࡗ࡙ࡥࡓࡄࡔࡈࡉࡓ࡙ࡈࡐࡖࠪ∓"),
                bstack1111_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ∔"): datetime.datetime.utcnow().isoformat() + bstack1111_opy_ (u"ࠪ࡞ࠬ∕"),
                bstack1111_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬ∖"): screenshot[bstack1111_opy_ (u"ࠬ࡯࡭ࡢࡩࡨࠫ∗")],
                bstack1111_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭∘"): screenshot[bstack1111_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧ∙")]
            }]
        }, event_url=bstack1111_opy_ (u"ࠨࡣࡳ࡭࠴ࡼ࠱࠰ࡵࡦࡶࡪ࡫࡮ࡴࡪࡲࡸࡸ࠭√"))
    @classmethod
    @error_handler(class_method=True)
    def bstack11l1l1111l_opy_(cls, driver):
        current_test_uuid = cls.current_test_uuid()
        if not current_test_uuid:
            return
        cls.bstack1lll11lll1_opy_({
            bstack1111_opy_ (u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭∛"): bstack1111_opy_ (u"ࠪࡇࡇ࡚ࡓࡦࡵࡶ࡭ࡴࡴࡃࡳࡧࡤࡸࡪࡪࠧ∜"),
            bstack1111_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳ࠭∝"): {
                bstack1111_opy_ (u"ࠧࡻࡵࡪࡦࠥ∞"): cls.current_test_uuid(),
                bstack1111_opy_ (u"ࠨࡩ࡯ࡶࡨ࡫ࡷࡧࡴࡪࡱࡱࡷࠧ∟"): cls.bstack111ll1l11l_opy_(driver)
            }
        })
    @classmethod
    def bstack111ll111l1_opy_(cls, event: str, bstack1111llll11_opy_: bstack111l1l1ll1_opy_):
        bstack1111ll1111_opy_ = {
            bstack1111_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫ∠"): event,
            bstack1111llll11_opy_.bstack111l1l1111_opy_(): bstack1111llll11_opy_.bstack111l111lll_opy_(event)
        }
        cls.bstack1lll11lll1_opy_(bstack1111ll1111_opy_)
        result = getattr(bstack1111llll11_opy_, bstack1111_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ∡"), None)
        if event == bstack1111_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦࠪ∢"):
            threading.current_thread().bstackTestMeta = {bstack1111_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪ∣"): bstack1111_opy_ (u"ࠫࡵ࡫࡮ࡥ࡫ࡱ࡫ࠬ∤")}
        elif event == bstack1111_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳࡌࡩ࡯࡫ࡶ࡬ࡪࡪࠧ∥"):
            threading.current_thread().bstackTestMeta = {bstack1111_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭∦"): getattr(result, bstack1111_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧ∧"), bstack1111_opy_ (u"ࠨࠩ∨"))}
    @classmethod
    def on(cls):
        if (os.environ.get(bstack1111_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡖࡈࡗ࡙ࡎࡕࡃࡡࡍ࡛࡙࠭∩"), None) is None or os.environ[bstack1111_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚ࡈࡖࡄࡢࡎ࡜࡚ࠧ∪")] == bstack1111_opy_ (u"ࠦࡳࡻ࡬࡭ࠤ∫")) and (os.environ.get(bstack1111_opy_ (u"ࠬࡈࡓࡠࡃ࠴࠵࡞ࡥࡊࡘࡖࠪ∬"), None) is None or os.environ[bstack1111_opy_ (u"࠭ࡂࡔࡡࡄ࠵࠶࡟࡟ࡋ࡙ࡗࠫ∭")] == bstack1111_opy_ (u"ࠢ࡯ࡷ࡯ࡰࠧ∮")):
            return False
        return True
    @staticmethod
    def bstack1lll1lllll1l_opy_(func):
        def wrap(*args, **kwargs):
            if bstack1ll1ll111_opy_.on():
                return func(*args, **kwargs)
            return
        return wrap
    @staticmethod
    def default_headers():
        headers = {
            bstack1111_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ∯"): bstack1111_opy_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ∰"),
            bstack1111_opy_ (u"ࠪ࡜࠲ࡈࡓࡕࡃࡆࡏ࠲࡚ࡅࡔࡖࡒࡔࡘ࠭∱"): bstack1111_opy_ (u"ࠫࡹࡸࡵࡦࠩ∲")
        }
        if os.environ.get(bstack1111_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡊࡘࡆࡤࡐࡗࡕࠩ∳"), None):
            headers[bstack1111_opy_ (u"࠭ࡁࡶࡶ࡫ࡳࡷ࡯ࡺࡢࡶ࡬ࡳࡳ࠭∴")] = bstack1111_opy_ (u"ࠧࡃࡧࡤࡶࡪࡸࠠࡼࡿࠪ∵").format(os.environ[bstack1111_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡕࡇࡖࡘࡍ࡛ࡂࡠࡌ࡚ࡘࠧ∶")])
        return headers
    @staticmethod
    def request_url(url):
        return bstack1111_opy_ (u"ࠩࡾࢁ࠴ࢁࡽࠨ∷").format(bstack1llll11l111l_opy_, url)
    @staticmethod
    def current_test_uuid():
        return getattr(threading.current_thread(), bstack1111_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡࡸࡹ࡮ࡪࠧ∸"), None)
    @staticmethod
    def bstack111ll1l11l_opy_(driver):
        return {
            bstack111ll11llll_opy_(): bstack111ll1l1l11_opy_(driver)
        }
    @staticmethod
    def bstack1llll111l1l1_opy_(exception_info, report):
        return [{bstack1111_opy_ (u"ࠫࡧࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧ∹"): [exception_info.exconly(), report.longreprtext]}]
    @staticmethod
    def bstack1lllllll111_opy_(typename):
        if bstack1111_opy_ (u"ࠧࡇࡳࡴࡧࡵࡸ࡮ࡵ࡮ࠣ∺") in typename:
            return bstack1111_opy_ (u"ࠨࡁࡴࡵࡨࡶࡹ࡯࡯࡯ࡇࡵࡶࡴࡸࠢ∻")
        return bstack1111_opy_ (u"ࠢࡖࡰ࡫ࡥࡳࡪ࡬ࡦࡦࡈࡶࡷࡵࡲࠣ∼")