# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import threading
import logging
import bstack_utils.accessibility as bstack11l1111l1l_opy_
from bstack_utils.helper import bstack11lll1l11_opy_
logger = logging.getLogger(__name__)
def bstack1ll111ll11_opy_(bstack111llllll1_opy_):
  return True if bstack111llllll1_opy_ in threading.current_thread().__dict__.keys() else False
def bstack1ll1l1111l_opy_(context, *args):
    tags = getattr(args[0], bstack1111_opy_ (u"ࠧࡵࡣࡪࡷࠬ៘"), [])
    bstack1lll1l111l_opy_ = bstack11l1111l1l_opy_.bstack11l1l1l11l_opy_(tags)
    threading.current_thread().isA11yTest = bstack1lll1l111l_opy_
    try:
      bstack1lll1ll1_opy_ = threading.current_thread().bstackSessionDriver if bstack1ll111ll11_opy_(bstack1111_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡴ࡬ࡺࡪࡸࠧ៙")) else context.browser
      if bstack1lll1ll1_opy_ and bstack1lll1ll1_opy_.session_id and bstack1lll1l111l_opy_ and bstack11lll1l11_opy_(
              threading.current_thread(), bstack1111_opy_ (u"ࠩࡤ࠵࠶ࡿࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨ៚"), None):
          threading.current_thread().isA11yTest = bstack11l1111l1l_opy_.bstack1l1lllll11_opy_(bstack1lll1ll1_opy_, bstack1lll1l111l_opy_)
    except Exception as e:
       logger.debug(bstack1111_opy_ (u"ࠪࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡵࡣࡵࡸࠥࡧ࠱࠲ࡻࠣ࡭ࡳࠦࡢࡦࡪࡤࡺࡪࡀࠠࡼࡿࠪ៛").format(str(e)))
def bstack1l1ll1l1ll_opy_(bstack1lll1ll1_opy_):
    if bstack11lll1l11_opy_(threading.current_thread(), bstack1111_opy_ (u"ࠫ࡮ࡹࡁ࠲࠳ࡼࡘࡪࡹࡴࠨៜ"), None) and bstack11lll1l11_opy_(
      threading.current_thread(), bstack1111_opy_ (u"ࠬࡧ࠱࠲ࡻࡓࡰࡦࡺࡦࡰࡴࡰࠫ៝"), None) and not bstack11lll1l11_opy_(threading.current_thread(), bstack1111_opy_ (u"࠭ࡡ࠲࠳ࡼࡣࡸࡺ࡯ࡱࠩ៞"), False):
      threading.current_thread().a11y_stop = True
      bstack11l1111l1l_opy_.bstack111l11ll_opy_(bstack1lll1ll1_opy_, name=bstack1111_opy_ (u"ࠢࠣ៟"), path=bstack1111_opy_ (u"ࠣࠤ០"))