# coding: UTF-8
import sys
bstack1ll1l_opy_ = sys.version_info [0] == 2
bstack1ll_opy_ = 2048
bstack11111ll_opy_ = 7
def bstack1111_opy_ (bstack1l1ll11_opy_):
    global bstack11llll_opy_
    bstack11lll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack1ll1ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1l11l_opy_ = bstack11lll_opy_ % len (bstack1ll1ll1_opy_)
    bstack1lll1ll_opy_ = bstack1ll1ll1_opy_ [:bstack1l11l_opy_] + bstack1ll1ll1_opy_ [bstack1l11l_opy_:]
    if bstack1ll1l_opy_:
        bstack111ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    else:
        bstack111ll1l_opy_ = str () .join ([chr (ord (char) - bstack1ll_opy_ - (bstack11ll111_opy_ + bstack11lll_opy_) % bstack11111ll_opy_) for bstack11ll111_opy_, char in enumerate (bstack1lll1ll_opy_)])
    return eval (bstack111ll1l_opy_)
import collections
import datetime
import json
import os
import platform
import re
import subprocess
import traceback
import tempfile
import multiprocessing
import threading
import sys
import logging
from math import ceil
from unittest import result
import urllib
from urllib.parse import urlparse
import copy
import zipfile
import git
import requests
from packaging import version
from bstack_utils.config import Config
from bstack_utils.constants import (bstack1ll11ll11_opy_, bstack1l11ll1lll_opy_, bstack11lll11l_opy_,
                                    bstack11l1l1l1l1l_opy_, bstack11l1ll11l1l_opy_, bstack11l1l11ll1l_opy_, bstack11l1l1l1l11_opy_)
from bstack_utils.measure import measure
from bstack_utils.messages import bstack11111ll1_opy_, bstack111l1l11_opy_
from bstack_utils.proxy import bstack1l111ll1ll_opy_, bstack1lll1llll1_opy_
from bstack_utils.constants import *
from bstack_utils import bstack11l1lll1l_opy_
from bstack_utils.bstack111ll1111_opy_ import bstack1l11111ll1_opy_
from browserstack_sdk._version import __version__
bstack1l1l11ll11_opy_ = Config.bstack11l11l11l_opy_()
logger = bstack11l1lll1l_opy_.get_logger(__name__, bstack11l1lll1l_opy_.bstack1lll111l11l_opy_())
def bstack11ll11llll1_opy_(config):
    return config[bstack1111_opy_ (u"ࠪࡹࡸ࡫ࡲࡏࡣࡰࡩࠬ᭰")]
def bstack11ll1l1l1ll_opy_(config):
    return config[bstack1111_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶࡏࡪࡿࠧ᭱")]
def bstack11l111llll_opy_():
    try:
        import playwright
        return True
    except ImportError:
        return False
def bstack11l11l11ll1_opy_(obj):
    values = []
    bstack11l1111l1l1_opy_ = re.compile(bstack1111_opy_ (u"ࡷࠨ࡞ࡄࡗࡖࡘࡔࡓ࡟ࡕࡃࡊࡣࡡࡪࠫࠥࠤ᭲"), re.I)
    for key in obj.keys():
        if bstack11l1111l1l1_opy_.match(key):
            values.append(obj[key])
    return values
def bstack111ll111111_opy_(config):
    tags = []
    tags.extend(bstack11l11l11ll1_opy_(os.environ))
    tags.extend(bstack11l11l11ll1_opy_(config))
    return tags
def bstack111ll11ll11_opy_(markers):
    tags = []
    for marker in markers:
        tags.append(marker.name)
    return tags
def bstack11l111l1l11_opy_(bstack111l1lll11l_opy_):
    if not bstack111l1lll11l_opy_:
        return bstack1111_opy_ (u"࠭ࠧ᭳")
    return bstack1111_opy_ (u"ࠢࡼࡿࠣࠬࢀࢃࠩࠣ᭴").format(bstack111l1lll11l_opy_.name, bstack111l1lll11l_opy_.email)
def bstack11ll111l11l_opy_():
    try:
        repo = git.Repo(search_parent_directories=True)
        bstack11l111l111l_opy_ = repo.common_dir
        info = {
            bstack1111_opy_ (u"ࠣࡵ࡫ࡥࠧ᭵"): repo.head.commit.hexsha,
            bstack1111_opy_ (u"ࠤࡶ࡬ࡴࡸࡴࡠࡵ࡫ࡥࠧ᭶"): repo.git.rev_parse(repo.head.commit, short=True),
            bstack1111_opy_ (u"ࠥࡦࡷࡧ࡮ࡤࡪࠥ᭷"): repo.active_branch.name,
            bstack1111_opy_ (u"ࠦࡹࡧࡧࠣ᭸"): repo.git.describe(all=True, tags=True, exact_match=True),
            bstack1111_opy_ (u"ࠧࡩ࡯࡮࡯࡬ࡸࡹ࡫ࡲࠣ᭹"): bstack11l111l1l11_opy_(repo.head.commit.committer),
            bstack1111_opy_ (u"ࠨࡣࡰ࡯ࡰ࡭ࡹࡺࡥࡳࡡࡧࡥࡹ࡫ࠢ᭺"): repo.head.commit.committed_datetime.isoformat(),
            bstack1111_opy_ (u"ࠢࡢࡷࡷ࡬ࡴࡸࠢ᭻"): bstack11l111l1l11_opy_(repo.head.commit.author),
            bstack1111_opy_ (u"ࠣࡣࡸࡸ࡭ࡵࡲࡠࡦࡤࡸࡪࠨ᭼"): repo.head.commit.authored_datetime.isoformat(),
            bstack1111_opy_ (u"ࠤࡦࡳࡲࡳࡩࡵࡡࡰࡩࡸࡹࡡࡨࡧࠥ᭽"): repo.head.commit.message,
            bstack1111_opy_ (u"ࠥࡶࡴࡵࡴࠣ᭾"): repo.git.rev_parse(bstack1111_opy_ (u"ࠦ࠲࠳ࡳࡩࡱࡺ࠱ࡹࡵࡰ࡭ࡧࡹࡩࡱࠨ᭿")),
            bstack1111_opy_ (u"ࠧࡩ࡯࡮࡯ࡲࡲࡤ࡭ࡩࡵࡡࡧ࡭ࡷࠨᮀ"): bstack11l111l111l_opy_,
            bstack1111_opy_ (u"ࠨࡷࡰࡴ࡮ࡸࡷ࡫ࡥࡠࡩ࡬ࡸࡤࡪࡩࡳࠤᮁ"): subprocess.check_output([bstack1111_opy_ (u"ࠢࡨ࡫ࡷࠦᮂ"), bstack1111_opy_ (u"ࠣࡴࡨࡺ࠲ࡶࡡࡳࡵࡨࠦᮃ"), bstack1111_opy_ (u"ࠤ࠰࠱࡬࡯ࡴ࠮ࡥࡲࡱࡲࡵ࡮࠮ࡦ࡬ࡶࠧᮄ")]).strip().decode(
                bstack1111_opy_ (u"ࠪࡹࡹ࡬࠭࠹ࠩᮅ")),
            bstack1111_opy_ (u"ࠦࡱࡧࡳࡵࡡࡷࡥ࡬ࠨᮆ"): repo.git.describe(tags=True, abbrev=0, always=True),
            bstack1111_opy_ (u"ࠧࡩ࡯࡮࡯࡬ࡸࡸࡥࡳࡪࡰࡦࡩࡤࡲࡡࡴࡶࡢࡸࡦ࡭ࠢᮇ"): repo.git.rev_list(
                bstack1111_opy_ (u"ࠨࡻࡾ࠰࠱ࡿࢂࠨᮈ").format(repo.head.commit, repo.git.describe(tags=True, abbrev=0, always=True)), count=True)
        }
        remotes = repo.remotes
        bstack111ll1lll11_opy_ = []
        for remote in remotes:
            bstack11l111l1111_opy_ = {
                bstack1111_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᮉ"): remote.name,
                bstack1111_opy_ (u"ࠣࡷࡵࡰࠧᮊ"): remote.url,
            }
            bstack111ll1lll11_opy_.append(bstack11l111l1111_opy_)
        bstack11l11l11111_opy_ = {
            bstack1111_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᮋ"): bstack1111_opy_ (u"ࠥ࡫࡮ࡺࠢᮌ"),
            **info,
            bstack1111_opy_ (u"ࠦࡷ࡫࡭ࡰࡶࡨࡷࠧᮍ"): bstack111ll1lll11_opy_
        }
        bstack11l11l11111_opy_ = bstack111lll1ll11_opy_(bstack11l11l11111_opy_)
        return bstack11l11l11111_opy_
    except git.InvalidGitRepositoryError:
        return {}
    except Exception as err:
        print(bstack1111_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡵࡵࡰࡶ࡮ࡤࡸ࡮ࡴࡧࠡࡉ࡬ࡸࠥࡳࡥࡵࡣࡧࡥࡹࡧࠠࡸ࡫ࡷ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠥࢁࡽࠣᮎ").format(err))
        return {}
def bstack111ll11l1ll_opy_(bstack11l111lllll_opy_=None):
    bstack1111_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࡇࡦࡶࠣ࡫࡮ࡺࠠ࡮ࡧࡷࡥࡩࡧࡴࡢࠢࡶࡴࡪࡩࡩࡧ࡫ࡦࡥࡱࡲࡹࠡࡨࡲࡶࡲࡧࡴࡵࡧࡧࠤ࡫ࡵࡲࠡࡃࡌࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴࠠࡶࡵࡨࠤࡨࡧࡳࡦࡵࠣࡪࡴࡸࠠࡦࡣࡦ࡬ࠥ࡬࡯࡭ࡦࡨࡶࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡲࡩࡴࡶ࠱ࠎࠥࠦࠠࠡࡃࡵ࡫ࡸࡀࠊࠡࠢࠣࠤࠥࠦࠠࠡࡨࡲࡰࡩ࡫ࡲࡴࠢࠫࡰ࡮ࡹࡴ࠭ࠢࡲࡴࡹ࡯࡯࡯ࡣ࡯࠭࠿ࠦࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡏࡱࡱࡩ࠿ࠦࡍࡰࡰࡲ࠱ࡷ࡫ࡰࡰࠢࡤࡴࡵࡸ࡯ࡢࡥ࡫࠰ࠥࡻࡳࡦࡵࠣࡧࡺࡸࡲࡦࡰࡷࠤࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠠ࡜ࡱࡶ࠲࡬࡫ࡴࡤࡹࡧࠬ࠮ࡣࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡆ࡯ࡳࡸࡾࠦ࡬ࡪࡵࡷࠤࡠࡣ࠺ࠡࡏࡸࡰࡹ࡯࠭ࡳࡧࡳࡳࠥࡧࡰࡱࡴࡲࡥࡨ࡮ࠠࡸ࡫ࡷ࡬ࠥࡴ࡯ࠡࡵࡲࡹࡷࡩࡥࡴࠢࡦࡳࡳ࡬ࡩࡨࡷࡵࡩࡩ࠲ࠠࡳࡧࡷࡹࡷࡴࡳࠡ࡝ࡠࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠰ࠤࡑ࡯ࡳࡵࠢࡲࡪࠥࡶࡡࡵࡪࡶ࠾ࠥࡓࡵ࡭ࡶ࡬࠱ࡷ࡫ࡰࡰࠢࡤࡴࡵࡸ࡯ࡢࡥ࡫ࠤࡼ࡯ࡴࡩࠢࡶࡴࡪࡩࡩࡧ࡫ࡦࠤ࡫ࡵ࡬ࡥࡧࡵࡷࠥࡺ࡯ࠡࡣࡱࡥࡱࡿࡺࡦࠌࠣࠤࠥࠦࡒࡦࡶࡸࡶࡳࡹ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࡯࡭ࡸࡺ࠺ࠡࡎ࡬ࡷࡹࠦ࡯ࡧࠢࡧ࡭ࡨࡺࡳ࠭ࠢࡨࡥࡨ࡮ࠠࡤࡱࡱࡸࡦ࡯࡮ࡪࡰࡪࠤ࡬࡯ࡴࠡ࡯ࡨࡸࡦࡪࡡࡵࡣࠣࡪࡴࡸࠠࡢࠢࡩࡳࡱࡪࡥࡳ࠰ࠍࠤࠥࠦࠠࠣࠤࠥᮏ")
    if bstack11l111lllll_opy_ is None:
        bstack11l111lllll_opy_ = [os.getcwd()]
    elif isinstance(bstack11l111lllll_opy_, list) and len(bstack11l111lllll_opy_) == 0:
        return []
    results = []
    for folder in bstack11l111lllll_opy_:
        try:
            if not os.path.exists(folder):
                raise Exception(bstack1111_opy_ (u"ࠢࡇࡱ࡯ࡨࡪࡸࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡨࡼ࡮ࡹࡴ࠻ࠢࡾࢁࠧᮐ").format(folder))
            repo = git.Repo(folder, search_parent_directories=True)
            result = {
                bstack1111_opy_ (u"ࠣࡲࡵࡍࡩࠨᮑ"): bstack1111_opy_ (u"ࠤࠥᮒ"),
                bstack1111_opy_ (u"ࠥࡪ࡮ࡲࡥࡴࡅ࡫ࡥࡳ࡭ࡥࡥࠤᮓ"): [],
                bstack1111_opy_ (u"ࠦࡦࡻࡴࡩࡱࡵࡷࠧᮔ"): [],
                bstack1111_opy_ (u"ࠧࡶࡲࡅࡣࡷࡩࠧᮕ"): bstack1111_opy_ (u"ࠨࠢᮖ"),
                bstack1111_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺࡍࡦࡵࡶࡥ࡬࡫ࡳࠣᮗ"): [],
                bstack1111_opy_ (u"ࠣࡲࡵࡘ࡮ࡺ࡬ࡦࠤᮘ"): bstack1111_opy_ (u"ࠤࠥᮙ"),
                bstack1111_opy_ (u"ࠥࡴࡷࡊࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠥᮚ"): bstack1111_opy_ (u"ࠦࠧᮛ"),
                bstack1111_opy_ (u"ࠧࡶࡲࡓࡣࡺࡈ࡮࡬ࡦࠣᮜ"): bstack1111_opy_ (u"ࠨࠢᮝ")
            }
            bstack111lll11lll_opy_ = repo.active_branch.name
            bstack111ll1llll1_opy_ = repo.head.commit
            result[bstack1111_opy_ (u"ࠢࡱࡴࡌࡨࠧᮞ")] = bstack111ll1llll1_opy_.hexsha
            bstack111ll11l111_opy_ = _111l1llll11_opy_(repo)
            logger.debug(bstack1111_opy_ (u"ࠣࡄࡤࡷࡪࠦࡢࡳࡣࡱࡧ࡭ࠦࡦࡰࡴࠣࡧࡴࡳࡰࡢࡴ࡬ࡷࡴࡴ࠺ࠡࠤᮟ") + str(bstack111ll11l111_opy_) + bstack1111_opy_ (u"ࠤࠥᮠ"))
            if bstack111ll11l111_opy_:
                try:
                    bstack111l1lll111_opy_ = repo.git.diff(bstack1111_opy_ (u"ࠥ࠱࠲ࡴࡡ࡮ࡧ࠰ࡳࡳࡲࡹࠣᮡ"), bstack1lll11ll1ll_opy_ (u"ࠦࢀࡨࡡࡴࡧࡢࡦࡷࡧ࡮ࡤࡪࢀ࠲࠳࠴ࡻࡤࡷࡵࡶࡪࡴࡴࡠࡤࡵࡥࡳࡩࡨࡾࠤᮢ")).split(bstack1111_opy_ (u"ࠬࡢ࡮ࠨᮣ"))
                    logger.debug(bstack1111_opy_ (u"ࠨࡃࡩࡣࡱ࡫ࡪࡪࠠࡧ࡫࡯ࡩࡸࠦࡢࡦࡶࡺࡩࡪࡴࠠࡼࡤࡤࡷࡪࡥࡢࡳࡣࡱࡧ࡭ࢃࠠࡢࡰࡧࠤࢀࡩࡵࡳࡴࡨࡲࡹࡥࡢࡳࡣࡱࡧ࡭ࢃ࠺ࠡࠤᮤ") + str(bstack111l1lll111_opy_) + bstack1111_opy_ (u"ࠢࠣᮥ"))
                    result[bstack1111_opy_ (u"ࠣࡨ࡬ࡰࡪࡹࡃࡩࡣࡱ࡫ࡪࡪࠢᮦ")] = [f.strip() for f in bstack111l1lll111_opy_ if f.strip()]
                    commits = list(repo.iter_commits(bstack1lll11ll1ll_opy_ (u"ࠤࡾࡦࡦࡹࡥࡠࡤࡵࡥࡳࡩࡨࡾ࠰࠱ࡿࡨࡻࡲࡳࡧࡱࡸࡤࡨࡲࡢࡰࡦ࡬ࢂࠨᮧ")))
                except Exception:
                    logger.debug(bstack1111_opy_ (u"ࠥࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡧࡦࡶࠣࡧ࡭ࡧ࡮ࡨࡧࡧࠤ࡫࡯࡬ࡦࡵࠣࡪࡷࡵ࡭ࠡࡤࡵࡥࡳࡩࡨࠡࡥࡲࡱࡵࡧࡲࡪࡵࡲࡲ࠳ࠦࡆࡢ࡮࡯࡭ࡳ࡭ࠠࡣࡣࡦ࡯ࠥࡺ࡯ࠡࡴࡨࡧࡪࡴࡴࠡࡥࡲࡱࡲ࡯ࡴࡴ࠰ࠥᮨ"))
                    commits = list(repo.iter_commits(max_count=10))
                    if commits:
                        result[bstack1111_opy_ (u"ࠦ࡫࡯࡬ࡦࡵࡆ࡬ࡦࡴࡧࡦࡦࠥᮩ")] = _11l11l1111l_opy_(commits[:5])
            else:
                commits = list(repo.iter_commits(max_count=10))
                if commits:
                    result[bstack1111_opy_ (u"ࠧ࡬ࡩ࡭ࡧࡶࡇ࡭ࡧ࡮ࡨࡧࡧ᮪ࠦ")] = _11l11l1111l_opy_(commits[:5])
            bstack111l1lll1ll_opy_ = set()
            bstack111lll1l1l1_opy_ = []
            for commit in commits:
                logger.debug(bstack1111_opy_ (u"ࠨࡐࡳࡱࡦࡩࡸࡹࡩ࡯ࡩࠣࡧࡴࡳ࡭ࡪࡶ࠽ࠤ᮫ࠧ") + str(commit.message) + bstack1111_opy_ (u"ࠢࠣᮬ"))
                bstack11l111lll11_opy_ = commit.author.name if commit.author else bstack1111_opy_ (u"ࠣࡗࡱ࡯ࡳࡵࡷ࡯ࠤᮭ")
                bstack111l1lll1ll_opy_.add(bstack11l111lll11_opy_)
                bstack111lll1l1l1_opy_.append({
                    bstack1111_opy_ (u"ࠤࡰࡩࡸࡹࡡࡨࡧࠥᮮ"): commit.message.strip(),
                    bstack1111_opy_ (u"ࠥࡹࡸ࡫ࡲࠣᮯ"): bstack11l111lll11_opy_
                })
            result[bstack1111_opy_ (u"ࠦࡦࡻࡴࡩࡱࡵࡷࠧ᮰")] = list(bstack111l1lll1ll_opy_)
            result[bstack1111_opy_ (u"ࠧࡩ࡯࡮࡯࡬ࡸࡒ࡫ࡳࡴࡣࡪࡩࡸࠨ᮱")] = bstack111lll1l1l1_opy_
            result[bstack1111_opy_ (u"ࠨࡰࡳࡆࡤࡸࡪࠨ᮲")] = bstack111ll1llll1_opy_.committed_datetime.strftime(bstack1111_opy_ (u"࡛ࠢࠦ࠰ࠩࡲ࠳ࠥࡥࠤ᮳"))
            if (not result[bstack1111_opy_ (u"ࠣࡲࡵࡘ࡮ࡺ࡬ࡦࠤ᮴")] or result[bstack1111_opy_ (u"ࠤࡳࡶ࡙࡯ࡴ࡭ࡧࠥ᮵")].strip() == bstack1111_opy_ (u"ࠥࠦ᮶")) and bstack111ll1llll1_opy_.message:
                bstack111lll11ll1_opy_ = bstack111ll1llll1_opy_.message.strip().splitlines()
                result[bstack1111_opy_ (u"ࠦࡵࡸࡔࡪࡶ࡯ࡩࠧ᮷")] = bstack111lll11ll1_opy_[0] if bstack111lll11ll1_opy_ else bstack1111_opy_ (u"ࠧࠨ᮸")
                if len(bstack111lll11ll1_opy_) > 2:
                    result[bstack1111_opy_ (u"ࠨࡰࡳࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠨ᮹")] = bstack1111_opy_ (u"ࠧ࡝ࡰࠪᮺ").join(bstack111lll11ll1_opy_[2:]).strip()
            results.append(result)
        except Exception as err:
            logger.error(bstack1111_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱࡱࡳࡹࡱࡧࡴࡪࡰࡪࠤࡌ࡯ࡴࠡ࡯ࡨࡸࡦࡪࡡࡵࡣࠣࡪࡴࡸࠠࡂࡋࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࠨࡧࡱ࡯ࡨࡪࡸ࠺ࠡࡽࢀ࠭࠿ࠦࡻࡾࠢ࠰ࠤࢀࢃࠢᮻ").format(
                folder,
                type(err).__name__,
                str(err)
            ))
    filtered_results = [
        result
        for result in results
        if _11l11111l11_opy_(result)
    ]
    return filtered_results
def _11l11111l11_opy_(result):
    bstack1111_opy_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࡋࡩࡱࡶࡥࡳࠢࡷࡳࠥࡩࡨࡦࡥ࡮ࠤ࡮࡬ࠠࡢࠢࡪ࡭ࡹࠦ࡭ࡦࡶࡤࡨࡦࡺࡡࠡࡴࡨࡷࡺࡲࡴࠡ࡫ࡶࠤࡻࡧ࡬ࡪࡦࠣࠬࡳࡵ࡮࠮ࡧࡰࡴࡹࡿࠠࡧ࡫࡯ࡩࡸࡉࡨࡢࡰࡪࡩࡩࠦࡡ࡯ࡦࠣࡥࡺࡺࡨࡰࡴࡶ࠭࠳ࠐࠠࠡࠢࠣࠦࠧࠨᮼ")
    return (
        isinstance(result.get(bstack1111_opy_ (u"ࠥࡪ࡮ࡲࡥࡴࡅ࡫ࡥࡳ࡭ࡥࡥࠤᮽ"), None), list)
        and len(result[bstack1111_opy_ (u"ࠦ࡫࡯࡬ࡦࡵࡆ࡬ࡦࡴࡧࡦࡦࠥᮾ")]) > 0
        and isinstance(result.get(bstack1111_opy_ (u"ࠧࡧࡵࡵࡪࡲࡶࡸࠨᮿ"), None), list)
        and len(result[bstack1111_opy_ (u"ࠨࡡࡶࡶ࡫ࡳࡷࡹࠢᯀ")]) > 0
    )
def _111l1llll11_opy_(repo):
    bstack1111_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࡕࡴࡼࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡸ࡭࡫ࠠࡣࡣࡶࡩࠥࡨࡲࡢࡰࡦ࡬ࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡧࡪࡸࡨࡲࠥࡸࡥࡱࡱࠣࡻ࡮ࡺࡨࡰࡷࡷࠤ࡭ࡧࡲࡥࡥࡲࡨࡪࡪࠠ࡯ࡣࡰࡩࡸࠦࡡ࡯ࡦࠣࡻࡴࡸ࡫ࠡࡹ࡬ࡸ࡭ࠦࡡ࡭࡮࡚ࠣࡈ࡙ࠠࡱࡴࡲࡺ࡮ࡪࡥࡳࡵ࠱ࠎࠥࠦࠠࠡࡔࡨࡸࡺࡸ࡮ࡴࠢࡷ࡬ࡪࠦࡤࡦࡨࡤࡹࡱࡺࠠࡣࡴࡤࡲࡨ࡮ࠠࡪࡨࠣࡴࡴࡹࡳࡪࡤ࡯ࡩ࠱ࠦࡥ࡭ࡵࡨࠤࡓࡵ࡮ࡦ࠰ࠍࠤࠥࠦࠠࠣࠤࠥᯁ")
    try:
        try:
            origin = repo.remotes.origin
            bstack111lll11111_opy_ = origin.refs[bstack1111_opy_ (u"ࠨࡊࡈࡅࡉ࠭ᯂ")]
            target = bstack111lll11111_opy_.reference.name
            if target.startswith(bstack1111_opy_ (u"ࠩࡲࡶ࡮࡭ࡩ࡯࠱ࠪᯃ")):
                return target
        except Exception:
            pass
        if repo.remotes and repo.remotes.origin.refs:
            for ref in repo.remotes.origin.refs:
                if ref.name.startswith(bstack1111_opy_ (u"ࠪࡳࡷ࡯ࡧࡪࡰ࠲ࠫᯄ")):
                    return ref.name
        if repo.heads:
            return repo.heads[0].name
    except Exception:
        pass
    return None
def _11l11l1111l_opy_(commits):
    bstack1111_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࡌ࡫ࡴࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢࡦ࡬ࡦࡴࡧࡦࡦࠣࡪ࡮ࡲࡥࡴࠢࡩࡶࡴࡳࠠࡢࠢ࡯࡭ࡸࡺࠠࡰࡨࠣࡧࡴࡳ࡭ࡪࡶࡶ࠲ࠏࠦࠠࠡࠢࠥࠦࠧᯅ")
    bstack111l1lll111_opy_ = set()
    try:
        for commit in commits:
            if commit.parents:
                for parent in commit.parents:
                    diff = commit.diff(parent)
                    for bstack11l11l11lll_opy_ in diff:
                        if bstack11l11l11lll_opy_.a_path:
                            bstack111l1lll111_opy_.add(bstack11l11l11lll_opy_.a_path)
                        if bstack11l11l11lll_opy_.b_path:
                            bstack111l1lll111_opy_.add(bstack11l11l11lll_opy_.b_path)
    except Exception:
        pass
    return list(bstack111l1lll111_opy_)
def bstack111lll1ll11_opy_(bstack11l11l11111_opy_):
    bstack111ll1ll111_opy_ = bstack11l111ll1ll_opy_(bstack11l11l11111_opy_)
    if bstack111ll1ll111_opy_ and bstack111ll1ll111_opy_ > bstack11l1l1l1l1l_opy_:
        bstack111l1llll1l_opy_ = bstack111ll1ll111_opy_ - bstack11l1l1l1l1l_opy_
        bstack11l111l1ll1_opy_ = bstack111lll1llll_opy_(bstack11l11l11111_opy_[bstack1111_opy_ (u"ࠧࡩ࡯࡮࡯࡬ࡸࡤࡳࡥࡴࡵࡤ࡫ࡪࠨᯆ")], bstack111l1llll1l_opy_)
        bstack11l11l11111_opy_[bstack1111_opy_ (u"ࠨࡣࡰ࡯ࡰ࡭ࡹࡥ࡭ࡦࡵࡶࡥ࡬࡫ࠢᯇ")] = bstack11l111l1ll1_opy_
        logger.info(bstack1111_opy_ (u"ࠢࡕࡪࡨࠤࡨࡵ࡭࡮࡫ࡷࠤ࡭ࡧࡳࠡࡤࡨࡩࡳࠦࡴࡳࡷࡱࡧࡦࡺࡥࡥ࠰ࠣࡗ࡮ࢀࡥࠡࡱࡩࠤࡨࡵ࡭࡮࡫ࡷࠤࡦ࡬ࡴࡦࡴࠣࡸࡷࡻ࡮ࡤࡣࡷ࡭ࡴࡴࠠࡪࡵࠣࡿࢂࠦࡋࡃࠤᯈ")
                    .format(bstack11l111ll1ll_opy_(bstack11l11l11111_opy_) / 1024))
    return bstack11l11l11111_opy_
def bstack11l111ll1ll_opy_(bstack11l11lll11_opy_):
    try:
        if bstack11l11lll11_opy_:
            bstack11l111llll1_opy_ = json.dumps(bstack11l11lll11_opy_)
            bstack111l1llllll_opy_ = sys.getsizeof(bstack11l111llll1_opy_)
            return bstack111l1llllll_opy_
    except Exception as e:
        logger.debug(bstack1111_opy_ (u"ࠣࡕࡲࡱࡪࡺࡨࡪࡰࡪࠤࡼ࡫࡮ࡵࠢࡺࡶࡴࡴࡧࠡࡹ࡫࡭ࡱ࡫ࠠࡤࡣ࡯ࡧࡺࡲࡡࡵ࡫ࡱ࡫ࠥࡹࡩࡻࡧࠣࡳ࡫ࠦࡊࡔࡑࡑࠤࡴࡨࡪࡦࡥࡷ࠾ࠥࢁࡽࠣᯉ").format(e))
    return -1
def bstack111lll1llll_opy_(field, bstack11l11l111l1_opy_):
    try:
        bstack111llll1l11_opy_ = len(bytes(bstack11l1ll11l1l_opy_, bstack1111_opy_ (u"ࠩࡸࡸ࡫࠳࠸ࠨᯊ")))
        bstack111ll1lll1l_opy_ = bytes(field, bstack1111_opy_ (u"ࠪࡹࡹ࡬࠭࠹ࠩᯋ"))
        bstack111ll11lll1_opy_ = len(bstack111ll1lll1l_opy_)
        bstack111ll11111l_opy_ = ceil(bstack111ll11lll1_opy_ - bstack11l11l111l1_opy_ - bstack111llll1l11_opy_)
        if bstack111ll11111l_opy_ > 0:
            bstack11l1111111l_opy_ = bstack111ll1lll1l_opy_[:bstack111ll11111l_opy_].decode(bstack1111_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪᯌ"), errors=bstack1111_opy_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬᯍ")) + bstack11l1ll11l1l_opy_
            return bstack11l1111111l_opy_
    except Exception as e:
        logger.debug(bstack1111_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡨࡪ࡮ࡨࠤࡹࡸࡵ࡯ࡥࡤࡸ࡮ࡴࡧࠡࡨ࡬ࡩࡱࡪࠬࠡࡰࡲࡸ࡭࡯࡮ࡨࠢࡺࡥࡸࠦࡴࡳࡷࡱࡧࡦࡺࡥࡥࠢ࡫ࡩࡷ࡫࠺ࠡࡽࢀࠦᯎ").format(e))
    return field
def bstack1l1l1ll1l1_opy_():
    env = os.environ
    if (bstack1111_opy_ (u"ࠢࡋࡇࡑࡏࡎࡔࡓࡠࡗࡕࡐࠧᯏ") in env and len(env[bstack1111_opy_ (u"ࠣࡌࡈࡒࡐࡏࡎࡔࡡࡘࡖࡑࠨᯐ")]) > 0) or (
            bstack1111_opy_ (u"ࠤࡍࡉࡓࡑࡉࡏࡕࡢࡌࡔࡓࡅࠣᯑ") in env and len(env[bstack1111_opy_ (u"ࠥࡎࡊࡔࡋࡊࡐࡖࡣࡍࡕࡍࡆࠤᯒ")]) > 0):
        return {
            bstack1111_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᯓ"): bstack1111_opy_ (u"ࠧࡐࡥ࡯࡭࡬ࡲࡸࠨᯔ"),
            bstack1111_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᯕ"): env.get(bstack1111_opy_ (u"ࠢࡃࡗࡌࡐࡉࡥࡕࡓࡎࠥᯖ")),
            bstack1111_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᯗ"): env.get(bstack1111_opy_ (u"ࠤࡍࡓࡇࡥࡎࡂࡏࡈࠦᯘ")),
            bstack1111_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᯙ"): env.get(bstack1111_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࠥᯚ"))
        }
    if env.get(bstack1111_opy_ (u"ࠧࡉࡉࠣᯛ")) == bstack1111_opy_ (u"ࠨࡴࡳࡷࡨࠦᯜ") and bstack1l1lllllll_opy_(env.get(bstack1111_opy_ (u"ࠢࡄࡋࡕࡇࡑࡋࡃࡊࠤᯝ"))):
        return {
            bstack1111_opy_ (u"ࠣࡰࡤࡱࡪࠨᯞ"): bstack1111_opy_ (u"ࠤࡆ࡭ࡷࡩ࡬ࡦࡅࡌࠦᯟ"),
            bstack1111_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᯠ"): env.get(bstack1111_opy_ (u"ࠦࡈࡏࡒࡄࡎࡈࡣࡇ࡛ࡉࡍࡆࡢ࡙ࡗࡒࠢᯡ")),
            bstack1111_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᯢ"): env.get(bstack1111_opy_ (u"ࠨࡃࡊࡔࡆࡐࡊࡥࡊࡐࡄࠥᯣ")),
            bstack1111_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨᯤ"): env.get(bstack1111_opy_ (u"ࠣࡅࡌࡖࡈࡒࡅࡠࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࠦᯥ"))
        }
    if env.get(bstack1111_opy_ (u"ࠤࡆࡍ᯦ࠧ")) == bstack1111_opy_ (u"ࠥࡸࡷࡻࡥࠣᯧ") and bstack1l1lllllll_opy_(env.get(bstack1111_opy_ (u"࡙ࠦࡘࡁࡗࡋࡖࠦᯨ"))):
        return {
            bstack1111_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᯩ"): bstack1111_opy_ (u"ࠨࡔࡳࡣࡹ࡭ࡸࠦࡃࡊࠤᯪ"),
            bstack1111_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᯫ"): env.get(bstack1111_opy_ (u"ࠣࡖࡕࡅ࡛ࡏࡓࡠࡄࡘࡍࡑࡊ࡟ࡘࡇࡅࡣ࡚ࡘࡌࠣᯬ")),
            bstack1111_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᯭ"): env.get(bstack1111_opy_ (u"ࠥࡘࡗࡇࡖࡊࡕࡢࡎࡔࡈ࡟ࡏࡃࡐࡉࠧᯮ")),
            bstack1111_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᯯ"): env.get(bstack1111_opy_ (u"࡚ࠧࡒࡂࡘࡌࡗࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࠦᯰ"))
        }
    if env.get(bstack1111_opy_ (u"ࠨࡃࡊࠤᯱ")) == bstack1111_opy_ (u"ࠢࡵࡴࡸࡩ᯲ࠧ") and env.get(bstack1111_opy_ (u"ࠣࡅࡌࡣࡓࡇࡍࡆࠤ᯳")) == bstack1111_opy_ (u"ࠤࡦࡳࡩ࡫ࡳࡩ࡫ࡳࠦ᯴"):
        return {
            bstack1111_opy_ (u"ࠥࡲࡦࡳࡥࠣ᯵"): bstack1111_opy_ (u"ࠦࡈࡵࡤࡦࡵ࡫࡭ࡵࠨ᯶"),
            bstack1111_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣ᯷"): None,
            bstack1111_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣ᯸"): None,
            bstack1111_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨ᯹"): None
        }
    if env.get(bstack1111_opy_ (u"ࠣࡄࡌࡘࡇ࡛ࡃࡌࡇࡗࡣࡇࡘࡁࡏࡅࡋࠦ᯺")) and env.get(bstack1111_opy_ (u"ࠤࡅࡍ࡙ࡈࡕࡄࡍࡈࡘࡤࡉࡏࡎࡏࡌࡘࠧ᯻")):
        return {
            bstack1111_opy_ (u"ࠥࡲࡦࡳࡥࠣ᯼"): bstack1111_opy_ (u"ࠦࡇ࡯ࡴࡣࡷࡦ࡯ࡪࡺࠢ᯽"),
            bstack1111_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣ᯾"): env.get(bstack1111_opy_ (u"ࠨࡂࡊࡖࡅ࡙ࡈࡑࡅࡕࡡࡊࡍ࡙ࡥࡈࡕࡖࡓࡣࡔࡘࡉࡈࡋࡑࠦ᯿")),
            bstack1111_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤᰀ"): None,
            bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᰁ"): env.get(bstack1111_opy_ (u"ࠤࡅࡍ࡙ࡈࡕࡄࡍࡈࡘࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࠦᰂ"))
        }
    if env.get(bstack1111_opy_ (u"ࠥࡇࡎࠨᰃ")) == bstack1111_opy_ (u"ࠦࡹࡸࡵࡦࠤᰄ") and bstack1l1lllllll_opy_(env.get(bstack1111_opy_ (u"ࠧࡊࡒࡐࡐࡈࠦᰅ"))):
        return {
            bstack1111_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᰆ"): bstack1111_opy_ (u"ࠢࡅࡴࡲࡲࡪࠨᰇ"),
            bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᰈ"): env.get(bstack1111_opy_ (u"ࠤࡇࡖࡔࡔࡅࡠࡄࡘࡍࡑࡊ࡟ࡍࡋࡑࡏࠧᰉ")),
            bstack1111_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᰊ"): None,
            bstack1111_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᰋ"): env.get(bstack1111_opy_ (u"ࠧࡊࡒࡐࡐࡈࡣࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࠥᰌ"))
        }
    if env.get(bstack1111_opy_ (u"ࠨࡃࡊࠤᰍ")) == bstack1111_opy_ (u"ࠢࡵࡴࡸࡩࠧᰎ") and bstack1l1lllllll_opy_(env.get(bstack1111_opy_ (u"ࠣࡕࡈࡑࡆࡖࡈࡐࡔࡈࠦᰏ"))):
        return {
            bstack1111_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᰐ"): bstack1111_opy_ (u"ࠥࡗࡪࡳࡡࡱࡪࡲࡶࡪࠨᰑ"),
            bstack1111_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢᰒ"): env.get(bstack1111_opy_ (u"࡙ࠧࡅࡎࡃࡓࡌࡔࡘࡅࡠࡑࡕࡋࡆࡔࡉ࡛ࡃࡗࡍࡔࡔ࡟ࡖࡔࡏࠦᰓ")),
            bstack1111_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᰔ"): env.get(bstack1111_opy_ (u"ࠢࡔࡇࡐࡅࡕࡎࡏࡓࡇࡢࡎࡔࡈ࡟ࡏࡃࡐࡉࠧᰕ")),
            bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᰖ"): env.get(bstack1111_opy_ (u"ࠤࡖࡉࡒࡇࡐࡉࡑࡕࡉࡤࡐࡏࡃࡡࡌࡈࠧᰗ"))
        }
    if env.get(bstack1111_opy_ (u"ࠥࡇࡎࠨᰘ")) == bstack1111_opy_ (u"ࠦࡹࡸࡵࡦࠤᰙ") and bstack1l1lllllll_opy_(env.get(bstack1111_opy_ (u"ࠧࡍࡉࡕࡎࡄࡆࡤࡉࡉࠣᰚ"))):
        return {
            bstack1111_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᰛ"): bstack1111_opy_ (u"ࠢࡈ࡫ࡷࡐࡦࡨࠢᰜ"),
            bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᰝ"): env.get(bstack1111_opy_ (u"ࠤࡆࡍࡤࡐࡏࡃࡡࡘࡖࡑࠨᰞ")),
            bstack1111_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᰟ"): env.get(bstack1111_opy_ (u"ࠦࡈࡏ࡟ࡋࡑࡅࡣࡓࡇࡍࡆࠤᰠ")),
            bstack1111_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᰡ"): env.get(bstack1111_opy_ (u"ࠨࡃࡊࡡࡍࡓࡇࡥࡉࡅࠤᰢ"))
        }
    if env.get(bstack1111_opy_ (u"ࠢࡄࡋࠥᰣ")) == bstack1111_opy_ (u"ࠣࡶࡵࡹࡪࠨᰤ") and bstack1l1lllllll_opy_(env.get(bstack1111_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡌࡋࡗࡉࠧᰥ"))):
        return {
            bstack1111_opy_ (u"ࠥࡲࡦࡳࡥࠣᰦ"): bstack1111_opy_ (u"ࠦࡇࡻࡩ࡭ࡦ࡮࡭ࡹ࡫ࠢᰧ"),
            bstack1111_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣᰨ"): env.get(bstack1111_opy_ (u"ࠨࡂࡖࡋࡏࡈࡐࡏࡔࡆࡡࡅ࡙ࡎࡒࡄࡠࡗࡕࡐࠧᰩ")),
            bstack1111_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤᰪ"): env.get(bstack1111_opy_ (u"ࠣࡄࡘࡍࡑࡊࡋࡊࡖࡈࡣࡑࡇࡂࡆࡎࠥᰫ")) or env.get(bstack1111_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡌࡋࡗࡉࡤࡖࡉࡑࡇࡏࡍࡓࡋ࡟ࡏࡃࡐࡉࠧᰬ")),
            bstack1111_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᰭ"): env.get(bstack1111_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡎࡍ࡙ࡋ࡟ࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࠨᰮ"))
        }
    if bstack1l1lllllll_opy_(env.get(bstack1111_opy_ (u"࡚ࠧࡆࡠࡄࡘࡍࡑࡊࠢᰯ"))):
        return {
            bstack1111_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᰰ"): bstack1111_opy_ (u"ࠢࡗ࡫ࡶࡹࡦࡲࠠࡔࡶࡸࡨ࡮ࡵࠠࡕࡧࡤࡱ࡙ࠥࡥࡳࡸ࡬ࡧࡪࡹࠢᰱ"),
            bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᰲ"): bstack1111_opy_ (u"ࠤࡾࢁࢀࢃࠢᰳ").format(env.get(bstack1111_opy_ (u"ࠪࡗ࡞࡙ࡔࡆࡏࡢࡘࡊࡇࡍࡇࡑࡘࡒࡉࡇࡔࡊࡑࡑࡗࡊࡘࡖࡆࡔࡘࡖࡎ࠭ᰴ")), env.get(bstack1111_opy_ (u"ࠫࡘ࡟ࡓࡕࡇࡐࡣ࡙ࡋࡁࡎࡒࡕࡓࡏࡋࡃࡕࡋࡇࠫᰵ"))),
            bstack1111_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᰶ"): env.get(bstack1111_opy_ (u"ࠨࡓ࡚ࡕࡗࡉࡒࡥࡄࡆࡈࡌࡒࡎ࡚ࡉࡐࡐࡌࡈ᰷ࠧ")),
            bstack1111_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨ᰸"): env.get(bstack1111_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡃࡗࡌࡐࡉࡏࡄࠣ᰹"))
        }
    if bstack1l1lllllll_opy_(env.get(bstack1111_opy_ (u"ࠤࡄࡔࡕ࡜ࡅ࡚ࡑࡕࠦ᰺"))):
        return {
            bstack1111_opy_ (u"ࠥࡲࡦࡳࡥࠣ᰻"): bstack1111_opy_ (u"ࠦࡆࡶࡰࡷࡧࡼࡳࡷࠨ᰼"),
            bstack1111_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣ᰽"): bstack1111_opy_ (u"ࠨࡻࡾ࠱ࡳࡶࡴࡰࡥࡤࡶ࠲ࡿࢂ࠵ࡻࡾ࠱ࡥࡹ࡮ࡲࡤࡴ࠱ࡾࢁࠧ᰾").format(env.get(bstack1111_opy_ (u"ࠧࡂࡒࡓ࡚ࡊ࡟ࡏࡓࡡࡘࡖࡑ࠭᰿")), env.get(bstack1111_opy_ (u"ࠨࡃࡓࡔ࡛ࡋ࡙ࡐࡔࡢࡅࡈࡉࡏࡖࡐࡗࡣࡓࡇࡍࡆࠩ᱀")), env.get(bstack1111_opy_ (u"ࠩࡄࡔࡕ࡜ࡅ࡚ࡑࡕࡣࡕࡘࡏࡋࡇࡆࡘࡤ࡙ࡌࡖࡉࠪ᱁")), env.get(bstack1111_opy_ (u"ࠪࡅࡕࡖࡖࡆ࡛ࡒࡖࡤࡈࡕࡊࡎࡇࡣࡎࡊࠧ᱂"))),
            bstack1111_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨ᱃"): env.get(bstack1111_opy_ (u"ࠧࡇࡐࡑࡘࡈ࡝ࡔࡘ࡟ࡋࡑࡅࡣࡓࡇࡍࡆࠤ᱄")),
            bstack1111_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧ᱅"): env.get(bstack1111_opy_ (u"ࠢࡂࡒࡓ࡚ࡊ࡟ࡏࡓࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣ᱆"))
        }
    if env.get(bstack1111_opy_ (u"ࠣࡃ࡝࡙ࡗࡋ࡟ࡉࡖࡗࡔࡤ࡛ࡓࡆࡔࡢࡅࡌࡋࡎࡕࠤ᱇")) and env.get(bstack1111_opy_ (u"ࠤࡗࡊࡤࡈࡕࡊࡎࡇࠦ᱈")):
        return {
            bstack1111_opy_ (u"ࠥࡲࡦࡳࡥࠣ᱉"): bstack1111_opy_ (u"ࠦࡆࢀࡵࡳࡧࠣࡇࡎࠨ᱊"),
            bstack1111_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣ᱋"): bstack1111_opy_ (u"ࠨࡻࡾࡽࢀ࠳ࡤࡨࡵࡪ࡮ࡧ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡨࡵࡪ࡮ࡧࡍࡩࡃࡻࡾࠤ᱌").format(env.get(bstack1111_opy_ (u"ࠧࡔ࡛ࡖࡘࡊࡓ࡟ࡕࡇࡄࡑࡋࡕࡕࡏࡆࡄࡘࡎࡕࡎࡔࡇࡕ࡚ࡊࡘࡕࡓࡋࠪᱍ")), env.get(bstack1111_opy_ (u"ࠨࡕ࡜ࡗ࡙ࡋࡍࡠࡖࡈࡅࡒࡖࡒࡐࡌࡈࡇ࡙࠭ᱎ")), env.get(bstack1111_opy_ (u"ࠩࡅ࡙ࡎࡒࡄࡠࡄࡘࡍࡑࡊࡉࡅࠩᱏ"))),
            bstack1111_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧ᱐"): env.get(bstack1111_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡢࡆ࡚ࡏࡌࡅࡋࡇࠦ᱑")),
            bstack1111_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦ᱒"): env.get(bstack1111_opy_ (u"ࠨࡂࡖࡋࡏࡈࡤࡈࡕࡊࡎࡇࡍࡉࠨ᱓"))
        }
    if any([env.get(bstack1111_opy_ (u"ࠢࡄࡑࡇࡉࡇ࡛ࡉࡍࡆࡢࡆ࡚ࡏࡌࡅࡡࡌࡈࠧ᱔")), env.get(bstack1111_opy_ (u"ࠣࡅࡒࡈࡊࡈࡕࡊࡎࡇࡣࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡓࡐࡗࡕࡇࡊࡥࡖࡆࡔࡖࡍࡔࡔࠢ᱕")), env.get(bstack1111_opy_ (u"ࠤࡆࡓࡉࡋࡂࡖࡋࡏࡈࡤ࡙ࡏࡖࡔࡆࡉࡤ࡜ࡅࡓࡕࡌࡓࡓࠨ᱖"))]):
        return {
            bstack1111_opy_ (u"ࠥࡲࡦࡳࡥࠣ᱗"): bstack1111_opy_ (u"ࠦࡆ࡝ࡓࠡࡅࡲࡨࡪࡈࡵࡪ࡮ࡧࠦ᱘"),
            bstack1111_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣ᱙"): env.get(bstack1111_opy_ (u"ࠨࡃࡐࡆࡈࡆ࡚ࡏࡌࡅࡡࡓ࡙ࡇࡒࡉࡄࡡࡅ࡙ࡎࡒࡄࡠࡗࡕࡐࠧᱚ")),
            bstack1111_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤᱛ"): env.get(bstack1111_opy_ (u"ࠣࡅࡒࡈࡊࡈࡕࡊࡎࡇࡣࡇ࡛ࡉࡍࡆࡢࡍࡉࠨᱜ")),
            bstack1111_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᱝ"): env.get(bstack1111_opy_ (u"ࠥࡇࡔࡊࡅࡃࡗࡌࡐࡉࡥࡂࡖࡋࡏࡈࡤࡏࡄࠣᱞ"))
        }
    if env.get(bstack1111_opy_ (u"ࠦࡧࡧ࡭ࡣࡱࡲࡣࡧࡻࡩ࡭ࡦࡑࡹࡲࡨࡥࡳࠤᱟ")):
        return {
            bstack1111_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᱠ"): bstack1111_opy_ (u"ࠨࡂࡢ࡯ࡥࡳࡴࠨᱡ"),
            bstack1111_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᱢ"): env.get(bstack1111_opy_ (u"ࠣࡤࡤࡱࡧࡵ࡯ࡠࡤࡸ࡭ࡱࡪࡒࡦࡵࡸࡰࡹࡹࡕࡳ࡮ࠥᱣ")),
            bstack1111_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᱤ"): env.get(bstack1111_opy_ (u"ࠥࡦࡦࡳࡢࡰࡱࡢࡷ࡭ࡵࡲࡵࡌࡲࡦࡓࡧ࡭ࡦࠤᱥ")),
            bstack1111_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᱦ"): env.get(bstack1111_opy_ (u"ࠧࡨࡡ࡮ࡤࡲࡳࡤࡨࡵࡪ࡮ࡧࡒࡺࡳࡢࡦࡴࠥᱧ"))
        }
    if env.get(bstack1111_opy_ (u"ࠨࡗࡆࡔࡆࡏࡊࡘࠢᱨ")) or env.get(bstack1111_opy_ (u"ࠢࡘࡇࡕࡇࡐࡋࡒࡠࡏࡄࡍࡓࡥࡐࡊࡒࡈࡐࡎࡔࡅࡠࡕࡗࡅࡗ࡚ࡅࡅࠤᱩ")):
        return {
            bstack1111_opy_ (u"ࠣࡰࡤࡱࡪࠨᱪ"): bstack1111_opy_ (u"ࠤ࡚ࡩࡷࡩ࡫ࡦࡴࠥᱫ"),
            bstack1111_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᱬ"): env.get(bstack1111_opy_ (u"ࠦ࡜ࡋࡒࡄࡍࡈࡖࡤࡈࡕࡊࡎࡇࡣ࡚ࡘࡌࠣᱭ")),
            bstack1111_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᱮ"): bstack1111_opy_ (u"ࠨࡍࡢ࡫ࡱࠤࡕ࡯ࡰࡦ࡮࡬ࡲࡪࠨᱯ") if env.get(bstack1111_opy_ (u"ࠢࡘࡇࡕࡇࡐࡋࡒࡠࡏࡄࡍࡓࡥࡐࡊࡒࡈࡐࡎࡔࡅࡠࡕࡗࡅࡗ࡚ࡅࡅࠤᱰ")) else None,
            bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᱱ"): env.get(bstack1111_opy_ (u"ࠤ࡚ࡉࡗࡉࡋࡆࡔࡢࡋࡎ࡚࡟ࡄࡑࡐࡑࡎ࡚ࠢᱲ"))
        }
    if any([env.get(bstack1111_opy_ (u"ࠥࡋࡈࡖ࡟ࡑࡔࡒࡎࡊࡉࡔࠣᱳ")), env.get(bstack1111_opy_ (u"ࠦࡌࡉࡌࡐࡗࡇࡣࡕࡘࡏࡋࡇࡆࡘࠧᱴ")), env.get(bstack1111_opy_ (u"ࠧࡍࡏࡐࡉࡏࡉࡤࡉࡌࡐࡗࡇࡣࡕࡘࡏࡋࡇࡆࡘࠧᱵ"))]):
        return {
            bstack1111_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᱶ"): bstack1111_opy_ (u"ࠢࡈࡱࡲ࡫ࡱ࡫ࠠࡄ࡮ࡲࡹࡩࠨᱷ"),
            bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᱸ"): None,
            bstack1111_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᱹ"): env.get(bstack1111_opy_ (u"ࠥࡔࡗࡕࡊࡆࡅࡗࡣࡎࡊࠢᱺ")),
            bstack1111_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥᱻ"): env.get(bstack1111_opy_ (u"ࠧࡈࡕࡊࡎࡇࡣࡎࡊࠢᱼ"))
        }
    if env.get(bstack1111_opy_ (u"ࠨࡓࡉࡋࡓࡔࡆࡈࡌࡆࠤᱽ")):
        return {
            bstack1111_opy_ (u"ࠢ࡯ࡣࡰࡩࠧ᱾"): bstack1111_opy_ (u"ࠣࡕ࡫࡭ࡵࡶࡡࡣ࡮ࡨࠦ᱿"),
            bstack1111_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᲀ"): env.get(bstack1111_opy_ (u"ࠥࡗࡍࡏࡐࡑࡃࡅࡐࡊࡥࡂࡖࡋࡏࡈࡤ࡛ࡒࡍࠤᲁ")),
            bstack1111_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨᲂ"): bstack1111_opy_ (u"ࠧࡐ࡯ࡣࠢࠦࡿࢂࠨᲃ").format(env.get(bstack1111_opy_ (u"࠭ࡓࡉࡋࡓࡔࡆࡈࡌࡆࡡࡍࡓࡇࡥࡉࡅࠩᲄ"))) if env.get(bstack1111_opy_ (u"ࠢࡔࡊࡌࡔࡕࡇࡂࡍࡇࡢࡎࡔࡈ࡟ࡊࡆࠥᲅ")) else None,
            bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᲆ"): env.get(bstack1111_opy_ (u"ࠤࡖࡌࡎࡖࡐࡂࡄࡏࡉࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࠦᲇ"))
        }
    if bstack1l1lllllll_opy_(env.get(bstack1111_opy_ (u"ࠥࡒࡊ࡚ࡌࡊࡈ࡜ࠦᲈ"))):
        return {
            bstack1111_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᲉ"): bstack1111_opy_ (u"ࠧࡔࡥࡵ࡮࡬ࡪࡾࠨᲊ"),
            bstack1111_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤ᲋"): env.get(bstack1111_opy_ (u"ࠢࡅࡇࡓࡐࡔ࡟࡟ࡖࡔࡏࠦ᲌")),
            bstack1111_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥ᲍"): env.get(bstack1111_opy_ (u"ࠤࡖࡍ࡙ࡋ࡟ࡏࡃࡐࡉࠧ᲎")),
            bstack1111_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤ᲏"): env.get(bstack1111_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡢࡍࡉࠨᲐ"))
        }
    if bstack1l1lllllll_opy_(env.get(bstack1111_opy_ (u"ࠧࡍࡉࡕࡊࡘࡆࡤࡇࡃࡕࡋࡒࡒࡘࠨᲑ"))):
        return {
            bstack1111_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦᲒ"): bstack1111_opy_ (u"ࠢࡈ࡫ࡷࡌࡺࡨࠠࡂࡥࡷ࡭ࡴࡴࡳࠣᲓ"),
            bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᲔ"): bstack1111_opy_ (u"ࠤࡾࢁ࠴ࢁࡽ࠰ࡣࡦࡸ࡮ࡵ࡮ࡴ࠱ࡵࡹࡳࡹ࠯ࡼࡿࠥᲕ").format(env.get(bstack1111_opy_ (u"ࠪࡋࡎ࡚ࡈࡖࡄࡢࡗࡊࡘࡖࡆࡔࡢ࡙ࡗࡒࠧᲖ")), env.get(bstack1111_opy_ (u"ࠫࡌࡏࡔࡉࡗࡅࡣࡗࡋࡐࡐࡕࡌࡘࡔࡘ࡙ࠨᲗ")), env.get(bstack1111_opy_ (u"ࠬࡍࡉࡕࡊࡘࡆࡤࡘࡕࡏࡡࡌࡈࠬᲘ"))),
            bstack1111_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᲙ"): env.get(bstack1111_opy_ (u"ࠢࡈࡋࡗࡌ࡚ࡈ࡟ࡘࡑࡕࡏࡋࡒࡏࡘࠤᲚ")),
            bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᲛ"): env.get(bstack1111_opy_ (u"ࠤࡊࡍ࡙ࡎࡕࡃࡡࡕ࡙ࡓࡥࡉࡅࠤᲜ"))
        }
    if env.get(bstack1111_opy_ (u"ࠥࡇࡎࠨᲝ")) == bstack1111_opy_ (u"ࠦࡹࡸࡵࡦࠤᲞ") and env.get(bstack1111_opy_ (u"ࠧ࡜ࡅࡓࡅࡈࡐࠧᲟ")) == bstack1111_opy_ (u"ࠨ࠱ࠣᲠ"):
        return {
            bstack1111_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᲡ"): bstack1111_opy_ (u"ࠣࡘࡨࡶࡨ࡫࡬ࠣᲢ"),
            bstack1111_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᲣ"): bstack1111_opy_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡿࢂࠨᲤ").format(env.get(bstack1111_opy_ (u"࡛ࠫࡋࡒࡄࡇࡏࡣ࡚ࡘࡌࠨᲥ"))),
            bstack1111_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᲦ"): None,
            bstack1111_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᲧ"): None,
        }
    if env.get(bstack1111_opy_ (u"ࠢࡕࡇࡄࡑࡈࡏࡔ࡚ࡡ࡙ࡉࡗ࡙ࡉࡐࡐࠥᲨ")):
        return {
            bstack1111_opy_ (u"ࠣࡰࡤࡱࡪࠨᲩ"): bstack1111_opy_ (u"ࠤࡗࡩࡦࡳࡣࡪࡶࡼࠦᲪ"),
            bstack1111_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᲫ"): None,
            bstack1111_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨᲬ"): env.get(bstack1111_opy_ (u"࡚ࠧࡅࡂࡏࡆࡍ࡙࡟࡟ࡑࡔࡒࡎࡊࡉࡔࡠࡐࡄࡑࡊࠨᲭ")),
            bstack1111_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᲮ"): env.get(bstack1111_opy_ (u"ࠢࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࠨᲯ"))
        }
    if any([env.get(bstack1111_opy_ (u"ࠣࡅࡒࡒࡈࡕࡕࡓࡕࡈࠦᲰ")), env.get(bstack1111_opy_ (u"ࠤࡆࡓࡓࡉࡏࡖࡔࡖࡉࡤ࡛ࡒࡍࠤᲱ")), env.get(bstack1111_opy_ (u"ࠥࡇࡔࡔࡃࡐࡗࡕࡗࡊࡥࡕࡔࡇࡕࡒࡆࡓࡅࠣᲲ")), env.get(bstack1111_opy_ (u"ࠦࡈࡕࡎࡄࡑࡘࡖࡘࡋ࡟ࡕࡇࡄࡑࠧᲳ"))]):
        return {
            bstack1111_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᲴ"): bstack1111_opy_ (u"ࠨࡃࡰࡰࡦࡳࡺࡸࡳࡦࠤᲵ"),
            bstack1111_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᲶ"): None,
            bstack1111_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᲷ"): env.get(bstack1111_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡠࡌࡒࡆࡤࡔࡁࡎࡇࠥᲸ")) or None,
            bstack1111_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᲹ"): env.get(bstack1111_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡢࡍࡉࠨᲺ"), 0)
        }
    if env.get(bstack1111_opy_ (u"ࠧࡍࡏࡠࡌࡒࡆࡤࡔࡁࡎࡇࠥ᲻")):
        return {
            bstack1111_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦ᲼"): bstack1111_opy_ (u"ࠢࡈࡱࡆࡈࠧᲽ"),
            bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦᲾ"): None,
            bstack1111_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᲿ"): env.get(bstack1111_opy_ (u"ࠥࡋࡔࡥࡊࡐࡄࡢࡒࡆࡓࡅࠣ᳀")),
            bstack1111_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥ᳁"): env.get(bstack1111_opy_ (u"ࠧࡍࡏࡠࡒࡌࡔࡊࡒࡉࡏࡇࡢࡇࡔ࡛ࡎࡕࡇࡕࠦ᳂"))
        }
    if env.get(bstack1111_opy_ (u"ࠨࡃࡇࡡࡅ࡙ࡎࡒࡄࡠࡋࡇࠦ᳃")):
        return {
            bstack1111_opy_ (u"ࠢ࡯ࡣࡰࡩࠧ᳄"): bstack1111_opy_ (u"ࠣࡅࡲࡨࡪࡌࡲࡦࡵ࡫ࠦ᳅"),
            bstack1111_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧ᳆"): env.get(bstack1111_opy_ (u"ࠥࡇࡋࡥࡂࡖࡋࡏࡈࡤ࡛ࡒࡍࠤ᳇")),
            bstack1111_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨ᳈"): env.get(bstack1111_opy_ (u"ࠧࡉࡆࡠࡒࡌࡔࡊࡒࡉࡏࡇࡢࡒࡆࡓࡅࠣ᳉")),
            bstack1111_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧ᳊"): env.get(bstack1111_opy_ (u"ࠢࡄࡈࡢࡆ࡚ࡏࡌࡅࡡࡌࡈࠧ᳋"))
        }
    return {bstack1111_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢ᳌"): None}
def get_host_info():
    return {
        bstack1111_opy_ (u"ࠤ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠦ᳍"): platform.node(),
        bstack1111_opy_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱࠧ᳎"): platform.system(),
        bstack1111_opy_ (u"ࠦࡹࡿࡰࡦࠤ᳏"): platform.machine(),
        bstack1111_opy_ (u"ࠧࡼࡥࡳࡵ࡬ࡳࡳࠨ᳐"): platform.version(),
        bstack1111_opy_ (u"ࠨࡡࡳࡥ࡫ࠦ᳑"): platform.architecture()[0]
    }
def bstack11lll1l1ll_opy_():
    try:
        import selenium
        return True
    except ImportError:
        return False
def bstack111ll11llll_opy_():
    if bstack1l1l11ll11_opy_.get_property(bstack1111_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ᳒")):
        return bstack1111_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧ᳓")
    return bstack1111_opy_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࡢ࡫ࡷ࡯ࡤࠨ᳔")
def bstack111ll1l1l11_opy_(driver):
    info = {
        bstack1111_opy_ (u"ࠪࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴ᳕ࠩ"): driver.capabilities,
        bstack1111_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡤ࡯ࡤࠨ᳖"): driver.session_id,
        bstack1111_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ᳗࠭"): driver.capabilities.get(bstack1111_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨ᳘ࠫ"), None),
        bstack1111_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡠࡸࡨࡶࡸ࡯࡯࡯᳙ࠩ"): driver.capabilities.get(bstack1111_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩ᳚"), None),
        bstack1111_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࠫ᳛"): driver.capabilities.get(bstack1111_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡓࡧ࡭ࡦ᳜ࠩ"), None),
        bstack1111_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡥࡶࡦࡴࡶ࡭ࡴࡴ᳝ࠧ"):driver.capabilities.get(bstack1111_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡖࡦࡴࡶ࡭ࡴࡴ᳞ࠧ"), None),
    }
    if bstack111ll11llll_opy_() == bstack1111_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯᳟ࠬ"):
        if bstack111l1ll1_opy_():
            info[bstack1111_opy_ (u"ࠧࡱࡴࡲࡨࡺࡩࡴࠨ᳠")] = bstack1111_opy_ (u"ࠨࡣࡳࡴ࠲ࡧࡵࡵࡱࡰࡥࡹ࡫ࠧ᳡")
        elif driver.capabilities.get(bstack1111_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵ᳢ࠪ"), {}).get(bstack1111_opy_ (u"ࠪࡸࡺࡸࡢࡰࡵࡦࡥࡱ࡫᳣ࠧ"), False):
            info[bstack1111_opy_ (u"ࠫࡵࡸ࡯ࡥࡷࡦࡸ᳤ࠬ")] = bstack1111_opy_ (u"ࠬࡺࡵࡳࡤࡲࡷࡨࡧ࡬ࡦ᳥ࠩ")
        else:
            info[bstack1111_opy_ (u"࠭ࡰࡳࡱࡧࡹࡨࡺ᳦ࠧ")] = bstack1111_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡦ᳧ࠩ")
    return info
def bstack111l1ll1_opy_():
    if bstack1l1l11ll11_opy_.get_property(bstack1111_opy_ (u"ࠨࡣࡳࡴࡤࡧࡵࡵࡱࡰࡥࡹ࡫᳨ࠧ")):
        return True
    if bstack1l1lllllll_opy_(os.environ.get(bstack1111_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡋࡖࡣࡆࡖࡐࡠࡃࡘࡘࡔࡓࡁࡕࡇࠪᳩ"), None)):
        return True
    return False
def bstack1l1l1ll11_opy_(bstack111lllll111_opy_, url, data, config):
    headers = config.get(bstack1111_opy_ (u"ࠪ࡬ࡪࡧࡤࡦࡴࡶࠫᳪ"), None)
    proxies = bstack1l111ll1ll_opy_(config, url)
    auth = config.get(bstack1111_opy_ (u"ࠫࡦࡻࡴࡩࠩᳫ"), None)
    response = requests.request(
            bstack111lllll111_opy_,
            url=url,
            headers=headers,
            auth=auth,
            json=data,
            proxies=proxies
        )
    return response
def bstack1l11lllll1_opy_(bstack11ll11ll1l_opy_, size):
    bstack111l1l1l1_opy_ = []
    while len(bstack11ll11ll1l_opy_) > size:
        bstack11l1l1ll_opy_ = bstack11ll11ll1l_opy_[:size]
        bstack111l1l1l1_opy_.append(bstack11l1l1ll_opy_)
        bstack11ll11ll1l_opy_ = bstack11ll11ll1l_opy_[size:]
    bstack111l1l1l1_opy_.append(bstack11ll11ll1l_opy_)
    return bstack111l1l1l1_opy_
def bstack111llllll11_opy_(message, bstack111ll111l11_opy_=False):
    os.write(1, bytes(message, bstack1111_opy_ (u"ࠬࡻࡴࡧ࠯࠻ࠫᳬ")))
    os.write(1, bytes(bstack1111_opy_ (u"࠭࡜࡯᳭ࠩ"), bstack1111_opy_ (u"ࠧࡶࡶࡩ࠱࠽࠭ᳮ")))
    if bstack111ll111l11_opy_:
        with open(bstack1111_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠮ࡱ࠴࠵ࡾ࠳ࠧᳯ") + os.environ[bstack1111_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡂࡖࡋࡏࡈࡤࡎࡁࡔࡊࡈࡈࡤࡏࡄࠨᳰ")] + bstack1111_opy_ (u"ࠪ࠲ࡱࡵࡧࠨᳱ"), bstack1111_opy_ (u"ࠫࡦ࠭ᳲ")) as f:
            f.write(message + bstack1111_opy_ (u"ࠬࡢ࡮ࠨᳳ"))
def bstack1l1l1ll11ll_opy_():
    return os.environ[bstack1111_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡕࡕࡑࡐࡅ࡙ࡏࡏࡏࠩ᳴")].lower() == bstack1111_opy_ (u"ࠧࡵࡴࡸࡩࠬᳵ")
def bstack11l1111l11_opy_():
    return bstack1111ll1l1l_opy_().replace(tzinfo=None).isoformat() + bstack1111_opy_ (u"ࠨ࡜ࠪᳶ")
def bstack11l11111111_opy_(start, finish):
    return (datetime.datetime.fromisoformat(finish.rstrip(bstack1111_opy_ (u"ࠩ࡝ࠫ᳷"))) - datetime.datetime.fromisoformat(start.rstrip(bstack1111_opy_ (u"ࠪ࡞ࠬ᳸")))).total_seconds() * 1000
def bstack111ll1l1l1l_opy_(timestamp):
    return bstack11l11111ll1_opy_(timestamp).isoformat() + bstack1111_opy_ (u"ࠫ࡟࠭᳹")
def bstack111ll1l11l1_opy_(bstack11l11l1l111_opy_):
    date_format = bstack1111_opy_ (u"࡙ࠬࠫࠦ࡯ࠨࡨࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪ࠮ࠦࡨࠪᳺ")
    bstack111l1lll1l1_opy_ = datetime.datetime.strptime(bstack11l11l1l111_opy_, date_format)
    return bstack111l1lll1l1_opy_.isoformat() + bstack1111_opy_ (u"࡚࠭ࠨ᳻")
def bstack111ll111l1l_opy_(outcome):
    _, exception, _ = outcome.excinfo or (None, None, None)
    if exception:
        return bstack1111_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ᳼")
    else:
        return bstack1111_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨ᳽")
def bstack1l1lllllll_opy_(val):
    if val is None:
        return False
    return val.__str__().lower() == bstack1111_opy_ (u"ࠩࡷࡶࡺ࡫ࠧ᳾")
def bstack111llll11l1_opy_(val):
    return val.__str__().lower() == bstack1111_opy_ (u"ࠪࡪࡦࡲࡳࡦࠩ᳿")
def error_handler(bstack111ll1l1111_opy_=Exception, class_method=False, default_value=None):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except bstack111ll1l1111_opy_ as e:
                print(bstack1111_opy_ (u"ࠦࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡪࡺࡴࡣࡵ࡫ࡲࡲࠥࢁࡽࠡ࠯ࡁࠤࢀࢃ࠺ࠡࡽࢀࠦᴀ").format(func.__name__, bstack111ll1l1111_opy_.__name__, str(e)))
                return default_value
        return wrapper
    def bstack111ll1111l1_opy_(bstack11l111111ll_opy_):
        def wrapped(cls, *args, **kwargs):
            try:
                return bstack11l111111ll_opy_(cls, *args, **kwargs)
            except bstack111ll1l1111_opy_ as e:
                print(bstack1111_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡻࡾࠢ࠰ࡂࠥࢁࡽ࠻ࠢࡾࢁࠧᴁ").format(bstack11l111111ll_opy_.__name__, bstack111ll1l1111_opy_.__name__, str(e)))
                return default_value
        return wrapped
    if class_method:
        return bstack111ll1111l1_opy_
    else:
        return decorator
def bstack1ll1l1l1_opy_(bstack11111l11l1_opy_):
    if os.getenv(bstack1111_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡕࡕࡑࡐࡅ࡙ࡏࡏࡏࠩᴂ")) is not None:
        return bstack1l1lllllll_opy_(os.getenv(bstack1111_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡁࡖࡖࡒࡑࡆ࡚ࡉࡐࡐࠪᴃ")))
    if bstack1111_opy_ (u"ࠨࡣࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠬᴄ") in bstack11111l11l1_opy_ and bstack111llll11l1_opy_(bstack11111l11l1_opy_[bstack1111_opy_ (u"ࠩࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳ࠭ᴅ")]):
        return False
    if bstack1111_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠬᴆ") in bstack11111l11l1_opy_ and bstack111llll11l1_opy_(bstack11111l11l1_opy_[bstack1111_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳ࠭ᴇ")]):
        return False
    return True
def bstack11l1l1l11_opy_():
    try:
        from pytest_bdd import reporting
        bstack111lll1l111_opy_ = os.environ.get(bstack1111_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡚࡙ࡅࡓࡡࡉࡖࡆࡓࡅࡘࡑࡕࡏࠧᴈ"), None)
        return bstack111lll1l111_opy_ is None or bstack111lll1l111_opy_ == bstack1111_opy_ (u"ࠨࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠥᴉ")
    except Exception as e:
        return False
def bstack1ll111ll1_opy_(hub_url, CONFIG):
    if bstack11ll11l11l_opy_() <= version.parse(bstack1111_opy_ (u"ࠧ࠴࠰࠴࠷࠳࠶ࠧᴊ")):
        if hub_url:
            return bstack1111_opy_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࠤᴋ") + hub_url + bstack1111_opy_ (u"ࠤ࠽࠼࠵࠵ࡷࡥ࠱࡫ࡹࡧࠨᴌ")
        return bstack1l11ll1lll_opy_
    if hub_url:
        return bstack1111_opy_ (u"ࠥ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠧᴍ") + hub_url + bstack1111_opy_ (u"ࠦ࠴ࡽࡤ࠰ࡪࡸࡦࠧᴎ")
    return bstack11lll11l_opy_
def bstack111lll1ll1l_opy_():
    return isinstance(os.getenv(bstack1111_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡕ࡟ࡔࡆࡕࡗࡣࡕࡒࡕࡈࡋࡑࠫᴏ")), str)
def bstack1l11l1lll1_opy_(url):
    return urlparse(url).hostname
def bstack11l111l111_opy_(hostname):
    for bstack111111l1_opy_ in bstack1ll11ll11_opy_:
        regex = re.compile(bstack111111l1_opy_)
        if regex.match(hostname):
            return True
    return False
def bstack11l1111l11l_opy_(bstack111lll1111l_opy_, file_name, logger):
    bstack1ll1llll1l_opy_ = os.path.join(os.path.expanduser(bstack1111_opy_ (u"࠭ࡾࠨᴐ")), bstack111lll1111l_opy_)
    try:
        if not os.path.exists(bstack1ll1llll1l_opy_):
            os.makedirs(bstack1ll1llll1l_opy_)
        file_path = os.path.join(os.path.expanduser(bstack1111_opy_ (u"ࠧࡿࠩᴑ")), bstack111lll1111l_opy_, file_name)
        if not os.path.isfile(file_path):
            with open(file_path, bstack1111_opy_ (u"ࠨࡹࠪᴒ")):
                pass
            with open(file_path, bstack1111_opy_ (u"ࠤࡺ࠯ࠧᴓ")) as outfile:
                json.dump({}, outfile)
        return file_path
    except Exception as e:
        logger.debug(bstack11111ll1_opy_.format(str(e)))
def bstack111lll1lll1_opy_(file_name, key, value, logger):
    file_path = bstack11l1111l11l_opy_(bstack1111_opy_ (u"ࠪ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪᴔ"), file_name, logger)
    if file_path != None:
        if os.path.exists(file_path):
            bstack1l111ll1_opy_ = json.load(open(file_path, bstack1111_opy_ (u"ࠫࡷࡨࠧᴕ")))
        else:
            bstack1l111ll1_opy_ = {}
        bstack1l111ll1_opy_[key] = value
        with open(file_path, bstack1111_opy_ (u"ࠧࡽࠫࠣᴖ")) as outfile:
            json.dump(bstack1l111ll1_opy_, outfile)
def bstack1l1l1l11l1_opy_(file_name, logger):
    file_path = bstack11l1111l11l_opy_(bstack1111_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭ᴗ"), file_name, logger)
    bstack1l111ll1_opy_ = {}
    if file_path != None and os.path.exists(file_path):
        with open(file_path, bstack1111_opy_ (u"ࠧࡳࠩᴘ")) as bstack1l11ll1ll_opy_:
            bstack1l111ll1_opy_ = json.load(bstack1l11ll1ll_opy_)
    return bstack1l111ll1_opy_
def bstack1l1l1l1l11_opy_(file_path, logger):
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
    except Exception as e:
        logger.debug(bstack1111_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡨࡪࡲࡥࡵ࡫ࡱ࡫ࠥ࡬ࡩ࡭ࡧ࠽ࠤࠬᴙ") + file_path + bstack1111_opy_ (u"ࠩࠣࠫᴚ") + str(e))
def bstack11ll11l11l_opy_():
    from selenium import webdriver
    return version.parse(webdriver.__version__)
class Notset:
    def __repr__(self):
        return bstack1111_opy_ (u"ࠥࡀࡓࡕࡔࡔࡇࡗࡂࠧᴛ")
def bstack1l1l11l111_opy_(config):
    if bstack1111_opy_ (u"ࠫ࡮ࡹࡐ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠪᴜ") in config:
        del (config[bstack1111_opy_ (u"ࠬ࡯ࡳࡑ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࠫᴝ")])
        return False
    if bstack11ll11l11l_opy_() < version.parse(bstack1111_opy_ (u"࠭࠳࠯࠶࠱࠴ࠬᴞ")):
        return False
    if bstack11ll11l11l_opy_() >= version.parse(bstack1111_opy_ (u"ࠧ࠵࠰࠴࠲࠺࠭ᴟ")):
        return True
    if bstack1111_opy_ (u"ࠨࡷࡶࡩ࡜࠹ࡃࠨᴠ") in config and config[bstack1111_opy_ (u"ࠩࡸࡷࡪ࡝࠳ࡄࠩᴡ")] is False:
        return False
    else:
        return True
def bstack11ll1l1l11_opy_(args_list, bstack111llll1l1l_opy_):
    index = -1
    for value in bstack111llll1l1l_opy_:
        try:
            index = args_list.index(value)
            return index
        except Exception as e:
            return index
    return index
def bstack11ll1l1l111_opy_(a, b):
  for k, v in b.items():
    if isinstance(v, dict) and k in a and isinstance(a[k], dict):
        bstack11ll1l1l111_opy_(a[k], v)
    else:
        a[k] = v
class Result:
    def __init__(self, result=None, duration=None, exception=None, bstack111l1lll1l_opy_=None):
        self.result = result
        self.duration = duration
        self.exception = exception
        self.exception_type = type(self.exception).__name__ if exception else None
        self.bstack111l1lll1l_opy_ = bstack111l1lll1l_opy_
    @classmethod
    def passed(cls):
        return Result(result=bstack1111_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪᴢ"))
    @classmethod
    def failed(cls, exception=None):
        return Result(result=bstack1111_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᴣ"), exception=exception)
    def bstack1lllllll111_opy_(self):
        if self.result != bstack1111_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᴤ"):
            return None
        if isinstance(self.exception_type, str) and bstack1111_opy_ (u"ࠨࡁࡴࡵࡨࡶࡹ࡯࡯࡯ࠤᴥ") in self.exception_type:
            return bstack1111_opy_ (u"ࠢࡂࡵࡶࡩࡷࡺࡩࡰࡰࡈࡶࡷࡵࡲࠣᴦ")
        return bstack1111_opy_ (u"ࠣࡗࡱ࡬ࡦࡴࡤ࡭ࡧࡧࡉࡷࡸ࡯ࡳࠤᴧ")
    def bstack11l11111l1l_opy_(self):
        if self.result != bstack1111_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩᴨ"):
            return None
        if self.bstack111l1lll1l_opy_:
            return self.bstack111l1lll1l_opy_
        return bstack111l1ll1lll_opy_(self.exception)
def bstack111l1ll1lll_opy_(exc):
    return [traceback.format_exception(exc)]
def bstack11l1111ll1l_opy_(message):
    if isinstance(message, str):
        return not bool(message and message.strip())
    return True
def bstack11lll1l11_opy_(object, key, default_value):
    if not object or not object.__dict__:
        return default_value
    if key in object.__dict__.keys():
        return object.__dict__.get(key)
    return default_value
def bstack1l1ll1lll_opy_(config, logger):
    try:
        import playwright
        bstack111lllll1ll_opy_ = playwright.__file__
        bstack111ll1111ll_opy_ = os.path.split(bstack111lllll1ll_opy_)
        bstack111lll1l1ll_opy_ = bstack111ll1111ll_opy_[0] + bstack1111_opy_ (u"ࠪ࠳ࡩࡸࡩࡷࡧࡵ࠳ࡵࡧࡣ࡬ࡣࡪࡩ࠴ࡲࡩࡣ࠱ࡦࡰ࡮࠵ࡣ࡭࡫࠱࡮ࡸ࠭ᴩ")
        os.environ[bstack1111_opy_ (u"ࠫࡌࡒࡏࡃࡃࡏࡣࡆࡍࡅࡏࡖࡢࡌ࡙࡚ࡐࡠࡒࡕࡓ࡝࡟ࠧᴪ")] = bstack1lll1llll1_opy_(config)
        with open(bstack111lll1l1ll_opy_, bstack1111_opy_ (u"ࠬࡸࠧᴫ")) as f:
            bstack1ll111l1l1_opy_ = f.read()
            bstack111lll111l1_opy_ = bstack1111_opy_ (u"࠭ࡧ࡭ࡱࡥࡥࡱ࠳ࡡࡨࡧࡱࡸࠬᴬ")
            bstack111ll111ll1_opy_ = bstack1ll111l1l1_opy_.find(bstack111lll111l1_opy_)
            if bstack111ll111ll1_opy_ == -1:
              process = subprocess.Popen(bstack1111_opy_ (u"ࠢ࡯ࡲࡰࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥ࡭࡬ࡰࡤࡤࡰ࠲ࡧࡧࡦࡰࡷࠦᴭ"), shell=True, cwd=bstack111ll1111ll_opy_[0])
              process.wait()
              bstack111lllllll1_opy_ = bstack1111_opy_ (u"ࠨࠤࡸࡷࡪࠦࡳࡵࡴ࡬ࡧࡹࠨ࠻ࠨᴮ")
              bstack11l111l11ll_opy_ = bstack1111_opy_ (u"ࠤࠥࠦࠥࡢࠢࡶࡵࡨࠤࡸࡺࡲࡪࡥࡷࡠࠧࡁࠠࡤࡱࡱࡷࡹࠦࡻࠡࡤࡲࡳࡹࡹࡴࡳࡣࡳࠤࢂࠦ࠽ࠡࡴࡨࡵࡺ࡯ࡲࡦࠪࠪ࡫ࡱࡵࡢࡢ࡮࠰ࡥ࡬࡫࡮ࡵࠩࠬ࠿ࠥ࡯ࡦࠡࠪࡳࡶࡴࡩࡥࡴࡵ࠱ࡩࡳࡼ࠮ࡈࡎࡒࡆࡆࡒ࡟ࡂࡉࡈࡒ࡙ࡥࡈࡕࡖࡓࡣࡕࡘࡏ࡙࡛ࠬࠤࡧࡵ࡯ࡵࡵࡷࡶࡦࡶࠨࠪ࠽ࠣࠦࠧࠨᴯ")
              bstack11l11l111ll_opy_ = bstack1ll111l1l1_opy_.replace(bstack111lllllll1_opy_, bstack11l111l11ll_opy_)
              with open(bstack111lll1l1ll_opy_, bstack1111_opy_ (u"ࠪࡻࠬᴰ")) as f:
                f.write(bstack11l11l111ll_opy_)
    except Exception as e:
        logger.error(bstack111l1l11_opy_.format(str(e)))
def bstack1ll1l1111_opy_():
  try:
    bstack111ll11l1l1_opy_ = os.path.join(tempfile.gettempdir(), bstack1111_opy_ (u"ࠫࡴࡶࡴࡪ࡯ࡤࡰࡤ࡮ࡵࡣࡡࡸࡶࡱ࠴ࡪࡴࡱࡱࠫᴱ"))
    bstack11l1111l1ll_opy_ = []
    if os.path.exists(bstack111ll11l1l1_opy_):
      with open(bstack111ll11l1l1_opy_) as f:
        bstack11l1111l1ll_opy_ = json.load(f)
      os.remove(bstack111ll11l1l1_opy_)
    return bstack11l1111l1ll_opy_
  except:
    pass
  return []
def bstack111111111_opy_(bstack1ll11l111l_opy_):
  try:
    bstack11l1111l1ll_opy_ = []
    bstack111ll11l1l1_opy_ = os.path.join(tempfile.gettempdir(), bstack1111_opy_ (u"ࠬࡵࡰࡵ࡫ࡰࡥࡱࡥࡨࡶࡤࡢࡹࡷࡲ࠮࡫ࡵࡲࡲࠬᴲ"))
    if os.path.exists(bstack111ll11l1l1_opy_):
      with open(bstack111ll11l1l1_opy_) as f:
        bstack11l1111l1ll_opy_ = json.load(f)
    bstack11l1111l1ll_opy_.append(bstack1ll11l111l_opy_)
    with open(bstack111ll11l1l1_opy_, bstack1111_opy_ (u"࠭ࡷࠨᴳ")) as f:
        json.dump(bstack11l1111l1ll_opy_, f)
  except:
    pass
def bstack11ll1111_opy_(logger, bstack111lll11l11_opy_ = False):
  try:
    test_name = os.environ.get(bstack1111_opy_ (u"ࠧࡑ࡛ࡗࡉࡘ࡚࡟ࡕࡇࡖࡘࡤࡔࡁࡎࡇࠪᴴ"), bstack1111_opy_ (u"ࠨࠩᴵ"))
    if test_name == bstack1111_opy_ (u"ࠩࠪᴶ"):
        test_name = threading.current_thread().__dict__.get(bstack1111_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࡅࡨࡩࡥࡴࡦࡵࡷࡣࡳࡧ࡭ࡦࠩᴷ"), bstack1111_opy_ (u"ࠫࠬᴸ"))
    bstack111llllll1l_opy_ = bstack1111_opy_ (u"ࠬ࠲ࠠࠨᴹ").join(threading.current_thread().bstackTestErrorMessages)
    if bstack111lll11l11_opy_:
        bstack1lll111ll_opy_ = os.environ.get(bstack1111_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡖࡌࡂࡖࡉࡓࡗࡓ࡟ࡊࡐࡇࡉ࡝࠭ᴺ"), bstack1111_opy_ (u"ࠧ࠱ࠩᴻ"))
        bstack1ll1111ll1_opy_ = {bstack1111_opy_ (u"ࠨࡰࡤࡱࡪ࠭ᴼ"): test_name, bstack1111_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨᴽ"): bstack111llllll1l_opy_, bstack1111_opy_ (u"ࠪ࡭ࡳࡪࡥࡹࠩᴾ"): bstack1lll111ll_opy_}
        bstack11l111111l1_opy_ = []
        bstack111ll1ll1ll_opy_ = os.path.join(tempfile.gettempdir(), bstack1111_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࡣࡵࡶࡰࡠࡧࡵࡶࡴࡸ࡟࡭࡫ࡶࡸ࠳ࡰࡳࡰࡰࠪᴿ"))
        if os.path.exists(bstack111ll1ll1ll_opy_):
            with open(bstack111ll1ll1ll_opy_) as f:
                bstack11l111111l1_opy_ = json.load(f)
        bstack11l111111l1_opy_.append(bstack1ll1111ll1_opy_)
        with open(bstack111ll1ll1ll_opy_, bstack1111_opy_ (u"ࠬࡽࠧᵀ")) as f:
            json.dump(bstack11l111111l1_opy_, f)
    else:
        bstack1ll1111ll1_opy_ = {bstack1111_opy_ (u"࠭࡮ࡢ࡯ࡨࠫᵁ"): test_name, bstack1111_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭ᵂ"): bstack111llllll1l_opy_, bstack1111_opy_ (u"ࠨ࡫ࡱࡨࡪࡾࠧᵃ"): str(multiprocessing.current_process().name)}
        if bstack1111_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡡࡨࡶࡷࡵࡲࡠ࡮࡬ࡷࡹ࠭ᵄ") not in multiprocessing.current_process().__dict__.keys():
            multiprocessing.current_process().bstack_error_list = []
        multiprocessing.current_process().bstack_error_list.append(bstack1ll1111ll1_opy_)
  except Exception as e:
      logger.warn(bstack1111_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡳࡵࡱࡵࡩࠥࡶࡹࡵࡧࡶࡸࠥ࡬ࡵ࡯ࡰࡨࡰࠥࡪࡡࡵࡣ࠽ࠤࢀࢃࠢᵅ").format(e))
def bstack1lll1111l1_opy_(error_message, test_name, index, logger):
  try:
    from filelock import FileLock
  except ImportError:
    logger.debug(bstack1111_opy_ (u"ࠫ࡫࡯࡬ࡦ࡮ࡲࡧࡰࠦ࡮ࡰࡶࠣࡥࡻࡧࡩ࡭ࡣࡥࡰࡪ࠲ࠠࡶࡵ࡬ࡲ࡬ࠦࡢࡢࡵ࡬ࡧࠥ࡬ࡩ࡭ࡧࠣࡳࡵ࡫ࡲࡢࡶ࡬ࡳࡳࡹࠧᵆ"))
    try:
      bstack11l111l1l1l_opy_ = []
      bstack1ll1111ll1_opy_ = {bstack1111_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᵇ"): test_name, bstack1111_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬᵈ"): error_message, bstack1111_opy_ (u"ࠧࡪࡰࡧࡩࡽ࠭ᵉ"): index}
      bstack111ll1l1ll1_opy_ = os.path.join(tempfile.gettempdir(), bstack1111_opy_ (u"ࠨࡴࡲࡦࡴࡺ࡟ࡦࡴࡵࡳࡷࡥ࡬ࡪࡵࡷ࠲࡯ࡹ࡯࡯ࠩᵊ"))
      if os.path.exists(bstack111ll1l1ll1_opy_):
          with open(bstack111ll1l1ll1_opy_) as f:
              bstack11l111l1l1l_opy_ = json.load(f)
      bstack11l111l1l1l_opy_.append(bstack1ll1111ll1_opy_)
      with open(bstack111ll1l1ll1_opy_, bstack1111_opy_ (u"ࠩࡺࠫᵋ")) as f:
          json.dump(bstack11l111l1l1l_opy_, f)
    except Exception as e:
      logger.warn(bstack1111_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡳࡵࡱࡵࡩࠥࡸ࡯ࡣࡱࡷࠤ࡫ࡻ࡮࡯ࡧ࡯ࠤࡩࡧࡴࡢ࠼ࠣࡿࢂࠨᵌ").format(e))
    return
  bstack11l111l1l1l_opy_ = []
  bstack1ll1111ll1_opy_ = {bstack1111_opy_ (u"ࠫࡳࡧ࡭ࡦࠩᵍ"): test_name, bstack1111_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫᵎ"): error_message, bstack1111_opy_ (u"࠭ࡩ࡯ࡦࡨࡼࠬᵏ"): index}
  bstack111ll1l1ll1_opy_ = os.path.join(tempfile.gettempdir(), bstack1111_opy_ (u"ࠧࡳࡱࡥࡳࡹࡥࡥࡳࡴࡲࡶࡤࡲࡩࡴࡶ࠱࡮ࡸࡵ࡮ࠨᵐ"))
  lock_file = bstack111ll1l1ll1_opy_ + bstack1111_opy_ (u"ࠨ࠰࡯ࡳࡨࡱࠧᵑ")
  try:
    with FileLock(lock_file, timeout=10):
      if os.path.exists(bstack111ll1l1ll1_opy_):
          with open(bstack111ll1l1ll1_opy_, bstack1111_opy_ (u"ࠩࡵࠫᵒ")) as f:
              content = f.read().strip()
              if content:
                  bstack11l111l1l1l_opy_ = json.load(open(bstack111ll1l1ll1_opy_))
      bstack11l111l1l1l_opy_.append(bstack1ll1111ll1_opy_)
      with open(bstack111ll1l1ll1_opy_, bstack1111_opy_ (u"ࠪࡻࠬᵓ")) as f:
          json.dump(bstack11l111l1l1l_opy_, f)
  except Exception as e:
    logger.warn(bstack1111_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡴࡶࡲࡶࡪࠦࡲࡰࡤࡲࡸࠥ࡬ࡵ࡯ࡰࡨࡰࠥࡪࡡࡵࡣࠣࡻ࡮ࡺࡨࠡࡨ࡬ࡰࡪࠦ࡬ࡰࡥ࡮࡭ࡳ࡭࠺ࠡࡽࢀࠦᵔ").format(e))
def bstack11l1l111l_opy_(bstack11ll11l1ll_opy_, name, logger):
  try:
    bstack1ll1111ll1_opy_ = {bstack1111_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᵕ"): name, bstack1111_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬᵖ"): bstack11ll11l1ll_opy_, bstack1111_opy_ (u"ࠧࡪࡰࡧࡩࡽ࠭ᵗ"): str(threading.current_thread()._name)}
    return bstack1ll1111ll1_opy_
  except Exception as e:
    logger.warn(bstack1111_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡸࡺ࡯ࡳࡧࠣࡦࡪ࡮ࡡࡷࡧࠣࡪࡺࡴ࡮ࡦ࡮ࠣࡨࡦࡺࡡ࠻ࠢࡾࢁࠧᵘ").format(e))
  return
def bstack111ll1ll11l_opy_():
    return platform.system() == bstack1111_opy_ (u"࡚ࠩ࡭ࡳࡪ࡯ࡸࡵࠪᵙ")
def bstack1lllllll1_opy_(bstack111lll1l11l_opy_, config, logger):
    bstack11l11l11l11_opy_ = {}
    try:
        return {key: config[key] for key in config if bstack111lll1l11l_opy_.match(key)}
    except Exception as e:
        logger.debug(bstack1111_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡦࡪ࡮ࡷࡩࡷࠦࡣࡰࡰࡩ࡭࡬ࠦ࡫ࡦࡻࡶࠤࡧࡿࠠࡳࡧࡪࡩࡽࠦ࡭ࡢࡶࡦ࡬࠿ࠦࡻࡾࠤᵚ").format(e))
    return bstack11l11l11l11_opy_
def bstack11l111l11l1_opy_(bstack11l11111lll_opy_, bstack11l111ll111_opy_):
    bstack11l1111llll_opy_ = version.parse(bstack11l11111lll_opy_)
    bstack11l11l11l1l_opy_ = version.parse(bstack11l111ll111_opy_)
    if bstack11l1111llll_opy_ > bstack11l11l11l1l_opy_:
        return 1
    elif bstack11l1111llll_opy_ < bstack11l11l11l1l_opy_:
        return -1
    else:
        return 0
def bstack1111ll1l1l_opy_():
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
def bstack11l11111ll1_opy_(timestamp):
    return datetime.datetime.fromtimestamp(timestamp, datetime.timezone.utc).replace(tzinfo=None)
def bstack111ll1l1lll_opy_(framework):
    from browserstack_sdk._version import __version__
    return str(framework) + str(__version__)
def bstack11111ll1l_opy_(options, framework, config, bstack1l11l1l1l_opy_={}):
    if options is None:
        return
    if getattr(options, bstack1111_opy_ (u"ࠫ࡬࡫ࡴࠨᵛ"), None):
        caps = options
    else:
        caps = options.to_capabilities()
    bstack11ll111ll_opy_ = caps.get(bstack1111_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭ᵜ"))
    bstack111ll11l11l_opy_ = True
    bstack1llllll111_opy_ = os.environ[bstack1111_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡋ࡙ࡇࡥࡕࡖࡋࡇࠫᵝ")]
    bstack1ll111llll1_opy_ = config.get(bstack1111_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧᵞ"), False)
    if bstack1ll111llll1_opy_:
        bstack1ll1l111l1l_opy_ = config.get(bstack1111_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡐࡲࡷ࡭ࡴࡴࡳࠨᵟ"), {})
        bstack1ll1l111l1l_opy_[bstack1111_opy_ (u"ࠩࡤࡹࡹ࡮ࡔࡰ࡭ࡨࡲࠬᵠ")] = os.getenv(bstack1111_opy_ (u"ࠪࡆࡘࡥࡁ࠲࠳࡜ࡣࡏ࡝ࡔࠨᵡ"))
        bstack11ll111l1l1_opy_ = json.loads(os.getenv(bstack1111_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡘࡊ࡙ࡔࡠࡃࡆࡇࡊ࡙ࡓࡊࡄࡌࡐࡎ࡚࡙ࡠࡅࡒࡒࡋࡏࡇࡖࡔࡄࡘࡎࡕࡎࡠ࡛ࡐࡐࠬᵢ"), bstack1111_opy_ (u"ࠬࢁࡽࠨᵣ"))).get(bstack1111_opy_ (u"࠭ࡳࡤࡣࡱࡲࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧᵤ"))
    if bstack111llll11l1_opy_(caps.get(bstack1111_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡵࡴࡧ࡚࠷ࡈ࠭ᵥ"))) or bstack111llll11l1_opy_(caps.get(bstack1111_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡶࡵࡨࡣࡼ࠹ࡣࠨᵦ"))):
        bstack111ll11l11l_opy_ = False
    if bstack1l1l11l111_opy_({bstack1111_opy_ (u"ࠤࡸࡷࡪ࡝࠳ࡄࠤᵧ"): bstack111ll11l11l_opy_}):
        bstack11ll111ll_opy_ = bstack11ll111ll_opy_ or {}
        bstack11ll111ll_opy_[bstack1111_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡕࡇࡏࠬᵨ")] = bstack111ll1l1lll_opy_(framework)
        bstack11ll111ll_opy_[bstack1111_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳ࠭ᵩ")] = bstack1l1l1ll11ll_opy_()
        bstack11ll111ll_opy_[bstack1111_opy_ (u"ࠬࡺࡥࡴࡶ࡫ࡹࡧࡈࡵࡪ࡮ࡧ࡙ࡺ࡯ࡤࠨᵪ")] = bstack1llllll111_opy_
        bstack11ll111ll_opy_[bstack1111_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡕࡸ࡯ࡥࡷࡦࡸࡒࡧࡰࠨᵫ")] = bstack1l11l1l1l_opy_
        if bstack1ll111llll1_opy_:
            bstack11ll111ll_opy_[bstack1111_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠧᵬ")] = bstack1ll111llll1_opy_
            bstack11ll111ll_opy_[bstack1111_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡐࡲࡷ࡭ࡴࡴࡳࠨᵭ")] = bstack1ll1l111l1l_opy_
            bstack11ll111ll_opy_[bstack1111_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࡑࡳࡸ࡮ࡵ࡮ࡴࠩᵮ")][bstack1111_opy_ (u"ࠪࡷࡨࡧ࡮࡯ࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫᵯ")] = bstack11ll111l1l1_opy_
        if getattr(options, bstack1111_opy_ (u"ࠫࡸ࡫ࡴࡠࡥࡤࡴࡦࡨࡩ࡭࡫ࡷࡽࠬᵰ"), None):
            options.set_capability(bstack1111_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭ᵱ"), bstack11ll111ll_opy_)
        else:
            options[bstack1111_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧᵲ")] = bstack11ll111ll_opy_
    else:
        if getattr(options, bstack1111_opy_ (u"ࠧࡴࡧࡷࡣࡨࡧࡰࡢࡤ࡬ࡰ࡮ࡺࡹࠨᵳ"), None):
            options.set_capability(bstack1111_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࡙ࡄࡌࠩᵴ"), bstack111ll1l1lll_opy_(framework))
            options.set_capability(bstack1111_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠪᵵ"), bstack1l1l1ll11ll_opy_())
            options.set_capability(bstack1111_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡷࡩࡸࡺࡨࡶࡤࡅࡹ࡮ࡲࡤࡖࡷ࡬ࡨࠬᵶ"), bstack1llllll111_opy_)
            options.set_capability(bstack1111_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡦࡺ࡯࡬ࡥࡒࡵࡳࡩࡻࡣࡵࡏࡤࡴࠬᵷ"), bstack1l11l1l1l_opy_)
            if bstack1ll111llll1_opy_:
                options.set_capability(bstack1111_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫᵸ"), bstack1ll111llll1_opy_)
                options.set_capability(bstack1111_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬᵹ"), bstack1ll1l111l1l_opy_)
                options.set_capability(bstack1111_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡕࡰࡵ࡫ࡲࡲࡸ࠴ࡳࡤࡣࡱࡲࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧᵺ"), bstack11ll111l1l1_opy_)
        else:
            options[bstack1111_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࡙ࡄࡌࠩᵻ")] = bstack111ll1l1lll_opy_(framework)
            options[bstack1111_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠪᵼ")] = bstack1l1l1ll11ll_opy_()
            options[bstack1111_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡷࡩࡸࡺࡨࡶࡤࡅࡹ࡮ࡲࡤࡖࡷ࡬ࡨࠬᵽ")] = bstack1llllll111_opy_
            options[bstack1111_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡦࡺ࡯࡬ࡥࡒࡵࡳࡩࡻࡣࡵࡏࡤࡴࠬᵾ")] = bstack1l11l1l1l_opy_
            if bstack1ll111llll1_opy_:
                options[bstack1111_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫᵿ")] = bstack1ll111llll1_opy_
                options[bstack1111_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬᶀ")] = bstack1ll1l111l1l_opy_
                options[bstack1111_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࡕࡰࡵ࡫ࡲࡲࡸ࠭ᶁ")][bstack1111_opy_ (u"ࠨࡵࡦࡥࡳࡴࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩᶂ")] = bstack11ll111l1l1_opy_
    return options
def bstack111lll11l1l_opy_(bstack11l1111lll1_opy_, framework):
    bstack1l11l1l1l_opy_ = bstack1l1l11ll11_opy_.get_property(bstack1111_opy_ (u"ࠤࡓࡐࡆ࡟ࡗࡓࡋࡊࡌ࡙ࡥࡐࡓࡑࡇ࡙ࡈ࡚࡟ࡎࡃࡓࠦᶃ"))
    if bstack11l1111lll1_opy_ and len(bstack11l1111lll1_opy_.split(bstack1111_opy_ (u"ࠪࡧࡦࡶࡳ࠾ࠩᶄ"))) > 1:
        ws_url = bstack11l1111lll1_opy_.split(bstack1111_opy_ (u"ࠫࡨࡧࡰࡴ࠿ࠪᶅ"))[0]
        if bstack1111_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡭ࠨᶆ") in ws_url:
            from browserstack_sdk._version import __version__
            bstack111llll111l_opy_ = json.loads(urllib.parse.unquote(bstack11l1111lll1_opy_.split(bstack1111_opy_ (u"࠭ࡣࡢࡲࡶࡁࠬᶇ"))[1]))
            bstack111llll111l_opy_ = bstack111llll111l_opy_ or {}
            bstack1llllll111_opy_ = os.environ[bstack1111_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡌ࡚ࡈ࡟ࡖࡗࡌࡈࠬᶈ")]
            bstack111llll111l_opy_[bstack1111_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࡙ࡄࡌࠩᶉ")] = str(framework) + str(__version__)
            bstack111llll111l_opy_[bstack1111_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠪᶊ")] = bstack1l1l1ll11ll_opy_()
            bstack111llll111l_opy_[bstack1111_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡷࡩࡸࡺࡨࡶࡤࡅࡹ࡮ࡲࡤࡖࡷ࡬ࡨࠬᶋ")] = bstack1llllll111_opy_
            bstack111llll111l_opy_[bstack1111_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡦࡺ࡯࡬ࡥࡒࡵࡳࡩࡻࡣࡵࡏࡤࡴࠬᶌ")] = bstack1l11l1l1l_opy_
            bstack11l1111lll1_opy_ = bstack11l1111lll1_opy_.split(bstack1111_opy_ (u"ࠬࡩࡡࡱࡵࡀࠫᶍ"))[0] + bstack1111_opy_ (u"࠭ࡣࡢࡲࡶࡁࠬᶎ") + urllib.parse.quote(json.dumps(bstack111llll111l_opy_))
    return bstack11l1111lll1_opy_
def bstack1ll1l1l1l1_opy_():
    global bstack1l11l11111_opy_
    from playwright._impl._browser_type import BrowserType
    bstack1l11l11111_opy_ = BrowserType.connect
    return bstack1l11l11111_opy_
def bstack11l11ll11l_opy_(framework_name):
    global bstack111ll1l1_opy_
    bstack111ll1l1_opy_ = framework_name
    return framework_name
def bstack1l1111l1ll_opy_(self, *args, **kwargs):
    global bstack1l11l11111_opy_
    try:
        global bstack111ll1l1_opy_
        if bstack1111_opy_ (u"ࠧࡸࡵࡈࡲࡩࡶ࡯ࡪࡰࡷࠫᶏ") in kwargs:
            kwargs[bstack1111_opy_ (u"ࠨࡹࡶࡉࡳࡪࡰࡰ࡫ࡱࡸࠬᶐ")] = bstack111lll11l1l_opy_(
                kwargs.get(bstack1111_opy_ (u"ࠩࡺࡷࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭ᶑ"), None),
                bstack111ll1l1_opy_
            )
    except Exception as e:
        logger.error(bstack1111_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡬ࡪࡴࠠࡱࡴࡲࡧࡪࡹࡳࡪࡰࡪࠤࡘࡊࡋࠡࡥࡤࡴࡸࡀࠠࡼࡿࠥᶒ").format(str(e)))
    return bstack1l11l11111_opy_(self, *args, **kwargs)
def bstack11l1111l111_opy_(bstack111ll1ll1l1_opy_, proxies):
    proxy_settings = {}
    try:
        if not proxies:
            proxies = bstack1l111ll1ll_opy_(bstack111ll1ll1l1_opy_, bstack1111_opy_ (u"ࠦࠧᶓ"))
        if proxies and proxies.get(bstack1111_opy_ (u"ࠧ࡮ࡴࡵࡲࡶࠦᶔ")):
            parsed_url = urlparse(proxies.get(bstack1111_opy_ (u"ࠨࡨࡵࡶࡳࡷࠧᶕ")))
            if parsed_url and parsed_url.hostname: proxy_settings[bstack1111_opy_ (u"ࠧࡱࡴࡲࡼࡾࡎ࡯ࡴࡶࠪᶖ")] = str(parsed_url.hostname)
            if parsed_url and parsed_url.port: proxy_settings[bstack1111_opy_ (u"ࠨࡲࡵࡳࡽࡿࡐࡰࡴࡷࠫᶗ")] = str(parsed_url.port)
            if parsed_url and parsed_url.username: proxy_settings[bstack1111_opy_ (u"ࠩࡳࡶࡴࡾࡹࡖࡵࡨࡶࠬᶘ")] = str(parsed_url.username)
            if parsed_url and parsed_url.password: proxy_settings[bstack1111_opy_ (u"ࠪࡴࡷࡵࡸࡺࡒࡤࡷࡸ࠭ᶙ")] = str(parsed_url.password)
        return proxy_settings
    except:
        return proxy_settings
def bstack1l11111l11_opy_(bstack111ll1ll1l1_opy_):
    bstack111ll1l11ll_opy_ = {
        bstack11l1l1l1l11_opy_[bstack111ll111lll_opy_]: bstack111ll1ll1l1_opy_[bstack111ll111lll_opy_]
        for bstack111ll111lll_opy_ in bstack111ll1ll1l1_opy_
        if bstack111ll111lll_opy_ in bstack11l1l1l1l11_opy_
    }
    bstack111ll1l11ll_opy_[bstack1111_opy_ (u"ࠦࡵࡸ࡯ࡹࡻࡖࡩࡹࡺࡩ࡯ࡩࡶࠦᶚ")] = bstack11l1111l111_opy_(bstack111ll1ll1l1_opy_, bstack1l1l11ll11_opy_.get_property(bstack1111_opy_ (u"ࠧࡶࡲࡰࡺࡼࡗࡪࡺࡴࡪࡰࡪࡷࠧᶛ")))
    bstack111lll111ll_opy_ = [element.lower() for element in bstack11l1l11ll1l_opy_]
    bstack11l111l1lll_opy_(bstack111ll1l11ll_opy_, bstack111lll111ll_opy_)
    return bstack111ll1l11ll_opy_
def bstack11l111l1lll_opy_(d, keys):
    for key in list(d.keys()):
        if key.lower() in keys:
            d[key] = bstack1111_opy_ (u"ࠨࠪࠫࠬ࠭ࠦᶜ")
    for value in d.values():
        if isinstance(value, dict):
            bstack11l111l1lll_opy_(value, keys)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    bstack11l111l1lll_opy_(item, keys)
def bstack1l1l1l11l1l_opy_():
    bstack111llll1111_opy_ = [os.environ.get(bstack1111_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡆࡊࡎࡈࡗࡤࡊࡉࡓࠤᶝ")), os.path.join(os.path.expanduser(bstack1111_opy_ (u"ࠣࢀࠥᶞ")), bstack1111_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩᶟ")), os.path.join(bstack1111_opy_ (u"ࠪ࠳ࡹࡳࡰࠨᶠ"), bstack1111_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫᶡ"))]
    for path in bstack111llll1111_opy_:
        if path is None:
            continue
        try:
            if os.path.exists(path):
                logger.debug(bstack1111_opy_ (u"ࠧࡌࡩ࡭ࡧࠣࠫࠧᶢ") + str(path) + bstack1111_opy_ (u"ࠨࠧࠡࡧࡻ࡭ࡸࡺࡳ࠯ࠤᶣ"))
                if not os.access(path, os.W_OK):
                    logger.debug(bstack1111_opy_ (u"ࠢࡈ࡫ࡹ࡭ࡳ࡭ࠠࡱࡧࡵࡱ࡮ࡹࡳࡪࡱࡱࡷࠥ࡬࡯ࡳࠢࠪࠦᶤ") + str(path) + bstack1111_opy_ (u"ࠣࠩࠥᶥ"))
                    os.chmod(path, 0o777)
                else:
                    logger.debug(bstack1111_opy_ (u"ࠤࡉ࡭ࡱ࡫ࠠࠨࠤᶦ") + str(path) + bstack1111_opy_ (u"ࠥࠫࠥࡧ࡬ࡳࡧࡤࡨࡾࠦࡨࡢࡵࠣࡸ࡭࡫ࠠࡳࡧࡴࡹ࡮ࡸࡥࡥࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹ࠮ࠣᶧ"))
            else:
                logger.debug(bstack1111_opy_ (u"ࠦࡈࡸࡥࡢࡶ࡬ࡲ࡬ࠦࡦࡪ࡮ࡨࠤࠬࠨᶨ") + str(path) + bstack1111_opy_ (u"ࠧ࠭ࠠࡸ࡫ࡷ࡬ࠥࡽࡲࡪࡶࡨࠤࡵ࡫ࡲ࡮࡫ࡶࡷ࡮ࡵ࡮࠯ࠤᶩ"))
                os.makedirs(path, exist_ok=True)
                os.chmod(path, 0o777)
            logger.debug(bstack1111_opy_ (u"ࠨࡏࡱࡧࡵࡥࡹ࡯࡯࡯ࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨࠥ࡬࡯ࡳࠢࠪࠦᶪ") + str(path) + bstack1111_opy_ (u"ࠢࠨ࠰ࠥᶫ"))
            return path
        except Exception as e:
            logger.debug(bstack1111_opy_ (u"ࠣࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡸ࡫ࡴࠡࡷࡳࠤ࡫࡯࡬ࡦࠢࠪࡿࡵࡧࡴࡩࡿࠪ࠾ࠥࠨᶬ") + str(e) + bstack1111_opy_ (u"ࠤࠥᶭ"))
    logger.debug(bstack1111_opy_ (u"ࠥࡅࡱࡲࠠࡱࡣࡷ࡬ࡸࠦࡦࡢ࡫࡯ࡩࡩ࠴ࠢᶮ"))
    return None
@measure(event_name=EVENTS.bstack11l1l11l1l1_opy_, stage=STAGE.bstack1l1l11111l_opy_)
def bstack1lll1l1lll1_opy_(binary_path, bstack1ll1lll1l1l_opy_, bs_config):
    logger.debug(bstack1111_opy_ (u"ࠦࡈࡻࡲࡳࡧࡱࡸࠥࡉࡌࡊࠢࡓࡥࡹ࡮ࠠࡧࡱࡸࡲࡩࡀࠠࡼࡿࠥᶯ").format(binary_path))
    bstack111lllll11l_opy_ = bstack1111_opy_ (u"ࠬ࠭ᶰ")
    bstack111ll1l111l_opy_ = {
        bstack1111_opy_ (u"࠭ࡳࡥ࡭ࡢࡺࡪࡸࡳࡪࡱࡱࠫᶱ"): __version__,
        bstack1111_opy_ (u"ࠢࡰࡵࠥᶲ"): platform.system(),
        bstack1111_opy_ (u"ࠣࡱࡶࡣࡦࡸࡣࡩࠤᶳ"): platform.machine(),
        bstack1111_opy_ (u"ࠤࡦࡰ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴࠢᶴ"): bstack1111_opy_ (u"ࠪ࠴ࠬᶵ"),
        bstack1111_opy_ (u"ࠦࡸࡪ࡫ࡠ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠥᶶ"): bstack1111_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬᶷ")
    }
    bstack11l111lll1l_opy_(bstack111ll1l111l_opy_)
    try:
        if binary_path:
            if bstack111ll1ll11l_opy_():
                bstack111ll1l111l_opy_[bstack1111_opy_ (u"࠭ࡣ࡭࡫ࡢࡺࡪࡸࡳࡪࡱࡱࠫᶸ")] = subprocess.check_output([binary_path, bstack1111_opy_ (u"ࠢࡷࡧࡵࡷ࡮ࡵ࡮ࠣᶹ")]).strip().decode(bstack1111_opy_ (u"ࠨࡷࡷࡪ࠲࠾ࠧᶺ"))
            else:
                bstack111ll1l111l_opy_[bstack1111_opy_ (u"ࠩࡦࡰ࡮ࡥࡶࡦࡴࡶ࡭ࡴࡴࠧᶻ")] = subprocess.check_output([binary_path, bstack1111_opy_ (u"ࠥࡺࡪࡸࡳࡪࡱࡱࠦᶼ")], stderr=subprocess.DEVNULL).strip().decode(bstack1111_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪᶽ"))
        response = requests.request(
            bstack1111_opy_ (u"ࠬࡍࡅࡕࠩᶾ"),
            url=bstack1l11111ll1_opy_(bstack11l1l111l1l_opy_),
            headers=None,
            auth=(bs_config[bstack1111_opy_ (u"࠭ࡵࡴࡧࡵࡒࡦࡳࡥࠨᶿ")], bs_config[bstack1111_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪ᷀")]),
            json=None,
            params=bstack111ll1l111l_opy_
        )
        data = response.json()
        if response.status_code == 200 and bstack1111_opy_ (u"ࠨࡷࡵࡰࠬ᷁") in data.keys() and bstack1111_opy_ (u"ࠩࡸࡴࡩࡧࡴࡦࡦࡢࡧࡱ࡯࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ᷂") in data.keys():
            logger.debug(bstack1111_opy_ (u"ࠥࡒࡪ࡫ࡤࠡࡶࡲࠤࡺࡶࡤࡢࡶࡨࠤࡧ࡯࡮ࡢࡴࡼ࠰ࠥࡩࡵࡳࡴࡨࡲࡹࠦࡢࡪࡰࡤࡶࡾࠦࡶࡦࡴࡶ࡭ࡴࡴ࠺ࠡࡽࢀࠦ᷃").format(bstack111ll1l111l_opy_[bstack1111_opy_ (u"ࠫࡨࡲࡩࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ᷄")]))
            if bstack1111_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡇࡏࡎࡂࡔ࡜ࡣ࡚ࡘࡌࠨ᷅") in os.environ:
                logger.debug(bstack1111_opy_ (u"ࠨࡓ࡬࡫ࡳࡴ࡮ࡴࡧࠡࡤ࡬ࡲࡦࡸࡹࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡥࡸࠦࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡈࡉࡏࡃࡕ࡝ࡤ࡛ࡒࡍࠢ࡬ࡷࠥࡹࡥࡵࠤ᷆"))
                data[bstack1111_opy_ (u"ࠧࡶࡴ࡯ࠫ᷇")] = os.environ[bstack1111_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡃࡋࡑࡅࡗ࡟࡟ࡖࡔࡏࠫ᷈")]
            bstack11l111ll1l1_opy_ = bstack111l1lllll1_opy_(data[bstack1111_opy_ (u"ࠩࡸࡶࡱ࠭᷉")], bstack1ll1lll1l1l_opy_)
            bstack111lllll11l_opy_ = os.path.join(bstack1ll1lll1l1l_opy_, bstack11l111ll1l1_opy_)
            os.chmod(bstack111lllll11l_opy_, 0o777) # bstack111llll1ll1_opy_ permission
            return bstack111lllll11l_opy_
    except Exception as e:
        logger.debug(bstack1111_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡬࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࠦ࡮ࡦࡹࠣࡗࡉࡑࠠࡼࡿ᷊ࠥ").format(e))
    return binary_path
def bstack11l111lll1l_opy_(bstack111ll1l111l_opy_):
    try:
        if bstack1111_opy_ (u"ࠫࡱ࡯࡮ࡶࡺࠪ᷋") not in bstack111ll1l111l_opy_[bstack1111_opy_ (u"ࠬࡵࡳࠨ᷌")].lower():
            return
        if os.path.exists(bstack1111_opy_ (u"ࠨ࠯ࡦࡶࡦ࠳ࡴࡹ࠭ࡳࡧ࡯ࡩࡦࡹࡥࠣ᷍")):
            with open(bstack1111_opy_ (u"ࠢ࠰ࡧࡷࡧ࠴ࡵࡳ࠮ࡴࡨࡰࡪࡧࡳࡦࠤ᷎"), bstack1111_opy_ (u"ࠣࡴ᷏ࠥ")) as f:
                bstack11l111ll11l_opy_ = {}
                for line in f:
                    if bstack1111_opy_ (u"ࠤࡀ᷐ࠦ") in line:
                        key, value = line.rstrip().split(bstack1111_opy_ (u"ࠥࡁࠧ᷑"), 1)
                        bstack11l111ll11l_opy_[key] = value.strip(bstack1111_opy_ (u"ࠫࠧࡢࠧࠨ᷒"))
                bstack111ll1l111l_opy_[bstack1111_opy_ (u"ࠬࡪࡩࡴࡶࡵࡳࠬᷓ")] = bstack11l111ll11l_opy_.get(bstack1111_opy_ (u"ࠨࡉࡅࠤᷔ"), bstack1111_opy_ (u"ࠢࠣᷕ"))
        elif os.path.exists(bstack1111_opy_ (u"ࠣ࠱ࡨࡸࡨ࠵ࡡ࡭ࡲ࡬ࡲࡪ࠳ࡲࡦ࡮ࡨࡥࡸ࡫ࠢᷖ")):
            bstack111ll1l111l_opy_[bstack1111_opy_ (u"ࠩࡧ࡭ࡸࡺࡲࡰࠩᷗ")] = bstack1111_opy_ (u"ࠪࡥࡱࡶࡩ࡯ࡧࠪᷘ")
    except Exception as e:
        logger.debug(bstack1111_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡨࡧࡷࠤࡩ࡯ࡳࡵࡴࡲࠤࡴ࡬ࠠ࡭࡫ࡱࡹࡽࠨᷙ") + e)
@measure(event_name=EVENTS.bstack11l1l1lll1l_opy_, stage=STAGE.bstack1l1l11111l_opy_)
def bstack111l1lllll1_opy_(bstack111ll11ll1l_opy_, bstack111lllll1l1_opy_):
    logger.debug(bstack1111_opy_ (u"ࠧࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩࠣࡗࡉࡑࠠࡣ࡫ࡱࡥࡷࡿࠠࡧࡴࡲࡱ࠿ࠦࠢᷚ") + str(bstack111ll11ll1l_opy_) + bstack1111_opy_ (u"ࠨࠢᷛ"))
    zip_path = os.path.join(bstack111lllll1l1_opy_, bstack1111_opy_ (u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡧࡧࡣ࡫࡯࡬ࡦ࠰ࡽ࡭ࡵࠨᷜ"))
    bstack11l111ll1l1_opy_ = bstack1111_opy_ (u"ࠨࠩᷝ")
    with requests.get(bstack111ll11ll1l_opy_, stream=True) as response:
        response.raise_for_status()
        with open(zip_path, bstack1111_opy_ (u"ࠤࡺࡦࠧᷞ")) as file:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    file.write(chunk)
        logger.debug(bstack1111_opy_ (u"ࠥࡊ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼ࠲ࠧᷟ"))
    with zipfile.ZipFile(zip_path, bstack1111_opy_ (u"ࠫࡷ࠭ᷠ")) as zip_ref:
        bstack11l11l1l11l_opy_ = zip_ref.namelist()
        if len(bstack11l11l1l11l_opy_) > 0:
            bstack11l111ll1l1_opy_ = bstack11l11l1l11l_opy_[0] # bstack111ll1lllll_opy_ bstack11l1ll11111_opy_ will be bstack111llllllll_opy_ 1 file i.e. the binary in the zip
        zip_ref.extractall(bstack111lllll1l1_opy_)
        logger.debug(bstack1111_opy_ (u"ࠧࡌࡩ࡭ࡧࡶࠤࡸࡻࡣࡤࡧࡶࡷ࡫ࡻ࡬࡭ࡻࠣࡩࡽࡺࡲࡢࡥࡷࡩࡩࠦࡴࡰࠢࠪࠦᷡ") + str(bstack111lllll1l1_opy_) + bstack1111_opy_ (u"ࠨࠧࠣᷢ"))
    os.remove(zip_path)
    return bstack11l111ll1l1_opy_
def get_cli_dir():
    bstack111llll1lll_opy_ = bstack1l1l1l11l1l_opy_()
    if bstack111llll1lll_opy_:
        bstack1ll1lll1l1l_opy_ = os.path.join(bstack111llll1lll_opy_, bstack1111_opy_ (u"ࠢࡤ࡮࡬ࠦᷣ"))
        if not os.path.exists(bstack1ll1lll1l1l_opy_):
            os.makedirs(bstack1ll1lll1l1l_opy_, mode=0o777, exist_ok=True)
        return bstack1ll1lll1l1l_opy_
    else:
        raise FileNotFoundError(bstack1111_opy_ (u"ࠣࡐࡲࠤࡼࡸࡩࡵࡣࡥࡰࡪࠦࡤࡪࡴࡨࡧࡹࡵࡲࡺࠢࡤࡺࡦ࡯࡬ࡢࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡓࡅࡍࠣࡦ࡮ࡴࡡࡳࡻ࠱ࠦᷤ"))
def bstack1lll11l11l1_opy_(bstack1ll1lll1l1l_opy_):
    bstack1111_opy_ (u"ࠤࠥࠦࡌ࡫ࡴࠡࡶ࡫ࡩࠥࡶࡡࡵࡪࠣࡪࡴࡸࠠࡵࡪࡨࠤࡇࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࠣࡗࡉࡑࠠࡣ࡫ࡱࡥࡷࡿࠠࡪࡰࠣࡥࠥࡽࡲࡪࡶࡤࡦࡱ࡫ࠠࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻ࠱ࠦࠧࠨᷥ")
    bstack11l1111ll11_opy_ = [
        os.path.join(bstack1ll1lll1l1l_opy_, f)
        for f in os.listdir(bstack1ll1lll1l1l_opy_)
        if os.path.isfile(os.path.join(bstack1ll1lll1l1l_opy_, f)) and f.startswith(bstack1111_opy_ (u"ࠥࡦ࡮ࡴࡡࡳࡻ࠰ࠦᷦ"))
    ]
    if len(bstack11l1111ll11_opy_) > 0:
        return max(bstack11l1111ll11_opy_, key=os.path.getmtime) # get bstack111llll11ll_opy_ binary
    return bstack1111_opy_ (u"ࠦࠧᷧ")
def bstack11ll1l111ll_opy_():
  from selenium import webdriver
  return version.parse(webdriver.__version__)
def bstack1ll1111l1l1_opy_(d, u):
  for k, v in u.items():
    if isinstance(v, collections.abc.Mapping):
      d[k] = bstack1ll1111l1l1_opy_(d.get(k, {}), v)
    else:
      if isinstance(v, list):
        d[k] = d.get(k, []) + v
      else:
        d[k] = v
  return d
def bstack1ll1l11l_opy_(data, keys, default=None):
    bstack1111_opy_ (u"ࠧࠨࠢࠋࠢࠣࠤ࡙ࠥࡡࡧࡧ࡯ࡽࠥ࡭ࡥࡵࠢࡤࠤࡳ࡫ࡳࡵࡧࡧࠤࡻࡧ࡬ࡶࡧࠣࡪࡷࡵ࡭ࠡࡣࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡰࡴࠣࡰ࡮ࡹࡴ࠯ࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡤࡢࡶࡤ࠾࡚ࠥࡨࡦࠢࡧ࡭ࡨࡺࡩࡰࡰࡤࡶࡾࠦ࡯ࡳࠢ࡯࡭ࡸࡺࠠࡵࡱࠣࡸࡷࡧࡶࡦࡴࡶࡩ࠳ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣ࡯ࡪࡿࡳ࠻ࠢࡄࠤࡱ࡯ࡳࡵࠢࡲࡪࠥࡱࡥࡺࡵ࠲࡭ࡳࡪࡩࡤࡧࡶࠤࡷ࡫ࡰࡳࡧࡶࡩࡳࡺࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡱࡣࡷ࡬࠳ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡨࡪ࡬ࡡࡶ࡮ࡷ࠾ࠥ࡜ࡡ࡭ࡷࡨࠤࡹࡵࠠࡳࡧࡷࡹࡷࡴࠠࡪࡨࠣࡸ࡭࡫ࠠࡱࡣࡷ࡬ࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡦࡺ࡬ࡷࡹ࠴ࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠦࡔࡩࡧࠣࡺࡦࡲࡵࡦࠢࡤࡸࠥࡺࡨࡦࠢࡱࡩࡸࡺࡥࡥࠢࡳࡥࡹ࡮ࠬࠡࡱࡵࠤࡩ࡫ࡦࡢࡷ࡯ࡸࠥ࡯ࡦࠡࡰࡲࡸࠥ࡬࡯ࡶࡰࡧ࠲ࠏࠦࠠࠡࠢࠥࠦࠧᷨ")
    if not data:
        return default
    current = data
    try:
        for key in keys:
            if isinstance(current, dict):
                current = current[key]
            elif isinstance(current, list) and isinstance(key, int):
                current = current[key]
            else:
                return default
        return current
    except (KeyError, IndexError, TypeError):
        return default