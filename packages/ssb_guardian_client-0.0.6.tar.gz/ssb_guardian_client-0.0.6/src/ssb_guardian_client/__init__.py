"""SSB Guardian Client."""
