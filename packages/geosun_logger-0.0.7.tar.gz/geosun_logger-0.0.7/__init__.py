"""geosun-logger"""
__version__ = "0.0.7"

from .geosun_logger import CustomFormatter, AutoLogger
from .geosun_logger import CustomFormatter, AutoLogger
from .geosun_logger import CustomFormatter, AutoLogger
from .geosun_logger import CustomFormatter, AutoLogger
from .geosun_logger import CustomFormatter, AutoLogger
from .geosun_logger import CustomFormatter, AutoLogger

__all__ = ["CustomFormatter", "AutoLogger", "CustomFormatter", "AutoLogger", "CustomFormatter", "AutoLogger", "CustomFormatter", "AutoLogger", "CustomFormatter", "AutoLogger", "CustomFormatter", "AutoLogger"]