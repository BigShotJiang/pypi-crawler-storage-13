from buptmw import BUPT_Auth

auth = {
    "username": "2023213685",
    "password": "zero-bupt-A1"
}

user = BUPT_Auth(cas=auth)
ucloud = user.get_Ucloud()

resp = ucloud.get(
    "https://apiucloud.bupt.edu.cn/ykt-site/site/list/student/current",
    headers={
        "Authorization": ucloud.authorization,
        "Blade-Auth": ucloud.access_token,
        "Identity": ucloud.identity
    },
    params={
        "size": 999999,
        "current": 1,
        "userId": ucloud.user_id,
        "siteRoleCode": 2
    }
)
data = resp.json()["data"]["records"]
print(data)
