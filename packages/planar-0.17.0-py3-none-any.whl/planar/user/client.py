import os

import httpx

from planar.user.models import DirectoryGroup, DirectoryUser


async def query_groups() -> list[DirectoryGroup]:
    async with httpx.AsyncClient(base_url=os.environ["COPLANE_API_URL"]) as client:
        response = await client.get(
            "/v1/dir_sync/groups/",
            headers={"Authorization": f"Bearer {os.environ['COPLANE_API_TOKEN']}"},
        )
        response = response.raise_for_status()
        return [DirectoryGroup.model_validate(i) for i in response.json()]


async def query_users() -> list[DirectoryUser]:
    async with httpx.AsyncClient(base_url=os.environ["COPLANE_API_URL"]) as client:
        response = await client.get(
            "/v1/dir_sync/users/",
            headers={"Authorization": f"Bearer {os.environ['COPLANE_API_TOKEN']}"},
        )
        response = response.raise_for_status()
        return [DirectoryUser.model_validate(i) for i in response.json()]
