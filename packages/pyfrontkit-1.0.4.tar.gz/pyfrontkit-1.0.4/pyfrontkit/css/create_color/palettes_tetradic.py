# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.


# palettes_tetradic.py



# Paleta de colores tetrádicos
palette_tetradic = {
    # REDS
    "red_pure":    {"principal": "#FF0000", "secondary": "#00FF00", "tertiary": "#0000FF", "quaternary": "#FFFF00"},
    "red_dark":    {"principal": "#990000", "secondary": "#009900", "tertiary": "#000099", "quaternary": "#999900"},
    "red_pink":    {"principal": "#FF66CC", "secondary": "#66FF99", "tertiary": "#9966FF", "quaternary": "#FFCC66"},
    "coral":       {"principal": "#FF7F50", "secondary": "#50FF7F", "tertiary": "#7F50FF", "quaternary": "#FFFF50"},
    "tomato":      {"principal": "#FF6347", "secondary": "#47FF63", "tertiary": "#6347FF", "quaternary": "#FFFF63"},

    # BLUES
    "blue_pure":   {"principal": "#0000FF", "secondary": "#FF0000", "tertiary": "#00FF00", "quaternary": "#FFFF00"},
    "blue_medium": {"principal": "#0000CC", "secondary": "#CC0000", "tertiary": "#00CC00", "quaternary": "#CCCC00"},
    "aqua":        {"principal": "#00FFFF", "secondary": "#FF00FF", "tertiary": "#FFFF00", "quaternary": "#00FF00"},
    "cyan":        {"principal": "#00CED1", "secondary": "#D100CD", "tertiary": "#CDCD00", "quaternary": "#00D1CD"},
    "sky_blue":    {"principal": "#87CEEB", "secondary": "#EB87CE", "tertiary": "#CEEB87", "quaternary": "#EBCF87"},

    # GREENS
    "green_pure":  {"principal": "#00FF00", "secondary": "#0000FF", "tertiary": "#FF0000", "quaternary": "#FFFF00"},
    "green_light": {"principal": "#90EE90", "secondary": "#9090EE", "tertiary": "#EE9090", "quaternary": "#EEEE90"},
    "green_dark":  {"principal": "#006400", "secondary": "#000064", "tertiary": "#640000", "quaternary": "#646400"},
    "lime":        {"principal": "#32CD32", "secondary": "#3131CD", "tertiary": "#CD3131", "quaternary": "#CDCD31"},
    "sea_green":   {"principal": "#2E8B57", "secondary": "#562E8A", "tertiary": "#8A572E", "quaternary": "#8A8A2E"},

    # YELLOWS
    "yellow":      {"principal": "#FFFF00", "secondary": "#FF0000", "tertiary": "#00FF00", "quaternary": "#0000FF"},
    "golden":      {"principal": "#FFD700", "secondary": "#00FFD7", "tertiary": "#D600FF", "quaternary": "#FF6D00"},
    "light_yellow":{"principal": "#FFFFE0", "secondary": "#E0FFFF", "tertiary": "#FEE0FF", "quaternary": "#FFE0FE"},
    "lemon":       {"principal": "#FFF44F", "secondary": "#4FFEF4", "tertiary": "#F34FFE", "quaternary": "#F4FF4F"},

    # ORANGES
    "orange":      {"principal": "#FFA500", "secondary": "#00FFA5", "tertiary": "#A400FF", "quaternary": "#FF00A4"},
    "dark_orange": {"principal": "#FF8C00", "secondary": "#00FF8C", "tertiary": "#8B00FF", "quaternary": "#FF008B"},
    "peach":       {"principal": "#FFE5B4", "secondary": "#B4FFE5", "tertiary": "#E4B4FF", "quaternary": "#FFB4E4"},
    "tangerine":   {"principal": "#F28500", "secondary": "#00F285", "tertiary": "#8400F2", "quaternary": "#F20084"},

    # VIOLETS
    "violet":      {"principal": "#8A2BE2", "secondary": "#E2892B", "tertiary": "#2BE289", "quaternary": "#89E22B"},
    "lilac":       {"principal": "#C8A2C8", "secondary": "#C7C8A1", "tertiary": "#A1C7C8", "quaternary": "#A2C8A1"},
    "purple":      {"principal": "#800080", "secondary": "#7F8000", "tertiary": "#007F80", "quaternary": "#808000"},
    "orchid":      {"principal": "#DA70D6", "secondary": "#D6DA6F", "tertiary": "#6FD6DA", "quaternary": "#DA6FDA"},

    # NEUTRALS
    "white":       {"principal": "#FFFFFF", "secondary": "#FFFFFF", "tertiary": "#FFFFFF", "quaternary": "#FFFFFF"},
    "black":       {"principal": "#000000", "secondary": "#000000", "tertiary": "#000000", "quaternary": "#000000"},
    "light_gray":  {"principal": "#D3D3D3", "secondary": "#D3D3D3", "tertiary": "#D3D3D3", "quaternary": "#D3D3D3"},
    "dark_gray":   {"principal": "#A9A9A9", "secondary": "#A9A9A9", "tertiary": "#A9A9A9", "quaternary": "#A9A9A9"},
    "beige":       {"principal": "#F5F5DC", "secondary": "#F5F5DC", "tertiary": "#F5F5DC", "quaternary": "#F5F5DC"},
    "silver":      {"principal": "#C0C0C0", "secondary": "#C0C0C0", "tertiary": "#C0C0C0", "quaternary": "#C0C0C0"},
}
tetradic_color_rule = {
    "body": {
        "bg": palette_tetradic["white"]["principal"],
        "text": palette_tetradic["black"]["principal"],
        "children": {
            "header": {
                "bg": palette_tetradic["red_pure"]["principal"],
                "text": palette_tetradic["yellow"]["secondary"],
                "children": {
                    "h1": {"text": palette_tetradic["blue_pure"]["tertiary"]},
                    "nav": {"bg": palette_tetradic["yellow"]["quaternary"],
                            "text": palette_tetradic["green_pure"]["secondary"]},
                },
            },
            "main": {
                "bg": palette_tetradic["white"]["principal"],
                "text": palette_tetradic["black"]["principal"],
                "children": {
                    "section": {
                        "bg": palette_tetradic["blue_pure"]["secondary"],
                        "text": palette_tetradic["red_pure"]["tertiary"],
                        "children": {
                            "p": {"text": palette_tetradic["green_pure"]["principal"]},
                            "a": {"text": palette_tetradic["yellow"]["quaternary"]},
                            "div": {"bg": palette_tetradic["red_dark"]["secondary"],
                                    "text": palette_tetradic["blue_pure"]["principal"]},
                        },
                    },
                    "article": {
                        "bg": palette_tetradic["green_light"]["tertiary"],
                        "text": palette_tetradic["blue_medium"]["secondary"],
                        "children": {
                            "h2": {"text": palette_tetradic["red_pink"]["principal"]},
                            "p": {"text": palette_tetradic["violet"]["tertiary"]},
                        },
                    },
                },
            },
            "footer": {
                "bg": palette_tetradic["dark_gray"]["principal"],
                "text": palette_tetradic["white"]["principal"],
                "children": {
                    "p": {"text": palette_tetradic["white"]["principal"]},
                    "a": {"text": palette_tetradic["light_gray"]["principal"]},
                },
            },
        },
    }
}

# Función de utilidad para obtener color de un tag según la regla
def get_color_for_tag(tag_path: list, rule=None):
    """
    Devuelve un dict {'bg': color, 'text': color} para cualquier tag_path.
    - tag_path: lista de tags desde 'body' hasta el tag objetivo, ej: ['body', 'main', 'section', 'p']
    - rule: regla a usar, por defecto usa tetradic_color_rule
    """
    from copy import deepcopy
    if rule is None:
        rule = deepcopy(tetradic_color_rule)

    current = rule
    bg, text = None, None

    for tag in tag_path:
        # Primero buscamos el tag exacto
        if "children" in current and tag in current["children"]:
            current = current["children"][tag]
        # Si no existe, usamos el comodín "*"
        elif "children" in current and "*" in current["children"]:
            current = current["children"]["*"]
        # Si no hay hijos, rompemos
        else:
            break

        # Actualizamos bg/text si están definidos
        bg = current.get("bg", bg)
        text = current.get("text", text)

    # Fallback si no se definió nunca
    bg = bg or palette_tetradic["white"]["principal"]
    text = text or palette_tetradic["black"]["principal"]

    return {"bg": bg, "text": text}
