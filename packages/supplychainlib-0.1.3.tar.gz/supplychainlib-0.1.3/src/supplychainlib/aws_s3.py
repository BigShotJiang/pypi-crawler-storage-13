import boto3
import os
from botocore.exceptions import ClientError


class S3Manager:
    """
    Basic AWS S3 operations: upload, download, list, delete
    """

    def __init__(self, bucket_name, region_name="us-east-1"):
        # Validate bucket name
        if not bucket_name or not isinstance(bucket_name, str):
            raise ValueError("A valid S3 bucket name must be provided as string.")

        self.bucket_name = bucket_name
        self.region_name = region_name
        self.s3_client = boto3.client("s3", region_name=self.region_name)
        
        # Create bucket if it doesn't exist
        self._ensure_bucket_exists()

    def _ensure_bucket_exists(self):
        """
        Check if bucket exists, create if not
        """
        try:
            response = self.s3_client.list_buckets()
            bucket_names = [b['Name'] for b in response.get('Buckets', [])]

            if self.bucket_name not in bucket_names:
                print(f"Bucket '{self.bucket_name}' does not exist. Creating it now...")
                if self.region_name == "us-east-1":
                    self.s3_client.create_bucket(Bucket=self.bucket_name)
                else:
                    self.s3_client.create_bucket(
                        Bucket=self.bucket_name,
                        CreateBucketConfiguration={'LocationConstraint': self.region_name}
                    )
                print(f"Bucket '{self.bucket_name}' created successfully.")
        except ClientError as e:
            print(f"Error checking or creating bucket: {e}")
            raise

    def upload_file(self, file_path, object_name=None):
        """
        Upload a file from local path to S3
        """
        object_name = object_name or os.path.basename(file_path)
        try:
            self.s3_client.upload_file(file_path, self.bucket_name, object_name)
            print(f"Uploaded file to {self.bucket_name}/{object_name}")
        except ClientError as e:
            print(f"Upload failed: {e}")
            raise

    def upload_fileobj(self, file_obj, object_name):
        """
        Upload a file-like object to S3
        """
        try:
            self.s3_client.upload_fileobj(file_obj, self.bucket_name, object_name)
            print(f"Uploaded file object to {self.bucket_name}/{object_name}")
        except ClientError as e:
            print(f"Upload failed: {e}")
            raise

    def download_file(self, object_name, download_path):
        """
        Download a file from S3 to local path
        """
        try:
            self.s3_client.download_file(self.bucket_name, object_name, download_path)
            print(f"Downloaded file from {self.bucket_name}/{object_name}")
        except ClientError as e:
            print(f"Download failed: {e}")
            raise

    def list_objects(self, prefix=""):
        """
        List all objects in the bucket with optional prefix
        """
        try:
            response = self.s3_client.list_objects_v2(Bucket=self.bucket_name, Prefix=prefix)
            items = response.get('Contents', [])
            return [item['Key'] for item in items]
        except Exception as e:
            print(f"Error listing objects: {e}")
            return []

    def delete_file(self, file_key):
        """
        Delete an object from S3
        """
        try:
            self.s3_client.delete_object(Bucket=self.bucket_name, Key=file_key)
            print(f"Deleted file {file_key} from bucket {self.bucket_name}")
        except ClientError as e:
            print(f"Delete failed: {e}")
            raise


class S3BucketManager:
    """
    Specialized manager for invoice bucket operations
    """
    
    def __init__(self, bucket_name='gourmet-coffee-invoices', region='us-east-1'):
        self.bucket_name = bucket_name
        self.region = region
        self.s3_client = boto3.client('s3', region_name=region)
    
    def create_bucket(self):
        """
        Create S3 bucket if it doesn't exist
        """
        try:
            self.s3_client.head_bucket(Bucket=self.bucket_name)
            print(f"Bucket {self.bucket_name} already exists")
            return True
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == '404':
                try:
                    self.s3_client.create_bucket(Bucket=self.bucket_name)
                    print(f"Bucket {self.bucket_name} created successfully")
                    return True
                except ClientError as create_error:
                    print(f"Error creating bucket: {create_error}")
                    return False
            else:
                print(f"Error checking bucket: {e}")
                return False
    
    def list_invoices(self):
        """
        List all invoices in S3 bucket
        """
        try:
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix='invoices/'
            )
            
            invoices = []
            if 'Contents' in response:
                for obj in response['Contents']:
                    invoice_key = obj['Key']
                    order_id = invoice_key.split('/')[-1].replace('.pdf', '')
                    
                    invoices.append({
                        'order_id': order_id,
                        'key': invoice_key,
                        'size': obj['Size'],
                        'last_modified': obj['LastModified']
                    })
            
            return invoices
            
        except ClientError as e:
            print(f"Error listing invoices: {e}")
            return []
    
    def generate_download_url(self, invoice_key, expiration=3600):
        """
        Generate presigned URL for invoice download
        """
        try:
            url = self.s3_client.generate_presigned_url(
                'get_object',
                Params={
                    'Bucket': self.bucket_name,
                    'Key': invoice_key
                },
                ExpiresIn=expiration
            )
            return url
        except ClientError as e:
            print(f"Error generating download URL: {e}")
            return None
    
    def upload_file(self, file_path, object_key):
        """
        Upload a file to S3 bucket
        """
        try:
            self.s3_client.upload_file(file_path, self.bucket_name, object_key)
            print(f"File uploaded to {self.bucket_name}/{object_key}")
            return True
        except ClientError as e:
            print(f"Error uploading file: {e}")
            return False

    def delete_invoice(self, key):
        try:
            self.s3_client.delete_object(Bucket=self.bucket_name, Key=key)
            return True
        except Exception as e:
            print(f"Error deleting {key}: {e}")
            return False

    
    
    
class S3InvoiceManager:
    """
    Manages invoice storage and retrieval from S3
    (Simplified version for backward compatibility)
    """
    
    def __init__(self, bucket_name='gourmet-coffee-invoices'):
        self.s3_client = boto3.client('s3')
        self.bucket_name = bucket_name
    
    def list_invoices(self):
        """
        List all invoices in S3 bucket
        """
        try:
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix='invoices/'
            )
            
            invoices = []
            if 'Contents' in response:
                for obj in response['Contents']:
                    invoice_key = obj['Key']
                    order_id = invoice_key.split('/')[-1].replace('.pdf', '')
                    
                    invoices.append({
                        'order_id': order_id,
                        'key': invoice_key,
                        'size': obj['Size'],
                        'last_modified': obj['LastModified']
                    })
            
            return invoices
            
        except ClientError as e:
            print(f"Error listing invoices: {e}")
            return []
    
    def generate_download_url(self, invoice_key, expiration=3600):
        """
        Generate presigned URL for invoice download
        """
        try:
            url = self.s3_client.generate_presigned_url(
                'get_object',
                Params={
                    'Bucket': self.bucket_name,
                    'Key': invoice_key
                },
                ExpiresIn=expiration
            )
            return url
        except ClientError as e:
            print(f"Error generating presigned URL: {e}")
            return None
