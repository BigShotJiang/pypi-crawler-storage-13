
from setuptools import setup, find_packages

setup(
    name="PyOUNTM",
    version="1.2.3",
    packages=find_packages(),
    description="Pip creator PY",
    python_requires='>=3.7',
)
