
class Pip:
    def create(self):
        print("pip objesi oluşturuldu")
        return self

    def dex(self, desc):
        print("Açıklama eklendi:", desc)

    def cls(self, *args):
        print("Ekler eklendi:", args)

    def vrs(self, ver):
        print("Sürüm ayarlandı:", ver)

    def start_create(self):
        import getpass
        token = getpass.getpass("PyPI API Token giriniz: ")
        print(f"Paket oluşturuldu ve PyPI'ye yüklendi! (Token: {token})")

pip = Pip()
