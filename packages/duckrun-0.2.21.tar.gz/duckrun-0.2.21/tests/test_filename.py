import os
from urllib.parse import urlparse

url = 'https://github.com/djouallah/Fabric_Notebooks_Demo/raw/refs/heads/main/googleanalytics/report.pbix'
parsed = urlparse(url)
filename = os.path.basename(parsed.path)
print(f'Filename: {filename}')

report_name = filename[:-5] if filename.lower().endswith('.pbix') else filename
print(f'Report name: {report_name}')
