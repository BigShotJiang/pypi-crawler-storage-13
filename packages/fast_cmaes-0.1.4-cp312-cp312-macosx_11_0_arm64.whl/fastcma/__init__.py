from .fastcma import *

__doc__ = fastcma.__doc__
if hasattr(fastcma, "__all__"):
    __all__ = fastcma.__all__