from setuptools import find_packages, setup

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="d1-client",
    version="0.1.0",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=["httpx", "pydantic"],
    author="Haozhe Li",
    author_email="mail@haozheli.com",
    description="A Python sync/async client for Cloudflare D1 database",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Haozhe-Li/D1-Client",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
