# d1-client

`d1-client` is a naive synchronous and asynchronous Python client for the Cloudflare D1 database API.

## Installation

```bash
pip install d1-client
```

## Usage

Synchronous client:

```python
from d1_client import D1Client

client = D1Client(account_id="your_account_id", api_token="your_api_token")
resp = client.list_db()
print(resp.success, resp.result)
client.close()
```

Asynchronous client:

```python
import asyncio
from d1_client import AsyncD1Client


async def main() -> None:
	client = AsyncD1Client(account_id="your_account_id", api_token="your_api_token")
	resp = await client.list_db()
	print(resp.success, resp.result)
	await client.aclose()


asyncio.run(main())
```
