from __future__ import annotations

from typing import Any, List, Optional

from pydantic import BaseModel


class D1Error(BaseModel):
    code: Optional[int] = None
    message: str


class D1Database(BaseModel):
    id: str
    name: str


class D1Response(BaseModel):
    success: bool
    result: Any | None = None
    errors: List[D1Error] = []


class D1QueryResult(BaseModel):
    # Cloudflare D1 query response structure can vary; keep it flexible
    success: bool
    results: Any | None = None
    meta: dict | None = None
    errors: List[D1Error] = []
