from __future__ import annotations

from typing import Any, List, Optional

from ._http import AsyncHttpClient
from .models import D1QueryResult, D1Response


class AsyncD1Client:
    """Asynchronous Cloudflare D1 client wrapper using httpx.AsyncClient."""

    def __init__(
        self, account_id: str, api_token: str, *, timeout: Optional[float] = 10.0
    ):
        self._http = AsyncHttpClient(account_id, api_token, timeout=timeout)

    async def list_db(self) -> D1Response:
        return await self._http.list_db()

    async def create_db(self, db_name: str) -> D1Response:
        return await self._http.create_db(db_name)

    async def delete_db(self, db_id: str) -> D1Response:
        return await self._http.delete_db(db_id)

    async def get_db(self, db_id: str) -> D1Response:
        return await self._http.get_db(db_id)

    async def query_db(
        self, db_id: str, sql: str, params: Optional[List[Any]] = None
    ) -> D1QueryResult:
        return await self._http.query_db(db_id, sql, params)

    async def raw_db_query(
        self, db_id: str, sql: str, params: Optional[List[Any]] = None
    ) -> D1QueryResult:
        return await self._http.raw_db_query(db_id, sql, params)

    async def aclose(self) -> None:
        await self._http.aclose()
