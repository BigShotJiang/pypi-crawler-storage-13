class D1ClientError(Exception):
    """Base exception for d1-client."""


class D1ApiError(D1ClientError):
    """Raised when Cloudflare D1 API returns success=false or errors."""

    def __init__(self, message: str, *, errors=None, status_code: int | None = None):
        super().__init__(message)
        self.errors = errors or []
        self.status_code = status_code

    def __str__(self) -> str:  # pragma: no cover - simple formatting
        base = super().__str__()
        if self.status_code is not None:
            base = f"[HTTP {self.status_code}] {base}"
        if self.errors:
            return f"{base} | errors={self.errors}"
        return base
