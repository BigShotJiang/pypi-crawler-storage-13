from __future__ import annotations

from typing import Any, List, Optional

from ._http import SyncHttpClient
from .models import D1QueryResult, D1Response


class D1Client:
    """Synchronous Cloudflare D1 client wrapper.

    Example
    -------
    >>> client = D1Client(account_id="...", api_token="...")
    >>> resp = client.list_db()
    >>> print(resp.success, resp.result)
    """

    def __init__(
        self, account_id: str, api_token: str, *, timeout: Optional[float] = 10.0
    ):
        self._http = SyncHttpClient(account_id, api_token, timeout=timeout)

    def list_db(self) -> D1Response:
        return self._http.list_db()

    def create_db(self, db_name: str) -> D1Response:
        return self._http.create_db(db_name)

    def delete_db(self, db_id: str) -> D1Response:
        return self._http.delete_db(db_id)

    def get_db(self, db_id: str) -> D1Response:
        return self._http.get_db(db_id)

    def query_db(
        self, db_id: str, sql: str, params: Optional[List[Any]] = None
    ) -> D1QueryResult:
        return self._http.query_db(db_id, sql, params)

    def raw_db_query(
        self, db_id: str, sql: str, params: Optional[List[Any]] = None
    ) -> D1QueryResult:
        return self._http.raw_db_query(db_id, sql, params)

    def close(self) -> None:
        self._http.close()
