from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from .exceptions import D1ApiError, D1ClientError
from .models import D1Error, D1QueryResult, D1Response

BASE_URL_TEMPLATE = (
    "https://api.cloudflare.com/client/v4/accounts/{account_id}/d1/database"
)


def _build_headers(api_token: str) -> Dict[str, str]:
    return {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_token}",
    }


def _parse_d1_response(data: Dict[str, Any], *, status_code: int) -> D1Response:
    success = bool(data.get("success", False))
    errors_raw = data.get("errors", []) or []
    errors = [
        D1Error(code=e.get("code"), message=e.get("message", "")) for e in errors_raw
    ]
    result = data.get("result")

    if not success:
        raise D1ApiError(
            "Cloudflare D1 API error", errors=errors_raw, status_code=status_code
        )

    return D1Response(success=success, result=result, errors=errors)


def _parse_d1_query_response(
    data: Dict[str, Any], *, status_code: int
) -> D1QueryResult:
    success = bool(data.get("success", False))
    errors_raw = data.get("errors", []) or []
    errors = [
        D1Error(code=e.get("code"), message=e.get("message", "")) for e in errors_raw
    ]
    result = data.get("result") or data.get("results")
    meta = data.get("meta")

    if not success:
        raise D1ApiError(
            "Cloudflare D1 query error", errors=errors_raw, status_code=status_code
        )

    return D1QueryResult(success=success, results=result, meta=meta, errors=errors)


class SyncHttpClient:
    def __init__(
        self, account_id: str, api_token: str, *, timeout: Optional[float] = 10.0
    ):
        self.base_url = BASE_URL_TEMPLATE.format(account_id=account_id)
        self.headers = _build_headers(api_token)
        self._client = httpx.Client(timeout=timeout)

    def _request(
        self, method: str, path: str = "", *, json: Any | None = None
    ) -> httpx.Response:
        url = self.base_url + path
        try:
            resp = self._client.request(method, url, headers=self.headers, json=json)
            resp.raise_for_status()
            return resp
        except httpx.HTTPStatusError as exc:  # network layer OK but 4xx/5xx
            raise D1ApiError(
                "HTTP error from Cloudflare D1", status_code=exc.response.status_code
            ) from exc
        except httpx.RequestError as exc:
            raise D1ClientError(f"HTTP request failed: {exc}") from exc

    def list_db(self) -> D1Response:
        resp = self._request("GET")
        return _parse_d1_response(resp.json(), status_code=resp.status_code)

    def create_db(self, db_name: str) -> D1Response:
        payload = {"name": db_name}
        resp = self._request("POST", json=payload)
        return _parse_d1_response(resp.json(), status_code=resp.status_code)

    def delete_db(self, db_id: str) -> D1Response:
        resp = self._request("DELETE", path=f"/{db_id}")
        return _parse_d1_response(resp.json(), status_code=resp.status_code)

    def get_db(self, db_id: str) -> D1Response:
        resp = self._request("GET", path=f"/{db_id}")
        return _parse_d1_response(resp.json(), status_code=resp.status_code)

    def query_db(
        self, db_id: str, sql: str, params: Optional[list[Any]] = None
    ) -> D1QueryResult:
        payload = {"sql": sql, "params": params or []}
        resp = self._request("POST", path=f"/{db_id}/query", json=payload)
        return _parse_d1_query_response(resp.json(), status_code=resp.status_code)

    def raw_db_query(
        self, db_id: str, sql: str, params: Optional[list[Any]] = None
    ) -> D1QueryResult:
        payload = {"sql": sql, "params": params or []}
        resp = self._request("POST", path=f"/{db_id}/raw", json=payload)
        return _parse_d1_query_response(resp.json(), status_code=resp.status_code)

    def close(self) -> None:
        self._client.close()


class AsyncHttpClient:
    def __init__(
        self, account_id: str, api_token: str, *, timeout: Optional[float] = 10.0
    ):
        self.base_url = BASE_URL_TEMPLATE.format(account_id=account_id)
        self.headers = _build_headers(api_token)
        self._client = httpx.AsyncClient(timeout=timeout)

    async def _request(
        self, method: str, path: str = "", *, json: Any | None = None
    ) -> httpx.Response:
        url = self.base_url + path
        try:
            resp = await self._client.request(
                method, url, headers=self.headers, json=json
            )
            resp.raise_for_status()
            return resp
        except httpx.HTTPStatusError as exc:
            raise D1ApiError(
                "HTTP error from Cloudflare D1", status_code=exc.response.status_code
            ) from exc
        except httpx.RequestError as exc:
            raise D1ClientError(f"HTTP request failed: {exc}") from exc

    async def list_db(self) -> D1Response:
        resp = await self._request("GET")
        return _parse_d1_response(resp.json(), status_code=resp.status_code)

    async def create_db(self, db_name: str) -> D1Response:
        payload = {"name": db_name}
        resp = await self._request("POST", json=payload)
        return _parse_d1_response(resp.json(), status_code=resp.status_code)

    async def delete_db(self, db_id: str) -> D1Response:
        resp = await self._request("DELETE", path=f"/{db_id}")
        return _parse_d1_response(resp.json(), status_code=resp.status_code)

    async def get_db(self, db_id: str) -> D1Response:
        resp = await self._request("GET", path=f"/{db_id}")
        return _parse_d1_response(resp.json(), status_code=resp.status_code)

    async def query_db(
        self, db_id: str, sql: str, params: Optional[list[Any]] = None
    ) -> D1QueryResult:
        payload = {"sql": sql, "params": params or []}
        resp = await self._request("POST", path=f"/{db_id}/query", json=payload)
        return _parse_d1_query_response(resp.json(), status_code=resp.status_code)

    async def raw_db_query(
        self, db_id: str, sql: str, params: Optional[list[Any]] = None
    ) -> D1QueryResult:
        payload = {"sql": sql, "params": params or []}
        resp = await self._request("POST", path=f"/{db_id}/raw", json=payload)
        return _parse_d1_query_response(resp.json(), status_code=resp.status_code)

    async def aclose(self) -> None:
        await self._client.aclose()
