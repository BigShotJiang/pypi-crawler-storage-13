"""Constants for ZynPay SDK"""

# Router contract ABI (simplified - only methods we need)
ROUTER_ABI = [
    {
        "inputs": [
            {"name": "merchant", "type": "address"},
            {"name": "amount", "type": "uint256"},
            {"name": "paymentRequestId", "type": "bytes32"}
        ],
        "name": "pay",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "anonymous": False,
        "inputs": [
            {"indexed": True, "name": "paymentRequestId", "type": "bytes32"},
            {"indexed": True, "name": "payer", "type": "address"},
            {"indexed": True, "name": "merchant", "type": "address"},
            {"name": "amountTotal", "type": "uint256"},
            {"name": "amountToMerchant", "type": "uint256"},
            {"name": "amountToPlatform", "type": "uint256"}
        ],
        "name": "PaymentSplit",
        "type": "event"
    }
]

# USDC ERC-20 ABI (minimal)
USDC_ABI = [
    {
        "constant": True,
        "inputs": [{"name": "_owner", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "balance", "type": "uint256"}],
        "type": "function"
    },
    {
        "constant": False,
        "inputs": [
            {"name": "_spender", "type": "address"},
            {"name": "_value", "type": "uint256"}
        ],
        "name": "approve",
        "outputs": [{"name": "", "type": "bool"}],
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [
            {"name": "_owner", "type": "address"},
            {"name": "_spender", "type": "address"}
        ],
        "name": "allowance",
        "outputs": [{"name": "", "type": "uint256"}],
        "type": "function"
    },
    {
        "constant": True,
        "inputs": [],
        "name": "decimals",
        "outputs": [{"name": "", "type": "uint8"}],
        "type": "function"
    }
]

# Default API configuration
DEFAULT_API_URL = "http://localhost:3000"
DEFAULT_TIMEOUT = 30  # seconds

# Payment defaults
DEFAULT_CHAIN = "base"
MIN_PAYMENT_AMOUNT = 0.01  # USDC
MAX_PAYMENT_AMOUNT = 1000000.0  # USDC

# Gas settings
DEFAULT_GAS_LIMIT_APPROVAL = 100000  # Standard approval gas
DEFAULT_GAS_LIMIT_PAYMENT = 150000  # Standard payment gas (tested and working!)

# Confirmation settings
DEFAULT_CONFIRMATIONS = 1  # Number of block confirmations to wait
MAX_WAIT_TIME = 300  # seconds (5 minutes)

# Platform fee
PLATFORM_FEE_BPS = 1000  # 10% (1000 basis points)

# SDK metadata
SDK_VERSION = "0.1.0"
SDK_USER_AGENT = f"zynpay-python/{SDK_VERSION}"

