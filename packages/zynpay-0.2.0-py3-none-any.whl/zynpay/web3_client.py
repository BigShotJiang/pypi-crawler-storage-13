"""Web3 operations for ZynPay SDK"""

from typing import Optional
from web3 import Web3
from web3.contract import Contract
from eth_account import Account

from .environment import Environment
from .networks import get_network_config
from .constants import ROUTER_ABI, USDC_ABI, DEFAULT_GAS_LIMIT_APPROVAL, DEFAULT_GAS_LIMIT_PAYMENT
from .models import Balance, Transaction, GasEstimate
from .errors import (
    Web3Exception,
    TransactionFailedException,
    InsufficientGasException,
    NetworkException,
    InvalidAddressException
)
from .utils import validate_address, usdc_to_smallest_unit, smallest_unit_to_usdc


class Web3Client:
    """Web3 operations"""
    
    def __init__(self, environment: Environment, chain: str):
        """Initialize Web3 client
        
        Args:
            environment: Testnet or mainnet
            chain: Chain name
        """
        self.environment = environment
        self.chain = chain
        self.config = get_network_config(environment, chain)
        
        # Initialize Web3
        try:
            self.w3 = Web3(Web3.HTTPProvider(self.config["rpc_url"]))
            if not self.w3.is_connected():
                raise NetworkException(f"Cannot connect to {chain} RPC")
        except Exception as e:
            raise NetworkException(f"Failed to connect to {chain}: {str(e)}")
    
    def get_usdc_balance(self, wallet: str) -> float:
        """Get USDC balance
        
        Args:
            wallet: Wallet address
            
        Returns:
            USDC balance
        """
        wallet = validate_address(wallet)
        usdc_contract = self._get_usdc_contract()
        
        try:
            balance = usdc_contract.functions.balanceOf(
                self.w3.to_checksum_address(wallet)
            ).call()
            decimals = self.config["usdc_decimals"]
            return smallest_unit_to_usdc(balance, decimals)
        except Exception as e:
            raise Web3Exception(f"Failed to get USDC balance: {str(e)}")
    
    def get_native_balance(self, wallet: str) -> float:
        """Get native token balance (ETH or USDC for Arc)
        
        Args:
            wallet: Wallet address
            
        Returns:
            Native balance in tokens
        """
        wallet = validate_address(wallet)
        
        try:
            balance_wei = self.w3.eth.get_balance(
                self.w3.to_checksum_address(wallet)
            )
            return float(self.w3.from_wei(balance_wei, 'ether'))
        except Exception as e:
            raise Web3Exception(f"Failed to get native balance: {str(e)}")
    
    def get_balance(self, wallet: str) -> Balance:
        """Get both USDC and native balances
        
        Args:
            wallet: Wallet address
            
        Returns:
            Balance object
        """
        return Balance(
            wallet=wallet,
            usdc=self.get_usdc_balance(wallet),
            native=self.get_native_balance(wallet),
            chain=self.chain
        )
    
    def get_allowance(self, wallet: str) -> float:
        """Get USDC allowance for router
        
        Args:
            wallet: Wallet address
            
        Returns:
            Allowance amount in USDC
        """
        wallet = validate_address(wallet)
        usdc_contract = self._get_usdc_contract()
        router_address = self.config["router_address"]
        
        try:
            allowance = usdc_contract.functions.allowance(
                self.w3.to_checksum_address(wallet),
                self.w3.to_checksum_address(router_address)
            ).call()
            decimals = self.config["usdc_decimals"]
            return smallest_unit_to_usdc(allowance, decimals)
        except Exception as e:
            raise Web3Exception(f"Failed to get allowance: {str(e)}")
    
    def approve_usdc(self, amount: float, private_key: str) -> str:
        """Approve USDC spending by router
        
        Args:
            amount: Amount in USDC
            private_key: Payer's private key
            
        Returns:
            Transaction hash
        """
        account = Account.from_key(private_key)
        usdc_contract = self._get_usdc_contract()
        router_address = self.config["router_address"]
        
        # Convert amount to smallest unit
        amount_smallest = usdc_to_smallest_unit(amount, self.config["usdc_decimals"])
        
        # Build transaction
        try:
            nonce = self.w3.eth.get_transaction_count(account.address)
            
            # Get current gas price and use reasonable values for testnet
            current_gas_price = self.w3.eth.gas_price
            max_fee = max(current_gas_price * 2, self.w3.to_wei(2, 'gwei'))  # 2x current or min 2 gwei
            priority_fee = min(self.w3.to_wei(1, 'gwei'), max_fee // 10)  # 1 gwei or 10% of max
            
            tx = usdc_contract.functions.approve(
                self.w3.to_checksum_address(router_address),
                amount_smallest
            ).build_transaction({
                'from': account.address,
                'nonce': nonce,
                'gas': DEFAULT_GAS_LIMIT_APPROVAL,
                'maxFeePerGas': max_fee,
                'maxPriorityFeePerGas': priority_fee,
                'chainId': self.config["chain_id"]
            })
            
            # Sign and send
            signed_tx = account.sign_transaction(tx)
            tx_hash = self.w3.eth.send_raw_transaction(signed_tx.raw_transaction)
            
            return self.w3.to_hex(tx_hash)
        except Exception as e:
            raise TransactionFailedException(f"Approval failed: {str(e)}")
    
    def execute_payment(
        self, 
        merchant: str, 
        amount: float, 
        payment_request_id: str,
        private_key: str
    ) -> str:
        """Execute payment via router
        
        Args:
            merchant: Merchant wallet address
            amount: Amount in USDC
            payment_request_id: Payment request ID (will be hashed to bytes32)
            private_key: Payer's private key
            
        Returns:
            Transaction hash
        """
        account = Account.from_key(private_key)
        merchant = validate_address(merchant)
        router_contract = self._get_router_contract()
        
        # Convert amount to smallest unit
        amount_smallest = usdc_to_smallest_unit(amount, self.config["usdc_decimals"])
        
        # Convert payment request ID to bytes32
        payment_id_bytes = self.w3.keccak(text=payment_request_id)
        
        # Build transaction
        try:
            nonce = self.w3.eth.get_transaction_count(account.address)
            
            # Get current gas price and use reasonable values for testnet
            current_gas_price = self.w3.eth.gas_price
            max_fee = max(current_gas_price * 2, self.w3.to_wei(2, 'gwei'))  # 2x current or min 2 gwei
            priority_fee = min(self.w3.to_wei(1, 'gwei'), max_fee // 10)  # 1 gwei or 10% of max
            
            tx = router_contract.functions.pay(
                self.w3.to_checksum_address(merchant),
                amount_smallest,
                payment_id_bytes
            ).build_transaction({
                'from': account.address,
                'nonce': nonce,
                'gas': DEFAULT_GAS_LIMIT_PAYMENT,
                'maxFeePerGas': max_fee,
                'maxPriorityFeePerGas': priority_fee,
                'chainId': self.config["chain_id"]
            })
            
            # Sign and send
            signed_tx = account.sign_transaction(tx)
            tx_hash = self.w3.eth.send_raw_transaction(signed_tx.raw_transaction)
            
            return self.w3.to_hex(tx_hash)
        except Exception as e:
            raise TransactionFailedException(f"Payment failed: {str(e)}")
    
    def wait_for_transaction(self, tx_hash: str, timeout: int = 300) -> Transaction:
        """Wait for transaction confirmation
        
        Args:
            tx_hash: Transaction hash
            timeout: Timeout in seconds
            
        Returns:
            Transaction object
        """
        try:
            receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=timeout)
            
            return Transaction(
                hash=tx_hash,
                from_address=receipt['from'],
                to_address=receipt['to'],
                value=int(receipt.get('value', 0)),
                gas_used=int(receipt['gasUsed']),
                gas_price=int(receipt.get('effectiveGasPrice', 0)),
                block_number=int(receipt['blockNumber']),
                status=int(receipt['status'])
            )
        except Exception as e:
            raise TransactionFailedException(f"Transaction failed or timed out: {str(e)}")
    
    def get_transaction(self, tx_hash: str) -> Optional[Transaction]:
        """Get transaction details
        
        Args:
            tx_hash: Transaction hash
            
        Returns:
            Transaction object or None if not found
        """
        try:
            receipt = self.w3.eth.get_transaction_receipt(tx_hash)
            
            return Transaction(
                hash=tx_hash,
                from_address=receipt['from'],
                to_address=receipt['to'],
                value=int(receipt.get('value', 0)),
                gas_used=int(receipt['gasUsed']),
                gas_price=int(receipt.get('effectiveGasPrice', 0)),
                block_number=int(receipt['blockNumber']),
                status=int(receipt['status'])
            )
        except Exception:
            return None
    
    def estimate_gas(self, amount: float) -> GasEstimate:
        """Estimate gas cost for payment
        
        Args:
            amount: Payment amount in USDC
            
        Returns:
            GasEstimate object
        """
        try:
            gas_price = self.w3.eth.gas_price
            total_gas = DEFAULT_GAS_LIMIT_APPROVAL + DEFAULT_GAS_LIMIT_PAYMENT
            
            total_cost_wei = gas_price * total_gas
            total_cost_eth = float(self.w3.from_wei(total_cost_wei, 'ether'))
            
            # Rough USD estimate (assume $2000/ETH)
            total_cost_usd = total_cost_eth * 2000
            
            return GasEstimate(
                gas_limit=total_gas,
                gas_price=int(gas_price),
                total_cost_eth=total_cost_eth,
                total_cost_usd=total_cost_usd
            )
        except Exception as e:
            raise Web3Exception(f"Failed to estimate gas: {str(e)}")
    
    def _get_usdc_contract(self) -> Contract:
        """Get USDC contract instance"""
        return self.w3.eth.contract(
            address=self.w3.to_checksum_address(self.config["usdc_address"]),
            abi=USDC_ABI
        )
    
    def _get_router_contract(self) -> Contract:
        """Get router contract instance"""
        return self.w3.eth.contract(
            address=self.w3.to_checksum_address(self.config["router_address"]),
            abi=ROUTER_ABI
        )

