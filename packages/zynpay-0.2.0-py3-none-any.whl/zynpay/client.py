"""Main ZynPay client - No API keys required!"""

from typing import Optional, List, Dict, Any

from .environment import Environment
from .networks import get_network_config, get_supported_chains
from .web3_client import Web3Client
from .models import Payment, PaymentStatus, Balance
from .constants import DEFAULT_CHAIN
from .errors import PaymentException
from .utils import (
    validate_address,
    validate_amount,
    log_warning,
    log_info,
    get_env_emoji,
    usdc_to_smallest_unit
)


class ZynPayClient:
    """Main ZynPay SDK client
    
    No API keys required! Works directly with blockchain.
    You automatically earn 10% platform fee from every payment.
    
    Examples:
        >>> # Testnet (safe for development)
        >>> client = ZynPayClient(
        ...     merchant_wallet="0x...",
        ...     environment=Environment.TESTNET
        ... )
        >>> 
        >>> # Mainnet (production)
        >>> client = ZynPayClient(
        ...     merchant_wallet="0x...",
        ...     environment=Environment.MAINNET
        ... )
    """
    
    def __init__(
        self,
        merchant_wallet: str,
        environment: Environment = Environment.TESTNET,
        default_chain: str = DEFAULT_CHAIN,
        require_confirmation: bool = False,
        verbose: bool = True
    ):
        """Initialize ZynPay client
        
        Args:
            merchant_wallet: Merchant's wallet address (receives 90% of payments)
            environment: TESTNET or MAINNET (defaults to TESTNET for safety)
            default_chain: Default blockchain (base, arc, ethereum)
            require_confirmation: Require confirmation for mainnet operations
            verbose: Print info messages
            
        Examples:
            >>> # Testnet
            >>> client = ZynPayClient(
            ...     merchant_wallet="0x...",
            ...     environment=Environment.TESTNET
            ... )
            >>> 
            >>> # Mainnet
            >>> client = ZynPayClient(
            ...     merchant_wallet="0x...",
            ...     environment=Environment.MAINNET
            ... )
        """
        self.merchant_wallet = validate_address(merchant_wallet)
        self.environment = environment
        self.default_chain = default_chain
        self.require_confirmation = require_confirmation
        self.verbose = verbose
        
        # Log environment
        if self.verbose:
            emoji = get_env_emoji(self.is_testnet)
            env_name = self.environment.value.upper()
            log_info(f"{emoji} Using {env_name} environment")
            log_info(f"Merchant: {self.merchant_wallet}")
            
            if self.is_mainnet:
                log_warning("MAINNET MODE - Using real money!")
                log_info("Platform earns 10% automatically from every payment")
        
        # Initialize sub-clients
        self.payments = PaymentsClient(self)
        self.web3 = Web3ClientWrapper(self)
        
        if self.is_testnet:
            self.testnet = TestnetClient(self)
    
    @property
    def is_testnet(self) -> bool:
        """Check if testnet"""
        return self.environment.is_testnet
    
    @property
    def is_mainnet(self) -> bool:
        """Check if mainnet"""
        return self.environment.is_mainnet
    
    def get_supported_chains(self) -> List[str]:
        """Get supported chains for current environment"""
        return get_supported_chains(self.environment)


class PaymentsClient:
    """Payment operations - Direct blockchain integration"""
    
    def __init__(self, client: ZynPayClient):
        self.client = client
    
    def create(
        self,
        amount: float,
        chain: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> Payment:
        """Create payment (generates payment details)
        
        Args:
            amount: Amount in USDC
            chain: Chain name (base, arc, ethereum) - uses default if not provided
            metadata: Optional metadata
            
        Returns:
            Payment object with payment details
            
        Examples:
            >>> payment = client.payments.create(amount=5.00, chain="base")
            >>> print(f"Pay {payment.amount_usdc} USDC")
            >>> print(f"To: {payment.router_address}")
        """
        # Validate
        amount = validate_amount(amount)
        chain = chain or self.client.default_chain
        
        # Get network config
        config = get_network_config(self.client.environment, chain)
        
        # Generate payment ID
        import uuid
        payment_id = f"pay_{uuid.uuid4().hex[:24]}"
        
        # Create payment object
        payment = Payment(
            id=payment_id,
            amount=amount,
            amount_usdc=usdc_to_smallest_unit(amount),
            merchant_wallet=self.client.merchant_wallet,
            router_address=config["router_address"],
            usdc_address=config["usdc_address"],
            chain=chain,
            chain_id=config["chain_id"],
            status=PaymentStatus.PENDING,
            metadata=metadata
        )
        
        if self.client.verbose:
            log_info(f"Created payment: {payment.id}")
            log_info(f"Amount: {payment.amount} USDC")
            log_info(f"Merchant gets: {payment.amount * 0.90:.2f} USDC (90%)")
            log_info(f"Platform gets: {payment.amount * 0.10:.2f} USDC (10%)")
        
        return payment
    
    def pay(
        self,
        payment: Payment,
        payer_private_key: str,
        wait_for_confirmation: bool = True
    ) -> str:
        """Execute payment on blockchain
        
        Args:
            payment: Payment object from create()
            payer_private_key: Payer's private key
            wait_for_confirmation: Wait for transaction confirmation
            
        Returns:
            Transaction hash
            
        Examples:
            >>> payment = client.payments.create(amount=5.00)
            >>> tx_hash = client.payments.pay(
            ...     payment=payment,
            ...     payer_private_key="0x...",
            ...     wait_for_confirmation=True
            ... )
            >>> print(f"Payment confirmed! TX: {tx_hash}")
        """
        from eth_account import Account
        
        # Get Web3 client for chain
        web3_client = Web3Client(self.client.environment, payment.chain)
        
        # Check balance
        payer_address = Account.from_key(payer_private_key).address
        balance = web3_client.get_balance(payer_address)
        
        if balance.usdc < payment.amount:
            from .errors import InsufficientFundsException
            raise InsufficientFundsException(
                f"Insufficient USDC balance",
                required=payment.amount,
                available=balance.usdc
            )
        
        if balance.native < 0.0001:  # Rough gas estimate (lowered for testnet)
            from .errors import InsufficientGasException
            raise InsufficientGasException(
                f"Insufficient {web3_client.config['gas_token']} for gas fees"
            )
        
        # Approve USDC
        if self.client.verbose:
            log_info(f"Approving {payment.amount} USDC...")
        
        approve_tx = web3_client.approve_usdc(
            amount=payment.amount,
            private_key=payer_private_key
        )
        
        if wait_for_confirmation:
            web3_client.wait_for_transaction(approve_tx)
            if self.client.verbose:
                log_info("✅ Approval confirmed")
            # Small delay to ensure nonce is updated
            import time
            time.sleep(1)
        
        # Execute payment
        if self.client.verbose:
            log_info(f"💳 Executing payment of {payment.amount} USDC...")
            log_info(f"   Merchant gets: {payment.amount * 0.90:.2f} USDC")
            log_info(f"   Platform gets: {payment.amount * 0.10:.2f} USDC")
        
        payment_tx = web3_client.execute_payment(
            merchant=payment.merchant_wallet,
            amount=payment.amount,
            payment_request_id=payment.id,
            private_key=payer_private_key
        )
        
        if wait_for_confirmation:
            tx = web3_client.wait_for_transaction(payment_tx)
            if tx.is_successful:
                payment.status = PaymentStatus.CONFIRMED
                payment.tx_hash = payment_tx
                if self.client.verbose:
                    from .utils import log_success
                    log_success(f"Payment confirmed! TX: {payment_tx}")
            else:
                payment.status = PaymentStatus.FAILED
                raise PaymentException(f"Payment transaction failed: {payment_tx}")
        
        return payment_tx
    
    def verify(self, payment: Payment, tx_hash: Optional[str] = None) -> bool:
        """Verify payment on blockchain
        
        Args:
            payment: Payment object
            tx_hash: Transaction hash (uses payment.tx_hash if not provided)
            
        Returns:
            True if payment confirmed on blockchain
            
        Examples:
            >>> verified = client.payments.verify(payment)
            >>> if verified:
            ...     print("Payment confirmed!")
        """
        tx_hash = tx_hash or payment.tx_hash
        if not tx_hash:
            return False
        
        # Get Web3 client
        web3_client = Web3Client(self.client.environment, payment.chain)
        
        # Check transaction
        tx = web3_client.get_transaction(tx_hash)
        
        if tx and tx.is_successful:
            payment.status = PaymentStatus.CONFIRMED
            payment.tx_hash = tx_hash
            return True
        
        return False
    
    def get_status(self, payment: Payment) -> PaymentStatus:
        """Get current payment status
        
        Args:
            payment: Payment object
            
        Returns:
            Current payment status
        """
        if payment.tx_hash:
            self.verify(payment)
        
        return payment.status


class Web3ClientWrapper:
    """Web3 operations wrapper"""
    
    def __init__(self, client: ZynPayClient):
        self.client = client
    
    def get_balance(self, wallet: str, chain: Optional[str] = None) -> Balance:
        """Get wallet balance
        
        Args:
            wallet: Wallet address
            chain: Chain name (uses default if not provided)
            
        Returns:
            Balance object with USDC and native balances
        """
        chain = chain or self.client.default_chain
        web3_client = Web3Client(self.client.environment, chain)
        return web3_client.get_balance(wallet)
    
    def get_usdc_balance(self, wallet: str, chain: Optional[str] = None) -> float:
        """Get USDC balance
        
        Args:
            wallet: Wallet address
            chain: Chain name
            
        Returns:
            USDC balance
        """
        chain = chain or self.client.default_chain
        web3_client = Web3Client(self.client.environment, chain)
        return web3_client.get_usdc_balance(wallet)
    
    def estimate_gas(self, amount: float, chain: Optional[str] = None):
        """Estimate gas cost for payment
        
        Args:
            amount: Payment amount
            chain: Chain name
            
        Returns:
            GasEstimate object
        """
        chain = chain or self.client.default_chain
        web3_client = Web3Client(self.client.environment, chain)
        return web3_client.estimate_gas(amount)


class TestnetClient:
    """Testnet-only operations"""
    
    def __init__(self, client: ZynPayClient):
        self.client = client
        
        if not client.is_testnet:
            raise ValueError("Testnet operations only available in testnet mode")
    
    def get_faucet_url(self, chain: Optional[str] = None) -> str:
        """Get faucet URL for chain
        
        Args:
            chain: Chain name (uses default if not provided)
            
        Returns:
            Faucet URL
        """
        from .networks import get_faucet_url
        chain = chain or self.client.default_chain
        return get_faucet_url(self.client.environment, chain)
    
    def get_usdc(self, wallet: str, amount: float = 10.0, chain: Optional[str] = None):
        """Get testnet USDC (returns faucet URL)
        
        Args:
            wallet: Wallet address
            amount: Amount to request (informational)
            chain: Chain name
            
        Returns:
            Faucet URL
        """
        faucet_url = self.get_faucet_url(chain)
        log_info(f"Get testnet USDC from: {faucet_url}")
        log_info(f"Paste wallet: {wallet}")
        log_info(f"Request amount: {amount} USDC")
        return faucet_url
