<p align="center">
  <!-- Баннер -->
  <img src="https://raw.githubusercontent.com/skyaree/heroku-modules/test/IMG_20251124_141104_162.jpg" alt="SKYLINETL Banner" width="600"/>
</p>

<p align="center">
  <!-- Название в кастомном стиле -->
  <span style="font-size:48px;">🌌 ＳＫＹＬＩＮＥＴＬ</span><br>
  <em> FORK OF  <img src="https://img.shields.io/badge/Telethon-GitHub-7289DA?style=flat-square&logo=github" alt="Telethon GitHub"/></em>
</p>

<p align="center">
  <!-- Основные бейджи -->
  <img src="https://img.shields.io/badge/Branch-main-blue?style=flat-square" alt="branch">
  <img src="https://img.shields.io/badge/Version-v1.0.0-green?style=flat-square" alt="version">
  <img src="https://img.shields.io/badge/GitHub-skyaree%2Fskylinetl-181717?style=flat-square&logo=github" alt="github">
  <img src="https://img.shields.io/badge/License-MIT-yellow?style=flat-square" alt="license">
</p>

---

## ❓ Что такое Skylinetl?

**Skylinetl** — это форк популярной библиотеки [Telethon](https://github.com/LonamiWebs/Telethon).  
Он создан для:

- ⚡ Оптимизации и повышения стабильности работы  
- 🤖 Использования как для обычных ботов, так и для **юзерботов**  
- 🛠 Лёгкой настройки и использования Telegram API  

> Этот форк немного улучшен, чтобы ваши боты работали быстрее и надёжнее!

---

## 🚀 Установка

Просто пропишите в терминале:

```bash
pip install skylinetl==1.0.0
```
Если возникнут проблемы при установке попробуйте:
```bash
pip install skylinetl==1.0.0 --break-system-packages
```
## 💻 Пример использования:
```python
from skylinetl import TelegramClient

api_id = 123456
api_hash = "your_api_hash"

client = TelegramClient('session_name', api_id, api_hash)

async def main():
    me = await client.get_me()
    print(me.stringify())

with client:
    client.loop.run_until_complete(main())
```

Спасибо за telethon, LonamiWebs!
