"""Beacon communication"""
