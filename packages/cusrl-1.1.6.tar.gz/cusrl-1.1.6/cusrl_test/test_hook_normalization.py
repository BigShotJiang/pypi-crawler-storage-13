import random

import gymnasium as gym
import pytest
import torch

import cusrl
from cusrl_test import create_dummy_env


def train_agent_with_observation_normalization(env, window_size=None, num_iterations=5):
    agent_factory = cusrl.preset.ppo.AgentFactory()
    agent_factory.register_hook(cusrl.hook.ObservationNormalization(window_size), after="module_initialization")
    trainer = cusrl.Trainer(env, agent_factory, num_iterations=num_iterations)
    trainer.run_training_loop()
    return trainer.agent


@pytest.mark.parametrize(
    "environment",
    [
        create_dummy_env(),
        create_dummy_env(with_state=True),
        create_dummy_env(numpy=True),
        create_dummy_env(numpy=True, with_state=True),
        cusrl.make_gym_vec(
            "MountainCarContinuous-v0",
            num_envs=4,
            vector_kwargs={"autoreset_mode": gym.vector.AutoresetMode.DISABLED},
        ),
    ],
)
@pytest.mark.parametrize("window_size", [None, 100])
def test_observation_normalization(environment, window_size):
    agent = train_agent_with_observation_normalization(environment, window_size)
    agent.load_state_dict(agent.state_dict())


def test_observation_normalization_with_symmetry():
    env = create_dummy_env(with_state=True, symmetric=True)
    agent = train_agent_with_observation_normalization(env)
    hook = agent.hook["observation_normalization"]

    mean = hook.observation_rms.mean
    mirrored_mean = env.spec.mirror_observation(mean)
    var = hook.observation_rms.var
    mirrored_var = abs(env.spec.mirror_observation(var))
    assert torch.allclose(mean, mirrored_mean)
    assert torch.allclose(var, mirrored_var)

    mean = hook.state_rms.mean
    mirrored_mean = env.spec.mirror_state(mean)
    var = hook.state_rms.var
    mirrored_var = abs(env.spec.mirror_state(var))
    assert torch.allclose(mean, mirrored_mean)
    assert torch.allclose(var, mirrored_var)


@pytest.mark.parametrize(
    "env",
    [
        create_dummy_env(with_state=True),
        create_dummy_env(with_state=True, symmetric=True),
    ],
)
def test_observation_normalization_with_observation_is_subset_of_state(env):
    random_indices = list(range(env.state_dim))
    random.shuffle(random_indices)

    for subset in (slice(0, env.observation_dim), random_indices[: env.observation_dim]):
        env.spec.observation_is_subset_of_state = subset
        agent = train_agent_with_observation_normalization(env)
        hook = agent.hook["observation_normalization"]

        mean = hook.observation_rms.mean
        sliced_mean = hook.state_rms.mean[subset]
        var = hook.observation_rms.var
        sliced_var = hook.state_rms.var[subset]
        assert torch.allclose(mean, sliced_mean)
        assert torch.allclose(var, sliced_var)


def test_observation_normalization_with_groups_and_excluded_indices():
    env = create_dummy_env(with_state=True)
    env.spec.observation_stat_groups = (slice(8, 16),)
    env.spec.state_stat_groups = ((0, 3), slice(16, 24))
    env.spec.observation_normalization_excluded_indices = slice(4, 8)
    env.spec.state_normalization_excluded_indices = (4, 5, 6)
    agent = train_agent_with_observation_normalization(env)
    hook = agent.hook["observation_normalization"]

    for indices in env.spec.observation_stat_groups:
        mean = hook.observation_rms.mean[indices,]
        var = hook.observation_rms.var[indices,]
        assert torch.allclose(mean, mean)
        assert torch.allclose(var, var)

    for indices in env.spec.state_stat_groups:
        mean = hook.state_rms.mean[indices,]
        var = hook.state_rms.var[indices,]
        assert torch.allclose(mean, mean)
        assert torch.allclose(var, var)

    excluded_indices = env.spec.observation_normalization_excluded_indices
    excluded_mean = hook.observation_rms.mean[excluded_indices,]
    excluded_var = hook.observation_rms.var[excluded_indices,]
    assert torch.allclose(excluded_mean, torch.zeros_like(excluded_mean))
    assert torch.allclose(excluded_var, torch.ones_like(excluded_var))
    excluded_indices = env.spec.state_normalization_excluded_indices
    excluded_mean = hook.state_rms.mean[excluded_indices,]
    excluded_var = hook.state_rms.var[excluded_indices,]
    assert torch.allclose(excluded_mean, torch.zeros_like(excluded_mean))
    assert torch.allclose(excluded_var, torch.ones_like(excluded_var))
