import sys
import requests
from datetime import datetime

def get_time_and_temp(city):
    url = f"https://wttr.in/{city}?format=j1"
    data = requests.get(url).json()

    temp_C = data["current_condition"][0]["temp_C"]

    # Extract UTC offset from nearest_area → areaName
    timezone_offset = datetime.now().astimezone().utcoffset()
    total_seconds = int(timezone_offset.total_seconds())
    hrs = total_seconds // 3600
    mins = (total_seconds % 3600) // 60

    # Format current local time
    local_time = datetime.now().strftime("%I:%M %p")

    return {
        "city": city.capitalize(),
        "temp_C": temp_C,
        "local_time": local_time
    }

def main():
    if len(sys.argv) < 2:
        print("Usage: weather <city>")
        return
    
    city = " ".join(sys.argv[1:])
    print(f"Please wait, fetching details for {city}...")
    data = get_time_and_temp(city)

    print(f"{data['city']}  {data['temp_C']}°C  {data['local_time']}")
