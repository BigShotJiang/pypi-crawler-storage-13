import sys
import os
from google import genai
from dotenv import load_dotenv

# Load .env file
load_dotenv()

# Read API key
API_KEY = os.getenv("GEMINI_API_KEY")

if not API_KEY:
    print("GEMINI_API_KEY not found in .env")
    sys.exit(1)

client = genai.Client(api_key=API_KEY)


# ---------------- WEATHER MODE ----------------
def ask_gemini_weather(city):
    
    prompt = f"""
            You are a factual weather assistant.

            TASK:
            - Fetch real weather and current time for the city.
            - Use tools/retrieval if available.
            - If unsure, say "I cannot retrieve real weather right now."

            RESPONSE FORMAT (STRICT):
            City: <city>
            Temperature: <temp in °C>
            Local Time: <12-hour format>

            City to lookup: {city}

            Do NOT include extra text.
            Do NOT give explanations.
            Do NOT hallucinate values.
            Return ONLY the 3-line format above.
            """


    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=prompt
    )

    return response.text.strip()


# --------------- ERROR RESOLVER MODE ---------------
def ask_gemini_resolve(error_text):
    prompt = f"""
        You are a senior debugging assistant.

        TASK:
        Analyze the given error EXACTLY as written.
        If there is not enough information, say:
        "Insufficient error details to diagnose."

        ERROR:
        {error_text}

        RESPONSE FORMAT (STRICT):
        Cause: <one-line root cause>
        Fix: <exact steps to fix>
        Notes: <beginner-friendly explanation>

        RULES:
        - Be concise.
        - Do NOT invent missing details.
        - Do NOT assume the user environment.
        - No storytelling. Strictly technical.
        """


    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=prompt
    )

    return response.text.strip()


# ------------------- MAIN CLI ----------------------
def main():
    script = os.path.basename(sys.argv[0])

    # WEATHER
    if "weather" in script:
        if len(sys.argv) < 2:
            print("Usage: weather <city>")
            return

        city = " ".join(sys.argv[1:])
        print(f"Please wait… asking Gemini about {city}...\n")

        try:
            print(ask_gemini_weather(city))
        except Exception as e:
            print("❌ Gemini Error:", e)
        return

    # RESOLVE
    if "resolve" in script:
        if len(sys.argv) < 2:
            print("Usage: resolve <error text>")
            return

        error_text = " ".join(sys.argv[1:])
        print("Please wait… analyzing the error...\n")

        try:
            print(ask_gemini_resolve(error_text))
        except Exception as e:
            print("❌ Gemini Error:", e)
        return

    # Unknown
    print("Unknown command. Use:")
    print("  weather <city>")
    print("  resolve <error text>")
