"""
gpio-clear — Safely reset all Raspberry Pi GPIO pins.

Usage:
    babicli gpio_clear
"""

def run():
    print("Clearing GPIO state...")

    try:
        import RPi.GPIO as GPIO
        GPIO.setmode(GPIO.BCM)
        GPIO.cleanup()
        print("GPIO cleanup complete.")
    except Exception:
        print("RPi.GPIO not available on this system.")
        print("No hardware pins were changed.")
