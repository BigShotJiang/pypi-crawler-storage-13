
# **BABICLI — Fast & Modular Command-Line Toolkit**

## **Developer Notes & Version History**

**Latest Release:** 0.3.4

**Architecture:** Fully plugin-driven — all commands come from modules inside `babicli/plugins/`.

**Highlights:**

* Fixed gpio_clear bc stupid AI

---

# **Overview**

**babicli** is a lightweight, fast, and extensible command-line toolkit.

Every command is a  **plugin** , allowing unlimited customization without modifying the core CLI.

If you know Python, you can instantly add new commands.

---

# **Installation**

Install from PyPI:

<pre class="overflow-visible!" data-start="1040" data-end="1069"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>pip install babicli
</span></span></code></div></div></pre>

Upgrade to the newest version:

<pre class="overflow-visible!" data-start="1103" data-end="1142"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>pip install --upgrade babicli
</span></span></code></div></div></pre>

Run:

<pre class="overflow-visible!" data-start="1150" data-end="1172"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>babicli </span><span>help</span><span>
</span></span></code></div></div></pre>

---

# **Features**

* Fast command execution
* Clean plugin system — drop a file, gain a command
* System diagnostics (doctor, diskguard)
* Network tools (netinfo)
* Chaos random generator (ranum)
* Benchmarks (bench)
* Auto plugin generator (`mgenerate`)
* Cache inspection + cleanup tools
* Zero dependencies except Python standard library

---

# **Available Commands**

*(Commands vary depending on installed plugins)*

| Command               | Description                                      |
| --------------------- | ------------------------------------------------ |
| **bench**       | Run CPU and disk benchmarks                      |
| **cache clear** | Clear all cache files                            |
| **cache show**  | Show the cache directory                         |
| **cache size**  | Display cache storage usage                      |
| **diskguard**   | Detect low disk space or filesystem issues       |
| **doctor**      | Diagnose common system issues                    |
| **help**        | Show all available commands                      |
| **mgenerate**   | Generate a boilerplate plugin                    |
| **modules**     | List all installed plugins                       |
| **netinfo**     | Show internal and external network information   |
| **ranum**       | Generate a secure chaotic 32-digit random number |
| **sysinfo**     | Display OS, CPU, RAM, and storage information    |

Run any command:

<pre class="overflow-visible!" data-start="2312" data-end="2372"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>babicli sysinfo
babicli netinfo
babicli cache size
</span></span></code></div></div></pre>

---

# **Usage Examples**

Show system information:

<pre class="overflow-visible!" data-start="2427" data-end="2452"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>babicli sysinfo
</span></span></code></div></div></pre>

Detect low disk space:

<pre class="overflow-visible!" data-start="2478" data-end="2505"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>babicli diskguard
</span></span></code></div></div></pre>

Generate a cryptographically chaotic random number:

<pre class="overflow-visible!" data-start="2560" data-end="2583"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>babicli ranum
</span></span></code></div></div></pre>

Clear all cache:

<pre class="overflow-visible!" data-start="2603" data-end="2632"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>babicli cache clear
</span></span></code></div></div></pre>

---

# **Creating Your Own Plugins**

babicli is designed to make plugin creation extremely simple.

## **Option 1: Auto-Generate a Plugin (Recommended)**

<pre class="overflow-visible!" data-start="2790" data-end="2826"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>babicli mgenerate myplugin
</span></span></code></div></div></pre>

Creates:

<pre class="overflow-visible!" data-start="2838" data-end="2873"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre!"><span><span>babicli/plugins/myplugin.py
</span></span></code></div></div></pre>

With boilerplate:

<pre class="overflow-visible!" data-start="2894" data-end="2968"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-python"><span><span>def</span><span></span><span>run</span><span>():
    </span><span>print</span><span>(</span><span>"Plugin myplugin loaded successfully!"</span><span>)
</span></span></code></div></div></pre>

Run it:

<pre class="overflow-visible!" data-start="2979" data-end="3005"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>babicli myplugin
</span></span></code></div></div></pre>

---

## **Option 2: Manual Creation**

Create a file:

<pre class="overflow-visible!" data-start="3062" data-end="3094"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre!"><span><span>babicli/plugins/hello.py
</span></span></code></div></div></pre>

Add:

<pre class="overflow-visible!" data-start="3102" data-end="3159"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-python"><span><span>def</span><span></span><span>run</span><span>():
    </span><span>print</span><span>(</span><span>"Hello from babicli!"</span><span>)
</span></span></code></div></div></pre>

Run it:

<pre class="overflow-visible!" data-start="3170" data-end="3193"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>babicli hello
</span></span></code></div></div></pre>

---

# **Troubleshooting**

### **babicli: command not found**

Try reinstalling:

<pre class="overflow-visible!" data-start="3277" data-end="3324"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>pip install --force-reinstall babicli
</span></span></code></div></div></pre>

Or run directly:

<pre class="overflow-visible!" data-start="3344" data-end="3376"><div class="contain-inline-size rounded-2xl relative bg-token-sidebar-surface-primary"><div class="sticky top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre! language-sh"><span><span>python -m babicli </span><span>help</span><span>
</span></span></code></div></div></pre>

---

### **Plugin not detected**

Check the following:

* Plugin file is in: `babicli/plugins/`
* Filename is lowercase
* Contains a `run()` function
* `__init__.py` exists inside the plugins folder

---

# **Ideas for Future Plugins**

* **memwatch** — detect RAM leaks
* **powercheck** — Raspberry Pi undervoltage monitor
* **sdhealth** — SD card corruption detector
* **netdoctor** — deep network diagnostics
* **logguard** — detect rapidly growing log files
* **sshwatch** — detect SSH brute-force attempts
* **zombies** — zombie process detector

---

# **License**

SHADOWLOCK License
