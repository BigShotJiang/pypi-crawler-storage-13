# LungSegmentation nnUNetv2 Prediction Script

[![Python](https://img.shields.io/badge/Python-3.9%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-MIT-green)](LICENSE)

A Python script to easily run **nnUNetv2** lung segmentation predictions
on medical images. Automatic model download, file preparation for
prediction, and result renaming included.

------------------------------------------------------------------------

## Features

-   Automatic download and extraction of models from a URL.
-   Preparation of `dataset.json` for nnUNet prediction.
-   Conversion of input images to `.nrrd` if necessary.
-   Prediction execution with detailed logs.
-   Automatic cleanup of temporary files.
-   Automatic renaming of the final prediction file.

------------------------------------------------------------------------

## Requirements

Before running the script, make sure you have installed and configured
the following:

``` bash
git clone https://github.com/FlorianDAVAUX/nnUNet_package.git
cd nnUNet_package
pip install -e .
```

------------------------------------------------------------------------

## Usage

  -------------------------------------------------------------------------------------------
  Option                        Description              Example
  ----------------------------- ------------------------ ------------------------------------
  `--mode`                      Prediction mode          `--mode Invivo`
                                (`Invivo` or `Exvivo`)   

  `--structure`                 Structure to segment     `--structure Parenchyma`
                                (`Parenchyma`,           
                                `Airways`, `Vascular`,   
                                `ParenchymaAirways`,     
                                `All`, `Lobes`)          

  `--input`                     Path to the input image  `--input ~/data/scan_patient.nrrd`
                                (.nii, .nii.gz, .mha,    
                                .nrrd)                   

  `--output`                    Output directory for the `--output ~/predictions`
                                prediction (default:     
                                `prediction`)            

  `--models_dir`                Path to store or search  `--models_dir ~/models`
                                for models               

  `--name`                      Final name of the        `--name segmentation_parenchyma`
                                prediction file (without 
                                extension)               
  -------------------------------------------------------------------------------------------

------------------------------------------------------------------------

### Full Example

``` bash
nnunet_predict     --mode Invivo     --structure Parenchyma     --input ~/data/scan_patient.nrrd     --output ~/predictions     --models_dir ~/models     --name segmentation_parenchyma
```