import os
import torch
import torch.nn as nn
import rasterio
import geopandas as gpd
import numpy as np
from shapely.geometry import shape
from skimage import measure
import json
from .models.hf_model_manager import HuggingFaceModelManager

class SimpleFloodModel(nn.Module):
    """
    Simple CNN model for flood detection.
    This should match the architecture your model was trained with.
    """
    def __init__(self, input_channels=4, num_classes=1):
        super(SimpleFloodModel, self).__init__()
        self.encoder = nn.Sequential(
            nn.Conv2d(input_channels, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
        )
        
        self.decoder = nn.Sequential(
            nn.Conv2d(256, 128, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            
            nn.Conv2d(128, 64, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            
            nn.Conv2d(64, 32, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, num_classes, kernel_size=1),
        )
    
    def forward(self, x):
        x = self.encoder(x)
        x = self.decoder(x)
        return x

class FloodGeoAITool:
    def __init__(self, model_path=None, model_name='default', repo_id=None, model_architecture=None):
        """
        Initialize tool with Hugging Face model support.
        """
        # Set device FIRST
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
        # Set Hugging Face repo
        if repo_id is None:
            repo_id = "yourusername/flood-detection-model"
            
        self.model_manager = HuggingFaceModelManager(repo_id)
        
        if model_path:
            # Use custom model path
            self.model_path = model_path
            print(f"Using custom model: {model_path}")
        else:
            # Download from Hugging Face
            self.model_path = self.model_manager.get_model_path(model_name)
            print(f"Using pre-trained model: {model_name}")
            
        # Load model AFTER device is set
        self.model = self.load_model(model_architecture)
        print(f"✓ Model loaded successfully")
    
    def load_model(self, model_architecture=None):
        """Load the model, handling both complete models and state dictionaries."""
        try:
            if not os.path.exists(self.model_path):
                raise FileNotFoundError(f"Model file not found: {self.model_path}")
            
            print(f"Loading model from: {self.model_path}")
            
            # Load the model file
            model_data = torch.load(self.model_path, map_location=self.device)
            
            # Check if it's a state dictionary or a complete model
            if isinstance(model_data, dict):
                print("Detected state dictionary, loading into model architecture...")
                
                # Use provided architecture or default
                if model_architecture is None:
                    model_architecture = self.detect_model_architecture(model_data)
                
                # Load state dict into model
                model_architecture.load_state_dict(model_data)
                model = model_architecture
            else:
                print("Detected complete model object")
                model = model_data
            
            # Set to evaluation mode
            if hasattr(model, 'eval'):
                model.eval()
            
            return model
                
        except Exception as e:
            print(f"✗ Failed to load model: {e}")
            print("\nTroubleshooting tips:")
            print("1. The model might be a state dictionary - we'll try automatic detection")
            print("2. Check if the model architecture matches")
            print("3. Try providing a custom model architecture")
            raise
    
    def detect_model_architecture(self, state_dict):
        """
        Try to detect the appropriate model architecture from the state dict.
        This is a simple heuristic - you may need to customize this for your specific model.
        """
        print("Attempting to detect model architecture from state dict...")
        
        # Analyze state dict keys to guess architecture
        keys = list(state_dict.keys())
        print(f"State dict keys: {keys[:5]}...")  # Show first 5 keys
        
        # Check for common architecture patterns
        if any('encoder' in key for key in keys) or any('decoder' in key for key in keys):
            print("Detected encoder-decoder architecture (like UNet)")
            return SimpleFloodModel()
        elif any('resnet' in key for key in keys):
            print("Detected ResNet-like architecture")
            # You would import and return appropriate ResNet model here
            return SimpleFloodModel()
        else:
            print("Using default SimpleFloodModel architecture")
            return SimpleFloodModel()
    
    def preprocess_image(self, image_array):
        """Preprocess satellite image for the model."""
        if image_array.dtype == np.uint16:
            image_array = image_array / 65535.0
        elif image_array.dtype == np.uint8:
            image_array = image_array / 255.0
            
        if len(image_array.shape) == 2:
            image_array = np.expand_dims(image_array, axis=0)
        elif len(image_array.shape) == 3:
            if image_array.shape[2] <= 4:
                image_array = np.moveaxis(image_array, 2, 0)
        
        return image_array.astype(np.float32)
    
    def detect_surface_water(self, image_path, confidence_threshold=0.5):
        """Run model inference on satellite image."""
        with rasterio.open(image_path) as src:
            image_data = src.read()
            transform = src.transform
            crs = src.crs
        
        print(f"Input image shape: {image_data.shape}")
        processed_image = self.preprocess_image(image_data)
        print(f"Processed image shape: {processed_image.shape}")
        
        # Add batch dimension and move to device
        input_tensor = torch.from_numpy(processed_image).unsqueeze(0).float().to(self.device)
        print(f"Input tensor shape: {input_tensor.shape}")
        
        with torch.no_grad():
            if self.model is not None:
                # Now self.model should be callable
                output = self.model(input_tensor)
                print(f"Model output shape: {output.shape}")
                
                # Handle model output
                if isinstance(output, torch.Tensor):
                    if output.shape[1] == 1:  # Binary segmentation
                        predictions = torch.sigmoid(output).squeeze().cpu().numpy()
                        water_mask = (predictions > confidence_threshold).astype(np.uint8)
                    else:  # Multi-class segmentation
                        predictions = torch.softmax(output, dim=1).squeeze().cpu().numpy()
                        water_mask = (np.argmax(predictions, axis=0) == 1).astype(np.uint8)
                else:
                    raise ValueError("Model output format not recognized")
            else:
                # Fallback water detection
                print("Model not loaded, using fallback water detection")
                water_mask = self.fallback_water_detection(processed_image)
        
        print(f"Water pixels detected: {np.sum(water_mask)} / {water_mask.size}")
        return water_mask, transform, crs

    # ... (keep the rest of the methods the same as before - polygonize_water_mask, analyze_flood_impact, etc.)

    def debug_model_info(self):
        """Debug method to inspect the loaded model."""
        print("=== Model Debug Information ===")
        print(f"Model type: {type(self.model)}")
        print(f"Model device: {next(self.model.parameters()).device if hasattr(self.model, 'parameters') else 'N/A'}")
        
        if hasattr(self.model, 'parameters'):
            total_params = sum(p.numel() for p in self.model.parameters())
            print(f"Total parameters: {total_params:,}")
        
        # Test if model is callable
        try:
            test_input = torch.randn(1, 4, 64, 64).to(self.device)
            test_output = self.model(test_input)
            print(f"Model test successful. Input: {test_input.shape}, Output: {test_output.shape}")
        except Exception as e:
            print(f"Model test failed: {e}")