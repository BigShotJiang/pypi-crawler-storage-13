import json
from pathlib import Path

from typer.testing import CliRunner

from cli.main import app

runner = CliRunner()


def test_pg_list_runs():
    """pg --list sollte ohne Fehler laufen und mindestens ein Preset anzeigen."""
    result = runner.invoke(app, ["pg", "--list"])
    assert result.exit_code == 0
    # einfache Sanity-Checks
    assert "Verfügbare Presets" in result.stdout
    # mindestens eines der erwarteten Presets sollte vorkommen
    assert "oracle_oltp" in result.stdout


def test_pg_preset_oracle_oltp():
    """pg --preset oracle_oltp sollte Tabelle ausgeben."""
    result = runner.invoke(app, ["pg", "--preset", "oracle_oltp"])
    assert result.exit_code == 0
    assert "Preset: oracle_oltp" in result.stdout
    # ein paar typische Parameter prüfen
    assert "shared_buffers" in result.stdout or "work_mem" in result.stdout


def test_pg_diff_oracle_oltp_highload():
    """pg --diff oracle_oltp,highload sollte ohne Fehler laufen und Diff-Tabelle zeigen."""
    result = runner.invoke(app, ["pg", "--diff", "oracle_oltp,highload"])
    assert result.exit_code == 0
    # Überschrift
    assert "Preset-Diff" in result.stdout
    assert "oracle_oltp" in result.stdout
    assert "highload" in result.stdout
    # Irgendein Status muss vorkommen
    assert "SAME" in result.stdout or "DIFFERENT" in result.stdout


def test_deploy_dry_run_default_config():
    """deploy (Default, Dry-Run) sollte eine Übersicht mit DB Identifier etc. anzeigen."""
    result = runner.invoke(app, ["deploy"])
    assert result.exit_code == 0
    assert "RDS Deploy – Dry Run" in result.stdout
    assert "DB Identifier" in result.stdout
    assert "Engine" in result.stdout
    assert "Region" in result.stdout


def test_deploy_export_plan(tmp_path):
    """deploy --out <file> sollte einen JSON-Plan erzeugen."""
    out_file = tmp_path / "plan.json"
    result = runner.invoke(app, ["deploy", "--out", str(out_file)])
    assert result.exit_code == 0
    assert out_file.exists()

    data = json.loads(out_file.read_text(encoding="utf-8"))
    # einfache Strukturchecks
    assert "aws" in data
    assert "db" in data
    assert "network" in data
    assert "maintenance" in data

    assert data["aws"]["region"]
    assert data["db"]["identifier"]
    # neuer Check: Cluster Identifier muss im Plan vorhanden sein
    assert data["db"]["cluster_identifier"] is not None


def test_readiness_basic():
    """readiness sollte ohne Parameter laufen und eine Tabelle mit Checks anzeigen."""
    result = runner.invoke(app, ["readiness"])
    assert result.exit_code == 0
    assert "Migration Readiness – Oracle → PostgreSQL" in result.stdout
    # Irgendein typischer Check-Name muss auftauchen
    assert "BULK_LOAD_STRATEGY" in result.stdout or "NUMERIC" in result.stdout


def test_readiness_export_html(tmp_path):
    """readiness --export <file> sollte eine HTML-Datei erzeugen."""
    out_file = tmp_path / "readiness.html"
    result = runner.invoke(app, ["readiness", "--export", str(out_file)])
    assert result.exit_code == 0
    assert out_file.exists()

    content = out_file.read_text(encoding="utf-8")
    assert "<html" in content
    assert "Migration Readiness – Oracle → PostgreSQL" in content
    assert "<table" in content


def test_readiness_with_source_and_export(tmp_path):
    """readiness mit --source und --export sollte beides korrekt verarbeiten."""
    ddl_file = tmp_path / "schema.sql"
    ddl_file.write_text("CREATE TABLE dummy(id NUMBER);", encoding="utf-8")
    out_file = tmp_path / "readiness.html"

    result = runner.invoke(
        app,
        [
            "readiness",
            "--source",
            str(ddl_file),
            "--export",
            str(out_file),
        ],
    )
    assert result.exit_code == 0
    assert out_file.exists()
    content = out_file.read_text(encoding="utf-8")
    assert "dummy" in content or "Migration Readiness" in content  # grober Check


def test_pg_export_aws():
    """pg --export aws sollte einen AWS-CLI-Snippet ausgeben."""
    result = runner.invoke(app, ["pg", "--preset", "oracle_oltp", "--export", "aws"])
    assert result.exit_code == 0
    assert "aws rds modify-db-parameter-group" in result.stdout
    assert "--db-parameter-group-name" in result.stdout
