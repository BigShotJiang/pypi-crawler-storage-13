RDS Ops Kit

Migration Accelerator for Oracle → PostgreSQL / Aurora-PostgreSQL

Ein leichtgewichtiges, erweiterbares Toolkit zur Unterstützung von Datenbank-Migrationen, speziell von Oracle nach PostgreSQL / AWS Aurora PostgreSQL.

Das RDS Ops Kit bietet:

✔ Parameter Group Generator (Presets + AWS-CLI Export)

✔ Deployment Dry-Run (liest .env-Konfiguration und zeigt Cluster-Plan an)

✔ Readiness Checks für typische Oracle→PG-Risiken

✔ Vollständig modular aufgebaut

✔ Zero-Dependency JSON-Templates für Parametergruppen

✔ AWS-CLI-Export zum sofortigen Anwenden in AWS

📦 Features
🔧 1. Deployment – Dry Run

Zeigt an, wie ein Aurora/RDS-Cluster angelegt würde – ohne AWS-Calls.

python -m cli.main deploy


Nutzung mit eigener Config:

python -m cli.main deploy --config templates/configs/sample.env

🎛 2. Parameter Group Generator

Lädt Presets aus templates/parameter_groups:

python -m cli.main pg --list
python -m cli.main pg --preset oracle_oltp


Mit AWS CLI Export:

python -m cli.main pg --preset oracle_oltp --export aws

🧭 3. Readiness Scanner

Checkliste typischer Oracle→PostgreSQL-Migrationsrisiken:

python -m cli.main readiness


Mit optionaler Quelle:

python -m cli.main readiness --source dump.sql


Noch kein DDL-Parsing — Platzhalter für die spätere Analyse.

📁 Projektstruktur
rds_ops_kit/
  cli/
    main.py
  templates/
    parameter_groups/
      oracle_oltp.json
      oracle_migration.json
      highload.json
    configs/
      sample.env
  docs/
    install.md
    usage.md
  tests/
  README.md

🚀 Installation

Schritt 1: Python 3.12 installieren
https://python.org

Schritt 2: Repo klonen / Projektordner erstellen

mkdir ~/dev
cd ~/dev
git clone <repo-url> rds_ops_kit
cd rds_ops_kit


Schritt 3: Virtual Environment

python -m venv .venv
.\.venv\Scripts\activate


Schritt 4: Dependencies

pip install typer rich boto3


Fertig.

Details: siehe docs/install.md

🖥 Nutzung

Alle Commands laufen über:

python -m cli.main <command>


Hilfe:

python -m cli.main --help


Details: siehe docs/usage.md

🗺 Roadmap

 Echte boto3-Deployment-Calls (create-db-cluster, create-db-instance)

 Export-Modus für Parameter Groups in Datei (--out ...)

 Diff-Tool für Parametergruppen

 Readiness-Scanner mit SQL/DDL-Parsing

 Packaging als pip-installierbares CLI (pyproject.toml)

 pipx-Installation als globales Kommando

🤝 Contributing

Pull Requests, Feature-Requests und Issues sind willkommen.

📄 Lizenz

MIT License (falls du willst – kann angepasst werden).

🧑‍💻 Autor

RDS Ops Kit – Cloud Migration Accelerator
Created by Vjekoslav Goronja ©2025 