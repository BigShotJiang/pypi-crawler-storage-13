from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Optional, Any, List

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(help="RDS Ops Kit – Migration Accelerator")
console = Console()


# -------------------------
# BASE DIR & TEMPLATES
# -------------------------


def _detect_base_dir() -> Path:
    """
    Versucht, den Projekt-Root zu erkennen.

    1. Elternordner von main.py (typisch im Dev-Mode)
    2. Aktuelles Arbeitsverzeichnis (wenn dort 'templates' liegt)
    """
    here = Path(__file__).resolve()
    candidate = here.parents[1]
    if (candidate / "templates").exists():
        return candidate

    cwd = Path.cwd()
    if (cwd / "templates").exists():
        return cwd

    # Fallback: ursprünglicher candidate
    return candidate


BASE_DIR = _detect_base_dir()
TEMPLATES_DIR = BASE_DIR / "templates" / "parameter_groups"
CONFIGS_DIR = BASE_DIR / "templates" / "configs"


# -------------------------
# PARAMETER GROUPS
# -------------------------


def _load_preset(preset: str) -> dict:
    """
    Lädt ein Preset aus templates/parameter_groups/<preset>.json.
    Gibt das JSON-Dict zurück oder beendet mit Exit(1) bei Fehlern.
    """
    template_path = TEMPLATES_DIR / f"{preset}.json"

    if not template_path.exists():
        console.print(
            f"[bold red]Preset '{preset}' nicht gefunden.[/bold red] "
            f"Erwartet: {template_path}"
        )
        console.print("Verfügbare Presets:")
        _list_presets()
        raise typer.Exit(1)

    try:
        with template_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        console.print(f"[bold red]Fehler beim Lesen von {template_path}[/bold red]")
        console.print(str(e))
        raise typer.Exit(1)

    return data


def _print_preset_table(name: str, data: dict) -> None:
    """
    Schöne Ausgabe eines einzelnen Presets als Tabelle.
    """
    desc = data.get("description", "")
    engine = data.get("engine", "unknown")
    engine_version = data.get("engine_version", "unknown")
    params: dict = data.get("parameters", {})

    console.rule(f"[bold cyan]Preset: {name}[/bold cyan]")
    console.print(f"[bold]Beschreibung:[/bold] {desc}")
    console.print(f"[bold]Engine:[/bold] {engine} (Version {engine_version})")
    console.print()

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Parameter")
    table.add_column("Wert")

    for key, value in params.items():
        table.add_row(key, str(value))

    console.print(table)
    console.print(
        "[dim]Hinweis: Dieses Preset ist ein Startpunkt. "
        "Feintuning pro Projekt bleibt nötig.[/dim]"
    )


def _diff_presets(preset_a: str, preset_b: str) -> None:
    """
    Vergleicht zwei Presets und zeigt Unterschiede / Gemeinsamkeiten.
    """
    data_a = _load_preset(preset_a)
    data_b = _load_preset(preset_b)

    params_a: dict = data_a.get("parameters", {})
    params_b: dict = data_b.get("parameters", {})

    console.rule(
        f"[bold magenta]Preset-Diff[/bold magenta] [bold]{preset_a}[/bold] ↔ [bold]{preset_b}[/bold]"
    )

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Parameter")
    table.add_column(preset_a)
    table.add_column(preset_b)
    table.add_column("Status")

    all_keys = sorted(set(params_a.keys()) | set(params_b.keys()))

    for key in all_keys:
        val_a = params_a.get(key)
        val_b = params_b.get(key)

        if key in params_a and key in params_b:
            if str(val_a) == str(val_b):
                status = "[green]SAME[/green]"
            else:
                status = "[yellow]DIFFERENT[/yellow]"
        elif key in params_a:
            status = f"[red]ONLY_IN_{preset_a}[/red]"
        else:
            status = f"[red]ONLY_IN_{preset_b}[/red]"

        table.add_row(
            key,
            "" if val_a is None else str(val_a),
            "" if val_b is None else str(val_b),
            status,
        )

    console.print(table)
    console.print(
        "[dim]Tipp: DIFFERENT/ONLY_IN_* Parameter gezielt prüfen und bewusst entscheiden.[/dim]"
    )


def _list_presets() -> None:
    """
    Verfügbare JSON-Presets aus templates/parameter_groups auflisten.
    """
    if not TEMPLATES_DIR.exists():
        console.print(
            f"[bold red]Template-Verzeichnis existiert nicht:[/bold red] {TEMPLATES_DIR}"
        )
        return

    presets = sorted(p.stem for p in TEMPLATES_DIR.glob("*.json"))
    if not presets:
        console.print("[yellow]Keine Presets gefunden.[/yellow]")
        return

    console.print("[bold]Verfügbare Presets:[/bold]")
    for p in presets:
        console.print(f"  - {p}")


def _export_aws(params: dict) -> None:
    """
    Export der Parameter in ein aws rds modify-db-parameter-group Snippet.
    """
    console.rule("[bold green]AWS-CLI Export[/bold green]")
    parts = []
    for key, value in params.items():
        parts.append(
            f"ParameterName={key},ParameterValue='{value}',ApplyMethod=pending-reboot"
        )

    cli_param_string = " ".join(f'"{p}"' for p in parts)

    console.print("[bold]Beispielaufruf:[/bold]")
    console.print("aws rds modify-db-parameter-group \\")
    console.print("  --db-parameter-group-name <DEIN-PG-NAME> \\")
    console.print(f"  --parameters {cli_param_string}")
    console.print()
    console.print(
        "[dim]Hinweis: Passe Parametergruppe und ggf. ApplyMethod pro Umgebung an.[/dim]"
    )


@app.command()
def pg(
    preset: str = typer.Option(
        "oracle_oltp",
        "--preset",
        "-p",
        help="Name des Parameter-Group-Presets (z.B. oracle_oltp).",
    ),
    list_only: bool = typer.Option(
        False,
        "--list",
        "-l",
        help="Nur verfügbare Presets auflisten, nichts laden.",
    ),
    export: str = typer.Option(
        None,
        "--export",
        "-e",
        help="Export-Format, z.B. 'aws' für AWS-CLI Parameter.",
    ),
    diff: Optional[str] = typer.Option(
        None,
        "--diff",
        help="Zwei Presets zum Vergleich, z.B. 'oracle_oltp,highload'.",
    ),
):
    """
    Parameter-Group-Generator:
    - Auflisten von Presets (--list)
    - Anzeige eines Presets (--preset)
    - Export (z.B. --export aws)
    - Diff zwischen zwei Presets (--diff presetA,presetB)
    """

    if list_only:
        _list_presets()
        raise typer.Exit(0)

    if diff:
        # diff hat Priorität gegenüber preset/export
        try:
            a, b = [s.strip() for s in diff.split(",", 1)]
        except ValueError:
            console.print(
                "[bold red]Ungültiges Format für --diff.[/bold red] "
                "Erwartet: z.B. --diff oracle_oltp,highload"
            )
            raise typer.Exit(1)

        _diff_presets(a, b)
        raise typer.Exit(0)

    # Einzelnes Preset laden
    data = _load_preset(preset)
    _print_preset_table(preset, data)

    params: dict = data.get("parameters", {})

    # Export-Handling
    if export:
        export = export.lower().strip()
        if export == "aws":
            _export_aws(params)
        else:
            console.print(
                f"[yellow]Unbekanntes Export-Format '{export}'. "
                "Unterstützt aktuell: 'aws'.[/yellow]"
            )


# -------------------------
# DEPLOY: DRY-RUN + PLAN + AWS VALIDATE
# -------------------------


def _load_env_file(path: Path) -> Dict[str, str]:
    """
    Sehr einfache .env-Parser-Logik:
    - ignoriert leere Zeilen & Kommentare
    - key=value pro Zeile
    """
    if not path.exists():
        raise FileNotFoundError(f"Config-Datei nicht gefunden: {path}")

    data: Dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        data[key.strip()] = value.strip()
    return data


def _validate_config(cfg: Dict[str, str]) -> Dict[str, str]:
    """
    Validiert die wichtigsten Felder aus der ENV-Config.
    Gibt ein Dict mit Fehlern zurück: key -> Fehlermeldung.
    """
    errors: Dict[str, str] = {}

    required_keys = [
        "AWS_PROFILE",
        "AWS_REGION",
        "DB_IDENTIFIER",
        "DB_ENGINE",
        "DB_ENGINE_VERSION",
        "DB_INSTANCE_CLASS",
        "DB_STORAGE_GB",
        "DB_NAME",
        "DB_MASTER_USERNAME",
    ]

    for key in required_keys:
        if not cfg.get(key):
            errors[key] = "Pflichtfeld fehlt oder ist leer."

    # einfache Typprüfungen
    int_fields = ["DB_STORAGE_GB", "BACKUP_RETENTION_DAYS"]
    for key in int_fields:
        if key in cfg and cfg[key]:
            try:
                int(cfg[key])
            except ValueError:
                errors[key] = f"Wert '{cfg[key]}' ist keine gültige Ganzzahl."

    # Booleans als Strings
    bool_fields = ["DB_MULTI_AZ", "DB_PUBLIC_ACCESS", "DB_STORAGE_ENCRYPTED"]
    valid_bool = {"true", "false", "True", "False", "1", "0"}
    for key in bool_fields:
        val = cfg.get(key)
        if val is not None and val != "" and val not in valid_bool:
            errors[key] = f"Wert '{val}' ist kein gültiger Bool (erwartet: true/false/1/0)."

    return errors


def _build_plan(cfg: Dict[str, str]) -> Dict[str, object]:
    """
    Baut ein Plan-Objekt, das später z.B. als JSON exportiert werden kann.
    """
    sg_list = [s.strip() for s in cfg.get("DB_SECURITY_GROUPS", "").split(",") if s.strip()]

    cluster_identifier = cfg.get("DB_CLUSTER_IDENTIFIER") or cfg.get("DB_IDENTIFIER")

    plan = {
        "aws": {
            "profile": cfg.get("AWS_PROFILE", "default"),
            "region": cfg.get("AWS_REGION", "eu-central-1"),
        },
        "db": {
            "identifier": cfg.get("DB_IDENTIFIER"),
            "cluster_identifier": cluster_identifier,
            "engine": cfg.get("DB_ENGINE", "aurora-postgresql"),
            "engine_version": cfg.get("DB_ENGINE_VERSION", "15.4"),
            "instance_class": cfg.get("DB_INSTANCE_CLASS", "db.r6g.large"),
            "storage_gb": int(cfg.get("DB_STORAGE_GB", "100")),
            "name": cfg.get("DB_NAME", "appdb"),
            "master_username": cfg.get("DB_MASTER_USERNAME", "appuser"),
            "multi_az": cfg.get("DB_MULTI_AZ", "true"),
            "public_access": cfg.get("DB_PUBLIC_ACCESS", "false"),
            "encrypted": cfg.get("DB_STORAGE_ENCRYPTED", "true"),
        },
        "network": {
            "subnet_group": cfg.get("DB_SUBNET_GROUP", ""),
            "security_groups": sg_list,
        },
        "parameterization": {
            "parameter_group": cfg.get("DB_PARAMETER_GROUP", ""),
            "option_group": cfg.get("DB_OPTION_GROUP", ""),
        },
        "maintenance": {
            "backup_retention_days": int(cfg.get("BACKUP_RETENTION_DAYS", "7")),
            "backup_window": cfg.get("BACKUP_WINDOW", "02:00-03:00"),
            "maintenance_window": cfg.get("MAINTENANCE_WINDOW", "Sun:03:00-Sun:04:00"),
        },
    }
    return plan


def _validate_with_aws(plan: dict) -> None:
    """
    Validiert den Plan gegen AWS (nur READ-Calls).
    - Prüft Subnet Group + AZ-Verteilung
    - Prüft Parameter Group
    - Prüft, ob Instance-/Cluster-Identifier bereits existieren
    - Prüft Security Groups
    - Prüft Engine + Version
    - Prüft Instance Class (orderable options)
    """
    try:
        import boto3
        from botocore.exceptions import BotoCoreError, ClientError
    except ImportError:
        console.print(
            "[bold red]boto3/botocore nicht installiert.[/bold red] "
            "Bitte mit 'pip install boto3' nachinstallieren."
        )
        raise typer.Exit(1)

    aws = plan["aws"]
    db = plan["db"]
    net = plan["network"]
    param = plan["parameterization"]

    profile = aws["profile"]
    region = aws["region"]

    console.print()
    console.rule("[bold cyan]AWS Validate[/bold cyan]")
    console.print(f"[bold]Profil:[/bold] {profile}, [bold]Region:[/bold] {region}")

    try:
        session = boto3.Session(profile_name=profile, region_name=region)
        rds = session.client("rds")
        ec2 = session.client("ec2")
    except Exception as e:
        console.print(f"[bold red]Fehler beim Erstellen der AWS-Clients:[/bold red] {e}")
        raise typer.Exit(1)

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Check")
    table.add_column("Status")
    table.add_column("Details")

    def ok(check: str, msg: str) -> None:
        table.add_row(check, "[green]OK[/green]", msg)

    def warn(check: str, msg: str) -> None:
        table.add_row(check, "[yellow]WARN[/yellow]", msg)

    def err(check: str, msg: str) -> None:
        table.add_row(check, "[red]ERROR[/red]", msg)

    # --- Subnet Group + AZ-Verteilung ---
    subnet = net.get("subnet_group") or ""
    if subnet:
        try:
            resp = rds.describe_db_subnet_groups(DBSubnetGroupName=subnet)
            groups = resp.get("DBSubnetGroups", [])
            if not groups:
                err("DB Subnet Group", f"{subnet} nicht gefunden.")
            else:
                ok("DB Subnet Group", f"{subnet} gefunden.")
                subnets = groups[0].get("Subnets", [])
                azs = {
                    s.get("SubnetAvailabilityZone", {}).get("Name")
                    for s in subnets
                    if s.get("SubnetAvailabilityZone")
                }
                azs = {a for a in azs if a}
                if len(azs) >= 2:
                    ok("Subnet AZ Spread", f"Subnets in {len(azs)} AZs: {', '.join(sorted(azs))}")
                elif len(azs) == 1:
                    warn(
                        "Subnet AZ Spread",
                        f"Alle Subnets in nur einer AZ: {', '.join(sorted(azs))}. "
                        "Für Produktions-Workloads meist nicht empfohlen.",
                    )
                else:
                    warn("Subnet AZ Spread", "Keine AZ-Informationen gefunden.")
        except ClientError as ce:
            code = ce.response.get("Error", {}).get("Code", "")
            if code == "DBSubnetGroupNotFoundFault":
                err("DB Subnet Group", f"{subnet} nicht gefunden.")
            else:
                err("DB Subnet Group", f"ClientError: {code}")
        except (BotoCoreError, Exception) as e:
            err("DB Subnet Group", f"Fehler: {e}")
    else:
        warn("DB Subnet Group", "Kein Subnet Group Name konfiguriert.")

    # --- Parameter Group ---
    pg_name = param.get("parameter_group") or ""
    if pg_name:
        try:
            rds.describe_db_parameter_groups(DBParameterGroupName=pg_name)
            ok("DB Parameter Group", f"{pg_name} gefunden.")
        except ClientError as ce:
            code = ce.response.get("Error", {}).get("Code", "")
            if code == "DBParameterGroupNotFoundFault":
                err("DB Parameter Group", f"{pg_name} nicht gefunden.")
            else:
                err("DB Parameter Group", f"ClientError: {code}")
        except (BotoCoreError, Exception) as e:
            err("DB Parameter Group", f"Fehler: {e}")
    else:
        warn("DB Parameter Group", "Kein Parameter Group Name konfiguriert.")

    # --- DB Identifier + Cluster Identifier (existieren schon?) ---
    identifier = db.get("identifier")
    cluster_identifier = db.get("cluster_identifier") or identifier
    engine = db.get("engine") or ""

    if identifier:
        exists_instance = False
        exists_cluster = False
        details_parts: List[str] = []

        # Instanz prüfen
        try:
            resp = rds.describe_db_instances(DBInstanceIdentifier=identifier)
            instances = resp.get("DBInstances", [])
            if instances:
                exists_instance = True
                details_parts.append("als DB Instance")
        except ClientError as ce:
            code = ce.response.get("Error", {}).get("Code", "")
            if code not in ("DBInstanceNotFound", "DBInstanceNotFoundFault"):
                warn("DB Identifier", f"ClientError bei Instance-Check: {code}")
        except (BotoCoreError, Exception) as e:
            warn("DB Identifier", f"Fehler bei Instance-Check: {e}")

        # Cluster anhand cluster_identifier prüfen
        try:
            resp_c = rds.describe_db_clusters(DBClusterIdentifier=cluster_identifier)
            clusters = resp_c.get("DBClusters", [])
            if clusters:
                exists_cluster = True
                details_parts.append(f"als DB Cluster (Identifier: {cluster_identifier})")
        except ClientError as ce:
            code = ce.response.get("Error", {}).get("Code", "")
            if code not in ("DBClusterNotFoundFault",):
                warn("DB Identifier", f"ClientError bei Cluster-Check: {code}")
        except (BotoCoreError, Exception) as e:
            warn("DB Identifier", f"Fehler bei Cluster-Check: {e}")

        if exists_instance or exists_cluster:
            where = " und ".join(details_parts)
            err(
                "DB Identifier",
                f"Identifier '{identifier}' bzw. ClusterIdentifier '{cluster_identifier}' "
                f"existiert bereits ({where}). Deployment würde scheitern – andere Namen wählen.",
            )
        else:
            ok(
                "DB Identifier",
                f"{identifier} / {cluster_identifier} sind frei (weder Instance noch Cluster gefunden).",
            )

        # Spezieller Hinweis für Aurora-Engines
        if engine.startswith("aurora"):
            if identifier == cluster_identifier:
                warn(
                    "Aurora Identifier Design",
                    "Instance- und Cluster-Identifier sind identisch. AWS erlaubt das, "
                    "üblich ist aber eine Trennung wie 'myapp-cluster' / 'myapp-instance-1'.",
                )
            else:
                ok(
                    "Aurora Identifier Design",
                    f"Instance-Identifier ({identifier}) und Cluster-Identifier ({cluster_identifier}) "
                    "sind getrennt – gut für Klarheit und Betrieb.",
                )
    else:
        warn("DB Identifier", "Kein DB_IDENTIFIER konfiguriert.")

    # --- Security Groups ---
    sg_ids = net.get("security_groups") or []
    if sg_ids:
        missing = []
        for sg in sg_ids:
            try:
                ec2.describe_security_groups(GroupIds=[sg])
            except ClientError as ce:
                code = ce.response.get("Error", {}).get("Code", "")
                if code in ("InvalidGroup.NotFound", "InvalidGroupId.Malformed"):
                    missing.append(sg)
                else:
                    warn("Security Groups", f"ClientError für {sg}: {code}")
            except (BotoCoreError, Exception) as e:
                warn("Security Groups", f"Fehler für {sg}: {e}")
        if missing:
            err("Security Groups", f"Folgende Security Groups existieren nicht: {', '.join(missing)}")
        else:
            ok("Security Groups", f"Alle Security Groups gefunden: {', '.join(sg_ids)}")
    else:
        warn("Security Groups", "Keine Security Groups konfiguriert.")

    # --- Engine + Engine Version ---
    engine_version = db.get("engine_version")
    try:
        resp = rds.describe_db_engine_versions(
            Engine=engine,
            EngineVersion=engine_version,
            MaxRecords=20,
        )
        if resp.get("DBEngineVersions"):
            ok(
                "Engine/Version",
                f"{engine} {engine_version} in Region {region} verfügbar.",
            )
        else:
            err(
                "Engine/Version",
                f"{engine} {engine_version} in Region {region} nicht gefunden.",
            )
    except ClientError as ce:
        code = ce.response.get("Error", {}).get("Code", "")
        err("Engine/Version", f"ClientError: {code}")
    except (BotoCoreError, Exception) as e:
        err("Engine/Version", f"Fehler: {e}")

    # --- Instance Class ---
    instance_class = db.get("instance_class")
    try:
        opts = rds.describe_orderable_db_instance_options(
            Engine=engine,
            EngineVersion=engine_version,
            MaxRecords=50,
        )
        classes = {o["DBInstanceClass"] for o in opts.get("OrderableDBInstanceOptions", [])}
        if instance_class in classes:
            ok("Instance Class", f"{instance_class} ist für {engine} {engine_version} bestellbar.")
        else:
            warn(
                "Instance Class",
                f"{instance_class} wurde in den Orderable Options nicht gefunden. Bitte manuell prüfen.",
            )
    except ClientError as ce:
        code = ce.response.get("Error", {}).get("Code", "")
        warn("Instance Class", f"ClientError bei Orderable Options: {code}")
    except (BotoCoreError, Exception) as e:
        warn("Instance Class", f"Fehler bei Orderable Options: {e}")

    console.print()
    console.print(table)
    console.print(
        "[dim]Hinweis: validate führt nur READ-Calls aus und nimmt keine Änderungen in AWS vor.[/dim]"
    )


@app.command()
def deploy(
    config: Path = typer.Option(
        CONFIGS_DIR / "sample.env",
        "--config",
        "-c",
        help="Pfad zur Config-Datei (.env-Format).",
    ),
    dry_run: bool = typer.Option(
        True,
        "--dry-run/--no-dry-run",
        help="Nur anzeigen, was erstellt würde (Standard: --dry-run).",
    ),
    out: Optional[Path] = typer.Option(
        None,
        "--out",
        "-o",
        help="Optional: Pfad für JSON-Export des Deployment-Plans.",
    ),
    validate: bool = typer.Option(
        False,
        "--validate",
        help="Plan gegen AWS validieren (nur READ-Calls, kein Deployment).",
    ),
):
    """
    Deployment-Dry-Run:
    Liest eine .env-Konfiguration, validiert sie und zeigt an,
    wie ein RDS/Aurora-Cluster angelegt würde.
    Optional:
      - JSON-Plan exportieren (--out plan.json)
      - Plan gegen AWS validieren (--validate)
    """
    console.rule("[bold green]RDS Deploy – Dry Run[/bold green]")

    try:
        cfg = _load_env_file(config)
    except FileNotFoundError as e:
        console.print(f"[bold red]{e}[/bold red]")
        raise typer.Exit(1)

    errors = _validate_config(cfg)
    if errors:
        console.print("[bold red]Konfigurationsfehler:[/bold red]")
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Feld")
        table.add_column("Fehler")

        for key, msg in errors.items():
            table.add_row(key, msg)

        console.print(table)
        console.print(
            "[yellow]Bitte Config korrigieren, bevor ein echtes Deployment durchgeführt wird.[/yellow]"
        )
        raise typer.Exit(1)

    plan = _build_plan(cfg)

    aws = plan["aws"]
    db = plan["db"]
    net = plan["network"]
    param = plan["parameterization"]
    maint = plan["maintenance"]

    console.print(f"[bold]AWS Profile:[/bold] {aws['profile']}")
    console.print(f"[bold]Region:[/bold] {aws['region']}")
    console.print()

    info = Table(show_header=True, header_style="bold magenta")
    info.add_column("Feld")
    info.add_column("Wert")

    info.add_row("DB Identifier", str(db["identifier"]))
    info.add_row("Cluster Identifier", str(db.get("cluster_identifier") or ""))
    info.add_row("Engine", str(db["engine"]))
    info.add_row("Engine Version", str(db["engine_version"]))
    info.add_row("Instance Class", str(db["instance_class"]))
    info.add_row("Storage (GB)", str(db["storage_gb"]))
    info.add_row("DB Name", str(db["name"]))
    info.add_row("Master User", str(db["master_username"]))
    info.add_row("Multi-AZ", str(db["multi_az"]))
    info.add_row("Public Access", str(db["public_access"]))
    info.add_row("Encrypted", str(db["encrypted"]))
    info.add_row("Parameter Group", param["parameter_group"] or "<none>")
    info.add_row("Option Group", param["option_group"] or "<none>")
    info.add_row("Subnet Group", net["subnet_group"] or "<none>")
    info.add_row(
        "Security Groups", ", ".join(net["security_groups"]) if net["security_groups"] else "<none>"
    )
    info.add_row("Backup Retention (Tage)", str(maint["backup_retention_days"]))
    info.add_row("Backup Window", maint["backup_window"])
    info.add_row("Maintenance Window", maint["maintenance_window"])

    console.print(info)

    # Optionaler JSON-Export
    if out is not None:
        try:
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(plan, indent=2), encoding="utf-8")
            console.print()
            console.print(f"[bold green]Plan nach[/bold green] {out} [bold green]geschrieben.[/bold green]")
        except Exception as e:
            console.print(f"[bold red]Fehler beim Schreiben der Plan-Datei:[/bold red] {e}")
            raise typer.Exit(1)

    # AWS-Validierung (READ-Only)
    if validate:
        _validate_with_aws(plan)

    if dry_run:
        console.print()
        console.print(
            "[dim]Dry-Run: Es werden keine AWS-Calls ausgeführt. "
            "Mit --validate werden nur READ-Calls zur Prüfung der Umgebung ausgeführt.[/dim]"
        )
    else:
        console.print()
        console.print(
            "[bold yellow]WARNUNG:[/bold yellow] "
            "Echte Deploy-Logik ist noch nicht implementiert."
        )
        console.print(
            "[dim]Hier würde später der boto3-Aufruf für create-db-cluster/-instance stehen.[/dim]"
        )


# -------------------------
# READINESS
# -------------------------


@app.command()
def readiness(
    source: Optional[Path] = typer.Option(
        None,
        "--source",
        "-s",
        help="Optionale Quelle (z.B. Export/DDL-Datei) für spätere Analysen.",
    ),
    export: Optional[Path] = typer.Option(
        None,
        "--export",
        "-e",
        help="Optionaler HTML-Export der Readiness-Checks (z.B. reports/readiness.html).",
    ),
):
    """
    Dummy-Migration-Readiness-Scanner:
    Zeigt typische Oracle→Postgres-Risiken als Checkliste.
    Optional: Export als HTML-Report (--export).
    """

    console.rule("[bold magenta]Migration Readiness – Oracle → PostgreSQL[/bold magenta]")

    if source:
        console.print(f"[bold]Quelle:[/bold] {source}")
        console.print(
            "[dim]Hinweis: Inhalt der Quelle wird in dieser Version noch nicht analysiert.[/dim]"
        )
        console.print()

    checks = [
        {
            "id": "DATATYPE_NUMERIC_PRECISION",
            "severity": "HIGH",
            "status": "CHECK_MANUALLY",
            "details": "Oracle NUMBER vs. PostgreSQL numeric – Präzision/Skala prüfen.",
        },
        {
            "id": "DATATYPE_DATE_TIMESTAMP",
            "severity": "MEDIUM",
            "status": "CHECK_MANUALLY",
            "details": "Oracle DATE vs. TIMESTAMP WITH/WITHOUT TIME ZONE prüfen.",
        },
        {
            "id": "PARTITIONING_STRATEGY",
            "severity": "HIGH",
            "status": "CHECK_MANUALLY",
            "details": "Oracle-Partitionierung vs. PostgreSQL-Partitionierung abgleichen.",
        },
        {
            "id": "SEQUENCES_IDENTITY",
            "severity": "MEDIUM",
            "status": "CHECK_MANUALLY",
            "details": "SEQUENCES, IDENTITY-Spalten, SERIAL-Verhalten prüfen.",
        },
        {
            "id": "PLSQL_FUNCTIONS",
            "severity": "HIGH",
            "status": "CHECK_MANUALLY",
            "details": "PL/SQL-Logik und Portierung nach PL/pgSQL / andere Schichten.",
        },
        {
            "id": "NLS_COLLATION",
            "severity": "HIGH",
            "status": "CHECK_MANUALLY",
            "details": "NLS / Collation / Sortierreihenfolge prüfen.",
        },
        {
            "id": "INDEX_STRATEGY",
            "severity": "MEDIUM",
            "status": "CHECK_MANUALLY",
            "details": "Oracle-Indexe vs. B-Tree/GIN/GiST in PostgreSQL.",
        },
        {
            "id": "BULK_LOAD_STRATEGY",
            "severity": "MEDIUM",
            "status": "OK",
            "details": "Bulk-Load kann mit 'oracle_migration'-Preset unterstützt werden.",
        },
        {
            "id": "CONSTRAINTS_TRIGGERS",
            "severity": "MEDIUM",
            "status": "CHECK_MANUALLY",
            "details": "Constraints/Triggers und referentielle Integrität prüfen.",
        },
    ]

    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Check-ID")
    table.add_column("Severity")
    table.add_column("Status")
    table.add_column("Details")

    for c in checks:
        sev = c["severity"]
        status = c["status"]

        if sev == "HIGH":
            sev_str = "[bold red]HIGH[/bold red]"
        elif sev == "MEDIUM":
            sev_str = "[yellow]MEDIUM[/yellow]"
        else:
            sev_str = sev

        if status == "OK":
            status_str = "[green]OK[/green]"
        elif status == "CHECK_MANUALLY":
            status_str = "[yellow]CHECK_MANUALLY[/yellow]"
        else:
            status_str = status

        table.add_row(c["id"], sev_str, status_str, c["details"])

    console.print(table)
    console.print()
    console.print(
        "[dim]Diese Checks sind ein Dummy-Gerüst. "
        "Später können hier echte Analysen von DDL/Exports integriert werden.[/dim]"
    )

    if export is not None:
        _export_readiness_html(checks, source, export)


def _export_readiness_html(checks: list, source: Optional[Path], out: Path) -> None:
    """
    Schreibt einen einfachen HTML-Report mit Tabelle der Readiness-Checks.
    """
    out.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    for c in checks:
        rows.append(
            f"<tr>"
            f"<td>{c['id']}</td>"
            f"<td>{c['severity']}</td>"
            f"<td>{c['status']}</td>"
            f"<td>{c['details']}</td>"
            f"</tr>"
        )

    source_info = (
        f"<p><strong>Quelle:</strong> {source}</p>" if source is not None else ""
    )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Migration Readiness – Oracle to PostgreSQL</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 2rem; }}
    h1 {{ margin-bottom: 0.2rem; }}
    table {{ border-collapse: collapse; width: 100%; margin-top: 1rem; }}
    th, td {{ border: 1px solid #ccc; padding: 0.4rem 0.6rem; text-align: left; }}
    th {{ background-color: #f4f4f4; }}
    .high {{ color: #b60205; font-weight: bold; }}
    .medium {{ color: #d28b00; font-weight: bold; }}
    .ok {{ color: #22863a; font-weight: bold; }}
  </style>
</head>
<body>
  <h1>Migration Readiness – Oracle → PostgreSQL</h1>
  {source_info}
  <p>Diese Übersicht zeigt typische Migrationsrisiken und Prüfbereiche.</p>
  <table>
    <thead>
      <tr>
        <th>Check-ID</th>
        <th>Severity</th>
        <th>Status</th>
        <th>Details</th>
      </tr>
    </thead>
    <tbody>
      {''.join(rows)}
    </tbody>
  </table>
</body>
</html>
"""

    out.write_text(html, encoding="utf-8")
    console.print()
    console.print(f"[bold green]HTML-Report nach[/bold green] {out} [bold green]geschrieben.[/bold green]")


if __name__ == "__main__":
    app()
