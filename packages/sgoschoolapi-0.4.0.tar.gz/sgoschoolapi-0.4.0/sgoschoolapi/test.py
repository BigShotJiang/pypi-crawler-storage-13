import asyncio
import os
import sys
from datetime import datetime

# Добавляем путь к папке netschoolapi для импорта
sys.path.append(os.path.join(os.path.dirname(__file__), 'netschoolapi'))

from netschoolapi import NetSchoolAPI

async def main():
    config = {
        'url': 'https://sgo.edu-74.ru/',
        'login': 'ЮдинЯ',
        'password': '2409Наталья2010',
        'school': 'МОУ "СОШ № 25 при МаГК" г. Магнитогорска'
    }
    
    print("🚀 Тест NetSchool API с весом оценок")
    print("=" * 60)
    
    async with NetSchoolAPI(config['url']) as api:
        try:
            print("🔐 Вход...")
            await api.login(config['login'], config['password'], config['school'])
            print("✅ Успешный вход!")
            
            # Получаем дневник за ноябрь 2025
            start_date = datetime(2025, 11, 1).date()
            end_date = datetime(2025, 11, 30).date()
            
            print(f"\n📖 Получение оценок с весом за ноябрь 2025...")
            
            # Используем новый метод для получения оценок с весом
            marks_with_weight = await api.get_marks_with_weight(start=start_date, end=end_date)
            
            print(f"\n🎯 ОЦЕНКИ С ВЕСОМ ЗА 06.11.2025:")
            print("=" * 70)
            
            found_marks = 0
            for mark in marks_with_weight:
                # Проверяем строку даты
                if mark['date'].startswith('2025-11-06'):
                    found_marks += 1
                    print(f"\n📚 {mark['subject']}:")
                    print(f"   📝 {mark['assignment_name']}")
                    print(f"   ⭐ Оценка: {mark['mark']}")
                    print(f"   ⚖️  Вес: {mark['weight']}")
                    print(f"   🏷️  Тип: {mark.get('type_name', '')}")
                    
                    if mark.get('comment'):
                        print(f"   💬 Комментарий: {mark['comment']}")
            
            print(f"\n📊 ИТОГО: Найдено {found_marks} оценок с весом за 06.11.2025")
            
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            import traceback
            traceback.print_exc()
        
        finally:
            print("\n👋 Выход из системы...")
            await api.logout()
            print("✅ Успешный выход!")

if __name__ == "__main__":
    asyncio.run(main())