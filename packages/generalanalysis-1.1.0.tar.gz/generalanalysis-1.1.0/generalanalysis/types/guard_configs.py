"""Guard configuration type definitions and helpers."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field, field_validator


class PolicyConfig(BaseModel):
    """Represents a policy entry inside a guard configuration."""

    policy: str
    sensitivity: float = Field(0.0, ge=0.0, le=1.0)

    @field_validator("policy")
    @classmethod
    def _validate_policy(cls, value: str) -> str:
        cleaned = (value or "").strip()
        if not cleaned:
            raise ValueError("policy name cannot be empty")
        return cleaned


class GuardPolicyGroup(BaseModel):
    """Policies that belong to a single guard."""

    guard_name: str
    policies: list[PolicyConfig] = Field(default_factory=list)

    @field_validator("guard_name")
    @classmethod
    def _validate_guard_name(cls, value: str) -> str:
        cleaned = (value or "").strip()
        if not cleaned:
            raise ValueError("guard_name cannot be empty")
        return cleaned


class GuardConfigurationConfig(BaseModel):
    """Top-level configuration wrapper sent to the Guardrails service."""

    guards: list[GuardPolicyGroup] = Field(default_factory=list)


class GuardConfigurationRecord(BaseModel):
    """Represents a stored guard configuration on the Guardrails service."""

    id: int
    name: str
    project_id: int | None = None
    config: GuardConfigurationConfig = Field(default_factory=GuardConfigurationConfig)
    created_at: str | None = None
    updated_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return self.model_dump()

    def to_json(self, **kwargs: Any) -> str:
        """Convert to JSON string."""
        return self.model_dump_json(**kwargs)


class GuardConfigurationBuilder:
    """Convenience helper for building GuardConfigurationConfig objects."""

    def __init__(self) -> None:
        self._guard_map: dict[str, GuardPolicyGroup] = {}

    def add_policy(
        self,
        guard_name: str,
        *,
        policy: str,
        sensitivity: float = 0.0,
    ) -> GuardConfigurationBuilder:
        """Add a policy by name for an existing guard on the Guardrails service."""

        guard_key = guard_name.strip()
        if not guard_key:
            raise ValueError("guard_name cannot be empty")

        new_policy = PolicyConfig(policy=policy, sensitivity=sensitivity)

        group = self._guard_map.get(guard_key)
        if group is None:
            group = GuardPolicyGroup(guard_name=guard_key, policies=[])
            self._guard_map[guard_key] = group

        # Merge sensitivities when the same policy is added repeatedly; choose the stricter threshold
        norm_new = new_policy.policy.lower()
        for existing in group.policies:
            if existing.policy.lower() == norm_new:
                existing.sensitivity = min(existing.sensitivity, new_policy.sensitivity)
                break
        else:
            group.policies.append(new_policy)
        return self

    def build(self) -> GuardConfigurationConfig:
        """Return a GuardConfigurationConfig with the accumulated groups."""

        return GuardConfigurationConfig(guards=list(self._guard_map.values()))
