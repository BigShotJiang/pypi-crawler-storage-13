from __future__ import annotations
from os.path import exists

from nervels.parser import Parser
from nervels.compiler import Compiler
from nervels.parser import Document

from chromakitx import ColorFormattable

def compile_nls(path: str) -> tuple[str, str, list[ColorFormattable], ColorFormattable, ColorFormattable]:
    path: str = path + '.nls'

    if not exists(path):
        raise FileNotFoundError("File " + path + " does not exist")

    with open(file=path, encoding="utf-8") as file:
        content: str = file.read()

    parser: Parser = Parser(content)
    document: Document = parser.parse()
    compiler: Compiler = Compiler(document)

    return compiler.compile()

__all__: list[str] = ['compile_nls']
