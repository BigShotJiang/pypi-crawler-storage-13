from __future__ import annotations
from re import (Match, match as _match)

from nervels.nodes import ColorNode
from nervels.document import Document
from nervels.utils import is_color

class Parser:
    def __init__(self, content: str) -> None:
        self.lines: list[str] = content.splitlines()
        self.position: int = 0

    def parse(self) -> Document:
        properties: dict[str, str | ColorNode] = {}
        sections: dict[str, list[str]] = {}

        while self.position < len(self.lines):
            raw: str = self.lines[self.position].strip()
            self.position += 1

            if not raw or raw.startswith("#"):
                continue

            if raw == "{":
                self._parse_root_block(properties, sections)
                break

        return Document(properties=properties, sections=sections)

    def _parse_root_block(self, properties: dict[str, str | ColorNode], sections: dict[str, list[str]]) -> None:
        while self.position < len(self.lines):
            raw: str = self.lines[self.position].strip()
            self.position += 1

            if not raw or raw.startswith("#"):
                continue

            if raw == "}":
                break

            prop_match: Match[str] | None = _match(pattern=r'^([\w\-]+)\s+"(.+)"$', string=raw)

            if prop_match:
                (key, value) = prop_match[1], prop_match[2]
                properties[key] = ColorNode.parse(value) if is_color(value) else value

                continue

            section_match: Match[str] | None = _match(pattern=r"^([\w\-]+)\s*\{\s*(?:#.*)?$", string=raw)

            if section_match:
                name: str = section_match[1]
                sections[name] = self._collect_section()

    def _collect_section(self) -> list[str]:
        raw_lines: list[str] = []

        while self.position < len(self.lines):
            current:  str = self.lines[self.position]
            stripped: str = current.strip()

            if stripped == "}":
                self.position += 1
                break

            if stripped.startswith("#"):
                self.position += 1
                continue

            raw_lines.append(current)
            self.position += 1

        if not raw_lines:
            return []

        indented:   list[str] = [l for l in raw_lines if l.strip()]
        normalized: list[str] = []

        min_indent: int = min(len(l) - len(l.lstrip()) for l in indented) if indented else 0

        for line in raw_lines:
            normalized.append(((" " * ((len(line) - len(line.lstrip())) - min_indent)) + line.lstrip()) if line.strip() else "")

        return normalized
