from __future__ import annotations
from abc import ABC, abstractmethod
from datetime import date, datetime
import re
from typing import Any, TypeVar
from pydantic import BaseModel, GetCoreSchemaHandler
from pydantic_core import CoreSchema, core_schema

V = TypeVar("V", bound="Version")


class Version(ABC):
    @classmethod
    def __get_pydantic_core_schema__(
        cls, _source_type: Any, handler: GetCoreSchemaHandler
    ) -> CoreSchema:
        return core_schema.no_info_after_validator_function(cls, handler(str))

    @property
    @abstractmethod
    def parts(self) -> tuple[int, ...]: ...

    def __repr__(self) -> str:
        return f"{type(self).__name__}({super().__repr__()})"

    # Using functools.total_ordering to derive everything from __lt__ doesn't
    # work, as the comparison operators inherited from str keep the decorator
    # from working.

    def __lt__(self, other: Any) -> bool:
        if isinstance(other, type(self)):
            return self.parts < other.parts
        else:
            return NotImplemented  # pragma: no cover

    def __le__(self, other: Any) -> bool:
        if isinstance(other, type(self)):
            return self.parts <= other.parts
        else:
            return NotImplemented  # pragma: no cover

    def __gt__(self, other: Any) -> bool:
        if isinstance(other, type(self)):
            return self.parts > other.parts
        else:
            return NotImplemented  # pragma: no cover

    def __ge__(self, other: Any) -> bool:
        if isinstance(other, type(self)):
            return self.parts >= other.parts
        else:
            return NotImplemented  # pragma: no cover


class MajorVersion(Version, str):
    def __init__(self, s: str) -> None:
        if not re.fullmatch(r"(\d+)", s):
            raise ValueError(f"Invalid major version: {s!r}")
        self.x = int(s)

    @property
    def parts(self) -> tuple[int]:
        return (self.x,)

    @classmethod
    def construct(cls, x: int) -> MajorVersion:
        return cls(str(x))


class MinorVersion(Version, str):
    def __init__(self, s: str) -> None:
        if not re.fullmatch(r"(\d+)\.(\d+)", s):
            raise ValueError(f"Invalid minor version: {s!r}")
        x, _, y = s.partition(".")
        self.x = int(x)
        self.y = int(y)

    @property
    def parts(self) -> tuple[int, int]:
        return (self.x, self.y)

    @classmethod
    def construct(cls, x: int, y: int) -> MinorVersion:
        return cls(f"{x}.{y}")


class MicroVersion(Version, str):
    def __init__(self, s: str) -> None:
        if not re.fullmatch(r"(\d+)\.(\d+)\.(\d+)", s):
            raise ValueError(f"Invalid micro version: {s!r}")
        x, y, z = s.split(".")
        self.x = int(x)
        self.y = int(y)
        self.z = int(z)

    @property
    def parts(self) -> tuple[int, int, int]:
        return (self.x, self.y, self.z)

    @classmethod
    def construct(cls, x: int, y: int, z: int) -> MicroVersion:
        return cls(f"{x}.{y}.{z}")

    @property
    def minor(self) -> MinorVersion:
        return MinorVersion.construct(self.x, self.y)


# Union[bool, date] needs to have `bool` first so that True and False aren't
# treated as the timestamps 1 and 0.


class RawCPythonInfo(BaseModel):
    release_dates: dict[MicroVersion, bool | date]
    eol_dates: dict[MinorVersion, bool | date]


class RawPyPyInfo(BaseModel):
    release_dates: dict[MicroVersion, bool | date]
    cpython_versions: dict[MicroVersion, list[MicroVersion]]


class RawDatabase(BaseModel):
    last_modified: datetime
    cpython: RawCPythonInfo
    pypy: RawPyPyInfo
