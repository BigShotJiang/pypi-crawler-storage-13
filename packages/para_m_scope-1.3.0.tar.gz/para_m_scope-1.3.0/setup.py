from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="para-m-scope",
    version="1.3.0",
    author="TEAMBCS",
    description="Para-M-Scope: Parameter Mapping & Discovery Engine",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/TEAMBCS/Para-M-Scope",
    packages=find_packages(),

    install_requires=[
        "aiohttp",
        "rich",
	"beautifulsoup4",
	"lxml", 
   ],

    entry_points={
        "console_scripts": [
            "para-m-scope=paramscope.main:main"
        ]
    },

    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],

    python_requires=">=3.7",
)
