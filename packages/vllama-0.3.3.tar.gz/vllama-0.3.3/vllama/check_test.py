import os
import json
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, RobustScaler

def apply_transformations(metadata_path, test_file_path):
    """
    Apply saved transformations (encoding, scaling) to a test dataset.
    Save the transformed dataset as `test_transformed.csv` in the same directory as the metadata file.
    """
    # Load transformation metadata
    with open(metadata_path, "r") as f:
        metadata = json.load(f)

    # Load test data
    test_df = pd.read_csv(test_file_path)

    # Apply encoders
    encoders = {
        col: LabelEncoder().fit(classes)
        for col, classes in metadata.get("encoders", {}).items()
    }
    for col, encoder in encoders.items():
        if col in test_df.columns:
            # Handle unknown labels by mapping them to a known label or a special token if possible
            # Here we map to the first class if unknown, or stringify. 
            # Ideally, we should have a handle_unknown='ignore' or similar, but LabelEncoder doesn't support it.
            # We'll use a safe map.
            known_classes = set(encoder.classes_)
            test_df[col] = test_df[col].astype(str).map(
                lambda x: x if x in known_classes else list(known_classes)[0]
            )
            test_df[col] = encoder.transform(test_df[col])

    # Apply target encoder (if applicable)
    if metadata.get("target_encoder"):
        target_encoder = LabelEncoder()
        target_encoder.classes_ = np.array(metadata["target_encoder"])
        if "target" in test_df.columns:
             known_classes = set(target_encoder.classes_)
             test_df["target"] = test_df["target"].astype(str).map(
                lambda x: x if x in known_classes else list(known_classes)[0]
            )
             test_df["target"] = target_encoder.transform(test_df["target"])

    # Handle one-hot encoded columns
    # We need to recreate the dummies as they were in training
    # The metadata has 'one_hot_columns' which are the RESULTING columns (e.g. 'color_red', 'color_blue')
    # But we don't have the original column list in metadata to know which cols were one-hot encoded.
    # We have to infer or rely on what's in the test_df.
    # A better approach in preprocess.py would be to save which columns were OHE'd.
    # For now, we'll try to match the columns.
    
    # Identify categorical columns that might have been OHE'd (not in encoders dict)
    # This part is tricky with the current metadata. 
    # Let's assume any column in test_df that is object/categorical and NOT in encoders might need OHE.
    # OR, we just look at the 'one_hot_columns' in metadata and ensure they exist in test_df (filled with 0).
    
    # Actually, we should perform OHE on the test data first, then align.
    # But we don't know which columns to OHE from the metadata provided by the user's code.
    # The user's code just saved the *result* columns.
    # We will try to align columns directly.
    
    # 1. Get dummies for all remaining object columns
    # This is a guess because we don't know exactly which were OHE'd.
    object_cols = test_df.select_dtypes(include=['object']).columns
    if len(object_cols) > 0:
        test_df = pd.get_dummies(test_df, columns=object_cols, drop_first=True)
        # Convert boolean columns to int (0/1 instead of True/False)
        bool_cols = test_df.select_dtypes(include=['bool']).columns
        test_df[bool_cols] = test_df[bool_cols].astype(int)

    # 2. Align with metadata 'one_hot_columns' + numeric columns
    # The metadata 'one_hot_columns' seems to be "all columns that are not numeric/categorical/target"
    # which effectively means the OHE columns.
    
    expected_ohe_cols = metadata.get("one_hot_columns", [])
    
    # Add missing OHE cols with 0
    for col in expected_ohe_cols:
        if col not in test_df.columns:
            test_df[col] = 0
    
    # Convert any remaining boolean columns to int
    bool_cols = test_df.select_dtypes(include=['bool']).columns
    if len(bool_cols) > 0:
        test_df[bool_cols] = test_df[bool_cols].astype(int)
            
    # Apply scaler
    if metadata.get("scaler"):
        scaler_data = metadata["scaler"]
        center = np.array(scaler_data.get("center_", []))
        scale = np.array(scaler_data.get("scale_", []))
        feature_names = scaler_data.get("feature_names", [])
        
        if len(feature_names) > 0 and len(center) > 0:
            scaler = RobustScaler()
            scaler.center_ = center
            scaler.scale_ = scale
            # We must set unit_variance if it was default, but we don't know. Assuming default.
            
            # Check if we have all features
            missing_feats = [f for f in feature_names if f not in test_df.columns]
            if missing_feats:
                print(f"[WARNING] Missing features for scaling: {missing_feats}")
                # Add them as 0? Or skip scaling?
                # Adding as 0 is safer for shape
                for f in missing_feats:
                    test_df[f] = 0
            
            # Reorder columns to match scaler expectation
            X_scale = test_df[feature_names]
            
            # Transform
            test_df[feature_names] = scaler.transform(X_scale)
        else:
             print("[WARNING] Scaler metadata incomplete (missing center/scale or feature_names).")
    
    # Save the transformed test data
    output_dir = os.path.dirname(metadata_path)
    transformed_path = os.path.join(output_dir, "test_transformed.csv")
    test_df.to_csv(transformed_path, index=False)

    print(f"\n[SUCCESS] Transformed test file saved at: {transformed_path}")

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("TEST DATA TRANSFORMATION")
    print("=" * 80 + "\n")

    metadata_path = input("Enter the path to the transformation metadata file: ").strip()
    if not os.path.exists(metadata_path):
        print(f"\n[ERROR] Metadata file not found: {metadata_path}")
        exit(1)

    test_file_path = input("Enter the path to the test data file: ").strip()
    if not os.path.exists(test_file_path):
        print(f"\n[ERROR] Test data file not found: {test_file_path}")
        exit(1)

    try:
        apply_transformations(metadata_path, test_file_path)
    except Exception as e:
        print(f"\n[ERROR] Failed to transform test data: {e}")
        import traceback
        traceback.print_exc()