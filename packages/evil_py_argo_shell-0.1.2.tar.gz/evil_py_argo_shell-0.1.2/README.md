# Evil Py Argo Shell

这是一个Python包示例项目，演示了在构建过程中执行系统命令的方法。

## 项目特性

- 在构建过程中执行系统命令（如`id`）
- 纯Python实现
- 可以用于学习和研究目的

## 项目结构

- `setup.py`: Python包配置文件
- `evil_py_argo_shell/`: Python包目录
- `evil_py_argo_shell/__init__.py`: 主要功能实现

## 安全说明

**重要提醒**: 此包仅供学习和研究目的。在生产环境中不要使用类似的代码模式，因为它可能存在安全风险。

## 安装

```bash
pip install .
```

安装过程中，Cargo构建脚本会自动执行，您可以在构建日志中看到`id`命令的输出。

## 发布到PyPI

要将此包发布到PyPI，请按照以下步骤操作：

1. 注册PyPI账户并获取API令牌：
   - 访问 https://pypi.org/account/register/ 注册账户
   - 在账户设置中创建API令牌

2. 更新`.pypirc`文件中的API令牌

3. 安装构建工具：
   ```bash
   pip install build twine
   ```

4. 构建包：
   ```bash
   python -m build
   ```

5. 上传到PyPI：
   ```bash
   twine upload dist/*
   ```