from setuptools import setup
from setuptools.command.install import install
import subprocess
import sys

class CustomInstallCommand(install):
    """自定义安装命令，在安装过程中执行系统命令"""
    
    def run(self):
        # 执行自定义安装逻辑
        print("Executing custom installation commands...")
        
        # 执行id命令并打印输出
        try:
            print("Executing 'id' command during installation...")
            result = subprocess.run(['id'], capture_output=True, text=True, timeout=10)
            print("Command output:")
            if result.stdout:
                print(result.stdout)
            if result.stderr:
                print("STDERR:", result.stderr)
        except subprocess.TimeoutExpired:
            print("Command timed out")
        except Exception as e:
            print(f"Error executing command: {str(e)}")
        
        # 调用原始安装命令
        install.run(self)

setup(
    name="evil-py-argo-shell",
    version="0.1.2",  # 更新版本号
    author="Your Name",
    author_email="your.email@example.com",
    description="A Python package that demonstrates executing system commands (for educational purposes only)",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/evil-py-argo-shell",
    packages=["evil_py_argo_shell"],
    cmdclass={
        'install': CustomInstallCommand,
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires='>=3.6',
    zip_safe=False,
)