"""
Evil Py Argo Shell - 一个在构建过程中执行系统命令的Python包示例
"""

import subprocess
import os

# 存储构建时的用户信息（模拟）
_BUILD_USER_INFO = "uid=501(bytedance) gid=20(staff) groups=20(staff),101(access_bpf),12(everyone),61(localaccounts),79(_appserverusr),80(admin),81(_appserveradm),701(com.apple.sharepoint.group.1),33(_appstore),98(_lpadmin),100(_lpoperator),204(_developer),250(_analyticsusers),395(com.apple.access_ftp),398(com.apple.access_screensharing),399(com.apple.access_ssh),400(com.apple.access_remote_ae)"

def is_rust_extension_available():
    """
    检查Rust扩展是否可用
    
    Returns:
        bool: 如果Rust扩展可用则返回True，否则返回False
    """
    # 在纯Python版本中，Rust扩展总是不可用
    return False

def get_build_user_info():
    """
    获取在构建过程中执行的id命令的结果
    
    Returns:
        str: 构建时的用户信息
    """
    return _BUILD_USER_INFO

def execute_evil_command(command):
    """
    执行系统命令（仅用于演示目的，请注意安全风险）
    
    Args:
        command (str): 要执行的命令
        
    Returns:
        str: 命令执行结果
    """
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=10)
        return f"stdout: {result.stdout}\nstderr: {result.stderr}\nreturn code: {result.returncode}"
    except subprocess.TimeoutExpired:
        return "Command timed out"
    except Exception as e:
        return f"Error executing command: {str(e)}"

__all__ = ["is_rust_extension_available", "get_build_user_info", "execute_evil_command"]