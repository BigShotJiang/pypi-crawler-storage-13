import struct
import asyncio
import time
import numpy as np
from elrs import ELRS
from elrs.elrs import RC_CHANNEL_MIN, RC_CHANNEL_MAX
from scipy.spatial.transform import Rotation as R

import trigga

from ..drone import Drone

# import asyncio
# from datetime import datetime

# PORT = "/dev/ttyUSB0"
# BAUD = 921600

# async def main() -> None:

#     def callback(ftype, decoded):
#         ts = datetime.now().strftime('%H:%M:%S.%f')[:-3]
#         print(f"[{ts}] {ftype:02X} {decoded}")


#     asyncio.create_task(elrs.start())

#     value = 1000
#     while True:
#         channels = [value] * 16
#         elrs.set_channels(channels)
#         value = (value + 1) % 2048
#         await asyncio.sleep(0.1)

# if __name__ == "__main__":
#     asyncio.run(main())

def to_channel(value):
    return np.clip(value, -1, 1) * (RC_CHANNEL_MAX - RC_CHANNEL_MIN) / 2 + (RC_CHANNEL_MAX + RC_CHANNEL_MIN) / 2


class Betaflight(Drone):
    def __init__(self, name, uri='/dev/ttyUSB0', BAUD=921600, rate=50, odometry_source="mocap", verbose=False, SOFT_LANDING=True, **kwargs):
        super().__init__(name, **kwargs)
        self.odometry_source = odometry_source
        self.orientation = None
        self.position = None
        self.velocity = None
        self.target_position = None
        self.target_velocity = None
        self.target_yaw = 0
        self.elrs = ELRS(uri, baud=BAUD, rate=rate, telemetry_callback=self._telemetry_callback, verbose=verbose)
        asyncio.create_task(self.elrs.start())


        self.position_number = 0
        self.safety_distance = 0.15
        loop = asyncio.get_event_loop()
        loop.create_task(self.main())
        self.disarmed = False
        self.last_pose_callback = None
        self.pose_callback_dts = []
        self.POSITION_ERROR_CLIP = 0.6
        self.VELOCITY_ERROR_CLIP = 2.0
        self.SOFT_LANDING = SOFT_LANDING
    def _telemetry_callback(self, frame_type, data):
        pass
    def _mocap_callback(self, timestamp, position, orientation, velocity, metadata):
        self.velocity = velocity
        self.orientation = orientation
        self.position = position
        if self.target_position is None:
            self.target_position = position
            self.target_velocity = np.zeros(3)
        if self.odometry_source == "mocap":
            self._odometry_callback(timestamp, position, orientation, velocity, metadata)
        now = time.time()
        if self.last_pose_callback is not None and (now - self.last_pose_callback < 0.01):
            return
        if self.last_pose_callback is not None:
            dt = now - self.last_pose_callback
            self.pose_callback_dts.append(dt)
            self.pose_callback_dts = self.pose_callback_dts[-100:]
        self.last_pose_callback = now
        # print(f"vicon pos: {position[0]:.2f} {position[1]:.2f} {position[2]:.2f} {1/np.mean(self.pose_callback_dts):.2f} Hz", file=mux[1])
    
    async def arm(self):
        pass
    
    async def main(self):
        tick = 0
        previous_deadman_trigger = None
        landing_start = None
        landing_position = None
        while True:
            if self.orientation is None or self.position is None or self.velocity is None or self.target_position is None or self.target_velocity is None:
                await asyncio.sleep(0.01)
                output = [
                    to_channel([0, 0, 1]), # AET
                    to_channel([0]), # R
                    to_channel([0]), # AUX1
                    to_channel([0, 0, 0]) # AUX2-4
                ]
            else:
                w_m, z_m = self.orientation[0], self.orientation[3]
                if w_m < 0:
                    w_m = -w_m
                    z_m = -z_m
                d_m = np.sqrt(w_m*w_m + z_m*z_m)
                if d_m < 1e-6:
                    continue
                yaw = 2 * np.arctan2(z_m / d_m, w_m / d_m)
                angle_transmission = (yaw - self.target_yaw) / np.pi


                if previous_deadman_trigger is not None and previous_deadman_trigger != trigga.trigga:
                    if not trigga.trigga and landing_start is None and self.SOFT_LANDING:
                        print("Landing")
                        landing_start = time.time()
                        landing_position = self.position.copy()
                        landing_position[2] = 0

                if landing_start is not None:
                    self.target_position = landing_position
                    self.target_velocity = np.zeros(3)
                    if time.time() - landing_start > 1:
                        landing_start = None
                        armed = False
                    else:
                        armed = True
                else:
                    armed = trigga.trigga
                
                previous_deadman_trigger = trigga.trigga



                relative_position = np.array(self.position) - np.array(self.target_position)
                relative_velocity = np.array(self.velocity) - np.array(self.target_velocity)
                clipped_relative_position = np.clip(relative_position, -self.POSITION_ERROR_CLIP, self.POSITION_ERROR_CLIP)
                clipped_relative_velocity = np.clip(relative_velocity, -self.VELOCITY_ERROR_CLIP, self.VELOCITY_ERROR_CLIP)
                if tick % 100 == 0:
                    pass
                    # print(f"angle transmission: {angle_transmission:.2f}")
                    # print(f"relative position: {relative_position[0]:.2f} {relative_position[1]:.2f} {relative_position[2]:.2f} velocity: {relative_velocity[0]:.2f} {relative_velocity[1]:.2f} {relative_velocity[2]:.2f}")

                target_frame_R = R.from_euler('XYZ', [0, 0, self.target_yaw])
                target_frame_R_inv = target_frame_R.inv()
                relative_position_target_frame = target_frame_R_inv.apply(clipped_relative_position)
                relative_velocity_target_frame = target_frame_R_inv.apply(clipped_relative_velocity)

                output = [
                    to_channel(relative_position_target_frame), # AET
                    to_channel([angle_transmission]), # R
                    to_channel([1 if armed else -1]), # AUX1
                    to_channel(relative_velocity_target_frame) # AUX2-4
                ]
            self.elrs.set_channels(np.concatenate(output).astype(int).tolist())
            await asyncio.sleep(0.01)
            tick += 1
    def _forward_command(self, position, velocity, yaw=0):
            self.target_position = position
            self.target_velocity = velocity
            self.target_yaw = yaw

    async def disarm(self):
        pass

async def main():
    # time.sleep(10)
    VICON_IP = "192.168.1.3"
    from ..mocap import Vicon
    target_position = [0, 0, 0.2]
    mocap = Vicon(VICON_TRACKER_IP=VICON_IP)
    URI = '/dev/serial/by-name/elrs-transmitter1'
    # URI = '/dev/serial/by-name/elrs-transmitter1'
    betaflight = Betaflight("betaflight", uri=URI, BAUD=921600, rate=50, odometry_source="mocap", verbose=True)
    betaflight.command(target_position, [0, 0, 0])
    # asyncio.create_task(deadman.monitor(type="foot-pedal")),
    asyncio.create_task(trigga.monitor(type="foot-pedal")),
    betaflight_main_task = asyncio.create_task(betaflight.main())
    mocap.add("savagebee_pusher", betaflight._mocap_callback)
    while betaflight.position is None:
        await asyncio.sleep(0.1)
    initial_position = betaflight.position.copy()
    target_position = initial_position + np.array([0, 0, 0.4])
    print(f"Initial position: {initial_position}")
    print(f"Target position: {target_position}")

    async def timer():
        tick = 0
        dt = 0.01
        while True:
            if tick*dt > 5:
                betaflight.elrs.verbose = False
            await asyncio.sleep(dt)
            tick += 1
    asyncio.create_task(timer())
    while True:
        betaflight.command(target_position, [0, 0, 0])
        while not trigga.trigga:
            await asyncio.sleep(0.1)
        betaflight.command(target_position, [0, 0, 0])
        timeout = asyncio.create_task(asyncio.sleep(15))
        while not timeout.done():
            distance = betaflight.position - target_position
            print(f"Distance to target: {distance[0]:.2f} {distance[1]:.2f} {distance[2]:.2f} m")
            await asyncio.sleep(0.1)
        betaflight.command(initial_position + np.array([0, 0, 0]), [0, 0, 0])
        await asyncio.sleep(5)
        while trigga.trigga:
            await asyncio.sleep(0.1)
    # await betaflight.goto(initial_position, distance_threshold=0.0)
    await betaflight_main_task # DO NOT TERMINATE, IF TERMINATED, THE DRONE DOES NOT RECEIVE FEEDBACK AND LIKELY SHOOTS INTO THE SKY

async def main_elrs_test():
    URI = '/dev/serial/by-name/elrs-transmitter1'
    elrs = ELRS(URI, baud=921600, rate=50, telemetry_callback=None, verbose=True)
    output = [
        to_channel([-0.5, 0.0, 0.5]), # AET
        to_channel([1]), # R
        to_channel([-1]), # AUX1
        to_channel([-0.6, 0.0, 0.6]) # AUX2-4
    ]
    elrs.set_channels(np.concatenate(output).astype(int).tolist())
    task = asyncio.create_task(elrs.start())
    await task
    

if __name__ == "__main__":
    # asyncio.run(main())
    asyncio.run(main_elrs_test())