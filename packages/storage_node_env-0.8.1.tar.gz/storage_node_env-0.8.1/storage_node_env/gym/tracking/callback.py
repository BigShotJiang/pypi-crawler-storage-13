"""
Stable-Baselines3 callbacks for results tracking.

This module provides callback classes that integrate with Stable-Baselines3
training workflows, enabling automatic results saving during training.
"""

import os
from typing import Any


try:
    from stable_baselines3.common.callbacks import BaseCallback
    SB3_AVAILABLE = True
except ImportError:
    # SB3 not installed - create dummy BaseCallback for type hints
    BaseCallback = object  # type: ignore
    SB3_AVAILABLE = False


class ResultsCallback(BaseCallback):  # type: ignore
    """
    Optional callback for periodic checkpointing during SB3 training.

    **When to use**: This callback is OPTIONAL and only needed for long multi-episode
    training where you want periodic saves. The ResultsTracker automatically collects
    results from the last episode, which you can access after training via `env.results`.

    **Use case**: Long training runs (e.g., 1M timesteps) where you want to save
    intermediate checkpoints every N timesteps to avoid data loss.

    **Basic SB3 usage** (no callback needed):
        >>> env = gym.make('storage_node_env/EnergyStorage-v0', track_results=True, ...)
        >>> env.set_controller('ppo')
        >>> model = PPO('MlpPolicy', env, verbose=1)
        >>> model.learn(total_timesteps=100000)  # no callback
        >>> results = env.results['ppo']  # access results after training

    **Advanced usage** (with periodic checkpointing):
        >>> callback = ResultsCallback(save_freq=10000, save_path='results/ppo_training.csv')
        >>> model.learn(total_timesteps=1000000, callback=callback)  # saves every 10k steps

    Args:
        save_freq: Save results every N timesteps.
        save_path: File path where results will be saved.
        controller_name: Optional controller name to save (if None, saves current controller).
        verbose: Verbosity level (0: no output, 1: info messages).

    Note:
        Requires stable-baselines3 to be installed. Install with:
        pip install stable-baselines3
    """

    def __init__(
        self,
        save_freq: int,
        save_path: str,
        controller_name: str | None = None,
        verbose: int = 0
    ) -> None:
        """
        Initialize results callback.

        Args:
            save_freq: Save results every N timesteps.
            save_path: File path where results will be saved.
            controller_name: Optional controller name to save (if None, saves all controllers).
            verbose: Verbosity level (0: no output, 1: info messages).

        Raises:
            ImportError: If stable-baselines3 is not installed.
        """
        if not SB3_AVAILABLE:
            raise ImportError(
                'stable-baselines3 is required for ResultsCallback. '
                'Install with: pip install stable-baselines3'
            )

        super().__init__(verbose)
        self.save_freq = save_freq
        self.save_path = save_path
        self.controller_name = controller_name
        self.last_save_step = 0

        # create directory if it doesn't exist
        os.makedirs(os.path.dirname(save_path) or '.', exist_ok=True)

    def _init_callback(self) -> None:
        """
        Initialize callback at the start of training.

        Raises:
            RuntimeError: If environment doesn't have results tracking enabled.
        """
        # verify that environment has results tracking
        if not hasattr(self.training_env, 'envs'):
            raise RuntimeError(
                'ResultsCallback requires a vectorized environment. '
                'Wrap your environment with DummyVecEnv.'
            )

        # get the unwrapped environment from the vectorized wrapper
        env = self.training_env.envs[0].unwrapped  # type: ignore

        # check for results tracking
        if not hasattr(env, 'tracker') or env.tracker is None:
            raise RuntimeError(
                'Environment does not have results tracking enabled. '
                'Set track_results=True when creating the environment.'
            )

        # check that controller is set
        if env.tracker.current_controller is None:
            raise RuntimeError(
                'No controller set in environment. '
                'Call env.set_controller(name) before training.'
            )

    def _on_step(self) -> bool:
        """
        Called after each environment step during training.

        Returns:
            True to continue training, False to stop.
        """
        # check if it's time to save
        if self.num_timesteps - self.last_save_step >= self.save_freq:
            self._save_results()
            self.last_save_step = self.num_timesteps

        return True

    def _on_training_end(self) -> None:
        """Called at the end of training to perform final save."""
        self._save_results()
        if self.verbose > 0:
            print(f'Final results saved to {self.save_path}')

    def _save_results(self) -> None:
        """Save current results to CSV file."""
        try:
            # get unwrapped environment
            env = self.training_env.envs[0].unwrapped  # type: ignore

            # save results
            if self.controller_name is not None:
                # save specific controller
                env.save_results(self.controller_name, self.save_path)
            else:
                # save current controller
                if env.tracker.current_controller is not None:
                    controller_name = env.tracker.current_controller
                    env.save_results(controller_name, self.save_path)

            if self.verbose > 0:
                print(f'Results saved at timestep {self.num_timesteps} to {self.save_path}')

        except Exception as e:
            if self.verbose > 0:
                print(f'Warning: Failed to save results: {e}')
