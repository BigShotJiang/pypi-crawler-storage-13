"""
Results tracking for EnergyStorageEnv interactions.

This module provides classes for collecting and managing timestep-level
results from environment interactions, supporting multiple controllers
and episode tracking.
"""

from typing import Any

import pandas as pd


class ControllerData:
    """
    Manages results collection for a single controller.

    This class stores timestep-by-timestep data in a memory-efficient format
    (list of dictionaries) and converts to pandas DataFrame on demand.

    Attributes:
        controller_name: Name identifier for this controller.
        node_type: Type of energy node ('producer' or 'prosumer').
        episode_id: Current episode counter.
        steps: List of recorded timesteps (memory-efficient storage).
    """

    def __init__(self, controller_name: str, node_type: str) -> None:
        """
        Initialize controller data collector.

        Args:
            controller_name: Name identifier for this controller.
            node_type: Type of energy node ('producer' or 'prosumer').
        """
        self.controller_name = controller_name
        self.node_type = node_type
        self.episode_id = 0
        self.steps: list[dict[str, Any]] = []

    def record_step(
        self,
        timestep: int,
        action: int,
        action_power: float,
        info: dict[str, Any],
        datetime: 'pd.Timestamp'
    ) -> None:
        """
        Record data from one environment timestep.

        Args:
            timestep: Current timestep index.
            action: Discrete action index taken.
            action_power: Converted action power in kW.
            info: Info dictionary returned by env.step().
            datetime: Timestamp of the current step.
        """
        # build step record with all info fields
        step_record = {
            'datetime': str(datetime),  # first column for easy reference
            'controller': self.controller_name,
            'episode': self.episode_id,
            'timestep': timestep,
            'action_index': action,
            'action_kw': action_power,
            # context fields
            'production_kw': info['production'],
            'consumption_kw': info['consumption'],
            'energy_balance_kw': info['energy_balance'],
            'soc_final_pct': info['final_soc'],
            # power flows
            'grid_power_kw': info['P_grid'],
            'import_power_kw': info['P_import'],
            'export_power_kw': info['P_export'],
            # energy flows
            'import_energy_kwh': info['E_import'],
            'export_energy_kwh': info['E_export'],
            # economic metrics
            'import_cost_eur': info['cost_import'],
            'export_revenue_eur': info['revenue_export'],
            # constraint violations
            'violation_kw': info['violation'],
            # self-consumption metrics
            'selfcons_energy_kwh': info['E_selfcons'],
            'selfcons_ratio': info['selfcons_ratio'],
            'selfsuff_energy_kwh': info['E_selfsuff'],
            'selfsuff_ratio': info['selfsuff_ratio'],
            # battery metrics
            'battery_charge_kwh': info['E_bat_charge'],
            'battery_discharge_kwh': info['E_bat_discharge'],
            'soc_delta_pct': info['delta_soc'],
        }

        # add node-specific economic field
        if self.node_type == 'producer':
            step_record['net_profit_eur'] = info['net_profit']
        else:  # prosumer
            step_record['net_cost_eur'] = info['net_cost']

        self.steps.append(step_record)

    def on_reset(self) -> None:
        """
        Increment episode counter and clear previous episode data.

        This method is called when the environment resets. It clears all previously
        recorded steps to keep only the current (last) episode data, preventing
        memory issues during long multi-episode training.

        Note:
            Only the most recent episode's data is retained. For multi-episode
            tracking with periodic saves, use ResultsCallback.
        """
        self.episode_id += 1
        self.steps.clear()  # keep only last episode

    def get_dataframe(self) -> pd.DataFrame:
        """
        Convert collected results to pandas DataFrame.

        Returns:
            DataFrame with all recorded timesteps.

        Raises:
            ValueError: If no steps have been recorded.
        """
        if not self.steps:
            raise ValueError(f'No results recorded for controller \'{self.controller_name}\'')

        return pd.DataFrame(self.steps)

    def __repr__(self) -> str:
        """Return string representation of controller data."""
        return (
            f'ControllerData('
            f'controller=\'{self.controller_name}\', '
            f'node_type=\'{self.node_type}\', '
            f'episodes={self.episode_id}, '
            f'steps={len(self.steps)}'
            f')'
        )


class ResultsTracker:
    """
    Manages results collection for multiple controllers.

    This class coordinates tracking of results across different controllers,
    allowing users to test multiple control strategies on the same environment
    instance without recreation.

    **Memory Efficiency**: The tracker stores only the LAST episode for each
    controller. When the environment resets, previous episode data is cleared.
    For long multi-episode training with periodic checkpointing, use ResultsCallback.

    Attributes:
        node_type: Type of energy node ('producer' or 'prosumer').
        current_controller: Name of currently active controller.
        controllers: Dictionary mapping controller names to their ControllerData.

    Example:
        >>> tracker = ResultsTracker(node_type='prosumer')
        >>> tracker.set_controller('naive')
        >>> tracker.record_step(0, 10, 0.0, info_dict)
        >>> tracker.set_controller('ppo')
        >>> tracker.record_step(0, 15, 1.25, info_dict)
        >>> results = tracker.get_results()
        >>> print(results.keys())
        dict_keys(['naive', 'ppo'])
    """

    def __init__(self, node_type: str) -> None:
        """
        Initialize results tracker.

        Args:
            node_type: Type of energy node ('producer' or 'prosumer').
        """
        self.node_type = node_type
        self.current_controller: str | None = None
        self.controllers: dict[str, ControllerData] = {}

    def set_controller(self, name: str) -> None:
        """
        Set the active controller for results tracking.

        This creates a new ControllerData instance if the controller name
        is new, or switches to an existing controller if it was used before.

        Args:
            name: Controller name identifier.

        Example:
            >>> tracker.set_controller('naive')
            >>> tracker.set_controller('ppo')  # creates new controller
            >>> tracker.set_controller('naive')  # switches back to existing
        """
        if name not in self.controllers:
            self.controllers[name] = ControllerData(name, self.node_type)

        self.current_controller = name

    def record_step(
        self,
        timestep: int,
        action: int,
        action_power: float,
        info: dict[str, Any],
        datetime: 'pd.Timestamp'
    ) -> None:
        """
        Record one timestep for the current controller.

        Args:
            timestep: Current timestep index.
            action: Discrete action index taken.
            action_power: Converted action power in kW.
            info: Info dictionary returned by env.step().
            datetime: Timestamp of the current step.

        Raises:
            RuntimeError: If no controller is set.

        Example:
            >>> tracker.set_controller('naive')
            >>> tracker.record_step(0, 10, 0.0, info, datetime)
        """
        if self.current_controller is None:
            raise RuntimeError(
                'No controller set. Call set_controller(name) before recording steps.'
            )

        self.controllers[self.current_controller].record_step(
            timestep, action, action_power, info, datetime
        )

    def on_reset(self) -> None:
        """
        Increment episode counter for current controller.

        Called automatically by EnergyStorageEnv.reset() to track
        episode boundaries during multi-episode training.
        """
        if self.current_controller is not None:
            self.controllers[self.current_controller].on_reset()

    def get_results(self) -> dict[str, pd.DataFrame]:
        """
        Get all results as dictionary of DataFrames.

        Returns:
            Dictionary mapping controller names to their result DataFrames.

        Example:
            >>> results = tracker.get_results()
            >>> df_naive = results['naive']
            >>> df_ppo = results['ppo']
        """
        return {
            name: ctrl.get_dataframe()
            for name, ctrl in self.controllers.items()
        }

    def get_controller_results(self, name: str) -> pd.DataFrame:
        """
        Get results for a specific controller.

        Args:
            name: Controller name identifier.

        Returns:
            DataFrame with results for the specified controller.

        Raises:
            ValueError: If controller name not found.

        Example:
            >>> df = tracker.get_controller_results('naive')
        """
        if name not in self.controllers:
            raise ValueError(
                f'No results for controller \'{name}\'. '
                f'Available controllers: {list(self.controllers.keys())}'
            )

        return self.controllers[name].get_dataframe()

    def __repr__(self) -> str:
        """Return string representation of tracker state."""
        return (
            f'ResultsTracker('
            f'node_type=\'{self.node_type}\', '
            f'current_controller=\'{self.current_controller}\', '
            f'controllers={list(self.controllers.keys())}'
            f')'
        )
