"""
Reward normalization utilities.

This module provides utilities for normalizing reward values to specific ranges,
which can improve learning stability in reinforcement learning algorithms.
"""

import numpy as np


class RewardNormalizer:
    """
    Min-max normalizer for reward values.

    This class normalizes rewards from an observed range [min, max] to a target
    range [target_min, target_max], typically [0, 1] or [-1, 1].

    Attributes:
        min_val: Minimum observed reward value.
        max_val: Maximum observed reward value.
        target_min: Minimum value of target range.
        target_max: Maximum value of target range.
        is_fitted: Whether the normalizer has been fitted to data.

    Example:
        >>> normalizer = RewardNormalizer(target_min=-1.0, target_max=1.0)
        >>> normalizer.fit([0.1, 0.5, -0.2, 0.8])
        >>> normalized = normalizer.transform(0.3)
    """

    def __init__(
        self,
        target_min: float = 0.0,
        target_max: float = 1.0,
        epsilon: float = 1e-8
    ) -> None:
        """
        Initialize the reward normalizer.

        Args:
            target_min: Minimum value of target range. Defaults to 0.0.
            target_max: Maximum value of target range. Defaults to 1.0.
            epsilon: Small constant to prevent division by zero. Defaults to 1e-8.
        """
        self.target_min = target_min
        self.target_max = target_max
        self.epsilon = epsilon

        self.min_val: float | None = None
        self.max_val: float | None = None
        self.is_fitted = False

    def fit(self, rewards: list[float] | np.ndarray) -> None:
        """
        Fit the normalizer to observed reward values.

        This method computes the minimum and maximum values from the provided
        reward samples, which will be used for normalization.

        Args:
            rewards: List or array of reward values to fit.

        Raises:
            ValueError: If rewards is empty.

        Example:
            >>> normalizer = RewardNormalizer()
            >>> normalizer.fit([0.1, 0.5, -0.2, 0.8, 0.3])
            >>> print(f'Range: [{normalizer.min_val:.2f}, {normalizer.max_val:.2f}]')
            Range: [-0.20, 0.80]
        """
        if len(rewards) == 0:
            raise ValueError('Cannot fit normalizer to empty reward list')

        rewards_array = np.array(rewards)
        self.min_val = float(np.min(rewards_array))
        self.max_val = float(np.max(rewards_array))
        self.is_fitted = True

    def transform(self, reward: float) -> float:
        """
        Normalize a reward value using fitted range.

        Args:
            reward: Raw reward value to normalize.

        Returns:
            Normalized reward in target range [target_min, target_max].

        Raises:
            RuntimeError: If normalizer has not been fitted yet.

        Note:
            - If min_val == max_val (constant rewards), returns target_min
            - Values outside fitted range are clipped to target range

        Example:
            >>> normalizer = RewardNormalizer(target_min=0.0, target_max=1.0)
            >>> normalizer.fit([-0.2, 0.8])
            >>> print(normalizer.transform(0.3))  # 0.5
        """
        if not self.is_fitted:
            raise RuntimeError('Normalizer must be fitted before transform')

        # handle edge case: constant rewards
        if abs(self.max_val - self.min_val) < self.epsilon:
            return self.target_min

        # min-max normalization to [0, 1]
        normalized = (reward - self.min_val) / (self.max_val - self.min_val + self.epsilon)

        # scale to target range
        scaled = self.target_min + normalized * (self.target_max - self.target_min)

        # clip to target range to handle outliers
        return float(np.clip(scaled, self.target_min, self.target_max))

    def fit_transform(self, rewards: list[float] | np.ndarray) -> np.ndarray:
        """
        Fit normalizer and transform rewards in one step.

        Args:
            rewards: List or array of reward values.

        Returns:
            Array of normalized rewards.

        Example:
            >>> normalizer = RewardNormalizer()
            >>> normalized = normalizer.fit_transform([0.1, 0.5, -0.2, 0.8])
        """
        self.fit(rewards)
        return np.array([self.transform(r) for r in rewards])

    def inverse_transform(self, normalized_reward: float) -> float:
        """
        Convert normalized reward back to original scale.

        Args:
            normalized_reward: Normalized reward value.

        Returns:
            Reward in original scale.

        Raises:
            RuntimeError: If normalizer has not been fitted yet.

        Example:
            >>> normalizer = RewardNormalizer()
            >>> normalizer.fit([0.0, 1.0])
            >>> normalized = normalizer.transform(0.5)
            >>> original = normalizer.inverse_transform(normalized)
            >>> print(f'{original:.2f}')  # 0.50
        """
        if not self.is_fitted:
            raise RuntimeError('Normalizer must be fitted before inverse_transform')

        # handle edge case: constant rewards
        if abs(self.max_val - self.min_val) < self.epsilon:
            return self.min_val

        # reverse scaling from target range to [0, 1]
        unscaled = (normalized_reward - self.target_min) / (self.target_max - self.target_min)

        # reverse min-max normalization
        original = self.min_val + unscaled * (self.max_val - self.min_val)

        return original

    def __repr__(self) -> str:
        """
        Return string representation of the normalizer.

        Returns:
            Formatted string with normalizer configuration.
        """
        if self.is_fitted:
            return (
                f'RewardNormalizer(fitted=True, '
                f'range=[{self.min_val:.4f}, {self.max_val:.4f}], '
                f'target=[{self.target_min:.4f}, {self.target_max:.4f}])'
            )
        else:
            return (
                f'RewardNormalizer(fitted=False, '
                f'target=[{self.target_min:.4f}, {self.target_max:.4f}])'
            )


class RunningRewardNormalizer:
    """
    Online (running) reward normalizer using exponential moving statistics.

    This normalizer computes running mean and standard deviation of rewards
    and normalizes using standardization (z-score normalization). Useful for
    online learning where reward distribution is not known in advance.

    Attributes:
        mean: Running mean of rewards.
        var: Running variance of rewards.
        count: Number of rewards seen.
        epsilon: Small constant to prevent division by zero.
        clip_range: Range to clip normalized rewards (optional).

    Example:
        >>> normalizer = RunningRewardNormalizer(clip_range=10.0)
        >>> for reward in [0.1, 0.5, -0.2, 0.8]:
        ...     normalized = normalizer.update_and_transform(reward)
    """

    def __init__(
        self,
        epsilon: float = 1e-8,
        clip_range: float | None = 10.0
    ) -> None:
        """
        Initialize the running reward normalizer.

        Args:
            epsilon: Small constant to prevent division by zero. Defaults to 1e-8.
            clip_range: Maximum absolute value for clipping (e.g., 10.0 means
                rewards are clipped to [-10, 10]). None for no clipping.
                Defaults to 10.0.
        """
        self.mean = 0.0
        self.var = 1.0
        self.count = 0
        self.epsilon = epsilon
        self.clip_range = clip_range

    def update(self, reward: float) -> None:
        """
        Update running statistics with a new reward value.

        Uses Welford's online algorithm for numerical stability.

        Args:
            reward: New reward value to incorporate.

        Example:
            >>> normalizer = RunningRewardNormalizer()
            >>> normalizer.update(0.5)
            >>> normalizer.update(1.0)
            >>> print(f'Mean: {normalizer.mean:.2f}')
        """
        self.count += 1
        delta = reward - self.mean
        self.mean += delta / self.count
        delta2 = reward - self.mean
        self.var += (delta * delta2 - self.var) / self.count

    def transform(self, reward: float) -> float:
        """
        Normalize a reward value using current statistics.

        Applies z-score normalization: (reward - mean) / std

        Args:
            reward: Raw reward value to normalize.

        Returns:
            Normalized reward (z-score).

        Note:
            - Returns original reward if count < 2 (not enough data)
            - Clips to [-clip_range, clip_range] if clip_range is set

        Example:
            >>> normalizer = RunningRewardNormalizer()
            >>> normalizer.update(0.0)
            >>> normalizer.update(1.0)
            >>> print(normalizer.transform(0.5))
        """
        if self.count < 2:
            return reward

        std = np.sqrt(self.var + self.epsilon)
        normalized = (reward - self.mean) / std

        if self.clip_range is not None:
            normalized = np.clip(normalized, -self.clip_range, self.clip_range)

        return float(normalized)

    def update_and_transform(self, reward: float) -> float:
        """
        Update statistics and normalize in one step.

        Args:
            reward: Raw reward value.

        Returns:
            Normalized reward.

        Example:
            >>> normalizer = RunningRewardNormalizer()
            >>> normalized = normalizer.update_and_transform(0.5)
        """
        normalized = self.transform(reward)
        self.update(reward)
        return normalized

    def __repr__(self) -> str:
        """
        Return string representation of the normalizer.

        Returns:
            Formatted string with normalizer statistics.
        """
        std = np.sqrt(self.var) if self.count > 0 else 0.0
        return (
            f'RunningRewardNormalizer(count={self.count}, '
            f'mean={self.mean:.4f}, std={std:.4f}, '
            f'clip_range={self.clip_range})'
        )
