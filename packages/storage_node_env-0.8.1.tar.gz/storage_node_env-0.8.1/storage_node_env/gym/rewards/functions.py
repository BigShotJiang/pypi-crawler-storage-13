"""
Helper functions for reward calculation.

This module provides utility functions for computing specific reward components
and metrics used across different reward calculators.
"""

from typing import Any


def calculate_self_consumption_ratio(node_results: dict[str, Any]) -> float:
    """
    Calculate self-consumption ratio for prosumer nodes.

    Self-consumption ratio measures how much of the produced energy is consumed
    locally versus exported to the grid. Higher values indicate better self-consumption.

    Args:
        node_results: Dictionary containing node step results with fields:
            - production: Power produced (kW)
            - consumption: Power consumed (kW)
            - P_export: Power exported to grid (kW)

    Returns:
        Self-consumption ratio in range [0, 1]:
            - 1.0: All production consumed locally (no export)
            - 0.0: All production exported (no self-consumption)
            - Returns 0.0 if production is zero

    Note:
        Self-consumption = (production - export) / production
        Only applicable for prosumer nodes with consumption > 0.

    Example:
        >>> node_results = {'production': 5.0, 'consumption': 3.0, 'P_export': 2.0}
        >>> ratio = calculate_self_consumption_ratio(node_results)
        >>> print(f'{ratio:.2f}')  # 0.60 (60% self-consumed)
    """
    production = node_results.get('production', 0.0)
    p_export = node_results.get('P_export', 0.0)

    # avoid division by zero
    if production <= 0.0:
        return 0.0

    # self-consumption = production used locally / total production
    self_consumed = production - p_export
    ratio = self_consumed / production

    # clip to [0, 1] range to handle numerical errors
    return max(0.0, min(1.0, ratio))


def calculate_grid_independence_score(node_results: dict[str, Any]) -> float:
    """
    Calculate grid independence score for prosumer nodes.

    Grid independence measures how much of the consumption is satisfied by local
    production versus grid imports. Higher values indicate less grid dependency.

    Args:
        node_results: Dictionary containing node step results with fields:
            - production: Power produced (kW)
            - consumption: Power consumed (kW)
            - P_import: Power imported from grid (kW)

    Returns:
        Grid independence score in range [0, 1]:
            - 1.0: All consumption satisfied by local production (no import)
            - 0.0: All consumption from grid (fully dependent)
            - Returns 0.0 if consumption is zero

    Note:
        Independence = (consumption - import) / consumption
        Only applicable for prosumer nodes.

    Example:
        >>> node_results = {'production': 4.0, 'consumption': 5.0, 'P_import': 1.0}
        >>> score = calculate_grid_independence_score(node_results)
        >>> print(f'{score:.2f}')  # 0.80 (80% independent)
    """
    consumption = node_results.get('consumption', 0.0)
    p_import = node_results.get('P_import', 0.0)

    # avoid division by zero
    if consumption <= 0.0:
        return 0.0

    # independence = consumption satisfied locally / total consumption
    local_satisfied = consumption - p_import
    score = local_satisfied / consumption

    # clip to [0, 1] range to handle numerical errors
    return max(0.0, min(1.0, score))


def calculate_economic_reward(node_results: dict[str, Any], node_type: str) -> float:
    """
    Calculate economic reward based on net profit or cost.

    For producer nodes: reward is net profit (revenue - cost)
    For prosumer nodes: reward is negative net cost (to maximize profit/minimize cost)

    Args:
        node_results: Dictionary containing node step results with fields:
            - net_profit: Net profit for producer nodes (€)
            - net_cost: Net cost for prosumer nodes (€)
        node_type: Type of energy node ('producer' or 'prosumer').

    Returns:
        Economic reward value:
            - Producer: net_profit (positive is better)
            - Prosumer: -net_cost (less negative/more positive is better)

    Note:
        - For prosumer, we negate cost so that minimizing cost = maximizing reward
        - Values are in euros (€)

    Example:
        >>> # Producer with profit
        >>> node_results = {'net_profit': 0.15}
        >>> reward = calculate_economic_reward(node_results, 'producer')
        >>> print(f'{reward:.4f}')  # 0.1500

        >>> # Prosumer with cost
        >>> node_results = {'net_cost': 0.20}
        >>> reward = calculate_economic_reward(node_results, 'prosumer')
        >>> print(f'{reward:.4f}')  # -0.2000
    """
    if node_type == 'producer':
        # for producer, maximize net profit
        return node_results.get('net_profit', 0.0)
    else:  # prosumer
        # for prosumer, minimize net cost (= maximize -net_cost)
        return -node_results.get('net_cost', 0.0)


def calculate_energy_arbitrage_potential(node_results: dict[str, Any]) -> float:
    """
    Calculate energy arbitrage potential based on price spread.

    This metric measures the price difference between buying and selling,
    which indicates the potential profit from energy storage arbitrage.

    Args:
        node_results: Dictionary containing node step results with fields:
            - buy_price: Grid purchase price (€/kWh)
            - sell_price: Grid selling price (€/kWh)

    Returns:
        Price spread (sell_price - buy_price) in €/kWh.
            - Positive: Favorable for arbitrage (sell > buy)
            - Negative: Unfavorable for arbitrage (buy > sell)
            - Zero: No arbitrage opportunity

    Note:
        This is a potential indicator, not an actual reward.
        Actual arbitrage profit depends on storage utilization.

    Example:
        >>> node_results = {'buy_price': 0.15, 'sell_price': 0.20}
        >>> spread = calculate_energy_arbitrage_potential(node_results)
        >>> print(f'{spread:.4f}')  # 0.0500 (5 cents/kWh spread)
    """
    buy_price = node_results.get('buy_price', 0.0)
    sell_price = node_results.get('sell_price', 0.0)

    return sell_price - buy_price


def calculate_storage_efficiency_loss(node_results: dict[str, Any]) -> float:
    """
    Calculate energy loss due to battery inefficiency.

    This metric estimates the energy lost during charge/discharge cycles
    based on the actual energy throughput.

    Args:
        node_results: Dictionary containing node step results with fields:
            - initial_soc: Initial state of charge (%)
            - final_soc: Final state of charge (%)
            - action_power: Requested battery power (kW)

    Returns:
        Estimated efficiency loss (non-negative value).

    Note:
        This is a simplified estimate. Actual losses depend on battery
        efficiency parameters which are not directly available in node_results.
        Returns absolute SoC change as a proxy for energy throughput.
    """
    initial_soc = node_results.get('initial_soc', 0.0)
    final_soc = node_results.get('final_soc', 0.0)

    # return absolute change as proxy for throughput
    return abs(final_soc - initial_soc)


def normalize_to_range(
    value: float,
    min_val: float,
    max_val: float,
    target_min: float = 0.0,
    target_max: float = 1.0
) -> float:
    """
    Normalize a value from original range to target range.

    Args:
        value: Value to normalize.
        min_val: Minimum value of original range.
        max_val: Maximum value of original range.
        target_min: Minimum value of target range. Defaults to 0.0.
        target_max: Maximum value of target range. Defaults to 1.0.

    Returns:
        Normalized value in target range.

    Note:
        - If min_val == max_val, returns target_min
        - Handles edge cases gracefully

    Example:
        >>> # Normalize 5 from [0, 10] to [0, 1]
        >>> normalized = normalize_to_range(5, 0, 10, 0, 1)
        >>> print(normalized)  # 0.5
    """
    # handle edge case: constant value
    if max_val == min_val:
        return target_min

    # linear normalization
    normalized = (value - min_val) / (max_val - min_val)
    scaled = target_min + normalized * (target_max - target_min)

    return scaled
