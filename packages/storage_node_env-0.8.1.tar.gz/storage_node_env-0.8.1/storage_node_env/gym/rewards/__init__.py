"""
Reward calculation system for energy storage environments.

This package provides a modular reward system with multiple objective functions
for reinforcement learning in energy storage optimization.

Available reward types:
    - self_consumption: Maximize local energy consumption (prosumer nodes)
    - energy_arbitrage: Maximize profit through price arbitrage (producer/prosumer)

Main components:
    - RewardCalculator: Abstract base class for all reward calculators
    - SelfConsumptionReward: Self-consumption maximization reward
    - EnergyArbitrageReward: Energy arbitrage reward
    - create_reward_calculator: Factory function for creating reward instances
    - RewardConfig: Configuration dataclass
    - REWARD_REGISTRY: Registry of available reward types

Example:
    >>> from storage_node_env.gym.rewards import create_reward_calculator
    >>> calculator = create_reward_calculator(
    ...     reward_type='self_consumption',
    ...     weights={'main': 1.0, 'violation_penalty': 0.1, 'storage_usage_penalty': 0.01},
    ...     node_type='prosumer'
    ... )
    >>> reward = calculator.calculate(node_results)
"""

from storage_node_env.gym.rewards.base import RewardCalculator
from storage_node_env.gym.rewards.calculators import (
    EnergyArbitrageReward,
    SelfConsumptionReward,
    create_reward_calculator,
)
from storage_node_env.gym.rewards.config import (
    REWARD_REGISTRY,
    RewardConfig,
    get_default_reward_settings,
    get_reward_config,
    list_available_rewards,
    print_reward_registry,
    validate_reward_settings,
)
from storage_node_env.gym.rewards.functions import (
    calculate_economic_reward,
    calculate_energy_arbitrage_potential,
    calculate_grid_independence_score,
    calculate_self_consumption_ratio,
    calculate_storage_efficiency_loss,
    normalize_to_range,
)
from storage_node_env.gym.rewards.normalizers import (
    RewardNormalizer,
    RunningRewardNormalizer,
)


__all__ = [
    # base class
    'RewardCalculator',
    # concrete implementations
    'SelfConsumptionReward',
    'EnergyArbitrageReward',
    # factory function
    'create_reward_calculator',
    # configuration
    'RewardConfig',
    'REWARD_REGISTRY',
    'get_reward_config',
    'list_available_rewards',
    'validate_reward_settings',
    'get_default_reward_settings',
    'print_reward_registry',
    # helper functions
    'calculate_self_consumption_ratio',
    'calculate_grid_independence_score',
    'calculate_economic_reward',
    'calculate_energy_arbitrage_potential',
    'calculate_storage_efficiency_loss',
    'normalize_to_range',
    # normalizers
    'RewardNormalizer',
    'RunningRewardNormalizer',
]
