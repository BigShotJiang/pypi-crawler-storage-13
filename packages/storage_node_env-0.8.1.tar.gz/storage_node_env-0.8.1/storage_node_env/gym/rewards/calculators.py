"""
Concrete reward calculator implementations.

This module provides specific reward calculators for different optimization
objectives in energy storage environments.
"""

from typing import Any

from storage_node_env.gym.rewards.base import RewardCalculator
from storage_node_env.gym.rewards.functions import (
    calculate_economic_reward,
    calculate_grid_independence_score,
    calculate_self_consumption_ratio,
)


class SelfConsumptionReward(RewardCalculator):
    """
    Reward calculator for maximizing self-consumption in prosumer nodes.

    This reward encourages the agent to maximize the use of locally produced
    energy for local consumption, reducing reliance on grid imports/exports.

    The main reward is computed as a weighted combination of:
    - Self-consumption ratio: fraction of production consumed locally
    - Grid independence score: fraction of consumption satisfied by local production

    This reward is primarily designed for prosumer nodes with both production
    and consumption. For producer nodes (no consumption), it degenerates to
    minimizing exports.

    Attributes:
        weight_self_consumption: Weight for self-consumption ratio component.
        weight_grid_independence: Weight for grid independence score component.

    Example:
        >>> calculator = SelfConsumptionReward(
        ...     weights={'main': 1.0, 'violation_penalty': 0.1, 'storage_usage_penalty': 0.01},
        ...     node_type='prosumer'
        ... )
        >>> node_results = {
        ...     'production': 5.0,
        ...     'consumption': 4.0,
        ...     'P_export': 1.0,
        ...     'P_import': 0.0,
        ...     'violation': 0.0,
        ...     'initial_soc': 50.0,
        ...     'final_soc': 52.0
        ... }
        >>> reward = calculator.calculate(node_results)
    """

    def __init__(
        self,
        weights: dict[str, float],
        normalize: bool = False,
        node_type: str = 'prosumer',
        weight_self_consumption: float = 0.5,
        weight_grid_independence: float = 0.5
    ) -> None:
        """
        Initialize the self-consumption reward calculator.

        Args:
            weights: Dictionary with weight coefficients for reward combination:
                - 'main': Weight for main reward component
                - 'violation_penalty': Weight for violation penalty
                - 'storage_usage_penalty': Weight for storage usage penalty
            normalize: Whether to apply normalization to rewards. Defaults to False.
            node_type: Type of energy node ('producer' or 'prosumer'). Defaults to 'prosumer'.
            weight_self_consumption: Weight for self-consumption ratio [0, 1].
                Defaults to 0.5.
            weight_grid_independence: Weight for grid independence score [0, 1].
                Defaults to 0.5.

        Note:
            weight_self_consumption + weight_grid_independence should ideally sum to 1.0
            for balanced contribution, but this is not enforced.
        """
        super().__init__(weights=weights, normalize=normalize, node_type=node_type)

        self.weight_self_consumption = weight_self_consumption
        self.weight_grid_independence = weight_grid_independence

    def _calculate_main_reward(self, node_results: dict[str, Any]) -> float:
        """
        Calculate main reward based on self-consumption and grid independence.

        The reward combines two metrics:
        1. Self-consumption ratio: (production - export) / production
        2. Grid independence score: (consumption - import) / consumption

        Both metrics are in range [0, 1] where 1.0 is optimal.

        Args:
            node_results: Dictionary containing node step results with fields:
                - production: Power produced (kW)
                - consumption: Power consumed (kW)
                - P_export: Power exported to grid (kW)
                - P_import: Power imported from grid (kW)

        Returns:
            Combined self-consumption reward in range [0, 1].

        Note:
            - For producer nodes (consumption = 0), grid independence score is 0
            - For nodes without production, self-consumption ratio is 0
            - Returns 0 if both production and consumption are zero
        """
        # calculate self-consumption ratio (how much production is used locally)
        sc_ratio = calculate_self_consumption_ratio(node_results)

        # calculate grid independence score (how much consumption is satisfied locally)
        gi_score = calculate_grid_independence_score(node_results)

        # weighted combination of both metrics
        main_reward = (
            self.weight_self_consumption * sc_ratio +
            self.weight_grid_independence * gi_score
        )

        return main_reward

    def __repr__(self) -> str:
        """
        Return string representation of the calculator.

        Returns:
            Formatted string with calculator configuration.
        """
        return (
            f'SelfConsumptionReward('
            f'weights=[main={self.weight_main}, '
            f'violation={self.weight_violation}, '
            f'usage={self.weight_storage_usage}], '
            f'sc_weight={self.weight_self_consumption}, '
            f'gi_weight={self.weight_grid_independence}, '
            f'normalize={self.normalize}, '
            f'node_type=\'{self.node_type}\')'
        )


class EnergyArbitrageReward(RewardCalculator):
    """
    Reward calculator for maximizing profit through energy arbitrage.

    This reward encourages the agent to buy energy when prices are low (charging
    the battery) and sell when prices are high (discharging), maximizing economic
    profit or minimizing costs.

    The main reward is based on:
    - Producer nodes: net_profit (revenue from exports - cost of imports)
    - Prosumer nodes: -net_cost (minimizing cost = maximizing reward)

    This reward is suitable for both producer and prosumer nodes, as long as
    there are price differences that enable profitable arbitrage.

    Example:
        >>> calculator = EnergyArbitrageReward(
        ...     weights={'main': 1.0, 'violation_penalty': 0.1, 'storage_usage_penalty': 0.01},
        ...     node_type='producer'
        ... )
        >>> node_results = {
        ...     'net_profit': 0.15,
        ...     'violation': 0.0,
        ...     'initial_soc': 50.0,
        ...     'final_soc': 60.0
        ... }
        >>> reward = calculator.calculate(node_results)
    """

    def __init__(
        self,
        weights: dict[str, float],
        normalize: bool = False,
        node_type: str = 'prosumer'
    ) -> None:
        """
        Initialize the energy arbitrage reward calculator.

        Args:
            weights: Dictionary with weight coefficients for reward combination:
                - 'main': Weight for main reward component
                - 'violation_penalty': Weight for violation penalty
                - 'storage_usage_penalty': Weight for storage usage penalty
            normalize: Whether to apply normalization to rewards. Defaults to False.
            node_type: Type of energy node ('producer' or 'prosumer'). Defaults to 'prosumer'.
        """
        super().__init__(weights=weights, normalize=normalize, node_type=node_type)

    def _calculate_main_reward(self, node_results: dict[str, Any]) -> float:
        """
        Calculate main reward based on economic profit/cost.

        The reward is directly based on the economic outcome:
        - Producer: net_profit = revenue_export - cost_import (in €)
        - Prosumer: -net_cost = -(cost_import - revenue_export) (in €)

        Args:
            node_results: Dictionary containing node step results with fields:
                - net_profit: Net profit for producer nodes (€)
                - net_cost: Net cost for prosumer nodes (€)

        Returns:
            Economic reward value (in euros):
                - Positive: Profitable or cost-saving action
                - Negative: Loss-making or costly action
                - Zero: Break-even

        Note:
            - For prosumer nodes, we negate net_cost so that minimizing cost
              corresponds to maximizing reward
            - Values are in euros (€) per timestep
            - Typical values range from -0.5 to +0.5 € for 15-minute timesteps
        """
        return calculate_economic_reward(node_results, self.node_type)

    def __repr__(self) -> str:
        """
        Return string representation of the calculator.

        Returns:
            Formatted string with calculator configuration.
        """
        return (
            f'EnergyArbitrageReward('
            f'weights=[main={self.weight_main}, '
            f'violation={self.weight_violation}, '
            f'usage={self.weight_storage_usage}], '
            f'normalize={self.normalize}, '
            f'node_type=\'{self.node_type}\')'
        )


def create_reward_calculator(
    reward_type: str,
    weights: dict[str, float],
    normalize: bool = False,
    node_type: str = 'prosumer'
) -> RewardCalculator:
    """
    Factory function to create reward calculator instances.

    Args:
        reward_type: Type of reward calculator to create:
            - 'self_consumption': SelfConsumptionReward
            - 'energy_arbitrage': EnergyArbitrageReward
        weights: Dictionary with weight coefficients.
        normalize: Whether to apply normalization. Defaults to False.
        node_type: Type of energy node. Defaults to 'prosumer'.

    Returns:
        Instance of the specified reward calculator.

    Raises:
        ValueError: If reward_type is not recognized.

    Example:
        >>> calculator = create_reward_calculator(
        ...     reward_type='self_consumption',
        ...     weights={'main': 1.0, 'violation_penalty': 0.1, 'storage_usage_penalty': 0.01},
        ...     node_type='prosumer'
        ... )
    """
    if reward_type == 'self_consumption':
        return SelfConsumptionReward(
            weights=weights,
            normalize=normalize,
            node_type=node_type
        )
    elif reward_type == 'energy_arbitrage':
        return EnergyArbitrageReward(
            weights=weights,
            normalize=normalize,
            node_type=node_type
        )
    else:
        raise ValueError(
            f'Unknown reward type: \'{reward_type}\'. '
            f'Available types: [\'self_consumption\', \'energy_arbitrage\']'
        )
