"""
Self-consumption controller for maximizing local energy usage.

This module implements a rule-based controller that maximizes self-consumption
by charging the battery during excess production and discharging during deficit.
"""

from typing import Any

from storage_node_env.gym.controllers.base import BaseController


class SelfConsumptionController(BaseController):
    """
    Self-consumption maximization controller.

    This controller implements a rule-based strategy to maximize local energy
    self-consumption and minimize grid dependency:
    - Charge battery during excess production (production > consumption)
    - Discharge battery during deficit (consumption > production)
    - Charge/discharge proportionally to the energy imbalance magnitude

    The controller respects battery power bounds by mapping the energy balance
    to the available action space within the physical constraints.

    Decision Policy:
        - If energy_balance > threshold: Charge proportionally to excess
        - If energy_balance < -threshold: Discharge proportionally to deficit
        - Otherwise: Neutral action (small imbalance)

    Args:
        num_actions: Number of discrete actions in the action space (must be odd).
        balance_threshold: Minimum absolute energy balance (kW) to trigger battery
            action. Defaults to 0.5 kW (avoids unnecessary cycling for small imbalances).

    Attributes:
        num_actions: Number of discrete actions.
        balance_threshold: Energy balance threshold for action triggering.
        neutral_action: Action index for neutral (no action).

    Example:
        >>> controller = SelfConsumptionController(num_actions=21, balance_threshold=0.5)
        >>> obs = {'production': 5.0, 'consumption': 2.0, 'energy_balance': 3.0,
        ...        'upper_bound': 80.0, 'lower_bound': -80.0}
        >>> action = controller.choose_action(obs, {})
        >>> print(action)  # Returns charging action proportional to excess
    """

    def __init__(self, num_actions: int = 21, balance_threshold: float = 0.5) -> None:
        """
        Initialize self-consumption controller.

        Args:
            num_actions: Number of discrete actions. Must be odd for symmetric
                action space. Defaults to 21.
            balance_threshold: Minimum energy balance magnitude (kW) to trigger
                battery action. Defaults to 0.5 kW.

        Raises:
            AssertionError: If parameters are invalid.
        """
        assert num_actions % 2 == 1, 'num_actions must be odd for symmetric action space'
        assert num_actions >= 3, 'num_actions must be at least 3'
        assert balance_threshold >= 0, 'balance_threshold must be non-negative'

        self.num_actions = num_actions
        self.balance_threshold = balance_threshold
        self.neutral_action = num_actions // 2

    def choose_action(self, observation: dict[str, Any], info: dict[str, Any]) -> int:
        """
        Choose action based on energy balance and battery bounds.

        The controller calculates the action based on the energy balance
        (production - consumption) and maps it proportionally to the action space
        while respecting battery power constraints.

        Args:
            observation: Current observation dict, must contain:
                - 'energy_balance': Production - consumption (kW) [prosumer]
                  OR computed as production - 0 for producer nodes
                - 'upper_bound': Maximum charging power limit (% of nominal)
                - 'lower_bound': Maximum discharging power limit (% of nominal)
                - 'production': Production power (kW) [if energy_balance not present]
                - 'consumption': Consumption power (kW) [optional, defaults to 0]
            info: Additional information dict from environment (unused).

        Returns:
            Action index based on energy balance and battery constraints.
        """
        # extract energy balance
        if 'energy_balance' in observation:
            energy_balance = observation['energy_balance']
        else:
            # fallback: calculate from production and consumption
            production = observation.get('production', 0.0)
            consumption = observation.get('consumption', 0.0)
            energy_balance = production - consumption

        # extract power bounds (as percentage of nominal power)
        upper_bound_pct = observation.get('upper_bound', 100.0)  # % charging capacity
        lower_bound_pct = observation.get('lower_bound', -100.0)  # % discharging capacity

        # calculate maximum feasible actions based on battery bounds
        # upper_bound_pct is in [0, 100], map to action space [neutral, num_actions-1]
        max_charge_action = self.neutral_action + int(
            (upper_bound_pct / 100.0) * (self.num_actions // 2)
        )
        max_charge_action = min(self.num_actions - 1, max_charge_action)

        # lower_bound_pct is in [-100, 0], map to action space [0, neutral]
        max_discharge_action = self.neutral_action - int(
            (abs(lower_bound_pct) / 100.0) * (self.num_actions // 2)
        )
        max_discharge_action = max(0, max_discharge_action)

        # check if imbalance exceeds threshold
        if energy_balance > self.balance_threshold:
            # excess production: charge battery proportionally
            # calculate desired action based on energy imbalance
            # assume nominal power of 10 kW as reference (can be adjusted)
            desired_charge_pct = min(energy_balance / 10.0 * 100, 100.0)
            desired_action = self.neutral_action + int(
                (desired_charge_pct / 100.0) * (self.num_actions // 2)
            )

            # clip desired action to feasible bounds
            action = min(desired_action, max_charge_action)
            action = max(self.neutral_action, min(self.num_actions - 1, action))

            return action

        elif energy_balance < -self.balance_threshold:
            # deficit: discharge battery proportionally
            # calculate desired action based on energy imbalance
            desired_discharge_pct = min(abs(energy_balance) / 10.0 * 100, 100.0)
            desired_action = self.neutral_action - int(
                (desired_discharge_pct / 100.0) * (self.num_actions // 2)
            )

            # clip desired action to feasible bounds
            action = max(desired_action, max_discharge_action)
            action = max(0, min(self.neutral_action, action))

            return action

        else:
            # small imbalance: neutral action
            return self.neutral_action

    def __repr__(self) -> str:
        """
        Return string representation of the controller.

        Returns:
            String describing the controller configuration and policy.
        """
        return (
            f'SelfConsumptionController(num_actions={self.num_actions}, '
            f'balance_threshold={self.balance_threshold} kW, '
            f"policy='charge on excess production, discharge on deficit')"
        )
