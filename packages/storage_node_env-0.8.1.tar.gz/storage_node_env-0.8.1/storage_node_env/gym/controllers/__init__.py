"""
Rule-based controllers for battery energy storage systems.

This package provides rule-based controllers (RBCs) that implement fixed decision
policies for battery charge/discharge control. These controllers serve as baselines
for comparison with reinforcement learning agents.

Available Controllers:
    - NaiveController: No battery control (always neutral action)
    - PriceBasedController: Energy arbitrage based on price levels
    - SelfConsumptionController: Maximize local energy self-consumption

Example:
    >>> from storage_node_env.gym.controllers import (
    ...     NaiveController, PriceBasedController, SelfConsumptionController,
    ...     list_controllers
    ... )
    >>> # create a controller
    >>> controller = PriceBasedController(num_actions=21, window_size=168)
    >>> # use in evaluation loop
    >>> obs, info = env.reset()
    >>> action = controller.choose_action(obs, info)
    >>> obs, reward, terminated, truncated, info = env.step(action)
    >>> # list all available controllers
    >>> controllers_info = list_controllers()
    >>> for name, policy in controllers_info.items():
    ...     print(f'{name}: {policy}')
"""

from storage_node_env.gym.controllers.base import BaseController
from storage_node_env.gym.controllers.naive import NaiveController
from storage_node_env.gym.controllers.price_based import PriceBasedController
from storage_node_env.gym.controllers.self_consumption import SelfConsumptionController


def list_controllers() -> dict[str, str]:
    """
    List all available rule-based controllers and their decision policies.

    Returns:
        Dictionary mapping controller names to their decision policy descriptions.

    Example:
        >>> from storage_node_env.gym.controllers import list_controllers
        >>> controllers = list_controllers()
        >>> for name, policy in controllers.items():
        ...     print(f'{name}:')
        ...     print(f'  {policy}')
        NaiveController:
          Always neutral action (no battery control). Serves as baseline with zero battery intervention.
        PriceBasedController:
          Energy arbitrage based on electricity prices. Charges battery when prices are low (≤25th percentile) and discharges when prices are high (≥75th percentile). Uses rolling window of historical prices to respect causality.
        SelfConsumptionController:
          Maximizes local energy self-consumption. Charges battery during excess production (production > consumption) and discharges during deficit. Action magnitude is proportional to energy imbalance.
    """
    controllers_info = {
        'NaiveController': (
            'Always neutral action (no battery control). Serves as baseline with '
            'zero battery intervention.'
        ),
        'PriceBasedController': (
            'Energy arbitrage based on electricity prices. Charges battery when prices '
            'are low (≤25th percentile) and discharges when prices are high '
            '(≥75th percentile). Uses rolling window of historical prices to respect '
            'causality.'
        ),
        'SelfConsumptionController': (
            'Maximizes local energy self-consumption. Charges battery during excess '
            'production (production > consumption) and discharges during deficit. '
            'Action magnitude is proportional to energy imbalance.'
        ),
    }
    return controllers_info


def print_controllers() -> None:
    """
    Print detailed information about all available controllers.

    This function provides a formatted display of all controllers and their
    decision policies.

    Example:
        >>> from storage_node_env.gym.controllers import print_controllers
        >>> print_controllers()
        Available Rule-Based Controllers:
        ================================================================================
        <BLANKLINE>
        NaiveController:
          Always neutral action (no battery control). Serves as baseline with zero
          battery intervention.
        <BLANKLINE>
        PriceBasedController:
          Energy arbitrage based on electricity prices. Charges battery when prices
          are low (≤25th percentile) and discharges when prices are high
          (≥75th percentile). Uses rolling window of historical prices to respect
          causality.
        <BLANKLINE>
        SelfConsumptionController:
          Maximizes local energy self-consumption. Charges battery during excess
          production (production > consumption) and discharges during deficit.
          Action magnitude is proportional to energy imbalance.
    """
    controllers = list_controllers()

    print('Available Rule-Based Controllers:')
    print('=' * 80)
    print()

    for name, policy in controllers.items():
        print(f'{name}:')
        # wrap text at 78 characters with 2-space indentation
        words = policy.split()
        line = '  '
        for word in words:
            if len(line) + len(word) + 1 > 78:
                print(line)
                line = '  ' + word
            else:
                if line == '  ':
                    line += word
                else:
                    line += ' ' + word
        print(line)
        print()


__all__ = [
    'BaseController',
    'NaiveController',
    'PriceBasedController',
    'SelfConsumptionController',
    'list_controllers',
    'print_controllers',
]
