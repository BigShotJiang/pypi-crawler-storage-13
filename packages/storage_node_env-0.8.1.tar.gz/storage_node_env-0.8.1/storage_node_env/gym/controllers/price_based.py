"""
Price-based controller for energy arbitrage optimization.

This module implements a rule-based controller that charges/discharges the battery
based on electricity price levels, using a rolling window to calculate dynamic
price thresholds while respecting causality constraints.
"""

from typing import Any

import numpy as np

from storage_node_env.gym.controllers.base import BaseController


class PriceBasedController(BaseController):
    """
    Price-based controller for energy arbitrage.

    This controller implements a simple energy arbitrage strategy:
    - Charge battery when prices are low (below 25th percentile)
    - Discharge battery when prices are high (above 75th percentile)
    - Remain neutral at medium prices

    The controller respects causality by only using historical prices to compute
    thresholds. Price percentiles are calculated from a rolling window of past
    buy prices, ensuring the controller cannot look into the future.

    Physical constraints are respected by clipping actions to battery power bounds
    based on the current state of charge, preventing violations of charge/discharge
    limits.

    Decision Policy:
        - If buy_price <= p25: Charge at 50% power (action = 75% of action range)
        - If buy_price >= p75: Discharge at 50% power (action = 25% of action range)
        - Otherwise: Neutral action (no battery control)
        - All actions are clipped to respect battery bounds from observation

    Args:
        num_actions: Number of discrete actions in the action space (must be odd).
        window_size: Number of past timesteps for rolling window percentile
            calculation. Defaults to 168 (1 week with hourly data).
        charge_action_pct: Percentage of action range for charging (0-100).
            Defaults to 75 (maps to 50% of nominal power).
        discharge_action_pct: Percentage of action range for discharging (0-100).
            Defaults to 25 (maps to -50% of nominal power).

    Attributes:
        num_actions: Number of discrete actions.
        window_size: Rolling window size for price percentiles.
        charge_action: Action index for charging.
        discharge_action: Action index for discharging.
        neutral_action: Action index for neutral (no action).
        price_history: List storing historical buy prices.

    Example:
        >>> controller = PriceBasedController(num_actions=21, window_size=168)
        >>> obs = {'buy_price': 0.25, 'sell_price': 0.10,
        ...        'upper_bound': 80.0, 'lower_bound': -100.0}
        >>> action = controller.choose_action(obs, {})
        >>> print(action)  # Returns charge/discharge/neutral based on price
    """

    def __init__(
        self,
        num_actions: int = 21,
        window_size: int = 168,
        charge_action_pct: float = 75.0,
        discharge_action_pct: float = 25.0,
    ) -> None:
        """
        Initialize price-based controller.

        Args:
            num_actions: Number of discrete actions. Must be odd for symmetric
                action space. Defaults to 21.
            window_size: Number of past timesteps for rolling window. Defaults to
                168 (1 week of hourly data).
            charge_action_pct: Percentage of action range for charging (0-100).
                Defaults to 75.0 (50% charging power).
            discharge_action_pct: Percentage of action range for discharging (0-100).
                Defaults to 25.0 (50% discharging power).

        Raises:
            AssertionError: If parameters are invalid.
        """
        assert num_actions % 2 == 1, 'num_actions must be odd for symmetric action space'
        assert num_actions >= 3, 'num_actions must be at least 3'
        assert window_size > 0, 'window_size must be positive'
        assert 0 <= charge_action_pct <= 100, 'charge_action_pct must be in [0, 100]'
        assert 0 <= discharge_action_pct <= 100, 'discharge_action_pct must be in [0, 100]'

        self.num_actions = num_actions
        self.window_size = window_size

        # calculate action indices from percentages
        self.charge_action = int(num_actions * charge_action_pct / 100)
        self.discharge_action = int(num_actions * discharge_action_pct / 100)
        self.neutral_action = num_actions // 2

        # clip to valid range
        self.charge_action = max(self.neutral_action, min(num_actions - 1, self.charge_action))
        self.discharge_action = max(0, min(self.neutral_action, self.discharge_action))

        # rolling window for price history (respects causality)
        self.price_history: list[float] = []

    def choose_action(self, observation: dict[str, Any], info: dict[str, Any]) -> int:
        """
        Choose action based on current price and historical price distribution.

        The controller compares the current buy price against the 25th and 75th
        percentiles of recent historical prices:
        - Low price (≤ p25): Charge battery to store cheap energy
        - High price (≥ p75): Discharge battery to avoid expensive energy
        - Medium price: Neutral (no battery action)

        Physical constraints are respected by clipping actions to battery power bounds
        based on current state of charge.

        Args:
            observation: Current observation dict, must contain:
                - 'buy_price': Current electricity purchase price (€/kWh)
                - 'upper_bound': Maximum charging power limit (% of nominal, 0-100)
                - 'lower_bound': Maximum discharging power limit (% of nominal, -100-0)
            info: Additional information dict from environment (unused).

        Returns:
            Action index based on price comparison with historical percentiles,
            clipped to respect physical battery constraints.
        """
        # extract current buy price
        buy_price = observation['buy_price']

        # extract power bounds (as percentage of nominal power)
        upper_bound_pct = observation.get('upper_bound', 100.0)  # % charging capacity
        lower_bound_pct = observation.get('lower_bound', -100.0)  # % discharging capacity

        # add current price to history (for next timestep - respects causality)
        self.price_history.append(buy_price)

        # maintain rolling window
        if len(self.price_history) > self.window_size:
            self.price_history.pop(0)

        # need at least 4 prices to compute meaningful percentiles
        if len(self.price_history) < 4:
            return self.neutral_action

        # calculate price percentiles from history (excluding current price)
        # use history up to previous timestep to respect causality
        historical_prices = self.price_history[:-1]
        p25 = np.percentile(historical_prices, 25)
        p75 = np.percentile(historical_prices, 75)

        # calculate maximum feasible actions based on battery bounds
        # upper_bound_pct is in [0, 100], map to action space [neutral, num_actions-1]
        max_charge_action = self.neutral_action + int(
            (upper_bound_pct / 100.0) * (self.num_actions // 2)
        )
        max_charge_action = min(self.num_actions - 1, max_charge_action)

        # lower_bound_pct is in [-100, 0], map to action space [0, neutral]
        max_discharge_action = self.neutral_action - int(
            (abs(lower_bound_pct) / 100.0) * (self.num_actions // 2)
        )
        max_discharge_action = max(0, max_discharge_action)

        # decision logic based on price levels
        if buy_price <= p25:
            # low price: charge battery (clipped to feasible bounds)
            return min(self.charge_action, max_charge_action)
        elif buy_price >= p75:
            # high price: discharge battery (clipped to feasible bounds)
            return max(self.discharge_action, max_discharge_action)
        else:
            # medium price: neutral
            return self.neutral_action

    def reset(self) -> None:
        """
        Reset controller state (clear price history).

        Call this method when starting a new episode to ensure clean state.
        """
        self.price_history = []

    def __repr__(self) -> str:
        """
        Return string representation of the controller.

        Returns:
            String describing the controller configuration and policy.
        """
        return (
            f'PriceBasedController(num_actions={self.num_actions}, '
            f'window_size={self.window_size}, '
            f"policy='charge on low prices (≤p25), discharge on high prices (≥p75)')"
        )
