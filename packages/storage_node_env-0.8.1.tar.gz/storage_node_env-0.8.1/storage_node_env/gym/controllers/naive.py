"""
Naive controller that always selects the neutral action.

This module implements a baseline controller that performs no battery control,
always selecting the neutral action (zero power).
"""

from typing import Any

from storage_node_env.gym.controllers.base import BaseController


class NaiveController(BaseController):
    """
    Naive baseline controller with no battery control.

    This controller always selects the neutral action (middle of the action space),
    which corresponds to zero battery power (no charging or discharging). It serves
    as a baseline for evaluating the performance of more sophisticated control
    strategies.

    Without battery control, the system relies entirely on direct grid exchange:
    - Excess production is exported to the grid
    - Deficit is imported from the grid
    - Battery state of charge remains constant (except for parasitic losses)

    Args:
        num_actions: Number of discrete actions in the action space (must be odd).

    Attributes:
        num_actions: Number of discrete actions.
        neutral_action: Index of neutral action (num_actions // 2).

    Example:
        >>> controller = NaiveController(num_actions=21)
        >>> obs = {'production': 5.0, 'consumption': 2.0}
        >>> action = controller.choose_action(obs, {})
        >>> print(action)  # Always returns 10 (neutral)
        10
    """

    def __init__(self, num_actions: int = 21) -> None:
        """
        Initialize naive controller.

        Args:
            num_actions: Number of discrete actions. Must be odd for symmetric
                action space. Defaults to 21.

        Raises:
            AssertionError: If num_actions is not odd.
        """
        assert num_actions % 2 == 1, 'num_actions must be odd for symmetric action space'
        assert num_actions >= 3, 'num_actions must be at least 3'

        self.num_actions = num_actions
        self.neutral_action = num_actions // 2

    def choose_action(self, observation: dict[str, Any], info: dict[str, Any]) -> int:
        """
        Choose action (always returns neutral action).

        Args:
            observation: Current observation dict from environment (unused).
            info: Additional information dict from environment (unused).

        Returns:
            Neutral action index (num_actions // 2).
        """
        return self.neutral_action

    def __repr__(self) -> str:
        """
        Return string representation of the controller.

        Returns:
            String describing the controller configuration and policy.
        """
        return (
            f'NaiveController(num_actions={self.num_actions}, '
            f"policy='always neutral (no battery control)')"
        )
