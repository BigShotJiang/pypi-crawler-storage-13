"""
Base controller interface for rule-based battery control strategies.

This module defines the abstract base class for implementing rule-based controllers
that select battery charge/discharge actions based on fixed decision rules.
"""

from abc import ABC, abstractmethod
from typing import Any


class BaseController(ABC):
    """
    Abstract base class for rule-based battery controllers.

    Rule-based controllers (RBCs) implement fixed decision policies for battery
    energy storage systems. They are used as baselines for comparison with
    reinforcement learning agents.

    All concrete controllers must implement:
        - choose_action(): Select action based on observation and info
        - __repr__(): String representation describing the controller's policy

    Example:
        >>> class MyController(BaseController):
        ...     def choose_action(self, observation, info):
        ...         return 10  # neutral action
        ...     def __repr__(self):
        ...         return 'MyController(policy=neutral)'
    """

    @abstractmethod
    def choose_action(self, observation: dict[str, Any], info: dict[str, Any]) -> int:
        """
        Choose a discrete action based on current observation and info.

        This method implements the controller's decision policy. It receives the
        same observation and info dictionaries provided by the Gymnasium environment
        and must return a discrete action index.

        Args:
            observation: Current observation dict from environment, containing:
                - timestamp: Current timestep index
                - production: Current production power (kW)
                - consumption: Current consumption power (kW) [prosumer only]
                - buy_price: Grid purchase price (€/kWh)
                - sell_price: Grid selling price (€/kWh)
                - energy_balance: Production - consumption (kW) [prosumer only]
                - final_soc: Battery state of charge after previous action (%)
                - upper_bound: Maximum charging power limit (%)
                - lower_bound: Maximum discharging power limit (%)
                - (additional temporal and lookback features)
            info: Additional information dict from environment, containing:
                - P_grid: Grid power exchange (kW)
                - P_import: Power imported from grid (kW)
                - P_export: Power exported to grid (kW)
                - E_import: Energy imported (kWh)
                - E_export: Energy exported (kWh)
                - cost_import: Import cost (€)
                - revenue_export: Export revenue (€)
                - net_cost: Net cost (€) [prosumer] or net_profit (€) [producer]
                - violation: Power constraint violation (kW)

        Returns:
            Action index in discrete action space [0, num_actions-1], where:
                - 0 = maximum discharge
                - num_actions // 2 = neutral (no battery action)
                - num_actions - 1 = maximum charge

        Example:
            >>> obs = {'production': 5.0, 'consumption': 2.0, 'final_soc': 50.0}
            >>> info = {'P_grid': -3.0, 'net_cost': 0.5}
            >>> action = controller.choose_action(obs, info)
            >>> print(action)  # e.g., 15 (charge action)
        """
        pass

    @abstractmethod
    def __repr__(self) -> str:
        """
        Return string representation of the controller.

        Returns:
            String describing the controller type and its decision policy.

        Example:
            >>> controller = NaiveController(num_actions=21)
            >>> print(controller)
            NaiveController(num_actions=21, policy='always neutral')
        """
        pass
