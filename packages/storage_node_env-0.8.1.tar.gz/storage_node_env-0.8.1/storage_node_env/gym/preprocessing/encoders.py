"""
Encoding functions for observation preprocessing.

This module provides various encoding strategies for transforming raw features
into normalized representations suitable for reinforcement learning.
"""

import numpy as np


def encode_cyclical(value: float, max_value: float) -> tuple[float, float]:
    """
    Encode a cyclical feature using sine and cosine transformation.

    This encoding preserves the cyclical nature of temporal features
    (e.g., hour 23 is close to hour 0).

    Args:
        value: The raw feature value (e.g., hour=14, month=3).
        max_value: The maximum value for the cycle (e.g., 24 for hours, 12 for months).

    Returns:
        Tuple containing (sin_encoded, cos_encoded), both in range [-1, 1].

    Example:
        >>> sin_h, cos_h = encode_cyclical(12, 24)  # noon
        >>> print(f'sin={sin_h:.3f}, cos={cos_h:.3f}')
        sin=0.000, cos=-1.000
    """
    # normalize to [0, 2π]
    angle = 2.0 * np.pi * value / max_value
    sin_encoded = np.sin(angle)
    cos_encoded = np.cos(angle)
    return float(sin_encoded), float(cos_encoded)


def encode_binary(value: bool | int | float) -> float:
    """
    Encode a binary feature to 0.0 or 1.0.

    Args:
        value: Boolean or numeric value to encode.

    Returns:
        1.0 if value is truthy, 0.0 otherwise.

    Example:
        >>> encode_binary(True)
        1.0
        >>> encode_binary(0)
        0.0
    """
    return 1.0 if value else 0.0


def normalize_minmax(
    value: float,
    min_val: float,
    max_val: float,
    clip: bool = True
) -> float:
    """
    Normalize a value to [0, 1] range using min-max scaling.

    Args:
        value: The raw value to normalize.
        min_val: Minimum value of the feature range.
        max_val: Maximum value of the feature range.
        clip: If True, clip the result to [0, 1]. Defaults to True.

    Returns:
        Normalized value in [0, 1] range (if clipped).

    Raises:
        ValueError: If min_val == max_val (constant feature).

    Example:
        >>> normalize_minmax(2.5, 0, 5)
        0.5
        >>> normalize_minmax(7, 0, 5, clip=True)
        1.0
    """
    if min_val == max_val:
        # constant feature, cannot normalize
        raise ValueError(
            f'Cannot normalize constant feature: min={min_val}, max={max_val}'
        )

    normalized = (value - min_val) / (max_val - min_val)

    if clip:
        normalized = np.clip(normalized, 0.0, 1.0)

    return float(normalized)


def normalize_symmetric(
    value: float,
    abs_max: float,
    clip: bool = True
) -> float:
    """
    Normalize a value to [-1, 1] range using symmetric scaling.

    Useful for features that can be positive or negative (e.g., energy_balance).

    Args:
        value: The raw value to normalize.
        abs_max: Maximum absolute value of the feature range.
        clip: If True, clip the result to [-1, 1]. Defaults to True.

    Returns:
        Normalized value in [-1, 1] range (if clipped).

    Raises:
        ValueError: If abs_max == 0 (constant feature).

    Example:
        >>> normalize_symmetric(5, 10)
        0.5
        >>> normalize_symmetric(-5, 10)
        -0.5
    """
    if abs_max == 0:
        raise ValueError('Cannot normalize with abs_max=0')

    normalized = value / abs_max

    if clip:
        normalized = np.clip(normalized, -1.0, 1.0)

    return float(normalized)
