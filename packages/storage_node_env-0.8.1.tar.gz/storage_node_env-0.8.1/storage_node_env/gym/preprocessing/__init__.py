"""
Observation preprocessing package for energy storage environments.

This package provides modular and extensible preprocessing for observations,
including cyclical encoding, normalization, and feature engineering.
"""

from storage_node_env.gym.preprocessing.encoders import (
    encode_binary,
    encode_cyclical,
    normalize_minmax,
    normalize_symmetric,
)
from storage_node_env.gym.preprocessing.feature_config import (
    FEATURE_REGISTRY,
    OBSERVATION_SCHEMA,
    EncodingType,
    FeatureConfig,
    calculate_encoded_observation_dim_from_registry,
    calculate_raw_observation_dim,
    calculate_total_output_dim,
    get_all_feature_names,
    get_current_features,
    get_feature_config,
    get_lookback_features,
    get_observation_offsets,
    get_temporal_features,
    register_feature,
)
from storage_node_env.gym.preprocessing.normalizers import MinMaxNormalizer


__all__ = [
    # encoders
    'encode_cyclical',
    'encode_binary',
    'normalize_minmax',
    'normalize_symmetric',
    # normalizers
    'MinMaxNormalizer',
    # feature config
    'FeatureConfig',
    'EncodingType',
    'FEATURE_REGISTRY',
    'OBSERVATION_SCHEMA',
    'get_feature_config',
    'register_feature',
    'get_all_feature_names',
    'calculate_total_output_dim',
    'get_temporal_features',
    'get_current_features',
    'get_lookback_features',
    'calculate_raw_observation_dim',
    'calculate_encoded_observation_dim_from_registry',
    'get_observation_offsets',
]
