"""
Normalization classes for feature scaling.

This module provides classes for computing and applying min-max normalization
based on dataset statistics.
"""

from typing import Any

import numpy as np
import pandas as pd

from storage_node_env.gym.preprocessing.encoders import normalize_minmax


class MinMaxNormalizer:
    """
    Min-max normalizer for numerical features.

    Computes min/max statistics from dataset and provides normalization
    for specified features. Handles edge cases like constant features (min=max).

    Attributes:
        bounds: Dictionary mapping feature names to (min, max) tuples.
        skip_features: Set of feature names to skip (constant features).
    """

    def __init__(self) -> None:
        """Initialize an empty normalizer."""
        self.bounds: dict[str, tuple[float, float]] = {}
        self.skip_features: set[str] = set()

    def fit(self, data: pd.DataFrame, features: list[str]) -> None:
        """
        Compute min/max bounds from dataset for specified features.

        Args:
            data: DataFrame containing the feature columns.
            features: List of feature names to compute bounds for.

        Raises:
            KeyError: If a feature is not found in the data.

        Example:
            >>> normalizer = MinMaxNormalizer()
            >>> normalizer.fit(df, ['production', 'consumption'])
            >>> print(normalizer.bounds)
            {'production': (0.0, 7.09), 'consumption': (0.96, 4.0)}
        """
        for feature in features:
            if feature not in data.columns:
                raise KeyError(f'Feature "{feature}" not found in data columns')

            min_val = float(data[feature].min())
            max_val = float(data[feature].max())

            # check if constant feature (min == max)
            if np.isclose(min_val, max_val, rtol=1e-9, atol=1e-9):
                self.skip_features.add(feature)
                # store bounds anyway for reference
                self.bounds[feature] = (min_val, max_val)
            else:
                self.bounds[feature] = (min_val, max_val)

    def transform(self, value: float, feature_name: str, clip: bool = True) -> float:
        """
        Normalize a single value using pre-computed bounds.

        Args:
            value: The raw value to normalize.
            feature_name: Name of the feature (must be in bounds).
            clip: If True, clip result to [0, 1]. Defaults to True.

        Returns:
            Normalized value in [0, 1], or original value if feature is skipped.

        Raises:
            KeyError: If feature_name is not in bounds.

        Example:
            >>> normalizer.transform(3.5, 'production')
            0.493
        """
        if feature_name not in self.bounds:
            raise KeyError(f'Feature "{feature_name}" not found in normalizer bounds')

        # skip normalization for constant features
        if feature_name in self.skip_features:
            return value

        min_val, max_val = self.bounds[feature_name]
        return normalize_minmax(value, min_val, max_val, clip=clip)

    def get_bounds(self, feature_name: str) -> tuple[float, float]:
        """
        Get the min/max bounds for a feature.

        Args:
            feature_name: Name of the feature.

        Returns:
            Tuple of (min_value, max_value).

        Raises:
            KeyError: If feature_name is not in bounds.
        """
        if feature_name not in self.bounds:
            raise KeyError(f'Feature "{feature_name}" not found in normalizer bounds')
        return self.bounds[feature_name]

    def is_skipped(self, feature_name: str) -> bool:
        """
        Check if a feature is skipped (constant).

        Args:
            feature_name: Name of the feature.

        Returns:
            True if the feature is constant and normalization is skipped.
        """
        return feature_name in self.skip_features

    def __repr__(self) -> str:
        """Return string representation of normalizer."""
        return (
            f'MinMaxNormalizer(features={len(self.bounds)}, '
            f'skipped={len(self.skip_features)})'
        )
