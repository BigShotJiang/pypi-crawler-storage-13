"""
Feature configuration and registry for observation preprocessing.

This module defines the structure and metadata for all observable features,
making it easy to add new features in the future.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any


class EncodingType(Enum):
    """Types of encoding strategies for features."""

    CYCLICAL = 'cyclical'  # sin/cos encoding for temporal features
    BINARY = 'binary'  # binary 0/1 encoding
    MINMAX = 'minmax'  # min-max normalization to [0, 1]
    SYMMETRIC = 'symmetric'  # symmetric normalization to [-1, 1]
    RAW = 'raw'  # no encoding (pass-through)


@dataclass
class FeatureConfig:
    """
    Configuration for a single observable feature.

    Attributes:
        name: Feature name (e.g., 'production', 'hour').
        encoding_type: Type of encoding to apply.
        output_dim: Number of output dimensions after encoding.
        bounds: Optional (min, max) bounds for normalization.
        max_value: Optional max value for cyclical encoding.
        description: Human-readable description of the feature.
    """

    name: str
    encoding_type: EncodingType
    output_dim: int
    bounds: tuple[float, float] | None = None
    max_value: float | None = None
    description: str = ''

    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        if self.encoding_type == EncodingType.CYCLICAL:
            if self.max_value is None:
                raise ValueError(
                    f'Feature "{self.name}" with CYCLICAL encoding requires max_value'
                )
            if self.output_dim != 2:
                raise ValueError(
                    f'Feature "{self.name}" with CYCLICAL encoding must have output_dim=2'
                )

        if self.encoding_type in (EncodingType.MINMAX, EncodingType.SYMMETRIC):
            # bounds can be None initially, will be set during fit()
            if self.output_dim != 1:
                raise ValueError(
                    f'Feature "{self.name}" with {self.encoding_type.value} encoding '
                    f'must have output_dim=1'
                )

        if self.encoding_type == EncodingType.BINARY:
            if self.output_dim != 1:
                raise ValueError(
                    f'Feature "{self.name}" with BINARY encoding must have output_dim=1'
                )


# feature registry: defines all features and their encoding strategies
FEATURE_REGISTRY: dict[str, FeatureConfig] = {
    # temporal features (cyclical encoding)
    'year': FeatureConfig(
        name='year',
        encoding_type=EncodingType.CYCLICAL,
        output_dim=2,
        max_value=10.0,  # assume data within 10-year span
        description='Year component of timestamp (cyclical)'
    ),
    'month': FeatureConfig(
        name='month',
        encoding_type=EncodingType.CYCLICAL,
        output_dim=2,
        max_value=12.0,
        description='Month of year (1-12, cyclical)'
    ),
    'day': FeatureConfig(
        name='day',
        encoding_type=EncodingType.CYCLICAL,
        output_dim=2,
        max_value=31.0,
        description='Day of month (1-31, cyclical)'
    ),
    'hour': FeatureConfig(
        name='hour',
        encoding_type=EncodingType.CYCLICAL,
        output_dim=2,
        max_value=24.0,
        description='Hour of day (0-23, cyclical)'
    ),
    'quarter': FeatureConfig(
        name='quarter',
        encoding_type=EncodingType.CYCLICAL,
        output_dim=2,
        max_value=4.0,
        description='Quarter hour (0-3, representing 0/15/30/45 min, cyclical)'
    ),
    # holiday feature (binary)
    'is_holiday': FeatureConfig(
        name='is_holiday',
        encoding_type=EncodingType.BINARY,
        output_dim=1,
        description='Binary indicator for Italian holidays (0=workday, 1=holiday)'
    ),
    # power/energy features (min-max normalization)
    'production': FeatureConfig(
        name='production',
        encoding_type=EncodingType.MINMAX,
        output_dim=1,
        description='Power produced (kW), normalized to [0, 1]'
    ),
    'consumption': FeatureConfig(
        name='consumption',
        encoding_type=EncodingType.MINMAX,
        output_dim=1,
        description='Power consumed (kW), normalized to [0, 1]'
    ),
    'buy_price': FeatureConfig(
        name='buy_price',
        encoding_type=EncodingType.MINMAX,
        output_dim=1,
        description='Grid purchase price (€/kWh), normalized to [0, 1]'
    ),
    'sell_price': FeatureConfig(
        name='sell_price',
        encoding_type=EncodingType.MINMAX,
        output_dim=1,
        description='Grid selling price (€/kWh), normalized to [0, 1]'
    ),
    'energy_balance': FeatureConfig(
        name='energy_balance',
        encoding_type=EncodingType.MINMAX,
        output_dim=1,
        description='Energy balance: production - consumption (kW), normalized to [0, 1]'
    ),
    # battery state features (min-max normalization, already in %)
    'final_soc': FeatureConfig(
        name='final_soc',
        encoding_type=EncodingType.MINMAX,
        output_dim=1,
        bounds=(0.0, 100.0),
        description='Battery state of charge (%), normalized to [0, 1]'
    ),
    'upper_bound': FeatureConfig(
        name='upper_bound',
        encoding_type=EncodingType.MINMAX,
        output_dim=1,
        bounds=(0.0, 100.0),
        description='Max charge power bound (% of P_cha_max), normalized to [0, 1]'
    ),
    'lower_bound': FeatureConfig(
        name='lower_bound',
        encoding_type=EncodingType.MINMAX,
        output_dim=1,
        bounds=(-100.0, 0.0),
        description='Max discharge power bound (% of P_dis_max), normalized to [0, 1]'
    ),
}


def get_feature_config(feature_name: str) -> FeatureConfig:
    """
    Get configuration for a feature.

    Args:
        feature_name: Name of the feature.

    Returns:
        FeatureConfig object for the feature.

    Raises:
        KeyError: If feature is not in registry.
    """
    if feature_name not in FEATURE_REGISTRY:
        raise KeyError(f'Feature "{feature_name}" not found in registry')
    return FEATURE_REGISTRY[feature_name]


def register_feature(config: FeatureConfig) -> None:
    """
    Register a new feature in the registry.

    Useful for adding custom features at runtime.

    Args:
        config: FeatureConfig object for the new feature.

    Example:
        >>> new_feature = FeatureConfig(
        ...     name='temperature',
        ...     encoding_type=EncodingType.MINMAX,
        ...     output_dim=1,
        ...     description='Ambient temperature (°C)'
        ... )
        >>> register_feature(new_feature)
    """
    FEATURE_REGISTRY[config.name] = config


def get_all_feature_names() -> list[str]:
    """
    Get list of all registered feature names.

    Returns:
        List of feature names in registry.
    """
    return list(FEATURE_REGISTRY.keys())


def calculate_total_output_dim(feature_names: list[str]) -> int:
    """
    Calculate total output dimension for a list of features.

    Args:
        feature_names: List of feature names to include.

    Returns:
        Total number of output dimensions after encoding.

    Example:
        >>> calculate_total_output_dim(['hour', 'production', 'is_holiday'])
        4  # hour: 2 (sin/cos), production: 1, is_holiday: 1
    """
    total_dim = 0
    for name in feature_names:
        config = get_feature_config(name)
        total_dim += config.output_dim
    return total_dim


# observation schema: defines which features belong to each section of the observation
OBSERVATION_SCHEMA: dict[str, list[str]] = {
    'temporal': ['year', 'month', 'day', 'hour', 'quarter'],
    'current': [
        'production', 'consumption', 'buy_price', 'sell_price',
        'energy_balance', 'final_soc', 'upper_bound', 'lower_bound'
    ],
    'lookback': ['production', 'consumption', 'energy_balance', 'final_soc']
}


def get_temporal_features() -> list[str]:
    """
    Get list of temporal features in observation order.

    Returns:
        List of temporal feature names.

    Example:
        >>> get_temporal_features()
        ['year', 'month', 'day', 'hour', 'quarter']
    """
    return OBSERVATION_SCHEMA['temporal']


def get_current_features() -> list[str]:
    """
    Get list of current state features in observation order.

    Returns:
        List of current state feature names.

    Example:
        >>> get_current_features()
        ['production', 'consumption', 'buy_price', 'sell_price', ...]
    """
    return OBSERVATION_SCHEMA['current']


def get_lookback_features() -> list[str]:
    """
    Get list of lookback features in observation order.

    Returns:
        List of lookback feature names (subset of current features).

    Example:
        >>> get_lookback_features()
        ['production', 'consumption', 'energy_balance', 'final_soc']
    """
    return OBSERVATION_SCHEMA['lookback']


def calculate_raw_observation_dim(lookback_n: int) -> int:
    """
    Calculate raw observation dimension from schema.

    Args:
        lookback_n: Number of lookback timesteps.

    Returns:
        Total dimension of raw observation array.

    Note:
        Raw observation structure:
        - Temporal: year, month, day, hour, quarter (5 values)
        - Current state: production, consumption, etc. (8 values)
        - Lookback: subset of current features × lookback_n timesteps (4 × n values)

    Example:
        >>> calculate_raw_observation_dim(lookback_n=2)
        21  # 5 temporal + 8 current + (4 × 2) lookback
    """
    temporal_count = len(get_temporal_features())
    current_count = len(get_current_features())
    lookback_count = len(get_lookback_features())
    return temporal_count + current_count + (lookback_count * lookback_n)


def calculate_encoded_observation_dim_from_registry(
    lookback_n: int,
    add_holiday: bool = True
) -> int:
    """
    Calculate encoded observation dimension using feature registry.

    This function dynamically calculates the dimension based on the actual
    features defined in OBSERVATION_SCHEMA and their encoding properties
    in FEATURE_REGISTRY.

    Args:
        lookback_n: Number of lookback timesteps.
        add_holiday: Whether holiday feature is included. Defaults to True.

    Returns:
        Total dimension of encoded observation array.

    Note:
        Encoded observation structure:
        - Temporal features: cyclical encoding (sin/cos) → 2 × num_features
        - Holiday feature: binary (0/1) → 1 value (if add_holiday=True)
        - Current state: normalized → 1 × num_features
        - Lookback: normalized → 1 × num_features × lookback_n

    Example:
        >>> calculate_encoded_observation_dim_from_registry(lookback_n=2, add_holiday=True)
        27  # 10 temporal (5×2) + 1 holiday + 8 current + 8 lookback (4×2)
    """
    temporal_dim = calculate_total_output_dim(get_temporal_features())
    holiday_dim = 1 if add_holiday else 0
    current_dim = calculate_total_output_dim(get_current_features())
    lookback_dim = calculate_total_output_dim(get_lookback_features()) * lookback_n
    return temporal_dim + holiday_dim + current_dim + lookback_dim


def get_observation_offsets(lookback_n: int) -> dict[str, dict[str, int]]:
    """
    Calculate start/end offsets for each section in raw observation array.

    Args:
        lookback_n: Number of lookback timesteps.

    Returns:
        Dictionary mapping section names to offset information:
            - 'start': Starting index in observation array
            - 'end': Ending index (exclusive) in observation array
            - 'count': Total number of features in section
            - 'per_timestep': Features per timestep (for lookback only)

    Example:
        >>> offsets = get_observation_offsets(lookback_n=2)
        >>> offsets['temporal']
        {'start': 0, 'end': 5, 'count': 5}
        >>> offsets['current']
        {'start': 5, 'end': 13, 'count': 8}
        >>> offsets['lookback']
        {'start': 13, 'end': 21, 'count': 8, 'per_timestep': 4}
    """
    temporal = get_temporal_features()
    current = get_current_features()
    lookback = get_lookback_features()

    temporal_start = 0
    temporal_end = len(temporal)

    current_start = temporal_end
    current_end = current_start + len(current)

    lookback_start = current_end
    lookback_end = lookback_start + (len(lookback) * lookback_n)

    return {
        'temporal': {
            'start': temporal_start,
            'end': temporal_end,
            'count': len(temporal)
        },
        'current': {
            'start': current_start,
            'end': current_end,
            'count': len(current)
        },
        'lookback': {
            'start': lookback_start,
            'end': lookback_end,
            'count': len(lookback) * lookback_n,
            'per_timestep': len(lookback)
        }
    }
