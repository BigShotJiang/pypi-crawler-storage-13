"""
Gymnasium environment for energy storage systems.

This module provides a Gymnasium-compliant environment for reinforcement learning
with energy nodes (Producer/Prosumer) and battery energy storage systems.
"""

from typing import Any

import gymnasium as gym
from gymnasium import spaces
import numpy as np

from storage_node_env.core import Battery, Producer, Prosumer
from storage_node_env.gym.preprocessing.observation_encoders import (
    ObservationEncoder,
    create_encoder_from_data,
)
from storage_node_env.gym.rewards import (
    RewardCalculator,
    create_reward_calculator,
    get_default_reward_settings,
    validate_reward_settings,
)
from storage_node_env.gym.tracking import ResultsTracker
from storage_node_env.gym.tracking.utils import save_dataframe_to_csv
from storage_node_env.gym.utils import (
    build_observation,
    build_terminal_observation,
    calculate_encoded_observation_dim,
    calculate_observation_dim,
    is_episode_truncated,
    split_timestamp,
    update_lookback_buffer,
)


class EnergyStorageEnv(gym.Env):
    """
    Gymnasium environment for energy storage optimization.

    This environment simulates an energy node (Producer or Prosumer) with battery
    storage, compatible with Stable-Baselines3 and other RL libraries.

    Attributes:
        node_type: Type of energy node ('producer' or 'prosumer').
        node: Energy node instance (Producer or Prosumer).
        battery: Battery storage system instance.
        lookback_n: Number of historical timesteps in observation.
        num_actions: Size of discrete action space.
        action_space: Gymnasium discrete action space.
        observation_space: Gymnasium box observation space.
        time_step: Current timestep index (property delegating to node.time_step).

    Example:
        >>> battery_config = {
        ...     'capacity': 5.12,
        ...     'dod_max': 90,
        ...     'power_charge_max': 2.5,
        ...     'power_discharge_max': 2.5,
        ...     'efficiency_charge': 0.95,
        ...     'efficiency_discharge': 0.95
        ... }
        >>> env = EnergyStorageEnv(
        ...     node_type='prosumer',
        ...     csv_path='dataset/1h/prosumer_test_data.csv',
        ...     battery_config=battery_config,
        ...     delta_t=1.0,
        ...     lookback_n=2
        ... )
        >>> obs, info = env.reset()
        >>> obs, reward, terminated, truncated, info = env.step(10)
    """

    metadata = {'render_modes': []}

    def __init__(
        self,
        node_type: str,
        csv_path: str,
        battery_config: dict[str, float],
        delta_t: float,
        lookback_n: int = 2,
        num_actions: int = 21,
        use_preprocessing: bool = False,
        add_holiday: bool = True,
        reward_settings: dict[str, Any] | None = None,
        track_results: bool = False
    ) -> None:
        """
        Initialize the energy storage environment.

        Args:
            node_type: Type of node - 'producer' or 'prosumer'.
            csv_path: Path to CSV file with historical data.
            battery_config: Dictionary with battery parameters:
                - capacity: Nominal capacity (kWh)
                - dod_max: Maximum depth of discharge (%)
                - power_charge_max: Maximum charging power (kW)
                - power_discharge_max: Maximum discharging power (kW)
                - efficiency_charge: Charging efficiency (0-1)
                - efficiency_discharge: Discharging efficiency (0-1)
                - alpha: Parasitic loss coefficient (optional)
                - soc_initial: Initial SoC in kWh (optional)
            delta_t: Timestep duration in hours.
            lookback_n: Number of historical timesteps in observation.
            num_actions: Number of discrete actions (must be odd).
            use_preprocessing: Whether to apply observation preprocessing
                (cyclical encoding, normalization). Defaults to False for
                backward compatibility.
            add_holiday: Whether to add Italian holiday feature to observations
                (only used if use_preprocessing=True). Defaults to True.
            reward_settings: Dictionary with reward configuration (optional):
                - type: Reward type ('self_consumption', 'energy_arbitrage')
                - weights: Weight coefficients for reward components:
                    - main: Weight for main reward (default: 1.0)
                    - violation_penalty: Weight for violation penalty (default: 0.1)
                    - storage_usage_penalty: Weight for storage usage penalty (default: 0.01)
                - normalize: Whether to normalize rewards (default: False)
                If None, uses default reward based on node_type:
                    - prosumer: self_consumption
                    - producer: energy_arbitrage
            track_results: Whether to enable results tracking for controller comparison.
                Defaults to False for backward compatibility. When enabled, results
                can be accessed via env.results property after calling set_controller().

        Raises:
            ValueError: If node_type is not 'producer' or 'prosumer'.
            ValueError: If num_actions is not odd.
            ValueError: If reward_settings is invalid or incompatible with node_type.
        """
        super().__init__()

        # validate node type
        if node_type not in ['producer', 'prosumer']:
            raise ValueError(f'node_type must be "producer" or "prosumer", got: {node_type}')

        # validate num_actions
        if num_actions % 2 == 0:
            raise ValueError(f'num_actions must be odd, got: {num_actions}')

        self.node_type = node_type
        self.lookback_n = lookback_n
        self.num_actions = num_actions
        self.delta_t = delta_t
        self.use_preprocessing = use_preprocessing
        self.add_holiday = add_holiday

        # create battery instance
        self.battery = Battery(
            capacity=battery_config['capacity'],
            dod_max=battery_config['dod_max'],
            power_charge_max=battery_config['power_charge_max'],
            power_discharge_max=battery_config['power_discharge_max'],
            efficiency_charge=battery_config['efficiency_charge'],
            efficiency_discharge=battery_config['efficiency_discharge'],
            alpha=battery_config.get('alpha', 0.0),
            soc_initial=battery_config.get('soc_initial', None)
        )

        # create energy node instance
        if node_type == 'producer':
            self.node = Producer(
                csv_path=csv_path,
                delta_t=delta_t,
                num_actions=num_actions
            )
        else:  # prosumer
            self.node = Prosumer(
                csv_path=csv_path,
                delta_t=delta_t,
                num_actions=num_actions
            )

        # link battery to node
        self.node.set_storage(self.battery)

        # get data for timestamp extraction
        self.data = self.node.get_data(column=None)

        # create observation encoder if preprocessing is enabled
        self.encoder: ObservationEncoder | None = None
        if use_preprocessing:
            self.encoder = create_encoder_from_data(
                data=self.data,  # type: ignore
                lookback_n=lookback_n,
                add_holiday=add_holiday
            )

        # create reward calculator with validation
        if reward_settings is None:
            # use default reward settings based on node type
            reward_settings = get_default_reward_settings(node_type)
        else:
            # validate and complete provided settings
            reward_settings = validate_reward_settings(reward_settings, node_type)

        self.reward_calculator: RewardCalculator = create_reward_calculator(
            reward_type=reward_settings['type'],
            weights=reward_settings['weights'],
            normalize=reward_settings['normalize'],
            node_type=node_type
        )

        # create results tracker if enabled
        if track_results:
            self.tracker: ResultsTracker | None = ResultsTracker(node_type)
        else:
            self.tracker = None

        # lookback buffer for historical observations
        self.lookback_buffer: list[dict[str, Any]] = []

        # define action space: discrete actions from 0 to num_actions-1
        # action=0 -> -100% (max discharge)
        # action=(num_actions-1)/2 -> 0% (inactive)
        # action=num_actions-1 -> +100% (max charge)
        self.action_space = spaces.Discrete(num_actions)

        # define observation space with appropriate bounds
        if use_preprocessing:
            # encoded observations with normalized bounds
            obs_dim = calculate_encoded_observation_dim(lookback_n, add_holiday)
            low, high = self.encoder.get_observation_space_bounds()
            self.observation_space = spaces.Box(
                low=low,
                high=high,
                shape=(obs_dim,),
                dtype=np.float32
            )
        else:
            # raw observations with unbounded values
            obs_dim = calculate_observation_dim(lookback_n)
            self.observation_space = spaces.Box(
                low=-np.inf,
                high=np.inf,
                shape=(obs_dim,),
                dtype=np.float32
            )

    @property
    def time_step(self) -> int:
        """
        Get the current timestep index from the energy node.

        Returns:
            Current timestep index (0-based).

        Example:
            >>> env.reset()
            >>> print(env.time_step)  # prints 0
            >>> env.step(10)
            >>> print(env.time_step)  # prints 1
        """
        return self.node.time_step

    def set_controller(self, name: str) -> None:
        """
        Set the controller name for results tracking.

        This method activates results tracking for a specific controller,
        allowing multiple controllers to be tested on the same environment
        instance without recreation.

        Args:
            name: Controller name identifier (e.g., 'naive', 'ppo', 'self_consumption').

        Raises:
            RuntimeError: If results tracking is not enabled.

        Example:
            >>> env = gym.make('storage_node_env/EnergyStorage-v0', track_results=True, ...)
            >>> env.set_controller('naive')
            >>> obs, info = env.reset()
            >>> # ... run episode with naive controller ...
            >>> env.set_controller('ppo')
            >>> obs, info = env.reset()
            >>> # ... run episode with PPO controller ...
            >>> print(env.results.keys())
            dict_keys(['naive', 'ppo'])
        """
        if self.tracker is None:
            raise RuntimeError(
                'Results tracking not enabled. Set track_results=True when creating environment.'
            )

        self.tracker.set_controller(name)

    def get_controller_observation(self) -> dict[str, Any]:
        """
        Build raw dictionary observation for rule-based controller evaluation.

        This method provides a controller-compatible observation dictionary extracted
        from the current environment state. Use this when evaluating rule-based
        controllers on a Gymnasium environment instance.

        Returns:
            Dictionary with the following keys:
                - production: Current production (kW)
                - consumption: Current consumption (kW) - prosumer only
                - buy_price: Grid purchase price (€/kWh)
                - sell_price: Grid selling price (€/kWh)
                - energy_balance: production - consumption (kW) - prosumer only
                - final_soc: Battery state of charge (%)
                - upper_bound: Maximum charge power (% of nominal)
                - lower_bound: Maximum discharge power (% of nominal, negative)

        Example:
            >>> env = gym.make('storage_node_env/EnergyStorage-v0', ...)
            >>> obs, info = env.reset()
            >>> controller = SelfConsumptionController(num_actions=21)
            >>>
            >>> # get observation for controller
            >>> controller_obs = env.get_controller_observation()
            >>> action = controller.choose_action(controller_obs, {})
            >>> obs, reward, terminated, truncated, info = env.step(action)

        Raises:
            IndexError: If current timestep exceeds data length.
        """
        # get current data row
        if self.node.time_step >= len(self.data):
            raise IndexError(
                f'Cannot get observation: timestep {self.node.time_step} '
                f'exceeds data length {len(self.data)}'
            )

        current_row = self.data.iloc[self.node.time_step]

        # get battery state
        upper_bound, lower_bound = self.battery.get_bounds_percent(self.delta_t)

        # build base observation (common to producer and prosumer)
        observation = {
            'production': float(current_row['production']),
            'buy_price': float(current_row['buy_price']),
            'sell_price': float(current_row['sell_price']),
            'final_soc': self.battery.soc_percent,
            'upper_bound': upper_bound,
            'lower_bound': lower_bound,
        }

        # add prosumer-specific fields
        if self.node_type == 'prosumer':
            consumption = float(current_row['consumption'])
            observation['consumption'] = consumption
            observation['energy_balance'] = observation['production'] - consumption

        return observation

    def __repr__(self) -> str:
        """
        Return a detailed string representation of the environment.

        Returns:
            Formatted string with environment configuration and current state.

        Example:
            >>> print(env)
            EnergyStorageEnv(node_type='prosumer', timestep=0/8760, ...)
        """
        total_timesteps = len(self.data)
        obs_dim = self.observation_space.shape[0] # type: ignore
        battery_repr = repr(self.battery).replace('\n', '\n    ')

        return (
            f'EnergyStorageEnv(\n'
            f'    node_type=\'{self.node_type}\',\n'
            f'    timestep={self.time_step}/{total_timesteps},\n'
            f'    delta_t={self.delta_t}h,\n'
            f'    lookback_n={self.lookback_n},\n'
            f'    actions={self.num_actions},\n'
            f'    obs_dim={obs_dim},\n'
            f'    battery={battery_repr},\n'
            f'    csv_path=\'{self.node.csv_path}\'\n'
            f')'
        )

    def reset( # type: ignore
        self,
        seed: int | None = None,
        options: dict[str, Any] | None = None
    ) -> tuple[np.ndarray, dict[str, Any]]:
        """
        Reset the environment to initial state.

        Args:
            seed: Random seed for reproducibility.
            options: Additional options (not used currently).

        Returns:
            Tuple containing:
                - observation: Initial observation array.
                - info: Additional information dictionary.

        Raises:
            ValueError: If dataset is empty.

        Example:
            >>> obs, info = env.reset(seed=42)
        """
        super().reset(seed=seed)

        if len(self.data) == 0:
            raise ValueError("Cannot reset environment: dataset is empty")

        # reset node (resets timestep to 0 and battery to initial SoC)
        self.node.reset()

        # increment episode counter for results tracking
        if self.tracker:
            self.tracker.on_reset()

        # clear lookback buffer
        self.lookback_buffer = []

        # validate initial timestep is within bounds
        if self.node.time_step >= len(self.data):
            raise ValueError(
                f"Initial timestep {self.node.time_step} exceeds data length {len(self.data)}"
            )

        # get initial observation by taking a neutral action (middle action = 0 kW)
        neutral_action = self.num_actions // 2
        node_results = self.node.step(neutral_action)

        # add timestamp information to node_results
        current_timestamp = self.data.index[self.node.time_step]
        year, month, day, hour, quarter = split_timestamp(current_timestamp)
        node_results['year'] = year
        node_results['month'] = month
        node_results['day'] = day
        node_results['hour'] = hour
        node_results['quarter'] = quarter

        # build initial observation
        observation = build_observation(
            node_results=node_results,
            lookback_buffer=self.lookback_buffer,
            lookback_n=self.lookback_n,
            node_type=self.node_type
        )

        # apply preprocessing if enabled
        if self.use_preprocessing and self.encoder is not None:
            observation = self.encoder.encode(observation, current_timestamp)

        # update lookback buffer
        self.lookback_buffer = update_lookback_buffer(
            buffer=self.lookback_buffer,
            new_result=node_results,
            max_size=self.lookback_n
        )

        # create info dict
        info: dict[str, Any] = {
            'timestep': self.node.time_step,
            'node_type': self.node_type
        }

        return observation, info

    def step(
        self,
        action: int
    ) -> tuple[np.ndarray, float, bool, bool, dict[str, Any]]:
        """
        Execute one timestep of the environment.

        Args:
            action: Discrete action index (0 to num_actions-1).

        Returns:
            Tuple containing:
                - observation: New observation array.
                - reward: Reward value calculated by the reward calculator.
                - terminated: Whether episode has ended (always False, episodes end via truncation).
                - truncated: Whether episode was truncated (True when all data exhausted).
                - info: Additional information dictionary.

        Example:
            >>> obs, reward, terminated, truncated, info = env.step(action=15)
        """
        # advance time to next timestep
        self.node.advance_time()

        # check if we've exhausted available data
        if is_episode_truncated(self.node.time_step, len(self.data)):
            # build terminal observation and info
            observation, info = build_terminal_observation(
            data=self.data,  # type: ignore
                battery_soc_percent=self.battery.soc_percent,
                lookback_buffer=self.lookback_buffer,
                lookback_n=self.lookback_n,
                node_type=self.node_type
            )

            # apply preprocessing if enabled
            if self.use_preprocessing and self.encoder is not None:
                # use last valid timestamp for encoding
                last_timestamp = self.data.index[-1]
                observation = self.encoder.encode(observation, last_timestamp)

            return observation, 0.0, False, True, info

        # normal step execution - we have valid data
        # step 1: execute action in node
        node_results = self.node.step(action)

        # add timestamp information to node_results
        current_timestamp = self.data.index[self.node.time_step]
        year, month, day, hour, quarter = split_timestamp(current_timestamp)
        node_results['year'] = year
        node_results['month'] = month
        node_results['day'] = day
        node_results['hour'] = hour
        node_results['quarter'] = quarter

        # step 2: create observation from node_results
        observation = build_observation(
            node_results=node_results,
            lookback_buffer=self.lookback_buffer,
            lookback_n=self.lookback_n,
            node_type=self.node_type
        )

        # apply preprocessing if enabled
        if self.use_preprocessing and self.encoder is not None:
            observation = self.encoder.encode(observation, current_timestamp)

        # step 3: calculate reward using reward calculator
        reward = self.reward_calculator.calculate(node_results)

        # step 3.5: record results for tracking (if enabled)
        if self.tracker:
            action_power = self.node._action_to_power(action)
            self.tracker.record_step(
                timestep=self.node.time_step,
                action=action,
                action_power=action_power,
                info=node_results,
                datetime=current_timestamp
            )

        # step 4: create info dict
        info: dict[str, Any] = {
            # metadata
            'timestep': self.node.time_step,
            'node_type': self.node_type,

            # context fields
            'production': node_results['production'],
            'consumption': node_results['consumption'],
            'energy_balance': node_results['energy_balance'],
            'final_soc': node_results['final_soc'],

            # power flows
            'P_grid': node_results['P_grid'],
            'P_import': node_results['P_import'],
            'P_export': node_results['P_export'],

            # energy flows
            'E_import': node_results['E_import'],
            'E_export': node_results['E_export'],

            # economic metrics
            'cost_import': node_results['cost_import'],
            'revenue_export': node_results['revenue_export'],

            # constraint violations
            'violation': node_results['violation'],

            # self-consumption metrics (symmetric for both nodes)
            'E_selfcons': node_results['E_selfcons'],
            'selfcons_ratio': node_results['selfcons_ratio'],
            'E_selfsuff': node_results['E_selfsuff'],
            'selfsuff_ratio': node_results['selfsuff_ratio'],

            # battery metrics
            'E_bat_charge': node_results['E_bat_charge'],
            'E_bat_discharge': node_results['E_bat_discharge'],
            'delta_soc': node_results['delta_soc'],
        }

        # add node-specific economic metrics
        if self.node_type == 'producer':
            info['net_profit'] = node_results['net_profit']
        else:  # prosumer
            info['net_cost'] = node_results['net_cost']

        # update lookback buffer with current results
        self.lookback_buffer = update_lookback_buffer(
            buffer=self.lookback_buffer,
            new_result=node_results,
            max_size=self.lookback_n
        )

        # not truncated in normal flow
        truncated = False
        terminated = False

        return observation, reward, terminated, truncated, info

    @property
    def results(self) -> dict[str, Any]:
        """
        Access all results as dictionary of DataFrames.

        Returns:
            Dictionary mapping controller names to their result DataFrames.

        Raises:
            RuntimeError: If results tracking is not enabled.

        Example:
            >>> env = gym.make('storage_node_env/EnergyStorage-v0', track_results=True, ...)
            >>> env.set_controller('naive')
            >>> # ... run episode ...
            >>> env.set_controller('ppo')
            >>> # ... run episode ...
            >>> results = env.results
            >>> print(results.keys())
            dict_keys(['naive', 'ppo'])
            >>> df_naive = results['naive']
            >>> print(df_naive.head())
        """
        if self.tracker is None:
            raise RuntimeError('Results tracking not enabled. Set track_results=True.')

        return self.tracker.get_results()

    def get_controller_results(self, controller_name: str) -> Any:
        """
        Get results for a specific controller.

        Args:
            controller_name: Controller name identifier.

        Returns:
            DataFrame with results for the specified controller.

        Raises:
            RuntimeError: If results tracking is not enabled.
            ValueError: If controller name not found.

        Example:
            >>> df = env.get_controller_results('naive')
            >>> print(df.describe())
        """
        if self.tracker is None:
            raise RuntimeError('Results tracking not enabled. Set track_results=True.')

        return self.tracker.get_controller_results(controller_name)

    def compute_baselines(
        self,
        controllers: list[str] | None = None,
        max_steps: int | None = None,
        seed: int | None = None,
        verbose: bool = True
    ) -> dict[str, Any]:
        """
        Compute baseline results with rule-based controllers.

        This method automates the process of evaluating multiple RBC controllers
        on the same environment instance, populating the results tracker for each.

        Args:
            controllers: List of controller names to evaluate. If None, evaluates all
                available RBC controllers: ['naive', 'price_based', 'self_consumption'].
            max_steps: Maximum timesteps per episode. If None, runs entire dataset.
            seed: Random seed for env.reset(). Defaults to None.
            verbose: Print progress and summary for each controller. Defaults to True.

        Returns:
            Dictionary mapping controller names to their result DataFrames.

        Raises:
            RuntimeError: If results tracking is not enabled.
            ValueError: If unknown controller name is specified.

        Example:
            >>> env = gym.make('storage_node_env/EnergyStorage-v0', track_results=True, ...)
            >>> results = env.compute_baselines()
            >>> print(results.keys())
            dict_keys(['naive', 'price_based', 'self_consumption'])

            >>> # Evaluate specific controllers only
            >>> results = env.compute_baselines(
            ...     controllers=['naive', 'self_consumption'],
            ...     max_steps=1000,
            ...     seed=42
            ... )
        """
        # verify that results tracking is enabled
        if self.tracker is None:
            raise RuntimeError(
                'Results tracking not enabled. Set track_results=True when creating environment.'
            )

        # default controllers: all 3 RBC controllers
        if controllers is None:
            controllers = ['naive', 'price_based', 'self_consumption']

        # import RBC controllers
        from storage_node_env.gym.controllers import (
            NaiveController,
            PriceBasedController,
            SelfConsumptionController,
        )

        # map controller names to classes
        controller_classes = {
            'naive': NaiveController,
            'price_based': PriceBasedController,
            'self_consumption': SelfConsumptionController,
        }

        # evaluate each controller
        for ctrl_name in controllers:
            if ctrl_name not in controller_classes:
                raise ValueError(
                    f'Unknown controller: {ctrl_name}. '
                    f'Available controllers: {list(controller_classes.keys())}'
                )

            # create controller instance with default parameters
            controller = controller_classes[ctrl_name](num_actions=self.num_actions)

            # reset controller if it has a reset method (PriceBasedController)
            if hasattr(controller, 'reset'):
                controller.reset()

            # set controller in tracker
            self.set_controller(ctrl_name)

            # reset environment
            _, info = self.reset(seed=seed)

            # determine number of steps to run
            steps_to_run = max_steps if max_steps is not None else len(self.data) - 1

            if verbose:
                print(f'Running {ctrl_name} controller for {steps_to_run} steps...')

            # evaluation loop
            for step in range(steps_to_run):
                # get controller-compatible observation
                controller_obs = self.get_controller_observation()

                # controller chooses action
                action = controller.choose_action(controller_obs, info)

                # step environment
                _, _, terminated, truncated, info = self.step(action)

                if terminated or truncated:
                    break

            # print summary if verbose
            if verbose:
                df = self.tracker.get_controller_results(ctrl_name)
                if self.node_type == 'prosumer':
                    total_cost = df['net_cost_eur'].sum()
                    print(f'  Completed {len(df)} steps, total cost: {total_cost:.2f} €')
                else:  # producer
                    total_profit = df['net_profit_eur'].sum()
                    print(f'  Completed {len(df)} steps, total profit: {total_profit:.2f} €')

        # return all results
        return self.results

    def save_results(self, controller_name: str, filepath: str) -> None:
        """
        Save specific controller results to CSV file.

        Args:
            controller_name: Controller name identifier.
            filepath: Destination file path for CSV.

        Raises:
            RuntimeError: If results tracking is not enabled.
            ValueError: If controller name not found.

        Example:
            >>> env.save_results('naive', 'results/naive_controller.csv')
        """
        if self.tracker is None:
            raise RuntimeError('Results tracking not enabled. Set track_results=True.')

        df = self.tracker.get_controller_results(controller_name)
        save_dataframe_to_csv(df, filepath, create_dirs=True)

    def save_all_results(self, directory: str) -> None:
        """
        Save all controller results to separate CSV files.

        Each controller's results are saved to a separate file named
        '{controller_name}.csv' in the specified directory.

        Args:
            directory: Directory path where CSV files will be saved.

        Raises:
            RuntimeError: If results tracking is not enabled.

        Example:
            >>> env.save_all_results('results/')
            >>> # Creates: results/naive.csv, results/ppo.csv, etc.
        """
        if self.tracker is None:
            raise RuntimeError('Results tracking not enabled. Set track_results=True.')

        import os
        os.makedirs(directory, exist_ok=True)

        for controller_name, df in self.results.items():
            filepath = os.path.join(directory, f'{controller_name}.csv')
            save_dataframe_to_csv(df, filepath, create_dirs=False)

    def render(self) -> None:
        """
        Render the environment (placeholder for future implementation).

        Note:
            Currently not implemented. Can be extended for visualization.
        """

    def close(self) -> None:
        """
        Clean up environment resources.

        Note:
            Currently not needed, but provided for Gymnasium compatibility.
        """
