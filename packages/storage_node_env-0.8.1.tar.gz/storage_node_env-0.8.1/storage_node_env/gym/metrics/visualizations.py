"""
Visualization functions for metrics and results.

This module provides plotting functions to visualize simulation results
and computed metrics using matplotlib.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from storage_node_env.gym.metrics.aggregation import apply_lttb_aggregation, filter_to_day


# optional dependency: matplotlib
try:
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    plt = None  # type: ignore


def plot_soc_timeseries(
    df: pd.DataFrame,
    figsize: tuple[float, float] = (12, 4),
    battery_config: dict | None = None,
    aggregate_window: int | None = None
) -> tuple[plt.Figure, plt.Axes]:
    """
    Plot battery state of charge over time.

    Args:
        df: Results DataFrame with 'timestep' and 'soc_final_pct' columns.
        figsize: Figure size (width, height).
        battery_config: Optional battery configuration dict. If provided,
                       adds reference lines for capacity bounds (DoD limits).
        aggregate_window: Optional target number of points for LTTB downsampling.
                         If None, plots all points (default behavior).
                         Recommended: 1000-2000 for large datasets (8760+ points).

    Returns:
        Tuple of (Figure, Axes) objects.

    Raises:
        ImportError: If matplotlib is not installed.

    Example:
        >>> fig, ax = plot_soc_timeseries(df, battery_config=battery_config)
        >>> plt.savefig('soc_timeseries.png')
        >>> plt.close()

        >>> # with downsampling for large dataset
        >>> fig, ax = plot_soc_timeseries(df, aggregate_window=1000)
        >>> plt.savefig('soc_timeseries_downsampled.png')
        >>> plt.close()
    """
    if not MATPLOTLIB_AVAILABLE:
        raise ImportError(
            'matplotlib is required for visualization. '
            'Install it with: pip install storage-node-env[visualization]'
        )

    # apply LTTB downsampling if requested
    if aggregate_window is not None and len(df) > aggregate_window:
        df = apply_lttb_aggregation(df, n_points=aggregate_window, y_column='soc_final_pct')

    fig, ax = plt.subplots(figsize=figsize)

    # plot SoC
    ax.plot(df['timestep'], df['soc_final_pct'], linewidth=1.5, label='SoC', zorder=3)

    # add mean line
    mean_soc = df['soc_final_pct'].mean()
    ax.axhline(mean_soc, color='red', linestyle='--', alpha=0.5, label=f'Mean ({mean_soc:.1f}%)', zorder=2)

    # add capacity bounds if battery_config available
    if battery_config is not None:
        dod_max = battery_config.get('dod_max', 100)
        min_soc = 100 - dod_max
        max_soc = 100.0

        # shade usable range
        ax.axhspan(min_soc, max_soc, alpha=0.1, color='green', label='Usable Range', zorder=1)

        # add boundary lines
        ax.axhline(min_soc, color='orange', linestyle=':', linewidth=2,
                   alpha=0.7, label=f'Min SoC ({min_soc:.0f}%)', zorder=2)
        ax.axhline(max_soc, color='darkgreen', linestyle=':', linewidth=2,
                   alpha=0.7, label=f'Max SoC ({max_soc:.0f}%)', zorder=2)

    ax.set_xlabel('Timestep')
    ax.set_ylabel('State of Charge (%)')
    ax.set_title('Battery State of Charge Evolution')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)

    return fig, ax


def plot_power_flows(
    df: pd.DataFrame,
    figsize: tuple[float, float] = (14, 5),
    battery_config: dict | None = None,
    aggregate_window: int | None = None
) -> tuple[plt.Figure, plt.Axes]:
    """
    Plot power flows (production, consumption, grid, battery).

    Args:
        df: Results DataFrame with power columns.
        figsize: Figure size (width, height).
        battery_config: Optional battery configuration dict. If provided,
                       adds reference lines for battery power limits.
        aggregate_window: Optional target number of points for LTTB downsampling.
                         If None, plots all points (default behavior).
                         Recommended: 1000-2000 for large datasets (8760+ points).

    Returns:
        Tuple of (Figure, Axes) objects.

    Raises:
        ImportError: If matplotlib is not installed.

    Example:
        >>> fig, ax = plot_power_flows(df, battery_config=battery_config)
        >>> plt.savefig('power_flows.png')
        >>> plt.close()

        >>> # with downsampling for large dataset
        >>> fig, ax = plot_power_flows(df, aggregate_window=1500)
        >>> plt.savefig('power_flows_downsampled.png')
        >>> plt.close()
    """
    if not MATPLOTLIB_AVAILABLE:
        raise ImportError(
            'matplotlib is required for visualization. '
            'Install it with: pip install storage-node-env[visualization]'
        )

    # apply LTTB downsampling if requested
    # use grid_power_kw as representative column (usually has most variation)
    if aggregate_window is not None and len(df) > aggregate_window:
        y_col = 'grid_power_kw' if 'grid_power_kw' in df.columns else 'production_kw'
        df = apply_lttb_aggregation(df, n_points=aggregate_window, y_column=y_col)

    fig, ax = plt.subplots(figsize=figsize)

    timesteps = df['timestep']

    # plot production if available
    if 'production_kw' in df.columns:
        ax.plot(timesteps, df['production_kw'], label='Production', alpha=0.8, zorder=3)

    # plot consumption if available (prosumer)
    if 'consumption_kw' in df.columns:
        ax.plot(timesteps, df['consumption_kw'], label='Consumption', alpha=0.8, zorder=3)

    # plot grid power
    if 'grid_power_kw' in df.columns:
        ax.plot(timesteps, df['grid_power_kw'], label='Grid Power', alpha=0.8, zorder=3)

    # plot battery action
    if 'action_kw' in df.columns:
        ax.plot(timesteps, df['action_kw'], label='Battery Action', alpha=0.6, linewidth=1, zorder=3)

    # add power limits if battery_config available
    if battery_config is not None and 'action_kw' in df.columns:
        P_cha_max = battery_config.get('power_charge_max', 0)
        P_dis_max = battery_config.get('power_discharge_max', 0)

        if P_cha_max > 0 or P_dis_max > 0:
            # shade allowed range
            ax.axhspan(-P_dis_max, P_cha_max, alpha=0.05, color='gray', zorder=1)

            # add boundary lines
            if P_cha_max > 0:
                ax.axhline(P_cha_max, color='green', linestyle=':', linewidth=2,
                           alpha=0.7, label=f'Max Charge ({P_cha_max:.1f} kW)', zorder=2)
            if P_dis_max > 0:
                ax.axhline(-P_dis_max, color='red', linestyle=':', linewidth=2,
                           alpha=0.7, label=f'Max Discharge ({P_dis_max:.1f} kW)', zorder=2)

    ax.axhline(0, color='black', linestyle='-', linewidth=0.5, zorder=2)
    ax.set_xlabel('Timestep')
    ax.set_ylabel('Power (kW)')
    ax.set_title('Power Flows')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)

    return fig, ax


def plot_cost_analysis(
    df: pd.DataFrame,
    node_type: str,
    figsize: tuple[float, float] = (12, 4),
    aggregate_window: int | None = None
) -> tuple[plt.Figure, plt.Axes]:
    """
    Plot cumulative cost/revenue evolution.

    Args:
        df: Results DataFrame with economic columns.
        node_type: 'producer' or 'prosumer'.
        figsize: Figure size (width, height).
        aggregate_window: Optional target number of points for LTTB downsampling.
                         If None, plots all points (default behavior).
                         Recommended: 1000-2000 for large datasets (8760+ points).

    Returns:
        Tuple of (Figure, Axes) objects.

    Raises:
        ImportError: If matplotlib is not installed.

    Example:
        >>> fig, ax = plot_cost_analysis(df, 'prosumer')
        >>> plt.savefig('cost_analysis.png')
        >>> plt.close()

        >>> # with downsampling for large dataset
        >>> fig, ax = plot_cost_analysis(df, 'prosumer', aggregate_window=1000)
        >>> plt.savefig('cost_analysis_downsampled.png')
        >>> plt.close()
    """
    if not MATPLOTLIB_AVAILABLE:
        raise ImportError(
            'matplotlib is required for visualization. '
            'Install it with: pip install storage-node-env[visualization]'
        )

    # apply LTTB downsampling if requested
    # use import_cost_eur as representative column for economic data
    if aggregate_window is not None and len(df) > aggregate_window:
        y_col = 'import_cost_eur' if 'import_cost_eur' in df.columns else 'net_cost_eur'
        df = apply_lttb_aggregation(df, n_points=aggregate_window, y_column=y_col)

    fig, ax = plt.subplots(figsize=figsize)

    timesteps = df['timestep']

    # plot cumulative cost
    if 'import_cost_eur' in df.columns:
        cum_cost = df['import_cost_eur'].cumsum()
        ax.plot(timesteps, cum_cost, label='Cumulative Cost', color='red', alpha=0.8)

    # plot cumulative revenue
    if 'export_revenue_eur' in df.columns:
        cum_revenue = df['export_revenue_eur'].cumsum()
        ax.plot(timesteps, cum_revenue, label='Cumulative Revenue', color='green', alpha=0.8)

    # plot net cost/profit
    if node_type == 'prosumer' and 'net_cost_eur' in df.columns:
        cum_net = df['net_cost_eur'].cumsum()
        ax.plot(timesteps, cum_net, label='Cumulative Net Cost', color='blue', linewidth=2)
    elif node_type == 'producer' and 'net_profit_eur' in df.columns:
        cum_net = df['net_profit_eur'].cumsum()
        ax.plot(timesteps, cum_net, label='Cumulative Net Profit', color='blue', linewidth=2)

    ax.set_xlabel('Timestep')
    ax.set_ylabel('Amount (€)')
    ax.set_title('Economic Performance')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)

    return fig, ax


def plot_distribution(
    df: pd.DataFrame,
    column: str,
    bins: int = 30,
    figsize: tuple[float, float] = (10, 4)
) -> tuple[plt.Figure, plt.Axes]:
    """
    Plot distribution histogram for a specific column.

    Args:
        df: Results DataFrame.
        column: Column name to plot.
        bins: Number of histogram bins.
        figsize: Figure size (width, height).

    Returns:
        Tuple of (Figure, Axes) objects.

    Raises:
        ImportError: If matplotlib is not installed.

    Example:
        >>> fig, ax = plot_distribution(df, 'soc_final_pct')
        >>> plt.savefig('soc_distribution.png')
        >>> plt.close()
    """
    if not MATPLOTLIB_AVAILABLE:
        raise ImportError(
            'matplotlib is required for visualization. '
            'Install it with: pip install storage-node-env[visualization]'
        )

    fig, ax = plt.subplots(figsize=figsize)

    data = df[column]

    # plot histogram
    ax.hist(data, bins=bins, alpha=0.7, edgecolor='black')

    # add mean and median lines
    mean_val = data.mean()
    median_val = data.median()
    ax.axvline(mean_val, color='red', linestyle='--', label=f'Mean: {mean_val:.2f}')
    ax.axvline(median_val, color='green', linestyle='--', label=f'Median: {median_val:.2f}')

    ax.set_xlabel(column.replace('_', ' ').title())
    ax.set_ylabel('Frequency')
    ax.set_title(f'Distribution of {column.replace("_", " ").title()}')
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')

    return fig, ax


def plot_controller_comparison(
    results: dict[str, pd.DataFrame],
    metric_column: str,
    figsize: tuple[float, float] = (10, 6)
) -> tuple[plt.Figure, plt.Axes]:
    """
    Create box plot comparison across controllers for a specific metric.

    Args:
        results: Dictionary mapping controller names to DataFrames.
        metric_column: Column name to compare.
        figsize: Figure size (width, height).

    Returns:
        Tuple of (Figure, Axes) objects.

    Raises:
        ImportError: If matplotlib is not installed.

    Example:
        >>> results = {'naive': df1, 'ppo': df2, 'sc': df3}
        >>> fig, ax = plot_controller_comparison(results, 'soc_final_pct')
        >>> plt.savefig('controller_comparison.png')
        >>> plt.close()
    """
    if not MATPLOTLIB_AVAILABLE:
        raise ImportError(
            'matplotlib is required for visualization. '
            'Install it with: pip install storage-node-env[visualization]'
        )

    fig, ax = plt.subplots(figsize=figsize)

    # prepare data for box plot
    data_to_plot = []
    labels = []
    for controller_name, df in results.items():
        if metric_column in df.columns:
            data_to_plot.append(df[metric_column])
            labels.append(controller_name)

    # create box plot
    bp = ax.boxplot(data_to_plot, labels=labels, patch_artist=True)

    # color boxes
    colors = plt.cm.Set3.colors
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)

    ax.set_ylabel(metric_column.replace('_', ' ').title())
    ax.set_title(f'Controller Comparison: {metric_column.replace("_", " ").title()}')
    ax.grid(True, alpha=0.3, axis='y')

    return fig, ax


def create_dashboard(
    df: pd.DataFrame,
    node_type: str,
    figsize: tuple[float, float] = (16, 10),
    battery_config: dict | None = None,
    aggregate_window: int | None = None
) -> plt.Figure:
    """
    Create comprehensive dashboard with multiple metrics visualizations.

    Args:
        df: Results DataFrame.
        node_type: 'producer' or 'prosumer'.
        figsize: Figure size (width, height).
        battery_config: Optional battery configuration dict. If provided,
                       adds battery specifications panel and capacity bounds to SoC plot.
        aggregate_window: Optional target number of points for LTTB downsampling.
                         If None, plots all points (default behavior).
                         Applied to time series plots (SoC, grid power, costs, self-consumption).
                         Recommended: 1000-2000 for large datasets (8760+ points).

    Returns:
        Figure with multiple subplots.

    Raises:
        ImportError: If matplotlib is not installed.

    Example:
        >>> fig = create_dashboard(df, 'prosumer', battery_config=battery_config)
        >>> plt.savefig('dashboard.png', dpi=150, bbox_inches='tight')
        >>> plt.close()

        >>> # with downsampling for large dataset
        >>> fig = create_dashboard(df, 'prosumer', aggregate_window=1500)
        >>> plt.savefig('dashboard_downsampled.png', dpi=150, bbox_inches='tight')
        >>> plt.close()
    """
    if not MATPLOTLIB_AVAILABLE:
        raise ImportError(
            'matplotlib is required for visualization. '
            'Install it with: pip install storage-node-env[visualization]'
        )

    # apply LTTB downsampling if requested for timeseries plots
    # distributions and histograms use full data
    if aggregate_window is not None and len(df) > aggregate_window:
        df_plot = apply_lttb_aggregation(df, n_points=aggregate_window, y_column='soc_final_pct')
    else:
        df_plot = df

    # create figure with subplots
    fig = plt.figure(figsize=figsize)
    gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)

    # 1. SoC timeseries (top row, spans 2 columns)
    ax1 = fig.add_subplot(gs[0, :2])
    ax1.plot(df_plot['timestep'], df_plot['soc_final_pct'], linewidth=1, zorder=3)

    # add capacity bounds if battery_config available
    if battery_config is not None:
        dod_max = battery_config.get('dod_max', 100)
        min_soc = 100 - dod_max
        max_soc = 100.0
        ax1.axhspan(min_soc, max_soc, alpha=0.1, color='green', zorder=1)
        ax1.axhline(min_soc, color='orange', linestyle=':', linewidth=1.5,
                   alpha=0.6, zorder=2)
        ax1.axhline(max_soc, color='darkgreen', linestyle=':', linewidth=1.5,
                   alpha=0.6, zorder=2)

    ax1.set_ylabel('SoC (%)')
    ax1.set_title('Battery State of Charge')
    ax1.grid(True, alpha=0.3)

    # 2. Power flows (top right)
    ax2 = fig.add_subplot(gs[0, 2])
    if 'grid_power_kw' in df_plot.columns:
        ax2.plot(df_plot['timestep'], df_plot['grid_power_kw'], linewidth=1, alpha=0.7)
    ax2.axhline(0, color='black', linestyle='-', linewidth=0.5)
    ax2.set_ylabel('Grid Power (kW)')
    ax2.set_title('Grid Power')
    ax2.grid(True, alpha=0.3)

    # 3. Cost evolution (middle left, spans 2 columns)
    ax3 = fig.add_subplot(gs[1, :2])
    if node_type == 'prosumer' and 'net_cost_eur' in df_plot.columns:
        cum_cost = df_plot['net_cost_eur'].cumsum()
        ax3.plot(df_plot['timestep'], cum_cost, linewidth=1.5, color='blue')
        ax3.set_ylabel('Cumulative Cost (€)')
        ax3.set_title('Cumulative Net Cost')
    elif node_type == 'producer' and 'net_profit_eur' in df_plot.columns:
        cum_profit = df_plot['net_profit_eur'].cumsum()
        ax3.plot(df_plot['timestep'], cum_profit, linewidth=1.5, color='green')
        ax3.set_ylabel('Cumulative Profit (€)')
        ax3.set_title('Cumulative Net Profit')
    ax3.grid(True, alpha=0.3)

    # 4. Action distribution (middle right)
    ax4 = fig.add_subplot(gs[1, 2])
    if 'action_kw' in df.columns:
        ax4.hist(df['action_kw'], bins=25, edgecolor='black', alpha=0.7)
        ax4.set_xlabel('Action (kW)')
        ax4.set_ylabel('Frequency')
        ax4.set_title('Action Distribution')
        ax4.grid(True, alpha=0.3, axis='y')

    # 5. SoC distribution (bottom left)
    ax5 = fig.add_subplot(gs[2, 0])
    ax5.hist(df['soc_final_pct'], bins=30, edgecolor='black', alpha=0.7)
    ax5.set_xlabel('SoC (%)')
    ax5.set_ylabel('Frequency')
    ax5.set_title('SoC Distribution')
    ax5.grid(True, alpha=0.3, axis='y')

    # 6. Violations (bottom middle)
    ax6 = fig.add_subplot(gs[2, 1])
    if 'violation_kw' in df.columns:
        violations = df[df['violation_kw'] > 0]
        if len(violations) > 0:
            ax6.scatter(violations['timestep'], violations['violation_kw'],
                       alpha=0.6, s=20, color='red')
            ax6.set_ylabel('Violation (kW)')
            ax6.set_title(f'Violations (count: {len(violations)})')
        else:
            ax6.text(0.5, 0.5, 'No Violations', ha='center', va='center',
                    transform=ax6.transAxes, fontsize=12)
            ax6.set_title('Violations')
        ax6.grid(True, alpha=0.3)

    # 7. Self-consumption (bottom right) - prosumer only
    ax7 = fig.add_subplot(gs[2, 2])
    if node_type == 'prosumer' and 'selfcons_ratio' in df_plot.columns:
        ax7.plot(df_plot['timestep'], df_plot['selfcons_ratio'] * 100, linewidth=1, alpha=0.7)
        mean_sc = df_plot['selfcons_ratio'].mean() * 100
        ax7.axhline(mean_sc, color='red', linestyle='--', alpha=0.5)
        ax7.set_ylabel('Self-consumption (%)')
        ax7.set_title(f'Self-consumption (mean: {mean_sc:.1f}%)')
        ax7.grid(True, alpha=0.3)
    else:
        ax7.text(0.5, 0.5, 'N/A', ha='center', va='center',
                transform=ax7.transAxes, fontsize=12)
        ax7.set_title('Self-consumption')

    # add main title
    controller_name = df['controller'].iloc[0] if 'controller' in df.columns else 'Unknown'
    fig.suptitle(f'Results Dashboard - {controller_name.upper()} Controller ({node_type})',
                fontsize=14, fontweight='bold')

    # add battery specifications panel if battery_config provided
    if battery_config is not None:
        specs_text = (
            f"Battery Specifications:\n"
            f"Capacity: {battery_config.get('capacity', 'N/A'):.2f} kWh\n"
            f"DoD: {battery_config.get('dod_max', 100):.0f}%\n"
            f"P_charge: {battery_config.get('power_charge_max', 0):.2f} kW\n"
            f"P_discharge: {battery_config.get('power_discharge_max', 0):.2f} kW\n"
            f"η_charge: {battery_config.get('efficiency_charge', 1.0):.2%}\n"
            f"η_discharge: {battery_config.get('efficiency_discharge', 1.0):.2%}"
        )
        fig.text(0.02, 0.02, specs_text, fontsize=9,
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5),
                verticalalignment='bottom')

    return fig


def create_comparison_dashboard(
    results: dict[str, pd.DataFrame],
    node_type: str,
    figsize: tuple[float, float] = (16, 10),
    battery_config: dict | None = None,
    day: str | None = None
) -> plt.Figure:
    """
    Create comparison dashboard for multiple controllers.

    Args:
        results: Dictionary mapping controller names to DataFrames.
        node_type: 'producer' or 'prosumer'.
        figsize: Figure size (width, height).
        battery_config: Optional battery configuration dict. If provided,
                       adds capacity bounds to SoC comparison plot.
        day: Optional specific day to show in SoC comparison (format: 'YYYY-MM-DD').
             If None, shows all data (may be cluttered for large datasets).
             Other plots (costs, violations, self-consumption) remain global.

    Returns:
        Figure with comparison visualizations.

    Raises:
        ImportError: If matplotlib is not installed.

    Example:
        >>> results = {'naive': df1, 'ppo': df2, 'sc': df3}
        >>> fig = create_comparison_dashboard(results, 'prosumer', battery_config=battery_config)
        >>> plt.savefig('comparison.png', dpi=150, bbox_inches='tight')
        >>> plt.close()

        >>> # compare controllers for specific day
        >>> fig = create_comparison_dashboard(results, 'prosumer', day='2024-01-15')
        >>> plt.savefig('comparison_2024-01-15.png', dpi=150, bbox_inches='tight')
        >>> plt.close()
    """
    if not MATPLOTLIB_AVAILABLE:
        raise ImportError(
            'matplotlib is required for visualization. '
            'Install it with: pip install storage-node-env[visualization]'
        )

    fig = plt.figure(figsize=figsize)
    gs = fig.add_gridspec(2, 3, hspace=0.3, wspace=0.3)

    colors = plt.cm.Set2.colors

    # 1. SoC comparison (top left, spans 2 columns)
    ax1 = fig.add_subplot(gs[0, :2])

    # add capacity bounds if battery_config available
    if battery_config is not None:
        dod_max = battery_config.get('dod_max', 100)
        min_soc = 100 - dod_max
        max_soc = 100.0
        ax1.axhspan(min_soc, max_soc, alpha=0.1, color='green', zorder=1)
        ax1.axhline(min_soc, color='orange', linestyle=':', linewidth=1.5,
                   alpha=0.6, zorder=2)
        ax1.axhline(max_soc, color='darkgreen', linestyle=':', linewidth=1.5,
                   alpha=0.6, zorder=2)

    # plot SoC comparison - filter to day if specified
    for idx, (name, df) in enumerate(results.items()):
        if 'soc_final_pct' not in df.columns:
            continue

        # filter to specific day if requested
        if day is not None:
            try:
                df_plot = filter_to_day(df, day)
                x_values = df_plot['hour_of_day']
                x_label = 'Hour of Day'
            except ValueError as e:
                # day not found in this controller's data, skip
                print(f'Warning: {e} for controller {name}')
                continue
        else:
            df_plot = df
            x_values = df_plot['timestep']
            x_label = 'Timestep'

        ax1.plot(x_values, df_plot['soc_final_pct'],
                label=name, alpha=0.7, color=colors[idx % len(colors)], zorder=3)

    ax1.set_ylabel('SoC (%)')
    ax1.set_xlabel(x_label)
    title_suffix = f' ({day})' if day else ''
    ax1.set_title(f'Battery SoC Comparison{title_suffix}')
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # 2. Cost comparison (top right)
    ax2 = fig.add_subplot(gs[0, 2])
    costs = []
    labels = []
    for name, df in results.items():
        if node_type == 'prosumer' and 'net_cost_eur' in df.columns:
            total_cost = df['net_cost_eur'].sum()
            costs.append(total_cost)
            labels.append(name)
        elif node_type == 'producer' and 'net_profit_eur' in df.columns:
            total_profit = df['net_profit_eur'].sum()
            costs.append(-total_profit)  # negative for comparison
            labels.append(name)
    if costs:
        bars = ax2.bar(labels, costs, color=colors[:len(costs)])
        ax2.set_ylabel('Total Cost (€)' if node_type == 'prosumer' else 'Total Profit (€)')
        ax2.set_title('Economic Comparison')
        ax2.grid(True, alpha=0.3, axis='y')
        # rotate labels if many controllers
        if len(labels) > 3:
            ax2.tick_params(axis='x', rotation=45)

    # 3. SoC box plots (bottom left)
    ax3 = fig.add_subplot(gs[1, 0])
    soc_data = [df['soc_final_pct'] for name, df in results.items()
                if 'soc_final_pct' in df.columns]
    soc_labels = [name for name, df in results.items() if 'soc_final_pct' in df.columns]
    if soc_data:
        bp = ax3.boxplot(soc_data, labels=soc_labels, patch_artist=True)
        for patch, color in zip(bp['boxes'], colors):
            patch.set_facecolor(color)
        ax3.set_ylabel('SoC (%)')
        ax3.set_title('SoC Distribution')
        ax3.grid(True, alpha=0.3, axis='y')
        if len(soc_labels) > 3:
            ax3.tick_params(axis='x', rotation=45)

    # 4. Violations comparison (bottom middle)
    ax4 = fig.add_subplot(gs[1, 1])
    violation_counts = []
    violation_labels = []
    for name, df in results.items():
        if 'violation_kw' in df.columns:
            count = (df['violation_kw'] > 0).sum()
            violation_counts.append(count)
            violation_labels.append(name)
    if violation_counts:
        bars = ax4.bar(violation_labels, violation_counts, color=colors[:len(violation_counts)])
        ax4.set_ylabel('Violation Count')
        ax4.set_title('Constraint Violations')
        ax4.grid(True, alpha=0.3, axis='y')
        if len(violation_labels) > 3:
            ax4.tick_params(axis='x', rotation=45)

    # 5. Self-consumption comparison (bottom right) - prosumer only
    ax5 = fig.add_subplot(gs[1, 2])
    if node_type == 'prosumer':
        sc_means = []
        sc_labels = []
        for name, df in results.items():
            if 'selfcons_ratio' in df.columns:
                mean_sc = df['selfcons_ratio'].mean() * 100
                sc_means.append(mean_sc)
                sc_labels.append(name)
        if sc_means:
            bars = ax5.bar(sc_labels, sc_means, color=colors[:len(sc_means)])
            ax5.set_ylabel('Mean Self-consumption (%)')
            ax5.set_title('Self-consumption Comparison')
            ax5.set_ylim(0, 100)
            ax5.grid(True, alpha=0.3, axis='y')
            if len(sc_labels) > 3:
                ax5.tick_params(axis='x', rotation=45)
    else:
        ax5.text(0.5, 0.5, 'N/A for Producer', ha='center', va='center',
                transform=ax5.transAxes, fontsize=12)
        ax5.set_title('Self-consumption')

    fig.suptitle(f'Controller Comparison Dashboard ({node_type})',
                fontsize=14, fontweight='bold')

    return fig
