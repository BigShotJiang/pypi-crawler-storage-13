"""
Battery Energy Storage System Model.

This module provides a concrete implementation of a battery energy storage system
based on commercial datasheet parameters. It implements the StorageSystem interface
with physics-based modeling including efficiency losses and parasitic consumption.

"""

from storage_node_env.core.storage.base import StorageSystem


class Battery(StorageSystem):
    """
    Battery Energy Storage System (BESS) based on datasheet parameters.

    This class implements a battery model using a power*Δt formulation for flexible timestep
    support.

    Key features:
    - No arbitrage constraint: battery can charge from both local production and grid
    - Parasitic losses modeling (optional)
    - Dynamic bounds calculation
    - Efficiency losses in charging/discharging

    Attributes:
        C_nom (float): Nominal capacity (kWh)
        C_min (float): Minimum capacity - SoC minimum (kWh)
        C_max (float): Maximum capacity - SoC maximum (kWh)
        P_cha_max (float): Maximum charging power (kW)
        P_dis_max (float): Maximum discharging power (kW)
        eta_cha (float): Charging efficiency (-)
        eta_dis (float): Discharging efficiency (-)
        alpha (float): Parasitic loss coefficient (-)
        soc (float): Current state of charge (kWh)
        soc_initial (float): Initial SoC for reset (kWh)
    """

    def __init__(
        self,
        capacity: float,
        dod_max: float,
        power_charge_max: float,
        power_discharge_max: float,
        efficiency_charge: float,
        efficiency_discharge: float,
        alpha: float = 0.0,
        soc_initial: float | None = None,
    ):
        """
        Initializes a Battery Energy Storage System.

        Args:
            capacity (float): Nominal capacity C_nom (kWh)
            dod_max (float): Maximum depth of discharge (%), e.g., 90 for 90%
            power_charge_max (float): Maximum charging power P_cha_max (kW)
            power_discharge_max (float): Maximum discharging power P_dis_max (kW)
            efficiency_charge (float): Charging efficiency eta_cha, value between 0 and 1
            efficiency_discharge (float): Discharging efficiency eta_dis, value between 0 and 1
            alpha (float, optional): Parasitic loss coefficient. Defaults to 0.0 (no losses)
            soc_initial (float, optional): Initial SoC (kWh). If None, starts at 50% capacity.

        Raises:
            AssertionError: If parameters are invalid
        """
        # validate parameters
        assert capacity > 0, "Nominal capacity must be positive"
        assert 0 < dod_max <= 100, "DoD must be between 0 and 100%"
        assert power_charge_max > 0, "Maximum charging power must be positive"
        assert power_discharge_max > 0, "Maximum discharging power must be positive"
        assert 0 < efficiency_charge <= 1, "Charging efficiency must be between 0 and 1"
        assert 0 < efficiency_discharge <= 1, "Discharging efficiency must be between 0 and 1"
        assert 0 <= alpha < 1, "Parasitic loss coefficient must be between 0 and 1"

        # store parameters
        self.C_nom = capacity
        self.DoD_max = dod_max
        self.P_cha_max = power_charge_max
        self.P_dis_max = power_discharge_max
        self.eta_cha = efficiency_charge
        self.eta_dis = efficiency_discharge
        self.alpha = alpha

        # compute derived parameters
        self.C_min = (1 - dod_max / 100) * capacity  # minimum SoC (kWh)
        self.C_max = capacity  # maximum SoC (kWh)

        assert self.C_min < self.C_max, "C_min must be less than C_max"

        # initialize state
        if soc_initial is None:
            self.soc_initial = 0.5 * self.C_nom  # start at 50%
        else:
            assert (
                self.C_min <= soc_initial <= self.C_max
            ), f"Initial SoC must be between C_min={self.C_min} and C_max={self.C_max}"
            self.soc_initial = soc_initial

        self.soc = self.soc_initial

    def __repr__(self):
        return (
            f"Battery(C_nom={self.C_nom:.2f} kWh, DoD={self.DoD_max}%, "
            f"P_cha={self.P_cha_max:.2f} kW, P_dis={self.P_dis_max:.2f} kW, "
            f"eta_cha={self.eta_cha:.3f}, eta_dis={self.eta_dis:.3f}, "
            f"alpha={self.alpha:.4f}, SoC={self.soc:.2f} kWh [{self.soc_percent:.1f}%])"
        )

    @property
    def soc_percent(self) -> float:
        """Returns the current SoC as percentage of nominal capacity."""
        return (self.soc / self.C_nom) * 100

    def get_bounds(self, delta_t: float) -> tuple[float, float]:
        """
        Calculate dynamic power bounds based on current SoC.

        Args:
            delta_t (float): Duration of timestep (hours)

        Returns:
            Tuple[float, float]:
                - P_upper (float): Maximum charging power allowed (kW)
                - P_lower (float): Maximum discharging power allowed (kW, negative)
        """
        # upper bound: minimum between C-rate limit and capacity constraint
        P_upper = min(self.P_cha_max, (self.C_max - self.soc) / delta_t)

        # lower bound: minimum between C-rate limit and capacity constraint
        P_lower = -min(self.P_dis_max, (self.soc - self.C_min) / delta_t)

        return P_upper, P_lower

    def get_bounds_percent(self, delta_t: float) -> tuple[float, float]:
        """
        Calculate dynamic power bounds as percentage of nominal power.

        Args:
            delta_t (float): Duration of timestep (hours)

        Returns:
            Tuple[float, float]:
                - P_upper_percent (float): Upper bound as % of P_cha_max [0, 100]
                - P_lower_percent (float): Lower bound as % of P_dis_max [-100, 0]
        """
        P_upper, P_lower = self.get_bounds(delta_t)

        P_upper_percent = (P_upper / self.P_cha_max) * 100
        P_lower_percent = (P_lower / self.P_dis_max) * 100

        return P_upper_percent, P_lower_percent

    @staticmethod
    def _clip(x: float, x_min: float, x_max: float) -> float:
        """Clip value x to interval [x_min, x_max]."""
        return max(x_min, min(x, x_max))

    def step(self, power: float, delta_t: float) -> tuple[float, float, float, float, float]:
        """
        Simulate one timestep of the battery.

        This method implements the complete battery dynamics including:
        1. Parasitic losses (optional)
        2. Dynamic bounds calculation
        3. Power clipping
        4. Capacity constraints
        5. SoC update with efficiency
        6. External energy calculation

        Args:
            power (float): Requested power (kW). Positive for charging, negative for discharging.
            delta_t (float): Duration of timestep (hours)

        Returns:
            Tuple[float, float, float, float, float]:
                - SoC_new (float): New state of charge (kWh)
                - E_ext (float): Energy exchanged with external system (kWh)
                  Positive = energy absorbed by battery from external system
                  Negative = energy released by battery to external system
                - P_upper (float): Upper bound for next timestep (kW)
                - P_lower (float): Lower bound for next timestep (kW)
                - violation (float): Absolute value of power constraint violation (kW)

        Raises:
            AssertionError: If SoC constraint is violated (implementation error)
        """
        # store previous SoC for reference
        SoC_prev = self.soc

        # step 1: apply parasitic losses (if alpha > 0)
        if self.alpha > 0:
            SoC_init = self.soc * (1 - self.alpha)
            # prevent parasitic losses from violating minimum constraint
            SoC_init = max(SoC_init, self.C_min)
        else:
            SoC_init = self.soc

        # step 2: calculate dynamic bounds for current timestep (used for clipping)
        P_upper_curr, P_lower_curr = self.get_bounds(delta_t)

        # step 3: clip requested power to current bounds
        P_bat = self._clip(power, P_lower_curr, P_upper_curr)

        # calculate power constraint violation
        violation = abs(power - P_bat)

        # step 4: calculate requested energy
        E_bat = P_bat * delta_t

        # step 5: apply capacity constraints to internal energy change
        # key insight: capacity constraints must be applied to INTERNAL energy (after efficiency)
        if E_bat > 0:  # charging
            # convert external energy request to internal stored energy
            E_internal_requested = E_bat * self.eta_cha
            # clamp to available capacity headroom
            E_internal = min(E_internal_requested, self.C_max - SoC_init)
        elif E_bat < 0:  # discharging
            # for discharge, E_bat already represents internal energy perspective
            # clamp to available capacity above C_min
            E_internal = max(E_bat, self.C_min - SoC_init)
        else:  # inactive
            E_internal = 0

        # step 6: update SoC with internal energy change
        # E_internal is already the correct internal battery energy change
        self.soc = SoC_init + E_internal

        # step 7: compute external energy (energy seen by external system)
        # apply efficiency losses to convert internal to external perspective
        if E_internal > 0:  # charging
            # external system must provide MORE energy than stored
            E_ext = E_internal / self.eta_cha
        elif E_internal < 0:  # discharging
            # external system receives LESS energy than released
            E_ext = E_internal * self.eta_dis
        else:  # inactive
            E_ext = 0

        # step 8: verify state constraint
        TOLERANCE = 1e-6  # add small tolerance for floating point errors
        assert self.C_min - TOLERANCE <= self.soc <= self.C_max + TOLERANCE, (
            f"SoC constraint violated: {self.soc:.6f} kWh not in "
            f"[{self.C_min:.6f}, {self.C_max:.6f}] kWh\n"
            f"Previous SoC: {SoC_prev:.6f} kWh, SoC_init: {SoC_init:.6f} kWh\n"
            f"P_req: {power:.3f} kW, P_bat: {P_bat:.3f} kW, E_internal: {E_internal:.6f} kWh"
        )

        # round to avoid floating point accumulation errors
        self.soc = round(self.soc, 6)
        E_ext = round(E_ext, 6)
        violation = round(violation, 6)

        # step 9: calculate dynamic bounds for next timestep (after SoC update)
        P_upper, P_lower = self.get_bounds(delta_t)

        return self.soc, E_ext, P_upper, P_lower, violation

    def reset(self) -> None:
        """
        Reset the battery to its initial state.
        """
        self.soc = self.soc_initial
