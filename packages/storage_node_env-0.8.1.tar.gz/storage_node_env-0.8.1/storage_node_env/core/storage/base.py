"""
Abstract Storage System Model.

This module provides the abstract base class for energy storage systems
in the storage-node-environment. Storage systems represent physical devices
that can store and release energy, such as batteries, supercapacitors, etc.

"""

from abc import ABC, abstractmethod


class StorageSystem(ABC):
    """
    Abstract class representing an energy storage system.

    This class defines the interfaces for the basic operations that any storage system must
    implement, such as stepping through time, resetting, and terminating.

    Abstract Methods:
        step(power: float, delta_t: float) -> Tuple[float, float, float, float, float]:
            Simulates one timestep of the storage system.

        reset() -> None:
            Resets the initial state of the storage system.

        terminate() -> None:
            Terminates and cleans up any resources or final states of the storage system.
    """

    @abstractmethod
    def step(self, power: float, delta_t: float) -> tuple[float, float, float, float, float]:
        """
        Abstract method for simulating one timestep of the storage system.
        Must be implemented by derived classes.

        Args:
            power (float): Requested power (kW). Positive for charging, negative for discharging.
            delta_t (float): Duration of timestep (hours).

        Returns:
            Tuple[float, float, float, float, float]:
                - SoC_new (float): New state of charge (kWh)
                - E_ext (float): Energy exchanged with external system (kWh)
                - P_upper (float): Upper bound for next timestep (kW)
                - P_lower (float): Lower bound for next timestep (kW)
                - violation (float): Absolute value of power constraint violation (kW)
        """

    @abstractmethod
    def reset(self) -> None:
        """
        Resets the initial state of the storage system.
        """

    def terminate(self) -> None:
        """
        Ends storage operations. This method can be used to free resources or save
        the final state, if necessary.
        """
