"""
Prosumer Energy Node Model.

This module implements the prosumer node, representing an energy system with
both production (e.g., photovoltaic) and consumption (loads), equipped with
battery energy storage.

The prosumer's objective is to maximize self-consumption and minimize energy
costs, considering system charges applied to grid imports.

"""

from typing import Any, Dict

from storage_node_env.core.nodes.base import EnergyNode


class Prosumer(EnergyNode):
    """
    Prosumer energy node with production and consumption.

    A prosumer node represents a physical system with:
    - Energy production (typically solar PV)
    - Local consumption (electrical loads)
    - Battery energy storage system (BESS)
    - Bidirectional grid connection (import/export)

    The prosumer pays standard tariffs including system charges on grid imports

    CSV Data Requirements:
        - datetime: Timestamp of the sample
        - production: Power produced by the plant (kW)
        - consumption: Power consumed by loads (kW)
        - buy_price: Energy purchase price from grid, including system charges (€/kWh)
        - sell_price: Energy selling price to grid (€/kWh)

    Energy Balance:
        P_prod - P_cons + P_grid - P_bat = 0

    Grid Power (derived):
        P_grid = P_cons - P_prod + P_bat
        - P_grid > 0: importing from grid
        - P_grid < 0: exporting to grid

    Economic Model:
        - Import cost: E_import * buy_price (includes system charges)
        - Export revenue: E_export * sell_price
        - Net cost: cost_import - revenue_export
    """

    def __init__(
        self,
        csv_path: str,
        delta_t: float,
        num_actions: int = 21,
    ):
        """
        Initialize the prosumer node.

        Args:
            csv_path (str): Path to CSV file with columns:
                datetime, production, consumption, buy_price, sell_price
            delta_t (float): Timestep duration in hours.
            num_actions (int, optional): Number of discrete actions. Defaults to 21.

        Raises:
            AssertionError: If required columns are missing from CSV.
        """
        super().__init__(csv_path, delta_t, num_actions)

    def _validate_data(self) -> None:
        """
        Validate that required columns exist in the CSV data.

        Required columns for Prosumer:
            - datetime (used as index)
            - production
            - consumption
            - buy_price
            - sell_price

        Returns:
            None

        Raises:
            AssertionError: If any required column is missing.
        """
        # note: datetime is the index, not a column
        required_columns = ["production", "consumption", "buy_price", "sell_price"]
        available_columns = self.data.columns.tolist()

        for col in required_columns:
            assert col in available_columns, (
                f'Required column "{col}" not found in CSV. '
                f"Available columns: {available_columns}"
            )

    def step(self, action: int) -> Dict[str, Any]:
        """
        Execute one timestep of the prosumer node simulation.

        This method implements the complete prosumer energy flow:
        1. Load historical data at current timestep
        2. Calculate energy balance (production - consumption)
        3. Convert action to requested battery power
        4. Execute battery step
        5. Calculate grid power (Prosumer formula)
        6. Decompose into import/export
        7. Calculate energies and costs/revenues
        8. Build observation and info dictionaries

        Args:
            action (int): Discrete action chosen by agent [0, num_actions-1].

        Returns:
            Dict[str, Any]: step results containing:
                    - timestamp (int): Current timestep index
                    - production (float): Power produced (kW)
                    - consumption (float): Power consumed (kW)
                    - buy_price (float): Grid purchase price INCLUDING charges (€/kWh)
                    - sell_price (float): Grid selling price (€/kWh)
                    - energy_balance (float): Production - consumption (kW)
                    - initial_soc (float): Battery SoC before action (%)
                    - action (int): Discrete action index [0, num_actions-1]
                    - action_power (float): Requested battery power (kW)
                    - final_soc (float): Battery SoC after action (%)
                    - upper_bound (float): Max charge power bound (%)
                    - lower_bound (float): Max discharge power bound (%)
                    - P_grid (float): Net grid power (kW)
                    - P_import (float): Grid import power (kW, ≥0)
                    - P_export (float): Grid export power (kW, ≥0)
                    - E_import (float): Energy imported (kWh)
                    - E_export (float): Energy exported (kWh)
                    - cost_import (float): Import cost (€)
                    - revenue_export (float): Export revenue (€)
                    - net_cost (float): Net cost for timestep (€)
                    - net_profit (float): Net profit for timestep (€) - negative of net_cost
                    - violation (float): Power constraint violation (kW)
                    - E_selfcons (float): Self-consumed energy (kWh) - production not exported
                    - selfcons_ratio (float): Self-consumption ratio [0-1]
                    - E_selfsuff (float): Self-sufficient energy (kWh) - consumption not imported
                    - selfsuff_ratio (float): Self-sufficiency ratio [0-1]
                    - E_bat_charge (float): Energy charged to battery (kWh, ≥0)
                    - E_bat_discharge (float): Energy discharged from battery (kWh, ≥0)
                    - delta_soc (float): SoC change during timestep (percentage points)

        Raises:
            AssertionError: If battery not set or timestep out of bounds.
        """
        assert self.battery is not None, "Battery must be set before step. Use set_storage()."
        assert self.time_step < len(
            self.data
        ), f"Timestep {self.time_step} exceeds data length {len(self.data)}"

        # step 1: load historical data at current timestep
        P_prod_t = self.get_current_data("production")
        P_cons_t = self.get_current_data("consumption")
        pi_buy_t = self.get_current_data("buy_price")
        pi_sell_t = self.get_current_data("sell_price")

        # step 2: calculate energy balance (derived quantity)
        delta_P_t = P_prod_t - P_cons_t

        # step 3: save initial state before battery step
        initial_soc = self.battery.soc_percent # type: ignore

        # step 4: convert action to requested power
        P_req_t = self._action_to_power(action)

        # step 5: execute battery step
        _, E_ext_t, P_upper_t, P_lower_t, violation_t = self.battery.step(P_req_t, self.delta_t)

        # step 6: calculate percentage bounds for observation (after battery step)
        P_upper_percent = (P_upper_t / self.battery.P_cha_max) * 100 # type: ignore
        P_lower_percent = (P_lower_t / self.battery.P_dis_max) * 100 # type: ignore

        # step 7: calculate effective battery power
        P_bat_t = E_ext_t / self.delta_t

        # step 8: calculate net grid power (PROSUMER FORMULA)
        # P_grid = P_cons - P_prod + P_bat
        P_grid_t = P_cons_t - P_prod_t + P_bat_t

        # step 9: decompose into import/export
        P_import_t = max(0.0, P_grid_t)
        P_export_t = max(0.0, -P_grid_t)

        # step 10: calculate energies
        E_import_t = P_import_t * self.delta_t
        E_export_t = P_export_t * self.delta_t

        # step 11: calculate costs and revenues
        cost_import = E_import_t * pi_buy_t  # buy_price includes system charges
        revenue_export = E_export_t * pi_sell_t
        net_cost_t = cost_import - revenue_export

        # step 12: calculate self-consumption metrics
        E_prod_total = P_prod_t * self.delta_t
        E_cons_total = P_cons_t * self.delta_t
        E_selfcons_t = E_prod_total - E_export_t
        E_selfsuff_t = E_cons_total - E_import_t

        # calculate ratios (avoid division by zero, clamp to [0, 1])
        selfcons_ratio_t = max(0.0, min(1.0, (E_selfcons_t / E_prod_total))) if E_prod_total > 0 else 0.0
        selfsuff_ratio_t = max(0.0, min(1.0, (E_selfsuff_t / E_cons_total))) if E_cons_total > 0 else 0.0

        # step 13: calculate battery metrics
        delta_soc_t = self.battery.soc_percent - initial_soc # type: ignore
        E_bat_charge_t = max(0.0, E_ext_t)
        E_bat_discharge_t = max(0.0, -E_ext_t)

        # step 14: build result dictionary
        results = {
            "timestamp": self.time_step,
            "production": float(P_prod_t),
            "consumption": float(P_cons_t),
            "buy_price": float(pi_buy_t),
            "sell_price": float(pi_sell_t),
            "energy_balance": float(delta_P_t),
            "initial_soc": float(initial_soc),
            "action": int(action),
            "action_power": float(P_req_t),
            "final_soc": float(self.battery.soc_percent), # type: ignore
            "upper_bound": float(P_upper_percent),
            "lower_bound": float(P_lower_percent),

            "P_grid": float(P_grid_t),
            "P_import": float(P_import_t),
            "P_export": float(P_export_t),
            "E_import": float(E_import_t),
            "E_export": float(E_export_t),
            "cost_import": float(cost_import),
            "revenue_export": float(revenue_export),
            "net_cost": float(net_cost_t),
            "net_profit": float(-net_cost_t),  # negative of net_cost
            "violation": float(violation_t),

            # self-consumption metrics
            "E_selfcons": float(E_selfcons_t),
            "selfcons_ratio": float(selfcons_ratio_t),
            "E_selfsuff": float(E_selfsuff_t),
            "selfsuff_ratio": float(selfsuff_ratio_t),

            # battery metrics
            "E_bat_charge": float(E_bat_charge_t),
            "E_bat_discharge": float(E_bat_discharge_t),
            "delta_soc": float(delta_soc_t),
        }

        return results

    def __repr__(self) -> str:
        """
        String representation of the Prosumer node.

        Returns:
            str: Human-readable description of the node state.
        """
        battery_info = (
            f"Battery(SoC={self.battery.soc_percent:.1f}%)" if self.battery else "No Battery" # type: ignore
        )
        return (
            f"Prosumer(timestep={self.time_step}/{len(self.data)}, "
            f"delta_t={self.delta_t}h, "
            f"actions={self.num_actions}, "
            f"{battery_info})"
        )
