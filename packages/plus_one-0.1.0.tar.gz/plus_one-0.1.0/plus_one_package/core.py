def plus_one(x):
    """Add 1 to the given number."""
    return x + 1