import warnings
import logging


import cobra



def print_json_tree(data, level=0, max_level=2):
    # explore contents of a json object
    
    if level > max_level:
        return
    indent = '  ' * level
    if isinstance(data, dict):
        for key, value in data.items():
            print(f"{indent}{key}")
            print_tree(value, level + 1, max_level)
    elif isinstance(data, list):
        for i, item in enumerate(data):
            print(f"{indent}[{i}]")
            print_tree(item, level + 1, max_level)
            
            

def count_undrawn_rids(logger, universe, lastmap, focus):
    
    
    rids = set([r.id for r in universe.reactions])
    
    drawn_rids = set()
    for key, value in lastmap['json'][1]['reactions'].items():
        drawn_rids.add(value['bigg_id'])
        
        
    remainings = rids - drawn_rids
    filename = lastmap['filename']
    logger.debug(f"Last universal map version detected: '{filename}'.")
    if len(remainings) > 0:
        logger.warning(f"Our universal map is {len(remainings)} reactions behind. Please draw!")
        if focus == '-':
            logger.warning(f"Drawing is eased when using '--focus'...")
    else:
        logger.info(f"Our universal map is {len(remainings)} reactions behind. Thank you ♥")
        
        
        
def count_undrawn_rids_focus(logger, universe, lastmap, focus, outdir):
    
    
    # get modeled reads for this --focus:
    rids = set()
    try: gr = universe.groups.get_by_id(focus)
    except: 
        logger.warning(f"Group '{focus}' not found!")
        return 
    for r in gr.members:
        rids.add(r.id)


    # get rids on Escher: 
    drawn_rids = set()
    for key, value in lastmap['json'][1]['reactions'].items():
        drawn_rids.add(value['bigg_id'])

        
    # get remaining rids for this map:
    remainings = rids - drawn_rids
    remainings_krs = set()
    for rid in remainings: 
        r = universe.reactions.get_by_id(rid)
        krs = r.annotation['kegg.reaction']
        for kr in krs: 
            remainings_krs.add(kr)
    
    
    if len(remainings) > 0:
        if focus != 'transport':
            logger.warning(f"Focusing on '{focus}', our universal map is {len(remainings)} reactions behind: {' '.join(list(remainings_krs))}.")
        else:
            logger.warning(f"Focusing on '{focus}', our universal map is {len(remainings)} reactions behind.")  # usually no kegg codes for tranport reactions
        
        
        # subset the universe to ease the drawing: 
        universe_focus = universe.copy()
        to_remove = [r for r in universe_focus.reactions if r.id not in rids]
        
        
        # trick to avoid the WARNING "cobra/core/group.py:147: UserWarning: need to pass in a list" 
        # triggered when trying to remove reactions that are included in groups. 
        with warnings.catch_warnings():  # temporarily suppress warnings for this block
            warnings.simplefilter("ignore")  # ignore all warnings
            cobra_logger = logging.getLogger("cobra.util.solver")
            old_level = cobra_logger.level
            cobra_logger.setLevel(logging.ERROR)   
           
            universe_focus.remove_reactions(to_remove,remove_orphans=True)

            # restore original behaviour: 
            cobra_logger.setLevel(old_level)  
            
            
        # save the subset for drawing in Escher!
        logger.info(f"Writing '{outdir}/{focus}.json' to ease your drawing workflow...")
        cobra.io.save_json_model(universe_focus, f'{outdir}/{focus}.json')
    else:
        logger.info(f"Focusing on '{focus}', our universal map is {len(remainings)} reactions behind. Thank you ♥")
        