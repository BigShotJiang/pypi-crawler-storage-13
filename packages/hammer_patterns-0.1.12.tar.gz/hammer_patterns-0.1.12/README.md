hammer-patterns is a lightweight ASCII art library created, owned, and maintained by Deepinder Singh.
It provides a collection of simple and clean terminal-based patterns such as stars, squares, diamonds, arrows, hammers, and other basic shapes.

The library has no external dependencies and works on all major operating systems.
It is suitable for students, beginners, hobby programmers, and anyone who wants to print ASCII patterns using Python.

nstallation

Install from PyPI:

pip install hammer-patterns


Upgrade to the latest version:

pip install --upgrade hammer-patterns --no-cache-dir

Usage Example
import hammer_patterns as hp

hp.c_star()
hp.c_square()
hp.c_diamond()
hp.c_arrow()
hp.c_hammer()


Each function prints a pattern directly in the terminal.

Features

Easy to use

Pure Python, no dependencies

Clean and readable ASCII output

Multiple terminal patterns included

Maintained with frequent updates

Provided Patterns

These are some of the patterns available in the package:

Star shapes

Square and box patterns

Diamond shapes

Arrow patterns

Hammer pattern

Other simple geometric and line-based patterns

More patterns are added over time.

Author

This package is created, owned, and maintained by:

Deepinder Singh
Email: deepindersingh.ac@gmail.com

License

This package uses the
Creative Commons Attribution-NoDerivatives 4.0 International License (CC BY-ND 4.0).

You are allowed to:

Share and redistribute the package as it is

Use it for personal or commercial work

You are not allowed to:

Modify the package

Upload modified versions

Change or adapt the source code and redistribute it

Full license text:
https://creativecommons.org/licenses/by-nd/4.0/

Project Status

This project is actively maintained and updated with new patterns and improvements.