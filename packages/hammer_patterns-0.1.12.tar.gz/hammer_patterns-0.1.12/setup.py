from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_desc = f.read()

setup(
    name="hammer-patterns",
    version="0.1.12",  # bump version for PyPI
    packages=find_packages(),
    include_package_data=True,
    description="A lightweight ASCII art library by Deepinder Singh.",
    long_description=long_desc,
    long_description_content_type="text/markdown",
    author="Deepinder Singh",
    author_email="deepindersingh.ac@gmail.com",
    python_requires=">=3.7",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
