"""
FastMCP MCP server entry point, packaged under ibkr_mcp.
"""

from mcp.server.fastmcp import FastMCP
from contextlib import asynccontextmanager
from typing import AsyncIterator
from ib_async import IB
from dotenv import load_dotenv
from dataclasses import dataclass

load_dotenv()

@dataclass
class IbkrContext:
    ib: IB


@asynccontextmanager
async def ibkr_lifespan(server: FastMCP) -> AsyncIterator[IbkrContext]:
    """
    Manages the IB client lifecycle.
    
    Args:
        server: The FastMCP server instance
        
    Yields:
        IbkrContext: The context containing the IB client
    """
    # Create the IB client
    ib = IB()
    await ib.connectAsync('127.0.0.1', 4001, clientId=996)
    
    try:
        yield IbkrContext(ib=ib)
    finally:
        # No explicit cleanup needed for the IB client
        ib.disconnect()

# Create an MCP server
mcp = FastMCP(
    name="ibkr-mcp",
    lifespan=ibkr_lifespan,
)


@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b


@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    """Get a personalized greeting resource."""
    return f"Hello, {name}!"


@mcp.prompt()
def greet_user(name: str, style: str = "friendly") -> str:
    """Generate a greeting prompt."""
    styles = {
        "friendly": "Please write a warm, friendly greeting",
        "formal": "Please write a formal, professional greeting",
        "casual": "Please write a casual, relaxed greeting",
    }

    return f"{styles.get(style, styles['friendly'])} for someone named {name}."


async def serve() -> None:
    """Async entry point for running the MCP server over stdio."""
    await mcp.run_stdio_async()


