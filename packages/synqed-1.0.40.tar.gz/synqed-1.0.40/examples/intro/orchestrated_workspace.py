"""
orchestrated workspace example - inbox-based multi-agent collaboration

This demonstrates the new inbox-based multi-agent communication system:
1. Agents use InboxAgent with built-in memory and structured responses
2. InboxAgentServer provides inbox endpoints (/inbox, /respond)
3. MessageRouter manages turn-based conversation flow
4. True agent-to-agent communication with no conversation history blobs

Architecture:
- Each agent maintains server-side message memory
- Agents respond with structured JSON: {"send_to": "...", "content": "..."}
- Router routes messages one at a time between agents
- No conversation history concatenation - only direct message exchange

Setup:
1. install: pip install synqed anthropic python-dotenv
2. create .env file with: ANTHROPIC_API_KEY='your-key-here'
3. run: python orchestrated_workspace.py
"""
import asyncio
import os
from pathlib import Path
from dotenv import load_dotenv

from synqed.inbox import (
    InboxAgent,
    InboxAgentServer,
    MessageRouter,
    AgentMemory,
    InboxMessage,
    ResponseBuilder,
)

# Load environment variables
load_dotenv()
load_dotenv(dotenv_path=Path(__file__).parent / '.env')


# ============================================================================
# Agent Logic Functions
# ============================================================================

async def writer_logic(
    memory: AgentMemory,
    latest_message: InboxMessage | None,
    builder: ResponseBuilder
) -> str:
    """
    Writer agent logic function.
    
    This function receives:
    - memory: All messages the agent has received
    - latest_message: The most recent message (or None)
    - builder: Helper to create structured responses
    
    Returns:
        JSON string with {"send_to": "Editor", "content": "..."}
    """
    import anthropic
    
    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    
    system_prompt = (
        "You are a creative writer collaborating with an editor. "
        "You receive messages one at a time and respond naturally. "
        "When you want to send a message to the Editor, respond with JSON: "
        '{"send_to": "Editor", "content": "your message here"}. '
        "Be brief and creative."
    )
    
    # Get the latest message from memory
    if not latest_message:
        return builder.send_to("Editor", "I'm ready to start writing!")
    
    # Build conversation context from agent's own memory
    # Only include messages this agent has received
    conversation_parts = []
    for msg in memory.get_messages():
        if msg.from_agent == "USER":
            conversation_parts.append(f"User: {msg.content}")
        elif msg.from_agent == "Editor":
            conversation_parts.append(f"Editor: {msg.content}")
        else:
            conversation_parts.append(f"{msg.from_agent}: {msg.content}")
    
    # Add instruction to respond
    conversation_parts.append("\n\nRespond with JSON: {\"send_to\": \"Editor\", \"content\": \"your response\"}")
    
    conversation_text = "\n\n".join(conversation_parts)
    
    # Call Anthropic API
    resp = client.messages.create(
        model="claude-sonnet-4-5",
        max_tokens=300,
        system=system_prompt,
        messages=[{"role": "user", "content": conversation_text}],
    )
    
    response_text = resp.content[0].text.strip()
    
    # Return the response (InboxAgent will ensure it's valid JSON)
    return response_text


async def editor_logic(
    memory: AgentMemory,
    latest_message: InboxMessage | None,
    builder: ResponseBuilder
) -> str:
    """
    Editor agent logic function.
    
    This function receives:
    - memory: All messages the agent has received
    - latest_message: The most recent message (or None)
    - builder: Helper to create structured responses
    
    Returns:
        JSON string with {"send_to": "Writer", "content": "..."}
    """
    import anthropic
    
    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    
    system_prompt = (
        "You are an editor collaborating with a writer. "
        "You receive messages one at a time and provide feedback. "
        "When you want to send a message to the Writer, respond with JSON: "
        '{"send_to": "Writer", "content": "your message here"}. '
        "Be concise and helpful."
    )
    
    # Get the latest message from memory
    if not latest_message:
        return builder.send_to("Writer", "I'm ready to edit!")
    
    # Build conversation context from agent's own memory
    # Only include messages this agent has received
    conversation_parts = []
    for msg in memory.get_messages():
        if msg.from_agent == "USER":
            conversation_parts.append(f"User: {msg.content}")
        elif msg.from_agent == "Writer":
            conversation_parts.append(f"Writer: {msg.content}")
        else:
            conversation_parts.append(f"{msg.from_agent}: {msg.content}")
    
    # Add instruction to respond
    conversation_parts.append("\n\nRespond with JSON: {\"send_to\": \"Writer\", \"content\": \"your response\"}")
    
    conversation_text = "\n\n".join(conversation_parts)
    
    # Call Anthropic API
    resp = client.messages.create(
        model="claude-sonnet-4-5",
        max_tokens=300,
        system=system_prompt,
        messages=[{"role": "user", "content": conversation_text}],
    )
    
    response_text = resp.content[0].text.strip()
    
    # Return the response (InboxAgent will ensure it's valid JSON)
    return response_text


# ============================================================================
# Turn Callback for Progress Display
# ============================================================================

def turn_callback(turn: int, agent_name: str, response) -> None:
    """Callback function called after each turn to display progress."""
    send_to = response.send_to if hasattr(response, 'send_to') else response.get("send_to", "Unknown")
    content = response.content if hasattr(response, 'content') else response.get("content", "")
    print(f"[Turn {turn}] {agent_name} → {send_to}: {content[:100]}...")


# ============================================================================
# Main Execution
# ============================================================================

async def main():
    print("\n" + "="*80)
    print("  Multi-Agent Collaboration - Inbox-based Communication")
    print("  True agent-to-agent messaging | Server-side memory | Structured responses")
    print("="*80 + "\n")
    
    # Step 1: Create agents using InboxAgent
    print("📝 Creating inbox agents...\n")
    
    writer = InboxAgent(
        name="Writer",
        description="a creative writer specializing in storytelling and narrative",
        skills=["creative_writing", "storytelling", "character_development"],
        logic=writer_logic
    )
    
    editor = InboxAgent(
        name="Editor",
        description="an editor who reviews and improves written content",
        skills=["editing", "proofreading", "content_improvement"],
        logic=editor_logic
    )
    
    print(f"✓ created agent: {writer.name}")
    print(f"✓ created agent: {editor.name}\n")
    
    # Step 2: Start agent servers with inbox endpoints
    print("🚀 Starting inbox agent servers...\n")
    
    writer_server = InboxAgentServer(writer, port=8001)
    editor_server = InboxAgentServer(editor, port=8002)
    
    await writer_server.start_background()
    await editor_server.start_background()
    
    # Give servers time to start
    await asyncio.sleep(2.0)
    
    writer_url = "http://localhost:8001"
    editor_url = "http://localhost:8002"
    
    print(f"✓ writer server running on {writer_url}")
    print(f"✓ editor server running on {editor_url}")
    print(f"✓ endpoints: POST /inbox, GET /inbox, POST /respond\n")
    
    # Step 3: Set up message router
    print("🔀 Setting up message router...\n")
    
    router = MessageRouter()
    router.register_agent("Writer", writer_url)
    router.register_agent("Editor", editor_url)
    
    print(f"✓ registered agents: {list(router.agent_urls.keys())}\n")
    
    # Step 4: Run turn-based conversation
    print("="*80)
    print("  Conversation structure:")
    print("  turn 1: writer → character concept")
    print("  turn 2: editor → feedback on concept")
    print("  turn 3: writer → story draft")
    print("  turn 4: editor → critique and revision")
    print("  turn 5: writer → revised story")
    print("  turn 6: editor → final polish")
    print("="*80 + "\n")
    
    task = "write a short story about a robot learning to paint."
    
    print(f"📋 task: {task}\n")
    print("="*80)
    print("  starting turn-based conversation...")
    print("="*80 + "\n")
    
    # Execute turn-based conversation using router
    transcript = await router.run_turns(
        initial_agent="Writer",
        initial_message=task,
        from_user="USER",
        num_turns=6,
        turn_callback=turn_callback
    )
    
    # Step 5: Display results
    print("\n" + "="*80)
    print("  conversation complete")
    print("="*80 + "\n")
    
    print("✅ task completed successfully!\n")
    
    # Print final message transcript
    print("📜 full conversation transcript (from actual exchanged messages):")
    print("-" * 80)
    for i, msg in enumerate(transcript, 1):
        print(f"\n[{i}] {msg['from']} → {msg['to']}:")
        print(msg['content'])
    print("-" * 80 + "\n")
    
    # Clean up
    print("🧹 cleaning up...")
    
    await writer_server.stop()
    await editor_server.stop()
    
    print("✓ servers stopped\n")
    
    print("="*80)
    print("  demo complete!")
    print("  architecture:")
    print("  • agents use InboxAgent with built-in memory")
    print("  • InboxAgentServer provides inbox endpoints")
    print("  • MessageRouter manages turn-based conversation")
    print("  • true agent-to-agent communication")
    print("  • no conversation history blobs")
    print("="*80 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
