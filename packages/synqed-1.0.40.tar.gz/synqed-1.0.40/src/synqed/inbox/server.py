"""
InboxAgentServer - FastAPI server for InboxAgent with inbox endpoints.

Provides /inbox (POST, GET) and /respond (POST) endpoints for
inbox-based agent communication.
"""
import json
import uuid
from typing import Any, Optional
from fastapi import HTTPException

from a2a.server.agent_execution import RequestContext
from a2a.types import Task, TaskStatus, TaskState

from synqed.server import AgentServer
from synqed.inbox.agent import InboxAgent
from synqed.inbox.memory import get_agent_memory
from synqed.inbox.message import InboxMessage, AgentResponse
from synqed.inbox.response import ResponseBuilder


class InboxAgentServer(AgentServer):
    """Extended AgentServer with inbox endpoints for InboxAgent.
    
    Provides the following endpoints:
    - POST /inbox: Receive a message in the agent's inbox
    - GET /inbox: Get all messages in the agent's inbox
    - POST /respond: Process inbox and generate a response
    
    Example:
        ```python
        agent = InboxAgent(
            name="Writer",
            description="A writer",
            skills=["writing"],
            logic=writer_logic
        )
        
        server = InboxAgentServer(agent, port=8001)
        await server.start_background()
        ```
    """
    
    def __init__(self, agent: InboxAgent, port: int, **kwargs):
        """Initialize InboxAgentServer.
        
        Args:
            agent: The InboxAgent instance to serve
            port: Port to bind to
            **kwargs: Additional arguments passed to AgentServer
        """
        if not isinstance(agent, InboxAgent):
            raise TypeError("InboxAgentServer requires an InboxAgent instance")
        
        super().__init__(agent, port=port, **kwargs)
        self.inbox_agent = agent
        self._add_inbox_endpoints()
    
    def _add_inbox_endpoints(self):
        """Add inbox endpoints to the FastAPI app."""
        
        @self.app.post("/inbox")
        async def post_inbox(message: InboxMessage):
            """Receive a message in the agent's inbox.
            
            Args:
                message: InboxMessage with from_agent and content
                
            Returns:
                Dict with status and agent name
            """
            memory = get_agent_memory(self.inbox_agent.name)
            memory.add_message(message.from_agent, message.content)
            return {
                "status": "received",
                "agent": self.inbox_agent.name,
                "message_count": len(memory)
            }
        
        @self.app.get("/inbox")
        async def get_inbox():
            """Get all messages in the agent's inbox.
            
            Returns:
                Dict with agent name, messages, and count
            """
            memory = get_agent_memory(self.inbox_agent.name)
            return {
                "agent": self.inbox_agent.name,
                "messages": [msg.dict() for msg in memory.get_messages()],
                "count": len(memory)
            }
        
        @self.app.post("/respond")
        async def respond():
            """Process inbox and generate a response.
            
            This endpoint:
            1. Gets the agent's memory
            2. Calls the agent's logic function
            3. Returns a structured AgentResponse
            
            Returns:
                AgentResponse with send_to and content
                
            Raises:
                HTTPException: If response generation fails
            """
            # Create a minimal RequestContext for the logic function
            # The logic functions use agent memory directly, so context is minimal
            task = Task(
                id=str(uuid.uuid4()),
                context_id=str(uuid.uuid4()),
                status=TaskStatus(state=TaskState.working),
                history=[]
            )
            
            context = RequestContext(
                task_id=task.id,
                context_id=task.context_id,
                task=task
            )
            
            # Call the agent's logic function directly
            # The executor wraps it, but we need direct access for the /respond endpoint
            try:
                memory = get_agent_memory(self.inbox_agent.name)
                latest_message = memory.get_latest_message()
                builder = ResponseBuilder()
                
                # Call the user's logic function directly
                # Access via the stored _logic attribute from InboxAgent
                logic_func = getattr(self.inbox_agent, '_logic', None)
                if logic_func is None:
                    raise ValueError("InboxAgent logic function not found")
                
                response_text = await logic_func(memory, latest_message, builder)
                
            except Exception as e:
                import traceback
                error_detail = f"Error generating response: {str(e)}\n{traceback.format_exc()}"
                raise HTTPException(status_code=500, detail=error_detail) from e
            
            # Parse and validate response
            try:
                response_data = json.loads(response_text)
                # Validate structure
                if "send_to" not in response_data or "content" not in response_data:
                    raise ValueError("Invalid response structure")
                return AgentResponse(**response_data)
            except (json.JSONDecodeError, ValueError, KeyError) as e:
                # If not valid JSON, wrap it with default target
                # Try to infer default target from agent name or use "Unknown"
                default_target = "Unknown"
                if "Writer" in self.inbox_agent.name:
                    default_target = "Editor"
                elif "Editor" in self.inbox_agent.name:
                    default_target = "Writer"
                
                wrapped = ResponseBuilder.wrap_text(response_text, default_target)
                response_data = json.loads(wrapped)
                return AgentResponse(**response_data)

