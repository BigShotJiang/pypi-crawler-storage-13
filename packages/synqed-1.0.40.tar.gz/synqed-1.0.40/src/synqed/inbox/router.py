"""
MessageRouter - Routes messages between InboxAgents.

Provides turn-based conversation management and message routing
for inbox-based multi-agent systems.
"""
import httpx
from typing import Dict, List, Optional, Callable, Any
from synqed.inbox.message import AgentResponse, InboxMessage


class MessageRouter:
    """Routes messages between InboxAgents in a turn-based conversation.
    
    The router manages:
    - Agent registration (name -> URL mapping)
    - Message routing between agents
    - Turn-based conversation flow
    - Transcript generation
    
    Example:
        ```python
        router = MessageRouter()
        router.register_agent("Writer", "http://localhost:8001")
        router.register_agent("Editor", "http://localhost:8002")
        
        # Start a conversation
        transcript = await router.run_turns(
            initial_agent="Writer",
            initial_message="Write a story",
            from_user="USER",
            num_turns=6
        )
        ```
    """
    
    def __init__(self, timeout: float = 30.0):
        """Initialize the message router.
        
        Args:
            timeout: HTTP request timeout in seconds
        """
        self.agent_urls: Dict[str, str] = {}
        self.timeout = timeout
    
    def register_agent(self, agent_name: str, agent_url: str) -> None:
        """Register an agent with the router.
        
        Args:
            agent_name: The name of the agent
            agent_url: The base URL of the agent's server
        """
        self.agent_urls[agent_name] = agent_url.rstrip("/")
    
    def unregister_agent(self, agent_name: str) -> None:
        """Unregister an agent from the router.
        
        Args:
            agent_name: The name of the agent to unregister
        """
        if agent_name in self.agent_urls:
            del self.agent_urls[agent_name]
    
    async def send_message(
        self,
        to_agent: str,
        from_agent: str,
        content: str
    ) -> dict:
        """Send a message to an agent's inbox.
        
        Args:
            to_agent: The name of the agent to send to
            from_agent: The name of the agent/user sending the message
            content: The message content
            
        Returns:
            Response dict from the inbox endpoint
            
        Raises:
            ValueError: If agent is not registered
            httpx.HTTPError: If HTTP request fails
        """
        if to_agent not in self.agent_urls:
            raise ValueError(f"Agent '{to_agent}' is not registered")
        
        agent_url = self.agent_urls[to_agent]
        
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                f"{agent_url}/inbox",
                json={
                    "from_agent": from_agent,
                    "content": content
                }
            )
            response.raise_for_status()
            return response.json()
    
    async def get_response(self, agent_name: str) -> AgentResponse:
        """Get a response from an agent.
        
        Args:
            agent_name: The name of the agent to get response from
            
        Returns:
            AgentResponse with send_to and content
            
        Raises:
            ValueError: If agent is not registered
            httpx.HTTPError: If HTTP request fails
        """
        if agent_name not in self.agent_urls:
            raise ValueError(f"Agent '{agent_name}' is not registered")
        
        agent_url = self.agent_urls[agent_name]
        
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(f"{agent_url}/respond")
            response.raise_for_status()
            return AgentResponse(**response.json())
    
    async def route_message(
        self,
        from_agent: str,
        send_to: str,
        content: str
    ) -> dict:
        """Route a message from one agent to another.
        
        Convenience method that combines send_message with validation.
        
        Args:
            from_agent: The name of the sending agent
            send_to: The name of the receiving agent
            content: The message content
            
        Returns:
            Response dict from the inbox endpoint
        """
        return await self.send_message(send_to, from_agent, content)
    
    async def run_turns(
        self,
        initial_agent: str,
        initial_message: str,
        from_user: str = "USER",
        num_turns: int = 6,
        turn_callback: Optional[Callable[[int, str, AgentResponse], None]] = None
    ) -> List[Dict[str, str]]:
        """Run a turn-based conversation between agents.
        
        Args:
            initial_agent: The name of the agent to start with
            initial_message: The initial message to send
            from_user: The name of the user sending the initial message
            num_turns: Number of conversation turns to execute
            turn_callback: Optional callback called after each turn
                          Receives (turn_number, agent_name, response)
        
        Returns:
            List of message dicts with 'from', 'to', and 'content' keys
            
        Raises:
            ValueError: If initial_agent is not registered
        """
        if initial_agent not in self.agent_urls:
            raise ValueError(f"Initial agent '{initial_agent}' is not registered")
        
        transcript: List[Dict[str, str]] = []
        
        # Start conversation: place initial message in initial agent's inbox
        await self.send_message(initial_agent, from_user, initial_message)
        transcript.append({
            "from": from_user,
            "to": initial_agent,
            "content": initial_message
        })
        
        # Track current speaker
        current_agent = initial_agent
        
        # Run turns
        for turn in range(num_turns):
            # Get response from current agent
            try:
                response = await self.get_response(current_agent)
                
                # Add to transcript
                transcript.append({
                    "from": current_agent,
                    "to": response.send_to,
                    "content": response.content
                })
                
                # Call turn callback if provided
                if turn_callback:
                    turn_callback(turn + 1, current_agent, response)
                
                # Route message to target agent's inbox
                if response.send_to not in self.agent_urls:
                    raise ValueError(f"Target agent '{response.send_to}' is not registered")
                
                await self.send_message(response.send_to, current_agent, response.content)
                
                # Switch to target agent for next turn
                current_agent = response.send_to
                
            except Exception as e:
                # Log error and break
                transcript.append({
                    "from": "SYSTEM",
                    "to": "ERROR",
                    "content": f"Turn {turn + 1} failed: {str(e)}"
                })
                break
        
        return transcript
    
    def get_agent_url(self, agent_name: str) -> Optional[str]:
        """Get the URL for a registered agent.
        
        Args:
            agent_name: The name of the agent
            
        Returns:
            The agent's URL, or None if not registered
        """
        return self.agent_urls.get(agent_name)
    
    def list_agents(self) -> List[str]:
        """List all registered agent names.
        
        Returns:
            List of agent names
        """
        return list(self.agent_urls.keys())
    
    def __repr__(self) -> str:
        """String representation of the router."""
        agents = ", ".join(self.agent_urls.keys())
        return f"MessageRouter(agents=[{agents}])"

