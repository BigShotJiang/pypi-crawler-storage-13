"""
Message models for inbox-based agent communication.
"""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class InboxMessage(BaseModel):
    """Message structure for inbox-based communication.
    
    Represents a single message sent to an agent's inbox.
    Each message includes the sender, content, and timestamp.
    """
    from_agent: str
    """The name of the agent or user who sent this message."""
    content: str
    """The message content."""
    timestamp: Optional[str] = None
    """ISO format timestamp when the message was created."""
    
    def __init__(self, **data):
        """Initialize message with automatic timestamp if not provided."""
        if 'timestamp' not in data or data['timestamp'] is None:
            data['timestamp'] = datetime.now().isoformat()
        super().__init__(**data)


class AgentResponse(BaseModel):
    """Structured response from an agent.
    
    Agents must return responses in this format, specifying
    which agent to send the message to and the content.
    """
    send_to: str
    """The name of the agent to send this message to."""
    content: str
    """The message content to send."""

