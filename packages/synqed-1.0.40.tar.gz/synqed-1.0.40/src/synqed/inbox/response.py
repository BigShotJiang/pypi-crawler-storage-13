"""
Response builder helper for inbox-based agents.

Provides utilities for creating structured agent responses.
"""
import json
from typing import Dict, Any
from synqed.inbox.message import AgentResponse


class ResponseBuilder:
    """Helper class for building structured agent responses.
    
    Agents must return JSON with "send_to" and "content" fields.
    This class provides convenient methods to create such responses.
    
    Example:
        ```python
        builder = ResponseBuilder()
        
        # Simple response
        response = builder.send_to("Editor", "Here's my draft")
        
        # Or build manually
        response = builder.build("Editor", "Content here")
        ```
    """
    
    @staticmethod
    def send_to(agent_name: str, content: str) -> str:
        """Create a response to send to a specific agent.
        
        Args:
            agent_name: The name of the agent to send to
            content: The message content
            
        Returns:
            JSON string with {"send_to": agent_name, "content": content}
        """
        return json.dumps({
            "send_to": agent_name,
            "content": content
        })
    
    @staticmethod
    def build(send_to: str, content: str) -> str:
        """Build a structured response (alias for send_to).
        
        Args:
            send_to: The name of the agent to send to
            content: The message content
            
        Returns:
            JSON string with structured response
        """
        return ResponseBuilder.send_to(send_to, content)
    
    @staticmethod
    def wrap_text(text: str, default_target: str) -> str:
        """Wrap plain text into a structured response.
        
        If the text is already valid JSON with send_to/content,
        return it as-is. Otherwise, wrap it.
        
        Args:
            text: The text to wrap (may be JSON or plain text)
            default_target: Default agent to send to if text isn't JSON
            
        Returns:
            JSON string with structured response
        """
        # Try to parse as JSON
        try:
            parsed = json.loads(text)
            if isinstance(parsed, dict) and "send_to" in parsed and "content" in parsed:
                return text  # Already valid
            else:
                # Invalid structure, wrap it
                return ResponseBuilder.send_to(default_target, text)
        except (json.JSONDecodeError, TypeError):
            # Not JSON, wrap it
            return ResponseBuilder.send_to(default_target, text)
    
    @staticmethod
    def validate_response(response_text: str) -> AgentResponse:
        """Validate and parse a response string.
        
        Args:
            response_text: JSON string or plain text
            
        Returns:
            AgentResponse object
            
        Raises:
            ValueError: If response cannot be parsed or is invalid
        """
        try:
            data = json.loads(response_text)
            if not isinstance(data, dict):
                raise ValueError("Response must be a JSON object")
            if "send_to" not in data or "content" not in data:
                raise ValueError("Response must contain 'send_to' and 'content' fields")
            return AgentResponse(**data)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON response: {e}") from e

