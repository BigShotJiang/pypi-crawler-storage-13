"""
Inbox-based multi-agent communication system.

This module provides a clean, inbox-based architecture for multi-agent
systems where agents communicate via structured messages and maintain
their own server-side memory.

Key Components:
- InboxAgent: Agent with built-in memory and structured responses
- InboxAgentServer: FastAPI server with /inbox and /respond endpoints
- MessageRouter: Routes messages between agents in turn-based conversations
- AgentMemory: Server-side memory storage for agents
- ResponseBuilder: Helper for creating structured JSON responses

Example:
    ```python
    from synqed.inbox import InboxAgent, InboxAgentServer, MessageRouter
    
    # Define agent logic
    async def writer_logic(memory, latest_message, builder):
        if not latest_message:
            return builder.send_to("Editor", "Hello!")
        return builder.send_to("Editor", "Here's my draft")
    
    # Create agent
    writer = InboxAgent(
        name="Writer",
        description="A writer",
        skills=["writing"],
        logic=writer_logic
    )
    
    # Start server
    server = InboxAgentServer(writer, port=8001)
    await server.start_background()
    
    # Set up router
    router = MessageRouter()
    router.register_agent("Writer", "http://localhost:8001")
    
    # Run conversation
    transcript = await router.run_turns(
        initial_agent="Writer",
        initial_message="Write a story",
        num_turns=6
    )
    ```
"""
from synqed.inbox.agent import InboxAgent, InboxAgentLogic
from synqed.inbox.server import InboxAgentServer
from synqed.inbox.router import MessageRouter
from synqed.inbox.memory import AgentMemory, MemoryStore, get_agent_memory
from synqed.inbox.message import InboxMessage, AgentResponse
from synqed.inbox.response import ResponseBuilder

__all__ = [
    # Core classes
    "InboxAgent",
    "InboxAgentServer",
    "MessageRouter",
    "AgentMemory",
    "MemoryStore",
    
    # Message models
    "InboxMessage",
    "AgentResponse",
    
    # Helpers
    "ResponseBuilder",
    "get_agent_memory",
    
    # Type hints
    "InboxAgentLogic",
]

