"""
Agent memory abstraction for inbox-based communication.

This module provides server-side memory storage for agents,
allowing them to maintain conversation history independently.
"""
from typing import Dict, List, Optional
from synqed.inbox.message import InboxMessage


class AgentMemory:
    """Server-side memory storage for an agent.
    
    Each agent maintains its own memory instance that stores
    all messages it has received. This allows agents to have
    independent conversation histories.
    
    Example:
        ```python
        memory = AgentMemory("Writer")
        memory.add_message("USER", "Write a story")
        memory.add_message("Editor", "Make it shorter")
        
        latest = memory.get_latest_message()
        all_messages = memory.get_messages()
        ```
    """
    
    def __init__(self, agent_name: str):
        """Initialize memory for an agent.
        
        Args:
            agent_name: The name of the agent this memory belongs to
        """
        self.agent_name = agent_name
        self.messages: List[InboxMessage] = []
    
    def add_message(self, from_agent: str, content: str) -> None:
        """Add a message to the agent's memory.
        
        Args:
            from_agent: The name of the agent/user who sent the message
            content: The message content
        """
        message = InboxMessage(
            from_agent=from_agent,
            content=content
        )
        self.messages.append(message)
    
    def get_messages(self) -> List[InboxMessage]:
        """Get all messages in the agent's memory.
        
        Returns:
            A copy of all messages received by this agent
        """
        return self.messages.copy()
    
    def get_latest_message(self) -> Optional[InboxMessage]:
        """Get the most recent message.
        
        Returns:
            The latest InboxMessage, or None if no messages exist
        """
        return self.messages[-1] if self.messages else None
    
    def clear(self) -> None:
        """Clear all messages from memory."""
        self.messages.clear()
    
    def __len__(self) -> int:
        """Return the number of messages in memory."""
        return len(self.messages)
    
    def __repr__(self) -> str:
        """String representation of the memory."""
        return f"AgentMemory(agent='{self.agent_name}', messages={len(self.messages)})"


class MemoryStore:
    """Global memory store for all agents.
    
    In production, this should be replaced with a proper database.
    For now, it provides in-memory storage per agent.
    
    Example:
        ```python
        store = MemoryStore()
        memory = store.get_memory("Writer")
        memory.add_message("USER", "Hello")
        ```
    """
    
    def __init__(self):
        """Initialize the memory store."""
        self._memories: Dict[str, AgentMemory] = {}
    
    def get_memory(self, agent_name: str) -> AgentMemory:
        """Get or create memory for an agent.
        
        Args:
            agent_name: The name of the agent
            
        Returns:
            AgentMemory instance for the agent
        """
        if agent_name not in self._memories:
            self._memories[agent_name] = AgentMemory(agent_name)
        return self._memories[agent_name]
    
    def clear_memory(self, agent_name: str) -> None:
        """Clear memory for a specific agent.
        
        Args:
            agent_name: The name of the agent
        """
        if agent_name in self._memories:
            self._memories[agent_name].clear()
    
    def clear_all(self) -> None:
        """Clear all agent memories."""
        for memory in self._memories.values():
            memory.clear()
    
    def remove_agent(self, agent_name: str) -> None:
        """Remove an agent's memory from the store.
        
        Args:
            agent_name: The name of the agent
        """
        if agent_name in self._memories:
            del self._memories[agent_name]


# Global memory store instance
_global_store = MemoryStore()


def get_agent_memory(agent_name: str) -> AgentMemory:
    """Get or create memory for an agent (convenience function).
    
    Args:
        agent_name: The name of the agent
        
    Returns:
        AgentMemory instance for the agent
    """
    return _global_store.get_memory(agent_name)

