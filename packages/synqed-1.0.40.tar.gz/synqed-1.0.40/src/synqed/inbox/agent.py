"""
InboxAgent - Agent with built-in inbox memory and structured responses.

This module provides the InboxAgent class, which wraps agent logic
with inbox-based memory management and structured response handling.
"""
import json
from typing import Callable, Coroutine, Any, Optional
from synqed.inbox.memory import AgentMemory, get_agent_memory
from synqed.inbox.message import InboxMessage, AgentResponse
from synqed.inbox.response import ResponseBuilder
from synqed.agent import Agent


class InboxAgentLogic:
    """Type hint for inbox agent logic functions.
    
    Logic functions receive:
    - memory: AgentMemory with all received messages
    - latest_message: The most recent message (or None)
    - response_builder: ResponseBuilder helper for creating responses
    
    They should return a JSON string with {"send_to": "...", "content": "..."}
    """
    LogicFunction = Callable[
        [AgentMemory, Optional[InboxMessage], ResponseBuilder],
        Coroutine[Any, Any, str]
    ]


class InboxAgent(Agent):
    """Agent with built-in inbox memory and structured response handling.
    
    InboxAgent extends the base Agent class with:
    - Server-side message memory
    - Structured JSON response requirements
    - Simplified logic function interface
    
    The logic function receives only:
    - memory: All messages the agent has received
    - latest_message: The most recent message
    - response_builder: Helper to create structured responses
    
    Example:
        ```python
        async def my_logic(memory, latest_message, builder):
            if not latest_message:
                return builder.send_to("OtherAgent", "Hello!")
            
            # Process messages from memory
            for msg in memory.get_messages():
                # ... process ...
            
            return builder.send_to("OtherAgent", "Response")
        
        agent = InboxAgent(
            name="My Agent",
            description="Does something",
            skills=["skill1"],
            logic=my_logic
        )
        ```
    """
    
    def __init__(
        self,
        name: str,
        description: str,
        skills: list[str] | list[dict[str, Any]],
        logic: InboxAgentLogic.LogicFunction,
        version: str = "1.0.0",
        url: str | None = None,
        default_input_modes: list[str] | None = None,
        default_output_modes: list[str] | None = None,
        capabilities: dict[str, Any] | None = None,
        security_schemes: dict[str, Any] | None = None,
    ):
        """Initialize an InboxAgent.
        
        Args:
            name: Human-readable name for the agent
            description: Description of what the agent does
            skills: List of skill names or skill dictionaries
            logic: Async function that processes messages and returns structured JSON
            version: Agent version (default: "1.0.0")
            url: Base URL for the agent (set automatically if using InboxAgentServer)
            default_input_modes: Supported input MIME types
            default_output_modes: Supported output MIME types
            capabilities: Agent capabilities
            security_schemes: Security configuration
        """
        # Wrap the logic function to work with A2A executor interface
        async def wrapped_executor(context):
            """Wrapper that adapts A2A RequestContext to inbox logic."""
            memory = get_agent_memory(name)
            latest_message = memory.get_latest_message()
            builder = ResponseBuilder()
            
            # Call the user's logic function
            response_text = await logic(memory, latest_message, builder)
            
            # Ensure response is valid JSON with send_to/content
            return ResponseBuilder.wrap_text(response_text, "Unknown")
        
        # Initialize base Agent with wrapped executor
        super().__init__(
            name=name,
            description=description,
            skills=skills,
            executor=wrapped_executor,
            version=version,
            url=url,
            default_input_modes=default_input_modes,
            default_output_modes=default_output_modes,
            capabilities=capabilities,
            security_schemes=security_schemes,
        )
        
        self._logic = logic
        self._memory = None  # Will be accessed via get_agent_memory(name)
    
    @property
    def memory(self) -> AgentMemory:
        """Get the agent's memory instance."""
        return get_agent_memory(self.name)
    
    def get_memory(self) -> AgentMemory:
        """Get the agent's memory instance (convenience method)."""
        return self.memory

