"""
Synqed - A simplified wrapper around A2A for multi-agent systems.

This module provides high-level abstractions for creating, managing,
and coordinating AI agents using the A2A protocol.
"""

import asyncio
import aiohttp

from synqed.agent import Agent
from synqed.agent_card import AgentCardBuilder
from synqed.client import Client
from synqed.delegator import TaskDelegator
from synqed.orchestrator import (
    Orchestrator,
    LLMProvider,
    AgentSelection,
    OrchestrationResult,
)
from synqed.server import AgentServer
from synqed.workspace import (
    Workspace,
    WorkspaceState,
    WorkspaceMessage,
    WorkspaceArtifact,
    WorkspaceParticipant,
    MessageType,
)
try:
    from synqed.orchestrated_workspace import (
        OrchestratedWorkspace,
        ConversationPlan,
        ExecutionResult,
        CollaborationMode,
    )
except ImportError:
    # Module doesn't exist, define placeholders or skip
    OrchestratedWorkspace = None
    ConversationPlan = None
    ExecutionResult = None
    CollaborationMode = None
from synqed.message_model import (
    StructuredMessage,
    MessageType as StructuredMessageType,
    MessagePriority,
    MessageMetadata,
    create_suggestion,
    create_critique,
    create_vote,
    create_final_output_proposal,
)

# === Inbox-based Multi-Agent System (Recommended) ===
from synqed.inbox import (
    InboxAgent,
    InboxAgentServer,
    MessageRouter,
    AgentMemory,
    MemoryStore,
    InboxMessage,
    AgentResponse,
    ResponseBuilder,
    get_agent_memory,
)

__version__ = "1.0.8"

__all__ = [
    # === Core Agent Components ===
    "Agent",
    "AgentCardBuilder",
    "AgentServer",
    "Client",
    
    # === Inbox-based Multi-Agent System (Recommended) ===
    "InboxAgent",
    "InboxAgentServer",
    "MessageRouter",
    "AgentMemory",
    "MemoryStore",
    "InboxMessage",
    "AgentResponse",
    "ResponseBuilder",
    "get_agent_memory",
    
    # === Orchestration (Deprecated - use MessageRouter instead) ===
    "TaskDelegator",
    "Orchestrator",
    "LLMProvider",
    "AgentSelection",
    "OrchestrationResult",
    
    # === Workspaces ===
    "Workspace",
    "WorkspaceState",
    "WorkspaceMessage",
    "WorkspaceArtifact",
    "WorkspaceParticipant",
    "MessageType",
    "OrchestratedWorkspace",
    "ConversationPlan",
    "ExecutionResult",
    "CollaborationMode",
    
    # === Message Model ===
    "StructuredMessage",
    "StructuredMessageType",
    "MessagePriority",
    "MessageMetadata",
    "create_suggestion",
    "create_critique",
    "create_vote",
    "create_final_output_proposal",
    
    # === Utils ===
    "asyncio",
    "aiohttp",
]

