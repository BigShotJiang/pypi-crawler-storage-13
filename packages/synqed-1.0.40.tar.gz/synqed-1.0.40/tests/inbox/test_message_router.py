"""
Tests for MessageRouter.
"""
import pytest
from synqed.inbox.router import MessageRouter


def test_message_router_creation():
    """Test creating a MessageRouter."""
    router = MessageRouter()
    assert len(router.list_agents()) == 0


def test_message_router_register_agent():
    """Test registering agents."""
    router = MessageRouter()
    router.register_agent("Writer", "http://localhost:8001")
    router.register_agent("Editor", "http://localhost:8002")
    
    agents = router.list_agents()
    assert "Writer" in agents
    assert "Editor" in agents
    assert len(agents) == 2


def test_message_router_get_agent_url():
    """Test getting agent URLs."""
    router = MessageRouter()
    router.register_agent("Writer", "http://localhost:8001")
    
    url = router.get_agent_url("Writer")
    assert url == "http://localhost:8001"
    
    url = router.get_agent_url("Unknown")
    assert url is None


def test_message_router_unregister_agent():
    """Test unregistering agents."""
    router = MessageRouter()
    router.register_agent("Writer", "http://localhost:8001")
    router.register_agent("Editor", "http://localhost:8002")
    
    assert len(router.list_agents()) == 2
    router.unregister_agent("Writer")
    assert len(router.list_agents()) == 1
    assert "Writer" not in router.list_agents()
    assert "Editor" in router.list_agents()

