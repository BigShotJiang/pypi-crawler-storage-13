"""
Tests for inbox response builder.
"""
import json
import pytest
from synqed.inbox.response import ResponseBuilder
from synqed.inbox.message import AgentResponse


def test_response_builder_send_to():
    """Test creating a response with send_to."""
    response = ResponseBuilder.send_to("Editor", "Hello!")
    
    data = json.loads(response)
    assert data["send_to"] == "Editor"
    assert data["content"] == "Hello!"


def test_response_builder_build():
    """Test the build method (alias for send_to)."""
    response = ResponseBuilder.build("Writer", "Test message")
    
    data = json.loads(response)
    assert data["send_to"] == "Writer"
    assert data["content"] == "Test message"


def test_response_builder_wrap_text():
    """Test wrapping plain text into structured response."""
    # Valid JSON should be returned as-is
    valid_json = '{"send_to": "Editor", "content": "Hello"}'
    wrapped = ResponseBuilder.wrap_text(valid_json, "Writer")
    assert wrapped == valid_json
    
    # Plain text should be wrapped
    plain_text = "Hello, this is plain text"
    wrapped = ResponseBuilder.wrap_text(plain_text, "Editor")
    data = json.loads(wrapped)
    assert data["send_to"] == "Editor"
    assert data["content"] == plain_text
    
    # Invalid JSON structure should be wrapped
    invalid_json = '{"wrong": "structure"}'
    wrapped = ResponseBuilder.wrap_text(invalid_json, "Writer")
    data = json.loads(wrapped)
    assert data["send_to"] == "Writer"
    assert data["content"] == invalid_json


def test_response_builder_validate():
    """Test validating a response."""
    valid_response = '{"send_to": "Editor", "content": "Hello"}'
    response = ResponseBuilder.validate_response(valid_response)
    
    assert isinstance(response, AgentResponse)
    assert response.send_to == "Editor"
    assert response.content == "Hello"
    
    # Invalid JSON should raise ValueError
    with pytest.raises(ValueError):
        ResponseBuilder.validate_response("not json")
    
    # Missing fields should raise ValueError
    with pytest.raises(ValueError):
        ResponseBuilder.validate_response('{"send_to": "Editor"}')

