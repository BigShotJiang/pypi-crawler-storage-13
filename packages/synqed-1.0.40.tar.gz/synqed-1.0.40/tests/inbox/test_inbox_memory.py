"""
Tests for inbox memory system.
"""
import pytest
from synqed.inbox.memory import AgentMemory, MemoryStore, get_agent_memory
from synqed.inbox.message import InboxMessage


def test_agent_memory_creation():
    """Test creating an AgentMemory instance."""
    memory = AgentMemory("TestAgent")
    assert memory.agent_name == "TestAgent"
    assert len(memory) == 0
    assert memory.get_messages() == []


def test_agent_memory_add_message():
    """Test adding messages to memory."""
    memory = AgentMemory("TestAgent")
    memory.add_message("User", "Hello")
    
    assert len(memory) == 1
    messages = memory.get_messages()
    assert len(messages) == 1
    assert messages[0].from_agent == "User"
    assert messages[0].content == "Hello"


def test_agent_memory_get_latest():
    """Test getting the latest message."""
    memory = AgentMemory("TestAgent")
    assert memory.get_latest_message() is None
    
    memory.add_message("User", "First")
    memory.add_message("Agent", "Second")
    
    latest = memory.get_latest_message()
    assert latest is not None
    assert latest.content == "Second"


def test_agent_memory_clear():
    """Test clearing memory."""
    memory = AgentMemory("TestAgent")
    memory.add_message("User", "Hello")
    memory.add_message("Agent", "Hi")
    
    assert len(memory) == 2
    memory.clear()
    assert len(memory) == 0


def test_memory_store():
    """Test MemoryStore functionality."""
    store = MemoryStore()
    
    memory1 = store.get_memory("Agent1")
    memory2 = store.get_memory("Agent2")
    memory1_again = store.get_memory("Agent1")
    
    assert memory1 is memory1_again  # Same instance
    assert memory1 is not memory2  # Different instances
    
    memory1.add_message("User", "Hello")
    assert len(memory1) == 1
    assert len(memory2) == 0


def test_get_agent_memory():
    """Test the convenience function."""
    memory1 = get_agent_memory("TestAgent")
    memory2 = get_agent_memory("TestAgent")
    
    assert memory1 is memory2  # Same instance from global store
    
    memory1.add_message("User", "Test")
    assert len(memory2) == 1  # Shared state

