"""
Tests for inbox-based multi-agent system.
"""

