#server.py
from mcp.server.fastmcp import FastMCP
#Create an MCP server
mcp = FastMCP("Demo")

#Add an addition tool
@mcp.tool()
def add(a:int,b:int)->int:
    """Add two numbers"""
    return a+b

#Add an addition tool
@mcp.tool()
def minus(a:int,b:int)->int:
    """minus two numbers"""
    return a-b

#Add an addition tool
@mcp.tool()
def multiply(a:int,b:int)->int:
    """multiply two numbers"""
    return a*b
#Add a dynamic greeting resource
@mcp.resource("greeting://{name}")
def get_greeting(name:str)->str:
    """Get a greeting for a name"""
    return f"Hello, {name}"

def main() -> None:
    print("Hello from justin-mcpacculate!")
    mcp.run(transport="stdio")   
    #mcp.run(transport="sse")   #http://localhost:8000/sse
    #mcp.run(transport="streamable-http") #http://localhost:8000/mcp