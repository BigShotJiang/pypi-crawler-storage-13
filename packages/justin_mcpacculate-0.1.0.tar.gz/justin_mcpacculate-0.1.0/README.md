# 这个是Justin第一个MCP demo，用来做计算
add/mul/minus