"""PTU (Intel Power Thermal Utility) task."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from hil_testbench.task.command import Command
from hil_testbench.task.specs import Parser, ParserDefinition
from hil_testbench.config.task_config import TaskConfig


class _PTUCsvParser(Parser):
    """Minimal CSV parser for PTU-like output: timestamp,value.

    Produces dicts with keys: timestamp (str), value (float), unit ("W").
    Lines that are empty or malformed are ignored.
    """

    def feed(self, line: str, is_error: bool) -> list[dict[str, Any]]:
        if is_error:
            return []
        text = (line or "").strip()
        if not text:
            return []
        parts = [p.strip() for p in text.split(",")]
        if len(parts) < 2:
            return []
        ts = parts[0]
        try:
            val = float(parts[1])
        except ValueError:
            return []
        return [{"timestamp": ts, "value": val, "unit": "W"}]


@dataclass
class PTUTask:
    """Builds TaskDefinition for PTU monitoring using CSV-like output."""

    bin: str = "ptu"

    def _monitor(self, c, duration: str, interval: str) -> None:  # ExecutionContext
        c.run(f"{self.bin} -mon -t {duration} -int {interval}")

    def task_name(self) -> str:
        return "ptu"

    def commands(self, config: TaskConfig) -> list[Command]:
        """Build PTU monitoring command.

        Config params:
            host_id: Host ID for PTU monitoring (e.g., "server1")
        """
        duration = config.duration or "60"
        interval = config.interval or "1"

        # Get host configuration using helper method
        host = config.get_host_param("host_id")
        if not host:
            raise ValueError("ptu requires 'host_id' in task config")

        def make_run(duration, interval):
            def run(c):
                self._monitor(c, duration=duration, interval=interval)

            return run

        return [
            Command(
                name="ptu_monitor",
                run=make_run(duration, interval),
                host=host,
            )
        ]

    def parser(self, config: TaskConfig) -> ParserDefinition:  # noqa: ARG002
        return ParserDefinition(factory=_PTUCsvParser)
