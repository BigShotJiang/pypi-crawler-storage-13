"""Network throughput benchmarking between hosts across multiple interfaces."""

import json
import re
from typing import Any

from hil_testbench.task.command import Command
from hil_testbench.task.specs import Parser, ParserDefinition
from hil_testbench.config.task_config import TaskConfig


class IperfCommandValidator:
    """Validator for iperf3 commands.

    Validates that:
    - Exit code is 0
    - JSON output was produced
    - Throughput data exists in output
    """

    def validate(
        self,
        exit_code: int,
        stdout: str,
        stderr: str,
        duration: float,
        parameter_count: int = 0,
    ) -> tuple[bool, str | None]:
        """Validate iperf3 command execution."""
        # Check exit code first
        if exit_code != 0:
            # Try to extract error from stderr
            error_lines = [line for line in stderr.split("\n") if line.strip()]
            if error_lines:
                first_error = error_lines[0][:80]
                return False, f"iperf3 failed (exit {exit_code}): {first_error}"
            return False, f"iperf3 exited with code {exit_code}"

        # Check for JSON output
        if not stdout or "{" not in stdout:
            return False, "No JSON output from iperf3"

        # Try to parse JSON and check for throughput data
        try:
            # Look for any JSON object
            for match in re.finditer(r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", stdout):
                obj = json.loads(match.group())

                # Check for interval data (running output)
                intervals = obj.get("intervals")
                if isinstance(intervals, list) and intervals:
                    interval = intervals[-1]
                    if isinstance(interval, dict) and "sum" in interval:
                        bps = interval["sum"].get("bits_per_second")
                        if bps and bps > 0:
                            return True, None

                # Check for final summary
                if "end" in obj and isinstance(obj["end"], dict):
                    summary = obj["end"].get("sum_received") or obj["end"].get(
                        "sum_sent"
                    )
                    if summary and summary.get("bits_per_second", 0) > 0:
                        return True, None

        except (json.JSONDecodeError, KeyError, TypeError):
            return False, "Invalid JSON output from iperf3"

        return False, "No throughput data in iperf3 output"


class IperfTask:
    """Network throughput benchmarking task.

    Config format:
        links:
          - server: host_id
            client: host_id
            port: 5201
            interface: eth0  # optional, label for this link
    """

    task_name = "iperf"
    concurrent = True
    bin = "iperf3"

    def schema(self, config: TaskConfig) -> dict:
        links = config.task_params.get("links", [])
        schema = {}

        for i, link in enumerate(links):
            label = link.get("interface") or f"link{i}"
            schema[f"bits_per_second_{label}"] = {
                "type": float,
                "unit": "bit/second",
                "description": f"Throughput ({label})",
                "precision": 1,
                "scale_strategy": "auto",
                "is_primary": i == 0,  # Mark first link as primary
            }

        return schema

    def parser(self, config: TaskConfig) -> ParserDefinition:
        return ParserDefinition(factory=lambda: _IperfParser())

    def commands(self, config: TaskConfig) -> list[Command]:
        links = config.task_params.get("links", [])
        if not links:
            raise ValueError("iperf task requires 'links' in config")

        duration = config.duration or "60"
        commands = []
        validator = IperfCommandValidator()

        for i, link in enumerate(links):
            server_host = config.get_host(link["server"])
            client_host = config.get_host(link["client"])
            port = link.get("port", 5201 + i)
            label = link.get("interface", f"link{i}")

            commands.append(
                Command(
                    name=f"server_{label}",
                    run=lambda c, p=port: c.run(f"{self.bin} -s -p {p} -1 --json"),
                    host=server_host,
                    validator=validator,
                )
            )

            commands.append(
                Command(
                    name=f"client_{label}",
                    run=lambda c, h=server_host.host, p=port, d=duration: c.run(
                        f"{self.bin} -c {h} -p {p} -t {d} --json"
                    ),
                    host=client_host,
                    validator=validator,
                )
            )

        return commands


class _IperfParser(Parser):
    """Parse iperf3 JSON output."""

    def __init__(self):
        self._buffer = ""

    def feed(
        self, line: str, is_error: bool, context: dict[str, Any] | None = None
    ) -> list[dict]:
        if is_error:
            return []

        self._buffer += line
        events = []

        # Extract label from command name (e.g., "client_eth0" -> "eth0")
        label = "link0"
        if context and "command_name" in context:
            parts = context["command_name"].split("_", 1)
            if len(parts) > 1:
                label = parts[1]

        for obj_str in re.findall(r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", self._buffer):
            try:
                obj = json.loads(obj_str)

                # Extract interval data
                intervals = obj.get("intervals")
                if isinstance(intervals, list) and intervals:
                    interval = intervals[-1]
                else:
                    interval = obj.get("interval")

                if isinstance(interval, dict) and "sum" in interval:
                    bps = interval["sum"].get("bits_per_second")
                    if bps:
                        events.append({f"bits_per_second_{label}": bps})

                self._buffer = self._buffer.replace(obj_str, "", 1)
            except json.JSONDecodeError:
                continue

        return events
