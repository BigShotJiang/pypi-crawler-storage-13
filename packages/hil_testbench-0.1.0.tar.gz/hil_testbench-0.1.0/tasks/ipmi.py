"""IPMI task provider using task pipeline and multi-metric events.

Parses ipmitool sensor output and emits per-sensor events with thresholds.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from hil_testbench.task.command import Command
from hil_testbench.task.specs import Parser, ParserDefinition
from hil_testbench.config.task_config import TaskConfig


def _sensor_thresholds(sensor_name: str, unit: str) -> dict[str, Any]:
    name_lower = sensor_name.lower()

    if "temp" in name_lower:
        return {
            "thresholds": {"good": (0, 65), "warn": (65, 80), "bad": (80, 100)},
            "threshold_mode": "lower",
        }
    if "fan" in name_lower and unit.lower() == "rpm":
        return {
            "thresholds": {"good": (1500, 10000), "warn": (800, 1500), "bad": (0, 800)},
            "threshold_mode": "higher",
        }
    if "volt" in name_lower or unit == "V":
        # Use wide generic bounds if nominal not detected
        return {
            "thresholds": {"good": (0.9, 12.6), "warn": (0.7, 0.9), "bad": (0, 0.7)},
            "threshold_mode": "higher",
        }
    if "w" in unit.lower() or "power" in name_lower:
        return {
            "thresholds": {"good": (0, 300), "warn": (300, 500), "bad": (500, 10000)},
            "threshold_mode": "lower",
        }
    if "load" in name_lower:
        return {
            "thresholds": {"good": (0, 50), "warn": (50, 80), "bad": (80, 100)},
            "threshold_mode": "lower",
        }
    return {"thresholds": None, "threshold_mode": "higher"}


class _IPMIParser(Parser):
    """Parse ipmitool sensor lines of the form:
    Sensor Name | value | Unit Description
    """

    def __init__(self) -> None:
        self._sensor_re = re.compile(r"^([^|]+)\|\s*([^|]+?)\s*\|\s*(.+)$")

    def feed(self, line: str, is_error: bool) -> list[dict[str, Any]]:
        if is_error or not line:
            return []

        text = line.strip()
        if not text or text.startswith("=== TIMESTAMP:"):
            return []

        m = self._sensor_re.match(text)
        if not m:
            return []

        sensor_name = m.group(1).strip()
        value_field = m.group(2).strip()
        unit_description = m.group(3).strip()

        num = re.search(r"([0-9.]+)", value_field)
        if not num:
            return []

        try:
            value = float(num.group(1))
        except ValueError:
            return []

        unit = unit_description
        low = unit.lower()
        if "degrees c" in low:
            unit = "°C"
        elif low == "volts":
            unit = "V"
        elif low in ("state", "status"):
            return []

        th = _sensor_thresholds(sensor_name, unit)

        event = {
            "sensor_name": sensor_name,
            "param_name": sensor_name,  # for multi-metric display routing
            "value": value,
            "unit": unit,
            **th,
        }
        return [event]


@dataclass
class IPMITask:
    """Builds TaskDefinition for IPMI sensor monitoring."""

    bin: str = "ipmitool"

    def _monitor(self, c, duration: str, interval: str) -> None:
        duration_int = int(duration)
        if duration_int == 0:
            script = (
                "#!/bin/sh\n"
                "while true; do\n"
                '  echo "=== TIMESTAMP: $(date) ==="\n'
                f'  {self.bin} sensor chassis status sdr 2>&1 || echo "ERROR: ipmitool not found"\n'
                f"  sleep {interval}\n"
                "done\n"
            )
        else:
            max_iter = duration_int // int(interval)
            iterations = " ".join(str(i) for i in range(1, max_iter + 1))
            script = (
                "#!/bin/sh\n"
                f"for i in {iterations}; do\n"
                '  echo "=== TIMESTAMP: $(date) ==="\n'
                f'  {self.bin} sensor chassis status sdr 2>&1 || echo "ERROR: ipmitool not found"\n'
                f'  test "$i" = "{max_iter}" || sleep {interval}\n'
                "done\n"
            )

        c.run(f"cat > /tmp/ipmi_monitor.sh << 'EOFSCRIPT'\n{script}EOFSCRIPT\n")
        c.run("chmod +x /tmp/ipmi_monitor.sh")
        c.run("/tmp/ipmi_monitor.sh")
        c.run("rm -f /tmp/ipmi_monitor.sh")

    def task_name(self) -> str:
        return "ipmi"

    def commands(self, config: TaskConfig) -> list[Command]:
        """Build IPMI monitoring command.

        Config params:
            host_id: Host ID for IPMI monitoring (e.g., "server1")
        """
        duration = config.duration or "60"
        interval = config.interval or "5"

        # Get host configuration using helper method
        host = config.get_host_param("host_id")
        if not host:
            raise ValueError("ipmi requires 'host_id' in task config")

        def make_run(duration, interval):
            def run(c):
                self._monitor(c, duration=duration, interval=interval)

            return run

        return [
            Command(
                name="ipmi_monitor",
                run=make_run(duration, interval),
                host=host,
            )
        ]

    def parser(self, config: TaskConfig) -> ParserDefinition:  # noqa: ARG002
        return ParserDefinition(factory=_IPMIParser)
