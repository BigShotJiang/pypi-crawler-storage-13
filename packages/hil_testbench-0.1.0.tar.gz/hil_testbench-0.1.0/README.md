# HIL Testbench

A Hardware-in-Loop (HIL) testbench framework for concurrent task execution, running commands locally and remotely via SSH, with structured logging, health monitoring, and live metrics dashboard.

## Features
- Concurrent local/remote task execution
- Structured JSONL logging
- Health monitoring (CPU, memory, disk)
- Live metrics dashboard
- Extensible task definitions

## License
MIT License (see LICENSE)
