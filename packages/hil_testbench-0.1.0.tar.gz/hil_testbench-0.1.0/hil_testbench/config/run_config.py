"""Run configuration for the task executor."""

from typing import Any
from dataclasses import dataclass, field
from hil_testbench.data_structs.config_data import CleanupMode


@dataclass
class RunConfig:
    """Global runner configuration (applies to all tasks in a run)."""

    # Logging configuration (global/main only)
    # When a log file reaches max size, it rotates (creates .1, .2, etc for long-running programs)
    max_log_size_main_mb: int = 10  # Triggers rotation when main log hits this size
    max_log_file_count_main: int = 10  # Keep this many rotated main log files
    log_level: str = "INFO"  # Main logger level: DEBUG, INFO, WARNING, ERROR

    # Local host health monitoring (TaskRunner machine only)
    # Tracks CPU, memory, disk space, thread count for the local process host.
    # Remote SSH hosts are NOT monitored.
    enable_runner_health: bool = True
    runner_health_interval: int = 600

    # Cleanup settings
    force_cleanup: bool = False
    cleanup_mode: CleanupMode = CleanupMode.NONE

    # PTY settings
    disable_pty: bool = (
        False  # Set True to force subprocess mode (useful with VS Code ConPTY)
    )

    # Infrastructure: all configured hosts
    # Format: {"server1": {"host": "110.212.30.100", "user": "my_user", ...}, ...}
    hosts: dict[str, dict[str, Any]] = field(default_factory=dict)

    @classmethod
    def from_yaml(cls, yaml_data: dict[str, Any]) -> "RunConfig":
        """Create RunConfig from YAML configuration dict.

        Example YAML structure:
            hosts:
              server1:
                host: 110.212.30.100
                user: my_user
                port: 22
                password: ""

        Args:
            yaml_data: Loaded YAML dict (typically from yaml.safe_load())

        Returns:
            RunConfig with hosts populated from YAML
        """
        return cls(
            hosts=yaml_data.get("hosts", {}),
            # Other fields use dataclass defaults unless overridden in YAML
            max_log_size_main_mb=yaml_data.get("max_log_size_main_mb", 10),
            max_log_file_count_main=yaml_data.get("max_log_file_count_main", 10),
            log_level=yaml_data.get("log_level", "INFO").upper(),
            enable_runner_health=yaml_data.get("enable_health", True),
            runner_health_interval=yaml_data.get("health_interval", 600),
            disable_pty=yaml_data.get("disable_pty", False),
        )
