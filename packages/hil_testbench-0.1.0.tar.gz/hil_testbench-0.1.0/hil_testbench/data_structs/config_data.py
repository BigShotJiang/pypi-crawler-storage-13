from enum import Enum


class CleanupMode(Enum):
    """Cleanup execution timing modes."""

    STARTUP = "startup"
    SHUTDOWN = "shutdown"
    BOTH = "both"
    NONE = "none"
