"""
Parameter schema and threshold definitions for framework-wide use.
"""

from dataclasses import dataclass, field
from typing import Union


@dataclass
class Threshold:
    """Definition of a threshold for parameter monitoring."""

    value: Union[float, tuple[float, float]]
    mode: str  # "lt", "gt", "eq", "range"
    color: Union[str, int] = ""
    description: str = ""


@dataclass
class ParameterField:
    """Definition of a single parameter field in the schema."""

    name: str
    type: type
    unit: str = ""
    description: str = ""
    is_summary: bool = False
    is_primary: bool = False  # Primary parameter for task summary
    thresholds: dict[str, Threshold] = field(default_factory=dict)

    # Visualization settings (YAML-overridable)
    display_enabled: bool = True
    trendline_length: int = 30
    trendline_window_sec: float = 60.0
    display_order: int = 0
    display_group: str = ""
    precision: int = 2  # Decimal places for value display
    scale_strategy: str = "raw"  # "raw" | "auto" - unit scaling behavior
    normalize_range: tuple[float, float] | None = None


@dataclass
class ParametersSchema:
    """Schema defining expected parameters and their properties."""

    fields: list[ParameterField] = field(default_factory=list)
