"""Base widget protocol and rendering infrastructure."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Protocol

from rich.text import Text


class VisualizationMode(Enum):
    """Display verbosity levels."""

    MINIMAL = "minimal"  # Status + primary value only
    NORMAL = "normal"  # + trendline + progress
    FULL = "full"  # + all parameters + commands


@dataclass
class WidgetContext:
    """Rendering context passed to widgets."""

    mode: VisualizationMode
    max_width: int = 80
    color_enabled: bool = True
    unicode_enabled: bool = True
    emoji_enabled: bool = True
    compact: bool = False  # Override to force compact rendering

    def is_minimal(self) -> bool:
        """Check if minimal rendering should be used."""
        return self.mode == VisualizationMode.MINIMAL or self.compact


@dataclass
class RenderOutput:
    """Widget rendering result."""

    rich_text: Text  # Rich-formatted text
    plain_text: str  # Plain text fallback
    width: int  # Character width

    @classmethod
    def from_text(cls, text: Text) -> RenderOutput:
        """Create RenderOutput from Rich Text object."""
        return cls(rich_text=text, plain_text=text.plain, width=len(text.plain))


class Widget(Protocol):
    """Base protocol for all widgets."""

    def render(self, context: WidgetContext) -> RenderOutput:
        """Render widget to Rich Text with context awareness."""
        ...
