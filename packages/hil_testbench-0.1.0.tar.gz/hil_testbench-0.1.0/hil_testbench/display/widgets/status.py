"""Status widget for task/command status indicators."""

from __future__ import annotations

from rich.text import Text

from hil_testbench.display.widgets.base import RenderOutput, WidgetContext
from hil_testbench.display.widgets.theme import get_theme


class StatusWidget:
    """Status indicator with icon and optional text."""

    def __init__(self, status: str, show_text: bool = False):
        """
        Args:
            status: Status string (not_started, running, completed, failed, stale)
            show_text: Whether to show text label after icon
        """
        self.status = status
        self.show_text = show_text

    def render(self, context: WidgetContext) -> RenderOutput:
        """Render status icon with optional text."""
        theme = get_theme()
        icon = theme.status_icons.get(self.status, "?")

        # Determine color
        color_map = {
            "completed": "green",
            "failed": "red",
            "running": "yellow",
            "stale": "yellow",
            "not_started": "dim",
        }
        color = color_map.get(self.status, "white")

        text = Text(icon, style=color)

        if self.show_text:
            status_text = self.status.upper().replace("_", " ")
            text.append(f" {status_text}", style=color)

        return RenderOutput.from_text(text)
