from dataclasses import dataclass
from datetime import datetime


@dataclass
class CommandResult:
    """Result of a command execution."""

    command_name: str
    success: bool
    return_code: int
    stdout: str = ""
    stderr: str = ""
    error: Exception | None = None
    start_time: datetime | None = None
    end_time: datetime | None = None
    duration: float | None = None

    def __repr__(self) -> str:
        status = "SUCCESS" if self.success else "FAILED"
        return f"CommandResult(command='{self.command_name}', status={status}, code={self.return_code})"
