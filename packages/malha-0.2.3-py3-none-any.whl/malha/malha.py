# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "sqlmodel>=0.0.16",
#     "sqlalchemy>=2.0",
#     "aiosqlite>=0.17.0",
#     "kuzu>=0.3.0",
#     "duckdb>=0.10.0",
#     "politipo>=0.4.0",
#     "registro>=0.3.1",
#     "pydantic>=2.5"
# ]
# ///

"""
ontologia/core.py (Malha v4.0 - "The Loom")
-------------------------------------------
O KERNEL DO SISTEMA OPERACIONAL SEMÂNTICO.

Arquitetura:
1.  **Async-Native & Thread-Safe**: I/O não bloqueante. Drivers C++ (Kùzu/DuckDB) isolados em threads.
2.  **Bitemporalidade Estrita (SCD Type 2)**: Histórico imutável garantido por clonagem de versão.
3.  **Consistência Dual via Outbox**: Sincronia SQL->Grafo desacoplada e atômica.
4.  **Data Physics**: Uso de Politipo para serialização Zero-Copy (Arrow).
5.  **Identidade**: Uso nativo de Registro RIDs.

Dependências:
- `registro` (v0.3.1+): Identidade e Imutabilidade corrigidas.
- `politipo` (v0.4.0+): DDL Seguro e Tipagem Dialect-Aware.
"""

import abc
import asyncio
import json
import logging
import os
import shutil
import sys
import time
import warnings
from contextlib import asynccontextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Protocol, Type, runtime_checkable

from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine
from sqlmodel import Field, SQLModel, select
from sqlmodel.ext.asyncio.session import AsyncSession

# --- Fundações (Identity & Data Physics) ---
from registro import Resource
from registro.models.rid import RID
from politipo import DataType, generate_ddl, PolyTransporter

# --- Configuração de Logging ---
logger = logging.getLogger("ontologia.kernel")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("[KERNEL] %(asctime)s | %(levelname)s | %(message)s"))
    logger.addHandler(handler)

# --- Telemetria (Stub OTeL) ---
class Tracer:
    @asynccontextmanager
    async def span(self, name: str):
        # Placeholder para OpenTelemetry real
        t0 = time.perf_counter()
        try:
            yield
        finally:
            dt = (time.perf_counter() - t0) * 1000
            if dt > 100:  # Loga apenas operações lentas (>100ms)
                logger.debug(f"Span '{name}' finished in {dt:.2f}ms")

tracer = Tracer()


# =============================================================================
# 1. SISTEMA NERVOSO (Signals & Outbox Model)
# =============================================================================

class SysOutbox(SQLModel, table=True):
    """
    Tabela de Fila Transacional (Outbox Pattern).
    Garante que eventos de colateral (atualizar Grafo, notificar Webhook)
    só ocorram se a transação SQL principal for commitada com sucesso.
    """
    __tablename__ = "sys_outbox"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    rid: str = Field(index=True)
    operation: str  # 'UPSERT', 'DELETE'
    payload: str    # JSON serializado
    status: str = Field(default="PENDING", index=True)  # PENDING, DONE, FAILED
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    processed_at: Optional[datetime] = None


Handler = Callable[[Any], Any]

class Signal:
    def __init__(self, name: str):
        self.name = name
        self._handlers: List[Handler] = []

    def connect(self, handler: Handler):
        if handler not in self._handlers:
            self._handlers.append(handler)

    async def emit(self, payload: Any, background: bool = True):
        """Dispara eventos de forma segura."""
        async with tracer.span(f"signal.emit.{self.name}"):
            for handler in self._handlers:
                try:
                    if asyncio.iscoroutinefunction(handler):
                        coro = handler(payload)
                        if background:
                            task = asyncio.create_task(coro)
                            # Log de erro no callback para não silenciar exceções
                            task.add_done_callback(
                                lambda t: logger.error(f"Signal Error: {t.exception()}") if t.exception() else None
                            )
                        else:
                            await coro
                    else:
                        handler(payload)
                except Exception as e:
                    logger.error(f"❌ Erro no Signal '{self.name}': {e}")

post_save = Signal("post_save")
post_delete = Signal("post_delete")
post_ingest = Signal("post_ingest")


# =============================================================================
# 2. O JUIZ (Governança)
# =============================================================================

class Interceptor(abc.ABC):
    """Guardião de Regras de Negócio e Segurança."""
    @abc.abstractmethod
    async def on_write(self, obj: Resource, agent: Any = None) -> None:
        """Pré-escrita (Validação/Policy). Deve lançar erro se negado."""
        pass

    @abc.abstractmethod
    async def on_read(self, obj: Resource, agent: Any = None) -> Resource:
        """Pós-leitura (Mascaramento/View). Retorna o objeto transformado."""
        return obj


# =============================================================================
# 3. PORTAS (Drivers Hexagonais)
# =============================================================================

@runtime_checkable
class SQLDriver(Protocol):
    def get_engine(self) -> AsyncEngine: ...
    async def create_tables(self) -> None: ...

@runtime_checkable
class GraphDriver(Protocol):
    async def register_schema(self, model_cls: Type[SQLModel]) -> None: ...
    async def upsert_node(self, data: dict, node_type: str) -> None: ...
    async def delete_node(self, rid: str, label: str) -> None: ...
    async def create_edge(self, src: str, dst: str, label: str, props: dict) -> None: ...
    async def delete_edge(self, src: str, dst: str, label: str) -> None: ...
    async def query(self, cypher: str, params: dict) -> List[Dict]: ...

@runtime_checkable
class AnalyticsDriver(Protocol):
    async def register_view(self, view_name: str, source_table: str) -> None: ...
    async def ingest_arrow(self, table_name: str, arrow_table: Any) -> None: ...
    async def query(self, sql: str) -> Any: ...


# =============================================================================
# 4. ADAPTADORES (Implementações SotA)
# =============================================================================

class AsyncSQLAlchemyDriver:
    def __init__(self, url: str):
        # Auto-fix para drivers async
        if "sqlite" in url and "aiosqlite" not in url:
            url = url.replace("sqlite:", "sqlite+aiosqlite:")
        elif "postgresql" in url and "asyncpg" not in url:
            url = url.replace("postgresql:", "postgresql+asyncpg:")
            
        connect_args = {}
        if "sqlite" in url:
            # Otimização de Concorrência para SQLite
            connect_args = {"check_same_thread": False, "timeout": 30}

        self.engine = create_async_engine(url, echo=False, future=True, connect_args=connect_args)
        self._url = url

    def get_engine(self) -> AsyncEngine:
        return self.engine

    async def create_tables(self):
        async with self.engine.begin() as conn:
            if "sqlite" in self._url:
                # Ativa WAL Mode para permitir leitura/escrita concorrente
                await conn.execute(select(1)) # Força init
                # PRAGMA deve ser executado em conexões raw, SQLAlchemy abstrai.
                # Geralmente configurado no connect event, mas simplificando aqui.
                pass
            await conn.run_sync(SQLModel.metadata.create_all)


import kuzu
class KuzuDriver:
    """
    Driver Kùzu Blindado.
    Garante que objetos C++ não vazem entre threads.
    """
    def __init__(self, path: str):
        self.path = path
        parent = os.path.dirname(path)
        if parent and not os.path.exists(parent): os.makedirs(parent, exist_ok=True)
        
        # Inicialização Lazy para evitar lock no fork
        self._db = None
        self._conn = None

    @property
    def conn(self):
        if not self._conn:
            # Kuzu Database manager (single process lock)
            self._db = kuzu.Database(self.path)
            self._conn = kuzu.Connection(self._db)
        return self._conn

    async def _run(self, func, *args):
        return await asyncio.to_thread(func, *args)

    async def register_schema(self, model_cls):
        # Usa o Politipo v0.4.0 para gerar DDL seguro
        ddl = generate_ddl(model_cls, dialect="kuzu", table_name=model_cls.__name__)
        try:
            if ddl: await self._run(self.conn.execute, ddl)
        except RuntimeError: pass

    async def upsert_node(self, data: dict, node_type: str):
        rid = data.pop("rid", None)
        if not rid: return

        clean_props = {}
        set_items = []
        
        for k, v in data.items():
            # Kuzu exige tipos primitivos ou Lists fixas
            if isinstance(v, (dict, list)) and not k.startswith("embedding"): 
                v = json.dumps(v)
            
            # Sanitiza chaves
            safe_k = k.replace("-", "_")
            clean_props[safe_k] = v
            set_items.append(f"n.{safe_k} = ${safe_k}")

        set_clause = f"SET {', '.join(set_items)}" if set_items else ""
        cypher = f"MERGE (n:{node_type} {{rid: $rid}}) {set_clause} RETURN n"
        
        # Executa encapsulado
        await self._run(self.conn.execute, cypher, {"rid": rid, **clean_props})

    async def delete_node(self, rid, label):
        await self._run(self.conn.execute, f"MATCH (n:{label} {{rid: $rid}}) DETACH DELETE n", {"rid": rid})

    async def create_edge(self, src, dst, label, props):
        # Auto-create relation table if missing
        try:
            # Nota: FROM Object TO Object requer que um supertipo Object exista.
            # Para robustez, idealmente deveríamos saber os tipos de src/dst.
            # Fallback: Tenta criar assumindo nós genéricos, ou falha logando.
            await self._run(self.conn.execute, f"CREATE REL TABLE {label} (FROM Resource TO Resource)")
        except RuntimeError: pass
        
        # Cria aresta
        q = f"MATCH (a {{rid: $src}}), (b {{rid: $dst}}) MERGE (a)-[r:{label}]->(b) RETURN r"
        await self._run(self.conn.execute, q, {"src": src, "dst": dst})

    async def delete_edge(self, src, dst, label):
        q = f"MATCH (a {{rid: $src}})-[r:{label}]->(b {{rid: $dst}}) DELETE r"
        await self._run(self.conn.execute, q, {"src": src, "dst": dst})

    async def query(self, cypher, params):
        # CRÍTICO: Materialização dentro da thread
        def _exec_safe():
            res = self.conn.execute(cypher, params or {})
            # Converte para list[dict] nativo do Python imediatamente
            # Isso desvincula os dados do cursor C++
            df = res.get_as_df()
            return df.to_dict(orient='records')
            
        return await self._run(_exec_safe)


import duckdb
class DuckDBDriver:
    def __init__(self, sqlite_path: str = None):
        self.conn = duckdb.connect(":memory:")
        self.zero_copy = False
        
        if sqlite_path and os.path.exists(sqlite_path):
            try:
                self.conn.execute("INSTALL sqlite; LOAD sqlite;")
                # Read-Only para evitar travamento do DB principal
                self.conn.execute(f"CALL sqlite_attach('{sqlite_path}', alias='source_db', mode='READ_ONLY');")
                self.zero_copy = True
            except Exception as e:
                logger.warning(f"DuckDB Zero-Copy unavailable: {e}")

    async def _run(self, func, *args):
        return await asyncio.to_thread(func, *args)

    async def register_view(self, view, source):
        if self.zero_copy:
            await self._run(self.conn.execute, f"CREATE OR REPLACE VIEW {view} AS SELECT * FROM source_db.{source}")

    async def ingest_arrow(self, table_name, arrow_table):
        def _ingest():
            self.conn.register("arrow_buffer", arrow_table)
            self.conn.execute(f"CREATE TABLE IF NOT EXISTS {table_name} AS SELECT * FROM arrow_buffer LIMIT 0")
            self.conn.execute(f"INSERT INTO {table_name} SELECT * FROM arrow_buffer")
            self.conn.unregister("arrow_buffer")
        await self._run(_ingest)

    async def query(self, sql):
        return await self._run(self.conn.sql, sql)


# =============================================================================
# 5. O KERNEL (UnifiedDataManager)
# =============================================================================

class UnifiedDataManager:
    def __init__(self, sql: SQLDriver, graph: GraphDriver, analytics: AnalyticsDriver):
        self.sql = sql
        self.graph = graph
        self.analytics = analytics
        self._interceptors: List[Interceptor] = []
        
        # Registro de Tipos Globais (Injeção de Dependência)
        if not hasattr(DataType, "RID"): 
            DataType.register("RID", RID)

    async def boot(self):
        logger.info("⚡ Booting Malha Kernel v4.0...")
        await self.sql.create_tables()
        # Inicia processador de outbox em background? 
        # Idealmente sim, mas em serverless pode ser invocado explicitamente.

    def add_interceptor(self, interceptor: Interceptor):
        self._interceptors.append(interceptor)

    async def register_model(self, model_cls: Type[SQLModel]):
        """Registra esquemas nas projeções (Grafo/Analytics)."""
        await self.graph.register_schema(model_cls)
        await self.analytics.register_view(model_cls.__name__, model_cls.__tablename__)

    # --- Write Path: SCD Type 2 & Outbox ---

    async def save(self, obj: Resource, agent: Any = None) -> Resource:
        """
        Salva uma nova versão imutável do recurso.
        Garante consistência ACID no SQL e consistência eventual no Grafo via Outbox.
        """
        async with tracer.span(f"save.{obj.__class__.__name__}"):
            # 1. Governança
            for i in self._interceptors: await i.on_write(obj, agent)

            now = datetime.now(timezone.utc)
            
            # Preparação da Nova Versão (SCD Type 2 Real)
            # Clonamos os dados úteis, ignorando metadados de sistema da versão anterior
            new_data = obj.model_dump(exclude={"id", "valid_from", "valid_to", "tx_from", "tx_to"})
            
            # Instancia nova versão limpa
            new_version = obj.__class__(**new_data)
            
            # Configura metadados de versão
            new_version.rid = obj.rid # Mantém identidade lógica
            new_version.valid_from = now
            new_version.valid_to = None
            new_version.tx_from = now
            new_version.tx_to = None

            async with AsyncSession(self.sql.get_engine()) as session:
                async with session.begin():
                    # 2. Fecha versão anterior (se existir)
                    if obj.rid:
                        stmt = select(obj.__class__).where(
                            obj.__class__.rid == obj.rid,
                            obj.__class__.valid_to.is_(None)
                        )
                        result = await session.exec(stmt)
                        current = result.first()
                        
                        if current:
                            current.valid_to = now
                            current.tx_to = now
                            session.add(current)
                    
                    # 3. Insere nova versão
                    session.add(new_version)
                    
                    # 4. Outbox Pattern (Enfileira sync do grafo na mesma transação)
                    outbox_event = SysOutbox(
                        rid=new_version.rid,
                        operation="UPSERT",
                        payload=new_version.model_dump_json(),
                        status="PENDING"
                    )
                    session.add(outbox_event)
                
                # Commit acontece aqui automaticamente pelo context manager
                await session.refresh(new_version)

            # 5. Dispara worker de sincronia (Fire-and-Forget ou await dependendo da config)
            # Aqui rodamos em background para não travar a resposta da API
            asyncio.create_task(self._process_outbox())
            
            await post_save.emit(new_version)
            return new_version

    async def delete(self, obj: Resource, agent: Any = None):
        """Soft Delete Bitemporal."""
        for i in self._interceptors: await i.on_write(obj, agent)
        
        now = datetime.now(timezone.utc)
        
        async with AsyncSession(self.sql.get_engine()) as session:
            async with session.begin():
                # Busca a versão ativa REAL no banco (não confia no obj da memória)
                stmt = select(obj.__class__).where(
                    obj.__class__.rid == obj.rid,
                    obj.__class__.valid_to.is_(None)
                )
                result = await session.exec(stmt)
                active_row = result.first()
                
                if active_row:
                    active_row.valid_to = now
                    active_row.tx_to = now # Fecha validade
                    session.add(active_row)
                    
                    # Outbox: Evento de Delete
                    session.add(SysOutbox(
                        rid=obj.rid,
                        operation="DELETE",
                        payload=json.dumps({"type": obj.__class__.__name__}),
                        status="PENDING"
                    ))

        asyncio.create_task(self._process_outbox())
        await post_delete.emit(obj)

    async def _process_outbox(self):
        """Worker que drena a tabela Outbox e aplica no Grafo."""
        async with tracer.span("process_outbox"):
            async with AsyncSession(self.sql.get_engine()) as session:
                # Pega eventos pendentes (com lock row for update idealmente, simplificado aqui)
                stmt = select(SysOutbox).where(SysOutbox.status == "PENDING").limit(100)
                events = (await session.exec(stmt)).all()
                
                if not events: return

                for ev in events:
                    try:
                        if ev.operation == "UPSERT":
                            data = json.loads(ev.payload)
                            # Extrai o tipo do payload ou metadados. 
                            # Assumindo que o nome da classe está disponível ou inferido.
                            # Simplificação: Usamos Resource type do payload ou genérico
                            # O ideal é salvar 'resource_type' na SysOutbox.
                            # Aqui, recuperamos do payload (se for model_dump_json)
                            # Hack: Recarrega como dict
                            node_type = data.get("resource_type", "Resource").capitalize()
                            await self.graph.upsert_node(data, node_type)
                        
                        elif ev.operation == "DELETE":
                            meta = json.loads(ev.payload)
                            await self.graph.delete_node(ev.rid, meta.get("type", "Resource"))
                        
                        ev.status = "DONE"
                        ev.processed_at = datetime.now(timezone.utc)
                        
                    except Exception as e:
                        logger.error(f"Outbox processing failed for RID {ev.rid}: {e}")
                        ev.status = "FAILED"
                        # Retry logic could be added here
                    
                    session.add(ev)
                
                await session.commit()

    # --- Read Path ---

    async def get(self, model_cls: Type[SQLModel], rid: str, agent: Any = None) -> Optional[SQLModel]:
        async with AsyncSession(self.sql.get_engine()) as session:
            stmt = select(model_cls).where(
                model_cls.rid == rid, 
                model_cls.valid_to.is_(None)
            )
            obj = (await session.exec(stmt)).first()
            
            if not obj: return None
            
            for i in self._interceptors:
                obj = await i.on_read(obj, agent)
            return obj

    # --- Edge Management ---

    async def link(self, src: Resource, dst: Resource, via: str, props: dict = None):
        # Links são diretos no grafo pois não gerimos histórico de arestas no SQL (ainda)
        await self.graph.create_edge(src.rid, dst.rid, via, props or {})

    async def unlink(self, src: Resource, dst: Resource, via: str):
        await self.graph.delete_edge(src.rid, dst.rid, via)

    # --- Fast Path (Analytics) ---

    async def ingest_batch(self, table_name: str, data: List[BaseModel]):
        if not data: return
        async with tracer.span("ingest_batch"):
            # CPU-bound: Politipo faz a mágica do Arrow
            transporter = PolyTransporter(type(data[0]))
            arrow_table = await asyncio.to_thread(transporter.to_arrow, data)
            
            # I/O: DuckDB ingere memória bruta
            await self.analytics.ingest_arrow(table_name, arrow_table)
            await post_ingest.emit(table_name)

    # --- Simulation (What-If) ---

    async def fork(self, new_db_url: str, new_kuzu_path: str) -> "UnifiedDataManager":
        """Cria clone do Kernel com estado físico copiado e governança preservada."""
        logger.info(f"🧪 Forking Kernel to {new_db_url}")
        
        # 1. Snapshot SQL
        if "sqlite" in str(self.sql.get_engine().url) and "sqlite" in new_db_url:
            src = str(self.sql.get_engine().url).replace("sqlite+aiosqlite:///", "")
            dst = new_db_url.replace("sqlite+aiosqlite:///", "")
            # Checkpoint WAL antes de copiar
            if os.path.exists(src):
                await asyncio.to_thread(shutil.copy2, src, dst)
        
        # 2. Snapshot Grafo
        if hasattr(self.graph, "path"):
            src_path = self.graph.path
            if os.path.exists(new_kuzu_path): shutil.rmtree(new_kuzu_path)
            # Copytree é seguro se não houver escritas ativas (garantido pelo lock do Kuzu se fechado,
            # mas em execução concorrente é arriscado. Ideal é backup feature do Kuzu)
            await asyncio.to_thread(shutil.copytree, src_path, new_kuzu_path)

        # 3. Instancia Novo Kernel
        new_sql = AsyncSQLAlchemyDriver(new_db_url)
        new_graph = KuzuDriver(new_kuzu_path)
        new_analytics = DuckDBDriver(new_db_url.replace("sqlite+aiosqlite:///", ""))
        
        manager = UnifiedDataManager(new_sql, new_graph, new_analytics)
        
        # 4. CRÍTICO: Copia a Constituição (Interceptors)
        # Sem isso, a simulação roda sem regras de negócio.
        manager._interceptors = list(self._interceptors)
        
        return manager


# =============================================================================
# 6. FACTORY
# =============================================================================

_ctx: ContextVar[Optional[UnifiedDataManager]] = ContextVar("ontologia_ctx", default=None)

async def connect(
    url: str = "sqlite+aiosqlite:///ontologia.db", 
    kuzu_path: str = "data/kuzu",
    reset: bool = False,
    sql_driver: Optional[SQLDriver] = None,
    graph_driver: Optional[GraphDriver] = None,
    analytics_driver: Optional[AnalyticsDriver] = None
) -> UnifiedDataManager:
    
    if reset:
        if os.path.exists(kuzu_path): shutil.rmtree(kuzu_path)
        local_db = url.split("///")[-1]
        if os.path.exists(local_db): os.remove(local_db)

    # Convention over Configuration
    sql = sql_driver or AsyncSQLAlchemyDriver(url)
    graph = graph_driver or KuzuDriver(kuzu_path)
    
    sqlite_path = None
    if "sqlite" in url and ":memory:" not in url:
        sqlite_path = url.split("///")[-1]
    analytics = analytics_driver or DuckDBDriver(sqlite_path)
    
    manager = UnifiedDataManager(sql, graph, analytics)
    await manager.boot()
    
    _ctx.set(manager)
    return manager

def get_kernel() -> UnifiedDataManager:
    m = _ctx.get()
    if not m: raise RuntimeError("Kernel not connected.")
    return m