"""
Configuration management for DcisionAI MCP Server
"""

import os
from typing import Optional


class MCPConfig:
    """Configuration for MCP Server"""
    
    # FastAPI Backend Configuration
    # Default to production Railway backend, allow override via env var for local dev
    API_URL: str = os.getenv("DCISIONAI_API_URL", "https://dcisionai-mcp-platform-production.up.railway.app")
    API_KEY: Optional[str] = os.getenv("DCISIONAI_API_KEY", None)
    
    # Timeout Configuration
    REQUEST_TIMEOUT: int = int(os.getenv("DCISIONAI_REQUEST_TIMEOUT", "300"))  # 5 minutes
    
    # Async Configuration
    ASYNC_ENABLED: bool = os.getenv("DCISIONAI_ASYNC_ENABLED", "true").lower() == "true"
    
    # Logging
    LOG_LEVEL: str = os.getenv("DCISIONAI_LOG_LEVEL", "INFO")
    
    # Domain Filtering
    # Options: "all" (default), "ria", "pe", "hf", "manufacturing", "logistics", etc.
    DOMAIN_FILTER: str = os.getenv("DCISIONAI_DOMAIN_FILTER", "all").lower()
    
    @classmethod
    def get_api_url(cls) -> str:
        """Get FastAPI backend URL"""
        return cls.API_URL
    
    @classmethod
    def get_api_key(cls) -> Optional[str]:
        """Get API key for authentication"""
        return cls.API_KEY
    
    @classmethod
    def get_timeout(cls) -> int:
        """Get request timeout in seconds"""
        return cls.REQUEST_TIMEOUT
    
    @classmethod
    def is_async_enabled(cls) -> bool:
        """Check if async optimization is enabled"""
        return cls.ASYNC_ENABLED
    
    @classmethod
    def get_domain_filter(cls) -> str:
        """Get domain filter setting"""
        return cls.DOMAIN_FILTER
    
    @classmethod
    def should_filter_by_domain(cls) -> bool:
        """Check if domain filtering is enabled (not 'all')"""
        return cls.DOMAIN_FILTER != "all"

