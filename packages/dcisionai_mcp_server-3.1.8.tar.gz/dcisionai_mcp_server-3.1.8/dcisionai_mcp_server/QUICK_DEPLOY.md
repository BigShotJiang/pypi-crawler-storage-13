# Quick Deploy to FastMCP Cloud

## 🚀 Fast Deployment Steps

### 1. Push to GitHub
```bash
git add dcisionai_mcp_server/
git commit -m "Add FastMCP server for FastMCP Cloud deployment"
git push origin main
```

### 2. Deploy to FastMCP Cloud

1. **Sign In**: Go to [https://fastmcp.cloud/](https://fastmcp.cloud/)
2. **Create Project**: Click "New Project" or "Create Server"
3. **Link Repository**: Select `dcisionai-mcp-platform` repository
4. **Configure**:
   - **Name**: `dcisionai-optimization`
   - **Entrypoint**: `dcisionai_mcp_server.fastmcp_server:mcp`
   - **Description**: "DcisionAI MCP Server - AI-Powered Optimization"
5. **Environment Variables**:
   ```
   DCISIONAI_API_URL=https://dcisionai-mcp-platform-production.up.railway.app
   DCISIONAI_REQUEST_TIMEOUT=300
   DCISIONAI_ASYNC_ENABLED=true
   ```
6. **Deploy**: Click "Deploy" or "Save"

### 3. Verify Deployment

Your server will be available at:
```
https://dcisionai-optimization.fastmcp.app/mcp
```

**Test it:**
```bash
curl https://dcisionai-optimization.fastmcp.app/mcp \
  -H "Content-Type: application/json" \
  -d '{"method": "tools/list"}'
```

## ✅ What Gets Deployed

- ✅ FastMCP server (`fastmcp_server.py`)
- ✅ 5 optimization tools
- ✅ 2 resources (models, solvers)
- ✅ FastAPI backend client
- ✅ Configuration management

## 📚 Full Guide

See [FASTMCP_DEPLOYMENT.md](FASTMCP_DEPLOYMENT.md) for detailed instructions.

