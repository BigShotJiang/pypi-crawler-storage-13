# DcisionAI MCP Server Setup

## Quick Start

### 1. Install Dependencies

```bash
pip install -r dcisionai_mcp_server/requirements.txt
```

Or install individually:
```bash
pip install mcp aiohttp pydantic
```

### 2. Configure Environment

Set environment variables:
```bash
export DCISIONAI_API_URL="http://localhost:8000"  # FastAPI backend URL
export DCISIONAI_API_KEY="your-api-key"            # Optional
export DCISIONAI_REQUEST_TIMEOUT="300"             # 5 minutes
```

### 3. Run MCP Server

```bash
python -m dcisionai_mcp_server.mcp_server
```

Or using the mcp.json config:
```bash
# The mcp.json file already references this module
# MCP clients will automatically use it
```

## Architecture

```
MCP Clients
    ↓ MCP Protocol
MCP Server (dcisionai_mcp_server/)
    ↓ HTTP Calls
FastAPI Backend (api/fastapi_app.py)
    ↓
dcisionai_graph (Unchanged)
```

**Key Point**: MCP Server is isolated from `dcisionai_graph` - no changes to working code!

## Tools Available

1. **dcisionai_solve** - Full optimization workflow
2. **dcisionai_classify_problem** - Problem classification
3. **dcisionai_extract_intent** - Intent extraction
4. **dcisionai_solve_with_model** - Use deployed models
5. **dcisionai_explain_solution** - Business explanation

## Resources Available

1. **dcisionai://models/list** - Deployed models
2. **dcisionai://solvers/list** - Available solvers

## Testing

```bash
# Test with MCP Inspector or CLI client
# TODO: Add test scripts
```

## Next Steps

1. ✅ Structure created
2. ⏳ Implement async optimization support
3. ⏳ Add error handling improvements
4. ⏳ Add logging
5. ⏳ Add tests
6. ⏳ Add prompts

## References

- [MCP Server Planning](../docs/MCP_SERVER_PLANNING.md)
- [ADR-029](../docs/adr/029-mcp-server-integration-architecture.md)

