# DcisionAI MCP Server

Model Context Protocol (MCP) server for exposing DcisionAI optimization capabilities to enterprise platforms.

## Architecture

```
MCP Clients (Salesforce, PowerBI, Excel, etc.)
    ↓ MCP Protocol (SSE/HTTP)
MCP Server (This Package)
    ↓ HTTP Calls
FastAPI Backend (api/fastapi_app.py)
    ↓
dcisionai_graph (Core Platform - Unchanged)
```

**Key Principle**: MCP server is a thin protocol adapter. It does NOT modify `dcisionai_graph`.

## Directory Structure

```
dcisionai_mcp_server/
├── __init__.py              # Package initialization
├── mcp_server.py            # Main MCP server
├── config.py                # Configuration management
├── client.py                # FastAPI backend client wrapper
├── tools/                   # MCP Tools (functions)
│   ├── __init__.py
│   ├── optimization.py      # Core optimization tools
│   ├── intent.py            # Intent discovery tools
│   └── utils.py             # Utility tools
├── resources/               # MCP Resources (read-only data)
│   ├── __init__.py
│   ├── models.py            # Model resources
│   └── solvers.py           # Solver resources
└── prompts/                 # MCP Prompts (templates)
    ├── __init__.py
    └── optimization.py      # Optimization prompts
```

## Installation

```bash
pip install mcp aiohttp pydantic
```

## Usage

```bash
# Run MCP server
python -m dcisionai_mcp_server.mcp_server
```

## Configuration

Set environment variables:
- `DCISIONAI_API_URL`: FastAPI backend URL (default: http://localhost:8000)
- `DCISIONAI_API_KEY`: API key for authentication (optional)
- `DCISIONAI_DOMAIN_FILTER`: Domain filter (default: "all")
  - `"all"` - Show all models (generic deployment)
  - `"ria"` - RIA Edition (only RIA models)
  - `"pe"` - Private Equity Edition
  - `"hf"` - Hedge Fund Edition
  - `"manufacturing"` - Manufacturing Edition
  - `"logistics"` - Logistics Edition

See [DOMAIN_FILTERING.md](DOMAIN_FILTERING.md) for details.

## Tools

### User-Facing Tools (2)
- `dcisionai_solve` ⭐ - Full optimization workflow (includes classification, intent extraction, solving, and explanation)
- `dcisionai_solve_with_model` - Solve using deployed models (faster for known problem types)

**Note**: Classification, intent extraction, and explanation are internal implementation details that are automatically included in `dcisionai_solve` results. See [TOOLS_RATIONALE.md](TOOLS_RATIONALE.md) for details.

### Resources
- `dcisionai://models/list` - Available deployed models
- `dcisionai://solvers/list` - Available solvers

## References

- [MCP Server Planning](../docs/MCP_SERVER_PLANNING.md)
- [ADR-029](../docs/adr/029-mcp-server-integration-architecture.md)

