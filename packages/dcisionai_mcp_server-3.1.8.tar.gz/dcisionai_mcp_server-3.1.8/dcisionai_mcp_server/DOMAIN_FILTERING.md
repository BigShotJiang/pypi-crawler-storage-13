# Domain Filtering Configuration

## Overview

The DcisionAI MCP Server supports **domain filtering** to focus on specific verticals (RIA, PE, HF, Manufacturing, Logistics) while maintaining a single codebase and deployment.

## Configuration

Set the `DCISIONAI_DOMAIN_FILTER` environment variable:

```bash
# Show all models (default)
export DCISIONAI_DOMAIN_FILTER="all"

# RIA-specific deployment
export DCISIONAI_DOMAIN_FILTER="ria"

# Private Equity deployment
export DCISIONAI_DOMAIN_FILTER="pe"

# Hedge Fund deployment
export DCISIONAI_DOMAIN_FILTER="hf"

# Manufacturing deployment
export DCISIONAI_DOMAIN_FILTER="manufacturing"

# Logistics deployment
export DCISIONAI_DOMAIN_FILTER="logistics"
```

## How It Works

### 1. **Server Name**
The server name automatically reflects the domain filter:
- `DCISIONAI_DOMAIN_FILTER="all"` → "DcisionAI Optimization Server"
- `DCISIONAI_DOMAIN_FILTER="ria"` → "DcisionAI Optimization Server - RIA Edition"
- `DCISIONAI_DOMAIN_FILTER="pe"` → "DcisionAI Optimization Server - PE Edition"

### 2. **Model Filtering**
The `/api/models` endpoint automatically filters models by domain:

**All Models** (`DCISIONAI_DOMAIN_FILTER="all"`):
```json
{
  "models": [
    {"id": "portfolio_optimization_v1", "domain": "private_equity", ...},
    {"id": "portfolio_rebalancing_v1", "domain": "ria", ...},
    {"id": "capital_deployment_v1", "domain": "private_equity", ...},
    {"id": "fund_structure_v1", "domain": "private_equity", ...}
  ]
}
```

**RIA Models Only** (`DCISIONAI_DOMAIN_FILTER="ria"`):
```json
{
  "models": [
    {"id": "portfolio_rebalancing_v1", "domain": "ria", ...}
  ],
  "filtered_by_domain": "ria",
  "total_models": 4,
  "filtered_count": 1
}
```

### 3. **Tools**
Tools (`dcisionai_solve`, `dcisionai_solve_with_model`) work the same regardless of domain filter. Domain filtering only affects **which models are visible** in resources.

## Deployment Examples

### FastMCP Cloud: RIA Edition

**Configuration**:
```yaml
# FastMCP Cloud project settings
name: dcisionai-ria-mcp-server
entrypoint: dcisionai_mcp_server.fastmcp_server:mcp

# Environment Variables
DCISIONAI_DOMAIN_FILTER: "ria"
DCISIONAI_API_URL: "https://dcisionai-mcp-platform-production.up.railway.app"
```

**Result**:
- Server name: "DcisionAI Optimization Server - RIA Edition"
- Only RIA models visible in resources
- Same tools, filtered models

### FastMCP Cloud: Generic Edition

**Configuration**:
```yaml
# FastMCP Cloud project settings
name: dcisionai-mcp-server
entrypoint: dcisionai_mcp_server.fastmcp_server:mcp

# Environment Variables
DCISIONAI_DOMAIN_FILTER: "all"
DCISIONAI_API_URL: "https://dcisionai-mcp-platform-production.up.railway.app"
```

**Result**:
- Server name: "DcisionAI Optimization Server"
- All models visible in resources
- Same tools, all models

## Benefits

### ✅ Single Codebase
- One MCP server codebase
- No code duplication
- One place to fix bugs

### ✅ Flexible Deployment
- Deploy RIA-specific instance: `DCISIONAI_DOMAIN_FILTER="ria"`
- Deploy generic instance: `DCISIONAI_DOMAIN_FILTER="all"`
- Same code, different configuration

### ✅ Easy Expansion
- Add new domain: Just set `DCISIONAI_DOMAIN_FILTER="new_domain"`
- No code changes needed
- Models automatically filtered

### ✅ Marketing Flexibility
- Market as "RIA Edition" (branding)
- Keep generic architecture (technical)
- Best of both worlds

## Domain Values

Supported domain values (must match model `domain` field):

| Domain | Description | Example Models |
|--------|-------------|----------------|
| `ria` | Registered Investment Advisor | `portfolio_rebalancing_v1` |
| `private_equity` or `pe` | Private Equity | `portfolio_optimization_v1`, `capital_deployment_v1`, `fund_structure_v1` |
| `hedge_fund` or `hf` | Hedge Funds | (future models) |
| `manufacturing` | Manufacturing | (future models) |
| `logistics` | Logistics | (future models) |
| `all` | All domains (default) | All models |

## Implementation Details

### Configuration (`config.py`)
```python
DOMAIN_FILTER: str = os.getenv("DCISIONAI_DOMAIN_FILTER", "all").lower()
```

### Model Filtering (`resources/models.py`)
```python
if domain_filter != "all":
    filtered_models = [
        model for model in models_list
        if model.get("domain", "").lower() == domain_filter.lower()
    ]
```

### Server Name (`fastmcp_server.py`, `mcp_server.py`)
```python
if _domain_filter != "all":
    server_name = f"DcisionAI Optimization Server - {_domain_filter.upper()} Edition"
else:
    server_name = "DcisionAI Optimization Server"
```

## Testing

### Test Domain Filtering Locally

```bash
# Test RIA filter
export DCISIONAI_DOMAIN_FILTER="ria"
python -m dcisionai_mcp_server.fastmcp_server

# Test generic (all models)
export DCISIONAI_DOMAIN_FILTER="all"
python -m dcisionai_mcp_server.fastmcp_server
```

### Verify Filtering

```python
# Check models resource
curl http://localhost:8000/api/models | jq '.models[] | select(.domain == "ria")'
```

## Migration Path

### Current State
- Generic MCP server
- All models visible

### With Domain Filtering
- Same MCP server codebase
- Domain-specific deployments via configuration
- RIA Edition: `DCISIONAI_DOMAIN_FILTER="ria"`
- Generic Edition: `DCISIONAI_DOMAIN_FILTER="all"`

### Future Expansion
- Add new domain: Update `DCISIONAI_DOMAIN_FILTER`
- No code changes needed
- Models automatically filtered

## References

- [Rebranding Analysis](REBRANDING_ANALYSIS.md) - Why domain filtering > separate servers
- [Configuration](config.py) - Domain filter implementation
- [Model Resources](resources/models.py) - Filtering logic

