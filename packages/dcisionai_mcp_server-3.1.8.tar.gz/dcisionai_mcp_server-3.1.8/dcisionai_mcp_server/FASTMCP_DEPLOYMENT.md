# FastMCP Cloud Deployment Guide

## Overview

This guide explains how to deploy the DcisionAI MCP Server to [FastMCP Cloud](https://fastmcp.cloud/).

FastMCP Cloud is a managed platform for hosting MCP servers with:
- Zero-configuration deployment
- Serverless scaling
- Built-in OAuth security
- Git-native CI/CD workflows

## Prerequisites

1. **GitHub Repository**: Your code must be in a GitHub repository
2. **FastMCP Cloud Account**: Sign up at [FastMCP Cloud](https://fastmcp.cloud/)
3. **Python Dependencies**: Ensure `fastmcp>=2.13.0` is in requirements

## Deployment Steps

### Step 1: Prepare Your Repository

Ensure your repository has:

1. **FastMCP Server File**: `dcisionai_mcp_server/fastmcp_server.py`
2. **Dependencies**: `requirements.txt` or `pyproject.toml` with `fastmcp>=2.13.0`
3. **Configuration**: Environment variables documented

### Step 2: Sign In to FastMCP Cloud

1. Visit [FastMCP Cloud](https://fastmcp.cloud/)
2. Click "Sign in" → "Continue with GitHub"
3. Authorize FastMCP Cloud to access your GitHub account

### Step 3: Create New Project

1. Click "New Project" or "Create Server"
2. Select your GitHub repository (`dcisionai-mcp-platform`)
3. Configure the project:

   **Project Settings:**
   - **Name**: `dcisionai-optimization` (or your preferred name)
   - **Entrypoint**: `dcisionai_mcp_server.fastmcp_server:mcp`
   - **Description**: "DcisionAI MCP Server - AI-Powered Optimization with Intent Classification"
   
   **Environment Variables:**
   ```
   DCISIONAI_API_URL=https://dcisionai-mcp-platform-production.up.railway.app
   DCISIONAI_API_KEY=your-api-key-if-needed
   DCISIONAI_REQUEST_TIMEOUT=300
   DCISIONAI_ASYNC_ENABLED=true
   DCISIONAI_LOG_LEVEL=INFO
   DCISIONAI_DOMAIN_FILTER=all  # Options: "all", "ria", "pe", "hf", "manufacturing", "logistics"
   ```
   
   **Domain Filtering**:
   - `DCISIONAI_DOMAIN_FILTER="all"` - Show all models (default, generic deployment)
   - `DCISIONAI_DOMAIN_FILTER="ria"` - RIA Edition (only RIA models visible)
   - `DCISIONAI_DOMAIN_FILTER="pe"` - Private Equity Edition
   - See [DOMAIN_FILTERING.md](DOMAIN_FILTERING.md) for details

### Step 4: Deploy

1. Click "Deploy" or "Save"
2. FastMCP Cloud will:
   - Clone your repository
   - Install dependencies (`fastmcp`, `aiohttp`, `pydantic`)
   - Build your FastMCP server
   - Deploy to a unique URL
   - Make it immediately available

### Step 5: Verify Deployment

Your server will be available at:
```
https://dcisionai-optimization.fastmcp.app/mcp
```

Or your custom URL if configured.

**Test the deployment:**
```bash
curl https://dcisionai-optimization.fastmcp.app/mcp \
  -H "Content-Type: application/json" \
  -d '{"method": "tools/list"}'
```

## Project Structure for FastMCP

```
dcisionai_mcp_server/
├── fastmcp_server.py      # FastMCP server (entrypoint)
├── client.py              # FastAPI backend client
├── config.py              # Configuration
├── tools/                 # Tool implementations
└── resources/             # Resource implementations
```

## FastMCP vs Standard MCP

**FastMCP Server** (`fastmcp_server.py`):
- Uses `@mcp.tool()` decorators
- Uses `@mcp.resource()` decorators
- Entry point: `mcp.run()`
- Compatible with FastMCP Cloud

**Standard MCP Server** (`mcp_server.py`):
- Uses `@server.list_tools()` decorators
- Uses `@server.call_tool()` handlers
- Entry point: `asyncio.run(main())`
- Compatible with local MCP clients

**Both are available** - use FastMCP for cloud deployment, standard MCP for local development.

## Environment Variables

Set these in FastMCP Cloud dashboard:

| Variable | Description | Default |
|----------|-------------|---------|
| `DCISIONAI_API_URL` | FastAPI backend URL | `http://localhost:8000` |
| `DCISIONAI_API_KEY` | API key (optional) | `None` |
| `DCISIONAI_REQUEST_TIMEOUT` | Request timeout (seconds) | `300` |
| `DCISIONAI_ASYNC_ENABLED` | Enable async optimization | `true` |
| `DCISIONAI_LOG_LEVEL` | Logging level | `INFO` |

## Updating Deployment

FastMCP Cloud supports Git-native CI/CD:

1. **Push to GitHub**: Changes automatically trigger rebuild
2. **Manual Deploy**: Use "Redeploy" button in dashboard
3. **Rollback**: Use "Rollback" to previous version

## Monitoring

FastMCP Cloud provides:
- Request logs
- Error tracking
- Performance metrics
- Usage analytics

Access via FastMCP Cloud dashboard.

## Troubleshooting

### Server Not Starting

1. Check entrypoint path: `dcisionai_mcp_server.fastmcp_server:mcp`
2. Verify `fastmcp>=2.13.0` in requirements
3. Check environment variables

### Tools Not Appearing

1. Verify `@mcp.tool()` decorators are correct
2. Check FastMCP server logs
3. Ensure `mcp.run()` is called

### Backend Connection Issues

1. Verify `DCISIONAI_API_URL` is correct
2. Check backend is accessible from FastMCP Cloud
3. Verify API key if required

## References

- [FastMCP Cloud](https://fastmcp.cloud/)
- [FastMCP Documentation](https://fastmcp.wiki/)
- [FastMCP Cloud Deployment Guide](https://fastmcp.wiki/en/deployment/fastmcp-cloud)
- [DcisionAI MCP Server Planning](../docs/MCP_SERVER_PLANNING.md)

