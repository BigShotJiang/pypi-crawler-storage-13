"""
Core Optimization Tools for MCP Server

These tools expose DcisionAI's optimization capabilities via MCP protocol.
"""

import json
from typing import Dict, Any
from mcp.types import Tool, TextContent
from ..client import DcisionAIClient


# Initialize client
_client = DcisionAIClient()


def get_tools() -> list[Tool]:
    """
    Get list of all optimization tools.
    
    Note: Only user-facing tools are exposed. Internal implementation details
    (classification, intent extraction, explanation) are part of dcisionai_solve workflow.
    See TOOLS_RATIONALE.md for details.
    """
    return [
        Tool(
            name="dcisionai_solve",
            description="Solve an optimization problem using DcisionAI. Provides full optimization workflow including problem classification, intent extraction, model generation, solving, and business explanation. All internal steps are included automatically.",
            inputSchema={
                "type": "object",
                "properties": {
                    "problem_description": {
                        "type": "string",
                        "description": "Natural language description of the optimization problem"
                    }
                },
                "required": ["problem_description"]
            }
        ),
        Tool(
            name="dcisionai_solve_with_model",
            description="Solve an optimization problem using a deployed DcisionAI model. Faster than full solve for known problem types.",
            inputSchema={
                "type": "object",
                "properties": {
                    "model_id": {
                        "type": "string",
                        "description": "ID of the deployed model to use"
                    },
                    "data": {
                        "type": "object",
                        "description": "Model-specific input data"
                    }
                },
                "required": ["model_id", "data"]
            }
        ),
    ]


async def dcisionai_solve(problem_description: str) -> list[TextContent]:
    """
    Solve an optimization problem
    
    Args:
        problem_description: Natural language problem description
        
    Returns:
        Optimization results
    """
    try:
        result = await _client.optimize(problem_description)
        return [
            TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )
        ]
    except Exception as e:
        return [
            TextContent(
                type="text",
                text=f"Error: {str(e)}"
            )
        ]


async def dcisionai_solve_with_model(model_id: str, data: Dict[str, Any]) -> list[TextContent]:
    """
    Solve with deployed model
    
    Args:
        model_id: Deployed model ID
        data: Model-specific input data
        
    Returns:
        Optimization results
    """
    try:
        result = await _client.optimize_with_model(model_id, data)
        return [
            TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )
        ]
    except Exception as e:
        return [
            TextContent(
                type="text",
                text=f"Error: {str(e)}"
            )
        ]


# Note: dcisionai_classify_problem, dcisionai_extract_intent, and dcisionai_explain_solution
# have been removed as they are internal implementation details.
# Classification, intent extraction, and explanation are all included in dcisionai_solve results.
# See TOOLS_RATIONALE.md for details.

