# Railway MCP Server - Quick Fix

## Issue

Railway is reading `railway.toml` which points to `./Dockerfile` (backend Dockerfile).
For MCP server, we need `./Dockerfile.mcp`.

## Solution: Override in Railway UI

### Step 1: Go to Build Tab

1. Railway Dashboard → Your MCP Service
2. Click **"Build"** tab

### Step 2: Change Dockerfile Path

1. Find **"Dockerfile"** section
2. Click the dropdown/input field
3. Change from: `./Dockerfile`
4. Change to: `./Dockerfile.mcp`
5. Save

### Step 3: Deploy

Railway will rebuild using `Dockerfile.mcp` (with uv, optimized for MCP server).

---

## Alternative: Service-Specific Config

If Railway supports per-service config files, you can:

1. Create `railway.mcp.toml` in repo root
2. Railway might auto-detect it for MCP service
3. Or specify it in Railway UI

**railway.mcp.toml:**
```toml
[build]
builder = "dockerfile"
dockerfilePath = "./Dockerfile.mcp"

[deploy]
startCommand = "python dcisionai_mcp_server/start_mcp_server.py"
healthcheckPath = "/health"
healthcheckTimeout = 100
restartPolicyType = "on_failure"
```

---

## Quick Check

After changing Dockerfile path:
- ✅ Build should use `Dockerfile.mcp`
- ✅ Faster builds (uv instead of pip)
- ✅ Lighter image (no conda/SCIP)
- ✅ MCP server optimized

---

## Current Configuration Summary

- ✅ Source: `prod` branch
- ✅ Start Command: `python dcisionai_mcp_server/start_mcp_server.py`
- ⚠️ Dockerfile: Change to `./Dockerfile.mcp` in Build tab
- ✅ Port: 8080
- ✅ Ready to deploy!

