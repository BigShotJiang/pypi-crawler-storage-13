"""
Solver Resources - Expose available solvers as MCP resources
"""

import json
from mcp.types import Resource


def get_solver_resources() -> list[Resource]:
    """Get list of solver resources"""
    return [
        Resource(
            uri="dcisionai://solvers/list",
            name="Available Solvers",
            description="List of all available optimization solvers",
            mimeType="application/json"
        )
    ]


async def read_solver_resource(uri: str) -> str:
    """
    Read solver resource
    
    Args:
        uri: Resource URI (e.g., dcisionai://solvers/list)
        
    Returns:
        Resource content as JSON string
    """
    if uri == "dcisionai://solvers/list":
        # Static list of available solvers
        solvers = {
            "mathematical": [
                {"name": "HiGHS", "type": "LP/MIP", "description": "High-performance LP/MIP solver"},
                {"name": "SCIP", "type": "MIP", "description": "Solving Constraint Integer Programs"},
                {"name": "OR-Tools", "type": "CP-SAT", "description": "Google OR-Tools constraint programming"}
            ],
            "heuristic": [
                {"name": "DAME", "type": "Evolutionary", "description": "DcisionAI Multi-Objective Adaptive Engine"}
            ]
        }
        return json.dumps(solvers, indent=2)
    else:
        return json.dumps({"error": f"Unknown resource URI: {uri}"})

