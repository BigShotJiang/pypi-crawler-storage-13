"""
Model Resources - Expose deployed models as MCP resources
"""

import json
from mcp.types import Resource
from ..client import DcisionAIClient
from ..config import MCPConfig


_client = DcisionAIClient()


def get_model_resources() -> list[Resource]:
    """Get list of model resources"""
    return [
        Resource(
            uri="dcisionai://models/list",
            name="Deployed Models",
            description="List of all deployed DcisionAI models",
            mimeType="application/json"
        )
    ]


async def read_model_resource(uri: str) -> str:
    """
    Read model resource
    
    Args:
        uri: Resource URI (e.g., dcisionai://models/list)
        
    Returns:
        Resource content as JSON string (filtered by domain if configured)
    """
    if uri == "dcisionai://models/list":
        try:
            models_response = await _client.get_models()
            
            # Apply domain filtering if configured
            domain_filter = MCPConfig.get_domain_filter()
            if domain_filter != "all":
                models_list = models_response.get("models", [])
                filtered_models = [
                    model for model in models_list
                    if model.get("domain", "").lower() == domain_filter.lower()
                ]
                models_response = {
                    "models": filtered_models,
                    "filtered_by_domain": domain_filter,
                    "total_models": len(models_list),
                    "filtered_count": len(filtered_models)
                }
            
            return json.dumps(models_response, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})
    else:
        return json.dumps({"error": f"Unknown resource URI: {uri}"})

