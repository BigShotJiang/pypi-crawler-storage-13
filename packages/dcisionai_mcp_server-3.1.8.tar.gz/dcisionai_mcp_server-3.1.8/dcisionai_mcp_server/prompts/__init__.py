"""
MCP Prompts - Template-based interactions
"""

# Prompts will be implemented here
__all__ = []

