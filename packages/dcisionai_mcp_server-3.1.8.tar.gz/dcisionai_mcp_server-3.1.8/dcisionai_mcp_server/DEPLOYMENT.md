# DcisionAI MCP Server Deployment Guide

## Deployment Options

### Option 1: FastMCP Cloud (Recommended)

**Best for**: Production deployment, managed hosting, easy scaling

See [FASTMCP_DEPLOYMENT.md](FASTMCP_DEPLOYMENT.md) for detailed instructions.

**Quick Steps:**
1. Sign in to [FastMCP Cloud](https://fastmcp.cloud/)
2. Create new project → Link GitHub repo
3. Set entrypoint: `dcisionai_mcp_server.fastmcp_server:mcp`
4. Configure environment variables
5. Deploy!

**Benefits:**
- ✅ Zero-configuration deployment
- ✅ Serverless scaling
- ✅ Built-in OAuth security
- ✅ Git-native CI/CD
- ✅ Managed infrastructure

### Option 2: Local Development

**Best for**: Development, testing, local MCP clients

```bash
# Install dependencies
pip install -r dcisionai_mcp_server/requirements.txt

# Run standard MCP server
python -m dcisionai_mcp_server.mcp_server
```

### Option 3: Self-Hosted

**Best for**: Custom infrastructure, on-premises deployment

Deploy `fastmcp_server.py` to your infrastructure:
- Docker container
- Kubernetes
- Cloud Run / Lambda
- VPS / VM

## Which Server File to Use?

| Use Case | File | Framework |
|----------|------|-----------|
| **FastMCP Cloud** | `fastmcp_server.py` | FastMCP |
| **Local Development** | `mcp_server.py` | Standard MCP SDK |
| **Self-Hosted** | `fastmcp_server.py` | FastMCP |

## Environment Configuration

Both servers use the same configuration (`config.py`):

```bash
export DCISIONAI_API_URL="https://your-backend-url.com"
export DCISIONAI_API_KEY="optional-api-key"
export DCISIONAI_REQUEST_TIMEOUT="300"
export DCISIONAI_ASYNC_ENABLED="true"
export DCISIONAI_LOG_LEVEL="INFO"
```

## References

- [FastMCP Cloud Deployment](FASTMCP_DEPLOYMENT.md)
- [MCP Server Planning](../docs/MCP_SERVER_PLANNING.md)
- [ADR-029](../docs/adr/029-mcp-server-integration-architecture.md)

