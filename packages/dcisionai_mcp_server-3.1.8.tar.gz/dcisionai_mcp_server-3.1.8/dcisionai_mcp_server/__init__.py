"""
DcisionAI MCP Server

Model Context Protocol server for exposing DcisionAI optimization capabilities
to MCP clients (IDEs, Salesforce, PowerBI, Excel, etc.).

This server acts as a thin protocol adapter, calling the existing FastAPI backend.
"""

__version__ = "0.1.0"

