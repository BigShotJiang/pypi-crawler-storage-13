# 如何使用
pip install chenx-utils

# 可以用的包
### upload_file, delete_file 上传文件到eos
### upload_file as upload_file_sync 异步上传
### AsyncHttpClient 异步http请求
### RedisManager, redis_manager redis管理
### json_response, error_response, CODES 响应json
### generate_metadata  生成元数据
### zip_folder_files    压缩文件夹
### models 配置生成的通用方法