
from pydantic import BaseModel
from fastapi.responses import FileResponse, JSONResponse



from enum import Enum, unique
ERROR_CODE = 1
SUCCESS_CODE = 0

@unique
class CODES(Enum):
    """
    业务错误码与 HTTP 状态码的映射
    格式：(业务错误码, 默认消息, 推荐 HTTP 状态码)
    """
    
    # ==================================
    # 成功（HTTP 2xx）
    # ==================================
    # ==========================
    # Success
    # ==========================
    SUCCESS = (0, "请求成功", 200)

    # ==========================
    # 400 系列（客户端错误）
    # ==========================
    BAD_REQUEST = (4000, "请求无效", 400)
    INVALID_PARAM = (4001, "参数无效", 400)
    PARAM_MISSING = (4002, "缺少必填参数", 400)
    INVALID_PROMPT = (4003, "输入提示词无效", 400)
    FILE_FORMAT_ERROR = (4004, "文件格式错误", 400)

    METHOD_NOT_ALLOWED = (4050, "请求方式不支持", 405)
    RESOURCE_CONFLICT = (4090, "资源冲突（如名称已存在）", 409)
    TOO_MANY_REQUESTS = (4290, "请求过于频繁，请稍后再试", 429)

    # ==========================
    # 认证与权限（401 / 403）
    # ==========================
    UNAUTHORIZED = (4010, "未登录或 Token 失效", 401)
    FORBIDDEN = (4030, "权限不足", 403)

    # ==========================
    # 404 系列
    # ==========================
    RESOURCE_NOT_FOUND = (4040, "资源不存在", 404)
    TASK_NOT_FOUND = (4041, "任务 ID 不存在", 404)

    # ==========================
    # 500 系列（服务器错误）
    # ==========================
    INTERNAL_ERROR = (5000, "服务器内部错误", 500)
    FILE_IO_ERROR = (5001, "文件读写错误", 500)
    GENERATION_FAILED = (5002, "模型生成失败", 500)

    # ==========================
    # 502 系列（上游依赖错误）
    # ==========================
    BAD_GATEWAY = (5020, "上游服务错误", 502)
    HUGGINGFACE_ERROR = (5021, "Hugging Face 服务异常", 502)
    RAY_SERVE_ERROR = (5022, "Ray Serve 服务未响应", 502)
    THIRD_PARTY_ERROR = (5023, "第三方 API 调用失败", 502)

    # ==========================
    # 503 系列（系统繁忙）
    # ==========================
    RESOURCE_EXHAUSTED = (5030, "GPU 资源耗尽", 503)
    TASK_LIMITED = (5031, "任务数量达到上限", 503)
    SERVICE_UNAVAILABLE = (5032, "服务不可用，请稍后再试", 503)
    
    def __init__(self, code: int, message: str, http_status: int):
        self.code = code          # 业务错误码
        self.message = message    # 默认错误消息
        self.http_status = http_status  # 对应的 HTTP 状态码
    
    def __str__(self) -> str:
        return f"[{self.code}] {self.message} (HTTP {self.http_status})"
    
# 自定义异常
class CustomException(Exception):
    def __init__(
        self,
        code: CODES,  # 传入 CODES 枚举
        message: str = None,  # 可选：覆盖默认消息
        http_status: int = None  # 可选：覆盖推荐的 HTTP 状态码
    ):
        self.code = code.code
        self.message = message or code.message
        self.http_status = http_status or code.http_status  # 优先使用传入的 HTTP 状态码
        super().__init__(self.message)


def error_response(message = None, data = None, code: CODES = CODES.RAY_SERVE_ERROR,  status_code: int = None):
    message = code.message if message is None else message
    if isinstance(data, BaseModel):
        data = data.model_dump()
    return JSONResponse(
                {
                "code": status_code if status_code else code.code,
                "message": message,
                "data": data
            },
            code.http_status
    )

def json_response(message = None, data = None, code: CODES  = CODES.SUCCESS, status_code: int = None):
    message = code.message if message is None else message
    if isinstance(data, BaseModel):
        data = data.model_dump()
    return JSONResponse(
            {
                "code": status_code if status_code else code.code,
                "message": message,
                "data": data
            },
            code.http_status
    )
