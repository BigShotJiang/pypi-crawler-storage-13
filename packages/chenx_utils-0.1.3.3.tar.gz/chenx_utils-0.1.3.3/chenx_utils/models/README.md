# 动态配置使用指南

## 快速开始

### 方式一：使用 `process_request()`（最简单，推荐）

```python
from fastapi import Request
from models.base_model import process_request

@router.post("/submit")
async def submit(request: Request):
    # 1. 获取原始 JSON 数据
    input_data = await request.json()
    
    # 2. 使用动态配置验证和处理
    validated_data = process_request("hunyuan", input_data)
    
    # 3. 使用验证后的数据（字典格式）
    prompt = validated_data.get("prompt")
    seed = validated_data.get("seed")
    face_limit = validated_data.get("face_limit")
    
    # 继续处理...
    return {"success": True}
```

### 方式二：使用动态模型类（类型安全）

```python
from models.router_helper import get_dynamic_model

# 在模块级别获取模型类
HunyuanModel = get_dynamic_model("hunyuan")

@router.post("/submit")
async def submit(input: HunyuanModel):
    # input 已经是验证后的模型实例
    # 可以直接访问字段
    prompt = input.prompt
    seed = input.seed
    face_limit = input.face_limit
    
    # 转换为字典
    data = input.model_dump()
    
    return {"success": True}
```

## 核心函数说明

### 1. `process_request(model_name, input_data) -> dict`

**功能：**
- 自动加载模型配置
- 验证输入参数
- 处理透传逻辑（如果启用）
- 处理图片转换（如果启用）
- 返回验证后的字典

**参数：**
- `model_name`: 模型名称（如 "meshy", "hunyuan"）
- `input_data`: 原始输入数据字典

**返回：**
- 验证和处理后的数据字典

**示例：**
```python
validated_data = process_request("meshy", {
    "prompt": "一只猫",
    "art_style": "realistic",
    "seed": 12345
})
```

### 2. `get_dynamic_model(model_name) -> Type[BaseModel]`

**功能：**
- 加载模型配置
- 动态生成 Pydantic 模型类
- 返回可用于类型注解的模型类

**参数：**
- `model_name`: 模型名称

**返回：**
- Pydantic 模型类

**示例：**
```python
Model = get_dynamic_model("hunyuan")
instance = Model(prompt="一只猫", seed=12345)
```

### 3. `build_dynamic_model(config) -> Type[BaseModel]`

**功能：**
- 根据配置对象生成模型类
- 需要先加载配置

**示例：**
```python
from models.model_loader import load_model_config
from models.base_model import build_dynamic_model

config = load_model_config("hunyuan")
Model = build_dynamic_model(config)
```

## 访问参数的方式

### 方式一：字典方式（使用 `process_request`）

```python
validated_data = process_request("hunyuan", input_data)

# 访问字段
prompt = validated_data.get("prompt")
seed = validated_data.get("seed", -1)  # 带默认值
face_limit = validated_data.get("face_limit")
```

### 方式二：模型实例方式（使用 `get_dynamic_model`）

```python
Model = get_dynamic_model("hunyuan")
instance = Model(**input_data)

# 访问字段
prompt = instance.prompt
seed = instance.seed
face_limit = instance.face_limit

# 转换为字典
data = instance.model_dump()
```

## 实际迁移示例

### 原来的代码：
```python
from data.schemas import Generate3d_input_data

@router.post("/submit")
async def submit(input: Generate3d_input_data):
    data = input.model_dump()
    prompt = input.prompt
    # ...
```

### 迁移后（方式一）：
```python
from fastapi import Request
from models.base_model import process_request

@router.post("/submit")
async def submit(request: Request):
    input_data = await request.json()
    validated_data = process_request("hunyuan", input_data)
    
    prompt = validated_data.get("prompt")
    # ...
```

### 迁移后（方式二）：
```python
from models.router_helper import get_dynamic_model

HunyuanModel = get_dynamic_model("hunyuan")

@router.post("/submit")
async def submit(input: HunyuanModel):
    prompt = input.prompt
    data = input.model_dump()
    # ...
```

## 错误处理

```python
from models.base_model import process_request
from data.schemas import error_response
from data.response_data import CODES

@router.post("/submit")
async def submit(request: Request):
    try:
        input_data = await request.json()
        validated_data = process_request("hunyuan", input_data)
        # 处理逻辑...
    except ValueError as e:
        # 参数验证失败
        return error_response(code=CODES.INVALID_PARAM, message=str(e))
    except FileNotFoundError as e:
        # 配置文件不存在
        return error_response(code=CODES.SERVER_ERROR, message=f"模型配置不存在: {e}")
    except Exception as e:
        # 其他错误
        return error_response(code=CODES.SERVER_ERROR, message=str(e))
```

## 注意事项

1. **模型名称**：必须与配置文件名称一致（不含 `.yml` 后缀）
2. **透传模式**：如果配置中启用了透传，`process_request` 会直接返回原始数据
3. **图片处理**：如果配置中启用了图片处理，会自动转换 base64 和路径
4. **类型检查**：使用 `get_dynamic_model` 可以获得更好的类型提示

## 支持的模型

- `hunyuan` / `hunyuan_img`
- `meshy` / `meshy_img`
- `tripo` / `tripo_img`
- `rodin` / `rodin_img`
- `trellis` / `trellis_img`

## 更多示例

查看 `usage_examples.md` 获取更多详细示例。

