"""
从模型配置生成元数据
用于前端表单生成
"""
from typing import List, Dict, Any
from .model_loader import ModelConfig, ParameterConfig
from .model_loader import load_model_config, list_available_models, ModelID
from .base_model import build_dynamic_model
import logging 
logger = logging.getLogger(__name__)
def generate_metadata_from_config(model_config: ModelConfig) -> List[Dict[str, Any]]:
    """
    从模型配置生成元数据
    
    Args:
        model_config: 模型配置
    
    Returns:
        元数据列表，用于前端表单生成
    """
    metadata = []
    
    for param_name, param_config in model_config.parameters.items():
        # 跳过某些字段（这些字段在 general_schema 中处理）
        # 构建字段元数据
        # 优先使用 name 字段（中文名），如果没有则使用 json_schema_extra 中的 label，最后使用字段名
        label = param_name
        if param_config.name:
            label = param_config.name
        elif param_config.json_schema_extra and "label" in param_config.json_schema_extra:
            label = param_config.json_schema_extra["label"]
        
        field_metadata = {
            "key": param_name,
            "label": label,
            # "name": param_config.name,  # 中文显示名称
            "type": param_config.type,
            "default": param_config.default if param_config.default is not None else (0 if param_config.type == "number" else ""),
            "placeholder": param_config.description,
            "component": param_config.json_schema_extra.get("type", "input") if param_config.json_schema_extra else "input",
            "value": param_config.json_schema_extra.get("value", "") if param_config.json_schema_extra else "",
            "required": param_config.required,
        }
        
        # 添加约束条件
        if param_config.range:
            min_val, max_val = param_config.range
            if min_val is not None:
                field_metadata["min"] = min_val
            if max_val is not None:
                field_metadata["max"] = max_val
        
        if param_config.max_length:
            field_metadata["max_length"] = param_config.max_length
        
        # 添加选项（用于 select 类型）
        # 从 json_schema_extra.value 读取选项
        if param_config.type == "select":
            options = None
            if param_config.json_schema_extra and "value" in param_config.json_schema_extra:
                options = param_config.json_schema_extra["value"]
            elif param_config.options:
                options = param_config.options  # 向后兼容
            
            # if options:
            #     field_metadata["options"] = options
        
        # 添加显示标志
        if param_config.json_schema_extra:
            field_metadata["show"] = param_config.json_schema_extra.get("show", False)
            # 添加其他 json_schema_extra 中的信息
            if "value_cn" in param_config.json_schema_extra:
                field_metadata["value_cn"] = param_config.json_schema_extra["value_cn"]
            if "tips" in param_config.json_schema_extra or param_config.tips:
                field_metadata["tips"] = param_config.json_schema_extra.get("tips") or param_config.tips
        else:
            field_metadata["show"] = False
        
        metadata.append(field_metadata)
    
    return metadata

"""
   
"""
def get_schema(model_display_config: dict = None, General_config: str = None, model_type: ModelID = ModelID.img):
    """
    获取模型配置 schema
    参数:
    model_display_config: 模型显示配置, 名称，缩略图
    General_config: 模型通用配置，所有的模型都需要的字段
    model_type: 模型类型，0-5 分别对应：img，model，texture，sky，scene
    """
    # 模型显示配置（可以从配置文件读取，这里保持硬编码以兼容现有前端）
    
    
    # 获取所有可用的模型配置
    available_models = list_available_models()
    
    # 构建模型列表和 extra_schema
    models_list = []
    extra_schema = {}
    
    # 用于存储已处理的模型（避免重复）
    processed_models = set()
    
    # 首先处理 YAML 配置的模型
    for model_name in available_models:
        try:
            # 跳过 _img 后缀的模型（它们会在主模型中处理）
            if model_name.endswith("_img"):
                continue
            
            # 获取基础模型名（去掉 _img 后缀）
            base_name = model_name.replace("_img", "")
            
            if base_name in processed_models:
                continue
            
            # 加载配置
            try:
                config = load_model_config(model_name)
            except FileNotFoundError:
                # 如果主模型配置不存在，尝试加载 _img 版本
                img_model_name = f"{model_name}_img"
                if img_model_name in available_models:
                    config = load_model_config(img_model_name)
                else:
                    continue
            
            # 生成元数据
            metadata = generate_metadata_from_config(config)
            extra_schema[model_name] = metadata
            
            # 如果有 _img 版本，也生成其元数据
            img_model_name = f"{model_name}_img"
            if img_model_name in available_models:
                try:
                    img_config = load_model_config(img_model_name)
                    img_metadata = generate_metadata_from_config(img_config)
                    extra_schema[img_model_name] = img_metadata
                except Exception as e:
                    logger.warning(f"加载 {img_model_name} 配置失败: {e}")
                    extra_schema[img_model_name] = []
            
            # 添加到模型列表
            display_info = model_display_config.get(base_name, {"display": base_name, "multi_imgs": False})
            models_list.append({
                "name": base_name,
                "thumbnail": display_info.get("thumbnail", "https://112.48.155.24:37443/mos/api/test/client_api/v1/buckets/40268c6e3ff741c1a4af38778351bf2f/content/4af66a3b7508b4930a7595554b35af68_538694.png"),
                "display": display_info["display"],
                "multi_imgs": display_info["multi_imgs"]
            })
            
            processed_models.add(base_name)
            
        except Exception as e:
            import traceback
            logger.warning(f"处理模型 {model_name} 配置时出错: {traceback.format_exc()  }")
            # 如果配置加载失败，初始化空列表
            extra_schema[model_name] = []
            if f"{model_name}_img" in available_models:
                extra_schema[f"{model_name}_img"] = []
    
    # 向后兼容：如果某些模型没有配置，使用旧的硬编码方式
    # fallback_models = {
    #     'hunyuan': Generate3d_input_data,
    #     'hunyuan_img': Generate3d_img_data,
    #     'meshy': Meshy_t2m_input_data,
    #     'meshy_img': Meshy_t2m_input_data,
    #     'tripo': Tripo_text_to_model,
    #     'tripo_img': Tripo_text_to_model,
    #     "rodin": Rodin_to_model,
    #     "rodin_img": Rodin_to_model,
    #     "trellis": Generate3d_input_data,
    #     "trellis_img": Generate3d_input_data,   
    # }
    
    # for model_name, model_class in fallback_models.items():
    #     if model_name not in extra_schema:
    #         try:
    #             metadata = generate_metadata(model_class)
    #             extra_schema[model_name] = metadata
    #         except Exception as e:
    #             logger.warning(f"生成 {model_name} 元数据失败: {e}")
    #             extra_schema[model_name] = []
        
    #     # 确保模型在列表中（如果还没有）
    #     base_name = model_name.replace("_img", "")
    #     if base_name not in [m["name"] for m in models_list]:
    #         display_info = model_display_config.get(base_name, {"display": base_name, "multi_imgs": False})
    #         models_list.append({
    #             "name": base_name,
    #             "thumbnail": "https://112.48.155.24:37443/mos/api/test/client_api/v1/buckets/40268c6e3ff741c1a4af38778351bf2f/content/4af66a3b7508b4930a7595554b35af68_538694.png",
    #             "display": display_info["display"],
    #             "multi_imgs": display_info["multi_imgs"]
    #         })
    
    # # 生成通用 schema（使用 Generate3d_input_data）
    general_schema = generate_metadata_from_config(load_model_config(General_config))
    
    result = {
        "model_type": 1,
        "models": models_list,
        "general_schema": general_schema,
        "extra_schema": extra_schema
    }
    
    return result