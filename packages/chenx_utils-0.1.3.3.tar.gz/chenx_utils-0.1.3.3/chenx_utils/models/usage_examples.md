# 动态配置使用示例

## 方式一：在路由中直接使用动态模型（推荐）

### 示例 1：替换硬编码的模型类

**原来的代码：**
```python
from data.schemas import Generate3d_input_data

@Hy_router.post("/submit")
async def submit(input: Generate3d_input_data):
    data = input.model_dump()
    # 使用 data
```

**使用动态配置后：**
```python
from models.router_helper import get_dynamic_model
from fastapi import Request

@Hy_router.post("/submit")
async def submit(request: Request):
    # 获取原始 JSON 数据
    input_data = await request.json()
    
    # 使用动态配置验证和处理数据
    from models.base_model import process_request
    validated_data = process_request("hunyuan", input_data)
    
    # 使用 validated_data（已经验证和处理过）
    url = HUNYUAN_URL + "/hy_3d/submit"
    http_instance = await AsyncHttpClient.get_instance()
    res = await http_instance.post(
        url=url,
        data=validated_data,
        timeout=600
    )
    return res
```

### 示例 2：使用动态生成的模型类作为类型注解

```python
from models.router_helper import get_dynamic_model

# 在路由定义时获取模型类
MeshyInputModel = get_dynamic_model("meshy")

@Meshy_router.post("/text_to_3d")
async def text23d(input: MeshyInputModel):
    # input 已经是验证后的动态模型实例
    data = input.model_dump()
    
    # 访问具体字段
    prompt = input.prompt
    art_style = input.art_style
    seed = input.seed
    
    # 继续处理...
    res = await meshy.text_to_3d(input, request)
    return res
```

## 方式二：在服务层使用动态配置

### 示例：修改 meshy 服务

**原来的代码：**
```python
async def text_to_3d(data: Meshy_t2m_input_data, request: Request):
    # 直接使用 data
    prompt = data.prompt
    art_style = data.art_style
    ...
```

**使用动态配置后：**
```python
from models.base_model import process_request

async def text_to_3d(data: dict, request: Request):
    # 使用动态配置验证和处理
    validated_data = process_request("meshy", data)
    
    # 访问字段（作为字典）
    prompt = validated_data.get("prompt")
    art_style = validated_data.get("art_style")
    seed = validated_data.get("seed")
    
    # 或者如果需要模型实例
    from models.router_helper import get_dynamic_model
    Model = get_dynamic_model("meshy")
    model_instance = Model(**validated_data)
    
    # 继续处理...
```

## 方式三：完全动态的路由（高级用法）

```python
from models.router_helper import get_dynamic_model
from fastapi import Request

# 动态创建路由函数
def create_dynamic_route(model_name: str, endpoint: str):
    Model = get_dynamic_model(model_name)
    
    @router.post(f"/{endpoint}")
    async def dynamic_handler(input: Model):
        # 处理逻辑
        data = input.model_dump()
        # ...
        return data
    
    return dynamic_handler

# 使用
create_dynamic_route("meshy", "text_to_3d")
create_dynamic_route("hunyuan", "submit")
```

## 方式四：使用 Request 手动解析（最灵活）

```python
from fastapi import Request
from models.base_model import process_request

@router.post("/submit")
async def submit(request: Request):
    # 获取原始 JSON
    input_data = await request.json()
    
    # 根据请求参数或路径确定模型名称
    model_name = request.query_params.get("model", "hunyuan")
    
    # 验证和处理
    try:
        validated_data = process_request(model_name, input_data)
    except Exception as e:
        return error_response(message=f"参数验证失败: {e}")
    
    # 使用验证后的数据
    # ...
```

## 关键点总结

1. **`process_request(model_name, input_data)`** - 最常用的方式
   - 自动验证参数
   - 处理透传逻辑
   - 处理图片转换
   - 返回验证后的字典

2. **`get_dynamic_model(model_name)`** - 获取模型类
   - 返回 Pydantic 模型类
   - 可以用作类型注解
   - 适合需要强类型检查的场景

3. **字段访问方式**
   - 字典方式：`data.get("prompt")`
   - 模型实例：`model.prompt`（需要先创建实例）

## 实际迁移步骤

1. 将路由参数从硬编码模型改为 `Request`
2. 在函数内部使用 `process_request()` 验证数据
3. 使用返回的字典访问字段
4. 或者使用 `get_dynamic_model()` 创建模型实例

