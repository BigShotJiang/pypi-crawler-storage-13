"""
图片处理工具
处理 base64、路径转换等
"""
import base64
import os
from io import BytesIO
from typing import Any, List, Union
from PIL import Image

import logging
logger = logging.getLogger(__name__)


def handle_image(
    image_data: Union[str, List[str], dict],
    convert_base64: bool = False,
    convert_path: bool = False,
    clean_empty_img: bool = False
) -> Union[str, List[str], dict, Image.Image, List[Image.Image]]:
    """
    处理图片数据
    
    Args:
        image_data: 图片数据（可以是 base64 字符串、URL、路径、字典等）
        convert_base64: 是否将 base64 转换为 PIL Image
        convert_path: 是否将路径转换为绝对路径
    
    Returns:
        处理后的图片数据
    """
    if isinstance(image_data, list):
        # 处理列表
        # meshy 处理多张图，不能有空字符串中间, 假如输入[img, "", "", img2] 处理后变成 [img, img2]  
        if clean_empty_img and len(image_data) >= 1:
            logger.debug(f"clean_empty_img: {image_data}")
            image_data = [item for item in image_data if item and item != ""]
            if len(image_data) == 0:
                return []
        return [handle_image(item, convert_base64, convert_path, clean_empty_img) for item in image_data]
    
    if isinstance(image_data, dict):
        # 处理字典（例如 tripo 的 file 字段）
        if "url" in image_data and image_data["url"]:
            if convert_base64 and image_data["url"].startswith("data:image"):
                # base64 转 PIL
                image_data["url"] = base64_to_pil(image_data["url"])
            elif convert_path and not image_data["url"].startswith(("http://", "https://", "data:")):
                # 路径转换
                if not os.path.isabs(image_data["url"]):
                    from data.config import FILE_SAVE_PATH
                    image_data["url"] = os.path.join(FILE_SAVE_PATH, image_data["url"])
        return image_data
    
    if isinstance(image_data, str):
        if not image_data:
            return image_data
        
        # base64 转 PIL
        if convert_base64 and image_data.startswith("data:image"):
            return base64_to_pil(image_data)
        
        # 路径转换
        if convert_path and not image_data.startswith(("http://", "https://", "data:")):
            if not os.path.isabs(image_data):
                from data.config import FILE_SAVE_PATH
                return os.path.join(FILE_SAVE_PATH, image_data)
        
        return image_data
    
    return image_data


def base64_to_pil(base64_string: str) -> Image.Image:
    """
    将 base64 字符串转换为 PIL Image
    
    Args:
        base64_string: base64 编码的图片字符串（可能包含 data:image/...;base64, 前缀）
    
    Returns:
        PIL Image 对象
    """
    try:
        # 移除 data:image/...;base64, 前缀
        if "," in base64_string:
            header, b64data = base64_string.split(",", 1)
        else:
            b64data = base64_string
        
        # 解码 base64
        image_bytes = base64.b64decode(b64data)
        
        # 转换为 PIL Image
        img = Image.open(BytesIO(image_bytes))
        return img
    except Exception as e:
        logger.error(f"base64 转 PIL Image 失败: {e}")
        raise ValueError(f"无效的 base64 图片数据: {e}")


def pil_to_base64(image: Image.Image, format: str = "PNG") -> str:
    """
    将 PIL Image 转换为 base64 字符串
    
    Args:
        image: PIL Image 对象
        format: 图片格式（PNG, JPEG 等）
    
    Returns:
        base64 编码的图片字符串（带 data:image/...;base64, 前缀）
    """
    from io import BytesIO
    
    buffer = BytesIO()
    image.save(buffer, format=format)
    image_bytes = buffer.getvalue()
    
    b64data = base64.b64encode(image_bytes).decode("utf-8")
    mime_type = f"image/{format.lower()}"
    
    return f"data:{mime_type};base64,{b64data}"

