"""
路由辅助函数
用于在 FastAPI 路由中使用动态配置
"""
from typing import Type, Optional
from fastapi import Depends
from pydantic import BaseModel

from .model_loader import load_model_config
from .base_model import build_dynamic_model, process_request


def get_dynamic_model(model_name: str) -> Type[BaseModel]:
    """
    获取动态生成的模型类
    
    Args:
        model_name: 模型名称（例如 "meshy", "hunyuan"）
    
    Returns:
        动态生成的 Pydantic 模型类
    
    使用示例:
        @router.post("/submit")
        async def submit(input: get_dynamic_model("hunyuan")):
            # input 已经是验证后的动态模型实例
            data = input.model_dump()
            ...
    """
    config = load_model_config(model_name)
    return build_dynamic_model(config)


def create_model_dependency(model_name: str):
    """
    创建 FastAPI 依赖函数，用于依赖注入
    
    Args:
        model_name: 模型名称
    
    Returns:
        FastAPI 依赖函数
    
    使用示例:
        @router.post("/submit")
        async def submit(input: Depends(create_model_dependency("hunyuan"))):
            data = input.model_dump()
            ...
    """
    def dependency():
        config = load_model_config(model_name)
        Model = build_dynamic_model(config)
        return Model
    
    return dependency


async def get_validated_data(model_name: str, input_data: dict) -> dict:
    """
    验证和处理输入数据（推荐方式）
    
    Args:
        model_name: 模型名称
        input_data: 原始输入数据字典
    
    Returns:
        验证和处理后的数据字典
    
    使用示例:
        @router.post("/submit")
        async def submit(request: Request):
            input_data = await request.json()
            validated_data = await get_validated_data("hunyuan", input_data)
            # 使用 validated_data
            ...
    """
    return process_request(model_name, input_data)


# 更简洁的方式：直接使用函数作为类型注解
def DynamicModel(model_name: str):
    """
    创建一个动态模型类型，可以直接用作 FastAPI 路由参数的类型注解
    
    注意：这种方式需要在路由函数内部处理，因为 FastAPI 的类型注解系统
    不支持这种动态类型。建议使用 get_validated_data 或 process_request。
    
    使用示例（不推荐，仅作参考）:
        @router.post("/submit")
        async def submit(request: Request):
            input_data = await request.json()
            Model = DynamicModel("hunyuan")
            validated = Model(**input_data)
            ...
    """
    config = load_model_config(model_name)
    return build_dynamic_model(config)

