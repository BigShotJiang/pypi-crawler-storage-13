"""
动态生成 Pydantic 模型
根据模型配置动态创建 Pydantic 模型类
"""
from typing import Any, Dict, List, Optional, Type, Union, Literal
from pydantic import BaseModel, Field, create_model
from pydantic_core import PydanticUndefined
from annotated_types import Ge, Le, MaxLen

from .model_loader import ModelConfig, ParameterConfig
import logging
logger = logging.getLogger(__name__)

def _get_python_type(param_config: ParameterConfig) -> Type:
    """
    将配置中的类型转换为 Python 类型
    
    Args:
        param_config: 参数配置
    
    Returns:
        Python 类型
    """
    type_mapping = {
        "string": str,
        "number": int,
        "boolean": bool,
        "select": str,
        "list": list,
        "dict": dict,
    }
    
    python_type = type_mapping.get(param_config.type, str)
    
    # 对于可选字段（required=False 或 有默认值），使用 Optional
    # 注意：如果 required=True 但提供了默认值，字段实际上也是可选的
    if not param_config.required:
        return Optional[python_type]
    elif param_config.default is not None and param_config.default is not PydanticUndefined:
        # required=True 但提供了默认值，字段实际上是可选的
        return Optional[python_type]
    
    return python_type


def _create_field_info(param_config: ParameterConfig, field_name: str) -> tuple:
    """
    创建 Pydantic Field 信息
    
    Args:
        param_config: 参数配置
        field_name: 字段名称
    
    Returns:
        (type, Field) 元组
    """
    python_type = _get_python_type(param_config)
    
    if param_config.type in ["number", "float", "double"]:
        python_type = float if param_config.required else Optional[float]

    if param_config.type in ["integer", "int"]:
        python_type = int if param_config.required else Optional[int]
    # 构建 Field 参数
    # 在 Pydantic 中，字段是否必需（required）取决于是否有默认值：
    # - 如果 required=True，使用 ...（Ellipsis）表示必需字段（忽略 default 值）
    # - 如果 required=False，使用配置的默认值（包括 None、[]、"" 等）
    if param_config.required:
        # 必需字段：无论是否有 default 值，都使用 ... 表示必需
        # 这样字段就是必需的，不会因为 default 值而变成可选
        default_value = ...  # 使用 ... 表示必需字段
    else:
        # 可选字段：使用配置的默认值
        if param_config.default is PydanticUndefined:
            default_value = None  # 如果没有默认值，使用 None
        else:
            default_value = param_config.default
    
    field_kwargs = {
        "default": default_value,
        "description": param_config.description,
    }
    
    # 添加 title（用于前端显示）
    if param_config.json_schema_extra and "label" in param_config.json_schema_extra:
        field_kwargs["title"] = param_config.json_schema_extra["label"]
    else:
        field_kwargs["title"] = field_name
    
    # 处理约束条件
    if param_config.range:
        min_val, max_val = param_config.range
        if min_val is not None:
            field_kwargs["ge"] = min_val
        if max_val is not None:
            field_kwargs["le"] = max_val
    
    if param_config.max_length:
        field_kwargs["max_length"] = param_config.max_length
    
    # 添加 json_schema_extra
    if param_config.json_schema_extra:
        field_kwargs["json_schema_extra"] = param_config.json_schema_extra
    
    # 处理 Literal 类型（select）
    # 从 json_schema_extra.value 读取选项
    if param_config.type == "select":
        options = None
        if param_config.json_schema_extra and "value" in param_config.json_schema_extra:
            options = param_config.json_schema_extra["value"]
        elif param_config.options:
            options = param_config.options  # 向后兼容
        
        if options:
            # 创建 Literal 类型
            literal_type = Literal[tuple(options)]
            python_type = Optional[literal_type] if not param_config.required else literal_type
    
    # 处理 list 类型
    if param_config.type == "list":
        # 如果默认值是 None，使用 Optional[List[str]]
        if param_config.default is None:
            python_type = Optional[List[str]]
        else:
            python_type = List[str] if not param_config.required else List[str]
    
    # 处理 dict 类型
    if param_config.type == "dict":
        python_type = Dict[str, Any] if not param_config.required else Dict[str, Any]
    
    field = Field(**field_kwargs)
    
    return (python_type, field)


def build_dynamic_model(model_config: ModelConfig, base_class: Type[BaseModel] = None) -> Type[BaseModel]:
    """
    根据模型配置动态生成 Pydantic 模型
    
    Args:
        model_config: 模型配置
        base_class: 基础类，默认为 MyBaseModel（带 protected_namespaces 配置）
    
    Returns:
        动态生成的 Pydantic 模型类
    """
    if base_class is None:
        # 使用 MyBaseModel 作为基类（支持 protected_namespaces）
        from .model_loader import MyBaseModel
        base_class = MyBaseModel
    
    fields = {}
    
    for param_name, param_config in model_config.parameters.items():
        field_type, field = _create_field_info(param_config, param_name)
        fields[param_name] = (field_type, field)
    
    # 使用 create_model 动态创建模型类
    model_name = f"{model_config.name.capitalize()}_Input"
    dynamic_model = create_model(
        model_name,
        __base__=base_class,
        **fields
    )
    
    return dynamic_model


def process_request(model_name: str, input_data: dict, config_dir: Optional[str] = None) -> dict:
    """
    处理请求数据
    
    Args:
        model_name: 模型名称
        input_data: 输入数据字典
        config_dir: 配置文件目录
    
    Returns:
        处理后的数据字典
    """
    from .model_loader import load_model_config
    from .image_handler import handle_image
    
    cfg = load_model_config(model_name, config_dir)
    
    # 检查是否启用透传
    if cfg.passthrough.enabled:
        logger.info(f"[{model_name}] 模型设置为透传，直接下发输入数据")
        return input_data
    
    # 在验证之前预处理需要转换的字段（例如：list -> string）
    # 这样可以避免类型校验错误
    # preprocessed_data = input_data.copy()
    # if cfg.image_handling.enabled and cfg.image_handling.field_name:
    #     field_name = cfg.image_handling.field_name
    #     if field_name in preprocessed_data:
    #         # 如果配置了 convert_to_string，且输入是 list，先转换为 string
    #         if cfg.image_handling.convert_to_string:
    #             field_value = preprocessed_data[field_name]
    #             if isinstance(field_value, list):
    #                 # 如果是列表，取第一个元素或转换为字符串
    #                 if len(field_value) > 0:
    #                     preprocessed_data[field_name] = field_value[0] if isinstance(field_value[0], str) else str(field_value[0])
    #                 else:
    #                     preprocessed_data[field_name] = ""
    
    # 动态生成模型并验证数据
    Model = build_dynamic_model(cfg)
    # 查看Model 的files 是不是必须的属性
    # print(f"Model: {Model.model_fields}")

    parsed = Model(**input_data).model_dump()
    
    # 设置特殊处理字段（在图片处理之前）
    if cfg.special_fields.enabled and cfg.special_fields.fields:
        for field_name, field_value in cfg.special_fields.fields.items():
            # 如果字段值是可调用的（函数），则调用它
            if callable(field_value):
                parsed[field_name] = field_value(parsed, cfg.name)
            else:
                # 否则直接设置值
                # 设置值
                # logger.debug(f"设置特殊处理字段: {field_name} = {field_value}")
                parsed[field_name] = field_value
    
    # 处理图片
    if cfg.image_handling.enabled and cfg.image_handling.field_name:
        field_name = cfg.image_handling.field_name
        if field_name in parsed:
            parsed[field_name] = handle_image(
                parsed[field_name],
                convert_base64=cfg.image_handling.convert_base64,
                convert_path=cfg.image_handling.convert_path,
                clean_empty_img=cfg.image_handling.clean_empty_img
            )
    
    return parsed

