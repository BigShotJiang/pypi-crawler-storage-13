"""
模型配置加载器
从 YAML 配置文件加载模型配置
"""
import os
import yaml
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field
from enum import Enum

CONFIG_DIR = os.getenv('CONFIG_DIR', 'params')
class ParameterConfig(BaseModel):
    """参数配置"""
    type: Literal["string", "number", "boolean", "select", "list", "dict", "float"]
    default: Any = None
    description: str = ""
    name: Optional[str] = None  # 中文显示名称（用于前端显示）
    required: bool = False
    options: Optional[list] = None  # 用于 select 类型
    range: Optional[list] = None  # 用于 number 类型 [min, max]
    max_length: Optional[int] = None  # 用于 string 和 list 类型
    json_schema_extra: Optional[dict] = None
    tips: Optional[str] = None

class MyBaseModel(BaseModel):
    class Config:
        # 禁用受保护命名空间检查
        protected_namespaces = ()
        
class ImageHandlingConfig(BaseModel):
    """图片处理配置"""
    enabled: bool = False
    field_name: Optional[str] = None
    convert_base64: bool = False
    convert_path: bool = False
    clean_empty_img: bool = False


class PassthroughConfig(BaseModel):
    """透传配置"""
    enabled: bool = False


class SpecialFieldConfig(BaseModel):
    """特殊字段处理配置"""
    enabled: bool = False
    fields: Optional[Dict[str, Any]] = None  # 字段名 -> 处理方式或值
    # 例如: {"model": "hunyuan"} 或 {"mode": "preview"}

class ModelID(int, Enum):
    img = 0
    model = 1
    texture = 2
    sky = 3
    scene = 4
class ModelConfig(BaseModel):
    """模型配置"""
    name: str
    type: ModelID
    mode: Literal["text", "img"]
    parameters: Dict[str, ParameterConfig]
    image_handling: ImageHandlingConfig = Field(default_factory=ImageHandlingConfig)
    passthrough: PassthroughConfig = Field(default_factory=PassthroughConfig)
    special_fields: SpecialFieldConfig = Field(default_factory=SpecialFieldConfig)

    class Config:
        protected_namespaces = ()
        
class ModelSchemaConfig(BaseModel):
    model_type: int = Field(description="模型类型")
    models: List[dict] = Field(description="模型配置")
    general_schema: List = Field(description="模型通用配置")
    extra_schema: dict = Field(description="模型额外配置")
    class Config:
        protected_namespaces = ()

def load_model_config(name: str, config_dir: Optional[str] = None) -> ModelConfig:
    """
    加载模型的输入参数配置
    
    Args:
        name: 模型名称（例如 "meshy", "hunyuan"）
        config_dir: 配置文件目录，默认为 routeapi/config
    
    Returns:
        ModelConfig: 模型配置对象
    """
    if config_dir is None:
        # 获取当前文件所在目录的父目录（routeapi）
        current_dir = Path(__file__).parent.parent
        config_dir = current_dir / CONFIG_DIR
    else:
        config_dir = Path(config_dir)
    
    config_path = config_dir / f"{name}.yml"
    
    if not config_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")
    
    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    
    # 转换 parameters 字典为 ParameterConfig 对象
    if "parameters" in data:
        parameters = {}
        for param_name, param_data in data["parameters"].items():
            parameters[param_name] = ParameterConfig(**param_data)
        data["parameters"] = parameters
    
    # 转换 image_handling
    if "image_handling" in data:
        data["image_handling"] = ImageHandlingConfig(**data["image_handling"])
    else:
        data["image_handling"] = ImageHandlingConfig()
    
    # 转换 passthrough
    if "passthrough" in data:
        data["passthrough"] = PassthroughConfig(**data["passthrough"])
    else:
        data["passthrough"] = PassthroughConfig()
    
    # 转换 special_fields
    if "special_fields" in data:
        data["special_fields"] = SpecialFieldConfig(**data["special_fields"])
    else:
        data["special_fields"] = SpecialFieldConfig()
    
    return ModelConfig(**data)


def list_available_models(config_dir: Optional[str] = None) -> list[str]:
    """
    列出所有可用的模型配置
    
    Args:
        config_dir: 配置文件目录
    
    Returns:
        list[str]: 模型名称列表
    """
    if config_dir is None:
        current_dir = Path(__file__).parent.parent
        config_dir = current_dir / CONFIG_DIR
    else:
        config_dir = Path(config_dir)
    
    if not config_dir.exists():
        return []
    
    models = []
    for config_file in config_dir.glob("*.yml"):
        model_name = config_file.stem
        if model_name.startswith("model"):
            continue
        models.append(model_name)
    return sorted(models)

# 加载配置成json
def load_config_to_json(name: str, config_dir: Optional[str] = None) -> dict:
    """
    加载配置成json
    参数:
    name: 配置名称
    config_dir: 配置文件目录
    Returns:
        dict: 配置json
    """
    if config_dir is None:
        current_dir = Path(__file__).parent.parent
        config_dir = current_dir / CONFIG_DIR
    else:
        config_dir = Path(config_dir)
    
    config_path = config_dir / f"{name}.yml"
    if not config_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")
    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return data