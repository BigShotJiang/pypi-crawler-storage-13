
import asyncio
import base64
import hashlib
import logging as logger
import os
import shutil
from typing import Callable, List, Optional, Tuple, Union
from uuid import uuid4

from boto3.s3.transfer import TransferConfig
from boto3.session import Session
from botocore.exceptions import BotoCoreError, ClientError
import urllib3
from urllib3.exceptions import InsecureRequestWarning

from .data.config import (
    EOS_APPID,
    EOS_BUCKETID,
    EOS_ONLINE_URL,
    EOS_SAVE_DATA_URL,
    EOS_SECRET,
    EOS_TOKEN_URL,
    EOS_URL,
    UPLOAD_TEMP_PATH,
)
from .data.response_json import CODES, CustomException
from .http_requests import AsyncHttpClient

urllib3.disable_warnings(InsecureRequestWarning)

def get_image_type(urls: Union[str, List[str]]) -> str:
    """
    判断图像类型，通过文件的后缀名进行判断。
    
    :param url: 图像文件的 URL
    :return: 图像类型（如 'png', 'jpeg', 'gif', 'bmp'）或 'unknown'
    """
    # 统一转为列表处理
    if isinstance(urls, str):
        urls = [urls]
    extension = ""
    for url in urls:
        if url == "":
            continue
            # 提取文件名及其扩展名
        url_without_query = url.split('?')[0]
        file_name = os.path.basename(url_without_query)
        _, extension = os.path.splitext(file_name)
            # 去掉点号并转换为小写
        extension = extension.lower().lstrip('.')
            # 检查扩展名是否是常见图像类型
        # if extension not in ('png', 'jpeg', 'jpg', 'bmp', 'webp'):
        #     return False # 统一返回 'jpeg'
    if not extension:
        raise CustomException(
            code=CODES.FILE_FORMAT_ERROR,
            message="无法识别图片格式"
        )
    return extension
# Step 1: 下载文件并保存到临时目录
async def download_file(url: str, save_folder: Optional[str] = None, ext: Optional[str] = None) -> Tuple[str, str]:
    try:
        
        http = await AsyncHttpClient.get_instance(verify_ssl=False)
        local_url = url
        if os.path.exists(local_url):
            return (local_url, get_image_type(local_url))
        
        logger.debug(f"download_file: {url}, ext is {ext}")
        if ext:
            file_type = ext
        else:
            file_type = get_image_type(url)
        # if file_type == "unknown":
        id = uuid4()
        #     raise Exception("only support png, jpeg, jpg, bmp, webp")
        if save_folder:
            file_path = f"{save_folder}/{id}.{file_type}"
        else:
            # 放在temp 文件夹下
            file_path = f"{UPLOAD_TEMP_PATH}/{id}.{file_type}"
        
        response = await http.download_file(url, file_path)
        logger.debug(f"download_file: {file_path}")
        return (response, file_type)
    except CustomException:
        raise
    except Exception as e:
        logger.error(f"download_file error: {e}")
        raise CustomException(
            code=CODES.THIRD_PARTY_ERROR,
            message=f"下载文件失败: {e}"
        ) from e

def calculate_md5(file_path: str, block_size: int = 4096) -> str:
    """
    计算指定文件的 MD5 散列值（hex string）。

    :param file_path: 本地文件路径
    :param block_size: 每次读取的字节块大小（默认 4096）
    :return: 文件内容的 MD5 值（长度为 32 的十六进制字符串）
    """
    md5_hash = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(block_size), b""):
            md5_hash.update(chunk)
    return md5_hash.hexdigest()

async def get_upload_token() -> dict:
    url = f"{EOS_TOKEN_URL}"
    original_string = f"{EOS_APPID}:{EOS_SECRET}"
    byte_data = original_string.encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic " + base64.b64encode(byte_data).decode("utf-8"),
        "AppId": EOS_APPID
    }
    
    json_data = {
        "bucketId": EOS_BUCKETID
    }

    try:
        http = await AsyncHttpClient.get_instance(verify_ssl=False)
        # logger.info(f"AsyncHttpClient 实例化完成，verify_ssl=False 是否生效: {http.ssl_context is None}")
        result = await http.post(url, headers=headers, data=json_data)  # verify=False 忽略 HTTPS 证书校验（仅测试用）
        logger.info(f"result: {result}")
        return result["data"]
    except CustomException:
        raise
    except Exception as e:
        logger.error(f"get_upload_token error: {e}")
        raise CustomException(
            code=CODES.THIRD_PARTY_ERROR,
            message="获取上传凭证失败"
        ) from e

async def save_data(file_path: str, file_type: str, obj_name: str, actual: str):
    url = EOS_SAVE_DATA_URL
    original_string = f"{EOS_APPID}:{EOS_SECRET}"
    byte_data = original_string.encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Basic " + base64.b64encode(byte_data).decode("utf-8"),
        "AppId": EOS_APPID
    }
    json_data = {
        "bucketId": EOS_BUCKETID,
        "path": obj_name,
        "contentHash": actual,
        "contentSize": os.path.getsize(file_path),
        "contentType": file_type
    }

    try:
        http = await AsyncHttpClient.get_instance(verify_ssl=False)

        result = await http.post(url, headers=headers, data=json_data) 
        return result["data"]
    except CustomException:
        raise
    except Exception as e:
        logger.error(f"save_data error: {e}")
        raise CustomException(
            code=CODES.THIRD_PARTY_ERROR,
            message="同步文件元数据失败"
        ) from e


def upload_file_to_eos(
    file_path: str,
    access_key: str,
    secret_key: str,
    token: str,
    object_name: str,
    bucket: str,
    content_type: str,
) -> None:
#     # -*- coding: utf-8 -*-
#     # Client 初始化
#     # 填写 EOS 账号的认证信息，或者子账号的认证信息
#     # 填写 url。例如：'https://IP:PORT' 或者 'https://eos-wuxi-1.cmecloud.cn'
    url = EOS_URL
    try:
        session = Session(access_key, secret_key, token)
        s3_client = session.client('s3', endpoint_url=url)
        # EOS存储桶和对象键（文件名）  
        bucket_name = bucket
        # 要上传的文件路径  
        
        # actual = calculate_md5(file_path)
        
        # 配置上传行为  
        trans_config = TransferConfig(
            multipart_threshold=5 * 1024 * 1024,  # 超过5MB的文件使用分块上传  
            max_concurrency=10,                  # 最大并发数为10  
            multipart_chunksize=5 * 1024 * 1024,  # 每个分块大小为5MB  
            use_threads=True                     # 使用线程加速上传  
        )
        # file_size = os.path.getsize(file_path)
        # 打开文件并获取文件对象  
        s3_client.upload_file(
            Filename=file_path,
            Bucket=bucket_name,
            Key=object_name,
            ExtraArgs={"ContentType": content_type, "ACL": "public-read"},
            Config=trans_config,
        )
        logger.info(f"{file_path} 上传成功")

    except FileNotFoundError as e:
        raise CustomException(
            code=CODES.FILE_IO_ERROR,
            message=f"上传文件不存在: {file_path}"
        ) from e
    except (BotoCoreError, ClientError) as e:
        raise CustomException(
            code=CODES.THIRD_PARTY_ERROR,
            message=f"上传到 EOS 失败: {e}"
        ) from e
    except Exception as e:
        raise CustomException(
            code=CODES.INTERNAL_ERROR,
            message=f"上传到 EOS 出现异常: {e}"
        ) from e
    
def get_content_type(file_extension):
    """
    根据文件后缀获取对应的Content-Type（MIME类型）
    
    参数:
        file_extension: 文件后缀（带不带点都可以，如'.txt'或'txt'）
    
    返回:
        str: 对应的Content-Type，默认返回'application/octet-stream'
    """
    # 统一处理后缀：转为小写，去掉可能的点
    ext = file_extension.lower().lstrip('.')
    
    # MIME类型映射表，可根据需要扩展
    mime_types = {
        # 图片类型
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'png': 'image/png',
        'gif': 'image/gif',
        'bmp': 'image/bmp',
        'webp': 'image/webp',
        'svg': 'image/svg+xml',
        
        # 3D模型类型
        'ply': 'model/x-ply',
        'glb': 'model/gltf-binary',
        'gltf': 'model/gltf+json',
        'obj': 'model/obj',
        'stl': 'model/stl',
        
        # 文本类型
        'txt': 'text/plain',
        'html': 'text/html',
        'css': 'text/css',
        'js': 'text/javascript',
        'csv': 'text/csv',
        'md': 'text/markdown',
        
        # 文档类型
        'pdf': 'application/pdf',
        'doc': 'application/msword',
        'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls': 'application/vnd.ms-excel',
        'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'ppt': 'application/vnd.ms-powerpoint',
        'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        
        # 压缩文件
        'zip': 'application/zip',
        'tar': 'application/x-tar',
        'gz': 'application/gzip',
        'rar': 'application/vnd.rar',
        
        # 其他常见类型
        'json': 'application/json',
        'xml': 'application/xml',
        'mp3': 'audio/mpeg',
        'mp4': 'video/mp4',
        'avi': 'video/x-msvideo'
    }
    
    # 查找对应的MIME类型，找不到则返回默认值
    return mime_types.get(ext, 'application/octet-stream')

async def upload_file(file_path: str, callback: Optional[Callable] = None, ext: Optional[str] = None):
    Max_retry = 3  # 最大重试次数
    retry_delay = 1  # 初始重试延迟（秒）
    
    last_error: Optional[Exception] = None

    for attempt in range(Max_retry):
        try:
            if file_path.startswith("http"):
                # 下载文件
                file_path, _ = await download_file(file_path, ext=ext)
            
            # 获取文件md5
            file_id = uuid4()
            actual = calculate_md5(file_path)
            logger.info(f"md5的值是：{actual}")
            
            # 获取文件类型和文件名称
            file_name = os.path.basename(file_path)
            _, file_ext = os.path.splitext(file_name)
            eos_file_name = f"{file_id}{file_ext}"
            file_type = get_content_type(file_ext)
            
            # 获取凭证
            token_info = await get_upload_token()
            obj_name = f'{token_info["RootDir"]}/{EOS_APPID}/{actual}/{eos_file_name}'
            
            # 上传文件
            upload_file_to_eos(
                file_path, 
                token_info['AccessKeyId'], 
                token_info['SecretAccessKey'], 
                token_info["SessionToken"], 
                obj_name, 
                token_info["Bucket"], 
                file_type
            )
            
            # 上传数据库
            await save_data(file_path, file_type, eos_file_name, actual)
            
            dir = f"{EOS_ONLINE_URL}{eos_file_name}"
            print(f"dir is {dir}")
            if callback:
                callback(dir)
            return dir 
        
        except CustomException as e:
            last_error = e
            if attempt == Max_retry - 1:
                raise
            logger.warning(f"第 {attempt + 1} 次上传失败: {e}, 将在 {retry_delay} 秒后重试")
        except Exception as e:
            last_error = e
            # 如果是最后一次尝试，则抛出异常
            if attempt == Max_retry - 1:
                raise CustomException(
                    code=CODES.INTERNAL_ERROR,
                    message=f"达到最大重试次数，文件上传失败: {e}"
                ) from e
            
            # 记录重试信息
            logger.warning(f"第 {attempt + 1} 次上传失败: {str(e)}，将在 {retry_delay} 秒后重试")
            
            # 等待一段时间后重试，指数退避策略
            await asyncio.sleep(retry_delay)
            retry_delay *= 2  # 每次重试延迟翻倍，减少服务器压力

    # 理论上不会到达这里，因为循环内要么返回要么抛出异常
    if isinstance(last_error, CustomException):
        raise last_error

    raise CustomException(
        code=CODES.INTERNAL_ERROR,
        message="未知错误，文件上传失败"
    )

def delete_folder(folder_path: str) -> bool:
    # 判断是文件么
    # 判断该路径是否为目录（实际脚本通常是文件，所以此判断可能返回 False）
    if not os.path.isdir(folder_path):
        # 如果是目录，直接使用该路径
        folder_path = os.path.dirname(folder_path)
    
    # 检查文件夹是否存在
    if os.path.exists(folder_path):
        try:
            # 递归删除文件夹及其内容
            shutil.rmtree(folder_path)
            logger.debug(f"文件夹 '{folder_path}' 已成功删除")
            return True
        except Exception as e:
            logger.error(f"删除文件夹失败: {e}")
            raise CustomException(
                code=CODES.FILE_IO_ERROR,
                message=f"删除临时文件失败: {e}"
            ) from e
    else:
        logger.error(f"文件夹 '{folder_path}' 不存在")
        code = getattr(CODES, "FILE_NOT_FOUND", CODES.FILE_IO_ERROR)
        raise CustomException(
            code=code,
            message="临时文件夹不存在"
        )
    