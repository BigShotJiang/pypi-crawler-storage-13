import json
from typing import Optional
from redis.asyncio import Redis, RedisCluster, ConnectionError
from redis.exceptions import RedisError
from redis.cluster import ClusterNode
import logging as logger

from .data.config import (
    MODE,
    REDIS_PORT,
    REDIS_HOST,
    REDIS_PASSWORD,
    TASK_STATUS_PREFIX,
    TASK_QUEUE_KEY,
    TASK_DATA_PREFIX,
)
from .data.response_json import CODES, CustomException
# TASK_QUEUE_KEY = "img_task_queue"
# TASK_DATA_PREFIX = "img_task_data:"
# TASK_IMG_URL_PREFIX = "img_url:"

def singleton(cls):
    """单例装饰器"""
    instances = {}
    def wrapper(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    return wrapper

@singleton
class RedisManager:
    def __init__(self):
        self.redis_client = None

    async def _check_connection_health(self):
        """检查当前 Redis 客户端健康状态"""
        if self.redis_client is None:
            raise ConnectionError("Redis client is not initialized")

        if hasattr(self.redis_client, "cluster_info"):
            cluster_info = await self.redis_client.cluster_info()
            if cluster_info.get("cluster_state") != "ok":
                raise ConnectionError("Redis cluster is not in a healthy state")
        else:
            await self.redis_client.ping()

    def _create_client(self):
        """创建 Redis 客户端"""
        if MODE == "Production":
           cluster_nodes = [ClusterNode(host=REDIS_HOST, port=REDIS_PORT)]
           self.redis_client = RedisCluster(startup_nodes=cluster_nodes, decode_responses=True,password=REDIS_PASSWORD, health_check_interval=30)
        else:
            self.redis_client = Redis(
                host=REDIS_HOST,
                port=REDIS_PORT,
                decode_responses=True,
                retry_on_timeout=True,
                password=REDIS_PASSWORD,
                health_check_interval=30
            )
    async def ensure_connection(self):
        """确保 Redis 连接可用"""
        """确保 Redis 集群连接可用"""
        if self.redis_client is None:
            self._create_client()
        try:
            await self._check_connection_health()
        except (ConnectionError, RedisError) as conn_err:
            logger.warning(f"Redis connection error: {conn_err}, retrying...")
            self._create_client()
            try:
                await self._check_connection_health()
            except (ConnectionError, RedisError) as retry_err:
                logger.error(f"Redis reconnection failed: {retry_err}")
                raise CustomException(
                    code=CODES.SERVICE_UNAVAILABLE,
                    message="Redis 服务不可用，请稍后再试"
                ) from retry_err
        except Exception as e:
            logger.exception("Unexpected Redis connection error")
            raise CustomException(
                code=CODES.INTERNAL_ERROR,
                message="Redis 连接检测异常"
            ) from e


    async def set_task_status(self, task_id: str, status: str = "processing", progress: any = None, result: str = None, timestamp: str = None, ttl: int = 172800):
        """设置任务状态，默认1小时过期"""
        key = f"{TASK_STATUS_PREFIX}{task_id}"
        # print(f"set_task_status: {result} and progress is {progress}")
        try:
            await self.ensure_connection()
            mapping = {}
            if status:
                mapping["status"] = str(status.value) if hasattr(status, "value") else str(status)
            if progress is not None:
                mapping["progress"] = int(progress)
            if result is not None:
                if isinstance(result, (list, dict)):
                    mapping["output"] = json.dumps(result, ensure_ascii=False)
                else:
                    mapping["output"] = result
            if timestamp:
                mapping["created_at"] = int(timestamp)

            if not mapping:
                logger.warning(f"set_task_status called with empty payload for task_id={task_id}")
                return

            await self.redis_client.hset(key, mapping=mapping)
            await self.redis_client.expire(key, ttl)
        except CustomException:
            raise
        except Exception as e:
            logger.error(f"set_task_status error: {e}")
            raise CustomException(
                code=CODES.INTERNAL_ERROR,
                message="更新任务状态失败"
            ) from e

    async def get_task_status(self, task_id: str) -> dict:
        """获取任务状态"""
        key = f"{TASK_STATUS_PREFIX}{task_id}"
        try:
            await self.ensure_connection()
            res = await self.redis_client.hgetall(key)
            # print(f"get_task_status: {res}")
            return res
        except CustomException:
            raise
        except Exception as e:
            logger.error(f"get_task_status error: {e}")
            raise CustomException(
                code=CODES.INTERNAL_ERROR,
                message="查询任务状态失败"
            ) from e
    # async def set_img_url(self, img_id: str, img_url: str):
    #     """设置图像url"""
    #     key = f"{TASK_IMG_URL_PREFIX}{img_id}"
    #     try:
    #         await self.ensure_connection()
    #         await self.redis_client.set(key, img_url)
    #     except Exception as e:
    #         logger.error("set_img_url error")
    #         logger.error(e)
    #         raise Exception("set_img_url error")
    # async def get_img_url(self, img_id: str):
    #     key = f"{TASK_IMG_URL_PREFIX}{img_id}"
    #     try:
    #         await self.ensure_connection()
    #         return await self.redis_client.get(key)
    #     except Exception as e:
    #         logger.error("get_img_url error")
    #         logger.error(e)
    #         raise Exception("get_img_url error")
    async def add_task_to_queue(self, task_id: str, data: dict, ttl: int = 3600) -> bool:
        """添加任务到队列"""
        try:
            # 保存任务数据
            await self.ensure_connection()
            await self.redis_client.set(
                f"{TASK_DATA_PREFIX}{task_id}", 
                json.dumps(data, default=str),
                ex=ttl
            )
            # 添加到队列
            result = await self.redis_client.rpush(TASK_QUEUE_KEY, task_id)
            return result > 0
        except CustomException:
            raise
        except Exception as e:
            logger.error(f"add_task_to_queue error: {e}")
            raise CustomException(
                code=CODES.INTERNAL_ERROR,
                message="添加任务到队列失败"
            ) from e

    async def get_next_task(self) -> Optional[tuple[str, dict]]:
        """获取下一个任务"""
        try:
            await self.ensure_connection()
            task_id = await self.redis_client.lpop(TASK_QUEUE_KEY)
            if not task_id:
                return None

            task_data = await self.redis_client.get(f"{TASK_DATA_PREFIX}{task_id}")
            if task_data:
                return task_id, json.loads(task_data)
            return None
        except CustomException:
            raise
        except Exception as e:
            logger.error(f"get_next_task error: {e}")
            raise CustomException(
                code=CODES.INTERNAL_ERROR,
                message="获取任务队列数据失败"
            ) from e

    async def delete_task(self, task_id: str):
        """删除任务相关的所有数据"""
        try:
            await self.ensure_connection()
            await self.redis_client.delete(
                f"{TASK_STATUS_PREFIX}{task_id}",
                f"{TASK_DATA_PREFIX}{task_id}"
            )
        except CustomException:
            raise
        except Exception as e:
            logger.error(f"delete_task error: {e}")
            raise CustomException(
                code=CODES.INTERNAL_ERROR,
                message="删除任务数据失败"
            ) from e

# 创建全局 Redis 管理器实例
redis_manager = RedisManager()