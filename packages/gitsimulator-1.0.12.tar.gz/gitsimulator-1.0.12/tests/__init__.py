"""Tests for git-sim."""
