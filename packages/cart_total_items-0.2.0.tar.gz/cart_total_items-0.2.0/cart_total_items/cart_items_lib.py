
def cart_total(cart):
    total = 0
    for item in cart:
        price = float(item['price'])
        qty = int(item['quantity'])
        total += price * qty
    return total

def cart_count(cart):
    count = 0
    for item in cart:
        count += int(item['quantity'])
    return count

