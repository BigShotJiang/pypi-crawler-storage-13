#!/opt/anaconda3/envs/idex/bin/python
# -*- coding: utf-8 -*-
from __future__ import annotations

# =====================================================================
# IDEX Quicklook — QtAgg canvas + Matplotlib Navigation Toolbar
# Interactive viewer with channel selection, overlays, and fit editing tools
# =====================================================================

import os
os.environ.pop("QT_DEBUG_PLUGINS", None)
import sys
import argparse
import importlib
import tempfile
import io
import base64
import re
import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple, Set

# ---------------------------------------------------------------------------
# Support execution both as part of the ``spectrumpy_flight`` package and when
# dynamically loaded from disk (e.g. via :func:`importlib.util.spec_from_file`).
# ``HDF_Explorer`` uses the latter approach which means ``__package__`` can be
# empty unless we normalise ``sys.path`` here.  Keeping the parent directory on
# ``sys.path`` lets us rely on absolute imports without mutating ``__package__``
# (which was the source of ``__package__ != __spec__.parent`` warnings).
# ---------------------------------------------------------------------------
if __package__ in (None, ""):
    package_root = Path(__file__).resolve().parent.parent
    parent_dir = str(package_root)
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)

import html
import textwrap
from datetime import timedelta

try:
    import h5py  # type: ignore
except Exception:  # pragma: no cover - optional dependency for environments without h5py
    h5py = None

# --- ERFC shim compatible with NumPy 1.x/2.x (SciPy optional) ---
from typing import Union
import numpy as np
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.pool import QueuePool

from spectrumpy_flight.idex_analysis_utils import RISE_METRIC_SUFFIXES, compute_rise_metrics
from spectrumpy_flight.paths import default_hdf5_dir

try:
    # Preferred on modern stacks
    from scipy.special import erfc as _compat_erfc  # type: ignore
except Exception:
    # Fallback: vectorize Python's math.erfc
    from math import erfc as _math_erfc

    def _compat_erfc(x: Union[np.ndarray, float, int]) -> np.ndarray:
        arr = np.asarray(x, dtype=float)
        if arr.ndim == 0:
            return np.array(_math_erfc(float(arr)))
        vec = np.vectorize(lambda v: _math_erfc(float(v)), otypes=[float])
        return vec(arr)
# --- end shim ---


def _erfc(values: Union[np.ndarray, float, int]) -> np.ndarray:
    """Return the complementary error function for *values*."""

    return _compat_erfc(values)

from spectrumpy_flight.HDF_View import launch_hdf_viewer
from spectrumpy_flight.dust_composition import launch_dust_composition_window
from spectrumpy_flight.dust_estimator_gui import launch_dust_estimator_window
from spectrumpy_flight.calibration_data import AcceleratorMatch, AcceleratorMatchFinder
from spectrumpy_flight.mass_calibration import TOFMassCal
from spectrumpy_flight.noise_analysis import ChannelMeta, launch_noise_analysis_window
from spectrumpy_flight.plot_style import apply_plot_style
try:  # pragma: no cover - optional dependency, loaded lazily
    from spectrumpy_flight.HDF_View import launch_hdf_viewer
except Exception:  # pragma: no cover
    launch_hdf_viewer = None

try:  # pragma: no cover - optional dependency, loaded lazily
    from spectrumpy_flight.CDF_View import launch_cdf_viewer
except Exception:  # pragma: no cover
    launch_cdf_viewer = None

try:  # pragma: no cover - optional dependency
    from spectrumpy_flight.IDEX_Definitions_View import launch_variable_definitions_viewer
except Exception:  # pragma: no cover
    launch_variable_definitions_viewer = None

# Qt-backed Matplotlib so NavigationToolbar works
import matplotlib
from matplotlib import mathtext
matplotlib.use("QtAgg")

apply_plot_style()

from matplotlib import patheffects
from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.ticker import FuncFormatter


class ScrollFriendlyFigureCanvas(FigureCanvas):
    """Matplotlib canvas that plays nicely inside scroll areas."""

    def wheelEvent(self, event):  # type: ignore[override]
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            super().wheelEvent(event)
            return
        event.ignore()

# --------- Qt binding-agnostic imports (prefer PySide6, fallback PyQt6) ---------
_QT = None
try:
    from PySide6.QtCore import Qt, QSize, QTimer, QUrl, QBuffer, QIODevice, QSignalBlocker
    from PySide6.QtGui import QAction, QFont, QIcon, QPixmap, QImage, QTextCursor, QTextDocument
    from PySide6.QtWidgets import (
        QApplication, QFileDialog, QMainWindow, QMessageBox, QStatusBar, QToolBar,
        QVBoxLayout, QWidget, QComboBox, QLabel, QSizePolicy, QDialog, QPushButton,
        QHBoxLayout, QGridLayout, QTableWidget, QTableWidgetItem, QHeaderView,
        QCheckBox, QDialogButtonBox, QMenu, QMenuBar, QToolButton, QTextBrowser,
        QListWidget, QListWidgetItem, QLineEdit, QWidgetAction, QStyle, QSplitter,
        QScrollArea, QFrame, QGroupBox, QDoubleSpinBox, QSpinBox
    )
    _QT = "PySide6"
except Exception:
    from PyQt6.QtCore import Qt, QSize, QTimer, QUrl, QBuffer, QIODevice, QSignalBlocker
    from PyQt6.QtGui import QAction, QFont, QIcon, QPixmap, QImage, QTextCursor, QTextDocument
    from PyQt6.QtWidgets import (
        QApplication, QFileDialog, QMainWindow, QMessageBox, QStatusBar, QToolBar,
        QVBoxLayout, QWidget, QComboBox, QLabel, QSizePolicy, QDialog, QPushButton,
        QHBoxLayout, QGridLayout, QTableWidget, QTableWidgetItem, QHeaderView,
        QCheckBox, QDialogButtonBox, QMenu, QMenuBar, QToolButton, QTextBrowser,
        QListWidget, QListWidgetItem, QLineEdit, QWidgetAction, QStyle, QSplitter,
        QScrollArea, QFrame, QGroupBox, QDoubleSpinBox, QSpinBox
    )
    _QT = "PyQt6"

# print(f"[info] Qt binding: {_QT}, Matplotlib backend: {matplotlib.get_backend()}")

matplotlib.rcParams.update({
    "axes.titlesize": 18,
    "axes.labelsize": 16,
    "xtick.labelsize": 14,
    "ytick.labelsize": 14,
    "legend.fontsize": 14,
    "lines.linewidth": 1.8,
})

IMAGES_DIR = Path(__file__).resolve().parent / "Images"
IMAP_LOGO_CANDIDATES = (
    "IMAP_logo.png",
    "IMAP_logo.jpg",
    "IMAP_logo.jpeg",
    "imap_logo.png",
    "IMAP.png",
    "IMAP.jpeg",
)


def _find_brand_logo() -> Optional[Path]:
    for candidate in IMAP_LOGO_CANDIDATES:
        logo_path = IMAGES_DIR / candidate
        if logo_path.exists():
            return logo_path
    return None


def _load_brand_pixmap(*, max_height: int = 72) -> Optional[QPixmap]:
    logo_path = _find_brand_logo()
    if logo_path is None:
        return None

    pixmap = QPixmap(str(logo_path))
    if pixmap.isNull():
        return None

    # ``scaledToHeight`` already preserves the aspect ratio; in PyQt6/PySide6 it only
    # accepts the target height and an optional transformation mode.  Passing an
    # aspect-ratio flag raises a ``TypeError`` under PyQt6, so we only supply the
    # desired height and transformation mode here.
    return pixmap.scaledToHeight(
        max_height,
        Qt.TransformationMode.SmoothTransformation,
    )

# --------- Small utils ---------
def prompt_for_data_file(
    parent: QWidget,
    start_dir: str | None = None,
    *,
    preferred: Optional[str] = None,
) -> Optional[str]:
    """Show a non-native file dialog that accepts HDF5 and CDF payloads."""

    if start_dir is None:
        repo_root = Path(__file__).resolve().parent
        hdf5_dir = default_hdf5_dir()
        preferred_map = {
            "cdf": repo_root / "CDF",
            "hdf5": hdf5_dir,
        }
        if preferred and (target_dir := preferred_map.get(preferred.lower())) and target_dir.exists():
            start_dir = str(target_dir)
        else:
            default_dir = hdf5_dir if hdf5_dir.exists() else repo_root
            start_dir = str(default_dir)

    options = QFileDialog.Option.DontUseNativeDialog | QFileDialog.Option.ReadOnly

    filters = [
        "Data Files (*.h5 *.hdf5 *.cdf)",
        "HDF5 Files (*.h5 *.hdf5)",
        "CDF Files (*.cdf)",
        "All files (*)",
    ]

    if preferred == "hdf5":
        filters = [filters[1], filters[0], filters[2], filters[3]]
    elif preferred == "cdf":
        filters = [filters[2], filters[0], filters[1], filters[3]]

    filename, _ = QFileDialog.getOpenFileName(
        parent,
        "Open Data File",
        start_dir,
        ";;".join(filters),
        options=options,
    )
    return filename or None

def _normalize_name(value: str) -> str:
    return "".join(ch.lower() for ch in value if ch.isalnum())

def _pair_key(path: str) -> str:
    base = _normalize_name(os.path.basename(path))
    for token in ("time", "result", "fit", "curve"):
        base = base.replace(token, "")
    return base

def _friendly_label(path: str) -> str:
    base = os.path.basename(path)
    replacements = {
        "FitResult": "Fit",
        "fitresult": "Fit",
        "Result": "Fit",
    }
    for needle, repl in replacements.items():
        base = base.replace(needle, repl)
    return base


def _label_from_param_path(path: str) -> str:
    base = os.path.basename(path)
    replacements = (
        ("FitParameters", "Fit"),
        ("FitParams", "Fit"),
        ("fitparameters", "Fit"),
        ("fitparams", "Fit"),
        ("Parameters", "Fit"),
        ("Params", "Fit"),
    )
    for needle, repl in replacements:
        if needle in base:
            base = base.replace(needle, repl)
    if "Fit" in base and " Fit" not in base:
        base = base.replace("Fit", " Fit")
    base = " ".join(base.split()).strip()
    if not base:
        base = "Fit"
    if "Fit" not in base:
        base = f"{base} Fit"
    return f"{base} (calc)"


@dataclass(frozen=True)
class DocumentationEntry:
    path: Path
    title: str
    text: str
    lines: List[str]

    @property
    def display_name(self) -> str:
        return self.title or self.path.stem.replace("_", " ").title()

    @property
    def relative_path(self) -> str:
        try:
            return str(self.path.relative_to(Path(__file__).resolve().parent))
        except ValueError:
            return str(self.path)


def _iter_document_paths() -> List[Path]:
    root = Path(__file__).resolve().parent
    candidates: List[Path] = []
    readme = root / "README.md"
    if readme.exists():
        candidates.append(readme)
    docs_dir = root / "docs"
    if docs_dir.exists():
        candidates.extend(sorted(docs_dir.rglob("*.md")))
    return candidates


def _derive_title(path: Path, text: str) -> str:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            return stripped.lstrip("# ").strip()
    return path.stem.replace("_", " ").title()


def _load_documentation_entries() -> List[DocumentationEntry]:
    entries: List[DocumentationEntry] = []
    for path in _iter_document_paths():
        try:
            text = path.read_text(encoding="utf-8")
        except Exception:
            continue
        lines = text.splitlines()
        title = _derive_title(path, text)
        entries.append(DocumentationEntry(path=path, title=title, text=text, lines=lines))
    return entries


_DOCUMENTATION_ENTRIES: List[DocumentationEntry] = _load_documentation_entries()


class DocumentationCenter(QDialog):
    """A lightweight reader with full-text search across project documentation."""

    def __init__(self, parent: Optional[QWidget] = None, *, initial_query: str = "") -> None:
        super().__init__(parent)
        self.setWindowTitle("SpectrumPY Flight Documentation Center")
        self.resize(1024, 680)
        self.setModal(False)
        self.setStyleSheet(
            """
            QDialog {
                background: #eef2f7;
            }
            QLineEdit {
                font-size: 15px;
                padding: 8px 10px;
                border-radius: 6px;
            }
            QPushButton {
                font-size: 15px;
                padding: 8px 18px;
                border-radius: 6px;
            }
            QListWidget {
                font-size: 15px;
                border: 1px solid #cbd5e0;
                border-radius: 10px;
            }
            QListWidget::item {
                padding: 8px 10px;
            }
            QListWidget::item:selected {
                background: #2563eb;
                color: white;
            }
            QLabel#docHeading {
                font-size: 28px;
                font-weight: 600;
            }
            QLabel#docDescription {
                font-size: 15px;
                color: #475569;
            }
            QLabel#docStatus {
                font-size: 14px;
                color: #475569;
            }
            """
        )
        self._documents = _DOCUMENTATION_ENTRIES
        self._current_entry: Optional[DocumentationEntry] = None
        self._current_query: str = ""

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(18)

        heading = QLabel("SpectrumPY Documentation & Tutorials", self)
        heading.setObjectName("docHeading")
        layout.addWidget(heading)

        description = QLabel(
            "Search the bundled README and guides, or browse tutorials with a single click.",
            self,
        )
        description.setObjectName("docDescription")
        description.setWordWrap(True)
        layout.addWidget(description)

        search_row = QHBoxLayout()
        search_row.setSpacing(10)

        self.search_field = QLineEdit(self)
        self.search_field.setPlaceholderText("Search documentation…")
        self.search_field.setClearButtonEnabled(True)
        self.search_field.setMinimumWidth(280)
        self.search_field.returnPressed.connect(self.perform_search)
        search_row.addWidget(self.search_field, stretch=1)

        search_button = QPushButton("Search", self)
        search_button.setMinimumHeight(32)
        search_button.clicked.connect(self.perform_search)
        search_row.addWidget(search_button)

        show_all_button = QPushButton("Show All", self)
        show_all_button.setMinimumHeight(32)
        show_all_button.clicked.connect(self.show_all_documents)
        search_row.addWidget(show_all_button)

        layout.addLayout(search_row)

        self.result_label = QLabel("Browse documentation", self)
        self.result_label.setObjectName("docStatus")
        layout.addWidget(self.result_label)

        splitter = QSplitter(Qt.Orientation.Horizontal, self)
        splitter.setChildrenCollapsible(False)
        layout.addWidget(splitter, stretch=1)

        self.results = QListWidget(splitter)
        self.results.setAlternatingRowColors(True)
        self.results.setSelectionMode(QListWidget.SelectionMode.SingleSelection)
        self.results.setMinimumWidth(320)
        self.results.itemSelectionChanged.connect(self._on_result_selected)
        self.results.itemActivated.connect(self._on_result_activated)

        self.viewer = QTextBrowser(splitter)
        self.viewer.setOpenExternalLinks(True)
        self.viewer.setStyleSheet(
            """
            QTextBrowser {
                font-size: 15px;
                line-height: 1.7em;
                background: #f8fafc;
                border: 1px solid #cbd5e0;
                border-radius: 14px;
                padding: 22px;
            }
            """
        )
        self.viewer.document().setDefaultStyleSheet(
            """
            body {
                font-family: 'Helvetica Neue', Arial, sans-serif;
                font-size: 15px;
                line-height: 1.7;
                color: #1f2937;
            }
            h1 { font-size: 26px; margin: 0 0 16px; }
            h2 { font-size: 22px; margin: 24px 0 12px; }
            h3 { font-size: 18px; margin: 20px 0 10px; }
            p { margin: 0 0 14px; }
            ul, ol { margin: 0 0 14px 24px; }
            code {
                font-family: 'SFMono-Regular', Menlo, monospace;
                background: #e2e8f0;
                border-radius: 4px;
                padding: 2px 4px;
                font-size: 13px;
            }
            pre {
                background: #e2e8f0;
                border-radius: 10px;
                padding: 14px;
                font-size: 13px;
                margin: 0 0 16px;
            }
            table { border-collapse: collapse; }
            th, td { padding: 6px 10px; }
            .latex-inline { font-style: italic; }
            .latex-block { margin: 18px 0; }
            .latex-cases {
                display: inline-block;
                border-left: 3px solid #1d4ed8;
                padding: 6px 14px;
                background: #eef2ff;
                border-radius: 8px;
            }
            .latex-cases table { border-spacing: 0; }
            .latex-cases td { padding: 4px 8px; vertical-align: top; }
            .latex-operator { font-style: italic; margin-right: 6px; }
            .latex-frac {
                display: inline-flex;
                flex-direction: column;
                align-items: center;
                font-size: 0.95em;
            }
            .latex-frac > .latex-frac-bar {
                display: block;
                width: 100%;
                border-top: 1px solid currentColor;
                margin: 2px 0;
            }
            .latex-frac > span { display: block; }
            """
        )

        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)

        self.show_all_documents()

        if initial_query:
            self.search_field.setText(initial_query)
            self.perform_search()

    # ------------------------------------------------------------------
    def focus_search(self) -> None:
        self.search_field.setFocus()
        self.search_field.selectAll()

    def set_query(self, value: str) -> None:
        self.search_field.setText(value)
        if value:
            self.perform_search()
        else:
            self.show_all_documents()

    def _entry_for_path(self, path_str: str) -> Optional[DocumentationEntry]:
        path = Path(path_str).resolve()
        for entry in self._documents:
            if entry.path.resolve() == path:
                return entry
        return None

    def show_all_documents(self) -> None:
        self.results.clear()
        self._current_query = ""
        for entry in self._documents:
            item = QListWidgetItem(f"{entry.display_name}")
            item.setData(Qt.ItemDataRole.UserRole, (str(entry.path), 0, ""))
            self.results.addItem(item)
        self.result_label.setText("Browse documentation")
        if self._documents:
            self.results.setCurrentRow(0)

    def perform_search(self) -> None:
        query = self.search_field.text().strip()
        self.results.clear()
        if not query:
            self.show_all_documents()
            return

        lowered = query.lower()
        matches: List[Tuple[DocumentationEntry, int, str]] = []
        for entry in self._documents:
            for idx, line in enumerate(entry.lines, start=1):
                if lowered in line.lower():
                    snippet = textwrap.shorten(line.strip(), width=100, placeholder="…")
                    matches.append((entry, idx, snippet))

        if not matches:
            item = QListWidgetItem("No matches found")
            item.setFlags(Qt.ItemFlag.NoItemFlags)
            self.results.addItem(item)
            self.result_label.setText(f"No results for '{query}'.")
            self.viewer.setPlainText("")
            return

        self._current_query = query
        for entry, line_no, snippet in matches:
            display = f"{entry.display_name} — L{line_no}: {snippet}"
            item = QListWidgetItem(display)
            item.setData(Qt.ItemDataRole.UserRole, (str(entry.path), line_no, query))
            self.results.addItem(item)
        self.result_label.setText(f"{len(matches)} match(es) for '{query}'.")
        self.results.setCurrentRow(0)

    def _display_entry(self, entry: DocumentationEntry, *, line_no: int = 0, highlight: str = "") -> None:
        self._current_entry = entry
        document = self.viewer.document()
        if hasattr(document, "setMarkdownFeatures"):
            feature = getattr(QTextDocument.MarkdownFeature, "MarkdownDialectGitHub", None)
            if feature is None:
                feature = getattr(QTextDocument.MarkdownFeature, "MarkdownDialectCommonMark", None)
            if feature is not None:
                document.setMarkdownFeatures(feature)
        if hasattr(document, "setBaseUrl"):
            document.setBaseUrl(QUrl.fromLocalFile(str(entry.path.parent)))
        header = f"**{entry.display_name}**  \n`{entry.relative_path}`\n\n{entry.text}"
        rendered = _inject_latex_images(header)
        if hasattr(self.viewer, "setMarkdown"):
            self.viewer.setMarkdown(rendered)
        else:
            plain = f"{entry.display_name}\n{entry.relative_path}\n\n{entry.text}"
            self.viewer.setPlainText(plain)
        if line_no > 0:
            cursor = self.viewer.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.Start)
            for _ in range(line_no + 2):
                cursor.movePosition(QTextCursor.MoveOperation.Down)
            self.viewer.setTextCursor(cursor)
            self.viewer.ensureCursorVisible()
        if highlight:
            cursor = self.viewer.document().find(
                highlight,
                self.viewer.textCursor(),
                QTextDocument.FindFlag.FindCaseSensitively,
            )
            if cursor.isNull():
                cursor = self.viewer.document().find(
                    highlight,
                    0,
                    QTextDocument.FindFlag.FindCaseSensitively,
                )
            if cursor.isNull():
                cursor = self.viewer.document().find(highlight)
            if not cursor.isNull():
                self.viewer.setTextCursor(cursor)
                self.viewer.ensureCursorVisible()

    def _on_result_selected(self) -> None:
        item = self.results.currentItem()
        if item is None:
            return
        data = item.data(Qt.ItemDataRole.UserRole)
        if not data:
            return
        path_str, line_no, highlight = data
        entry = self._entry_for_path(path_str)
        if entry:
            self._display_entry(entry, line_no=line_no, highlight=highlight)

    def _on_result_activated(self, item: QListWidgetItem) -> None:
        data = item.data(Qt.ItemDataRole.UserRole)
        if not data:
            return
        path_str, line_no, highlight = data
        entry = self._entry_for_path(path_str)
        if entry:
            self._display_entry(entry, line_no=line_no, highlight=highlight)


_LATEX_CACHE: Dict[str, Optional[QPixmap]] = {}

_LATEX_GREEK_HTML = {
    "alpha": "&alpha;",
    "beta": "&beta;",
    "gamma": "&gamma;",
    "delta": "&delta;",
    "epsilon": "&epsilon;",
    "zeta": "&zeta;",
    "eta": "&eta;",
    "theta": "&theta;",
    "iota": "&iota;",
    "kappa": "&kappa;",
    "lambda": "&lambda;",
    "mu": "&mu;",
    "nu": "&nu;",
    "xi": "&xi;",
    "pi": "&pi;",
    "rho": "&rho;",
    "sigma": "&sigma;",
    "tau": "&tau;",
    "upsilon": "&upsilon;",
    "phi": "&phi;",
    "chi": "&chi;",
    "psi": "&psi;",
    "omega": "&omega;",
    "Gamma": "&Gamma;",
    "Delta": "&Delta;",
    "Theta": "&Theta;",
    "Lambda": "&Lambda;",
    "Xi": "&Xi;",
    "Pi": "&Pi;",
    "Sigma": "&Sigma;",
    "Upsilon": "&Upsilon;",
    "Phi": "&Phi;",
    "Psi": "&Psi;",
    "Omega": "&Omega;",
}

_LATEX_SIMPLE_COMMANDS = {
    ",": "&#8239;",  # thin space
    ";": "&ensp;",
    "!": "",
    "\\": "<br/>",
}


def _extract_braced(text: str, start: int) -> Tuple[str, int]:
    depth = 0
    i = start
    assert text[i] == "{"
    i += 1
    begin = i
    while i < len(text):
        char = text[i]
        if char == "{":
            depth += 1
        elif char == "}":
            if depth == 0:
                return text[begin:i], i + 1
            depth -= 1
        i += 1
    return text[begin:], len(text)


def _extract_environment(text: str, start: int, env_name: str) -> Tuple[str, int]:
    end_token = f"\\end{{{env_name}}}"
    begin_token = f"\\begin{{{env_name}}}"
    depth = 1
    i = start
    while i < len(text):
        if text.startswith(begin_token, i):
            depth += 1
            i += len(begin_token)
            continue
        if text.startswith(end_token, i):
            depth -= 1
            if depth == 0:
                return text[start:i], i + len(end_token)
            i += len(end_token)
            continue
        i += 1
    return text[start:], len(text)


def _prepare_latex_for_mathtext(expr: str) -> Tuple[str, bool]:
    requires_html = False
    if "\\begin{cases}" in expr or "\\text{" in expr:
        requires_html = True

    normalized = expr.replace("\\tfrac", "\\frac").replace("\\dfrac", "\\frac")

    for macro in (
        "\\bigl",
        "\\bigr",
        "\\biggl",
        "\\biggr",
        "\\Bigl",
        "\\Bigr",
        "\\Biggl",
        "\\Biggr",
        "\\big",
        "\\Big",
        "\\bigg",
        "\\Bigg",
    ):
        if macro in normalized:
            normalized = normalized.replace(macro, "")

    def _replace_command(command: str, transform: Callable[[str], str]) -> None:
        nonlocal normalized
        search = f"\\{command}"
        index = 0
        while True:
            idx = normalized.find(search, index)
            if idx == -1:
                break
            j = idx + len(search)
            while j < len(normalized) and normalized[j].isspace():
                j += 1
            if j >= len(normalized) or normalized[j] != "{":
                index = j
                continue
            content, new_index = _extract_braced(normalized, j)
            replacement = transform(content)
            normalized = normalized[:idx] + replacement + normalized[new_index:]
            index = idx + len(replacement)

    _replace_command("operatorname", lambda value: f"\\mathrm{{{value}}}")

    return normalized, requires_html


def _cases_environment_to_html(content: str) -> str:
    rows: List[str] = []
    for raw_row in re.split(r"\\\\", content):
        row = raw_row.strip()
        if not row:
            continue
        if "&" in row:
            lhs, rhs = row.split("&", 1)
        else:
            lhs, rhs = row, ""
        lhs_html = _latex_to_html(lhs.strip()) if lhs.strip() else ""
        rhs_html = _latex_to_html(rhs.strip()) if rhs.strip() else ""
        rows.append(
            f"<tr><td class=\"latex-cases-condition\">{lhs_html}</td><td class=\"latex-cases-result\">{rhs_html}</td></tr>"
        )
    if not rows:
        return ""
    body = "".join(rows)
    return f"<div class=\"latex-block latex-cases\"><table>{body}</table></div>"


def _latex_to_html(latex: str) -> str:
    if not latex:
        return ""

    result: List[str] = []
    i = 0
    length = len(latex)

    while i < length:
        char = latex[i]
        if char == "\\":
            if i + 1 >= length:
                break
            next_char = latex[i + 1]
            if next_char.isalpha():
                j = i + 2
                while j < length and latex[j].isalpha():
                    j += 1
                command = latex[i + 1 : j]
                if command in ("left", "right"):
                    i = j
                    continue
                if command in (
                    "operatorname",
                    "text",
                    "mathrm",
                    "mathcal",
                    "mathbf",
                    "mathbin",
                    "texttt",
                ):
                    if j < length and latex[j] == "{":
                        content, new_index = _extract_braced(latex, j)
                        rendered = html.escape(content)
                        if command in {"operatorname", "mathrm", "mathcal", "mathbf", "mathbin"}:
                            rendered = f"<span class=\"latex-operator\">{rendered}</span>"
                        elif command == "texttt":
                            rendered = f"<code>{rendered}</code>"
                        result.append(rendered)
                        i = new_index
                        continue
                if command in ("frac", "tfrac", "dfrac"):
                    if j < length and latex[j] == "{":
                        numerator, new_index = _extract_braced(latex, j)
                        if new_index < length and latex[new_index] == "{":
                            denominator, final_index = _extract_braced(latex, new_index)
                            num_html = _latex_to_html(numerator)
                            den_html = _latex_to_html(denominator)
                            result.append(
                                "<span class=\"latex-frac\"><span>"
                                + num_html
                                + "</span><span class=\"latex-frac-bar\"></span><span>"
                                + den_html
                                + "</span></span>"
                            )
                            i = final_index
                            continue
                if command == "sqrt":
                    if j < length and latex[j] == "{":
                        content, new_index = _extract_braced(latex, j)
                        inner_html = _latex_to_html(content)
                        result.append(f"√({inner_html})")
                        i = new_index
                        continue
                if command == "begin":
                    if j < length and latex[j] == "{":
                        env_name, env_index = _extract_braced(latex, j)
                        if env_name == "cases":
                            env_content, end_index = _extract_environment(latex, env_index, env_name)
                            cases_html = _cases_environment_to_html(env_content)
                            result.append(cases_html)
                            i = end_index
                            continue
                if command == "end":
                    i = j
                    continue
                if command in {
                    "exp",
                    "sin",
                    "cos",
                    "tan",
                    "log",
                    "ln",
                    "min",
                    "max",
                    "sup",
                    "inf",
                    "sum",
                    "int",
                    "approx",
                    "gg",
                    "in",
                    "partial",
                }:
                    symbol_map = {
                        "sum": "&sum;",
                        "int": "&int;",
                        "approx": "&asymp;",
                        "gg": "&gg;",
                        "in": "&isin;",
                        "partial": "&part;",
                    }
                    rendered = symbol_map.get(command, command)
                    result.append(rendered)
                    i = j
                    continue
                if command in {"left", "right", "big", "Big", "bigg", "Bigg", "bigl", "bigr", "biggl", "biggr", "Bigl", "Bigr", "Biggl", "Biggr"}:
                    i = j
                    continue
                if command in {"quad", "qquad"}:
                    result.append("&emsp;")
                    i = j
                    continue
                replacement = _LATEX_GREEK_HTML.get(command)
                if replacement is not None:
                    result.append(replacement)
                elif command == "cdot":
                    result.append("&middot;")
                else:
                    result.append(html.escape("\\" + command))
                i = j
                continue

            mapped = _LATEX_SIMPLE_COMMANDS.get(next_char)
            if mapped is not None:
                result.append(mapped)
                i += 2
                continue
            if next_char == " ":
                result.append("&nbsp;")
                i += 2
                continue
            result.append(html.escape(next_char))
            i += 2
            continue

        if char in "^_":
            tag = "sup" if char == "^" else "sub"
            i += 1
            if i >= length:
                break
            if latex[i] == "{":
                content, new_index = _extract_braced(latex, i)
                inner = _latex_to_html(content)
                result.append(f"<{tag}>{inner}</{tag}>")
                i = new_index
            else:
                inner = _latex_to_html(latex[i])
                result.append(f"<{tag}>{inner}</{tag}>")
                i += 1
            continue

        if char == "{":
            content, new_index = _extract_braced(latex, i)
            result.append(_latex_to_html(content))
            i = new_index
            continue

        if char == "\n":
            result.append("<br/>")
            i += 1
            continue

        result.append(html.escape(char))
        i += 1

    return "".join(result)


def _latex_to_pixmap(latex: str) -> Optional[QPixmap]:
    if not latex:
        return None
    cached = _LATEX_CACHE.get(latex)
    if cached is not None:
        return cached
    normalized, requires_html = _prepare_latex_for_mathtext(latex)
    if requires_html:
        _LATEX_CACHE[latex] = None
        return None
    try:
        buffer = io.BytesIO()
        mathtext.math_to_image(normalized, buffer, dpi=200, format="png")
    except Exception as exc:
        print(f"[warn] Failed to render LaTeX '{latex}': {exc}")
        _LATEX_CACHE[latex] = None
        return None

    data = buffer.getvalue()
    if not data:
        _LATEX_CACHE[latex] = None
        return None

    image = QImage.fromData(data, "PNG")
    if image.isNull():
        _LATEX_CACHE[latex] = None
        return None

    pixmap = QPixmap.fromImage(image)
    _LATEX_CACHE[latex] = pixmap
    return pixmap


def _pixmap_to_data_uri(pixmap: QPixmap) -> Optional[str]:
    if pixmap.isNull():
        return None
    buffer = QBuffer()
    if not buffer.open(QIODevice.OpenModeFlag.WriteOnly):
        return None
    if not pixmap.save(buffer, b"PNG"):
        buffer.close()
        return None
    data = bytes(buffer.data())
    buffer.close()
    encoded = base64.b64encode(data).decode("ascii")
    return f"data:image/png;base64,{encoded}"


_CODE_BLOCK_PATTERN = re.compile(r"```.+?```", re.DOTALL)
_INLINE_CODE_PATTERN = re.compile(r"`[^`\n]+`")
_LATEX_BLOCK_PATTERN = re.compile(r"(?<!\\)\$\$(.+?)(?<!\\)\$\$", re.DOTALL)
_LATEX_INLINE_PATTERN = re.compile(r"(?<!\\)\$(.+?)(?<!\\)\$")


def _render_latex_fragment(latex: str, *, inline: bool) -> str:
    expr = latex.strip()
    if not expr:
        return ""
    pixmap = _latex_to_pixmap(expr)
    if pixmap is not None and not pixmap.isNull():
        data_uri = _pixmap_to_data_uri(pixmap)
        if data_uri:
            style = "vertical-align: middle;" if inline else "display: block; margin: 12px auto;"
            return f"<img src=\"{data_uri}\" style=\"{style}\" alt=\"{html.escape(expr)}\"/>"
    html_text = _latex_to_html(expr)
    if html_text:
        if inline:
            return f"<span class=\"latex-inline\">{html_text}</span>"
        return f"<div class=\"latex-block\" style=\"text-align: center;\">{html_text}</div>"
    return html.escape(expr)


def _inject_latex_images(markdown_text: str) -> str:
    if "$" not in markdown_text:
        return markdown_text

    placeholders: Dict[str, str] = {}
    counter = 0

    def _store_placeholder(match: re.Match) -> str:
        nonlocal counter
        key = f"\ufff0DOCPLACEHOLDER{counter}\uf8ff"
        counter += 1
        placeholders[key] = match.group(0)
        return key

    text = _CODE_BLOCK_PATTERN.sub(_store_placeholder, markdown_text)
    text = _INLINE_CODE_PATTERN.sub(_store_placeholder, text)

    def _replace_block(match: re.Match) -> str:
        fragment = _render_latex_fragment(match.group(1), inline=False)
        return f"\n\n{fragment}\n\n"

    text = _LATEX_BLOCK_PATTERN.sub(_replace_block, text)

    def _replace_inline(match: re.Match) -> str:
        return _render_latex_fragment(match.group(1), inline=True)

    text = _LATEX_INLINE_PATTERN.sub(_replace_inline, text)

    if placeholders:
        pattern = re.compile("|".join(re.escape(key) for key in placeholders))
        text = pattern.sub(lambda m: placeholders[m.group(0)], text)
    return text


def _mass_identifier_from_path(path: str) -> Optional[str]:
    if not path or "/Masses/" not in path:
        return None
    tail = path.split("/Masses/", 1)[-1]
    segment = tail.split("/", 1)[0]
    for suffix in ("FitParameters", "FitParams", "Parameters", "Params"):
        if segment.endswith(suffix):
            segment = segment[: -len(suffix)]
            break
    segment = segment.strip().strip("_-")
    return segment or None


def _dataset_sort_key(channel: str, dataset_path: str) -> Tuple[int, object]:
    mass_label = _mass_identifier_from_path(dataset_path)
    if mass_label is not None:
        try:
            mass_value: object = float(mass_label)
        except ValueError:
            mass_value = mass_label
        return (0, mass_value)
    return (1, os.path.basename(dataset_path))


def _coerce_parameter_values(values: np.ndarray) -> Optional[np.ndarray]:
    try:
        arr = np.asarray(values)
    except Exception:
        return None

    if arr.size == 0:
        return None

    if arr.dtype.names:  # structured array
        for field in ("value", "values", "val"):
            if field in arr.dtype.names:
                arr = np.asarray(arr[field])
                break
        else:
            pieces = []
            for name in arr.dtype.names:
                try:
                    pieces.append(np.asarray(arr[name]).ravel())
                except Exception:
                    return None
            if not pieces:
                return None
            arr = np.concatenate(pieces)
    elif arr.dtype == object:
        coerced: List[float] = []
        for item in arr.ravel():
            if item is None:
                coerced.append(np.nan)
                continue
            if isinstance(item, (float, int, np.floating, np.integer)):
                coerced.append(float(item))
                continue
            if hasattr(item, "value"):
                try:
                    coerced.append(float(item.value))
                    continue
                except Exception:
                    pass
            if isinstance(item, (list, tuple, np.ndarray)):
                sub = np.asarray(item).ravel()
                if sub.size:
                    try:
                        coerced.append(float(sub[0]))
                        continue
                    except Exception:
                        pass
            try:
                coerced.append(float(item))
            except Exception:
                return None
        arr = np.asarray(coerced, dtype=float)
    else:
        arr = np.asarray(arr, dtype=float)

    arr = np.asarray(arr, dtype=float).ravel()
    if arr.size == 0:
        return None
    return arr

def _to_1d(array: np.ndarray) -> np.ndarray:
    arr = np.asarray(array)
    if arr.ndim == 0:
        return arr.reshape(1)
    return arr.ravel()

def _has_samples(array: Optional[np.ndarray]) -> bool:
    """Return ``True`` when *array* contains at least one finite sample."""

    if array is None:
        return False

    try:
        values = np.asarray(array)
    except Exception:
        return False

    if values.size == 0:
        return False

    return bool(np.isfinite(values).any())


@dataclass
class MassAxisContext:
    mass: np.ndarray
    time: np.ndarray
    calibration: Optional[TOFMassCal] = None
    origin: float = 0.0
    stretch: Optional[float] = None
    shift: Optional[float] = None
    _time_sorted: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _mass_for_time: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _mass_sorted: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    _time_for_mass: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        self.mass = np.asarray(self.mass, dtype=float).ravel()
        self.time = np.asarray(self.time, dtype=float).ravel()
        count = min(self.mass.size, self.time.size)
        if count > 0:
            self.mass = self.mass[:count]
            self.time = self.time[:count]
        else:
            self.mass = np.zeros(0, dtype=float)
            self.time = np.zeros(0, dtype=float)
        self.origin = float(self.origin or 0.0)
        if self.stretch is not None:
            self.stretch = float(self.stretch)
        if self.shift is not None:
            self.shift = float(self.shift)
        self._time_sorted = None
        self._mass_for_time = None
        self._mass_sorted = None
        self._time_for_mass = None

    def trimmed(self, count: int) -> "MassAxisContext":
        limit = int(max(0, min(count, self.mass.size, self.time.size)))
        if limit <= 0:
            return MassAxisContext(
                mass=np.zeros(0, dtype=float),
                time=np.zeros(0, dtype=float),
                calibration=self.calibration,
                origin=self.origin,
                stretch=self.stretch,
                shift=self.shift,
            )
        return MassAxisContext(
            mass=self.mass[:limit],
            time=self.time[:limit],
            calibration=self.calibration,
            origin=self.origin,
            stretch=self.stretch,
            shift=self.shift,
        )

    def _ensure_sorted_by_time(self) -> None:
        if self._time_sorted is not None:
            return
        if self.time.size == 0:
            self._time_sorted = np.zeros(0, dtype=float)
            self._mass_for_time = np.zeros(0, dtype=float)
            return
        order = np.argsort(self.time)
        time_sorted = self.time[order]
        mass_sorted = self.mass[order]
        mask = np.isfinite(time_sorted) & np.isfinite(mass_sorted)
        time_sorted = time_sorted[mask]
        mass_sorted = mass_sorted[mask]
        if time_sorted.size >= 2:
            unique_time, indices = np.unique(time_sorted, return_index=True)
            mass_sorted = mass_sorted[indices]
            time_sorted = unique_time
        self._time_sorted = time_sorted
        self._mass_for_time = mass_sorted

    def _ensure_sorted_by_mass(self) -> None:
        if self._mass_sorted is not None:
            return
        if self.mass.size == 0:
            self._mass_sorted = np.zeros(0, dtype=float)
            self._time_for_mass = np.zeros(0, dtype=float)
            return
        order = np.argsort(self.mass)
        mass_sorted = self.mass[order]
        time_sorted = self.time[order]
        mask = np.isfinite(mass_sorted) & np.isfinite(time_sorted)
        mass_sorted = mass_sorted[mask]
        time_sorted = time_sorted[mask]
        if mass_sorted.size >= 2:
            unique_mass, indices = np.unique(mass_sorted, return_index=True)
            time_sorted = time_sorted[indices]
            mass_sorted = unique_mass
        self._mass_sorted = mass_sorted
        self._time_for_mass = time_sorted

    def time_to_mass(self, times: Sequence[float]) -> np.ndarray:
        arr = np.asarray(times, dtype=float)
        if self.calibration is not None:
            offsets = arr - self.origin
            try:
                return np.asarray(self.calibration.tof_to_mass(offsets), dtype=float)
            except Exception:
                pass
        if self.stretch is not None and self.shift is not None and abs(self.stretch) > 1.0e-12:
            return np.asarray(self.stretch * (arr - self.shift), dtype=float)
        self._ensure_sorted_by_time()
        if self._time_sorted is None or self._time_sorted.size == 0:
            return np.zeros_like(arr, dtype=float)
        if self._time_sorted.size == 1:
            return np.full(arr.shape, float(self._mass_for_time[0]), dtype=float)
        return np.interp(
            arr,
            self._time_sorted,
            self._mass_for_time,
            left=self._mass_for_time[0],
            right=self._mass_for_time[-1],
        )

    def mass_to_time(self, masses: Sequence[float]) -> np.ndarray:
        arr = np.asarray(masses, dtype=float)
        if self.calibration is not None:
            try:
                tof = np.asarray(self.calibration.mass_to_tof(arr), dtype=float)
                return tof + self.origin
            except Exception:
                pass
        if self.stretch is not None and self.shift is not None and abs(self.stretch) > 1.0e-12:
            return np.asarray(arr / self.stretch + self.shift, dtype=float)
        self._ensure_sorted_by_mass()
        if self._mass_sorted is None or self._mass_sorted.size == 0:
            return np.zeros_like(arr, dtype=float)
        if self._mass_sorted.size == 1:
            return np.full(arr.shape, float(self._time_for_mass[0]), dtype=float)
        return np.interp(
            arr,
            self._mass_sorted,
            self._time_for_mass,
            left=self._time_for_mass[0],
            right=self._time_for_mass[-1],
        )


def _normalise_attr_value(value: Any) -> Any:
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except Exception:
            return value.decode("latin-1", "ignore")
    if isinstance(value, np.ndarray):
        if value.shape == ():
            return value.item()
        return np.array(value, copy=True)
    if isinstance(value, np.generic):
        return value.item()
    return value


def _coerce_float_attr(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float, np.floating)):
        result = float(value)
    else:
        try:
            arr = np.asarray(value, dtype=float)
        except Exception:
            return None
        if arr.size == 0:
            return None
        result = float(arr.reshape(-1)[0])
    if np.isfinite(result):
        return result
    return None


def _load_mass_calibration_from_attrs(attrs: Dict[str, Any]) -> Optional[TOFMassCal]:
    raw = attrs.get("MassCalibration")
    if raw is None:
        return None
    candidate: Any = raw
    if isinstance(candidate, bytes):
        try:
            candidate = candidate.decode("utf-8")
        except Exception:
            candidate = candidate.decode("latin-1", "ignore")
    elif isinstance(candidate, np.ndarray):
        if candidate.shape == ():
            candidate = candidate.item()
        else:
            try:
                candidate = candidate.tobytes().decode("utf-8")
            except Exception:
                candidate = candidate.tolist()
    elif isinstance(candidate, np.generic):
        candidate = candidate.item()
    if isinstance(candidate, str):
        try:
            data = json.loads(candidate)
        except Exception:
            return None
        try:
            return TOFMassCal.from_dict(data)
        except Exception:
            return None
    if isinstance(candidate, dict):
        try:
            return TOFMassCal.from_dict(candidate)
        except Exception:
            return None
    return None


def _gather_mass_attributes(data_source: "BaseDataSource", event: str) -> Dict[str, Any]:
    for group_path in MASS_ATTRIBUTE_GROUPS:
        attrs = data_source.get_group_attributes(event, group_path)
        if not attrs:
            continue
        if any(
            key in attrs
            for key in ("MassStretch", "MassShift", "MassCalibration", "MassCalibrationOrigin")
        ):
            return attrs
    return {}

# --------- Channel & fit metadata ---------
FAMILY_HIGH = "high"
FAMILY_LOW = "low"


@dataclass(frozen=True)
class ChannelDefinition:
    dataset: str
    time_dataset: str
    family: str


CHANNEL_DEFS: Dict[str, ChannelDefinition] = {
    "TOF L": ChannelDefinition(dataset="TOF L", time_dataset="Time (high sampling)", family=FAMILY_HIGH),
    "TOF M": ChannelDefinition(dataset="TOF M", time_dataset="Time (high sampling)", family=FAMILY_HIGH),
    "TOF H": ChannelDefinition(dataset="TOF H", time_dataset="Time (high sampling)", family=FAMILY_HIGH),
    "TOF Combined": ChannelDefinition(
        dataset="Analysis/DustComposition/CombinedSignal",
        time_dataset="Analysis/DustComposition/CombinedTime",
        family=FAMILY_HIGH,
    ),
    "Ion Grid": ChannelDefinition(dataset="Ion Grid", time_dataset="Time (low sampling)", family=FAMILY_LOW),
    "Target L": ChannelDefinition(dataset="Target L", time_dataset="Time (low sampling)", family=FAMILY_LOW),
    "Target H": ChannelDefinition(dataset="Target H", time_dataset="Time (low sampling)", family=FAMILY_LOW),
}

CHANNEL_ORDER: List[str] = ["TOF L", "TOF M", "TOF H", "TOF Combined", "Ion Grid", "Target L", "Target H"]

FIT_ELIGIBLE_CHANNELS = {"Ion Grid", "Target L", "Target H", "TOF H"}

RISE_METRIC_CHANNELS = {"Ion Grid", "Target L", "Target H"}

BASELINE_PRIMARY_WINDOW = (-7.0, -5.0)
BASELINE_FALLBACK_THRESHOLD = -2.0

FAMILY_YLABELS = {
    FAMILY_HIGH: r"$TOF$ [pC/ $\Delta t$]",
    FAMILY_LOW: r"$Q$ [pC]",
}

FAMILY_UNITS = {
    FAMILY_HIGH: "pC/Δt",
    FAMILY_LOW: "pC",
}

TIME_AXIS_LABEL = r"Time [$\mu$s]"
MASS_AXIS_LABEL = "Mass [amu]"
MASS_ATTRIBUTE_GROUPS: Tuple[str, ...] = (
    "Analysis/DustComposition",
    "Analysis/TOF H",
    "Analysis/TOF M",
    "Analysis/TOF L",
)


# Instrument-specific conversion factors. Raw waveform counts are divided by the
# matching factor before plotting so that the quicklook display is reported in
# engineering units.
CHANNEL_CONVERSION_FACTORS: Dict[str, float] = {
    "TOF H": 2.89e-4,
    "TOF M": 1.13e-2,
    "TOF L": 5.14e-4,
    "Ion Grid": 7.46e-4,
    "Target H": 1.63e-1,
    "Target L": 1.58e1,
}


@dataclass(frozen=True)
class FitModelMeta:
    parameter_labels: Tuple[str, ...]
    latex: str
    evaluator: Callable[..., np.ndarray]


ION_GRID_PARAMETER_LABELS_FULL: Tuple[str, ...] = (
    "t0 (impact onset)",
    "C0 (baseline)",
    "C1 (image amplitude)",
    "C2 (impact amplitude)",
    "τ0 (image decay)",
    "τ1 (impact rise)",
    "τ2 (impact decay)",
)

ION_GRID_PARAMETER_LABELS_LEGACY: Tuple[str, ...] = (
    "t0 (impact onset)",
    "C0 (baseline)",
    "C2 (impact amplitude)",
    "τ1 (impact rise)",
    "τ2 (impact decay)",
)

ION_GRID_LABEL_OVERRIDES: Dict[int, Tuple[str, ...]] = {
    len(ION_GRID_PARAMETER_LABELS_LEGACY): ION_GRID_PARAMETER_LABELS_LEGACY,
}


def _idex_ion_grid_model(x: np.ndarray, *params: float) -> np.ndarray:
    """Evaluate the standard IDEX ion grid / target response model."""

    arr = np.asarray(x, dtype=float)
    if arr.size == 0:
        return arr

    if len(params) >= 7:
        t0, c0, c1, c2, tau0, tau1, tau2 = params[:7]
        shift = arr - t0
        step = np.heaviside(shift, 0.0)
        safe_tau0 = tau0 if abs(tau0) > 1.0e-12 else 1.0e-12
        safe_tau1 = tau1 if abs(tau1) > 1.0e-12 else 1.0e-12
        safe_tau2 = tau2 if abs(tau2) > 1.0e-12 else 1.0e-12
        with np.errstate(over="ignore", under="ignore", divide="ignore", invalid="ignore"):
            image_decay = np.exp(-shift / safe_tau0)
            rise = 1.0 - np.exp(-shift / safe_tau1)
            decay = np.exp(-shift / safe_tau2)
        return c0 + step * (-c1 * image_decay + c2 * rise * decay - c1)

    if len(params) >= 5:
        p0, p1, p4, p5, p6 = params[:5]
        shift = arr - p0
        step = np.heaviside(shift, 0.0)
        safe_p5 = p5 if abs(p5) > 1.0e-12 else 1.0e-12
        safe_p6 = p6 if abs(p6) > 1.0e-12 else 1.0e-12
        with np.errstate(over="ignore", under="ignore", divide="ignore", invalid="ignore"):
            rise = 1.0 - np.exp(-shift / safe_p5)
            decay = np.exp(-shift / safe_p6)
        return p1 + step * (p4 * rise * decay)

    if len(params) >= 1:
        baseline = params[1] if len(params) > 1 else params[0]
        return np.full_like(arr, float(baseline), dtype=float)

    return np.zeros_like(arr, dtype=float)


def _emg_model(x: np.ndarray, mu: float, sigma: float, lam: float) -> np.ndarray:
    arr = np.asarray(x, dtype=float)
    if arr.size == 0:
        return arr
    if abs(lam) < 1.0e-15:
        return np.zeros_like(arr, dtype=float)
    safe_sigma = sigma if abs(sigma) > 1.0e-15 else 1.0e-15
    safe_lambda = lam
    with np.errstate(over="ignore", under="ignore", divide="ignore", invalid="ignore"):
        exponent = np.exp((safe_lambda / 2.0) * (2.0 * mu + safe_lambda * safe_sigma**2 - 2.0 * arr))
    argument = (mu + safe_lambda * safe_sigma**2 - arr) / (np.sqrt(2.0) * safe_sigma)
    return (safe_lambda / 2.0) * exponent * _erfc(argument)


ION_GRID_FIT = FitModelMeta(
    parameter_labels=ION_GRID_PARAMETER_LABELS_FULL,
    latex=(
        r"w(t; t_0, C_0, C_1, C_2, \tau_0, \tau_1, \tau_2) = C_0"
        r" - H(t - t_0)\,C_1\,e^{-(t - t_0)/\tau_0}"
        r" + H(t - t_0)\left[C_2\left(1 - e^{-(t - t_0)/\tau_1}\right)e^{-(t - t_0)/\tau_2} - C_1\right]"
    ),
    evaluator=_idex_ion_grid_model,
)

EMG_FIT = FitModelMeta(
    parameter_labels=(
        "μ (location)",
        "σ (width)",
        "λ (decay)",
    ),
    latex=(
        r"f(t) = \frac{\lambda}{2} \exp\left[\frac{\lambda}{2}(2\mu + \lambda\sigma^2 - 2t)\right]"
        r" \mathrm{erfc}\left(\frac{\mu + \lambda\sigma^2 - t}{\sqrt{2}\,\sigma}\right)"
    ),
    evaluator=_emg_model,
)

FIT_MODEL_BY_CHANNEL: Dict[str, FitModelMeta] = {
    "Ion Grid": ION_GRID_FIT,
    "Target L": ION_GRID_FIT,
    "Target H": ION_GRID_FIT,
    "TOF H": EMG_FIT,
}


def _evaluate_fit_curve(channel: str, time_values: np.ndarray, params: np.ndarray) -> Optional[np.ndarray]:
    """Evaluate a fit curve for the supplied channel using the stored parameters."""

    model = FIT_MODEL_BY_CHANNEL.get(channel)
    if not model:
        return None

    param_array = _coerce_parameter_values(params)
    if param_array is None:
        return None

    allowed_lengths = {len(model.parameter_labels)}
    if model is ION_GRID_FIT:
        allowed_lengths.update(ION_GRID_LABEL_OVERRIDES.keys())

    first: Optional[np.ndarray] = None
    for length in sorted(allowed_lengths, reverse=True):
        if param_array.size >= length:
            first = np.asarray(param_array[:length], dtype=float)
            break

    if first is None:
        return None

    if not np.all(np.isfinite(first)):
        return None

    try:
        return model.evaluator(time_values, *first)
    except Exception:
        return None


def _masked_mean(values: np.ndarray, mask: np.ndarray) -> Optional[float]:
    values = np.asarray(values)
    mask = np.asarray(mask, dtype=bool)
    if values.size == 0 or mask.size != values.size:
        return None
    if not np.any(mask):
        return None
    subset = values[mask]
    subset = subset[np.isfinite(subset)]
    if subset.size == 0:
        return None
    return float(subset.mean())


def _fit_paths_from_param(dataset_path: str) -> Optional[Tuple[str, str]]:
    """Return the fit result/time dataset paths corresponding to a parameter dataset."""

    if not dataset_path:
        return None

    for needle in ("FitParams", "FitParameters", "FitParam"):
        if needle in dataset_path:
            result_path = dataset_path.replace(needle, "FitResult")
            time_path = dataset_path.replace(needle, "FitTime")
            return result_path, time_path

    return None


@dataclass
class FitData:
    time_series: Dict[str, np.ndarray] = field(default_factory=dict)
    value_series: Dict[str, np.ndarray] = field(default_factory=dict)
    parameter_series: Dict[str, np.ndarray] = field(default_factory=dict)
    extras: Dict[str, np.ndarray] = field(default_factory=dict)

    def has_overlay(self) -> bool:
        if any(True for _ in self.iter_time_result_pairs()):
            return True
        return bool(self.parameter_series)

    def has_parameters(self) -> bool:
        return bool(self.parameter_series)

    def iter_time_result_pairs(self) -> Iterable[Tuple[str, str, str, np.ndarray, np.ndarray]]:
        seen_keys = set()
        for time_path, time_values in self.time_series.items():
            pair_key = _pair_key(time_path)
            if not pair_key:
                continue
            for value_path, value_values in self.value_series.items():
                if _pair_key(value_path) != pair_key:
                    continue
                dedupe_key = (time_path, value_path)
                if dedupe_key in seen_keys:
                    continue
                seen_keys.add(dedupe_key)
                yield (
                    _friendly_label(value_path),
                    time_path,
                    value_path,
                    _to_1d(time_values),
                    _to_1d(value_values),
                )

    def iter_parameter_items(self) -> Iterable[Tuple[str, np.ndarray]]:
        for path, values in self.parameter_series.items():
            yield path, np.asarray(values)


class BaseDataSource(ABC):
    """Abstract data provider used by the quicklook controller."""

    def __init__(self, filename: str):
        self.filename = filename

    # ------------------------------------------------------------------
    # Lifecycle helpers
    # ------------------------------------------------------------------
    def close(self) -> None:
        """Close any open resources (default: no-op)."""

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------
    @abstractmethod
    def list_events(self) -> List[str]:
        """Return the ordered list of events contained in the file."""

    @abstractmethod
    def get_dataset(self, event: str, dataset_name: str) -> Optional[np.ndarray]:
        """Return the dataset for ``/{event}/{dataset_name}`` or ``None``."""

    @abstractmethod
    def gather_fit_data(self, event: str, channel: str) -> FitData:
        """Collect fit products for ``channel`` within ``event``."""

    def get_group_attributes(self, event: str, group_path: str) -> Dict[str, Any]:
        """Return attribute mapping for ``/{event}/{group_path}`` (default: empty)."""

        return {}

    def describe(self) -> str:
        return os.path.basename(self.filename)

    def supports_structure_viewer(self) -> bool:
        return False

    def launch_structure_viewer(self, parent: QWidget | None = None) -> QWidget:
        raise NotImplementedError("Structure viewer not implemented for this source")


class HDF5DataSource(BaseDataSource):
    """Adapter that exposes an HDF5 file via the quicklook datasource API."""

    def __init__(self, filename: str):
        if h5py is None:  # pragma: no cover - handled in runtime environment
            raise ImportError("h5py is required to open HDF5 files but is not installed.")
        super().__init__(filename)
        self._file = h5py.File(filename, "r")

    def close(self) -> None:
        try:
            self._file.close()
        except Exception:
            pass

    def list_events(self) -> List[str]:
        events: List[str] = []
        for key, value in self._file.items():
            if isinstance(value, h5py.Group):
                events.append(str(key))
        try:
            return sorted(events, key=lambda token: int(str(token)))
        except Exception:
            return sorted(events)

    def get_dataset(self, event: str, dataset_name: str) -> Optional[np.ndarray]:
        path = f"/{event}/{dataset_name}"
        try:
            obj = self._file[path]
        except Exception:
            return None
        if isinstance(obj, h5py.Dataset):
            try:
                return np.array(obj[()], copy=True)
            except Exception:
                return None
        return None

    def get_group_attributes(self, event: str, group_path: str) -> Dict[str, Any]:
        cleaned = group_path.strip("/")
        if not cleaned:
            return {}
        path = f"/{event}/{cleaned}"
        try:
            obj = self._file[path]
        except Exception:
            return {}
        if not isinstance(obj, h5py.Group):
            return {}
        result: Dict[str, Any] = {}
        for key, value in obj.attrs.items():
            result[key] = _normalise_attr_value(value)
        return result

    def gather_fit_data(self, event: str, channel: str) -> FitData:
        data = FitData()
        group = self._file.get(event)
        if not isinstance(group, h5py.Group):
            return data

        base_norm = _normalize_name(channel)

        def visitor(name: str, obj):
            if not isinstance(obj, h5py.Dataset):
                return
            dataset_name = name.split("/")[-1]
            norm = _normalize_name(dataset_name)
            if "fit" not in norm or base_norm not in norm:
                return
            try:
                arr = np.array(obj[()], copy=True)
            except Exception:
                return
            full_path = f"{group.name}/{name}"
            if "time" in norm:
                data.time_series[full_path] = arr
            elif "result" in norm or "curve" in norm:
                data.value_series[full_path] = arr
            elif "param" in norm:
                data.parameter_series[full_path] = arr
            else:
                data.extras[full_path] = arr

        group.visititems(visitor)
        return data

    def supports_structure_viewer(self) -> bool:
        return True

    def launch_structure_viewer(self, parent: QWidget | None = None) -> QWidget:
        if launch_hdf_viewer is None:
            raise RuntimeError("HDF viewer is unavailable in this environment.")
        return launch_hdf_viewer(self.filename, parent=parent)


class CDFDataSource(BaseDataSource):
    """Adapter around ``cdflib`` to serve CDF content to the viewer."""

    #: Mapping from quicklook dataset names to CDF variable identifiers.
    DATASET_MAP: Dict[str, str] = {
        "Time (high sampling)": "time_high_sample_rate",
        "Time (low sampling)": "time_low_sample_rate",
        "TOF L": "tof_low",
        "TOF M": "tof_mid",
        "TOF H": "tof_high",
        "Ion Grid": "ion_grid",
        "Target L": "target_low",
        "Target H": "target_high",
    }

    SHARED_DATASETS = {"Time (high sampling)", "Time (low sampling)"}

    #: Mapping from analysis dataset names (under ``/event/Analysis``) to the
    #: underlying CDF variable and extraction mode.
    #: ``mode`` indicates how the data should be returned:
    #: ``"direct"`` slices the record, while ``"time_low"`` and ``"time_high"``
    #: reuse the shared sampling axes.
    ANALYSIS_DATASET_MAP: Dict[str, Tuple[str, str]] = {
        # Ion Grid derived products
        "Ion Grid Fit Result": ("ion_grid_fit_results", "direct"),
        "Ion Grid Fit Parameters": ("ion_grid_fit_parameters", "direct"),
        "Ion Grid Fit Time": ("time_low_sample_rate", "time_low"),
        "Ion Grid Impact Charge": ("ion_grid_impact_charge", "direct"),
        "Ion Grid Velocity Estimate": ("ion_grid_velocity_estimate", "direct"),
        "Ion Grid Dust Mass Estimate": ("ion_grid_dust_mass_estimate", "direct"),
        "Ion Grid Chi Squared": ("ion_grid_chi_squared", "direct"),
        "Ion Grid Reduced Chi Squared": ("ion_grid_reduced_chi_squared", "direct"),
        # Target low-rate products
        "Target L Fit Result": ("target_low_fit_results", "direct"),
        "Target L Fit Parameters": ("target_low_fit_parameters", "direct"),
        "Target L Fit Time": ("time_low_sample_rate", "time_low"),
        "Target L Impact Charge": ("target_low_impact_charge", "direct"),
        "Target L Velocity Estimate": ("target_low_velocity_estimate", "direct"),
        "Target L Dust Mass Estimate": ("target_low_dust_mass_estimate", "direct"),
        "Target L Chi Squared": ("target_low_chi_squared", "direct"),
        "Target L Reduced Chi Squared": ("target_low_reduced_chi_squared", "direct"),
        # Target high-rate products
        "Target H Fit Result": ("target_high_fit_results", "direct"),
        "Target H Fit Parameters": ("target_high_fit_parameters", "direct"),
        "Target H Fit Time": ("time_low_sample_rate", "time_low"),
        "Target H Impact Charge": ("target_high_impact_charge", "direct"),
        "Target H Velocity Estimate": ("target_high_velocity_estimate", "direct"),
        "Target H Dust Mass Estimate": ("target_high_dust_mass_estimate", "direct"),
        "Target H Chi Squared": ("target_high_chi_squared", "direct"),
        "Target H Reduced Chi Squared": ("target_high_reduced_chi_squared", "direct"),
        # TOF peak products
        "TOF H Fit Parameters": ("tof_peak_fit_parameters", "direct"),
        "TOF H Fit Time": ("time_high_sample_rate", "time_high"),
        "TOF H Peak Area": ("tof_peak_area_under_fit", "direct"),
        "TOF H Peak Chi Squared": ("tof_peak_chi_square", "direct"),
        "TOF H Peak Reduced Chi Squared": ("tof_peak_reduced_chi_square", "direct"),
        "TOF H Peak Kappa": ("tof_peak_kappa", "direct"),
        "TOF H SNR": ("tof_snr", "direct"),
    }

    #: Fit metadata required for quicklook overlays.
    FIT_VARIABLES: Dict[str, Dict[str, str]] = {
        "Ion Grid": {
            "result": "ion_grid_fit_results",
            "params": "ion_grid_fit_parameters",
        },
        "Target L": {
            "result": "target_low_fit_results",
            "params": "target_low_fit_parameters",
        },
        "Target H": {
            "result": "target_high_fit_results",
            "params": "target_high_fit_parameters",
        },
        "TOF H": {
            "params": "tof_peak_fit_parameters",
        },
    }

    def __init__(self, filename: str):
        try:
            import cdflib  # type: ignore
        except Exception as exc:  # pragma: no cover - dependency not installed
            raise ImportError(
                "cdflib is required to open CDF files but is not installed."
            ) from exc

        super().__init__(filename)
        self._cdflib = cdflib
        self._cdf = cdflib.CDF(filename)
        self._cache: Dict[str, np.ndarray] = {}
        self._event_count = self._resolve_event_count()
        self._epoch_seconds: Optional[np.ndarray] = self._resolve_epoch_seconds()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def close(self) -> None:
        try:
            self._cdf.close()
        except Exception:
            pass

    def _resolve_event_count(self) -> int:
        try:
            epoch = self._cdf.varget("epoch")
            return int(np.asarray(epoch).shape[0])
        except Exception:
            # Fallback: inspect a known waveform variable.
            for varname in ("tof_low", "tof_mid", "ion_grid"):
                try:
                    candidate = self._cdf.varget(varname)
                    return int(np.asarray(candidate).shape[0])
                except Exception:
                    continue
        return 0

    def _event_index(self, event: str) -> int:
        try:
            return max(0, int(str(event)) - 1)
        except Exception:
            return 0

    @lru_cache(maxsize=None)
    def _cached_variable(self, varname: str) -> np.ndarray:
        try:
            return np.asarray(self._cdf.varget(varname))
        except Exception:
            return np.asarray([])

    def _resolve_epoch_seconds(self) -> Optional[np.ndarray]:
        try:
            raw = self._cdf.varget("epoch")
        except Exception:
            return None

        arr = np.asarray(raw)
        if arr.size == 0:
            return None

        converter = getattr(self._cdflib, "cdfepoch", None)
        if converter is not None:
            try:
                dt_list = converter.to_datetime(arr)
            except Exception:
                dt_list = None
            if dt_list:
                try:
                    seconds = []
                    for dt in dt_list:
                        if dt.tzinfo is None:
                            dt = dt.replace(tzinfo=timezone.utc)
                        seconds.append(float(datetime.timestamp(dt)))
                    return np.asarray(seconds, dtype=float)
                except Exception:
                    pass

        with np.errstate(all="ignore"):
            coerced = np.asarray(arr, dtype=float)
        if coerced.size == 0:
            return None
        return coerced.astype(float, copy=False)

    def _analysis_dataset_names(self) -> List[str]:
        return list(self.ANALYSIS_DATASET_MAP.keys())

    def _analysis_dataset(self, event: str, name: str) -> Optional[np.ndarray]:
        mapping = self.ANALYSIS_DATASET_MAP.get(name)
        if not mapping:
            return None

        varname, mode = mapping
        if mode == "time_low":
            data = self._cached_variable("time_low_sample_rate")
        elif mode == "time_high":
            data = self._cached_variable("time_high_sample_rate")
        else:
            data = self._cached_variable(varname)

        if data.size == 0:
            return None

        index = self._event_index(event)
        if data.ndim == 1:
            if mode in {"time_low", "time_high"}:
                return np.array(data, copy=True)
            if index >= data.shape[0]:
                return None
            return np.array(data[index], copy=True)

        if index >= data.shape[0]:
            return None

        try:
            slice_data = data[index]
        except Exception:
            return None

        return np.array(slice_data, copy=True)

    def list_events(self) -> List[str]:
        return [str(idx + 1) for idx in range(self._event_count)]

    def get_dataset(self, event: str, dataset_name: str) -> Optional[np.ndarray]:
        varname = self.DATASET_MAP.get(dataset_name)
        if not varname:
            if dataset_name.startswith("Analysis/"):
                analysis_name = dataset_name.split("/", 1)[1]
                return self._analysis_dataset(event, analysis_name)
            return None
        data = self._cached_variable(varname)
        if data.size == 0:
            return None
        index = self._event_index(event)
        if data.ndim == 1:
            if dataset_name in self.SHARED_DATASETS:
                return np.array(data, copy=True)
            if index >= data.shape[0]:
                return None
            return np.array(data[index], copy=True)
        if index >= data.shape[0]:
            return None
        try:
            slice_data = data[index]
        except Exception:
            return None
        return np.array(slice_data, copy=True)

    def iter_analysis_datasets(self, event: str) -> Dict[str, np.ndarray]:
        datasets: Dict[str, np.ndarray] = {}
        for name in self._analysis_dataset_names():
            arr = self._analysis_dataset(event, name)
            if arr is None:
                continue
            if arr.size == 0:
                continue
            datasets[name] = arr
        return datasets

    def get_epoch_seconds(self, event: str) -> Optional[float]:
        if self._epoch_seconds is None:
            return None
        index = self._event_index(event)
        if index < 0 or index >= self._epoch_seconds.shape[0]:
            return None
        try:
            value = float(self._epoch_seconds[index])
        except Exception:
            return None
        return value if np.isfinite(value) else None

    def gather_fit_data(self, event: str, channel: str) -> FitData:
        data = FitData()
        mapping = self.FIT_VARIABLES.get(channel)
        if not mapping:
            return data

        index = self._event_index(event)
        event_prefix = f"/{event}/Analysis"

        # Time bases reuse the shared sampling axes.
        if channel in ("Ion Grid", "Target L", "Target H"):
            time_name = "Time (low sampling)"
        else:
            time_name = "Time (high sampling)"

        base_time = self.get_dataset(event, time_name)
        if base_time is not None:
            time_key = f"{event_prefix}/{channel} Fit Time"
            data.time_series[time_key] = np.array(base_time, copy=True)

        result_var = mapping.get("result")
        if result_var:
            result_data = self._cached_variable(result_var)
            if result_data.size and index < result_data.shape[0]:
                result_key = f"{event_prefix}/{channel} Fit Result"
                data.value_series[result_key] = np.array(result_data[index], copy=True)

        params_var = mapping.get("params")
        if params_var:
            params_data = self._cached_variable(params_var)
            if params_data.size and index < params_data.shape[0]:
                params_key = f"{event_prefix}/{channel} Fit Parameters"
                data.parameter_series[params_key] = np.array(params_data[index], copy=True)

        return data

    def supports_structure_viewer(self) -> bool:
        return launch_cdf_viewer is not None

    def launch_structure_viewer(self, parent: QWidget | None = None) -> QWidget:
        if launch_cdf_viewer is None:
            raise RuntimeError("CDF viewer is not available. Install optional GUI components.")
        return launch_cdf_viewer(self.filename, parent=parent)


def create_data_source(filename: str) -> BaseDataSource:
    """Instantiate the appropriate data source for ``filename``."""

    suffix = Path(filename).suffix.lower()
    if suffix in {".h5", ".hdf5"}:
        return HDF5DataSource(filename)
    if suffix == ".cdf":
        return CDFDataSource(filename)

    # Fallback: attempt HDF5 first, then CDF.
    try:
        return HDF5DataSource(filename)
    except Exception:
        return CDFDataSource(filename)


# --------- SQL matching helpers ---------
SQL_DB_URI = os.environ.get(
    "IDEX_SQL_URI",
    "mysql+pymysql://admin:1jlwbXqCVkNdt91KCijx@impactlab.cbhrpdddmhcs.us-east-1.rds.amazonaws.com/impactdb",
)

_SQL_ENGINE = None


def _get_sql_engine():
    global _SQL_ENGINE
    if _SQL_ENGINE is None:
        _SQL_ENGINE = create_engine(
            SQL_DB_URI,
            poolclass=QueuePool,
            pool_size=5,
            max_overflow=10,
        )
    return _SQL_ENGINE


def _parse_iso_datetime(value: str) -> Optional[float]:
    stripped = value.strip()
    if not stripped:
        return None
    if stripped.endswith("Z"):
        stripped = f"{stripped[:-1]}+00:00"
    try:
        dt_value = datetime.fromisoformat(stripped)
    except ValueError:
        return None
    if dt_value.tzinfo is None:
        dt_value = dt_value.replace(tzinfo=timezone.utc)
    else:
        dt_value = dt_value.astimezone(timezone.utc)
    return dt_value.timestamp()


def _coerce_epoch_value(value: Any) -> Optional[float]:
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, (bytes, bytearray)):
        try:
            value = value.decode("utf-8", errors="ignore")
        except Exception:
            return None
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        try:
            numeric = float(stripped)
        except ValueError:
            numeric = _parse_iso_datetime(stripped)
            if numeric is None:
                return None
    else:
        try:
            numeric = float(value)
        except (TypeError, ValueError, OverflowError):
            return None
    if not np.isfinite(numeric):
        return None
    return float(numeric)


def _first_finite_scalar(values: Any) -> Optional[float]:
    if values is None:
        return None

    try:
        arr = np.asarray(values, dtype=float)
    except Exception:
        try:
            arr = np.asarray(values)
        except Exception:
            return None
        arr = arr.ravel()
        for item in arr:
            candidate = _coerce_epoch_value(item)
            if candidate is not None:
                return candidate
        return None

    arr = np.asarray(arr, dtype=float).ravel()
    if arr.size == 0:
        return None

    for value in arr:
        if np.isfinite(value):
            return float(value)
    return None


def _get_dataset_scalar(data_source: BaseDataSource, event: str, dataset: str) -> Optional[float]:
    try:
        data = data_source.get_dataset(event, dataset)
    except Exception:
        return None
    return _first_finite_scalar(data)


_EVENT_TIME_DATASETS: List[Tuple[str, str]] = [
    ("Metadata/IntegerTimestamp", "milliseconds"),
    ("Metadata/Timestamp", "seconds"),
    ("Metadata/Epoch", "seconds"),
    ("Metadata/EventEpoch", "seconds"),
    ("Analysis/Accelerator Timestamp", "milliseconds"),
    ("Analysis/AcceleratorTimestamp", "milliseconds"),
    ("Analysis/Trigger Time (ms)", "milliseconds"),
    ("Analysis/Trigger Time", "seconds"),
    ("Analysis/TriggerTime", "seconds"),
    ("Analysis/TriggerTimeMs", "milliseconds"),
    ("Analysis/QD Trigger (ms)", "milliseconds"),
    ("Analysis/QD Trigger", "seconds"),
    ("Analysis/QD Trigger Time", "seconds"),
    ("Metadata/Trigger Time (ms)", "milliseconds"),
    ("Metadata/TriggerTime", "milliseconds"),
]

_EVENT_VELOCITY_DATASETS: List[Tuple[str, str]] = [
    ("Analysis/Particle Velocity (kmps, QD Fit)", "kmps"),
    ("Analysis/Particle Velocity (kmps, Accelerator)", "kmps"),
    ("Analysis/QD Velocity (km/s)", "kmps"),
    ("Analysis/QD Velocity Estimate", "kmps"),
    ("Analysis/QD Velocity", "kmps"),
    ("Analysis/QD Velocity (m/s)", "mps"),
    ("Analysis/QDFitVelocity", "kmps"),
    ("Analysis/Accelerator Velocity", "kmps"),
    ("Analysis/Ion Grid Velocity Estimate", "kmps"),
    ("Analysis/Target H Velocity Estimate", "kmps"),
    ("Analysis/Target L Velocity Estimate", "kmps"),
]


def _guess_event_timestamp_ms(data_source: BaseDataSource, event: str) -> Optional[float]:
    getter = getattr(data_source, "get_epoch_seconds", None)
    if callable(getter):
        try:
            epoch_seconds = getter(event)
        except Exception:
            epoch_seconds = None
        if epoch_seconds is not None:
            try:
                return float(epoch_seconds) * 1000.0
            except Exception:
                pass

    for dataset, unit in _EVENT_TIME_DATASETS:
        value = _get_dataset_scalar(data_source, event, dataset)
        if value is None:
            continue
        if unit == "milliseconds":
            return float(value)
        if unit == "seconds":
            return float(value) * 1000.0
        if unit == "microseconds":
            return float(value) / 1000.0

    return None


def _guess_event_velocity_kmps(data_source: BaseDataSource, event: str) -> Optional[float]:
    for dataset, unit in _EVENT_VELOCITY_DATASETS:
        value = _get_dataset_scalar(data_source, event, dataset)
        if value is None:
            continue
        if unit == "kmps":
            return float(value)
        if unit == "mps":
            return float(value) / 1000.0
    return None


def _timestamp_to_iso(ms: Optional[float]) -> str:
    if ms is None or not np.isfinite(ms):
        return "Unavailable"
    try:
        dt = datetime.fromtimestamp(float(ms) / 1000.0, tz=timezone.utc)
    except Exception:
        return f"{ms:.0f} ms"
    return dt.isoformat()


def _format_delta_ms(delta_ms: Optional[float]) -> str:
    if delta_ms is None or not np.isfinite(delta_ms):
        return "–"
    if abs(delta_ms) < 1e-3:
        return "0 ms"
    sign = "-" if delta_ms < 0 else "+"
    delta = timedelta(milliseconds=abs(delta_ms))
    total_seconds = delta.total_seconds()
    if total_seconds >= 3600:
        hours = total_seconds / 3600.0
        return f"{sign}{hours:.2f} h"
    if total_seconds >= 60:
        minutes = total_seconds / 60.0
        return f"{sign}{minutes:.2f} min"
    if total_seconds >= 1:
        return f"{sign}{total_seconds:.2f} s"
    return f"{sign}{abs(delta_ms):.0f} ms"


def _format_float(value: Optional[float], precision: int = 3) -> str:
    if value is None or not np.isfinite(value):
        return "–"
    if abs(value) >= 1e3 or (abs(value) > 0 and abs(value) < 1e-3):
        return f"{value:.{precision}e}"
    return f"{value:.{precision}f}"


def _format_mass(value: Optional[float]) -> str:
    return _format_float(value, precision=3)


def _format_charge(value: Optional[float]) -> str:
    return _format_float(value, precision=3)


DEFAULT_RESULT_LIMIT = 5


@dataclass
class SQLMatchCriteria:
    time_ms: Optional[float] = None
    time_window_ms: float = 2000.0
    velocity_kmps: Optional[float] = None
    velocity_tolerance_kmps: float = 0.2
    min_quality: Optional[int] = 0
    limit: Optional[int] = None
    extra_filter: str = ""
    restrict_time: bool = False
    restrict_velocity: bool = False

    def effective_limit(self) -> int:
        if self.limit is None:
            return DEFAULT_RESULT_LIMIT
        try:
            value = int(self.limit)
        except (TypeError, ValueError):
            return DEFAULT_RESULT_LIMIT
        return max(1, value)


@dataclass
class SQLMatchResult:
    record_id: Optional[int]
    estimate_quality: Optional[float]
    timestamp_ms: Optional[float]
    velocity_mps: Optional[float]
    mass_kg: Optional[float]
    charge_c: Optional[float]
    radius_m: Optional[float]
    experiment_settings_id: Optional[int] = None
    dust_info_id: Optional[int] = None
    experiment_tag: Optional[str] = None
    experiment_description: Optional[str] = None
    experiment_timestamp_ms: Optional[float] = None
    run_start_ms: Optional[float] = None
    run_stop_ms: Optional[float] = None
    dust_type_id: Optional[int] = None
    dust_source_builder: Optional[int] = None
    dust_shot_count: Optional[float] = None
    dust_initial_mass: Optional[float] = None
    dust_final_mass: Optional[float] = None
    dust_run_time: Optional[float] = None
    dust_source_notes: Optional[str] = None
    source_settings_id: Optional[int] = None
    source_settings_key: Optional[str] = None
    source_einzel_voltage: Optional[float] = None
    source_needle_voltage: Optional[float] = None
    source_frequency: Optional[float] = None
    source_width: Optional[float] = None
    source_amplitude: Optional[float] = None
    source_x_voltage: Optional[float] = None
    source_y_voltage: Optional[float] = None
    psu_velocity_max: Optional[float] = None
    psu_velocity_min: Optional[float] = None
    psu_charge_max: Optional[float] = None
    psu_charge_min: Optional[float] = None
    psu_mass_max: Optional[float] = None
    psu_mass_min: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def velocity_kmps(self) -> Optional[float]:
        if self.velocity_mps is None or not np.isfinite(self.velocity_mps):
            return None
        return float(self.velocity_mps) / 1000.0

    def age_ms(self, reference_ms: Optional[float]) -> Optional[float]:
        if reference_ms is None or self.timestamp_ms is None:
            return None
        if not np.isfinite(reference_ms) or not np.isfinite(self.timestamp_ms):
            return None
        return float(self.timestamp_ms) - float(reference_ms)


def _sql_result_from_accelerator_match(match: AcceleratorMatch) -> SQLMatchResult:
    metadata: Dict[str, Any] = {"Source": match.source}
    if match.dust_type:
        metadata.setdefault("DustType", match.dust_type)
    if match.campaign:
        metadata["Campaign"] = match.campaign
    if match.schedule_label:
        metadata["ScheduleLabel"] = match.schedule_label
    entry = match.calibration_entry
    if entry is not None:
        if entry.material:
            metadata["CalibrationMaterial"] = entry.material
        if entry.target_location:
            metadata["TargetLocation"] = entry.target_location
        if entry.azimuthal_location:
            metadata["AzimuthalLocation"] = entry.azimuthal_location
        if entry.speed_range:
            metadata["SpeedRange"] = entry.speed_range
        if entry.reference_voltage is not None:
            metadata["ReferenceVoltage"] = entry.reference_voltage
        if entry.target_voltage is not None:
            metadata["TargetVoltage"] = entry.target_voltage
        if entry.detector_voltage is not None:
            metadata["DetectorVoltage"] = entry.detector_voltage
        if entry.notes:
            metadata["CalibrationNotes"] = entry.notes
    return SQLMatchResult(
        record_id=match.record_id,
        estimate_quality=match.estimate_quality,
        timestamp_ms=match.timestamp_ms,
        velocity_mps=match.velocity_mps,
        mass_kg=match.mass_kg,
        charge_c=match.charge_c,
        radius_m=match.radius_m,
        experiment_settings_id=None,
        dust_info_id=None,
        experiment_tag=match.experiment_name,
        experiment_description=match.experiment_description,
        metadata=metadata,
    )


def build_default_criteria(data_source: BaseDataSource, event: str) -> SQLMatchCriteria:
    time_ms = _guess_event_timestamp_ms(data_source, event)
    velocity_kmps = _guess_event_velocity_kmps(data_source, event)
    return SQLMatchCriteria(time_ms=time_ms, velocity_kmps=velocity_kmps)


def _coerce_optional_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        numeric = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    if not np.isfinite(numeric):
        return None
    return numeric


def _coerce_optional_int(value: Any) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, (float, np.floating)) and (np.isnan(value) or np.isinf(value)):
        return None
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return None


def _coerce_optional_str(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, (bytes, bytearray)):
        try:
            value = value.decode("utf-8", errors="ignore")
        except Exception:
            value = value.decode("latin1", errors="ignore")
    text = str(value).strip()
    return text or None


def query_dust_events(criteria: SQLMatchCriteria) -> Tuple[List[SQLMatchResult], str, Dict[str, Any]]:
    engine = _get_sql_engine()
    where_clauses = ["mass != -1"]
    params: Dict[str, Any] = {}
    order_terms: List[str] = []
    fallback_order = "de.integer_timestamp DESC"

    if criteria.time_ms is not None and np.isfinite(criteria.time_ms):
        params["time_center"] = int(criteria.time_ms)
        order_terms.append("ABS(de.integer_timestamp - :time_center)")
        if criteria.restrict_time:
            window = max(criteria.time_window_ms, 0.0)
            time_lower = float(criteria.time_ms) - window
            time_upper = float(criteria.time_ms) + window
            where_clauses.append("de.integer_timestamp BETWEEN :time_lower AND :time_upper")
            params["time_lower"] = int(time_lower)
            params["time_upper"] = int(time_upper)

    if criteria.velocity_kmps is not None and np.isfinite(criteria.velocity_kmps):
        target_mps = float(criteria.velocity_kmps) * 1000.0
        params["velocity_target"] = target_mps
        order_terms.append("ABS(velocity - :velocity_target)")
        if criteria.restrict_velocity:
            tol = max(criteria.velocity_tolerance_kmps, 0.0) * 1000.0
            where_clauses.append("velocity BETWEEN :velocity_lower AND :velocity_upper")
            params["velocity_lower"] = target_mps - tol
            params["velocity_upper"] = target_mps + tol

    if criteria.min_quality is not None:
        where_clauses.append("estimate_quality >= :min_quality")
        params["min_quality"] = int(criteria.min_quality)

    extra = criteria.extra_filter.strip()
    if extra:
        where_clauses.append(f"({extra})")

    if fallback_order not in order_terms:
        order_terms.append(fallback_order)

    where_sql = " AND ".join(where_clauses) if where_clauses else "1"
    order_sql = ", ".join(order_terms)

    sql = (
        "SELECT "
        "de.id_dust_event AS id_dust_event, "
        "de.estimate_quality AS estimate_quality, "
        "de.integer_timestamp AS integer_timestamp, "
        "de.velocity AS velocity, "
        "de.mass AS mass, "
        "de.charge AS charge, "
        "de.radius AS radius, "
        "de.id_experiment_settings AS id_experiment_settings, "
        "de.id_dust_info AS id_dust_info, "
        "es.integer_timestamp AS experiment_integer_timestamp, "
        "es.tag AS experiment_tag, "
        "es.description AS experiment_description, "
        "rt.start_timestamp AS run_start_timestamp, "
        "rt.stop_timestamp AS run_stop_timestamp, "
        "di.dust_type AS dust_type, "
        "di.source_builder AS dust_source_builder, "
        "di.shot_count AS dust_shot_count, "
        "di.initial_dust_mass AS dust_initial_mass, "
        "di.final_dust_mass AS dust_final_mass, "
        "di.run_time AS dust_run_time, "
        "di.dust_source_notes AS dust_source_notes, "
        "ss.id_source_settings AS source_settings_id, "
        "ss.settings_id AS source_settings_key, "
        "ss.einzel_voltage AS source_einzel_voltage, "
        "ss.needle_voltage AS source_needle_voltage, "
        "ss.frequency AS source_frequency, "
        "ss.width AS source_width, "
        "ss.amplitude AS source_amplitude, "
        "ss.x_voltage AS source_x_voltage, "
        "ss.y_voltage AS source_y_voltage, "
        "psu.velocity_max AS psu_velocity_max, "
        "psu.velocity_min AS psu_velocity_min, "
        "psu.charge_max AS psu_charge_max, "
        "psu.charge_min AS psu_charge_min, "
        "psu.mass_max AS psu_mass_max, "
        "psu.mass_min AS psu_mass_min "
        "FROM dust_event AS de "
        "LEFT JOIN dust_info AS di ON de.id_dust_info = di.id_dust_info "
        "LEFT JOIN experiment_settings AS es ON de.id_experiment_settings = es.id_experiment_settings "
        "LEFT JOIN run_times AS rt ON es.id_experiment_settings = rt.id_experiment_settings "
        "LEFT JOIN source_settings AS ss ON es.integer_timestamp = ss.integer_timestamp "
        "LEFT JOIN psu ON de.integer_timestamp = psu.integer_timestamp "
        f"WHERE {where_sql} "
    )
    if order_sql:
        sql += f"ORDER BY {order_sql} "
    limit_value = criteria.effective_limit()
    if limit_value:
        sql += "LIMIT :limit"
        params["limit"] = int(limit_value)

    with engine.connect() as connection:
        frame = pd.read_sql_query(text(sql), connection, params=params)

    results: List[SQLMatchResult] = []
    for row in frame.to_dict(orient="records"):
        record_id = _coerce_optional_int(row.get("id_dust_event"))
        estimate_quality = _coerce_optional_float(row.get("estimate_quality"))
        timestamp_ms = _coerce_optional_float(row.get("integer_timestamp"))
        velocity = _coerce_optional_float(row.get("velocity"))
        mass = _coerce_optional_float(row.get("mass"))
        charge = _coerce_optional_float(row.get("charge"))
        radius = _coerce_optional_float(row.get("radius"))
        experiment_settings_id = _coerce_optional_int(row.get("id_experiment_settings"))
        dust_info_id = _coerce_optional_int(row.get("id_dust_info"))
        experiment_timestamp = _coerce_optional_float(row.get("experiment_integer_timestamp"))
        run_start = _coerce_optional_float(row.get("run_start_timestamp"))
        run_stop = _coerce_optional_float(row.get("run_stop_timestamp"))
        dust_type_id = _coerce_optional_int(row.get("dust_type"))
        dust_source_builder = _coerce_optional_int(row.get("dust_source_builder"))
        dust_shot_count = _coerce_optional_float(row.get("dust_shot_count"))
        dust_initial_mass = _coerce_optional_float(row.get("dust_initial_mass"))
        dust_final_mass = _coerce_optional_float(row.get("dust_final_mass"))
        dust_run_time = _coerce_optional_float(row.get("dust_run_time"))
        dust_source_notes = _coerce_optional_str(row.get("dust_source_notes"))
        source_settings_id = _coerce_optional_int(row.get("source_settings_id"))
        source_settings_key = _coerce_optional_str(row.get("source_settings_key"))
        source_einzel = _coerce_optional_float(row.get("source_einzel_voltage"))
        source_needle = _coerce_optional_float(row.get("source_needle_voltage"))
        source_frequency = _coerce_optional_float(row.get("source_frequency"))
        source_width = _coerce_optional_float(row.get("source_width"))
        source_amplitude = _coerce_optional_float(row.get("source_amplitude"))
        source_x_voltage = _coerce_optional_float(row.get("source_x_voltage"))
        source_y_voltage = _coerce_optional_float(row.get("source_y_voltage"))
        psu_velocity_max = _coerce_optional_float(row.get("psu_velocity_max"))
        psu_velocity_min = _coerce_optional_float(row.get("psu_velocity_min"))
        psu_charge_max = _coerce_optional_float(row.get("psu_charge_max"))
        psu_charge_min = _coerce_optional_float(row.get("psu_charge_min"))
        psu_mass_max = _coerce_optional_float(row.get("psu_mass_max"))
        psu_mass_min = _coerce_optional_float(row.get("psu_mass_min"))

        match = SQLMatchResult(
            record_id=record_id,
            estimate_quality=estimate_quality,
            timestamp_ms=timestamp_ms,
            velocity_mps=velocity,
            mass_kg=mass,
            charge_c=charge,
            radius_m=radius,
            experiment_settings_id=experiment_settings_id,
            dust_info_id=dust_info_id,
            experiment_tag=_coerce_optional_str(row.get("experiment_tag")),
            experiment_description=_coerce_optional_str(row.get("experiment_description")),
            experiment_timestamp_ms=experiment_timestamp,
            run_start_ms=run_start,
            run_stop_ms=run_stop,
            dust_type_id=dust_type_id,
            dust_source_builder=dust_source_builder,
            dust_shot_count=dust_shot_count,
            dust_initial_mass=dust_initial_mass,
            dust_final_mass=dust_final_mass,
            dust_run_time=dust_run_time,
            dust_source_notes=dust_source_notes,
            source_settings_id=source_settings_id,
            source_settings_key=source_settings_key,
            source_einzel_voltage=source_einzel,
            source_needle_voltage=source_needle,
            source_frequency=source_frequency,
            source_width=source_width,
            source_amplitude=source_amplitude,
            source_x_voltage=source_x_voltage,
            source_y_voltage=source_y_voltage,
            psu_velocity_max=psu_velocity_max,
            psu_velocity_min=psu_velocity_min,
            psu_charge_max=psu_charge_max,
            psu_charge_min=psu_charge_min,
            psu_mass_max=psu_mass_max,
            psu_mass_min=psu_mass_min,
        )

        metadata: Dict[str, Any] = {
            "RecordID": record_id,
            "EstimateQuality": estimate_quality,
            "IntegerTimestamp": timestamp_ms,
            "VelocityMetersPerSecond": velocity,
            "VelocityKilometersPerSecond": match.velocity_kmps,
            "MassKilograms": mass,
            "ChargeCoulombs": charge,
            "RadiusMeters": radius,
            "ExperimentSettingsID": experiment_settings_id,
            "DustInfoID": dust_info_id,
            "ExperimentTimestamp": experiment_timestamp,
            "ExperimentTag": match.experiment_tag,
            "ExperimentDescription": match.experiment_description,
            "RunStartTimestamp": run_start,
            "RunStopTimestamp": run_stop,
            "DustTypeID": dust_type_id,
            "DustSourceBuilder": dust_source_builder,
            "DustShotCount": dust_shot_count,
            "DustInitialMass": dust_initial_mass,
            "DustFinalMass": dust_final_mass,
            "DustRunTime": dust_run_time,
            "DustSourceNotes": dust_source_notes,
            "SourceSettingsID": source_settings_id,
            "SourceSettingsKey": source_settings_key,
            "SourceEinzelVoltage": source_einzel,
            "SourceNeedleVoltage": source_needle,
            "SourceFrequency": source_frequency,
            "SourceWidth": source_width,
            "SourceAmplitude": source_amplitude,
            "SourceXVoltage": source_x_voltage,
            "SourceYVoltage": source_y_voltage,
            "PSUVelocityMax": psu_velocity_max,
            "PSUVelocityMin": psu_velocity_min,
            "PSUChargeMax": psu_charge_max,
            "PSUChargeMin": psu_charge_min,
            "PSUMassMax": psu_mass_max,
            "PSUMassMin": psu_mass_min,
        }
        match.metadata = metadata
        results.append(match)

    return results, sql, params


def _write_sql_match(
    h5_handle: Any,
    event: str,
    match: SQLMatchResult,
    criteria: SQLMatchCriteria,
) -> None:
    if h5_handle is None or h5py is None:
        raise RuntimeError("The current file is not writable.")

    try:
        analysis_group = h5_handle.require_group(f"{event}/Analysis")
        match_group = analysis_group.require_group("SQLMatch")
    except Exception as exc:  # pragma: no cover - defensive
        raise RuntimeError(f"Unable to create SQLMatch group: {exc}") from exc

    string_fields = {
        "ExperimentTag",
        "ExperimentDescription",
        "DustSourceNotes",
        "SourceSettingsKey",
    }

    def _write_scalar(group: Any, name: str, value: Any) -> None:
        if group is None:
            return
        if name in group:
            del group[name]
        if name in string_fields:
            text_value = value if isinstance(value, str) else "" if value is None else str(value)
            dtype = h5py.string_dtype(encoding="utf-8") if h5py is not None else None
            group.create_dataset(name, data=np.array(text_value, dtype=dtype))
            return
        numeric: float
        if name == "RecordID":
            coerced = _coerce_optional_float(value)
            numeric = float(coerced) if coerced is not None else -1.0
        else:
            coerced = _coerce_optional_float(value)
            numeric = float(coerced) if coerced is not None else np.nan
        group.create_dataset(name, data=np.array(numeric, dtype=float))

    payload: Dict[str, Any] = {
        "RecordID": match.record_id if match.record_id is not None else -1,
        "EstimateQuality": match.estimate_quality if match.estimate_quality is not None else np.nan,
        "IntegerTimestamp": match.timestamp_ms if match.timestamp_ms is not None else np.nan,
        "VelocityMetersPerSecond": match.velocity_mps if match.velocity_mps is not None else np.nan,
        "VelocityKilometersPerSecond": match.velocity_kmps if match.velocity_kmps is not None else np.nan,
        "MassKilograms": match.mass_kg if match.mass_kg is not None else np.nan,
        "ChargeCoulombs": match.charge_c if match.charge_c is not None else np.nan,
        "RadiusMeters": match.radius_m if match.radius_m is not None else np.nan,
        "QueryCenterTimestamp": criteria.time_ms if criteria.time_ms is not None else np.nan,
        "QueryWindowMilliseconds": criteria.time_window_ms,
        "QueryVelocityKilometersPerSecond": criteria.velocity_kmps if criteria.velocity_kmps is not None else np.nan,
        "QueryVelocityToleranceKilometersPerSecond": criteria.velocity_tolerance_kmps,
        "MinimumEstimateQuality": criteria.min_quality if criteria.min_quality is not None else np.nan,
        "ResultLimit": criteria.effective_limit(),
        "CustomResultLimit": 1 if criteria.limit is not None else 0,
        "RestrictTimeWindow": 1 if criteria.restrict_time else 0,
        "RestrictVelocity": 1 if criteria.restrict_velocity else 0,
    }

    for name, value in payload.items():
        _write_scalar(match_group, name, value)

    extra = criteria.extra_filter.strip()
    if extra:
        if "ExtraFilter" in match_group:
            del match_group["ExtraFilter"]
        match_group.create_dataset("ExtraFilter", data=np.array(extra, dtype=h5py.string_dtype("utf-8")))

    accelerator_group = analysis_group.require_group("AcceleratorMetadata")
    accelerator_payload = dict(match.metadata or {})
    accelerator_payload.setdefault("RecordID", match.record_id)
    accelerator_payload.setdefault("EstimateQuality", match.estimate_quality)
    accelerator_payload.setdefault("IntegerTimestamp", match.timestamp_ms)
    accelerator_payload.setdefault("VelocityMetersPerSecond", match.velocity_mps)
    accelerator_payload.setdefault("VelocityKilometersPerSecond", match.velocity_kmps)
    accelerator_payload.setdefault("MassKilograms", match.mass_kg)
    accelerator_payload.setdefault("ChargeCoulombs", match.charge_c)
    accelerator_payload.setdefault("RadiusMeters", match.radius_m)
    accelerator_payload.setdefault("ExperimentSettingsID", match.experiment_settings_id)
    accelerator_payload.setdefault("DustInfoID", match.dust_info_id)
    accelerator_payload.setdefault("ExperimentTag", match.experiment_tag)
    accelerator_payload.setdefault("ExperimentDescription", match.experiment_description)
    accelerator_payload.setdefault("ExperimentTimestamp", match.experiment_timestamp_ms)
    accelerator_payload.setdefault("RunStartTimestamp", match.run_start_ms)
    accelerator_payload.setdefault("RunStopTimestamp", match.run_stop_ms)
    accelerator_payload.setdefault("DustTypeID", match.dust_type_id)
    accelerator_payload.setdefault("DustSourceBuilder", match.dust_source_builder)
    accelerator_payload.setdefault("DustShotCount", match.dust_shot_count)
    accelerator_payload.setdefault("DustInitialMass", match.dust_initial_mass)
    accelerator_payload.setdefault("DustFinalMass", match.dust_final_mass)
    accelerator_payload.setdefault("DustRunTime", match.dust_run_time)
    accelerator_payload.setdefault("DustSourceNotes", match.dust_source_notes)
    accelerator_payload.setdefault("SourceSettingsID", match.source_settings_id)
    accelerator_payload.setdefault("SourceSettingsKey", match.source_settings_key)
    accelerator_payload.setdefault("SourceEinzelVoltage", match.source_einzel_voltage)
    accelerator_payload.setdefault("SourceNeedleVoltage", match.source_needle_voltage)
    accelerator_payload.setdefault("SourceFrequency", match.source_frequency)
    accelerator_payload.setdefault("SourceWidth", match.source_width)
    accelerator_payload.setdefault("SourceAmplitude", match.source_amplitude)
    accelerator_payload.setdefault("SourceXVoltage", match.source_x_voltage)
    accelerator_payload.setdefault("SourceYVoltage", match.source_y_voltage)
    accelerator_payload.setdefault("PSUVelocityMax", match.psu_velocity_max)
    accelerator_payload.setdefault("PSUVelocityMin", match.psu_velocity_min)
    accelerator_payload.setdefault("PSUChargeMax", match.psu_charge_max)
    accelerator_payload.setdefault("PSUChargeMin", match.psu_charge_min)
    accelerator_payload.setdefault("PSUMassMax", match.psu_mass_max)
    accelerator_payload.setdefault("PSUMassMin", match.psu_mass_min)

    for name, value in sorted(accelerator_payload.items()):
        _write_scalar(accelerator_group, name, value)

    match_group.attrs["MatchedAtUTC"] = datetime.now(timezone.utc).isoformat()

    try:
        h5_handle.flush()
    except Exception:  # pragma: no cover - filesystem edge cases
        pass


class SQLMatchDialog(QDialog):
    COLUMN_DEFINITIONS: List[Tuple[str, Callable[[SQLMatchResult], str]]] = [
        ("ID", lambda m: "–" if m.record_id is None else str(m.record_id)),
        ("Quality", lambda m: _format_float(m.estimate_quality, precision=1)),
        ("Timestamp (UTC)", lambda m: _timestamp_to_iso(m.timestamp_ms)),
        ("Δt", lambda m: _format_delta_ms(m.age_ms(m._reference_time_ms))),  # type: ignore[attr-defined]
        ("Velocity (km/s)", lambda m: _format_float(m.velocity_kmps, precision=3)),
        ("Mass (kg)", lambda m: _format_mass(m.mass_kg)),
        ("Charge (C)", lambda m: _format_charge(m.charge_c)),
        ("Radius (m)", lambda m: _format_float(m.radius_m, precision=3)),
        ("Experiment tag", lambda m: m.experiment_tag or "–"),
    ]

    def __init__(
        self,
        data_source: BaseDataSource,
        event_name: str,
        *,
        event_names: Optional[List[str]] = None,
        parent: Optional[QWidget] = None,
        h5_handle: Any = None,
        on_event_changed: Optional[Callable[[str], None]] = None,
        status_callback: Optional[Callable[[str, int], None]] = None,
    ):
        super().__init__(parent)
        self.setWindowTitle("Accelerator SQL Matching")
        self.resize(980, 720)

        self._data_source = data_source
        self._event_names = event_names or []
        self._current_event = event_name if event_name in self._event_names else (self._event_names[0] if self._event_names else event_name)
        self._h5_handle = h5_handle
        self._on_event_changed = on_event_changed
        self._status_callback = status_callback
        self._default_criteria = SQLMatchCriteria()
        self._last_criteria = SQLMatchCriteria()
        self._matches: List[SQLMatchResult] = []
        self._last_query_sql: str = ""
        self._last_query_params: Dict[str, Any] = {}
        self._reference_time_ms: Optional[float] = None
        self._custom_limit_value: int = DEFAULT_RESULT_LIMIT
        self._accelerator_matcher: Optional[AcceleratorMatchFinder] = None

        self._build_ui()
        self._populate_event_combo()
        if self._current_event:
            self._refresh_for_event(self._current_event, notify_parent=False)

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)

        header_layout = QHBoxLayout()
        header_layout.addWidget(QLabel("Event:"))
        self.event_combo = QComboBox(self)
        self.event_combo.currentIndexChanged.connect(self._event_combo_changed)
        header_layout.addWidget(self.event_combo)
        header_layout.addStretch(1)
        layout.addLayout(header_layout)

        self.summary_label = QLabel("Select an event to begin.")
        self.summary_label.setWordWrap(True)
        layout.addWidget(self.summary_label)

        criteria_group = QGroupBox("Search criteria", self)
        criteria_layout = QGridLayout(criteria_group)

        self.timestamp_edit = QLineEdit(self)
        self.timestamp_edit.setPlaceholderText("Epoch milliseconds (leave blank to ignore)")
        criteria_layout.addWidget(QLabel("Timestamp (ms)"), 0, 0)
        criteria_layout.addWidget(self.timestamp_edit, 0, 1)

        self.time_window_spin = QDoubleSpinBox(self)
        self.time_window_spin.setRange(1.0, 3600_000.0)
        self.time_window_spin.setDecimals(0)
        self.time_window_spin.setSingleStep(250.0)
        criteria_layout.addWidget(QLabel("± Window (ms)"), 0, 2)
        criteria_layout.addWidget(self.time_window_spin, 0, 3)
        self.restrict_time_check = QCheckBox("Restrict by time", self)
        self.restrict_time_check.setToolTip("Limit matches to the specified time window.")
        criteria_layout.addWidget(self.restrict_time_check, 0, 4)

        self.velocity_edit = QLineEdit(self)
        self.velocity_edit.setPlaceholderText("Velocity in km/s (optional)")
        criteria_layout.addWidget(QLabel("Velocity (km/s)"), 1, 0)
        criteria_layout.addWidget(self.velocity_edit, 1, 1)

        self.velocity_tol_spin = QDoubleSpinBox(self)
        self.velocity_tol_spin.setRange(0.0, 100.0)
        self.velocity_tol_spin.setDecimals(3)
        self.velocity_tol_spin.setSingleStep(0.05)
        criteria_layout.addWidget(QLabel("± Velocity tol. (km/s)"), 1, 2)
        criteria_layout.addWidget(self.velocity_tol_spin, 1, 3)
        self.restrict_velocity_check = QCheckBox("Restrict by velocity", self)
        self.restrict_velocity_check.setToolTip("Limit matches to the specified velocity tolerance.")
        criteria_layout.addWidget(self.restrict_velocity_check, 1, 4)

        self.quality_spin = QSpinBox(self)
        self.quality_spin.setRange(-100, 100)
        self.quality_spin.setValue(0)
        criteria_layout.addWidget(QLabel("Minimum quality"), 2, 0)
        criteria_layout.addWidget(self.quality_spin, 2, 1)

        self.limit_spin = QSpinBox(self)
        self.limit_spin.setRange(1, 200)
        self.limit_spin.setValue(DEFAULT_RESULT_LIMIT)
        self.limit_spin.setEnabled(False)
        criteria_layout.addWidget(QLabel("Result limit"), 2, 2)
        criteria_layout.addWidget(self.limit_spin, 2, 3)
        self.custom_limit_check = QCheckBox("Specify result limit", self)
        self.custom_limit_check.toggled.connect(self._toggle_custom_limit)
        criteria_layout.addWidget(self.custom_limit_check, 2, 4)

        self.extra_filter_edit = QLineEdit(self)
        self.extra_filter_edit.setPlaceholderText("Additional SQL filter (advanced)")
        criteria_layout.addWidget(QLabel("Extra filter"), 3, 0)
        criteria_layout.addWidget(self.extra_filter_edit, 3, 1, 1, 4)

        layout.addWidget(criteria_group)

        button_row = QHBoxLayout()
        self.refresh_button = QPushButton("Refresh matches", self)
        self.refresh_button.clicked.connect(self.run_search)
        button_row.addWidget(self.refresh_button)

        self.reset_button = QPushButton("Reset to event defaults", self)
        self.reset_button.clicked.connect(self.reset_to_defaults)
        button_row.addWidget(self.reset_button)

        self.copy_sql_button = QPushButton("Copy SQL", self)
        self.copy_sql_button.clicked.connect(self.copy_last_query)
        button_row.addWidget(self.copy_sql_button)

        button_row.addStretch(1)
        layout.addLayout(button_row)

        self.matches_table = QTableWidget(self)
        self.matches_table.setColumnCount(len(self.COLUMN_DEFINITIONS))
        self.matches_table.setHorizontalHeaderLabels([label for label, _ in self.COLUMN_DEFINITIONS])
        self.matches_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.matches_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.matches_table.horizontalHeader().setStretchLastSection(True)
        self.matches_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.matches_table.verticalHeader().setVisible(False)
        self.matches_table.itemSelectionChanged.connect(self._update_details_from_selection)
        layout.addWidget(self.matches_table)

        details_group = QGroupBox("Match details", self)
        details_layout = QVBoxLayout(details_group)
        self.details_browser = QTextBrowser(self)
        self.details_browser.setOpenExternalLinks(True)
        details_layout.addWidget(self.details_browser)
        layout.addWidget(details_group)

        bottom_row = QHBoxLayout()
        bottom_row.addStretch(1)
        self.apply_button = QPushButton("Apply match to event", self)
        self.apply_button.clicked.connect(self.apply_match)
        self.apply_button.setEnabled(False)
        bottom_row.addWidget(self.apply_button)

        close_button = QPushButton("Close", self)
        close_button.clicked.connect(self.close)
        bottom_row.addWidget(close_button)
        layout.addLayout(bottom_row)

    def _populate_event_combo(self) -> None:
        self.event_combo.blockSignals(True)
        self.event_combo.clear()
        self.event_combo.addItems(self._event_names)
        self.event_combo.blockSignals(False)
        if self._current_event and self._current_event in self._event_names:
            index = self._event_names.index(self._current_event)
            self.event_combo.setCurrentIndex(index)

    def _event_combo_changed(self, index: int) -> None:
        if index < 0 or index >= len(self._event_names):
            return
        event_name = self._event_names[index]
        self._refresh_for_event(event_name, notify_parent=True)

    def _refresh_for_event(self, event_name: str, notify_parent: bool) -> None:
        self._current_event = event_name
        self._default_criteria = build_default_criteria(self._data_source, event_name)
        self._reference_time_ms = self._default_criteria.time_ms
        self._set_criteria_fields(self._default_criteria)
        self._update_summary_label()
        self._load_initial_matches()
        if notify_parent and self._on_event_changed is not None:
            self._on_event_changed(event_name)

    def _set_criteria_fields(self, criteria: SQLMatchCriteria) -> None:
        if criteria.time_ms is None or not np.isfinite(criteria.time_ms):
            self.timestamp_edit.clear()
        else:
            self.timestamp_edit.setText(f"{criteria.time_ms:.3f}")
        self.time_window_spin.setValue(criteria.time_window_ms)
        if criteria.velocity_kmps is None or not np.isfinite(criteria.velocity_kmps):
            self.velocity_edit.clear()
        else:
            self.velocity_edit.setText(f"{criteria.velocity_kmps:.4f}")
        self.velocity_tol_spin.setValue(criteria.velocity_tolerance_kmps)
        self.quality_spin.setValue(criteria.min_quality or 0)
        with QSignalBlocker(self.restrict_time_check):
            self.restrict_time_check.setChecked(criteria.restrict_time)
        with QSignalBlocker(self.restrict_velocity_check):
            self.restrict_velocity_check.setChecked(criteria.restrict_velocity)

        custom_limit_enabled = criteria.limit is not None
        with QSignalBlocker(self.custom_limit_check):
            self.custom_limit_check.setChecked(custom_limit_enabled)
        self.limit_spin.setEnabled(custom_limit_enabled)
        if custom_limit_enabled and criteria.limit is not None:
            limit_value = criteria.effective_limit()
            self.limit_spin.setValue(limit_value)
            self._custom_limit_value = limit_value
        else:
            self.limit_spin.setValue(DEFAULT_RESULT_LIMIT)
        self.extra_filter_edit.setText(criteria.extra_filter)

    def _collect_criteria(self) -> Optional[SQLMatchCriteria]:
        timestamp_text = self.timestamp_edit.text().strip()
        velocity_text = self.velocity_edit.text().strip()

        time_ms: Optional[float]
        if timestamp_text:
            try:
                time_ms = float(timestamp_text)
            except ValueError:
                QMessageBox.warning(self, "Invalid timestamp", "Timestamp must be a numeric value in milliseconds.")
                return None
        else:
            time_ms = None

        velocity_kmps: Optional[float]
        if velocity_text:
            try:
                velocity_kmps = float(velocity_text)
            except ValueError:
                QMessageBox.warning(self, "Invalid velocity", "Velocity must be expressed in km/s.")
                return None
        else:
            velocity_kmps = None

        criteria = SQLMatchCriteria(
            time_ms=time_ms,
            time_window_ms=float(self.time_window_spin.value()),
            velocity_kmps=velocity_kmps,
            velocity_tolerance_kmps=float(self.velocity_tol_spin.value()),
            min_quality=int(self.quality_spin.value()),
            limit=int(self.limit_spin.value()) if self.custom_limit_check.isChecked() else None,
            extra_filter=self.extra_filter_edit.text().strip(),
            restrict_time=self.restrict_time_check.isChecked(),
            restrict_velocity=self.restrict_velocity_check.isChecked(),
        )
        if self.custom_limit_check.isChecked():
            self._custom_limit_value = criteria.effective_limit()
        return criteria

    def _toggle_custom_limit(self, checked: bool) -> None:
        if checked:
            self.limit_spin.setEnabled(True)
            self.limit_spin.setValue(self._custom_limit_value)
        else:
            self._custom_limit_value = int(self.limit_spin.value())
            self.limit_spin.setEnabled(False)
            self.limit_spin.setValue(DEFAULT_RESULT_LIMIT)

    def run_search(self) -> None:
        criteria = self._collect_criteria()
        if criteria is None:
            return

        sql_error: str | None = None
        try:
            results, sql, params = query_dust_events(criteria)
        except Exception as exc:
            results = []
            sql = ""
            params = {}
            sql_error = str(exc)

        for result in results:
            result.metadata.setdefault("Source", "server")

        combined: List[SQLMatchResult] = list(results)
        matcher = self._ensure_accelerator_matcher()
        if (
            matcher is not None
            and criteria.time_ms is not None
            and np.isfinite(criteria.time_ms)
        ):
            try:
                velocity_mps = (
                    float(criteria.velocity_kmps) * 1000.0
                    if criteria.velocity_kmps is not None and np.isfinite(criteria.velocity_kmps)
                    else None
                )
            except Exception:
                velocity_mps = None
            try:
                csv_matches = matcher.search(
                    criteria.time_ms,
                    velocity_mps=velocity_mps,
                    limit=criteria.effective_limit(),
                    time_window_ms=criteria.time_window_ms,
                    restrict_time=criteria.restrict_time,
                    restrict_velocity=criteria.restrict_velocity and velocity_mps is not None,
                    velocity_tolerance_mps=criteria.velocity_tolerance_kmps * 1000.0,
                )
            except Exception:
                csv_matches = []
            csv_results = [_sql_result_from_accelerator_match(match) for match in csv_matches]
            combined.extend(csv_results)

        reference = criteria.time_ms if criteria.time_ms is not None and np.isfinite(criteria.time_ms) else None

        def _delta(result: SQLMatchResult) -> float:
            if reference is None or result.timestamp_ms is None or not np.isfinite(result.timestamp_ms):
                return float("inf")
            return abs(float(result.timestamp_ms) - reference)

        combined.sort(key=_delta)

        self._matches = combined
        self._last_query_sql = sql
        self._last_query_params = params
        self._last_criteria = criteria
        self._populate_table()
        if combined:
            self.matches_table.selectRow(0)
        else:
            self.apply_button.setEnabled(False)
            if sql_error:
                self.details_browser.setText(
                    "SQL query failed; no CSV matches were found either."
                )
            else:
                self.details_browser.setText(
                    "No results were returned for the current criteria."
                )
        if sql_error and combined:
            self.details_browser.setText(
                "SQL query failed; displaying CSV lookup matches only."
            )

    def _populate_table(self) -> None:
        self.matches_table.setRowCount(len(self._matches))
        reference = self._reference_time_ms
        for row_index, match in enumerate(self._matches):
            setattr(match, "_reference_time_ms", reference)  # type: ignore[attr-defined]
            for col_index, (_label, formatter) in enumerate(self.COLUMN_DEFINITIONS):
                value = formatter(match)
                item = QTableWidgetItem(value)
                item.setFlags(item.flags() ^ Qt.ItemFlag.ItemIsEditable)
                self.matches_table.setItem(row_index, col_index, item)
        self.matches_table.resizeRowsToContents()

    def _update_details_from_selection(self) -> None:
        match = self._current_selection()
        self.apply_button.setEnabled(match is not None)
        if match is None:
            return

        lines = ["<b>Selected SQL record</b>"]
        lines.append(f"<b>ID:</b> {match.record_id if match.record_id is not None else '–'}")
        lines.append(f"<b>Timestamp (UTC):</b> {_timestamp_to_iso(match.timestamp_ms)}")
        delta = match.age_ms(self._reference_time_ms)
        lines.append(f"<b>Δt relative to event:</b> {_format_delta_ms(delta)}")
        lines.append(f"<b>Estimate quality:</b> {_format_float(match.estimate_quality, precision=1)}")
        lines.append(f"<b>Velocity:</b> {_format_float(match.velocity_kmps, precision=4)} km/s")
        lines.append(f"<b>Mass:</b> {_format_mass(match.mass_kg)} kg")
        lines.append(f"<b>Charge:</b> {_format_charge(match.charge_c)} C")
        lines.append(f"<b>Radius:</b> {_format_float(match.radius_m, precision=3)} m")

        def _fmt_int(value: Optional[int]) -> str:
            return "–" if value is None else html.escape(str(value))

        def _fmt_text(value: Optional[str], *, max_length: int = 600) -> str:
            if value is None or not value.strip():
                return "–"
            escaped = html.escape(value.strip())
            if len(escaped) > max_length:
                return escaped[:max_length] + "…"
            return escaped

        def _fmt_timestamp(value: Optional[float]) -> str:
            if value is None or not np.isfinite(value):
                return "–"
            return _timestamp_to_iso(value)

        def _fmt_count(value: Optional[float]) -> str:
            if value is None or not np.isfinite(value):
                return "–"
            rounded = round(value)
            if abs(value - rounded) < 1e-6:
                return html.escape(str(int(rounded)))
            return _format_float(value, precision=3)

        def _append_section(title: str, entries: Sequence[Tuple[str, str]]) -> None:
            valid = [f"<b>{html.escape(label)}:</b> {value}" for label, value in entries if value != "–"]
            if valid:
                lines.append("<hr/>")
                lines.append(f"<b>{html.escape(title)}</b>")
                lines.extend(valid)

        experiment_entries = [
            ("Settings ID", _fmt_int(match.experiment_settings_id)),
            ("Tag", _fmt_text(match.experiment_tag)),
            ("Description", _fmt_text(match.experiment_description, max_length=800)),
            ("Timestamp (UTC)", _fmt_timestamp(match.experiment_timestamp_ms)),
        ]
        _append_section("Experiment settings", experiment_entries)

        run_entries = [
            ("Run start (UTC)", _fmt_timestamp(match.run_start_ms)),
            ("Run stop (UTC)", _fmt_timestamp(match.run_stop_ms)),
        ]
        _append_section("Run window", run_entries)

        dust_entries = [
            ("Dust info ID", _fmt_int(match.dust_info_id)),
            ("Dust type ID", _fmt_int(match.dust_type_id)),
            ("Source builder", _fmt_int(match.dust_source_builder)),
            ("Shot count", _fmt_count(match.dust_shot_count)),
            ("Initial mass (kg)", _format_mass(match.dust_initial_mass)),
            ("Final mass (kg)", _format_mass(match.dust_final_mass)),
            ("Run time", _format_float(match.dust_run_time, precision=3)),
            ("Source notes", _fmt_text(match.dust_source_notes, max_length=1200)),
        ]
        _append_section("Dust source", dust_entries)

        source_entries = [
            ("Source settings ID", _fmt_int(match.source_settings_id)),
            ("Settings key", _fmt_text(match.source_settings_key)),
            ("Einzel voltage", _format_float(match.source_einzel_voltage, precision=3)),
            ("Needle voltage", _format_float(match.source_needle_voltage, precision=3)),
            ("Frequency", _format_float(match.source_frequency, precision=3)),
            ("Width", _format_float(match.source_width, precision=3)),
            ("Amplitude", _format_float(match.source_amplitude, precision=3)),
            ("X voltage", _format_float(match.source_x_voltage, precision=3)),
            ("Y voltage", _format_float(match.source_y_voltage, precision=3)),
        ]
        _append_section("Source settings", source_entries)

        psu_entries = [
            ("Velocity max", _format_float(match.psu_velocity_max, precision=3)),
            ("Velocity min", _format_float(match.psu_velocity_min, precision=3)),
            ("Charge max", _format_float(match.psu_charge_max, precision=3)),
            ("Charge min", _format_float(match.psu_charge_min, precision=3)),
            ("Mass max", _format_float(match.psu_mass_max, precision=3)),
            ("Mass min", _format_float(match.psu_mass_min, precision=3)),
        ]
        _append_section("PSU limits", psu_entries)

        if self._last_query_sql:
            lines.append("<hr/>")
            lines.append("<b>SQL query</b>")
            lines.append(f"<pre>{html.escape(self._last_query_sql)}</pre>")
            if self._last_query_params:
                lines.append("<b>Parameters</b>")
                formatted_params = "<br/>".join(
                    f"&nbsp;&nbsp;{html.escape(str(key))} = {html.escape(str(value))}"
                    for key, value in self._last_query_params.items()
                )
                lines.append(formatted_params)

        self.details_browser.setHtml("<br/>".join(lines))

    def _current_selection(self) -> Optional[SQLMatchResult]:
        selected = self.matches_table.selectionModel()
        if not selected:
            return None
        indexes = selected.selectedRows()
        if not indexes:
            return None
        row = indexes[0].row()
        if row < 0 or row >= len(self._matches):
            return None
        return self._matches[row]

    def apply_match(self) -> None:
        match = self._current_selection()
        if match is None or not self._current_event:
            return
        try:
            _write_sql_match(self._h5_handle, self._current_event, match, self._last_criteria)
        except RuntimeError as exc:
            QMessageBox.critical(self, "Unable to save", str(exc))
            return

        message = (
            f"Stored SQL match for event {self._current_event} (record {match.record_id if match.record_id is not None else '–'})."
        )
        if self._status_callback is not None:
            self._status_callback(message, 6000)
        QMessageBox.information(self, "Match saved", message)

    def reset_to_defaults(self) -> None:
        self._set_criteria_fields(self._default_criteria)
        self.run_search()

    def copy_last_query(self) -> None:
        clipboard = QApplication.clipboard()
        combined = self._last_query_sql
        if self._last_query_params:
            combined += "\n\n" + "\n".join(f":{key} = {value}" for key, value in self._last_query_params.items())
        clipboard.setText(combined)
        if self._status_callback is not None:
            self._status_callback("Copied SQL query to clipboard.", 4000)

    def _update_summary_label(self) -> None:
        event_time = _timestamp_to_iso(self._default_criteria.time_ms)
        velocity = _format_float(self._default_criteria.velocity_kmps, precision=4)
        summary = [f"<b>Event:</b> {html.escape(str(self._current_event))}"]
        summary.append(f"<b>Trigger (UTC):</b> {event_time}")
        summary.append(f"<b>Velocity estimate:</b> {velocity} km/s")
        self.summary_label.setText("<br/>".join(summary))

    def _ensure_accelerator_matcher(self) -> Optional[AcceleratorMatchFinder]:
        if self._accelerator_matcher is None:
            try:
                self._accelerator_matcher = AcceleratorMatchFinder()
            except Exception:
                self._accelerator_matcher = None
        return self._accelerator_matcher

    def _load_initial_matches(self) -> None:
        timestamp = self._default_criteria.time_ms
        combined: List[SQLMatchResult] = []
        sql_text = ""
        sql_params: Dict[str, Any] = {}

        if timestamp is not None and np.isfinite(timestamp):
            initial_criteria = SQLMatchCriteria(time_ms=timestamp, limit=5)
            try:
                server_results, sql_text, sql_params = query_dust_events(initial_criteria)
            except Exception:
                server_results = []
            for result in server_results[:5]:
                result.metadata.setdefault("Source", "server")
                combined.append(result)

            matcher = self._ensure_accelerator_matcher()
            if matcher is not None:
                try:
                    csv_matches = matcher.search(timestamp, limit=5)
                except Exception:
                    csv_matches = []
                csv_results = [_sql_result_from_accelerator_match(match) for match in csv_matches]
                combined.extend(csv_results)
        else:
            matcher = None

        if combined:
            reference = timestamp if timestamp is not None and np.isfinite(timestamp) else None

            def _delta(match: SQLMatchResult) -> float:
                if reference is None or match.timestamp_ms is None or not np.isfinite(match.timestamp_ms):
                    return float("inf")
                return abs(float(match.timestamp_ms) - reference)

            combined.sort(key=_delta)
            self._matches = combined
            self._last_query_sql = sql_text
            self._last_query_params = sql_params
            self._last_criteria = SQLMatchCriteria(time_ms=timestamp)
            self._populate_table()
            if combined:
                self.matches_table.selectRow(0)
                self.apply_button.setEnabled(True)
            self.details_browser.setText(
                "Initial matches include live SQL results and FM lookup records."
            )
        else:
            self._matches = []
            self._last_query_sql = ""
            self._last_query_params = {}
            self._last_criteria = SQLMatchCriteria(time_ms=timestamp)
            self._populate_table()
            self.apply_button.setEnabled(False)
            self.details_browser.setText(
                "No accelerator metadata were found near the event timestamp."
            )

    def set_current_event(self, event_name: Optional[str]) -> None:
        if not event_name or event_name not in self._event_names:
            return
        index = self._event_names.index(event_name)
        self.event_combo.blockSignals(True)
        self.event_combo.setCurrentIndex(index)
        self.event_combo.blockSignals(False)
        self._refresh_for_event(event_name, notify_parent=False)


def launch_sql_matcher_window(
    data_source: BaseDataSource,
    event_name: str,
    *,
    event_names: Optional[List[str]] = None,
    parent: Optional[QWidget] = None,
    h5_handle: Any = None,
    on_event_changed: Optional[Callable[[str], None]] = None,
    status_callback: Optional[Callable[[str, int], None]] = None,
) -> SQLMatchDialog:
    dialog = SQLMatchDialog(
        data_source,
        event_name,
        event_names=event_names,
        parent=parent,
        h5_handle=h5_handle,
        on_event_changed=on_event_changed,
        status_callback=status_callback,
    )
    dialog.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
    dialog.show()
    dialog.raise_()
    dialog.activateWindow()
    return dialog


Y_AXIS_LABELS: Dict[str, str] = {
    "Target L": r"$Q_{TL}$ [pC]",
    "Target H": r"$Q_{TH}$ [pC]",
    "Ion Grid": r"$Q_{IG}$ [pC]",
    "TOF L": r"$TOF_{L}$ [pC/ $\Delta t$]",
    "TOF M": r"$TOF_{M}$ [pC/ $\Delta t$]",
    "TOF H": r"$TOF_{H}$ [pC/ $\Delta t$]",
    "TOF Combined": r"$TOF_{combined}$ [pC/ $\Delta t$]",
}


def y_label_with_units(channel_name: str) -> str:
    return Y_AXIS_LABELS.get(channel_name, channel_name)

# --------- Main Window ---------
class MainWindow(QMainWindow):
    def __init__(self, filename: str | None = None, eventnumber: int | None = None):
        super().__init__()
        self.setWindowTitle("IDEX Quicklook — Interactive Viewer")
        self.setMinimumSize(1250, 820)
        self.setStatusBar(QStatusBar(self))

        logo_path = _find_brand_logo()
        if logo_path is not None:
            self.setWindowIcon(QIcon(str(logo_path)))

        self._data_source: Optional[BaseDataSource] = None
        self._events: List[str] = []
        self._current_event: Optional[str] = None
        self._filename: Optional[str] = None
        self._h5: Optional[Any] = None
        self._tmpdir = tempfile.TemporaryDirectory(prefix="idex_quicklook_")
        self._fit_cache: Dict[Tuple[str, str], FitData] = {}
        self._fit_param_overrides: Dict[Tuple[str, str, str], np.ndarray] = {}
        self._fit_fixed_overrides: Dict[Tuple[str, str, str], np.ndarray] = {}
        self._fit_result_overrides: Dict[Tuple[str, str, str], np.ndarray] = {}
        self._fit_time_overrides: Dict[Tuple[str, str, str], np.ndarray] = {}
        self._baseline_cache: Dict[Tuple[str, str], float] = {}
        self._rise_metric_cache: Dict[Tuple[str, str], Dict[str, float]] = {}
        self._low_rate_waveform_cache: Dict[
            Tuple[str, str], Tuple[np.ndarray, np.ndarray]
        ] = {}
        self._show_fit: Dict[str, bool] = {name: False for name in FIT_ELIGIBLE_CHANNELS}
        # ``refresh_fit_controls`` is invoked as soon as data are loaded, so make
        # sure ``fit_buttons`` always exists even before the control panel is
        # constructed.  Some startup paths (for example early failures while
        # building the control panel) were leaving the attribute undefined which
        # caused an ``AttributeError`` when plotting the first event.
        self.fit_buttons: Dict[str, QPushButton] = {}
        self.selected_channels = set(CHANNEL_ORDER)
        self._child_windows: List[QWidget] = []
        self._documentation_center: Optional[DocumentationCenter] = None

        self._create_actions()

        self._apply_modern_palette()

        central = QWidget(self)
        self.vbox = QVBoxLayout(central)
        self.vbox.setContentsMargins(10, 10, 10, 10)
        self.vbox.setSpacing(12)
        self.setCentralWidget(central)

        branding_widget = self._build_branding_banner()
        if branding_widget is not None:
            self.vbox.addWidget(branding_widget)

        self._build_menubar()
        self._build_toolbar()
        self._build_controls()

        self.figure = Figure(figsize=(12, 8), constrained_layout=True)
        self.canvas = FigureCanvas(self.figure)
        self.canvas.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.canvas.setMinimumWidth(800)

        self._plot_container = QWidget(self)
        self._plot_container.setAutoFillBackground(False)
        container_layout = QVBoxLayout(self._plot_container)
        container_layout.setContentsMargins(0, 0, 0, 0)
        container_layout.setSpacing(0)
        container_layout.addWidget(self.canvas)

        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll_area.setStyleSheet(
            """
            QScrollArea { border: none; background: transparent; }
            QScrollArea > QWidget > QWidget { background: transparent; }
            """
        )
        self.scroll_area.setWidget(self._plot_container)

        self.nav_toolbar = NavigationToolbar(self.canvas, self)
        self.nav_toolbar.setStyleSheet("font-size: 14px; padding: 6px;")
        self.vbox.addWidget(self.nav_toolbar)
        self.vbox.addWidget(self.scroll_area)

        self.statusBar().showMessage("Select a data file (HDF5 or CDF) to get started.")

        if filename:
            self.open_file(filename)
        else:
            chosen = prompt_for_data_file(self)
            if not chosen:
                self.close()
                return
            self.open_file(chosen)

        if eventnumber is not None and self._events and 1 <= eventnumber <= len(self._events):
            self.event_combo.setCurrentIndex(eventnumber - 1)

    def _channel_scale(self, channel: str) -> float:
        """Return the waveform conversion factor for *channel*."""

        return CHANNEL_CONVERSION_FACTORS.get(channel, 1.0)

    def _apply_plot_scale(self, channel: str, values: Iterable[float]) -> np.ndarray:
        """Scale ``values`` into the display units for *channel*."""

        arr = np.asarray(values, dtype=float)
        scale = self._channel_scale(channel)
        # if scale != 1.0:
        #     arr = arr / scale
        return arr

    # ---- UI construction -------------------------------------------------
    def _apply_modern_palette(self) -> None:
        self.setStyleSheet(
            """
            QMainWindow {
                background-color: #edf1fb;
            }
            QMenuBar {
                background-color: #ffffff;
                font-size: 14px;
            }
            QMenu {
                font-size: 14px;
                padding: 6px 10px;
            }
            QToolBar {
                background-color: #ffffff;
                padding: 6px;
                border: none;
            }
            QStatusBar {
                background-color: #f4f6fb;
                font-size: 13px;
            }
            QListWidget {
                font-size: 14px;
            }
            QTextBrowser {
                font-size: 14px;
            }
            """
        )
        status = self.statusBar()
        status.setStyleSheet("background-color: #f4f6fb; font-size: 13px; padding: 4px 8px;")
        status.setContentsMargins(6, 0, 6, 0)

    def _create_actions(self):
        self.open_any_action = QAction("Open…", self)
        self.open_any_action.setShortcut("Ctrl+O")
        self.open_any_action.triggered.connect(self.action_open)

        self.open_hdf5_action = QAction("Open HDF5…", self)
        self.open_hdf5_action.triggered.connect(lambda: self.action_open(preferred="hdf5"))

        self.open_cdf_action = QAction("Open CDF…", self)
        self.open_cdf_action.triggered.connect(lambda: self.action_open(preferred="cdf"))

        self.view_structure_action = QAction("Open Data Browser", self)
        self.view_structure_action.setShortcut("Ctrl+B")
        self.view_structure_action.triggered.connect(self.action_view_structure)

        self.open_hdf_explorer_action = QAction("Open HDF Explorer", self)
        self.open_hdf_explorer_action.setShortcut("Ctrl+Shift+H")
        self.open_hdf_explorer_action.setStatusTip("Launch the standalone HDF Explorer for this file")
        self.open_hdf_explorer_action.triggered.connect(self.action_open_hdf_explorer)

        self.open_variable_definitions_action = QAction("Variable Definitions…", self)
        self.open_variable_definitions_action.setEnabled(launch_variable_definitions_viewer is not None)
        self.open_variable_definitions_action.triggered.connect(self.action_open_variable_definitions)

        self.reload_action = QAction("Reload", self)
        self.reload_action.setShortcut("Ctrl+R")
        self.reload_action.triggered.connect(self.reload_current)

        self.close_file_action = QAction("Close File", self)
        self.close_file_action.triggered.connect(self.close_current_file)

        self.quit_action = QAction("Quit", self)
        self.quit_action.setShortcut("Ctrl+Q")
        self.quit_action.triggered.connect(self.close)

        self.save_png_action = QAction("Save Plot as PNG…", self)
        self.save_png_action.triggered.connect(lambda: self.save_plot("png"))

        self.save_pdf_action = QAction("Save Plot as PDF…", self)
        self.save_pdf_action.triggered.connect(lambda: self.save_plot("pdf"))

        self.save_svg_action = QAction("Save Plot as SVG…", self)
        self.save_svg_action.triggered.connect(lambda: self.save_plot("svg"))

        self.edit_fit_action = QAction("Edit Fit Parameters", self)
        self.edit_fit_action.setShortcut("Ctrl+E")
        self.edit_fit_action.triggered.connect(self.open_fit_parameter_dialog)

        self.reset_fit_action = QAction("Reset Fit Overrides", self)
        self.reset_fit_action.triggered.connect(self.reset_all_overrides)

        self.open_dust_estimator_action = QAction("Impact Parameters…", self)
        self.open_dust_estimator_action.setShortcut("Ctrl+Shift+D")
        self.open_dust_estimator_action.setStatusTip(
            "Open the dust velocity and mass estimator tool",
        )
        self.open_dust_estimator_action.triggered.connect(self.action_open_dust_estimator)

        self.open_noise_analysis_action = QAction("Noise Analysis…", self)
        self.open_noise_analysis_action.setShortcut("Ctrl+N")
        self.open_noise_analysis_action.setStatusTip("Inspect noise characteristics for the current event")
        self.open_noise_analysis_action.triggered.connect(self.action_open_noise_analysis)

        self.open_sql_matcher_action = QAction("Accelerator Match…", self)
        self.open_sql_matcher_action.setShortcut("Ctrl+Shift+M")
        self.open_sql_matcher_action.setStatusTip(
            "Match the current event against accelerator SQL records.",
        )
        self.open_sql_matcher_action.triggered.connect(self.action_open_sql_matcher)

        help_icon = self.style().standardIcon(QStyle.StandardPixmap.SP_DialogHelpButton)
        self.help_action = QAction(help_icon, "Documentation Center", self)
        self.help_action.setShortcut("F1")
        self.help_action.setToolTip("Open the documentation center (F1)")
        self.help_action.setStatusTip("Open the searchable documentation center")
        self.help_action.setIconText("?")
        self.help_action.triggered.connect(self.open_documentation_center)

        self.search_docs_action = QAction("Search Documentation…", self)
        self.search_docs_action.setShortcut("Ctrl+F1")
        self.search_docs_action.setStatusTip("Jump straight to the documentation search panel")
        self.search_docs_action.triggered.connect(lambda: self.open_documentation_center(show_search=True))

    def _build_menubar(self):
        menubar = self.menuBar()
        if menubar is None:
            menubar = QMenuBar(self)
            self.setMenuBar(menubar)

        menubar.clear()
        menubar.setStyleSheet("font-size: 14px; background-color: #ffffff; padding: 4px;")

        file_menu = menubar.addMenu("&File")
        file_menu.addAction(self.open_any_action)
        file_menu.addAction(self.open_hdf5_action)
        file_menu.addAction(self.open_cdf_action)
        file_menu.addSeparator()

        save_menu = QMenu("Export Plot", self)
        save_menu.addAction(self.save_png_action)
        save_menu.addAction(self.save_pdf_action)
        save_menu.addAction(self.save_svg_action)
        file_menu.addMenu(save_menu)

        file_menu.addSeparator()
        file_menu.addAction(self.reload_action)
        file_menu.addAction(self.close_file_action)
        file_menu.addSeparator()
        file_menu.addAction(self.quit_action)

        edit_menu = menubar.addMenu("&Edit")
        edit_menu.addAction(self.edit_fit_action)
        edit_menu.addAction(self.reset_fit_action)

        view_menu = menubar.addMenu("&View")
        view_menu.addAction(self.view_structure_action)
        view_menu.addAction(self.open_hdf_explorer_action)
        view_menu.addAction(self.open_variable_definitions_action)
        view_menu.addAction(self.open_dust_estimator_action)
        view_menu.addAction(self.open_noise_analysis_action)
        view_menu.addAction(self.open_sql_matcher_action)

        help_menu = menubar.addMenu("&Help")
        help_menu.addAction(self.help_action)
        help_menu.addAction(self.search_docs_action)
        help_menu.addSeparator()

        self.menu_search_field = QLineEdit(self)
        self.menu_search_field.setPlaceholderText("Search documentation…")
        self.menu_search_field.setClearButtonEnabled(True)
        self.menu_search_field.returnPressed.connect(self._trigger_menu_search)

        search_widget = QWidgetAction(self)
        search_widget.setDefaultWidget(self.menu_search_field)
        help_menu.addAction(search_widget)

    def _trigger_menu_search(self) -> None:
        query = self.menu_search_field.text().strip()
        self.open_documentation_center(initial_query=query, show_search=True)

    def _build_toolbar(self):
        tb = QToolBar("Main", self)
        tb.setIconSize(QSize(22, 22))
        tb.setMovable(False)
        tb.setFloatable(False)
        tb.setStyleSheet("QToolBar { background-color: #ffffff; border: none; padding: 8px; spacing: 8px; }")

        toolbar_container = QWidget(self)
        toolbar_container.setObjectName("quicklookToolbarContainer")
        toolbar_container.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        toolbar_container.setStyleSheet(
            "#quicklookToolbarContainer { background-color: #ffffff; border-radius: 12px; }"
        )

        toolbar_layout = QHBoxLayout(toolbar_container)
        toolbar_layout.setContentsMargins(0, 0, 0, 0)
        toolbar_layout.setSpacing(0)
        toolbar_layout.addWidget(tb)

        scroll = QScrollArea(self)
        scroll.setObjectName("quicklookToolbarScrollArea")
        scroll.setWidget(toolbar_container)
        scroll.setWidgetResizable(False)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        scroll.setStyleSheet(
            """
            QScrollArea#quicklookToolbarScrollArea {
                border: none;
                background-color: #ffffff;
            }
            QScrollArea#quicklookToolbarScrollArea > QWidget > QWidget {
                background-color: #ffffff;
            }
            """
        )

        self.vbox.addWidget(scroll)

        tb.addAction(self.open_any_action)
        tb.addAction(self.open_hdf5_action)
        tb.addAction(self.open_cdf_action)
        tb.addSeparator()
        tb.addAction(self.reload_action)

        export_button = QToolButton(self)
        export_button.setText("Export Plot")
        export_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        export_menu = QMenu(export_button)
        export_menu.addAction(self.save_png_action)
        export_menu.addAction(self.save_pdf_action)
        export_menu.addAction(self.save_svg_action)
        export_button.setMenu(export_menu)
        export_button.setStyleSheet(
            """
            QToolButton {
                font-size: 15px;
                font-weight: 600;
                padding: 6px 14px;
                border-radius: 12px;
                background-color: #4263eb;
                color: #ffffff;
            }
            QToolButton:hover {
                background-color: #3b5bdb;
            }
            """
        )
        tb.addWidget(export_button)

        tb.addSeparator()

        act_dust = QAction("Dust Composition…", self)
        act_dust.setShortcut("Ctrl+D")
        act_dust.setToolTip("Open the dust composition analysis window for the current event.")
        act_dust.triggered.connect(self.action_open_dust_composition)
        self.addAction(act_dust)

        self.dust_button = QPushButton("Dust Composition", self)
        self.dust_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.dust_button.setMinimumHeight(46)
        self.dust_button.setStyleSheet(
            """
            QPushButton {
                font-size: 16px;
                font-weight: 700;
                padding: 10px 22px;
                border-radius: 14px;
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                                 stop:0 #845ef7, stop:1 #5c7cfa);
                color: #ffffff;
                border: 1px solid #5f3dc4;
            }
            QPushButton:hover {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                                 stop:0 #7048e8, stop:1 #4c6ef5);
            }
            QPushButton:pressed {
                background-color: #364fc7;
            }
            """
        )
        self.dust_button.clicked.connect(act_dust.trigger)
        tb.addWidget(self.dust_button)

        act_dust_estimator = self.open_dust_estimator_action
        self.addAction(act_dust_estimator)

        self.dust_estimator_button = QPushButton("Impact Parameters", self)
        self.dust_estimator_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.dust_estimator_button.setMinimumHeight(46)
        self.dust_estimator_button.setStyleSheet(
            """
            QPushButton {
                font-size: 16px;
                font-weight: 700;
                padding: 10px 22px;
                border-radius: 14px;
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                                 stop:0 #0ca678, stop:1 #099268);
                color: #ffffff;
                border: 1px solid #087f5b;
            }
            QPushButton:hover {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                                 stop:0 #099268, stop:1 #087f5b);
            }
            QPushButton:pressed {
                background-color: #066649;
            }
            """
        )
        self.dust_estimator_button.clicked.connect(act_dust_estimator.trigger)
        tb.addWidget(self.dust_estimator_button)

        self.sql_match_button = QPushButton("Accelerator Match", self)
        self.sql_match_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.sql_match_button.setMinimumHeight(46)
        self.sql_match_button.setStyleSheet(
            """
            QPushButton {
                font-size: 16px;
                font-weight: 700;
                padding: 10px 22px;
                border-radius: 14px;
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                                 stop:0 #228be6, stop:1 #1c7ed6);
                color: #ffffff;
                border: 1px solid #1864ab;
            }
            QPushButton:hover {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                                 stop:0 #1c7ed6, stop:1 #1971c2);
            }
            QPushButton:pressed {
                background-color: #184a8b;
            }
            """
        )
        self.sql_match_button.clicked.connect(self.open_sql_matcher_action.trigger)
        tb.addWidget(self.sql_match_button)

        act_noise = self.open_noise_analysis_action
        self.addAction(act_noise)

        self.noise_button = QPushButton("Noise Analysis", self)
        self.noise_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.noise_button.setMinimumHeight(46)
        self.noise_button.setStyleSheet(
            """
            QPushButton {
                font-size: 16px;
                font-weight: 700;
                padding: 10px 22px;
                border-radius: 14px;
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                                 stop:0 #4dabf7, stop:1 #3b82f6);
                color: #ffffff;
                border: 1px solid #1c7ed6;
            }
            QPushButton:hover {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                                 stop:0 #3a8de0, stop:1 #2962d9);
            }
            QPushButton:pressed {
                background-color: #1c7ed6;
            }
            """
        )
        self.noise_button.clicked.connect(act_noise.trigger)
        tb.addWidget(self.noise_button)

        act_reload = QAction("Reload", self)
        act_reload.setShortcut("Ctrl+R")
        act_reload.triggered.connect(self.reload_current)
        tb.addAction(act_reload)
        tb.addAction(self.view_structure_action)
        tb.addAction(self.open_hdf_explorer_action)
        if launch_variable_definitions_viewer is not None:
            tb.addAction(self.open_variable_definitions_action)
        tb.addSeparator()

        tb.addAction(self.close_file_action)
        tb.addSeparator()

        tb.addAction(self.quit_action)
        tb.addSeparator()

        tb.addAction(self.help_action)
        tb.addSeparator()
        label = QLabel("Event:", self)
        label.setStyleSheet("font-size: 15px; font-weight: bold; padding-right: 6px;")
        tb.addWidget(label)

        self.event_combo = QComboBox(self)
        self.event_combo.setMinimumWidth(220)
        self.event_combo.setStyleSheet("font-size: 15px; min-height: 36px;")
        self.event_combo.currentIndexChanged.connect(self.on_event_changed)
        tb.addWidget(self.event_combo)

        toolbar_container.adjustSize()
        scroll.setMinimumHeight(tb.sizeHint().height() + 16)

    def _build_branding_banner(self) -> Optional[QWidget]:
        pixmap = _load_brand_pixmap(max_height=64)
        if pixmap is None:
            return None

        container = QWidget(self)
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)

        logo_label = QLabel()
        logo_label.setPixmap(pixmap)
        logo_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        layout.addWidget(logo_label)

        title_label = QLabel("SpectrumPY: Flight Edition")
        title_label.setStyleSheet("font-size: 18px; font-weight: 600; color: #1f2937;")
        title_label.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(title_label)

        layout.addStretch()
        return container

    def _build_controls(self):
        panel = QWidget(self)
        panel.setObjectName("controlPanel")
        panel.setStyleSheet(
            """
            QWidget#controlPanel {
                background-color: #ffffff;
                border-radius: 16px;
                border: 1px solid #d6dfee;
                padding: 16px;
            }
            """
        )
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(0, 0, 0, 0)
        panel_layout.setSpacing(8)
        panel_layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        heading = QLabel("Display Controls", self)
        heading.setObjectName("controlHeading")
        heading.setStyleSheet("font-size: 19px; font-weight: 600;")
        panel_layout.addWidget(heading)

        sub_label = QLabel("Choose which channels and overlays are shown:", self)
        sub_label.setStyleSheet("font-size: 15px; color: #4a5568;")
        panel_layout.addWidget(sub_label)

        channel_widget = QWidget(self)
        grid = QGridLayout(channel_widget)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setSpacing(10)
        self.channel_buttons: Dict[str, QPushButton] = {}

        toggle_style = (
            """
            QPushButton {
                font-size: 16px;
                font-weight: 600;
                padding: 10px 18px;
                border-radius: 12px;
                background-color: #e8f0ff;
                border: 1px solid #c3d0ff;
            }
            QPushButton:hover {
                background-color: #dbe4ff;
            }
            QPushButton:checked {
                background-color: #4c6ef5;
                color: #ffffff;
                border: 1px solid #364fc7;
            }
            """
        )
        primary_style = (
            """
            QPushButton {
                font-size: 16px;
                font-weight: 600;
                padding: 10px 18px;
                border-radius: 12px;
                background-color: #4263eb;
                color: #ffffff;
            }
            QPushButton:hover {
                background-color: #3b5bdb;
            }
            """
        )

        self._primary_channel_buttons: List[QPushButton] = []
        for idx, name in enumerate(CHANNEL_ORDER):
            btn = QPushButton(name, self)
            btn.setCheckable(True)
            btn.setChecked(True)
            btn.setMinimumHeight(50)
            btn.setStyleSheet(toggle_style)
            btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            btn.clicked.connect(lambda checked, channel=name: self.on_channel_toggled(channel, checked))
            self.channel_buttons[name] = btn
            grid.addWidget(btn, idx // 3, idx % 3)
            self._primary_channel_buttons.append(btn)

        panel_layout.addWidget(channel_widget)

        toggle_row = QHBoxLayout()
        toggle_row.setSpacing(10)

        self.overlay_button = QPushButton("Overlay same time axis", self)
        self.overlay_button.setCheckable(True)
        self.overlay_button.setMinimumHeight(50)
        self.overlay_button.setStyleSheet(toggle_style)
        self.overlay_button.setToolTip("When enabled, channels with the same time base are drawn together.")
        self.overlay_button.clicked.connect(self.on_overlay_toggled)
        toggle_row.addWidget(self.overlay_button)

        self.fit_buttons: Dict[str, QPushButton] = {}
        for channel in sorted(FIT_ELIGIBLE_CHANNELS):
            btn = QPushButton(f"Show {channel} Fit", self)
            btn.setCheckable(True)
            btn.setMinimumHeight(50)
            btn.setStyleSheet(toggle_style)
            btn.setToolTip("Overlay fit curves when available.")
            btn.clicked.connect(lambda checked, chan=channel: self.on_fit_toggled(chan, checked))
            toggle_row.addWidget(btn)
            self.fit_buttons[channel] = btn

        self.edit_params_button = QPushButton("Edit Fit Parameters", self)
        self.edit_params_button.setMinimumHeight(50)
        self.edit_params_button.setStyleSheet(primary_style)
        self.edit_params_button.clicked.connect(self.open_fit_parameter_dialog)
        toggle_row.addWidget(self.edit_params_button)

        toggle_row.addStretch(1)
        panel_layout.addLayout(toggle_row)

        self._harmonize_primary_button_widths()
        QTimer.singleShot(0, self._harmonize_primary_button_widths)

        self.vbox.addWidget(panel)

    def _harmonize_primary_button_widths(self) -> None:
        """Ensure channel toggles share the width of the primary action button."""

        if not getattr(self, "_primary_channel_buttons", None):
            return

        reference_widgets = [self.edit_params_button, self.overlay_button, *self.fit_buttons.values()]
        reference_width = 0
        for widget in reference_widgets:
            if widget is None:
                continue
            reference_width = max(reference_width, widget.sizeHint().width())

        if reference_width <= 0:
            return

        reference_height = 0
        for widget in reference_widgets:
            if widget is None:
                continue
            reference_height = max(reference_height, widget.sizeHint().height())

        for btn in self._primary_channel_buttons:
            btn.setMinimumWidth(reference_width)
            btn.setMaximumWidth(reference_width)
            btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
            if reference_height > 0:
                btn.setFixedHeight(max(btn.minimumHeight(), reference_height))

    def _reset_layout_engine(self) -> None:
        """Re-enable Matplotlib's constrained layout after clearing the figure."""

        try:
            self.figure.set_constrained_layout(True)
        except Exception:
            try:
                self.figure.set_layout_engine("constrained")
            except Exception:
                pass

    def _update_canvas_geometry(self, axis_count: int) -> None:
        """Resize the canvas to keep stacked plots readable within a scroll area."""

        axis_count = max(1, axis_count)
        base_height = 6.5
        per_axis = 2.6
        target_height = max(base_height, per_axis * axis_count)

        try:
            self.figure.set_size_inches(self.figure.get_figwidth(), target_height, forward=True)
        except Exception:
            try:
                self.figure.set_figheight(target_height)
            except Exception:
                pass

        target_pixels = int(target_height * self.figure.get_dpi())
        if target_pixels > 0:
            self.canvas.setMinimumHeight(target_pixels)
            self.canvas.resize(self.canvas.width(), target_pixels)
            self.canvas.updateGeometry()

    def open_documentation_center(
        self,
        initial_query: Optional[str] = None,
        *,
        show_search: bool = False,
    ) -> None:
        query = initial_query or ""
        if self._documentation_center is None:
            self._documentation_center = DocumentationCenter(self, initial_query=query)
            self._documentation_center.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)

            def _clear_reference(_object=None) -> None:
                self._documentation_center = None

            self._documentation_center.destroyed.connect(_clear_reference)
        else:
            if query:
                self._documentation_center.set_query(query)
            elif not self._documentation_center.isVisible():
                self._documentation_center.set_query("")

        if self._documentation_center is None:
            return

        self._documentation_center.show()
        self._documentation_center.raise_()
        self._documentation_center.activateWindow()

        if show_search:
            self._documentation_center.focus_search()

    # ---- Actions ---------------------------------------------------------
    def action_open(self, preferred: Optional[str] = None):
        chosen = prompt_for_data_file(self, preferred=preferred)
        if chosen:
            self.open_file(chosen)

    def action_view_structure(self):
        if not self._filename or not self._data_source:
            QMessageBox.information(
                self,
                "No File Loaded",
                "Open a data file to browse its structure.",
            )
            return

        if not self._data_source.supports_structure_viewer():
            QMessageBox.information(
                self,
                "Viewer Unavailable",
                "A structure viewer is not available for this data source.",
            )
            return

        try:
            viewer = self._data_source.launch_structure_viewer(parent=self)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Viewer Error",
                f"Unable to launch the data browser:\n{exc}",
            )
            return

        viewer.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        viewer.raise_()
        viewer.activateWindow()

        self._child_windows.append(viewer)

        def _cleanup(*_args):
            if viewer in self._child_windows:
                self._child_windows.remove(viewer)

        viewer.destroyed.connect(_cleanup)

    def action_open_hdf_explorer(self) -> None:
        if not self._filename:
            QMessageBox.information(
                self,
                "No File Loaded",
                "Open an HDF5 file to launch the HDF Explorer.",
            )
            return

        suffix = Path(self._filename).suffix.lower()
        if suffix not in {".h5", ".hdf5"}:
            QMessageBox.information(
                self,
                "Unsupported File",
                "The HDF Explorer is only available for HDF5 products.",
            )
            return

        try:
            explorer_module = importlib.import_module("spectrumpy_flight.HDF_Explorer")
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Viewer Error",
                f"Unable to import the HDF Explorer module:\n{exc}",
            )
            return

        explorer_class = getattr(explorer_module, "HDFDataExplorer", None)
        if explorer_class is None:
            QMessageBox.critical(
                self,
                "Viewer Error",
                "The HDF Explorer entry point is unavailable in this installation.",
            )
            return

        try:
            window = explorer_class(self._filename)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Viewer Error",
                f"Unable to launch the HDF Explorer:\n{exc}",
            )
            return

        window.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        window.show()
        window.raise_()
        window.activateWindow()

        self._child_windows.append(window)

        def _cleanup(*_args):
            if window in self._child_windows:
                self._child_windows.remove(window)

        window.destroyed.connect(_cleanup)

    def action_open_variable_definitions(self):
        if launch_variable_definitions_viewer is None:
            QMessageBox.information(
                self,
                "Viewer Unavailable",
                "The variable definitions viewer is not available in this environment.",
            )
            return

        try:
            window = launch_variable_definitions_viewer(parent=self)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Viewer Error",
                f"Unable to launch the variable definitions viewer:\n{exc}",
            )
            return

        window.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        window.raise_()
        window.activateWindow()

        self._child_windows.append(window)

        def _cleanup(*_args):
            if window in self._child_windows:
                self._child_windows.remove(window)

        window.destroyed.connect(_cleanup)

    def action_open_dust_composition(self):
        if not self._h5 or not self._current_event:
            QMessageBox.information(
                self,
                "No Event",
                "Open an HDF5 file and select an event before analysing dust composition.",
            )
            return

        try:
            window = launch_dust_composition_window(
                self._h5,
                self._current_event,
                parent=self,
                event_names=self._events,
                on_event_changed=self._handle_child_event_change,
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Dust Composition Error",
                f"Unable to launch the dust composition window:\n{exc}",
            )
            return

        window.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        window.show()

        self._child_windows.append(window)

        def _cleanup(*_args):
            if window in self._child_windows:
                self._child_windows.remove(window)

        window.destroyed.connect(_cleanup)

    def action_open_dust_estimator(self):
        kwargs = {"parent": self}
        if self._h5 is not None:
            kwargs["h5"] = self._h5
        if self._current_event:
            kwargs["event_name"] = self._current_event
        if self._events:
            kwargs["event_names"] = self._events
            kwargs["on_event_changed"] = self._handle_child_event_change

        try:
            window = launch_dust_estimator_window(**kwargs)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Impact Parameters Error",
                f"Unable to launch the dust estimator window:\n{exc}",
            )
            return

        window.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        window.show()

        self._child_windows.append(window)

        def _cleanup(*_args):
            if window in self._child_windows:
                self._child_windows.remove(window)

        window.destroyed.connect(_cleanup)

    def action_open_noise_analysis(self):
        if not self._current_event or not self._data_source:
            QMessageBox.information(
                self,
                "No Event",
                "Open a data file and select an event before launching noise analysis.",
            )
            return

        available = False
        for channel in CHANNEL_ORDER:
            values, _times = self._resolve_channel_data(self._current_event, channel)
            if values is None:
                continue
            flat = np.asarray(values, dtype=float).ravel()
            flat = flat[np.isfinite(flat)]
            if flat.size:
                available = True
                break
        if not available:
            QMessageBox.information(
                self,
                "Noise Analysis",
                "No channel data are available for noise analysis in this event.",
            )
            return

        channel_metas = [
            ChannelMeta(
                name=name,
                dataset=definition.dataset,
                time_dataset=definition.time_dataset,
                unit=FAMILY_UNITS.get(definition.family, ""),
            )
            for name, definition in CHANNEL_DEFS.items()
        ]

        def loader(event: str, channel: str) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
            values, times = self._resolve_channel_data(event, channel)
            return (
                None if values is None else np.array(values, copy=True),
                None if times is None else np.array(times, copy=True),
            )

        try:
            window = launch_noise_analysis_window(
                event_name=self._current_event,
                channels=channel_metas,
                loader=loader,
                event_names=self._events,
                on_event_changed=self._handle_child_event_change,
                parent=self,
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Noise Analysis Error",
                f"Unable to launch the noise analysis window:\n{exc}",
            )
            return

        window.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        window.show()

        self._child_windows.append(window)

        def _cleanup(*_args):
            if window in self._child_windows:
                self._child_windows.remove(window)

        window.destroyed.connect(_cleanup)

    def action_open_sql_matcher(self):
        if not self._current_event or not self._data_source:
            QMessageBox.information(
                self,
                "No Event",
                "Open a data file and select an event before matching SQL records.",
            )
            return

        try:
            window = launch_sql_matcher_window(
                self._data_source,
                self._current_event,
                event_names=self._events,
                parent=self,
                h5_handle=self._h5,
                on_event_changed=self._handle_child_event_change,
                status_callback=lambda message, duration=6000: self.statusBar().showMessage(message, duration),
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "SQL Match Error",
                f"Unable to launch the accelerator matching interface:\n{exc}",
            )
            return

        self._child_windows.append(window)

        def _cleanup(*_args):
            if window in self._child_windows:
                self._child_windows.remove(window)

        window.destroyed.connect(_cleanup)

    def close_current_file(self):
        if not self._filename and not self._data_source:
            return
        self._reset_state()
        self.plot_event(None)
        self.statusBar().showMessage("No data file loaded.")

    def reset_all_overrides(self):
        if not (self._fit_param_overrides or self._fit_result_overrides or self._fit_time_overrides):
            QMessageBox.information(
                self,
                "No Overrides",
                "No in-memory fit overrides are currently applied.",
            )
            return

        self._fit_param_overrides.clear()
        self._fit_result_overrides.clear()
        self._fit_time_overrides.clear()
        self._fit_cache.clear()
        self._baseline_cache.clear()
        self.plot_event(self._current_event)
        self.statusBar().showMessage("Cleared all in-memory fit edits.", 6000)

    def save_plot(self, fmt: str):
        fmt = fmt.lower()
        if fmt not in {"png", "pdf", "svg"}:
            raise ValueError(f"Unsupported export format: {fmt}")

        if self.figure is None:
            return

        base_name = "idex_quicklook"
        if self._filename:
            base_name = Path(self._filename).stem
        if self._current_event:
            base_name += f"_event_{self._current_event}"

        suggested = Path(self._tmpdir.name) / f"{base_name}.{fmt}"

        path, _ = QFileDialog.getSaveFileName(
            self,
            f"Export Plot ({fmt.upper()})",
            str(suggested),
            f"{fmt.upper()} files (*.{fmt});;All files (*)",
        )

        if not path:
            return

        export_path = Path(path)
        if export_path.suffix.lower() != f".{fmt}":
            export_path = export_path.with_suffix(f".{fmt}")

        try:
            self.figure.savefig(str(export_path), format=fmt, bbox_inches="tight")
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Export Failed",
                f"Could not export the plot:\n{exc}",
            )
            return

        self.statusBar().showMessage(f"Saved plot to {export_path}", 6000)

    # ---- Data helpers -----------------------------------------------------
    def _reset_state(self):
        if self._h5 is not None:
            try:
                self._h5.close()
            except Exception:
                pass
        self._h5 = None
        if self._data_source is not None:
            try:
                self._data_source.close()
            except Exception:
                pass
        self._data_source = None
        self._filename = None
        self._events = []
        self._current_event = None
        self._fit_cache.clear()
        self._fit_param_overrides.clear()
        self._fit_fixed_overrides.clear()
        self._fit_result_overrides.clear()
        self._fit_time_overrides.clear()
        self._baseline_cache.clear()
        self._rise_metric_cache.clear()
        self._low_rate_waveform_cache.clear()
        self._show_fit = {name: False for name in FIT_ELIGIBLE_CHANNELS}

        self.event_combo.blockSignals(True)
        self.event_combo.clear()
        self.event_combo.blockSignals(False)

    def _get_dataset(self, event: str, dataset: str) -> Optional[np.ndarray]:
        if not self._data_source:
            return None
        return self._data_source.get_dataset(event, dataset)

    def _get_dataset_by_path(self, path: str) -> Optional[np.ndarray]:
        if not self._data_source:
            return None
        cleaned = path.strip("/")
        if not cleaned:
            return None
        parts = cleaned.split("/", 1)
        if len(parts) == 1:
            if not self._current_event:
                return None
            return self._data_source.get_dataset(self._current_event, parts[0])
        event, dataset = parts
        return self._data_source.get_dataset(event, dataset)

    def _update_channel_button_states(self, event_name: str) -> None:
        if not self.channel_buttons:
            return

        for name, definition in CHANNEL_DEFS.items():
            btn = self.channel_buttons.get(name)
            if btn is None:
                continue

            has_data = False
            if self._data_source is not None:
                values = self._get_dataset(event_name, definition.dataset)
                times = self._get_dataset(event_name, definition.time_dataset)
                has_data = _has_samples(values) and _has_samples(times)

            with QSignalBlocker(btn):
                btn.setEnabled(has_data)
                if not has_data:
                    btn.setChecked(False)
                    btn.setToolTip(f"{name} data unavailable for this event.")
                else:
                    btn.setChecked(name in self.selected_channels)
                    btn.setToolTip(f"Toggle {name} channel display.")

    def _rise_dataset_name(self, channel: str, suffix: str) -> str:
        return f"Analysis/{channel} {suffix}"

    def _load_rise_metrics(self, event: str, channel: str) -> Dict[str, float]:
        cache_key = (event, channel)
        cached = self._rise_metric_cache.get(cache_key)
        if cached is not None:
            return cached

        metrics = {key: float("nan") for key in RISE_METRIC_SUFFIXES}
        for key, suffix in RISE_METRIC_SUFFIXES.items():
            dataset = self._get_dataset(event, self._rise_dataset_name(channel, suffix))
            if dataset is None:
                continue
            arr = np.asarray(dataset, dtype=float).ravel()
            if arr.size == 0:
                continue
            value = float(arr[0])
            if np.isfinite(value):
                metrics[key] = value

        self._rise_metric_cache[cache_key] = metrics
        return metrics

    def _write_rise_metrics(self, event: str, channel: str, metrics: Dict[str, float]) -> None:
        if self._h5 is None or h5py is None:
            return
        try:
            analysis_group = self._h5.require_group(f"{event}/Analysis")
        except Exception:
            return

        updated = False
        for key, suffix in RISE_METRIC_SUFFIXES.items():
            value = metrics.get(key)
            if value is None or not np.isfinite(value):
                continue
            dataset_name = f"{channel} {suffix}"
            if dataset_name in analysis_group:
                continue
            try:
                analysis_group.create_dataset(dataset_name, data=np.array([float(value)], dtype=float))
                updated = True
            except Exception:
                continue

        if updated:
            try:
                self._h5.flush()
            except Exception:
                pass

    def _ensure_rise_metrics(
        self,
        event: str,
        channel: str,
        time_values: Iterable[float],
        fit_values: Iterable[float],
    ) -> Dict[str, float]:
        metrics = dict(self._load_rise_metrics(event, channel))
        missing = [key for key, value in metrics.items() if not np.isfinite(value)]
        if not missing:
            return metrics

        computed = compute_rise_metrics(time_values, fit_values)
        metrics.update(computed)
        self._rise_metric_cache[(event, channel)] = metrics
        self._write_rise_metrics(event, channel, metrics)
        return metrics

    def _write_fit_parameters(self, dataset_path: str, values: np.ndarray) -> bool:
        if self._h5 is None or h5py is None:
            return False

        cleaned = dataset_path.strip("/")
        if not cleaned:
            return False

        try:
            parent_path, dataset_name = cleaned.rsplit("/", 1)
        except ValueError:
            return False

        try:
            parent = self._h5[parent_path]
        except Exception:
            return False

        if not isinstance(parent, h5py.Group):
            return False

        data = np.array(values, copy=True)
        try:
            if dataset_name in parent:
                existing = parent[dataset_name]
                if isinstance(existing, h5py.Dataset) and existing.shape == data.shape:
                    existing[...] = data
                else:
                    try:
                        del parent[dataset_name]
                    except Exception:
                        return False
                    parent.create_dataset(dataset_name, data=data)
            else:
                parent.create_dataset(dataset_name, data=data)
        except Exception:
            return False

        try:
            self._h5.flush()
        except Exception:
            pass
        return True

    def _resolve_channel_data(self, event: str, channel: str) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        definition = CHANNEL_DEFS.get(channel)
        if not definition:
            return None, None
        values = self._get_dataset(event, definition.dataset)
        times = self._get_dataset(event, definition.time_dataset)
        return values, times

    def _handle_child_event_change(self, event_name: str) -> None:
        if not event_name or event_name not in self._events:
            return
        index = self._events.index(event_name)
        if self.event_combo.currentIndex() != index:
            self.event_combo.setCurrentIndex(index)
        else:
            self.plot_event(event_name)

    def _broadcast_event_to_children(self, event_name: Optional[str]) -> None:
        for window in list(self._child_windows):
            if hasattr(window, "set_current_event"):
                try:
                    window.set_current_event(event_name)
                except Exception:
                    continue

    def open_file(self, path: str, preferred_event: Optional[str] = None):
        self._reset_state()

        suffix = Path(path).suffix.lower()
        h5_handle = None

        try:
            if h5py is not None and suffix in {".h5", ".hdf5"}:
                try:
                    h5_handle = h5py.File(path, "r+")
                except OSError:
                    h5_handle = h5py.File(path, "r")
            source = create_data_source(path)
        except ImportError as exc:
            QMessageBox.critical(
                self,
                "Open Error",
                f"Failed to open file:\n{path}\n\n{exc}",
            )
            if h5_handle is not None:
                try:
                    h5_handle.close()
                except Exception:
                    pass
            self.plot_event(None)
            return
        except Exception as exc:
            if h5_handle is not None:
                try:
                    h5_handle.close()
                except Exception:
                    pass
            QMessageBox.critical(
                self,
                "Open Error",
                f"Failed to open file:\n{path}\n\n{exc}",
            )
            self.plot_event(None)
            return

        if h5_handle is None and h5py is not None and isinstance(source, HDF5DataSource):
            try:
                h5_handle = h5py.File(path, "r+")
            except OSError:
                try:
                    h5_handle = h5py.File(path, "r")
                except Exception:
                    h5_handle = None

        self._h5 = h5_handle
        self._data_source = source
        self._filename = path

        events = source.list_events()
        if not events:
            QMessageBox.warning(self, "No Events", "No top-level event groups found in this file.")
        self._events = events

        self.event_combo.blockSignals(True)
        self.event_combo.clear()
        self.event_combo.addItems(self._events)
        self.event_combo.blockSignals(False)

        target_event = None
        if preferred_event and preferred_event in self._events:
            target_event = preferred_event
        elif self._events:
            target_event = self._events[0]

        if target_event:
            idx = self._events.index(target_event)
            self.event_combo.blockSignals(True)
            self.event_combo.setCurrentIndex(idx)
            self.event_combo.blockSignals(False)
            self.plot_event(target_event)
        else:
            self.plot_event(None)

    def reload_current(self):
        if self._filename:
            self.open_file(self._filename, preferred_event=self._current_event)

    def on_event_changed(self, idx: int):
        if 0 <= idx < len(self._events):
            self.plot_event(self._events[idx])

    def on_channel_toggled(self, channel: str, checked: bool):
        if checked:
            self.selected_channels.add(channel)
        else:
            self.selected_channels.discard(channel)
        self.plot_event(self._current_event)

    def on_overlay_toggled(self, checked: bool):
        self.plot_event(self._current_event)

    def on_fit_toggled(self, channel: str, checked: bool):
        if not self._current_event or not self._data_source:
            self._show_fit[channel] = False
            if channel in self.fit_buttons:
                self.fit_buttons[channel].setChecked(False)
            return

        data = self.get_fit_data(self._current_event, channel)
        if checked and not data.has_overlay():
            QMessageBox.information(self, "No Fit", f"No fit curves were found for {channel} in this event.")
            self._show_fit[channel] = False
            if channel in self.fit_buttons:
                self.fit_buttons[channel].setChecked(False)
            return

        self._show_fit[channel] = checked
        self.plot_event(self._current_event)

    # ---- Plotting --------------------------------------------------------
    def plot_event(self, event_name: Optional[str]):
        self.figure.clear()
        self._reset_layout_engine()
        try:
            self.figure.set_constrained_layout_pads(wspace=0.06, hspace=0.28)
        except Exception:
            pass

        if not self._data_source or not event_name:
            self._broadcast_event_to_children(None)
            self._current_event = None
            ax = self.figure.add_subplot(111)
            ax.text(
                0.5,
                0.5,
                "Open a data file and choose an event to visualize.",
                ha="center",
                va="center",
                transform=ax.transAxes,
                fontsize=18,
            )
            ax.axis("off")
            self._update_canvas_geometry(1)
            self.canvas.draw_idle()
            self.refresh_fit_controls()
            self.update_status_text()
            return

        self._current_event = event_name
        self._broadcast_event_to_children(event_name)
        self._update_channel_button_states(event_name)
        self.refresh_fit_controls()

        selected = [name for name in CHANNEL_ORDER if self.channel_buttons.get(name) and self.channel_buttons[name].isChecked()]
        missing: List[str] = []

        self.figure.suptitle(
            f"{os.path.basename(self._filename or '')} — Event {event_name}",
            fontsize=20,
            fontweight="bold",
        )

        if not selected:
            ax = self.figure.add_subplot(111)
            ax.text(
                0.5,
                0.5,
                "No channels selected.\nUse the buttons above to enable channels.",
                ha="center",
                va="center",
                transform=ax.transAxes,
                fontsize=18,
            )
            ax.axis("off")
            self._update_canvas_geometry(1)
            self.canvas.draw_idle()
            self.update_status_text()
            return

        overlay_mode = self.overlay_button.isChecked()

        axes: List[Any] = []
        axis_count = 1

        try:
            if overlay_mode:
                families: List[Tuple[str, List[str]]] = []
                high = [ch for ch in selected if CHANNEL_DEFS[ch].family == FAMILY_HIGH]
                low = [ch for ch in selected if CHANNEL_DEFS[ch].family == FAMILY_LOW]
                if high:
                    families.append((FAMILY_HIGH, high))
                if low:
                    families.append((FAMILY_LOW, low))

                if not families:
                    ax = self.figure.add_subplot(111)
                    ax.text(
                        0.5,
                        0.5,
                        "No compatible channels selected for overlay.",
                        ha="center",
                        va="center",
                        transform=ax.transAxes,
                        fontsize=18,
                    )
                    ax.axis("off")
                else:
                    for idx, (family, channels) in enumerate(families, start=1):
                        ax = self.figure.add_subplot(len(families), 1, idx)
                        axes.append(ax)
                        plotted_any = False
                        for channel in channels:
                            plotted_any |= self._plot_channel(ax, event_name, channel, overlay_mode=True, missing_channels=missing)
                        self._style_overlay_axis(ax, family, bottom=(idx == len(families)))
            else:
                ordered = [ch for ch in CHANNEL_ORDER if ch in selected]
                if not ordered:
                    ax = self.figure.add_subplot(111)
                    ax.text(
                        0.5,
                        0.5,
                        "No channels available to plot.",
                        ha="center",
                        va="center",
                        transform=ax.transAxes,
                        fontsize=18,
                    )
                    ax.axis("off")
                else:
                    grid = self.figure.add_gridspec(len(ordered), 1, hspace=0.3)
                    for idx, channel in enumerate(ordered):
                        ax = self.figure.add_subplot(grid[idx, 0])
                        axes.append(ax)
                        plotted_any = self._plot_channel(ax, event_name, channel, overlay_mode=False, missing_channels=missing)
                        next_family = None
                        if idx + 1 < len(ordered):
                            next_family = CHANNEL_DEFS[ordered[idx + 1]].family
                        self._style_single_axis(
                            ax,
                            channel=channel,
                            bottom=(idx == len(ordered) - 1),
                            next_family=next_family,
                        )
        except Exception as exc:
            self.figure.clear()
            self._reset_layout_engine()
            ax = self.figure.add_subplot(111)
            ax.text(0.5, 0.5, f"Plot error:\n{exc}", ha="center", va="center", transform=ax.transAxes, fontsize=16)
            ax.axis("off")
        else:
            if axes:
                try:
                    self.figure.align_ylabels(axes)
                except Exception:
                    pass
            axis_count = max(len(axes), 1)

        self._update_canvas_geometry(axis_count)
        self.canvas.draw_idle()
        self.update_status_text(missing)

    def _compute_combined_mass_axis(self, event_name: str, times: np.ndarray) -> Optional[MassAxisContext]:
        if not self._data_source:
            return None
        time_values = np.asarray(times, dtype=float).ravel()
        if time_values.size == 0:
            return None

        context_time = time_values
        context_mass: Optional[np.ndarray] = None

        dataset = self._get_dataset(event_name, "Mass")
        if dataset is not None:
            try:
                mass_data = _to_1d(dataset)
            except Exception:
                mass_data = np.array([], dtype=float)
            if mass_data.size:
                m = min(mass_data.size, time_values.size)
                if m > 0:
                    context_mass = np.asarray(mass_data[:m], dtype=float)
                    context_time = time_values[:m]

        attrs = _gather_mass_attributes(self._data_source, event_name)
        calibration = _load_mass_calibration_from_attrs(attrs) if attrs else None
        origin = _coerce_float_attr(attrs.get("MassCalibrationOrigin")) if attrs else None
        if origin is None:
            origin = 0.0
        stretch = _coerce_float_attr(attrs.get("MassStretch")) if attrs else None
        shift = _coerce_float_attr(attrs.get("MassShift")) if attrs else None
        if stretch is not None and (not np.isfinite(stretch) or abs(stretch) < 1.0e-12):
            stretch = None
        if shift is not None and not np.isfinite(shift):
            shift = None

        if context_mass is None:
            base_time = context_time
            if calibration is not None:
                try:
                    context_mass = np.asarray(calibration.tof_to_mass(base_time - origin), dtype=float)
                except Exception:
                    context_mass = None
            if context_mass is None and stretch is not None and shift is not None:
                context_mass = np.asarray(stretch * (base_time - shift), dtype=float)
            if context_mass is None:
                return None

        context = MassAxisContext(
            mass=context_mass,
            time=context_time,
            calibration=calibration,
            origin=origin,
            stretch=stretch,
            shift=shift,
        )
        if context.mass.size == 0:
            return None
        return context

    def _attach_time_axis(self, ax, context: MassAxisContext) -> None:
        if getattr(ax, "_time_axis", None) is not None:
            return
        masses = np.asarray(context.mass, dtype=float)
        times = np.asarray(context.time, dtype=float)
        if masses.size < 2 or times.size < 2:
            return
        twin = ax.twiny()
        twin.set_xlim(ax.get_xlim())

        def _format(value: float, _pos: int) -> str:
            converted = context.mass_to_time([value])
            try:
                numeric = float(np.asarray(converted).ravel()[0])
            except Exception:
                return ""
            if not np.isfinite(numeric):
                return ""
            return f"{numeric:.2f}"

        twin.xaxis.set_major_formatter(FuncFormatter(_format))
        twin.set_xlabel(TIME_AXIS_LABEL, fontsize=14)
        twin.tick_params(axis="x", labelsize=12, width=1.2, length=6)
        twin.set_navigate(False)
        twin.patch.set_visible(False)
        for spine in twin.spines.values():
            spine.set_visible(False)
        twin.grid(False)
        ax._time_axis = twin

    def _plot_channel(self, ax, event_name: str, channel: str, overlay_mode: bool, missing_channels: List[str]) -> bool:
        definition = CHANNEL_DEFS[channel]
        time_data = self._get_dataset(event_name, definition.time_dataset)
        value_data = self._get_dataset(event_name, definition.dataset)

        base_plotted = False
        reason: Optional[str] = None

        use_filtered = False
        filtered_time_data: Optional[np.ndarray] = None
        filtered_value_data: Optional[np.ndarray] = None
        if self._show_fit.get(channel):
            filtered_value_data = self._get_dataset(event_name, f"Analysis/{channel} Filtered Signal")
            filtered_time_data = self._get_dataset(event_name, f"Analysis/{channel} Fit Time")
            if filtered_time_data is None or filtered_value_data is None:
                filtered_time_data = None
                filtered_value_data = None
            else:
                filtered_time = _to_1d(filtered_time_data)
                filtered_values = _to_1d(filtered_value_data)
                n = min(len(filtered_time), len(filtered_values))
                if n:
                    times = np.asarray(filtered_time[:n], dtype=float)
                    values = self._apply_plot_scale(channel, filtered_values[:n])
                    ax.plot(
                        times,
                        values,
                        color="#111111",
                        linewidth=1.1,
                        alpha=0.85,
                        label=None,
                        zorder=2,
                    )
                    base_plotted = True
                    use_filtered = True

        if not use_filtered:
            if time_data is None or value_data is None:
                reason = "Missing data"
            else:
                t = _to_1d(time_data)
                y = _to_1d(value_data)
                n = min(len(t), len(y))
                if n == 0:
                    reason = "Empty dataset"
                else:
                    times = np.asarray(t[:n], dtype=float)
                    values = np.asarray(self._apply_plot_scale(channel, y[:n]), dtype=float)
                    x_values = times
                    context: Optional[MassAxisContext] = None
                    if channel == "TOF Combined" and not overlay_mode:
                        context = self._compute_combined_mass_axis(event_name, times)
                        if context is not None and context.mass.size and values.size:
                            m = min(context.mass.size, values.size)
                            if m > 0:
                                context = context.trimmed(m)
                                values = values[:m]
                                x_values = context.mass
                            else:
                                context = None
                        else:
                            context = None
                    if context is None:
                        x_values = times
                    ax.plot(
                        x_values,
                        values,
                        color="#111111",
                        linewidth=1.1,
                        alpha=0.85,
                        label=None,
                        zorder=2,
                    )
                    if context is not None:
                        ax._custom_xlabel = MASS_AXIS_LABEL
                        ax._mass_axis_context = context
                        self._attach_time_axis(ax, context)
                    base_plotted = True

        fit_plotted = self._plot_fit(ax, event_name, channel, overlay_mode)

        if base_plotted or fit_plotted:
            if not overlay_mode:
                ax.set_ylabel(y_label_with_units(channel), fontsize=16)
            return True

        if reason:
            if not overlay_mode:
                self._draw_missing_message(ax, channel, reason)
            missing_channels.append(channel)
        return False

    def _estimate_baseline(self, event_name: str, channel: str, reference_time: Optional[np.ndarray]) -> float:
        key = (event_name, channel)
        cached = self._baseline_cache.get(key)
        if cached is not None:
            return cached

        baseline_value = 0.0
        if not self._data_source:
            self._baseline_cache[key] = baseline_value
            return baseline_value

        definition = CHANNEL_DEFS.get(channel)
        if not definition:
            self._baseline_cache[key] = baseline_value
            return baseline_value

        raw_data = self._get_dataset(event_name, definition.dataset)
        if raw_data is None:
            self._baseline_cache[key] = baseline_value
            return baseline_value

        raw_values = _to_1d(raw_data)
        if raw_values.size == 0:
            self._baseline_cache[key] = baseline_value
            return baseline_value

        raw_values = self._apply_plot_scale(channel, raw_values)

        times: Optional[np.ndarray] = None
        if reference_time is not None:
            ref = _to_1d(reference_time)
            if ref.size == raw_values.size:
                times = np.asarray(ref, dtype=float)

        if times is None:
            stored_time = self._get_dataset(event_name, definition.time_dataset)
            if stored_time is not None:
                stored = _to_1d(stored_time)
                if stored.size == raw_values.size:
                    times = np.asarray(stored, dtype=float)

        candidate: Optional[float] = None
        if times is not None and times.size == raw_values.size:
            primary_mask = (times >= BASELINE_PRIMARY_WINDOW[0]) & (times <= BASELINE_PRIMARY_WINDOW[1])
            candidate = _masked_mean(raw_values, primary_mask)
            if candidate is None:
                fallback_mask = times < BASELINE_FALLBACK_THRESHOLD
                candidate = _masked_mean(raw_values, fallback_mask)

        if candidate is None:
            count = min(max(1, raw_values.size // 10), raw_values.size)
            subset = raw_values[:count]
            finite = subset[np.isfinite(subset)]
            if finite.size:
                candidate = float(finite.mean())
            else:
                candidate = 0.0

        baseline_value = float(candidate if np.isfinite(candidate) else 0.0)
        self._baseline_cache[key] = baseline_value
        return baseline_value

    def _iter_fit_curves(self, event_name: str, channel: str, data: FitData):
        yielded = False
        skip_baseline = False
        if self._show_fit.get(channel):
            filtered = self._get_dataset(event_name, f"Analysis/{channel} Filtered Signal")
            if filtered is not None:
                filtered_arr = _to_1d(filtered)
                if filtered_arr.size:
                    skip_baseline = True
        for label, _time_path, _value_path, time_values, fit_values in data.iter_time_result_pairs():
            times = np.asarray(time_values, dtype=float)
            values = np.asarray(fit_values, dtype=float)
            baseline_offset = self._estimate_baseline(event_name, channel, times)
            if baseline_offset and not skip_baseline:
                values = values + baseline_offset
            n = min(len(times), len(values))
            if n == 0:
                continue
            yield label, times[:n], values[:n]
            yielded = True

        if yielded or not data.parameter_series or not self._data_source:
            return

        definition = CHANNEL_DEFS.get(channel)
        if not definition:
            return
        base_time_data = self._get_dataset(event_name, definition.time_dataset)
        if base_time_data is None:
            return
        base_time = np.asarray(_to_1d(base_time_data), dtype=float)
        if base_time.size == 0:
            return

        model = FIT_MODEL_BY_CHANNEL.get(channel)
        if not model:
            return

        for path, raw_params in data.iter_parameter_items():
            derived = _fit_paths_from_param(path)
            if derived:
                result_path, time_path = derived
                if result_path in data.value_series and time_path in data.time_series:
                    continue

            param_array = _coerce_parameter_values(raw_params)
            if param_array is None:
                continue

            curve = _evaluate_fit_curve(channel, base_time, param_array)
            if curve is None:
                continue

            fit_values = np.asarray(curve, dtype=float)
            if fit_values.size != base_time.size:
                continue
            baseline_offset = self._estimate_baseline(event_name, channel, base_time)
            if baseline_offset and not skip_baseline:
                fit_values = fit_values + baseline_offset

            label = _label_from_param_path(path)
            yield label, base_time, fit_values

    def _plot_fit(self, ax, event_name: str, channel: str, overlay_mode: bool) -> bool:
        if not self._show_fit.get(channel):
            return False

        data = self.get_fit_data(event_name, channel)
        plotted = False
        for label, time_values, fit_values in self._iter_fit_curves(event_name, channel, data):
            n = min(len(time_values), len(fit_values))
            if n == 0:
                continue

            times = np.asarray(time_values[:n], dtype=float)
            values = np.asarray(fit_values[:n], dtype=float)

            x_values = times
            if channel == "TOF Combined" and not overlay_mode:
                context = getattr(ax, "_mass_axis_context", None)
                if isinstance(context, MassAxisContext):
                    converted = context.time_to_mass(times)
                    if converted.size:
                        x_values = np.asarray(converted, dtype=float)

            ax.plot(
                x_values,
                values,
                color="#c1121f",
                linewidth=2.4,
                label=None,
                zorder=3,
            )

            if channel in RISE_METRIC_CHANNELS:
                metrics = self._ensure_rise_metrics(event_name, channel, times, values)
                t10 = metrics.get("t10")
                v10 = metrics.get("v10")
                t90 = metrics.get("t90")
                v90 = metrics.get("v90")
                marker_kwargs = dict(
                    color="#2563eb",
                    edgecolors="white",
                    linewidths=1.2,
                    zorder=4,
                    s=70,
                )
                if np.isfinite(t10) and np.isfinite(v10):
                    ax.scatter([t10], [v10], **marker_kwargs)
                if np.isfinite(t90) and np.isfinite(v90):
                    ax.scatter([t90], [v90], **marker_kwargs)

            plotted = True
        return plotted

    def _style_overlay_axis(self, ax, family: str, bottom: bool):
        ax.set_facecolor("#f8f9fb")
        ax.grid(True, alpha=0.35)
        ax.tick_params(axis="both", labelsize=14, width=1.5, length=7)
        ax.set_ylabel(FAMILY_YLABELS.get(family, "Channel"), fontsize=16)
        show_x = bottom or family == FAMILY_HIGH
        if show_x:
            ax.set_xlabel(TIME_AXIS_LABEL, fontsize=16)
        else:
            ax.set_xlabel("")

    def _style_single_axis(self, ax, channel: str, bottom: bool, next_family: Optional[str]):
        ax.set_facecolor("#f8f9fb")
        ax.grid(True, alpha=0.35)
        ax.tick_params(axis="both", labelsize=14, width=1.5, length=7)
        current_family = CHANNEL_DEFS.get(channel)
        family_name = current_family.family if current_family else None
        show_x = bottom or (next_family is not None and next_family != family_name)
        custom_label = getattr(ax, "_custom_xlabel", None)
        if show_x:
            if custom_label:
                ax.set_xlabel(custom_label, fontsize=16)
            else:
                ax.set_xlabel(TIME_AXIS_LABEL, fontsize=16)
        else:
            ax.set_xlabel("")

    def _draw_missing_message(self, ax, channel: str, reason: str):
        ax.set_facecolor("#f8f9fb")
        ax.text(0.5, 0.5, f"{channel}\n{reason}", ha="center", va="center", transform=ax.transAxes, fontsize=16)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_frame_on(False)

    def refresh_fit_controls(self):
        if not self._data_source or not self._current_event:
            for btn in self.fit_buttons.values():
                btn.setEnabled(False)
            return

        for channel, btn in self.fit_buttons.items():
            data = self.get_fit_data(self._current_event, channel)
            available = any(True for _ in self._iter_fit_curves(self._current_event, channel, data))
            btn.setEnabled(available)
            if not available:
                btn.setChecked(False)
                self._show_fit[channel] = False
                btn.setToolTip("No fit curve found for this event.")
            else:
                btn.setToolTip("Overlay the available fit curve on the channel plot.")

    def update_status_text(self, missing: Optional[List[str]] = None):
        parts: List[str] = []
        event_label = self._current_event or "–"
        parts.append(f"Event {event_label}")

        channels = [ch for ch in CHANNEL_ORDER if ch in self.selected_channels and self.channel_buttons.get(ch) and self.channel_buttons[ch].isChecked()]
        parts.append("Channels: " + (", ".join(channels) if channels else "none"))
        parts.append(f"Overlay: {'ON' if self.overlay_button.isChecked() else 'OFF'}")

        fits_on = [ch for ch, state in self._show_fit.items() if state]
        if fits_on:
            parts.append("Fits: " + ", ".join(sorted(fits_on)))

        if missing:
            parts.append("Missing: " + ", ".join(sorted(set(missing))))

        edited = sorted({ch for (evt, ch, _path) in self._fit_param_overrides.keys() if evt == self._current_event})
        if edited:
            parts.append("Edited params: " + ", ".join(edited))

        self.statusBar().showMessage(" | ".join(parts))

    # ---- Fit data helpers -----------------------------------------------
    def get_fit_data(self, event_name: str, channel: str) -> FitData:
        key = (event_name, channel)
        if key in self._fit_cache:
            return self._fit_cache[key]

        data = FitData()
        if not self._data_source:
            self._fit_cache[key] = data
            return data

        base = self._data_source.gather_fit_data(event_name, channel)
        data.time_series = {path: np.array(values, copy=True) for path, values in base.time_series.items()}
        data.value_series = {path: np.array(values, copy=True) for path, values in base.value_series.items()}
        data.parameter_series = {path: np.array(values, copy=True) for path, values in base.parameter_series.items()}
        data.extras = {path: np.array(values, copy=True) for path, values in base.extras.items()}

        for path in list(data.time_series.keys()):
            override_time = self._fit_time_overrides.get((event_name, channel, path))
            if override_time is not None:
                data.time_series[path] = np.array(override_time, copy=True)

        for path in list(data.value_series.keys()):
            override_result = self._fit_result_overrides.get((event_name, channel, path))
            if override_result is not None:
                data.value_series[path] = np.array(override_result, copy=True)

        self._fit_cache[key] = data
        return data

    def open_fit_parameter_dialog(self):
        if not self._current_event or not self._data_source:
            QMessageBox.information(self, "No Event", "Open an event before editing fit parameters.")
            return

        available: Dict[str, FitData] = {}
        for channel in FIT_ELIGIBLE_CHANNELS:
            data = self.get_fit_data(self._current_event, channel)
            if data.has_parameters():
                available[channel] = data

        if not available:
            QMessageBox.information(self, "No Parameters", "No editable fit parameters were found for this event.")
            return

        def _load_channel_data(event_name: str) -> Dict[str, FitData]:
            data_map: Dict[str, FitData] = {}
            for channel in FIT_ELIGIBLE_CHANNELS:
                data = self.get_fit_data(event_name, channel)
                if data.has_parameters():
                    data_map[channel] = data
            return data_map

        dialog = FitParameterDialog(
            parent=self,
            event_name=self._current_event,
            channel_data=available,
            value_getter=self.get_parameter_values,
            fixed_getter=self.get_parameter_fixed_mask,
            save_callback=self.update_fit_override,
            reset_callback=self.clear_fit_override,
            waveform_getter=self.get_low_rate_waveform,
            event_names=self._events,
            data_loader=_load_channel_data,
            event_change_callback=self._handle_child_event_change,
        )
        dialog.exec()

    def get_parameter_values(self, event: str, channel: str, dataset_path: str, base_array: np.ndarray) -> np.ndarray:
        key = (event, channel, dataset_path)
        override = self._fit_param_overrides.get(key)
        if override is not None:
            return np.array(override, copy=True)
        return np.array(base_array, copy=True)

    def get_parameter_fixed_mask(
        self,
        event: str,
        channel: str,
        dataset_path: str,
        base_array: np.ndarray,
    ) -> np.ndarray:
        key = (event, channel, dataset_path)
        override = self._fit_fixed_overrides.get(key)
        if override is not None:
            mask = np.array(override, copy=True, dtype=bool)
        else:
            mask = np.zeros_like(base_array, dtype=bool)

        if mask.shape != base_array.shape:
            resized = np.zeros_like(base_array, dtype=bool)
            flat_mask = np.asarray(mask, dtype=bool).ravel()
            flat_target = resized.ravel()
            limit = min(flat_mask.size, flat_target.size)
            if limit:
                flat_target[:limit] = flat_mask[:limit]
            mask = resized
        return mask

    def _downsample_waveform(
        self,
        time_axis: np.ndarray,
        waveform: np.ndarray,
        *,
        max_points: int = 4096,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Return evenly-spaced samples limited to ``max_points``."""

        count = min(time_axis.size, waveform.size)
        if count <= max_points:
            return time_axis[:count], waveform[:count]

        indices = np.linspace(0, count - 1, max_points, dtype=int)
        if indices.size == 0:
            return time_axis[:count], waveform[:count]
        return time_axis[indices], waveform[indices]

    def get_low_rate_waveform(
        self, event: str, channel: str
    ) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        key = (event, channel)
        cached = self._low_rate_waveform_cache.get(key)
        if cached is not None:
            return np.array(cached[0], copy=True), np.array(cached[1], copy=True)

        values, times = self._resolve_channel_data(event, channel)
        if values is None or times is None:
            return None, None

        try:
            time_axis = np.asarray(times, dtype=float).ravel()
        except Exception:
            return None, None

        try:
            waveform = np.asarray(values, dtype=float).ravel()
        except Exception:
            return None, None

        if time_axis.size == 0 or waveform.size == 0:
            return None, None

        count = min(time_axis.size, waveform.size)
        if count == 0:
            return None, None

        time_axis = time_axis[:count]
        waveform = waveform[:count]
        waveform = self._apply_plot_scale(channel, waveform)

        down_time, down_values = self._downsample_waveform(time_axis, waveform)
        self._low_rate_waveform_cache[key] = (
            np.array(down_time, copy=True),
            np.array(down_values, copy=True),
        )
        return down_time, down_values

    def update_fit_override(
        self,
        event: str,
        channel: str,
        dataset_path: str,
        values: np.ndarray,
        fixed_mask: Optional[np.ndarray] = None,
        *,
        persist: bool = True,
    ) -> bool:
        array = np.array(values, copy=True)
        self._fit_param_overrides[(event, channel, dataset_path)] = array
        mask_key = (event, channel, dataset_path)
        mask_array: Optional[np.ndarray]
        if fixed_mask is not None:
            mask_array = np.array(fixed_mask, copy=True, dtype=bool)
            if mask_array.size == array.size:
                mask_array = mask_array.reshape(array.shape)
        else:
            mask_array = None

        if mask_array is not None and mask_array.any():
            self._fit_fixed_overrides[mask_key] = mask_array
        else:
            self._fit_fixed_overrides.pop(mask_key, None)

        self._remove_fit_override(event, channel, dataset_path)
        recomputed = self._recalculate_fit(event, channel, dataset_path, array)
        saved_to_file = False
        if persist:
            saved_to_file = self._write_fit_parameters(dataset_path, array)

        if recomputed:
            message = f"Updated fit parameters for {channel}; recomputed fit curve (in-memory only)."
        else:
            message = f"Updated fit parameters for {channel}; fit curve unchanged (missing data)."

        if persist:
            if saved_to_file:
                if "(in-memory only)" in message:
                    message = message.replace("(in-memory only)", "and saved to file")
                else:
                    message += " Saved to file."
            elif self._h5 is None or h5py is None:
                message += " File changes unavailable in this session."
            else:
                message += " Unable to persist changes to the file."
        self.statusBar().showMessage(message, 6000)
        self._fit_cache.pop((event, channel), None)
        self.plot_event(self._current_event)
        return saved_to_file

    def clear_fit_override(self, event: str, channel: str, dataset_path: str):
        key = (event, channel, dataset_path)
        removed_param = self._fit_param_overrides.pop(key, None) is not None
        mask_removed = self._fit_fixed_overrides.pop(key, None) is not None
        removed_curve = self._remove_fit_override(event, channel, dataset_path)
        if removed_param or removed_curve or mask_removed:
            self.statusBar().showMessage(f"Reverted fit parameters for {channel}.", 6000)
            self._fit_cache.pop((event, channel), None)
            self.plot_event(self._current_event)

    def _recalculate_fit(self, event: str, channel: str, dataset_path: str, params: np.ndarray) -> bool:
        if not self._data_source:
            return False
        derived = _fit_paths_from_param(dataset_path)
        if not derived:
            return False
        result_path, time_path = derived
        time_data = self._get_dataset_by_path(time_path)
        if time_data is None:
            definition = CHANNEL_DEFS.get(channel)
            if definition:
                time_data = self._get_dataset(event, definition.time_dataset)
        if time_data is None:
            return False
        time_array = np.array(time_data, copy=True)
        flat_time = np.asarray(time_array, dtype=float).ravel()
        curve = _evaluate_fit_curve(channel, flat_time, params)
        if curve is None:
            return False
        curve_array = np.array(curve, copy=True)
        if curve_array.size != time_array.size:
            return False
        curve_array = curve_array.reshape(time_array.shape)
        self._fit_time_overrides[(event, channel, time_path)] = time_array
        self._fit_result_overrides[(event, channel, result_path)] = curve_array
        self._fit_cache.pop((event, channel), None)
        return True

    def _remove_fit_override(self, event: str, channel: str, dataset_path: str) -> bool:
        removed = False
        derived = _fit_paths_from_param(dataset_path)
        if derived:
            result_path, time_path = derived
            if (event, channel, result_path) in self._fit_result_overrides:
                del self._fit_result_overrides[(event, channel, result_path)]
                removed = True
            if (event, channel, time_path) in self._fit_time_overrides:
                del self._fit_time_overrides[(event, channel, time_path)]
                removed = True
        return removed

    # --- Cleanup ---------------------------------------------------------
    def closeEvent(self, event):
        if self._data_source is not None:
            try:
                self._data_source.close()
            except Exception:
                pass
        try:
            self._tmpdir.cleanup()
        except Exception:
            pass
        event.accept()

# --------- Fit parameter editor dialog ---------
class FitParameterDialog(QDialog):
    def __init__(
        self,
        parent: QWidget,
        event_name: str,
        channel_data: Dict[str, FitData],
        value_getter: Callable[[str, str, str, np.ndarray], np.ndarray],
        fixed_getter: Callable[[str, str, str, np.ndarray], np.ndarray],
        save_callback: Callable[..., bool],
        reset_callback: Callable[[str, str, str], None],
        waveform_getter: Callable[[str, str], Tuple[Optional[np.ndarray], Optional[np.ndarray]]],
        *,
        event_names: Optional[Sequence[str]] = None,
        data_loader: Optional[Callable[[str], Dict[str, FitData]]] = None,
        event_change_callback: Optional[Callable[[str], None]] = None,
    ):
        super().__init__(parent)
        self.setModal(True)
        self.setMinimumSize(760, 720)
        self.resize(1120, 860)

        self._event_name = event_name
        self._value_getter = value_getter
        self._fixed_getter = fixed_getter
        self._save_callback = save_callback
        self._reset_callback = reset_callback
        self._waveform_getter = waveform_getter
        self._data_loader = data_loader
        self._event_change_callback = event_change_callback
        self._event_names = list(event_names or [])
        self._updating_event_combo = False

        self._param_arrays: Dict[Tuple[str, str], np.ndarray] = {}
        self._channel_datasets: Dict[str, List[str]] = {}
        self._fixed_masks: Dict[Tuple[str, str], np.ndarray] = {}
        self._waveform_cache: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}
        self._missing_waveforms: Set[str] = set()

        self._current_channel: Optional[str] = None
        self._current_dataset: Optional[str] = None
        self._current_shape: Optional[Tuple[int, ...]] = None
        self._is_updating_table = False
        self._preview_manual_selection = False
        self._updating_preview_selection = False

        self._selector_keyword_map: Dict[str, Tuple[str, ...]] = {
            "baseline": ("baseline",),
            "offset": ("offset",),
            "amplitude": ("amplitude", "amp"),
            "trigger": ("trigger", "t0", "impact onset", "onset"),
            "start": ("start", "window start"),
            "end": ("end", "window end"),
        }
        self._selector_buttons: Dict[str, QToolButton] = {}
        self._selector_mode: Optional[str] = None
        self._selector_values: Dict[str, Optional[float]] = {
            "baseline": None,
            "offset": None,
            "amplitude": None,
            "trigger": None,
            "start": None,
            "end": None,
        }
        self._preview_time = np.array([], dtype=float)
        self._preview_values = np.array([], dtype=float)
        self._preview_signal_time = np.array([], dtype=float)
        self._preview_signal_values = np.array([], dtype=float)
        self._preview_ax = None
        self._preview_offset = 0.0

        self._ingest_channel_data(channel_data)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        scroll_area = QScrollArea(self)
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.AsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.AsNeeded)

        content = QWidget(scroll_area)
        scroll_area.setWidget(content)

        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(12)

        header_row = QHBoxLayout()
        header_row.setContentsMargins(0, 0, 0, 0)
        header_row.setSpacing(12)

        self.header_label = QLabel("", self)
        self.header_label.setStyleSheet("font-size: 18px; font-weight: bold;")
        header_row.addWidget(self.header_label, stretch=1)

        if self._event_names and self._data_loader is not None:
            header_row.addStretch(1)
            event_label = QLabel("Event:", self)
            event_label.setStyleSheet("font-size: 15px;")
            header_row.addWidget(event_label)

            self.event_combo = QComboBox(self)
            self.event_combo.setStyleSheet("font-size: 15px; min-height: 32px;")
            for name in self._event_names:
                self.event_combo.addItem(name)
            if event_name in self._event_names:
                index = self._event_names.index(event_name)
                self.event_combo.setCurrentIndex(index)
            self.event_combo.currentTextChanged.connect(self._on_event_combo_changed)
            header_row.addWidget(self.event_combo)
        else:
            self.event_combo = None

        content_layout.addLayout(header_row)

        self.formula_label = QLabel("", self)
        self.formula_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.formula_label.setStyleSheet("font-size: 16px;")
        self.formula_label.setWordWrap(True)
        self.formula_label.setMinimumHeight(70)
        self.formula_label.setTextFormat(Qt.TextFormat.RichText)
        self._default_formula_text = "Select a dataset to view its fit function."
        self.formula_label.setText(html.escape(self._default_formula_text))
        content_layout.addWidget(self.formula_label)

        chooser_row = QHBoxLayout()
        chooser_row.setSpacing(10)

        self.channel_combo = QComboBox(self)
        self.channel_combo.setStyleSheet("font-size: 15px; min-height: 36px;")
        self.channel_combo.currentTextChanged.connect(self._on_channel_changed)
        chooser_row.addWidget(QLabel("Channel:", self))
        chooser_row.addWidget(self.channel_combo)

        self.dataset_combo = QComboBox(self)
        self.dataset_combo.setStyleSheet("font-size: 15px; min-height: 36px;")
        self.dataset_combo.currentIndexChanged.connect(self._on_dataset_changed)
        chooser_row.addWidget(QLabel("Dataset:", self))
        chooser_row.addWidget(self.dataset_combo)
        chooser_row.addStretch(1)
        content_layout.addLayout(chooser_row)

        preview_group = QGroupBox("Low-rate waveform preview", self)
        preview_group.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding))
        preview_group.setMinimumHeight(240)
        preview_layout = QVBoxLayout(preview_group)
        preview_layout.setContentsMargins(10, 12, 10, 12)
        preview_layout.setSpacing(8)

        preview_controls = QHBoxLayout()
        preview_controls.setSpacing(8)
        preview_controls.addWidget(QLabel("Waveform:", preview_group))

        self.waveform_combo = QComboBox(preview_group)
        self.waveform_combo.setStyleSheet("font-size: 14px; min-height: 32px;")
        self.waveform_combo.currentIndexChanged.connect(self._on_waveform_channel_changed)
        preview_controls.addWidget(self.waveform_combo)

        self.overlay_checkbox = QCheckBox("Overlay current fit", preview_group)
        self.overlay_checkbox.setChecked(True)
        self.overlay_checkbox.setStyleSheet("font-size: 14px;")
        self.overlay_checkbox.stateChanged.connect(self._on_overlay_toggled)
        preview_controls.addWidget(self.overlay_checkbox)
        preview_controls.addStretch(1)
        preview_layout.addLayout(preview_controls)

        self.preview_figure = Figure(figsize=(7.0, 3.8), constrained_layout=True)
        self.preview_ax = self.preview_figure.add_subplot(111)
        self.preview_ax.set_facecolor("#f8f9fb")
        self.preview_canvas = ScrollFriendlyFigureCanvas(self.preview_figure)
        self.preview_canvas.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding))
        self.preview_toolbar = NavigationToolbar(self.preview_canvas, preview_group)
        preview_layout.addWidget(self.preview_toolbar)
        preview_layout.addWidget(self.preview_canvas, stretch=1)

        self.preview_status_label = QLabel("", preview_group)
        self.preview_status_label.setStyleSheet("font-size: 13px; color: #555555;")
        self.preview_status_label.setWordWrap(True)
        preview_layout.addWidget(self.preview_status_label)

        preview_box = QGroupBox("Fit preview", self)
        preview_box.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding))
        preview_box.setMinimumHeight(260)
        preview_layout = QVBoxLayout(preview_box)
        preview_layout.setContentsMargins(12, 12, 12, 12)
        preview_layout.setSpacing(6)

        selector_row = QHBoxLayout()
        selector_row.setContentsMargins(0, 0, 0, 0)
        selector_row.setSpacing(6)
        selector_label = QLabel("Interactive selectors:", preview_box)
        selector_label.setStyleSheet("font-weight: 600; font-size: 14px;")
        selector_row.addWidget(selector_label)

        def _create_selector_button(text: str, mode: str, tooltip: str) -> QToolButton:
            button = QToolButton(preview_box)
            button.setText(text)
            button.setCheckable(True)
            button.setToolTip(tooltip)
            button.setStyleSheet(
                "QToolButton { padding: 4px 10px; border-radius: 6px; }"
                "QToolButton:checked { background-color: #4263eb; color: white; }"
            )
            button.clicked.connect(lambda checked, m=mode: self._on_selector_toggled(m, checked))
            self._selector_buttons[mode] = button
            return button

        selector_specs = (
            ("Baseline", "baseline", "Click, then select a horizontal level to assign the baseline."),
            ("Offset", "offset", "Assign an offset value from a horizontal line."),
            ("Amplitude", "amplitude", "Assign an amplitude using a horizontal selector."),
            ("Trigger", "trigger", "Assign the trigger/onset time from a vertical selector."),
            ("Start", "start", "Assign the fit window start from a vertical selector."),
            ("End", "end", "Assign the fit window end from a vertical selector."),
        )
        for text, mode, tip in selector_specs:
            selector_row.addWidget(_create_selector_button(text, mode, tip))
        selector_row.addStretch(1)
        preview_layout.addLayout(selector_row)

        self._preview_figure = Figure(figsize=(6.0, 3.6), constrained_layout=True)
        self._preview_canvas = FigureCanvas(self._preview_figure)
        self._preview_canvas.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding))
        self._preview_toolbar = NavigationToolbar(self._preview_canvas, preview_box)
        preview_layout.addWidget(self._preview_toolbar)
        preview_layout.addWidget(self._preview_canvas, stretch=1)

        self._preview_canvas.mpl_connect("button_press_event", self._on_preview_click)

        self.table = QTableWidget(self)
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Fit parameter", "Value", "Fixed"])
        header_view = self.table.horizontalHeader()
        header_view.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header_view.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header_view.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectItems)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(
            QTableWidget.EditTrigger.DoubleClicked | QTableWidget.EditTrigger.SelectedClicked
        )
        self.table.setStyleSheet("font-size: 15px;")
        self.table.itemChanged.connect(self._on_table_item_changed)

        self.info_label = QLabel("", self)
        self.info_label.setStyleSheet("font-size: 14px; color: #555555;")
        self.info_label.setWordWrap(True)

        self.feedback_label = QLabel("", self)
        self.feedback_label.setStyleSheet("font-size: 14px; color: #146c43;")
        self.feedback_label.setWordWrap(True)

        self.image_charge_checkbox = QCheckBox("Include image charge component", self)
        self.image_charge_checkbox.setStyleSheet("font-size: 14px;")
        self.image_charge_checkbox.stateChanged.connect(self._on_image_charge_toggled)
        self.image_charge_checkbox.setVisible(False)

        table_panel = QWidget(self)
        table_panel.setSizePolicy(QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding))
        table_panel.setMinimumHeight(220)
        table_layout = QVBoxLayout(table_panel)
        table_layout.setContentsMargins(0, 0, 0, 0)
        table_layout.setSpacing(8)
        table_layout.addWidget(self.image_charge_checkbox, alignment=Qt.AlignmentFlag.AlignLeft)
        table_layout.addWidget(self.table, stretch=1)
        table_layout.addWidget(self.info_label)
        table_layout.addWidget(self.feedback_label)

        self.content_splitter = QSplitter(Qt.Orientation.Vertical, self)
        self.content_splitter.setChildrenCollapsible(False)
        self.content_splitter.setHandleWidth(10)
        self.content_splitter.addWidget(preview_group)
        self.content_splitter.addWidget(preview_box)
        self.content_splitter.addWidget(table_panel)
        self.content_splitter.setStretchFactor(0, 3)
        self.content_splitter.setStretchFactor(1, 2)
        self.content_splitter.setStretchFactor(2, 3)
        self.content_splitter.setSizePolicy(
            QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        )
        self.content_splitter.setMinimumHeight(520)
        content_layout.addWidget(self.content_splitter, stretch=1)

        content_layout.addStretch(1)

        layout.addWidget(scroll_area, stretch=1)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close, self)

        self.recompute_button = QPushButton("Recompute Fit", self)
        self.recompute_button.setStyleSheet("font-size: 15px; padding: 8px 18px;")
        self.recompute_button.clicked.connect(self.recompute_fit)
        buttons.addButton(self.recompute_button, QDialogButtonBox.ButtonRole.ActionRole)

        self.apply_button = QPushButton("Apply Changes", self)
        self.apply_button.setStyleSheet("font-size: 15px; font-weight: bold; padding: 8px 18px;")
        self.apply_button.clicked.connect(self.apply_changes)
        buttons.addButton(self.apply_button, QDialogButtonBox.ButtonRole.AcceptRole)

        self.reset_button = QPushButton("Reset to File Values", self)
        self.reset_button.setStyleSheet("font-size: 15px; padding: 8px 18px;")
        self.reset_button.clicked.connect(self.reset_changes)
        buttons.addButton(self.reset_button, QDialogButtonBox.ButtonRole.ResetRole)

        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._update_header_text()
        self.setWindowTitle(f"Fit Parameters — Event {self._event_name}")

        self._populate_waveform_options()
        self._refresh_channel_combo()
        self._update_action_states()

    # ---- UI helpers -----------------------------------------------------
    def _ingest_channel_data(self, channel_data: Dict[str, FitData]) -> None:
        self._channel_data = dict(channel_data)
        self._param_arrays.clear()
        self._channel_datasets.clear()
        for channel, data in self._channel_data.items():
            entries: List[str] = []
            for path, array in data.iter_parameter_items():
                self._param_arrays[(channel, path)] = np.asarray(array)
                entries.append(path)
            if entries:
                entries.sort(key=lambda value: _dataset_sort_key(channel, value))
                self._channel_datasets[channel] = entries

    def _update_header_text(self) -> None:
        self.header_label.setText(f"Editing parameters for event {self._event_name}")

    def _refresh_channel_combo(
        self,
        preferred_channel: Optional[str] = None,
        preferred_dataset: Optional[str] = None,
    ) -> None:
        self.channel_combo.blockSignals(True)
        self.channel_combo.clear()
        for channel in sorted(self._channel_datasets.keys()):
            self.channel_combo.addItem(channel)
        self.channel_combo.blockSignals(False)

        if self.channel_combo.count() == 0:
            self.dataset_combo.blockSignals(True)
            self.dataset_combo.clear()
            self.dataset_combo.blockSignals(False)
            self._display_dataset(None, None)
            self._populate_waveform_options()
            self._update_waveform_plot()
            self._load_preview_series(None, None)
            self._update_preview_plot()
            return

        target_channel = preferred_channel
        if not target_channel or target_channel not in self._channel_datasets:
            target_channel = self.channel_combo.itemText(0)
        index = self.channel_combo.findText(target_channel)
        if index < 0:
            index = 0
        self.channel_combo.setCurrentIndex(index)

        dataset_entries = self._channel_datasets.get(target_channel, [])
        target_dataset = preferred_dataset if preferred_dataset in dataset_entries else None
        if target_dataset is None and dataset_entries:
            target_dataset = dataset_entries[0]
        if target_dataset is not None:
            dataset_index = self.dataset_combo.findData(target_dataset)
            if dataset_index >= 0:
                self.dataset_combo.setCurrentIndex(dataset_index)
                return

        self._on_channel_changed(target_channel)

    def _sync_event_combo_selection(self) -> None:
        if self.event_combo is None:
            return
        index = self.event_combo.findText(self._event_name)
        if index < 0:
            return
        self._updating_event_combo = True
        try:
            self.event_combo.setCurrentIndex(index)
        finally:
            self._updating_event_combo = False

    def _on_event_combo_changed(self, event_name: str) -> None:
        if self._updating_event_combo:
            return
        if not event_name or event_name == self._event_name:
            return
        self._change_event(event_name, notify_parent=True)

    def _change_event(self, event_name: str, *, notify_parent: bool) -> None:
        if self._data_loader is None:
            return
        try:
            new_data = self._data_loader(event_name)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Fit Parameters",
                f"Unable to load parameters for event {event_name}:\n{exc}",
            )
            self._sync_event_combo_selection()
            return

        self._event_name = event_name
        self.setWindowTitle(f"Fit Parameters — Event {self._event_name}")
        self._update_header_text()

        self._ingest_channel_data(new_data)
        self._fixed_masks.clear()
        self._waveform_cache.clear()
        self._missing_waveforms.clear()
        self._preview_manual_selection = False
        self._updating_preview_selection = False
        for key in list(self._selector_values.keys()):
            self._selector_values[key] = None

        self._populate_waveform_options()
        previous_channel = self._current_channel
        previous_dataset = self._current_dataset
        self._current_channel = None
        self._current_dataset = None
        self._current_shape = None
        self._refresh_channel_combo(previous_channel, previous_dataset)
        self._update_action_states()

        if notify_parent and self._event_change_callback is not None:
            try:
                self._event_change_callback(event_name)
            except Exception:
                pass

    def set_current_event(self, event_name: Optional[str]) -> None:
        if not event_name or event_name == self._event_name:
            self._sync_event_combo_selection()
            return
        if self._event_names and event_name not in self._event_names:
            return
        self._change_event(event_name, notify_parent=False)
        self._sync_event_combo_selection()

    def _populate_waveform_options(self) -> None:
        available: List[str] = []
        for name in sorted(FIT_ELIGIBLE_CHANNELS):
            if self._get_waveform(name) is not None:
                available.append(name)

        self.waveform_combo.blockSignals(True)
        self.waveform_combo.clear()
        for name in available:
            self.waveform_combo.addItem(name, name)
        self.waveform_combo.blockSignals(False)

        enabled = bool(available)
        self.waveform_combo.setEnabled(enabled)
        self.overlay_checkbox.setEnabled(enabled)

        if not available:
            self.preview_status_label.setText("Waveform preview unavailable for this event.")
        else:
            self._preview_manual_selection = False

    def _on_channel_changed(self, channel: str):
        self.dataset_combo.blockSignals(True)
        self.dataset_combo.clear()
        entries = self._channel_datasets.get(channel, [])
        for path in entries:
            label = self._dataset_display_name(channel, path)
            self.dataset_combo.addItem(label, path)
        self.dataset_combo.blockSignals(False)

        if entries:
            self.dataset_combo.setCurrentIndex(0)
            self._display_dataset(channel, entries[0])
        else:
            self._display_dataset(channel, None)

    def _on_dataset_changed(self, index: int):
        channel = self.channel_combo.currentText()
        dataset_path = self.dataset_combo.itemData(index)
        self._display_dataset(channel, dataset_path)

    def _on_selector_toggled(self, mode: str, checked: bool) -> None:
        if checked:
            for other_mode, button in self._selector_buttons.items():
                if other_mode == mode or not isinstance(button, QToolButton):
                    continue
                button.blockSignals(True)
                button.setChecked(False)
                button.blockSignals(False)
            self._selector_mode = mode
        else:
            if self._selector_mode == mode:
                self._selector_mode = None

    def _display_dataset(
        self,
        channel: Optional[str],
        dataset_path: Optional[str],
        *,
        preserve_feedback: bool = False,
    ):
        if not channel or dataset_path is None:
            self._update_formula_display(None)
            self._clear_table("No fit parameters are available for this channel.")
            return

        base_array = self._param_arrays.get((channel, dataset_path))
        if base_array is None:
            self._update_formula_display(None)
            self._clear_table("No fit parameters are available for this channel.")
            return

        self._update_formula_display(channel)

        values = self._value_getter(self._event_name, channel, dataset_path, base_array)
        array = np.asarray(values)
        self._current_channel = channel
        self._current_dataset = dataset_path
        self._current_shape = array.shape

        mask_key = (channel, dataset_path)
        mask_array = self._fixed_masks.get(mask_key)
        if mask_array is None:
            base_mask = self._fixed_getter(self._event_name, channel, dataset_path, base_array)
            mask_array = self._ensure_mask_shape(base_mask, array.shape)
        else:
            mask_array = self._ensure_mask_shape(mask_array, array.shape)
        self._fixed_masks[mask_key] = mask_array

        flat = array.ravel()
        flat_mask = mask_array.ravel()
        labels = self._parameter_labels(channel, dataset_path, flat.size)
        self._update_image_charge_controls(channel, dataset_path, flat)

        self._is_updating_table = True
        try:
            self.table.setRowCount(flat.size)
            for idx, value in enumerate(flat):
                label = labels[idx] if idx < len(labels) else f"p{idx + 1}"
                idx_item = QTableWidgetItem(label)
                idx_item.setFlags(Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEnabled)

                value_item = QTableWidgetItem(self._format_value(value))
                value_item.setFlags(value_item.flags() | Qt.ItemFlag.ItemIsEditable)

                fixed_item = QTableWidgetItem("")
                fixed_item.setFlags(
                    Qt.ItemFlag.ItemIsEnabled
                    | Qt.ItemFlag.ItemIsUserCheckable
                    | Qt.ItemFlag.ItemIsSelectable
                )
                fixed_item.setCheckState(
                    Qt.CheckState.Checked if flat_mask[idx] else Qt.CheckState.Unchecked
                )

                self.table.setItem(idx, 0, idx_item)
                self.table.setItem(idx, 1, value_item)
                self.table.setItem(idx, 2, fixed_item)
        finally:
            self._is_updating_table = False

        self.table.resizeColumnsToContents()
        self._update_info_label(channel, dataset_path, array, flat_mask)
        if not preserve_feedback:
            self.feedback_label.clear()

        self._update_waveform_selection(channel)
        self._update_action_states()
        self._update_waveform_plot()
        self._sync_selector_values_from_table()
        self._load_preview_series(channel, dataset_path)
        self._update_preview_plot()

    def _dataset_display_name(self, channel: str, dataset_path: str) -> str:
        mass_label = _mass_identifier_from_path(dataset_path)
        if mass_label:
            return f"Mass {mass_label}"
        base = os.path.basename(dataset_path)
        return base or dataset_path

    def _parameter_labels(self, channel: str, dataset_path: str, count: int) -> List[str]:
        model = FIT_MODEL_BY_CHANNEL.get(channel)
        if not model:
            return [f"p{i + 1}" for i in range(count)]
        if model is ION_GRID_FIT:
            override = ION_GRID_LABEL_OVERRIDES.get(count)
            if override:
                return list(override)
        labels = list(model.parameter_labels)
        if len(labels) >= count:
            return labels[:count]
        extras = [f"p{i + 1}" for i in range(len(labels), count)]
        return labels + extras

    def _update_formula_display(self, channel: Optional[str]):
        self.formula_label.setPixmap(QPixmap())
        self.formula_label.setToolTip("")
        if not channel:
            self.formula_label.setText(html.escape(self._default_formula_text))
            return

        model = FIT_MODEL_BY_CHANNEL.get(channel)
        if not model or not model.latex:
            self.formula_label.setText(
                html.escape("Fit function preview unavailable for this selection.")
            )
            return

        pixmap = _latex_to_pixmap(model.latex)
        if pixmap is not None and not pixmap.isNull():
            self.formula_label.setText("")
            self.formula_label.setPixmap(pixmap)
        else:
            html_text = _latex_to_html(model.latex)
            if html_text:
                self.formula_label.setText(
                    (
                        "<span style='font-family: \"STIX Two Math\", "
                        "\"Times New Roman\", serif;'>"
                        f"{html_text}</span>"
                    )
                )
            else:
                self.formula_label.setText(html.escape(model.latex))
        self.formula_label.setToolTip(model.latex)

    def _ensure_mask_shape(self, source: np.ndarray, shape: Tuple[int, ...]) -> np.ndarray:
        mask = np.zeros(shape, dtype=bool)
        src_flat = np.asarray(source, dtype=bool).ravel()
        dst_flat = mask.ravel()
        limit = min(src_flat.size, dst_flat.size)
        if limit:
            dst_flat[:limit] = src_flat[:limit]
        return mask

    def _update_info_label(
        self,
        channel: str,
        dataset_path: str,
        array: np.ndarray,
        mask: np.ndarray,
    ) -> None:
        display_name = self._dataset_display_name(channel, dataset_path)
        total = mask.size
        fixed = int(np.count_nonzero(mask)) if total else 0
        fixed_text = f"Fixed parameters: {fixed}/{total}" if total else ""
        text = f"{channel} — {display_name}\n{dataset_path} — shape {array.shape}"
        if fixed_text:
            text += f"\n{fixed_text}"
        self.info_label.setText(text)

    def _set_feedback(self, text: str, *, success: bool):
        if not text:
            self.feedback_label.clear()
            return
        color = "#146c43" if success else "#b02a37"
        self.feedback_label.setStyleSheet(f"font-size: 14px; color: {color};")
        self.feedback_label.setText(text)

    def _apply_current_values(self, *, auto: bool) -> bool:
        if not self._current_channel or not self._current_dataset:
            if not auto:
                QMessageBox.information(
                    self,
                    "No Selection",
                    "Select a parameter set before applying changes.",
                )
            return False

        values: List[float] = []
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 1)
            text = item.text().strip() if item else ""
            if not text:
                values.append(0.0)
                continue
            try:
                values.append(float(text))
            except ValueError:
                message = f"Row {row + 1} contains a non-numeric value: {text}"
                if auto:
                    self._set_feedback(message, success=False)
                else:
                    QMessageBox.warning(self, "Invalid value", message)
                return False

        mask_flat = self._collect_fixed_mask()
        if mask_flat is None:
            if auto:
                self._set_feedback("Unable to read fixed-parameter states.", success=False)
            else:
                QMessageBox.warning(self, "Invalid state", "Unable to read fixed-parameter states.")
            return False

        expected = int(np.prod(self._current_shape)) if self._current_shape else len(values)

        if len(values) != expected:
            message = "The number of edited values does not match the original parameter shape."
            if auto:
                self._set_feedback(message, success=False)
            else:
                QMessageBox.warning(self, "Shape mismatch", message)
            return False

        array = np.array(values, dtype=float)
        mask_array = np.array(mask_flat, dtype=bool)
        if self._current_shape:
            array = array.reshape(self._current_shape)
            mask_array = mask_array.reshape(self._current_shape)

        self._param_arrays[(self._current_channel, self._current_dataset)] = np.array(array, copy=True)
        self._fixed_masks[(self._current_channel, self._current_dataset)] = np.array(mask_array, copy=True)

        saved_to_file = bool(
            self._save_callback(
                self._event_name,
                self._current_channel,
                self._current_dataset,
                array,
                mask_array,
                persist=not auto,
            )
        )

        self._display_dataset(self._current_channel, self._current_dataset, preserve_feedback=True)

        if auto:
            self._set_feedback("Fit updated with latest parameters.", success=True)
        else:
            if saved_to_file:
                self._set_feedback("Changes saved to file and fit recomputed.", success=True)
            else:
                self._set_feedback("Changes stored in-memory and fit recomputed.", success=True)
        return True

    def _on_table_item_changed(self, item: QTableWidgetItem):
        if self._is_updating_table or item is None:
            return

        if item.column() == 1:
            self._set_row_fixed(item.row(), True)
            self._apply_current_values(auto=True)
        elif item.column() == 2:
            state = item.checkState() == Qt.CheckState.Checked
            self._set_row_fixed(item.row(), state)
            self._apply_current_values(auto=True)

    def _set_row_fixed(self, row: int, fixed: bool) -> None:
        if not self._current_channel or not self._current_dataset:
            return
        mask = self._fixed_masks.get((self._current_channel, self._current_dataset))
        if mask is None:
            return
        flat = mask.ravel()
        if 0 <= row < flat.size:
            flat[row] = fixed
        item = self.table.item(row, 2)
        if item is not None:
            with QSignalBlocker(self.table):
                item.setCheckState(Qt.CheckState.Checked if fixed else Qt.CheckState.Unchecked)
        param_array = self._param_arrays.get((self._current_channel, self._current_dataset), np.array([]))
        self._update_info_label(
            self._current_channel,
            self._current_dataset,
            param_array,
            mask.ravel(),
        )

    def _clear_table(self, message: str = ""):
        self.table.setRowCount(0)
        self.info_label.setText(message)
        self.feedback_label.clear()
        self._current_channel = None
        self._current_dataset = None
        self._current_shape = None
        self._is_updating_table = False
        self.image_charge_checkbox.setVisible(False)
        with QSignalBlocker(self.image_charge_checkbox):
            self.image_charge_checkbox.setChecked(False)
        self._load_preview_series(None, None)
        self._update_preview_plot()

    def _format_value(self, value: object) -> str:
        try:
            if isinstance(value, (np.floating, float)):
                return f"{float(value):.6g}"
            if isinstance(value, (np.integer, int)):
                return str(int(value))
        except Exception:
            pass
        return str(value)

    # ---- Actions --------------------------------------------------------
    def apply_changes(self):
        self._apply_current_values(auto=False)

    def recompute_fit(self):
        if self._apply_current_values(auto=True):
            self._set_feedback("Fit recomputed with current parameters (not saved).", success=True)

    def reset_changes(self):
        if not self._current_channel or not self._current_dataset:
            return
        self._reset_callback(self._event_name, self._current_channel, self._current_dataset)
        self._fixed_masks.pop((self._current_channel, self._current_dataset), None)
        self._display_dataset(self._current_channel, self._current_dataset, preserve_feedback=True)
        self._set_feedback("Reverted to values from the file.", success=False)

    def _load_preview_series(self, channel: Optional[str], dataset_path: Optional[str]) -> None:
        self._preview_time = np.array([], dtype=float)
        self._preview_values = np.array([], dtype=float)
        self._preview_signal_time = np.array([], dtype=float)
        self._preview_signal_values = np.array([], dtype=float)
        self._preview_ax = None
        if not channel or not dataset_path:
            self._update_selector_button_states()
            return

        data = self._channel_data.get(channel)
        if not data:
            self._update_selector_button_states()
            return

        derived = _fit_paths_from_param(dataset_path)
        time_values: Optional[np.ndarray] = None
        value_values: Optional[np.ndarray] = None
        if derived:
            result_path, time_path = derived
            time_values = data.time_series.get(time_path)
            value_values = data.value_series.get(result_path)

        if time_values is None or value_values is None:
            pair_key = _pair_key(dataset_path)
            for _label, time_path, value_path, time_arr, value_arr in data.iter_time_result_pairs():
                if _pair_key(time_path) == pair_key or _pair_key(value_path) == pair_key:
                    time_values = time_arr
                    value_values = value_arr
                    break

        if time_values is not None and value_values is not None:
            self._preview_time = np.asarray(time_values, dtype=float).ravel()
            self._preview_values = np.asarray(value_values, dtype=float).ravel()

        waveform_pair = self._get_waveform(channel)
        if waveform_pair is not None:
            wave_time, wave_values = waveform_pair
            wave_time = np.asarray(wave_time, dtype=float).ravel()
            wave_values = np.asarray(wave_values, dtype=float).ravel()
            mask = np.isfinite(wave_time) & np.isfinite(wave_values)
            wave_time = wave_time[mask]
            wave_values = wave_values[mask]
            if self._preview_time.size:
                t_min = float(np.nanmin(self._preview_time))
                t_max = float(np.nanmax(self._preview_time))
                if np.isfinite(t_min) and np.isfinite(t_max):
                    window_mask = (wave_time >= t_min) & (wave_time <= t_max)
                    if np.any(window_mask):
                        wave_time = wave_time[window_mask]
                        wave_values = wave_values[window_mask]
            if wave_time.size:
                order = np.argsort(wave_time)
                self._preview_signal_time = wave_time[order]
                self._preview_signal_values = wave_values[order]

        self._update_selector_button_states()

    def _update_preview_plot(self) -> None:
        self._preview_figure.clear()
        ax = self._preview_figure.add_subplot(111)
        self._preview_ax = ax

        has_fit = self._preview_time.size > 0 and self._preview_values.size > 0
        has_signal = (
            self._preview_signal_time.size > 0 and self._preview_signal_values.size > 0
        )

        if not has_fit and not has_signal:
            ax.text(0.5, 0.5, "No fit preview available for this dataset.", ha="center", va="center")
            ax.set_axis_off()
            self._preview_canvas.draw_idle()
            return

        if has_signal:
            signal_line, = ax.plot(
                self._preview_signal_time,
                self._preview_signal_values,
                color="#495057",
                linewidth=1.3,
                alpha=0.9,
                label="Signal",
            )
            signal_line.set_path_effects(
                [patheffects.Stroke(linewidth=1.8, foreground="#ffffff", alpha=0.65), patheffects.Normal()]
            )

        if has_fit:
            order = np.argsort(self._preview_time)
            time_data = self._preview_time[order]
            value_data = self._preview_values[order]
            fit_line, = ax.plot(
                time_data,
                value_data,
                color="#0c5da5",
                linewidth=2.4,
                label="Fit curve",
                zorder=5,
            )
            fit_line.set_path_effects(
                [patheffects.Stroke(linewidth=3.4, foreground="#ffffff", alpha=0.8), patheffects.Normal()]
            )

        ax.set_xlabel("Time (µs)")
        channel_label = self._current_channel or ""
        if channel_label:
            ax.set_ylabel(y_label_with_units(channel_label))
        else:
            ax.set_ylabel("Value")
        ax.set_facecolor("#f8f9fb")
        ax.grid(True, alpha=0.35)
        if has_signal or has_fit:
            ax.legend(loc="best")
        self._preview_offset = 0.0
        self._draw_preview_overlays(ax)
        self._preview_canvas.draw_idle()

    def _draw_preview_overlays(self, ax) -> None:
        if ax is None:
            return
        color_map = {
            "baseline": "#b02a37",
            "offset": "#6f42c1",
            "amplitude": "#0d6efd",
            "trigger": "#0ca678",
            "start": "#228be6",
            "end": "#e8590c",
        }
        for mode, value in self._selector_values.items():
            if value is None or not np.isfinite(value):
                continue
            color = color_map.get(mode, "#495057")
            if mode in {"baseline", "offset", "amplitude"}:
                ax.axhline(value, color=color, linestyle="--", linewidth=1.1, alpha=0.75)
            else:
                ax.axvline(value, color=color, linestyle="--", linewidth=1.1, alpha=0.75)

    def _on_preview_click(self, event) -> None:
        if self._selector_mode is None:
            return
        if event is None or event.inaxes != self._preview_ax:
            return
        mode = self._selector_mode
        if mode in {"baseline", "offset", "amplitude"}:
            if event.ydata is None:
                return
            value = float(event.ydata)
        else:
            if event.xdata is None:
                return
            value = float(event.xdata)
        self._apply_selector_value(mode, value)

    def _find_parameter_rows_for_mode(self, mode: str) -> List[int]:
        rows: List[int] = []
        keywords = self._selector_keyword_map.get(mode, ())
        if not keywords:
            return rows
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            label = item.text().strip().lower() if item else ""
            if not label:
                continue
            if any(keyword in label for keyword in keywords):
                rows.append(row)
        return rows

    def _apply_selector_value(self, mode: str, value: float) -> None:
        if not np.isfinite(value):
            return
        rows = self._find_parameter_rows_for_mode(mode)
        if not rows:
            self._set_feedback(f"No parameter labelled for {mode} in this dataset.", success=False)
            return
        selected_rows = {index.row() for index in self.table.selectionModel().selectedRows()} if self.table.selectionModel() else set()
        target_row = rows[0]
        for row in rows:
            if row in selected_rows:
                target_row = row
                break
        item = self.table.item(target_row, 1)
        if item is None:
            item = QTableWidgetItem()
            self.table.setItem(target_row, 1, item)
        formatted = self._format_value(value)
        self._is_updating_table = True
        try:
            item.setText(formatted)
        finally:
            self._is_updating_table = False
        if not self._apply_current_values(auto=True):
            return
        self._selector_values[mode] = value
        self._set_feedback(f"Updated {mode} to {formatted} from selector.", success=True)
        self._sync_selector_values_from_table()

    def _sync_selector_values_from_table(self) -> None:
        for mode in list(self._selector_values.keys()):
            rows = self._find_parameter_rows_for_mode(mode)
            value: Optional[float] = None
            for row in rows:
                item = self.table.item(row, 1)
                if item is None:
                    continue
                text = item.text().strip()
                if not text:
                    continue
                try:
                    value = float(text)
                except ValueError:
                    continue
                break
            self._selector_values[mode] = value
        self._update_selector_button_states()

    def _update_selector_button_states(self) -> None:
        has_fit = self._preview_time.size > 0 and self._preview_values.size > 0
        has_signal = (
            self._preview_signal_time.size > 0 and self._preview_signal_values.size > 0
        )
        has_preview = has_fit or has_signal
        for mode, button in self._selector_buttons.items():
            if not isinstance(button, QToolButton):
                continue
            enabled = has_preview and bool(self._find_parameter_rows_for_mode(mode))
            button.setEnabled(enabled)
            if not enabled and button.isChecked():
                button.blockSignals(True)
                button.setChecked(False)
                button.blockSignals(False)
                if self._selector_mode == mode:
                    self._selector_mode = None

    def _channel_supports_image_charge(self, channel: Optional[str]) -> bool:
        if not channel:
            return False
        model = FIT_MODEL_BY_CHANNEL.get(channel)
        return model is ION_GRID_FIT

    def _update_image_charge_controls(
        self,
        channel: Optional[str],
        dataset_path: Optional[str],
        flat_values: np.ndarray,
    ) -> None:
        supports = self._channel_supports_image_charge(channel)
        with QSignalBlocker(self.image_charge_checkbox):
            if not supports:
                self.image_charge_checkbox.setVisible(False)
                self.image_charge_checkbox.setChecked(False)
                return

            include_image_charge = flat_values.size >= len(ION_GRID_PARAMETER_LABELS_FULL)
            self.image_charge_checkbox.setVisible(True)
            self.image_charge_checkbox.setToolTip(
                "Toggle whether the Ion Grid fit includes the image charge component."
            )
            self.image_charge_checkbox.setChecked(include_image_charge)

    def _collect_table_values(self) -> Optional[List[float]]:
        values: List[float] = []
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 1)
            text = item.text().strip() if item else ""
            if not text:
                values.append(0.0)
                continue
            try:
                values.append(float(text))
            except ValueError:
                return None
        return values

    def _collect_fixed_mask(self) -> Optional[List[bool]]:
        mask: List[bool] = []
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 2)
            if item is None:
                return None
            mask.append(item.checkState() == Qt.CheckState.Checked)
        return mask

    def _update_action_states(self) -> None:
        enabled = self._current_channel is not None and self.table.rowCount() > 0
        self.recompute_button.setEnabled(enabled)
        self.apply_button.setEnabled(enabled)
        self.reset_button.setEnabled(enabled)

    def _get_waveform(self, channel: str) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        if channel in self._waveform_cache:
            return self._waveform_cache[channel]
        if channel in self._missing_waveforms:
            return None
        try:
            times, values = self._waveform_getter(self._event_name, channel)
        except Exception:
            times = None
            values = None
        if times is None or values is None:
            self._missing_waveforms.add(channel)
            return None
        pair = (np.asarray(times, dtype=float), np.asarray(values, dtype=float))
        if pair[0].size == 0 or pair[1].size == 0:
            self._missing_waveforms.add(channel)
            return None
        self._waveform_cache[channel] = pair
        return pair

    def _on_waveform_channel_changed(self, _index: int):
        if self._updating_preview_selection:
            return
        self._preview_manual_selection = True
        self._update_waveform_plot()

    def _on_overlay_toggled(self, _state: int):
        self._update_waveform_plot()

    def _update_waveform_selection(self, channel: str) -> None:
        if self._preview_manual_selection:
            return
        index = self.waveform_combo.findData(channel)
        if index < 0:
            return
        if self.waveform_combo.currentIndex() == index:
            return
        self._updating_preview_selection = True
        try:
            self.waveform_combo.setCurrentIndex(index)
        finally:
            self._updating_preview_selection = False

    def _update_waveform_plot(self) -> None:
        self.preview_ax.clear()
        self.preview_ax.set_facecolor("#f8f9fb")
        channel = self.waveform_combo.currentData()
        if not channel:
            self.preview_status_label.setText("Select a waveform to preview.")
            self.preview_canvas.draw_idle()
            return

        data = self._get_waveform(channel)
        if data is None:
            self.preview_status_label.setText(f"No waveform samples available for {channel}.")
            self.preview_canvas.draw_idle()
            return

        time_axis, waveform = data
        count = min(time_axis.size, waveform.size)
        if count == 0:
            self.preview_status_label.setText(f"No waveform samples available for {channel}.")
            self.preview_canvas.draw_idle()
            return

        time_values = np.asarray(time_axis[:count], dtype=float)
        signal_values = np.asarray(waveform[:count], dtype=float)
        finite_mask = np.isfinite(time_values) & np.isfinite(signal_values)
        if not np.any(finite_mask):
            self.preview_status_label.setText(f"Waveform contains no finite samples for {channel}.")
            self.preview_canvas.draw_idle()
            return

        time_values = time_values[finite_mask]
        signal_values = signal_values[finite_mask]
        if time_values.size == 0:
            self.preview_status_label.setText(f"Waveform contains no finite samples for {channel}.")
            self.preview_canvas.draw_idle()
            return

        self.preview_ax.plot(time_values, signal_values, color="#1f77b4", label=f"{channel} waveform")

        show_overlay = False
        if self.overlay_checkbox.isChecked():
            params = self._parameters_for_preview(channel)
            if params is not None:
                curve = _evaluate_fit_curve(channel, time_values, params)
                if curve is not None:
                    overlay = np.asarray(curve, dtype=float)
                    overlay = overlay[: time_values.size]
                    overlay_mask = np.isfinite(overlay)
                    if np.any(overlay_mask):
                        overlay_time = time_values[: overlay_mask.size][overlay_mask]
                        overlay = overlay[overlay_mask]
                        if overlay.size and overlay_time.size:
                            self.preview_ax.plot(
                                overlay_time,
                                overlay,
                                color="#d9480f",
                                label="Fit",
                            )
                            show_overlay = True

        self.preview_ax.set_xlabel("Time (µs)")
        self.preview_ax.set_ylabel(y_label_with_units(channel))
        self.preview_ax.grid(True, alpha=0.35)
        if show_overlay:
            self.preview_ax.legend(loc="upper right")

        amplitude = float(np.nanmax(np.abs(signal_values))) if signal_values.size else 0.0
        if np.isfinite(amplitude) and amplitude > 0.0:
            threshold = amplitude * 0.02
            strong = np.where(np.abs(signal_values) >= threshold)[0]
            if strong.size:
                left = max(int(strong[0]) - 3, 0)
                right = min(int(strong[-1]) + 3, signal_values.size - 1)
                self.preview_ax.set_xlim(time_values[left], time_values[right])

        if signal_values.size:
            y_min = float(np.nanmin(signal_values))
            y_max = float(np.nanmax(signal_values))
            if np.isfinite(y_min) and np.isfinite(y_max):
                if y_min == y_max:
                    pad = abs(y_max) * 0.1 if y_max else 1.0
                    self.preview_ax.set_ylim(y_min - pad, y_max + pad)
                else:
                    span = y_max - y_min
                    pad = max(span * 0.08, 1e-9)
                    self.preview_ax.set_ylim(y_min - pad, y_max + pad)

        status_parts = [f"{channel}: {time_values.size} samples"]
        if time_values.size:
            start = float(time_values[0])
            end = float(time_values[-1])
            if np.isfinite(start) and np.isfinite(end):
                status_parts.append(f"{start:.3f}–{end:.3f} µs")
        status_parts.append("fit overlay enabled" if show_overlay else "fit overlay hidden")
        self.preview_status_label.setText("; ".join(status_parts))
        self.preview_canvas.draw_idle()

    def _parameters_for_preview(self, channel: str) -> Optional[np.ndarray]:
        if self._current_channel == channel and self._current_dataset:
            values = self._collect_table_values()
            if values is not None:
                return np.asarray(values, dtype=float)
        dataset_path = self._default_dataset_for_channel(channel)
        if dataset_path is None:
            return None
        array = self._param_arrays.get((channel, dataset_path))
        if array is None:
            return None
        return np.asarray(array, dtype=float).ravel()

    def _default_dataset_for_channel(self, channel: str) -> Optional[str]:
        entries = self._channel_datasets.get(channel)
        if not entries:
            return None
        return entries[0]

    def _ensure_image_charge_values(self, values: Iterable[float]) -> List[float]:
        value_list = list(values)
        if len(value_list) >= len(ION_GRID_PARAMETER_LABELS_FULL):
            return list(value_list[: len(ION_GRID_PARAMETER_LABELS_FULL)])

        expanded = [0.0] * len(ION_GRID_PARAMETER_LABELS_FULL)
        if value_list:
            expanded[0] = value_list[0]
        if len(value_list) > 1:
            expanded[1] = value_list[1]
        if len(value_list) > 2:
            expanded[3] = value_list[2]
        if len(value_list) > 3:
            expanded[5] = value_list[3]
        if len(value_list) > 4:
            expanded[6] = value_list[4]

        # Defaults for the image charge terms
        expanded[2] = 0.0
        expanded[4] = expanded[5] if len(value_list) > 3 else 1.0
        return expanded

    def _ensure_legacy_values(self, values: Iterable[float]) -> List[float]:
        value_list = list(values)
        if len(value_list) <= len(ION_GRID_PARAMETER_LABELS_LEGACY):
            return list(value_list[: len(ION_GRID_PARAMETER_LABELS_LEGACY)])

        legacy = [0.0] * len(ION_GRID_PARAMETER_LABELS_LEGACY)
        if value_list:
            legacy[0] = value_list[0]
        if len(value_list) > 1:
            legacy[1] = value_list[1]
        if len(value_list) > 3:
            legacy[2] = value_list[3]
        if len(value_list) > 5:
            legacy[3] = value_list[5]
        if len(value_list) > 6:
            legacy[4] = value_list[6]
        return legacy

    def _on_image_charge_toggled(self, state: int):
        if self._is_updating_table:
            return
        if not self._current_channel or not self._current_dataset:
            return
        if not self._channel_supports_image_charge(self._current_channel):
            return

        include = state == Qt.CheckState.Checked
        values = self._collect_table_values()
        if values is None:
            with QSignalBlocker(self.image_charge_checkbox):
                self.image_charge_checkbox.setChecked(not include)
            self._set_feedback(
                "Cannot toggle image charge because one or more values are invalid.",
                success=False,
            )
            return

        if include:
            new_values = self._ensure_image_charge_values(values)
        else:
            new_values = self._ensure_legacy_values(values)

        self._current_shape = (len(new_values),)
        mask_key = (self._current_channel, self._current_dataset)
        mask = self._fixed_masks.get(mask_key, np.zeros(len(new_values), dtype=bool))
        mask = self._ensure_mask_shape(mask, (len(new_values),))
        self._fixed_masks[mask_key] = mask

        labels = self._parameter_labels(self._current_channel, self._current_dataset, len(new_values))
        flat_mask = mask.ravel()
        self._is_updating_table = True
        try:
            self.table.setRowCount(len(new_values))
            for idx, value in enumerate(new_values):
                label = labels[idx] if idx < len(labels) else f"p{idx + 1}"
                idx_item = QTableWidgetItem(label)
                idx_item.setFlags(Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEnabled)
                value_item = QTableWidgetItem(self._format_value(value))
                value_item.setFlags(value_item.flags() | Qt.ItemFlag.ItemIsEditable)
                fixed_item = QTableWidgetItem("")
                fixed_item.setFlags(
                    Qt.ItemFlag.ItemIsEnabled
                    | Qt.ItemFlag.ItemIsUserCheckable
                    | Qt.ItemFlag.ItemIsSelectable
                )
                fixed_item.setCheckState(
                    Qt.CheckState.Checked if flat_mask[idx] else Qt.CheckState.Unchecked
                )
                self.table.setItem(idx, 0, idx_item)
                self.table.setItem(idx, 1, value_item)
                self.table.setItem(idx, 2, fixed_item)
        finally:
            self._is_updating_table = False
        self.table.resizeColumnsToContents()

        if not self._apply_current_values(auto=True):
            with QSignalBlocker(self.image_charge_checkbox):
                self.image_charge_checkbox.setChecked(not include)

# --------- CLI / main ---------
def main():
    parser = argparse.ArgumentParser(description="Run the IDEX Quicklook (QtAgg + Matplotlib toolbar).")
    parser.add_argument(
        "-f",
        "--file",
        "--filename",
        nargs="?",
        dest="filename",
        default=None,
        help="Path to the data file (HDF5 or CDF).",
    )
    parser.add_argument("--eventnumber", nargs="?", type=int, default=None, help="1-based event index.")
    args = parser.parse_args()
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    base_font = QFont(app.font())
    size = base_font.pointSize()
    if size <= 0:
        size = 12
    else:
        size = max(size, 12)
    base_font.setPointSize(size)
    app.setFont(base_font)

    w = MainWindow(filename=args.filename, eventnumber=args.eventnumber)
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
