from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List, Optional
from contextlib import asynccontextmanager
import logging

from .search import search_web
from .crawler import fetch_page, html_to_markdown
from .qa import ModernBertQA, ModernBertNLI
from .expander import GraniteQueryExpander, MECEQueryExpansion, DempsterShaferScore

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Request/Response models
class SearchRequest(BaseModel):
    query: str = Field(..., description="Search query string")
    max_results: int = Field(default=5, ge=1, le=50, description="Maximum number of search results")
    engine: str = Field(default="duckduckgo", description="Search engine to use")

class SearchResponse(BaseModel):
    urls: List[str]
    count: int

class CrawlRequest(BaseModel):
    url: str = Field(..., description="URL to crawl")

class CrawlResponse(BaseModel):
    url: str
    markdown: str
    content_length: int

class QARequest(BaseModel):
    context: str = Field(..., description="Context text for question answering")
    question: str = Field(..., description="Question to answer")

class QAResponse(BaseModel):
    answer: str
    question: str

class NLIRequest(BaseModel):
    premise: str = Field(..., description="Premise text")
    hypothesis: str = Field(..., description="Hypothesis text")

class NLIResponse(BaseModel):
    score: float
    premise: str
    hypothesis: str

class ProcessRequest(BaseModel):
    query: str = Field(..., description="Search query")
    max_results: int = Field(default=3, ge=1, le=10, description="Maximum number of URLs to process")
    engine: str = Field(default="duckduckgo", description="Search engine to use")

class ProcessResult(BaseModel):
    url: str
    markdown: str
    answer: str
    nli_score: float

class ProcessResponse(BaseModel):
    query: str
    results: List[ProcessResult]

class ExpandRequest(BaseModel):
    query: str = Field(..., description="Query to expand")
    num_queries: int = Field(default=5, ge=3, le=10, description="Number of expanded queries to generate")
    use_serp_only: bool = Field(default=True, description="Use only SERP results without crawling")
    custom_prompt: Optional[str] = Field(default=None, description="Optional custom prompt instruction (default: MECE)")
    max_serp_results: int = Field(default=10, ge=3, le=20, description="Maximum number of SERP results to analyze")

class ScoreRequest(BaseModel):
    claim: str = Field(..., description="The claim to evaluate")
    facts: List[str] = Field(..., min_items=1, description="List of facts to score against the claim")

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Load models
    logger.info("Loading ModernBertQA model...")
    try:
        app.state.qa_model = ModernBertQA()
        logger.info("ModernBertQA model loaded successfully")
    except Exception as e:
        logger.error(f"Failed to load ModernBertQA model: {e}")
        app.state.qa_model = None
    
    logger.info("Loading ModernBertNLI model...")
    try:
        app.state.nli_model = ModernBertNLI()
        logger.info("ModernBertNLI model loaded successfully")
    except Exception as e:
        logger.error(f"Failed to load ModernBertNLI model: {e}")
        app.state.nli_model = None
    
    logger.info("Loading Granite Query Expander model...")
    try:
        app.state.expander_model = GraniteQueryExpander()
        logger.info("Granite Query Expander model loaded successfully")
    except Exception as e:
        logger.error(f"Failed to load Granite Query Expander model: {e}")
        app.state.expander_model = None
    
    yield
    
    # Shutdown: Cleanup (if needed)
    logger.info("Shutting down service...")

app = FastAPI(
    title="DingoCrawl API",
    description="Web crawling service with ModernBERT-based QA and NLI scoring",
    version="0.1.0",
    lifespan=lifespan
)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    qa_ready = app.state.qa_model is not None and app.state.qa_model.qa_pipeline is not None
    nli_ready = app.state.nli_model is not None and app.state.nli_model.nli_pipeline is not None
    expander_ready = app.state.expander_model is not None and app.state.expander_model.model is not None
    
    return {
        "status": "healthy" if (qa_ready and nli_ready and expander_ready) else "degraded",
        "qa_model_ready": qa_ready,
        "nli_model_ready": nli_ready,
        "expander_model_ready": expander_ready
    }

@app.post("/search", response_model=SearchResponse)
async def search(request: SearchRequest):
    """Search the web using DDGS"""
    try:
        urls = search_web(request.query, max_results=request.max_results, engine=request.engine)
        return SearchResponse(urls=urls, count=len(urls))
    except Exception as e:
        logger.error(f"Search error: {e}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")

@app.post("/crawl", response_model=CrawlResponse)
async def crawl(request: CrawlRequest):
    """Fetch and convert HTML to markdown"""
    try:
        html = fetch_page(request.url)
        if not html:
            raise HTTPException(status_code=404, detail=f"Failed to fetch content from {request.url}")
        
        markdown = html_to_markdown(html)
        return CrawlResponse(
            url=request.url,
            markdown=markdown,
            content_length=len(markdown)
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Crawl error: {e}")
        raise HTTPException(status_code=500, detail=f"Crawl failed: {str(e)}")

@app.post("/qa", response_model=QAResponse)
async def qa(request: QARequest):
    """Answer a question using ModernBertQA"""
    if not app.state.qa_model or not app.state.qa_model.qa_pipeline:
        raise HTTPException(status_code=503, detail="QA model not available")
    
    try:
        answer = app.state.qa_model.answer(request.context, request.question)
        return QAResponse(answer=answer, question=request.question)
    except Exception as e:
        logger.error(f"QA error: {e}")
        raise HTTPException(status_code=500, detail=f"QA failed: {str(e)}")

@app.post("/nli", response_model=NLIResponse)
async def nli(request: NLIRequest):
    """Score entailment using ModernBertNLI"""
    if not app.state.nli_model or not app.state.nli_model.nli_pipeline:
        raise HTTPException(status_code=503, detail="NLI model not available")
    
    try:
        score = app.state.nli_model.score(request.premise, request.hypothesis)
        return NLIResponse(
            score=score,
            premise=request.premise,
            hypothesis=request.hypothesis
        )
    except Exception as e:
        logger.error(f"NLI error: {e}")
        raise HTTPException(status_code=500, detail=f"NLI failed: {str(e)}")

@app.post("/process", response_model=ProcessResponse)
async def process(request: ProcessRequest):
    """Full pipeline: search → crawl → qa → nli"""
    if not app.state.qa_model or not app.state.qa_model.qa_pipeline:
        raise HTTPException(status_code=503, detail="QA model not available")
    if not app.state.nli_model or not app.state.nli_model.nli_pipeline:
        raise HTTPException(status_code=503, detail="NLI model not available")
    
    try:
        # Search
        urls = search_web(request.query, max_results=request.max_results, engine=request.engine)
        if not urls:
            return ProcessResponse(query=request.query, results=[])
        
        results = []
        for url in urls:
            try:
                # Crawl
                html = fetch_page(url)
                if not html:
                    continue
                
                markdown = html_to_markdown(html)
                
                # QA
                answer = app.state.qa_model.answer(markdown, request.query)
                
                # NLI (use first 2000 chars of markdown as premise)
                nli_score = app.state.nli_model.score(markdown[:2000], answer)
                
                results.append(ProcessResult(
                    url=url,
                    markdown=markdown,
                    answer=answer,
                    nli_score=nli_score
                ))
            except Exception as e:
                logger.warning(f"Error processing {url}: {e}")
                continue
        
        return ProcessResponse(query=request.query, results=results)
    except Exception as e:
        logger.error(f"Process error: {e}")
        raise HTTPException(status_code=500, detail=f"Process failed: {str(e)}")

@app.post("/expand", response_model=MECEQueryExpansion)
async def expand(request: ExpandRequest):
    """Expand a query using Granite model with SERP-based MECE expansion"""
    if not app.state.expander_model or not app.state.expander_model.model:
        raise HTTPException(status_code=503, detail="Query expander model not available")
    
    try:
        result = app.state.expander_model.generate_structured_output(
            query=request.query,
            num_queries=request.num_queries,
            use_serp_only=request.use_serp_only,
            custom_prompt=request.custom_prompt,
            max_serp_results=request.max_serp_results
        )
        return result
    except Exception as e:
        logger.error(f"Expand error: {e}")
        raise HTTPException(status_code=500, detail=f"Query expansion failed: {str(e)}")

@app.post("/score", response_model=DempsterShaferScore)
async def score_claim(request: ScoreRequest):
    """Score a claim against facts using Dempster-Shafer theory with Granite model"""
    if not app.state.expander_model or not app.state.expander_model.model:
        raise HTTPException(status_code=503, detail="Query expander model not available")
    
    try:
        result = app.state.expander_model.score_claim_dempster_shafer(
            claim=request.claim,
            facts=request.facts
        )
        return result
    except Exception as e:
        logger.error(f"Score error: {e}")
        raise HTTPException(status_code=500, detail=f"Claim scoring failed: {str(e)}")

