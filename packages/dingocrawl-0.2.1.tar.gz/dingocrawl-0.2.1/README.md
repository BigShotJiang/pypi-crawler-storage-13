# DingoCrawl

DingoCrawl is a powerful web crawling solution with a FastAPI service that integrates search, HTML-to-Markdown conversion, ModernBERT-based Question Answering (QA) and Natural Language Inference (NLI) scoring, and Granite model for query expansion and Dempster-Shafer claim scoring.

## Features

- **FastAPI Service**: Hot-loaded models for fast inference
- **Search**: Uses `duckduckgo-search` to find relevant URLs
- **Crawling**: Fetches HTML and converts it to Markdown using a custom rule-based converter
- **Bot Evasion**: Implements User-Agent rotation and realistic browser headers
- **QA**: Uses ModernBERT-based models for extractive QA
- **NLI**: Uses NLI models to score the entailment of answers
- **Query Expansion**: Uses IBM Granite 4.0-H-350M model for MECE query expansion with SERP analysis
- **Dempster-Shafer Scoring**: Scores claims against facts using Granite model

## Installation

```bash
pip install dingocrawl
```

## Quick Start

### Start the FastAPI Service

```bash
dingocrawl start
```

The service will be available at `http://127.0.0.1:8000`

### Stop the Service

```bash
dingocrawl stop
```

### API Documentation

Once running, visit:
- Swagger UI: http://127.0.0.1:8000/docs
- ReDoc: http://127.0.0.1:8000/redoc

## API Endpoints

### Health Check
```bash
curl http://127.0.0.1:8000/health
```

### Query Expansion
```bash
curl -X POST http://127.0.0.1:8000/expand \
  -H "Content-Type: application/json" \
  -d '{"query": "machine learning", "num_queries": 5}'
```

### Dempster-Shafer Claim Scoring
```bash
curl -X POST http://127.0.0.1:8000/score \
  -H "Content-Type: application/json" \
  -d '{
    "claim": "Python is the best language for beginners",
    "facts": [
      "Python has simple syntax",
      "Python has extensive documentation"
    ]
  }'
```

### Question Answering
```bash
curl -X POST http://127.0.0.1:8000/qa \
  -H "Content-Type: application/json" \
  -d '{
    "context": "Python is a programming language created by Guido van Rossum.",
    "question": "Who created Python?"
  }'
```

### Full Pipeline
```bash
curl -X POST http://127.0.0.1:8000/process \
  -H "Content-Type: application/json" \
  -d '{"query": "What is Python?", "max_results": 3}'
```

## Command Line Usage

### Legacy Query Mode (Backward Compatible)
```bash
dingocrawl --query "What is the capital of France?"
```

## Python API

```python
from dingocrawl import search_web, fetch_page, html_to_markdown, ModernBertQA

# Search
urls = search_web("Python programming")

# Crawl
html = fetch_page(urls[0])
markdown = html_to_markdown(html)

# QA
qa = ModernBertQA()
answer = qa.answer(markdown, "What is Python?")
print(answer)
```

## Models

- **ModernBertQA**: Question answering model (deepset/roberta-base-squad2)
- **ModernBertNLI**: Natural language inference model (cross-encoder/nli-deberta-v3-base)
- **Granite Query Expander**: IBM Granite 4.0-H-350M for query expansion and claim scoring

All models are hot-loaded at service startup for fast inference.

## License

MIT
