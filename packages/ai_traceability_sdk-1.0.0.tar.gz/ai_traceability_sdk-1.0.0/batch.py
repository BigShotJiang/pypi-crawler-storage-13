"""
Batch processing functionality for the AI Traceability SDK.
Provides intelligent batching with automatic flushing and error handling.
"""

import asyncio
import uuid
from typing import List, Dict, Any, Optional, Callable
from datetime import datetime, timezone
import logging
from contextlib import asynccontextmanager

from .models import ActivityData, ToolCallData, DecisionData, BatchResponse
from .exceptions import BatchError


logger = logging.getLogger(__name__)


class BatchProcessor:
    """Intelligent batch processor with automatic flushing and error handling."""

    def __init__(
        self,
        send_func: Callable,
        batch_size: int = 100,
        batch_timeout_seconds: float = 5.0,
        auto_flush_enabled: bool = True,
        max_retries: int = 3,
    ):
        """
        Initialize batch processor.

        Args:
            send_func: Function to send batches to the server
            batch_size: Maximum items per batch
            batch_timeout_seconds: Maximum time to wait before flushing
            auto_flush_enabled: Whether to automatically flush batches
            max_retries: Maximum retry attempts for failed batches
        """
        self.send_func = send_func
        self.batch_size = batch_size
        self.batch_timeout_seconds = batch_timeout_seconds
        self.auto_flush_enabled = auto_flush_enabled
        self.max_retries = max_retries

        self._batch_queue: List[Dict[str, Any]] = []
        self._batch_lock = asyncio.Lock()
        self._flush_task: Optional[asyncio.Task] = None
        self._last_flush_time = datetime.now(timezone.utc)
        self._is_shutdown = False

        # Start auto-flush if enabled
        if self.auto_flush_enabled:
            self._start_auto_flush()

    def _start_auto_flush(self) -> None:
        """Start the automatic flush task."""
        if self._flush_task is None or self._flush_task.done():
            self._flush_task = asyncio.create_task(self._auto_flush_worker())

    async def _auto_flush_worker(self) -> None:
        """Worker coroutine for automatic batch flushing."""
        while not self._is_shutdown:
            try:
                await asyncio.sleep(self.batch_timeout_seconds)

                # Check if we need to flush based on time
                time_since_last_flush = (
                    datetime.now(timezone.utc) - self._last_flush_time
                ).total_seconds()

                if time_since_last_flush >= self.batch_timeout_seconds:
                    await self._flush_if_not_empty()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in auto-flush worker: {e}")
                await asyncio.sleep(1.0)  # Brief pause before retrying

    async def add_activity(self, activity: ActivityData, session_id: str) -> None:
        """Add an activity to the batch queue."""
        item = {
            "type": "activity",
            "data": activity.dict(),
            "session_id": session_id,
            "id": str(uuid.uuid4()),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        await self._add_item(item)

    async def add_tool_call(self, tool_call: ToolCallData, session_id: str) -> None:
        """Add a tool call to the batch queue."""
        item = {
            "type": "tool_call",
            "data": tool_call.dict(),
            "session_id": session_id,
            "id": str(uuid.uuid4()),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        await self._add_item(item)

    async def add_decision(self, decision: DecisionData, session_id: str) -> None:
        """Add a decision to the batch queue."""
        item = {
            "type": "decision",
            "data": decision.dict(),
            "session_id": session_id,
            "id": str(uuid.uuid4()),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        await self._add_item(item)

    async def _add_item(self, item: Dict[str, Any]) -> None:
        """Add an item to the batch queue and flush if necessary."""
        async with self._batch_lock:
            self._batch_queue.append(item)

            # Auto-flush if batch is full
            if len(self._batch_queue) >= self.batch_size:
                await self._flush_batch()

    async def flush(self) -> Optional[BatchResponse]:
        """Manually flush the current batch."""
        async with self._batch_lock:
            return await self._flush_batch()

    async def _flush_if_not_empty(self) -> Optional[BatchResponse]:
        """Flush batch if it's not empty."""
        async with self._batch_lock:
            if self._batch_queue:
                return await self._flush_batch()
        return None

    async def _flush_batch(self) -> Optional[BatchResponse]:
        """Flush the current batch (must be called within lock)."""
        if not self._batch_queue:
            return None

        # Take a copy of the current batch and clear the queue
        batch_items = self._batch_queue.copy()
        self._batch_queue.clear()
        self._last_flush_time = datetime.now(timezone.utc)

        batch_id = str(uuid.uuid4())

        logger.debug(f"Flushing batch {batch_id} with {len(batch_items)} items")

        # Send batch with retry logic
        for attempt in range(self.max_retries + 1):
            try:
                await self.send_func(batch_items)

                logger.info(
                    f"Successfully sent batch {batch_id} with {len(batch_items)} items"
                )

                return BatchResponse(
                    batch_id=batch_id, item_count=len(batch_items), status="completed"
                )

            except Exception as e:
                if attempt < self.max_retries:
                    wait_time = 2**attempt  # Exponential backoff
                    logger.warning(
                        f"Batch {batch_id} failed (attempt {attempt + 1}), "
                        f"retrying in {wait_time}s: {e}"
                    )
                    await asyncio.sleep(wait_time)
                else:
                    logger.error(
                        f"Batch {batch_id} failed after {self.max_retries + 1} attempts: {e}"
                    )

                    # Re-queue failed items (optional behavior)
                    if self.auto_flush_enabled:
                        async with self._batch_lock:
                            self._batch_queue.extend(batch_items)

                    raise BatchError(
                        f"Failed to send batch after {self.max_retries + 1} attempts",
                        failed_items=batch_items,
                    )

        return None

    def get_queue_size(self) -> int:
        """Get the current queue size."""
        return len(self._batch_queue)

    def get_stats(self) -> Dict[str, Any]:
        """Get batch processor statistics."""
        return {
            "queue_size": len(self._batch_queue),
            "batch_size": self.batch_size,
            "batch_timeout_seconds": self.batch_timeout_seconds,
            "auto_flush_enabled": self.auto_flush_enabled,
            "max_retries": self.max_retries,
            "last_flush_time": self._last_flush_time.isoformat(),
            "is_shutdown": self._is_shutdown,
        }

    async def shutdown(self, flush_remaining: bool = True) -> None:
        """Shutdown the batch processor."""
        self._is_shutdown = True

        # Cancel auto-flush task
        if self._flush_task and not self._flush_task.done():
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass

        # Flush remaining items if requested
        if flush_remaining and self._batch_queue:
            try:
                await self.flush()
                logger.info("Flushed remaining items during shutdown")
            except Exception as e:
                logger.error(f"Failed to flush remaining items during shutdown: {e}")

    @asynccontextmanager
    async def batch_context(self):
        """Context manager for batch processing."""
        try:
            yield self
        finally:
            await self.shutdown(flush_remaining=True)

    def __len__(self) -> int:
        """Get the current queue size."""
        return len(self._batch_queue)

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.shutdown(flush_remaining=True)
