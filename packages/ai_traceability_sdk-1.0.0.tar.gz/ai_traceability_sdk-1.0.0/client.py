"""
AI Traceability Python SDK Client.
Provides async/sync clients with comprehensive functionality.
"""

import asyncio
import uuid
import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
from contextlib import asynccontextmanager
from concurrent.futures import ThreadPoolExecutor

import httpx

from .config import SDKConfig
from .models import (
    ActivityData,
    ToolCallData,
    DecisionData,
    ActivityResponse,
    ToolCallResponse,
    DecisionResponse,
    BatchResponse,
    ActivitySearchRequest,
    ActivitySearchResponse,
    ToolCallSearchRequest,
    ToolCallSearchResponse,
    # Epic 4: File Tracking Models
    FileOperationType,
    FileOperationData,
    FileOperationResponse,
    SecurityAnalysisData,
    SecurityAnalysisResponse,
    AnomalyDetectionData,
    AnomalyDetectionResponse,
    FileRiskData,
    FileRiskResponse,
    FileTrackingBatchRequest,
    FileTrackingBatchResponse,
)
from .exceptions import (
    TraceabilityError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    NetworkError,
    ServerError,
    TimeoutError,
)
from .session import Session
from .batch import BatchProcessor


logger = logging.getLogger(__name__)


class AITraceabilityClient:
    """AI Traceability SDK Client with async/sync support."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        service_url: Optional[str] = None,
        config: Optional[SDKConfig] = None,
        **config_kwargs,
    ):
        """
        Initialize the AI Traceability Client.

        Args:
            api_key: API key for authentication
            service_url: Base URL for the service
            config: SDK configuration object
            **config_kwargs: Additional configuration options
        """
        # Initialize configuration
        try:
            if config is None:
                config_data = {}
                if api_key:
                    config_data["api_key"] = api_key
                if service_url:
                    config_data["service_url"] = service_url
                config_data.update(config_kwargs)
                self.config = SDKConfig(**config_data)
            else:
                self.config = config
                if api_key:
                    self.config.api_key = api_key
                if service_url:
                    self.config.service_url = service_url
        except Exception as e:
            # Convert Pydantic validation errors to our ValidationError
            raise ValidationError(f"Configuration validation failed: {e}")

        # Validate configuration
        if not self.config.api_key or self.config.api_key is None:
            raise ValidationError("API key is required")

        # Initialize HTTP client
        self._http_client: Optional[httpx.AsyncClient] = None
        self._sync_http_client: Optional[httpx.Client] = None

        # Initialize batch processor
        self._batch_processor: Optional[BatchProcessor] = None

        # Thread pool for sync operations
        self._thread_pool = ThreadPoolExecutor(max_workers=4)

        # Client state
        self._closed = False

        logger.info(f"Initialized AI Traceability Client for {self.config.service_url}")

    async def _get_http_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._http_client is None or self._http_client.is_closed:
            limits = httpx.Limits(
                max_keepalive_connections=self.config.pool_connections,
                max_connections=self.config.pool_maxsize,
                keepalive_expiry=300,  # 5 minutes
            )

            timeout_config = self.config.get_timeout_config()
            timeout = httpx.Timeout(
                connect=timeout_config["connect"],
                read=timeout_config["read"],
                write=timeout_config["write"],
                pool=timeout_config["pool"],
            )

            self._http_client = httpx.AsyncClient(
                base_url=self.config.service_url,
                headers=self.config.get_headers(),
                timeout=timeout,
                limits=limits,
                verify=self.config.verify_ssl,
                http2=True,  # Enable HTTP/2 for better performance
            )

        return self._http_client

    def _get_sync_http_client(self) -> httpx.Client:
        """Get or create sync HTTP client."""
        if self._sync_http_client is None or self._sync_http_client.is_closed:
            limits = httpx.Limits(
                max_keepalive_connections=self.config.pool_connections,
                max_connections=self.config.pool_maxsize,
                keepalive_expiry=300,  # 5 minutes
            )

            timeout_config = self.config.get_timeout_config()
            timeout = httpx.Timeout(
                connect=timeout_config["connect"],
                read=timeout_config["read"],
                write=timeout_config["write"],
                pool=timeout_config["pool"],
            )

            self._sync_http_client = httpx.Client(
                base_url=self.config.service_url,
                headers=self.config.get_headers(),
                timeout=timeout,
                limits=limits,
                verify=self.config.verify_ssl,
                http2=True,
            )

        return self._sync_http_client

    async def _get_batch_processor(self) -> BatchProcessor:
        """Get or create batch processor."""
        if self._batch_processor is None:
            self._batch_processor = BatchProcessor(
                send_func=self._send_batch,
                batch_size=self.config.batch_size,
                batch_timeout_seconds=self.config.batch_timeout_seconds,
                auto_flush_enabled=self.config.auto_flush_enabled,
                max_retries=self.config.max_retries,
            )

        return self._batch_processor

    async def _send_batch(self, batch_items: List[Dict[str, Any]]) -> None:
        """Send a batch of items to the server."""
        client = await self._get_http_client()

        # Group items by type for different endpoints
        activities = [item for item in batch_items if item["type"] == "activity"]
        tool_calls = [item for item in batch_items if item["type"] == "tool_call"]
        decisions = [item for item in batch_items if item["type"] == "decision"]

        # Send activities
        if activities:
            await self._send_request(
                client,
                "POST",
                "/api/v1/activities/batch",
                {"activities": [item["data"] for item in activities]},
            )

        # Send tool calls
        if tool_calls:
            await self._send_request(
                client,
                "POST",
                "/api/v1/tool_calls/batch",
                {"tool_calls": [item["data"] for item in tool_calls]},
            )

        # Send decisions
        if decisions:
            await self._send_request(
                client,
                "POST",
                "/api/v1/decisions/batch",
                {"decisions": [item["data"] for item in decisions]},
            )

    async def _send_request(
        self,
        client: httpx.AsyncClient,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Send HTTP request with retry logic."""
        last_exception = None

        for attempt in range(self.config.max_retries + 1):
            try:
                if self.config.log_requests:
                    logger.debug(f"{method} {endpoint}: {data}")

                response = await client.request(
                    method, endpoint, json=data, params=params
                )

                if self.config.log_responses:
                    logger.debug(f"Response {response.status_code}: {response.text}")

                # Handle different response codes
                if response.status_code == 401:
                    raise AuthenticationError("Authentication failed")
                elif response.status_code == 429:
                    retry_after = response.headers.get("Retry-After")
                    raise RateLimitError(
                        "Rate limit exceeded",
                        retry_after=int(retry_after) if retry_after else None,
                    )
                elif 400 <= response.status_code < 500:
                    raise ValidationError(f"Client error: {response.status_code}")
                elif response.status_code >= 500:
                    raise ServerError(
                        f"Server error: {response.status_code}",
                        status_code=response.status_code,
                    )

                response.raise_for_status()
                return response.json()

            except httpx.TimeoutException as e:
                last_exception = TimeoutError(f"Request timed out: {e}")
                if not self.config.retry_on_timeout:
                    raise last_exception
            except httpx.NetworkError as e:
                last_exception = NetworkError(f"Network error: {e}")
            except (AuthenticationError, RateLimitError, ValidationError) as e:
                # Don't retry client errors
                raise e
            except ServerError as e:
                last_exception = e
            except Exception as e:
                last_exception = TraceabilityError(f"Unexpected error: {e}")

            # Calculate delay for next attempt
            if attempt < self.config.max_retries:
                delays = self.config.get_retry_delays()
                wait_time = delays[attempt] if attempt < len(delays) else delays[-1]

                logger.warning(
                    f"Request failed (attempt {attempt + 1}), "
                    f"retrying in {wait_time:.2f}s: {last_exception}"
                )

                await asyncio.sleep(wait_time)

        # All retries exhausted
        raise last_exception or TraceabilityError("Request failed after all retries")

    # Public async methods
    async def log_activity_structured(
        self,
        session_id: str,
        activity_type: str,
        data: ActivityData,
        activity_subtype: Optional[str] = None,
        duration_ms: Optional[int] = None,
        token_count: Optional[int] = None,
        app_id: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> ActivityResponse:
        """Log an activity using structured ActivityData object (original API)."""
        if self._closed:
            raise ValidationError("Client has been closed")

        # Set app_id if provided
        if app_id and not data.app_id:
            data.app_id = app_id

        # Set project_id if provided
        if project_id and not data.project_id:
            data.project_id = project_id

        batch_processor = await self._get_batch_processor()
        await batch_processor.add_activity(data, session_id)

        return ActivityResponse(
            id=str(uuid.uuid4()),
            session_id=session_id,
            queued=True,
            timestamp=datetime.now(timezone.utc),
            app_id=app_id,
            project_id=project_id,
        )

    async def log_tool_call(
        self, session_id: str, tool_call: ToolCallData, app_id: Optional[str] = None, project_id: Optional[str] = None
    ) -> ToolCallResponse:
        """Log a tool call asynchronously."""
        if self._closed:
            raise ValidationError("Client has been closed")

        # Set app_id if provided
        if app_id and not tool_call.app_id:
            tool_call.app_id = app_id

        # Set project_id if provided
        if project_id and not tool_call.project_id:
            tool_call.project_id = project_id

        # Calculate cost if not provided
        if tool_call.estimated_cost_cents is None:
            tool_call.estimated_cost_cents = self._estimate_cost(tool_call)

        # Set MCP server info if not provided
        if not tool_call.mcp_server_name:
            tool_call.mcp_server_name = "python-sdk"
            tool_call.mcp_server_version = "1.0.0"

        batch_processor = await self._get_batch_processor()
        await batch_processor.add_tool_call(tool_call, session_id)

        return ToolCallResponse(
            id=str(uuid.uuid4()),
            session_id=session_id,
            tool_name=tool_call.tool_name,
            status=tool_call.status,
            timestamp=datetime.now(timezone.utc),
            app_id=app_id,
            project_id=project_id,
        )

    async def log_decision_structured(
        self, session_id: str, decision: DecisionData, app_id: Optional[str] = None, project_id: Optional[str] = None
    ) -> DecisionResponse:
        """Log a decision using structured DecisionData object (original API)."""
        if self._closed:
            raise ValidationError("Client has been closed")

        # Set app_id if provided
        if app_id and not decision.app_id:
            decision.app_id = app_id

        # Set project_id if provided
        if project_id and not decision.project_id:
            decision.project_id = project_id

        batch_processor = await self._get_batch_processor()
        await batch_processor.add_decision(decision, session_id)

        return DecisionResponse(
            id=str(uuid.uuid4()),
            session_id=session_id,
            decision_name=decision.name or "decision",
            timestamp=datetime.now(timezone.utc),
            app_id=app_id,
            project_id=project_id,
        )

    async def flush(self) -> Optional[BatchResponse]:
        """Manually flush the batch queue."""
        if self._batch_processor:
            return await self._batch_processor.flush()
        return None

    # Search methods for project filtering
    async def search_activities(
        self,
        project_ids: Optional[List[str]] = None,
        activity_types: Optional[List[str]] = None,
        activity_subtypes: Optional[List[str]] = None,
        user_id: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> ActivitySearchResponse:
        """Search activities with project filtering support."""
        if self._closed:
            raise ValidationError("Client has been closed")
            
        client = await self._get_http_client()
        
        search_request = ActivitySearchRequest(
            project_ids=project_ids,
            activity_types=activity_types,
            activity_subtypes=activity_subtypes,
            user_id=user_id,
            start_time=start_time,
            end_time=end_time,
            page=page,
            page_size=page_size,
        )
        
        response_data = await self._send_request(
            client,
            "POST",
            "/api/v1/activities/search",
            search_request.dict(exclude_none=True),
        )
        
        return ActivitySearchResponse(**response_data)

    async def search_tool_calls(
        self,
        project_ids: Optional[List[str]] = None,
        tool_names: Optional[List[str]] = None,
        tool_categories: Optional[List[str]] = None,
        statuses: Optional[List[str]] = None,
        user_id: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        page: int = 1,
        page_size: int = 10,
    ) -> ToolCallSearchResponse:
        """Search tool calls with project filtering support."""
        if self._closed:
            raise ValidationError("Client has been closed")
            
        client = await self._get_http_client()
        
        search_request = ToolCallSearchRequest(
            project_ids=project_ids,
            tool_names=tool_names,
            tool_categories=tool_categories,
            statuses=statuses,
            user_id=user_id,
            start_time=start_time,
            end_time=end_time,
            page=page,
            page_size=page_size,
        )
        
        response_data = await self._send_request(
            client,
            "POST",
            "/api/v1/tool_calls/search",
            search_request.dict(exclude_none=True),
        )
        
        return ToolCallSearchResponse(**response_data)

    # =============================================================================
    # Epic 4: File Tracking Methods
    # =============================================================================

    async def log_file_read(
        self, 
        session_id: str, 
        operation_data: FileOperationData,
        project_id: Optional[str] = None
    ) -> FileOperationResponse:
        """
        Log file read operation with comprehensive security analysis.
        
        Args:
            session_id: Session identifier
            operation_data: File operation data containing file_path, file_size, etc.
            project_id: Optional project identifier
            
        Returns:
            FileOperationResponse with operation details and risk analysis
        """
        if self._closed:
            raise ValidationError("Client has been closed")
        
        # Set project_id if provided
        if project_id and not operation_data.project_id:
            operation_data.project_id = project_id
            
        client = await self._get_http_client()
        
        request_data = {
            "session_id": session_id,
            "project_id": operation_data.project_id,
            "file_path": operation_data.file_path,
            "file_size": operation_data.file_size or 0,
            "partial_read": operation_data.partial_read or False,
            "byte_range": list(operation_data.byte_range) if operation_data.byte_range else None,
            "user_id": operation_data.user_id
        }
        
        response_data = await self._send_request(
            client, "POST", "/api/v1/file-tracking/read", request_data
        )
        
        return FileOperationResponse(
            id=response_data["id"],
            session_id=session_id,
            operation=FileOperationType.READ,
            file_path=operation_data.file_path,
            timestamp=datetime.now(timezone.utc),
            status=response_data.get("status", "success"),
            risk_score=response_data.get("risk_score"),
            risk_level=response_data.get("risk_level"),
            project_id=operation_data.project_id
        )

    async def log_file_write(
        self, 
        session_id: str, 
        operation_data: FileOperationData,
        project_id: Optional[str] = None
    ) -> FileOperationResponse:
        """
        Log file write operation with security analysis and risk assessment.
        
        Args:
            session_id: Session identifier
            operation_data: File operation data containing file_path, content_size, etc.
            project_id: Optional project identifier
            
        Returns:
            FileOperationResponse with operation details and risk analysis
        """
        if self._closed:
            raise ValidationError("Client has been closed")
        
        # Set project_id if provided
        if project_id and not operation_data.project_id:
            operation_data.project_id = project_id
            
        client = await self._get_http_client()
        
        request_data = {
            "session_id": session_id,
            "project_id": operation_data.project_id,
            "file_path": operation_data.file_path,
            "content_size": operation_data.content_size or operation_data.file_size or 0,
            "operation_type": operation_data.operation_type or "write",
            "content_hash_before": operation_data.content_hash_before,
            "content_hash_after": operation_data.content_hash_after,
            "user_id": operation_data.user_id
        }
        
        response_data = await self._send_request(
            client, "POST", "/api/v1/file-tracking/write", request_data
        )
        
        return FileOperationResponse(
            id=response_data["id"],
            session_id=session_id,
            operation=FileOperationType.WRITE,
            file_path=operation_data.file_path,
            timestamp=datetime.now(timezone.utc),
            status=response_data.get("status", "success"),
            risk_score=response_data.get("risk_score"),
            risk_level=response_data.get("risk_level"),
            project_id=operation_data.project_id
        )

    async def log_file_delete(
        self, 
        session_id: str, 
        operation_data: FileOperationData,
        project_id: Optional[str] = None
    ) -> FileOperationResponse:
        """
        Log file deletion operation with high-priority security monitoring.
        
        Args:
            session_id: Session identifier
            operation_data: File operation data containing file_path, file_size, etc.
            project_id: Optional project identifier
            
        Returns:
            FileOperationResponse with operation details and risk analysis
        """
        if self._closed:
            raise ValidationError("Client has been closed")
        
        # Set project_id if provided
        if project_id and not operation_data.project_id:
            operation_data.project_id = project_id
            
        client = await self._get_http_client()
        
        request_data = {
            "session_id": session_id,
            "project_id": operation_data.project_id,
            "file_path": operation_data.file_path,
            "file_size": operation_data.file_size,
            "content_hash": operation_data.content_hash,
            "user_id": operation_data.user_id
        }
        
        response_data = await self._send_request(
            client, "POST", "/api/v1/file-tracking/delete", request_data
        )
        
        return FileOperationResponse(
            id=response_data["id"],
            session_id=session_id,
            operation=FileOperationType.DELETE,
            file_path=operation_data.file_path,
            timestamp=datetime.now(timezone.utc),
            status=response_data.get("status", "success"),
            risk_score=response_data.get("risk_score"),
            risk_level=response_data.get("risk_level"),
            project_id=operation_data.project_id
        )

    async def log_file_move(
        self, 
        session_id: str, 
        operation_data: FileOperationData,
        project_id: Optional[str] = None
    ) -> FileOperationResponse:
        """
        Log file move/rename operation with path security analysis.
        
        Args:
            session_id: Session identifier
            operation_data: File operation data containing source_path, destination_path, etc.
            project_id: Optional project identifier
            
        Returns:
            FileOperationResponse with operation details and risk analysis
        """
        if self._closed:
            raise ValidationError("Client has been closed")
        
        if not operation_data.source_path or not operation_data.destination_path:
            raise ValidationError("source_path and destination_path are required for move operations")
        
        # Set project_id if provided
        if project_id and not operation_data.project_id:
            operation_data.project_id = project_id
            
        client = await self._get_http_client()
        
        request_data = {
            "session_id": session_id,
            "project_id": operation_data.project_id,
            "source_path": operation_data.source_path,
            "destination_path": operation_data.destination_path,
            "file_size": operation_data.file_size,
            "user_id": operation_data.user_id
        }
        
        response_data = await self._send_request(
            client, "POST", "/api/v1/file-tracking/move", request_data
        )
        
        return FileOperationResponse(
            id=response_data["id"],
            session_id=session_id,
            operation=FileOperationType.MOVE,
            file_path=operation_data.destination_path,
            timestamp=datetime.now(timezone.utc),
            status=response_data.get("status", "success"),
            risk_score=response_data.get("risk_score"),
            risk_level=response_data.get("risk_level"),
            project_id=operation_data.project_id
        )

    async def log_file_copy(
        self, 
        session_id: str, 
        operation_data: FileOperationData,
        project_id: Optional[str] = None
    ) -> FileOperationResponse:
        """
        Log file copy operation with data exfiltration monitoring.
        
        Args:
            session_id: Session identifier
            operation_data: File operation data containing source_path, destination_path, etc.
            project_id: Optional project identifier
            
        Returns:
            FileOperationResponse with operation details and risk analysis
        """
        if self._closed:
            raise ValidationError("Client has been closed")
        
        if not operation_data.source_path or not operation_data.destination_path:
            raise ValidationError("source_path and destination_path are required for copy operations")
        
        # Set project_id if provided
        if project_id and not operation_data.project_id:
            operation_data.project_id = project_id
            
        client = await self._get_http_client()
        
        request_data = {
            "session_id": session_id,
            "project_id": operation_data.project_id,
            "source_path": operation_data.source_path,
            "destination_path": operation_data.destination_path,
            "file_size": operation_data.file_size,
            "user_id": operation_data.user_id
        }
        
        response_data = await self._send_request(
            client, "POST", "/api/v1/file-tracking/copy", request_data
        )
        
        return FileOperationResponse(
            id=response_data["id"],
            session_id=session_id,
            operation=FileOperationType.COPY,
            file_path=operation_data.destination_path,
            timestamp=datetime.now(timezone.utc),
            status=response_data.get("status", "success"),
            risk_score=response_data.get("risk_score"),
            risk_level=response_data.get("risk_level"),
            project_id=operation_data.project_id
        )

    async def analyze_file_security(
        self, 
        session_id: str, 
        analysis_data: SecurityAnalysisData
    ) -> SecurityAnalysisResponse:
        """
        Perform comprehensive security analysis on file operation.
        
        Args:
            session_id: Session identifier
            analysis_data: Security analysis data containing file details
            
        Returns:
            SecurityAnalysisResponse with detailed security analysis
        """
        if self._closed:
            raise ValidationError("Client has been closed")
            
        client = await self._get_http_client()
        
        request_data = {
            "file_path": analysis_data.file_path,
            "operation": analysis_data.operation,
            "content": analysis_data.content,
            "file_size": analysis_data.file_size,
            "content_hash": analysis_data.content_hash
        }
        
        response_data = await self._send_request(
            client, "POST", "/api/v1/file-tracking/security-analysis", request_data
        )
        
        return SecurityAnalysisResponse(
            file_path=analysis_data.file_path,
            operation=analysis_data.operation,
            risk_score=response_data["risk_score"],
            risk_level=response_data["risk_level"],
            is_sensitive=response_data["is_sensitive"],
            is_executable=response_data["is_executable"],
            is_system=response_data["is_system"],
            has_malicious_content=response_data["has_malicious_content"],
            threats=response_data["threats"],
            recommendations=response_data["recommendations"],
            timestamp=datetime.now(timezone.utc)
        )

    async def detect_file_anomalies(
        self, 
        session_id: str, 
        detection_data: AnomalyDetectionData
    ) -> AnomalyDetectionResponse:
        """
        Detect anomalous file access patterns that may indicate malicious behavior.
        
        Args:
            session_id: Session identifier
            detection_data: Anomaly detection parameters
            
        Returns:
            AnomalyDetectionResponse with anomaly analysis results
        """
        if self._closed:
            raise ValidationError("Client has been closed")
            
        client = await self._get_http_client()
        
        request_data = {
            "session_id": session_id,
            "time_window_minutes": detection_data.time_window_minutes or 30
        }
        
        response_data = await self._send_request(
            client, "POST", "/api/v1/file-tracking/anomaly-detection", request_data
        )
        
        return AnomalyDetectionResponse(
            session_id=session_id,
            anomalies_detected=response_data["anomalies_detected"],
            anomaly_types=response_data["anomaly_types"],
            risk_score=response_data["risk_score"],
            recommendations=response_data["recommendations"],
            timestamp=datetime.now(timezone.utc),
            details=response_data.get("details", {})
        )

    async def calculate_file_risk_score(
        self, 
        session_id: str, 
        risk_data: FileRiskData
    ) -> FileRiskResponse:
        """
        Calculate comprehensive risk score for file operation.
        
        Args:
            session_id: Session identifier
            risk_data: File risk assessment data
            
        Returns:
            FileRiskResponse with calculated risk score and factors
        """
        if self._closed:
            raise ValidationError("Client has been closed")
            
        client = await self._get_http_client()
        
        query_params = {
            "file_path": risk_data.file_path,
            "operation": risk_data.operation,
            "is_sensitive": risk_data.is_sensitive or False,
            "is_executable": risk_data.is_executable or False,
            "is_system": risk_data.is_system or False,
            "file_size": risk_data.file_size,
            "has_malicious_content": risk_data.has_malicious_content or False
        }
        
        response_data = await self._send_request(
            client, "POST", "/api/v1/file-tracking/risk-score", query_params
        )
        
        return FileRiskResponse(
            file_path=risk_data.file_path,
            operation=risk_data.operation,
            risk_score=response_data["risk_score"],
            risk_level=response_data["risk_level"],
            factors=response_data["factors"],
            timestamp=datetime.now(timezone.utc)
        )

    async def log_file_operations_batch(
        self, 
        session_id: str, 
        operations: List[Dict[str, Any]]
    ) -> FileTrackingBatchResponse:
        """
        Process multiple file operations in a single batch request.
        
        Args:
            session_id: Session identifier
            operations: List of file operations to process (max 100)
            
        Returns:
            FileTrackingBatchResponse with batch processing results
        """
        if self._closed:
            raise ValidationError("Client has been closed")
        
        if not operations or len(operations) == 0:
            raise ValidationError("operations array cannot be empty")
        
        if len(operations) > 100:
            raise ValidationError("operations array cannot exceed 100 items")
            
        client = await self._get_http_client()
        
        # Ensure all operations have session_id
        for op in operations:
            if "session_id" not in op:
                op["session_id"] = session_id
        
        request_data = {"operations": operations}
        
        response_data = await self._send_request(
            client, "POST", "/api/v1/file-tracking/batch", request_data
        )
        
        return FileTrackingBatchResponse(
            batch_id=response_data["batch_id"],
            total_requested=response_data["total_requested"],
            successful_count=response_data["successful_count"],
            failed_count=response_data["failed_count"],
            successful_operations=response_data["successful_operations"],
            failed_operations=response_data["failed_operations"],
            timestamp=datetime.now(timezone.utc)
        )

    # Primary dict-based API (user-friendly methods)
    async def log_activity(self, data: Dict[str, Any]) -> ActivityResponse:
        """
        Log an activity using a dictionary (primary API for IDF integration).

        Expected format:
        {
            "activity_type": "chat",
            "data": {"role": "user", "content": "Hello"},
            "session_id": "optional-session-id",  # defaults to "default-session"
            "app_id": "optional-app-id",
            "project_id": "optional-project-id"
        }
        """
        if self._closed:
            raise ValidationError("Client has been closed")

        # Extract activity type, session, app, and project
        activity_type = data.get("activity_type", "unknown")
        session_id = data.get("session_id", "default-session")
        app_id = data.get("app_id")
        project_id = data.get("project_id")
        data_content = data.get("data", {})

        # Create ActivityData from the provided data
        if isinstance(data_content, dict):
            # Convert dict data to content string for ActivityData
            if "content" in data_content:
                content = str(data_content["content"])
            else:
                content = str(data_content)

            activity_data = ActivityData(
                content=content,
                metadata=data_content,
                context={"activity_type": activity_type}
            )
        else:
            # Handle string content directly
            activity_data = ActivityData(
                content=str(data_content),
                metadata={"original_data": data_content},
                context={"activity_type": activity_type}
            )

        return await self.log_activity_structured(
            session_id=session_id,
            activity_type=activity_type,
            data=activity_data,
            app_id=app_id,
            project_id=project_id
        )

    async def log_decision(self, data: Dict[str, Any]) -> DecisionResponse:
        """
        Log a decision using a dictionary (primary API for IDF integration).

        Expected format:
        {
            "decision_type": "reasoning",
            "data": {"analysis": "User needs help with..."},
            "session_id": "optional-session-id",  # defaults to "default-session"
            "app_id": "optional-app-id",
            "project_id": "optional-project-id"
        }
        """
        if self._closed:
            raise ValidationError("Client has been closed")

        # Extract session info
        session_id = data.get("session_id", "default-session")
        decision_type = data.get("decision_type", "unknown")
        app_id = data.get("app_id")
        project_id = data.get("project_id")
        data_content = data.get("data", {})

        # Create DecisionData from the provided data
        decision_data = DecisionData(
            name=data.get("name", f"{decision_type}_decision"),
            decision_type=decision_type,
            reasoning_steps=data.get("reasoning_steps", []),
            decision_context=data_content,
            data=data_content
        )

        return await self.log_decision_structured(session_id=session_id, decision=decision_data, app_id=app_id, project_id=project_id)

    @asynccontextmanager
    async def session(
        self,
        session_id: Optional[str] = None,
        external_session_id: Optional[str] = None,
        agent_type: str = "python-sdk",
        agent_version: str = "1.0.0",
        user_id: Optional[str] = None,
        user_email: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_id: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> Session:
        """Create a session context manager."""
        session_obj = Session(
            client=self,
            session_id=session_id,
            external_session_id=external_session_id,
            agent_type=agent_type,
            agent_version=agent_version,
            user_id=user_id,
            user_email=user_email,
            metadata=metadata,
            app_id=app_id,
            project_id=project_id,
        )

        async with session_obj as session:
            yield session

    async def with_session(
        self,
        session_config: Dict[str, Any],
        callback,
    ):
        """Create a session context manager (TypeScript parity method)."""
        session_obj = Session(
            client=self,
            session_id=session_config.get("session_id"),
            external_session_id=session_config.get("external_session_id"),
            agent_type=session_config.get("agent_type", "python-sdk"),
            agent_version=session_config.get("agent_version", "1.0.0"),
            user_id=session_config.get("user_id"),
            user_email=session_config.get("user_email"),
            metadata=session_config.get("metadata", {}),
            app_id=session_config.get("app_id"),
            project_id=session_config.get("project_id"),
        )

        await session_obj.start()
        try:
            return await callback(session_obj)
        finally:
            await session_obj.end()

    def create_session(
        self,
        session_config: Dict[str, Any],
    ) -> Session:
        """Create a session that can be managed manually (TypeScript parity method)."""
        return Session(
            client=self,
            session_id=session_config.get("session_id"),
            external_session_id=session_config.get("external_session_id"),
            agent_type=session_config.get("agent_type", "python-sdk"),
            agent_version=session_config.get("agent_version", "1.0.0"),
            user_id=session_config.get("user_id"),
            user_email=session_config.get("user_email"),
            metadata=session_config.get("metadata", {}),
            app_id=session_config.get("app_id"),
            project_id=session_config.get("project_id"),
        )

    # Sync methods (using thread pool)
    def log_activity_sync(
        self, session_id: str, activity_type: str, data: ActivityData, **kwargs
    ) -> ActivityResponse:
        """Log an activity synchronously."""
        return self._run_async_in_thread(
            self.log_activity(session_id, activity_type, data, **kwargs)
        )

    def log_tool_call_sync(
        self, session_id: str, tool_call: ToolCallData
    ) -> ToolCallResponse:
        """Log a tool call synchronously."""
        return self._run_async_in_thread(self.log_tool_call(session_id, tool_call))

    def log_decision_sync(
        self, session_id: str, decision: DecisionData
    ) -> DecisionResponse:
        """Log a decision synchronously."""
        return self._run_async_in_thread(self.log_decision(session_id, decision))

    def flush_sync(self) -> Optional[BatchResponse]:
        """Manually flush the batch queue synchronously."""
        return self._run_async_in_thread(self.flush())

    def _run_async_in_thread(self, coro):
        """Run async coroutine in thread pool."""
        future = asyncio.run_coroutine_threadsafe(coro, self._get_event_loop())
        return future.result(timeout=self.config.timeout_seconds)

    def _get_event_loop(self):
        """Get or create event loop for sync operations."""
        try:
            return asyncio.get_running_loop()
        except RuntimeError:
            # Create new event loop in thread
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            return loop

    def _estimate_cost(self, tool_call: ToolCallData) -> int:
        """Estimate cost for tool call (in cents)."""
        # Simple cost estimation logic
        base_cost = 1  # 1 cent base cost

        if tool_call.request_params:
            param_cost = len(str(tool_call.request_params)) // 1000  # 1 cent per 1KB
            base_cost += param_cost

        if tool_call.response_data:
            response_cost = len(str(tool_call.response_data)) // 1000  # 1 cent per 1KB
            base_cost += response_cost

        if tool_call.duration_ms:
            duration_cost = tool_call.duration_ms // 10000  # 1 cent per 10 seconds
            base_cost += duration_cost

        return min(base_cost, 100)  # Cap at $1.00

    async def close(self) -> None:
        """Close the client and clean up resources."""
        if self._closed:
            return

        self._closed = True

        # Flush remaining batches
        if self._batch_processor:
            await self._batch_processor.shutdown(flush_remaining=True)

        # Close HTTP clients
        if self._http_client and not self._http_client.is_closed:
            await self._http_client.aclose()

        if self._sync_http_client and not self._sync_http_client.is_closed:
            self._sync_http_client.close()

        # Shutdown thread pool
        self._thread_pool.shutdown(wait=True)

        logger.info("AI Traceability Client closed")

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()

    def __del__(self):
        """Destructor - ensure resources are cleaned up."""
        if hasattr(self, "_closed") and not self._closed:
            logger.warning("Client was not properly closed, some resources may leak")

    def get_stats(self) -> Dict[str, Any]:
        """Get client statistics."""
        config_dict = self.config.to_dict()
        # Mask sensitive information
        if "api_key" in config_dict:
            config_dict["api_key"] = "***"
        
        stats = {
            "config": config_dict,
            "closed": self._closed,
            "batch_processor": None,
        }

        if self._batch_processor:
            stats["batch_processor"] = self._batch_processor.get_stats()

        return stats
