"""
Exception classes for the AI Traceability SDK.
Provides comprehensive error handling with specific exception types.
"""

from typing import Optional, Dict, Any


class TraceabilityError(Exception):
    """Base exception for all SDK errors."""

    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
        status_code: Optional[int] = None,
        retryable: bool = False,
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        self.request_id = request_id
        self.status_code = status_code
        self.retryable = retryable

    def __str__(self) -> str:
        parts = [self.message]
        if self.error_code:
            parts.append(f"Code: {self.error_code}")
        if self.request_id:
            parts.append(f"Request ID: {self.request_id}")
        return " | ".join(parts)

    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary format."""
        return {
            "error": self.error_code or "UNKNOWN_ERROR",
            "message": self.message,
            "details": self.details,
            "request_id": self.request_id,
            "status_code": self.status_code,
            "retryable": self.retryable,
        }


class AuthenticationError(TraceabilityError):
    """Raised when authentication fails."""

    def __init__(self, message: str = "Authentication failed", **kwargs):
        super().__init__(
            message,
            error_code="AUTHENTICATION_ERROR",
            status_code=401,
            retryable=False,
            **kwargs,
        )


class RateLimitError(TraceabilityError):
    """Raised when rate limits are exceeded."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: Optional[int] = None,
        **kwargs,
    ):
        super().__init__(
            message,
            error_code="RATE_LIMIT_ERROR",
            status_code=429,
            retryable=True,
            **kwargs,
        )
        self.retry_after = retry_after


class ValidationError(TraceabilityError):
    """Raised when data validation fails."""

    def __init__(self, message: str = "Validation failed", **kwargs):
        super().__init__(
            message,
            error_code="VALIDATION_ERROR",
            status_code=400,
            retryable=False,
            **kwargs,
        )


class NetworkError(TraceabilityError):
    """Raised when network operations fail."""

    def __init__(self, message: str = "Network error occurred", **kwargs):
        super().__init__(
            message, error_code="NETWORK_ERROR", status_code=0, retryable=True, **kwargs
        )


class ServerError(TraceabilityError):
    """Raised when server returns 5xx errors."""

    def __init__(
        self,
        message: str = "Server error occurred",
        status_code: Optional[int] = None,
        **kwargs,
    ):
        super().__init__(
            message,
            error_code="SERVER_ERROR",
            status_code=status_code or 500,
            retryable=True,
            **kwargs,
        )


class TimeoutError(TraceabilityError):
    """Raised when operations timeout."""

    def __init__(
        self,
        message: str = "Operation timed out",
        timeout_seconds: Optional[float] = None,
        **kwargs,
    ):
        super().__init__(
            message, error_code="TIMEOUT_ERROR", status_code=0, retryable=True, **kwargs
        )
        self.timeout_seconds = timeout_seconds


class BatchError(TraceabilityError):
    """Raised when batch operations fail."""

    def __init__(
        self,
        message: str = "Batch operation failed",
        failed_items: Optional[list] = None,
        **kwargs,
    ):
        super().__init__(message, error_code="BATCH_ERROR", **kwargs)
        self.failed_items = failed_items or []


class SessionError(TraceabilityError):
    """Raised when session operations fail."""

    def __init__(self, message: str = "Session error occurred", **kwargs):
        super().__init__(message, error_code="SESSION_ERROR", **kwargs)
