"""
Session management for the AI Traceability SDK.
Provides context managers and session lifecycle management.
"""

import uuid
from datetime import datetime, timezone
from typing import Optional, Dict, Any
import logging

from .models import (
    SessionData,
    ActivityData,
    ToolCallData,
    DecisionData,
    ActivityResponse,
    ToolCallResponse,
    DecisionResponse,
)

# Import version for tracking
try:
    from . import __version__ as SDK_VERSION
except ImportError:
    SDK_VERSION = "unknown"


logger = logging.getLogger(__name__)


class Session:
    """Session context manager for AI Traceability SDK."""

    def __init__(
        self,
        client,  # Forward reference to avoid circular import
        session_id: Optional[str] = None,
        external_session_id: Optional[str] = None,
        agent_type: str = "unknown",
        agent_version: Optional[str] = None,
        user_id: Optional[str] = None,
        user_email: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_id: Optional[str] = None,
        project_id: Optional[str] = None,
        auto_end: bool = True,
    ):
        """
        Initialize session.

        Args:
            client: AI Traceability client instance
            session_id: Optional session ID (generated if not provided)
            external_session_id: External session identifier
            agent_type: Type of AI agent
            agent_version: Version of the AI agent
            user_id: User identifier
            user_email: User email
            metadata: Additional session metadata
            app_id: Application identifier
            project_id: Project identifier for session filtering
            auto_end: Whether to automatically end session on exit
        """
        self.client = client
        self.session_id = session_id or str(uuid.uuid4())
        self.external_session_id = external_session_id
        self.agent_type = agent_type
        self.agent_version = agent_version
        self.user_id = user_id
        self.user_email = user_email
        self.metadata = metadata or {}
        # Automatically track SDK version in metadata
        if 'sdk_version' not in self.metadata:
            self.metadata['sdk_version'] = SDK_VERSION
        self.app_id = app_id
        self.project_id = project_id
        self.auto_end = auto_end

        self._started = False
        self._ended = False
        self._start_time: Optional[datetime] = None
        self._end_time: Optional[datetime] = None
        self._activity_count = 0
        self._error_count = 0

        logger.debug(f"Created session {self.session_id}")

    async def start(self) -> None:
        """Start the session."""
        if self._started:
            return

        self._started = True
        self._start_time = datetime.now(timezone.utc)

        logger.info(f"Starting session {self.session_id}")

        # Create session data
        session_data = SessionData(
            session_id=self.session_id,
            external_session_id=self.external_session_id,
            agent_type=self.agent_type,
            agent_version=self.agent_version,
            user_id=self.user_id,
            user_email=self.user_email,
            metadata=self.metadata,
            app_id=self.app_id,
            project_id=self.project_id,
        )

        try:
            # Send session start to the API (if client supports it)
            if hasattr(self.client, "_create_session"):
                await self.client._create_session(session_data)
        except Exception as e:
            logger.warning(f"Failed to create session on server: {e}")
            # Continue anyway - session tracking is still useful locally

    async def end(self) -> None:
        """End the session."""
        if self._ended:
            return

        self._ended = True
        self._end_time = datetime.now(timezone.utc)

        duration = None
        if self._start_time:
            duration = (self._end_time - self._start_time).total_seconds()

        logger.info(
            f"Ending session {self.session_id} "
            f"(duration: {duration:.2f}s, activities: {self._activity_count}, errors: {self._error_count})"
        )

        try:
            # Flush any remaining batch items
            if hasattr(self.client, "_batch_processor"):
                await self.client._batch_processor.flush()

            # Send session end to the API (if client supports it)
            if hasattr(self.client, "_end_session"):
                await self.client._end_session(
                    self.session_id,
                    {
                        "ended_at": self._end_time.isoformat(),
                        "duration_seconds": duration,
                        "activity_count": self._activity_count,
                        "error_count": self._error_count,
                    },
                )
        except Exception as e:
            logger.warning(f"Failed to end session on server: {e}")

    async def log_activity(
        self,
        activity_type: str,
        content: str,
        activity_subtype: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        duration_ms: Optional[int] = None,
        token_count: Optional[int] = None,
    ) -> ActivityResponse:
        """Log an activity in this session."""
        if not self._started:
            await self.start()

        activity_data = ActivityData(
            content=content,
            metadata=metadata or {},
            context=context or {},
            app_id=self.app_id,
            project_id=self.project_id
        )

        try:
            response = await self.client.log_activity_structured(
                session_id=self.session_id,
                activity_type=activity_type,
                activity_subtype=activity_subtype,
                data=activity_data,
                duration_ms=duration_ms,
                token_count=token_count,
                app_id=self.app_id,
                project_id=self.project_id,
            )

            self._activity_count += 1
            logger.debug(
                f"Logged activity in session {self.session_id}: {activity_type}"
            )

            return response

        except Exception as e:
            self._error_count += 1
            logger.error(f"Failed to log activity in session {self.session_id}: {e}")
            raise

    async def log_tool_call(
        self,
        tool_name: str,
        request_params: Optional[Dict[str, Any]] = None,
        response_data: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> ToolCallResponse:
        """Log a tool call in this session."""
        if not self._started:
            await self.start()

        tool_call_data = ToolCallData(
            tool_name=tool_name,
            request_params=request_params,
            response_data=response_data,
            app_id=self.app_id,
            project_id=self.project_id,
            **kwargs,
        )

        try:
            response = await self.client.log_tool_call(
                session_id=self.session_id, tool_call=tool_call_data, app_id=self.app_id, project_id=self.project_id
            )

            self._activity_count += 1
            logger.debug(f"Logged tool call in session {self.session_id}: {tool_name}")

            return response

        except Exception as e:
            self._error_count += 1
            logger.error(f"Failed to log tool call in session {self.session_id}: {e}")
            raise

    async def log_decision(
        self,
        name: str,
        reasoning_steps: list[str],
        decision_type: Optional[str] = None,
        confidence_score: Optional[float] = None,
        selected_option: Optional[Dict[str, Any]] = None,
        alternatives_considered: Optional[list[Dict[str, Any]]] = None,
        decision_context: Optional[Dict[str, Any]] = None,
    ) -> DecisionResponse:
        """Log a decision in this session."""
        if not self._started:
            await self.start()

        decision_data = DecisionData(
            name=name,
            decision_type=decision_type,
            reasoning_steps=reasoning_steps,
            confidence_score=confidence_score,
            selected_option=selected_option,
            alternatives_considered=alternatives_considered or [],
            decision_context=decision_context or {},
            app_id=self.app_id,
            project_id=self.project_id,
        )

        try:
            response = await self.client.log_decision_structured(
                session_id=self.session_id, decision=decision_data, app_id=self.app_id, project_id=self.project_id
            )

            self._activity_count += 1
            logger.debug(f"Logged decision in session {self.session_id}: {name}")

            return response

        except Exception as e:
            self._error_count += 1
            logger.error(f"Failed to log decision in session {self.session_id}: {e}")
            raise

    def get_stats(self) -> Dict[str, Any]:
        """Get session statistics."""
        return {
            "session_id": self.session_id,
            "external_session_id": self.external_session_id,
            "started": self._started,
            "ended": self._ended,
            "start_time": self._start_time.isoformat() if self._start_time else None,
            "end_time": self._end_time.isoformat() if self._end_time else None,
            "duration_seconds": (
                (self._end_time - self._start_time).total_seconds()
                if self._start_time and self._end_time
                else None
            ),
            "activity_count": self._activity_count,
            "error_count": self._error_count,
            "agent_type": self.agent_type,
            "agent_version": self.agent_version,
            "user_id": self.user_id,
            "app_id": self.app_id,
            "project_id": self.project_id,
        }

    async def __aenter__(self):
        """Async context manager entry."""
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if exc_type is not None:
            self._error_count += 1
            logger.error(f"Session {self.session_id} ended with exception: {exc_val}")

        if self.auto_end:
            await self.end()

    def __str__(self) -> str:
        return f"Session(id={self.session_id}, type={self.agent_type}, started={self._started})"

    def __repr__(self) -> str:
        return (
            f"Session(session_id='{self.session_id}', agent_type='{self.agent_type}', "
            f"started={self._started}, ended={self._ended})"
        )
