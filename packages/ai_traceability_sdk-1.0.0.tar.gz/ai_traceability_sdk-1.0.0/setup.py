#!/usr/bin/env python3
"""Setup configuration for AI Traceability Python SDK."""

from setuptools import setup, find_packages
import os

# Version is managed manually for releases
VERSION = "1.1.0"

# Read long description from README
def get_long_description():
    try:
        with open(os.path.join(os.path.dirname(__file__), "README.md"), "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return "AI Traceability Python SDK - A comprehensive SDK for AI activity tracking and monitoring"

setup(
    name="ai-traceability-sdk",
    version=VERSION,
    author="AI Traceability Team",
    author_email="team@ai-traceability.com",
    description="A comprehensive Python SDK for AI activity tracking and monitoring",
    long_description=get_long_description(),
    long_description_content_type="text/markdown",
    url="https://github.com/ai-traceability/python-sdk",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Monitoring",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10", 
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
    install_requires=[
        "aiohttp>=3.8.0",
        "pydantic>=2.0.0",
        "python-dateutil>=2.8.2",
        "typing-extensions>=4.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "isort>=5.12.0",
            "mypy>=1.0.0",
            "flake8>=6.0.0",
        ],
        "docs": [
            "mkdocs>=1.4.0",
            "mkdocs-material>=9.0.0",
            "mkdocstrings[python]>=0.20.0",
        ],
    },
    keywords=[
        "ai", "traceability", "monitoring", "logging", "soc", "security",
        "artificial intelligence", "machine learning", "observability"
    ],
    project_urls={
        "Documentation": "https://docs.ai-traceability.com/",
        "Source": "https://github.com/ai-traceability/python-sdk",
        "Tracker": "https://github.com/ai-traceability/python-sdk/issues",
    },
    include_package_data=True,
    zip_safe=False,
)