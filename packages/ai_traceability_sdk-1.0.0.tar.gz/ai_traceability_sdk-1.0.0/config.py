"""
Configuration management for the AI Traceability SDK.
Supports environment variables, file-based config, and runtime configuration.
"""

import os
from typing import Optional, Dict, Any
from pydantic import Field, field_validator, ConfigDict
from pydantic_settings import BaseSettings


class SDKConfig(BaseSettings):
    """SDK configuration with environment variable support."""

    # Core connection settings
    api_key: Optional[str] = Field(None, description="API key for authentication")
    service_url: str = Field(
        "https://api.ai-traceability.com",
        description="Base URL for the AI Traceability Service",
    )
    timeout_seconds: float = Field(
        30.0, ge=1.0, description="Request timeout in seconds"
    )

    # Batching configuration
    batch_size: int = Field(100, ge=1, le=1000, description="Maximum batch size")
    batch_timeout_seconds: float = Field(
        5.0, ge=0.1, description="Batch timeout in seconds"
    )
    auto_flush_enabled: bool = Field(
        True, description="Enable automatic batch flushing"
    )

    # Retry configuration
    max_retries: int = Field(3, ge=0, le=10, description="Maximum retry attempts")
    retry_backoff_factor: float = Field(
        2.0, ge=1.0, description="Exponential backoff factor"
    )
    retry_jitter: bool = Field(True, description="Enable retry jitter")
    retry_on_timeout: bool = Field(True, description="Retry on timeout errors")

    # Connection pooling
    pool_connections: int = Field(10, ge=1, description="Connection pool size")
    pool_maxsize: int = Field(10, ge=1, description="Maximum pool size")
    pool_block: bool = Field(False, description="Block when pool is full")

    # Security settings
    verify_ssl: bool = Field(True, description="Verify SSL certificates")
    api_key_header: str = Field("Authorization", description="API key header name")
    api_key_prefix: str = Field("Bearer", description="API key prefix")

    # Logging and debugging
    debug_enabled: bool = Field(False, description="Enable debug logging")
    log_level: str = Field("INFO", description="Log level")
    log_requests: bool = Field(False, description="Log HTTP requests")
    log_responses: bool = Field(False, description="Log HTTP responses")

    # Performance settings
    compression_enabled: bool = Field(True, description="Enable request compression")
    keep_alive_enabled: bool = Field(True, description="Enable HTTP keep-alive")

    # Session management
    session_auto_create: bool = Field(True, description="Auto-create sessions")
    session_timeout_minutes: int = Field(
        30, ge=1, description="Session timeout in minutes"
    )

    # Error handling
    raise_on_error: bool = Field(True, description="Raise exceptions on errors")
    include_stack_trace: bool = Field(
        True, description="Include stack traces in errors"
    )

    # Data handling
    sanitize_sensitive_data: bool = Field(True, description="Sanitize sensitive data")
    max_content_length: int = Field(
        1048576, ge=1024, description="Maximum content length in bytes"
    )  # 1MB

    model_config = ConfigDict(
        env_prefix="TRACEABILITY_",
        env_file=None,  # Don't auto-load .env to avoid conflicts
        env_file_encoding="utf-8",
        case_sensitive=False,
        validate_assignment=True,
        extra="ignore",  # Ignore extra fields to avoid conflicts
    )

    @field_validator("service_url")
    @classmethod
    def validate_service_url(cls, v):
        """Validate service URL format."""
        if not v.startswith(("http://", "https://")):
            raise ValueError("service_url must start with http:// or https://")
        if v.endswith("/"):
            v = v.rstrip("/")
        return v

    @field_validator("api_key")
    @classmethod
    def validate_api_key(cls, v):
        """Validate API key format."""
        if v is not None:
            if len(v) < 10:
                raise ValueError("api_key must be at least 10 characters long")
            if not v.replace("-", "").replace("_", "").isalnum():
                raise ValueError(
                    "api_key must contain only alphanumeric characters, hyphens, and underscores"
                )
        return v

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v):
        """Validate log level."""
        valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        v = v.upper()
        if v not in valid_levels:
            raise ValueError(f'log_level must be one of: {", ".join(valid_levels)}')
        return v

    def get_headers(self) -> Dict[str, str]:
        """Get HTTP headers for requests."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "lighthouse-ai-traceability-sdk/1.0.0",
        }

        if self.api_key:
            headers[self.api_key_header] = f"{self.api_key_prefix} {self.api_key}"

        if self.compression_enabled:
            headers["Accept-Encoding"] = "gzip, deflate"

        return headers

    def get_timeout_config(self) -> Dict[str, float]:
        """Get timeout configuration for httpx."""
        return {
            "timeout": self.timeout_seconds,
            "connect": min(self.timeout_seconds, 10.0),
            "read": self.timeout_seconds,
            "write": self.timeout_seconds,
            "pool": 5.0,
        }

    def get_retry_delays(self) -> list[float]:
        """Get retry delays for exponential backoff."""
        delays = []
        for attempt in range(self.max_retries):
            delay = self.retry_backoff_factor**attempt
            if self.retry_jitter:
                import random

                delay *= 0.5 + random.random() * 0.5  # Add jitter
            delays.append(delay)
        return delays

    def update_from_dict(self, config_dict: Dict[str, Any]) -> "SDKConfig":
        """Update configuration from dictionary."""
        for key, value in config_dict.items():
            if hasattr(self, key):
                setattr(self, key, value)
        return self

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return self.model_dump()

    @classmethod
    def from_env(cls) -> "SDKConfig":
        """Create configuration from environment variables."""
        return cls()

    @classmethod
    def from_file(cls, file_path: str) -> "SDKConfig":
        """Create configuration from file."""
        import json
        import yaml

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Configuration file not found: {file_path}")

        with open(file_path, "r") as f:
            if file_path.endswith(".json"):
                config_data = json.load(f)
            elif file_path.endswith((".yml", ".yaml")):
                config_data = yaml.safe_load(f)
            else:
                raise ValueError("Configuration file must be JSON or YAML")

        return cls(**config_data)

    def save_to_file(self, file_path: str) -> None:
        """Save configuration to file."""
        import json

        config_dict = self.to_dict()

        # Remove sensitive data
        if "api_key" in config_dict:
            config_dict["api_key"] = "[REDACTED]"

        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        with open(file_path, "w") as f:
            json.dump(config_dict, f, indent=2, sort_keys=True)
