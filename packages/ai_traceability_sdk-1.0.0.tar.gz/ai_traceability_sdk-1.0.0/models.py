"""
Data models for the AI Traceability SDK.
Provides comprehensive schemas for all SDK operations.
"""

from datetime import datetime, timezone
from typing import Dict, Any, Optional, List, Tuple
from enum import Enum
from pydantic import BaseModel, Field, field_validator, ConfigDict


class ActivityData(BaseModel):
    """Activity data content model."""

    content: str = Field(..., min_length=1, description="Activity content or message")
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Activity metadata"
    )
    context: Dict[str, Any] = Field(
        default_factory=dict, description="Activity context"
    )
    app_id: Optional[str] = Field(
        None, max_length=255, description="Application identifier"
    )
    project_id: Optional[str] = Field(
        None, max_length=255, description="Project identifier for activity filtering"
    )

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class ToolCallData(BaseModel):
    """Complete tool call data model supporting all 25+ fields."""

    # Core identification fields
    tool_name: str = Field(..., description="Name of the tool called")
    tool_category: Optional[str] = Field(None, description="Category of the tool")
    tool_version: Optional[str] = Field(None, description="Version of the tool")

    # MCP server fields
    mcp_server_name: Optional[str] = Field(None, description="MCP server name")
    mcp_server_version: Optional[str] = Field(None, description="MCP server version")

    # Request/response data
    request_params: Optional[Dict[str, Any]] = Field(
        None, description="Tool request parameters"
    )
    response_data: Optional[Dict[str, Any]] = Field(
        None, description="Tool response data"
    )
    response_format: Optional[str] = Field(None, description="Response format type")

    # Timing fields
    start_time: Optional[datetime] = Field(None, description="Tool call start time")
    end_time: Optional[datetime] = Field(None, description="Tool call end time")
    duration_ms: Optional[int] = Field(
        None, ge=0, description="Duration in milliseconds"
    )

    # Performance metrics
    cpu_ms: Optional[int] = Field(None, ge=0, description="CPU time in milliseconds")
    memory_mb: Optional[int] = Field(None, ge=0, description="Memory usage in MB")
    network_bytes: Optional[int] = Field(
        None, ge=0, description="Network bytes transferred"
    )

    # Cost tracking
    estimated_cost_cents: Optional[int] = Field(
        None, ge=0, description="Estimated cost in cents"
    )
    billing_model: Optional[str] = Field(None, description="Billing model used")
    rate_limit_consumed: Optional[int] = Field(
        None, ge=0, description="Rate limit units consumed"
    )

    # Error handling
    status: str = Field("completed", description="Tool call status")
    error_code: Optional[str] = Field(None, description="Error code if failed")
    error_message: Optional[str] = Field(None, description="Error message if failed")
    retry_count: Optional[int] = Field(
        None, ge=0, description="Number of retries attempted"
    )

    # Data classification
    data_classification: Optional[str] = Field(
        None, description="Data sensitivity classification"
    )
    contains_pii: Optional[bool] = Field(None, description="Whether data contains PII")

    # Context and tracing
    correlation_id: Optional[str] = Field(
        None, description="Correlation ID for related calls"
    )
    parent_tool_call_id: Optional[str] = Field(None, description="Parent tool call ID")
    trace_id: Optional[str] = Field(None, description="Distributed trace ID")

    # Additional metadata
    user_agent: Optional[str] = Field(None, description="User agent string")
    source_location: Optional[str] = Field(None, description="Source code location")
    additional_metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata"
    )

    # Project filtering support
    app_id: Optional[str] = Field(
        None, max_length=255, description="Application identifier"
    )
    project_id: Optional[str] = Field(
        None, max_length=255, description="Project identifier for tool call filtering"
    )

    def calculate_duration(self) -> Optional[int]:
        """Calculate duration in milliseconds if start and end times are provided."""
        if self.start_time and self.end_time:
            delta = self.end_time - self.start_time
            return int(delta.total_seconds() * 1000)
        return self.duration_ms

    @field_validator("end_time")
    @classmethod
    def validate_end_time(cls, v, info):
        """Validate that end_time is after start_time."""
        if v is not None and info.data.get("start_time") is not None:
            if v <= info.data["start_time"]:
                raise ValueError("end_time must be after start_time")
        return v

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class DecisionData(BaseModel):
    """Decision data model for AI reasoning tracking."""

    name: Optional[str] = Field(None, description="Decision name or identifier")
    decision_type: Optional[str] = Field(None, description="Type of decision")
    reasoning_steps: List[str] = Field(
        default_factory=list, description="Reasoning steps taken"
    )
    confidence_score: Optional[float] = Field(
        None, ge=0.0, le=1.0, description="Confidence score"
    )
    selected_option: Optional[Dict[str, Any]] = Field(
        None, description="Selected option details"
    )
    alternatives_considered: List[Dict[str, Any]] = Field(
        default_factory=list, description="Alternatives considered"
    )
    decision_context: Dict[str, Any] = Field(
        default_factory=dict, description="Decision context"
    )
    
    # Support for simple dict-based creation
    data: Optional[Dict[str, Any]] = Field(
        default_factory=dict, description="Raw decision data for simple usage"
    )

    # Project filtering support
    app_id: Optional[str] = Field(
        None, max_length=255, description="Application identifier"
    )
    project_id: Optional[str] = Field(
        None, max_length=255, description="Project identifier for decision filtering"
    )

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class SessionData(BaseModel):
    """Session data model."""

    session_id: Optional[str] = Field(None, description="Session identifier")
    external_session_id: Optional[str] = Field(None, description="External session ID")
    agent_type: str = Field(..., description="Type of AI agent")
    agent_version: Optional[str] = Field(None, description="Agent version")
    user_id: Optional[str] = Field(None, description="User identifier")
    user_email: Optional[str] = Field(None, description="User email")
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Session metadata"
    )
    app_id: Optional[str] = Field(
        None, max_length=255, description="Application identifier"
    )
    project_id: Optional[str] = Field(
        None, max_length=255, description="Project identifier for session filtering"
    )

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


# Response models
class ActivityResponse(BaseModel):
    """Response model for activity operations."""

    id: str = Field(..., description="Activity ID")
    session_id: str = Field(..., description="Session ID")
    queued: bool = Field(
        False, description="Whether activity was queued for batch processing"
    )
    timestamp: Optional[datetime] = Field(None, description="Response timestamp")
    app_id: Optional[str] = Field(None, description="Application identifier")
    project_id: Optional[str] = Field(None, description="Project identifier")

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class ToolCallResponse(BaseModel):
    """Response model for tool call operations."""

    id: str = Field(..., description="Tool call ID")
    session_id: str = Field(..., description="Session ID")
    tool_name: str = Field(..., description="Tool name")
    status: str = Field("completed", description="Tool call status")
    timestamp: Optional[datetime] = Field(None, description="Response timestamp")
    app_id: Optional[str] = Field(None, description="Application identifier")
    project_id: Optional[str] = Field(None, description="Project identifier")

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class DecisionResponse(BaseModel):
    """Response model for decision operations."""

    id: str = Field(..., description="Decision ID")
    session_id: str = Field(..., description="Session ID")
    decision_name: str = Field(..., description="Decision name")
    timestamp: Optional[datetime] = Field(None, description="Response timestamp")
    app_id: Optional[str] = Field(None, description="Application identifier")
    project_id: Optional[str] = Field(None, description="Project identifier")

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class BatchResponse(BaseModel):
    """Response model for batch operations."""

    batch_id: str = Field(..., description="Batch ID")
    item_count: int = Field(..., description="Number of items in batch")
    status: str = Field("queued", description="Batch status")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


# Search request models for project filtering
class ActivitySearchRequest(BaseModel):
    """Request model for searching activities with project filtering."""

    project_ids: Optional[List[str]] = Field(None, description="Filter by project IDs")
    activity_types: Optional[List[str]] = Field(None, description="Filter by activity types")
    activity_subtypes: Optional[List[str]] = Field(None, description="Filter by activity subtypes")
    user_id: Optional[str] = Field(None, description="Filter by user ID")
    
    start_time: Optional[datetime] = Field(None, description="Start time for filtering")
    end_time: Optional[datetime] = Field(None, description="End time for filtering")
    
    page: int = Field(1, ge=1, description="Page number")
    page_size: int = Field(10, ge=1, le=1000, description="Number of items per page")

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class ToolCallSearchRequest(BaseModel):
    """Request model for searching tool calls with project filtering."""

    project_ids: Optional[List[str]] = Field(None, description="Filter by project IDs")
    tool_names: Optional[List[str]] = Field(None, description="Filter by tool names")
    tool_categories: Optional[List[str]] = Field(None, description="Filter by tool categories")
    statuses: Optional[List[str]] = Field(None, description="Filter by status")
    user_id: Optional[str] = Field(None, description="Filter by user ID")
    
    start_time: Optional[datetime] = Field(None, description="Start time for filtering")
    end_time: Optional[datetime] = Field(None, description="End time for filtering")
    
    page: int = Field(1, ge=1, description="Page number")
    page_size: int = Field(10, ge=1, le=1000, description="Number of items per page")

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class ActivitySearchResponse(BaseModel):
    """Response model for activity search results."""

    activities: List[Dict[str, Any]] = Field(..., description="List of activities")
    total_count: int = Field(..., description="Total number of matching activities")
    page: int = Field(..., description="Current page number")
    page_size: int = Field(..., description="Items per page")
    has_next: bool = Field(..., description="Whether there are more pages")

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class ToolCallSearchResponse(BaseModel):
    """Response model for tool call search results."""

    tool_calls: List[Dict[str, Any]] = Field(..., description="List of tool calls")
    total_count: int = Field(..., description="Total number of matching tool calls")
    page: int = Field(..., description="Current page number")
    page_size: int = Field(..., description="Items per page")
    has_next: bool = Field(..., description="Whether there are more pages")

    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


# =============================================================================
# Epic 4: File Tracking Models
# =============================================================================

class FileOperationType(str, Enum):
    """Enumeration of supported file operation types."""
    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    MOVE = "move"
    COPY = "copy"


class FileOperationData(BaseModel):
    """Data model for file operation tracking."""
    
    # Core fields
    file_path: str = Field(..., description="Path to the file")
    file_size: Optional[int] = Field(None, ge=0, description="Size of file in bytes")
    user_id: Optional[str] = Field(None, description="User performing the operation")
    project_id: Optional[str] = Field(None, description="Project identifier")
    
    # Read-specific fields
    partial_read: Optional[bool] = Field(None, description="Whether this was a partial read")
    byte_range: Optional[Tuple[int, int]] = Field(None, description="Byte range for partial reads")
    
    # Write-specific fields
    content_size: Optional[int] = Field(None, ge=0, description="Size of written content")
    operation_type: Optional[str] = Field(None, description="Specific operation type")
    content_hash_before: Optional[str] = Field(None, description="Content hash before write")
    content_hash_after: Optional[str] = Field(None, description="Content hash after write")
    
    # Move/Copy-specific fields
    source_path: Optional[str] = Field(None, description="Source path for move/copy operations")
    destination_path: Optional[str] = Field(None, description="Destination path for move/copy operations")
    
    # General metadata
    content_hash: Optional[str] = Field(None, description="File content hash")
    
    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class FileOperationResponse(BaseModel):
    """Response model for file operation tracking."""
    
    id: str = Field(..., description="Operation ID")
    session_id: str = Field(..., description="Session ID")
    operation: FileOperationType = Field(..., description="Operation type")
    file_path: str = Field(..., description="File path")
    timestamp: datetime = Field(..., description="Operation timestamp")
    status: str = Field(..., description="Operation status")
    risk_score: Optional[float] = Field(None, description="Risk score (0.0-1.0)")
    risk_level: Optional[str] = Field(None, description="Risk level")
    project_id: Optional[str] = Field(None, description="Project identifier")
    
    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class SecurityAnalysisData(BaseModel):
    """Data model for security analysis requests."""
    
    file_path: str = Field(..., description="Path to the file")
    operation: FileOperationType = Field(..., description="Operation type")
    content: Optional[str] = Field(None, description="File content for analysis")
    file_size: Optional[int] = Field(None, ge=0, description="File size in bytes")
    content_hash: Optional[str] = Field(None, description="File content hash")
    
    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class SecurityAnalysisResponse(BaseModel):
    """Response model for security analysis."""
    
    file_path: str = Field(..., description="File path")
    operation: FileOperationType = Field(..., description="Operation type")
    risk_score: float = Field(..., ge=0.0, le=1.0, description="Risk score")
    risk_level: str = Field(..., description="Risk level")
    is_sensitive: bool = Field(..., description="Whether file is sensitive")
    is_executable: bool = Field(..., description="Whether file is executable")
    is_system: bool = Field(..., description="Whether file is system-related")
    has_malicious_content: bool = Field(..., description="Whether content appears malicious")
    threats: List[str] = Field(..., description="Identified threats")
    recommendations: List[str] = Field(..., description="Security recommendations")
    timestamp: datetime = Field(..., description="Analysis timestamp")
    
    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class AnomalyDetectionData(BaseModel):
    """Data model for anomaly detection requests."""
    
    time_window_minutes: Optional[int] = Field(30, ge=1, le=1440, description="Time window for detection")
    
    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class AnomalyDetectionResponse(BaseModel):
    """Response model for anomaly detection."""
    
    session_id: str = Field(..., description="Session ID")
    anomalies_detected: bool = Field(..., description="Whether anomalies were detected")
    anomaly_types: List[str] = Field(..., description="Types of anomalies detected")
    risk_score: float = Field(..., ge=0.0, le=1.0, description="Overall risk score")
    recommendations: List[str] = Field(..., description="Recommendations")
    timestamp: datetime = Field(..., description="Detection timestamp")
    details: Dict[str, Any] = Field(default_factory=dict, description="Detailed analysis")
    
    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class FileRiskData(BaseModel):
    """Data model for file risk assessment."""
    
    file_path: str = Field(..., description="File path")
    operation: FileOperationType = Field(..., description="Operation type")
    is_sensitive: Optional[bool] = Field(None, description="Whether file is sensitive")
    is_executable: Optional[bool] = Field(None, description="Whether file is executable")
    is_system: Optional[bool] = Field(None, description="Whether file is system-related")
    file_size: Optional[int] = Field(None, ge=0, description="File size in bytes")
    has_malicious_content: Optional[bool] = Field(None, description="Whether content appears malicious")
    
    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class FileRiskResponse(BaseModel):
    """Response model for file risk assessment."""
    
    file_path: str = Field(..., description="File path")
    operation: FileOperationType = Field(..., description="Operation type")
    risk_score: float = Field(..., ge=0.0, le=1.0, description="Risk score")
    risk_level: str = Field(..., description="Risk level")
    factors: Dict[str, Any] = Field(..., description="Risk factors")
    timestamp: datetime = Field(..., description="Assessment timestamp")
    
    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class FileTrackingBatchRequest(BaseModel):
    """Request model for batch file operations."""
    
    operations: List[Dict[str, Any]] = Field(
        ..., 
        max_items=100,
        description="List of file operations to process in batch"
    )
    
    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})


class FileTrackingBatchResponse(BaseModel):
    """Response model for batch file operations."""
    
    batch_id: str = Field(..., description="Batch ID")
    total_requested: int = Field(..., description="Total operations requested")
    successful_count: int = Field(..., description="Number of successful operations")
    failed_count: int = Field(..., description="Number of failed operations")
    successful_operations: List[Dict[str, Any]] = Field(..., description="Successful operations")
    failed_operations: List[Dict[str, Any]] = Field(..., description="Failed operations")
    timestamp: datetime = Field(..., description="Batch processing timestamp")
    
    model_config = ConfigDict(json_encoders={datetime: lambda dt: dt.isoformat()})
