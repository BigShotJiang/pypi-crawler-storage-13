# (generated with --quick)

import pytest
import queue
import socket
import struct
import subprocess
import sys
import threading
import time
from typing import Any

ACN_PID: bytes
BIND_ADDR: str
MCAST_GROUP: str
SACN_PORT: int
UCAST_ADDR: str
fixture_udp_capture: Any
fixture_udp_socket: Any
test_sends_udp_packet: Any

def is_sacn_packet(data: bytes) -> bool: ...
def make_multicast_socket() -> socket.socket: ...
def make_unicast_socket() -> socket.socket: ...
