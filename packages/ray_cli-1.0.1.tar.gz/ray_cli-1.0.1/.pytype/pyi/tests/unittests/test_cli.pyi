# (generated with --quick)

import argparse
import pytest
import ray_cli.cli
import ray_cli.modes.mode
import ray_cli.utils.cli
from hypothesis import strategies as st
from typing import Any, List, Optional, Tuple, Type, Union

Number = Union[float, int]

Limits: Type[ray_cli.cli.Limits]
Mode: Type[ray_cli.modes.mode.Mode]
OPTION_CASES: List[Tuple[str, str, Tuple[int, int], Type[int]]]
cli: ray_cli.utils.cli.Cli
given: Any
test_channels_non_numeric_exits: Any
test_flag_sets_true: Any
test_mode_invalid: Any
test_mode_valid: Any
test_option_invalid: Any
test_option_order_invariance: Any
test_option_valid: Any
test_sacn_universes_invalid: Any
test_sacn_universes_valid: Any

def in_range_int(bounds: Tuple[Optional[float], Optional[float]]) -> Any: ...
def list_of_in_range_ints(bounds: Tuple[Optional[float], Optional[float]], *, min_size: int = ..., max_size: int = ...) -> Any: ...
def non_numeric_text() -> Any: ...
def out_of_range_int(bounds: Tuple[Optional[float], Optional[float]]) -> Any: ...
def parse(argv, protocol: str = ...) -> argparse.Namespace: ...
def test_channels_edges() -> None: ...
def test_help_prints_and_exits(capsys) -> None: ...
def test_packets_duration_mutex() -> None: ...
def test_verbose_and_quiet_are_exclusive() -> None: ...
def test_version_prints_and_exits(capsys) -> None: ...
