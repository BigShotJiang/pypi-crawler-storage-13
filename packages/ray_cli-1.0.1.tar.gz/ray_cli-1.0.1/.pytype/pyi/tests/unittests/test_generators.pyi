# (generated with --quick)

import pytest
import ray_cli.modes.generators
from typing import Any, Type

ChaseModeDmxDataGenerator: Type[ray_cli.modes.generators.ChaseModeDmxDataGenerator]
RampDownModeDmxDataGenerator: Type[ray_cli.modes.generators.RampDownModeDmxDataGenerator]
RampModeDmxDataGenerator: Type[ray_cli.modes.generators.RampModeDmxDataGenerator]
RampUpModeDmxDataGenerator: Type[ray_cli.modes.generators.RampUpModeDmxDataGenerator]
SineModeDmxDataGenerator: Type[ray_cli.modes.generators.SineModeDmxDataGenerator]
SquareModeDmxDataGenerator: Type[ray_cli.modes.generators.SquareModeDmxDataGenerator]
StaticModeDmxDataGenerator: Type[ray_cli.modes.generators.StaticModeDmxDataGenerator]
test_channels_sweep: Any
test_chase_mode_output_shape: Any
test_intensity_lower_sweep: Any
test_intensity_upper_sweep: Any
test_ramp_down_mode_output_shape: Any
test_ramp_mode_output_shape: Any
test_ramp_up_mode_output_shape: Any
test_sine_mode_output_shape: Any
test_square_mode_output_shape: Any
test_static_mode_output_shape: Any
