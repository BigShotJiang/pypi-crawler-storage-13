# (generated with --quick)

import importlib

__version__: str
