# (generated with --quick)

import ray_cli.core.sender
from typing import Hashable, Sequence, Type

BaseSender: Type[ray_cli.core.sender.BaseSender]
Sender: Type[ray_cli.core.sender.Sender]

class SenderPool(ray_cli.core.sender.BaseSender):
    senders: Sequence[ray_cli.core.sender.Sender[Hashable]]
    def __init__(self, senders: Sequence[ray_cli.core.sender.Sender]) -> None: ...
    def close(self) -> None: ...
    def open(self) -> None: ...
    def send(self, dmx_data: Sequence[int]) -> None: ...
