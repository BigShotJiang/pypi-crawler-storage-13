# (generated with --quick)

import ray_cli.core.sender
import ray_cli.core.sender_pool
import ray_cli.core.socket
import ray_cli.core.types
from typing import Callable, Hashable, Sequence, Tuple, Type, TypeVar

FrameEncoder = Callable[[int, Sequence[int]], bytes]

BaseSender: Type[ray_cli.core.sender.BaseSender]
BaseUDPSocket: Type[ray_cli.core.socket.BaseUDPSocket]
ProtocolFactory: Type[ray_cli.core.types.ProtocolFactory]
Sender: Type[ray_cli.core.sender.Sender]
SenderPool: Type[ray_cli.core.sender_pool.SenderPool]
__all__: Tuple[str, str, str, str, str, str, str]

U = TypeVar('U', bound=Hashable)
