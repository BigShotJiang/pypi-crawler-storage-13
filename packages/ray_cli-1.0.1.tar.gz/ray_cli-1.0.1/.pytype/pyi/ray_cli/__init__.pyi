# (generated with --quick)

from typing import Tuple

__all__: Tuple[str]
__version__: str
