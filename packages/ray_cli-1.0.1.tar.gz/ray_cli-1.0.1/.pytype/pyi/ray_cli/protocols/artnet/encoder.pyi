# (generated with --quick)

import abc
import itertools
import ray_cli.protocols.artnet.packets
from typing import Callable, Sequence, Type, TypeVar

ABC: Type[abc.ABC]
ArtDmx: Type[ray_cli.protocols.artnet.packets.ArtDmx]
ArtNetUniverse: Type[ray_cli.protocols.artnet.packets.ArtNetUniverse]
chain: Type[itertools.chain]
islice: Type[itertools.islice]
repeat: Type[itertools.repeat]

_FuncT = TypeVar('_FuncT', bound=Callable)

class ArtNetEncoder(Encoder):
    def build_frame(self, universe: ray_cli.protocols.artnet.packets.ArtNetUniverse, physical: int, sequence: int, dmx_data: Sequence[int]) -> bytes: ...

class Encoder(abc.ABC):
    @abstractmethod
    def build_frame(self, universe: ray_cli.protocols.artnet.packets.ArtNetUniverse, physical: int, sequence: int, dmx_data: Sequence[int]) -> bytes: ...

def abstractmethod(funcobj: _FuncT) -> _FuncT: ...
