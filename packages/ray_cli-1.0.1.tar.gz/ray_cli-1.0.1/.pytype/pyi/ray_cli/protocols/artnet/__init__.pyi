# (generated with --quick)

import ray_cli.protocols.artnet.factory
import ray_cli.protocols.artnet.packets
from typing import Tuple, Type

ArtNetFactory: Type[ray_cli.protocols.artnet.factory.ArtNetFactory]
ArtNetUniverse: Type[ray_cli.protocols.artnet.packets.ArtNetUniverse]
__all__: Tuple[str, str]
