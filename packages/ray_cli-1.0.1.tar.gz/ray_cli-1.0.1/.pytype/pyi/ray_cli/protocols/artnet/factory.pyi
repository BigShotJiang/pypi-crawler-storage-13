# (generated with --quick)

import ipaddress
import ray_cli.core.socket
import ray_cli.core.types
import ray_cli.protocols.artnet.encoder
import ray_cli.protocols.artnet.packets
import ray_cli.protocols.artnet.sockets
from typing import Callable, Optional, Sequence, Type

FrameEncoder = Callable[[int, Sequence[int]], bytes]

ArtNetBroadcastSocket: Type[ray_cli.protocols.artnet.sockets.ArtNetBroadcastSocket]
ArtNetEncoder: Type[ray_cli.protocols.artnet.encoder.ArtNetEncoder]
ArtNetUnicastSocket: Type[ray_cli.protocols.artnet.sockets.ArtNetUnicastSocket]
ArtNetUniverse: Type[ray_cli.protocols.artnet.packets.ArtNetUniverse]
BaseUDPSocket: Type[ray_cli.core.socket.BaseUDPSocket]
ProtocolFactory: Type[ray_cli.core.types.ProtocolFactory]

class ArtNetFactory(ray_cli.core.types.ProtocolFactory[ray_cli.protocols.artnet.packets.ArtNetUniverse]):
    _encoder: ray_cli.protocols.artnet.encoder.ArtNetEncoder
    _physical: int
    def __init__(self, *, physical: int = ...) -> None: ...
    def create_frame_encoder(self, universe: ray_cli.protocols.artnet.packets.ArtNetUniverse) -> Callable[[int, Sequence[int]], bytes]: ...
    def create_socket(self, universe: ray_cli.protocols.artnet.packets.ArtNetUniverse, src: ipaddress.IPv4Address, dst: Optional[ipaddress.IPv4Address] = ...) -> ray_cli.core.socket.BaseUDPSocket: ...
