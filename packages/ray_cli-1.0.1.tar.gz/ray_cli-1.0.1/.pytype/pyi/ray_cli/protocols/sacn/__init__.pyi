# (generated with --quick)

import ray_cli.protocols.sacn.factory
from typing import Tuple, Type

SACNFactory: Type[ray_cli.protocols.sacn.factory.SACNFactory]
__all__: Tuple[str]
