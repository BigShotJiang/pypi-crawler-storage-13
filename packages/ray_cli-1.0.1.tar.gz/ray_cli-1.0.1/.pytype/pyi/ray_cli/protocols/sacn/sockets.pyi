# (generated with --quick)

import ipaddress
import ray_cli.core.socket
import socket
from typing import Callable, Optional, Type, TypeVar

BaseUDPSocket: Type[ray_cli.core.socket.BaseUDPSocket]
DEFAULT_PORT: int
IPv4Address: Type[ipaddress.IPv4Address]

_FuncT = TypeVar('_FuncT', bound=Callable)

class BaseSACNSocket(ray_cli.core.socket.BaseUDPSocket):
    _bind_address: ipaddress.IPv4Address
    _dest_address: ipaddress.IPv4Address
    _port: int
    _sock: Optional[socket.socket]
    def __init__(self, dest_address: ipaddress.IPv4Address, bind_address: ipaddress.IPv4Address = ...) -> None: ...
    @abstractmethod
    def _configure_socket(self, sock: socket.socket) -> None: ...
    def close(self) -> None: ...
    def open(self) -> None: ...
    def send(self, payload: bytes) -> None: ...

class SACNMulticastSocket(BaseSACNSocket):
    _bind_address: ipaddress.IPv4Address
    _dest_address: ipaddress.IPv4Address
    _port: int
    _sock: Optional[socket.socket]
    _ttl: int
    def __init__(self, group_address: ipaddress.IPv4Address, bind_address: ipaddress.IPv4Address = ..., ttl: int = ...) -> None: ...
    def _configure_socket(self, sock: socket.socket) -> None: ...

class SACNUnicastSocket(BaseSACNSocket):
    _bind_address: ipaddress.IPv4Address
    _dest_address: ipaddress.IPv4Address
    _port: int
    _sock: Optional[socket.socket]
    def _configure_socket(self, sock: socket.socket) -> None: ...

def abstractmethod(funcobj: _FuncT) -> _FuncT: ...
def pick_outgoing_ip_via_route(group_address: ipaddress.IPv4Address) -> ipaddress.IPv4Address: ...
def sacn_multicast_address(universe: int) -> ipaddress.IPv4Address: ...
