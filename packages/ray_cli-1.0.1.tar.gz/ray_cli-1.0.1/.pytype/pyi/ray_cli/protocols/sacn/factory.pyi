# (generated with --quick)

import ipaddress
import ray_cli.core.socket
import ray_cli.core.types
import ray_cli.protocols.sacn.encoder
import ray_cli.protocols.sacn.sockets
import uuid
from typing import Callable, Optional, Sequence, Type

FrameEncoder = Callable[[int, Sequence[int]], bytes]

BaseUDPSocket: Type[ray_cli.core.socket.BaseUDPSocket]
ProtocolFactory: Type[ray_cli.core.types.ProtocolFactory]
SACNEncoder: Type[ray_cli.protocols.sacn.encoder.SACNEncoder]
SACNMulticastSocket: Type[ray_cli.protocols.sacn.sockets.SACNMulticastSocket]
SACNUnicastSocket: Type[ray_cli.protocols.sacn.sockets.SACNUnicastSocket]

class SACNFactory(ray_cli.core.types.ProtocolFactory[int]):
    _encoder: ray_cli.protocols.sacn.encoder.SACNEncoder
    _priority: int
    def __init__(self, *, source_name: str, priority: int = ..., cid: Optional[bytes] = ...) -> None: ...
    def create_frame_encoder(self, universe: int) -> Callable[[int, Sequence[int]], bytes]: ...
    def create_socket(self, universe: int, src: ipaddress.IPv4Address, dst: Optional[ipaddress.IPv4Address] = ...) -> ray_cli.core.socket.BaseUDPSocket: ...

def sacn_multicast_address(universe: int) -> ipaddress.IPv4Address: ...
