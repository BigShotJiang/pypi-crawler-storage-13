# (generated with --quick)

import enum

class Mode(enum.Enum):
    CHASE: str
    RAMP: str
    RAMP_DOWN: str
    RAMP_UP: str
    SINE: str
    SQUARE: str
    STATIC: str
    def __str__(self) -> str: ...
