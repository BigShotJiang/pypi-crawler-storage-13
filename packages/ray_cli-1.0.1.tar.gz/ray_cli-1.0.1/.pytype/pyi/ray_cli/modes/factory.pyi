# (generated with --quick)

import ray_cli.modes.generators
import ray_cli.modes.mode
from typing import Dict, Type, Union

DmxDataGenerator = Union[ray_cli.modes.generators.ChaseModeDmxDataGenerator, ray_cli.modes.generators.RampDownModeDmxDataGenerator, ray_cli.modes.generators.RampModeDmxDataGenerator, ray_cli.modes.generators.RampUpModeDmxDataGenerator, ray_cli.modes.generators.SineModeDmxDataGenerator, ray_cli.modes.generators.SquareModeDmxDataGenerator, ray_cli.modes.generators.StaticModeDmxDataGenerator]

ChaseModeDmxDataGenerator: Type[ray_cli.modes.generators.ChaseModeDmxDataGenerator]
MODE_TO_GENERATOR: Dict[ray_cli.modes.mode.Mode, Type[Union[ray_cli.modes.generators.ChaseModeDmxDataGenerator, ray_cli.modes.generators.RampDownModeDmxDataGenerator, ray_cli.modes.generators.RampModeDmxDataGenerator, ray_cli.modes.generators.RampUpModeDmxDataGenerator, ray_cli.modes.generators.SineModeDmxDataGenerator, ray_cli.modes.generators.SquareModeDmxDataGenerator, ray_cli.modes.generators.StaticModeDmxDataGenerator]]]
Mode: Type[ray_cli.modes.mode.Mode]
RampDownModeDmxDataGenerator: Type[ray_cli.modes.generators.RampDownModeDmxDataGenerator]
RampModeDmxDataGenerator: Type[ray_cli.modes.generators.RampModeDmxDataGenerator]
RampUpModeDmxDataGenerator: Type[ray_cli.modes.generators.RampUpModeDmxDataGenerator]
SineModeDmxDataGenerator: Type[ray_cli.modes.generators.SineModeDmxDataGenerator]
SquareModeDmxDataGenerator: Type[ray_cli.modes.generators.SquareModeDmxDataGenerator]
StaticModeDmxDataGenerator: Type[ray_cli.modes.generators.StaticModeDmxDataGenerator]

def generator_factory(mode: ray_cli.modes.mode.Mode, channels: int, fps: int, frequency: int, intensity_upper: int, intensity_lower: int) -> Union[ray_cli.modes.generators.ChaseModeDmxDataGenerator, ray_cli.modes.generators.RampDownModeDmxDataGenerator, ray_cli.modes.generators.RampModeDmxDataGenerator, ray_cli.modes.generators.RampUpModeDmxDataGenerator, ray_cli.modes.generators.SineModeDmxDataGenerator, ray_cli.modes.generators.SquareModeDmxDataGenerator, ray_cli.modes.generators.StaticModeDmxDataGenerator]: ...
