# (generated with --quick)

import ray_cli.modes.generators
from typing import Type, Union

DmxDataGenerator = Union[ray_cli.modes.generators.ChaseModeDmxDataGenerator, ray_cli.modes.generators.RampDownModeDmxDataGenerator, ray_cli.modes.generators.RampModeDmxDataGenerator, ray_cli.modes.generators.RampUpModeDmxDataGenerator, ray_cli.modes.generators.SineModeDmxDataGenerator, ray_cli.modes.generators.SquareModeDmxDataGenerator, ray_cli.modes.generators.StaticModeDmxDataGenerator]

ChaseModeDmxDataGenerator: Type[ray_cli.modes.generators.ChaseModeDmxDataGenerator]
RampDownModeDmxDataGenerator: Type[ray_cli.modes.generators.RampDownModeDmxDataGenerator]
RampModeDmxDataGenerator: Type[ray_cli.modes.generators.RampModeDmxDataGenerator]
RampUpModeDmxDataGenerator: Type[ray_cli.modes.generators.RampUpModeDmxDataGenerator]
SineModeDmxDataGenerator: Type[ray_cli.modes.generators.SineModeDmxDataGenerator]
SquareModeDmxDataGenerator: Type[ray_cli.modes.generators.SquareModeDmxDataGenerator]
StaticModeDmxDataGenerator: Type[ray_cli.modes.generators.StaticModeDmxDataGenerator]
