# (generated with --quick)

import ray_cli.core.sender
import ray_cli.modes.generators
import ray_cli.utils.feedback
import ray_cli.utils.progress_bar
import ray_cli.utils.table_logger
import time
from typing import Annotated, Generator, Optional, Type, Union

DmxDataGenerator = Union[ray_cli.modes.generators.ChaseModeDmxDataGenerator, ray_cli.modes.generators.RampDownModeDmxDataGenerator, ray_cli.modes.generators.RampModeDmxDataGenerator, ray_cli.modes.generators.RampUpModeDmxDataGenerator, ray_cli.modes.generators.SineModeDmxDataGenerator, ray_cli.modes.generators.SquareModeDmxDataGenerator, ray_cli.modes.generators.StaticModeDmxDataGenerator]

BaseSender: Type[ray_cli.core.sender.BaseSender]
Feedback: Type[ray_cli.utils.feedback.Feedback]
ProgressBar: Type[ray_cli.utils.progress_bar.ProgressBar]
TableLogger: Type[ray_cli.utils.table_logger.TableLogger]

class App:
    channels: int
    fps: int
    generator: Union[ray_cli.modes.generators.ChaseModeDmxDataGenerator, ray_cli.modes.generators.RampDownModeDmxDataGenerator, ray_cli.modes.generators.RampModeDmxDataGenerator, ray_cli.modes.generators.RampUpModeDmxDataGenerator, ray_cli.modes.generators.SineModeDmxDataGenerator, ray_cli.modes.generators.SquareModeDmxDataGenerator, ray_cli.modes.generators.StaticModeDmxDataGenerator]
    max_packets: Optional[int]
    progress_bar: ray_cli.utils.progress_bar.ProgressBar
    sender: ray_cli.core.sender.BaseSender
    table_logger: ray_cli.utils.table_logger.TableLogger
    throttle: Throttle
    def __init__(self, sender: ray_cli.core.sender.BaseSender, generator: Union[ray_cli.modes.generators.ChaseModeDmxDataGenerator, ray_cli.modes.generators.RampDownModeDmxDataGenerator, ray_cli.modes.generators.RampModeDmxDataGenerator, ray_cli.modes.generators.RampUpModeDmxDataGenerator, ray_cli.modes.generators.SineModeDmxDataGenerator, ray_cli.modes.generators.SquareModeDmxDataGenerator, ray_cli.modes.generators.StaticModeDmxDataGenerator], channels: int, fps: int, max_packets: Optional[int] = ...) -> None: ...
    def purge_output(self) -> None: ...
    def run(self, feedback: Optional[ray_cli.utils.feedback.Feedback] = ..., dry = ...) -> None: ...

class Throttle:
    _rate: int
    last_tick: float
    time_step: Annotated[float, 'property']
    def __init__(self, rate: int) -> None: ...
    def loop(self, max_ticks: Optional[int] = ...) -> Generator[int, None, None]: ...
    def wait_next(self) -> None: ...
