# (generated with --quick)

import ray_cli.utils.cli
import ray_cli.utils.feedback
import ray_cli.utils.formatters
import ray_cli.utils.progress_bar
import ray_cli.utils.table_logger
from typing import Tuple, Type

Cli: Type[ray_cli.utils.cli.Cli]
Command: Type[ray_cli.utils.cli.Command]
CommandGroup: Type[ray_cli.utils.cli.CommandGroup]
CustomHelpFormatter: Type[ray_cli.utils.formatters.CustomHelpFormatter]
Feedback: Type[ray_cli.utils.feedback.Feedback]
Group: Type[ray_cli.utils.cli.Group]
MutualExclusiveGroup: Type[ray_cli.utils.cli.MutualExclusiveGroup]
Option: Type[ray_cli.utils.cli.Option]
ProgressBar: Type[ray_cli.utils.progress_bar.ProgressBar]
TableLogger: Type[ray_cli.utils.table_logger.TableLogger]
__all__: Tuple[str, str, str, str, str, str, str, str, str, str, str]

def generate_settings_report(args, max_channels, max_priority, max_intensity, max_workers, width = ..., padding_left = ..., padding_right = ...) -> str: ...
