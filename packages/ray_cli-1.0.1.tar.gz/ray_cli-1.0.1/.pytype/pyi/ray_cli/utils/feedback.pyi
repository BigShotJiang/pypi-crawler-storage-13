# (generated with --quick)

import enum

class Feedback(enum.Enum):
    PROGRESS_BAR: int
    TABULAR: int
