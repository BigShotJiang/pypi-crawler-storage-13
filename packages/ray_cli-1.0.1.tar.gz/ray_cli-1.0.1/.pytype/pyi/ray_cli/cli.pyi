# (generated with --quick)

import argparse
import dataclasses
import importlib
import ipaddress
import ray_cli.app
import ray_cli.core.sender
import ray_cli.core.sender_pool
import ray_cli.modes.generators
import ray_cli.modes.mode
import ray_cli.protocols.artnet.factory
import ray_cli.protocols.artnet.packets
import ray_cli.protocols.sacn.factory
import ray_cli.utils.cli
import ray_cli.utils.feedback
import sys
from typing import Callable, List, Optional, Tuple, Type, TypeVar, Union, overload

App: Type[ray_cli.app.App]
ArtNetFactory: Type[ray_cli.protocols.artnet.factory.ArtNetFactory]
ArtNetUniverse: Type[ray_cli.protocols.artnet.packets.ArtNetUniverse]
Cli: Type[ray_cli.utils.cli.Cli]
Command: Type[ray_cli.utils.cli.Command]
CommandGroup: Type[ray_cli.utils.cli.CommandGroup]
Feedback: Type[ray_cli.utils.feedback.Feedback]
Group: Type[ray_cli.utils.cli.Group]
Mode: Type[ray_cli.modes.mode.Mode]
MutualExclusiveGroup: Type[ray_cli.utils.cli.MutualExclusiveGroup]
Option: Type[ray_cli.utils.cli.Option]
PACKAGE_NAME: str
PACKAGE_SUMMARY: str
SACNFactory: Type[ray_cli.protocols.sacn.factory.SACNFactory]
Sender: Type[ray_cli.core.sender.Sender]
SenderPool: Type[ray_cli.core.sender_pool.SenderPool]
__version__: str
artnet_group: ray_cli.utils.cli.Group
cli: ray_cli.utils.cli.Cli
display_group: ray_cli.utils.cli.MutualExclusiveGroup
dmx_group: ray_cli.utils.cli.Group
network_group: ray_cli.utils.cli.Group
operational_group: ray_cli.utils.cli.Group
query_group: ray_cli.utils.cli.Group
runtime_group: ray_cli.utils.cli.Group
sacn_group: ray_cli.utils.cli.Group
shared_opts: List[Union[ray_cli.utils.cli.Group, ray_cli.utils.cli.MutualExclusiveGroup]]

_T = TypeVar('_T')

@dataclasses.dataclass
class Limits:
    channels: Tuple[int, int]
    intensity: Tuple[int, int]
    intensity_min: Tuple[int, int]
    frequency: Tuple[float, None]
    workers: Tuple[int, int]
    packets: Tuple[int, None]
    duration: Tuple[float, None]
    fps: Tuple[float, None]
    sacn_universes: Tuple[int, int]
    artnet_universes: Tuple[ray_cli.protocols.artnet.packets.ArtNetUniverse, ray_cli.protocols.artnet.packets.ArtNetUniverse]
    sacn_priority: Tuple[int, int]
    def __init__(self) -> None: ...

def app_factory(args: argparse.Namespace) -> ray_cli.app.App: ...
def artnet_sender_poll_factory(args: argparse.Namespace) -> ray_cli.core.sender_pool.SenderPool: ...
@overload
def dataclass(__cls: None) -> Callable[[Type[_T]], Type[_T]]: ...
@overload
def dataclass(__cls: Type[_T]) -> Type[_T]: ...
@overload
def dataclass(*, init: bool = ..., repr: bool = ..., eq: bool = ..., order: bool = ..., unsafe_hash: bool = ..., frozen: bool = ..., match_args: bool = ..., kw_only: bool = ..., slots: bool = ..., weakref_slot: bool = ...) -> Callable[[Type[_T]], Type[_T]]: ...
def generate_settings_report(args, max_channels, max_priority, max_intensity, max_workers, width = ..., padding_left = ..., padding_right = ...) -> str: ...
def generator_factory(mode: ray_cli.modes.mode.Mode, channels: int, fps: int, frequency: int, intensity_upper: int, intensity_lower: int) -> Union[ray_cli.modes.generators.ChaseModeDmxDataGenerator, ray_cli.modes.generators.RampDownModeDmxDataGenerator, ray_cli.modes.generators.RampModeDmxDataGenerator, ray_cli.modes.generators.RampUpModeDmxDataGenerator, ray_cli.modes.generators.SineModeDmxDataGenerator, ray_cli.modes.generators.SquareModeDmxDataGenerator, ray_cli.modes.generators.StaticModeDmxDataGenerator]: ...
def main(args = ...) -> None: ...
def print_report(args) -> None: ...
def sacn_sender_pool_factory(args: argparse.Namespace) -> ray_cli.core.sender_pool.SenderPool: ...
def select_feedback(args: argparse.Namespace) -> Optional[ray_cli.utils.feedback.Feedback]: ...
