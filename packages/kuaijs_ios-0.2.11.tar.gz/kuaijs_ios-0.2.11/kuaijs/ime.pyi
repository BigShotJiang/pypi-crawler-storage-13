# 输入法是否可用
def is_ok() -> bool:
    """输入法是否可用（键盘是否已弹出）"""
    ...

# 获取/清空输入框文本
def get_text() -> str:
    """获取当前输入框文本"""
    ...

def clear_text() -> bool:
    """清空输入框文本"""
    ...

# 输入/粘贴文本（content为空时使用剪切板）
def input(content: str) -> str:
    """输入文本（content 为空时使用剪贴板）"""
    ...

def paste(content: str = ...) -> str:
    """粘贴文本（content 为空时使用剪贴板）"""
    ...

# 删除一个字符/回车/隐藏键盘
def press_del() -> str:
    """删除一个字符（返回剩余文本；空表示无数据）"""
    ...

def press_enter() -> bool:
    """回车键"""
    ...

def dismiss() -> bool:
    """隐藏键盘"""
    ...

# 剪切板读写
def get_clipboard() -> str:
    """获取剪贴板"""
    ...

def set_clipboard(content: str) -> bool:
    """设置剪贴板（键盘显示时）"""
    ...

# 切换输入法
def switch_keyboard() -> bool:
    """切换输入法"""
    ...
