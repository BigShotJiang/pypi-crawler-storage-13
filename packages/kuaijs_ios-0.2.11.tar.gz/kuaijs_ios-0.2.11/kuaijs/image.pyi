from typing import List, Optional, Protocol

class Size(Protocol):
    width: int
    height: int

# 单点找色（返回点坐标列表）
class Point(Protocol):
    x: int
    y: int

# 找图（返回矩形列表）
class Rect(Protocol):
    x: int
    y: int
    width: int
    height: int
    confidence: float
    centerX: int
    centerY: int
    ex: int
    ey: int

# 截取全屏并返回图片ID
def capture_full_screen() -> Optional[str]:
    """截取全屏并返回图片ID（失败返回 None）"""
    ...

# 截取屏幕区域并返回图片ID
# 参数：x/y 左上角；ex/ey 右下角
def capture_rect(x: int, y: int, ex: int, ey: int) -> Optional[str]:
    """截取屏幕区域并返回图片ID（x/y 左上角；ex/ey 右下角）"""
    ...

# 读取图片文件为图片ID
def read_image(path: str) -> Optional[str]:
    """读取图片文件为图片ID"""
    ...

# 裁剪图片并返回新的图片ID
def clip(id: str, x: int, y: int, ex: int, ey: int) -> Optional[str]:
    """裁剪图片并返回新的图片ID"""
    ...

# 获取图片尺寸信息 {width,height}
def get_size(id: str) -> Optional[Size]:
    """获取图片尺寸信息 {width,height}"""
    ...

# 图片转 base64（format: jpg|png；q: 质量1-100，仅jpg）
def to_base64_format(id: str, format: str, q: int) -> Optional[str]:
    """图片转 base64（format: jpg|png；q: 质量1-100，仅jpg）"""
    ...

# base64 转图片ID
def base64_to_image(base64data: str) -> Optional[str]:
    """base64 转图片ID"""
    ...

# 图片是否被释放
def is_release(id: str) -> bool:
    """图片是否已被释放"""
    ...

# 释放图片/全部图片
def release(id: str) -> None:
    """释放图片"""
    ...

def release_all() -> None:
    """释放全部图片"""
    ...

# 保存图片到路径
def save_to(id: str, path: str) -> bool:
    """保存图片到路径"""
    ...

# 旋转图片（degree: 90 | -90 | 180）返回新ID
def rotate_image(id: str, degree: int) -> Optional[str]:
    """旋转图片（degree: 90 | -90 | 180），返回新ID"""
    ...

# 多点比色（points: "x|y|主色-偏色,..."；threshold: 0.0-1.0；区域 x/y/ex/ey）
def cmp_color(
    id: str, points: str, threshold: float, x: int, y: int, ex: int, ey: int
) -> bool:
    """多点比色

    参数:
      points: "x|y|主色-偏色,..."
      threshold: 0.0-1.0
      x/y/ex/ey: 区域坐标
    返回:
      bool: 是否相同
    """
    ...

def find_color(
    id: str,
    color: str,
    threshold: float,
    x: int,
    y: int,
    ex: int,
    ey: int,
    limit: int,
    orz: int,
) -> List[Point]:
    """单点找色（返回点坐标列表）"""
    ...

# 多点找色（返回点坐标列表）
def find_multi_color(
    id: str,
    firstColor: str,
    threshold: float,
    points: str,
    x: int,
    y: int,
    ex: int,
    ey: int,
    limit: int,
    orz: int,
) -> List[Point]:
    """多点找色（返回点坐标列表）"""
    ...

def find_image(
    id: str,
    templateImageId: str,
    x: int,
    y: int,
    ex: int,
    ey: int,
    threshold: float,
    limit: int,
    method: int,
    rgb: bool = ...,
) -> List[Rect]:
    """找图（返回矩形列表）

    参数默认值:
      rgb: False
    """
    ...

# 获取像素颜色（返回整数RGB）
def pixel(id: str, x: int, y: int) -> int:
    """获取像素颜色（整数 RGB）"""
    ...

# 颜色值转16进制字符串（#RRGGBB）
def argb(color: int) -> str:
    """颜色值转 16 进制字符串（#RRGGBB）"""
    ...

# 二值化/灰度化图片（返回新ID）
def binaryzation(id: str, threshold: float) -> Optional[str]:
    """二值化图片（返回新ID）"""
    ...

def gray(id: str) -> Optional[str]:
    """灰度化图片（返回新ID）"""
    ...

# 扫描条码/二维码（返回识别文本）
def scan_code(id: str) -> Optional[str]:
    """扫描条码/二维码（返回识别文本）"""
    ...

# 在图片上绘制矩形（直接修改原图）
def draw_rect(
    id: str, x: int, y: int, ex: int, ey: int, color: str, thickness: int
) -> bool:
    """在图片上绘制矩形（直接修改原图）"""
    ...
