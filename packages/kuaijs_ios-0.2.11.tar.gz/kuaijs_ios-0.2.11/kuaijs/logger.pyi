def set_logger_level(level: str) -> bool:
    """设置日志级别

    参数:
      level: 日志级别（error|warn|info|debug|off）
    返回:
      bool: 是否设置成功
    """
    ...

def set_log_to_file(enabled: bool) -> bool:
    """设置是否输出到日志文件

    参数:
      enabled: True 启用文件输出；False 关闭文件输出
    返回:
      bool: 是否设置成功
    """
    ...

def set_max_log_file_count(count: int) -> bool:
    """设置最大日志文件数量（默认 10 个）"""
    ...

def set_max_log_file_size(size: int) -> bool:
    """设置最大日志文件大小（单位 MB，默认 10MB）"""
    ...

def reset_log_file() -> bool:
    """重置日志文件（创建新文件并开始写入）"""
    ...

def debug(*args: object) -> bool:
    """输出调试日志（将参数按空格拼接为字符串）"""
    ...

def info(*args: object) -> bool:
    """输出信息日志（将参数按空格拼接为字符串）"""
    ...

def warn(*args: object) -> bool:
    """输出警告日志（将参数按空格拼接为字符串）"""
    ...

def error(*args: object) -> bool:
    """输出错误日志（将参数按空格拼接为字符串）"""
    ...
