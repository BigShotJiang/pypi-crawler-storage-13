from typing import Literal, Protocol

class ScreenSize(Protocol):
    width: float
    height: float

class BatteryInfo(Protocol):
    level: int
    isCharging: bool

# 获取电池信息
# 返回：{"level": 百分比int, "isCharging": 是否充电bool}
def get_battery_info() -> BatteryInfo:
    """获取电池信息（level/isCharging）"""
    ...

# 获取设备ID（Vendor ID）
def get_device_id() -> str:
    """获取设备 ID（Vendor ID）"""
    ...

# 获取服务器设备ID（自定义）
def get_server_device_id() -> str:
    """获取服务器设备 ID（自定义）"""
    ...

# 获取设备名称
def get_device_name() -> str:
    """获取设备名称"""
    ...

# 获取设备型号（硬件型号）
def get_device_model() -> str:
    """获取设备型号（硬件型号）"""
    ...

# 获取屏幕逻辑尺寸
# 返回：{"width": float, "height": float}
def get_screen_size() -> ScreenSize:
    """获取屏幕逻辑尺寸（width/height）"""
    ...

# 获取屏幕实际尺寸
# 返回：{"width": float, "height": float}
def get_screen_real_size() -> ScreenSize:
    """获取屏幕实际尺寸（width/height）"""
    ...

# 获取屏幕缩放比例
def get_screen_scale() -> float:
    """获取屏幕缩放比例"""
    ...

# 获取屏幕方向
def get_orientation() -> Literal["PORTRAIT", "LANDSCAPE"]:
    """获取屏幕方向"""
    ...

# 获取系统版本
def get_os_version() -> str:
    """获取系统版本（例如 16.7.11）"""
    ...

# 获取局域网IP
def get_lan_ip() -> str:
    """获取局域网 IP（例如 192.168.1.100）"""
    ...

# 震动
# 参数：duration 毫秒；intensity 0.0-1.0
def vibrate(duration: int, intensity: float) -> bool:
    """震动

    参数:
      duration: 持续时间（毫秒）
      intensity: 强度 0.0-1.0
    返回:
      bool: 是否成功
    """
    ...
