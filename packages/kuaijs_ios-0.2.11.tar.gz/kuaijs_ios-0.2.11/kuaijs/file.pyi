from typing import List, Optional, Literal

# 获取内部目录
# 参数：type = documents | library | temp | libraryCaches
def get_internal_dir(
    type: Literal["documents", "library", "temp", "libraryCaches"],
) -> str:
    """获取内部目录路径

    参数:
      type: 目录类型
    返回:
      str: 路径
    """
    ...

# 获取数据目录
def get_data_dir() -> str:
    """获取应用数据目录路径"""
    ...

# 获取数据文件路径
# 参数：file = 文件名
def get_data_file(file: str) -> str:
    """获取应用数据文件路径"""
    ...

# 创建文件
def create(path: str) -> bool:
    """创建文件"""
    ...

# 递归创建目录
def mkdirs(path: str) -> bool:
    """递归创建目录"""
    ...

# 删除文件或目录（谨慎）
def delete_all_file(path: str) -> bool:
    """删除文件或目录（谨慎）"""
    ...

# 读取文件内容（UTF-8）
def read_file(path: str) -> Optional[str]:
    """读取文件内容（UTF-8）"""
    ...

# 读取资源文件内容（UTF-8）
def read_res_file(fileName: str) -> Optional[str]:
    """读取资源文件内容（UTF-8）"""
    ...

# 删除指定行或包含关键字的行
# 参数：line >=0 删除行号；line <0 且 contains 指定关键字
def delete_line(path: str, line: int, contains: Optional[str]) -> bool:
    """删除指定行或包含关键字的行

    参数:
      line: 行号（>=0 删除对应行；<0 时忽略行号）
      contains: 包含关键字（当行号<0时生效）
    """
    ...

# 列出目录文件
# 参数：recursion 是否递归
def list_dir(path: str, recursion: bool) -> List[str]:
    """列出目录文件"""
    ...

# 写入文件（覆盖，UTF-8）
def write_file(path: str, data: str) -> bool:
    """写入文件（覆盖，UTF-8）"""
    ...

# 追加一行（UTF-8）
def append_line(path: str, data: str) -> bool:
    """追加一行（UTF-8）"""
    ...

# 读取指定行（0 基）
def read_line(path: str, lineNo: int) -> Optional[str]:
    """读取指定行（0 基）"""
    ...

# 读取所有行
def read_all_lines(path: str) -> Optional[List[str]]:
    """读取所有行"""
    ...

# 文件是否存在
def exists(path: str) -> bool:
    """文件或目录是否存在"""
    ...

# 复制文件
def copy(src: str, dest: str) -> bool:
    """复制文件"""
    ...

# 计算文件 MD5（十六进制字符串）
def file_md5(path: str) -> Optional[str]:
    """计算文件 MD5（十六进制字符串）"""
    ...
