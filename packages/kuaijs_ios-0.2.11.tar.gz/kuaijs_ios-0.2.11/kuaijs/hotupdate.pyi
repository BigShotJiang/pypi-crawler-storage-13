from typing import Optional, Protocol

# 检查更新（options: url/timeout/version），返回 {needUpdate,data?,error?}
class HotUpdateResponse(Protocol):
    download_url: str
    version: int
    download_timeout: int
    dialog: bool
    msg: str
    force: bool
    md5: Optional[str]

class HotUpdateResult(Protocol):
    need_update: bool
    error: Optional[str]
    data: Optional[HotUpdateResponse]

class HotUpdateOptions(Protocol):
    url: Optional[str]
    version: Optional[int]
    timeout: Optional[int]

# 下载并安装（返回 {updated,error?}）
class InstallResult(Protocol):
    updated: bool
    error: Optional[str]

def check_update(options: Optional[HotUpdateOptions] = ...) -> HotUpdateResult:
    """检查更新

    参数:
      options: 检查参数（url/version/timeout）
    返回:
      HotUpdateResult: needUpdate/data/error
    """
    ...

def download_and_install() -> InstallResult:
    """下载并安装更新（执行成功会自动重启脚本）"""
    ...

# 获取当前应用版本号（整数）
def get_current_version() -> int:
    """获取当前应用版本号（数字）"""
    ...
