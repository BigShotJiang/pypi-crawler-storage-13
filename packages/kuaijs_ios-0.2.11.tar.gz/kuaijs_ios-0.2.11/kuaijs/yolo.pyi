from typing import List, Optional, Protocol

# 目标检测（返回边框/置信度/类别等）
class YoloResult(Protocol):
    x: int
    y: int
    ex: int
    ey: int
    centerX: int
    centerY: int
    width: int
    height: int
    confidence: float
    classId: int

# 加载 YOLOv11 模型，返回模型ID
def load_v11(paramPath: str, binPath: str, nc: int) -> Optional[str]:
    """加载 YOLOv11 模型，返回模型ID（失败返回 None）"""
    ...

def detect(
    modelId: str,
    input: str,
    targetSize: int = ...,
    threshold: float = ...,
    nmsThreshold: float = ...,
) -> List[YoloResult]:
    """目标检测（返回边框/置信度/类别等）

    参数默认值:
      targetSize: 640
      threshold: 0.4
      nmsThreshold: 0.5
    """
    ...

# 释放指定模型/所有模型
def free(modelId: str) -> None:
    """释放指定模型资源"""
    ...

def free_all() -> None:
    """释放所有模型资源"""
    ...
