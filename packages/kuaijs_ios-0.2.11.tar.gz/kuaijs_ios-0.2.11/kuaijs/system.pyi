from typing import Any, Dict, List, Optional, Protocol

# 获取内存使用信息（单位：MB）
# 返回键：
# - used: 已使用内存
# - available: 可用内存
# - total: 系统总内存
# - usagePercentage: 使用率（0-100）
class MemoryInfo(Protocol):
    used: int
    available: int
    total: int
    usagePercentage: int

# 获取当前运行的应用信息（可能为 None）
class ProcessArguments(Protocol):
    env: Dict[str, Any]
    args: List[str]

class ActivateAppInfo(Protocol):
    name: str
    pid: int
    bundleId: str
    processArguments: ProcessArguments

# 设置 WDA 参数
# 参数：
# - params: 支持的键：
#   - mjpegServerScreenshotQuality: int 截图质量（MJPEG）
#   - mjpegServerFramerate: int MJPEG 帧率
#   - screenshotQuality: int 普通截图质量
class WDASettings(Protocol):
    mjpegServerScreenshotQuality: Optional[int]
    mjpegServerFramerate: Optional[int]
    screenshotQuality: Optional[int]

# 启动应用
# 参数：
# - bundle_id: 应用的 Bundle ID，例如 "com.example.app"
# - args: 启动参数列表，例如 ["--flag", "--debug"]
# - env: 环境变量映射，例如 {"ENV": "1"}
def start_app(bundle_id: str, args: List[str] = ..., env: Dict[str, Any] = ...) -> bool:
    """启动应用

    参数:
      bundle_id: 应用 Bundle ID
      args: 启动参数列表
      env: 环境变量映射
    返回:
      bool: 是否启动成功
    """
    ...

# 停止应用
# 参数：
# - bundle_id: 应用的 Bundle ID
def stop_app(bundle_id: str) -> bool:
    """停止应用"""
    ...

# 激活应用到前台
# 参数：
# - bundle_id: 应用的 Bundle ID
def activate_app(bundle_id: str) -> bool:
    """激活应用到前台（未启动则启动）"""
    ...

def activate_app_info() -> Optional[ActivateAppInfo]:
    """获取当前运行的应用信息（可能为 None）"""
    ...

# 使用系统浏览器打开 URL
# 参数：
# - url: 例如 "https://example.com"
def open_url(url: str) -> bool:
    """使用系统浏览器打开 URL"""
    ...

# 发送系统通知（后台生效）
# 参数：
# - msg: 通知内容
# - title: 通知标题，空或 "undefined" 时使用应用名称
# - id: 通知 ID，相同 ID 会覆盖
def notify(msg: str, title: str = ..., id: str = ...) -> bool:
    """发送系统通知（后台生效）"""
    ...

# 设置剪贴板文本（仅前台有效）
# 参数：
# - text: 要写入剪贴板的文本
def set_clipboard(text: str) -> bool:
    """设置剪贴板文本（仅前台有效）"""
    ...

# 获取剪贴板文本（仅前台有效）
def get_clipboard() -> str:
    """获取剪贴板文本（仅前台有效）"""
    ...

# 是否锁屏
def is_locked() -> bool:
    """是否锁屏"""
    ...

# 锁屏
def lock() -> bool:
    """锁屏"""
    ...

# 解锁
def unlock() -> bool:
    """解锁"""
    ...

def get_memory_info() -> MemoryInfo:
    """获取内存使用信息（MB）：used/available/total/usagePercentage"""
    ...

# 获取已使用内存（MB）
def get_used_memory() -> int:
    """获取已使用内存（MB）"""
    ...

# 获取可用内存（MB）
def get_available_memory() -> int:
    """获取可用内存（MB）"""
    ...

# 获取系统总内存（MB）
def get_total_memory() -> int:
    """获取系统总内存（MB）"""
    ...

# 启动 WDA 服务
def start_wda() -> bool:
    """启动 WDA 服务"""
    ...

# 获取 WDA 状态（是否可用）
def get_wda_status() -> bool:
    """获取 WDA 状态（是否可用）"""
    ...

def set_wda_settings(params: Optional[WDASettings] = ...) -> bool:
    """设置 WDA 参数（质量/帧率/截图质量）"""
    ...
