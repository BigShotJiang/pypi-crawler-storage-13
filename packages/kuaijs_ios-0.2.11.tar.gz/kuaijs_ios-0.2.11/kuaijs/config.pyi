from typing import Any, Dict, Optional

# 读取整数配置
def read_int(key: str) -> int:
    """读取整数配置

    参数:
      key: 配置键
    返回:
      int: 配置值
    """
    ...

# 读取浮点配置
def read_double(key: str) -> float:
    """读取浮点配置"""
    ...

# 读取字符串配置
def read_string(key: str) -> Optional[str]:
    """读取字符串配置（不存在返回 None）"""
    ...

# 读取布尔配置
def read_bool(key: str) -> bool:
    """读取布尔配置"""
    ...

# 获取所有配置
def get_json() -> Dict[str, Any]:
    """获取所有配置 JSON"""
    ...

# 更新配置
# value 支持：str/int/float/bool
def update_config(key: str, value: Any) -> bool:
    """更新配置值（支持 str/int/float/bool）"""
    ...

# 删除配置
def delete_config(key: str) -> bool:
    """删除配置"""
    ...
