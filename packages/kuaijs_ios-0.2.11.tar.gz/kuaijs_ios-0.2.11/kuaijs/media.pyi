"""媒体管理：相册与音频"""

# 保存图片/视频到相册
def save_image_to_album(imageId: str) -> bool:
    """保存图像到相册"""
    ...

def save_video_to_album_path(path: str) -> bool:
    """保存视频路径到相册"""
    ...

# 清空相册图片/视频
def delete_all_photos() -> bool:
    """清空相册中的图片"""
    ...

def delete_all_videos() -> bool:
    """清空相册中的视频"""
    ...

# 播放/停止MP3；同步播放（等待结束）
def play_mp3(path: str, loop: bool) -> bool:
    """播放 MP3（异步）"""
    ...

def stop_mp3() -> bool:
    """停止播放 MP3"""
    ...

def play_mp3_wait_end(path: str, loop: bool) -> bool:
    """同步播放 MP3（等待结束）"""
    ...
