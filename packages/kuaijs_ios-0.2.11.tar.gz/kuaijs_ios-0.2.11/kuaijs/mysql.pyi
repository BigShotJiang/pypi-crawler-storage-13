from typing import Any, List, Dict, Optional, Protocol

# 连接配置：host/port/username/password/database/charset
class MySQLConfig(Protocol):
    host: str
    port: Optional[int]
    username: str
    password: str
    database: str
    charset: Optional[str]

# 查询/执行，返回对象：rows/affectedRows/insertId/success/error
class MySQLResult(Protocol):
    rows: List[Dict[str, Any]]
    affectedRows: int
    success: bool
    insertId: Optional[int]
    error: Optional[str]

def connect(config: MySQLConfig) -> bool:
    """连接到数据库"""
    ...

def disconnect() -> None:
    """断开数据库连接"""
    ...

def is_connected() -> bool:
    """检查连接状态"""
    ...

def query(sql: str, params: List[Any] = ...) -> MySQLResult:
    """执行查询（SELECT）"""
    ...

def execute(sql: str, params: List[Any] = ...) -> MySQLResult:
    """执行更新（INSERT/UPDATE/DELETE）"""
    ...

# 事务控制
def begin_transaction() -> bool:
    """开始事务"""
    ...

def commit() -> bool:
    """提交事务"""
    ...

def rollback() -> bool:
    """回滚事务"""
    ...
