.. Document meta section

:orphan:

.. meta::
  :antsibull-docs: <ANTSIBULL_DOCS_VERSION>

.. Document body

.. Anchors

.. _ansible_collections.ns.col2.extra_filter:

.. Title

ns.col2.extra filter
++++++++++++++++++++


The documentation for the filter plugin, ns.col2.extra,  was malformed.

The errors were:

* .. code-block:: text

        2 validation errors for PositionalDocSchema
        doc -> options -> _input -> extra
          Extra inputs are not permitted (type=extra_forbidden)
        doc -> extra
          Extra inputs are not permitted (type=extra_forbidden)


File a bug with the `ns.col2 collection <https://galaxy.ansible.com/ui/repo/published/ns/col2/>`_ in order to have it corrected.
