# DSF EngineXAI SDK

**Configurable Evaluation Engine with AI Integration**

Enterprise analysis module that combines structured data with AI-generated signals while maintaining transparent audit trails.

---

## 🚀 Why EngineXAI?

Balance flexibility and transparency in evaluation workflows:
- Configure logic without hardcoding
- Integrate AI-generated signals under client control
- Maintain mathematical transparency

---

## 🧠 AI Signal Integration

Incorporate AI-generated assessments as configurable inputs.

```python
config = {
    "ai_assessment": {
        "input_type": "external",
        "params": {"tuning": 2.5}
    },
    "metric_primary": {
        "input_type": "standard",
        "reference_value": 700,
        "params": {"tuning": 2.0}
    }
}

applicant = {
    "ai_assessment": 0.73, 
    "metric_primary": 680
}
```

---

## ⚙️ Installation

```bash
pip install dsf-enginexai-sdk
```

---

## 🧩 Quick Start

```python
from dsf_enginexai_sdk import CreditScoreClient

config = {
    "metric_a": {
        "input_type": "standard", 
        "reference_value": 3000, 
        "params": {"tuning": 1.8}
    },
    "metric_b": {
        "input_type": "standard", 
        "reference_value": 0.3, 
        "params": {"tuning": 2.5}
    }
}

subject = {"metric_a": 2800, "metric_b": 0.42}

with EvaluationClient(api_key="your_key", tier="community") as client:
    result = client.evaluate(subject, config)
    print(f"Outcome: {result['outcome']}")
    print(f"Score: {result['score']:.4f}")
```

---

## 🤖 AI Integration Pattern

```python

ai_score = your_ai_system.assess(data)


subject = {
    "ai_signal": ai_score,
    "structured_metric": 720
}

result = client.evaluate(subject, config)
```

**Note:** AI signals are client-provided. EngineXAI does not generate or store AI content.

---

## 🔍 Analysis Breakdown

Available for Professional and Enterprise tiers.

```python
result = client.evaluate(subject, config, audit=True)
breakdown = result["audit_trail"]
```

**Example:**

```python
[
  {
    "feature": "ai_signal",
    "contribution_pct": 35.2,
    "metadata": "optional"
  },
  {
    "feature": "metric_primary", 
    "contribution_pct": 28.5
  }
]
```

---

## 📊 Tier Comparison

|     Feature     | Community | Professional | Enterprise |
|-----------------|-----------|--------------|------------|
| AI Signal Input |    ✅     |     ✅      |     ✅     |
| Batch Size      |     1     |     100      |    500     |
| Audit Trails    |    ❌     |     ✅      |     ✅     |
| Adaptive Mode   |    ❌     |     ✅      |     ✅     |

---

## 🧬 Advanced Features

### Adaptive Evaluation (Pro/Enterprise)

```python
result = client.evaluate_batch(
    subjects, 
    config,
    adaptive={'enabled': True}
)
```

Automatically adjusts for missing fields.

---

## 🎯 Use Cases

### AI-Enhanced Analysis

```python
config = {
    "ai_context": {"input_type": "external", "params": {...}},
    "traditional_metric": {"input_type": "standard", "reference_value": 1.0, "params": {...}}
}
```

### Hybrid Systems

```python
config = {
    "standard_metric": {"input_type": "standard", "reference_value": 700, "params": {...}},
    "ml_output": {"input_type": "external", "params": {...}},
    "ai_context": {"input_type": "external", "params": {...}}
}
```

---

## ⚠️ Important Notes

**Client Responsibility:**  
Clients must validate compliance with applicable regulations. This SDK is an evaluation support tool.

**Data Processing:**  
All logic executes server-side. SDK exposes only configuration interface.

**Input Requirements:**  
Inputs must be normalized where applicable. See technical documentation (requires NDA).

**AI Signals:**  
AI-generated signals are client-provided and client-controlled. EngineXAI does not generate, interpret, or store AI content.

---

## 📞 Support

**Licensing:** contacto@dsfuptech.cloud  
**Technical Documentation:** Available under NDA

---

## 🔒 Architecture

- Server-side computation engine
- Configurable evaluation rules
- Transparent audit interface
- Secure API authentication

Technical specifications available under NDA.

---

## 📋 Credits

**Technology Architect:** Jaime Alexander Jimenez

---

© 2025 DSF UpTech. All rights reserved.
