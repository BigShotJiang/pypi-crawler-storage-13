import os
import sys
import time
from pathlib import Path

import packaging.version

import src
from src import utils
from src.utils.dump import dump  # noqa: F401

VERSION_CHECK_FNAME = Path.home() / ".l2m" / "caches" / "versioncheck"


def install_from_main_branch(io):
    """
    Install the latest version of l2m from the main branch of the GitHub repository.
    """

    return utils.check_pip_install_extra(
        io,
        None,
        "Install the development version of l2m from the main branch?",
        ["git+https://github.com/astrio-ai/l2m.git"],
        self_update=True,
    )


def install_upgrade(io, latest_version=None):
    """
    Install the latest version of l2m from PyPI.
    """

    if latest_version:
        new_ver_text = f"Newer l2m version v{latest_version} is available."
    else:
        new_ver_text = "Install latest version of l2m?"

    docker_image = os.environ.get("L2M_DOCKER_IMAGE")
    if docker_image:
        text = f"""
{new_ver_text} To upgrade, run:

    docker pull {docker_image}
"""
        io.tool_warning(text)
        return True

    success = utils.check_pip_install_extra(
        io,
        None,
        new_ver_text,
        ["l2m"],
        self_update=True,
    )

    if success:
        io.tool_output("Re-run l2m to use new version.")
        sys.exit()

    return


def check_version(io, just_check=False, verbose=False):
    if not just_check and VERSION_CHECK_FNAME.exists():
        day = 60 * 60 * 24
        since = time.time() - os.path.getmtime(VERSION_CHECK_FNAME)
        if 0 < since < day:
            if verbose:
                hours = since / 60 / 60
                io.tool_output(f"Too soon to check version: {hours:.1f} hours")
            return

    # To keep startup fast, avoid importing this unless needed
    import requests

    try:
        response = requests.get("https://pypi.org/pypi/l2m/json", timeout=5)
        # If package doesn't exist on PyPI yet (404), silently skip version check
        if response.status_code == 404:
            if verbose:
                io.tool_output("Package not found on PyPI, skipping version check")
            return False
        response.raise_for_status()  # Raise an exception for other bad status codes
        data = response.json()
        if "info" not in data or "version" not in data.get("info", {}):
            # Invalid response structure, skip version check
            if verbose:
                io.tool_output("Invalid PyPI response, skipping version check")
            return False
        latest_version = data["info"]["version"]
        current_version = src.__version__

        if just_check or verbose:
            io.tool_output(f"Current version: {current_version}")
            io.tool_output(f"Latest version: {latest_version}")

        is_update_available = packaging.version.parse(latest_version) > packaging.version.parse(
            current_version
        )
    except Exception as err:
        io.tool_error(f"Error checking pypi for new version: {err}")
        return False
    finally:
        VERSION_CHECK_FNAME.parent.mkdir(parents=True, exist_ok=True)
        VERSION_CHECK_FNAME.touch()

    ###
    # is_update_available = True

    if just_check or verbose:
        if is_update_available:
            io.tool_output("Update available")
        else:
            io.tool_output("No update available")

    if just_check:
        return is_update_available

    if not is_update_available:
        return False

    install_upgrade(io, latest_version)
    return True
