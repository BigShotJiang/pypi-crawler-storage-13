import unittest

# from unittest import TestCase

from science.dataset import Dataset
from science.metric import Metric, MetricCollector


class MetricCollectorTest(unittest.TestCase):

    def test_collect(self):
        
        collector = MetricCollector(name="network-metrics",
                                    metrics_schema=[Metric("waiting_time", float),
                                                    Metric("total_packages", int),
                                                    Metric("package_type", str)])
        
        collector.collect({"waiting_time": 1.1,
                           "total_packages": 2})
        
        collector.collect({"waiting_time": 1.2,
                           "package_type": "UDP"})
        
        print(f"dset = \n{collector.metrics}")

        result = collector.metrics.data
        expected = Dataset.from_dict({"waiting_time": [1.1, 1.2], "total_packages": [2, None], "package_type": [None, "UDP"]}).data

        self.assertListEqual(result["waiting_time"].to_list(), expected["waiting_time"].to_list())
        # self.assertListEqual(result["total_packages"].to_list(), expected["total_packages"].to_list())
        self.assertListEqual(result["package_type"].to_list(), expected["package_type"].to_list())        


if __name__ == "__main__":
    unittest.main(MetricCollectorTest(), verbosity=3)
