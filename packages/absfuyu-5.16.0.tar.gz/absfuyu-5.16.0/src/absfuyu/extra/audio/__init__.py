"""
Absfuyu: Audio
--------------
Audio related

Version: 5.16.0
Date updated: 20/11/2025 (dd/mm/yyyy)
"""
