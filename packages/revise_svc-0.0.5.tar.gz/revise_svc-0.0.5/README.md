# REVISE

REVISE (REconstruction via Vision-integrated Spatial Estimation) is a unified framework for reconstructing **Spatially-inferred Virtual Cells (SVCs)** by integrating spatial transcriptomics (ST) data, histological imaging, and matched single-cell RNA-seq references.

Visit our [documentation](https://revise-svc.readthedocs.io/en/latest/) for installation, tutorials, examples and more.

## Motivation

Current ST technologies are limited by six key **confounding factors (CFs)** that hinder the reconstruction of biologically coherent single-cell units:

![ST limations](png/ST_limitations.png)

<p align="center">Current ST limitations</p>



- **Spatially heterogeneous CFs**: image segmentation artifacts, bin-to-cell assignment errors
- **Spatially homogeneous CFs**: spot size, batch effects, gene panel limitations, gene dropout

REVISE addresses these limitations through a **topology-aware hierarchical optimal transport (OT)** framework, generating two complementary types of virtual cells:

- **sp-SVC**: leverages spatial priors to correct spatially heterogeneous CFs and preserve local tissue architecture
- **sc-SVC**: integrates scRNA-seq references to restore transcriptome-wide coverage and correct dropout

![REVISE Overview](png/REVISE_overview.png)

<p align="center">Overview of the REVISE framework</p>




## Highlights

- **Unified Framework**: Handles six CFs across three ST platforms (sST, iST, hST)
- **Dual SVC Modes**: sp-SVC for spatial refinement, sc-SVC for molecular completeness
- **Benchmark Module**: Reproducible evaluation pipelines for simulated or public datasets
- **Application Module**: Annotation, reconstruction, and downstream analyses for real ST data

## SVC Applications

### sp-SVC Applications

- Recovers spatially resolved gene and pathway signals from Visium HD data
- Identifies localized transcriptional programs (e.g., EMT at tumor leading edge)
- Enhances spatial autocorrelation and clustering coherence

### sc-SVC Applications

- Reconstructs whole-transcriptome profiles for Xenium data
- Defines fine-grained immune subtypes (T cells, TAMs, CAFs)
- Reveals spatially organized cell-cell communication and clinical associations

![SVC Applications](png/SVC_applications.png)

<p align="center">Biological insights enabled by SVC reconstruction</p>




## Quick Start

If you just need the published Python package:

```bash
pip install revise-svc
```

## Example

```python
import anndata as ad
from revise.application import SpSVC

st = ad.read_h5ad("data/spatial.h5ad")
sc = ad.read_h5ad("data/single_cell_reference.h5ad")
config = ...

svc = SpSVC(st, sc, config=config, logger=None)
svc.annotate()
svc.reconstruct()
```

## Repository Layout

- `revise/application`: SVC workflows for real datasets.
- `revise/benchmark`: SVC variants for benchmarking studies.
- `revise/methods`: Algorithm implementations and model components.
- `revise/tools`: Distance metrics, logging helpers, and general utilities.
- `conf`: Example configurations and experiment parameters.

## License

REVISE is released under the MIT License (see `LICENSE`).
