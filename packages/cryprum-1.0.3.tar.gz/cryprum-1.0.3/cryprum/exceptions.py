class CryprumError(Exception):
    pass
