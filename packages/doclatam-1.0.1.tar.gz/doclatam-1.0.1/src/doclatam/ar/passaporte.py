from ..core.base import BaseValidator
import re

class Passaporte(BaseValidator):
    """
    Validator for Argentine Passport.
    Format: 3 letters + 6 numbers (e.g., AAA123456) or similar alphanumeric.
    """

    @classmethod
    def validate(cls, doc: str) -> bool:
        doc = doc.upper().replace(' ', '')
        # Common format: 3 letters + 6 digits
        return bool(re.match(r'^[A-Z]{3}[0-9]{6}$', doc))

    @classmethod
    def format(cls, doc: str) -> str:
        doc = doc.upper().replace(' ', '')
        if not cls.validate(doc):
             raise ValueError("Invalid passport format")
        return doc
