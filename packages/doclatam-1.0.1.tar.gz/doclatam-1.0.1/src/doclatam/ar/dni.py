from ..core.base import BaseValidator
import re

class DNI(BaseValidator):
    """
    Validator for Argentine DNI (Documento Nacional de Identidad).
    Validates format only (7-8 digits), as there is no standard public check digit algorithm.
    """

    @classmethod
    def validate(cls, doc: str) -> bool:
        doc = cls.clean(doc)
        
        # DNI is typically 7 or 8 digits
        if not (7 <= len(doc) <= 8):
            return False
            
        return True

    @classmethod
    def format(cls, doc: str) -> str:
        doc = cls.clean(doc)
        if not (7 <= len(doc) <= 8):
            raise ValueError("DNI must have 7 or 8 digits")
        
        if len(doc) == 8:
            return f"{doc[:2]}.{doc[2:5]}.{doc[5:]}"
        else:
            return f"{doc[:1]}.{doc[1:4]}.{doc[4:]}"
