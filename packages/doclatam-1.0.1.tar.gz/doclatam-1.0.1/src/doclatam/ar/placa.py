import re

class PlacaMercosul:
    """
    Validator for Mercosur License Plates (Argentina standard).
    Format: LL123LL
    """

    @classmethod
    def validate(cls, plate: str) -> bool:
        """Validates if the plate is in Argentina Mercosur format."""
        plate = plate.upper().replace('-', '').replace(' ', '')
        
        # Check Mercosur format (LL123LL)
        # 2 letters, 3 numbers, 2 letters
        if re.match(r'^[A-Z]{2}[0-9]{3}[A-Z]{2}$', plate):
            return True
            
        return False
