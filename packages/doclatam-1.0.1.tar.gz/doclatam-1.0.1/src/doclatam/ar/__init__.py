from .dni import DNI
from .cuit import CUIT, CUIL
from .placa import PlacaMercosul
from .passaporte import Passaporte
