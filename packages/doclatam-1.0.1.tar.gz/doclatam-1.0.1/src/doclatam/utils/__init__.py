from .plate_identifier import identify_plate

__all__ = ['identify_plate']
