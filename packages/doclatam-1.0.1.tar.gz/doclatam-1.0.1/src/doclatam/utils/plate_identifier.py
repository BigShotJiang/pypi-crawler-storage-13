"""
Utility to identify license plate country based on format.
"""
import re

def identify_plate(plate: str) -> list:
    """
    Identifies which country(ies) a license plate could belong to.
    
    Args:
        plate: License plate string
        
    Returns:
        List of possible countries
    """
    plate = plate.upper().replace('-', '').replace(' ', '')
    
    countries = []
    
    # Brasil: LLL1L23 or LLL1234
    if re.match(r'^[A-Z]{3}[0-9][A-Z][0-9]{2}$', plate):
        countries.append('Brasil')
    elif re.match(r'^[A-Z]{3}[0-9]{4}$', plate):
        countries.extend(['Brasil', 'Uruguai'])
        
    # Argentina: LL123LL
    if re.match(r'^[A-Z]{2}[0-9]{3}[A-Z]{2}$', plate):
        countries.append('Argentina')
        
    # Paraguai: LLLL123
    if re.match(r'^[A-Z]{4}[0-9]{3}$', plate):
        countries.append('Paraguai')
        
    # Bolívia: 1234ABC
    if re.match(r'^[0-9]{4}[A-Z]{3}$', plate):
        countries.append('Bolívia')
        
    # Peru: ABC-123 or AB-1234
    if re.match(r'^[A-Z]{3}[0-9]{3}$', plate):
        countries.append('Peru')
    elif re.match(r'^[A-Z]{2}[0-9]{4}$', plate):
        countries.append('Peru')
        
    # Equador: ABC-1234
    if re.match(r'^[A-Z]{3}[0-9]{4}$', plate):
        if 'Equador' not in countries:
            countries.append('Equador')
            
    # Colômbia: ABC-123
    if re.match(r'^[A-Z]{3}[0-9]{3}$', plate):
        if 'Colômbia' not in countries:
            countries.append('Colômbia')
            
    # Venezuela: AB123CD
    if re.match(r'^[A-Z]{2}[0-9]{3}[A-Z]{2}$', plate):
        if 'Venezuela' not in countries:
            countries.append('Venezuela')
            
    # México: AAA123 or AAA1234
    if re.match(r'^[A-Z]{3}[0-9]{3,4}$', plate):
        if 'México' not in countries:
            countries.append('México')
    
    return countries if countries else ['Desconhecido']
