from typing import Any, Callable, Generator
from pydantic import GetCoreSchemaHandler
from pydantic_core import core_schema

class PydanticValidator:
    """
    Base class for Pydantic integration.
    """
    validator_cls = None

    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> core_schema.CoreSchema:
        return core_schema.with_info_after_validator_function(
            cls.validate,
            core_schema.str_schema(),
        )

    @classmethod
    def validate(cls, v: str, info: core_schema.ValidationInfo) -> str:
        if not cls.validator_cls.validate(v):
            raise ValueError(f"Invalid {cls.validator_cls.__name__}")
        return cls.validator_cls.format(v)

# Factory to create Pydantic types
def create_pydantic_type(validator_class):
    class PydanticType(PydanticValidator):
        validator_cls = validator_class
    PydanticType.__name__ = validator_class.__name__
    return PydanticType

# Import all validators
from ..br.cpf import CPF as CPFValidator
from ..br.cnpj import CNPJ as CNPJValidator
from ..ar.cuit import CUIT as CUITValidator
from ..cl.rut import RUT as RUTValidator
from ..py.ruc import RUC as RUCValidator
from ..mx.curp import CURP as CURPValidator
from ..mx.rfc import RFC as RFCValidator

# Create types
CPF = create_pydantic_type(CPFValidator)
CNPJ = create_pydantic_type(CNPJValidator)
CUIT = create_pydantic_type(CUITValidator)
RUT = create_pydantic_type(RUTValidator)
RUC = create_pydantic_type(RUCValidator)
CURP = create_pydantic_type(CURPValidator)
RFC = create_pydantic_type(RFCValidator)
