from ..core.base import BaseValidator

class CI(BaseValidator):
    """
    Validator for Venezuelan Cédula.
    Validates format (numeric, usually V/E prefix but just number for now).
    """

    @classmethod
    def validate(cls, doc: str) -> bool:
        doc = cls.clean(doc)
        # 6 to 9 digits?
        return 6 <= len(doc) <= 9

    @classmethod
    def format(cls, doc: str) -> str:
        doc = cls.clean(doc)
        if not (6 <= len(doc) <= 9):
             raise ValueError("Invalid CI length")
        return doc
