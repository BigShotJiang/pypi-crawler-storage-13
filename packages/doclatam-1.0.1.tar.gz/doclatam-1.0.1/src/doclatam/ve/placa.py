import re

class Placa:
    """
    Validator for Venezuelan License Plates.
    Format: AB123CD (2 letters, 3 numbers, 2 letters)
    """

    @classmethod
    def validate(cls, plate: str) -> bool:
        plate = plate.upper().replace('-', '').replace(' ', '')
        return bool(re.match(r'^[A-Z]{2}[0-9]{3}[A-Z]{2}$', plate))
