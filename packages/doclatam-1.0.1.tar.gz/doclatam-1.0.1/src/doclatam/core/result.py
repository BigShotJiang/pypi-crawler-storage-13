from dataclasses import dataclass
from typing import Optional

@dataclass
class ValidationResult:
    """
    Represents the detailed result of a validation check.
    """
    valid: bool
    error_code: Optional[str] = None
    message: Optional[str] = None

    def __bool__(self) -> bool:
        return self.valid
