from abc import ABC, abstractmethod
import re
from typing import List, Union
from .result import ValidationResult

class BaseValidator(ABC):
    """
    Abstract base class for all document validators.
    """

    @classmethod
    @abstractmethod
    def validate(cls, doc: str) -> bool:
        """
        Validates the document.
        """
        pass

    @classmethod
    def clean(cls, doc: str) -> str:
        """
        Removes non-numeric characters from the document string.
        """
        return re.sub(r'[^0-9]', '', str(doc))

    @classmethod
    @abstractmethod
    def format(cls, doc: str) -> str:
        """
        Formats the document with standard punctuation.
        """
        pass

    @classmethod
    def mask(cls, doc: str) -> str:
        """
        Masks the document, showing only the last 4 characters.
        """
        clean_doc = cls.clean(doc)
        if len(clean_doc) <= 4:
            return '*' * len(clean_doc)
        return '*' * (len(clean_doc) - 4) + clean_doc[-4:]

    @classmethod
    def compare(cls, doc1: str, doc2: str) -> bool:
        """
        Compares two documents ignoring formatting.
        """
        return cls.clean(doc1) == cls.clean(doc2)

    @classmethod
    def check(cls, doc: str) -> ValidationResult:
        """
        Detailed validation check.
        """
        is_valid = cls.validate(doc)
        if is_valid:
            return ValidationResult(valid=True)
        return ValidationResult(valid=False, error_code="INVALID", message="Document is invalid")

    @classmethod
    def validate_bulk(cls, docs: List[str]) -> List[bool]:
        """
        Validates a list of documents efficiently.
        """
        return [cls.validate(doc) for doc in docs]

    @classmethod
    def get_validation_pattern(cls) -> str:
        """
        Returns the regex pattern for validation.
        """
        return r"^\d+$"
