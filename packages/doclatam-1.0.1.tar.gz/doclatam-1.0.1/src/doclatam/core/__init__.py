"""
Core validation logic and exceptions.
"""
