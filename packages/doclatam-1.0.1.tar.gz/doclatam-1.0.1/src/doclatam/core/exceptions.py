"""
Custom exceptions for detailed error feedback.
"""

class ValidationError(Exception):
    """Base validation error."""
    pass

class InvalidLengthError(ValidationError):
    """Document has invalid length."""
    def __init__(self, expected, actual):
        self.expected = expected
        self.actual = actual
        super().__init__(f"Expected length {expected}, got {actual}")

class InvalidChecksumError(ValidationError):
    """Check digit validation failed."""
    def __init__(self, expected, actual):
        self.expected = expected
        self.actual = actual
        super().__init__(f"Expected check digit {expected}, got {actual}")

class InvalidFormatError(ValidationError):
    """Document format is invalid."""
    pass

class InvalidCharacterError(ValidationError):
    """Document contains invalid characters."""
    pass
