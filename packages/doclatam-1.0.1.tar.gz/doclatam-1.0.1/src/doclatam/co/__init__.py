from .nit import NIT
from .placa import Placa
from .passaporte import Passaporte
