import re

class Placa:
    """
    Validator for Colombian License Plates.
    Format: ABC-123 (Private), etc.
    """

    @classmethod
    def validate(cls, plate: str) -> bool:
        plate = plate.upper().replace('-', '').replace(' ', '')
        # Private: 3 letters + 3 numbers
        # Public: 3 letters + 3 numbers (white)
        # Diplomatic: 2 letters + 4 numbers
        # Remolques: 1 letter + 5 numbers
        
        if re.match(r'^[A-Z]{3}[0-9]{3}$', plate): return True
        if re.match(r'^[A-Z]{2}[0-9]{4}$', plate): return True
        if re.match(r'^[A-Z]{1}[0-9]{5}$', plate): return True
        
        return False
