import re

class Placa:
    """
    Validator for Mexican License Plates.
    Various formats (AAA-000, AAA-00-00, etc).
    """

    @classmethod
    def validate(cls, plate: str) -> bool:
        plate = plate.upper().replace('-', '').replace(' ', '')
        
        # Private Car: 3 letters + 3 numbers (AAA123) or 3 letters + 4 numbers (AAA1234)
        if re.match(r'^[A-Z]{3}[0-9]{3}$', plate): return True
        if re.match(r'^[A-Z]{3}[0-9]{4}$', plate): return True
        
        # Truck: 2 letters + 4 numbers (AA1234) or 2 letters + 5 numbers
        if re.match(r'^[A-Z]{2}[0-9]{4,5}$', plate): return True
        
        # Public/Bus: 1 letter + numbers... varies too much.
        # Let's stick to the most common private formats.
        
        return False
