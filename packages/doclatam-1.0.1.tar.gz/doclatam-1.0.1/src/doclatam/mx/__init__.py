from .curp import CURP
from .rfc import RFC
from .placa import Placa
