import re

class Placa:
    """
    Validator for Peruvian License Plates.
    Format: ABC-123 (3 letters, 3 numbers)
    """

    @classmethod
    def validate(cls, plate: str) -> bool:
        plate = plate.upper().replace('-', '').replace(' ', '')
        return bool(re.match(r'^[A-Z0-9]{2,3}[0-9]{3,4}$', plate)) # Generalized regex based on research (2-3 letters, 3-4 numbers)
        # Actually, standard is ABC-123. Let's stick to that for now or generalize slightly.
        # Research said: 2 letters + 4 numbers OR 3 letters + 3 numbers.
        # Let's support both.
        # ^[A-Z]{2}[0-9]{4}$ OR ^[A-Z]{3}[0-9]{3}$

    @classmethod
    def validate_strict(cls, plate: str) -> bool:
        plate = plate.upper().replace('-', '').replace(' ', '')
        if re.match(r'^[A-Z]{2}[0-9]{4}$', plate): return True
        if re.match(r'^[A-Z]{3}[0-9]{3}$', plate): return True
        return False

