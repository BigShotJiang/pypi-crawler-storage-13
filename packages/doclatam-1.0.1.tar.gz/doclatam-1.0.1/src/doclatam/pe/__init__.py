from .dni import DNI
from .ruc import RUC
from .placa import Placa
from .passaporte import Passaporte
