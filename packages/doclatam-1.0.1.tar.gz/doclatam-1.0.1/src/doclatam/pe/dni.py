from ..core.base import BaseValidator

class DNI(BaseValidator):
    """
    Validator for Peruvian DNI.
    Validates format (8 digits).
    """

    @classmethod
    def validate(cls, doc: str) -> bool:
        doc = cls.clean(doc)
        return len(doc) == 8

    @classmethod
    def format(cls, doc: str) -> str:
        doc = cls.clean(doc)
        if len(doc) != 8:
             raise ValueError("DNI must have 8 digits")
        return doc
