from ..core.base import BaseValidator
import re

class Passaporte(BaseValidator):
    """
    Validator for Chilean Passport.
    Format: Alphanumeric, often similar to RUN/RUT but as document number.
    """

    @classmethod
    def validate(cls, doc: str) -> bool:
        doc = doc.upper().replace(' ', '')
        # Chile passport often matches the RUN/RUT number or is alphanumeric
        # Let's assume a general alphanumeric format of 9 characters for now
        return bool(re.match(r'^[A-Z0-9]{9}$', doc)) or bool(re.match(r'^[0-9]{8,9}$', doc))

    @classmethod
    def format(cls, doc: str) -> str:
        doc = doc.upper().replace(' ', '')
        if not cls.validate(doc):
             raise ValueError("Invalid passport format")
        return doc
