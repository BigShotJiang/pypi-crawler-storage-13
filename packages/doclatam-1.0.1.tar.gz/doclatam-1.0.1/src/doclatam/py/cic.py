from ..core.base import BaseValidator

class CIC(BaseValidator):
    """
    Validator for Paraguayan Cédula de Identidad Civil (CIC).
    Validates format only (numeric).
    """

    @classmethod
    def validate(cls, doc: str) -> bool:
        doc = cls.clean(doc)
        # Typically 5 to 8 digits
        return 5 <= len(doc) <= 8

    @classmethod
    def format(cls, doc: str) -> str:
        doc = cls.clean(doc)
        if not (5 <= len(doc) <= 8):
             raise ValueError("Invalid CIC length")
        
        # Format with dots
        # 1.234.567
        reversed_doc = doc[::-1]
        formatted = ""
        for i, digit in enumerate(reversed_doc):
            if i > 0 and i % 3 == 0:
                formatted = "." + formatted
            formatted = digit + formatted
        return formatted
