from ..core.base import BaseValidator
import re

class Passaporte(BaseValidator):
    """
    Validator for Paraguayan Passport.
    """

    @classmethod
    def validate(cls, doc: str) -> bool:
        doc = doc.upper().replace(' ', '')
        # Typically alphanumeric
        return bool(re.match(r'^[A-Z0-9]{6,9}$', doc))

    @classmethod
    def format(cls, doc: str) -> str:
        doc = doc.upper().replace(' ', '')
        if not cls.validate(doc):
             raise ValueError("Invalid passport format")
        return doc
