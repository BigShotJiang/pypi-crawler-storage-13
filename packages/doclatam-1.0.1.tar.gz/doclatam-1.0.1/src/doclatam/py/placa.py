import re

class PlacaMercosul:
    """
    Validator for Mercosur License Plates (Paraguay standard).
    Format: LLLL123
    """

    @classmethod
    def validate(cls, plate: str) -> bool:
        plate = plate.upper().replace('-', '').replace(' ', '')
        # 4 letters, 3 numbers
        return bool(re.match(r'^[A-Z]{4}[0-9]{3}$', plate))
