from .ruc import RUC
from .cic import CIC
from .placa import PlacaMercosul
from .passaporte import Passaporte
