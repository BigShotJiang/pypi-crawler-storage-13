from ..core.base import BaseValidator

class PIS(BaseValidator):
    """
    Validator for Brazilian PIS/PASEP.
    """

    @classmethod
    def validate(cls, doc: str) -> bool:
        doc = cls.clean(doc)
        
        if len(doc) != 11:
            return False
            
        if doc == doc[0] * 11:
            return False

        weights = [3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        sum_val = sum(int(doc[i]) * weights[i] for i in range(10))
        
        remainder = sum_val % 11
        digit = 0 if (11 - remainder) in [10, 11] else 11 - remainder

        return int(doc[10]) == digit

    @classmethod
    def format(cls, doc: str) -> str:
        doc = cls.clean(doc)
        if len(doc) != 11:
            raise ValueError("PIS/PASEP must have 11 digits")
        return f"{doc[:3]}.{doc[3:8]}.{doc[8:10]}-{doc[10]}"
