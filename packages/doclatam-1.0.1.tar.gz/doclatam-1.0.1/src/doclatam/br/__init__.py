from .cpf import CPF
from .cnpj import CNPJ
from .pis import PIS
from .cnh import CNH
from .titulo_eleitor import TituloEleitor
from .renavam import Renavam
from .placa import PlacaMercosul
from .passaporte import Passaporte
import re
from typing import List, Dict

def extract_all(text: str) -> List[Dict[str, str]]:
    """
    Extracts all valid CPF and CNPJ from the text.
    Returns: [{'type': 'CPF', 'value': '...'}, {'type': 'CNPJ', 'value': '...'}]
    """
    results = []
    seen = set()
    
    # Find potential candidates: sequences of digits and separators
    # \b ensures boundaries, but we allow dots, dashes, slashes inside
    matches = re.finditer(r'\b\d[\d\.\-\/]*\d\b', text)
    
    for match in matches:
        raw = match.group()
        clean = re.sub(r'[^0-9]', '', raw)
        
        if clean in seen:
            continue
            
        if len(clean) == 11:
            if CPF.validate(clean):
                results.append({'type': 'CPF', 'value': raw})
                seen.add(clean)
        elif len(clean) == 14:
            if CNPJ.validate(clean):
                results.append({'type': 'CNPJ', 'value': raw})
                seen.add(clean)
                
    return results
