from ..core.base import BaseValidator
import re

class Passaporte(BaseValidator):
    """
    Validator for Brazilian Passport.
    Format: 2 letters + 6 numbers (e.g., AB123456).
    """

    @classmethod
    def validate(cls, doc: str) -> bool:
        doc = doc.upper().replace(' ', '')
        # Standard format: 2 letters followed by 6 digits
        return bool(re.match(r'^[A-Z]{2}[0-9]{6}$', doc))

    @classmethod
    def format(cls, doc: str) -> str:
        doc = doc.upper().replace(' ', '')
        if not cls.validate(doc):
             raise ValueError("Invalid passport format")
        return doc
