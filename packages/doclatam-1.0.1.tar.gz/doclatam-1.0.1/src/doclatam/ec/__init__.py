from .ci import CI
from .ruc import RUC
from .placa import Placa
from .passaporte import Passaporte
