import re

class Placa:
    """
    Validator for Ecuadorian License Plates.
    Format: ABC-1234 (3 letters, 3-4 numbers)
    """

    @classmethod
    def validate(cls, plate: str) -> bool:
        plate = plate.upper().replace('-', '').replace(' ', '')
        return bool(re.match(r'^[A-Z]{3}[0-9]{3,4}$', plate))
