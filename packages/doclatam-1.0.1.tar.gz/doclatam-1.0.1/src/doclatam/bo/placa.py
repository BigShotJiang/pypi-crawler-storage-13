import re

class Placa:
    """
    Validator for Bolivian License Plates.
    Format: 1234ABC (4 numbers, 3 letters)
    """

    @classmethod
    def validate(cls, plate: str) -> bool:
        plate = plate.upper().replace('-', '').replace(' ', '')
        return bool(re.match(r'^[0-9]{4}[A-Z]{3}$', plate))
