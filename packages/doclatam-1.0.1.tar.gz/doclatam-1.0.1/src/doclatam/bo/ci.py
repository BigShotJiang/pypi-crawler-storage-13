from ..core.base import BaseValidator

class CI(BaseValidator):
    """
    Validator for Bolivian Cédula de Identidad (CI).
    Validates format only (numeric, 7-10 digits).
    """

    @classmethod
    def validate(cls, doc: str) -> bool:
        doc = cls.clean(doc)
        return 7 <= len(doc) <= 10

    @classmethod
    def format(cls, doc: str) -> str:
        doc = cls.clean(doc)
        if not (7 <= len(doc) <= 10):
             raise ValueError("Invalid CI length")
        return doc
