from .ci import CI
from .placa import Placa
from .passaporte import Passaporte
