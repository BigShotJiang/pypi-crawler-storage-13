from .placa import PlacaMercosul
from .ci import CI
from .passaporte import Passaporte
