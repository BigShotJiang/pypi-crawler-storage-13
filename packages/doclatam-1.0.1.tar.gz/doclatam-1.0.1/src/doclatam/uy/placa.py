import re

class PlacaMercosul:
    """
    Validator for Mercosur License Plates (Uruguay standard).
    Format: LLL1234
    """

    @classmethod
    def validate(cls, plate: str) -> bool:
        """Validates if the plate is in Uruguay Mercosur format."""
        plate = plate.upper().replace('-', '').replace(' ', '')
        
        # Check Mercosur format (LLL1234)
        # 3 letters, 4 numbers
        if re.match(r'^[A-Z]{3}[0-9]{4}$', plate):
            return True
            
        return False
