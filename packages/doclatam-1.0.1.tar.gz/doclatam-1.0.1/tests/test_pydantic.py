import unittest
try:
    from pydantic import BaseModel, ValidationError
    from doclatam.integrations.pydantic import CPF, CNPJ, CUIT, RUT, RUC, CURP, RFC
    from doclatam.br.cpf import CPF as CPFVal
    
    HAS_PYDANTIC = True
except ImportError:
    HAS_PYDANTIC = False

class TestPydantic(unittest.TestCase):

    def setUp(self):
        if not HAS_PYDANTIC:
            self.skipTest("Pydantic not installed")

    def test_cpf_model(self):
        class User(BaseModel):
            cpf: CPF

        # Valid
        valid_cpf = CPFVal.generate()
        user = User(cpf=valid_cpf)
        self.assertEqual(user.cpf, valid_cpf)

        # Invalid
        with self.assertRaises(ValidationError):
            User(cpf="123.456.789-00")

    def test_curp_model(self):
        class Person(BaseModel):
            curp: CURP
            
        # Valid (Generate one)
        from doclatam.mx.curp import CURP as CURPVal
        valid_curp = CURPVal.generate()
        p = Person(curp=valid_curp)
        self.assertEqual(p.curp, valid_curp)
        
        # Invalid
        with self.assertRaises(ValidationError):
            Person(curp="INVALIDCURP")

if __name__ == '__main__':
    unittest.main()
