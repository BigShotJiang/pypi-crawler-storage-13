"""
Property-based testing with Hypothesis for robust validation.
"""
import unittest
try:
    from hypothesis import given, strategies as st, assume
    from doclatam.br.cpf import CPF
    from doclatam.ar.cuit import CUIT
    from doclatam.cl.rut import RUT
    
    HAS_HYPOTHESIS = True
except ImportError:
    HAS_HYPOTHESIS = False

class TestHypothesis(unittest.TestCase):

    def setUp(self):
        if not HAS_HYPOTHESIS:
            self.skipTest("Hypothesis not installed")

    @given(st.text())
    def test_cpf_never_crashes(self, text):
        """CPF validator should never crash, regardless of input."""
        try:
            result = CPF.validate(text)
            self.assertIsInstance(result, bool)
        except Exception as e:
            self.fail(f"CPF.validate crashed with: {e}")

    @given(st.text())
    def test_cuit_never_crashes(self, text):
        """CUIT validator should never crash, regardless of input."""
        try:
            result = CUIT.validate(text)
            self.assertIsInstance(result, bool)
        except Exception as e:
            self.fail(f"CUIT.validate crashed with: {e}")

    @given(st.text())
    def test_rut_never_crashes(self, text):
        """RUT validator should never crash, regardless of input."""
        try:
            result = RUT.validate(text)
            self.assertIsInstance(result, bool)
        except Exception as e:
            self.fail(f"RUT.validate crashed with: {e}")

    def test_generated_cpf_always_valid(self):
        """All generated CPFs must be valid."""
        for _ in range(100):
            cpf = CPF.generate()
            self.assertTrue(CPF.validate(cpf), f"Generated CPF {cpf} is invalid")

    def test_generated_cuit_always_valid(self):
        """All generated CUITs must be valid."""
        for _ in range(100):
            cuit = CUIT.generate()
            self.assertTrue(CUIT.validate(cuit), f"Generated CUIT {cuit} is invalid")

if __name__ == '__main__':
    unittest.main()
