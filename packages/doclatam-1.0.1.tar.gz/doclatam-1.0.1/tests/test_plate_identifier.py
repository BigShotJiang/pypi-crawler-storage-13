import unittest
from doclatam.utils import identify_plate

class TestPlateIdentifier(unittest.TestCase):

    def test_brasil_mercosul(self):
        self.assertIn('Brasil', identify_plate('ABC1D23'))
        
    def test_brasil_antiga(self):
        result = identify_plate('ABC-1234')
        self.assertTrue('Brasil' in result or 'Uruguai' in result)
        
    def test_argentina(self):
        self.assertIn('Argentina', identify_plate('AA123BB'))
        
    def test_paraguai(self):
        self.assertIn('Paraguai', identify_plate('ABCD123'))
        
    def test_bolivia(self):
        self.assertIn('Bolívia', identify_plate('1234ABC'))
        
    def test_peru(self):
        self.assertIn('Peru', identify_plate('ABC-123'))
        
    def test_venezuela(self):
        self.assertIn('Venezuela', identify_plate('AB123CD'))
        
    def test_unknown(self):
        self.assertEqual(['Desconhecido'], identify_plate('INVALID'))

if __name__ == '__main__':
    unittest.main()
