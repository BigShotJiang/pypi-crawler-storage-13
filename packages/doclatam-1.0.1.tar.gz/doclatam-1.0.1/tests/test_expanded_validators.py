import unittest
from doclatam.uy import CI as CI_UY, PlacaMercosul as Placa_UY, Passaporte as Passaporte_UY
from doclatam.py import RUC as RUC_PY, CIC as CIC_PY, PlacaMercosul as Placa_PY, Passaporte as Passaporte_PY
from doclatam.bo import CI as CI_BO, Placa as Placa_BO, Passaporte as Passaporte_BO
from doclatam.pe import DNI as DNI_PE, RUC as RUC_PE, Placa as Placa_PE, Passaporte as Passaporte_PE
from doclatam.ec import CI as CI_EC, RUC as RUC_EC, Placa as Placa_EC, Passaporte as Passaporte_EC
from doclatam.co import NIT as NIT_CO, Placa as Placa_CO, Passaporte as Passaporte_CO
from doclatam.ve import RIF as RIF_VE, CI as CI_VE, Placa as Placa_VE, Passaporte as Passaporte_VE
from doclatam.br import Passaporte as Passaporte_BR
from doclatam.ar import Passaporte as Passaporte_AR
from doclatam.cl import Passaporte as Passaporte_CL

class TestExpandedValidators(unittest.TestCase):

    # --- Uruguay ---
    def test_uy_ci(self):
        # Valid CI (generated/known valid)
        # 1.234.567-2 (Check digit calculation: 1*2 + 2*9 + 3*8 + 4*7 + 5*6 + 6*3 + 7*4 = 2+18+24+28+30+18+28 = 148. 148%10=8. 10-8=2. Correct.)
        self.assertTrue(CI_UY.validate("1.234.567-2"))
        self.assertTrue(CI_UY.validate("12345672"))
        self.assertFalse(CI_UY.validate("12345670")) # Invalid check digit

    def test_uy_passaporte(self):
        self.assertTrue(Passaporte_UY.validate("A123456"))
        self.assertFalse(Passaporte_UY.validate("123"))

    # --- Paraguay ---
    def test_py_ruc(self):
        # Valid RUC: 80001234-5 (Example)
        # Base 80001234. 
        # 4*2 + 3*3 + 2*4 + 1*5 + 0*6 + 0*7 + 0*8 + 8*9 = 8+9+8+5+0+0+0+72 = 102. 102%11 = 3. 11-3=8.
        # Let's try to construct a valid one.
        # Base 1001. 1*2 + 0*3 + 0*4 + 1*5 = 2+0+0+5=7. 7%11=7. 11-7=4. RUC 1001-4
        self.assertTrue(RUC_PY.validate("1001-4"))
        self.assertFalse(RUC_PY.validate("1001-5"))

    def test_py_cic(self):
        self.assertTrue(CIC_PY.validate("1234567"))
        self.assertFalse(CIC_PY.validate("123")) # Too short

    def test_py_placa(self):
        self.assertTrue(Placa_PY.validate("ABCD123"))
        self.assertFalse(Placa_PY.validate("ABC1234"))

    # --- Bolivia ---
    def test_bo_ci(self):
        self.assertTrue(CI_BO.validate("1234567"))
        self.assertFalse(CI_BO.validate("123"))

    def test_bo_placa(self):
        self.assertTrue(Placa_BO.validate("1234ABC"))
        self.assertFalse(Placa_BO.validate("ABC1234"))

    # --- Peru ---
    def test_pe_dni(self):
        self.assertTrue(DNI_PE.validate("12345678"))
        self.assertFalse(DNI_PE.validate("1234567")) # 7 digits

    def test_pe_ruc(self):
        # Valid RUC: 10 + DNI + DV
        # Example: 20100070970 (SUNAT example)
        # Weights: 5,4,3,2,7,6,5,4,3,2
        # 2*5 + 0*4 + 1*3 + 0*2 + 0*7 + 0*6 + 7*5 + 0*4 + 9*3 + 7*2
        # 10 + 0 + 3 + 0 + 0 + 0 + 35 + 0 + 27 + 14 = 89. 89%11 = 1. 11-1=10 -> 0.
        # So 20100070970 is valid.
        self.assertTrue(RUC_PE.validate("20100070970"))
        self.assertFalse(RUC_PE.validate("20100070971"))

    def test_pe_placa(self):
        self.assertTrue(Placa_PE.validate("ABC-123"))
        self.assertTrue(Placa_PE.validate("AB-1234")) # Old format supported
        self.assertFalse(Placa_PE.validate("123-ABC"))

    # --- Ecuador ---
    def test_ec_ci(self):
        # Valid CI: 1710034065 (Pichincha)
        # 1*2 + 7*1 + 1*2 + 0*1 + 0*2 + 3*1 + 4*2 + 0*1 + 6*2
        # 2 + 7 + 2 + 0 + 0 + 3 + 8 + 0 + 12(->3) = 25. 25%10=5. 10-5=5. Last digit 5. Correct.
        self.assertTrue(CI_EC.validate("1710034065"))
        self.assertFalse(CI_EC.validate("1710034066"))

    def test_ec_ruc(self):
        # Natural person RUC = CI + 001
        self.assertTrue(RUC_EC.validate("1710034065001"))
        self.assertFalse(RUC_EC.validate("1710034065002"))

    def test_ec_placa(self):
        self.assertTrue(Placa_EC.validate("ABC-1234"))
        self.assertFalse(Placa_EC.validate("AB-1234"))

    # --- Colombia ---
    def test_co_nit(self):
        # Valid NIT: 800197268-4 (DIAN example)
        # Base 800197268.
        # Rev: 8,6,2,7,9,1,0,0,8
        # Weights: 3,7,13,17,19,23,29,37,41
        # 8*3 + 6*7 + 2*13 + 7*17 + 9*19 + 1*23 + 0 + 0 + 8*41
        # 24 + 42 + 26 + 119 + 171 + 23 + 0 + 0 + 328 = 733.
        # 733 % 11 = 7. 11-7=4. Correct.
        self.assertTrue(NIT_CO.validate("800197268-4"))
        self.assertFalse(NIT_CO.validate("800197268-5"))

    def test_co_placa(self):
        self.assertTrue(Placa_CO.validate("ABC-123"))
        self.assertTrue(Placa_CO.validate("AB-1234")) # Diplomatic style
        self.assertFalse(Placa_CO.validate("123-ABC"))

    # --- Venezuela ---
    def test_ve_rif(self):
        # Valid RIF: V-12345678-?
        # Let's calculate one. V=4. Base 12345678.
        # Weights: 3,2,7,6,5,4,3,2
        # 1*3 + 2*2 + 3*7 + 4*6 + 5*5 + 6*4 + 7*3 + 8*2
        # 3 + 4 + 21 + 24 + 25 + 24 + 21 + 16 = 138.
        # Total = 4 (V) + 138 = 142.
        # 142 % 11 = 10. 11-10=1. DV=1.
        self.assertTrue(RIF_VE.validate("V-12345678-1"))
        self.assertFalse(RIF_VE.validate("V-12345678-0"))

    def test_ve_ci(self):
        self.assertTrue(CI_VE.validate("12345678"))
        self.assertFalse(CI_VE.validate("123"))

    def test_ve_placa(self):
        self.assertTrue(Placa_VE.validate("AB123CD"))
        self.assertFalse(Placa_VE.validate("ABC123D"))

    # --- Passports (General) ---
    def test_passports(self):
        self.assertTrue(Passaporte_BR.validate("AB123456"))
        self.assertTrue(Passaporte_AR.validate("AAA123456"))
        self.assertTrue(Passaporte_CL.validate("123456789"))

if __name__ == '__main__':
    unittest.main()
