import unittest
from doclatam.br.cpf import CPF
from doclatam.br.cnpj import CNPJ
from doclatam.ar.cuit import CUIT
from doclatam.cl.rut import RUT
from doclatam.py.ruc import RUC

class TestEdgeCases(unittest.TestCase):

    def test_empty_strings(self):
        self.assertFalse(CPF.validate(""))
        self.assertFalse(CNPJ.validate(""))
        self.assertFalse(CUIT.validate(""))
        self.assertFalse(RUT.validate(""))
        self.assertFalse(RUC.validate(""))

    def test_garbage_strings(self):
        self.assertFalse(CPF.validate("abcdefghijk"))
        self.assertFalse(CNPJ.validate("!@#$%^&*()"))
        self.assertFalse(CUIT.validate("invalid-cuit"))

    def test_formatting_handling(self):
        # Ensure validators handle formatted strings correctly (clean method)
        # CPF
        self.assertTrue(CPF.validate("123.456.789-09")) # Assuming this is the invalid one from before? 
        # Wait, 123.456.789-09 is mathematically invalid.
        # Let's use a valid one with extra formatting
        valid_cpf = CPF.generate()
        formatted_cpf = f"{valid_cpf[:3]}.{valid_cpf[3:6]}.{valid_cpf[6:9]}-{valid_cpf[9:]}"
        self.assertTrue(CPF.validate(formatted_cpf))
        
        # Valid one with weird formatting
        weird_cpf = f"{valid_cpf[:3]}/{valid_cpf[3:6]}.{valid_cpf[6:9]} {valid_cpf[9:]}"
        self.assertTrue(CPF.validate(weird_cpf)) # Should clean non-digits

    def test_types(self):
        # BaseValidator.clean converts input to string, so integers should work if valid
        # This is a feature, not a bug (robustness)
        
        # Integer input
        # Assuming 11111111111 is invalid CPF but valid format (11 digits)
        self.assertFalse(CPF.validate(11111111111)) 
        
        # None input
        # str(None) -> "None" -> clean -> "" -> False
        self.assertFalse(CPF.validate(None))

if __name__ == '__main__':
    unittest.main()
