import unittest
from doclatam.br.cpf import CPF
from doclatam.br.cnpj import CNPJ
from doclatam.ar.cuit import CUIT
from doclatam.cl.rut import RUT
from doclatam.uy.ci import CI
from doclatam.py.ruc import RUC
from doclatam.pe.ruc import RUC as RUC_PE
from doclatam.ec.ci import CI as CI_EC
from doclatam.co.nit import NIT
from doclatam.ve.rif import RIF
from doclatam.mx.curp import CURP

class TestGenerators(unittest.TestCase):

    def test_cpf_generate(self):
        for _ in range(10):
            doc = CPF.generate()
            self.assertTrue(CPF.validate(doc), f"Generated CPF {doc} is invalid")

    def test_cuit_generate(self):
        for _ in range(10):
            doc = CUIT.generate()
            self.assertTrue(CUIT.validate(doc), f"Generated CUIT {doc} is invalid")

    def test_rut_generate(self):
        for _ in range(10):
            doc = RUT.generate()
            self.assertTrue(RUT.validate(doc), f"Generated RUT {doc} is invalid")

    def test_ci_uy_generate(self):
        for _ in range(10):
            doc = CI.generate()
            self.assertTrue(CI.validate(doc), f"Generated CI UY {doc} is invalid")

    def test_ruc_py_generate(self):
        for _ in range(10):
            doc = RUC.generate()
            self.assertTrue(RUC.validate(doc), f"Generated RUC PY {doc} is invalid")

    def test_ruc_pe_generate(self):
        for _ in range(10):
            doc = RUC_PE.generate()
            self.assertTrue(RUC_PE.validate(doc), f"Generated RUC PE {doc} is invalid")

    def test_ci_ec_generate(self):
        for _ in range(10):
            doc = CI_EC.generate()
            self.assertTrue(CI_EC.validate(doc), f"Generated CI EC {doc} is invalid")

    def test_nit_co_generate(self):
        for _ in range(10):
            doc = NIT.generate()
            self.assertTrue(NIT.validate(doc), f"Generated NIT CO {doc} is invalid")

    def test_rif_ve_generate(self):
        for _ in range(10):
            doc = RIF.generate()
            self.assertTrue(RIF.validate(doc), f"Generated RIF VE {doc} is invalid")

    def test_curp_mx_generate(self):
        for _ in range(10):
            doc = CURP.generate()
            self.assertTrue(CURP.validate(doc), f"Generated CURP MX {doc} is invalid")

if __name__ == '__main__':
    unittest.main()
